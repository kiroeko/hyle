"""B04 metadata only. No tensor body mode; no HTTP with --plan-only.

Root owns actual network execution. The current acquisition pause still applies.
Reuse strict206 HTTP and the frozen S01 GGUF parser; derive physical offsets
from the actual header, never from B03/S01 or the fidelity filename.
"""
import argparse
import hashlib
import importlib.util
import json
import math
from pathlib import Path
import struct
import sys

sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
R = S.parents[2]
REPO = 'unsloth/Qwen3.8-27B-GGUF'
REV = '4ca720788d1e01f1bff70c033e0d0028fd02e502'
FILE = 'Qwen3.8-27B-UD-Q8_K_XL.gguf'
URL = f'https://huggingface.co/{REPO}/resolve/{REV}/{FILE}'
CENSUS = R / '.scratch/gguf-weight-audit.json'
REVIEW = S.parent / 'review/b04-fidelity-next.json'
HTTP = R / '.scratch/mtp-artifact-schema-20261023/fetch_headers.py'
PARSER = S.parent / 'S01/fetch_headers.py'
PARSER_SHA = '503da40eb3efab9b05b80213fe77606324eae176d0c4f61055bdde7b7a51c1e5'
LIMIT, CHUNK = 16 * 1024 * 1024, 256 * 1024
TENSORS = 866
TYPES = {0: ('F32', 1, 4), 8: ('Q8_0', 32, 34), 30: ('BF16', 1, 2)}


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def identity(path):
    raw = path.read_bytes()
    return dict(path=path.relative_to(R).as_posix(), bytes=len(raw), sha256=sha(raw))


def save(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + '.next')
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    temporary.replace(path)


def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


def expected():
    review = read(REVIEW)
    assert identity(CENSUS)['sha256'] == review['evidence']['census_file_sha256']
    census = read(CENSUS)['qwen38_27b_ud_q8_k_xl']
    assert (census['repo'], census['revision'], census['first_file']) == (REPO, REV, FILE)
    assert census['complete'] and census['tensor_count'] == len(census['tensors']) == TENSORS
    rows = {t['name']: (list(map(int, t['shape'])), t['dtype']) for t in census['tensors']}
    assert len(rows) == TENSORS and len(review['role_manifest']) == 29
    assert identity(PARSER)['sha256'] == PARSER_SHA
    return rows, review


class MetadataReader:
    """Read only bytes proved to belong to GGUF metadata by its structure.

    minimum_after is a conservative LOWER bound for still-unread metadata,
    not a guessed prefix size. Readahead can never exceed that lower bound.
    All tensor records need at least32 bytes (empty name, rank1). A remaining
    KV needs at least13 bytes; a remaining string-array item needs8 bytes.
    Requests are disjoint, sequential, <=256KiB, and share one strong ETag.
    """
    def __init__(self, exact):
        self.exact, self.raw, self.offset = exact, bytearray(), 0
        self.total = self.etag = None

    def take(self, size, minimum_after=0):
        assert 0 <= size <= LIMIT and minimum_after >= 0
        end = self.offset + size
        assert end <= LIMIT, 'GGUF metadata exceeds16MiB; refuse body/prefix guessing'
        while len(self.raw) < end:
            first = len(self.raw)
            stop = min(end + minimum_after, first + CHUNK, LIMIT)
            assert stop > first
            part, total, etag = self.exact(URL, first, stop - 1, total=self.total, etag=self.etag)
            assert len(part) == stop - first
            self.total, self.etag = total, etag
            self.raw.extend(part)
        result = self.raw[self.offset:end]
        self.offset = end
        return result

    def number(self, fmt, minimum_after=0):
        return struct.unpack('<' + fmt, self.take(struct.calcsize('<' + fmt), minimum_after))[0]

    def string(self, minimum_after=0, keep=True):
        size = self.number('Q', minimum_after)
        raw = self.take(size, minimum_after)
        return raw.decode('utf-8') if keep else None


def scan(exact, tensor_count=TENSORS):
    reader = MetadataReader(exact)
    magic, version, count, metadata_count = struct.unpack('<4sIQQ', reader.take(24))
    assert magic == b'GGUF' and version in (2, 3) and count == tensor_count
    assert 0 < metadata_count <= 1000
    formats = {0: 'B', 1: 'b', 2: 'H', 3: 'h', 4: 'I', 5: 'i', 6: 'f',
               7: '?', 10: 'Q', 11: 'q', 12: 'd'}

    def value(kind, after, keep):
        if kind in formats:
            result = reader.number(formats[kind], after)
            return result if keep else None
        if kind == 8:
            return reader.string(after, keep)
        assert kind == 9, 'Unknown GGUF metadata type'
        element = reader.number('I', after + 8)
        length = reader.number('Q', after)
        assert element != 9 and length <= LIMIT
        if element in formats:
            width = struct.calcsize('<' + formats[element])
            raw = reader.take(length * width, after)
            return list(struct.unpack('<' + formats[element] * length, raw)) if keep else None
        assert element == 8
        result = [] if keep else None
        for index in range(length):
            item = reader.string(after + (length - index - 1) * 8, keep)
            if keep:
                result.append(item)
        return result

    metadata, seen = {}, set()
    for index in range(metadata_count):
        after = (metadata_count - index - 1) * 13 + tensor_count * 32
        key = reader.string(after + 5)
        assert key not in seen
        seen.add(key)
        kind = reader.number('I', after + 1)
        # Preserve ordinary config scalars and strings, not duplicated tokens.
        keep = not key.startswith('tokenizer.') and kind != 9
        result = value(kind, after, keep)
        if keep:
            metadata[key] = result
    tensors = []
    for index in range(tensor_count):
        after = (tensor_count - index - 1) * 32
        name = reader.string(after + 24)
        rank = reader.number('I', after + 20)
        assert 0 < rank <= 4
        shape = list(struct.unpack('<' + 'Q' * rank, reader.take(rank * 8, after + 12)))
        assert all(n > 0 for n in shape)
        code = reader.number('I', after + 8)
        offset = reader.number('Q', after)
        tensors.append(dict(name=name, shape=shape, dtype_code=code, offset=offset))
    alignment = metadata.get('general.alignment', 32)
    assert type(alignment) is int and 0 < alignment <= 4096
    data_base = (reader.offset + alignment - 1) // alignment * alignment
    reader.take(data_base - reader.offset)
    assert len(reader.raw) == reader.offset == data_base
    return bytes(reader.raw), metadata, tensors, metadata_count, reader.total, reader.etag


def emit(raw, metadata, tensors, metadata_count, total, etag, expected_rows, review):
    parser = module('b04_reused_s01_parser', PARSER)
    parsed_metadata, parsed_tensors, parsed_count = parser.parse_header(raw, TENSORS, len(raw), metadata)
    assert parsed_metadata == metadata and parsed_tensors == tensors and parsed_count == metadata_count
    actual, table = {}, {}
    for row in tensors:
        name, shape, code, offset = row['name'], row['shape'], row['dtype_code'], row['offset']
        dtype, block, physical = TYPES[code]
        assert name not in actual and expected_rows[name] == (shape, dtype)
        assert shape[0] % block == 0 and offset % metadata.get('general.alignment', 32) == 0
        extent = math.prod(shape) // block * physical
        assert len(raw) + offset + extent <= total
        actual[name] = dict(row, dtype=dtype, bytes=extent)
        table[name] = dict(dtype=dtype, shape=shape, data_offsets=[offset, offset + extent])
    assert set(actual) == set(expected_rows)
    ordered = sorted(actual.values(), key=lambda row: row['offset'])
    assert all(left['offset'] + left['bytes'] <= right['offset']
               for left, right in zip(ordered, ordered[1:]))
    (S / 'original-header.bin').write_bytes(raw)
    save(S / 'header-table.json', table)
    save(S / 'physical-table.json', dict(tensors=list(actual.values()), metadata=metadata))
    receipt = dict(complete=True, repository=REPO, revision=REV, file=FILE, url=URL,
                   data_base=len(raw), whole_file_bytes=total, etag=etag, http_status=206,
                   tensor_count=TENSORS, metadata_count=metadata_count, header=identity(S / 'original-header.bin'),
                   physical_table=identity(S / 'physical-table.json'), fixed_census=identity(CENSUS),
                   http_helper=identity(HTTP), parser=identity(PARSER), tensor_payload_bytes=0,
                   metadata_bytes=len(raw), maximum_metadata_bytes=LIMIT, whole_shards_downloaded=False)
    save(S / 'header.json', receipt)
    shard = dict(file=FILE, url=URL, data_base=len(raw), whole_file_bytes=total, etag=etag,
                 header=identity(S / 'header-table.json'), raw_gguf_header=receipt['header'], source_format='GGUF')
    groups = [('draft', 'nextn64', 15, 569284608), ('target', 'target63_and_global_norm', 12, 464386048),
              ('vocabulary', 'vocabulary', 2, 3893657600), ('all', None, 29, 4927328256)]
    for group, selection, count, size in groups:
        roles, ranges, cursor = [], [], 0
        chosen = [r for r in review['role_manifest'] if selection is None or r['group'] == selection]
        for source in sorted(chosen, key=lambda item: actual[item['name']]['offset']):
            row = actual[source['name']]
            assert row['bytes'] == source['bytes']
            first = len(raw) + row['offset']
            roles.append(dict(index=len(roles), name=row['name'], dtype=row['dtype'], dtype_code=row['dtype_code'],
                shape=row['shape'], bytes=row['bytes'], source_shard=0, bundle_offset=cursor,
                data_relative_half_open=[row['offset'], row['offset'] + row['bytes']],
                absolute_inclusive=[first, first + row['bytes'] - 1]))
            # Merge only physically touching roles. No unrequested gap bytes.
            if ranges and ranges[-1]['last'] + 1 == first:
                ranges[-1]['last'] += row['bytes']; ranges[-1]['bytes'] += row['bytes']
            else:
                ranges.append(dict(index=len(ranges), source_shard=0, first=first,
                    last=first + row['bytes'] - 1, bundle_offset=cursor, bytes=row['bytes']))
            cursor += row['bytes']
        assert len(roles) == count and cursor == size
        save(S / f'{group}-plan.json', dict(repository=REPO, revision=REV, file=FILE, group=group,
             original_roles=count, bundle_bytes=size, shards=[shard], roles=roles, groups=ranges,
             original_header=identity(S / 'header.json'), whole_shards_downloaded=False, unrequested_bytes=0))
    return receipt


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--plan-only', action='store_true', help='Only validate local census and budget; zero HTTP.')
    args = parser.parse_args()
    expected_rows, review = expected()
    S.mkdir(parents=True, exist_ok=True)
    if args.plan_only:
        result = dict(offline=True, network_bytes=0, repository=REPO, revision=REV, file=FILE,
            complete_census=TENSORS, exact_data_base=None, exact_ranges=None,
            maximum_metadata_bytes=LIMIT, maximum_request_bytes=CHUNK,
            planned_groups=dict(draft=dict(roles=15, bytes=569284608), target=dict(roles=12, bytes=464386048),
                                vocabulary=dict(roles=2, bytes=3893657600)),
            all29_payload_bytes=4927328256, maximum_header_plus_all29_bytes=4927328256 + LIMIT,
            reuse=dict(downloader='.scratch/qwen-gguf-selected-20261023/B04/fetch_loose_roles.py',
                      loader='qwen27_original_nextn_roles::Data::load', body_pin_reuse=0),
            pause='Prepared only. Actual network remains paused by root/user budget policy.')
        save(S / 'prefetch-budget.json', result)
        print(json.dumps(result))
        return
    if (S / 'header.json').exists():
        receipt = read(S / 'header.json')
        assert receipt['complete'] and (receipt['repository'], receipt['revision'], receipt['file']) == (REPO, REV, FILE)
        assert identity(S / 'original-header.bin') == receipt['header']
        print(json.dumps(receipt))
        return
    helper = module('b04_reused_strict206', HTTP)
    helper.MAX_TOTAL = LIMIT
    try:
        result = scan(helper.exact)
        receipt = emit(*result, expected_rows, review)
        print(json.dumps(receipt))
    finally:
        save(S / 'http-requests.json', helper.requests)


if __name__ == '__main__':
    main()
