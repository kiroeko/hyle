"""B04 exact29-role loose acquisition adapter. Root runs actual HTTP.

Reuse the existing B02 main/acquire_role/single-writer/resume implementation;
only physical GGUF plan validation and the final manifest description differ.
Never use B04/fetch_roles.py (the obsolete aggregate-bundle proposal).
"""
import importlib.util
import json
from pathlib import Path
import sys

sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
R = S.parents[2]


def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


def configured():
    schema = module('b04_checked_loose_schema', S / 'prepare_loose_plan.py')
    common = module('b04_existing_loose_acquisition', R / '.scratch/qwen-bfloat-selected-20261023/fetch_roles.py')
    # The reviewed request-cap adapter preserves the128MiB authenticated resume
    # format but caps each new request at8MiB. It extracts the same acquire_role.
    capped = module('b04_existing_request_cap', R / '.scratch/qwen-gguf-selected-20261023/offline/request-chunk/next-source/fetch_roles.py')
    capped.R, capped.HELPER, capped.HELPER_SHA = common.R, common.HELPER, common.HELPER_SHA
    original_manifests = common.manifests
    common.ARTIFACT_DIR = S
    common.REPO = 'unsloth/Qwen3.8-27B-GGUF'
    common.REV = '4ca720788d1e01f1bff70c033e0d0028fd02e502'
    common.COUNT, common.BODY = schema.COUNT, schema.BODY
    common.NEXTN_COUNT, common.TARGET_COUNT, common.TARGET_SECTION = 17, 12, 'target63'
    common.checked_plan = schema.checked_plan
    common.downloader = lambda record, receipt: capped.downloader(record, receipt, request_chunk_bytes=8*1024*1024)

    def manifests(out, record):
        original_manifests(out, record)
        for name in ('manifest.json', 'nextn-manifest.json', 'target-manifest.json'):
            path = out / name
            value = common.read(path)
            value.update(file='Qwen3.8-27B-UD-Q8_K_XL.gguf', variant='UD-Q8_K_XL',
                source_receipt=common.identity(out / 'acquisition.json'),
                source_plan=common.identity(S / 'loose-plan.json'),
                source_header=common.identity(S / 'header.json'),
                scope='Actual original GGUF BF16/F32/Q8_0 loose roles. Original bytes, no repack or duplicate vocabulary; no full model execution claim.')
            path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    common.manifests = manifests
    return common


if __name__ == '__main__':
    configured().main()
