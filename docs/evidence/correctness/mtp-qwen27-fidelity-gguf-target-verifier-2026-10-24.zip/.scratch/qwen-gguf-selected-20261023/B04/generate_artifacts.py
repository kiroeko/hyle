"""Generate B04's exact29-role C++ ManifestSpecs after loose acquisition.

No HTTP, no payload copy/re-hash, no guessed pins or incomplete fallback.
Runtime Data::load authenticates each mapped original role against these pins.
"""
import argparse
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import sys

sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
R = S.parents[2]


def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def identity(path):
    raw = path.read_bytes()
    return dict(path=path.relative_to(R).as_posix(), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


def checked_metadata(directory=None, *, variant='UD-Q8_K_XL', header_receipt=None):
    directory = S if directory is None else Path(directory)
    header_receipt = directory / 'header.json' if header_receipt is None else Path(header_receipt)
    spec = importlib.util.spec_from_file_location('gguf_pins_actual_schema', directory / 'prepare_loose_plan.py')
    schema = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(schema)
    plan_path, plan = schema.checked_plan()
    out = directory / 'original-roles'
    receipt_path, manifest_path = out / 'acquisition.json', out / 'manifest.json'
    receipt, manifest = read(receipt_path), read(manifest_path)
    assert receipt['complete'] is True and manifest['complete'] is True
    for value in (receipt, manifest):
        assert (value['repository'], value['revision'], value['original_roles']) == (
            plan['repository'], plan['revision'], schema.COUNT)
    assert receipt['source_plan_sha256'] == identity(plan_path)['sha256']
    assert receipt['expected_role_payload_bytes'] == receipt['role_payload_bytes'] == schema.BODY
    assert receipt['successful_request_body_bytes'] == schema.BODY
    assert manifest['source_bytes'] == schema.BODY
    assert manifest['source_receipt'] == identity(receipt_path)
    assert manifest['source_plan'] == identity(plan_path)
    assert manifest['source_header'] == identity(header_receipt)
    assert (manifest['file'], manifest['variant']) == (plan['file'], variant)
    assert len(receipt['roles']) == len(manifest['roles']) == schema.COUNT
    wanted = {row['name']: row for row in plan['roles']}
    acquired = {row['name']: row for row in receipt['roles']}
    pinned = {row['name']: row for row in manifest['roles']}
    assert len(acquired) == len(pinned) == schema.COUNT and wanted.keys() == acquired.keys() == pinned.keys()
    for name, row in wanted.items():
        actual, pin = acquired[name], pinned[name]
        assert actual['complete'] is True
        assert all(actual[key] == val for key, val in row.items())
        assert (pin['file'], pin['dtype'], pin['shape'], pin['bytes'], pin['section']) == (
            row['filename'], row['dtype'], row['shape'], row['bytes'], row['section'])
        digest = actual['payload']['sha256']
        assert re.fullmatch('[0-9a-f]{64}', digest) and pin['sha256'] == digest
        file = out / row['filename']
        assert file.name == row['filename'] and file.stat().st_size == row['bytes']
        assert actual['payload'] == dict(path=file.relative_to(R).as_posix(), bytes=row['bytes'], sha256=digest)
        offset = 0
        for chunk in actual['chunks']:
            assert chunk['offset'] == offset and 0 < chunk['bytes'] <= 128*1024*1024 and re.fullmatch('[0-9a-f]{64}', chunk['sha256'])
            first = row['absolute_inclusive'][0] + offset
            assert chunk['absolute_range_inclusive'] == [first, first + chunk['bytes'] - 1]
            offset += chunk['bytes']
        assert offset == row['bytes']
    return plan, pinned, identity(receipt_path), identity(manifest_path)


def quoted(value):
    return json.dumps(value, ensure_ascii=True)


def header(plan, rows, receipt, manifest, *, namespace='b04', variant='UD-Q8_K_XL',
           directory=None, header_path=None, profile_lines=None):
    directory = S if directory is None else Path(directory)
    header_path = directory / 'original-header.bin' if header_path is None else Path(header_path)
    profile_lines = ['inline constexpr auto &kProfile=d5_qwen38_gdn_fixture::kFidelityGgufProfile;'] if profile_lines is None else profile_lines
    lines = ['#pragma once', '', '#include <array>', '#include <cstdint>', '#include <string_view>',
        '#include "qwen27_original_nextn_roles.h"', '#include "d5_qwen38_gdn_fixture.h"', '',
        '// Pins generated only from the completed fixed-revision loose acquisition.',
        ('// Raw GGUF BF16/F32/Q8_0 bytes; no repack, fallback or duplicate vocabulary.' if namespace == 'b04' else
         '// Actual per-role GGUF codecs; no repack, fallback or duplicate vocabulary.'),
        'namespace qwen_gguf_original_artifacts::' + namespace + ' {',
        'namespace roles=qwen27_original_nextn_roles;',
        'namespace c=hyle::compute;',
        'inline constexpr qwen_original_mtp_roles::Identity kIdentity{',
        '    ' + ','.join(quoted(value) for value in (plan['repository'],plan['revision'],variant,plan['file'])) + '};',
        *profile_lines,
        f'inline constexpr std::uint64_t kOriginalBytes={plan["source_bytes"]}ULL;',
        f'inline constexpr std::string_view kReceiptSha256={quoted(receipt["sha256"])};',
        f'inline constexpr std::string_view kManifestSha256={quoted(manifest["sha256"])};',
        f'inline constexpr std::string_view kHeaderSha256={quoted(identity(header_path)["sha256"])};',
        f'inline constexpr std::string_view kPlanSha256={quoted(identity(directory / "loose-plan.json")["sha256"])};',
        'inline std::array<roles::ManifestSpec,29> manifest() {', '  return {{']
    for spec in plan['roles']:
        row = rows[spec['name']]
        shape, dtype = row['shape'], row['dtype']
        packed = {'Q8_0': ('kQ8_0', 32), 'Q5_K': ('kQ5K', 256),
                  'Q6_K': ('kQ6K', 256), 'NVFP4': ('kNvfp4', 64)}
        if dtype in packed:
            kind, block = packed[dtype]
            assert len(shape) == 2 and shape[0] % block == 0
            desc = (f'roles::original::detail::take(c::gguf_weight_description(c::GgufQuantizedType::{kind},'
                f'c::DataType::kFloat32,{shape[0]},{shape[1]}),'+quoted('B04 original Q8_0 RHS' if namespace == 'b04' else namespace.upper()+' original '+dtype+' RHS')+')')
            if row['name'] == 'token_embd.weight':
                desc = f'roles::original::detail::take(({desc}).transposed(),'+quoted('B04 original Q8_0 Gather rows' if namespace == 'b04' else namespace.upper()+' original '+dtype+' Gather rows')+')'
        else:
            assert dtype in ('BF16', 'F32')
            # Plain GGUF dimensions are innermost-first; compute descriptors
            # are outermost-first. This is metadata only, not a transpose copy.
            dimensions = ','.join(map(str, reversed(shape)))
            data_type = 'kBFloat16' if dtype == 'BF16' else 'kFloat32'
            desc = (f'roles::original::detail::take(c::TensorDesc::dense(c::DataType::{data_type},'
                f'std::array<std::int64_t,{len(shape)}>{{{dimensions}}}),"B04 original plain role")')
        native = {'Q8_0': 'GGML_TYPE_Q8_0', 'Q5_K': 'GGML_TYPE_Q5_K',
                  'Q6_K': 'GGML_TYPE_Q6_K', 'NVFP4': 'GGML_TYPE_NVFP4',
                  'BF16': 'GGML_TYPE_BF16', 'F32': 'GGML_TYPE_F32'}[dtype]
        lines.append(f'    {{{quoted(row["name"])},{quoted(row["file"])},{quoted(row["sha256"])},{native},{desc}}},')
    lines += ['  }};', '}', '} // namespace qwen_gguf_original_artifacts::' + namespace, '']
    return '\n'.join(lines)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, default=S / 'generated/qwen_gguf_b04_artifacts.h')
    args = parser.parse_args()
    plan, rows, receipt, manifest = checked_metadata()  # Missing/partial fails before output.
    text = header(plan, rows, receipt, manifest)
    output = args.output.resolve()
    assert output.is_relative_to(R) and output.suffix == '.h'
    output.parent.mkdir(parents=True, exist_ok=True)
    if output.exists():
        assert output.read_text(encoding='utf-8-sig') == text, 'Refuse to replace a different generated pin header'
    else:
        output.write_text(text, encoding='utf-8')
    proof = dict(repository=plan['repository'], revision=plan['revision'], file=plan['file'],
        original_roles=29, source_bytes=4927328256, receipt=receipt, manifest=manifest,
        source_plan=identity(S / 'loose-plan.json'), header=identity(output),
        body_rehashed=False, artifact_executed=False, pins_from_completed_acquisition=True)
    output.with_suffix('.json').write_text(json.dumps(proof, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(proof))


if __name__ == '__main__':
    main()
