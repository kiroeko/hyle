"""Root-only single-Qwen-TU integration on the actual GQ cached product ABI.

Actions plan/compile/link/list/run reuse GQ's checked lifecycle. Only plan is
offline metadata; no action is run on import. No SDK/NVCC/worker rebuild and no
expert-fetch driver. Q03/B04 cases stay unregistered without their real pins.
"""
import argparse
import hashlib
import importlib.util
import json
from pathlib import Path
import sys

sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
R = S.parents[3]
GQ = R / '.scratch/qwen-gguf-selected-20261023'
QB = R / '.scratch/qwen-bfloat-selected-20261023'
GQ_BUILD = GQ / 'build.py'
GQ_BUILD_SHA = 'b4ac1fdff678dfe91290a9b3d42ccbcdc37249131cdb46879d156968242847fe'
HEADER = GQ / 'S01/generated/qwen_gguf_original_artifacts.h'
S01_MACRO = '/DHYLE_TEST_QWEN_GGUF_ARTIFACTS_HEADER='
DISABLED_MACROS = ('/DHYLE_TEST_QWEN_Q03_ARTIFACTS_HEADER=', '/DHYLE_TEST_QWEN_B04_ARTIFACTS_HEADER=')
B02_CASE = 'QwenMtpStateConsumer.CpuQ27OriginalBFloatTargetAndNextNFullVocabularyVerifierPublishesRepairedPrefix'


def identity(path):
    path = Path(path)
    raw = path.read_bytes()
    return dict(path=str(path), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


def configured():
    assert identity(GQ_BUILD)['sha256'] == GQ_BUILD_SHA
    # Separate module globals keep GQ's authenticated artifact/proof paths
    # fixed while its unchanged lifecycle writes only new integration outputs.
    support = load('qwen_integration_fixed_gq_support', GQ_BUILD)
    job = load('qwen_integration_new_outputs', GQ_BUILD)
    job.S, job.BASE = S, GQ / 'tests-link1'
    job.RECIPE = GQ / 'compile1/qwen-state/identity.json'
    job.artifacts = support.artifacts
    job.retained_proof = support.retained_proof
    job.legacy_environment = support.legacy_environment
    job.CASES = {name: support.CASES[name] for name in ('s01cpu', 's01cuda')}
    job.CASES['b02cpu'] = B02_CASE
    native_host_command = job.b.host_command

    def host_command(recipe, source, tag, out):
        assert not any(arg.startswith(DISABLED_MACROS) for arg in recipe)
        # GQ's actual completed recipe already contains S01. Its host() adds
        # the currently authenticated exact header once, so strip that one
        # old argument before reusing the unchanged command transformation.
        existing = [arg for arg in recipe if arg.startswith(S01_MACRO)]
        assert len(existing) == 1
        assert existing[0] == S01_MACRO + '"' + HEADER.as_posix() + '"'
        return native_host_command([arg for arg in recipe if not arg.startswith(S01_MACRO)], source, tag, out)
    job.b.host_command = host_command
    return job, support


def adapter_record():
    return dict(adapter=identity(__file__), reused_support=identity(GQ_BUILD),
        output_directory=str(S), new_host_translation_units=1,
        reused_product_objects=13, SDK_builds=0, NVCC_builds=0, worker_builds=0,
        disabled_new_artifact_macros=list(DISABLED_MACROS), network_requests=0)


def annotate(job, path, extra=None):
    value = read(path)
    value['integration_adapter'] = adapter_record()
    if extra:
        value.update(extra)
    job.c.save(path, value)


def b02_artifacts():
    directory = QB / 'B02/original-roles'
    receipt_path, manifest_path = directory / 'acquisition.json', directory / 'manifest.json'
    receipt, manifest = read(receipt_path), read(manifest_path)
    assert receipt['complete'] is True and manifest['complete'] is True
    assert receipt['original_roles'] == manifest['original_roles'] == 29
    assert receipt['role_payload_bytes'] == manifest['source_bytes'] == 6679513088
    assert (manifest['repository'], manifest['revision']) == (
        'Qwen/Qwen3.8-27B', '1d4bf0f2ff6012fd82039f2fa52739d0dd7c60c0')
    acquired = {row['name']: row for row in receipt['roles']}
    assert len(acquired) == len(manifest['roles']) == 29
    for row in manifest['roles']:
        actual = acquired[row['name']]
        assert actual['complete'] is True
        assert (row['file'], row['sha256'], row['bytes']) == (
            actual['filename'], actual['payload']['sha256'], actual['payload']['bytes'])
        assert (directory / row['file']).stat().st_size == row['bytes']
    return directory, [identity(receipt_path), identity(manifest_path)]


def plan(job, support, attempt, header):
    pins = support.artifacts(header)
    proof, _ = support.retained_proof()
    base_path = GQ / 'tests-link1/link-plan.json'
    base = read(base_path)
    assert read(base_path.with_name('link.result.json'))['exit'] == 0
    records = [(entry, read(entry['path'])) for entry in base['compiled_records']]
    products = [(entry, record) for entry, record in records
        if job.c.key(record['source']['path']) != job.c.key(job.SOURCE)]
    assert len(products) == 13 and len(records) == 14
    recipe = read(job.RECIPE)
    command = job.b.host_command(recipe['command'], job.SOURCE, job.TAG, S / f'compile{attempt}' / job.TAG)
    command.insert(1, S01_MACRO + '"' + Path(header).resolve().as_posix() + '"')
    assert sum(arg.startswith(S01_MACRO) for arg in command) == 1
    assert not any(arg.startswith(DISABLED_MACROS) for arg in command)
    b02_directory, b02_inputs = b02_artifacts()
    value = dict(prepared_only=True, source=identity(job.SOURCE), source_recipe=identity(job.RECIPE),
        actual_compile_command=command, base_link=identity(base_path),
        cached_product_records=[entry for entry, _ in products],
        cached_product_objects=[record['object'] for _, record in products],
        cached_inputs_rehashed=False, retained_exact_comment_header_proof=proof,
        S01_artifact_inputs=pins, B02_artifact_inputs=b02_inputs,
        B02_directory=str(b02_directory), cases=job.CASES,
        new_cases_enabled=False, cpp_compiled=False, linked=False, native_executed=False,
        commands=[
            f'python {S.relative_to(R).as_posix()}/build.py compile --attempt {attempt}',
            f'python {S.relative_to(R).as_posix()}/build.py link --attempt {attempt} --compile-attempt {attempt}',
            *[f'python {S.relative_to(R).as_posix()}/build.py run --attempt {index} --link-attempt {attempt} --case {case}'
              for index, case in enumerate(job.CASES, 1)]],
        integration_adapter=adapter_record())
    path = S / f'plan{attempt}.json'
    assert not path.exists(), 'Keep each reviewed source plan immutable; choose a new attempt'
    job.c.save(path, value)
    print(json.dumps(dict(plan=identity(path), actual_macros=[arg for arg in command if arg.startswith('/D')],
        cached_product_objects=13, enabled_cases=job.CASES, network_requests=0)))


def compile_one(job, attempt, header):
    job.host(attempt, header)
    folder = S / f'compile{attempt}' / job.TAG
    record = read(folder / 'identity.json')
    assert sum(arg.startswith(S01_MACRO) for arg in record['command']) == 1
    assert not any(arg.startswith(DISABLED_MACROS) for arg in record['command'])
    for filename in ('plan.json', 'identity.json'):
        annotate(job, folder / filename)


def link_one(job, attempt, compile_attempt):
    job.link(attempt, compile_attempt)
    folder = S / f'tests-link{attempt}'
    # Annotate only the newly created records and then refresh their actual
    # identity in the new ready record. Historical GQ records stay untouched.
    annotate(job, folder / 'link-plan.json')
    annotate(job, folder / 'ready.json', dict(link_plan=identity(folder / 'link-plan.json')))


def run_one(job, attempt, link_attempt, case, timeout, list_only):
    inputs = []
    if case == 'b02cpu':
        directory, inputs = b02_artifacts()
        # Existing run() first clears all HYLE_QWEN env; this exact cached
        # BF16 case needs only its29-role owner, no old GGUF or expert driver.
        job.legacy_environment = lambda: dict(HYLE_QWEN_BFLOAT_27_DIR=directory)
    try:
        job.run(link_attempt, attempt, case, timeout, list_only)
    finally:
        folder = S / (f'listing{attempt}' if list_only else f'checks{attempt}')
        summary = folder / 'summary.json'
        if summary.is_file():
            extra = dict(driver=None, cached_only=True, automatic_expert_fetch=False)
            if case == 'b02cpu':
                extra.update(source='B02 official original BF1629-role affected regression',
                    artifact_inputs_b02=inputs,
                    scope='Actual B02 NextN64,target63 and shared vocabulary under the explicit existing BF16 policy; finite upstream/history fixtures; no whole model/quality/TPS claim')
            annotate(job, summary, extra)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action', choices=['plan', 'compile', 'link', 'list', 'run'])
    parser.add_argument('--attempt', type=int, required=True)
    parser.add_argument('--artifacts-header', type=Path, default=HEADER)
    parser.add_argument('--compile-attempt', type=int, default=1)
    parser.add_argument('--link-attempt', type=int, default=1)
    parser.add_argument('--case', choices=['s01cpu', 's01cuda', 'b02cpu'], default='s01cpu')
    parser.add_argument('--timeout', type=int, default=1800)
    args = parser.parse_args()
    assert min(args.attempt, args.compile_attempt, args.link_attempt, args.timeout) > 0
    assert args.artifacts_header.resolve() == HEADER
    job, support = configured()
    if args.action == 'plan':
        plan(job, support, args.attempt, args.artifacts_header)
    elif args.action == 'compile':
        compile_one(job, args.attempt, args.artifacts_header)
    elif args.action == 'link':
        link_one(job, args.attempt, args.compile_attempt)
    else:
        run_one(job, args.attempt, args.link_attempt, args.case, args.timeout, args.action == 'list')


if __name__ == '__main__':
    main()
