"""Root-only publication after the three exact cached regressions terminate.

No build/native/network, new artifact certification, body hash or SDK archive.
Q03/B04 entry source is retained; their disabled cases are not counted as run.
"""
import argparse
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
import xml.etree.ElementTree as ET
import zipfile

sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
R = S.parents[3]
GQ = R / '.scratch/qwen-gguf-selected-20261023'
QB = R / '.scratch/qwen-bfloat-selected-20261023'
COMBINED = QB / 'derived/Q03/nvfp4-target-proposal'
DESTINATION = R / 'docs/evidence/correctness/mtp-qwen-projection-source-integration-2026-10-23.json'
EXPECTED = (
    'QwenMtpStateConsumer.CpuQ27SidecarOriginalNextNAndMainTargetFullVocabularyVerifierPublishesRepairedPrefix',
    'QwenMtpStateConsumer.CudaQ27SidecarOriginalNextNAndMainTargetFullVocabularyVerifierPublishesRepairedPrefix',
    'QwenMtpStateConsumer.CpuQ27OriginalBFloatTargetAndNextNFullVocabularyVerifierPublishesRepairedPrefix')
DISABLED = ('/DHYLE_TEST_QWEN_Q03_ARTIFACTS_HEADER=', '/DHYLE_TEST_QWEN_B04_ARTIFACTS_HEADER=')
TEXT = {'.h', '.cc', '.cu', '.cuh', '.hpp', '.py', '.json', '.xml', '.log', '.txt', '.patch', '.diff'}
files = set()


def resolve(path):
    path = Path(path)
    return (path if path.is_absolute() else R / path).resolve()


def read(path):
    return json.loads(resolve(path).read_text(encoding='utf-8-sig'))


def identity(path):
    path = resolve(path)
    assert path.name != 'roles.bin', 'No weight-body hash in publication'
    with path.open('rb') as stream:
        digest = hashlib.file_digest(stream, 'sha256').hexdigest()
    return dict(path=path.relative_to(R).as_posix(), bytes=path.stat().st_size, sha256=digest)


def verify(row):
    path = resolve(row['path'])
    actual = identity(path)
    assert (actual['bytes'], actual['sha256']) == (row['bytes'], row['sha256']), str(path)
    return path


def keep(path):
    path = resolve(path)
    assert path.is_relative_to(R) and path.is_file() and path.stat().st_size < 2_000_000, str(path)
    assert path.suffix.lower() in TEXT or path.name.endswith('.before-ordinal-fix'), str(path)
    files.add(path)
    return path


def retain(folder):
    for path in resolve(folder).rglob('*'):
        if path.is_file() and (path.suffix.lower() in TEXT or path.name.endswith('.before-ordinal-fix')):
            keep(path)


def successful(path):
    result = read(keep(path))
    assert result['exit'] == 0 and result.get('terminal', True) and not result.get('timed_out', False), str(path)
    return result


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


def completed_runs(numbers, ready):
    assert len(numbers) == len(set(numbers)) == 3
    cases, total = {}, 0
    for number in numbers:
        folder = S / f'checks{number}'
        summary = read(keep(folder / 'summary.json'))
        assert summary['terminal'] is True and summary['process']['exit'] == 0
        assert not summary['process']['timed_out']
        assert summary['image'] == ready['image'] and summary['source_record'] == ready['source_record']
        assert summary['link_plan'] == ready['link_plan']
        assert summary['artifact_inputs'] == ready['artifact_inputs']
        assert summary.get('driver') is None and summary['cached_only'] is True
        assert summary['automatic_expert_fetch'] is False
        assert summary['tests'] == 1 and not any(summary[key] for key in ('failures', 'errors', 'disabled', 'skips'))
        xml = ET.parse(keep(folder / 'results.xml')).getroot()
        assert int(xml.attrib['tests']) == 1 and not any(int(xml.attrib[key]) for key in ('failures', 'errors', 'disabled'))
        testcases = list(xml.iter('testcase'))
        assert len(testcases) == 1
        case = testcases[0]
        name = case.attrib['classname'] + '.' + case.attrib['name']
        assert name in EXPECTED and name not in cases
        assert case.find('failure') is None and case.find('error') is None and case.find('skipped') is None
        assert case.attrib['status'] == 'run' and case.attrib['result'] == 'completed'
        assert summary['selected_cases'] == [name]
        assert '--gtest_filter=' + name in summary['process']['command']
        props = {row.attrib['name']: row.attrib['value'] for row in case.iter('property')}
        assert len(props) == len(list(case.iter('property')))
        submitted = int(props['actual_submissions'])
        assert submitted > 0 and submitted == sum(int(props[key]) for key in
            ('target_submissions', 'nextn_submissions', 'target_verifier_submissions'))
        assert props['complete_target_draft_resources'] == '12'
        assert props['original_native_reference_submissions'] == '0'
        assert int(props['accepted_target_conditioned_repairs']) > 0
        assert int(props['first_full_target_verifier_values']) == 2 * int(props['target_verifier_full_vocabulary'])
        assert int(props['peak_state_backing_bytes']) <= int(props['state_budget_bytes'])
        actual_case = summary['cases']
        assert len(actual_case) == 1 and actual_case[0]['properties'] == props
        retain(folder)
        keep(S / 'run-plans' / (folder.name + '.json'))
        cases[name] = dict(summary=identity(folder / 'summary.json'), xml=identity(folder / 'results.xml'),
            process=summary['process'], environment=summary['environment'], properties=props,
            actual_graph_submissions=submitted, driver=None)
        total += submitted
    assert set(cases) == set(EXPECTED), 'All three exact regressions must pass; no substitute cases'
    return cases, total


def compiled_and_linked(compile_attempt, link_attempt):
    compiled = S / f'compile{compile_attempt}/qwen-state'
    linked = S / f'tests-link{link_attempt}'
    successful(compiled / 'compile.result.json')
    successful(linked / 'link.result.json')
    ready = read(keep(linked / 'ready.json'))
    record_path = keep(verify(ready['source_record']))
    assert record_path == compiled / 'identity.json'
    record = read(record_path)
    verify(ready['image'])  # Image hash only; never archived.
    verify(record['object'])  # One test object hash; never archived.
    keep(verify(record['source']))
    plan_path = keep(verify(ready['link_plan']))
    link = read(plan_path)
    assert link['host_translation_units'] == 1
    assert all(link[key] == 0 for key in ('product_host_translation_units', 'SDK_builds', 'native_CPU_builds', 'NVCC_builds'))
    assert len(link['compiled_records']) == 14
    macros = [arg for arg in record['command'] if arg.startswith('/D')]
    s01_macros = [arg for arg in macros if arg.startswith('/DHYLE_TEST_QWEN_GGUF_ARTIFACTS_HEADER=')]
    expected_header = GQ / 'S01/generated/qwen_gguf_original_artifacts.h'
    assert s01_macros == ['/DHYLE_TEST_QWEN_GGUF_ARTIFACTS_HEADER="' + expected_header.as_posix() + '"']
    assert '/DHYLE_TEST_QWEN_STATE_CPU=1' in macros and '/DHYLE_TEST_QWEN_STATE_CUDA=1' in macros
    assert not any(arg.startswith(DISABLED) for arg in record['command'])
    assert record['artifact_inputs'] == ready['artifact_inputs'] == link['artifact_inputs']
    closure = []
    for dependency in record['dependencies']:
        path = resolve(dependency['path'])
        if path.is_relative_to(R) and path.relative_to(R).parts[0] in ('include', 'src', 'tests'):
            keep(verify(dependency))
            closure.append(dependency)
    assert resolve(record['source']['path']) in {resolve(row['path']) for row in closure}
    products = []
    for row in link['compiled_records']:
        path = keep(verify(row))
        item = read(path)
        assert sum(info == item['object'] for info in link['inputs']) == 1
        if path != record_path:
            assert '/src/' in item['source']['path'].replace('\\', '/')
            keep(verify(item['source']))
            products.append(dict(record=row, source=item['source'], object=item['object']))
    assert len(products) == 13
    retain(compiled)
    for name in ('link.command.json', 'link.result.json', 'link.stdout.log', 'link.stderr.log',
                 'runtime-environment.json', 'ready.json'):
        keep(linked / name)
    return ready, dict(compile_record=identity(record_path), source=record['source'], object=record['object'],
        source_closure=closure, actual_macros=macros, linked_image=ready['image'],
        link_plan=identity(plan_path), cached_product_objects=products,
        SDK_built=False, NVCC_invoked=False, worker_built=False,
        SDK_or_weight_bodies_archived=False)


def pins_and_proof(ready):
    build = load('qwen_projection_existing_gq_metadata', GQ / 'build.py')
    inputs = build.artifacts(GQ / 'S01/generated/qwen_gguf_original_artifacts.h')
    assert inputs == ready['artifact_inputs']
    for row in inputs:
        keep(verify(row))
    proof, pairs = build.retained_proof()
    keep(verify(proof))
    for pair in pairs:
        keep(verify(pair['cached_snapshot']))
        keep(verify(pair['current_header']))
    integration = load('qwen_projection_integration_metadata', S / 'build.py')
    _, b02 = integration.b02_artifacts()
    for row in b02:
        keep(verify(row))
    prior = []
    for path in (R / 'docs/evidence/correctness/mtp-qwen27-sidecar-target-verifier-2026-10-23.json',
                 R / 'docs/evidence/correctness/mtp-qwen-bfloat-target-verifier-2026-10-23.json'):
        prior.append(identity(keep(path)))
    return dict(S01=inputs, B02=b02, exact_comment_header_equivalence=proof,
        previous_evidence=prior, new_weight_acquisition=False, body_rehashed=False)


def history():
    failures = []
    for attempt in (1, 2, 3):
        folder = S / f'compile{attempt}/qwen-state'
        result = read(keep(folder / 'compile.result.json'))
        assert result['terminal'] is True and result['exit'] != 0
        plan = read(keep(folder / 'plan.json'))
        snapshot = folder / 'source' / resolve(plan['source']['path']).relative_to(R)
        actual = identity(keep(snapshot))
        assert (actual['bytes'], actual['sha256']) == (plan['source']['bytes'], plan['source']['sha256'])
        retain(folder)
        failures.append(dict(attempt=attempt, kind='compile_failure_not_a_native_failure',
            result=identity(folder / 'compile.result.json'), source=plan['source'], snapshot=actual))
    retain(S / 'compile-fixes')
    retain(S / 'runner-path-fix')
    fix_path = keep(S / 'runner-path-fix/fix.json')
    fix = read(fix_path)
    assert 'before native launch' in fix['problem'] and 'no test had run' in fix['problem']
    runner_sources = dict(GQ_before=identity(S / 'runner-path-fix/gq-before.py'),
        adapter_before=identity(S / 'runner-path-fix/adapter-before.py'),
        GQ_after=identity(GQ / 'build.py'), adapter_after=identity(S / 'build.py'))
    assert runner_sources['GQ_after']['sha256'] == fix['support_after_sha256']
    assert runner_sources['adapter_after']['sha256'] == fix['adapter_after_sha256']
    compiled = read(S / 'compile4/qwen-state/identity.json')
    for row, snapshot in ((compiled['script'], runner_sources['GQ_before']),
                          (compiled['integration_adapter']['adapter'], runner_sources['adapter_before'])):
        assert (row['bytes'], row['sha256']) == (snapshot['bytes'], snapshot['sha256'])
    return dict(compile_failures=failures,
        pre_native_runner_assertion=dict(record=identity(fix_path), explanation=fix,
            native_test_executed=False, counted_as_model_failure=False),
        historical_runner_sources=runner_sources,
        resolution='ValueId comparison syntax uses explicit ordinals; runner source directory is independent of output stage. No numerical gate was relaxed.')


def retain_changes():
    for folder in (COMBINED / 'combined', COMBINED / 'entries-combined',
                   GQ / 'B04/q8-embedding-reference-proposal'):
        for name in ('combined.patch', 'combined.json', 'entries.patch', 'entries.json', 'applied.json', 'source.patch', 'proposal.json'):
            if (folder / name).is_file():
                keep(folder / name)
    for path in (GQ / 'build.py', S / 'build.py', S / 'prepared.json', Path(__file__)):
        keep(path)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--compile', type=int, default=4)
    parser.add_argument('--link', type=int, default=1)
    parser.add_argument('--runs', type=int, nargs=3, default=[1, 2, 3])
    parser.add_argument('--check-only', action='store_true')
    args = parser.parse_args()
    ready, closure = compiled_and_linked(args.compile, args.link)
    cases, submissions = completed_runs(args.runs, ready)  # Missing/live/failure refuses publication.
    artifacts = pins_and_proof(ready)
    previous = history()
    retain_changes()
    value = dict(kind='correctness', date='2026-10-23', status='passed',
        scope='Shared Qwen projection/source integration regression: existing S01 original draft paired with MAIN target63/head on CPU/CUDA, plus existing B02 original BF16 CPU. Finite upstream/history fixtures; no whole-model quality or TPS claim.',
        tests=3, failures=0, errors=0, skips=0, actual_graph_submissions=submissions,
        cases=cases, compiled_and_linked=closure, artifact_pins=artifacts, history=previous,
        Q03_B04=dict(entry_source_retained=True, generated_macros_enabled=False,
            cases_registered=False, artifacts_executed=False, new_pins_inferred=False),
        identity_completion_delta=0, identity_ledger_modified=False,
        throughput_evidence=False, whole_original_model=False,
        archive=DESTINATION.with_suffix('.zip').relative_to(R).as_posix(),
        supporting_files=[identity(path) for path in sorted(files)])
    if args.check_only:
        print(json.dumps(dict(validated=True, tests=3, actual_graph_submissions=submissions,
            supporting_files=len(files), published=False)))
        return
    archive = DESTINATION.with_suffix('.zip')
    assert not DESTINATION.exists() and not archive.exists(), 'Do not overwrite published evidence'
    assert sum(path.stat().st_size for path in files) < 12_000_000, 'Keep the archive small; no SDK or payload copy'
    DESTINATION.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as package:
        for path in sorted(files | {DESTINATION}):
            package.write(path, path.relative_to(R).as_posix())
    result = dict(evidence=identity(DESTINATION), archive=identity(archive))
    (S / 'publication.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(result))


if __name__ == '__main__':
    main()
