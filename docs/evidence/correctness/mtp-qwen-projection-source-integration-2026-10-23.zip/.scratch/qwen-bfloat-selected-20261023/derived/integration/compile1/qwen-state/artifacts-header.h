#pragma once
#include "qwen27_original_nextn_roles.h"
#include "d5_qwen38_gdn_fixture.h"
namespace qwen_gguf_original_artifacts::s01 {
inline constexpr auto kReceiptSha256="e76fe68789595b2af2820fd7eb136f3ff9297e0c6d2e8ab594cfe433089826ee";
inline constexpr auto kPlanSha256="135700f6cf253e6e3384a21dfd4baa40b11b6fb9571cbb07d03dc1218c47fe61";
inline constexpr auto kOriginalFileSha256="50d9ce5a6da381bbcfb31061cf73df94a90e6faf8efeddee379a9cb8f1501c6e";
inline constexpr auto kProfile=[] {
  auto p=d5_qwen38_gdn_fixture::kPrimaryGgufProfile;
  p.variant="sidecar:MTP/mtp-Qwen3.8-27B-Q4_0.gguf";
  p.manifest_digest="e94135836ef1ea7fcb4dd77420060378d200f70d55ed2fbc73030661e9d531c8";
  return p;
 }();
inline std::array<qwen27_original_nextn_roles::PinnedFile,18> files() {
  return {{
    {"blk.64.attn_k.weight.bin","aeaf731e350b33f8ccaa2a7a0b56bcd1971ff992c52d1cf1397040becf6869a1"},
    {"blk.64.attn_k_norm.weight.bin","13e8086a61052d510f01a7984b2ac7c5012337887e80594331ddef3a6a0f05c7"},
    {"blk.64.attn_norm.weight.bin","afb539011550a9d32f6cfb14db69b9aaed81e63fbd732124e020ae9903e0f275"},
    {"blk.64.attn_output.weight.bin","c3b17401794e74c1962846f897fb673f82f212f61d7f06337815a20bfeac1d42"},
    {"blk.64.attn_q.weight.bin","ebec153220a43ff360e3fcc4670f4ab6a21ee24cbfa4a54ad9dad7e671be8f10"},
    {"blk.64.attn_q_norm.weight.bin","4a7f959094211b3dade3324736bb75e25c61a9197e025102646e7f74bd094a48"},
    {"blk.64.attn_v.weight.bin","e925316727c506dc1b66c7ec62b65352d68f50cabb35a8f9978faab1ab52122a"},
    {"blk.64.ffn_down.weight.bin","1b0d2382c7ebcc278555ef665b51ab672b2b23ca634ad23e161bf3c7b9abb481"},
    {"blk.64.ffn_gate.weight.bin","b053dc1304d5d6920e7259bdd725a4fccce7d765c2dcbffb3c37e37ef4c8d82d"},
    {"blk.64.ffn_up.weight.bin","abf8f9c8aeb7c5e4f9fb74e523b5c4b03a3fe0e96e06d7690da307e753f230d4"},
    {"blk.64.nextn.shared_head_norm.weight.bin","afdf2c4845dcce4470aeaf40e1726690b606eb642c5a4145a0e3f2598b0734d0"},
    {"blk.64.post_attention_norm.weight.bin","fcfcdbdb492b9a1c31ca44997a188982a68e0741df67f36080c0562da6b7c6dd"},
    {"token_embd.weight.bin","87ba81fbf69d89fbe83785367f4c7805c485b655b4b1b4b3ab296fa0a8d3562c"},
    {"output.weight.bin","86c1ebd638652b6e9cd4b7b4e6fb256739c74302c82ff1b1bf7277ca4804e557"},
    {"blk.64.nextn.enorm.weight.bin","d96abe72c938e866b5a8bdaa8aa9f8590577f55bef6281c2e9fce892db518d97"},
    {"blk.64.nextn.hnorm.weight.bin","e9247e9fc08ebd0ca8f14a610cfd1046a0115143f6967de9d520647149890ac2"},
    {"blk.64.nextn.eh_proj.weight.bin","bd076051e71feda901904fff74dca56a1642d1a9155d31e6e6f2b0ef505fe4ec"},
    {"output_norm.weight.bin","b3ba4f3231a21b1559f52115d3bffc7c28dcd03e4be22df269ef97a3f5d4bfbf"},
  }};
}
inline auto manifest(){return qwen27_original_nextn_roles::sidecar_manifest(files());}
} // namespace qwen_gguf_original_artifacts::s01
