from pathlib import Path
import hashlib, json, zipfile
R=Path(__file__).resolve().parents[2]
D=Path(__file__).resolve().parent
def read(p): return json.loads(p.read_text(encoding='utf8'))
def pin(p): return dict(path=p.relative_to(R).as_posix(),bytes=p.stat().st_size,
    sha256=hashlib.sha256(p.read_bytes()).hexdigest())
proof=read(D/'regression/proof-summary.json')
host=read(D/'host/summary.json')
assert proof['state']=='passed' and not proof['differences'] and host['state']=='passed'
out=R/'docs/evidence/correctness/inference-request-window-2026-10-24.json'
archive=out.with_suffix('.zip')
assert not out.exists() and not archive.exists()
sources=read(D/'after-pins.json')['files']
for p in sources:
    now=pin(R/p['path']);assert all(now[k]==p[k] for k in ['path','bytes','sha256'])
files=[D/name for name in ['before-pins.json','after-pins.json','source-only.json',
    'changes.patch','independent-review.md','publish.py','regression/check.py',
    'regression/proof.zip','regression/proof-summary.json','regression/proof-pins.json',
    'regression/cleanup-candidates.json','host/check.py','host/summary.json',
    'host/cleanup-candidates.json','host/compile/command.json','host/compile/stdout.log',
    'host/compile/stderr.log','host/compile/process.json','host/run/command.json',
    'host/run/process.json','host/run/stdout.log','host/run/stderr.log']]
files += [R/p['path'] for p in sources if p['path']!='engine/models/qwen35/main.cc']
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for p in files:
        z.write(p,p.relative_to(D).as_posix() if p.is_relative_to(D) else 'source/'+p.relative_to(R).as_posix())
cleanup=[read(D/name) for name in ['host/cleanup-candidates.json','regression/cleanup-candidates.json']]
result=dict(state='passed',date='2026-10-24',
    scope='Shared index-only FIFO/active/whole-turn request window, used by Qwen natural ordinary and MTP paths. Model admission, complete state, version budgets, bucket execution and publication remain original.',
    sources=sources,source_assertions=read(D/'source-only.json'),
    independent_review=pin(D/'independent-review.md'),
    host=dict(summary=pin(D/'host/summary.json'),checks=4,
        compile=host['compile'],run=host['run'],
        contracts=['N1 whole-turn FIFO and requeue order',
            'N2 headless reservations and actual oldest-idle victim facts',
            'Invalid transitions preserve waiting/active order',
            '7 requests/21 turns/N5 valid operations have zero tracked operator-new allocations after prepare'],
        CTest_registration='Source registered once; direct strict host run, no whole-project reconfigure.'),
    actual=dict(consumer_TUs=1,reporting_TUs=1,actual_processes=1,old_runs=0,
        report_count=proof['report_count'],differences=proof['differences'],
        added_fields=proof['added_report_fields'],groups=proof['request_groups']['counts'],
        late_IO_failures=proof['late_IO_failures_observed'],
        process={k:proof[k] for k in ['compile','reporting_compile','link','run']},
        summary=pin(D/'regression/proof-summary.json')),
    limits=['Retained tiny A-only Vulkan fixture, existing multi-turn Text N2/R2 cache hit/evict/recovery and stochastic MTP K2/R2; fixed replay remains separate.',
        'Window shares indices only; this does not prove an entire allocation-free generation loop or cross-model request/cache adaptation.',
        'No new full-model, GDN, platform matrix, quality, throughput or memory-peak measurement.'],
    SDK_builds=0,HTTP=0,throughput_claim=False,
    cleanup=dict(exact_files=sum(p['count'] for p in cleanup),
        logical_bytes=sum(p['logical_bytes'] for p in cleanup),
        contains_one_private_DLL_hardlink=True,original_caches_retained=True,performed=False),
    archive=pin(archive))
out.write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n',encoding='utf8')
print(json.dumps(dict(evidence=pin(out),archive=pin(archive),cleanup=result['cleanup'])))
