"""Strict, std-only current RequestWindow policy check. No SDK/model build."""
from pathlib import Path
import importlib.util, sys
sys.dont_write_bytecode = True
D = Path(__file__).resolve().parent
R = D.parents[2]
spec = importlib.util.spec_from_file_location('retained',
    R / '.scratch/mtp-extraction-regression-20261024/check.py')
b = importlib.util.module_from_spec(spec)
spec.loader.exec_module(b)
source = R / 'tests/tools/inference_request_window_test.cc'
header = R / 'engine/inference/request_window.h'
pins = [b.pin(p) for p in [source, header]]
reference = R / '.scratch/inference-request-boundaries-20261024/check2/compile/command.json'
original = b.args(reference)
command, skip = [], False
for word in original:
    if skip:
        skip = False
        continue
    if word == '/sourceDependencies':
        skip = True
        continue
    if word.lower().startswith(('/fo', '/fe')) or word.lower().endswith('.cc'):
        continue
    command.append(word)
folder = D / 'compile'
command += ['/sourceDependencies', str(folder / 'dependencies.json'), str(source),
    '/Fo'+str(folder / 'window.obj'), '/Fe'+str(folder / 'window.exe')]
env = b.environment(original[0])
b.execute(command, folder, env, 60)
b.execute([str(folder / 'window.exe')], D / 'run', env, 30)
assert pins == [b.pin(p) for p in [source, header]], 'Canonical host source changed during check'
b.save(D / 'summary.json', dict(state='passed', scope='Current std-only RequestWindow policy test',
    source_pins=pins, compile=b.read(folder / 'process.json'),
    run=b.read(D / 'run/process.json'), output=(D / 'run/stdout.log').read_text(),
    sdk_builds=0, model_runs=0, http_requests=0,
    cmake='Target registered in product tests; this check invokes its actual source directly without reconfiguring the full project.'))
files=[dict(path=str(p),bytes=p.stat().st_size) for p in folder.iterdir()
    if p.is_file() and p.suffix.lower() in {'.exe','.obj','.pdb','.lib','.exp'}]
b.save(D / 'cleanup-candidates.json',dict(files=files,count=len(files),
    logical_bytes=sum(p['bytes'] for p in files),performed=False))
print('Host RequestWindow source and runtime checks passed.', flush=True)
