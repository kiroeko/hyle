# RequestWindow 独立源码复审

结论：本次有限复审未发现确定的产品缺陷；不建议再加状态、所有者或执行抽象。
已核稳定 main `da27965d52d1e67897eb4e3af9c634be0dc454559e5317004353be968db641c1`，
header `37f3998cc2e13da1beb9729e1025ac1ece5928b28a494e99583b436c9a8eaf77`，
与本批 `before` 的 LoadedWeight main `3e476956...` 实际差异。
本代理只读源码及现有测试内容；没有编译、运行或下载，不把源码结论写成实际回归通过。

- 无 head 的预约：`run_generation_sessions` 的 admission 先用 `window.active()`
  统计 `!requests[index].session`，与真实 resident_count 相加后才逐次退休 idle victim。
  `admitted` 只在恢复/本轮输入准备成功后提交 FIFO head；它计入 active 即使尚未 create_session。
  后续 peer 不能重用这个预约。真实版本、字节、原生退休仍由原 admission/model gates 证明，
  Window 没把“释放一个索引”解释成释放一个物理版本。
- 同波次顺序：admission/restore 完成后借用一次 active；遍历全部 active 调用
  `prepare_generation_call`，然后执行各兼容 bucket，最后才逐 call 发布 prompt checkpoint，
  再发布 completed checkpoint、release_turn。新 window 未插入 lookup、submit 或目录 publish。
  另一成员的本波新 head 不会成为这一波准备时的 prefix hit。
- span 寿命：admission 内的 active span 仅用于当次 reserved_heads 计数；之后才 admitted。
  执行阶段的 active span 在所有 bucket/member映射结束前没有被修改。
  release loop 每次通过 `window.active().size()` 和 `[at]` 新取视图；erase 后不递增 at，
  只在保留未完成项时递增；request 引用来自不再扩容的 requests，不指向被 erase 的索引数组。
  release 后旧 active span 虽仍在作用域内，已没有读用；无失效迭代器或跳过相邻完成项。
- FIFO/idle：新请求按原 index 顺序入队；more turn 放尾；idle_clock 顺序和相等时 first-index
  victim 规则与原扫描相同。`waiting_front` 不在可能失败的恢复前推进 cursor，成功 admitted 才推进。
  该函数失败即向外退出，未引入“恢复失败后跳过请求”的新行为。
- 容量/分配：prepare 冷 reserve(total_turns) 与 reserve(N)，总 turn 数由原 checked add 得到；
  初始 waiting=request_count，每个 more turn 只追加一次，合法 push 总数不超 total_turns。
  active 最多 N；有效 admitted/release 不会重新分配，erase 只搬动 size_t，未调用 shrink。
  copy 被显式删除，隐式 move 也不可用；不会通过复制 helper 丢失预留容量。
  main 原有 calls/buckets/report 的可能 spill 分配没有因 Window 消失，不能宣传整条生成零分配。
- N1：仍是一个预约槽，不作为唯一 State/Snapshot owner 证明。
  原 `make_generation_room`、`make_generation_batch_room`、`version_admission` 和
  Model/Session retirement gates 未变；prefix/escaped readers 能继续阻止复用。
- 失败/提交：header 所有可检测的越界/非法转换在 vector mutation 前检查。
  release 在 completed checkpoint 发布之后；真实退休仍由原函数完成，未跳过 Completion。
  计算的 precommit 失败仍由原事务保留旧头和 RNG；postcommit 诊断失败仍以原 ledger 为准。
  后一个 bucket 失败不撤销先前已提交 bucket；这本来就不是整波原子回滚合同。
  Window 不持有 Snapshot/StateVersion/lease/backend，也不使失败重新执行或释放未知退休工作。

范围边界：标准库 host test 源码含 N1 FIFO、headless reservation、非法转换不改队列、
copy/move 禁止、cold spill 后的地址/分配观测；这里只确认它们与实现合同对应，没有代跑。
普通/MTP 使用同一 natural 模板接线；fixed tape 的既有调度未迁 Window，不能把 fixed 回归当成
Window 本身的证明。实际数值、调度序列和 late-IO 幂等仍由本批既定 tiny consumer 回归确认。
