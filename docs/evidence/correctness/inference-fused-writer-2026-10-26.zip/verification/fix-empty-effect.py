"""Preserve the first tested source, then fix the confirmed empty-binding regression."""
from pathlib import Path
import hashlib
import json
W = Path(__file__).resolve().parent
R = W.parents[1]
FILES = ['src/graph/resources.cc', 'include/hyle/graph/detail/region_access.h',
         'tests/graph/region_provider_test.cc']
snapshot = W/'source-attempt1'
assert not snapshot.exists()
pins = []
for name in FILES:
    data = (R/name).read_bytes()
    dest = snapshot/name
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_bytes(data)
    pins.append(dict(path=name, bytes=len(data), sha256=hashlib.sha256(data).hexdigest()))
(W/'source-attempt1.json').write_text(json.dumps(dict(
    sources=pins, successful_result='summary.json',
    known_gap='Unconditionally storing a nominated node for empty write-effect inputs changes legacy no-binding behavior. This version passed four selected tests before that untested case was added.'), indent=2)+'\n', encoding='utf-8')

path = R/'src/graph/resources.cc'
data = path.read_bytes()
begin = data.index(b'Status RegionAccess::bind_write_effect(')
end = data.index(b'bool RegionAccess::successful_outcome', begin)
part = data[begin:end]
old = b'  episode->nominated_writers[writer.step]=writer.node.ordinal();\n'
new = (b'  if(!pages.empty() || !writers.empty() || !appenders.empty() || !controls.empty())\n'
       b'    episode->nominated_writers[writer.step]=writer.node.ordinal();\n')
assert part.count(old) == 1
path.write_bytes(data[:begin]+part.replace(old,new)+data[end:])

path = R/'tests/graph/region_provider_test.cc'
data = path.read_bytes()
old = (b'  const std::array<const hyle::compute::WriteLease *, 1> writers{&writer};\r\n'
       b'  auto foreign_graph = make_projected_write_graph();\r\n')
new = (b'  const std::array<const hyle::compute::WriteLease *, 1> writers{&writer};\r\n'
       b'  // Empty effects install no authority and keep the original repeatable bind contract.\r\n'
       b'  ASSERT_TRUE(Access::bind_write_effect(run, logical.graph, capacity, {}, {}, {}, selected, {}, {}).ok());\r\n'
       b'  ASSERT_TRUE(Access::bind_write_effect(run, logical.graph, capacity, {}, {}, {}, selected, {}, {}).ok());\r\n'
       b'  EXPECT_TRUE(Access::release_write_effect(run, logical.writer).IsInvalidArgument());\r\n'
       b'  auto foreign_graph = make_projected_write_graph();\r\n')
assert data.count(old) == 1
path.write_bytes(data.replace(old,new))
print('Preserved first tested sources; corrected empty write-effect nomination only.')
