"""One bounded source-correction retry, preserving all original build/run artifacts."""
from pathlib import Path
import importlib.util
import os
import sys
sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('fused_writer', W/'build.py')
driver = importlib.util.module_from_spec(spec)
spec.loader.exec_module(driver)
driver.W = W/'empty-effect-fix'
if sys.argv[1] == 'run':
    ready = driver.b.read(driver.W/'ready.json')
    runtime = driver.b.read(ready['runtime']['path'])
    driver.b.exact(runtime['native'])
    alias = Path(ready['image']['path']).parent/Path(runtime['native']['path']).name
    assert not alias.exists()
    os.link(runtime['native']['path'], alias)
    runtime['native_hardlink'] = driver.b.pin(alias)
    assert runtime['native_hardlink']['sha256'] == runtime['native']['sha256']
    driver.b.save(driver.W/'runtime.json', runtime)
    driver.run()
else:
    {'plan': driver.plan, 'build': driver.build}[sys.argv[1]]()
