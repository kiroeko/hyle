"""Recompile only the corrected test; reuse the original passing resources object."""
from pathlib import Path
import importlib.util
import os
import sys
import xml.etree.ElementTree as ET
sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('fused_writer', W/'build.py')
d = importlib.util.module_from_spec(spec)
spec.loader.exec_module(d)
b, m = d.b, d.m
R = d.R
F = W/'empty-rejection-final'

def plan():
    assert not (F/'plan.json').exists()
    initial = b.read(W/'ready.json')
    current_resources = b.pin(R/'src/graph/resources.cc')
    assert current_resources['sha256'] == '60df445357d9b7f146dd880721da469043e259f193d355cf80112310b239ef6a'
    for row in b.read(initial['inputs']['path']):
        b.exact(row)
    recipe = R/'.scratch/inference-lease-slots-20261026/compile4/test/command.json'
    source = R/'tests/graph/region_provider_test.cc'
    command = m.command(recipe, source, F/'compile/test')
    command.insert(1, '/I'+str(R/'src/graph'))
    b.save(F/'canonical-recipe.json', dict(command=command))
    b.save(F/'source-freeze.json', m.c.closure([str(source)], [F/'canonical-recipe.json']))
    b.save(F/'plan.json', dict(status='FROZEN_NOT_BUILT',
        units=[dict(name='test', source=b.pin(source), recipe=b.pin(recipe), command=command)],
        source_freeze=b.pin(F/'source-freeze.json'),
        reused_resources=dict(source=current_resources, object=initial['compiled'][0]['object']),
        baseline=dict(ready=b.pin(W/'ready.json'), command=b.pin(W/'link/command.json'),
                      inputs=initial['inputs'], runtime=b.pin(W/'runtime2.json')),
        replaced_test=initial['compiled'][1]['object'],
        actual_compiled_TUs=1, reused_inputs=136, filter=d.FILTER,
        correction='Withdraw unreachable ghost-binding claim and redundant product change. Preserve original empty-write rejection and prove that repeated rejections leave no state residue before a valid writer binding.'))
    print('PLAN FINAL', flush=True)

def build():
    p = b.read(F/'plan.json')
    assert not (F/'compile').exists()
    for row in b.read(p['source_freeze']['path']):
        b.exact(row)
    b.exact(p['reused_resources']['source'])
    b.exact(p['reused_resources']['object'])
    h, env = d.environment(p)
    u = p['units'][0]
    process = h.execute(u['command'], env, F/'compile/test', timeout=180)
    deps = b.read(F/'compile/test/dependencies.json')['Data']
    b.save(F/'compile/test/actual-dependencies.json', [b.pin(q) for q in dict.fromkeys([deps['Source'], *deps['Includes']])])
    for row in b.read(p['source_freeze']['path']):
        b.exact(row)
    obj = b.pin(F/'compile/test/unit.obj')
    image = F/'link/fused-writer-test.exe'
    args, changes = [], 0
    for arg in b.read(p['baseline']['command']['path'])['command']:
        if b.key(arg) == b.key(p['replaced_test']['path']):
            arg = obj['path']; changes += 1
        elif arg.upper().startswith('/OUT:'):
            arg = '/OUT:'+str(image)
        elif arg.upper().startswith('/PDB:'):
            arg = '/PDB:'+str(image.with_suffix('.pdb'))
        elif arg.upper().startswith('/IMPLIB:'):
            arg = '/IMPLIB:'+str(image.with_suffix('.lib'))
        args.append(arg)
    assert changes == 1
    linked = h.execute(args, env, image.parent, timeout=120)
    inputs = [obj if b.key(x['path']) == b.key(p['replaced_test']['path']) else x
              for x in b.read(p['baseline']['inputs']['path'])]
    for row in inputs:
        b.exact(row)
    b.save(F/'link-inputs.json', inputs)
    runtime = b.read(p['baseline']['runtime']['path'])
    b.exact(runtime['native'])
    alias = image.parent/Path(runtime['native']['path']).name
    os.link(runtime['native']['path'], alias)
    runtime['native_hardlink'] = b.pin(alias)
    assert runtime['native_hardlink']['sha256'] == runtime['native']['sha256']
    b.save(F/'runtime.json', runtime)
    b.save(F/'ready.json', dict(status='BUILT_NOT_RUN', image=b.pin(image),
        compiled=dict(source=u['source'], process=process, object=obj),
        reused_resources=p['reused_resources'], link=linked,
        inputs=b.pin(F/'link-inputs.json'), runtime=b.pin(F/'runtime.json'),
        plan=b.pin(F/'plan.json'), actual_compiled_TUs=1))
    print('READY FINAL', flush=True)

def run():
    p, ready = b.read(F/'plan.json'), b.read(F/'ready.json')
    b.exact(ready['image'])
    h, env = d.environment(p)
    env['PATH'] = b.read(ready['runtime']['path'])['PATH']
    xml = F/'results.xml'
    process = h.execute([ready['image']['path'], '--gtest_color=no',
        '--gtest_filter='+d.FILTER, '--gtest_output=xml:'+str(xml)], env, F/'run1', timeout=90)
    cases = ET.parse(xml).getroot().findall('./testsuite/testcase')
    assert {x.attrib['name'] for x in cases} == d.EXPECTED
    assert all(x.attrib['status'] == 'run' and not list(x) for x in cases)
    b.save(F/'summary.json', dict(status='FOUR_TARGETED_GRAPH_TESTS_PASS',
        process=process, ready=b.pin(F/'ready.json'), results=b.pin(xml),
        tests=[x.attrib for x in cases], actual_compiled_TUs=1,
        reused_resources=p['reused_resources'],
        original_setup_failure=b.pin(W/'attempt1.json'),
        rejected_test_expectation=b.pin(W/'attempt2.json'),
        scope='Same four CPU host Graph tests. No model, native/SDK compilation, HTTP, full Graph suite or performance run.'))
    print('SUMMARY FINAL', flush=True)

if __name__ == '__main__':
    {'plan': plan, 'build': build, 'run': run}[sys.argv[1]]()
