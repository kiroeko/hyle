"""Two frozen Graph TUs; four targeted host GTests. No model/native/SDK build."""
from pathlib import Path
import importlib.util
import json
import os
import sys
import xml.etree.ElementTree as ET
sys.dont_write_bytecode = True
sys.stdout.reconfigure(encoding='utf-8')
W = Path(__file__).resolve().parent
R = W.parents[1]
F = R/'.scratch/inference-lease-slots-20261026'
spec = importlib.util.spec_from_file_location('cached_slots', F/'build.py')
cache = importlib.util.module_from_spec(spec)
spec.loader.exec_module(cache)
m, b = cache.m, cache.b
FILTER = ('GraphRouteBoundary.ProjectedWriteRegionKeepsOneOriginalNominatedEffect:'
          'GraphRouteBoundary.ProjectedWriteRejectsASecondRegionEffectBeforeBinding:'
          'GraphRouteBoundary.ProjectedRegion*:'
          'GraphRouteBoundary.ProjectedInput*')
EXPECTED = {
    'ProjectedWriteRegionKeepsOneOriginalNominatedEffect',
    'ProjectedWriteRejectsASecondRegionEffectBeforeBinding',
    'ProjectedRegionRequiresItsSelectedArtifactAndPhysicalPort',
    'ProjectedInputRetainsAllReadersAndLivePageGuards',
}
SPECS = [
    ('resources', 'src/graph/resources.cc',
     R/'.scratch/inference-bulk-append-20261026/compile/resources/unit.obj'),
    ('test', 'tests/graph/region_provider_test.cc', F/'compile4/test/unit.obj'),
]

def environment(p):
    h = b.helper()
    cl = p['units'][0]['command'][0]
    return h, h.discover_environment(compiler='msvc', cache={
        'CMAKE_C_COMPILER': cl, 'CMAKE_CXX_COMPILER': cl,
        'CMAKE_GENERATOR': 'Ninja'}, backends=()).env

def plan():
    assert not (W/'plan.json').exists()
    ready = b.read(F/'ready4.json')
    inputs = b.read(ready['inputs']['path'])
    assert len(inputs) == 137
    for row in inputs:
        b.exact(row)
    recipe = F/'compile4/test/command.json'
    units = []
    for name, source, old in SPECS:
        assert sum(b.key(x['path']) == b.key(old) for x in inputs) == 1, str(old)
        command = m.command(recipe, R/source, W/'compile'/name)
        command.insert(1, '/I'+str(R/'src/graph'))
        assert not any(x.startswith('/I') and b.key(R/'.scratch') in b.key(x) for x in command)
        units.append(dict(name=name, source=b.pin(R/source), recipe=b.pin(recipe),
                          before=b.pin(old), command=command))
    canonical = W/'canonical-recipes.json'
    b.save(canonical, dict(command=[x for unit in units for x in unit['command']]))
    frozen = m.c.closure([u['source']['path'] for u in units], [canonical])
    b.save(W/'source-freeze.json', frozen)
    b.save(W/'plan.json', dict(status='FROZEN_NOT_BUILT', units=units,
        source_freeze=b.pin(W/'source-freeze.json'), baseline={
            'ready': b.pin(F/'ready4.json'), 'command': b.pin(F/'link4/command.json'),
            'inputs': ready['inputs'], 'runtime': ready['runtime']},
        compiled_TUs=2, images=1, reused_inputs=135, filter=FILTER,
        expected_tests=sorted(EXPECTED), model_runs=0, SDK_native_builds=0,
        scope='CPU host Graph selected-region projected writer and adjacent projected read/write contracts only; no native device kernel or performance claim.'))
    print('PLAN', json.dumps(b.pin(W/'plan.json')), flush=True)

def build():
    p = b.read(W/'plan.json')
    assert not (W/'compile').exists() and not (W/'ready.json').exists()
    frozen = b.read(p['source_freeze']['path'])
    own = {b.key(x['path']): x for x in frozen}
    for row in frozen:
        b.exact(row)
    for row in b.read(p['baseline']['inputs']['path']):
        b.exact(row)
    h, env = environment(p)
    results, replace = [], {}
    for u in p['units']:
        out = W/'compile'/u['name']
        result = h.execute(u['command'], env, out, timeout=180)
        dep = b.read(out/'dependencies.json')['Data']
        actual = [b.pin(q) for q in dict.fromkeys([dep['Source'], *dep['Includes']])]
        b.save(out/'actual-dependencies.json', actual)
        for row in actual:
            q = Path(row['path'])
            if q.is_relative_to(R) and not q.is_relative_to(R/'.scratch'):
                assert own[b.key(q)]['sha256'] == row['sha256'], str(q)
        obj = b.pin(out/'unit.obj')
        replace[b.key(u['before']['path'])] = obj['path']
        results.append(dict(name=u['name'], source=u['source'], process=result,
                            object=obj, actual_dependencies=b.pin(out/'actual-dependencies.json')))
        for row in frozen:
            b.exact(row)
    image = W/'link/fused-writer-test.exe'
    args, changed = [], 0
    for arg in b.read(p['baseline']['command']['path'])['command']:
        if b.key(arg) in replace:
            arg = replace[b.key(arg)]
            changed += 1
        elif arg.upper().startswith('/OUT:'):
            arg = '/OUT:'+str(image)
        elif arg.upper().startswith('/PDB:'):
            arg = '/PDB:'+str(image.with_suffix('.pdb'))
        elif arg.upper().startswith('/IMPLIB:'):
            arg = '/IMPLIB:'+str(image.with_suffix('.lib'))
        elif arg.upper().startswith('/MAP:'):
            continue
        args.append(arg)
    assert changed == 2
    linked = h.execute(args, env, image.parent, timeout=120)
    inputs = [b.pin(replace.get(b.key(x['path']), x['path']))
              for x in b.read(p['baseline']['inputs']['path'])]
    b.save(W/'link-inputs.json', inputs)
    b.save(W/'runtime.json', b.read(p['baseline']['runtime']['path']))
    b.save(W/'ready.json', dict(status='BUILT_NOT_RUN', image=b.pin(image),
        compiled=results, link=linked, inputs=b.pin(W/'link-inputs.json'),
        runtime=b.pin(W/'runtime.json'), plan=b.pin(W/'plan.json')))
    print('READY', json.dumps(b.pin(W/'ready.json')), flush=True)

def run(second=False):
    p, ready = b.read(W/'plan.json'), b.read(W/'ready.json')
    b.exact(ready['image'])
    h, env = environment(p)
    runtime = b.read(ready['runtime']['path'])
    if second:
        b.exact(runtime['native'])
        alias = Path(ready['image']['path']).parent/Path(runtime['native']['path']).name
        assert not alias.exists()
        os.link(runtime['native']['path'], alias)
        runtime['native_hardlink'] = b.pin(alias)
        assert runtime['native_hardlink']['sha256'] == runtime['native']['sha256']
        b.save(W/'runtime2.json', runtime)
        b.save(W/'attempt1.json', dict(status='THREE_PASS_ONE_RUNTIME_SETUP_FAILURE',
            process=b.read(W/'run1/process.json'), results=b.pin(W/'results.xml'),
            unchanged_image=ready['image'], product_source_changes=0,
            cause='Original ggml CPU loader uses LOAD_LIBRARY_SEARCH_DEFAULT_DIRS, which does not search PATH. The new image directory lacked the existing pinned plugin hardlink.',
            correction='Only add the original pinned hyle_ggml_cpu_gdn_scale_v3.dll as a hardlink beside the unchanged test image. Re-run exactly the same four tests; no recompile or product change.'))
    env['PATH'] = runtime['PATH']
    xml = W/('results2.xml' if second else 'results.xml')
    result = h.execute([ready['image']['path'], '--gtest_color=no',
        '--gtest_filter='+FILTER, '--gtest_output=xml:'+str(xml)], env, W/('run2' if second else 'run1'), timeout=90)
    root = ET.parse(xml).getroot()
    cases = root.findall('./testsuite/testcase')
    assert {x.attrib['name'] for x in cases} == EXPECTED
    assert all(x.attrib['status'] == 'run' and not list(x) for x in cases)
    b.save(W/'summary.json', dict(status='FOUR_TARGETED_GRAPH_TESTS_PASS',
        process=result, ready=b.pin(W/'ready.json'), results=b.pin(xml),
        tests=[x.attrib for x in cases], compiled_TUs=2,
        model_runs=0, SDK_native_builds=0, HTTP=0, scope=p['scope'],
        runtime=b.pin(W/('runtime2.json' if second else 'runtime.json')),
        original_failure=b.pin(W/'attempt1.json') if second else None))
    print('SUMMARY', json.dumps(b.pin(W/'summary.json')), flush=True)

if __name__ == '__main__':
    if sys.argv[1] == 'run2':
        run(second=True)
    else:
        {'plan': plan, 'build': build, 'run': run}[sys.argv[1]]()
