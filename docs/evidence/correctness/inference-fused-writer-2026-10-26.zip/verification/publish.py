"""Archive only explicit sources, recipes, dependency identities and raw targeted results."""
from pathlib import Path
from datetime import datetime
import hashlib
import json
import zipfile
W = Path(__file__).resolve().parent
R = W.parents[1]
D = R/'docs/evidence/correctness'
NAME = 'inference-fused-writer-2026-10-26'
FILES = ['src/graph/resources.cc', 'include/hyle/graph/detail/region_access.h',
         'tests/graph/region_provider_test.cc']

def pin(path):
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())

def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))

def stage_entries(base, prefix, compiles, runs, extras):
    result = []
    for name in extras:
        result.append((base/name, prefix+'/'+name))
    for name in compiles:
        for item in ['command.json', 'process.json', 'stdout.log', 'stderr.log',
                     'dependencies.json', 'actual-dependencies.json']:
            result.append((base/'compile'/name/item, prefix+'/compile/'+name+'/'+item))
    for item in ['command.json', 'process.json', 'stdout.log', 'stderr.log']:
        result.append((base/'link'/item, prefix+'/link/'+item))
    for name in runs:
        for item in ['command.json', 'process.json', 'stdout.log', 'stderr.log']:
            result.append((base/name/item, prefix+'/'+name+'/'+item))
    return result

final = W/'empty-rejection-final'
summary = read(final/'summary.json')
assert summary['status'] == 'FOUR_TARGETED_GRAPH_TESTS_PASS'
assert summary['process']['exit'] == 0
assert read(W/'run1/process.json')['exit'] == 1
assert read(W/'run2/process.json')['exit'] == 0
assert read(W/'empty-effect-fix/run1/process.json')['exit'] == 1
assert len(summary['tests']) == 4
sources = [pin(R/name) for name in FILES]
assert sources[0]['sha256'] == '60df445357d9b7f146dd880721da469043e259f193d355cf80112310b239ef6a'
assert sources[1]['sha256'] == 'e381ce58457a6dd503c78058eb2622bc55f2e7f32fe63283d3b8280b25e7c68b'
assert sources[2]['sha256'] == read(final/'ready.json')['compiled']['source']['sha256']
entries = [(R/name, 'source-final/'+name) for name in FILES]
for version in ['source-attempt1', 'source-attempt2']:
    entries += [(W/version/name, version+'/'+name) for name in FILES]
entries += [(W/name, 'verification/'+name) for name in [
    'build.py', 'retry.py', 'final.py', 'publish.py', 'fix-empty-effect.py',
    'preserve-empty-failure.py', 'correct-empty-expectation.py',
    'source-attempt1.json', 'attempt1.json', 'attempt2.json']]
entries += stage_entries(W, 'verification/initial', ['resources','test'], ['run1','run2'],
    ['plan.json','source-freeze.json','canonical-recipes.json','ready.json',
     'link-inputs.json','runtime.json','runtime2.json','results.xml','results2.xml','summary.json'])
entries += stage_entries(W/'empty-effect-fix', 'verification/empty-expectation-failed',
    ['resources','test'], ['run1'], ['plan.json','source-freeze.json','canonical-recipes.json',
    'ready.json','link-inputs.json','runtime.json','results.xml'])
entries += stage_entries(final, 'verification/final', ['test'], ['run1'],
    ['plan.json','source-freeze.json','canonical-recipe.json','ready.json',
     'link-inputs.json','runtime.json','results.xml','summary.json'])
assert len({dest for _, dest in entries}) == len(entries)
for path, _ in entries:
    assert path.is_file(), str(path)
D.mkdir(parents=True, exist_ok=True)
archive = D/(NAME+'.zip')
receipt = D/(NAME+'.json')
assert not archive.exists() and not receipt.exists()
manifest = [dict(archive_path=dest, **pin(path)) for path,dest in entries]
with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as out:
    for path, dest in entries:
        out.write(path, dest)
    out.writestr('manifest.json', json.dumps(manifest, indent=2)+'\n')
with zipfile.ZipFile(archive) as verify:
    assert verify.testzip() is None
    for row in manifest:
        assert hashlib.sha256(verify.read(row['archive_path'])).hexdigest() == row['sha256']
result = dict(
    status='FOUR_TARGETED_GRAPH_TESTS_PASS', recorded_at=datetime.now().astimezone().isoformat(),
    task='Allow a selected multi-node Graph region to retain exactly one original nominated external-write effect, with only pure companions.',
    changes=[
        'Validate exact graph generation, nominated member, selected plan/artifact and original region node traits. Pure companion nodes do not become writable authorities.',
        'Keep one cold nominated-node ordinal per selected step; the original binding records retain actual permissions. Reset, replacement, single release and bulk release clear the corresponding nomination.',
        'Reject a second effect, a pure sibling nomination, foreign node/artifact/prepared state, duplicate release and repeated live binding before consuming authority.',
        'Preserve the existing empty-input rejection. Repeated empty rejection leaves no nomination or binding residue before a valid writer binding.'
    ],
    final_sources=sources,
    actual_results=dict(final_process=summary['process'], final_tests=summary['tests'],
        unique_TUs=2, actual_compile_invocations=5, actual_link_invocations=3,
        test_processes=4, final_incremental_compile_invocations=1,
        final_resources_object_reused_from_first_passing_build=True),
    retained_failures=[
        dict(stage='Initial run', process=read(W/'run1/process.json'),
             outcome='Three tests passed; the adjacent projected-input test failed while loading the existing ggml CPU plugin.',
             cause='The new executable directory lacked the pinned plugin hardlink. LOAD_LIBRARY_SEARCH_DEFAULT_DIRS does not search PATH.',
             correction='Add the same pinned DLL as a hardlink beside the unchanged executable; same four tests then passed without rebuilding.'),
        dict(stage='Incorrect empty-effect test expectation', process=read(W/'empty-effect-fix/run1/process.json'),
             outcome='Three tests passed; the new empty-input success assertion failed.',
             cause='The original validate_write_ranges already rejects missing writers and appenders. The suspected ghost nomination was unreachable.',
             correction='Withdraw the claim and redundant product condition, restore the first passing resources.cc/object, and assert the original InvalidArgument contract. Recompile only the test; same four tests pass.')
    ],
    scope=[
        'Windows x64, cached MSVC 14.50, /O2 /W4 /WX. Actual original selected Graph RegionProbe artifacts and real LeasePool/Invocation/Queue/Completion paths.',
        'Exactly two new ProjectedWrite tests plus the existing ProjectedRegion and ProjectedInput neighbors; no full Graph suite.',
        'Existing singleton-reader restrictions, actual lease admission, COW/tail permissions and retirement protocols are preserved; this batch does not introduce indexed-state kernels.'
    ],
    not_claimed=['No CUDA/Apple/Vulkan kernel validation, model inference, SDK/native rebuild, network transfer or performance measurement.',
                 'No empty-binding product defect was demonstrated or fixed.',
                 'No release_read_projection implementation or validation is included.'],
    archive=pin(archive), archive_entries=len(manifest)+1,
    final_summary=pin(final/'summary.json'))
receipt.write_text(json.dumps(result, indent=2, ensure_ascii=False)+'\n', encoding='utf-8')
print(json.dumps(dict(receipt=pin(receipt), archive=pin(archive), sources=sources), indent=2))
