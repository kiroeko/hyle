from pathlib import Path
import hashlib
W = Path(__file__).resolve().parent
R = W.parents[1]
original = (W/'source-attempt1/src/graph/resources.cc').read_bytes()
assert hashlib.sha256(original).hexdigest() == '60df445357d9b7f146dd880721da469043e259f193d355cf80112310b239ef6a'
(R/'src/graph/resources.cc').write_bytes(original)
path = R/'tests/graph/region_provider_test.cc'
data = path.read_bytes()
old = (b'  // Empty effects install no authority and keep the original repeatable bind contract.\r\n'
       b'  ASSERT_TRUE(Access::bind_write_effect(run, logical.graph, capacity, {}, {}, {}, selected, {}, {}).ok());\r\n'
       b'  ASSERT_TRUE(Access::bind_write_effect(run, logical.graph, capacity, {}, {}, {}, selected, {}, {}).ok());\r\n')
new = (b'  // Rejected empty effects install no authority and cannot block a later valid bind.\r\n'
       b'  EXPECT_TRUE(Access::bind_write_effect(run, logical.graph, capacity, {}, {}, {}, selected, {}, {}).IsInvalidArgument());\r\n'
       b'  EXPECT_TRUE(Access::bind_write_effect(run, logical.graph, capacity, {}, {}, {}, selected, {}, {}).IsInvalidArgument());\r\n')
assert data.count(old) == 1
path.write_bytes(data.replace(old,new))
print('Restored first passing product source; corrected only the empty-input rejection expectations.')
