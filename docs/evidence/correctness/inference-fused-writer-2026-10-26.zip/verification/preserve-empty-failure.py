from pathlib import Path
import hashlib
import json
W = Path(__file__).resolve().parent
R = W.parents[1]
snapshot = W/'source-attempt2'
assert not snapshot.exists()
pins = []
for name in ['src/graph/resources.cc', 'include/hyle/graph/detail/region_access.h',
             'tests/graph/region_provider_test.cc']:
    data = (R/name).read_bytes()
    dest = snapshot/name
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_bytes(data)
    pins.append(dict(path=name, bytes=len(data), sha256=hashlib.sha256(data).hexdigest()))
(W/'attempt2.json').write_text(json.dumps(dict(status='TEST_EXPECTATION_REJECTED_BY_EXISTING_VALIDATOR',
    sources=pins, process=json.loads((W/'empty-effect-fix/run1/process.json').read_text()),
    cause='The new empty-input assertion incorrectly expected success. Both original and current validate_write_ranges reject writers.empty() && appenders.empty() before installing any authority. The hypothesized empty-binding ghost is unreachable under this validator.',
    scope='Three adjacent tests pass; the first new test rejects its first incorrect empty-bind success assertion. No broadened write authority is intended.'), indent=2)+'\n', encoding='utf-8')
print('Preserved the rejected empty-input expectation and exact sources.')
