"""Recover the exact failed consumer bytes from the three reviewed corrections."""
from pathlib import Path
import hashlib
import json
W = Path(__file__).resolve().parent
R = W.parents[1]
source = (R/'tests/compute_models/glm_pro_mtp_state_consumer_test.cc').read_text(encoding='utf-8')
changes = [
('        std::int32_t cursor=0,index_cursor=0,lag=0;\n        std::uint64_t epoch=0;',
 '        c::StateIdentity result;'),
('            // The ledger witnesses publication without retaining a native\n'
 '            // StateIdentity, which would pin this historical GPU version.\n'
 '            record.cursor=state.scalar(version,kCursor);record.index_cursor=state.scalar(version,kIndexCursor);\n'
 '            record.lag=state.scalar(version,kLag);record.epoch=state.epoch(version).epoch;\n'
 '            record.sampling=random_cursor(version);',
 '            record.result=version.identity();record.sampling=random_cursor(version);'),
('                  if(record.emitted[0]!=state.scalar(actual,kPending)||record.sampling!=random_cursor(actual)||\n'
 '                      record.cursor!=state.scalar(actual,kCursor)||record.index_cursor!=state.scalar(actual,kIndexCursor)||\n'
 '                      record.lag!=state.scalar(actual,kLag)||record.epoch!=state.epoch(actual).epoch)',
 '                  if(record.result!=actual.identity()||record.emitted[0]!=state.scalar(actual,kPending)||\n'
 '                      record.sampling!=random_cursor(actual))')]
for current, previous in changes:
    assert source.count(current)==1
    source = source.replace(current,previous)
receipt = json.loads((W/'compile/glm/superseded-receipt.json').read_text())
expected = next(p for p in receipt['source_identities'] if p['path'].endswith('glm_pro_mtp_state_consumer_test.cc'))
for newline in ('\n','\r\n'):
    payload = source.replace('\n',newline).encode('utf-8')
    if hashlib.sha256(payload).hexdigest()==expected['sha256']:
        assert len(payload)==expected['bytes']
        (W/'failed-glm-source/glm_pro_mtp_state_consumer_test.cc').write_bytes(payload)
        print('Recovered exact failed GLM consumer; matches original compiler source receipt SHA256.')
        break
else:
    raise RuntimeError('Failed consumer reconstruction is not byte-exact')
