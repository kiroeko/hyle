from pathlib import Path
import hashlib
import importlib.util
import json
import subprocess
import sys
import xml.etree.ElementTree as ET
import zipfile

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = W.parents[1]
spec = importlib.util.spec_from_file_location('consumer_build', W / 'build.py')
b = importlib.util.module_from_spec(spec)
spec.loader.exec_module(b)
read, save, pin, exact = b.read, b.save, b.pin, b.exact
plan = read(W / 'plan.json')
for item in plan['retained']:
    exact(item)
builds = {}
all_sources = {}
for name in ('qwen','ordinary','glm'):
    receipt = read(W / 'compile' / name / 'receipt.json')
    exact(receipt['object'])
    for item in receipt['source_identities']:
        exact(item)
        all_sources[item['path'].lower()] = item
    processes = [read(p) for p in sorted((W / 'compile' / name).glob('process*/process.json'))]
    links = [read(p) for p in sorted((W / 'link' / name).rglob('process.json'))]
    assert all(p['state'] == 'TERMINAL' and not p['timed_out'] for p in processes+links)
    assert any(p['exit']==0 for p in processes) and all(p['exit']==0 for p in links)
    builds[name] = dict(compiles=processes, links=links, object=receipt['object'], source_inputs=len(receipt['source_identities']))
cases = {}
for name in ('host','ledger-cpu','mtp-cuda','ordinary-cuda','glm-cuda'):
    folder = W / 'runs' / name
    if name == 'ordinary-cuda':
        folder /= 'final'
    if name == 'glm-cuda':
        folder /= 'owner-fix'
    process = read(folder / 'process.json')
    assert process['state']=='TERMINAL' and process['exit']==0 and not process['timed_out']
    if name == 'glm-cuda':
        root = ET.parse(folder / 'results.xml').getroot()
        assert root.get('tests') == '1' and root.get('failures') == '0' and not root.findall('.//skipped')
        properties = {p.get('name'):p.get('value') for p in root.findall('.//property')}
        assert properties['request_record_committed_prefixes']=='2,1'
        assert properties['request_record_head_publications']=='3'
        assert properties['request_record_late_catchup_refusals']=='1'
        assert properties['request_record_observer_refusals']=='1'
        assert properties['request_record_observer_retry_graphs']=='0'
        assert properties['request_record_observer_retry_head_publications']=='0'
        report = dict(test=root.find('.//testcase').get('name'), properties=properties)
    else:
        report = read(folder / 'report.json')
        assert report['status']=='PASS'
    cases[name] = dict(process=process, report=report)
assert cases['ordinary-cuda']['report']['control_and_candidate_arms']==16
assert cases['ordinary-cuda']['report']['complete_prefix_state_epoch_rng_equal']
assert cases['ledger-cpu']['report']['real_R2_late_trace_error']
assert cases['mtp-cuda']['report']['original_ledger_equal'] and cases['mtp-cuda']['report']['generated_ids_equal']
assert cases['mtp-cuda']['report']['state_checks'][0]['payloads_byte_equal']
failed = read(W / 'runs/ordinary-cuda/process.json')
assert failed['state']=='TERMINAL' and failed['exit']==1 and not failed['timed_out']
assert 'fixture already exists' in (W/'runs/ordinary-cuda/stderr.log').read_text()
glm_failed = read(W / 'runs/glm-cuda/process.json')
assert glm_failed['state']=='TERMINAL' and glm_failed['exit']==1 and not glm_failed['timed_out']
assert 'state.store.stats().versions' in (W/'runs/glm-cuda/stdout.log').read_text()

sources = [R/p for p in ('engine/inference/commit_observation.h','engine/models/qwen35/main.cc',
    'tests/tools/inference_commit_observation_case.h','tests/tools/qwen_request_lifecycle_test.cc',
    'tests/compute_models/glm_pro_mtp_state_consumer_test.cc','tests/compute_models/model_sampling_fragment.h')]
source_pins = [pin(p) for p in sources]
reference_roots = {'vllm': ('vllm','276fbcff2717'), 'tensorrt_llm': ('TensorRT-LLM','46d9966b54d9')}
reference_notes = dict(
    source='Read-only local checkout inspection; no claim of clean worktree or newest upstream.',
    vllm=dict(commit='276fbcff2717', paths=['v1/engine/core.py','v1/core/sched/scheduler.py','model_executor/models/qwen3_5.py'],
              finding='Common scheduler consumes original executor result; model provides math, logits and recurrent-state facts.'),
    tensorrt_llm=dict(commit='46d9966b54d9', paths=['tensorrt_llm/_torch/pyexecutor/engine/model_call.py','tensorrt_llm/_torch/pyexecutor/py_executor.py','tensorrt_llm/_torch/pyexecutor/model_engine.py'],
              finding='Model invocation borrows metadata; resource, request and response updates have distinct responsibilities. Do not copy a large dynamic ModelEngine or a second resource authority.'))
archive = R / 'docs/evidence/correctness/inference-commit-observation-2026-10-29.zip'
include = []
for pattern in ('*.py','*.cc','plan.json','failed-glm-source/*.cc','compile/**/*.json','compile/**/*.log','link/**/*.json','link/**/*.log','runs/**/*.json','runs/**/*.log','runs/**/*.xml'):
    include.extend(W.glob(pattern))
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for path in sorted(set(include)):
        assert path.suffix.lower() not in ('.obj','.exe','.dll','.pdb','.lib','.bin')
        z.write(path, str(path.relative_to(W)).replace('\\','/'))
    for path in sources:
        z.write(path, 'source/'+str(path.relative_to(R)).replace('\\','/'))
    z.writestr('reference-boundaries.json',json.dumps(reference_notes,indent=2)+'\n')
report = dict(schema='hyle.correctness.commit-observation.v1',date='2026-10-29',status='PASS_AFTER_RECORDED_CORRECTIONS',
    base_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),
    change='Reuse original reserved record/count for immediate successful-head witness and contiguous, duplicate-free RequestProgress observation; Qwen and actual GLM Pro component use one common mechanism.',
    counts=dict(CXX_attempts=sum(len(v['compiles']) for v in builds.values()), successful_final_CXX=3,links=4,
        retained_SDK_inputs=227, SDK_rebuilds=0,NVCC=0,native_processes=7,passed_finite_cases=5,
        pre_model_fixture_reuse_refusals=1,detected_and_corrected_GLM_version_retention_failures=1,downloads=0),
    builds=builds,cases=cases,source_inputs=source_pins,archive=pin(archive),reference_boundaries=reference_notes,
    corrections=[
        'First Qwen compile passed; read-only review found active call-scoped tickets could survive failed finish with an unretired Step. Failure-only resets added and Qwen recompiled before native cases.',
        'First GLM compile rejected existing model_sampling_fragment Builder missing dense_spec and explicit TensorSpec one. Adapter now preserves original inference and verifies actual fixed output; no shared sampling algorithm or history branch removed.',
        'First GLM native run detected 5 retained versions versus original required 2. Record StateIdentity retained 3 complete versions. Replaced it with scalar pending/RNG/cursor/lag/epoch facts; original retirement thresholds and actual Head identity checks remain unchanged.',
        'First ordinary process rejected a previously generated stop fixture before creating Model. Final run used fresh metadata-only input folder referencing the same weight payloads; previous fixture/results preserved.'],
    limits=[
        'Qwen request-ledger and ordinary control cases use finite untrained H64 fixtures; no quality/performance claim.',
        'Natural Qwen CUDA case uses cached actual 2B trained weights and 40 greedy outputs; serial and pipeline ledger/IDs/full state match, without throughput measurement.',
        'GLM uses actual target77/NextN78 and full-vocabulary components with finite cached experts and fixture-provided upstream state; not full-model GLM generation or throughput.',
        'Existing lifecycle dispatcher wiring is source-reviewed; the same host helper body is compiled/run by this finite adapter.',
        'Common witness does not prove a complete model-independent execution engine, all model combinations, multiple devices or distributed inference.'])
save(R/'docs/evidence/correctness/inference-commit-observation-2026-10-29.json',report)
print('Recorded 5 finite passed cases, 7 native processes including preserved fixture refusal and corrected GLM retention; small archive',archive.stat().st_size,'bytes.')
