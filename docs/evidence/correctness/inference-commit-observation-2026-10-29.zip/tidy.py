from pathlib import Path
root = Path(__file__).resolve().parents[2]
path = root / 'engine/models/qwen35/main.cc'
source = path.read_text(encoding='utf-8')
begin = source.index('    const auto output_end = request.progress.generated.size();', source.index('void observe_generation_commits'))
end = source.index('\n        });', begin)
body = source[begin:end]
helper = ('void apply_generation_observation(GenerationRequest &request, const GenerationCommitRecord &record,\n'
          '    const inference::CommitObservation &observation) noexcept {\n' +
          '\n'.join(line[2:] if line.startswith('  ') else line for line in body.splitlines()) + '\n}\n\n')
source = source[:begin] + '          apply_generation_observation(request, record, observation);' + source[end:]
marker = '// Consume committed host facts even when a subsequent diagnostic write threw.'
assert source.count(marker) == 1
source = source.replace(marker, helper + marker)
path.write_text(source, encoding='utf-8', newline='\n')
