#include "engine/models/qwen35/main.cc"
#include "tests/tools/inference_commit_observation_case.h"
#include "tests/tools/qwen_request_ledger_case.h"
#include "tests/tools/qwen_host_image_case.h"
#include "tests/tools/qwen_mtp_batch_state_case.h"
#include "tests/tools/qwen_packed_prefill_case.h"
#include "tests/tools/qwen_mtp_natural_relay_case.h"

int main(int argc, char **argv) {
  try {
    if (argc == 2 && std::string_view(argv[1]) == "--host")
      return inference_commit_observation_case::run();
    if (argc == 3 && std::string_view(argv[1]) == "--ledger")
      return qwen_request_ledger_case::run(argv[2]);
    if (argc == 3 && std::string_view(argv[1]) == "--mtp")
      return qwen_mtp_natural_relay_case::run(argv[2], qwen35::BackendKind::kCuda);
    throw std::runtime_error("expected --host, --ledger INPUT, or --mtp INPUT");
  } catch (const std::exception &error) {
    std::cerr << "commit_consumer_failure=" << error.what() << '\n';
    return 1;
  }
}
