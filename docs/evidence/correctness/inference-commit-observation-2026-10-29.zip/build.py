"""Bounded current consumers; no SDK rebuild, download, or throughput claim."""
from pathlib import Path
import importlib.util
import os
import shutil
import sys

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = W.parents[1]
spec = importlib.util.spec_from_file_location('original_process', R / '.scratch/inference-program-identity-20261029/build.py')
b = importlib.util.module_from_spec(spec)
spec.loader.exec_module(b)
b.W = W
read, save, pin, exact, key = b.read, b.save, b.pin, b.exact, b.key
BASE = R / '.scratch/inference-backend-budget-20261029/model-link-base.json'

def prepare():
    base = read(BASE)
    assert len(base['retained']) == 227
    for item in base['retained']:
        exact(item)
    exact(base['runtime'])
    sdk = read(base['sdk_engine_dependencies']['path'])
    for unit in sdk['engine_consumers']:
        for item in unit['source_identities']:
            exact(item)
    original_source = base['consumer_source']['path']
    original_object = read(base['previous_consumer']['path'])['object']['path']
    units = {}
    for name, source in [('qwen', W / 'consumer.cc'),
                         ('ordinary', R / 'tests/tools/qwen_generation_batch_relay_probe.cc'),
                         ('glm', R / 'tests/compute_models/glm_pro_mtp_state_consumer_test.cc')]:
        folder = W / 'compile' / name
        folder.mkdir(parents=True, exist_ok=True)
        args = []
        for index, arg in enumerate(base['compile']):
            if index and base['compile'][index-1].lower() == '/sourcedependencies':
                arg = str(folder / 'dependencies.json')
            elif arg.lower().startswith('/fo'):
                arg = '/Fo' + str(folder / 'unit.obj')
            elif arg.lower().startswith('/fd'):
                arg = '/Fd' + str(folder / 'unit.pdb')
            elif key(arg) == key(original_source):
                arg = str(source)
            args.append(arg)
        if name == 'glm':
            prior = read(R / '.scratch/inference-request-progress-20261025/verification/glm/attempt1/reviewed-command.json')['command']
            args += [arg for arg in prior if arg.startswith(('/I', '/external:I', '/DHYLE_TEST_GLM_')) and arg not in args]
        link = []
        for arg in base['link']:
            if key(arg) == key(original_object):
                arg = str(folder / 'unit.obj')
            for prefix, suffix in [('/OUT:', '.exe'), ('/PDB:', '.pdb'), ('/IMPLIB:', '.lib'), ('/MAP:', '.map')]:
                if arg.upper().startswith(prefix):
                    arg = prefix + str((W / 'bin' / name).with_suffix(suffix))
                    break
            link.append(arg)
        if name == 'glm':
            link += [str(R / '.scratch/build-compute-v2-dev/lib' / name) for name in ('gtest_main.lib', 'gtest.lib')]
        assert sum(key(arg) == key(source) for arg in args) == 1
        assert sum(key(arg) == key(folder / 'unit.obj') for arg in link) == 1
        units[name] = dict(source=str(source), compile=args, link=link)
    (W / 'bin').mkdir(exist_ok=True)
    shutil.copyfile(base['runtime']['path'], W / 'bin' / Path(base['runtime']['path']).name)
    previous = read(R / '.scratch/inference-episode-release-20261029/plan.json')
    ledger_input = R / '.scratch/mtp-runtime-backend-20261024/verification1/tiny-run/fixture'
    natural = previous['fixtures']['natural']['directory']
    original_ordinary = R / '.scratch/inference-episode-release-20261029/ordinary-input'
    ordinary = W / 'ordinary-input'
    ordinary.mkdir(exist_ok=True)
    for metadata in ('weights.tsv', 'prompt.ids'):
        shutil.copyfile(original_ordinary / metadata, ordinary / metadata)
    glm_env = read(R / '.scratch/inference-request-progress-20261025/verification/glm/attempt1/run-inputs.json')
    glm_env = {k: v for k, v in glm_env.items() if k.startswith('HYLE_GLM_PRO') or k in ('HF_HUB_OFFLINE','TRANSFORMERS_OFFLINE')}
    for k, path in glm_env.items():
        if k.startswith('HYLE_GLM_PRO'):
            assert Path(path).is_dir()
    cases = {
        'host': ['qwen', '--host'],
        'ledger-cpu': ['qwen', '--ledger', str(ledger_input)],
        'mtp-cuda': ['qwen', '--mtp', natural],
        'ordinary-cuda': ['ordinary', '--cuda-continuous', str(ordinary)],
        'glm-cuda': ['glm', '--gtest_color=no', '--gtest_filter=GlmProMtpStateConsumer.CudaOriginalTarget77AndNextNRandomVerifierContinuesAtomically',
                     '--gtest_output=xml:' + str(W / 'runs/glm-cuda/results.xml')]
    }
    save(W / 'plan.json', dict(base=pin(BASE), units=units, retained=base['retained'], runtime=base['runtime'],
        sdk=base['sdk_engine_dependencies'], cases=cases, glm_environment=glm_env,
        ledger_manifest=pin(ledger_input / 'weights.tsv'),
        natural_fixture=previous['fixtures']['natural'], ordinary_manifest=pin(ordinary / 'weights.tsv'),
        policy='3 CXX/link consumers, 5 finite native cases, no SDK/NVCC rebuild, download or throughput measurement.'))
    print('Prepared 3 current consumers, 227 retained SDK inputs, 5 finite cases; no native work started.')

def main():
    action = sys.argv[1]
    if action == 'prepare':
        prepare()
        return
    plan = read(W / 'plan.json')
    name = sys.argv[2]
    if action == 'compile':
        attempt = 'process' if len(sys.argv) < 4 else 'process-' + sys.argv[3]
        receipt_path = W / 'compile' / name / 'receipt.json'
        if receipt_path.exists():
            shutil.copyfile(receipt_path, receipt_path.with_name('superseded-receipt.json'))
            shutil.copyfile(receipt_path.with_name('dependencies.json'), receipt_path.with_name('superseded-dependencies.json'))
        b.execute(plan['units'][name]['compile'], W / 'compile' / name / attempt, 240)
        deps = read(W / 'compile' / name / 'dependencies.json')['Data']
        paths = sorted({Path(p).resolve() for p in [deps['Source'], *deps['Includes']] if Path(p).is_relative_to(R)})
        assert R / 'engine/inference/commit_observation.h' in paths
        save(W / 'compile' / name / 'receipt.json', dict(object=pin(W / 'compile' / name / 'unit.obj'), source_identities=[pin(p) for p in paths]))
    elif action == 'link':
        receipt = read(W / 'compile' / name / 'receipt.json')
        exact(receipt['object'])
        for item in receipt['source_identities']:
            exact(item)
        for item in plan['retained']:
            exact(item)
        folder = W / 'link' / name
        if len(sys.argv) > 3:
            folder /= sys.argv[3]
        b.execute(plan['units'][name]['link'], folder, 180)
        save(W / ('link-receipt-' + name + '.json'), pin(folder / 'process.json'))
        save(W / ('ready-' + name + '.json'), pin(W / 'bin' / (name + '.exe')))
    elif action == 'run':
        unit, *args = plan['cases'][name]
        image = read(W / ('ready-' + unit + '.json'))
        exact(image)
        receipt = read(W / 'compile' / unit / 'receipt.json')
        for item in receipt['source_identities']:
            exact(item)
        if name == 'glm-cuda':
            os.environ.update(plan['glm_environment'])
        folder = W / 'runs' / name
        if len(sys.argv) > 3:
            folder = folder / sys.argv[3]
        if name == 'glm-cuda':
            args = ['--gtest_output=xml:' + str(folder / 'results.xml') if arg.startswith('--gtest_output=xml:') else arg for arg in args]
        b.execute([image['path'], *args], folder, 360 if name == 'glm-cuda' else 300)
        output = (folder / 'stdout.log').read_text(encoding='utf-8', errors='replace')
        if name == 'glm-cuda':
            import xml.etree.ElementTree as ET
            tree = ET.parse(folder / 'results.xml')
            assert tree.getroot().get('tests') == '1' and tree.getroot().get('failures') == '0'
            assert not tree.findall('.//skipped')
            print('PASS real GLM Pro target77/NextN78 CUDA consumer; properties retained in XML.')
        else:
            report = read(folder / 'stdout.log')
            assert report['status'] == 'PASS'
            save(folder / 'report.json', report)
            print('PASS', name)
    else:
        raise ValueError(action)

if __name__ == '__main__':
    main()
