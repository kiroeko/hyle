"""Explicit two-TU Graph slot transaction check; no SDK/configure/engine build."""
from pathlib import Path
import importlib.util,json,os,sys,xml.etree.ElementTree as ET
sys.dont_write_bytecode=True;sys.stdout.reconfigure(encoding='utf-8')
W=Path(__file__).resolve().parent;R=W.parents[1]
B=R/'.scratch/inference-fused-writer-20261026/empty-rejection-final'
spec=importlib.util.spec_from_file_location('cached_frame',R/'.scratch/inference-paged-frame-20261026/build.py')
f=importlib.util.module_from_spec(spec);spec.loader.exec_module(f);m,b=f.m,f.b
SPECS=[('slots','src/graph/slots.cc',R/'.scratch/inference-fused-writer-20261026/compile/resources/command.json'),
 ('test','tests/graph/slot_bindings_test.cc',B/'compile/test/command.json')]
EXPECTED={'include/hyle/graph/slots.h':'218b43a9d792c18e7b4c51e1edf46c1bb5bd928130de0d5392af0b21e0db2e9f',
 'src/graph/slots.cc':'96761f58fefb7dad3cfc9f703b53a333524e2cbc0225bc3b223f8a93b05af2c8',
 'tests/graph/slot_bindings_test.cc':'281f4190d03ba5a9b09d79aed3dd0a87853952636c061c22b5cfa4bb66094b94'}
def plan():
    assert not (W/'plan.json').exists()
    for path,expected in EXPECTED.items():assert b.pin(R/path)['sha256']==expected,path
    ready=b.read(B/'ready.json');inputs=b.read(ready['inputs']['path']);assert len(inputs)==137
    for row in inputs:b.exact(row)
    assert sum(b.key(x['path'])==b.key(ready['compiled']['object']['path']) for x in inputs)==1
    assert sum(b.key(x['path'])==b.key(ready['reused_resources']['object']['path']) for x in inputs)==1
    assert ready['reused_resources']['source']['sha256']=='60df445357d9b7f146dd880721da469043e259f193d355cf80112310b239ef6a'
    core=R/'.scratch/inference-lease-slots-20261026/compile/core/unit.obj'
    assert sum(b.key(x['path'])==b.key(core) for x in inputs)==1
    units=[dict(name=n,source=b.pin(R/s),recipe=b.pin(recipe),command=m.command(recipe,R/s,W/'compile'/n)) for n,s,recipe in SPECS]
    for u in units:
        assert all(x in u['command'] for x in ('/O2','/W4','/WX','/DHYLE_COMPUTE_CPU=1'))
        assert not any(x.startswith('/I') and b.key(R/'.scratch') in b.key(x) for x in u['command'])
    frozen=m.c.closure([u['source']['path'] for u in units],[r for _,_,r in SPECS]);b.save(W/'source-freeze.json',frozen)
    b.save(W/'plan.json',dict(status='FROZEN_NOT_BUILT',units=units,source_freeze=b.pin(W/'source-freeze.json'),expected_source_hashes=EXPECTED,
      baseline=dict(command=b.pin(B/'link/command.json'),inputs=ready['inputs'],runtime=ready['runtime'],ready=b.pin(B/'ready.json')),
      replace_test=ready['compiled']['object'],reused_Graph_resources=ready['reused_resources'],reused_LeaseSlots_core=b.pin(core),
      compiled_TUs=2,images=1,SDK_configure_engine_native_builds=0,
      scope='All six GraphSlots cases in slot_bindings_test.cc, using passed fused-writer resources object and passed LeaseSlots core. In-progress new resources release is not compiled or claimed.'))
    print('PLAN',json.dumps(b.pin(W/'plan.json')),flush=True)
def environment(p):
    h=b.helper();cl=p['units'][0]['command'][0]
    return h,h.discover_environment(compiler='msvc',cache={'CMAKE_C_COMPILER':cl,'CMAKE_CXX_COMPILER':cl,'CMAKE_GENERATOR':'Ninja'},backends=()).env
def build():
    p=b.read(W/'plan.json');assert not (W/'compile').exists() and not (W/'ready.json').exists()
    frozen=b.read(p['source_freeze']['path']);own={b.key(x['path']):x for x in frozen}
    for row in frozen:b.exact(row)
    for row in b.read(p['baseline']['inputs']['path']):b.exact(row)
    h,env=environment(p);objects={};results=[]
    for u in p['units']:
        out=W/'compile'/u['name'];process=h.execute(u['command'],env,out,timeout=180)
        deps=b.read(out/'dependencies.json')['Data'];actual=[b.pin(x) for x in dict.fromkeys([deps['Source'],*deps['Includes']])]
        for row in actual:
            q=Path(row['path'])
            if q.is_relative_to(R) and not q.is_relative_to(R/'.scratch'):assert own[b.key(q)]['sha256']==row['sha256'],str(q)
        b.save(out/'actual-dependencies.json',actual);objects[u['name']]=b.pin(out/'unit.obj')
        results.append(dict(name=u['name'],source=u['source'],object=objects[u['name']],process=process,actual_dependencies=b.pin(out/'actual-dependencies.json')))
        for row in frozen:b.exact(row)
    image=W/'link/slot-bindings-test.exe';args=[];changed=0
    for arg in b.read(p['baseline']['command']['path'])['command']:
        if b.key(arg)==b.key(p['replace_test']['path']):arg=objects['test']['path'];changed+=1
        elif arg.upper().startswith('/OUT:'):arg='/OUT:'+str(image)
        elif arg.upper().startswith('/PDB:'):arg='/PDB:'+str(image.with_suffix('.pdb'))
        elif arg.upper().startswith('/IMPLIB:'):arg='/IMPLIB:'+str(image.with_suffix('.lib'))
        elif arg.upper().startswith('/MAP:'):continue
        args.append(arg)
    assert changed==1;args.insert(1,objects['slots']['path'])
    result=h.execute(args,env,W/'link',timeout=90)
    inputs=[objects['test'] if b.key(x['path'])==b.key(p['replace_test']['path']) else x for x in b.read(p['baseline']['inputs']['path'])]+[objects['slots']]
    assert len(inputs)==138;b.save(W/'link-inputs.json',inputs);b.save(W/'runtime.json',b.read(p['baseline']['runtime']['path']))
    b.save(W/'ready.json',dict(status='BUILT_NOT_RUN',image=b.pin(image),compiled=results,link=result,inputs=b.pin(W/'link-inputs.json'),runtime=b.pin(W/'runtime.json'),plan=b.pin(W/'plan.json'),SDK_configure_engine_native_builds=0))
    print('READY',json.dumps(b.pin(W/'ready.json')),flush=True)
def run():
    p=b.read(W/'plan.json');ready=b.read(W/'ready.json');b.exact(ready['image']);h,env=environment(p);env['PATH']=b.read(ready['runtime']['path'])['PATH']
    result=h.execute([ready['image']['path'],'--gtest_color=no','--gtest_filter=GraphSlots.*','--gtest_output=xml:'+str(W/'results.xml')],env,W/'run1',timeout=60)
    tree=ET.parse(W/'results.xml').getroot();assert int(tree.attrib['tests'])==6 and int(tree.attrib['failures'])==0
    b.save(W/'summary.json',dict(status='SIX_GRAPH_SLOT_BINDING_CASES_PASS',process=result,tests=6,failures=0,ready=b.pin(W/'ready.json'),results=b.pin(W/'results.xml'),model_runs=0,SDK_configure_native_builds=0,scope=p['scope']))
    print('SUMMARY',json.dumps(b.pin(W/'summary.json')),flush=True)
if __name__=='__main__':
    if sys.argv[1:]==['plan']:plan()
    elif sys.argv[1:]==['build']:build()
    elif sys.argv[1:]==['run']:run()
    else:print(__doc__)
