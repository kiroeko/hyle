"""Publish this completed six-case slot transaction check; no native actions."""
from pathlib import Path
from datetime import datetime,timedelta,timezone
import hashlib,json,sys,xml.etree.ElementTree as ET,zipfile
W=Path(__file__).resolve().parent;R=W.parents[1]
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def sha(raw):return hashlib.sha256(raw).hexdigest()
def publish():
    dest=R/'docs/evidence/correctness/inference-slot-bindings-2026-10-27.json';archive=dest.with_suffix('.zip')
    assert not dest.exists() and not archive.exists()
    plan=read(W/'plan.json');ready=read(W/'ready.json');payload={};sources=[]
    for path,expected in plan['expected_source_hashes'].items():
        raw=(R/path).read_bytes();assert sha(raw)==expected,path
        payload['source/'+path]=raw;sources.append(dict(path=path,bytes=len(raw),sha256=expected))
    for row in read(W/'source-freeze.json'):
        assert sha(Path(row['path']).read_bytes())==row['sha256'],row['path']
    records=['build.py','publish.py','plan.json','source-freeze.json','ready.json','link-inputs.json','runtime.json','results.xml','summary.json']
    for tag in ['compile/slots','compile/test','link','run1']:
        records += [tag+'/'+n for n in ('command.json','process.json','running.json','stdout.log','stderr.log')]
        if tag.startswith('compile/'):
            records += [tag+'/dependencies.json',tag+'/actual-dependencies.json']
    for n in records:payload['records/'+n]=(W/n).read_bytes()
    assert not any(Path(n).suffix.lower() in ('.obj','.exe','.pdb','.lib','.dll','.bin') for n in payload)
    tree=ET.parse(W/'results.xml').getroot();assert int(tree.attrib['tests'])==6 and int(tree.attrib['failures'])==0
    cases=[]
    for x in tree.iter('testcase'):
        assert x.attrib['result']=='completed' and x.find('skipped') is None
        cases.append(x.attrib)
    processes=[dict(stage=n,**read(W/n/'process.json')) for n in ['compile/slots','compile/test','link','run1']]
    assert all(x['exit']==0 for x in processes)
    files=[dict(path=n,bytes=len(raw),sha256=sha(raw)) for n,raw in sorted(payload.items())]
    with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED) as z:
        for n,raw in sorted(payload.items()):z.writestr(n,raw)
    with zipfile.ZipFile(archive) as z:
        assert z.namelist()==[x['path'] for x in files]
        for row in files:
            raw=z.read(row['path']);assert len(raw)==row['bytes'] and sha(raw)==row['sha256'],row['path']
    assert archive.stat().st_size<2_000_000
    data=dict(schema=1,batch='inference-slot-bindings-20261027',status='SIX_GRAPH_SLOT_BINDING_CASES_PASS',
      published_at=datetime.now(timezone.utc).astimezone(timezone(timedelta(hours=8))).isoformat(),
      test_started_at=tree.attrib['timestamp'],test_timestamp_timezone='Asia/Shanghai, UTC+08:00',
      scope='Finite Windows CPU resource transaction/schema contract tests for graph::slots::SlotBindings. Complete slot_bindings_test.cc TU; no model or native execution pipeline.',
      source_identity=sources,image=ready['image'],processes=processes,tests=6,failures=0,skipped=0,test_cases=cases,
      successful_TUs=2,compile_processes=2,link_processes=1,test_processes=1,
      compile_contract='Original CPU /O2 /W4 /WX CXX flags with canonical Hyle include roots; all actual own-source dependencies checked against the 32-file frozen closure.',
      reuse=dict(baseline=plan['baseline'],reused_Graph_resources=plan['reused_Graph_resources'],reused_LeaseSlots_core=plan['reused_LeaseSlots_core'],
        original_inputs=137,result_inputs=138,replaced='One original Graph GTest TU object',added='One current graph/slots.cc object',
        retained='All other Compute/Graph/provider/native dependencies and GoogleTest from the passed fused-writer closure remain unchanged; no archive rewrite.',
        note='The Graph resources object is the passed 60df445... implementation, not the later in-progress release work.'),
      limits=['This does not claim engine wiring, native Gather/scatter execution, complete projected-read permission, or a throughput gain.',
        'No reconfigure, SDK rebuild, CUDA build/run, Apple/Linux run, or full-engine test was performed in this batch.'],
      quality_claim=False,performance_claim=False,model_runs=0,SDK_builds=0,reconfigure_runs=0,HTTP=0,
      archive=dict(path=archive.relative_to(R).as_posix(),bytes=archive.stat().st_size,sha256=sha(archive.read_bytes()),file_count=len(files),files=files))
    dest.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(dict(summary=dict(path=str(dest),bytes=dest.stat().st_size,sha256=sha(dest.read_bytes())),archive={k:v for k,v in data['archive'].items() if k!='files'},tests=6,failures=0),ensure_ascii=False,indent=2))
if __name__=='__main__':
    if sys.argv[1:]==['publish']:publish()
    else:print(__doc__)
