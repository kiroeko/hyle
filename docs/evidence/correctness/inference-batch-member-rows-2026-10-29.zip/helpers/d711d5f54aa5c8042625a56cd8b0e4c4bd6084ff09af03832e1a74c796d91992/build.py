"""One explicit consumer CXX/link, then separately requested local-only cases."""
from pathlib import Path
import importlib.util
import json
import re
import shlex
import sys

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = W.parents[1]
OLD = R / '.scratch/inference-ledger-storage-20261029'
BASE = OLD / 'model-link-base.json'
NATURAL_HELPER = R / '.scratch/inference-mtp-natural-20261029/build.py'
spec = importlib.util.spec_from_file_location('member_rows_existing_build', NATURAL_HELPER)
b = importlib.util.module_from_spec(spec); spec.loader.exec_module(b)
t = b.t
b.W = t.W = W
b.SOURCES = {'tiny': R / 'tests/tools/qwen_host_image_test.cc'}
b.CASES = {'varlen-cpu': ('tiny', 'cpu', '--mtp-varlen-verify'),
           'varlen-cuda': ('tiny', 'cuda', '--mtp-varlen-verify'),
           'cli-cpu': ('tiny', 'cpu', '--engine'),
           'cli-cuda': ('tiny', 'cuda', '--engine'),
           'natural-cuda': ('tiny', 'cuda', '--mtp-natural-relay')}


def fixture(directory):
    files = {}
    for line in (directory / 'weights.tsv').read_text(encoding='utf-8-sig').splitlines()[3:]:
        fields = shlex.split(line)
        if not fields: continue
        rank = int(fields[2]); path = Path(fields[3 + rank]).resolve()
        start, length = map(int, fields[4 + rank:6 + rank]); st = path.stat()
        assert start >= 0 and length >= 0 and start + length <= st.st_size
        files[t.key(path)] = dict(path=str(path), bytes=st.st_size,
                                 mtime_ns=st.st_mtime_ns, file_id=st.st_ino)
    assert files
    return dict(directory=str(directory), manifest=t.pin(directory / 'weights.tsv'),
                prompt=t.pin(directory / 'prompt.ids'), local_weight_sources=list(files.values()))


def closure(paths):
    found = {t.key(Path(path).resolve()): str(Path(path).resolve()) for path in paths}
    todo = list(found.values())
    while todo:
        current = Path(todo.pop())
        for inc in re.findall(r'^\s*#\s*include\s*"([^\"]+)"', current.read_text(encoding='utf-8-sig'), re.M):
            path = next((q.resolve() for root in (current.parent, R / 'include', R)
                         if (q := root / inc).is_file()), None)
            if path is not None and t.project(path) and t.key(path) not in found:
                found[t.key(path)] = str(path); todo.append(str(path))
    return sorted(found.values(), key=t.key)


def prepare():
    base = t.read(BASE); previous_path = Path(base['previous_consumer']['path'])
    previous = t.read(previous_path)
    assert len(base['retained']) == 227
    retained_keys = {t.key(row['path']) for row in base['retained']}
    assert len(retained_keys) == 227
    for row in base['retained']: t.exact(row)
    old = [arg for arg in base['link'] if arg.lower().endswith('.obj') and t.key(arg) not in retained_keys]
    assert len(old) == 1
    source = b.SOURCES['tiny']; compile_args = []
    for index, arg in enumerate(base['compile']):
        if index and base['compile'][index - 1].lower() == '/sourcedependencies':
            arg = str(W / 'compile/tiny/dependencies.json')
        elif arg.lower().startswith('/fo'): arg = '/Fo' + str(W / 'compile/tiny/unit.obj')
        elif arg.lower().startswith('/fd'): arg = '/Fd' + str(W / 'compile/tiny/unit.pdb')
        compile_args.append(arg)
    if not any(arg.lower().startswith('/fd') for arg in compile_args):
        compile_args.append('/Fd' + str(W / 'compile/tiny/unit.pdb'))
    assert sum(t.key(arg) == t.key(source) for arg in compile_args) == 1
    link_args = []
    for arg in base['link']:
        if t.key(arg) == t.key(old[0]): arg = str(W / 'compile/tiny/unit.obj')
        for prefix, suffix in (('/OUT:', '.exe'), ('/PDB:', '.pdb'), ('/IMPLIB:', '.lib'), ('/MAP:', '.map')):
            if arg.upper().startswith(prefix): arg = prefix + str((W / 'bin/tiny').with_suffix(suffix)); break
        link_args.append(arg)
    assert sum(t.key(arg) == t.key(W / 'compile/tiny/unit.obj') for arg in link_args) == 1
    assert all(sum(t.key(arg) == key for arg in link_args) == 1 for key in retained_keys)
    sources = closure([str(t.canonical(row['path'])) for row in previous['project_dependencies']] + [str(source)])
    case_directory = W / 'cases'; case_directory.mkdir(exist_ok=False)
    case_files = {'prompt.ids': '1 2 3\n', 'short.schedule': 'prompt "prompt.ids"\ngenerate 3\n',
                  'long.schedule': 'prompt "prompt.ids"\ngenerate 4\n',
                  'sessions.txt': 'short "short.schedule"\nlong "long.schedule"\n'}
    for name, contents in case_files.items():
        with (case_directory / name).open('x', encoding='utf-8', newline='\n') as stream: stream.write(contents)
    env = t.read(OLD / 'attempt2/environment.json')
    env['PATH'] = str(W / 'bin') + ';' + env['PATH']
    t.save(W / 'environment.json', env)  # Local only; never print/archive environment values.
    t.save(W / 'plan.json', dict(base=t.pin(BASE), previous_consumer=t.pin(previous_path),
        units={'tiny': dict(source=str(source), compile=compile_args, link=link_args)},
        retained=base['retained'], runtime=base['runtime'], sources=sources,
        fixtures=dict(varlen=fixture(b.PLAIN), natural=fixture(b.NATURAL)),
        cli_inputs=[t.pin(case_directory / name) for name in case_files],
        cli_arguments=['--engine', '--inputs', str(b.PLAIN), '--session-schedules', str(case_directory / 'sessions.txt'),
            '--capacity', '16', '--max-sessions', '2', '--active-sequences', '2', '--prefix-cache', 'off',
            '--progress', 'direct', '--replay', 'auto', '--mtp', 'on', '--mtp-max-drafts', '2', '--sampling', 'greedy'],
        helpers=[t.pin(__file__), t.pin(NATURAL_HELPER),
                 t.pin(R / '.scratch/inference-indexed-store-20261028/build.py')],
        cases=b.CASES, counts=dict(CXX=1, links=1, SDK_CXX=0, NVCC=0,
            inputs_per_link=228, retained_inputs=227, planned_native_cases=4, optional_natural_cases=1, downloads=0),
        policy='Explicit actions only: no retry, implicit build/run, SDK copy, download or cleanup. '
               'Only existing local manifest SHA and weight file identity/size/mtime/extents are checked.'))
    print('PREPARED one consumer CXX/link; 227 retained SDK inputs, no native execution')


def validate():
    plan = t.read(W / 'plan.json')
    for row in t.read(W / 'source-freeze.json'): t.exact(row)
    for row in [plan['base'], plan['previous_consumer'], *plan['helpers']]: t.exact(row)
    for row in plan['cli_inputs']: t.exact(row)
    for entry in plan['fixtures'].values():
        t.exact(entry['manifest']); t.exact(entry['prompt'])
        for row in entry['local_weight_sources']:
            st = Path(row['path']).stat()
            assert (st.st_size, st.st_mtime_ns, st.st_ino) == (row['bytes'], row['mtime_ns'], row['file_id'])
    return plan


b.validate = validate


def parse_cli(name, process, report):
    assert report['mtp'] is True and report['source_id'] == '6' * 64
    assert report['session_count'] == report['turn_count'] == report['active_sequences'] == report['max_sessions'] == 2
    assert report['prefix_cache'] is False and report['retired_requests'] == 2 and report['live_committed_versions'] == 0
    assert report['requested_output_tokens'] == report['generated_tokens'] == 7 and report['restore_count'] == 0
    batches = report['batches']; assert batches
    by_session = {'short': [], 'long': []}; active = verified = prefill = 0
    unequal = []
    for batch in batches:
        rows = batch['input_rows']; ids = batch['session_ids']
        assert len(rows) == len(ids) == batch['requests'] and rows and all(n > 0 for n in rows)
        assert batch['tokens'] == max(rows) and batch['active_rows'] == sum(rows)
        assert batch['active_rows'] <= batch['physical_rows'] == batch['tokens'] * len(rows)
        active += batch['active_rows']
        if batch['generation']: verified += batch['active_rows']
        else: prefill += batch['active_rows']
        if batch['role'] == 1 and rows == [2,3]:
            assert batch['tokens'] == 3 and batch['active_rows'] == 5 and batch['physical_rows'] == 6
            unequal.append(batch['index'])
        for member, (identity, count) in enumerate(zip(ids, rows)):
            by_session[identity].append((batch['role'], batch['generation'], batch['requests'], member, count))
    assert unequal, 'actual natural CLI did not submit the unequal Verify2/Verify3 batch'
    assert report['actual_target_rows'] == active + report['restored_target_rows']
    assert report['verified_target_rows'] == verified and report['prefill_target_rows'] == prefill
    assert len(report['sessions']) == 2
    per_session_actual = per_session_verified = 0
    for session in report['sessions']:
        identity = session['session_id']; result = session['result']; ledger = session['ledger']
        assert len(result['generated_ids']) == result['generated_tokens'] == (3 if identity == 'short' else 4)
        assert len(ledger) == len(by_session[identity]) and all(record['imported'] is False for record in ledger)
        member_verified = member_prefill = 0; rounds = []
        for record, fact in zip(ledger, by_session[identity]):
            role, generation, requests, member, count = fact
            assert (record['role'], record['generation'], record['requests'], record['member_index']) == (role, generation, requests, member)
            if generation:
                assert record['verified_rows'] == len(record['verification_input_ids']) == count
                assert 1 <= record['accepted'] <= count and record['after_length'] - record['before_length'] == record['accepted']
                member_verified += count; rounds.append(record)
            else:
                assert record['input_rows'] == count; member_prefill += count
        assert result['verified_target_rows'] == member_verified
        assert result['prefill_target_rows'] == member_prefill
        assert result['actual_target_rows'] == member_prefill + member_verified + result['restored_target_rows']
        assert len(result['rounds']) == len(rounds)
        for row, record in zip(result['rounds'], rounds): assert row['verified_rows'] == record['verified_rows']
        per_session_actual += result['actual_target_rows']; per_session_verified += member_verified
    assert per_session_actual == report['actual_target_rows'] and per_session_verified == verified
    t.save(W / 'runs' / name / 'checks.json', dict(status='PASS', backend=name.removeprefix('cli-'),
        actual_cli=True, natural_acceptance=True, session_output_limits=[3,4], unequal_verify_batches=unequal,
        all_batch_members_match_ledger=True, all_active_rows_sum=True, active_target_rows=active,
        verified_target_rows=verified, prefill_target_rows=prefill, final_versions=0,
        quality_claim=False, performance_claim=False))
    print('CLI PASS', name, 'PID', process['pid'], 'unequal Verify batches', unequal)


def parse(name):
    validate()
    if name == 'natural-cuda': b.parse(name); return
    assert name in ('varlen-cpu', 'varlen-cuda', 'cli-cpu', 'cli-cuda')
    _, backend, _ = b.CASES[name]; out = W / 'runs' / name
    process = t.read(out / 'process.json')
    assert process['state'] == 'TERMINAL' and process['exit'] == 0 and not process['timed_out']
    reports = [json.loads(line) for line in (out / 'stdout.log').read_text(encoding='utf-8-sig').splitlines() if line.startswith('{')]
    if name in ('cli-cpu', 'cli-cuda'):
        assert len(reports) == 1; parse_cli(name, process, reports[0]); t.save(out / 'report.json', reports[0]); return
    assert len(reports) == 2; host, report = reports
    assert host['status'] == 'PASS' and host['case'] == 'packed-prefix-rows' and host['models'] == 0 and host['manual_orders'] == 2
    for field in ('allocation_free_selector', 'zero_history', 'late_failure_preserves_outputs', 'overlap_preserves_outputs'):
        assert host[field] is True, field
    assert report['status'] == 'PASS' and report['backend'] == backend and report['mode'] == 'mtp_varlen_verify'
    assert report['models'] == 1 and report['requests'] == 2
    assert (report['physical_rows_per_member'], report['active_rows'], report['physical_rows']) == (3, 4, 6)
    assert report['length_orders'] == [[1,3],[3,1],[1,3]] and report['controlled_accepted'] == [[1,2],[3,1]]
    assert (report['target_submissions'], report['bounded_target_submissions']) == (11,3)
    assert report['ledger_reserved_width'] == 8 and report['ledger_record_storage_checks'] == 24
    assert report['ledger_cold_storage_reused'] is True and report['ledger_host_prepare_withdraw_reprepare'] is True
    assert report['natural_proposal_rows'] == [0,2] and report['natural_rng_draws'] == [1,5]
    assert report['batch_observer_calls'] == 1 and report['batch_member_target_rows'] == [1,3]
    assert report['batch_active_rows'] == 4 and report['batch_physical_rows'] == 6
    for field in ('old_checkpoints_unchanged', 'accepted_prefixes_1_2_3', 'fixed_carrier_reused',
                  'engine_unequal_lengths_one_submission', 'original_q_identity_and_release', 'natural_R1_results_equal'):
        assert report[field] is True, field
    assert report['full_request_history_import_coverage'] is False and report['quality_claim'] is False
    assert report['performance_claim'] is False and report['synthetic_untrained'] is True and report['final_versions'] == 0
    assert len(report['natural_processed_target']) == len(report['natural_processed_draft']) == 2
    assert report['natural_processed_target'][0] == 1 and 1 <= report['natural_processed_target'][1] <= 3
    assert report['natural_processed_draft'][0] == 2
    rows = report['state_checks']; assert len(rows) == 6 and report['numerically_equivalent'] is True
    assert report['payloads_byte_equal'] == all(row['payloads_byte_equal'] for row in rows)
    for row in rows:
        assert row['boundary_equal'] and row['numerically_equivalent'] and row['exact_next'] == row['bucket_next']
        assert row['payloads_byte_equal'] == (not row['differences'])
        for diff in row['differences']:
            assert diff['role'] == 3 and diff['nonfinite_differences'] == 0 and 0 <= diff['maximum_absolute'] <= 3e-6
    t.save(out / 'host-report.json', host); t.save(out / 'report.json', report)
    print('PASS', name, 'PID', process['pid'], 'complete state comparisons', len(rows))


def run(name):
    plan = validate(); _, backend, flag = b.CASES[name]
    entry = plan['fixtures']['natural' if name == 'natural-cuda' else 'varlen']
    ready = t.read(W / 'ready-tiny.json'); t.exact(ready['image'])
    argv = [ready['image']['path']]
    if name.startswith('cli-'): argv += plan['cli_arguments'] + ['--backend', backend]
    else: argv += ['--' + backend, entry['directory'], flag]
    t.execute(argv, W / 'runs' / name, 300)
    parse(name)


if __name__ == '__main__':
    action = sys.argv[1]
    if action == 'prepare': prepare()
    elif action in ('freeze', 'validate'): getattr(b, action)()
    elif action in ('compile', 'parse_compile', 'link'):
        assert len(sys.argv) == 3 and sys.argv[2] == 'tiny'; getattr(b, action)('tiny')
    elif action in ('run', 'parse'): globals()[action](sys.argv[2])
    else: raise ValueError(action)
