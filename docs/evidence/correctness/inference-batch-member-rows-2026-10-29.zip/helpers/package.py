"""Offline finite row-accounting evidence; no build, run, cleanup or network."""
from pathlib import Path
import collections
import hashlib
import importlib.util
import json
import math
import sys
import zipfile

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = W.parents[1]
DEST = R / 'docs/evidence/correctness/inference-batch-member-rows-2026-10-29'
spec = importlib.util.spec_from_file_location('member_rows_evidence_build', W / 'build.py')
b = importlib.util.module_from_spec(spec); spec.loader.exec_module(b)
t = b.t
CASES = ('cli-cpu', 'cli-cuda', 'varlen-cpu', 'varlen-cuda', 'natural-cuda')


def terminal(directory):
    value = t.read(directory / 'process.json')
    assert value['state'] == 'TERMINAL' and value['exit'] == 0 and not value['timed_out'], directory
    return value


def main():
    plan = b.validate()
    frozen = t.read(W / 'source-freeze.json'); assert len(frozen) == 240
    compiled = t.read(W / 'compile/tiny/compiled.json'); assert len(compiled['project_dependencies']) == 226
    ready = t.read(W / 'ready-tiny.json')
    cxx = terminal(W / 'logs/compile-tiny'); link = terminal(W / 'logs/link-tiny')
    assert compiled['process'] == cxx and ready['process'] == link and ready['compiled'] == compiled
    assert t.command(W / 'logs/compile-tiny/command.json') == plan['units']['tiny']['compile']
    assert t.command(W / 'logs/link-tiny/command.json') == plan['units']['tiny']['link']
    assert ready['source_freeze'] == t.pin(W / 'source-freeze.json')
    t.exact(ready['image']); t.exact(compiled['object'])
    sdk = {t.key(row['path']): row for row in plan['retained']}; assert len(sdk) == 227
    assert collections.Counter(Path(row['path']).suffix.lower() for row in sdk.values()) == {'.obj':202, '.lib':25}
    assert ready['inputs'] == plan['retained'] + [compiled['object']]
    assert len({t.key(row['path']) for row in ready['inputs']}) == 228
    source_index = {t.key(row['path']): row for row in frozen}
    for row in compiled['project_dependencies']: assert source_index[t.key(row['path'])] == row
    assert [row for row in compiled['actual_dependencies'] if t.project(row['path'])] == compiled['project_dependencies']
    runs = {}; state_rows = []; storage_checks = 0
    for name in CASES:
        directory = W / 'runs' / name; process = terminal(directory)
        report = t.read(directory / 'report.json'); backend = name.rsplit('-',1)[1]
        raw = [json.loads(line) for line in (directory / 'stdout.log').read_text(encoding='utf-8-sig').splitlines() if line.startswith('{')]
        command = t.command(directory / 'command.json')
        if name.startswith('cli-'):
            assert raw == [report]
            assert command == [ready['image']['path'], *plan['cli_arguments'], '--backend', backend]
            checks = t.read(directory / 'checks.json')
            assert checks['status'] == 'PASS' and checks['backend'] == backend and checks['actual_cli'] is True
            assert checks['natural_acceptance'] is True and checks['session_output_limits'] == [3,4]
            assert checks['unequal_verify_batches'] and checks['all_batch_members_match_ledger'] is True
            assert checks['all_active_rows_sum'] is True and checks['final_versions'] == 0
            assert checks['quality_claim'] is False and checks['performance_claim'] is False
            unequal = [row['index'] for row in report['batches'] if row['role'] == 1 and row['input_rows'] == [2,3]]
            assert unequal == checks['unequal_verify_batches']
            for row in report['batches']:
                assert sum(row['input_rows']) == row['active_rows'] and max(row['input_rows']) == row['tokens']
                assert row['active_rows'] <= row['physical_rows'] == row['tokens'] * row['requests']
            assert report['actual_target_rows'] == sum(row['active_rows'] for row in report['batches']) + report['restored_target_rows']
            assert report['requested_output_tokens'] == report['generated_tokens'] == 7 and report['live_committed_versions'] == 0
            facts = checks
        elif name.startswith('varlen-'):
            assert raw == [t.read(directory / 'host-report.json'), report]
            assert command == [ready['image']['path'], '--' + backend, plan['fixtures']['varlen']['directory'], '--mtp-varlen-verify']
            assert report['status'] == 'PASS' and report['backend'] == backend and report['mode'] == 'mtp_varlen_verify'
            assert (report['batch_observer_calls'], report['batch_member_target_rows'], report['batch_active_rows'], report['batch_physical_rows']) == (1,[1,3],4,6)
            assert report['ledger_reserved_width'] == 8 and report['ledger_record_storage_checks'] == 24
            assert report['ledger_cold_storage_reused'] is True and report['ledger_host_prepare_withdraw_reprepare'] is True
            assert (report['target_submissions'], report['bounded_target_submissions']) == (11,3)
            for key in ('old_checkpoints_unchanged', 'accepted_prefixes_1_2_3', 'fixed_carrier_reused',
                        'engine_unequal_lengths_one_submission', 'original_q_identity_and_release', 'natural_R1_results_equal'):
                assert report[key] is True, key
            assert report['natural_rng_draws'] == [1,5] and report['final_versions'] == 0
            assert report['quality_claim'] is False and report['performance_claim'] is False and report['synthetic_untrained'] is True
            assert len(report['state_checks']) == 6
            for row in report['state_checks']:
                assert row['boundary_equal'] and row['numerically_equivalent'] and row['exact_next'] == row['bucket_next']
                assert row['payloads_byte_equal'] == (not row['differences'])
                for diff in row['differences']:
                    assert diff['role'] == 3 and diff['nonfinite_differences'] == 0
                    assert math.isfinite(diff['maximum_absolute']) and 0 <= diff['maximum_absolute'] <= 3e-6
                state_rows.append(row)
            storage_checks += report['ledger_record_storage_checks']
            facts = {key:report[key] for key in ('batch_observer_calls', 'batch_member_target_rows', 'batch_active_rows',
                'batch_physical_rows', 'target_submissions', 'bounded_target_submissions', 'ledger_reserved_width',
                'ledger_record_storage_checks', 'ledger_cold_storage_reused', 'ledger_host_prepare_withdraw_reprepare',
                'natural_rng_draws', 'natural_processed_target', 'natural_processed_draft', 'final_versions')}
        else:
            assert name == 'natural-cuda' and raw == [report]
            assert command == [ready['image']['path'], '--cuda', plan['fixtures']['natural']['directory'], '--mtp-natural-relay']
            assert report['status'] == 'PASS' and report['backend'] == 'cuda' and report['case'] == 'mtp-natural-relay'
            assert report['natural_RequestLoop'] is True and report['controlled_acceptance'] is False
            assert report['quality_claim'] is False and report['performance_claim'] is False and report['final_versions'] == 0
            assert (report['resident_capacity'],report['state_slots'],report['hidden_slots']) == (1,5,6)
            assert report['outputs'] == report['output_limit'] == len(report['ids']) == 40
            for key in ('original_ledger_equal','generated_ids_equal','greedy_rng_unchanged','all_sources_expired'):
                assert report[key] is True, key
            for key in ('successor_submissions','successor_publications','pending_pairs_before_A_publish',
                        'deferred_waves','reserved_two_grants'):
                assert report[key] > 0, key
            assert len(report['state_checks']) == 1
            row = report['state_checks'][0]
            assert row['boundary_equal'] and row['numerically_equivalent'] and row['exact_next'] == row['bucket_next']
            assert row['payloads_byte_equal'] == (not row['differences'])
            for diff in row['differences']:
                assert diff['role'] == 3 and diff['nonfinite_differences'] == 0
                assert math.isfinite(diff['maximum_absolute']) and 0 <= diff['maximum_absolute'] <= 3e-6
            state_rows.append(row)
            facts = {key:report[key] for key in ('outputs','ledger_records','resident_capacity','state_slots',
                'hidden_slots','successor_submissions','successor_publications','successor_discards',
                'successor_refusals','accepted_drafts','rejected_drafts','final_versions')}
        runs[name] = dict(process=process, facts=facts, report_member='records/runs/' + name + '/report.json')
    assert len(state_rows) == 13 and storage_checks == 48
    members = {}
    def add(path, name, expected=None):
        path = Path(path); body = path.read_bytes()
        assert path.name.lower() not in ('environment.json','env.json')
        assert path.suffix.lower() not in ('.obj','.lib','.dll','.exe','.pdb','.bin','.safetensors','.gguf')
        if expected: assert (len(body),hashlib.sha256(body).hexdigest()) == (expected['bytes'],expected['sha256'])
        assert name not in members or members[name] == body
        members[name] = body
    for row in frozen:
        path = Path(row['path']); assert t.project(path) and path.is_relative_to(R)
        add(path, 'source/' + path.relative_to(R).as_posix(), row)
    for path in sorted((W / 'before').rglob('*')):
        if path.is_file():
            assert path.suffix.lower() in ('.cc','.h','.md')
            add(path, 'before/' + path.relative_to(W / 'before').as_posix())
    for rel in ('plan.json','source-freeze.json','ready-tiny.json','compile/tiny/compiled.json','compile/tiny/dependencies.json'):
        add(W / rel, 'records/' + rel)
    for directory in (W / 'logs/compile-tiny', W / 'logs/link-tiny', *(W / 'runs' / name for name in CASES)):
        for filename in ('command.json','process.json','stdout.log','stderr.log','report.json','host-report.json','checks.json'):
            path = directory / filename
            if path.is_file(): add(path, 'records/' + path.relative_to(W).as_posix())
    for row in plan['cli_inputs']: add(row['path'], 'fixtures/cli/' + Path(row['path']).name, row)
    for name in ('varlen','natural'):
        for field in ('manifest','prompt'):
            row = plan['fixtures'][name][field]
            add(row['path'], 'fixtures/' + name + '/' + Path(row['path']).name, row)
    for row in plan['helpers']:
        add(row['path'], 'helpers/' + row['sha256'] + '/' + Path(row['path']).name, row)
    add(__file__, 'helpers/package.py')
    for field in ('base','previous_consumer'):
        row = plan[field]; add(row['path'], 'referenced/' + row['sha256'] + '/' + Path(row['path']).name, row)
    manifest = dict(schema='hyle.inference-batch-member-rows.archive.v1',
        source_freeze=t.pin(W / 'source-freeze.json'), frozen_project_files=240, actual_compiled_project_files=226,
        members={name:dict(bytes=len(body),sha256=hashlib.sha256(body).hexdigest()) for name,body in sorted(members.items())})
    members['manifest.json'] = (json.dumps(manifest,ensure_ascii=False,indent=2)+'\n').encode('utf-8')
    archive = DEST.with_suffix('.zip'); DEST.parent.mkdir(parents=True,exist_ok=True)
    with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as output:
        for name,body in sorted(members.items()): output.writestr(name,body)
    with zipfile.ZipFile(archive) as check:
        assert check.testzip() is None and set(check.namelist()) == set(members)
        for name,body in members.items(): assert check.read(name) == body, name
    changed = ('engine/models/qwen35/main.cc','tests/tools/qwen_mtp_varlen_verify_case.h')
    t.save(DEST.with_suffix('.json'), dict(schema='hyle.inference-batch-member-rows.v1',status='PASS_FINITE_MEMBER_ROW_ACCOUNTING',
        product_sources=[source_index[t.key(R / path)] for path in changed], source_freeze=t.pin(W / 'source-freeze.json'),
        frozen_project_files=240, actual_compiled_project_files=226, image=ready['image'], object=compiled['object'],
        CXX=cxx,link=link,native_processes=runs,actual_process_counts=dict(CXX=1,link=1,native=5,failed_native=0),
        SDK=dict(retained_inputs=227,objects=202,libraries=25,SDK_CXX=0,NVCC=0,downloads=0),
        actual_cli=dict(backends=['cpu','cuda'],session_output_limits=[3,4],maximum_drafts=2,active_sequences=2,
            resident_sessions=2,capacity=16,prefix_cache=False,natural_acceptance=True,
            unequal_verify_input_rows=[2,3],max_rows=3,active_rows=5,physical_rows=6,
            all_batch_member_rows_match_original_ledger=True),
        typed_batch_observer=dict(backends=['cpu','cuda'],input_rows=[1,3],max_rows=3,active_rows=4,physical_rows=6),
        natural_K1_regression=dict(backend='cuda',outputs=40,resident_sessions=1,active_sequences=1,
            in_flight_batches=2,state_slots=5,hidden_slots=6,actual_RequestLoop=True,controlled_acceptance=False),
        explicit_state_comparisons=dict(total=13,numerically_equivalent=13,F32_GDN_absolute_budget=3e-6),
        ledger_storage=dict(reserved_width=8,checks_per_backend=24,total_checks=48,cold_buffers_reused=True),
        fixtures=plan['fixtures'],cli_inputs=plan['cli_inputs'],
        limits=['Finite synthetic untrained CPU/CUDA two-member multi-draft consumers; no arbitrary-model quality claim.',
            'Actual natural CLI acceptance is unchanged; separate controlled prefix tests preserve their stated state semantics.',
            'Thirteen complete-state numerical comparisons retain the existing F32 GDN absolute budget 3e-6; byte identity is not required.',
            'The explicitly requested fifth case is a real cached CUDA greedy K1 RequestLoop regression; it does not expand pipeline applicability.',
            'No new throughput comparison, pipeline applicability expansion, downloads or full-goal completion claim.',
            'Frozen source closure has 240 files; actual consumer dependencies contain 226 files. These counts describe different scopes.',
            'Archive contains source, helpers, recipes, receipts, logs, reports and small input manifests. Environment values, tensor payloads and binaries are excluded.'],
        archive=t.pin(archive),archive_members=len(members),crc_and_member_sha256_readback=True))
    print('ARCHIVE WRITTEN',archive.name,t.pin(archive)['bytes'],t.pin(archive)['sha256'])


if __name__ == '__main__': main()
