"""Archive the completed finite pending-append window; no builds or test runs."""
from pathlib import Path
import hashlib
import json
import sys
import xml.etree.ElementTree as ET
import zipfile

W = Path(__file__).resolve().parent
R = W.parents[1]
OUT = R / 'docs/evidence/correctness/inference-pending-append-source-2026-10-27'


def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def pin(path):
    data = path.read_bytes()
    return {'path': path.relative_to(R).as_posix(), 'bytes': len(data),
            'sha256': hashlib.sha256(data).hexdigest()}


def publish():
    summary, ready, plan = (read(W / x) for x in ('summary.json', 'ready.json', 'plan.json'))
    first_link = read(W / 'link/process.json')
    mapping = read(W / 'relink-map.json')
    xml = ET.parse(W / 'results.xml').getroot()
    assert summary['status'] == 'PASS' and summary['process']['exit'] == 0
    assert xml.attrib['tests'] == '16' and xml.attrib['failures'] == '0' and xml.attrib['errors'] == '0'
    assert len(ready['compiled']) == len(plan['units']) == 10
    assert all(x['process']['exit'] == 0 for x in ready['compiled'])
    assert first_link['exit'] == 1120 and ready['link']['exit'] == 0
    assert mapping['compile_count'] == 10 and mapping['extra_compiles'] == 0
    members = []
    for source in summary['sources']:
        relative = Path(source['path']).relative_to(R)
        snapshot = W / 'source' / relative
        actual = pin(snapshot)
        assert actual['sha256'] == source['sha256'] and actual['bytes'] == source['bytes']
        members.append((snapshot, 'source/' + relative.as_posix()))
    roots = ('evidence.py', 'check.py', 'relink.py', 'plan.json', 'compiled.json',
             'ready.json', 'relink-map.json', 'link-inputs.json', 'link-inputs-final.json',
             'build-failure.json', 'summary.json', 'results.xml')
    for name in roots:
        members.append((W / name, 'records/' + name))
    for unit in plan['units']:
        name = unit['name']
        source = read(W / 'compile' / name / 'dependencies.json')['Data']['Source']
        assert str(Path(source)).lower() == str(Path(unit['source']['path'])).lower()
        for leaf in ('command.json', 'dependencies.json', 'process.json', 'stdout.log', 'stderr.log'):
            relative = 'compile/' + name + '/' + leaf
            members.append((W / relative, 'records/' + relative))
    for name in ('link', 'link-final', 'run'):
        for leaf in ('command.json', 'process.json', 'stdout.log', 'stderr.log'):
            relative = name + '/' + leaf
            members.append((W / relative, 'records/' + relative))
    runtime = Path(ready['runtime']['path'])
    assert pin(runtime)['sha256'] == ready['runtime']['sha256']
    members.append((runtime, 'records/runtime.json'))
    baseline = Path(plan['baseline']['path'])
    assert pin(baseline)['sha256'] == plan['baseline']['sha256']
    old, new = read(baseline), read(W / 'link-inputs-final.json')
    retained = len({(x['path'].lower(), x['sha256']) for x in old} &
                   {(x['path'].lower(), x['sha256']) for x in new})
    assert len(new) - retained == 10
    archive = OUT.with_suffix('.zip')
    manifest = []
    with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as target:
        for path, name in members:
            assert path.suffix in {'.py', '.h', '.cc', '.json', '.log', '.xml'}
            row = pin(path)
            target.writestr(name, path.read_bytes())
            manifest.append({'member': name, 'bytes': row['bytes'], 'sha256': row['sha256']})
    with zipfile.ZipFile(archive) as target:
        assert target.namelist() == [x['member'] for x in manifest]
        for row in manifest:
            data = target.read(row['member'])
            assert len(data) == row['bytes'] and hashlib.sha256(data).hexdigest() == row['sha256']
    assert archive.stat().st_size < 2_000_000
    prior = R / 'docs/evidence/correctness/inference-paged-owned-source-2026-10-27.json'
    report = {
        'date': '2026-10-27', 'status': 'PASS',
        'scope': 'Real shared-Queue CUDA A-to-B PagedAppend continuation with exact COW or empty-read page-boundary dependence; finite common Source regressions.',
        'environment': {'platform': 'Windows', 'gpu': 'NVIDIA GeForce RTX 4070',
            'compute_capability': '8.9', 'evidence': 'Actual run/stderr.log, without a new hardware query or frequency/exclusivity claim.'},
        'build': {'distinct_CXX_TUs': 10, 'compile_attempts': 10, 'compile_failures': 0,
            'link_attempts': 2, 'successful_links': 1, 'runnable_images': 1,
            'test_processes': 1, 'NVCC_TUs': 0, 'SDK_rebuilds': 0, 'downloads': 0,
            'baseline_inputs': len(old), 'final_inputs': len(new), 'retained_inputs': retained,
            'replaced_inputs': len(new) - retained, 'compiled': ready['compiled'],
            'first_link': first_link, 'final_link': ready['link'], 'image': ready['image'],
            'closure_correction': 'Initial recipe confused a slots.cc object directory with slots_region.cc. The failed link reported duplicate and missing definitions and produced no runnable image. Compiler Data.Source located the exact original slots_region object; only that link mapping was corrected. All ten successful compiled objects were reused without recompilation or source changes.',
            'mapping_receipt': pin(W / 'relink-map.json')},
        'run': {**summary['process'], 'gtest_timestamp': xml.attrib['timestamp'],
            'tests': 16, 'passed': 16, 'failed': 0, 'skipped': 0,
            'cases': [x['classname'] + '.' + x['name'] for x in summary['tests']]},
        'implementation_scope': [
            'One original SubmissionSource terminal supports effect-only continuations with no pending tensor input. Source-required registration is retained even when the real COW read list is empty.',
            'ResourceFullRange.readable_bytes bounds full-writer tickets to genuinely written prefixes. Effect admission selects only original ready/full/append permissions covering the actual registered read ranges; an empty read list grants none.',
            'The successor owns fresh targets and retains the predecessor Source metadata owner, not its writer/tail or returned transaction pointer. Final ready inheritance clones real bounded guards from the successfully published predecessor cache.'
        ],
        'checked': [
            'COW variant: original three-row snapshot, A appends two rows to five, B copies A partial tail to its distinct page and appends one row to six. Exact BF16 row values, original snapshot and A prefix remain correct.',
            'Page-boundary variant: A appends three rows to six, B adds one row to a new page with no COW effect reads. It still reports one Source/device wait and zero host waits and rejects ordinary submit.',
            'Both variants use actual pending A, one original Queue and a controlled pending B. A retires and detaches; its returned transaction is published while B stays pending. That transaction and local A frame are destroyed before B ready inheritance.',
            'COW source coverage accepts the original 128 bytes and rejects 129 bytes inside the same physical page. A separately malformed effect descriptor is rejected before the unchanged complete bundle binds successfully.',
            'COW A tail reservation is unavailable while its admitted B reader remains active, then succeeds and rolls back after B retirement.',
            'The same final process also passes two nominated-effect boundary checks, ten token/Store/Hybrid Source cases and the retained explicit/private metadata attention cases.'
        ],
        'limitations': [
            'The finite tests exercise selective and empty read paths; they do not instrument every native lease counter or every possible permission combination.',
            'No B-to-C continuation chain, indexed-state path, complete model execution/task quality, performance result, other platform or new GPU/driver-fault test is claimed.'
        ],
        'failures': {'first_link_setup_failure_preserved': True,
            'failed_test_processes': 0, 'expected_negative_checks_are_not_test_failures': True,
            'first_failed_link_had_no_runnable_image': True},
        'sources': summary['sources'],
        'reuse': {'prior_receipt': pin(prior), 'baseline_link_inputs': pin(baseline),
            'boundary': 'Native kernels, vendor libraries and other cached Compute/SDK objects are reused. Ten CXX objects replace ten exact source-matched inputs. No SDK/native/model rebuild, model download or new performance window.'},
        'archive': {**pin(archive), 'members': manifest},
    }
    OUT.with_suffix('.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({'summary': pin(OUT.with_suffix('.json')), 'archive': pin(archive),
                      'members': len(manifest)}, indent=2))


if __name__ == '__main__':
    if sys.argv[1:] != ['publish']:
        raise SystemExit('usage: evidence.py publish (packages existing records only)')
    publish()
