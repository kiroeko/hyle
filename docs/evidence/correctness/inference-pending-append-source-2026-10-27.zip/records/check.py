from pathlib import Path
import importlib.util
import sys
import traceback
import xml.etree.ElementTree as ET

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = W.parents[1]
BASE = R / '.scratch/inference-paged-owned-source-20261027'
spec = importlib.util.spec_from_file_location('owned_recipe', BASE / 'check.py')
q = importlib.util.module_from_spec(spec)
spec.loader.exec_module(q)
b, h = q.p.b, q.p.h
SPECS = [
    ('resources','src/graph/resources.cc','/compile/resources/'),
    ('inputs','src/graph/input_sources.cc','/compile/inputs/'),
    ('submission','src/graph/submission.cc','/compile/graph-submission/'),
    ('progress','src/graph_progress/progress.cc','/graph_progress--progress_cc/'),
    ('slots','src/graph/slots_region.cc','/compile/slots/'),
    ('batch','src/graph_batch/batch.cc','/compile/batch/'),
    ('append','src/graph_batch/paged_append.cc','/compile/append/'),
    ('graph-test','tests/graph/output_source_cuda_test.cc','/compile/graph-test/'),
    ('paged-test','tests/graph_batch/paged_append_source_test.cc','/compile/paged-test/'),
    ('region-test','tests/graph/region_provider_test.cc','/compile2/region-test/'),
]
EXTRA = ['include/hyle/graph/detail/input_source.h','include/hyle/graph/detail/output_source.h',
    'include/hyle/graph/detail/region_access.h','include/hyle/graph/detail/resource_source.h',
    'include/hyle/graph/detail/paged_append_source.h','include/hyle/graph/batch.h',
    'src/graph/input_sources.h','src/graph_batch/paged_append.h']


def environment(command):
    env = h.discover_environment(compiler='msvc', cache={
        'CMAKE_C_COMPILER': command[0], 'CMAKE_CXX_COMPILER': command[0],
        'CMAKE_GENERATOR': 'Ninja'}, backends=()).env
    env['PATH'] = b.read(Path(b.read(BASE / 'ready-final.json')['runtime']['path']))['PATH']
    return env


def freeze():
    assert not (W / 'plan.json').exists()
    inputs = b.read(BASE / 'link-inputs-final.json')
    units = []
    for name, source, needle in SPECS:
        old = [x for x in inputs if needle in x['path'].replace('\\','/')]
        assert len(old) == 1, (name, old)
        out = W / 'compile' / name
        argv = b.read(Path(old[0]['path']).parent / 'command.json')['command']
        command = []
        for i, arg in enumerate(argv):
            if i and argv[i-1].lower() == '/sourcedependencies':
                arg = str(out / 'dependencies.json')
            elif arg.lower().startswith('/fo'):
                arg = '/Fo' + str(out / 'unit.obj')
            elif arg.lower().startswith('/fd'):
                arg = '/Fd' + str(out / 'unit.pdb')
            elif arg.lower().endswith('.cc'):
                arg = str(R / source)
            command.append(arg)
        units.append({'name': name, 'source': b.pin(R / source), 'old': old[0], 'command': command})
    sources = [b.pin(R / x) for x in [*(x[1] for x in SPECS), *EXTRA]]
    for row in sources:
        dest = W / 'source' / Path(row['path']).relative_to(R)
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_bytes(Path(row['path']).read_bytes())
    tests = b.read(BASE / 'selection.json')['tests'] + [
        'GraphPagedAppendSourceCuda.PendingAppendCopiesOriginalTailAndInheritsPublishedPages',
        'GraphPagedAppendSourceCuda.PageBoundaryAppendRetainsSourceWithoutCowReads',
        'GraphRouteBoundary.ProjectedWriteRegionKeepsOneOriginalNominatedEffect',
        'GraphRouteBoundary.ProjectedWriteRejectsASecondRegionEffectBeforeBinding']
    assert len(set(tests)) == len(tests)
    b.save(W / 'plan.json', {'units': units, 'sources': sources, 'tests': tests,
        'baseline': b.pin(BASE / 'link-inputs-final.json'), 'input_count': len(inputs),
        'scope': 'Original effect-only shared CUDA A->B pending previous append/COW and page-boundary no-copy predecessor; finite Source/resource regression. No full model overlap/performance.'})
    print('FROZEN', len(units), 'CXX,', len(tests), 'tests', flush=True)


def check(plan):
    for row in plan['sources']:
        b.exact(row)


def build():
    plan = b.read(W / 'plan.json')
    check(plan)
    env = environment(plan['units'][0]['command'])
    inputs = b.read(BASE / 'link-inputs-final.json')
    for row in inputs:
        b.exact(row)
    compiled, replacements = [], {}
    for unit in plan['units']:
        out = W / 'compile' / unit['name']
        assert not out.exists()
        process = h.execute(unit['command'], env, out, timeout=180)
        check(plan)
        obj = b.pin(out / 'unit.obj')
        replacements[b.key(unit['old']['path'])] = obj
        compiled.append({'name': unit['name'], 'object': obj, 'process': process})
        b.save(W / 'compiled.json', compiled)
    linked = [replacements.get(b.key(x['path']), x) for x in inputs]
    b.save(W / 'link-inputs.json', linked)
    image = W / 'bin/pending-append-test.exe'
    image.parent.mkdir(parents=True, exist_ok=True)
    command = []
    for arg in b.read(BASE / 'link-final/command.json')['command']:
        if b.key(arg) in replacements:
            arg = replacements[b.key(arg)]['path']
        elif arg.lower().startswith('/out:'):
            arg = '/OUT:' + str(image)
        elif arg.lower().startswith('/pdb:'):
            arg = '/PDB:' + str(image.with_suffix('.pdb'))
        elif arg.lower().startswith('/implib:'):
            arg = '/IMPLIB:' + str(image.with_suffix('.lib'))
        command.append(arg)
    link = h.execute(command, env, W / 'link', timeout=120)
    b.save(W / 'ready.json', {'image': b.pin(image), 'compiled': compiled, 'link': link,
        'inputs': b.pin(W / 'link-inputs.json'), 'plan': b.pin(W / 'plan.json'),
        'runtime': b.read(BASE / 'ready-final.json')['runtime']})
    print('READY', flush=True)


def run():
    plan, ready = b.read(W / 'plan.json'), b.read(W / 'ready.json')
    check(plan)
    b.exact(ready['image'])
    xml = W / 'results.xml'
    process = h.execute([ready['image']['path'], '--gtest_color=no',
        '--gtest_filter=' + ':'.join(plan['tests']), '--gtest_output=xml:' + str(xml)],
        environment(plan['units'][0]['command']), W / 'run', timeout=90)
    cases = ET.parse(xml).getroot().findall('./testsuite/testcase')
    actual = {x.attrib['classname'] + '.' + x.attrib['name'] for x in cases}
    ok = actual == set(plan['tests']) and all(x.attrib.get('status') == 'run' and
        not x.findall('failure') and not x.findall('error') and not x.findall('skipped') for x in cases)
    b.save(W / 'summary.json', {'status': 'PASS' if ok else 'FAIL', 'process': process,
        'tests': [x.attrib for x in cases], 'image': ready['image'], 'sources': plan['sources']})
    assert ok
    print('PASS', len(cases), flush=True)


if __name__ == '__main__':
    try:
        {'freeze': freeze, 'build': build, 'run': run}[sys.argv[1]]()
    except Exception:
        b.save(W / (sys.argv[1] + '-failure.json'), {'error': traceback.format_exc()})
        raise
