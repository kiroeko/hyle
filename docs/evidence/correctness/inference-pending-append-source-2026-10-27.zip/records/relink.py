from pathlib import Path
import importlib.util
import sys

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('pending_recipe', W / 'check.py')
q = importlib.util.module_from_spec(spec)
spec.loader.exec_module(q)
b, h = q.b, q.h
plan = b.read(W / 'plan.json')
q.check(plan)
compiled = b.read(W / 'compiled.json')
assert len(compiled) == len(plan['units']) == 10
baseline = b.read(q.BASE / 'link-inputs-final.json')
replacements, corrections = {}, []
for unit, built in zip(plan['units'], compiled):
    assert unit['name'] == built['name']
    b.exact(built['object'])
    actual = b.read(Path(built['object']['path']).parent / 'dependencies.json')['Data']['Source']
    assert b.key(actual) == b.key(unit['source']['path'])
    matches = []
    for row in baseline:
        dep = Path(row['path']).parent / 'dependencies.json'
        if dep.is_file():
            old_source = b.read(dep).get('Data', {}).get('Source')
            if old_source and b.key(old_source) == b.key(actual):
                matches.append(row)
    assert len(matches) == 1, (unit['name'], matches)
    replacements[b.key(matches[0]['path'])] = built['object']
    if b.key(matches[0]['path']) != b.key(unit['old']['path']):
        corrections.append({'unit': unit['name'], 'compiled_source': actual,
            'initial_wrong_link_target': unit['old'], 'actual_replaced_object': matches[0],
            'reason': 'The directory name slots contains slots.cc, not slots_region.cc; use compiler Data.Source rather than directory-name inference.'})
assert len(corrections) == 1 and corrections[0]['unit'] == 'slots'
b.save(W / 'relink-map.json', {'corrections': corrections,
    'compile_count': 10, 'extra_compiles': 0, 'source_mapping': 'Compiler Data.Source for every rebuilt object; unique original source match.'})
linked = [replacements.get(b.key(row['path']), row) for row in baseline]
for row in linked:
    b.exact(row)
b.save(W / 'link-inputs-final.json', linked)
image = W / 'bin/pending-append-test.exe'
command = []
for arg in b.read(q.BASE / 'link-final/command.json')['command']:
    if b.key(arg) in replacements:
        arg = replacements[b.key(arg)]['path']
    elif arg.lower().startswith('/out:'):
        arg = '/OUT:' + str(image)
    elif arg.lower().startswith('/pdb:'):
        arg = '/PDB:' + str(image.with_suffix('.pdb'))
    elif arg.lower().startswith('/implib:'):
        arg = '/IMPLIB:' + str(image.with_suffix('.lib'))
    command.append(arg)
link = h.execute(command, q.environment(plan['units'][0]['command']), W / 'link-final', timeout=120)
b.save(W / 'ready.json', {'image': b.pin(image), 'compiled': compiled, 'link': link,
    'inputs': b.pin(W / 'link-inputs-final.json'), 'plan': b.pin(W / 'plan.json'),
    'relink_map': b.pin(W / 'relink-map.json'),
    'runtime': b.read(q.BASE / 'ready-final.json')['runtime']})
print('READY, reused all 10 compiled units', flush=True)
