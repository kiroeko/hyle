from pathlib import Path
import hashlib,json,zipfile
R=Path.cwd();W=Path(__file__).resolve().parent
B=R/'.scratch/qwen-multi-draft-20261024/geometry-cuda-check2'
def load(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def ident(p):return dict(path=p.relative_to(R).as_posix(),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
files={};cases=[]
for source,codec,roles in [('Q01','GPTQ',785),('Q03','NVFP4',893)]:
    result=load(W/source/'result.json');report=result['report']
    assert result['status']=='PASS' and result['process']['exit']==0
    original=R/'.scratch/qwen35-unsloth-mtp-20261024/geometry-v2-check'/source
    rows=(original/'weights.tsv').read_text(encoding='utf-8').splitlines()[3:]
    names=[line.split('\t',1)[0] for line in rows if line]
    assert len(names)==len(set(names))==roles
    counts=dict(text=sum(not name.startswith('mtp.') for name in names),
                mtp=sum(name.startswith('mtp.') for name in names))
    cases.append(dict(source=source,codec=codec,source_id=report['source_id'],exit=0,
        physical_roles=roles,physical_role_counts_from_actual_prepared_manifest=counts,
        frozen_report_counts=dict(text=report['text_tensors'],mtp=report['mtp_tensors']),
        generated_ids=report['generated_ids'],proposals=[x['proposals']for x in report['rounds']],
        consumed_drafts=report['consumed_drafts'],sampling_draw_cursor=report['sampling_draw_cursor'],
        target_rows=report['actual_target_rows'],draft_rows=report['actual_draft_rows'],
        original_device_weight_bytes=report['original_device_weight_bytes'],cache_peak_requested_bytes=report['cache_peak_requested_bytes']))
    for p in (W/source).iterdir():
        if p.is_file():files['cases/'+source+'/'+p.name]=p
    for name in ['weights.tsv','prompt.ids','input.json']:files['inputs/'+source+'/'+name]=original/name
for p in (B/'source').rglob('*'):
    if p.is_file()and p.suffix in ('.h','.cc'):files['consumer-source/'+p.relative_to(B/'source').as_posix()]=p
for name in ['identity.json','sources.json']:files['consumer/'+name]=B/name
for name in ['run.py','publish.py']:files['commands/'+name]=W/name
base='qwen35-original-quantized-mtp-k4-random-2026-10-24';dest=R/'docs/evidence/correctness'
archive=dest/(base+'-logs.zip');record=dest/(base+'.json');assert not archive.exists()and not record.exists()
manifest=[dict(archive_path=k,**ident(p))for k,p in sorted(files.items())]
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=9)as z:
    for k,p in sorted(files.items()):z.write(p,k)
    z.writestr('manifest.json',json.dumps(manifest,indent=2)+'\n')
with zipfile.ZipFile(archive)as z:
    assert z.testzip()is None
    for x in manifest:assert hashlib.sha256(z.read(x['archive_path'])).hexdigest()==x['sha256']
result=dict(date='2026-10-24',status='PASS',scope='One complete original-model CUDA random K4 journey per existing GPTQ/NVFP4 identity, extending the existing ordinary/K1 source evidence.',
    model='Qwen3.5-2B',prompt_tokens=154,capacity=256,maximum_output_tokens=6,
    policy=dict(temperature=1,top_k=8,top_p=.9,seed=123),cache_requested_byte_limit=268435456,
    cases=cases,consumer=ident(B/'recursive-probe.exe'),fresh_TUs=0,SDK_builds=0,HTTP=0,weight_copies=0,
    limits=['Finite original-source functional execution, not task-quality or inference performance comparison.',
        'Do not require equal output IDs across different original quantized sources or the BF16 checkpoint.',
        'Frozen consumer predates the model-independent sampler header relocation; the mathematical nodes/policy are the same.',
        'Frozen consumer hardcodes the obsolete BF16 tensor counts 320/15 in reports. Actual physical counts come from the archived prepared manifest; current product reports now count the selected loaded physical roles. No raw report is rewritten.',
        'Known cache and workspace do not certify physical peak VRAM or native-private allocations.',
        'Shared rejection/state correctness and multi-user/checkpoint algorithms use their separate existing evidence, not a Cartesian rerun here.'],
    archive=ident(archive),archive_members=len(manifest)+1)
record.write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(record=ident(record),archive=ident(archive),cases=len(cases))))
