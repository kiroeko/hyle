"""One new multi-draft random journey per already acquired complete quantized source."""
from pathlib import Path
import argparse, hashlib, json, os, subprocess, sys, time
R=Path.cwd(); B=R/'.scratch/qwen-multi-draft-20261024/geometry-cuda-check2'
W=Path(__file__).resolve().parent
def load(p): return json.loads(p.read_text(encoding='utf-8-sig'))
def ident(p):
    return dict(path=p.relative_to(R).as_posix(), bytes=p.stat().st_size,
                sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def save(p,v): p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8')
parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('source',choices=['Q01','Q03']);a=parser.parse_args()
I=R/'.scratch/qwen35-unsloth-mtp-20261024/geometry-v2-check'/a.source
assert (I/'weights.tsv').read_text(encoding='utf-8-sig').splitlines()[0]=='HYLE_QWEN_ROLE_FILES_V2'
image=B/'recursive-probe.exe'; image_id=ident(image)
assert image_id['sha256']==load(B/'identity.json')['image_sha256']=='0286bc8733dfdbc061f41cc7f6730e9e62657af3bd3d3c2ecec545c0418f9c32'
folder=W/a.source;folder.mkdir(exist_ok=False)
command=[str(image),'--inputs',str(I),'--capacity','256','--steps','6','--cache-bytes','268435456',
    '--prefix-cache','off','--replay','commands','--mtp','on','--mtp-max-drafts','4',
    '--sampling','random','--top-k','8','--top-p','.9','--seed','123']
ready=load(R/'.scratch/qwen35-unsloth-mtp-20261024/engine-check/ready-cuda.json')
env=dict(os.environ,PATH=str(B)+os.pathsep+ready['PATH'])
record=dict(command=command, image=image_id, source_snapshot=ident(B/'sources.json'),
    manifest=ident(I/'weights.tsv'), prompt=ident(I/'prompt.ids'), preparation=ident(I/'input.json'),
    scope='One finite original complete quantized model CUDA K4 random journey; no task-quality or performance claim.',
    fresh_TUs=0, SDK_builds=0, HTTP=0,started=time.time())
save(folder/'command.json',record)
with (folder/'stdout.log').open('wb')as out,(folder/'stderr.log').open('wb')as err:
    p=subprocess.run(command,cwd=R,env=env,stdout=out,stderr=err,timeout=180,creationflags=subprocess.CREATE_NO_WINDOW)
record.update(exit=p.returncode,ended=time.time());save(folder/'process.json',record)
if p.returncode:
    print((folder/'stderr.log').read_text(encoding='utf-8',errors='replace')[-3000:])
    raise SystemExit(p.returncode)
report=load(folder/'stdout.log')
assert report['backend']=='cuda' and report['mtp'] and report['sampling']=='random' and report['mtp_max_drafts']==4
assert report['prefix_decision_graph_calls']>0 and report['sampling_draw_cursor']>0
assert report['cache_peak_requested_bytes']<=report['cache_requested_byte_limit']==268435456
assert any(x['proposals']==4 for x in report['rounds'])
save(folder/'result.json',dict(status='PASS',process=record,report=report))
print(json.dumps(dict(source=a.source,status='PASS',generated_ids=report['generated_ids'],
    proposals=[x['proposals']for x in report['rounds']],consumed_drafts=report['consumed_drafts'],
    sampling_draw_cursor=report['sampling_draw_cursor'],cache_peak_requested_bytes=report['cache_peak_requested_bytes'])))
