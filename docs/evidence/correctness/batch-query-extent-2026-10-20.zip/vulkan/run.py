"""Run the frozen actual Vulkan native ragged journey with the retained SDK."""
import importlib.util
import shutil
import sys
import xml.etree.ElementTree as ET
from pathlib import Path
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('extent_vulkan_build',S/'build.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
b,c=m.b,m.c
O=S/'checks'
plan=c.read(O/'plan.json');link=c.read(O/'link-plan.json')
assert c.read(O/'summary.json')['passed']
for identity in plan['frozen']: assert b.same(identity),identity['path']
for identity in link['inputs']: assert b.same(identity),identity['path']
image=c.read(O/'image.json');assert b.same(image)
env,runtime=b.environment(link['command'],[x['path'] for x in link['inputs']],O)
query=shutil.which('nvidia-smi')
if query:
    c.execute('hardware',[query,'--query-gpu=name,uuid,driver_version,memory.total','--format=csv,noheader'],env,O)
xml=O/'native-ragged.xml'
command=[image['path'],'--gtest_filter=NativeRaggedAttentionGraph.*','--gtest_output=xml:'+str(xml)]
error=None
try: c.execute('native-ragged',command,env,O)
except Exception as failure: error=repr(failure)
root=ET.parse(xml).getroot() if xml.exists() else None
cases=[] if root is None else [dict(suite=s.get('name'),name=t.get('name'),
    failures=len(t.findall('failure')),skipped=len(t.findall('skipped')))
    for s in root.findall('testsuite') for t in s.findall('testcase')]
summary=dict(passed=not error and len(cases)==3 and all(not x['failures'] and not x['skipped'] for x in cases),
    error=error,cases=cases,case_count=len(cases),
    failure_count=sum(x['failures'] for x in cases),skip_count=sum(x['skipped'] for x in cases),
    image=image,command=command,SDK_rebuilt=False,native_compiles=0,
    host_compiles=plan['host_TUs'],current_owners_reused=len(plan['reused']),
    source_freeze=[x for x in plan['frozen'] if x['path'].endswith(('source-freeze.json','freeze.json'))])
for identity in plan['frozen']: assert b.same(identity),identity['path']
c.save(O/'test-summary.json',summary)
print(summary,flush=True)
assert summary['passed'],summary
