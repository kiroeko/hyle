"""Archive-sized source/dependency proof; do not duplicate binary caches."""
import difflib
import hashlib
import importlib.util
import sys
from pathlib import Path
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('extent_vulkan_final_helpers',S/'build.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
b,c=m.b,m.c
O=S/'checks';plan=c.read(O/'plan.json')
normalizations=[];owners=[]
def check_dependencies(receipt):
    exceptions=[]
    for before in receipt.get('dependencies',[]):
        if m.h.same_identity(before):continue
        assert m.source_equivalent(before),before['path']
        after=b.identity(before['path'])
        data=Path(before['path']).read_bytes().replace(b'\r\n',b'\n')
        crlf=data.replace(b'\n',b'\r\n')
        pure_newline=before['sha256'] in {hashlib.sha256(x).hexdigest() for x in (data,crlf)}
        item=dict(before=before,current=after,normalized_lf_sha256=hashlib.sha256(data).hexdigest(),
            proof='Only LF/CRLF bytes differ' if pure_newline else 'Exact parent-authorized default-empty canonical{} initializer')
        exceptions.append(item)
    return exceptions
for row in plan['compile']:
    receipt=c.read(O/(row['tag']+'-identity.json'))
    assert b.same(receipt['object'])
    exceptions=check_dependencies(receipt)
    normalizations.extend(exceptions)
    owners.append(dict(source=receipt['source'],object=receipt['object'],
        receipt=b.identity(O/(row['tag']+'-identity.json')),
        dependencies=len(receipt['dependencies']),all_declared_dependencies_current_or_exact_equivalent=True,
        equivalent_differences=exceptions))
for row in plan['reused']:
    receipt=row['chosen']['owner'];assert b.same(row['chosen']['object'])
    exceptions=[]
    for before in receipt.get('dependencies',[]):
        if m.h.same_identity(before):continue
        if m.source_equivalent(before):continue
        # Some unchanged old owners see only additive public declarations /
        # comments. The build planner records that exact retained admission.
        assert Path(before['path']).name in ('batch_ops.h','batch_layout.h','batch_graph_access.h','native_batch_regions.h'),before
        exceptions.append(dict(before=before,current=b.identity(before['path']),reason='Comments/additive non-inline declaration only; common.diff preserves exact source change.'))
    owners.append(dict(source=receipt.get('source'),object=row['chosen']['object'],
        retained_receipt=receipt.get('recipe'),normalized_command=row['normalized_command'],
        all_code_generation_flags_macros_and_ordered_include_roots_equal=True,
        additive_declaration_differences=exceptions))
for row in plan['supplemental_current_owners']:
    assert b.same(row['object']);assert all(m.h.same_identity(d) for d in row['dependencies'])
    owners.append(dict(source=row['source'],object=row['object'],all_declared_dependencies_current=True,
        command=row.get('command'),reason='Retained current canonical native driver or parent-validated memory-resource owner.'))
c.save(S/'source-normalization-proof.json',dict(exceptions=normalizations,
    guard_failure=dict(reason='A strict raw source-hash guard observed concurrent CRLF-to-LF normalization; no compiler or GPU ran in that attempt.',product_semantic_changes=False),
    parent_authorized_default_initializer_proof=dict(
        before=b.identity(m.STAGE/'delegated/graph-pending-copy-init/before.cc'),
        after=b.identity(m.STAGE/'delegated/graph-pending-copy-init/after.cc'))))
result=c.read(O/'test-summary.json');assert result['passed']
first=c.read(S/'first-native-owner-missing/test-summary.json')
assert not first['passed'] and first['failure_count']==3
before_link=c.read(S/'first-native-owner-missing/link-plan.json')
after_link=c.read(O/'link-plan.json')
old={c.key(x['path']):x for x in before_link['inputs']}
new={c.key(x['path']):x for x in after_link['inputs']}
assert not(old.keys()-new.keys())
added=[new[k] for k in new.keys()-old.keys()]
assert len(added)==1 and added[0]['sha256']=='fdf1b1bdf5231239a748cf6dcc3dbeee14c6f25cd4a04496e821b6496bc1524b'
assert all(old[k]==new[k] for k in old)
closure=dict(passed=True,actual_device=(O/'hardware.stdout.log').read_text().strip(),
    tests=result,compiled_host_TUs=25,new_native_compiler_invocations=0,SDK_or_shader_rebuilt=False,
    binary_cache_owners_not_copied=True,current_owners=owners,
    first_attempt=dict(result=first,reason='The NVFP4 retained link predated the canonical explicit Vulkan driver owner; it used the old library native host. The same compiled Hyle/test objects pass after adding the existing manifest-matched current native owner.',
        first_link=b.identity(S/'first-native-owner-missing/link-plan.json'),
        exact_link_input_difference=added,all_original_link_inputs_byte_identical=True),
    current_native_manifest_proof=b.identity(S/'native-closure-proof.json'),
    normalization_proof=b.identity(S/'source-normalization-proof.json'),
    limitations=['No throughput conclusion','No other Vulkan device/platform/shape domain certification','No CPU/CUDA inactive-tail zero guarantee'],
    product_or_test_edits_in_this_validation=False,root_test_ps1_edited=False)
c.save(S/'final-closure.json',closure)
print('FINAL',b.identity(S/'final-closure.json'),flush=True)
