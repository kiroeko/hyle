"""Current Hyle Vulkan owners only; reuse the existing SDK/native library closure."""
import argparse
import concurrent.futures
import importlib.util
from pathlib import Path
import sys
import hashlib
sys.dont_write_bytecode = True
S=Path(__file__).resolve().parent; STAGE=S.parent; A=STAGE.parent; ROOT=A.parents[1]
spec=importlib.util.spec_from_file_location('extent_vk_build_helpers',A/'grouped-shared-activation/build_host.py')
h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
b,c=h.b,h.c

def source_equivalent(identity):
    if h.same_identity(identity):return True
    path=Path(identity['path'])
    if path.suffix.lower() not in ('.cc','.h','.cpp'):return False
    data=path.read_bytes().replace(b'\r\n',b'\n')
    candidates=[data,data.replace(b'\n',b'\r\n')]
    if identity.get('sha256') in {hashlib.sha256(x).hexdigest() for x in candidates}:return True
    # The independent Apple strict-warning correction names exactly this one
    # empty Ref initializer. Parent explicitly authorized the equivalent owner.
    if path==ROOT/'src/graph/executable.cc':
        before=(STAGE/'delegated/graph-pending-copy-init/before.cc').read_bytes().replace(b'\r\n',b'\n')
        after=(STAGE/'delegated/graph-pending-copy-init/after.cc').read_bytes().replace(b'\r\n',b'\n')
        assert before.replace(b'util::Ref<detail::CanonicalConstantState> canonical;',b'util::Ref<detail::CanonicalConstantState> canonical{};')==after
        if data==after and identity.get('sha256') in {hashlib.sha256(x).hexdigest() for x in (before,before.replace(b'\n',b'\r\n'))}:return True
    return False

def canonical(command,source):
    # Preserve every code-generation option, macro, and ordered include root.
    # Only output/dependency filenames and diagnostic switches do not affect ABI.
    values=b.host_command(command,source,'comparison',S)
    result=[];skip=False
    for arg in values:
        if skip:skip=False;continue
        low=arg.lower()
        if low=='/sourcedependencies':skip=True;continue
        if low.startswith(('/fo','/fd','/wd')) or low in ('/w4','/wx','/showincludes'):
            continue
        if low.endswith(('.cc','.cpp')):continue
        normalized=arg
        for prefix,common in (('-external:I','/external:I'),('/external:I','/external:I'),('-I','/I'),('/I','/I'),('/FI','/FI')):
            if low.startswith(prefix.lower()) and len(arg)>len(prefix):
                normalized=common.lower()+c.key(Path(arg[len(prefix):]).resolve());break
        if Path(arg).is_absolute():normalized=c.key(Path(arg).resolve())
        result.append(normalized)
    return result

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--build',action='store_true');parser.add_argument('--resume',action='store_true');args=parser.parse_args()
    inv=c.read(S/'inventory.json');base=c.read(inv['base_path'])
    out=S/'checks';out.mkdir(exist_ok=True);(out/'tmp').mkdir(exist_ok=True)
    rows=[];replace={};reuse=[];drop=[];unchanged=[]
    # These headers exactly match the frozen pre-change versions in this base.
    # Changes are comments/additive overload; existing layouts/inline code stay.
    additive={c.key(ROOT/p) for p in ('include/hyle/compute/batch_ops.h','include/hyle/compute/batch_layout.h',
        'include/hyle/compute/detail/batch_graph_access.h','src/graph_batch/native_batch_regions.h')}
    # Only declaration/definition and the actual ragged caller use the changed
    # private method signature. Other static methods/class layout are unchanged.
    safe_declaration=c.key(ROOT/'include/hyle/compute/detail/vulkan_batch_access.h')
    critical={c.key(ROOT/p) for p in ('src/graph/plan_state.h','src/graph/constant_artifact.h','src/graph/resource_episode.h')}
    required={c.key(ROOT/p) for p in ('src/compute_batch/batch_layout.cc','src/compute_batch/batch_execution.cc',
        'src/graph_batch/batch.cc','src/graph_batch/native_batch_regions.cc',
        'src/compute_route_vulkan/vulkan_batch.cc','src/graph_route_vulkan/native_ragged_region.cc')}
    for entry in inv['owners']:
        owner=entry['owner'];source=Path(owner['source_path']);key=c.key(source)
        if source.is_relative_to(ROOT/'tests'):
            drop.append(dict(object=entry['object'],source=str(source),reason='Unrelated previous NVFP4 fixture; link only the requested native ragged owner.'));continue
        changed=[v for v in entry['changes'] if v['kind']=='source' or c.key(v['after']['path']) not in additive|{safe_declaration}]
        refresh=key in required or bool(changed)
        if not refresh:
            unchanged.append(dict(object=entry['object'],source=str(source),ignored_additive_header_changes=entry['changes']));continue
        matches=[]
        for candidate in entry['current_alternatives']:
            receipt=candidate['owner'];sid=receipt.get('source')
            if not isinstance(sid,dict) or not sid.get('sha256') or not source_equivalent(sid):continue
            if not b.same(candidate['object']):continue
            if canonical(owner['command'],source)!=canonical(receipt['command'],source):continue
            # Reuse allows only the known additive/comment headers above to
            # differ. Every other declared source/header must be current.
            stale=[d for d in receipt.get('dependencies',[]) if not source_equivalent(d) and c.key(d['path']) not in additive]
            if stale:continue
            matches.append(candidate)
        if matches:
            chosen=matches[0];replace[c.key(entry['object']['path'])]=chosen['object']
            reuse.append(dict(source=str(source),old=entry['object'],chosen=chosen,
                normalized_command=canonical(owner['command'],source),normalization='Output/dependency paths and diagnostics only; ordered includes, macro and codegen flags retained.'))
            continue
        tag=source.parent.name+'-'+source.stem
        command=b.host_command(owner['command'],source,tag,out)
        rows.append(dict(tag=tag,source=b.identity(source),old_object=entry['object'],command=command,object=str(out/(tag+'.obj')),
                         reason=changed,critical_header_member=any(c.key(d['path']) in critical for d in owner.get('dependencies',[]))))
    recipe_path=A/'native-ragged-graph/validation/windows/compile-macro-fixed-ragged-test.command.json'
    source=ROOT/'tests/graph_batch/native_ragged_attention_test.cc';tag='native-ragged-test'
    recipe=c.read(recipe_path)['argv']
    rows.append(dict(tag=tag,source=b.identity(source),old_object=None,command=b.host_command(recipe,source,tag,out),object=str(out/(tag+'.obj')),reason='New F16/BF16 C128/R1 regression and existing actual ragged cases.'))
    correction_path=STAGE/'checks-current/closure-correction.json'
    correction=c.read(correction_path)
    mem=next(x for x in correction['matching_cached_owners'] if Path(x['source']['path']).name=='resource.cc')
    assert mem['all_project_dependencies_equal'] and h.same_identity(mem['source'])
    assert b.same(mem['object']) and all(h.same_identity(d) for d in mem['dependencies'])
    # The parent broad CPU run proved the identical retained hyle_mem.lib
    # requires this current explicit owner. Preserve that corrected closure.
    native_path=A/'grouped-shared-activation/vulkan/native-driver/checks/20261019T211724/driver-identity.json'
    native=c.read(native_path)
    assert b.same(native['source']) and b.same(native['object'])
    assert all(h.same_identity(d) for d in native['dependencies'])
    manifest_path=ROOT/'third_party/ggml_vulkan_runtime/patches.json'
    manifest=c.read(manifest_path)
    patched=next(x for x in manifest['files'] if x['path']=='src/ggml-vulkan/ggml-vulkan.cpp')
    assert native['source']['sha256']==patched['after_sha256']
    # The NVFP4 baseline predates its subsequent current native-host owner.
    # Reuse that already compiled canonical source, same native bridge/deps.
    supplements=[mem['object'],native['object']]
    assert len(rows)==len({c.key(r['object']) for r in rows})
    frozen=[b.identity(STAGE/'source-freeze.json'),b.identity(STAGE/'delegated/freeze.json'),b.identity(correction_path),mem['source'],
        b.identity(native_path),b.identity(manifest_path),native['source']]
    frozen += [r['source'] for r in rows]
    frozen += [b.identity(ROOT/p) for p in ('src/graph/plan_state.h','src/graph/constant_artifact.h','src/graph/resource_episode.h',
        'include/hyle/compute/detail/vulkan_batch_access.h','include/hyle/compute/batch_layout.h')]
    plan=dict(base=inv['base_path'],compile=rows,reused=reuse,unchanged=unchanged,dropped=drop,frozen=frozen,supplemental_current_owners=[mem,native],
              host_TUs=len(rows),SDK_rebuild=False,native_TUs=0,product_edits=False)
    c.save(out/'plan.json',plan)
    print('VULKAN_PLAN compile',len(rows),'reuse',len(reuse),'unchanged',len(unchanged),'drop',len(drop),flush=True)
    for row in rows:print('COMPILE',row['source']['path'],flush=True)
    for row in reuse:print('REUSE',row['source'],flush=True)
    if not args.build:return
    for obj in base['inputs']:assert b.same(obj),obj['path']
    env,runtime=b.environment(base['command'],[r['path'] for r in base['inputs']],out)
    c.save(out/'runtime-environment.json',dict(runtime=runtime,PATH=env['PATH']))
    def check():
        for obj in frozen:assert source_equivalent(obj),obj['path']
    def compile_one(row):
        check();path=out/(row['tag']+'-identity.json')
        if args.resume and path.exists():
            prior=c.read(path)
            if prior['command']==row['command'] and b.same(prior['object']) and all(source_equivalent(x) for x in prior['dependencies']):
                print('REUSE_COMPILE',row['tag'],flush=True);return row['tag'],prior
        c.execute(row['tag']+'-compile',row['command'],env,out);check()
        deps=c.read(out/(row['tag']+'-deps.json'))['Data'];paths=list(dict.fromkeys([deps['Source'],*deps['Includes']]))
        receipt=dict(command=row['command'],source=row['source'],object=b.identity(row['object']),dependencies=[b.identity(p) for p in paths])
        c.save(path,receipt);return row['tag'],receipt
    finished={};errors=[]
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
        for future in concurrent.futures.as_completed([pool.submit(compile_one,row) for row in rows]):
            try:tag,receipt=future.result();finished[tag]=receipt
            except Exception as error:errors.append(repr(error))
    c.save(out/'compile-summary.json',dict(passed=not errors,errors=errors));assert not errors,errors
    additions=list(supplements)
    for row in rows:
        obj=finished[row['tag']]['object']
        if row['old_object']:replace[c.key(row['old_object']['path'])]=obj
        else:additions.append(obj)
    drops={c.key(r['object']['path']) for r in drop}
    command=[replace.get(c.key(arg),{}).get('path',arg) for arg in base['command']
        if c.key(arg) not in drops and not arg.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:'))]
    command += [obj['path'] for obj in additions]
    image=out/'vulkan.exe';command += ['/OUT:'+str(image),'/MAP:'+str(image.with_suffix('.map')),'/IMPLIB:'+str(image.with_suffix('.lib'))]
    lookup={c.key(obj['path']):obj for obj in base['inputs']}
    lookup.update({c.key(obj['path']):obj for obj in [*replace.values(),*additions]})
    inputs=[lookup[c.key(arg)] for arg in command if Path(arg).is_absolute() and Path(arg).suffix.lower() in ('.obj','.lib')]
    assert len(inputs)==len({c.key(obj['path']) for obj in inputs})
    for obj in inputs:assert b.same(obj),obj['path']
    c.save(out/'link-plan.json',dict(command=command,inputs=inputs));check()
    c.execute('vulkan-link',command,env,out);c.save(out/'image.json',b.identity(image))
    plan['link']=dict(command=command,inputs=inputs,image=str(image));c.save(out/'plan.json',plan)
    c.save(out/'summary.json',dict(passed=True,host_TUs=len(rows),reused_current=len(reuse),SDK_rebuild=False,native_TUs=0))
    print('VULKAN_LINKED',flush=True)

if __name__=='__main__':main()
