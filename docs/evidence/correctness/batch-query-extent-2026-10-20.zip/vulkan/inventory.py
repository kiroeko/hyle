"""Read real retained Vulkan object/source/header closure; no SDK configure."""
import importlib.util
from pathlib import Path
import sys
sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
STAGE = S.parent
A = STAGE.parent
ROOT = A.parents[1]
spec = importlib.util.spec_from_file_location('extent_vk_inventory_helpers', A/'grouped-shared-activation/build_host.py')
h = importlib.util.module_from_spec(spec); spec.loader.exec_module(h)
b, c = h.b, h.c
base_path = A/'gguf-nvfp4/windows-host/checks/20261019T201048/vulkan-link-plan.json'
latest_path = STAGE/'checks-current/cpu-link-plan.json'
bases = dict(vulkan=c.read(base_path), current=c.read(latest_path))
meta = h.metadata(bases)
current_by_source = {}
for obj in bases['current']['inputs']:
    record = meta.get(c.key(obj['path']))
    if record:
        current_by_source.setdefault(c.key(record['source_path']), []).append(dict(owner=record, object=obj))
rows, missing = [], []
for obj in bases['vulkan']['inputs']:
    if Path(obj['path']).suffix.lower() != '.obj':
        continue
    record = meta.get(c.key(obj['path']))
    if not record:
        missing.append(obj);continue
    source = Path(record['source_path']).resolve()
    local = source.is_relative_to(ROOT/'src') or source.is_relative_to(ROOT/'tests')
    changes = []
    source_id = record.get('source')
    if local and isinstance(source_id,dict) and source_id.get('sha256') and not h.same_identity(source_id):
        changes.append(dict(kind='source', before=source_id, after=b.identity(source)))
    for dep in record.get('dependencies',[]):
        path=Path(dep['path']).resolve()
        if not(path.is_relative_to(ROOT/'src') or path.is_relative_to(ROOT/'include')):
            continue
        if dep.get('sha256') and not h.same_identity(dep):
            changes.append(dict(kind='header', before=dep, after=b.identity(path)))
    rows.append(dict(object=obj, owner=record, local=local, changes=changes,
                     current_alternatives=current_by_source.get(c.key(source),[])))
c.save(S/'inventory.json',dict(base_path=str(base_path), current_path=str(latest_path),
    owners=rows, missing_metadata=missing, read_only=True))
print('OBJECTS',len(rows),'MISSING',len(missing),flush=True)
for row in rows:
    if row['local']:
        changes=[Path(change['after']['path']).name for change in row['changes']]
        print(Path(row['owner']['source_path']).parent.name+'/'+Path(row['owner']['source_path']).name,
              len(changes),','.join(changes), 'alternatives='+str(len(row['current_alternatives'])),flush=True)
