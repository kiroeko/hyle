"""One new small public inference test on the retained actual CPU product."""
import importlib.util
from pathlib import Path
import sys
import xml.etree.ElementTree as ET
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('batch_extent_red_helpers',S.parent/'projected-bind-cold-index/build.py')
h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
b,c=h.b,h.c
out=S/'reproduction';out.mkdir(exist_ok=False);(out/'tmp').mkdir()
base=c.read(S.parent/'state-clone-slot-ownership/checks/after-link-plan.json')
recipe=c.read(S.parent/'state-clone-slot-ownership/checks/after-state_clone_test-identity.json')
source=S/'reproduction_test.cc'
command=b.host_command(recipe['command'],source,'probe',out)
for row in base['inputs']:assert b.same(row),row['path']
env,runtime=b.environment(base['command'],[row['path'] for row in base['inputs']],out)
c.execute('probe-compile',command,env,out)
data=c.read(out/'probe-deps.json')['Data'];obj=b.identity(out/'probe.obj')
c.save(out/'probe-identity.json',dict(command=command,source=b.identity(source),object=obj,
  dependencies=[b.identity(p) for p in dict.fromkeys([data['Source'],*data['Includes']])]))
link=[arg for arg in base['command'] if not arg.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:'))]
image=out/'tests.exe';link += [obj['path'],'/OUT:'+str(image),'/MAP:'+str(image.with_suffix('.map')),'/IMPLIB:'+str(image.with_suffix('.lib'))]
c.save(out/'link-plan.json',dict(command=link,inputs=[*base['inputs'],obj]))
c.execute('link',link,env,out);c.save(out/'image.json',b.identity(image))
try:c.execute('tests',[str(image),'--gtest_filter=BatchQueryExtentReproduction.*','--gtest_output=xml:'+str(out/'results.xml')],env,out)
except RuntimeError:assert c.read(out/'tests.result.json')['exit']==1
cases=ET.parse(out/'results.xml').findall('.//testcase')
failures=[f.text for case in cases for f in case.findall('failure')]
assert len(cases)==1 and len(failures)==2 and not any(case.find('skipped') is not None for case in cases)
c.save(out/'summary.json',dict(executed=True,expected_red=True,defect_confirmed=True,cases=1,failures=failures,
  exit=1,host_TUs=1,product_compilations=0,SDK_rebuild=False,
  scope='Real retained CPU product public inference rejects R1 with C128 for ordinary ragged and paged; R128 controls remain accepted. No native arithmetic or shape-family execution claim.'))
print('BATCH_EXTENT_PUBLIC_INFERENCE_RED',flush=True)
