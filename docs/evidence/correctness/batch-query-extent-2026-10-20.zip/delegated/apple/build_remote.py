from pathlib import Path
import json,subprocess,time,hashlib,concurrent.futures,shlex,os
RUN=Path(__file__).resolve().parent;plan=json.loads((RUN/'plan.json').read_text());manifest=json.loads((RUN/'source-manifest.json').read_text());byname={}
for r in manifest:byname.setdefault(Path(r['path']).name,[]).append(r)
for row in manifest:assert hashlib.sha256((RUN/row['path']).read_bytes()).hexdigest()==row['sha256'],row['path']
LF_PROOF={x['path']:x for x in json.loads((RUN/'line-ending-proof.json').read_text())['files']}
(RUN/'objects').mkdir(exist_ok=True);(RUN/'results').mkdir(exist_ok=True);records=[]
def write(name,obj):(RUN/'results'/name).write_text(json.dumps(obj,indent=2)+'\n')
def sha(path):
 h=hashlib.sha256()
 with Path(path).open('rb')as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
def input_match(path,old_sha):
 current=sha(path)
 if current==old_sha:return True
 for rel,proof in LF_PROOF.items():
  if str(path).endswith('/'+rel)and proof['prior_crlf_sha256']==old_sha and proof['final_lf_sha256']==current and proof['crlf_reconstruction_normalizes_exactly']:return True
 return False
def compile_one(row):
 source=row['source'];obj=RUN/'objects'/(source.replace('/','--').replace('.cc','.o').replace('.mm','.o'));dep=Path(str(obj)+'.d');argv=row['recipe']['argv'].copy()
 for flag in ['-MF','-MT','-MQ']:
  while flag in argv:
   i=argv.index(flag);del argv[i:i+2]
 argv=[x for x in argv if x not in ['-MMD','-MD']];argv[argv.index('-c')+1]=str(RUN/source);argv[argv.index('-o')+1]=str(obj)
 first=['-I'+str(RUN/'include'),'-I'+str(RUN),'-I'+str(RUN/'src/compute'),'-I'+str(RUN/'src/graph'),'-I'+str(RUN/'src/compute_ops'),'-I'+str(RUN/'src/compute_route_apple'),'-I'+str(RUN/'src/graph_route_apple')]
 # Mirror existing recipe's repository-owned recipe directories with current headers.
 for a in argv:
  if a.startswith('-I')and'/third_party/'in a:
   q=RUN/'third_party'/a.split('/third_party/',1)[1]
   if q.is_dir():first.append('-I'+str(q))
 if '-DHYLE_STATIC'not in argv:first.append('-DHYLE_STATIC')
 if '-Werror'not in argv:first.append('-Werror')
 argv[1:1]=first;argv+=['-MMD','-MF',str(dep)]
 record_path=RUN/'results'/(source.replace('/','--')+'.json')
 if record_path.is_file()and obj.is_file():
  old=json.loads(record_path.read_text())
  if old.get('exit_code')==0 and not old.get('dependency_drifts') and old['argv']==argv and input_match(RUN/source,old['source_sha256']) and old['object_sha256']==sha(obj) and all(input_match(x['path'],x['sha256'])for x in old.get('canonical_dependencies',[])):
   old['final_normalized_source_sha256']=sha(RUN/source);old['line_ending_proof']='line-ending-proof.json';print('REUSED',source,flush=True);return old
 start=time.monotonic();r=subprocess.run(argv,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
 stem=source.replace('/','--');(RUN/'results'/(stem+'.stdout.log')).write_text(r.stdout);(RUN/'results'/(stem+'.stderr.log')).write_text(r.stderr)
 result=dict(source=source,source_sha256=sha(RUN/source),argv=argv,exit_code=r.returncode,seconds=time.monotonic()-start,old_object=row['old_object'],object=str(obj),dependency=str(dep),recipe_record=row['recipe']['record'])
 if r.returncode==0:
  result['object_sha256']=sha(obj);drifts=[];current=[]
  for name in dep.read_text().replace('\\\n',' ').split(': ',1)[1].split():
   path=Path(name)
   if not path.is_file():continue
   for frozen in byname.get(path.name,[]):
    if str(path.resolve()).endswith('/'+frozen['path']):
     got=sha(path);current.append(dict(path=str(path),canonical=frozen['path'],sha256=got))
     if got!=frozen['sha256']:drifts.append(dict(path=str(path),canonical=frozen['path'],expected=frozen['sha256'],actual=got))
  result['canonical_dependencies']=current;result['dependency_drifts']=drifts
 write(stem+'.json',result);print('COMPILED',source,r.returncode,'%.2fs'%result['seconds'],flush=True);return result
priority=['src/compute_batch/batch_layout.cc','src/compute_batch/batch_execution.cc','src/graph_batch/batch.cc','src/graph_batch/native_batch_regions.cc','src/compute_route_apple/apple_batch.cc','src/graph_route_apple/native_ragged_region.cc','tests/graph_batch/native_ragged_attention_test.cc']
rows={x['source']:x for x in plan['recipes']}
for source in priority:
 r=compile_one(rows.pop(source));records.append(r)
 if r['exit_code']or r.get('dependency_drifts'):write('summary.json',dict(compiles=records));raise SystemExit(2)
# Keep each heavy MLX/Torch-header translation unit exclusive on the16 GiB Air.
heavy=[];light=[]
for row in rows.values():
 s=row['source'];heavy_source=s.startswith(('src/compute_route_apple/','src/graph_route_apple/','src/compute_provider_native/','tests/graph_route_apple/','tests/compute_route_apple/','tests/compute_route_vulkan/'))
 (heavy if heavy_source else light).append(row)
for row in heavy:
 r=compile_one(row);records.append(r)
 if r['exit_code']or r.get('dependency_drifts'):write('summary.json',dict(compiles=records));raise SystemExit(2)
with concurrent.futures.ThreadPoolExecutor(max_workers=2)as pool:
 for r in pool.map(compile_one,light):records.append(r)
write('summary.json',dict(compiles=records))
if any(r['exit_code']or r.get('dependency_drifts')for r in records):raise SystemExit(2)
# Replace every matched original owner exactly once; all external math/foundation archives stay shared.
argv=plan['link']['argv'].copy();replacements=[]
for row in records:
 old=row['old_object'];assert argv.count(old)==1,(row['source'],old,argv.count(old));argv[argv.index(old)]=row['object'];replacements.append(dict(source=row['source'],old=old,new=row['object']))
math=json.loads((RUN/'metal-reuse.json').read_text())
for row in math['objects']:assert sha(row['path'])==row['sha256']
argv[1:1]=[x['path']for x in math['objects']]
exe=RUN/'finite-query-tests';argv[argv.index('-o')+1]=str(exe);argv=[('-Wl,-map,'+str(exe)+'.map')if x.startswith('-Wl,-map,')else x for x in argv]
start=time.monotonic();r=subprocess.run(argv,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True);(RUN/'results/link.stdout.log').write_text(r.stdout);(RUN/'results/link.stderr.log').write_text(r.stderr);link=dict(argv=argv,exit_code=r.returncode,seconds=time.monotonic()-start,replacements=replacements);write('link.json',link);print('LINK',r.returncode,flush=True)
if r.returncode:raise SystemExit(3)
# Preserve the original cached metallib identity without copying its payload.
metallib=RUN/'mlx.metallib';oldroot=Path('/Users/kiro/hyle-scratch/compute-unified/architecture-refactor-20261019-apple-page-invocation/native-ragged-graph/validation');target=(oldroot/'mlx.metallib').resolve();assert target.is_file()
if not metallib.exists():metallib.symlink_to(target)
args=[str(exe),'--gtest_filter=NativeRaggedAttentionGraph.*','--gtest_output=json:'+str(RUN/'results/gtest.json')];start=time.monotonic();r=subprocess.run(args,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,timeout=180);(RUN/'results/run.stdout.log').write_text(r.stdout);(RUN/'results/run.stderr.log').write_text(r.stderr);write('run.json',dict(argv=args,exit_code=r.returncode,seconds=time.monotonic()-start,exe_sha256=sha(exe),metallib=dict(path=str(target),sha256=sha(target))));print('RUN',r.returncode,r.stdout,r.stderr,flush=True)
raise SystemExit(r.returncode)
