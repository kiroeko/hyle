from pathlib import Path
import base64,hashlib,json,re,subprocess,sys,time
ROOT=Path.cwd();OUT=Path(__file__).resolve().parent
OLD=ROOT/'.scratch/architecture-refactor-2026-10-18/native-ragged-graph/validation/apple'
REMOTE='/Users/kiro/hyle-scratch/compute-unified/architecture-refactor-20261019-apple-page-invocation/batch-query-extent/delegated'
def ssh(code,payload=None):
 encoded=base64.b64encode(code.encode()).decode();cmd="python3 -c \"import base64;exec(base64.b64decode('"+encoded+"'))\""
 r=subprocess.run(['ssh','kiro@172.22.10.198',cmd],input=json.dumps(payload).encode() if payload is not None else None,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 if r.returncode:raise RuntimeError(r.stderr.decode(errors='replace')+'\n'+r.stdout.decode(errors='replace'))
 return json.loads(r.stdout)
def save(name,value):(OUT/name).write_text(json.dumps(value,indent=2)+'\n')
def plan():
 rows=json.loads((OUT/'recipes-all.json').read_text());search=[ROOT,ROOT/'include',ROOT/'src/compute',ROOT/'src/graph',ROOT/'src/compute_provider_ggml',ROOT/'src/compute_provider_native',ROOT/'src/compute_ops',ROOT/'src/compute_route_apple',ROOT/'src/graph_route_apple']
 for row in rows:
  for a in row['recipe']['argv']:
   if a.startswith('-I') and '/third_party/' in a:
    tail=a.split('/third_party/',1)[1];p=ROOT/'third_party'/tail
    if p.is_dir() and p not in search:search.append(p)
 include=re.compile(r'^\s*#\s*include\s*[<"]([^">]+)[">]',re.M);seen=set()
 def visit(rel):
  if rel in seen:return
  p=ROOT/rel
  if not p.is_file():return
  seen.add(rel)
  if p.suffix not in ['.h','.hpp','.hh','.inl','.inc','.cc','.mm']:return
  for inc in include.findall(p.read_text(errors='replace')):
   q=next((x for x in [p.parent/inc]+[x/inc for x in search]if x.is_file()),None)
   if q:
    try:visit(q.resolve().relative_to(ROOT).as_posix())
    except ValueError:pass
 for row in rows:visit(row['source'])
 # Explicit new API/comment-only headers are part of the frozen batch.
 for rel in ['include/hyle/compute/batch_layout.h','include/hyle/compute/batch_ops.h','include/hyle/compute/detail/batch_graph_access.h','include/hyle/compute/detail/apple_batch_access.h','src/graph_batch/native_batch_regions.h']:visit(rel)
 files=[]
 for rel in sorted(seen):
  data=(ROOT/rel).read_bytes();files.append(dict(path=rel,bytes=len(data),sha256=hashlib.sha256(data).hexdigest(),data=base64.b64encode(data).decode()))
 payload=dict(remote=REMOTE,files=files,recipes=rows,link=json.loads((OLD/'results/025-host-address-link.result.json').read_text()))
 (OUT/'payload.json').write_text(json.dumps(payload));save('source-manifest.json',[{k:v for k,v in row.items()if k!='data'}for row in files]);print(json.dumps(dict(tus=len(rows),files=len(files),bytes=sum(x['bytes']for x in files))))
 code="""from pathlib import Path
import base64,json,sys,hashlib
p=json.load(sys.stdin);root=Path(p['remote']);root.mkdir(parents=True,exist_ok=True)
for row in p['files']:
 data=base64.b64decode(row['data']);assert hashlib.sha256(data).hexdigest()==row['sha256'];f=root/row['path'];f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes(data)
 (root/'source-manifest.json').write_text(json.dumps([{k:v for k,v in r.items()if k!='data'}for r in p['files']],indent=2))
(root/'plan.json').write_text(json.dumps({k:v for k,v in p.items()if k!='files'},indent=2))
print(json.dumps(dict(path=str(root),files=len(p['files']),all_sha_match=all(hashlib.sha256((root/r['path']).read_bytes()).hexdigest()==r['sha256']for r in p['files']))))
"""
 save('sync.json',ssh(code,payload))
if __name__=='__main__':plan()
