"""Four identical common owners shared by CPU/CUDA, plus three test owners."""
import concurrent.futures
import importlib.util
from pathlib import Path
import sys
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent; A=S.parent; ROOT=S.parents[2]
spec=importlib.util.spec_from_file_location('batch_extent_build_helpers',A/'projected-bind-cold-index/build.py')
h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
b,c=h.b,h.c

def main():
    inventory=c.read(S/'owner-inventory.json')
    assert (S/'source-freeze.json').is_file() and (S/'tests/source-freeze.json').is_file()
    out=S/'checks';out.mkdir(exist_ok=True);(out/'tmp').mkdir(exist_ok=True)
    bases={arm:c.read(path) for arm,path in inventory['base_paths'].items()}
    rows=[]
    for name, data in inventory['owners']['cpu'].items():
        tag=name.replace('/','-').removesuffix('.cc')
        source=Path(data['owner']['source_path'])
        command=b.host_command(data['owner']['command'],source,tag,out)
        alternate=b.host_command(inventory['owners']['cuda'][name]['owner']['command'],source,tag,out)
        assert command==alternate, name
        rows.append(dict(tag=tag,source=b.identity(source),command=command,object=str(out/(tag+'.obj')),
            arms=['cpu','cuda'],old_objects={arm:inventory['owners'][arm][name]['old_object'] for arm in bases}))
    cpu_recipe=c.read(A/'state-clone-slot-ownership/checks/after-state_clone_test-identity.json')['command']
    typed_recipe=c.read(A/'cuda-hot-prepare-selection/checks/cpu-20261019T082439/typed-capability-compile.command.json')['command']
    cuda_recipe=c.read(A/'batch-graph-capture/checks/20261019T151524-fixture-include/capture-test-compile.command.json')['command']
    for tag,rel,recipe,arm in [
        ('layout-test','tests/compute_batch/batch_layout_test.cc',cpu_recipe,'cpu'),
        ('typed-test','tests/graph_batch/typed_capability_graph_test.cc',typed_recipe,'cpu'),
        ('capture-test','tests/graph_batch/batch_capture_test.cc',cuda_recipe,'cuda')]:
        source=ROOT/rel
        rows.append(dict(tag=tag,source=b.identity(source),command=b.host_command(recipe,source,tag,out),
            object=str(out/(tag+'.obj')),arms=[arm],old_objects={}))
    files=[row['source'] for row in rows]
    files += [b.identity(ROOT/path) for path in (
        'include/hyle/compute/batch_layout.h','include/hyle/compute/batch_ops.h',
        'include/hyle/compute/detail/batch_graph_access.h','src/graph_batch/native_batch_regions.h')]
    files += [b.identity(S/path) for path in ('source-freeze.json','tests/source-freeze.json')]
    plan=dict(compile=rows,base_paths=inventory['base_paths'],frozen=files,host_TUs=7,native_TUs=0,
        SDK_rebuild=False,common_compile_deduplicated=True,actual_common_owner_command_pairs_equal=4)
    c.save(out/'plan.json',plan)
    for base in bases.values():
        for row in base['inputs']:assert b.same(row),row['path']
    env,runtime=b.environment(bases['cuda']['command'],[row['path'] for row in bases['cuda']['inputs']],out)
    c.save(out/'runtime-environment.json',dict(runtime=runtime,PATH=env['PATH']))
    def check():
        for row in files:assert b.same(row),row['path']
    def compile_one(row):
        check();path=out/(row['tag']+'-identity.json')
        if path.exists():
            old=c.read(path)
            if old['command']==row['command'] and b.same(old['object']) and all(b.same(d) for d in old['dependencies']):
                print('REUSE',row['tag'],flush=True);return row['tag'],old
        c.execute(row['tag']+'-compile',row['command'],env,out);check()
        data=c.read(out/(row['tag']+'-deps.json'))['Data']
        result=dict(command=row['command'],source=row['source'],object=b.identity(row['object']),
            dependencies=[b.identity(p) for p in dict.fromkeys([data['Source'],*data['Includes']])])
        c.save(path,result);return row['tag'],result
    finished,errors={},[]
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
        for future in concurrent.futures.as_completed([pool.submit(compile_one,row) for row in rows]):
            try:
                tag,result=future.result();finished[tag]=result
            except Exception as error:errors.append(repr(error))
    c.save(out/'compile-summary.json',dict(passed=not errors,errors=errors));assert not errors,errors
    probe=c.read(S/'reproduction/probe-identity.json')['object'];assert b.same(probe)
    for arm,base in bases.items():
        replacements={c.key(row['old_objects'][arm]['path']):finished[row['tag']]['object'] for row in rows if arm in row['old_objects']}
        additions=[finished[row['tag']]['object'] for row in rows if arm in row['arms'] and not row['old_objects']]
        if arm=='cpu':additions.append(probe)
        lookup={c.key(row['path']):row for row in base['inputs']}
        lookup.update({c.key(row['path']):row for row in [*replacements.values(),*additions]})
        command=[replacements.get(c.key(arg),{}).get('path',arg) for arg in base['command']
            if not arg.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:'))]
        command += [row['path'] for row in additions]
        image=out/(arm+'.exe')
        command += ['/OUT:'+str(image),'/MAP:'+str(image.with_suffix('.map')),'/IMPLIB:'+str(image.with_suffix('.lib'))]
        inputs=[lookup[c.key(arg)] for arg in command if Path(arg).is_absolute() and Path(arg).suffix.lower() in ('.obj','.lib')]
        for row in inputs:assert b.same(row),row['path']
        check();c.save(out/(arm+'-link-plan.json'),dict(command=command,inputs=inputs))
        c.execute(arm+'-link',command,env,out);c.save(out/(arm+'-image.json'),b.identity(image))
    c.save(out/'summary.json',dict(passed=True,host_TUs=7,native_TUs=0,SDK_rebuild=False,
        unchanged_probe_reused=True,common_owners_compiled_once_for_both_arms=4))
    print('BATCH_EXTENT_BUILT',flush=True)

if __name__=='__main__':main()
