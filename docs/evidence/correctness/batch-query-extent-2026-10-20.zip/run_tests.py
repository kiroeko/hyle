"""Run only the changed public batch geometry, workspace and real graph journeys."""
import argparse
import importlib.util
from pathlib import Path
import re
import sys
import xml.etree.ElementTree as ET
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent;ROOT=S.parents[2]
spec=importlib.util.spec_from_file_location('batch_extent_test_helpers',S.parent/'projected-bind-cold-index/build.py')
h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
b,c=h.b,h.c
parser=argparse.ArgumentParser()
parser.add_argument('--arm',choices=('cpu','cuda','both'),default='both')
parser.add_argument('--destination',default='validation-final')
args=parser.parse_args()
assert Path(args.destination).name==args.destination
assert c.read(S/'checks/summary.json')['passed']
specs={
 'cpu': [('BatchLayout','tests/compute_batch/batch_layout_test.cc'),
         ('BatchWorkspace','tests/compute_batch/workspace_test.cc'),
         ('TypedCapabilityGraph','tests/graph_batch/typed_capability_graph_test.cc'),
         ('StateVersions','tests/compute_state/state_versions_test.cc'),
         ('StateClone','tests/compute_state/state_clone_test.cc')],
 'cuda':[('GraphBatchCapture','tests/graph_batch/batch_capture_test.cc')]}
all_results={}
for arm,tests in specs.items():
    if args.arm!='both' and arm!=args.arm:continue
    out=S/args.destination/arm;out.mkdir(parents=True,exist_ok=False);(out/'tmp').mkdir()
    checks=S/('checks-current' if arm=='cpu' else 'checks')
    image=c.read(checks/(arm+'-image.json'));assert b.same(image)
    link=c.read(checks/(arm+'-link-plan.json'))
    env,runtime=b.environment(link['command'],[row['path'] for row in link['inputs']],out)
    filters=':'.join(suite+'.*' for suite,_ in tests)
    expected=sum(len(re.findall(r'TEST\(\s*'+suite+r'\s*,',(ROOT/path).read_text(encoding='utf-8')))for suite,path in tests)
    if arm=='cpu':filters+=':BatchQueryExtentReproduction.*';expected+=1
    c.save(out/'inputs.json',dict(image=image,filter=filters,expected_cases=expected,runtime=runtime,
        fresh_processes=1,platform='Windows',real_native_math=True))
    c.execute('tests',[image['path'],'--gtest_filter='+filters,'--gtest_output=xml:'+str(out/'results.xml')],env,out)
    cases=ET.parse(out/'results.xml').findall('.//testcase')
    failures=[dict(name=t.attrib['classname']+'.'+t.attrib['name'],details=[f.text for f in t.findall('failure')])for t in cases if t.find('failure')is not None]
    skipped=sum(t.find('skipped')is not None for t in cases)
    result=dict(executed=True,cases=len(cases),expected_cases=expected,skipped=skipped,failures=failures,
        actual=[t.attrib['classname']+'.'+t.attrib['name']for t in cases],passed=len(cases)==expected and not skipped and not failures)
    c.save(out/'summary.json',result);assert result['passed'],result
    all_results[arm]=result
for arm in specs:
    path=S/args.destination/arm/'summary.json'
    if path.exists():all_results[arm]=c.read(path)
c.save(S/args.destination/'summary.json',dict(passed=len(all_results)==2 and all(v['passed'] for v in all_results.values()),arms=all_results,model_run=False,performance_claim=False,
    scope='Actual CPU ggml and CUDA FlashInfer finite-family C128/R128/R1 graph execution, output oracle, metadata ownership and CUDA required capture; ordinary public ragged/paged inference and unchanged workspace neighbors. No broader model or platform claim.'))
print('BATCH_EXTENT_CPU_CUDA_PASSED', {k:v['cases']for k,v in all_results.items()},flush=True)
