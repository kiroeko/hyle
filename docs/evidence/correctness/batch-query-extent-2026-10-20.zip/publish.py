"""Offline evidence publisher. No compilation, GPU, remote access or deletion.

Prepared without execution. After the parent receives the terminal Mac results:
  python <this-file> --apple-results delegated/apple/results --publish
The default only prints the expected intake and never writes public evidence.
"""
from pathlib import Path
import argparse
import hashlib
import json
import xml.etree.ElementTree as ET
import zipfile

S=Path(__file__).resolve().parent
ROOT=S.parents[2]

def read(path): return json.loads(Path(path).read_text(encoding='utf-8'))
def save(path,value): Path(path).write_text(json.dumps(value,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
def identity(path):
    path=Path(path).resolve();data=path.read_bytes()
    return dict(path=str(path),bytes=len(data),sha256=hashlib.sha256(data).hexdigest())
def exact(row,path=None):
    now=identity(path or row['path'])
    return now['bytes']==row['bytes'] and now['sha256']==row['sha256']
def normalized(path): return Path(path).read_bytes().replace(b'\r\n',b'\n').replace(b'\r',b'\n')
def xml_summary(path):
    root=ET.parse(path).getroot();cases=[t for suite in root.findall('testsuite') for t in suite.findall('testcase')]
    return dict(tests=len(cases),failed_cases=sum(bool(t.findall('failure')) for t in cases),
        failure_elements=sum(len(t.findall('failure')) for t in cases),
        skipped=sum(bool(t.findall('skipped')) for t in cases),source=identity(path))
def is_payload(path,base=S):
    relative=path.relative_to(base);name=relative.as_posix();parts={x.lower() for x in relative.parts}
    if parts&{'objects','tmp','cache','__pycache__'} or any('cleanup' in x for x in parts):return False
    if path.name in {'archive-manifest.json','archive-receipt.json','payload-sha256.json','payload.json'}:return False
    # Repeated full inherited object inventories are represented by the small
    # frozen closure, actual per-owner receipts and exact before/after links.
    if name in {'vulkan/inventory.json','vulkan/checks/plan.json',
        'vulkan/first-native-owner-missing/plan.json','delegated/apple/recipes-all.json'}:return False
    return path.suffix.lower() in {'.py','.cc','.cpp','.h','.hpp','.mm','.json','.log','.xml','.diff','.cmake','.md','.d'}

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--apple-results',default='delegated/apple/results')
    parser.add_argument('--publish',action='store_true')
    args=parser.parse_args()
    apple_dir=Path(args.apple_results)
    if not apple_dir.is_absolute():apple_dir=S/apple_dir
    if not args.publish:
        print(json.dumps(dict(prepared_only=True,public_files_written=False,
            waiting_for=[str(apple_dir/name) for name in ('summary.json','run.json','gtest.json')],
            destination='docs/evidence/correctness/batch-query-extent-2026-10-20.json/.zip'),indent=2))
        return

    red=read(S/'reproduction/summary.json');build=read(S/'checks/summary.json')
    final=read(S/'validation-final/summary.json');corrected=read(S/'checks-current/summary.json')
    assert red['defect_confirmed'] and red['expected_red'] and red['exit']==1 and red['cases']==1 and len(red['failures'])==2
    red_xml=xml_summary(S/'reproduction/results.xml')
    assert red_xml['tests']==1 and red_xml['failed_cases']==1 and red_xml['failure_elements']==2
    assert build['passed'] and build['host_TUs']==7 and build['native_TUs']==0 and not build['SDK_rebuild']
    assert corrected['passed'] and corrected['compiler_runs']==0 and not corrected['product_changed']
    initial_cpu=xml_summary(S/'validation/cpu/results.xml')
    assert initial_cpu['tests']==37 and initial_cpu['failed_cases']==1 and initial_cpu['skipped']==0
    for arm,count in [('cpu',74),('cuda',2)]:
        result=final['arms'][arm]
        assert result['passed'] and result['executed'] and result['cases']==count and not result['failures'] and result['skipped']==0
        actual=xml_summary(S/f'validation-final/{arm}/results.xml')
        assert actual['tests']==count and actual['failed_cases']==actual['skipped']==0
    assert final['passed'] and not final['model_run'] and not final['performance_claim']
    probe=read(S/'reproduction/probe-identity.json')['object']
    green_inputs=read(S/'checks-current/cpu-link-plan.json')['inputs']
    assert any(x==probe for x in green_inputs) and exact(probe)

    vk=read(S/'vulkan/final-closure.json');vk_result=read(S/'vulkan/checks/test-summary.json')
    assert vk['passed'] and vk_result['passed'] and vk_result['case_count']==3 and vk_result['failure_count']==vk_result['skip_count']==0
    assert vk['compiled_host_TUs']==25 and vk['new_native_compiler_invocations']==0 and not vk['SDK_or_shader_rebuilt']
    assert vk['first_attempt']['all_original_link_inputs_byte_identical']
    assert len(vk['first_attempt']['exact_link_input_difference'])==1
    vk_xml=xml_summary(S/'vulkan/checks/native-ragged.xml')
    assert vk_xml['tests']==3 and vk_xml['failed_cases']==vk_xml['skipped']==0

    apple_build=read(apple_dir/'summary.json');apple_run=read(apple_dir/'run.json');apple_tests=read(apple_dir/'gtest.json')
    apple_compiles=apple_build['compiles']
    assert len(apple_compiles)>=7 and all(x['exit_code']==0 and not x.get('dependency_drifts') for x in apple_compiles)
    assert apple_run['exit_code']==0
    apple_cases=[x for suite in apple_tests['testsuites'] for x in suite['testsuite']]
    assert len(apple_cases)==3 and apple_tests['tests']==3 and apple_tests['failures']==0
    assert not apple_tests.get('disabled',0) and not apple_tests.get('errors',0)
    assert all(x.get('status')=='RUN' and x.get('result')=='COMPLETED' and not x.get('failures') for x in apple_cases)
    assert all(not x.get('skipped') for x in apple_tests['testsuites'])

    tail_dir=S.parent/'batch-output-tail'
    tail=read(tail_dir/'summary.json')
    tail_source=identity(tail_dir/'reproduction_test.cc')
    assert tail['executed'] and tail['CPU_CUDA_tail_defect_confirmed']
    tail_results={}
    for arm in ('cpu','cuda'):
        result=tail['arms'][arm]
        assert result['executed'] and result['expected_red'] and result['defect_confirmed']
        assert result['cases']==1 and result['exit']==1 and result['skipped']==0 and len(result['failures'])==1
        assert result['source_or_SDK_compilations']==0 and result['new_test_TUs']==1
        xml=xml_summary(tail_dir/arm/'results.xml')
        assert xml['tests']==1 and xml['failed_cases']==xml['failure_elements']==1 and xml['skipped']==0
        receipt=read(tail_dir/arm/'tail-test-identity.json')
        assert exact(receipt['source'],tail_source['path'])
        tail_results[arm]=dict(result=result,xml=xml,test_receipt=identity(tail_dir/arm/'tail-test-identity.json'))

    common=read(S/'source-freeze.json');delegated=read(S/'delegated/freeze.json');tests=read(S/'tests/source-freeze.json')
    for row in common['files']:
        assert exact(row['snapshot']) and exact(row['after'])
        assert exact(row['before'],row['before']['snapshot'])
    for row in delegated['files']:
        assert exact(row,ROOT/row['path'])
        assert normalized(ROOT/row['path'])==normalized(S/'delegated/after'/row['path'])
    for row in tests['files']:
        assert exact(row['frozen']) and exact(row['current']) and exact(row['before'])
    next_design=read(S/'qwen-family-design.json')
    assert next_design['status']=='independent_read_only_design_not_implemented_compiled_or_GPU_tested'

    docs=[]
    for name in ('docs/user/batch-attention.md','docs/architecture/graph-design.md','docs/developer/current-work.md'):
        path=ROOT/name;copy=S/'documentation'/name;copy.parent.mkdir(parents=True,exist_ok=True);copy.write_bytes(path.read_bytes())
        docs.append(dict(relative=name,current=identity(path),snapshot=identity(copy)))
    save(S/'documentation-freeze.json',docs)
    destination=ROOT/'docs/evidence/correctness/batch-query-extent-2026-10-20.zip'
    destination.parent.mkdir(parents=True,exist_ok=True)
    files=[(p.relative_to(S).as_posix(),p) for p in S.rglob('*') if p.is_file() and is_payload(p)]
    files += [('next-open-issue/batch-output-tail/'+p.relative_to(tail_dir).as_posix(),p)
        for p in tail_dir.rglob('*') if p.is_file() and is_payload(p,tail_dir)]
    files.sort(key=lambda entry:entry[0])
    rows=[]
    with zipfile.ZipFile(destination,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as archive:
        for member,path in files:
            row=dict(**identity(path),member=member);rows.append(row);archive.writestr(row['member'],path.read_bytes())
        archive.writestr('payload-sha256.json',json.dumps(rows,indent=2,ensure_ascii=False).encode())
    with zipfile.ZipFile(destination) as archive:
        assert archive.testzip() is None and len(archive.namelist())==len(rows)+1
        assert read_manifest(archive)==rows
        for row in rows:
            payload=archive.read(row['member'])
            assert len(payload)==row['bytes'] and hashlib.sha256(payload).hexdigest()==row['sha256']
    body=dict(date='2026-10-20',scope='Ordinary batch attention concrete Q/output extent and unchanged schema capacity; per-platform frozen real test journeys.',
        defect='Ordinary RaggedAttention/PagedAttention inference and Graph/native preparation confused schema maximum query capacity C with selected concrete Q/output rows R. A one-row decode variant under the same C128 schema was rejected.',
        contract=dict(C='BatchCapacity.max_query_rows: schema upper bound',R='Concrete Graph Q/output rows, frozen in the cold region',A='Active query rows in the owned BatchLayoutVersion',invariant='A <= R <= C',
            admission='Reject A>R before retained command invalidation, metadata replacement or native planning. Original batch_query_description(C) retains full-C behavior; the explicit rows overload truthfully describes R.',
            stricter_existing_domains='Owned paged programs retain R=A; separate MLA retains its previous independent full-C constraints.',
            architecture='Reuse existing shape families, provider routing, native plans, metadata ownership and capture. No padding, new math, model whitelist, cross-Graph global cache or executor.'),
        old_product_red=red,old_product_red_xml=red_xml,same_old_probe_object=probe,
        actual_windows_cpu_cuda=final,common_build=build,
        windows_cpu_manual_closure=dict(initial=initial_cpu,correction=read(S/'checks-current/closure-correction.json'),result=corrected,
            explanation='An unchanged existing shared HostResource test exposed stale manual CopyBatch/system memory owners. Reuse two already compiled source/project-header-matching current owners and relink: zero extra compilation/product edits.'),
        actual_windows_vulkan=vk,
        actual_apple=dict(build=apple_build,run=apple_run,gtest=apple_tests,
            results_directory=str(apple_dir),note='The exact Apple source/compile/native-bridge snapshot and failure/correction logs are archived. This is a separate actual platform snapshot; no cross-platform bit-identical assertion.'),
        source_freezes=dict(common=common,delegated=delegated,tests=tests),
        next_qwen_family_design=next_design,
        next_qwen_family_design_record=dict(member='qwen-family-design.json',identity=identity(S/'qwen-family-design.json'),implemented=False,compiled=False,model_or_GPU_executed=False),
        next_open_issue=dict(status='confirmed_actual_CPU_CUDA_red_unfixed',
            issue='The existing ordinary native CPU/CUDA Graph path does not initialize its inactive A<R output suffix before publishing the concrete R-row result.',
            witness=dict(C=4,R=4,A=1,query_heads=1,head_depth=64,
                Q='All zero',K='All zero',V='Two F16 rows containing 1 and 3',
                initial_output='F16 sentinel0x3535 in all256 elements',
                active_result='All64 active F16 values equal2 exactly; the independent arithmetic assertion passes',
                inactive_result='All192 inactive F16 values remain0x3535 on both CPU and CUDA; only the zero-tail assertion fails'),
            actual_summary=tail,source=tail_source,per_platform=tail_results,
            archive_prefix='next-open-issue/batch-output-tail/',
            product_changed=False,SDK_or_product_compilations=0,new_test_TUs_total=2,
            conclusion='This batch fixes finite query extent admission/execution. It does not close all ordinary batch-attention functionality; the observed CPU/CUDA inactive-output-tail defect remains to implement.'),
        archive=identity(destination),payload_count=len(rows),payloads=rows,archive_verified=dict(CRC=True,all_payload_SHA256=True),
        archive_policy='Keep exact old/new source, commands, dependency/source receipts, actual logs/XML/JSON, old-red and failed stale-closure attempts, corrections, exact line-ending proofs and next Qwen-family design. Exclude objects/executables/maps/libraries/SDKs/cache and base64 source-sync payloads; do not duplicate unchanged third-party math payloads.',
        limits=['CPU74, CUDA2, Vulkan3 and the separately recorded Apple3 are the actual local cases; this is not all-provider/all-shape certification.',
            'CPU/CUDA finite family uses true A=R128/R1 and actual independent output oracles. No whole Qwen model load, same-window throughput or allocation/memory comparison ran in this batch.',
            'A<R inactive output initialization is an actual confirmed and unfixed CPU/CUDA defect: each extra one-case probe fails its only zero-tail assertion, while active values are correct and all192 inactive sentinels remain. Delegated Apple/Vulkan preserve their original tail initialization; the finite-family green tests do not close this separate defect.',
            'MLA and owned paged constraints were not widened. No new precision policy, ordinary-F32/FP8 equivalence or selected-model quality claim.',
            'The embedded next Qwen-family work is reviewed design only; neither implementation nor performance gain is claimed.'])
    save(destination.with_suffix('.json'),body);save(S/'archive-manifest.json',rows)
    save(S/'archive-receipt.json',dict(archive=identity(destination),public_record=identity(destination.with_suffix('.json')),payloads=len(rows),CRC=True,all_SHA256=True,deletion_performed=False))
    print('BATCH_QUERY_EXTENT_PUBLISHED',len(rows),destination.stat().st_size,flush=True)

def read_manifest(archive): return json.loads(archive.read('payload-sha256.json'))

if __name__=='__main__':main()
