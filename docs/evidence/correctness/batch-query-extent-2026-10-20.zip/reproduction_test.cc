#include <gtest/gtest.h>
#include <array>
#include "hyle/compute/batch_ops.h"
namespace {
namespace c=hyle::compute;
TEST(BatchQueryExtentReproduction, OrdinaryPortsUseTheConcreteQueryRowsBelowCapacity) {
  const auto plain=c::CacheStorage::plain(c::DataType::kFloat16).value();
  for (auto storage : {c::BatchStorage::kRagged,c::BatchStorage::kPaged}) {
    const c::BatchCapacity cap{.storage=storage,
      .query_type=c::DataType::kFloat16,.output_type=c::DataType::kFloat16,
      .key_storage=plain,.value_storage=plain,.max_requests=1,.max_query_rows=128,
      .max_kv_rows=128,.max_pages=storage==c::BatchStorage::kPaged?8u:0u,
      .max_page_refs=storage==c::BatchStorage::kPaged?8u:0u,.query_heads=2,.kv_heads=1,
      .qk_head_dim=64,.value_head_dim=64,.page_size=storage==c::BatchStorage::kPaged?16u:1u};
    ASSERT_TRUE(c::validate_batch_capacity(cap).ok());
    for (std::uint32_t rows : {128u,1u}) {
      SCOPED_TRACE(rows);
      const std::array inputs{
        c::TensorDesc::dense(cap.query_type,std::array<std::int64_t,3>{rows,cap.query_heads,cap.qk_head_dim}).value(),
        c::batch_cache_description(cap,c::BatchCacheRole::kKey).value(),
        c::batch_cache_description(cap,c::BatchCacheRole::kValue).value(),
        c::batch_metadata_description(cap).value()};
      std::array<c::TensorDesc,1> outputs;
      const auto status=c::infer_batch_attention(cap,storage,inputs,outputs);
      EXPECT_TRUE(status.ok()) << status.message();
      if (status.ok()) EXPECT_EQ(outputs[0],c::batch_output_description(cap,rows).value());
    }
  }
}
}
