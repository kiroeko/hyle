#include <gtest/gtest.h>

#include <algorithm>
#include <array>
#include <cstdint>
#include <utility>
#include <vector>

#include "../compute_provider_native/half_test_support.h"
#include "hyle/compute/backends/cpu.h"
#include "hyle/compute/providers/ggml_cpu.h"
#include "hyle/graph/batch.h"
#include "hyle/graph/result.h"

namespace {
namespace c = hyle::compute;
namespace g = hyle::graph;
namespace gb = g::batch;
namespace m = hyle::mem;
using F16 = hyle::simd::float16_t;

// Two genuinely distinct resource identities, backed by the real coherent
// host allocator/mapping. The batch providers must keep independent mirrors.
class HostResource final : public m::MemoryResource {
public:
  std::string_view name() const noexcept override { return "batch.test.host"; }
  m::MemoryProperties properties() const noexcept override {
    return m::system_resource().properties();
  }
  hyle::Result<m::ResourceAllocation> allocate(std::size_t bytes,
                                             std::size_t alignment) noexcept override {
    return m::system_resource().resource().allocate(bytes, alignment);
  }
  void deallocate(m::ResourceAllocation allocation) noexcept override {
    m::system_resource().resource().deallocate(allocation);
  }
  hyle::Result<m::ResourceHostMapping> map_host(void *handle, std::size_t offset,
      std::size_t bytes, m::HostAccess access) noexcept override {
    return m::system_resource().resource().map_host(handle, offset, bytes, access);
  }
  hyle::Status unmap_host(void *handle, void *token, std::size_t offset,
      std::size_t bytes, m::HostAccess access) noexcept override {
    return m::system_resource().resource().unmap_host(handle, token, offset, bytes, access);
  }
};

TEST(TypedCapabilityGraph, SharedMetadataAcrossHostResourcesSurvivesLayoutUpdates) {
  HostResource first_resource, second_resource;
  const std::array resources{m::MemoryResourceRef(first_resource), m::MemoryResourceRef(second_resource)};
  auto first = c::Context::create(c::cpu::device(),
      c::ggml_cpu::provider({.native_threads = 1})).value();
  auto second = c::Context::create(c::cpu::device(),
      c::ggml_cpu::provider({.native_threads = 1})).value();
  auto first_queue = first.create_queue().value();
  auto second_queue = second.create_queue().value();
  const auto plain = c::CacheStorage::plain(c::DataType::kFloat16).value();
  const c::BatchCapacity capacity{
      .storage = c::BatchStorage::kRagged,
      .query_type = c::DataType::kFloat16, .output_type = c::DataType::kFloat16,
      .key_storage = plain, .value_storage = plain,
      .max_requests = 1, .max_query_rows = 2, .max_kv_rows = 3,
      .max_pages = 0, .max_page_refs = 0,
      .query_heads = 2, .kv_heads = 1, .qk_head_dim = 64, .value_head_dim = 64,
      .page_size = 1};
  auto schema = c::BatchSchema::create(capacity).value();
  const std::array<std::int32_t, 2> queries{0, 2}, two_keys{0, 2}, three_keys{0, 3};
  const std::array versions{schema.version({queries, two_keys, {}, {}}).value(),
                            schema.version({queries, three_keys, {}, {}}).value()};
  const std::array descriptions{
      c::batch_query_description(capacity).value(),
      c::batch_cache_description(capacity, c::BatchCacheRole::kKey).value(),
      c::batch_cache_description(capacity, c::BatchCacheRole::kValue).value(),
      schema.metadata_description().value()};
  auto builder = g::GraphBuilder::create().value();
  std::array<g::ValueId, 4> inputs;
  for (std::size_t port = 0; port < inputs.size(); ++port)
    inputs[port] = builder.input(descriptions[port]).value();
  std::array<g::NodeId, 2> nodes;
  std::array<g::ValueId, 2> outputs;
  for (std::size_t branch = 0; branch < nodes.size(); ++branch) {
    nodes[branch] = builder.add_node(c::Operation::custom(c::RaggedAttention{
        .capacity = capacity, .scale = .125F, .causal = false}), inputs).value();
    outputs[branch] = builder.result(nodes[branch]).value();
    ASSERT_TRUE(builder.publish(outputs[branch]).ok());
  }
  auto graph = std::move(builder).finish().value();
  const std::array domains{g::StorageDomain{resources[0]}, g::StorageDomain{resources[1]}};
  const std::array targets{
      g::ExecutionTarget{g::ExecutionSource::acquire(first).value(), g::StorageDomainId{0}},
      g::ExecutionTarget{g::ExecutionSource::acquire(second).value(), g::StorageDomainId{1}}};
  const std::array placements{
      g::NodePlacement{nodes[0], g::ExecutionTargetId{0}, g::PlacementStrength::kRequired},
      g::NodePlacement{nodes[1], g::ExecutionTargetId{1}, g::PlacementStrength::kRequired}};
  const std::array output_places{
      g::ValuePlacement{outputs[0], g::StorageDomainId{0}, g::PlacementStrength::kRequired},
      g::ValuePlacement{outputs[1], g::StorageDomainId{1}, g::PlacementStrength::kRequired}};
  const std::array external{
      g::ExternalResourceContract{inputs[0], g::StorageDomainId{0}},
      g::ExternalResourceContract{inputs[1], g::StorageDomainId{0}},
      g::ExternalResourceContract{inputs[2], g::StorageDomainId{0}},
      g::ExternalResourceContract{inputs[3], g::StorageDomainId{0}},
      g::ExternalResourceContract{outputs[0], g::StorageDomainId{0}},
      g::ExternalResourceContract{outputs[1], g::StorageDomainId{1}}};
  auto compiled = gb::compile(graph, {.storage_domains = domains, .targets = targets},
      {.node_placements = placements, .value_placements = output_places,
       .external_resources = external, .operation_fallback = g::OperationFallbackPolicy::kReject});
  ASSERT_TRUE(compiled) << compiled.error().message();
  auto slot = compiled->executable.create_invocation().value();
  const std::array queues{g::QueueBinding{g::ExecutionLaneId{0}, &first_queue},
                          g::QueueBinding{g::ExecutionLaneId{1}, &second_queue}};
  std::array<m::Buffer, 3> payload;
  for (std::size_t port = 0; port < payload.size(); ++port) {
    payload[port] = m::Buffer::create(resources[0], descriptions[port].required_bytes().value(), 64).value();
    ASSERT_TRUE(payload[port].view().fill(std::byte{0}).ok());
  }
  std::vector<F16> values(3 * 64);
  for (std::size_t row = 0; row < 3; ++row)
    std::fill_n(values.begin() + row * 64, 64, half_test::encode<F16>(float(2 * row + 1)));
  ASSERT_TRUE(payload[2].view().write(std::as_bytes(std::span(values))).ok());
  const auto output_description = c::batch_output_description(capacity, 2).value();
  std::array<m::Buffer, 2> destinations;
  for (std::size_t branch = 0; branch < destinations.size(); ++branch)
    destinations[branch] = m::Buffer::create(resources[branch],
        output_description.required_bytes().value(), 64).value();
  auto replacement = m::Buffer::create(resources[0], descriptions[3].required_bytes().value(), 64).value();
  ASSERT_TRUE(replacement.view().fill(std::byte{0}).ok());

  // Revisit the old version after updating too: reset must drop the Graph's
  // canonical mirror reference before each provider makes its own mirror writable.
  std::size_t round = 0;
  for (const std::size_t version : {0u, 1u, 0u}) {
    const std::array layouts{gb::NodeLayout{nodes[0], versions[version]},
                             gb::NodeLayout{nodes[1], versions[version]}};
    if (round != 0) {
      // Both rejections start from a successful cached selection. A move keeps
      // the original state; failure must not leave its old token submit-ready.
      if (round == 1) {
        auto moved = std::move(slot);
        slot = std::move(moved);
        const std::array duplicated{layouts[0], layouts[0]};
        EXPECT_TRUE(gb::prepare(slot, queues, duplicated,
            {.max_float_workspace_bytes = 8u << 20, .max_int_workspace_bytes = 4096})
            .IsInvalidArgument());
      } else {
        const std::array wrong_queues{queues[0],
            g::QueueBinding{g::ExecutionLaneId{1}, &first_queue}};
        EXPECT_TRUE(gb::prepare(slot, wrong_queues, layouts,
            {.max_float_workspace_bytes = 8u << 20, .max_int_workspace_bytes = 4096})
            .IsInvalidArgument());
      }
      auto stale = slot.submit(queues);
      EXPECT_FALSE(stale);
    }
    const auto prepared = gb::prepare(slot, queues, layouts,
        {.max_float_workspace_bytes = 8u << 20, .max_int_workspace_bytes = 4096});
    ASSERT_TRUE(prepared.ok()) << prepared.message();
    for (std::size_t port = 0; port < payload.size(); ++port)
      ASSERT_TRUE(slot.bind(inputs[port], c::ConstTensorView::create(
          descriptions[port], payload[port].view()).value()).ok());
    for (std::size_t branch = 0; branch < destinations.size(); ++branch)
      ASSERT_TRUE(slot.bind(outputs[branch], c::TensorView::create(
          output_description, destinations[branch].view()).value()).ok());
    EXPECT_TRUE(slot.bind(inputs[3], c::ConstTensorView::create(
        descriptions[3], replacement.view()).value()).IsFailedPrecondition());
    ASSERT_TRUE(slot.prepare_replay(queues).ok());
    {
      auto completion = slot.submit(queues);
      ASSERT_TRUE(completion) << completion.error().message();
      ASSERT_TRUE(completion->wait().ok());
      const double expected = version ? 3. : 2.; // Uniform scores average V rows.
      for (std::size_t branch = 0; branch < outputs.size(); ++branch) {
        auto result = slot.result(outputs[branch]).value();
        auto tensor = result.tensor().value();
        EXPECT_EQ(tensor.storage().resource(), resources[branch]);
        std::array<std::uint16_t, 2 * 2 * 64> observed;
        ASSERT_TRUE(tensor.storage().read(std::as_writable_bytes(std::span(observed))).ok());
        for (const auto word : observed)
          EXPECT_NEAR(half_test::decode_bits<F16>(word), expected, .002);
      }
    }
    ++round;
  }
}
} // namespace
