"""Read actual retained CPU/CUDA object recipes without configuring an SDK."""
import importlib.util
from pathlib import Path
import sys
sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
A = S.parent
spec = importlib.util.spec_from_file_location('batch_extent_inventory_helpers', A/'grouped-shared-activation/build_host.py')
h = importlib.util.module_from_spec(spec)
spec.loader.exec_module(h)
b, c = h.b, h.c
paths = dict(cpu=A/'state-clone-slot-ownership/checks/after-link-plan.json',
            cuda=A/'grouped-fp8-scale-order/checks/tests-link-plan.json')
bases = {arm:c.read(path) for arm,path in paths.items()}
meta = h.metadata(bases)
owners = {}
for arm, base in bases.items():
    owners[arm] = {}
    for obj in base['inputs']:
        owner = meta.get(c.key(obj['path']))
        if not owner:
            continue
        source = Path(owner['source_path'])
        if source.parent.name in ('compute_batch','graph_batch') and source.name in (
                'batch_layout.cc','batch_execution.cc','batch.cc','native_batch_regions.cc'):
            owners[arm][source.parent.name+'/'+source.name] = dict(owner=owner, old_object=obj)
    assert len(owners[arm])==4, (arm,list(owners[arm]))
c.save(S/'owner-inventory.json', dict(base_paths={k:str(v) for k,v in paths.items()}, owners=owners,
    scope='Four actual changed source owners per retained arm; additive public helper declaration does not change existing caller ABI. New test owners will be compiled with the selected arm recipe.'))
print('BATCH_EXTENT_OWNER_INVENTORY', {arm:list(rows) for arm,rows in owners.items()}, flush=True)
