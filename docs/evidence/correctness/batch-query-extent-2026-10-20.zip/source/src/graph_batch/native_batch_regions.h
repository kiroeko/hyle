#pragma once

#include "hyle/graph/batch.h"
#include "hyle/graph/detail/region_access.h"
#include "hyle/graph/region_provider.h"
#include "native_pending_regions.h"
#include "hyle/mem/std_allocator.h"

#include <utility>
#include <vector>

namespace hyle::graph::batch::detail {
// Cold layout capability of one exact selected prepared implementation. The
// payload ports describe Q/K/V (or Q/compact-cache). An explicit metadata
// input is bound once by the typed preparation; it is never a second executor.
// The physical input indices are the original region boundary port indices.
inline constexpr compute::ProviderExtensionId kNativeBatchRegionExtensionId{
    0x48594c454e415450ULL, 0x414745445245474eULL, 4};
struct NativeBatchRegionFacts final {
  NodeId node;
  // Only a real page recipe grants exact projected page permissions. Ragged
  // implementations report their real capacity and leave this null.
  const compute::NativePagedBatchProgram *paged_program = nullptr;
  compute::BatchCapacity capacity{};
  compute::MlaCacheLayout mla = compute::MlaCacheLayout::kNone;
  bool causal = true;
  std::int32_t window_left = -1;
  std::span<const ValueId> inputs;
  std::span<const std::uint32_t> input_ports;
  ValueId metadata_input;
  // Exact selected Q/output port extent R <= schema maximum. An owned page
  // recipe additionally fixes R to its active row count; ordinary ragged
  // preparation checks its owned layout's active rows fit R.
  std::uint32_t output_query_rows = 0;
  // Ragged has no owned initial layout in its operation descriptor. This is
  // empty until its first explicit prepare, then names the actual slot version.
  compute::BatchLayoutVersion layout;
};
struct NativeBatchRegionVTable final {
  Result<NativeBatchRegionFacts> (*inspect)(void *prepared,
                                           void *invocation) noexcept = nullptr;
  Status (*prepare)(void *prepared, void *invocation,
                    compute::BatchLayoutVersion) noexcept = nullptr;
  Status (*validate_frame)(void *prepared, void *invocation, ValueId,
                           const compute::PagedArenaRead &) noexcept = nullptr;
  // Only called after every real reader and the original Graph binding have
  // accepted the exact frame. It cannot fail or manufacture ready permission.
  void (*commit_frame)(void *prepared, void *invocation, ValueId,
                        compute::PagedArenaRead) noexcept = nullptr;
  Status (*reset)(void *prepared, void *invocation) noexcept = nullptr;
  compute::NativePagedBatchReport (*report)(void *prepared,
                                           void *invocation) noexcept = nullptr;

};
// Borrowed original slot references, retained only by its existing resource
// payload for cold reset. Destruction never dereferences these pointers.
struct NativeBatchRegionRef final {
  const NativeBatchRegionVTable *table = nullptr;
  const ProviderRegionPreparedVTable *implementation = nullptr;
  void *prepared = nullptr;
  void *invocation = nullptr;
  std::uint32_t step = 0;
  ExecutionLaneId lane;
  NodeId node;
  const compute::NativePagedBatchProgram *paged_program = nullptr;
  std::span<const ValueId> inputs;
  std::span<const std::uint32_t> input_ports;
  ValueId metadata_input;
};
using NativeBatchRegions = std::vector<NativeBatchRegionRef,
    mem::StdAllocator<NativeBatchRegionRef>>;
using NodeLayouts = std::vector<NodeLayout, mem::StdAllocator<NodeLayout>>;
using ProjectedReaders = std::vector<graph::detail::ProjectedReader,
    mem::StdAllocator<graph::detail::ProjectedReader>>;
Status collect_native_batch_regions(Invocation &, NativeBatchRegions &) noexcept;
Result<NativeBatchRegionFacts> inspect_native_batch_region(
    const NativeBatchRegionRef &) noexcept;
Status split_native_batch_layouts(std::span<const NativeBatchRegionRef>,
    std::span<const NodeLayout>, NodeLayouts &shared) noexcept;
Status prepare_native_batch_regions(std::span<const NativeBatchRegionRef>,
    std::span<const NodeLayout>) noexcept;
Status reset_native_batch_regions(std::span<const NativeBatchRegionRef>) noexcept;
Result<std::uint64_t> native_paged_read_capacity(
    std::span<const NativeBatchRegionRef>) noexcept;
Status native_paged_frame(std::span<const NativeBatchRegionRef>, ValueId,
    const compute::PagedArenaRead &, ProjectedReaders &) noexcept;
void commit_native_paged_frame(std::span<const NativeBatchRegionRef>, ValueId,
    compute::PagedArenaRead) noexcept;
Result<compute::NativePagedBatchReport> native_paged_report(
    Invocation &, NodeId) noexcept;
} // namespace hyle::graph::batch::detail
