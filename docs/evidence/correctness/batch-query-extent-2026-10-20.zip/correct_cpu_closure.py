"""Replace the stale manual-copy owner using fully matching cached source/headers."""
import importlib.util
from pathlib import Path
import sys
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent;A=S.parent;ROOT=S.parents[2]
spec=importlib.util.spec_from_file_location('batch_extent_cpu_closure_helpers',A/'projected-bind-cold-index/build.py')
h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
b,c=h.b,h.c
prior=A/'cuda-hot-prepare-selection/checks/cpu-identity-20261019T082918'
old_plan=c.read(prior/'plan.json')
frozen={c.key(row['path']):row for row in old_plan['frozen']}
proof=[]
for name in ('batch-transfer','mem-resource'):
    receipt=c.read(prior/(name+'-identity.json'))
    assert b.same(receipt['source']) and b.same(receipt['object'])
    deps=c.read(prior/(name+'-deps.json'))['Data']
    checked=[]
    for path in [deps['Source'],*deps['Includes']]:
        p=Path(path).resolve()
        if p.is_relative_to(ROOT):
            identity=frozen.get(c.key(path),receipt['source'] if c.key(path)==c.key(receipt['source']['path']) else None)
            assert identity is not None and b.same(identity),path
            checked.append(identity)
    proof.append(dict(receipt=b.identity(prior/(name+'-identity.json')),object=receipt['object'],
        source=receipt['source'],all_project_dependencies_equal=True,dependencies=checked))
base=c.read(S/'checks/cpu-link-plan.json')
out=S/'checks-current';out.mkdir(exist_ok=False);(out/'tmp').mkdir()
old_copy=[row for row in base['inputs'] if Path(row['path']).name=='batch-transfer-final.obj']
assert len(old_copy)==1
copy=proof[0]['object'];memory=proof[1]['object']
lookup={c.key(row['path']):row for row in base['inputs']}
lookup.update({c.key(row['path']):row for row in (copy,memory)})
command=[copy['path'] if c.key(arg)==c.key(old_copy[0]['path']) else arg for arg in base['command']
    if not arg.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:'))]
command.append(memory['path'])
image=out/'cpu.exe'
command += ['/OUT:'+str(image),'/MAP:'+str(image.with_suffix('.map')),'/IMPLIB:'+str(image.with_suffix('.lib'))]
inputs=[lookup[c.key(arg)]for arg in command if Path(arg).is_absolute()and Path(arg).suffix.lower()in('.obj','.lib')]
for row in inputs:assert b.same(row),row['path']
env,runtime=b.environment(command,[row['path']for row in inputs],out)
c.save(out/'closure-correction.json',dict(before_link=b.identity(S/'checks/cpu-link-plan.json'),
    removed_stale_copy=old_copy[0],matching_cached_owners=proof,product_changed=False,
    compiler_runs=0,SDK_build=False,reason='The first broad CPU image carried an old manual CopyBatch object and old system memory capability; unchanged existing shared-resource test exposed it. No fixture or product source change.'))
c.save(out/'cpu-link-plan.json',dict(command=command,inputs=inputs))
c.execute('cpu-link',command,env,out);c.save(out/'cpu-image.json',b.identity(image))
c.save(out/'summary.json',dict(passed=True,compiler_runs=0,SDK_build=False,product_changed=False,
    source_header_checked_cached_owners=2,runtime=runtime))
print('BATCH_EXTENT_CPU_CLOSURE_CORRECTED',flush=True)
