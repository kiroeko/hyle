"""Freeze the common bounded-query port repair; no compilation or device work."""
from pathlib import Path
import difflib
import hashlib
import json

S = Path(__file__).resolve().parent
ROOT = S.parents[2]


def identity(path):
    blob = path.read_bytes()
    return dict(path=str(path.resolve()), bytes=len(blob), sha256=hashlib.sha256(blob).hexdigest())


before = json.loads((S / 'before.json').read_text(encoding='utf-8'))
rows, diff = [], []
for original in before['files']:
    relative = original['relative']
    source = ROOT / relative
    old = Path(original['snapshot'])
    assert identity(old)['sha256'] == original['sha256']
    snapshot = S / 'source' / relative
    snapshot.parent.mkdir(parents=True, exist_ok=True)
    snapshot.write_bytes(source.read_bytes())
    rows.append(dict(relative=relative, before=original, after=identity(source), snapshot=identity(snapshot)))
    diff.extend(difflib.unified_diff(old.read_text(encoding='utf-8').splitlines(True),
                                    source.read_text(encoding='utf-8').splitlines(True),
                                    fromfile='a/' + relative, tofile='b/' + relative))
(S / 'common.diff').write_text(''.join(diff), encoding='utf-8', newline='\n')
description = dict(
    scope='Common ordinary RaggedAttention/PagedAttention bounded concrete query/output ports; '
          'explicit MLA keeps its original full-capacity inference and owned page keeps active-sized shape.',
    invariant='C=schema.max_query_rows, R=concrete Graph Q/output extent, A=owned layout active query rows; A<=R<=C.',
    public_API='Add batch_query_description(BatchCapacity,std::uint32_t rows), symmetric with output helper. '
               'The original one-argument overload still constructs C rows. Both preserve schema identity.',
    inference='Validate exact rank3 dense Q geometry for R<=C, preserve exact K/V/metadata descriptions, infer R-sized output.',
    common_preparation='Compile Region freezes R from real concrete Q/output descriptions. Cold prepare preflights '
                       'A>R before command invalidation, token clearing, metadata mutation or native planning. '
                       'Queue/Context, schema owner, shared metadata identity and owned page strictness remain.',
    bridge='Graph-admitted immutable Q TensorDesc supplies the physical extent to graph_views; it checks '
           'A<=R, exact helper geometry and R-sized output. Explicit non-owned MLA remains C-sized; '
           'owned pages remain A-sized. No runtime shape search or changed native math.',
    delegated_facts='Use existing output_query_rows as R<=C and reject any already owned active layout exceeding it. '
                    'NativeBatchRegionFacts layout and vtable ABI unchanged.',
    ownership='No new buffer, copy, executor, route, global cache, mutable BatchProgramOptions field or precision mode. '
              'Native CPU/FlashInfer planning still uses the original owned layout A/request lengths; '
              'Direct PreparedBatch full-capacity input lease contract is unchanged.',
    headers=dict(
        batch_layout='One exported overload; no public object layout changed.',
        batch_ops='Comment only; separate MLA inline inference untouched.',
        batch_graph_access='Comment only; signatures and enum unchanged.',
        native_batch_regions='Comment only; fields/vtable layout unchanged.'),
    tests_added=[
        'BatchLayout.AttentionConcreteQueryExtentIsBoundedByTheUnchangedSchemaCapacity: '
        'both ordinary Paged/Ragged C128/R1/R128, truthful byte extents, unchanged metadata/schema, '
        'R129/type/head/value/metadata/strided rejects.',
        'BatchLayout.OrdinaryQueryExtentAdmissionDoesNotChangeTheSeparateMlaContract: '
        'both explicit MLA contracts still accept C128 and reject R1.'
    ],
    limits='Source only by this agent; root owns real old/new builds and CPU/CUDA runtime, '
           'another assigned agent owns delegated Apple/Vulkan implementation and verification. '
           'No performance or complete finite-family/consumer result is claimed.',
)
(S / 'design.json').write_text(json.dumps(description, indent=2) + '\n', encoding='utf-8')
record = dict(files=rows, diff=identity(S / 'common.diff'), design=identity(S / 'design.json'),
              compiler_or_GPU_executed=False, frozen=True)
(S / 'source-freeze.json').write_text(json.dumps(record, indent=2) + '\n', encoding='utf-8')
print(json.dumps(dict(source_freeze=identity(S / 'source-freeze.json'), files=len(rows),
                      changed=sum(row['before']['sha256'] != row['after']['sha256'] for row in rows))))
