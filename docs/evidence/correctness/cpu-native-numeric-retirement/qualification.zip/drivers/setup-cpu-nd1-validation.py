from pathlib import Path
import hashlib,json,subprocess
repo=Path(__file__).resolve().parents[1]
old=repo/'.scratch/validation/cpu-aten-compilation-storage'
fixture=repo/'.scratch/validation/cpu-native-numeric-retirement'
fixture.mkdir(parents=True,exist_ok=True)
def write(p,data):
    p.parent.mkdir(parents=True,exist_ok=True)
    if not p.exists() or p.read_bytes()!=data:p.write_bytes(data)
base=(repo/'.scratch/validation/cpu-aten-transformer-matrix/consumer.cc').read_text(encoding='utf-8').split('int main() {')[0]
base=base.replace('auto prepared = take(c::prepare(context, op, inputs, std::span(&output, 1),','''auto native_context = take(c::Context::create(c::cpu::device(), c::native::provider()));
  auto declined = c::prepare(native_context, op, inputs, std::span(&output, 1), m::system_resource());
  if (declined || !declined.error().IsUnimplemented()) std::exit(9);
  auto prepared = take(c::prepare(context, op, inputs, std::span(&output, 1),''')
base=base.replace('auto gi = take(compiled.executable.create_invocation());','''const std::array only_native{c::native::kProviderId};
  g::CompileOptions restricted{};
  restricted.allowed_providers = only_native;
  if (g::compile(logical, gc, restricted)) std::exit(10);
  auto gi = take(compiled.executable.create_invocation());''')
main=r'''
double activate(double x,int kind){
 if(kind==1)return .5*x*std::erfc(-x/std::sqrt(2.));
 const double inner=kind==2?2*std::sqrt(2/std::acos(-1.))*(x+.044715*x*x*x):x;
 const double e=std::exp(-std::abs(inner));return x*(inner<0?e/(1+e):1/(1+e));
}
int main(){
 const auto f=c::DataType::kFloat32;
 const auto d=desc(f,{1,4});
 const std::array<float,4> values{-100,-6,-5,2};
 for(int kind=0;kind<3;++kind){
  const auto unary=kind==0?c::UnaryKind::kSilu:kind==1?c::UnaryKind::kGelu:c::UnaryKind::kGeluTanh;
  journey(c::Operation(c::Unary{unary}),std::array{d},
   [&](auto &b,int seed){auto x=values;x[3]+=float(seed);write<float>(b[0],d,x);},
   [&](const auto &b,int seed){std::array<float,4> x;for(int i=0;i<4;++i)x[i]=float(activate(values[i]+(i==3?seed:0),kind));compare(b,x);});
  for(bool packed:{false,true}){
   const auto input=desc(f,packed?std::initializer_list<std::int64_t>{1,8}:std::initializer_list<std::int64_t>{1,4});
   std::vector<c::TensorDesc> ds{input};if(!packed)ds.push_back(d);
   journey(c::Operation(c::GatedActivation{.activation=c::GatedActivationKind(kind),.inputs=packed?c::GatedInputKind::kPackedHalves:c::GatedInputKind::kSeparate}),ds,
    [&](auto &b,int seed){auto x=values;x[3]+=float(seed);const std::array<float,4> v{1e38F,1e30F,1e30F,1};
     if(packed){std::array<float,8> all;std::copy(x.begin(),x.end(),all.begin());std::copy(v.begin(),v.end(),all.begin()+4);write<float>(b[0],input,all);}
     else{write<float>(b[0],input,x);write<float>(b[1],d,v);}},
    [&](const auto &b,int seed){std::array<float,4> x;const std::array<float,4> v{1e38F,1e30F,1e30F,1};for(int i=0;i<4;++i)x[i]=float(activate(values[i]+(i==3?seed:0),kind))*v[i];compare(b,x);});
  }
 }
 const std::array ds{desc(f,{1,2,1,4}),desc(c::DataType::kInt64,{2}),desc(f,{2})};
 journey(c::Operation(c::RoPE{.rotary_dimensions=4,.sequence_axis=1}),ds,
  [&](auto &b,int seed){std::array<float,8>x;for(int i=0;i<8;++i)x[i]=float(i+1+seed);const std::array<std::int64_t,2>p{2147483651LL,-2147483651LL};const std::array<float,2>freq{.125,.25};write<float>(b[0],ds[0],x);write<std::int64_t>(b[1],ds[1],p);write<float>(b[2],ds[2],freq);},
  [&](const auto &b,int seed){std::array<float,8>x;for(int row=0;row<2;++row)for(int pair=0;pair<2;++pair){const double p=row?-2147483651.:2147483651.,angle=p*(pair?.25:.125),a=row*4+pair*2+1+seed,z=a+1;x[row*4+pair*2]=float(a*std::cos(angle)-z*std::sin(angle));x[row*4+pair*2+1]=float(a*std::sin(angle)+z*std::cos(angle));}compare(b,x);});
 std::puts("PASS ordinary mature retired-domain Direct/Graph tails/gates/long I64/replay/close; Native and Native-only Graph reject");
}
'''
write(fixture/'consumer.cc',(base+main).encode())
write(fixture/'consumer/CMakeLists.txt',(old/'consumer/CMakeLists.txt').read_bytes())
for platform in ('windows','linux'):
    text=(old/(platform+'-overlay.cmake')).read_text(encoding='utf-8').replace('cpu-aten-compilation-storage','cpu-native-numeric-retirement')
    write(fixture/(platform+'-overlay.cmake'),text.encode())
manifest=json.loads((old/'manifest.json').read_text());head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
result={'candidate':'f32d261a5b83238162b62aa9cb6d5991e53d2573','fixture_commit':head,'files':{}}
# Resolve the source commit without assuming a full hash from memory.
result['candidate']=subprocess.check_output(['git','rev-parse','f32d261a'],cwd=repo,text=True).strip()
for name in manifest['files']:
    if name.startswith('.scratch/'):continue
    result['files'][name]=hashlib.sha256((repo/name).read_bytes()).hexdigest()
for name in ('consumer.cc','consumer/CMakeLists.txt','windows-overlay.cmake','linux-overlay.cmake'):
    result['files'][(fixture/name).relative_to(repo).as_posix()]=hashlib.sha256((fixture/name).read_bytes()).hexdigest()
write(fixture/'manifest.json',(json.dumps(result,indent=2)+'\n').encode())
for platform in ('windows','linux'):
    text=(repo/('.scratch/cpu-cp-'+platform+'.py')).read_text(encoding='utf-8').replace('cpu-aten-compilation-storage','cpu-native-numeric-retirement').replace('cpu-cp-','cpu-nd1-').replace("+'-cp-consumer'","+'-nd1-consumer'")
    write(repo/('.scratch/cpu-nd1-'+platform+'.py'),text.encode())
print(json.dumps({'candidate':result['candidate'],'fixture':head,'inputs':len(result['files'])}))
