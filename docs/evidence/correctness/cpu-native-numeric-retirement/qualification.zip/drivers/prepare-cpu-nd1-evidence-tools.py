from pathlib import Path
import json,hashlib
repo=Path(__file__).resolve().parents[1]
fixture=repo/'.scratch/validation/cpu-native-numeric-retirement'
for name in ('cleanup-cpu-cp-windows.ps1','cleanup-cpu-cp-linux.py','collect-cpu-cp-evidence.py'):
    text=(repo/'.scratch'/name).read_text(encoding='utf-8').replace('cpu-aten-compilation-storage','cpu-native-numeric-retirement').replace('cpu-cp-','cpu-nd1-').replace('shared-cp-consumer','shared-nd1-consumer').replace('static-cp-consumer','static-nd1-consumer')
    text=text.replace('CP1-2; exact extra cold compilation storage declaration and strict-budget ordinary Graph','ND-R1; retired numerically ineligible Native domains and mature ordinary migration')
    text=text.replace('tests/compute_provider_native/provider_shape_test.cc','tests/compute_provider_native/provider_shape_test.cc')
    text=text.replace("'cpu-nd1-reuse-proof.py', 'cpu-nd1-baseline.py', 'cpu-nd1-loc.py'","'prepare-cpu-nd1-evidence-tools.py'")
    if name=='collect-cpu-cp-evidence.py':
        text=text.replace("result['reuse_proof'] = json.loads((fixture/'reuse-proof.json').read_text())","result['mature_and_infra_identity'] = json.loads((fixture/'mature-identity.json').read_text())")
        text=text.replace("'src/compute_provider_native/aten_cpu_provider.cc',","'src/compute_provider_native/elementwise.cc', 'src/compute_provider_native/native_provider.cc', 'src/compute_provider_native/transformer.cc',")
    (repo/'.scratch'/name.replace('cpu-cp','cpu-nd1')).write_text(text,encoding='utf-8',newline='\n')
old=json.loads((repo/'.scratch/validation/cpu-aten-compilation-storage/manifest.json').read_text())
unchanged={}
for name,digest in old['files'].items():
    if name.startswith(('include/hyle/simd/','src/simd/','src/compute_provider_native/aten_cpu_provider.cc','src/compute_provider_ggml/','src/compute_provider_onednn/','src/compute_route_cpu/','src/graph_route_cpu/','src/graph_provider_onednn/')):
        assert hashlib.sha256((repo/name).read_bytes()).hexdigest()==digest,name
        unchanged[name]=digest
proof={'mature_math_simd_and_assemblers_unchanged':unchanged,'basis':'CP immutable source manifest','not_inferred':'Does not replace current Native retirement correctness/delivery or final self performance verdict.'}
(fixture/'mature-identity.json').write_text(json.dumps(proof,indent=2)+'\n',encoding='utf-8',newline='\n')
loc=(repo/'.scratch/validation/cpu-native-final/retirement-loc/loc.json').read_bytes();(fixture/'loc.json').write_bytes(loc)
print(json.dumps({'unchanged_mature_simd_route_inputs':len(unchanged)}))
