import hashlib
import json
import xml.etree.ElementTree as ET
import zipfile
from pathlib import Path

repo = Path.cwd()
fixture = repo / '.scratch/validation/cpu-native-numeric-retirement'
evidence = repo / 'evidence/correctness/cpu-native-numeric-retirement'
manifest = json.loads((fixture / 'manifest.json').read_text())
for name, digest in manifest['files'].items():
    assert hashlib.sha256((repo / name).read_bytes()).hexdigest() == digest, name


def tests(path):
    root = ET.parse(path).getroot()
    cases = list(root.iter('testcase'))
    assert not any(case.find('failure') is not None or case.find('error') is not None for case in cases)
    skipped = [case.attrib.get('classname', '') + '.' + case.attrib['name']
               for case in cases if case.find('skipped') is not None]
    return dict(registered=len(cases), passed=len(cases) - len(skipped), skipped=skipped)


required = {'configure', 'batch-build', 'provider-tests', 'public-header',
            'compute_route_cpu-affected-tests','graph_route_cpu-affected-tests',
            *[stage + '-' + name for stage in ('shared', 'static')
              for name in ('producer-configure', 'producer-build', 'source-ordinary',
                           'install', 'consumer-configure', 'consumer-build', 'installed-ordinary')]}
result = dict(candidate=manifest['candidate'], fixture_commit=manifest['fixture_commit'],
              scope='ND-R1; retired numerically ineligible Native domains and mature ordinary migration',
              performance='P0; no self operator performance comparison', platforms={})
for platform in ('windows', 'linux'):
    folder = fixture / platform
    records = json.loads((folder / 'receipt.json').read_text())
    latest = {row['name']: row for row in records}
    assert not (required - latest.keys()), (platform, required - latest.keys())
    assert all(latest[name]['returncode'] == 0 for name in required), platform
    identity = json.loads((folder / 'source-identity.json').read_text())
    assert identity['candidate'] == manifest['candidate'] and identity['checked'] == len(manifest['files'])
    result['platforms'][platform] = dict(commands=len(records),
        actual_validation_commits=sorted({r['candidate'] for r in records}),
        tests={name: tests(folder / (name + '.xml')) for name in ('provider', 'compute_route_cpu','graph_route_cpu', 'header')},
        source_identity=identity, latest_commands_passed=sorted(required))
    cleanup = json.loads((folder / 'cleanup.json').read_text(encoding='utf-8-sig'))
    assert all(row['removed'] for row in cleanup)
    result['platforms'][platform]['cleanup'] = cleanup

loc = json.loads((fixture / 'loc.json').read_text(encoding='utf-8-sig'))
metric = next(row for row in loc['metrics'] if row['id'] == 'module')
result['mature_and_infra_identity'] = json.loads((fixture/'mature-identity.json').read_text())
result['loc'] = dict(code=metric['code'], files=metric['files'], commit=loc['repository']['commit'])
semantic = repo / '.scratch/validation/cpu-native-final'
semantic_records = json.loads((semantic / 'receipt.json').read_text())
assert all(r['candidate'] == manifest['candidate'] and r['returncode'] == 0 for r in semantic_records[-2:])
semantic_log = semantic / semantic_records[-1]['log']
lines = semantic_log.read_text().splitlines()
declined = [line.split('\t') for line in lines if line.startswith('DECLINED\t')]
executed = [line.split('\t') for line in lines if line.startswith('ROW\t')]
assert lines[-1] == 'SUMMARY rows=322 rejected=31 bad_rows=0 mature_bad_rows=0'
assert len(declined) == 31 and all(row[4] == 'Native' for row in declined)
assert len({(row[1], row[2]) for row in declined}) == 16
assert sum(row[4] == 'mature' for row in executed) == 161
result['post_retirement_semantic_witness'] = dict(candidate=manifest['candidate'],
    records=322, native_declined=31, retired_domains=16, mature_executed=161,
    executed_mismatch_rows=0, scope='Sampled witness; declines are not execution PASS',
    earlier_receipt_limit='Earlier witness receipts retain their stale cde6fb3a stamp; only the final pair binds the corrected immutable candidate.')
files = [(path, 'qualification/' + path.relative_to(fixture).as_posix())
         for path in fixture.rglob('*') if path.is_file() and path.suffix != '.obj']
for name in ('cpu-nd1-windows.py', 'cpu-nd1-linux.py', 'cleanup-cpu-nd1-windows.ps1',
             'cleanup-cpu-nd1-linux.py', 'cpu-ggml-wsl-launch.py', 'collect-cpu-nd1-evidence.py', 'setup-cpu-nd1-validation.py', 'prepare-cpu-nd1-evidence-tools.py'):
    files.append((repo / '.scratch' / name, 'drivers/' + name))
for name in ('src/compute_provider_native/elementwise.cc', 'src/compute_provider_native/native_provider.cc', 'src/compute_provider_native/transformer.cc',
             'tests/compute_provider_native/provider_shape_test.cc'):
    files.append((repo / name, 'source/' + name))
for name in ('semantic_probe.cc', 'semantic_reference.h', 'receipt.json',
             '13-same-contract-frozen-semantic-witness.log',
             semantic_records[-2]['log'], semantic_records[-1]['log']):
    files.append((semantic / name, 'semantic-witness/' + name))
files.append((repo / '.scratch/cpu-native-semantic-probe.py', 'drivers/cpu-native-semantic-probe.py'))
archive = evidence / 'qualification.zip'
evidence.mkdir(parents=True, exist_ok=True)
with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED) as z:
    for path, name in sorted(files, key=lambda row: row[1]):
        z.write(path, name)
result['artifact'] = dict(file='qualification.zip', entries=len(files), bytes=archive.stat().st_size,
    sha256=hashlib.sha256(archive.read_bytes()).hexdigest())
(evidence / 'receipt.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({key: result[key] for key in ('candidate', 'loc', 'artifact')}))
