#include "hyle/compute/providers/native.h"

#include <algorithm>
#include <array>
#include <cmath>
#include <cstdint>
#include <limits>
#include <new>
#include <span>
#include <utility>

#include "../compute/matmul_kernels.h"
#include "../compute/native_route.h"
#include "../compute/provider_internal.h"
#include "hyle/compute/prepared_operation.h"
#include "hyle/math/scalar.h"
#include "hyle/mem/resource.h"
#include "hyle/simd/fat_kernel.h"
#include "hyle/simd/math.h"
#include "hyle/simd/ops.h"
#include "native_plan.h"
#if defined(HYLE_COMPUTE_TORCH_CPU)
#include "torch_cpu_program.h"
#endif

namespace hyle::compute::native {
namespace {

using Parameters = detail::NativeParameters;
using Route = detail::NativeRoute;
using internal::aligned_for_storage;
using internal::completed;
using internal::NativePlan;
using internal::preserve_first_error;

struct NativeContext final {
  ParallelExecutorRef executor{};
};

struct NativeInvocation final {
  mem::BufferView workspace{};
};

inline constexpr std::size_t kMinimumParallelWorkItems = 16U * 1024U;

std::size_t saturating_product(std::size_t left, std::size_t right) noexcept {
  if (left == 0 || right == 0)
    return 0;
  if (left > (std::numeric_limits<std::size_t>::max)() / right)
    return (std::numeric_limits<std::size_t>::max)();
  return left * right;
}

std::size_t saturating_sum(std::size_t left, std::size_t right) noexcept {
  if (left > (std::numeric_limits<std::size_t>::max)() - right)
    return (std::numeric_limits<std::size_t>::max)();
  return left + right;
}

std::size_t recommended_parallel_tasks(ParallelExecutorRef executor,
                                       std::size_t units,
                                       std::size_t work_per_unit) noexcept {
  const std::size_t concurrency = executor.concurrency();
  if (concurrency <= 1 || units <= 1 || work_per_unit == 0)
    return 1;
  const std::size_t total = saturating_product(units, work_per_unit);
  const std::size_t work_limited =
      total / kMinimumParallelWorkItems +
      static_cast<std::size_t>(total % kMinimumParallelWorkItems != 0);
  return (std::max)(std::size_t{1},
                    (std::min)({concurrency, units, work_limited}));
}

void run_rms_norm(const float *input, const float *weight, float *output,
                  const Parameters &parameters, float epsilon) noexcept {
  const std::size_t rows = parameters[0];
  const std::size_t hidden = parameters[1];
  if (hidden == 0)
    return;
  for (std::size_t row = 0; row < rows; ++row) {
    const float *row_input = input + row * hidden;
    float *row_output = output + row * hidden;
    if (weight == nullptr)
      simd::rms_norm_f32(row_input, row_output, hidden, epsilon);
    else
      simd::rms_norm_f32(row_input, weight, row_output, hidden, epsilon);
  }
}

struct FloatRouteEpisode final {
  const NativePlan *plan = nullptr;
  const float *first = nullptr;
  const float *second = nullptr;
  float *output = nullptr;
};

void run_float_range(void *context, std::size_t, std::size_t begin,
                     std::size_t end) noexcept {
  auto &episode = *static_cast<FloatRouteEpisode *>(context);
  const NativePlan &plan = *episode.plan;
  Parameters parameters = plan.parameters;
  parameters[0] = end - begin;
  const float *first = episode.first + begin * plan.row_first_stride;
  const float *second = episode.second == nullptr || plan.row_second_stride == 0
                            ? episode.second
                            : episode.second + begin * plan.row_second_stride;
  float *output = episode.output + begin * plan.row_output_stride;
  plan.route(first, second, output, parameters, plan.scalar);
}

void run_matmul_transposed_weight(const float *left, const float *right,
                                  float *output, const Parameters &parameters,
                                  float) noexcept {
  const std::size_t rows = parameters[0];
  const std::size_t inner = parameters[1];
  const std::size_t columns = parameters[2];
  if (rows == 0 || columns == 0)
    return;
  if (inner == 0) {
    std::fill_n(output, rows * columns, 0.0F);
    return;
  }
  for (std::size_t row = 0; row < rows; ++row) {
    const float *left_row = left + row * inner;
    float *output_row = output + row * columns;
    for (std::size_t column = 0; column < columns; ++column)
      output_row[column] = simd::dot(left_row, right + column * inner, inner);
  }
}

Route select_row_major_matmul() noexcept {
#if HYLE_ARCH_X64
  return HYLE_SIMD_SELECT_FAT_KERNEL(
      &detail::run_matmul_row_major_scalar, &detail::run_matmul_row_major_sse4,
      &detail::run_matmul_row_major_avx2, &detail::run_matmul_row_major_avx512);
#elif HYLE_ARCH_ARM64
  return HYLE_SIMD_SELECT_FAT_KERNEL(&detail::run_matmul_row_major_scalar,
                                     &detail::run_matmul_row_major_neon,
                                     &detail::run_matmul_row_major_sve);
#elif HYLE_ARCH_RISCV64
  return HYLE_SIMD_SELECT_FAT_KERNEL(&detail::run_matmul_row_major_scalar,
                                     &detail::run_matmul_row_major_rvv);
#else
  return HYLE_SIMD_SELECT_FAT_KERNEL(&detail::run_matmul_row_major_scalar);
#endif
}

Status validate_logical_f32(const TensorDesc &description) noexcept {
  if (!description.valid())
    return Status::InvalidArgument("operation tensor description is invalid");
  if (description.data_type() != DataType::kFloat32) {
    return Status::Unimplemented(
        "HYLE native route currently requires float32 tensors");
  }
  return Status::Ok();
}

Status validate_dense_f32(const TensorDesc &description) noexcept {
  Status status = validate_logical_f32(description);
  if (!status.ok())
    return status;
  if (!description.is_plain() || !description.is_dense()) {
    return Status::Unimplemented(
        "HYLE native route requires dense plain tensor storage");
  }
  return Status::Ok();
}

bool has_row_major_matrix_layout(const TensorDesc &description) noexcept {
  if (!description.valid() || !description.is_plain() || description.rank() < 2)
    return false;
  const auto dimensions = description.dimensions();
  const auto strides = description.byte_strides();
  const std::size_t rank = description.rank();
  if (std::find(dimensions.begin(), dimensions.end(), 0) != dimensions.end())
    return true;
  const auto row_bytes = math::try_multiply(
      dimensions[rank - 1], static_cast<std::int64_t>(sizeof(float)));
  return row_bytes.has_value() &&
         strides[rank - 1] == static_cast<std::int64_t>(sizeof(float)) &&
         strides[rank - 2] == *row_bytes;
}

bool has_transposed_weight_layout(const TensorDesc &description) noexcept {
  if (!description.valid() || !description.is_plain() || description.rank() < 2)
    return false;
  const auto dimensions = description.dimensions();
  const auto strides = description.byte_strides();
  const std::size_t rank = description.rank();
  if (std::find(dimensions.begin(), dimensions.end(), 0) != dimensions.end())
    return true;
  const auto column_bytes = math::try_multiply(
      dimensions[rank - 2], static_cast<std::int64_t>(sizeof(float)));
  return column_bytes.has_value() &&
         strides[rank - 2] == static_cast<std::int64_t>(sizeof(float)) &&
         strides[rank - 1] == *column_bytes;
}

Result<std::size_t> matrix_batch_count(const TensorDesc &description) noexcept {
  std::size_t result = 1;
  const auto dimensions = description.dimensions();
  for (std::size_t axis = 0; axis + 2 < dimensions.size(); ++axis) {
    auto extent = math::try_integer_cast<std::size_t>(dimensions[axis]);
    if (!extent)
      return std::unexpected(
          Status::OutOfRange("MatMul batch dimension exceeds size_t"));
    auto next = math::try_multiply(result, *extent);
    if (!next)
      return std::unexpected(
          Status::OutOfRange("MatMul batch count overflows"));
    result = *next;
  }
  return result;
}

std::size_t matrix_batch_byte_offset(const TensorDesc &input,
                                     const TensorDesc &output,
                                     std::size_t output_batch) noexcept {
  const auto input_dimensions = input.dimensions();
  const auto input_strides = input.byte_strides();
  const auto output_dimensions = output.dimensions();
  const std::size_t input_batch_rank = input.rank() - 2;
  const std::size_t output_batch_rank = output.rank() - 2;
  std::size_t offset = 0;
  for (std::size_t reverse = 0; reverse < output_batch_rank; ++reverse) {
    const std::size_t output_axis = output_batch_rank - 1 - reverse;
    const std::size_t output_extent =
        static_cast<std::size_t>(output_dimensions[output_axis]);
    const std::size_t coordinate = output_batch % output_extent;
    output_batch /= output_extent;
    if (reverse >= input_batch_rank)
      continue;
    const std::size_t input_axis = input_batch_rank - 1 - reverse;
    if (input_dimensions[input_axis] != 1) {
      offset +=
          coordinate * static_cast<std::size_t>(input_strides[input_axis]);
    }
  }
  return offset;
}

Result<std::size_t> outer_count(const TensorDesc &description) noexcept {
  std::size_t result = 1;
  const auto dimensions = description.dimensions();
  for (std::size_t axis = 0; axis + 1 < dimensions.size(); ++axis) {
    auto value = math::try_integer_cast<std::size_t>(dimensions[axis]);
    if (!value)
      return std::unexpected(
          Status::OutOfRange("tensor dimension exceeds size_t"));
    auto next = math::try_multiply(result, *value);
    if (!next)
      return std::unexpected(Status::OutOfRange("tensor row count overflows"));
    result = *next;
  }
  return result;
}

Result<std::size_t> dimension(const TensorDesc &description,
                              std::size_t axis) noexcept {
  auto result =
      math::try_integer_cast<std::size_t>(description.dimensions()[axis]);
  if (!result)
    return std::unexpected(
        Status::OutOfRange("tensor dimension exceeds size_t"));
  return *result;
}

Status create_context(const Provider &provider_value, Device device, void *,
                      mem::AllocatorRef allocator,
                      void **context_output) noexcept {
  if (context_output == nullptr)
    return Status::InvalidArgument("native context output is null");
  *context_output = nullptr;
  if (device.device_class() != DeviceClass::kCpu)
    return Status::Unimplemented("HYLE native provider requires a CPU device");
  void *storage =
      allocator.allocate(sizeof(NativeContext), alignof(NativeContext));
  if (storage == nullptr)
    return Status::ResourceExhausted(
        "native provider context allocation failed");
  const Options options =
      detail::ProviderAccess::payload<Options>(provider_value);
  *context_output = ::new (storage) NativeContext{.executor = options.executor};
  return Status::Ok();
}

void destroy_context(void *context_value,
                     mem::AllocatorRef allocator) noexcept {
  auto *context = static_cast<NativeContext *>(context_value);
  if (context == nullptr)
    return;
  context->~NativeContext();
  allocator.deallocate(context, sizeof(NativeContext), alignof(NativeContext));
}

void destroy_prepared(void *state, mem::AllocatorRef allocator) noexcept {
  auto *plan = static_cast<NativePlan *>(state);
  if (plan == nullptr)
    return;
  plan->~NativePlan();
  allocator.deallocate(plan, sizeof(NativePlan), alignof(NativePlan));
}

Status create_invocation(void *prepared_value, mem::AllocatorRef allocator,
                         mem::BufferView workspace, void **output) noexcept {
  if (output == nullptr)
    return Status::InvalidArgument("native invocation output is null");
  *output = nullptr;
  const auto *plan = static_cast<const NativePlan *>(prepared_value);
  if (plan == nullptr)
    return Status::Internal("native prepared plan is null");
  if (plan->workspace_submit_route == nullptr)
    return Status::Ok();
  void *storage =
      allocator.allocate(sizeof(NativeInvocation), alignof(NativeInvocation));
  if (storage == nullptr)
    return Status::ResourceExhausted(
        "native invocation workspace state allocation failed");
  *output = ::new (storage) NativeInvocation{.workspace = workspace};
  return Status::Ok();
}

void destroy_invocation(void *value, mem::AllocatorRef allocator) noexcept {
  auto *invocation = static_cast<NativeInvocation *>(value);
  if (invocation == nullptr)
    return;
  invocation->~NativeInvocation();
  allocator.deallocate(invocation, sizeof(NativeInvocation),
                       alignof(NativeInvocation));
}

detail::EnqueueResult
submit_float(const NativePlan &plan, std::span<const ConstTensorView> inputs,
             std::span<const TensorView> outputs) noexcept {
  if (plan.route == nullptr || inputs.empty() || inputs.size() > 2 ||
      outputs.size() != 1) {
    return completed(Status::Internal("native float plan is invalid"));
  }

  auto output_elements = outputs[0].description().element_count();
  if (!output_elements)
    return completed(std::move(output_elements).error());
  if (*output_elements == 0)
    return completed(Status::Ok());

  const mem::ConstBufferView first_storage = inputs[0].storage();
  const mem::BufferView output_storage = outputs[0].storage();
  const bool in_place =
      first_storage.resource() == output_storage.resource() &&
      first_storage.native_handle() == output_storage.native_handle() &&
      first_storage.offset() == output_storage.offset() &&
      first_storage.size() == output_storage.size();
  mem::ConstBufferView second_storage;
  bool shared_inputs = false;
  if (inputs.size() == 2) {
    second_storage = inputs[1].storage();
    shared_inputs =
        first_storage.resource() == second_storage.resource() &&
        first_storage.native_handle() == second_storage.native_handle() &&
        first_storage.offset() == second_storage.offset() &&
        first_storage.size() == second_storage.size();
  }

  const mem::MemoryProperties first_properties =
      first_storage.resource().properties();
  const mem::MemoryProperties output_properties =
      output_storage.resource().properties();
  mem::MemoryProperties second_properties{};
  if (inputs.size() == 2)
    second_properties = second_storage.resource().properties();

  if (!first_properties.has(mem::MemoryProperty::kHostDeviceCoherent)) {
    Status status = first_storage.invalidate();
    if (!status.ok())
      return completed(std::move(status));
  }
  if (inputs.size() == 2 && !shared_inputs &&
      !second_properties.has(mem::MemoryProperty::kHostDeviceCoherent)) {
    Status status = second_storage.invalidate();
    if (!status.ok())
      return completed(std::move(status));
  }

  mem::HostMapping first_mapping;
  mem::HostMapping second_mapping;
  mem::HostMapping output_mapping;
  const float *first_data = nullptr;
  const float *second_data = nullptr;
  float *output_data = nullptr;

  if (in_place) {
    auto mapping = output_storage.map_host(mem::HostAccess::kReadWrite);
    if (!mapping)
      return completed(std::move(mapping).error());
    output_mapping = std::move(*mapping);
    auto writable = output_mapping.writable_bytes();
    if (!writable)
      return completed(std::move(writable).error());
    output_data = reinterpret_cast<float *>(writable->data());
    first_data = output_data;
  } else {
    auto mapping = first_storage.map_host();
    if (!mapping)
      return completed(std::move(mapping).error());
    first_mapping = std::move(*mapping);
    first_data = reinterpret_cast<const float *>(first_mapping.bytes().data());
  }

  if (inputs.size() == 2) {
    if (shared_inputs && !in_place) {
      second_data = first_data;
    } else {
      auto mapping = second_storage.map_host();
      if (!mapping) {
        first_mapping.close().IgnoreError();
        output_mapping.close().IgnoreError();
        return completed(std::move(mapping).error());
      }
      second_mapping = std::move(*mapping);
      second_data =
          reinterpret_cast<const float *>(second_mapping.bytes().data());
    }
  }

  if (!in_place) {
    auto mapping = output_storage.map_host(mem::HostAccess::kWrite);
    if (!mapping) {
      second_mapping.close().IgnoreError();
      first_mapping.close().IgnoreError();
      return completed(std::move(mapping).error());
    }
    output_mapping = std::move(*mapping);
    auto writable = output_mapping.writable_bytes();
    if (!writable) {
      output_mapping.close().IgnoreError();
      second_mapping.close().IgnoreError();
      first_mapping.close().IgnoreError();
      return completed(std::move(writable).error());
    }
    output_data = reinterpret_cast<float *>(writable->data());
  }

  const bool first_aligned = aligned_for_storage(
      first_data, inputs[0].description().required_alignment());
  const bool second_aligned =
      inputs.size() != 2 ||
      aligned_for_storage(second_data,
                          inputs[1].description().required_alignment());
  const bool output_aligned = aligned_for_storage(
      output_data, outputs[0].description().required_alignment());
  if (!first_aligned || !second_aligned || !output_aligned) {
    output_mapping.close().IgnoreError();
    second_mapping.close().IgnoreError();
    first_mapping.close().IgnoreError();
    return completed(Status::FailedPrecondition(
        "CPU operation tensor mapping does not satisfy its format alignment"));
  }

  FloatRouteEpisode episode{
      .plan = &plan,
      .first = first_data,
      .second = second_data,
      .output = output_data,
  };
  parallel_for_ranges(plan, plan.parameters[0], &run_float_range, &episode);
  Status terminal = Status::Ok();
  if (!output_properties.has(mem::MemoryProperty::kHostDeviceCoherent))
    preserve_first_error(terminal, output_mapping.flush());
  preserve_first_error(terminal, output_mapping.close());
  preserve_first_error(terminal, second_mapping.close());
  preserve_first_error(terminal, first_mapping.close());
  return completed(std::move(terminal));
}

detail::EnqueueResult
submit_zero_inner_matmul(const NativePlan &plan,
                         std::span<const ConstTensorView> inputs,
                         std::span<const TensorView> outputs) noexcept {
  if (plan.parameters[1] != 0 || inputs.size() != 2 || outputs.size() != 1) {
    return completed(
        Status::Internal("native zero-inner MatMul plan is invalid"));
  }

  auto output_elements = outputs[0].description().element_count();
  if (!output_elements)
    return completed(std::move(output_elements).error());
  if (*output_elements == 0)
    return completed(Status::Ok());

  const mem::BufferView output_storage = outputs[0].storage();
  auto output_result = output_storage.map_host(mem::HostAccess::kWrite);
  if (!output_result)
    return completed(std::move(output_result).error());
  mem::HostMapping output_mapping = std::move(*output_result);
  auto output_bytes = output_mapping.writable_bytes();
  if (!output_bytes) {
    output_mapping.close().IgnoreError();
    return completed(std::move(output_bytes).error());
  }
  auto *output = reinterpret_cast<float *>(output_bytes->data());
  if (!aligned_for_storage(output,
                           outputs[0].description().required_alignment())) {
    output_mapping.close().IgnoreError();
    return completed(Status::FailedPrecondition(
        "CPU MatMul output mapping does not satisfy tensor alignment"));
  }
  std::fill_n(output, *output_elements, 0.0F);

  Status terminal = Status::Ok();
  if (!output_storage.resource().properties().has(
          mem::MemoryProperty::kHostDeviceCoherent)) {
    preserve_first_error(terminal, output_mapping.flush());
  }
  preserve_first_error(terminal, output_mapping.close());
  return completed(std::move(terminal));
}

struct BatchedMatMulEpisode final {
  const NativePlan *plan = nullptr;
  const TensorDesc *left_description = nullptr;
  const TensorDesc *right_description = nullptr;
  const TensorDesc *output_description = nullptr;
  const std::byte *left = nullptr;
  const std::byte *right = nullptr;
  float *output = nullptr;
};

void run_batched_matmul_range(void *context, std::size_t, std::size_t begin,
                              std::size_t end) noexcept {
  auto &episode = *static_cast<BatchedMatMulEpisode *>(context);
  const NativePlan &plan = *episode.plan;
  const std::size_t rows = plan.parameters[0];
  const std::size_t inner = plan.parameters[1];
  const std::size_t columns = plan.parameters[2];
  if (rows == 0)
    return;

  while (begin < end) {
    const std::size_t batch = begin / rows;
    const std::size_t first_row = begin % rows;
    const std::size_t run_rows = (std::min)(end - begin, rows - first_row);
    const std::size_t left_batch_offset = matrix_batch_byte_offset(
        *episode.left_description, *episode.output_description, batch);
    const std::size_t right_batch_offset = matrix_batch_byte_offset(
        *episode.right_description, *episode.output_description, batch);
    const auto *left =
        reinterpret_cast<const float *>(episode.left + left_batch_offset) +
        first_row * inner;
    const auto *right =
        reinterpret_cast<const float *>(episode.right + right_batch_offset);
    float *output = episode.output + (batch * rows + first_row) * columns;
    const Parameters parameters{run_rows, inner, columns};
    plan.route(left, right, output, parameters, plan.scalar);
    begin += run_rows;
  }
}

detail::EnqueueResult
submit_batched_matmul(const NativePlan &plan,
                      std::span<const ConstTensorView> inputs,
                      std::span<const TensorView> outputs) noexcept {
  if (plan.route == nullptr || inputs.size() != 2 || outputs.size() != 1)
    return completed(Status::Internal("native batched MatMul plan is invalid"));

  auto output_elements = outputs[0].description().element_count();
  if (!output_elements)
    return completed(std::move(output_elements).error());
  if (*output_elements == 0)
    return completed(Status::Ok());

  const mem::ConstBufferView left_storage = inputs[0].storage();
  const mem::ConstBufferView right_storage = inputs[1].storage();
  const mem::BufferView output_storage = outputs[0].storage();
  const bool shared_inputs =
      left_storage.resource() == right_storage.resource() &&
      left_storage.native_handle() == right_storage.native_handle() &&
      left_storage.offset() == right_storage.offset() &&
      left_storage.size() == right_storage.size();

  Status status = Status::Ok();
  if (!left_storage.resource().properties().has(
          mem::MemoryProperty::kHostDeviceCoherent)) {
    status = left_storage.invalidate();
  }
  if (status.ok() && !shared_inputs &&
      !right_storage.resource().properties().has(
          mem::MemoryProperty::kHostDeviceCoherent)) {
    status = right_storage.invalidate();
  }
  if (!status.ok())
    return completed(std::move(status));

  auto left_result = left_storage.map_host();
  if (!left_result)
    return completed(std::move(left_result).error());
  mem::HostMapping left_mapping = std::move(*left_result);
  mem::HostMapping right_mapping;
  const std::byte *left = left_mapping.bytes().data();
  const std::byte *right = left;
  if (!shared_inputs) {
    auto right_result = right_storage.map_host();
    if (!right_result) {
      left_mapping.close().IgnoreError();
      return completed(std::move(right_result).error());
    }
    right_mapping = std::move(*right_result);
    right = right_mapping.bytes().data();
  }

  auto output_result = output_storage.map_host(mem::HostAccess::kWrite);
  if (!output_result) {
    right_mapping.close().IgnoreError();
    left_mapping.close().IgnoreError();
    return completed(std::move(output_result).error());
  }
  mem::HostMapping output_mapping = std::move(*output_result);
  auto output_bytes = output_mapping.writable_bytes();
  if (!output_bytes) {
    output_mapping.close().IgnoreError();
    right_mapping.close().IgnoreError();
    left_mapping.close().IgnoreError();
    return completed(std::move(output_bytes).error());
  }
  auto *output = reinterpret_cast<float *>(output_bytes->data());
  if (!aligned_for_storage(left,
                           inputs[0].description().required_alignment()) ||
      !aligned_for_storage(right,
                           inputs[1].description().required_alignment()) ||
      !aligned_for_storage(output,
                           outputs[0].description().required_alignment())) {
    output_mapping.close().IgnoreError();
    right_mapping.close().IgnoreError();
    left_mapping.close().IgnoreError();
    return completed(Status::FailedPrecondition(
        "CPU batched MatMul mapping does not satisfy tensor alignment"));
  }

  BatchedMatMulEpisode episode{
      .plan = &plan,
      .left_description = &inputs[0].description(),
      .right_description = &inputs[1].description(),
      .output_description = &outputs[0].description(),
      .left = left,
      .right = right,
      .output = output,
  };
  const std::size_t units = plan.count * plan.parameters[0];
  internal::parallel_for_ranges(plan, units, &run_batched_matmul_range,
                                &episode);

  Status terminal = Status::Ok();
  if (!output_storage.resource().properties().has(
          mem::MemoryProperty::kHostDeviceCoherent)) {
    preserve_first_error(terminal, output_mapping.flush());
  }
  preserve_first_error(terminal, output_mapping.close());
  preserve_first_error(terminal, right_mapping.close());
  preserve_first_error(terminal, left_mapping.close());
  return completed(std::move(terminal));
}

detail::EnqueueResult submit(void *prepared_value, void *invocation_value,
                             Queue &, std::span<const ConstTensorView> inputs,
                             std::span<const TensorView> outputs) noexcept {
  auto *plan = static_cast<NativePlan *>(prepared_value);
  if (plan == nullptr || (plan->submit_route == nullptr &&
                          plan->workspace_submit_route == nullptr)) {
    return completed(Status::Internal("native execution state is invalid"));
  }
  if (plan->workspace_submit_route != nullptr) {
    auto *invocation = static_cast<NativeInvocation *>(invocation_value);
    if (invocation == nullptr)
      return completed(Status::Internal("native workspace state is invalid"));
    return plan->workspace_submit_route(*plan, inputs, outputs,
                                        invocation->workspace);
  }
  return plan->submit_route(*plan, inputs, outputs);
}

AliasSupport alias_support(void *prepared_value, std::size_t output_index,
                           std::size_t input_index) noexcept {
  const auto *plan = static_cast<const NativePlan *>(prepared_value);
  if (plan == nullptr || output_index != 0 || input_index >= 8 ||
      (plan->alias_input_mask &
       (std::uint8_t{1} << static_cast<std::uint8_t>(input_index))) == 0) {
    return {};
  }
  return AliasSupport{
      .supported = true,
      .byte_offset = input_index == 0 ? plan->alias_input0_offset : 0,
  };
}

const detail::ProviderPreparedVTable kPreparedVTable{
    .destroy_prepared = &destroy_prepared,
    .alias_support = &alias_support,
    .create_invocation = &create_invocation,
    .destroy_invocation = &destroy_invocation,
    .shared_submit = &submit,
    .delegated_submit = nullptr,
};

constexpr ProviderRuntimeProperties kRuntimeProperties{
    .mode = ProviderRuntimeMode::kSharedQueue,
    .workspace_owner = ProviderWorkspaceOwner::kCaller,
    .replay_class = ProviderReplayClass::kPrepared,
    .blocks_host = true,
    .uses_private_threads = false,
    .supports_concurrent_invocations = true,
    .capture_compatible = false,
};

Status build_plan(Operation operation, std::span<const TensorDesc> inputs,
                  std::span<const TensorDesc> outputs, NativePlan &plan,
                  ParallelExecutorRef executor = {}) noexcept {
  if (outputs.size() != operation_traits(operation).outputs)
    return Status::Internal("native route output arity is invalid");

  plan = {};
  switch (operation.kind()) {
  case OperationKind::kView:
  case OperationKind::kCopy:
  case OperationKind::kFill: {
    Status status =
        internal::prepare_transform(operation, inputs, outputs, plan);
    if (!status.ok())
      return status;
    break;
  }
  case OperationKind::kCast: {
    Status status = internal::prepare_cast(operation, inputs, outputs, plan);
    if (!status.ok())
      return status;
    break;
  }
  case OperationKind::kCustom: {
    Status status =
        internal::prepare_ds4_quantization(operation, inputs, outputs, plan);
    if (!status.ok())
      return status;
    break;
  }
  case OperationKind::kUnary:
  case OperationKind::kBinary:
  case OperationKind::kSelect: {
    Status status =
        internal::prepare_elementwise(operation, inputs, outputs, plan);
    if (!status.ok())
      return status;
    break;
  }
  case OperationKind::kReduce: {
    Status status =
        internal::prepare_reduction(operation, inputs, outputs, plan);
    if (!status.ok())
      return status;
    break;
  }
  case OperationKind::kLayerNorm: {
    Status status =
        internal::prepare_normalization(operation, inputs, outputs, plan);
    if (!status.ok())
      return status;
    break;
  }
  case OperationKind::kRmsNorm: {
    if (operation.get_if<RmsNorm>()->accumulation_type != DataType::kFloat32)
      return Status::Unimplemented(
          "native RMSNorm supports float32 accumulation");
    if (inputs[0].data_type() == DataType::kFloat16 ||
        inputs[0].data_type() == DataType::kBFloat16) {
      Status status =
          internal::prepare_normalization(operation, inputs, outputs, plan);
      if (!status.ok())
        return status;
      break;
    }
    Status status = validate_dense_f32(inputs[0]);
    if (!status.ok())
      return status;
    if (inputs.size() == 2) {
      status = validate_dense_f32(inputs[1]);
      if (!status.ok())
        return status;
    }
    status = validate_dense_f32(outputs[0]);
    if (!status.ok())
      return status;
    auto rows = outer_count(inputs[0]);
    auto hidden = dimension(inputs[0], inputs[0].rank() - 1);
    if (!rows)
      return std::move(rows).error();
    if (!hidden)
      return std::move(hidden).error();
    plan.parameters = {*rows, *hidden, 0};
    plan.scalar = operation.get_if<RmsNorm>()->epsilon;
    plan.row_first_stride = *hidden;
    plan.row_output_stride = *hidden;
    plan.alias_input_mask = 1;
    plan.route = &run_rms_norm;
    plan.submit_route = &submit_float;
    break;
  }
  case OperationKind::kMatMul: {
    if (operation.get_if<MatMul>()->accumulation_type != DataType::kFloat32)
      return Status::Unimplemented(
          "native MatMul supports float32 accumulation");
    if (inputs.size() != 2 || inputs[0].rank() < 2 || inputs[1].rank() < 2)
      return Status::Internal("native MatMul shape is invalid");
    Status status = validate_logical_f32(inputs[0]);
    if (!status.ok())
      return status;
    status = validate_logical_f32(inputs[1]);
    if (!status.ok())
      return status;
    if (!has_row_major_matrix_layout(inputs[0])) {
      return Status::Unimplemented(
          "native MatMul requires contiguous rows in its left operand");
    }
    const bool right_row_major = has_row_major_matrix_layout(inputs[1]);
    const bool right_transposed = has_transposed_weight_layout(inputs[1]);
    if (!right_row_major && !right_transposed) {
      return Status::Unimplemented(
          "native MatMul requires row-major or transposed-weight matrix rows");
    }
    status = validate_dense_f32(outputs[0]);
    if (!status.ok())
      return status;
    auto rows = dimension(inputs[0], inputs[0].rank() - 2);
    auto inner = dimension(inputs[0], inputs[0].rank() - 1);
    auto columns = dimension(inputs[1], inputs[1].rank() - 1);
    auto output_elements = outputs[0].element_count();
    if (!rows)
      return std::move(rows).error();
    if (!inner)
      return std::move(inner).error();
    if (!columns)
      return std::move(columns).error();
    if (!output_elements)
      return std::move(output_elements).error();
    std::size_t batches = 0;
    if (*output_elements != 0) {
      auto batch_count = matrix_batch_count(outputs[0]);
      if (!batch_count)
        return std::move(batch_count).error();
      batches = *batch_count;
    }
    plan.parameters = {*rows, *inner, *columns};
    plan.count = batches;
    plan.row_first_stride = *inner;
    plan.row_output_stride = *columns;
    plan.route = right_row_major ? select_row_major_matmul()
                                 : &run_matmul_transposed_weight;
    if (*inner == 0) {
      plan.submit_route = &submit_zero_inner_matmul;
    } else {
      plan.submit_route = outputs[0].rank() == 2 && inputs[0].rank() == 2 &&
                                  inputs[1].rank() == 2
                              ? &submit_float
                              : &submit_batched_matmul;
    }
    break;
  }
  case OperationKind::kGatedActivation: {
    HYLE_RETURN_IF_ERROR(
        internal::prepare_half_gated(operation, inputs, outputs, plan));
    break;
  }
  case OperationKind::kGather:
  case OperationKind::kScatter:
  case OperationKind::kConcat: {
    Status status =
        internal::prepare_indexing(operation, inputs, outputs, plan);
    if (!status.ok())
      return status;
    break;
  }
  case OperationKind::kRoPE:
  case OperationKind::kSoftmax: {
    Status status =
        internal::prepare_transformer(operation, inputs, outputs, plan);
    if (!status.ok())
      return status;
    break;
  }
  case OperationKind::kScaledDotProductAttention: {
    const auto *attention = operation.get_if<ScaledDotProductAttention>();
    const std::size_t head_axis =
        attention->layout == AttentionLayout::kBatchSequenceHeadDepth ? 2 : 1;
    if (inputs.size() < 3 || inputs[0].rank() != 4 || inputs[1].rank() != 4 ||
        inputs[2].rank() != 4 ||
        inputs[0].dimensions()[head_axis] !=
            inputs[1].dimensions()[head_axis] ||
        inputs[0].dimensions()[head_axis] !=
            inputs[2].dimensions()[head_axis]) {
      return Status::Unimplemented("native SDPA requires equal Q/K/V heads");
    }
    Status status =
        internal::prepare_attention(operation, inputs, outputs, plan);
    if (!status.ok())
      return status;
    break;
  }
  default:
    return Status::Unimplemented(
        "operation has no current HYLE native executable route");
  }

  plan.executor = executor;
  std::size_t parallel_units = plan.parameters[0];
  std::size_t work_per_unit = 0;
  switch (operation.kind()) {
  case OperationKind::kRmsNorm:
  case OperationKind::kGatedActivation:
  case OperationKind::kLayerNorm:
    work_per_unit = plan.parameters[1];
    break;
  case OperationKind::kMatMul:
    parallel_units = saturating_product(plan.count, plan.parameters[0]);
    work_per_unit = saturating_product(plan.parameters[1], plan.parameters[2]);
    break;
  case OperationKind::kScaledDotProductAttention:
    work_per_unit = saturating_product(
        plan.attention_keys,
        saturating_sum(
            saturating_product(std::size_t{2}, plan.attention_query_depth),
            plan.attention_value_depth));
    break;
  default:
    break;
  }
  plan.parallel_tasks =
      recommended_parallel_tasks(executor, parallel_units, work_per_unit);
  if (operation.kind() == OperationKind::kScaledDotProductAttention) {
    auto workspace = math::try_multiply(plan.attention_workspace_stride,
                                        plan.parallel_tasks);
    if (!workspace)
      return Status::OutOfRange("native SDPA workspace size overflows");
    plan.workspace.size = *workspace;
  }
  return Status::Ok();
}

detail::ResourceBindingRequirement
host_requirement(const TensorDesc &description) noexcept {
  return detail::ResourceBindingRequirement{
      .required_properties = mem::MemoryProperty::kHostAccessible,
      .minimum_alignment = description.required_alignment(),
  };
}

Status
validate_bounded_rms(const detail::ProviderOperationRequest &request) noexcept {
  for (const auto &map : request.shape.inputs)
    if (map.layout != detail::ProviderTensorLayout::kDerived)
      return Status::Unimplemented(
          "native bounded RMSNorm requires derived dense input layouts");
  for (const auto &map : request.shape.outputs)
    if (map.layout != detail::ProviderTensorLayout::kDerived)
      return Status::Unimplemented(
          "native bounded RMSNorm requires derived dense output layouts");
  if (request.operation.kind() != OperationKind::kRmsNorm ||
      request.inputs.empty() || request.inputs.size() > 2 ||
      request.outputs.size() != 1)
    return Status::Unimplemented(
        "native bounded route currently requires RMSNorm");
  const auto &input = request.inputs[0];
  const auto &output = request.outputs[0];
  if (input.rank() == 0 || input.rank() != output.rank())
    return Status::Unimplemented("native bounded RMSNorm rank differs");
  const auto fixed = [&](std::uint32_t value) noexcept {
    return value == detail::kFixedShapeAxis ||
           request.shape.dimensions[value].bounds.exact();
  };
  if (!fixed(request.shape.inputs[0].values[input.rank() - 1]))
    return Status::Unimplemented(
        "native bounded RMSNorm requires fixed hidden width");
  // Equal envelopes of independent symbols are NOT a whole-domain proof.
  // Every output extent must be the same expression or the same fixed value.
  for (std::size_t axis = 0; axis < input.rank(); ++axis) {
    const auto left = request.shape.inputs[0].values[axis];
    const auto right = request.shape.outputs[0].values[axis];
    if (input.dimensions()[axis] != output.dimensions()[axis] ||
        (left != right && !(fixed(left) && fixed(right))))
      return Status::Unimplemented(
          "native bounded RMSNorm needs identical input/output axes");
  }
  if (request.inputs.size() == 2) {
    for (std::size_t axis = 0; axis < request.inputs[1].rank(); ++axis) {
      if (!fixed(request.shape.inputs[1].values[axis]))
        return Status::Unimplemented(
            "native bounded RMSNorm requires fixed scale shape");
    }
  }
  // RMSNorm's schema is shape-preserving, with fixed dtype, epsilon, hidden
  // width and optional scale. The axis proof above makes these conditions
  // invariant over the domain; this is not sampling an envelope as evidence.
  HYLE_ASSIGN_OR_RETURN(const auto inferred,
                        infer_single_output(request.operation, request.inputs));
  if (inferred != output)
    return Status::InvalidArgument(
        "native bounded RMSNorm output does not match its schema");
  return Status::Ok();
}

Status instantiate_rms(void *root, std::span<const TensorDesc> inputs,
                       std::span<const TensorDesc> outputs,
                       mem::AllocatorRef allocator,
                       detail::ProviderPrepared *instance) noexcept {
  if (root == nullptr || instance == nullptr || inputs.empty() ||
      outputs.size() != 1)
    return Status::InvalidArgument(
        "native RMSNorm instance request is invalid");
  *instance = {};
  NativePlan concrete = *static_cast<const NativePlan *>(root);
  if (inputs[0].rank() == 0 ||
      inputs[0].dimensions().back() !=
          static_cast<std::int64_t>(concrete.parameters[1]))
    return Status::Internal(
        "native RMSNorm instance changed compiled hidden width");
  HYLE_ASSIGN_OR_RETURN(const auto rows, outer_count(inputs[0]));
  concrete.parameters[0] = rows;
  concrete.parallel_tasks = recommended_parallel_tasks(concrete.executor, rows,
                                                       concrete.parameters[1]);
  // Rebind scalar metadata only. Kernel, precision, alias and resource route
  // were compiled once; no build_plan(), proposal, prepare or SIMD dispatch.
  void *storage = allocator.allocate(sizeof(NativePlan), alignof(NativePlan));
  if (storage == nullptr)
    return Status::ResourceExhausted(
        "native RMSNorm instance allocation failed");
  *instance = {.vtable = &kPreparedVTable,
               .state = ::new (storage) NativePlan(concrete),
               .workspace = concrete.workspace,
               .runtime = kRuntimeProperties,
               .persistent_bytes = sizeof(NativePlan),
               .invocation_private_bytes = 0};
  return Status::Ok();
}

Status validate_bounded_copy(
    const detail::ProviderOperationRequest &request) noexcept {
  if (request.inputs.size() != 1 || request.outputs.size() != 1 ||
      !request.inputs[0].is_plain() || !request.outputs[0].is_plain() ||
      !request.outputs[0].is_dense() ||
      request.shape.outputs[0].layout !=
          detail::ProviderTensorLayout::kDerived ||
      request.inputs[0].data_type() != request.outputs[0].data_type() ||
      request.inputs[0].rank() != request.outputs[0].rank())
    return Status::Unimplemented(
        "native bounded Copy requires plain input and canonical dense output");
  const auto fixed = [&](std::uint32_t value) noexcept {
    return value == detail::kFixedShapeAxis ||
           request.shape.dimensions[value].bounds.exact();
  };
  for (std::size_t axis = 0; axis < request.inputs[0].rank(); ++axis) {
    const auto left = request.shape.inputs[0].values[axis];
    const auto right = request.shape.outputs[0].values[axis];
    if (request.inputs[0].dimensions()[axis] !=
            request.outputs[0].dimensions()[axis] ||
        (left != right && !(fixed(left) && fixed(right))))
      return Status::Unimplemented(
          "native bounded Copy needs identical input/output axes");
  }
  // Copy's input can have any checked non-negative strides, including zero.
  // Its output schema is dense, shape/dtype preserving and never aliases.
  return Status::Ok();
}

Status
validate_bounded(const detail::ProviderOperationRequest &request) noexcept {
  return request.operation.kind() == OperationKind::kCopy
             ? validate_bounded_copy(request)
             : validate_bounded_rms(request);
}

Status instantiate_copy(void *root, std::span<const TensorDesc> inputs,
                        std::span<const TensorDesc> outputs,
                        mem::AllocatorRef allocator,
                        detail::ProviderPrepared *instance) noexcept {
  if (root == nullptr || instance == nullptr || inputs.size() != 1 ||
      outputs.size() != 1)
    return Status::InvalidArgument("native Copy instance request is invalid");
  *instance = {};
  void *storage = allocator.allocate(sizeof(NativePlan), alignof(NativePlan));
  if (storage == nullptr)
    return Status::ResourceExhausted("native Copy instance allocation failed");
  const auto &plan = *static_cast<const NativePlan *>(root);
  *instance = {.vtable = &kPreparedVTable,
               .state = ::new (storage) NativePlan(plan),
               .workspace = plan.workspace,
               .runtime = kRuntimeProperties,
               .persistent_bytes = sizeof(NativePlan),
               .invocation_private_bytes = 0};
  return Status::Ok();
}

Status
propose(void *context_value, const detail::ProviderOperationRequest &request,
        std::span<detail::ResourceBindingRequirement> input_requirements,
        std::span<detail::ResourceBindingRequirement> output_requirements,
        detail::ProviderOperationProposal *proposal) noexcept {
  if (proposal == nullptr)
    return Status::InvalidArgument("native proposal output is null");
  *proposal = {};
  if (!request.shape.exact()) {
    HYLE_RETURN_IF_ERROR(validate_bounded(request));
  }
  const Operation operation = request.operation;
  const auto inputs = request.inputs;
  const auto outputs = request.outputs;
  if (input_requirements.size() != inputs.size() ||
      output_requirements.size() != outputs.size()) {
    return Status::InvalidArgument(
        "native proposal requirement counts do not match bindings");
  }

  auto *context = static_cast<NativeContext *>(context_value);
  if (context == nullptr)
    return Status::Internal("native provider context is null");
#if defined(HYLE_COMPUTE_TORCH_CPU)
  if (internal::is_torch_cpu_operation(operation, inputs))
    return internal::propose_torch_cpu(request, input_requirements,
                                       output_requirements, proposal);
#endif
  NativePlan plan{};
  Status status =
      build_plan(operation, inputs, outputs, plan, context->executor);
  if (!status.ok())
    return status;
  for (std::size_t index = 0; index < inputs.size(); ++index)
    input_requirements[index] = host_requirement(inputs[index]);
  for (std::size_t index = 0; index < outputs.size(); ++index)
    output_requirements[index] = host_requirement(outputs[index]);
  *proposal = detail::ProviderOperationProposal{
      .route = static_cast<std::uint64_t>(operation.kind()),
      .runtime = kRuntimeProperties,
      .workspace_resource =
          detail::ResourceBindingRequirement{
              .required_properties = mem::MemoryProperty::kHostAccessible,
          },
      .cost =
          ProviderRouteCostFacts{
              .workspace = plan.workspace,
              .persistent_bytes = sizeof(NativePlan),
              .copy_bytes = 0,
              .repack_bytes = 0,
              .synchronization_count = 0,
              .dispatch_count = 1,
              .compilation_storage = {.resident_bytes = 0, .peak_bytes = 0},
          },
      .shape_coverage = request.shape.exact()
                            ? detail::ProviderShapeCoverage::kExactPoint
                            : detail::ProviderShapeCoverage::kEntireDomain,
      .implementation =
          ProviderImplementationId{
              static_cast<std::uint64_t>(operation.kind()) + 1 +
              (request.shape.exact() ? 0 : (std::uint64_t{1} << 32))},
  };
  return Status::Ok();
}

ProviderPrepareOutcome
prepare(void *context_value, const detail::ProviderPrepareRequest &request,
        mem::AllocatorRef allocator,
        detail::ProviderPrepared *prepared_output) noexcept {
  if (prepared_output == nullptr)
    return ProviderPrepareOutcome::error(
        Status::InvalidArgument("native prepared output is null"));
  *prepared_output = {};
  if (request.input_resources.size() != request.inputs.size() ||
      request.output_resources.size() != request.outputs.size() ||
      request.route != static_cast<std::uint64_t>(request.operation.kind())) {
    return ProviderPrepareOutcome::error(
        Status::InvalidArgument("native exact prepare request is invalid"));
  }
  auto *context = static_cast<NativeContext *>(context_value);
  if (context == nullptr)
    return ProviderPrepareOutcome::error(
        Status::Internal("native provider context is null"));
#if defined(HYLE_COMPUTE_TORCH_CPU)
  if (internal::is_torch_cpu_operation(request.operation, request.inputs))
    return internal::prepare_torch_cpu(request, allocator, prepared_output);
#endif
  if (!request.shape.exact()) {
    const auto status = validate_bounded(
        {request.operation, request.inputs, request.outputs, request.shape});
    if (!status.ok())
      return status.IsUnimplemented()
                 ? ProviderPrepareOutcome::unsupported(status)
                 : ProviderPrepareOutcome::error(status);
  }
  NativePlan plan{};
  Status status = build_plan(request.operation, request.inputs, request.outputs,
                             plan, context->executor);
  if (!status.ok()) {
    return status.IsUnimplemented()
               ? ProviderPrepareOutcome::unsupported(std::move(status))
               : ProviderPrepareOutcome::error(std::move(status));
  }

  void *storage = allocator.allocate(sizeof(NativePlan), alignof(NativePlan));
  if (storage == nullptr) {
    return ProviderPrepareOutcome::resource_declined(
        Status::ResourceExhausted("native plan allocation failed"));
  }
  auto *prepared = ::new (storage) NativePlan(plan);
  prepared_output->vtable = &kPreparedVTable;
  prepared_output->state = prepared;
  prepared_output->workspace = plan.workspace;
  prepared_output->runtime = kRuntimeProperties;
  prepared_output->persistent_bytes = sizeof(NativePlan);
  prepared_output->invocation_private_bytes = 0;
  prepared_output->instantiate =
      request.shape.exact()                              ? nullptr
      : request.operation.kind() == OperationKind::kCopy ? &instantiate_copy
                                                         : &instantiate_rms;
  return ProviderPrepareOutcome::prepared();
}

Status drain_context(void *) noexcept { return Status::Ok(); }

const detail::ProviderVTable kProviderVTable{
    .identity =
        ProviderIdentity{.id = kProviderId,
                         .name = "hyle-native",
#if defined(HYLE_COMPUTE_TORCH_CPU)
                         .version =
                             "2+torchao-a701b6a60587+libtorch-2.8.0-cpu"},
#else
                         .version = "2"},
#endif
    .create_context = &create_context,
    .destroy_context = &destroy_context,
    .propose = &propose,
    .prepare = &prepare,
    .drain_context = &drain_context,
};

} // namespace

Provider provider(Options options) noexcept {
  return detail::ProviderAccess::make(&kProviderVTable, options);
}

} // namespace hyle::compute::native
