#include "hyle/compute/cpu.h"
#include "hyle/compute/prepared_operation.h"
#include "hyle/compute/providers/native.h"
#include "hyle/graph/cpu.h"
#include <array>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <limits>
#include <span>
#include <vector>

namespace c = hyle::compute;
namespace g = hyle::graph;
namespace m = hyle::mem;
template <class T> T take(hyle::Result<T> value) {
  if (!value) {
    std::fprintf(stderr, "%.*s\n", int(value.error().message().size()),
                 value.error().message().data());
    std::exit(2);
  }
  return std::move(*value);
}
void require(hyle::Status value) {
  if (!value.ok()) {
    std::fprintf(stderr, "%.*s\n", int(value.message().size()),
                 value.message().data());
    std::exit(2);
  }
}
c::TensorDesc desc(c::DataType type,
                   std::initializer_list<std::int64_t> dimensions,
                   bool odd = false) {
  if (!odd)
    return take(
        c::TensorDesc::dense(type, {dimensions.begin(), dimensions.size()}));
  std::vector<std::int64_t> strides(dimensions.size());
  auto n = std::int64_t(c::data_type_size(type) + 1);
  for (std::size_t i = dimensions.size(); i-- > 0;) {
    strides[i] = n;
    n = n * dimensions.begin()[i] + 1;
  }
  return take(c::TensorDesc::strided_bytes(
      type, {dimensions.begin(), dimensions.size()}, strides));
}
m::Buffer allocate(const c::TensorDesc &d) {
  return take(
      m::Buffer::create(m::system_resource(), take(d.required_bytes()), 64));
}
std::size_t offset(const c::TensorDesc &d, std::size_t linear) {
  std::size_t out = 0;
  for (std::size_t i = d.rank(); i-- > 0;) {
    out += linear % std::size_t(d.dimensions()[i]) *
           std::size_t(d.byte_strides()[i]);
    linear /= std::size_t(d.dimensions()[i]);
  }
  return out;
}
template <class T>
void write(m::Buffer &b, const c::TensorDesc &d, std::span<const T> values) {
  std::vector<std::byte> bytes(b.size());
  for (std::size_t i = 0; i < values.size(); ++i)
    std::memcpy(bytes.data() + offset(d, i), &values[i], sizeof(T));
  require(b.view().write(bytes));
}
void compare(const m::Buffer &b, std::span<const float> expected) {
  std::vector<float> x(expected.size());
  require(b.view().read(std::as_writable_bytes(std::span(x))));
  for (std::size_t i = 0; i < x.size(); ++i) {
    bool match = std::isnan(expected[i]) ? std::isnan(x[i])
                 : std::isinf(expected[i])
                     ? x[i] == expected[i]
                     : std::abs(x[i] - expected[i]) <=
                           1e-6F + std::abs(expected[i]) * 8e-5F;
    if (!match) {
      std::fprintf(stderr, "Mismatch %zu actual=%g expected=%g\n", i, x[i],
                   expected[i]);
      std::exit(3);
    }
  }
}
template <class Fill, class Check>
void journey(c::Operation op, std::span<const c::TensorDesc> inputs, Fill fill,
             Check check) {
  std::vector<m::Buffer> buffers;
  for (const auto &d : inputs)
    buffers.push_back(allocate(d));
  auto context = take(c::cpu::create_context());
  auto queue = take(context.create_queue());
  const auto output = take(c::infer_single_output(op, inputs));
  auto native_context = take(c::Context::create(c::cpu::device(), c::native::provider()));
  auto declined = c::prepare(native_context, op, inputs, std::span(&output, 1), m::system_resource());
  if (declined || !declined.error().IsUnimplemented()) std::exit(9);
  auto prepared = take(c::prepare(context, op, inputs, std::span(&output, 1),
                                  m::system_resource()));
  if (prepared.provider().id != c::aten_cpu::kProviderId) {
    std::fprintf(stderr, "Unqualified default carrier %.*s\n",
                 int(prepared.provider().name.size()),
                 prepared.provider().name.data());
    std::exit(4);
  }
  auto invocation = take(prepared.create_invocation());
  auto direct = allocate(output), graph_output = allocate(output);
  std::vector<c::ConstTensorView> views;
  for (std::size_t i = 0; i < inputs.size(); ++i)
    views.push_back(
        take(c::ConstTensorView::create(inputs[i], buffers[i].view())));
  const std::array destination{
      take(c::TensorView::create(output, direct.view()))};
  auto builder = take(g::GraphBuilder::create());
  std::vector<g::ValueId> ids;
  for (const auto &d : inputs)
    ids.push_back(take(builder.input(d)));
  auto node = take(builder.add_node(op, ids));
  auto result = take(builder.result(node));
  auto final = take(builder.add(c::Copy{}, result));
  require(builder.publish(final));
  auto logical = take(std::move(builder).finish());
  auto gc = take(g::cpu::create_context());
  auto gq = take(gc.create_queue());
  auto compiled = take(g::compile(logical, gc));
  const std::array only_native{c::native::kProviderId};
  g::CompileOptions restricted{};
  restricted.allowed_providers = only_native;
  if (g::compile(logical, gc, restricted)) std::exit(10);
  auto gi = take(compiled.executable.create_invocation());
  bool aten = false;
  for (std::size_t i = 0; i < compiled.report.step_count(); ++i)
    aten |=
        take(compiled.report.step(i)).provider.id == c::aten_cpu::kProviderId;
  if (!aten)
    std::exit(5);
  for (std::size_t i = 0; i < ids.size(); ++i)
    require(gi.bind(ids[i], views[i]));
  require(
      gi.bind(final, take(c::TensorView::create(output, graph_output.view()))));
  const std::array lanes{
      g::QueueBinding{.lane = g::ExecutionLaneId{0}, .queue = &gq}};
  require(gi.prepare_replay(lanes));
  for (int replay = 0; replay < 2; ++replay) {
    fill(buffers, replay);
    require(take(invocation.submit(queue, views, destination)).wait());
    require(take(gi.submit(gq)).wait());
    check(direct, replay);
    check(graph_output, replay);
  }
  require(context.close());
  require(gc.close());
  if (invocation.submit(queue, views, destination) || gi.submit(gq))
    std::exit(6);
}

double activate(double x,int kind){
 if(kind==1)return .5*x*std::erfc(-x/std::sqrt(2.));
 const double inner=kind==2?2*std::sqrt(2/std::acos(-1.))*(x+.044715*x*x*x):x;
 const double e=std::exp(-std::abs(inner));return x*(inner<0?e/(1+e):1/(1+e));
}
int main(){
 const auto f=c::DataType::kFloat32;
 const auto d=desc(f,{1,4});
 const std::array<float,4> values{-100,-6,-5,2};
 for(int kind=0;kind<3;++kind){
  const auto unary=kind==0?c::UnaryKind::kSilu:kind==1?c::UnaryKind::kGelu:c::UnaryKind::kGeluTanh;
  journey(c::Operation(c::Unary{unary}),std::array{d},
   [&](auto &b,int seed){auto x=values;x[3]+=float(seed);write<float>(b[0],d,x);},
   [&](const auto &b,int seed){std::array<float,4> x;for(int i=0;i<4;++i)x[i]=float(activate(values[i]+(i==3?seed:0),kind));compare(b,x);});
  for(bool packed:{false,true}){
   const auto input=desc(f,packed?std::initializer_list<std::int64_t>{1,8}:std::initializer_list<std::int64_t>{1,4});
   std::vector<c::TensorDesc> ds{input};if(!packed)ds.push_back(d);
   journey(c::Operation(c::GatedActivation{.activation=c::GatedActivationKind(kind),.inputs=packed?c::GatedInputKind::kPackedHalves:c::GatedInputKind::kSeparate}),ds,
    [&](auto &b,int seed){auto x=values;x[3]+=float(seed);const std::array<float,4> v{1e38F,1e30F,1e30F,1};
     if(packed){std::array<float,8> all;std::copy(x.begin(),x.end(),all.begin());std::copy(v.begin(),v.end(),all.begin()+4);write<float>(b[0],input,all);}
     else{write<float>(b[0],input,x);write<float>(b[1],d,v);}},
    [&](const auto &b,int seed){std::array<float,4> x;const std::array<float,4> v{1e38F,1e30F,1e30F,1};for(int i=0;i<4;++i)x[i]=float(activate(values[i]+(i==3?seed:0),kind))*v[i];compare(b,x);});
  }
 }
 const std::array ds{desc(f,{1,2,1,4}),desc(c::DataType::kInt64,{2}),desc(f,{2})};
 journey(c::Operation(c::RoPE{.rotary_dimensions=4,.sequence_axis=1}),ds,
  [&](auto &b,int seed){std::array<float,8>x;for(int i=0;i<8;++i)x[i]=float(i+1+seed);const std::array<std::int64_t,2>p{2147483651LL,-2147483651LL};const std::array<float,2>freq{.125,.25};write<float>(b[0],ds[0],x);write<std::int64_t>(b[1],ds[1],p);write<float>(b[2],ds[2],freq);},
  [&](const auto &b,int seed){std::array<float,8>x;for(int row=0;row<2;++row)for(int pair=0;pair<2;++pair){const double p=row?-2147483651.:2147483651.,angle=p*(pair?.25:.125),a=row*4+pair*2+1+seed,z=a+1;x[row*4+pair*2]=float(a*std::cos(angle)-z*std::sin(angle));x[row*4+pair*2+1]=float(a*std::sin(angle)+z*std::cos(angle));}compare(b,x);});
 std::puts("PASS ordinary mature retired-domain Direct/Graph tails/gates/long I64/replay/close; Native and Native-only Graph reject");
}
