"""Publish the scoped natural-turn/replay implementation and actual evidence."""
from pathlib import Path
import difflib,hashlib,json,subprocess,zipfile
Z=Path(__file__).resolve().parent;R=Z.parents[1];O=R/'docs/evidence/correctness';NAME='qwen-mtp-resume-2026-10-22'
def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def save(p,d):Path(p).write_text(json.dumps(d,indent=2,ensure_ascii=False,allow_nan=False)+'\n',encoding='utf-8')
def identity(p):
 p=Path(p);h=hashlib.sha256()
 with p.open('rb')as f:
  for block in iter(lambda:f.read(8<<20),b''):h.update(block)
 return dict(path=str(p.resolve()),bytes=p.stat().st_size,sha256=h.hexdigest())
sources=['tools/qwen35_text/'+n for n in ['main.cc','mtp_session_probe.cc','mtp_graph.h','mtp_schedule.h','session_schedule.h','schedule.h','README.md']]+['docs/developer/current-work.md']
frozen=[]
for name in sources:
 p=R/name;before=Z/'before'/name;snapshot=Z/'current'/name;snapshot.parent.mkdir(parents=True,exist_ok=True);snapshot.write_bytes(p.read_bytes())
 previous=before.read_text(encoding='utf-8-sig')if before.exists()else''
 diff=Z/'product-diffs'/(name.replace('/','--')+'.diff');diff.parent.mkdir(exist_ok=True)
 diff.write_text(''.join(difflib.unified_diff(previous.splitlines(True),p.read_text(encoding='utf-8-sig').splitlines(True),fromfile='before/'+name,tofile=name)),encoding='utf-8')
 if before.exists():
  check=subprocess.run(['git','diff','--no-index','--check',str(before),str(p)],capture_output=True,text=True,encoding='utf-8',errors='replace')
  assert check.returncode in(0,1)and not(check.stdout.strip()or check.stderr.strip()),(name,check.stdout,check.stderr)
 else:assert all(line.rstrip()==line for line in p.read_text().splitlines())
 frozen.append(dict(source=identity(p),snapshot=identity(snapshot),before=identity(before)if before.exists()else None,diff=identity(diff)))
save(Z/'product-freeze.json',dict(files=frozen))
ready={}
for tag in ['qwen','mtp_session']:
 record=read(Z/f'{tag}-ready-attempt2.json')
 assert all(identity(record[k]['path'])==record[k]for k in('image','source','main'))
 compiled=read(read(record['link_plan']['path'])['compiled_record']['path'])
 assert all(identity(v['path'])==v for v in compiled['dependencies'])
 ready[tag]=record
probe=read(Z/'probe-run1/vectors/observation.json')
assert probe['status']=='PASS_BYTE_EXACT'and probe['actual_graph_calls']==12 and len(probe['vectors'])==216 and probe['final_live_snapshot_versions']==0
cli=read(Z/'review/actual-analysis.json');work=read(Z/'review/cli-work-analysis.json')
assert cli['status'].startswith('PASS')and work['status'].startswith('PASS')
assert len(cli['raw_files'])==1912 and len(cli['byte_exact_comparisons'])==1184
reports={p.name:read(p)for p in sorted((Z/'review').glob('*.json'))if p.name not in('cli-analysis.json','resume-design.json','resume-validation-design.json')}
runs=[]
for directory in [Z/'probe-run1',*sorted((Z/'cli-runs1').iterdir())]:
 terminal=read(directory/'run.result.json');assert terminal['terminal']and terminal['exit']==0
 runs.append(dict(command=terminal['command'],terminal=identity(directory/'run.result.json'),stdout=identity(directory/'run.stdout.log'),stderr=identity(directory/'run.stderr.log'),diagnostic=True,performance_evidence=False))
assert len(runs)==8
errors=read(Z/'review/errors-analysis.json');assert len(errors['cases'])==8 and errors['model_weight_loads']==errors['GPU_inference_runs']==0
summary=dict(status='CUDA R1 MTP faithful generated-state rebuild and natural multi-turn input implemented; finite actual checks passed; broader goal remains active',date='2026-10-22',
 product_freeze=identity(Z/'product-freeze.json'),ready=ready,actual_runs=runs,actual_diagnostic_model_processes=8,early_validation_processes=8,
 build_scope=dict(host_compile_attempts=4,successful_host_compiles=4,successful_links=3,final_consumer_TUs=2,library_TUs=0,SDK_builds=0,NVCC_builds=0,full_configures=0,reused_link_inputs_per_consumer=194,
  superseded='Attempt1 host objects and the Qwen link were produced before a shared manifest metadata max_size bug was fixed. They were never run. Both host TUs were recompiled as attempt2 with the corrected header; all actual runs use attempt2.'),
 reports=reports,probe=probe,probe_analysis=read(Z/'probe/actual-analysis.json'),performance_window_performed=False,
 findings=[
  'One shared335 Model, original ordinary Graph/Queue/Completion and14-bank append transaction remain authoritative. No new executor, native provider path, GPU shadow state or public API was added.',
  'The natural MTP-only promptFILE/generateCOUNT grammar supports multiple turns; a single prompt/steps remains shorthand. Fixed decode tapes are rejected clearly. Both schedule grammars share bounded token-file parsing and manifest identity/path rules.',
  'A preallocated consumer-private typed ledger records actual roles, original chunks, quota, freshly computed draft/target decisions, accepted boundary and target/draft/carry metadata. After the complete head swap a no-allocation witness records the real commit before trace/report IO. Request output/round progress consumes that witness using cold-reserved buffers.',
  'A generated head is rebuilt with the original T1/T2 roles, shapes and quotas, recomputing natural proposals and checking immutable observations before publication. All old GPU heads are actually retired first under N1; only CPU tokens/observations remain. A fresh Session is returned only after the entire replay succeeds.',
  'Generating heads are protected; turn-idle heads may be evicted by bounded LRU. New prompt input is exactly old pending plus new user IDs. Lag1 draft catchup uses prior/carry/new target rows in the same warm Graph and writes only required draft K/V.',
  'Actual C64 three-session/two-turn CLI produced26 outputs. N3 used19 Graph calls. N1 performed3 real idle evictions/restores and29 calls=19+10, with66 restored target rows and63 draft rows. Warm target25/draft26 and target2/draft3, lag0 and EOS followed by another turn were exercised.',
  'N2 prefixauto performed a real complete initial prompt hit, imported its original prompt provenance into the ledger, then evicted/restored that request. It used28 Graph calls=18 logical+10 replay, without fabricating payloads for the zero-Graph hit.',
  'The permanent resume probe used12 actual Graph calls=11positive+1wrong expected metadata. Four54-component images yielded216 finite byte-identical metrics; the final recovered original quota1 state is L19/D19/lag0. Wrong metadata rejected before publishing a rebuilt head; a postcommit filesystem error retained exactly one authoritative commit and successful subsequent replay/continuation.',
  'Host checks validated1912 CLI numeric payloads and1184 same-partition byte-equal pairs, including all10 replay episodes under N1 and N2. The probe retains216 unique baseline payloads. Eight invalid-input processes rejected before model weight loading.',
  'Actual Graph/target/draft work includes replay, which remains inside the next logical prefill wall. Replay adds no logical new output. Global P/D are disjoint intervals summing to one wall; per-Session P/D plus explicit between-turn idle equal that Session wall. No throughput or physical-memory comparison was run.'],
 limitations=[
  'Finite same-device CUDA BF16 Qwen tests do not prove all supported model/quant routes, cross-provider deterministic rebuild, GPU serving concurrency or full model quality. A replay decision mismatch is an explicit failure, not forced old-token feedback.',
  'N3 original same-role/partition payloads are the oracle for N1/N2 replay and continuation, not an independent mathematical or quality reference. Intermediate replay transitions are checked by the typed ledger; the probe independently reads only the final restored54-component images.',
  'Six payloads for the short target2/draft3 new turn and its later generation are finite/structurally checked without an independent same-partition numerical oracle; no stronger numerical claim is made.',
  'MTP R>1 batching, other native backends and selected-model/quant coverage, image projection, capture-invalidations/performance and the full architecture audit remain active.',
  'No new performance or physical-memory window was run. The previous complete four-metric table remains authoritative.'],
 previous_evidence=['docs/evidence/correctness/qwen-mtp-prefix-2026-10-22.json','docs/evidence/correctness/qwen-mtp-sessions-2026-10-22.json','docs/evidence/performance/qwen-mtp-divergence-2026-10-22.json'],
 remaining=['Extend applicable real MTP batch execution without duplicating execution/state mechanisms.','Continue other backend/model/quant, image projector and architecture/performance work.'])
save(Z/'actual-summary.json',summary)
excluded={'.exe','.dll','.obj','.map','.lib','.exp','.pdb','.pyc'}
files=sorted(p for p in Z.rglob('*')if p.is_file()and p.suffix.lower()not in excluded and not any(v in('tmp','__pycache__')for v in p.relative_to(Z).parts)and p.name not in('published.json','cleanup-plan.json','cleanup-result.json','cleanup_script.ps1'))
archive=O/(NAME+'.data.zip');assert not archive.exists();entries=[];unique={}
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=6)as z:
 for p in files:
  e=identity(p);key=(e['bytes'],e['sha256']);canonical=unique.get(key)
  if canonical is None:canonical=p.relative_to(R).as_posix();unique[key]=canonical;z.write(p,canonical)
  else:e['identical_content_alias']=True
  e['entry']=canonical;entries.append(e)
with zipfile.ZipFile(archive)as z:
 assert z.testzip()is None and len(z.namelist())==len(unique)
 for(size,sha),entry in unique.items():
  raw=z.read(entry);assert len(raw)==size and hashlib.sha256(raw).hexdigest()==sha
manifest=O/(NAME+'.json');assert not manifest.exists()
save(manifest,dict(**summary,archives=[identity(archive)],archive_files=entries,archive_verified=dict(CRC=True,all_unique_entry_SHA256=True,source_files=len(entries),unique_entries=len(unique),original_bytes=sum(e['bytes']for e in entries),unique_bytes=sum(k[0]for k in unique),content_deduplication='Every original path retains SHA/size and canonical ZIP entry; identical payloads stored once.')))
published=dict(manifest=identity(manifest),archives=[identity(archive)]);save(Z/'published.json',published)
print(json.dumps(dict(**published,source_files=len(entries),unique_entries=len(unique),original_bytes=sum(e['bytes']for e in entries),unique_bytes=sum(k[0]for k in unique)),indent=2))
