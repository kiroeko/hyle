"""Offline resume-probe checker; requires actual terminal native records/raws."""
from pathlib import Path
import argparse
import hashlib
import json
import math
import numpy as np

HERE = Path(__file__).resolve().parent
STAGE = HERE.parent
SOURCE_SHA = '8f481274dcb26cacb8d1d10f59547512e78e39211ac32342213fed30971e97cf'


def load(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def identity(path):
    path = Path(path)
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(block)
    return dict(path=str(path.resolve()), bytes=path.stat().st_size, sha256=digest.hexdigest())


def same_identity(record):
    actual = identity(record['path'])
    assert (actual['bytes'], actual['sha256']) == (record['bytes'], record['sha256']), record['path']
    return actual


def values(raw, dtype):
    if dtype == 'BF16':
        assert len(raw) % 2 == 0
        return (np.frombuffer(raw, dtype='<u2').astype(np.uint32) << 16).view(np.float32)
    assert dtype == 'F32' and len(raw) % 4 == 0
    return np.frombuffer(raw, dtype='<f4')


def expected_inventory(head, role):
    assert head['length'] == head['draft_frontier'] + head['lag']
    assert head['carry_bytes'] == 4096 and head['prior_bytes'] == (4096 if head['lag'] else 0)
    assert head['lag'] in [0, 1] and (head['catchup_token'] >= 0) == bool(head['lag'])
    result = {}
    for layer in range(24):
        if layer % 4 != 3:
            result[f'layer{layer}.conv.bf16'] = ('BF16', 36864)
            result[f'layer{layer}.gdn.f32'] = ('F32', 1048576)
    for layer in range(6):
        for kind in ['key', 'value']:
            result[f'target{layer}.{kind}.bf16'] = ('BF16', head['length'] * 1024)
    for kind in ['key', 'value']:
        result[f'draft.{kind}.bf16'] = ('BF16', head['draft_frontier'] * 1024)
    result['carry.bf16'] = ('BF16', head['carry_bytes'])
    result['prior.bf16'] = ('BF16', head['prior_bytes'])
    assert len(result) == 52
    rows = 2 if role in [3, 4] else 1
    result['output.logits.f32'] = ('F32', rows * 248320 * 4)
    result['output.hidden.bf16'] = ('BF16', rows * 4096)
    assert len(result) == 54
    return result


def assert_close(actual, expected):
    assert math.isclose(actual, expected, rel_tol=2e-12, abs_tol=1e-20), (actual, expected)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--run', type=Path, default=STAGE / 'probe-run1')
    parser.add_argument('--ready', type=Path, default=STAGE / 'mtp_session-ready-attempt1.json')
    parser.add_argument('--output', type=Path, default=HERE / 'actual-analysis.json')
    args = parser.parse_args()
    # No wait, retry, native call or synthetic observation. Missing files fail.
    run = load(args.run / 'run.result.json')
    plan = load(args.run / 'plan.json')
    ready = load(args.ready)
    assert run['terminal'] is True and run['exit'] == 0
    assert run['command'] == plan['command'] and plan['ready'] == ready
    assert run['command'][0] == ready['image']['path']
    assert run['command'][run['command'].index('--scenario') + 1] == 'resume'
    assert run['command'][run['command'].index('--output') + 1] == str(args.run / 'vectors')
    assert plan['diagnostic'] and plan['throughput_evidence'] is False
    assert ready['source']['sha256'] == SOURCE_SHA
    image = same_identity(ready['image'])
    same_identity(ready['link_plan'])
    same_identity(ready['runtime_environment'])
    link = load(Path(ready['link_plan']['path']))
    same_identity(link['compiled_record'])
    compiled = load(Path(link['compiled_record']['path']))
    assert compiled['source'] == ready['source'] and compiled['main'] == ready['main']
    assert any(row == ready['main'] for row in compiled['dependencies'])
    assert sum(row == compiled['object'] for row in link['inputs']) == 1
    # Only the two relevant source snapshots and receipts; no SDK/object closure hash.
    source_snapshot = Path(link['compiled_record']['path']).parent / 'source/tools/qwen35_text/mtp_session_probe.cc'
    assert identity(source_snapshot)['sha256'] == SOURCE_SHA
    main_candidates = list(STAGE.glob('compile*/qwen/source/tools/qwen35_text/main.cc'))
    main_snapshot = next(path for path in main_candidates
                         if path.stat().st_size == ready['main']['bytes'] and identity(path)['sha256'] == ready['main']['sha256'])
    main_text = main_snapshot.read_text(encoding='utf-8-sig')
    finish_start = main_text.index('void finish_selected_evaluations(')
    wait = main_text.index('check(step.completion.wait())', finish_start)
    expected_check = main_text.index('!commit_record->same_result(', wait)
    publish = main_text.index('member.session->head = std::move(member.next)', expected_check)
    witness = main_text.index('++commit_ledger->committed_count', publish)
    trace = main_text.index('std::filesystem::create_directories(directory)', witness)
    assert wait < expected_check < publish < witness < trace
    observation_path = args.run / 'vectors/observation.json'
    observed = load(observation_path)
    assert observed['scenario'] == 'resume' and observed['status'] in [
        'PASS_BYTE_EXACT', 'PASS_STRUCTURE_NUMERICAL_DIFFERENCES_RECORDED']
    assert observed['model_objects'] == 1 and observed['weight_tensors'] == 335
    assert (observed['capacity'], observed['resident_limit'], observed['active_sequences']) == (64, 1, 1)
    assert (observed['actual_graph_calls'], observed['positive_graph_calls']) == (12, 11)
    assert observed['snapshot_slots'] == 2 and observed['peak_live_snapshot_versions'] == 2
    assert observed['final_live_snapshot_versions'] == 0 and observed['zero_version_retirements'] == 3
    assert observed['managed_backing_bytes'] == observed['planned_backing_bytes'] == 59777075
    assert observed['timing_comparison'] is False and observed['numerical_tolerance_policy'] is None
    assert observed['wrong_expected_rejected'] and observed['wrong_expected_actual_graph_calls'] == 1
    assert 'natural decision or state boundary diverged' in observed['wrong_expected_error']
    assert observed['postcommit_trace_failed'] and observed['postcommit_trace_error']
    assert observed['postcommit_witness_installed'] and observed['original_ledger_retry_succeeded']
    assert (args.run / 'vectors/trace-blocker').is_file()
    ledger = observed['ledger']
    assert len(ledger) == 4 and all(row['committed'] for row in ledger)
    assert [row['role'] for row in ledger] == [2, 3, 4, 5]
    assert [row['generation'] for row in ledger] == [False, True, True, True]
    assert [row['quota'] for row in ledger] == [2, 2, 2, 1]
    assert [row['accepted_tokens'] for row in ledger] == [15, 2, 1, 1]
    assert [row['draft_rows'] for row in ledger] == [15, 1, 2, 1]
    assert [row['after']['length'] for row in ledger] == [15, 17, 18, 19]
    assert [row['after']['frontier'] for row in ledger] == [15, 16, 18, 19]
    assert [row['after']['lag'] for row in ledger] == [0, 1, 0, 0]
    assert [row['after']['next_id'] for row in ledger[:3]] == [198, 74455, 271]
    assert ledger[1]['accepted_draft'] and ledger[1]['emitted'] == [248045, 74455]
    assert not ledger[2]['accepted_draft'] and ledger[2]['emitted'] == [271]
    for index, row in enumerate(ledger):
        assert row['turn'] == 0 and all(0 <= token < 248320 for token in row['inputs'] + row['emitted'])
        if index:
            assert row['before'] == ledger[index - 1]['after']
            assert row['inputs'] == [row['before']['next_id']]
        else:
            assert row['before']['length'] == 0 and len(row['inputs']) == 15
        assert row['emitted'][-1] == row['after']['next_id']
    assert observed['original_first_record'] == ledger[0]
    wrong = observed['wrong_expected'].copy()
    assert wrong['target_first'] == (ledger[0]['target_first'] + 1) % 248320
    wrong['target_first'] = ledger[0]['target_first']
    assert wrong == ledger[0]  # Input/proposal computation was not replaced.
    episodes = observed['episodes']
    assert [row['name'] for row in episodes] == [
        'continuity0', 'continuity1', 'continuity2', 'continuity3', 'postcommit_trace_failure', 'resumed_single']
    for row, index in zip(episodes, [0, 1, 2, 3, 2, 3]):
        assert row['record'] == ledger[index]
    stderr = (args.run / 'run.stderr.log').read_text(encoding='utf-8-sig')
    stdout = (args.run / 'run.stdout.log').read_text(encoding='utf-8-sig')
    terminal_json = json.loads(stdout.strip().splitlines()[-1])
    assert terminal_json['status'] == 'MTP_RESUME_PROBE_COMPLETED'
    assert (terminal_json['actual_graph_calls'], terminal_json['positive_graph_calls'], terminal_json['vectors']) == (12, 11, 216)
    assert terminal_json['timing_comparison'] is False
    baseline = observed['baseline']
    assert len(baseline) == 4
    raws, references = {}, {}

    def inspect(path, dtype):
        path = Path(path)
        key = str(path.resolve())
        raw = path.read_bytes()
        scalar = values(raw, dtype)
        finite = np.isfinite(scalar)
        assert finite.all(), path
        row = dict(path=key, bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest(),
                   dtype=dtype, elements=int(scalar.size), nonfinite=0)
        if key in raws:
            assert raws[key] == row
        else:
            raws[key] = row
        return raw, scalar

    for index, step in enumerate(baseline):
        head = step['metadata']
        after = ledger[index]['after']
        assert (head['length'], head['draft_frontier'], head['lag'], head['next_id'], head['catchup_token']) == (
            after['length'], after['frontier'], after['lag'], after['next_id'], after['catchup_token'])
        expected = expected_inventory(head, ledger[index]['role'])
        assert len(step['vectors']) == 54 and {row['name'] for row in step['vectors']} == set(expected)
        for row in step['vectors']:
            dtype, size = expected[row['name']]
            assert (row['dtype'], row['bytes']) == (dtype, size)
            raw, _ = inspect(row['path'], dtype)
            assert len(raw) == size
            references[index, row['name']] = row
    assert len(raws) == 216  # Four actual continuity images; no old GPU owner retained.
    labels = dict(restore_lag1=1, postcommit_trace_failure=2, restore_lag0=2, resumed_single=3)
    checked, counts, all_bytes = [], {name: 0 for name in labels}, True
    metric_names = set()
    assert len(observed['vectors']) == 216
    for metric in observed['vectors']:
        label, component = metric['name'].split('/', 1)
        assert metric['name'] not in metric_names
        metric_names.add(metric['name'])
        assert label in labels
        reference = references[labels[label], component]
        assert (metric['baseline'], metric['dtype'], metric['bytes']) == (reference['path'], reference['dtype'], reference['bytes'])
        a, x = inspect(metric['baseline'], metric['dtype'])
        b, y = inspect(metric['actual'], metric['dtype'])
        assert len(a) == len(b) == metric['bytes']
        equal = a == b
        all_bytes = all_bytes and equal
        assert metric['byte_equal'] == equal and metric['actual_reuses_baseline_payload'] == equal
        if equal:
            assert Path(metric['actual']) == Path(metric['baseline'])
        assert metric['nonfinite_baseline'] == metric['nonfinite_actual'] == 0
        difference = y.astype(np.float64) - x.astype(np.float64)
        max_abs = float(np.abs(difference).max(initial=0))
        squared = float(np.dot(difference, difference))
        reference_squared = float(np.dot(x.astype(np.float64), x.astype(np.float64)))
        assert_close(metric['max_abs'], max_abs)
        assert_close(metric['squared_error'], squared)
        assert_close(metric['reference_squared'], reference_squared)
        counts[label] += 1
        checked.append(dict(name=metric['name'], baseline=str(Path(metric['baseline']).resolve()),
                            actual=str(Path(metric['actual']).resolve()), bytes=len(a),
                            baseline_sha256=hashlib.sha256(a).hexdigest(), actual_sha256=hashlib.sha256(b).hexdigest(),
                            byte_equal=equal, canonical_raw_reuse=equal, nonfinite=0, max_abs=max_abs,
                            squared_error=squared, reference_squared=reference_squared,
                            relative_l2=math.sqrt(squared / reference_squared) if reference_squared else 0.0))
    assert all(count == 54 for count in counts.values())
    assert observed['all_vectors_byte_equal'] == terminal_json['all_vectors_byte_equal'] == all_bytes
    assert observed['all_finite'] is True
    assert (observed['status'] == 'PASS_BYTE_EXACT') == all_bytes
    result = dict(status='PASS_HOST_RAW_REVIEW', native_exit=0, scenario='resume',
                  records=dict(ready=identity(args.ready), terminal=identity(args.run / 'run.result.json'),
                               plan=identity(args.run / 'plan.json'), stdout=identity(args.run / 'run.stdout.log'),
                               stderr=identity(args.run / 'run.stderr.log'), observation=identity(observation_path),
                               image=image, probe_source=identity(source_snapshot), main_source=identity(main_snapshot),
                               compiled_record=link['compiled_record']),
                  actual_graph_calls=12, positive_graph_calls=11, negative_actual_graph_calls=1,
                  complete_head_components=52, actual_graph_components=54, baseline_raw_images=4,
                  comparison_counts=counts, compared_vectors=len(checked), all_byte_equal=all_bytes, all_finite=True,
                  retirement=dict(N=1, peak_native_snapshot_versions=2, final_native_snapshot_versions=0,
                                  actual_zero_version_retirements=3, backing_bytes=59777075),
                  negatives=dict(dynamic_wrong_expected=dict(actual_graph_calls=1, rejected=True, input_unchanged=True,
                                                            error=observed['wrong_expected_error']),
                                 postcommit_trace=dict(failed=True, ordinary_file=True, witness_before_IO=True,
                                                       original_ledger_retry=True, error=observed['postcommit_trace_error'])),
                  source_order_proof=dict(wait=wait, expected_check=expected_check, head_publish=publish, witness=witness, trace=trace),
                  ledger=ledger, raw_files=list(raws.values()), comparisons=checked,
                  limits=['No performance, natural acceptance-rate or cross-provider quality claim.',
                          'Finite same-Model/role/partition/quota replay case; not universal bitwise recompute determinism.',
                          'Equality actual payloads explicitly alias canonical baseline raw; native complete-array comparison remains source/runtime assertion, not independent second actual payload.',
                          'Only final restore boundaries54 independently read; intermediate transitions use typed native replay ledger checks.',
                          'Retirement and two rejection/publication gates corroborate actual probe assertions and compiled source; host checker cannot reconstruct GPU permission events.',
                          'No warm CatchupPrefill native case here; CLI natural turns are separately checked.'])
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({key: result[key] for key in ['status', 'actual_graph_calls', 'positive_graph_calls',
                                                'comparison_counts', 'compared_vectors', 'all_byte_equal', 'all_finite']}, indent=2))


if __name__ == '__main__':
    main()
