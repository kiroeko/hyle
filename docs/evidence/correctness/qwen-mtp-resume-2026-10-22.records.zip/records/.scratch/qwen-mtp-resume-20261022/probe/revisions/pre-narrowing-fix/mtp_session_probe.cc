// Explicit single-Model MTP isolation consumer; no throughput/quality claim.
#define main hyle_qwen35_text_consumer_main
#include "main.cc"
#undef main

#include <bit>
#include <cstring>
#include "hyle/compute/detail/paged_arena_access.h"

namespace {
namespace q = qwen35;
namespace c = q::c;
using Bytes = std::vector<std::byte>;

void require(bool value, const char *message) {
  if (!value) throw std::runtime_error(message);
}
std::string quoted(std::string_view value) {
  std::ostringstream out; out << '"';
  for (const auto ch : value) {
    if (ch == '"' || ch == '\\') out << '\\' << ch;
    else if (ch == '\n') out << "\\n";
    else if (static_cast<unsigned char>(ch) < 32) out << '?';
    else out << ch;
  }
  out << '"'; return out.str();
}
Bytes read(c::ReadLease const &lease) {
  if (!lease.valid()) return {};
  Bytes bytes(lease.size()); q::check(q::take(lease.view()).read(bytes)); return bytes;
}
Bytes read(q::Tensor &tensor) {
  Bytes bytes(tensor.buffer.size()); q::check(tensor.buffer.view().read(bytes)); return bytes;
}
void write(const std::filesystem::path &path, const Bytes &bytes) {
  std::filesystem::create_directories(path.parent_path());
  std::ofstream out(path, std::ios::binary);
  out.write(reinterpret_cast<const char *>(bytes.data()), static_cast<std::streamsize>(bytes.size()));
  require(static_cast<bool>(out), "cannot write MTP Session probe vector");
}
Bytes read_file(const std::filesystem::path &path, std::size_t size) {
  std::ifstream in(path, std::ios::binary | std::ios::ate);
  require(in && in.tellg() == static_cast<std::streamoff>(size), "baseline vector extent differs");
  in.seekg(0); Bytes bytes(size);
  in.read(reinterpret_cast<char *>(bytes.data()), static_cast<std::streamsize>(size));
  require(static_cast<bool>(in), "cannot read MTP Session baseline"); return bytes;
}
std::string fingerprint(const Bytes &bytes) {
  std::uint64_t hash = 14695981039346656037ull;
  for (const auto value : bytes) { hash ^= std::to_integer<unsigned char>(value); hash *= 1099511628211ull; }
  std::ostringstream out; out << std::hex << std::setw(16) << std::setfill('0') << hash; return out.str();
}
struct Blob final { std::string name; bool bf16 = false; Bytes bytes; };

// Read exactly the committed logical rows, independent of physical page IDs.
// No capacity/whole-bank view is used as permission for an unused tail.
Bytes logical_rows(const c::PagedArena &arena, const c::PagedArenaRead &frame, std::size_t rows) {
  const auto host = frame.layout().host();
  const auto count = (rows + q::cache::Plan::page_rows - 1) / q::cache::Plan::page_rows;
  require(frame.valid() && host.page_indices.size() == count && frame.page_count() == count &&
          host.last_page_lengths.size() == 1, "MTP frame has the wrong committed page footprint");
  require(!count || (count - 1) * q::cache::Plan::page_rows +
          static_cast<std::size_t>(host.last_page_lengths[0]) == rows, "MTP frame frontier differs from its snapshot");
  Bytes result(q::cache::multiply(rows, std::size_t{1024}));
  const auto guards = c::detail::PagedArenaAccess::pages(frame);
  std::size_t offset = 0;
  for (std::size_t logical = 0; logical < count; ++logical) {
    const auto physical = host.page_indices[logical]; const c::ReadLease *selected = nullptr;
    for (const auto &guard : guards)
      if (q::take(c::detail::PagedArenaAccess::page(arena, guard)) == static_cast<std::uint32_t>(physical)) selected = &guard;
    require(selected != nullptr, "logical MTP page lacks its real ready guard");
    const auto bytes = (std::min)(std::size_t{16 * 1024}, result.size() - offset);
    q::check(q::take(q::take(selected->view()).subview(0, bytes)).read(std::span(result).subspan(offset, bytes)));
    offset += bytes;
  }
  return result;
}
struct HeadImage final {
  std::string metadata;
  std::vector<std::uint32_t> target_pages, draft_pages;
  std::vector<Blob> blobs;
};
HeadImage image(q::Model &model, const q::cache::Snapshot &head) {
  model.validate_mtp_snapshot(head);
  require(head.draft && head.carry_hidden.valid(), "incomplete MTP head");
  HeadImage result;
  std::ostringstream metadata;
  metadata << "{\"length\":" << head.length << ",\"next_id\":" << head.next_id
    << ",\"draft_frontier\":" << head.draft->frontier << ",\"lag\":" << head.draft->lag
    << ",\"catchup_token\":" << head.draft->catchup_token << ",\"carry_bytes\":" << head.carry_hidden.size()
    << ",\"prior_bytes\":" << head.prior_hidden.size() << '}';
  result.metadata = metadata.str();
  for (const auto &page : head.pages) result.target_pages.push_back(page.page());
  for (const auto &page : head.draft->pages) result.draft_pages.push_back(page.page());
  for (std::size_t layer = 0; layer < head.state.size(); ++layer) if (layer % 4 != 3) {
    result.blobs.push_back({"layer" + std::to_string(layer) + ".conv.bf16", true, read(head.state[layer].history)});
    result.blobs.push_back({"layer" + std::to_string(layer) + ".gdn.f32", false, read(head.state[layer].recurrent)});
  }
  for (std::size_t layer = 0; layer < head.keys.size(); ++layer) {
    result.blobs.push_back({"target" + std::to_string(layer) + ".key.bf16", true,
        logical_rows(model.page_inventory.keys[layer], head.keys[layer], head.length)});
    result.blobs.push_back({"target" + std::to_string(layer) + ".value.bf16", true,
        logical_rows(model.page_inventory.values[layer], head.values[layer], head.length)});
  }
  result.blobs.push_back({"draft.key.bf16", true, logical_rows(model.draft_inventory.keys[0], head.draft->key, head.draft->frontier)});
  result.blobs.push_back({"draft.value.bf16", true, logical_rows(model.draft_inventory.values[0], head.draft->value, head.draft->frontier)});
  result.blobs.push_back({"carry.bf16", true, read(head.carry_hidden)});
  result.blobs.push_back({"prior.bf16", true, read(head.prior_hidden)});
  return result;
}
bool same(const HeadImage &a, const HeadImage &b) {
  if (a.metadata != b.metadata || a.target_pages != b.target_pages || a.draft_pages != b.draft_pages || a.blobs.size() != b.blobs.size()) return false;
  for (std::size_t i = 0; i < a.blobs.size(); ++i)
    if (a.blobs[i].name != b.blobs[i].name || a.blobs[i].bytes != b.blobs[i].bytes) return false;
  return true;
}

struct VectorRecord final { std::string name, path, hash; bool bf16 = false; std::size_t bytes = 0; };
struct SavedStep final { std::string metadata; std::vector<VectorRecord> vectors; };
struct Metric final {
  std::string name, baseline, actual, dtype, baseline_hash, actual_hash;
  std::size_t bytes = 0, nonfinite_baseline = 0, nonfinite_actual = 0;
  bool byte_equal = false;
  double max_abs = 0, squared_error = 0, reference_squared = 0;
};
Metric compare(const VectorRecord &reference, const Blob &actual, const std::filesystem::path &path) {
  require(reference.name == actual.name && reference.bf16 == actual.bf16 && reference.bytes == actual.bytes.size(), "corresponding MTP vector shape/type differs");
  const auto baseline = read_file(reference.path, reference.bytes);
  Metric result{.name = actual.name, .baseline = reference.path, .dtype = actual.bf16 ? "BF16" : "F32",
      .baseline_hash = reference.hash, .actual_hash = fingerprint(actual.bytes), .bytes = actual.bytes.size(), .byte_equal = baseline == actual.bytes};
  // Store just one baseline payload on byte equality; differences retain the
  // actual raw vector. The observation records the exact reuse relation.
  if (!result.byte_equal) { write(path, actual.bytes); result.actual = path.string(); }
  else result.actual = reference.path;
  const auto width = actual.bf16 ? sizeof(std::uint16_t) : sizeof(float);
  require(reference.bytes % width == 0, "MTP vector has a non-scalar byte extent");
  const auto scalar = [&](const Bytes &data, std::size_t index) {
    if (actual.bf16) { std::uint16_t word = 0; std::memcpy(&word, data.data() + index * width, sizeof(word)); return std::bit_cast<float>(std::uint32_t(word) << 16); }
    float value = 0; std::memcpy(&value, data.data() + index * width, sizeof(value)); return value;
  };
  for (std::size_t i = 0; i < reference.bytes / width; ++i) {
    const double x = scalar(baseline, i), y = scalar(actual.bytes, i);
    result.nonfinite_baseline += !std::isfinite(x); result.nonfinite_actual += !std::isfinite(y);
    if (!std::isfinite(x) || !std::isfinite(y)) continue;
    const auto error = y - x; result.max_abs = (std::max)(result.max_abs, std::abs(error));
    result.squared_error += error * error; result.reference_squared += x * x;
  }
  return result;
}
struct Run final {
  std::string name;
  std::span<const std::int32_t> prompt;
  std::size_t quota = 0, step = 0;
  std::shared_ptr<q::Session> session;
  std::vector<std::int32_t> generated;
  bool done() const { return !generated.empty() && (generated.size() >= quota || q::is_end_of_generation(generated.back())); }
};
struct Probe final {
  std::filesystem::path output;
  std::array<std::vector<SavedStep>, 2> baseline;
  std::vector<Metric> metrics;
  std::vector<std::string> episodes;
  std::size_t peak_versions = 0, idle_checks = 0, after_stop_calls = 0;
  std::size_t actual_backing = 0, phases = 0, slots = 0;
  bool all_bytes = true, all_finite = true, stopped_b = false;
  void observe(q::Model &model) {
    peak_versions = (std::max)(peak_versions, std::size_t(model.snapshot_versions.live));
    require(model.snapshot_versions.live <= model.cache_plan.snapshot_slots, "MTP Session probe exceeded finite snapshot capacity");
    actual_backing = q::take(model.cache_budget.usage(model.memory.ref())).live_bytes;
    require(actual_backing == model.cache_plan.backing_bytes, "MTP state backing is not charged exactly once");
  }
  void save_or_compare(std::size_t which, Run &run, HeadImage captured, bool reference) {
    auto &saved = baseline[which];
    const auto directory = output / ((reference ? "baseline_" : "interleaved_") + run.name) / ("step" + std::to_string(run.step));
    if (reference) {
      SavedStep step; step.metadata = captured.metadata;
      for (const auto &blob : captured.blobs) {
        const auto path = directory / blob.name; write(path, blob.bytes);
        step.vectors.push_back({blob.name, path.string(), fingerprint(blob.bytes), blob.bf16, blob.bytes.size()});
      }
      saved.push_back(std::move(step));
    } else {
      require(run.step < saved.size(), "interleaved MTP used more natural episodes than its baseline");
      const auto &step = saved[run.step];
      require(captured.metadata == step.metadata && captured.blobs.size() == step.vectors.size(), "interleaved natural MTP transition differs from its baseline");
      for (std::size_t i = 0; i < captured.blobs.size(); ++i) {
        auto metric = compare(step.vectors[i], captured.blobs[i], directory / captured.blobs[i].name);
        metric.name = run.name + "/step" + std::to_string(run.step) + "/" + metric.name;
        all_bytes = all_bytes && metric.byte_equal;
        all_finite = all_finite && !metric.nonfinite_baseline && !metric.nonfinite_actual;
        metrics.push_back(std::move(metric));
      }
    }
    ++run.step;
  }
  void report(std::string_view status, q::Model &model, std::string_view error = {}) {
    phases = model.phases.size(); slots = 0;
    for (const auto &[key, phase] : model.phases) { (void)key; for (const auto &slot : phase->slots) slots += slot.valid(); }
    std::ofstream out(output / "observation.json"); require(static_cast<bool>(out), "cannot write MTP Session observation");
    out << std::setprecision(17) << "{\"status\":" << quoted(status) << ",\"error\":" << quoted(error)
      << ",\"model_objects\":1,\"weight_tensors\":335,\"capacity\":64,\"resident_limit\":2,\"active_sequences\":1"
      << ",\"baseline_prompt_rows\":[15,23],\"output_quotas\":[8,16],\"all_vectors_byte_equal\":" << (all_bytes ? "true" : "false")
      << ",\"all_finite\":" << (all_finite ? "true" : "false") << ",\"idle_head_full_byte_checks\":" << idle_checks
      << ",\"stopped_EOS_session_B\":" << (stopped_b ? "true" : "false") << ",\"A_calls_after_B_stop\":" << after_stop_calls
      << ",\"peak_live_snapshot_versions\":" << peak_versions << ",\"snapshot_slots\":" << model.cache_plan.snapshot_slots
      << ",\"state_slots\":" << model.cache_plan.state_slots << ",\"hidden_slots\":" << model.cache_plan.hidden_slots
      << ",\"managed_backing_bytes\":" << actual_backing << ",\"planned_backing_bytes\":" << model.cache_plan.backing_bytes
      << ",\"final_live_snapshot_versions\":" << model.snapshot_versions.live << ",\"actual_phases\":" << phases << ",\"actual_slots\":" << slots
      << ",\"fingerprint\":\"FNV1a64 diagnostic identity; byte equality uses complete arrays\",\"timing_comparison\":false,\"numerical_tolerance_policy\":null"
      << ",\"scope\":\"Same Model/GraphRole/partitions/N2 plan/native math and auto capture policy. Serial active R1; no MTP simultaneous R2, server isolation, or cross-engine quality claim. Physical page IDs may differ between sequential baselines and interleaved allocations; KV vectors contain exact logical committed rows. Equal actual payloads reference one saved baseline raw file.\""
      << ",\"episodes\":[";
    for (std::size_t i = 0; i < episodes.size(); ++i) out << (i ? "," : "") << episodes[i];
    out << "],\"baseline\":[";
    for (std::size_t r = 0; r < baseline.size(); ++r) {
      out << (r ? "," : "") << '[';
      for (std::size_t s = 0; s < baseline[r].size(); ++s) {
        const auto &step = baseline[r][s]; out << (s ? "," : "") << "{\"metadata\":" << step.metadata << ",\"vectors\":[";
        for (std::size_t i = 0; i < step.vectors.size(); ++i) { const auto &v = step.vectors[i];
          out << (i ? "," : "") << "{\"name\":" << quoted(v.name) << ",\"path\":" << quoted(v.path) << ",\"bytes\":" << v.bytes
              << ",\"dtype\":" << quoted(v.bf16 ? "BF16" : "F32") << ",\"fnv1a64\":" << quoted(v.hash) << '}'; }
        out << "]}";
      }
      out << ']';
    }
    out << "],\"vectors\":[";
    for (std::size_t i = 0; i < metrics.size(); ++i) { const auto &v = metrics[i];
      out << (i ? "," : "") << "{\"name\":" << quoted(v.name) << ",\"baseline\":" << quoted(v.baseline)
        << ",\"actual\":" << quoted(v.actual) << ",\"dtype\":" << quoted(v.dtype) << ",\"bytes\":" << v.bytes
        << ",\"byte_equal\":" << (v.byte_equal ? "true" : "false") << ",\"actual_reuses_baseline_payload\":" << (v.byte_equal ? "true" : "false")
        << ",\"baseline_fnv1a64\":" << quoted(v.baseline_hash) << ",\"actual_fnv1a64\":" << quoted(v.actual_hash)
        << ",\"nonfinite_baseline\":" << v.nonfinite_baseline << ",\"nonfinite_actual\":" << v.nonfinite_actual
        << ",\"max_abs\":" << v.max_abs << ",\"squared_error\":" << v.squared_error << ",\"reference_squared\":" << v.reference_squared << '}';
    }
    out << "]}\n"; require(static_cast<bool>(out), "MTP Session observation write failed");
  }
};

void retire(Run &run) {
  q::check(run.session->stop()); require(q::take(run.session->try_retire()), "completed MTP Session failed actual retirement");
  run.session.reset();
}
void advance(q::Model &model, Probe &probe, Run &run, std::size_t which, bool reference) {
  const bool prefill = run.generated.empty();
  require(prefill || !run.done(), "MTP probe attempted to advance an ended Session");
  const auto before = run.session->length();
  const auto quota = run.quota - run.generated.size();
  const auto lag = run.session->head->draft->lag;
  const bool single = !prefill && (quota == 1 || model.capacity - before == 1);
  const auto role = prefill ? q::GraphRole::kMtpPrefill : single
      ? (lag ? q::GraphRole::kMtpCatchupSingle : q::GraphRole::kMtpSingle)
      : (lag ? q::GraphRole::kMtpCatchupRound : q::GraphRole::kMtpRound);
  const auto pending = run.session->head->next_id;
  const auto inputs = prefill ? run.prompt : std::span(&pending, 1);
  model.prepare_evaluation(*run.session, inputs, nullptr, role); probe.observe(model);
  require(model.active_step && run.session->pending, "original MTP episode was not admitted");
  auto *phase = run.session->pending->phase;
  q::StepObservation observation;
  model.submit_evaluation(*run.session);
  q::MtpRoundResult round;
  const auto name = run.name + (prefill ? "_prefill" : "_round" + std::to_string(run.step));
  if (prefill) run.generated.push_back(model.finish_evaluation(*run.session, name, {}, false, nullptr, nullptr, &observation));
  else {
    const q::EvaluationOutput output{.session = run.session, .name = name, .trace_states = false, .observation = &observation};
    round = model.finish_mtp_round(*run.session, quota, std::array<std::int32_t, 2>{248044,248046}, &output);
    run.generated.insert(run.generated.end(), round.emitted.begin(), round.emitted.end());
  }
  probe.observe(model);
  require(!model.active_step && !model.carrier_borrowed && !run.session->pending &&
          model.snapshot_versions.live <= model.cache_plan.resident_sessions, "MTP episode retained a candidate/carrier after finish");
  auto captured = image(model, *run.session->head);
  captured.blobs.push_back({"output.logits.f32", false, read(phase->logits)});
  captured.blobs.push_back({"output.hidden.bf16", true, read(phase->final_hidden)});
  std::ostringstream meta;
  meta << "{\"head\":" << captured.metadata << ",\"role\":" << static_cast<int>(role)
    << ",\"input_rows\":" << inputs.size() << ",\"generated_ids\":[";
  for (std::size_t i = 0; i < run.generated.size(); ++i) meta << (i ? "," : "") << run.generated[i];
  meta << "],\"pending\":" << round.pending << ",\"proposal\":" << round.draft << ",\"target_first\":" << round.target_first
    << ",\"target_second\":" << round.target_second << ",\"agreed\":" << (round.agreed ? "true" : "false")
    << ",\"accepted\":" << (round.accepted_draft ? "true" : "false") << ",\"processed_target\":" << round.processed_target
    << ",\"processed_draft\":" << round.processed_draft << '}'; captured.metadata = meta.str();
  std::ostringstream episode;
  episode << "{\"reference\":" << (reference ? "true" : "false") << ",\"session\":" << quoted(run.name) << ",\"step\":" << run.step
    << ",\"metadata\":" << captured.metadata << ",\"capture_recorded\":" << observation.capture_recorded
    << ",\"capture_reused\":" << observation.capture_reused << ",\"execution_parity_after\":" << model.execution_parity << '}';
  probe.episodes.push_back(episode.str());
  probe.save_or_compare(which, run, std::move(captured), reference);
}

void run(const std::filesystem::path &inputs, const std::filesystem::path &output) {
  auto source = q::read_ids(inputs / "prompt.ids"); require(source.size() >= 23, "probe needs original prompt first23 IDs");
  require(!std::filesystem::exists(output), "probe output directory must be fresh"); std::filesystem::create_directories(output);
  const auto plan = q::cache::plan(64, 2, 23, q::recurrent_bytes(q::state_schema_for(64)), 1, 2, true);
  q::Model model(inputs / "weights.tsv", 64, plan);
  require(model.weights.size() == 335, "MTP Session probe requires complete335 weight inventory");
  Probe probe{.output = output};
  try {
    const std::array prefills{std::size_t{15},std::size_t{23}};
    const std::array pair{std::size_t{2}};
    const std::array single{std::size_t{1}};
    model.prepare_family(prefills, false, 1, q::GraphRole::kMtpPrefill);
    // Each shape/role uses the same original auto-capture policy in both
    // stages, conservatively planned for either Model parity before any slot.
    for (const auto size : prefills) model.plan_replay_uses(size, 1, 4, q::GraphRole::kMtpPrefill);
    for (const auto role : {q::GraphRole::kMtpRound,q::GraphRole::kMtpCatchupRound,q::GraphRole::kMtpSingle,q::GraphRole::kMtpCatchupSingle}) {
      model.prepare_family(q::drafts_token(role) ? std::span(pair) : std::span(single), false, 1, role);
      model.plan_replay_uses(q::drafts_token(role) ? 2u : 1u, 1, 48, role);
    }
    probe.observe(model);
    const auto make_run = [&](std::size_t which) {
      const auto size = prefills[which]; const std::array calls{size};
      return Run{.name = which ? "B" : "A", .prompt = std::span(source).first(size), .quota = which ? 16u : 8u,
          .session = model.create_session(calls, {}, q::GraphRole::kMtpPrefill)};
    };
    for (std::size_t which = 0; which < 2; ++which) {
      auto baseline = make_run(which);
      do { advance(model, probe, baseline, which, true); } while (!baseline.done());
      retire(baseline); require(model.snapshot_versions.live == 0, "sequential baseline retained device state");
    }
    std::array runs{make_run(0), make_run(1)};
    for (;;) {
      bool progress = false;
      for (std::size_t which = 0; which < runs.size(); ++which) {
        auto &current = runs[which]; auto &other = runs[1 - which];
        if (!current.session || current.done()) continue;
        const auto idle = other.session ? std::optional(image(model, *other.session->head)) : std::nullopt;
        advance(model, probe, current, which, false); progress = true;
        if (idle) { require(same(*idle, image(model, *other.session->head)), "advancing one MTP Session changed another complete head"); ++probe.idle_checks; }
        if (probe.stopped_b && which == 0) ++probe.after_stop_calls;
        if (current.done() && which == 1) {
          require(q::is_end_of_generation(current.generated.back()), "fixed P23 Session did not end at its natural EOS");
          require(runs[0].session && !runs[0].done(), "probe did not retain a live Session across early stop");
          retire(current); probe.stopped_b = true; probe.observe(model);
          require(!model.carrier_borrowed && !model.active_step, "stopping idle Session closed shared admission");
        }
      }
      if (!progress) break;
    }
    for (std::size_t which = 0; which < runs.size(); ++which) {
      require(runs[which].step == probe.baseline[which].size(), "interleaved MTP episode count differs from baseline");
      if (runs[which].session) retire(runs[which]);
    }
    probe.observe(model);
    require(probe.stopped_b && probe.after_stop_calls && probe.idle_checks && probe.all_finite &&
            model.snapshot_versions.live == 0 && !model.active_step && !model.carrier_borrowed,
            "MTP Session isolation/finite-state/early-stop cleanup did not complete");
    probe.report(probe.all_bytes ? "PASS_BYTE_EXACT" : "PASS_STRUCTURE_NUMERICAL_DIFFERENCES_RECORDED", model);
    std::cout << "{\"status\":\"MTP_SESSION_PROBE_COMPLETED\",\"all_vectors_byte_equal\":" << (probe.all_bytes ? "true" : "false")
              << ",\"vectors\":" << probe.metrics.size() << ",\"idle_head_checks\":" << probe.idle_checks
              << ",\"after_stop_calls\":" << probe.after_stop_calls << ",\"timing_comparison\":false}\n";
  } catch (const std::exception &error) { probe.report("FAIL", model, error.what()); throw; }
}

struct PrefixCase final {
  std::string name, seed_metadata;
  std::vector<SavedStep> baseline;
};
struct PrefixObservation final {
  std::filesystem::path output;
  std::array<PrefixCase, 3> cases{{{"whole", {}, {}}, {"T1", {}, {}}, {"T8", {}, {}}}};
  std::vector<Metric> metrics;
  std::vector<std::string> episodes;
  std::size_t graph_calls = 0, peak_versions = 0, full_hits = 0, full_hit_vectors = 0, old_checks = 0;
  std::size_t negative_bound_banks = 0, negative_versions_before = 0, negative_versions_pending = 0, negative_versions_after = 0;
  bool all_bytes = true, all_finite = true, negative_rejected = false, same_retry_slot = false;
  std::string negative_error;
  void observe(q::Model &model) {
    peak_versions = (std::max)(peak_versions, std::size_t(model.snapshot_versions.live));
    require(model.snapshot_versions.live <= 3 && q::take(model.cache_budget.usage(model.memory.ref())).live_bytes == model.cache_plan.backing_bytes,
            "MTP prefix probe exceeded its real finite state/backing plan");
  }
  void compare_vectors(const SavedStep &reference, const HeadImage &actual, const std::string &label) {
    require(reference.vectors.size() == actual.blobs.size(), "prefix vector inventory differs");
    for (std::size_t i = 0; i < actual.blobs.size(); ++i) {
      auto metric = compare(reference.vectors[i], actual.blobs[i], output / "differences" / label / actual.blobs[i].name);
      metric.name = label + "/" + metric.name; all_bytes = all_bytes && metric.byte_equal;
      all_finite = all_finite && !metric.nonfinite_baseline && !metric.nonfinite_actual; metrics.push_back(std::move(metric));
    }
  }
  void record(std::size_t which, std::size_t index, bool reference, HeadImage actual, std::string metadata) {
    auto &selected = cases[which];
    const auto label = selected.name + "/step" + std::to_string(index);
    if (reference) {
      require(index == selected.baseline.size(), "prefix baseline episode index differs");
      SavedStep saved; saved.metadata = std::move(metadata);
      if (index == 0) selected.seed_metadata = actual.metadata;
      if (which && index == 0) {
        require(saved.metadata == cases[0].baseline[0].metadata, "freshP15 baseline partitions differ");
        compare_vectors(cases[0].baseline[0], actual, "baseline_" + label);
        saved.vectors = cases[0].baseline[0].vectors;
      } else for (const auto &blob : actual.blobs) {
        const auto path = output / ("baseline_" + selected.name) / ("step" + std::to_string(index)) / blob.name;
        write(path, blob.bytes); saved.vectors.push_back({blob.name,path.string(),fingerprint(blob.bytes),blob.bf16,blob.bytes.size()});
      }
      selected.baseline.push_back(std::move(saved));
    } else {
      require(index < selected.baseline.size(), "prefix branch has no matching actual partition baseline");
      if (metadata != selected.baseline[index].metadata) {
        const auto directory = output / "transition_differences" / label;
        for (const auto &blob : actual.blobs) write(directory / blob.name,blob.bytes);
        std::ofstream description(directory / "metadata.json"); description << metadata << '\n';
        require(static_cast<bool>(description), "cannot retain differing prefix transition");
      }
      require(metadata == selected.baseline[index].metadata, "prefix natural transition differs from its same-partition baseline");
      compare_vectors(selected.baseline[index], actual, label);
    }
  }
  void report(std::string_view status, q::Model &model, std::string_view error = {}) const {
    std::ofstream out(output / "observation.json"); require(static_cast<bool>(out), "cannot write prefix probe observation");
    out << std::setprecision(17) << "{\"status\":" << quoted(status) << ",\"scenario\":\"prefix\",\"error\":" << quoted(error)
      << ",\"model_objects\":1,\"weight_tensors\":335,\"capacity\":64,\"resident_limit\":2,\"active_sequences\":1"
      << ",\"actual_graph_calls\":" << graph_calls << ",\"full_hits\":" << full_hits << ",\"full_hit_head_vectors\":" << full_hit_vectors
      << ",\"old_prefix_full_byte_checks\":" << old_checks << ",\"peak_live_snapshot_versions\":" << peak_versions
      << ",\"final_live_snapshot_versions\":" << model.snapshot_versions.live << ",\"managed_backing_bytes\":"
      << q::take(model.cache_budget.usage(model.memory.ref())).live_bytes << ",\"planned_backing_bytes\":" << model.cache_plan.backing_bytes
      << ",\"all_vectors_byte_equal\":" << (all_bytes ? "true" : "false") << ",\"all_finite\":" << (all_finite ? "true" : "false")
      << ",\"negative_teacher_forced_input\":248045,\"cached_pending\":198,\"negative_rejected\":" << (negative_rejected ? "true" : "false")
      << ",\"negative_error\":" << quoted(negative_error) << ",\"negative_bound_banks\":" << negative_bound_banks
      << ",\"negative_versions_before\":" << negative_versions_before << ",\"negative_versions_pending\":" << negative_versions_pending
      << ",\"negative_versions_after\":" << negative_versions_after << ",\"retry_same_carrier_slot\":" << (same_retry_slot ? "true" : "false")
      << ",\"timing_comparison\":false,\"numerical_tolerance_policy\":null"
      << ",\"scope\":\"Complete52-component prompt checkpoint, no fake Graph outputs on fullhit. Actual commits54-components. T1=P15+[source index16=248045], T8=P15+source[15:23]; each is compared with its own identical input partition, never monolithicP23. Directory and one current Session consume at most N2 distinct committed versions.\""
      << ",\"episodes\":[";
    for (std::size_t i = 0; i < episodes.size(); ++i) out << (i ? "," : "") << episodes[i];
    out << "],\"baselines\":[";
    for (std::size_t cindex = 0; cindex < cases.size(); ++cindex) {
      const auto &selected = cases[cindex]; out << (cindex ? "," : "") << "{\"case\":" << quoted(selected.name) << ",\"steps\":[";
      for (std::size_t index = 0; index < selected.baseline.size(); ++index) {
        const auto &step = selected.baseline[index]; out << (index ? "," : "") << "{\"metadata\":" << step.metadata << ",\"vectors\":[";
        for (std::size_t i = 0; i < step.vectors.size(); ++i) { const auto &v = step.vectors[i];
          out << (i ? "," : "") << "{\"name\":" << quoted(v.name) << ",\"path\":" << quoted(v.path)
            << ",\"dtype\":" << quoted(v.bf16 ? "BF16" : "F32") << ",\"bytes\":" << v.bytes << ",\"fnv1a64\":" << quoted(v.hash) << '}'; }
        out << "]}";
      }
      out << "]}";
    }
    out << "],\"vectors\":[";
    for (std::size_t i = 0; i < metrics.size(); ++i) { const auto &v = metrics[i];
      out << (i ? "," : "") << "{\"name\":" << quoted(v.name) << ",\"baseline\":" << quoted(v.baseline)
        << ",\"actual\":" << quoted(v.actual) << ",\"dtype\":" << quoted(v.dtype) << ",\"bytes\":" << v.bytes
        << ",\"byte_equal\":" << (v.byte_equal ? "true" : "false") << ",\"actual_reuses_baseline_payload\":" << (v.byte_equal ? "true" : "false")
        << ",\"baseline_fnv1a64\":" << quoted(v.baseline_hash) << ",\"actual_fnv1a64\":" << quoted(v.actual_hash)
        << ",\"nonfinite_baseline\":" << v.nonfinite_baseline << ",\"nonfinite_actual\":" << v.nonfinite_actual
        << ",\"max_abs\":" << v.max_abs << ",\"squared_error\":" << v.squared_error << ",\"reference_squared\":" << v.reference_squared << '}';
    }
    out << "]}\n"; require(static_cast<bool>(out), "prefix probe report failed");
  }
};

void retire_prefix_session(std::shared_ptr<q::Session> &session) {
  q::check(session->stop()); require(q::take(session->try_retire()), "prefix Session did not really retire"); session.reset();
}
void prefix_commit(q::Model &model, PrefixObservation &observation, std::size_t which, std::size_t index,
                   const std::shared_ptr<q::Session> &session, std::span<const std::int32_t> inputs,
                   q::GraphRole role, bool natural, bool reference, q::g::Invocation *retry_slot = nullptr) {
  model.prepare_evaluation(*session, inputs, nullptr, role); observation.observe(model);
  auto *phase = session->pending->phase;
  if (retry_slot) { observation.same_retry_slot = session->pending->run == retry_slot; require(observation.same_retry_slot, "teacher-forced retry replaced its carrier slot"); }
  model.submit_evaluation(*session); ++observation.graph_calls;
  q::StepObservation step_observation;
  q::MtpRoundResult round;
  std::int32_t next = -1;
  const auto name = observation.cases[which].name + "_step" + std::to_string(index);
  if (natural) {
    const q::EvaluationOutput output{.session=session,.name=name,.trace_states=false,.observation=&step_observation};
    round = model.finish_mtp_round(*session, 2, std::array<std::int32_t,2>{248044,248046}, &output); next = round.next_id;
  } else next = model.finish_evaluation(*session, name, {}, false, nullptr, nullptr, &step_observation);
  observation.observe(model);
  require(!model.active_step && !model.carrier_borrowed && !session->pending && model.snapshot_versions.live <= 2,
          "prefix commit retained a candidate or shared carrier");
  auto captured = image(model, *session->head);
  captured.blobs.push_back({"output.logits.f32",false,read(phase->logits)});
  captured.blobs.push_back({"output.hidden.bf16",true,read(phase->final_hidden)});
  std::ostringstream meta;
  meta << "{\"head\":" << captured.metadata << ",\"role\":" << static_cast<int>(role) << ",\"inputs\":[";
  for (std::size_t i = 0; i < inputs.size(); ++i) meta << (i ? "," : "") << inputs[i];
  meta << "],\"natural_round\":" << (natural ? "true" : "false") << ",\"next_id\":" << next
    << ",\"pending\":" << round.pending << ",\"proposal\":" << round.draft << ",\"target_first\":" << round.target_first
    << ",\"target_second\":" << round.target_second << ",\"accepted\":" << (round.accepted_draft ? "true" : "false")
    << ",\"processed_target\":" << round.processed_target << ",\"processed_draft\":" << round.processed_draft << '}';
  std::ostringstream episode;
  episode << "{\"reference\":" << (reference ? "true" : "false") << ",\"case\":" << quoted(observation.cases[which].name)
    << ",\"step\":" << index << ",\"metadata\":" << meta.str() << ",\"capture_recorded\":" << step_observation.capture_recorded
    << ",\"capture_reused\":" << step_observation.capture_reused << '}'; observation.episodes.push_back(episode.str());
  observation.record(which,index,reference,std::move(captured),meta.str());
}

void run_prefix(const std::filesystem::path &inputs, const std::filesystem::path &output) {
  const auto source = q::read_ids(inputs / "prompt.ids"); require(source.size() >= 23 && source[16] == 248045, "prefix probe needs original first23 IDs");
  require(!std::filesystem::exists(output), "prefix probe output must be fresh"); std::filesystem::create_directories(output);
  const auto prompt = std::span(source).first(15), suffix8 = std::span(source).subspan(15,8), suffix1 = std::span(source).subspan(16,1);
  const auto plan = q::cache::plan(64,2,15,q::recurrent_bytes(q::state_schema_for(64)),1,2,true);
  q::Model model(inputs / "weights.tsv",64,plan); require(model.weights.size() == 335, "prefix probe requires335 weights");
  q::cache::PrefixCache directory(1);
  PrefixObservation observation{.output=output};
  try {
    const std::array prefills{std::size_t{15},std::size_t{8}};
    const std::array single{std::size_t{1}};
    const std::array pair{std::size_t{2}};
    model.prepare_family(prefills,false,1,q::GraphRole::kMtpPrefill);
    for (auto tokens : prefills) model.plan_replay_uses(tokens,1,24,q::GraphRole::kMtpPrefill);
    for (auto role : {q::GraphRole::kMtpRound,q::GraphRole::kMtpCatchupRound,q::GraphRole::kMtpSingle,q::GraphRole::kMtpCatchupSingle}) {
      model.prepare_family(q::drafts_token(role) ? std::span(pair) : std::span(single),false,1,role);
      model.plan_replay_uses(q::drafts_token(role) ? 2u : 1u,1,24,role);
    }
    const std::array calls{std::size_t{15}};
    auto producer = model.create_session(calls,{},q::GraphRole::kMtpPrefill);
    model.prepare_evaluation(*producer,prompt,nullptr,q::GraphRole::kMtpPrefill); observation.observe(model);
    model.submit_evaluation(*producer); ++observation.graph_calls;
    const auto cached_next = model.finish_evaluation(*producer,"prefix_seed",{},false);
    require(cached_next == 198 && producer->head->draft->lag == 0 && suffix1[0] != cached_next, "fixed lag0 prefix/teacher-forced witness changed");
    const auto checkpoint = image(model,*producer->head); // CPU only, never an extra SnapshotRef.
    const std::array phases{q::benchmark::Phase{q::benchmark::PhaseKind::kPrompt,std::vector<std::int32_t>(prompt.begin(),prompt.end()),1}};
    const auto token_plan = q::cache::token_plan(phases,64);
    auto history = std::make_shared<q::cache::ReplayHistory>(64); history->append(token_plan,0,15,cached_next);
    require(directory.publish(token_plan,producer->head,{history,1,15}), "real P15 checkpoint publish failed");
    retire_prefix_session(producer); require(model.snapshot_versions.live == 1, "source Session did not leave exactly one directory version");
    const auto check_old = [&]() {
      auto hit = directory.lookup(*token_plan,15,15,&model,model.math_identity());
      require(hit && same(checkpoint,image(model,*hit.snapshot)), "prefix branch changed the directory's complete old head"); ++observation.old_checks;
    };
    // Same partition baselines, each independently initialized; no baseline
    // Snapshot survives retirement beside the one cache checkpoint.
    for (std::size_t which = 0; which < observation.cases.size(); ++which) {
      auto session = model.create_session(calls,{},q::GraphRole::kMtpPrefill);
      prefix_commit(model,observation,which,0,session,prompt,q::GraphRole::kMtpPrefill,false,true);
      std::size_t index = 1;
      if (which) prefix_commit(model,observation,which,index++,session,which == 1 ? suffix1 : suffix8,
          which == 1 ? q::GraphRole::kMtpSingle : q::GraphRole::kMtpPrefill,false,true);
      const auto pending = session->head->next_id;
      require(!q::is_end_of_generation(pending), "fixed partial baseline ended before its natural round");
      prefix_commit(model,observation,which,index,session,std::span(&pending,1),q::GraphRole::kMtpRound,true,true);
      retire_prefix_session(session); observation.observe(model); check_old();
      require(model.snapshot_versions.live == 1, "baseline retained device state outside its directory");
    }
    for (std::size_t which = 0; which < observation.cases.size(); ++which) {
      const auto graph_before = observation.graph_calls, parity_before = model.execution_parity;
      auto hit = directory.lookup(*token_plan,15,15,&model,model.math_identity());
      require(hit && hit.snapshot->next_id == cached_next, "exact whole-prompt hit unavailable");
      auto session = model.create_session({},hit.snapshot,q::GraphRole::kMtpPrefill); hit.reset();
      require(std::all_of(session->tails.begin(),session->tails.end(),[](const auto &tail){return !tail.valid();}) &&
              std::all_of(session->draft_tails.begin(),session->draft_tails.end(),[](const auto &tail){return !tail.valid();}),
              "prefix adoption imported exclusive tail authority");
      const auto adopted = image(model,*session->head);
      require(adopted.metadata == observation.cases[which].seed_metadata && same(checkpoint,adopted), "full hit did not preserve complete original state");
      SavedStep reference_head = observation.cases[which].baseline[0]; reference_head.vectors.resize(52);
      observation.compare_vectors(reference_head,adopted,observation.cases[which].name+"/full_hit");
      require(observation.graph_calls == graph_before && model.execution_parity == parity_before && !model.active_step && !model.carrier_borrowed,
              "whole prompt hit executed or manufactured a Graph output");
      ++observation.full_hits; observation.full_hit_vectors += adopted.blobs.size();
      std::size_t index = 1;
      q::g::Invocation *retry_slot = nullptr;
      if (which == 1) {
        const auto before = image(model,*session->head); const auto *original = session->head.get();
        const auto target_owners = model.page_inventory.owners, draft_owners = model.draft_inventory.owners;
        observation.negative_versions_before = model.snapshot_versions.live;
        model.prepare_evaluation(*session,suffix1,nullptr,q::GraphRole::kMtpSingle); observation.observe(model);
        retry_slot = session->pending->run; observation.negative_versions_pending = model.snapshot_versions.live;
        observation.negative_bound_banks = static_cast<std::size_t>(std::count(session->pending->bound.begin(),session->pending->bound.end(),true));
        require(observation.negative_bound_banks == 14, "teacher-forced test did not bind all14 original banks");
        model.submit_evaluation(*session); ++observation.graph_calls;
        try { (void)model.finish_mtp_round(*session,2); }
        catch (const std::runtime_error &error) { observation.negative_rejected = true; observation.negative_error = error.what(); }
        observation.negative_versions_after = model.snapshot_versions.live;
        require(observation.negative_rejected && !model.active_step && !model.carrier_borrowed && !session->pending &&
                session->head.get() == original && model.execution_parity == parity_before &&
                model.snapshot_versions.live == observation.negative_versions_before &&
                model.page_inventory.owners == target_owners && model.draft_inventory.owners == draft_owners &&
                same(before,image(model,*session->head)), "terminal selector rejection did not reclaim its original transaction");
        check_old();
      }
      if (which) prefix_commit(model,observation,which,index++,session,which == 1 ? suffix1 : suffix8,
          which == 1 ? q::GraphRole::kMtpSingle : q::GraphRole::kMtpPrefill,false,false,retry_slot);
      const auto pending = session->head->next_id;
      prefix_commit(model,observation,which,index,session,std::span(&pending,1),q::GraphRole::kMtpRound,true,false);
      check_old(); retire_prefix_session(session); observation.observe(model);
      require(model.snapshot_versions.live == 1, "completed cached branch retained another committed version");
    }
    require(directory.evict_one() && !directory.size(), "prefix directory did not release its final entry");
    observation.observe(model);
    require(model.snapshot_versions.live == 0 && observation.full_hits == 3 && observation.full_hit_vectors == 156 &&
            observation.graph_calls == 15 && observation.negative_rejected && observation.same_retry_slot && observation.all_finite,
            "finite prefix/selection/reclamation probe did not complete");
    observation.report(observation.all_bytes ? "PASS_BYTE_EXACT" : "PASS_STRUCTURE_NUMERICAL_DIFFERENCES_RECORDED",model);
    std::cout << "{\"status\":\"MTP_PREFIX_PROBE_COMPLETED\",\"actual_graph_calls\":" << observation.graph_calls
      << ",\"full_hits\":" << observation.full_hits << ",\"vectors\":" << observation.metrics.size()
      << ",\"all_vectors_byte_equal\":" << (observation.all_bytes ? "true" : "false") << ",\"timing_comparison\":false}\n";
  } catch (const std::exception &error) { observation.report("FAIL",model,error.what()); throw; }
}
// Recovery keeps only this CPU ledger and raw oracle. It never retains a
// Snapshot, arena permission or hidden tensor from the retired GPU head.
std::string resume_record_json(const q::MtpReplayRecord &record) {
  const auto boundary = [](const q::MtpBoundary &value) {
    std::ostringstream out;
    out << "{\"length\":" << value.length << ",\"frontier\":" << value.frontier
      << ",\"lag\":" << value.lag << ",\"next_id\":" << value.next_id
      << ",\"catchup_token\":" << value.catchup_token << '}'; return out.str();
  };
  std::ostringstream out;
  out << "{\"role\":" << static_cast<int>(record.role) << ",\"generation\":" << (record.generation ? "true" : "false")
    << ",\"committed\":" << (record.committed ? "true" : "false") << ",\"quota\":" << record.quota
    << ",\"turn\":" << record.turn << ",\"inputs\":[";
  const auto ids = record.ids();
  for (std::size_t i = 0; i < ids.size(); ++i) out << (i ? "," : "") << ids[i];
  out << "],\"before\":" << boundary(record.before) << ",\"after\":" << boundary(record.after)
    << ",\"accepted_tokens\":" << record.accepted << ",\"draft_rows\":" << record.draft_rows
    << ",\"draft\":" << record.draft << ",\"target_first\":" << record.target_first
    << ",\"target_second\":" << record.target_second << ",\"agreed\":" << (record.agreed ? "true" : "false")
    << ",\"accepted_draft\":" << (record.accepted_draft ? "true" : "false")
    << ",\"stopped\":" << (record.stopped ? "true" : "false") << ",\"emitted\":[";
  for (std::size_t i = 0; i < record.emitted_count; ++i) out << (i ? "," : "") << record.emitted[i];
  out << "]}"; return out.str();
}
q::MtpReplayLedger resume_prefix(const q::MtpReplayLedger &source, std::size_t count) {
  require(count && count <= source.committed_count, "resume ledger prefix is not committed");
  q::MtpReplayLedger result(source.records.size());
  std::copy_n(source.records.begin(),count,result.records.begin()); result.committed_count = count; return result;
}
HeadImage resume_image(q::Model &model, const q::Session &session, const q::MtpReplayRecord &record) {
  auto captured = image(model,*session.head);
  const auto tokens = q::drafts_token(record.role) ? std::size_t{2} : record.ids().size();
  auto &phase = *model.phases.at(q::ExecutionShape{1,tokens,record.role});
  captured.blobs.push_back({"output.logits.f32",false,read(phase.logits)});
  captured.blobs.push_back({"output.hidden.bf16",true,read(phase.final_hidden)});
  return captured;
}
struct ResumeObservation final {
  std::filesystem::path output;
  std::array<SavedStep,4> baseline;
  std::vector<Metric> metrics;
  std::vector<std::string> episodes;
  std::size_t graph_calls = 0, positive_graph_calls = 0, peak_versions = 0, actual_backing = 0;
  std::size_t zero_version_retirements = 0, mismatch_graph_calls = 0;
  bool all_bytes = true, all_finite = true, mismatch_rejected = false, trace_rejected = false;
  bool trace_commit_witness = false, correct_retry = false;
  std::string mismatch_error, trace_error, bad_expected, actual_first;
  void observe(q::Model &model) {
    peak_versions = (std::max)(peak_versions,std::size_t(model.snapshot_versions.live));
    actual_backing = q::take(model.cache_budget.usage(model.memory.ref())).live_bytes;
    require(model.snapshot_versions.live <= model.cache_plan.snapshot_slots && actual_backing == model.cache_plan.backing_bytes,
            "resume probe exceeded its finite snapshot/backing plan");
  }
  void record(std::size_t index, HeadImage captured, bool reference, const std::string &label) {
    require(index < baseline.size() && captured.blobs.size() == 54, "resume output is not its complete54-component image");
    if (reference) {
      auto &saved = baseline[index]; saved.metadata = captured.metadata;
      for (const auto &blob : captured.blobs) {
        const auto path = output / "baseline" / ("step" + std::to_string(index)) / blob.name;
        write(path,blob.bytes); saved.vectors.push_back({blob.name,path.string(),fingerprint(blob.bytes),blob.bf16,blob.bytes.size()});
      }
      return;
    }
    const auto &saved = baseline[index];
    if (saved.metadata != captured.metadata) {
      const auto directory = output / "transition_differences" / label;
      for (const auto &blob : captured.blobs) write(directory / blob.name,blob.bytes);
      std::ofstream description(directory / "metadata.json"); description << captured.metadata << '\n';
      require(static_cast<bool>(description), "cannot retain differing resume transition");
    }
    require(saved.metadata == captured.metadata && saved.vectors.size() == captured.blobs.size(),
            "recovered MTP head differs from the same-partition continuity boundary");
    for (std::size_t i = 0; i < captured.blobs.size(); ++i) {
      auto metric = compare(saved.vectors[i],captured.blobs[i],output / "differences" / label / captured.blobs[i].name);
      metric.name = label + "/" + metric.name; all_bytes = all_bytes && metric.byte_equal;
      all_finite = all_finite && !metric.nonfinite_baseline && !metric.nonfinite_actual; metrics.push_back(std::move(metric));
    }
  }
  void report(std::string_view status, q::Model &model, const q::MtpReplayLedger &ledger, std::string_view error = {}) const {
    std::ofstream out(output / "observation.json"); require(static_cast<bool>(out), "cannot write resume probe observation");
    out << std::setprecision(17) << "{\"status\":" << quoted(status) << ",\"scenario\":\"resume\",\"error\":" << quoted(error)
      << ",\"model_objects\":1,\"weight_tensors\":335,\"capacity\":64,\"resident_limit\":1,\"active_sequences\":1"
      << ",\"actual_graph_calls\":" << graph_calls << ",\"positive_graph_calls\":" << positive_graph_calls
      << ",\"peak_live_snapshot_versions\":" << peak_versions << ",\"snapshot_slots\":" << model.cache_plan.snapshot_slots
      << ",\"final_live_snapshot_versions\":" << model.snapshot_versions.live << ",\"zero_version_retirements\":" << zero_version_retirements
      << ",\"managed_backing_bytes\":" << actual_backing << ",\"planned_backing_bytes\":" << model.cache_plan.backing_bytes
      << ",\"all_vectors_byte_equal\":" << (all_bytes ? "true" : "false") << ",\"all_finite\":" << (all_finite ? "true" : "false")
      << ",\"wrong_expected_rejected\":" << (mismatch_rejected ? "true" : "false") << ",\"wrong_expected_error\":" << quoted(mismatch_error)
      << ",\"wrong_expected_actual_graph_calls\":" << mismatch_graph_calls << ",\"wrong_expected\":" << (bad_expected.empty() ? "null" : bad_expected)
      << ",\"original_first_record\":" << (actual_first.empty() ? "null" : actual_first)
      << ",\"postcommit_trace_failed\":" << (trace_rejected ? "true" : "false") << ",\"postcommit_trace_error\":" << quoted(trace_error)
      << ",\"postcommit_witness_installed\":" << (trace_commit_witness ? "true" : "false") << ",\"original_ledger_retry_succeeded\":" << (correct_retry ? "true" : "false")
      << ",\"timing_comparison\":false,\"numerical_tolerance_policy\":null"
      << ",\"scope\":\"N1 complete GPU heads are actually retired before product restore. Only original CPU token/decision ledger and raw52/54 oracle survive. Replay uses original roles, input partitions, quota and freshly recomputed proposals. Physical page IDs are not compared across allocations. Final replay Graph outputs54 and final head52 are checked; intermediate replay commits are validated by the product ledger, not claimed as independently read54 images. Equal actual payloads reference one saved baseline raw file.\""
      << ",\"ledger\":[";
    for (std::size_t i = 0; i < ledger.committed_count; ++i) out << (i ? "," : "") << resume_record_json(ledger.records[i]);
    out << "],\"episodes\":[";
    for (std::size_t i = 0; i < episodes.size(); ++i) out << (i ? "," : "") << episodes[i];
    out << "],\"baseline\":[";
    for (std::size_t s = 0; s < baseline.size(); ++s) {
      const auto &step = baseline[s]; out << (s ? "," : "") << "{\"metadata\":" << (step.metadata.empty() ? "null" : step.metadata) << ",\"vectors\":[";
      for (std::size_t i = 0; i < step.vectors.size(); ++i) { const auto &v = step.vectors[i];
        out << (i ? "," : "") << "{\"name\":" << quoted(v.name) << ",\"path\":" << quoted(v.path)
          << ",\"dtype\":" << quoted(v.bf16 ? "BF16" : "F32") << ",\"bytes\":" << v.bytes << ",\"fnv1a64\":" << quoted(v.hash) << '}'; }
      out << "]}";
    }
    out << "],\"vectors\":[";
    for (std::size_t i = 0; i < metrics.size(); ++i) { const auto &v = metrics[i];
      out << (i ? "," : "") << "{\"name\":" << quoted(v.name) << ",\"baseline\":" << quoted(v.baseline) << ",\"actual\":" << quoted(v.actual)
        << ",\"dtype\":" << quoted(v.dtype) << ",\"bytes\":" << v.bytes << ",\"byte_equal\":" << (v.byte_equal ? "true" : "false")
        << ",\"actual_reuses_baseline_payload\":" << (v.byte_equal ? "true" : "false") << ",\"baseline_fnv1a64\":" << quoted(v.baseline_hash)
        << ",\"actual_fnv1a64\":" << quoted(v.actual_hash) << ",\"nonfinite_baseline\":" << v.nonfinite_baseline
        << ",\"nonfinite_actual\":" << v.nonfinite_actual << ",\"max_abs\":" << v.max_abs << ",\"squared_error\":" << v.squared_error
        << ",\"reference_squared\":" << v.reference_squared << '}';
    }
    out << "]}\n"; require(static_cast<bool>(out), "resume observation write failed");
  }
};
void retire_resume_session(q::Model &model, ResumeObservation &observation, std::shared_ptr<q::Session> &session) {
  retire_prefix_session(session); observation.observe(model);
  require(model.snapshot_versions.live == 0 && !model.active_step && !model.carrier_borrowed,
          "resume retained a complete GPU head, candidate or borrowed carrier after retirement");
  ++observation.zero_version_retirements;
}
void resume_commit(q::Model &model, ResumeObservation &observation, const std::shared_ptr<q::Session> &session,
                   q::MtpReplayLedger &ledger, std::span<const std::int32_t> inputs, q::GraphRole role,
                   bool generation, std::size_t quota, const std::string &name, const std::filesystem::path &trace = {}) {
  q::prepare_mtp_replay_record(ledger,*session,role,inputs,generation,quota,0);
  model.prepare_evaluation(*session,inputs,nullptr,role); observation.observe(model);
  require(session->pending && std::count(session->pending->bound.begin(),session->pending->bound.end(),true) == 14,
          "resume episode did not use the original14-bank transaction");
  model.submit_evaluation(*session); ++observation.graph_calls; ++observation.positive_graph_calls;
  q::StepObservation step;
  const q::EvaluationOutput selected{.session=session,.name=name,.trace=&trace,.trace_states=false,.observation=&step,.mtp_ledger=&ledger};
  if (generation) (void)model.finish_mtp_round(*session,quota,std::array<std::int32_t,2>{248044,248046},&selected);
  else (void)model.finish_evaluation(*session,name,trace,false,nullptr,nullptr,&step,nullptr,{},&ledger);
  observation.observe(model);
  require(!model.active_step && !model.carrier_borrowed && !session->pending && ledger.committed_count &&
          ledger.records[ledger.committed_count - 1].committed, "resume commit lacks its original retirement/ledger witness");
  std::ostringstream episode;
  episode << "{\"name\":" << quoted(name) << ",\"record\":" << resume_record_json(ledger.records[ledger.committed_count - 1])
    << ",\"capture_recorded\":" << step.capture_recorded << ",\"capture_reused\":" << step.capture_reused << '}';
  observation.episodes.push_back(episode.str());
}
void run_resume(const std::filesystem::path &inputs, const std::filesystem::path &output) {
  const auto source = q::read_ids(inputs / "prompt.ids"); require(source.size() >= 15, "resume probe needs the original P15 prompt");
  require(!std::filesystem::exists(output), "resume output must be fresh"); std::filesystem::create_directories(output);
  const auto prompt = std::span(source).first(15);
  const auto plan = q::cache::plan(64,1,15,q::recurrent_bytes(q::state_schema_for(64)),1,2,true);
  q::Model model(inputs / "weights.tsv",64,plan); require(model.weights.size() == 335, "resume needs the complete335 Model");
  ResumeObservation observation{.output=output}; q::MtpReplayLedger ledger(4);
  try {
    const std::array prefills{std::size_t{15}};
    const std::array pair{std::size_t{2}};
    const std::array single{std::size_t{1}};
    model.prepare_family(prefills,false,1,q::GraphRole::kMtpPrefill);
    model.plan_replay_uses(15,1,24,q::GraphRole::kMtpPrefill);
    for (auto role : {q::GraphRole::kMtpRound,q::GraphRole::kMtpCatchupRound,q::GraphRole::kMtpSingle,q::GraphRole::kMtpCatchupSingle}) {
      model.prepare_family(q::drafts_token(role) ? std::span(pair) : std::span(single),false,1,role);
      model.plan_replay_uses(q::drafts_token(role) ? 2u : 1u,1,24,role);
    }
    auto session = model.create_session(prefills,{},q::GraphRole::kMtpPrefill);
    const std::array roles{q::GraphRole::kMtpPrefill,q::GraphRole::kMtpRound,q::GraphRole::kMtpCatchupRound,q::GraphRole::kMtpSingle};
    for (std::size_t i = 0; i < roles.size(); ++i) {
      const auto pending = session->head->next_id;
      resume_commit(model,observation,session,ledger,i ? std::span(&pending,1) : prompt,roles[i],i != 0,i == 3 ? 1u : 2u,"continuity" + std::to_string(i));
      observation.record(i,resume_image(model,*session,ledger.records[i]),true,{});
    }
    require(ledger.records[0].after == q::MtpBoundary{15,15,0,198,-1} &&
            ledger.records[1].after == q::MtpBoundary{17,16,1,74455,248045} && ledger.records[1].accepted_draft &&
            ledger.records[2].after == q::MtpBoundary{18,18,0,271,-1} && !ledger.records[2].accepted_draft &&
            ledger.records[3].after.length == 19 && ledger.records[3].after.frontier == 19 && ledger.records[3].after.lag == 0,
            "fixed natural accept/lag1/reject/Single continuity changed");
    observation.actual_first = resume_record_json(ledger.records[0]);
    retire_resume_session(model,observation,session);

    auto lag1_ledger = resume_prefix(ledger,2); q::MtpRestoreStats lag1_stats;
    session = q::restore_mtp_session(model,lag1_ledger,{},false,&lag1_stats);
    observation.graph_calls += lag1_stats.graph_calls; observation.positive_graph_calls += lag1_stats.graph_calls;
    require(lag1_stats.graph_calls == 2 && q::mtp_boundary(*session->head) == ledger.records[1].after,
            "product restore did not reconstruct the lag1 boundary");
    observation.observe(model); observation.record(1,resume_image(model,*session,ledger.records[1]),false,"restore_lag1");
    const auto trace_file = output / "trace-blocker";
    { std::ofstream file(trace_file); file << "ordinary file: postcommit trace failure\n"; require(static_cast<bool>(file),"cannot prepare trace failure"); }
    const auto pending = session->head->next_id;
    try { resume_commit(model,observation,session,lag1_ledger,std::span(&pending,1),q::GraphRole::kMtpCatchupRound,true,2,"postcommit",trace_file); }
    catch (const std::filesystem::filesystem_error &error) { observation.trace_rejected = true; observation.trace_error = error.what(); }
    observation.observe(model);
    observation.trace_commit_witness = observation.trace_rejected && lag1_ledger.committed_count == 3 &&
        lag1_ledger.records[2].committed && lag1_ledger.records[2].same_result(ledger.records[2]) &&
        q::mtp_boundary(*session->head) == ledger.records[2].after && !model.active_step && !model.carrier_borrowed && !session->pending;
    require(observation.trace_commit_witness,"postcommit trace failure lost or duplicated the authoritative ledger/head");
    observation.episodes.push_back("{\"name\":\"postcommit_trace_failure\",\"record\":" + resume_record_json(lag1_ledger.records[2]) + "}");
    observation.record(2,resume_image(model,*session,ledger.records[2]),false,"postcommit_trace_failure");
    retire_resume_session(model,observation,session);

    auto expected_bad = resume_prefix(lag1_ledger,3);
    expected_bad.records[0].target_first = (expected_bad.records[0].target_first + 1) % q::vocabulary;
    observation.bad_expected = resume_record_json(expected_bad.records[0]); q::MtpRestoreStats bad_stats;
    std::shared_ptr<q::Session> unexpected;
    try { unexpected = q::restore_mtp_session(model,expected_bad,{},false,&bad_stats); }
    catch (const std::runtime_error &error) { observation.mismatch_rejected = true; observation.mismatch_error = error.what(); }
    observation.graph_calls += bad_stats.graph_calls; observation.mismatch_graph_calls = bad_stats.graph_calls;
    observation.observe(model);
    require(observation.mismatch_rejected && observation.mismatch_error.find("natural decision or state boundary diverged") != std::string::npos &&
            bad_stats.graph_calls == 1 && !unexpected && !model.active_step && !model.carrier_borrowed && model.snapshot_versions.live == 0 &&
            resume_record_json(ledger.records[0]) == observation.actual_first && !ledger.records[0].generation,
            "wrong expected metadata was not rejected before publishing a recovered head with actual retirement");

    q::MtpRestoreStats lag0_stats;
    session = q::restore_mtp_session(model,lag1_ledger,{},false,&lag0_stats);
    observation.graph_calls += lag0_stats.graph_calls; observation.positive_graph_calls += lag0_stats.graph_calls;
    require(lag0_stats.graph_calls == 3 && q::mtp_boundary(*session->head) == ledger.records[2].after,
            "correct postcommit ledger did not retry naturally to lag0");
    observation.correct_retry = true; observation.observe(model);
    observation.record(2,resume_image(model,*session,ledger.records[2]),false,"restore_lag0");
    const auto final_pending = session->head->next_id;
    resume_commit(model,observation,session,lag1_ledger,std::span(&final_pending,1),q::GraphRole::kMtpSingle,true,1,"resumed_single");
    require(lag1_ledger.committed_count == 4 && lag1_ledger.records[3].same_result(ledger.records[3]),"quota1 continuation changed its natural record");
    observation.record(3,resume_image(model,*session,ledger.records[3]),false,"resumed_single");
    retire_resume_session(model,observation,session);
    require(observation.positive_graph_calls == 11 && observation.graph_calls == 12 && observation.metrics.size() == 216 && observation.all_finite,
            "resume positive/negative graph or complete-vector work did not match the finite probe");
    observation.report(observation.all_bytes ? "PASS_BYTE_EXACT" : "PASS_STRUCTURE_NUMERICAL_DIFFERENCES_RECORDED",model,ledger);
    std::cout << "{\"status\":\"MTP_RESUME_PROBE_COMPLETED\",\"actual_graph_calls\":" << observation.graph_calls
      << ",\"positive_graph_calls\":" << observation.positive_graph_calls << ",\"vectors\":" << observation.metrics.size()
      << ",\"all_vectors_byte_equal\":" << (observation.all_bytes ? "true" : "false") << ",\"timing_comparison\":false}\n";
  } catch (const std::exception &error) { observation.observe(model); observation.report("FAIL",model,ledger,error.what()); throw; }
}
} // namespace

int main(int argc, char **argv) {
  try {
    std::filesystem::path inputs, output;
    std::string scenario = "sessions";
    for (int i = 1; i < argc; i += 2) {
      if (i + 1 == argc) throw std::runtime_error("probe option lacks its value");
      const std::string_view option(argv[i]);
      if (option == "--inputs") inputs = argv[i + 1];
      else if (option == "--output") output = argv[i + 1];
      else if (option == "--scenario") scenario = argv[i + 1];
      else throw std::runtime_error("unknown MTP Session probe option");
    }
    if (inputs.empty() || output.empty() || (scenario != "sessions" && scenario != "prefix" && scenario != "resume"))
      throw std::runtime_error("usage: hyle_qwen35_mtp_session_probe --inputs DIR --output FRESH_DIR [--scenario sessions|prefix|resume]");
    if (scenario == "resume") run_resume(inputs,output);
    else if (scenario == "prefix") run_prefix(inputs,output); else run(inputs, output); return 0;
  } catch (const std::exception &error) { std::cerr << "Qwen MTP Session probe: " << error.what() << '\n'; return 1; }
}
