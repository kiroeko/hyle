from pathlib import Path
root = Path(__file__).resolve().parents[2]
p = root / 'tools/qwen35_text/session_schedule.h'
s = p.read_text()
start = s.index('  std::vector<SessionSchedule> sessions;', s.index('inline std::vector<SessionSchedule> read_session_schedules('))
end = s.index('\n  return sessions;\n}', start)
s = s[:start] + '''  std::vector<SessionSchedule> sessions;
  if (vocabulary <= 0 || vocabulary > (std::numeric_limits<std::int32_t>::max)() ||
      capacity == 0 || capacity > static_cast<std::size_t>((std::numeric_limits<std::int32_t>::max)()))
    throw std::runtime_error("session manifest requires positive vocabulary and context capacity within I32 positions");
  const auto entries = read_session_manifest(path, max_sessions);
  sessions.reserve(entries.size());
  for (const auto &entry : entries) {
    try {
      auto phases = read_schedule(entry.path, vocabulary, capacity, allow_terminal_prompt);
      sessions.push_back({entry.id, std::move(phases)});
    } catch (const std::runtime_error &exception) {
      throw std::runtime_error(path.string() + ":" + std::to_string(entry.line) + ": session " + entry.id + ": " + exception.what());
    }
  }''' + s[end:]
p.write_text(s, newline='\n')
