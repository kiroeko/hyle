"""Integer matrix/index check only: no Torch, weights, build or GPU work."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
HERE = Path(__file__).resolve().parent


def identity(path: Path) -> dict:
    data = path.read_bytes()
    return {"path": path.relative_to(ROOT).as_posix(), "bytes": len(data),
            "sha256": hashlib.sha256(data).hexdigest()}


def hidden(position: int) -> tuple[int, ...]:
    # Distinct small matrix rows expose a missing, repeated or reordered row.
    return tuple((position + 2) * 100 + lane for lane in range(4))


def check(length: int, rows: int, lag: int) -> dict:
    target_tokens = list(range(10000 + length, 10000 + length + rows))
    target_hidden = [hidden(length + i) for i in range(rows)]
    tokens = ([10000 + length - 1] if lag else []) + target_tokens
    shifted = ([hidden(length - 2)] if lag else []) + [hidden(length - 1)] + target_hidden[:-1]
    positions = list(range(length - lag, length + rows))
    assert len(tokens) == len(shifted) == len(positions) == rows + lag
    for token, state, position in zip(tokens, shifted, positions):
        assert token == 10000 + position
        assert state == hidden(position - 1)
    assert length - lag + rows + lag == length + rows
    return {"base_length": length, "target_rows": rows, "lag": lag,
            "target_positions": [length, length + rows - 1],
            "draft_positions": [positions[0], positions[-1]],
            "draft_rows": len(positions), "after_frontier": length + rows}


def main() -> None:
    cases = []
    for length in (0, 1, 2, 15, 16, 17, 31, 32, 63):
        for rows in (1, 2, 3, 8, 15, 16, 17):
            for lag in (0, 1):
                if lag and not length:
                    continue
                cases.append(check(length, rows, lag))
    capacity_cases = 0
    for capacity in (16, 64, 256, 1024):
        for length in range(1, capacity):
            rows = capacity - length
            assert rows + 1 <= capacity
            check(length, rows, 1)
            capacity_cases += 1
    examples = [check(17, rows, lag) for rows in (1, 2, 8) for lag in (0, 1)]
    result = {
        "status": "PASS integer matrix/index assertions",
        "scope": "Independent coordinate/row-order check; not C++ template instantiation, model math, device arithmetic or runtime proof.",
        "matrix_cases": len(cases), "capacity_boundary_cases": capacity_cases,
        "examples": examples,
        "T1": "Same mathematical row order checked; helper is T>=2 and main must use Single/CatchupSingle for T1.",
        "pending": "Target IDs already include an earlier emitted pending token exactly once when warming a later user turn. The prepended draft catch-up token is the previously committed token at L-1, not that pending token at L.",
        "helper": identity(ROOT / "tools/qwen35_text/mtp_graph.h"),
    }
    output = HERE / "shift-review.json"
    output.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"status": result["status"], "matrix_cases": len(cases),
                      "capacity_boundary_cases": capacity_cases, "report": str(output)}))


if __name__ == "__main__":
    main()
