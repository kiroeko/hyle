"""Freeze this one owned graph helper and the limited host review."""
from __future__ import annotations

import difflib
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
HERE = Path(__file__).resolve().parent


def identity(path: Path) -> dict:
    raw = path.read_bytes()
    return {"path": path.relative_to(ROOT).as_posix(), "bytes": len(raw),
            "sha256": hashlib.sha256(raw).hexdigest()}


def write(path: Path, value: dict) -> None:
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def main() -> None:
    source = ROOT / "tools/qwen35_text/mtp_graph.h"
    before = HERE / "before/tools/qwen35_text/mtp_graph.h"
    frozen = HERE / "source/tools/qwen35_text/mtp_graph.h"
    frozen.parent.mkdir(parents=True, exist_ok=True)
    frozen.write_bytes(source.read_bytes())
    diff = HERE / "implementation.diff"
    diff.write_text("".join(difflib.unified_diff(
        before.read_text(encoding="utf-8").splitlines(keepends=True),
        source.read_text(encoding="utf-8").splitlines(keepends=True),
        fromfile="before/tools/qwen35_text/mtp_graph.h", tofile="tools/qwen35_text/mtp_graph.h")), encoding="utf-8")
    original_main = ROOT / ".scratch/qwen-mtp-resume-20261022/before/tools/qwen35_text/main.cc"
    report = {
        "status": "Source implementation frozen; no C++ build, model math or GPU execution by this task.",
        "owned_product": identity(source),
        "interface": "mtp::KeyValue mtp::prefill_kv(R&, Value target_ids, Value normalized_target_rows, Value carry, Value prior, Value catchup_token, Dimension draft_rows, Value positions, Value frequencies, bool catchup)",
        "scope": "Only ordinary Graph Slice/Concat followed by existing input_projection/project_kv. No append, publication, queue, provider, proposal injection, submission or state owner is created by this helper.",
        "caller_contract": [
            "Recipe defines token_rows=last_row+1. This multirow helper is only selected for exact T>=2 finite children. Single/CatchupSingle handles T1 without an empty hidden Slice.",
            "target_ids are the actual T new target inputs, normalized_target_rows are their BF16 post-final-RMSNorm [T,2048] rows. carry is old h[L-1]; lag1 prior is h[L-2] and catchup_token is the already committed token at L-1.",
            "Lag0: tokens=target_ids, hidden=[carry,new_target_hidden[:-1]], draft positions L..L+T-1.",
            "Lag1: tokens=[catchup_token,target_ids], hidden=[prior,carry,new_target_hidden[:-1]], draft positions L-1..L+T-1. Actual target work remains T rows; both committed frontiers end at L+T and lag0.",
            "Main creates the actual draft_rows Dimension once and shares it with the position-port spec and this helper. The helper checks exact identity against that port, uses the same Dimension in Concat outputs, and never independently recreates T+1. Original finite-child inference still validates semantic row counts. RoPE positions are unchanged.",
            "Caller must explicitly order the last target append effect before new draft K append; original draft K->V and whole-Graph success/retirement remain unchanged. A hidden data edge alone is not a substitute for explicit unknown-external-write ordering.",
            "When warming a later user turn, the target input is [previous pending]+new user IDs. Consume that previously emitted pending exactly once; do not duplicate it with the separate lag1 draft catch-up token."
        ],
        "budget_review": {
            "schema": "Shared BatchSchema max_query_rows must cover max(target_T,draft_T+lag). Lag1 warm T needs T+1; nominal target shape alone is insufficient.",
            "context": "For lag1, L>=1 and target T<=C-L imply T+1<=C. No extra KV context is required. Do not add1 to a lag0 initial P=C shape unnecessarily.",
            "existing_plan": "session_state.h::plan reserves N+R Snapshot versions, N+2R recurrent alternatives for MTP, 2*(N+R) carry/prior hidden rows, and N*ceil(C/16)+R physical pages independently per each of 14 banks. One serialized warm episode fits these original bounds under original L/D admission; it is not a separately committed draft catch-up transaction.",
            "restore": "Restoring a truly nonresident/retired request allows at most N-1 other committed heads, one reconstructed working head and the existing +1 candidate. Retaining an old resident head while rebuilding from scratch can require N+2 versions and is not covered by the N+1 plan.",
            "owners": "Replay ledger must remain host-only and must not hold SnapshotRefs/ReadLeases across reconstructed steps. Directory alias eviction does not prove a version was freed; recount real VersionCount and original selected-base D after temporary Hits are released.",
            "failure": "Use original 14-bank publication, partial-export cleanup and native retirement gates. No use_count/unused-tail/footprint shortcut grants a write permission."
        },
        "commit_witness_review": {
            "existing_risk": "The frozen baseline swaps the complete head before tracing/reporting that can throw. Appending CPU generation or replay records only after finish returns can omit an already committed episode.",
            "agreed_private_change": "Root/quant selected a typed preallocated ledger record plus count pointer in EvaluationOutput. Selector fills fresh decision fields; after all head swaps and before detach/reporting, infallibly fill after-metadata, then mark committed and increment count exactly once.",
            "required_checks": [
                "Prevalidate record/count lifetime, index/capacity and all checked arithmetic before submission. Record fields are fixed scalars/arrays or immutable already-owned input spans; no allocation/callback/lease ownership is introduced at commit.",
                "CPU generated IDs, round counts and authoritative replay history must derive from the same committed witness, including a reporting exception after the real swap. Do not leave them dependent on finish returning normally.",
                "A precommit selector mismatch writes no committed record and uses original abort/retirement. A postcommit trace error must not replay or abort the already committed step a second time.",
                "Restorer compares freshly computed draft/target/accepted boundaries against an immutable expected record before publication. It may not inject recorded proposals or replace original T2 verification with T1 token-tape replay."
            ],
            "scope": "Design review only: main/ledger implementation is owned by quant and not yet reviewed/frozen by this helper report."
        },
        "read_only_references": [identity(original_main), identity(ROOT / "tools/qwen35_text/session_state.h")],
        "source_anchors": {
            "before_main": "Z/before main SHA7999: Recipe:213-235, original prompt shift:1199-1207, draft rows:1563+, finish-selected swap/detach before trace:1995-2054. These anchors refer to the before snapshot, not the concurrently edited canonical main.",
            "session_state": "Plan:29-101, VersionCount/VersionRef:175-198, immutable DraftState/Snapshot:199-222.",
            "helper": "Original input_projection and project_kv are unchanged; new prefill_kv is inserted between project_kv and append_kv."
        },
        "revision": {
            "initial": "revisions/initial-derived-symbol preserves the initial e96c969e helper/freeze. It independently constructed T+1, but graph.cc::derived_dimension creates a fresh ordinal rather than interning expressions. A separately constructed position-port T+1 therefore failed coordinates()'s exact Dimension identity check. This is a real cold-construction defect in the initial source, not a numerical mismatch.",
            "fix": "One explicit shared draft_rows argument, exact equality with positions dimension, and no local dimension_sum. Main owns the one derived symbol; no public Graph/API change.",
            "source_evidence": "src/graph/graph.cc:159-184 appends a fresh DimensionRecord and returns its new ordinal for every derived_dimension call."
        },
        "independent_check": identity(HERE / "shift-review.json"),
        "limits": "119 synthetic integer matrix/index cases plus1356 capacity boundary cases; not a compiled C++ template, BF16 arithmetic test, natural MTP acceptance result or any backend pass. No public API or numerical tolerance changed."
    }
    write(HERE / "report.json", report)
    write(HERE / "source-freeze.json", {
        "status": "source-only owned helper freeze",
        "files": [{"current": identity(source), "before": identity(before), "frozen": identity(frozen), "diff": identity(diff)}],
        "report": identity(HERE / "report.json"),
        "shift_check": identity(HERE / "shift-review.json"),
        "scripts": [identity(HERE / "check_shift.py"), identity(Path(__file__))],
        "builds": 0, "gpu_runs": 0,
    })
    print(json.dumps({"source": identity(source), "freeze": identity(HERE / "source-freeze.json")}))


if __name__ == "__main__":
    main()
