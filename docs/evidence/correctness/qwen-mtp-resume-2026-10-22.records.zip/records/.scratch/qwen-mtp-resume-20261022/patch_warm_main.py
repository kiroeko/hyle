from pathlib import Path
p = Path(__file__).resolve().parents[2] / 'tools/qwen35_text/main.cc'
s = p.read_text()
s = s.replace('role != GraphRole::kMtpPrefill', '!is_mtp_prefill(role)')
s = s.replace('role == GraphRole::kMtpPrefill', 'is_mtp_prefill(role)')
# Restore the predicate body itself after the mechanical caller update.
s = s.replace('return is_mtp_prefill(role) || role == GraphRole::kMtpCatchupPrefill;',
              'return role == GraphRole::kMtpPrefill || role == GraphRole::kMtpCatchupPrefill;')
s = s.replace('active_step->phase->family->is_mtp_prefill(role)',
              'is_mtp_prefill(active_step->phase->family->role)')
s = s.replace('is_mtp_prefill(role) ? t : f(static_cast<std::int64_t>(draft_lag(role) + 1))',
              'is_mtp_prefill(role) ? take(r.builder.dimension_sum(t, f(static_cast<std::int64_t>(draft_lag(role))))) : f(static_cast<std::int64_t>(draft_lag(role) + 1))')
old = '''      const auto previous = r.slice(normalized_last, 0, f(0), D(r.last_row));
      const auto shifted = r.one(c::Concat{.axis = 0}, {definition.carry_input_port, previous},
          r.dense_spec(Type::kBFloat16, {t, f(hidden)}));
      const auto projection = mtp::input_projection(r, definition.token_port, shifted);
      const auto kv = mtp::project_kv(r, projection, definition.draft_position_port, frequencies);'''
new = '''      const auto kv = mtp::prefill_kv(r, definition.token_port, normalized_last,
          definition.carry_input_port, definition.prior_input_port, definition.catchup_token_port,
          definition.draft_position_port, frequencies, draft_lag(role) != 0);'''
assert old in s
s = s.replace(old, new, 1)
old = '''      const auto append = mtp::append_kv(r, attention_schema, kv);
      definition.append_nodes[12] = append.key; definition.append_nodes[13] = append.value;'''
new = '''      const auto append = mtp::append_kv(r, attention_schema, kv);
      check(r.builder.depends_on(append.key, definition.append_nodes[11]));
      definition.append_nodes[12] = append.key; definition.append_nodes[13] = append.value;'''
assert old in s
s = s.replace(old, new, 1)
s = s.replace('is_mtp_prefill(role) ? step.input_tokens : draft_lag(role) + 1',
              'is_mtp_prefill(role) ? cache::add(step.input_tokens, draft_lag(role)) : draft_lag(role) + 1')
s = s.replace('''(session.length() && !is_mtp_prefill(role) && role != GraphRole::kMtpSingle &&
             request.ids.front() != session.head->next_id)''',
              '''(session.length() && drafts_token(role) && request.ids.front() != session.head->next_id)''')
# Fixed Phase allocation uses target T plus the one lagged draft row.
s = s.replace('is_mtp_prefill(role) ? t : static_cast<std::int64_t>(draft_lag(role) + 1)',
              'is_mtp_prefill(role) ? t + static_cast<std::int64_t>(draft_lag(role)) : static_cast<std::int64_t>(draft_lag(role) + 1)')
p.write_text(s, newline='\n')
