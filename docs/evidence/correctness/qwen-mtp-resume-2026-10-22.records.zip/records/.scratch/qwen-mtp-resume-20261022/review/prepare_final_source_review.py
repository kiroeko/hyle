"""Freeze the scoped final static review; no native/model execution."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
HERE = Path(__file__).resolve().parent
EXPECTED = {
    "tools/qwen35_text/main.cc": "40103f1f1852e2ba4082e71e67854bfdfa1d9bc49e97515a328054702cdba46d",
    "tools/qwen35_text/session_schedule.h": "7ce20af02378a4904cda4d522a01ffeb7b047febaaed5b41d1b82c7ab18c31ac",
    "tools/qwen35_text/schedule.h": "093583e30cdce2e55d4a40b3f384715a25928a3583b8171057c0719218145fbe",
    "tools/qwen35_text/mtp_schedule.h": "091a7d5c7b61bf72c842ddbb540f428ae29d362fc0a2a7892d2f2cd1dd7349ff",
    "tools/qwen35_text/mtp_graph.h": "fcae043370a879177605eb06351a6bfafdc30e57db83e50d46a3d2cf4bdcf79e",
}


def identity(path: Path) -> dict:
    raw = path.read_bytes()
    return {"path": path.relative_to(ROOT).as_posix(), "bytes": len(raw),
            "sha256": hashlib.sha256(raw).hexdigest()}


def write(path: Path, value: dict) -> None:
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def main() -> None:
    history = HERE / "revisions" / "source-phase1"
    history.mkdir(parents=True, exist_ok=True)
    for name in ("source-review.json", "source-review-freeze.json"):
        target = history / name
        if not target.exists():
            target.write_bytes((HERE / name).read_bytes())
    frozen = HERE / "source-final"
    sources = []
    for name, expected in EXPECTED.items():
        source = ROOT / name
        assert identity(source)["sha256"] == expected, f"source drift: {name}"
        target = frozen / name
        if target.exists():
            assert identity(target)["sha256"] == expected, f"frozen source drift: {name}"
        else:
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(source.read_bytes())
        sources.append({"current": identity(source), "frozen": identity(target)})
    main_file = frozen / "tools/qwen35_text/main.cc"
    lines = main_file.read_text(encoding="utf-8").splitlines()

    def anchor(needle: str) -> dict:
        return {"path": main_file.relative_to(ROOT).as_posix(),
                "line": next(i for i, line in enumerate(lines, 1) if needle in line),
                "text": needle}

    report = {
        "status": "final scoped static review: no remaining blocking finding in these exact sources",
        "sources": sources,
        "scope": "Private natural-turn/session parsers, shared bounded IDs reader, MTP typed ledger/commit witness/restore, final run_mtp_sessions driver/CLI, warm host owners and finite preparation/accounting. No generic backend or expanded model audit.",
        "findings": [],
        "resolved_defects_and_review_history": [
            {
                "issue": "The first warm helper independently created T+1. Graph derived dimensions are not interned, so equal expressions had different IDs from the position port and failed exact coordinates().",
                "resolution": "One main-owned draft_rows symbol is passed explicitly to prefill_kv and shared with the position spec. Helper checks identity and does not recreate dimension_sum. Original source e96c is preserved under warm-helper/revisions/initial-derived-symbol.",
                "current": "mtp_graph.h fcae0433"
            },
            {
                "issue": "Early observe_mtp_commits built result.emitted with a fresh allocation after actual head publication. With insufficient multi-turn reservation, generated insertion could throw after rounds/counters changed but before ledger_observed advanced.",
                "resolution": "Per-request constructor is given sum(all turn quotas), reserving generated and rounds for that total. A cold round_emitted pool has outputs-1 slots, each reserve2. Observer moves the unused slot's storage into the result, assigns at most2 I32s in capacity, moves into reserved rounds, appends into reserved generated, updates scalar metadata, and only then advances ledger_observed. No allocation is needed along this valid postcommit path.",
                "attribution": "Root identified the allocation defect; this final review independently checked the corrected capacity argument and consumer order."
            },
            {
                "issue": "The first read_session_manifest extraction rejected max_sessions > vector<SessionManifestEntry>::max_size(), although wrappers pass the max_size of a different element type. A valid default wrapper limit could therefore be rejected before reading any session.",
                "resolution": "Final session_schedule.h 7ce20af0 checks nonzero max_sessions and the actual parsed count, with no comparison to another vector element type's max_size. Normal container allocation/index bounds still apply.",
                "review_miss": "The earlier source-phase1 review missed this wrapper/container-type mismatch. Its old-header no-blocker statement is superseded for this seam; it is preserved, not silently rewritten.",
                "validation_boundary": "Parent reports the old-header two host compiles and link succeeded but were superseded before any GPU run. This review is source-only and does not claim the corrected header has run."
            }
        ],
        "checks": [
            {
                "area": "parser and CLI rejection",
                "facts": "Both grammars use read_schedule_ids for strict whole-token from_chars, vocabulary/range, NUL path, nonempty/EOF and pre-push row limit. Fixed PhaseKind and prompt/decode grammar are unchanged. MTP uses explicit prompt/generate quotas, preserves one-prompt --steps shorthand and rejects fixed decode tapes/ambiguous explicit quotas. All schedules/context sums, Rauto1 restriction and cache-byte minimum selection precede Model weight loading.",
                "anchors": [anchor("if (active_sequences > 1)"), anchor("std::vector<qwen35::benchmark::MtpSessionSchedule> mtp_schedules;")]
            },
            {
                "area": "commit witness and natural policy",
                "facts": "The reserved record is validated against the actual role/base/input before wait. Natural selector results and after-boundaries are compared to immutable expected facts before any head swap. All14 ready results, owned state exports, tail checks, unbind and expected-base checks precede complete head publication. committed/count are then written infallibly before detach and later trace/report I/O; endpoint timing is also recorded before those diagnostics. Generation still post-wait rejects first_input != original pending, even though prompt Single/CatchupSingle permits arbitrary valid input.",
                "anchors": [anchor("MTP replay natural decision or state boundary diverged"), anchor("commit_record->committed = true;"), anchor("MTP generation input differs from its original pending token")]
            },
            {
                "area": "observer capacities and exactly-once host facts",
                "facts": "Each turn contributes at least1 output. With total requested outputs O=sum(K), generated count<=O, generation rounds<=sum(K-1)<=O-1, and emitted_count<=2. Constructor reserves those O/O-1 parent slots, cold emitted pool reserves2 per slot, and the pre-episode guard checks cumulative steps. Thus the observer's moves/copies use existing storage for trivial I32/scalar fields. ledger_observed is last, and the trace-error catch consumes committed facts before rethrowing instead of rerunning a committed episode.",
                "anchors": [anchor("result.emitted = std::move(request.round_emitted[request.rounds.size()]);"), anchor("++request.ledger_observed;"), anchor("request.round_emitted.resize(outputs - 1);")],
                "limit": "This is a source/capacity argument under the parser/driver invariants, not injected allocation-failure runtime evidence."
            },
            {
                "area": "warm input owners / shift",
                "facts": "All turn vectors are allocated before execution. Each later turn has its own unused first slot for the preceding emitted pending; it is filled once when that turn is admitted. Previous ledger spans point into different earlier vectors and are not mutated. Each prompt record retains that vector via input_owner, so idle Session retirement does not destroy replay input. Warm lag1 uses T target rows, T+1 draft rows, [prior,carry,new_hidden[:-1]], [catchup_token,target_ids] and unchanged draft positions; the existing explicit target-last-V -> draft-K effect edge remains.",
                "anchors": [anchor("request.warm_inputs.reserve(schedule.turns.size());"), anchor("(*request.warm_inputs[request.turn_index])[0] = request.session->head->next_id;"), anchor("check(r.builder.depends_on(append.key, definition.append_nodes[11]));")]
            },
            {
                "area": "bounded restoration and directory owners",
                "facts": "Only idle entries outside the active generation set can be LRU victims. retire_mtp_request performs original stop/try_retire and drops the old Session before new reconstruction. Restore requires an idle carrier, a zero-origin complete host ledger and real live-version room. It owns only one working head plus the existing candidate. Each generation replays its original role/quota and freshly computed GPU proposal/T2 target selection; immutable expected facts gate publication. Temporary Hits are reset before L/D admission; directory aliases remain real retained versions. No SnapshotRef/lease oracle is stored per replay step.",
                "anchors": [anchor("std::shared_ptr<Session> restore_mtp_session"), anchor("all MTP heads are generating; no idle owner may be evicted"), anchor("retire_mtp_request(requests[victim]);")],
                "failure": "Mismatch/prepare/trace exceptions stop and drain the temporary Session. A postcommit temporary restore remains a real committed witness, but the failed temporary request is discarded; the original immutable ledger is not rewritten. No T2-to-T1 forced replay or credit from mere directory erasure is introduced."
            },
            {
                "area": "finite shapes and replay-use bounds",
                "facts": "All initial nominal/suffix shapes at earlier real prompt checkpoints are planned. Every later user prompt has actual target width user_count+1 and both lag0/lag1 prompt roles. Generation retains original Single/Round/catchup roles. Schema maxima include warm draft T+1. The total restore bound sums at most(turn_count-1)*ledger_capacity per request when N is smaller than request count; it conservatively bounds per-shape replay uses and is added before any carrier is prepared. Imported source chunks are from the same global prior-prompt shape union. Full hits run0 Graph and do not fabricate output tensors.",
                "anchors": [anchor("restore_bound = cache::add(restore_bound, cache::multiply(schedule.turns.size() - 1, ledger_capacity));"), anchor("model.plan_replay_uses(tokens, 1, cache::add(count, restore_bound), role);"), anchor("std::size_t mtp_schema_rows = 0;")]
            },
            {
                "area": "work counts / timing / final lifetimes",
                "facts": "Real restore Graph/target/draft work is counted separately and included in actual totals, without becoming new user outputs. Logical prompt counts include one prior pending per later turn. Final report uses retained scalar metadata, not a retired Session head. Each request reports per-turn P/D latency plus between_turn_seconds; session wall includes idle gaps. Global P/D uses disjoint continuous episode intervals, so the request latency sums are not pooled as throughput. Requests and prefix directory are local owners destroyed before their outer Model.",
                "anchors": [anchor("\"between_turn_seconds\"".replace('"', '\\"')), anchor("retire_mtp_request(request); ++completed;"), anchor("actual_target_rows")],
                "limit": "No timing quality, speedup, numerical equivalence or backend pass is inferred from this static review."
            }
        ],
        "history": {
            "phase1": identity(history / "source-review.json"),
            "parser_phase": identity(HERE / "parser-review.json"),
            "note": "Historical phase reports predate later implementation/corrections. This final report supersedes their applicable source conclusions and retains the explicit missed parser defect."
        },
        "limits": "Read-only final source review. This task performed0 C++ builds,0 parser/runtime tests,0 Torch/model calculations and0 GPU runs; root owns all actual compile/runtime validation. It does not sign MTP quality/acceptance rate, throughput, MTP R2 or other backends."
    }
    report_path = HERE / "source-review.json"
    write(report_path, report)
    freeze_path = HERE / "source-review-freeze.json"
    write(freeze_path, {"phase": "source-final", "report": identity(report_path),
                        "script": identity(Path(__file__)), "sources": sources,
                        "builds": 0, "gpu_runs": 0})
    print(json.dumps({"report": identity(report_path), "freeze": identity(freeze_path)}))


if __name__ == "__main__":
    main()
