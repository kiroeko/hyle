"""Host-only checks of actual natural-turn and faithful-replay CUDA evidence."""
from pathlib import Path
import hashlib,json,math,zipfile
import numpy as np

Z=Path(__file__).resolve().parents[1];R=Z.parents[1]
def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def save(p,d):Path(p).write_text(json.dumps(d,indent=2,allow_nan=False)+'\n')
def identity(p):
 p=Path(p);raw=p.read_bytes()
 return dict(path=str(p.resolve()),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def values(raw,suffix):
 if suffix=='.bf16':
  assert len(raw)%2==0
  return(np.frombuffer(raw,dtype='<u2').astype(np.uint32)<<16).view(np.float32)
 assert suffix=='.f32'and len(raw)%4==0
 return np.frombuffer(raw,dtype='<f4')
def norm(p):return str(p).replace('\\','/').casefold()
class OldArchive:
 def __init__(self,name):
  self.manifest=read(R/f'docs/evidence/correctness/{name}.json')
  self.zip=zipfile.ZipFile(self.manifest['archives'][0]['path'])
  self.files={norm(v['path']):v for v in self.manifest['archive_files']};self.used={}
 def raw(self,p):
  rec=self.files[norm(p)];raw=self.zip.read(rec['entry'])
  assert len(raw)==rec['bytes']and hashlib.sha256(raw).hexdigest()==rec['sha256']
  self.used[norm(p)]=rec;return raw
def timing(row):
 p,d,wall=[row[k]for k in('prefill_seconds','decode_seconds','session_seconds')]
 assert p>0 and d>=0 and math.isclose(p+d,wall,rel_tol=1e-12,abs_tol=1e-12)
 assert row['startup_to_ready_seconds']<=row['first_token_elapsed_seconds']<=row['startup_to_endpoint_seconds']
 assert row['startup_total_seconds']==row['startup_to_endpoint_seconds']
 assert math.isclose(row['output_tokens_per_second'],row['generated_tokens']/wall,rel_tol=1e-12)
 return dict(prefill=p,decode=d,wall=wall,sum_error=p+d-wall,diagnostic=True,performance_evidence=False)

def main():
 raw_files={};comparisons=[]
 def inspect(p):
  p=Path(p).resolve();raw=p.read_bytes();v=values(raw,p.suffix)
  assert np.isfinite(v).all(),str(p)
  raw_files[str(p)]=dict(**identity(p),elements=int(v.size),nonfinite=0)
  return raw
 def equal(p,reference,raw_reference=None,label='same_partition'):
  a=inspect(p);b=Path(reference).read_bytes()if raw_reference is None else raw_reference
  assert np.isfinite(values(b,Path(p).suffix)).all()and a==b,(str(p),str(reference))
  comparisons.append(dict(actual=str(Path(p).resolve()),reference=str(reference),label=label,
   bytes=len(a),sha256=hashlib.sha256(a).hexdigest(),byte_equal=True))
 ready=read(Z/'qwen-ready-attempt2.json');results={};runs=[]
 for case in ['resident-n3','resume-n1','one-schedule','shorthand','single','ordinary','prefix-n2']:
  out=Z/'cli-runs1'/case;t=read(out/'run.result.json');plan=read(out/'plan.json');row=read(out/'parsed.json')
  assert t['terminal']and t['exit']==0 and t['command']==plan['command']
  assert plan['ready']==ready and plan['diagnostic']and not plan['throughput_evidence']
  assert json.loads((out/'run.stdout.log').read_text())==row
  results[case]=row
  for p in(out/'trace').rglob('*'):
   if p.suffix in('.bf16','.f32'):inspect(p)
  runs.append(dict(case=case,terminal=identity(out/'run.result.json'),result=identity(out/'parsed.json'),timing=timing(row)))
 def logical(case):
  root=Z/'cli-runs1'/case/'trace'
  return{p.relative_to(root).as_posix():p for p in root.rglob('*')if p.suffix in('.bf16','.f32')and 'restores'not in p.relative_to(root).parts}
 baseline,restored=logical('resident-n3'),logical('resume-n1')
 assert baseline.keys()==restored.keys()
 for name,p in restored.items():equal(p,baseline[name],label='N1_LRU_vs_N3_resident')
 assert len(baseline)==19*38
 for case in ['resume-n1','prefix-n2']:
  for actual,reference in zip(results[case]['sessions'],results['resident-n3']['sessions']):
   assert actual['session_id']==reference['session_id']
   assert actual['result']['generated_ids']==reference['result']['generated_ids']
   assert actual['result']['rounds']==reference['result']['rounds']
   assert len(actual['ledger'])==len(reference['ledger'])
   for a,b in zip(actual['ledger'],reference['ledger']):
    assert {k:v for k,v in a.items()if k not in('imported','trace_name')}=={k:v for k,v in b.items()if k not in('imported','trace_name')}
 # Every replayed original episode has the same partition, role and numerical
 # payload oracle. Imported full hits use the real original Prefill as oracle.
 for case in ['resume-n1','prefix-n2']:
  root=Z/'cli-runs1'/case/'trace';count=0
  for i,session in enumerate(results[case]['sessions']):
   sid=f"session{i}_{session['session_id']}";original=results['resident-n3']['sessions'][i]['ledger']
   first_later=next(v['index']for v in original if v['turn']==2)
   for j in range(first_later):
    directory=root/sid/'restores/restore0'/f'episode{j}'
    files=[p for p in directory.iterdir()if p.suffix in('.bf16','.f32')]
    assert len(files)==(38 if case=='resume-n1'else 2)
    for p in files:
     equal(p,baseline[f"{sid}/{original[j]['trace_name']}/{p.name}"],label='faithful_original_episode_replay');count+=1
  assert count==(380 if case=='resume-n1'else 20)
 for name,p in logical('prefix-n2').items():equal(p,baseline[name],label='prefix_import_and_restore_vs_original')
 assert len(logical('prefix-n2'))==36
 hit=read(Z/'cli-runs1/prefix-n2/trace/session1_B/prefill/cache-hit.json')
 assert hit==dict(prefix_hit=True,graph_calls=0,tensor_payload_available=False,reused_tokens=15,next_id=198)
 assert results['prefix-n2']['sessions'][1]['ledger'][0]['imported']
 for name,p in logical('shorthand').items():
  equal(p,Z/'cli-runs1/single/trace'/Path(name).relative_to('session0_default'),label='shorthand_vs_original_single')
 for name,p in logical('one-schedule').items():
  relative=Path(name).relative_to('session0_default')
  if relative.parts[0].startswith('round2_'):continue
  equal(p,baseline['session0_A/'+relative.as_posix()],label='short_warm_case_original_first_turn')
 old=OldArchive('qwen-mtp-prefix-2026-10-22')
 for case in ['single','ordinary']:
  for name,p in logical(case).items():
   previous=R/'.scratch/qwen-mtp-prefix-20261022/cli-runs1'/case/'trace'/name
   equal(p,previous,old.raw(previous),label='unchanged_original_entry')
 assert len(raw_files)==1912 and len(comparisons)==1184
 finite_only=[identity(p)for name,p in logical('one-schedule').items()if Path(name).parts[1].startswith('round2_')]
 assert len(finite_only)==6
 probe=read(Z/'probe/actual-analysis.json');assert probe['status'].startswith('PASS')
 errors=read(Z/'review/errors-analysis.json');assert len(errors['cases'])==8 and errors['model_weight_loads']==0
 report=dict(status='PASS_CLI_BYTE_EXACT_AND_FINITE_SCOPE',runs=runs,results=results,raw_files=list(raw_files.values()),
  byte_exact_comparisons=comparisons,old_archive_entries=list(old.used.values()),
  finite_only_short_warm_payloads=finite_only,probe_analysis=identity(Z/'probe/actual-analysis.json'),early_errors=identity(Z/'review/errors-analysis.json'),
  performance_window_performed=False,limits=['Diagnostic trace timings are not performance measurements.',
   'N3 same-partition Graph outputs are the numerical oracle for N1/N2 replay and continuation, not an independent mathematical/quality reference.',
   'Six short-warm T2-prefill and subsequent payloads are finite and structurally checked, without an independent same-partition numerical oracle.'])
 save(Z/'review/actual-analysis.json',report)
 print(json.dumps(dict(status=report['status'],numeric_files=len(raw_files),paired_vectors=len(comparisons))))
if __name__=='__main__':main()
