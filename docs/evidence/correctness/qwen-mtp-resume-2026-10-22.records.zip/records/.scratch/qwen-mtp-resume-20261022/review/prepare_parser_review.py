"""Static source audit of the two frozen token-reader extraction headers."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
HERE = Path(__file__).resolve().parent


def identity(path: Path) -> dict:
    raw = path.read_bytes()
    return {"path": path.relative_to(ROOT).as_posix(), "bytes": len(raw),
            "sha256": hashlib.sha256(raw).hexdigest()}


def main() -> None:
    freeze_path = HERE / "parser-source-freeze.json"
    freeze = json.loads(freeze_path.read_text(encoding="utf-8"))
    sources = []
    for entry in freeze["files"]:
        current = Path(entry["path"])
        snapshot = Path(entry["snapshot"])
        assert identity(current)["sha256"] == entry["sha256"] == identity(snapshot)["sha256"]
        sources.append({"current": identity(current), "snapshot": identity(snapshot)})
    result = {
        "status": "no blocking finding in the scoped static parser extraction",
        "source_freeze": identity(freeze_path), "sources": sources,
        "shared_manifest": identity(ROOT / "tools/qwen35_text/session_schedule.h"),
        "reviewed_facts": [
            "read_schedule_ids preserves strict from_chars full-token consumption, nonnegative vocabulary-bound I32 IDs, nonempty/EOF checks and a bound checked before every push.",
            "The helper rejects embedded native-path NUL before opening the token file. Relative/quoted path interpretation remains in each grammar.",
            "Fixed-input read_schedule passes capacity-total to the helper. Since every successful phase size fits that remaining count, total stays within capacity before the next subtraction; PhaseKind and prompt/decode turn ordering are unchanged.",
            "Natural MTP read_mtp_schedule passes the per-prompt capacity and retains its separate subtraction-based sum of user inputs, previous pending once, and per-turn quota-1 committed generation inputs. It continues rejecting fixed decode tapes.",
            "Both callers wrap the common reader's diagnostics with their original manifest path/line. The session-manifest caller adds session ID context."
        ],
        "findings": [],
        "scope": "Only source review and identity comparison. No added tests, parser execution, build, GPU or complete main-driver claim.",
    }
    path = HERE / "parser-review.json"
    path.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(identity(path)))


if __name__ == "__main__":
    main()
