"""Host-only ledger/CLI accounting review. Does not read tensor payloads or launch models."""
from pathlib import Path
from collections import Counter
import hashlib
import json
import math
import re
import shlex

Z = Path(__file__).resolve().parents[1]
ROOT = Z.parents[1]
EOS = {248044, 248046}
NAMES = ['resident-n3', 'resume-n1', 'one-schedule', 'shorthand', 'single', 'ordinary', 'prefix-n2']
ROLES = {2: 'MtpPrefill', 3: 'MtpRound', 4: 'MtpCatchupRound',
         5: 'MtpSingle', 6: 'MtpCatchupSingle', 7: 'MtpCatchupPrefill'}
CHECKS = 0
READ = {}


def check(condition, message):
    global CHECKS
    CHECKS += 1
    if not condition:
        raise AssertionError(message)


def raw(path):
    data = path.read_bytes()
    READ[str(path.relative_to(ROOT)).replace('\\', '/')] = {
        'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
    return data.decode('utf-8-sig')


def read(path):
    return json.loads(raw(path))


def close(a, b, message, tolerance=2e-12):
    check(math.isfinite(a) and math.isfinite(b) and math.isclose(a, b, rel_tol=tolerance, abs_tol=tolerance), message)


def terminal(path, expected=0):
    receipt = read(path)
    check(receipt['terminal'] and receipt['exit'] == expected, str(path) + ' terminal/exit')
    check(receipt['finished'] >= receipt['started'], str(path) + ' timestamps')
    return receipt


def getoption(command, option, default=None):
    return command[command.index(option) + 1] if option in command else default


def fnv(ids):
    value = 1469598103934665603
    for token in ids:
        value = ((value ^ token) * 1099511628211) & ((1 << 64) - 1)
    return value


def turns(path, shorthand=None):
    lines = [shlex.split(line) for line in raw(path).splitlines() if line.strip() and not line.lstrip().startswith('#')]
    result = []
    for i in range(0, len(lines), 2):
        check(lines[i][0] == 'prompt', str(path) + ' prompt grammar')
        ids = list(map(int, raw(path.parent / lines[i][1]).split()))
        quota = int(lines[i + 1][1]) if i + 1 < len(lines) else shorthand
        check(bool(ids) and quota is not None and quota > 0, str(path) + ' prompt/quota')
        result.append((ids, quota))
    return result


def request_specs(command):
    shorthand = int(getoption(command, '--steps', '4'))
    if '--session-schedules' in command:
        manifest = Path(getoption(command, '--session-schedules'))
        return {sid: turns(manifest.parent / name, shorthand) for sid, name in
                (shlex.split(line) for line in raw(manifest).splitlines() if line.strip())}
    return {'default': turns(Path(getoption(command, '--schedule')), shorthand)}


def target_rows(record):
    return 2 if record['role'] in (3, 4) else record['input_rows']


def review_session(arm, directory, entry, spec):
    sid = entry['session_id']
    result, ledger = entry['result'], entry['ledger']
    generated, reconstructed = result['generated_ids'], []
    current = (0, 0, 0, -1)
    role_counts, by_turn = Counter(), []
    decoded, new_calls, prefill_calls, verified, drafted = 0, 0, 0, 0, 0
    ptarget, pdraft, agreements, accepted_drafts, rounds = 0, 0, 0, 0, []
    for i, record in enumerate(ledger):
        prefix = f'{arm}/{sid}/ledger{i}'
        check(record['index'] == i, prefix + ' index')
        check(record['role'] in ROLES, prefix + ' known role')
        role_counts[ROLES[record['role']]] += 1
        before = tuple(record[k] for k in ('before_length', 'before_frontier', 'before_lag', 'before_next_id'))
        check(before == current, prefix + ' boundary chain')
        check(record['before_lag'] in (0, 1), prefix + ' lag')
        check(record['before_length'] - record['before_frontier'] == record['before_lag'], prefix + ' old frontier')
        gen, turn = record['generation'], record['turn']
        if not gen:
            check(turn == len(by_turn) + 1, prefix + ' increasing prompt turn')
            user, quota = spec[turn - 1]
            ids = ([current[3]] if turn > 1 else []) + user
            check(record['role'] == (7 if record['before_lag'] else 2), prefix + ' prompt/catchup role')
            check(record['quota'] == 0 and record['accepted'] == len(ids), prefix + ' prompt commit rows')
            check(record['draft'] == record['target_second'] == -1, prefix + ' prompt decision')
            by_turn.append({'turn': turn, 'requested_steps': quota, 'new_user_tokens': len(user),
                            'pending_flushed': int(turn > 1), 'output_begin': len(reconstructed),
                            'input_rows': len(ids), 'draft_rows': record['draft_rows'],
                            'first_input': ids[0], 'prior_pending': current[3] if turn > 1 else None,
                            'role': ROLES[record['role']], 'imported': record['imported']})
            emitted = [record['target_first']]
            if not record['imported']:
                prefill_calls += 1
                ptarget += len(ids)
                pdraft += record['draft_rows']
        else:
            check(turn == len(by_turn), prefix + ' generation in current turn')
            ids = [current[3]]
            remaining = spec[turn - 1][1] - (len(reconstructed) - by_turn[-1]['output_begin'])
            check(record['quota'] == remaining and remaining > 0, prefix + ' remaining output quota')
            check(reconstructed[-1] not in EOS, prefix + ' no generation after EOS')
            expected_role = (6 if record['before_lag'] else 5) if remaining == 1 else (4 if record['before_lag'] else 3)
            check(record['role'] == expected_role, prefix + ' lag/quota exact role')
            agreement = record['role'] in (3, 4) and record['draft'] == record['target_first']
            accepted = int(agreement and remaining >= 2 and record['target_first'] not in EOS)
            check(record['accepted'] == 1 + accepted, prefix + ' fresh acceptance/EOS policy')
            emitted = [record['target_first']] + ([record['target_second']] if accepted else [])
            if record['role'] in (5, 6):
                check(record['draft'] == record['target_second'] == -1, prefix + ' quota1 has no draft decision')
            agreements += int(agreement)
            accepted_drafts += accepted
            decoded += record['accepted']
            verified += target_rows(record)
            drafted += record['draft_rows']
            rounds.append(record)
        check(len(ids) == record['input_rows'] and ids[0] == record['first_input'] and fnv(ids) == record['input_hash'], prefix + ' actual input owner/hash/pending')
        check(record['draft_rows'] == (len(ids) + record['before_lag'] if not gen else 1 + record['before_lag']), prefix + ' exact draft shape')
        check(record['next_id'] == emitted[-1], prefix + ' next_id')
        check(record['after_length'] == record['before_length'] + record['accepted'], prefix + ' accepted length')
        check(record['after_frontier'] == record['before_frontier'] + record['draft_rows'], prefix + ' draft frontier')
        check(record['after_lag'] == record['after_length'] - record['after_frontier'], prefix + ' new lag')
        current = tuple(record[k] for k in ('after_length', 'after_frontier', 'after_lag', 'next_id'))
        reconstructed.extend(emitted)
        by_turn[-1]['output_end'] = len(reconstructed)
        if not record['imported']:
            new_calls += 1
        else:
            check(not gen and i == 0 and record['trace_name'] == '', prefix + ' only initial prompt imported')
    check(generated == reconstructed, f'{arm}/{sid} all emitted IDs from committed ledger')
    check((result['visible_tokens'], result['draft_frontier'], result['draft_lag']) == current[:3], f'{arm}/{sid} terminal boundary')
    check(result['generated_tokens'] == len(generated) and result['generated_decode_tokens'] == decoded, f'{arm}/{sid} output counters')
    check(result['requested_steps'] == sum(q for _, q in spec), f'{arm}/{sid} requested quota')
    check(result['committed_target_rows'] == current[0] and result['committed_target_decode_rows'] == decoded, f'{arm}/{sid} committed rows')
    check(result['logical_prompt_tokens'] == sum(len(ids) + int(i > 0) for i, (ids, _) in enumerate(spec)), f'{arm}/{sid} logical prompt includes pending once')
    check(len(by_turn) == len(spec) == len(result['turns']), f'{arm}/{sid} turn count')
    for turn, logged in zip(by_turn, result['turns']):
        for k in ('turn', 'requested_steps', 'new_user_tokens', 'pending_flushed', 'output_begin', 'output_end'):
            check(turn[k] == logged[k], f'{arm}/{sid} turn {k}')
        outputs = generated[turn['output_begin']:turn['output_end']]
        check(len(outputs) <= turn['requested_steps'] and (len(outputs) == turn['requested_steps'] or outputs[-1] in EOS), f'{arm}/{sid} quota/EOS termination')
        turn['actual_outputs'] = len(outputs)
        turn['ended_by_eos'] = outputs[-1] in EOS
        turn['prefill_seconds'], turn['decode_seconds'] = logged['prefill_seconds'], logged['decode_seconds']
    close(sum(t['prefill_seconds'] for t in result['turns']), result['prefill_seconds'], f'{arm}/{sid} sum turn P')
    close(sum(t['decode_seconds'] for t in result['turns']), result['decode_seconds'], f'{arm}/{sid} sum turn D')
    close(result['prefill_seconds'] + result['decode_seconds'] + result['between_turn_seconds'], result['session_seconds'], f'{arm}/{sid} P+D+between=session')
    check(result['between_turn_seconds'] >= 0, f'{arm}/{sid} nonnegative between-turn wall')
    for k, value in [('prefill_graph_calls', prefill_calls), ('decode_graph_calls', len(rounds)),
                     ('prefill_target_rows', ptarget), ('prefill_draft_rows', pdraft),
                     ('verified_target_rows', verified), ('draft_rows', drafted),
                     ('draft_rounds', sum(r['role'] in (3, 4) for r in rounds)),
                     ('agreements', agreements), ('accepted_drafts', accepted_drafts)]:
        check(result[k] == value, f'{arm}/{sid} {k}')
    for record, row in zip(rounds, result['rounds']):
        for key, source in [('pending', 'first_input'), ('draft', 'draft'), ('target_first', 'target_first'), ('target_second', 'target_second'),
                            ('committed_target_rows', 'accepted'), ('draft_rows', 'draft_rows')]:
            check(row[key] == record[source], f'{arm}/{sid} rounds/ledger {key}')
    check(len(rounds) == len(result['rounds']), f'{arm}/{sid} round count')

    sd = directory / 'trace' / f'session{next(i for i, e in enumerate(read(directory / "parsed.json")["sessions"]) if e["session_id"] == sid)}_{sid}'
    restores, rt, rd = [], 0, 0
    for folder in sorted((sd / 'restores').glob('restore*')):
        episodes = sorted((p for p in folder.iterdir() if p.is_dir()), key=lambda p: int(p.name[7:]))
        check([p.name for p in episodes] == [f'episode{i}' for i in range(len(episodes))], f'{arm}/{sid} contiguous restore graph traces')
        replayed = ledger[:len(episodes)]
        check(bool(replayed), f'{arm}/{sid} nonempty restore')
        tr, dr = sum(map(target_rows, replayed)), sum(r['draft_rows'] for r in replayed)
        rt += tr
        rd += dr
        restores.append({'directory': str(folder.relative_to(Z)).replace('\\', '/'), 'graph_calls': len(episodes),
                         'target_rows': tr, 'draft_rows': dr, 'roles': [ROLES[r['role']] for r in replayed],
                         'contains_imported_prompt': any(r['imported'] for r in replayed),
                         'last_boundary': {k: replayed[-1][k] for k in ('after_length', 'after_frontier', 'after_lag', 'next_id')}})
    restore_calls = sum(x['graph_calls'] for x in restores)
    check(entry['restore_count'] == len(restores), f'{arm}/{sid} actual restore count')
    check(result['actual_graph_calls'] == new_calls + restore_calls, f'{arm}/{sid} graph work includes restore')
    check(result['actual_target_rows'] == ptarget + verified + rt, f'{arm}/{sid} target work includes restore')
    check(result['actual_draft_rows'] == pdraft + drafted + rd, f'{arm}/{sid} draft work includes restore')
    if result['prefix_full_hits']:
        hit = read(sd / 'prefill' / 'cache-hit.json')
        check(hit == {'prefix_hit': True, 'graph_calls': 0, 'tensor_payload_available': False, 'reused_tokens': 15, 'next_id': 198}, f'{arm}/{sid} full-hit metadata')
        check(not any((sd / 'prefill').glob('*.bf16')) and not any((sd / 'prefill').glob('*.f32')), f'{arm}/{sid} no fake full-hit vectors')
    return {'session_id': sid, 'ledger_records': len(ledger), 'new_graph_calls': new_calls,
            'restored_graph_calls': restore_calls, 'restored_target_rows': rt, 'restored_draft_rows': rd,
            'actual_graph_calls': result['actual_graph_calls'], 'actual_target_rows': result['actual_target_rows'],
            'actual_draft_rows': result['actual_draft_rows'], 'generated_ids': generated,
            'final_boundary': dict(zip(('length', 'draft_frontier', 'lag', 'next_id'), current)),
            'role_counts': dict(role_counts), 'turns': by_turn, 'restores': restores,
            'timing_seconds': {k: result[k] for k in ('prefill_seconds', 'decode_seconds', 'between_turn_seconds', 'session_seconds')},
            'idle_evictions': entry['idle_evictions'], 'prefix_full_hits': result['prefix_full_hits']}


def main():
    ready = read(Z / 'qwen-ready-attempt2.json')
    freeze = read(Z / 'source-freeze.json')
    check(ready['source']['sha256'] == ready['main']['sha256'] == freeze['sources'][0]['sha256'], 'frozen main/compiled main identity')
    terminal(Z / 'compile2/qwen/compile.result.json')
    terminal(Z / 'qwen-link2/link.result.json')
    arms, parsed = {}, {}
    for name in NAMES:
        d = Z / 'cli-runs1' / name
        receipt, plan = terminal(d / 'run.result.json'), read(d / 'plan.json')
        stdout, stderr = raw(d / 'run.stdout.log'), raw(d / 'run.stderr.log')
        p = read(d / 'parsed.json')
        parsed[name] = p
        check(p == json.loads(stdout.splitlines()[-1]), name + ' parsed equals actual stdout')
        check(receipt['command'] == plan['command'], name + ' actual/planned command')
        check(plan['ready']['image'] == ready['image'] and plan['ready']['main'] == ready['main'], name + ' recorded image/source')
        check(p['diagnostic'], name + ' trace is diagnostic')
        check(stderr.count('resident text weights:') == 1, name + ' one weight load')
        arm = {'terminal_exit': 0, 'pid': receipt['pid'], 'diagnostic': True,
               'raw_directory': str(d.relative_to(ROOT)).replace('\\', '/'), 'single_model_load_count': 1}
        close(p['prefill_seconds'] + p['decode_seconds'], p['session_seconds'], name + ' global disjoint P+D=wall')
        if 'sessions' in p:
            specs = request_specs(receipt['command'])
            summaries = [review_session(name, d, e, specs[e['session_id']]) for e in p['sessions']]
            arm['sessions'] = summaries
            for key in ['requested_output_tokens', 'generated_tokens', 'generated_decode_tokens', 'actual_graph_calls',
                        'prefill_graph_calls', 'decode_graph_calls', 'logical_prompt_tokens', 'prefill_target_rows', 'prefill_draft_rows',
                        'verified_target_rows', 'draft_rows', 'actual_target_rows', 'actual_draft_rows', 'committed_target_rows',
                        'committed_target_decode_rows', 'draft_rounds', 'agreements', 'accepted_drafts']:
                skey = 'requested_steps' if key == 'requested_output_tokens' else key
                check(p[key] == sum(e['result'][skey] for e in p['sessions']), name + ' sum per-session ' + key)
            for key in ['restored_graph_calls', 'restored_target_rows', 'restored_draft_rows']:
                check(p[key] == sum(s[key] for s in summaries), name + ' actual ' + key)
            check(p['restore_count'] == sum(e['restore_count'] for e in p['sessions']), name + ' sum restore count')
            check(p['idle_evictions'] == sum(e['idle_evictions'] for e in p['sessions']), name + ' idle eviction sum')
            check(p['logical_user_prompt_tokens'] == sum(len(ids) for spec in specs.values() for ids, _ in spec), name + ' actual fixture user rows')
            check(p['pending_flushed_tokens'] == sum(len(spec) - 1 for spec in specs.values()), name + ' pending exactly once per new turn')
            check(p['peak_committed_versions'] <= p['max_sessions'] and p['peak_resident_requests'] <= p['max_sessions'] and p['live_committed_versions'] == 0, name + ' bounded/final retired')
            expected_dispatch = Counter((e['session_id'], r['turn']) for e in p['sessions'] for r in e['ledger'])
            check(Counter((e['session_id'], e['turn']) for e in p['dispatch']) == expected_dispatch, name + ' dispatch logical ledger count')
            check(p['logical_dispatches'] == len(p['dispatch']), name + ' logical dispatch count')
            logs = re.findall(r'^episode(\d+) tokens=(\d+) visible=(\d+).*?step_seconds=([\d.e+-]+).*?next=(-?\d+)\r?$', stderr, re.M)
            expected = Counter((r['index'], target_rows(r), r['after_length'], r['next_id'])
                               for e, summary in zip(p['sessions'], summaries) for restore in summary['restores']
                               for r in e['ledger'][:restore['graph_calls']])
            check(Counter((int(i), int(t), int(v), int(n)) for i, t, v, _, n in logs) == expected, name + ' real restore stderr matches original roles/accepted boundaries')
            close(sum(float(row[3]) for row in logs), p['restore_step_seconds'], name + ' raw restore step sum', 1e-7)
            arm['top_work'] = {k: p[k] for k in ['session_count', 'turn_count', 'max_sessions', 'shared_backing_bytes',
                'requested_output_tokens', 'generated_tokens', 'generated_decode_tokens', 'logical_dispatches',
                'logical_user_prompt_tokens', 'logical_prompt_tokens', 'pending_flushed_tokens', 'actual_graph_calls',
                'prefill_graph_calls', 'decode_graph_calls', 'prefill_target_rows', 'prefill_draft_rows',
                'verified_target_rows', 'draft_rows', 'actual_target_rows', 'actual_draft_rows', 'committed_target_rows',
                'restore_count', 'restored_graph_calls', 'restored_target_rows', 'restored_draft_rows', 'idle_evictions',
                'prefix_hits', 'prefix_full_hits', 'reused_tokens', 'peak_resident_requests', 'peak_committed_versions', 'live_committed_versions']}
        else:
            check(p['generated_tokens'] == len(p['generated_ids']), name + ' flat output count')
            if name == 'single':
                check(p['generated_ids'] == parsed['shorthand']['sessions'][0]['result']['generated_ids'], 'single/shorthand output regression')
                for key in ('actual_graph_calls', 'actual_target_rows', 'actual_draft_rows', 'visible_tokens', 'draft_frontier', 'draft_lag'):
                    check(p[key] == parsed['shorthand']['sessions'][0]['result'][key], 'single/shorthand ' + key)
            else:
                check(not p['mtp'] and p['generated_ids'] == [20, 248046] and p['actual_graph_calls'] == 2 and p['visible_tokens'] == 24, 'ordinary natural EOS smoke')
            arm['top_work'] = {k: p[k] for k in ('generated_ids', 'generated_tokens', 'actual_graph_calls', 'actual_target_rows', 'actual_draft_rows', 'visible_tokens')}
        arm['timing_seconds'] = {k: p[k] for k in ('prefill_seconds', 'decode_seconds', 'session_seconds', 'startup_to_ready_seconds', 'startup_to_endpoint_seconds')}
        arms[name] = arm
    for name in ('resume-n1', 'prefix-n2'):
        for a, b in zip(parsed['resident-n3']['sessions'], parsed[name]['sessions']):
            check(a['session_id'] == b['session_id'] and a['result']['generated_ids'] == b['result']['generated_ids'], name + ' resident emitted IDs')
            for k in ('visible_tokens', 'draft_frontier', 'draft_lag', 'generated_tokens'):
                check(a['result'][k] == b['result'][k], name + ' resident final ' + k)
            for i, (left, right) in enumerate(zip(a['ledger'], b['ledger'])):
                check({k: v for k, v in left.items() if k not in ('imported', 'trace_name')} ==
                      {k: v for k, v in right.items() if k not in ('imported', 'trace_name')}, name + f' resident committed ledger {a["session_id"]}/{i}')
    errors = {}
    for d in sorted((Z / 'errors1').iterdir()):
        if not d.is_dir():
            continue
        terminal(d / 'run.result.json', 1)
        stderr, stdout = raw(d / 'run.stderr.log'), raw(d / 'run.stdout.log')
        check('resident text weights:' not in stderr and not stdout.strip(), d.name + ' no model-load/output marker')
        check(not (Z / 'fixtures/no-weights/weights.tsv').exists(), d.name + ' inputs deliberately lack weight inventory')
        errors[d.name] = {'exit': 1, 'model_load_marker': False, 'stderr': stderr.strip()}
    check(len(errors) == 8, 'eight pre-load rejects')
    probe_receipt = terminal(Z / 'probe-run1/run.result.json')
    probe_ready = read(Z / 'mtp_session-ready-attempt2.json')
    probe = json.loads(raw(Z / 'probe-run1/run.stdout.log').splitlines()[-1])
    check(probe_receipt['command'][0] == probe_ready['image']['path'] and probe_ready['main'] == ready['main'], 'resume probe compiled identity')
    check(probe['status'] == 'MTP_RESUME_PROBE_COMPLETED' and probe['actual_graph_calls'] == 12 and probe['positive_graph_calls'] == 11 and probe['all_vectors_byte_equal'], 'resume probe actual summary')
    report = {
        'status': 'PASS: host-only accounting/invariant review of completed processes',
        'scope': 'Seven CLI processes plus resume-probe terminal/summary and eight pre-load rejections; no tensor payload reads, model execution, build, or independent quality claim.',
        'source': ready['main'], 'recorded_image': ready['image'], 'ready': '.scratch/qwen-mtp-resume-20261022/qwen-ready-attempt2.json',
        'arms': arms, 'early_rejections': errors, 'resume_probe': {'receipt_exit': 0, 'recorded_source': probe_ready['source'], 'recorded_image': probe_ready['image'], 'reported_observation': probe},
        'conclusions': [
            'N3: 19 new Graph episodes. N1: same 19 plus 10 real replay episodes (66 target/63 draft rows). N2 prefix: 18 new episodes plus the same 10 replay episodes.',
            'B initial prompt is an imported lag0 complete checkpoint (15 reused rows, zero Graph, no hidden/logits payload). Its actual later restore replays three original-role episodes including the imported prompt.',
            'All three main manifests emit the same 26 IDs over six turns. The 86 new user rows plus three previously emitted pending tokens give 89 logical prompt rows; replay adds actual work, not new outputs.',
            'A warm second turn actually processes target T25 and draft T26 from lag1. B/C second turns process T2/T2 and T9/T9. Each pending input hash reconstructs from the previous stored next_id and new user IDs.',
            'C reaches EOS after two outputs in its first quota16 turn and still executes the second prompt/generate turn. EOS does not retire the whole multi-turn request.',
            'Global prefill/decode buckets are disjoint continuous episode intervals and sum once to global token-visible wall. Per-request P+D excludes inter-turn idle; explicit between_turn_seconds restores its request-latency identity.',
        ],
        'limitations': [
            'Trace-enabled timings are diagnostic, not throughput comparisons. Arithmetic checks do not independently reconstruct monotonic host endpoints.',
            'No hidden/logits/KV/RNN/carry payload comparison was repeated here; root separately owns full raw payload comparison and finite checks.',
            'Graph work and boundary checks use real stdout ledger, native-completed receipts, restore trace-directory episode presence and stderr token-visible summaries; no claim of all rollback scenarios or model quality.',
            'Recorded image/source hashes are bound to ready/plan/compile receipts; large images, input weights, and old full link closures were not rehashed.',
            'shared_backing_bytes is the consumer reserved state-backing budget, not measured physical GPU peak; IO/workspace and runtime allocation are separate.'
        ],
        'check_count': CHECKS, 'small_evidence_read': READ,
    }
    out = Z / 'review/cli-work-analysis.json'
    out.write_text(json.dumps(report, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')
    print(json.dumps({'report': str(out), 'checks': CHECKS, 'bytes': out.stat().st_size,
                      'sha256': hashlib.sha256(out.read_bytes()).hexdigest()}, ensure_ascii=False))


if __name__ == '__main__':
    main()
