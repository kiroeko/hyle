"""Freeze a narrow read-only source-review phase; never executes model code."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
HERE = Path(__file__).resolve().parent
SOURCES = ["tools/qwen35_text/main.cc", "tools/qwen35_text/mtp_schedule.h",
           "tools/qwen35_text/session_schedule.h", "tools/qwen35_text/mtp_graph.h"]


def identity(path: Path) -> dict:
    data = path.read_bytes()
    return {"path": path.relative_to(ROOT).as_posix(), "bytes": len(data),
            "sha256": hashlib.sha256(data).hexdigest()}


def main() -> None:
    frozen = HERE / "source-phase1"
    for name in SOURCES:
        target = frozen / name
        if not target.exists():
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes((ROOT / name).read_bytes())
    main_file = frozen / SOURCES[0]
    text = main_file.read_text(encoding="utf-8")
    lines = text.splitlines()

    def anchor(needle: str) -> dict:
        return {"path": main_file.relative_to(ROOT).as_posix(),
                "line": next(i for i, line in enumerate(lines, 1) if needle in line),
                "text": needle}

    value = {
        "status": "phase1 source review: no blocking finding in the landed scoped pieces; no build or GPU work",
        "phase": "Parser extraction plus typed replay ledger/commit witness/restore. Main CLI integration is still under its owner's implementation and is not assessed as complete or defective here.",
        "sources": [identity(frozen / name) for name in SOURCES],
        "scope": ["read_mtp_schedule/read_mtp_session_schedules",
                  "shared read_session_manifest extraction",
                  "MtpBoundary/MtpReplayRecord/MtpReplayLedger and EvaluationOutput witness pointers",
                  "finish_selected_evaluations/finish_mtp_round witness and expected replay gate",
                  "prepare_mtp_replay_record/restore_mtp_session and original retirement failure path",
                  "warm helper's shared draft-row identity and original typed append ordering"],
        "findings": [],
        "reviewed_facts": [
            {
                "area": "parser",
                "fact": "The natural grammar is prompt IDSFILE / generate COUNT, with count1..128 and one-prompt --steps shorthand. Fixed decode IDSFILE is explicitly rejected rather than reinterpreted. Relative/quoted paths, full token vocabulary validation and nonempty prompts remain pre-model host work.",
                "limits": "The old fixed-input schedule parser is not changed. A single no-generate prompt can use default_steps; mixing explicit quotas and explicit --steps is rejected."
            },
            {
                "area": "context arithmetic",
                "fact": "The parser uses subtraction before every accumulated capacity increment. For later turns it counts the prior emitted pending exactly once, all new user IDs and quota-1 further committed generated inputs. This is the same worst-case committed length sum(prompt sizes)+sum(quotas)-1; EOS may stop earlier.",
                "limits": "Transient verification shape still obeys Model's remaining-context/T1 fallback. New CLI cold schema must separately include lag1 draft query T+1; this phase does not sign that not-yet-integrated computation."
            },
            {
                "area": "manifest extraction",
                "fact": "Common identity/path extraction preserves ASCII safe IDs, duplicate rejection, explicit finite entry-count bound, quoted paths relative to the session manifest and error line/session context. Each selected parser owns its own schedule grammar."
            },
            {
                "area": "witness storage",
                "fact": "Ledger constructs its record vector to final capacity. next() checks count and uncommitted status before returning a stable slot. Records contain only host input ownership/spans and fixed scalar/array state/decision fields, not Snapshot or lease history.",
                "anchor": anchor("struct MtpReplayLedger final")
            },
            {
                "area": "actual commit point",
                "fact": "Fresh selector/after-state facts are prepared before publication; expected replay comparison occurs before any head swap. The original all-bank take/ready, tail validation, state unbind and expected-base checks remain fallible before publication. Only after all heads swap does the code set committed and increment the reserved count, before detach and later trace/report I/O. This fixes the previous missing-witness seam for a postcommit trace exception.",
                "anchors": [anchor("MTP replay natural decision or state boundary diverged"),
                            anchor("commit_record->committed = true;"),
                            anchor("detach_episode(); // Old states/transactions retire inside the host endpoint."),
                            anchor("if (output.trace && !output.trace->empty())")]
            },
            {
                "area": "generation policy",
                "fact": "Teacher-forced Single/CatchupSingle inputs can maintain prompt math, but finish_mtp_round still observes only the original terminal result and rejects first_input != base.next_id before owned-state export or publication. The natural GPU draft and target decisions fill the fixed record; the old proposed token is never forced by restore.",
                "anchor": anchor("MTP generation input differs from its original pending token")
            },
            {
                "area": "restore",
                "fact": "A zero-origin, fully committed ledger and idle original carrier are required. The old request must be actually retired/nonresident before a new working Session is created. Reconstruction uses the recorded original role and host prompt chunk, or the rebuilt head's actual pending for generation; a separate reserved actual ledger is compared with each immutable expected record before publication. This preserves T2 verification and accepted boundaries instead of replaying a T1 token tape.",
                "anchor": anchor("std::shared_ptr<Session> restore_mtp_session")
            },
            {
                "area": "retained owners / failure",
                "fact": "Restore holds one working Session and a host-only actual ledger. It does not keep a SnapshotRef oracle per replay step. Directory aliases remain subject to the real VersionCount / selected-base D gate. A replay/prepare/trace exception stops and drains the temporary Session through the original methods before unwinding; no byte credit or page permission is inferred from removing a directory entry.",
                "limits": "The scalar decision comparison is a checked reconstruction protocol, not a claim that all reconstructed state bytes match. A replay already committed before a trace error is discarded as a temporary failed restore; the immutable expected ledger is not rewritten."
            },
            {
                "area": "warm math",
                "fact": "Lag1 prompt maintenance uses the original post-final-RMS target hidden shift [prior,carry,new[:-1]], tokens [catchup_token,actual_target_ids], shared actual draft_rows Dimension and real positions D..D+T. The caller has an explicit last-target-V -> draft-K effect edge; helper creates no executor/permission/publication.",
                "limits": "The first helper's independent derived T+1 symbol defect was corrected and preserved under warm-helper/revisions; current helper has the shared identity fix."
            }
        ],
        "integration_conditions_not_findings": [
            "Any temporary [pending]+new-user token vector retained as a prompt_ids span must have a stable immutable host owner for the whole ledger lifetime (or point into a proven outliving immutable owner). A span into a local concatenation vector is insufficient.",
            "The new driver must consume newly committed witness records into generated IDs / rounds / work counts even if later trace/reporting throws; these counters cannot depend exclusively on finish returning normally. Do not re-execute an already committed record.",
            "Cold uses/shapes must be planned before carrier preparation, including lag1 prompt draft T+1 and the original generation T2/catchup roles; this review does not treat the still-unfinished driver as passed.",
            "Restore is permitted only after the old resident head actually retires/drops. Atomic old+working+candidate restoration can exceed the existing N+1 version plan. Ledger fields cannot bypass actual native retirement or writer permissions."
        ],
        "evidence_limit": "Read-only static review only. No C++ template/build verification, parser execution, Torch/model computation, GPU experiment, natural acceptance-rate or quality claim. No new verification framework or product edits.",
    }
    out = HERE / "source-review.json"
    out.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    freeze = {"phase": "source-phase1", "report": identity(out),
              "script": identity(Path(__file__)), "sources": value["sources"],
              "builds": 0, "gpu_runs": 0}
    fp = HERE / "source-review-freeze.json"
    fp.write_text(json.dumps(freeze, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"report": identity(out), "freeze": identity(fp)}))


if __name__ == "__main__":
    main()
