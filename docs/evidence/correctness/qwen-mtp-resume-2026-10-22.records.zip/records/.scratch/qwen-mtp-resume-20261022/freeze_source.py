from pathlib import Path
import difflib, hashlib, json

stage = Path(__file__).resolve().parent
root = stage.parents[1]
relative = [Path('tools/qwen35_text') / name for name in
            ('main.cc', 'session_schedule.h', 'mtp_schedule.h', 'schedule.h', 'mtp_graph.h')]
def identity(path):
    return {'path': str(path.relative_to(root)).replace('\\', '/'), 'bytes': path.stat().st_size,
            'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}
before_main = (stage / 'before' / relative[0]).read_text()
main = (root / relative[0]).read_text()
ordinary = '    // These owners are declared after Model, including on exception paths.'
assert before_main[before_main.index(ordinary):] == main[main.index(ordinary):]
single, multi = 'int run_mtp(Model &model,', 'int run_mtp_sessions(Model &model,'
assert before_main[before_main.index(single):before_main.index(multi)] == main[main.index(single):main.index(multi)]
sources, diffs = [], []
for rel in relative:
    current = root / rel
    snapshot = stage / 'source' / rel
    snapshot.parent.mkdir(parents=True, exist_ok=True); snapshot.write_bytes(current.read_bytes())
    old = stage / 'before' / rel
    diff = stage / 'diff' / (rel.name + '.diff'); diff.parent.mkdir(parents=True, exist_ok=True)
    diff.write_text(''.join(difflib.unified_diff(old.read_text().splitlines(True) if old.exists() else [],
        current.read_text().splitlines(True), fromfile=('before/' + rel.as_posix()) if old.exists() else '/dev/null',
        tofile=rel.as_posix())), encoding='utf-8', newline='\n')
    sources.append(identity(current)); diffs.append(identity(diff))
report = {
 'status': 'frozen implementation; root owns the actual incremental CXX/link and model/probe runs',
 'base_main': identity(stage / 'before' / relative[0]), 'sources': sources,
 'owners': {'main.cc/session_schedule.h/new_mtp_schedule.h': 'quant_gap agent',
            'schedule.h/shared_read_schedule_ids_and_natural_parser_call': 'root',
            'mtp_graph.h/prefill_kv': 'vulkan agent'},
 'implemented': [
  'Natural prompt FILE / generate K pairs selected only by --mtp on; original one-prompt --steps shorthand kept, explicit quotas reject explicit --steps, fixed decode tape meaning unchanged.',
  'Same original Model/Session/Phase/14-bank transaction; one CatchupPrefill role and a shared is_mtp_prefill predicate, no public/provider/native API changes.',
  'Warm target IDs are previous emitted pending plus new user IDs, once; draft lag1 uses prior/carry/new normalized hidden and T+1 positions, then publishes lag0 with the complete target/draft head.',
  'Schema max query is cold max(targetT,draftT+lag), including actual A-long target25/draft26; T1 continues through existing Single/CatchupSingle with post-wait generation pending check.',
  'Typed preallocated MtpReplayLedger records actual role/input owner/shape/quota/natural proposal+target decisions/accepted boundary/frontiers/lag/next/EOS. Same-shape restore recomputes native proposals and rejects mismatches in the original prepublication selector.',
  'Commit record bounds checked before publication; original full head swaps install POD witness and committed_count before any trace/report. No callback or postcommit ledger allocation.',
  'Observer generated/round arrays are reserved to sum of all turn quotas; each round owns a cold capacity2 emission buffer. Pool move, capacity-bounded writes and ledger_observed update consume committed facts without allocating.',
  'Trace exception catch consumes committed witness and preserves original exception; no rollback or duplicate pending for already published heads.',
  'N resident slots protect generating requests; only turn-idle Session heads may be selected by LRU for actual stop/try_retire/drop. Later turn restores the host-only immutable ledger before admission; no old head retained beside working+candidate.',
  'Initial lag0 PrefixCache whole/partial support retained. Imported actual source chunks seed the generated-state ledger; warm/generated states do not enter the old role-less directory.',
  'Global P/D remain disjoint continuous intervals ending at original host-token endpoints. Restore cost remains in triggering P wall and actual Graph work, with separate restored Graph/target/draft/step/full-time counters; no new output numerator.',
  'Per-session multi-turn P/D are sum of per-turn latency including interleaving; between-turn queued time is explicit and total session latency is not used as global pooled throughput.'
 ],
 'API': {
  'ledger': 'MtpReplayLedger(size_t capacity), records pre-resized, committed_count',
  'prepare_record': 'prepare_mtp_replay_record(ledger,const Session&,GraphRole,span<const int32_t>,bool generation,size_t quota,size_t turn,shared_ptr<const void> owner={}) -> MtpReplayRecord&',
  'finish': 'EvaluationOutput optional mtp_ledger and mtp_expected pointers; finish_evaluation has matching optional final arguments',
  'restore': 'restore_mtp_session(Model&,const MtpReplayLedger&,path trace={},bool trace_states=true,MtpRestoreStats*=nullptr,PrefixCache*=nullptr,span<const MtpGenerationRequest>={}) -> shared_ptr<Session>',
  'precondition': 'idle serial carrier and real committed capacity for a nonresident request; no retained old resident head hidden from N',
  'expected': 'record committed flag and all natural decision/boundary fields verified before temporary publication; do not force recorded draft or acceptance'
 },
 'static_checks': {'git_diff_check': 'passed', 'legacy_single_run_mtp_function_byte_equal': True,
                   'ordinary_execution_driver_body_byte_equal': True,
                   'shared_dimension': 'main creates T+lag once; helper and draft positions consume that exact Dimension identity'},
 'instrumentation': 'stdout per-session ledger has index/turn/role/input rows/hash/first input/quota/before-after/natural decisions and trace name; restoreN/episodeI maps each recomputation to that immutable index',
 'metadata_fix': 'read_session_manifest compares actual parsed count against both logical max_sessions and its own entries.max_size, instead of rejecting a logical vector max_size belonging to a different metadata element type',
 'limits': ['Process-local same-Model/math restoration, not a serialized cross-model checkpoint format.',
            'Matching replay decisions/frontiers is protocol validation; complete KV/state bit equality requires actual finite probe/CLI checks.',
            'Replay policy mismatch is a host consumer error; it is not relabeled as a native device fault.',
            'Only R1 MTP; no batch/server executor or lag1 arbitrary prefix lookup.',
            'No model quality, speed improvement or physical GPU peak claim from these source changes.'],
 'activity_by_this_agent': {'CXX_builds': 0, 'GPU_runs': 0}
}
review = stage / 'review' / 'implementation-review.json'
review.write_text(json.dumps(report, indent=2)+'\n', encoding='utf-8')
freeze = stage / 'source-freeze.json'
freeze.write_text(json.dumps({'status': 'source frozen for root build/runtime', 'sources': sources,
    'diffs': diffs, 'review': identity(review), 'activity_by_this_agent': {'CXX_builds': 0, 'GPU_runs': 0}}, indent=2)+'\n', encoding='utf-8')
print(json.dumps({'freeze': identity(freeze), 'sources': sources}, indent=2))
