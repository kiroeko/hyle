from pathlib import Path
import hashlib,json,zipfile
R=Path(__file__).resolve().parents[2];W=Path(__file__).resolve().parent
def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def pin(p):
    p=Path(p);return dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def save(p,x):
    with Path(p).open('x',encoding='utf-8') as f:json.dump(x,f,ensure_ascii=False,indent=2);f.write('\n')
sources=['engine/models/qwen35/main.cc','tests/tools/qwen_packed_prefill_case.h',
    'tests/tools/qwen_ragged_prefill_case.h','tests/tools/qwen_host_image_test.cc']
for p in sources:
    out=W/'source'/p;out.parent.mkdir(parents=True,exist_ok=True)
    with out.open('xb') as f:f.write((R/p).read_bytes())
summary={}
for backend in ('cpu','cuda'):
    path=W/('tiny-'+backend+'-run/report.json');a=read(path)
    assert a['status']=='PASS' and a['numerically_equivalent'] and a['old_checkpoints_byte_unchanged']
    assert (a['actual_prefill_rows'],a['physical_prefill_rows'],a['committed_prefill_rows'])==(22,64,21)
    assert a['batches'][0]['state_only'] and a['batches'][-1]['member_cancelled'] and a['batches'][-1]['retirement_deferred']
    diffs=[d for b in a['batches'] for m in b['members'] for d in m['differences']]+a['peer_decode']['differences']
    assert all(d['role']==3 and d['nonfinite_differences']==0 for d in diffs)
    summary[backend]=dict(status=a['status'],report=pin(path),
        orders=[b['order'] for b in a['batches']],lengths=[b['Li'] for b in a['batches']],
        actual_rows=22,physical_rows=64,committed_rows=21,cancelled_rows=1,peer_decode_rows=1,
        payloads_byte_equal=a['payloads_byte_equal'],maximum_absolute_gdn_error=max([d['maximum_absolute'] for d in diffs],default=0),
        old_checkpoints_byte_unchanged=True,rng_and_epochs_equal=True,retirement_deferred=True,
        final_versions=0,final_images=0,final_native_episodes=0)
cli=read(W/'cli-natural-run/report.json');first=cli['batches'][0]
assert first['input_rows']==[154,37] and (first['active_rows'],first['physical_rows'])==(191,308)
assert cli['packed_prefill_calls']==1 and cli['cold_exact_admissions']==0
assert len(cli['batches'])==4 and all(b['input_rows']==[1,1] for b in cli['batches'][1:])
r1=read(W/'tiny-r1-cuda-run/report.json');assert r1['status']=='PASS' and len(r1['steps'])==8
processes=[dict(relative=str(p.relative_to(W)),**read(p)) for p in sorted(W.rglob('process.json'))]
assert all(p['exit']==0 and not p['timed_out'] for p in processes)
target=R/'docs/evidence/correctness/inference-ragged-prefill-2026-10-28.json'
data=dict(date='2026-10-28',base_commit='11fa9c102',status='Finite CPU/CUDA checks passed',
    scope='Ordinary nonempty ragged prefill with common completion/sampler; original exact MTP/decode/relay contracts retained.',
    sources=[pin(R/p) for p in sources],
    implementation=['Per-member Li and compact row start, actual A=sum(Li), physical R=B*C remain separate throughout original prepare/layout/append/state/commit/ledger/observer.',
      'Same public prepared query-offset lease and original Store/Append transactions; no new executor, queue or permission ledger.',
      'Natural grouping selects an admitted shared capacity for unequal Li; exact decode/MTP/relay retain their original gates.',
      'B2 raw histories use checked Gather from original activation bytes; last IDs use each true query endpoint.'],
    tiny=summary,r1_regression=dict(backend='cuda',report=pin(W/'tiny-r1-cuda-run/report.json'),status='PASS'),
    real_cli=dict(image=read(W/'ready-model.json')['image'],report=pin(W/'cli-natural-run/report.json'),
        initial_batch=first,subsequent_batches=cli['batches'][1:],cold_exact_admissions=0,
        generated_ids={x['session_id']:x['result']['generated_ids'] for x in cli['sessions']},
        logical_prefill_rows=191,physical_prefill_rows=308,performance_claim=False),
    numerical_contract='Only newly recomputed finite F32 GDN payloads use existing FP64 component absolute budget3e-6; other state/history/KV/hidden, old snapshots, boundaries and RNG remain strict. No full-model FP64 or quality claim.',
    static_quantization_review=dict(actual_runtime_checks=False,
        findings=['FlashInfer and ggml attention clear authorized inactive output suffix after native success.',
         'Reviewed norm, CT channel/token/block128, static FP8, NVFP4 and GroupedFloat4 scaling is row-local or uses stored scales.',
         'ggml Q4 adapter adds no cross-row scaling; cached upstream kernels were read, not exhaustively retraced against every binary branch.'],
        limits='Bad padding can still set a shared numeric failure in quantization; row-local math alone does not establish harmless padding. This review does not prove every dtype/provider combination.'),
    processes=processes,cost=dict(CXX=2,links=2,consumer_processes=4,SDK_builds=0,NVCC=0,downloads=0),
    remaining=['MTP effective-length prefill including true shift/lag and independent draft offsets',
      'Apple/Vulkan compilation and native checks','Full quantized/provider feature combinations and current speed/memory A/B'],
    performance='No refreshed performance comparison. R/A work and original process times remain in raw reports; fewer graph calls are not a speed claim.')
save(target,data)
files={'evidence.json':target}
for p in W.rglob('*'):
    if p.is_file() and p.suffix.lower() in {'.json','.log','.py','.h','.cc','.txt','.turns','.ids'} and '__pycache__' not in p.parts:
        files['scratch/'+str(p.relative_to(W)).replace('\\','/')]=p
manifest=[dict(name=k,**pin(v)) for k,v in sorted(files.items())]
archive=target.with_suffix('.zip')
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for k,v in sorted(files.items()):z.write(v,k)
    z.writestr('manifest.json',json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for row in manifest:assert hashlib.sha256(z.read(row['name'])).hexdigest()==row['sha256']
save(W/'packaged.json',dict(evidence=pin(target),archive=pin(archive),members=len(manifest)+1))
print(json.dumps(read(W/'packaged.json'),indent=2))
