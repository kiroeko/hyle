"""Offline shape/offset checks of the retained metadata; no tensor payload I/O."""
from pathlib import Path
import collections
import hashlib
import json
import math

STAGE = Path(__file__).resolve().parent


def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def identity(path):
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())


def save(path, value):
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False)+'\n', encoding='utf-8')


def main():
    inventory = read(STAGE/'tensor-header-inventory.json')
    api, index = read(STAGE/'api-model.json'), read(STAGE/'model.safetensors.index.json')
    assert inventory['complete'] and api['sha'] == '6e134bae811fb5adac50ee042ae5f029ac6779aa'
    all_rows = {row['name']:row for shard in inventory['shards'] for row in shard['tensors']}
    assert set(all_rows) == set(index['weight_map']) and len(all_rows) == 2396
    sizes = {'I32':4, 'I64':8, 'BF16':2, 'F32':4}
    files = []
    for shard in inventory['shards']:
        published = next(row for row in api['siblings'] if row['rfilename'] == shard['file'])
        intervals = sorted(row['data_offsets'] for row in shard['tensors'])
        assert intervals[0][0] == 0 and all(a[1] == b[0] for a,b in zip(intervals,intervals[1:]))
        assert intervals[-1][1]+8+shard['header_bytes'] == published['size']
        for row in shard['tensors']:
            assert row['bytes'] == math.prod(row['shape'])*sizes[row['dtype']]
        files.append(dict(file=shard['file'], header=shard['header'], header_bytes=shard['header_bytes'],
            tensor_count=len(shard['tensors']), published_file_bytes=published['size'],
            published_file_SHA256_not_computed_from_payload=published['lfs']['sha256']))
    prefixes = sorted(name[:-len('.weight_packed')] for name in all_rows if name.endswith('.weight_packed'))
    assert len(prefixes) == 399
    roles = []
    for name in prefixes:
        fields = {field:all_rows[name+'.'+field] for field in ('weight_packed','weight_scale','weight_zero_point','weight_shape')}
        packed, scale, zero, shape = (fields[k] for k in fields)
        n, words = packed['shape']
        groups = scale['shape'][1]
        k = groups*32
        assert packed['dtype'] == zero['dtype'] == 'I32' and scale['dtype'] == 'BF16'
        assert packed['shape'] == [n,k//8] and scale['shape'] == [n,groups]
        assert zero['shape'] == [(n+7)//8,groups]
        assert shape['dtype'] == 'I64' and shape['shape'] == [2] and shape['bytes'] == 16
        roles.append(dict(role=name, logical_NK_derived_from_header=[n,k],
            original_weight_shape_tensor_values_read=False, group_size=32, fields=fields))
    assert not any(name.endswith('.weight_g_idx') for name in all_rows)
    assert not any(name.endswith('.input_global_scale') for name in all_rows)
    save(STAGE/'quantized-roles.json', dict(repository=api['id'], revision=api['sha'], count=399,
        metadata_only=True, tensor_payload_bytes_read=0, roles=roles))
    save(STAGE/'header-facts.json', dict(revision=api['sha'], complete_index_and_headers=True,
        tensor_count=len(all_rows), quantized_roles=399, files=files,
        role_counts=dict(collections.Counter(row['role'].rsplit('.',1)[-1] for row in roles)),
        physical_signatures=[dict(N=n,K=k,roles=count) for (n,k),count in sorted(collections.Counter(
            tuple(row['logical_NK_derived_from_header']) for row in roles).items())],
        g_idx_tensors=0, input_global_scale_tensors=0, dtype_counts=dict(collections.Counter(row['dtype'] for row in all_rows.values())),
        complete_header_prefix_bytes=311120, first_client_parser_correction_prefix_bytes=40,
        tensor_payload_bytes_read=0, weight_shape_values_read=False,
        role_inventory=identity(STAGE/'quantized-roles.json')))
    print(json.dumps(identity(STAGE/'header-facts.json')))


if __name__ == '__main__':
    main()
