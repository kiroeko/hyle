"""Offline report/snapshot only. Does not read tensor payload or run a backend."""
import hashlib
import json
import shutil
import struct
from pathlib import Path

STAGE = Path(__file__).resolve().parent
ROOT = STAGE.parent.parent
REV = "6e134bae811fb5adac50ee042ae5f029ac6779aa"
CT = "ac8e2ba82f4e0d5eaa40069f8fc642738f124cd4"
REPO = "cyankiwi/Qwen3.8-27B-AWQ-INT4"


def identity(path):
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())


def save(name, value):
    (STAGE / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def bf16_rne(value):
    bits = struct.unpack("<I", struct.pack("<f", value))[0]
    rounded = (bits + 0x7fff + ((bits >> 16) & 1)) >> 16
    return rounded, struct.unpack("<f", struct.pack("<I", rounded << 16))[0]


facts = json.loads((STAGE / "header-facts.json").read_text(encoding="utf-8"))
assert facts["quantized_roles"] == 399 and facts["tensor_count"] == 2396
assert facts["complete_index_and_headers"] and facts["tensor_payload_bytes_read"] == 0
artifact = json.loads((ROOT / "docs/implementation/model-quantizations.json").read_text(encoding="utf-8"))["artifacts"][9]
assert artifact["repository"] == REPO and artifact["revision"] == REV
save("catalog-artifact9-snapshot.json", {"meaning": "Catalog row as read; its older static coverage text is not updated by this investigation.", "artifact": artifact})
prior = ROOT / ".scratch/model-quantization-discovery-2026-10-19/qwen-kimi"
prior_records = json.loads((prior / "retrieval.json").read_text(encoding="utf-8"))


def records(value):
    if isinstance(value, dict):
        if value.get("repo") == REPO and value.get("file") == "config.json":
            yield value
        for item in value.values():
            yield from records(item)
    elif isinstance(value, list):
        for item in value:
            yield from records(item)


config_record, = list(records(prior_records))
config_source = prior / "cyankiwi--Qwen3.8-27B-AWQ-INT4/config.json"
assert config_record["revision"] == REV
assert identity(config_source)["sha256"] == config_record["sha256"]
assert identity(config_source)["bytes"] == config_record["bytes"]
shutil.copyfile(config_source, STAGE / "config.json")
save("config-original-retrieval.json", {"existing_receipt_source": str(prior / "retrieval.json"), "record": config_record, "retained_config": identity(STAGE / "config.json")})
config = json.loads((STAGE / "config.json").read_text(encoding="utf-8"))
group = config["quantization_config"]["config_groups"]["group_0"]
assert group["weights"]["num_bits"] == 4 and group["weights"]["group_size"] == 32
assert group["weights"]["symmetric"] is False and group["weights"]["actorder"] is None

source_paths = [
    "include/hyle/compute/model_ops.h", "src/compute_ops/weight_decode.cc",
    "src/compute_provider_native/torch_cpu_program.cc",
    "src/compute_provider_torch_cuda/artifact_provider.cc",
    "src/compute_route_apple/apple_mature_artifact.cc",
    "src/compute_route_vulkan/vulkan_iree.cc",
    "src/compute_provider_iree_vulkan/native_program.h",
    "src/compute_provider_iree_vulkan/native_program.cc",
    "third_party/compressed_tensors_cpu/compressed_tensors_cpu.h",
    "third_party/compressed_tensors_cuda/compressed_tensors_cuda.h",
    "third_party/compressed_tensors_apple/compressed_tensors_apple.h",
    "third_party/iree_vulkan_runtime/programs/generate_artifacts.py",
    "tests/compute_ops/operation_test.cc",
    "tests/compute_route_cpu/cpu_artifact_decode_test.cc",
    "tests/graph_route_cuda/artifact_test.cc",
    "tests/compute_route_vulkan/artifact_test_support.h",
]
snapshots = []
for rel in source_paths:
    source = ROOT / rel
    source.read_text(encoding="utf-8-sig")
    target = STAGE / "local-source" / rel
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(source, target)
    snapshots.append(dict(source=rel, retained=identity(target)))
save("local-source-snapshots.json", {"scope": "Read-only relevant source snapshots, not a compiled dependency closure or implementation patch.", "files": snapshots})

scale = struct.unpack("<f", struct.pack("<I", 0x3dcd0000))[0]
product = (5 - 2) * scale
rounded_bits, rounded = bf16_rne(product)
assert product == 0.30029296875 and rounded == 0.30078125 and rounded_bits == 0x3e9a
save("source-contract.json", {
    "status": "fixed-source and safetensors-header inspection; no backend execution",
    "artifact": {"repository": REPO, "revision": REV, "catalog_index": 9,
                 "base_model_commit": "not established by these metadata; do not assume selected official base revision"},
    "retained_fixed_config": identity(STAGE / "config.json"),
    "config_group": group,
    "official_links": {
        "index": f"https://huggingface.co/{REPO}/blob/{REV}/model.safetensors.index.json",
        "config": f"https://huggingface.co/{REPO}/blob/{REV}/config.json",
        "CT_base": f"https://github.com/vllm-project/compressed-tensors/blob/{CT}/src/compressed_tensors/compressors/pack_quantized/base.py",
        "CT_unpack": f"https://github.com/vllm-project/compressed-tensors/blob/{CT}/src/compressed_tensors/compressors/pack_quantized/helpers.py",
        "CT_dequantize": f"https://github.com/vllm-project/compressed-tensors/blob/{CT}/src/compressed_tensors/quantization/lifecycle/forward_helpers.py",
    },
    "physical_ports_from_all_399_headers": {
        "weight_packed": "I32[N,K/8], low-first 4-bit code along K",
        "weight_zero_point": "I32[ceil(N/8),K/group], low-first 4-bit zero point along N; actual N all divisible by 8",
        "weight_scale": "BF16[N,K/group]; actual group=32",
        "weight_shape": "I64[2]; 16 payload bytes not read; logical N/K independently derived from packed/scales dimensions",
        "weight_g_idx": "Absent in complete 2396-name index and all five headers",
        "configuration_dtype_is_not_storage": "QuantizationArgs zp_dtype/int8 denotes unpacked quantized values, not this artifact's stored I32 packed zero-point tensor.",
    },
    "source_steps": [
        {"source": "ct-source/compressors/pack_quantized/base.py:107-110,146-160", "fact": "Zero point packs/unpacks on packed_dim=0; weights use default packed_dim=1; decompression passes both to dequantize without an explicit result dtype."},
        {"source": "ct-source/compressors/pack_quantized/helpers.py:140-180", "fact": "Both code and zero-point unpack to signed int8 by subtracting 8. The equal +8 storage offsets cancel in their difference, but packing axes and word lookup cannot be conflated with each other or AWQ GEMM4."},
        {"source": "ct-source/quantization/lifecycle/forward.py:99-143", "fact": "Group size derives from q/scales dimensions and default output dtype is scale.dtype."},
        {"source": "ct-source/quantization/lifecycle/forward_helpers.py:140-177,550-570", "fact": "Natural column groups when g_idx absent; initialized g_idx has explicit argsort/permutation behavior. q cast, zero-point cast, subtraction and multiplication occur in scale dtype before optional final output conversion."},
    ],
    "selected_artifact_math": "BF16(BF16(q_signed) - BF16(zp_signed)), then BF16 multiply by the BF16 scale; explicit F32 output is the exact widening of that BF16 product.",
    "legal_nibble_shortcut": "Both signed INT4 operands and their [-15,15] integer difference are exactly representable in F16/BF16/F32. A direct integer nibble difference may replace the two offset removals/subtract only if the scale-dtype product RNE and non-finite/signed-zero behavior remain intact. Do not replace the typed product with a F32 product.",
    "rounding_witness": {"q_signed": 5, "zp_signed": 2, "q_nibble": 13, "zp_nibble": 10,
                         "scale_bf16_bits": "0x3dcd", "scale": scale,
                         "F32_product_without_source_rounding": product,
                         "original_BF16_product_bits": hex(rounded_bits), "original_BF16_then_F32": rounded,
                         "method": "Independent scalar integer/IEEE bit rounding only; no tensor payload or backend was used."},
    "unknowns": ["Actual codes/scales/zero-point values, finite/subnormal distributions and weight_shape values were not read.",
                 "Published whole-shard LFS SHA metadata was retained but not recomputed from tensor payload.",
                 "No full-model/provider/numerical/quality verification or build has been performed."]
})

owners = [
    {"layer": "public schema/infer", "files": ["include/hyle/compute/model_ops.h:230-266", "src/compute_ops/weight_decode.cc:95-165"],
     "change": "Append a distinct kCompressedTensorsAsymmetric4 format to existing ArtifactWeightDecode, retaining old enum ordinals/descriptor layout. Three ports are packed codes, packed zero-point, scales. New format is natural-column-group only; do not accept or silently ignore an extra permutation/g_idx port. Update comments/accepted formats/scale port selection and validate I32[N,K/8], I32[ceil(N/8),K/group], floating[N,K/group]. Unknown output selects scales dtype. Existing positive/dense/capacity/group checks remain; checked ceil via division/remainder.",
     "fresh_TUs": ["src/compute_ops/weight_decode.cc", "all actual model_ops.h inline owners in selected final CPU/CUDA/Apple/Vulkan link closures, resolved from depfiles at implementation time"]},
    {"layer": "CPU", "files": ["src/compute_provider_native/torch_cpu_program.cc:130-133,495-511", "third_party/compressed_tensors_cpu/compressed_tensors_cpu.h:8-19"],
     "change": "Add explicit new format branch and asymmetric helper. Unsigned/masked nibble reads from both actual axes; subtract and multiply in scales dtype; only then to requested output. Existing prepared operation/lifetime/execution remains.", "fresh_TUs": ["src/compute_provider_native/torch_cpu_program.cc"]},
    {"layer": "CUDA existing Torch artifact carrier", "files": ["src/compute_provider_torch_cuda/artifact_provider.cc:278-280,380-399,450-454", "third_party/compressed_tensors_cuda/compressed_tensors_cuda.h:8-17"],
     "change": "Same typed asymmetric helper/case, include new format in 8-shift setup but keep AWQ lane-order setup AWQ-only. Existing six-port capacity already covers three ports; no new stream, executor, prepared state ABI or weight copy. Keep managed/provider-workspace/host-blocking/noncapture runtime facts truthful for this cold carrier.", "fresh_TUs": ["src/compute_provider_torch_cuda/artifact_provider.cc"]},
    {"layer": "Apple", "files": ["src/compute_route_apple/apple_mature_artifact.cc:14-34", "third_party/compressed_tensors_apple/compressed_tensors_apple.h:10-24"],
     "change": "Add an explicit asymmetric branch before current remaining-format symmetric fallthrough (or explicitly decline until implemented). Decode zero points along N, truncate padded rows, use separate scales-type subtract/multiply and final cast. Must prove materialized source-type rounding under MLX evaluation; do not declare general cross-platform bit equality from algebra alone.", "fresh_TUs": ["src/compute_route_apple/apple_mature_artifact.cc", "actual selected Apple model_ops.h header owners"]},
    {"layer": "Vulkan/IREE", "files": ["src/compute_route_vulkan/vulkan_iree.cc:79-109,257-275,340-365", "src/compute_provider_iree_vulkan/native_program.h:12-54,80-95", "src/compute_provider_iree_vulkan/native_program.cc:124-154,461-474,674-676,814-862", "third_party/iree_vulkan_runtime/programs/generate_artifacts.py:1-166"],
     "change": "Append a distinct ProgramKind/export using existing ProgramSpec fields; explicit lower selection prevents current non-AWQ-to-symmetric fallthrough. Third input scale and packed-zero shape/bytes must be reflected in allocation/admission. Extend existing source_rounding path so low-scale typed product materializes before requested F32 output. Extend current generated artifact MLIR/VMFB with CT-asymmetric word indices and typed arithmetic; rebuild only that existing data/runtime carrier via locked recipe, not the SDK.",
     "fresh_TUs": ["src/compute_route_vulkan/vulkan_iree.cc", "src/compute_provider_iree_vulkan/native_program.cc", "actual selected header owners of native_program.h", "existing generated artifact program data owner"],
     "generated_files": ["third_party/iree_vulkan_runtime/programs/artifacts.mlir", "third_party/iree_vulkan_runtime/programs/artifacts.vmfb.b64"]},
]
save("implementation-design.json", {
    "status": "Read-only minimal plan; no API/source implementation, build or GPU run in this stage.",
    "artifact": dict(repository=REPO, revision=REV, catalog_index=9, roles=399),
    "facts": identity(STAGE / "header-facts.json"), "role_inventory": identity(STAGE / "quantized-roles.json"),
    "source_contract": identity(STAGE / "source-contract.json"),
    "choice": "Extend existing explicit cold ArtifactWeightDecode with distinct CT asymmetric4 format; no similar new operation, model-name branch or common Graph change.",
    "inputs": ["I32[N,K/8] packed codes", "I32[ceil(N/8),K/group] packed zero points", "F16/BF16/F32[N,K/group] scales (selected artifact BF16, group32)"],
    "permutation_boundary": "Natural column groups only. The selected artifact has no g_idx. A genuinely present initialized map must be rejected by the importer/format admission rather than dropped. A fourth g_idx tensor is rejected by three-port infer. Supporting it later requires an explicit permutation contract; it is not inferred from the AWQ repository name.",
    "shape_metadata": "weight_shape need not become a mathematical fourth port: infer N/K from codes/scales and validate loaded exporter metadata if/when an importer reads it. This investigation did not read its 16-byte payload.",
    "owners": owners,
    "dependency_provenance": "Any edits to the three compressed_tensors borrowed helpers and the generated IREE artifact data require their matching NOTICE/SOURCE/provenance/tree-lock updates only. No unrelated SDK/whole-lock rebuild is implied.",
    "cold_path": {
        "existing_contract": "model_ops.h:237-244 already says run once and retain decoded [N,K] as immutable constant for mature MatMul/Gather.",
        "minimal_use": "Use the existing decode prepared operation once in model/import cold preparation; retain source/code/Z/scale owners until actual Completion retirement, then bind the ready decoded StorageOwner/ReadLease as an ordinary ConstantBinding. Do not leave this decode node in per-token hot recipes.",
        "automatic_folding_limit": "ggml CUDA constant_expressions.h only folds its supported native immutable recipe; tensor_program.cc has no ArtifactWeightDecode lowerer. A new enum does not automatically make this Torch artifact decoder part of that native pass. Existing tests/compute_route_cpu/cpu_artifact_decode_test.cc:26-64 already demonstrate explicit decoded constant -> mature projection. No Graph cache/executor branch is needed for minimal completion.",
        "if_cached_later": "Any provider-local reuse must key all real code/Z/scale roots, offsets and exact descriptions plus format/group/output version; retain original owner/lease and use existing ConstantArtifactAccess. Pointer stability does not imply immutable payload. Such automatic caching is outside this minimal implementation."
    },
    "minimal_regressions": [
        {"owners": ["tests/compute_ops/operation_test.cc:1667-1683"], "cases": "Correct three-port infer/default BF16/F32 override; reject AWQ axes/lane layout, symmetric two ports, wrong Z dtype/ceilN shape/scales shape, extra g_idx, incomplete group and capacity overflow."},
        {"owners": ["tests/compute_route_cpu/cpu_artifact_decode_test.cc:67-112,147-198", "tests/graph_route_cuda/artifact_test.cc:44-164"], "cases": "Independent scalar nibble oracle, N=9 exercises packed-Z tail and K=64/group32 two groups. Distinct per-row/per-group zero points, negative I32 high-bit words, code extrema and q==zp; include BF16 0x3dcd witness/F16 equivalent and explicit F32-after-lowtype result. Reuse two-slot changed-input/owner-retirement/failure/immutable-constant MatMul controls. No full model/large matrix needed."},
        {"owners": ["tests/compute_route_apple/parity_delivery/main.cc existing Artifact Direct/Graph entry (or one focused existing Apple artifact fixture)", "tests/compute_route_vulkan/artifact_test_support.h", "tests/compute_route_vulkan/iree_test.cc:246-259", "tests/compute_route_vulkan/mature_tensor_test.cc"], "cases": "Use same small packing/typed-round oracle on actual original carriers. Extend shared Vulkan Direct/Graph artifact fixture; preserve source dtype temporary/final Cast. Apple needs a targeted low-source-rounding witness, not merely output tolerance. Keep existing NF4/AWQ/symmetric regressions as neighbours."}
    ],
    "not_claimed": ["No codes/zero/scale/weight_shape payload read or numerical artifact verification.", "No provider currently implements the proposed new format merely because this plan exists.", "No automatic Graph folding, all-artifact/group/activation-order support or model quality assertion.", "No build/GPU/SDK execution; exact final owner recipes must come from actual linked dependency manifests when implementation begins."]
})
print(json.dumps({name: identity(STAGE / name) for name in ["source-contract.json", "implementation-design.json", "local-source-snapshots.json"]}, indent=2))
