"""Bounded public metadata/source reads; never reads a safetensors payload."""
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import hashlib
import json
import struct
import urllib.error
import urllib.parse
import urllib.request

STAGE = Path(__file__).resolve().parent
ROOT = STAGE.parents[1]
REPO = 'cyankiwi/Qwen3.8-27B-AWQ-INT4'
REVISION = '6e134bae811fb5adac50ee042ae5f029ac6779aa'
CT_REVISION = 'ac8e2ba82f4e0d5eaa40069f8fc642738f124cd4'
MAX_HEADER = 16 * 1024 * 1024
records = []


def save(path, value):
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False)+'\n', encoding='utf-8')


def identity(path):
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())


def open_request(tag, url, byte_range=None):
    headers = {'Accept-Encoding': 'identity', 'User-Agent': 'Hyle-metadata-review/1'}
    if byte_range:
        headers['Range'] = byte_range
    row = dict(tag=tag, requested_url=url, requested_headers=headers,
               revision=CT_REVISION if 'githubusercontent.com' in url else REVISION)
    records.append(row)
    try:
        response = urllib.request.urlopen(urllib.request.Request(url, headers=headers), timeout=25)
        resolved = urllib.parse.urlsplit(response.geturl())
        row.update(status=response.status, response_headers=dict(response.headers),
                   resolved_url_without_signing_query=urllib.parse.urlunsplit(resolved._replace(query='')),
                   resolved_query_present=bool(resolved.query))
        return response, row
    except Exception as error:
        row.update(error=type(error).__name__+': '+str(error))
        if isinstance(error, urllib.error.HTTPError):
            row.update(status=error.code, response_headers=dict(error.headers))
            error.close()
        save(STAGE/(tag+'.http.json'), row)
        return None, row


def fetch_small(tag, url, filename, limit=2*1024*1024):
    response, row = open_request(tag, url)
    if response is None:
        return None
    try:
        with response:
            data = response.read(limit+1)
        row['application_bytes_read'] = len(data)
        if len(data) > limit:
            raise ValueError('Metadata/source size limit exceeded')
        path = STAGE/filename
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(data)
        row['body'] = identity(path)
        return data
    except Exception as error:
        row['error'] = type(error).__name__+': '+str(error)
        return None
    finally:
        save(STAGE/(tag+'.http.json'), row)


def fetch_header(filename):
    stem = Path(filename).stem
    url = f'https://huggingface.co/{REPO}/resolve/{REVISION}/{filename}?download=true'
    response, first = open_request(stem+'-prefix', url, 'bytes=0-7')
    if response is None:
        return dict(file=filename, completed=False, reason=first['error'])
    try:
        with response:
            prefix = response.read(8)
        first['application_bytes_read'] = len(prefix)
        if len(prefix) != 8:
            raise ValueError('Incomplete eight-byte length prefix')
        if first['status'] == 206 and not first['response_headers'].get('Content-Range', '').startswith('bytes 0-7/'):
            raise ValueError('Unexpected prefix Content-Range')
        length = struct.unpack('<Q', prefix)[0]
        first['decoded_header_bytes'] = length
        if not 2 <= length <= MAX_HEADER:
            raise ValueError('Unreasonable safetensors header length; payload not read')
        path = STAGE/'headers'/(stem+'.prefix.bin')
        path.parent.mkdir(exist_ok=True)
        path.write_bytes(prefix)
        first['body'] = identity(path)
    except Exception as error:
        first['error'] = type(error).__name__+': '+str(error)
        return dict(file=filename, completed=False, reason=first['error'])
    finally:
        save(STAGE/(stem+'-prefix.http.json'), first)
    response, second = open_request(stem+'-header', url, f'bytes=8-{length+7}')
    if response is None:
        return dict(file=filename, completed=False, reason=second['error'])
    try:
        with response:
            if second['status'] == 200:
                # Range ignored: consume only prefix+declared bounded JSON,
                # then close before tensor data, regardless of Content-Length.
                repeated = response.read(8)
                if repeated != prefix:
                    raise ValueError('Ignored-Range response prefix changed')
                data = response.read(length)
                second['application_bytes_read'] = 8+len(data)
                second['range_ignored'] = True
            elif second['status'] == 206:
                content_range = second['response_headers'].get('Content-Range', '')
                if not content_range.startswith(f'bytes 8-{length+7}/'):
                    raise ValueError('Unexpected JSON-header Content-Range')
                data = response.read(length)
                second['application_bytes_read'] = len(data)
                second['range_ignored'] = False
            else:
                raise ValueError('Unexpected response status')
        if len(data) != length:
            raise ValueError('Incomplete declared header')
        header = json.loads(data)
        path = STAGE/'headers'/(stem+'.header.json')
        path.write_bytes(data)
        second.update(body=identity(path), tensor_payload_bytes_read=0,
                      exact_application_interval='[8,8+header_length)',
                      payload_begin_offset=8+length)
        tensors = []
        for name, value in header.items():
            if name == '__metadata__':
                continue
            begin, end = value['data_offsets']
            assert 0 <= begin <= end
            tensors.append(dict(name=name, shard=filename, dtype=value['dtype'],
                shape=value['shape'], data_offsets=value['data_offsets'], bytes=end-begin,
                absolute_file_offsets=[8+length+begin, 8+length+end]))
        return dict(file=filename, completed=True, header=identity(path), header_bytes=length,
                    tensor_payload_bytes_read=0, tensors=tensors)
    except Exception as error:
        second['error'] = type(error).__name__+': '+str(error)
        return dict(file=filename, completed=False, reason=second['error'])
    finally:
        save(STAGE/(stem+'-header.http.json'), second)


def main():
    sources = ['compressors/pack_quantized/base.py', 'compressors/pack_quantized/helpers.py',
               'quantization/lifecycle/forward.py', 'quantization/lifecycle/forward_helpers.py',
               'quantization/quant_args.py']
    jobs = [('hf-api', f'https://huggingface.co/api/models/{REPO}/revision/{REVISION}?blobs=true', 'api-model.json'),
            ('hf-index', f'https://huggingface.co/{REPO}/resolve/{REVISION}/model.safetensors.index.json?download=true', 'model.safetensors.index.json')]
    jobs += [('ct-'+str(i), f'https://raw.githubusercontent.com/vllm-project/compressed-tensors/{CT_REVISION}/src/compressed_tensors/{name}', 'ct-source/'+name)
             for i, name in enumerate(sources)]
    with ThreadPoolExecutor(max_workers=3) as executor:
        fetched = list(executor.map(lambda args: fetch_small(*args), jobs))
    headers = []
    if fetched[1] is not None:
        index = json.loads(fetched[1])
        files = sorted(set(index['weight_map'].values()))
        assert len(files) <= 16 and all(Path(x).name == x and x.endswith('.safetensors') for x in files)
        with ThreadPoolExecutor(max_workers=3) as executor:
            headers = list(executor.map(fetch_header, files))
    all_complete = bool(headers) and all(row['completed'] for row in headers)
    tensors = [tensor for row in headers if row['completed'] for tensor in row['tensors']]
    if all_complete:
        assert {row['name'] for row in tensors} == set(index['weight_map'])
        assert all(index['weight_map'][row['name']] == row['shard'] for row in tensors)
    save(STAGE/'tensor-header-inventory.json', dict(complete=all_complete, shards=headers,
         metadata_only=True, tensor_payload_bytes_read=0,
         limit='Application reads end at declared JSON boundary. Socket/CDN internal prefetch is not measured; no tensor bytes are requested by Range, parsed, retained or used.'))
    save(STAGE/'retrieval.json', dict(repository=REPO, revision=REVISION, CT_revision=CT_REVISION,
         safetensors_headers_complete=all_complete, HTTP_records=records,
         new_GPU_runs=0, builds=0, tensor_payload_bytes_read=0,
         retries=0, errors=[r for r in records if 'error' in r]))
    print(json.dumps(dict(metadata_requests=len(records), headers_complete=all_complete,
        completed_shards=sum(r['completed'] for r in headers), tensors=len(tensors),
        errors=[dict(tag=r['tag'],error=r['error']) for r in records if 'error' in r]), indent=2))


if __name__ == '__main__':
    main()
