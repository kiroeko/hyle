"""Archive metadata and read-only source evidence; never include tensor payload."""
import hashlib
import json
import zipfile
from pathlib import Path

STAGE = Path(__file__).resolve().parent
ROOT = STAGE.parent.parent
DEST = ROOT / "docs/evidence/correctness/ct-asymmetric-int4-header-2026-10-20.zip"


def sha(data):
    return hashlib.sha256(data).hexdigest()


def read(name):
    return json.loads((STAGE / name).read_text(encoding="utf-8"))


facts = read("header-facts.json")
assert facts["complete_index_and_headers"] and facts["tensor_count"] == 2396
assert facts["quantized_roles"] == 399 and facts["tensor_payload_bytes_read"] == 0
assert read("quantized-roles.json")["count"] == 399
assert read("source-contract.json")["artifact"]["revision"] == facts["revision"]
assert read("implementation-design.json")["artifact"]["revision"] == facts["revision"]
for row in read("local-source-snapshots.json")["files"]:
    p = Path(row["retained"]["path"])
    assert p.is_relative_to(STAGE) and sha(p.read_bytes()) == row["retained"]["sha256"]
files = sorted((p for p in STAGE.rglob("*") if p.is_file() and p.name != "archive-receipt.json"), key=lambda p: p.relative_to(STAGE).as_posix())
payloads = {}
for p in files:
    assert p.suffix in {".json", ".py", ".cc", ".h", ".md", ".bin"}, p
    data = p.read_bytes()
    if p.suffix == ".bin":
        assert p.name.endswith(".prefix.bin") and len(data) == 8, p
    payloads[p.relative_to(STAGE).as_posix()] = data
manifest = {name: {"bytes": len(data), "sha256": sha(data)} for name, data in payloads.items()}
assert not DEST.exists(), "Archive already exists; no overwrite is performed."
DEST.parent.mkdir(parents=True, exist_ok=True)
with zipfile.ZipFile(DEST, "x", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as z:
    for name, data in payloads.items():
        z.writestr(name, data)
    z.writestr("payload-manifest.json", json.dumps(manifest, indent=2) + "\n")
with zipfile.ZipFile(DEST) as z:
    assert set(z.namelist()) == {*manifest, "payload-manifest.json"}
    assert json.loads(z.read("payload-manifest.json")) == manifest
    for name, row in manifest.items():
        data = z.read(name)  # ZipFile also checks this entry's CRC on this one read.
        assert len(data) == row["bytes"] and sha(data) == row["sha256"]
archive_bytes = DEST.read_bytes()
receipt = dict(path=str(DEST), bytes=len(archive_bytes), sha256=sha(archive_bytes),
               payload_entries=len(manifest), total_entries=len(manifest) + 1,
               crc_verified=True, payload_sha256_verified=True,
               tensor_payload_bytes_read=0, build_or_GPU_run=False,
               includes="Fixed config/index/API, five header+prefix pairs, HTTP receipts and first client parser failure, all399 roles, pinned CT source, relevant local source snapshots and read-only design.",
               limits="No weight payload/weight_shape values/full shard rehash/provider execution/whole-model or quality claim.")
(STAGE / "archive-receipt.json").write_text(json.dumps(receipt, indent=2) + "\n", encoding="utf-8")
print(json.dumps(receipt, indent=2))
