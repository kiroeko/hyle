param([switch]$Apply, [switch]$RemoveClosedInferenceRoundBinaries)

if ($RemoveClosedInferenceRoundBinaries) {
  $ErrorActionPreference = 'Stop'
  $roundRoot = (Resolve-Path -LiteralPath $PSScriptRoot).Path
  if ($roundRoot -ne 'C:\public\project-hyle\hyle') { throw 'Unexpected workspace' }
  $roundBase = Join-Path $roundRoot '.scratch/inference-system-review-20261025/closed-round-cleanup'
  $roundPlan = Get-Content -LiteralPath (Join-Path $roundBase 'plan.json') -Raw | ConvertFrom-Json
  if ((Test-Path -LiteralPath (Join-Path $roundBase 'removed.json')) -or $roundPlan.files.Count -ne 9 -or $roundPlan.logical_bytes -ne 144653020L) { throw 'Cleanup plan changed or already applied' }
  $roundActive = @(Get-CimInstance Win32_Process | Select-Object -ExpandProperty ExecutablePath)
  $roundTargets = @(foreach ($entry in $roundPlan.files) {
    $roundPath = [IO.Path]::GetFullPath((Join-Path $roundRoot $entry.path))
    $roundAllowed = [IO.Path]::GetFullPath((Join-Path $roundRoot $entry.task_base))
    if (!$roundPath.StartsWith($roundAllowed+'\',[StringComparison]::OrdinalIgnoreCase) -or
        [IO.Path]::GetExtension($roundPath) -notin @('.exe','.obj','.exp','.lib','.dll','.map')) { throw 'Target outside exact binary scope' }
    if ((Resolve-Path -LiteralPath $roundPath).Path -ne $roundPath -or $roundActive -contains $roundPath) { throw 'Target changed or active' }
    for ($roundParent=$roundPath; $roundParent; $roundParent=[IO.Path]::GetDirectoryName($roundParent)) {
      if ((Get-Item -LiteralPath $roundParent -Force).Attributes -band [IO.FileAttributes]::ReparsePoint) { throw 'Reparse point in target path' }
    }
    $roundProof = Get-Content -LiteralPath (Join-Path $roundRoot $entry.proof) -Raw | ConvertFrom-Json
    if ((Get-FileHash -LiteralPath (Join-Path $roundRoot $roundProof.archive.path) -Algorithm SHA256).Hash -ne $roundProof.archive.sha256) { throw 'Published evidence differs' }
    $roundItem = Get-Item -LiteralPath $roundPath
    if ($roundItem.PSIsContainer -or $roundItem.Length -ne $entry.bytes -or
        (Get-FileHash -LiteralPath $roundPath -Algorithm SHA256).Hash -ne $entry.sha256) { throw 'Recorded binary differs' }
    $roundFile = [IO.File]::Open($roundPath,[IO.FileMode]::Open,[IO.FileAccess]::Read,[IO.FileShare]::None)
    $roundFile.Dispose()
    [pscustomobject]@{path=$roundPath;bytes=$entry.bytes;sha256=$entry.sha256}
  })
  $roundResult = [ordered]@{applied=[bool]$Apply;files=$roundTargets;logical_bytes=$roundPlan.logical_bytes;physical_bytes_freed_unknown=$true}
  $roundResult | ConvertTo-Json -Depth 7 | Set-Content -LiteralPath (Join-Path $roundBase 'preview.json') -Encoding utf8
  if ($Apply) {
    foreach ($entry in $roundTargets) { Remove-Item -LiteralPath $entry.path }
    foreach ($entry in $roundTargets) { if (Test-Path -LiteralPath $entry.path) { throw 'Target still present' } }
    $roundResult | ConvertTo-Json -Depth 7 | Set-Content -LiteralPath (Join-Path $roundBase 'removed.json') -Encoding utf8
  }
  [ordered]@{files=$roundTargets.Count;logical_bytes=$roundPlan.logical_bytes;applied=[bool]$Apply} | ConvertTo-Json
  exit 0
}
