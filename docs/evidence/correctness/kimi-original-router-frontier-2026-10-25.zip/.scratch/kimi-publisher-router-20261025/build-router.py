from pathlib import Path
import json,hashlib,sys,importlib.util,shutil,os
sys.dont_write_bytecode=True
R=Path.cwd();W=R/'.scratch/kimi-publisher-router-20261025';A=W/'build1'
spec=importlib.util.spec_from_file_location('b',R/'.scratch/mtp-extraction-regression-20261024/check.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
source=W/'router.cc';assert hashlib.sha256(source.read_bytes()).hexdigest()=='b679b1b0a9ef8e9a34a184395d136479101782a377b89f3b2358982b197754a1'
S=A/'source';S.mkdir(parents=True);shutil.copyfile(source,S/'router.cc')
includes=b.read(R/'.scratch/kimi-mixed-working-set-20261025/strict2/dependencies.json')['Data']['Includes'];pins=[]
for name in includes:
 p=Path(name)
 try:rel=p.resolve().relative_to(R.resolve())
 except ValueError:continue
 if str(rel).lower().startswith(('include\\','engine\\')):
  target=S/rel;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,target);pins.append(b.pin(target))
b.save(A/'source-pins.json',[b.pin(S/'router.cc'),*pins])
old=b.args(R/'.scratch/inference-system-review-20261025/text-r2-suffix/compile/command.json');cmd=[old[0],'/I'+str(S),'/I'+str(S/'include'),'/I'+str(R)];skip=False
for word in old[1:]:
 if skip:skip=False;continue
 if word=='/sourceDependencies':skip=True;continue
 low=word.lower().replace('\\','/')
 if low.startswith(('/fo','/fd'))or low.endswith(('.cc','.cpp')):continue
 if low.startswith(('/i','-i'))and'/.scratch/'in low and low.endswith('/source'):continue
 cmd.append(word)
cmd+=['/sourceDependencies',str(A/'compile/dependencies.json'),str(S/'router.cc'),'/Fo'+str(A/'compile/router.obj'),'/Fd'+str(A/'compile/router.pdb')]
env=b.environment(old[0]);b.execute(cmd,A/'compile',env,90)
base=b.args(R/'.scratch/nf4-packed-contraction-20261025/component3/link/command.json');replace={}
replace[str(R/'.scratch/nf4-packed-contraction-20261025/component3/compile/component.obj')]=str(A/'compile/router.obj')
for kind,sha,source_sha in [('budget','4c434358cd6807490401d4c38b3cf0912ac93b99f84d4a6396988be16bd227b9','b5d6fdce4703e30a51be3046cd93480cf7e83bb01a654061bb833aa58ee953bd'),('leases','97c3079899d4c9cf599bfbaa6693f4e178e568c0a7a8b1e8a9247fee5a94e3fd','456c075f6fdfa6016a8c1159348224d040bcdccbd69d6ae11eac2a0dbdf70c2e')]:
 p=R/'.scratch/lease-budget-deallocation-order-20261025/implementation/attempt1'/kind/'unit.obj';assert b.pin(p)['sha256']==sha
 product=R/'src/compute'/('resource_budget.cc'if kind=='budget'else'resource_leases.cc');assert b.pin(product)['sha256']==source_sha
 candidate=[str(R/'.scratch/engine-product-20261024/cpu-budget-fix1'/kind/(kind+'.obj'))]
 if kind=='budget':candidate.append(str(R/'.scratch/inference-shared-requested-budget-20261025/attempt1/core/unit.obj'))
 actual=[x for x in candidate if x in base];assert len(actual)==1;replace[actual[0]]=str(p)
assert all(base.count(x)==1 for x in replace)
args=[replace.get(x,x)for x in base if not x.lower().startswith(('/out:','/pdb:','/map:','/implib:'))]
for x in args[1:]:
 if Path(x).is_absolute()and x.lower().endswith(('.obj','.lib')):assert Path(x).is_file(),x
args+=['/OUT:'+str(A/'link/router.exe'),'/PDB:'+str(A/'link/router.pdb'),'/IMPLIB:'+str(A/'link/router.lib')];b.execute(args,A/'link',env,90)
native=R/'.scratch/mtp-performance-convergence-20261025/baseline/link/hyle_ggml_cpu_gdn_scale_v3.dll';os.link(native,A/'link'/native.name)
b.save(A/'summary.json',dict(status='ACTUAL_ROUTER_ENTRY_COMPILED_LINKED_NOT_YET_EXECUTED',compile=b.read(A/'compile/process.json'),link=b.read(A/'link/process.json'),source=b.pin(S/'router.cc'),image=b.pin(A/'link/router.exe'),exact_link_replacements=[dict(before=a,after=b.pin(Path(b0)))for a,b0 in replace.items()],native=b.pin(native),source_pins=b.pin(A/'source-pins.json'),GPU_started=False,SDK_rebuilt=False))
