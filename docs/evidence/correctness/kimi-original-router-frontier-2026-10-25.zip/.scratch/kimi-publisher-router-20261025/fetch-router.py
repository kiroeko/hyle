"""Four authorized exact source body ranges; no retries, no unbounded HTTP."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor,as_completed
import hashlib,importlib.util,inspect,json,sys,urllib.request
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;R=W.parents[1];B=R/'.scratch/mtp-download-budget-20261023/budget.py';SCRIPT=Path(__file__).resolve().relative_to(R).as_posix()
def sha(raw):return hashlib.sha256(raw).hexdigest()
def save(p,x):p.write_text(json.dumps(x,indent=2)+'\n',encoding='utf8')
def main():
 plan=json.loads((W/'fetch-plan.json').read_bytes());assert plan['request_count']==4 and plan['maximum_new_bytes']==25697280 and len(plan['requests'])==4
 assert sum(x['exact_bytes']for x in plan['requests'])==25697280 and plan['automatic_retries']==0
 assert sha(B.read_bytes())==plan['budget_helper']['sha256']
 spec=importlib.util.spec_from_file_location('kimi_router_budget',B);budget=importlib.util.module_from_spec(spec);spec.loader.exec_module(budget);budget.require_enabled()
 guard=urllib.request.urlopen;assert Path(guard.__code__.co_filename).resolve()==B.resolve()and inspect.getclosurevars(guard).nonlocals['script']==SCRIPT
 out=W/'payload';out.mkdir(exist_ok=False);save(out/'source.json',dict(plan_sha256=sha((W/'fetch-plan.json').read_bytes()),sources=plan['source_identities'],whole_LFS_hash_verified=False))
 def fetch(item):
  first,last=item['range_inclusive'];amount=last-first+1;assert amount==item['exact_bytes']and 0<amount<=12845056 and last<item['source_bytes'];budget.require_mirror_url(item['url'])
  folder=out/f'request-{item["ordinal"]}';folder.mkdir();headers={'Range':f'bytes={first}-{last}','If-Match':item['source_etag'],'Accept-Encoding':'identity','Cache-Control':'no-transform','User-Agent':'Hyle-Kimi-original-router/2026-10-25'}
  with budget.locked()as ledger:floor=len(ledger['requests'])
  raw=bytearray();info=None
  def ordinal():
   with budget.locked()as ledger:ids=[r['id']for r in ledger['requests'][floor:]if r['script']==SCRIPT and r['url']==item['url']and r['range']==[first,last]]
   assert len(ids)==1;return ids[0]
  try:
   with urllib.request.urlopen(urllib.request.Request(item['url'],headers=headers),timeout=45)as response:
    budget.require_mirror_url(response.geturl());info=dict(status=response.status,final_url=response.geturl(),etag=response.headers.get('ETag'),content_range=response.headers.get('Content-Range'),content_length=response.headers.get('Content-Length'),source_revision=response.headers.get('X-Repo-Commit'),content_encoding=response.headers.get('Content-Encoding'))
    assert response.status==206 and info['content_range']==f'bytes {first}-{last}/{item["source_bytes"]}'and info['content_length']is not None and int(info['content_length'])==amount,'Not exact206/Content-Range/length'
    assert info['etag']==item['source_etag'],'Strong source ETag changed'
    assert (info['content_encoding']or'identity').lower()=='identity','Encoded body refused'
    assert info['source_revision']is None or info['source_revision']==item['revision'],'Pinned revision changed'
    reader=getattr(response,'read1',response.read)
    while len(raw)<amount:
     part=reader(min(65536,amount-len(raw)))
     if not part:raise EOFError('Exact source body truncated')
     raw.extend(part)
   assert len(raw)==amount;request_id=ordinal();payload=out/item['output'];payload.write_bytes(raw)
   info.update(bytes=len(raw),sha256=sha(raw));budget.update(request_id,outcome='downloaded',received_bytes=len(raw),sha256=sha(raw),verified_response=info)
   result=dict(ordinal=item['ordinal'],catalog_index=item['catalog_index'],role=item['role'],path=payload.relative_to(R).as_posix(),dtype=item['dtype'],shape=item['shape'],range=[first,last],bytes=len(raw),sha256=sha(raw),budget_request_id=request_id,response=info,whole_LFS_hash_verified=False)
   save(folder/'complete.json',result);return result
  except BaseException as e:
   request_id=ordinal();budget.update(request_id,outcome='failed',received_bytes=len(raw),error_type=type(e).__name__,error=str(e),response_metadata=info)
   save(folder/'failed.json',dict(budget_request_id=request_id,range=[first,last],received_bytes=len(raw),error_type=type(e).__name__,error=str(e),response=info,automatic_retries=0));raise
 completed=[];failure=None
 with ThreadPoolExecutor(max_workers=4)as pool:
  futures=[pool.submit(fetch,item)for item in plan['requests']]
  try:
   for f in as_completed(futures):
    completed.append(f.result());completed.sort(key=lambda x:x['ordinal']);save(out/'verified-parts.json',dict(complete=False,parts=completed));print(json.dumps(dict(completed=len(completed),planned=4,bytes=sum(x['bytes']for x in completed))),flush=True)
  except BaseException as e:
   failure=e
   for f in futures:f.cancel()
   save(out/'failed.json',dict(status='FIRST_FAILURE_PRESERVED_NO_RETRY',error_type=type(e).__name__,error=str(e),automatic_retries=0))
 if failure:raise failure
 assert len(completed)==4 and sum(x['bytes']for x in completed)==25697280
 complete=dict(status='EXACT_TWO_PUBLISHER_ROUTERS_AND_BIASES_ACQUIRED',parts=completed,bytes=25697280,HTTP_requests=4,only_HTTPS_host='hf-mirror.net',whole_LFS_hash_verified=False,experts_acquired=0,Phase2_authorized=False)
 save(out/'complete.json',complete);print(json.dumps({k:v for k,v in complete.items()if k!='parts'}),flush=True)
if __name__=='__main__':main()
