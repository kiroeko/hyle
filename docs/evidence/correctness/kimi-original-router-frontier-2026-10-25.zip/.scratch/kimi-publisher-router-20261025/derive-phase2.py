from pathlib import Path
import json,hashlib,zipfile
R=Path.cwd();W=R/'.scratch/kimi-publisher-router-20261025';old=R/'.scratch/kimi-mixed-working-set-20261025/source-inventory.json';inventory=json.loads(old.read_bytes());run=json.loads((W/'run1/result.json').read_bytes());assert run['status']=='ORIGINAL_PUBLISHER_ROUTER_TWO_INPUTS_PASS'and run['process']['exit']==0
ids=[]
for epoch in range(2):
 import struct
 raw=(W/f'actual-{epoch}/ids.i32').read_bytes();values=list(struct.unpack('<16i',raw));assert values==run['rows'][epoch]['actual_IDs'];assert len(set(values))==16 and all(0<=x<896 for x in values);ids.append(values)
selected=sorted(set(x for row in ids for x in row));assert len(selected)==16
parts=[];groups=[];artifacts=[]
for a in inventory['artifacts']:
 with zipfile.ZipFile(R/a['source_archive']['path'])as z:raw=z.read(a['header']['entry']);assert hashlib.sha256(raw).hexdigest()==a['header']['sha256'];header=json.loads(raw)
 base=a['header']['data_base'];prefix='language_model.model.layers.1.block_sparse_moe.';already={x['name']for x in a['minimal_authentic_router_frontier']};wanted=[(x['name'],'static',None)for x in a['roles']if x['scope']=='static'and x['name']not in already]
 for eid in selected:
  for leg in ['w1','w3','w2']:
   suffixes=['weight','weight_scale']if a['catalog_index']==23 else['weight_packed','weight_scale','weight_shape']
   for suffix in suffixes:wanted.append((prefix+f'experts.{eid}.{leg}.{suffix}','expert',eid))
 rows=[]
 for name,kind,eid in wanted:
  d=header[name];start,end=d['data_offsets'];row=dict(catalog_index=a['catalog_index'],role=name,kind=kind,global_expert=eid,dtype=d['dtype'],physical_shape=d['shape'],first=base+start,last=base+end-1,bytes=end-start)
  if name.endswith('weight_shape'):
   leg=name.split('.')[-2];row['expected_original_I64_values']=[3584,3072]if leg=='w2'else[3072,3584];assert d['dtype']=='I64'and d['shape']==[2]and end-start==16
  rows.append(row)
 rows.sort(key=lambda x:x['first']);merged=[]
 for row in rows:
  if merged and merged[-1]['last']+1==row['first']:
   merged[-1]['last']=row['last'];merged[-1]['bytes']+=row['bytes'];merged[-1]['roles'].append(row)
  else:merged.append(dict(catalog_index=a['catalog_index'],url=a['url'],source_etag=a['source_etag'],source_bytes=a['source_bytes'],revision=a['revision'],first=row['first'],last=row['last'],bytes=row['bytes'],roles=[row]))
 for m in merged:assert m['bytes']==m['last']-m['first']+1==sum(x['bytes']for x in m['roles'])
 artifacts.append(dict(catalog_index=a['catalog_index'],selected_globals=selected,logical_role_count=len(rows),exact_contiguous_ranges=len(merged),bytes=sum(x['bytes']for x in rows),static_bytes=sum(x['bytes']for x in rows if x['kind']=='static'),selected_expert_bytes=sum(x['bytes']for x in rows if x['kind']=='expert'),header=a['header'],source_archive=a['source_archive']))
 groups+=merged;parts+=rows
for i,row in enumerate(groups):row['ordinal']=i
plan=dict(status='DERIVED_ONLY_FROM_ACTUAL_GPU_IDS_NOT_AUTHORIZED_TO_FETCH',actual_GPU_result_sha256=hashlib.sha256((W/'run1/result.json').read_bytes()).hexdigest(),actual_IDs_by_input=ids,actual_same_ID_sets=True,source_numeric_router_aliases=[23,24],source_bank_union=selected,artifacts=artifacts,logical_roles=parts,requests=groups,request_count=len(groups),logical_role_count=len(parts),maximum_new_payload_bytes=sum(x['bytes']for x in groups),maximum_concurrency=4,automatic_retries=0,network_authorized=False,PAUSED_must_remain=True,whole_LFS_hash_verified=False,scope='Only actual original selected expert operands and genuinely consumed latent/shared/independent FP8 static roles. Each role interval authenticated from the complete fixed source header. Merged ranges consist exclusively of adjacent required bytes; no unrelated expert gap or full-file download.',execution_notes=['The original two input Top16 sets are equal; keep that fact. Fetch each selected expert once and reuse local source bytes; never fabricate alternate IDs or fetch0..16.', 'Keep distinct A32/FP8 and K512 contracts, source I64 shape-value authentication, source norm direct scales and explicit SiTU F32 then BF16.', 'Actual-original dense rows need independent complete/source-equation references with a declared F32/BF16 accumulation boundary; the former sparse bitwise oracle cannot be copied to genuine dense weights.', 'Decode/reference one expert at a time if needed; no896-expert float bank or large archived generated banks. Use the same existing supplier/Graph/resource owners.'])
(W/'phase2-derived-plan.json').write_text(json.dumps(plan,indent=2)+'\n',encoding='utf8');print(json.dumps(dict(total_bytes=plan['maximum_new_payload_bytes'],requests=len(groups),roles=len(parts),artifacts=artifacts),indent=2))
