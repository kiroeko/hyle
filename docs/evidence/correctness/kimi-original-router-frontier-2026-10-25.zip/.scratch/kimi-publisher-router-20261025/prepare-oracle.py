"""Independent fixed original-router reference: no Hyle math or GPU."""
from pathlib import Path
import json,hashlib,sys
import numpy as np
R=Path.cwd();W=R/'.scratch/kimi-publisher-router-20261025';O=W/'oracle';O.mkdir(exist_ok=False)
def sha(raw):return hashlib.sha256(raw).hexdigest()
def pin(p):return dict(path=p.relative_to(R).as_posix(),bytes=p.stat().st_size,sha256=sha(p.read_bytes()))
def bf16(x):
 u=np.asarray(x,dtype=np.float32).view(np.uint32);return((u+0x7fff+((u>>16)&1))>>16).astype('<u2')
def wide(x):return(np.asarray(x,dtype=np.uint32)<<16).view(np.float32)
manifest=json.loads((W/'payload/complete.json').read_bytes());assert manifest['status']=='EXACT_TWO_PUBLISHER_ROUTERS_AND_BIASES_ACQUIRED'
parts={}
for p in manifest['parts']:
 raw=(R/p['path']).read_bytes();assert len(raw)==p['bytes']and sha(raw)==p['sha256'];parts[p['catalog_index'],p['dtype']]=raw
assert parts[23,'BF16']==parts[24,'BF16']and parts[23,'F32']==parts[24,'F32']
weights=wide(np.frombuffer(parts[23,'BF16'],dtype='<u2')).reshape(896,7168);bias=np.frombuffer(parts[23,'F32'],dtype='<f4');assert np.isfinite(weights).all()and np.isfinite(bias).all()
rows=[]
for epoch in range(2):
 x=np.resize(np.array([1.,2.,-.75,-1.],dtype=np.float32),7168)
 for i in range(17):x[i]=(2.+(16-i if epoch else i)/8.)/64.
 xb=bf16(x);a=wide(xb);input_path=O/f'input-{epoch}.bf16';input_path.write_bytes(xb.tobytes());logits=weights.astype(np.float64)@a.astype(np.float64);absolute=np.abs(weights.astype(np.float64))@np.abs(a.astype(np.float64));assert np.isfinite(logits).all()
 # IEEE F32 sum bound, chosen before seeing CUDA outputs: products of finite
 # BF16 operands are exactly representable here, then at most K-1 F32 adds.
 u=2.**-24;gamma=(7167*u)/(1.-7167*u);bound=gamma*absolute+np.maximum(np.abs(logits)*u,np.finfo(np.float32).tiny)
 # This separate final-round reference is descriptive; the measured CUDA
 # TopK is independently checked from its validated F32 intermediate scores.
 lf=logits.astype(np.float32);sig=np.empty(896,dtype=np.float64);mask=lf>=0;sig[mask]=1./(1.+np.exp(-lf[mask].astype(np.float64)));t=np.exp(lf[~mask].astype(np.float64));sig[~mask]=t/(1.+t);sig=sig.astype(np.float32);scores=(sig+bias).astype(np.float32);ids=np.argsort(-scores,kind='stable')[:16].astype('<i4');prob=sig[ids];rw=(prob.astype(np.float64)/prob.astype(np.float64).sum()).astype('<f4')
 artifacts={}
 for name,v in [('logits-f64',logits.astype('<f8')),('sum-abs-f64',absolute.astype('<f8')),('bound-f64',bound.astype('<f8')),('final-round-ids',ids),('final-round-weights',rw)]:
  p=O/f'{name}-{epoch}.bin';p.write_bytes(v.tobytes());artifacts[name]=pin(p)
 rows.append(dict(epoch=epoch,input=pin(input_path),reference=artifacts,descriptive_final_round_ids=ids.tolist(),logit_range=[float(logits.min()),float(logits.max())],maximum_predeclared_F32_dot_error_bound=float(bound.max())))
result=dict(status='INDEPENDENT_ORACLE_PREPARED_BEFORE_GPU',numpy=np.__version__,python=sys.version,source_role_pins=[p for p in manifest['parts']],source_numeric_roles_identical_between_artifacts=True,source_infinite_or_nan_values=0,generated_input_patterns='Frozen arithmetic patterns copied from the generated-composition fixture; no seed or input search.',logit_reference='Independent NumPy F64 product/sum; original BF16 values widened mathematically, no Hyle/provider decoder or kernel.',comparison='All896 CUDA logits vs F64 with predeclared gamma_(K-1)*sumabs bound; sigmoid checked independently at validated actual F32 logits with abs<=2e-7; corrected scores exact F32 addition; TopK exact stable order from validated actual F32 corrected scores, normalized raw sigmoid weights abs<=2e-7. F64-final-round reference IDs are reported separately, not used to demand an unjustified F32 reduction order.',F32_add_rounding_unit=2.**-24,rows=rows,oracle_source=pin(Path(__file__).resolve()),GPU_executed=False)
(O/'manifest.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8');print(json.dumps({k:result[k]for k in ['status','source_numeric_roles_identical_between_artifacts','GPU_executed']}));print(json.dumps([dict(epoch=r['epoch'],IDs=r['descriptive_final_round_ids'],logit_range=r['logit_range'],maximum_bound=r['maximum_predeclared_F32_dot_error_bound'])for r in rows]))
