from pathlib import Path
import sys,importlib.util,json,os
sys.dont_write_bytecode=True
R=Path.cwd();W=R/'.scratch/kimi-publisher-router-20261025'
spec=importlib.util.spec_from_file_location('b',R/'.scratch/mtp-extraction-regression-20261024/check.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
summary=b.read(W/'build1/summary.json');exe=Path(summary['image']['path']);assert b.pin(exe)==summary['image'];assert b.pin(Path(summary['source']['path']))==summary['source']
source=b.read(W/'payload/complete.json');oracle=b.read(W/'oracle/manifest.json');pins=[]
for row in source['parts']:
 p=R/row['path'];q=b.pin(p);assert q['bytes']==row['bytes']and q['sha256']==row['sha256'];pins.append(q)
for row in oracle['rows']:
 for x in[row['input'],*row['reference'].values()]:
  p=R/x['path'];q=b.pin(p);assert q['bytes']==x['bytes']and q['sha256']==x['sha256'];pins.append(q)
assert not(W/'actual-0').exists()and not(W/'actual-1').exists();runtime=R/'.scratch/mtp-performance-convergence-20261025/baseline/runtime.json';env=os.environ.copy();env['PATH']=str(exe.parent)+os.pathsep+b.read(runtime)['PATH']
b.save(W/'actual-run-plan.json',dict(status='FROZEN_BEFORE_UNIQUE_CUDA_ROUTER_RUN',command=[str(exe),'--run',str(W)],source=summary['source'],image=summary['image'],inputs=pins,oracle_source=b.pin(W/'prepare-oracle.py'),runtime=b.pin(runtime),source_numeric_aliases=[23,24],shared_graph=True,planned_GPU_processes=1,planned_graph_submissions=2,Phase2_authorized=False))
b.execute([str(exe),'--run',str(W)],W/'run1',env,60)
rows=[json.loads(s)for s in(W/'run1/stdout.log').read_text().splitlines()if s.startswith('{')];assert len(rows)==3 and rows[-1]['status']=='PASS'
b.save(W/'run1/result.json',dict(status='ORIGINAL_PUBLISHER_ROUTER_TWO_INPUTS_PASS',process=b.read(W/'run1/process.json'),rows=rows,image=summary['image'],source=summary['source'],GPU_released=True))
