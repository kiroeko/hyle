$ErrorActionPreference = 'Stop'
$kimiTaskRoot = 'C:\public\project-hyle\hyle'
$kimiPauseMarker = Join-Path $kimiTaskRoot '.scratch/mtp-download-budget-20261023/PAUSED'
$kimiHeldMarker = Join-Path $PSScriptRoot 'download-paused-before-kimi-router'
if ((Resolve-Path -LiteralPath $PSScriptRoot).Path -ne (Join-Path $kimiTaskRoot '.scratch/kimi-publisher-router-20261025')) { throw 'Unexpected Kimi acquisition directory' }
if (!(Test-Path -LiteralPath $kimiPauseMarker -PathType Leaf) -or (Test-Path -LiteralPath $kimiHeldMarker)) { throw 'Expected unchanged pause marker' }
Move-Item -LiteralPath $kimiPauseMarker -Destination $kimiHeldMarker
try {
  & python (Join-Path $kimiTaskRoot '.scratch/mtp-download-budget-20261023/budget.py') run (Join-Path $PSScriptRoot 'fetch-router.py')
  if ($LASTEXITCODE -ne 0) { throw "Planned Kimi router acquisition failed, exit $LASTEXITCODE; partial evidence retained, no retry" }
} finally {
  if ((Test-Path -LiteralPath $kimiPauseMarker) -or !(Test-Path -LiteralPath $kimiHeldMarker -PathType Leaf)) { throw 'Kimi pause marker changed during acquisition' }
  Move-Item -LiteralPath $kimiHeldMarker -Destination $kimiPauseMarker
}
