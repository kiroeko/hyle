from pathlib import Path
from urllib.parse import urlsplit
import hashlib
import json
import zipfile

root = Path.cwd()
folder = Path(__file__).resolve().parent
plan = json.loads((folder / 'phase2-derived-plan.json').read_text())
shapes = json.loads((folder / 'phase2-k512-shapes-only-plan.json').read_text())
pin = lambda p: dict(bytes=p.stat().st_size, sha256=hashlib.sha256(p.read_bytes()).hexdigest())
artifacts = {a['catalog_index']: a for a in plan['artifacts']}
headers = {}
for key, artifact in artifacts.items():
    archive = root / artifact['source_archive']['path']
    assert pin(archive) == {k: artifact['source_archive'][k] for k in ['bytes', 'sha256']}
    with zipfile.ZipFile(archive) as z:
        data = z.read(artifact['header']['entry'])
    assert len(data) == artifact['header']['bytes']
    assert hashlib.sha256(data).hexdigest() == artifact['header']['sha256']
    headers[key] = json.loads(data)
roles = {}
counts = {key: 0 for key in artifacts}
for role in plan['logical_roles']:
    key = role['catalog_index']
    name = role['role']
    src = headers[key][name]
    base = artifacts[key]['header']['data_base']
    assert [role['first'], role['last'] + 1] == [base + v for v in src['data_offsets']]
    assert role['bytes'] == role['last'] - role['first'] + 1
    assert role['dtype'] == src['dtype'] and role['physical_shape'] == src['shape']
    assert role['global_expert'] is None or role['global_expert'] in plan['source_bank_union']
    identity = (key, name)
    assert identity not in roles
    roles[identity] = role
    counts[key] += 1
covered = set()
for req in plan['requests']:
    url = urlsplit(req['url'])
    assert url.scheme == 'https' and url.hostname == 'hf-mirror.net' and not url.username
    assert f"/resolve/{req['revision']}/" in req['url']
    assert 0 <= req['first'] <= req['last'] < req['source_bytes']
    cursor = req['first']
    for role in req['roles']:
        identity = (role['catalog_index'], role['role'])
        assert role == roles[identity] and identity not in covered
        assert role['first'] == cursor
        cursor = role['last'] + 1
        covered.add(identity)
    assert cursor == req['last'] + 1
    assert req['bytes'] == cursor - req['first']
assert covered == set(roles)
assert len(plan['requests']) == 65 and sum(r['bytes'] for r in plan['requests']) == 1090010368
assert len(roles) == 257 and sum(counts.values()) == 257
shape_roles = set()
for req in shapes['requests']:
    cursor = req['first']
    for role in req['roles']:
        identity = (role['catalog_index'], role['role'])
        assert role == roles[identity] and identity not in shape_roles
        assert role['first'] == cursor and role['dtype'] == 'I64' and role['physical_shape'] == [2]
        cursor = role['last'] + 1
        shape_roles.add(identity)
    assert req['bytes'] == cursor - req['first'] and cursor == req['last'] + 1
assert len(shape_roles) == 48 and len(shapes['requests']) == 15
assert sum(r['bytes'] for r in shapes['requests']) == 768
summary = dict(plan=pin(folder / 'phase2-derived-plan.json'),
    shape_plan=pin(folder / 'phase2-k512-shapes-only-plan.json'),
    source_headers_independently_authenticated=True, exact_contiguous_required_byte_coverage=True,
    unrelated_gap_bytes=0, original_selected_expert_count=len(plan['source_bank_union']),
    logical_roles=len(roles), bulk_payload_bytes=1090010368,
    preliminary_I64_shape_bytes=768, preliminary_I64_shape_roles=48,
    scope='Offline range review only; no new download, GPU run, dense numeric reference or full-model claim.')
(folder / 'root-phase2-review.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps(summary, indent=2))
