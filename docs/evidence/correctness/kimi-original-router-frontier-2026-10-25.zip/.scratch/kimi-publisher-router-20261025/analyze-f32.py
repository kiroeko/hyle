from pathlib import Path
import numpy as np,json,hashlib
R=Path.cwd();W=R/'.scratch/kimi-publisher-router-20261025'
def pin(p):return dict(path=p.relative_to(R).as_posix(),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def rounded_bf16_direct(values):
 result=[]
 for x in values:
  sign=0x8000 if np.signbit(x) else 0;v=abs(float(x));approx=int(np.asarray(v,dtype=np.float32).view(np.uint32))>>16;choices=range(max(0,approx-2),min(0x7f7f,approx+2)+1)
  code=min(choices,key=lambda c:(abs(float(np.asarray(c<<16,dtype=np.uint32).view(np.float32))-v),c&1,c));result.append(code|sign)
 return np.asarray(result,dtype=np.uint16)
rows=[]
for epoch in range(2):
 actual=np.frombuffer((W/f'actual-{epoch}/logits.f32').read_bytes(),dtype='<f4');ref=np.frombuffer((W/f'oracle/logits-f64-{epoch}.bin').read_bytes(),dtype='<f8');codes=rounded_bf16_direct(ref);hyp=(codes.astype(np.uint32)<<16).view(np.float32);grid=(actual.view(np.uint32)&0xffff)==0;ae=np.abs(actual.astype(np.float64)-ref);be=np.abs(hyp.astype(np.float64)-ref)
 ids=np.frombuffer((W/f'actual-{epoch}/ids.i32').read_bytes(),dtype='<i4');rows.append(dict(epoch=epoch,actual_logit_pin=pin(W/f'actual-{epoch}/logits.f32'),count=896,finite=int(np.isfinite(actual).sum()),not_on_BF16_grid=int((~grid).sum()),on_BF16_grid=int(grid.sum()),different_from_independent_F64_final_BF16=int(np.count_nonzero(actual!=hyp)),actual_F32_maximum_absolute_error=float(ae.max()),hypothetical_BF16_final_maximum_absolute_error=float(be.max()),actual_IDs=ids.tolist(),F64_final_round_reference_IDs=np.frombuffer((W/f'oracle/final-round-ids-{epoch}.bin').read_bytes(),dtype='<i4').tolist(),first_non_grid_witness=dict(index=int(np.flatnonzero(~grid)[0]),actual_F32=float(actual[~grid][0]),actual_F32_bits=int(actual.view(np.uint32)[~grid][0]),F64_reference=float(ref[~grid][0]),hypothetical_BF16=float(hyp[~grid][0]),BF16_code=int(codes[~grid][0]))))
result=dict(status='ACTUAL_F32_FRONTIER_WITNESS_FROM_RETIRED_RAW_OUTPUTS',rows=rows,total_not_on_BF16_grid=sum(r['not_on_BF16_grid']for r in rows),interpretation='Nonzero low16 F32 mantissa bits are measured evidence that these published logits were not universally narrowed to BF16 then widened. The conservative gamma7167 bound alone cannot establish that fact. This output witness does not certify every internal accumulation algorithm or upstream runtime bitwise equivalence.',independent_BF16_reference='Scalar enumeration of neighboring mathematical BF16 values with nearest/even on the original F64 dot; no product BF16 converter.',GPU_rerun=False)
(W/'f32-frontier-witness.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8');print(json.dumps(result,indent=2))

