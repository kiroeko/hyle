// Authentic publisher router/bias only; generated BF16 hidden input boundary.
#include "engine/inference/artifact_digest.h"
#include "engine/inference/prepared_output.h"
#include "hyle/compute/backends/cuda.h"
#include "hyle/compute/model_ops.h"
#include "hyle/graph/cuda.h"
#include <algorithm>
#include <array>
#include <bit>
#include <cstdint>
#include <memory>
#include <span>
#include <stdexcept>
#include <string>
#include <string_view>
#include <cmath>
#include <cstring>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <numeric>
#include <vector>
namespace c = hyle::compute;
namespace g = hyle::graph;
namespace m = hyle::mem;
namespace inf = hyle::inference;
namespace fs = std::filesystem;
using T = c::DataType;
using V = g::ValueId;
using Bytes = std::vector<std::byte>;
template <class X> X take(hyle::Result<X> r) {
  if (!r)
    throw std::runtime_error(std::string(r.error().message()));
  return std::move(*r);
}
void check(hyle::Status s) {
  if (!s.ok())
    throw std::runtime_error(std::string(s.message()));
}
void require(bool b, const char *message) {
  if (!b)
    throw std::runtime_error(message);
}
c::TensorDesc dense(T t, std::initializer_list<std::int64_t> s) {
  return take(c::TensorDesc::dense(t, {s.begin(), s.size()}));
}
Bytes read(const fs::path &p, std::size_t size) {
  std::ifstream f(p, std::ios::binary | std::ios::ate);
  require(bool(f), "source/reference file missing");
  require(std::size_t(f.tellg()) == size, "exact local extent differs");
  Bytes bytes(size);
  f.seekg(0);
  f.read(reinterpret_cast<char *>(bytes.data()), std::streamsize(size));
  require(bool(f), "local read truncated");
  return bytes;
}
void write(const fs::path &p, std::span<const std::byte> bytes) {
  std::ofstream f(p, std::ios::binary);
  f.write(reinterpret_cast<const char *>(bytes.data()), std::streamsize(bytes.size()));
  require(bool(f), "actual output write failed");
}
template <class X> std::vector<X> values(const Bytes &bytes) {
  require(bytes.size() % sizeof(X) == 0, "typed byte extent");
  std::vector<X> x(bytes.size() / sizeof(X));
  std::memcpy(x.data(), bytes.data(), bytes.size());
  return x;
}
struct Memory {
  std::shared_ptr<c::cuda::MemoryResource> resource;
  m::MemoryResourceRef ref() const noexcept { return resource->ref(); }
};
struct Device {
  c::Context context = take(g::cuda::create_context());
  std::shared_ptr<c::cuda::MemoryResource> memory =
      std::make_shared<c::cuda::MemoryResource>(
          take(c::cuda::MemoryResource::create(context, c::cuda::MemoryKind::kDevice)));
  c::StorageOwner owner = take(c::StorageOwner::adopt(context, Memory{memory}));
  c::Queue queue = take(context.create_queue());
  c::ReadLease upload(c::TensorDesc desc, const Bytes &data) {
    require(take(desc.required_bytes()) == data.size(), "source descriptor extent");
    auto buffer = take(m::Buffer::create(memory->ref(), data.size(), 256));
    check(buffer.view().write(data));
    return take(owner.adopt_buffer(std::move(buffer)));
  }
};
struct Router {
  Device &device;
  g::GraphBuilder b = take(g::GraphBuilder::create());
  std::vector<c::ReadLease> constants;
  std::vector<g::ConstantBinding> bindings;
  V x;
  std::vector<V> outputs;
  g::CompiledGraph compiled;
  V one(c::Operation op, std::initializer_list<V> in) {
    return take(b.result(take(b.add_node(op, {in.begin(), in.size()}))));
  }
  template <class Op> V one(Op op, std::initializer_list<V> in) {
    return one(c::Operation(op), in);
  }
  V constant(c::TensorDesc desc, const Bytes &data) {
    auto v = take(b.constant(desc));
    constants.push_back(device.upload(desc, data));
    bindings.push_back({v, take(constants.back().tensor(desc)),
                        g::ConstantPolicy::kBorrow, device.owner, constants.back()});
    return v;
  }
  Router(Device &d, const Bytes &weight, const Bytes &bias) : device(d) {
    x = take(b.input(dense(T::kBFloat16, {1, 7168})));
    auto w = constant(dense(T::kBFloat16, {896, 7168}), weight),
         offset = constant(dense(T::kFloat32, {896}), bias);
    auto logits = one(c::model_ops::dense_linear_f32(), {x, w});
    auto probabilities = one(c::Unary{c::UnaryKind::kSigmoid}, {logits});
    auto corrected = one(c::Binary{c::BinaryKind::kAdd}, {probabilities, offset});
    auto top =
        take(b.add_node(c::Operation(c::TopK{.count = 16}), std::span(&corrected, 1)));
    auto ids = take(b.result(top, 1));
    auto selected =
        one(c::model_ops::gather_elements(-1, c::IndexBoundsPolicy::kUnchecked),
            {probabilities, ids});
    auto sum =
        one(c::Reduce{.kind = c::ReductionKind::kSum,
                      .axes = take(c::Axes::from(std::array<std::int32_t, 1>{1})),
                      .keep_dimensions = true,
                      .accumulation_type = T::kFloat32},
            {selected});
    auto weights = one(c::Binary{c::BinaryKind::kDivide}, {selected, sum});
    outputs = {logits, probabilities, corrected, ids, selected, weights};
    for (auto v : outputs)
      check(b.publish(v));
    auto graph = take(std::move(b).finish());
    compiled = take(
        g::cuda::compile(graph, device.context, device.owner, {.constants = bindings}));
  }
};
struct Episode {
  g::Invocation invocation;
  std::vector<c::LeasePool> pools;
  std::vector<c::ReadLease> outputs;
  std::vector<Bytes> saved;
};
Episode evaluate(Device &device, const Router &r, const c::ReadLease &input) {
  Episode e;
  e.invocation = take(r.compiled.executable.create_invocation());
  check(e.invocation.prepare_resources());
  check(e.invocation.bind(r.x, dense(T::kBFloat16, {1, 7168}), input));
  std::vector<inf::PreparedOutputFacts> facts;
  for (auto v : r.outputs) {
    auto f = take(inf::prepare_output(r.compiled, v));
    facts.push_back(f);
    if (f.caller_owned()) {
      auto size = take(f.description.required_bytes());
      e.pools.push_back(
          take(c::LeasePool::create(device.memory->ref(), size, {.max_blocks = 1})));
      check(e.invocation.bind(v, f.description, take(e.pools.back().allocate(size))));
    }
  }
  const std::array queues{g::QueueBinding{g::ExecutionLaneId{0}, &device.queue}};
  check(e.invocation.prepare_replay(queues, {.mode = g::ReplayMode::kCommands,
                                             .host_wait = g::HostWaitPolicy::kAllow}));
  {
    auto done = take(e.invocation.submit(queues));
    check(done.wait());
  }
  for (auto f : facts) {
    auto output = take(inf::retain_output(e.invocation, f));
    Bytes raw(output.size());
    check(take(output.view()).read(raw));
    e.saved.push_back(std::move(raw));
    e.outputs.push_back(std::move(output));
  }
  return e;
}
float f32(double x) {
  volatile float f = static_cast<float>(x);
  return f;
}
float sigmoid(float x) {
  if (x >= 0)
    return f32(1. / (1. + std::exp(-double(x))));
  const auto e = std::exp(double(x));
  return f32(e / (1. + e));
}
void verify(const Episode &e, std::span<const float> bias, const fs::path &base,
            unsigned epoch) {
  auto directory = base / ("actual-" + std::to_string(epoch));
  require(fs::create_directory(directory), "refusing to overwrite prior actual outputs");
  constexpr std::array names{"logits.f32", "probabilities.f32", "corrected.f32",
                             "ids.i32",    "selected.f32",      "weights.f32"};
  for (std::size_t j = 0; j < names.size(); ++j)
    write(directory / names[j], e.saved[j]);
  const auto logits = values<float>(e.saved[0]), prob = values<float>(e.saved[1]),
             scores = values<float>(e.saved[2]), selected = values<float>(e.saved[4]),
             weights = values<float>(e.saved[5]);
  const auto ids = values<std::int32_t>(e.saved[3]);
  const auto reference = values<double>(read(
      base / "oracle" / ("logits-f64-" + std::to_string(epoch) + ".bin"), 896 * 8));
  const auto bound = values<double>(
      read(base / "oracle" / ("bound-f64-" + std::to_string(epoch) + ".bin"), 896 * 8));
  double max_logit = 0, max_ratio = 0, max_sigmoid = 0, max_weight = 0;
  for (std::size_t j = 0; j < 896; ++j) {
    require(std::isfinite(logits[j]), "nonfinite source logit");
    auto error = std::abs(double(logits[j]) - reference[j]);
    max_logit = std::max(max_logit, error);
    max_ratio = std::max(max_ratio, error / bound[j]);
    require(error <= bound[j],
            "original BF16 dot outside independent predeclared F32 accumulation bound");
    const auto expected = sigmoid(logits[j]);
    const auto pe = std::abs(double(prob[j]) - expected);
    max_sigmoid = std::max(max_sigmoid, pe);
    require(pe <= 2.e-7, "sigmoid outside independent F32 oracle interval");
    require(std::bit_cast<std::uint32_t>(scores[j]) ==
                std::bit_cast<std::uint32_t>(f32(double(prob[j]) + bias[j])),
            "router correction must be exact F32 add");
  }
  std::vector<std::int32_t> expected(896);
  std::iota(expected.begin(), expected.end(), 0);
  std::stable_sort(expected.begin(), expected.end(), [&](auto a, auto b) {
    return scores[std::size_t(a)] > scores[std::size_t(b)];
  });
  expected.resize(16);
  require(ids == expected,
          "actual Top16 is not independent sorted corrected score order");
  double sum = 0;
  for (std::size_t j = 0; j < 16; ++j) {
    require(std::bit_cast<std::uint32_t>(selected[j]) ==
                std::bit_cast<std::uint32_t>(prob[std::size_t(ids[j])]),
            "gathered uncorrected sigmoid probability changed");
    sum += prob[std::size_t(ids[j])];
  }
  require(sum > 0 && std::isfinite(sum), "router normalization denominator invalid");
  for (std::size_t j = 0; j < 16; ++j) {
    auto error = std::abs(double(weights[j]) - f32(double(selected[j]) / f32(sum)));
    max_weight = std::max(max_weight, error);
    require(error <= 2.e-7, "normalized source route weight differs");
  }
  std::cout
      << "{\"epoch\":" << epoch
      << ",\"status\":\"PASS_AUTHENTIC_ROUTER\",\"source_catalogs\":[23,24],\"input_generated\":true,\"GPU_graph_submissions\":1,\"checked_logits\":896,\"checked_sigmoid\":896,\"checked_corrected\":896,\"checked_IDs\":16,\"checked_selected_probabilities\":16,\"checked_weights\":16,\"maximum_logit_absolute_error\":"
      << max_logit << ",\"maximum_fraction_of_predeclared_dot_bound\":" << max_ratio
      << ",\"maximum_sigmoid_absolute_error\":" << max_sigmoid
      << ",\"maximum_normalized_weight_error\":" << max_weight << ",\"actual_IDs\":[";
  for (std::size_t j = 0; j < ids.size(); ++j) {
    if (j)
      std::cout << ',';
    std::cout << ids[j];
  }
  std::cout << "]}\n";
}
int main(int argc, char **argv) {
  try {
    require(argc == 3 && std::string_view(argv[1]) == "--run",
            "usage: router --run fixed-private-directory");
    fs::path base = argv[2];
    auto w = read(base / "payload/catalog-23-router.bf16", 12845056),
         biasraw = read(base / "payload/catalog-23-bias.f32", 3584);
    require(
        inf::artifact::sha256(w) ==
                "25ebb27dfe797648f0d815f433fb2cf36f5617987bc2208e01d071588e79a957" &&
            inf::artifact::sha256(biasraw) ==
                "853727cc546c18e82efe23f124519049f001feb3d429123876ba8ec5484e5a1d",
        "actual source SHA changed");
    require(w == read(base / "payload/catalog-24-router.bf16", 12845056) &&
                biasraw == read(base / "payload/catalog-24-bias.f32", 3584),
            "catalog numerical aliases changed");
    Device device;
    Router r(device, w, biasraw);
    std::array<Episode, 2> episodes;
    std::array<c::ReadLease, 2> inputs;
    for (unsigned epoch = 0; epoch < 2; ++epoch) {
      auto x = read(base / "oracle" / ("input-" + std::to_string(epoch) + ".bf16"),
                    7168 * 2);
      inputs[epoch] = device.upload(dense(T::kBFloat16, {1, 7168}), x);
      episodes[epoch] = evaluate(device, r, inputs[epoch]);
      verify(episodes[epoch], values<float>(biasraw), base, epoch);
    }
    for (std::size_t j = 0; j < episodes[0].outputs.size(); ++j) {
      Bytes b(episodes[0].outputs[j].size());
      check(take(episodes[0].outputs[j].view()).read(b));
      require(b == episodes[0].saved[j],
              "old immutable router output changed after second input");
    }
    std::cout
        << "{\"status\":\"PASS\",\"catalog_numeric_roles_identical\":true,\"GPU_graph_submissions\":2,\"old_reader_unchanged\":true,\"expert_payloads_acquired\":0,\"full_model\":false}\n";
    return 0;
  } catch (const std::exception &e) {
    std::cerr << "Original Kimi router: " << e.what() << '\n';
    return 1;
  }
}
