#include <gtest/gtest.h>
#include <algorithm>
#include <array>
#include <cmath>
#include <span>
#include <vector>
#include "hyle/compute/cpu.h"
#include "hyle/compute/prepared_operation.h"
#include "hyle/mem/buffer.h"
#include "hyle/compute/low_precision.h"
#include "hyle/graph/cpu.h"
#include <ggml.h>

TEST(MixedCpuDelivery, OrdinaryCpuMathRemainsIndependentOfCuda) {
  namespace c=hyle::compute;namespace m=hyle::mem;
  auto context=c::cpu::create_context().value();
  auto desc=[](std::int64_t rows,std::int64_t columns) {
    return c::TensorDesc::dense(c::DataType::kFloat32,std::array{rows,columns}).value();
  };
  const auto a_desc=desc(2,17),b_desc=desc(17,3),o_desc=desc(2,3);
  auto alloc=[](const c::TensorDesc &d) {
    return m::Buffer::create(m::system_resource(),d.required_bytes().value(),64).value();
  };
  auto a=alloc(a_desc),b=alloc(b_desc),o=alloc(o_desc);
  const std::array input{c::ConstTensorView::create(a_desc,a.view()).value(),
                         c::ConstTensorView::create(b_desc,b.view()).value()};
  auto output=c::TensorView::create(o_desc,o.view()).value();
  auto prepared=c::prepare(context,c::Operation(c::MatMul{}),input,std::span(&output,1));
  ASSERT_TRUE(prepared) << prepared.error().message();
  const auto requirement=prepared->workspace_requirement();
  m::Buffer workspace;
  if(requirement.size)
    workspace=m::Buffer::create(m::system_resource(),requirement.size,requirement.alignment).value();
  auto created=prepared->create_invocation(workspace.view());
  ASSERT_TRUE(created) << created.error().message();
  auto invocation=std::move(*created);
  auto queue=context.create_queue().value();
  std::vector<float> left(34),right(51);std::array<float,6> actual{};
  for(std::size_t i=0;i<right.size();++i)right[i]=float(int(i%7)-3)*0.125F;
  ASSERT_TRUE(b.view().write(std::as_bytes(std::span(right))).ok());
  for(int pass:{1,3}) {
    for(std::size_t i=0;i<left.size();++i)left[i]=float((int(i)+pass)%11-5)*0.0625F;
    ASSERT_TRUE(a.view().write(std::as_bytes(std::span(left))).ok());
    auto done=invocation.submit(queue,input,std::span(&output,1));
    ASSERT_TRUE(done) << done.error().message();ASSERT_TRUE(done->wait().ok());
    ASSERT_TRUE(o.view().read(std::as_writable_bytes(std::span(actual))).ok());
    for(int row=0;row<2;++row)for(int col=0;col<3;++col) {
      double expected=0;for(int k=0;k<17;++k)expected+=double(left[row*17+k])*right[k*3+col];
      EXPECT_NEAR(actual[row*3+col],expected,1.0e-5);
    }
  }
  ASSERT_TRUE(context.close().ok());
}

TEST(MixedCpuDelivery, OriginalCpuQ8CodecSurvivesSharedCudaCore) {
  namespace c=hyle::compute;namespace m=hyle::mem;
  const auto lhs=c::TensorDesc::dense(c::DataType::kFloat32,std::array<std::int64_t,2>{1,32}).value();
  const auto rhs=c::gguf_weight_description(c::GgufQuantizedType::kQ8_0,c::DataType::kFloat32,32,2).value();
  const auto out=c::TensorDesc::dense(c::DataType::kFloat32,std::array<std::int64_t,2>{1,2}).value();
  std::array<float,64> weights{};std::fill_n(weights.begin(),32,1.F);std::fill_n(weights.begin()+32,32,-2.F);
  std::vector<std::byte> packed(rhs.required_bytes().value());
  ASSERT_EQ(ggml_quantize_chunk(GGML_TYPE_Q8_0,weights.data(),packed.data(),0,2,32,nullptr),packed.size());
  auto a=m::Buffer::create(m::system_resource(),128,64).value();
  auto b=m::Buffer::create(m::system_resource(),packed.size(),64).value();
  auto o=m::Buffer::create(m::system_resource(),8,64).value();
  ASSERT_TRUE(b.view().write(packed).ok());
  const std::array input{c::ConstTensorView::create(lhs,a.view()).value(),c::ConstTensorView::create(rhs,b.view()).value()};
  auto output=c::TensorView::create(out,o.view()).value();
  auto context=c::cpu::create_context().value();
  auto program=c::prepare(context,c::Operation(c::MatMul{}),input,std::span(&output,1)).value();
  auto invocation=program.create_invocation().value();auto queue=context.create_queue().value();
  for(float value:{0.25F,0.5F}) {
    std::array<float,32> activation{};activation.fill(value);
    ASSERT_TRUE(a.view().write(std::as_bytes(std::span(activation))).ok());
    auto done=invocation.submit(queue,input,std::span(&output,1));ASSERT_TRUE(done);ASSERT_TRUE(done->wait().ok());
    std::array<float,2> actual{};ASSERT_TRUE(o.view().read(std::as_writable_bytes(std::span(actual))).ok());
    EXPECT_NEAR(actual[0],32.F*value,0.1F);EXPECT_NEAR(actual[1],-64.F*value,0.1F);
  }
}

TEST(MixedCpuDelivery, OrdinaryCpuGraphReplaysInMixedSdk) {
  namespace c=hyle::compute;namespace g=hyle::graph;namespace m=hyle::mem;
  auto matrix=[](std::int64_t r,std::int64_t n) {
    return c::TensorDesc::dense(c::DataType::kFloat32,std::array{r,n}).value();
  };
  const auto ad=matrix(1,17),bd=matrix(17,3),od=matrix(1,3);
  auto builder=g::GraphBuilder::create().value();
  const auto ai=builder.input(ad).value(),bi=builder.input(bd).value();
  const auto result=builder.add(c::MatMul{},ai,bi).value();ASSERT_TRUE(builder.publish(result).ok());
  auto logical=std::move(builder).finish().value();auto context=g::cpu::create_context().value();
  auto compiled=g::compile(logical,context);ASSERT_TRUE(compiled) << compiled.error().message();
  auto invocation=compiled->executable.create_invocation().value();auto queue=context.create_queue().value();
  auto allocate=[](const c::TensorDesc &d) {
    return m::Buffer::create(m::system_resource(),d.required_bytes().value(),64).value();
  };
  auto a=allocate(ad),b=allocate(bd),o=allocate(od);
  ASSERT_TRUE(invocation.bind(ai,c::ConstTensorView::create(ad,a.view()).value()).ok());
  ASSERT_TRUE(invocation.bind(bi,c::ConstTensorView::create(bd,b.view()).value()).ok());
  ASSERT_TRUE(invocation.bind(result,c::TensorView::create(od,o.view()).value()).ok());
  std::array<float,51> weights{};weights.fill(0.125F);
  ASSERT_TRUE(b.view().write(std::as_bytes(std::span(weights))).ok());
  const std::array lanes{g::QueueBinding{.lane=g::ExecutionLaneId{0},.queue=&queue}};
  ASSERT_TRUE(invocation.prepare_replay(lanes).ok());
  for(float value:{0.25F,0.5F}) {
    std::array<float,17> activation{};activation.fill(value);
    ASSERT_TRUE(a.view().write(std::as_bytes(std::span(activation))).ok());
    auto done=invocation.submit(queue);ASSERT_TRUE(done) << done.error().message();ASSERT_TRUE(done->wait().ok());
    std::array<float,3> actual{};ASSERT_TRUE(o.view().read(std::as_writable_bytes(std::span(actual))).ok());
    for(float output:actual)EXPECT_NEAR(output,17.F*value*0.125F,1.0e-5);
  }
}
