from pathlib import Path
R=Path.cwd();P=R/'engine/models/qwen35/main.cc';s=P.read_text()
def sub(a,b,count=1):
 global s
 assert s.count(a)==count,(a[:130],s.count(a),count)
 s=s.replace(a,b)
sub('struct GenerationBoundary final {','enum class TextCompletion { kEmitNext, kStateOnly };\n\nstruct GenerationBoundary final {')
sub('  bool imported = false;','  bool imported = false, prefill_complete = true;\n  TextCompletion completion = TextCompletion::kEmitNext;\n  std::size_t input_begin = 0;')
sub('        role == other.role && generation == other.generation && quota == other.quota &&','        role == other.role && generation == other.generation && quota == other.quota &&\n        completion == other.completion && prefill_complete == other.prefill_complete && input_begin == other.input_begin &&')
sub('  GraphRole role;\n  FamilyKey','  GraphRole role;\n  TextCompletion completion;\n  FamilyKey')
sub('            std::size_t rows = 0) noexcept\n      : requests(count), verification_rows(selected == GraphRole::kVerify ? rows : 0), role(selected) {}\n  static FamilyKey exact(std::size_t count, GraphRole selected, std::size_t rows) noexcept {\n    FamilyKey key(count, selected);',
'''            std::size_t rows = 0, TextCompletion mode = TextCompletion::kEmitNext) noexcept
      : requests(count), verification_rows(selected == GraphRole::kVerify ? rows : 0), role(selected), completion(mode) {}
  static FamilyKey exact(std::size_t count, GraphRole selected, std::size_t rows,
                         TextCompletion mode = TextCompletion::kEmitNext) noexcept {
    FamilyKey key(count, selected, 0, mode);''')
sub('  GraphRole role = GraphRole::kText;\n  auto operator<=>(const ExecutionShape','  GraphRole role = GraphRole::kText;\n  TextCompletion completion = TextCompletion::kEmitNext;\n  auto operator<=>(const ExecutionShape')
sub('  GraphRole role = GraphRole::kText;\n  bool admitted_exact','  GraphRole role = GraphRole::kText;\n  TextCompletion completion = TextCompletion::kEmitNext;\n  bool admitted_exact')
sub('bool admitted_exact = false) {\n    preparation_started_', '''bool admitted_exact = false, TextCompletion completion = TextCompletion::kEmitNext) {
    if ((completion != TextCompletion::kEmitNext && completion != TextCompletion::kStateOnly) ||
        (completion == TextCompletion::kStateOnly && role != GraphRole::kText))
      throw std::runtime_error("state-only completion requires an ordinary Text family");
    preparation_started_''')
sub('FamilyKey::exact(requests, role, planned_chunks.front()) : FamilyKey(requests, role, prefix_rows)','FamilyKey::exact(requests, role, planned_chunks.front(), completion) : FamilyKey(requests, role, prefix_rows, completion)')
sub('definition.requests = requests; definition.role = role; definition.prefix_rows = prefix_rows;','definition.requests = requests; definition.role = role; definition.prefix_rows = prefix_rows; definition.completion = completion;')
sub('    if (sampler.enabled && role != GraphRole::kVerify) definition.sampling_identity_port', '    if (sampler.enabled && completion == TextCompletion::kEmitNext && role != GraphRole::kVerify) definition.sampling_identity_port')
start=s.index('    definition.logits_port = r.scores(last,');end=s.index('    definition.graph = take(std::move(r.builder).finish());',start)
block=s[start:end];assert block.endswith('    for (auto value : {definition.hidden_port, definition.logits_port, definition.id_port}) r.publish(value);\n')
block=block[:block.rindex('    for (auto value')]
s=s[:start]+'    if (completion == TextCompletion::kEmitNext) {\n'+''.join('  '+line+'\n' for line in block.splitlines())+'      r.publish(definition.logits_port); r.publish(definition.id_port);\n    }\n    r.publish(definition.hidden_port);\n'+s[end:]
sub('bool diagnostic = false) {\n    auto &table', 'bool diagnostic = false, TextCompletion completion = TextCompletion::kEmitNext) {\n    auto &table')
sub('const auto primary = table.find({requests, role, tokens});','const auto primary = table.find({requests, role, tokens, completion});')
sub('const auto exact = table.find(FamilyKey::exact(requests, role, tokens));','const auto exact = table.find(FamilyKey::exact(requests, role, tokens, completion));')
sub('  void admit_exact_shape(std::size_t tokens, std::size_t requests, GraphRole role) {\n    if (find_family(requests, tokens, role)) return;', '  void admit_exact_shape(std::size_t tokens, std::size_t requests, GraphRole role,\n                         TextCompletion completion = TextCompletion::kEmitNext) {\n    if (find_family(requests, tokens, role, false, completion)) return;')
sub('const ExecutionShape shape{victim.requests, old->second->chunks[0], victim.role};','const ExecutionShape shape{victim.requests, old->second->chunks[0], victim.role, victim.completion};')
sub('const auto key = FamilyKey::exact(requests, role, tokens);','const auto key = FamilyKey::exact(requests, role, tokens, completion);')
sub('prepare_family(chunk, false, requests, role, true);','prepare_family(chunk, false, requests, role, true, completion);')
sub('planned_slot_uses[{requests, tokens, role}].fill(1);','planned_slot_uses[{requests, tokens, role, completion}].fill(1);')
sub('GraphRole role = GraphRole::kText) {\n    if (!phases.empty()', 'GraphRole role = GraphRole::kText, TextCompletion completion = TextCompletion::kEmitNext) {\n    if (!phases.empty()',2)
sub('families.contains({requests, role, tokens})','families.contains({requests, role, tokens, completion})',2)
sub('families.at({requests, role, tokens})','families.at({requests, role, tokens, completion})',6)
sub('auto &uses = planned_slot_uses[{requests, tokens, role}];','auto &uses = planned_slot_uses[{requests, tokens, role, completion}];')
sub('planned_slot_uses[{requests, tokens, role}])','planned_slot_uses[{requests, tokens, role, completion}])')
sub('bool resample_frontier = false) {','bool resample_frontier = false,\n                                         TextCompletion completion = TextCompletion::kEmitNext) {')
sub('if (!find_family(1, rows, role)) admit_exact_shape(rows, 1, role);','if (!find_family(1, rows, role, false, completion)) admit_exact_shape(rows, 1, role, completion);')
sub('families.contains({1, role}) : !find_family(1, initial_rows, role)','families.contains({1, role, 0, completion}) : !find_family(1, initial_rows, role, false, completion)')
sub('probe_families.contains({1, role, initial_rows})','probe_families.contains({1, role, initial_rows, completion})')
sub('{find_family(1, tokens, role), layer0_probe.empty() ? nullptr : probe_families.at({1, role, tokens}).get()}','{find_family(1, tokens, role, false, completion), layer0_probe.empty() ? nullptr : probe_families.at({1, role, tokens, completion}).get()}')
sub('planned_slot_uses.contains({1, tokens, role})','planned_slot_uses.contains({1, tokens, role, completion})')
sub('    if (sampler.enabled && definition.role != GraphRole::kVerify) {','    if (sampler.enabled && definition.completion == TextCompletion::kEmitNext && definition.role != GraphRole::kVerify) {')
sub('    check(phase.next_id.bind(run));','    if (definition.completion == TextCompletion::kEmitNext) check(phase.next_id.bind(run));')
sub('  Phase &prepare_child(std::size_t tokens, bool diagnostic, std::size_t requests = 1, GraphRole role = GraphRole::kText) {','  Phase &prepare_child(std::size_t tokens, bool diagnostic, std::size_t requests = 1, GraphRole role = GraphRole::kText,\n                       TextCompletion completion = TextCompletion::kEmitNext) {')
sub('cache.find({requests, tokens, role});','cache.find({requests, tokens, role, completion});')
sub('find_family(requests, tokens, role, diagnostic);','find_family(requests, tokens, role, diagnostic, completion);')
sub('planned_slot_uses.at({requests, tokens, role});','planned_slot_uses.at({requests, tokens, role, completion});')
sub('    if (sampler.enabled && role != GraphRole::kVerify) {','    if (sampler.enabled && completion == TextCompletion::kEmitNext && role != GraphRole::kVerify) {',2)
sub('    phase.logits_facts = &phase.child->output(phase.logits_port);\n    phase.logits = Tensor(take(execution.resource_for(phase.logits_facts->storage)),\n        phase.logits_facts->description, phase.logits_facts->caller_owned());\n    phase.next_id = take(PreparedReadback::prepare(phase.child->compiled, phase.id_port, execution));','''    if (completion == TextCompletion::kEmitNext) {
      phase.logits_facts = &phase.child->output(phase.logits_port);
      phase.logits = Tensor(take(execution.resource_for(phase.logits_facts->storage)),
          phase.logits_facts->description, phase.logits_facts->caller_owned());
      phase.next_id = take(PreparedReadback::prepare(phase.child->compiled, phase.id_port, execution));
    }''')
sub('cache.emplace(ExecutionShape{requests, tokens, role},','cache.emplace(ExecutionShape{requests, tokens, role, completion},')
sub('std::size_t requests = 1, GraphRole role = GraphRole::kText) {','std::size_t requests = 1, GraphRole role = GraphRole::kText,\n                          TextCompletion completion = TextCompletion::kEmitNext) {')
# prepare_execution and actual evaluation resolve the same semantic carrier key.
sub('prepare_child(tokens, false, requests, role);','prepare_child(tokens, false, requests, role, completion);')
sub('prepare_child(tokens, !layer0_probe.empty(), requests, role);','prepare_child(tokens, !layer0_probe.empty(), requests, role, completion);')
sub('GraphRole role = GraphRole::kText) {\n    if (requests.empty()', '''GraphRole role = GraphRole::kText,
                           TextCompletion completion = TextCompletion::kEmitNext) {
    if ((completion != TextCompletion::kEmitNext && completion != TextCompletion::kStateOnly) ||
        (completion == TextCompletion::kStateOnly && role != GraphRole::kText))
      throw std::runtime_error("state-only evaluation requires ordinary Text");
    if (requests.empty()''')
sub('!find_family(requests.size(), tokens, role))\n      admit_exact_shape(tokens, requests.size(), role);','!find_family(requests.size(), tokens, role, false, completion))\n      admit_exact_shape(tokens, requests.size(), role, completion);')
sub('prepare_child(tokens, false, width, role);','prepare_child(tokens, false, width, role, completion);')
sub('prepare_child(tokens, !layer0_probe.empty(), width, role);','prepare_child(tokens, !layer0_probe.empty(), width, role, completion);')
sub('member.next->sampling = sampler.enabled && role != GraphRole::kVerify ?', 'member.next->sampling = sampler.enabled && completion == TextCompletion::kEmitNext && role != GraphRole::kVerify ?')
sub('GraphRole role = GraphRole::kText) {\n    const std::array requests', 'GraphRole role = GraphRole::kText, TextCompletion completion = TextCompletion::kEmitNext) {\n    const std::array requests')
sub('prepare_evaluations(requests, preparation, role);','prepare_evaluations(requests, preparation, role, completion);')
sub('    const auto tokens = step.input_tokens;\n    const auto submit_seconds','    const auto tokens = step.input_tokens;\n    const bool state_only = phase.family->completion == TextCompletion::kStateOnly;\n    const auto submit_seconds')
sub('if (record.role != phase.family->role || record.before', 'if (record.role != phase.family->role || record.completion != phase.family->completion || record.before')
sub('if (!phase.logits.buffer) generated_logits', 'if (!state_only && !phase.logits.buffer) generated_logits')
sub('if (sampler.enabled && phase.family->role != GraphRole::kVerify) {','if (sampler.enabled && !state_only && phase.family->role != GraphRole::kVerify) {')
sub('      } else {\n        check(phase.next_id.read(execution, run, std::as_writable_bytes(next_ids)));','''      } else if (state_only) {
        std::ranges::fill(next_ids, -1);
        select(std::span<const std::int32_t>(next_ids), step, next_ids);
      } else {
        check(phase.next_id.read(execution, run, std::as_writable_bytes(next_ids)));''')
sub('            next_ids[j] < 0 || next_ids[j] >= vocabulary)', '            (!state_only && (next_ids[j] < 0 || next_ids[j] >= vocabulary)))')
sub('          record->stopped = is_end_of_generation(next_ids[j]);\n          record->emitted = {next_ids[j], -1}; record->emitted_count = 1;', '''          record->stopped = !state_only && is_end_of_generation(next_ids[j]);
          if (state_only) { record->emitted.clear(); record->emitted_count = 0; }
          else { record->emitted = {next_ids[j], -1}; record->emitted_count = 1; }''')
sub('        completed.logits = phase.logits.buffer ? phase.logits.view().as_const()\n            : take(generated_logits.tensor(phase.logits.description));','        if (!state_only) completed.logits = phase.logits.buffer ? phase.logits.view().as_const()\n            : take(generated_logits.tensor(phase.logits.description));')
sub('    dump_row(completed.logits, "logits.f32");','    if (completed.logits.valid()) dump_row(completed.logits, "logits.f32");')
P.write_bytes(s.replace('\n','\r\n').encode())
print('core edits applied')
