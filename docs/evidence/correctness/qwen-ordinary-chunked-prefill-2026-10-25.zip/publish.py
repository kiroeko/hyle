from pathlib import Path
import copy,difflib,hashlib,json,zipfile
R=Path.cwd();W=R/'.scratch/inference-chunked-prefill-20261025';D=R/'docs/evidence/correctness';J=D/'qwen-ordinary-chunked-prefill-2026-10-25.json';Z=J.with_suffix('.zip')
assert not J.exists()and not Z.exists()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def record(p):return dict(path=p.relative_to(R).as_posix(),bytes=p.stat().st_size,sha256=sha(p))
summary=json.loads((W/'proof-summary.json').read_bytes());assert summary['result']['status']=='PASS'
compiled=W/'actual-main.cc';canonical=R/'engine/models/qwen35/main.cc'
assert sha(compiled)==next(v['sha256']for v in summary['actual_source_files']if Path(v['path']).resolve()==canonical)
old=compiled.read_text();new=canonical.read_text()
def without_publisher(s):
 a=s.index('void publish_generation_prompt(');b=s.index('void publish_generation_completed(',a);return s[:a]+s[b:]
assert without_publisher(old)==without_publisher(new)
assert old!=new
(W/'publisher-source-bridge.patch').write_text(''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='actual/engine/models/qwen35/main.cc',tofile='final/engine/models/qwen35/main.cc')))
bridge=dict(actual_source=record(compiled),final_source=record(canonical),patch=record(W/'publisher-source-bridge.patch'),all_bytes_outside_publish_generation_prompt_exact=True,reason='One forward ledger scan replaces repeated find for each chunk; preserves actual input partition/mode and complete final boundary.',actual_GPU_coverage='The original case executes publish_generation_completed and full PrefixDirectory reuse, but not publish_generation_prompt.',final_validation='Combined canonical driver /W4 /WX /Zs only; no additional GPU run.')
(W/'publisher-source-bridge.json').write_text(json.dumps(bridge,indent=2)+'\n')
base=(W/'implementation-base-main.cc').read_text();(W/'source.patch').write_text(''.join(difflib.unified_diff(base.splitlines(True),new.splitlines(True),fromfile='before/engine/models/qwen35/main.cc',tofile='after/engine/models/qwen35/main.cc')))
final_pins=json.loads((W/'final-syntax2/source-pins.json').read_bytes())
for p in final_pins:assert sha(Path(p['path']))==p['sha256']
summary['final_source_pins']=final_pins;summary['publisher_source_bridge']=bridge
summary['final_canonical_syntax']=json.loads((W/'final-syntax2/process.json').read_bytes())
summary['precompiler_preparation_failures']=json.loads((W/'preparation-failures.json').read_bytes())
summary['closure_scope']='Original reviewed BF16 CUDA schedule-inputs public/native closure reused; only actual consumer TUs and final canonical syntax refreshed. Not a blanket current quant-provider/SDK certification.'
summary['archive_boundaries']='No executable/object/DLL/library/SDK/weight payload. Input manifest and original prompt IDs are retained; they reference existing original source ranges.'
files={}
with zipfile.ZipFile(W/'proof.zip')as src:
 assert src.testzip()is None
 for n in src.namelist():
  if n!='archive-inventory.json':files[n]=src.read(n)
 files['initial-private-archive-inventory.json']=src.read('archive-inventory.json')
for p in [W/'publisher-source-bridge.patch',W/'publisher-source-bridge.json',W/'preparation-failures.json',W/'source.patch',W/'syntax.py',W/'publish.py',W/'final-syntax2-before.json']:
 files[p.relative_to(W).as_posix()]=p.read_bytes()
for folder in ('final-syntax','final-syntax2'):
 for p in (W/folder).rglob('*'):
  if p.is_file()and p.suffix in('.json','.log'):files[p.relative_to(W).as_posix()]=p.read_bytes()
files['final-source/engine/models/qwen35/main.cc']=canonical.read_bytes()
files['final-source/engine/models/qwen35/prefix_cache.h']=(R/'engine/models/qwen35/prefix_cache.h').read_bytes()
with zipfile.ZipFile(Z,'w',zipfile.ZIP_DEFLATED)as dst:
 for name,b in sorted(files.items()):dst.writestr(name,b)
 dst.writestr('archive-inventory.json',json.dumps([dict(path=n,bytes=len(b),sha256=hashlib.sha256(b).hexdigest())for n,b in sorted(files.items())],indent=2)+'\n')
with zipfile.ZipFile(Z)as dst:
 assert dst.testzip()is None
 assert not any(Path(n).suffix.lower()in('.exe','.obj','.exp','.lib','.dll','.pdb')for n in dst.namelist())
 for v in json.loads(dst.read('archive-inventory.json')):
  b=dst.read(v['path']);assert len(b)==v['bytes']and hashlib.sha256(b).hexdigest()==v['sha256']
 count=len(dst.namelist())
summary['archive']=record(Z);summary['archive_verification']=dict(members=count,CRC_and_all_SHA='PASS',binaries=False,SDK=False,weight_payload=False)
J.write_text(json.dumps(summary,indent=2)+'\n')
(W/'final-proof-summary.json').write_bytes(J.read_bytes())
publication=dict(summary=record(J),archive=record(Z),members=count,CRC_and_all_SHA='PASS',cleanup=summary['cleanup'],retained_success=summary['retained_success'])
(W/'public-publication.json').write_text(json.dumps(publication,indent=2)+'\n');print(json.dumps({k:v for k,v in publication.items()if k not in('cleanup','retained_success')},indent=2))
