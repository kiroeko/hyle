from pathlib import Path
P=Path('engine/models/qwen35/main.cc');s=P.read_text()
def sub(a,b,count=1):
 global s
 assert s.count(a)==count,(a[:120],s.count(a),count)
 s=s.replace(a,b)
sub('  std::size_t last_idle = 0;','  std::size_t last_idle = 0;\n  std::size_t input_turn = SIZE_MAX, turn_input_consumed = 0;')
sub('GenerationCommitRecord &prepare_generation_record(','''// Cold episode count; imported source chunks have their own explicit bound.
std::size_t generation_record_capacity(std::span<const inference::GenerationTurn> turns,
    std::size_t max_prefill_rows = SIZE_MAX, std::size_t imported_records = 0) {
  if (!max_prefill_rows) throw std::runtime_error("prefill quantum must be positive");
  auto count = imported_records;
  for (std::size_t turn = 0; turn < turns.size(); ++turn) {
    const auto rows = cache::add(turns[turn].prompt.size(), turn ? 1u : 0u);
    if (!rows || !turns[turn].max_outputs) throw std::runtime_error("generation requires nonempty turn input and positive quota");
    const auto chunks = rows / max_prefill_rows + (rows % max_prefill_rows != 0);
    count = cache::add(count, cache::add(chunks, turns[turn].max_outputs - 1));
  }
  return count;
}

GenerationCommitRecord &prepare_generation_record(''')
sub('std::size_t quota, std::size_t turn, std::shared_ptr<const void> owner = {}, std::size_t maximum = 0) {','''std::size_t quota, std::size_t turn, std::shared_ptr<const void> owner = {}, std::size_t maximum = 0,
    TextCompletion completion = TextCompletion::kEmitNext, std::size_t input_begin = 0, bool prefill_complete = true) {
  if (completion == TextCompletion::kStateOnly && (role != GraphRole::kText || generation || prefill_complete))
    throw std::runtime_error("state-only ledger entry requires an incomplete ordinary prefill");''')
sub('  record.role = role; record.generation = generation; record.quota = quota; record.turn = turn;','''  record.role = role; record.generation = generation; record.quota = quota; record.turn = turn;
  record.completion = completion; record.input_begin = input_begin; record.prefill_complete = prefill_complete;
  record.user_output = completion == TextCompletion::kEmitNext;''')
sub('    const bool prefill_complete = !record.generation && !record.imported;','''    const bool prefill_complete = !record.generation && !record.imported && record.prefill_complete;
    if (!record.generation && !record.imported &&
        (record.turn != request.progress.turn_index || record.input_begin != request.turn_input_consumed ||
         record.ids().size() > request.prompt.size() - request.turn_input_consumed ||
         record.ids().data() != request.prompt.data() + request.turn_input_consumed ||
         record.prefill_complete != (record.ids().size() == request.prompt.size() - request.turn_input_consumed)))
      throw std::runtime_error("committed prefill input is not the next actual turn slice");''')
sub('      } else if (!record.imported) {\n        ++request.prefill_graph_calls; request.prefill_graph_tokens += record.ids().size();\n        request.prefill_draft_rows += record.draft_rows;\n        request.prefill_step_seconds += record.step_seconds;\n      }\n    }','''      }
    }
    if (!record.generation && !record.imported) {
      ++request.prefill_graph_calls; request.prefill_graph_tokens += record.ids().size();
      request.prefill_draft_rows += record.draft_rows;
      request.prefill_step_seconds += record.step_seconds;
    }''')
sub('    if (!record.generation && !record.imported) {\n      request.prefill_endpoint', '    if (prefill_complete) {\n      request.prefill_endpoint')
sub('    (void)request.progress.observe_commit(ordinal, emitted, record.user_output, prefill_complete, stopped);','''    (void)request.progress.observe_commit(ordinal, emitted, record.user_output, prefill_complete, stopped);
    if (!record.generation && !record.imported) request.turn_input_consumed += record.ids().size();''')
sub('ledger.records[0].before.sampling);\n  GenerationLedger actual(ledger.committed_count);','ledger.records[0].before.sampling, false, ledger.records[0].completion);\n  GenerationLedger actual(ledger.committed_count);')
sub('prepare_generation_record(actual, *session, role, ids, false, 0, source.turn, source.input_owner);','''prepare_generation_record(actual, *session, role, ids, false, 0, source.turn, source.input_owner, 0,
          source.completion, source.input_begin, source.prefill_complete);''')
sub('model.prepare_evaluation(*session, ids, nullptr, role); model.submit_evaluation(*session);','model.prepare_evaluation(*session, ids, nullptr, role, source.completion); model.submit_evaluation(*session);')
sub('  bool generation = false, full_hit = false, initial_prefix = false;','''  bool generation = false, full_hit = false, initial_prefix = false, prefill_complete = true;
  TextCompletion completion = TextCompletion::kEmitNext;
  std::size_t input_begin = 0;''')
sub('    std::size_t output_credit = SIZE_MAX) {','''    std::size_t output_credit = SIZE_MAX, std::size_t max_prefill_rows = SIZE_MAX) {
  if (!max_prefill_rows || (model.cache_plan.draft_cache && max_prefill_rows != SIZE_MAX))
    throw std::runtime_error("bounded prefill rows require a positive ordinary Text quantum");
  if (max_prefill_rows != SIZE_MAX && !request.ledger)
    throw std::runtime_error("chunked prefill requires the original committed generation ledger");''')
sub('  call.generation = request.progress.prefilled;\n  if (!call.generation) {','''  call.generation = request.progress.prefilled;
  if (!call.generation) {
    if (request.input_turn != request.progress.turn_index) {
      const auto before = request.session ? request.session->length() : 0;
      if (request.prompt.empty() || request.prompt.size() > model.capacity - before)
        throw std::runtime_error("complete turn input exceeds the remaining context");
      for (auto id : request.prompt) if (id < 0 || id >= model.vocabulary)
        throw std::runtime_error("token ID outside vocabulary");
      request.input_turn = request.progress.turn_index; request.turn_input_consumed = 0;
    }''')
sub('    request.prefill_start = request.admission_start == Clock::time_point{} ? Clock::now()\n        : std::exchange(request.admission_start, Clock::time_point{});','''    if (!request.turn_input_consumed) request.prefill_start = request.admission_start == Clock::time_point{} ? Clock::now()
        : std::exchange(request.admission_start, Clock::time_point{});''')
sub('    if (call.initial_prefix) {','    if (call.initial_prefix && !request.session) {')
sub('        const std::array chunks{suffix};','''        request.turn_input_consumed = request.reused_tokens;
        const auto suffix_rows = (std::min)(suffix, max_prefill_rows);
        const auto suffix_completion = suffix > suffix_rows ? TextCompletion::kStateOnly : TextCompletion::kEmitNext;
        const std::array chunks{suffix_rows};''')
sub('request.progress.initial_sampling, suffix == 0);','request.progress.initial_sampling, suffix == 0, suffix_completion);')
sub('    call.prompt = request.prompt.subspan(request.progress.turn_index == 0 ? request.reused_tokens : 0);','''    call.input_begin = request.turn_input_consumed;
    const auto remaining_input = request.prompt.size() - call.input_begin;
    const auto rows = (std::min)(remaining_input, max_prefill_rows);
    call.prefill_complete = rows == remaining_input;
    call.completion = call.prefill_complete ? TextCompletion::kEmitNext : TextCompletion::kStateOnly;
    call.prompt = request.prompt.subspan(call.input_begin, rows);''')
sub('request.session = model.create_session(chunks, {}, call.role, request.progress.initial_sampling);','request.session = model.create_session(chunks, {}, call.role, request.progress.initial_sampling, false, call.completion);')
sub('    call.name = request.progress.turn_index ? "round" + std::to_string(request.progress.turn_index + 1) + "_prefill" : "prefill";','''    call.name = request.progress.turn_index ? "round" + std::to_string(request.progress.turn_index + 1) + "_prefill" : "prefill";
    if (!call.prefill_complete || call.input_begin > request.reused_tokens)
      call.name += "_chunk" + std::to_string(call.input_begin);''')
# A finite state-only record is already observed through the ledger; it has no output wrapper.
sub('  else if (!call.generation) {\n    request.prefill_step_seconds','  else if (!call.generation) {\n    request.prefill_step_seconds')
sub('  if (!call.generation) {\n    request.endpoint = request.prefill_endpoint;\n  }','  if (!call.generation && call.prefill_complete) {\n    request.endpoint = request.prefill_endpoint;\n  }')
sub('    if (!call.generation) { turn.start = request.prefill_start; turn.prefill_endpoint = request.prefill_endpoint; }','    if (!call.generation && call.prefill_complete) { turn.start = request.prefill_start; turn.prefill_endpoint = request.prefill_endpoint; }')
sub('  if (!call.generation)\n    std::cerr << "memory_phase="','  if (!call.generation && call.prefill_complete)\n    std::cerr << "memory_phase="')
sub('call.full_hit || call.role != role || call.generation != generation || call.ids().size() != calls[0].ids().size()', 'call.full_hit || call.role != role || call.completion != calls[0].completion || call.generation != generation || call.ids().size() != calls[0].ids().size()')
sub('request.warm_inputs.at(request.progress.turn_index)), call.maximum);','request.warm_inputs.at(request.progress.turn_index)), call.maximum, call.completion, call.input_begin, call.prefill_complete);')
sub('model.prepare_evaluations(std::span(inputs.data(), inputs.size()), nullptr, role); model.submit_evaluations();','model.prepare_evaluations(std::span(inputs.data(), inputs.size()), nullptr, role, calls[0].completion); model.submit_evaluations();')
sub('  if (!call.initial_prefix || call.full_hit) return;','  if (!call.initial_prefix || call.full_hit || !call.prefill_complete) return;')
sub('request.history->append(request.input, request.reused_tokens, call.ids().size(), request.session->head->next_id);','request.history->append(request.input, request.reused_tokens, request.prompt.size() - request.reused_tokens, request.session->head->next_id);')
sub('    const auto ledger_capacity = cache::add(first.size(), outputs);','    const auto ledger_capacity = generation_record_capacity(schedule.turns, SIZE_MAX, first.size());')
P.write_bytes(s.replace('\n','\r\n').encode());print('request edits applied')
