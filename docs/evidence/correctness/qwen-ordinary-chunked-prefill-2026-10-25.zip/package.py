from pathlib import Path
import hashlib,json,zipfile
R=Path.cwd();W=R/'.scratch/inference-chunked-prefill-20261025';A=W/'attempt2'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def record(p):return dict(path=p.relative_to(R).as_posix(),bytes=p.stat().st_size,sha256=sha(p))
result=json.loads((A/'run1/result.json').read_bytes());assert result['status']=='PASS'
pins=json.loads((A/'compile/actual-source-pins.json').read_bytes())
for pin in pins:
 p=Path(pin['path']);assert p.stat().st_size==pin['bytes']and sha(p)==pin['sha256'],str(p)
cleanup=[];retained=[]
for n,out in [(1,cleanup),(2,retained)]:
 for q in ['compile/unit.obj','link/consumer.exe','link/consumer.exp','link/consumer.lib','link/hyle_ggml_cpu_gdn_scale_v3.dll']:
  p=W/f'attempt{n}'/q;out.append(record(p))
summary=dict(status='PASS_ORIGINAL_ORDINARY_CHUNKED_PREFILL',date='2026-10-25',scope='One original BF16 Qwen2B ordinary random Model; finite scripted owner using the existing Window/Graph/State/Ledger. No online CLI, server, scheduler performance or MTP runtime claim.',
 result=result,canonical_bridge=json.loads((W/'canonical-bridge.json').read_bytes()),source_only=json.loads((W/'source-only.json').read_bytes()),
 actual_source_files=pins,compile=json.loads((A/'compile/process.json').read_bytes()),link=json.loads((A/'link/process.json').read_bytes()),run=json.loads((A/'run1/process.json').read_bytes()),
 input_pins=json.loads((A/'inputs.json').read_bytes()),command=json.loads((A/'run1/command.json').read_bytes()),
 scenarios=['P154 splits into64/64/26, only final chunk emits and advances cursor0→1.',
 'Actual original-token P15 peer has a ready T1 decode between the two long-prefill chunks, exact FIFO and same request keys.',
 'Partial committed64-row state is retired and rebuilt through its actual state_only ledger mode; all GDN state and carry bytes match, length/cursor/offset agree.',
 'One original submitted state-only64-row episode is aborted; original committed head/offset/ledger/cursor remain unchanged, and exact same slice succeeds on retry.',
 'Final full154 state enters existing PrefixCache once with64/64/26 history retaining two state_only markers and one emit marker; partial state was not published.',
 'A later131-row input contains actual pending once and130 original user suffix tokens;64/64/3, only final chunk emits and advances cursor1→2.',
 'A following empty user suffix consumes the actual pending once through T1; final length286, ledger7/cursor3/output3.',
 'All original participants retire and the existing Window releases only after actual completion.'],
 boundaries=['Invocation in_flight at abort is a logical owner fact; physical GPU completion at that instant is unknown.',
 'Independent bitwise comparison covers rebuilt GDN history/recurrent state and normalized carry only, not KV tensor bytes, F64 math or cross-partition distributions.',
 'No full-prompt versus chunk-partition bitwise ID/logit equivalence claim; source math is unchanged and chunk shapes can legally change floating arithmetic.',
 'Actual per-wave token quantum is64 with R1; cache Plan supports N3/R2, but no ragged/fused R2 mixed-shape execution or latency bound is claimed.',
 'Whole-turn ID/context preflight is implemented and source-reviewed; this one actual case uses valid inputs throughout and does not newly execute a bad-late-token case.',
 'No opaque-provider total memory bound, throughput, quality, online ingress or socket ACK claim. Existing default/MTP behavior has source-equivalence review only, not a rerun matrix.'],
 work=dict(committed_input_rows=303,additional_rebuild_rows=64,submitted_cancelled_candidate_rows=64,output_tokens=6,formula='committed A286+B17; rebuild and cancelled candidate are separate actual work, not silently excluded from throughput.'),
 actual_attempts=1,actual_failures=0,strict_consumer_compiles=2,SDK_builds=0,HTTP_requests=0,new_weight_bytes=0,
 preserved_unrun_compile=dict(attempt='attempt1',status='COMPILE_LINK_PASS_NOT_RUN',reason='Cold output publish order was corrected before first GPU run to preserve original default hidden/logits/id ordering.',source=record(W/'compile1-unrun-main.cc'),patch=record(W/'port-order-correction.patch')),
 cleanup=dict(files=cleanup,count=len(cleanup),logical_bytes=sum(v['bytes']for v in cleanup),deleted=False,scope='Only superseded unrun first consumer generation.'),
 retained_success=dict(files=retained,count=len(retained),logical_bytes=sum(v['bytes']for v in retained)))
(W/'cleanup-candidates.json').write_text(json.dumps(summary['cleanup'],indent=2)+'\n')
(W/'proof-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
files={}
def add(p,name=None):files[name or p.relative_to(W).as_posix()]=p
for pin in pins:
 p=Path(pin['path']).resolve()
 if p.is_relative_to(R/'engine')or p.is_relative_to(R/'include'):add(p,'actual-source/'+p.relative_to(R).as_posix())
for p in (R/'tests/tools/qwen_request_lifecycle_test.cc',R/'tests/tools/qwen_chunked_prefill_case.h'):add(p,'canonical/'+p.relative_to(R).as_posix())
for p in W.iterdir():
 if p.is_file()and p.suffix in('.cc','.h','.json','.patch','.py'):add(p)
for attempt in ('attempt1','attempt2'):
 for p in (W/attempt).rglob('*'):
  if p.is_file()and p.suffix in('.json','.log')and 'tmp'not in p.relative_to(W/attempt).parts:add(p)
inputs=R/'.scratch/qwen35-unsloth-mtp-20261024/geometry-v2-check/original'
for name in ('weights.tsv','prompt.ids'):add(inputs/name,'inputs/'+name)
Z=W/'proof.zip'
with zipfile.ZipFile(Z,'w',zipfile.ZIP_DEFLATED)as zip:
 for name,p in sorted(files.items()):zip.writestr(name,p.read_bytes())
 zip.writestr('archive-inventory.json',json.dumps([dict(path=name,bytes=p.stat().st_size,sha256=sha(p))for name,p in sorted(files.items())],indent=2)+'\n')
with zipfile.ZipFile(Z)as zip:
 assert zip.testzip()is None
 assert not any(Path(n).suffix.lower()in('.exe','.obj','.pdb','.lib','.dll','.exp')for n in zip.namelist())
 for v in json.loads(zip.read('archive-inventory.json')):
  b=zip.read(v['path']);assert len(b)==v['bytes']and hashlib.sha256(b).hexdigest()==v['sha256']
 count=len(zip.namelist())
publication=dict(summary=record(W/'proof-summary.json'),archive=record(Z),members=count,CRC_and_all_member_SHA='PASS',cleanup_count=len(cleanup),cleanup_logical_bytes=summary['cleanup']['logical_bytes'],retained_success_count=len(retained),retained_success_logical_bytes=summary['retained_success']['logical_bytes'])
(W/'publication.json').write_text(json.dumps(publication,indent=2)+'\n');print(json.dumps(publication,indent=2))
