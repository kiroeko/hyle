from pathlib import Path
import hashlib,importlib.util,json
R=Path.cwd();W=R/'.scratch/inference-chunked-prefill-20261025'
spec=importlib.util.spec_from_file_location('retained',R/'.scratch/mtp-extraction-regression-20261024/check.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
old=R/'.scratch/inference-system-review-20261025/schedule-inputs';original=b.args(old/'compile/command.json')
flags=[];skip=False
for a in original[1:]:
 if skip:skip=False;continue
 if a=='/sourceDependencies':skip=True;continue
 if a.lower().startswith(('/fo','/fd'))or a.lower().endswith(('.cc','.cpp')):continue
 flags.append(a)
inputs=[R/'engine/models/qwen35/main.cc',R/'engine/models/qwen35/prefix_cache.h',R/'tests/tools/qwen_request_lifecycle_test.cc',R/'tests/tools/qwen_chunked_prefill_case.h']
before=[b.pin(p)for p in inputs];b.save(W/'final-syntax2-before.json',before)
b.execute([original[0],*flags,'/Zs',str(inputs[2]),'/sourceDependencies',str(W/'final-syntax2/dependencies.json')],W/'final-syntax2',b.environment(original[0]),90)
for pin in before:assert b.pin(Path(pin['path']))==pin
b.save(W/'final-syntax2/source-pins.json',before)
print(json.dumps(dict(status='STRICT_SYNTAX_PASS',sources=before)),flush=True)
