from pathlib import Path
import importlib.util,os,shutil,sys
sys.dont_write_bytecode=True
R=Path.cwd();W=R/'.scratch/nf4-typed-profile-20261025';A=W/'ga-cuda1';A.mkdir();S=A/'source';S.mkdir()
spec=importlib.util.spec_from_file_location('retained',R/'.scratch/mtp-extraction-regression-20261024/check.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
files=[R/'engine/models/qwen35/main.cc',*(R/'engine/models/qwen35').glob('*.h'),*(R/'engine/inference').glob('*.h'),R/'engine/reporting/execution_report.h',R/'tests/compute_models/original_role_input.h']
for p in files:
 d=S/p.relative_to(R);d.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,d)
shutil.copyfile(W/'ga-cuda.cc',S/'component.cc');b.save(A/'pins.json',[b.pin(p)for p in S.rglob('*')if p.is_file()])
ref=R/'.scratch/inference-system-review-20261025/text-r2-suffix';base=b.args(ref/'compile/command.json');cmd=[base[0],'/I'+str(S)];skip=False
for word in base[1:]:
 if skip:skip=False;continue
 if word=='/sourceDependencies':skip=True;continue
 low=word.lower().replace('\\','/')
 if low.startswith(('/fo','/fd'))or low.endswith(('.cc','.cpp')):continue
 if low.startswith(('/i','-i'))and'/.scratch/'in low and low.endswith('/source'):continue
 cmd.append(word)
cmd+=['/sourceDependencies',str(A/'compile/dependencies.json'),str(S/'component.cc'),'/Fo'+str(A/'compile/component.obj'),'/Fd'+str(A/'compile/component.pdb')]
env=b.environment(base[0]);b.execute(cmd,A/'compile',env,120)
includes=[Path(p).resolve()for p in b.read(A/'compile/dependencies.json')['Data']['Includes']];assert not [str(p)for p in includes if p.is_relative_to(R/'engine')or p.is_relative_to(R/'tests')]
link=[];old=str(ref/'compile/unit.obj');found=0
for word in b.args(ref/'link/command.json'):
 if word.lower().startswith(('/out:','/pdb:','/map:','/implib:')):continue
 if word.lower()==old.lower():word=str(A/'compile/component.obj');found+=1
 link.append(word)
assert found==1
for word in link[1:]:
 if word.lower().endswith(('.obj','.lib'))and Path(word).is_absolute():assert Path(word).is_file(),word
link+=['/OUT:'+str(A/'link/component.exe'),'/PDB:'+str(A/'link/component.pdb'),'/IMPLIB:'+str(A/'link/component.lib')];b.execute(link,A/'link',env,60)
runtime=b.read(R/'.scratch/mtp-performance-convergence-20261025/baseline/runtime.json');native=Path(runtime['native']['path']);os.link(native,A/'link'/native.name);env['PATH']=str(A/'link')+';'+runtime['PATH']
b.save(A/'runtime.json',dict(image=b.pin(A/'link/component.exe'),native=b.pin(native),entry_only_closure_replacement=True,SDK_builds=0,HTTP=0,GPU_runs=0))
b.save(A/'ready-command.json',dict(command=[str(A/'link/component.exe'),str(A/'fixture'),str(A/'state-output')],runtime=b.pin(A/'runtime.json'),GPU_not_started=True))
print('CUDA private image ready; not run until root releases GPU.')
