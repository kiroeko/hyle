"""Fetch only the offline exact NF4 plan through the retained mirror budget."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed
import argparse
import hashlib
import importlib.util
import inspect
import json
import sys
import urllib.request

sys.dont_write_bytecode = True
base = Path(__file__).resolve().parent
root = base.parents[1]
budget_path = root/'.scratch/mtp-download-budget-20261023/budget.py'
transport_path = root/'.scratch/mtp-metadata-offline-20261024/fetch-small-headers.py'
script = Path(__file__).resolve().relative_to(root).as_posix()
plan_path = base/'fetch-plan.json'

def sha(data): return hashlib.sha256(data).hexdigest()
def save(path,value): path.write_text(json.dumps(value,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')

def run(resume=False):
    assert sha(budget_path.read_bytes()) == '24b008fb7a91f0eba34739cd4817fbf97b42ca7f435032d76cfb6e97ea398a17'
    assert sha(transport_path.read_bytes()) == '3dc89fb1efc369615d7a3132bd08b3aabcf125259498b5f8581cec83d559a7da'
    plan = json.loads(plan_path.read_bytes())
    assert plan['maximum_new_payload_bytes']==2757098 and plan['HTTP_requests']==354 and plan['maximum_concurrency']==4
    assert sum(item['bytes'] for item in plan['requests'])==2757098
    assert [item['ordinal'] for item in plan['requests']]==list(range(354))
    for item in plan['cached_inputs']:
        data=(root/item['path']).read_bytes()
        assert len(data)==item['bytes'] and sha(data)==item['sha256'],item['path']
    spec=importlib.util.spec_from_file_location('retained_nf4_transport',transport_path)
    transport=importlib.util.module_from_spec(spec);spec.loader.exec_module(transport)
    transport.SCRIPT=script
    budget=transport.module();budget.require_enabled()
    guard=urllib.request.urlopen
    assert Path(guard.__code__.co_filename).resolve()==budget_path.resolve()
    assert inspect.getclosurevars(guard).nonlocals.get('script')==script
    row=dict(repository=plan['repository'],revision=plan['revision'],file=plan['source']['file'],uri=plan['url'])
    metadata=root/'.scratch/mtp-metadata-offline-20261024/cat13'
    source=transport.crosscheck_tree_identity(row,(metadata/'expanded-api.json').read_bytes(),(metadata/'tree-api.json').read_bytes())
    assert source==plan['source']
    header=(metadata/'header.json').read_bytes()
    facts=transport.parse_header(header,source['size'])
    assert plan['payload_base']==8+len(header)
    for item in plan['requests']:
        assert item['output']==f"range-{item['ordinal']:03d}.bin" and item['bytes']==item['last']-item['first']+1
        assert 0<=item['first']<=item['last']<source['size'] and item['bytes']<=transport.HEADER_LIMIT
        assert len(item['roles'])==1
        role=facts['all_physical_tensors'][item['roles'][0]]
        first,last=role['data_offsets']
        first+=plan['payload_base'];last+=plan['payload_base']-1
        if item['kind']=='quant_states':
            assert (item['first'],item['last'])==(first,last)
        else:
            assert item['kind']=='whole_kproj_tail' and first<item['first'] and item['last']==last
    output=base/'payload'
    if not resume:
        output.mkdir(exist_ok=False)
        save(output/'source.json',dict(source=source,plan_sha256=sha(plan_path.read_bytes()),full_source_LFS_verified=False,
            scope='Exact authenticated ranges; no full-file hash or full model claim.'))
    else:
        prior=json.loads((output/'source.json').read_bytes())
        assert prior['source']==source and prior['plan_sha256']==sha(plan_path.read_bytes())
    receipt_root=output/'explicit-resume-1' if resume else output
    if resume: receipt_root.mkdir(exist_ok=False)
    completed=[];pending=[]
    for item in plan['requests']:
        original_folder=output/f"request-{item['ordinal']:03d}"
        previous=original_folder/'complete.json'
        if previous.exists():
            record=json.loads(previous.read_bytes())
            data=(root/record['path']).read_bytes()
            assert (record['ordinal'],record['range'],record['roles'])==(item['ordinal'],[item['first'],item['last']],item['roles'])
            assert record['path']==(output/item['output']).relative_to(root).as_posix()
            assert len(data)==item['bytes']==record['bytes'] and sha(data)==record['sha256']
            assert record['response']['etag']==source['etag']
            completed.append(record)
        else:
            assert not (output/item['output']).exists(),'Unverified partial body must be inspected before reuse'
            pending.append(item)
    save(receipt_root/'invocation-plan.json',dict(explicit_resume=resume,reused_requests=len(completed),new_requests=len(pending),
        new_bytes=sum(item['bytes'] for item in pending),automatic_retry=False))

    def fetch(item):
        folder=receipt_root/f"request-{item['ordinal']:03d}";folder.mkdir()
        client=transport.Fetch(budget,row,timeout=45,receipt_dir=folder)
        raw,receipt=client.get(item['first'],item['last'],source=source)
        assert len(raw)==item['bytes']
        path=output/item['output'];path.write_bytes(raw)
        result=dict(ordinal=item['ordinal'],kind=item['kind'],roles=item['roles'],
            range=[item['first'],item['last']],path=path.relative_to(root).as_posix(),bytes=len(raw),sha256=sha(raw),response=receipt)
        save(folder/'complete.json',result)
        if resume:
            original_folder=output/f"request-{item['ordinal']:03d}";original_folder.mkdir(exist_ok=True)
            save(original_folder/'complete.json',result)
        return result

    failure=None
    with ThreadPoolExecutor(max_workers=4) as pool:
        futures={pool.submit(fetch,item):item for item in pending}
        try:
            for future in as_completed(futures):
                completed.append(future.result())
                completed.sort(key=lambda item:item['ordinal'])
                save(output/'verified-parts.json',dict(complete=False,parts=completed))
                if len(completed)%16==0 or len(completed)<=4:
                    print(json.dumps(dict(completed=len(completed),planned=354,bytes=sum(item['bytes'] for item in completed))),flush=True)
                if {0,1,2}.issubset(item['ordinal'] for item in completed) and not (output/'kproj-tails-ready.json').exists():
                    save(output/'kproj-tails-ready.json',dict(status='EXACT_KPROJ_TAILS_READY',parts=[item for item in completed if item['ordinal']<3],cached_prefix_bytes=9183))
        except BaseException as error:
            failure=error
            for future in futures: future.cancel()
            save(receipt_root/'failed.json',dict(status='FAILED_PRESERVED',type=type(error).__name__,error=str(error),automatic_retries=0))
    if failure: raise failure
    assert len(completed)==354 and sum(item['bytes'] for item in completed)==2757098
    complete=dict(status='EXACT_NF4_COMPONENT_AND_ALL_QUANT_STATE_RANGES_ACQUIRED',parts=completed,
        payload_bytes=2757098,HTTP_requests=354,full_model_download=False,full_source_LFS_verified=False,
        source=source,cached_original_bytes_reused=9183,only_https_host='hf-mirror.net')
    save(output/'complete.json',complete)
    print(json.dumps({key:value for key,value in complete.items() if key not in ('parts','source')}),flush=True)

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--apply',action='store_true')
    parser.add_argument('--resume',action='store_true');args=parser.parse_args()
    assert args.apply,'Explicit planned application required'
    run(args.resume)
