# NF4 typed profile: independent classification

Read-only against completed chunked-prefill main `28875a2240b4e9ea701c8977a14a382166dfd1404d300eb2b7055436b9c3bea5`; no model/build/network run. Function anchors remain authoritative after edits.

| Boundary | Required handling |
|---|---|
| `state_schema_for`, `prepare_attention_schema` | History, Q/K/V/Y use the fixed activation profile; recurrent state remains F32. Both F16/BF16 are two bytes, so geometry byte counts remain valid. |
| `Recipe::embedding`, dense `StoredProjection`, final head | Imported NF4 and original floating roles use F16 activations/weights/output, F32 accumulation. Preserve the F16 head rounding before widening to F32. Existing BF16 dense scores keep their current direct F32 contract. |
| `Recipe::scalar`, `l2` | Encode F16 through existing SIMD conversion; epsilon follows actual input dtype. Current BF16 scalar writes the upper 16 bits, so do not silently change arbitrary legacy values to RNE while wiring F16. Check existing scalar constants if replacing that branch. |
| Family GDN history, post-conv activation, GDN result norm/gate | Activation boundaries follow profile. Conv/GDN gates/recurrent/F32 norm accumulation and explicit mathematical F32 intermediates remain as originally declared. |
| Carry/prior/hidden/frontier schemas, retain validation and binding | Use one immutable profile at every producer/consumer descriptor, including prefix sampling and the original draft helpers; do not infer dtype separately per caller. No new NF4 MTP weights/functionality. |
| `mtp_graph.h` | Query/cache/state/hidden descriptors read the same Recipe profile. Its existing default remains BF16. |
| CT/GPTQ/NVFP4/FP8 equations | Explicit source-scale/decode/QDQ BF16 arithmetic is an artifact contract, not a generic activation literal. Preserve these branches and reject incompatible mixed policies. |
| Quantized binding validation | `detail::activation` is currently the BF16 input for specific typed quant equations. Do not globally replace it by the source NF4 profile. NF4 imported dense F16 resolves through `StoredProjection`. |
| Diagnostic outputs | `hidden.bf16`, `.conv.bf16`, probe extension and layer0 BF16 assertion must describe actual dtype. Keep old BF16 filenames while naming F16 accurately. |

Most important actual literal sites in the frozen main: state404; embedding640; scalar648; projection764–856; l2 epsilon891; attention2175–2178; carry/prior2345–2378; GDN2436–2497; attention2539; probe2555; carry2571/2682; draft2764–2927; frontier3141/3179; carry binding3625–3628; diagnostics4457/4461/4479. These numbers are discovery pointers, not mutable schema IDs.

The public Compute operators already carry actual dtypes. The model-private profile fixes source semantics before schema/Graph construction; it is not a user-facing provider/dtype registry or per-token routing decision.
