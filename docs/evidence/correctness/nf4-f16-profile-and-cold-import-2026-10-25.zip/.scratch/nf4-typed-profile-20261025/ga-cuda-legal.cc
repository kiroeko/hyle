// Actual untrained GA Model state regression. The T3 accepted prefix is an
// explicit consumed2 state control, not a natural acceptance/quality claim.
#include "engine/models/qwen35/main.cc"
#include "hyle/compute/detail/paged_arena_access.h"

namespace q = qwen35;
namespace c = q::c;
using Bytes = std::vector<std::byte>;
void require(bool yes, const char* message) { if (!yes) throw std::runtime_error(message); }
q::ModelGeometry geometry() {
  q::ModelGeometry s;
  s.hidden=64; s.intermediate=128; s.vocabulary=64;
  s.query_heads=s.kv_heads=1; s.key_depth=s.value_depth=s.rotary=64;
  s.gdn_key_heads=1; s.gdn_value_heads=2; s.gdn_key_depth=s.gdn_value_depth=64;
  s.conv_kernel=4; s.context_limit=16; s.rope_theta=10000; s.epsilon=1.e-6F;
  s.tied_head=true; s.layers="GA"; s.mtp_layers=0; s.validate(); return s;
}
std::pair<std::filesystem::path,std::size_t> weights(const std::filesystem::path& folder,const q::ModelGeometry& shape) {
  std::filesystem::create_directories(folder);const auto body=folder/"untrained-f16.bin",list=folder/"weights.tsv";
  std::ofstream payload(body,std::ios::binary),manifest(list);require(bool(payload)&&bool(manifest),"cannot create F16 fixture");
  const std::string packed="model.language_model.layers.1.self_attn.k_proj.weight";
  const std::string json="{\"quant_type\":\"nf4\",\"blocksize\":64,\"dtype\":\"float16\",\"shape\":[64,64],\"nested_blocksize\":256,\"nested_dtype\":\"float32\",\"nested_offset\":0}";
  manifest<<"HYLE_QWEN_ROLE_FILES_V2\n"<<std::string(64,'6')<<"\ngeometry 64 128 64 1 1 64 64 64 1 2 64 64 4 16 10000 1e-6 1 0 grouped \"GA\"\n"<<q::prepared::nf4_policy_line<<'\n'
    <<"nf4_state\t"<<packed<<'\t'<<hyle::inference::artifact::sha256(std::as_bytes(std::span(json)))<<"\t00000000\n";
  std::size_t offset=0,index=0;
  const auto role=[&](const std::string&name,const char*dtype,std::initializer_list<std::int64_t> dims,std::span<const std::byte> bytes){
    payload.write(reinterpret_cast<const char*>(bytes.data()),static_cast<std::streamsize>(bytes.size()));manifest<<name<<' '<<dtype<<' '<<dims.size();for(auto d:dims)manifest<<' '<<d;manifest<<' '<<std::quoted(body.generic_string())<<' '<<offset<<' '<<bytes.size()<<'\n';offset+=bytes.size();
  };
  for(const auto&[name,p]:q::prepared::parameter_inventory(false,shape)){
    if(name==packed){
      std::vector<std::byte> codes(2048,std::byte{0x88}),indices(64,std::byte{255});const float scale=.001F;
      const auto root=std::filesystem::current_path()/".scratch/inference-system-review-20261025/nf4-component-values/codebooks.bin";std::ifstream booksfile(root,std::ios::binary);std::vector<std::byte> books(1088);booksfile.read(reinterpret_cast<char*>(books.data()),1088);require(bool(booksfile),"original codebooks unavailable");
      role(name,"U8",{2048,1},codes);role(name+".absmax","U8",{64},indices);role(name+".nested_absmax","F32",{1},std::as_bytes(std::span(&scale,1)));
      role(name+".nested_quant_map","F32",{256},std::span(books).first(1024));role(name+".quant_map","F32",{16},std::span(books).subspan(1024));role(name+std::string(q::prepared::nf4_state_suffix),"U8",{std::int64_t(json.size())},std::as_bytes(std::span(json)));continue;
    }
    std::size_t n=1;for(auto d:p.shape)n*=std::size_t(d);std::vector<hyle::simd::float16_t> values(n);
    for(std::size_t i=0;i<n;++i)values[i]=hyle::simd::f32_to_f16(p.shape.size()==1?0.F:.03F*std::sin(float(i+index*17)*.13F));
    payload.write(reinterpret_cast<const char*>(values.data()),static_cast<std::streamsize>(values.size()*2));manifest<<name<<" F16 "<<p.shape.size();for(auto d:p.shape)manifest<<' '<<d;manifest<<' '<<std::quoted(body.generic_string())<<' '<<offset<<' '<<n*2<<'\n';offset+=n*2;++index;
  }
  require(bool(payload)&&bool(manifest)&&offset<1024*1024,"F16 fixture exceeds finite scope");return{list,offset};
}
Bytes read(q::Model& model,const c::ReadLease& lease) {
  if(!lease.valid())return{};
  Bytes result(lease.size());q::check(model.execution.read(q::take(lease.view()),result));return result;
}
void store(const std::filesystem::path& file,const Bytes& bytes) {
  std::filesystem::create_directories(file.parent_path());std::ofstream out(file,std::ios::binary);
  out.write(reinterpret_cast<const char*>(bytes.data()),static_cast<std::streamsize>(bytes.size()));
  require(bool(out),"cannot write actual state bytes");
}
Bytes logical_rows(q::Model& model,const c::PagedArena& arena,const c::PagedArenaRead& frame,std::size_t rows,std::size_t row_bytes) {
  const auto layout=frame.layout().host();const auto pages=(rows+15)/16;
  require(frame.valid()&&layout.page_indices.size()==pages&&frame.page_count()==pages,"logical state page footprint differs");
  Bytes result(rows*row_bytes);std::size_t at=0;
  const auto guards=c::detail::PagedArenaAccess::pages(frame);
  for(std::size_t i=0;i<pages;++i) {
    const c::ReadLease* selected=nullptr;
    for(const auto& guard:guards)if(q::take(c::detail::PagedArenaAccess::page(arena,guard))==static_cast<std::uint32_t>(layout.page_indices[i]))selected=&guard;
    require(selected!=nullptr,"logical page lost original read guard");
    const auto bytes=(std::min)(16*row_bytes,result.size()-at);
    q::check(model.execution.read(q::take(q::take(selected->view()).subview(0,bytes)),std::span(result).subspan(at,bytes)));at+=bytes;
  }
  return result;
}
using Image=std::map<std::string,Bytes>;
Image image(q::Model& model,const q::cache::Snapshot& head) {
  Image result;
  const auto add=[&](std::string name,const c::ReadLease& lease){if(lease.valid())result.emplace(std::move(name),read(model,lease));};
  for(std::size_t i=0;i<head.state.size();++i)if(model.geometry.is_gdn(i)) {
    add("gdn"+std::to_string(i)+".history.f16",head.state[i].history);
    add("gdn"+std::to_string(i)+".recurrent.f32",head.state[i].recurrent);
  }
  for(std::size_t i=0;i<head.keys.size();++i) {
    result.emplace("target"+std::to_string(i)+".key.f16",logical_rows(model,model.page_inventory.keys[i],head.keys[i],head.length,static_cast<std::size_t>(model.geometry.key_row_bytes())));
    result.emplace("target"+std::to_string(i)+".value.f16",logical_rows(model,model.page_inventory.values[i],head.values[i],head.length,static_cast<std::size_t>(model.geometry.value_row_bytes())));
  }
  add("carry.f16",head.carry_hidden);add("prior.f16",head.prior_hidden);
  if(head.draft) {
    result.emplace("draft.key.f16",logical_rows(model,model.draft_inventory.keys[0],head.draft->key,head.draft->frontier,static_cast<std::size_t>(model.geometry.key_row_bytes())));
    result.emplace("draft.value.f16",logical_rows(model,model.draft_inventory.values[0],head.draft->value,head.draft->frontier,static_cast<std::size_t>(model.geometry.value_row_bytes())));
  }
  std::ostringstream meta;
  meta<<"length="<<head.length<<" next="<<head.next_id<<" seed="<<head.sampling.seed<<" stream="<<head.sampling.stream<<" draw="<<head.sampling.draw;
  if(head.draft)meta<<" frontier="<<head.draft->frontier<<" lag="<<head.draft->lag<<" catchup="<<head.draft->catchup_token;
  const auto text=meta.str();result.emplace("metadata.txt",Bytes(reinterpret_cast<const std::byte*>(text.data()),reinterpret_cast<const std::byte*>(text.data()+text.size())));return result;
}
void dump(const std::filesystem::path& folder,const Image& data){for(const auto& [name,bytes]:data)store(folder/name,bytes);}
void retire(std::shared_ptr<q::Session>& session){q::check(session->stop());q::check(session->drain());require(q::take(session->try_retire()),"session retirement incomplete");session.reset();}
int main(int argc,char**argv){try{
 require(argc==3,"ga FIXTURE OUTPUT");const auto shape=geometry();const auto fixture=weights(argv[1],shape);const std::filesystem::path out=argv[2];std::filesystem::create_directories(out);
 const auto plan=q::cache::plan(shape,16,4,3,q::recurrent_bytes(q::state_schema_for(shape,16),shape),1,2,false,true);
 q::Model model(fixture.first,shape,16,plan,{},false,q::ReplayPolicy::kCommands,16*1024*1024,{.enabled=true,.policy={1.F,8,.9F},.seed=123},0,{.primary=hyle::inference::BackendKind::kCuda});
 require(model.precision.is_f16()&&model.state_schema[0].history.data_type()==q::Type::kFloat16&&model.state_schema[0].recurrent.data_type()==q::Type::kFloat32,"typed GDN state schema differs");
 require(model.weights.at("model.language_model.layers.1.self_attn.k_proj.weight").codec==q::prepared::ProjectionCodec::kNf4DoubleQuant,"cold fallback lost original codec");
 require(model.score_precision_policy()=="f16_inputs_f16_projection_f32_logits","F16 head rounding policy differs");
 const std::array chunks{std::size_t{2},std::size_t{1}};const std::array decode{std::size_t{1}};model.prepare_family(chunks);model.plan_execution(chunks);model.plan_replay_uses(1,1,2);
 require(model.attention_schema.capacity().query_type==q::Type::kFloat16&&model.attention_schema.capacity().output_type==q::Type::kFloat16,"typed attention schema differs");
 auto session=model.create_session(chunks);const std::array<std::int32_t,2> prompt{1,2};const auto first=q::evaluate(model,*session,prompt,"f16-P2",out,true);auto base=session->head;
 const auto saved=image(model,*base);dump(out/"base-state",saved);require(base->length==2&&base->sampling.draw==1&&!base->draft,"ordinary prefill boundary differs");
 require(std::ranges::any_of(saved.at("gdn0.history.f16"),[](std::byte b){return b!=std::byte{};})&&std::ranges::any_of(saved.at("gdn0.recurrent.f32"),[](std::byte b){return b!=std::byte{};}),"F16 GA state witness is all zero");
 const std::array pending{first};const auto next=q::evaluate(model,*session,pending,"f16-T1",out,true);require(session->head->length==3&&session->head->sampling.draw==2,"ordinary decode boundary differs");
 require(saved==image(model,*base),"old F16 Snapshot changed after decode");const auto after=image(model,*session->head);dump(out/"final-state",after);
 auto restored=model.create_session(decode,base);require(restored->head->next_id==first&&restored->head->sampling==base->sampling,"same-request restore lost pending/cursor");const auto repeat=q::evaluate(model,*restored,pending,"f16-restored-T1",{},false);require(repeat==next&&image(model,*restored->head)==after,"same-request F16 state/RNG restore differs");retire(restored);
 const q::cache::SamplingCursor own{321,99,0};auto fresh=model.create_session(decode,base,q::GraphRole::kText,own,true);require(fresh->head->sampling.seed==321&&fresh->head->sampling.stream==99&&fresh->head->sampling.draw==1&&saved==image(model,*base),"new-request F16 frontier sampling mutated original prefix");retire(fresh);
 const auto peak=model.cache_usage().peak_bytes;require(peak<=16*1024*1024,"F16 cache budget escaped");base.reset();retire(session);require(!model.active_step&&!model.carrier_borrowed&&model.snapshot_versions.live==0,"F16 original resources not retired");
 std::cout<<"{\"status\":\"PASS\",\"backend\":\"CUDA\",\"source\":\"untrained_tiny_GA_with_one_NF4_group\",\"fixture_bytes\":"<<fixture.second<<",\"activation\":\"F16\",\"GDN_history\":\"F16\",\"GDN_recurrent\":\"F32\",\"ordinary_ids\":["<<first<<','<<next<<"],\"actual_decode_replay_same_request\":true,\"fresh_prefix_own_stream\":true,\"old_snapshot_unchanged\":true,\"sampling_draw\":2,\"cache_peak\":"<<peak<<",\"full_original_model\":false,\"GPU_runs\":1}\n";return 0;
}catch(const std::exception&e){std::cerr<<"F16 GA: "<<e.what()<<'\n';return 1;}}
