from pathlib import Path
import hashlib
import json
import subprocess

root = Path(__file__).resolve().parents[2]
pins = json.loads(Path(__file__).with_name('product-final').joinpath('pins.json').read_text('utf-8'))
assert len(pins) == 12
for pin in pins:
    path = root / pin['path']
    assert path.resolve().is_relative_to(root)
    raw = path.read_bytes()
    assert len(raw) == pin['bytes'] and hashlib.sha256(raw).hexdigest() == pin['sha256'], pin['path']
subprocess.run(['git','add','--',*[x['path'] for x in pins]],cwd=root,check=True)
print('Staged 12 exact final NF4 product files; index main7d09, no other working changes included.')
