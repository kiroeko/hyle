from pathlib import Path
import json,hashlib,zipfile
R=Path.cwd();W=R/'.scratch/nf4-typed-profile-20261025';pub=R/'docs/evidence/correctness';pub.mkdir(parents=True,exist_ok=True)
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def pin(p):p=Path(p);return dict(path=p.relative_to(R).as_posix(),bytes=p.stat().st_size,sha256=sha(p))
def save(p,x):Path(p).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
summary=json.loads((W/'proof-summary.json').read_text())
summary['product_final_pins']=pin(W/'product-final/pins.json')
summary['closure']=dict(retained_baseline_image=pin(R/'.scratch/mtp-performance-convergence-20261025/baseline/link/hyle.exe'),
 retained_runtime=pin(R/'.scratch/mtp-performance-convergence-20261025/baseline/runtime.json'),
 reused_link_template=pin(R/'.scratch/inference-system-review-20261025/text-r2-suffix/link/command.json'),
 delta='Each component/GA image replaces only the original app object in the retained exact link closure. Native/runtime/SDK/Graph objects are reused; importer executes the existing decoder through the ordinary Backend/Graph path. All per-attempt exact compiler/link argv and frozen source hashes are archived.',
 direct_runtime_native_DLL=pin(R/'.scratch/mtp-performance-convergence-20261025/baseline/link/hyle_ggml_cpu_gdn_scale_v3.dll'))
assert summary['closure']['retained_baseline_image']['sha256']=='c343db76232c4b5bd34878820433057b8c23789cd1b170b6a3b86cd91bf82fa1'
summary['archive_contract']='All source/command/result/receipt paths in this private batch map to archived payloads via payload-manifest.json. Large original numeric ranges, generated full weight banks, expected full decoder output and binaries are intentionally omitted with exact pins; they are not implicitly supplied or full-LFS verified. Source paths outside the batch are explicitly cached identities/related evidence.'
save(W/'proof-summary.json',summary)
files=set();omitted=[]
blocked={'.obj','.exe','.lib','.exp','.pdb','.dll','.zip'}
for p in W.rglob('*'):
 if not p.is_file()or p.name in {'payload-manifest.json'}:continue
 rel=p.relative_to(W)
 if p.suffix.lower()in blocked:continue
 if (rel.parts[0]=='payload'and p.name in {'range-000.bin','range-001.bin','range-002.bin'})or p.name in {'expected-f16.bin','untrained-f16.bin'}:
  omitted.append(pin(p));continue
 # Scripts/metadata/source/actual state outputs and all 352 tiny original JSON states retained.
 files.add(p)
combined=R/'.scratch/inference-combined-interface-20261025'
for p in combined.rglob('*'):
 if p.is_file()and p.suffix.lower()not in blocked:files.add(p)
# Exact cached source metadata and 9183B input slices; no full original source bank.
plan=json.loads((W/'fetch-plan.json').read_text())
for row in plan['cached_inputs']:
 p=R/row['path'];assert p.stat().st_size==row['bytes']and sha(p)==row['sha256'];files.add(p)
for n in ['baseline/runtime.json','baseline/link/command.json']:
 files.add(R/'.scratch/mtp-performance-convergence-20261025'/n)
files.add(R/'.scratch/inference-system-review-20261025/text-r2-suffix/link/command.json')
# One shared build helper is part of command reproduction, no SDK body.
files.add(R/'.scratch/mtp-extraction-regression-20261024/check.py')
# Source deduplication retains exact byte identity, including first-failure source snapshots.
source_store={};entries=[];payloads={}
for p in sorted(files):
 row=pin(p);parts=p.parts
 is_source=('source'in parts or 'product-final'in parts)and p.suffix.lower()in{'.h','.cc','.py','.txt'}
 if is_source and row['sha256']in source_store:target=source_store[row['sha256']]
 else:
  target=row['path'];payloads[target]=p
  if is_source:source_store[row['sha256']]=target
 row['archive_payload']=target;entries.append(row)
manifest=dict(version=1,entries=entries,intentionally_omitted_payloads=omitted,
 outside_source_pins='Commands retain cached compiler/SDK/library paths; these are environment dependencies, not archive promises. Retained baseline closure image/native identities and source metadata are in proof-summary.json.',
 binary_cleanup='cleanup-candidates.json pins all24 private reproducible binaries; none are archived or deleted by this publication.')
save(W/'payload-manifest.json',manifest);payloads[(W/'payload-manifest.json').relative_to(R).as_posix()]=W/'payload-manifest.json'
archive=pub/'nf4-f16-profile-and-cold-import-2026-10-25.zip'
assert not archive.exists()
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9)as z:
 for target,p in sorted(payloads.items()):z.write(p,target)
with zipfile.ZipFile(archive)as z:
 assert z.testzip()is None
 names=set(z.namelist())
 for row in entries:
  b=z.read(row['archive_payload']);assert len(b)==row['bytes']and hashlib.sha256(b).hexdigest()==row['sha256']
 assert not any(Path(n).suffix.lower()in blocked-{'.zip'} for n in names)
public=dict(summary)
public['archive']=pin(archive)
public['archive']['CRC_verified']=True
public['archive']['payloads']=len(payloads)
public['archive']['source_and_path_mapping']='.scratch/nf4-typed-profile-20261025/payload-manifest.json'
public['cleanup']['receipt']=None
save(pub/'nf4-f16-profile-and-cold-import-2026-10-25.json',public)
print(json.dumps(dict(archive=public['archive'],cleanup_files=len(public['cleanup']['files']),cleanup_bytes=public['cleanup']['logical_bytes'],all_processes_terminal=True,GPU_released=True),indent=2))
