#include "engine/models/qwen35/nf4_weight_import.h"
#include "engine/models/qwen35/precision_profile.h"
#include "tests/compute_models/original_role_input.h"
#include "hyle/compute/prepared_operation.h"
#include <filesystem>
#include <iostream>

namespace c=hyle::compute;
namespace m=hyle::mem;
namespace q=qwen35;
namespace fs=std::filesystem;
using T=c::DataType;
template<class V> V take(hyle::Result<V> result){if(!result)throw std::runtime_error(std::string(result.error().message()));return std::move(*result);}
void check(hyle::Status status){if(!status.ok())throw std::runtime_error(std::string(status.message()));}
void require(bool yes,const char*text){if(!yes)throw std::runtime_error(text);}
using Bytes=std::vector<std::byte>;
Bytes read(const fs::path&p,std::size_t bytes,std::string_view sha){return original_role_input::read_bytes(p,bytes,sha);}
Bytes join(Bytes a,Bytes b){a.insert(a.end(),b.begin(),b.end());return a;}
c::TensorDesc dense(T type,std::initializer_list<std::int64_t> shape){return take(c::TensorDesc::dense(type,{shape.begin(),shape.size()}));}
c::ReadLease upload(const hyle::inference::Backend&backend,std::span<const std::byte> bytes){auto storage=take(m::Buffer::create(backend.device(),bytes.size(),256));check(backend.write(storage.view(),bytes));return take(backend.adopt_buffer(std::move(storage)));}
int main(int argc,char**argv){try{
 require(argc==2,"component requires repository root");const fs::path root=argv[1];const auto old=root/".scratch/inference-system-review-20261025/nf4-component-values";const auto work=root/".scratch/nf4-typed-profile-20261025";
 auto codes=join(read(old/"weight.bin",7680,"cbe6e709c20b76eef516b2e8bf2893c319e2621d7b5dc0f3ddf4f8d0bb00fa0a"),read(work/"payload/range-000.bin",2613760,"49d54617b7ef6288c7988ffdd8f706728caaee1a880c8eec507838a7ac325b54"));
 auto indices=join(read(old/"absmax.bin",240,"214115a8d7b2f306d036502a1bece2440c314d6e024a47099124670e71646a3f"),read(work/"payload/range-001.bin",81680,"4bb908ff3528484fba1ddd68139ba3acacf7f901069b2cb489b42a32e8fba51e"));
 auto nested=join(read(old/"nested_absmax.bin",4,"5399407b8dc0c00401a5b15f2bf8f6bc0f60b93ef32c1e81e907344525c02d12"),read(work/"payload/range-002.bin",1276,"d2b2e8d33f7d1b3f8dbb31080836b4576d4bc2d5724e641b90cb04053660c399"));
 const auto books=read(old/"codebooks.bin",1088,"9bec262dd7ad4b9a4a3a8ffb16eb4769b7f69ec89c45eae4383ffee97b888385");
 const auto raw=read(old.parent_path()/"nf4-quant-state/quant-state.bin",171,"9210c25c0ca8632c7166cc3a92dc0cc43ffe528a45a11e3b8dde08941ed9d6c1");
 const auto expected=read(work/"oracle/expected-f16.bin",10485760,"297da15cee9ba93c2a9d50b154a82c07b18677f8f940e9c6a239f5c4803e5d93");
 const auto activation=read(work/"oracle/activation-f16.bin",20480,"bdf17bc0f53a4e44fe2f79241cfb2bf15c1e75206de4a4a750efe64298455c0e");
 const auto projection=read(work/"oracle/projection-f16.bin",4096,"9c219f6a7ce214419e941eda38f16015cbced17366d489a6119c63115745a482");
 auto state=q::prepared::parse_nf4_state({reinterpret_cast<const char*>(raw.data()),raw.size()});state.original_json_sha256="9210c25c0ca8632c7166cc3a92dc0cc43ffe528a45a11e3b8dde08941ed9d6c1";
 check(c::cpu::configure_runtime_threads(1));auto backend=take(hyle::inference::Backend::create({.primary=hyle::inference::BackendKind::kCpu}));
 const auto offset=std::bit_cast<float>(state.offset_f32_bits);
 const std::array<std::span<const std::byte>,6> payloads{codes,indices,nested,std::span(books).first(1024),std::as_bytes(std::span(&offset,1)),std::span(books).subspan(1024)};
 q::Nf4DecodeInputs inputs;inputs.original_json=raw;inputs.descriptions={dense(T::kUInt8,{1024,2560}),dense(T::kUInt8,{81920}),dense(T::kFloat32,{320}),dense(T::kFloat32,{256}),dense(T::kFloat32,{}),dense(T::kFloat32,{16})};
 for(std::size_t i=0;i<6;++i)inputs.ready[i]=upload(backend,payloads[i]);
 auto corrupt=raw;corrupt[0]=std::byte{'!'};inputs.original_json=corrupt;auto rejected=q::import_nf4_weight(backend,state,inputs);require(!rejected&&rejected.error().IsInvalidArgument(),"corrupt original JSON was not rejected before decode");inputs.original_json=raw;
 const auto retained_offset=inputs.ready[4];const float wrong=0;inputs.ready[4]=upload(backend,std::as_bytes(std::span(&wrong,1)));rejected=q::import_nf4_weight(backend,state,inputs);require(!rejected&&rejected.error().IsInvalidArgument(),"wrong offset operand was not rejected before decode");inputs.ready[4]=retained_offset;
 auto invalid_shape=state;invalid_shape.logical_shape[0]=3;rejected=q::import_nf4_weight(backend,invalid_shape,inputs);require(!rejected&&rejected.error().IsInvalidArgument(),"component view was mistaken for complete original shape");
 auto imported=take(q::import_nf4_weight(backend,state,inputs));require(imported.description==dense(T::kFloat16,{1024,5120})&&imported.canonical_bytes==10485760,"complete importer output shape/type differs");
 Bytes actual(expected.size());check(backend.read(take(imported.ready.view()),actual));require(actual==expected,"complete original F16 decode differs from independent reader");
 auto context=take(backend.common_context());auto queue=take(backend.common_queue());std::array<std::string,2> providers;std::array<std::size_t,2> workspaces;
 for(std::size_t rows=1;rows<=2;++rows){
  auto a=take(m::Buffer::create(backend.device(),rows*5120*2,256));check(a.view().write(std::span(activation).first(a.size())));auto y=take(m::Buffer::create(backend.device(),rows*1024*2,256));
  auto ad=dense(T::kFloat16,{std::int64_t(rows),5120});auto wd=take(imported.description.transposed());auto yd=dense(T::kFloat16,{std::int64_t(rows),1024});
  auto op=take(c::prepare(*context,c::MatMul{.accumulation_type=T::kFloat32},ad,wd,backend.device()));const auto workspace=op.workspace_requirement();m::Buffer scratch;
  if(op.runtime_properties().workspace_owner==c::ProviderWorkspaceOwner::kCaller&&workspace.size)scratch=take(m::Buffer::create(backend.device(),workspace.size,workspace.alignment));
  auto invocation=take(op.create_invocation(scratch.view()));auto done=take(invocation.submit(*queue,take(c::ConstTensorView::create(ad,a.view())),take(imported.ready.tensor(wd)),take(c::TensorView::create(yd,y.view()))));check(done.wait());
  Bytes got(y.size());check(y.view().read(got));require(std::equal(got.begin(),got.end(),projection.begin()),"complete original F16 projection differs from independent reader");providers[rows-1]=op.provider().name;workspaces[rows-1]=workspace.size;
 }
 std::cout<<"{\"status\":\"PASS\",\"actual_decoder_calls\":1,\"decoded_values\":5242880,\"decoded_bytes\":10485760,\"ordinary_projection_rows\":[1,2],\"projection_values\":3072,\"providers\":[\""<<providers[0]<<"\",\""<<providers[1]<<"\"],\"projection_workspace\":["<<workspaces[0]<<','<<workspaces[1]<<"],\"import_graph_workspace\":"<<imported.graph_workspace_bytes<<",\"bad_JSON_SHA_rejected\":true,\"bad_F32_offset_rejected\":true,\"component_as_whole_shape_rejected\":true,\"full_model\":false,\"GPU_runs\":0}\n";
 return 0;
}catch(const std::exception&e){std::cerr<<"original NF4 importer: "<<e.what()<<'\n';return 1;}}
