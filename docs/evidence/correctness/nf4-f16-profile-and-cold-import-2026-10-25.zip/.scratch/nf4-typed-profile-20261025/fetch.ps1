param([switch]$Resume)
$ErrorActionPreference = 'Stop'
$nf4TaskRoot = 'C:\public\project-hyle\hyle'
$nf4PauseMarker = Join-Path $nf4TaskRoot '.scratch/mtp-download-budget-20261023/PAUSED'
$nf4HeldMarker = Join-Path $PSScriptRoot 'download-paused-before-nf4-profile'
if ((Resolve-Path -LiteralPath $PSScriptRoot).Path -ne (Join-Path $nf4TaskRoot '.scratch/nf4-typed-profile-20261025')) { throw 'Unexpected NF4 acquisition directory' }
if (!(Test-Path -LiteralPath $nf4PauseMarker -PathType Leaf) -or (Test-Path -LiteralPath $nf4HeldMarker)) { throw 'Expected unchanged pause marker' }
Move-Item -LiteralPath $nf4PauseMarker -Destination $nf4HeldMarker
try {
  $nf4Args = @('--apply')
  if ($Resume) { $nf4Args += '--resume' }
  & python (Join-Path $nf4TaskRoot '.scratch/mtp-download-budget-20261023/budget.py') run (Join-Path $PSScriptRoot 'fetch.py') -- @nf4Args
  if ($LASTEXITCODE -ne 0) { throw "Planned NF4 acquisition failed, exit $LASTEXITCODE; partial evidence retained" }
} finally {
  if ((Test-Path -LiteralPath $nf4PauseMarker) -or !(Test-Path -LiteralPath $nf4HeldMarker -PathType Leaf)) { throw 'NF4 pause marker changed during acquisition' }
  Move-Item -LiteralPath $nf4HeldMarker -Destination $nf4PauseMarker
}
