from pathlib import Path
import hashlib,json,sys
sys.dont_write_bytecode=True
R=Path.cwd();sys.path.insert(0,str(R))
from engine.models.qwen35 import prepare
W=R/'.scratch/nf4-typed-profile-20261025'
def read(p):return json.loads(p.read_bytes())
plan=read(W/'fetch-plan.json');complete=read(W/'payload/complete.json');assert complete['status']=='EXACT_NF4_COMPONENT_AND_ALL_QUANT_STATE_RANGES_ACQUIRED'
header=read(R/'.scratch/mtp-metadata-offline-20261024/cat13/header.json');config=read(R/'.scratch/model-quantization-discovery-2026-10-19/qwen-kimi/unsloth--Qwen3.8-27B-unsloth-bnb-4bit/config.json')
geometry=prepare.geometry.from_hf(config);roles={n:v for n,v in header.items()if n.startswith(('model.language_model.','lm_head.','mtp.'))};groups=prepare.nf4_state.groups(roles,config,prepare.geometry.role_shapes(geometry));prepare.validate_role_geometry(roles,geometry,(),groups)
raws={};parts={p['ordinal']:p for p in complete['parts']}
for request in plan['requests']:
 part=parts[request['ordinal']];payload=(R/part['path']).read_bytes();response=part['response']
 assert part['range']==[request['first'],request['last']]and len(payload)==request['bytes']and hashlib.sha256(payload).hexdigest()==part['sha256']and response['status']==206 and response['etag']==plan['source']['etag']and response['final_url']==plan['url']
 for state in request.get('states',[]):
  delta=state['first']-request['first'];raws[state['role']]=(payload[delta:delta+state['bytes']],part['path'],delta)
known='model.language_model.layers.3.self_attn.k_proj.weight'+prepare.nf4_state.STATE_SUFFIX
path='.scratch/inference-system-review-20261025/nf4-quant-state/quant-state.bin';raws[known]=((R/path).read_bytes(),path,0)
assert len(raws)==len(groups)==352
result=[];manifest=[]
for name,group in sorted(groups.items()):
 raw,path,offset=raws[name+prepare.nf4_state.STATE_SUFFIX];state=prepare.nf4_state.parse(raw,group['logical_shape']);item=dict(role=name,path=path,offset=offset,bytes=len(raw),**state);result.append(item)
 assert offset==0 # Current exact-coalescing has one state per Range.
 manifest.append('\t'.join([str(group['logical_shape'][0]),str(group['logical_shape'][1]),state['offset_f32_bits'],state['original_json_sha256'],json.dumps(str(R/path))]))
(W/'states-manifest.tsv').write_text('\n'.join(manifest)+'\n')
x=dict(status='ALL_352_ORIGINAL_QUANT_STATES_PASS',groups=352,original_bytes=sum(x['bytes']for x in result),decode='F16',compute='F16',main_group=64,nested_group=256,nested_dtype='F32',all_shapes_match_original_header=True,per_group_offset_and_JSON_SHA_preserved=True,raw_states=result,full_model_body_present=False,new_HTTP=0)
(W/'states-audit.json').write_text(json.dumps(x,indent=2)+'\n');print(json.dumps({k:v for k,v in x.items()if k!='raw_states'},indent=2))
