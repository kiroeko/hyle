from pathlib import Path
import hashlib
import importlib.util
import json
import shutil

root = Path(__file__).resolve().parents[2]
base = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('retained_build',root/'.scratch/mtp-extraction-regression-20261024/check.py')
build = importlib.util.module_from_spec(spec)
spec.loader.exec_module(build)
original_base = root/'.scratch/inference-system-review-20261025/schedule-inputs'
original = build.args(original_base/'compile/command.json')
frozen = base/'source'
paths = [root/'engine/models/qwen35/main.cc']
for directory in ('engine/models/qwen35','engine/inference','engine/reporting'):
    paths.extend(sorted((root/directory).glob('*.h')))
paths.extend(root/'tests/tools'/name for name in ('qwen_request_lifecycle_test.cc','qwen_chunked_prefill_case.h','qwen_dual_model_case.h'))
pins = []
for path in paths:
    target = frozen/path.relative_to(root)
    target.parent.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(path,target)
    pins.append(dict(path=path.relative_to(root).as_posix(),bytes=path.stat().st_size,
                     sha256=hashlib.sha256(path.read_bytes()).hexdigest()))
build.save(base/'source-pins.json',pins)
flags = []
skip = False
for arg in original[1:]:
    if skip:
        skip=False
        continue
    if arg == '/sourceDependencies':
        skip=True
        continue
    if arg.lower().startswith(('/fo','/fd')) or arg.lower().endswith(('.cc','.cpp')):
        continue
    flags.append(arg.replace(str(original_base/'source'),str(frozen)))
assert '/W4' in flags and '/WX' in flags
output=base/'strict-syntax2'
build.execute([original[0],*flags,'/Zs',str(frozen/'tests/tools/qwen_request_lifecycle_test.cc'),
    '/sourceDependencies',str(output/'dependencies.json')],output,build.environment(original[0]),90)
for pin in pins:
    assert hashlib.sha256((root/pin['path']).read_bytes()).hexdigest()==pin['sha256'],pin['path']
build.save(base/'summary.json',dict(status='STRICT_COMBINED_INTERFACE_SYNTAX_PASS',
    scope='Frozen current NF4 F16 profile plus canonical lifecycle/chunked/dual-model/host-retirement driver. No object/link, GPU, model execution or full CMake configure.',
    source_files=len(pins),source_bytes=sum(p['bytes'] for p in pins),source_pins='source-pins.json',
    process='strict-syntax2/process.json',
    preparation_attempt1='Runner created its output directory before helper mkdir(exist_ok=False); rejected before compiler launch. Empty first directory retained.'))
print(json.dumps(dict(status='STRICT_COMBINED_INTERFACE_SYNTAX_PASS',source_files=len(pins),source_bytes=sum(p['bytes'] for p in pins))))
