from pathlib import Path
import sys,importlib.util,json,hashlib,os
sys.dont_write_bytecode=True
R=Path.cwd();D=R/'.scratch/inference-system-review-20261025/schedule-inputs'
spec=importlib.util.spec_from_file_location('retained',R/'.scratch/mtp-extraction-regression-20261024/check.py')
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
def require(x,m):
 if not x:raise RuntimeError(m)
image=D/'link/hyle.exe';inputs=R/'.scratch/qwen35-unsloth-mtp-20261024/geometry-v2-check/original'
ready=b.read(D/'ready.json');require(b.pin(image)==ready['image'],'image changed')
case=D/'case';case.mkdir(exist_ok=False)
prompt=list(map(int,(inputs/'prompt.ids').read_text().split()))
(case/'prompt.ids').write_text(' '.join(map(str,prompt))+'\n',encoding='utf-8')
(case/'empty.ids').write_text('',encoding='utf-8')
(case/'pending-only.schedule').write_text('prompt prompt.ids\ngenerate 3\nprompt empty.ids\ngenerate 2\n',encoding='utf-8')
(case/'sessions.txt').write_text('continued pending-only.schedule\n',encoding='utf-8')
command=[str(image),'--inputs',str(inputs),'--session-schedules',str(case/'sessions.txt'),'--backend','cuda','--mtp','off','--sampling','greedy','--capacity',str(len(prompt)+4),'--max-sessions','1','--active-sequences','1','--cache-bytes','536870912','--prefix-cache','off','--progress','direct','--replay','commands','--trace-level','decisions']
env=os.environ.copy();env.update({k:v for k,v in b.read(R/'.scratch/mtp-performance-convergence-20261025/baseline/runtime.json').items() if isinstance(v,str)})
env['PATH']=str(D/'link')+';'+env['PATH']
b.execute(command,D/'run',env,180)
reports=[json.loads(x) for x in (D/'run/stdout.log').read_text(encoding='utf-8').splitlines() if x.startswith('{')]
require(len(reports)==1,'expected one aggregate report')
r=reports[0];b.save(D/'run/consumer-result.json',r)
require(not r['mtp'] and r['backend']=='cuda' and r['session_count']==1 and r['turn_count']==2,'wrong actual mode/domain')
require(r['text_tensors']==320 and r['mtp_tensors']==r['draft_program_graph_calls']==r['prefix_decision_graph_calls']==r['frontier_sampling_graph_calls']==0,'ordinary selected draft resources')
require(r['requested_output_tokens']==r['generated_tokens']==5 and r['pending_flushed_tokens']==1 and r['logical_user_prompt_tokens']==len(prompt),'output/pending/user count changed')
require(r['cache_live_requested_bytes']<=r['cache_requested_byte_limit'] and r['peak_committed_versions']<=1,'finite cache/version budget exceeded')
require(len(r['sessions'])==1,'missing per-request result')
s=r['sessions'][0]['result'];ids=s['generated_ids'];turns=s['turns']
require(len(ids)==5 and ids[:3]==[71093,12305,198],'first turn changed from the retained real R2 reference')
require(s['sampling_draw_cursor']==0 and s['visible_tokens']==len(prompt)+4,'greedy RNG/committed length changed')
require(len(turns)==2 and turns[0]['input_ids']==prompt and turns[0]['context_before']==0 and turns[0]['context_after']==len(prompt)+2 and turns[0]['output_begin']==0 and turns[0]['output_end']==3,'first turn extent/output changed')
require(turns[1]['new_user_tokens']==0 and turns[1]['pending_flushed']==1 and turns[1]['input_ids']==[ids[2]] and turns[1]['context_before']==len(prompt)+2 and turns[1]['context_after']==len(prompt)+4 and turns[1]['output_begin']==3 and turns[1]['output_end']==5,'second turn did not consume exactly the historical pending once')
ledger=r['sessions'][0]['ledger']
require(len(ledger)==5 and all(not x['imported'] and x['role']==0 and x['draft_rows']==0 and x['after_frontier']==x['after_lag']==0 and x['sampling_draw_before']==x['sampling_draw_after']==0 for x in ledger),'not five genuine ordinary committed records')
require([x['after_length'] for x in ledger]==[len(prompt)+i for i in range(5)],'ordinary KV lengths gap/duplicate')
require([x['next_id'] for x in ledger]==ids and ledger[3]['first_input']==ids[2] and ledger[3]['input_rows']==1 and ledger[3]['before_length']==len(prompt)+2 and ledger[3]['after_length']==len(prompt)+3,'pending-only actual graph commit mismatches host input')
require(ledger[4]['first_input']==ids[3] and ledger[4]['input_rows']==1,'second output consumed wrong token')
b.save(D/'run/assertions.json',{'status':'PASS','generated_ids':ids,'turns':turns,'committed_records':ledger,'actual_calls':r['actual_graph_calls'],'cache_peak_bytes':r['cache_peak_requested_bytes'],'cache_limit_bytes':r['cache_requested_byte_limit'],'ordinary_only':True,'draft_resources':False,'sampling_draw_cursor':0,'pending_consumed_once':True,'new_user_tokens_second_turn':0,'performance_claim':False,'quality_claim':False})
print(json.dumps({'status':'PASS','generated_ids':ids,'second_input':turns[1]['input_ids'],'visible_tokens':s['visible_tokens'],'model_processes':1}),flush=True)
