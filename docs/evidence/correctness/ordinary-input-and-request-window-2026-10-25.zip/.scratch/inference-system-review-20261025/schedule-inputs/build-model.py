from pathlib import Path
import importlib.util,sys,hashlib,json,os
sys.dont_write_bytecode=True
R=Path.cwd();D=R/'.scratch/inference-system-review-20261025/schedule-inputs'
spec=importlib.util.spec_from_file_location('retained',R/'.scratch/mtp-extraction-regression-20261024/check.py')
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
previous=R/'.scratch/inference-system-review-20261025/text-r2-suffix'
original=b.args(previous/'compile/command.json')
flags=[];skip=False
for x in original[1:]:
 if skip:skip=False;continue
 if x=='/sourceDependencies':skip=True;continue
 if x.lower().startswith(('/fo','/fd')) or x.lower().endswith(('.cc','.cpp')):continue
 flags.append(x)
probe=D/'probe.cc'
probe.write_text('#include "engine/models/qwen35/main.cc"\nint main(int argc, char **argv) { return qwen35::run(argc, argv); }\n',encoding='utf-8')
files={str(R/'engine/models/qwen35/main.cc'),str(R/'engine/models/qwen35/token_ids.h')}
for pin in b.read(previous/'compile/actual-source-pins.json'):files.add(pin['path'])
files.update(str(p) for p in (R/'engine/models/qwen35').glob('*.h'))
files.update(str(p) for p in (R/'engine/inference').glob('*.h'))
files=sorted({str(Path(p).resolve()) for p in files})
before=[b.pin(Path(p)) for p in files]
b.save(D/'model-before-pins.json',before)
command=[original[0],*flags,str(probe),'/sourceDependencies',str(D/'compile/dependencies.json'),'/Fo'+str(D/'compile/unit.obj'),'/Fd'+str(D/'compile/unit.pdb')]
env=b.environment(original[0]);b.execute(command,D/'compile',env,90)
after=[b.pin(Path(p)) for p in files]
if before!=after:raise RuntimeError('Current sources changed during app TU compilation')
dep=b.read(D/'compile/dependencies.json')['Data'];actual=[]
for name in [dep['Source'],*dep['Includes']]:
 p=Path(name).resolve()
 if p.is_relative_to(R) and (str(p).lower().startswith(str(R/'engine').lower()) or p==probe):actual.append(b.pin(p))
b.save(D/'compile/actual-source-pins.json',actual)
freeze=D/'source'
for pin in actual:
 p=Path(pin['path']);q=freeze/p.relative_to(R);q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(p.read_bytes())
old=b.args(previous/'link/command.json');oldobj=str(previous/'compile/unit.obj').lower();filtered=[];replaced=0
for x in old[1:]:
 if x.lower()==oldobj:filtered.append(str(D/'compile/unit.obj'));replaced+=1
 elif not x.lower().startswith(('/out:','/pdb:','/map:','/implib:')):filtered.append(x)
if replaced!=1:raise RuntimeError('Expected exactly one prior consumer object')
b.execute([old[0],*filtered,'/OUT:'+str(D/'link/hyle.exe'),'/IMPLIB:'+str(D/'link/hyle.lib')],D/'link',env,90)
native=previous/'link/hyle_ggml_cpu_gdn_scale_v3.dll';os.link(native,D/'link'/native.name)
b.save(D/'ready.json',{'image':b.pin(D/'link/hyle.exe'),'object':b.pin(D/'compile/unit.obj'),'native':b.pin(D/'link'/native.name),'sources':actual,'scope':'One current consumer TU + existing retained SDK/native closure, no native/SDK rebuild, no HTTP.'})
print(json.dumps({'ready':b.pin(D/'link/hyle.exe'),'app_sources':len(actual)}),flush=True)
