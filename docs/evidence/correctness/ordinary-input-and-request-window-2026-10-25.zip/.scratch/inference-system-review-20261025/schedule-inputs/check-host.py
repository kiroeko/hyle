from pathlib import Path
import importlib.util,sys,json,hashlib
sys.dont_write_bytecode=True
R=Path.cwd();D=R/'.scratch/inference-system-review-20261025/schedule-inputs'
spec=importlib.util.spec_from_file_location('retained',R/'.scratch/mtp-extraction-regression-20261024/check.py')
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
original=b.args(R/'.scratch/inference-request-progress-20261025/host/qwen_generation_schedule_test/compile/command.json')
source=R/'tests/tools/qwen_generation_schedule_test.cc';target=D/(sys.argv[1] if len(sys.argv)>1 else 'host');target.mkdir(exist_ok=False)
files=[source,*[R/'engine/models/qwen35'/n for n in ['token_ids.h','schedule.h','generation_schedule.h','session_schedule.h']],R/'engine/inference/request_progress.h',R/'engine/inference/sampling_cursor.h']
before=[b.pin(p) for p in files]
command=[];skip=False
for x in original:
 if skip:skip=False;continue
 if x=='/sourceDependencies':skip=True;continue
 if x.lower().startswith(('/fo','/fe')) or x.lower().endswith('.cc'):continue
 command.append(x)
command += ['/sourceDependencies',str(target/'compile/dependencies.json'),str(source),'/Fo'+str(target/'compile/host.obj'),'/Fe'+str(target/'compile/checks.exe')]
env=b.environment(command[0]);b.execute(command,target/'compile',env,60)
b.execute([str(target/'compile/checks.exe'),str(target/'fixture')],target/'run',env,30)
after=[b.pin(p) for p in files]
if before!=after:raise RuntimeError('Host source changed during compilation/run')
b.save(target/'summary.json',{'status':'PASS','before':before,'after':after,'compile':b.read(target/'compile/process.json'),'run':b.read(target/'run/process.json'),'scope':'Actual existing std-only schedule parser regression; one TU, no native SDK/model/network.'})
