from pathlib import Path
import importlib.util,sys,os,json
sys.dont_write_bytecode=True
R=Path.cwd();D=R/'.scratch/inference-system-review-20261025/schedule-inputs'
spec=importlib.util.spec_from_file_location('retained',R/'.scratch/mtp-extraction-regression-20261024/check.py')
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
env=os.environ.copy();env.update({k:v for k,v in b.read(R/'.scratch/mtp-performance-convergence-20261025/baseline/runtime.json').items() if isinstance(v,str)})
env['PATH']=str(D/'link')+';'+env['PATH']
command=[sys.executable,str(R/'tests/tooling/qwen_text_prefix_batch_test.py'),'check','--image',str(D/'link/hyle.exe'),'--inputs',str(R/'.scratch/qwen35-unsloth-mtp-20261024/geometry-v2-check/original'),'--case',str(R/'.scratch/inference-system-review-20261025/text-r2-suffix/case'),'--output',str(D/'r2-control')]
b.execute(command,D/'r2-driver',env,180)
print(json.dumps(b.read(D/'r2-control/assertions.json')),flush=True)
