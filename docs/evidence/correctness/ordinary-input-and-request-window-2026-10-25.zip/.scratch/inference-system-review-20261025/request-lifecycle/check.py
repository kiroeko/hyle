"""Two existing std-only consumers, bounded live RequestWindow API; no SDK/model/GPU."""
from pathlib import Path
import importlib.util
import json
import subprocess
import sys

sys.dont_write_bytecode = True
D = Path(__file__).resolve().parent
R = D.parents[2]
spec = importlib.util.spec_from_file_location('retained_host', R / '.scratch/mtp-extraction-regression-20261024/check.py')
b = importlib.util.module_from_spec(spec)
spec.loader.exec_module(b)
sources = [R / 'engine/inference/request_window.h', R / 'tests/tools/inference_request_window_test.cc',
           R / 'tests/tools/inference_request_progress_test.cc', R / 'engine/inference/request_progress.h']
pins = [b.pin(p) for p in sources]
cases = [
    ('window', R / 'tests/tools/inference_request_window_test.cc',
     R / '.scratch/inference-request-window-20261024/host/compile/command.json'),
    ('progress', R / 'tests/tools/inference_request_progress_test.cc',
     R / '.scratch/inference-request-progress-20261025/host/inference_request_progress_test/compile/command.json')]
results = {}
for name, source, reference in cases:
    original = b.args(reference)
    command, skip = [], False
    for word in original:
        if skip:
            skip = False
            continue
        if word == '/sourceDependencies':
            skip = True
            continue
        if word.lower().startswith(('/fo', '/fe')) or word.lower().endswith('.cc'):
            continue
        command.append(word)
    folder = D / name / 'compile'
    command.extend(['/sourceDependencies', str(folder / 'dependencies.json'), str(source),
                    '/Fo'+str(folder / 'host.obj'), '/Fe'+str(folder / 'checks.exe')])
    env = b.environment(original[0])
    b.execute(command, folder, env, 60)
    b.execute([str(folder / 'checks.exe')], D / name / 'run', env, 30)
    results[name] = dict(compile=b.read(folder / 'process.json'), run=b.read(D / name / 'run/process.json'),
                         stdout=(D / name / 'run/stdout.log').read_text())
assert pins == [b.pin(p) for p in sources], 'Source changed during strict host checks'
patch = subprocess.run(['git', 'diff', '--', *(str(p.relative_to(R)) for p in sources[:3])],
                       cwd=R, capture_output=True, check=True).stdout
(D / 'changes.patch').write_bytes(patch)
b.save(D / 'summary.json', dict(status='passed_two_existing_std_only_consumers', sources=pins, results=results,
    scope='Bounded FIFO slots/generation/queued cancellation and explicit caller retirement release; no active device cancellation or output backpressure integration claimed.',
    model_processes=0, GPU_processes=0, SDK_builds=0, HTTP=0))
files = [b.pin(p) for name, _, _ in cases for p in (D / name / 'compile').iterdir()
         if p.is_file() and p.suffix.lower() in {'.obj', '.exe', '.pdb', '.lib', '.exp'}]
b.save(D / 'cleanup-candidates.json', dict(performed=False, files=files,
    logical_bytes=sum(p['bytes'] for p in files)))
print(json.dumps(dict(status='passed', cases=results), indent=2))
