"""Six explicit native actions using the existing Windows driver; parse is offline."""
from pathlib import Path
import importlib.util
import json
import sys
sys.dont_write_bytecode = True
W=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('episode_build',W/'build.py')
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
t=b.t
FIXTURE=b.R/'.scratch/inference-paged-frame-20261026/tiny-recursive-input'
CASES={'logits-cpu':('tiny',['--cpu',str(FIXTURE),'--mtp-logits']),
       'logits-cuda':('tiny',['--cuda',str(FIXTURE),'--mtp-logits']),
       'batch-state-cpu':('tiny',['--cpu',str(FIXTURE),'--mtp-batch-state']),
       'batch-state-cuda':('tiny',['--cuda',str(FIXTURE),'--mtp-batch-state']),
       'relay-cuda':('relay',['--cuda',str(FIXTURE)]),
       'submission-relay-cuda':('submission-source',['--relay','--cuda',str(FIXTURE)])}


def prepare():
    b.validate();ready={name:t.read(W/f'ready-{name}.json') for name in b.SOURCES}
    for row in ready.values(): t.exact(row['image']);t.exact(row['inputs'])
    t.save(W/'run-plan.json',dict(script=t.pin(__file__),parser=t.pin(W/'parse.py'),
        fixture=t.pin(FIXTURE/'weights.tsv'),runtime=t.pin(W/'runtime.json'),
        cases={name:dict(consumer=unit,ready=t.pin(W/f'ready-{unit}.json'),
            command=[ready[unit]['image']['path'],*args]) for name,(unit,args) in CASES.items()},
        native_processes=6,automatic_retries=0,scope='Four Tiny CPU/CUDA plus distinct batch relay and singleQueue submission-source gate. No Vulkan unknown-native retest, performance, download or new SDK.'))
    print('RUN PLAN READY6; no model started')


def parse_case(name):
    spec=importlib.util.spec_from_file_location('episode_offline_parser',W/'parse.py')
    parser=importlib.util.module_from_spec(spec);spec.loader.exec_module(parser)
    backend,kind,_=parser.CASES[name];out=W/'runs'/name;process=t.read(out/'process.json')
    assert process['exit']==0 and not process['timed_out']
    reports=[json.loads(line) for line in (out/'stdout.log').read_text(encoding='utf-8-sig').splitlines() if line.startswith('{')]
    assert len(reports)==1;parser.check_report(reports[0],backend,kind)
    print('OFFLINE PASS',name)


def run(name):
    b.validate();plan=t.read(W/'run-plan.json')
    for key in ('script','parser','fixture','runtime'):t.exact(plan[key])
    row=plan['cases'][name];t.exact(row['ready']);ready=t.read(row['ready']['path']);t.exact(ready['image'])
    out=W/'runs'/name;assert not out.exists(),'Never rerun or overwrite any native attempt'
    t.execute(row['command'],out,300);parse_case(name)


if __name__=='__main__':
    if sys.argv[1]=='prepare':prepare()
    elif sys.argv[1]=='run':run(sys.argv[2])
    elif sys.argv[1]=='parse':parse_case(sys.argv[2])
    else:raise ValueError(sys.argv[1])
