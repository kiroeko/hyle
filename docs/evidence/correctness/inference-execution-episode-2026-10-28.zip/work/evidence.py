"""One final offline evidence package after the six real cases finish."""
from pathlib import Path
import difflib
import hashlib
import importlib.util
import json
import sys
import zipfile

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = W.parent.parent
DEST = R / 'docs/evidence/correctness/inference-execution-episode-2026-10-28'
UNITS = ['tiny', 'relay', 'submission-source']


def read(path):
    return json.loads(Path(path).read_bytes())


def digest(data):
    return hashlib.sha256(data).hexdigest()


def pin(path):
    path = Path(path); data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=digest(data))


def body(value):
    return (json.dumps(value, indent=2, ensure_ascii=False) + '\n').encode('utf-8')


def same_pin(path, identity):
    actual = pin(path)
    assert (actual['bytes'], actual['sha256']) == (identity['bytes'], identity['sha256']), str(path)


def main():
    assert not DEST.with_suffix('.json').exists() and not DEST.with_suffix('.zip').exists(), 'Never overwrite a prior evidence package'
    spec = importlib.util.spec_from_file_location('episode_strict_offline_parser', W / 'parse.py')
    parser = importlib.util.module_from_spec(spec); spec.loader.exec_module(parser)
    analysis = read(W / 'analysis.json')
    assert analysis['status'] == 'PASS_SIX_FINITE_EPISODE_CASES' and analysis['native_processes'] == 6
    assert analysis['state_byte_checks'] == 20
    members = {}

    def add(path, name=None):
        path = Path(path)
        name = name or 'work/' + path.relative_to(W).as_posix()
        assert name not in members and not name.lower().endswith(('.exe', '.obj', '.dll', '.lib', '.pdb'))
        members[name] = path.read_bytes()

    for f in ['build.py', 'run.py', 'parse.py', 'evidence.py', 'analysis.json', 'run-plan.json',
              'final-build-plan.json', 'final-source-freeze.json', 'frozen-project-dependencies.json',
              'runtime.json', 'runtime-hardlink-prepared.json', 'pre-cxx-refinement.json']:
        add(W / f)
    freeze = read(W / 'final-source-freeze.json')
    same_pin(W / 'build.py', freeze['helper'])
    for row in freeze['snapshots']:
        same_pin(row['original']['path'], row['original'])
        same_pin(row['snapshot']['path'], row['snapshot'])
        relative = Path(row['original']['path']).relative_to(R)
        add(row['snapshot']['path'], 'source/after/' + relative.as_posix())
    add(W / 'main-before.cc', 'source/before/engine/models/qwen35/main.cc')

    # Retain closure identities once; each consumer changes only the one object.
    plan = read(W / 'final-build-plan.json')
    assert sorted(p.parent.name for p in (W / 'logs').glob('*/process.json')) == sorted(UNITS)
    assert sorted(p.parent.name for p in (W / 'links').glob('*/process.json')) == sorted(UNITS)
    assert sorted(p.parent.name for p in (W / 'runs').glob('*/process.json')) == sorted(parser.CASES)
    base = read(plan['inputs']['path'])
    assert len(base) == 228 and base.count(plan['original_object']) == 1
    members['identity/base-link-inputs.json'] = body(base)
    replacement_index = base.index(plan['original_object'])
    units = []; dependency_union = {}
    for unit in UNITS:
        ready = read(W / f'ready-{unit}.json')
        compiled = read(W / f'compile/{unit}/compiled.json')
        cxx_process = read(W / f'logs/{unit}/process.json')
        link_process = read(W / f'links/{unit}/process.json')
        assert cxx_process == compiled['process'] and link_process == ready['process']
        assert cxx_process['exit'] == link_process['exit'] == 0
        assert not cxx_process['timed_out'] and not link_process['timed_out']
        assert ready['compiled'] == compiled
        inputs = read(ready['inputs']['path'])
        expected = list(base); expected[replacement_index] = compiled['object']
        assert inputs == expected
        same_pin(ready['inputs']['path'], ready['inputs'])
        units.append(dict(name=unit, compilation=compiled, link=link_process, image=ready['image'],
                          link_inputs=ready['inputs'], replacement_index=replacement_index,
                          replacement_object=compiled['object'], recipe=ready['recipe']))
        for f in [f'recipes/{unit}.json', f'link-recipes/{unit}.json', f'ready-{unit}.json',
                  f'compile/{unit}/compiled.json', f'compile/{unit}/dependencies.json']:
            add(W / f)
        for directory in [W / 'logs' / unit, W / 'links' / unit]:
            for f in ['command.json', 'process.json', 'stdout.log', 'stderr.log']: add(directory / f)
        for item in read(W / f'compile/{unit}/actual-dependencies.json'):
            key = item['path'].replace('\\', '/').lower()
            if key in dependency_union: assert dependency_union[key] == item
            else: dependency_union[key] = item
    members['identity/actual-dependency-identities.json'] = body(list(dependency_union.values()))

    run_plan = read(W / 'run-plan.json')
    assert set(run_plan['cases']) == set(parser.CASES)
    assert len(analysis['cases']) == 6
    native = []
    for row in analysis['cases']:
        name = row['name']; backend, kind, _ = parser.CASES[name]
        out = W / 'runs' / name
        process = read(out / 'process.json'); command = read(out / 'command.json')
        reports = [json.loads(line) for line in (out / 'stdout.log').read_text(encoding='utf-8-sig').splitlines() if line.startswith('{')]
        assert process == row['process'] and command == row['command']
        assert command['command'] == run_plan['cases'][name]['command']
        assert len(reports) == 1 and reports[0] == row['report']
        assert process['exit'] == 0 and process['state'] == 'TERMINAL' and not process['timed_out']
        parser.check_report(reports[0], backend, kind)
        native.append(dict(name=name, process=process, backend=backend,
                           kind=kind, state_byte_checks=len(reports[0].get('state_checks', []))))
        for f in ['command.json', 'process.json', 'stdout.log', 'stderr.log']: add(out / f)
    assert len({row['process']['pid'] for row in native}) == 6

    # The two chronological manifests are complete mechanical edits. Reverse
    # them only in memory to form one final reviewable diff per affected file.
    edits = [read(R / '.scratch/step-composition-edits-20261028.json'),
             read(R / '.scratch/step-composition-method-edits-20261028.json')]
    for f in ['step-composition-edits-20261028.json', 'step-composition-method-edits-20261028.json']:
        add(R / '.scratch' / f, 'migration/' + f)
    paths = dict.fromkeys(entry['file'] for group in edits for entry in group)
    changed = []
    for file in paths:
        path = R / file; after = path.read_bytes(); lines = after.decode('utf-8').splitlines(keepends=True)
        for group in reversed(edits):
            for entry in group:
                if entry['file'] != file: continue
                for edit in entry['edits']:
                    i = edit['line'] - 1; suffix = lines[i][len(lines[i].rstrip('\r\n')):]
                    assert lines[i].rstrip('\r\n') == edit['after'], (file, edit['line'])
                    lines[i] = edit['before'] + suffix
        before = ''.join(lines).encode('utf-8')
        relative = path.relative_to(R).as_posix()
        diff = ''.join(difflib.unified_diff(before.decode('utf-8').splitlines(keepends=True),
                                          after.decode('utf-8').splitlines(keepends=True),
                                          fromfile='a/' + relative, tofile='b/' + relative))
        members['diff/' + relative + '.diff'] = diff.encode('utf-8')
        changed.append(dict(file=relative, before_sha256=digest(before), after_sha256=digest(after)))
    before = (W / 'main-before.cc').read_text(encoding='utf-8').splitlines(keepends=True)
    after = (W / 'source/engine/models/qwen35/main.cc').read_text(encoding='utf-8').splitlines(keepends=True)
    members['diff/engine/models/qwen35/main.cc.diff'] = ''.join(difflib.unified_diff(
        before, after, fromfile='a/engine/models/qwen35/main.cc', tofile='b/engine/models/qwen35/main.cc')).encode('utf-8')

    refinement = read(W / 'pre-cxx-refinement.json')
    assert refinement['stage'] == 'PRE_CXX_METADATA_REFINEMENT_NO_NATIVE_OR_COMPILER'
    summary = dict(schema='hyle.execution-episode.finite-correctness.v1', status=analysis['status'],
        scope='Shared model-independent resource episode composed into the existing Step; model selection, publication, request policy and ledger remain in the consumer.',
        claims=dict(performance_improvement=False, complete_inference_core=False, native_unknown_retirement_tested=False),
        actual_counts=dict(CXX=3, links=3, native_processes=6, SDK_CXX=0, NVCC=0, downloads=0, state_byte_checks=20),
        compilation_and_closures=units, native_cases=native, mechanical_migrations=changed,
        mechanical_batches=[dict(files=len(group), changed_lines=sum(len(item['edits']) for item in group)) for group in edits],
        pre_cxx_refinement=dict(reason=refinement['reason'], old_main_sha256=refinement['old_main_sha'],
            new_main_sha256=refinement['new_main_sha'], CXX_before_refinement=0,
            note='Freeze 1 to freeze 2 only removed forwarding methods and adjusted existing accesses before any CXX; historical duplicate snapshots are not repackaged.'),
        previous_driver_identity=plan['original_driver'],
        limits=['Finite CPU/CUDA synthetic fixture consumers only; no model-quality or performance claim.',
                'The controlled CUDA Source gate is actual pending work, but is not an unknown-device-retirement failure injection.',
                'Vulkan/Apple and Model-teardown unknown-retirement cases were not rerun in this slice.',
                'SDK, executable, object, runtime DLL, weights and duplicate historical archives are excluded; their identities are retained.'])
    members['summary.json'] = body(summary)
    manifest = [dict(name=name, bytes=len(data), sha256=digest(data)) for name, data in sorted(members.items())]
    members['manifest.json'] = body(dict(members=manifest, excludes_itself=True))
    DEST.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(DEST.with_suffix('.zip'), 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for name, data in sorted(members.items()): archive.writestr(name, data)
    archive_identity = pin(DEST.with_suffix('.zip'))
    summary['archive'] = dict(path=archive_identity['path'], bytes=archive_identity['bytes'],
                              sha256=archive_identity['sha256'], members=len(members))
    with DEST.with_suffix('.json').open('x', encoding='utf-8') as stream:
        stream.write(json.dumps(summary, indent=2, ensure_ascii=False) + '\n')
    print(json.dumps(dict(status=summary['status'], archive=summary['archive'], actual_counts=summary['actual_counts'])))


if __name__ == '__main__':
    main()
