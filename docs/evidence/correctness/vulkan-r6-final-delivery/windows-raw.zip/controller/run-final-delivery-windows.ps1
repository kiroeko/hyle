$ErrorActionPreference = 'Stop'
. C:/hyle-scratch/r3-cpu-20260916/msvc-env.ps1
$env:PATH = 'C:/public/tools/glslang;' + $env:PATH
python C:/hyle-scratch/r6-vulkan-20260917/verify-final-delivery.py `
    --root C:/hyle-scratch/r6-vulkan-20260917/final-delivery-20a029ad `
    --archive C:/hyle-scratch/r6-vulkan-20260917/source-package-20a029ad/dist/hyle-0.1.0-source.zip `
    --sha256 22d4cce9a4f9c9f912b62877c8bc2a13a6d17f08a96d40c5499a3dbb5e3c5fa6
exit $LASTEXITCODE
