#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "hyle::_factor_error" for configuration "Release"
set_property(TARGET hyle::_factor_error APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(hyle::_factor_error PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libhyle_error.0.1.0.dylib"
  IMPORTED_SONAME_RELEASE "@rpath/libhyle_error.0.1.0.dylib"
  )

list(APPEND _cmake_import_check_targets hyle::_factor_error )
list(APPEND _cmake_import_check_files_for_hyle::_factor_error "${_IMPORT_PREFIX}/lib/libhyle_error.0.1.0.dylib" )

# Import target "hyle::_factor_time" for configuration "Release"
set_property(TARGET hyle::_factor_time APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(hyle::_factor_time PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libhyle_time.0.1.0.dylib"
  IMPORTED_SONAME_RELEASE "@rpath/libhyle_time.0.1.0.dylib"
  )

list(APPEND _cmake_import_check_targets hyle::_factor_time )
list(APPEND _cmake_import_check_files_for_hyle::_factor_time "${_IMPORT_PREFIX}/lib/libhyle_time.0.1.0.dylib" )

# Import target "hyle::_factor_platform" for configuration "Release"
set_property(TARGET hyle::_factor_platform APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(hyle::_factor_platform PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libhyle_platform.0.1.0.dylib"
  IMPORTED_SONAME_RELEASE "@rpath/libhyle_platform.0.1.0.dylib"
  )

list(APPEND _cmake_import_check_targets hyle::_factor_platform )
list(APPEND _cmake_import_check_files_for_hyle::_factor_platform "${_IMPORT_PREFIX}/lib/libhyle_platform.0.1.0.dylib" )

# Import target "hyle::_factor_platform_thread" for configuration "Release"
set_property(TARGET hyle::_factor_platform_thread APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(hyle::_factor_platform_thread PROPERTIES
  IMPORTED_LINK_DEPENDENT_LIBRARIES_RELEASE "hyle::_factor_platform"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libhyle_platform_thread.0.1.0.dylib"
  IMPORTED_SONAME_RELEASE "@rpath/libhyle_platform_thread.0.1.0.dylib"
  )

list(APPEND _cmake_import_check_targets hyle::_factor_platform_thread )
list(APPEND _cmake_import_check_files_for_hyle::_factor_platform_thread "${_IMPORT_PREFIX}/lib/libhyle_platform_thread.0.1.0.dylib" )

# Import target "hyle::_factor_mem" for configuration "Release"
set_property(TARGET hyle::_factor_mem APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(hyle::_factor_mem PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libhyle_mem.0.1.0.dylib"
  IMPORTED_SONAME_RELEASE "@rpath/libhyle_mem.0.1.0.dylib"
  )

list(APPEND _cmake_import_check_targets hyle::_factor_mem )
list(APPEND _cmake_import_check_files_for_hyle::_factor_mem "${_IMPORT_PREFIX}/lib/libhyle_mem.0.1.0.dylib" )

# Import target "hyle::_factor_container" for configuration "Release"
set_property(TARGET hyle::_factor_container APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(hyle::_factor_container PROPERTIES
  IMPORTED_LINK_DEPENDENT_LIBRARIES_RELEASE "hyle::_factor_platform"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libhyle_container.0.1.0.dylib"
  IMPORTED_SONAME_RELEASE "@rpath/libhyle_container.0.1.0.dylib"
  )

list(APPEND _cmake_import_check_targets hyle::_factor_container )
list(APPEND _cmake_import_check_files_for_hyle::_factor_container "${_IMPORT_PREFIX}/lib/libhyle_container.0.1.0.dylib" )

# Import target "hyle::_factor_compute" for configuration "Release"
set_property(TARGET hyle::_factor_compute APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(hyle::_factor_compute PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libhyle_compute.0.1.0.dylib"
  IMPORTED_SONAME_RELEASE "@rpath/libhyle_compute.0.1.0.dylib"
  )

list(APPEND _cmake_import_check_targets hyle::_factor_compute )
list(APPEND _cmake_import_check_files_for_hyle::_factor_compute "${_IMPORT_PREFIX}/lib/libhyle_compute.0.1.0.dylib" )

# Import target "hyle::_factor_graph" for configuration "Release"
set_property(TARGET hyle::_factor_graph APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(hyle::_factor_graph PROPERTIES
  IMPORTED_LINK_DEPENDENT_LIBRARIES_RELEASE "hyle::_factor_container"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libhyle_graph.0.1.0.dylib"
  IMPORTED_SONAME_RELEASE "@rpath/libhyle_graph.0.1.0.dylib"
  )

list(APPEND _cmake_import_check_targets hyle::_factor_graph )
list(APPEND _cmake_import_check_files_for_hyle::_factor_graph "${_IMPORT_PREFIX}/lib/libhyle_graph.0.1.0.dylib" )

# Import target "hyle::_factor_compute_ops" for configuration "Release"
set_property(TARGET hyle::_factor_compute_ops APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(hyle::_factor_compute_ops PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libhyle_compute_ops.0.1.0.dylib"
  IMPORTED_SONAME_RELEASE "@rpath/libhyle_compute_ops.0.1.0.dylib"
  )

list(APPEND _cmake_import_check_targets hyle::_factor_compute_ops )
list(APPEND _cmake_import_check_files_for_hyle::_factor_compute_ops "${_IMPORT_PREFIX}/lib/libhyle_compute_ops.0.1.0.dylib" )

# Import target "hyle::_factor_compute_route_vulkan" for configuration "Release"
set_property(TARGET hyle::_factor_compute_route_vulkan APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(hyle::_factor_compute_route_vulkan PROPERTIES
  IMPORTED_LINK_DEPENDENT_LIBRARIES_RELEASE "hyle::_factor_platform;hyle::_factor_time"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libhyle_compute_route_vulkan.0.1.0.dylib"
  IMPORTED_SONAME_RELEASE "@rpath/libhyle_compute_route_vulkan.0.1.0.dylib"
  )

list(APPEND _cmake_import_check_targets hyle::_factor_compute_route_vulkan )
list(APPEND _cmake_import_check_files_for_hyle::_factor_compute_route_vulkan "${_IMPORT_PREFIX}/lib/libhyle_compute_route_vulkan.0.1.0.dylib" )

# Import target "hyle::_factor_graph_route_vulkan" for configuration "Release"
set_property(TARGET hyle::_factor_graph_route_vulkan APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(hyle::_factor_graph_route_vulkan PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libhyle_graph_route_vulkan.0.1.0.dylib"
  IMPORTED_SONAME_RELEASE "@rpath/libhyle_graph_route_vulkan.0.1.0.dylib"
  )

list(APPEND _cmake_import_check_targets hyle::_factor_graph_route_vulkan )
list(APPEND _cmake_import_check_files_for_hyle::_factor_graph_route_vulkan "${_IMPORT_PREFIX}/lib/libhyle_graph_route_vulkan.0.1.0.dylib" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
