"""Final immutable R6 delivery; one finite attempt per platform and output root."""
import argparse
import ctypes
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import time
import zipfile

parser = argparse.ArgumentParser()
parser.add_argument('--root', type=Path, required=True)
parser.add_argument('--archive', type=Path, required=True)
parser.add_argument('--sha256', required=True)
args = parser.parse_args()
root, archive = args.root.resolve(), args.archive.resolve()
root.mkdir(exist_ok=False)
logs = root / 'logs'
logs.mkdir()
windows = os.name == 'nt'
if windows:
    ctypes.windll.kernel32.SetErrorMode(0x8003)
commit = '20a029aded4bc00c9fc80a182bd3051853e7c99e'
env = dict(os.environ, CMAKE_BUILD_PARALLEL_LEVEL='2', CTEST_PARALLEL_LEVEL='1',
           VK_LOADER_LAYERS_DISABLE='~implicit~', CTEST_INTERACTIVE_DEBUG_MODE='0')
if not windows:
    env.update(PATH='/opt/homebrew/bin:' + env['PATH'], MACOSX_DEPLOYMENT_TARGET='14.4',
               DYLD_LIBRARY_PATH='/opt/homebrew/opt/vulkan-loader/lib')
headers = Path('C:/public/project-hyle/.deps/sources/vulkan_headers-e3b1eec08173-69d6adc9001f'
    if windows else '/Users/kiro/Library/Caches/hyle/dependencies/v1/sources/vulkan_headers-e3b1eec08173-69d6adc9001f')
compiler = 'C:/public/tools/glslang/glslangValidator.exe' if windows else '/opt/homebrew/bin/glslangValidator'
records = []
identity = {'snapshot': commit, 'product_candidate': '8e45b10423686a0753aaa9d461c4ef3b117412c5',
    'state': 'RUNNING', 'source_archive': str(archive), 'source_archive_sha256': args.sha256,
    'platform': 'Windows' if windows else 'Air Mac16,12', 'records': records, 'executables': {}}

def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def save():
    (logs / 'identity.json').write_text(json.dumps(identity, indent=2) + '\n', encoding='utf-8')

def run(label, command, timeout=600):
    command = [str(x) for x in command]
    print(label, flush=True)
    started = time.monotonic()
    with (logs / (label + '.log')).open('w', encoding='utf-8') as f:
        result = subprocess.run(command, cwd=root, env=env, stdout=f, stderr=subprocess.STDOUT, timeout=timeout)
    records.append({'label': label, 'command': command, 'exit_code': result.returncode,
                    'seconds': time.monotonic() - started})
    save()
    if result.returncode:
        print((logs / (label + '.log')).read_text(errors='replace')[-6000:], flush=True)
    result.check_returncode()

def relocate(old, new):
    assert root in old.resolve().parents and root in new.resolve().parents
    assert old.is_dir() and not new.exists()
    old.rename(new)

def configure(build, tree, static, install=True):
    command = ['cmake', '-S', tree, '-B', build, '-G', 'Ninja', '-DCMAKE_BUILD_TYPE=Release',
        '-DCMAKE_EXPORT_COMPILE_COMMANDS=ON', '-DHYLE_COMPONENTS=compute;graph',
        '-DHYLE_COMPUTE_CPU=OFF', '-DHYLE_COMPUTE_CUDA=OFF', '-DHYLE_COMPUTE_APPLE=OFF',
        '-DHYLE_COMPUTE_ONEDNN=OFF', '-DHYLE_COMPUTE_VULKAN=ON', '-DHYLE_BUILD_TESTS=OFF',
        '-DHYLE_BUILD_BENCH=OFF', '-DHYLE_WERROR=ON', '-DHYLE_STATIC=' + ('ON' if static else 'OFF'),
        '-DHYLE_INSTALL=' + ('ON' if install else 'OFF'), '-DHYLE_VULKAN_GLSLANG=' + compiler,
        '-DFETCHCONTENT_FULLY_DISCONNECTED=ON', '-DFETCHCONTENT_SOURCE_DIR_VULKAN_HEADERS=' + str(headers)]
    if not windows:
        command.append('-DCMAKE_OSX_DEPLOYMENT_TARGET=14.4')
    run(build.name + '-configure', command)

def verify_executables(build, names):
    if windows:
        for name in ('msvcp140.dll', 'msvcp140_atomic_wait.dll', 'vcruntime140.dll', 'vcruntime140_1.dll', 'vulkan-1.dll'):
            shutil.copyfile(Path('C:/Windows/System32') / name, build / name)
    run(build.name + '-test', ['ctest', '--test-dir', build, '--output-on-failure', '--no-tests=error', '--timeout', '120'])
    shutil.copyfile(build / 'Testing/Temporary/LastTest.log', logs / (build.name + '-LastTest.log'))
    for name in names:
        executable = build / (name + ('.exe' if windows else ''))
        identity['executables'][build.name + '/' + name] = sha(executable)
        run(build.name + '-' + name + '-linkage', ['dumpbin', '/dependents', executable] if windows else
            ['/usr/bin/otool', '-L', executable])

try:
    save()
    assert sha(archive) == args.sha256
    assert (headers / 'include/vulkan/vulkan_core.h').is_file()
    extracted = root / 'complete-source'
    with zipfile.ZipFile(archive) as z:
        assert all(not Path(n).is_absolute() and '..' not in Path(n).parts for n in z.namelist())
        z.extractall(extracted)
    trees = list(extracted.glob('hyle-*-source'))
    assert len(trees) == 1
    tree = trees[0]
    assert commit in (tree / 'SOURCE-MANIFEST.txt').read_text()
    consumers = root / 'independent-consumers'
    for product in ('compute', 'graph'):
        shutil.copytree(tree / 'samples/package' / product / 'cpp', consumers / product / 'cpp')
    parent = root / 'source-consumer'
    parent.mkdir()
    (parent / 'CMakeLists.txt').write_text('''cmake_minimum_required(VERSION 3.25)
project(vulkan_source_consumer LANGUAGES CXX)
add_subdirectory("''' + tree.as_posix() + '''" hyle)
enable_testing()
foreach(product IN ITEMS compute graph)
  add_executable(vulkan_source_${product} "''' + tree.as_posix() + '''/samples/package/${product}/cpp/main.cc")
  target_compile_features(vulkan_source_${product} PRIVATE cxx_std_23)
  target_link_libraries(vulkan_source_${product} PRIVATE hyle::${product})
  hyle_stage_runtime_dependencies(vulkan_source_${product})
  add_test(NAME vulkan_source_${product} COMMAND vulkan_source_${product})
endforeach()
''', encoding='utf-8')
    source_build = root / 'source-build'
    configure(source_build, parent, True, False)
    run('source-build', ['cmake', '--build', source_build, '--parallel', '2'])
    verify_executables(source_build, ['vulkan_source_compute', 'vulkan_source_graph'])
    producer_builds, prefixes = [source_build], {}
    for linkage in ('static', 'shared'):
        build = root / ('public-' + linkage)
        configure(build, tree, linkage == 'static')
        run(linkage + '-build', ['cmake', '--build', build, '--parallel', '2'])
        prefix = root / ('sdk-' + linkage)
        run(linkage + '-install', ['cmake', '--install', build, '--prefix', prefix])
        relocated = root / ('relocated-sdk-' + linkage)
        relocate(prefix, relocated)
        prefixes[linkage] = relocated
        producer_builds.append(build)
    for build in producer_builds:
        for name in ('CMakeCache.txt', 'compile_commands.json'):
            shutil.copyfile(build / name, logs / (build.name + '-' + name))
        relocate(build, build.with_name(build.name + '-hidden'))
    relocate(extracted, extracted.with_name(extracted.name + '-hidden'))
    identity['producer_paths_hidden_before_sdk_consumption'] = True
    for linkage, prefix in prefixes.items():
        assert (prefix / 'include/vulkan/vulkan_core.h').is_file()
        for name in ('ggml-vulkan-shaders-LICENSE', 'ggml-vulkan-shaders-NOTICE.md',
                     'vulkan-headers-LICENSE.md', 'vulkan-headers-Apache-2.0.txt', 'vulkan-headers-MIT.txt'):
            assert (prefix / 'share/licenses/Hyle' / name).is_file(), name
        artifacts = [p.name for p in prefix.rglob('*') if p.suffix.lower() in ('.lib', '.dll', '.a', '.so', '.dylib')]
        forbidden = ('onednn', 'libmlx', 'cublas', 'marlin', 'compute_backend_cpu', 'compute_backend_cuda', 'compute_route_apple')
        assert not any(word in name.lower() for name in artifacts for word in forbidden), artifacts
        (logs / (linkage + '-artifacts.json')).write_text(json.dumps(artifacts, indent=2) + '\n')
        for product in ('compute', 'graph'):
            build = root / ('consumer-' + linkage + '-' + product)
            command = ['cmake', '-S', consumers / product / 'cpp', '-B', build, '-G', 'Ninja',
                '-DCMAKE_BUILD_TYPE=Release', '-DCMAKE_PREFIX_PATH=' + str(prefix)]
            if not windows:
                command.append('-DCMAKE_OSX_DEPLOYMENT_TARGET=14.4')
            run(build.name + '-configure', command)
            run(build.name + '-build', ['cmake', '--build', build, '--parallel', '2'])
            if windows and linkage == 'shared':
                assert (build / 'hyle_compute_route_vulkan.dll').is_file()
            verify_executables(build, ['hyle_package_' + product + '_cpp'])
    identity['state'] = 'PASS'
except Exception as error:
    identity.update(state='FAIL', error=str(error))
    raise
finally:
    identity['finished'] = time.time()
    save()
