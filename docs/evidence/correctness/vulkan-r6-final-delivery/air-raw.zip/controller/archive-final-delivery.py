"""Archive the completed R6 ordinary source/static/shared consumer journeys."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import zipfile

parser = argparse.ArgumentParser()
parser.add_argument('--root', type=Path, required=True)
args = parser.parse_args()
root = args.root.resolve()
delivery = root / 'final-delivery-20a029ad'
logs = delivery / 'logs'
identity = json.loads((logs / 'identity.json').read_text(encoding='utf-8'))
assert identity['state'] == 'PASS'
assert identity['snapshot'] == '20a029aded4bc00c9fc80a182bd3051853e7c99e'
assert identity['product_candidate'] == '8e45b10423686a0753aaa9d461c4ef3b117412c5'
assert identity['source_archive_sha256'] == '22d4cce9a4f9c9f912b62877c8bc2a13a6d17f08a96d40c5499a3dbb5e3c5fa6'
assert identity['producer_paths_hidden_before_sdk_consumption'] is True
assert all(row['exit_code'] == 0 for row in identity['records'])
assert len([row for row in identity['records'] if row['label'].endswith('-test')]) == 5
expected = {'source-build/vulkan_source_compute', 'source-build/vulkan_source_graph'}
expected.update('consumer-' + linkage + '-' + product + '/hyle_package_' + product + '_cpp'
                for linkage in ('static', 'shared') for product in ('compute', 'graph'))
assert set(identity['executables']) == expected


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


assert sha(Path(identity['source_archive'])) == identity['source_archive_sha256']
windows = identity['platform'] == 'Windows'
assert windows == (os.name == 'nt')
for name, digest in identity['executables'].items():
    path = delivery / (name + ('.exe' if windows else ''))
    if name.startswith('source-build/'):
        path = delivery / (name.replace('source-build/', 'source-build-hidden/', 1) +
                           ('.exe' if windows else ''))
    assert sha(path) == digest, str(path)
for name in ('source-build', 'public-static', 'public-shared', 'complete-source'):
    assert not (delivery / name).exists()
    assert (delivery / (name + '-hidden')).is_dir()
for row in identity['records']:
    if row['label'].endswith('-test'):
        assert '100% tests passed' in (logs / (row['label'] + '.log')).read_text(encoding='utf-8')
files = {'logs/' + p.relative_to(logs).as_posix(): p for p in logs.rglob('*') if p.is_file()}
source_manifests = list((delivery / 'complete-source-hidden').glob('hyle-*-source/SOURCE-MANIFEST.txt'))
assert len(source_manifests) == 1
files['source/SOURCE-MANIFEST.txt'] = source_manifests[0]
for linkage in ('static', 'shared'):
    prefix = delivery / ('relocated-sdk-' + linkage)
    for p in (prefix / 'share/licenses/Hyle').rglob('*'):
        if p.is_file():
            files[linkage + '/licenses/' + p.relative_to(prefix / 'share/licenses/Hyle').as_posix()] = p
    for p in prefix.rglob('*.cmake'):
        files[linkage + '/exports/' + p.relative_to(prefix).as_posix()] = p
for name in ('verify-final-delivery.py', 'archive-final-delivery.py'):
    files['controller/' + name] = root / name
if windows:
    files['controller/run-final-delivery-windows.ps1'] = root / 'run-final-delivery-windows.ps1'
out = root / ('archive-final-delivery-' + ('windows' if windows else 'air'))
out.mkdir(exist_ok=False)
entries = {name: {'source': str(p), 'sha256': sha(p), 'bytes': p.stat().st_size}
           for name, p in sorted(files.items())}
with zipfile.ZipFile(out / 'raw.zip', 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as z:
    for name, p in sorted(files.items()):
        z.write(p, name)
    z.writestr('archive-manifest.json', json.dumps(entries, indent=2) + '\n')
with zipfile.ZipFile(out / 'raw.zip') as z:
    for name, row in entries.items():
        assert hashlib.sha256(z.read(name)).hexdigest() == row['sha256'], name
receipt = {'product_candidate': identity['product_candidate'], 'source_snapshot': identity['snapshot'],
           'source_archive_sha256': identity['source_archive_sha256'], 'platform': identity['platform'],
           'delivery': 'PASS', 'source_static_shared_consumer_executables': 6,
           'producer_paths_hidden_before_sdk_consumption': True,
           'archive': {'file': 'raw.zip', 'sha256': sha(out / 'raw.zip'), 'entries': len(entries),
                       'per_entry_integrity': 'PASS'}}
(out / 'identity.json').write_bytes((json.dumps(receipt, indent=2) + '\n').encode())
print(json.dumps(receipt, indent=2), flush=True)
