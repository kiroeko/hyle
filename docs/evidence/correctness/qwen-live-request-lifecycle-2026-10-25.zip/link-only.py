from pathlib import Path
import hashlib,importlib.util,json,os
R=Path.cwd();W=R/'.scratch/inference-live-owner-20261025';F=W/'attempt1';old=R/'.scratch/inference-system-review-20261025/schedule-inputs'
spec=importlib.util.spec_from_file_location('retained',R/'.scratch/mtp-extraction-regression-20261024/check.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
b.save(F/'closure-precheck-failure.json',dict(state='PRIVATE_HELPER_REJECTED_BEFORE_LINK',compile_exit=0,reason='Bare Windows SDK bcrypt.lib is resolved by retained LIB search path; treating it as a cwd file was wrong.',recompile=False))
original=b.args(old/'compile/command.json');env=b.environment(original[0]);link=b.args(old/'link/command.json');oldobj=str(old/'compile/unit.obj').lower();args=[];replaced=0
for a in link[1:]:
 if a.lower()==oldobj:args.append(str(F/'compile/unit.obj'));replaced+=1
 elif not a.lower().startswith(('/out:','/pdb:','/map:','/implib:')):args.append(a)
assert replaced==1
for a in args:
 if Path(a).is_absolute()and a.lower().endswith(('.obj','.lib'))and not Path(a).is_file():raise RuntimeError('Retained absolute input missing: '+a)
b.execute([link[0],*args,'/OUT:'+str(F/'link/consumer.exe'),'/IMPLIB:'+str(F/'link/consumer.lib')],F/'link',env,90)
os.link(old/'link/hyle_ggml_cpu_gdn_scale_v3.dll',F/'link/hyle_ggml_cpu_gdn_scale_v3.dll')
actual=b.read(F/'compile/actual-source-pins.json')
for pin in actual:
 p=Path(pin['path']);assert hashlib.sha256(p.read_bytes()).hexdigest()==pin['sha256']
b.save(F/'ready.json',dict(image=b.pin(F/'link/consumer.exe'),object=b.pin(F/'compile/unit.obj'),native=b.pin(F/'link/hyle_ggml_cpu_gdn_scale_v3.dll'),sources=actual,SDK_builds=0,HTTP_requests=0))
print(json.dumps(dict(state='BUILT',image=b.pin(F/'link/consumer.exe'),actual_self_sources=len(actual))),flush=True)
