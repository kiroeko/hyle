#include "source/engine/models/qwen35/main.cc"
#include "source/engine/inference/output_delivery.h"
namespace q = qwen35;
namespace i = hyle::inference;
namespace {
void require(bool value,const char *message){if(!value)throw std::runtime_error(message);}
void event(const char *name){std::cerr<<"live_owner_stage="<<name<<'\n';}
void finish_payload(q::GenerationRequest &request){
  q::check(request.session->stop());q::check(request.session->drain());
  require(q::take(request.session->try_retire()),"request payload did not actually retire");request.session.reset();
}
}
int main(int argc,char **argv){
 try{
  if(argc!=2)throw std::runtime_error("pass original prepared input directory");
  const std::filesystem::path input=argv[1];const auto geometry=q::read_weight_geometry(input/"weights.tsv");
  const auto prompt=q::read_ids(input/"prompt.ids",geometry.vocabulary,192);require(prompt.size()==154,"expected original P154 prompt");
  const auto plan=q::cache::plan(geometry,192,3,154,q::recurrent_bytes(q::state_schema_for(geometry,192),geometry),2,1,false,false);
  event("load_original_ordinary");
  q::Model model(input/"weights.tsv",geometry,192,plan,{},true,q::ReplayPolicy::kCommands,1073741824,
      {.enabled=true,.policy={1,8,.9F},.seed=123},0,{.primary=q::BackendKind::kCuda});
  require(model.physical_text_roles==320 && !model.physical_mtp_roles && !model.cache_plan.draft_cache,"ordinary loaded draft resources");
  const std::array shapes{std::size_t{154},std::size_t{1}};
  for(auto width:{std::size_t{1},std::size_t{2}}){
    model.prepare_family(shapes,false,width,q::GraphRole::kText);
    model.plan_replay_uses(154,width,4,q::GraphRole::kText);model.plan_replay_uses(1,width,16,q::GraphRole::kText);
  }
  for(auto width:{std::size_t{1},std::size_t{2}})model.prepare_execution(shapes,width,q::GraphRole::kText);
  const std::array a_turns{i::GenerationTurn{prompt,3}};
  const std::array b_turns{i::GenerationTurn{prompt,3},i::GenerationTurn{{},1}};
  const std::array c_turns{i::GenerationTurn{prompt,1}};
  std::vector<q::GenerationRequest> requests;requests.reserve(3);
  requests.emplace_back("A",prompt,std::filesystem::path{},3);requests.emplace_back("B",prompt,std::filesystem::path{},4);requests.emplace_back("C",prompt,std::filesystem::path{},1);
  requests[0].progress.bind_turns(a_turns);requests[1].progress.bind_open_turns(std::span(b_turns).first(1),2,154);requests[2].progress.bind_turns(c_turns);
  for(std::size_t index=0;index<requests.size();++index){
    auto &request=requests[index];const auto outputs=request.progress.maximum_outputs();
    request.progress.initial_sampling={123,100+index,0};
    request.ledger=std::make_unique<q::GenerationLedger>(154+outputs,1);request.round_emitted.resize(outputs-1);
    for(auto &row:request.round_emitted)row.reserve(1);
    request.turn_observations.resize(index==1?2:1);request.warm_inputs.reserve(index==1?2:1);
    request.warm_inputs.push_back(std::make_shared<std::vector<std::int32_t>>(prompt));
    if(index==1)request.warm_inputs.push_back(std::make_shared<std::vector<std::int32_t>>(1,-1));
  }
  i::RequestWindow window;window.prepare(3,2);
  std::array delivery{i::OutputDelivery(1),i::OutputDelivery(1),i::OutputDelivery(1)};
  auto &a=requests[0];auto &b=requests[1];auto &c=requests[2];
  a.request_key=window.enqueue(0);b.request_key=window.enqueue(1);
  const auto key_a=a.request_key,key_b=b.request_key;
  const auto ack=[&](std::size_t index,i::RequestKey key,std::size_t through){
    auto &request=requests[index];if(key!=request.request_key || !window.matches(key))return false;
    delivery[index].acknowledge_prefix(request.progress.generated.size(),through);return true;
  };
  const auto prepare=[&](std::size_t index){
    auto &request=requests[index];const auto credit=delivery[index].available(request.progress.generated.size());
    require(credit==1,"ordinary episode must have exactly one real output credit");
    return q::prepare_generation_call(model,request,request.progress.output_limit(),nullptr,requests,credit);
  };
  for(auto index:{std::size_t{0},std::size_t{1}}){
    auto &request=requests[index];window.admitted(request.request_key);request.prompt=request.progress.begin_turn(*request.warm_inputs[0]);
  }
  event("original_R2_prefill");std::array calls{prepare(0),prepare(1)};
  q::execute_generation_calls(model,calls,false,nullptr,requests);
  require(!model.active_step && a.ledger->committed_count==1 && b.ledger->committed_count==1,"R2 prefill was not observed atomically");
  require(a.session->head->sampling.draw==1 && b.session->head->sampling.draw==1 && !a.progress.turn_done && !b.progress.turn_done,"natural prefill did not leave two live random requests");
  require(ack(0,key_a,1) && ack(1,key_b,1),"initial actual transport acknowledgements failed");
  const auto before_a=q::generation_boundary(*a.session->head),before_b=q::generation_boundary(*b.session->head);
  const auto *head_a=a.session->head.get(),*head_b=b.session->head.get();
  const auto base_b_outputs=b.progress.generated;const auto base_b_state_count=b.session->head->state.size();
  auto cancelled_a=prepare(0),cancelled_b=prepare(1);
  for(auto *call:{&cancelled_a,&cancelled_b})q::prepare_generation_record(*call->request->ledger,*call->request->session,q::GraphRole::kText,call->ids(),true,call->quota,0);
  const std::array batch{q::EvaluationRequest{a.session,cancelled_a.ids()},q::EvaluationRequest{b.session,cancelled_b.ids()}};
  event("submit_R2_then_cancel_A");model.prepare_evaluations(batch,nullptr,q::GraphRole::kText);model.submit_evaluations();
  require(model.active_step && model.active_step->submitted && a.session->pending==b.session->pending && model.active_step->members.size()==2,"original submitted R2 episode was not shared");
  const bool logical_inflight=model.active_step->run->in_flight();
  q::check(a.session->stop());q::check(model.abort_episode());
  require(!model.active_step && !model.carrier_borrowed && !a.session->pending && !b.session->pending,"cancelled shared native episode did not completely retire");
  require(a.session->head.get()==head_a && b.session->head.get()==head_b && q::generation_boundary(*a.session->head)==before_a && q::generation_boundary(*b.session->head)==before_b && b.session->head->state.size()==base_b_state_count,"cancelled R2 changed a committed full head or random cursor");
  require(a.ledger->committed_count==1 && b.ledger->committed_count==1 && !a.ledger->records[1].committed && !b.ledger->records[1].committed && b.progress.generated==base_b_outputs && b.progress.observed_commits()==1 && !b.session->stopping && !b.session->failed,"cancelled batch published or stopped its surviving request");
  const bool survivor_retirement_ok=b.session->retirement_status.ok();
  require(q::take(a.session->try_retire()),"cancelled A payload was not retired");a.session.reset();window.retire_active(key_a);window.release(key_a);
  window.requeue(key_b);require(window.waiting_front()==key_b && window.matches(key_b),"survivor lost its original key or FIFO continuation");window.admitted(key_b);
  event("invalid_C_request_local_preflight");c.request_key=window.enqueue(2);const auto old_c_key=c.request_key;window.admitted(old_c_key);
  const std::array chunks{std::size_t{154}};c.session=model.create_session(chunks,{},q::GraphRole::kText,c.progress.initial_sampling);
  const auto *c_empty=c.session->head.get();const auto visible_before_error=q::generation_boundary(*b.session->head);
  const std::int32_t pending=b.session->head->next_id,bad_id=static_cast<std::int32_t>(geometry.vocabulary);
  const std::array bad_batch{q::EvaluationRequest{b.session,std::span(&pending,1)},q::EvaluationRequest{c.session,std::span(&bad_id,1)}};
  bool input_rejected=false;
  try{model.prepare_evaluations(bad_batch,nullptr,q::GraphRole::kText);}catch(const std::runtime_error &error){input_rejected=std::string_view(error.what())=="token ID outside vocabulary";}
  require(input_rejected && !model.active_step && !model.carrier_borrowed && b.session->head.get()==head_b && c.session->head.get()==c_empty && q::generation_boundary(*b.session->head)==visible_before_error && b.ledger->committed_count==1 && !c.ledger->committed_count,"bad C token mutated a valid request or admitted native work");
  finish_payload(c);window.retire_active(old_c_key);window.release(old_c_key);c.request_key=window.enqueue(2);
  require(c.request_key.generation>old_c_key.generation && !window.matches(old_c_key),"request-local input retry reused a stale generation");
  event("survivor_continue_then_credit_pause");std::array survivor{prepare(1)};q::execute_generation_calls(model,survivor,false,nullptr,requests);
  require(b.progress.generated.size()==2 && b.session->head->sampling.draw==2 && b.ledger->committed_count==2 && b.ledger->records[1].pending_input==before_b.next_id && b.request_key==key_b,"survivor did not continue the original pending and RNG");
  require(!delivery[1].can_accept(b.progress.generated.size(),1),"small delivery credit did not block another episode");
  const auto paused_boundary=q::generation_boundary(*b.session->head);const auto paused_ledger=b.ledger->committed_count;
  bool zero_rejected=false;try{(void)q::prepare_generation_call(model,b,b.progress.output_limit(),nullptr,requests,0);}catch(const std::runtime_error &){zero_rejected=true;}
  require(zero_rejected && !model.active_step && q::generation_boundary(*b.session->head)==paused_boundary && b.ledger->committed_count==paused_ledger,"zero-credit call produced side effects");
  b.last_idle=window.pause(key_b);require(window.waiting_front()==c.request_key && window.matches(key_b),"credit pause blocked the next logical arrival");
  event("C_runs_while_B_paused");window.admitted(c.request_key);c.prompt=c.progress.begin_turn(*c.warm_inputs[0]);std::array c_call{prepare(2)};q::execute_generation_calls(model,c_call,false,nullptr,requests);
  require(c.progress.generated.size()==1 && c.progress.request_done() && c.session->head->sampling.draw==1 && q::generation_boundary(*b.session->head)==paused_boundary,"new C failed to run independently of paused B");
  window.release_turn(c.request_key,false);
  require(!delivery[2].pending(c.progress.generated).empty() && window.matches(c.request_key),"final pending output was released prematurely");
  require(!ack(2,old_c_key,1) && !delivery[2].acknowledged(),"stale C acknowledgement advanced a new generation");
  require(ack(2,c.request_key,1) && delivery[2].pending(c.progress.generated).empty(),"final C output was not drained");finish_payload(c);window.release(c.request_key);
  require(ack(1,key_b,2),"B delivery acknowledgement failed");window.wake(key_b);require(window.waiting_front()==key_b,"awakened B did not use the original FIFO");window.admitted(key_b);
  event("B_finishes_known_turn_then_waits_for_input");std::array third{prepare(1)};q::execute_generation_calls(model,third,false,nullptr,requests);
  require(b.progress.generated.size()==3 && b.progress.waiting_for_input() && !b.progress.request_done() && b.session->head->sampling.draw==3,"open request incorrectly completed its final known turn");
  window.pause(key_b);const auto before_append=q::generation_boundary(*b.session->head);const auto old_ledger=b.ledger->committed_count;
  b.progress.extend_turns(b_turns);require(ack(1,key_b,3),"B final-known output did not drain before resume");window.wake(key_b);window.admitted(key_b);
  b.progress.advance_turn();b.prompt=b.progress.begin_turn(*b.warm_inputs[1],b.session->head->next_id);b.progress.close_input();
  require(b.prompt.size()==1 && b.prompt[0]==before_append.next_id && b.ledger->committed_count==old_ledger,"appended empty suffix changed history before its actual pending input");
  event("pending_only_append_close_and_final_drain");std::array appended{prepare(1)};q::execute_generation_calls(model,appended,false,nullptr,requests);
  require(b.progress.request_done() && b.progress.generated.size()==4 && b.ledger->committed_count==4 && b.progress.observed_commits()==4 && b.session->head->sampling.draw==4 && b.session->length()==157 && b.ledger->records[3].ids().size()==1 && b.ledger->records[3].ids()[0]==before_append.next_id && b.ledger->records[3].before.length==156 && b.ledger->records[3].after.length==157,"pending-only continuation duplicated input/output or RNG");
  window.release_turn(key_b,false);require(window.matches(key_b) && delivery[1].pending(b.progress.generated).size()==1,"terminal pending output did not retain its request slot");
  bool occupied=true;try{(void)window.enqueue(1);occupied=false;}catch(const std::logic_error &){}require(occupied,"terminal slot was reused before output drain");
  require(ack(1,key_b,4) && delivery[1].pending(b.progress.generated).empty(),"final B output did not drain");
  const auto b_ids=b.progress.generated,c_ids=c.progress.generated;const bool b_status_before_stop=b.session->retirement_status.ok();finish_payload(b);window.release(key_b);
  require(!window.matches(key_b) && !ack(1,key_b,4) && window.active().empty() && !window.waiting_front() && !model.active_step && !model.carrier_borrowed,"final retirement left native admission or accepted a stale ACK");
  require(model.draft_programs.empty() && model.prefix_sampling_programs.empty() && !model.draft_program_graph_calls && !model.prefix_decision_graph_calls,"ordinary owner used MTP paths");
  std::cout<<"{\"status\":\"PASS\",\"ordinary\":true,\"backend\":\"cuda\",\"physical_text_roles\":"<<model.physical_text_roles<<",\"physical_mtp_roles\":"<<model.physical_mtp_roles<<",\"device_weight_bytes\":"<<model.device_weight_bytes<<",\"cache_limit\":1073741824,\"cache_backing_bytes\":"<<model.known_cache_backing_bytes<<",\"submitted_R2_inflight_fact\":"<<(logical_inflight?"true":"false")<<",\"hardware_completion_at_cancel\":\"unknown\",\"survivor_retirement_status_after_abort_ok\":"<<(survivor_retirement_ok?"true":"false")<<",\"survivor_final_status_before_stop_ok\":"<<(b_status_before_stop?"true":"false")<<",\"B_key_generation\":"<<key_b.generation<<",\"C_old_generation\":"<<old_c_key.generation<<",\"C_new_generation\":"<<c.request_key.generation<<",\"B_sampling_draw\":4,\"B_committed_records\":4,\"B_ids\":[";
  for(std::size_t x=0;x<b_ids.size();++x)std::cout<<(x?",":"")<<b_ids[x];std::cout<<"],\"C_ids\":[";
  for(std::size_t x=0;x<c_ids.size();++x)std::cout<<(x?",":"")<<c_ids[x];std::cout<<"],\"scope\":\"one_original_model_host_owner_process_not_online_CLI\"}\n";
  return 0;
 }catch(const std::exception &error){std::cerr<<"live_owner_failure="<<error.what()<<'\n';return 1;}
}
