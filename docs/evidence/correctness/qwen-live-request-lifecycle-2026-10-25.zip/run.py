from pathlib import Path
import hashlib,importlib.util,json,os
R=Path.cwd();W=R/'.scratch/inference-live-owner-20261025';F=W/'attempt1'
spec=importlib.util.spec_from_file_location('retained',R/'.scratch/mtp-extraction-regression-20261024/check.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
ready=b.read(F/'ready.json');assert b.pin(Path(ready['image']['path']))==ready['image']
for p in b.read(F/'compile/actual-source-pins.json'):
 path=Path(p['path']);assert hashlib.sha256(path.read_bytes()).hexdigest()==p['sha256']
inputs=R/'.scratch/qwen35-unsloth-mtp-20261024/geometry-v2-check/original';before=b.read(F/'inputs.json');assert b.pin(inputs/'weights.tsv')==before['manifest']and b.pin(inputs/'prompt.ids')==before['prompt']
env=os.environ.copy();env.update({k:v for k,v in b.read(R/'.scratch/mtp-performance-convergence-20261025/baseline/runtime.json').items()if isinstance(v,str)})
env['PATH']=str(F/'link')+';'+env['PATH']
command=[ready['image']['path'],str(inputs)];b.execute(command,F/'run1',env,180)
lines=(F/'run1/stdout.log').read_text().splitlines();reports=[json.loads(line)for line in lines if line.startswith('{')];assert len(reports)==1 and reports[0]['status']=='PASS'
b.save(F/'run1/result.json',reports[0]);print(json.dumps(reports[0]),flush=True)
