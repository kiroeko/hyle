from pathlib import Path
import difflib
import hashlib
import subprocess

root = Path(__file__).resolve().parents[2]
base = Path(__file__).resolve().parent/'retirement-error-followup'
base.mkdir(exist_ok=False)
name = 'engine/models/qwen35/main.cc'
staged = subprocess.check_output(['git','show',':'+name],cwd=root)
working = (root/name).read_bytes()
helper = '''// A requested cancellation is an expected episode outcome. Preserve a later
// actual retirement failure instead of letting first-error aggregation hide it.
// Other first errors keep their original identity; this does not prove retirement.
void record_retirement_status(hyle::Status &status, const hyle::Status &observed) noexcept {
  if (status.IsCancelled() && !status.has_native_error() && !observed.ok() &&
      (!observed.IsCancelled() || observed.has_native_error()))
    status = observed;
  else status.Update(observed);
}

'''
replacements = [
 ('struct StepState final {', helper+'struct StepState final {'),
 ('terminal.Update(observed.error());', 'record_retirement_status(terminal, observed.error());'),
 ('if (active_step) session->retirement_status.Update(active_step->terminal);',
  'if (active_step) record_retirement_status(session->retirement_status, active_step->terminal);'),
 ('member.session->retirement_status.Update(active_step->terminal);',
  'record_retirement_status(member.session->retirement_status, active_step->terminal);'),
 ('hyle::Result<bool> try_retire_episode() noexcept {',
  'hyle::Result<bool> try_retire_episode(hyle::Status *observed_status = nullptr) noexcept {'),
 ('active_step->terminal.Update(execution.collect_retired());',
  'record_retirement_status(active_step->terminal, execution.collect_retired());'),
 ('HYLE_ASSIGN_OR_RETURN(auto retired, active_step->try_abort());\n    if (retired) detach_episode();',
  'HYLE_ASSIGN_OR_RETURN(auto retired, active_step->try_abort());\n    if (observed_status) record_retirement_status(*observed_status, active_step->terminal);\n    if (retired) detach_episode();'),
 ('active_step->terminal.Update(terminal);\n    HYLE_ASSIGN_OR_RETURN(auto retired, try_retire_episode());',
  'record_retirement_status(active_step->terminal, terminal);\n    HYLE_ASSIGN_OR_RETURN(auto retired, try_retire_episode(&terminal));'),
 ('if (!cancelled.IsUnimplemented()) retirement_status.Update(cancelled);',
  'if (!cancelled.IsUnimplemented()) record_retirement_status(retirement_status, cancelled);'),
 ('retirement_status.Update(resources_->retire(false));',
  'record_retirement_status(retirement_status, resources_->retire(false));'),
 ('if (!model_) status.Update(resources_->retire(true));\n  else if (pending) status.Update(model_->abort_episode());\n  status.Update(retirement_status); return status;',
  'if (!model_) record_retirement_status(status, resources_->retire(true));\n  else if (pending) record_retirement_status(status, model_->abort_episode());\n  record_retirement_status(status, retirement_status); return status;'),
]

def transform(data):
    text = data.decode('utf-8')
    crlf = '\r\n' in text
    text = text.replace('\r\n','\n')
    for before, after in replacements:
        assert text.count(before) == 1, (before,text.count(before))
        text = text.replace(before,after)
    return text.replace('\n','\r\n').encode() if crlf else text.encode()

staged_after, working_after = transform(staged), transform(working)
for label, data in [('staged-before',staged),('staged-after',staged_after),('working-before',working),('working-after',working_after)]:
    (base/(label+'.cc')).write_bytes(data)
patch = ''.join(difflib.unified_diff(staged.decode().splitlines(True),staged_after.decode().splitlines(True),
    fromfile='a/'+name,tofile='b/'+name))
(base/'staged.patch').write_text(patch,encoding='utf-8')
assert (root/name).read_bytes() == working
subprocess.run(['git','apply','--cached','--check','-'],input=patch.encode(),cwd=root,check=True)
(root/name).write_bytes(working_after)
subprocess.run(['git','apply','--cached','-'],input=patch.encode(),cwd=root,check=True)
print('Applied only local retirement-error aggregation to working and staged main; chunk changes remain unstaged.')
print('staged main SHA256',hashlib.sha256(staged_after).hexdigest())
