from pathlib import Path
import hashlib
import importlib.util
import json
import os
import subprocess

root = Path(__file__).resolve().parents[2]
base = Path(__file__).resolve().parent
work = base/'canonical-retirement'
source = work/'source'
source.mkdir(parents=True, exist_ok=False)
spec = importlib.util.spec_from_file_location('retained_host_build', root/'.scratch/engine-product-20261024/cpu-build.py')
build = importlib.util.module_from_spec(spec)
spec.loader.exec_module(build)
names = subprocess.check_output(['git','ls-files','-z','engine'],cwd=root).decode().split('\0')
names = [name for name in names if Path(name).suffix in ('.h','.cc')]
names += ['tests/tools/qwen_request_lifecycle_test.cc']
pins = []
for name in names:
    data = subprocess.check_output(['git','show',':'+name],cwd=root)
    path = source/name
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(data)
    pins.append({'path':name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
build.save(work/'source-pins.json',pins)
recipe = build.read(base/'attempt4/compile/command.json')['command']
env = build.discover_environment(compiler='msvc', cache={'CMAKE_C_COMPILER':recipe[0],
    'CMAKE_CXX_COMPILER':recipe[0],'CMAKE_GENERATOR':'Ninja'},backends=()).env
command = []
skip = False
for arg in recipe:
    if skip:
        skip = False
        continue
    if arg == '/sourceDependencies':
        skip = True
        continue
    if arg == '/c' or arg.startswith(('/Fo','/Fd')) or arg.lower().endswith('.cc'):
        continue
    if arg.startswith('/I'):
        for old in (str(base/'source'),str(root)):
            if arg == '/I'+old or arg.startswith('/I'+old+'\\engine'):
                arg = '/I'+str(source)+arg[len('/I'+old):]
                break
    command.append(arg)
command += ['/c','/U_CRT_SECURE_NO_WARNINGS',str(source/'tests/tools/qwen_request_lifecycle_test.cc'),
            '/Fo'+str(work/'checks.obj')]
result = build.execute(command,env,work/'compile',60)
link_recipe = build.read(base/'attempt4/link/command.json')['command']
link = []
image = work/'checks.exe'
for arg in link_recipe:
    if arg == str(base/'attempt4/compile/unit.obj'):
        arg = str(work/'checks.obj')
    elif arg.upper().startswith('/OUT:'):
        arg = '/OUT:'+str(image)
    elif arg.upper().startswith('/IMPLIB:'):
        arg = '/IMPLIB:'+str(work/'checks.lib')
    elif arg.upper().startswith('/PDB:'):
        arg = '/PDB:'+str(work/'checks.pdb')
    link.append(arg)
assert str(work/'checks.obj') in link and '/OUT:'+str(image) in link
linked = build.execute(link,env,work/'link',30)
runtime = os.environ.copy()
runtime.update({key:value for key,value in build.read(root/'.scratch/mtp-performance-convergence-20261025/baseline/runtime.json').items() if isinstance(value,str)})
runtime['PATH'] = str(base/'attempt4/link')+';'+runtime['PATH']
runtime.pop('HYLE_QWEN_REQUEST_INPUTS',None)
ran = build.execute([str(image),'--retirement-status-only'],runtime,work/'host-run',30)
endpoints = {}
for label,args,expected in [('absent-input',[],77),('invalid-input',[str(work/'nonexistent-input')],1)]:
    process = subprocess.run([str(image),*args],env=runtime,cwd=root,capture_output=True,text=True,timeout=30)
    endpoints[label] = {'exit':process.returncode,'expected_exit':expected,'stdout':process.stdout,'stderr':process.stderr}
    assert process.returncode == expected
build.save(work/'input-endpoints.json',endpoints)
summary = {'status':'STRICT_CANONICAL_BUILD_AND_HOST_CHECKS_PASS','scope':'Frozen staged engine and canonical consumer, MSVC /W4 /WX with CRT warning suppression explicitly undefined; seven synthetic status-aggregation cases and absent/invalid input endpoints. No model/backend/GPU execution or actual device error injection; no CMake configure.',
           'compile':result,'link':linked,'host':ran,'endpoints':endpoints,'source_pins':pins,'SDK_builds':0,'GPU_runs':0,'HTTP':0}
build.save(work/'summary.json',summary)
print(json.dumps({'status':summary['status'],'compile_seconds':result['process_wall_seconds'],
    'link_seconds':linked['process_wall_seconds'],'host_seconds':ran['process_wall_seconds'],
    'endpoints':{name:record['exit'] for name,record in endpoints.items()}},indent=2))
