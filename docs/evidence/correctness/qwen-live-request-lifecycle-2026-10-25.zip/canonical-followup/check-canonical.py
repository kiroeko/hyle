from pathlib import Path
import hashlib
import importlib.util
import json
import subprocess

root = Path(__file__).resolve().parents[2]
base = Path(__file__).resolve().parent
work = base/'canonical-portability'
source = work/'source'
source.mkdir(parents=True, exist_ok=False)
spec = importlib.util.spec_from_file_location('retained_host_build', root/'.scratch/engine-product-20261024/cpu-build.py')
build = importlib.util.module_from_spec(spec)
spec.loader.exec_module(build)
names = subprocess.check_output(['git','ls-files','-z','engine'],cwd=root).decode().split('\0')
names = [name for name in names if Path(name).suffix in ('.h','.cc')]
names += ['tests/tools/qwen_request_lifecycle_test.cc']
pins = []
for name in names:
    data = subprocess.check_output(['git','show',':'+name],cwd=root)
    path = source/name
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(data)
    pins.append({'path':name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
build.save(work/'source-pins.json',pins)
recipe = build.read(base/'attempt4/compile/command.json')['command']
env = build.discover_environment(compiler='msvc', cache={'CMAKE_C_COMPILER':recipe[0],
    'CMAKE_CXX_COMPILER':recipe[0],'CMAKE_GENERATOR':'Ninja'},backends=()).env
command = []
skip = False
for arg in recipe:
    if skip:
        skip = False
        continue
    if arg == '/sourceDependencies':
        skip = True
        continue
    if arg == '/c' or arg.startswith(('/Fo','/Fd')) or arg.lower().endswith('.cc'):
        continue
    if arg.startswith('/I'):
        for old in (str(base/'source'),str(root)):
            if arg == '/I'+old or arg.startswith('/I'+old+'\\engine'):
                arg = '/I'+str(source)+arg[len('/I'+old):]
                break
    command.append(arg)
command += ['/Zs','/U_CRT_SECURE_NO_WARNINGS',str(source/'tests/tools/qwen_request_lifecycle_test.cc')]
result = build.execute(command,env,work/'compile',60)
summary = {'status':'STRICT_CANONICAL_SYNTAX_PASS','scope':'Frozen staged engine and canonical consumer, MSVC /W4 /WX /Zs with CRT warning suppression explicitly undefined; no link/model/GPU run or CMake configure.',
           'result':result,'source_pins':pins,'SDK_builds':0,'GPU_runs':0,'HTTP':0}
build.save(work/'summary.json',summary)
print(json.dumps({'status':summary['status'],'seconds':result['process_wall_seconds']},indent=2))
