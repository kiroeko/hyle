from pathlib import Path
import difflib
import hashlib
import json
import shutil

S = Path(__file__).resolve().parent
ROOT = S.parents[2]

def identity(path):
    path = Path(path).resolve()
    payload = path.read_bytes()
    return {"path": str(path), "bytes": len(payload),
            "sha256": hashlib.sha256(payload).hexdigest()}

def save(path, value):
    Path(path).write_text(json.dumps(value, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")

paths = ["include/hyle/compute/state_clone.h", "src/compute_state/state_versions.cc",
         "tests/compute_state/state_clone_test.cc"]
rows, changes = [], []
for relative in paths:
    source, before, snapshot = ROOT / relative, S / "before" / relative, S / "source" / relative
    snapshot.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(source, snapshot)
    rows.append({"relative": relative, "before": identity(before),
                 "current": identity(source), "snapshot": identity(snapshot)})
    changes.extend(difflib.unified_diff(
        before.read_text(encoding="utf-8").splitlines(keepends=True),
        source.read_text(encoding="utf-8").splitlines(keepends=True),
        fromfile="a/" + relative, tofile="b/" + relative))
(S / "product-changes.diff").write_text("".join(changes), encoding="utf-8")

reproduction = json.loads((S / "reproduction/summary.json").read_text(encoding="utf-8"))
assert reproduction["executed"] and reproduction["defect_confirmed"] and reproduction["exit"] == 1
assert identity(S / "reproduction/state_clone_test.cc")["sha256"] == "414601aa2338d79a2728e7131bf8cd4517d7016b35b35ef0eedba9a1e15be7fb"
unchanged = []
for relative in ["src/compute_state/state_internal.h"]:
    assert identity(ROOT / relative)["sha256"] == identity(S / "before" / relative)["sha256"]
    unchanged.append(identity(ROOT / relative))

design = {
    "status": "final_source_only_not_compiled_or_run_by_implementation_agent",
    "existing_root_expected_red": {
        "summary": identity(S / "reproduction/summary.json"),
        "exact_test": identity(S / "reproduction/state_clone_test.cc"),
        "result": "Original observer-fixed product object plus one fresh test TU actually exited1, one case with23 failures; product source was unchanged at reproduction.",
    },
    "new_tests": [
        {"name": "StateClone.OldFailedControlsCannotObserveOrCancelAReusedCopySlot",
         "coverage": "Six sequential old-control operations: wait/poll/ticket cancel/ticket destruction/draft cancel/draft destruction. A new accepted same-slot copy remains active across collect and publishes real bytes; a subsequent clone needs no extra rearm. Native wait/cancel counters expose erroneous cross-episode access."},
        {"name": "StateClone.FailedNativeObservationRevokesOwnershipBeforeColdRearm",
         "coverage": "The transparent original-CPU F2 wrapper reports one DataLoss after original wait succeeds, separately through poll/take and explicit wait. The first candidate retains that exact failure; after actual retirement/rearm old controls cannot touch the new accepted copy."},
        {"name": "StateClone.UnavailableExclusiveOutputRetainsTheSameCopyForRetry",
         "coverage": "An additional real ReadLease returned by original CPU F2 output prevents the original try_write from obtaining exclusivity. Unavailable keeps the same owner/live copy; release the extra reader and poll the same ticket to publish without cancellation, re-copy or cold rearm."},
        {"name": "StateClone.UnavailableNativeObservationKeepsItsAcceptedSlotForRetry",
         "coverage": "The transparent real-CPU F2 wrapper returns one Unavailable after original wait success, through both poll/take and explicit wait. Collect/rearm cannot retire/replace that accepted copy, another draft cannot claim its slot, and the same ticket can retry without another native submission. This models an observation boundary, not measured GPU readiness."},
    ],
    "existing_preserved": "Original observer-close deterministic regression, schema-extent fix and all original StateVersions/StateClone neighbors remain in the source.",
    "expected_final_cpu_cases": 37,
    "limits": [
        "Only root executed the recorded first reproduction. No final compile/test or any GPU/backend run was performed by this implementation agent.",
        "The DataLoss/Unavailable wrapper changes only one observation diagnostic after the original CPU copy; it is not an independently failed native GPU kernel, measured hardware pending state or a second executor. Actual native errors remain checked and cannot turn into success by this product change.",
        "The Unavailable case uses actual original output-reader exclusivity; no arbitrary pending outcome or fake lease is substituted.",
        "No public generation API or StateRecord layout change is introduced. TypedStateCopy keeps its original live Submission on Unavailable instead of freeing a slot whose public owner remains valid; fatal native status cleanup is unchanged.",
    ],
}
save(S / "test-design.json", design)
freeze = {
    "status": "source_frozen_for_root_incremental_build_and_independent_review",
    "scope": "Revoke the existing StateCell pending route/copy ownership before cancellation/fatal failure permits finite native slot reuse.",
    "files": rows,
    "unchanged_headers": unchanged,
    "diff": identity(S / "product-changes.diff"),
    "test_design": identity(S / "test-design.json"),
    "ownership_rules": [
        "pending denotes an unpublished schema member; route/copy jointly name only its currently accepted native copy.",
        "cancel_copy executes under the existing StateStore monitor, exchanges route/copy to UINT32_MAX before calling original driver.cancel, preserves pending and the first candidate failure.",
        "Every old Ticket native access proves its exact StateCell still owns its route/copy; failed/closed draft prechecks release any still-owned copy before returning original status.",
        "Explicit wait validates ownership before observer pinning; original native wait remains outside the monitor and uses the existing per-slot wait lock.",
        "Non-Unavailable native wait/take failures revoke and abandon their copy; Unavailable retains the same owner and original live Submission for retry, including the typed take wait-error branch.",
        "Successful take clears both route/copy before transferring its existing draft reference and writer permission to StateWriter.",
        "Store close/drain, actual native retirement, collect/rearm and observer exclusion remain in their original implementations."
    ]
}
save(S / "source-freeze.json", freeze)
print(json.dumps({"freeze": identity(S / "source-freeze.json"),
                  "files": [row["current"] for row in rows]}, indent=2))
