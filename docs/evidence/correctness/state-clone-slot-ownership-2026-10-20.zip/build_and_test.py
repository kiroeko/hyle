"""Four current CXX compiles; retained old product versus the same new tests."""
import concurrent.futures
import importlib.util
from pathlib import Path
import re
import sys
import xml.etree.ElementTree as ET

sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
ROOT = S.parents[2]
spec = importlib.util.spec_from_file_location('slot_build_helpers', S.parent/'projected-bind-cold-index/build.py')
h = importlib.util.module_from_spec(spec)
spec.loader.exec_module(h)
b, c = h.b, h.c
out = S/'checks'
out.mkdir(exist_ok=True)
(out/'tmp').mkdir(exist_ok=True)
prior = S.parent/'state-clone-observer-close/checks'
base = c.read(prior/'after-link-plan.json')
freeze = c.read(S/'source-freeze.json')
frozen = [v for row in freeze['files'] for v in (row['before'], row['current'], row['snapshot'])]
frozen += freeze['unchanged_headers']
frozen += [b.identity(S/'source-freeze.json'), b.identity(S/'independent-review.json')]
before_files = {c.key(row['current']['path']): row['before'] for row in freeze['files']}
recipes = {name: c.read(prior/('after-'+name+'-identity.json'))
    for name in ('state_versions', 'state_versions_test', 'state_clone_test')}

def check():
    for row in frozen:
        assert b.same(row), row['path']

# Reused before objects must have the exact old source/header, not current files.
for name in ('state_versions', 'state_versions_test'):
    receipt = recipes[name]
    assert b.same(receipt['object'])
    for dep in receipt['dependencies']:
        replacement = before_files.get(c.key(dep['path']))
        if replacement:
            assert (dep['bytes'], dep['sha256']) == (replacement['bytes'], replacement['sha256'])
            assert b.same(replacement)
        else:
            assert b.same(dep), dep['path']

rows = []
for arm, names in [('before', ['state_clone_test']), ('after', list(recipes))]:
    for name in names:
        recipe = recipes[name]
        source = Path(recipe['source']['path'])
        tag = arm+'-'+name
        command = b.host_command(recipe['command'], source, tag, out)
        if arm == 'before':
            command.insert(1, '/I'+str(S/'before/include'))
        rows.append(dict(arm=arm, name=name, tag=tag, source=b.identity(source),
            command=command, old_object=recipe['object'], object=str(out/(tag+'.obj'))))
plan = dict(base=str(prior/'after-link-plan.json'), compile=rows, frozen=frozen,
    host_TUs=4, native_TUs=0, SDK_rebuild=False, actual_header_owners=3,
    before_reuses=['state_versions', 'state_versions_test'])
c.save(out/'plan.json', plan)
for row in base['inputs']:
    assert b.same(row), row['path']
env, runtime = b.environment(base['command'], [row['path'] for row in base['inputs']], out)
c.save(out/'runtime-environment.json', dict(runtime=runtime, PATH=env['PATH']))

def compile_one(row):
    check()
    identity = out/(row['tag']+'-identity.json')
    if identity.exists():
        old = c.read(identity)
        if old['command'] == row['command'] and b.same(old['object']) and all(b.same(d) for d in old['dependencies']):
            print('REUSE', row['tag'], flush=True)
            return row['tag'], old
    c.execute(row['tag']+'-compile', row['command'], env, out)
    check()
    data = c.read(out/(row['tag']+'-deps.json'))['Data']
    header = S/'before/include/hyle/compute/state_clone.h' if row['arm']=='before' else ROOT/'include/hyle/compute/state_clone.h'
    assert c.key(header) in {c.key(p) for p in data['Includes']}
    result = dict(command=row['command'], source=row['source'], object=b.identity(row['object']),
        dependencies=[b.identity(p) for p in dict.fromkeys([data['Source'], *data['Includes']])])
    c.save(identity, result)
    return row['tag'], result

finished, errors = {}, []
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
    for future in concurrent.futures.as_completed([pool.submit(compile_one, row) for row in rows]):
        try:
            tag, result = future.result()
            finished[tag] = result
        except Exception as error:
            errors.append(repr(error))
c.save(out/'compile-summary.json', dict(passed=not errors, errors=errors))
assert not errors, errors
results = {}
for arm in ('before', 'after'):
    replacement = {c.key(row['old_object']['path']): finished[row['tag']]['object'] for row in rows if row['arm']==arm}
    lookup = {c.key(row['path']): row for row in base['inputs']}
    lookup.update({c.key(row['path']): row for row in replacement.values()})
    command = [replacement.get(c.key(arg), {}).get('path', arg) for arg in base['command']
        if not arg.upper().startswith(('/OUT:', '/MAP:', '/IMPLIB:', '/PDB:'))]
    image = out/(arm+'.exe')
    command += ['/OUT:'+str(image), '/MAP:'+str(image.with_suffix('.map')), '/IMPLIB:'+str(image.with_suffix('.lib'))]
    inputs = [lookup[c.key(arg)] for arg in command if Path(arg).is_absolute() and Path(arg).suffix.lower() in ('.obj', '.lib')]
    for row in inputs:
        assert b.same(row), row['path']
    check()
    c.save(out/(arm+'-link-plan.json'), dict(command=command, inputs=inputs))
    c.execute(arm+'-link', command, env, out)
    c.save(out/(arm+'-image.json'), b.identity(image))
    destination = S/'tests'/arm
    destination.mkdir(parents=True, exist_ok=True)
    filters = ('StateClone.OldFailedControlsCannotObserveOrCancelAReusedCopySlot:'
        'StateClone.FailedNativeObservationRevokesOwnershipBeforeColdRearm:'
        'StateClone.UnavailableExclusiveOutputRetainsTheSameCopyForRetry:'
        'StateClone.UnavailableNativeObservationKeepsItsAcceptedSlotForRetry') if arm=='before' else 'StateVersions.*:StateClone.*'
    c.save(destination/'inputs.json', dict(image=b.identity(image), filters=filters, runtime=runtime))
    try:
        c.execute('tests', [str(image), '--gtest_filter='+filters, '--gtest_output=xml:'+str(destination/'results.xml')], env, destination)
    except RuntimeError:
        assert arm=='before' and c.read(destination/'tests.result.json')['exit']==1
    cases = ET.parse(destination/'results.xml').findall('.//testcase')
    failed = [dict(name=t.attrib['classname']+'.'+t.attrib['name'], details=[f.text for f in t.findall('failure')])
        for t in cases if t.find('failure') is not None]
    skipped = sum(t.find('skipped') is not None for t in cases)
    expected = 4 if arm=='before' else sum(len(re.findall(r'TEST\(\s*'+suite+r'\s*,', (ROOT/path).read_text(encoding='utf-8')))
        for suite, path in [('StateVersions','tests/compute_state/state_versions_test.cc'), ('StateClone','tests/compute_state/state_clone_test.cc')])
    result = dict(executed=True, expected_red=arm=='before', cases=len(cases), expected_cases=expected,
        skipped=skipped, failure_cases=len(failed), failures=failed,
        exit=c.read(destination/'tests.result.json')['exit'],
        actual=[t.attrib['classname']+'.'+t.attrib['name'] for t in cases])
    result['passed'] = len(cases)==expected and not skipped and (bool(failed) if arm=='before' else not failed)
    c.save(destination/'summary.json', result)
    assert result['passed'], result
    results[arm] = result
c.save(S/'tests/summary.json', dict(passed=True, arms=results, GPU_run=False, model_run=False,
    host_TUs=4, native_TUs=0, SDK_rebuild=False,
    limits='Original real CPU F2 copy, sequential slot reuse and actual output-reader exclusion. Fatal/Unavailable diagnostics are test-only transparent observation boundaries after original CPU wait success; no GPU pending/error claim.'))
print('STATE_SLOT_RED_GREEN', results['before']['failure_cases'], results['after']['cases'], flush=True)
