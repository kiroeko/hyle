"""Seal the actual retained-control slot-reuse red/green evidence, no binaries."""
import hashlib
import json
from pathlib import Path
import shutil
import zipfile

S = Path(__file__).resolve().parent
ROOT = S.parents[2]

def read(path):
    return json.loads(Path(path).read_text(encoding="utf-8-sig"))

def identity(path):
    path = Path(path).resolve()
    payload = path.read_bytes()
    return {"path": str(path), "bytes": len(payload),
            "sha256": hashlib.sha256(payload).hexdigest()}

def save(path, value):
    Path(path).write_text(json.dumps(value, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")

def key(path):
    return str(Path(path).resolve()).casefold()

freeze = read(S / "source-freeze.json")
before_by_path = {}
for row in freeze["files"]:
    assert identity(Path(row["current"]["path"]))["sha256"] == row["current"]["sha256"]
    assert identity(Path(row["snapshot"]["path"]))["sha256"] == row["current"]["sha256"]
    assert identity(Path(row["before"]["path"]))["sha256"] == row["before"]["sha256"]
    before_by_path[key(row["current"]["path"])] = row["before"]
review = read(S / "independent-review.json")
assert review["blocking_findings"] == []
assert review["source_freeze"]["sha256"] == identity(S / "source-freeze.json")["sha256"]

tests = read(S / "tests/summary.json")
first = read(S / "reproduction/summary.json")
plan = read(S / "checks/plan.json")
assert tests["passed"] and tests["host_TUs"] == 4 and tests["native_TUs"] == 0
assert not tests["GPU_run"] and not tests["model_run"] and not tests["SDK_rebuild"]
assert tests["arms"]["before"]["cases"] == 4 and tests["arms"]["before"]["failure_cases"] == 3
assert tests["arms"]["before"]["exit"] == 1 and tests["arms"]["before"]["expected_red"]
assert tests["arms"]["after"]["cases"] == 37 and tests["arms"]["after"]["failure_cases"] == 0
assert tests["arms"]["after"]["exit"] == 0 and tests["arms"]["after"]["skipped"] == 0
assert first["executed"] and first["defect_confirmed"] and first["exit"] == 1
assert len(first["failures"]) == 23
assert identity(S / "reproduction/state_clone_test.cc")["sha256"] == "414601aa2338d79a2728e7131bf8cd4517d7016b35b35ef0eedba9a1e15be7fb"
assert len(plan["compile"]) == 4 and plan["actual_header_owners"] == 3
assert read(S / "checks/compile-summary.json")["passed"]

# Carry the exact dependency receipts for the two legitimately reused before
# owners into this archive. Their old hashes match this batch's before files,
# rather than the now-modified product at the original path.
prior = S.parent / "state-clone-observer-close/checks"
reused = []
for name in plan["before_reuses"]:
    receipt_path = prior / ("after-" + name + "-identity.json")
    deps_path = prior / ("after-" + name + "-deps.json")
    receipt = read(receipt_path)
    changed = []
    for dep in receipt["dependencies"]:
        expected = before_by_path.get(key(dep["path"]))
        if expected:
            assert dep["bytes"] == expected["bytes"] and dep["sha256"] == expected["sha256"]
            changed.append({"compiler_dependency": dep, "preserved_before": expected})
    assert any(Path(row["compiler_dependency"]["path"]).name.lower() == "state_clone.h" for row in changed)
    destination = S / "checks/reused-before-owners"
    destination.mkdir(exist_ok=True)
    for path in (receipt_path, deps_path):
        shutil.copyfile(path, destination / path.name)
    if name == "state_versions_test":
        source = Path(receipt["source"]["path"])
        assert identity(source)["sha256"] == receipt["source"]["sha256"]
        target = S / "source/context/tests/compute_state/state_versions_test.cc"
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(source, target)
    reused.append({"owner": name, "receipt": identity(destination / receipt_path.name),
                   "compiler_dependencies": identity(destination / deps_path.name),
                   "object": receipt["object"], "matched_before_dependencies": changed})

fresh = []
for row in plan["compile"]:
    tag, arm = row["tag"], row["arm"]
    expected = (S / "before/include/hyle/compute/state_clone.h" if arm == "before"
                else ROOT / "include/hyle/compute/state_clone.h")
    deps_path = S / "checks" / (tag + "-deps.json")
    receipt_path = S / "checks" / (tag + "-identity.json")
    deps, receipt = read(deps_path), read(receipt_path)
    actual = [p for p in deps["Data"]["Includes"] if Path(p).name.lower() == "state_clone.h"]
    assert len(actual) == 1 and key(actual[0]) == key(expected)
    selected = [dep for dep in receipt["dependencies"] if Path(dep["path"]).name.lower() == "state_clone.h"]
    assert len(selected) == 1 and selected[0]["sha256"] == identity(expected)["sha256"]
    fresh.append({"arm": arm, "owner": row["source"], "header": selected[0],
                  "compiler_dependencies": identity(deps_path), "receipt": identity(receipt_path)})
save(S / "actual-compiler-closure.json", {"fresh": fresh, "reused_before": reused})

# Suggestions only. Root owns the deletion script and exact live-target review.
candidate_bases = [S / "reproduction/tests", S / "checks/before",
                   S.parent / "state-clone-observer-close/checks/after"]
cleanup = []
for base in candidate_bases:
    for suffix in (".exe", ".map", ".lib", ".exp"):
        path = base.with_suffix(suffix)
        if path.is_file():
            cleanup.append(identity(path))
save(S / "cleanup-candidates.json", {
    "status": "suggestions_only_no_files_deleted_no_test_ps1_written",
    "keep": str(S / "checks/after.exe"),
    "reason": "Keep the newest passing CPU image/objects. Final before and initial reproduction images are reconstructible from retained source, recipes, receipts and old object closure; the observer-only CPU after image is superseded.",
    "files": cleanup,
    "bytes": sum(row["bytes"] for row in cleanup),
})

archive_path = ROOT / "docs/evidence/correctness/state-clone-slot-ownership-2026-10-20.zip"
assert not archive_path.exists(), "Do not overwrite sealed evidence"
allowed = {".py", ".h", ".cc", ".json", ".log", ".xml", ".diff", ".ps1"}
files = sorted(path for path in S.rglob("*") if path.is_file()
               and path.suffix.lower() in allowed
               and not any(part.lower() == "tmp" or part.lower().startswith("cleanup")
                           for part in path.relative_to(S).parts))
payloads = []
with zipfile.ZipFile(archive_path, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
    for path in files:
        row = identity(path)
        row["member"] = path.relative_to(S).as_posix()
        payloads.append(row)
        archive.writestr(row["member"], path.read_bytes())
    archive.writestr("payload-sha256.json", json.dumps(payloads, indent=2))
with zipfile.ZipFile(archive_path) as archive:
    assert archive.testzip() is None
    for row in payloads:
        payload = archive.read(row["member"])
        assert len(payload) == row["bytes"] and hashlib.sha256(payload).hexdigest() == row["sha256"]

body = {
    "date": "2026-10-20",
    "scope": "Common StateClone ownership of a finite original native copy slot, including retained failed controls, cancellation, explicit wait/poll and retry.",
    "defect": "A failed/cancelled StateCell and retained Ticket/Draft kept route/copy ordinals after native cleanup and explicit cold rearm. Old wait could observe a newer copy; old cancellation/destruction could cancel or retire it. Typed take also freed an Unavailable copy while its public owner remained valid.",
    "fix": "Revoke existing StateCell route/copy ownership before original cancellation/fatal-error retirement; every ticket native entry validates its retained record's ownership before access/observer admission. Preserve pending publication semantics and first candidate failure; successful writer transfer clears both native indices. Unavailable preserves original live Submission and retry ownership. No public generation API or StateRecord layout change.",
    "actual_tests": tests,
    "initial_reproduction": {"cases": 1, "exit": 1, "failure_assertions": 23,
                             "summary": identity(S / "reproduction/summary.json"),
                             "exact_source": identity(S / "reproduction/state_clone_test.cc")},
    "final_before": "The same final four new tests against the retained old product/old header execute with3 failing cases and1 passing reader-exclusivity control. Old fatal-observation failure includes its original Bad expected access exception; the unexecuted remainder of that old case is not claimed as coverage.",
    "final_after": "37 actual StateVersions/StateClone cases, zero failures/skips, including six old-control actions, fatal poll and wait, original extra-reader try_write Unavailable and one diagnostic Unavailable through poll/wait. Original observer-close and schema-extent neighbors remain included.",
    "compiler_closure": {"fresh_CXX": 4, "native_TUs": 0, "SDK_rebuild": False,
                         "fresh": fresh, "before_reused_owners": reused},
    "freeze": freeze,
    "independent_review": review,
    "test_design": read(S / "test-design.json"),
    "archive": identity(archive_path),
    "payloads": payloads,
    "archive_verified": {"CRC": True, "all_payload_SHA256": True},
    "limits": [
        "Actual Windows CPU only. No CUDA/Vulkan/Apple pending native run, model validation, GPU profile or throughput result for this batch.",
        "DataLoss/Unavailable diagnostics are transparent test-only observation boundaries after original CPU wait success. They do not prove a failing GPU kernel, hardware pending timing or recovery of a cached native failure; actual native errors remain checked.",
        "The separate Unavailable reader test uses an actual additional original F2 output ReadLease and genuine try_write exclusivity, then retries the same copy without resubmission.",
        "The independent source review and these focused cases do not prove all cross-platform State lifetime or the full inference architecture complete.",
        "No executable/object/library/map payloads or cleanup suggestions/receipts are included in the archive. No files were deleted while publishing."
    ],
}
save(archive_path.with_suffix(".json"), body)
print(json.dumps({"archive": identity(archive_path), "report": identity(archive_path.with_suffix(".json")),
                  "payloads": len(payloads), "CRC": True, "all_payload_SHA256": True,
                  "cleanup_suggestion": identity(S / "cleanup-candidates.json")}, indent=2))
