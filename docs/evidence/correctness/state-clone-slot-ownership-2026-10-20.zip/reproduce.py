"""One new test TU on the retained observer-correct CPU product closure."""
import importlib.util
from pathlib import Path
import sys
import xml.etree.ElementTree as ET

sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
A = S.parent
ROOT = S.parents[2]
spec = importlib.util.spec_from_file_location('slot_ownership_repro_helpers', A/'projected-bind-cold-index/build.py')
h = importlib.util.module_from_spec(spec)
spec.loader.exec_module(h)
b, c = h.b, h.c
out = S/'reproduction'
out.mkdir(exist_ok=False)
(out/'tmp').mkdir()
prior = A/'state-clone-observer-close/checks'
base_path = prior/'after-link-plan.json'
base = c.read(base_path)
recipe = c.read(prior/'after-state_clone_test-identity.json')
source = ROOT/'tests/compute_state/state_clone_test.cc'
frozen = [b.identity(p) for p in (source, ROOT/'src/compute_state/state_versions.cc',
    ROOT/'src/compute_state/state_internal.h', ROOT/'include/hyle/compute/state_clone.h')]
command = b.host_command(recipe['command'], source, 'clone-test', out)
for row in base['inputs']:
    assert b.same(row), row['path']
env, runtime = b.environment(base['command'], [row['path'] for row in base['inputs']], out)
c.save(out/'inputs.json', dict(base_path=str(base_path), frozen=frozen, compiler_command=command,
    runtime=runtime, unchanged_product_object=c.read(prior/'after-state_versions-identity.json')['object']))
c.execute('clone-test-compile', command, env, out)
for row in frozen:
    assert b.same(row), row['path']
dep = c.read(out/'clone-test-deps.json')['Data']
obj = b.identity(out/'clone-test.obj')
c.save(out/'clone-test-identity.json', dict(command=command, source=frozen[0], object=obj,
    dependencies=[b.identity(p) for p in dict.fromkeys([dep['Source'], *dep['Includes']])]))
old_key = c.key(recipe['object']['path'])
assert sum(c.key(row['path'])==old_key for row in base['inputs'])==1
lookup = {c.key(row['path']): row for row in base['inputs']}
lookup[c.key(obj['path'])] = obj
argv = [obj['path'] if c.key(arg)==old_key else arg for arg in base['command']
    if not arg.upper().startswith(('/OUT:', '/MAP:', '/IMPLIB:', '/PDB:'))]
image = out/'tests.exe'
argv += ['/OUT:'+str(image), '/MAP:'+str(image.with_suffix('.map')), '/IMPLIB:'+str(image.with_suffix('.lib'))]
inputs = [lookup[c.key(arg)] for arg in argv if Path(arg).is_absolute() and Path(arg).suffix.lower() in ('.obj', '.lib')]
c.save(out/'link-plan.json', dict(command=argv, inputs=inputs))
c.execute('tests-link', argv, env, out)
c.save(out/'image.json', b.identity(image))
filters = 'StateClone.OldFailedControlsCannotObserveOrCancelAReusedCopySlot'
try:
    c.execute('tests', [str(image), '--gtest_filter='+filters, '--gtest_output=xml:'+str(out/'results.xml')], env, out)
except RuntimeError:
    assert c.read(out/'tests.result.json')['exit']==1
cases = ET.parse(out/'results.xml').findall('.//testcase')
failures = [f.text for case in cases for f in case.findall('failure')]
assert len(cases)==1 and cases[0].find('skipped') is None and failures
c.save(out/'summary.json', dict(executed=True, defect_confirmed=True, expected_red=True, cases=1,
    exit=c.read(out/'tests.result.json')['exit'], failures=failures,
    source_or_SDK_product_compilations=0, test_TUs=1,
    limits='Sequential real CPU F2 copies and legal retained controls; this reproduces native-slot ownership reuse without intentional undefined concurrency.'))
print('STATE_SLOT_OWNERSHIP_REPRODUCED', len(failures), flush=True)
