#include "source/engine/models/qwen35/main.cc"
#include "source/tests/tools/qwen_request_ledger_case.h"
#include "source/tests/tools/qwen_request_stop_case.h"
int main(int argc,char **argv){try{if(argc!=2)throw std::runtime_error("request-ledger PREPARED_INPUTS");const auto result=qwen_request_ledger_case::run(argv[1]);if(result)return result;return qwen_request_stop_case::run(argv[1]);}catch(const std::exception &e){std::cerr<<"request_ledger_failure="<<e.what()<<"\n";return 1;}}
