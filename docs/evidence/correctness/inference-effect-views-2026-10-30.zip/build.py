from pathlib import Path
import importlib.util
import os
import shutil
import subprocess
import sys
import xml.etree.ElementTree as ET

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = W.parents[1]
PREV = R / '.scratch/inference-private-handoff-20261030'
spec = importlib.util.spec_from_file_location('shared', R / '.scratch/inference-stage-handoff-20261030/build.py')
b = importlib.util.module_from_spec(spec)
spec.loader.exec_module(b)
b.W = b.b.W = b.b.s.W = b.b.s.b.W = W
read, save, pin, exact, key = b.read, b.save, b.pin, b.exact, b.key

def prepare():
    base = read(PREV / 'model-link-base.json')
    changed = {key(R / x) for x in subprocess.check_output(
        ['git', 'diff', '--name-only', '--', 'engine', 'include', 'src'], cwd=R, text=True).splitlines()}
    sdk = read(base['sdk_engine_dependencies']['path'])
    rows = {key(x['object']): x for x in sdk['inspected']}
    rows.update({key(x['object']): x for x in sdk['engine_consumers'] if 'dependencies' in x})
    inspected, unavailable, matches = [], [], []
    for item in base['retained']:
        exact(item)
        adjacent = Path(item['path']).parent / 'dependencies.json'
        row = rows.get(key(item['path']))
        path = adjacent if adjacent.is_file() and 'Data' in read(adjacent) else Path(row['dependencies']['path']) if row else None
        if path is None:
            unavailable.append(item['path'])
            continue
        data = read(path)['Data']
        inspected.append(dict(object=item['path'], dependencies=pin(path)))
        if any(key(x) in changed for x in [data['Source'], *data['Includes']]): matches.append(item['path'])
    assert not matches, matches
    recipes = {
        'cli': read(PREV / 'plan.json')['consumers']['cli'],
        'views': read(R / '.scratch/inference-view-storage-20261030/plan.json')['units']['views'],
        'paged': read(R / '.scratch/inference-stage-resources-20261030/plan.json')['consumers']['paged-test']}
    consumers = {name: dict(source=x['source'], compile=b.b.s.relocated(x['compile'], name)) for name, x in recipes.items()}
    (W / 'bin').mkdir(exist_ok=True)
    shutil.copyfile(base['runtime']['path'], W / 'bin' / Path(base['runtime']['path']).name)
    save(W / 'plan.json', dict(base=pin(PREV / 'model-link-base.json'), base_commit='22bc2a555',
        retained=base['retained'], runtime=base['runtime'], original_link=base['link'],
        original_consumer=read(base['previous_consumer']['path'])['object']['path'],
        sdk_engine_dependencies=base['sdk_engine_dependencies'], consumers=consumers, units={},
        sdk_dependency_audit=dict(inspected=inspected, unavailable=unavailable, matches=matches),
        cases={'views': dict(unit='views', filter='InferenceSubmissionViewsCuda.*', tests=4),
            'paged': dict(unit='paged', filter='GraphPagedAppendSourceCuda.*', tests=7),
            'recursive': read(PREV / 'plan.json')['cases']['recursive']},
        SDK_CXX=0, NVCC=0, downloads=0, performance_experiments=0))
    print('3 affected consumer/test TUs;227 SDK objects reused; no SDK/NVCC/download/benchmark.', flush=True)

def link(name, attempt):
    p = read(W / 'plan.json')
    receipt = read(W / 'compile' / name / 'receipt.json')
    for item in [receipt['object'], *p['retained']]: exact(item)
    args = []
    for arg in p['original_link']:
        if key(arg) == key(p['original_consumer']): arg = receipt['object']['path']
        for prefix, suffix in [('/OUT:', '.exe'), ('/PDB:', '.pdb'), ('/IMPLIB:', '.lib'), ('/MAP:', '.map')]:
            if arg.upper().startswith(prefix):
                arg = prefix + str((W / 'bin' / name).with_suffix(suffix))
                break
        args.append(arg)
    if name != 'cli':
        args.extend(str(R / '.scratch/build-compute-v2-dev/lib' / x) for x in ('gtest_main.lib','gtest.lib'))
    b.b.s.b.execute(args, W / 'link' / name / attempt, 240)
    save(W / ('ready-' + name + '.json'), pin(W / 'bin' / (name + '.exe')))

def run(name, attempt):
    p = read(W / 'plan.json')
    case = p['cases'][name]
    folder = W / 'runs' / name / attempt
    image = read(W / ('ready-' + case['unit'] + '.json'))
    exact(image)
    save(folder / 'image.json', image)
    os.environ.update(HF_HUB_OFFLINE='1', TRANSFORMERS_OFFLINE='1', HF_DATASETS_OFFLINE='1')
    if 'filter' in case:
        b.b.s.b.execute([image['path'],'--gtest_color=no','--gtest_fail_fast','--gtest_filter='+case['filter'],
            '--gtest_output=xml:'+str(folder / 'results.xml')], folder, 300)
        result = ET.parse(folder / 'results.xml').getroot()
        assert result.get('tests') == str(case['tests']) and result.get('failures') == result.get('errors','0') == '0'
        assert not result.findall('.//skipped')
        report = dict(status='PASS', tests=case['tests'], failures=0, skipped=0,
            cases=[dict(name=t.get('classname')+'.'+t.get('name'),
                properties={x.get('name'):x.get('value') for x in t.findall('./properties/property')}) for t in result.findall('.//testcase')])
    else:
        b.b.s.b.execute([image['path'],*case['args']], folder, 300)
        report = read(folder / 'stdout.log')
        assert report['live_committed_versions'] == 0
    save(folder / 'report.json', report)
    print('PASS', name, flush=True)

if __name__ == '__main__':
    action = sys.argv[1]
    if action == 'prepare': prepare()
    elif action == 'compile': b.compile_group(sys.argv[2], sys.argv[3:])
    elif action == 'link':
        for name in sys.argv[3:]: link(name, sys.argv[2])
    elif action == 'run':
        for name in sys.argv[3:]: run(name, sys.argv[2])
    else: raise ValueError(action)
