from pathlib import Path
import importlib.util
import shutil
import subprocess
import sys
import zipfile

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = W.parents[1]
spec = importlib.util.spec_from_file_location('build', W / 'build.py')
b = importlib.util.module_from_spec(spec)
spec.loader.exec_module(b)
read, save, pin, exact, key = b.read, b.save, b.pin, b.exact, b.key

def stable(value):
    if isinstance(value, dict):
        return {k: stable(v) for k, v in value.items() if not k.endswith('_seconds') and not k.endswith('_per_second')}
    if isinstance(value, list): return [stable(v) for v in value]
    return value

def prepare():
    p = read(W / 'plan.json')
    reports = {name: read(W / 'runs' / name / 'attempt1/report.json') for name in p['cases']}
    assert reports['views']['tests'] == 4 and reports['paged']['tests'] == 7
    for name in ('views','paged'): assert reports[name]['failures'] == reports[name]['skipped'] == 0
    anchor = b.PREV / 'runs/recursive/attempt1/report.json'
    assert stable(read(anchor)) == stable(reports['recursive'])
    consumers = {}
    for name in p['consumers']:
        path = W / 'compile' / name / 'receipt.json'
        receipt = read(path)
        for item in [receipt['object'], *receipt['source_identities']]: exact(item)
        consumers[name] = dict(receipt=pin(path), object=receipt['object'])
    assert len(p['retained']) == 227 and not p['sdk_dependency_audit']['matches']
    for item in p['retained']: exact(item)
    save(W / 'analysis.json', dict(status='PASS_FINITE_EFFECT_ONLY_SUBMISSION_VIEWS_CHECKS',
        gtests=11, finite_full_model_processes=1, failures=0, skipped=0,
        cases={name:pin(W / 'runs' / name / 'attempt1/report.json') for name in reports},
        recursive_original_all_non_timing_fields_equal=True, recursive_baseline=pin(anchor),
        affected_consumer_CXX_TUs=3, retained_SDK_engine_objects=227,
        SDK_CXX=0, NVCC=0, downloads=0, performance_experiments=0, performance_claim=False,
        original_fixture_checks=['Both existing zero-tensor dual-Append producers feed Attention through the common bundle.',
            'Original producer/consumer submits, bounded pending gates, device_wait=1 and host_wait=0 remain.',
            'Original exact page values, NaN sentinel and old snapshots remain.',
            'Actual pure SubmissionSource without selected tensor/Store/Page exports transfers only its original completion.',
            'Count mismatch preserves the original completion; duplicate capture refuses.',
            'First and second wrong tensor owners preserve the original partial bundle and recovery.',
            'Default and cleared bundles still return the original empty-output FailedPrecondition.'],
        limits=['Windows single-CUDA-context checks; not multi-GPU or cross-context support.',
            'Multiowner Store/Page combinations and complete second engine model remain separately unverified.',
            'No native fault injection, Apple/Vulkan run or throughput/peer/memory benchmark this batch.']))
    base = read(p['base']['path'])
    base.update(schema='hyle.effect-views.current-link-base.v1', base=p['base'],
        current_consumers={**base['current_consumers'], **consumers}, previous_consumer=consumers['cli']['receipt'],
        consumer_source=pin(p['consumers']['cli']['source']), compile=p['consumers']['cli']['compile'],
        link=[consumers['cli']['object']['path'] if key(arg) == key(p['original_consumer']) else arg for arg in p['original_link']])
    save(W / 'model-link-base.json', base)
    targets = []
    for path in sorted((W / 'bin').iterdir()):
        assert path.is_file() and path.suffix.lower() in ('.exe','.dll','.lib','.exp')
        targets.append(pin(path))
    save(W / 'cleanup-targets.json', dict(boundary=str(W / 'bin'), targets=targets))
    (W / 'product.diff').write_bytes(subprocess.check_output(['git','diff','--','engine','tests'], cwd=R))
    print('PASS11 tests+1 full-model process; complete non-timing recursive report unchanged.')

def finish():
    p, a = read(W / 'plan.json'), read(W / 'analysis.json')
    cleanup = read(W / 'cleanup-report.json')
    assert cleanup['status'] == 'REMOVED_EXACT_FLAT_BATCH_IMAGES'
    shutil.copyfile(R / 'test.ps1', W / 'cleanup.ps1')
    out = R / 'docs/evidence/correctness/inference-effect-views-2026-10-30.json'
    save(out, dict(schema='hyle.correctness.effect-views.v1', date='2026-10-30', base_commit=p['base_commit'],
        status='EFFECT_ONLY_STAGES_USE_ORIGINAL_SUBMISSION_BUNDLE',
        contract=dict(zero_tensor='A successful capture may select no tensor outputs, including Store/Page-only or completion-only stages.',
            failure='Record zero-tensor capture only after all selected views capture. A nonempty first-output failure remains distinct and keeps its exact original Status and recovery.',
            authority='No new executor, owner, submission, retirement or resource permission; the one boolean records selection success only. Original whole-Graph wait, Source detach and typed view permissions remain authoritative.'),
        checks=a, cleanup=cleanup, retained_build_plan=pin(W / 'model-link-base.json'),
        source_files=[pin(R / x) for x in ('engine/inference/submission_views.h','tests/tools/inference_submission_views_test.cc','tests/graph_batch/paged_append_source_test.cc')],
        archive='inference-effect-views-2026-10-30.zip'))
    files = [W / x for x in ('analysis.json','build.py','finish.py','product.diff','cleanup.ps1','cleanup-report.json','cleanup-targets.json')]
    for prefix in ('runs','compile','link'):
        files.extend(x for x in (W / prefix).rglob('*') if x.is_file() and x.suffix.lower() in ('.json','.log','.xml'))
    with zipfile.ZipFile(out.with_suffix('.zip'),'w',zipfile.ZIP_DEFLATED) as archive:
        for path in sorted(set(files)): archive.write(path,path.relative_to(W).as_posix())
    print('Recorded effect-only architecture evidence without a performance claim.')

if __name__ == '__main__': {'prepare':prepare,'finish':finish}[sys.argv[1]]()
