"""Run the already linked Tiny image; unrelated GTest source edits do not relink it."""
from pathlib import Path
import importlib.util
import json
import sys
sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
F = W / 'refinement'
spec = importlib.util.spec_from_file_location('actual_model_build', F / 'build.py')
b = importlib.util.module_from_spec(spec); spec.loader.exec_module(b)
t = b.t
def run(name):
    plan = t.read(F / 'run-plan.json')
    case = plan['cases'][name]
    assert name != 'gtest'
    t.exact(plan['fixture']); t.exact(case['ready'])
    ready = t.read(case['ready']['path'])
    for field in ('image', 'inputs', 'source_freeze'): t.exact(ready[field])
    for source in t.read(ready['source_freeze']['path'])['snapshots']: t.exact(source['snapshot'])
    for receipt in ready['compiled'].values(): t.exact(receipt['object'])
    t.exact(ready['retained_tiny']['object'])
    out = F / 'runs' / name
    assert not out.exists(), 'No automatic reruns'
    process = t.execute(case['command'], out, 300)
    t.save(out / 'as-run.json', dict(helper=t.pin(__file__), ready=case['ready'],
        image=ready['image'], inputs=ready['inputs'], source_freeze=ready['source_freeze'],
        run_plan=t.pin(F / 'run-plan.json'), fixture=plan['fixture'], process=process,
        boundary='Linked model image and immutable source snapshots; unrelated GTest-only edits do not change this image.'))
    reports = [json.loads(line) for line in (out / 'stdout.log').read_text(
        encoding='utf-8-sig').splitlines() if line.startswith('{')]
    assert reports and all(row.get('status', 'PASS') == 'PASS'
        for row in reports if 'case' in row or 'mode' in row)
    print('NATIVE EXIT0', name, 'PID', process['pid'], 'reports', len(reports))
if __name__ == '__main__': run(sys.argv[1])
