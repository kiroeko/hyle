"""One finite GTest process and six existing consumers. Root executes serially."""
from pathlib import Path
import importlib.util
import json
import sys
sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('physical_build', W / 'build.py')
b = importlib.util.module_from_spec(spec)
spec.loader.exec_module(b)
t, R = b.t, b.R
FIXTURE = R / '.scratch/inference-paged-frame-20261026/tiny-recursive-input'
FILTER = ':'.join([
    'ConfigurationInput.*',
    'GraphSlotsCudaExecution.DeviceStoreUpdatesPrivateIndicesOnTheOriginalQueue',
    'GraphRegions.PreparedReplayChecksReplacedQueueOwnerAndClosedContext',
    'GraphRegions.CaptureReuseKeepsFullViewAliasAndPrivateBindingRequirements',
    'GraphRegions.CaptureVariantEndAndSealFailuresCannotPublishAnOldRoute',
    'GraphRegions.UnknownCaptureIdentityRepreparesAfterSameTupleBindingEpisode',
    'GraphRegions.OwnedNativeInputsKeepFirstCoveringPermissionAcrossRetryAndRebind',
])
CASES = {f'{name}-{backend}': ('tiny', ['--' + backend, str(FIXTURE), flag])
    for name, flag in [('policies', '--sampling-policies'),
                       ('sampling', '--mtp-sampling'),
                       ('wave', '--generation-wave')]
    for backend in ('cpu', 'cuda')}
CASES['gtest'] = ('gtest', ['--gtest_filter=' + FILTER,
    '--gtest_output=xml:' + str(W / 'runs/gtest/result.xml')])

def prepare():
    b.validate()
    ready = {name: t.read(W / f'ready-{name}.json') for name in ('tiny', 'gtest')}
    for value in ready.values():
        t.exact(value['image']); t.exact(value['inputs'])
    t.save(W / 'run-plan.json', dict(helper=t.pin(__file__),
        fixture=t.pin(FIXTURE / 'weights.tsv'), native_processes=len(CASES),
        automatic_retries=0, cases={name: dict(ready=t.pin(W / f'ready-{consumer}.json'),
            command=[ready[consumer]['image']['path'], *args])
            for name, (consumer, args) in CASES.items()},
        performance_claim=False, full_model_quality_claim=False))
    print('RUN PLAN: 12 filtered GTests in 1 process; six finite model consumers; no native started')

def run(name):
    b.validate()
    plan = t.read(W / 'run-plan.json')
    for key in ('helper', 'fixture'): t.exact(plan[key])
    case = plan['cases'][name]
    t.exact(case['ready'])
    ready = t.read(case['ready']['path'])
    for key in ('image', 'inputs', 'source_freeze'): t.exact(ready[key])
    out = W / 'runs' / name
    assert not out.exists(), 'Keep every native attempt; repair metadata offline'
    process = t.execute(case['command'], out, 300)
    t.save(out / 'as-run.json', dict(image=ready['image'], ready=case['ready'],
        inputs=ready['inputs'], source_freeze=ready['source_freeze'],
        run_plan=t.pin(W / 'run-plan.json'), fixture=plan['fixture'], process=process))
    reports = [json.loads(line) for line in (out / 'stdout.log').read_text(
        encoding='utf-8-sig').splitlines() if line.startswith('{')]
    if name != 'gtest':
        assert reports and all(row.get('status', 'PASS') == 'PASS'
            for row in reports if 'case' in row or 'mode' in row)
    print('NATIVE EXIT0', name, 'PID', process['pid'], 'reports', len(reports))

if __name__ == '__main__':
    if sys.argv[1] == 'prepare': prepare()
    elif sys.argv[1] == 'run': run(sys.argv[2])
    else: raise ValueError(sys.argv[1])
