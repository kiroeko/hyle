"""Three incremental CXX actions and two links. Root owns all execution.

Reads parent successful receipts without calling its now-historical validate().
Keeps the first four-test failure and its baseline diagnostic unchanged.
"""
from pathlib import Path
import importlib.util
import re
import sys
sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = Path(r'C:\public\project-hyle\hyle')
BASE = W.parent
SDK = R / '.scratch/inference-indexed-store-20261028/build.py'
REGION = R / '.scratch/inference-identical-capture-inputs-20261027/compile/region-test2/compiled.json'
spec = importlib.util.spec_from_file_location('physical_spans_refinement_original_driver', SDK)
t = importlib.util.module_from_spec(spec); spec.loader.exec_module(t); t.W = W
SOURCES = {'executable': 'src/graph/executable.cc',
    'configuration-test': 'tests/graph/configuration_input_test.cc',
    'region-test': 'tests/graph/region_provider_test.cc'}


def deps(receipt):
    return receipt.get('dependencies', receipt.get('compiler_dependencies'))


def prepare():
    parent = t.read(BASE / 'final-build-plan.json')
    ready = {name: t.read(BASE / f'ready-{name}.json') for name in ('tiny', 'gtest')}
    for row in ready.values(): t.exact(row['inputs']); t.exact(row['recipe'])
    priors = {name: ready['gtest']['compiled'][name] for name in ('executable', 'configuration-test')}
    priors['region-test'] = t.read(REGION)
    region = ready['gtest']['retained_region_test']
    assert region['object'] == priors['region-test']['object']
    retained_sources = {name: receipt['source'] for name, receipt in ready['gtest']['compiled'].items()
                        if name in ('resources', 'cuda-test')}
    assert set(retained_sources) == {'resources', 'cuda-test'}
    for row in retained_sources.values(): t.exact(row)
    units = {}
    for name, relative in SOURCES.items():
        prior = priors[name]
        assert prior['process']['exit'] == 0
        t.exact(prior['command']); t.exact(deps(prior))
        before = t.command(prior['command']['path'])
        source = t.read(deps(prior)['path'])['Data']['Source']
        args = []
        for i, arg in enumerate(before):
            if t.key(arg) == t.key(source): arg = str(R / relative)
            elif i and before[i-1].lower() == '/sourcedependencies': arg = str(W / f'compile/{name}/dependencies.json')
            elif arg.lower().startswith('/fo'): arg = '/Fo' + str(W / f'compile/{name}/unit.obj')
            elif arg.lower().startswith('/fd'): arg = '/Fd' + str(W / f'compile/{name}/unit.pdb')
            args.append(arg)
        assert all(flag in args for flag in ('/MD', '/O2', '/WX', '/c'))
        assert sum(t.key(arg) == t.key(R / relative) for arg in args) == 1
        t.save(W / f'recipes/{name}.json', dict(command=args, timeout_seconds=300))
        units[name] = dict(source=relative, original_command=prior['command'],
            original_dependencies=deps(prior), original_object=prior['object'],
            recipe=t.pin(W / f'recipes/{name}.json'))
    manifests, retained = {}, {}
    for consumer in ('tiny', 'gtest'):
        rows = t.read(ready[consumer]['inputs']['path'])
        assert len(rows) == (228 if consumer == 'tiny' else 232)
        relevant = ('executable',) if consumer == 'tiny' else tuple(SOURCES)
        mapping = {t.key(units[name]['original_object']['path']): str(W / f'compile/{name}/unit.obj') for name in relevant}
        for key in mapping:
            assert sum(t.key(row['path']) == key for row in rows) == 1
        manifests[consumer] = ready[consumer]['inputs']
        for row in rows:
            if t.key(row['path']) not in mapping: retained[t.key(row['path'])] = row
        args = []
        for arg in t.command(ready[consumer]['recipe']['path']):
            arg = mapping.get(t.key(arg), arg)
            for prefix, suffix in (('/OUT:', '.exe'), ('/PDB:', '.pdb'), ('/IMPLIB:', '.lib'), ('/MAP:', '.map')):
                if arg.upper().startswith(prefix): arg = prefix + str((W / 'bin' / consumer).with_suffix(suffix)); break
            args.append(arg)
        for replacement in mapping.values(): assert sum(t.key(arg) == t.key(replacement) for arg in args) == 1
        t.save(W / f'link-recipes/{consumer}.json', dict(command=args, timeout_seconds=240))
    stats = []
    for row in retained.values():
        st = Path(row['path']).stat(); assert st.st_size == row['bytes']
        stats.append(dict(path=row['path'], bytes=st.st_size, mtime_ns=st.st_mtime_ns, retained_sha256=row['sha256']))
    t.save(W / 'retained-input-stats.json', stats)
    env = t.read(BASE / 'environment.json'); env['PATH'] = str(W / 'bin') + ';' + env['PATH']
    t.save(W / 'environment.json', env)
    t.save(W / 'runtime.json', dict(PATH=env['PATH'], native=t.read(BASE / 'runtime.json')['native']))
    previous = []
    for directory in ('runs/gtest', 'runs/gtest-baseline', 'links/gtest-baseline'):
        for filename in ('command.json', 'process.json', 'stdout.log', 'stderr.log', 'result.xml'):
            path = BASE / directory / filename
            if path.is_file(): previous.append(t.pin(path))
    t.save(W / 'final-build-plan.json', dict(parent_plan=t.pin(BASE / 'final-build-plan.json'),
        parent_ready={name: t.pin(BASE / f'ready-{name}.json') for name in ready}, inputs=manifests,
        parent_source_freeze=t.pin(BASE / 'final-source-freeze.json'),
        original_driver=t.pin(SDK), units=units, retained_sources=retained_sources,
        retained_tiny=parent['retained_tiny'], retained_stats=t.pin(W / 'retained-input-stats.json'),
        environment=t.pin(W / 'environment.json'), runtime=t.pin(W / 'runtime.json'),
        links={name: t.pin(W / f'link-recipes/{name}.json') for name in ('tiny', 'gtest')},
        previous_actual_records=previous,
        historical_boundary='Parent 4CXX/2links all succeeded; GTest was 8pass/4fail. Baseline diagnostic link and OwnedNative case also failed at turn0. Preserve all actual records; none are rewritten as successful.',
        counts=dict(CXX=3, SDK_CXX=1, test_CXX=2, Model_CXX=0, links=2,
            tiny_inputs=228, gtest_inputs=232, NVCC=0, downloads=0),
        scope='Refresh executable only plus configuration and Region fixture tests. Reuse successful resources/cuda-test and current Tiny object. No call to parent validate or its stale canonical Region-source proof. Fresh Region CXX uses current header/ABI.'))
    print('PREPARED 3CXX/2links; no CXX/link/native process')


def plan():
    value = t.read(W / 'final-build-plan.json')
    for key in ('parent_plan', 'parent_source_freeze', 'original_driver', 'retained_stats', 'environment', 'runtime'):
        t.exact(value[key])
    for row in [*value['parent_ready'].values(), *value['inputs'].values(), *value['retained_sources'].values(), *value['links'].values()]:
        t.exact(row)
    for unit in value['units'].values():
        for key in ('original_command', 'original_dependencies', 'recipe'): t.exact(unit[key])
    return value


def freeze():
    value = plan(); path = W / 'expected-sources.json'
    expected = t.read(path) if path.exists() else {relative: t.pin(R / relative)['sha256'] for relative in SOURCES.values()}
    for relative, sha in expected.items(): assert t.pin(R / relative)['sha256'] == sha, relative
    if not path.exists(): t.save(path, expected)
    paths, roots = {}, [R / 'include', R]
    for unit in value['units'].values():
        for p in t.dep_paths(unit['original_dependencies']['path']):
            p = t.canonical(p)
            if t.project(p): paths[t.key(p)] = p
        roots.extend(Path(arg[2:]) for arg in t.command(unit['recipe']['path']) if arg.lower().startswith('/i'))
    pending, seen = [R / relative for relative in dict.fromkeys([*SOURCES.values(), *expected])], set()
    while pending:
        p = pending.pop().resolve()
        if t.key(p) in seen: continue
        seen.add(t.key(p)); paths[t.key(p)] = p
        for kind, name in re.findall(r'^\s*#\s*include\s*([<"])([^>"\r\n]+)[>"]', p.read_text(encoding='utf-8-sig'), re.M):
            q = next((candidate.resolve() for root in ([p.parent] if kind == '"' else []) + roots
                      if (candidate := root / name).is_file()), None)
            if q is not None and t.project(q): pending.append(q)
    t.save(W / 'frozen-project-dependencies.json', [t.pin(p) for p in paths.values()])
    snapshots = []
    for relative in expected:
        target = W / 'source' / relative; target.parent.mkdir(parents=True, exist_ok=True)
        with target.open('xb') as out: out.write((R / relative).read_bytes())
        snapshots.append(dict(original=t.pin(R / relative), snapshot=t.pin(target)))
    t.save(W / 'final-source-freeze.json', dict(helper=t.pin(__file__), expected=t.pin(path),
        dependencies=t.pin(W / 'frozen-project-dependencies.json'), snapshots=snapshots))
    print('SOURCE FROZEN', len(paths), 'project dependencies; no CXX/native process')


def validate():
    value = plan(); frozen = t.read(W / 'final-source-freeze.json')
    for key in ('helper', 'expected', 'dependencies'): t.exact(frozen[key])
    for row in t.read(frozen['dependencies']['path']): t.exact(row)
    for row in frozen['snapshots']: t.exact(row['original']); t.exact(row['snapshot'])
    return value, frozen


def parse_compile(name):
    _, frozen = validate(); assert name in SOURCES
    out = W / 'compile' / name; process = t.read(W / f'logs/{name}/process.json')
    assert process['exit'] == 0 and not process['timed_out']
    allowed = {t.key(row['path']): row for row in t.read(frozen['dependencies']['path'])}; actual = []
    for path in dict.fromkeys(t.dep_paths(out / 'dependencies.json')):
        if t.project(path):
            assert t.key(path) in allowed, ('Successful CXX: repair parser only; never recompile', str(path))
            t.exact(allowed[t.key(path)])
        actual.append(t.pin(path))
    t.save(out / 'actual-dependencies.json', actual)
    t.save(out / 'compiled.json', dict(source=t.pin(R / SOURCES[name]), object=t.pin(out / 'unit.obj'),
        process=process, command=t.pin(W / f'logs/{name}/command.json'), dependencies=t.pin(out / 'dependencies.json'),
        actual_dependencies=t.pin(out / 'actual-dependencies.json')))
    print('CXX metadata PASS', name)


def compile_unit(name):
    value, _ = validate(); assert name in SOURCES
    (W / 'compile' / name).mkdir(parents=True, exist_ok=False)
    t.execute(t.command(value['units'][name]['recipe']['path']), W / 'logs' / name, 300)
    parse_compile(name)


def link_unit(name):
    value, _ = validate(); assert name in ('tiny', 'gtest')
    required = ('executable',) if name == 'tiny' else tuple(SOURCES)
    compiled = {unit: t.read(W / f'compile/{unit}/compiled.json') for unit in required}
    for receipt in compiled.values(): t.exact(receipt['object'])
    for row in t.read(value['retained_stats']['path']):
        st = Path(row['path']).stat(); assert (st.st_size, st.st_mtime_ns) == (row['bytes'], row['mtime_ns'])
    t.exact(value['retained_tiny']['object'])
    mapping = {t.key(value['units'][unit]['original_object']['path']): compiled[unit]['object'] for unit in required}
    rows = [mapping.get(t.key(row['path']), row) for row in t.read(value['inputs'][name]['path'])]
    assert len(rows) == value['counts'][name + '_inputs']
    assert sum(t.key(row['path']) in {t.key(receipt['object']['path']) for receipt in compiled.values()} for row in rows) == len(compiled)
    t.save(W / f'inputs-{name}.json', rows)
    (W / 'bin').mkdir(exist_ok=True); native = t.read(value['runtime']['path'])['native']
    alias = W / 'bin' / Path(native['path']).name
    if not alias.exists(): alias.hardlink_to(native['path'])
    assert alias.samefile(native['path'])
    process = t.execute(t.command(value['links'][name]['path']), W / 'links' / name, 240)
    t.save(W / f'ready-{name}.json', dict(image=t.pin(W / f'bin/{name}.exe'), inputs=t.pin(W / f'inputs-{name}.json'),
        compiled=compiled, retained_tiny=value['retained_tiny'] if name == 'tiny' else None,
        process=process, recipe=t.pin(W / f'links/{name}/command.json'), runtime=value['runtime'],
        source_freeze=t.pin(W / 'final-source-freeze.json')))
    print('LINK PASS', name, len(rows), 'inputs')


if __name__ == '__main__':
    action = sys.argv[1]
    if action == 'prepare': prepare()
    elif action == 'freeze': freeze()
    elif action == 'preflight': validate()
    elif action == 'compile': compile_unit(sys.argv[2])
    elif action == 'parse-compile': parse_compile(sys.argv[2])
    elif action == 'link': link_unit(sys.argv[2])
    else: raise ValueError(action)
