"""Two SDK and two GTest CXX actions; reuse the current Tiny OBJ. Root executes.

Writing this helper does not prepare/freeze sources or start any native process.
All generated records are exclusive; parse-compile is independent of compilation.
"""
from pathlib import Path
import hashlib
import importlib.util
import re
import sys
sys.dont_write_bytecode = True

W = Path(__file__).resolve().parent
R = Path(r'C:\public\project-hyle\hyle')
BASE = R / '.scratch/inference-selected-cold-demand-20261028/validation/final'
COHORT = R / '.scratch/inference-store-cohort-20261028'
EXECUTABLE = R / '.scratch/inference-identical-capture-inputs-20261027'
DRIVER = R / '.scratch/inference-indexed-store-20261028/build.py'
spec = importlib.util.spec_from_file_location('physical_spans_original_driver', DRIVER)
t = importlib.util.module_from_spec(spec)
spec.loader.exec_module(t)
t.W = W

SOURCES = {
    'resources': 'src/graph/resources.cc',
    'executable': 'src/graph/executable.cc',
    'configuration-test': 'tests/graph/configuration_input_test.cc',
    'cuda-test': 'tests/graph/slots_cuda_execution_test.cc',
}
SDK_UNITS = ('resources', 'executable')
TEST_UNITS = ('configuration-test', 'cuda-test')
SNAPSHOT_ROOTS = (EXECUTABLE / 'source', COHORT / 'source')


def prior_units():
    resources = t.read(COHORT / 'compile/resources/compiled.json')
    executable = t.read(EXECUTABLE / 'compile/executable/compiled.json')
    test = t.read(COHORT / 'compile/slots-test/compiled.json')
    return {'resources': resources, 'executable': executable,
            'configuration-test': test, 'cuda-test': test}


def dependencies(receipt):
    return receipt.get('dependencies', receipt.get('compiler_dependencies'))


def canonical_argument(arg):
    for root in SNAPSHOT_ROOTS:
        arg = arg.replace(str(root), str(R))
    return arg


def retained_region_test():
    path = EXECUTABLE / 'compile/region-test2/compiled.json'
    receipt = t.read(path)
    assert receipt['process']['exit'] == 0
    t.exact(receipt['object']); t.exact(receipt['actual_dependencies'])
    source = t.pin(R / 'tests/graph/region_provider_test.cc')
    assert (source['bytes'], source['sha256']) == (receipt['source']['bytes'], receipt['source']['sha256'])
    project = {}
    for old in t.read(receipt['actual_dependencies']['path']):
        current_path = t.canonical(old['path'])
        if not t.project(current_path): continue
        current = t.pin(current_path)
        if (current['bytes'], current['sha256']) == (old['bytes'], old['sha256']):
            proof = dict(original=old, current=current, status='BYTE_IDENTICAL')
        else:
            assert t.key(current_path) == t.key(R / 'include/hyle/graph/detail/region_access.h')
            body = current_path.read_bytes()
            declaration = rb'  HYLE_GRAPH_API static Status release_read_projections\(Invocation&,\r?\n      std::span<const ValueId>\) noexcept;\r?\n'
            matches = list(re.finditer(declaration, body))
            assert len(matches) == 1
            match = matches[0]
            removed = body[match.start():match.end()]
            before = body[:match.start()] + body[match.end():]
            assert len(removed) == 111
            assert (len(before), hashlib.sha256(before).hexdigest()) == (old['bytes'], old['sha256'])
            proof = dict(original=old, current=current, status='ADDED_STATIC_METHOD_DECLARATION_ONLY',
                removed_bytes=len(removed), added_declaration=removed.decode('utf-8'),
                mechanically_reconstructed_old_sha256=hashlib.sha256(before).hexdigest(),
                object_layout_vtable_data_members_changed=False)
        project[t.key(current_path)] = proof
    assert len(project) == 92
    assert sum(row['status'] != 'BYTE_IDENTICAL' for row in project.values()) == 1
    t.save(W / 'retained-region-test-proof.json', dict(receipt=t.pin(path), source=source,
        actual_dependencies=receipt['actual_dependencies'], project_dependencies=list(project.values()),
        scope='92 original project dependencies: 91 identical; one add-only static method declaration, no layout change. No test source/CXX refresh.'))
    return dict(object=receipt['object'], source=source, receipt=t.pin(path),
        command=receipt['command'], dependencies=dependencies(receipt),
        proof=t.pin(W / 'retained-region-test-proof.json'))


def prepare():
    ready_path = BASE / 'ready-tiny.json'
    ready = t.read(ready_path)
    t.exact(ready['inputs'])
    rows = t.read(ready['inputs']['path'])
    assert len(rows) == 228
    priors = prior_units()
    old = {name: priors[name]['object'] for name in SDK_UNITS}
    old['tiny'] = ready['compiled']['object']
    for row in old.values():
        assert sum(t.key(p['path']) == t.key(row['path']) for p in rows) == 1, row['path']
    # The old image is deliberately not required: its original 44MB consumer
    # object and all retained inputs, not the removed EXE, are the baseline.
    st = Path(old['tiny']['path']).stat()
    assert st.st_size == old['tiny']['bytes']
    units = {}
    for name, source in SOURCES.items():
        prior = priors[name]
        deps = dependencies(prior)
        t.exact(prior['command']); t.exact(deps)
        before = t.command(prior['command']['path'])
        original_source = t.read(deps['path'])['Data']['Source']
        args = []
        for i, arg in enumerate(before):
            if t.key(arg) == t.key(original_source):
                arg = str(R / source)
            elif i and before[i - 1].lower() == '/sourcedependencies':
                arg = str(W / f'compile/{name}/dependencies.json')
            elif arg.lower().startswith('/fo'):
                arg = '/Fo' + str(W / f'compile/{name}/unit.obj')
            elif arg.lower().startswith('/fd'):
                arg = '/Fd' + str(W / f'compile/{name}/unit.pdb')
            else:
                arg = canonical_argument(arg)
            args.append(arg)
        assert all(flag in args for flag in ('/MD', '/O2', '/WX', '/c'))
        assert sum(t.key(a) == t.key(R / source) for a in args) == 1
        t.save(W / f'recipes/{name}.json', dict(command=args, timeout_seconds=300))
        units[name] = dict(source=source, original_command=prior['command'],
            original_dependencies=deps, recipe=t.pin(W / f'recipes/{name}.json'))

    # Root selected this actual same-source GraphRegions object. Do not reuse
    # the different-source slots_execution object merely because it exists.
    retained_test = retained_region_test()
    gtest = [t.pin(R / f'.scratch/build-compute-v2-dev/lib/{name}.lib')
             for name in ('gtest_main', 'gtest')]
    for consumer in ('tiny', 'gtest'):
        mapping = {t.key(old[name]['path']): [str(W / f'compile/{name}/unit.obj')]
                   for name in SDK_UNITS}
        if consumer == 'gtest':
            mapping[t.key(old['tiny']['path'])] = [str(W / f'compile/{name}/unit.obj') for name in TEST_UNITS]
        args = []
        for arg in t.command(ready['recipe']['path']):
            replacement = mapping.get(t.key(arg))
            if replacement is not None:
                args.extend(replacement)
                continue
            for prefix, suffix in (('/OUT:', '.exe'), ('/PDB:', '.pdb'), ('/IMPLIB:', '.lib'), ('/MAP:', '.map')):
                if arg.upper().startswith(prefix):
                    arg = prefix + str((W / 'bin' / consumer).with_suffix(suffix))
                    break
            args.append(arg)
        if consumer == 'gtest':
            args.append(retained_test['object']['path'])
            args.extend(row['path'] for row in gtest)
        for replacements in mapping.values():
            for path in replacements:
                assert sum(t.key(a) == t.key(path) for a in args) == 1
        t.save(W / f'link-recipes/{consumer}.json', dict(command=args, timeout_seconds=240))
    excluded = {t.key(old[name]['path']) for name in SDK_UNITS}
    retained = [row for row in rows if t.key(row['path']) not in excluded]
    extras = [*gtest, retained_test['object']]
    stats = []
    for row in [*retained, *extras]:
        st = Path(row['path']).stat()
        assert st.st_size == row['bytes']
        stats.append(dict(path=row['path'], bytes=st.st_size, mtime_ns=st.st_mtime_ns,
                          retained_sha256=row['sha256']))
    t.save(W / 'retained-input-stats.json', stats)
    env = t.read(BASE / 'environment.json')
    env['PATH'] = str(W / 'bin') + ';' + env['PATH']
    t.save(W / 'environment.json', env)
    t.save(W / 'runtime.json', dict(PATH=env['PATH'], native=t.read(ready['runtime']['path'])['native']))
    t.save(W / 'final-build-plan.json', dict(baseline=t.pin(ready_path), inputs=ready['inputs'],
        original_objects=old, units=units, retained_tiny=ready['compiled'],
        retained_tiny_source_freeze=ready['source_freeze'], retained_region_test=retained_test, gtest=gtest,
        original_driver=t.pin(DRIVER), retained_stats=t.pin(W / 'retained-input-stats.json'),
        environment=t.pin(W / 'environment.json'), runtime=t.pin(W / 'runtime.json'),
        links={name: t.pin(W / f'link-recipes/{name}.json') for name in ('tiny', 'gtest')},
        counts=dict(CXX=4, SDK_CXX=2, test_CXX=2, Model_CXX=0, links=2, NVCC=0,
            tiny_inputs=228, gtest_inputs=232, downloads=0),
        scope='Only resources.cc/executable.cc SDK objects change. Tiny reuses the retained current include-main object. Two canonical GTest TUs plus same-source cached region-test2; its single static-declaration ABI difference is mechanically proved. Different-source slots_execution OBJ is excluded. No native work started.'))
    print('PREPARED 4CXX/2links; Tiny228; GTest232 inputs')


def plan():
    value = t.read(W / 'final-build-plan.json')
    for key in ('baseline', 'inputs', 'original_driver', 'retained_stats', 'environment', 'runtime'):
        t.exact(value[key])
    for unit in value['units'].values():
        for key in ('original_command', 'original_dependencies', 'recipe'):
            t.exact(unit[key])
    for row in value['links'].values(): t.exact(row)
    retained = value['retained_region_test']
    t.exact(retained['receipt']); t.exact(retained['proof'])
    for row in t.read(retained['proof']['path'])['project_dependencies']: t.exact(row['current'])
    return value


def freeze():
    value = plan()
    expected_path = W / 'expected-sources.json'
    expected = t.read(expected_path) if expected_path.exists() else {
        relative: t.pin(R / relative)['sha256'] for relative in SOURCES.values()}
    for relative, sha in expected.items(): assert t.pin(R / relative)['sha256'] == sha, relative
    if not expected_path.exists(): t.save(expected_path, expected)
    paths, roots = {}, [R / 'include', R]
    for unit in value['units'].values():
        for path in t.dep_paths(unit['original_dependencies']['path']):
            path = t.canonical(path)
            if t.project(path): paths[t.key(path)] = path
        roots.extend(Path(arg[2:]) for arg in t.command(unit['recipe']['path'])
                     if arg.lower().startswith('/i'))
    pending = [R / relative for relative in dict.fromkeys([*SOURCES.values(), *expected])]
    seen = set()
    while pending:
        path = pending.pop().resolve()
        if t.key(path) in seen: continue
        seen.add(t.key(path)); paths[t.key(path)] = path
        for kind, name in re.findall(r'^\s*#\s*include\s*([<"])([^>"\r\n]+)[>"]',
                                     path.read_text(encoding='utf-8-sig'), re.M):
            target = next((candidate.resolve() for root in ([path.parent] if kind == '"' else []) + roots
                           if (candidate := root / name).is_file()), None)
            if target is not None and t.project(target): pending.append(target)
    t.save(W / 'frozen-project-dependencies.json', [t.pin(path) for path in paths.values()])
    snapshots = []
    for relative in expected:
        target = W / 'source' / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        with target.open('xb') as out: out.write((R / relative).read_bytes())
        snapshots.append(dict(original=t.pin(R / relative), snapshot=t.pin(target)))
    t.save(W / 'final-source-freeze.json', dict(helper=t.pin(__file__), expected=t.pin(expected_path),
        dependencies=t.pin(W / 'frozen-project-dependencies.json'), snapshots=snapshots))
    print('SOURCE FROZEN', len(paths), 'project dependency paths; no CXX/native process')


def validate():
    value = plan()
    frozen = t.read(W / 'final-source-freeze.json')
    for key in ('helper', 'expected', 'dependencies'): t.exact(frozen[key])
    for row in t.read(frozen['dependencies']['path']): t.exact(row)
    for row in frozen['snapshots']: t.exact(row['original']); t.exact(row['snapshot'])
    return value, frozen


def parse_compile(name):
    value, frozen = validate()
    assert name in SOURCES
    out = W / 'compile' / name
    process = t.read(W / f'logs/{name}/process.json')
    assert process['exit'] == 0 and not process['timed_out']
    allowed = {t.key(row['path']): row for row in t.read(frozen['dependencies']['path'])}
    actual = []
    for path in dict.fromkeys(t.dep_paths(out / 'dependencies.json')):
        if t.project(path):
            assert t.key(path) in allowed, ('Successful CXX: repair dependency parser only; never recompile', str(path))
            t.exact(allowed[t.key(path)])
        actual.append(t.pin(path))
    t.save(out / 'actual-dependencies.json', actual)
    t.save(out / 'compiled.json', dict(source=t.pin(R / SOURCES[name]), object=t.pin(out / 'unit.obj'),
        process=process, command=t.pin(W / f'logs/{name}/command.json'),
        dependencies=t.pin(out / 'dependencies.json'), actual_dependencies=t.pin(out / 'actual-dependencies.json')))
    print('CXX metadata PASS', name)


def compile_unit(name):
    value, _ = validate()
    assert name in SOURCES
    (W / 'compile' / name).mkdir(parents=True, exist_ok=False)
    t.execute(t.command(value['units'][name]['recipe']['path']), W / 'logs' / name, 300)
    parse_compile(name)


def link_unit(name):
    value, _ = validate()
    assert name in ('tiny', 'gtest')
    required = SDK_UNITS if name == 'tiny' else (*SDK_UNITS, *TEST_UNITS)
    compiled = {unit: t.read(W / f'compile/{unit}/compiled.json') for unit in required}
    for receipt in compiled.values(): t.exact(receipt['object'])
    for row in t.read(value['retained_stats']['path']):
        st = Path(row['path']).stat()
        assert (st.st_size, st.st_mtime_ns) == (row['bytes'], row['mtime_ns']), row['path']
    t.exact(value['retained_tiny']['object'])
    region_test = value['retained_region_test']
    if name == 'gtest':
        t.exact(region_test['object']); t.exact(region_test['source'])
    replacements = {t.key(value['original_objects'][unit]['path']): compiled[unit]['object'] for unit in SDK_UNITS}
    rows = []
    for row in t.read(value['inputs']['path']):
        if name == 'gtest' and t.key(row['path']) == t.key(value['original_objects']['tiny']['path']):
            rows.extend(compiled[unit]['object'] for unit in TEST_UNITS)
        else:
            rows.append(replacements.get(t.key(row['path']), row))
    if name == 'gtest':
        rows.append(region_test['object'])
        rows.extend(value['gtest'])
    assert len(rows) == value['counts'][name + '_inputs']
    t.save(W / f'inputs-{name}.json', rows)
    (W / 'bin').mkdir(exist_ok=True)
    native = t.read(value['runtime']['path'])['native']
    alias = W / 'bin' / Path(native['path']).name
    if not alias.exists(): alias.hardlink_to(native['path'])
    assert alias.samefile(native['path'])
    process = t.execute(t.command(value['links'][name]['path']), W / 'links' / name, 240)
    t.save(W / f'ready-{name}.json', dict(image=t.pin(W / f'bin/{name}.exe'),
        inputs=t.pin(W / f'inputs-{name}.json'), compiled=compiled,
        retained_tiny=value['retained_tiny'] if name == 'tiny' else None,
        retained_region_test=region_test if name == 'gtest' else None,
        process=process, recipe=t.pin(W / f'links/{name}/command.json'),
        runtime=value['runtime'], source_freeze=t.pin(W / 'final-source-freeze.json')))
    print('LINK PASS', name, len(rows), 'inputs')


if __name__ == '__main__':
    action = sys.argv[1]
    if action == 'prepare': prepare()
    elif action == 'freeze': freeze()
    elif action == 'preflight': validate()
    elif action == 'compile': compile_unit(sys.argv[2])
    elif action == 'parse-compile': parse_compile(sys.argv[2])
    elif action == 'link': link_unit(sys.argv[2])
    else: raise ValueError(action)
