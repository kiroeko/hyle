from pathlib import Path
import difflib, hashlib, importlib.util, json, os, shutil, sys
sys.dont_write_bytecode = True
R=Path.cwd(); W=R/'.scratch/inference-prefix-admission-20261025'
spec=importlib.util.spec_from_file_location('b',R/'.scratch/mtp-extraction-regression-20261024/check.py')
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
S=W/'source';B=W/'before'; A=W/'attempt1'
shutil.copyfile(W/'component.cc',S/'component.cc')
changed=['engine/inference/request_progress.h','engine/models/qwen35/main.cc']
patch=''.join(''.join(difflib.unified_diff((B/n).read_text().splitlines(True), (S/n).read_text().splitlines(True),
    fromfile='a/'+n,tofile='b/'+n))for n in changed)
(W/'source.patch').write_text(patch,encoding='utf-8',newline='\n')
b.save(W/'after-pins.json',[b.pin(S/n)for n in changed])
b.save(W/'execution-plan.json',dict(scope='one actual CPU untrained ordinary full-prefix admission/refusal/retry/control process',
    source_files=[b.pin(p)for p in S.rglob('*')if p.is_file()],GPU=False,HTTP=False,SDK_builds=0,
    mathematical_changes=False,expected_real_resource_refusals=1,
    failure_scope='prefix admission publication; original begin_turn/input_turn/timing not rolled back',
    unknown_native_failure='not triggered; original retirement gates remain authoritative'))
original=b.args(R/'.scratch/mtp-q27-fp8-20261024/engine-cpu-current1/compile-command.json')
cmd=[original[0],'/I'+str(S)]; skip=False
for word in original[1:]:
    if skip:skip=False;continue
    if word=='/sourceDependencies':skip=True;continue
    low=word.lower().replace('\\','/')
    if low.startswith(('/fo','/fd'))or low.endswith(('.cc','.cpp')):continue
    if low.startswith(('/i','-i'))and'/.scratch/'in low and low.endswith('/source'):continue
    cmd.append(word)
cmd+=['/sourceDependencies',str(A/'compile/dependencies.json'),str(S/'component.cc'),
      '/Fo'+str(A/'compile/unit.obj'),'/Fd'+str(A/'compile/unit.pdb')]
env=b.environment(original[0]);b.execute(cmd,A/'compile',env,150)
dependencies=b.read(A/'compile/dependencies.json')['Data']['Includes']
leaks=[str(p)for p in map(Path,dependencies)if p.resolve().is_relative_to(R/'engine')]
assert not leaks,leaks
b.save(A/'compile/source-pins.json',[b.pin(Path(p))for p in dependencies if Path(p).resolve().is_relative_to(R)])

base=b.args(R/'.scratch/mtp-q27-fp8-20261024/engine-cpu-current2/link-command.json')
core=R/'.scratch/inference-cache-shared-source-20261025/attempt1'
replacements={
 str(R/'.scratch/engine-product-20261024/cpu-budget-fix1/budget/budget.obj'):str(core/'budget/unit.obj'),
 str(R/'.scratch/engine-product-20261024/cpu-budget-fix1/leases/leases.obj'):str(core/'leases/unit.obj'),
 str(R/'.scratch/glm-quark-selected-20261024/Q30/graph-integration-preparation/host1/compute_batch--paged_arena.obj'):str(core/'arena/unit.obj'),
 str(R/'.scratch/mtp-q27-fp8-20261024/engine-cpu-current1/main.obj'):str(A/'compile/unit.obj')}
normalized={k.lower().replace('\\','/'):v for k,v in replacements.items()}
link=[base[0]];seen={k:0 for k in normalized};removed=[]
for word in base[1:]:
    low=word.lower().replace('\\','/')
    if low.startswith(('/out:','/map:','/pdb:','/implib:')):continue
    if low.endswith('/engine/main.cc.obj'):
        removed.append(word);continue
    if low in normalized:
        seen[low]+=1;word=normalized[low]
    link.append(word)
assert all(n==1 for n in seen.values()),seen
assert len(removed)==1,removed
report=R/'.scratch/mtp-performance-convergence-20261025/current-cuda/report/unit.obj'
assert b.pin(R/'engine/reporting/execution_report.cc')['sha256']=='069a735b7e1f760d27bf427cddb63aba8850972caaa52790435be428049843ce'
link.append(str(report))
for word in link[1:]:
    p=Path(word)
    if p.is_absolute()and p.suffix.lower()in{'.obj','.lib'}:assert p.is_file(),str(p)
b.save(A/'closure-delta.json',dict(template=b.pin(R/'.scratch/mtp-q27-fp8-20261024/engine-cpu-current2/link-command.json'),
    replacements=[dict(before=k,after=b.pin(Path(v)))for k,v in replacements.items()],
    removed_original_entry=removed,additional_report=b.pin(report),SDK_rebuilds=0,core_rebuilds=0))
link+=['/OUT:'+str(A/'link/component.exe'),'/PDB:'+str(A/'link/component.pdb'),'/IMPLIB:'+str(A/'link/component.lib')]
b.execute(link,A/'link',env,90)
runtime=b.read(R/'.scratch/mtp-q27-fp8-20261024/engine-cpu-current2/runtime-environment.json')
env['PATH']=str(A/'link')+';'+runtime['PATH']
native=R/'.scratch/mtp-q27-fp8-20261024/engine-cpu-current2/bin/hyle_ggml_cpu_pure_ffa4_current.dll'
os.link(native,A/'link'/native.name)
fixture=R/'.scratch/mtp-runtime-backend-20261024/verification1/tiny-run/fixture/weights.tsv'
b.save(A/'pre-run-pins.json',dict(image=b.pin(A/'link/component.exe'),native=b.pin(native),
    fixture=b.pin(fixture),fixture_body=b.pin(fixture.parent/'untrained-bf16.bin'),
    source=[b.pin(p)for p in S.rglob('*')if p.is_file()],
    closure=[b.pin(Path(p))for p in link[1:]if Path(p).is_absolute()and Path(p).suffix.lower()in{'.obj','.lib'}]))
b.execute([str(A/'link/component.exe'),str(fixture)],A/'run',env,60)
print((A/'run/stdout.log').read_text(encoding='utf8'))
