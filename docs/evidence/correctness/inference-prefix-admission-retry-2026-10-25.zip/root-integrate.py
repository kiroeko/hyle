from pathlib import Path
import hashlib
import json

root = Path(__file__).resolve().parents[2]
batch = Path(__file__).resolve().parent
out = batch / 'root-integration.json'
assert not out.exists()
read = lambda p: json.loads(p.read_bytes())

def pin(path):
    data = path.read_bytes()
    return {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}

before, after = read(batch / 'before-pins.json'), read(batch / 'after-pins.json')
assert len(after) == 2
for row in before:
    assert pin(Path(row['path'])) == {k: row[k] for k in ('bytes', 'sha256')}
for row in after:
    private = Path(row['path'])
    assert private.is_relative_to(batch / 'source')
    assert pin(private) == {k: row[k] for k in ('bytes', 'sha256')}

attempt = batch / 'attempt3'
for phase in ('compile', 'link', 'run'):
    process = read(attempt / phase / 'process.json')
    assert process['exit'] == 0 and not process['timeout']
compiled = {row['path'].lower(): row for row in read(attempt / 'compile/source-pins.json')}
for row in after:
    assert compiled[row['path'].lower()] == row
actual = read(attempt / 'run/stdout.log')
assert actual['status'] == 'PASS' and actual['ordinary'] and actual['backend'] == 'cpu'
assert actual['same_request_retry'] and actual['fresh_direct_control'] and actual['single_new_draw']
assert actual['real_resource_refusals'] == 1 and actual['frontier_graph_calls'] == 2
assert not actual['prefix_history_adopted_after_refusal'] and actual['final_versions'] == 0
assert not actual['GPU'] and not actual['HTTP']
stderr = (attempt / 'run/stderr.log').read_text(encoding='utf-8')
assert 'expected_real_resource_refusal=graph invocation allocation failed' in stderr
assert 'Status::ResourceExhausted("graph invocation allocation failed")' in (
    root / 'src/graph/executable.cc').read_text(encoding='utf-8')

integrated = []
for row in after:
    private = Path(row['path'])
    target = root / private.relative_to(batch / 'source')
    target.write_bytes(private.read_bytes())
    assert pin(target) == {k: row[k] for k in ('bytes', 'sha256')}
    integrated.append({'path': str(target.relative_to(root)).replace('\\', '/'), **pin(target)})
out.write_bytes((json.dumps({
    'status': 'INTEGRATED_AFTER_FINITE_CPU_JOURNEY', 'sources': integrated,
    'actual': actual, 'actual_process': read(attempt / 'run/process.json'),
    'real_error_source': 'src/graph/executable.cc:51 ResourceExhausted invocation metadata allocation',
    'scope': 'Prefix admission publication only; original turn start, timing and LRU preparation may advance.',
    'extra_build_or_process': False,
}, indent=2) + '\n').encode('utf-8'))
print('Integrated two checked sources; the same request retries after real resource refusal.')
