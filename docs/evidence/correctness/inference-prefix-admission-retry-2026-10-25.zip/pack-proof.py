from pathlib import Path
import hashlib, json, zipfile
R=Path.cwd();W=R/'.scratch/inference-prefix-admission-20261025'
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def pin(p):return dict(path=str(p.relative_to(R)).replace('\\','/'),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def save(p,x):p.write_text(json.dumps(x,indent=2)+'\n',encoding='utf-8')
cleanup=[]
for attempt in ['attempt1','attempt2']:
    for p in (W/attempt).rglob('*'):
        if p.is_file()and p.suffix.lower()in{'.obj','.exe','.lib','.exp','.dll','.pdb'}:cleanup.append(pin(p))
cleanup.sort(key=lambda x:x['path'])
save(W/'cleanup-candidates.json',dict(performed=False,files=cleanup,logical_bytes=sum(p['bytes']for p in cleanup),
    retained='attempt3 current ready app/entry/native hardlink; all shared Graph/resources/core/SDK objects; source/commands/raw/cache fixture'))
actual=read(W/'attempt3/run/stdout.log')
assert actual['status']=='PASS'and actual['output']==45 and actual['final_versions']==0
refusal='graph invocation allocation failed'
assert 'expected_real_resource_refusal='+refusal in (W/'attempt3/run/stderr.log').read_text()
summary=dict(
    status='PASS_ORDINARY_PREFIX_ADMISSION_RETRY_CANONICAL_INTEGRATED',date='2026-10-25',
    problem='Initial prefix hit imported history/observed cursor and input offset before fallible Session/frontier admission, making a resource-refused live request non-retryable.',
    change='Read-only history/record/progress preflight, local history/name/Session, bounded original-ledger population, then request publication. No second ledger, new executor, route, math or budget limit.',
    current_sources=read(W/'root-integration.json')['sources'],actual=actual,
    actual_process=read(W/'attempt3/run/process.json'),
    actual_work=dict(target_prefill_graphs=1,completed_frontier_graphs=2,refused_frontier_submissions=0,
        cold_same_model=True,fixture_original_publisher_weights=False,
        fixture='cached untrained A-only H64 FFN128 V64 BF16, ordinary Text selection (13 roles/98944 selected bytes); existing full fixture body includes unused NextN roles',
        source_fixture=read(W/'attempt3/pre-run-pins.json')['fixture'],
        source_body=read(W/'attempt3/pre-run-pins.json')['fixture_body']),
    refusal=dict(message=refusal,status_source='src/graph/executable.cc:51-52, invocation_allocation_failure returns ResourceExhausted',
        cause='The original shared requested-byte scope is exhausted by a normal Reservation; typed reserve(resource,1) also returns ResourceExhausted. The same prepared frontier succeeds without pressure and after reservation release.',
        allocation_path='Compiled graph resource_budget.metadata_allocator -> original plan/storage runtime allocator -> Executable::create_invocation allocation failure. No per-allocation call stack was instrumented.',
        current_source_anchors=['src/graph/executable.cc:8912-8914','src/graph/executable.cc:10187-10189','src/compute/resource_budget.cc:245-248'],
        compiled_graph_object=pin(R/'.scratch/graph-system-constant-lease-20261024/executable/executable.obj'),
        compiled_graph_source_identity='closure/graph-executable-identity.json (retained older Graph source hash; current anchors are source-level explanation, not a claim that this old object was rebuilt)',
        current_explanatory_source=pin(R/'src/graph/executable.cc')),
    assertions=[
        'After refusal: no Session/history, no imported ledger records/count/sampling binding, no progress history adoption/output, no consumed-prefix offset/hit counters/frontier call.',
        'Original begin_turn may legitimately mark the turn started; retry then uses the same already started request. Input validation marker, timing and cache LRU are not rolled back.',
        'After releasing only the unrelated Reservation: same request full hit succeeds, canonical state shared, one fresh stream draw/output, imported history observed once.',
        'Retry and direct same-stream control match emitted IDs, full GenerationBoundary, pending/cursor, ledger.same_result, history length/chunk count and observed cursor.',
        'Old producer Snapshot/boundary/pending/cursor, actual carry-hidden byte digest, KV ready-reader validity/page counts unchanged. This does not claim every KV backing byte was independently read.',
        'Evicting the directory alias preserves original escaped ready readers. Explicit stop/drain/try_retire releases all request state; final version count 0.'
    ],
    attempts=[
        dict(name='attempt1',consumer_compile=read(W/'attempt1/compile/process.json'),link=read(W/'attempt1/link/process.json'),runtime='NOT_STARTED',
            failure='Historical CPU closure lacked the already implemented two-scope GraphOutput::storage_lease. Fixed by reusing the canonical-matching retained resources object; no product change.'),
        dict(name='attempt2',link=read(W/'attempt2/link/process.json'),runtime=read(W/'attempt2/run/process.json'),
            failure='Private consumer wrongly required the caught error string to contain budget/quota before printing it. Original caught text was not captured in this attempt and remains unknown; this failure is not retroactively labeled a numerical/state pass.'),
        dict(name='attempt3',consumer_compile=read(W/'attempt3/compile/process.json'),link=read(W/'attempt3/link/process.json'),runtime=read(W/'attempt3/run/process.json'),
            correction='Print actual refusal before checks; separately assert typed public reserve(1) ResourceExhausted. All state, output/control, cursor and retirement gates retained.',result='PASS')],
    totals=dict(actual_consumer_processes=2,strict_consumer_TU_compiles=2,links=3,SDK_builds=0,core_builds=0,GPU_processes=0,HTTP=0),
    integration=read(W/'root-integration.json'),
    limits=[
        'Common ordinary/MTP source correction; this new runtime check covers ordinary pure CPU only, not a new MTP or native GPU matrix.',
        'The original defect was established by source order; no old-binary negative-control model run was added.',
        'Only prefix admission publication is made retry safe. No promise of whole-function rollback for begin_turn/input markers/timing/LRU.',
        'Pre-submit requested-byte refusal is covered. Unknown or accepted native work still requires the existing actual-retirement gate; no gate is reset for retry.',
        'Cached untrained tiny fixture, not full artifact/model quality, server, tokenizer, physical-memory cap or performance evidence.'],
    cleanup=read(W/'cleanup-candidates.json'))
save(W/'summary.json',summary)
entries={}
def add(p,name=None):
    if not p.is_file():raise FileNotFoundError(p)
    name=name or p.relative_to(W).as_posix()
    assert name not in entries,name
    entries[name]=p
for directory in [W/'before',W/'source']:
    for p in directory.rglob('*'):
        if p.is_file():add(p)
for name in ['prepare.py','check.py','relink2.py','recheck3.py','pack-proof.py','first-run-component.cc','component.cc',
             'before-pins.json','after-pins.json','source.patch','execution-plan.json','summary.json','cleanup-candidates.json',
             'root-integrate.py','root-integration.json']:
    add(W/name)
for attempt in ['attempt1','attempt2','attempt3']:
    for p in (W/attempt).rglob('*'):
        if p.is_file()and p.suffix.lower()in{'.json','.log'}:add(p)
for name in ['ordinary-session-state-review.md','request-admission-publication-review.md']:
    add(R/'.scratch/inference-system-review-20261025'/name,'reviews/'+name)
add(R/'.scratch/graph-system-constant-lease-20261024/executable/identity.json','closure/graph-executable-identity.json')
add(R/'.scratch/inference-native-retention-scopes-20261025/attempt1/resources/repository-inputs.json','closure/graph-resources-inputs.json')
for unit in ['budget','leases','arena']:
    for name in ['command.json','repository-inputs.json','process.json']:
        add(R/'.scratch/inference-cache-shared-source-20261025/attempt1'/unit/name,'closure/cache-core/'+unit+'/'+name)
archive=W/'proof.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9)as z:
    for name,p in sorted(entries.items()):z.write(p,name)
with zipfile.ZipFile(archive)as z:
    assert z.testzip()is None
    assert len(z.namelist())==len(set(z.namelist()))
outer=dict(summary,archive={**pin(archive), 'entries':len(entries),'crc_verified':True,
                           'excludes':'No OBJ/EXE/LIB/EXP/DLL/SDK or fixture weight bodies; actual source/dependency pins identify retained inputs.'})
save(W/'proof-summary.json',outer)
print(json.dumps(dict(proof=pin(archive),entries=len(entries),cleanup_files=len(cleanup),cleanup_logical_bytes=sum(p['bytes']for p in cleanup))))
