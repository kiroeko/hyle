# Ordinary session/prefix state review — 2026-10-25

Read-only source review; no build, test, GPU, HTTP or product edits. Scope: shared SessionCache/PrefixDirectory/VersionAdmission, Qwen immutable state, natural ordinary request admission/restore/retirement and fixed replay consumer. This is not certification of every model/backend or all error paths.

## Highest-value concrete omission: failed prefix admission partially commits host history

- `engine/models/qwen35/main.cc:5405–5436`: after an initial prefix hit, the function writes `reused_tokens`, hit counts, `history`, imported ledger records/count, `progress.adopt_committed_history`, and `turn_input_consumed` **before** the fallible `model.create_session` / full-hit random frontier completes.
- `main.cc:3553–3574`: full-hit sampling creates a real Invocation and submits the original frontier; resource/native rejection is possible before any new request Session is returned. A partial hit can instead fail actual cold suffix admission (`main.cc:3081–3122`, `3624`).
- `main.cc:5071–5094`: import rejects any already nonempty ledger and incrementally marks original records committed. `engine/inference/request_progress.h:164–166` separately allows history adoption only once.

Minimal sequence: publish a complete ordinary random prefix; create a fresh request with that exact prompt, its cold empty ledger and own stream; temporarily exhaust its actual execution/shared requested-byte budget with a normal `ResourceBudget::Reservation`; call `prepare_generation_call`. It imports history, then frontier Invocation admission rejects. `request.session` stays null while ledger/progress/input offset are already changed. Release the unrelated reservation and retry the **same** request: the repeated import rejects its nonempty ledger. The finite CLI currently exits at the first exception, hiding this live-owner retry hole. No wrong-token, premature native retirement or buffer overwrite is claimed.

## Minimum correction (proposal only)

1. Preflight the original empty ledger, every destination record's uncommitted state, `prefix.chunks` versus history/record extents and valid replay ranges. Factor the existing progress history-adoption checks into a const preflight reused by adoption, including private `history_adopted_`; do not infer it solely from observed count.
2. Keep copied history, reused/full-hit/suffix facts, hit counters and adopted Session local. Complete `create_session`, frontier execution and local pending/cursor/history adjustments before publishing any of them into the request. Early sampling identity work can validate rather than bind the ledger.
3. Commit to original reserved records without a second ledger: their shared_ptr/span/scalar writes do not allocate; `emitted` is `SmallVector<int32_t,2>` and always receives two values (inline capacity 2). With all slot/extent checks done, use indexed slots rather than throwing `ledger.next()`. Publish committed flags/count, immutable sampling binding and progress adoption, then session/history/consumed/counters in a bounded no-allocation tail. No rollback protocol or new state owner is needed.

One necessary finite check: one cached tiny CPU ordinary random full hit. Hold a normal reservation to force the first real frontier Invocation resource rejection, assert request ledger/progress/consumed/session and original cached Snapshot/pending/cursor unchanged, release reservation and retry the same request successfully. Assert one fresh stream draw/output and no duplicate history import; the old producer reader stays unchanged. This check has **not** been run in this review.

## Existing contracts confirmed by the inspected source

- `session_state.h:242–269`: canonical Snapshot retains ColdResources, which outlives VersionRef/PageRef; sampling wrappers keep the canonical origin alive and share one actual evaluated version. `main.cc:3580–3584` math identity is a ColdResources-owned family-table address, so an escaped prefix cannot accidentally match a newly address-reused Model's resource generation.
- `prefix_cache.h:124–161` and `prefix_directory.h:175–202,233–284`: exact token/domain lookup, actual complete boundary, authenticated rebuild history, typed immutable payload, Hit pin/move lifetime and no eviction of pinned payloads. Directory eviction drops its alias; it does not pretend the backing necessarily freed.
- `main.cc:6036–6053` distinguishes same-request recovery (original last pending/cursor) from new-request full hit (`3651–3668`, new frontier/stream). Cross-policy batching uses immutable PreparedSampling identity; ledger carries a weak ColdResources identity (`1194–1200`).
- `main.cc:6030–6033,5718–5723` retires idle Session payloads through stop + actual try_retire before dropping them. Fixed replay `6764–6776` supplies the same actual-owner proof to SessionCache. `session_cache.h:120–143` leaves withdrawn unproven owners invisible and charged; `request_window.h:139–145` cannot release Active/Queued/Paused identities.
- `main.cc:5174–5188,5503–5520` rechecks live version facts after each directory eviction. `version_admission.h` is a synchronous owner-facts query, not a retirement proof; its callsites explicitly constrain their complete owner inventory.
- Cancellation preserves unpublished candidates/old heads until original episode retirement (`main.cc:3912–3952,4942–4964`); this review did not rerun native cancellation or claim hardware completion timing.

## Source pins / boundary

Main SHA256 `6e690bc368e4e5c6747cf0c030c7252561efd2b9fc02e8ce4a1869489db726e6`.
PrefixDirectory `5161c250059bf9a02dffbcdfcfba2b1c4292d11f741d3decf59568644fae1e9c`; Qwen PrefixCache `5031a6c6a407f4b197d73b9befebc1c3db38c6e06dbdf4e32091f1c319a7b1de`; SessionCache `e72420340efb5bb0a9e449f54ace38e6d89ed467928fa4155ec72c68ce7b6200`.
No additional definite defect was found in this finite pass. Provider/page-core internals, every native error branch, unrelated selected-family loaders, full artifact execution and performance were not re-audited. Native dual retention-scope work was intentionally excluded.
