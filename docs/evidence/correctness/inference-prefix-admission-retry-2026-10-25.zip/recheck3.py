from pathlib import Path
import importlib.util,os,shutil,sys
sys.dont_write_bytecode=True
R=Path.cwd();W=R/'.scratch/inference-prefix-admission-20261025';A=W/'attempt3';S=W/'source'
spec=importlib.util.spec_from_file_location('b',R/'.scratch/mtp-extraction-regression-20261024/check.py')
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
shutil.copyfile(W/'component.cc',S/'component.cc')
original=b.args(W/'attempt1/compile/command.json');command=[];skip=False
for arg in original:
    if skip:skip=False;continue
    if arg=='/sourceDependencies':skip=True;continue
    if arg.lower().startswith(('/fo','/fd')):continue
    command.append(arg)
command+=['/sourceDependencies',str(A/'compile/dependencies.json'),'/Fo'+str(A/'compile/unit.obj'),'/Fd'+str(A/'compile/unit.pdb')]
env=b.environment(original[0]);b.execute(command,A/'compile',env,150)
b.save(A/'compile/source-pins.json',[b.pin(p)for p in S.rglob('*')if p.is_file()])
base=b.args(W/'attempt2/link/command.json');link=[];found=0
for arg in base:
    if arg.lower().startswith(('/out:','/pdb:','/implib:')):continue
    if arg==str(W/'attempt1/compile/unit.obj'):arg=str(A/'compile/unit.obj');found+=1
    link.append(arg)
assert found==1
link+=['/OUT:'+str(A/'link/component.exe'),'/PDB:'+str(A/'link/component.pdb'),'/IMPLIB:'+str(A/'link/component.lib')]
b.execute(link,A/'link',env,90)
native=R/'.scratch/mtp-q27-fp8-20261024/engine-cpu-current2/bin/hyle_ggml_cpu_pure_ffa4_current.dll'
os.link(native,A/'link'/native.name)
env['PATH']=str(A/'link')+';'+b.read(R/'.scratch/mtp-q27-fp8-20261024/engine-cpu-current2/runtime-environment.json')['PATH']
fixture=R/'.scratch/mtp-runtime-backend-20261024/verification1/tiny-run/fixture/weights.tsv'
b.save(A/'pre-run-pins.json',dict(image=b.pin(A/'link/component.exe'),native=b.pin(native),fixture=b.pin(fixture),
    fixture_body=b.pin(fixture.parent/'untrained-bf16.bin'),source=[b.pin(p)for p in S.rglob('*')if p.is_file()],
    closure=[b.pin(Path(p))for p in link[1:]if Path(p).is_absolute()and Path(p).suffix.lower()in{'.obj','.lib'}],
    consumer_delta='Print original refusal before classification; assert public reserve(1) ResourceExhausted; state/numerical retry gates unchanged',
    first_actual_source=b.pin(W/'first-run-component.cc')))
b.execute([str(A/'link/component.exe'),str(fixture)],A/'run',env,60)
print((A/'run/stdout.log').read_text(encoding='utf8'))
