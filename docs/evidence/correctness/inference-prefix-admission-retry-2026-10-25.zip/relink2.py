from pathlib import Path
import importlib.util,os,sys
sys.dont_write_bytecode=True
R=Path.cwd();W=R/'.scratch/inference-prefix-admission-20261025';A=W/'attempt2'
spec=importlib.util.spec_from_file_location('b',R/'.scratch/mtp-extraction-regression-20261024/check.py')
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
old=R/'.scratch/glm-quark-selected-20261024/Q30/graph-integration-preparation/host1/graph--resources.obj'
new=R/'.scratch/inference-native-retention-scopes-20261025/attempt1/resources/unit.obj'
records=b.read(new.parent/'repository-inputs.json')
source=next(p for p in records if p['path'].lower().endswith('src\\graph\\resources.cc'))
assert source['sha256']==b.pin(R/'src/graph/resources.cc')['sha256']
command=b.args(W/'attempt1/link/command.json');found=0;link=[]
for arg in command:
    if arg.lower().startswith(('/out:','/pdb:','/implib:')):continue
    if arg.lower()==str(old).lower():arg=str(new);found+=1
    link.append(arg)
assert found==1
link+=['/OUT:'+str(A/'link/component.exe'),'/PDB:'+str(A/'link/component.pdb'),'/IMPLIB:'+str(A/'link/component.lib')]
env=b.environment(link[0]);b.execute(link,A/'link',env,90)
native=R/'.scratch/mtp-q27-fp8-20261024/engine-cpu-current2/bin/hyle_ggml_cpu_pure_ffa4_current.dll'
os.link(native,A/'link'/native.name)
runtime=b.read(R/'.scratch/mtp-q27-fp8-20261024/engine-cpu-current2/runtime-environment.json')
env['PATH']=str(A/'link')+';'+runtime['PATH']
fixture=R/'.scratch/mtp-runtime-backend-20261024/verification1/tiny-run/fixture/weights.tsv'
b.save(A/'closure-correction.json',dict(first_failure='LNK2019 absent latest two-scope GraphOutput::storage_lease in old cached resources leaf',
    source=source,actual_source=b.pin(R/'src/graph/resources.cc'),old_object=str(old),new_object=b.pin(new),
    unchanged_entry=b.pin(W/'attempt1/compile/unit.obj'),no_recompile=True,SDK_builds=0,
    library_delta=[dict(before=str(old),after=b.pin(new))]))
b.save(A/'pre-run-pins.json',dict(image=b.pin(A/'link/component.exe'),native=b.pin(native),
    fixture=b.pin(fixture),fixture_body=b.pin(fixture.parent/'untrained-bf16.bin'),
    source=[b.pin(p)for p in (W/'source').rglob('*')if p.is_file()],
    closure=[b.pin(Path(p))for p in link[1:]if Path(p).is_absolute()and Path(p).suffix.lower()in{'.obj','.lib'}]))
b.execute([str(A/'link/component.exe'),str(fixture)],A/'run',env,60)
print((A/'run/stdout.log').read_text(encoding='utf8'))
