from pathlib import Path
import hashlib, json, shutil, difflib

R = Path.cwd()
W = R / '.scratch/inference-prefix-admission-20261025'
B = W / 'before'
S = W / 'source'
def pin(p):
    return dict(path=str(p), bytes=p.stat().st_size, sha256=hashlib.sha256(p.read_bytes()).hexdigest())
files = [R/'engine/models/qwen35/main.cc', *(R/'engine/models/qwen35').glob('*.h'),
         *(R/'engine/inference').glob('*.h'), R/'engine/reporting/execution_report.h',
         R/'engine/reporting/execution_report.cc']
assert not B.exists() and not S.exists()
for p in files:
    for destination in (B, S):
        q = destination / p.relative_to(R)
        q.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(p, q)
(W/'before-pins.json').write_text(json.dumps([pin(p) for p in files], indent=2)+'\n')

p = S/'engine/inference/request_progress.h'
t = p.read_text(encoding='utf-8')
old = '''  void adopt_committed_history(std::size_t count) {
    if (history_adopted_ || observed_commits_ || !generated.empty() || turn_index || prefilled || turn_done)
      throw std::logic_error("request can adopt committed history only before its first output");
    observed_commits_ = count; history_adopted_ = true;
  }'''
new = '''  void preflight_adopt_committed_history() const {
    if (history_adopted_ || observed_commits_ || !generated.empty() || turn_index || prefilled || turn_done)
      throw std::logic_error("request can adopt committed history only before its first output");
  }
  void adopt_committed_history(std::size_t count) {
    preflight_adopt_committed_history();
    observed_commits_ = count; history_adopted_ = true;
  }'''
assert t.count(old) == 1
p.write_text(t.replace(old,new), encoding='utf-8', newline='\n')

p = S/'engine/models/qwen35/main.cc'
t = p.read_text(encoding='utf-8')
old = '''void import_generation_prompt_ledger(GenerationLedger &ledger, const cache::ReplayPrefix &prefix,
                              bool full_hit, bool draft_cache) {
  if (ledger.committed_count || !prefix.history || prefix.chunks > ledger.records.size())
    throw std::runtime_error("MTP initial prompt import requires an empty bounded ledger");
  std::int32_t previous = -1;
  for (std::size_t i = 0; i < prefix.chunks; ++i) {
    const auto &part = prefix.history->chunks[i];
    auto &record = ledger.next();'''
new = '''void preflight_generation_prompt_ledger(const GenerationLedger &ledger, const cache::ReplayPrefix &prefix) {
  if (ledger.committed_count || !prefix.history || !prefix.chunks ||
      prefix.chunks > prefix.history->chunks.size() || prefix.chunks > ledger.records.size())
    throw std::runtime_error("MTP initial prompt import requires an empty bounded ledger");
  std::size_t covered = 0;
  for (std::size_t i = 0; i < prefix.chunks; ++i) {
    const auto &part = prefix.history->chunks[i];
    if (ledger.records[i].committed || ledger.records[i].emitted.capacity() < 2 ||
        !part.input || !part.count || part.first != covered || part.first > part.input->ids.size() ||
        part.count > part.input->ids.size() - part.first || covered > prefix.length ||
        part.count > prefix.length - covered || (part.state_only ? part.next_id != -1 : part.next_id < 0))
      throw std::runtime_error("prompt import requires complete original ranges and uncommitted reserved records");
    covered += part.count;
  }
  if (covered != prefix.length)
    throw std::runtime_error("prompt import history does not cover its complete boundary");
}

void import_generation_prompt_ledger(GenerationLedger &ledger, const cache::ReplayPrefix &prefix,
                              bool full_hit, bool draft_cache) {
  preflight_generation_prompt_ledger(ledger, prefix);
  std::int32_t previous = -1;
  for (std::size_t i = 0; i < prefix.chunks; ++i) {
    const auto &part = prefix.history->chunks[i];
    auto &record = ledger.records[i];'''
assert t.count(old)==1
t=t.replace(old,new)
old='''    record.imported = true; record.committed = true; ++ledger.committed_count;
    record.requests = 0; // Role-only source history does not claim original batch geometry.
    previous = part.next_id;
  }
}'''
new='''    record.imported = true;
    record.requests = 0; // Role-only source history does not claim original batch geometry.
    previous = part.next_id;
  }
  // All ranges/capacities were checked before population. shared_ptr/span and
  // scalar writes, including the two inline emitted IDs, allocate nothing.
  for (std::size_t i = 0; i < prefix.chunks; ++i) ledger.records[i].committed = true;
  ledger.committed_count = prefix.chunks;
}'''
assert t.count(old)==1
t=t.replace(old,new)
old='''    if (request.ledger) request.ledger->bind_sampling(prepared_sampling, model.resources_);
    std::cerr << "memory_phase=" << request.memory_name << "_prefill_begin\\n";'''
new='''    if (request.ledger) request.ledger->validate_sampling(prepared_sampling, model.resources_);
    std::cerr << "memory_phase=" << request.memory_name << "_prefill_begin\\n";'''
assert t.count(old)==1
t=t.replace(old,new)
start=t.index('        request.reused_tokens = hit.payload.snapshot->length; request.prefix_hits = 1;',t.index('PreparedGenerationCall prepare_generation_call'))
end=t.index('        hit.reset();',start)
oldblock=t[start:end]
newblock='''        const auto reused_tokens = hit.payload.snapshot->length;
        const bool full_hit = reused_tokens == request.prompt.size();
        auto history = cache::copy_history(hit.payload.replay, model.capacity);
        if (request.ledger) {
          preflight_generation_prompt_ledger(*request.ledger, hit.payload.replay);
          request.progress.preflight_adopt_committed_history();
        }
        const auto suffix = request.prompt.size() - reused_tokens;
        const auto suffix_rows = (std::min)(suffix, max_prefill_rows);
        const auto suffix_completion = suffix > suffix_rows ? TextCompletion::kStateOnly : TextCompletion::kEmitNext;
        std::string hit_name = "prefill";
        if (suffix > suffix_rows) hit_name += "_chunk" + std::to_string(reused_tokens);
        const std::array chunks{suffix_rows};
        const auto prior_sampling_seconds = model.frontier_sampling_seconds;
        const auto suffix_role = !model.cache_plan.draft_cache ? GraphRole::kText : (suffix == 1 || request.prompt.size() == 1)
            ? (cached_lag ? GraphRole::kMtpCatchupSingle : GraphRole::kMtpSingle)
            : (cached_lag ? GraphRole::kMtpCatchupPrefill : GraphRole::kMtpPrefill);
        // Keep every new request fact local until the actual Session/frontier
        // succeeds. Failed native/resource admission must permit the same retry.
        const auto admission_role = !model.cache_plan.draft_cache ? GraphRole::kText
            : suffix ? suffix_role : request.prompt.size() == 1 ? GraphRole::kMtpSingle : GraphRole::kMtpPrefill;
        auto adopted = model.create_session(suffix ? std::span<const std::size_t>(chunks) : std::span<const std::size_t>{},
            hit.payload.snapshot, admission_role,
            request.progress.initial_sampling, suffix == 0, suffix_completion, request.sampling_index);
        if (!suffix) history->chunks.back().next_id = adopted->head->next_id;
        // Only original reserved metadata remains. Preconditions are unchanged
        // since preflight; no allocation or native work follows this commit.
        if (request.ledger) {
          import_generation_prompt_ledger(*request.ledger, hit.payload.replay, full_hit, model.cache_plan.draft_cache);
          if (sampler.enabled || model.sampling_configuration_count() > 1) {
            for (std::size_t i = 0; i < request.ledger->committed_count; ++i) {
              auto &record = request.ledger->records[i];
              record.before.sampling = sampler.enabled ? request.progress.initial_sampling : cache::SamplingCursor{};
              record.after.sampling = record.before.sampling;
              record.emitted_count = 0; record.emitted = {-1, -1};
            }
            request.ledger->records[request.ledger->committed_count - 1].after.sampling = adopted->head->sampling;
          }
          if (!suffix) {
            auto &last = request.ledger->records[request.ledger->committed_count - 1];
            last.after.sampling = adopted->head->sampling;
            last.after.next_id = adopted->head->next_id;
            last.target_first = last.after.next_id; last.emitted = {last.after.next_id, -1};
            last.emitted_count = 1; last.stopped = is_end_of_generation(last.after.next_id);
          }
          request.ledger->bind_sampling(prepared_sampling, model.resources_);
          request.progress.adopt_committed_history(request.ledger->committed_count);
        }
        request.history = std::move(history);
        request.session = std::move(adopted);
        request.reused_tokens = reused_tokens; request.prefix_hits = 1;
        request.prefix_full_hits = full_hit ? 1 : 0;
        request.turn_input_consumed = reused_tokens;
        call.name = std::move(hit_name);
        if (sampler.enabled || model.sampling_configuration_count() > 1) {
          request.prefix_sampling_calls = suffix == 0 ? 1 : 0;
          request.prefix_sampling_seconds = model.frontier_sampling_seconds - prior_sampling_seconds;
        }
'''
t=t[:start]+newblock+t[end:]
old='''    if (!request.turn_observations.empty() &&
        call.input_begin == (request.progress.turn_index ? 0 : request.reused_tokens))'''
new='''    if (request.ledger && !request.ledger->sampling) request.ledger->bind_sampling(prepared_sampling, model.resources_);
    if (!request.turn_observations.empty() &&
        call.input_begin == (request.progress.turn_index ? 0 : request.reused_tokens))'''
assert t.count(old)==1
t=t.replace(old,new)
old='''    call.name = request.progress.turn_index ? "round" + std::to_string(request.progress.turn_index + 1) + "_prefill" : "prefill";
    if (!call.prefill_complete || call.input_begin > request.reused_tokens)
      call.name += "_chunk" + std::to_string(call.input_begin);'''
new='''    if (call.name.empty()) {
      call.name = request.progress.turn_index ? "round" + std::to_string(request.progress.turn_index + 1) + "_prefill" : "prefill";
      if (!call.prefill_complete || call.input_begin > request.reused_tokens)
        call.name += "_chunk" + std::to_string(call.input_begin);
    }'''
assert t.count(old)==1
t=t.replace(old,new)
p.write_text(t,encoding='utf-8',newline='\n')

changed=['engine/inference/request_progress.h','engine/models/qwen35/main.cc']
patch=''
for name in changed:
    patch+=''.join(difflib.unified_diff((B/name).read_text().splitlines(True),
        (S/name).read_text().splitlines(True),fromfile='a/'+name,tofile='b/'+name))
(W/'source.patch').write_text(patch,encoding='utf-8',newline='\n')
(W/'after-pins.json').write_text(json.dumps([pin(S/name)for name in changed],indent=2)+'\n')
print(json.dumps(dict(frozen_files=len(files), changed=changed,patch_bytes=len(patch.encode()))))
