#include "engine/models/qwen35/main.cc"

namespace q = qwen35;
namespace i = hyle::inference;
namespace {
void require(bool value, const char *message) {
  if (!value) throw std::runtime_error(message);
}
std::uint64_t hidden_digest(q::Model &model, const q::cache::Snapshot &head) {
  const auto view = q::take(head.carry_hidden.view());
  std::vector<std::byte> bytes(view.size());
  q::check(model.execution.read(view, bytes));
  std::uint64_t hash = 1469598103934665603ULL;
  for (auto value : bytes) { hash ^= std::to_integer<std::uint8_t>(value); hash *= 1099511628211ULL; }
  return hash;
}
void retire(q::GenerationRequest &request) {
  q::check(request.session->stop()); q::check(request.session->drain());
  require(q::take(request.session->try_retire()), "ordinary payload did not really retire");
  request.session.reset();
}
}

int main(int argc, char **argv) {
  try {
    if (argc != 2) throw std::runtime_error("prefix-admission PRIVATE_CACHED_FIXTURE_MANIFEST");
    const std::filesystem::path manifest(argv[1]);
    const auto shape = q::read_weight_geometry(manifest);
    require(shape.hidden == 64 && shape.intermediate == 128 && shape.vocabulary == 64 && shape.layers == "A",
        "expected the original finite untrained cached A fixture");
    const auto plan = q::cache::plan(shape, 16, 4, 2,
        q::recurrent_bytes(q::state_schema_for(shape, 16), shape), 1, 1, false, true);
    auto execution = q::create_execution(shape, plan, 0, {.primary = i::BackendKind::kCpu});
    const auto resource = execution.device();
    const std::array resources{resource};
    const std::array limits{q::c::ResourceBudgetLimit{resource, 64u << 20}};
    auto budget = q::take(q::c::ResourceBudget::create(
        {.limits = limits, .allow_unattributed = true}, resources, 64u << 20));
    q::Model model(std::move(execution), budget, q::prepare_weight_source(manifest, false),
        shape, 16, plan, {}, false, q::ReplayPolicy::kCommands, 16u << 20,
        {.enabled = true, .policy = {1.F, 8, .9F}, .seed = 123}, 0);
    require(model.execution.host_only() && !model.cache_plan.draft_cache && !model.physical_mtp_roles,
        "ordinary pure CPU only");
    const std::array rows{std::size_t{2}};
    model.prepare_family(rows); model.plan_replay_uses(2, 1, 4); model.prepare_execution(rows);
    auto input = std::make_shared<std::vector<std::int32_t>>(std::initializer_list<std::int32_t>{1, 2});
    const auto make_request = [&](std::string name, std::uint64_t stream) {
      q::GenerationRequest request(std::move(name), *input, {}, 1);
      request.warm_inputs.push_back(input);
      request.ledger = std::make_unique<q::GenerationLedger>(1, 1);
      request.progress.initial_sampling = {123, stream, 0};
      request.input = q::cache::token_plan(*input, 16);
      return request;
    };
    auto producer = make_request("producer", 0);
    std::array produced{q::prepare_generation_call(model, producer, 1, nullptr, {})};
    q::execute_generation_calls(model, produced, false);
    require(producer.progress.generated.size() == 1 && producer.ledger->committed_count == 1 &&
        producer.session->head->sampling == q::cache::SamplingCursor{123, 0, 1}, "producer did not commit its actual ordinary prefix");
    q::cache::PrefixCache prefix(4);
    q::publish_generation_completed(model, producer, &prefix);
    require(prefix.size() == 1, "original complete producer boundary was not cached");
    auto original = producer.session->head;
    const auto original_boundary = q::generation_boundary(*original);
    const auto original_digest = hidden_digest(model, *original);
    const auto keys = original->keys[0].page_count(), values = original->values[0].page_count();
    require(original->keys[0].valid() && original->values[0].valid() && keys && values,
        "producer has no original ready KV readers");

    // Same stream/control: a fresh full hit succeeds without any prior refusal.
    auto control = make_request("direct-control", 77);
    std::array direct{q::prepare_generation_call(model, control, 1, &prefix, {})};
    require(direct[0].full_hit && control.session->head->state_identity() == original.get(), "control is not a real complete state hit");
    q::execute_generation_calls(model, direct, false, &prefix);
    const auto control_pending = control.session->head->next_id;
    const auto control_cursor = control.session->head->sampling;
    const auto control_boundary = q::generation_boundary(*control.session->head);
    const auto control_commits = control.ledger->committed_count;
    const auto before_frontier = model.frontier_sampling_graph_calls;

    auto request = make_request("refused-then-retry", 77);
    require(!request.progress.turn_started() && !request.session && !request.ledger->sampling,
        "fresh request was already admitted");
    const auto before_versions = model.snapshot_versions.live;
    const auto before_usage = *budget.shared_usage();
    require(before_usage.limit_bytes > before_usage.live_bytes, "fixture has no real unused requested-byte capacity");
    auto reservation = q::take(budget.reserve(resource, before_usage.limit_bytes - before_usage.live_bytes));
    require(budget.shared_usage()->live_bytes == before_usage.limit_bytes, "real budget reservation did not exhaust admission");
    const auto denied = budget.reserve(resource, 1);
    require(!denied && denied.error().IsResourceExhausted(), "actual exhausted scope did not return typed ResourceExhausted");
    std::string failure;
    try { (void)q::prepare_generation_call(model, request, 1, &prefix, {}); }
    catch (const std::runtime_error &error) { failure = error.what(); }
    require(!failure.empty(), "expected a real frontier admission resource refusal");
    std::cerr << "expected_real_resource_refusal=" << failure << '\n';
    require(request.progress.turn_started() && !request.progress.prefilled && !request.progress.turn_done &&
        request.progress.generated.empty() && request.progress.observed_commits() == 0 && request.turn_input_consumed == 0 &&
        !request.session && !request.history && !request.reused_tokens && !request.prefix_hits && !request.prefix_full_hits &&
        !request.ledger->sampling && request.ledger->sampling_owner.expired() && !request.ledger->committed_count &&
        !request.ledger->records[0].committed && !request.prefix_sampling_calls && !request.prefix_sampling_seconds,
        "failed prefix resource admission published request history/session/progress/counters");
    require(model.frontier_sampling_graph_calls == before_frontier && !model.active_step && !model.carrier_borrowed &&
        model.snapshot_versions.live == before_versions, "refused frontier submitted work or retained a new state version");
    require(producer.session->head == original && q::generation_boundary(*original) == original_boundary &&
        hidden_digest(model, *original) == original_digest && original->keys[0].valid() && original->values[0].valid() &&
        original->keys[0].page_count() == keys && original->values[0].page_count() == values,
        "refused new request mutated an old immutable producer reader");
    reservation.reset();
    require(budget.shared_usage()->live_bytes == before_usage.live_bytes,
        "failed frontier or original reservation leaked requested bytes");
    // This is the same logical request and its already begun turn, no reset.
    std::array retried{q::prepare_generation_call(model, request, 1, &prefix, {})};
    require(retried[0].full_hit && request.session->head->state_identity() == original.get(), "same-request retry did not reuse the original complete state");
    q::execute_generation_calls(model, retried, false, &prefix);
    require(request.progress.generated == control.progress.generated &&
        request.session->head->next_id == control_pending && request.session->head->sampling == control_cursor &&
        q::generation_boundary(*request.session->head) == control_boundary && request.ledger->committed_count == control_commits &&
        request.ledger->records[0].same_result(control.ledger->records[0]) &&
        request.history->length == control.history->length && request.history->chunks.size() == control.history->chunks.size() &&
        request.turn_input_consumed == input->size() && request.progress.observed_commits() == control.progress.observed_commits() &&
        request.progress.observed_commits() == 1 && request.progress.generated.size() == 1 && request.progress.turn_done &&
        request.session->head->sampling == q::cache::SamplingCursor{123, 77, 1},
        "retry differs from the direct request or duplicates history/RNG/output");
    require(model.frontier_sampling_graph_calls == before_frontier + 1 &&
        q::generation_boundary(*original) == original_boundary && hidden_digest(model, *original) == original_digest,
        "retry changed the producer or sampled more than once");
    require(prefix.evict_one() && !prefix.size() && original->keys[0].valid() && original->values[0].valid(),
        "directory alias retirement invalidated an original external reader");
    const auto output = request.progress.generated[0];
    produced = {}; direct = {}; retried = {};
    retire(producer); retire(control); retire(request); original.reset();
    require(!model.active_step && !model.carrier_borrowed && model.snapshot_versions.live == 0,
        "finite ordinary journey retained native admission or versions");
    std::cout << "{\"status\":\"PASS\",\"ordinary\":true,\"backend\":\"cpu\",\"fixture\":\"cached_untrained_A_H64_FFN128_V64\","
        "\"real_resource_refusals\":1,\"frontier_graph_calls\":" << model.frontier_sampling_graph_calls
        << ",\"fresh_direct_control\":true,\"same_request_retry\":true,\"turn_started_after_refusal\":true,"
        "\"prefix_history_adopted_after_refusal\":false,\"single_new_draw\":true,\"output\":" << output
        << ",\"old_hidden_digest\":" << original_digest << ",\"final_versions\":0,\"GPU\":false,\"HTTP\":false}\n";
    return 0;
  } catch (const std::exception &error) {
    std::cerr << "prefix_admission_failure=" << error.what() << '\n'; return 1;
  }
}
