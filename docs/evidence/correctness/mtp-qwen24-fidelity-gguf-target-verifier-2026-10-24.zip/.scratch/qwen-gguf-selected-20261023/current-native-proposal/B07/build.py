from pathlib import Path
import hashlib,importlib.util,sys
sys.dont_write_bytecode=True
COMMON=Path(__file__).resolve().parents[1]/'build_current.py'
COMMON_SHA='59f66fc38ceecdc1b9b54a2535da32c16bbaed5b4419cd19827e4558b4320e0f'
if hashlib.sha256(COMMON.read_bytes()).hexdigest()!=COMMON_SHA:raise ValueError('Frozen GGUF current helper changed')
spec=importlib.util.spec_from_file_location('_b07_own_current_build',COMMON)
common=importlib.util.module_from_spec(spec);spec.loader.exec_module(common)
if __name__=='__main__':sys.exit(common.main('B07',Path(__file__)))
