"""Offline B07 actual GGUF headers -> static33 / six-bank metadata plans.

Missing headers fail before any output. No tensor body or pins are invented.
"""
import argparse
import hashlib
import importlib.util
import json
from pathlib import Path
import sys

sys.dont_write_bytecode = True
S = next(p for p in Path(__file__).resolve().parents if (p / 'metadata-proposal/fetch_headers.py').is_file())
R = S.parents[2]
REPO, REV = 'unsloth/Qwen3.8-2.4T-A95B-GGUF', '567d3e6ac26c5474b18311e619c04350fb9a5556'
COUNT, BODY = 33, 5497491456
DOMAIN, PLANE_BYTES, EXPERT_BYTES = 512, 17825792, 53477376
SECTIONS, LEGS = ('nextn', 'target91'), ('gate', 'up', 'down')


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def identity(path):
    path = Path(path)
    raw = path.read_bytes()
    return dict(path=path.relative_to(R).as_posix(), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


def schema():
    fetch = module('_b07_actual_headers', S / 'metadata-proposal/fetch_headers.py')
    rows = fetch.expected()  # frozen census + actual scanner/parser identities
    census = read(fetch.CENSUS)['qwen38_24t_q8_0']['tensors']
    return fetch, rows, census


def checked_header(fetch, expected, shard):
    directory = S / 'headers' / f'shard{shard:02d}'
    path = directory / 'receipt.json'
    if not path.is_file():
        raise FileNotFoundError(f'B07 actual shard{shard:02d} header is absent; run only its approved metadata batch first: {path}')
    receipt = read(path)
    assert receipt['complete'] is True and receipt['http_status'] == 206
    assert (receipt['repository'], receipt['revision'], receipt['file'], receipt['url']) == (
        fetch.REPO, fetch.REV, fetch.file(shard), f'https://huggingface.co/{fetch.REPO}/resolve/{fetch.REV}/{fetch.file(shard)}')
    assert receipt['tensor_payload_bytes'] == 0 and receipt['whole_shard_downloaded'] is False
    assert receipt['census'] == identity(fetch.CENSUS)
    assert receipt['header'] == identity(directory / 'header.bin')
    assert receipt['physical_table'] == identity(directory / 'physical-table.json')
    raw = (directory / 'header.bin').read_bytes()
    assert len(raw) == receipt['data_base'] <= fetch.LIMIT
    table = read(directory / 'physical-table.json')
    assert receipt['tensor_count'] == len(expected[shard]) == len(table['tensors'])
    actual = fetch.validate(raw, table['metadata'], table['tensors'], receipt['metadata_count'],
        receipt['whole_file_bytes'], receipt['etag'], expected[shard])
    assert table['physical'] == actual
    item = {key: receipt[key] for key in ('file', 'url', 'data_base', 'whole_file_bytes', 'etag', 'header')}
    item.update(original_shard=shard, header_receipt=identity(path))
    return item, {row['name']: row for row in actual}


def plan(kind):
    assert kind in ('static', 'experts')
    fetch, expected, census = schema()
    wanted = [row for row in census if
        (row['name'].startswith(('blk.91.', 'blk.92.')) or row['name'] in ('token_embd.weight', 'output.weight', 'output_norm.weight'))
        and (('_exps.weight' in row['name']) == (kind == 'experts'))]
    shards = sorted({row['shard'] for row in wanted})
    assert shards == ([7, 51, 56] if kind == 'static' else [49, 50, 56])
    actual = [checked_header(fetch, expected, shard) for shard in shards]
    roles = []
    for selected in wanted:
        slot = shards.index(selected['shard'])
        shard, table = actual[slot]
        row = table[selected['name']]
        assert (row['shape'], row['dtype']) == (list(map(int, selected['shape'])), selected['dtype'])
        first = shard['data_base'] + row['offset']
        section = 'target91' if row['name'].startswith('blk.91.') or row['name'] == 'output_norm.weight' else 'nextn'
        item = dict(index=len(roles), name=row['name'], filename=row['name'] + '.bin',
            section=section, dtype=row['dtype'], dtype_code=row['dtype_code'], shape=row['shape'],
            bytes=row['bytes'], source_shard=slot,
            data_relative_half_open=[row['offset'], row['offset'] + row['bytes']],
            absolute_inclusive=[first, first + row['bytes'] - 1])
        if kind == 'experts':
            leg = next(leg for leg in LEGS if row['name'].endswith(f'.ffn_{leg}_exps.weight'))
            assert row['dtype'] == 'Q8_0' and row['shape'] == ([2048, 8192, DOMAIN] if leg == 'down' else [8192, 2048, DOMAIN])
            assert row['bytes'] == DOMAIN * PLANE_BYTES
            item.update(leg=leg, acquire_full_role=False, expert_stride=PLANE_BYTES)
        roles.append(item)
    assert len(roles) == (COUNT if kind == 'static' else 6)
    assert sum(row['bytes'] for row in roles) == (BODY if kind == 'static' else 6 * DOMAIN * PLANE_BYTES)
    assert len({row['name'] for row in roles}) == len(roles)
    if kind == 'static':
        assert sum(row['section'] == 'nextn' for row in roles) == 19
        assert sum(row['section'] == 'target91' for row in roles) == 14
    else:
        assert {(row['section'], row['leg']) for row in roles} == {(s, l) for s in SECTIONS for l in LEGS}
    return dict(repository=fetch.REPO, revision=fetch.REV, variant='Q8_0', file=fetch.file(1),
        original_roles=len(roles), source_bytes=sum(row['bytes'] for row in roles),
        shards=[value[0] for value in actual], roles=roles, census=identity(fetch.CENSUS),
        complete_absolute_ranges=True, metadata_only=True, tensor_payload_bytes=0,
        full_bank_download_allowed=False, whole_shards_downloaded=False, artifact_executed=False)


def checked_plan(kind='static'):
    path = S / ('loose-plan.json' if kind == 'static' else 'expert-source-plan.json')
    value = read(path)
    assert value == plan(kind), 'B07 plan differs from its current authenticated actual GGUF headers'
    return path, value


def save_immutable(path, value):
    text = json.dumps(value, ensure_ascii=False, indent=2) + '\n'
    if path.exists():
        assert path.read_text(encoding='utf-8-sig') == text, f'Refuse to replace a different actual source plan: {path}'
    else:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(text, encoding='utf-8')


def expert_templates():
    path, value = checked_plan('experts')
    result = {}
    for row in value['roles']:
        shard = value['shards'][row['source_shard']]
        result[(row['section'], row['leg'])] = dict(source_name=row['name'], source_file=shard['file'],
            source_header=shard['header'], url=shard['url'], etag=shard['etag'], whole_file_bytes=shard['whole_file_bytes'],
            tensor_relative_first=row['data_relative_half_open'][0], tensor_absolute_first=row['absolute_inclusive'][0],
            expert_stride=PLANE_BYTES, leg_offset=0, shape=row['shape'][:2])
    return result, identity(path)


def expert_plan(templates, plan_identity, section, global_id):
    assert section in SECTIONS and type(global_id) is int and 0 <= global_id < DOMAIN
    rows = []
    for leg in LEGS:
        source = templates[(section, leg)]
        first = source['tensor_absolute_first'] + global_id * PLANE_BYTES
        relative = source['tensor_relative_first'] + global_id * PLANE_BYTES
        assert first + PLANE_BYTES <= source['whole_file_bytes']
        rows.append(dict(source, name=f"{source['source_name']}#expert{global_id:03d}/{leg}",
            section=section, global_id=global_id, leg=leg, dtype='Q8_0', bytes=PLANE_BYTES,
            filename=f'expert-{global_id:03d}-{leg}.gguf-plane',
            data_relative_half_open=[relative, relative + PLANE_BYTES], absolute_inclusive=[first, first + PLANE_BYTES - 1]))
    return dict(repository=REPO, revision=REV, variant='Q8_0', section=section, stage=0,
        globals=[global_id], source_plan_sha256=plan_identity['sha256'], original_roles=3, source_bytes=EXPERT_BYTES,
        full_bank_download_allowed=False, whole_shards_downloaded=False, roles=rows)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--kind', choices=('static', 'experts', 'all'), default='static')
    args = parser.parse_args()
    kinds = ('static', 'experts') if args.kind == 'all' else (args.kind,)
    # Derive every requested value before publishing any new file.
    values = [(kind, plan(kind)) for kind in kinds]
    for kind, value in values:
        path = S / ('loose-plan.json' if kind == 'static' else 'expert-source-plan.json')
        save_immutable(path, value)
        print(json.dumps(dict(plan=identity(path), roles=value['original_roles'], logical_source_bytes=value['source_bytes'],
            tensor_payload_bytes=0, network_requests=0)))


if __name__ == '__main__':
    main()
