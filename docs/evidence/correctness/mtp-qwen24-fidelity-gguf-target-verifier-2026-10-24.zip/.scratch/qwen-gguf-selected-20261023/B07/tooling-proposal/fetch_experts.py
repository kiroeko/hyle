"""B07 actual IDs only; reuse B05 owned immutable per-ID acquisition protocol.

The existing acquisition loop is reused with one audited catalogue-version
literal substitution. Geometry/ranges come from actual GGUF headers, not BF16
fused-bank offsets. HTTP must run inside the existing budget runner.
"""
import ast
import hashlib
import importlib.util
from pathlib import Path
import sys

sys.dont_write_bytecode = True
S = next(p for p in Path(__file__).resolve().parents if (p / 'metadata-proposal/fetch_headers.py').is_file())
R = S.parents[2]
BASE = R / '.scratch/qwen-bfloat-selected-20261023/B05/fetch_experts.py'
BASE_SHA = '072ef65cd3afd0e4130616af134dfd7c5bfe252c4fd0a0c5dc5f9c06717b81ab'


def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    value = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(value)
    return value


def configured():
    raw = BASE.read_bytes()
    assert hashlib.sha256(raw).hexdigest() == BASE_SHA, 'Pinned original per-ID acquisition protocol changed'
    source = module('_b07_actual_selected_schema', Path(__file__).with_name('prepare_plans.py'))
    loose = module('_b07_actual_loose_configuration', Path(__file__).with_name('fetch_loose_roles.py'))
    base = module('_b07_original_per_id_acquisition', BASE)
    base.S, base.R, base.REPO, base.REV = S, R, source.REPO, source.REV
    base.DOMAIN, base.PLANE_BYTES, base.EXPERT_BYTES = source.DOMAIN, source.PLANE_BYTES, source.EXPERT_BYTES
    # Only this B07 module instance: at most8 actual-ID futures. Each ID's
    # original three planes remain serial, with one authenticated HTTP stream.
    base.WORKERS = 8
    base.helper = loose.configured
    base.checked_plan = lambda common: source.expert_templates()
    base.expert_plan = source.expert_plan
    request_args = base.request_args

    def bounded_request(args, common):
        if args.frontier_file is not None:
            assert 0 < args.frontier_file.stat().st_size <= 65536, 'B07 actual frontier exceeds its finite metadata bound'
        section, ids = request_args(args, common)
        assert 1 <= len(ids) <= 10, 'B07 may acquire only the bounded actual Top10 missing IDs'
        if args.frontier_file is not None:
            assert 1 <= len(common.read(args.frontier_file)['global_ids']) <= 10
        return section, ids
    base.request_args = bounded_request
    parsed = ast.parse(raw, filename=str(BASE))
    functions = [node for node in parsed.body if isinstance(node, ast.FunctionDef) and node.name == 'acquire_one']
    assert len(functions) == 1
    versions = [node for node in ast.walk(functions[0]) if isinstance(node, ast.Constant)
        and isinstance(node.value, str) and node.value == 'HYQBF001\t']
    assert len(versions) == 1
    versions[0].value = 'HYQGF001\t'  # Exact source consumer's packed-GGUF catalogue version.
    # No other statement, loop, HTTP reader, retry, publication or cleanup is changed.
    exec(compile(ast.Module(body=functions, type_ignores=[]), str(BASE), 'exec'), base.__dict__)
    return base, loose


if __name__ == '__main__':
    base, loose = configured()
    if not any(flag in sys.argv[1:] for flag in ('--plan-only', '--help', '-h')):
        loose.require_budget()
    base.main()
