"""One actual B07 frontier -> existing explicit budget batch; no HTTP here."""
import argparse
import importlib.util
import json
from pathlib import Path
import subprocess
import sys

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--frontier-file', type=Path, required=True)
    parser.add_argument('--plan-only', action='store_true')
    args = parser.parse_args()
    spec = importlib.util.spec_from_file_location('_b07_owned_frontier_source', HERE / 'fetch_experts.py')
    fetch = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(fetch)
    base, loose = fetch.configured()
    common = loose.configured()
    templates, pin = base.checked_plan(common)
    args.section = args.stage = args.ids = None
    section, ids = base.request_args(args, common)
    for global_id in ids:
        base.expert_plan(templates, pin, section, global_id)
    if args.plan_only:
        print(json.dumps(dict(section=section, stage=0, global_ids=ids, roles=3*len(ids),
            maximum_body_bytes=base.EXPERT_BYTES*len(ids), source_plan=pin, network_requests=0)))
        return 0
    prefix = section + '-experts-' + '-'.join(map(str, ids))
    number = 1
    while True:
        attempt = prefix + '-attempt' + str(number)
        batch = fetch.S / 'batch-plans' / (attempt + '.json')
        if not batch.exists() and not (fetch.S / 'batches' / attempt).exists():
            break
        number += 1
    subprocess.run([sys.executable, str(HERE / 'make_batch_plan.py'), '--kind', 'experts', '--attempt', attempt,
        '--frontier-file', str(args.frontier_file)], cwd=fetch.R, check=True)
    plan = common.read(batch)
    assert plan['source'] == common.identity(HERE / 'fetch_experts.py'), 'B07 source changed after the fixed batch was prepared'
    return subprocess.run([sys.executable, str(fetch.R / '.scratch/mtp-download-budget-20261023/run_batch.py'), str(batch)], cwd=fetch.R).returncode


if __name__ == '__main__':
    sys.exit(main())
