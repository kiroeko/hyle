"""B07 source configuration for the existing owned-process validation driver."""
import importlib.util
import json
import os
from pathlib import Path
import sys

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
S = next(p for p in Path(__file__).resolve().parents if (p / 'metadata-proposal/fetch_headers.py').is_file())
R = S.parents[2]


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    value = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(value)
    return value


def actual_static():
    generate = load('_b07_owned_actual_pins', HERE / 'generate_artifacts.py')
    schema = generate.schema()
    plan, pins, experts, facts = generate.checked_metadata(schema)
    path = S / 'generated/qwen_gguf_b07_artifacts.h'
    assert path.read_text(encoding='utf-8-sig') == generate.header(schema, plan, pins, experts, facts), 'B07 generated header differs from the actual completed acquisition'
    return dict(original_roles=33, source_bytes=schema.BODY, generated_header=schema.identity(path), network_requests=0)


def restore_pause():
    directory = R / '.scratch/mtp-download-budget-20261023'
    marker = directory / 'PAUSED'
    if marker.exists():
        return
    budget = load('_b07_restore_existing_budget', directory / 'budget.py')
    with budget.locked() as record:
        if not marker.exists():
            temporary = directory / 'PAUSED.b07-next'
            temporary.write_text(json.dumps(dict(paused_at=budget.now(), reason='B07 owned supply ended; no implicit prefetch.',
                reserved_request_bytes=record['reserved_request_bytes'], requests=len(record['requests'])))+'\n', encoding='utf-8')
            temporary.replace(marker)


def main():
    if sys.argv[1:] == ['--preflight']:
        print(json.dumps(actual_static()))
        return 0
    driver = load('_b07_existing_owned_driver', R / '.scratch/dspark-pro-target-draft-20261023/run_with_supply.py')
    if any(flag in sys.argv[1:] for flag in ('--help', '-h')):
        return driver.main()  # Read-only help must not touch another active batch's PAUSED marker.
    actual_static()
    assert hasattr(driver, 'FETCH_SCRIPT'), 'Current actual descendant-cleanup driver is required'
    driver.S, driver.R = S, R
    driver.DOMAIN, driver.SECTIONS = 512, ('nextn', 'target91')
    driver.FETCH_SCRIPT = HERE / 'supply_experts.py'
    driver.WAIT_ENV = 'HYLE_QWEN_GGUF_24_WAIT_FOR_EXPERTS'
    driver.FRONTIER_ENV = 'HYLE_QWEN_GGUF_24_EXPERT_REQUEST_FILE'
    for key, path in (('HYLE_QWEN24_FIDELITY_DIR', S / 'original-roles'), ('HYLE_QWEN_GGUF_24_EXPERT_DIR', S / 'original-experts')):
        assert key not in os.environ or Path(os.environ[key]).resolve() == path.resolve(), 'B07 actual cache location differs: ' + key
        os.environ[key] = str(path)
    try:
        return driver.main()
    finally:
        restore_pause()


if __name__ == '__main__':
    sys.exit(main())
