"""B07 C++ pins + physical expert contracts from actual complete receipts only.

Offline metadata reads/file stats only. No weight body rehash/copy or HTTP.
"""
import argparse
import importlib.util
import json
from pathlib import Path
import re
import sys

sys.dont_write_bytecode = True
S = next(p for p in Path(__file__).resolve().parents if (p / 'metadata-proposal/fetch_headers.py').is_file())
R = S.parents[2]


def schema():
    spec = importlib.util.spec_from_file_location('_b07_pins_actual_schema', Path(__file__).with_name('prepare_plans.py'))
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


def checked_metadata(s):
    plan_path, plan = s.checked_plan('static')
    expert_path, experts = s.checked_plan('experts')
    out = S / 'original-roles'
    receipt_path, manifest_path = out / 'acquisition.json', out / 'manifest.json'
    receipt, manifest = s.read(receipt_path), s.read(manifest_path)
    assert receipt['complete'] is True and manifest['complete'] is True
    for value in (receipt, manifest):
        assert (value['repository'], value['revision'], value['original_roles']) == (plan['repository'], plan['revision'], s.COUNT)
    assert receipt['whole_shard_downloaded'] is False
    assert receipt['source_plan_sha256'] == s.identity(plan_path)['sha256']
    assert receipt['expected_role_payload_bytes'] == receipt['role_payload_bytes'] == s.BODY
    assert receipt['successful_request_body_bytes'] == s.BODY
    assert manifest['source_bytes'] == s.BODY
    assert (manifest['file'], manifest['variant']) == (plan['file'], 'Q8_0')
    assert manifest['source_receipt'] == s.identity(receipt_path)
    assert manifest['source_plan'] == s.identity(plan_path)
    assert manifest['source_headers'] == [row['header_receipt'] for row in plan['shards']]
    wanted = {row['name']: row for row in plan['roles']}
    acquired = {row['name']: row for row in receipt['roles']}
    pinned = {row['name']: row for row in manifest['roles']}
    assert len(receipt['roles']) == len(manifest['roles']) == len(wanted) == len(acquired) == len(pinned) == s.COUNT
    assert wanted.keys() == acquired.keys() == pinned.keys()
    for name, row in wanted.items():
        actual, pin = acquired[name], pinned[name]
        assert actual['complete'] is True
        assert all(actual[key] == val for key, val in row.items())
        assert (pin['file'], pin['dtype'], pin['shape'], pin['bytes'], pin['section']) == (
            row['filename'], row['dtype'], row['shape'], row['bytes'], row['section'])
        digest = actual['payload']['sha256']
        assert re.fullmatch('[0-9a-f]{64}', digest) and pin['sha256'] == digest
        file = out / row['filename']
        assert file.name == row['filename'] and file.stat().st_size == row['bytes']
        assert actual['payload'] == dict(path=file.relative_to(R).as_posix(), bytes=row['bytes'], sha256=digest)
        shard = plan['shards'][row['source_shard']]
        assert (actual['url'], actual['etag'], actual['whole_file_bytes']) == (shard['url'], shard['etag'], shard['whole_file_bytes'])
        offset = 0
        for chunk in actual['chunks']:
            assert chunk['offset'] == offset and 0 < chunk['bytes'] <= 128*1024*1024
            assert re.fullmatch('[0-9a-f]{64}', chunk['sha256'])
            first = row['absolute_inclusive'][0] + offset
            assert chunk['absolute_range_inclusive'] == [first, first + chunk['bytes'] - 1]
            offset += chunk['bytes']
        assert offset == row['bytes']
    return plan, pinned, experts, dict(receipt=s.identity(receipt_path), manifest=s.identity(manifest_path),
        static_plan=s.identity(plan_path), expert_plan=s.identity(expert_path))


def quoted(value):
    return json.dumps(value, ensure_ascii=True)


def header(s, plan, pins, experts, facts):
    q = quoted
    lines = ['#pragma once', '', '#include "qwen_gguf_q24_artifacts.h"',
        '#include "d5_qwen_gguf_vocabulary_cases.h"', '',
        '// Actual completed original static33 pins; expert banks are metadata only.',
        'namespace qwen_gguf_q24_artifacts::b07 {',
        'namespace selected=qwen_gguf_selected_experts;',
        'inline constexpr auto &kIdentity=qwen_gguf_q24_artifacts::kIdentity;',
        '// The selected whole-model census/profile remains the frozen Q8_0 identity.',
        'inline constexpr auto &kProfile=d5_qwen_gguf_vocabulary_cases::k24TFidelityProfile;',
        'inline constexpr std::string_view kReceiptSha256='+q(facts['receipt']['sha256'])+';',
        'inline constexpr std::string_view kManifestSha256='+q(facts['manifest']['sha256'])+';',
        'inline constexpr std::string_view kPlanSha256='+q(facts['static_plan']['sha256'])+';',
        'inline constexpr std::string_view kExpertPlanSha256='+q(facts['expert_plan']['sha256'])+';',
        'inline std::array<named::ManifestSpec,kStaticRoles> manifest() {',
        '  return qwen_gguf_q24_artifacts::manifest(std::array<named::PinnedFile,kStaticRoles>{{']
    for row in plan['roles']:
        pin = pins[row['name']]
        lines.append('    {'+q(pin['file'])+','+q(pin['sha256'])+'},')
    lines += ['  }});', '}', 'inline selected::Contract expert_contract(selected::Section section) {',
        '  selected::Contract result;',
        '  result.repository=kIdentity.repository;result.revision=kIdentity.revision;result.variant=kIdentity.variant;',
        '  result.source_plan_sha256=kExpertPlanSha256;result.section=section;', '  switch(section) {']
    by_name = {(row['section'], row['leg']): row for row in experts['roles']}
    for section, enum in [('nextn', 'kNextn'), ('target91', 'kTarget91')]:
        lines += ['  case selected::Section::'+enum+':', '    result.banks={{']
        for leg in s.LEGS:
            row = by_name[(section, leg)]
            shard = experts['shards'][row['source_shard']]
            shape = row['shape']
            desc = 'original::detail::take(c::gguf_grouped_weight_description(c::GgufQuantizedType::kQ8_0,c::DataType::kFloat32,'+','.join(map(str, [shape[2], shape[1], shape[0]]))+'),"actual B07 original expert bank")'
            lines.append('      {'+q(row['name'])+','+q(shard['file'])+','+desc+','+str(row['absolute_inclusive'][0])+'ULL,'+str(shard['whole_file_bytes'])+'ULL},')
        lines += ['    }};break;']
    lines += ['  default:throw std::runtime_error("invalid B07 actual expert section");', '  }', '  return result;', '}',
        '} // namespace qwen_gguf_q24_artifacts::b07', '']
    return '\n'.join(lines)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, default=S / 'generated/qwen_gguf_b07_artifacts.h')
    args = parser.parse_args()
    s = schema()
    plan, pins, experts, facts = checked_metadata(s)  # Missing/partial fails before any output.
    text = header(s, plan, pins, experts, facts)
    output = args.output.resolve()
    assert output.is_relative_to(S) and output.suffix == '.h'
    output.parent.mkdir(parents=True, exist_ok=True)
    if output.exists():
        assert output.read_text(encoding='utf-8-sig') == text, 'Refuse to overwrite a different actual generated header'
    else:
        output.write_text(text, encoding='utf-8')
    proof = dict(repository=plan['repository'], revision=plan['revision'], variant='Q8_0', original_roles=s.COUNT,
        source_bytes=s.BODY, **facts, generated_header=s.identity(output), body_rehashed=False, artifact_executed=False,
        pins_from_completed_acquisition=True, whole_expert_banks_acquired=False)
    s.save_immutable(output.with_suffix('.json'), proof)
    print(json.dumps(proof))


if __name__ == '__main__':
    main()
