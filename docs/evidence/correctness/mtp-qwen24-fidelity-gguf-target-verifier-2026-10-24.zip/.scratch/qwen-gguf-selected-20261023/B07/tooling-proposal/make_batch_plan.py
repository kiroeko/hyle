"""Offline explicit B07 budget-batch plans; never executes a batch or HTTP.

Static requires real static metadata; experts require actual missing IDs or
an immutable actual frontier snapshot. No full expert bank/model mode exists.
"""
import argparse
import importlib.util
from pathlib import Path
import sys

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--kind', required=True, choices=('static', 'experts'))
    parser.add_argument('--attempt', required=True)
    parser.add_argument('--section', choices=('nextn', 'target91'))
    parser.add_argument('--ids', type=int, nargs='+')
    parser.add_argument('--frontier-file', type=Path)
    args = parser.parse_args()
    spec = importlib.util.spec_from_file_location('_b07_batch_actual_schema', HERE / 'prepare_plans.py')
    s = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(s)
    assert args.attempt and all(ch.isalnum() or ch in '-_' for ch in args.attempt)
    if args.kind == 'static':
        assert args.section is None and args.ids is None and args.frontier_file is None
        path, source = s.checked_plan('static')
        evidence, body, script, arguments = s.identity(path), s.BODY, HERE / 'fetch_loose_roles.py', []
    else:
        source = s.module('_b07_selected_actual_protocol', HERE / 'fetch_experts.py')
        base, common = source.configured()
        helper = common.configured()
        templates, pin = base.checked_plan(helper)
        args.stage = None
        section, ids = base.request_args(args, helper)
        plans = [s.expert_plan(templates, pin, section, global_id) for global_id in ids]
        if args.frontier_file:
            # Freeze the exact actual request; later file replacement cannot
            # silently expand a previously reviewed acquisition.
            evidence_path = s.S / 'frontier-plans' / ('request-' + args.attempt + '.json')
            s.save_immutable(evidence_path, helper.read(args.frontier_file))
            evidence = s.identity(evidence_path)
            arguments = ['--frontier-file', str(evidence_path)]
        else:
            evidence_path = s.S / 'frontier-plans' / ('ids-' + args.attempt + '.json')
            s.save_immutable(evidence_path, dict(source_plan=pin, per_id_plans=plans, actual_missing_ids_required=True))
            evidence = s.identity(evidence_path)
            arguments = ['--section', section, '--ids', *map(str, ids)]
        body, script = s.EXPERT_BYTES * len(ids), HERE / 'fetch_experts.py'
    plan = dict(script=script.relative_to(s.R).as_posix(), arguments=arguments,
        out=(s.S / 'batches' / args.attempt).relative_to(s.R).as_posix(), need_evidence=evidence,
        new_unique_body_bytes=body, new_unique_body_bytes_is_upper_bound=True,
        amount_note='Necessary original payload upper bound before authenticated cached-prefix reuse; actual transfer and retries are accounted by budget.py.',
        whole_bank=False, whole_model=False, metadata_only=False, maximum_request_bytes=8*1024*1024,
        transport='Exclusive hf-mirror.net guarded transport; any other redirect fails, no HF/CAS fallback.',
        timeout_seconds=7200 if args.kind == 'static' else 3600, source=s.identity(script),
        preparation_only=True)
    if args.kind == 'experts':
        plan.update(expert_workers=base.WORKERS, per_id_streams=1,
            maximum_live_stream_bytes=base.WORKERS * helper.IO,
            worker_policy='At most8 actual-ID futures; original three planes serial per ID. Walltime benefit is unmeasured.')
    output = s.S / 'batch-plans' / (args.attempt + '.json')
    assert not (s.R / plan['out']).exists(), 'Choose a new attempt output; authenticated body cache is reused independently'
    s.save_immutable(output, plan)
    print(__import__('json').dumps(dict(batch=s.identity(output), payload_upper_bound=body, network_requests=0)))


if __name__ == '__main__':
    main()
