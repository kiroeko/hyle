"""B07 static33 only; reuse B04/B02 authenticated Range/resume machinery.

Root executes HTTP exclusively through the existing explicit budget runner.
"""
import importlib.util
import hashlib
import json
from pathlib import Path
import sys
import urllib.request

sys.dont_write_bytecode = True
S = next(p for p in Path(__file__).resolve().parents if (p / 'metadata-proposal/fetch_headers.py').is_file())
R = S.parents[2]


def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


def configured():
    schema = module('_b07_actual_plan', Path(__file__).with_name('prepare_plans.py'))
    common_path = R / '.scratch/qwen-bfloat-selected-20261023/fetch_roles.py'
    capped_path = R / '.scratch/qwen-gguf-selected-20261023/offline/request-chunk/next-source/fetch_roles.py'
    assert hashlib.sha256(common_path.read_bytes()).hexdigest() == '1b34877ca22ab16eeaeb508e781dd84d0abf6555a73454b37f48e6d6a7e5cca3'
    assert hashlib.sha256(capped_path.read_bytes()).hexdigest() == '2fc0a5a81251b0a621940baac8f5b08ea3217f4ecc9ef121130b4a45548a2b29'
    common = module('_b07_existing_loose_acquisition', common_path)
    capped = module('_b07_existing_request_cap', capped_path)
    capped.R, capped.HELPER, capped.HELPER_SHA = common.R, common.HELPER, common.HELPER_SHA
    manifests = common.manifests
    common.ARTIFACT_DIR = S
    common.REPO, common.REV = schema.REPO, schema.REV
    common.COUNT, common.BODY = schema.COUNT, schema.BODY
    common.NEXTN_COUNT, common.TARGET_COUNT, common.TARGET_SECTION = 19, 14, 'target91'
    common.checked_plan = schema.checked_plan
    common.downloader = lambda record, receipt: capped.downloader(record, receipt, request_chunk_bytes=8*1024*1024)

    def actual_manifests(out, record):
        manifests(out, record)
        _, plan = schema.checked_plan()
        for name in ('manifest.json', 'nextn-manifest.json', 'target-manifest.json'):
            path = out / name
            value = common.read(path)
            value.update(file=plan['file'], variant='Q8_0', source_receipt=common.identity(out / 'acquisition.json'),
                source_plan=common.identity(S / 'loose-plan.json'),
                source_headers=[row['header_receipt'] for row in plan['shards']],
                scope='Actual original static33 Q8_0/F32 loose roles. No expert banks, repack, fallback, or full-model execution claim.')
            path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    common.manifests = actual_manifests
    return common


def require_budget():
    opener = urllib.request.urlopen
    code = getattr(opener, '__code__', None)
    assert code and Path(code.co_filename).resolve() == (R / '.scratch/mtp-download-budget-20261023/budget.py').resolve(), 'Actual HTTP requires the existing explicit budget runner'
    assert opener.__qualname__ == 'guarded.<locals>.open_range' and opener.__globals__.get('MIRROR_HOST') == 'hf-mirror.net'


if __name__ == '__main__':
    if not any(flag in sys.argv[1:] for flag in ('--plan-only', '--help', '-h')):
        require_budget()
    configured().main()
