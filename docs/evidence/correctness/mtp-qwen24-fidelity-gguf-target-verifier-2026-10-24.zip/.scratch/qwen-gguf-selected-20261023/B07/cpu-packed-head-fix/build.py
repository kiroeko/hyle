"""One CPU provider TU, then one-for-one replacement in actual B07 link1."""
from pathlib import Path
import argparse, difflib, importlib.util, json, os, sys
sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
R = next(p for p in S.parents if (p / 'include/hyle').is_dir())
N = S.parent / 'native-current'
F = R / '.scratch/mtp-packed-head-20261024/orin-proposal/mmq-query-proposal'
OLD = R / '.scratch/glm-mlx-flash-original-20261024/gdn-output-scale-validation/compile1/cpu-provider/identity.json'
SOURCE = R / 'src/compute_provider_ggml/ggml_cpu_provider.cc'

def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m); return m

f = module('_b07_cpu_delta_checks', F / 'build_focused.py')
h = module('_b07_cpu_delta_environment', R / '.scratch/native-paged-effects-20261022/build_windows.py')
q = module('_b07_cpu_delta_process', R / '.scratch/qwen-mtp-quality-20261022/run_quality.py')
read, save, identity, require = f.read, f.save, f.identity, f.require

def compile_provider():
    old = read(OLD)
    before = S / 'before' / SOURCE.relative_to(R)
    assert identity(before)['sha256'] == old['source']['sha256']
    out = S / 'compile1/cpu-provider'; out.mkdir(parents=True, exist_ok=False); (out / 'tmp').mkdir()
    obj = out / 'cpu-provider.obj'
    command = [('/Fo'+str(obj) if a.startswith('/Fo') else
                '/Fd'+str(out/'cpu-provider.pdb') if a.startswith('/Fd') else a) for a in old['command']]
    command[command.index('/sourceDependencies') + 1] = str(out / 'source-deps.json')
    observed = identity(SOURCE)
    snapshot = out / 'source' / SOURCE.relative_to(R)
    snapshot.parent.mkdir(parents=True); snapshot.write_bytes(SOURCE.read_bytes())
    (S/'source.patch').write_text(''.join(difflib.unified_diff(before.read_text().splitlines(True),
        SOURCE.read_text().splitlines(True), fromfile='a/'+SOURCE.relative_to(R).as_posix(),
        tofile='b/'+SOURCE.relative_to(R).as_posix())), encoding='utf-8', newline='\n')
    save(out/'plan.json', dict(command=command, source=observed, recipe=identity(OLD)))
    env, _ = h.b.environment(command, [], out); env.update(TEMP=str(out/'tmp'), TMP=str(out/'tmp'))
    print('START CPU provider', flush=True)
    process = q.execute(command, env, out/'run', timeout=1800)
    if process['exit'] or process['timed_out']: raise SystemExit(process['exit'] or 1)
    assert identity(SOURCE) == observed
    deps = read(out/'source-deps.json')['Data']
    dependencies = [identity(p) for p in dict.fromkeys([deps['Source'], *deps['Includes']])]
    save(out/'identity.json', dict(source=observed, object=identity(obj), command=command,
        dependencies=dependencies, recipe=identity(OLD), process=identity(out/'run/process.json'),
        source_snapshot=identity(snapshot)))
    print('END CPU provider exit0', flush=True)

def link():
    base = N/'tests-link1'; ready = read(base/'ready.json'); old_plan = read(base/'link-plan.json')
    assert read(base/'link.result.json')['exit'] == 0
    old = read(OLD); fresh_path = S/'compile1/cpu-provider/identity.json'
    fresh = f.current_record(identity(fresh_path))
    before = S/'before'/SOURCE.relative_to(R)
    assert identity(before)['sha256'] == old['source']['sha256']
    require(old['object']); require(ready['consumer_record'])
    f.current_record(ready['consumer_record'])
    records = []; replacements = 0
    for row in old_plan['retained_current_records']:
        if Path(row['path']).resolve() == OLD:
            require(row); records.append(identity(fresh_path)); replacements += 1
        else:
            f.current_record(row); records.append(row)
    assert replacements == 1 and len(records) == 131
    for row in old_plan['retained_inputs']: require(row)
    native = module('_b07_unchanged_native_inputs', F/'current_closure.py').native_inputs()
    command = []; replaced = 0
    for arg in old_plan['command']:
        if arg.upper().startswith(('/OUT:', '/MAP:', '/IMPLIB:', '/PDB:')): continue
        if arg.lower().endswith('.obj') and Path(arg).resolve() == Path(old['object']['path']).resolve():
            arg = fresh['object']['path']; replaced += 1
        command.append(arg)
    assert replaced == 1
    for row in native:
        assert sum(a.lower().endswith('.obj') and Path(a).resolve() == Path(row['object']['path']).resolve() for a in command) == 1
    out = N/'tests-link2'; out.mkdir(exist_ok=False); (out/'tmp').mkdir()
    image = out/'qwen-gguf-checks.exe'
    command += ['/OUT:'+str(image), '/MAP:'+str(image.with_suffix('.map')), '/IMPLIB:'+str(image.with_suffix('.lib'))]
    retired = dict(record=identity(OLD), object=old['object'], original_source=old['source'],
        source_snapshot=identity(before), retired_only=True, source_is_current=False)
    plan = dict(old_plan, command=command, base=identity(base/'link-plan.json'), base_image=ready['image'],
        retained_current_records=records, retired_product_records=[retired],
        fresh_product_records=[identity(fresh_path)], product_translation_units=1,
        consumer_translation_units=0, reused_consumer_translation_units=1,
        delta_helper=identity(__file__), product_delta=identity(S/'source.patch'))
    save(out/'link-plan.json', plan)
    env, _ = h.b.environment(command, [], out); env.update(TEMP=str(out/'tmp'), TMP=str(out/'tmp'))
    print('START link2', flush=True)
    process = q.execute(command, env, out/'link', timeout=1800)
    save(out/'link.result.json', process)
    if process['exit'] or process['timed_out']: raise SystemExit(process['exit'] or 1)
    runtime = read(base/'runtime-environment.json')
    for row in runtime['staged_dlls']:
        require(row); os.link(row['path'], out/Path(row['path']).name)
    runtime['PATH'] = str(out) + os.pathsep + runtime['PATH']
    runtime.update(previous=identity(base/'runtime-environment.json'),
        staged_dlls=[identity(p) for p in out.glob('*.dll')])
    runtime['matched_HC_PRE_worker'] = runtime['staged_dlls'][0]
    save(out/'runtime-environment.json', runtime)
    save(out/'ready.json', dict(ready, image=identity(image), link_plan=identity(out/'link-plan.json'),
        runtime_environment=identity(out/'runtime-environment.json'),
        cpu_provider_record=identity(fresh_path), link_result=identity(out/'link.result.json')))
    print('END link2 exit0', flush=True)

if __name__ == '__main__':
    parser=argparse.ArgumentParser(description=__doc__); parser.add_argument('action', choices=['compile','link'])
    args=parser.parse_args(); compile_provider() if args.action=='compile' else link()
