"""Actual B07 link2 product closure; omit its existing model consumer."""
from pathlib import Path
import importlib.util, json, sys
sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
R = next(p for p in S.parents if (p/'include/hyle').is_dir())
F = S.parent/'native-current/tests-link2'
OLD = R/'.scratch/mtp-packed-head-20261024/orin-proposal/mmq-query-proposal/current_closure.py'
spec = importlib.util.spec_from_file_location('_unchanged_mmq_native_helpers', OLD)
old = importlib.util.module_from_spec(spec); spec.loader.exec_module(old)
helper = old.helper
read, save, identity, require, resolve = old.read, old.save, old.identity, old.require, old.resolve
check_record, native_inputs = old.check_record, old.native_inputs

def closure():
    helper.cached.clear()
    ready = read(F/'ready.json')
    for key in ('image','link_plan','runtime_environment','consumer_record','cpu_provider_record','link_result'):
        require(ready[key])
    actual, process = read(ready['link_plan']['path']), read(ready['link_result']['path'])
    if process['exit'] or process['timed_out'] or process['command'] != actual['command']:
        raise ValueError('Require the actual successful one-provider replacement link')
    rows = actual['retained_current_records']
    if len(rows) != 131 or len({resolve(r['path']) for r in rows}) != 131:
        raise ValueError('Expected exactly131 actual current host records')
    paths = []
    for row in rows:
        helper.current_record(row); paths.append(resolve(row['path']))
    for retired in actual['retired_product_records']:
        record = read(require(retired['record']))
        require(retired['object']); snapshot = require(retired['source_snapshot'])
        if any(identity(snapshot)[k] != record['source'][k] for k in ('bytes','sha256')):
            raise ValueError('Retired provider source must retain its exact compiled bytes')
    native = native_inputs()
    for row in actual['retained_inputs']: require(row)
    for row in read(ready['runtime_environment']['path'])['staged_dlls']: require(row)
    consumer = read(require(ready['consumer_record']))
    require(consumer['object'])
    # This source was compiled before the base link; it is retired here,
    # never asserted to be the source of the next model consumer.
    snapshot = Path(ready['consumer_record']['path']).parent/'source'/resolve(consumer['source']['path']).relative_to(R)
    if any(identity(snapshot)[k] != consumer['source'][k] for k in ('bytes','sha256')):
        raise ValueError('Missing actual compiled consumer snapshot')
    removed = resolve(consumer['object']['path']); count = 0; command = []
    for arg in actual['command']:
        if arg.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:')): continue
        if arg.lower().endswith('.obj') and resolve(arg) == removed:
            count += 1
        else: command.append(arg)
    if count != 1: raise ValueError('Remove exactly the actual base model consumer')
    plan = dict(command=command, actual_flat_link=ready['link_plan'],
        host_records=rows, retained_inputs=actual['retained_inputs'], native_inputs=actual['native_inputs'],
        native_objects=[r['object'] for r in native], consumer_record=None,
        pending_consumer=True, append_consumer=True, current_host_count=131,
        removed_focused_test_records=actual['removed_focused_test_records'],
        removed_base_consumer_record=ready['consumer_record'], retired_product_records=actual['retired_product_records'],
        note='Actual link2 with one new CPU admission owner; append one consumer to this product-only command.')
    return plan, ready, resolve(ready['runtime_environment']['path']), None, paths

if __name__ == '__main__':
    p, r, runtime, consumer, paths = closure()
    print(json.dumps(dict(current_hosts=len(paths), native_objects=len(p['native_objects']),
        consumer=consumer, append_consumer=True, actual_base_image=r['image'], runtime=str(runtime)), indent=2))
