"""Publish B07's actual CPU/CUDA results and selected original expert receipts.

Offline metadata/source archive only: no inference, compilation, HTTP, weight
rehashing, scope mutation, or replacement of an earlier result.
"""
from datetime import datetime, timezone
import argparse
import importlib.util
import json
from pathlib import Path
import sys
import xml.etree.ElementTree as ET
import zipfile

sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
A = S.parent
G = A.parent
R = G.parents[1]
D = R / 'docs/evidence/correctness'
NAME = 'mtp-qwen24-fidelity-gguf-target-verifier-2026-10-24'


def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    value = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(value)
    return value


tools = module('_b07_small_archive', R / '.scratch/glm-quark-selected-20261024/Q30/publish.py')
tools.SMALL_SUFFIXES.update({'.tsv', '.c'})  # Typed catalog and actual CPU native index basis.
read, resolve, identity, require = tools.read, tools.resolve, tools.identity, tools.require


def build(ready, inputs, archive):
    for key in ('consumer_record', 'link_plan', 'runtime_environment'):
        require(ready[key]); archive.add(ready[key]['path'])
    record_path = resolve(ready['consumer_record']['path'])
    record, link = read(record_path), read(ready['link_plan']['path'])
    if (ready['artifact'] != 'B07' or record['artifact'] != 'B07' or
            ready['actual_artifact_inputs'] != inputs or record['artifact_inputs'] != inputs or
            link['consumer_record'] != ready['consumer_record'] or link['actual_artifact_inputs'] != inputs):
        raise ValueError('Executed consumer and its actual own-source pins differ')
    image = resolve(ready['image']['path'])
    if (image.stat().st_size != ready['image']['bytes'] or
            read(record_path.parent / 'compile.result.json')['exit'] != 0 or
            read(image.parent / 'link.result.json')['exit'] != 0):
        raise ValueError('Actual compile/link/image did not complete')
    product_delta = link.get('fresh_product_records', [])
    counts = (link['consumer_translation_units'], link.get('reused_consumer_translation_units', 0),
              link['product_translation_units'])
    if (link['append_consumer'] is not True or counts not in ((1, 0, 0), (0, 1, 1)) or
            any(link[key] != 0 for key in ('SDK_builds', 'NVCC_builds')) or
            len(product_delta) != counts[2]):
        raise ValueError('Expected the actual one-consumer image and its optional single CPU provider delta')
    for item in product_delta:
        require(item); archive.metadata_tree(resolve(item['path']).parent)
    for item in link.get('retired_product_records', []):
        require(item['record']); archive.add(item['record']['path'])
        require(item['source_snapshot']); archive.add(item['source_snapshot']['path'])
    for key in ('delta_helper', 'product_delta'):
        if key in link:
            require(link[key]); archive.add(link[key]['path'])
    for info in (record['source'], *record['dependencies']):
        if resolve(info['path']).is_relative_to(R / 'tests/compute_models'):
            archive.source(info, record_path)
    for key in ('entry', 'shared_helper', 'closure_helper'):
        require(link[key]); archive.add(link[key]['path'])
    archive.metadata_tree(record_path.parent)
    archive.metadata_tree(image.parent)
    return dict(consumer_record=ready['consumer_record'], link_plan=ready['link_plan'],
        runtime=ready['runtime_environment'], image=ready['image'],
        retained_host_records=len(link['retained_current_records']),
        native_inputs=link['native_inputs'], retained_native_objects=link['retained_native_objects'],
        fresh_consumer_TUs=counts[0], reused_consumer_TUs=counts[1], fresh_product_TUs=counts[2],
        fresh_product_records=product_delta, SDK_builds=0, NVCC_builds=0)


def completed_run(backend, attempt, adapter, inputs, archive):
    folder = S / f'checks{attempt}-{backend}'
    summary, plan = read(folder / 'summary.json'), read(folder / 'plan.json')
    process, driver = read(folder / 'run/process.json'), read(folder / 'frontier.driver.json')
    if (summary['passed'] is not True or process['exit'] != 0 or process['timed_out'] is not False or
            summary['process'] != process or process['command'] != plan['command'] or
            plan['automatic_supply'] is not True or plan['driver'] is None):
        raise ValueError('An actual successful owned run is required')
    if (driver.get('exit') != 0 or driver['native']['exit'] != 0 or
            driver['native']['stopped_by_driver'] is not False or
            driver['job_cleanup']['remaining_descendants'] != 0 or
            any(row['exit'] != 0 or row.get('stopped_by_driver', False) for row in driver['fetches'])):
        raise ValueError('Native or selected expert supplier did not retire successfully')
    if driver['native']['command'] != plan['native_command']:
        raise ValueError('Owned driver ran a different native command')
    tree = ET.parse(folder / 'results.xml').getroot()
    cases = list(tree.iter('testcase'))
    expected = adapter.CASES[backend]
    if (len(cases) != 1 or any(list(tree.iter(k)) for k in ('failure', 'error', 'skipped')) or
            any(int(tree.get(k, '0')) for k in ('failures', 'errors', 'disabled'))):
        raise ValueError('Exactly one passing, unskipped case is required')
    case = cases[0]
    properties = {row.get('name'): row.get('value') for row in case.iter('property')}
    if (case.get('classname') + '.' + case.get('name') != expected or
            case.get('status') != 'run' or case.get('result') != 'completed' or
            summary['case'] != expected or summary['properties'] != properties or
            (summary['tests'], summary['failures'], summary['skips']) != (1, 0, 0)):
        raise ValueError('Actual case/XML/summary differ')
    if (summary['artifacts'] != inputs or plan['artifacts'] != inputs or
            summary['image'] != plan['image'] or summary['consumer_record'] != plan['consumer_record']):
        raise ValueError('Actual source/image inputs differ')
    graphs = int(properties['actual_submissions'])
    if graphs <= 0 or graphs != summary['actual_graph_submissions']:
        raise ValueError('Missing actual Graph execution count')
    image = resolve(plan['image']['path'])
    ready = read(image.parent / 'ready.json')
    if (ready['image'] != plan['image'] or ready['consumer_record'] != plan['consumer_record'] or
            resolve(driver['native']['command'][0]) != image or '--gtest_filter=' + expected not in driver['native']['command']):
        raise ValueError('Executed image does not match the actual linked consumer')
    for key in ('entry', 'shared_helper', 'closure_helper', 'driver'):
        require(plan[key]); archive.add(plan[key]['path'])
    archive.metadata_tree(folder)
    archive.add(image.parent / 'ready.json')
    return dict(backend=backend.upper(), case=expected, tests=1, failures=0, skips=0,
        graph_submissions=graphs, properties=properties,
        summary=identity(folder / 'summary.json'), XML=identity(folder / 'results.xml'),
        process=identity(folder / 'run/process.json'), driver=identity(folder / 'frontier.driver.json'),
        build=build(ready, inputs, archive)), driver


def selected_experts(drivers, archive):
    source = identity(A / 'expert-source-plan.json')
    cached, requests = {}, []
    for driver in drivers:
        for fetch in driver['fetches']:
            request = fetch['request']
            if (request['section'] not in ('nextn', 'target91') or request['stage'] != 0 or
                    not set(request['missing_ids']) <= set(request['global_ids']) or
                    not 1 <= len(request['global_ids']) <= 10 or
                    any(type(n) is not int or not 0 <= n < 512 for n in request['global_ids'])):
                raise ValueError('Actual expert frontier exceeds the selected original domain')
            requests.append(dict(request=request, exit=fetch['exit']))
    for path in sorted((A / 'original-experts').glob('*/expert*/ready.json')):
        ready = read(path)
        directory, section = path.parent, ready['section']
        ids = ready['globals']
        receipt = read(directory / 'acquisition.json')
        if (ready['complete'] is not True or section not in ('nextn', 'target91') or
                len(ids) != 1 or not 0 <= ids[0] < 512 or ready['source_plan_sha256'] != source['sha256'] or
                receipt['complete'] is not True or receipt['original_roles'] != 3 or
                receipt['role_payload_bytes'] != 53_477_376 or receipt['whole_shard_downloaded'] is not False):
            raise ValueError('Selected original expert receipt is incomplete or mismatched')
        require(ready['acquisition'], directory / 'acquisition.json')
        catalog = identity(directory / 'catalog.tsv')
        if catalog['bytes'] > 65536 or any(catalog[k] != ready['catalog'][k] for k in ('bytes', 'sha256')):
            raise ValueError('Actual immutable selected expert catalog differs')
        if any(not row['complete'] or resolve(row['payload']['path']).stat().st_size != row['bytes']
               for row in receipt['roles']):
            raise ValueError('Selected expert plane is absent or incomplete')
        archive.metadata_tree(directory)
        archive.add(directory / 'catalog.tsv')
        cached[(section, ids[0])] = dict(section=section, global_id=ids[0],
            bytes=receipt['role_payload_bytes'], ready=identity(path), catalog=catalog,
            acquisition=identity(directory / 'acquisition.json'), plan=identity(directory / 'plan.json'))
    if any((item['request']['section'], n) not in cached for item in requests for n in item['request']['missing_ids']):
        raise ValueError('Actual successful missing frontier lacks its original expert receipt')
    return dict(cached_sets=list(cached.values()), actual_missing_frontiers=requests,
        cached_payload_bytes=sum(row['bytes'] for row in cached.values()), body_rehashed=False,
        accounting='Cached receipts and missing-frontier requests; native active-ID observations remain verbatim in each execution.')


def main():
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument('--cpu-attempt', type=int, required=True)
    cli.add_argument('--cuda-attempt', type=int, required=True)
    cli.add_argument('--source-root', type=Path, action='append', default=[])
    args = cli.parse_args()
    if min(args.cpu_attempt, args.cuda_attempt) <= 0:
        raise ValueError('Positive actual attempts are required')
    output, zip_path = D / (NAME + '.json'), D / (NAME + '.zip')
    if output.exists() or zip_path.exists():
        raise ValueError('Do not overwrite earlier published evidence')
    common = module('_b07_actual_adapter', G / 'current-native-proposal/build_current.py')
    adapter = common.Adapter('B07')
    inputs = adapter.artifacts(adapter.HEADER)
    generator = module('_b07_actual_generator', adapter.GENERATOR)
    plan, pins, experts, facts = generator.checked_metadata(generator.schema())
    archive = tools.Archive([path.resolve() for path in args.source_root])
    pairs = [completed_run(backend, attempt, adapter, inputs, archive)
        for backend, attempt in (('cpu', args.cpu_attempt), ('cuda', args.cuda_attempt))]
    executions = [pair[0] for pair in pairs]
    experts = selected_experts([pair[1] for pair in pairs], archive)
    for item in inputs:
        archive.add(item['path'])
    static_history = []
    chains = R / '.scratch/mtp-download-budget-20261023/static-umbrella-20261024/batches'
    for chain in sorted(chains.glob('attempt*/children/B07')):
        archive.metadata_tree(chain)
        if (chain / 'summary.json').is_file():
            child = read(chain / 'summary.json')
            static_history.append(dict(summary=identity(chain / 'summary.json'), passed=child['passed']))
    archive.metadata_tree(S / 'pins-generation1')
    attempt_history = []
    for folder in sorted(S.glob('checks*-*')):
        archive.metadata_tree(folder)
        if (folder / 'summary.json').is_file():
            prior = read(folder / 'summary.json')
            prior_plan = read(folder / 'plan.json')
            stdout = (folder / 'run/stdout.log').read_text(encoding='utf-8', errors='replace')
            kind = 'completed' if prior.get('passed') is True else 'failed_run'
            if 'graph node 23: matmul: no available operation or region implementation' in stdout:
                kind = 'cold_encoded_rhs_admission_failure'
            elif (prior_plan.get('automatic_supply') is False and prior['process']['exit'] == 3 and
                    'actual original original expert planes are absent; explicit frontier supply is required' in stdout):
                kind = 'cached_only_frontier_probe_missing_experts'
            attempt_history.append(dict(summary=identity(folder / 'summary.json'),
                passed=prior.get('passed'), kind=kind, backend=folder.name.rsplit('-', 1)[-1],
                image=prior['image']))
    # The cold-only diagnostic still ends at missing selected experts and is
    # retained as a failed attempt, never counted as an execution pass.
    correction = A / 'cpu-packed-head-fix'
    archive.metadata_tree(correction)
    archive.add(R / 'src/compute_provider_ggml/ggml_cpu_provider.cc')
    archive.add(R / 'tests/compute_provider_ggml/mature_admission_test.cc')
    native_source = R / '.scratch/validation/cpu-final-f1/mixed-iq1/source'
    archive.add(native_source / 'include/ggml.h')
    archive.add(native_source / 'src/ggml-cpu/ggml-cpu.c')
    for path in (Path(__file__), A / 'tooling-proposal'):
        if path.is_dir():
            for source in path.glob('*.py'): archive.add(source)
        else: archive.add(path)
    archive.add(R / '.scratch/qwen-bfloat-selected-20261023/B05/fetch_experts.py')
    archive.add(R / '.scratch/dspark-pro-target-draft-20261023/run_with_supply.py')
    for directory in ('batch-plans', 'batches', 'frontier-plans'):
        archive.metadata_tree(A / directory)
    for directory in ('workers8-before', 'workers8-plan-only1'):
        archive.metadata_tree(A / 'tooling-proposal' / directory)
    shared = [identity(D / (name + '.json')) for name in
        ('mtp-packed-mmq-workspace-2026-10-24', 'mtp-cpu-native-family-2026-10-24')]
    record = dict(created_at=datetime.now(timezone.utc).isoformat(), status='passed',
        identity=dict(id='B07', repository=plan['repository'], revision=plan['revision'], file=plan['file'], variant='Q8_0'),
        original_roles=33, original_bytes=plan['source_bytes'], original_parameters=facts,
        static_acquisition_attempts=static_history,
        pin_generation=identity(S / 'pins-generation1/process.json'),
        attempt_history=attempt_history,
        failed_runs=[row for row in attempt_history if row['passed'] is not True],
        cpu_packed_head_correction=dict(source_patch=identity(correction / 'source.patch'),
            focused_test_patch=identity(correction / 'focused-test.patch'),
            descriptor_only_check=identity(correction / 'cold-checks1/summary.json'),
            native_index_basis='Fixed same-family ggml.h:320-326 uses int64 dimensions and size_t strides; ggml-cpu.c:1183-1270 reads W at src0_row + ir0*nb01, with int64 ir0. MUL_MAT converts only activation rows to its original vec_dot_type.',
            scope='Canonical rank2 F32 A/Y and previously supported encoded RHS only; existing logical element, individual stride and other-port limits retained.'),
        selected_expert_acquisition=experts, executions=executions,
        actual_Graph_submissions=sum(row['graph_submissions'] for row in executions),
        compiled_consumer_sources=list(archive.sources.values()), shared_product_evidence=shared,
        scope='Own original target91/NextN92 and full vocabulary, domain512/Top10 Q8_0 experts; shared K1/12-resource StateHead with finite upstream/history fixtures.',
        limitations=['Layer90 input/history fixtures do not execute the preceding trained trunk or full model.',
            'One natural K1 trial and separate controlled match/rejection are not a natural acceptance-rate result.',
            'No TPS, full-model quality, measured physical memory or additional platform/device claim.'],
        throughput_evidence=False, memory_evidence=False, whole_model_quality=False, body_rehashed=False)
    if sum(path.stat().st_size for path in archive.files.values()) > 33_554_432:
        raise ValueError('Keep only the finite source/commands/logs/receipt subset')
    with zipfile.ZipFile(zip_path, 'x', zipfile.ZIP_DEFLATED, compresslevel=6) as target:
        for name, path in sorted(archive.files.items()): target.write(path, name)
    record.update(archive=identity(zip_path), archived_files=len(archive.files))
    output.write_text(json.dumps(record, ensure_ascii=False, indent=2, allow_nan=False) + '\n', encoding='utf-8')
    print(json.dumps(dict(evidence=identity(output), archive=record['archive'], graphs=record['actual_Graph_submissions'])))


if __name__ == '__main__':
    main()
