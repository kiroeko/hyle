#pragma once

#include "qwen_gguf_q24_artifacts.h"
#include "d5_qwen_gguf_vocabulary_cases.h"

// Actual completed original static33 pins; expert banks are metadata only.
namespace qwen_gguf_q24_artifacts::b07 {
namespace selected=qwen_gguf_selected_experts;
inline constexpr auto &kIdentity=qwen_gguf_q24_artifacts::kIdentity;
// The selected whole-model census/profile remains the frozen Q8_0 identity.
inline constexpr auto &kProfile=d5_qwen_gguf_vocabulary_cases::k24TFidelityProfile;
inline constexpr std::string_view kReceiptSha256="f17d9f7b136e644bf1a8130aa4d2145c8b0e25e8128a91c38bc794a133df713f";
inline constexpr std::string_view kManifestSha256="d83a13a64e7fc5a656723e015d21dc7b0e3eef5a9a52be1c66df78c1a84b11f6";
inline constexpr std::string_view kPlanSha256="3a3546a5d7b583189f227ae9383d9c999731ac8098daf93732b379e61ab2e344";
inline constexpr std::string_view kExpertPlanSha256="14a18c316c6de42d6d8c66b58b22b19586b8b92187b8207e5b6d081df91cb218";
inline std::array<named::ManifestSpec,kStaticRoles> manifest() {
  return qwen_gguf_q24_artifacts::manifest(std::array<named::PinnedFile,kStaticRoles>{{
    {"token_embd.weight.bin","b683b09ac64d662b842ff4a43460b3673586ec55aab9f70cc37219cf40232d27"},
    {"output_norm.weight.bin","6cec2111e1c0dabe6dd413a0cc8a102519a510b7ce3272866d938cf518ce7c1c"},
    {"blk.92.nextn.eh_proj.weight.bin","6751ef5e6b912e3870e5f9caa02b9a40786aab3c3cb24e1b55af94ca4bfc8e3a"},
    {"blk.92.attn_norm.weight.bin","cf0b140e2bf1e2b879c3b4e501c979b9be42e7f872cbe1b23502638c31e659a7"},
    {"blk.92.ffn_gate_inp.weight.bin","02151dcd70510967ebf688277965458e07664da440460f73321b830ddf54aca0"},
    {"blk.92.ffn_down_shexp.weight.bin","4e971267c11418cb5f2fa6b34bbada4c608fc76080fefa96425543eaf6c51674"},
    {"blk.92.ffn_gate_shexp.weight.bin","180fd106413d082a5f2c2d45263274cc3cdffbc1a697e7bdf66caff0d46f047e"},
    {"blk.92.ffn_up_shexp.weight.bin","c48da9915a61bb47142fbfb64d81a2814a0e92512834dc3f3252ccb309b6ec4c"},
    {"blk.92.ffn_gate_inp_shexp.weight.bin","7d506c35ad678bb0ee1f6bbf4986819d0a88f668b3e2809c4387b0e96ac7a29b"},
    {"blk.92.post_attention_norm.weight.bin","4d5a6f2409e1d1f814cc5c541fa964c1a41aa5167ecd3e5206c0ee864aec2312"},
    {"blk.92.attn_k_norm.weight.bin","815bc7300aad77fecbbb494b15e70949ecb0e43b8ccaf2958a40afdc39737125"},
    {"blk.92.attn_k.weight.bin","0ba4ef7e14e37e503307509ab37b30f4f78ea7b92f0b4be5e8a4e81d4440577c"},
    {"blk.92.attn_output.weight.bin","596ba9ba07c4010cfad801be0acd31249bad13ae94d74cd31ea77228d2681a83"},
    {"blk.92.attn_q_norm.weight.bin","63f5b65322b3810ee1c0517f34128331d30adce9860efab873380558a4a54b8d"},
    {"blk.92.attn_q.weight.bin","e1894aeef0cfe5accbf21a9f16be81da5ad04d3bf77985be0fbf615bac21d1a6"},
    {"blk.92.attn_v.weight.bin","e04ed961be56f72f0d02511bbc752299cb71c4df56c57ae842ad6410d73a7f22"},
    {"blk.92.nextn.shared_head_norm.weight.bin","84d91000988b8995b93fe268a3ac7fe6a0239203ffd23277b64e2a39b31b287a"},
    {"blk.92.nextn.enorm.weight.bin","6c97b1107715a0a97d85f2f6b663ed2f8d22896d65f67cdb3cebc48cd0ab433e"},
    {"blk.92.nextn.hnorm.weight.bin","f2818f79d7c61980a063f600c9d06d07ff6e4e8f9f7b866a244c8e01bbce2a9d"},
    {"blk.91.attn_norm.weight.bin","4da43d09a561163a684f4e9d5426e5b51d428a91ee827b5140bec05caa469f54"},
    {"blk.91.ffn_gate_inp.weight.bin","ef5efde62f9ac68fb6f97d9d3a34661e30b279849b3e8c4a919ab03eb5f3baf3"},
    {"blk.91.ffn_down_shexp.weight.bin","87efe76971a7c3cafbafe3bfd7bb953878c4c8189f0ded5bc2e5acf5cb9e4d96"},
    {"blk.91.ffn_gate_shexp.weight.bin","8a1a390112d416692696b38ac9f54d05c149590819da8647628ea3ca3ec7eb84"},
    {"blk.91.ffn_up_shexp.weight.bin","a312849db305f792a87107fce4c9839dbd8544bdacdfcbd967988a8bc0b76816"},
    {"blk.91.ffn_gate_inp_shexp.weight.bin","fdef3f9399555111dad0fc976ab5437e06cefa32ead03fb7886cb5af55256d56"},
    {"blk.91.post_attention_norm.weight.bin","5fc9df2dfde80ff743ec7c9c3aae9979ada6917aef50579d8e56a4f176cfc4d5"},
    {"blk.91.attn_k_norm.weight.bin","36489e8fbe3b618d03885fec3e24959a616ffa4c41c7ddb04ea61397f1cfd60c"},
    {"blk.91.attn_output.weight.bin","5e643ea79d2410e347b5e4c9df4916015a1e6921617046a95673155027cbefe5"},
    {"output.weight.bin","6d9921b0cd13e13493e7b72fc474c122b799016456cb4f0e25bc50697df64fe5"},
    {"blk.91.attn_k.weight.bin","b717aeded27f0f02e57ef5e027e579327cca725bfe6ec941bb1e9d9f4c5190c9"},
    {"blk.91.attn_q_norm.weight.bin","0377cdf1c646494a50688c78ed370e9eb2725d0014786793ff8646b0287956af"},
    {"blk.91.attn_q.weight.bin","2cf8e73391ad143dfe541cc2f84eba133a9ec29d8cd7be4a34616f155dc13604"},
    {"blk.91.attn_v.weight.bin","034af0bc0de3631c7528f58c49b1846a13ea8878f42da185acc6c57729835a54"},
  }});
}
inline selected::Contract expert_contract(selected::Section section) {
  selected::Contract result;
  result.repository=kIdentity.repository;result.revision=kIdentity.revision;result.variant=kIdentity.variant;
  result.source_plan_sha256=kExpertPlanSha256;result.section=section;
  switch(section) {
  case selected::Section::kNextn:
    result.banks={{
      {"blk.92.ffn_gate_exps.weight","Q8_0/Qwen3.8-2.4T-A95B-Q8_0-00049-of-00056.gguf",original::detail::take(c::gguf_grouped_weight_description(c::GgufQuantizedType::kQ8_0,c::DataType::kFloat32,512,2048,8192),"actual B07 original expert bank"),28966591360ULL,47220202368ULL},
      {"blk.92.ffn_up_exps.weight","Q8_0/Qwen3.8-2.4T-A95B-Q8_0-00049-of-00056.gguf",original::detail::take(c::gguf_grouped_weight_description(c::GgufQuantizedType::kQ8_0,c::DataType::kFloat32,512,2048,8192),"actual B07 original expert bank"),38093396864ULL,47220202368ULL},
      {"blk.92.ffn_down_exps.weight","Q8_0/Qwen3.8-2.4T-A95B-Q8_0-00050-of-00056.gguf",original::detail::take(c::gguf_grouped_weight_description(c::GgufQuantizedType::kQ8_0,c::DataType::kFloat32,512,8192,2048),"actual B07 original expert bank"),480ULL,45634028000ULL},
    }};break;
  case selected::Section::kTarget91:
    result.banks={{
      {"blk.91.ffn_gate_exps.weight","Q8_0/Qwen3.8-2.4T-A95B-Q8_0-00056-of-00056.gguf",original::detail::take(c::gguf_grouped_weight_description(c::GgufQuantizedType::kQ8_0,c::DataType::kFloat32,512,2048,8192),"actual B07 original expert bank"),9126809984ULL,41096785792ULL},
      {"blk.91.ffn_up_exps.weight","Q8_0/Qwen3.8-2.4T-A95B-Q8_0-00056-of-00056.gguf",original::detail::take(c::gguf_grouped_weight_description(c::GgufQuantizedType::kQ8_0,c::DataType::kFloat32,512,2048,8192),"actual B07 original expert bank"),18253615488ULL,41096785792ULL},
      {"blk.91.ffn_down_exps.weight","Q8_0/Qwen3.8-2.4T-A95B-Q8_0-00056-of-00056.gguf",original::detail::take(c::gguf_grouped_weight_description(c::GgufQuantizedType::kQ8_0,c::DataType::kFloat32,512,8192,2048),"actual B07 original expert bank"),27380420992ULL,41096785792ULL},
    }};break;
  default:throw std::runtime_error("invalid B07 actual expert section");
  }
  return result;
}
} // namespace qwen_gguf_q24_artifacts::b07
