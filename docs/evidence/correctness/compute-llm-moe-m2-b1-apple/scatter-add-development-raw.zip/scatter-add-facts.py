import hashlib
import json
from pathlib import Path
import subprocess

root = Path('/Users/kiro/hyle')
work = Path('/Users/kiro/hyle-m2b1-apple')
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def run(*args): return subprocess.check_output(args, text=True).strip()
sources = ['src/compute_route_apple/apple_mature_indexing.cc',
           'src/compute_route_apple/apple_tensor.cc',
           'tests/compute_route_apple/scatter_test.cc',
           'tests/compute_route_apple/scatter_test_support.h',
           'tests/compute_route_apple/indexing_test.cc',
           'tests/graph_route_apple/scatter_test.cc',
           'include/hyle/compute/operation.h', 'src/compute_ops/operation.cc',
           'tests/compute_ops/operation_test.cc', 'docs/user/apple-compute.md']
cache = (work / 'build/CMakeCache.txt').read_text(encoding='utf-8')
facts = {
    'machine_model': run('/usr/sbin/sysctl', '-n', 'hw.model'),
    'os': run('/usr/bin/sw_vers'),
    'compiler': run('/Library/Developer/CommandLineTools/usr/bin/clang++', '--version'),
    'source_checkout_commit': run('git', '-C', str(root), 'rev-parse', 'HEAD'),
    'canonical_validation_tree': run('git', '-C', str(root), 'write-tree'),
    'unstaged_changes': run('git', '-C', str(root), 'diff', '--name-only'),
    'source_sha256': {name: sha(root / name) for name in sources},
    'artifact_sha256': {name: sha(work / 'build/bin' / name) for name in [
        'libhyle_compute_ops.dylib', 'libhyle_compute_route_apple.dylib',
        'libhyle_graph_route_apple.dylib', 'libmlx.dylib', 'hyle_compute_ops_test',
        'hyle_compute_route_apple_test', 'hyle_graph_route_apple_test']},
    'configuration': [line for line in cache.splitlines() if line.startswith((
        'CMAKE_BUILD_TYPE:', 'CMAKE_CXX_COMPILER:', 'HYLE_STATIC:', 'MLX_BUILD_CPU:',
        'MLX_BUILD_METAL:', 'MLX_BUILD_CUDA:', 'MLX_METAL_JIT:', 'HYLE_COMPUTE_APPLE:',
        'CMAKE_OSX_DEPLOYMENT_TARGET:', 'HYLE_WERROR:'))],
}
assert facts['canonical_validation_tree'] == '1ca0ac214b274dd92993072899eb7a7bc2900491'
assert facts['unstaged_changes'] == ''
(work / 'scatter-add-facts.json').write_text(json.dumps(facts, indent=2) + '\n', encoding='utf-8')
print('Recorded', facts['machine_model'], facts['canonical_validation_tree'])
