#include <mlx/array.h>
#include <mlx/compile.h>
#include <mlx/ops.h>
#include <mlx/transforms.h>
#include <algorithm>
#include <cmath>
#include <cstdint>
#include <cstring>
#include <iostream>
#include <limits>
#include <numeric>
#include <stdexcept>
#include <vector>

namespace mx = mlx::core;
mx::Stream stream() { return mx::default_stream(mx::Device::gpu); }
void require(bool ok, const char *message) { if (!ok) throw std::runtime_error(message); }
template<class T> std::vector<T> host(mx::array value) {
  value = mx::contiguous(value, false, stream());
  mx::eval(value); mx::synchronize(stream());
  if (!value.size()) return {};
  return {value.data<T>(), value.data<T>() + value.size()};
}
std::vector<float> values(const mx::array &value) {
  return host<float>(mx::astype(value, mx::float32, stream()));
}
std::vector<unsigned char> bytes(mx::array value) {
  value = mx::contiguous(value, false, stream());
  mx::eval(value); mx::synchronize(stream());
  std::vector<unsigned char> out(value.size() * value.itemsize());
  if (!out.empty()) std::memcpy(out.data(), value.data<void>(), out.size());
  return out;
}
int elements(const mx::Shape &shape) {
  return std::accumulate(shape.begin(), shape.end(), 1, std::multiplies<int>());
}
mx::array data(mx::Shape shape, mx::Dtype type, int phase, bool strided) {
  std::vector<float> payload(elements(shape));
  for (std::size_t i=0; i<payload.size(); ++i)
    payload[i] = (static_cast<int>((i * 7 + phase * 3) % 29) - 14) / 32.F;
  auto stored = shape;
  if (strided) std::reverse(stored.begin(), stored.end());
  auto out = mx::astype(mx::array(payload.data(), stored, mx::float32), type, stream());
  if (strided) {
    std::vector<int> axes(shape.size());
    std::iota(axes.rbegin(), axes.rend(), 0);
    out = mx::transpose(out, axes, stream());
  }
  return out;
}
std::vector<mx::array> original(const std::vector<mx::array> &input, int axis, bool checked) {
  auto s = stream(); const auto &base=input[0];
  if (!base.size()) return {mx::zeros(base.shape(),base.dtype(),s),mx::array(0)};
  if (!input[1].size()) return {mx::copy(base,s),mx::array(0)};
  if (axis<0) axis+=base.ndim();
  int count=static_cast<int>(input[1].size());
  auto ids=mx::reshape(input[1],{count},s);
  auto safe=ids; auto status=mx::array(0);
  if (checked) {
    auto bad=mx::logical_or(mx::less(ids,mx::array(0,ids.dtype()),s),
        mx::greater_equal(ids,mx::array(base.shape(axis),ids.dtype()),s),s);
    safe=mx::where(bad,mx::array(0,ids.dtype()),ids,s);
    status=mx::astype(mx::any(bad,s),mx::int32,s);
  }
  auto shape=base.shape(); shape[axis]=count;
  auto updates=mx::expand_dims(mx::moveaxis(mx::reshape(input[2],shape,s),axis,0,s),axis+1,s);
  auto sum=mx::scatter_add(mx::astype(base,mx::float32,s),safe,
      mx::astype(updates,mx::float32,s),axis,s);
  return {mx::astype(sum,base.dtype(),s),status};
}
std::vector<double> oracle(const mx::array &base, const mx::array &updates,
                           const std::vector<std::int64_t> &ids, int axis) {
  const auto source=values(base), delta=values(updates);
  std::vector<double> expected(source.begin(),source.end());
  if (source.empty() || ids.empty()) return expected;
  if (axis<0) axis+=base.ndim();
  std::size_t inner=1;
  for (std::size_t i=axis+1;i<base.ndim();++i) inner*=base.shape(i);
  std::size_t extent=base.shape(axis);
  for (std::size_t outer=0;outer<source.size()/extent/inner;++outer)
    for (std::size_t index=0;index<ids.size();++index)
      for (std::size_t lane=0;lane<inner;++lane)
        expected[(outer*extent+ids[index])*inner+lane] += delta[(outer*ids.size()+index)*inner+lane];
  return expected;
}
void check(mx::array output, const std::vector<double> &expected) {
  auto actual=values(output);
  require(actual.size()==expected.size(),"shape differs");
  const double relative=output.dtype()==mx::bfloat16 ? 0.004 : output.dtype()==mx::float16 ? 0.0005 : 0;
  for (std::size_t i=0;i<actual.size();++i) {
    if (std::isnan(expected[i])) require(std::isnan(actual[i]),"NaN lost");
    else if (std::isinf(expected[i])) require(actual[i]==expected[i],"Inf differs");
    else require(std::abs(actual[i]-expected[i])<=relative*std::abs(expected[i]),"independent exact-binary sum differs");
  }
}
int main() try {
  struct Case { mx::Shape shape; int axis; mx::Shape indices; };
  const std::vector<Case> cases={{{7},0,{}},{{7},-1,{17}},{{7,129},0,{129}},
    {{2,7,3},1,{2,3}},{{2,7,3},-2,{4097}},{{2,3,7},-1,{17}},
    {{1,2,1,7,1,1,3,1},3,{}},{{1,2,1,7,1,1,3,1},3,{2,2}},
    {{2,7,3},1,{0}},{{2,0,3},1,{2}},{{0,7,3},1,{2}}};
  int checked_cases=0, controls=0;
  for (auto type:{mx::float32,mx::float16,mx::bfloat16})
    for (auto itype:{mx::int32,mx::int64})
      for (const auto &test:cases) {
        int axis=test.axis<0 ? test.axis+test.shape.size() : test.axis;
        auto us=test.shape;
        us.erase(us.begin()+axis);
        us.insert(us.begin()+axis,test.indices.begin(),test.indices.end());
        for (bool checked:{false,true}) {
          auto fn=mx::compile([=](const std::vector<mx::array> &in){return original(in,test.axis,checked);});
          for (int phase=0;phase<(checked?4:2);++phase) {
            auto base=data(test.shape,type,phase,true), updates=data(us,type,phase+1,true);
            std::vector<std::int64_t> ids(elements(test.indices));
            for (std::size_t i=0;i<ids.size();++i) ids[i]=phase%2 ? 3 : (i*5)%7;
            bool invalid=phase>=2 && !ids.empty() && base.size();
            if (invalid) ids.back()=phase==2 ? -1 : (itype==mx::int32 ? INT32_MAX : INT64_MAX);
            auto indices=mx::astype(mx::array(ids.data(),test.indices,mx::int64),itype,stream());
            if (test.indices.size()==2) {
              indices=mx::transpose(indices,{1,0},stream());
              ids=host<std::int64_t>(mx::astype(indices,mx::int64,stream()));
              us=test.shape; us.erase(us.begin()+axis);
              us.insert(us.begin()+axis,indices.shape().begin(),indices.shape().end());
              updates=data(us,type,phase+1,true);
            }
            auto base_bytes=bytes(base),update_bytes=bytes(updates);
            auto result=fn({base,indices,updates});
            require(host<std::int32_t>(result[1])[0]==int(invalid),"checked status differs");
            if (!invalid) check(result[0],oracle(base,updates,ids,axis));
            require(bytes(base)==base_bytes && bytes(updates)==update_bytes,"input changed");
            ++checked_cases;
          }
        }
      }
  std::cout<<"PASS "<<checked_cases<<" original MLX add shape/layout/status cases"<<std::endl;
  for (auto type:{mx::float32,mx::float16,mx::bfloat16}) {
    auto fn=mx::compile([](const std::vector<mx::array>& in){return original(in,0,true);});
    for (int count:{1,17,129}) {
      auto base=mx::zeros({1},type,stream()), updates=mx::ones({count},type,stream());
      auto result=fn({base,mx::zeros({count},mx::int64,stream()),updates});
      require(values(result[0])[0]==count,"exact contribution control lost an update"); ++controls;
    }
    float large=type==mx::float32 ? 16777216.F : type==mx::float16 ? 2048.F : 256.F;
    auto update=mx::astype(mx::array({large,1.F,-large}),type,stream());
    auto result=fn({mx::zeros({1},type,stream()),mx::array({0,0,0}),update});
    auto observed=values(result[0])[0];
    require(type==mx::float32 ? observed==0 || observed==1 : observed==1,"three-term association differs");
    std::cout<<"association type="<<type<<" expected_exact=1 observed="<<observed<<std::endl; ++controls;
    for (auto special:std::vector<std::vector<float>>{{INFINITY,-INFINITY},{NAN,1.F},{INFINITY,1.F},{-INFINITY,1.F}}) {
      auto updates=mx::astype(mx::array(special.data(),{2},mx::float32),type,stream());
      auto base=mx::zeros({1},type,stream());
      auto out=fn({base,mx::array({0,0}),updates});
      check(out[0],oracle(base,updates,{0,0},0)); ++controls;
    }
  }
  std::cout<<"PASS "<<controls<<" contribution/association/special controls; total "<<checked_cases+controls<<std::endl;
} catch (const std::exception &error) { std::cerr<<"FAIL "<<error.what()<<std::endl; return 1; }
