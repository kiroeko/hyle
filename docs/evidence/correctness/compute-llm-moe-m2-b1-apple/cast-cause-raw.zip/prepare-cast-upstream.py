import hashlib
import json
from pathlib import Path
import urllib.request

work = Path(__file__).resolve().parent
pin = '1f8e74e3f12f31365464a6867c6579f0e9b29d85'
old_pin = '726dbd926770b7c78cd23480e71f1a21c07a9bc0'
files = {
    'upstream-bf16.h': (pin, 'mlx/backend/metal/kernels/bf16.h'),
    'upstream-utils.h': (pin, 'mlx/backend/metal/kernels/utils.h'),
    'upstream-mlx-LICENSE': (pin, 'LICENSE'),
    'upstream-legacy-bf16.h': (old_pin, 'mlx/backend/metal/kernels/bf16.h'),
}
facts = {}
for name, (revision, path) in files.items():
    url = f'https://raw.githubusercontent.com/ml-explore/mlx/{revision}/{path}'
    data = urllib.request.urlopen(url, timeout=30).read()
    (work / name).write_bytes(data)
    facts[name] = {'revision': revision, 'path': path, 'url': url,
                   'sha256': hashlib.sha256(data).hexdigest()}
legacy = (work / 'upstream-legacy-bf16.h').read_text(encoding='utf-8')
start = legacy.index('constexpr METAL_FUNC uint16_t float_to_bfloat_bits(float x) {')
end = legacy.index('\n}\n', start) + 3
(work / 'upstream-converter.txt').write_text(legacy[start:end], encoding='utf-8', newline='\n')
(work / 'cast-upstream.json').write_text(json.dumps(facts, indent=2) + '\n', encoding='utf-8', newline='\n')
print(json.dumps(facts, indent=2))
