import hashlib
import json
from pathlib import Path
import subprocess

work = Path('/Users/kiro/hyle-m2b1-apple')
source = Path('/Users/kiro/Library/Caches/hyle/dependencies/v1/sources/mlx-1f8e74e3f12f-95caa530dd41')
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
def run(*args):
    return subprocess.check_output(args, text=True).strip()
cache = (work / 'build/CMakeCache.txt').read_text()
facts = {
    'machine_model': run('/usr/sbin/sysctl', '-n', 'hw.model'),
    'os': run('/usr/bin/sw_vers'),
    'compiler': run('/Library/Developer/CommandLineTools/usr/bin/clang++', '--version'),
    'source_sha256': {name: sha(source / name) for name in [
        'mlx/ops.h', 'mlx/ops.cpp', 'mlx/backend/metal/scan.cpp', 'mlx/backend/metal/sort.cpp', 'LICENSE']},
    'artifact_sha256': {name: sha(work / name) for name in ['indexed-probe', 'build/bin/libmlx.dylib']},
    'configuration': [line for line in cache.splitlines() if line.startswith((
        'CMAKE_BUILD_TYPE:', 'CMAKE_CXX_COMPILER:', 'HYLE_STATIC:', 'MLX_BUILD_CPU:',
        'MLX_BUILD_METAL:', 'MLX_BUILD_CUDA:', 'MLX_METAL_JIT:', 'HYLE_COMPUTE_APPLE:'))],
    'source_checkout_commit': run('git', '-C', '/Users/kiro/hyle', 'rev-parse', 'HEAD'),
}
(work / 'qualification-facts.json').write_text(json.dumps(facts, indent=2) + '\n')
