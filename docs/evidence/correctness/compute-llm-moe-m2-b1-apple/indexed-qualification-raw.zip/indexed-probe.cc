#include <mlx/array.h>
#include <mlx/compile.h>
#include <mlx/ops.h>
#include <mlx/stream.h>
#include <mlx/transforms.h>
#include <algorithm>
#include <array>
#include <climits>
#include <cmath>
#include <cstdint>
#include <cstring>
#include <iostream>
#include <limits>
#include <numeric>
#include <stdexcept>
#include <vector>

namespace mx = mlx::core;
mx::Stream stream() { return mx::default_stream(mx::Device::gpu); }
template<class T> std::vector<T> host(mx::array a) {
  a = mx::contiguous(a, false, stream());
  mx::eval(a);
  mx::synchronize(stream());
  const auto *p = a.data<T>();
  return {p, p + a.size()};
}
std::vector<std::uint64_t> bits(mx::array a) {
  a = mx::contiguous(a, false, stream()); mx::eval(a); mx::synchronize(stream());
  std::vector<std::uint64_t> out(a.size(), 0);
  for (std::size_t i=0; i<out.size(); ++i)
    std::memcpy(&out[i], reinterpret_cast<const char*>(a.data<void>()) + i*a.itemsize(), a.itemsize());
  return out;
}
void require(bool good, const char *reason) { if (!good) throw std::runtime_error(reason); }

int scan_cases() {
  int count=0;
  for (bool exclusive : {false,true}) {
    auto fn=mx::compile([exclusive](const std::vector<mx::array>& x) {
      auto s=stream();
      auto prefix=mx::cumsum(x[0], 1, false, true, mx::int64, s);
      auto invalid=mx::any(mx::logical_or(mx::less(prefix,mx::array(std::int64_t{INT32_MIN}),s),
                                           mx::greater(prefix,mx::array(std::int64_t{INT32_MAX}),s),s),s);
      auto output=prefix;
      if(exclusive) output=mx::concatenate({mx::zeros({2,1},mx::int64,s),
          mx::slice(prefix,{0,0},{2,prefix.shape(1)-1},s)},1,s);
      return std::vector<mx::array>{mx::astype(output,mx::int32,s),
          mx::where(invalid,mx::array(2),mx::array(0),s), prefix};
    });
    for (int width : {3,17,8193}) for (int pattern=0; pattern<3; ++pattern) {
      std::vector<std::int32_t> values(width*2);
      for(int i=0;i<width;++i) for(int row=0;row<2;++row)
        values[i*2+row]=i%3-1;
      if(pattern) { values[0]=pattern==1?INT32_MAX:INT32_MIN; values[2]=pattern==1?1:-1; }
      auto input=mx::transpose(mx::array(values.data(),{width,2},mx::int32),{1,0},stream());
      const auto logical=host<std::int32_t>(input);
      auto outputs=fn({input}); const auto prefix=host<std::int64_t>(outputs[2]);
      bool bad=false;
      for(int row=0;row<2;++row) {
        std::int64_t total=0;
        for(int i=0;i<width;++i) {
          total+=logical[row*width+i];
          require(prefix[row*width+i]==total,"scan widened prefix differs");
          bad|=total<INT32_MIN || total>INT32_MAX;
        }
      }
      require(host<std::int32_t>(outputs[1])[0]==(bad?2:0),"scan status differs");
      if(!bad) {
        const auto actual=host<std::int32_t>(outputs[0]);
        for(int row=0;row<2;++row) for(int i=0;i<width;++i)
          require(actual[row*width+i]==(exclusive?(i?prefix[row*width+i-1]:0):prefix[row*width+i]),"scan result differs");
      }
      ++count;
    }
  }
  const auto f=mx::array({1.5F,-2.F,.25F,3.F});
  require(host<float>(mx::cumsum(f,0,false,true,stream()))==std::vector<float>({1.5F,-.5F,-.25F,2.75F}),"float scan differs");
  return count+1;
}

int sort_cases() {
  int count=0;
  for(auto dtype:{mx::float32,mx::float16,mx::bfloat16,mx::int32})
    for(bool largest:{false,true}) for(int width:{17,129,4097}) {
      auto fn=mx::compile([largest,width](const std::vector<mx::array>& x) {
        auto s=stream();
        auto keys=mx::astype(x[0],x[0].dtype()==mx::int32?mx::int64:mx::float32,s);
        if(largest) keys=mx::negative(keys,s);
        auto order=mx::argsort(keys,1,s);
        return std::vector<mx::array>{mx::take_along_axis(x[0],order,1,s),mx::astype(order,mx::int32,s)};
      });
      for(int repeat=0;repeat<2;++repeat) {
        std::vector<float> data(width*2);
        for(std::size_t i=0;i<data.size();++i) data[i]=float(int((i*3+repeat)%13)-6);
        const std::array special={std::numeric_limits<float>::quiet_NaN(),0.F,-0.F,
            std::numeric_limits<float>::infinity(),-std::numeric_limits<float>::infinity(),3.F,3.F};
        if(dtype!=mx::int32) std::copy(special.begin(),special.end(),data.begin());
        mx::array input=mx::astype(mx::array(data.data(),{2,width},mx::float32),dtype,stream());
        if(dtype==mx::int32) {
          std::vector<std::int32_t> integers(data.begin(),data.end());
          integers[0]=INT32_MIN; integers[1]=INT32_MAX; integers[2]=16777217; integers[3]=16777216;
          input=mx::array(integers.data(),{2,width},mx::int32);
        }
        const auto raw=bits(input); std::vector<double> numbers;
        if(dtype==mx::int32) { auto values=host<std::int32_t>(input); numbers.assign(values.begin(),values.end()); }
        else { auto values=host<float>(mx::astype(input,mx::float32,stream())); numbers.assign(values.begin(),values.end()); }
        const auto outputs=fn({input}); const auto actual=bits(outputs[0]); const auto indices=host<std::int32_t>(outputs[1]);
        for(int row=0;row<2;++row) {
          std::vector<int> expected(width); std::iota(expected.begin(),expected.end(),0);
          std::stable_sort(expected.begin(),expected.end(),[&](int a,int b){
            double x=numbers[row*width+a], y=numbers[row*width+b];
            if(std::isnan(x)) return false; if(std::isnan(y)) return true;
            return largest?x>y:x<y;
          });
          for(int i=0;i<width;++i) {
            require(indices[row*width+i]==expected[i],"original stable argsort index differs");
            require(actual[row*width+i]==raw[row*width+expected[i]],"original gather sorted bits differ");
          }
        }
        ++count;
      }
    }
  return count;
}

int gather_cases() {
  int count=0;
  for(auto dtype:{mx::float32,mx::float16,mx::bfloat16,mx::int32,mx::int64,mx::bool_})
    for(auto index_type:{mx::int32,mx::int64}) {
      auto fn=mx::compile([](const std::vector<mx::array>& x){
        auto s=stream();
        auto bad=mx::logical_or(mx::less(x[1],mx::array(std::int64_t{0}),s),
            mx::greater_equal(x[1],mx::array(std::int64_t{7}),s),s);
        auto safe=mx::where(bad,mx::array(0,x[1].dtype()),x[1],s);
        return std::vector<mx::array>{mx::take(x[0],safe,1,s),
            mx::where(mx::any(bad,s),mx::array(1),mx::array(0),s)};
      });
      std::vector<std::int64_t> data(42); std::iota(data.begin(),data.end(),-17);
      auto source=mx::transpose(mx::astype(mx::array(data.data(),{7,2,3},mx::int64),dtype,stream()),{1,0,2},stream());
      const auto raw=bits(source);
      const std::int64_t maximum=index_type==mx::int64?INT64_MAX:INT32_MAX;
      for(std::int64_t last:{std::int64_t{3},std::int64_t{-1},std::int64_t{7},maximum,std::int64_t{0}}) {
        const std::array<std::int64_t,4> ids={6,0,6,last};
        auto indices=mx::astype(mx::array(ids.data(),{2,2},mx::int64),index_type,stream());
        auto out=fn({source,indices}); const bool invalid=last<0||last>=7;
        require(host<std::int32_t>(out[1])[0]==(invalid?1:0),"gather status differs");
        const auto actual=bits(out[0]);
        for(int row=0;row<2;++row) for(int i=0;i<4;++i) for(int lane=0;lane<3;++lane) {
          const auto id=ids[i]<0||ids[i]>=7?0:ids[i];
          require(actual[(row*4+i)*3+lane]==raw[(row*7+id)*3+lane],"original gather bits differ");
        }
        ++count;
      }
    }
  return count;
}
int main() try {
  const auto scans=scan_cases(); std::cout<<"scan PASS "<<scans<<std::endl;
  const auto sorts=sort_cases(); std::cout<<"sort PASS "<<sorts<<std::endl;
  const auto gathers=gather_cases(); std::cout<<"gather PASS "<<gathers<<std::endl;
  std::cout<<"PASS "<<scans+sorts+gathers<<" original MLX GPU compiled qualification cases; no HYLE math or timing"<<std::endl;
} catch(const std::exception& error) { std::cerr<<"FAIL "<<error.what()<<std::endl; return 1; }
