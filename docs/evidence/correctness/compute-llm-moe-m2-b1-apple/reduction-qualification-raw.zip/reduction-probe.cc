#include <mlx/array.h>
#include <mlx/compile.h>
#include <mlx/ops.h>
#include <mlx/stream.h>
#include <mlx/transforms.h>
#include <algorithm>
#include <bit>
#include <cmath>
#include <cstdint>
#include <iostream>
#include <limits>
#include <numeric>
#include <stdexcept>
#include <vector>

namespace mx = mlx::core;
mx::Stream stream() { return mx::default_stream(mx::Device::gpu); }
constexpr float inf = std::numeric_limits<float>::infinity();
constexpr float qnan = std::numeric_limits<float>::quiet_NaN();
void require(bool good, const char* why) { if (!good) throw std::runtime_error(why); }
std::vector<float> host(mx::array a) {
  a = mx::contiguous(mx::astype(a, mx::float32, stream()), false, stream());
  mx::eval(a); mx::synchronize(stream());
  if (!a.size()) return {};
  return {a.data<float>(), a.data<float>() + a.size()};
}
std::size_t count(const mx::Shape& shape) {
  return std::accumulate(shape.begin(), shape.end(), std::size_t{1}, std::multiplies<>{});
}
void check(const mx::array& actual, const std::vector<double>& expected, bool signs=false) {
  auto values = host(actual);
  require(values.size() == expected.size(), "shape size differs");
  const double rel = actual.dtype() == mx::float32 ? 3e-5 : actual.dtype() == mx::float16 ? 0.002 : 0.012;
  for (std::size_t i=0; i<values.size(); ++i) {
    bool good = std::isnan(expected[i]) ? std::isnan(values[i])
              : std::isinf(expected[i]) ? values[i] == expected[i]
              : std::abs(values[i]-expected[i]) <= rel * std::abs(expected[i]) + 3e-6;
    if (signs && expected[i] == 0) good &= std::signbit(values[i]) == std::signbit(expected[i]);
    if (!good) { std::cerr << "at " << i << " expected " << expected[i] << " got " << values[i] << '\n'; }
    require(good, "independent numerical oracle mismatch");
  }
}
mx::Shape reduced_shape(const mx::Shape& shape, const std::vector<int>& axes, bool keep) {
  mx::Shape out;
  for(int i=0; i<static_cast<int>(shape.size()); ++i)
    if (std::find(axes.begin(),axes.end(),i)==axes.end()) out.push_back(shape[i]);
    else if (keep) out.push_back(1);
  return out;
}
mx::array original_reduce(const mx::array& input, const std::vector<int>& axes, bool keep, int kind, bool repair) {
  auto s=stream(); auto shape=reduced_shape(input.shape(),axes,keep);
  if(!count(shape)) return mx::zeros(shape,input.dtype(),s);
  if(!input.size()) return mx::full(shape, kind==0?0.F:kind==1?qnan:kind==2?inf:-inf,input.dtype(),s);
  auto x=mx::astype(input,mx::float32,s);
  auto value=kind==0?mx::sum(x,axes,keep,s):kind==1?mx::mean(x,axes,keep,s)
               :kind==2?mx::min(x,axes,keep,s):mx::max(x,axes,keep,s);
  if(repair && kind>=2) {
    auto raw=mx::view(x,mx::uint32,s);
    auto wanted_zero=mx::equal(raw,mx::array(kind==2?0x80000000U:0U),s);
    auto has_zero=mx::any(wanted_zero,axes,keep,s);
    auto zero_bits=kind==2?mx::where(has_zero,mx::array(0x80000000U),mx::array(0U),s)
                         :mx::where(has_zero,mx::array(0U),mx::array(0x80000000U),s);
    value=mx::where(mx::equal(value,mx::array(0.F),s),mx::view(zero_bits,mx::float32,s),value,s);
    value=mx::where(mx::any(mx::isnan(x,s),axes,keep,s),mx::array(qnan),value,s);
  }
  return mx::astype(value,input.dtype(),s);
}
std::vector<double> reduction_oracle(const mx::array& x,const std::vector<int>& axes,bool keep,int kind) {
  auto data=host(x); auto shape=reduced_shape(x.shape(),axes,keep);
  std::vector<double> out(count(shape),kind==2?inf:kind==3?-inf:0);
  std::vector<std::size_t> sizes(out.size());
  for(std::size_t i=0;i<data.size();++i) {
    auto remaining=i; std::size_t target=0,stride=1;
    for(int dim=static_cast<int>(x.ndim())-1;dim>=0;--dim) {
      auto coordinate=remaining % x.shape(dim); remaining/=x.shape(dim);
      if(std::find(axes.begin(),axes.end(),dim)==axes.end()) {target+=coordinate*stride;stride*=x.shape(dim);}
    }
    auto v=data[i]; ++sizes[target];
    if(std::isnan(v)) out[target]=qnan;
    else if(kind<2) out[target]+=v;
    else if(!std::isnan(out[target])) {
      if(kind==2) {if(v<out[target] || (v==0 && out[target]==0 && std::signbit(v))) out[target]=v;}
      else {if(v>out[target] || (v==0 && out[target]==0 && !std::signbit(v))) out[target]=v;}
    }
  }
  if(kind==1) for(std::size_t i=0;i<out.size();++i) out[i]=sizes[i]?out[i]/sizes[i]:qnan;
  return out;
}
int reduction_cases() {
  int cases=0;
  for(auto dtype:{mx::float32,mx::float16,mx::bfloat16}) {
    for(auto shape:{mx::Shape{3,129},mx::Shape{2,17,3},mx::Shape{1,2,1,3,1,17,1,1},
                    mx::Shape{2,0,3},mx::Shape{0,17},mx::Shape{},mx::Shape{1,1}}) {
      std::vector<float> data(count(shape));
      for(std::size_t i=0;i<data.size();++i) data[i]=1.F+float(int(i%13)-6)*0.03125F;
      auto x=mx::astype(mx::array(data.data(),shape,mx::float32),dtype,stream());
      if(shape==mx::Shape{2,17,3}) x=mx::transpose(mx::reshape(x,{17,2,3},stream()),{1,0,2},stream());
      std::vector<int> axes;
      if(shape.size()==3) axes=shape[1]==0?std::vector{1}:std::vector{0,2};
      else if(shape.size()==8) axes={1,3,5};
      else if(!shape.empty()) axes={static_cast<int>(shape.size())-1};
      for(bool keep:{false,true}) for(int kind=0;kind<4;++kind) {
        auto fn=mx::compile([=](const std::vector<mx::array>& in){return std::vector{original_reduce(in[0],axes,keep,kind,true)};});
        auto output=fn({x})[0]; require(output.shape()==reduced_shape(shape,axes,keep),"reduce shape differs");
        check(output,reduction_oracle(x,axes,keep,kind),kind>=2); ++cases;
      }
    }
    std::vector<float> specials{0.F,-0.F,0.F, 0.F,-0.F,-0.F, 1.F,qnan,3.F, inf,-inf,1.F,
                                -0.F,-0.F,-0.F, 0.F,0.F,0.F};
    auto x=mx::astype(mx::array(specials.data(),{6,3},mx::float32),dtype,stream());
    for(int kind:{2,3}) {
      auto plain=mx::compile([=](const std::vector<mx::array>& in){return std::vector{original_reduce(in[0],{1},false,kind,false)};});
      auto observed=host(plain({x})[0]);
      std::cout<<"plain original reduction dtype="<<dtype<<" kind="<<kind<<" bits=";
      for(auto v:observed) std::cout<<std::hex<<std::bit_cast<std::uint32_t>(v)<<',';
      std::cout<<std::dec<<'\n';
      auto fixed=mx::compile([=](const std::vector<mx::array>& in){return std::vector{original_reduce(in[0],{1},false,kind,true)};});
      check(fixed({x})[0],reduction_oracle(x,{1},false,kind),true); ++cases;
    }
  }
  return cases;
}
mx::array original_probability(const std::vector<mx::array>& in,int axis,int mask,bool log,float scale) {
  auto s=stream(); if(!in[0].size()) return mx::zeros(in[0].shape(),in[0].dtype(),s);
  auto x=mx::multiply(mx::astype(in[0],mx::float32,s),mx::array(scale),s);
  if(mask==1) x=mx::where(in[1],x,mx::array(-inf),s);
  if(mask==2) x=mx::add(x,mx::astype(in[1],mx::float32,s),s);
  auto y=x;
  if(log) {auto shifted=mx::subtract(x,mx::max(x,axis,true,s),s);y=mx::subtract(shifted,mx::logsumexp(shifted,axis,true,s),s);}
  else y=mx::softmax(x,axis,true,s);
  return mx::astype(y,in[0].dtype(),s);
}
std::vector<double> probability_oracle(const mx::array& input,int axis,int mode,const mx::array& mask,bool log,float scale) {
  const auto data=host(input),m=host(mask); std::vector<double> out(data.size());
  const auto width=input.shape(axis); std::size_t inner=1;
  for(std::size_t i=axis+1;i<input.ndim();++i) inner*=input.shape(i);
  if(data.empty()) return out;
  for(std::size_t outer=0;outer<data.size()/width/inner;++outer) for(std::size_t lane=0;lane<inner;++lane) {
    std::vector<double> row(width); double max=-inf;bool bad=false;
    for(int j=0;j<width;++j) {
      float v=data[(outer*width+j)*inner+lane]*scale;
      if(mode==1 && m[j]==0) v=-inf;
      if(mode==2) v+=m[j];
      row[j]=v; bad|=std::isnan(v)||v==inf;max=std::max(max,row[j]);
    }
    bad|=!std::isfinite(max);double total=0;
    for(auto v:row) total+=std::exp(v-max);
    for(int j=0;j<width;++j) out[(outer*width+j)*inner+lane]=bad?qnan:log?row[j]-max-std::log(total):std::exp(row[j]-max)/total;
  }
  return out;
}
int probability_cases() {
  int cases=0;
  for(auto dtype:{mx::float32,mx::float16,mx::bfloat16}) {
    for(int width:{0,1,17,129,2048,8193}) for(bool last:{false,true}) {
      std::vector<float> data(6*width);for(std::size_t i=0;i<data.size();++i) data[i]=float(int(i%29)-14)*0.2F;
      auto x=mx::astype(mx::array(data.data(),{width,2,3},mx::float32),dtype,stream());
      x=mx::transpose(x,last?std::vector{1,2,0}:std::vector{1,0,2},stream());int axis=last?2:1;
      for(int mode=0;mode<3;++mode) {
        std::vector<float> m(width);for(int j=0;j<width;++j) m[j]=mode==1?float(j%3!=1):j%3!=1?float(j%7)*0.3F:-inf;
        auto mask=mx::astype(mx::array(m.data(),last?mx::Shape{width}:mx::Shape{1,width,1},mx::float32),mode==1?mx::bool_:dtype,stream());
        for(bool log:{false,true}) {
          auto fn=mx::compile([=](const std::vector<mx::array>& in){return std::vector{original_probability(in,axis,mode,log,-0.7F)};});
          check(fn({x,mask})[0],probability_oracle(x,axis,mode,mask,log,-0.7F));++cases;
        }
      }
    }
    const std::vector<float> special{qnan,1,2,-inf,4, 0,inf,2,3,4, -inf,-inf,-inf,-inf,-inf, 0,1,qnan,3,4};
    auto x=mx::astype(mx::array(special.data(),{4,5},mx::float32),dtype,stream());
    for(auto m:{std::vector<float>{0,1,1,1,1},std::vector<float>{0,0,0,0,0},std::vector<float>{1,1,1,1,1}}) {
      auto mask=mx::astype(mx::array(m.data(),{5},mx::float32),mx::bool_,stream());
      for(bool log:{false,true}) {
        auto fn=mx::compile([=](const std::vector<mx::array>& in){return std::vector{original_probability(in,1,1,log,1.F)};});
        check(fn({x,mask})[0],probability_oracle(x,1,1,mask,log,1.F));++cases;
      }
    }
  }
  auto fn=mx::compile([](const std::vector<mx::array>& in){return std::vector{original_probability(in,1,0,true,1.F)};});
  check(fn({mx::full({1,4},1e8F,mx::float32,stream())})[0],std::vector<double>(4,-std::log(4.0)));++cases;
  return cases;
}
int main() try {
  auto reductions=reduction_cases();std::cout<<"PASS "<<reductions<<" original MLX reduction compositions"<<std::endl;
  auto probabilities=probability_cases();std::cout<<"PASS "<<probabilities<<" original MLX softmax/logsoftmax compositions"<<std::endl;
  std::cout<<"PASS total "<<reductions+probabilities<<"; independent scalar oracles; no HYLE math or timing"<<std::endl;
} catch(const std::exception& e) {std::cerr<<"FAIL "<<e.what()<<std::endl;return 1;}
