#!/bin/bash
set -euo pipefail
export PATH="/Users/kiro/hyle-verify-tools/metal-17F109/shim:/opt/homebrew/bin:$PATH"
work=/Users/kiro/hyle-m2b1-apple
mlx=/Users/kiro/Library/Caches/hyle/dependencies/v1/sources/mlx-1f8e74e3f12f-95caa530dd41
/Library/Developer/CommandLineTools/usr/bin/clang++ -std=c++20 -O2 \
  -isysroot "$(/usr/bin/xcrun --sdk macosx --show-sdk-path)" -I "$mlx" \
  "$work/reduction-probe.cc" -L "$work/build/bin" -lmlx \
  -Wl,-rpath,"$work/build/bin" -o "$work/reduction-probe"
"$work/reduction-probe"
shasum -a 256 "$work/reduction-probe" "$mlx/mlx/ops.cpp" \
  "$mlx/python/mlx/nn/layers/activations.py" "$work/build/bin/libmlx.dylib"
