import json
from pathlib import Path
import subprocess

root = Path('/Users/kiro/hyle-m2b1-apple').resolve()
checkout = Path('/Users/kiro/hyle').resolve()
assert root == Path('/Users/kiro/hyle-m2b1-apple')
assert checkout == Path('/Users/kiro/hyle')
assert (root / '.hyle-owner').read_text().strip() == 'M2-B1 Apple validation; Windows canonical; /root'
def git(*args): return subprocess.check_output(['git', '-C', str(checkout), *args], text=True).strip()
expected = 'b94a091a7a577d30df5bce327b9755258220b941'
assert git('write-tree') == expected and git('diff', '--name-only') == ''
git('fetch', 'origin', 'main')
assert git('rev-parse', '6724165e^{tree}') == expected
git('reset', '--hard', '6724165e')
assert git('status', '--porcelain') == ''
archive = root / 'indexed-source.tar.gz'
assert archive.is_file() and not archive.is_symlink() and archive.resolve().parent == root
receipt = {'removed': str(archive), 'bytes': archive.stat().st_size,
           'validation_checkout': git('rev-parse', 'HEAD'), 'tree': expected}
archive.unlink()
(root / 'cast-cleanup-air.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt))
