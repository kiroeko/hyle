$ErrorActionPreference = 'Stop'
$workspacePath = 'C:\public\project-hyle\hyle'
$archivePath = [System.IO.Path]::GetFullPath((Join-Path $workspacePath '.scratch\validation\m2-b1-apple\indexed-source.tar.gz'))
$scratchPath = [System.IO.Path]::GetFullPath((Join-Path $workspacePath '.scratch\validation\m2-b1-apple'))
$removed = @()
if (Test-Path -LiteralPath $archivePath) {
    $resolved = (Resolve-Path -LiteralPath $archivePath).Path
    if ([System.IO.Path]::GetDirectoryName($resolved) -ne $scratchPath) { throw 'Unexpected archive path' }
    $removed += [pscustomobject]@{ path = $resolved; bytes = (Get-Item -LiteralPath $resolved).Length }
    Remove-Item -LiteralPath $resolved -Force
}
$buildPath = 'C:\hv\m2b1-apple-off'
if (Test-Path -LiteralPath $buildPath) {
    $resolved = (Resolve-Path -LiteralPath $buildPath).Path
    if ($resolved -ne $buildPath -or [System.IO.Path]::GetDirectoryName($resolved) -ne 'C:\hv') { throw 'Unexpected build path' }
    if ((Get-Content -LiteralPath (Join-Path $resolved '.hyle-owner') -Raw).Trim() -ne 'M2-B1 Apple OFF validation /root') { throw 'Unexpected build owner' }
    $bytes = (Get-ChildItem -LiteralPath $resolved -File -Recurse -Force | Measure-Object -Property Length -Sum).Sum
    $removed += [pscustomobject]@{ path = $resolved; bytes = $bytes }
    Remove-Item -LiteralPath $resolved -Recurse -Force
}
$removed | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $scratchPath 'cast-cleanup-windows.json')
$removed | ConvertTo-Json
