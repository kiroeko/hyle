#include <mlx/array.h>
#include <mlx/compile.h>
#include <mlx/ops.h>
#include <mlx/transforms.h>
#include <array>
#include <cstdint>
#include <cstring>
#include <iomanip>
#include <iostream>
#include <stdexcept>
#include <vector>

namespace mx = mlx::core;

int main() try {
  const auto stream = mx::default_stream(mx::Device::gpu);
  constexpr std::array<std::uint32_t, 20> input_bits{
      0, 0x80000000, 1, 0x7fff, 0x8000, 0x8001, 0x10000, 0x10001,
      0x7f0000, 0x7fffff, 0x800000, 0x800001, 0x807fffff, 0x80010000,
      0x3f800000, 0x3f808000, 0x3f818000, 0x7f800000, 0xff800000, 0x7fc00001};
  constexpr std::array<std::uint16_t, 20> expected_bits{
      0, 0x8000, 0, 0, 0, 1, 1, 1, 0x7f, 0x80, 0x80, 0x80, 0x8080,
      0x8001, 0x3f80, 0x3f80, 0x3f82, 0x7f80, 0xff80, 0x7fc0};
  auto input = mx::view(mx::array(input_bits.data(), {20}, mx::uint32), mx::float32, stream);
  mx::eval(input);
  mx::synchronize(stream);
  if (std::memcmp(input.data<void>(), input_bits.data(), sizeof(input_bits)))
    throw std::runtime_error("input bit patterns changed before cast");
  auto original = [=](const std::vector<mx::array>& values) {
    return std::vector<mx::array>{mx::astype(values[0], mx::bfloat16, stream)};
  };
  auto compiled = mx::compile(original);
  int total_mismatches = 0;
  for (bool use_compiled : {false, true}) {
    auto output = (use_compiled ? compiled({input}) : original({input}))[0];
    mx::eval(output);
    mx::synchronize(stream);
    std::array<std::uint16_t, 20> observed{};
    std::memcpy(observed.data(), output.data<void>(), sizeof(observed));
    int mismatches = 0;
    for (std::size_t i = 0; i < input_bits.size(); ++i) {
      const bool nan_case = i == input_bits.size() - 1;
      const bool match = nan_case ? ((observed[i] & 0x7f80) == 0x7f80 &&
                                    (observed[i] & 0x7f) != 0)
                                  : observed[i] == expected_bits[i];
      mismatches += !match;
      std::cout << (use_compiled ? "compiled" : "eager") << " input=0x"
                << std::hex << input_bits[i] << " observed=0x" << observed[i]
                << " expected=0x" << expected_bits[i] << std::dec
                << " match=" << match << '\n';
    }
    total_mismatches += mismatches;
    std::cout << "mode=" << (use_compiled ? "compiled" : "eager")
              << " cases=" << input_bits.size() << " mismatches=" << mismatches << '\n';
  }
  return total_mismatches == 0 ? 0 : 2;
} catch (const std::exception& error) {
  std::cerr << error.what() << '\n';
  return 3;
}
