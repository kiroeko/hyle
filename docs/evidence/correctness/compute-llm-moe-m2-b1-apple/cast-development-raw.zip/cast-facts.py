import hashlib
import json
from pathlib import Path
import subprocess

root = Path('/Users/kiro/hyle')
work = Path('/Users/kiro/hyle-m2b1-apple')
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def run(*args): return subprocess.check_output(args, text=True).strip()
sources = run('git', '-C', str(root), 'diff', '--cached', '--name-only').splitlines()
facts = {
    'machine_model': run('/usr/sbin/sysctl', '-n', 'hw.model'),
    'os': run('/usr/bin/sw_vers'),
    'compiler': run('/Library/Developer/CommandLineTools/usr/bin/clang++', '--version'),
    'source_checkout_commit': run('git', '-C', str(root), 'rev-parse', 'HEAD'),
    'canonical_validation_tree': run('git', '-C', str(root), 'write-tree'),
    'unstaged_changes': run('git', '-C', str(root), 'diff', '--name-only'),
    'source_sha256': {name: sha(root / name) for name in sources},
    'artifact_sha256': {name: sha(work / 'build/bin' / name) for name in [
        'libhyle_compute_route_apple.dylib', 'libhyle_graph_route_apple.dylib',
        'libmlx.dylib', 'hyle_compute_route_apple_test', 'hyle_graph_route_apple_test']},
    'configuration': [line for line in (work / 'build/CMakeCache.txt').read_text(encoding='utf-8').splitlines() if line.startswith((
        'CMAKE_BUILD_TYPE:', 'CMAKE_CXX_COMPILER:', 'HYLE_STATIC:', 'MLX_BUILD_CPU:',
        'MLX_BUILD_METAL:', 'MLX_BUILD_CUDA:', 'MLX_METAL_JIT:', 'HYLE_COMPUTE_APPLE:',
        'CMAKE_OSX_DEPLOYMENT_TARGET:', 'HYLE_WERROR:'))],
}
assert facts['canonical_validation_tree'] == 'b94a091a7a577d30df5bce327b9755258220b941'
assert facts['unstaged_changes'] == ''
(work / 'cast-facts.json').write_text(json.dumps(facts, indent=2) + '\n', encoding='utf-8')
(work / 'cast-native-last-test.log').write_bytes((work / 'build/Testing/Temporary/LastTest.log').read_bytes())
print('Recorded', facts['machine_model'], facts['canonical_validation_tree'])
