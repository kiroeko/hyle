from pathlib import Path
import importlib.util,json,os,sys
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent;R=S.parents[1]
spec=importlib.util.spec_from_file_location('old',S/'build.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
T=R/'.scratch/glm-k2-state-20261024'
def build(kind,attempt):
 out=T/kind/f'attempt{attempt}';out.mkdir(parents=True,exist_ok=False)
 name='glm_pro_mtp_state_consumer_test.cc' if kind=='pro' else 'glm_mtp_state_consumer_test.cc';src=R/'tests/compute_models'/name
 recipe=R/'.scratch/glm-quantized-random-20261024'/('B09' if kind=='pro' else 'Q30')/'compile/command.json'
 command=[];skip=False
 for flag in m.read(recipe)['command']:
  if skip:skip=False;continue
  if flag=='/sourceDependencies':skip=True;continue
  if flag.startswith(('/Fo','/Fd')) or flag.endswith(name):continue
  command.append(flag)
 command+=['/sourceDependencies',str(out/'deps.json'),str(src),'/Fo'+str(out/'consumer.obj')]
 env=m.discover_environment(compiler='msvc',cache={'CMAKE_C_COMPILER':command[0],'CMAKE_CXX_COMPILER':command[0],'CMAKE_GENERATOR':'Ninja'},backends=()).env
 before=m.ident(src);m.b.execute(command,env,out/'compile',timeout=240);assert m.ident(src)==before
 deps=[m.ident(p) for p in m.read(out/'deps.json')['Data']['Includes']];m.save(out/'source-identity.json',dict(source=before,object=m.ident(out/'consumer.obj'),dependencies=deps))
 # Freeze only this consumer and its application/test-private inline helpers.
 records=[before]+[row for row in deps if Path(row['path']).is_relative_to(R/'tests/compute_models') or Path(row['path']).is_relative_to(R/'engine/inference')]
 for row in records:
  source=Path(row['path']);target=out/'source'/source.relative_to(R);target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(source.read_bytes());assert m.ident(source)==row
 m.save(out/'source-records.json',records)
 base=m.read(R/'.scratch/dspark-random-mtp-20261024/link-command.json');command=[x for x in base if not x.upper().startswith(('/OUT:','/IMPLIB:','/MAP:','/PDB:')) and not x.endswith('dspark-random-mtp-20261024\\consumer.obj')]
 command.insert(1,str(out/'consumer.obj'));command+=['/OUT:'+str(out/'checks.exe'),'/IMPLIB:'+str(out/'checks.lib')]
 m.save(out/'link-inputs.json',[m.ident(x) for x in command if x.lower().endswith(('.obj','.lib')) and Path(x).is_absolute()])
 m.b.execute(command,env,out/'link',timeout=120)
 dll=R/'.scratch/mtp-full-quant-20261024/f32-paged-check/attempt3/native-link/hyle_ggml_cpu_gdn_scale_v3.dll';os.link(dll,out/dll.name)
 m.save(out/'ready.json',dict(image=m.ident(out/'checks.exe'),consumer_TUs=1,SDK_TUs=0))
def run(kind,attempt,run_attempt=1):
 out=T/kind/f'attempt{attempt}';run=out/f'run{run_attempt}';assert not run.exists(),run
 source=m.read(S/'pro/run1-inputs.json' if kind=='pro' else S/'run1-inputs.json')
 env={k:v for k,v in os.environ.items() if not k.startswith('HYLE_GLM')};env.update(source)
 env.update(PATH=str(out)+';'+m.read(R/'.scratch/dspark-random-mtp-20261024/runtime.json')['PATH'],HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1')
 m.save(out/'run-inputs.json',{k:v for k,v in env.items() if k.startswith(('HYLE_GLM','HF_','TRANSFORMERS_'))})
 name='GlmProMtpStateConsumer.CudaOriginalTarget77AndNextNRandomK2PublishesCompletePrefixes' if kind=='pro' else 'GlmMtpStateConsumer.CudaOriginalTarget43And44AndNextNRandomK2PublishesCompletePrefixes'
 command=[str(out/'checks.exe'),'--gtest_filter='+name,'--gtest_output=xml:'+str(run/'results.xml')]
 m.b.execute(command,env,run,timeout=600)
if __name__=='__main__':
 import argparse
 p=argparse.ArgumentParser();p.add_argument('action',choices=['build','run']);p.add_argument('kind',choices=['flash','pro']);p.add_argument('--attempt',type=int,default=1);p.add_argument('--run-attempt',type=int,default=1);a=p.parse_args();build(a.kind,a.attempt) if a.action=='build' else run(a.kind,a.attempt,a.run_attempt)
