from pathlib import Path
import difflib,hashlib,json,re,subprocess,zipfile,xml.etree.ElementTree as ET

R=Path(__file__).resolve().parents[2];T=R/'.scratch/glm-k2-state-20261024'
E=R/'docs/evidence/correctness';name='mtp-glm-original-stochastic-k2-state-2026-10-24'
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def ident(p):return dict(path=str(p.relative_to(R)) if p.is_relative_to(R) else str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
cases=[];archive=[]
for kind in ('flash','pro'):
 out=T/kind/'attempt2';run=out/'run1';process=read(run/'process.json');assert process['exit']==0
 xml=ET.parse(run/'results.xml').getroot();assert xml.attrib['tests']=='1' and xml.attrib['failures']=='0' and xml.attrib['errors']=='0'
 log=(run/'stdout.log').read_text(errors='replace')
 lines=[line for line in log.splitlines() if re.match(r'GLM (?:PRO )?K2 (?:BOUNDARY|CONTINUED)',line)]
 assert len(lines)==7,(kind,lines)
 assert any('name=natural' in line and 'consumed_drafts=0' in line and 'draw=5' in line for line in lines)
 assert any('name=all_accepted_bonus' in line and 'consumed_drafts=2' in line for line in lines)
 assert any('name=accepted_second_EOS' in line and 'consumed_drafts=1' in line and 'stopped=1' in line for line in lines)
 frozen=read(out/'source-records.json');source=Path(frozen[0]['path'])
 before=out/'source'/source.relative_to(R);assert ident(before)['sha256']==frozen[0]['sha256']
 delta=''.join(difflib.unified_diff(before.read_text(encoding='utf-8').splitlines(True),source.read_text(encoding='utf-8').splitlines(True),fromfile='executed-frozen/'+source.name,tofile='canonical/'+source.name))
 (out/'canonical-after-run.diff').write_text(delta,encoding='utf-8')
 cases.append(dict(family=kind,result=xml.attrib,process=process,image=read(out/'ready.json'),source=frozen[0],properties={p.attrib['name']:p.attrib['value'] for p in xml.findall('.//property')},actual_transitions=lines,source_change_after_run='Flash only: three thin source-format wrapper signatures/calls now forward optional maximum_drafts=1; no executed official K2 math/control change. Pro unchanged. Shared helper gained only four explanatory admission comments and explicit standard/state-header includes. Final strict Flash TU syntax passed.' if kind=='flash' else 'Consumer unchanged after actual run; shared helper gained explanatory comments and explicit standard/state-header includes only.'))
 for folder in ('compile','link','run1','source'):
  for p in (out/folder).rglob('*'):
   if p.is_file() and p.suffix not in ('.obj','.exe','.dll','.lib','.pdb','.exp'):
    archive.append((p,str(p.relative_to(T))))
 for file in ('source-identity.json','source-records.json','link-inputs.json','ready.json','run-inputs.json','canonical-after-run.diff'):
  archive.append((out/file,str((out/file).relative_to(T))))
reader=R.parent/'sglang';commit=subprocess.check_output(['git','-C',str(reader),'rev-parse','HEAD'],text=True).strip()
assert commit=='234ccba7f625e12639e621044496bcc6197c3758'
reader_paths=['python/sglang/srt/models/glm5_next_nextn.py','python/sglang/srt/models/deepseek_nextn.py','python/sglang/srt/speculative/eagle_worker_v2.py','python/sglang/srt/layers/attention/index_topk_share.py']
reader_files=[ident(reader/p) for p in reader_paths]
syntax=T/'final-flash-syntax3';assert read(syntax/'compile/process.json')['exit']==0
result=dict(date='2026-10-24',status='PASS finite original-role CUDA GLM Flash and Pro K2 state journeys',
 source_identities=[dict(repository='zai-org/GLM-5.3-Flash',revision='eb9eb208eb0d988989d07a6a12d0fdeb5f52574a',target_tail_layers=[43,44],nextn_layer=45),dict(repository='zai-org/GLM-5.3',revision='aca966e4e02791568aa6a4ced368624b3d897f42',target_tail_layer=77,nextn_layer=78)],
 reader=dict(repository='sglang',commit=commit,files=reader_files,contract='No K1 prohibition. eagle_worker_v2:756..848 iterates NextN, increases positions and carries each actual hidden to the next forward. IndexTopKShareState keeps same-iteration selection/carry until iteration exit. One trained NextN layer does not limit proposals to one.'),
 implementation=[
  'Existing family consumers accept finite maximum_drafts=1 or2. Default K1 is retained. Flash Quark/MLX/GGUF thin wrappers forward the same option; Pro uses its existing Official/Converted Runtime template. This is component functionality, not a new whole-model GLM application.',
  'Second proposal is sampled from real recursive same-epoch NextN logits after consuming actual first proposal. Original target tails consume current/q0/q1 privately. Three actual final-normalized taps are projected together in one T3 original shared-head graph; actual T3 logits pass the established original-weight value reference.',
  'GLM fragment adapter calls the existing hyle::inference::sampling::speculative_prefix. No p/q/logit mutation, host ID reconstruction or replacement greedy selection. Actual q0/q1 distributions, proposals, residual/bonus and valid flags are bound by their real result leases.',
  'Prefix0 means after mandatory current, never pre-current base. Prefix1/2 replay accepted q0/q1 NextN from true target taps and preserve actual corresponding target states. Current+accepted nonterminal drafts is the committed consumed-row count. Same-epoch frozen index selections are unchanged during draft/verify/repair.',
  'Accepted journal slot0/1 is caught up sequentially only after expected-base publication seals the iteration. lag2 becomes1 then0 with original epoch provenance; only then fresh epoch8 consumes the actual residual/bonus. Unverified approximate second/third states are never published as repaired accepted state.',
  'Natural schedule is proposal0/proposal1/accept2/accept3/final4, atomic cursor+5. Independent bounded controlled accept addresses are searched using original distributions and KAT-qualified Philox/F64, are distinct, final=max+1 and commit maxused+1. They prove reachable branch state behavior, not natural acceptance rate.',
  'Caller admits m2/T3 only for quota/context>=3 and non-EOS first proposal. Context/quota2 or first-proposal EOS uses existing m1/T2 three-draw path; context/quota1 is existing target-only p0 one draw with mandatory-current NextN maintenance. Public limits/acceptance mathematics and prior K1 tail proof are reused. No fixed five-draw claim for shorter episodes.',
  'Independent Heads reuse already retired authentic T3 state/ID leases to select quota1/2/3 and second-proposal EOS. Accepted terminal/unemitted proposals remain pending in q0/q1 lease and are not consumed. Cancellation after staged pending+cursor and wrong-type replacement, stale expected-base rejection and same-decision retry leave old Head/RNG intact.'
 ],cases=cases,
 verification=dict(consumer_compile_attempts=2,consumer_TUs_per_family_per_attempt=1,all_compile_link_exit0=True,SDK_TUs=0,HTTP_bytes=0,new_model_payload_bytes=0,actual_original_source_frontier_missing=0,final_canonical_flash_syntax=read(syntax/'compile/process.json'),canonical_deltas='Three Flash wrapper option-forwarding pairs plus four shared-helper admission comments and explicit dependency includes after frozen actual-run source; no executed graph/state/RNG math changes. /Zs /W4 /WX checks all final Flash entry definitions.'),
 limitations=[
  'Finite original tail-layer/NextN components use explicit generated upstream activations/residual token adapter, initial histories and Pro upstream index fixture. This is not complete GLM generation, task quality, throughput, physical-memory peak, all publishers or all backends.',
  'Actual executions are one Flash and one Pro CUDA source journey. Shared paths are instantiated by both CPU/CUDA compile gates; CPU K2 was not additionally run. Selected quantized wrappers expose the option and compile, not every quantized K2 bank rerun.',
  'Natural two-proposal episodes both rejected first proposal. Accepted prefix1/2 and bonus continuations use explicit legal controlled RNG addresses and unmodified real distributions, separately labelled in raw logs.',
  'K2 is the finite component capacity of this patch; it does not introduce an unbounded speculation tree. Existing complete Qwen K2/K4 and generic arbitrary-prefix mathematics are separate evidence.',
  'Final syntax wrapper initially reused an already-created scratch output directory and did not invoke the compiler; corrected separate compile output then passed. Model runs and source images were never overwritten.'
 ],prior_evidence=['docs/evidence/correctness/mtp-glm-stochastic-output-boundaries-2026-10-24.json','docs/evidence/correctness/mtp-glm-original-stochastic-state-2026-10-24.json'])
for p in syntax.rglob('*'):
 if p.is_file():archive.append((p,str(p.relative_to(T))))
for file in ('build-k2.py','k2-final-syntax.py','publish-k2.py'):
 p=Path(__file__).parent/file;archive.append((p,'scripts/'+file))
for file in ('glm_mtp_state_consumer_test.cc','glm_pro_mtp_state_consumer_test.cc','glm_stochastic_prefix_fragment.h'):
 p=R/'tests/compute_models'/file;archive.append((p,'canonical/tests/compute_models/'+file))
for relative in reader_paths:archive.append((reader/relative,'reader/'+relative))
zip_path=E/(name+'.zip')
with zipfile.ZipFile(zip_path,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p,arc in archive:z.write(p,arc)
with zipfile.ZipFile(zip_path) as z:assert z.testzip() is None;count=len(z.namelist())
result['archive']=ident(zip_path)|dict(entries=count,includes='Frozen compiled sources/private headers, commands/dependency identities, full raw logs/XML, source inputs and current narrow source delta; no weights/SDK/EXE/DLL/OBJ.')
(E/(name+'.json')).write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
print(json.dumps(dict(evidence=str(E/(name+'.json')),archive=result['archive']),indent=2))
