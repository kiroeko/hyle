from pathlib import Path
import importlib.util,sys
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('build',S/'build.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
R=m.R;out=R/'.scratch/glm-k2-state-20261024/final-flash-syntax3'
out.mkdir(exist_ok=False)
old=m.read(R/'.scratch/glm-k2-state-20261024/flash/attempt2/compile/command.json')['command']
command=[];skip=False
for flag in old:
 if skip:skip=False;continue
 if flag=='/sourceDependencies':skip=True;continue
 if flag.startswith(('/Fo','/Fd')):continue
 command.append(flag)
command+=['/Zs']
env=m.discover_environment(compiler='msvc',cache={'CMAKE_C_COMPILER':command[0],'CMAKE_CXX_COMPILER':command[0],'CMAKE_GENERATOR':'Ninja'},backends=()).env
files=[R/'tests/compute_models'/name for name in ('glm_mtp_state_consumer_test.cc','glm_pro_mtp_state_consumer_test.cc','glm_stochastic_prefix_fragment.h')]
before=[m.ident(p) for p in files]
m.b.execute(command,env,out/'compile',timeout=180)
assert before==[m.ident(p) for p in files]
m.save(out/'source-identities.json',before)
