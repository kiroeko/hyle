from pathlib import Path
import json

work=Path(__file__).resolve().parent
root=work.parents[1]
plan=json.loads((work/'design.json').read_text())
plan['files'] += [
    'tests/compute_models/glm_gguf_flash_reference.h: zero-score guard, independent actual pool/tail widths, published cursor ID bounds',
    'tests/compute_models/glm_flash_ordinary_startup_case.h: real13-resource StateStore/Head feedback for original layer43 sparse attention at positions0..4'
]
plan['files'][2]='tests/compute_models/glm_mtp_state_consumer_test.cc: official original FP8 graph and all official/MLX diagnostics use independent actual pool/tail lengths; includes host/startup cases'
plan['minimum_check_plan']=[
    'Root reviews six-file frozen source/pins. No compilation, execution or GPU has been performed by this branch.',
    'Stage only the one TU and its transitive project-header closure, preserving repository-relative paths, with these six private files overlaid. Quote includes from canonical nested headers otherwise bypass a plain /I override. Reuse all existing SDK/public build caches; no SDK or archive copy.',
    'Reuse the current130-absolute-input CPU link closure from inference-ordinary-boundaries-20261025/retirement-implementation/attempt2 plus the same cached GTest2 libraries and existing CPU native DLL; replace only its old app object with this one Flash consumer TU. Define HYLE_TEST_GLM_STATE_CPU=1; no CUDA or artifact-generated-header defines are required.',
    'One compile/link then one CPU invocation with filter GlmFlashOrdinaryEarlyHistoryPlan.*:GlmFlashOrdinaryEarlyHistory.CpuOriginalSparseStartsEmptyAndFeedsBackThroughFirstPool (3 host tests and1 actual sparse-component startup test). Existing host cases include mature2055 for all three original-codec branches; no additional native mature model test is proposed.',
    'Set only HYLE_GLM_MTP_TARGET43_DIR to the existing original layer43 static cache. The existing Data loaders check exact16 role hashes at execution; no implicit download or expert hook. Use the same already consumed CPU native DLL beside the executable if its loader requires application-directory lookup.',
    'Preserve compile/link/run command and raw logs plus sourcepins and a short result summary. Any compile/native failure is reported and repaired within this scope; no SDK/core rebuild, full model, GPU or extra matrix.'
]
plan['explicit_limits']=[
    'Host cases check supplied original physical descriptors and pure Graph composition, not publisher payload numerical execution.',
    'The startup native case is now implemented in private source but has not been built or run. It loads only authenticated original layer43 indexer/attention roles, accepts declared upstream BF16 NX/QR, feeds all13 state resources through one Head for5 real steps, and checks first4 rows form the first pool before publication.',
    'This is the ordinary sparse attention/indexer portion used by target43. It does not claim a whole target43 mHC/MoE/head/model generation or new short-history MTP carried-selection policy.',
    'The old mature initial_pool_recipe/initial_sparse initialization restriction remains unchanged. The new independent empty-state constructor has positive capacity, zero cursors/counters, all-1 selection, and NaN poison for unwritten cache/raw/pool/query slots.',
    'Existing official finite BF16 validation already checks only the published visible cache prefix; retained unchanged. New startup checks additionally require all unwritten suffix rows to stay NaN.'
]
(work/'design.json').write_text(json.dumps(plan,indent=2)+'\n')
cache=root/'.scratch/glm-original-target43-20261023/original-target43'
names=['index_kpool_compress_ape.bf16','index_kpool_compress_gate.bf16','k_norm.bias.bf16','k_norm.weight.bf16',
       'weights_proj.weight.bf16','wk.weight.bf16','wq_b.weight.bf16','q_b.weight.e4m3','q_b.weight_scale.f32',
       'kv_a.weight.e4m3','kv_a.weight_scale.f32','kv_a_layernorm.weight.bf16','kv_b.weight.bf16',
       'o.weight.e4m3','o.weight_scale.f32','post_attention_layernorm.weight.bf16']
files=[{'file':name,'exists':(cache/name).is_file(),'bytes':(cache/name).stat().st_size if (cache/name).is_file() else None} for name in names]
commands={
    'state':'plan only; not executed',
    'cache_directory':str(cache),
    'cache_check':'existence/size metadata only; exact original_target43::kIndexerSha256/kAttentionSha256 checked by existing Data loaders during actual case',
    'role_files':files,
    'cached_payload_bytes':sum(f['bytes'] or 0 for f in files),
    'compile_tu':'source/tests/compute_models/glm_mtp_state_consumer_test.cc',
    'compile_define':'HYLE_TEST_GLM_STATE_CPU=1',
    'overlay_note':'Stage transitive local project-header closure with private overrides; merely adding private /I does not replace nested quoted canonical includes.',
    'link_closure':'.scratch/inference-ordinary-boundaries-20261025/retirement-implementation/attempt2/link/command.json',
    'reuse_app_recipe':'.scratch/inference-sampling-range-20261025/check_candidate2.py (replace app TU/define/filter and use prepared header overlay; keep current native/link/GTest facts)',
    'run_environment':{'HYLE_GLM_MTP_TARGET43_DIR':str(cache)},
    'run_args':['--gtest_filter=GlmFlashOrdinaryEarlyHistoryPlan.*:GlmFlashOrdinaryEarlyHistory.CpuOriginalSparseStartsEmptyAndFeedsBackThroughFirstPool'],
    'expected_test_count':4,
    'native_scope':'5 real positions0,1,2,3,4 -> accepted frontier5; one StateHead, original layer43 indexer/MLA13-resource component, no generated weights, no MTP acceptance',
    'no_actions':['C++ build yet','CPU/native run yet','GPU','SDK/core rebuild','download','expert acquisition','full model']
}
(work/'finite-command-plan.json').write_text(json.dumps(commands,indent=2)+'\n')
print(json.dumps({'source_files':len(json.loads((work/'source-pins.json').read_text())),'cached_roles':len(files),'all_cached':all(f['exists'] for f in files),'cached_payload_bytes':commands['cached_payload_bytes']}))
