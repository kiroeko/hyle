from pathlib import Path
import hashlib
import importlib.util
import json
import os
import re
import subprocess
import sys
import time

sys.dont_write_bytecode=True
WORK=Path(__file__).resolve().parent
ROOT=WORK.parents[1]
spec=importlib.util.spec_from_file_location('sampling_cpu_helpers',ROOT/'.scratch/inference-sampling-range-20261025/check_cpu.py')
common=importlib.util.module_from_spec(spec);spec.loader.exec_module(common)
read,save,identity,require=common.read,common.save,common.identity,common.require

def execute(command,env,folder,timeout):
    folder.mkdir(parents=True,exist_ok=True)
    save(folder/'command.json',dict(command=command,cwd=str(ROOT),timeout_seconds=timeout))
    start=time.monotonic()
    with (folder/'stdout.log').open('wb') as stdout,(folder/'stderr.log').open('wb') as stderr:
        process=subprocess.Popen(command,cwd=ROOT,env=env,stdout=stdout,stderr=stderr)
        save(folder/'running.json',dict(pid=process.pid,stage=folder.name,started=time.time()))
        print('START',folder.name,'pid',process.pid,flush=True)
        try:code=process.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            process.kill();process.wait();code=-999
    save(folder/'process.json',dict(exit=code,seconds=time.monotonic()-start,pid=process.pid))
    print('END',folder.name,'exit',code,'seconds',round(time.monotonic()-start,3),flush=True)
    if code:
        print((folder/'stdout.log').read_text(encoding='utf-8',errors='replace')[-16000:],flush=True)
        print((folder/'stderr.log').read_text(encoding='utf-8',errors='replace')[-4000:],flush=True)
    return code

def main():
    attempt_name=sys.argv[1] if len(sys.argv)>1 else 'attempt1'
    folder=WORK/attempt_name
    assert not folder.exists(),'Retain prior attempts; use a fresh attempt name'
    folder.mkdir()
    pins=read(WORK/'source-pins.json')
    overrides={p['path']:p for p in pins}
    for pin in pins:
        assert identity(WORK/'source'/pin['path'])['sha256']==pin['after_sha256']
        if pin['before_sha256']:
            assert identity(ROOT/pin['path'])['sha256']==pin['before_sha256']
    tree=folder/'compile-source'
    project_dirs=[ROOT/'include',ROOT,ROOT/'engine',ROOT/'tests/compute_models',ROOT/'tests/graph_route_cpu']
    queue=[Path('tests/compute_models/glm_mtp_state_consumer_test.cc')]
    seen=set();records=[]
    while queue:
        rel=queue.pop().as_posix()
        if rel in seen:continue
        seen.add(rel)
        source=WORK/'source'/rel if rel in overrides else ROOT/rel
        body=source.read_bytes();target=tree/rel;target.parent.mkdir(parents=True,exist_ok=True)
        # Source snapshots are small; no SDK, dependency or model payload copied.
        target.write_bytes(body)
        records.append(dict(path=rel,source=str(source),bytes=len(body),sha256=hashlib.sha256(body).hexdigest(),override=rel in overrides))
        for name in re.findall(r'^\s*#\s*include\s*"([^"]+)"',body.decode('utf-8-sig'),re.M):
            for base in [(ROOT/rel).parent,*project_dirs]:
                candidate=(base/name).resolve()
                try:child=candidate.relative_to(ROOT).as_posix()
                except ValueError:continue
                if child in overrides or candidate.is_file():
                    queue.append(Path(child));break
    assert set(overrides).issubset(seen)
    save(folder/'frozen-project-headers.json',records)
    save(folder/'source-pins.json',pins)
    print('FROZEN',len(records),'project files',sum(x['bytes'] for x in records),'bytes; six overrides',flush=True)

    closure=ROOT/'.scratch/inference-ordinary-boundaries-20261025/retirement-implementation/attempt2/link'
    ready=read(closure/'ready.json');old_link=read(closure/'command.json')['command']
    for row in [ready['native'],*ready['actual_inputs']]:require(row)
    old_app=Path(ready['app']['path'])
    absolute=[x for x in old_link if Path(x).is_absolute() and Path(x).suffix.lower() in ('.obj','.lib')]
    system=[x for x in old_link if not Path(x).is_absolute() and x.lower().endswith('.lib')]
    assert len(absolute)==130 and len(system)==24
    gtest=[ROOT/'.scratch/build-compute-v2-dev/lib'/x for x in ('gtest_main.lib','gtest.lib')]
    ggml_base=ROOT/'.scratch/validation/cuda-final-u3-delivery/reference-windows/lib/ggml-base.lib'
    save(folder/'link-inputs.json',dict(common=[row for row in ready['actual_inputs'] if Path(row['path'])!=old_app],gtest=[identity(x) for x in gtest],cached_ggml_quantization_oracle=identity(ggml_base),native=ready['native'],system_libraries=system))
    recipe=read(ROOT/'.scratch/inference-sampling-range-20261025/cpu/candidate2/compile/command.json')['command']
    compiler=recipe[0]
    env=common.discover_environment(compiler='msvc',cache=dict(CMAKE_C_COMPILER=compiler,CMAKE_CXX_COMPILER=compiler,CMAKE_GENERATOR='Ninja'),backends=()).env
    flags=[];skip=False
    for arg in recipe[1:]:
        if skip:skip=False;continue
        if arg=='/sourceDependencies':skip=True
        elif arg.startswith(('/Fo','/Fd')) or arg.lower().endswith('.cc'):continue
        else:flags.append(arg)
    flags=[x for x in flags if not x.startswith('/I')]
    flags += ['/DHYLE_TEST_GLM_STATE_CPU=1',*['/I'+str(tree/d) for d in ('include','.','engine','tests/compute_models','tests/graph_route_cpu')]]
    flags += ['/I'+str(x) for x in project_dirs]
    flags += ['/external:I'+str(ROOT/'.scratch/validation/cpu-final-f1/mixed-iq1/source'/d) for d in ('include','src')]
    assert '/W4' in flags and '/WX' in flags
    obj=folder/'unit.obj';image=folder/'glm-early.exe'
    command=[compiler,*flags,str(tree/'tests/compute_models/glm_mtp_state_consumer_test.cc'),'/sourceDependencies',str(folder/'dependencies.json'),'/Fo'+str(obj),'/Fd'+str(folder/'unit.pdb')]
    if execute(command,env,folder/'compile',180):raise RuntimeError('compile failed; original raw retained')
    data=read(folder/'dependencies.json')['Data'];dep_paths=list(dict.fromkeys([data['Source'],*data['Includes']]))
    resolved={str(Path(x).resolve()).casefold() for x in dep_paths}
    for pin in pins:assert str((tree/pin['path']).resolve()).casefold() in resolved,pin['path']
    assert not any(str((ROOT/pin['path']).resolve()).casefold() in resolved for pin in pins)
    save(folder/'actual-source-dependencies.json',[identity(x) for x in dep_paths])
    command=[str(obj) if x==str(old_app) else x for x in old_link if not x.upper().startswith(('/OUT:','/PDB:','/IMPLIB:','/MAP:'))]
    command += [str(x) for x in gtest]+[str(ggml_base),'/OUT:'+str(image),'/PDB:'+str(folder/'glm-early.pdb'),'/IMPLIB:'+str(folder/'glm-early.lib')]
    if execute(command,env,folder/'link',60):raise RuntimeError('link failed; original raw retained')
    native=Path(ready['native']['path']);alias=folder/native.name;os.link(native,alias)
    assert os.path.samefile(alias,native);require(dict(ready['native'],path=str(alias)))
    save(folder/'native-runtime.json',dict(original=ready['native'],alias=identity(alias),same_file=True))
    plan=read(ROOT/'.scratch/inference-ordinary-boundaries-20261025/retirement-implementation/execution-plan2.json')
    runtime=read(plan['runtime']['path']);run_env=dict(env);run_env['PATH']=runtime['PATH']
    run_env['HYLE_GLM_MTP_TARGET43_DIR']=str(ROOT/'.scratch/glm-original-target43-20261023/original-target43')
    run_env['HF_HUB_OFFLINE']=run_env['TRANSFORMERS_OFFLINE']='1'
    test_filter='GlmFlashOrdinaryEarlyHistoryPlan.*:GlmFlashOrdinaryEarlyHistory.CpuOriginalSparseStartsEmptyAndFeedsBackThroughFirstPool'
    code=execute([str(image),'--gtest_color=no','--gtest_filter='+test_filter,'--gtest_output=json:'+str(folder/'tests.json')],run_env,folder/'run',120)
    print((folder/'run/stdout.log').read_text(encoding='utf-8',errors='replace')[-20000:],flush=True)
    report=read(folder/'tests.json')
    status='PASSED' if code==0 and report['tests']==4 and report['failures']==0 else 'FAILED'
    save(folder/'summary.json',dict(status=status,exit=code,tests=report['tests'],failures=report['failures'],source_pins=pins,
        image=identity(image),dependencies=identity(folder/'actual-source-dependencies.json'),native=ready['native'],
        compile=read(folder/'compile/process.json'),link=read(folder/'link/process.json'),run=read(folder/'run/process.json'),
        reuse_common_absolute_inputs=129,relative_windows_libraries=24,cached_gtest_libraries=2,
        application_TUs=1,CPU_processes=1,GPU=0,HTTP=0,SDK_core_provider_rebuilds=0,model_payload_copies=0,canonical_changed=False))
    assert status=='PASSED','actual Graph/numerical failure; do not relax gates'
    print('PASS four exact cases',folder/'summary.json',flush=True)

if __name__=='__main__':main()
