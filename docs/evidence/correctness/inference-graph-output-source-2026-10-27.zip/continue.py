from pathlib import Path
import importlib.util,json,os,sys,traceback
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;R=W.parents[1]
spec=importlib.util.spec_from_file_location('pending_base',W/'build.py');p=importlib.util.module_from_spec(spec);spec.loader.exec_module(p)
b,m=p.b,p.m;h=b.helper()
try:
    freeze=b.read(W/'source-freeze.json')
    current=[]
    for row in freeze:
        actual=b.pin(row['path'])
        if actual['sha256']!=row['sha256']:assert Path(row['path'])==R/'src/graph/resources.cc'
        current.append(actual)
    b.save(W/'source-freeze2.json',current)
    snapshot=W/'source2/src/graph/resources.cc';snapshot.parent.mkdir(parents=True,exist_ok=True);snapshot.write_bytes((R/'src/graph/resources.cc').read_bytes())
    plan=b.read(W/'plan.json');units=plan['units'];cl=units[0]['command'][0]
    env=h.discover_environment(compiler='msvc',cache={'CMAKE_C_COMPILER':cl,'CMAKE_CXX_COMPILER':cl,'CMAKE_GENERATOR':'Ninja'},backends=()).env
    closure=m.c.closure([u['source']['path'] for u in units],[str(u['template']['path']) for u in units]);b.save(W/'closure2.json',closure);own={b.key(x['path']):x for x in closure}
    done=b.read(W/'compiled-partial.json'); assert [x['name'] for x in done]==['retained']
    for u in units[1:]:
        out=W/('compile2' if u['name']=='resources' else 'compile')/u['name']; command=[]
        for i,a in enumerate(u['command']):
            if i and u['command'][i-1].lower()=='/sourcedependencies':a=str(out/'dependencies.json')
            elif a.lower().startswith('/fo'):a='/Fo'+str(out/'unit.obj')
            elif a.lower().startswith('/fd'):a='/Fd'+str(out/'unit.pdb')
            command.append(a)
        assert not out.exists()
        process=h.execute(command,env,out,timeout=180)
        deps=b.read(out/'dependencies.json')['Data']; actual=[b.pin(s) for s in dict.fromkeys([deps['Source'],*deps['Includes']])];b.save(out/'actual-dependencies.json',actual)
        for row in actual:
            if Path(row['path']).is_relative_to(R) and not Path(row['path']).is_relative_to(R/'.scratch'):assert own[b.key(row['path'])]['sha256']==row['sha256']
        for row in current:b.exact(row)
        done.append(dict(name=u['name'],source=b.pin(u['source']['path']),object=b.pin(out/'unit.obj'),process=process,dependencies=b.pin(out/'actual-dependencies.json')));b.save(W/'compiled-partial2.json',done)
    before=b.read(p.BASE/'link2-inputs.json');replacements={b.key(u['baseline']['path']):c['object'] for u,c in zip(units,done) if u['baseline']}; additional=done[-1]['object']
    inputs=[replacements.get(b.key(x['path']),x) for x in before]+[additional];assert len(inputs)==230
    b.save(W/'link-inputs.json',inputs);image=W/'bin/output-source-test.exe';image.parent.mkdir(parents=True,exist_ok=True)
    command=[]
    for a in b.read(p.BASE/'link2/command.json')['command']:
        if b.key(a) in replacements:a=replacements[b.key(a)]['path']
        elif a.lower().startswith('/out:'):a='/OUT:'+str(image)
        elif a.lower().startswith('/pdb:'):a='/PDB:'+str(image.with_suffix('.pdb'))
        command.append(a)
    command.append(additional['path']);linked=h.execute(command,env,W/'link',timeout=120)
    runtime=b.read(p.BASE/'runtime2.json');native=runtime['native_cpu'];b.exact(native);alias=image.parent/Path(native['path']).name;os.link(native['path'],alias);runtime['PATH']=str(image.parent)+';'+runtime['PATH'];b.save(W/'runtime.json',runtime)
    b.save(W/'ready.json',dict(image=b.pin(image),compiled=done,link=linked,inputs=b.pin(W/'link-inputs.json'),runtime=b.pin(W/'runtime.json'),source_freeze=b.pin(W/'source-freeze2.json'),counts=dict(CXX_TUs=4,compiler_attempts=5,failed_compile=1,links=1,images=1,NVCC=0,SDK=0)))
    print('READY',flush=True)
except Exception:
    b.save(W/'continue-failure.json',dict(error=traceback.format_exc(),note='No automatic retry; original results retained.'))
    raise
