from pathlib import Path
import hashlib, importlib.util, json, os, sys, traceback, xml.etree.ElementTree as ET
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent; R=W.parents[1]
spec=importlib.util.spec_from_file_location('old_batched',R/'.scratch/inference-batched-slot-controls-20261027/build.py'); old=importlib.util.module_from_spec(spec);spec.loader.exec_module(old)
b,m=old.helpers(); h=b.helper()
BASE=R/'.scratch/inference-batched-slot-controls-20261027'
def save(p,x): b.save(p,x)
def check_sources():
    path=W/'source-freeze2.json' if (W/'source-freeze2.json').exists() else W/'source-freeze.json'
    for row in b.read(path): b.exact(row)
def build():
    check_sources(); before=b.read(BASE/'link2-inputs.json')
    assert len(before)==229
    for row in before:b.exact(row)
    recipes=[('retained',R/'src/compute/retained_completion.cc',R/'.scratch/inference-current-closure-20261026/headers79/compute--retained_completion_cc/command.json','compute--retained_completion_cc'),('resources',R/'src/graph/resources.cc',BASE/'compile/resources/command.json','compile\\resources\\unit.obj'),('inputs',R/'src/graph/input_sources.cc',R/'.scratch/inference-current-closure-20261026/headers79/graph--input_sources_cc/command.json','graph--input_sources_cc'),('test',R/'tests/graph/output_source_cuda_test.cc',BASE/'compile3/cuda-test/command.json',None)]
    units=[]
    for name,src,template,needle in recipes:
        out=W/'compile'/name; argv=b.read(template)['command']; original=next(a for a in argv if a.lower().endswith('.cc'))
        command=[]
        for i,a in enumerate(argv):
            if i and argv[i-1].lower()=='/sourcedependencies':a=str(out/'dependencies.json')
            elif a.lower().startswith('/fo'):a='/Fo'+str(out/'unit.obj')
            elif a.lower().startswith('/fd'):a='/Fd'+str(out/'unit.pdb')
            elif a==original:a=str(src)
            command.append(a)
        matches=[row for row in before if needle and needle.lower() in row['path'].lower()]
        assert len(matches)==(0 if needle is None else 1),(name,matches)
        units.append(dict(name=name,source=b.pin(src),template=b.pin(template),baseline=matches[0] if matches else None,command=command))
    closure=m.c.closure([u['source']['path'] for u in units],[str(u['template']['path']) for u in units])
    save(W/'closure.json',closure); own={b.key(r['path']):r for r in closure}
    save(W/'plan.json',dict(baseline_ready=b.pin(BASE/'ready2.json'),baseline_inputs=b.pin(BASE/'link2-inputs.json'),source_freeze=b.pin(W/'source-freeze.json'),units=units,scope='4 CXX + one link + exactly GraphOutputSourceCuda.* (2); no NVCC/SDK/model/performance'))
    cl=units[0]['command'][0]; env=h.discover_environment(compiler='msvc',cache={'CMAKE_C_COMPILER':cl,'CMAKE_CXX_COMPILER':cl,'CMAKE_GENERATOR':'Ninja'},backends=()).env
    compiled=[]
    for u in units:
        out=W/'compile'/u['name']; assert not out.exists()
        result=h.execute(u['command'],env,out,timeout=180)
        d=b.read(out/'dependencies.json')['Data']; actual=[b.pin(p) for p in dict.fromkeys([d['Source'],*d['Includes']])]
        save(out/'actual-dependencies.json',actual)
        for row in actual:
            p=Path(row['path'])
            if p.is_relative_to(R) and not p.is_relative_to(R/'.scratch'):
                assert own[b.key(p)]['sha256']==row['sha256'],str(p)
        check_sources()
        compiled.append(dict(name=u['name'],source=u['source'],object=b.pin(out/'unit.obj'),process=result,dependencies=b.pin(out/'actual-dependencies.json')))
        save(W/'compiled-partial.json',compiled)
    replacements={b.key(u['baseline']['path']):c['object'] for u,c in zip(units,compiled) if u['baseline']}
    additional=compiled[-1]['object']; inputs=[replacements.get(b.key(x['path']),x) for x in before]+[additional]
    save(W/'link-inputs.json',inputs); assert len(inputs)==230
    image=W/'bin/output-source-test.exe';image.parent.mkdir(parents=True,exist_ok=True)
    argv=b.read(BASE/'link2/command.json')['command']; command=[]
    for a in argv:
        if b.key(a) in replacements:a=replacements[b.key(a)]['path']
        elif a.lower().startswith('/out:'):a='/OUT:'+str(image)
        elif a.lower().startswith('/pdb:'):a='/PDB:'+str(image.with_suffix('.pdb'))
        command.append(a)
    command.append(additional['path'])
    result=h.execute(command,env,W/'link',timeout=120)
    runtime=b.read(BASE/'runtime2.json'); native=runtime['native_cpu'];b.exact(native)
    alias=image.parent/Path(native['path']).name; os.link(native['path'],alias)
    runtime['PATH']=str(image.parent)+';'+runtime['PATH'];save(W/'runtime.json',runtime)
    save(W/'ready.json',dict(image=b.pin(image),compiled=compiled,link=result,inputs=b.pin(W/'link-inputs.json'),runtime=b.pin(W/'runtime.json'),source_freeze=b.pin(W/'source-freeze.json'),counts=dict(CXX_TUs=4,links=1,images=1,NVCC=0,SDK=0)))
    print('READY',flush=True)
def run():
    ready=b.read(W/'ready.json');b.exact(ready['image']);check_sources()
    cl=b.read(W/'plan.json')['units'][0]['command'][0]; env=h.discover_environment(compiler='msvc',cache={'CMAKE_C_COMPILER':cl,'CMAKE_CXX_COMPILER':cl,'CMAKE_GENERATOR':'Ninja'},backends=()).env
    env['PATH']=b.read(W/'runtime.json')['PATH']; xml=W/'results.xml'
    command=[ready['image']['path'],'--gtest_color=no','--gtest_filter=GraphOutputSourceCuda.*','--gtest_output=xml:'+str(xml)]
    result=h.execute(command,env,W/'run',timeout=60)
    root=ET.parse(xml).getroot();cases=root.findall('./testsuite/testcase')
    assert len(cases)==2 and int(root.attrib['tests'])==2
    assert all(not c.findall('failure') and not c.findall('error') and not c.findall('skipped') and c.attrib.get('status')=='run' for c in cases)
    save(W/'summary.json',dict(status='PASS',process=result,tests=[c.attrib for c in cases],image=ready['image'],source_freeze=ready['source_freeze'],scope='One-shot pending I32 output relay on original Queue; checked producer error and actual retirement. No full engine overlap, model, performance or native fault injection.'))
    print('PASS 2',flush=True)
if __name__ == '__main__':
    try:
        {'build':build,'run':run}[sys.argv[1]]()
    except Exception:
        save(W/(sys.argv[1]+'-failure.json'),dict(error=traceback.format_exc(),note='Original process/source/logs preserved; no automatic retry.'))
        raise
