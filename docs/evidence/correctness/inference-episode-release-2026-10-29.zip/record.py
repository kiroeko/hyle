"""Record four completed native journeys, original errors and source identities."""
from pathlib import Path
import hashlib
import json
import zipfile

W = Path(__file__).resolve().parent
R = W.parents[1]
OUT = R / 'docs/evidence/correctness/inference-episode-release-2026-10-29.json'

def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))

def pin(path):
    p = Path(path).resolve()
    return dict(path=p.relative_to(R).as_posix() if p.is_relative_to(R) else str(p),
                bytes=p.stat().st_size, sha256=hashlib.file_digest(p.open('rb'), 'sha256').hexdigest())

def exact(item):
    actual = pin(item['path'])
    assert all(actual[k] == item[k] for k in ('bytes', 'sha256')), item['path']

def terminal(path):
    item = read(path)
    assert item['state'] == 'TERMINAL' and item['exit'] == 0 and not item['timed_out']
    return item

plan = read(W / 'plan.json')
for item in plan['retained']:
    exact(item)
builds = {}
for name in plan['units']:
    receipt = read(W / 'compile' / name / 'receipt.json')
    for item in receipt['source_identities']:
        exact(item)
    builds[name] = dict(compile=terminal(W / 'compile' / name / 'process/process.json'),
        link=terminal(W / 'link' / name / 'process.json'), object=pin(W / 'compile' / name / 'unit.obj'),
        image=pin(W / 'bin' / (name + '.exe')), source=pin(plan['units'][name]['source']),
        project_source_inputs=len(receipt['source_identities']))

cases = {}
for name in plan['cases']:
    report = read(W / 'runs' / name / 'report.json')
    assert report['status'] == 'PASS' and report['performance_claim'] is False
    if name == 'source-cuda':
        assert report['mode'] == 'relay' and report['backend'] == 'cuda'
        assert report['arms'] == 4 and report['native_submissions'] == 45
        assert report['released_source_failure_native_submissions'] == 12
        assert report['released_source_failure_extra_native_submissions'] == 1
        assert report['decode_steps_per_arm'] == 10 and report['prefill_tokens'] == 3
        assert report['physical_carriers'] == 3 and report['candidate_depth'] == 2
        assert report['pending_capture_recorded'] == report['final_live_versions'] == 0
        for field in ('released_source_then_input_rejected', 'source_withdrawal_not_repeated',
                      'failure_head_checkpoint_epoch_rng_ledger_unpublished', 'same_session_retry_matches_serial',
                      'successor_prepared_while_predecessor_pending', 'successor_submitted_while_predecessor_pending',
                      'predecessor_published_while_successor_pending', 'rejected_successor_preserved_predecessor',
                      'old_checkpoint_unchanged', 'rng_cursor_unchanged', 'all_source_generations_released'):
            assert report[field] is True, field
        assert report['complete_state_bytes_compared'] == 215424
        summary = dict(arms=4, native_submissions=45, failed_arm_submissions=12,
            serial_complete_state_payload_bytes=215424, typed_failure='InvalidArgument from original Invocation::unbind',
            failed_unbind_metadata_kept_during_recovery=True, same_original_session_retry_matches_serial=True)
    elif name == 'ordinary-cuda':
        assert report['control_and_candidate_arms'] == 16 and len(report['candidates']) == 8
        for field in ('same_original_executor', 'complete_prefix_state_epoch_rng_equal', 'actual_owner_credit_checked',
                      'all_source_session_page_owners_retired', 'accepted_work_control_exception'):
            assert report[field] is True, field
        assert not report['gpu_native_fault_injected'] and not report['model_quality_claim']
        assert [(c['requests'], c['mode']) for c in report['candidates']] == [
            (1, 'normal'), (2, 'normal'), (2, 'credit_exhaustion'), (2, 'member_cancel'),
            (2, 'yield_resume'), (2, 'cancel_then_control_exception'), (1, 'extra_stop'), (2, 'extra_stop')]
        assert all(c['submit_before_observe'] and c['pending_length27'] for c in report['candidates'])
        summary = dict(control_and_candidate_arms=16, complete_prefix_state_epoch_rng_equal=True)
    else:
        assert name in ('mtp-cuda', 'controls-cpu')
        count = 1 if name == 'mtp-cuda' else 3
        assert len(report['state_checks']) == count and report['final_versions'] == 0
        assert report['quality_claim'] is False
        for item in report['state_checks']:
            assert item['boundary_equal'] and item['payloads_byte_equal'] and item['numerically_equivalent']
            assert item['exact_next'] == item['bucket_next'] and not item['differences']
        if name == 'mtp-cuda':
            assert report['output_limit'] == report['outputs'] == 40 and report['journeys'] == 2
            for field in ('original_ledger_equal', 'generated_ids_equal', 'greedy_rng_unchanged', 'all_sources_expired'):
                assert report[field] is True, field
            assert report['successor_submissions'] == 3 and report['successor_publications'] == 2
            assert report['successor_discards'] == 1
        else:
            assert report['target_submissions'] == 9 and report['synthetic_untrained']
            for field in ('whole_episode_retired', 'cancelled_heads_ledger_RNG_unchanged', 'independent_request_RNG',
                          'HostImage_same_key_restore', 'old_checkpoints_unchanged', 'q_conditional_owners_cleared'):
                assert report[field] is True, field
        summary = dict(complete_state_byte_checks=count, original_owners_and_ledger_preserved=True)
    cases[name] = dict(status='PASS', process=terminal(W / 'runs' / name / 'process.json'),
        report=pin(W / 'runs' / name / 'report.json'), summary=summary)

archive = OUT.with_suffix('.zip')
members = {W / 'build.py', Path(__file__), W / 'plan.json'}
for parent in ('compile', 'link', 'runs'):
    members.update(p for p in (W / parent).rglob('*') if p.is_file() and p.suffix in ('.json', '.log'))
with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for p in sorted(members):
        assert p.name != 'environment.json'
        z.write(p, p.relative_to(W).as_posix())
result = dict(schema='hyle.correctness.episode-release.v1', date='2026-10-29',
    status='PASS_FOUR_FINITE_NATIVE_CASES',
    change='ExecutionEpisode owns original Source withdrawal and caller-input release. Successful Source withdrawal clears its bound fact immediately; later unbind failure preserves remaining owners. Retired recovery reuses only Source withdrawal, then resets the original Invocation, without reopening carrier admission.',
    counts=dict(consumer_CXX=3, links=3, retained_SDK_inputs=227, SDK_CXX=0, NVCC=0,
                native_processes=4, native_failures=0, native_retries=0, downloads=0),
    builds=builds, cases=cases,
    sources=[pin(R / path) for path in ('engine/inference/execution_episode.h', 'engine/models/qwen35/main.cc',
                                       'tests/tools/qwen_submission_source_probe.cc')],
    boundaries=[
        'Windows MSVC 14.50 and RTX 4070 driver 617.14; retained original SDK inputs, no full SDK build.',
        'The original caller-input API rejects an invalid ValueId after real Source withdrawal. This is not a GPU fault or fake Completion.',
        'The failure arm keeps its external original outgoing Source owner so automatic abort must retain remaining resources before explicit release.',
        'Original serial, ready relay and controlled pending/cold-tuple rejection arms remain; the added arm retries the same original Session without clearing failed/stopping flags.',
        'Unknown native failure, Apple/Vulkan, a second full inference model, global architecture completion and new throughput/quality are not established.',
        'One serial arm has 215424 bytes of complete state payload; three other arms compare IDs, epochs and full state against it. The reported byte field is not a multiplied I/O total.'],
    archive=pin(archive))
OUT.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print('PASS four finite native cases; real Source withdrawal/unbind refusal/recovery; archived', archive.stat().st_size, 'bytes')
