from pathlib import Path

root = Path(__file__).resolve().parents[2]
path = root / 'tools/qwen35_text/main.cc'
text = path.read_text(encoding='utf-8')
old = text[text.index('int run_mtp(Model &model,'):text.index('} // namespace qwen35\n\nint main(')]
new = Path(__file__).with_name('mtp-request.inc').read_text(encoding='utf-8')
text = text.replace(old, new, 1)

def replace(old, new):
    global text
    assert text.count(old) == 1, old
    text = text.replace(old, new, 1)

replace('''    const bool prefix_enabled = prefix_policy == "auto" || (prefix_policy.empty() && multiple_schedules);
    if (mtp_enabled && (scheduled || explicit_continuation || explicit_decode_ids || !layer0_probe.empty() || active_sequences > 1))
      throw std::runtime_error("MTP currently supports single-session greedy generation; schedules, continuation, forced decode and layer probes require further integration");''', '''    const bool prefix_enabled = prefix_policy == "auto" || (prefix_policy.empty() && multiple_schedules && !mtp_enabled);
    if (mtp_enabled) {
      if (explicit_continuation || explicit_decode_ids || !layer0_probe.empty())
        throw std::runtime_error("--mtp on uses natural generation; --continuation, --decode-ids and --layer0-probe are not supported");
      if (preparation_diagnostics)
        throw std::runtime_error("--preparation-diagnostics is not supported with --mtp on");
      if (prefix_enabled)
        throw std::runtime_error("--mtp on currently requires --prefix-cache off");
      if (active_sequences > 1)
        throw std::runtime_error("--mtp on currently requires --active-sequences auto or 1; sessions are interleaved at R1");
      active_sequences = 1;
      if (steps > 128) throw std::runtime_error("--mtp on requires --steps in [1,128]");
    }''')
replace('''    if (scheduled && (explicit_continuation || explicit_decode_ids || explicit_steps))''', '''    if (scheduled && (explicit_continuation || explicit_decode_ids || (explicit_steps && !mtp_enabled)))''')
replace('''          std::vector<qwen35::benchmark::SessionSchedule>{}.max_size(), true);
    const auto recurrent_payload''', '''          std::vector<qwen35::benchmark::SessionSchedule>{}.max_size(), true);
    if (mtp_enabled && scheduled) for (const auto &request : schedules) {
      if (request.phases.size() != 1 || request.phases.front().kind != qwen35::benchmark::PhaseKind::kPrompt)
        throw std::runtime_error("--mtp on schedules require exactly one prompt phase per session; decode tapes and multi-turn prompts are not supported");
      const auto tokens = request.phases.front().ids.size();
      if (tokens > capacity || steps - 1 > capacity - tokens)
        throw std::runtime_error("MTP session " + request.id + " prompt plus requested generation exceeds --capacity");
    }
    const auto recurrent_payload''')
replace('''    const auto cached_slots = (std::min)(max_sessions, scheduled ? schedules.size() : std::size_t{1});
    if (active_sequences''', '''    const auto cached_slots = (std::min)(max_sessions, scheduled ? schedules.size() : std::size_t{1});
    if (mtp_enabled && scheduled && cached_slots < schedules.size())
      throw std::runtime_error("--mtp on requires --max-sessions to retain all requested sessions; generated MTP state cannot use ordinary token replay");
    if (active_sequences''')
replace('''[--capacity 128] [--max-sessions auto|N]''', '''[--mtp off|on] [--capacity 128] [--max-sessions auto|N]''')
replace('''    else if (selected_cache.backing_bytes > cache_bytes) {
      const auto minimum''', '''    else if (selected_cache.backing_bytes > cache_bytes) {
      if (mtp_enabled && scheduled)
        throw std::runtime_error("--cache-bytes must hold all MTP sessions: requires " +
            std::to_string(selected_cache.backing_bytes) + " shared target/draft KV/RNN backing bytes");
      const auto minimum''')
replace('''    if (mtp_enabled) return qwen35::run_mtp(model, prompt, steps, trace, trace_states, startup, constructed);''', '''    if (mtp_enabled) {
      if (scheduled) return qwen35::run_mtp_sessions(model, schedules, steps, trace, trace_states, startup, constructed);
      return qwen35::run_mtp(model, prompt, steps, trace, trace_states, startup, constructed);
    }''')
path.write_text(text, encoding='utf-8', newline='\n')
print(path)
