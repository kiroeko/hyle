"""New CLI validation cases with intentionally absent weight manifest."""
from pathlib import Path
import importlib.util,os,sys
sys.dont_write_bytecode=True
X=Path(__file__).resolve().parent;R=X.parents[1]
s=importlib.util.spec_from_file_location('build',X/'build_hyle.py');h=importlib.util.module_from_spec(s);s.loader.exec_module(h)
b,c=h.b,h.c
ready=c.read(X/'qwen-ready-attempt2.json');assert h.same(ready['image'])and h.same(ready['source'])
env=os.environ.copy();env['PATH']=c.read(ready['runtime_environment']['path'])['PATH']
f=X/'fixtures';out=X/'cli-errors1';out.mkdir(exist_ok=False)
(f/'no-weight-manifest').mkdir(exist_ok=False)
(f/'no-weight-manifest/prompt.ids').write_text('')
base=[ready['image']['path'],'--inputs',str(f/'no-weight-manifest'),'--capacity','64']
manifest=['--session-schedules',str(f/'sessions.txt')]
cases=[
 ('empty-prompt',['--mtp','on'],['nonempty prompt']),
 ('tape',['--mtp','on','--schedule',str(f/'fixed.txt')],['prompt']),
 ('multi-turn',['--mtp','on','--schedule',str(f/'turns.txt')],['prompt']),
 ('active-two',['--mtp','on',*manifest,'--active-sequences','2'],['1']),
 ('prefix-auto',['--mtp','on',*manifest,'--prefix-cache','auto'],['prefix']),
 ('resident-one',['--mtp','on',*manifest,'--max-sessions','1'],['sessions']),
 ('bytes-one',['--mtp','on',*manifest,'--cache-bytes','1'],['bytes']),
 ('bytes-below-all',['--mtp','on',*manifest,'--cache-bytes','80240690'],['bytes']),
 ('output-quota',['--mtp','on',*manifest,'--steps','129'],['128']),
 ('context',['--mtp','on',*manifest,'--steps','64'],['capacity']),
 ('diagnostic',['--mtp','on',*manifest,'--preparation-diagnostics','1'],['preparation']),
 ('ordinary-steps',[*manifest,'--steps','4'],['steps']),
]
results=[]
for name,args,needles in cases:
 d=out/name;d.mkdir();command=base+args
 c.save(d/'plan.json',dict(command=command,expected_exit=1,missing_weight_manifest=True,expected_text=needles,throughput_evidence=False))
 try:c.execute('run',command,env,d)
 except RuntimeError:pass
 record=c.read(d/'run.result.json');error=(d/'run.stderr.log').read_text(encoding='utf-8',errors='replace')
 assert record['exit']==1 and record['terminal'] and all(s.lower()in error.lower()for s in needles),(name,record,error)
 assert 'cannot open weight'not in error.lower()and'weights_load_seconds='not in error and not (d/'run.stdout.log').read_bytes(),(name,error)
 results.append(dict(name=name,command=command,exit=record['exit'],stderr=error,expected_validation=True,missing_weight_manifest=True,terminal=b.identity(d/'run.result.json')))
c.save(X/'review/cli-errors-analysis.json',dict(status='PASS_EXPECTED_EARLY_VALIDATION',cases=results,model_weight_loads=0,GPU_inference_runs=0,source=ready['source'],image=ready['image'],scope='Only the specified new CLI option combinations. Expected nonzero exits are retained as such; not model correctness or timing evidence.'))
print('EXPECTED_VALIDATION',len(results))
