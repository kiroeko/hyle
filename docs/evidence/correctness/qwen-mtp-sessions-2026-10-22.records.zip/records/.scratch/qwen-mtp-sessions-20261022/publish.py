"""Publish the finite shared-Model MTP multi-session implementation and checks."""
from pathlib import Path
import difflib, hashlib, json, subprocess, zipfile
X=Path(__file__).resolve().parent;R=X.parents[1];O=R/'docs/evidence/correctness';NAME='qwen-mtp-sessions-2026-10-22'

def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def save(p,d):p.write_text(json.dumps(d,indent=2,ensure_ascii=False,allow_nan=False)+'\n',encoding='utf-8')
def identity(p):
 p=Path(p);h=hashlib.sha256()
 with p.open('rb')as f:
  for data in iter(lambda:f.read(8<<20),b''):h.update(data)
 return dict(path=str(p.resolve()),bytes=p.stat().st_size,sha256=h.hexdigest())

changed=['tools/qwen35_text/main.cc','tools/qwen35_text/mtp_session_probe.cc','tools/qwen35_text/CMakeLists.txt','tools/qwen35_text/README.md','docs/developer/current-work.md']
frozen=[]
for name in changed:
 p=R/name;snap=X/'current'/name;snap.parent.mkdir(parents=True,exist_ok=True);snap.write_bytes(p.read_bytes())
 before=X/'before'/name;old=before.read_text(encoding='utf-8-sig') if before.exists() else ''
 diff=X/'product-diffs'/(name.replace('/','--')+'.diff');diff.parent.mkdir(exist_ok=True)
 diff.write_text(''.join(difflib.unified_diff(old.splitlines(True),p.read_text(encoding='utf-8-sig').splitlines(True),fromfile='before/'+name,tofile=name)),encoding='utf-8')
 if before.exists():
  result=subprocess.run(['git','diff','--no-index','--check',str(before),str(p)],capture_output=True,text=True,encoding='utf-8',errors='replace')
  assert result.returncode in(0,1)and not result.stdout.strip()and not result.stderr.strip(),(name,result.stdout,result.stderr)
 frozen.append(dict(source=identity(p),snapshot=identity(snap),before=identity(before)if before.exists()else None,diff=identity(diff)))
save(X/'product-freeze.json',dict(files=frozen))
ready={}
for tag,attempt in [('qwen',2),('mtp_session',2)]:
 record=read(X/f'{tag}-ready-attempt{attempt}.json');assert identity(record['image']['path'])==record['image']
 ready[tag]=record
assert ready['qwen']['source']==identity(R/'tools/qwen35_text/main.cc')
assert ready['mtp_session']['main']['sha256']==identity(X/'before/tools/qwen35_text/main.cc')['sha256']
probe=read(X/'probe-run1/vectors/observation.json')
assert probe['status']=='PASS_BYTE_EXACT'and len(probe['vectors'])==378 and probe['final_live_snapshot_versions']==0
diagnostic_runs=[]
for folder in [X/'probe-run1',*sorted((X/'cli-runs1').iterdir())]:
 if not folder.is_dir():continue
 terminal=read(folder/'run.result.json');assert terminal['terminal']and terminal['exit']==0
 diagnostic_runs.append(dict(terminal=identity(folder/'run.result.json'),stdout=identity(folder/'run.stdout.log'),stderr=identity(folder/'run.stderr.log'),command=terminal['command'],throughput_evidence=False))
reports={p.name:read(p)for p in sorted((X/'review').glob('*.json'))}
assert 'probe-analysis.json'in reports and 'cli-analysis.json'in reports
assert reports['cli-analysis.json']['status']=='PASS_INDEPENDENT_HOST_REVIEW_OF_8_ACTUAL_EXIT0_CLI_PROCESSES'
assert reports['probe-analysis.json']['status']=='PASS_HOST_REVIEW_OF_ACTUAL_EXIT0'
summary=dict(status='CUDA shared-Model interleaved R1 MTP CLI implemented; finite complete-state and consumer checks passed; broader goal active',date='2026-10-22',
 product_freeze=identity(X/'product-freeze.json'),ready=ready,probe=probe,reports=reports,diagnostic_runs=diagnostic_runs,
 actual_diagnostic_GPU_processes=len(diagnostic_runs),timing_window_performed=False,
 build_scope=dict(new_Hyle_library_TUs=0,Hyle_consumer_distinct_TUs=2,host_compile_attempts=4,successful_host_compiles=3,failed_host_compiles=1,successful_links=2,SDK_builds=0,NVCC_builds=0,full_configures=0,reused_Hyle_link_inputs_per_consumer=194),
 findings=[
 'The same 335-tensor Model, finite GraphRoles, page/state pools and globally borrowed execution carrier run two naturally generated MTP sessions in round-robin R1. Single generation and the manifest CLI use one generation-step helper, with no copied Model or extra executor.',
 'The permanent probe executes independent sequential baselines then interleaved P15/P23 with output quotas8/16. Every committed boundary compares36 conv/GDN vectors,14 logical committed KV vectors, carry/prior, complete logits/hidden, next ID, frontier, lag and catchup metadata. All378 vectors are byte-identical and finite. Four idle-head complete-byte checks pass.',
 'Session B stops at its original natural EOS, releases its head, and A executes three further episodes using the shared Model carrier. Peak live Snapshot versions3 is within N2+R1; recurrent slots4 and hidden slots6; shared state backing80,240,691 bytes is charged once; final live versions0.',
 'CLI errors are validated before Model loading. MTP manifests currently contain one prompt per session and use --steps as each session output quota. R auto resolves to1. Insufficient resident count/bytes, prefix auto, fixed decode tapes and multi-turn schedules are explicitly rejected rather than sent through ordinary replay.',
 'Eight actual CLI GPU processes all exit0. Independent host checks find12 before/current decision-vector pairs,6 single-schedule/flat pairs, and266 multi-session/probe vector pairs byte-identical and finite. Multi trace exports36 conv/GDN states plus complete logits/hidden; the permanent probe separately covers14 logical KV and carry/prior. Twelve actual early-validation processes retain their expected exit1 and do not load weights.',
 'Published raw equality reuses one canonical baseline payload when bytes are identical. FNV identities are diagnostic only; full-array equality and independent SHA256/finite checks are retained.'],
 limitations=[
 'Only CUDA BF16 Qwen3.5-2B K1, the stated finite inputs and serial active R1 were run. No simultaneous R2 MTP, server isolation, selected-model/quant coverage, Apple/Vulkan native consumer or image support claim.',
 'MTP session eviction/rebuild and natural multi-turn prompt continuation remain implementation work. Ordinary ReplayHistory lacks the actual draft/verify acceptance history; a lag1 MTP head cannot be passed directly to arbitrary prompt prefill.',
 'The initial MTP manifest CLI requires enough resident capacity for all supplied requests and keeps prefix reuse off. Those restrictions are explicit, not an assertion that general multi-session caching is complete.',
 'No performance comparison was performed in this correctness tranche. Trace/probe timing must not replace the latest complete four-metric performance window.',
 'The probe was compiled against the frozen pre-refactor consumer main; the current CLI build and source review independently cover the new generation driver. Shared Model/Graph/math/state code is unchanged in this tranche.',
 'One first probe compile failed on a C++ deduced array declaration, corrected in compile2; original failed source/command/output are retained. No failed build is labeled passed.'],
 previous_evidence=['docs/evidence/performance/qwen-mtp-divergence-2026-10-22.json','docs/evidence/correctness/qwen-mtp-retirement-2026-10-22.json'],
 remaining=['Complete actual MTP prefix reuse, safe bounded request admission/eviction and multi-turn state semantics.',
 'Extend MTP grouping to applicable equal-shape real batches with per-request acceptance and complete transactions.',
 'Diagnose remaining actual capture invalidations; keep speed/memory/quality claims separate.',
 'Other systems/backends, selected models/quantization, image projector and the full architecture scope remain active.'])
save(X/'actual-summary.json',summary)
excluded={'.exe','.dll','.obj','.map','.lib','.exp','.pdb','.pyc'}
files=sorted(p for p in X.rglob('*')if p.is_file()and p.suffix.lower()not in excluded and not any(a in('tmp','__pycache__')for a in p.relative_to(X).parts)and p.name not in('published.json','cleanup-plan.json','cleanup-result.json','cleanup_script.ps1'))
archive=O/(NAME+'.data.zip');assert not archive.exists();entries=[];unique={}
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=6)as z:
 for p in files:
  e=identity(p);key=(e['bytes'],e['sha256']);canonical=unique.get(key)
  if canonical is None:canonical=p.relative_to(R).as_posix();unique[key]=canonical;z.write(p,canonical)
  else:e['identical_content_alias']=True
  e['entry']=canonical;entries.append(e)
with zipfile.ZipFile(archive)as z:
 assert z.testzip()is None and len(z.namelist())==len(unique)
 for (size,sha),entry in unique.items():
  raw=z.read(entry);assert len(raw)==size and hashlib.sha256(raw).hexdigest()==sha
manifest=O/(NAME+'.json');assert not manifest.exists()
save(manifest,dict(**summary,archives=[identity(archive)],archive_files=entries,archive_verified=dict(CRC=True,all_unique_entry_SHA256=True,source_files=len(entries),unique_entries=len(unique),original_bytes=sum(x['bytes']for x in entries),unique_bytes=sum(x[0]for x in unique),content_deduplication='Every original source path retains SHA/size and canonical ZIP entry; identical raw payloads stored once.')))
published=dict(manifest=identity(manifest),archives=[identity(archive)]);save(X/'published.json',published)
print(json.dumps(dict(**published,source_files=len(entries),unique_entries=len(unique),original_bytes=sum(x['bytes']for x in entries),unique_bytes=sum(x[0]for x in unique)),indent=2))
