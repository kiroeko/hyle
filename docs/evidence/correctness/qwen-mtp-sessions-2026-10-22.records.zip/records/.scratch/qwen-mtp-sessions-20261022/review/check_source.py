"""Check that this consumer-driver change does not alter Model/Graph mathematics."""
from pathlib import Path
import difflib,hashlib,json
X=Path(__file__).resolve().parents[1];R=X.parents[1]
before=X/'before/tools/qwen35_text/main.cc';now=R/'tools/qwen35_text/main.cc'
old=before.read_text(encoding='utf-8-sig');new=now.read_text(encoding='utf-8-sig')
prefix=old[:old.index('\nint run_mtp(')]
assert new.startswith(prefix),'Model/Graph/state code changed; require additional review'
marker='    // These owners are declared after Model, including on exception paths.'
assert old.split(marker,1)[1]==new.split(marker,1)[1],'ordinary consumer body changed'
def rec(p):return dict(path=str(p.resolve()),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
diff=''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='before/main.cc',tofile='main.cc'))
(X/'review/cli-main.diff').write_text(diff,encoding='utf-8')
report=dict(status='PASS_FINITE_SOURCE_BOUNDARIES',before=rec(before),source=rec(now),unchanged_Model_Graph_state_prefix_lines=prefix.count('\n'),ordinary_consumer_body_identical=True,scope='New helpers and CLI validation are reviewed separately. This check establishes the old compiled permanent state probe still exercises unchanged Model/Graph/state code; it is not a build or runtime result.')
(X/'review/cli-source-boundaries.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
print(json.dumps(report,indent=2))
