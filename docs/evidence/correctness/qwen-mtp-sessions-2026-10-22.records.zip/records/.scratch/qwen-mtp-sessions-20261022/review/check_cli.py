"""Host-only checks of the eight actual CLI processes and retained raw traces."""
from pathlib import Path
import argparse
import hashlib
import json
import math
import numpy as np

HERE = Path(__file__).resolve().parent
X = HERE.parent


def load(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def identity(path):
    raw = path.read_bytes()
    return dict(path=str(path.resolve()), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


def semantic(row):
    return {key: value for key, value in row.items() if not key.endswith(('_seconds', '_second'))}


def finite(raw, suffix):
    if suffix == '.bf16':
        assert len(raw) % 2 == 0
        array = (np.frombuffer(raw, dtype='<u2').astype(np.uint32) << 16).view(np.float32)
    else:
        assert suffix == '.f32' and len(raw) % 4 == 0
        array = np.frombuffer(raw, dtype='<f4')
    assert np.isfinite(array).all()
    return int(array.size)


def raw_files(directory):
    return {str(path.relative_to(directory)): path for path in directory.rglob('*')
            if path.is_file() and path.suffix in ('.bf16', '.f32')}


def timing(row):
    p, d, wall = (row[key] for key in ['prefill_seconds', 'decode_seconds', 'session_seconds'])
    assert p > 0 and d >= 0 and wall > 0 and abs((p + d) - wall) < 1e-12
    assert row['startup_total_seconds'] == row['startup_to_endpoint_seconds']
    assert row['startup_to_ready_seconds'] <= row['first_token_elapsed_seconds'] <= row['startup_to_endpoint_seconds']
    assert math.isclose(row['output_tokens_per_second'], row['generated_tokens'] / wall, rel_tol=1e-12)
    assert math.isclose(row['decode_output_tokens_per_second'], row['generated_decode_tokens'] / d if d else 0, rel_tol=1e-12, abs_tol=1e-15)
    assert math.isclose(row['prefill_tokens_per_second'], row['prefill_target_rows'] / p, rel_tol=1e-12)
    assert row['generated_decode_tokens'] == row['generated_tokens'] - (row.get('session_count') or 1)
    assert row['actual_graph_calls'] == row['prefill_graph_calls'] + row['decode_graph_calls']
    return dict(prefill=p, decode=d, once_wall=wall, P_plus_D_minus_wall=p + d - wall,
                diagnostic=row['diagnostic'], performance_evidence=False)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--runs', type=Path, default=X / 'cli-runs1')
    parser.add_argument('--output', type=Path, default=HERE / 'cli-analysis.json')
    args = parser.parse_args()
    runs = args.runs.resolve()
    names = ['p1-before','p1-current','p15-before','p15-current','ordinary-before','ordinary-current','multi-current','schedule-current']
    rows, process_records, raw_manifest = {}, [], {}
    image_current = load(X / 'qwen-ready-attempt2.json')
    compiled_current = X / 'compile2/qwen/source/tools/qwen35_text/main.cc'
    assert identity(compiled_current)['sha256'] == image_current['source']['sha256'] == '48302bd77278df98db8882e32a305800db914089dcb22c1006cf4be2f6c5faeb'
    for name in names:
        directory = runs / name
        terminal, plan = load(directory / 'run.result.json'), load(directory / 'plan.json')
        assert terminal['terminal'] and terminal['exit'] == 0 and terminal['command'] == plan['command']
        assert plan['diagnostic'] and not plan['throughput_evidence']
        if name.endswith('before'):
            assert plan['image']['source']['sha256'] == 'c6dc3d58a6b6bad811226fd972b6588b0507cd0901c8168c3f785a186306b71a'
        else:
            assert plan['image'] == image_current
        assert Path(terminal['command'][0]) == Path(plan['image']['image']['path'])
        row = load(directory / 'parsed.json')
        stdout_json = json.loads((directory / 'run.stdout.log').read_text())
        assert stdout_json == row
        rows[name] = row
        process_records.append(dict(name=name, image=plan['image']['image'], source=plan['image']['source'],
            terminal=identity(directory / 'run.result.json'), parsed=identity(directory / 'parsed.json'),
            stdout=identity(directory / 'run.stdout.log'), stderr=identity(directory / 'run.stderr.log'),
            plan=identity(directory / 'plan.json'), timing=timing(row)))
        for relative, path in raw_files(directory / 'trace').items():
            raw = path.read_bytes()
            raw_manifest[str(path)] = dict(**identity(path), elements=finite(raw, path.suffix), nonfinite=0,
                                           dtype='BF16' if path.suffix == '.bf16' else 'F32')
    comparisons = []
    def equal_raw(label, left, right):
        a, b = left.read_bytes(), right.read_bytes()
        assert a == b, (label, str(left), str(right))
        assert finite(a, left.suffix) == finite(b, right.suffix)
        comparisons.append(dict(label=label, left=str(left), right=str(right), bytes=len(a),
                                sha256=hashlib.sha256(a).hexdigest(), byte_equal=True, nonfinite=0))
    single_comparisons = []
    for prefix in ['p1', 'p15', 'ordinary']:
        before, current = rows[prefix + '-before'], rows[prefix + '-current']
        assert semantic(before) == semantic(current)
        a_dir, b_dir = runs / (prefix + '-before') / 'trace', runs / (prefix + '-current') / 'trace'
        a, b = raw_files(a_dir), raw_files(b_dir)
        assert set(a) == set(b) and len(a) == dict(p1=2, p15=6, ordinary=4)[prefix]
        for name in a:
            equal_raw(prefix + '/' + name, a[name], b[name])
        single_comparisons.append(dict(case=prefix, semantic_and_work_equal=True, vectors=len(a),
                                       generated_ids=current['generated_ids'], work={key:current[key] for key in
                                       ['actual_graph_calls','actual_target_rows','actual_draft_rows','generated_tokens','generated_decode_tokens']}))
    assert rows['p1-current']['requested_steps'] == 1 and rows['p1-current']['actual_graph_calls'] == 1
    assert rows['p15-current']['generated_ids'] == [198,248045,74455,271]
    assert rows['ordinary-current']['generated_ids'] == [20,248046]

    schedule = rows['schedule-current']
    assert schedule['session_count'] == 1 and schedule['dispatch'] == ['default'] * 3
    assert schedule['sessions'][0]['session_id'] == 'default'
    assert semantic(schedule['sessions'][0]['result']) == semantic(rows['p15-current'])
    schedule_raw = raw_files(runs / 'schedule-current/trace/session0_default')
    p15_raw = raw_files(runs / 'p15-current/trace')
    assert set(schedule_raw) == set(p15_raw) and len(schedule_raw) == 6
    for name in schedule_raw:
        equal_raw('schedule/' + name, p15_raw[name], schedule_raw[name])

    multi = rows['multi-current']
    assert multi['session_count'] == multi['max_sessions'] == 2 and multi['active_sequences'] == 1
    assert not multi['prefix_cache'] and multi['requested_steps_per_session'] == 8
    assert multi['shared_backing_bytes'] == 80_240_691
    assert multi['dispatch'] == ['A','B','A','B','A','A','A']
    assert multi['actual_graph_calls'] == multi['logical_dispatches'] == 7
    assert multi['prefill_graph_calls'] == 2 and multi['decode_graph_calls'] == 5
    probe = load(X / 'probe-run1/vectors/observation.json')
    session_results = {entry['session_id']:entry['result'] for entry in multi['sessions']}
    multi_vector_count = 0
    for owner, steps in zip(['A','B'], probe['baseline']):
        row = session_results[owner]
        assert len(row['rounds']) + 1 == len(steps) and row['generated_ids'] == steps[-1]['metadata']['generated_ids']
        final = steps[-1]['metadata']['head']
        assert (row['visible_tokens'],row['draft_frontier'],row['draft_lag']) == (final['length'],final['draft_frontier'],final['lag'])
        timing(row)
        for index, step in enumerate(steps):
            meta = step['metadata']
            directory = runs / f'multi-current/trace/session{0 if owner == "A" else 1}_{owner}' / ('prefill' if index == 0 else f'mtp{index}')
            raw = raw_files(directory)
            expected = {v['name']:v for v in step['vectors'] if v['name'].startswith('layer') or v['name'].startswith('output.')}
            assert len(expected) == len(raw) == 38
            for original, vector in expected.items():
                trace_name = original.removeprefix('output.')
                assert trace_name in raw
                equal_raw(f'multi/{owner}/step{index}/{trace_name}', Path(vector['path']), raw[trace_name])
                multi_vector_count += 1
            layout = load(directory / 'kv-layout.json')
            assert layout['visible_tokens'] == meta['head']['length'] and layout['page_rows'] == 16
            assert len(layout['pages']) == (layout['visible_tokens'] + 15) // 16 and len(set(layout['pages'])) == len(layout['pages'])
            raw_manifest[str(directory / 'kv-layout.json')] = identity(directory / 'kv-layout.json')
            if index:
                episode = row['rounds'][index - 1]
                assert episode == { 'pending':meta['pending'], 'draft':meta['proposal'],
                    'target_first':meta['target_first'], 'target_second':meta['target_second'],
                    'accepted_draft':meta['accepted'], 'committed_target_rows':meta['processed_target'], 'draft_rows':meta['processed_draft'] }
    assert multi_vector_count == 266
    counters = ['generated_tokens','generated_decode_tokens','actual_graph_calls','prefill_graph_calls','decode_graph_calls',
        'prefill_target_rows','prefill_draft_rows','verified_target_rows','draft_rows','actual_target_rows','actual_draft_rows',
        'committed_target_rows','committed_target_decode_rows','draft_rounds','agreements','accepted_drafts']
    assert all(multi[key] == sum(row[key] for row in session_results.values()) for key in counters)
    assert (multi['actual_target_rows'],multi['actual_draft_rows'],multi['verified_target_rows'],multi['draft_rows'],multi['generated_tokens']) == (48,45,10,7,10)
    assert session_results['B']['generated_ids'][-1] == 248046 and session_results['B']['accepted_drafts'] == 0
    sum_session_wall = sum(row['session_seconds'] for row in session_results.values())
    assert multi['session_seconds'] == session_results['A']['session_seconds']
    assert not math.isclose(multi['session_seconds'], sum_session_wall, rel_tol=1e-12)
    assert multi['startup_to_endpoint_seconds'] == max(row['startup_to_endpoint_seconds'] for row in session_results.values())

    error_report_path = HERE / 'cli-errors-analysis.json'
    errors = load(error_report_path)
    assert errors['status'] == 'PASS_EXPECTED_EARLY_VALIDATION' and len(errors['cases']) == 12
    error_cases = []
    for case in errors['cases']:
        terminal_path = Path(case['terminal']['path'])
        assert identity(terminal_path) == case['terminal']
        terminal = load(terminal_path)
        assert terminal['exit'] == case['exit'] == 1 and terminal['terminal']
        command = terminal['command']; inputs = Path(command[command.index('--inputs') + 1])
        assert not (inputs / 'weights.tsv').exists() and case['missing_weight_manifest'] and case['expected_validation']
        stderr = (terminal_path.parent / 'run.stderr.log').read_text()
        assert stderr == case['stderr']
        assert all(text not in stderr for text in ['resident text weights:', 'weights_load_seconds=', 'pinned_weight_loader', 'cannot open weight'])
        error_cases.append(dict(name=case['name'], terminal=identity(terminal_path), stderr=identity(terminal_path.parent / 'run.stderr.log'),
                                exit=1, missing_weight_manifest=True, no_weight_loading_log=True))
    report = dict(status='PASS_INDEPENDENT_HOST_REVIEW_OF_8_ACTUAL_EXIT0_CLI_PROCESSES',
        compiled_source=identity(compiled_current), current_image=image_current['image'], processes=process_records,
        before_current=single_comparisons, schedule=dict(session='default', semantic_work_and_rounds_equal=True, trace_vectors_byte_equal=6),
        multi=dict(dispatch=multi['dispatch'], sessions={key:dict(generated_ids=value['generated_ids'],rounds=value['rounds'],
            visible_tokens=value['visible_tokens'],draft_frontier=value['draft_frontier'],draft_lag=value['draft_lag']) for key,value in session_results.items()},
            vectors_byte_equal_to_sequential_probe=266, components_per_episode=38, actual_graph_episodes=7,
            aggregate_work={key:multi[key] for key in counters}, shared_backing_bytes=multi['shared_backing_bytes'],
            global_wall_seconds=multi['session_seconds'], sum_request_latency_seconds=sum_session_wall,
            global_wall_is_once_interval_not_sum=True, P_plus_D_equals_wall=True),
        totals=dict(native_success_processes=8,before_current_trace_pairs=12,schedule_trace_pairs=6,multi_probe_trace_pairs=266,
                    all_byte_equal_pairs=len(comparisons), trace_numeric_raw_files=296, expected_failure_processes=12),
        expected_errors=dict(reference=identity(error_report_path), cases=error_cases),
        raw_identities=list(raw_manifest.values()), comparisons=comparisons,
        primary_refs=[identity(Path(__file__)),identity(X / 'qwen-ready-attempt2.json'),identity(X / 'probe-run1/vectors/observation.json'),
                      identity(HERE / 'probe-analysis.json')],
        limits=['These eight runs include decisions/full trace dump overhead and are diagnostic, not a performance window or speedup claim.',
                'CLI full trace directly checks36 conv/GDN plus logits/hidden (38 per episode); target/draft KV and carry/prior raw payloads are covered by the separate54-class permanent probe, not newly exported by CLI.',
                'MTP sessions are serial active R1 with independent complete heads and early EOS. No simultaneous MTP R2, prefix caching, eviction/recompute, distributed serving or quality guarantee is inferred.',
                'Global P spans first request start to last prefill endpoint, including intervening host/trace/admission costs. D spans that boundary to final endpoint; per-request latencies overlap and must not be summed as service wall.',
                'Missing-manifest error fixtures plus exact expected early validation and absence of loader output are checked; no model/GPU work was launched by this offline checker.'])
    assert len(comparisons) == 284
    assert len([row for row in raw_manifest.values() if row.get('dtype')]) == 296
    args.output.write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(dict(status=report['status'],totals=report['totals'],multi=report['multi'],output=str(args.output))))


if __name__ == '__main__':
    main()
