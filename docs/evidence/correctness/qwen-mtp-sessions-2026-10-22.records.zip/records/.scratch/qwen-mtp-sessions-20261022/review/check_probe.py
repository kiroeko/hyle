"""Independently read the bounded probe's canonical raw payloads (host only)."""
from pathlib import Path
import argparse
import hashlib
import json
import numpy as np

HERE = Path(__file__).resolve().parent
X = HERE.parent


def load(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def identity(path):
    raw = path.read_bytes()
    return dict(path=str(path.resolve()), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


def values(raw, dtype):
    if dtype == 'BF16':
        assert len(raw) % 2 == 0
        return (np.frombuffer(raw, dtype='<u2').astype(np.uint32) << 16).view(np.float32)
    assert dtype == 'F32' and len(raw) % 4 == 0
    return np.frombuffer(raw, dtype='<f4')


def expected_vectors(meta):
    head = meta['head']
    result = {}
    for layer in range(24):
        if layer % 4 != 3:
            result[f'layer{layer}.conv.bf16'] = ('BF16', 3 * 6144 * 2)
            result[f'layer{layer}.gdn.f32'] = ('F32', 16 * 128 * 128 * 4)
    for layer in range(6):
        for kind in ['key', 'value']:
            result[f'target{layer}.{kind}.bf16'] = ('BF16', head['length'] * 1024)
    for kind in ['key', 'value']:
        result[f'draft.{kind}.bf16'] = ('BF16', head['draft_frontier'] * 1024)
    result['carry.bf16'] = ('BF16', head['carry_bytes'])
    result['prior.bf16'] = ('BF16', head['prior_bytes'])
    target_rows = 2 if meta['role'] in (3, 4) else 1
    result['output.logits.f32'] = ('F32', target_rows * 248320 * 4)
    result['output.hidden.bf16'] = ('BF16', target_rows * 2048 * 2)
    assert len(result) == 54
    return result


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--run', type=Path, default=X / 'probe-run1')
    parser.add_argument('--output', type=Path, default=HERE / 'probe-analysis.json')
    args = parser.parse_args()
    run = args.run.resolve()
    observation_path = run / 'vectors/observation.json'
    data = load(observation_path)
    ready = load(X / 'mtp_session-ready-attempt2.json')
    result = load(run / 'run.result.json')
    assert result['terminal'] and result['exit'] == 0
    assert Path(result['command'][0]) == Path(ready['image']['path'])
    assert load(run / 'identity.json') == ready
    compiled = load(X / 'compile2/mtp_session/identity.json')
    assert compiled['source'] == ready['source'] and compiled['main'] == ready['main']
    probe_source = X / 'compile2/mtp_session/source/tools/qwen35_text/mtp_session_probe.cc'
    assert identity(probe_source)['sha256'] == ready['source']['sha256']
    assert identity(X / 'before/tools/qwen35_text/main.cc')['sha256'] == ready['main']['sha256']
    assert load(X / 'compile1/mtp_session/compile.result.json')['exit'] == 2
    assert load(X / 'compile2/mtp_session/compile.result.json')['exit'] == 0
    assert load(X / 'mtp_session-link2/link.result.json')['exit'] == 0
    source = probe_source.read_text()
    assert 'baseline == actual.bytes' in source
    assert 'same(*idle, image(model, *other.session->head))' in source
    assert 'model.snapshot_versions.live == 0' in source and 'model.cache_plan.snapshot_slots' in source

    episodes = data['episodes']
    reference = [row for row in episodes if row['reference']]
    actual = [row for row in episodes if not row['reference']]
    assert len(episodes) == 14 and len(reference) == len(actual) == 7
    assert [(row['session'], row['step']) for row in actual] == [
        ('A', 0), ('B', 0), ('A', 1), ('B', 1), ('A', 2), ('A', 3), ('A', 4)]
    ref_meta = {(row['session'], row['step']): row['metadata'] for row in reference}
    assert all(row['metadata'] == ref_meta[row['session'], row['step']] for row in actual)
    for index, row in enumerate(episodes):
        assert row['execution_parity_after'] == (index + 1) % 2
        meta = row['metadata']; head = meta['head']; generated = meta['generated_ids']
        assert head['next_id'] == generated[-1]
        assert head['draft_frontier'] + head['lag'] == head['length']
        assert head['carry_bytes'] == 4096 and head['prior_bytes'] == (4096 if head['lag'] else 0)
        if head['lag']:
            assert head['catchup_token'] == meta['proposal'] and meta['accepted']
        else:
            assert head['catchup_token'] == -1
        if row['step']:
            previous = ref_meta[row['session'], row['step'] - 1]
            assert meta['pending'] == previous['head']['next_id']
            assert meta['processed_target'] == (2 if meta['accepted'] else 1)
            assert head['length'] == previous['head']['length'] + meta['processed_target']
            assert head['draft_frontier'] == previous['head']['draft_frontier'] + meta['processed_draft']
            assert meta['processed_draft'] == previous['head']['lag'] + 1
            assert generated == previous['generated_ids'] + [meta['target_first']] + ([meta['target_second']] if meta['accepted'] else [])
    a_final = ref_meta['A', 4]; b_final = ref_meta['B', 1]
    assert a_final['generated_ids'] == [198, 248045, 74455, 271, 248068, 271, 248069, 271]
    assert b_final['generated_ids'] == [20, 248046]
    assert b_final['agreed'] and not b_final['accepted'] and b_final['processed_target'] == 1
    assert b_final['head']['length'] == b_final['head']['draft_frontier'] == 24
    assert data['stopped_EOS_session_B'] and data['A_calls_after_B_stop'] == 3
    assert data['idle_head_full_byte_checks'] == 4
    assert data['peak_live_snapshot_versions'] == data['snapshot_slots'] == 3
    assert data['state_slots'] == 4 and data['hidden_slots'] == 6 and data['final_live_snapshot_versions'] == 0
    payload = 18 * (3 * 6144 * 2 + 16 * 128 * 128 * 4)
    bank = (2 * 4 + 1) * 16 * 1024 + 1
    expected_backing = 14 * bank + payload * 4 + 36 + 6 * 4096 + 1
    assert expected_backing == data['managed_backing_bytes'] == data['planned_backing_bytes'] == 80_240_691

    manifests = {}
    per_step = []
    for owner, steps in zip(['A', 'B'], data['baseline']):
        assert len(steps) == (5 if owner == 'A' else 2)
        for step_index, step in enumerate(steps):
            assert step['metadata'] == ref_meta[owner, step_index]
            expected = expected_vectors(step['metadata'])
            assert len(step['vectors']) == 54
            assert {row['name'] for row in step['vectors']} == set(expected)
            total = 0
            for row in step['vectors']:
                dtype, size = expected[row['name']]
                path = Path(row['path']).resolve()
                assert path.is_relative_to(run / 'vectors') and (row['dtype'], row['bytes']) == (dtype, size)
                raw = path.read_bytes(); assert len(raw) == size
                array = values(raw, dtype)
                nonfinite = int(np.count_nonzero(~np.isfinite(array)))
                assert nonfinite == 0
                manifest = dict(path=str(path), bytes=size, sha256=hashlib.sha256(raw).hexdigest(),
                                dtype=dtype, elements=int(array.size), nonfinite=nonfinite)
                manifests[str(path)] = manifest
                total += size
            per_step.append(dict(session=owner, step=step_index, metadata=step['metadata'], vectors=54, raw_bytes=total))
    assert len(manifests) == len(data['vectors']) == 378
    reused = distinct_actual = 0
    checked = []
    for metric in data['vectors']:
        owner, step_text, name = metric['name'].split('/', 2)
        step_index = int(step_text.removeprefix('step'))
        meta = ref_meta[owner, step_index]
        dtype, size = expected_vectors(meta)[name]
        a_path, b_path = Path(metric['baseline']).resolve(), Path(metric['actual']).resolve()
        a, b = a_path.read_bytes(), b_path.read_bytes()
        assert len(a) == len(b) == metric['bytes'] == size and metric['dtype'] == dtype
        equal = a == b
        assert equal == metric['byte_equal'] and equal
        va, vb = values(a, dtype), values(b, dtype)
        nonfinite_a = int(np.count_nonzero(~np.isfinite(va)))
        nonfinite_b = int(np.count_nonzero(~np.isfinite(vb)))
        assert nonfinite_a == metric['nonfinite_baseline'] == 0 and nonfinite_b == metric['nonfinite_actual'] == 0
        assert metric['max_abs'] == metric['squared_error'] == 0
        assert metric['actual_reuses_baseline_payload'] == (a_path == b_path)
        reused += a_path == b_path; distinct_actual += a_path != b_path
        checked.append(dict(name=metric['name'], bytes=size, dtype=dtype, canonical_baseline=str(a_path),
            canonical_actual=str(b_path), sha256=hashlib.sha256(a).hexdigest(), canonical_byte_equal=equal,
            actual_reuses_baseline_payload=a_path == b_path, nonfinite=nonfinite_b))
    assert reused == 378 and distinct_actual == 0
    assert data['status'] == 'PASS_BYTE_EXACT' and data['all_vectors_byte_equal'] and data['all_finite']
    capture = {key: dict(recorded=sum(row['capture_recorded'] for row in rows), reused=sum(row['capture_reused'] for row in rows))
               for key, rows in [('baseline', reference), ('interleaved', actual)]}
    assert capture == dict(baseline=dict(recorded=12, reused=0), interleaved=dict(recorded=12, reused=0))
    records = [X / 'mtp_session-ready-attempt2.json', X / 'compile2/mtp_session/identity.json',
               X / 'compile2/mtp_session/compile.result.json', X / 'mtp_session-link2/link-plan.json',
               X / 'mtp_session-link2/link.result.json', X / 'mtp_session-link2/runtime-environment.json',
               X / 'compile1/mtp_session/compile.result.json', run / 'run.result.json',
               run / 'run.stdout.log', run / 'run.stderr.log', observation_path, probe_source,
               X / 'before/tools/qwen35_text/main.cc', Path(__file__)]
    report = dict(status='PASS_HOST_REVIEW_OF_ACTUAL_EXIT0', run=str(run), records=[identity(path) for path in records],
        native_image_identity_from_actual_ready=ready['image'], compiled_source=ready['source'], compiled_main=ready['main'],
        totals=dict(graph_episodes=14, sequential_baseline_episodes=7, interleaved_episodes=7,
                    corresponding_steps=7, vector_classes_per_step=54, comparisons=378,
                    canonical_raw_files=378, canonical_raw_bytes=sum(row['bytes'] for row in manifests.values()),
                    finite_raw_elements=sum(row['elements'] for row in manifests.values()),
                    canonical_raw_nonfinite=0, canonical_byte_equal_comparisons=378,
                    actual_payload_aliases_to_baseline=reused, distinct_retained_actual_payloads=distinct_actual),
        sequence=dict(interleaved_order=[dict(session=row['session'], step=row['step']) for row in actual],
                      A_final=a_final, B_final=b_final, idle_head_runtime_byte_checks=4,
                      A_calls_after_B_EOS_stop=3, all_transition_metadata_equal=True),
        capture=capture, actual_prepared_resources=dict(phases=data['actual_phases'], slots=data['actual_slots']),
        capacity=dict(N=2, R=1, candidate_boundaries=2, peak_versions=3, snapshot_slots=3, state_slots=4,
                      hidden_slots=6, final_snapshot_versions=0, shared_backing_bytes=expected_backing,
                      note='Final Session versions0 does not release Model-owned shared arena/pool backing; it remains charged.'),
        per_step=per_step, raw_identities=list(manifests.values()), canonical_comparisons=checked,
        limits=['All actual values were compared as complete byte arrays in the compiled native probe; equal actual payloads were deliberately not duplicated. Offline SHA/byte comparison proves the retained canonical payloads and their reuse map, not a second retained copy of the discarded actual readback.',
                'Idle-head invariance and in-flight candidate bounds are successful runtime assertions in the compiled source, not separately retained idle-oracle raw payloads.',
                'Both stages used the same Model/R1 shapes and auto capture plan. Actual capture counters show24 recordings and0 reuses; this probe does not prove capture reuse across sessions.',
                'No simultaneous multi-request MTP R2, CLI scheduler, network service, prefix fork/COW, cancellation injection, cross-platform execution, TPS, or cross-engine numerical quality is certified by this probe.',
                'First C3538 compile failure remains recorded. Revision2 only split three std::array declarations; actual final strict compilation/link/run succeeded.'])
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(dict(status=report['status'], totals=report['totals'], capture=capture,
                          capacity=report['capacity'], output=str(args.output))))


if __name__ == '__main__':
    main()
