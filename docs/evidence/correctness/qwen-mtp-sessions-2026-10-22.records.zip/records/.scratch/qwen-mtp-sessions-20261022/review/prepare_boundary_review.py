"""Read-only current-source MTP session boundary review; no model execution."""
from pathlib import Path
import hashlib
import json

R = Path(__file__).resolve().parent
ROOT = R.parents[2]


def identity(path):
    data = path.read_bytes()
    return dict(path=str(path.resolve()), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())


def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


files = {name: ROOT / name for name in (
    'tools/qwen35_text/main.cc', 'tools/qwen35_text/session_state.h',
    'tools/qwen35_text/prefix_cache.h', 'tools/qwen35_text/retirement_probe.cc',
    'src/graph_batch/paged_append.cc', 'src/compute_batch/paged_arena.cc')}
source_ids = {name: identity(path) for name, path in files.items()}


def anchor(name, needle):
    lines = files[name].read_text(encoding='utf-8').splitlines()
    matches = [i + 1 for i, line in enumerate(lines) if needle in line]
    if not matches:
        raise ValueError(f'anchor absent: {name}: {needle}')
    return dict(file=name, lines=matches, source_SHA256=source_ids[name]['sha256'], text=needle)


MAIN = 'tools/qwen35_text/main.cc'
STATE = 'tools/qwen35_text/session_state.h'
PREFIX = 'tools/qwen35_text/prefix_cache.h'
APPEND = 'src/graph_batch/paged_append.cc'
ARENA = 'src/compute_batch/paged_arena.cc'

earlier = []
for stage, verify_rows in [('qwen-mtp-retirement-20261022', 2), ('qwen-mtp-window-20261022', 1)]:
    run = ROOT / '.scratch' / stage / 'retirement-run1'
    terminal = read(run / 'run.result.json')
    assert terminal['terminal'] and terminal['exit'] == 0
    observation = read(run / 'run.stdout.log')
    assert observation['status'] == 'PASS' and observation['pending_target_query_rows'] == verify_rows
    old_identity = read(run / 'identity.json')
    earlier.append(dict(stage=stage, terminal=identity(run / 'run.result.json'),
        observation=identity(run / 'run.stdout.log'), runtime_identity=identity(run / 'identity.json'),
        reviewed_main_matches_that_record=source_ids[MAIN]['sha256'] == old_identity['main']['sha256'],
        exercised=dict(target_query_rows=verify_rows, draft_query_rows=observation['pending_draft_query_rows'],
            bound_banks=observation['bound_append_banks'], graph_submissions=observation['actual_graph_submissions'],
            busy_prepare_rejections=observation['busy_prepare_rejections'],
            completion_dropped=observation['dropped_live_public_completion'],
            idle_alias_retire_did_not_close_active_carrier=True,
            same_retired_slot_rebuilt=observation['same_slot_rebuilt_after_close'],
            old_target_draft_KV_unchanged=observation['old_target_and_draft_kv_bytes_unchanged'],
            old_recurrent_unchanged=observation['old_recurrent_resources_byte_unchanged'],
            old_carry_prior_unchanged=observation['old_carry_and_prior_bytes_unchanged'],
            selector_failure_published=observation['selector_failure_published_head']),
        scope='Earlier actual native lifetime/complete-prefix proof, not a new interleaved sessions or CLI run. Full historical closure remains in its original record.'))

report = dict(
    status='Narrow read-only review: no blocking cross-session state-mixing path found for valid externally serialized Model/Session calls. Multi-session runtime/CLI is not signed by source review.',
    reviewed_sources=list(source_ids.values()),
    execution_boundary=[
        dict(fact='Families and carriers include GraphRole in their key. Phase IO is shared by all sessions using that role/R/T; it is not per-session memory.',
             proof=[anchor(MAIN, 'struct ExecutionShape final'), anchor(MAIN, 'std::map<ExecutionShape, std::unique_ptr<Phase>>')]),
        dict(fact='One Model has at most one active StepState and one borrowed carrier across both parity slots and all roles. Prepare rejects a second Session while any original loan remains. Every StepMember strongly pins its Session/base/candidate.',
             proof=[anchor(MAIN, 'if (carrier_borrowed || active_step)'), anchor(MAIN, 'candidate->members.push_back'), anchor(MAIN, 'step.candidate_admission = &carrier_borrowed')]),
        dict(fact='Each episode binds current Session conv/GDN inputs and fresh owned outputs. MTP carry/prior, draft positions and catchup token are rebound/written from the member.base snapshot before native preparation; the shared phase does not retain a session identity as mathematical state.',
             proof=[anchor(MAIN, 'void prepare_draft_append'), anchor(MAIN, 'member.base->carry_hidden'), anchor(MAIN, 'member.base->prior_hidden'), anchor(MAIN, 'step.members[j].base->state[i]')]),
        dict(fact='After terminal wait, selector chooses the accepted row. All36 recurrent outputs and carry/prior are exported before any take; all14 append permissions are taken, ready frames validated, state ports unbound, then one nonthrowing head swap publishes the complete target+draft state. Readback keeps the carrier borrowed after the swap.',
             proof=[anchor(MAIN, 'Export every participant'), anchor(MAIN, 'validate_mtp_snapshot(*member.next)'), anchor(MAIN, 'check(run.unbind(phase.state_resource_ports))'), anchor(MAIN, 'return_readback.admission = std::exchange')]),
        dict(fact='Global execution parity advances only on complete publication. It chooses replay identity, not Session state; cancelled/failed episodes keep it unchanged. Admission is released only after full abort cleanup or successful host readback.',
             proof=[anchor(MAIN, 'execution_parity = 1 - execution_parity'), anchor(MAIN, 'hyle::Result<bool> try_abort() noexcept'), anchor(MAIN, 'release_admission();')])
    ],
    complete_prefix_and_tail_ownership=dict(
        conclusion='Safe source path: importing a complete Snapshot copies no weights/plan/state and grants no target/draft tail write capability. Missing appender rights force fresh dirty pages and exact inherited-prefix COW in both inventories.',
        proof=[anchor(MAIN, 'if (prefix) session->head = std::move(prefix)'),
               anchor(MAIN, 'session.draft_tail_head == member.base.get()'),
               anchor(MAIN, 'session.tail_head == member.base.get()'),
               anchor(MAIN, 'auto reservation = take(draft_inventory.acquire())'),
               anchor(APPEND, 'retained prefix must use a distinct dirty COW page'),
               anchor(APPEND, 'p->ranges.push_back({index,0,ordinal'),
               anchor(ARENA, "not the slot's current frontier"), anchor(ARENA, 'Status PagedPageAppender::reserve_rows')],
        details=[
            'Session has its own move-only target12/draft2 appender arrays and corresponding head pointer. Prefix adoption initializes neither. Sharing readonly Snapshot/frames is not permission to append in place.',
            'Every reusable tail must match original page, initialized frontier and current committed head, then pass real reserve_rows generation/native-use checks. A failed reservation falls back to COW; no shared_ptr count or free physical suffix is used as authority.',
            'The core COW range copies exactly the old bounded initialized prefix from its real ReadLease. New layout/root/page/frame guards remain validated; bounded older readers cannot access newly appended rows.',
            'An externally retained old prefix may consume an additional distinct committed version after publication. Directory eviction alone cannot assume it was freed if another Session/Hit still owns it.'
        ]),
    state_and_budget=dict(
        complete_head='6 targetK +6 targetV frames;18conv BF16 +18GDN F32 leases; target length/next_id; draft K/V frames/page refs/frontier/lag/catchup token; owned postnorm carry and lag1 prior hidden.',
        proof=[anchor(STATE, 'struct Snapshot final'), anchor(STATE, 'struct DraftState final'),
               anchor(MAIN, 'void validate_mtp_snapshot'), anchor(STATE, 'const auto snapshots ='),
               anchor(STATE, 'const auto states ='), anchor(STATE, 'const auto hidden_slots ='),
               anchor(STATE, 'Policy eligibility never proves native retirement')],
        limits='N is distinct retained Snapshot capacity, not number of aliases or directory entries. R is active candidate width; MTP currently only R1. Candidate state uses N+2R pool slots, N+R Snapshot slots, two hidden rows per Snapshot capacity, separate target/draft inventories, and one physical cache budget reservation per real backing.',
        admission='Finite snapshot/state/page exhaustion rejects safely; no automatic policy split/eviction or general MTP rebuild is implied. PageRef eligibility is always checked again by actual native PagedArena acquire.'),
    identity_and_prefix_domain=dict(
        current_key='PrefixCache uses exact tokens plus (model pointer, math identity pointer), not GraphRole. math identity is the stable families/probe_families container identity.',
        conclusion='Current model-level separation is sufficient: one Model fixes cache_plan.draft_cache, weight inventory and complete state family. create_session and prepare_evaluations reject plain-vs-MTP mode mismatch; imported heads must match this model/math and have matching optional draft + valid frontier/hidden state. MTP roles intentionally share one complete-state domain.',
        proof=[anchor(PREFIX, 'struct Domain final'), anchor(PREFIX, 'head->model == model'),
               anchor(MAIN, 'const void *math_identity() const noexcept'),
               anchor(MAIN, 'cache_plan.draft_cache != has_mtp(role)'),
               anchor(MAIN, 'prefix->model != this'), anchor(MAIN, 'cache_plan.draft_cache != head.draft.has_value()')],
        caution='This is not a general graph-role fingerprint. If a future Model admits both plain and MTP state modes or different math/provider identities under the same container, its domain contract must be made explicit before sharing entries. Current mode rejection must not be bypassed.'),
    real_admission_or_integration_limits=[
        dict(issue='A complete lag1 MTP prefix is a valid generation fork, but it cannot immediately accept arbitrary multi-token MtpPrefill input.',
             behavior='prepare_evaluations requires snapshot.lag == draft_lag(role). MtpPrefill has lag0; CatchupSingle/Round consume original next_id. Sending a lag1 head to MtpPrefill errors before mutation, rather than silently correcting it.',
             minimum='First CLI slice can publish/adopt complete prompt lag0 boundaries and choose catchup roles only for normal generation. Arbitrary user prompt append to a lag1 generated head needs a real catchup-prefill contract; do not claim that path from current code.',
             proof=[anchor(MAIN, 'session.head->draft->lag != draft_lag(role)'), anchor(MAIN, 'request.ids.front() != session.head->next_id')]),
        dict(issue='The ordinary ReplayHistory is not enough to reconstruct an arbitrary MTP generated head after eviction.',
             behavior='ReplayChunk stores only input/count/next_id; it carries no GraphRole, lag, target verify partition or draft catchup ordering. Replaying the same tokens as ordinary text or MtpPrefill does not recreate the original MTP state.',
             minimum='A direct complete Snapshot hit is safe. Initial prompt-only lag0 recovery can use exact original prompt chunks with explicit MtpPrefill(T>=2)/MtpSingle(T1) roles; otherwise reject pressure/admission or add the actual role-aware history in its own implementation.',
             proof=[anchor(PREFIX, 'struct ReplayChunk final'), anchor(PREFIX, 'inline std::shared_ptr<ReplayHistory> copy_history')]),
        dict(issue='Existing public CLI still rejects MTP schedules and multi-active use.',
             behavior='The Model can serialize multiple Session owners through its existing R1 episode API; current CLI does not yet dispatch them. This is integration work, not evidence of simultaneous MTP R2 execution.',
             proof=[anchor(MAIN, 'if (mtp_enabled && (scheduled'), anchor(MAIN, 'if (mtp_enabled) return qwen35::run_mtp')])
    ],
    failure_and_retirement=dict(
        proof=[anchor(MAIN, 'if (run->in_flight()) return false'), anchor(MAIN, 'auto recovered = g::batch::take_append'),
               anchor(MAIN, '*run = {};'), anchor(MAIN, 'auto rolled_back = tail.rollback()'),
               anchor(MAIN, 'member.next.reset(); member.base.reset();'), anchor(MAIN, 'hyle::Status Session::stop() noexcept')],
        conclusion='Stopped/failed episode retains candidate/base/14 permission owners until original native retirement. Abort then takes all bound appends, destroys the affected slot, rolls back actual reserved suffixes/discards dirty writers and releases candidate/admission. Idle Session stop has no pending run to close. Old bounded prefix remains valid even if failed publication already advanced a physical suffix; retry can fall back to COW.',
        lifetime='Model must outlive every Session/Snapshot/PrefixCache Hit and all native work. StepState strongly pins the active Session; raw pending is borrowed, cleared before active_step destruction. API is externally serialized, not a concurrent scheduler.'),
    prior_actual_lifetime_evidence=earlier,
    minimum_new_runtime_scope=[
        'One335 Model/C64/N2/R1: distinct P15/P23 Sessions, identical baseline vs interleaved role/chunk choices. Compare original full hidden/logits, 36recurrent leases, 14KV logical prefixes, carry/prior and next_id/length/frontier/lag/catchup, not only greedy IDs. Check the idle other head before/after every step.',
        'Complete lag1 prefix adoption with no target/draft tails must show distinct dirty COW pages and unchanged old prefix. Existing native lifetime probes already exercise this plus pending loan rejection, idle alias stop, Completion drop, successful-terminal selector rejection and same-slot rebuild; cite their scope rather than inventing a new matrix.',
        'Prompt lag0 PrefixCache whole-hit/adopt should issue0Graph calls and keep complete draft/hidden state. Mismatched plain/MTP domains must be rejected. Finite N exhaustion must remain explicit and count actual retained versions. No fullhit/generation correctness is inferred from source alone.'
    ],
    new_probe_coordination='new_phase owns permanent mtp_session_probe: fresh P15/P23 baseline vs interleaving, complete state bytes. This review does not sign its not-yet-run result and requests no redundant native tests.',
    actions='0 product/doc edits, 0 builds, 0 GPU, 0 Torch/model computation. Source identities bind the reviewed bytes; later CLI changes require their own diff review.')

# Fail if a concurrently edited source changed while collecting the review.
assert all(identity(files[name])['sha256'] == value['sha256'] for name, value in source_ids.items())
out = R / 'mtp-session-boundary-review.json'
out.write_text(json.dumps(report, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')
freeze = dict(status='Frozen read-only source/lifetime-scope review; not a new runtime result.',
              files=[identity(out), identity(Path(__file__))])
fp = R / 'source-review-freeze.json'
fp.write_text(json.dumps(freeze, indent=2) + '\n', encoding='utf-8')
print(json.dumps(dict(report=identity(out), freeze=identity(fp)), indent=2))
