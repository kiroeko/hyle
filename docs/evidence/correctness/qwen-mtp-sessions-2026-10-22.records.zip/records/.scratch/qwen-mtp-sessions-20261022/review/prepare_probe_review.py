"""Source-only review of the permanent focused MTP session consumer."""
from pathlib import Path
import hashlib
import json

R = Path(__file__).resolve().parent
ROOT = R.parents[2]


def identity(p):
    data = p.read_bytes()
    return dict(path=str(p.resolve()), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())


def read(p):
    return json.loads(p.read_text(encoding='utf-8-sig'))


source = ROOT / 'tools/qwen35_text/mtp_session_probe.cc'
text = source.read_text(encoding='utf-8')
source_id = identity(source)
revision = ROOT / '.scratch/qwen-mtp-sessions-20261022/implementation/source-freeze2.json'
first = revision.with_name('source-freeze.json')
assert source_id['sha256'] == read(revision)['source']['sha256']
first_data = read(first)
main = ROOT / 'tools/qwen35_text/main.cc'
assert identity(main)['sha256'] == first_data['compiled_main_dependency_required']['sha256']


def anchor(needle):
    found = [n + 1 for n, line in enumerate(text.splitlines()) if needle in line]
    if not found:
        raise ValueError(needle)
    return dict(lines=found, text=needle)


report = dict(
    status='No blocking permission/state-owner/lifetime finding in the scoped source review. This is not a runtime result or a quality threshold.',
    source=source_id, included_main=identity(main), revision2_freeze=identity(revision), first_freeze=identity(first),
    compile_history='First source d11ef7c0 had actual C3538: heterogeneous deduced std::array declarations shared one declaration. Revision2 only splits prefills/pair/single into three declarations; math/owners unchanged. Reviewer did not compile.',
    source_findings=[
        dict(subject='54 boundary classes', finding='The source captures18conv BF16 +18GDN F32,12targetKV BF16 +2draftKV BF16, carry/prior BF16, complete original Graph hidden BF16/logits F32 =54 vectors per episode. Lag0 may have an explicitly empty prior; metadata records its bytes. Full T2 outputs include both rows, while the committed head owns selected carry/state.',
             anchors=[anchor('HeadImage image('), anchor('captured.blobs.push_back({"output.logits.f32"'), anchor('captured.blobs.push_back({"output.hidden.bf16"')]),
        dict(subject='Logical KV read permissions', finding='logical_rows checks exact1request page footprint/frontier and obtains the original frame ReadLease guard matching each physical page. PagedArenaAccess::page validates arena identity. Each read is a guard subview of only remaining committed logical rows*1024B; the unused tail and full bank carrier are not read as authority. Frame page IDs may differ across baseline/interleaved runs; bytes are normalized only by logical row order.',
             anchors=[anchor('Bytes logical_rows('), anchor('const auto guards ='), anchor('selected->view()')]),
        dict(subject='Snapshot and version lifetime', finding='Sequential baseline sessions are explicitly stopped/retired before interleaving, and live versions must return0. Oracle HeadImage contains CPU byte vectors and physical-ID values, not SnapshotRef/ReadLease owners; it does not secretly occupy N committed slots. Two fresh interleaved Session owners plus one candidate are checked against snapshot_slots3, with state_slots4/hidden_slots6 and actual shared backing accounting.',
             anchors=[anchor('struct HeadImage final'), anchor('void observe('), anchor('sequential baseline retained device state'), anchor('std::array runs{')]),
        dict(subject='Shared Phase IO reads', finding='advance borrows Phase* from the admitted original episode, finishes/waits that episode, then reads its complete output tensors before any subsequent prepare. It never reads a saved phase output after another Session overwrote shared IO. Model retains the Phase and the probe remains serial.',
             anchors=[anchor('auto *phase ='), anchor('finish_mtp_round'), anchor('auto captured = image')]),
        dict(subject='Idle head immutability', finding='Before advancing one Session, the probe copies the other complete head to CPU. It then checks metadata, physical target/draft page IDs and every captured byte after the active step. This protects the idle head without retaining another GPU Snapshot version. It does not attempt to retain every replaced active head; historical complete-prefix lifetime proofs cover that separate case.',
             anchors=[anchor('const auto idle ='), anchor('if (idle)'), anchor('bool same(')]),
        dict(subject='Natural protocol and early stop', finding='Both branches choose role from their own lag/quota/context, feed their own stored pending ID, use original EOS and ordinary finish_mtp_round. No oracle token is fed into interleaved computation. Metadata includes complete target/draft frontier/lag/catchup/next IDs plus cumulative generated IDs and selected accepted boundaries; exact mismatch fails. B must stop at natural EOS while A remains live and actually advances afterward.',
             anchors=[anchor('const auto role ='), anchor('const auto pending ='), anchor('probe did not retain a live Session'), anchor('probe.after_stop_calls')]),
        dict(subject='Failure teardown', finding='Run locals unwind before Model, while active StepState strongly pins any pending Session. Model performs native abort/drain before phases/inventory destruction. The probe emits failure metadata and does not convert a thrown structural mismatch to success. Native cancellation/in-flight gate testing remains in existing retirement_probe rather than this new correctness journey.',
             anchors=[anchor('q::Model model('), anchor('Probe probe{'), anchor('probe.report("FAIL"')]),
        dict(subject='Evidence and finite values', finding='Baseline raw is stored once; byte-equal actual vectors explicitly reference that exact baseline file. Differing numeric vectors retain actual raw and full byte comparison, finite counts, maxabs/squared-error/reference-square metrics. FNV is only a compact diagnostic identity; equality compares complete bytes. Numerical differences can be reported without inventing a tolerance PASS.',
             anchors=[anchor('Metric compare('), anchor('if (!result.byte_equal)'), anchor('PASS_STRUCTURE_NUMERICAL_DIFFERENCES_RECORDED')])
    ],
    known_nonblocking_evidence_limit=dict(
        scope='Confirmed and already acknowledged by root; no source change requested for this frozen attempt.',
        detail='If transition metadata or episode count differs, save_or_compare throws before saving that failing step raw vectors. The episode JSON/failure metadata survives, but those not-yet-compared actual tensor payloads do not. A successful complete run is unaffected; do not describe a failing run as having a complete diff payload archive.',
        anchors=[anchor('require(run.step < saved.size()'), anchor('require(captured.metadata ==')]),
    exclusions=[
        'The probe is serial active R1 over two retained Session owners. It does not prove MTP R2, asynchronous simultaneous graph execution, serving/QoS, throughput or cross-engine model quality.',
        'The current CLI changes and prefix-cache integration are separate work. No prefix full-hit or arbitrary lag1 prompt continuation is tested here.',
        'Physical nonsharing is not separately asserted, but real arena permission checks, fresh Session construction and the complete idle-head byte comparison are exercised. Do not claim a new allocation-isolation test beyond those observations.',
        'No reviewer build/GPU/Torch/model execution or product/document edits.'
    ],
    prior_boundary_review=identity(R / 'mtp-session-boundary-review.json'))
assert identity(source)['sha256'] == source_id['sha256']
out = R / 'mtp-session-probe-source-review.json'
out.write_text(json.dumps(report, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')
fp = R / 'probe-source-review-freeze.json'
fp.write_text(json.dumps(dict(status='Frozen source-only review, no native runtime assertion.',
    files=[identity(out), identity(Path(__file__))]), indent=2) + '\n', encoding='utf-8')
print(json.dumps(dict(report=identity(out), freeze=identity(fp)), indent=2))
