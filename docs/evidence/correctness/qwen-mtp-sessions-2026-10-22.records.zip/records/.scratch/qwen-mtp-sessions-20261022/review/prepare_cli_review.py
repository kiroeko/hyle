"""Focused source review of generation helpers and CLI; no native execution."""
from pathlib import Path
import hashlib
import json

R = Path(__file__).resolve().parent
ROOT = R.parents[2]
X = R.parent


def identity(path):
    raw = path.read_bytes()
    return dict(path=str(path.resolve()), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


source = ROOT / 'tools/qwen35_text/main.cc'
before = X / 'before/tools/qwen35_text/main.cc'
current_id = identity(source)
assert current_id['sha256'] == '48302bd77278df98db8882e32a305800db914089dcb22c1006cf4be2f6c5faeb'
text, old = source.read_text(encoding='utf-8'), before.read_text(encoding='utf-8')
old_prefix = old[:old.index('int run_mtp(')]
ordinary = '    // These owners are declared after Model'
assert text.startswith(old_prefix)
assert old[old.index(ordinary):] == text[text.index(ordinary):]
formatter = text[text.index('void print_mtp_request('):text.index('int run_mtp(')]
assert 'request.session' not in formatter
multi = text[text.index('int run_mtp_sessions('):text.index('} // namespace qwen35', text.index('int run_mtp_sessions('))]
assert multi.rfind('model.plan_replay_uses(') < multi.index('model.prepare_execution(')
assert '("session" + std::to_string(requests.size()) + "_" + schedule.id)' in multi
compile_identity = X / 'compile2/qwen/identity.json'
assert read(compile_identity)['source']['sha256'] == current_id['sha256']
compile_result = X / 'compile2/qwen/compile.result.json'
terminal = read(compile_result)
assert terminal['exit'] == 0


def anchor(needle):
    lines = [n + 1 for n, value in enumerate(text.splitlines()) if needle in value]
    if not lines:
        raise ValueError(needle)
    return dict(lines=lines, text=needle)


report = dict(
    status='No remaining blocking source finding in final generation-helper/CLI scope. Source-only review; runtime evidence belongs to root runs.',
    source=current_id, before=identity(before), actual_strict_compile_identity=identity(compile_identity),
    actual_strict_compile_result=identity(compile_result),
    scope_proofs=dict(Model_and_all_source_before_generation_helpers_byte_unchanged=True,
                      ordinary_execution_body_after_Model_creation_byte_unchanged=True,
                      final_formatter_has_no_Session_or_head_access=True,
                      all_multi_use_plans_before_first_carrier=True),
    repaired_finding=dict(
        first_draft='ef335201064346083210369937368943f6b8087e57d9066cf76276169b0d1171',
        issue='Non-schedule MTP empty prompt could reach Model/335 weight loading before run_mtp rejected it. Its old additive capacity expression also missed the intended subtractive MTP guard.',
        resolution='Final code checks empty prompt, prompt.size()>capacity and steps-1>capacity-prompt.size() before plan/Model. The legacy additive guard now applies only to mtp-off; ordinary execution body is unchanged.',
        anchors=[anchor('MTP requires a nonempty prompt before loading weights'),
                 anchor('if (prompt.size() > capacity || steps - 1 > capacity - prompt.size())'),
                 anchor('if (!mtp_enabled && !scheduled && prompt.size() + extra.size()')],
        history='Original ef335 compile1 success and this final compile2 are retained; repair does not pretend the first source was identical.'),
    reviewed=[
        dict(subject='Input/R/N/bytes early admission', finding='MTP auto resolves toR1 and rejects R>1, prefixauto, forced tapes, continuation, probes and prep diagnostics. Scheduled inputs must contain exactly one nonempty prompt phase. Steps is1..128; every prompt+requested output input bound uses short-circuit subtraction. N must retain all supplied requests; explicit cache bytes cannot silently shrink MTP N. These checks precede Model/weights.',
             anchors=[anchor('active_sequences = 1;'), anchor('request.phases.size() != 1'),
                      anchor('steps - 1 > capacity - tokens'), anchor('cached_slots < schedules.size()'),
                      anchor('--cache-bytes must hold all MTP sessions'), anchor('qwen35::Model model(')]),
        dict(subject='P1 and finite family/use order', finding='Prompt union T>=2 is one MtpPrefill family. P1 and generation T1 share one MtpSingle family without duplicate prepare. The other original three generation roles are prepared once when needed. All checked per-role plans are registered before any carrier. Only first actual prefill is prewarmed; later prefills initialize lazily at their true global parity. Original recurring T2 roles can prepare both slots; no carrier is cloned per Session.',
             anchors=[anchor('if (!prefill_chunks.empty())'), anchor('if (prefill_counts.contains(1) || steps > 1)'),
                      anchor('role != GraphRole::kMtpSingle'), anchor('const auto decode_bound ='),
                      anchor('const std::array first_prefill{')]),
        dict(subject='One helper and original math', finding='Legacy single and scheduled multi call advance_mtp_request. Each visit performs exactly one original prepare/submit/finish episode using its own Session lag/quota/pending/EOS; accepted two-ID output remains one dispatch. No alternate executor, state-rebuild fallback, padding or MTP R2 is added. Model code is unchanged.',
             anchors=[anchor('void advance_mtp_request('), anchor('finish_mtp_round(*request.session'),
                      anchor('while (!request.done) advance_mtp_request'), anchor('advance_mtp_request(model, request, steps')]),
        dict(subject='Session lifetime and post-retirement stats', finding='Request records own Session pointers and prompt spans into validated schedules that outlive the call; records die before Model. Each complete step saves visible_tokens/frontier/lag and generated/round ledgers before retirement. Multi stop calls original stop+try_retire and resets Session only after success. Formatter and aggregate read only saved host fields; they do not dereference a retired head.',
             anchors=[anchor('request.visible_tokens = request.session->length()'), anchor('void retire_mtp_request('),
                      anchor('request.session->try_retire()'), anchor('if (request.done) { retire_mtp_request'),
                      anchor('void print_mtp_request(')]),
        dict(subject='Single endpoints and JSON compatibility', finding='Single still admits its Session and prepares original carriers before ready. Prefill starts before original prepare; finish supplies unchanged host_endpoint before trailing diagnostics. Decode is first-to-last host endpoint; session/startup retain the same endpoints. Extracted formatter preserves original single fields/counters; single stop occurs after formatting and any retirement error still makes the process fail. New helper does not add model IO copies.',
             anchors=[anchor('request.prefill_start = Clock::now()'), anchor('&request.prefill_step_seconds, &request.prefill_endpoint'),
                      anchor('const auto decode_seconds ='), anchor('MtpGenerationRequest request({}, prompt'),
                      anchor('print_mtp_request(request, steps, startup, ready);')]),
        dict(subject='Global multi-session timing and work', finding='First pass admits/prefills each request; later round-robin visits skip done requests and retire EOS/quota members. Global session time is one first-prefill-start to final host_endpoint interval, never a sum of request latency/TPS. Global prefill spans all initial prefills; decode follows the last prefill endpoint. Graph calls, target/draft/committed rows and generated IDs are counted from actual successful rounds, while each nested request latency may include others service.',
             anchors=[anchor('while (remaining) for ('), anchor('dispatch.push_back(index); endpoint ='),
                      anchor('const auto start = requests.front().prefill_start'), anchor('R1 interleaving measures one wall interval')]),
        dict(subject='Trace and observer identity', finding='Each scheduled request trace is session<manifestindex>_<validatedsafeID>, preventing cross-session overwrite while ordinary single keeps original path. Memory names are safely ID-prefixed generation markers. Marker receipt is not the timing endpoint and diagnostic runs are identified in JSON.',
             anchors=[anchor('("session" + std::to_string(requests.size()) + "_" + schedule.id)'),
                      anchor('memory_name(id.empty() ? "generation"'), anchor('"_prefill_begin\\n"')])
    ],
    finite_limits=[
        'MTP remains one active request per episode with all declared sessions retained. No prefix cache, eviction/rebuild, multi-turn user prompt, R2 MTP, scheduler concurrency, serving fairness, or quality/throughput claim is delivered by source review.',
        'Prefill and generation per-slot use counts are conservative finite upper bounds; they are not observed capture counts or proof of optimal capture policy.',
        'Nested request decode/session latency includes interleaving and cannot be summed into global wall time or compared as isolated per-user throughput.',
        'Single prints its JSON before explicit final retirement; consumers must still check the real process exit rather than stdout alone. Runtime errors are not signed away.',
        'Source changes only; reviewer performed0 builds/GPU/model computations. The compile record cited was produced by root, not by this script.'
    ],
    design=identity(R / 'cli-mtp-sessions-design.json'))
assert identity(source)['sha256'] == current_id['sha256']
out = R / 'cli-source-review.json'
out.write_text(json.dumps(report, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')
fp = R / 'cli-source-review-freeze.json'
fp.write_text(json.dumps(dict(status='Frozen final48302 source review; not a native runtime approval.',
    files=[identity(out), identity(Path(__file__))]), indent=2) + '\n', encoding='utf-8')
print(json.dumps(dict(report=identity(out), freeze=identity(fp)), indent=2))
