"""One real R1 interleaved MTP state/isolation probe, not a timing run."""
from pathlib import Path
import importlib.util, os, sys
sys.dont_write_bytecode=True
X=Path(__file__).resolve().parent; R=X.parents[1]
s=importlib.util.spec_from_file_location('build',X/'build_hyle.py'); h=importlib.util.module_from_spec(s);s.loader.exec_module(h)
b,c=h.b,h.c
ready=c.read(X/'mtp_session-ready-attempt2.json')
assert all(h.same(ready[k]) for k in ('image','source','main'))
out=X/'probe-run1';out.mkdir(exist_ok=False)
env=os.environ.copy();env['PATH']=c.read(ready['runtime_environment']['path'])['PATH']
command=[ready['image']['path'],'--inputs',str(R/'.scratch/qwen-mtp-weights-20261022/prepared'),'--output',str(out/'vectors')]
c.save(out/'identity.json',ready)
c.save(out/'plan.json',dict(command=command,diagnostic=True,timing_evidence=False,model_objects=1,weight_tensors=335,capacity=64,resident_sessions=2,active_sequences=1,source_prompt='original prepared first15 / first23',baseline='same Model, plan and finite GraphRoles; each sequential baseline is retired before the next is created',reuse='no duplicate SDK, model weight or native build'))
c.execute('run',command,env,out)
