from pathlib import Path
import difflib
import hashlib
import json
import re

stage = Path(__file__).resolve().parent
root = stage.parents[1]
relative = Path('tools/qwen35_text/main.cc')
before = (stage / 'before' / relative).read_text(encoding='utf-8')
path = root / relative
current = path.read_text(encoding='utf-8')
identity = lambda p: {'path': str(p.relative_to(root)).replace('\\', '/'), 'bytes': p.stat().st_size,
                      'sha256': hashlib.sha256(p.read_bytes()).hexdigest()}
# Graph/Model/Session implementation and the complete old ordinary driver are
# unchanged; this isolates the new policy to request progression and CLI input.
assert before[:before.index('int run_mtp(Model &model,')] == current[:current.index('struct MtpGenerationRequest {')]
ordinary = '    // These owners are declared after Model, including on exception paths.'
assert before[before.index(ordinary):] == current[current.index(ordinary):]
# The shared per-request formatter keeps the exact legacy JSON key sequence.
old_report = before[before.index('  std::cout << std::setprecision(17)', before.index('int run_mtp(')):before.index('} // namespace qwen35')]
new_report = current[current.index('  std::cout << std::setprecision(17)', current.index('void print_mtp_request(')):current.index('\nint run_mtp(Model &model,')]
keys = lambda s: re.findall(r'\\"([A-Za-z_]+)\\"\s*:', s)
assert keys(old_report) == keys(new_report), (keys(old_report), keys(new_report))
top_keys = keys(new_report[:new_report.index('  for (std::size_t i = 0; i < rounds.size();')])
assert len(set(top_keys)) == len(top_keys)
# Original single shape planning/preparation order is preserved exactly, with
# its Session still admitted before both prewarm and ready.
old_prepare = before[before.index('  const auto prefill_role', before.index('int run_mtp(')):before.index('  auto session = model.create_session', before.index('int run_mtp('))]
new_prepare = current[current.index('  const auto prefill_role', current.index('int run_mtp(')):current.index('  MtpGenerationRequest request', current.index('int run_mtp('))]
assert old_prepare == new_prepare
assert current.index('  request.session = model.create_session', current.index('int run_mtp(')) < current.index('  const auto ready =', current.index('int run_mtp('))
source = stage / 'source' / relative
source.parent.mkdir(parents=True, exist_ok=True)
source.write_bytes(path.read_bytes())
diff = stage / 'main.cc.diff'
diff.write_text(''.join(difflib.unified_diff(before.splitlines(True), current.splitlines(True),
    fromfile='before/tools/qwen35_text/main.cc', tofile='tools/qwen35_text/main.cc')), encoding='utf-8', newline='\n')
report = {
 'status': 'source frozen; static checks only, build and device execution owned by root',
 'source': identity(path), 'before': identity(stage / 'before' / relative),
 'checks': {'graph_model_session_prefix_byte_equal': True, 'ordinary_driver_suffix_byte_equal': True,
            'legacy_single_JSON_key_sequence_equal': True, 'legacy_single_JSON_keys_unique': True,
            'legacy_single_family_planning_order_equal': True, 'legacy_single_Session_before_ready': True},
 'implemented': [
  'Natural --mtp on with exactly one prompt phase per --schedule/--session-schedules input and per-session --steps quota.',
  'MTP R auto=1, reject R>1/prefix auto/forced tapes/multi-turn/preparation diagnostics before Model.',
  'All requested sessions must fit N and shared target/draft cache byte budget; no ordinary replay shrink.',
  'Single and multi use the same complete original MTP episode advance and original per-request formatter.',
  'One shared335Model, cold role/shape union, bounded per-role either-slot use counts, global Model parity unchanged.',
  'Only first prompt actual slot and original T2 role double slots prewarmed; later prompt slots/T1 roles initialize in explicit actual prepare.',
  'Round-robin one complete episode; saved final scalars survive checked stop/try_retire without closing another shared carrier.',
  'Multi global wall is measured once; per-request elapsed includes interleaving and is not summed; trace uses parsed safe ID subdirectories.'
 ],
 'schema': {'single': 'original flat JSON key sequence unchanged',
            'scheduled': 'sessions:[{session_id,result:<original MTP result>}], dispatch:[id per actual episode], plus global work/wall',
            'trace': '<trace>/session<index>_<safe-id>/{prefill,mtpN}; original single trace path unchanged',
            'multi_timing': 'first request prefill_start before admission to final actual host endpoint; all prompts first pass, then one whole episode per request per round',
            'cold_timing': 'single Session and first carrier before ready as before; multi Session admission and later prompt carrier initialization inside measured requests'},
 'not_implemented': ['MTP R>1 batches', 'prefix hit/adoption in scheduled MTP', 'generated-state pressure/replay',
                     'multi-turn or forced decode schedule in MTP', 'serving scheduler'],
 'limitations': ['Trace is diagnostic; existing trace/log I/O between calls remains in elapsed.',
                 'cache bytes count shared state backings, not weights/IO/workspace/native capture or physical GPU peak.',
                 'Replay use plans are conservative upper bounds under EOS/acceptance, not actual role usage.'],
 'activity': {'CXX_builds': 0, 'GPU_runs': 0, 'product_files_changed': [str(relative).replace('\\', '/')]}
}
review = stage / 'review' / 'implementation-review.json'
review.write_text(json.dumps(report, indent=2)+'\n', encoding='utf-8')
freeze = {'source': identity(path), 'before': identity(stage / 'before' / relative),
          'source_snapshot': identity(source), 'diff': identity(diff), 'review': identity(review),
          'builds': 0, 'GPU_runs': 0, 'status': 'frozen for root incremental single-TU build and actual tests'}
out = stage / 'source-freeze.json'
out.write_text(json.dumps(freeze, indent=2)+'\n', encoding='utf-8')
print(json.dumps({'source': freeze['source'], 'freeze': identity(out), 'static_checks': report['checks']}, indent=2))
