"""Finite original/current CLI and interleaved MTP checks; no throughput claim."""
from pathlib import Path
import argparse, hashlib, importlib.util, json, os, sys
sys.dont_write_bytecode=True
X=Path(__file__).resolve().parent;R=X.parents[1];W=X.parent/'qwen-mtp-divergence-20261022'
s=importlib.util.spec_from_file_location('build',X/'build_hyle.py');h=importlib.util.module_from_spec(s);s.loader.exec_module(h)
b,c=h.b,h.c

def prepare():
 f=X/'fixtures';f.mkdir(exist_ok=False)
 ids=(X.parent/'qwen-mtp-weights-20261022/prepared/prompt.ids').read_text().split()
 for name,count in [('p1',1),('p15',15),('p23',23)]:
  d=f/name;d.mkdir();os.link(X.parent/'qwen-mtp-weights-20261022/prepared/weights.tsv',d/'weights.tsv')
  (d/'prompt.ids').write_text(' '.join(ids[:count])+'\n')
 (f/'a.txt').write_text('prompt p15/prompt.ids\n');(f/'b.txt').write_text('prompt p23/prompt.ids\n')
 (f/'sessions.txt').write_text('A a.txt\nB b.txt\n')
 (f/'fixed.txt').write_text('prompt p15/prompt.ids\ndecode p1/prompt.ids\n')
 (f/'turns.txt').write_text('prompt p15/prompt.ids\ndecode p1/prompt.ids\nprompt p1/prompt.ids\n')
 ordinary=f/'ordinary';ordinary.mkdir();os.link(X.parent/'qwen-mtp-window-20261022/inputs/text/weights.tsv',ordinary/'weights.tsv')
 (ordinary/'prompt.ids').write_text(' '.join(ids[:23])+'\n')

def run_case(name,arm,args):
 out=X/'cli-runs1'/f'{name}-{arm}';out.mkdir(parents=True,exist_ok=False)
 root=W if arm=='before' else X
 ready=c.read(root/('qwen-ready-attempt1.json' if arm=='before' else 'qwen-ready-attempt2.json'));assert h.same(ready['image'])
 if arm=='current':assert h.same(ready['source'])
 else:assert hashlib.sha256((X/'before/tools/qwen35_text/main.cc').read_bytes()).hexdigest()==ready['source']['sha256']
 env=os.environ.copy();env['PATH']=c.read(ready['runtime_environment']['path'])['PATH']
 command=[ready['image']['path'],*args,'--trace',str(out/'trace'),'--trace-level','full' if name=='multi' else 'decisions']
 c.save(out/'plan.json',dict(command=command,image=ready,diagnostic=True,throughput_evidence=False))
 c.execute('run',command,env,out)
 result=json.loads((out/'run.stdout.log').read_text().splitlines()[-1]);c.save(out/'parsed.json',result)

def positive():
 f=X/'fixtures';common=['--capacity','64','--active-sequences','1','--prefix-cache','off','--progress','direct','--replay','auto']
 for name,steps in [('p1',1),('p15',4)]:
  args=['--inputs',str(f/name),'--steps',str(steps),'--mtp','on',*common]
  for arm in ['before','current']:run_case(name,arm,args)
 args=['--inputs',str(f/'ordinary'),'--steps','4',*common]
 for arm in ['before','current']:run_case('ordinary',arm,args)
 args=['--inputs',str(f/'p15'),'--session-schedules',str(f/'sessions.txt'),'--steps','8','--capacity','64','--mtp','on','--progress','direct','--replay','auto']
 run_case('multi','current',args)
 args=['--inputs',str(f/'p15'),'--schedule',str(f/'a.txt'),'--steps','4','--capacity','64','--mtp','on']
 run_case('schedule','current',args)

if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('mode',choices=['prepare','positive']);a=p.parse_args()
 {'prepare':prepare,'positive':positive}[a.mode]()
