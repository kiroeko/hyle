// Explicit single-Model MTP isolation consumer; no throughput/quality claim.
#define main hyle_qwen35_text_consumer_main
#include "main.cc"
#undef main

#include <bit>
#include <cstring>
#include "hyle/compute/detail/paged_arena_access.h"

namespace {
namespace q = qwen35;
namespace c = q::c;
using Bytes = std::vector<std::byte>;

void require(bool value, const char *message) {
  if (!value) throw std::runtime_error(message);
}
std::string quoted(std::string_view value) {
  std::ostringstream out; out << '"';
  for (const auto ch : value) {
    if (ch == '"' || ch == '\\') out << '\\' << ch;
    else if (ch == '\n') out << "\\n";
    else if (static_cast<unsigned char>(ch) < 32) out << '?';
    else out << ch;
  }
  out << '"'; return out.str();
}
Bytes read(c::ReadLease const &lease) {
  if (!lease.valid()) return {};
  Bytes bytes(lease.size()); q::check(q::take(lease.view()).read(bytes)); return bytes;
}
Bytes read(q::Tensor &tensor) {
  Bytes bytes(tensor.buffer.size()); q::check(tensor.buffer.view().read(bytes)); return bytes;
}
void write(const std::filesystem::path &path, const Bytes &bytes) {
  std::filesystem::create_directories(path.parent_path());
  std::ofstream out(path, std::ios::binary);
  out.write(reinterpret_cast<const char *>(bytes.data()), static_cast<std::streamsize>(bytes.size()));
  require(static_cast<bool>(out), "cannot write MTP Session probe vector");
}
Bytes read_file(const std::filesystem::path &path, std::size_t size) {
  std::ifstream in(path, std::ios::binary | std::ios::ate);
  require(in && in.tellg() == static_cast<std::streamoff>(size), "baseline vector extent differs");
  in.seekg(0); Bytes bytes(size);
  in.read(reinterpret_cast<char *>(bytes.data()), static_cast<std::streamsize>(size));
  require(static_cast<bool>(in), "cannot read MTP Session baseline"); return bytes;
}
std::string fingerprint(const Bytes &bytes) {
  std::uint64_t hash = 14695981039346656037ull;
  for (const auto value : bytes) { hash ^= std::to_integer<unsigned char>(value); hash *= 1099511628211ull; }
  std::ostringstream out; out << std::hex << std::setw(16) << std::setfill('0') << hash; return out.str();
}
struct Blob final { std::string name; bool bf16 = false; Bytes bytes; };

// Read exactly the committed logical rows, independent of physical page IDs.
// No capacity/whole-bank view is used as permission for an unused tail.
Bytes logical_rows(const c::PagedArena &arena, const c::PagedArenaRead &frame, std::size_t rows) {
  const auto host = frame.layout().host();
  const auto count = (rows + q::cache::Plan::page_rows - 1) / q::cache::Plan::page_rows;
  require(frame.valid() && host.page_indices.size() == count && frame.page_count() == count &&
          host.last_page_lengths.size() == 1, "MTP frame has the wrong committed page footprint");
  require(!count || (count - 1) * q::cache::Plan::page_rows +
          static_cast<std::size_t>(host.last_page_lengths[0]) == rows, "MTP frame frontier differs from its snapshot");
  Bytes result(q::cache::multiply(rows, std::size_t{1024}));
  const auto guards = c::detail::PagedArenaAccess::pages(frame);
  std::size_t offset = 0;
  for (std::size_t logical = 0; logical < count; ++logical) {
    const auto physical = host.page_indices[logical]; const c::ReadLease *selected = nullptr;
    for (const auto &guard : guards)
      if (q::take(c::detail::PagedArenaAccess::page(arena, guard)) == static_cast<std::uint32_t>(physical)) selected = &guard;
    require(selected != nullptr, "logical MTP page lacks its real ready guard");
    const auto bytes = (std::min)(std::size_t{16 * 1024}, result.size() - offset);
    q::check(q::take(q::take(selected->view()).subview(0, bytes)).read(std::span(result).subspan(offset, bytes)));
    offset += bytes;
  }
  return result;
}
struct HeadImage final {
  std::string metadata;
  std::vector<std::uint32_t> target_pages, draft_pages;
  std::vector<Blob> blobs;
};
HeadImage image(q::Model &model, const q::cache::Snapshot &head) {
  model.validate_mtp_snapshot(head);
  require(head.draft && head.carry_hidden.valid(), "incomplete MTP head");
  HeadImage result;
  std::ostringstream metadata;
  metadata << "{\"length\":" << head.length << ",\"next_id\":" << head.next_id
    << ",\"draft_frontier\":" << head.draft->frontier << ",\"lag\":" << head.draft->lag
    << ",\"catchup_token\":" << head.draft->catchup_token << ",\"carry_bytes\":" << head.carry_hidden.size()
    << ",\"prior_bytes\":" << head.prior_hidden.size() << '}';
  result.metadata = metadata.str();
  for (const auto &page : head.pages) result.target_pages.push_back(page.page());
  for (const auto &page : head.draft->pages) result.draft_pages.push_back(page.page());
  for (std::size_t layer = 0; layer < head.state.size(); ++layer) if (layer % 4 != 3) {
    result.blobs.push_back({"layer" + std::to_string(layer) + ".conv.bf16", true, read(head.state[layer].history)});
    result.blobs.push_back({"layer" + std::to_string(layer) + ".gdn.f32", false, read(head.state[layer].recurrent)});
  }
  for (std::size_t layer = 0; layer < head.keys.size(); ++layer) {
    result.blobs.push_back({"target" + std::to_string(layer) + ".key.bf16", true,
        logical_rows(model.page_inventory.keys[layer], head.keys[layer], head.length)});
    result.blobs.push_back({"target" + std::to_string(layer) + ".value.bf16", true,
        logical_rows(model.page_inventory.values[layer], head.values[layer], head.length)});
  }
  result.blobs.push_back({"draft.key.bf16", true, logical_rows(model.draft_inventory.keys[0], head.draft->key, head.draft->frontier)});
  result.blobs.push_back({"draft.value.bf16", true, logical_rows(model.draft_inventory.values[0], head.draft->value, head.draft->frontier)});
  result.blobs.push_back({"carry.bf16", true, read(head.carry_hidden)});
  result.blobs.push_back({"prior.bf16", true, read(head.prior_hidden)});
  return result;
}
bool same(const HeadImage &a, const HeadImage &b) {
  if (a.metadata != b.metadata || a.target_pages != b.target_pages || a.draft_pages != b.draft_pages || a.blobs.size() != b.blobs.size()) return false;
  for (std::size_t i = 0; i < a.blobs.size(); ++i)
    if (a.blobs[i].name != b.blobs[i].name || a.blobs[i].bytes != b.blobs[i].bytes) return false;
  return true;
}

struct VectorRecord final { std::string name, path, hash; bool bf16 = false; std::size_t bytes = 0; };
struct SavedStep final { std::string metadata; std::vector<VectorRecord> vectors; };
struct Metric final {
  std::string name, baseline, actual, dtype, baseline_hash, actual_hash;
  std::size_t bytes = 0, nonfinite_baseline = 0, nonfinite_actual = 0;
  bool byte_equal = false;
  double max_abs = 0, squared_error = 0, reference_squared = 0;
};
Metric compare(const VectorRecord &reference, const Blob &actual, const std::filesystem::path &path) {
  require(reference.name == actual.name && reference.bf16 == actual.bf16 && reference.bytes == actual.bytes.size(), "corresponding MTP vector shape/type differs");
  const auto baseline = read_file(reference.path, reference.bytes);
  Metric result{.name = actual.name, .baseline = reference.path, .dtype = actual.bf16 ? "BF16" : "F32",
      .baseline_hash = reference.hash, .actual_hash = fingerprint(actual.bytes), .bytes = actual.bytes.size(), .byte_equal = baseline == actual.bytes};
  // Store just one baseline payload on byte equality; differences retain the
  // actual raw vector. The observation records the exact reuse relation.
  if (!result.byte_equal) { write(path, actual.bytes); result.actual = path.string(); }
  else result.actual = reference.path;
  const auto width = actual.bf16 ? sizeof(std::uint16_t) : sizeof(float);
  require(reference.bytes % width == 0, "MTP vector has a non-scalar byte extent");
  const auto scalar = [&](const Bytes &data, std::size_t index) {
    if (actual.bf16) { std::uint16_t word = 0; std::memcpy(&word, data.data() + index * width, sizeof(word)); return std::bit_cast<float>(std::uint32_t(word) << 16); }
    float value = 0; std::memcpy(&value, data.data() + index * width, sizeof(value)); return value;
  };
  for (std::size_t i = 0; i < reference.bytes / width; ++i) {
    const double x = scalar(baseline, i), y = scalar(actual.bytes, i);
    result.nonfinite_baseline += !std::isfinite(x); result.nonfinite_actual += !std::isfinite(y);
    if (!std::isfinite(x) || !std::isfinite(y)) continue;
    const auto error = y - x; result.max_abs = (std::max)(result.max_abs, std::abs(error));
    result.squared_error += error * error; result.reference_squared += x * x;
  }
  return result;
}
struct Run final {
  std::string name;
  std::span<const std::int32_t> prompt;
  std::size_t quota = 0, step = 0;
  std::shared_ptr<q::Session> session;
  std::vector<std::int32_t> generated;
  bool done() const { return !generated.empty() && (generated.size() >= quota || q::is_end_of_generation(generated.back())); }
};
struct Probe final {
  std::filesystem::path output;
  std::array<std::vector<SavedStep>, 2> baseline;
  std::vector<Metric> metrics;
  std::vector<std::string> episodes;
  std::size_t peak_versions = 0, idle_checks = 0, after_stop_calls = 0;
  std::size_t actual_backing = 0, phases = 0, slots = 0;
  bool all_bytes = true, all_finite = true, stopped_b = false;
  void observe(q::Model &model) {
    peak_versions = (std::max)(peak_versions, std::size_t(model.snapshot_versions.live));
    require(model.snapshot_versions.live <= model.cache_plan.snapshot_slots, "MTP Session probe exceeded finite snapshot capacity");
    actual_backing = q::take(model.cache_budget.usage(model.memory.ref())).live_bytes;
    require(actual_backing == model.cache_plan.backing_bytes, "MTP state backing is not charged exactly once");
  }
  void save_or_compare(std::size_t which, Run &run, HeadImage captured, bool reference) {
    auto &saved = baseline[which];
    const auto directory = output / ((reference ? "baseline_" : "interleaved_") + run.name) / ("step" + std::to_string(run.step));
    if (reference) {
      SavedStep step; step.metadata = captured.metadata;
      for (const auto &blob : captured.blobs) {
        const auto path = directory / blob.name; write(path, blob.bytes);
        step.vectors.push_back({blob.name, path.string(), fingerprint(blob.bytes), blob.bf16, blob.bytes.size()});
      }
      saved.push_back(std::move(step));
    } else {
      require(run.step < saved.size(), "interleaved MTP used more natural episodes than its baseline");
      const auto &step = saved[run.step];
      require(captured.metadata == step.metadata && captured.blobs.size() == step.vectors.size(), "interleaved natural MTP transition differs from its baseline");
      for (std::size_t i = 0; i < captured.blobs.size(); ++i) {
        auto metric = compare(step.vectors[i], captured.blobs[i], directory / captured.blobs[i].name);
        metric.name = run.name + "/step" + std::to_string(run.step) + "/" + metric.name;
        all_bytes = all_bytes && metric.byte_equal;
        all_finite = all_finite && !metric.nonfinite_baseline && !metric.nonfinite_actual;
        metrics.push_back(std::move(metric));
      }
    }
    ++run.step;
  }
  void report(std::string_view status, q::Model &model, std::string_view error = {}) {
    phases = model.phases.size(); slots = 0;
    for (const auto &[key, phase] : model.phases) { (void)key; for (const auto &slot : phase->slots) slots += slot.valid(); }
    std::ofstream out(output / "observation.json"); require(static_cast<bool>(out), "cannot write MTP Session observation");
    out << std::setprecision(17) << "{\"status\":" << quoted(status) << ",\"error\":" << quoted(error)
      << ",\"model_objects\":1,\"weight_tensors\":335,\"capacity\":64,\"resident_limit\":2,\"active_sequences\":1"
      << ",\"baseline_prompt_rows\":[15,23],\"output_quotas\":[8,16],\"all_vectors_byte_equal\":" << (all_bytes ? "true" : "false")
      << ",\"all_finite\":" << (all_finite ? "true" : "false") << ",\"idle_head_full_byte_checks\":" << idle_checks
      << ",\"stopped_EOS_session_B\":" << (stopped_b ? "true" : "false") << ",\"A_calls_after_B_stop\":" << after_stop_calls
      << ",\"peak_live_snapshot_versions\":" << peak_versions << ",\"snapshot_slots\":" << model.cache_plan.snapshot_slots
      << ",\"state_slots\":" << model.cache_plan.state_slots << ",\"hidden_slots\":" << model.cache_plan.hidden_slots
      << ",\"managed_backing_bytes\":" << actual_backing << ",\"planned_backing_bytes\":" << model.cache_plan.backing_bytes
      << ",\"final_live_snapshot_versions\":" << model.snapshot_versions.live << ",\"actual_phases\":" << phases << ",\"actual_slots\":" << slots
      << ",\"fingerprint\":\"FNV1a64 diagnostic identity; byte equality uses complete arrays\",\"timing_comparison\":false,\"numerical_tolerance_policy\":null"
      << ",\"scope\":\"Same Model/GraphRole/partitions/N2 plan/native math and auto capture policy. Serial active R1; no MTP simultaneous R2, server isolation, or cross-engine quality claim. Physical page IDs may differ between sequential baselines and interleaved allocations; KV vectors contain exact logical committed rows. Equal actual payloads reference one saved baseline raw file.\""
      << ",\"episodes\":[";
    for (std::size_t i = 0; i < episodes.size(); ++i) out << (i ? "," : "") << episodes[i];
    out << "],\"baseline\":[";
    for (std::size_t r = 0; r < baseline.size(); ++r) {
      out << (r ? "," : "") << '[';
      for (std::size_t s = 0; s < baseline[r].size(); ++s) {
        const auto &step = baseline[r][s]; out << (s ? "," : "") << "{\"metadata\":" << step.metadata << ",\"vectors\":[";
        for (std::size_t i = 0; i < step.vectors.size(); ++i) { const auto &v = step.vectors[i];
          out << (i ? "," : "") << "{\"name\":" << quoted(v.name) << ",\"path\":" << quoted(v.path) << ",\"bytes\":" << v.bytes
              << ",\"dtype\":" << quoted(v.bf16 ? "BF16" : "F32") << ",\"fnv1a64\":" << quoted(v.hash) << '}'; }
        out << "]}";
      }
      out << ']';
    }
    out << "],\"vectors\":[";
    for (std::size_t i = 0; i < metrics.size(); ++i) { const auto &v = metrics[i];
      out << (i ? "," : "") << "{\"name\":" << quoted(v.name) << ",\"baseline\":" << quoted(v.baseline)
        << ",\"actual\":" << quoted(v.actual) << ",\"dtype\":" << quoted(v.dtype) << ",\"bytes\":" << v.bytes
        << ",\"byte_equal\":" << (v.byte_equal ? "true" : "false") << ",\"actual_reuses_baseline_payload\":" << (v.byte_equal ? "true" : "false")
        << ",\"baseline_fnv1a64\":" << quoted(v.baseline_hash) << ",\"actual_fnv1a64\":" << quoted(v.actual_hash)
        << ",\"nonfinite_baseline\":" << v.nonfinite_baseline << ",\"nonfinite_actual\":" << v.nonfinite_actual
        << ",\"max_abs\":" << v.max_abs << ",\"squared_error\":" << v.squared_error << ",\"reference_squared\":" << v.reference_squared << '}';
    }
    out << "]}\n"; require(static_cast<bool>(out), "MTP Session observation write failed");
  }
};

void retire(Run &run) {
  q::check(run.session->stop()); require(q::take(run.session->try_retire()), "completed MTP Session failed actual retirement");
  run.session.reset();
}
void advance(q::Model &model, Probe &probe, Run &run, std::size_t which, bool reference) {
  const bool prefill = run.generated.empty();
  require(prefill || !run.done(), "MTP probe attempted to advance an ended Session");
  const auto before = run.session->length();
  const auto quota = run.quota - run.generated.size();
  const auto lag = run.session->head->draft->lag;
  const bool single = !prefill && (quota == 1 || model.capacity - before == 1);
  const auto role = prefill ? q::GraphRole::kMtpPrefill : single
      ? (lag ? q::GraphRole::kMtpCatchupSingle : q::GraphRole::kMtpSingle)
      : (lag ? q::GraphRole::kMtpCatchupRound : q::GraphRole::kMtpRound);
  const auto pending = run.session->head->next_id;
  const auto inputs = prefill ? run.prompt : std::span(&pending, 1);
  model.prepare_evaluation(*run.session, inputs, nullptr, role); probe.observe(model);
  require(model.active_step && run.session->pending, "original MTP episode was not admitted");
  auto *phase = run.session->pending->phase;
  q::StepObservation observation;
  model.submit_evaluation(*run.session);
  q::MtpRoundResult round;
  const auto name = run.name + (prefill ? "_prefill" : "_round" + std::to_string(run.step));
  if (prefill) run.generated.push_back(model.finish_evaluation(*run.session, name, {}, false, nullptr, nullptr, &observation));
  else {
    const q::EvaluationOutput output{.session = run.session, .name = name, .trace_states = false, .observation = &observation};
    round = model.finish_mtp_round(*run.session, quota, std::array<std::int32_t, 2>{248044,248046}, &output);
    run.generated.insert(run.generated.end(), round.emitted.begin(), round.emitted.end());
  }
  probe.observe(model);
  require(!model.active_step && !model.carrier_borrowed && !run.session->pending &&
          model.snapshot_versions.live <= model.cache_plan.resident_sessions, "MTP episode retained a candidate/carrier after finish");
  auto captured = image(model, *run.session->head);
  captured.blobs.push_back({"output.logits.f32", false, read(phase->logits)});
  captured.blobs.push_back({"output.hidden.bf16", true, read(phase->final_hidden)});
  std::ostringstream meta;
  meta << "{\"head\":" << captured.metadata << ",\"role\":" << static_cast<int>(role)
    << ",\"input_rows\":" << inputs.size() << ",\"generated_ids\":[";
  for (std::size_t i = 0; i < run.generated.size(); ++i) meta << (i ? "," : "") << run.generated[i];
  meta << "],\"pending\":" << round.pending << ",\"proposal\":" << round.draft << ",\"target_first\":" << round.target_first
    << ",\"target_second\":" << round.target_second << ",\"agreed\":" << (round.agreed ? "true" : "false")
    << ",\"accepted\":" << (round.accepted_draft ? "true" : "false") << ",\"processed_target\":" << round.processed_target
    << ",\"processed_draft\":" << round.processed_draft << '}'; captured.metadata = meta.str();
  std::ostringstream episode;
  episode << "{\"reference\":" << (reference ? "true" : "false") << ",\"session\":" << quoted(run.name) << ",\"step\":" << run.step
    << ",\"metadata\":" << captured.metadata << ",\"capture_recorded\":" << observation.capture_recorded
    << ",\"capture_reused\":" << observation.capture_reused << ",\"execution_parity_after\":" << model.execution_parity << '}';
  probe.episodes.push_back(episode.str());
  probe.save_or_compare(which, run, std::move(captured), reference);
}

void run(const std::filesystem::path &inputs, const std::filesystem::path &output) {
  auto source = q::read_ids(inputs / "prompt.ids"); require(source.size() >= 23, "probe needs original prompt first23 IDs");
  require(!std::filesystem::exists(output), "probe output directory must be fresh"); std::filesystem::create_directories(output);
  const auto plan = q::cache::plan(64, 2, 23, q::recurrent_bytes(q::state_schema_for(64)), 1, 2, true);
  q::Model model(inputs / "weights.tsv", 64, plan);
  require(model.weights.size() == 335, "MTP Session probe requires complete335 weight inventory");
  Probe probe{.output = output};
  try {
    const std::array prefills{std::size_t{15},std::size_t{23}};
    const std::array pair{std::size_t{2}};
    const std::array single{std::size_t{1}};
    model.prepare_family(prefills, false, 1, q::GraphRole::kMtpPrefill);
    // Each shape/role uses the same original auto-capture policy in both
    // stages, conservatively planned for either Model parity before any slot.
    for (const auto size : prefills) model.plan_replay_uses(size, 1, 4, q::GraphRole::kMtpPrefill);
    for (const auto role : {q::GraphRole::kMtpRound,q::GraphRole::kMtpCatchupRound,q::GraphRole::kMtpSingle,q::GraphRole::kMtpCatchupSingle}) {
      model.prepare_family(q::drafts_token(role) ? std::span(pair) : std::span(single), false, 1, role);
      model.plan_replay_uses(q::drafts_token(role) ? 2u : 1u, 1, 48, role);
    }
    probe.observe(model);
    const auto make_run = [&](std::size_t which) {
      const auto size = prefills[which]; const std::array calls{size};
      return Run{.name = which ? "B" : "A", .prompt = std::span(source).first(size), .quota = which ? 16u : 8u,
          .session = model.create_session(calls, {}, q::GraphRole::kMtpPrefill)};
    };
    for (std::size_t which = 0; which < 2; ++which) {
      auto baseline = make_run(which);
      do { advance(model, probe, baseline, which, true); } while (!baseline.done());
      retire(baseline); require(model.snapshot_versions.live == 0, "sequential baseline retained device state");
    }
    std::array runs{make_run(0), make_run(1)};
    for (;;) {
      bool progress = false;
      for (std::size_t which = 0; which < runs.size(); ++which) {
        auto &current = runs[which]; auto &other = runs[1 - which];
        if (!current.session || current.done()) continue;
        const auto idle = other.session ? std::optional(image(model, *other.session->head)) : std::nullopt;
        advance(model, probe, current, which, false); progress = true;
        if (idle) { require(same(*idle, image(model, *other.session->head)), "advancing one MTP Session changed another complete head"); ++probe.idle_checks; }
        if (probe.stopped_b && which == 0) ++probe.after_stop_calls;
        if (current.done() && which == 1) {
          require(q::is_end_of_generation(current.generated.back()), "fixed P23 Session did not end at its natural EOS");
          require(runs[0].session && !runs[0].done(), "probe did not retain a live Session across early stop");
          retire(current); probe.stopped_b = true; probe.observe(model);
          require(!model.carrier_borrowed && !model.active_step, "stopping idle Session closed shared admission");
        }
      }
      if (!progress) break;
    }
    for (std::size_t which = 0; which < runs.size(); ++which) {
      require(runs[which].step == probe.baseline[which].size(), "interleaved MTP episode count differs from baseline");
      if (runs[which].session) retire(runs[which]);
    }
    probe.observe(model);
    require(probe.stopped_b && probe.after_stop_calls && probe.idle_checks && probe.all_finite &&
            model.snapshot_versions.live == 0 && !model.active_step && !model.carrier_borrowed,
            "MTP Session isolation/finite-state/early-stop cleanup did not complete");
    probe.report(probe.all_bytes ? "PASS_BYTE_EXACT" : "PASS_STRUCTURE_NUMERICAL_DIFFERENCES_RECORDED", model);
    std::cout << "{\"status\":\"MTP_SESSION_PROBE_COMPLETED\",\"all_vectors_byte_equal\":" << (probe.all_bytes ? "true" : "false")
              << ",\"vectors\":" << probe.metrics.size() << ",\"idle_head_checks\":" << probe.idle_checks
              << ",\"after_stop_calls\":" << probe.after_stop_calls << ",\"timing_comparison\":false}\n";
  } catch (const std::exception &error) { probe.report("FAIL", model, error.what()); throw; }
}
} // namespace

int main(int argc, char **argv) {
  try {
    std::filesystem::path inputs, output;
    for (int i = 1; i < argc; i += 2) {
      if (i + 1 == argc) throw std::runtime_error("probe option lacks its value");
      const std::string_view option(argv[i]);
      if (option == "--inputs") inputs = argv[i + 1];
      else if (option == "--output") output = argv[i + 1];
      else throw std::runtime_error("unknown MTP Session probe option");
    }
    if (inputs.empty() || output.empty()) throw std::runtime_error("usage: hyle_qwen35_mtp_session_probe --inputs DIR --output FRESH_DIR");
    run(inputs, output); return 0;
  } catch (const std::exception &error) { std::cerr << "Qwen MTP Session probe: " << error.what() << '\n'; return 1; }
}
