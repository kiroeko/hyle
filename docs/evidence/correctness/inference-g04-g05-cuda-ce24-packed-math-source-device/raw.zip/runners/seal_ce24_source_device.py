from pathlib import Path
import hashlib, json, subprocess, xml.etree.ElementTree as ET, zipfile

root = Path.cwd()
base = root/'.scratch/inference-gaps/g04-g05'
candidate = '6e57e28ada9e29ed07819fbe9a97b8a7d08271fe'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
source = json.loads((base/'ce24-source-1/result.json').read_text())
device = json.loads((base/'ce24-device-risks-1/result.json').read_text())
assert source['state'] == device['state'] == 'TERMINAL_PASS'
assert device['product_commit'] == candidate
assert all(s['exit_code'] == 0 for r in (source, device) for s in r['stages'])
assert device['source_result_sha256'] == sha(base/'ce24-source-1/result.json')
for name, count in [('ce24-source-1/tests.xml',17), ('ce24-device-risks-1/memcheck.xml',10),
                    ('ce24-device-risks-1/racecheck.xml',10), ('ce24-device-risks-1/legacy-racecheck.xml',2)]:
    x = ET.parse(base/name).getroot()
    assert int(x.attrib['tests']) == count and x.attrib['failures'] == x.attrib['errors'] == '0'
    assert not any(c.find('skipped') is not None or c.attrib.get('status') == 'notrun' for c in x.findall('.//testcase'))
for row in source['inputs']:
    assert sha(root/row['path']) == row['sha256'], row['path']
for name in ['third_party/flashinfer_cache/patches.json', 'third_party/flashinfer_cache/NOTICE.md', 'cmake/HyleDependencyLock.json']:
    committed = subprocess.check_output(['git','show',candidate+':'+name]).replace(b'\r\n',b'\n')
    assert (root/name).read_bytes().replace(b'\r\n',b'\n') == committed
for label in ['memcheck','racecheck','legacy-racecheck']:
    text = (base/'ce24-device-risks-1'/(label+'.log')).read_text()
    assert not any(word in text.lower() for word in ['========= warning:', '========= error:', 'race reported'])
for path, expected in device['artifacts'].items():
    assert subprocess.check_output(['wsl','-e','sha256sum',path], text=True).split()[0] == expected

dest = root/'evidence/correctness/inference-g04-g05-cuda-ce24-packed-math-source-device'
assert not dest.exists()
dest.mkdir()
with zipfile.ZipFile(dest/'raw.zip','w',zipfile.ZIP_DEFLATED) as archive:
    for folder in ['ce24-source-1','ce24-device-risks-1']:
        for p in sorted((base/folder).rglob('*')):
            if p.is_file(): archive.write(p,p.relative_to(base).as_posix())
    for name in ['launch_ce24_source.py','ce24_source_wsl.py','ce19_cuda_compile.cmake',
                 'ce24_device_risks_wsl.py','seal_ce24_source_device.py']:
        archive.write(base/name,'runners/'+name)
    with zipfile.ZipFile(base/'ce24-source-1.zip') as package:
        archive.writestr('source-manifest.json',package.read('source-manifest.json'))
receipt = dict(kind='G04_G05_CUDA_CE24_PACKED_MATH_BUDGET_SOURCE_DEVICE',
    verdict='PASS_SOURCE17_CACHE_MEM10_RACE10_LEGACY_RACE2_ONLY', product_candidate=candidate,
    source_tests=17, source_stages=source['stages'], source_input_count=len(source['inputs']),
    source_result_raw_sha256=sha(base/'ce24-source-1/result.json'), native_cuda_edges=source['native_cuda_edges'],
    device_stages=device['stages'],artifacts=device['artifacts'],
    measured_stage_seconds=dict(source=sum(s['elapsed_seconds'] for s in source['stages']),
                               device=sum(s['elapsed_seconds'] for s in device['stages'])),
    limits=['Actual W1 WSL RTX4070 SM89 only; no other GPU or OS qualification.',
        'One audited fix: exact FP8 packed-row validity and original native16-bit working-set bound; four private manifest edits.',
        'Original CTA_Q,warp,math primitives,async ordering and synchronization preserved; exact row guard and native16 work bound change MMA_KV; no performance verdict.',
        'All earlier qualified FAIL, hazards, diagnostic runs and measured costs remain immutable evidence.',
        'Codegen comparison, static/shared SDK, three host facets, new numeric/P1 and aggregate G04/G05 remain pending.'],
    raw_zip_sha256=sha(dest/'raw.zip'))
(dest/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n',newline='\n')
p = root/'docs/implementation/module-status.json'
registry = json.loads(p.read_text(encoding='utf-8'))
m = next(x for x in registry['modules'] if x['module']=='compute_provider_flashinfer')
assert m['state']=='AUDITED' and 'candidate' not in m
m['state']='CANDIDATE';m['candidate']=candidate
m['summary']='G04/G05 CE24 CANDIDATE：准确packed行约束与原native16bit计算粒度上界；17数学、十cache mem/race及两普通case race实测PASS/零warning。codegen、static/shared、三host facets及新numeric/P1待验；原qualified FAIL及累计成本保留。'
p.write_text(json.dumps(registry,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\r\n')
print(json.dumps(dict(path=str(dest),candidate=candidate,seconds=receipt['measured_stage_seconds'])))
