"""Publish actual B02 CPU/CUDA and the affected Q27 F32 pair, never B05.

Root invocation after successful native runs:
  python publish.py --link 2 --runs 2 3
Only metadata/source/logs are archived. Original BF16 bodies are stat-only;
their actual SHA verification belongs to the passed Data::load consumers.
"""
import argparse
import importlib.util
import json
from pathlib import Path
import re
import sys
import xml.etree.ElementTree as ET
import zipfile

sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
R = S.parents[1]
CA = R / '.scratch/dspark-pro-target-draft-20261023'
spec = importlib.util.spec_from_file_location('ca_metadata_publisher', CA / 'publish.py')
shared = importlib.util.module_from_spec(spec)
spec.loader.exec_module(shared)
read, identity, verify, add = shared.read, shared.identity, shared.verify, shared.add
resolve, number, successful = shared.resolve, shared.number, shared.successful
REPO = 'Qwen/Qwen3.8-27B'
REV = '1d4bf0f2ff6012fd82039f2fa52739d0dd7c60c0'
MANIFEST = '0c81c7c18e2ac7cf21308a0cd07d3e34d8b24896b2af80028e7b77b24ace1008'
BFLOAT = 'Q27OriginalBFloatTargetAndNextNFullVocabularyVerifierPublishesRepairedPrefix'
F32 = 'Q27OriginalTargetAndNextNFullVocabularyVerifierPublishesRepairedPrefix'
EXPECTED = {backend + suffix for backend in ('Cpu', 'Cuda') for suffix in (BFLOAT, F32)}


def artifact():
    folder = S / 'B02/original-roles'
    manifest_path, receipt_path = add(folder / 'manifest.json'), add(folder / 'acquisition.json')
    manifest, receipt = read(manifest_path), read(receipt_path)
    assert identity(manifest_path)['sha256'] == MANIFEST
    assert manifest['complete'] is receipt['complete'] is True
    assert (manifest['repository'], manifest['revision'], manifest['original_roles'], manifest['source_bytes']) == (REPO, REV, 29, 6679513088)
    assert (receipt['repository'], receipt['revision'], receipt['original_roles']) == (REPO, REV, 29)
    assert receipt['role_payload_bytes'] == receipt['successful_request_body_bytes'] == 6679513088
    assert receipt['whole_shard_downloaded'] is False
    plan_path = add(receipt['source_plan'])
    assert identity(plan_path)['sha256'] == receipt['source_plan_sha256']
    plan = read(plan_path)
    assert (plan['repository'], plan['revision'], plan['original_roles'], plan['source_bytes']) == (REPO, REV, 29, 6679513088)
    add(verify(receipt['downloader']))
    headers = []
    for shard in plan['shards']:
        raw = add(verify(shard['header'])).read_bytes()
        assert shard['data_base'] == len(raw) + 8
        assert shard['url'] == f"https://huggingface.co/{REPO}/resolve/{REV}/{shard['file']}"
        headers.append(json.loads(raw))
    source = add(R / 'tests/compute_models/qwen_bfloat_original_artifacts.h').read_text(encoding='utf-8-sig')
    assert re.search(r'kManifestSha256\s*=\s*"' + MANIFEST + r'"', source)
    pins = dict(re.findall(r'\{\s*"([^"\n]+\.bf16)"\s*,\s*"([0-9a-f]{64})"', source))
    assert len(pins) == len(manifest['roles']) == len(receipt['roles']) == len(plan['roles']) == 29
    manifest_by_name = {row['name']:row for row in manifest['roles']}
    for planned, actual in zip(plan['roles'], receipt['roles'], strict=True):
        for key in ('name', 'section', 'dtype', 'shape', 'filename', 'source_shard', 'source_file',
                    'data_relative_half_open', 'absolute_inclusive', 'bytes', 'ordinal'):
            assert planned[key] == actual[key], (planned['name'], key)
        item = manifest_by_name[planned['name']]
        assert actual['complete'] and planned['dtype'] == item['dtype'] == 'BF16'
        assert item['file'] == planned['filename'] and item['shape'] == planned['shape'] and item['bytes'] == planned['bytes']
        payload = actual['payload']
        assert payload['bytes'] == planned['bytes'] and payload['sha256'] == item['sha256'] == pins[item['file']]
        assert resolve(payload['path']) == folder / item['file']
        assert resolve(payload['path']).stat().st_size == planned['bytes']  # Do not open/hash the body.
        shard = plan['shards'][planned['source_shard']]
        header = headers[planned['source_shard']][planned['name']]
        assert (header['dtype'], header['shape'], header['data_offsets']) == (
            planned['dtype'], planned['shape'], planned['data_relative_half_open'])
        first, end = header['data_offsets']
        assert end-first == planned['bytes'] and planned['absolute_inclusive'] == [shard['data_base']+first, shard['data_base']+end-1]
        offset = 0
        for chunk in actual['chunks']:
            assert chunk['offset'] == offset and 0 < chunk['bytes'] <= 128*1024*1024
            assert re.fullmatch('[0-9a-f]{64}', chunk['sha256'])
            assert chunk['absolute_range_inclusive'] == [planned['absolute_inclusive'][0]+offset,
                planned['absolute_inclusive'][0]+offset+chunk['bytes']-1]
            offset += chunk['bytes']
        assert offset == planned['bytes']
    assert sum(row['bytes'] for row in plan['roles'] if row['section']=='nextn') == 5934992384
    assert sum(row['bytes'] for row in plan['roles'] if row['section']=='target63') == 744520704
    for request in receipt['requests']:
        if request.get('complete'):
            assert request['http_status'] == 206 and request['requested_bytes'] == request['bytes']
            assert request['content_range'].startswith(f"bytes {request['first']}-{request['last']}/")
    return dict(repository=REPO, revision=REV, hf=f'https://huggingface.co/{REPO}/tree/{REV}',
                manifest=identity(manifest_path), acquisition=identity(receipt_path), plan=identity(plan_path),
                original_roles=29, original_bytes=6679513088, nextn_and_vocabulary_roles=17,
                nextn_and_vocabulary_bytes=5934992384, distinct_target63_and_globalnorm_roles=12,
                distinct_target63_and_globalnorm_bytes=744520704,
                vocabulary=248320, hidden=5120, query_heads=24, key_value_heads=4, head_depth=256,
                body_rehashed=False, body_archived=False)


def linked(attempt):
    folder = S / f'tests-link{attempt}'
    ready = read(add(folder / 'ready.json'))
    verify(ready['image'])
    successful(folder / 'link.result.json')
    plan = read(add(folder / 'link-plan.json'))
    runtime = read(add(folder / 'runtime-environment.json'))
    assert all(plan[key] == 0 for key in ('SDK_builds', 'native_CPU_builds', 'NVCC_builds', 'shaders'))
    assert plan['host_translation_units'] == 1
    inputs = {verify(row) for row in plan['inputs']}
    host = add(verify(ready['source_record']))
    assert host == (CA / 'compile4/qwen-state-bfloat/identity.json').resolve(), 'Actual observer-liveowner repair is compile4'
    successful(host.with_name('compile.result.json'))
    source_record = read(host)
    assert verify(source_record['object']) in inputs
    actual_sources = []
    for row in (source_record['source'], *source_record['dependencies']):
        path = verify(row)
        if path.is_relative_to(R):
            add(path)
            actual_sources.append(row)
    assert {'qwen_mtp_state_consumer_test.cc','qwen_bfloat_original_roles.h','qwen_bfloat_original_reference.h',
            'qwen_bfloat_original_artifacts.h','qwen_full_attention_fragment.h','qwen_nextn_input_fragment.h'} <= {Path(row['path']).name for row in actual_sources}
    for row in plan['compiled_records']:
        path = add(verify(row))
        record = read(path)
        assert verify(record['object']) in inputs
    for row in runtime['staged_dlls']:
        verify(row)
    return dict(image=ready['image'], link_plan=identity(folder / 'link-plan.json'),
                runtime=identity(folder / 'runtime-environment.json'), host_record=identity(host),
                host_object=source_record['object'], actual_sources=actual_sources,
                SDK_builds=0, native_CPU_builds=0, NVCC_builds=0, shaders=0)


def cases(attempt, image):
    folder = S / f'checks{attempt}'
    summary = read(add(folder / 'summary.json'))
    process = summary['process']
    assert summary['image'] == image and process['exit'] == 0 and not process['timed_out']
    assert resolve(process['command'][0]) == resolve(image['path'])
    assert summary['tests'] == len(summary['cases']) > 0
    assert not any(summary[key] for key in ('failures','errors','disabled','skips'))
    assert all(summary[key] is False for key in ('throughput_evidence','physical_memory_evidence','whole_original_model'))
    tree = ET.parse(add(folder / 'results.xml')).getroot()
    actual = [dict(attributes=case.attrib, properties={p.attrib['name']:p.attrib['value'] for p in case.iter('property')}) for case in tree.iter('testcase')]
    assert actual == summary['cases']
    counts = {}
    for case in actual:
        a,p = case['attributes'],case['properties']
        name = a['name']
        assert name in EXPECTED and a['classname']=='QwenMtpStateConsumer' and a['status']=='run' and a['result']=='completed'
        exact = dict(target_verifier_submissions=3, original_native_reference_submissions=0,
            natural_k1_trials=1, controlled_matching_trials=1, controlled_rejection_trials=1,
            complete_target_draft_resources=12, original_target_roles=12, first_full_target_projection_values=59392,
            first_full_target_verifier_values=496640, target_verifier_full_vocabulary=248320,
            target_verifier_matmuls=1, target_verifier_rows=2, first_full_nextn_head_values=248320)
        for key,value in exact.items():
            assert number(p,key)==value,(name,key,p.get(key))
        for key in ('actual_submissions','target_submissions','nextn_submissions','accepted_target_conditioned_repairs',
                    'accepted_zero_drafts','accepted_one_draft','actual_pending_embedding_feedback_checks',
                    'whole_state_publications','cancelled_unpublished_drafts','rejected_stale_publishes','actual_target_reseed_checks'):
            assert number(p,key)>0
        assert number(p,'natural_accepted_drafts') in (0,1) and number(p,'natural_proposal')<248320
        assert number(p,'accepted_zero_drafts')+number(p,'accepted_one_draft')==3
        assert number(p,'accepted_target_conditioned_repairs')==number(p,'accepted_one_draft')
        assert number(p,'actual_accepted_kv_repair_submissions')==number(p,'accepted_target_conditioned_repairs')
        assert number(p,'nextn_submissions')==number(p,'actual_pending_embedding_feedback_checks')
        assert number(p,'actual_submissions')==sum(number(p,key) for key in ('target_submissions','nextn_submissions','target_verifier_submissions'))
        assert number(p,'peak_state_backing_bytes')<=number(p,'state_budget_bytes')
        if BFLOAT in name:
            assert (p['artifact_repository'],p['artifact_revision'],p['artifact_variant'],p['original_bfloat_manifest_sha256']) == (REPO,REV,'official-bf16',MANIFEST)
            assert number(p,'original_role_count')==29 and number(p,'original_role_bytes')==6679513088
            assert number(p,'original_target_source_bytes')==744520704 and number(p,'full_head_encoded_bytes')==2542796800
            assert p['full_head_provider']==p['target_verifier_provider']==('cublasLt' if name.startswith('Cuda') else 'ggml-cpu')
        else:
            assert number(p,'original_target_source_bytes')==282318848 and number(p,'full_head_encoded_bytes')==1042944000
            assert p['full_head_provider']==p['target_verifier_provider']==('ggml-cuda' if name.startswith('Cuda') else 'ggml-cpu')
        counts['QwenMtpStateConsumer.'+name]=number(p,'actual_submissions')
    return dict(summary=identity(folder / 'summary.json'),process=process,cases=actual,graph_submissions_by_case=counts)


def retain_text(folder):
    for path in folder.rglob('*'):
        if path.is_file() and path.suffix.lower() in shared.TEXT:
            add(path)
        elif path.is_file() and path.name=='header-length.bin':
            assert path.stat().st_size==8
            shared.files.add(path.resolve())


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--link',type=int,required=True)
    parser.add_argument('--runs',type=int,nargs='+',required=True)
    args=parser.parse_args()
    assert args.link>0 and args.runs==sorted(set(args.runs)) and min(args.runs)>0
    protected=shared.protect()
    source=artifact()
    image=linked(args.link)
    runs=[cases(n,image['image']) for n in args.runs]
    names=[case['attributes']['name'] for run in runs for case in run['cases']]
    assert len(names)==4 and set(names)==EXPECTED
    failed_path=add(S / 'checks1/summary.json')
    failed=read(failed_path)
    assert failed['process']['exit']!=0 and failed['failures']>0
    assert 1 not in args.runs
    for folder in [S / 'B02',S / 'before',S / 'before-state-wiring',S / 'review',
                   CA / 'compile3/qwen-state-bfloat',CA / 'compile4/qwen-state-bfloat']:
        if folder.is_dir():retain_text(folder)
    for folder in S.glob('checks*'):
        assert (folder / 'process.json').is_file(), 'A native process is not terminal'
        retain_text(folder)
    for folder in S.glob('tests-link*'):retain_text(folder)
    for path in S.glob('*.py'):add(path)
    add(CA / 'publish.py')
    add(R / 'docs/evidence/correctness/mtp-qwen27-target-verifier-2026-10-23.json')
    assert not any(path.is_relative_to(S / 'B05') for path in shared.files)
    graphs={name:count for run in runs for name,count in run['graph_submissions_by_case'].items()}
    destination=R / 'docs/evidence/correctness/mtp-qwen-bfloat-target-verifier-2026-10-23.json'
    archive=destination.with_suffix('.zip')
    assert not destination.exists() and not archive.exists()
    assert shared.protect()==protected
    with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=7) as zipped:
        for path in sorted(shared.files):zipped.write(path,path.relative_to(R).as_posix())
    result=dict(date='2026-10-23',stage='QB-B02',goal_complete=False,
        conclusion='Original Qwen3.8-27B BF16 target63/NextN/full-V K1 consumer passed CPU/CUDA; affected original GGUF F32 Q27 target/NextN consumers also passed.',
        artifact=source,
        implementation=dict(
            source='One29-role original BF16 source owns mappings and once-bound readonly leases:15 NextN roles, untied original embedding/head and12 distinct target63/globalnorm roles. Source/profile geometry is H5120,24 Q heads,4 KV heads,D256.',
            numerics='Original BF16 byte operands and actual predecessors feed independent blocked F64/F32-accumulation bounds. Raw delta norms use F32(1+originalBF16) and explicit BF16 stores. Q/K RMS, separate SiLU/product stores, local SDPA/gate/rotation and stable actual full-V head are checked; no GGUF arithmetic substitution.',
            state='Shared K1 controller/ordinary Graphs, real two-row single full-V verifier and actual I32 pending leases. Accept0 keeps after-current; accept1 repairs recursive NextN KV from the correctly shifted target tap before atomic12-resource publication. Original readers/cancel/stale/bounded backing and real pending continuation remain checked.',
            live_constant_observer='First attempt incorrectly read cleared cold constant bytes. The compile4 observer reads the actual prepared Program.parameters exact-one binding; numerical rules/inputs were not widened. The first failed process/XML/logs remain in the archive.',
            build='One current Qwen host TU linked to existing product/native/runtime caches; no SDK/CPUworker/NVCC/shader rebuild or new executor/public operation.'),
        validation=dict(tests=4,failures=0,errors=0,skips=0,graph_submissions=sum(graphs.values()),
            graph_submissions_by_case=graphs,runs=runs,linked=image,
            failed_attempt=dict(summary=identity(failed_path),process=failed['process'],counted_as_pass=False),
            SDK_builds=0,native_CPU_builds=0,NVCC_builds=0,shaders=0),
        limitations=['Layer62 upstream inputs and initial histories are finite fixtures; this is not a full64-layer prompt-to-output model or task-quality result.',
            'Natural K1 once and separately controlled actualTop1/Top2 trials are not a natural acceptance-rate estimate.',
            'The explicit F32-fused RoPE with one BF16 output store is not HF eager BF16-intermediate bit equivalence.',
            'No B05/Q24 BF16 execution, throughput/loading comparison, physical memory/VRAM measurement or overall MTP completion is claimed. State budget counters are declared-resource accounting.'],
        protection=protected,archive=identity(archive),archive_items=len(shared.files))
    destination.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    publication=dict(evidence=identity(destination),archive=identity(archive))
    (S / 'publication.json').write_text(json.dumps(publication,indent=2)+'\n',encoding='utf-8')
    assert shared.protect()==protected
    print(json.dumps(dict(**publication,tests=4,graphs=sum(graphs.values()))))


if __name__=='__main__':
    main()
