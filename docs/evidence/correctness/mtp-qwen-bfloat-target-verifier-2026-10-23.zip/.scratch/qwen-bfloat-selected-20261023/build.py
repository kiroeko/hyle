"""Narrow Qwen link/run support; root executes, cached product closure stays intact.

Suggested sequence:
  python build.py link --attempt 1 --compile-attempt 3
  python build.py run --attempt 1 --link-attempt 1 --case cpu-bfloat
  python build.py run --attempt 2 --link-attempt 1 --case cuda-and-f32
The second run is chosen only after root inspects the actual CPU result.
"""
from pathlib import Path
import argparse
import importlib.util
import os
import sys
import xml.etree.ElementTree as ET

sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
R = S.parents[1]
CA = R / '.scratch/dspark-pro-target-draft-20261023'
BASE = R / '.scratch/dspark-original-target-tail-20261023/tests-link4'
spec = importlib.util.spec_from_file_location('ca_cached_build', CA / 'build.py')
cached = importlib.util.module_from_spec(spec)
spec.loader.exec_module(cached)
b, c = cached.b, cached.c
BFLOAT = 'Q27OriginalBFloatTargetAndNextNFullVocabularyVerifierPublishesRepairedPrefix'
F32 = 'Q27OriginalTargetAndNextNFullVocabularyVerifierPublishesRepairedPrefix'
CASES = {
    'cpu-bfloat': ['QwenMtpStateConsumer.Cpu' + BFLOAT],
    'cuda-bfloat': ['QwenMtpStateConsumer.Cuda' + BFLOAT],
    'f32-regression': ['QwenMtpStateConsumer.' + backend + F32 for backend in ('Cpu', 'Cuda')],
    'cuda-and-f32': ['QwenMtpStateConsumer.Cuda' + BFLOAT] +
                    ['QwenMtpStateConsumer.' + backend + F32 for backend in ('Cpu', 'Cuda')],
}


def host_record(attempt):
    path = CA / f'compile{attempt}/qwen-state-bfloat/identity.json'
    result = c.read(path.with_name('compile.result.json'))
    assert result['exit'] == 0 and result.get('terminal', True)
    record = c.read(path)
    assert Path(record['source']['path']) == R / 'tests/compute_models/qwen_mtp_state_consumer_test.cc'
    assert all(b.identity(row['path']) == row for row in [record['source'], record['object'], *record['dependencies']])
    return path, record


def link(attempt, compile_attempt):
    compiled_path, compiled = host_record(compile_attempt)
    base_path = BASE / 'link-plan.json'
    base = c.read(base_path)
    remove, retained, removed = set(), [], []
    for item in base['compiled_records']:
        assert b.identity(item['path']) == item
        record = c.read(item['path'])
        if '/tests/' in record['source']['path'].replace('\\', '/'):
            remove.add(c.key(record['object']['path']))
            removed.append(item)
        else:
            retained.append(item)
    assert removed and c.key(compiled['object']['path']) not in remove
    inputs = [compiled['object']] + [row for row in base['inputs'] if c.key(row['path']) not in remove]
    assert all(b.identity(row['path']) == row for row in inputs)
    command = [arg for arg in base['command'] if c.key(arg) not in remove and
               not arg.upper().startswith(('/OUT:', '/MAP:', '/IMPLIB:', '/PDB:'))]
    command[1:1] = [compiled['object']['path']]
    out = S / f'tests-link{attempt}'
    out.mkdir(exist_ok=False)
    (out / 'tmp').mkdir()
    image = out / 'qwen-bfloat-checks.exe'
    command += ['/OUT:' + str(image), '/MAP:' + str(image.with_suffix('.map')),
                '/IMPLIB:' + str(image.with_suffix('.lib'))]
    c.save(out / 'link-plan.json', dict(command=command, inputs=inputs,
        compiled_records=[b.identity(compiled_path), *retained], removed_test_records=removed,
        base=b.identity(base_path), host_translation_units=1,
        SDK_builds=0, native_CPU_builds=0, NVCC_builds=0, shaders=0))
    env, _ = b.environment(command, [row['path'] for row in inputs], out)
    c.execute('link', command, env, out)
    runtime = c.read(BASE / 'runtime-environment.json')
    for dll in runtime['staged_dlls']:
        assert b.identity(dll['path']) == dll
        os.link(dll['path'], out / Path(dll['path']).name)
    runtime['PATH'] = str(out) + ';' + ';'.join(p for p in runtime['PATH'].split(';') if c.key(p) != c.key(str(BASE)))
    runtime['staged_dlls'] = [b.identity(p) for p in out.glob('*.dll')]
    runtime.pop('identical_executable', None)  # This is a new Qwen host image.
    runtime['previous'] = b.identity(BASE / 'runtime-environment.json')
    runtime['full_SDK_builds'] = runtime['native_CPU_TUs'] = runtime['NVCC_builds'] = 0
    runtime['host_translation_units'] = 1
    c.save(out / 'runtime-environment.json', runtime)
    c.save(out / 'ready.json', dict(image=b.identity(image), source_record=b.identity(compiled_path)))
    print('LINKED one Qwen host TU with cached BZ product/runtime closure', flush=True)


def run(link_attempt, attempt, selected, timeout):
    spec_run = importlib.util.spec_from_file_location('original_quality_run', R / '.scratch/qwen-mtp-quality-20261022/run_quality.py')
    q = importlib.util.module_from_spec(spec_run)
    spec_run.loader.exec_module(q)
    folder = S / f'tests-link{link_attempt}'
    ready = c.read(folder / 'ready.json')
    image = ready['image']
    assert b.identity(image['path']) == image
    # Do not silently run a stale host object after a source/pin change.
    actual = c.read(ready['source_record']['path'])
    assert b.identity(ready['source_record']['path']) == ready['source_record']
    assert all(b.identity(row['path']) == row for row in [actual['source'], actual['object'], *actual['dependencies']])
    role_dir = S / 'B02/original-roles'
    receipt = c.read(role_dir / 'acquisition.json')
    manifest = c.read(role_dir / 'manifest.json')
    assert receipt['complete'] and manifest['complete']
    assert receipt['original_roles'] == manifest['original_roles'] == 29
    assert receipt['role_payload_bytes'] == manifest['source_bytes'] == 6679513088
    assert all(row['complete'] for row in receipt['roles'])
    env = os.environ.copy()
    env['PATH'] = c.read(folder / 'runtime-environment.json')['PATH']
    role_paths = dict(
        HYLE_QWEN_BFLOAT_27_DIR=role_dir,
        HYLE_QWEN27_ORIGINAL_TARGET_DIR=R / '.scratch/qwen27-target-verifier-20261023/original-target63',
        HYLE_QWEN24_ORIGINAL_TARGET_DIR=R / '.scratch/q24-target-verifier-20261023/original-target91',
        HYLE_QWEN27_MTP_INPUT_DIR=R / '.scratch/qwen-original-mtp-20261022/original-q27',
        HYLE_QWEN24_MTP_KV_DIR=R / '.scratch/qwen24-original-mtp-20261022/original-q24',
        HYLE_QWEN27_ORIGINAL_NEXTN_DIR=R / '.scratch/mtp-next-original-20261023/original-q27-nextn',
        HYLE_QWEN24_ORIGINAL_NEXTN_DIR=R / '.scratch/q24-original-nextn-20261023/original-q24-nextn')
    for name, path in role_paths.items():
        assert path.is_dir(), str(path)
        env[name] = str(path)
    temporary = S / 'runtime-tmp'
    temporary.mkdir(exist_ok=True)
    env['TMP'] = env['TEMP'] = str(temporary)
    out = S / f'checks{attempt}'
    xml = out / 'results.xml'
    expected = CASES[selected]
    command = [image['path'], '--gtest_filter=' + ':'.join(expected), '--gtest_output=xml:' + str(xml)]
    process = q.execute(command, env, out, timeout=timeout)
    result = dict(process=process, image=image, selected_cases=expected,
        environment={name:str(path) for name,path in role_paths.items()},
        artifact_manifest=b.identity(role_dir / 'manifest.json'),
        throughput_evidence=False, physical_memory_evidence=False, whole_original_model=False)
    if xml.is_file():
        tree = ET.parse(xml).getroot()
        result.update(tests=int(tree.attrib['tests']), failures=int(tree.attrib['failures']),
            errors=int(tree.attrib['errors']), disabled=int(tree.attrib['disabled']),
            skips=sum(case.find('skipped') is not None for case in tree.iter('testcase')),
            cases=[dict(attributes=case.attrib, properties={p.attrib['name']:p.attrib['value']
                for p in case.iter('property')}) for case in tree.iter('testcase')])
    c.save(out / 'summary.json', result)
    assert process['exit'] == 0 and not process['timed_out'], process
    assert result.get('tests') == len(expected) and not any(result[k] for k in ('failures','errors','disabled','skips')), result
    observed = {case['attributes']['classname'] + '.' + case['attributes']['name'] for case in result['cases']}
    assert observed == set(expected)
    print('PASS actual Qwen BF16/related F32 cases', len(expected), flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action', choices=['link', 'run'])
    parser.add_argument('--attempt', type=int, required=True)
    parser.add_argument('--compile-attempt', type=int, default=3)
    parser.add_argument('--link-attempt', type=int, default=1)
    parser.add_argument('--case', choices=list(CASES), default='cpu-bfloat')
    parser.add_argument('--timeout', type=int, default=1800)
    args = parser.parse_args()
    assert min(args.attempt, args.compile_attempt, args.link_attempt, args.timeout) > 0
    if args.action == 'link':
        link(args.attempt, args.compile_attempt)
    else:
        run(args.link_attempt, args.attempt, args.case, args.timeout)
