"""B02: authenticate four exact safetensors headers; never fetch tensor bytes.

Root command: python .scratch/qwen-bfloat-selected-20261023/fetch_headers.py
Uses the existing bounded206 implementation; the only requests are each file's
8-byte length and <=1MiB JSON header. Existing stage content is preserved.
"""
from pathlib import Path
import hashlib
import importlib.util
import json

S = Path(__file__).resolve().parent
R = S.parents[1]
OUT = S / 'B02'
REPO = 'Qwen/Qwen3.8-27B'
REV = '1d4bf0f2ff6012fd82039f2fa52739d0dd7c60c0'
HELPER = R / '.scratch/mtp-artifact-schema-20261023/fetch_headers.py'


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def identity(path):
    raw = Path(path).read_bytes()
    return dict(path=Path(path).relative_to(R).as_posix(), bytes=len(raw),
                sha256=hashlib.sha256(raw).hexdigest())


def save(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


def main():
    plan_path = OUT / 'header-plan.json'
    plan = read(plan_path)
    assert (plan['repository'], plan['revision'], len(plan['roles'])) == (REPO, REV, 29)
    assert plan['sections'] == dict(nextn=dict(roles=17, bytes=5934992384),
                                    target63=dict(roles=12, bytes=744520704))
    required = {f'model-{n:05d}-of-00018.safetensors' for n in (3, 16, 17, 18)}
    assert {row['file'] for row in plan['shards']} == required
    index_identity = plan['source']['index']
    assert identity(R / index_identity['path']) == index_identity
    index = read(R / index_identity['path'])['weight_map']
    assert len(index) == 1199 and all(index[r['name']] == r['source_file'] for r in plan['roles'])
    spec = importlib.util.spec_from_file_location('fixed_bounded_mtp_headers', HELPER)
    helper = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(helper)  # Existing helper's __main__ is not invoked.
    helper.S = S
    helper.MAX_TOTAL = 4 * (helper.MAX_HEADER + 8)
    receipts, roles = [], []
    try:
        for shard_number, shard in enumerate(plan['shards']):
            tensors, receipt = helper.header('B02', REPO, REV, shard['file'])
            receipts.append(receipt)
            for row in plan['roles']:
                if row['source_file'] != shard['file']:
                    continue
                actual = tensors[row['name']]
                assert (actual['dtype'], actual['shape'], actual['data_offsets']) == (
                    row['dtype'], row['shape'], row['data_relative_half_open']), row['name']
                start, end = actual['data_offsets']
                assert end - start == row['bytes']
                roles.append(dict(row, source_shard=shard_number,
                                  absolute_inclusive=[receipt['data_base'] + start,
                                                      receipt['data_base'] + end - 1]))
        assert len(roles) == 29 and len({r['name'] for r in roles}) == 29
        assert {r['name'] for r in roles if r['name'].startswith('mtp.')} == {
            name for name in index if name.startswith('mtp.')}
        assert {r['name'] for r in roles if r['name'].startswith('model.language_model.layers.63.')} == {
            name for name in index if name.startswith('model.language_model.layers.63.')}
        shards = [dict(file=r['file'], url=r['url'], header=r['header'],
                       data_base=r['data_base'], etag=r['etag'],
                       whole_file_bytes=r['whole_file_bytes']) for r in receipts]
        outputs = []
        for section, filename in [(None, 'static-plan.json'), ('nextn', 'nextn-plan.json'),
                                  ('target63', 'target-plan.json')]:
            chosen = [dict(r) for r in roles if section is None or r['section'] == section]
            chosen.sort(key=lambda r:(r['source_shard'], r['data_relative_half_open'][0]))
            for ordinal, row in enumerate(chosen):
                row['ordinal'] = ordinal
            record = dict(id='B02', repository=REPO, revision=REV, hf=plan['hf'],
                          original_roles=len(chosen), source_bytes=sum(r['bytes'] for r in chosen),
                          shards=shards, roles=chosen, geometry=plan['geometry'],
                          source_header_plan=identity(plan_path), header_receipts=receipts,
                          complete_absolute_ranges=True, metadata_only=True,
                          tensor_payload_bytes=0, whole_shards_downloaded=False,
                          artifact_executed=False, native_builds=0)
            path = OUT / filename
            save(path, record)
            outputs.append(identity(path))
        save(OUT / 'summary.json', dict(repository=REPO, revision=REV,
             complete=True, complete_absolute_ranges=True, helper=identity(HELPER),
             plans=outputs, headers=receipts, tensor_payload_bytes=0,
             network_metadata_bytes=sum(r['bytes'] for r in helper.requests if r.get('complete')),
             metadata_network_limit=helper.MAX_TOTAL, native_builds=0,
             scope='17 distinct original BF16 NextN/vocabulary roles and12 target63/globalnorm roles; no weight body or original-artifact execution is claimed.'))
        print(json.dumps(read(OUT / 'summary.json'), ensure_ascii=False))
    finally:
        save(OUT / 'http-requests.json', helper.requests)


if __name__ == '__main__':
    main()
