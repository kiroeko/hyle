"""Q14 cached-header-only plan. No HTTP, tensor body or guessed offsets."""
import hashlib
import importlib.util
import json
import math
from pathlib import Path
import sys

sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
R = S.parents[2]
CACHE = R / '.scratch/architecture-refactor-2026-10-18/gguf-nvfp4/header'
HEADER = CACHE / 'model.header.bin'
HTTP = CACHE / 'header.http.json'
INVENTORY = CACHE / 'header-inventory.json'
PARSER = R / '.scratch/mtp-artifact-schema-20261023/gguf_metadata.py'
SEMANTICS = S.parent / 'review/b04-fidelity-next.json'
REPO = 'cdiamond/Qwen3.8-27B-iMatrix-NVFP4-MTP-GGUF'
REV = 'ac343e8f44caef0896f79d372ecc07ef7ab34ec8'
FILE = 'Qwen3.8-27B-iMatrix-NVFP4-MTP.gguf'
VARIANT = 'iMatrix-NVFP4-MTP'
URL = f'https://hf-mirror.net/{REPO}/resolve/{REV}/{FILE}'
COUNT, BODY, WHOLE, BASE = 29, 2900606976, 17125207136, 10996832
TYPES = {0: ('F32', 1, 4), 8: ('Q8_0', 32, 34), 13: ('Q5_K', 256, 176),
         14: ('Q6_K', 256, 210), 40: ('NVFP4', 64, 36)}
PINS = {
    HEADER: 'd6b286fea2fceacbbaf9e40428ad40afd973506925de4ae3093476d9b02229cf',
    HTTP: '2acea2bf3e22a980429f267eee35d4e6550d8624acca3c34624cf038e39565f5',
    INVENTORY: 'a917ce8175bae0a2dbe42c53a4f080c15ac4a0b51a84d21d4b6f253266949f34',
    PARSER: 'e3204073182c535c03570ad3b13e6ac51dfc8b5f6998f2cc5e6c38a55daf3f8f',
    SEMANTICS: '05f38e8bf87ec76988d197578c44bb55465669eaa6304879cc56d35a60684e1d',
}


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':'),
        ensure_ascii=True, allow_nan=False).encode()).hexdigest()


def identity(path):
    path = Path(path)
    raw = path.read_bytes()  # Structural metadata only.
    return dict(path=path.relative_to(R).as_posix(), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


def checked_header():
    for path, expected in PINS.items():
        assert identity(path)['sha256'] == expected, str(path)
    http, inventory = read(HTTP), read(INVENTORY)
    assert http['status'] == 206 and http['revision'] == REV and http['file'] == FILE
    assert http['url'] == f'https://huggingface.co/{REPO}/resolve/{REV}/{FILE}?download=true'
    headers = http['response_headers']
    etag = headers['etag']
    assert etag == '"46aae0fb441164b024a25294a79728ffaf2b8cd5eb43fa75b4680f690ec642cb"'
    assert headers['content-range'] == f'bytes 0-33554431/{WHOLE}'
    assert headers['content-length'] == '33554432' and http['total_file_size'] == WHOLE
    assert http['application_bytes_read'] == http['data_offset'] == BASE
    assert http['tensor_payload_bytes_read'] == 0 and http['whole_file_download'] is False
    assert inventory['complete'] is True and inventory['tensor_count'] == 866
    assert (inventory['repository'], inventory['revision'], inventory['file'], inventory['file_size']) == (REPO, REV, FILE, WHOLE)
    assert inventory['file_payload_hash_verified'] is False
    raw = HEADER.read_bytes()
    assert len(raw) == BASE
    spec = importlib.util.spec_from_file_location('q14_existing_gguf_metadata', PARSER)
    parser = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(parser)
    metadata, tensors, count = parser.parse_header(raw, 866, BASE, whole_file_bytes=WHOLE)
    assert count == inventory['kv_count'] == 50
    original = {row['name']: row for row in inventory['tensors']}
    assert len(original) == len(tensors) == 866
    table = {}
    for row in tensors:
        dtype, block, stored = TYPES[row['dtype_code']]
        assert row['shape'][0] % block == 0 and row['offset'] % metadata.get('general.alignment', 32) == 0
        size = math.prod(row['shape']) // block * stored
        first = BASE + row['offset']
        old = original[row['name']]
        assert (row['shape'], row['dtype_code'], dtype, size, row['offset'], [first, first + size]) == (
            old['ggml_shape'], old['type_id'], old['type_name'], old['bytes'],
            old['relative_data_offset'], old['absolute_data_interval'])
        assert first >= BASE and first + size <= WHOLE
        table[row['name']] = dict(row, dtype=dtype, bytes=size)
    ordered = sorted(table.values(), key=lambda row: row['offset'])
    assert all(a['offset'] + a['bytes'] <= b['offset'] for a, b in zip(ordered, ordered[1:]))
    # Parser drops tokenizer fields by construction. This is the actual GGUF
    # configuration digest, not an official base config or tokenizer hash.
    assert not any(key.startswith('tokenizer.') for key in metadata)
    configuration_digest = digest(metadata)
    manifest_digest = digest(dict(repository=REPO, revision=REV, file=FILE,
        header_sha256=PINS[HEADER], tensors=[dict(name=x['name'], shape=x['shape'],
            dtype=x['dtype'], dtype_code=x['dtype_code'], offset=x['offset'], bytes=x['bytes'])
            for x in tensors_to_table_order(tensors, table)]))
    return table, metadata, etag, configuration_digest, manifest_digest


def tensors_to_table_order(tensors, table):
    return [table[row['name']] for row in tensors]


def plan():
    table, metadata, etag, config_digest, manifest_digest = checked_header()
    semantic = read(SEMANTICS)['role_manifest']  # Names/shapes only, never B04 codecs or bytes.
    assert len(semantic) == 29
    roles = []
    for spec in sorted(semantic, key=lambda row: table[row['name']]['offset']):
        row = table[spec['name']]
        assert row['shape'] == spec['gguf_shape']
        first = BASE + row['offset']
        roles.append(dict(index=len(roles), name=row['name'], filename=row['name'] + '.bin',
            section='target63' if spec['group'] == 'target63_and_global_norm' else 'nextn',
            dtype=row['dtype'], dtype_code=row['dtype_code'], shape=row['shape'], bytes=row['bytes'],
            source_shard=0, data_relative_half_open=[row['offset'], row['offset'] + row['bytes']],
            absolute_inclusive=[first, first + row['bytes'] - 1]))
    assert len(roles) == COUNT and sum(row['bytes'] for row in roles) == BODY
    assert sum(row['section'] == 'nextn' for row in roles) == 17
    assert sum(row['section'] == 'target63' for row in roles) == 12
    assert next(x for x in roles if x['name'] == 'token_embd.weight')['bytes'] == 1042944000
    assert next(x for x in roles if x['name'] == 'output.weight')['bytes'] == 1350860800
    proof = dict(proof_kind='local replay of exact cached original header; no new HTTP',
        header=identity(HEADER), historical_http=identity(HTTP), inventory=identity(INVENTORY),
        parser=identity(PARSER), semantic_names_shapes=identity(SEMANTICS),
        tensors=866, data_base=BASE, whole_file_bytes=WHOLE, tensor_payload_bytes=0,
        base_revision=None, configuration_digest=config_digest, manifest_digest=manifest_digest,
        configuration_digest_rule='SHA256 canonical JSON of actual non-tokenizer GGUF metadata',
        manifest_digest_rule='SHA256 canonical JSON of original repository/revision/file/header SHA and all866 original tensor names/shapes/types/offsets/bytes')
    result = dict(repository=REPO, revision=REV, file=FILE, variant=VARIANT,
        original_roles=COUNT, source_bytes=BODY, roles=roles,
        shards=[dict(file=FILE, url=URL, etag=etag, whole_file_bytes=WHOLE, data_base=BASE, header=identity(HEADER))],
        metadata_only=True, tensor_payload_bytes=0, complete_absolute_ranges=True,
        source_header=identity(HEADER), historical_http=identity(HTTP), source_inventory=identity(INVENTORY),
        configuration_digest=config_digest, manifest_digest=manifest_digest, base_revision=None,
        geometry=dict(hidden=5120, heads=24, kv_heads=4, depth=256, rotary=64,
            intermediate=17408, vocabulary=248320, target_layer=63, nextn_layer=64),
        whole_file_sha256_declared_only=read(INVENTORY)['expected_file_lfs_sha256'],
        whole_file_sha256_verified=False, artifact_executed=False,
        transport='Exclusive https://hf-mirror.net, no cross-origin redirect or fallback')
    return result, proof


def checked_plan():
    path = S / 'loose-plan.json'
    expected, proof = plan()
    assert read(path) == expected and read(S / 'header.json') == proof
    return path, expected


def main():
    value, proof = plan()
    for name, content in [('loose-plan.json', value), ('header.json', proof)]:
        path = S / name
        if path.exists():
            assert read(path) == content, 'Refuse to replace different fixed metadata'
        else:
            path.write_text(json.dumps(content, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(dict(plan=identity(S / 'loose-plan.json'), roles=COUNT, source_bytes=BODY, network_requests=0)))


if __name__ == '__main__':
    main()
