"""Root-only Q14 exact29-role acquisition through existing QB+8MiB transport.

--plan-only does no HTTP. Actual HTTP requires the existing net-only budget
runner, whose redirect handler rejects cross-origin before opening it.
"""
import argparse
import importlib.util
import json
from pathlib import Path
import sys
import urllib.request

sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
R = S.parents[2]


def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


def configured():
    schema = module('q14_checked_loose_schema', S / 'prepare_loose_plan.py')
    common = module('q14_existing_loose_acquisition', R / '.scratch/qwen-bfloat-selected-20261023/fetch_roles.py')
    capped = module('q14_existing_request_cap', S.parent / 'offline/request-chunk/next-source/fetch_roles.py')
    capped.R, capped.HELPER, capped.HELPER_SHA = common.R, common.HELPER, common.HELPER_SHA
    original_manifests = common.manifests
    common.ARTIFACT_DIR, common.REPO, common.REV = S, schema.REPO, schema.REV
    common.COUNT, common.BODY = schema.COUNT, schema.BODY
    common.NEXTN_COUNT, common.TARGET_COUNT, common.TARGET_SECTION = 17, 12, 'target63'
    common.checked_plan = schema.checked_plan
    def downloader(record, receipt):
        functions = capped.downloader(record, receipt, request_chunk_bytes=8*1024*1024)
        with functions['LOCK']:
            record.update(request_chunk_bytes=8*1024*1024, authenticated_chunk_limit_bytes=common.CHUNK)
        return functions
    common.downloader = downloader

    def manifests(out, record):
        original_manifests(out, record)
        for name in ('manifest.json', 'nextn-manifest.json', 'target-manifest.json'):
            path = out / name
            value = common.read(path)
            value.update(file=schema.FILE, variant=schema.VARIANT,
                source_receipt=common.identity(out / 'acquisition.json'),
                source_plan=common.identity(S / 'loose-plan.json'),
                source_header=common.identity(S / 'header.json'),
                original_header=common.identity(schema.HEADER),
                scope='Actual Q14 GGUF NVFP4/Q5_K/Q6_K/Q8_0/F32 per-role bytes. No repack, whole GGUF, duplicated vocab, base-revision or execution claim.')
            path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    common.manifests = manifests
    return common


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--plan-only', action='store_true')
    args = parser.parse_args()
    common = configured()
    if args.plan_only:
        path, plan = common.checked_plan()
        assert common.identity(common.HELPER)['sha256'] == common.HELPER_SHA
        print(json.dumps(dict(repository=common.REPO, revision=common.REV,
            roles=common.COUNT, body_bytes=common.BODY,
            output_directory=(S / 'original-roles').relative_to(R).as_posix(),
            new_request_bytes=8*1024*1024, authenticated_chunk_limit_bytes=common.CHUNK,
            stream_buffer_bytes=common.IO, role_workers=common.WORKERS,
            source_plan=common.identity(path), network_requests=0)))
        return
    # The shared budget wrapper owns redirect validation and request accounting.
    # Refuse an unguarded standalone HTTP run instead of silently bypassing it.
    opener = urllib.request.urlopen
    expected = R / '.scratch/mtp-download-budget-20261023/budget.py'
    code = getattr(opener, '__code__', None)
    assert code is not None and Path(code.co_filename).resolve() == expected.resolve(), 'Use run_batch.py; unguarded Q14 HTTP is forbidden'
    assert opener.__globals__.get('MIRROR_HOST') == 'hf-mirror.net'
    assert opener.__qualname__ == 'guarded.<locals>.open_range'
    common.main()


if __name__ == '__main__':
    main()
