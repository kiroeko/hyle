#pragma once

#include <array>
#include <cstdint>
#include <string_view>
#include "qwen27_original_nextn_roles.h"
#include "d5_qwen38_gdn_fixture.h"

// Pins generated only from the completed fixed-revision loose acquisition.
// Actual per-role GGUF codecs; no repack, fallback or duplicate vocabulary.
namespace qwen_gguf_original_artifacts::q14 {
namespace roles=qwen27_original_nextn_roles;
namespace c=hyle::compute;
inline constexpr qwen_original_mtp_roles::Identity kIdentity{
    "cdiamond/Qwen3.8-27B-iMatrix-NVFP4-MTP-GGUF","ac343e8f44caef0896f79d372ecc07ef7ab34ec8","iMatrix-NVFP4-MTP","Qwen3.8-27B-iMatrix-NVFP4-MTP.gguf"};
// Original Qwen base revision is unknown; do not borrow the official model revision.
inline constexpr bool kBaseRevisionKnown=false;
inline constexpr c::ModelArtifactProfileDescription kProfile{
    .model_publisher="cdiamond",
    .model_repository="cdiamond/Qwen3.8-27B-iMatrix-NVFP4-MTP-GGUF",
    .model_family="qwen35",
    .model_name="Qwen3.8-27B-iMatrix-NVFP4-MTP",
    .model_revision="ac343e8f44caef0896f79d372ecc07ef7ab34ec8",
    .configuration_digest="5059e18410a87515ce3f3b105eb089af65b7d17d7cfe4d51478960c74e5496ce",
    .artifact_repository="cdiamond/Qwen3.8-27B-iMatrix-NVFP4-MTP-GGUF",
    .artifact_revision="ac343e8f44caef0896f79d372ecc07ef7ab34ec8",
    .variant="iMatrix-NVFP4-MTP",
    .manifest_digest="213bc91a8c51b96fd5a049ae649353dacce20dbd32d62161f5c4157e2219dbfa",
    .format_family="gguf",
};
inline constexpr std::uint64_t kOriginalBytes=2900606976ULL;
inline constexpr std::string_view kReceiptSha256="858af4690264f3943bfa113d59346f29a505c6ede50caa4244f9787425409fdb";
inline constexpr std::string_view kManifestSha256="4ccaca29be8cbb0e5ed23bc1da376ce52c944668e2d45e3ab79fc5c8617c67d5";
inline constexpr std::string_view kHeaderSha256="d6b286fea2fceacbbaf9e40428ad40afd973506925de4ae3093476d9b02229cf";
inline constexpr std::string_view kPlanSha256="402814de361440076bcd7edc3cb30137ea271733bc80e1e1815914a65df9eccd";
inline std::array<roles::ManifestSpec,29> manifest() {
  return {{
    {"output.weight","output.weight.bin","06dbe1f91f939d44cce18e62d71d6ed5555eb46142682e33d4dc22bf6b820030",GGML_TYPE_Q8_0,roles::original::detail::take(c::gguf_weight_description(c::GgufQuantizedType::kQ8_0,c::DataType::kFloat32,5120,248320),"Q14 original Q8_0 RHS")},
    {"output_norm.weight","output_norm.weight.bin","b3ba4f3231a21b1559f52115d3bffc7c28dcd03e4be22df269ef97a3f5d4bfbf",GGML_TYPE_F32,roles::original::detail::take(c::TensorDesc::dense(c::DataType::kFloat32,std::array<std::int64_t,1>{5120}),"B04 original plain role")},
    {"token_embd.weight","token_embd.weight.bin","7f1e9796461977d3d5315e30d04304d41ccc4bba3e2686e7815518853fe0e721",GGML_TYPE_Q6_K,roles::original::detail::take((roles::original::detail::take(c::gguf_weight_description(c::GgufQuantizedType::kQ6K,c::DataType::kFloat32,5120,248320),"Q14 original Q6_K RHS")).transposed(),"Q14 original Q6_K Gather rows")},
    {"blk.63.attn_k.weight","blk.63.attn_k.weight.bin","1a587aa0798ac9e46c68fb714544d8e4bf44ab16b71f060cc3c581e209066209",GGML_TYPE_Q5_K,roles::original::detail::take(c::gguf_weight_description(c::GgufQuantizedType::kQ5K,c::DataType::kFloat32,5120,1024),"Q14 original Q5_K RHS")},
    {"blk.63.attn_k_norm.weight","blk.63.attn_k_norm.weight.bin","dd2837b022e7bb5f24223f7937c377658d72258baf44072def2bff47fbf5c039",GGML_TYPE_F32,roles::original::detail::take(c::TensorDesc::dense(c::DataType::kFloat32,std::array<std::int64_t,1>{256}),"B04 original plain role")},
    {"blk.63.attn_norm.weight","blk.63.attn_norm.weight.bin","fff0b300a720e0626a1b5982729a66769cfcb796f9cfbfe2e02293a7e448b073",GGML_TYPE_F32,roles::original::detail::take(c::TensorDesc::dense(c::DataType::kFloat32,std::array<std::int64_t,1>{5120}),"B04 original plain role")},
    {"blk.63.attn_output.weight","blk.63.attn_output.weight.bin","f7c0d22fca1dbf815f73f5c28fc27b1eeb721f0ef6eb228e57f359d9e2ef72df",GGML_TYPE_Q5_K,roles::original::detail::take(c::gguf_weight_description(c::GgufQuantizedType::kQ5K,c::DataType::kFloat32,6144,5120),"Q14 original Q5_K RHS")},
    {"blk.63.attn_q.weight","blk.63.attn_q.weight.bin","7f39fc330a6708aa4f021f10f6da7e074a9ed3b239032503a8f70da15f90bb83",GGML_TYPE_Q5_K,roles::original::detail::take(c::gguf_weight_description(c::GgufQuantizedType::kQ5K,c::DataType::kFloat32,5120,12288),"Q14 original Q5_K RHS")},
    {"blk.63.attn_q_norm.weight","blk.63.attn_q_norm.weight.bin","4d82f12e9d3e60003032eee0c0a413b85588b9253ba3bfe43456eed32a91960c",GGML_TYPE_F32,roles::original::detail::take(c::TensorDesc::dense(c::DataType::kFloat32,std::array<std::int64_t,1>{256}),"B04 original plain role")},
    {"blk.63.attn_v.weight","blk.63.attn_v.weight.bin","855806f3d2b62f41f8aa917dc2fc2505d5c0936994778fd326005c483536b176",GGML_TYPE_Q5_K,roles::original::detail::take(c::gguf_weight_description(c::GgufQuantizedType::kQ5K,c::DataType::kFloat32,5120,1024),"Q14 original Q5_K RHS")},
    {"blk.63.ffn_down.weight","blk.63.ffn_down.weight.bin","f6006a7ac1be33fc6e68f992bd9116446e2b91c1acbb49924008d15d0f56c59d",GGML_TYPE_Q6_K,roles::original::detail::take(c::gguf_weight_description(c::GgufQuantizedType::kQ6K,c::DataType::kFloat32,17408,5120),"Q14 original Q6_K RHS")},
    {"blk.63.ffn_gate.weight","blk.63.ffn_gate.weight.bin","cdf3340566cb184bc055d10f499e03c7b951668dfbcebdda9f18ca08d768bb17",GGML_TYPE_Q5_K,roles::original::detail::take(c::gguf_weight_description(c::GgufQuantizedType::kQ5K,c::DataType::kFloat32,5120,17408),"Q14 original Q5_K RHS")},
    {"blk.63.ffn_up.weight","blk.63.ffn_up.weight.bin","272520f45cf57547bc4cf0735f235780164d598271464c9ad3f0ca7696b4105a",GGML_TYPE_Q5_K,roles::original::detail::take(c::gguf_weight_description(c::GgufQuantizedType::kQ5K,c::DataType::kFloat32,5120,17408),"Q14 original Q5_K RHS")},
    {"blk.63.post_attention_norm.weight","blk.63.post_attention_norm.weight.bin","bd1d77170441438d96258413ed00462a96a4290341dbcc78cf66c9990aa06506",GGML_TYPE_F32,roles::original::detail::take(c::TensorDesc::dense(c::DataType::kFloat32,std::array<std::int64_t,1>{5120}),"B04 original plain role")},
    {"blk.64.attn_k.weight","blk.64.attn_k.weight.bin","5b48157791f84e529074729b5ab3a2d1cdfd10da39c887a860dbcb0118372744",GGML_TYPE_NVFP4,roles::original::detail::take(c::gguf_weight_description(c::GgufQuantizedType::kNvfp4,c::DataType::kFloat32,5120,1024),"Q14 original NVFP4 RHS")},
    {"blk.64.attn_k_norm.weight","blk.64.attn_k_norm.weight.bin","13e8086a61052d510f01a7984b2ac7c5012337887e80594331ddef3a6a0f05c7",GGML_TYPE_F32,roles::original::detail::take(c::TensorDesc::dense(c::DataType::kFloat32,std::array<std::int64_t,1>{256}),"B04 original plain role")},
    {"blk.64.attn_norm.weight","blk.64.attn_norm.weight.bin","afb539011550a9d32f6cfb14db69b9aaed81e63fbd732124e020ae9903e0f275",GGML_TYPE_F32,roles::original::detail::take(c::TensorDesc::dense(c::DataType::kFloat32,std::array<std::int64_t,1>{5120}),"B04 original plain role")},
    {"blk.64.attn_output.weight","blk.64.attn_output.weight.bin","59489d7b80731a2b383a4d5d5a4b66618e3ca72c592a519ee0497b1d4d1a44bb",GGML_TYPE_NVFP4,roles::original::detail::take(c::gguf_weight_description(c::GgufQuantizedType::kNvfp4,c::DataType::kFloat32,6144,5120),"Q14 original NVFP4 RHS")},
    {"blk.64.attn_q.weight","blk.64.attn_q.weight.bin","b25c4f3d1bc33579699f3fc8f0747e4a28abc547ed9ce56c62469bbb57144e0b",GGML_TYPE_NVFP4,roles::original::detail::take(c::gguf_weight_description(c::GgufQuantizedType::kNvfp4,c::DataType::kFloat32,5120,12288),"Q14 original NVFP4 RHS")},
    {"blk.64.attn_q_norm.weight","blk.64.attn_q_norm.weight.bin","4a7f959094211b3dade3324736bb75e25c61a9197e025102646e7f74bd094a48",GGML_TYPE_F32,roles::original::detail::take(c::TensorDesc::dense(c::DataType::kFloat32,std::array<std::int64_t,1>{256}),"B04 original plain role")},
    {"blk.64.attn_v.weight","blk.64.attn_v.weight.bin","61a81a6795403c7c8864207d4550ed865ee97602da64714cd79b4c8fe2525dc9",GGML_TYPE_NVFP4,roles::original::detail::take(c::gguf_weight_description(c::GgufQuantizedType::kNvfp4,c::DataType::kFloat32,5120,1024),"Q14 original NVFP4 RHS")},
    {"blk.64.ffn_down.weight","blk.64.ffn_down.weight.bin","42ab7abf17becd6ebdafe11b3c7185043af8ee75842af69bde7b1c8ace0909fb",GGML_TYPE_NVFP4,roles::original::detail::take(c::gguf_weight_description(c::GgufQuantizedType::kNvfp4,c::DataType::kFloat32,17408,5120),"Q14 original NVFP4 RHS")},
    {"blk.64.ffn_gate.weight","blk.64.ffn_gate.weight.bin","af6bcee3546bdbdc027ade2b9d643d1bbc265503c4037137b0d5e2bf336903c4",GGML_TYPE_NVFP4,roles::original::detail::take(c::gguf_weight_description(c::GgufQuantizedType::kNvfp4,c::DataType::kFloat32,5120,17408),"Q14 original NVFP4 RHS")},
    {"blk.64.ffn_up.weight","blk.64.ffn_up.weight.bin","862622c726cf1dc9fc9287ac5bc254a2a73b62f665d441c8aa18950a382a6071",GGML_TYPE_NVFP4,roles::original::detail::take(c::gguf_weight_description(c::GgufQuantizedType::kNvfp4,c::DataType::kFloat32,5120,17408),"Q14 original NVFP4 RHS")},
    {"blk.64.nextn.eh_proj.weight","blk.64.nextn.eh_proj.weight.bin","ad2e3e3a697f64a5bb3d0f6b0db12ef14954a6b2b40f23df08fe836c431dae7f",GGML_TYPE_NVFP4,roles::original::detail::take(c::gguf_weight_description(c::GgufQuantizedType::kNvfp4,c::DataType::kFloat32,10240,5120),"Q14 original NVFP4 RHS")},
    {"blk.64.nextn.enorm.weight","blk.64.nextn.enorm.weight.bin","d96abe72c938e866b5a8bdaa8aa9f8590577f55bef6281c2e9fce892db518d97",GGML_TYPE_F32,roles::original::detail::take(c::TensorDesc::dense(c::DataType::kFloat32,std::array<std::int64_t,1>{5120}),"B04 original plain role")},
    {"blk.64.nextn.hnorm.weight","blk.64.nextn.hnorm.weight.bin","e9247e9fc08ebd0ca8f14a610cfd1046a0115143f6967de9d520647149890ac2",GGML_TYPE_F32,roles::original::detail::take(c::TensorDesc::dense(c::DataType::kFloat32,std::array<std::int64_t,1>{5120}),"B04 original plain role")},
    {"blk.64.nextn.shared_head_norm.weight","blk.64.nextn.shared_head_norm.weight.bin","afdf2c4845dcce4470aeaf40e1726690b606eb642c5a4145a0e3f2598b0734d0",GGML_TYPE_F32,roles::original::detail::take(c::TensorDesc::dense(c::DataType::kFloat32,std::array<std::int64_t,1>{5120}),"B04 original plain role")},
    {"blk.64.post_attention_norm.weight","blk.64.post_attention_norm.weight.bin","fcfcdbdb492b9a1c31ca44997a188982a68e0741df67f36080c0562da6b7c6dd",GGML_TYPE_F32,roles::original::detail::take(c::TensorDesc::dense(c::DataType::kFloat32,std::array<std::int64_t,1>{5120}),"B04 original plain role")},
  }};
}
} // namespace qwen_gguf_original_artifacts::q14
