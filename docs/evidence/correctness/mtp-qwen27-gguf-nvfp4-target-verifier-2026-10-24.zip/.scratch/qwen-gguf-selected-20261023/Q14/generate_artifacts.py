"""Q14 thin actual-pin generator. Missing/incomplete acquisition emits nothing."""
import argparse
import importlib.util
import json
from pathlib import Path
import sys

sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
R = S.parents[2]


def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


def profile(plan, quoted):
    # The converted artifact revision is known; its source-base revision is not.
    values = dict(model_publisher='cdiamond', model_repository=plan['repository'],
        model_family='qwen35', model_name=plan['file'].removesuffix('.gguf'),
        model_revision=plan['revision'], configuration_digest=plan['configuration_digest'],
        artifact_repository=plan['repository'], artifact_revision=plan['revision'],
        variant=plan['variant'], manifest_digest=plan['manifest_digest'], format_family='gguf')
    return ['// Original Qwen base revision is unknown; do not borrow the official model revision.',
        'inline constexpr bool kBaseRevisionKnown=false;',
        'inline constexpr c::ModelArtifactProfileDescription kProfile{'] + [
            f'    .{name}={quoted(value)},' for name, value in values.items()] + ['};']


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, default=S / 'generated/qwen_gguf_q14_artifacts.h')
    args = parser.parse_args()
    schema = module('q14_pin_schema', S / 'prepare_loose_plan.py')
    shared = module('q14_reused_actual_gguf_emitter', S.parent / 'B04/generate_artifacts.py')
    plan, rows, receipt, manifest = shared.checked_metadata(S, variant=schema.VARIANT)
    text = shared.header(plan, rows, receipt, manifest, namespace='q14', variant=schema.VARIANT,
        directory=S, header_path=schema.HEADER, profile_lines=profile(plan, shared.quoted))
    output = args.output.resolve()
    assert output.is_relative_to(R / '.scratch') and output.suffix == '.h'
    output.parent.mkdir(parents=True, exist_ok=True)
    if output.exists():
        assert output.read_text(encoding='utf-8-sig') == text, 'Do not replace different generated pins'
    else:
        output.write_text(text, encoding='utf-8')
    proof = dict(repository=plan['repository'], revision=plan['revision'], file=plan['file'],
        original_roles=schema.COUNT, source_bytes=schema.BODY, receipt=receipt, manifest=manifest,
        source_plan=shared.identity(S / 'loose-plan.json'), original_header=shared.identity(schema.HEADER),
        header=shared.identity(output), pins_from_completed_acquisition=True,
        base_revision=None, configuration_digest=plan['configuration_digest'],
        profile_manifest_digest=plan['manifest_digest'], body_rehashed=False, artifact_executed=False)
    output.with_suffix('.json').write_text(json.dumps(proof, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(proof))


if __name__ == '__main__':
    main()
