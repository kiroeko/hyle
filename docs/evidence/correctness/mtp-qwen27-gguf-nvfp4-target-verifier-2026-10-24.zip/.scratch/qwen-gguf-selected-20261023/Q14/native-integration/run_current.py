"""Q14 real-pinned consumer, reusing the current mixed-provider image closure."""
from pathlib import Path
import argparse, importlib.util, json, os, sys, xml.etree.ElementTree as ET
sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
R = S.parents[3]

def load_module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module

h = load_module('q14_cached_build', R/'.scratch/native-paged-effects-20261022/build_windows.py')
q = load_module('q14_native_runner', R/'.scratch/qwen-mtp-quality-20261022/run_quality.py')
b, c = h.b, h.c
BASE = R/'.scratch/glm-gguf-selected-20261023/B09/integration/tests-link1'
LINK = S/'tests-link1'

def check_record(identity):
    assert b.identity(identity['path']) == identity, identity['path']
    record = c.read(identity['path'])
    for item in (record['source'], record['object'], *record['dependencies']):
        assert b.identity(item['path']) == item, item['path']
    return record

def link():
    base = c.read(BASE/'link-plan.json')
    new_path = S/'compile1/qwen-state/identity.json'
    new_record = check_record(b.identity(new_path))
    retained = []
    old_object = None
    for item in base['new_consumer_records']:
        record = c.read(item['path'])
        if Path(record['source']['path']).name == 'qwen_mtp_state_consumer_test.cc':
            assert old_object is None
            old_object = record['object']['path']
        else:
            check_record(item)
            retained.append(item)
    for item in base['retained_current_providers']:
        check_record(item)
    for item in base['retained_product_records']:
        # These cached product records were reconciled by the base current link.
        assert b.identity(item['path']) == item
        record = c.read(item['path'])
        assert b.identity(record['object']['path']) == record['object']
    assert old_object
    command = []
    replacements = 0
    for arg in base['command']:
        if arg.upper().startswith(('/OUT:', '/MAP:', '/IMPLIB:', '/PDB:')):
            continue
        if arg.lower() == old_object.lower():
            arg = new_record['object']['path']
            replacements += 1
        command.append(arg)
    assert replacements == 1
    LINK.mkdir(parents=True, exist_ok=False)
    (LINK/'tmp').mkdir()
    image = LINK/'q14-checks.exe'
    command += ['/OUT:'+str(image), '/MAP:'+str(image.with_suffix('.map')),
                '/IMPLIB:'+str(image.with_suffix('.lib'))]
    c.save(LINK/'link-plan.json', dict(
        command=command, base=b.identity(BASE/'link-plan.json'),
        new_consumer_record=b.identity(new_path), retained_consumer_records=retained,
        retained_current_providers=base['retained_current_providers'],
        retained_product_records=base['retained_product_records'],
        SDK_builds=0, NVCC_builds=0, host_translation_units=1,
        note='Fresh Qwen TU; current mixed BF16 provider objects and GLM Pro TU.'))
    env, _ = b.environment(command, [], LINK)
    c.execute('link', command, env, LINK)
    runtime = c.read(BASE/'runtime-environment.json')
    for dll in runtime['staged_dlls']:
        assert b.identity(dll['path']) == dll
        os.link(dll['path'], LINK/Path(dll['path']).name)
    runtime['previous'] = b.identity(BASE/'runtime-environment.json')
    runtime['PATH'] = runtime['PATH'].replace(str(BASE), str(LINK))
    runtime['staged_dlls'] = [b.identity(x) for x in LINK.glob('*.dll')]
    c.save(LINK/'runtime-environment.json', runtime)
    c.save(LINK/'ready.json', dict(image=b.identity(image),
        link_plan=b.identity(LINK/'link-plan.json'),
        runtime_environment=b.identity(LINK/'runtime-environment.json')))
    print('LINKED Q14 current closure', flush=True)

def run(backend):
    ready = c.read(LINK/'ready.json')
    for field in ('image', 'link_plan', 'runtime_environment'):
        assert b.identity(ready[field]['path']) == ready[field]
    check_record(c.read(LINK/'link-plan.json')['new_consumer_record'])
    env = {k:v for k,v in os.environ.items() if not k.startswith('HYLE_QWEN')}
    env['PATH'] = c.read(LINK/'runtime-environment.json')['PATH']
    env['HYLE_QWEN_Q14_ORIGINAL_DIR'] = str(S.parent/'original-roles')
    case = 'QwenMtpStateConsumer.'+backend.capitalize()+(
        'Q14OriginalNvfp4NextNAndPackedTargetFullVocabularyVerifierPublishesRepairedPrefix')
    out = S/('checks1' if backend == 'cpu' else 'checks2')
    command = [ready['image']['path'], '--gtest_filter='+case,
               '--gtest_output=xml:'+str(out/'results.xml')]
    print('START', case, flush=True)
    process = q.execute(command, env, out, timeout=1800)
    print('END', backend, process['exit'], flush=True)
    if process['exit'] != 0:
        raise SystemExit(process['exit'])
    tree = ET.parse(out/'results.xml').getroot()
    assert tree.attrib['tests'] == '1' and all(
        int(tree.attrib.get(k,0)) == 0 for k in ('failures','errors','disabled'))
    cases = tree.findall('.//testcase')
    assert len(cases) == 1 and cases[0].find('skipped') is None
    properties = {x.attrib['name']:x.attrib['value'] for x in cases[0].findall('./properties/property')}
    c.save(out/'result-summary.json', dict(case=case, backend=backend,
        image=ready['image'], process=b.identity(out/'process.json'),
        xml=b.identity(out/'results.xml'), properties=properties,
        throughput_evidence=False, memory_evidence=False,
        scope='Original Q14 finite target63/NextN64 with actual vocabulary; upstream/history fixtures, not full model quality.'))
    print(json.dumps(properties, ensure_ascii=False), flush=True)

if __name__ == '__main__':
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('action', choices=('link', 'cpu', 'cuda'))
    args = p.parse_args()
    link() if args.action == 'link' else run(args.action)
