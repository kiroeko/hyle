"""Publish only actual Q14 native results and their small reproducibility closure."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, zipfile

S = Path(__file__).resolve().parent
R = S.parents[3]
A = S.parent
D = R/'docs/evidence/correctness'
NAME = 'mtp-qwen27-gguf-nvfp4-target-verifier-2026-10-24'

def read(path): return json.loads(Path(path).read_text(encoding='utf-8-sig'))
def ident(path):
    p = Path(path).resolve(); raw = p.read_bytes()
    return dict(path=p.relative_to(R).as_posix(), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())
def save(path, value):
    Path(path).write_text(json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf-8')

pins = read(A/'generated/qwen_gguf_q14_artifacts.json')
assert pins['pins_from_completed_acquisition'] and pins['original_roles'] == 29
executions=[]
for backend,folder in (('CPU',S/'checks1'),('CUDA',S/'checks2')):
    summary=read(folder/'result-summary.json'); process=read(folder/'process.json')
    assert process['exit']==0 and not process['timed_out']
    p=summary['properties']
    assert int(p['actual_submissions'])==23 and int(p['original_source_roles'])==29
    assert int(p['original_source_bytes'])==2900606976
    assert int(p['complete_target_draft_resources'])==12
    assert p['original_manifest_sha256']==pins['manifest']['sha256']
    assert int(p['target_verifier_full_vocabulary'])==248320
    executions.append(dict(case=summary['case'],backend=backend,
        placement='CPU Context/system owner only' if backend=='CPU' else 'CUDA Context/device owner only',
        tests=1,failures=0,errors=0,skips=0,graphs=int(p['actual_submissions']),
        summary=ident(folder/'result-summary.json'),properties=p))

paths=set()
for sub in ('checks1','checks2','tests-link1','compile1/qwen-state'):
    for path in (S/sub).rglob('*'):
        if path.is_file() and path.suffix in ('.json','.log','.xml','.py','.cc'):
            paths.add(path)
for path in A.glob('*.py'): paths.add(path)
for path in S.glob('*.py'): paths.add(path)
for path in A.glob('*.json'): paths.add(path)
for path in (A/'generated').glob('*'): paths.add(path)
for path in (A/'batches/body1').rglob('*'):
    if path.is_file() and path.suffix in ('.json','.log'): paths.add(path)
for name in ('acquisition.json','manifest.json'):
    paths.add(A/'original-roles'/name)
compile_record=read(S/'compile1/qwen-state/identity.json')
for item in [compile_record['source'],*compile_record['dependencies']]:
    path=Path(item['path']).resolve()
    if path.is_relative_to(R) and path.parts[len(R.parts)] in ('tests','include','src'):
        assert ident(path)['sha256']==item['sha256'], str(path)
        paths.add(path)
paths.add(R/'.scratch/qwen-gguf-selected-20261023/B04/generate_artifacts.py')
paths.add(R/'.scratch/native-paged-effects-20261022/build_windows.py')
paths.add(R/'.scratch/qwen-mtp-quality-20261022/run_quality.py')
archive=D/(NAME+'.zip')
assert not archive.exists()
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for path in sorted(paths):
        z.write(path,path.relative_to(R).as_posix())

batch=read(A/'batches/body1/result.json') if (A/'batches/body1/result.json').exists() else None
record=dict(created_at=datetime.now(timezone.utc).isoformat(),
    identity=dict(id='Q14',repository=pins['repository'],revision=pins['revision'],variant='iMatrix-NVFP4-MTP',file=pins['file']),
    scope='Original GGUF target63, complete NVFP4 NextN64 and own original Q6_K embedding/Q8_0 full vocabulary in the existing K1/12-resource Head controller',
    original_roles=29,original_bytes=2900606976,whole_original_model=False,
    original_pins=ident(A/'generated/qwen_gguf_q14_artifacts.json'),
    source_plan=pins['source_plan'],original_header=pins['original_header'],
    acquisition=pins['receipt'],manifest=pins['manifest'],executions=executions,
    build=dict(host_translation_units=1,SDK_builds=0,NVCC_builds=0,
        compile_record=ident(S/'compile1/qwen-state/identity.json'),
        link_plan=ident(S/'tests-link1/link-plan.json'),
        retained_providers='Current mixed F32/BF16 CPU, CUDA and cuBLAS host owners; current Pro consumer and reconciled Graph/product objects retained'),
    transport=dict(endpoint='https://hf-mirror.net',cross_origin_redirects='rejected before send',
        batch_plan=ident(A/'body-batch-plan.json'),batch_directory=(A/'batches/body1').relative_to(R).as_posix(),
        requested_unique_body_bytes=2900606976,HF_reserved_bytes=0,
        body_includes_retries_note='Actual request reservations retained in batch receipt; reservations are not exact wire bytes'),
    limits=['Layer62 inputs and initial histories are finite fixtures, not a full 64-layer trained trunk.',
        'Natural accepted0 is one finite trial; forced match/rejection controls are separate, not an acceptance-rate result.',
        'No whole-model generation/task-quality, TPS, load-rate, physical-memory peak, Linux/macOS or all-device validation claim.',
        'Artifact own converted repository/revision is pinned; unknown base model revision is not borrowed from another artifact.'],
    archive=ident(archive),archived_files=len(paths),
    throughput_evidence=False,memory_evidence=False)
output=D/(NAME+'.json'); assert not output.exists(); save(output,record)
print(json.dumps(dict(evidence=ident(output),archive=ident(archive),graphs=sum(e['graphs'] for e in executions)),ensure_ascii=False))
