"""Explicit one-host-TU current-policy probe; import performs no build or run.

Root invokes compile, link and run separately. The only replaced AD link input
is the consumer object. Retained SDK/native objects are checked by path/size,
not rehashed or rebuilt. A failed action is preserved and never auto-retried.
"""
from pathlib import Path
import argparse
import importlib.util
import os
import sys


sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
R = S.parents[1]
AD = R / '.scratch/qwen-cublas-scores-20261022'
V = R / '.scratch/qwen-mtp-window-20261022'
SOURCE = S / 'source/current_probe.cc'
BASE_PLAN = AD / 'qwen-link1/link-plan.json'
PRODUCTS = [R / name for name in (
    'tools/qwen35_text/main.cc', 'tools/qwen35_text/mtp_graph.h',
    'tools/qwen35_text/mtp_session_probe.cc',
    'src/compute_provider_cublas/cublas_provider.cc',
    'src/compute_route_cuda/default_policy.cc')]
_helpers = None


def helpers():
    global _helpers
    if _helpers is None:
        spec = importlib.util.spec_from_file_location('ag_ad_helpers', AD / 'build.py')
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        _helpers = module.b, module.c
    return _helpers


def same(record):
    b, _ = helpers()
    return b.identity(record['path']) == record


def basis():
    b, c = helpers()
    base = c.read(BASE_PLAN)
    assert len(base['inputs']) == 195
    record_path = Path(base['consumer_compiled_record']['path'])
    assert same(base['consumer_compiled_record'])
    record = c.read(record_path)
    assert same(record['source']) and same(record['object'])
    current = c.read(AD / 'qwen-ready-attempt1.json')
    assert current['main'] == record['source']
    assert all(same(item) for item in current['changed_sources'])
    return base, record_path, record


def compile_probe(attempt):
    b, c = helpers()
    _, recipe_path, recipe = basis()
    assert SOURCE.is_file(), 'root must first run prepare_probe_source.py'
    frozen = [b.identity(path) for path in [SOURCE, *PRODUCTS]]
    out = S / f'compile{attempt}/probe'
    command = b.host_command(recipe['command'], SOURCE, 'probe', out)
    include = '/I' + str(R / 'tools/qwen35_text')
    if include.casefold() not in {item.casefold() for item in command}:
        command.insert(1, include)
    assert all(flag in command for flag in ('/O2', '/MD', '/W4', '/WX'))
    out.mkdir(parents=True, exist_ok=False)
    (out / 'tmp').mkdir()
    snapshots = []
    for path, original in zip([SOURCE, *PRODUCTS], frozen):
        target = out / 'source' / path.relative_to(R)
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(path.read_bytes())
        assert same(original)
        snapshots.append(dict(source=original, snapshot=b.identity(target)))
    c.save(out / 'plan.json', dict(command=command, source=frozen[0],
        current_products=frozen[1:], snapshots=snapshots,
        recipe=b.identity(recipe_path), base_link_plan=b.identity(BASE_PLAN),
        SDK_builds=0, NVCC_builds=0, host_TUs=1))
    env, _ = b.environment(command, [], out)
    c.execute('compile', command, env, out)
    deps = c.read(out / 'probe-deps.json')['Data']
    paths = list(dict.fromkeys([deps['Source'], *deps['Includes']]))
    assert all(same(item) for item in frozen), 'probe/product changed during compile'
    c.save(out / 'identity.json', dict(source=frozen[0], main=frozen[1],
        current_products=frozen[1:], object=b.identity(out / 'probe.obj'),
        command=command, recipe=b.identity(recipe_path), snapshots=snapshots,
        dependencies=[b.identity(path) for path in paths],
        SDK_builds=0, NVCC_builds=0, host_TUs=1))
    print('COMPILED probe', flush=True)


def link_probe(attempt, link_attempt):
    b, c = helpers()
    base, old_record_path, old = basis()
    record_path = S / f'compile{attempt}/probe/identity.json'
    record = c.read(record_path)
    assert all(same(item) for item in [record['source'], record['object'],
        *record['current_products'], *record['dependencies']])
    assert record['main'] == old['source']
    old_key = c.key(old['object']['path'])
    assert sum(c.key(item['path']) == old_key for item in base['inputs']) == 1
    assert sum(c.key(item) == old_key for item in base['command']) == 1
    assert all(Path(item['path']).is_file() and
               Path(item['path']).stat().st_size == item['bytes']
               for item in base['inputs']), 'retained link input path/size differs'
    inputs = [record['object'] if c.key(item['path']) == old_key else item
              for item in base['inputs']]
    assert len(inputs) == 195 and len({c.key(item['path']) for item in inputs}) == 195
    command = [record['object']['path'] if c.key(item) == old_key else item
               for item in base['command']
               if not item.upper().startswith(('/OUT:', '/MAP:', '/IMPLIB:', '/PDB:'))]
    out = S / f'probe-link{link_attempt}'
    out.mkdir(exist_ok=False)
    (out / 'tmp').mkdir()
    image = out / 'probe.exe'
    command += ['/OUT:' + str(image), '/MAP:' + str(image.with_suffix('.map')),
                '/IMPLIB:' + str(image.with_suffix('.lib'))]
    c.save(out / 'link-plan.json', dict(command=command, inputs=inputs,
        base=b.identity(BASE_PLAN), compiled_record=b.identity(record_path),
        consumer_compiled_record=b.identity(record_path),
        base_consumer_compiled_record=b.identity(old_record_path),
        consumer_recompiled=True, replaced_inputs=1, retained_inputs=194,
        retained_identity_check='Original paths and byte sizes; no full SDK rehash.',
        SDK_builds=0, NVCC_builds=0))
    env, _ = b.environment(command, [item['path'] for item in inputs], out)
    c.execute('link', command, env, out)
    runtime_path = AD / 'qwen-link1/runtime-environment.json'
    runtime = c.read(runtime_path)
    for item in runtime['staged_dlls']:
        assert same(item)
        source = Path(item['path'])
        os.link(source, out / source.name)
    runtime['previous_environment'] = b.identity(runtime_path)
    runtime['staged_dlls'] = [b.identity(path) for path in out.glob('*.dll')]
    if 'CPU_DLL' in runtime:
        name = Path(runtime['CPU_DLL']['source']['path']).name
        runtime['CPU_DLL']['destination'] = b.identity(out / name)
    c.save(out / 'runtime-environment.json', runtime)
    current = {Path(item['path']).name: item for item in record['current_products']}
    c.save(S / f'probe-ready-attempt{link_attempt}.json', dict(
        image=b.identity(image), source=record['source'], probe_source=record['source'],
        main=record['main'], current_product_main=record['main'],
        current_provider=current['cublas_provider.cc'],
        current_policy=current['default_policy.cc'],
        current_products=record['current_products'],
        compiled_record=b.identity(record_path),
        compile_receipt=b.identity(S / f'compile{attempt}/probe/compile.result.json'),
        link_receipt=b.identity(out / 'link.result.json'),
        base_link_plan=b.identity(BASE_PLAN), link_plan=b.identity(out / 'link-plan.json'),
        runtime_environment=b.identity(out / 'runtime-environment.json'),
        consumer_recompiled=True, replaced_inputs=1, retained_inputs=194,
        SDK_builds=0, NVCC_builds=0, throughput_evidence=False))
    print('READY probe', flush=True)


def run_probe(link_attempt):
    b, c = helpers()
    ready_path = S / f'probe-ready-attempt{link_attempt}.json'
    ready = c.read(ready_path)
    assert all(same(ready[key]) for key in
               ('image', 'source', 'main', 'runtime_environment', 'link_plan'))
    assert all(same(item) for item in ready['current_products'])
    out = S / 'probe1'
    out.mkdir(exist_ok=False)
    inputs = V / 'inputs/mtp'
    command = [ready['image']['path'], '--inputs', str(inputs),
               '--output', str(out / 'vectors')]
    c.save(out / 'plan.json', dict(command=command, ready=ready,
        ready_record=b.identity(ready_path), prompt=b.identity(inputs / 'prompt.ids'),
        diagnostic=True, throughput_evidence=False,
        scope='One actual finite current-policy probe; no retry or extra model process.'))
    env = os.environ.copy()
    env['PATH'] = c.read(ready['runtime_environment']['path'])['PATH']
    c.execute('run', command, env, out)
    c.save(out / 'actual-run.json', dict(terminal=b.identity(out / 'run.result.json'),
        stdout=b.identity(out / 'run.stdout.log'), stderr=b.identity(out / 'run.stderr.log'),
        ready_record=b.identity(ready_path), output=str(out / 'vectors'),
        model_processes=1, throughput_evidence=False))
    print('PROBE_COMPLETE', flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action', choices=('compile', 'link', 'run'))
    parser.add_argument('--attempt', type=int, default=1)
    parser.add_argument('--link-attempt', type=int)
    args = parser.parse_args()
    if args.attempt < 1 or (args.link_attempt is not None and args.link_attempt < 1):
        parser.error('attempt numbers must be positive')
    if args.action == 'compile':
        compile_probe(args.attempt)
    elif args.action == 'link':
        link_probe(args.attempt, args.link_attempt or args.attempt)
    else:
        run_probe(args.link_attempt or args.attempt)
