# Exact AF leaves only. No recursion. Review plan, then run once.
$ErrorActionPreference = 'Stop'
$taskRoot = 'C:\public\project-hyle\hyle\.scratch\qwen-mtp-steady-profile-20261022'
$resultFile = Join-Path $taskRoot 'cleanup-result.json'
$publicFile = 'C:\public\project-hyle\hyle\docs\evidence\performance\qwen-mtp-steady-profile-cleanup-2026-10-22.json'
if ((Test-Path -LiteralPath $resultFile) -or (Test-Path -LiteralPath $publicFile)) { throw 'Existing cleanup result; do not rerun.' }
$plan = Get-Content -LiteralPath (Join-Path $taskRoot 'cleanup-plan.json') -Raw | ConvertFrom-Json
$batch = [IO.Path]::GetFullPath($plan.batch_scope).TrimEnd('\')
if ($batch -cne $taskRoot) { throw 'Unexpected cleanup scope' }
$prefix = $batch + '\'
function Confirm-Identity($record) {
 $item = Get-Item -LiteralPath $record.path -Force -ErrorAction Stop
 if ($item.PSIsContainer -or ($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -or $item.Length -ne $record.bytes) { throw ('File identity differs: ' + $record.path) }
 if ((Get-FileHash -LiteralPath $record.path -Algorithm SHA256).Hash.ToLowerInvariant() -cne $record.sha256) { throw ('File hash differs: ' + $record.path) }
}
$allowed = [Collections.Generic.HashSet[string]]::new([StringComparer]::OrdinalIgnoreCase)
foreach ($folder in @('qwen-link1','tests-link1')) {
 $name = if ($folder -ceq 'qwen-link1') { 'qwen' } else { 'tests' }
 foreach ($suffix in @('.exe','.map','.lib','.exp')) { [void]$allowed.Add((Join-Path $taskRoot ('candidate\' + $folder + '\' + $name + $suffix))) }
}
foreach ($name in @('capture.sqlite','capture.nsys-rep')) { [void]$allowed.Add((Join-Path $taskRoot ('execution\attempt1\' + $name))) }
$seen = [Collections.Generic.HashSet[string]]::new([StringComparer]::OrdinalIgnoreCase)
foreach ($target in $plan.targets) {
 $absolute = [IO.Path]::GetFullPath($target.path)
 $tmp = $target.kind -ceq 'rebuildable-tmp' -and [IO.Path]::GetExtension($absolute) -ceq '.tmp'
 if (-not $absolute.StartsWith($prefix,[StringComparison]::OrdinalIgnoreCase) -or (-not $allowed.Contains($absolute) -and -not $tmp) -or -not $seen.Add($absolute)) { throw ('Unsafe cleanup target: ' + $absolute) }
 $parent = [IO.Path]::GetDirectoryName($absolute)
 while ($parent.Length -ge $batch.Length) {
  if (Test-Path -LiteralPath $parent) {
   $entry = Get-Item -LiteralPath $parent -Force
   if (-not $entry.PSIsContainer -or ($entry.Attributes -band [IO.FileAttributes]::ReparsePoint)) { throw ('Unsafe parent: ' + $parent) }
  }
  if ($parent -ceq $batch) { break }
  $parent = [IO.Path]::GetDirectoryName($parent)
 }
}
Confirm-Identity $plan.script
Confirm-Identity $plan.script_copy
Confirm-Identity $plan.published.manifest
foreach ($archive in $plan.published.archives) { Confirm-Identity $archive }
foreach ($record in $plan.keep_images) { Confirm-Identity $record }
$results = [Collections.Generic.List[object]]::new()
$removedBytes = [int64]0
$removedCount = 0
$absentCount = 0
$failure = $null
try {
 foreach ($target in $plan.targets) {
  if (-not (Test-Path -LiteralPath $target.path)) {
   $absentCount++
   $results.Add([ordered]@{path=$target.path;kind=$target.kind;status='absent-not-deleted'})
   continue
  }
  if ($target.planned_status -cne 'present') { throw ('Previously absent leaf appeared; not authorized for deletion: ' + $target.path) }
  # Verify this exact leaf immediately before its single non-recursive removal.
  Confirm-Identity $target
  Remove-Item -LiteralPath $target.path -Force -ErrorAction Stop
  if (Test-Path -LiteralPath $target.path) { throw ('Leaf still exists: ' + $target.path) }
  $removedCount++
  $removedBytes += [int64]$target.bytes
  $results.Add([ordered]@{path=$target.path;kind=$target.kind;status='removed';bytes=$target.bytes;sha256=$target.sha256;preservation=$target.preservation})
 }
} catch { $failure = $_.Exception.Message }
$status = if ($failure) { 'failed; inspect individual results' } elseif ($absentCount) { 'completed-with-absent-not-deleted; do not rerun' } else { 'completed; do not rerun' }
$result = [ordered]@{status=$status;recursive=$false;failure=$failure;removed_files=$removedCount;removed_logical_bytes=$removedBytes;absent_not_deleted=$absentCount;planned_files=$plan.count;script=$plan.script;script_copy=$plan.script_copy;verified_manifest=$plan.published.manifest;verified_archives=$plan.published.archives;archive_verification=$plan.archive_verification;kept_images=$plan.keep_images;canonical_sqlite=$plan.canonical_sqlite;transformed_report_limitation=$plan.transformed_report_limitation;results=$results}
$result | ConvertTo-Json -Depth 18 | Set-Content -LiteralPath $resultFile -Encoding utf8
if (Test-Path -LiteralPath $publicFile) { throw 'Public cleanup record appeared; refusing overwrite' }
Copy-Item -LiteralPath $resultFile -Destination $publicFile -ErrorAction Stop
if ($failure) { throw $failure }
Write-Output ('Removed ' + $removedCount + ' exact leaves / ' + $removedBytes + ' logical bytes; absent-not-deleted=' + $absentCount)
