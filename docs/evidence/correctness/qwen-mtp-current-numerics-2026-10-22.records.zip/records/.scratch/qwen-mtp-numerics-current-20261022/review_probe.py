"""Host-only finite review of existing current F32 same-head controls."""
from pathlib import Path
from collections import defaultdict
import hashlib,json,math,re
import numpy as np

S=Path(__file__).resolve().parent
P=S/'probe1/vectors'
cache={};payloads={}
def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def raw(p):
    p=Path(p);key=str(p)
    if key not in cache:
        cache[key]=p.read_bytes();payloads[key]=dict(path=key,bytes=len(cache[key]),sha256=hashlib.sha256(cache[key]).hexdigest())
    return cache[key]
def scalar(b,bf16):
    return (np.frombuffer(b,dtype='<u2').astype(np.uint32)<<16).view(np.float32) if bf16 else np.frombuffer(b,dtype='<f4')
def metric(a,b,bf16):
    assert len(a)==len(b)
    x=scalar(a,bf16).astype(np.float64);y=scalar(b,bf16).astype(np.float64)
    error=float(np.sum((x-y)**2));reference=float(np.sum(x*x))
    return dict(bytes=len(a),elements=int(x.size),byte_equal=a==b,changed_elements=int(np.count_nonzero(x!=y)),
        nonfinite_reference=int(np.count_nonzero(~np.isfinite(x))),nonfinite_actual=int(np.count_nonzero(~np.isfinite(y))),
        max_abs=float(np.max(np.abs(x-y))) if x.size else 0.0,squared_error=error,reference_squared=reference,
        relative_L2=math.sqrt(error/reference) if reference else (0.0 if error==0 else None))
def category(name):
    if name.endswith('.conv.bf16'):return 'target_conv18'
    if name.endswith('.gdn.f32'):return 'target_GDN18'
    if name.startswith('target'):return 'target_KV12'
    if name.startswith('draft.'):return 'draft_KV2'
    if name=='carry.bf16':return 'carry1'
    if name=='prior.bf16':return 'prior1'
    return 'target_row0_outputs2'
def scores(b):
    x=scalar(b,False).reshape(-1,248320);result=[]
    for row in x:
        order=np.argsort(row,kind='stable')[-2:][::-1]
        result.append(dict(argmax=int(np.argmax(row)),top2=[dict(id=int(k),value=float(row[k])) for k in order],
            score11=float(row[11]),score271=float(row[271]),margin271_minus11=float(row[271]-row[11])))
    return result
def identity(p):
    p=Path(p);b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())

def main():
    observation=read(P/'observation.json');images={x['label']:x for x in observation['images']}
    assert observation['status']=='CURRENT_F32_SAME_HEAD_CONTROL_COMPLETE' and observation['error']==''
    expected=dict(capacity=1024,resident_limit=6,active_sequences=1,actual_graph_calls=33,image_count=6,
        seed_full52_unchanged_checks=2,control_full52_unchanged_checks=4,final_live_snapshot_versions=0)
    assert all(observation[k]==v for k,v in expected.items())
    assert observation['managed_backing_bytes']==observation['planned_backing_bytes']==244670515
    assert read(S/'probe1/run.result.json')['exit']==0
    vectors={};finite_checks=0
    for label,image in images.items():
        assert len(image['vectors'])==54
        vectors[label]={v['name']:v for v in image['vectors']}
        for v in image['vectors']:
            b=raw(v['path']);assert len(b)==v['bytes'];assert bool(np.all(np.isfinite(scalar(b,v['dtype']=='BF16'))))
            finite_checks+=1
    recalculated=[]
    for m in observation['vectors']:
        result=metric(raw(m['baseline']),raw(m['actual']),m['dtype']=='BF16')
        assert result['byte_equal']==m['byte_equal'] and result['nonfinite_reference']==m['nonfinite_baseline'] and result['nonfinite_actual']==m['nonfinite_actual']
        for k in ('max_abs','squared_error','reference_squared'):assert math.isclose(result[k],m[k],rel_tol=1e-10,abs_tol=1e-12),(m['name'],k)
        recalculated.append(dict(name=m['name'],category=category(m['name'].split('/')[-1]),**result))
    assert len(recalculated)==108
    points={}
    for point in ('P154','L171'):
        selected=[x for x in recalculated if x['name'].startswith(point+'_')]
        groups=defaultdict(list)
        for row in selected:groups[row['category']].append(row)
        summaries={k:dict(vectors=len(v),byte_equal=sum(x['byte_equal'] for x in v),different=sum(not x['byte_equal'] for x in v),
            max_abs=max(x['max_abs'] for x in v),max_relative_L2=max((x['relative_L2'] for x in v if x['relative_L2'] is not None),default=None)) for k,v in groups.items()}
        assert {k:v['vectors'] for k,v in summaries.items()}==dict(target_conv18=18,target_GDN18=18,target_KV12=12,draft_KV2=2,carry1=1,prior1=1,target_row0_outputs2=2)
        a=raw(vectors[point+'_T1']['layer0.conv.bf16']['path']);b=raw(vectors[point+'_T2']['layer0.conv.bf16']['path'])
        assert len(a)==len(b)==3*6144*2
        conv_rows=[metric(a[i*12288:(i+1)*12288],b[i*12288:(i+1)*12288],True) for i in range(3)]
        first_difference=np.flatnonzero(np.frombuffer(a,dtype='<u2')!=np.frombuffer(b,dtype='<u2'))
        head=image=images[point+'_T1']['metadata'];other=images[point+'_T2']['metadata']
        assert head['length']==other['length'] and head['draft_frontier']==other['draft_frontier'] and head['lag']==other['lag']==0
        points[point]=dict(control=next(c for c in observation['controls'] if c.get('name')==point),
            selected_T1_metadata=head,selected_T2_metadata=other,categories=summaries,
            row0_output_metrics=[x for x in selected if x['category']=='target_row0_outputs2'],
            per_layer_state_metrics=[x for x in selected if x['category'] in ('target_conv18','target_GDN18')],
            first_layer_conv_history=dict(shape=[3,6144],row_metrics=conv_rows,
                first_changed_element=int(first_difference[0]) if first_difference.size else None,
                changed_indices_all_within_last6144=bool(np.all(first_difference>=12288)),
                first_two_inherited_rows_byte_equal=a[:24576]==b[:24576]),
            T1_scores=scores(raw(vectors[point+'_T1']['output.logits.f32']['path'])),
            T2_scores=scores(raw(vectors[point+'_T2']['output.logits.f32']['path'])))
    links=[]
    def compare_trace(label,probe_image,control,phase,first_row=False):
        for filename,name in [('hidden.bf16','output.hidden.bf16'),('logits.f32','output.logits.f32')]:
            a=raw(vectors[probe_image][name]['path']);b=raw(S/'controls1'/control/'trace'/phase/filename)
            if first_row:
                width=4096 if filename.startswith('hidden') else 993280
                a=a[:width];b=b[:width]
            links.append(dict(label=label,vector=name,probe_image=probe_image,CLI_control=control,CLI_phase=phase,first_row_only=first_row,**metric(a,b,filename.startswith('hidden'))))
    compare_trace('allSingle20_matches_plain20_final','all_single20_final','plain20','decode19')
    compare_trace('P154_T1_matches_plain_first_decode','P154_T1','plain20','decode1')
    for name in ('plain20','mtp19','mtp20'):compare_trace('same_P154_prefill','P154_prefill',name,'prefill')
    for control,probe_image in [('mtp19','L171_T1'),('mtp20','L171_T2')]:
        parsed=read(S/'controls1'/control/'parsed.json')
        index=next(i for i,row in enumerate(parsed['rounds']) if row['pending']==11906)
        phase='mtp'+str(index+1)
        compare_trace('L171_corresponding_pending11906',probe_image,control,phase)
        if control=='mtp20':
            compare_trace('L171_T1_vs_T2_CLI_row0','L171_T1',control,phase,True)
    all_single=next(x for x in observation['controls'] if x['kind']=='all_single20')
    ordinary=read(S/'controls1/plain20/parsed.json')
    assert all_single['generated_ids']==ordinary['generated_ids']
    assert all(x['byte_equal'] for x in links if x['label'] in ('allSingle20_matches_plain20_final','P154_T1_matches_plain_first_decode','same_P154_prefill'))
    for point,value in points.items():
        c=value['control'];assert value['T1_scores'][0]['argmax']==c['T1_target_first']
        assert [r['argmax'] for r in value['T2_scores']]==[c['T2_target_first'],c['T2_target_second']]
        assert c['same_old_snapshot_pointer'] and c['old_full52_unchanged'] and not c['accepted_draft'] and c['quota']==1
    outdir=S/'review';payload_file=outdir/'probe-payload-index.json'
    payload_file.write_text(json.dumps(dict(unique_files=len(payloads),files=list(payloads.values())),indent=2)+'\n',encoding='utf-8')
    report=dict(status='FROZEN_HOST_ONLY_CURRENT_F32_PROBE_ANALYSIS',
        execution=dict(**expected,model_objects=1,weight_tensors=335,peak_live_versions=observation['peak_live_snapshot_versions'],
            managed_backing_bytes=observation['managed_backing_bytes'],planned_backing_bytes=observation['planned_backing_bytes']),
        verification=dict(native_exit0=True,all_image_vectors_finite=True,image_vector_checks=finite_checks,raw_metrics_recomputed=108,
            own_argmax_matches_recorded_target_IDs=True,allSingle20_IDs_equal_plain20=True,
            allSingle_final_hidden_logits_byte_equal_plain_decode19=True,P154_T1_hidden_logits_byte_equal_plain_decode1=True,
            full52_source_unchanged_checks='2seed+4control actual runtime assertions; source pointers checked in the executed probe, not reconstructed from separate CLI traces'),
        same_head_points=points,CLI_payload_links=links,all_single20=all_single,
        finite_payload_index=identity(payload_file),
        interpretation=['The same P154 Snapshot yields non-byte-identical T1/T2 row0 hidden/F32scores while both argmax12305. At the same L171 Snapshot both predict11 despite fresh T2 draft271; report exact measured errors without a quality threshold.',
            'allSingle20 reproduces ordinary20 IDs and final hidden/logits bytes; it does not inherit the natural T2 trajectory merely because the consumed token history agrees.',
            'First-layer conv history is split into three6144-element rows explicitly. Differences in the new projected row versus inherited rows are measured, not assumed to be legal native rounding or a GDN defect.',
            'The two selected heads use identical L+1/draft-frontier boundaries under diagnostic quota1. The T2 Graph/proposal executes naturally; quota1 only declines the bonus.',
            'CLI MTP20 has an additional later Single after the pending11906 round. L171 comparisons use its corresponding mtp10 payload, not the literal final mtp11.',
            'No independent per-operator mathematical oracle, complete model quality error budget, new performance window or numerical tolerance acceptance is supplied.'],
        source=[identity(P/'observation.json'),identity(S/'probe1/run.result.json'),identity(S/'probe-ready-attempt1.json'),identity(S/'source/current_probe.cc'),identity(Path(__file__))],
        new_native_processes=0,GPU_runs=0,builds=0,product_edits=0)
    output=outdir/'actual-probe-analysis.json';output.write_text(json.dumps(report,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf-8')
    print(json.dumps(dict(report=identity(output),finite_checks=finite_checks,points={p:dict(categories=v['categories'],conv_rows=[dict(byte_equal=r['byte_equal'],changed=r['changed_elements'],max_abs=r['max_abs'],relative_L2=r['relative_L2']) for r in v['first_layer_conv_history']['row_metrics']],row0=v['row0_output_metrics']) for p,v in points.items()},CLI_links=[dict(label=x['label'],vector=x['vector'],byte_equal=x['byte_equal'],relative_L2=x['relative_L2']) for x in links]),ensure_ascii=False))


if __name__=='__main__':main()
