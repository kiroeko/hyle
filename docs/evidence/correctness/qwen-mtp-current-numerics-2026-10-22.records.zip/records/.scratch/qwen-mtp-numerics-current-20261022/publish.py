"""Root-only publication of AG's four finite current-policy model processes.

Import is inert. This script never builds, starts a model or calls a GPU API.
Run only after the actual probe analysis and the final two docs are frozen.
"""
from pathlib import Path
import argparse
import difflib
import hashlib
import json
import zipfile

S = Path(__file__).resolve().parent
R = S.parents[1]
AD = R / '.scratch/qwen-cublas-scores-20261022'
O = R / 'docs/evidence/correctness'
NAME = 'qwen-mtp-current-numerics-2026-10-22'
EXCLUDED_SUFFIXES = {'.exe', '.map', '.lib', '.exp', '.obj', '.dll', '.pdb',
                     '.pyc', '.tmp', '.zip', '.safetensors', '.gguf', '.nsys-rep'}
EXCLUDED_PARTS = {'tmp', 'cache', '__pycache__', 'publication-tmp'}


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def save(path, value):
    Path(path).write_text(json.dumps(value, ensure_ascii=False, indent=2,
                                    allow_nan=False) + '\n', encoding='utf-8')


def resolve(path):
    path = Path(path)
    return path.resolve() if path.is_absolute() else (R / path).resolve()


def identity(path):
    path = resolve(path)
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(8 << 20), b''):
            digest.update(block)
    return dict(path=str(path), bytes=path.stat().st_size, sha256=digest.hexdigest())


def verify(item):
    actual = identity(item['path'])
    assert (actual['bytes'], actual['sha256']) == (item['bytes'], item['sha256']), item['path']
    return actual


def successful(path):
    value = read(path)
    assert value['exit'] == 0, str(path)
    if 'terminal' in value:
        assert value['terminal'], str(path)
    return identity(path)


def validate(final_review):
    current = read(AD / 'qwen-ready-attempt1.json')
    for field in ('image', 'main', 'source', 'link_plan', 'runtime_environment'):
        verify(current[field])
    for item in current['changed_sources']:
        verify(item)
    controls = []
    for name in ('mtp19', 'mtp20', 'plain20'):
        folder = S / 'controls1' / name
        plan = read(folder / 'plan.json')
        assert plan['ready']['image'] == current['image']
        assert plan['ready']['main'] == current['main']
        assert not plan['throughput_evidence']
        assert read(folder / 'run.result.json')['command'] == plan['command']
        controls.append(dict(name=name, plan=identity(folder / 'plan.json'),
                             receipt=successful(folder / 'run.result.json')))
    summary = read(S / 'controls1/summary.json')
    assert summary['model_processes'] == 3 and not summary['throughput_evidence']
    assert {row['name'] for row in summary['controls']} == {'mtp19', 'mtp20', 'plain20'}
    probe = read(S / 'probe-ready-attempt1.json')
    for field in ('image', 'source', 'main', 'compiled_record', 'link_plan', 'runtime_environment'):
        verify(probe[field])
    for item in probe['current_products']:
        verify(item)
    assert probe['main'] == current['main']
    assert probe['current_provider'] in current['changed_sources']
    assert probe['current_policy'] in current['changed_sources']
    assert probe['replaced_inputs'] == 1 and probe['retained_inputs'] == 194
    assert probe['SDK_builds'] == 0 and probe['NVCC_builds'] == 0
    assert not probe['throughput_evidence']
    compile_receipt = successful(S / 'compile1/probe/compile.result.json')
    link_receipt = successful(S / 'probe-link1/link.result.json')
    verify(probe['compile_receipt']); verify(probe['link_receipt'])
    assert probe['compile_receipt']['sha256'] == compile_receipt['sha256']
    assert probe['link_receipt']['sha256'] == link_receipt['sha256']
    compiled = read(probe['compiled_record']['path'])
    verify(compiled['source']); verify(compiled['object'])
    assert compiled['source'] == probe['source'] and compiled['main'] == current['main']
    assert compiled['host_TUs'] == 1 and compiled['SDK_builds'] == compiled['NVCC_builds'] == 0
    assert all(flag in compiled['command'] for flag in ('/O2', '/MD', '/W4', '/WX'))
    base = read(current['link_plan']['path'])
    linked = read(probe['link_plan']['path'])
    verify(linked['base'])
    assert linked['base'] == current['link_plan']
    assert len(base['inputs']) == len(linked['inputs']) == 195
    assert linked['replaced_inputs'] == 1 and linked['retained_inputs'] == 194
    # Compare the recorded closure, without opening or copying retained SDK files.
    key = lambda item: str(resolve(item['path'])).casefold()
    old = {key(item): item for item in base['inputs']}
    new = {key(item): item for item in linked['inputs']}
    assert len(old) == len(new) == 195
    retained = set(old) & set(new)
    assert len(retained) == 194 and all(old[k] == new[k] for k in retained)
    assert list(new[k] for k in set(new) - retained) == [compiled['object']]
    original_consumer = read(linked['base_consumer_compiled_record']['path'])
    assert list(old[k] for k in set(old) - retained) == [original_consumer['object']]
    assert original_consumer['source'] == current['main']
    plan = read(S / 'probe1/plan.json')
    assert plan['ready']['image'] == probe['image'] and not plan['throughput_evidence']
    assert read(S / 'probe1/run.result.json')['command'] == plan['command']
    run_receipt = successful(S / 'probe1/run.result.json')
    final = read(final_review)
    # The root's terminal report is identity-bound; do not couple its probe schema.
    status = str(final.get('status', '')).lower()
    assert status and not any(word in status for word in ('pending', 'awaiting', 'draft', 'not_run', 'plan_only'))
    assert resolve(final_review).is_relative_to(S)
    return dict(current=current, probe=probe, controls=controls,
                controls_summary=identity(S / 'controls1/summary.json'),
                compile_receipt=compile_receipt, link_receipt=link_receipt,
                probe_receipt=run_receipt, actual_review=identity(final_review))


def docs_snapshot():
    docs = []
    for relative, name in (('docs/developer/current-work.md', 'current-work.md'),
                           ('docs/developer/performance/decode.md', 'decode.md')):
        original = R / relative
        target = S / 'current' / relative
        before = S / 'before' / name
        old = identity(before)
        actual = identity(original)
        payload = original.read_bytes()
        target.parent.mkdir(parents=True, exist_ok=True)
        if target.exists():
            assert target.read_bytes() == payload, 'preserve prior final-doc snapshot'
        else:
            target.write_bytes(payload)
        verify(actual)
        diff = S / 'current' / (name + '.diff')
        diff.write_text(''.join(difflib.unified_diff(before.read_text(encoding='utf-8-sig').splitlines(True),
            payload.decode('utf-8-sig').splitlines(True), fromfile='before/' + name, tofile=relative)), encoding='utf-8')
        docs.append(dict(current=actual, snapshot=identity(target), before=old, diff=identity(diff)))
    save(S / 'docs-freeze.json', dict(files=docs))
    return docs


def include(path):
    relative = path.relative_to(S)
    return (path.is_file() and path.suffix.lower() not in EXCLUDED_SUFFIXES
            and path.name not in ('published.json', 'postconditions.json')
            and not path.name.lower().startswith('cleanup')
            and not any(part.lower() in EXCLUDED_PARTS for part in relative.parts))


def publish(final_review):
    output = O / (NAME + '.json')
    archive = O / (NAME + '.data.zip')
    assert not output.exists() and not archive.exists(), 'never overwrite published evidence'
    checked = validate(final_review)
    docs = docs_snapshot()
    summary = dict(
        status='Finite current-policy target numerical diagnosis complete; broader goal remains active',
        date='2026-10-22', product_code_changed=False, product_promotion=False,
        actual_model_processes=4, model_ledger=dict(current_image_controls=3, same_state_probe=1),
        host_CXX_processes=1, link_processes=1, SDK_builds=0, NVCC_builds=0,
        build_scope='One scratch probe consumer object replaces original main; 194 of195 link inputs retained.',
        controls=checked['controls'], controls_summary=checked['controls_summary'],
        compile_receipt=checked['compile_receipt'], link_receipt=checked['link_receipt'],
        probe_receipt=checked['probe_receipt'], final_actual_analysis=checked['actual_review'],
        current_AD_ready=identity(AD / 'qwen-ready-attempt1.json'),
        current_AD_image=checked['current']['image'], current_main=checked['current']['main'],
        current_products=checked['probe']['current_products'],
        probe_ready=identity(S / 'probe-ready-attempt1.json'), probe_image=checked['probe']['image'],
        docs_freeze=identity(S / 'docs-freeze.json'),
        throughput_evidence=False, quality_pass=False, numerical_quality_threshold=None,
        limitations=[
            'Four finite diagnostic model processes, not a throughput window or general acceptance/quality result.',
            'Equal emitted prefixes alone do not prove equal complete KV/recurrent/carry state; use the terminal actual probe report for its precise same-state and selected-row scope.',
            'Changed-input speculative/rejected rows are not treated as equal-input mathematical controls. No altered proposal, sampler, dtype or product implementation is promoted.',
            'Original raw boundary tensors are retained with exact source identities and archive entries; byte-identical files may share one payload entry.',
            'No SDK, models, build objects or executable payloads are copied into the archive. Their identities and actual commands remain in receipts.'
        ], previous_evidence=['docs/evidence/performance/qwen-mtp-steady-profile-2026-10-22.json'])
    save(S / 'actual-summary.json', summary)
    files = sorted((p for p in S.rglob('*') if include(p)), key=lambda p: p.relative_to(S).as_posix())
    assert all(p.resolve().is_relative_to(S) for p in files), 'external SDK/model link forbidden'
    assert resolve(final_review) in files
    assert any(p.suffix.lower() == '.bf16' for p in files)
    assert any(p.suffix.lower() == '.f32' for p in files)
    assert any(p.is_relative_to(S / 'probe1') and p.suffix.lower() in ('.bf16', '.f32') for p in files)
    temporary = S / 'publication-tmp'
    temporary.mkdir(exist_ok=True)
    staged = temporary / (NAME + '.data.zip.tmp')
    assert not staged.exists(), 'preserve prior incomplete archive for root inspection'
    entries, unique = [], {}
    with zipfile.ZipFile(staged, 'x', zipfile.ZIP_DEFLATED, compresslevel=6) as z:
        for path in files:
            item = identity(path)
            digest_key = item['bytes'], item['sha256']
            entry = unique.get(digest_key)
            if entry is None:
                entry = path.relative_to(R).as_posix()
                unique[digest_key] = entry
                z.write(path, entry)
            else:
                item['identical_content_alias'] = True
            item['entry'] = entry
            entries.append(item)
    with zipfile.ZipFile(staged) as z:
        assert z.testzip() is None
        for (size, digest), entry in unique.items():
            actual = hashlib.sha256()
            length = 0
            with z.open(entry) as stream:
                for block in iter(lambda: stream.read(8 << 20), b''):
                    actual.update(block)
                    length += len(block)
            assert length == size and actual.hexdigest() == digest
    for item in entries:
        verify(item)
    for item in docs:
        verify(item['current'])
    O.mkdir(parents=True, exist_ok=True)
    staged.rename(archive)
    save(output, dict(**summary, archives=[identity(archive)], archive_files=entries,
                      archive_verified=dict(CRC=True, all_unique_entry_SHA256=True,
                          exact_source_identity_for_every_payload=True,
                          source_files=len(entries), unique_payloads=len(unique))))
    result = dict(manifest=identity(output), archives=[identity(archive)])
    save(S / 'published.json', result)
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--actual-review', type=Path,
                        default=S / 'review/actual-probe-analysis.json')
    args = parser.parse_args()
    publish(args.actual_review.resolve())
