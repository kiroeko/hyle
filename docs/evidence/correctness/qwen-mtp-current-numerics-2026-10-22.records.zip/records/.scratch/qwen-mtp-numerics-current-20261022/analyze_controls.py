"""Host-only aligned committed-row observations; no quality threshold."""
from pathlib import Path
import hashlib
import json
import numpy as np

S = Path(__file__).resolve().parent
C = S / 'controls1'


def read(p):
    return json.loads(p.read_text(encoding='utf-8'))


def vector(p, bf16=False):
    if bf16:
        return (np.fromfile(p, dtype='<u2').astype(np.uint32) << 16).view(np.float32)
    return np.fromfile(p, dtype='<f4')


def metrics(a, b):
    assert a.shape == b.shape
    finite = np.isfinite(a) & np.isfinite(b)
    x, y = a[finite].astype(np.float64), b[finite].astype(np.float64)
    norm = float(x @ x)
    e = y-x
    return dict(elements=a.size, nonfinite_left=int(np.count_nonzero(~np.isfinite(a))),
                nonfinite_right=int(np.count_nonzero(~np.isfinite(b))),
                float_values_equal=bool(np.array_equal(a, b)),
                max_abs=float(np.max(np.abs(e))), relative_L2=float(np.sqrt((e @ e)/norm)) if norm else None)


def main():
    parsed = {name: read(C/name/'parsed.json') for name in ('mtp19', 'mtp20', 'plain20')}
    prefills = {}
    for name in ('mtp19', 'mtp20'):
        prefills[name] = {file: (C/name/'trace/prefill'/file).read_bytes() == (C/'plain20/trace/prefill'/file).read_bytes()
                          for file in ('hidden.bf16', 'logits.f32')}
    assert all(all(x.values()) for x in prefills.values())
    comparisons = []
    for name in ('mtp19', 'mtp20'):
        output_index = 1
        for i, record in enumerate(parsed[name]['rounds'], 1):
            for row in range(record['committed_target_rows']):
                assert output_index < len(parsed['plain20']['generated_ids'])
                # Compare only before the first actual input token difference.
                same_input_prefix = parsed[name]['generated_ids'][:output_index] == parsed['plain20']['generated_ids'][:output_index]
                item = dict(control=name, round=i, row=row, generated_output_index=output_index,
                            same_logical_target_input_prefix=same_input_prefix,
                            plain_id=parsed['plain20']['generated_ids'][output_index],
                            actual_id=parsed[name]['generated_ids'][output_index])
                for file, width, bf16 in [('hidden.bf16', 2048, True), ('logits.f32', 248320, False)]:
                    left = vector(C/'plain20/trace'/f'decode{output_index}'/file, bf16)
                    right = vector(C/name/'trace'/f'mtp{i}'/file, bf16).reshape(-1,width)[row]
                    item[file] = metrics(left, right)
                    if not bf16:
                        item['top1_from_raw'] = [int(left.argmax()), int(right.argmax())]
                        item['scores_11_271'] = dict(plain=[float(left[t]) for t in (11,271)], actual=[float(right[t]) for t in (11,271)])
                comparisons.append(item)
                output_index += 1
    last = {}
    for name in ('mtp19','mtp20'):
        data = vector(C/name/'trace/mtp10/logits.f32').reshape(-1,248320)[0]
        last[name] = dict(rows=(C/name/'trace/mtp10/logits.f32').stat().st_size//(248320*4),
                          top1=int(data.argmax()), scores_11_271=[float(data[t]) for t in (11,271)])
    report = dict(status='COMPLETE_HOST_ONLY_CURRENT_THREE_CONTROL_ANALYSIS',
                  prefill_hidden_and_logits_exact=prefills, model_processes=3, build_processes=0,
                  final_round=last, aligned_committed_rows=comparisons,
                  within_MTP_first_nine_round_decisions_equal=parsed['mtp19']['rounds'][:9] == parsed['mtp20']['rounds'][:9],
                  conclusions=['The final quota-selected T1 and T2 both choose11; final shape alone does not reproduce plain271.',
                               'All three published prefill hidden/logits are byte-identical. This does not yet assert all KV/recurrent state bytes are equal.',
                               'Committed-row comparisons retain BF16 hidden and F32 score differences; natural IDs alone are not a state equality test.'],
                  quality_threshold=None, quality_pass=False, throughput_evidence=False)
    out=S/'review/three-control-analysis.json';out.parent.mkdir(exist_ok=True)
    out.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(dict(report=str(out), compared_committed_rows=len(comparisons),
        first_comparison=comparisons[0], final_round=last),ensure_ascii=False))


if __name__=='__main__':
    main()
