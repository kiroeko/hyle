"""Read existing controls1 only; no model, native call, build or quality gate."""
from pathlib import Path
import hashlib
import json
import numpy as np

S = Path(__file__).resolve().parents[1]
C = S / 'controls1'


def read(p):
    return json.loads(p.read_text(encoding='utf-8-sig'))


def identity(p):
    b = p.read_bytes()
    return dict(path=str(p), bytes=len(b), sha256=hashlib.sha256(b).hexdigest())


def metrics(a, b):
    assert a.shape == b.shape and np.isfinite(a).all() and np.isfinite(b).all()
    x, y = a.astype(np.float64), b.astype(np.float64)
    delta = y - x
    return dict(elements=a.size, finite=True, max_abs=float(np.abs(delta).max()),
                relative_L2=float(np.linalg.norm(delta) / np.linalg.norm(x)))


def rows(p, bf16):
    b = p.read_bytes()
    width = 2048 if bf16 else 248320
    values = ((np.frombuffer(b, dtype='<u2').astype(np.uint32) << 16).view(np.float32)
              if bf16 else np.frombuffer(b, dtype='<f4'))
    assert values.size % width == 0 and np.isfinite(values).all()
    return values.reshape(-1, width), b


def main():
    names = ('mtp19', 'mtp20', 'plain20')
    data, receipts, plans = {}, {}, {}
    primary = read(S / 'review/three-control-analysis.json')
    for name in names:
        folder = C / name
        data[name] = read(folder / 'parsed.json')
        assert data[name] == read(folder / 'run.stdout.log')
        receipts[name] = read(folder / 'run.result.json')
        plans[name] = read(folder / 'plan.json')
        assert receipts[name]['terminal'] and receipts[name]['exit'] == 0
        assert receipts[name]['command'] == plans[name]['command']
        assert not plans[name]['throughput_evidence']
        assert data[name]['score_policy'] == 'bf16_inputs_f32_output'
    assert len({plans[n]['ready']['image']['sha256'] for n in names}) == 1
    assert len({plans[n]['ready']['main']['sha256'] for n in names}) == 1
    assert len({plans[n]['prompt']['sha256'] for n in names}) == 1
    assert [len(data[n]['generated_ids']) for n in names] == [19, 20, 20]
    assert data['mtp19']['rounds'][:9] == data['mtp20']['rounds'][:9]
    prefill = {}
    for name in ('mtp19', 'mtp20'):
        prefill[name] = {f: (C / name / 'trace/prefill' / f).read_bytes() ==
                        (C / 'plain20/trace/prefill' / f).read_bytes()
                        for f in ('hidden.bf16', 'logits.f32')}
        assert all(prefill[name].values())
    plain_ids = data['plain20']['generated_ids']
    selected, excluded, counts = [], [], {}
    raw_checks = 0
    for name in ('mtp19', 'mtp20'):
        next_output = 1
        same = 0
        for round_index, record in enumerate(data[name]['rounds'], 1):
            assert record['pending'] == data[name]['generated_ids'][next_output - 1]
            committed = record['committed_target_rows']
            assert committed in (1, 2)
            expected = [record['target_first']]
            if committed == 2:
                assert record['accepted_draft'] and record['draft'] == record['target_first']
                expected.append(record['target_second'])
            assert data[name]['generated_ids'][next_output:next_output + committed] == expected
            loaded = {f: rows(C / name / 'trace' / f'mtp{round_index}' / f, bf)
                      for f, bf in [('hidden.bf16', True), ('logits.f32', False)]}
            for row in range(committed):
                index = next_output + row
                equal_prefix = data[name]['generated_ids'][:index] == plain_ids[:index]
                result = dict(control=name, round=round_index, row=row,
                              output_index_zero_based=index,
                              same_actual_evaluated_prefix=equal_prefix,
                              plain_id=plain_ids[index], actual_id=expected[row])
                for f, bf in [('hidden.bf16', True), ('logits.f32', False)]:
                    left, left_raw = rows(C / 'plain20/trace' / f'decode{index}' / f, bf)
                    right, right_raw = loaded[f]
                    width_bytes = left_raw.__len__()
                    result[f] = dict(**metrics(left[0], right[row]),
                                     byte_equal=left_raw == right_raw[row * width_bytes:(row + 1) * width_bytes])
                    old = next(x for x in primary['aligned_committed_rows'] if
                               (x['control'], x['round'], x['row']) == (name, round_index, row))
                    assert old['same_logical_target_input_prefix'] == equal_prefix
                    assert abs(old[f]['relative_L2'] - result[f]['relative_L2']) < 1e-14
                    assert old[f]['max_abs'] == result[f]['max_abs']
                    raw_checks += 1
                    if not bf:
                        result['raw_argmax'] = [int(left[0].argmax()), int(right[row].argmax())]
                        assert result['raw_argmax'] == [plain_ids[index], expected[row]]
                        result['scores11_271'] = dict(plain=[float(left[0, t]) for t in (11, 271)],
                                                      actual=[float(right[row, t]) for t in (11, 271)])
                if equal_prefix:
                    same += 1
                    if index in (1, 18):
                        selected.append(result)
                else:
                    excluded.append(result)
            next_output += committed
        assert next_output == len(data[name]['generated_ids'])
        counts[name] = dict(committed_rows=next_output - 1, same_input_rows=same)
    assert sum(v['committed_rows'] for v in counts.values()) == 37
    assert sum(v['same_input_rows'] for v in counts.values()) == 36
    assert len(excluded) == 1 and excluded[0]['output_index_zero_based'] == 19
    first9 = {str(i): all((C / 'mtp19/trace' / f'mtp{i}' / f).read_bytes() ==
                         (C / 'mtp20/trace' / f'mtp{i}' / f).read_bytes()
                         for f in ('hidden.bf16', 'logits.f32')) for i in range(1, 10)}
    assert all(first9.values())
    final = {}
    for name in ('mtp19', 'mtp20'):
        a, _ = rows(C / name / 'trace/mtp10/logits.f32', False)
        final[name] = dict(target_rows=a.shape[0], row0_argmax=int(a[0].argmax()),
                           scores11_271=[float(a[0, t]) for t in (11, 271)])
    final['plain20'] = dict(output_index_zero_based=18, raw_argmax=plain_ids[18])
    report = dict(
        status='FROZEN_BOUNDED_HOST_ONLY_THREE_CONTROL_RECHECK',
        activity=dict(new_GPU_runs=0, new_builds=0, new_model_calculation=0),
        counts=dict(actual_processes=3, raw_committed_row_comparisons=37,
                    same_evaluated_prefix_rows=36, excluded_different_prefix_rows=1,
                    raw_hidden_logits_metric_checks=raw_checks),
        image=plans['plain20']['ready']['image'], main=plans['plain20']['ready']['main'],
        source=identity(Path(__file__)),
        inputs={n: [identity(C/n/f) for f in ('plan.json', 'run.result.json', 'run.stdout.log', 'parsed.json')]
                for n in names},
        primary=identity(S/'review/three-control-analysis.json'),
        prefill_published_last_hidden_and_logits_byte_equal=prefill,
        MTP_first9_round_published_full_rows_byte_equal=first9,
        committed_row_accounting=counts, selected_same_input_rows=selected,
        excluded_different_input_prefix=excluded, final_quota_control=final,
        findings=[
            'All three processes exited0 on the same current AD image/main and original P154. Only the selected published prefill hidden/logits are proven byte-equal here; complete recurrent/KV state equality is not inferred.',
            'MTP19 and MTP20 first9 rounds publish byte-identical hidden/logits with the same decisions. Their final quota T1/T2 row0 both choose11; ending with T1 alone does not recover plain271.',
            'Against plain, the first committed decode row already has hidden RL2 0.023649855761486902 and F32 score RL2 0.023175246954555632. The divergence therefore precedes the final head; this does not identify the first differing layer or prove an error.',
            'The 37 committed-row comparisons contain exactly36 same-input-prefix rows. MTP20 output index19 follows token11 versus plain271 at index18, so its numeric differences are separate changed-input observations and excluded from same-input causal claims.'
        ], quality_threshold=None, quality_pass=False, throughput_evidence=False)
    out = S/'review/three-controls-independent.json'
    out.write_text(json.dumps(report, ensure_ascii=False, indent=2, allow_nan=False)+'\n', encoding='utf-8')
    print(json.dumps(dict(report=identity(out), counts=report['counts'], final=final), indent=2))


if __name__ == '__main__':
    main()
