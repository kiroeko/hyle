"""Generate the finite current-policy scratch probe; no build/model on import or run."""
from pathlib import Path
import hashlib
import json

S=Path(__file__).resolve().parent
R=S.parents[1]
CPP=r'''

namespace {
struct AgNotMet final : std::runtime_error { using std::runtime_error::runtime_error; };
void ag_expect(bool value,const char *text) { if (!value) throw AgNotMet(text); }

void ag_current(const std::filesystem::path &inputs,const std::filesystem::path &output) {
  const auto tokens=q::read_ids(inputs/"prompt.ids");
  ag_expect(tokens.size()==154,"NOT_MET: original P154 input required");
  require(!std::filesystem::exists(output),"current diagnostic output must be fresh");
  std::filesystem::create_directories(output);
  const auto plan=q::cache::plan(1024,6,154,q::recurrent_bytes(q::state_schema_for(1024)),1,2,true);
  q::Model model(inputs/"weights.tsv",1024,plan);
  require(model.weights.size()==335,"current diagnostic needs335 tensors");
  model.trace_routes=output/"routes";
  MtpNumericsObservation observation{.data={.output=output}};
  const std::array prefills{std::size_t{154}},one{std::size_t{1}},two{std::size_t{2}};
  model.prepare_family(prefills,false,1,q::GraphRole::kMtpPrefill);
  model.plan_replay_uses(154,1,1,q::GraphRole::kMtpPrefill);
  for (auto role:{q::GraphRole::kMtpSingle,q::GraphRole::kMtpCatchupSingle,
                 q::GraphRole::kMtpRound,q::GraphRole::kMtpCatchupRound}) {
    model.prepare_family(q::drafts_token(role)?std::span(two):std::span(one),false,1,role);
    model.plan_replay_uses(q::drafts_token(role)?2u:1u,1,64,role);
  }
  q::MtpGenerationRequest request({},tokens,{},64);
  request.session=model.create_session(prefills,{},q::GraphRole::kMtpPrefill);
  q::advance_mtp_request(model,request,64,false); ++observation.data.graph_calls;
  observation.data.observe(model);
  auto seed=request.session->head;
  const auto seed_bytes=image(model,*seed);
  observation.data.record("P154_prefill",batch_image(model,*request.session,
      *model.phases.at(q::ExecutionShape{1,154,q::GraphRole::kMtpPrefill}),0,1));
  while (request.session->length()<171 && !request.done) {
    q::advance_mtp_request(model,request,64,false); ++observation.data.graph_calls;
    observation.data.observe(model);
  }
  const std::array<std::int32_t,18> expected_prefix{@PREFIX@};
  ag_expect(request.session->length()==171 && request.generated.size()==18 &&
      std::equal(request.generated.begin(),request.generated.end(),expected_prefix.begin()),
      "NOT_MET: natural64-quota derivation did not reach original L171/18-ID prefix");
  ag_expect(request.generated.back()==11906 && request.session->head->draft &&
      request.session->head->draft->lag==1,"NOT_MET: original L171/pending11906/lag1 required");
  require(same(seed_bytes,image(model,*seed)),"natural derivation changed retained P154 source52");
  ++observation.seed_unchanged_checks;
  auto later=request.session->head;
  const auto control=[&](const std::string &name,const q::cache::SnapshotRef &old,std::int32_t pending) {
    const auto original=image(model,*old);
    const auto lag=old->draft->lag;
    const auto role1=lag?q::GraphRole::kMtpCatchupSingle:q::GraphRole::kMtpSingle;
    const auto role2=lag?q::GraphRole::kMtpCatchupRound:q::GraphRole::kMtpRound;
    auto first=model.create_session({},old,q::GraphRole::kMtpPrefill);
    require(first->head.get()==old.get(),"T1 did not borrow exact source Snapshot");
    q::MtpReplayLedger ledger1(1);
    batch_single_commit(model,observation.data,first,ledger1,std::span(&pending,1),role1,true,1,name+"_T1",pending);
    const auto saved=observation.data.record(name+"_T1",batch_image(model,*first,
        *model.phases.at(q::ExecutionShape{1,1,role1}),0,1));
    require(same(original,image(model,*old)),"T1 changed retained source52");
    ++observation.control_unchanged_checks;
    const auto first_after=first->length();
    retire_prefix_session(first);
    auto second=model.create_session({},old,q::GraphRole::kMtpPrefill);
    require(second->head.get()==old.get(),"T2 did not borrow exact source Snapshot");
    q::MtpReplayLedger ledger2(1);
    // Explicit T2 Graph; quota1 selects its real first boundary, never fakes agreement.
    batch_single_commit(model,observation.data,second,ledger2,std::span(&pending,1),role2,true,1,name+"_T2",pending);
    auto captured=batch_image(model,*second,*model.phases.at(q::ExecutionShape{1,2,role2}),0,1);
    for (const auto &blob:captured.blobs) if (blob.name=="output.logits.f32" || blob.name=="output.hidden.bf16") {
      const auto found=std::find_if(saved.vectors.begin(),saved.vectors.end(),[&](const auto &v){return v.name==blob.name;});
      require(found!=saved.vectors.end() && blob.bytes.size()==2*found->bytes,"T2 output is not exactly two T1 rows");
      Blob row0{blob.name,blob.bf16,Bytes(blob.bytes.begin(),blob.bytes.begin()+static_cast<std::ptrdiff_t>(found->bytes))};
      auto metric=compare(*found,row0,output/(name+"_T2_row0")/blob.name);
      metric.name=name+"_T2_row0/"+metric.name;
      observation.data.finite=observation.data.finite && !metric.nonfinite_baseline && !metric.nonfinite_actual;
      observation.data.metrics.push_back(std::move(metric));
    }
    observation.data.record(name+"_T2",std::move(captured),&saved);
    require(same(original,image(model,*old)),"T2 changed retained source52");
    ++observation.control_unchanged_checks;
    const auto &a=ledger1.records[0];const auto &b=ledger2.records[0];
    require(first_after==old->length+1 && second->length()==old->length+1 &&
        a.accepted==1 && b.accepted==1 && !b.accepted_draft,"quota1 did not publish first boundary");
    std::ostringstream note;
    note<<"{\"kind\":\"same_head_T1_T2\",\"name\":"<<quoted(name)<<",\"source\":"<<original.metadata
        <<",\"same_old_snapshot_pointer\":true,\"old_full52_unchanged\":true,\"pending\":"<<pending
        <<",\"T1_target_first\":"<<a.target_first<<",\"fresh_T2_draft\":"<<b.draft
        <<",\"T2_target_first\":"<<b.target_first<<",\"T2_target_second\":"<<b.target_second
        <<",\"natural_agreed\":"<<(b.agreed?"true":"false")<<",\"accepted_draft\":false,\"quota\":1}";
    observation.controls.push_back(note.str());
    retire_prefix_session(second);
  };
  control("P154",seed,expected_prefix[0]);
  control("L171",later,request.generated.back());
  q::retire_mtp_request(request); later.reset();
  auto single=model.create_session({},seed,q::GraphRole::kMtpPrefill);
  q::MtpReplayLedger singles(19);
  std::vector<std::int32_t> ids{expected_prefix[0]};ids.reserve(20);
  for (std::size_t i=0;i<19;++i) {
    const auto pending=ids.back();
    ag_expect(pending!=248044 && pending!=248046,"NOT_MET: natural Single EOS before20 outputs");
    const auto role=single->head->draft->lag?q::GraphRole::kMtpCatchupSingle:q::GraphRole::kMtpSingle;
    batch_single_commit(model,observation.data,single,singles,std::span(&pending,1),role,true,1,"all_single"+std::to_string(i+1),pending);
    const auto &record=singles.records[singles.committed_count-1];
    require(record.emitted_count==1,"Single emitted more than quota1");ids.push_back(record.emitted[0]);
  }
  const std::array<std::int32_t,20> ordinary{@ORDINARY@};
  std::ostringstream all;
  all<<"{\"kind\":\"all_single20\",\"generated_ids\":[";
  for(std::size_t i=0;i<ids.size();++i)all<<(i?",":"")<<ids[i];
  all<<"],\"ordinary20_reference_equal\":"<<(std::equal(ids.begin(),ids.end(),ordinary.begin())?"true":"false")
      <<",\"actual_graph_calls_after_seed\":19,\"ordinary_reference\":"<<quoted("@ORDINARY_PATH@")<<"}";
  observation.controls.push_back(all.str());
  observation.data.record("all_single20_final",batch_image(model,*single,
      *model.phases.at(q::ExecutionShape{1,1,q::GraphRole::kMtpSingle}),0,1));
  require(same(seed_bytes,image(model,*seed)),"allSingle changed retained P154 source52");
  ++observation.seed_unchanged_checks;
  retire_prefix_session(single);seed.reset();observation.data.observe(model);
  require(!model.active_step && !model.carrier_borrowed && model.snapshot_versions.live==0 && observation.data.finite,
      "current probe left a live head/borrow/candidate or nonfinite vector");
  observation.report("CURRENT_F32_SAME_HEAD_CONTROL_COMPLETE",model);
  std::cout<<"{\"status\":\"CURRENT_F32_SAME_HEAD_CONTROL_COMPLETE\",\"actual_graph_calls\":"
      <<observation.data.graph_calls<<",\"timing_comparison\":false}\n";
}
} // namespace
int main(int argc,char **argv) {
  try {
    std::filesystem::path inputs,output;
    for(int i=1;i<argc;i+=2) {
      if(i+1==argc)throw std::runtime_error("probe option lacks value");
      const std::string_view option(argv[i]);
      if(option=="--inputs")inputs=argv[i+1];else if(option=="--output")output=argv[i+1];
      else throw std::runtime_error("unknown current numerical probe option");
    }
    require(!inputs.empty()&&!output.empty(),"usage: current_probe --inputs DIR --output FRESH_DIR");
    ag_current(inputs,output);return 0;
  } catch(const AgNotMet &error) {
    std::cerr<<"NATURAL_PRECONDITIONS_NOT_MET: "<<error.what()<<'\n';return 2;
  } catch(const std::exception &error) {
    std::cerr<<"Current numerical probe: "<<error.what()<<'\n';return 1;
  }
}
'''


def identity(p):
    b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())


def load_observation(folder):
    for name in ('observation.json','stdout.log','run.stdout.log'):
        p=folder/name
        if not p.is_file():continue
        text=p.read_text(encoding='utf-8-sig')
        try:
            value=json.loads(text)
            if 'raw' in value:value=value['raw']
            if 'generated_ids' in value:return value,p
        except ValueError:
            pass
        for line in reversed(text.splitlines()):
            if not line.startswith('{'):continue
            try:value=json.loads(line)
            except ValueError:continue
            if 'raw' in value:value=value['raw']
            if 'generated_ids' in value:return value,p
    raise ValueError('missing existing control output: '+str(folder))


def main():
    original=R/'tools/qwen35_text/mtp_session_probe.cc'
    source=original.read_text(encoding='utf-8-sig')
    assert source.count('int main(int argc, char **argv) {')==1
    source=source.replace('int main(int argc, char **argv) {','int retained_mtp_session_probe_main(int argc, char **argv) {')
    assert source.count('#include "main.cc"')==1
    source=source.replace('#include "main.cc"','#include "'+(R/'tools/qwen35_text/main.cc').as_posix()+'"')
    old_metadata=r'\"capacity\":64,\"resident_limit\":6,\"active_sequences\":2'
    assert source.count(old_metadata)==1
    source=source.replace(old_metadata,r'\"capacity\":1024,\"resident_limit\":6,\"active_sequences\":1')
    lines=source.splitlines(True)
    matches=[i for i,line in enumerate(lines) if 'scope' in line and 'One R1 P15' in line]
    assert len(matches)==1
    lines[matches[0]]=r'      << ",\"scope\":\"Current AD F32 scores; one Model, P154 and natural L171 exact old-Snapshot T1 versus T2 quota1 first-boundary controls, plus allSingle20. No forced proposal, same-state fabrication, throughput or quality threshold.\""'+'\n'
    mtp,mtp_path=load_observation(S/'controls1/mtp19')
    ordinary,ordinary_path=load_observation(S/'controls1/plain20')
    assert len(mtp['generated_ids'])==19 and len(ordinary['generated_ids'])==20
    assert mtp['generated_ids'][:18]==ordinary['generated_ids'][:18]
    appended=CPP.replace('@PREFIX@',','.join(map(str,mtp['generated_ids'][:18])))
    appended=appended.replace('@ORDINARY@',','.join(map(str,ordinary['generated_ids'])))
    appended=appended.replace('@ORDINARY_PATH@',ordinary_path.as_posix())
    path=S/'source/current_probe.cc';path.parent.mkdir(exist_ok=True)
    if path.exists():raise ValueError('refuse to overwrite existing generated probe')
    path.write_text(''.join(lines)+appended,encoding='utf-8')
    record=dict(status='GENERATED_SOURCE_NOT_BUILT',source=identity(path),basis=identity(original),
        main=identity(R/'tools/qwen35_text/main.cc'),mtp_header=identity(R/'tools/qwen35_text/mtp_graph.h'),
        control_references=[identity(mtp_path),identity(ordinary_path)],generated_by=identity(Path(__file__)),
        builds=0,GPU_runs=0,scope='Finite source generation only; not a numerical or native execution result.')
    (S/'source/generated-source.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(record))


if __name__=='__main__':main()
