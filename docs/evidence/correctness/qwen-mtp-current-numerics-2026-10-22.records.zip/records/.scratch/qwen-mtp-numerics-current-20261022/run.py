"""Three finite current-image numerical controls; no throughput claim."""
from pathlib import Path
import importlib.util
import json
import os
import sys

sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
R = S.parents[1]
AD = R / '.scratch/qwen-cublas-scores-20261022'
V = R / '.scratch/qwen-mtp-window-20261022'
spec = importlib.util.spec_from_file_location('cached_AD_build_helpers', AD / 'build.py')
h = importlib.util.module_from_spec(spec)
spec.loader.exec_module(h)
b, c = h.b, h.c


def run():
    ready_path = AD / 'qwen-ready-attempt1.json'
    ready = c.read(ready_path)
    assert all(h.same(ready[key]) for key in ('image', 'source', 'runtime_environment'))
    assert (V/'inputs/text/prompt.ids').read_bytes() == (V/'inputs/mtp/prompt.ids').read_bytes()
    records = []
    for name, mtp, steps in [('mtp19', True, 19), ('mtp20', True, 20), ('plain20', False, 20)]:
        folder = S / 'controls1' / name
        folder.mkdir(parents=True, exist_ok=False)
        inputs = V / 'inputs' / ('mtp' if mtp else 'text')
        command = [ready['image']['path'], '--inputs', str(inputs), '--steps', str(steps),
                   '--capacity', '1024', '--max-sessions', '1', '--active-sequences', '1',
                   '--prefix-cache', 'off', '--progress', 'direct', '--replay', 'auto',
                   '--mtp', 'on' if mtp else 'off', '--trace', str(folder/'trace'),
                   '--trace-level', 'decisions']
        c.save(folder/'plan.json', dict(command=command, ready=ready,
            ready_record=b.identity(ready_path), prompt=b.identity(inputs/'prompt.ids'),
            diagnostic=True, throughput_evidence=False, tensor_trace='final hidden/logits per actual call; no full state dumps',
            limits=['Different output quota naturally selects Single versus Round at the final call.',
                    'A shared prompt is not an assertion of identical target states or algorithms.',
                    'No precision/provider/acceptance/ID changes; no synthetic proposals.']))
        env = os.environ.copy()
        env['PATH'] = c.read(ready['runtime_environment']['path'])['PATH']
        c.execute('run', command, env, folder)
        raw = json.loads((folder/'run.stdout.log').read_text(encoding='utf-8').splitlines()[-1])
        c.save(folder/'parsed.json', raw)
        records.append(dict(name=name, actual_generated_ids=raw['generated_ids'],
                            rounds=raw.get('rounds', []), process_receipt=b.identity(folder/'run.result.json')))
        print('CONTROL_COMPLETE', name, raw['generated_ids'], flush=True)
    c.save(S/'controls1/summary.json', dict(status='THREE_FINITE_CURRENT_IMAGE_CONTROLS_COMPLETE',
        model_processes=3, build_processes=0, score_policy='bf16_inputs_f32_output',
        throughput_evidence=False, controls=records))


if __name__ == '__main__':
    run()
