"""Write root test.ps1 before any exact-leaf cleanup; requires verified archive."""
from pathlib import Path
import hashlib,json
X=Path(__file__).resolve().parent;R=X.parents[1]
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def identity(p):
 p=Path(p);h=hashlib.sha256()
 with p.open('rb')as f:
  for data in iter(lambda:f.read(8<<20),b''):h.update(data)
 return dict(path=str(p.resolve()),bytes=p.stat().st_size,sha256=h.hexdigest())
published=read(X/'published.json');manifest=read(Path(published['manifest']['path']));members={Path(e['path']).resolve():e for e in manifest['archive_files']}
keep=[R/'.scratch/qwen-cublas-scores-20261022/qwen-link1/qwen.exe',R/'.scratch/qwen-mtp-window-20261022/peer/checks/attempt1/peer.exe']
assert all(p.exists()for p in keep)
targets=[]
for p in sorted(X.rglob('*')):
 if not p.is_file():continue
 raw=p.suffix in('.bf16','.f32','.i32','.bin')
 rebuild=p.suffix in('.map','.lib','.exp','.pdb','.pyc')or(p.suffix=='.exe'and p not in keep)
 if not(raw or rebuild):continue
 e=identity(p);e['kind']='verified archived raw diagnostic payload'if raw else'rebuildable probe/link output'
 if raw:
  archived=members[p.resolve()];assert all(archived[k]==e[k]for k in('bytes','sha256'));e['archive_entry']=archived['entry']
 targets.append(e)
plan=dict(scope=str((R/'.scratch').resolve()),batch_scope=str(X.resolve()),historical_image_allowlist=[],published=published,keep_images=[identity(p)for p in keep],targets=targets,count=len(targets),logical_bytes=sum(e['bytes']for e in targets),recursive=False)
(X/'cleanup-plan.json').write_text(json.dumps(plan,indent=2)+'\n',encoding='utf-8')
script=r'''# Exact verified leaves only. No recursion. Do not rerun after completion.
$ErrorActionPreference = 'Stop'
$taskRoot = 'C:\public\project-hyle\hyle\.scratch\qwen-mtp-numerics-current-20261022'
$planFile = Join-Path $taskRoot 'cleanup-plan.json'
$resultFile = Join-Path $taskRoot 'cleanup-result.json'
if (Test-Path -LiteralPath $resultFile) { throw 'Completed cleanup; do not rerun test.ps1.' }
$plan = Get-Content -LiteralPath $planFile -Raw | ConvertFrom-Json
$scope = [IO.Path]::GetFullPath($plan.scope).TrimEnd('\') + '\'
$batch = [IO.Path]::GetFullPath($plan.batch_scope).TrimEnd('\') + '\'
if ($scope -cne 'C:\public\project-hyle\hyle\.scratch\' -or $batch -cne ($taskRoot + '\')) { throw 'Unexpected cleanup scope' }
function Confirm-Identity($record) {
 $item = Get-Item -LiteralPath $record.path -Force -ErrorAction Stop
 if ($item.PSIsContainer -or $item.Length -ne $record.bytes) { throw ('File identity differs: ' + $record.path) }
 if ((Get-FileHash -LiteralPath $record.path -Algorithm SHA256).Hash.ToLowerInvariant() -cne $record.sha256) { throw ('File hash differs: ' + $record.path) }
}
Confirm-Identity $plan.script
Confirm-Identity $plan.script_copy
Confirm-Identity $plan.published.manifest
foreach ($archive in $plan.published.archives) { Confirm-Identity $archive }
$protected = [Collections.Generic.HashSet[string]]::new([StringComparer]::OrdinalIgnoreCase)
foreach ($record in $plan.keep_images) { Confirm-Identity $record; [void]$protected.Add([IO.Path]::GetFullPath($record.path)) }
$allowOld = [Collections.Generic.HashSet[string]]::new([StringComparer]::OrdinalIgnoreCase)
foreach ($path in $plan.historical_image_allowlist) { [void]$allowOld.Add([IO.Path]::GetFullPath($path)) }
$seen = [Collections.Generic.HashSet[string]]::new([StringComparer]::OrdinalIgnoreCase)
foreach ($target in $plan.targets) {
 $absolute = [IO.Path]::GetFullPath($target.path)
 if (-not $absolute.StartsWith($scope,[StringComparison]::OrdinalIgnoreCase) -or
     (-not $absolute.StartsWith($batch,[StringComparison]::OrdinalIgnoreCase) -and -not $allowOld.Contains($absolute)) -or
     $protected.Contains($absolute) -or -not $seen.Add($absolute)) { throw ('Unsafe cleanup target: ' + $absolute) }
 Confirm-Identity $target
}
$scriptText = Get-Content -LiteralPath $plan.script_copy.path -Raw
$removed = [Collections.Generic.List[object]]::new()
foreach ($target in $plan.targets) { Remove-Item -LiteralPath $target.path -Force -ErrorAction Stop; $removed.Add($target) }
$result = [ordered]@{status='completed; do not rerun';recursive=$false;script=$plan.script;script_copy=$plan.script_copy;script_text=$scriptText;removed_files=$removed.Count;removed_logical_bytes=$plan.logical_bytes;kept_images=$plan.keep_images;verified_archives=$plan.published.archives;removed=$removed}
$result | ConvertTo-Json -Depth 12 | Set-Content -LiteralPath $resultFile -Encoding utf8
Copy-Item -LiteralPath $resultFile -Destination 'C:\public\project-hyle\hyle\docs\evidence\correctness\qwen-mtp-current-numerics-cleanup-2026-10-22.json'
Write-Output ('Removed ' + $removed.Count + ' exact leaves / ' + $plan.logical_bytes + ' logical bytes. Completed; do not rerun.')
'''
(R/'test.ps1').write_text(script,encoding='utf-8');(X/'cleanup_script.ps1').write_text(script,encoding='utf-8')
plan['script']=identity(R/'test.ps1');plan['script_copy']=identity(X/'cleanup_script.ps1')
(X/'cleanup-plan.json').write_text(json.dumps(plan,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(files=len(targets),logical_bytes=plan['logical_bytes'],GiB=plan['logical_bytes']/2**30,keep_images=plan['keep_images']),indent=2))
