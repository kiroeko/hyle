from pathlib import Path
import hashlib
import json
import sys
import xml.etree.ElementTree as ET
import zipfile

ROOT = Path.cwd()
A = ROOT / '.scratch/architecture-refactor-2026-10-18'
S = A / 'static-fp8-reference'
DEST = ROOT / 'docs/evidence/correctness/static-fp8-reference-2026-10-20'
RESEARCH = ROOT / 'docs/evidence/research/static-fp8-stored-scale-contract-2026-10-20'
PUBLISH = '--publish' in sys.argv
FINAL_FREEZE = S / 'root/final-source-freeze.json'
CUDA_FINAL = S / 'cuda/final-validation.json'
entries, provenance, projections = {}, {}, []


def load(path):
    return json.loads(Path(path).read_bytes())


def encoded(value):
    return (json.dumps(value, ensure_ascii=False, indent=2) + '\n').encode('utf8')


def identity(path):
    path = Path(path)
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())


def add(path, member=None):
    path = Path(path)
    member = member or ('evidence/' + path.relative_to(A).as_posix())
    data = path.read_bytes()
    assert member not in entries or entries[member] == data, member
    entries[member] = data
    provenance[member] = identity(path)


def compact(value):
    if isinstance(value, dict):
        result = {}
        for key, child in value.items():
            if key == 'dependencies' and isinstance(child, list):
                result['dependency_inventory'] = dict(count=len(child),
                    sha256=hashlib.sha256(encoded(child)).hexdigest(),
                    omitted='Repeated transitive header/SDK identities only; full original receipt identity is retained.')
            else:
                result[key] = compact(child)
        return result
    if isinstance(value, list):
        return [compact(child) for child in value]
    return value


def project_receipt(path):
    original = load(path)
    projected = compact(original)
    member = 'receipts/' + path.relative_to(A).as_posix()
    entries[member] = encoded(projected)
    provenance[member] = identity(path)
    projections.append(dict(original=identity(path), compact_member=member,
                            only_repeated_dependency_arrays_omitted=True))


# Original before/after snapshots and real red processes remain separate. No
# model tensor, SDK, executable, object, map, archive copy or generated C++ array.
allowed = {'.json', '.py', '.diff', '.xml', '.txt', '.log', '.h', '.cc', '.cuh',
           '.cu', '.comp', '.glsl', '.before'}
for path in sorted(S.rglob('*')):
    if not path.is_file() or path in (S / 'package-plan.json', S / 'package-receipt.json'):
        continue
    relative = path.relative_to(S)
    if '__pycache__' in relative.parts or path.suffix.lower() not in allowed:
        continue
    if path.name.endswith(('-deps.json', '.d')) or path.name in ('live.json', 'vulkan_shaders.cc'):
        continue
    if path.suffix.lower() == '.json' and (
            path.name.endswith('-identity.json') or
            path.name in ('objects-ready.json', 'compile-summary.json')):
        project_receipt(path)
    else:
        add(path)

# Research is already independently published. Keep its small report and exact
# ZIP identity instead of copying the full primary-source archive a second time.
add(RESEARCH.with_suffix('.json'), 'research/' + RESEARCH.with_suffix('.json').name)
research = dict(report=identity(RESEARCH.with_suffix('.json')),
                archive=identity(RESEARCH.with_suffix('.zip')),
                status='Header/source-only research; no artifact tensor payload execution.')


def source_records(value):
    if isinstance(value, dict):
        if all(key in value for key in ('path', 'bytes', 'sha256')):
            candidate = Path(value['path'])
            if not candidate.is_absolute():
                candidate = ROOT / candidate
            if candidate.is_relative_to(ROOT) and candidate.is_file():
                relative = candidate.relative_to(ROOT)
                if relative.parts[0] in ('include', 'src', 'tests'):
                    yield candidate, value
        for child in value.values():
            yield from source_records(child)
    elif isinstance(value, list):
        for child in value:
            yield from source_records(child)


source_paths = {ROOT / path for path in (
    'src/compute_packed_shared/static_fp8_linear.h',
    'src/graph/static_fp8_region.h', 'src/graph/closed_region.h',
    'src/graph/mapped_pattern_region.h', 'src/graph/artifact_packed_region.h',
    'src/compute_shader_shared/nvfp4_f32.h', 'src/compute_shader_shared/ct_packed.h',
    'src/compute_torch_shared/storage_cast.h',
    'include/hyle/simd/dtype.h', 'tests/compute_models/static_fp8_reference_fixture.h',
    'src/compute_route_cuda/default_policy.cc',
    'src/compute_provider_cuda/tensor_provider.cc',
    'src/compute_provider_cuda/tensor_kernel.h', 'src/compute_provider_cuda/tensor_kernel.cu',
    'tests/graph_route_cuda/scalar_float_test.cc')}
for path in (S / 'root/source-freeze.json', S / 'common-cpu/source-freeze.json',
             S / 'common-cpu/fixture-source-freeze.json', S / 'apple/source-freeze.json',
             S / 'vulkan/final-source-freeze.json', S / 'cuda-scalar-bridge/source-freeze.json',
             S / 'cuda-scalar-bridge/tests/source-freeze.json', FINAL_FREEZE):
    if not path.is_file():
        continue
    for candidate, record in source_records(load(path)):
        # Early snapshots remain historical facts. Only root's final freeze is
        # a publication condition for the current common/CUDA product sources.
        if path == FINAL_FREEZE:
            actual = identity(candidate)
            assert actual['bytes'] == record['bytes'] and actual['sha256'] == record['sha256'], candidate
        source_paths.add(candidate)
for path in sorted(source_paths):
    add(path, 'source/' + path.relative_to(ROOT).as_posix())
add(S / 'vulkan/shaders/static_fp8.spv')
entries['recipe-provenance.json'] = encoded(projections)


def parse_xml(path):
    document = ET.parse(path).getroot()
    cases = []
    for case in document.findall('.//testcase'):
        assert not any(case.findall(tag) for tag in ('failure', 'error', 'skipped')), path
        assert case.attrib.get('status') == 'run' and case.attrib.get('result') == 'completed', path
        cases.append(dict(suite=case.attrib['classname'], name=case.attrib['name'],
            properties={p.attrib['name']: p.attrib['value']
                        for p in case.findall('./properties/property')}))
    assert int(document.attrib['failures']) == 0 and int(document.attrib['errors']) == 0, path
    assert int(document.attrib['tests']) == len(cases), path
    return dict(tests=len(cases), failures=0, errors=0, skipped=0,
                cases=cases, xml=identity(path))


known_xmls = {
    'windows_cpu': S / 'common-cpu/checks/forced-native-provider/tests.xml',
    'windows_vulkan_static': S / 'vulkan/validation/static/tests.xml',
    'windows_vulkan_neighbors': S / 'vulkan/validation/neighbors/tests.xml',
    'macos_apple': S / 'apple/mac/remote/ieee-binary-v2/results/tests.xml',
}
missing = [str(path) for path in (*known_xmls.values(), FINAL_FREEZE, CUDA_FINAL) if not path.is_file()]
plan = dict(status='prepared_not_published', missing_final_evidence=missing,
            members=len(entries), uncompressed_bytes=sum(map(len, entries.values())),
            current_source_files=len(source_paths), projected_recipes=len(projections),
            known_green_tests=58,
            CUDA='Root scalar-policy correction3static+8neighbors passed; awaiting same-object ordinary scalar probe and final root freeze/receipt. Initial real red retained.',
            target=str(DEST), public_files_written=False)
if not PUBLISH:
    (S / 'package-plan.json').write_bytes(encoded(plan))
    print(json.dumps(plan, ensure_ascii=False, indent=2))
    raise SystemExit(0)

# Root will explicitly authorize publication only after the CUDA correction and
# focused neighbors are actually green and the final root freeze exists.
assert not missing, missing
validation = {name: parse_xml(path) for name, path in known_xmls.items()}
assert validation['windows_cpu']['tests'] == 31
assert validation['windows_vulkan_static']['tests'] == 4
assert validation['windows_vulkan_neighbors']['tests'] == 12
assert validation['macos_apple']['tests'] == 11
for path in (S / 'common-cpu/checks/forced-native-provider/tests.result.json',
             S / 'apple/mac/remote/ieee-binary-v2/results/validation.json',
             S / 'vulkan/validation/static/result.json',
             S / 'vulkan/validation/neighbors/result.json'):
    result = load(path)
    assert result.get('returncode', result.get('exit', result.get('exit_code'))) == 0, path


def xml_records(value):
    if isinstance(value, dict):
        if str(value.get('path', '')).endswith('tests.xml'):
            yield value
        else:
            for child in value.values():
                yield from xml_records(child)
    elif isinstance(value, list):
        for child in value:
            yield from xml_records(child)


cuda = load(CUDA_FINAL)
scope = cuda.get('final', cuda.get('processes'))
assert scope is not None, 'CUDA final receipt must explicitly identify final green processes/XML.'
cuda_xml = {}
for record in xml_records(scope):
    path = Path(record['path'])
    if not path.is_absolute():
        path = ROOT / path
    assert identity(path)['sha256'] == record['sha256'], path
    cuda_xml[str(path)] = parse_xml(path)
assert cuda_xml, 'CUDA final process XML missing.'
assert len(cuda_xml) == 3 and sum(item['tests'] for item in cuda_xml.values()) == 13
for process in cuda['final']:
    result_path = Path(process['result']['path'])
    if not result_path.is_absolute():
        result_path = ROOT / result_path
    assert identity(result_path)['sha256'] == process['result']['sha256']
    assert load(result_path)['returncode'] == 0 and load(result_path)['skipped'] == 0
assert any('Static' in case['suite'] for item in cuda_xml.values() for case in item['cases'])
validation['windows_cuda'] = dict(tests=sum(item['tests'] for item in cuda_xml.values()),
    failures=0, errors=0, skipped=0, processes=cuda_xml, final_receipt=identity(CUDA_FINAL))
report = dict(
    status='bounded_static_stored_scale_FP8_reference_and_ordinary_graph_correctness_verified',
    scope='Single-machine Windows CPU/CUDA/Vulkan and macOS Apple primitive math/lifetime regression; original stored E4M3FN weights and two independent F32 scalar scales.',
    contract=dict(inputs=['F32/F16/BF16 A[M,K]', 'E4M3FN W[N,K]', 'F32 SA[] or[1]', 'F32 SW[] or[1]'],
        arithmetic='F32 A * F32(1/SA), SATFINITE nearest-even E4M3FN Cast, widen codes to F32; F32 code-dot with backend reduction tree; separate F32 MulSA then MulSW; descriptor F32/F16/BF16 output rounding.',
        IEEE='All scalar IEEE values remain legal; signed zero, NaN class, Inf and subnormal boundaries are exercised. No positivity/finite scale guard, scale precombination or weight-scale predecode.',
        integration='Existing12-node ordinary graph may contract under the shared closed reader/publication/control proof. Published codes/weight escapes retain the original ordinary graph. Original bytes remain canonical; no persistent NK decoded bank or new executor.'),
    validation=validation, total_passed=sum(item['tests'] for item in validation.values()),
    final_source_freeze=identity(FINAL_FREEZE),
    source_counts=dict(final_root_freeze_entries=len(load(FINAL_FREEZE)['files']),
                       final_root_freeze_unique=len({str(Path(row['path']).resolve()).lower()
                           for row in load(FINAL_FREEZE)['files']}),
                       current_source_members=len(source_paths)), research=research,
    backend_receipts={name: identity(S / name / 'final-validation.json')
                      for name in ('common-cpu', 'cuda', 'vulkan', 'apple')},
    corrections=['CPU initial two policy assertions failed because an existing ggml preference100 prefix won; raw pattern, closed proof and proposal were actually true. Test-only public native ProviderId constraints select the real packed candidate; product ranking/matcher remain unchanged and ordinary escape retains the default route.',
                 'Apple initial ordinary subnormal escape and a minimal public Mul/Cast probe failed: F32 scalar Multiply flushed its product to zero while the original BF16 storage Cast correctly retained0x0008. The generic dense F32 scalar Mul/Divide bridge fixes that arithmetic path, and the same red test object passed in the final process.',
                 'CUDA initial ordinary escape produced zero for a nonzero BF16 subnormal. One default_policy CXX routes the existing admitted dense F32 scalar Multiply/Divide domain to the existing native leaf, whose actual retained kernel recipe has no fast-math FTZ flag; no new scalar executor, CUDA kernel, SDK rebuild or relaxed oracle. Original failing image/logs and final same-object tests are retained.',
                 'The first two-case CUDA scalar probe process failed during owned-output binding because its test invocation omitted the required resource episode. It never reached arithmetic and is not numerical FTZ evidence. The test-only resource option correction, first source/object identities and final same-object old/new-policy processes are retained separately.',
                 'With that setup corrected, the two-case minimal CUDA probe actually reproduced zero from ordinary F32 scalar Multiply/Divide while independent BF16 Cast retained0x0008. The same test object passed both cases after changing only the policy object; actual old/new selected provider records and link-input identity comparison are retained.',
                 'Private native MLX, ArtifactPackedLinear and checked GPTQ decode paths no longer allocate an unused per-invocation ATen result holder and report zero for that holder. Static FP8 still owns a small encoded-activation pointer holder and reports its actual sizeof(Invocation); ordinary ATen result paths retain their holder. This does not make opaque SDK allocations known.'],
    selection='Positive contracted tests select actual existing proposals using test-only source/provider constraints; this does not establish default static-contraction selection or performance. Vulkan/Apple retain ordinary200 before bounded201, and CPU/CUDA static candidate ranking is unchanged. CUDA ordinary plain dense F32 Multiply/Divide with a rank0 or rank1[1] scalar and peer shape equal to output now prefers the existing admitted native leaf. Other scalar dtypes, non-scalar tensor domains and unrelated rankings retain their previous behavior.',
    limits=['No publisher tensor payload/full artifact execution, full-model importer/quality, performance, native tensor-core FP8 scaled-mm equivalence, Linux or all-installed-build claim.',
            'This implements the selected compositional stored-scale reference tree, not a claim that every producer/exporter or deployment GEMM has the same reduction and rounding behavior.',
            'Ordinary FP8 storage Cast is a numeric bridge, not admission for arbitrary FP8 arithmetic. Direct dtype coverage and physical address limits are recorded per backend.',
            'Native F32 code-dot reduction order is backend-specific; sparse independent witnesses do not certify identical arbitrary reduction sums.',
            'Actual integer/grid/storage-buffer limits remain. Opaque private allocations are unknown, actual OOM does not automatically reselect, and no measured peak-memory or throughput gain is claimed.',
            'Vulkan standard run did not enable validation layers. Shader/host mathematical source checks supplement and do not replace the actual GPU test processes.'])
assert report['total_passed'] == 71
entries['report-core.json'] = encoded(report)
inventory = dict(schema='static-fp8-reference-archive-members-v1', members=[
    dict(member=name, bytes=len(data), sha256=hashlib.sha256(data).hexdigest(), original=provenance.get(name))
    for name, data in sorted(entries.items())],
    note='Every archive member except this inventory is listed. Repeated dependency arrays are projected, with full original receipt identities retained.')
entries['inventory.json'] = encoded(inventory)
for name in entries:
    assert Path(name).suffix.lower() not in ('.exe', '.obj', '.o', '.lib', '.a', '.dll', '.pdb', '.map', '.zip', '.tar', '.metallib'), name
DEST.parent.mkdir(parents=True, exist_ok=True)
with zipfile.ZipFile(DEST.with_suffix('.zip'), 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for name, data in sorted(entries.items()):
        info = zipfile.ZipInfo(name, date_time=(2026, 10, 20, 0, 0, 0))
        info.compress_type = zipfile.ZIP_DEFLATED
        info.external_attr = 0o100644 << 16
        archive.writestr(info, data, compresslevel=9)
with zipfile.ZipFile(DEST.with_suffix('.zip')) as archive:
    assert archive.testzip() is None
    assert set(archive.namelist()) == set(entries)
    for name, data in entries.items():
        assert archive.read(name) == data, name
report['archive'] = dict(identity=identity(DEST.with_suffix('.zip')), members=len(entries),
    uncompressed_bytes=sum(map(len, entries.values())),
    inventory=dict(member='inventory.json', bytes=len(entries['inventory.json']),
                   sha256=hashlib.sha256(entries['inventory.json']).hexdigest()),
    verification='CRC plus every member exact bytes and SHA inventory verified after writing.')
DEST.with_suffix('.json').write_bytes(encoded(report))
receipt = dict(report=identity(DEST.with_suffix('.json')), archive=identity(DEST.with_suffix('.zip')),
               tests=report['total_passed'], members=len(entries), projected_recipes=len(projections),
               source_counts=report['source_counts'])
(S / 'package-receipt.json').write_bytes(encoded(receipt))
print(json.dumps(receipt, ensure_ascii=False, indent=2))
