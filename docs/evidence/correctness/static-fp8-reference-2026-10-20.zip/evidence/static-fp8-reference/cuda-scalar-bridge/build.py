from pathlib import Path
import importlib.util,json,sys
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent; A=S.parents[1];ROOT=A.parents[1];O=S/'checks'
spec=importlib.util.spec_from_file_location('scalar_host',A/'grouped-shared-activation/build_host.py');h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h);b,c=h.b,h.c
BASE=A/'static-fp8-reference/cuda/tests-final/link-plan.json'
REC=A/'fp8-shared-prologue/checks/host1/compute_route_cuda--default_policy-identity.json'
def same(row):
 p=Path(row['path']);p=p if p.is_absolute() else ROOT/p;a=b.identity(p);assert a['sha256']==row['sha256'] and a['bytes']==row['bytes'],str(p)
def run():
 O.mkdir(parents=True,exist_ok=True);(O/'tmp').mkdir(exist_ok=True)
 for row in c.read(S/'source-freeze.json')['files']:same(row)
 rec=c.read(REC);base=c.read(BASE);old=next(x for x in base['inputs'] if c.key(x['path'])==c.key(rec['object']['path']));same(old)
 cmd=b.host_command(rec['command'],ROOT/'src/compute_route_cuda/default_policy.cc','default-policy',O)
 plan=dict(base=b.identity(BASE),source_freeze=b.identity(S/'source-freeze.json'),old_object=old,recipe=b.identity(REC),command=cmd,counts=dict(product_CXX=1,links=0,NVCC=0,SDK=0,GPU=0),unchanged_ggml_gate=b.identity(ROOT/'src/graph_provider_ggml_cuda/ggml_cuda_region.cc'))
 c.save(O/'plan.json',plan);assert not (O/'default-policy-compile.result.json').exists()
 env,_=b.environment(cmd,[],O);c.execute('default-policy-compile',cmd,env,O)
 dep=O/'default-policy-deps.json';d=c.read(dep)['Data'];row=dict(source=b.identity(ROOT/'src/compute_route_cuda/default_policy.cc'),object=b.identity(O/'default-policy.obj'),old_object=old,recipe=b.identity(REC),command=cmd,source_dependencies=b.identity(dep),dependencies=[b.identity(p) for p in dict.fromkeys([d['Source'],*d['Includes']])]);c.save(O/'default-policy-identity.json',row)
 c.save(O/'summary.json',dict(passed=True,counts=plan['counts'],object=row['object'],identity=b.identity(O/'default-policy-identity.json')));print(json.dumps(row['object']))
if __name__=='__main__':run()
