from pathlib import Path
import importlib.util,json,sys
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent;A=S.parents[1];ROOT=A.parents[1];O=S/'checks'
spec=importlib.util.spec_from_file_location('scalar_host',A/'grouped-shared-activation/build_host.py');h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h);b,c=h.b,h.c
REC=A/'static-fp8-reference/cuda/checks/selection/static-test-identity.json'
def same(row):
 p=Path(row['path']);p=p if p.is_absolute() else ROOT/p;a=b.identity(p);assert a['sha256']==row['sha256'] and a['bytes']==row['bytes'],str(p)
def run():
 O.mkdir(parents=True,exist_ok=True)
 freeze=S/'tests/source-freeze.json'
 for row in c.read(freeze)['files']:same(row)
 rec=c.read(REC);tag='scalar-test';cmd=b.host_command(rec['command'],ROOT/'tests/graph_route_cuda/scalar_float_test.cc',tag,O)
 c.save(O/'scalar-test-plan.json',dict(source_freeze=b.identity(freeze),actual_old_recipe=b.identity(REC),command=cmd,counts=dict(test_CXX=1,product_CXX=0,links=0,NVCC=0,SDK=0,GPU=0)))
 assert not (O/(tag+'-compile.result.json')).exists();env,_=b.environment(cmd,[],O);c.execute(tag+'-compile',cmd,env,O)
 dep=O/(tag+'-deps.json');d=c.read(dep)['Data'];row=dict(source=b.identity(ROOT/'tests/graph_route_cuda/scalar_float_test.cc'),object=b.identity(O/(tag+'.obj')),old_recipe=b.identity(REC),command=cmd,source_dependencies=b.identity(dep),dependencies=[b.identity(p) for p in dict.fromkeys([d['Source'],*d['Includes']])]);c.save(O/(tag+'-identity.json'),row);print(json.dumps(row['object']))
if __name__=='__main__':run()
