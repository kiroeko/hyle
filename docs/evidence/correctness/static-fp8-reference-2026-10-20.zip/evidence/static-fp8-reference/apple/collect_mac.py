"""Collect receipts and logs only; retain SDKs, objects and images on the Mac."""
from pathlib import Path
import base64
import hashlib
import json
import subprocess
S = Path(__file__).resolve().parent
OUT = S / "mac"
remote = json.loads((OUT / "plan.json").read_text(encoding="utf-8"))["remote"]
code = r'''
from pathlib import Path
import base64,json,hashlib,sys
r=Path(sys.argv[1])
def identity(p):
 b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
lib=(r/"mlx.metallib").resolve()
(r/"runtime-identity.json").write_text(json.dumps({"metallib":identity(lib)},indent=2)+"\n")
paths=[r/"plan.json",r/"source-manifest.json",r/"hardware.json",r/"runtime-identity.json",
 *sorted((r/"results").rglob("*")),*sorted((r/"probe/results").rglob("*")),*sorted((r/"ieee-binary-v2/results").rglob("*"))]
files=[]
for p in paths:
 if not p.is_file()or p.suffix not in [".json",".xml",".log"]:continue
 b=p.read_bytes();files.append(dict(path=p.relative_to(r).as_posix(),bytes=len(b),
 sha256=hashlib.sha256(b).hexdigest(),data=base64.b64encode(b).decode()))
print(json.dumps(files))
'''
encoded = base64.b64encode(code.encode()).decode()
command = ["ssh", "-o", "BatchMode=yes", "kiro@172.22.10.198",
           'python3 -c "import base64;exec(base64.b64decode(\'' + encoded + '\'))" ' + remote]
p = subprocess.run(command, capture_output=True, check=True)
rows = json.loads(p.stdout)
manifest = []
for row in rows:
    data = base64.b64decode(row["data"])
    assert hashlib.sha256(data).hexdigest() == row["sha256"]
    path = OUT / "remote" / row["path"]
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(data)
    manifest.append({k: v for k, v in row.items() if k != "data"})
(OUT / "collected.json").write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
print("COLLECTED", len(rows), sum(row["bytes"] for row in rows), "receipt bytes")
