"""Scoped current static FP8 documentation, with no test totals/performance claim."""
from pathlib import Path
import copy
import difflib
import hashlib
import json

S=Path(__file__).resolve().parent
ROOT=S.parents[3]
changes=[]


def write(path,before,after):
    assert before != after,path
    p=ROOT/path
    p.write_text(after,encoding="utf-8")
    changes.extend(difflib.unified_diff(before.splitlines(True),after.splitlines(True),
        fromfile="before/"+path,tofile=path))


path="docs/user/compute.md"
before=(ROOT/path).read_text(encoding="utf-8")
after=before.replace("`Cast` 当前执行推理常用的五种浮点 storage：", "CPU Native 与 CUDA Native 的 `Cast` 支持五种浮点 storage：",1)
anchor="Bool 与 FP8 的直接转换也不在上述双向范围内。\n"
assert after.count(anchor)==1
after=after.replace(anchor,anchor+"\nApple 另提供 E4M3FN 与 F32/F16/BF16 的 storage Cast 桥；Vulkan 直接接 F32↔E4M3FN，\nF16/BF16 可以显式经过 F32 组合。这些入口保留 SATFINITE RNE、有符号零与 NaN 类别，\n不开放任意 FP8 算术；绑定、布局和容量仍遵守各后端的实际合同。\n",1)
anchor="## 普通 CUDA 入口\n"
assert after.count(anchor)==1
section="""## 使用存储 scale 的静态 FP8 线性

对于 plain E4M3FN 权重 `W[N,K]`、浮点 `A[M,K]` 和独立 F32 标量 `SA`、`SW`（`[]` 或 `[1]`），
用现有 `Cast`、`Binary`、transpose `View` 和 F32 累加的 `MatMul` 表达以下普通图：

```text
Q = CastE4M3FN(CastF32(A) * F32(1 / SA))
D = MatMul(CastF32(Q), transpose(CastF32(W)))
Y = CastOutput((D * SA) * SW)
```

`CastE4M3FN` 是保 NaN 类别的 SATFINITE nearest-even 转换。输出可显式取 F32/F16/BF16；
归一化、code-dot 和两次 scale 乘法保持 F32 边界，不预合并 `SA*SW`、不先还原成 BF16 操作数，
也不计算 per-token absmax。这是存储 scale 的软件参考，与动态 block128、CT channel/token QDQ
或硬件 `scaled_mm` 不自动等价。

CPU、CUDA、Apple、Vulkan 已接通该普通图及闭合子图的有界冷候选；未发布、单读且无控制逃逸的
精确链可直接读取原 FP8 权重，避免整份 `N*K` F32 权重展开。发布中间结果时保留原分解与真实物化；
实际选择、workspace、capture 和设备范围仍以准备结果为准，没有新增公开线性算子。
[数值与资源寿命记录](../evidence/correctness/static-fp8-reference-2026-10-20.json)不代表所选制品 payload、
完整模型、质量或吞吐已经验证。

"""
after=after.replace(anchor,section+anchor,1)
write(path,before,after)

path="docs/architecture/compute-design.md"
before=(ROOT/path).read_text(encoding="utf-8")
anchor="这不证明整制品支持，也不授权将QDQ替换成另一种FP8计算。\n"
assert before.count(anchor)==1
addition="""
存储 scale 的静态 FP8 另保留明确的普通图：`F32(A)*F32(1/SA)` 经 SATFINITE E4M3 RNE 后扩宽做
F32 code-dot，再分别乘 `SA`、`SW`，最后转输出类型；不预合 scale 或先窄化 BF16 操作数。
四后端复用共同的 reader/control 闭合证明识别这条链；CPU/CUDA 按实际端口数冷准备映射，适配原 prepared
接口，Apple/Vulkan 沿原 native region lower。所选同 build 私有线性载体直接读取原权重，
没有新增公共算子、模型名单、执行器或热路由；公开中间结果仍走原图。
普通路径自身也必须正确：原生 F32 乘除的 FTZ 曾使逃逸路径丢失非零 BF16 结果，
现已沿 Apple/CUDA 通用算子桥修复；正常有限乘法仍用原生计算，敏感边界用严格位级实现。
[定向记录](../evidence/correctness/static-fp8-reference-2026-10-20.json)保留该真实红绿；
这不承诺所有布局、原生 TensorCore FP8 等价或性能改善。
"""
after=before.replace(anchor,anchor+addition,1)
write(path,before,after)

path="docs/implementation/model-operators.md"
before=(ROOT/path).read_text(encoding="utf-8")
identity=before.split("## 模型与量化身份\n",1)[1].split("\n## ",1)[0]
anchor="GPTQ-v1也已接原四端口decode及有界packed候选；小型算子回归不代表制品导入或整模型执行。\n"
assert before.count(anchor)==1
after=before.replace(anchor,anchor+"ModelOpt 存储 scale 的静态 FP8 也已接四后端普通图参考及有界冷候选，独立 SA/SW 不套动态 block128；\n+所选 mixed 制品的 payload、其它角色与整体执行仍未验。\n".replace("\n+","\n"),1)
anchor="| 官方/CT grouped FP8；"
start=after.index(anchor)
row="| ModelOpt 存储 scale 的静态 FP8 Linear | plain E4M3 `W[N,K]` 与独立 F32 标量 SA/SW；普通图保 `F32(A)*F32(1/SA)`→SATFINITE E4→F32 code-dot→先 SA 再 SW→末端 Cast。四后端已接精确闭合链的私有有界候选，直接读原 W、不留 NK F32 bank；公开中间值沿原分解。[数值／寿命与普通图红绿](../evidence/correctness/static-fp8-reference-2026-10-20.json) | 只签存储 scale 软件参考，不等同 fake-QDQ、动态 block128、CT token/channel 或原生 scaled_mm；固定 producer/header 研究不证明所选 mixed 制品 payload、KV/conv、整模型、质量或吞吐。保原默认偏好与设备范围 |\n"
after=after[:start]+row+after[start:]
assert identity==after.split("## 模型与量化身份\n",1)[1].split("\n## ",1)[0]
write(path,before,after)

path="docs/implementation/model-quantizations.json"
before=(ROOT/path).read_text(encoding="utf-8")
j=json.loads(before);original=copy.deepcopy(j)
for index in [7,17,28]:
    c=j["artifacts"][index]["provider_coverage"]
    assert c["artifact_execution_verified"] is False
    c["review"]="bounded_header_source_and_four_backend_static_fp8_reference_regressions"
    c["review_scope"]="Fixed-revision bounded FP8 role headers and primary-source contract research, plus synthetic ordinary Graph and closed bounded reference execution on CPU/CUDA/Apple/Vulkan. No selected artifact payload, full importer/model, quality or performance verification."
    if index==17:
        c["mapping_status"]="Existing GroupedNvfp4Linear reference and stored-scale static FP8 ordinary Graph/bounded candidates are implemented on CPU/CUDA/Apple/Vulkan; exact mixed-artifact payload/import binding remains unverified"
    elif index==28:
        c["mapping_status"]="Stored-scale static FP8 linear software reference is mapped to ordinary Graph and bounded four-backend candidates; NVFP4 expert payload binding, static FP8 KV layout and exact producer remain unverified"
    else:
        c["mapping_status"]="Stored-scale static FP8 linear ordinary Graph and bounded four-backend candidates are implemented; mixed NVFP4 role payload/global-scale/import binding remains unverified"
    c["reachable_entry_points"].append("CPU/CUDA/Apple/Vulkan ordinary Cast/Binary/transpose/MatMul stored-scale reference and same-Graph bounded cold candidate, taking A, original plain E4M3FN W[N,K], independent F32 scalar SA/SW")
    c["static_fp8_contract"]={
        "inputs":"Plain dense F32/F16/BF16 A[M,K], original E4M3FN W[N,K], independent F32 SA/SW scalar[] or[1]",
        "numerical":"F32(A)*F32(1/SA) -> SATFINITE nearest-even E4M3FN -> F32 code dot -> separate F32 *SA then*SW -> declared output Cast. No precombined scales, BF16 operand QDQ, per-token absmax or new scalar finite/positive guard.",
        "storage_and_selection":"Closed unpublished ordinary graph can cold-select a same-build private bounded carrier reading original W, without an N*K F32 bank. Published/control/reader escapes keep the ordinary decomposition; defaults and native device/address limits remain backend-specific.",
        "header_scope":"Bounded fixed-revision sampled Linear headers establish real plain FP8 weights and independent F32 scalar fields only; other roles/shards and all payload values remain unverified.",
        "producer_limit":"GLM publisher version0.0.0 does not identify an exact exporter; the software reference is explicit and does not certify this publisher's whole forward." if index==28 else "Pinned inspected producer/deployment source informs the explicit reference, not an unmodified publisher wheel, calibrated amax reconstruction or native scaled_mm bit-equivalence.",
        "research":"../evidence/research/static-fp8-stored-scale-contract-2026-10-20.json",
        "evidence":"../evidence/correctness/static-fp8-reference-2026-10-20.json"}
    c["artifact_unaligned_or_unverified"]=[
        x for x in c["artifact_unaligned_or_unverified"] if x not in [
          "Read per-role FP8/NVFP4 codes, group/global scale tensors and activation quantizer parameters",
          "Read per-role FP8/NVFP4 codes, group/global scales and static activation quantizer parameters",
          "The FP4 portion has the same unresolved static group16 W4A4 domain as artifact index 3"]]
    c["artifact_unaligned_or_unverified"].insert(0,"Only bounded FP8 headers and synthetic reference graphs were checked; actual FP8/NVFP4 code/scalar payload values, role import binding and the complete mixed artifact remain unverified.")
    if index in [7,17]:
        c["missing_capabilities"]=["Actual per-role mixed FP8/NVFP4 payload/global-scale/import binding and complete artifact execution; existing reference paths do not complete the importer"]
    else:
        c["missing_capabilities"]=[x for x in c["missing_capabilities"]if x!="Static calibrated FP8 linear activation/scale contract"]
        c["missing_capabilities"]=["Per-role NVFP4 group16 payload/global-scale/import binding; existing reference primitives do not establish this artifact's producer equivalence"if x=="Exact ModelOpt NVFP4 group16 W4A4 codec and kernel/importer"else x for x in c["missing_capabilities"]]
        c["fusion_coverage"]="Exact closed stored-scale FP8 software graph has a bounded candidate; no complete mixed-artifact FFN/expert fusion or native scaled_mm equivalence established. Packed-module aliases do not prove execution fusion."
    c["code"]=[x for x in c["code"]if "defines dynamic group128 activation rather than ModelOpt static quantizers"not in x]
    for new in ["src/compute_packed_shared/static_fp8_linear.h","src/graph/static_fp8_region.h","src/graph/mapped_pattern_region.h","src/compute_provider_native/static_fp8.cc","src/compute_provider_torch_cuda/artifact_provider.cc","src/compute_route_apple/apple_static_fp8.cc","src/compute_route_vulkan/vulkan_static_fp8.cc"]:
        if new not in c["code"]:c["code"].append(new)
    assert c["artifact_execution_verified"] is False
after=before
for index in [7,17,28]:
    old=json.dumps(original["artifacts"][index]["provider_coverage"],ensure_ascii=False,indent=2).replace("\n","\n      ")
    new=json.dumps(j["artifacts"][index]["provider_coverage"],ensure_ascii=False,indent=2).replace("\n","\n      ")
    assert after.count(old)==1
    after=after.replace(old,new)
assert json.loads(after)==j
for index,a in enumerate(j["artifacts"]):
    expected=copy.deepcopy(original["artifacts"][index])
    if index in [7,17,28]:expected["provider_coverage"]=a["provider_coverage"]
    assert a==expected,index
assert all(a["provider_coverage"]["artifact_execution_verified"]is False for a in j["artifacts"])
write(path,before,after)
(S/"current-docs-update.diff").write_text("".join(changes),encoding="utf-8")
print(json.dumps(dict(changed_docs=4,HF_identity_table_preserved=True,artifacts_edited=[7,17,28],all_33_artifact_execution_false=True,builds=0)))
