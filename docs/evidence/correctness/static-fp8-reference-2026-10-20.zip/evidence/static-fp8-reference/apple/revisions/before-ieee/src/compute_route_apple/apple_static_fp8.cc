#include "apple_static_fp8.h"

#include "../compute_shader_shared/ct_packed.h"
#include "../compute_shader_shared/nvfp4_f32.h"

#include <algorithm>
#include <array>
#include <cstdint>
#include <limits>
#include <optional>
#include <string>

#include <mlx/fast.h>
#include <mlx/ops.h>

namespace hyle::compute::apple::detail {
namespace mx = mlx::core;
namespace {
bool floating(DataType t) noexcept {
  return t == DataType::kFloat32 || t == DataType::kFloat16 || t == DataType::kBFloat16;
}
int scalar_tag(DataType t) noexcept {
  return t == DataType::kFloat16 ? 1 : t == DataType::kBFloat16 ? 2 : 0;
}
mx::Dtype raw_type(DataType t) noexcept {
  return t == DataType::kFloat8E4M3FN ? mx::uint8
       : t == DataType::kFloat32 ? mx::uint32 : mx::uint16;
}
mx::Dtype native_type(DataType t) noexcept {
  return t == DataType::kFloat8E4M3FN ? mx::uint8
       : t == DataType::kFloat32 ? mx::float32
       : t == DataType::kFloat16 ? mx::float16 : mx::bfloat16;
}
std::string kernel_header() {
  return std::string(R"METAL(
    inline uint hyle_mul_hi(uint a, uint b) { return uint((ulong(a) * ulong(b)) >> 32); }
    inline uint hyle_clz(uint a) { return clz(a); }
  )METAL") + shader::kNvfp4F32 + shader::kCtPacked + R"METAL(
    inline uint hyle_e4_to_f32(uint code) {
      const uint sign = (code & 128u) << 24u, magnitude = code & 127u;
      const uint exponent = magnitude >> 3u, mantissa = magnitude & 7u;
      if (magnitude == 127u) return sign | 0x7fc00000u;
      if (exponent != 0u)
        return sign | ((exponent + 120u) << 23u) | (mantissa << 20u);
      if (mantissa == 0u) return sign;
      const uint leading = 31u - hyle_clz(mantissa);
      return sign | ((leading + 118u) << 23u) |
          ((mantissa << (23u - leading)) & 0x7fffffu);
    }
    inline uint hyle_f32_to_e4(uint bits) {
      const uint sign = (bits >> 24u) & 128u, magnitude = bits & 0x7fffffffu;
      if (magnitude > 0x7f800000u) return sign | 127u;
      if (magnitude >= 0x43e00000u) return sign | 126u;
      const int exponent = int(magnitude >> 23u) - 120;
      uint high, remainder, midpoint;
      if (exponent >= 1) {
        high = (uint(exponent) << 3u) | ((magnitude >> 20u) & 7u);
        remainder = magnitude & 0xfffffu; midpoint = 0x80000u;
      } else {
        const uint shift = uint(1 - exponent);
        if (shift > 4u) return sign;
        const uint significand = (magnitude & 0x7fffffu) | 0x800000u;
        const uint drop = 20u + shift;
        high = significand >> drop;
        remainder = significand & ((1u << drop) - 1u);
        midpoint = 1u << (drop - 1u);
      }
      high += uint(remainder > midpoint || (remainder == midpoint && (high & 1u) != 0u));
      return sign | min(high, 126u);
    }
  )METAL";
}
Result<std::array<int, 2>> grid(std::uint64_t groups) noexcept {
  const auto x = (std::min)(groups, std::uint64_t{65535});
  const auto y = groups / x + (groups % x != 0);
  if (y > static_cast<std::uint64_t>((std::numeric_limits<int>::max)()))
    return std::unexpected(Status::OutOfRange("Apple static FP8 grid exceeds native int axes"));
  return std::array{static_cast<int>(x), static_cast<int>(y)};
}
Status carriers(std::span<const TensorDesc> descriptions, std::span<const mx::array> inputs) {
  if (inputs.size() != descriptions.size())
    return Status::InvalidArgument("Apple static FP8 carrier count differs");
  for (std::size_t i = 0; i < inputs.size(); ++i) {
    HYLE_ASSIGN_OR_RETURN(auto spec, input_spec(descriptions[i]));
    if (inputs[i].dtype() != spec.dtype || inputs[i].shape() != spec.shape)
      return Status::InvalidArgument("Apple static FP8 carrier differs from logical storage");
  }
  return Status::Ok();
}
} // namespace

bool is_mlx_float8_cast(const Operation &operation, std::span<const TensorDesc> in) noexcept {
  const auto *cast = operation.get_if<Cast>();
  return cast && in.size() == 1 && in[0].is_plain() &&
      ((in[0].data_type() == DataType::kFloat8E4M3FN && floating(cast->output_type)) ||
       (floating(in[0].data_type()) && cast->output_type == DataType::kFloat8E4M3FN));
}

Result<std::vector<mx::array>> lower_float8_cast(const Operation &operation,
    std::span<const TensorDesc> descriptions, std::span<const mx::array> inputs, mx::Stream stream) {
  if (!is_mlx_float8_cast(operation, descriptions) || stream.device.type != mx::Device::gpu)
    return std::unexpected(Status::Unimplemented("Apple E4M3 storage Cast requires a floating bridge"));
  HYLE_RETURN_IF_ERROR(carriers(descriptions, inputs));
  HYLE_ASSIGN_OR_RETURN(auto output, infer_single_output(operation, descriptions));
  HYLE_ASSIGN_OR_RETURN(auto spec, input_spec(output));
  HYLE_ASSIGN_OR_RETURN(auto count, output.element_count());
  if (!count) return std::vector{mx::zeros(spec.shape, spec.dtype, stream)};
  if (count > static_cast<std::uint64_t>((std::numeric_limits<int>::max)()))
    return std::unexpected(Status::OutOfRange("Apple E4M3 Cast exceeds the native flat axis"));
  HYLE_ASSIGN_OR_RETURN(auto shape, grid(count / 256 + (count % 256 != 0)));
  const auto src = descriptions[0].data_type(), dst = output.data_type();
  auto raw = mx::reshape(mx::view(inputs[0], raw_type(src), stream), {-1}, stream);
  static const auto header = kernel_header();
  static const auto kernel = mx::fast::metal_kernel("hyle_plain_e4m3_storage_cast",
      {"source"}, {"out"}, R"METAL(
    const ulong index = ulong(thread_position_in_grid.y) * GROUPS_X * 256 + thread_position_in_grid.x;
    if (index >= ulong(source_shape[0])) return;
    const uint bits = ENCODE ? hyle_ct_widen(uint(source[index]), SOURCE_TYPE)
                             : hyle_e4_to_f32(uint(source[index]));
    out[index] = OutType(ENCODE ? hyle_f32_to_e4(bits) : hyle_ct_narrow(bits, DEST_TYPE));
  )METAL", header, false, false, mx::CompileOptions{});
  auto values = kernel({raw}, {spec.shape}, {raw_type(dst)}, {shape[0]*256,shape[1],1},
      {256,1,1}, {{"GROUPS_X",shape[0]}, {"ENCODE",dst == DataType::kFloat8E4M3FN},
       {"SOURCE_TYPE",scalar_tag(src)}, {"DEST_TYPE",scalar_tag(dst)},
       {"OutType",raw_type(dst)}}, std::nullopt, false, stream);
  return std::vector{mx::view(values[0], native_type(dst), stream)};
}

Result<std::vector<mx::array>> lower_static_fp8(
    const packed::internal::StaticFloat8Linear &operation,
    std::span<const TensorDesc> descriptions, std::span<const mx::array> inputs, mx::Stream stream) {
  std::array<TensorDesc,1> output;
  HYLE_RETURN_IF_ERROR(operation.infer_output_descriptions(descriptions, output));
  if (stream.device.type != mx::Device::gpu)
    return std::unexpected(Status::InvalidArgument("Apple static FP8 linear requires the native GPU"));
  HYLE_RETURN_IF_ERROR(carriers(descriptions, inputs));
  const auto rows = static_cast<int>(descriptions[0].dimensions()[0]);
  const auto columns = static_cast<int>(output[0].dimensions()[1]);
  const auto items = std::uint64_t(rows) * columns;
  HYLE_ASSIGN_OR_RETURN(auto shape, grid(items / 4 + (items % 4 != 0)));
  auto a = mx::view(inputs[0],raw_type(descriptions[0].data_type()),stream);
  // Scalar raw storage must remain a one-element array rather than a Metal scalar parameter.
  auto sa = mx::reshape(mx::view(inputs[2],mx::uint32,stream),{1},stream);
  auto sw = mx::reshape(mx::view(inputs[3],mx::uint32,stream),{1},stream);
  static const auto header = kernel_header();
  static const auto kernel = mx::fast::metal_kernel("hyle_static_fp8_reference_linear",
      {"a","w","sa","sw"},{"out"}, R"METAL(
    const uint lane = thread_index_in_simdgroup, subgroup = simdgroup_index_in_threadgroup;
    const ulong group = ulong(threadgroup_position_in_grid.y) * GROUPS_X + threadgroup_position_in_grid.x;
    const ulong index = group * 4 + subgroup, columns = w_shape[0], depth = w_shape[1];
    threadgroup uint reciprocal;
    if (thread_index_in_threadgroup == 0) reciprocal = hyle_f32_div(0x3f800000u,sa[0]);
    threadgroup_barrier(mem_flags::mem_threadgroup);
    if (index >= ulong(a_shape[0]) * columns) return;
    const ulong row = index / columns, column = index % columns;
    float total = 0.0f;
    for (ulong k = lane; k < depth; k += 32) {
      const uint value = hyle_ct_widen(uint(a[row*a_strides[0]+k*a_strides[1]]),A_TYPE);
      const uint normalized = hyle_f32_mul(value,reciprocal);
      const uint code = hyle_f32_to_e4(normalized);
      const uint weight = hyle_e4_to_f32(uint(w[column*w_strides[0]+k*w_strides[1]]));
      // Finite E4 values are multiples of2^-9, so all finite products and
      // intermediate nonzero sums stay above the F32 subnormal range.
      const float product = as_type<float>(hyle_e4_to_f32(code)) * as_type<float>(weight);
      total = total + product;
    }
    for (ushort distance=16; distance>0; distance/=2)
      total = total + simd_shuffle_down(total,distance);
    if (lane == 0) {
      const uint scaled_a = hyle_f32_mul(as_type<uint>(total),sa[0]);
      const uint scaled_w = hyle_f32_mul(scaled_a,sw[0]);
      out[index] = OutType(hyle_ct_narrow(scaled_w,OUTPUT_TYPE));
    }
  )METAL", header, false, false, mx::CompileOptions{});
  auto values = kernel({a,inputs[1],sa,sw}, {{rows,columns}}, {raw_type(operation.output_type)},
      {shape[0]*128,shape[1],1}, {128,1,1}, {{"GROUPS_X",shape[0]},
       {"A_TYPE",scalar_tag(descriptions[0].data_type())},
       {"OUTPUT_TYPE",scalar_tag(operation.output_type)}, {"OutType",raw_type(operation.output_type)}},
      std::nullopt,false,stream);
  return std::vector{mx::view(values[0],native_type(operation.output_type),stream)};
}
} // namespace hyle::compute::apple::detail
