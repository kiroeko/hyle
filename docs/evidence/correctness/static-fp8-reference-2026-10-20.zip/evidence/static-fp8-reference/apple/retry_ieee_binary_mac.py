"""Refresh only the generic scalar-F32 IEEE bridge, retaining the actual red test object."""
from pathlib import Path
import base64
import json
import subprocess

S=Path(__file__).resolve().parent
R=json.loads((S/"mac/plan.json").read_text(encoding="utf-8"))["remote"]
files=["src/compute_route_apple/"+n for n in ["apple_static_fp8.cc","apple_static_fp8.h","apple_operations.cc","apple_mature_float.cc"]]
payload=dict(remote=R,files=[dict(path=p,data=base64.b64encode(Path(p).read_bytes()).decode())for p in files])
code=r'''
from pathlib import Path
import base64,hashlib,json,subprocess,time,shlex,xml.etree.ElementTree as E,sys,concurrent.futures
p=json.load(sys.stdin);base=Path(p['remote']);r=base/'ieee-binary-v2';r.mkdir(exist_ok=True)
o=r/'results';o.mkdir(exist_ok=True);(r/'objects').mkdir(exist_ok=True)
assert not(o/'compile-summary.json').exists()
def read(p):return json.loads(p.read_text())
def save(n,v):(o/n).write_text(json.dumps(v,indent=2)+'\n')
def ident(p):
 p=Path(p);b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def execute(n,c):
 save(n+'.command.json',dict(argv=c));t=time.time();q=subprocess.run(c,cwd=r,capture_output=True,text=True)
 (o/(n+'.stdout.log')).write_text(q.stdout);(o/(n+'.stderr.log')).write_text(q.stderr)
 save(n+'.result.json',dict(exit=q.returncode,seconds=time.time()-t));print(n,q.returncode,flush=True);return q.returncode
manifest=[]
for row in p['files']:
 q=r/row['path'];q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(base64.b64decode(row['data']));manifest.append(ident(q))
save('source-manifest.json',manifest)
rows=read(base/'results/compile-summary.json')['compiles']
sources=[x for x in rows if Path(x['source']['path']).name in ['apple_static_fp8.cc','apple_operations.cc','apple_mature_float.cc']];assert len(sources)==3
def compile_one(old):
 rel=old['source']['path'].split('/static-fp8-reference/apple/',1)[1];source=r/rel;tag=rel.replace('/','--');obj=r/'objects'/(tag+'.o');dep=Path(str(obj)+'.d');cmd=old['argv'].copy()
 for flag in ['-MF','-MT','-MQ']:
  while flag in cmd:
   i=cmd.index(flag);del cmd[i:i+2]
 cmd=[x for x in cmd if x not in ['-MD','-MMD']];cmd[cmd.index('-c')+1]=str(source);cmd[cmd.index('-o')+1]=str(obj)
 cmd[1:1]=['-I'+str(r/'src/compute_route_apple'),'-I'+str(r)];cmd+=['-MD','-MF',str(dep)]
 exit=execute(tag+'-compile',cmd);record=dict(argv=cmd,source=ident(source),old_object=old['object'],exit=exit)
 if exit:save(tag+'-identity.json',record);return record
 deps=[ident(x)for x in dict.fromkeys(shlex.split(dep.read_text().split(': ',1)[1].replace('\\\n',' ')))]
 record.update(object=ident(obj),dependencies=deps);save(tag+'-identity.json',record);return record
with concurrent.futures.ThreadPoolExecutor(max_workers=2)as pool:compiled=list(pool.map(compile_one,sources))
save('compile-summary.json',dict(compiles=compiled))
if any(x['exit']for x in compiled):sys.exit(1)
cmd=read(base/'probe/results/link.command.json')['argv']
for x in compiled:
 assert cmd.count(x['old_object'])==1;cmd[cmd.index(x['old_object'])]=x['object']['path']
image=r/'static-fp8-reference';cmd[cmd.index('-o')+1]=str(image);cmd=[('-Wl,-map,'+str(image)+'.map')if x.startswith('-Wl,-map,')else x for x in cmd]
save('link-inputs.json',[ident(x)for x in cmd if Path(x).is_file()and Path(x).suffix in ['.o','.a','.dylib']])
red=read(base/'probe/results/test-identity.json')['object'];assert ident(red['path'])==red
save('same-red-test-object.json',dict(red=red,after=ident(red['path']),equal=True))
if execute('link',cmd):sys.exit(2)
(r/'mlx.metallib').symlink_to((base/'mlx.metallib').resolve())
exit=execute('run',[str(image),'--gtest_filter=AppleStaticFloat8ReferenceGraph.*:AppleFloatingStorage.*:AppleGptqReferenceGraph.*:AppleCtPackedLinear.*','--gtest_output=xml:'+str(o/'tests.xml')])
cases=E.parse(o/'tests.xml').findall('.//testcase')
save('validation.json',dict(exit=exit,image=ident(image),tests=len(cases),failed=sum(bool(x.findall('failure'))for x in cases),skipped=sum(bool(x.findall('skipped'))for x in cases),names=[x.get('classname')+'.'+x.get('name')for x in cases],properties=[{p.get('name'):p.get('value')for p in x.findall('./properties/property')}for x in cases]))
print('VALIDATION',len(cases),'fail',sum(bool(x.findall('failure'))for x in cases),flush=True);sys.exit(exit)
'''
cmd=["ssh","-o","BatchMode=yes","kiro@172.22.10.198",'python3 -c "import base64;exec(base64.b64decode(\''+base64.b64encode(code.encode()).decode()+'\'))"']
(S/'retry-ieee-command.json').write_text(json.dumps(cmd,indent=2)+'\n',encoding='utf-8')
result=subprocess.run(cmd,input=json.dumps(payload).encode(),capture_output=True)
(S/'retry-ieee.stdout.log').write_bytes(result.stdout);(S/'retry-ieee.stderr.log').write_bytes(result.stderr)
print(result.stdout.decode(),result.stderr.decode());raise SystemExit(result.returncode)
