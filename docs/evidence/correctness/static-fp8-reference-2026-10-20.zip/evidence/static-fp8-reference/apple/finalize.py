"""Bounded summary from retained actual Metal receipts; no new compilation or execution."""
from pathlib import Path
import hashlib
import json
import xml.etree.ElementTree as E

S=Path(__file__).resolve().parent
ROOT=S.parents[3]
R=S/"mac/remote"
V=R/"ieee-binary-v2/results"

def read(p):return json.loads(Path(p).read_text(encoding="utf-8"))
def identity(p):
    p=Path(p);b=p.read_bytes()
    return dict(path=p.relative_to(ROOT).as_posix(),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())

freeze=read(S/"source-freeze.json")
for row in freeze["files"]+freeze["common_read_basis_not_owned"]:
    now=identity(ROOT/row["path"])
    assert (now["bytes"],now["sha256"])==(row["bytes"],row["sha256"]),row["path"]
first=read(R/"results/compile-summary.json")["compiles"]
last=read(V/"compile-summary.json")["compiles"]
assert len(first)==6 and len(last)==3
assert all(x["exit"]==0 for x in first+last)
assert read(R/"probe/results/compile.result.json")["exit"]==0
tests=E.parse(V/"tests.xml").findall(".//testcase")
assert len(tests)==11 and not any(x.findall(t) for x in tests for t in ["failure","error","skipped"])
for folder in [R/"results",R/"probe/results",V]:assert read(folder/"link.result.json")["exit"]==0
assert read(V/"run.result.json")["exit"]==0
before=read(R/"probe/results/validation.json")
assert before["tests"]==before["failed"]==1 and before["skipped"]==0
assert before["properties"][0]["mul0_f32_bits"]=="0" and before["properties"][0]["cast_direct_bf16_bits"]=="8"
assert read(V/"same-red-test-object.json")["equal"] is True
actual=read(V/"validation.json")
assert actual["properties"][3]["mul0_f32_bits"]=="524288"
assert actual["properties"][3]["cast_product0_bf16_bits"]=="8"
inputs=read(V/"link-inputs.json");assert len(inputs)==155
report=dict(
    status="passed_bounded_Apple_static_FP8_reference_and_generic_F32_scalar_FTZ_correction",
    source_freeze=identity(S/"source-freeze.json"),
    original_source_freeze=identity(S/"source-freeze-first.json"),
    hardware=read(R/"hardware.json"),
    final=dict(validation=identity(V/"validation.json"),xml=identity(V/"tests.xml"),
        stdout=identity(V/"run.stdout.log"),stderr=identity(V/"run.stderr.log"),
        link_command=identity(V/"link.command.json"),link_inputs=identity(V/"link-inputs.json"),
        same_red_test_object=identity(V/"same-red-test-object.json"),
        image=actual["image"],actual_input_count=155,
        cases=[dict(name=x.get("classname")+"."+x.get("name"),
            properties={p.get("name"):p.get("value") for p in x.findall("./properties/property")})for x in tests]),
    counts=dict(initial_product_CXX=5,initial_test_CXX=1,probe_test_CXX=1,
        correction_product_CXX=3,total_CXX_processes=10,CXX_failures=0,
        link_processes=3,link_failures=0,test_processes=3,
        initial_tests=10,initial_failed=1,probe_tests=1,probe_failed=1,
        final_passed=11,final_failed=0,final_skipped=0,
        final_static_cases=3,final_generic_scalar_case=1,final_GPTQ_neighbors=3,final_CT_neighbors=4,
        static_lifetime_submissions=16,static_runtime_success=22,static_escape_submissions=7,
        SDK_builds=0,SDK_copies=0,NVCC=0,Windows_GPU=0),
    actual_failure_and_correction=dict(
        first_failure=identity(R/"results/tests.xml"),
        probe=identity(R/"probe/results/validation.json"),
        cause="Original scalar-broadcast F32 Multiply produced raw F32 zeros from1/2 times0x00080000. Direct original F32->BF16 Cast produced0x0008 correctly, isolating arithmetic FTZ rather than storage conversion.",
        change="Generic plain-dense F32 Multiply/Divide with a scalar[]/[1] operand uses an original MLX native kernel bridge. Normal finite nonzero multiplication keeps one hardware F32 multiply; subnormal/zero/nonfinite/overflow paths use shared bit-defined helpers. Division is strict F32. Other shapes/dtypes retain original fallback; no static-model detection in arithmetic.",
        unchanged="Shared fixture dc298ec180013d0af1ec97d8a3f19d1f42e1c8467776e50d8721422ecab903f4 and original BF16 storage Cast remained unchanged. Same actual red test object reused for final green.",
        final_storage_bits=actual["properties"][3]),
    implementation=dict(
        Cast="Logical plain E4M3FN<->F32/F16/BF16 storage bridge with signed zeros, NaN sign/class and SATFINITE nearest-even; no arbitrary FP8 arithmetic admission.",
        bounded="Original A/W/SA/SW; strict F32 reciprocal and normalize -> E4 code -> F32 code-dot -> separate strict *SA then*SW -> output RNE. Reads originalW; no MK/NK temporary decoded bank or new executor.",
        cold="Shared12-node StaticFloat8Pattern and publication/control/reader closure. Apple route5 is distinct from old paged2/ragged3/artifact4; default ordinary200 and bounded candidate201 retained.",
        source_overlay=dict(files=131,bytes=1065513,base_inputs_hash_checked=153,
            retry="Only4 small current source/header payloads sent into fixed same-workspace ieee-binary-v2; no SDK/cache copies.")),
    limits=[
        "No full publisher artifact payload/importer/model quality/performance or TensorCore scaled-mm equivalence claim.",
        "Mac16,12 Apple M4 only; no Linux/Windows GPU run by this task.",
        "Direct F16/BF16<->E4 Cast variants use the same bit helper but were not separately subjected to a full dtype/layout matrix; actual ordinary graph exercises the F32 bridge and typed leaf profiles exercise three activation/output types.",
        "Plain E4 Cast retains native int flat-axis bound; scalar IEEE bridge is explicitly dense F32 with one scalar operand. Other numerical operations/layouts preserve the previous provider behavior.",
        "Native F32 dot reduction tree is backend-specific; selected sparse independent oracle avoids asserting identical sums for arbitrary reduction trees.",
        "Opaque native MLX allocations stay unknown; no physical peak-memory or throughput improvement is inferred.",
        "Initial failed process, one isolating public scalar probe and final full focused process are separate evidence; results are not pooled to conceal failures."],
    retained="All actual commands, input/source/dependency/object identities, first red sources/logs/XML and current objects are retained in the fixed Hyle workspace. No deletion or test.ps1 mutation performed.")
p=S/"final-validation.json";p.write_text(json.dumps(report,indent=2)+"\n",encoding="utf-8")
print(json.dumps(dict(report=identity(p),counts=report["counts"])))
