"""One public scalar-Mul/storage-Cast witness on the unchanged first Metal image closure."""
from pathlib import Path
import base64
import json
import subprocess

S=Path(__file__).resolve().parent
R=json.loads((S/"mac/plan.json").read_text(encoding="utf-8"))["remote"]
test="tests/graph_route_apple/static_fp8_reference_test.cc"
payload=dict(remote=R,source=base64.b64encode(Path(test).read_bytes()).decode())
code=r'''
from pathlib import Path
import base64,hashlib,json,subprocess,time,shlex,xml.etree.ElementTree as E,sys
p=json.load(sys.stdin);base=Path(p['remote']);r=base/'probe';r.mkdir(exist_ok=True)
o=r/'results';o.mkdir(exist_ok=True)
assert not(o/'compile.result.json').exists()
source=r/'tests/graph_route_apple/static_fp8_reference_test.cc';source.parent.mkdir(parents=True,exist_ok=True);source.write_bytes(base64.b64decode(p['source']))
def read(p):return json.loads(p.read_text())
def save(n,v):(o/n).write_text(json.dumps(v,indent=2)+'\n')
def ident(p):
 p=Path(p);b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def execute(n,c):
 save(n+'.command.json',dict(argv=c));t=time.time();q=subprocess.run(c,cwd=r,capture_output=True,text=True)
 (o/(n+'.stdout.log')).write_text(q.stdout);(o/(n+'.stderr.log')).write_text(q.stderr)
 save(n+'.result.json',dict(exit=q.returncode,seconds=time.time()-t));print(n,q.returncode,flush=True);return q.returncode
rows=read(base/'results/compile-summary.json')['compiles'];old=next(x for x in rows if x['source']['path'].endswith('/'+str(source.relative_to(r))))
obj=r/'static_fp8_test.o';dep=r/'static_fp8_test.d';cmd=old['argv'].copy()
for flag in ['-MF','-MT','-MQ']:
 while flag in cmd:
  i=cmd.index(flag);del cmd[i:i+2]
cmd=[x for x in cmd if x not in ['-MD','-MMD']];cmd[cmd.index('-c')+1]=str(source);cmd[cmd.index('-o')+1]=str(obj)
cmd[1:1]=['-I'+str(base/'tests/graph_route_apple')];cmd+=['-MD','-MF',str(dep)]
if execute('compile',cmd):sys.exit(1)
deps=[ident(x)for x in dict.fromkeys(shlex.split(dep.read_text().split(': ',1)[1].replace('\\\n',' ')))]
save('test-identity.json',dict(source=ident(source),object=ident(obj),argv=cmd,dependencies=deps))
cmd=read(base/'results/link.command.json')['argv'];assert cmd.count(old['object'])==1;cmd[cmd.index(old['object'])]=str(obj)
image=r/'ieee-before';cmd[cmd.index('-o')+1]=str(image);cmd=[('-Wl,-map,'+str(image)+'.map')if x.startswith('-Wl,-map,')else x for x in cmd]
save('link-inputs.json',[ident(x)for x in cmd if Path(x).is_file()and Path(x).suffix in ['.o','.a','.dylib']])
if execute('link',cmd):sys.exit(2)
(r/'mlx.metallib').symlink_to((base/'mlx.metallib').resolve())
exit=execute('run',[str(image),'--gtest_filter=AppleFloatingStorage.*','--gtest_output=xml:'+str(o/'tests.xml')])
cases=E.parse(o/'tests.xml').findall('.//testcase')
save('validation.json',dict(exit=exit,image=ident(image),tests=len(cases),failed=sum(bool(x.findall('failure'))for x in cases),skipped=sum(bool(x.findall('skipped'))for x in cases),properties=[{p.get('name'):p.get('value')for p in x.findall('./properties/property')}for x in cases]))
sys.exit(exit)
'''
cmd=["ssh","-o","BatchMode=yes","kiro@172.22.10.198",'python3 -c "import base64;exec(base64.b64decode(\''+base64.b64encode(code.encode()).decode()+'\'))"']
(S/'probe-command.json').write_text(json.dumps(cmd,indent=2)+'\n',encoding='utf-8')
result=subprocess.run(cmd,input=json.dumps(payload).encode(),capture_output=True)
(S/'probe.stdout.log').write_bytes(result.stdout);(S/'probe.stderr.log').write_bytes(result.stderr)
print(result.stdout.decode(),result.stderr.decode());raise SystemExit(result.returncode)
