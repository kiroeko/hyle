#pragma once

#include "hyle/graph/region_provider.h"
#include "hyle/container/small_vector.h"
#include "../compute/provider_internal.h"
#include "../compute_packed_shared/artifact_packed_linear.h"
#include "mapped_native_region.h"
#include "closed_region.h"

#include <algorithm>
#include <array>
#include <limits>
#include <optional>

namespace hyle::graph::detail {
namespace c = compute;
namespace native = c::packed::internal;

// The exact public recipe and reader/control proof are shared by provider
// regions and native graph lowerers; neither needs a second discovery policy.
struct ArtifactPackedPattern : ClosedRegionPattern {
inline static constexpr c::RoutePolicyId kPolicy{0x48594c454354504cULL, 1, 1};
inline static constexpr std::size_t kMaxNodes = 4;
inline static constexpr std::size_t kMaxInputs = 5;

struct Pattern final {
  std::array<NodeId, kMaxNodes> nodes{};
  std::size_t size = 0;
  std::array<ValueId, kMaxInputs> inputs{}; // Original A,codes[,Z],scale[,group index].
  std::size_t input_count = 0;
  ValueId output{};
  native::ArtifactPackedLinear descriptor{};
  std::span<const NodeId> span() const noexcept { return {nodes.data(), size}; }
  bool contains(NodeId node) const noexcept {
    return std::ranges::find(span(), node) != span().end();
  }
  void append(NodeId node) noexcept { nodes[size++] = node; }
  std::size_t boundary_count() const noexcept {
    std::size_t count = 0;
    for (std::size_t n = 0; n < input_count; ++n) {
      const auto prefix = std::span(inputs).first(n);
      count += std::ranges::find(prefix, inputs[n]) == prefix.end();
    }
    return count;
  }
  c::Operation composite() const noexcept { return c::Operation::custom(descriptor); }
};

static bool pattern(const Graph &graph, NodeId matrix, Pattern &p) noexcept {
  const auto mm = operation<c::MatMul>(graph, matrix);
  if (!mm || !arity(graph, matrix, 2) || mm->accumulation_type != c::DataType::kFloat32)
    return false;
  const auto activation = graph.node_input(matrix, 0).value();
  const auto weight = graph.node_input(matrix, 1).value();
  const auto operand = graph.value_description(weight);
  if (!operand || operand->rank() != 2) return false;

  auto value = weight;
  NodeId after_cast;
  auto node = producer(graph, value);
  if (operation<c::Cast>(graph, node)) {
    if (!arity(graph, node, 1)) return false;
    after_cast = node;
    value = graph.node_input(node, 0).value();
  }
  const auto transpose = producer(graph, value);
  const auto view = operation<c::View>(graph, transpose);
  if (!view || !arity(graph, transpose, 1) || view->kind() != c::ViewKind::kPermute)
    return false;
  const auto axes = view->permutation();
  if (axes.size() != 2 || (axes[0] != 1 && axes[0] != -1) ||
      (axes[1] != 0 && axes[1] != -2)) return false;
  value = graph.node_input(transpose, 0).value();
  const auto before_view = graph.value_description(value);
  const auto after_view = graph.value_description(graph.result(transpose).value());
  if (!before_view || !after_view || before_view->rank() != 2) return false;
  const auto expected_view = before_view->transposed();
  if (!expected_view || *expected_view != *after_view) return false;

  NodeId before_cast;
  node = producer(graph, value);
  if (operation<c::Cast>(graph, node)) {
    if (after_cast.valid() || !arity(graph, node, 1)) return false;
    before_cast = node;
    value = graph.node_input(node, 0).value();
  }
  const auto decode = producer(graph, value);
  if (!decode.valid()) return false;
  const auto decode_operation = graph.operation(decode);
  if (!decode_operation) return false;
  const auto artifact = decode_operation->custom_as<c::model_ops::ArtifactWeightDecode>();
  if (!artifact ||
      (artifact->format != c::model_ops::WeightArtifactFormat::kCompressedTensorsSymmetric4 &&
       artifact->format != c::model_ops::WeightArtifactFormat::kCompressedTensorsAsymmetric4 &&
       artifact->format != c::model_ops::WeightArtifactFormat::kGptqV1Int4))
    return false;
  const auto count = artifact->operation_traits().inputs.minimum;
  if (!arity(graph, decode, count)) return false;
  const auto decoded = graph.value_description(value);
  if (!decoded || decoded->rank() != 2) return false;
  p.descriptor = {artifact->format, artifact->group_size, decoded->data_type(), operand->data_type()};
  p.inputs[0] = activation;
  p.input_count = std::size_t(count) + 1;
  for (std::size_t n = 0; n < count; ++n)
    p.inputs[n + 1] = graph.node_input(decode, n).value();
  p.output = graph.result(matrix).value();
  p.append(decode);
  if (before_cast.valid()) p.append(before_cast);
  p.append(transpose);
  if (after_cast.valid()) p.append(after_cast);
  p.append(matrix);
  std::ranges::sort(std::span(p.nodes).first(p.size), {}, &NodeId::ordinal);
  return true;
}
// Only the chosen bounded node set is reconstructed here. Graph's exact
// boundary/contractibility check preserves escapes; discovery checked readers.
static Status qualify(const RegionCompileRequest &request, Pattern &result) noexcept {
  if (!request.graph || request.route != 1 || request.outputs.size() != 1 ||
      request.nodes.size() < 3 || request.nodes.size() > kMaxNodes ||
      request.has_unknown_effects || !request.effect_accesses.empty())
    return Status::Unimplemented("packed artifact region boundary differs");
  for (const auto node : request.nodes) {
    Pattern p;
    if (!pattern(*request.graph, node, p) || p.size != request.nodes.size() ||
        p.output != request.outputs[0] || p.boundary_count() != request.inputs.size()) continue;
    const auto logical_inputs = std::span(p.inputs).first(p.input_count);
    if (!std::ranges::all_of(p.span(), [&](NodeId id) {
          return std::ranges::count(request.nodes, id) == 1;
        }) || !std::ranges::all_of(logical_inputs, [&](ValueId id) {
          return std::ranges::count(request.inputs, id) == 1;
        })) continue;
    result = p;
    return Status::Ok();
  }
  return Status::Unimplemented("packed artifact region does not preserve the exact public recipe");
}
};

// Bind discovery to an existing provider without replacing its context,
// resources, prepared operation or submit path.
template <const c::detail::ProviderVTable &(*Original)() noexcept>
struct ArtifactPackedRegion final : ArtifactPackedPattern {
static const c::detail::ProviderVTable &original() noexcept { return Original(); }

static Status native_proposal(void *context, const Graph &graph, const Pattern &p,
    std::array<c::TensorDesc, kMaxInputs> &inputs, c::TensorDesc &output,
    std::array<c::detail::ResourceBindingRequirement, kMaxInputs> &requirements,
    c::detail::ResourceBindingRequirement &destination,
    c::detail::ProviderOperationProposal &proposal, const c::WorkloadContext &workload = {}) noexcept {
  for (std::size_t n = 0; n < p.input_count; ++n)
    inputs[n] = graph.value_description(p.inputs[n]).value();
  output = graph.value_description(p.output).value();
  std::array<c::TensorDesc, 1> inferred;
  const auto op = p.composite();
  HYLE_RETURN_IF_ERROR(c::infer_output_descriptions(op, std::span(inputs).first(p.input_count), inferred));
  if (inferred[0] != output)
    return Status::Unimplemented("packed artifact composite output differs from the public graph");
  HYLE_RETURN_IF_ERROR(original().propose(context,
      {.operation = op, .inputs = std::span(inputs).first(p.input_count),
       .outputs = std::span(&output, 1), .workload = workload},
      std::span(requirements).first(p.input_count), std::span(&destination, 1), &proposal));
  if (proposal.cost.persistent_bytes) {
    HYLE_ASSIGN_OR_RETURN(auto bytes, mapped_native_region::artifact_bytes(p.input_count, 1));
    if (*proposal.cost.persistent_bytes > SIZE_MAX - bytes)
      return Status::OutOfRange("packed artifact region metadata bytes overflow");
    *proposal.cost.persistent_bytes += bytes;
  }
  return Status::Ok();
}
static Status propose(void *context, const RegionDiscoveryRequest &request,
    mem::AllocatorRef allocator, RegionProposalWriter &writer) noexcept {
  const auto &graph = request.graph;
  if (!request.allowed_nodes.empty() && request.allowed_nodes.size() != graph.node_count())
    return Status::InvalidArgument("packed artifact allowed-node count differs");
  Uses uses(allocator);
  HYLE_RETURN_IF_ERROR(uses.initialize(graph));
  for (std::size_t i = 0; i < graph.node_count(); ++i) {
    HYLE_ASSIGN_OR_RETURN(auto node, graph.node_id(i));
    Pattern p;
    if (!pattern(graph, node, p) || !closed(graph, p, uses, request.allowed_nodes)) continue;
    std::array<c::TensorDesc, kMaxInputs> inputs;
    c::TensorDesc output;
    std::array<c::detail::ResourceBindingRequirement, kMaxInputs> requirements;
    c::detail::ResourceBindingRequirement destination;
    c::detail::ProviderOperationProposal proposal;
    const auto status = native_proposal(context, graph, p, inputs, output, requirements, destination, proposal);
    if (!status.ok()) {
      if (status.IsUnimplemented() || status.IsInvalidArgument()) continue;
      return status;
    }
    HYLE_ASSIGN_OR_RETURN(auto more, writer.try_add({.nodes = p.span(), .cost = proposal.cost,
        .route = 1, .replay_class = proposal.runtime.replay_class,
        .implementation = c::ProviderImplementationId{1}, .policy = kPolicy,
        .preference = proposal.preference == (std::numeric_limits<std::uint32_t>::max)()
            ? 200 : proposal.preference}));
    if (!more) return Status::Ok();
  }
  return Status::Ok();
}

static bool same_requirement(const c::ResourceRequirement &a, const c::ResourceRequirement &b) noexcept {
  return a.required_properties == b.required_properties && a.forbidden_properties == b.forbidden_properties &&
      a.minimum_alignment == b.minimum_alignment && a.exact_resource == b.exact_resource &&
      a.exact_domain == b.exact_domain && a.requires_exact_domain == b.requires_exact_domain;
}
static Status resources(void *context, const RegionCompileRequest &request, mem::AllocatorRef,
    std::span<RegionInputRequirement> inputs, std::span<RegionOutputRequirement> outputs,
    RegionResourceProposal *result) noexcept {
  *result = {};
  Pattern p;
  HYLE_RETURN_IF_ERROR(qualify(request, p));
  if (inputs.size() != request.inputs.size() || outputs.size() != 1)
    return Status::InvalidArgument("packed artifact resource count differs");
  std::array<c::TensorDesc, kMaxInputs> descriptions;
  c::TensorDesc output;
  std::array<c::detail::ResourceBindingRequirement, kMaxInputs> requirements;
  c::detail::ResourceBindingRequirement destination;
  c::detail::ProviderOperationProposal proposal;
  HYLE_RETURN_IF_ERROR(native_proposal(context, *request.graph, p, descriptions, output,
      requirements, destination, proposal, request.workload));
  const auto logical_inputs = std::span(p.inputs).first(p.input_count);
  for (std::size_t port = 0; port < request.inputs.size(); ++port) {
    const auto first = std::size_t(std::ranges::find(
        logical_inputs, request.inputs[port]) - logical_inputs.begin());
    for (std::size_t n = first + 1; n < p.input_count; ++n)
      if (p.inputs[n] == request.inputs[port] && !same_requirement(requirements[first], requirements[n]))
        return Status::Unimplemented("packed artifact shared port has different native resource requirements");
    inputs[port] = {.resource = requirements[first]};
  }
  outputs[0] = {.resource = destination};
  *result = {.runtime = proposal.runtime, .workspace_resource = proposal.workspace_resource,
      .compilation_storage = proposal.cost.compilation_storage};
  return Status::Ok();
}

static c::ProviderPrepareOutcome compile(void *context, const RegionCompileRequest &request,
    mem::AllocatorRef allocator, ProviderRegionPrepared *result) noexcept {
  *result = {};
  Pattern p;
  const auto qualification = qualify(request, p);
  if (!qualification.ok()) return c::ProviderPrepareOutcome::unsupported(qualification);
  if (request.input_resources.size() != request.inputs.size() || request.output_resources.size() != 1)
    return c::ProviderPrepareOutcome::error(Status::InvalidArgument("packed artifact physical resource count differs"));
  std::array<c::TensorDesc, kMaxInputs> inputs;
  c::TensorDesc output;
  std::array<c::detail::ResourceBindingRequirement, kMaxInputs> requirements;
  c::detail::ResourceBindingRequirement destination;
  c::detail::ProviderOperationProposal proposal;
  const auto status = native_proposal(context, *request.graph, p, inputs, output,
      requirements, destination, proposal, request.workload);
  if (!status.ok()) return status.IsUnimplemented() ? c::ProviderPrepareOutcome::unsupported(status)
                                                  : c::ProviderPrepareOutcome::error(status);
  std::array<std::size_t, kMaxInputs> ports;
  std::array<mem::MemoryResourceRef, kMaxInputs> resources;
  for (std::size_t n = 0; n < p.input_count; ++n) {
    ports[n] = std::size_t(std::ranges::find(request.inputs, p.inputs[n]) - request.inputs.begin());
    resources[n] = request.input_resources[ports[n]];
  }
  return mapped_native_region::prepare(original(), context,
      {.operation = p.composite(), .inputs = std::span(inputs).first(p.input_count),
       .outputs = std::span(&output, 1), .input_resources = std::span(resources).first(p.input_count),
       .output_resources = request.output_resources, .workspace_resource = request.workspace_resource,
       .route = proposal.route, .workload = request.workload}, proposal,
      std::span(ports).first(p.input_count), request.inputs.size(), allocator, result);
}
inline static const RegionProviderVTable kRegion{.propose = &propose, .propose_resources = &resources, .compile = &compile};
static const void *query_extension(void *context, c::ProviderExtensionId id) noexcept {
  if (id == kRegionProviderExtensionId) return &kRegion;
  return original().query_extension ? original().query_extension(context, id) : nullptr;
}
static const c::detail::ProviderVTable &decorated() noexcept {
  static const auto table = [] {
    auto value = original(); value.query_extension = &query_extension; return value;
  }();
  return table;
}
static c::Provider decorate(c::Provider provider) noexcept {
  return c::detail::ProviderAccess::with_vtable(std::move(provider), &decorated());
}
};
} // namespace hyle::graph::detail
