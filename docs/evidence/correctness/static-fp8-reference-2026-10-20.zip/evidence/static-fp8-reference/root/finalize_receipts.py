from pathlib import Path
import json,re,hashlib,xml.etree.ElementTree as ET
ROOT=Path.cwd();S=ROOT/'.scratch/architecture-refactor-2026-10-18/static-fp8-reference';R=S/'root'
def read(p):return json.loads(p.read_bytes())
def ident(p):
 data=p.read_bytes();return dict(path=str(p),bytes=len(data),sha256=hashlib.sha256(data).hexdigest())
def save(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def code(p):return '\n'.join(line.rstrip() for line in re.sub(r'//[^\n]*','',p.read_text(encoding='utf-8')).splitlines() if line.strip()).encode()
header=ROOT/'include/hyle/compute/providers/torch_cuda.h';before=S/'apple/before-public-comment/include/hyle/compute/providers/torch_cuda.h'
assert code(header)==code(before)
original_lf=before.read_bytes().replace(b'\r\n',b'\n')
original_lf_hash=hashlib.sha256(original_lf).hexdigest()
header_eq=dict(before=ident(before),current=ident(header),comment_only=True,code_sha256=hashlib.sha256(code(header)).hexdigest(),original_compiled_LF_bytes=dict(bytes=len(original_lf),sha256=original_lf_hash),snapshot_CRLF_only=True)
source={}
def scan(x):
 if isinstance(x,dict):
  if all(k in x for k in ['path','bytes','sha256']):
   p=Path(x['path']);p=p if p.is_absolute() else ROOT/p
   if p.is_file() and p.is_relative_to(ROOT) and p.relative_to(ROOT).parts[0] in ['src','tests','include']:source[str(p.relative_to(ROOT))]=ident(p)
  else:
   for k,v in x.items():
    if k not in ['dependencies','common_read_basis_not_owned']:scan(v)
 elif isinstance(x,list):
  for v in x:scan(v)
for rel in ['root/source-freeze.json','common-cpu/source-freeze.json','common-cpu/fixture-source-freeze.json','apple/source-freeze.json','vulkan/final-source-freeze.json']:
 scan(read(S/rel))
for p in S.rglob('*-identity.json'):
 v=read(p)
 if isinstance(v,dict) and 'source' in v:scan(v['source'])
for rel in ['include/hyle/compute/providers/torch_cuda.h','tests/graph_route_cuda/CMakeLists.txt','src/compute_shader_shared/nvfp4_f32.h','src/compute_shader_shared/ct_packed.h','src/compute_torch_shared/storage_cast.h','include/hyle/simd/dtype.h']:
 p=ROOT/rel;source[rel]=ident(p)
save(R/'final-source-freeze.json',dict(status='current_product_and_permanent_test_sources_frozen',files=list(source.values()),public_header_comment_equivalence=header_eq,no_new_GPU_or_build=True))
rows=[S/'cuda/checks/attempt1/artifact-kernel-identity.json',S/'cuda/checks/attempt1/cuda-region-identity.json',S/'cuda/checks/final/artifact-provider-identity.json',S/'cuda/checks/selection/static-test-identity.json',S/'cuda-scalar-bridge/checks/default-policy-identity.json',S/'cuda-scalar-bridge/checks/testattempt2/scalar-test-identity.json']
for p in rows:
 v=read(p)
 for key in ['source','object']:
  x=v[key];a=ident(Path(x['path']));assert a==x,(p,key)
checks=[];different=[]
for p in rows:
 for x in read(p).get('dependencies',[]):
  path=Path(x['path'])
  if path.is_relative_to(ROOT) and not path.is_relative_to(ROOT/'.scratch') and path.is_file():
   a=ident(path)
   if a['sha256']!=x['sha256']:
    if path==header and x['sha256'] in (ident(before)['sha256'],original_lf_hash):different.append(dict(path=str(path),reason='comment-only header; code equality checked above'))
    else:raise AssertionError((p,x,a))
   checks.append(str(path))
def process(tag,green):
 p=S/'cuda/validation'/tag;result=read(p/'result.json');x=ET.parse(p/'tests.xml').getroot()
 if green:assert result['returncode']==0 and x.get('failures')=='0' and not x.findall('.//skipped')
 return dict(tag=tag,result=ident(p/'result.json'),xml=ident(p/'tests.xml'),command=ident(p/'run-plan.json'),tests=int(x.get('tests')),failures=int(x.get('failures')),skipped=len(x.findall('.//skipped')))
final=[process(tag,True) for tag in ['scalar-fixed-static','scalar-fixed-neighbors','scalar-probe-final-v2']]
assert sum(x['tests'] for x in final)==13
left=read(S/'cuda/scalar-probe-before-v2/link-plan.json');right=read(S/'cuda/scalar-probe-final-v2/link-plan.json')
def inputmap(v):return {x['path']:x for x in v['inputs']}
lm,rm=inputmap(left),inputmap(right);removed=[lm[k] for k in lm.keys()-rm.keys()];added=[rm[k] for k in rm.keys()-lm.keys()]
assert len(removed)==len(added)==1
for k in lm.keys()&rm.keys():assert lm[k]==rm[k]
assert left['probe']==right['probe']
selection={}
for tag in ['scalar-probe-before-v2','scalar-probe-final-v2']:
 x=ET.parse(S/'cuda/validation'/tag/'tests.xml').getroot();selection[tag]={case.get('name'):{p.get('name'):p.get('value') for p in case.findall('./properties/property')} for case in x.findall('.//testcase')}
receipt=dict(status='bounded_static_FP8_CUDA_and_ordinary_scalar_math_verified',final=final,total_passed=13,skipped=0,
 final_images=[ident(S/'cuda/scalar-fixed/static-fp8.exe'),ident(S/'cuda/scalar-probe-final-v2/static-fp8.exe')],
 final_closures=[ident(S/'cuda/scalar-fixed/link-plan.json'),ident(S/'cuda/scalar-probe-final-v2/link-plan.json')],
 compiled_owners=[ident(p) for p in rows],current_source_and_object_identities_verified=True,workspace_dependency_entries_checked=len(checks),unique_workspace_dependencies=len(set(checks)),comment_equivalence=header_eq,comment_only_dependency_differences=different,
 history=[dict(**process('static',False),classification='Real ordinary escape numerical failure: zero instead of BF16 0x0008; contracted math/lifetimes already pass.'),dict(**process('scalar-probe-before',False),classification='Probe setup mistake: no ResourceEpisode before output bind; no numerical conclusion. Test-only factory.resources fix follows.'),dict(**process('scalar-probe-before-v2',False),classification='Actual minimal public Mul and Divide return zero; independent BF16 Cast preserves0x0008. Same permanent test object subsequently passes new policy.')],
 pair=dict(common_test_object=left['probe'],removed_policy=removed,added_policy=added,only_one_actual_input_object_differs=True,selection=selection),
 build=dict(CXX=8,NVCC=1,links=6,all_compile_and_link_returncodes_zero=True,CUDA_toolchain_or_SDK_builds=0,actual_GPU_processes=6,green_processes=3),
 implementation='Existing dense F32 scalar Mul/Divide leaf arithmetic is strict. Default cold preference now chooses native in that exact admitted domain; existing ggml island gate respects actual leaf preference. Static FP8 candidate preference and other native ranking unchanged. Static quantization writes caller MK-byte codes then F32 code-dot from original W and separate SA/SW. Existing native MLX/CT/GPTQ no longer allocate unreported holder; static retains and reports actual holder.',
 limits=['No full publisher artifact/importer/quality execution, Linux, installed-consumer or all-configured-build claim.','No hardware FP8 scaled-mm equivalence, throughput or measured peak-memory claim.','Source/control closure and successful capture are tested; arbitrary native reduction order is backend-dependent.'])
save(S/'cuda/final-validation.json',receipt)
print('FINAL',len(source),'sources; CUDA13 tests; deps',len(checks),len(set(checks)),'comment-only differences',len(different))
