from pathlib import Path
import importlib.util,sys,os,json,subprocess,time,xml.etree.ElementTree as ET
sys.dont_write_bytecode=True
ROOT=Path.cwd();A=ROOT/'.scratch/architecture-refactor-2026-10-18';S=A/'static-fp8-reference'
backend=sys.argv[1];tag=sys.argv[2];filter=sys.argv[3]
if backend=='cuda':
 image=S/'cuda/scalar-fixed/static-fp8.exe';envpath=S/'cuda/scalar-fixed/runtime-environment.json'
else:
 assert backend=='vulkan';image=S/'vulkan/checks/static-fp8-test.exe';envpath=A/'vulkan-mlx-constant-bank-reuse/checks/runtime-environment.json'
out=S/backend/'validation'/tag;out.mkdir(parents=True,exist_ok=False)
env=os.environ.copy();env['PATH']=json.loads(envpath.read_bytes())['PATH']
command=[str(image),'--gtest_filter='+filter,'--gtest_output=xml:'+str(out/'tests.xml')]
(out/'run-plan.json').write_text(json.dumps(dict(command=command,runtime_environment=str(envpath),actual_gpu_execution=True),indent=2)+'\n')
start=time.time();r=subprocess.run(command,cwd=ROOT,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
(out/'stdout.txt').write_bytes(r.stdout);(out/'stderr.txt').write_bytes(r.stderr)
result=dict(returncode=r.returncode,elapsed_seconds=time.time()-start)
if (out/'tests.xml').is_file():
 x=ET.fromstring((out/'tests.xml').read_bytes());result['xml']={k:x.get(k) for k in ['tests','failures','errors','disabled']};result['skipped']=len(x.findall('.//skipped'))
(out/'result.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result));print(r.stdout.decode(errors='replace')[-8500:])
if r.returncode:sys.exit(1)
