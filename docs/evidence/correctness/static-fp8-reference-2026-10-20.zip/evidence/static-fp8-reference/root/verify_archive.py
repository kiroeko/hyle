from pathlib import Path
import json,hashlib,zipfile,xml.etree.ElementTree as ET
ROOT=Path.cwd();S=ROOT/'.scratch/architecture-refactor-2026-10-18/static-fp8-reference';DEST=ROOT/'docs/evidence/correctness/static-fp8-reference-2026-10-20'
def ident(p):
 data=p.read_bytes();return dict(path=str(p),bytes=len(data),sha256=hashlib.sha256(data).hexdigest())
report=json.loads(DEST.with_suffix('.json').read_bytes())
assert report['total_passed']==71
with zipfile.ZipFile(DEST.with_suffix('.zip')) as z:
 assert z.testzip() is None
 inv=json.loads(z.read('inventory.json'));names=z.namelist();assert len(names)==len(set(names))
 assert set(names)=={x['member'] for x in inv['members']}|{'inventory.json'}
 for row in inv['members']:
  data=z.read(row['member']);assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256']
 sources=[n for n in names if n.startswith('source/')]
 for n in sources:assert z.read(n)==(ROOT/n.removeprefix('source/')).read_bytes(),n
 def xmls(x):
  if isinstance(x,dict):
   if str(x.get('path','')).endswith('tests.xml'):yield x
   else:
    for v in x.values():yield from xmls(v)
  elif isinstance(x,list):
   for v in x:yield from xmls(v)
 count=0;seen=set()
 for row in xmls(report['validation']):
  p=Path(row['path']);assert p not in seen;seen.add(p);assert ident(p)['sha256']==row['sha256']
  doc=ET.parse(p).getroot();cases=doc.findall('.//testcase');assert len(cases)==int(doc.get('tests'))
  for case in cases:assert not any(case.findall(t) for t in ['failure','error','skipped'])
  count+=len(cases)
 assert count==71
result=dict(status='independent_archive_and_current_source_check_passed',archive=ident(DEST.with_suffix('.zip')),report=ident(DEST.with_suffix('.json')),members=len(names),sources=len(sources),green_XML_processes=len(seen),tests=count,skipped=0,all_member_hashes_verified=True,current_source_bytes_equal=True,new_GPU_or_builds=0)
(S/'root/archive-independent-check.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8');print(json.dumps(result,indent=2))
