from pathlib import Path
import importlib.util,sys
sys.dont_write_bytecode=True
ROOT=Path.cwd();A=ROOT/'.scratch/architecture-refactor-2026-10-18';S=A/'static-fp8-reference'
spec=importlib.util.spec_from_file_location('static_probe_host',A/'grouped-shared-activation/build_host.py');h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h);b,c=h.b,h.c
basepath=S/'cuda/scalar-fixed/link-plan.json';base=c.read(basepath)
probe=c.read(S/'cuda-scalar-bridge/checks/testattempt2/scalar-test-identity.json');policy=c.read(S/'cuda-scalar-bridge/checks/default-policy-identity.json')
assert b.same(probe['source']) and b.same(probe['object']) and b.same(policy['source']) and b.same(policy['object'])
for tag,restore in [('scalar-probe-before-v2',True),('scalar-probe-final-v2',False)]:
 out=S/'cuda'/tag;out.mkdir(exist_ok=False);(out/'tmp').mkdir()
 def replace(arg):
  if restore and c.key(arg)==c.key(policy['object']['path']):return policy['old_object']['path']
  for flag,suffix in [('/OUT:','.exe'),('/MAP:','.map'),('/IMPLIB:','.lib'),('/PDB:','.pdb'),('/ILK:','.ilk')]:
   if arg.upper().startswith(flag):return flag+str(out/('static-fp8'+suffix))
  return arg
 command=[replace(arg) for arg in base['command']];command[1:1]=[probe['object']['path']]
 inputs=[replace(row['path']) for row in base['inputs']]+[probe['object']['path']];identities=[b.identity(p) for p in inputs]
 env,runtime=b.environment(command,inputs,out)
 c.save(out/'runtime-environment.json',dict(PATH=env['PATH'],runtime=runtime))
 c.save(out/'link-plan.json',dict(command=command,inputs=identities,base=b.identity(basepath),probe=probe['object'],policy=policy['old_object'] if restore else policy['object'],actual_inputs=len(identities),scope='Same permanent scalar test object and unchanged static fixture object; only policy object differs between before/final arms'))
 c.execute('scalar-probe-link',command,env,out)
 assert all(b.same(row) for row in identities)
 c.save(out/'image.json',b.identity(out/'static-fp8.exe'))
 print(tag,len(inputs),'inputs',flush=True)
