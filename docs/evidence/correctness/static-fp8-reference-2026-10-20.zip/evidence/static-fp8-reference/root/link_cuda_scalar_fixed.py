from pathlib import Path
import importlib.util,sys
sys.dont_write_bytecode=True
R=Path(__file__).resolve().parent;S=R.parent;A=S.parent;ROOT=A.parents[1]
spec=importlib.util.spec_from_file_location('static_link_host',A/'grouped-shared-activation/build_host.py')
h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h);b,c=h.b,h.c
base_path=A/'gptq-reference/cuda/tests-mapped/link-plan.json';base=c.read(base_path);meta=h.metadata({'cuda':base})
out=S/'cuda/scalar-fixed';out.mkdir(parents=True,exist_ok=False);(out/'tmp').mkdir()
rows=[]
for p in [S/'cuda/checks/final/artifact-provider-identity.json',S/'cuda/checks/attempt1/artifact-kernel-identity.json',S/'cuda/checks/attempt1/cuda-region-identity.json',S/'cuda/checks/selection/static-test-identity.json',S/'cuda-scalar-bridge/checks/default-policy-identity.json']:
 row=c.read(p);assert b.same(row['source']) and b.same(row['object']),str(p);rows.append(row)
replacement={};added=[];mapped=[]
for row in rows:
 matches=[old for old in base['inputs'] if c.key(old['path']) in meta and c.key(meta[c.key(old['path'])]['source_path'])==c.key(row['source']['path'])]
 if matches:
  assert len(matches)==1,(row['source'],len(matches))
  old=matches[0];replacement[c.key(old['path'])]=row['object']['path'];mapped.append(dict(old=old,new=row['object'],source=row['source']))
 else:
  assert Path(row['source']['path']).name in ('static_fp8_reference_test.cc',),row['source']
  added.append(row['object']['path'])
command=[]
for arg in base['command']:
 value=replacement.get(c.key(arg),arg)
 for flag,suffix in [('/OUT:','.exe'),('/MAP:','.map'),('/IMPLIB:','.lib'),('/PDB:','.pdb'),('/ILK:','.ilk')]:
  if arg.upper().startswith(flag):value=flag+str(out/('static-fp8'+suffix))
 command.append(value)
command[1:1]=added
inputs=[replacement.get(c.key(x['path']),x['path']) for x in base['inputs']]+added
identities=[b.identity(p) for p in inputs]
env,runtime=b.environment(command,inputs,out)
c.save(out/'runtime-environment.json',dict(PATH=env['PATH'],runtime=runtime))
c.save(out/'link-plan.json',dict(command=command,inputs=identities,base=b.identity(base_path),mapped_current_owners=mapped,additional_inputs=[b.identity(p) for p in added],scope='Actual cached closure, replacing only affected CUDA owners and adding one CUDA test; unchanged original CPU schemas/codecs retained where actually linked; no SDK rebuild'))
c.execute('static-fp8-link',command,env,out)
assert all(b.same(x) for x in identities)
c.save(out/'image.json',b.identity(out/'static-fp8.exe'))
print('CUDA_LINK_READY',len(identities),'inputs',flush=True)
