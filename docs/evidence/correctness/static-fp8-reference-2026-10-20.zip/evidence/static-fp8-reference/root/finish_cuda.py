from pathlib import Path
import concurrent.futures
import importlib.util
import json
import sys
sys.dont_write_bytecode = True

S = Path(__file__).resolve().parent
Q = S.parent
A = Q.parent
ROOT = A.parents[1]
spec = importlib.util.spec_from_file_location('static_fp8_host', A/'grouped-shared-activation/build_host.py')
h = importlib.util.module_from_spec(spec)
spec.loader.exec_module(h)
b,c = h.b,h.c
ns = importlib.util.spec_from_file_location('native_recipe', A/'grouped-nvfp4/cuda/build_products.py')
n = importlib.util.module_from_spec(ns)
ns.loader.exec_module(n)

out = Q/'cuda/checks/final'
out.mkdir(parents=True, exist_ok=False)
(out/'tmp').mkdir()
base_path = A/'grouped-nvfp4/cuda/tests/link-plan.json'
base = c.read(base_path)
meta = h.metadata({'cuda':base})
wanted = {
 'src/compute_provider_torch_cuda/artifact_provider.cc':'artifact-provider',
}
rows=[]
for relative,tag in wanted.items():
 source = ROOT/relative
 matches = [(old,meta[c.key(old['path'])]) for old in base['inputs']
            if c.key(old['path']) in meta and
            c.key(meta[c.key(old['path'])]['source_path']) == c.key(source)]
 assert len(matches)==1,(relative,len(matches))
 old,recipe = matches[0]
 assert b.same(old)
 command = n.native_command(recipe['command'],tag,out) if source.suffix=='.cu' else b.host_command(recipe['command'],source,tag,out)
 rows.append(dict(source=b.identity(source),tag=tag,old_object=old,
                  recipe=b.identity(recipe['recipe']),command=command,object=str(out/(tag+'.obj'))))
recipe_data = c.read(A/'gptq-reference/cuda/checks/attempt1/plan.json')
test_recipe = next(x for x in recipe_data['owners'] if x['tag']=='ct-test')
source = ROOT/'tests/graph_route_cuda/static_fp8_reference_test.cc'
rows.append(dict(source=b.identity(source),tag='static-test',old_object=None,
    recipe=test_recipe['recipe'],command=b.host_command(test_recipe['command'],source,'static-test',out),
    object=str(out/'static-test.obj')))
frozen = [b.identity(ROOT/p) for p in [
 'src/compute_provider_torch_cuda/mlx_packed_kernel.h',
 'src/compute_packed_shared/static_fp8_linear.h',
 'src/graph/closed_region.h', 'src/graph/static_fp8_region.h',
 'src/graph/mapped_pattern_region.h','src/graph/artifact_packed_region.h',
 'tests/compute_models/static_fp8_reference_fixture.h']]
c.save(out/'plan.json',dict(base=b.identity(base_path),owners=rows,frozen=frozen,
          scope='1 final product CXX +1 new test CXX; no SDK/GPU/link'))
env,runtime=b.environment(next(row['command'] for row in rows if row['tag']=='artifact-provider'),[],out)
c.save(out/'runtime-environment.json',dict(PATH=env['PATH'],runtime=runtime))

def compile_one(row):
 tag=row['tag'];job=out/'commands'/tag;job.mkdir(parents=True)
 result=c.execute(tag+'-compile',row['command'],env,job)
 if Path(row['source']['path']).suffix=='.cu':
  dep=out/(tag+'.d');paths=n.native_dependencies(dep)
 else:
  dep=out/(tag+'-deps.json');data=c.read(dep)['Data'];paths=list(dict.fromkeys([data['Source'],*data['Includes']]))
 record=dict(row,result=result,object=b.identity(row['object']),source_dependencies=b.identity(dep),dependencies=[b.identity(p) for p in paths])
 assert b.same(row['source']) and all(b.same(x) for x in frozen)
 c.save(out/(tag+'-identity.json'),record)
 print('COMPILED',tag,flush=True)
 return record

records=[];errors=[]
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
 futures=[pool.submit(compile_one,row) for row in rows]
 for future in futures:
  try:records.append(future.result())
  except Exception as exc:errors.append(str(exc))
c.save(out/'objects-ready.json',dict(owners=records,errors=errors))
c.save(out/'summary.json',dict(passed=not errors,errors=errors,CXX_successes=sum(Path(x['source']['path']).suffix=='.cc' for x in records),
    NVCC_successes=sum(Path(x['source']['path']).suffix=='.cu' for x in records),SDK=0,links=0,GPU=0))
if errors:raise RuntimeError('; '.join(errors))
print('CUDA_OWNERS_READY',len(records),flush=True)
