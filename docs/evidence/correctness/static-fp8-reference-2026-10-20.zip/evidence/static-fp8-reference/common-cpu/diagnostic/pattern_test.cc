#include "tests/compute_models/static_fp8_reference_fixture.h"
#include "src/graph/static_fp8_region.h"
#include "src/compute/provider_internal.h"
#include "hyle/compute/providers/native.h"
#include "hyle/compute/backends/cpu.h"
#include "hyle/graph/cpu.h"
#include <iostream>
TEST(StaticFloat8PatternDiagnostic, RawPatternClosedNativeProposalAndCompiledSteps) {
  namespace f=static_fp8_reference_test;namespace c=f::c;namespace g=f::g;
  using Recipe=g::detail::StaticFloat8Pattern;
  auto provider=c::native::provider();const auto *table=c::detail::ProviderAccess::vtable(provider);void *state=nullptr;auto allocator=f::m::system_allocator();
  f::check(table->create_context(provider,c::cpu::device(),nullptr,allocator,&state),"raw native context");
  for(const auto profile:f::profiles) {
    f::Case test(profile);f::Logical logical(test,false);Recipe::Pattern pattern;
    const bool matches=Recipe::pattern(logical.graph,f::take(logical.graph.producer(logical.output),"terminal"),pattern);
    Recipe::Uses uses(allocator);f::check(uses.initialize(logical.graph),"uses");const bool closed=matches&&Recipe::closed(logical.graph,pattern,uses,{});
    std::cout<<"PROFILE A="<<int(profile.input)<<" out="<<int(profile.output)<<" nodes="<<logical.graph.node_count()<<" pattern="<<matches<<" size="<<pattern.size<<" closed="<<closed<<"\n";
    std::array<c::detail::ResourceBindingRequirement,4> inputs;std::array<c::detail::ResourceBindingRequirement,1> outputs;const std::array output_desc{test.output};c::detail::ProviderOperationProposal proposal;
    const auto proposed=table->propose(state,{.operation=c::Operation::custom(c::packed::internal::StaticFloat8Linear{profile.output}),.inputs=test.descriptions,.outputs=output_desc},inputs,outputs,&proposal);
    std::cout<<"NATIVE status="<<proposed.message()<<" ok="<<proposed.ok()<<" pref="<<proposal.preference<<" route="<<proposal.route<<"\n";
    auto context=f::take(g::cpu::create_context(),"CPU context");auto compiled=g::cpu::compile(logical.graph,context,{.provider_replay=g::ProviderReplayPolicy::kRequirePrepared});ASSERT_TRUE(compiled)<<compiled.error().message();const auto search=compiled->report.search();
    std::cout<<"SEARCH regions="<<search.region_proposals<<" region_nodes="<<search.region_proposal_nodes<<" rejects="<<search.region_route_rejections<<" oprejects="<<search.operation_route_rejections<<" planrejects="<<search.route_plan_rejections<<" steps="<<compiled->report.step_count()<<"\n";
    for(std::size_t i=0;i<compiled->report.step_count();++i) {const auto s=f::take(compiled->report.step(i),"step");std::cout<<"STEP "<<i<<" kind="<<int(s.kind)<<" nodes="<<s.node_count<<" provider="<<s.provider.name<<" pref="<<s.preference<<" policy="<<std::hex<<s.policy.namespace_id<<":"<<s.policy.policy_id<<":"<<s.policy.version<<std::dec<<"\n";}
  }
  table->destroy_context(state,allocator);
}
