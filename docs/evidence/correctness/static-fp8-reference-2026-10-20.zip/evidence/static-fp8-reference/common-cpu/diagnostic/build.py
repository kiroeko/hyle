from pathlib import Path
import importlib.util,json,sys
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent;G=S.parent;A=G.parents[1];R=A.parents[1]
spec=importlib.util.spec_from_file_location('diag_h',A/'grouped-shared-activation/build_host.py');h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h);b,c=h.b,h.c
S.mkdir(exist_ok=True);(S/'tmp').mkdir(exist_ok=True);rec=c.read(G/'checks/attempt1/test-identity.json');src=S/'pattern_test.cc';command=b.host_command(rec['command'],src,'pattern-test',S);env,_=b.environment(command,[],S);c.execute('compile',command,env,S);d=c.read(S/'pattern-test-deps.json')['Data'];obj=b.identity(S/'pattern-test.obj');c.save(S/'test-identity.json',dict(source=b.identity(src),object=obj,command=command,source_dependencies=b.identity(S/'pattern-test-deps.json'),dependencies=[b.identity(x) for x in dict.fromkeys([d['Source'],*d['Includes']])]))
base=c.read(G/'checks/attempt1/link-plan.json');image=S/'cpu.exe';command=[x for x in base['command'] if not x.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:'))]+[obj['path'],'/OUT:'+str(image),'/MAP:'+str(image.with_suffix('.map')),'/IMPLIB:'+str(image.with_suffix('.lib'))];inputs=base['inputs']+[obj]
for row in inputs:assert b.identity(row['path'])['sha256']==row['sha256']
c.save(S/'link-plan.json',dict(command=command,inputs=inputs));env,_=b.environment(command,[x['path'] for x in inputs],S);c.execute('link',command,env,S);c.execute('run',[str(image),'--gtest_filter=StaticFloat8PatternDiagnostic.*','--gtest_output=xml:'+str(S/'tests.xml')],env,S)
