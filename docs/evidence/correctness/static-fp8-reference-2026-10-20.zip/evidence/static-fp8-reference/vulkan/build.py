from pathlib import Path
import hashlib, json, os, re, struct, subprocess, sys, time

root = Path.cwd()
a = root / '.scratch/architecture-refactor-2026-10-18'
stage = a / 'static-fp8-reference/vulkan'
checks, shaders = stage / 'checks', stage / 'shaders'
checks.mkdir(exist_ok=True)
shaders.mkdir(exist_ok=True)
base = a / 'gptq-reference/vulkan/checks'
phase = sys.argv[1]
env = os.environ.copy()
setup = subprocess.run(['cmd', '/d', '/c', str(a / 'bf16-nan-cast-contract/compiler-env.bat')],
                       capture_output=True, text=True, check=True)
for line in setup.stdout.splitlines():
    if '=' in line and not line.startswith('='):
        key, value = line.split('=', 1)
        env[key.upper()] = value
records = []


def identity(path):
    path = Path(path)
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())


def load(path):
    return json.loads(Path(path).read_bytes())


def save(path, value):
    Path(path).write_text(json.dumps(value, indent=2) + '\n')


def run(label, command):
    start = time.time()
    result = subprocess.run(command, cwd=root, env=env, capture_output=True,
                            text=True, encoding='utf8', errors='replace')
    (checks / (label + '.stdout.log')).write_text(result.stdout, encoding='utf8')
    (checks / (label + '.stderr.log')).write_text(result.stderr, encoding='utf8')
    records.append(dict(label=label, command=command, exit_code=result.returncode,
                        seconds=time.time() - start))
    save(checks / ('commands-' + phase + '.json'), records)
    print(label, result.returncode, flush=True)
    if result.returncode:
        print((result.stdout + result.stderr)[-9000:])
        raise SystemExit(result.returncode)


def recipe_for(obj):
    for path in Path(obj).parent.glob('*identity.json'):
        data = load(path)
        if str(Path(data.get('object', {}).get('path', ''))).lower() == str(Path(obj)).lower():
            return path
    raise AssertionError(obj)


if phase == 'plan':
    linked = load(base / 'link-plan.json')
    old = {Path(row['path']).name: row for row in linked['inputs']}
    items = [
        ('vulkan_tensor', 'src/compute_route_vulkan/vulkan_tensor.cc',
         old['compute_route_vulkan-vulkan_tensor.obj']['path']),
        ('vulkan_program', 'src/compute_route_vulkan/vulkan_program.cc',
         old['vulkan_program.obj']['path']),
        ('vulkan_operations', 'src/compute_route_vulkan/vulkan_operations.cc',
         old['vulkan_operations.obj']['path']),
        ('native_region', 'src/graph_route_vulkan/native_region.cc',
         old['native_region.obj']['path']),
        ('vulkan_static_fp8', 'src/compute_route_vulkan/vulkan_static_fp8.cc',
         old['vulkan_ct_packed.obj']['path']),
        ('vulkan_shaders', str(shaders / 'vulkan_shaders.cc'),
         old['vulkan_shaders.obj']['path']),
    ]
    compiles = []
    for tag, source, old_object in items:
        recipe = recipe_for(old_object)
        command, skip = [], False
        for arg in load(recipe)['command']:
            if skip:
                skip = False
                continue
            if arg == '/sourceDependencies':
                skip = True
                continue
            if arg.startswith(('/Fo', '/Fd')) or arg.lower().endswith(('.cc', '.cpp')):
                continue
            command.append(arg)
        command.insert(1, '-I' + str(shaders))
        source_path = Path(source) if Path(source).is_absolute() else root / source
        command += ['/W4', '/WX', '/sourceDependencies', str(checks / (tag + '-deps.json')),
                    str(source_path), '/Fo' + str(checks / (tag + '.obj')),
                    '/Fd' + str(checks / (tag + '.pdb'))]
        compiles.append(dict(tag=tag, source=str(source_path), object=str(checks / (tag + '.obj')),
                             command=command, recipe=identity(recipe), previous_object=identity(old_object)))
    for row in linked['inputs']:
        if row['path'].lower().endswith('.obj'):
            assert identity(row['path']) == row
    save(checks / 'product-plan.json', dict(baseline=identity(base / 'link-plan.json'),
        common_freeze=identity(a / 'static-fp8-reference/root/source-freeze.json'),
        compile=compiles, shader_compile=7, SPIRV_reused=10,
        limits='6 incremental product CXX; no test CXX, link, SDK or GPU in these phases.'))
    print('plan', len(compiles))
elif phase == 'shaders':
    previous = a / 'gptq-reference/vulkan/shaders'
    names = re.findall(r'uint32_t> (\w+)\(\) noexcept;', (previous / 'vulkan_shaders.h').read_text())
    assert len(names) == 16
    names.insert(0, 'static_fp8')
    old = {row['name']: Path(row['artifact']['path'])
           for row in load(base / 'shader-artifacts.json')['artifacts']}
    changed = {'static_fp8': {}, 'tensor': {}, 'checked_tensor': {'HYLE_TENSOR_CHECKED': '1'},
               'scatter': {'HYLE_TENSOR_SCATTER': '1'},
               'normalization': {'HYLE_TENSOR_NORMALIZATION': '1'},
               'concat': {'HYLE_TENSOR_CONCAT': '1'}, 'reduction': {'HYLE_TENSOR_REDUCTION': '1'}}
    numerical = []
    for name in ('nvfp4_f32.h', 'ct_packed.h'):
        text = (root / 'src/compute_shader_shared' / name).read_text()
        numerical.append(text.split('R"HYLE_SHADER(', 1)[1].split(')HYLE_SHADER"', 1)[0])
    static = (root / 'src/compute_route_vulkan/shaders/static_fp8.comp').read_text()
    generated = shaders / 'static_fp8.generated.comp'
    generated.write_bytes(static.replace('// HYLE_STATIC_FP8_F32_SOURCE', '\n'.join(numerical)).encode())
    for name, defines in changed.items():
        source = generated if name == 'static_fp8' else root / 'src/compute_route_vulkan/shaders/tensor.comp'
        command = ['C:/public/tools/glslang/glslangValidator.exe', '-V', '--target-env', 'vulkan1.2',
            '--preamble-text', '#extension GL_GOOGLE_include_directive : require\n',
            '-I' + str(root / 'third_party/ggml_vulkan_shaders/shaders'),
            '-I' + str(root / 'src/compute_route_vulkan/shaders'), '-S', 'comp']
        command += ['-D' + key + '=' + value for key, value in defines.items()]
        command += ['-o', str(shaders / (name + '.spv')), str(source)]
        run(name + '-shader', command)
    header = ['#pragma once', '#include <cstdint>', '#include <span>',
              'namespace hyle::compute::vulkan::detail::shaders {']
    cpp = ['#include "vulkan_shaders.h"', 'namespace hyle::compute::vulkan::detail::shaders {']
    artifacts = []
    for name in names:
        path = shaders / (name + '.spv') if name in changed else old[name]
        data = path.read_bytes()
        assert len(data) % 4 == 0
        words = struct.unpack('<' + 'I' * (len(data) // 4), data)
        assert words[0] == 0x07230203 and words[1] <= 0x00010500
        at = 5
        while at < len(words):
            count, opcode = words[at] >> 16, words[at] & 65535
            assert count and at + count <= len(words)
            if opcode == 17:
                assert count == 2 and words[at + 1] == 1
            at += count
        header.append('std::span<const std::uint32_t> ' + name + '() noexcept;')
        cpp.append('namespace { constexpr std::uint32_t ' + name + '_words[] = {')
        for offset in range(0, len(words), 8):
            cpp.append('  ' + ', '.join(f'0x{x:08x}u' for x in words[offset:offset + 8]) + ',')
        cpp += ['}; }', 'std::span<const std::uint32_t> ' + name + '() noexcept { return ' + name + '_words; }']
        artifacts.append(dict(name=name, artifact=identity(path), compiled=name in changed))
    header.append('} // namespace hyle::compute::vulkan::detail::shaders')
    cpp.append('} // namespace hyle::compute::vulkan::detail::shaders')
    (shaders / 'vulkan_shaders.h').write_bytes(('\n'.join(header) + '\n').encode())
    (shaders / 'vulkan_shaders.cc').write_bytes(('\n'.join(cpp) + '\n').encode())
    save(checks / 'shader-artifacts.json', dict(artifacts=artifacts, compiled=7, reused=10,
        local_codec=identity(root / 'src/compute_route_vulkan/shaders/fp8_storage.glsl'),
        shared_math=[identity(root / 'src/compute_shader_shared' / name)
                     for name in ('nvfp4_f32.h', 'ct_packed.h')]))
elif phase == 'product':
    for item in load(checks / 'product-plan.json')['compile']:
        run(item['tag'] + '-compile', item['command'])
        data = load(checks / (item['tag'] + '-deps.json'))['Data']
        paths = dict.fromkeys([data['Source'], *data['Includes']])
        save(checks / (item['tag'] + '-identity.json'), dict(command=item['command'],
            source=identity(item['source']), object=identity(item['object']), recipe=item['recipe'],
            dependencies=[identity(path) for path in paths]))
elif phase == 'test':
    recipe = base / 'gptq-test-identity.json'
    command, skip = [], False
    for arg in load(recipe)['command']:
        if skip:
            skip = False
            continue
        if arg == '/sourceDependencies':
            skip = True
            continue
        if arg.startswith(('/Fo', '/Fd')) or arg.lower().endswith(('.cc', '.cpp')):
            continue
        command.append(arg)
    source = root / 'tests/graph_route_vulkan/static_fp8_reference_test.cc'
    command.insert(1, '-I' + str(shaders))
    command += ['/W4', '/WX', '/sourceDependencies', str(checks / 'static-test-deps.json'),
                str(source), '/Fo' + str(checks / 'static-test.obj'),
                '/Fd' + str(checks / 'static-test.pdb')]
    save(checks / 'wrapper-plan.json', dict(command=command, recipe=identity(recipe),
        fixture_freeze=identity(a / 'static-fp8-reference/common-cpu/fixture-source-freeze.json')))
    run('static-test-compile', command)
    data = load(checks / 'static-test-deps.json')['Data']
    paths = dict.fromkeys([data['Source'], *data['Includes']])
    save(checks / 'static-test-identity.json', dict(command=command,
        source=identity(source), object=identity(checks / 'static-test.obj'), recipe=identity(recipe),
        dependencies=[identity(path) for path in paths]))
elif phase == 'link':
    linked = load(base / 'link-plan.json')
    plan = load(checks / 'product-plan.json')
    replacements = {str(Path(item['previous_object']['path'])).lower(): item['object']
                    for item in plan['compile'] if item['tag'] != 'vulkan_static_fp8'}
    shared = a / 'static-fp8-reference/common-cpu/checks/attempt1'
    native = load(shared / 'native-provider-identity.json')
    leaf = load(shared / 'static-fp8-identity.json')
    for record in (native, leaf):
        assert identity(record['source']['path']) == record['source']
        assert identity(record['object']['path']) == record['object']
    previous_native = next(row for row in linked['inputs']
        if Path(row['path']).name == 'native-provider.obj')
    previous_recipe = load(recipe_for(previous_native['path']))
    defines = lambda command: sorted(arg for arg in command if arg.startswith(('/D', '-D')))
    assert defines(previous_recipe['command']) == defines(native['command'])
    replacements[str(Path(previous_native['path'])).lower()] = native['object']['path']
    command, seen = [], set()
    for arg in linked['command']:
        if arg.upper().startswith(('/OUT:', '/MAP:', '/IMPLIB:')):
            continue
        key = str(Path(arg)).lower()
        if key in replacements:
            seen.add(key)
            command.append(replacements[key])
        else:
            command.append(arg)
    assert seen == set(replacements)
    command[1:1] = [str(checks / 'static-test.obj'), str(checks / 'vulkan_static_fp8.obj'), leaf['object']['path']]
    command += ['/OUT:' + str(checks / 'static-fp8-test.exe'), '/MAP:' + str(checks / 'static-fp8-test.map'),
                '/IMPLIB:' + str(checks / 'static-fp8-test.lib')]
    temporary = stage / 'tmp'
    temporary.mkdir(exist_ok=True)
    env['TMP'] = env['TEMP'] = str(temporary)
    run('link', command)
    save(checks / 'link-plan.json', dict(command=command,
        inputs=[identity(arg) for arg in command[1:] if Path(arg).is_file()],
        baseline=identity(base / 'link-plan.json'),
        shared_CPU_overlay=[dict(receipt=identity(shared / (tag + '-identity.json')),
            source=record['source'], object=record['object'])
            for tag, record in [('native-provider', native), ('static-fp8', leaf)]],
        native_CPU_compile_defines_unchanged=True,
        executable=identity(checks / 'static-fp8-test.exe')))
else:
    raise ValueError(phase)
