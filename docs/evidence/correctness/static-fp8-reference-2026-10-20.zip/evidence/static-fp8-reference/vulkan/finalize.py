from pathlib import Path
import hashlib
import json
import xml.etree.ElementTree as ET

ROOT = Path.cwd()
S = ROOT / '.scratch/architecture-refactor-2026-10-18/static-fp8-reference'
V = S / 'vulkan'


def load(path):
    return json.loads(Path(path).read_bytes())


def identity(path):
    path = Path(path)
    data = path.read_bytes()
    return dict(path=str(path.relative_to(ROOT)) if path.is_relative_to(ROOT) else str(path),
                bytes=len(data), sha256=hashlib.sha256(data).hexdigest())


def save(path, value):
    Path(path).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf8')


def verify(record):
    path = Path(record['path'])
    if not path.is_absolute():
        path = ROOT / path
    actual = identity(path)
    assert actual['bytes'] == record['bytes'] and actual['sha256'] == record['sha256'], path
    return actual


initial = load(V / 'source-freeze-after-canary.json')
files = []
for record in initial['files']:
    actual = verify(record)
    snapshot = identity(V / 'after' / record['path'])
    assert snapshot['sha256'] == actual['sha256'] and snapshot['bytes'] == actual['bytes']
    files.append(dict(**actual, snapshot=snapshot))

shared = initial['shared_headers'] + [identity(ROOT / path) for path in (
    'src/compute_shader_shared/nvfp4_f32.h',
    'src/compute_shader_shared/ct_packed.h',
    'tests/compute_models/static_fp8_reference_fixture.h',
)]
for record in shared:
    verify(record)

receipts = [V / 'checks' / (tag + '-identity.json') for tag in (
    'native_region', 'vulkan_operations', 'vulkan_program', 'vulkan_shaders',
    'vulkan_static_fp8', 'vulkan_tensor', 'static-test')]
dependencies = {}
for path in receipts:
    data = load(path)
    verify(data['source'])
    verify(data['object'])
    for entry in data['dependencies']:
        key = str(Path(entry['path'])).lower()
        assert key not in dependencies or dependencies[key] == entry, entry['path']
        dependencies[key] = entry
for record in dependencies.values():
    verify(record)

commands = {}
for phase, expected in (('shaders', 7), ('product', 6), ('test', 1), ('link', 1)):
    path = V / 'checks' / ('commands-' + phase + '.json')
    records = load(path)
    assert len(records) == expected and all(r['exit_code'] == 0 for r in records), phase
    commands[phase] = dict(processes=len(records), failed=0, receipt=identity(path))
image = verify(load(V / 'checks/link-plan.json')['executable'])
processes = {}
for phase, expected in (('static', 4), ('neighbors', 12)):
    directory = V / 'validation' / phase
    result = load(directory / 'result.json')
    assert result['returncode'] == 0 and result['skipped'] == 0, phase
    document = ET.parse(directory / 'tests.xml').getroot()
    cases = []
    for case in document.findall('.//testcase'):
        assert not any(case.findall(tag) for tag in ('failure', 'error', 'skipped'))
        assert case.attrib.get('status') == 'run' and case.attrib.get('result') == 'completed'
        cases.append(dict(suite=case.attrib['classname'], name=case.attrib['name'],
                          properties={p.attrib['name']: p.attrib['value']
                                      for p in case.findall('./properties/property')}))
    assert len(cases) == expected and int(document.attrib['tests']) == expected
    assert int(document.attrib['failures']) == 0 and int(document.attrib['errors']) == 0
    plan = load(directory / 'run-plan.json')
    assert Path(plan['command'][0]).resolve() == (ROOT / image['path']).resolve()
    processes[phase] = dict(tests=expected, failed=0, skipped=0, elapsed_seconds=result['elapsed_seconds'],
                           cases=cases, evidence={name: identity(directory / name) for name in (
                               'run-plan.json', 'result.json', 'tests.xml', 'stdout.txt', 'stderr.txt')})

freeze = dict(status='Windows_Vulkan_actual_16_tests_passed_zero_skip', files=files,
              common_headers=shared,
              compiled_source_and_dependencies_verified=dict(receipts=len(receipts),
                  unique_entries=len(dependencies), mismatches=0),
              scope=initial['scope'], arithmetic=initial['arithmetic'], integration=initial['integration'],
              chronology='Initial source-only and post-canary freezes are preserved unchanged; no product or matcher correction was required after the initial successful Vulkan build.')
save(V / 'final-source-freeze.json', freeze)
report = dict(status='Windows_Vulkan_static_FP8_reference_and_existing_neighbors_passed',
              execution=dict(actual_GPU=True, executed_by='root agent; this Vulkan owner only compiled and assembled evidence',
                             processes=2, tests=16, failures=0, skipped=0),
              source_freeze=identity(V / 'final-source-freeze.json'),
              image=image, build=commands, compiled_dependency_entries=len(dependencies),
              shader_artifacts=identity(V / 'checks/shader-artifacts.json'),
              SPIRV=dict(compiled=7, reused=10, SDK_builds=0),
              link_plan=identity(V / 'checks/link-plan.json'),
              shared_CPU_overlay=load(V / 'checks/link-plan.json')['shared_CPU_overlay'],
              processes=processes,
              storage_padding_proof=identity(V / 'padding-ownership-review.json'),
              selection='Test-only source filtering retains actual StaticFloat8Pattern proposals for the first two shared runs; the ordinary escape run excludes that policy. Product ordinary preference200 and bounded preference201 are unchanged. No default speedup was measured.',
              implementation='F32<->E4M3FN ordinary storage Cast bridge plus closed12-node bounded native static FP8 linear; original A/W/SA/SW bytes, no MK temporary or NK decoded bank, no new executor. Static scalar normalization and separate post-scales use bit-defined F32 helpers; code dot remains native F32.',
              limits=['No publisher artifact tensor payload execution, full-model importer/quality/performance, Linux, hardware FP8 GEMM or all-installed-build claim.',
                      'No validation-layer run or blanket arbitrary FP8 arithmetic admission. The ordinary bridge directly admits F32<->E4M3FN; F16/BF16 can compose through F32.',
                      'Actual native integer, dispatch and maxStorageBufferRange limits remain; no blanket multi-GiB model-bank capability.',
                      'Native F32 dot reduction order is backend-specific; the sparse independent fixture does not assert bit-identical arbitrary reduction trees.',
                      'Opaque native allocations remain unknown and true runtime OOM does not automatically reselect a route.',
                      'Count5/7 Cast tail tests use the explicit four-byte-aligned owned/borrowed capacity contract; bytes outside that authorized capacity remain canaries. They do not authorize arbitrary View output tail writes.'])
save(V / 'final-validation.json', report)
print(json.dumps(dict(final_validation=identity(V / 'final-validation.json'),
                      source_freeze=identity(V / 'final-source-freeze.json'),
                      tests=16, dependency_entries=len(dependencies)), indent=2))
