#pragma once
#include <cstdint>
#include <span>
namespace hyle::compute::vulkan::detail::shaders {
std::span<const std::uint32_t> static_fp8() noexcept;
std::span<const std::uint32_t> ct_packed() noexcept;
std::span<const std::uint32_t> gptq_v1() noexcept;
std::span<const std::uint32_t> nvfp4() noexcept;
std::span<const std::uint32_t> nvfp4_grouped() noexcept;
std::span<const std::uint32_t> row_cache_padded_map() noexcept;
std::span<const std::uint32_t> row_cache_indexer() noexcept;
std::span<const std::uint32_t> row_cache_paged_indexer() noexcept;
std::span<const std::uint32_t> row_cache() noexcept;
std::span<const std::uint32_t> sampling() noexcept;
std::span<const std::uint32_t> tensor() noexcept;
std::span<const std::uint32_t> checked_tensor() noexcept;
std::span<const std::uint32_t> integer_scan() noexcept;
std::span<const std::uint32_t> scatter() noexcept;
std::span<const std::uint32_t> normalization() noexcept;
std::span<const std::uint32_t> concat() noexcept;
std::span<const std::uint32_t> reduction() noexcept;
} // namespace hyle::compute::vulkan::detail::shaders
