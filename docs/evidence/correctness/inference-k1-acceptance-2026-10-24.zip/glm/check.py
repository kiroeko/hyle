from pathlib import Path
import argparse
import hashlib
import importlib.util
import json
import os
import shutil
import sys
import xml.etree.ElementTree as ET

sys.dont_write_bytecode = True
BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[2]
spec = importlib.util.spec_from_file_location('retained_glm_builder', ROOT / '.scratch/glm-random-mtp-20261024/build.py')
old = importlib.util.module_from_spec(spec)
spec.loader.exec_module(old)

def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))

def save(path, value):
    Path(path).write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8')

def pin(path):
    path = Path(path).resolve()
    return {'path': str(path), 'bytes': path.stat().st_size,
            'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}

def folder(kind):
    return BASE / kind / 'attempt1'

def build(kind):
    target = folder(kind)
    target.mkdir(parents=True, exist_ok=False)
    source_name = 'glm_pro_mtp_state_consumer_test.cc' if kind == 'pro' else 'glm_mtp_state_consumer_test.cc'
    cached = ROOT / '.scratch/glm-k2-state-20261024' / kind / 'attempt2'
    command = read(cached / 'compile/command.json')['command']
    dependencies = read(cached / 'deps.json')['Data']['Includes']
    own = [ROOT / 'tests/compute_models' / source_name]
    own.extend(Path(path) for path in dependencies if Path(path).is_relative_to(ROOT / 'tests/compute_models')
               or Path(path).is_relative_to(ROOT / 'engine/inference'))
    own.extend(ROOT / row['path'] for row in read(BASE / 'after-pins.json'))
    own = list(dict.fromkeys(path.resolve() for path in own))
    frozen = []
    for source in own:
        record = pin(source)
        output = target / 'source' / source.relative_to(ROOT)
        output.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, output)
        assert pin(source) == record
        frozen.append(dict(record, frozen_path=str(output)))
    save(target / 'frozen-sources.json', frozen)
    selected = target / 'source/tests/compute_models' / source_name
    compile_command = []
    skip = False
    for flag in command:
        if skip:
            skip = False
            continue
        if flag == '/sourceDependencies':
            skip = True
            continue
        if flag.startswith(('/Fo', '/Fd')) or flag.endswith(source_name):
            continue
        compile_command.append(flag)
    compile_command += ['/sourceDependencies', str(target / 'deps.json'), str(selected),
                        '/Fo' + str(target / 'consumer.obj')]
    env = old.discover_environment(compiler='msvc', cache={
        'CMAKE_C_COMPILER': compile_command[0], 'CMAKE_CXX_COMPILER': compile_command[0],
        'CMAKE_GENERATOR': 'Ninja'}, backends=()).env
    old.b.execute(compile_command, env, target / 'compile', timeout=240)
    actual_deps = [pin(path) for path in read(target / 'deps.json')['Data']['Includes']]
    save(target / 'actual-dependencies.json', actual_deps)
    for row in frozen:
        assert pin(row['path']) == {k: row[k] for k in ('path', 'bytes', 'sha256')}
    base_path = ROOT / '.scratch/dspark-random-mtp-20261024/link-command.json'
    link_command = [flag for flag in read(base_path) if not flag.upper().startswith(('/OUT:', '/IMPLIB:', '/MAP:', '/PDB:'))
                    and not flag.endswith('dspark-random-mtp-20261024\\consumer.obj')]
    link_command.insert(1, str(target / 'consumer.obj'))
    link_command += ['/OUT:' + str(target / 'checks.exe'), '/IMPLIB:' + str(target / 'checks.lib')]
    save(target / 'reused-link-plan.json', {'base': pin(base_path), 'new_consumer_tus': 1,
        'new_sdk_tus': 0, 'new_downloads': 0, 'new_object': pin(target / 'consumer.obj')})
    old.b.execute(link_command, env, target / 'link', timeout=120)
    dll = ROOT / '.scratch/mtp-full-quant-20261024/f32-paged-check/attempt3/native-link/hyle_ggml_cpu_gdn_scale_v3.dll'
    os.link(dll, target / dll.name)
    save(target / 'ready.json', {'image': pin(target / 'checks.exe'), 'native_runtime': pin(target / dll.name),
        'source': pin(selected), 'new_consumer_tus': 1, 'new_sdk_tus': 0, 'new_downloads': 0})
    print('READY', kind, flush=True)

def run(kind):
    target = folder(kind)
    ready = read(target / 'ready.json')
    assert pin(ready['image']['path']) == ready['image']
    env = {key: value for key, value in os.environ.items() if not key.startswith('HYLE_GLM')}
    source = ROOT / '.scratch/glm-random-mtp-20261024'
    inputs = source / ('pro/run1-inputs.json' if kind == 'pro' else 'run1-inputs.json')
    env.update(read(inputs))
    env.update(PATH=str(target) + ';' + read(ROOT / '.scratch/dspark-random-mtp-20261024/runtime.json')['PATH'],
               HF_HUB_OFFLINE='1', TRANSFORMERS_OFFLINE='1')
    for key in ('HYLE_GLM_Q30_WAIT_FOR_EXPERTS', 'HYLE_GLM_MLX_WAIT_FOR_EXPERTS',
                'HYLE_GLM_GGUF_FLASH_WAIT_FOR_EXPERTS', 'HYLE_GLM_GGUF_WAIT_FOR_EXPERTS'):
        env[key] = '0'
    save(target / 'run-inputs.json', {key: value for key, value in env.items()
         if key.startswith(('HYLE_GLM', 'HF_', 'TRANSFORMERS_'))})
    case = ('GlmProMtpStateConsumer.CudaOriginalTarget77AndNextNRandomVerifierContinuesAtomically' if kind == 'pro'
            else 'GlmMtpStateConsumer.CudaOriginalTarget43And44AndNextNFullVocabularyVerifier')
    output = target / 'run1'
    command = [str(target / 'checks.exe'), '--gtest_filter=' + case,
               '--gtest_output=xml:' + str(output / 'results.xml')]
    old.b.execute(command, env, output, timeout=600)
    tree = ET.parse(output / 'results.xml').getroot()
    assert int(tree.get('tests', '0')) == 1
    assert int(tree.get('failures', '0')) == int(tree.get('errors', '0')) == int(tree.get('disabled', '0')) == 0
    cases = list(tree.iter('testcase'))
    assert len(cases) == 1 and cases[0].find('skipped') is None
    save(output / 'summary.json', {'passed': True, 'case': case, 'tests': 1, 'skips': 0,
         'image': ready['image'], 'scope': 'finite original-role K1 shared-selector migration; not whole-model quality or throughput',
         'properties': {p.get('name'): p.get('value') for p in cases[0].iter('property')}})
    print('PASS', kind, case, flush=True)

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('action', choices=('build', 'run'))
    parser.add_argument('kind', choices=('flash', 'pro'))
    args = parser.parse_args()
    globals()[args.action](args.kind)
