from pathlib import Path
import hashlib
import json
import re
import zipfile

BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[2]

def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))

def save(path, value):
    Path(path).write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8')

def pin(path):
    path = Path(path).resolve()
    return {'path': str(path), 'bytes': path.stat().st_size,
            'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}

def decision_lines(kind, path, case):
    text = Path(path).read_text(encoding='utf-8', errors='replace')
    start = re.search(r'\[\s*RUN\s*\]\s+' + re.escape(case) + r'\s*\n', text)
    assert start, (path, case)
    tail = text[start.end():]
    end = re.search(r'\[\s*(?:OK|FAILED)\s*\]\s+' + re.escape(case) + r'\b', tail)
    assert end, (path, case)
    return [line for line in tail[:end.start()].splitlines() if
            ('GLM full-V verifier scenario=' in line if kind == 'flash' else
             'GLM Pro K1 stochastic=' in line or 'GLM PRO RANDOM BOUNDARY' in line or 'GLM PRO RANDOM TAIL' in line)]

baseline = read(BASE / 'baseline-observations.json')
summary = {'status': 'complete', 'scope': 'GLM K1 direct shared AcceptedPrefix consumer migration',
    'new_consumer_tus': 2, 'new_sdk_tus': 0, 'new_downloads': 0,
    'whole_model_generation_or_quality': False, 'throughput_evidence': False,
    'source_checks': read(BASE / 'source-checks.json'), 'cases': []}
cleanup = []
sources = {}
archive_files = {}
for old in baseline:
    kind = old['kind']
    folder = BASE / kind / 'attempt1'
    result = read(folder / 'run1/summary.json')
    process = read(folder / 'run1/process.json')
    assert result['passed'] and result['tests'] == 1 and result['skips'] == 0
    assert process['exit'] == 0 and not process['timed_out']
    props = result['properties']
    common = [key for key in old['properties'] if key in props and not any(
        word in key.lower() for word in ('seconds', 'elapsed', 'time', 'tps', 'tokens_per_second'))]
    different = {key: {'before': old['properties'][key], 'after': props[key]}
                 for key in common if old['properties'][key] != props[key]}
    lines = decision_lines(kind, folder / 'run1/stdout.log', result['case'])
    item = {'kind': kind, 'case': result['case'], 'process': pin(folder / 'run1/process.json'),
        'image': read(folder / 'ready.json')['image'], 'tests': 1, 'failures': 0, 'errors': 0, 'skips': 0,
        'baseline': {'xml': pin(ROOT / old['xml']), 'stdout': pin(ROOT / old['stdout']), 'case': old['case']},
        'non_time_properties': {'common_count': len(common), 'differences': different,
            'added': {key: value for key, value in props.items() if key not in old['properties']},
            'removed': {key: value for key, value in old['properties'].items() if key not in props}},
        'actual_decision_lines': lines, 'baseline_decision_lines': old['decision_lines'],
        'decisions_identical': lines == old['decision_lines'],
        'actual_coverage': ('actual original target43/44 + NextN, natural K1 and separately labelled match/reject fixtures, actual row pending leases, full state repair/catchup, cancellation/stale publish and continued Head' if kind == 'flash' else
            'actual original target77 + NextN stochastic K1 with original q/residual lease, complete selected state plus cursor, one-row quota/context and EOS controls, failure/cancellation/stale publication, pending consumption and target continuation'),
        'not_run': 'other publishers, CPU, K2 filters and whole models; K2 registrations compiled into this TU do not count as executed coverage'}
    summary['cases'].append(item)
    for row in read(folder / 'frozen-sources.json'):
        path = Path(row['path']).relative_to(ROOT)
        actual = pin(row['frozen_path'])
        assert actual['bytes'] == row['bytes'] and actual['sha256'] == row['sha256']
        key = path.as_posix()
        if key in sources:
            assert sources[key]['sha256'] == row['sha256']
        else:
            sources[key] = row
            archive_files['source/' + key] = Path(row['frozen_path'])
    for part in ('compile', 'link', 'run1'):
        for path in (folder / part).iterdir():
            if path.is_file() and path.suffix in ('.json', '.log', '.xml'):
                archive_files[path.relative_to(BASE).as_posix()] = path
    for name in ('ready.json', 'actual-dependencies.json', 'frozen-sources.json', 'reused-link-plan.json', 'run-inputs.json'):
        archive_files[(folder / name).relative_to(BASE).as_posix()] = folder / name
    for name in ('consumer.obj', 'checks.exe', 'checks.exp', 'checks.lib', 'hyle_ggml_cpu_gdn_scale_v3.dll'):
        path = folder / name
        assert path.is_file()
        cleanup.append(dict(pin(path), hardlink=(path.suffix == '.dll'),
            source_runtime=('C:/public/project-hyle/hyle/.scratch/mtp-full-quant-20261024/f32-paged-check/attempt3/native-link/hyle_ggml_cpu_gdn_scale_v3.dll' if path.suffix == '.dll' else None)))

summary['tests'] = 2
summary['skips'] = summary['failures'] = summary['errors'] = 0
summary['actual_baseline_decisions_all_identical'] = all(row['decisions_identical'] for row in summary['cases'])
summary['canonical_after_pins'] = read(BASE / 'after-pins.json')
summary['source_boundary'] = 'shared selector-required two-ID emission scratch is cold-reserved; no new wrapper, alias, state table, Graph, sampler or executable controller; original leases and Head transaction retained'
save(BASE / 'cleanup-candidates.json', {'candidates': cleanup, 'logical_bytes': sum(row['bytes'] for row in cleanup),
    'deletion_performed': False, 'scope': 'only this batch two consumer OBJ/EXE/EXP/LIB and staged native DLL hardlinks; logical sizes are not promised physical reclamation'})
for path in (BASE / 'before').rglob('*'):
    if path.is_file():
        archive_files[path.relative_to(BASE).as_posix()] = path
for name in ('before-pins.json', 'after-pins.json', 'changes.patch', 'source-checks.json', 'baseline-observations.json',
             'cleanup-candidates.json', 'check.py', 'package.py'):
    archive_files[name] = BASE / name
archive = BASE / 'proof.zip'
assert not archive.exists()
with zipfile.ZipFile(archive, 'x', zipfile.ZIP_DEFLATED, compresslevel=6) as output:
    for name, path in sorted(archive_files.items()):
        assert path.suffix.lower() not in ('.bin', '.exe', '.obj', '.lib', '.exp', '.dll', '.pdb')
        output.write(path, name)
summary['archive'] = pin(archive)
summary['cleanup_candidates'] = pin(BASE / 'cleanup-candidates.json')
save(BASE / 'proof-summary.json', summary)
print(json.dumps({'status': summary['status'], 'tests': 2, 'baseline_decisions_equal': summary['actual_baseline_decisions_all_identical'],
                  'archive': summary['archive'], 'cleanup_logical_bytes': sum(row['bytes'] for row in cleanup)}, indent=2))
