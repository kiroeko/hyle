from pathlib import Path
import hashlib, json, zipfile

R=Path(__file__).resolve().parents[2]
D=Path(__file__).resolve().parent
O=R/'docs/evidence/correctness'
NAME='inference-k1-acceptance-2026-10-24'
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def pin(p):return dict(path=p.relative_to(R).as_posix(),bytes=p.stat().st_size,
                       sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def save(p,v):p.write_text(json.dumps(v,indent=2,ensure_ascii=False)+'\n',encoding='utf8')

qwen=read(D/'qwen/proof-summary.json')
glm=read(D/'glm/proof-summary.json')
assert qwen['state']=='passed' and glm['status']=='complete'
assert len(glm['cases'])==2 and all(c['tests']==1 and
    not(c['failures']or c['errors']or c['skips'])for c in glm['cases'])
assert all(read(D/'source-only.json')['checks'].values())
assert read(D/'glm/source-checks.json')['wrappers_removed']
for manifest in [D/'after-pins.json',D/'glm/after-pins.json']:
    for row in read(manifest):
        p=Path(row['path'])
        if not p.is_absolute():p=R/p
        assert pin(p)['sha256']==row['sha256']
additional=['source-only.json','after-pins.json','changes.patch','integration-review.md','publish.py']
assert all((D/name).is_file()for name in additional)
archives=[D/'qwen/proof.zip',D/'glm/proof.zip']
for p in archives:
    assert p.is_file()
    with zipfile.ZipFile(p)as z:
        assert z.testzip()is None
        assert all(not i.is_dir()and Path(i.filename).suffix not in
                   {'.exe','.obj','.lib','.exp','.pdb','.dll'} for i in z.infolist())
archive=O/(NAME+'.zip');assert not archive.exists()
allowed={'.cc','.h','.py','.md','.json','.jsonl','.log','.patch','.txt','.xml','.ids','.bf16'}
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9)as out:
    for folder,original in zip(['qwen','glm'],archives):
        with zipfile.ZipFile(original)as z:
            for item in z.infolist():out.writestr(folder+'/'+item.filename,z.read(item))
    for p in sorted((D/'before').rglob('*')):
        if p.is_file()and p.suffix in allowed:out.write(p,'additional/'+p.relative_to(D).as_posix())
    for name in additional:out.write(D/name,'additional/'+name)
    for name in ['glm/before-pins.json','glm/after-pins.json','glm/source-checks.json','glm/changes.patch','glm/independent-review.json']:
        out.write(D/name,'additional/'+name)
    for name in ['engine/models/qwen35/main.cc','tests/compute_models/glm_target_verifier_fragment.h',
                 'tests/compute_models/glm_mtp_state_consumer_test.cc',
                 'tests/compute_models/glm_pro_mtp_state_consumer_test.cc']:
        out.write(R/name,'canonical/'+name)
report=dict(state='passed',date='2026-10-24',
 scope='Qwen classic K1/m0 and GLM original-role K1 consumers directly share existing AcceptedPrefix/selectors; original model state and atomic publication remain model-owned.',
 changes=['Qwen manual K1 boundary policy replaced with existing shared greedy/sampled selection; no graph, dtype or RNG-address change.',
          'GLM duplicate Checkpoint/K1Decision/decide_k1 removed; real pending leases and complete StateHead candidate/repair/publication preserved.',
          'GLM model verifier header is graph construction only; policy dependencies belong directly to consumers, with cold emitted scratch reuse.'],
 actual_qwen_old_current=qwen,actual_GLM_components=glm,
 source_review=dict(qwen=read(D/'source-only.json'),glm=read(D/'glm/source-checks.json'),
                    independent_GLM=read(D/'glm/independent-review.json'),integration=pin(D/'integration-review.md')),
 limitations=['Qwen fixture is untrained A-only; GLM tests are original-role component journeys with their existing upstream/history boundaries.',
              'Qwen actual accepted-proposal quota/EOS clipping was not reached; current host selector boundary evidence is separate.',
              'No full-model quality, all-platform, performance, new state-container or whole-architecture completion claim.'],
 HTTP_requests=0,downloads_bytes=0,SDK_builds=0,archive=pin(archive),
 cleanup='Private rebuildable binaries removed through root test.ps1 after publication; source, commands, results and original caches retained.')
save(O/(NAME+'.json'),report)
print(json.dumps(dict(report=pin(O/(NAME+'.json')),archive=pin(archive))))
