# One accepted-prefix result, original model state ownership

The existing `mtp_acceptance.h` is unchanged. Qwen classic K1 and target-only
MTP tails now use it directly, like the existing recursive verifier. GLM's local
Checkpoint/K1Decision/decide_k1 wrappers are removed. No new publisher, state
container, registry or second port declaration was introduced.

The important distinction is `consumed` versus `consumed_drafts`: the current
pending input is mandatory, so consuming no draft still selects after-current.
An accepted proposal stopped by EOS/quota remains pending rather than entering
KV. A fully accepted K1 consumes two inputs and leaves the bonus pending.

Qwen keeps its original graph-produced first/second diagnostics. Stochastic K1
passes the actual acceptance predicate and original residual/bonus final ID;
it does not resample or change p/q, graph math, dtypes or RNG reservations.
All main source outside the policy block remains unchanged. Existing emitted
capacity covers the stack-only selection inputs without a new hot allocation.

GLM greedy retains its original quota2/no-EOS component contract. The stochastic
path keeps the real q lease for an accepted-but-unconsumed proposal, otherwise
the real decision output. Host scalar next_id stays diagnostic; no selected ID
is uploaded back into state. Scalar-count diagnostic narrowing remains bounded
to K1's 0/1 values. Selection scratch is reserved outside finite control loops.

Complete state construction, repair, original pending leases, RNG metadata and
expected-base publication remain with the model. Qwen's whole-batch preflight
and nonthrowing publication differ from Compute StateHead's single-head atomic
publication. An extra callback publisher would hide that distinction.

Qwen old/current finite runs compare actual result, ledger, RNG and full logical
state with no timing-field exclusions. GLM uses existing original-role component
assertions; these are not whole-model quality or throughput claims. Runtime
coverage and unexercised limits are kept explicit in the separate summaries.
