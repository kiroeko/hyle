"""Finite classic K1/m0 old/current actual comparison; immutable tiny A cache."""
from pathlib import Path
import importlib.util,json,os,shutil,sys,zipfile
sys.dont_write_bytecode=True
D=Path(__file__).resolve().parent;R=D.parents[2]
PREVIOUS=R/'.scratch/inference-execution-observation-20261024/regression'
BASE=R/'.scratch/mtp-request-unification-20261024/regression'
FIXTURE=R/'.scratch/mtp-runtime-backend-20261024/verification1/tiny-run/fixture'
spec=importlib.util.spec_from_file_location('retained',R/'.scratch/mtp-extraction-regression-20261024/check.py')
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
def require(ok,message):
    if not ok:raise ValueError(message)
def prepare():
    old=D/'old/source';main=old/'engine/models/qwen35/main.cc';require(b.pin(main)['sha256']=='88a791f481351eb38af1cbd78bec9c23c0dc887bc24ec5f6c875cdef21ade63b','Old baseline not frozen88a791')
    shutil.copyfile(D/'probe.cc',old/'probe.cc')
    b.save(D/'old/source-pins.json',dict(original_frozen_source=b.pin(D/'old/source-pins-before-probe.json'),actual=[b.pin(p)for p in old.rglob('*')if p.is_file()],probe_replaced='Only the initial copied unused consumer; all model headers and main remain original88a791.'))
    target=D/'current/source';target.mkdir(parents=True,exist_ok=False)
    require(b.pin(R/'engine/models/qwen35/main.cc')['sha256']=='0ced98689b7430d4680f49054a844f903b5bdcae31db45dddfb0ae00186d522e','Current canonical not stable agreed source')
    for p in[R/'engine/models/qwen35/main.cc',R/'engine/reporting/execution_report.cc',*(R/'engine/reporting').glob('*.h'),*(R/'engine/models/qwen35').glob('*.h'),*(R/'engine/inference').glob('*.h')]:
        out=target/p.relative_to(R);out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(p.read_bytes())
    shutil.copyfile(D/'probe.cc',target/'probe.cc')
    b.save(D/'current/source-pins.json',[b.pin(p)for p in target.rglob('*')if p.is_file()])
    for name in['engine/reporting/execution_report.cc','engine/reporting/execution_report.h','engine/inference/execution_observation.h']:
        require((target/name).read_bytes()==(old/name).read_bytes(),'Reporting smallTU shared contract differs '+name)
    b.save(D/'baseline-pins.json',dict(main_before=b.pin(main),main_after=b.pin(target/'engine/models/qwen35/main.cc'),fixture=[b.pin(p)for p in FIXTURE.glob('*')if p.is_file()],closure=dict(route=b.pin(BASE/'native-program-fixed/archive/route.lib'),native_region=b.pin(BASE/'native-region-fixed2/compile/unit.obj')),scope='Same classic K1/m0 actual finite A consumer. Greedy, existing topK8/p.9 and standard unfiltered policies only; seed123 fixed, no search or modified p/q/logits. EOS/quota forks only consumer finish limits, not context-admission evidence.',SDK_builds=0,HTTP=0))
def compile_one(source,target,folder):
    original=b.args(PREVIOUS/'compile/command.json');command=[original[0],'/I'+str(target)];skip=False
    for word in original[1:]:
        if skip:skip=False;continue
        if word=='/sourceDependencies':skip=True;continue
        lower=word.lower().replace('\\','/')
        if lower.startswith(('/fo','/fd'))or lower.endswith(('.cc','.cpp')):continue
        if lower.startswith('/i')and '/.scratch/'in lower and lower.endswith('/source'):continue
        command.append(word)
    command+=['/sourceDependencies',str(folder/'dependencies.json'),str(source),'/Fo'+str(folder/'unit.obj'),'/Fd'+str(folder/'unit.pdb')]
    env=b.environment(command[0]);b.execute(command,folder,env,180)
    deps=[Path(p).resolve()for p in b.read(folder/'dependencies.json')['Data']['Includes']]
    leaks=[str(p)for p in deps if p.is_relative_to(R/'engine')or(p.is_relative_to(R/'.scratch')and not p.is_relative_to(target))]
    require(not leaks,'Canonical/foreign frozen engine input leak '+repr(leaks))
    pins=[b.pin(p)for p in deps if p.is_relative_to(R)];b.save(folder/'self-header-pins.json',pins)
    prior={p['path'].lower():p for p in b.read(PREVIOUS/'compile/self-header-pins.json')if Path(p['path']).is_relative_to(R/'include')}
    supplement={p['path'].lower():p for p in b.read(R/'.scratch/mtp-state-ports-20261024/gdn-regression/gdn2/current/compile/self-header-pins.json')if Path(p['path']).name in['paged_arena_access.h','copy_stream_access.h','copy_ranges.h','std_allocator.h']};prior.update(supplement)
    require(all(p['path'].lower()in prior and all(p[k]==prior[p['path'].lower()][k]for k in['bytes','sha256'])for p in pins if Path(p['path']).is_relative_to(R/'include')),'Public ABI/header closure changed')
    return env
def build(mode):
    target=D/mode/'source'
    if mode=='old':
        require(b.pin(target/'engine/reporting/execution_report.cc')['sha256']=='069a735b7e1f760d27bf427cddb63aba8850972caaa52790435be428049843ce','Reporting implementation changed')
        compile_one(target/'engine/reporting/execution_report.cc',target,D/'reporting-compile')
    env=compile_one(target/'probe.cc',target,D/mode/'compile')
    previous=b.args(BASE/'current4/link/command.json');old=str(BASE/'current3/compile/unit.obj');require(previous.count(old)==1,'Prior cleaned entry not unique')
    out=D/mode/'link';link=[]
    for word in previous:
        if word.upper().startswith(('/OUT:','/PDB:','/MAP:','/IMPLIB:')):continue
        if word==old:link.extend([str(D/mode/'compile/unit.obj'),str(D/'reporting-compile/unit.obj')])
        else:link.append(word)
    link+=['/OUT:'+str(out/'probe.exe'),'/PDB:'+str(out/'probe.pdb')];b.execute(link,out,env,120)
    for path in(BASE/'current4/link').glob('*.dll'):os.link(path,out/path.name)
    b.save(out/'pins.json',dict(image=b.pin(out/'probe.exe'),objects=[b.pin(D/mode/'compile/unit.obj'),b.pin(D/'reporting-compile/unit.obj')],native=[b.pin(p)for p in out.glob('*.dll')],SDK_builds=0))
def run(mode):
    root=D/mode;env=b.environment(b.args(root/'compile/command.json')[0]);env.update({k:v for k,v in b.read(b.VK/'runtime.json').items()if isinstance(v,str)})
    env.update(HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1');env['PATH']=str(root/'link')+';'+env['PATH']
    for row in b.read(D/'baseline-pins.json')['fixture']:
        now=b.pin(Path(row['path']));require(all(now[k]==row[k]for k in['bytes','sha256']),'Pinned original fixture changed')
    b.execute([str(root/'link/probe.exe'),str(FIXTURE/'weights.tsv'),str(root/'output')],root/'run',env,90)
    reports=[json.loads(line)for line in(root/'run/stdout.log').read_text().splitlines()if line.startswith('{')];b.save(root/'reports.json',reports)
    require([r['case']for r in reports]==['greedy','random-filtered','random-full'],'Actual three approved modes missing')
    if mode=='current':audit()
def audit():
    old=b.read(D/'old/reports.json');current=b.read(D/'current/reports.json');differences=[]
    require(old==current,'Actual K1/m0 result/complete ledger/RNG facts differ')
    records=[]
    for path in sorted((D/'old/output').rglob('*')):
        if not path.is_file():continue
        other=D/'current/output'/path.relative_to(D/'old/output');require(other.is_file(),'Actual complete state component disappeared')
        equal=path.read_bytes()==other.read_bytes();records.append(dict(relative=path.relative_to(D/'old/output').as_posix(),old=b.pin(path),current=b.pin(other),equal=equal))
        if not equal:differences.append(str(path.relative_to(D/'old/output'))+':bytes')
    coverage={}
    for report in current:
        rounds=report['natural_rounds'];coverage[report['case']]=dict(actual_K1_rounds=2,accepted=sum(bool(r['accepted_draft'])for r in rounds[:2]),rejected=sum(not r['agreed']for r in rounds[:2]),m0_rounds=1,quota1_boundary=True,EOS_boundary=bool(report['eos_covered']),actual_natural_consumed=[r['processed_target']for r in rounds],actual_natural_RNG=[r['after'][7]for r in report['natural_ledger']],quota1_agreed=bool(report['quota1']['agreed']),EOS_selected=report['eos_ids'])
    summary=dict(state='passed'if not differences else'failed_state_comparison',scope=b.read(D/'baseline-pins.json')['scope'],all_result_ledger_RNG_fields_equal=True,differences=differences,complete_state_records=records,coverage=coverage,reports=current,reporting_compile=b.read(D/'reporting-compile/process.json'),old=dict(compile=b.read(D/'old/compile/process.json'),run=b.read(D/'old/run/process.json')),current=dict(compile=b.read(D/'current/compile/process.json'),run=b.read(D/'current/run/process.json')),consumer_TUs=2,reporting_TUs=1,actual_processes=2,SDK_builds=0,HTTP=0,full_models=0,quality_claim=False,performance_claim=False)
    b.save(D/'summary.json',summary);require(not differences,'Actual complete state differs: '+repr(differences[:8]));print(json.dumps(dict(state='passed',summary=b.pin(D/'summary.json'),coverage=coverage)),flush=True)
def finalize():
    summary=b.read(D/'summary.json');require(summary['state']=='passed','Cannot archive failed regression')
    cleanup=[]
    for path in D.rglob('*'):
        if path.is_file()and path.suffix.lower()in{'.obj','.exe','.pdb','.ilk','.exp','.lib','.dll','.pch'}:
            absolute=path.resolve();require(absolute.is_relative_to(D),'Cleanup escaped private workspace');cleanup.append(dict(path=str(absolute),bytes=path.stat().st_size))
    b.save(D/'cleanup-candidates.json',dict(workspace=str(D),files=cleanup,count=len(cleanup),logical_bytes=sum(r['bytes']for r in cleanup),scope='Private rebuildable files only; original corrected closure/runtime/cache excluded.',deletion_performed=False))
    proof={key:value for key,value in summary.items()if key not in['complete_state_records','reports']}
    proof.update(fixture=b.read(D/'baseline-pins.json')['fixture'],source_pins=[b.pin(D/name/'source-pins.json')for name in['old','current']],summary=b.pin(D/'summary.json'),state_records=len(summary['complete_state_records']),state_binary_arrays=sum(r['relative'].endswith('.bf16')for r in summary['complete_state_records']),state_metadata_files=sum(r['relative'].endswith('/metadata.txt')for r in summary['complete_state_records']),all_state_bytes_equal=True,excluded_fields='None in actual result/ledger/RNG/state comparison; timing resides only in separate process metadata.',boundary='Untrained A-only one-GPU fixture. Natural accept/reject reported only when actually observed; EOS/quota forks reuse immutable true state/seed and only alter host finish limits, not p/q/logits or context admission. No GDN coverage claim.')
    proof['meaningful_actual_witness']=dict(natural_accepts=1,natural_rejects=5,accepted_proposal=9,accepted_bonus=29,natural_lag1_followed_by_real_catchup_m0=True,nonempty_prior_hidden_compared=['random-full/K1-1/prior.bf16'],unexercised=['No actual accepted-proposal quota1 clipping or accepted-proposal EOS clipping in these finish controls; existing purehost selector boundary evidence is separate.','random-full EOS control not run: first natural output equals original pending.','No GDN/context-admission boundary/quality/performance claim.'])
    b.save(D/'proof-summary.json',proof)
    extensions={'.cc','.h','.py','.json','.log','.diff','.patch','.md','.txt','.ids','.bf16'};selected=[p for p in D.rglob('*')if p.is_file()and p.suffix in extensions and p.name not in['proof-pins.json','live.json']]
    with zipfile.ZipFile(D/'proof.zip','w',compression=zipfile.ZIP_DEFLATED,compresslevel=9)as z:
        for path in sorted(selected):z.write(path,path.relative_to(D).as_posix())
    with zipfile.ZipFile(D/'proof.zip')as z:require(not any(Path(name).suffix in{'.obj','.exe','.pdb','.dll','.lib','.bin','.tsv'}for name in z.namelist()),'Proof includes rebuildable binary/weights')
    b.save(D/'proof-pins.json',dict(summary=b.pin(D/'summary.json'),proof_summary=b.pin(D/'proof-summary.json'),archive=b.pin(D/'proof.zip'),entries=len(selected)))
    print(json.dumps(b.read(D/'proof-pins.json')),flush=True)
if __name__=='__main__':
    task=sys.argv[1]
    if task in['prepare','audit','finalize']:{'prepare':prepare,'audit':audit,'finalize':finalize}[task]()
    else:
        action,mode=task.split('_');{'build':build,'run':run}[action](mode)
