// Finite untrained A-only actual classic K1/m0 boundary regression.
#include "engine/models/qwen35/main.cc"
#include "hyle/compute/detail/paged_arena_access.h"
namespace q=qwen35;
void require(bool yes,const char* message){if(!yes)throw std::runtime_error(message);}
q::ModelGeometry geometry(){
  q::ModelGeometry s;s.hidden=64;s.intermediate=128;s.vocabulary=64;
  s.query_heads=s.kv_heads=1;s.key_depth=s.value_depth=s.rotary=64;
  s.gdn_key_heads=s.gdn_value_heads=1;s.gdn_key_depth=s.gdn_value_depth=64;
  s.conv_kernel=4;s.context_limit=16;s.rope_theta=10000;s.epsilon=1.e-6F;
  s.tied_head=true;s.layers="A";s.mtp_layers=1;s.validate();return s;
}
using Bytes=std::vector<std::byte>;
Bytes lease_bytes(q::Model& model,const q::c::ReadLease& lease){
  if(!lease.valid())return{};Bytes bytes(lease.size());q::check(model.execution.read(q::take(lease.view()),bytes));return bytes;
}
Bytes logical_rows(q::Model& model,const q::c::PagedArena& arena,const q::c::PagedArenaRead& frame,std::size_t rows,std::size_t row_bytes){
  const auto layout=frame.layout().host();const auto pages=(rows+15)/16;
  require(frame.valid()&&layout.page_indices.size()==pages&&frame.page_count()==pages,"logical state page footprint differs");
  Bytes bytes(rows*row_bytes);std::size_t at=0;const auto guards=q::c::detail::PagedArenaAccess::pages(frame);
  for(std::size_t i=0;i<pages;++i){
    const q::c::ReadLease* selected=nullptr;
    for(const auto& guard:guards)if(q::take(q::c::detail::PagedArenaAccess::page(arena,guard))==static_cast<std::uint32_t>(layout.page_indices[i]))selected=&guard;
    require(selected!=nullptr,"state page lost original read guard");const auto count=(std::min)(16*row_bytes,bytes.size()-at);
    q::check(model.execution.read(q::take(q::take(selected->view()).subview(0,count)),std::span(bytes).subspan(at,count)));at+=count;
  }return bytes;
}
using Image=std::map<std::string,Bytes>;
Image image(q::Model& model,const q::cache::Snapshot& head){
  Image result;require(head.state.size()==1&&!model.geometry.is_gdn(0),"mixed control must use the exact original A fixture");
  require(head.keys.size()==1&&head.values.size()==1,"mixed A state bank count differs");
  result.emplace("target.key.bf16",logical_rows(model,model.page_inventory.keys[0],head.keys[0],head.length,static_cast<std::size_t>(model.geometry.key_row_bytes())));
  result.emplace("target.value.bf16",logical_rows(model,model.page_inventory.values[0],head.values[0],head.length,static_cast<std::size_t>(model.geometry.value_row_bytes())));
  if(head.carry_hidden)result.emplace("carry.bf16",lease_bytes(model,head.carry_hidden));
  if(head.prior_hidden)result.emplace("prior.bf16",lease_bytes(model,head.prior_hidden));
  if(head.draft){
    result.emplace("draft.key.bf16",logical_rows(model,model.draft_inventory.keys[0],head.draft->key,head.draft->frontier,static_cast<std::size_t>(model.geometry.key_row_bytes())));
    result.emplace("draft.value.bf16",logical_rows(model,model.draft_inventory.values[0],head.draft->value,head.draft->frontier,static_cast<std::size_t>(model.geometry.value_row_bytes())));
  }
  std::ostringstream meta;meta<<"length="<<head.length<<" next="<<head.next_id<<" seed="<<head.sampling.seed<<" stream="<<head.sampling.stream<<" draw="<<head.sampling.draw;
  if(head.draft)meta<<" frontier="<<head.draft->frontier<<" lag="<<head.draft->lag<<" catchup="<<head.draft->catchup_token;
  const auto text=meta.str();result.emplace("metadata.txt",Bytes(reinterpret_cast<const std::byte*>(text.data()),reinterpret_cast<const std::byte*>(text.data()+text.size())));return result;
}
void dump(const std::filesystem::path& folder,const Image& data){
  std::filesystem::create_directories(folder);
  for(const auto& [name,bytes]:data){std::ofstream out(folder/name,std::ios::binary);out.write(reinterpret_cast<const char*>(bytes.data()),static_cast<std::streamsize>(bytes.size()));require(bool(out),"cannot record finite state bytes");}
}
template<class Values>void numbers(std::ostream& out,const Values& values){out<<'[';bool comma=false;for(const auto value:values){out<<(comma?",":"")<<value;comma=true;}out<<']';}
void boundary(std::ostream& out,const q::GenerationBoundary& value){
  out<<'['<<value.length<<','<<value.frontier<<','<<value.lag<<','<<value.next_id<<','<<value.catchup_token<<','<<value.sampling.seed<<','<<value.sampling.stream<<','<<value.sampling.draw<<']';
}
void ledger_report(std::ostream& out,const q::GenerationLedger& ledger){
  out<<'[';
  for(std::size_t i=0;i<ledger.committed_count;++i){const auto& r=ledger.records[i];out<<(i?",":"")<<"{\"role\":"<<static_cast<int>(r.role)<<",\"generation\":"<<r.generation<<",\"committed\":"<<r.committed<<",\"user_output\":"<<r.user_output<<",\"imported\":"<<r.imported
      <<",\"pending_input\":"<<r.pending_input<<",\"quota\":"<<r.quota<<",\"turn\":"<<r.turn<<",\"accepted\":"<<r.accepted<<",\"draft_rows\":"<<r.draft_rows<<",\"draft_limit\":"<<r.draft_limit<<",\"verified_rows\":"<<r.verified_rows<<",\"consumed_drafts\":"<<r.consumed_drafts
      <<",\"auxiliary_graph_calls\":"<<r.auxiliary_graph_calls<<",\"draft\":"<<r.draft<<",\"target_first\":"<<r.target_first<<",\"target_second\":"<<r.target_second<<",\"agreed\":"<<r.agreed<<",\"accepted_draft\":"<<r.accepted_draft<<",\"stopped\":"<<r.stopped
      <<",\"requests\":"<<r.requests<<",\"member_index\":"<<r.member_index<<",\"emitted_count\":"<<r.emitted_count<<",\"before\":";boundary(out,r.before);out<<",\"after\":";boundary(out,r.after);
    out<<",\"committed_ids\":";numbers(out,r.committed_ids());out<<",\"emitted\":";numbers(out,r.emitted);out<<",\"accepted_inputs\":";numbers(out,r.accepted_inputs);out<<",\"verification_inputs\":";numbers(out,r.verification_inputs);out<<'}';
  }out<<']';
}
void retired(const q::Model& model){require(!model.active_step&&!model.carrier_borrowed&&model.snapshot_versions.live==0,"completed K1 test retained a state version or execution carrier");}
void retire(std::shared_ptr<q::Session>& session){q::check(session->stop());q::check(session->drain());require(q::take(session->try_retire()),"K1 actual Session retirement incomplete");session.reset();}
void print_round(const q::MtpRoundResult& r){
  std::cout<<"{\"pending\":"<<r.pending<<",\"draft\":"<<r.draft<<",\"target_first\":"<<r.target_first<<",\"target_second\":"<<r.target_second<<",\"next_id\":"<<r.next_id<<",\"agreed\":"<<r.agreed<<",\"accepted_draft\":"<<r.accepted_draft<<",\"stopped\":"<<r.stopped
      <<",\"processed_target\":"<<r.processed_target<<",\"processed_draft\":"<<r.processed_draft<<",\"proposal_count\":"<<r.proposal_count<<",\"consumed_drafts\":"<<r.consumed_drafts<<",\"verified_rows\":"<<r.verified_rows<<",\"auxiliary_graph_calls\":"<<r.auxiliary_graph_calls<<",\"emitted\":";numbers(std::cout,r.emitted);std::cout<<'}';
}
q::MtpRoundResult step(q::Model& model,std::shared_ptr<q::Session>& session,q::GenerationLedger& ledger,
    bool single,std::size_t quota,std::span<const std::int32_t> eos,const std::filesystem::path& output){
  const auto old=session->head;const auto saved=image(model,*old);const std::array ids{old->next_id};
  const bool lag=old->draft->lag!=0;
  const auto role=single?(lag?q::GraphRole::kMtpCatchupSingle:q::GraphRole::kMtpSingle):(lag?q::GraphRole::kMtpCatchupRound:q::GraphRole::kMtpRound);
  q::prepare_generation_record(ledger,*session,role,ids,true,quota,0);
  model.prepare_evaluation(*session,ids,nullptr,role);model.submit_evaluation(*session);
  const q::EvaluationOutput selected{.session=session,.name="finite-K1",.trace_states=false,.generation_ledger=&ledger};
  const auto result=model.finish_mtp_round(*session,ids[0],quota,eos,&selected);
  require(result.pending==ids[0]&&result.proposal_count==(single?0U:1U)&&result.verified_rows==(single?1U:2U)&&
    result.processed_target>=1&&result.processed_target<=(single?1U:2U)&&session->length()==old->length+result.processed_target&&
    session->head->next_id==result.next_id&&!result.emitted.empty()&&result.emitted.size()<=quota,"actual K1/m0 completion boundary differs");
  if(single)require(!result.agreed&&!result.accepted_draft&&result.emitted.size()==1,"m0 fabricated a proposal acceptance");
  if(model.sampler.enabled)require(session->head->sampling==old->sampling.advanced(single?1:3),"K1/m0 actual RNG addresses changed");
  require(saved==image(model,*old),"K1/m0 mutated the complete committed old Snapshot");model.validate_mtp_snapshot(*session->head);
  dump(output,image(model,*session->head));return result;
}
void mode(const std::filesystem::path& manifest,const std::filesystem::path& output,std::string_view name,bool random,q::sampling::Policy policy){
  std::filesystem::create_directories(output);const auto shape=geometry();
  const auto plan=q::cache::plan(shape,16,4,2,q::recurrent_bytes(q::state_schema_for(shape,16),shape),1,2,true,true);
  q::Model model(manifest,shape,16,plan,{},false,q::ReplayPolicy::kCommands,16*1024*1024,
    {.enabled=random,.policy=policy,.seed=123},0,{.primary=hyle::inference::BackendKind::kVulkan});
  model.configure_draft_policy({.max_drafts=1});const std::array p2{std::size_t{2}},t1{std::size_t{1}};
  model.prepare_family(p2,false,1,q::GraphRole::kMtpPrefill);model.plan_replay_uses(2,1,1,q::GraphRole::kMtpPrefill);
  model.prepare_family(p2,false,1,q::GraphRole::kMtpRound);model.plan_replay_uses(2,1,4,q::GraphRole::kMtpRound);
  model.prepare_family(p2,false,1,q::GraphRole::kMtpCatchupRound);model.plan_replay_uses(2,1,1,q::GraphRole::kMtpCatchupRound);
  model.prepare_family(t1,false,1,q::GraphRole::kMtpSingle);model.plan_replay_uses(1,1,1,q::GraphRole::kMtpSingle);
  model.prepare_family(t1,false,1,q::GraphRole::kMtpCatchupSingle);model.plan_replay_uses(1,1,1,q::GraphRole::kMtpCatchupSingle);
  const std::array<std::int32_t,2> prompt{1,2};auto session=model.create_session(p2,{},q::GraphRole::kMtpPrefill);q::GenerationLedger ledger(4,2);
  q::prepare_generation_record(ledger,*session,q::GraphRole::kMtpPrefill,prompt,false,0,0);
  model.prepare_evaluation(*session,prompt,nullptr,q::GraphRole::kMtpPrefill);model.submit_evaluation(*session);
  (void)model.finish_evaluation(*session,"prefill",{},false,nullptr,nullptr,nullptr,nullptr,{},&ledger);
  auto base=session->head;const auto saved=image(model,*base);dump(output/"base",saved);
  std::array<q::MtpRoundResult,3> natural;
  natural[0]=step(model,session,ledger,false,2,{},output/"K1-0");
  natural[1]=step(model,session,ledger,false,2,{},output/"K1-1");
  natural[2]=step(model,session,ledger,true,1,{},output/"m0");
  require(ledger.committed_count==4&&saved==image(model,*base),"natural K1/m0 ledger or original Snapshot changed");
  q::GenerationLedger quota_ledger(1,2);auto quota_session=model.create_session({},base,q::GraphRole::kMtpPrefill);
  const auto quota=step(model,quota_session,quota_ledger,false,1,{},output/"quota1");
  require(quota.processed_target==1&&!quota.accepted_draft&&quota.emitted.size()==1,"quota1 consumed an emitted pending proposal");retire(quota_session);
  std::vector<std::int32_t> eos;
  for(auto token:natural[0].emitted)if(token!=base->next_id){eos.push_back(token);break;}
  q::GenerationLedger eos_ledger(1,2);q::MtpRoundResult stopped;bool eos_covered=false;
  if(!eos.empty()){
    auto stopped_session=model.create_session({},base,q::GraphRole::kMtpPrefill);
    stopped=step(model,stopped_session,eos_ledger,false,2,eos,output/"eos");
    require(stopped.stopped&&stopped.next_id==eos.front()&&stopped.emitted.back()==eos.front(),"actual EOS limit failed to retain terminal pending output");
    eos_covered=true;retire(stopped_session);
  }
  require(saved==image(model,*base)&&model.cache_usage().peak_bytes<=16*1024*1024,"boundary-control fork mutated shared evaluated state or exceeded finite budget");
  std::cout<<"{\"case\":\""<<name<<"\",\"sampling\":"<<random<<",\"temperature\":"<<policy.temperature<<",\"top_k\":"<<policy.top_k<<",\"top_p\":"<<policy.top_p<<",\"natural_rounds\":[";
  for(std::size_t i=0;i<natural.size();++i){if(i)std::cout<<',';print_round(natural[i]);}
  std::cout<<"],\"natural_ledger\":";ledger_report(std::cout,ledger);std::cout<<",\"quota1\":";print_round(quota);
  std::cout<<",\"quota1_ledger\":";ledger_report(std::cout,quota_ledger);std::cout<<",\"eos_covered\":"<<eos_covered<<",\"eos_ids\":";numbers(std::cout,eos);
  std::cout<<",\"eos_result\":";print_round(stopped);std::cout<<",\"eos_ledger\":";ledger_report(std::cout,eos_ledger);
  std::cout<<",\"old_snapshots_unchanged\":true,\"cache_limit\":16777216,\"quality_claim\":false,\"performance_claim\":false,\"forced_probability_or_logit\":false}\n";
  base.reset();retire(session);retired(model);
}
int main(int argc,char** argv){
  try{
    require(argc==3,"K1-consumer EXISTING_MANIFEST PRIVATE_OUTPUT");const std::filesystem::path output=argv[2];
    mode(argv[1],output/"greedy","greedy",false,{});
    mode(argv[1],output/"random-filtered","random-filtered",true,{1.F,8,.9F});
    mode(argv[1],output/"random-full","random-full",true,{1.F,0,1.F});return 0;
  }catch(const std::exception& error){std::cerr<<"finite K1 acceptance: "<<error.what()<<'\n';return 1;}
}
