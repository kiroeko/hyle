from pathlib import Path
import hashlib,json,zipfile
S=Path(__file__).resolve().parent;F=S.parent;A=F.parent;R=A.parents[1];B=F/'blockwise-w4a8';APPLE=A/'blockwise-w4a8/apple'
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def identity(p):return dict(path=str(p.relative_to(R)).replace('\\','/'),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def save(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
def archive(p,entries):
 if p.exists():
  with zipfile.ZipFile(p) as z:
   assert set(z.namelist())==set(entries)
   for n,source in entries.items():assert hashlib.sha256(z.read(n)).digest()==hashlib.sha256(source.read_bytes()).digest(),n
 else:
  with zipfile.ZipFile(p,'w',zipfile.ZIP_DEFLATED,compresslevel=8) as z:
   for name,source in sorted(entries.items()):z.write(source,name)
 with zipfile.ZipFile(p) as z:
  assert not z.testzip() and len(z.namelist())==len(entries)
 return dict(**identity(p),members=len(entries),entry_identities=[dict(entry=n,**identity(s)) for n,s in sorted(entries.items())])

research_entries={}
for prefix in ('mlx','kimi','fp8-kv','inferact'):
 for p in (F/prefix).rglob('*'):
  if p.is_file() and p.suffix.lower() in ('.json','.py','.md','.txt','.html','.part','.bin','.log'):
   research_entries[str(p.relative_to(F)).replace('\\','/')]=p
for name in ('fetch_inferact.py','summarize_inferact.py','update_catalog.py','catalog_followup.py','catalog-update.json','model-quantizations.before.json'):
 if (S/name).exists():research_entries['root/'+name]=S/name
research_path=R/'docs/evidence/research/fixed-role-binding-2026-10-21.zip'
research_archive=archive(research_path,research_entries)
research=dict(observed_on='2026-10-21',scope='Sixteen fixed artifact sources; six complete MLX index/header sets plus bounded sampled roles and producer-source review. No model numeric tensor payload, full artifact/model, quality or throughput execution.',
 artifact_indices=[4,5,11,12,19,20,21,22,24,25,26,27,28,29,31,32],archive={k:v for k,v in research_archive.items() if k!='entry_identities'},
 reports=[dict(entry=n,**identity(F/n)) for n in ('mlx/assessment.json','kimi/review.json','kimi/24/contract-review.json','fp8-kv/review.json','inferact/assessment.json')],
 summaries=dict(mlx=read(F/'mlx/assessment.json'),kimi=read(F/'kimi/review.json')['findings'],fp8_kv=read(F/'fp8-kv/review.json')['non_gaps_and_limits'],inferact=read(F/'inferact/assessment.json')),
 conclusions=[
  'All six MLX stored descriptor sets are resolved; mode/bits/scale dtype schema fits existing math. Flash46five-bit overrides expand to12387triples; all37338scale/bias pairs F16. Independent expert/head-bank resource/forward bridges remain delivery3.',
  'Kimi24 fixed producer source defines real additional group512 BF16 W4A8 math; implemented and tested separately, see correctness evidence. Packing alone did not justify the old W4A16 mapping.',
  'Kimi21 sampled root FP8 physical E4/BF16 block128 agrees over nested legacyMXFP4, but exact BF16 CT block/dynamic-QDQ consumer remains to qualify using ordinary ops.',
  'DeepSeek27 actual scale F32,25/26 someattention/shared E8M0. Fixed officialGA source requires dynamic power2 group128/floor1e-4 A; grouped descriptor currently lacks that mode.',
  'CacheStorage E4 alone does not supply nonCUDA paged KV or compactMLA consumers.29constant-amax cast recipe is not proof of specific artifact exporter equivalence;28/29exact stored KV scalar remains unbound.',
  'Inferact19 actual sampledU8/F32micro32 is not QuarkU8/E8M0; nibble/activation/macro/fused-row producer contract still unresolved.'
 ],
 catalog=identity(R/'docs/implementation/model-quantizations.json'),all33_artifact_execution_verified_false=all(x['provider_coverage']['artifact_execution_verified'] is False for x in read(R/'docs/implementation/model-quantizations.json')['artifacts']),
 operation_followup='../correctness/blockwise-w4a8-reference-2026-10-21.json',entry_identities=research_archive['entry_identities'])
save(research_path.with_suffix('.json'),research)

sources=['include/hyle/compute/model_ops.h','src/compute_ops/blockwise_w4a8.cc','src/compute_ops/CMakeLists.txt',
 'src/compute_provider_native/blockwise_w4a8.cc','src/compute_provider_native/native_plan.h','src/compute_provider_native/native_provider.cc','src/compute_provider_native/CMakeLists.txt',
 'src/compute_provider_cuda/blockwise_w4a8_kernel.h','src/compute_provider_cuda/blockwise_w4a8_kernel.cu','src/compute_provider_cuda/blockwise_w4a8_provider.h','src/compute_provider_cuda/blockwise_w4a8_provider.cc','src/compute_provider_cuda/cuda_provider.cc','src/compute_provider_cuda/CMakeLists.txt',
 'src/compute_route_apple/apple_blockwise_w4a8.h','src/compute_route_apple/apple_blockwise_w4a8.cc','src/compute_route_apple/apple_mature_float.cc','src/compute_route_apple/CMakeLists.txt',
 'src/compute_route_vulkan/vulkan_blockwise_w4a8.cc','src/compute_route_vulkan/vulkan_operations.cc','src/compute_route_vulkan/vulkan_tensor.h','src/compute_route_vulkan/build_shaders.py','src/compute_route_vulkan/shaders/blockwise_w4a8.comp','src/compute_route_vulkan/CMakeLists.txt',
 'src/compute_shader_shared/nvfp4_f32.h','src/compute_shader_shared/ct_packed.h','tests/compute_models/nvfp4_reference_fixture.h','tests/compute_models/blockwise_w4a8_fixture.h']
for arm in ('cpu','cuda','vulkan','apple'):sources+=['tests/graph_route_'+arm+'/blockwise_w4a8_test.cc','tests/graph_route_'+arm+'/CMakeLists.txt']
source_ids=[identity(R/p) for p in sources]
entries={'source/'+n:R/n for n in sources}
for root,prefix in ((B,'windows'),(APPLE,'apple')):
 for p in root.rglob('*'):
  if p.is_file() and p.suffix.lower() in ('.json','.py','.log','.xml','.txt','.diff','.cc','.cu','.h','.comp','.d'):
   entries[prefix+'/'+str(p.relative_to(root)).replace('\\','/')]=p
for name in ('build_cpu.py','run_windows.py','prepare_tests.py','package.py'):entries['root/'+name]=S/name
windows_paths=[('CPU neighbors',B/'cpu/validation/attempt1/receipt.json',True),
 ('CPU new graph',B/'cpu/validation/attempt2/receipt.json',False),('CPU direct/schema',B/'cpu/validation/attempt3/receipt.json',False),
 ('CUDA new+neighbors',B/'cuda/validation/attempt1/receipt.json',False),
 ('Vulkan neighbors',B/'vulkan/validation/attempt1/receipt.json',True),('Vulkan new',B/'vulkan/validation/attempt2/receipt.json',False)]
windows=[];names=set();new=set();neighbors=set()
for label,p,partial in windows_paths:
 doc=read(p);assert not doc['skipped'];failed={x['classname']+'.'+x['name'] for x in doc['failed']}
 selected=[n for n in doc['names'] if n not in failed]
 if partial:selected=[n for n in selected if 'BlockwiseW4A8' not in n]
 else:assert doc['passed']
 for n in selected:
  names.add(n);(new if 'BlockwiseW4A8' in n else neighbors).add(n)
 windows.append(dict(label=label,receipt=identity(p),green_case_names=selected,partial_window=partial,original_failures_retained=doc['failed'] if partial else []))
apple=read(APPLE/'final-validation.json');assert apple['validation']['tests']==2 and not apple['validation']['failed'] and not apple['validation']['skipped']
names.update(apple['validation']['names']);new.update(apple['validation']['names'])
assert len(new)==10 and len(neighbors)==14 and len(names)==24
correctpath=R/'docs/evidence/correctness/blockwise-w4a8-reference-2026-10-21.zip';z=archive(correctpath,entries)
correct=dict(observed_on='2026-10-21',status='bounded_software_reference_10_new_and14_neighbor_cases_passed_no_skip',
 source_contract='../research/fixed-role-binding-2026-10-21.json',publisher_contract_entry='kimi/24/quantization/contract_ops.py',publisher_contract_sha256='b5551ca0fbeac2f16983ad2d2aace521e6cb804ce0be2b8a8ec92b5a2cca2b3d',
 public_operations=['BlockwiseW4A8Linear','GroupedBlockwiseW4A8Linear'],
 geometry='Dense BF16 A[M,K],I32 W[N,K/8],F32 SF[N,K/512] ->BF16[M,N]. Grouped BF16 A[T,1|S,K],I32 W[E,N,K/8],F32SF[E,N,K/512],I32IDs[T,S] ->BF16[T,S,N]. Positive dimensions, K multiple512; real zero-slot activation views allowed.',
 math='s=BF16(absmax(A)*BF16(1/127)); inv=s==0?0:BF16(1/s); q=I8_trunc(BF16(A*inv)). Per increasing512group: d=BF16(I32_dot(q,nibble-8)); p=BF16(d*s); v=BF16(p*BF16(SF)); y=BF16(y+v) from+0. All BF16 rounds RNE. No dequantized whole floating W bank.',
 defined_domain='A finite, original selected SF finite positive, derived q finite and truncated result in[-128,127]. Source undefined casts fail Completion rather than clamp/wrap. Zero-scale inv is0. Finite SF conversion may become BF16 zero/Inf and subsequent IEEE output is legal.',
 architecture='Existing NativePlan/PreparedOperation/QueueSequence or original Apple/Vulkan Program/Invocation. Shared A quantizesT rows, independent slotsTS, before checked selected dot. All IDs validated before expert addressing. No new Graph executor/lease/model whitelist.',
 storage='CPU/CUDA Q+SA body is R*(K+2*K/512)bytes, R=M or T or T*S. Vulkan stores Q I8 plus BF16-rounded SA widened F32; Apple adds existing checks/status arrays. Runtime ownership/state costs are separate. No hardware integer GEMM or throughput claim.',
 tests=dict(distinct_total=24,new_operator_cases=10,neighbors=14,new_names=sorted(new),neighbor_names=sorted(neighbors),windows=windows,apple=identity(APPLE/'final-validation.json'),new_graph_successful_submissions=248,new_graph_expected_failed_completions=80,
  counting='Each backend new2Graph tests gives16lifetime+46runtime success,20expectedFailedCompletions. CPU has2additional Direct/schema tests. Neighbors14 counted once across their actual windows; CPU/Vulkan earlier red windows retain only unaffected green neighbors, not a fabricated all-green final-image rerun.',
  CUDA_capture='Actual RequireCapture and kCaptured assertions passed in both new CUDA tests.',
  failures_retained=['First fixture compile had a mixed-auto declarator type error, corrected before numerical execution.', 'Initial CPU/Apple domain classification treated negative128 as invalid and positive128 as valid; scalar source oracle corrected the fixture without changing product math/tolerances.', 'Vulkan first new leaf placed status at binding3 rather than original checked protocol binding2; create_invocation failed before math. Only new lower/generated shader objects changed; original175inputs including same testobj retained. New2thenpassed.', 'CUDA2helperplanning errors occurred before nvcc; receipts retained.']),
 validation_limits=['No numeric publisher tensor payload or full artifact/model execution.','No Linux execution of this new operation yet; retained for delivery1.','No upstream CUDA/TPU nonportable-I8-cast behavior claim outside the stated defined domain.','No hardware INT8 GEMM, completeFFN, quantized quality or performance acceptance.','Independent expert source spans/working sets remain delivery3; bounded E17 tests do not accept arbitrarily large banks.'],
 current_sources=source_ids,archive={k:v for k,v in z.items() if k!='entry_identities'},entry_identities=z['entry_identities'])
save(correctpath.with_suffix('.json'),correct)
save(S/'package-summary.json',dict(research=identity(research_path.with_suffix('.json')),research_archive=identity(research_path),correctness=identity(correctpath.with_suffix('.json')),correctness_archive=identity(correctpath),current_sources=source_ids,new_cases=10,neighbor_cases=14))
print(json.dumps({k:v for k,v in read(S/'package-summary.json').items() if k!='current_sources'},indent=2))
