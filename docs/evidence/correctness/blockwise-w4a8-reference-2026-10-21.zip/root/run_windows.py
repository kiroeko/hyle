"""Root-owned, sequential GPU process; the plan supplies its actual image path."""
from pathlib import Path
import importlib.util,sys,xml.etree.ElementTree as ET
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent;P=S.parent/'blockwise-w4a8';A=S.parent.parent
spec=importlib.util.spec_from_file_location('ct_grouped_gpu_helpers',A/'grouped-shared-activation/build_host.py')
h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h);b,c=h.b,h.c
arm=sys.argv[1];assert arm in ['cpu','cuda','vulkan']
plan_path=Path(sys.argv[2]).resolve();plan=c.read(plan_path)
image=next(x[5:] for x in plan['command'] if x.upper().startswith('/OUT:'))
filter=sys.argv[3]
out=P/arm/'validation'/(sys.argv[4] if len(sys.argv)>4 else 'attempt1')
out.mkdir(parents=True,exist_ok=True);(out/'tmp').mkdir(exist_ok=True)
assert not (out/'tests.result.json').exists(),'Preserve an actual attempt'
assert all(b.same(row) for row in plan['inputs'])
env,runtime=b.environment(plan['command'],[r['path'] for r in plan['inputs']],out)
c.save(out/'runtime-environment.json',dict(PATH=env['PATH'],runtime=runtime))
c.save(out/'image-before.json',b.identity(image))
try:c.execute('tests',[image,'--gtest_filter='+filter,'--gtest_output=xml:'+str(out/'tests.xml')],env,out)
finally:
 if (out/'tests.xml').exists():
  cases=ET.parse(out/'tests.xml').findall('.//testcase')
  failed=[x.attrib for x in cases if x.find('failure') is not None];skipped=[x.attrib for x in cases if x.find('skipped') is not None]
  receipt=dict(passed=bool(cases) and not failed and not skipped,cases=len(cases),failed=failed,skipped=skipped,
    filter=filter,names=[x.get('classname')+'.'+x.get('name') for x in cases],
    properties=[dict(case=x.get('classname')+'.'+x.get('name'),properties=[p.attrib for p in x.findall('./properties/property')]) for x in cases],
    image=b.identity(image),link_plan=b.identity(plan_path),xml=b.identity(out/'tests.xml'),GPU_processes=arm!='cpu')
  c.save(out/'receipt.json',receipt);print(receipt,flush=True)

