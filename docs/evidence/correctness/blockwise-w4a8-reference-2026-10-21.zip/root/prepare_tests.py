from pathlib import Path

R=Path(__file__).resolve().parents[4]
target=R/'tests/compute_models/blockwise_w4a8_fixture.h'
text=target.read_text(encoding='utf-8')
assert 'void run_lifetimes' not in text
old=(R/'tests/compute_models/mxfp4_reference_fixture.h').read_text(encoding='utf-8')
start=old.index('template<class Compile,class Write,class Read,class Prepare>\nvoid run_lifetimes')
end=old.index('template<class Compile,class Write,class Read,class Prepare>\nvoid run_runtime_domain',start)
lifetimes=old[start:end].replace('MXFP4','W4A8').replace('MX ','W4A8 ')
lifetimes=lifetimes.replace('layout==Layout::kDense?2048:64','1536')
runtime=r'''
template<class Compile,class Write,class Read,class Prepare>
void run_runtime_domain(m::MemoryResourceRef resource,std::span<const g::QueueBinding> queues,
    Compile compile,Write write,Read read,Prepare prepare) {
  unsigned successes=0,failures=0;
  for(const auto layout:{Layout::kDense,Layout::kSharedView}) {
    SCOPED_TRACE(::testing::Message()<<"layout="<<int(layout));
    Case f(layout);Logical logical(f,true);
    auto compiled=compile(logical.graph,g::CompileOptions{});ASSERT_TRUE(compiled)<<compiled.error().message();
    auto executable=compiled->executable;
    auto run=take(executable.create_invocation({.resources=g::ResourceOptions{}}),"dynamic W4A8 slot");
    const auto ownership=take(executable.output_ownership(),"W4A8 ownership");
    if(ownership!=g::OutputOwnership::kCaller) ASSERT_EQ(ownership,g::OutputOwnership::kInvocation);
    const auto valid=f.data();const auto initial=valid.payloads();std::array<m::Buffer,4> inputs;
    for(std::size_t i=0;i<f.port_count();++i) inputs[i]=take(m::Buffer::create(resource,initial[i].size(),256),"original dynamic W4A8 input");
    const auto count=f.output_description.required_bytes().value();c::LeasePool pool;
    if(ownership==g::OutputOwnership::kCaller) pool=take(c::LeasePool::create(resource,(count+255)/256*256,{.max_blocks=1}),"W4A8 writer");
    const auto upload=[&](const Data &d) {const auto p=d.payloads();for(std::size_t i=0;i<f.port_count();++i)check(write(inputs[i].view(),p[i]),"update original bytes");};
    const auto bind=[&] {
      for(std::size_t i=0;i<f.port_count();++i) check(run.bind(logical.ports[i],take(c::ConstTensorView::create(i?f.descriptions[i]:f.activation_backing,inputs[i].view()),"W4A8 current view")),"bind original buffers");
      if(ownership==g::OutputOwnership::kCaller) check(run.bind(logical.output,f.output_description,take(pool.allocate(count),"W4A8 output lease")),"bind output");
      check(prepare(run,queues),"prepare W4A8 replay");
    };
    upload(valid);bind();compiled=g::CompiledGraph{};logical.graph={};
    const auto success=[&](const Data &d) {
      upload(d);auto done=take(run.submit(queues),"W4A8 submit");check(done.wait(),"valid W4A8 completion");
      auto result=take(run.result(logical.output),"W4A8 result");storage::expect_result(result,f.oracle(d),read);++successes;
    };
    success(valid); // Unselected NaN SF and NaN token padding stay unread.
    std::vector<std::pair<std::string,Data>> invalid;
    for(const auto bits:std::array<std::uint16_t,3>{0x7f80,0xff80,0x7fc1}) {
      auto d=valid;d.a[0]=bits;invalid.emplace_back("nonfinite source A",d);
    }
    for(const auto sf:{0.F,-1.F,std::numeric_limits<float>::infinity(),std::numeric_limits<float>::quiet_NaN()}) {
      auto d=valid;d.scales[0]=sf;invalid.emplace_back("invalid original selected SF",d);
    }
    for(const auto bits:std::array<std::uint16_t,3>{0x0080,0x0304,0x8304}) {
      auto d=valid;std::fill(d.a.begin(),d.a.end(),0);d.a[0]=bits;
      invalid.emplace_back("undefined derived I8 cast",d);
    }
    if(f.grouped()) for(const auto id:{-1,static_cast<int>(f.experts)}) {
      auto d=valid;d.ids.back()=id;invalid.emplace_back("invalid last ID",d);
    }
    for(const auto &[label,bad]:invalid) {
      SCOPED_TRACE(label);upload(bad);
      {auto done=run.submit(queues);ASSERT_TRUE(done)<<done.error().message();EXPECT_FALSE(done->wait().ok());EXPECT_FALSE(run.result(logical.output));}
      EXPECT_FALSE(run.submit(queues))<<"failed Invocation is terminal";++failures;
      run={};run=take(executable.create_invocation({.resources=g::ResourceOptions{}}),"fresh recovery slot");upload(valid);bind();success(valid);
    }
    // Published normal witness distinguishes INT8 truncation from W4A16.
    auto d=valid;std::fill(d.a.begin(),d.a.end(),0);std::fill(d.w.begin(),d.w.end(),0x88888888u);
    for(std::int64_t t=0;t<f.tokens;++t) {d.a[f.a_index(t,0,0)]=0x3f80;d.a[f.a_index(t,0,1)]=0x4000;}
    for(std::int64_t e=0;e<(f.grouped()?2:1);++e)for(std::int64_t n=0;n<f.columns;++n) {
      const auto row=std::size_t(e*f.columns+n);d.w[row*std::size_t(f.depth/8)]=0x88888889u;
      for(std::int64_t g=0;g<f.depth/512;++g)d.scales[row*std::size_t(f.depth/512)+std::size_t(g)]=1.F;
    }
    for(const auto v:f.oracle(d))ASSERT_EQ(v,0x3f7eu);success(d);
    // Zero scale, subnormal BF16 scale, and 127.5 ->127 are defined cases.
    for(const auto bits:std::array<std::uint16_t,6>{0,0x8000,0x0001,0x8001,0x0380,0x7f7f}) {
      auto next=d;std::fill(next.a.begin(),next.a.end(),0);
      for(std::int64_t t=0;t<f.tokens;++t)next.a[f.a_index(t,0,0)]=bits;
      success(next);
    }
    // SF itself is finite positive; only its BF16 conversion over/underflows.
    // The smallest positive BF16 SF also probes subnormal output arithmetic.
    for(const auto sf:{std::numeric_limits<float>::denorm_min(),storage::wide(1),std::numeric_limits<float>::max()}) {
      auto next=d;
      for(std::int64_t e=0;e<(f.grouped()?2:1);++e)for(std::int64_t n=0;n<f.columns;++n)
        next.scales[std::size_t((e*f.columns+n)*(f.depth/512))]=sf;
      success(next);
    }
  }
  ::testing::Test::RecordProperty("successful_submissions",successes);
  ::testing::Test::RecordProperty("failed_completions",failures);
}
} // namespace blockwise_w4a8_test
'''
target.write_text(text+lifetimes+runtime,encoding='utf-8')
for arm in ('cpu','cuda'):
    old=(R/f'tests/graph_route_{arm}/mxfp4_reference_test.cc').read_text(encoding='utf-8')
    if arm=='cpu':
        old=old[:old.index('TEST(CpuMxfp4ReferenceDirect')]
    new=old.replace('mxfp4_reference_fixture.h','blockwise_w4a8_fixture.h').replace('mxfp4_reference_test','blockwise_w4a8_test')
    new=new.replace('Mxfp4ReferenceGraph','BlockwiseW4A8Graph').replace('MXFP4','W4A8').replace('Group32','Group512')
    (R/f'tests/graph_route_{arm}/blockwise_w4a8_test.cc').write_text(new,encoding='utf-8')
    cmake=R/f'tests/graph_route_{arm}/CMakeLists.txt'
    text=cmake.read_text(encoding='utf-8');assert 'blockwise_w4a8_test.cc' not in text
    cmake.write_text(text.replace('mxfp4_reference_test.cc','blockwise_w4a8_test.cc mxfp4_reference_test.cc',1),encoding='utf-8')
print(target)
