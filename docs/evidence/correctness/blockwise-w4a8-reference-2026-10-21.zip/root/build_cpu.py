from pathlib import Path
import concurrent.futures, importlib.util, json, sys
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent;F=S.parent;A=F.parent;R=A.parents[1]
spec=importlib.util.spec_from_file_location('w4a8_helpers',A/'grouped-shared-activation/build_host.py')
h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h);b,c=h.b,h.c
basepath=A/'ct-packed-grouped-space/cpu-cuda/checks/link-cpu/attempt2/link-plan.json'
base=c.read(basepath);metadata=h.metadata({'cpu':base})
out=F/'blockwise-w4a8/cpu'/sys.argv[1];out.mkdir(parents=True,exist_ok=True);(out/'tmp').mkdir(exist_ok=True)
jobs=[('schema','src/compute_ops/blockwise_w4a8.cc','src/compute_ops/weight_decode.cc',False),
 ('kernel','src/compute_provider_native/blockwise_w4a8.cc','src/compute_provider_native/nvfp4.cc',False),
 ('native-provider','src/compute_provider_native/native_provider.cc','src/compute_provider_native/native_provider.cc',True),
 ('test','tests/graph_route_cpu/blockwise_w4a8_test.cc','tests/graph_route_cpu/mxfp4_reference_test.cc',False)]
def compile(job):
 tag,src,oldsrc,replace=job;source=R/src
 if len(sys.argv)>2:
  previous=F/'blockwise-w4a8/cpu'/sys.argv[2]/tag/'identity.json'
  if previous.exists():
   record=c.read(previous)
   if b.same(record['source']) and b.same(record['object']) and all(b.same(x) for x in record['dependencies']):
    print(tag+' reused '+str(previous),flush=True);return record
 matches=[(r,metadata.get(c.key(r['path']))) for r in base['inputs']
   if c.key(metadata.get(c.key(r['path']),{}).get('source_path',''))==c.key(R/oldsrc)]
 assert len(matches)==1,(tag,len(matches));old,recipe=matches[0]
 path=out/tag;path.mkdir(exist_ok=True);(path/'tmp').mkdir(exist_ok=True)
 assert not (path/'compile.result.json').exists()
 command=b.host_command(recipe['command'],source,tag,path);env,_=b.environment(command,[],path)
 c.save(path/'plan.json',dict(command=command,source=b.identity(source),recipe=b.identity(recipe['recipe']),old_object=old,replace=replace))
 c.execute('compile',command,env,path)
 depsfile=path/(tag+'-deps.json');deps=c.read(depsfile)['Data']
 record=dict(command=command,source=b.identity(source),object=b.identity(path/(tag+'.obj')),
   source_dependencies=b.identity(depsfile),dependencies=[b.identity(p) for p in dict.fromkeys([deps['Source'],*deps['Includes']])],
   old_object=old,replace=replace,recipe=b.identity(recipe['recipe']))
 c.save(path/'identity.json',record);print(tag+' compiled',flush=True);return record
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:records=list(pool.map(compile,jobs))
swaps={c.key(r['old_object']['path']):r['object']['path'] for r in records if r['replace']}
command=[swaps.get(c.key(arg),arg) for arg in base['command'] if not arg.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:'))]
command[1:1]=[r['object']['path'] for r in records if not r['replace']]
image=out/'cpu.exe';command+=['/OUT:'+str(image),'/MAP:'+str(image.with_suffix('.map')),'/IMPLIB:'+str(image.with_suffix('.lib'))]
ids={c.key(x['path']):x for x in base['inputs']};ids.update({c.key(r['object']['path']):r['object'] for r in records})
inputs=[ids[c.key(x)] for x in command if Path(x).is_absolute() and Path(x).suffix.lower() in ('.obj','.lib')]
assert len(inputs)==len(set(c.key(x['path']) for x in inputs)) and all(b.same(x) for x in inputs)
c.save(out/'link-plan.json',dict(command=command,inputs=inputs,base=b.identity(basepath),owners=records,SDK_rebuilt=False,GPU_runs=0))
env,runtime=b.environment(command,[x['path'] for x in inputs],out)
c.save(out/'runtime-environment.json',dict(PATH=env['PATH'],runtime=runtime));c.execute('link',command,env,out)
c.save(out/'image.json',b.identity(image));print(out/'link-plan.json',flush=True)
