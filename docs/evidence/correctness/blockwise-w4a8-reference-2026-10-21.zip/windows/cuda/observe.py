from pathlib import Path
import importlib.util,json,sys,xml.etree.ElementTree as ET
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('blockwise_observe',S/'build.py')
h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
b,c=h.b,h.c
out=S/'validation/attempt1';receipt=c.read(out/'receipt.json')
cases=ET.parse(out/'tests.xml').findall('.//testcase')
assert len(cases)==7 and receipt['passed'] and receipt['cases']==7
assert all(x.find('failure') is None and x.find('skipped') is None for x in cases)
assert b.same(receipt['image']) and b.same(receipt['link_plan']) and b.same(receipt['xml'])
properties={x.get('classname')+'.'+x.get('name'):{p.get('name'):p.get('value') for p in x.findall('./properties/property')} for x in cases}
assert properties['CudaBlockwiseW4A8Graph.DenseGroupedGroup512RoundingRetainsSlotsAndResults']['actual_submissions']=='16'
domain=properties['CudaBlockwiseW4A8Graph.RuntimeScaleIndexFailuresAndIeeeReconstruction']
assert domain['successful_submissions']=='46' and domain['failed_completions']=='20'
freeze=c.read(S/'source-freeze.json')
assert all(b.identity(x['path'])=={k:x[k] for k in ('path','bytes','sha256')} for x in freeze['sources'])
final=dict(status='CUDA7_cases_pass_0skip',root_actual_run=b.identity(out/'receipt.json'),xml=receipt['xml'],
    build=b.identity(S/'final-build-receipt.json'),source_freeze=b.identity(S/'source-freeze.json'),
    image=receipt['image'],link_plan=receipt['link_plan'],cases=7,failed=0,skipped=0,
    new_operator=dict(cases=2,lifetime_success=16,runtime_success=46,expected_failed_Completions=20,
        capture='Current actual wrapper requires RequireCapture and asserts Captured route; tests passed without skip.'),
    neighbor_cases=5,names=receipt['names'],GPU_executor='root; this agent compiled/linked but did not run GPU',
    no_product_change_after_first_successful_compiles=True,
    limitations=['Synthetic numerical/resource reference only; no publisher payload or whole model','No throughput/quality or hardware I4xI8 GEMM acceptance'])
c.save(S/'final-validation.json',final)
print(json.dumps(b.identity(S/'final-validation.json'),indent=2))
