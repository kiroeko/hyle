from pathlib import Path
import importlib.util,json,sys
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('blockwise_link',S/'build.py')
h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
b,c=h.b,h.c
attempt=sys.argv[1] if len(sys.argv)>1 else 'link-attempt1'
test_attempt=sys.argv[2] if len(sys.argv)>2 else 'attempt1'
out=S/'checks'/attempt;out.mkdir(parents=True,exist_ok=True);(out/'tmp').mkdir(exist_ok=True)
assert not (out/'link.result.json').exists()
base=c.read(h.BASE)
files=[S/'checks/attempt1/cuda-provider/cuda-provider-identity.json',
       S/'checks/attempt1/blockwise-provider/blockwise-provider-identity.json',
       S/'checks/attempt3/blockwise-kernel/blockwise-kernel-identity.json',
       S/f'checks/{test_attempt}/blockwise-test/blockwise-test-identity.json',
       S.parent/'cpu/attempt1/schema/identity.json']
rows=[c.read(p) for p in files]
assert all(b.same(r['source']) and b.same(r['object']) for r in rows)
replacement=rows[0];old=replacement['old_object']
assert any(c.key(x['path'])==c.key(old['path']) for x in base['inputs'])
extras=[r['object'] for r in rows[1:]]
image=out/'cuda.exe'
command=[replacement['object']['path'] if c.key(x)==c.key(old['path']) else x for x in base['command']
         if not x.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:'))]
command[1:1]=[x['path'] for x in extras]
command+=['/OUT:'+str(image),'/MAP:'+str(image.with_suffix('.map')),'/IMPLIB:'+str(image.with_suffix('.lib'))]
ids={c.key(x['path']):x for x in base['inputs']}
ids.update({c.key(r['object']['path']):r['object'] for r in rows})
paths=[x for x in command if Path(x).is_absolute() and Path(x).suffix.lower() in ('.obj','.lib')]
assert len(paths)==len(set(map(c.key,paths)))
inputs=[ids[c.key(x)] for x in paths]
assert len(inputs)==175 and all(b.same(x) for x in inputs)
c.save(out/'link-plan.json',dict(command=command,inputs=inputs,base=b.identity(h.BASE),
    replacement=dict(before=old,after=replacement['object']),added=extras,owner_receipts=[b.identity(p) for p in files],
    schema_reuse='Root supplied same MSVC14.50/MD/O2/HYLE_STATIC schema owner; source has no backend-specific branches or state layout.',
    SDK_builds=0,GPU_runs=0))
env,runtime=b.environment(command,[x['path'] for x in inputs],out)
c.save(out/'runtime-environment.json',dict(PATH=env['PATH'],runtime=runtime))
c.execute('link',command,env,out)
c.save(out/'image.json',b.identity(image))
print(json.dumps(dict(image=b.identity(image),inputs=len(inputs),filter='CudaBlockwiseW4A8Graph.*'),indent=2))
