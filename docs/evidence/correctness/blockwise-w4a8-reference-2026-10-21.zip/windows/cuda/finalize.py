from pathlib import Path
import importlib.util,json,shutil,sys
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('blockwise_cuda_final',S/'build.py')
h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
b,c=h.b,h.c
freeze=c.read(S/'source-freeze.json')
assert all(b.identity(x['path'])=={k:x[k] for k in ('path','bytes','sha256')} for x in freeze['sources'])
owners=[]
for attempt,tag in [('attempt1','cuda-provider'),('attempt1','blockwise-provider'),
                    ('attempt3','blockwise-kernel'),('attempt1','blockwise-test'),('attempt2','blockwise-test')]:
    path=S/'checks'/attempt/tag/(tag+'-identity.json')
    record=c.read(path);assert b.same(record['source']) and b.same(record['object'])
    owners.append(dict(receipt=b.identity(path),source=record['source'],object=record['object'],
        source_dependencies=record['source_dependencies'],dependency_count=len(record['dependencies'])))
test=c.read(S/'checks/attempt2/blockwise-test/blockwise-test-identity.json')
fixture=next(x for x in test['dependencies'] if Path(x['path']).name=='blockwise_w4a8_fixture.h')
assert b.same(fixture)
for source in [Path(fixture['path']),h.ROOT/'tests/graph_route_cuda/blockwise_w4a8_test.cc']:
    dest=S/'shared-tested-source'/source.relative_to(h.ROOT);dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(source,dest)
links=[b.identity(S/f'checks/link-attempt{i}/link-plan.json') for i in (1,2)]
current=c.read(S/'checks/link-attempt2/link-plan.json')
assert all(b.same(row) for row in current['inputs'])
receipt=dict(status='CUDA_product_and_final_fixture_linked_waiting_root_GPU',
    source_freeze=b.identity(S/'source-freeze.json'),math_contract=b.identity(S.parents[1]/'kimi/24/contract-review.json'),
    actual_build_counts=dict(successful_CXX=4,successful_NVCC=1,successful_links=2,
        compiler_failures=0,planning_failures_before_NVCC=2,SDK_builds=0,GPU_processes_by_this_agent=0),
    owners=owners,current_test_fixture=fixture,links=links,image=c.read(S/'checks/link-attempt2/image.json'),
    current_link_inputs=len(current['inputs']),root_schema=b.identity(S.parent/'cpu/attempt1/schema/identity.json'),
    domains='Group512/BF16 A and output, exact offset-binary packed W, F32 original positive finite SF; complete IDs first, derived finite trunc-to-I8 range, all explicit BF16 boundaries.',
    storage='Workspace is quant_rows*K I8 plus2*quant_rows*(K/512) BF16 scales; shared A1/zero-slot quant_rows=T, independent AS quant_rows=T*S. No whole NK or ENK floating bank.',
    capture='Cold function materialization; submit stays on QueueSequence stream with accepted device-status-reset prefix. Capture success must come from root actual GPU run, not this build.',
    historical='Old wrapper/image retain initial fixture classification. Final wrapper adopts root correction: -128 legal and +128 invalid. No CUDA product source changed after the first compile.',
    limitations=['No GPU run by this agent','No whole artifact payload/import/quality/throughput qualification','No hardware INT4xINT8 GEMM claim'])
c.save(S/'final-build-receipt.json',receipt)
print(json.dumps(dict(receipt=b.identity(S/'final-build-receipt.json'),current_fixture=fixture),indent=2))
