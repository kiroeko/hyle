from pathlib import Path
import concurrent.futures,importlib.util,json,sys,re
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent
F=S.parents[1]; A=F.parent; ROOT=A.parents[1]
spec=importlib.util.spec_from_file_location('blockwise_ct_build',A/'ct-packed-grouped-space/cpu-cuda/build.py')
h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
b,c=h.b,h.c
BASE=A/'ct-packed-grouped-space/cpu-cuda/checks/link-cuda/attempt1/link-plan.json'
def native_command(recipe,source,tag,out):
    args=[];skip=False
    for arg in recipe:
        if skip:skip=False;continue
        if arg in ('-c','-o','-MT','-MF'):skip=True
        elif not arg.startswith('-Xcompiler=-Fd'):args.append(arg)
    assert '-std=c++20' in args
    assert any('compute_89' in x and 'sm_89' in x for x in args)
    return args+['-MT',str(out/(tag+'.obj')),'-MF',str(out/(tag+'.d')),
        '-c',str(source),'-o',str(out/(tag+'.obj')),'-Xcompiler=-Fd'+str(out/(tag+'.pdb'))+',-FS']
def one(name,old_name,tag,attempt):
    base=c.read(BASE);meta=h.h.metadata({'cuda':base})
    matches=[(x,meta.get(c.key(x['path']))) for x in base['inputs'] if c.key(meta.get(c.key(x['path']),{}).get('source_path',''))==c.key(ROOT/old_name)]
    assert len(matches)==1,(old_name,len(matches))
    old,recipe=matches[0];source=ROOT/name
    out=S/'checks'/attempt/tag;out.mkdir(parents=True,exist_ok=True);(out/'tmp').mkdir(exist_ok=True)
    assert not (out/'compile.result.json').exists()
    native=source.suffix=='.cu'
    command=(native_command if native else b.host_command)(recipe['command'],source,tag,out)
    source_before=b.identity(source)
    c.save(out/'plan.json',dict(source=source_before,command=command,old_object=old,recipe=b.identity(recipe['recipe']),base=b.identity(BASE),new_owner=name!=old_name))
    envcommand=command
    if native:
        if '-ccbin' in command:
            cl=Path(command[command.index('-ccbin')+1])/'cl.exe'
        else:
            hosts=[r['command'][0] for r in meta.values() if c.key(r.get('source_path',''))==c.key(ROOT/'src/compute_provider_cuda/cuda_provider.cc')]
            assert len(set(hosts))==1,hosts
            cl=Path(hosts[0])
        assert cl.is_file();envcommand=[str(cl),*command[1:]]
    env,_=b.environment(envcommand,[],out)
    c.execute('compile',command,env,out)
    if native:
        deps=out/(tag+'.d')
        rhs=deps.read_text().split(' : ',1)[1].replace('\\\n',' ')
        paths=[Path(x.replace('\\ ',' ')).resolve() for x in re.split(r'(?<!\\)\s+',rhs) if x]
    else:
        deps=out/(tag+'-deps.json');data=c.read(deps)['Data']
        paths=[Path(x) for x in dict.fromkeys([data['Source'],*data['Includes']])]
    assert b.same(source_before) and all(x.is_file() for x in paths)
    identity=dict(source=source_before,object=b.identity(out/(tag+'.obj')),command=command,
        source_dependencies=b.identity(deps),dependencies=[b.identity(p) for p in dict.fromkeys(paths)],
        recipe=b.identity(recipe['recipe']),old_object=old,new_owner=name!=old_name)
    c.save(out/(tag+'-identity.json'),identity)
    return dict(identity=b.identity(out/(tag+'-identity.json')),object=identity['object'],source=source_before,old_object=old,new_owner=name!=old_name)
def main():
    mode,attempt=sys.argv[1:3]
    if mode=='products':
        rows=[('src/compute_provider_cuda/cuda_provider.cc','src/compute_provider_cuda/cuda_provider.cc','cuda-provider'),
            ('src/compute_provider_cuda/blockwise_w4a8_provider.cc','src/compute_provider_cuda/nvfp4_provider.cc','blockwise-provider'),
            ('src/compute_provider_cuda/blockwise_w4a8_kernel.cu','src/compute_provider_cuda/nvfp4_kernel.cu','blockwise-kernel')]
    elif mode=='test':
        rows=[('tests/graph_route_cuda/blockwise_w4a8_test.cc','tests/graph_route_cuda/grouped_nvfp4_reference_test.cc','blockwise-test')]
    elif mode=='native':
        rows=[('src/compute_provider_cuda/blockwise_w4a8_kernel.cu','src/compute_provider_cuda/nvfp4_kernel.cu','blockwise-kernel')]
    else:raise ValueError(mode)
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
        results=list(pool.map(lambda r:one(*r,attempt),rows))
    c.save(S/'checks'/attempt/(mode+'-summary.json'),dict(owners=results,SDK_builds=0,GPU_runs=0))
    print(json.dumps(results,indent=2))
if __name__=='__main__':main()
