from pathlib import Path
import hashlib,json
S=Path(__file__).resolve().parent
ROOT=S.parents[4]
def ident(p):
    raw=p.read_bytes();return dict(path=str(p),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def anchor(name,terms):
    p=ROOT/name;lines=p.read_text().splitlines()
    return dict(source=ident(p),anchors={term:[i+1 for i,s in enumerate(lines) if term in s] for term in terms})
files=[anchor('src/compute_route_apple/apple_blockwise_w4a8.cc',[
    'hyle_w4a8_trunc','id_status[0]','0x3c010000u','hyle_f32_div','simd_sum','sf_bits != 0u','hyle_f32_add','const int quant_rows','with_device_status']),
    anchor('src/compute_route_apple/apple_mature_float.cc',['lower_blockwise_w4a8','BlockwiseW4A8Linear']),
    anchor('src/compute_route_vulkan/vulkan_blockwise_w4a8.cc',[
        'infer_output_descriptions','quant_slots','check_storage','TensorDesc::dense','dispatch.checked_status','add(0','add(1','add(2']),
    anchor('src/compute_route_vulkan/shaders/blockwise_w4a8.comp',[
        'phase == 0u','if (failed())','0x3c010000u','uint bound','int code =','weight_scale == 0u','sum +=','hyle_f32_add','y[work] =']),
    anchor('src/compute_route_vulkan/vulkan_operations.cc',['BlockwiseW4A8Linear','lower_blockwise_w4a8']),
    anchor('src/compute_ops/blockwise_w4a8.cc',['b[2] == 2','b[1] == 0','k % 512','in[3]','TensorDesc::dense'])]
report=dict(status='no_concrete_blocker_in_bounded_source_review',product_changes_by_review=0,builds=0,GPU_runs=0,
    reviewed_sources=files,
    math=[
        'Both backends use exact BF16 constant0x3c01, explicit BF16 RNE on scale and reciprocal, zero-scale bypass without epsilon, and BF16 product before truncation.',
        'Apple raw-bit truncation rejects nonfinite/exponent overflow and then checks signed code[-128,127]. Vulkan raw positive bound128/negative bound129 allows127.5 and-128 but rejects+128 and NaN/Inf before native integer conversion.',
        'Both decode offset-binary low-first nibble minus8, with exact I32 group512 dot; bound512*128*8=524288 makes Metal simd_sum and Vulkan sequential sum safe.',
        'Dot becomes BF16 before separate activation-scale multiply, then BF16 original F32 weight-scale conversion/multiply, then increasing-group BF16 addition. No source BF16 boundary is postponed or scalar scales combined.',
        'SF validity uses raw positive-finite F32 bits, admitting positive subnormals while rejecting+/-0, negative, NaN and Inf. Later BF16(SF) underflow/overflow is left to IEEE arithmetic, including legitimate0*Inf NaN.',
        'Metal and Vulkan retain integer IEEE helpers for F32 multiply/divide/add, so they do not rely on native shader FTZ preserving BF16/F32 subnormal witnesses. Integer-dot-to-F32 is exact at the proven bound.'
    ],
    indexing_resources=[
        'Apple computes an all-ID logical/reduction result before quantize or dot; both kernels read its scalar dependency before any expert origin. Vulkan phases0->1->2 reuse the original checked-status recorder/barrier contract; phase0 rejects negative IDs through their high unsigned encoding as well as too-large positive IDs.',
        'A1 or actual zero-slot stride quantizes only T rows. Independent AS usesT*S. Original activation strides are retained; the common schema requires contiguous BF16 K and aligned nonoverlapping token rows for zero-slot views.',
        'Apple quantization/status outputs stay in the same lazy Program dependency chain, and with_device_status retains checks. No hot host wait or second executor is introduced. No uninitialized quantized lane is read on a successful path.',
        'Vulkan stores bounded unique-row I8 codes and widened BF16-rounded scales, never an ENK floating bank. Host checks native buffer_capacity, maxStorageBufferRange, UInt32 indexing and actual dispatch grid limits before recording.',
        'Vulkan output pairs use the existing packed-BF16 native buffer-capacity convention, as the NVFP4 path does; the final logical odd element occupies the low half of the final native word. This review did not replace or relax the original range/origin/lease rules.',
        'Quantization/source validation may leave partial scratch or outputs after failure; the public contract forbids consuming failed outputs and promises no whole-output rollback. That is preserved, not treated as successful math.'
    ],
    public_design_review=dict(approved_names=['BlockwiseW4A8Linear','GroupedBlockwiseW4A8Linear'],
        fixed_group512=True,ports='BF16 A; I32 K-packed W; original F32 per-group SF; grouped adds I32 IDs; BF16 output',
        corrections_to_earlier_research_draft='Root fixed512 rather than admitting unverified arbitrary group_size. No model/producer identity field; no W4A16/GPTQ alias. Public finite/derived-I8-range domain is explicit, and only selected SF is validated.',
        CPU_path='Existing native PreparedOperation/maps/workspace and Graph lifecycle; exact I32 group dot and separate BF16 product/add. No NativePlan/public ABI expansion or decoded whole bank is required.'),
    limits=[
        'This is source-only review, not extra GPU qualification. Actual Apple/Vulkan results belong to their backend receipts.',
        'The existing Program/array/lease/status recording and native packed-buffer padding permissions are reused; this is not a fresh audit of every backend subsystem.',
        'No whole publisher payload, model-quality or throughput conclusion.'])
out=S.parent/'review';out.mkdir(exist_ok=True)
(out/'apple-vulkan-source-review.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf8',newline='\n')
print(ident(out/'apple-vulkan-source-review.json'))
