from pathlib import Path
import concurrent.futures, difflib, hashlib, json, os, struct, subprocess, sys, threading, time

R=Path.cwd(); A=R/'.scratch/architecture-refactor-2026-10-18'
S=A/'fixed-role-binding-2026-10-21/blockwise-w4a8/vulkan'
B=A/'ct-packed-grouped-space/vulkan/checks'
C=S/'checks'; G=S/'shaders'
if os.environ.get('W4A8_BUILD_ATTEMPT'):
 C=C/os.environ['W4A8_BUILD_ATTEMPT'];G=G/os.environ['W4A8_BUILD_ATTEMPT']
C.mkdir(parents=True,exist_ok=True); G.mkdir(exist_ok=True)
phase=sys.argv[1]; records=[]; lock=threading.Lock()
env=os.environ.copy()
setup=subprocess.run(['cmd','/d','/c',str(A/'bf16-nan-cast-contract/compiler-env.bat')],capture_output=True,text=True,check=True)
for line in setup.stdout.splitlines():
 if '=' in line and not line.startswith('='):
  k,v=line.split('=',1);env[k.upper()]=v
temporary=S/'tmp';temporary.mkdir(exist_ok=True);env['TMP']=env['TEMP']=str(temporary)
def load(p):return json.loads(Path(p).read_bytes())
def save(p,x):Path(p).write_text(json.dumps(x,indent=2)+'\n',encoding='utf8')
def identity(p):
 p=Path(p);b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def run(tag,command):
 started=time.time();p=subprocess.run(command,cwd=R,env=env,capture_output=True,text=True,encoding='utf8',errors='replace')
 (C/(tag+'.stdout.txt')).write_text(p.stdout,encoding='utf8');(C/(tag+'.stderr.txt')).write_text(p.stderr,encoding='utf8')
 with lock:
  records.append(dict(label=tag,command=command,cwd=str(R),exit_code=p.returncode,seconds=time.time()-started));save(C/('commands-'+phase+'.json'),records)
 print(tag,p.returncode,flush=True)
 if p.returncode:raise RuntimeError(tag+': '+(p.stdout+p.stderr)[-7500:])
def recipe_for(obj):
 for p in Path(obj).parent.glob('*identity.json'):
  d=load(p)
  if Path(d.get('object',{}).get('path',''))==Path(obj):return p
 raise AssertionError(obj)
def command_for(recipe,source,tag):
 out=[];skip=False
 for arg in load(recipe)['command']:
  if skip:skip=False;continue
  if arg=='/sourceDependencies':skip=True;continue
  if arg.startswith(('/Fo','/Fd')) or arg.lower().endswith(('.cc','.cpp')):continue
  out.append(arg)
 out.insert(1,'-I'+str(G))
 return out+['/W4','/WX','/sourceDependencies',str(C/(tag+'-deps.json')),str(source),'/Fo'+str(C/(tag+'.obj')),'/Fd'+str(C/(tag+'.pdb'))]
base=load(B/'attempt3/link-plan.json')
if phase=='shaders':
 artifacts=load(B/'shader-artifacts.json')['artifacts'];assert len(artifacts)==22
 for row in artifacts:assert identity(row['artifact']['path'])==row['artifact']
 header_paths=[R/'src/compute_shader_shared/nvfp4_f32.h',R/'src/compute_shader_shared/ct_packed.h']
 numeric='\n'.join(p.read_text().split('R"HYLE_SHADER(',1)[1].split(')HYLE_SHADER"',1)[0] for p in header_paths)
 source=R/'src/compute_route_vulkan/shaders/blockwise_w4a8.comp';text=source.read_text();marker='// HYLE_BLOCKWISE_W4A8_F32_SOURCE';assert text.count(marker)==1
 generated=G/'blockwise_w4a8.generated.comp';generated.write_bytes(text.replace(marker,numeric).encode())
 for grouped in (False,True):
  name='blockwise_w4a8'+('_grouped' if grouped else '')
  command=['C:/public/tools/glslang/glslangValidator.exe','-V','--target-env','vulkan1.2','-S','comp']
  if grouped:command+=['-DHYLE_BLOCKWISE_GROUPED=1']
  command+=['-o',str(G/(name+'.spv')),str(generated)];run(name+'-shader',command)
  artifacts.append(dict(name=name,artifact=identity(G/(name+'.spv')),reused=False))
 header=['#pragma once','#include <cstdint>','#include <span>','namespace hyle::compute::vulkan::detail::shaders {'];cpp=['#include "vulkan_shaders.h"',header[-1]]
 for row in artifacts:
  name=row['name'];raw=Path(row['artifact']['path']).read_bytes();assert len(raw)%4==0
  words=struct.unpack('<'+'I'*(len(raw)//4),raw);assert words[0]==0x07230203 and words[1]<=0x00010500
  at=5
  while at<len(words):
   size,opcode=words[at]>>16,words[at]&65535;assert size and at+size<=len(words)
   if opcode==17:assert size==2 and words[at+1]==1
   at+=size
  row['capabilities_checked_shader_only']=True
  if not name.startswith('blockwise_w4a8'):row['reused']=True
  header.append('std::span<const std::uint32_t> '+name+'() noexcept;')
  cpp.append('namespace { constexpr std::uint32_t '+name+'_words[] = {')
  for offset in range(0,len(words),8):cpp.append('  '+', '.join(f'0x{x:08x}u' for x in words[offset:offset+8])+',')
  cpp+=['}; }','std::span<const std::uint32_t> '+name+'() noexcept { return '+name+'_words; }']
 header.append('} // namespace hyle::compute::vulkan::detail::shaders');cpp.append(header[-1])
 (G/'vulkan_shaders.h').write_bytes(('\n'.join(header)+'\n').encode());(G/'vulkan_shaders.cc').write_bytes(('\n'.join(cpp)+'\n').encode())
 save(C/'shader-artifacts.json',dict(artifacts=artifacts,new_shader_compiles=2,old_shader_artifacts_reused_byte_exact=22,SDK=0,GPU=0,math_headers=[identity(p) for p in header_paths],source=identity(source),generated=identity(generated)))
elif phase in ('compile','repair','tests'):
 objects={Path(x['path']).name:x for x in base['inputs']}
 if phase in ('compile','repair'):
  items=[('vulkan_operations',R/'src/compute_route_vulkan/vulkan_operations.cc',recipe_for(objects['vulkan_operations.obj']['path'])),('vulkan_blockwise_w4a8',R/'src/compute_route_vulkan/vulkan_blockwise_w4a8.cc',recipe_for(objects['vulkan_operations.obj']['path'])),('vulkan_shaders',G/'vulkan_shaders.cc',recipe_for(objects['vulkan_shaders.obj']['path']))]
  if phase=='repair':items=[x for x in items if x[0]!='vulkan_operations']
 else:items=[('blockwise-test',R/'tests/graph_route_vulkan/blockwise_w4a8_test.cc',recipe_for(objects['mxfp4-test.obj']['path']))]
 def one(item):
  tag,source,recipe=item;command=command_for(recipe,source,tag);run(tag+'-compile',command);deps=load(C/(tag+'-deps.json'))['Data'];paths=dict.fromkeys([deps['Source'],*deps['Includes']])
  record=dict(command=command,source=identity(source),object=identity(C/(tag+'.obj')),recipe=identity(recipe),dependencies=[identity(p) for p in paths]);save(C/(tag+'-identity.json'),record);return dict(tag=tag,receipt=identity(C/(tag+'-identity.json')))
 with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:done=list(pool.map(one,items))
 save(C/('receipts-'+phase+'.json'),done)
elif phase=='link':
 objects={Path(x['path']).name:x for x in base['inputs']}
 object_path=lambda tag:C/(tag+'.obj') if (C/(tag+'.obj')).exists() else S/'checks'/(tag+'.obj')
 replacements={objects[tag+'.obj']['path'].lower():str(object_path(tag)) for tag in ('vulkan_operations','vulkan_shaders')}
 shared=S.parent/'cpu/attempt1';overlays=[]
 for tag in ['schema','native-provider','kernel']:
  receipt=shared/tag/'identity.json';fresh=load(receipt);assert identity(fresh['object']['path'])==fresh['object'];assert identity(fresh['source']['path'])==fresh['source']
  overlays.append(dict(receipt=identity(receipt),source=fresh['source'],object=fresh['object']))
 old=objects['native-provider.obj'];old_recipe=load(recipe_for(old['path']));fresh=load(shared/'native-provider/identity.json')
 defines=lambda cmd:sorted(x[2:] for x in cmd if x.startswith(('/D','-D')))
 crt=lambda cmd:sorted(x.lower() for x in cmd if x.lower() in ('/md','/mt','/mdd','/mtd'))
 assert defines(old_recipe['command'])==defines(fresh['command']) and crt(old_recipe['command'])==crt(fresh['command']) and old_recipe['command'][0].lower()==fresh['command'][0].lower()
 replacements[old['path'].lower()]=fresh['object']['path']
 for row in base['inputs']:assert identity(row['path'])==row
 command=[];seen=set()
 for arg in base['command']:
  if arg.upper().startswith(('/OUT:','/MAP:','/IMPLIB:')):continue
  if arg.lower() in replacements:seen.add(arg.lower());command.append(replacements[arg.lower()])
  else:command.append(arg)
 assert seen==set(replacements)
 additions=[str(object_path('vulkan_blockwise_w4a8')),str(object_path('blockwise-test')),overlays[0]['object']['path'],overlays[2]['object']['path']]
 command[1:1]=additions
 exe=C/'blockwise-w4a8-test.exe';command+=['/OUT:'+str(exe),'/MAP:'+str(C/'blockwise-w4a8-test.map'),'/IMPLIB:'+str(C/'blockwise-w4a8-test.lib')]
 save(C/'proposed-link-plan.json',dict(command=command,inputs=[identity(x) for x in command[1:] if Path(x).is_file()],baseline=identity(B/'attempt3/link-plan.json'),replacements=replacements,additions=additions,shared_overlay=overlays,shared_native_provider_ABI=dict(defines_equal=True,CRT_equal=True,compiler_equal=True)))
 run('link',command);plan=load(C/'proposed-link-plan.json');plan['executable']=identity(exe);save(C/'link-plan.json',plan)
elif phase=='freeze':
 paths=['src/compute_route_vulkan/vulkan_blockwise_w4a8.cc','src/compute_route_vulkan/shaders/blockwise_w4a8.comp','src/compute_route_vulkan/vulkan_operations.cc','src/compute_route_vulkan/vulkan_tensor.h','src/compute_route_vulkan/CMakeLists.txt','src/compute_route_vulkan/build_shaders.py','tests/graph_route_vulkan/blockwise_w4a8_test.cc','tests/graph_route_vulkan/CMakeLists.txt']
 snapshots=[];diff=[]
 for name in paths:
  p=R/name;b=p.read_bytes();dest=S/'after'/name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(b);snapshots.append(dict(source=identity(p),snapshot=identity(dest)))
  old=S/'before'/name;before=old.read_text().splitlines(True) if old.exists() else [];diff+=difflib.unified_diff(before,p.read_text().splitlines(True),fromfile='before/'+name,tofile='after/'+name)
 (S/'implementation.diff').write_text(''.join(diff));save(S/'source-freeze.json',dict(sources=snapshots,fixture=identity(R/'tests/compute_models/blockwise_w4a8_fixture.h'),public_descriptor=identity(R/'include/hyle/compute/model_ops.h'),shared_math=[identity(R/'src/compute_shader_shared/nvfp4_f32.h'),identity(R/'src/compute_shader_shared/ct_packed.h')],GPU_executions_by_this_agent=0))
else:raise ValueError(phase)
