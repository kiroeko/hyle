from pathlib import Path
import ctypes
import hashlib
import importlib.util
import json
import shutil
import subprocess

repo = Path.cwd(); root = repo / '.scratch/foundation-f3/cpu-public-fixture-2f9c8200f'
job = json.loads((root / 'job.json').read_text())
assert job['stages'][-1]['exit_code'] == 1
assert 'is already used to build' in (root / 'configure.log').read_text()
parent = Path('C:/h7/w-cpu-cuda/selected-graph/source-parent')
file = parent / 'CMakeLists.txt'; text = file.read_text()
lines = text.splitlines(); gtest = [line for line in lines if line.startswith('add_subdirectory(') and ' f3-gtest ' in line]
assert len(gtest) == 2 and gtest[0] == gtest[1]
first = text.index(gtest[0]); second = text.index(gtest[1], first + len(gtest[0]))
file.write_text(text[:second] + text[second:].replace(gtest[1] + '\n', '', 1))
build = Path(job['build']); compiler = job['compiler']
spec = importlib.util.spec_from_file_location('header_env', repo / 'scripts/header-self-contained.py')
module = importlib.util.module_from_spec(spec); spec.loader.exec_module(module)
env = module.visual_studio_environment('', 'x64', '', compiler); env['VSLANG'] = '1033'
cmake = shutil.which('cmake', path=env['PATH'])
class MemoryStatus(ctypes.Structure):
    _fields_ = [('length', ctypes.c_ulong), ('load', ctypes.c_ulong)] + [(str(i), ctypes.c_ulonglong) for i in range(7)]
for name, command, timeout in [
    ('configure-gtest-once', [cmake, '-S', str(parent), '-B', str(build)], 300),
    ('build', [cmake, '--build', str(build), '--target', 'hyle_f3_cpu_file_risks', '--parallel', '4'], 1800),
    ('files', [str(build / 'hyle_f3_cpu_file_risks.exe'), '--gtest_filter=FileStream.*', '--gtest_output=xml:' + str(root / 'files.xml')], 120)]:
    memory = MemoryStatus(); memory.length = ctypes.sizeof(memory)
    assert ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(memory)); free = getattr(memory, '1')
    assert free >= 4 * 1024**3
    if '--parallel' in command: command[command.index('--parallel') + 1] = str(4 if free >= 12 * 1024**3 else 2 if free >= 8 * 1024**3 else 1)
    log = root / (name + '.log'); assert not log.exists()
    runtime = env.copy()
    if name == 'files': runtime['PATH'] = str(build) + ';C:/Windows/System32;C:/Windows'
    with log.open('w') as output:
        process = subprocess.Popen(command, cwd=root, env=runtime, stdout=output, stderr=subprocess.STDOUT, creationflags=subprocess.CREATE_NO_WINDOW)
        row = {'name': name, 'command': command, 'pid': process.pid, 'state': 'running', 'log': log.name, 'available_bytes': free}
        job['stages'].append(row); (root / 'job.json').write_text(json.dumps(job, indent=2))
        try: code = process.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            subprocess.run(['taskkill', '/PID', str(process.pid), '/T', '/F'], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            process.wait(); row.update(state='terminal', verdict='TIMEOUT'); (root / 'job.json').write_text(json.dumps(job, indent=2)); raise
        row.update(state='terminal', exit_code=code, verdict='PASS' if code == 0 else 'FAIL', sha256=hashlib.sha256(log.read_bytes()).hexdigest())
        (root / 'job.json').write_text(json.dumps(job, indent=2))
    print(name, code, flush=True)
    if code: raise SystemExit(code)
job['verdict'] = 'PASS_WINDOWS_F3_CPU_THIRTEEN_PUBLIC_RISKS_ONLY'
(root / 'job.json').write_text(json.dumps(job, indent=2))
