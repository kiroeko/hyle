from pathlib import Path
import hashlib
import json
import os
import re
import signal
import subprocess
import sys

mode = sys.argv[1]
assert mode in ['cuda', 'asan', 'ubsan', 'tsan']
candidate = sys.argv[2] if len(sys.argv) > 2 else '838c78bfd38dd122cdda03d6dd4386cb0e30e67b'
assert len(candidate) == 40
base = Path('/root/hyle-scratch/compute-unified')
root = base / ('foundation-f3-current-' + mode + '-' + candidate[:9])
assert not root.exists(); root.mkdir()
if mode == 'cuda':
    source = Path('/home/kiro/hyle-f1/native-fault/source-3034fc595abf')
    build = source.parent / 'build-3034fc595abf'
    target, pattern = 'hyle_compute_route_cuda_file_stream_test', 'CudaFileStream.*'
else:
    source = Path('/home/kiro/hyle-f1/sanitizers/source-03242e7723cb')
    build = source.parent / (mode + '-03242e7723cb')
    target, pattern = 'hyle_compute_stream_test', 'FileStream.*'
assert candidate in (source / 'SOURCE-MANIFEST.txt').read_text()
env = os.environ.copy()
env.update(PATH='/usr/local/cuda-13.3/bin:/usr/lib/wsl/lib:/usr/bin:/bin:/usr/sbin:/sbin',
           ASAN_OPTIONS='halt_on_error=1:detect_leaks=1', UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1', TSAN_OPTIONS='halt_on_error=1')
commands = [('build', ['/usr/bin/cmake', '--build', str(build), '--target', target, '--parallel', '1'], 1800)]
test = [str(build / 'bin' / target), '--gtest_filter=' + pattern, '--gtest_output=xml:' + str(root / 'files.xml')]
if len(sys.argv) > 3:
    test[1] = '--gtest_filter=' + sys.argv[3]
if mode == 'tsan': test = ['/usr/bin/setarch', 'x86_64', '-R'] + test
commands.append(('files', test, 120))
record = {'candidate': candidate, 'product_commit': '97858fbc88a6b5a87f109290b956eeaeee632dd2',
          'mode': mode, 'source': str(source), 'build': str(build),
          'scope': 'Incremental current F3 getter formatting and original deadline/close risk fixture only, prior config/flags retained.', 'stages': []}
for name, command, timeout in commands:
    free = int(re.search(r'MemAvailable:\s+(\d+)', Path('/proc/meminfo').read_text()).group(1)) * 1024
    assert free >= 4 * 1024**3
    if '--parallel' in command:
        record['parallel'] = 4 if free >= 12 * 1024**3 else 2 if free >= 8 * 1024**3 else 1
        command[command.index('--parallel') + 1] = str(record['parallel'])
    log = root / (name + '.log')
    with log.open('w') as output:
        process = subprocess.Popen(command, cwd=root, env=env, stdout=output, stderr=subprocess.STDOUT, start_new_session=True)
        row = {'name': name, 'command': command, 'pid': process.pid, 'state': 'running', 'log': log.name, 'available_bytes': free}
        record['stages'].append(row); (root / 'job.json').write_text(json.dumps(record, indent=2))
        try: code = process.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            os.killpg(process.pid, signal.SIGKILL); process.wait()
            row.update(state='terminal', verdict='TIMEOUT'); (root / 'job.json').write_text(json.dumps(record, indent=2)); raise
        row.update(state='terminal', exit_code=code, verdict='PASS' if code == 0 else 'FAIL', sha256=hashlib.sha256(log.read_bytes()).hexdigest())
        (root / 'job.json').write_text(json.dumps(record, indent=2))
    print(name, code, flush=True)
    if code: raise SystemExit(code)
record['verdict'] = 'PASS_CURRENT_F3_' + mode.upper() + '_ONLY'
(root / 'job.json').write_text(json.dumps(record, indent=2))
