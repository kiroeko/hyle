from pathlib import Path
import hashlib
import json
import xml.etree.ElementTree as ET
import zipfile

repo = Path.cwd(); scratch = repo / '.scratch/foundation-f3'
windows = scratch / 'cpu-public-fixture-2f9c8200f'
subjects = [(windows, 13, 'Windows CPU')]
subjects += [(scratch / ('foundation-f3-current-' + mode + '-2f9c8200f-logs'), 14, 'WSL ' + mode) for mode in ['asan', 'ubsan', 'tsan']]
subjects.append((scratch / 'direct-io-air-logs', 14, 'Air CPU'))
rows = []
for folder, count, label in subjects:
    job = json.loads((folder / 'job.json').read_text())
    for stage in job['stages']:
        assert stage['state'] == 'terminal'
        expected = 1 if label == 'Windows CPU' and stage['name'] == 'configure' else 0
        assert stage['exit_code'] == expected
        assert hashlib.sha256((folder / stage['log']).read_bytes()).hexdigest() == stage['sha256']
    tests = ET.parse(folder / 'files.xml').getroot()
    assert tests.attrib['tests'] == str(count) and tests.attrib['failures'] == '0' and tests.attrib['errors'] == '0'
    log = (folder / 'files.log').read_text()
    assert 'ExplicitDirectIoUsesAlignedChunksAndRejectsMisalignedTailBeforeConsumption' in log
    assert 'WARNING: ThreadSanitizer:' not in log and 'ERROR: AddressSanitizer:' not in log and 'runtime error:' not in log
    rows.append({'machine': label, 'tests_passed': count, 'source_or_fixture': job.get('candidate'), 'identity': job.get('identity', job.get('compiler'))})
out = repo / 'evidence/correctness/foundation-f3-direct-io'; out.mkdir(parents=True, exist_ok=True)
archive = out / 'raw-results.zip'
with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED) as packed:
    for folder, count, label in subjects:
        for path in sorted(folder.iterdir()):
            if path.is_file(): packed.writestr(label.replace(' ', '-') + '/' + path.name, path.read_bytes())
    for name in ['resume_cpu_direct_windows.py', 'run_wsl_current_delta.py', 'run_cpu_risks_air.py', 'seal_direct_io.py']:
        packed.writestr('workflow/' + name, (scratch / name).read_bytes())
receipt = {'schema_version': 1, 'product_commit': '97858fbc88a6b5a87f109290b956eeaeee632dd2',
    'fixture_commit': '2f9c8200f9a0c219d2dfc52cfe7f2ed20e01329d', 'runs': rows,
    'direct_io': 'Actual Windows/Linux original kDirect/non-buffered files. Unaligned 8191-byte tail rejected before consuming writer or IO/native calls; 4KiB stage reads 8KiB, writes a second initially-zero file, exact byte oracle passes.',
    'macos': 'Actual original Unimplemented rejection observed; portable direct-IO data journey NOT_APPLICABLE by original IO contract, not a native direct data PASS.',
    'original_failures': 'Private Windows test parent duplicated GoogleTest add_subdirectory and failed before tests; same-tree configure corrected to add it once. Raw failure retained, no product/tool rewrite or budget reset.',
    'limits': 'No new product changes, driver-private residency or throughput promise. Original sanitizer flags and twelve/thirteen prior risks preserved.',
    'archive': {'path': archive.relative_to(repo).as_posix(), 'sha256': hashlib.sha256(archive.read_bytes()).hexdigest()},
    'verdict': 'PASS_F3_EXPLICIT_DIRECT_IO_AND_COMMON_RISK_INCREMENT_ONLY'}
(out / 'receipt.json').write_bytes(json.dumps(receipt, indent=2).encode() + b'\n')
print('Windows/Linux actual direct-IO journey and Air explicit native refusal verified; current product unchanged.')
