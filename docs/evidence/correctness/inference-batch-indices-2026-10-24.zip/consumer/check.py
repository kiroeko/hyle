"""One finite current consumer; existing actual reports remain the baseline."""
from pathlib import Path
import importlib.util,json,os,re,shutil,sys,zipfile
sys.dont_write_bytecode=True
D=Path(__file__).resolve().parent;R=D.parents[2]
PREVIOUS=R/'.scratch/inference-execution-observation-20261024/regression'
BASE=R/'.scratch/mtp-request-unification-20261024/regression'
FIXTURE=R/'.scratch/mtp-runtime-backend-20261024/verification1/tiny-run/fixture'
spec=importlib.util.spec_from_file_location('retained',R/'.scratch/mtp-extraction-regression-20261024/check.py')
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
def require(ok,message):
    if not ok:raise ValueError(message)
def prepare():
    require(b.pin(PREVIOUS/'summary.json')['sha256']=='e05145b8c081086a49cc07c4faa213927c3b885fb6f38c6645bca3277de055c8','Previous actual baseline changed')
    target=D/'reference';target.mkdir(parents=True,exist_ok=False)
    b.save(target/'reports.json',b.read(PREVIOUS/'summary.json')['reports'])
    for source,name in[(PREVIOUS/'summary.json','previous-summary.json'),(PREVIOUS/'run/stderr.log','stderr.log'),(BASE/'current4/link/command.json','link-command.json'),(BASE/'current4/link/pins.json','link-pins.json')]:shutil.copyfile(source,target/name)
    shutil.copyfile(PREVIOUS/'probe.cc',D/'probe.cc')
    bridge=R/'.scratch/inference-k1-acceptance-20261024/qwen/proof-summary.json'
    require(b.pin(bridge)['sha256']=='80b1e77559a4cecfe285313cae40082a828940539f77a147c2ff8fceb0c40a33','Independently verified K1 selector bridge changed')
    b.save(D/'baseline-pins.json',dict(previous=b.pin(PREVIOUS/'summary.json'),probe=b.pin(D/'probe.cc'),reports=b.pin(target/'reports.json'),stderr=b.pin(target/'stderr.log'),independent_K1_bridge=b.pin(bridge),reference_chain='Existing actual eight reports at main88a791; classicK1/m0 selector then separately compared old88a791/new0ced with complete states/ledger/RNG identical. Current batch-index grouping changes now use that same actual report baseline; no old or GLM rerun.',fixture=[b.pin(p)for p in FIXTURE.glob('*')if p.is_file()],closure=dict(route=b.pin(BASE/'native-program-fixed/archive/route.lib'),native_region=b.pin(BASE/'native-region-fixed2/compile/unit.obj')),scope='One existing A-only current tiny consumer. No old rebuild/run, no new mixed/cold matrix.',SDK_builds=0,HTTP=0))
def freeze(expected_main,report_relative):
    target=D/'source';target.mkdir(parents=True,exist_ok=False);records=[]
    main=R/'engine/models/qwen35/main.cc';report=R/report_relative
    require(b.pin(main)['sha256']==expected_main,'Canonical main is not the agreed stable source')
    require(report.is_file()and report.is_relative_to(R/'engine'),'Actual standalone reporting implementation is absent')
    for p in[main,report,*report.parent.glob('*.h'),*(R/'engine/models/qwen35').glob('*.h'),*(R/'engine/inference').glob('*.h')]:
        out=target/p.relative_to(R);out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(p.read_bytes());records.append(dict(original=b.pin(p),frozen=b.pin(out)))
    shutil.copyfile(D/'probe.cc',target/'probe.cc');records.append(dict(original=b.pin(D/'probe.cc'),frozen=b.pin(target/'probe.cc')))
    b.save(D/'source-pins.json',dict(records=records,main_sha256=expected_main,report_relative=report.relative_to(R).as_posix(),probe_changes='None; original actual consumer source unchanged.'))
def compile_one(source,folder,env):
    original=b.args(PREVIOUS/'compile/command.json');command=[original[0],'/I'+str(D/'source')];skip=False
    for word in original[1:]:
        if skip:skip=False;continue
        if word=='/sourceDependencies':skip=True;continue
        lower=word.lower().replace('\\','/')
        if lower.startswith(('/fo','/fd'))or lower.endswith(('.cc','.cpp')):continue
        if lower.startswith('/i')and '/.scratch/'in lower and lower.endswith('/source'):continue
        command.append(word)
    command+=['/sourceDependencies',str(folder/'dependencies.json'),str(source),'/Fo'+str(folder/'unit.obj'),'/Fd'+str(folder/'unit.pdb')]
    b.execute(command,folder,env,180)
    deps=[Path(p).resolve()for p in b.read(folder/'dependencies.json')['Data']['Includes']]
    leaks=[str(p)for p in deps if p.is_relative_to(R/'engine')or(p.is_relative_to(R/'.scratch')and not p.is_relative_to(D/'source'))]
    require(not leaks,'Canonical/foreign private engine headers leaked into frozen closure: '+repr(leaks))
    pins=[b.pin(p)for p in deps if p.is_relative_to(R)];b.save(folder/'self-header-pins.json',pins)
    prior={p['path'].lower():p for p in b.read(PREVIOUS/'compile/self-header-pins.json')if Path(p['path']).is_relative_to(R/'include')}
    require(all(p['path'].lower()in prior and all(p[k]==prior[p['path'].lower()][k]for k in['bytes','sha256'])for p in pins if Path(p['path']).is_relative_to(R/'include')),'Public ABI/header closure changed; inspect before linking')
def build():
    env=b.environment(b.args(PREVIOUS/'compile/command.json')[0]);pins=b.read(D/'source-pins.json')
    compile_one(D/'source'/pins['report_relative'],D/'reporting-compile',env)
    compile_one(D/'source/probe.cc',D/'compile',env)
    previous=b.args(D/'reference/link-command.json');old=str(BASE/'current3/compile/unit.obj');require(previous.count(old)==1,'Previous cleaned app entry is not uniquely recorded')
    out=D/'link';link=[]
    for word in previous:
        if word.upper().startswith(('/OUT:','/PDB:','/MAP:','/IMPLIB:')):continue
        if word==old:link.extend([str(D/'compile/unit.obj'),str(D/'reporting-compile/unit.obj')])
        else:link.append(word)
    link+=['/OUT:'+str(out/'probe.exe'),'/PDB:'+str(out/'probe.pdb')];b.execute(link,out,env,120)
    for path in(BASE/'current4/link').glob('*.dll'):os.link(path,out/path.name)
    b.save(out/'pins.json',dict(image=b.pin(out/'probe.exe'),objects=[b.pin(D/'compile/unit.obj'),b.pin(D/'reporting-compile/unit.obj')],baseline_link=b.pin(D/'reference/link-command.json'),native=[b.pin(p)for p in out.glob('*.dll')],SDK_builds=0))
def run():
    env=b.environment(b.args(D/'compile/command.json')[0]);env.update({k:v for k,v in b.read(b.VK/'runtime.json').items()if isinstance(v,str)})
    env.update(HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1');env['PATH']=str(D/'link')+';'+env['PATH']
    for row in b.read(D/'baseline-pins.json')['fixture']:
        now=b.pin(Path(row['path']));require(all(now[k]==row[k]for k in['bytes','sha256']),'Pinned cached A fixture changed')
    b.execute([str(D/'link/probe.exe'),str(FIXTURE/'weights.tsv'),str(D/'output')],D/'run',env,90)
    audit()
def formatters(path):
    rows=[];counts={key:0 for key in['prefix_hit','request_prefix_hit','prepared','step','preparation','batch_plan']};fields={key:[]for key in counts}
    for line in path.read_text().splitlines():
        if line.startswith('prefix_hit name='):
            kind='prefix_hit'if' graph_calls='in line else'request_prefix_hit';head='prefix_hit'
        elif line.startswith('prepared T='):kind='prepared';head='prepared'
        elif line.startswith('preparation name='):kind='preparation';head='preparation'
        elif line.startswith('batch_plan name='):kind='batch_plan';head='batch_plan'
        elif re.match(r'^\S+ tokens=\d+ visible=\d+ seconds=',line):kind='step';head=line.split(' ',1)[0]
        else:continue
        pairs=[word.split('=',1)for word in line.split()[1:]]
        require(all(len(pair)==2 for pair in pairs),'Malformed actual formatter field: '+line)
        names=[pair[0]for pair in pairs]
        if names not in fields[kind]:fields[kind].append(names)
        rows.append(dict(kind=kind,head=head,fields=[pair for pair in pairs if pair[0]!='seconds'and not pair[0].endswith('_seconds')]))
        counts[kind]+=1
    return dict(counts=counts,fields=fields,non_timing_rows=rows)
def audit():
    actual=[json.loads(line)for line in(D/'run/stdout.log').read_text().splitlines()if line.startswith('{')];expected=b.read(D/'reference/reports.json')
    ignored=[];additions=[];differences=[]
    def compare(before,after,path):
        if isinstance(before,dict):
            if not isinstance(after,dict):differences.append(path+':type');return
            additions.extend(path+'.'+k for k in after.keys()-before.keys())
            for key,value in before.items():
                child=path+'.'+key
                if key=='seconds'or key.endswith('_seconds')or'tokens_per_second'in key:ignored.append(child);continue
                if key not in after:differences.append(child+':missing');continue
                compare(value,after[key],child)
        elif isinstance(before,list):
            if not isinstance(after,list)or len(before)!=len(after):differences.append(path+':length/type');return
            for i,(left,right)in enumerate(zip(before,after)):compare(left,right,path+'['+str(i)+']')
        elif before!=after:differences.append(path+':'+repr(before)+' -> '+repr(after))
    compare(expected,actual,'reports')
    before=formatters(D/'reference/stderr.log');after=formatters(D/'run/stderr.log');compare(before,after,'stderr_formatters')
    def groups(path):
        lines=[line for line in path.read_text().splitlines()if re.match(r'^generation_(batch|session) ',line)]
        return dict(lines=lines,counts={kind:sum(line.startswith('generation_'+kind+' ')for line in lines)for kind in['batch','session']})
    old_groups=groups(D/'reference/stderr.log');new_groups=groups(D/'run/stderr.log');compare(old_groups,new_groups,'stderr_request_groups')
    stderr=(D/'run/stderr.log').read_text();late={key:sum(line.startswith(key+'=')for line in stderr.splitlines())for key in['expected_late_diagnostic_failure','expected_fullhit_late_diagnostic_failure']}
    require(late==dict(expected_late_diagnostic_failure=1,expected_fullhit_late_diagnostic_failure=1),'Expected postcommit late diagnostic failures not both actually observed')
    summary=dict(state='passed'if not differences else'failed_comparison',scope='One current existing A-only natural Text4x2 N2/R2 full/partial prefixes/evict/restore, greedy recovery/lateIO, stochastic MTP K2R2 and fixed CLI tape. Compare previous actual reports, real stderr formatter and request grouping sequence; dispatch/wave/batch/members remain part of the complete JSON comparison.',differences=differences,added_report_fields=additions,ignored_timing_fields=ignored,formatter=after,request_groups=new_groups,late_IO_failures_observed=late,committed_math_ledgers_RNG_geometry_equal=not differences,reports=actual,compile=b.read(D/'compile/process.json'),reporting_compile=b.read(D/'reporting-compile/process.json'),link=b.read(D/'link/process.json'),run=b.read(D/'run/process.json'),consumer_TUs=1,reporting_TUs=1,actual_processes=1,old_runs=0,SDK_builds=0,HTTP=0,full_models=0,quality_claim=False,performance_claim=False)
    b.save(D/'summary.json',summary);require(not differences,'Actual finite report/formatter mismatch: '+repr(differences[:8]));print(json.dumps(dict(state='passed',summary=b.pin(D/'summary.json'),formatter_counts=after['counts'])),flush=True)
def finalize():
    summary=b.read(D/'summary.json');require(summary['state']=='passed','Cannot archive failed regression')
    cleanup=[]
    for path in D.rglob('*'):
        if path.is_file()and path.suffix.lower()in{'.obj','.exe','.pdb','.ilk','.exp','.lib','.dll','.pch'}:
            absolute=path.resolve();require(absolute.is_relative_to(D),'Cleanup candidate escaped this regression');cleanup.append(dict(path=str(absolute),bytes=path.stat().st_size))
    b.save(D/'cleanup-candidates.json',dict(workspace=str(D),files=cleanup,count=len(cleanup),logical_bytes=sum(x['bytes']for x in cleanup),scope='Only rebuildable files under this private regression. Original runtime DLL/cache/corrected native closure are outside and excluded.',deletion_performed=False))
    proof={key:value for key,value in summary.items()if key not in['reports','formatter','ignored_timing_fields']}
    proof.update(source_pins=b.pin(D/'source-pins.json'),baseline=b.read(D/'baseline-pins.json'),image=b.read(D/'link/pins.json'),formatter=dict(actual_line_counts=summary['formatter']['counts'],actual_field_sequences=summary['formatter']['fields'],full_sequence_and_non_timing_values_equal=True,unexercised=[key for key,value in summary['formatter']['counts'].items()if not value]),report_count=len(summary['reports']),excluded_fields='Only seconds / *_seconds / *tokens_per_second*. No process identities required exclusion.',summary=b.pin(D/'summary.json'),boundary='Tiny untrained A-only fixture, actual current execution and existing finite request/formatter contracts; no new GDN/mixed/full-model/quality/performance coverage.')
    b.save(D/'proof-summary.json',proof)
    extensions={'.cc','.h','.py','.json','.log','.diff','.patch','.md','.txt','.ids'};selected=[p for p in D.rglob('*')if p.is_file()and p.suffix in extensions and p.name not in['proof-pins.json','live.json']]
    with zipfile.ZipFile(D/'proof.zip','x',compression=zipfile.ZIP_DEFLATED,compresslevel=9)as z:
        for path in sorted(selected):z.write(path,path.relative_to(D).as_posix())
    with zipfile.ZipFile(D/'proof.zip')as z:require(not any(Path(name).suffix in{'.obj','.exe','.pdb','.dll','.lib','.bin','.tsv'}for name in z.namelist()),'Archive contains rebuildable binary/weights')
    b.save(D/'proof-pins.json',dict(summary=b.pin(D/'summary.json'),proof_summary=b.pin(D/'proof-summary.json'),archive=b.pin(D/'proof.zip'),entries=len(selected)))
    print(json.dumps(b.read(D/'proof-pins.json')),flush=True)
if __name__=='__main__':
    if sys.argv[1]=='freeze':freeze(sys.argv[2],sys.argv[3])
    else:{'prepare':prepare,'build':build,'run':run,'audit':audit,'finalize':finalize}[sys.argv[1]]()
