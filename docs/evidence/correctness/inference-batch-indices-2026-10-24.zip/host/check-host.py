from pathlib import Path
import hashlib
import importlib.util
import json
import shutil
import sys
import zipfile

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parents[2]
BASE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('retained_host_check', ROOT / '.scratch/mtp-extraction-regression-20261024/check.py')
b = importlib.util.module_from_spec(spec)
spec.loader.exec_module(b)
out = BASE / 'host-check1'
out.mkdir(exist_ok=False)
header = ROOT / 'engine/inference/batch_indices.h'
source = BASE / 'host.cc'
main = ROOT / 'engine/models/qwen35/main.cc'
library = ROOT / '.scratch/build-compute-v2-dev/bin/mimalloc_static.lib'
pins = [b.pin(path) for path in (header, source, main, ROOT / 'include/hyle/container/small_vector.h',
                                ROOT / 'include/hyle/mem/system_inline.h', library)]
b.save(out / 'source-pins.json', pins)
compiler = b.args(b.CPU / 'compile-command.json')[0]
env = b.environment(compiler)
image = out / 'compile/host.exe'
command = [compiler, '/nologo', '/std:c++latest', '/EHsc', '/W4', '/WX', '/utf-8',
    '/permissive-', '/Zc:preprocessor', '/Zc:__cplusplus', '/O2', '/Ob2', '/MD',
    '/DHYLE_STATIC', '/DNOMINMAX', '/I' + str(ROOT), '/I' + str(ROOT / 'include'),
    '/sourceDependencies', str(out / 'compile/dependencies.json'), str(source),
    '/Fo' + str(out / 'compile/host.obj'), '/Fe' + str(image), str(library),
    '/link', 'advapi32.lib', 'ws2_32.lib', 'synchronization.lib']
b.execute(command, out / 'compile', env, 60)
b.execute([str(image)], out / 'run', env, 30)
assert pins == [b.pin(Path(row['path'])) for row in pins], 'Tested source changed during host check'
dependencies = [b.pin(Path(path)) for path in b.read(out / 'compile/dependencies.json')['Data']['Includes']]
b.save(out / 'actual-dependency-pins.json', dependencies)
frozen = out / 'source'
for path, relative in ((header, 'engine/inference/batch_indices.h'), (source, 'host.cc')):
    target = frozen / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(path, target)
summary = {'state': 'passed', 'kind': 'one private host property TU against canonical BatchIndices header',
    'property_groups': 4, 'compile': b.read(out / 'compile/process.json'), 'run': b.read(out / 'run/process.json'),
    'source_pins': pins, 'actual_observations': [
        'selected7 lives outside the BatchIndices object (actual inline4 spill)',
        'selected.data pointer remains stable across24 reset/select rounds with11 candidates',
        'admitted prefix3 leaves suffix unmarked; subsequent7+1 executes all11 once',
        'fixed first-seen kind/actual-row grouping excludes0-row full hits',
        'natural full hits use limit1 and other groups preserve role/phase/row compatibility',
        'N1/R1 selected.data actually lies inside the object with one predicate call',
        'invalid capacities/limits invoke no matcher and oversized mark changes no completion'],
    'source_review_separate': 'main fixed whole-wave preflight and selected-span lifetimes reviewed separately; this test does not emulate token/state/lease/execution policy',
    'mask_pointer_observed': False, 'global_allocation_count_instrumented': False,
    'sdk_builds': 0, 'model_runs': 0, 'gpu_runs': 0, 'http_requests': 0,
    'no_throughput_claim': True, 'reused_allocator_library': b.pin(library)}
b.save(out / 'summary.json', summary)
candidates = [b.pin(path) for path in sorted((out / 'compile').iterdir())
              if path.is_file() and path.suffix.lower() in ('.obj', '.exe', '.pdb', '.exp', '.lib', '.map')]
b.save(out / 'cleanup-candidates.json', {'files': candidates, 'logical_bytes': sum(row['bytes'] for row in candidates),
    'deletion_performed': False, 'shared_allocator_library_excluded': True})
archive = out / 'proof.zip'
with zipfile.ZipFile(archive, 'x', zipfile.ZIP_DEFLATED, compresslevel=6) as z:
    for path in sorted(out.rglob('*')):
        if path.is_file() and path.suffix.lower() in ('.h', '.cc', '.json', '.log'):
            z.write(path, path.relative_to(out).as_posix())
    z.write(Path(__file__), 'check-host.py')
b.save(out / 'publication.json', {'summary': b.pin(out / 'summary.json'), 'archive': b.pin(archive),
    'cleanup': b.pin(out / 'cleanup-candidates.json')})
print(json.dumps({'state': 'passed', 'property_groups': 4, 'archive': b.pin(archive),
    'cleanup_logical_bytes': sum(row['bytes'] for row in candidates)}, indent=2))
