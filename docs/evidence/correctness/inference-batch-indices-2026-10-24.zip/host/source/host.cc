#include "engine/inference/batch_indices.h"

#include <algorithm>
#include <array>
#include <cstddef>
#include <cstdint>
#include <cstdio>
#include <initializer_list>
#include <span>
#include <stdexcept>

using hyle::inference::BatchIndices;

void require(bool value, const char *message) {
  if (!value) throw std::runtime_error(message);
}
template<class Action> void rejected(Action action, const char *message) {
  bool threw = false;
  try { action(); } catch (const std::exception &) { threw = true; }
  require(threw, message);
}
void ids(std::span<const std::size_t> actual, std::initializer_list<std::size_t> expected) {
  require(actual.size() == expected.size() && std::equal(actual.begin(), actual.end(), expected.begin()),
          "first-seen actual indices differ from the declared small oracle");
}
bool within_object(const BatchIndices &object, const std::size_t *pointer) {
  const auto base = reinterpret_cast<std::uintptr_t>(&object);
  const auto address = reinterpret_cast<std::uintptr_t>(pointer);
  return address >= base && address - base < sizeof(object);
}

void spill_and_shrink() {
  BatchIndices work;
  work.prepare(11, 7); // Both candidate count and real selected width exceed inline4.
  const std::size_t *prepared_selected = nullptr;
  for (std::size_t round = 0; round < 24; ++round) {
    work.reset(11);
    std::array<std::size_t, 11> executions{};
    const auto all = [](std::size_t) { return true; };
    auto selected = work.select(0, 7, all);
    ids(selected, {0, 1, 2, 3, 4, 5, 6});
    require(!within_object(work, selected.data()), "selected7 must actually spill beyond inline4");
    if (!round) prepared_selected = selected.data();
    require(selected.data() == prepared_selected, "reset/select must keep its cold selected allocation");
    // Simulate the real admission policy shrinking a seven-member bucket to3.
    for (auto index : selected.first(3)) ++executions[index];
    work.mark_selected(3);
    require(work.completed(0) && work.completed(2) && !work.completed(3) && !work.completed(6),
            "capacity shrink must not mark its unused selected suffix");
    selected = work.select(3, 7, all);
    ids(selected, {3, 4, 5, 6, 7, 8, 9});
    require(selected.data() == prepared_selected, "next group must reuse the same selected storage");
    for (auto index : selected) ++executions[index];
    work.mark_selected(selected.size());
    selected = work.select(10, 7, all);
    ids(selected, {10});
    require(selected.data() == prepared_selected, "one-member tail must not shrink/reallocate the spill");
    ++executions[selected.front()]; work.mark_selected(1);
    for (std::size_t i = 0; i < executions.size(); ++i)
      require(executions[i] == 1 && work.completed(i), "every real member must execute exactly once after shrinking");
  }
  std::puts("PASS spill11/batch7: selected.data stable across24 resets, shrink3 then7 then1 executes each once");
}

void fixed_rows() {
  BatchIndices work; work.prepare(8, 5); work.reset(8);
  constexpr std::array<std::size_t, 8> rows{2, 0, 1, 2, 1, 0, 2, 3};
  constexpr std::array<unsigned, 8> kind{0, 0, 1, 0, 1, 0, 0, 0};
  std::array<std::size_t, 8> executions{};
  std::size_t groups = 0;
  for (std::size_t first = 0; first < rows.size(); ++first) {
    if (!rows[first] || work.completed(first)) continue; // Fixed full hits remain host-only.
    const auto selected = work.select(first, 5, [&](std::size_t index) {
      return rows[index] == rows[first] && kind[index] == kind[first];
    });
    if (groups == 0) ids(selected, {0, 3, 6});
    else if (groups == 1) ids(selected, {2, 4});
    else if (groups == 2) ids(selected, {7});
    else require(false, "unexpected extra fixed bucket");
    ++groups;
    for (auto index : selected) ++executions[index];
    work.mark_selected(selected.size());
  }
  require(groups == 3, "fixed first-seen bucket count");
  for (std::size_t i = 0; i < rows.size(); ++i)
    require(executions[i] == std::size_t(rows[i] != 0), "zero-row fixed full hits must never be selected");
  std::puts("PASS fixed: first-seen kind/actual-row buckets, zero-row hits excluded");
}

void natural_and_inline() {
  struct Key { unsigned role, generation; std::size_t rows; bool full_hit; };
  constexpr std::array<Key, 9> keys{{{0, 0, 0, true}, {1, 0, 2, false}, {0, 0, 0, true},
      {1, 0, 2, false}, {1, 1, 2, false}, {2, 1, 2, false}, {1, 1, 2, false},
      {1, 1, 3, false}, {1, 1, 3, false}}};
  BatchIndices work; work.prepare(keys.size(), 5); work.reset(keys.size());
  std::array<std::size_t, keys.size()> executions{};
  std::size_t groups = 0;
  for (std::size_t first = 0; first < keys.size(); ++first) {
    if (work.completed(first)) continue;
    const auto anchor = keys[first];
    const auto selected = work.select(first, anchor.full_hit ? 1 : 5, [&](std::size_t index) {
      const auto candidate = keys[index];
      return candidate.full_hit == anchor.full_hit && candidate.role == anchor.role &&
          candidate.generation == anchor.generation && candidate.rows == anchor.rows;
    });
    switch (groups++) {
    case 0: ids(selected, {0}); break;
    case 1: ids(selected, {1, 3}); break;
    case 2: ids(selected, {2}); break;
    case 3: ids(selected, {4, 6}); break;
    case 4: ids(selected, {5}); break;
    case 5: ids(selected, {7, 8}); break;
    default: require(false, "unexpected extra natural bucket");
    }
    for (auto index : selected) ++executions[index];
    work.mark_selected(selected.size());
  }
  require(groups == 6, "natural first-seen bucket count");
  for (auto count : executions) require(count == 1, "natural full-hit members must each be observed once");
  BatchIndices one; one.prepare(1, 1); one.reset(1);
  std::size_t predicate_calls = 0;
  const auto selected = one.select(0, 1, [&](std::size_t) { ++predicate_calls; return true; });
  ids(selected, {0});
  require(predicate_calls == 1 && within_object(one, selected.data()), "N1/R1 selected storage remains inline with one predicate");
  one.mark_selected(1); require(one.completed(0), "N1/R1 completion");
  one.reset(0);
  std::puts("PASS natural: full-hit limit1 and actual role/phase/rows; N1/R1 inline selected storage");
}

void invalid_capacity() {
  BatchIndices work;
  rejected([&] { work.prepare(0, 1); }, "zero candidate capacity must reject");
  rejected([&] { work.prepare(1, 0); }, "zero batch capacity must reject");
  rejected([&] { work.prepare(4, 5); }, "batch above candidate capacity must reject");
  work.prepare(8, 5); work.reset(8);
  std::size_t predicate_calls = 0;
  const auto same = [&](std::size_t) { ++predicate_calls; return true; };
  rejected([&] { (void)work.select(0, 0, same); }, "zero actual batch limit must reject before matching");
  rejected([&] { (void)work.select(0, 6, same); }, "actual batch above prepared limit must reject before matching");
  rejected([&] { work.reset(9); }, "wave above prepared candidate capacity must reject");
  require(predicate_calls == 0, "invalid limits must be checked before invoking compatibility policy");
  work.reset(8);
  const auto selected = work.select(0, 5, same); ids(selected, {0, 1, 2, 3, 4});
  rejected([&] { work.mark_selected(6); }, "mark beyond real selected group must reject");
  for (std::size_t i = 0; i < 8; ++i) require(!work.completed(i), "invalid mark must not partially mark any work");
  work.mark_selected(2);
  require(work.completed(0) && work.completed(1) && !work.completed(2), "valid reuse after rejected mark");
  std::puts("PASS invalid capacities and oversized mark reject before policy/partial completion");
}

int main() {
  spill_and_shrink(); fixed_rows(); natural_and_inline(); invalid_capacity();
  std::puts("PASS BatchIndices host properties (4 groups)");
}
