from pathlib import Path
import hashlib,json,zipfile

R=Path(__file__).resolve().parents[2]
D=Path(__file__).resolve().parent
O=R/'docs/evidence/correctness'
NAME='inference-batch-indices-2026-10-24'
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def pin(p):return dict(path=p.relative_to(R).as_posix(),bytes=p.stat().st_size,
                       sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def save(p,v):p.write_text(json.dumps(v,indent=2,ensure_ascii=False)+'\n',encoding='utf8')

host=read(D/'host-check1/proof-summary.json')
consumer=read(D/'regression/proof-summary.json')
assert host['state']==consumer['state']=='passed'
assert all(read(D/'source-only.json')['checks'].values())
for row in read(D/'after-pins.json'):
    p=Path(row['path'])
    if not p.is_absolute():p=R/p
    assert pin(p)['sha256']==row['sha256']
additional=['source-only.json','after-pins.json','changes.patch','root-before-pins.json',
            'integration-review.md','publish.py']
assert all((D/p).is_file()for p in additional)
archives=[D/'host-check1/proof.zip',D/'regression/proof.zip']
for p in archives:
    with zipfile.ZipFile(p)as z:
        assert z.testzip()is None
        assert all(not i.is_dir()and Path(i.filename).suffix not in
                   {'.exe','.obj','.lib','.exp','.pdb','.dll'}for i in z.infolist())
archive=O/(NAME+'.zip');assert not archive.exists()
allowed={'.cc','.h','.py','.md','.json','.log','.patch','.txt','.ids'}
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9)as out:
    for label,p in zip(['host','consumer'],archives):
        with zipfile.ZipFile(p)as z:
            for item in z.infolist():out.writestr(label+'/'+item.filename,z.read(item))
    for p in sorted((D/'before').rglob('*')):
        if p.is_file()and p.suffix in allowed:out.write(p,'additional/'+p.relative_to(D).as_posix())
    for name in additional:out.write(D/name,'additional/'+name)
    for name in ['engine/models/qwen35/main.cc','engine/inference/batch_indices.h']:
        out.write(R/name,'canonical/'+name)
report=dict(state='passed',date='2026-10-24',
 scope='Cold-prepared finite host index scratch shared by natural ordinary/MTP requests and fixed replay. Payload, compatibility, state admission and publication remain at existing callers.',
 changes=['Natural paths prepare N/R and fixed waves prepare R/R index storage once; no hot nested bucket vectors.',
          'Actual full-hit width1, first-seen order, resource-driven shrink and only-completed-prefix marking retained.',
          'Fixed whole-wave row preflight precedes bucket execution; old cold shape-planning API unchanged.',
          'Borrowed selections stay local; no lease/history/report container or state budget copied into scratch.'],
 host_properties=host,host_review=read(D/'host-check1/review.json'),
 actual_consumer=consumer,source_only=read(D/'source-only.json'),
 limitations=['Host checks observe selected-pointer stability and four finite properties, not a global allocation trace.',
              'Actual model consumer is the existing small A-only Windows Vulkan fixture; no full-model quality, all-platform or TPS claim.',
              'Cross-family phase/repair adapters and request/report separation remain unfinished.'],
 SDK_builds=0,HTTP_requests=0,downloads_bytes=0,archive=pin(archive),
 cleanup='Rebuildable private checks removed via root test.ps1 after publication; commands/source/results and original caches retained.')
save(O/(NAME+'.json'),report)
print(json.dumps(dict(report=pin(O/(NAME+'.json')),archive=pin(archive))))
