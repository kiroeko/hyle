# Reusable finite batch index worklists

BatchIndices contains only completion bytes and selected indices. The caller
still owns compatibility, version admission, payloads, state, execution and
retained reports. It introduces no scheduler, registry or second budget table.

Natural requests prepare candidate capacity N and batch capacity R before ready;
fixed replay prepares R/R, matching the existing finite wave planner. Current
CLI already requires R <= N. Actual full-hit selection passes limit1, so it can
stop after its first member. Other groups preserve first-seen order and their
original caller-owned role/phase/row predicates.

Natural resource admission may shrink a selected group. The temporary payload
bucket shrinks as before; only its completed prefix is marked, after successful
execution and the existing member-report reserve. Unselected suffix members
remain eligible. Call/lease/history/report containers are not reused as indices.

Fixed replay validates every resolved row and the complete wave length before
any selection can submit. This preserves the previous all-wave preflight error
boundary. Zero-row full hits remain host-only. The original cold shape-planning
bucket API is unchanged; only hot bucket materialization is removed.

Selection spans borrow the scratch until the next prepare/reset/select. No span
is stored into retained reports. Copy/move is disabled so logical preparation
cannot outlive or lose its reserved buffers. N1/R1 uses inline storage; larger
capacity is reserved once. Host checks observe selected-pointer stability and
exactly-once membership after shrink, not a global allocator or TPS trace.

The finite current consumer separately checks natural Text/MTP, multi-turn
prefix/eviction/rebuild, late I/O idempotence and fixed replay. Its prior actual
baseline and the intervening K1 migration evidence are identified explicitly.
No numerical graph, device resource, dtype, RNG or model publication changed.
