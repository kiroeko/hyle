"""Mixed SDK shipping boundaries; source math already qualified, no CPU performance reopen."""
exec(open('.scratch/cuda-u3-windows-shared-runtime.py',encoding='utf-8').read()
    .replace("cuda-shared-consumer", "mixed-shared-consumer")
    .replace("windows-shared-runtime", "windows-mixed-shared-runtime")
    .replace("print(json.dumps(records[-1]),flush=True)",
             "print(json.dumps({k:v for k,v in records[-1].items() if k!='args'}),flush=True)"))
run('cpu-independent-route',[build/'u3_mixed_cpu.exe','--gtest_filter=MixedCpuDelivery.*',
    '--gtest_output=xml:'+str(out/'cpu-independent-route.xml')])
