exec(open('.scratch/cpu-ggml-isa-probe.py',encoding='utf-8').read().split('records=[]')[0])
args=['wsl.exe','-d','Ubuntu-24.04','--','python3',
      '/mnt/c/public/project-hyle/hyle/.scratch/cuda-u3-linux-static-resume.py']
r=subprocess.run(args,env=env,**flags);r.check_returncode()
