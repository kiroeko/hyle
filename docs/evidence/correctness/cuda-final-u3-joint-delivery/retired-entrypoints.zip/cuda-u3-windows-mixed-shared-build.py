"""Mixed shipping build only; original CPU closure is not reopened."""
exec(open('.scratch/cpu-ggml-isa-probe.py',encoding='utf-8').read().split('records=[]')[0])
root=Path('C:/hv/cuda-u3-delivery');build=Path('C:/hv/m2b1-cuda')
consumer=repo/'.scratch/validation/cuda-final-u3-delivery/consumer'
out=repo/'.scratch/validation/cuda-final-u3-delivery/windows-mixed-shared';out.mkdir(exist_ok=True)
installed=root/'mixed-shared-installed';relocated=root/'mixed-shared-relocated'
records=[];assert not (out/'receipt.json').exists();assert not installed.exists() and not relocated.exists()
candidate=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
assert not subprocess.check_output(['git','status','--porcelain'],text=True).strip()
def run(name,args):
    args=list(map(str,args));start=time.monotonic()
    with (out/(name+'.log')).open('wb') as f:r=subprocess.run(args,env=env,stdout=f,stderr=subprocess.STDOUT,**flags)
    records.append({'name':name,'candidate':candidate,'args':args,'returncode':r.returncode,'seconds':round(time.monotonic()-start,3)})
    (out/'receipt.json').write_text(json.dumps(records,indent=2)+'\n');print(json.dumps({k:v for k,v in records[-1].items() if k!='args'}),flush=True)
    if r.returncode:print((out/(name+'.log')).read_text(errors='replace')[-3500:]);r.check_returncode()
run('source-configure-mixed',['cmake','-S',repo,'-B',build,'-DHYLE_COMPUTE_CPU=ON','-DHYLE_STATIC=OFF',
    '-DCMAKE_INSTALL_PREFIX='+installed.as_posix()])
if os.environ.get('U3_CONFIGURE_ONLY')=='1':
    print('Prepared next shipping configure only; heavy build not started',flush=True)
    raise SystemExit(0)
run('source-build-mixed',['cmake','--build',build,'--target','u3_delivery','--parallel','2'])
run('install-mixed',['cmake','--install',build]);installed.rename(relocated)
cache=(root/'cuda-shared-consumer/CMakeCache.txt').read_text(errors='replace')
def value(key):return next(line.split('=',1)[1] for line in cache.splitlines() if line.startswith(key+':'))
cb=root/'mixed-shared-consumer'
run('sdk-configure-mixed',['cmake','-S',consumer,'-B',cb,'-G','Ninja','-DCMAKE_BUILD_TYPE=Release',
    '-DCMAKE_PREFIX_PATH='+relocated.as_posix(),'-DU3_REFERENCE_DIR='+value('U3_REFERENCE_DIR'),
    '-DU3_GTEST_SOURCE='+value('U3_GTEST_SOURCE'),'-DU3_LIB_PREFIX=','-DU3_LIB_SUFFIX=.lib',
    '-DFETCHCONTENT_FULLY_DISCONNECTED=ON'])
run('sdk-build-mixed',['cmake','--build',cb,'--target','u3_delivery','--parallel','2'])
print('Mixed shared source + SDK built; GPU and independent CPU consumer qualification remains',flush=True)
