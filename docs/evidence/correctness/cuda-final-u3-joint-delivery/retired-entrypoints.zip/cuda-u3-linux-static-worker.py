"""Linux CUDA-only source + relocated static SDK, existing vendor objects reused."""
import json,os,subprocess,time
from pathlib import Path
root=Path('/root/hyle-scratch/active-cpu-z');source=root/'source';build=root/'build'
delivery=root/'cuda-u3-delivery';inputs=json.loads((delivery/'inputs.json').read_text())
consumer=Path(inputs['consumer']);reference=Path(inputs['reference'])
out=Path('/mnt/c/public/project-hyle/hyle/.scratch/validation/cuda-final-u3-delivery/linux-cuda-static');out.mkdir(exist_ok=True)
installed=delivery/'static-installed';relocated=delivery/'static-relocated'
env=dict(os.environ,CC='gcc-14',CXX='g++-14',CUDAHOSTCXX='/usr/bin/g++-13',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1')
env['PATH']='/usr/local/cuda-13.3/bin:'+env['PATH'];env.pop('LD_LIBRARY_PATH',None)
env['HYLE_D5_QWEN35_FIXTURE']=str(root/'cpu-final-qwen-fixture/fixture')
records=[];assert not (out/'receipt.json').exists();assert not installed.exists() and not relocated.exists()
def run(name,args,timeout=None):
    args=list(map(str,args));start=time.monotonic()
    with (out/(name+'.log')).open('wb') as f:
        result=subprocess.run(args,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=timeout)
    records.append({'name':name,'candidate':inputs['candidate'],'args':args,'returncode':result.returncode,'seconds':round(time.monotonic()-start,3)})
    (out/'receipt.json').write_text(json.dumps(records,indent=2)+'\n');print(json.dumps({k:v for k,v in records[-1].items() if k!='args'}),flush=True)
    if result.returncode:print((out/(name+'.log')).read_text(errors='replace')[-3500:]);result.check_returncode()
overlay=delivery/'overlay.cmake'
overlay.write_text('''function(u3_source_consumer)
set(U3_SOURCE_MODE ON)
include("'''+consumer.as_posix()+'''/targets.cmake")
endfunction()
if(CMAKE_CURRENT_SOURCE_DIR STREQUAL CMAKE_SOURCE_DIR)
set(U3_CONSUMER_SOURCE "'''+consumer.as_posix()+'''")
include("'''+consumer.as_posix()+'''/dependencies.cmake")
cmake_language(DEFER CALL u3_source_consumer)
endif()
''')
common=['-DU3_REFERENCE_DIR='+reference.as_posix(),'-DU3_GTEST_SOURCE='+inputs['gtest'],
    '-DU3_LIB_PREFIX=lib','-DU3_LIB_SUFFIX=.a','-DFETCHCONTENT_FULLY_DISCONNECTED=ON']
run('source-configure',[source/'scripts/hyle-unix.sh','cmake','--preset','compute-cuda','-S',source,'-B',build,*common,
    '-DHYLE_STATIC=ON','-DHYLE_INSTALL=ON','-DHYLE_BUILD_TESTS=OFF','-DHYLE_COMPONENTS=compute;graph;simd',
    '-DCMAKE_CUDA_ARCHITECTURES=89-real','-DCMAKE_PROJECT_INCLUDE='+overlay.as_posix(),
    '-DCMAKE_INSTALL_PREFIX='+installed.as_posix()])
if os.environ.get('U3_CONFIGURE_ONLY')=='1':
    print('Prepared Linux static configure only; heavy build is deliberately not started',flush=True)
    raise SystemExit(0)
run('source-build',['cmake','--build',build,'--target','u3_delivery','--parallel','2'])
run('source-admission',[build/'bin/u3_admission','--gtest_filter=*D5Qwen35Official*','--gtest_output=xml:'+str(out/'source-admission.xml')],120)
run('source-local-graph',[build/'bin/u3_graph_local','--gtest_filter=*D5Qwen35Official*','--gtest_output=xml:'+str(out/'source-local-graph.xml')],120)
run('source-ref-regression',[build/'bin/u3_direct','--gtest_filter=CudaSidecarReference.*',
    '--gtest_output=xml:'+str(out/'source-reference.xml')],120)
run('install',['cmake','--install',build]);installed.rename(relocated)
cb=delivery/'static-consumer'
run('sdk-configure',['cmake','-S',consumer,'-B',cb,'-G','Ninja','-DCMAKE_BUILD_TYPE=Release',*common,
    '-DCMAKE_PREFIX_PATH='+relocated.as_posix()])
run('sdk-build',['cmake','--build',cb,'--target','u3_delivery','--parallel','2'])
print('Linux source + relocated static SDK built; full shipping seam qualification follows',flush=True)
