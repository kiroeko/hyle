"""Same declared shipping checks in Linux, without a second Windows-only driver."""
import pathlib
p=pathlib.Path('/mnt/c/public/project-hyle/hyle/.scratch/cuda-u3-windows-shared-runtime.py')
text=p.read_text()
bootstrap="exec(open('.scratch/cpu-ggml-isa-probe.py',encoding='utf-8').read().split('records=[]')[0])"
linux=r'''import json,os,subprocess,time
from pathlib import Path
repo=Path('/mnt/c/public/project-hyle/hyle')
env=dict(os.environ);env['PATH']='/usr/local/cuda-13.3/bin:'+env['PATH'];env.pop('LD_LIBRARY_PATH',None)
flags={}
'''
text=text.replace(bootstrap,linux)
text=text.replace("Path('C:/hv/cuda-u3-delivery/cuda-shared-consumer')",
                  "Path('/root/hyle-scratch/active-cpu-z/cuda-u3-delivery/static-consumer')")
text=text.replace('windows-shared-runtime','linux-static-runtime')
text=text.replace("str(repo/'.scratch/d5-qwen35-six-profile-fixture')",
                  "'/root/hyle-scratch/active-cpu-z/cpu-final-qwen-fixture/fixture'")
start=text.index('for key in list(runtime):')
end=text.index('items=re.findall',start)
text=text[:start]+text[end:]
text=text.replace("'.exe'", "''").replace(".exe'", "'")
text=text.replace("print(json.dumps(records[-1]),flush=True)",
                  "print(json.dumps({k:v for k,v in records[-1].items() if k!='args'}),flush=True)")
exec(compile(text,str(p),'exec'))
