exec(open('.scratch/cuda-u3-windows-static-delivery.py',encoding='utf-8').read().split("\nrun('source-configure'")[0].replace('windows-cuda-static-r2','windows-cuda-static-r3'))
previous=json.loads((out.parent/'windows-cuda-static-r2/receipt.json').read_text())
assert all(row['candidate']==candidate for row in previous)
assert any(row['name']=='source-build' and row['returncode']==0 for row in previous)
for target in ('u3_direct','u3_graph'):
 run('source-'+target,[build/'bin'/(target+'.exe'),'--gtest_filter='+filter,
  '--gtest_output=xml:'+str(out/(target+'.xml'))])
run('install',['cmake','--install',build]);installed.rename(relocated)
cb=root/'cuda-static-consumer'
run('sdk-configure',['cmake','-S',consumer,'-B',cb,'-G','Ninja','-DCMAKE_BUILD_TYPE=Release',*common,'-DCMAKE_PREFIX_PATH='+relocated.as_posix()])
run('sdk-build',['cmake','--build',cb,'--target','u3_delivery','--parallel','2'])
runtime=dict(env)
for key in list(runtime):
 if key.lower()=='path':del runtime[key]
runtime['PATH']=os.environ['SystemRoot']+'/System32;'+os.environ['SystemRoot']
run('sdk-run',['ctest','--test-dir',cb,'-R','^u3_(direct|graph)$','--verbose','--output-on-failure','--no-tests=error','-j','1','--output-junit',out/'sdk.xml'],runtime)
