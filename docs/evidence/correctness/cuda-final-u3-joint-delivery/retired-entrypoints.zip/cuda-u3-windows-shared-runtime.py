"""Shared ABI/loading verification; exact native mathematics remains qualified."""
exec(open('.scratch/cpu-ggml-isa-probe.py',encoding='utf-8').read().split('records=[]')[0])
import re
build=Path('C:/hv/cuda-u3-delivery/cuda-shared-consumer')
out=repo/'.scratch/validation/cuda-final-u3-delivery/windows-shared-runtime';out.mkdir(exist_ok=True)
runtime=dict(env,OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',HYLE_D5_QWEN35_FIXTURE=str(repo/'.scratch/d5-qwen35-six-profile-fixture'))
for key in list(runtime):
    if key.lower()=='path':del runtime[key]
runtime['PATH']=os.environ['SystemRoot']+'/System32;'+os.environ['SystemRoot']
items=re.findall(r'\{"([a-z0-9]+)",Kind::(\w+),(GGML_TYPE_\w+),[^,]+,(true|false),(\d+),(\d+),(\d+),',
    (repo/'tests/compute_models/cpu_c5_gguf_inputs.h').read_text())
assert len(items)==559,len(items)
selected={}
for identifier,kind,dtype,packed,k,n,e in items:
    cost=int(k)*int(n)*(min(int(e),8) if kind=='kExpert' else 1)
    key=kind,dtype
    if key not in selected or cost<selected[key][0]:selected[key]=(cost,identifier)
flt=':'.join('*ActualRoleAndWidthUseOriginalCodecAcrossReplay/'+item[1] for item in selected.values())
(out/'plan.json').write_text(json.dumps({'math':'Reuse sealed native 651/649 and static SDK full union; product mathematics unchanged',
    'delivery':'Every physical GGUF kind/type pair plus all packed contracts, full current programs/families and public resource/lifetime seams',
    'gguf_pairs':{str(key):value[1] for key,value in selected.items()},'flags':'SHARED ABI; system-only PATH; staged DLLs'},indent=2)+'\n')
records=[];assert not (out/'receipt.json').exists()
def run(name,args):
    args=list(map(str,args));start=time.monotonic()
    with (out/(name+'.log')).open('wb') as f:
        try:r=subprocess.run(args,env=runtime,stdout=f,stderr=subprocess.STDOUT,timeout=300,**flags);rc=r.returncode
        except subprocess.TimeoutExpired:rc=124
    records.append({'name':name,'args':args,'returncode':rc,'seconds':round(time.monotonic()-start,3)})
    (out/'receipt.json').write_text(json.dumps(records,indent=2)+'\n');print(json.dumps(records[-1]),flush=True)
    if rc:print((out/(name+'.log')).read_text(errors='replace')[-2400:]);raise SystemExit(rc)
for entry in ('direct','graph'):
    exe=build/('u3_'+entry+'.exe')
    for group,group_filter in [('gguf-pairs',flt),('packed','*N1*:*N2*'),
        ('families','*MoeFragments.D5Glm*:*MoeFragments.D5Kimi*:*MoeFragments.D5Kda*:*MoeFragments.D5SixProfiles*:*MoeFragments.D5EightGguf*:*MoeFragments.D5OfficialKimi*:*MoeFragments.D5Thirteen*:*QwenRecurrent.D5NineProfiles*:CudaDefaultCompute.*')]:
        name=entry+'-'+group
        run(name,[exe,'--gtest_filter='+group_filter,'--gtest_output=xml:'+str(out/(name+'.xml'))])
    text=subprocess.check_output([str(exe),'--gtest_filter=*CurrentRegions.*:*C5Parameters*:*C5NewDeepSeek*',
        '--gtest_list_tests'],env=runtime,text=True,**flags)
    names=[];suite=''
    for line in text.splitlines():
        body=line.split(' #')[0].strip()
        if line and not line.startswith(' ') and body.endswith('.'):suite=body
        elif line.startswith('  ') and suite:names.append(suite+body)
    assert len(names)==21
    for index,test in enumerate(names):
        name=entry+'-current-'+str(index)
        run(name,[exe,'--gtest_filter='+test,'--gtest_output=xml:'+str(out/(name+'.xml'))])
for name,exe,filter in [('admission','u3_admission','*D5Qwen35Official*'),
    ('graph-local','u3_graph_local','*D5Qwen35Official*:CudaDefaultGraph.DenseFfnCapturesTwoSlotsAndChangingInputs:CudaDefaultGraph.RejectsMissingResourcesAndUnsupportedOperations')]:
    run(name,[build/(exe+'.exe'),'--gtest_filter='+filter,'--gtest_output=xml:'+str(out/(name+'.xml'))])
