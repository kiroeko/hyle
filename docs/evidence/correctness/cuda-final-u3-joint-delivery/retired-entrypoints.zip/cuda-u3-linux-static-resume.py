import pathlib,json
p=pathlib.Path('/mnt/c/public/project-hyle/hyle/.scratch/cuda-u3-linux-static-worker.py')
text=p.read_text()
text=text.replace("records=[];assert not (out/'receipt.json').exists();assert not installed.exists() and not relocated.exists()",
    "records=json.loads((out/'receipt.json').read_text());assert len(records)==1 and records[0]['returncode']==0;assert not installed.exists() and not relocated.exists()")
start=text.index("run('source-configure',")
end=text.index("run('source-build',",start)
text=text[:start]+text[end:]
exec(compile(text,str(p),'exec'))
