text=open('.scratch/cuda-u3-windows-mixed-shared-build.py',encoding='utf-8').read()
text=text.replace('windows-mixed-shared','windows-mixed-static')
for part in ('installed','relocated','consumer'):text=text.replace('mixed-shared-'+part,'mixed-static-'+part)
text=text.replace('-DHYLE_STATIC=OFF','-DHYLE_STATIC=ON')
text=text.replace("records=[];assert not (out/'receipt.json').exists();assert not installed.exists() and not relocated.exists()",
    "records=json.loads((out/'receipt.json').read_text());assert len(records)==1 and records[0]['returncode']==0;assert not installed.exists() and not relocated.exists()")
start=text.index("run('source-configure-mixed',")
end=text.index("run('source-build-mixed',",start)
text=text[:start]+text[end:]
exec(compile(text,'.scratch/cuda-u3-windows-mixed-shared-build.py','exec'))
