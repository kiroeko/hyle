"""Publish this consumer batch once; do not overwrite historical windows."""
from pathlib import Path
import hashlib
import json
import zipfile

C = Path(__file__).resolve().parent
R = C.parents[1]
S = R / '.scratch/architecture-refactor-2026-10-18/d4-windows-preparation-2026-10-21/first-decode-startup-2026-10-21/multi-session-isolation-2026-10-21'
E = R / 'docs/evidence/correctness'
name = 'qwen-session-capacity-2026-10-21'
artifact, bundle = E / (name + '.json'), E / (name + '.zip')
assert not artifact.exists() and not bundle.exists()


def read(p):
    return json.loads(p.read_text(encoding='utf-8-sig'))


def identity(p):
    data = p.read_bytes()
    return dict(path=str(p.resolve()), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())


summary = read(C / 'validation/attempt1/summary.json')
assert summary['passed'] and len(summary['cases']) == 3
assert all(x['passed'] and x['vector_count'] == 72 for x in summary['cases'].values())
assert len(summary['invalid']) == 4 and all(x['passed'] for x in summary['invalid'].values())
review = read(C / 'runtime-independent-review.json')
ready = read(C / 'ready-for-root.json')
assert identity(Path(ready['image']['path'])) == ready['image']
files = set()
extensions = ('.json', '.py', '.cc', '.h', '.log', '.tsv', '.txt', '.diff')
for root in (C, S / 'cache', S / 'inputs'):
    for p in root.rglob('*'):
        if p.is_file() and p.suffix in extensions:
            files.add(p)
for name in ('run.py',):
    files.add(S / name)
files.add(R / 'include/hyle/compute/resource_budget.h')
files.add(R / 'src/compute/resource_budget.cc')
E.mkdir(parents=True, exist_ok=True)
with zipfile.ZipFile(bundle, 'x', zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
    for p in sorted(files):
        archive.write(p, p.relative_to(R).as_posix())
result = dict(date='2026-10-21', scope='Real CUDA test consumer: count/byte cache admission, idle LRU and full-state reconstruction on the original Model/Invocation chain.',
    throughput_evidence=False, source=ready['source'], image=ready['image'],
    build=dict(CXX=1, links=1, NVCC=0, SDK_builds=0,
        product_inputs=190, replaced_inputs=1,
        qualification='Only consumer main object changed in the retained closure. Concurrent new paged-append core work was not linked or validated by these runs.'),
    mechanism=dict(parameters=['capacity per sequence', 'max retained cache sessions', 'active request sequences', 'cache state requested-byte budget'],
        auto='Resolve from actual input session count and state budget; no fixed number of users. No preallocation of the configured maximum.',
        budget='Separate ResourceBudget. One aggregate per-session reservation before the first state allocation; released after original slots and state buffers are destroyed.',
        bytes='39,075,840 + 12,288 * context_capacity;84 dense KV/conv/GDN Buffer requests per session, including both recurrent banks. At256:42,221,568 bytes.',
        retirement='Only idle unpinned entries are eligible. Callback must drain and destroy actual Session before the directory removes its byte charge; failure remains charged and aborts admission.',
        restore='Consumer retains actual input history, reruns original chunks and checks prior output IDs; later endpoint vectors also match the independent baseline.',
        hot_path='Directory/admission/pinning happen at request/turn boundaries. Each decode directly uses its current Session. Cache count1 introduces no different mathematical kernel.'),
    results=summary, cache_directory_host_checks=read(S / 'cache/host-result.json'),
    consumer_source_review=read(C / 'consumer-review.json'), resource_review=read(C / 'resource-review.json'),
    independent_runtime_review=review,
    limits=['State requested bytes are not physical VRAM; weights, IO/workspace, capture/native private storage, allocator/driver overhead and external processes are separate.',
        'All216 endpoint vectors came from diagnostic export runs, not a new speed/memory-peak comparison.',
        'Each active request is one complete prompt/decode turn; cohorts interleave complete calls on one original queue. No simultaneous GPU batching or service throughput claim.',
        'Eviction restoration is full-history recomputation, not shared-prefix/COW cache reuse.',
        'Shared-prefix/COW, asynchronous page retirement, full MTP, image encoder/projector and architecture completion remain pending.'],
    bundle=identity(bundle), bundle_files=len(files), binary_tensor_payloads_archived=False,
    reproduction='Matching retained model/dependencies are required. Bundle retains input IDs, frozen consumer source/headers,190-input identities, commands, raw logs, hashes, host checks and independent recomputation scripts; no model weights, SDK copies, binaries or duplicate tensor payloads.')
artifact.write_text(json.dumps(result, indent=2, ensure_ascii=False, allow_nan=False) + '\n', encoding='utf-8')
print(identity(artifact))
print(identity(bundle), len(files), 'members')
