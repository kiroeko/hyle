"""Host-only independent audit of completed capacity/LRU consumer processes. No model execution."""
from pathlib import Path
import hashlib,json,re,shlex
C=Path(__file__).resolve().parent
R=C.parents[1]
S=R/".scratch/architecture-refactor-2026-10-18/d4-windows-preparation-2026-10-21/first-decode-startup-2026-10-21/multi-session-isolation-2026-10-21"
A=C/"validation/attempt1";B=R/".scratch/multi-session-20261021/attempt2/baseline"
cache={}
def load(p):return json.loads(Path(p).read_text())
def identity(p):
 p=Path(p).resolve()
 if p not in cache:
  b=p.read_bytes();cache[p]=dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
 return cache[p]
def match(row):
 x=identity(row["path"]);assert all(x[k]==row[k] for k in ("bytes","sha256"));return x
summary=load(A/"summary.json");assert summary["passed"] and summary["gpu_model_processes"]==3 and summary["invalid_early_rejections"]==4
for k in ("runner","helper","ready","input_plan"):match(summary[k])
ready=load(C/"ready-for-root.json");match(ready["image"]);match(ready["identity"]);match(ready["link_plan"]);match(ready["runtime_environment"])
frozen=Path(ready["image"]["path"]).parent/"source/tools/qwen35_text/main.cc";assert identity(frozen)["sha256"]==ready["source"]["sha256"]
plan=load(S/"inputs/plan.json");ids=list(plan["cases"]);assert ids==["alice","bob","carol","dave"]
per=18*2*(1*3*6144*2+1*16*128*128*4)+6*2*256*512*2;assert per==42_221_568
calls={};phases={}
for sid,case in plan["cases"].items():
 schedule=Path(case["schedule"]["path"]);match(case["schedule"]);visible=0;sc=[];ps=[]
 for line in schedule.read_text().splitlines():
  words=shlex.split(line,comments=True)
  if not words:continue
  kind,file=words;assert kind==("prompt" if len(ps)%2==0 else "decode")
  tokens=[int(x) for x in (schedule.parent/file).read_text().split()];assert tokens and all(0<=x<248320 for x in tokens)
  turn=len(ps)//2+1;name=f"round{turn}_"+("prefill" if kind=="prompt" else "decode");start=visible
  for local,chunk in enumerate([tokens] if kind=="prompt" else [[x] for x in tokens]):
   visible+=len(chunk);sc.append(dict(name=name if kind=="prompt" else name+str(local+1),ids=chunk,visible_tokens=visible,phase=len(ps)))
  ps.append(dict(turn=turn,kind="prefill" if kind=="prompt" else "decode",name=name,input_tokens=len(tokens),calls=1 if kind=="prompt" else len(tokens),generated_tokens=1 if kind=="prompt" else len(tokens),context_before=start,context_after=visible))
 assert sc==case["calls"] and len(sc)==9 and visible<=256
 calls[sid]=sc;phases[sid]=ps

def derive(active,max_sessions,max_bytes):
 # Independent simple owner-name LRU simulation; no production cache/header import.
 resident=set();pinned=set();idle=[];history={sid:[] for sid in ids};evictions=[];admissions=[];hits={sid:0 for sid in ids};misses=hits.copy();restored={sid:[] for sid in ids};dispatch=[];peak=0
 def acquire(sid):
  nonlocal peak
  if sid in pinned:return
  if sid in resident:
   hits[sid]+=1;idle.remove(sid)
  else:
   while len(resident)>=max_sessions or (len(resident)+1)*per>max_bytes:
    assert idle;victim=idle.pop(0);assert victim not in pinned
    evictions.append(victim);resident.remove(victim)
   misses[sid]+=1;restored[sid].extend(history[sid]);resident.add(sid)
   admissions.append(dict(session_id=sid,restore_calls=len(history[sid]),restore_tokens=sum(len(c["ids"]) for c in history[sid])))
   peak=max(peak,len(resident)*per)
  pinned.add(sid)
 for sid in ids[:active]:acquire(sid)
 for turn in (1,2):
  for first in range(0,len(ids),active):
   cohort=ids[first:first+active];selected={sid:[x for x in calls[sid] if phases[sid][x["phase"]]["turn"]==turn] for sid in cohort}
   for i in range(max(len(x) for x in selected.values())):
    for sid in cohort:
     if i>=len(selected[sid]):continue
     call=selected[sid][i]
     if i==0:acquire(sid)
     assert sid in pinned and sid in resident
     dispatch.append(sid);history[sid].append(call)
     if i+1==len(selected[sid]):pinned.remove(sid);idle.append(sid)
 assert not pinned
 return dict(dispatch=dispatch,evictions=evictions,peak=peak,live=len(resident)*per,retained=len(resident),hits=hits,misses=misses,restored=restored,admissions=admissions)

# Current consumer must overlay only main onto the exact old190input product closure.
linked=load(ready["link_plan"]["path"])
old_link=load(S.parent/"layout-workspace-facts-reuse-2026-10-21/checks/attempt1/link-plan.json")
key=lambda x:str(Path(x).resolve()).casefold()
new_inputs={key(x["path"]):x for x in linked["inputs"]};old_inputs={key(x["path"]):x for x in old_link["inputs"]}
assert len(new_inputs)==len(old_inputs)==190
added=[x for k,x in new_inputs.items() if k not in old_inputs];removed=[x for k,x in old_inputs.items() if k not in new_inputs]
assert len(added)==len(removed)==1 and Path(added[0]["path"]).name=="main.obj" and Path(removed[0]["path"]).name=="main.obj"
for k in new_inputs.keys()&old_inputs.keys():assert new_inputs[k]==old_inputs[k]
for row in linked["inputs"]:match(row)
processes=[];results={}
step_re=re.compile(r"^(round\d+_(?:prefill|decode\d+)) tokens=(\d+) visible=(\d+) .* next=(-?\d+)$",re.M)
config={"retained":(4,4,4*per),"count_bound":(2,2,4*per),"byte_bound":(1,4,per)}
for name,(active,limit,max_bytes) in config.items():
 folder=A/name;command=load(folder/"command.json");terminal=load(folder/"result.json");obs=load(folder/"observation.json")
 assert terminal["exit"]==0 and not terminal.get("timeout") and terminal["image"]==command["image"]==ready["image"]
 assert command["command"]==terminal["command"] and json.loads((folder/"stdout.log").read_text().splitlines()[-1])==obs
 match(command["ready"]);match(command["runtime_environment"])
 argv=terminal["command"]
 assert argv[0]==ready["image"]["path"] and argv[argv.index("--capacity")+1]=="256" and argv[argv.index("--trace-level")+1]=="decisions"
 assert argv[argv.index("--session-schedules")+1]==plan["manifests"]["4"]["manifest"]["path"]
 text=(folder/"stderr.log").read_text();assert text.count("resident text weights: 320 tensors, 3763655360 bytes")==1 and len(re.findall(r"^compile full text finite family variants=",text,re.M))==1
 assert "physical_vram_limit_known=false" in text
 expected=derive(active,limit,max_bytes)
 assert obs["execution"]=="turn_round_robin_serial" and obs["session_count"]==4 and obs["diagnostic"]
 assert obs["active_sequences"]==active and obs["max_cached_sessions"]==limit and obs["cache_state_bytes_per_session"]==per and obs["cache_requested_byte_limit"]==max_bytes
 assert obs["cache_peak_requested_bytes"]==expected["peak"] and obs["cache_live_requested_bytes"]==expected["live"] and obs["cache_retained_sessions"]==expected["retained"]
 assert obs["dispatch_session_ids"]==expected["dispatch"] and obs["evicted_session_ids"]==expected["evictions"]
 assert obs["generated_tokens"]==36 and obs["processed_tokens"]==239
 logged=step_re.findall(text);assert len(logged)==36
 vector_inventory=[];session_rows=[]
 for index,(sid,session) in enumerate(zip(ids,obs["sessions"])):
  prior=load(B/sid/"observation.json");assert session["session_id"]==sid and session["generated_ids"]==prior["generated_ids"]
  assert session["visible_tokens"]==session["processed_tokens"]==calls[sid][-1]["visible_tokens"] and session["generated_tokens"]==9
  assert session["decode_input_ids"]==[x["ids"][0] for x in calls[sid] if "decode" in x["name"]]
  assert session["phase_count"]==4 and session["turn_count"]==2
  for p,e in zip(session["phases"],phases[sid]):assert all(p[k]==v for k,v in e.items())
  assert session["cache_hits"]==expected["hits"][sid] and session["cache_misses"]==expected["misses"][sid]
  assert session["restored_calls"]==len(expected["restored"][sid]) and session["restored_tokens"]==sum(len(x["ids"]) for x in expected["restored"][sid])
  for row,call,predicted in zip(logged[index*9:(index+1)*9],calls[sid],session["generated_ids"]):assert row==(call["name"],str(len(call["ids"])),str(call["visible_tokens"]),str(predicted))
  old=B/sid/"trace";actual=folder/"trace"/session["trace_subdirectory"]
  required={f"{call['name']}/{filename}" for call in calls[sid] for filename in ("hidden.bf16","logits.f32")}
  for directory in (old,actual):assert {p.relative_to(directory).as_posix() for p in directory.rglob("*") if p.is_file() and p.suffix in (".bf16",".f32")}==required
  for relative in sorted(required):
   a,b=identity(old/relative),identity(actual/relative);assert a["bytes"]==b["bytes"]==(4096 if relative.endswith("hidden.bf16") else 993280)
   assert a["sha256"]==b["sha256"] and (old/relative).read_bytes()==(actual/relative).read_bytes()
   vector_inventory.append(dict(session_id=sid,vector=relative,bytes=b["bytes"],sha256=b["sha256"]))
  session_rows.append(dict(session_id=sid,visible_tokens=session["visible_tokens"],generated_ids=session["generated_ids"],cache_hits=session["cache_hits"],cache_misses=session["cache_misses"],restored_calls=session["restored_calls"],restored_tokens=session["restored_tokens"]))
 assert len(vector_inventory)==summary["cases"][name]["vector_count"]==72
 restored_calls=sum(x["restored_calls"] for x in session_rows);restored_tokens=sum(x["restored_tokens"] for x in session_rows)
 assert (restored_calls,restored_tokens)==((0,0) if name=="retained" else (18,185))
 results[name]=dict(passed=True,decision_vectors=72,byte_identical=True,vector_inventory_sha256=hashlib.sha256(json.dumps(vector_inventory,sort_keys=True).encode()).hexdigest(),session_results=session_rows,primary_calls=36,primary_input_tokens=239,primary_prefill_calls=8,primary_decode_calls=28,restored_calls=restored_calls,restored_input_tokens=restored_tokens,evicted_sessions=expected["evictions"],independently_derived_admissions=expected["admissions"],peak_requested_cache_bytes=expected["peak"],final_live_requested_cache_bytes=expected["live"],final_resident_sessions=expected["retained"],requested_cache_limit=max_bytes,active_sequences=active)
 processes.append(dict(name=name,pid=terminal["pid"],exit=0,start=terminal["started_unix_ns"],end=terminal["finished_unix_ns"],image=terminal["image"],weight_loads=1,family_compiles=1,records=[identity(folder/x) for x in ("command.json","result.json","stdout.log","stderr.log","observation.json")]))
ordered=sorted(processes,key=lambda x:x["start"]);assert all(a["end"]<=b["start"] for a,b in zip(ordered,ordered[1:]))
invalid=[]
for name,expected in (("below_one","cannot hold one session"),("active_count","cannot exceed"),("active_bytes","cannot hold all configured active"),("malformed","requires a positive integer")):
 folder=A/"invalid"/name;command=load(folder/"command.json");row=summary["invalid"][name];text=(folder/"stderr.log").read_text()
 assert command["image"]==ready["image"] and command["command"][0]==ready["image"]["path"]
 assert row["exit"]==1 and row["passed"] and row["expected"]==expected
 assert expected in text and not (folder/"stdout.log").read_bytes()
 assert all(x not in text for x in ("resident text weights","ggml_cuda_init","compile full text finite family","initialized model_seconds"))
 invalid.append(dict(name=name,reported_exit=1,error=text.strip(),rejected_before_Model_construction=True,records=[identity(folder/x) for x in ("command.json","stdout.log","stderr.log")],exit_record_scope="Exit1 is retained in the actual aggregate summary/runner subprocess.returncode record; no separate invalid/result.json was written."))
source_text=frozen.read_text();assert source_text.index('if (cache_bytes < bytes_per_session)')<source_text.index('qwen35::Model model(')
assert source_text.index('if (active_sequences > max_sessions)')<source_text.index('qwen35::Model model(')
assert source_text.index('if (active_slots > cache_bytes / bytes_per_session)')<source_text.index('qwen35::Model model(')
assert 'positive_size(option, value)' in source_text
report=dict(schema="hyle.multi-session-capacity-runtime-independent-review.v1",status="pass_for_recorded_consumer_scope",summary=identity(A/"summary.json"),runner=identity(C/"validate.py"),independent_script=identity(__file__),source=identity(frozen),image=ready["image"],input_plan=identity(S/"inputs/plan.json"),baseline="Original W ff748694 independent single-session decision traces under .scratch/multi-session-20261021/attempt2/baseline, reused without execution",closure=dict(inputs=190,only_replaced_input=added[0],removed_input=removed[0],unchanged_product_inputs=189,all_inputs_current_file_hashes_match=True,new_paged_append_code_linked=False,limitation="Exact object equality against the old W190 closure proves this is only consumer capacity/admission/replay. New library paged-append source is not exercised by these images."),processes=processes,cases=results,invalid_early_rejections=invalid,totals=dict(model_processes=3,early_error_processes=4,decision_vector_comparisons=216,distinct_primary_session_journeys=4,primary_calls=108,primary_input_tokens=717,additional_restored_calls=36,additional_restored_input_tokens=370,all_full_evaluate_calls_including_restoration=144,reviewer_GPU_runs=0,reviewer_builds=0,source_edits=0),conclusion="All three finite retained/count-bound/byte-bound journeys preserve original per-session hidden/logits bytes, token IDs and contexts. Independent owner-name LRU simulation reproduces six/seven evictions and restoration of the exact original first-turn chunks. Managed cache requested-byte peaks are exactly4/2/1 times42,221,568B. No blocking evidence mismatch found.",scope_limits=["Requested state bytes are not physical GPU peak. Model weights, GraphIO/slots/workspace/capture/native-private storage, driver overhead and other processes are outside this cache admission quota.","Restoration counters were independently derived from original call histories and match runtime; source replays the original chunks and checks every restored predictedID. Restoration hidden/logits vectors were not separately exported, so only the subsequent primary decision vectors are byte-compared.","Restoration is full recomputation of the original chunk history, not page/prefix/COW reuse or a cache hit. Each bounded case adds18calls/185tokens; retained adds none.","These are traced diagnostic processes, not throughput or latency comparisons. Actual restoration/preparation remains in complete phase/session timing, while primary step_sum excludes separate restoration work.","No simultaneous GPU execution, async eviction/cancellation failure, new paged append, complete internal-state bit dump, model quality or all-domain qualification is established."],anchors=[dict(path="tools/qwen35_text/main.cc",frozen_sha256=ready["source"]["sha256"],lines="1219-1261",fact="Strict capacity/active/byte preflight precedes Model creation"),dict(path="tools/qwen35_text/main.cc",lines="1360-1401",fact="LRU victim original Session drains and is destroyed before directory bytes return; missing owner reconstructs the original history chunks and checks outputs/context"),dict(path="tools/qwen35_text/main.cc",lines="1429-1449",fact="Admission occurs at prompt/turn boundary, decode uses original Session; original completed host endpoint precedes unpin"),dict(path="tools/qwen35_text/session_cache.h",lines="153-202",fact="Only idle entries are reclaimed; original retire callback must succeed before retained byte counters decrease")])
(C/"runtime-independent-review.json").write_text(json.dumps(report,indent=2)+"\n",encoding="utf8")
print(json.dumps({"report":identity(C/"runtime-independent-review.json"),"cases":{k:{field:v[field] for field in ("decision_vectors","restored_calls","restored_input_tokens","evicted_sessions","peak_requested_cache_bytes")} for k,v in results.items()}}))
