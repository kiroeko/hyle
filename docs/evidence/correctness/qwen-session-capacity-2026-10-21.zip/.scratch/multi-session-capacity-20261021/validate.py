"""Root-only three meaningful bounded-cache journeys, no timing claims."""
from pathlib import Path
import importlib.util
import os
import subprocess
import sys
sys.dont_write_bytecode = True
C = Path(__file__).resolve().parent
R = C.parents[1]
S = R / '.scratch/architecture-refactor-2026-10-18/d4-windows-preparation-2026-10-21/first-decode-startup-2026-10-21/multi-session-isolation-2026-10-21'
spec = importlib.util.spec_from_file_location('isolation', S / 'run.py')
h = importlib.util.module_from_spec(spec)
spec.loader.exec_module(h)
m = h.m
plan = m.read(S / 'inputs/plan.json')
base = R / '.scratch/multi-session-20261021/attempt2/baseline'
out = C / 'validation/attempt1'
out.mkdir(parents=True, exist_ok=False)
per = 42_221_568
cases = (
    ('retained', ['--max-sessions', 'auto', '--active-sequences', 'auto', '--cache-bytes', 'auto'],
     4, 4, [], 0),
    ('count_bound', ['--max-sessions', '2', '--active-sequences', '2', '--cache-bytes', str(4 * per)],
     2, 2, ['bob', 'alice', 'carol', 'dave', 'alice', 'bob'], 18),
    ('byte_bound', ['--max-sessions', '4', '--active-sequences', 'auto', '--cache-bytes', str(per)],
     1, 1, ['alice', 'bob', 'carol', 'dave', 'alice', 'bob', 'carol'], 18),
)
result = dict(passed=False, throughput_evidence=False, runner=m.identity(__file__),
              helper=m.identity(S / 'run.py'), ready=m.identity(C / 'ready-for-root.json'),
              input_plan=m.identity(S / 'inputs/plan.json'), cases={}, invalid={})
m.save(out / 'summary.json', result)
for name, extra, active, resident, evicted, restored in cases:
    folder = out / name
    observation = h.run(folder, C / 'ready-for-root.json',
        ['--session-schedules', plan['manifests']['4']['manifest']['path'], *extra])
    assert observation['execution'] == 'turn_round_robin_serial'
    assert observation['session_count'] == 4 and observation['generated_tokens'] == 36
    assert observation['processed_tokens'] == 239
    assert observation['active_sequences'] == active
    assert observation['cache_state_bytes_per_session'] == per
    assert observation['cache_retained_sessions'] == resident
    assert observation['cache_live_requested_bytes'] == observation['cache_peak_requested_bytes'] == resident * per
    assert observation['cache_peak_requested_bytes'] <= observation['cache_requested_byte_limit']
    assert observation['evicted_session_ids'] == evicted
    assert sum(s['restored_calls'] for s in observation['sessions']) == restored
    assert sum(s['restored_tokens'] for s in observation['sessions']) == (185 if restored else 0)
    # Fixed known per-turn call counts, independent of the C++ cursor implementation.
    turn_calls = ({'alice': 5, 'bob': 4, 'carol': 3, 'dave': 6},
                  {'alice': 4, 'bob': 5, 'carol': 6, 'dave': 3})
    expected = []
    ids = ['alice', 'bob', 'carol', 'dave']
    for counts in turn_calls:
        for group in range(0, 4, active):
            cohort = ids[group:group + active]
            for call in range(max(counts[s] for s in cohort)):
                expected.extend(s for s in cohort if call < counts[s])
    assert observation['dispatch_session_ids'] == expected
    row = dict(passed=False, sessions={})
    for session in observation['sessions']:
        sid = session['session_id']
        h.check_session(session, plan['cases'][sid])
        prior = m.read(base / sid / 'observation.json')
        assert session['generated_ids'] == prior['generated_ids']
        assert session['cache_hits'] == (1 if name == 'retained' else 0)
        assert session['cache_misses'] == (1 if name == 'retained' else 2)
        pairs = h.check_vectors(base / sid / 'trace',
            folder / 'trace' / session['trace_subdirectory'], plan['cases'][sid]['calls'])
        row['sessions'][sid] = dict(vectors=pairs, cache_hits=session['cache_hits'],
            cache_misses=session['cache_misses'], restored_calls=session['restored_calls'],
            restored_tokens=session['restored_tokens'], passed=all(x['byte_equal'] for x in pairs))
    row['vector_count'] = sum(len(s['vectors']) for s in row['sessions'].values())
    row['passed'] = all(s['passed'] for s in row['sessions'].values())
    row['evicted_session_ids'] = observation['evicted_session_ids']
    row['cache_peak_requested_bytes'] = observation['cache_peak_requested_bytes']
    result['cases'][name] = row
    m.save(out / 'summary.json', result)
    assert row['passed'], 'Actual decision vectors differ; raw bytes/logs preserved'
    print(name + ': 72 decision vectors byte-identical; bounded charge/eviction/rebuild passed', flush=True)

ready = m.read(C / 'ready-for-root.json')
environment = os.environ.copy()
environment['PATH'] = m.read(ready['runtime_environment']['path'])['PATH']
original, _ = m.original_commands()
for name, args, expected in (
    ('below_one', ['--cache-bytes', str(per - 1)], 'cannot hold one session'),
    ('active_count', ['--max-sessions', '1', '--active-sequences', '2'], 'cannot exceed'),
    ('active_bytes', ['--max-sessions', '4', '--active-sequences', '2', '--cache-bytes', str(per)], 'cannot hold all configured active'),
    ('malformed', ['--capacity', '256trailing'], 'requires a positive integer'),
):
    folder = out / 'invalid' / name
    folder.mkdir(parents=True, exist_ok=False)
    command = [ready['image']['path'], '--inputs', original[original.index('--inputs') + 1],
        '--session-schedules', plan['manifests']['4']['manifest']['path'], '--capacity', '256', *args]
    m.save(folder / 'command.json', dict(command=command, throughput_evidence=False, image=ready['image']))
    p = subprocess.run(command, cwd=R, env=environment, capture_output=True, timeout=30,
                       creationflags=subprocess.CREATE_NO_WINDOW)
    (folder / 'stdout.log').write_bytes(p.stdout)
    (folder / 'stderr.log').write_bytes(p.stderr)
    stderr = p.stderr.decode('utf-8', errors='replace')
    ok = p.returncode == 1 and expected in stderr and 'resident text weights' not in stderr
    result['invalid'][name] = dict(passed=ok, exit=p.returncode, expected=expected,
                                   rejected_before_weight_load=True if ok else None)
    m.save(out / 'summary.json', result)
    assert ok, 'Invalid configuration unexpectedly reached execution or wrong error: ' + name
result['passed'] = True
result['gpu_model_processes'] = 3
result['invalid_early_rejections'] = 4
m.save(out / 'summary.json', result)
print('All three real-model journeys and four early admission errors passed.', flush=True)
