"""One consumer TU against retained190 library inputs; no new Graph library claim."""
from pathlib import Path
import importlib.util
import os
import sys
sys.dont_write_bytecode = True
C = Path(__file__).resolve().parent
R = C.parents[1]
P = R / '.scratch/architecture-refactor-2026-10-18/d4-windows-preparation-2026-10-21/first-decode-startup-2026-10-21/multi-session-isolation-2026-10-21'
F = P.parent
W = F / 'layout-workspace-facts-reuse-2026-10-21'
spec = importlib.util.spec_from_file_location('existing_build', W / 'build.py')
h = importlib.util.module_from_spec(spec)
spec.loader.exec_module(h)
b, c = h.b, h.c
out = C / 'checks/attempt1'
out.mkdir(parents=True, exist_ok=False)
(out / 'tmp').mkdir()
recipe_path = P / 'cli/checks/attempt2/identity.json'
recipe = c.read(recipe_path)
source = R / 'tools/qwen35_text/main.cc'
frozen = b.identity(source)
command = b.host_command(recipe['command'], source, 'main', out)
assert all(flag in command for flag in ('/WX', '/W4', '/MD', '/O2'))
c.save(out / 'compile-plan.json', dict(command=command, source=frozen, recipe=b.identity(recipe_path), CXX=1, NVCC=0, SDK_builds=0))
env, _ = b.environment(command, [], out)
c.execute('compile', command, env, out)
deps_path = out / 'main-deps.json'
deps = c.read(deps_path)['Data']
dependencies = [b.identity(p) for p in dict.fromkeys([deps['Source'], *deps['Includes']])]
assert h.same(frozen) and all(h.same(x) for x in dependencies)
obj = b.identity(out / 'main.obj')
c.save(out / 'identity.json', dict(command=command, source=frozen, object=obj, dependencies=dependencies, source_dependencies=b.identity(deps_path), recipe=b.identity(recipe_path)))
for name in ('main.cc', 'schedule.h', 'session_schedule.h', 'session_cache.h'):
    p = R / 'tools/qwen35_text' / name
    target = out / 'source/tools/qwen35_text' / name
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(p.read_bytes())
base_path = P / 'cli/checks/attempt2/link-plan.json'
base = c.read(base_path)
assert len(base['inputs']) == 190 and all(h.same(x) for x in base['inputs'])
old = c.key(recipe['object']['path'])
assert sum(c.key(x['path']) == old for x in base['inputs']) == 1
inputs = [obj if c.key(x['path']) == old else x for x in base['inputs']]
image = out / 'qwen.exe'
link = [obj['path'] if c.key(x) == old else x for x in base['command'] if not x.upper().startswith(('/OUT:', '/MAP:', '/IMPLIB:', '/PDB:'))]
link += ['/OUT:' + str(image), '/MAP:' + str(image.with_suffix('.map')), '/IMPLIB:' + str(image.with_suffix('.lib'))]
c.save(out / 'link-plan.json', dict(command=link, inputs=inputs, base=b.identity(base_path), CXX=1, links=1, NVCC=0, SDK_builds=0, scope='consumer-only; new paged Graph work not linked'))
env, runtime = b.environment(link, [x['path'] for x in inputs], out)
c.execute('link', link, env, out)
original = c.read(P / 'cli/checks/attempt2/runtime-environment.json')['staged_CPU_modules'][0]['destination']
assert h.same(original)
target = out / Path(original['path']).name
os.link(original['path'], target)
c.save(out / 'runtime-environment.json', dict(PATH=env['PATH'], runtime=runtime, staged_CPU_modules=[dict(source=original, destination=b.identity(target), hardlink=True)]))
assert all(h.same(x) for x in inputs) and all(h.same(x) for x in dependencies)
c.save(C / 'ready-for-root.json', dict(status='capacity consumer built, runtime pending', image=b.identity(image), source=frozen, identity=b.identity(out / 'identity.json'), link_plan=b.identity(out / 'link-plan.json'), runtime_environment=b.identity(out / 'runtime-environment.json'), CXX=1, links=1, NVCC=0, SDK_builds=0, scope='Consumer budget/admission/idle eviction, same retained core; no new paged Graph execution claim.'))
print('CAPACITY_CONSUMER_READY', image, flush=True)
