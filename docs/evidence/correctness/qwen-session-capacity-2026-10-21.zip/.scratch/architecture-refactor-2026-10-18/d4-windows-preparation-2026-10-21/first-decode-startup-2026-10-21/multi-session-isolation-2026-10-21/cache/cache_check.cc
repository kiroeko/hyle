#include "session_cache.h"

#include <iostream>
#include <string>
#include <string_view>

namespace b = qwen35::benchmark;

void require(bool condition, std::string_view message) {
  if (!condition) throw std::runtime_error(std::string(message));
}

int main() {
  try {
    {
      b::SessionCache cache({1, 128});
      std::size_t callbacks = 0;
      auto retire = [&](std::size_t owner) {
        ++callbacks;
        require(owner == 0 && cache.retained_sessions() == 1 && cache.retained_bytes() == 64,
                "charge returned before real retirement callback");
        return true;
      };
      require(cache.admit(0, 64, retire).accepted(), "first admission");
      auto pin = cache.pin(0);
      require(bool(pin) && pin.owner_index() == 0 && !cache.pin(0), "exclusive active pin");
      // The caller keeps its direct owner pointer and this token across hot
      // evaluations. No directory lookup/touch is needed inside that loop.
      auto moved = std::move(pin);
      require(!pin && bool(moved) && moved.owner_index() == 0, "stable moved pin");
      require(cache.admit(1, 64, retire).status == b::CacheAdmissionStatus::kCapacityExceeded &&
              callbacks == 0 && cache.retained_bytes() == 64, "active capacity1 eviction");
      moved.reset(); moved.reset();
      const auto admitted = cache.admit(1, 64, retire);
      require(admitted.accepted() && admitted.evicted_sessions == 1 && admitted.evicted_bytes == 64 &&
              callbacks == 1 && !cache.contains(0) && cache.contains(1), "idle capacity1 replacement");
      std::cout << "PASS capacity1_active_pin_and_post_retirement_accounting\n";
    }
    {
      b::SessionCache cache({3, 100});
      std::vector<std::size_t> retired;
      auto retire = [&](std::size_t key) { retired.push_back(key); return true; };
      for (std::size_t key = 0; key < 3; ++key) require(cache.admit(key, 20, retire).accepted(), "fill LRU");
      auto recent = cache.pin(1); require(bool(recent), "recent pin"); recent.reset();
      auto active = cache.pin(0); require(bool(active), "active old owner");
      auto result = cache.admit(3, 60, retire);
      require(result.accepted() && retired == std::vector<std::size_t>({2}) &&
              active.owner_index() == 0 && cache.contains(0) && cache.contains(1) &&
              cache.retained_bytes() == 100, "LRU must skip active and preserve its slot");
      active.reset();
      result = cache.admit(4, 70, retire);
      require(result.accepted() && result.evicted_sessions == 2 && result.evicted_bytes == 80 &&
              retired == std::vector<std::size_t>({2, 1, 3}) && cache.contains(0) && cache.contains(4) &&
              cache.retained_bytes() == 90 && cache.retained_sessions() == 2, "LRU byte admission");
      require(cache.admit(4, 70, retire).status == b::CacheAdmissionStatus::kAlreadyResident &&
              cache.admit(4, 71, retire).status == b::CacheAdmissionStatus::kByteCountMismatch &&
              retired.size() == 3 && cache.retained_bytes() == 90, "resident bytes cannot silently change");
      std::cout << "PASS_idle_LRU_active_slot_stability_and_owner_byte_identity\n";
    }
    {
      b::SessionCache cache({3, 100});
      std::size_t callbacks = 0;
      auto retire = [&](std::size_t) { ++callbacks; return true; };
      require(cache.admit(10, 70, retire).accepted() && cache.admit(11, 20, retire).accepted(), "fill byte budget");
      auto pin = cache.pin(10);
      require(cache.admit(12, 40, retire).status == b::CacheAdmissionStatus::kCapacityExceeded &&
              callbacks == 0 && cache.contains(11) && cache.retained_bytes() == 90,
              "insufficient idle bytes must reject before evicting useful owners");
      require(cache.admit(12, 101, retire).status == b::CacheAdmissionStatus::kCapacityExceeded &&
              callbacks == 0, "oversize admission must not evict");
      std::cout << "PASS_impossible_admission_preserves_existing_idle_owners\n";
    }
    {
      b::SessionCache cache({3, 100});
      auto unused = [](std::size_t) { return true; };
      for (std::size_t key = 0; key < 3; ++key) require(cache.admit(key, 30, unused).accepted(), "fill retirement test");
      std::size_t calls = 0;
      auto partial = [&](std::size_t key) {
        ++calls;
        if (key == 0) {
          require(cache.retained_bytes() == 90 && cache.retained_sessions() == 3, "first callback charge");
          return true;
        }
        require(key == 1 && cache.retained_bytes() == 60 && cache.retained_sessions() == 2,
                "accepted retirement prefix not represented");
        return false;
      };
      auto result = cache.admit(3, 70, partial);
      require(result.status == b::CacheAdmissionStatus::kRetirementUnproven &&
              result.evicted_sessions == 1 && result.evicted_bytes == 30 && calls == 2 &&
              !cache.contains(0) && cache.contains(1) && cache.contains(2) && !cache.contains(3) &&
              cache.retained_bytes() == 60, "failed retirement must remain charged");
      result = cache.admit(3, 70, unused);
      require(result.accepted() && result.evicted_sessions == 1 && cache.contains(2) &&
              cache.contains(3) && cache.retained_bytes() == 100, "fresh retirement recovery");
      std::cout << "PASS_retirement_failure_keeps_charge_and_successful_prefix\n";
    }
    {
      const auto maximum = (std::numeric_limits<std::size_t>::max)();
      b::SessionCache cache({2, maximum});
      auto retire = [](std::size_t) { return true; };
      require(cache.admit(0, maximum - 5, retire).accepted() && cache.admit(1, 5, retire).accepted() &&
              cache.retained_bytes() == maximum, "exact SIZE_MAX metadata budget");
      auto active = cache.pin(0);
      require(cache.admit(2, 6, retire).status == b::CacheAdmissionStatus::kCapacityExceeded &&
              cache.retained_bytes() == maximum, "SIZE_MAX preflight overflow");
      active.reset();
      const auto result = cache.admit(2, 6, retire);
      require(result.accepted() && result.evicted_sessions == 2 && result.evicted_bytes == maximum &&
              cache.retained_bytes() == 6, "SIZE_MAX retirement arithmetic");
      std::cout << "PASS_SIZE_MAX_accounting_without_payload_allocation\n";
    }
    {
      bool rejected = false;
      try { b::SessionCache invalid({0, 100}); }
      catch (const std::runtime_error &) { rejected = true; }
      require(rejected, "zero entry limit");
      b::SessionCache cache({1, 0});
      auto retire = [](std::size_t) { return true; };
      require(cache.admit(1, 1, retire).status == b::CacheAdmissionStatus::kCapacityExceeded &&
              cache.admit(1, 0, retire).accepted() && cache.retained_sessions() == 1 &&
              cache.retained_bytes() == 0, "zero byte hard budget is not unlimited");
      auto pin = cache.pin(1);
      require(bool(pin) && !cache.pin(2), "missing owner pin");
      std::cout << "PASS_limits_and_zero_byte_budget\n";
    }
    std::cout << "SESSION_CACHE_CHECKS_PASS groups=6\n";
  } catch (const std::exception &error) {
    std::cerr << error.what() << '\n'; return 1;
  }
}
