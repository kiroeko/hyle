"""Standalone cache-metadata behavior checks. No Hyle SDK, model or GPU."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

stage = Path(__file__).resolve().parent
repo = next(p for p in stage.parents if (p / 'AGENTS.md').is_file() and (p / 'src').is_dir())
out = stage / 'checks/attempt1'
out.mkdir(parents=True, exist_ok=False)
msvc = Path('C:/Program Files/Microsoft Visual Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717')
sdk = Path('C:/Program Files (x86)/Windows Kits/10')
sdk_version = '10.0.26100.0'
compiler = msvc / 'bin/Hostx64/x64/cl.exe'
env = os.environ.copy()
env['INCLUDE'] = ';'.join(str(p) for p in [msvc / 'include', *(sdk / 'Include' / sdk_version / name for name in ('ucrt', 'shared', 'um', 'winrt', 'cppwinrt'))])
env['LIB'] = ';'.join(str(p) for p in [msvc / 'lib/x64', *(sdk / 'Lib' / sdk_version / name / 'x64' for name in ('ucrt', 'um'))])
env['PATH'] = str(compiler.parent) + os.pathsep + env['PATH']
header = repo / 'tools/qwen35_text/session_cache.h'

def identity(path):
    contents = path.read_bytes()
    return {'path': str(path), 'bytes': len(contents), 'sha256': hashlib.sha256(contents).hexdigest()}

sources = [identity(path) for path in [header, stage / 'cache_check.cc', Path(__file__)]]
image = out / 'cache_check.exe'
command = [str(compiler), '/nologo', '/std:c++17', '/W4', '/WX', '/permissive-', '/EHsc', '/utf-8', '/O2', '/MD', '/DNOMINMAX', '/I' + str(header.parent), str(stage / 'cache_check.cc'), '/Fo' + str(out / 'cache_check.obj'), '/Fe' + str(image), '/link', '/INCREMENTAL:NO', '/MAP:' + str(out / 'cache_check.map')]
records = []
for name, cmd in [('compile-link', command), ('run', [str(image)])]:
    (out / (name + '.command.json')).write_text(json.dumps({'command': cmd, 'cwd': str(out)}, indent=2) + '\n', encoding='utf-8')
    started = time.monotonic()
    result = subprocess.run(cmd, cwd=out, env=env, capture_output=True, timeout=60)
    (out / (name + '.stdout.log')).write_bytes(result.stdout)
    (out / (name + '.stderr.log')).write_bytes(result.stderr)
    record = {'command': cmd, 'exit_code': result.returncode, 'elapsed_seconds': time.monotonic() - started}
    records.append(record)
    (out / (name + '.result.json')).write_text(json.dumps(record, indent=2) + '\n', encoding='utf-8')
    print(name, result.returncode, flush=True)
    if result.returncode:
        print(result.stdout.decode('utf-8', errors='replace'))
        print(result.stderr.decode('utf-8', errors='replace'))
        raise SystemExit(result.returncode)
assert sources == [identity(path) for path in [header, stage / 'cache_check.cc', Path(__file__)]]
report = {'status': 'passed', 'sources': sources, 'compiler': identity(compiler), 'sdk_include_root': str(sdk / 'Include' / sdk_version), 'runs': records, 'check_groups': 6, 'CXX': 1, 'links': 1, 'SDK_builds': 0, 'model_loads': 0, 'GPU_runs': 0, 'object': identity(out / 'cache_check.obj'), 'image': identity(image)}
(stage / 'host-result.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
print('SESSION_CACHE_READY', json.dumps(identity(header)), flush=True)
