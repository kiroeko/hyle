"""Independent host-only sparse source witnesses; no Hyle/device execution."""
from pathlib import Path
import hashlib,json,math,struct

P=Path(__file__).resolve().parent
R=P.parents[3]
GLOBALS=[11,37,83,127,191,223,251,271,287]
T,D,H,E,S=2,4096,2048,288,8
def f32(x):return struct.unpack('<f',struct.pack('<f',x))[0]
def bf16(x):
    u=struct.unpack('<I',struct.pack('<f',x))[0]
    u=(u+0x7fff+((u>>16)&1))&0xffff0000
    return struct.unpack('<f',struct.pack('<I',u))[0]
def half(u):return struct.unpack('<e',struct.pack('<H',u))[0]
def rows(st):return D if st%3==2 else H
def depth(st):return H if st%3==2 else D
def width(st):return 4 if st<2 else 5 if st==2 else 6
def sf(st,e,n,g,epoch):
    exp=0x2400 if st%3==2 else 0x3800
    frac=3+(e*17+n*11+g*29+epoch*47+st*31)%797
    sign=0x8000 if (e+n+g+st)%5==0 else 0
    return half(exp|frac|sign)
def project(st,e,a,epoch,wrong_sf):
    out=[];k=depth(st)
    for n in range(rows(st)):
        pos=[(n*7+e*13+st*19+epoch*23)%(k//2),k//2+(n*11+e*5+st*31+epoch*17)%(k//2)]
        total=0.
        for lane,p in enumerate(pos):
            s=sf(st,e,n,p//64,epoch)
            if wrong_sf:s=bf16(s)
            code=2+(e*3+n*5+st*7+lane*11+epoch*13)%((1<<width(st))-2)
            w=f32(f32(code*s)-s)
            total=f32(total+f32(a[p]*w))
        out.append(total)
    return out
def activate(gate,up):
    return [f32(f32(min(g,10.)/(1+math.exp(-min(g,10.))))*max(-10.,min(u,10.))) for g,u in zip(gate,up)]
def route(phase,t,absent=False):
    logits=[-8.]*E;bias=[-2.]*E;bias[286]=0.
    for local,e in enumerate(GLOBALS):
        logits[e]=(12-((local+t*2+phase*3)%9)*3)/16
        bias[e]=(local%3-1)/32
    if absent:logits[286]=20.
    score=[f32(1/(1+math.exp(-x))) for x in logits]
    ids=sorted(range(E),key=lambda e:f32(score[e]+bias[e]),reverse=True)[:S]
    return logits,score,ids
def oracle(wrong_sf=False,early_bf16=False,softmax=False):
    final=[];selected_ids=[]
    for t in range(T):
        a=[bf16([.75,-.5,1.,1.25,-1.5][((t*D+k)*3+t)%5]) for k in range(D)]
        logits,scores,ids=route(0,t);selected_ids.append(ids)
        selected=[f32(math.exp(logits[e])) if softmax else scores[e] for e in ids]
        total=0.
        for v in selected:total=f32(total+v)
        total=f32(total+f32(1.e-20));combined=[0.]*D
        for e,v in zip(ids,selected):
            w=f32(f32(v/total)*2.5)
            gate=project(0,e,a,0,wrong_sf);up=project(1,e,a,0,wrong_sf)
            if early_bf16:gate=list(map(bf16,gate));up=list(map(bf16,up))
            down=project(2,e,activate(gate,up),0,wrong_sf)
            combined=[f32(x+f32(y*w)) for x,y in zip(combined,down)]
        sg=project(3,0,a,0,wrong_sf);su=project(4,0,a,0,wrong_sf)
        shared=project(5,0,activate(sg,su),0,wrong_sf)
        final.extend(f32(x+y) for x,y in zip(combined,shared))
    return final,selected_ids
def metrics(a,b):
    peak=max(map(abs,a));sr=sum(x*x for x in a)
    errors=[y-x for x,y in zip(a,b)]
    return dict(different_F32_words=sum(struct.pack('<f',x)!=struct.pack('<f',y) for x,y in zip(a,b)),
                peak_normalized_error=max(map(abs,errors))/peak,
                relative_l2=math.sqrt(sum(x*x for x in errors)/sr))
correct,ids=oracle();witness=[]
for mode,args in [('metadata_F16_wrongly_BF16',(True,False,False)),('premature_BF16_gate_up',(False,True,False)),('old_softmax_probabilities',(False,False,True))]:
    m=metrics(correct,oracle(*args)[0]);assert max(m['peak_normalized_error'],m['relative_l2'])>2.e-5
    witness.append(dict(policy=mode,**m,exceeds_fixed_tolerance=True))
selections=[]
for phase in range(4):
    for t in range(T):
        selected=route(phase,t)[2];assert set(selected)<=set(GLOBALS)
        missing=route(phase,t,True)[2];assert 286 in missing
        selections.append(dict(phase=phase,token=t,normal=selected,absent_probe=missing))
source=R/'tests/compute_models/glm_flash_mixed_mlx_fixture.h'
result=dict(scope='Host scalar source-data sanity only; no compiled Hyle/test/device execution.',
            source=dict(path=source.relative_to(R).as_posix(),bytes=source.stat().st_size,sha256=hashlib.sha256(source.read_bytes()).hexdigest()),
            geometry='T2,D4096,H2048,E288,Top8,resident9; epoch0phase0 witnesses',
            final_elements=len(correct),first_selected=ids,wrong_policies=witness,
            all4phase_selection_and_absent_checks=selections,product_oracle_calls=0,compiles=0,GPU_runs=0)
(P/'scalar-witness.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(json.dumps(witness))
