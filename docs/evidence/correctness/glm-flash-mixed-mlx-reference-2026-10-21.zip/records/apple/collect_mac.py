from pathlib import Path
import runpy,json,base64,sys
R=Path.cwd();A=R/'.scratch/architecture-refactor-2026-10-18';P=A/'glm-flash-mixed-mlx-2026-10-21/apple';ssh=runpy.run_path(str(A/'batch-query-extent/delegated/apple/validate.py'))['ssh'];remote=json.loads((P/'mac/plan.json').read_text())['remote'];dest=sys.argv[1]if len(sys.argv)>1 else'remote'
code='''from pathlib import Path
import sys,json,base64
r=Path(json.load(sys.stdin)['remote']);fs=[*r.glob('results/*'),r/'plan.json',r/'source-manifest.json',r/'hardware.json',r/'reused-source-manifest.json',r/'tests/compute_models/glm_flash_mixed_mlx_fixture.h',r/'tests/graph_route_apple/glm_flash_mixed_mlx_test.cc'];print(json.dumps([dict(path=p.relative_to(r).as_posix(),data=base64.b64encode(p.read_bytes()).decode())for p in fs if p.is_file()]))'''
for row in ssh(code,dict(remote=remote)):
 q=P/'mac'/dest/row['path'];q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(base64.b64decode(row['data']))
print('collected '+dest)
