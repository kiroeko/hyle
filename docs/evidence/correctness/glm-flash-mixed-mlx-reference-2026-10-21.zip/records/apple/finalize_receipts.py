"""Freeze actual focused Apple full-FFN consumer; inventory only, no deletion."""
from pathlib import Path
import hashlib,json,runpy,shutil,xml.etree.ElementTree as ET
ROOT=Path.cwd();A=ROOT/".scratch/architecture-refactor-2026-10-18";P=A/"glm-flash-mixed-mlx-2026-10-21/apple"
OUT=P/"mac/final";RESULTS=OUT/"results"
def read(p):return json.loads(p.read_text())
def save(p,value):p.write_text(json.dumps(value,indent=2)+"\n")
def identity(p):
 b=p.read_bytes();return dict(path=p.relative_to(ROOT).as_posix(),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
runpy.run_path(str(P/"audit_dependencies.py"))
audit=read(P/"actual-dependencies-canonical-audit.json");assert audit["drift_count"]==0
compiles=read(RESULTS/"compile-summary.json")["compiles"];assert len(compiles)==1
unique={r["current"]["path"]:r["current"]for c in audit["compiles"]for r in c["canonical"]}
ssh = runpy.run_path(str(A / "batch-query-extent/delegated/apple/validate.py"))["ssh"]
remote = read(OUT / "plan.json")["remote"]
inventory = ssh('''from pathlib import Path
import json,sys,hashlib,subprocess
r=Path(json.load(sys.stdin)['root']);assert r.is_absolute() and r.exists() and not r.is_symlink()
def ident(p):
 b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest(),symlink=p.is_symlink())
images=[];objects=[];dsym=[]
for q in sorted(r.rglob('*')):
 if q.is_symlink():continue
 if q.is_dir():
  if q.suffix=='.dSYM':dsym.append(str(q))
  continue
 if q.suffix=='.o':objects.append(ident(q))
 elif q.suffix=='.map':images.append(ident(q))
 else:
  with q.open('rb')as f:magic=f.read(4)
  if magic in [bytes.fromhex(x)for x in ('cffaedfe','feedfacf','cafebabe','bebafeca')]:images.append(ident(q))
ps=subprocess.check_output(['ps','-axo','pid=,command='],text=True)
active=[s for s in ps.splitlines()if str(r)in s and 'python3 -c'not in s and '/usr/bin/ssh'not in s]
lsof=subprocess.run(['lsof','--',*[x['path']for x in images]],capture_output=True,text=True)
print(json.dumps(dict(remote_root=str(r),root_symlink=r.is_symlink(),deletable_files=images,retained_objects=objects,dsym=dsym,active_image_processes=active,lsof_stdout=lsof.stdout,lsof_stderr=lsof.stderr,lsof_exit=lsof.returncode,deleted=False)))
''', dict(root=remote))
assert not inventory["active_image_processes"] and not inventory["lsof_stdout"]
save(P / "cleanup-readonly-inventory.json", inventory)

for rel,row in unique.items():
    assert identity(ROOT/rel)==row
    dest=P/"source"/rel;dest.parent.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(ROOT/rel,dest)
registration="tests/graph_route_apple/CMakeLists.txt"
dest=P/"source"/registration;dest.parent.mkdir(parents=True,exist_ok=True)
shutil.copyfile(ROOT/registration,dest)
inputs=read(RESULTS/"link-inputs.json")
reused_products=[row for row in inputs if row["path"].endswith(("src--compute_route_apple--apple_weights.mm.o","src--compute_route_apple--apple_memory.mm.o","src--graph--resources.cc.o"))]
assert len(reused_products)==3
assert next(x for x in reused_products if x["path"].endswith("apple_weights.mm.o"))["sha256"]=="cf4622f43748d2aca74841492e3eaa0a0f2c225bd8ac267d2262c1fd0307f2df"
freeze=dict(status="actual_wrapper_CXX_source_and_every_actual_canonical_dependency_equal_final_Windows_bytes",
    sources=sorted(unique.values(),key=lambda r:r["path"]),registration=identity(ROOT/registration),
    compiled_translation_units=[c["source"]for c in compiles],
    canonical_dependency_audit=identity(P/"actual-dependencies-canonical-audit.json"),
    actual_dependency_references=audit["actual_dependency_references"],unique_canonical_files=audit["unique_canonical_files"],
    actual_whole_dependencies_drift=0,source_snapshot="source/",SDK_source_copied=False,
    reused_current_products=reused_products,
    Apple_product_changes=0,new_test="tests/graph_route_apple/glm_flash_mixed_mlx_test.cc",new_CMake_target="hyle_graph_route_apple_glm_flash_mixed_mlx_test",
    shared_final_sha256="cf3b828e94c69f9f0f9112a81ba9a05e66446ab54102f4b088ae9981a2583b5a",
    CXX_include_argument_maintenance=identity(P/"include-argument-maintenance.json"),
    rule="Actual new command removes only duplicate identical-I arguments preserving first occurrence; noninclude compiler flags unchanged. Full actual-MD closure independently matches current canonical bytes.")
save(P/"source-freeze.json",freeze)
cases=[dict(name=t.attrib["classname"]+"."+t.attrib["name"],
    properties={v.attrib["name"]:v.attrib["value"]for v in t.findall("./properties/property")})
    for t in ET.parse(RESULTS/"tests.xml").iter("testcase")]
assert len(cases)==1 and cases[0]["name"]=="AppleGlmFlashMixedMlx.OriginalRolesKeepTypedPromotionAndWeightGeneration"
props=cases[0]["properties"]
for key,value in [("successful_submissions","4"),("expected_failed_submissions","1"),("successful_weight_generations","3"),("native_weight_slots","2"),("original_fragments_per_generation","92")]:assert props[key]==value
for key in ["metadata_bf16_counterfactual_words","early_bf16_counterfactual_words","softmax_counterfactual_words"]:assert int(props[key])>0
validation=read(RESULTS/"validation.json")
assert validation["tests"]==1 and validation["exit"]==0 and not validation["failed"]and not validation["skipped"]
final=dict(status="actual_Mac16_12_Metal_GLM32_typed_role_and_resource_consumer_pass",source_freeze=identity(P/"source-freeze.json"),
    hardware=identity(OUT/"hardware.json"),tests=1,new_cases=1,original_neighbors=0,failed=0,skipped=0,cases=cases,
    successful_submissions=4,expected_failed_submissions=1,successful_weight_generations=3,original_upload_slots=2,fragments_per_generation=92,configured_max_fragments=128,
    expected_retained_slot_rejections=2,missing_global_expert_maps_to_negative_local_and_fails_Completion=True,fresh_invocation_recovers_same_generation=True,
    upload_accounting="Original per-native-upload wait/report verifies logical/staged bytes and submitted/completed bounds; this is not measured bus/DRAM traffic.",
    capacities_derived_from_current_shared={"resident_triplets_plus_shared_bytes":157286400,"map_and_correction_bytes":2304,"per_generation_logical_bytes":157288704,"slot_capacity":157288960,"two_staging_two_destination_fixed_bytes":629155840,"successful_upload_logical_bytes_total":471866112,"router_matrix_included":False,"router_boundary":"Original F32 logits supplied as typed graph input; ordinary sigmoid/correction/Top8/normalization and I32 map stay in graph."},
    CXX_jobs=1,Apple_product_CXX_jobs=0,test_CXX_jobs=1,SDK_jobs=0,
    Apple_native_runtime_or_math_changes=0,shared_math_or_oracle_changed_for_Apple=False,
    compiles=[dict(source=c["source"],exit=c["exit"],object=c["object_identity"],dependency_count=len(c["dependencies"]),source_drifts=c["source_drifts"])for c in compiles],
    reused_current_products=reused_products,actual_whole_dependencies_drift=0,actual_dependency_references=audit["actual_dependency_references"],
    unique_canonical_files=audit["unique_canonical_files"],run=read(RESULTS/"run.result.json"),image=validation["image"],
    artifacts={n:identity(RESULTS/n)for n in ("compile-summary.json","link-inputs.json","link.command.json","link.result.json","run.command.json","run.result.json","tests.xml","validation.json")},
    read_only_design=identity(P/"read-only-design.json"),hot_metadata_review=identity(P/"hot-metadata-conversion-review.json"),
    hot_metadata_conversion_issue_solved=False,delivery3_followup="Repeated dynamic F16SF/B->F32 value conversion remains independent work. Compiled tape reuse is not converted-data memoization; no physical-allocation count is claimed.",
    attempts_preserved=["Only actual Apple attempt uses rootCPU-passed finalcf3b828e shared header; first actual Apple strict compile and runtime PASS. No failed Apple attempt exists."],
    scope="Fixed catalog32 GLM-5.3-Flash ordinary typed roles with synthetic original U32/F16 fragments: D4096/H2048/E288Top8/resident9, g64 routed4/4/5 and shared6, original BF16activation to promotedF32 equation without intermediate/terminal BF16 casts. Source sigmoid/correction router from F32logits boundary, same-generation checked I32 global/local map, post-down route weighting and F32 shared add. Eight boundaries retain IDs+sevenF32 outputs. Three real uploaded generations across two slots, original source destruction, old-reader rejection before reuse, missing-resident Completion failure and fresh recovery, old outputs after producer teardown.",
    limits=["Finite source-bound roles/resources consumer is not a complete GLM layer/model, checkpoint payload import, vision/attention/mHC/short-block optimized reader or throughput claim.","No8bit artifact role claim: this fixed artifact requires4/5/6bit; generic original MLX schema also supports8bit.","Thresholds2e-5 relativeL2 and peak-relative were fixed in shared fixture before backend execution; three independent wrong-policy witnesses remain outside that gate.","No native product or SDK CXX/Metal source rebuild; only new test CXX. Ordinary runtime MLX compilation/allocator pooling is not a measured performance or allocation result."],
    cleanup_inventory=identity(P/"cleanup-readonly-inventory.json"),no_deletion_performed=True)
save(P/"final-validation.json",final)
for q in (P/"source-freeze.json",P/"final-validation.json",P/"actual-dependencies-canonical-audit.json",P/"cleanup-readonly-inventory.json"):
    print(json.dumps(identity(q)))
