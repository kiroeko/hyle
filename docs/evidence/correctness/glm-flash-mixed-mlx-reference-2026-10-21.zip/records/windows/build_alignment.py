"""Refresh only the CUDA bank-layout owner and its existing focused test TU; never run."""
from pathlib import Path
import concurrent.futures
import difflib
import importlib.util
import sys

sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent
P=S.parent
A=P.parent
R=A.parents[1]
spec=importlib.util.spec_from_file_location('glm_alignment_helpers',S/'build.py')
h=importlib.util.module_from_spec(spec)
spec.loader.exec_module(h)
b,c=h.b,h.c
BEFORE=P/'cuda/revisions/bank-alignment-before'
PRODUCT_RECIPE=A/'ga-route-ffn-2026-10-21/opaque-slices/cuda/checks/attempt1/identity.json'
FIXTURE_SHA='cf3b828e94c69f9f0f9112a81ba9a05e66446ab54102f4b088ae9981a2583b5a'
NAMES=['src/compute_route_cuda/weights.cc',
    'tests/graph_route_cuda/glm_flash_mixed_mlx_test.cc',
    'tests/graph_route_cuda/CMakeLists.txt',
    'tests/compute_models/glm_flash_mixed_mlx_fixture.h']


def freeze():
    sources=[]
    diff=[]
    for name in NAMES:
        source=R/name
        dest=P/'cuda/source-bank-alignment'/name
        dest.parent.mkdir(parents=True,exist_ok=True)
        if dest.exists():assert dest.read_bytes()==source.read_bytes()
        else:dest.write_bytes(source.read_bytes())
        sources.append(dict(source=b.identity(source),snapshot=b.identity(dest)))
        before=BEFORE/name
        if before.exists():
            diff.extend(difflib.unified_diff(before.read_text(encoding='utf8').splitlines(True),
                source.read_text(encoding='utf8').splitlines(True),fromfile='before/'+name,tofile='after/'+name))
    (P/'cuda/bank-alignment.diff').write_text(''.join(diff),encoding='utf8')
    c.save(P/'cuda/bank-alignment-source-freeze.json',dict(status='source_frozen_not_executed',
        sources=sources,diff=b.identity(P/'cuda/bank-alignment.diff'),
        invariant='One native 256-byte alignment for backing and each whole/sliced bank start; last bank payload is not rounded.',
        product_ABI_changes=0,Graph_math_changes=0,agent_GPU_runs=0))
    return [b.identity(R/'tests/compute_models/glm_flash_mixed_mlx_fixture.h')]


def compile_product():
    recipe=c.read(PRODUCT_RECIPE)
    source=R/'src/compute_route_cuda/weights.cc'
    out=P/'cuda/checks/bank-alignment-product1'
    out.mkdir(parents=True,exist_ok=True)
    (out/'tmp').mkdir(exist_ok=True)
    assert not (out/'compile.result.json').exists()
    command=b.host_command(recipe['command'],source,'cuda-weights',out)
    source_id=b.identity(source)
    c.save(out/'compile-plan.json',dict(command=command,source=source_id,recipe=b.identity(PRODUCT_RECIPE),
        old_object=recipe['object'],product_CXX=1,SDK_builds=0,NVCC_compiles=0,agent_GPU_runs=0))
    env,_=b.environment(command,[],out)
    c.execute('compile',command,env,out)
    dep_path=out/'cuda-weights-deps.json'
    data=c.read(dep_path)['Data']
    dependencies=[b.identity(p) for p in dict.fromkeys([data['Source'],*data['Includes']])]
    assert all(b.same(x) for x in [source_id,*dependencies])
    record=dict(command=command,source=source_id,recipe=b.identity(PRODUCT_RECIPE),
        old_object=recipe['object'],object=b.identity(out/'cuda-weights.obj'),
        dependencies=dependencies,source_dependencies=b.identity(dep_path),
        product_CXX=1,SDK_builds=0,NVCC_compiles=0,agent_GPU_runs=0)
    c.save(out/'identity.json',record)
    print('COMPILED CUDA weights',flush=True)
    return record


def link(product,test):
    base_path=P/'cuda/checks/link1/link-plan.json'
    base=c.read(base_path)
    old_test=c.read(P/'cuda/checks/attempt2/identity.json')['object']
    replacements={c.key(product['old_object']['path']):product['object'],
        c.key(old_test['path']):test['object']}
    assert all(sum(c.key(row['path'])==key for row in base['inputs'])==1 for key in replacements)
    assert all(b.same(x) for x in base['inputs'])
    inputs=[replacements.get(c.key(x['path']),x) for x in base['inputs']]
    assert all(b.same(x) for x in inputs)
    command=[replacements[c.key(arg)]['path'] if c.key(arg) in replacements else arg for arg in base['command']
        if not arg.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:'))]
    out=P/'cuda/checks/link2'
    out.mkdir(parents=True,exist_ok=True)
    (out/'tmp').mkdir(exist_ok=True)
    assert not (out/'link.result.json').exists()
    image=out/'cuda.exe'
    command+=['/OUT:'+str(image),'/MAP:'+str(image.with_suffix('.map')),
        '/IMPLIB:'+str(image.with_suffix('.lib'))]
    actual=[arg for arg in command if Path(arg).is_absolute() and Path(arg).suffix.lower() in ('.obj','.lib')]
    assert list(map(c.key,actual))==[c.key(x['path']) for x in inputs]
    c.save(out/'link-plan.json',dict(command=command,inputs=inputs,base=b.identity(base_path),
        replaced_product=product['old_object'],new_product=product['object'],
        replaced_test=old_test,new_test=test['object'],
        delta='Only CUDA WeightSlots bank-start alignment and its focused regression; no public/Graph/codec/ABI changes.',
        SDK_builds=0,NVCC_compiles=0,agent_GPU_runs=0))
    env,runtime=b.environment(command,[x['path'] for x in inputs],out)
    c.save(out/'runtime-environment.json',dict(PATH=env['PATH'],runtime=runtime))
    c.execute('link',command,env,out)
    c.save(out/'image.json',b.identity(image))
    ready=dict(status='CUDA_product_and_two_case_image_ready_not_executed',arm='cuda',image=b.identity(image),
        link_plan=b.identity(out/'link-plan.json'),runtime_environment=b.identity(out/'runtime-environment.json'),
        filter='CudaGlmFlashMixedMlx.RoleBanksKeepPromotedCompleteMoe:CudaWeightBankAlignment.*',expected_tests=2,
        successful_product_CXX=1,successful_test_CXX=1,successful_links=1,SDK_builds=0,NVCC_compiles=0,
        agent_GPU_runs=0,source_freeze=b.identity(P/'cuda/bank-alignment-source-freeze.json'))
    path=S/'ready-for-root-run-cuda-alignment.json'
    c.save(path,ready)
    print(b.identity(path),flush=True)


if __name__=='__main__':
    frozen=freeze()
    assert frozen[0]['sha256']==FIXTURE_SHA
    if '--build' in sys.argv:
        with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
            product_job=pool.submit(compile_product)
            test_job=pool.submit(h.compile_one,'cuda','attempt3',frozen)
            product=product_job.result()
            _,test=test_job.result()
        link(product,test)
    else:print(b.identity(P/'cuda/bank-alignment-source-freeze.json'))
