"""Read-only current MLX mixed-type role/working-set and Windows closure audit; no build or execution."""
from pathlib import Path
import importlib.util
import sys

sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent
P=S.parent
A=P.parent
R=A.parents[1]
spec=importlib.util.spec_from_file_location('glm_mixed_review_helpers',A/'grouped-shared-activation/build_host.py')
h=importlib.util.module_from_spec(spec)
spec.loader.exec_module(h)
b,c=h.b,h.c
W=A/'ga-full-ffn-2026-10-21'
fact_root=A/'fixed-role-binding-2026-10-21/mlx/32'
facts=c.read(fact_root/'role-summary.json')
config=c.read(fact_root/'config.json')
config=config.get('text_config',config)
owners=[]
for relative in [
    'common/checks/schema1/compute_ops--weight_decode-25df34/identity.json',
    'cpu-cuda/checks/attempt1/torch-cpu/identity.json',
    'cpu-cuda/checks/attempt3/artifact-provider/identity.json',
    'cpu-cuda/checks/attempt2/mlx-packed-kernel/identity.json',
    'vulkan/checks/attempt1/mlx-identity.json',
    'vulkan/checks/attempt1/native-program-identity.json',
    'vulkan/checks/embedded2/embedded-identity.json',
]:
    path=A/'mlx-weight-orientation-2026-10-21'/relative
    record=c.read(path)
    source=record.get('source')
    if source:assert b.same(source),source
    assert b.same(record['object'])
    owners.append(dict(identity=b.identity(path),source=source,object=record['object'],
        source_current_bytes_equal=source is not None))
bases=[]
for arm in ['cpu','cuda','vulkan']:
    path=W/arm/'checks/link2/link-plan.json'
    plan=c.read(path)
    assert all(b.same(row) for row in plan['inputs'])
    matched=[owner for owner in owners if any(c.key(row['path'])==c.key(owner['object']['path']) for row in plan['inputs'])]
    bases.append(dict(arm=arm,link_plan=b.identity(path),input_count=len(plan['inputs']),
        current_mlx_owners=matched,test_recipe=b.identity(W/arm/'checks/attempt2/identity.json'),
        replaced_test=c.read(W/arm/'checks/attempt2/identity.json')['object']))
sources=[
    'include/hyle/compute/model_ops.h','src/compute_ops/weight_decode.cc',
    'src/compute_provider_native/torch_cpu_program.cc','third_party/mlx_cpu_quant/mlx_cpu_quant.h',
    'src/compute_provider_torch_cuda/artifact_provider.cc','src/compute_provider_torch_cuda/mlx_packed_kernel.cu',
    'src/compute_route_vulkan/vulkan_mlx.cc','src/compute_provider_iree_vulkan/native_program.cc',
    'third_party/iree_vulkan_runtime/programs/generate_mlx.py',
    'src/compute/weight_assembly.h','src/compute_route_cuda/weights.cc','src/compute_route_vulkan/vulkan_weights.cc',
    'tests/compute_models/mlx_orientation_fixture.h','tests/compute_models/mlx_moe_fixture.h',
]
roles=[role for role in facts['affine_roles'] if '.mlp.experts.' in role['module_pattern'] or '.mlp.shared_experts.' in role['module_pattern']]
c.save(S/'source-review.json',dict(status='source_supported_exact_mixed_role_resource_consumer_not_yet_executed',
    artifact=dict(catalog_index=32,repository=facts['repository'],revision=facts['revision'],
        scope=facts['scope'],facts=b.identity(fact_root/'role-summary.json'),config=b.identity(fact_root/'config.json'),
        roles=roles,geometry={key:config[key] for key in ['hidden_size','moe_intermediate_size','n_routed_experts',
            'num_experts_per_tok','n_group','topk_group','n_shared_experts','routed_scaling_factor','norm_topk_prob','swiglu_limit']}),
    math_contract=[
      'Physical affine W is dense U32[E,N,(K/32)*bits], continuous low-first bitstream; original F16 SF/bias[E,N,K/64] remain independent plain banks.',
      'BF16 A + F16 SF/bias promotes to F32 output. Widen each source scalar exactly; decode each code*scale then +bias with F32 boundaries, F32 dot/accumulation, no premature BF16 decoded weight or output.',
      'GLM SwitchLinear uses transpose=True. Grouped kWeightAsStored is available separately but is not the routed MoE direction; do not interchange physical N/K/grouping.',
      'For the ordinary mixed reader branch, first gate/up and shared projections promote BF16 A/F16 metadata to F32. LimitedSwiGLU, down, route-weight-after-down, reduction and shared addition remain F32; no GA-style BF16 boundary or pre-down route weighting is inserted.',
      'Pinned reader default load retains F16 metadata. Explicit set_dtype/conversion and specialized short-block verifier/fast_ops are different scopes. Native same-low-type QMM bit equivalence is not claimed.',
    ],
    backend_support=dict(
      cpu='Current torch_cpu_program kMlx checks all selected IDs, then borrowed mlx_cpu_quant slices current K group before expert selection. Activation/metadata convert through inferred F32 output_type, selected-group decoded values and dot are F32. Shared A1/zero-slot collapses before conversion. No full floating E*N*K bank.',
      cuda='artifact_provider carries activation_type/scale_type/output_type independently. Existing MLX kernel raw loads BF16 A/F16 SF+bias, F32 mul/add and F32 packed dot, one final F32 store. Existing checked IDs and direct queues are unchanged.',
      vulkan='lower_mlx carries independent typed source tags and inferred F32 output; native_program resolves affine_grouped_bf16_f16, followed by existing f32_f16 entry for later F32 stages. Original generator widens scalar SF/bias/A inside bounded current-group decoding. Checked IDs precede selected entry publication.',
      orientation='Affine transpose and as-stored support bits4/5/6/8 and groups32/64/128. Mixed source output promotion applies to both. MX/embedding non-transpose rejection remains correct.'),
    resource=dict(gap_found=False,
      reason='This MLX layout has three original plain banks per projection; current WeightSlots scalar fragments naturally assemble dense U32 W and F16 SF/bias without opaque reinterpretation, conversion, repacking or extra descriptor.',
      mapping='Checked Gather on same-generation I32 map[288] converts actual global IDs to local selected expert IDs; grouped MLX checks mapped IDs before W/SF/bias addressing. An absent mapping=-1 fails terminal completion, fresh Invocation can recover.',
      layout='Each expert tensor is a contiguous leading-axis fragment of W, SF or bias. Destination offset is local expert index times that tensor-plane expert bytes. K full g64 guarantees complete per-row U32 words, including cross-word 5-bit codes. No CT flat-Z packing issue exists.',
      limits='Real capacity, fixed metadata count, device storage range and backend indexing bounds remain enforced. Do not claim all37152 triples/129 banks or all288 experts fit one bank.',
      planned=dict(resident_experts=9,routed_formats=[4,4,5],shared_format=6,group=64,
        fragments=91,max_fragments=128,plain_banks=19,
        weight_plus_scale_bias_bytes=157286400,map_bytes=1152,total_logical_bytes=157287552,
        note='Exact cold max_fragments option must exceed default64; existing public option suffices, no default or API change.')),
    existing_coverage=[
      'Existing mlx_orientation fixture executes mixed BF16 A/F16 metadata with promoted F32 result, both directions, selected grouped layouts and checked recovery; it includes different smaller width/group combinations, not this complete g64 GLM role.',
      'Existing mlx_moe fixture is gate5/up6/down4 g32, F32 A/BF16 metadata, final-output-only generic TopK/softmax/SiLU/down/combine and independent slots. It is not the fixed GLM4/4/5+shared6/F16-metadata consumer.',
      'W finite GA full FFN proved shared ordinary resource/lifetime composition but has a distinct original FP4/FP8 equation, routing and rounding. Reuse its Backend and current product closure only, not its arithmetic graph.'
    ],
    prepared=dict(wrappers=[b.identity(R/f'tests/graph_route_{arm}/glm_flash_mixed_mlx_test.cc') for arm in ['cpu','cuda','vulkan']],
      cmake_targets=['hyle_graph_route_'+arm+'_glm_flash_mixed_mlx_test' for arm in ['cpu','cuda','vulkan']],
      build_script=b.identity(S/'build.py'),test_CXX=3,links=3,product_CXX=0,SDK_builds=0,NVCC_compiles=0,
      status='Prepared only; wait for root/quant final shared source SHA before compiling. CUDA default replay, no capture requirement; Vulkan dynamic transfer4MiB.'),
    current_bases=bases,
    producer_review=b.identity(A/'precise-role-consumers-2026-10-21/apple/producer-contract-review.json'),
    sources=[b.identity(R/path) for path in sources],
    actual_compile_actions=0,actual_execution_actions=0,product_edits=0,
    limits=['No new model payload download or exact artifact execution.','No native low-type equivalence, specialized short-block branch, mHC/whole model, Linux, quality, throughput or peak-memory claim.']))
print(b.identity(S/'source-review.json'))
