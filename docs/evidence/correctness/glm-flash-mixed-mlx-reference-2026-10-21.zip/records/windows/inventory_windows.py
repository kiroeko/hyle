"""Read-only exact rebuildable Windows outputs and cached-module links for root cleanup."""
from pathlib import Path
import importlib.util
import os
import subprocess
import sys

sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent;P=S.parent
spec=importlib.util.spec_from_file_location('glm_inventory_helpers',S/'build.py')
h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h);b,c=h.b,h.c
images_maps=[];objects=[];reparse=[]
for arm in ['cpu','cuda','vulkan']:
    for path in sorted((P/arm).rglob('*')):
        if getattr(path.lstat(),'st_file_attributes',0)&0x400:reparse.append(str(path))
        if not path.is_file():continue
        if path.suffix.lower() in ['.exe','.map']:images_maps.append(b.identity(path))
        if path.suffix.lower()=='.obj':objects.append(b.identity(path))
assert len(images_maps)==8,images_maps
modules=[];seen=set()
for arm,window in [('cpu','first1'),('cuda','first1'),('cuda','final1'),('vulkan','first1')]:
    runtime_path=P/arm/'validation'/window/'runtime-environment.json'
    runtime=c.read(runtime_path)
    for record in runtime['private_modules']:
        source=Path(record['source']['path']);target=Path(record['destination']['path'])
        assert b.same(record['source']) and b.same(record['destination'])
        assert source.resolve()!=target.resolve() and os.path.samefile(source,target)
        assert target.resolve().is_relative_to(P.resolve())
        key=c.key(target)
        if key in seen:continue
        seen.add(key)
        modules.append(dict(source=record['source'],destination=record['destination'],hardlink=True,
            runtime_evidence=b.identity(runtime_path),cache_source_action='retain'))
command=['powershell','-NoProfile','-Command',
    "@(Get-CimInstance Win32_Process | Where-Object { $_.ExecutablePath -and $_.ExecutablePath.StartsWith('"+
    str(P.resolve()).replace("'","''")+"\\',[System.StringComparison]::OrdinalIgnoreCase) } | Select-Object ProcessId,ExecutablePath) | ConvertTo-Json -Compress"]
observed=subprocess.run(command,text=True,capture_output=True,check=True)
assert observed.stdout.strip() in ['','[]'],observed.stdout
assert not reparse,reparse
c.save(S/'private-module-staging-proof.json',dict(modules=modules,
    verification='Recorded source/destination identities still match and os.path.samefile proves exact cache hardlinks.',
    source_cache_unchanged=True,no_SDK_copy=True,source_action='retain',destination_action='root may unlink only these exact targets'))
destinations=[row['destination'] for row in modules]
c.save(S/'cleanup-windows-inventory.json',dict(status='read_only_proposal_no_deletion',
    rebuildable_images_maps=images_maps,image_map_count=len(images_maps),
    image_map_bytes=sum(x['bytes'] for x in images_maps),
    staged_module_hardlink_targets=destinations,staged_target_count=len(destinations),
    staged_target_logical_bytes=sum(x['bytes'] for x in destinations),
    hardlink_note='Unlinking staged targets does not reclaim the cache source bytes; source paths must be retained.',
    retained_objects=objects,retained_object_count=len(objects),retained_object_bytes=sum(x['bytes'] for x in objects),
    no_running_stage_processes=dict(command=command,stdout=observed.stdout,exit=observed.returncode),
    reparse_points=reparse,private_module_proof=b.identity(S/'private-module-staging-proof.json'),
    no_test_ps1_changes=True,no_deletion_performed=True))
for name in ['private-module-staging-proof.json','cleanup-windows-inventory.json']:print(b.identity(S/name))
