"""Freeze the CUDA alignment delta and current Windows sources; consume root receipts only."""
from pathlib import Path
import argparse
import importlib.util
import sys

sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent;P=S.parent;A=P.parent;R=A.parents[1]
spec=importlib.util.spec_from_file_location('glm_alignment_freeze_helpers',S/'build.py')
h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h);b,c=h.b,h.c
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--cuda-validation')
args=parser.parse_args()
header=b.identity(R/'tests/compute_models/glm_flash_mixed_mlx_fixture.h')
assert header['sha256']=='cf3b828e94c69f9f0f9112a81ba9a05e66446ab54102f4b088ae9981a2583b5a'
names=['tests/compute_models/glm_flash_mixed_mlx_fixture.h','src/compute_route_cuda/weights.cc',
    *[f'tests/graph_route_{arm}/glm_flash_mixed_mlx_test.cc' for arm in ['cpu','cuda','vulkan']],
    *[f'tests/graph_route_{arm}/CMakeLists.txt' for arm in ['cpu','cuda','vulkan']]]
sources=[]
for name in names:
    source=R/name;dest=S/'source-alignment-final'/name
    dest.parent.mkdir(parents=True,exist_ok=True)
    if dest.exists():assert dest.read_bytes()==source.read_bytes()
    else:dest.write_bytes(source.read_bytes())
    sources.append(dict(source=b.identity(source),snapshot=b.identity(dest)))
c.save(S/'source-freeze-final.json',dict(sources=sources,source_count=len(sources),
    first_shared_compile_failure='CPU attempt1: explicit Operation(TopK) construction needed; no math change.',
    first_CUDA_runtime_failure=b.identity(P/'cuda/validation/first1/receipt.json'),
    before_after_freeze=b.identity(P/'cuda/bank-alignment-source-freeze.json'),
    Graph_codec_schema_ABI_changes=0,agent_GPU_runs=0))
owners=[];unique={};entries=0
for arm,relative in [('cpu','cpu/checks/attempt2/identity.json'),
    ('cuda','cuda/checks/attempt3/identity.json'),('vulkan','vulkan/checks/attempt2/identity.json'),
    ('cuda_weights','cuda/checks/bank-alignment-product1/identity.json')]:
    path=P/relative;record=c.read(path)
    assert all(b.same(row) for row in [record['source'],record['object'],*record['dependencies']])
    for row in record['dependencies']:
        entries+=1;key=c.key(row['path'])
        if key in unique:assert unique[key]==row
        unique[key]=row
    owners.append(dict(arm=arm,identity=b.identity(path),source=record['source'],object=record['object'],
        dependency_entries=len(record['dependencies'])))
c.save(S/'current-source-dependency-audit-final.json',dict(owners=owners,drift=[],dependency_entries=entries,
    unique_dependencies=len(unique),dependencies=list(unique.values()),
    baseline_product_audit=b.identity(S/'source-review.json'),
    scope='Current three wrappers plus the one changed CUDA WeightSlots owner; only that product object differs from current W closures.'))
build=[]
for arm,link_name in [('cpu','link1'),('cuda','link2'),('vulkan','link1')]:
    path=P/arm/'checks'/link_name/'link-plan.json';plan=c.read(path)
    assert all(b.same(row) for row in plan['inputs'])
    image=c.read(path.parent/'image.json');assert b.same(image)
    assert c.read(path.parent/'link.result.json')['exit']==0
    build.append(dict(arm=arm,link_plan=b.identity(path),image=image,input_count=len(plan['inputs'])))
validations=[]
for arm,window,expected in [('cpu','first1',1),('vulkan','first1',1),
    *([('cuda',args.cuda_validation,2)] if args.cuda_validation else [])]:
    path=P/arm/'validation'/window/'receipt.json';record=c.read(path)
    assert record['passed'] and record['cases']==expected and not record['failed'] and not record['skipped']
    assert record['image']==next(x['image'] for x in build if x['arm']==arm)
    validations.append(dict(arm=arm,receipt=b.identity(path),cases=expected,skipped=0,failed=0))
c.save(P/'cuda/bank-alignment-audit.json',dict(
    cause='Native CUDA provider Binary input alignment is 256 bytes; WeightSlots aligned backing to 256 but whole bank starts only to scalar alignment and sliced starts to 16.',
    source_contracts=['src/compute_provider_ggml_cuda/program.h:kBinding/boundary_alignment',
        'src/compute_provider_ggml_cuda/ggml_cuda_provider.cc:boundary alignment',
        'src/graph/executable.cc:validate_known_binding_alignment'],
    first_failure=b.identity(P/'cuda/validation/first1/receipt.json'),
    GLM=dict(large_bank_bytes=157286400,map_bytes=1152,bias_bytes=1152,
        old_bias_offset=157287552,old_bias_mod256=128,new_bias_offset=157287680,
        logical_staged_bytes=157288704,new_submitted_extent=157288832,capacity=157288960),
    fix='Reuse one native alignment constant for backing and both entry-layout paths; only private inter-bank padding changes, no extra payload copy.',
    regression='Whole and sliced 12+4-byte F32 banks: actual address/offset 256-aligned, signed zero/NaN payload byte-identical, capacity 260 accepted and 259 rejected before staging/submit.',
    no_change=['public API/ABI','Graph topology','MLX math/precision','source payload','readonly/retirement gates','report semantics'],
    before_after=b.identity(P/'cuda/bank-alignment-source-freeze.json'),GPU_validation_pending=not bool(args.cuda_validation)))
c.save(S/'build-report.json',dict(status='Windows_final_actual_receipts_bound' if args.cuda_validation else 'CUDA_alignment_image_ready_actual_validation_pending',
    successful_test_CXX=4,successful_product_CXX=1,successful_links=4,
    first_shared_compile_failure=b.identity(P/'cpu/checks/attempt1/compile.result.json'),
    first_CUDA_runtime_failure=b.identity(P/'cuda/validation/first1/receipt.json'),
    final_builds=build,actual_validation=validations,actual_validation_executor='root',
    actual_windows_distinct_tests=sum(x['cases'] for x in validations),
    next_incremental_CUDA_base=dict(link_plan=b.identity(P/'cuda/checks/link2/link-plan.json'),
        current_weight_owner=next(x for x in owners if x['arm']=='cuda_weights'),
        requirement='Retain this 256-byte per-bank alignment owner; do not revert to V opaque-slices weights object.'),
    independent_review=b.identity(P/'review/cuda-bank-alignment-review.json'),
    SDK_builds=0,NVCC_compiles=0,offline_shader_compiles=0,agent_CPU_runs=0,agent_GPU_runs=0,
    CUDA_prepare='Natural prepare; replay_route property describes only the last preparation observation, not all submissions.',
    scope='Finite source-bound GLM mixed-MLX role/resource reference and CUDA bank-alignment regression; no full artifact, payload, quality or throughput claim.',
    source_freeze=b.identity(S/'source-freeze-final.json'),
    dependency_audit=b.identity(S/'current-source-dependency-audit-final.json'),
    alignment_audit=b.identity(P/'cuda/bank-alignment-audit.json')))
for name in ['source-freeze-final.json','current-source-dependency-audit-final.json','build-report.json']:
    print(b.identity(S/name))
