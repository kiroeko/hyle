"""Freeze three compiled wrapper sources/dependencies; record actual CPU only, GPU execution remains pending."""
from pathlib import Path
import importlib.util
import sys

sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent
P=S.parent
A=P.parent
R=A.parents[1]
spec=importlib.util.spec_from_file_location('glm_prepared_helpers',A/'grouped-shared-activation/build_host.py')
h=importlib.util.module_from_spec(spec)
spec.loader.exec_module(h)
b,c=h.b,h.c
header=R/'tests/compute_models/glm_flash_mixed_mlx_fixture.h'
assert b.identity(header)['sha256']=='cf3b828e94c69f9f0f9112a81ba9a05e66446ab54102f4b088ae9981a2583b5a'
relative=['tests/compute_models/glm_flash_mixed_mlx_fixture.h',
    *[f'tests/graph_route_{arm}/glm_flash_mixed_mlx_test.cc' for arm in ['cpu','cuda','vulkan']],
    *[f'tests/graph_route_{arm}/CMakeLists.txt' for arm in ['cpu','cuda','vulkan']]]
sources=[]
for name in relative:
    source=R/name;dest=S/'source-final'/name
    dest.parent.mkdir(parents=True,exist_ok=True)
    if dest.exists():assert source.read_bytes()==dest.read_bytes()
    else:dest.write_bytes(source.read_bytes())
    sources.append(dict(source=b.identity(source),snapshot=b.identity(dest)))
c.save(S/'source-freeze.json',dict(status='compiled_sources_frozen_actual_GPU_validation_pending',
    source_count=len(sources),sources=sources,product_changes=0,
    first_shared_snapshot=b.identity(S/'source-attempt1/tests/compute_models/glm_flash_mixed_mlx_fixture.h'),
    mechanical_fix='Shared TopK add_node requires an explicit Operation wrapper; no shape, arithmetic or oracle change.'))
owners=[];unique={};entries=0
for arm in ['cpu','cuda','vulkan']:
    path=P/arm/'checks/attempt2/identity.json';record=c.read(path)
    assert all(b.same(x) for x in [record['source'],record['object'],*record['frozen_shared'],*record['dependencies']])
    for dependency in record['dependencies']:
        entries+=1;key=c.key(dependency['path'])
        if key in unique:assert unique[key]==dependency
        unique[key]=dependency
    owners.append(dict(arm=arm,identity=b.identity(path),source=record['source'],object=record['object'],
        dependency_entries=len(record['dependencies'])))
c.save(S/'current-source-dependency-audit.json',dict(status='three_new_wrappers_current_zero_drift',
    owners=owners,dependency_entries=entries,unique_dependencies=len(unique),drift=[],dependencies=list(unique.values()),
    baseline_audit=b.identity(S/'source-review.json'),
    weak_inline_scope='No model/Graph/native ABI change; only prior W test TU replaced. W product objects including V weights and T resources/geometry fixes remain.'))
build=[]
for arm in ['cpu','cuda','vulkan']:
    compile_path=P/arm/'checks/attempt2/compile.result.json';link_path=P/arm/'checks/link1/link.result.json'
    assert c.read(compile_path)['exit']==0 and c.read(link_path)['exit']==0
    plan_path=P/arm/'checks/link1/link-plan.json';plan=c.read(plan_path)
    assert all(b.same(x) for x in plan['inputs'])
    image=c.read(P/arm/'checks/link1/image.json');assert b.same(image)
    build.append(dict(arm=arm,compile=b.identity(compile_path),link=b.identity(link_path),
        image=image,link_plan=b.identity(plan_path),input_count=len(plan['inputs'])))
cpu_receipt_path=P/'cpu/validation/first1/receipt.json';cpu=c.read(cpu_receipt_path)
assert cpu['passed'] and cpu['cases']==1 and not cpu['failed'] and not cpu['skipped']
first_compile=P/'cpu/checks/attempt1/compile.result.json'
assert c.read(first_compile)['exit']!=0
c.save(S/'build-report-prevalidation.json',dict(status='three_focused_images_ready_CPU_actual_passed_GPU_pending',
    build=build,successful_test_CXX=3,first_shared_compile_failure=b.identity(first_compile),
    first_failure_classification='Test API expression needed explicit Operation(TopK); root/quant mechanical fix, not product/math failure.',
    successful_links=3,product_CXX=0,SDK_builds=0,NVCC_compiles=0,offline_shader_compiles=0,
    actual_CPU_receipt=b.identity(cpu_receipt_path),actual_CPU_cases=1,CPU_successful_submissions=4,
    CPU_expected_failed_submissions=1,GPU_pass_claim=False,agent_CPU_runs=0,agent_GPU_runs=0,
    source_freeze=b.identity(S/'source-freeze.json'),dependency_audit=b.identity(S/'current-source-dependency-audit.json'),
    prepared_gpu_list=b.identity(S/'ready-for-root-run-cuda-vulkan.json')))
for name in ['source-freeze.json','current-source-dependency-audit.json','build-report-prevalidation.json']:
    print(b.identity(S/name))
