from pathlib import Path, PurePosixPath
import hashlib, json, re, zipfile, xml.etree.ElementTree as ET

P = Path(__file__).resolve().parents[1]
R = P.parents[2]


def read(p):
    return json.loads(p.read_text(encoding='utf-8-sig'))


def sha(p):
    h = hashlib.sha256()
    with p.open('rb') as f:
        for block in iter(lambda: f.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def resolve(p):
    p = Path(p)
    return p if p.is_absolute() else R / p


def ident(p):
    return dict(path=p.relative_to(R).as_posix(), bytes=p.stat().st_size, sha256=sha(p))


def check(d):
    p = resolve(d['path'])
    assert p.is_file() and p.stat().st_size == d['bytes'] and sha(p) == d['sha256'], str(p)


def save(p, d):
    p.write_text(json.dumps(d, ensure_ascii=False, indent=2) + '\n', encoding='utf8')


config = read(P / 'root/final-results.json')
cases, receipts = [], []


def collect(arm, p):
    tests = ET.parse(p).findall('.//testcase')
    assert len(tests) == (2 if arm == 'cuda' else 1), (arm, len(tests))
    for x in tests:
        assert x.find('failure') is None and x.find('skipped') is None
        name = x.get('classname') + '.' + x.get('name')
        alignment = x.get('classname') == 'CudaWeightBankAlignment'
        assert (arm == 'cuda' and alignment) or 'GlmFlashMixedMlx.' in name, name
        cases.append(dict(backend=arm, name=name, neighbor=False,
                          role_consumer=not alignment,
                          properties={i.get('name'): i.get('value')
                                      for i in x.findall('./properties/property')}))


for arm in ('cpu', 'cuda', 'vulkan'):
    p = resolve(config[arm])
    d = read(p)
    assert d['passed'] and d['cases'] == (2 if arm == 'cuda' else 1) and not d['skipped'] and not d['failed']
    for key in ('image', 'link_plan', 'xml'):
        check(d[key])
    for row in read(resolve(d['link_plan']['path']))['inputs']:
        check(row)
    for row in read(p.parent / 'runtime-environment.json').get('private_modules', []):
        check(row['source'])
        check(row['destination'])
        assert row['hardlink'] and row['source']['sha256'] == row['destination']['sha256']
    collect(arm, resolve(d['xml']['path']))
    receipts.append(dict(backend=arm, receipt=ident(p)))

ap = resolve(config['apple'])
a = read(ap)
assert a['tests'] == 1 and a['failed'] == a['skipped'] == 0
check(a['source_freeze'])
for row in a['artifacts'].values():
    check(row)
assert a['run']['exit'] == 0
assert read(resolve(a['artifacts']['link.result.json']['path']))['exit'] == 0
collect('apple', resolve(a['artifacts']['tests.xml']['path']))
assert len(cases) == 5 and not any(x['neighbor'] for x in cases)
role_cases = [x for x in cases if x['role_consumer']]
alignment_cases = [x for x in cases if not x['role_consumer']]
assert len(role_cases) == 4 and len(alignment_cases) == 1
assert alignment_cases[0]['backend'] == 'cuda'
for x in role_cases:
    props = x['properties']
    assert props['successful_submissions'] == '4'
    assert props['expected_failed_submissions'] == '1'
    assert props['successful_weight_generations'] == '3'
    assert props['original_fragments_per_generation'] == '92'
    assert props['native_weight_slots'] == ('0' if x['backend'] == 'cpu' else '2')
    for key in ('metadata_bf16_counterfactual_words', 'early_bf16_counterfactual_words',
                'softmax_counterfactual_words'):
        assert int(props[key]) > 0
    for mode in range(3):
        assert max(float(props[f'wrong_policy{mode}_peak_error']),
                   float(props[f'wrong_policy{mode}_relative_l2'])) > 2.e-5
successful = sum(int(x['properties']['successful_submissions']) for x in role_cases)
expected_failed = sum(int(x['properties']['expected_failed_submissions']) for x in role_cases)
assert successful == 16 and expected_failed == 4
observed_peak = max(float(x['properties']['maximum_peak_normalized_error']) for x in role_cases)
observed_l2 = max(float(x['properties']['maximum_relative_l2_error']) for x in role_cases)
shared = R / 'tests/compute_models/glm_flash_mixed_mlx_fixture.h'
assert sha(shared) == 'cf3b828e94c69f9f0f9112a81ba9a05e66446ab54102f4b088ae9981a2583b5a'
check(read(P / 'source-freeze.json')['shared'])
catalog = read(R / 'docs/implementation/model-quantizations.json')
assert len(catalog['artifacts']) == 33
assert all(x['provider_coverage']['artifact_execution_verified'] is False
           for x in catalog['artifacts'])

# Most product references are reused; the CUDA weights owner is refreshed for
# the actual bank-alignment repair. Build counts are recorded in the receipts.
sources = {
    'src/compute/weight_assembly.h', 'include/hyle/compute/weight_assembly.h',
    'src/compute_route_cuda/weights.cc', 'src/compute_route_vulkan/vulkan_weights.cc',
    'src/compute_route_apple/apple_weights.mm',
    'include/hyle/compute/cuda_weights.h', 'include/hyle/compute/vulkan_weights.h',
    'include/hyle/compute/apple_weights.h',
    'src/graph_route_cuda/weight_binding.cc', 'src/graph_route_vulkan/weight_binding.cc',
    'src/graph_route_apple/weight_binding.cc', 'include/hyle/graph/weight_binding.h',
    'include/hyle/graph/result.h', 'include/hyle/graph/executable.h',
    'include/hyle/compute/resource_leases.h', 'include/hyle/compute/model_ops.h',
    'include/hyle/compute/operation.h', 'src/compute/resource_leases.cc',
    'src/graph/input_sources.cc', 'src/graph/resources.cc', 'src/graph/executable.cc',
    'src/compute_ops/weight_decode.cc',
    'src/compute_provider_native/torch_cpu_program.cc',
    'third_party/mlx_cpu_quant/mlx_cpu_quant.h',
    'src/compute_provider_torch_cuda/artifact_provider.cc',
    'src/compute_provider_torch_cuda/mlx_packed_kernel.h',
    'src/compute_provider_torch_cuda/mlx_packed_kernel.cu',
    'src/compute_provider_cuda/packed_rows.cuh',
    'src/compute_route_apple/apple_tensor.cc',
    'src/compute_route_vulkan/vulkan_mlx.cc',
    'docs/developer/current-work.md', 'docs/user/compute.md', 'docs/user/graph.md',
    'docs/implementation/model-operators.md', 'docs/implementation/model-quantizations.json',
}
sources.update(f'tests/graph_route_{arm}/{name}'
               for arm in ('cpu', 'cuda', 'vulkan', 'apple')
               for name in ('glm_flash_mixed_mlx_test.cc', 'CMakeLists.txt'))

# Retain only local test helpers transitively included by the new shared head.
# The existing independent bit writer/storage helpers are reused, not copied SDKs.
pending = [shared]
while pending:
    p = pending.pop()
    relative = p.relative_to(R).as_posix()
    if relative in sources:
        continue
    sources.add(relative)
    for name in re.findall(r'^\s*#include\s+"([^"]+)"', p.read_text(encoding='utf-8-sig'), re.M):
        child = (p.parent / name).resolve()
        if child.is_file() and child.is_relative_to(R / 'tests'):
            pending.append(child)

entries = {'source/' + s: R / s for s in sorted(sources)}
suffixes = {'.json', '.py', '.log', '.txt', '.xml', '.diff', '.cc', '.h', '.hpp',
            '.md', '.mm', '.ps1', '.cmake', '.in', '.d', '.cu', '.cuh', '.metal', '.comp'}
for p in P.rglob('*'):
    if (p.is_file() and p.suffix.lower() in suffixes
            and not p.name.startswith(('package-summary', 'cleanup-plan', 'cleanup-script', 'final-package'))):
        entries['records/' + p.relative_to(P).as_posix()] = p

# This is the actual existing public source archive, not an assumed GLM-named
# research pair. Its original fixed metadata/pinned producer claims stay scoped.
for ext in ('json', 'zip'):
    p = R / f'docs/evidence/research/fixed-role-binding-2026-10-21.{ext}'
    entries['provenance/' + p.name] = p
prerequisite = R / 'docs/evidence/correctness/expert-working-set-reference-2026-10-21.json'
entries['provenance/' + prerequisite.name] = prerequisite

# Small pinned primary snapshots and reports are explicitly named by the source
# review. Keep their repository-relative identity; no weight/SDK payload follows.
for row in read(P / 'review/design-review.json')['source_identities']:
    p = resolve(row['path'])
    if p.is_relative_to(R / '.scratch'):
        check(row)
        entries['provenance/' + p.relative_to(R / '.scratch').as_posix()] = p
for row in read(P / 'review/design-review.json')['original_header_records']:
    check(row['header'])
    p = resolve(row['header']['path'])
    entries['provenance/' + p.relative_to(R / '.scratch').as_posix()] = p
if config.get('next_role_review'):
    p = resolve(config['next_role_review'])
    entries['next_revisit/' + p.name] = p

archive = R / 'docs/evidence/correctness/glm-flash-mixed-mlx-reference-2026-10-21.zip'
for name, p in entries.items():
    path = PurePosixPath(name)
    assert not path.is_absolute() and '..' not in path.parts and p.is_file(), name
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED, compresslevel=8) as z:
    for name, p in sorted(entries.items()):
        z.write(p, name)
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None and len(z.namelist()) == len(entries)
    for name, p in entries.items():
        h = hashlib.sha256()
        with z.open(name) as f:
            for block in iter(lambda: f.read(1024 * 1024), b''):
                h.update(block)
        assert h.hexdigest() == sha(p), name

doc = dict(
    observed_on='2026-10-21', status='four_backend_GLM_Flash_mixed_MLX_role_and_resource_reference_passed',
    scope='Fixed GLM Flash role geometry and ordinary default-reader equation: D4096/H2048/globalE288/Top8/resident9, routed affine4/4/5 and shared affine6, group64 original F16 scale/bias. BF16 activation and an explicitly supplied F32 router-logit boundary. Synthetic original-format bytes; no checkpoint numeric payload or whole-model execution.',
    source='Fixed catalog32 mlx-community/GLM-5.3-Flash-4bit@fa04cbc3622b16aa7475404060b05e506d81bd4e metadata/header roles; pinned MLX-VLM f1a9b7bac6f2b95f588ffc9343495a3c61c6e328 and MLX core 1f8e74e3f12f31365464a6867c6579f0e9b29d85. Default load retains F16 metadata; ordinary BF16+F16 affine QMM promotes to F32. Original exporter identity and optimized short-block branches remain separate.',
    mathematics='Sigmoid(F32 logits), selection-only correction, Top8, gather unbiased probabilities, divide by(sum+1e-20), multiply2.5. Original BF16 A/F16 metadata gate/up promotes F32; gate only upper-clips10, up clips[-10,10], F32 SiLU multiply feeds F32 down. Routeweights apply after down, then F32 selected sum and original shared affine6 branch addition. No intermediate/final BF16 narrowing is inserted at this MoE boundary.',
    oracle='Existing independent bit-scatter writer and F32/BF16 storage helpers are reused. Synthetic affine rows have baseline code1/F16 bias=-scale and two nonbaseline positions, so the source scalar reference needs no floating NK/ENK bank. F32 decode product/add, clipping/SiLU, routing and sum order are explicit; expected results never read staged device bytes. Eight published source boundaries use fixed normalized-peak and relativeL2<=2e-5, with exact I32 selected global IDs for these non-tied scores.',
    counterfactuals='Before device execution, independent host scalar witnesses reject F16 metadata mistakenly converted to BF16, prematurely narrowed BF16 gate/up, and the older generic softmax route probabilities. All8192 final words differ in each arm and at least one normalized metric exceeds the fixed2e-5 bound. Per-case XML retains the actual error metrics, not only different-word counts.',
    observations=dict(maximum_peak_normalized_error=observed_peak, maximum_relative_l2_error=observed_l2),
    journey='Three same-generation original weight/map/correction sets. GPU uses two existing WeightSlots configured max_fragments128 and92 genuine source fragments per generation:81 independently stored expert W/SF/bias tensors,9 shared tensors,map and correction. Retained batch then Invocation/results reject overwrite; releasing original owners permits slot0 reuse. Host sources are destroyed before compute. A globally valid absent expert286 maps to-1, fails Completion without a result, and a fresh Invocation recovers. Old results survive later generations and public producer teardown.',
    CPU='The same ordinary graph binds original typed host ReadLeases after explicit cold assembly from independently stored source tensors. CPU does not fabricate native WeightSlots or claim GPU slot retirement. Backend context/resources and retained dynamic-input leases remain alive during the final result checks.',
    resource_limits='No entire288-expert floating bank, new format, quantizer, transfer executor or public operator was introduced. CUDA now places banks at the original256-byte backing alignment in both whole-entry and sliced uploads; the role exposed a small-map/bias boundary previously hidden by E256 dimensions. Actual upload reports distinguish logical data from aligned submitted extents. Apple may still convert resident F16 scale/bias arrays to temporary F32 in the warm path; that source-reviewed delivery3 optimization remains unmodified and no allocation/throughput improvement is claimed here.',
    fixes=config['fixes'], build=config['build'], prerequisite=ident(prerequisite),
    regression=dict(total=5, new_cases=5, role_cases=4, alignment_cases=1,
                    neighbors=0, failed=0, skipped=0,
                    successful_Graph_submissions=successful,
                    expected_failed_Graph_completions=expected_failed,
                    windows=receipts, apple=ident(ap), cases=cases,
                    alignment_scope='One CUDA regression covers original whole-entry and sliced F32[3]+F32[1] bank uploads, exact260-byte capacity versus rejected259, data/accounting and prewrite failure. Uploads are not counted as Graph submissions.'),
    limitations=[
        'Finite original-role synthetic payload/resource journey only; no artifact numeric weight payload, all129banks/288resident experts, full router projection, attention/mHC/model/quality or performance result.',
        'Existing mixed affine primitives and slice/bundle execution API are reused. One CUDA weights.cc resource-alignment fix refreshes its actual owner and CUDA wrapper; CPU/Apple/Vulkan role windows retain their already-green product closures. No SDK/new math/provider/executor implementation. Actual compile/link attempts are in metadata.',
        'The first CPU strict CXX failure is retained with originaldcd99 source/log and the one-line explicit Operation(TopK) fix. It is a GraphBuilder call-site preparation error, not a product numerical failure; oracle, equation, policy and public API remain unchanged.',
        'The first CUDA role run failed graph binding offset alignment before numerical execution. Original source/log and corrected source/link are preserved. Bank placement is fixed instead of relaxing alignment checks or adding a shadow copy; the shared cf3b source and numerical policy are unchanged.',
        'Pinned ordinary-reader F32 promotion is source-qualified. Explicit converted/set_dtype artifacts, original exporter version, native same-low-type bitwise equivalence and special optimized short-block branches are not signed.',
        'No Linux/full canonical configure/install/device/dtype/geometry matrix, total opaque-private-memory or all-captured execution claim. CUDA default preparation preserves its real original routing.',
        'All33 artifact_execution_verified remainfalse. Capability7/8 still requires the remaining Quark FP8 side-role action; any independent preview report is a next step, not closed qualification. Delivery0/3 remains a separate boundary.',
    ],
    source_freeze=ident(P / 'source-freeze.json'),
    current_sources=[ident(R / s) for s in sorted(sources)],
    archive=dict(**ident(archive), members=len(entries)),
    archive_entries=[dict(entry=name, bytes=p.stat().st_size, sha256=sha(p))
                     for name, p in sorted(entries.items())],
)
save(archive.with_suffix('.json'), doc)
summary = dict(evidence=ident(archive.with_suffix('.json')), archive=doc['archive'],
               sources=len(sources), cases=5, role_cases=4, alignment_cases=1,
               successful_submissions=16,
               expected_failed_completions=4)
save(P / 'root/package-summary.json', summary)
print(json.dumps(summary, ensure_ascii=False))
