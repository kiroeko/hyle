from pathlib import Path

R = Path(__file__).resolve().parents[4]
path = R / 'docs/implementation/model-operators.md'
text = path.read_text(encoding='utf-8')
changes = [
    ('37152专家碎片到129组MLX working-set实际旅程未验。',
     '[GLM32有限角色／工作集](../evidence/correctness/glm-flash-mixed-mlx-reference-2026-10-21.json)已四端执行9个驻留专家的92片段／三代双槽；原37152份payload与全部129组bank未执行。'),
    ('不签实际GLM routing／shared expert／mHC、其余payload／整制品、质量、吞吐或峰值；',
     'GLM32的精确routing／shared已由上述有限消费者覆盖；完整mHC、其余payload／整制品、质量、吞吐或峰值仍未签；')
]
for old, new in changes:
    assert text.count(old) == 1, old
    text = text.replace(old, new)
path.write_text(text, encoding='utf-8')
print('Updated the MLX row to distinguish the executed finite role from unexecuted whole artifacts.')
