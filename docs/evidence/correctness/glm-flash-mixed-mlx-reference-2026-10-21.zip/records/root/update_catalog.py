from pathlib import Path
import difflib
import json

P = Path(__file__).resolve().parents[1]
R = P.parents[2]
config = json.loads((P / 'root/final-results.json').read_text(encoding='utf-8-sig'))
for backend in ('cpu', 'cuda', 'vulkan'):
    d = json.loads((R / config[backend]).read_text(encoding='utf-8-sig'))
    assert d['passed'] and not d['failed'] and not d['skipped']
    assert d['cases'] == (2 if backend == 'cuda' else 1)
apple = json.loads((R / config['apple']).read_text(encoding='utf-8-sig'))
assert apple['tests'] == 1 and apple['failed'] == apple['skipped'] == 0

path = R / 'docs/implementation/model-quantizations.json'
before = path.read_text(encoding='utf-8')
catalog = json.loads(before)
assert len(catalog['artifacts']) == 33
assert all(a['provider_coverage']['artifact_execution_verified'] is False
           for a in catalog['artifacts'])
artifact = catalog['artifacts'][32]
assert artifact['repository'] == 'mlx-community/GLM-5.3-Flash-4bit'
coverage = artifact['provider_coverage']
evidence = 'docs/evidence/correctness/glm-flash-mixed-mlx-reference-2026-10-21.json'
mapping = (
    'Fixed affine4/4/5 routed and affine6 shared g64 U32/F16 scale/bias roles '
    'now have a four-backend finite source-bound ordinary MoE consumer: '
    'BF16 activation promotes to F32, sigmoid/correction Top8 selects unbiased '
    'probabilities, route weights apply after down, and shared/final remain F32. '
    'Original independent expert fragments bind through the existing bounded '
    'weight/map generation and old-result lifecycle. Synthetic original-format '
    'bytes, not the artifact numeric payload or a whole-layer/model run.'
)
limits = [
    'The representative layer3 role/resource journey is executed; all37152 '
    'original expert triples/all129 banks, original exporter identity, publisher '
    'numeric payload and a complete artifact importer/model are not established. '
    'They are not37152 missing public primitives.',
    'Explicit set_dtype/converted-artifact overrides, same-low-type native QMM '
    'bit equivalence, special short-block branches, complete attention/mHC, '
    'Linux closure, quality and throughput remain outside this finite reference.',
    'Apple warm replay still promotes immutable resident F16 SF/bias again. '
    'Per-generation prepared-promotion reuse and its resource budget/lifetime '
    'handoff are a concrete pending delivery3 repair; physical allocation counts '
    'and performance impact were not measured by the source review.'
]
coverage['mapping_status'] = mapping
coverage['role_domains'][0]['observed'] = mapping
coverage['role_domains'][0]['unresolved'] = limits
coverage['role_domains'][0]['followup_evidence'] = evidence
coverage['artifact_unaligned_or_unverified'] = limits
coverage['missing_capabilities'] = limits
coverage['fusion_coverage'] = (
    'Original affine packed primitives plus ordinary graph composition now '
    'execute the finite GLM32 sigmoid/correction, clipped routed4/4/5 and shared6 '
    'g64/F16-metadata role on CPU/CUDA/Vulkan/Apple. Original F32 promotion and '
    'post-down weighting are retained. Physical GLU/expert fusion remains an '
    'optional optimization, not established by ordinary composition.'
)
coverage['mixed_mlx_role_reference'] = {
    'observed_on': '2026-10-21', 'evidence': evidence,
    'reference_source': 'Pinned default MLX-VLM ordinary reader, original layer3 headers; no forced metadata cast',
    'geometry': 'D4096/H2048, globalE288/Top8/resident9, routed4/4/5+shared6, group64',
    'backends': ['CPU', 'CUDA', 'Vulkan', 'Apple'],
    'role_cases': 4, 'successful_Graph_submissions': 16,
    'expected_failed_Graph_completions': 4, 'skipped': 0,
    'resource_journey': '92 original fragments per generation, three generations; native GPU two-slot reuse/old-results/missing-map failure and recovery; CPU explicit host assembly and ReadLeases',
    'CUDA_bank_alignment': 'Original whole-entry and sliced upload layouts now satisfy the original256-byte native port alignment, with fixed-capacity prewrite rejection; separate260/259-byte regression',
    'artifact_execution_verified': False
}
bridge = coverage['working_set_bridge_reference']
bridge['prior_generic_evidence'] = bridge['evidence']
bridge['evidence'] = evidence
bridge['scope'] = (
    'Original independent MLX W/F16-SF/bias fragments now execute a representative '
    'resident9/global288 role with atomic map/correction binding, three generations, '
    'old results and expected missing-ID recovery. All129 original payload banks '
    'and the complete artifact are not executed.'
)
catalog['followup_reviews'].append({
    'observed_on': '2026-10-21', 'evidence': evidence,
    'scope': 'Catalog32 precise mixed-MLX finite role and resource consumer, four backends; CUDA bank alignment repaired; Apple warm metadata promotion remains pending delivery3.',
    'artifact_execution_verified': False
})
after = json.dumps(catalog, ensure_ascii=False, indent=2) + '\n'
(P / 'root/catalog-update.diff').write_text(''.join(difflib.unified_diff(
    before.splitlines(True), after.splitlines(True), fromfile=str(path), tofile=str(path))), encoding='utf-8')
path.write_text(after, encoding='utf-8')
print('Updated catalog32 finite role/resource reference; all33 whole-artifact flags remain false.')
