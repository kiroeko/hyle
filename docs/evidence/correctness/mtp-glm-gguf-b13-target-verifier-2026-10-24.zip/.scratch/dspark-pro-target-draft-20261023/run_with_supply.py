"""Windows native validation driver; supply only explicitly requested original experts."""
import argparse
import ctypes as ct
from ctypes import wintypes as wt
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time

S = Path(__file__).resolve().parent
R = S.parents[1]
DOMAIN = 384
SECTIONS = ('target', 'draft')
WAIT_ENV = 'HYLE_DSPARK_PRO_WAIT_FOR_EXPERTS'
FRONTIER_ENV = 'HYLE_DSPARK_PRO_FRONTIER_FILE'
FETCH_SCRIPT = None


class BasicLimits(ct.Structure):
    _fields_ = [('process_time', ct.c_int64), ('job_time', ct.c_int64), ('flags', wt.DWORD),
                ('minimum_working_set', ct.c_size_t), ('maximum_working_set', ct.c_size_t),
                ('active_processes', wt.DWORD), ('affinity', ct.c_size_t),
                ('priority', wt.DWORD), ('scheduling', wt.DWORD)]


class ExtendedLimits(ct.Structure):
    _fields_ = [('basic', BasicLimits), ('io', ct.c_uint64 * 6),
                ('process_memory', ct.c_size_t), ('job_memory', ct.c_size_t),
                ('peak_process_memory', ct.c_size_t), ('peak_job_memory', ct.c_size_t)]


class OwnedJob:
    def __init__(self):
        if os.name != 'nt':
            raise RuntimeError('This driver owns the Windows native validation process tree')
        self.api = ct.WinDLL('kernel32', use_last_error=True)
        for name, args, result in (
            ('CreateJobObjectW', [ct.c_void_p, wt.LPCWSTR], wt.HANDLE),
            ('SetInformationJobObject', [wt.HANDLE, ct.c_int, ct.c_void_p, wt.DWORD], wt.BOOL),
            ('AssignProcessToJobObject', [wt.HANDLE, wt.HANDLE], wt.BOOL),
            ('GetCurrentProcess', [], wt.HANDLE), ('CloseHandle', [wt.HANDLE], wt.BOOL),
            ('QueryInformationJobObject', [wt.HANDLE, ct.c_int, ct.c_void_p, wt.DWORD, ct.POINTER(wt.DWORD)], wt.BOOL),
            ('OpenProcess', [wt.DWORD, wt.BOOL, wt.DWORD], wt.HANDLE),
            ('TerminateProcess', [wt.HANDLE, wt.UINT], wt.BOOL),
            ('WaitForSingleObject', [wt.HANDLE, wt.DWORD], wt.DWORD)):
            fn = getattr(self.api, name)
            fn.argtypes, fn.restype = args, result
        self.handle = self.api.CreateJobObjectW(None, None)
        if not self.handle:
            raise ct.WinError(ct.get_last_error())
        self.limits = ExtendedLimits()
        self.limits.basic.flags = 0x2000  # JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE
        try:
            self.apply()
            # Assign this driver before creating any children. Descendants
            # inherit the job without a launch/assignment race. Parent
            # q.execute uses TerminateProcess on timeout: finally cannot run,
            # but Windows then closes this sole job handle and reaps children.
            if not self.api.AssignProcessToJobObject(self.handle, self.api.GetCurrentProcess()):
                raise ct.WinError(ct.get_last_error())
        except BaseException:
            self.api.CloseHandle(self.handle)
            raise

    def apply(self):
        if not self.api.SetInformationJobObject(self.handle, 9, ct.byref(self.limits), ct.sizeof(self.limits)):
            raise ct.WinError(ct.get_last_error())

    def child_pids(self):
        # Direct parents can exit while a budget/downloader grandchild lives.
        # Query the actual job before disabling its kill-on-close guarantee.
        capacity = 8
        while True:
            raw = ct.create_string_buffer(8 + ct.sizeof(ct.c_size_t) * capacity)
            ok = self.api.QueryInformationJobObject(self.handle, 3, raw, len(raw), None)
            error = ct.get_last_error() if not ok else 0
            assigned, count = (wt.DWORD * 2).from_buffer(raw)
            if not ok and error != 234:  # ERROR_MORE_DATA
                raise ct.WinError(error)
            if not ok or assigned > capacity:
                capacity = max(capacity * 2, assigned)
                continue
            pids = (ct.c_size_t * count).from_buffer(raw, 8)
            return [int(pid) for pid in pids if pid != os.getpid()]

    def close(self):
        retired = []
        try:
            deadline = time.monotonic() + 10
            while True:
                children = self.child_pids()
                if not children:
                    break
                if time.monotonic() >= deadline:
                    raise RuntimeError('Owned job still contains a native/download descendant')
                for pid in children:
                    handle = self.api.OpenProcess(0x00100001, False, pid)  # SYNCHRONIZE|PROCESS_TERMINATE
                    if not handle:
                        if ct.get_last_error() == 87:  # Process exited after the snapshot.
                            continue
                        raise ct.WinError(ct.get_last_error())
                    try:
                        if not self.api.TerminateProcess(handle, 130):
                            if self.api.WaitForSingleObject(handle, 0) != 0:
                                raise ct.WinError(ct.get_last_error())
                        remaining = max(0, min(5000, int((deadline - time.monotonic()) * 1000)))
                        if self.api.WaitForSingleObject(handle, remaining) != 0:
                            raise RuntimeError('Owned descendant did not retire: ' + str(pid))
                        retired.append(pid)
                    finally:
                        self.api.CloseHandle(handle)
            # Every descendant is now gone, not merely the two direct parents.
            self.limits.basic.flags = 0
            self.apply()
        finally:
            # A cleanup failure deliberately retains KILL_ON_JOB_CLOSE. It
            # cannot silently detach live descendants or report success.
            if not self.api.CloseHandle(self.handle):
                raise ct.WinError(ct.get_last_error())
        return dict(remaining_descendants=0, retired_descendants=retired)


def stop(child):
    if child is not None and child.poll() is None:
        child.terminate()
        try:
            child.wait(timeout=5)
        except subprocess.TimeoutExpired:
            child.kill()
            child.wait(timeout=5)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--image', type=Path, required=True)
    parser.add_argument('--frontier-file', type=Path, required=True)
    parser.add_argument('native_args', nargs=argparse.REMAINDER)
    args = parser.parse_args()
    image, frontier = args.image.resolve(), args.frontier_file.resolve()
    if not image.is_file():
        raise ValueError('Native image does not exist: ' + str(image))
    native_args = args.native_args[1:] if args.native_args[:1] == ['--'] else args.native_args
    command = [str(image), *native_args]
    frontier.parent.mkdir(parents=True, exist_ok=True)
    frontier.write_text('{}\n', encoding='utf-8')  # Ignore a preceding run's request.
    record_path = frontier.with_name(frontier.stem + '.driver.json')
    record = dict(driver_pid=os.getpid(), native=dict(command=command), fetches=[], started=time.time())

    def save(event):
        temporary = record_path.with_suffix('.json.next')
        temporary.write_text(json.dumps(record, indent=2) + '\n', encoding='utf-8')
        os.replace(temporary, record_path)
        message = dict(event=event, record=str(record_path), native=record['native'],
                       fetch_count=len(record['fetches']), exit=record.get('exit'))
        if event.startswith('expert_fetch_'):
            message['fetch'] = record['fetches'][-1]
        print(json.dumps(message), flush=True)

    def interrupted(signum, frame):
        raise KeyboardInterrupt('Supply driver interrupted by signal ' + str(signum))

    signal.signal(signal.SIGTERM, interrupted)
    signal.signal(signal.SIGINT, interrupted)
    env = os.environ.copy()
    env[WAIT_ENV] = '1'
    env[FRONTIER_ENV] = str(frontier)
    native = fetch = job = None
    result, seen = 1, set()
    try:
        job = OwnedJob()
        native = subprocess.Popen(command, cwd=R, env=env, stdout=sys.stdout, stderr=sys.stderr,
                                  creationflags=subprocess.CREATE_NO_WINDOW)
        record['native'].update(pid=native.pid, started=time.time())
        save('native_started')
        while native.poll() is None:
            try:
                request = json.loads(frontier.read_text(encoding='utf-8-sig'))
            except (FileNotFoundError, json.JSONDecodeError):
                time.sleep(1)
                continue
            missing = request.get('missing_ids', [])
            if missing:
                section, stage, globals_ = request['section'], request['stage'], request['global_ids']
                if (section not in SECTIONS or type(stage) is not int or not 0 <= stage < 3
                        or not isinstance(missing, list) or not isinstance(globals_, list)
                        or any(type(x) is not int or not 0 <= x < DOMAIN for x in missing + globals_)
                        or not set(missing) <= set(globals_)):
                    raise ValueError('Native frontier has invalid section/stage/global IDs')
                key = (section, stage, tuple(sorted(set(missing))))
                if key not in seen:
                    fetch_command = [sys.executable, str(FETCH_SCRIPT or S / 'fetch_experts.py'), '--frontier-file', str(frontier)]
                    item = dict(request=request, command=fetch_command, started=time.time())
                    record['fetches'].append(item)
                    fetch = subprocess.Popen(fetch_command, cwd=R, env=env, stdout=sys.stdout, stderr=sys.stderr,
                                             creationflags=subprocess.CREATE_NO_WINDOW)
                    item['pid'] = fetch.pid
                    save('expert_fetch_started')
                    # A failed native test must not open another frontier,
                    # but its already approved bounded HTTP batch drains.
                    # Never kill budget/downloader descendants mid-request
                    # merely because the numerical consumer exited first.
                    while fetch.poll() is None:
                        if native.poll() is not None and 'native_exited_during_fetch' not in item:
                            item['native_exited_during_fetch'] = dict(exit=native.returncode, observed=time.time())
                            save('expert_fetch_draining_after_native_exit')
                        time.sleep(1)
                    item.update(exit=fetch.wait(), finished=time.time())
                    save('expert_fetch_finished')
                    if item['exit'] != 0:
                        result = item['exit']
                        raise RuntimeError('Original expert fetch failed with exit ' + str(result))
                    seen.add(key)
                    fetch = None
            time.sleep(1)
        result = native.wait()
    except KeyboardInterrupt as error:
        result = 130
        record['error'] = str(error)
    except Exception as error:
        record['error'] = dict(type=type(error).__name__, message=str(error))
    finally:
        try:
            fetch_running = fetch is not None and fetch.poll() is None
            native_running = native is not None and native.poll() is None
            stop(fetch)
            stop(native)
            if fetch is not None:
                record['fetches'][-1].update(exit=fetch.returncode, finished=time.time(), stopped_by_driver=fetch_running)
            if native is not None:
                record['native'].update(exit=native.returncode, finished=time.time(), stopped_by_driver=native_running)
            record.update(exit=result, finished=time.time())
        finally:
            if job is not None:
                record['job_cleanup'] = job.close()
        save('supply_driver_finished')
    return result


if __name__ == '__main__':
    sys.exit(main())
