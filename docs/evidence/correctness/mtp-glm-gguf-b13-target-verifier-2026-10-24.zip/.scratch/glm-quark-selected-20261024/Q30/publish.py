"""Publish completed finite Q30 CPU/CUDA original-role executions only.

This script never builds, runs a model, fetches, or rehashes weight bodies.
All native counts come from the selected actual XML/summary/driver records.
"""
from pathlib import Path
from datetime import datetime, timezone
import argparse
import hashlib
import json
import re
import xml.etree.ElementTree as ET
import zipfile

S=Path(__file__).resolve().parent
R=S.parents[2]
Q=S/'graph-integration-preparation'
D=R/'docs/evidence/correctness'
NAME='mtp-glm-quark-target-verifier-2026-10-24'
REPO='amd/GLM-5.3-Flash-Quark-MXFP4'
REV='b5688f25491202978c19c4d036eef579f61bbe07'
CORRECT_MODULE='a020c6c3bd0d51bd50319fbe6924826979fec0b11cdd0e9db8457c132c136092'
SMALL_SUFFIXES={'.json','.xml','.log','.txt','.py','.h','.cc','.cpp','.cuh','.cu','.patch','.cmd','.rsp','.d'}


def read(path):return json.loads(Path(path).read_text(encoding='utf-8-sig'))
def resolve(path):
    path=Path(path);return path.resolve()if path.is_absolute()else(R/path).resolve()
def identity(path):
    path=resolve(path);sha=hashlib.sha256()
    with path.open('rb')as stream:
        for raw in iter(lambda:stream.read(1048576),b''):sha.update(raw)
    return dict(path=path.relative_to(R).as_posix(),bytes=path.stat().st_size,sha256=sha.hexdigest())
def require(info,path=None):
    actual=identity(path or info['path'])
    if resolve(info['path'])!=resolve(actual['path'])or any(actual[k]!=info[k]for k in('bytes','sha256')):
        raise ValueError('Recorded metadata/source identity differs: '+str(info['path']))
    return actual
def integer(properties,key,minimum=0):
    value=int(properties[key])
    if value<minimum:raise ValueError('Invalid actual property '+key)
    return value


class Archive:
    def __init__(self,source_roots):self.files={};self.sources={};self.source_roots=source_roots
    def add(self,path,arc=None):
        path=resolve(path)
        if not path.is_relative_to(R)or not path.is_file():raise ValueError('Archive file outside repository or absent: '+str(path))
        if path.suffix.lower()not in SMALL_SUFFIXES and path.name!='catalog.bin':
            raise ValueError('Body/binary/SDK files are not archive inputs: '+str(path))
        if path.name=='catalog.bin'and path.stat().st_size>65536:raise ValueError('Unexpected large catalog')
        name=arc or path.relative_to(R).as_posix()
        if name in self.files and self.files[name]!=path:raise ValueError('Conflicting archive path '+name)
        self.files[name]=path
    def metadata_tree(self,directory):
        directory=resolve(directory)
        if not directory.is_dir():return
        for path in directory.rglob('*'):
            if path.is_file()and path.suffix.lower()in{'.json','.xml','.log','.txt','.py','.patch','.cmd','.rsp'}:
                if path.name!='CMakeCache.txt':self.add(path)
    def source(self,info,record_path):
        original=resolve(info['path'])
        if not original.is_relative_to(R):return
        relative=original.relative_to(R)
        if relative.parts[0]not in('src','include','tests','third_party')and not original.is_relative_to(S/'generated'):return
        key=(relative.as_posix(),info['sha256'])
        if key in self.sources:return
        candidates=[original]
        for parent in list(resolve(record_path).parents)[:4]:candidates+=[parent/'source'/relative,parent/'source'/original.name]
        for root in self.source_roots:candidates+=[root/relative,root/original.name]
        actual=None
        for path in candidates:
            if path.is_file()and path.stat().st_size==info['bytes']and identity(path)['sha256']==info['sha256']:
                actual=path;break
        if actual is None:
            raise ValueError('Exact compiled bytes unavailable; provide --source-root, never substitute changed live source: '+str(original))
        archive_path='compiled-sources/'+info['sha256']+'/'+relative.as_posix()
        self.add(actual,archive_path)
        self.sources[key]=dict(original_path=relative.as_posix(),compiled_sha256=info['sha256'],
            bytes=info['bytes'],archive_path=archive_path,actual_copy=identity(actual))


def completed_run(backend,attempt,archive):
    folder=Q/f'checks{attempt}-{backend}'
    process=read(folder/'run/process.json');summary=read(folder/'summary.json');driver=read(folder/'frontier.driver.json');plan=read(folder/'plan.json')
    if process['exit']!=0 or process.get('timed_out')is not False:raise ValueError('Selected native process did not pass: '+str(folder))
    if driver.get('exit')!=0 or driver['native'].get('exit')!=0 or driver['native'].get('stopped_by_driver')is not False:
        raise ValueError('Native driver incomplete/failed/stopped: '+str(folder))
    if driver.get('job_cleanup',{}).get('remaining_descendants')!=0:raise ValueError('Owned descendants were not retired')
    if any(item.get('exit')!=0 or item.get('stopped_by_driver',False)for item in driver['fetches']):
        raise ValueError('A supply process is unfinished/failed/stopped')
    expected='GlmMtpStateConsumer.'+backend.title()+'QuarkOriginalTarget43And44AndNextNFullVocabularyVerifier'
    tree=ET.parse(folder/'results.xml').getroot();cases=list(tree.iter('testcase'))
    if len(cases)!=1 or any(int(tree.get(key,'0'))for key in('failures','errors','disabled'))or list(tree.iter('skipped')):
        raise ValueError('Exactly one completed, unskipped passing case is required')
    case=cases[0]
    if case.get('classname')+'.'+case.get('name')!=expected or summary['case']!=expected or summary['tests']!=1 or summary['failures']or summary['skips']:
        raise ValueError('Actual Q30 CPU/CUDA case differs')
    properties={row.get('name'):row.get('value')for row in case.iter('property')}
    if summary['properties']!=properties:raise ValueError('Summary properties differ from actual XML')
    if(properties['artifact_repository'],properties['artifact_revision'])!=(REPO,REV):raise ValueError('Actual artifact identity differs')
    graphs=integer(properties,'actual_submissions',1)
    if integer(properties,'target_full_vocabulary')!=154880 or integer(properties,'target_first_full_reference_values')!=309760:
        raise ValueError('Actual R2 full-vocabulary verification did not cover the required vocabulary')
    if integer(properties,'peak_state_backing_bytes')>integer(properties,'state_budget_bytes'):raise ValueError('Actual state budget exceeded')
    for key in('actual_pending_embedding_feedback_checks','accepted_zero_draft_checkpoints','accepted_one_draft_checkpoints',
        'controlled_matching_trials','controlled_rejection_trials','target_submissions','target43_submissions','target_verifier_submissions'):
        integer(properties,key,1)
    if integer(properties,'natural_k1_trials')!=1 or integer(properties,'natural_k1_accepted_drafts')not in(0,1):
        raise ValueError('Keep one actual natural trial separate from controlled prefixes')
    image_dir=resolve(plan['image_directory']);ready=read(image_dir/'ready.json')
    # The loader validated parameters and the runner validated image bytes.
    # Recheck image extent only; no body/image/SDK rehash is needed here.
    image=resolve(ready['image']['path'])
    if image.stat().st_size!=ready['image']['bytes']or plan['image']!=ready['image']or resolve(driver['native']['command'][0])!=image:
        raise ValueError('Actual native image identity/command differs')
    require(ready['runtime_environment'],image_dir/'runtime-environment.json');runtime=read(image_dir/'runtime-environment.json')
    if len(runtime['staged_dlls'])!=1 or runtime['staged_dlls'][0]['sha256']!=CORRECT_MODULE:
        raise ValueError('Only the corrected same-owning mixed CPU module is valid')
    if resolve(runtime['staged_dlls'][0]['path']).stat().st_size!=runtime['staged_dlls'][0]['bytes']:raise ValueError('Native module extent differs')
    if '--gtest_throw_on_failure=1'not in driver['native']['command']:raise ValueError('Numerical failure must stop before another frontier')
    archive.metadata_tree(folder)
    for path in(image_dir/'ready.json',image_dir/'runtime-environment.json'):archive.add(path)
    return dict(backend=backend.upper(),case=expected,tests=1,failures=0,skips=0,
        graph_submissions=graphs,properties=properties,image=ready['image'],runtime=identity(image_dir/'runtime-environment.json'),
        driver=identity(folder/'frontier.driver.json'),XML=identity(folder/'results.xml'),process=identity(folder/'run/process.json'),
        summary=identity(folder/'summary.json'),consumer_record=ready['consumer_record'],link_plan=ready['link_plan']),driver


def parameter_set(directory,plan_path,archive,count=None,global_id=None):
    manifest=read(directory/'manifest.json');receipt=read(directory/'acquisition.json');plan=read(plan_path)
    if manifest.get('complete')is not True or receipt.get('complete')is not True:raise ValueError('Original set is not complete: '+str(directory))
    if(manifest['repository'],manifest['revision'])!=(REPO,REV)or(receipt['repository'],receipt['revision'])!=(REPO,REV):raise ValueError('Parameter identity differs')
    require(manifest['source_plan'],plan_path);require(manifest['source_receipt'],directory/'acquisition.json')
    if receipt['source_plan_sha256']!=identity(plan_path)['sha256']or receipt.get('whole_shard_downloaded')is not False:
        raise ValueError('Expected selected exact ranges, not a whole shard')
    expected=[row for row in plan['roles']if global_id is None or row.get('global_id')==global_id]
    if count is not None and len(expected)!=count:raise ValueError('Original physical role count differs')
    if receipt['selected_names']!=[row['name']for row in expected]or len(manifest['roles'])!=len(receipt['roles'])or len(expected)!=len(manifest['roles']):
        raise ValueError('Actual role order/count differs from original source plan')
    if not(len(expected)==manifest['original_roles']==receipt['original_roles']):raise ValueError('Actual declared physical role count differs')
    total=sum(row['bytes']for row in expected)
    if not(manifest['source_bytes']==receipt['expected_role_payload_bytes']==receipt['role_payload_bytes']==total):raise ValueError('Original payload byte sum differs')
    for wanted,actual,published in zip(expected,receipt['roles'],manifest['roles'],strict=True):
        if actual.get('complete')is not True or any(actual[key]!=value for key,value in wanted.items()):raise ValueError('Acquisition role differs from original plan')
        if(published['name'],published['file'],published['dtype'],published['shape'],published['bytes'],published['sha256'])!=(
            wanted['name'],wanted['filename'],wanted['dtype'],wanted['shape'],wanted['bytes'],actual['payload']['sha256']):raise ValueError('Actual manifest role differs')
        payload=(directory/published['file']).resolve()
        if payload.parent!=directory.resolve()or resolve(actual['payload']['path'])!=payload or payload.stat().st_size!=wanted['bytes']:
            raise ValueError('Original loose payload extent/path differs')
        if actual['payload']['bytes']!=wanted['bytes']:raise ValueError('Original payload receipt extent differs')
        if not re.fullmatch('[0-9a-f]{64}',published['sha256']):raise ValueError('Actual SHA pin absent')
        offset=0
        for chunk in actual['chunks']:
            if chunk['offset']!=offset or not 0<chunk['bytes']<=134217728 or not re.fullmatch('[0-9a-f]{64}',chunk['sha256']):raise ValueError('Authenticated resume coverage differs')
            first=wanted['absolute_inclusive'][0]+offset
            if chunk['absolute_range_inclusive']!=[first,first+chunk['bytes']-1]:raise ValueError('Resume chunk original range differs')
            offset+=chunk['bytes']
        if offset!=wanted['bytes']:raise ValueError('Incomplete original payload coverage')
    archive.add(directory/'manifest.json');archive.add(directory/'acquisition.json');archive.add(plan_path)
    return dict(original_roles=len(expected),source_bytes=total,manifest=identity(directory/'manifest.json'),
        acquisition=identity(directory/'acquisition.json'),source_plan=identity(plan_path),body_rehashed=False,
        roles=[dict(name=row['name'],dtype=row['dtype'],shape=row['shape'],bytes=row['bytes'],sha256=row['sha256'])for row in manifest['roles']])


def compiled_closure(executions,archive):
    records={};links={}
    for execution in executions:
        path=resolve(execution['link_plan']['path']);require(execution['link_plan'],path);links[str(path)]=identity(path);archive.add(path)
        plan=read(path);record_path=resolve(execution['consumer_record']['path']);require(execution['consumer_record'],record_path)
        records[str(record_path)]=record_path
        if 'host_records' in plan:
            manifest_path=resolve(plan['host_records']['path']);require(plan['host_records'],manifest_path)
            archive.add(manifest_path);manifest=read(manifest_path)
            selected=manifest['records']
            if (manifest['count']!=len(selected)or plan['current_host_count']!=len(selected)or
                len({str(resolve(item['path']))for item in selected})!=len(selected)):
                raise ValueError('Current host-record manifest count/identity differs')
            for item in selected:
                require(item);candidate=resolve(item['path']);records[str(candidate)]=candidate
        else:
            for directory in(Q/'host1/records',Q/'support1/records'):
                for candidate in directory.glob('*/identity.json'):records[str(candidate)]=candidate
            for item in plan['reused_current_records']:
                require(item);candidate=resolve(item['path']);records[str(candidate)]=candidate
    for path in records.values():
        record=read(path);archive.add(path)
        for info in(record['source'],*record['dependencies']):archive.source(info,path)
        for candidate in(path.parent/'plan.json',path.parent/'run/command.json',path.parent/'run/process.json',
            path.parent/'run/stdout.log',path.parent/'run/stderr.log',path.parent/'compile.command.json',
            path.parent/'compile.result.json',path.parent/'compile.stdout.log',path.parent/'compile.stderr.log'):
            if candidate.is_file():archive.add(candidate)
    for directory in(Q/'mixed-native-preparation',Q/'native-mixed1'):
        archive.metadata_tree(directory)
    for path in Q.glob('*.json'):archive.add(path)
    for path in Q.glob('*.cmd'):archive.add(path)
    return dict(consumer_records=[entry['consumer_record']for entry in executions],links=list(links.values()),
        actual_host_records=len(records),compiled_source_versions=len(archive.sources),source_manifest=list(archive.sources.values()),
        native_family_correction=identity(D/'mtp-cpu-native-family-2026-10-24.json'),
        scope='Actual current Q30 Graph/provider host closure plus one Flash consumer; corrected own-family mixed CPU module. Native build counts remain the recorded history, not a new build by the publisher.')


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--cpu-run',type=int,default=2);parser.add_argument('--cuda-run',type=int,required=True)
    parser.add_argument('--source-root',type=Path,action='append',default=[],help='Optional exact archived repo source root if a compiled live dependency has since changed')
    args=parser.parse_args()
    if min(args.cpu_run,args.cuda_run)<=0:raise ValueError('Positive actual run attempts required')
    destination=D/(NAME+'.json');archive_path=D/(NAME+'.zip')
    if destination.exists()or archive_path.exists():raise ValueError('Published evidence already exists; preserve it')
    archive=Archive([path.resolve()for path in args.source_root]);executions=[];drivers=[]
    for backend,attempt in(('cpu',args.cpu_run),('cuda',args.cuda_run)):
        execution,driver=completed_run(backend,attempt,archive);executions.append(execution);drivers.append(driver)
    static={}
    for section,directory,plan,count in(('nextn',S/'original-static',S/'static-plan.json',34),
        ('target43',S/'original-target43/static',S/'target43-static-plan.json',34),
        ('target44',S/'original-target44/static',S/'target44-static-plan.json',32)):
        static[section]=parameter_set(directory,plan,archive,count)
        key=('nextn'if section=='nextn'else section)+'_static_manifest_sha256'
        if any(row['properties'][key]!=static[section]['manifest']['sha256']for row in executions):raise ValueError('Actual native pins differ from physical static manifests')
        header=S/'generated'/('q30_'+section+'_static_pins.h');text=header.read_text('utf-8')
        if 'kManifestSha256="'+static[section]['manifest']['sha256']+'"'not in text:raise ValueError('Generated static header pin differs')
        archive.add(header)
    if sum(row['original_roles']for row in static.values())!=100 or sum(row['source_bytes']for row in static.values())!=3240744240:
        raise ValueError('Q30 own static100/3240744240 contract differs')
    history=[];requests={section:[]for section in static}
    for folder in sorted(Q.glob('checks*-*')):
        if not folder.is_dir():continue
        archive.metadata_tree(folder)
        path=folder/'frontier.driver.json'
        if path.is_file():
            driver=read(path);history.append(dict(driver=identity(path),exit=driver.get('exit'),native=driver.get('native'),selected_for_publication=any(row['driver']['path']==identity(path)['path']for row in executions)))
            for item in driver.get('fetches',[]):
                request=item['request'];section=request['section']
                if section not in requests or request['repository']!=REPO or request['revision']!=REV or request['stage']!=0:
                    raise ValueError('Recorded actual frontier artifact/section differs')
                requests[section].append(dict(request=request,driver=identity(path),fetch_exit=item.get('exit')))
    experts={};frontiers={}
    for section,directory,plan in(('nextn',S/'original-experts',S/'expert-source-plan.json'),
        ('target43',S/'original-target43/experts',S/'target43-expert-source-plan.json'),
        ('target44',S/'original-target44/experts',S/'target44-expert-source-plan.json')):
        experts[section]=[]
        for folder in sorted(directory.glob('expert[0-9][0-9][0-9]')):
            if not(folder/'manifest.json').is_file():continue
            global_id=int(folder.name[6:]);value=parameter_set(folder,plan,archive,6,global_id)
            value.update(global_id=global_id,requested_by=[item['driver']for item in requests[section]if global_id in item['request']['missing_ids']])
            experts[section].append(value)
        frontiers[section]=dict(requests=requests[section],global_ids_seen=sorted({n for row in requests[section]for n in row['request']['global_ids']}),
            missing_ids_supplied=sorted({n for row in requests[section]for n in row['request']['missing_ids']if row['fetch_exit']==0}),
            complete_cached_sets=len(experts[section]),complete_cached_payload_bytes=sum(row['source_bytes']for row in experts[section]))
    for path in S.glob('*.py'):archive.add(path)
    for path in S.glob('*.json'):archive.add(path)
    for path in(S/'generated').glob('*.h'):archive.add(path)
    for directory in(S/'batches',S/'frontier-plans',S/'metadata',S/'headers',Q/'run-helper-update'):
        archive.metadata_tree(directory)
    archive.metadata_tree(Q/'consumer1/records/flash-state')
    for path in(Q/'run_original.py',Q/'run_host.py',Q/'run_link.py',Q/'prepare_commands.py',Q/'prepare_image.py',
        R/'.scratch/dspark-pro-target-draft-20261023/run_with_supply.py'):
        if path.is_file():archive.add(path)
    for stage in('tests-link1','tests-link2'):
        for name in('ready.json','runtime-environment.json'):
            path=Q/stage/name
            if path.is_file():archive.add(path)
    correction=D/'mtp-cpu-native-family-2026-10-24.json';archive.add(correction)
    build=compiled_closure(executions,archive)
    record=dict(created_at=datetime.now(timezone.utc).isoformat(),identity=dict(id='Q30',repository=REPO,revision=REV),
        status='Completed finite original-role CPU/CUDA target43/44 + NextN45 full-vocabulary K1 verification',
        validation=dict(cases=len(executions),failures=0,skips=0,graph_submissions=sum(row['graph_submissions']for row in executions),executions=executions),
        original_static=dict(roles=100,source_bytes=3240744240,sections=static),selected_expert_sets=experts,actual_frontiers=frontiers,
        expert_accounting='Six original planes per authenticated per-ID set. Cache totals include earlier failed-attempt frontiers and are not claimed to equal the successful-run active expert union; all observed requests retain their actual source run.',
        build=build,attempt_history=history,
        corrected_runtime=dict(proof=identity(correction),wrong_family_attempt='graph-integration-preparation/checks1-cpu',
            change='Same executable/model/reference; corrected owning mixed AVX2 module. No model compensation or numerical tolerance change.'),
        scope='Own Q30 raw source identity for target43 HC/MLA/indexer, target44 HC/KDA/conv/finalnorm, NextN45 and original full154880 head/embedding. Same ordinary Graph/Invocation and StateHead accepted-prefix/catchup workflow.',
        limits=['Upstream layer42 fourstream and finite initial histories remain fixtures; this is not a complete trained target engine or task-quality result.',
            'Single natural K1 trial and separate matching/rejection controls are policy checks, not a natural acceptance-rate benchmark.',
            'Original E4 attention/projection and E2M1/UE8M0 group32 target-MoE boundaries remain distinct. Recorded generic logical schema/source-byte properties are preserved verbatim; physical acquisition is the explicit static/per-ID manifest accounting above.',
            'Cached parameter extent and StateHead budget properties are not physical CPU/GPU memory samples. No TPS, load-speed, full-model quality, or all-platform claim.',
            'Repository source copies in compiled-sources match each actual compiler dependency SHA. Other current preparation helper files are archive context, not asserted to have been the byte-exact script used by an older run.'],
        weight_bodies_rehashed=False,whole_expert_bank_requests=False,
        complete_domain_cached={section:len(values)==288 for section,values in experts.items()},
        whole_original_model=False,throughput_evidence=False,memory_evidence=False)
    # All guards run before either public output is created.
    with zipfile.ZipFile(archive_path,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6)as output:
        for name,path in sorted(archive.files.items()):output.write(path,name)
        output.writestr('compiled-source-manifest.json',json.dumps(list(archive.sources.values()),indent=2)+'\n')
    record.update(archive=identity(archive_path),archived_files=len(archive.files)+1)
    destination.write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(dict(evidence=identity(destination),archive=identity(archive_path),graphs=record['validation']['graph_submissions'])))


if __name__=='__main__':main()
