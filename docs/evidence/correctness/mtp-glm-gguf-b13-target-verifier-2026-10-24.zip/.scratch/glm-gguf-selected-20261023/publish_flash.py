"""Publish completed B12/B13 finite runs; metadata/source only, never fetch/build/run."""
import argparse
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import struct
import sys
import xml.etree.ElementTree as ET
import zipfile

sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
R = S.parents[1]
D = R / 'docs/evidence/correctness'
ARCHIVE_TOOL = R / '.scratch/glm-quark-selected-20261024/Q30/publish.py'
ARCHIVE_SHA = 'aff6d102813826e91729249d0ff6cea1ec6fe45c030abbeb99980f0ff0a2cda5'
CONTRACTS = {
    'B12': ('unsloth/GLM-5.3-Flash-GGUF', '621d456e93e926e4b52f85cff5f634358c1828f9', 'UD-Q4_K_XL'),
    'B13': ('unsloth/GLM-5.3-Flash-GGUF', '621d456e93e926e4b52f85cff5f634358c1828f9', 'Q8_0'),
}


def read(path): return json.loads(Path(path).read_text(encoding='utf-8-sig'))
def resolve(path): return (Path(path) if Path(path).is_absolute() else R / path).resolve()
def identity(path):
    path = resolve(path)
    if path.stat().st_size > 16_777_216: raise ValueError('Only small source/metadata may be hashed: ' + str(path))
    raw = path.read_bytes()
    return dict(path=path.relative_to(R).as_posix(), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())
def require(info, path=None):
    actual = identity(path or info['path'])
    if resolve(actual['path']) != resolve(info['path']) or any(actual[k] != info[k] for k in ('bytes', 'sha256')):
        raise ValueError('Recorded metadata identity differs: ' + info['path'])
    return actual
def sha(value):
    if not isinstance(value, str) or not re.fullmatch('[0-9a-f]{64}', value): raise ValueError('Actual SHA pin is missing')
    return value
def extent(info):
    path = resolve(info['path'])
    if path.stat().st_size != info['bytes']: raise ValueError('Recorded payload/object/image extent differs: ' + str(path))
    sha(info['sha256'])
def integer(p, key, minimum=0):
    value = int(p[key])
    if value < minimum: raise ValueError('Actual property below required bound: ' + key)
    return value
def same_identity(data, contract):
    if tuple(data.get(k) for k in ('repository', 'revision', 'variant')) != contract:
        raise ValueError('Original artifact identity differs')
def chunk_coverage(chunks, total, ranges):
    offset = 0
    for row in chunks:
        n = row['bytes']; sha(row['sha256'])
        if row['offset'] != offset or not 0 < n <= 134_217_728: raise ValueError('Authenticated chunk gap/extent')
        expected = ranges(offset, n)
        actual = row.get('absolute_range_inclusive', row.get('absolute_inclusive'))
        if actual != expected: raise ValueError('Authenticated chunk original range differs')
        offset += n
    if offset != total: raise ValueError('Authenticated payload coverage incomplete')


def vocabulary(a):
    roles = {row['name']: row for row in read(a / 'static-plan.json')['roles']}
    shapes = [roles[name]['gguf_dimensions'] for name in ('output.weight', 'token_embd.weight')]
    if any(len(shape) != 2 or shape[0] != 4096 or shape[1] != 154880 for shape in shapes):
        raise ValueError('Own original embedding/head vocabulary geometry differs')
    return shapes[0][1]


def static_set(a, contract, archive):
    plan = read(a / 'static-plan.json'); receipt = read(a / 'original-static/acquisition.json')
    manifest = read(a / 'original-static/manifest.json'); pins_path = a / f'generated/glm_gguf_{a.name.lower()}_artifacts.json'
    pins = read(pins_path)
    for value in (plan, receipt, manifest, pins): same_identity(value, contract)
    if any(value.get('complete') is not True for value in (receipt, manifest, pins)): raise ValueError('Actual static pins/receipt incomplete')
    if receipt['whole_shard_downloaded'] is not False or receipt['selected_only'] is not True: raise ValueError('Only selected ranges are accepted')
    for value in (receipt, manifest): require(value['source_plan'], a / 'static-plan.json')
    require(manifest['acquisition'], a / 'original-static/acquisition.json')
    for key in ('static_plan', 'expert_source_plan', 'fixture_policy', 'acquisition', 'manifest', 'generated_header', 'generator', 'common_generator', 'validator'):
        require(pins[key]); archive.add(resolve(pins[key]['path']))
    if any(value['original_roles'] != 85 for value in (receipt, manifest, pins)) or len(plan['roles']) != 85 or len(manifest['roles']) != 85 or len(receipt['roles']) != 85:
        raise ValueError('Expected 85 actual static roles')
    total = sum(row['bytes'] for row in plan['roles'])
    if total != 1_892_821_552 or not (manifest['source_bytes'] == pins['source_bytes'] == receipt['expected_role_payload_bytes'] == receipt['role_payload_bytes'] == total):
        raise ValueError('Actual static extent differs')
    for wanted, got, published in zip(plan['roles'], receipt['roles'], manifest['roles'], strict=True):
        if got.get('complete') is not True or any(got[k] != v for k, v in wanted.items()): raise ValueError('Static receipt is not its planned original role')
        if any(published[k] != wanted[k] for k in ('name', 'dtype', 'dtype_code', 'gguf_dimensions', 'bytes')) or published['file'] != wanted['filename']:
            raise ValueError('Static manifest schema differs')
        if published['sha256'] != got['payload']['sha256']: raise ValueError('Static actual byte pins differ')
        payload = (a / 'original-static' / published['file']).resolve()
        if payload.parent != (a / 'original-static').resolve() or resolve(got['payload']['path']) != payload: raise ValueError('Static payload path differs')
        extent(got['payload'])
        chunk_coverage(got['chunks'], wanted['bytes'], lambda o, n: [wanted['absolute_inclusive'][0] + o, wanted['absolute_inclusive'][0] + o + n - 1])
    for path in (a / 'static-plan.json', a / 'roles-plan.json', a / 'roles-schema.json', pins_path): archive.add(path)
    for header in pins['original_headers']: require(header)  # Small original headers, never tensor bodies.
    archive.metadata_tree(a / 'headers')
    return dict(roles=85, bytes=total, vocabulary=vocabulary(a), manifest=identity(a / 'original-static/manifest.json'),
                acquisition=identity(a / 'original-static/acquisition.json'), pins=identity(pins_path), body_rehashed=False)


def completed_run(a, backend, attempt, ready, archive, contract):
    folder = a / f'native-integration/checks{attempt}-{backend}'
    summary = read(folder / 'summary.json'); process = read(folder / 'run/process.json')
    driver = read(folder / 'frontier.driver.json'); plan = read(folder / 'plan.json')
    if summary.get('passed') is not True or process['exit'] != 0 or process.get('timed_out') is not False or summary['process'] != process:
        raise ValueError('Selected run is not an actual terminal pass')
    if driver.get('exit') != 0 or driver['native'].get('exit') != 0 or driver['native'].get('stopped_by_driver') is not False or driver.get('error'):
        raise ValueError('Native/supply driver failed, incomplete or stopped')
    if driver.get('job_cleanup', {}).get('remaining_descendants') != 0: raise ValueError('Owned native tree did not retire')
    if any(row.get('exit') != 0 or row.get('stopped_by_driver', False) for row in driver['fetches']): raise ValueError('Supply fetch did not finish successfully')
    expected = f'GlmMtpStateConsumer.{backend.title()}{a.name}OriginalGgufTarget43And44AndNextNFullVocabularyVerifier'
    tree = ET.parse(folder / 'results.xml').getroot(); cases = list(tree.iter('testcase'))
    if len(cases) != 1 or any(int(tree.get(k, '0')) for k in ('failures', 'errors', 'disabled')) or list(tree.iter('failure')) or list(tree.iter('skipped')):
        raise ValueError('Exactly one actual passing unskipped case is required per backend')
    case = cases[0]
    if case.get('classname') + '.' + case.get('name') != expected or case.get('status') != 'run' or case.get('result') != 'completed' or summary['case'] != expected:
        raise ValueError('Selected exact original-artifact case differs')
    p = {row.get('name'): row.get('value') for row in case.iter('property')}
    if summary['tests'] != 1 or summary['failures'] or summary['skips'] or summary['properties'] != p: raise ValueError('Summary/XML facts differ')
    if tuple(p[k] for k in ('artifact_repository', 'artifact_revision', 'artifact_variant')) != contract: raise ValueError('Actual native source identity differs')
    if any(p[k] != v for k, v in dict(static_original_roles='85', static_original_bytes='1892821552', expert_domain='288', resident_experts='8', expert_planes='3').items()):
        raise ValueError('Actual source/schema properties differ')
    for key, file in (('static_source_plan_sha256', 'static-plan.json'), ('expert_source_plan_sha256', 'expert-source-plan.json')):
        if p[key] != identity(a / file)['sha256']: raise ValueError('Native used different original-source plan pins')
    graphs = integer(p, 'actual_submissions', 1)
    if summary['actual_graph_submissions'] != graphs or integer(p, 'target_full_f64_scores') != 2 * vocabulary(a):
        raise ValueError('Actual graph/full-vocabulary counts differ')
    for key in ('target43_calls', 'target44_calls', 'verifier_calls', 'accepted_target_conditioned_repairs',
                'controlled_match_trials', 'controlled_reject_trials', 'actual_selected_original_experts', 'actual_selected_original_bytes'):
        integer(p, key, 1)
    for key, expected_count in (('component_resources', 32), ('nextn_resources', 16), ('target43_resources', 12)):
        if integer(p, key) != expected_count: raise ValueError('Actual converted GGUF component resources differ: ' + key)
    if integer(p, 'natural_trials') != 1 or integer(p, 'natural_accepted_drafts') not in (0, 1) or integer(p, 'peak_state_backing_bytes') > integer(p, 'state_budget_bytes'):
        raise ValueError('Natural/control or state-budget boundary differs')
    if summary['image'] != ready['image'] or plan['image'] != ready['image'] or plan['consumer_record'] != ready['consumer_record'] or summary['consumer_record'] != ready['consumer_record']:
        raise ValueError('Run and linked consumer/image identities differ')
    if resolve(driver['native']['command'][0]) != resolve(ready['image']['path']) or '--gtest_filter=' + expected not in driver['native']['command'] or '--gtest_throw_on_failure=1' not in driver['native']['command']:
        raise ValueError('Owned native command does not select the exact checked case')
    for key in ('entry', 'owned_entry'): require(plan[key]); archive.add(resolve(plan[key]['path']))
    archive.metadata_tree(folder)
    return dict(backend=backend.upper(), case=expected, graph_submissions=graphs, properties=p,
                image=ready['image'], summary=identity(folder / 'summary.json'), XML=identity(folder / 'results.xml'),
                driver=identity(folder / 'frontier.driver.json'), process=identity(folder / 'run/process.json')), driver


def expert_sets(a, contract, drivers, archive):
    expert = read(a / 'expert-source-plan.json'); same_identity(expert, contract)
    if expert['full_expert_banks_acquire'] is not False or expert['whole_bank_sha256_required'] is not False: raise ValueError('Unexpected whole expert bank acquisition')
    expected_pin = identity(a / 'expert-source-plan.json')['sha256']; cached = {}; requests = []
    for driver in drivers:
        for fetch in driver['fetches']:
            request = fetch['request']; section = request['section']
            if section not in ('nextn', 'target43', 'target44') or request['stage'] != 0: raise ValueError('Actual frontier section differs')
            if not set(request['missing_ids']) <= set(request['global_ids']) or any(type(n) is not int or not 0 <= n < 288 for n in request['global_ids']): raise ValueError('Actual frontier IDs differ')
            requests.append(dict(request=request, exit=fetch['exit']))
    for path in sorted((a / 'original-experts').glob('*/stage0/expert*/ready.json')):
        directory = path.parent; ready = read(path); section = ready['section']; ids = ready['global_ids']
        same_identity(ready, contract)
        if ready.get('complete') is not True or section not in expert['sections'] or ready['stage'] != 0 or len(ids) != 1 or not 0 <= ids[0] < 288 or ready['source_plan_sha256'] != expected_pin:
            raise ValueError('Expert immutable ready identity differs')
        if directory.name != f'expert{ids[0]:03d}' or directory.parent.parent.name != section: raise ValueError('Expert immutable directory differs')
        plan = read(directory / 'plan.json'); receipt = read(directory / 'acquisition.json'); same_identity(plan, contract)
        for key in ('plan', 'acquisition'): require(ready[key], directory / (key + '.json'))
        if receipt.get('complete') is not True or receipt['original_roles'] != 3 or receipt['section'] != section or receipt['stage'] != 0 or receipt['global_ids'] != ids:
            raise ValueError('Expert acquisition incomplete or mismatched')
        if receipt['source_plan_sha256'] != identity(directory / 'plan.json')['sha256'] or receipt['whole_shards_downloaded'] is not False or receipt['unrequested_bytes'] != 0:
            raise ValueError('Expert original bounded plan differs')
        require(plan['source_plan'], a / 'expert-source-plan.json'); require(receipt['typed_catalog'], directory / 'catalog.bin')
        total = expert['sections'][section]['per_id_payload_bytes']
        if not (plan['bundle_bytes'] == receipt['bundle_bytes'] == receipt['role_payload_bytes'] == total): raise ValueError('Expert payload extent differs')
        if ready['bundle'] != receipt['bundle']: raise ValueError('Ready/bundle byte pins differ')
        extent(receipt['bundle']); raw = (directory / 'catalog.bin').read_bytes()
        if len(raw) != 112 or ready['typed_catalog']['sha256'] != identity(directory / 'catalog.bin')['sha256']: raise ValueError('Typed expert catalog differs')
        magic, version, count, size, reserved, digest = struct.unpack('<8sIIQQ32s', raw[:64])
        if (magic, version, count, size, reserved, digest.hex()) != (b'HYDSPT01', 1, 3, total, 0, receipt['bundle']['sha256']): raise ValueError('Typed expert catalog body pin differs')
        banks = {row['name']: row for row in expert['roles'] if row['name'].startswith(f"blk.{expert['sections'][section]['layer']}.")}
        if len(plan['roles']) != 3 or [row['leg'] for row in plan['roles']] != ['gate', 'up', 'down']: raise ValueError('Three original expert legs required')
        for i, row in enumerate(plan['roles']):
            bank = banks[row['name']]; first = bank['absolute_inclusive'][0] + ids[0] * bank['expert_bytes']
            if row['dtype_code'] != bank['dtype_code'] or row['shape'] != bank['gguf_dimensions'][:2] or row['bytes'] != bank['expert_bytes'] or row['absolute_inclusive'] != [first, first + row['bytes'] - 1] or row['global_id'] != ids[0]:
                raise ValueError('Expert role no longer maps to its exact original bank slice')
            if struct.unpack_from('<QQ', raw, 64 + 16 * i) != (row['bundle_offset'], row['bytes']): raise ValueError('Expert catalog plane bounds differ')
        def original_range(offset, n):
            group = next((row for row in plan['groups'] if row['bundle_offset'] <= offset < row['bundle_offset'] + row['bytes']), None)
            if group is None or offset + n > group['bundle_offset'] + group['bytes']: raise ValueError('Expert chunk crosses original source legs')
            first = group['first'] + offset - group['bundle_offset']; return [first, first + n - 1]
        chunk_coverage(receipt['chunks'], total, original_range)
        archive.metadata_tree(directory); archive.add(directory / 'catalog.bin')
        cached[(section, ids[0])] = dict(section=section, global_id=ids[0], source_bytes=total, ready=identity(path), acquisition=identity(directory / 'acquisition.json'), plan=identity(directory / 'plan.json'), bundle=receipt['bundle'])
    if any((request['request']['section'], n) not in cached for request in requests for n in request['request']['missing_ids']): raise ValueError('A successful actual frontier lacks its immutable original expert receipt')
    archive.metadata_tree(a / 'original-experts')  # Keep incomplete earlier transport metadata, never its body.
    return dict(complete_cached_sets=list(cached.values()), actual_missing_frontiers=requests,
                cached_payload_bytes=sum(row['source_bytes'] for row in cached.values()), body_rehashed=False,
                accounting='Cache totals can include failed-attempt frontiers; they are not the claimed successful active-ID union. Native actual_selected properties remain verbatim.')


def b12_corrections(a, archive):
    diagnosis = a / 'native-integration/stack-diagnostic1/diagnosis.json'
    if not diagnosis.is_file(): return None
    files = dict(stack_diagnosis=diagnosis,
        heap_program_patch=a / 'stack-overflow-diagnosis/unique-program-proposal/source.patch',
        stack_frame=a / 'native-integration/tests-link4/verifier-stack-frame.json',
        storage_patch=a / 'storage-reference-proposal/source.patch',
        storage_applied=a / 'storage-reference-proposal/applied.json',
        storage_build=a / 'storage-reference-proposal/build-result.json')
    evidence = {key: identity(path) for key, path in files.items()}
    for path in files.values(): archive.add(path)
    crash = read(diagnosis); frame = read(files['stack_frame'])
    applied = read(files['storage_applied']); rebuilt = read(files['storage_build'])
    if crash['native_exit'] != 0xC00000FD or frame['stack_reserve'] != 1_048_576:
        raise ValueError('B12 historical stack diagnosis differs')
    if frame['before_stack_bytes'] != 750456 or frame['after_stack_bytes'] != 510728:
        raise ValueError('B12 heap-owned Program frame correction differs')
    if not (applied['applied'] and applied['math_same_unchanged'] and applied['all_inactive_rows_still_bit_checked']) or len(applied['storage_sites']) != 9:
        raise ValueError('B12 storage reference correction differs')
    if rebuilt['header'] != applied['after'] or rebuilt['compile_exit'] != 0 or rebuilt['link_exit'] != 0:
        raise ValueError('B12 storage reference was not actually rebuilt')
    return dict(historical_stack_failure=dict(run='checks1-cpu', passed=False,
        native_exit=0xC00000FD, cause='Large by-value prepared Program temporaries exhausted the unchanged 1MiB stack during oneDNN cold descriptor creation.',
        correction='Program::create returns an independently heap-owned Program; no stack-reserve increase.',
        before_frame_bytes=frame['before_stack_bytes'], after_frame_bytes=frame['after_stack_bytes'],
        diagnosis=evidence['stack_diagnosis'], patch=evidence['heap_program_patch'], frame=evidence['stack_frame']),
        historical_reference_failure=dict(run='checks2-cpu', passed=False, native_exit=3,
        cause='The arithmetic finite-value comparator rejected the first untouched poison-NaN main-cache row: index1051648, row2054, width512.',
        correction='Nine state copy/Scatter checks compare every storage bit, including inactive rows. Arithmetic finite-value and tolerance checks are unchanged.',
        patch=evidence['storage_patch'], applied=evidence['storage_applied'], build=evidence['storage_build']),
        current_execution='Only validation.executions records the selected final CPU/CUDA passes; these historical failures and compile/link facts are not passing executions.')


def main(artifact=None):
    parser = argparse.ArgumentParser(description=__doc__)
    if artifact is None: parser.add_argument('--artifact', choices=tuple(CONTRACTS), required=True)
    parser.add_argument('--cpu-run', type=int, required=True); parser.add_argument('--cuda-run', type=int, required=True)
    parser.add_argument('--link-attempt', type=int, default=2); parser.add_argument('--compile-attempt', type=int, default=1)
    parser.add_argument('--source-root', type=Path, action='append', default=[])
    args = parser.parse_args(); artifact = artifact or args.artifact; a = S / artifact; n = a / 'native-integration'; contract = CONTRACTS[artifact]
    if min(args.cpu_run, args.cuda_run, args.link_attempt, args.compile_attempt) <= 0: raise ValueError('Positive actual attempts required')
    if identity(ARCHIVE_TOOL)['sha256'] != ARCHIVE_SHA: raise ValueError('Frozen small Archive helper changed')
    spec = importlib.util.spec_from_file_location('_flash_publisher_archive', ARCHIVE_TOOL); tools = importlib.util.module_from_spec(spec); spec.loader.exec_module(tools)
    tools.S = a
    archive = tools.Archive([path.resolve() for path in args.source_root]); archive.add(Path(__file__)); archive.add(ARCHIVE_TOOL)
    static = static_set(a, contract, archive)
    image_dir = n / f'tests-link{args.link_attempt}'; ready = read(image_dir / 'ready.json')
    for key in ('link_plan', 'runtime_environment', 'consumer_record'): require(ready[key]); archive.add(resolve(ready[key]['path']))
    extent(ready['image']); link = read(image_dir / 'link-plan.json'); process = read(image_dir / 'link.result.json')
    if process['exit'] != 0 or process['command'] != link['command']: raise ValueError('Actual link did not complete successfully')
    if resolve(ready['consumer_record']['path']) != (n / f'compile{args.compile_attempt}/glm-pro/identity.json').resolve(): raise ValueError('Requested actual consumer attempt differs')
    compiled = read(resolve(ready['consumer_record']['path']))
    for key in ('entry', 'shared_helper'):
        if key in compiled: require(compiled[key]); archive.add(resolve(compiled[key]['path']))
    require(compiled['actual_pins'], a / f'generated/glm_gguf_{artifact.lower()}_artifacts.h')
    require(compiled['actual_pin_receipt'], a / f'generated/glm_gguf_{artifact.lower()}_artifacts.json')
    if resolve(compiled['actual_pin_receipt']['path']) != resolve(static['pins']['path']): raise ValueError('Compiled pins are not this actual static manifest')
    for key in ('static_plan', 'expert_plan', 'acquisition', 'manifest'): require(compiled['actual_static'][key])
    if not any(resolve(info['path']) == resolve(compiled['actual_pins']['path']) and info['sha256'] == compiled['actual_pins']['sha256'] for info in compiled['dependencies']):
        raise ValueError('Actual generated pins are absent from the emitted compiler dependencies')
    for info in (compiled['source'], *compiled['dependencies']): archive.source(info, resolve(ready['consumer_record']['path']))
    archive.metadata_tree(resolve(ready['consumer_record']['path']).parent)
    for info in link['retained_current_records']:
        require(info); archive.add(resolve(info['path']))  # Retained actual records, not a new host build.
    require(link['retained_native_inputs']); archive.add(resolve(link['retained_native_inputs']['path']))
    runtime = read(image_dir / 'runtime-environment.json')
    for info in runtime['staged_dlls']: extent(info)
    archive.metadata_tree(image_dir)
    executions, drivers = [], []
    for backend, attempt in (('cpu', args.cpu_run), ('cuda', args.cuda_run)):
        execution, driver = completed_run(a, backend, attempt, ready, archive, contract); executions.append(execution); drivers.append(driver)
    experts = expert_sets(a, contract, drivers, archive)
    for path in a.glob('*.py'): archive.add(path)
    for path in n.glob('*.py'): archive.add(path)
    common_driver = R / '.scratch/dspark-pro-target-draft-20261023/run_with_supply.py'
    if identity(common_driver)['sha256'] != 'd3e0749a5b565717582ff33f9f02251faae5309c71b693abfd3a6e8b880be50a':
        raise ValueError('Actual owned-process driver source changed; preserve the run version')
    archive.add(common_driver)
    for path in (S / 'acquire_flash.py', S / 'generate_flash_artifacts.py', S / 'B09/acquire.py', S / 'B09/generate_artifacts.py'):
        archive.add(path)
    for directory in (a / 'frontier-plans', a / 'batches', n / 'tests-link1'): archive.metadata_tree(directory)
    history = []
    for folder in sorted(n.glob('checks*-*')):
        archive.metadata_tree(folder)
        path = folder / 'summary.json'
        if path.is_file(): history.append(dict(summary=identity(path), passed=read(path).get('passed'), selected_for_publication=any(row['summary'] == identity(path) for row in executions)))
    shared = []
    for name in ('mtp-cpu-native-family-2026-10-24', 'mtp-gdn-output-scale-2026-10-24', 'mtp-batched-f32-bfloat-linear-2026-10-24', 'mtp-packed-mmvq-tail-integration-2026-10-24', 'mtp-gguf-binding-gaps-2026-10-24'):
        path = D / (name + '.json'); archive.add(path); shared.append(identity(path))
    failure = n / 'tests-link1/link.not-started.json'
    not_started = identity(failure) if failure.is_file() else None
    if not_started and read(failure)['failed_before_linker_start'] is not True: raise ValueError('Keep historical link-preparation failure truthful')
    corrections = b12_corrections(a, archive) if artifact == 'B12' else None
    name = f'mtp-glm-gguf-{artifact.lower()}-target-verifier-2026-10-24'; destination = D / (name + '.json'); output = D / (name + '.zip')
    if destination.exists() or output.exists(): raise ValueError('Do not overwrite published evidence')
    total = sum(path.stat().st_size for path in archive.files.values())
    if total > 67_108_864 or any(path.stat().st_size > 16_777_216 for path in archive.files.values()): raise ValueError('Archive must stay a finite source/metadata subset')
    record = dict(created_at=datetime.now(timezone.utc).isoformat(), identity=dict(id=artifact, repository=contract[0], revision=contract[1], variant=contract[2]),
        status='Completed finite own target43/44 + NextN45 CPU/CUDA full-vocabulary K1 execution',
        validation=dict(cases=2, failures=0, skips=0, graph_submissions=sum(row['graph_submissions'] for row in executions), executions=executions),
        original_static=static, selected_expert_acquisition=experts, attempt_history=history,
        build=dict(consumer_record=ready['consumer_record'], link_plan=ready['link_plan'], runtime=ready['runtime_environment'], image=ready['image'],
                   retained_host_records=len(link['retained_current_records']), fresh_consumer_TUs=1, fresh_product_TUs=0, SDK_builds=0, NVCC_builds=0,
                   compiled_source_manifest=list(archive.sources.values()), shared_proofs=shared, link_preparation_failure=not_started),
        scope='Own authenticated 85 static roles and original packed selected experts for target43, target44 and NextN45; same ordinary Graph/Invocation and accepted-prefix controller with 16 draft, 12 target43 and 4 target44 state resources plus Epoch.',
        limits=['Layer42 upstream fourstream and finite initial histories remain fixtures; this is not a complete trained target engine or task-quality result.',
                'Single natural K1 trial and separate controlled match/rejection checks do not measure natural acceptance rate.',
                'Per-run properties are preserved verbatim; generic legacy logical role counters are not substituted for this artifact physical85-role acquisition.',
                'Logical parameter/state budgets are not measured physical memory peaks. No TPS, full-model, or all-platform claim.'],
        whole_original_model=False, throughput_evidence=False, memory_evidence=False, weight_bodies_rehashed=False, scope_or_progress_updated=False)
    if corrections is not None: record['corrections'] = corrections
    # Everything above is read-only validation. Public outputs begin only after both actual passes.
    with zipfile.ZipFile(output, 'x', zipfile.ZIP_DEFLATED, compresslevel=6) as target:
        for entry, path in sorted(archive.files.items()): target.write(path, entry)
        target.writestr('compiled-source-manifest.json', json.dumps(list(archive.sources.values()), indent=2) + '\n')
    record.update(archive=identity(output), archived_files=len(archive.files) + 1)
    destination.write_text(json.dumps(record, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(dict(evidence=identity(destination), archive=identity(output), graphs=record['validation']['graph_submissions'])))


if __name__ == '__main__': main()
