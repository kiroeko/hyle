"""Small metadata override for the actual complete AVX2 validation worker."""
from pathlib import Path
import hashlib,json

S=Path(__file__).resolve().parent;R=S.parents[1]
RESULT=S/'B10/cpu-native-avx2-corrected1/result.json'
RESULT_SHA='0fbd466594e7508f71a4d0ba6980e66cd37244b974c426d80ebdbb97b5ae9a8e'


def read(path):return json.loads(Path(path).read_text(encoding='utf-8-sig'))
def resolve(path):return Path(path).resolve() if Path(path).is_absolute() else (R/path).resolve()
def identity(path):
    path=resolve(path);digest=hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda:stream.read(1048576),b''):digest.update(block)
    return dict(path=str(path),bytes=path.stat().st_size,sha256=digest.hexdigest())
def require(info):
    if identity(info['path'])!=info:raise ValueError('Actual corrected-runtime input differs: '+info['path'])


def actual_result():
    if identity(RESULT)['sha256']!=RESULT_SHA:raise ValueError('Actual complete AVX2 result changed')
    result=read(RESULT);require(result['plan'])
    if result.get('passed')is not True or result['link']['exit']!=0 or len(result['compile_records'])!=15:
        raise ValueError('Complete15-TU AVX2 compile/link did not pass')
    flags={'/DGGML_AVX','/DGGML_AVX2','/DGGML_FMA','/DGGML_F16C','/DGGML_BMI2','/D__BMI2__','/arch:AVX2'}
    for row in result['compile_records']:
        if row['exit']!=0 or not flags<=set(row['command']):raise ValueError('Actual complete AVX2 command/exit differs')
        for key in ('source','actual_object','actual_dependencies'):require(row[key])
    for row in result['reused']:
        if not flags<=set(row['command']):raise ValueError('Reused ops/export is not the same AVX2 family')
        for key in ('source','object','dependencies'):require(row[key])
    require(result['link']['module'])
    return result


def override(base_runtime_path,output_path):
    result=actual_result();base=resolve(base_runtime_path);runtime=read(base);module=result['link']['module']
    if len(runtime['staged_dlls'])!=1 or Path(runtime['staged_dlls'][0]['path']).name!=Path(module['path']).name:
        raise ValueError('Corrected worker must replace the single existing CPU module basename')
    runtime.update(previous_native_cpu_runtime=identity(base),replaced_native_module=runtime['staged_dlls'][0],
        previous_same_family_native_plan=runtime.get('same_family_native_plan'),previous_native_build_result=runtime.get('native_build_result'),
        staged_dlls=[module],matched_HC_PRE_worker=module,same_family_native_plan=result['plan'],native_build_result=identity(RESULT),
        native_CPU_TUs=15,cpu_runtime_override=dict(helper=identity(Path(__file__)),source_runtime=identity(base),
            actual_result=identity(RESULT),module=module,scope='Actual complete15-TU AVX2 worker; old scratch module retained only as replaced history.'))
    output=resolve(output_path);raw=(json.dumps(runtime,indent=2)+'\n').encode()
    if output.exists():
        if output.read_bytes()!=raw:raise ValueError('Do not overwrite an existing different runtime override')
    else:output.parent.mkdir(parents=True,exist_ok=True);output.write_bytes(raw)
    return output


def verify(runtime_path):
    result=actual_result();runtime=read(resolve(runtime_path));proof=runtime['cpu_runtime_override']
    require(proof['helper']);require(proof['source_runtime']);require(proof['actual_result'])
    if proof['actual_result']!=identity(RESULT) or proof['module']!=result['link']['module']:
        raise ValueError('Runtime override does not reference its actual owning result')
    modules=runtime['staged_dlls']
    if len(modules)!=1 or any(modules[0][k]!=result['link']['module'][k] for k in ('bytes','sha256')):
        raise ValueError('Staged runtime differs from the actual complete AVX2 module')
    require(modules[0])
    return dict(result=identity(RESULT),plan=result['plan'],module=modules[0],helper=identity(Path(__file__)))
