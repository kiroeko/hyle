"""B09 exact static47 / actual selected-expert acquisition. Root executes batches.

No network on import, --plan-only or --write-batch-plan. Actual acquisition
requires the existing exclusive hf-mirror.net budget opener. No complete expert
bank is downloaded, mapped or hashed. Original packed bytes are unchanged.
"""
import argparse
from concurrent.futures import ThreadPoolExecutor, as_completed
import hashlib
import importlib.util
import json
import math
import os
from pathlib import Path
import re
import struct
import sys
import urllib.request

sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
R = S.parents[2]
REPO, REV = 'unsloth/GLM-5.3-GGUF', '346b3591c7f28d1a23716f97a065ecf12ec14771'
VARIANT = 'UD-Q4_K_XL'
COUNT, BODY, DOMAIN = 47, 2567086080, 256
REQUEST, IO, WORKERS = 8*1024*1024, 1024*1024, 3
LEGS = ('gate', 'up', 'down')
SECTION = {'draft': (78, 22806528), 'target': (77, 24477696)}
PINS = {
    'static-plan.json': 'e7aa49e97ce1981f1f9f4a1617b5f6bc2809377ea89e10699fe39bd8665007d7',
    'roles-plan.json': 'a34a5ebcb5c4096190e15256a3dc2239b7fb21f25f401342fe39b523dbc16d9c',
    'summary.json': 'e1f7bc4ccdff18b2422cd3beb1cd1cbd42e489ab3c8d2d3a08107371ea9da8d3',
}
HELPERS = {
    'loose': ('.scratch/qwen-bfloat-selected-20261023/fetch_roles.py', '1b34877ca22ab16eeaeb508e781dd84d0abf6555a73454b37f48e6d6a7e5cca3'),
    'bundle': ('.scratch/dspark-pro-target-draft-20261023/fetch_dense.py', '37d4414444a565f5b393d6908c63d176996c32cd359f519a60661f702091d5bf'),
    'budget': ('.scratch/mtp-download-budget-20261023/budget.py', '24b008fb7a91f0eba34739cd4817fbf97b42ca7f435032d76cfb6e97ea398a17'),
}
TYPES = {0: ('F32', 1, 4), 8: ('Q8_0', 32, 34), 12: ('Q4_K', 256, 144),
         13: ('Q5_K', 256, 176), 14: ('Q6_K', 256, 210)}


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def identity(path):
    path = Path(path).resolve()
    raw = path.read_bytes()  # Only named small source/metadata files.
    return dict(path=path.relative_to(R).as_posix(), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


def pin(value):
    return isinstance(value, str) and re.fullmatch('[0-9a-f]{64}', value) is not None


def save(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name+'.next')
    with temporary.open('w', encoding='utf-8', newline='\n') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)
        stream.write('\n')
        stream.flush()
        os.fsync(stream.fileno())
    # Match the existing Windows shared-delete receipt discipline. Retry only
    # atomic metadata replacement; this never repeats a body HTTP request.
    import time
    for attempt in range(50):
        try:
            os.replace(temporary, path)
            return
        except PermissionError:
            if attempt == 49:
                raise
            time.sleep(.02)


def retain(path, value):
    if path.exists():
        assert read(path) == value, 'Immutable plan differs: '+str(path)
    else:
        save(path, value)


def helper(key):
    name, sha = HELPERS[key]
    path = R/name
    assert identity(path)['sha256'] == sha, 'Pinned helper changed: '+key
    spec = importlib.util.spec_from_file_location('_b09_'+key, path)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


def checked():
    for name, sha in PINS.items():
        assert identity(S/name)['sha256'] == sha, 'Actual B09 metadata changed: '+name
    proof, static, all_roles = read(S/'summary.json'), read(S/'static-plan.json'), read(S/'roles-plan.json')
    assert proof['complete'] and proof['metadata_only'] and proof['tensor_payload_bytes'] == 0
    assert proof['static_plan'] == identity(S/'static-plan.json') and proof['roles_plan'] == identity(S/'roles-plan.json')
    assert static['roles'] == [r for r in all_roles['roles'] if not r['selected_source']]
    assert static['original_roles'] == len(static['roles']) == COUNT
    assert static['source_bytes'] == sum(r['bytes'] for r in static['roles']) == BODY
    assert all_roles['original_roles'] == 53 and all_roles['full_expert_banks_acquire'] is False
    assert len({r['name'] for r in all_roles['roles']}) == 53
    tables, shards = {}, {}
    for plan in (static, all_roles):
        assert (plan['repository'], plan['revision'], plan['variant']) == (REPO, REV, VARIANT)
        assert plan['complete_absolute_ranges'] and plan['http_identity_authenticated'] and plan['metadata_only']
        assert plan['whole_shards_downloaded'] is False
        assert plan['shards'] == proof['headers']
    for shard in all_roles['shards']:
        assert shard['complete'] and shard['schema_validated'] and shard['http_status'] == 206
        assert (shard['repository'], shard['revision']) == (REPO, REV)
        assert shard['url'] == f"https://huggingface.co/{REPO}/resolve/{REV}/{shard['file']}"
        assert re.fullmatch('"[0-9a-f]{64}"', shard['etag'])
        for key in ('header', 'physical_table', 'acquired_receipt'):
            assert identity(R/shard[key]['path']) == shard[key]
        table = read(R/shard['physical_table']['path'])['tensors']
        assert len(table) == shard['actual_tensor_count']
        tables[shard['shard']] = {r['name']: r for r in table}
        assert len(tables[shard['shard']]) == len(table)
        shards[shard['shard']] = shard
    for row in all_roles['roles']:
        shard, original = shards[row['source_shard']], tables[row['source_shard']][row['name']]
        dtype, block, stored = TYPES[row['dtype_code']]
        assert row['gguf_dimensions'] == original['shape'] and all(type(v) is int and v > 0 for v in original['shape'])
        assert row['dtype_code'] == original['dtype_code'] and row['dtype'] == original['dtype'] == dtype
        assert original['shape'][0] % block == 0
        assert row['bytes'] == original['bytes'] == math.prod(original['shape'])//block*stored
        first = shard['data_base']+original['offset']
        assert row['data_relative_half_open'] == [original['offset'], original['offset']+row['bytes']]
        assert row['absolute_inclusive'] == [first, first+row['bytes']-1]
        assert row['source_file'] == shard['file'] and first+row['bytes'] <= shard['whole_file_bytes']
        assert row['filename'] == row['name']+'.bin' and Path(row['filename']).name == row['filename']
        if row['selected_source']:
            assert len(original['shape']) == 3 and original['shape'][2] == DOMAIN
            assert row['expert_bytes']*DOMAIN == row['bytes'] and row['dtype_code'] in (12,13,14)
        else:
            assert row['dtype_code'] in (0,8)
    banks = [row for row in all_roles['roles'] if row['selected_source']]
    assert len(banks) == 6
    expert = dict(repository=REPO, revision=REV, variant=VARIANT, source_format='GGUF_ORIGINAL_PACKED_K',
        original_roles=6, expert_domain=DOMAIN, runtime_slots=8, stage=0,
        full_expert_banks_acquire=False, whole_bank_sha256_required=False,
        source_roles_plan=identity(S/'roles-plan.json'), source_schema=all_roles['source_schema'],
        shards=all_roles['shards'], roles=banks, leg_order=list(LEGS),
        sections={s: dict(layer=layer, per_id_payload_bytes=size) for s,(layer,size) in SECTION.items()},
        typed_catalog=dict(magic='HYDSPT01', version=1, roles=3, bytes=112),
        scope='Original bank metadata defines exact per-ID slices only. Never fetch/hash whole expert banks.')
    retain(S/'expert-source-plan.json', expert)
    return static, expert, shards


def require_transport():
    path, sha = HELPERS['budget']
    assert identity(R/path)['sha256'] == sha
    opener = urllib.request.urlopen
    assert (hasattr(opener, '__code__') and opener.__code__.co_name == 'open_range'
        and Path(opener.__code__.co_filename).resolve() == (R/path).resolve()
        and opener.__globals__.get('MIRROR_HOST') == 'hf-mirror.net'), \
        'Actual acquisition must run through budget.py/run_batch.py exclusive net opener'


def expected_loose(static, shards, directory):
    result = []
    for row in static['roles']:
        source = shards[row['source_shard']]
        result.append(dict(row, url=source['url'], etag=source['etag'], whole_file_bytes=source['whole_file_bytes'],
            complete=False, chunks=[], payload=dict(path=(directory/row['filename']).relative_to(R).as_posix(),
                                                   bytes=row['bytes'], sha256=None)))
    return result


def acquire_static(static, shards):
    common = helper('loose')
    common.CHUNK, common.IO = REQUEST, IO
    directory = S/'original-static'
    directory.mkdir(parents=True, exist_ok=True)
    receipt = directory/'acquisition.json'
    wanted = dict(repository=REPO, revision=REV, variant=VARIANT, original_roles=COUNT,
        source_plan=identity(S/'static-plan.json'), expected_role_payload_bytes=BODY,
        whole_shard_downloaded=False, selected_only=True, downloader=identity(R/HELPERS['loose'][0]))
    with common.single_writer(directory/'.fetch.lock'):
        rows = expected_loose(static, shards, directory)
        if receipt.exists():
            record = read(receipt)
            assert all(record[k] == v for k,v in wanted.items())
            for actual, expected in zip(record['roles'], rows, strict=True):
                assert all(actual[k] == v for k,v in expected.items() if k not in ('complete','chunks','payload'))
                assert actual['payload']['path'] == expected['payload']['path'] and actual['payload']['bytes'] == expected['bytes']
        else:
            assert not any((directory/r['filename']).exists() for r in rows), 'Unrecorded loose payload is not an authenticated prefix'
            record = dict(wanted, complete=False, requests=[], roles=rows)
        functions = common.downloader(record, receipt)
        with functions['LOCK']:
            record.update(complete=False, chunk_bytes=REQUEST, maximum_http_request_bytes=REQUEST,
                          stream_buffer_bytes=IO, parallel_role_workers=WORKERS)
            functions['save']()
        failures = []
        with ThreadPoolExecutor(max_workers=WORKERS) as pool:
            futures = {pool.submit(functions['acquire_role'], row): row['name'] for row in record['roles']}
            for future in as_completed(futures):
                try:
                    future.result()
                except Exception as error:
                    failures.append(dict(role=futures[future],type=type(error).__name__,error=str(error)))
        # Every role future is terminal before publishing success/failure.
        with functions['LOCK']:
            if failures:
                record.setdefault('failure_history',[]).append(dict(utc=functions['now'](),errors=failures))
            record['errors'] = failures
            if not failures:
                assert all(r['complete'] and pin(r['payload']['sha256']) for r in record['roles'])
                assert sum(r['payload']['bytes'] for r in record['roles']) == BODY
                assert sum(r['bytes'] for r in record['requests'] if r['complete']) == BODY
                record.update(complete=True, role_payload_bytes=BODY, finished_utc=functions['now']())
            functions['save']()
        if failures:
            raise RuntimeError('B09 static acquisition failed: '+json.dumps(failures))
        manifest = dict(repository=REPO, revision=REV, variant=VARIANT, complete=True,
            original_roles=COUNT, source_bytes=BODY, source_plan=identity(S/'static-plan.json'),
            acquisition=identity(receipt), roles=[dict(name=r['name'],file=r['filename'],dtype=r['dtype'],
            dtype_code=r['dtype_code'],gguf_dimensions=r['gguf_dimensions'],bytes=r['bytes'],
            sha256=r['payload']['sha256']) for r in record['roles']])
        save(directory/'manifest.json',manifest)
        return dict(complete=True, original_roles=COUNT, role_payload_bytes=BODY,
                    acquisition=identity(receipt), manifest=identity(directory/'manifest.json'))


def selected(args):
    if args.frontier_file:
        assert args.section is None and args.ids is None
        request = read(args.frontier_file)
        section, ids = request['section'], request['missing_ids']
        assert type(request['stage']) is int and request['stage'] == 0
        globals_ = request['global_ids']
        assert isinstance(globals_,list) and globals_ == sorted(set(globals_)) and len(globals_) <= 8
        assert all(type(n) is int and 0 <= n < DOMAIN for n in globals_)
        assert isinstance(ids,list) and ids == sorted(set(ids)) and set(ids) <= set(globals_)
    else:
        section, ids = args.section, args.ids
    assert section in SECTION and isinstance(ids,list) and len(ids) <= 8
    assert all(type(n) is int and 0 <= n < DOMAIN for n in ids)
    return section, sorted(set(ids))


def per_id_plan(expert, section, global_id, directory):
    layer, size = SECTION[section]
    rows, groups, table, offset = [], [], {}, 0
    shard_map = {s['shard']: s for s in expert['shards']}
    used = []
    for index,leg in enumerate(LEGS):
        bank = next(r for r in expert['roles'] if r['name'] == f'blk.{layer}.ffn_{leg}_exps.weight')
        source = shard_map[bank['source_shard']]
        if source not in used:
            used.append(source)
        source_index = used.index(source)
        stride = bank['expert_bytes']
        first = bank['absolute_inclusive'][0]+global_id*stride
        last = first+stride-1
        assert last <= bank['absolute_inclusive'][1]
        relative = [first-source['data_base'], last+1-source['data_base']]
        table[bank['name']] = dict(dtype=bank['dtype'],shape=bank['gguf_dimensions'][:2],data_offsets=relative)
        rows.append(dict(index=index,name=bank['name'],dtype=bank['dtype'],dtype_code=bank['dtype_code'],
            shape=bank['gguf_dimensions'][:2],bytes=stride,source_shard=source_index,bundle_offset=offset,
            data_relative_half_open=relative,absolute_inclusive=[first,last],global_id=global_id,leg=leg))
        groups.append(dict(index=index,source_shard=source_index,first=first,last=last,bundle_offset=offset,bytes=stride))
        offset += stride
    assert offset == size
    # Explicit metadata view only, independently derived above from the pinned
    # actual GGUF table. Reuses the existing exact-range bundle downloader.
    view = directory/'header-table.json'
    retain(view,table)
    shards = [dict(s,header=identity(view),source_format='GGUF_SELECTED_EXPERT_VIEW',
                   original_gguf_header=s['header']) for s in used]
    return dict(repository=REPO,revision=REV,variant=VARIANT,section=section,stage=0,global_ids=[global_id],
        original_roles=3,bundle_bytes=size,whole_shards_downloaded=False,unrequested_bytes=0,
        source_format='GGUF_ORIGINAL_PACKED_K',source_plan=identity(S/'expert-source-plan.json'),
        typed_order='gate,up,down; actual section/stage0/global ID; native packed bytes unchanged',
        shards=shards,roles=rows,groups=groups)


def check_catalog(record, plan, directory):
    assert record['complete'] and record['original_roles'] == 3
    assert record['role_payload_bytes'] == record['bundle_bytes'] == plan['bundle_bytes']
    assert record['source_plan_sha256'] == identity(directory/'plan.json')['sha256']
    raw = (directory/'catalog.bin').read_bytes()
    assert record['typed_catalog'] == identity(directory/'catalog.bin') and len(raw) == 112
    magic,version,count,size,reserved,digest = struct.unpack('<8sIIQQ32s',raw[:64])
    assert (magic,version,count,size,reserved) == (b'HYDSPT01',1,3,plan['bundle_bytes'],0)
    assert pin(record['bundle']['sha256']) and digest.hex() == record['bundle']['sha256']
    assert (directory/'roles.bin').stat().st_size == size
    for i,row in enumerate(plan['roles']):
        assert struct.unpack_from('<QQ',raw,64+i*16) == (row['bundle_offset'],row['bytes'])


def acquire_experts(expert, section, ids, plan_only=False):
    fetch, locks = helper('bundle'), helper('loose')
    # Fixed once, BEFORE any worker. Three IDs, each with three serial legs:
    # at most three8MiB requests and three1MiB streaming buffers in flight.
    fetch.COUNT,fetch.BODY_BYTES,fetch.CHUNK,fetch.IO,fetch.WORKERS = 3,SECTION[section][1],REQUEST,IO,1
    def acquire(global_id):
        directory = S/'original-experts'/section/'stage0'/f'expert{global_id:03d}'
        directory.mkdir(parents=True,exist_ok=True)
        with locks.single_writer(directory/'.fetch.lock'):
            plan = per_id_plan(expert,section,global_id,directory)
            retain(directory/'plan.json',plan)
            if plan_only:
                return dict(global_id=global_id,plan=identity(directory/'plan.json'),bundle_bytes=plan['bundle_bytes'],network_requests=0)
            record = fetch.main(plan_path=directory/'plan.json',out=directory)
            check_catalog(record,plan,directory)
            ready = dict(complete=True,repository=REPO,revision=REV,variant=VARIANT,section=section,stage=0,
                global_ids=[global_id],source_plan_sha256=identity(S/'expert-source-plan.json')['sha256'],
                directory=directory.resolve().as_posix(),typed_catalog=dict(file='catalog.bin',bytes=112,
                sha256=record['typed_catalog']['sha256']),plan=identity(directory/'plan.json'),
                acquisition=identity(directory/'acquisition.json'),bundle=record['bundle'],
                per_id_workers=1,outer_expert_workers=WORKERS,maximum_http_request_bytes=REQUEST,
                maximum_live_stream_bytes=WORKERS*IO)
            save(directory/'ready.json',ready)
            return ready
    completed,failures = [],[]
    with ThreadPoolExecutor(max_workers=WORKERS) as pool:
        futures = {pool.submit(acquire,n):n for n in ids}
        for future in as_completed(futures):
            try:
                completed.append(future.result())
            except Exception as error:
                failures.append(dict(global_id=futures[future],type=type(error).__name__,error=str(error)))
    # All futures terminal, including failure: no premature frontier_complete.
    result = dict(event='frontier_failed' if failures else 'frontier_planned' if plan_only else 'frontier_complete',
        complete=not plan_only and not failures,section=section,stage=0,global_ids=ids,
        caches=sorted(completed,key=lambda r:r.get('global_id',r.get('global_ids',[0])[0])),errors=failures)
    print(json.dumps(result),flush=True)
    if failures:
        raise RuntimeError('B09 selected-expert acquisition failed: '+json.dumps(failures))
    return result


def batch(args, size, section=None, ids=None):
    target = args.write_batch_plan.resolve()
    assert target.is_relative_to(S) and target.suffix == '.json'
    arguments = ['static'] if args.action == 'static' else ['experts','--section',section,'--ids',*map(str,ids)]
    evidence = S/('static-plan.json' if args.action == 'static' else 'expert-source-plan.json')
    label = 'static' if args.action == 'static' else section+'-'+'-'.join(map(str,ids))
    assert size > 0, 'Empty frontier needs no download batch'
    if args.action == 'experts':
        # Retain each exact three-leg metadata plan before root opens a body
        # batch. These are only the IDs in the actual supplied frontier.
        _,expert,_ = checked()
        for global_id in ids:
            directory = S/'original-experts'/section/'stage0'/f'expert{global_id:03d}'
            retain(directory/'plan.json',per_id_plan(expert,section,global_id,directory))
    value = dict(script=identity(Path(__file__))['path'],script_sha256=identity(Path(__file__))['sha256'],
        arguments=arguments,out=(S/'batches'/f'{label}-attempt{args.attempt}').relative_to(R).as_posix(),
        need_evidence=identity(evidence),new_unique_body_bytes=size,new_unique_body_bytes_is_upper_bound=True,
        payload_bound_note='Requested role extents, conservative upper bound; existing verified chunks/caches are reused.',
        whole_bank=False,whole_model=False,timeout_seconds=7200,repository=REPO,revision=REV,
        maximum_http_request_bytes=REQUEST,stream_buffer_bytes=IO,maximum_http_streams=WORKERS,
        transport='exclusive https://hf-mirror.net via pinned budget/run_batch; no automatic fallback',
        source_scripts={key:identity(R/info[0]) for key,info in HELPERS.items()})
    retain(target,value)
    print(json.dumps(dict(batch_plan=identity(target),network_requests=0,**{k:value[k] for k in ('arguments','new_unique_body_bytes','out')})))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action',choices=('static','experts'))
    parser.add_argument('--section',choices=tuple(SECTION))
    parser.add_argument('--ids',type=int,nargs='+')
    parser.add_argument('--frontier-file',type=Path)
    parser.add_argument('--plan-only',action='store_true')
    parser.add_argument('--write-batch-plan',type=Path)
    parser.add_argument('--attempt',type=int,default=1)
    args = parser.parse_args()
    assert args.attempt > 0 and not (args.plan_only and args.write_batch_plan)
    static,expert,shards = checked()
    for key in ('loose','bundle','budget'):
        assert identity(R/HELPERS[key][0])['sha256'] == HELPERS[key][1]
    if args.action == 'static':
        assert args.section is None and args.ids is None and args.frontier_file is None
        if args.write_batch_plan:
            return batch(args,BODY)
        if args.plan_only:
            print(json.dumps(dict(complete=False,plan_only=True,roles=COUNT,payload_bytes=BODY,network_requests=0,
                source_plan=identity(S/'static-plan.json'),expert_source_plan=identity(S/'expert-source-plan.json'),
                maximum_http_request_bytes=REQUEST,stream_buffer_bytes=IO,workers=WORKERS,
                directory=(S/'original-static').relative_to(R).as_posix())))
            return
        require_transport()
        print(json.dumps(acquire_static(static,shards)),flush=True)
    else:
        section,ids = selected(args)
        if args.write_batch_plan:
            # Capture immutable actual IDs, not a mutable request-file path.
            return batch(args,len(ids)*SECTION[section][1],section,ids)
        if not args.plan_only:
            require_transport()
        acquire_experts(expert,section,ids,args.plan_only)


if __name__ == '__main__':
    main()
