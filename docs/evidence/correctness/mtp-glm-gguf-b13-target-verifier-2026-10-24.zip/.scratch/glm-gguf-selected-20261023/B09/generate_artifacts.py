"""Generate B09 pins only from COMPLETE real static47 loose-role receipts.

No body download or rehash here. The downloader has already hashed every real
file/range; Data::load reauthenticates those exact files at native startup.
Expert pin is the authenticated six-bank RANGE PLAN, never a full-bank SHA.
"""
import argparse
import hashlib
import importlib.util
import json
from pathlib import Path
import sys

sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
R = S.parents[2]


def acquisition():
    spec = importlib.util.spec_from_file_location('_b09_metadata_only_acquisition',S/'acquire.py')
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


def validate(directory):
    a = acquisition()
    static,expert,shards = a.checked()
    record_path,manifest_path = directory/'acquisition.json',directory/'manifest.json'
    assert record_path.is_file() and manifest_path.is_file(), 'Actual complete B09 static47 acquisition is required'
    record,manifest = a.read(record_path),a.read(manifest_path)
    assert record['complete'] is True and manifest['complete'] is True
    assert (record['repository'],record['revision'],record['variant']) == (a.REPO,a.REV,a.VARIANT)
    assert record['original_roles'] == manifest['original_roles'] == a.COUNT
    assert record['expected_role_payload_bytes'] == record['role_payload_bytes'] == manifest['source_bytes'] == a.BODY
    assert record['source_plan'] == manifest['source_plan'] == a.identity(S/'static-plan.json')
    assert manifest['acquisition'] == a.identity(record_path)
    assert record['whole_shard_downloaded'] is False and record['selected_only'] is True
    assert not record['errors'] and record['chunk_bytes'] == record['maximum_http_request_bytes'] == a.REQUEST
    assert record['stream_buffer_bytes'] == a.IO and record['parallel_role_workers'] == a.WORKERS
    assert record['downloader'] == a.identity(R/a.HELPERS['loose'][0])
    expected = a.expected_loose(static,shards,directory)
    assert len(record['roles']) == len(manifest['roles']) == a.COUNT
    total = 0
    for row,wanted,item in zip(record['roles'],expected,manifest['roles'],strict=True):
        assert all(row[k] == v for k,v in wanted.items() if k not in ('complete','chunks','payload'))
        assert row['complete'] is True and a.pin(row['payload']['sha256'])
        body = directory/row['filename']
        assert (R/row['payload']['path']).resolve() == body.resolve()
        assert row['payload']['bytes'] == body.stat().st_size == row['bytes']
        cursor = 0
        for part in row['chunks']:
            assert part['offset'] == cursor and 0 < part['bytes'] <= a.REQUEST and a.pin(part['sha256'])
            first = row['absolute_inclusive'][0]+cursor
            assert part['absolute_range_inclusive'] == [first,first+part['bytes']-1]
            cursor += part['bytes']
        assert cursor == row['bytes']
        expected_item = dict(name=row['name'],file=row['filename'],dtype=row['dtype'],dtype_code=row['dtype_code'],
            gguf_dimensions=row['gguf_dimensions'],bytes=row['bytes'],sha256=row['payload']['sha256'])
        assert item == expected_item
        total += cursor
    assert total == a.BODY
    # Every successful request must exactly certify one stored role chunk.
    expected_requests = sorted((r['name'],p['absolute_range_inclusive'][0],p['absolute_range_inclusive'][1],
        p['bytes'],p['sha256']) for r in record['roles'] for p in r['chunks'])
    actual_requests = []
    by_name = {r['name']:r for r in record['roles']}
    for request in record['requests']:
        if not request['complete']:
            continue  # Preserved failed attempt; never generates a payload pin.
        row = by_name[request['role']]
        assert request['http_status'] == 206 and request['etag'] == row['etag']
        assert request['content_range'] == f"bytes {request['first']}-{request['last']}/{row['whole_file_bytes']}"
        assert request['requested_bytes'] == request['bytes'] == request['last']-request['first']+1
        actual_requests.append((row['name'],request['first'],request['last'],request['bytes'],request['sha256']))
    assert sorted(actual_requests) == expected_requests
    assert (manifest['repository'],manifest['revision'],manifest['variant']) == (a.REPO,a.REV,a.VARIANT)
    return a,record,manifest,expert


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--directory',type=Path,default=S/'original-static')
    parser.add_argument('--output',type=Path,default=S/'generated/glm_gguf_b09_artifacts.h')
    args = parser.parse_args()
    directory = args.directory.resolve()
    a,record,manifest,expert = validate(directory)
    values = dict(kRepository=a.REPO,kRevision=a.REV,kVariant=a.VARIANT,
        kStaticPlanSha256=a.identity(S/'static-plan.json')['sha256'],
        kExpertSourcePlanSha256=a.identity(S/'expert-source-plan.json')['sha256'],
        kStaticAcquisitionSha256=a.identity(directory/'acquisition.json')['sha256'],
        kStaticManifestSha256=a.identity(directory/'manifest.json')['sha256'])
    lines = ['#pragma once','#include <array>','#include <string_view>',
        '#include "original_named_role_source.h"',
        '// Actual completed original packed/F32 files. No full expert-bank payload pins.',
        'namespace glm_gguf_b09_artifacts {']
    lines += ['inline constexpr std::string_view '+name+'='+json.dumps(value)+';' for name,value in values.items()]
    lines += ['inline const std::array<original_named_role_source::PinnedFile,47> kStaticPins47{{']
    lines += ['    {'+json.dumps(row['file'])+','+json.dumps(row['sha256'])+'},' for row in manifest['roles']]
    lines += ['}};','inline const auto &kStaticPins=kStaticPins47;',
              '} // namespace glm_gguf_b09_artifacts','']
    output = args.output.resolve()
    assert output.is_relative_to(R), 'Generated header must stay in the workspace'
    output.parent.mkdir(parents=True,exist_ok=True)
    output.write_text('\n'.join(lines),encoding='utf-8',newline='\n')
    proof = dict(complete=True,repository=a.REPO,revision=a.REV,variant=a.VARIANT,
        original_roles=a.COUNT,source_bytes=a.BODY,directory=directory.relative_to(R).as_posix(),
        source_plan=a.identity(S/'static-plan.json'),expert_source_plan=a.identity(S/'expert-source-plan.json'),
        acquisition=a.identity(directory/'acquisition.json'),manifest=a.identity(directory/'manifest.json'),
        source_headers=[s['header'] for s in expert['shards']],generated_header=a.identity(output),
        generator=a.identity(Path(__file__)),body_rehashed=False,network_requests=0,
        expert_payload_scope='Only requested actual section/global IDs get immutable catalog112B+roles.bin caches.')
    a.save(output.with_suffix('.json'),proof)
    print(json.dumps(proof),flush=True)


if __name__ == '__main__':
    main()
