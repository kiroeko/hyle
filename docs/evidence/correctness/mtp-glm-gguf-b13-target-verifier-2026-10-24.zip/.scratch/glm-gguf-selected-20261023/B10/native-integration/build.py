"""B10 one-Pro-TU overlay on the actual current Q30 Graph/GDN/native closure.

Only root executes compile/link/run. No SDK, NVCC or product TU rebuild is
scheduled here. Missing real completed47-role pins block before compilation.
"""
from pathlib import Path
import argparse
import hashlib
import importlib.util
import json
import os
import sys

sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent
R=S.parents[3]
DATA=S.parent
BASE=R/'.scratch/glm-quark-selected-20261024/Q30/graph-integration-preparation'
BASE_IMAGE=BASE/'tests-link2'
BASE_PLAN_SHA='fe100231af267805be122c939ad8e8a9513099f11813bb073ee66785cf3d68ac'
RUNTIME_SHA='736419366b51a2171a01e49af5284fbe8a8b38c05a38e82080c0123893e5f3d4'
CPU_MODULE_SHA='a020c6c3bd0d51bd50319fbe6924826979fec0b11cdd0e9db8457c132c136092'
NATIVE_INPUTS_SHA='95c04ed7499348ba46922e0c8061734c3c22ef537ed4a0513ae2558f20b46ca0'
RECIPE=R/'.scratch/glm-gguf-selected-20261023/B09/native-integration/compile2/glm-pro/identity.json'
SOURCE=R/'tests/compute_models/glm_pro_mtp_state_consumer_test.cc'
ACQUIRE_SHA='0425e10c230289cf1ed10c1c57eb4c64fb9242fe3238157d07db2c0e18fc14cb'
GENERATOR_SHA='e0b79e16dd5d9ef314667008d739db74bf080d2315f4e25a5dd30db3de82172f'


def read(path):return json.loads(Path(path).read_text(encoding='utf-8-sig'))
def resolve(path):
    path=Path(path);return path.resolve() if path.is_absolute() else (R/path).resolve()
def identity(path):
    path=resolve(path);digest=hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda:stream.read(1048576),b''):digest.update(block)
    return dict(path=str(path),bytes=path.stat().st_size,sha256=digest.hexdigest())
def require(info,path=None):
    actual=identity(path or info['path'])
    if resolve(info['path'])!=resolve(actual['path']) or any(actual[k]!=info[k] for k in ('bytes','sha256')):
        raise ValueError('Actual cached source/object/metadata identity differs: '+actual['path'])
    return actual
def save(path,value):
    Path(path).parent.mkdir(parents=True,exist_ok=True)
    Path(path).write_text(json.dumps(value,indent=2)+'\n',encoding='utf-8',newline='\n')
def module(name,path):
    spec=importlib.util.spec_from_file_location(name,path);value=importlib.util.module_from_spec(spec);spec.loader.exec_module(value);return value
def helpers():return module('_b10_cached_host_build',R/'.scratch/native-paged-effects-20261022/build_windows.py')


def pins():
    if identity(DATA/'acquire.py')['sha256']!=ACQUIRE_SHA or identity(DATA/'generate_artifacts.py')['sha256']!=GENERATOR_SHA:
        raise ValueError('Frozen B10 acquisition/generator changed')
    generator=module('_b10_actual_receipt_validator',DATA/'generate_artifacts.py')
    a,record,manifest,expert=generator.validate(DATA/'original-static')
    header=DATA/'generated/glm_gguf_b10_artifacts.h';proof_path=header.with_suffix('.json');proof=read(proof_path)
    if not proof['complete'] or proof['original_roles']!=47 or proof['source_bytes']!=2566508544:
        raise ValueError('Actual B10 generated pin proof is not complete47')
    for key,path in [('generated_header',header),('acquisition',DATA/'original-static/acquisition.json'),
        ('manifest',DATA/'original-static/manifest.json'),('source_plan',DATA/'static-plan.json'),
        ('expert_source_plan',DATA/'expert-source-plan.json'),('generator',DATA/'generate_artifacts.py')]:
        require(proof[key],path)
    return header,proof_path,dict(manifest=identity(DATA/'original-static/manifest.json'),
        acquisition=identity(DATA/'original-static/acquisition.json'),source_plan=identity(DATA/'static-plan.json'),
        expert_plan=identity(DATA/'expert-source-plan.json'),roles=47,source_bytes=2566508544,body_rehashed=False)


def check_record(path):
    record=read(path)
    for item in (record['source'],record['object'],*record['dependencies']):require(item)
    return record



def native_inputs():
    path=S/'native-inputs.json'
    if identity(path)['sha256']!=NATIVE_INPUTS_SHA:raise ValueError('Actual retained native input pin changed')
    rows=read(path)['objects']
    if [row['name'] for row in rows]!=['cpu-baseline','cuda-gated-delta']:
        raise ValueError('Expected exactly the two explicit original native objects')
    for row in rows:
        for info in (row['object'],row['source'],row['plan'],row['process'],row['dependency_record'],*row['dependencies']):require(info)
        if read(row['process']['path'])['exit']!=0:raise ValueError('Retained native compiler was not successful')
    return rows

def closure():
    plan_path=BASE/'link-plan.json';plan=read(plan_path)
    for row in native_inputs():
        if sum(argument.lower().endswith('.obj') and resolve(argument)==resolve(row['object']['path']) for argument in plan['command'])!=1:
            raise ValueError('Pinned native object must occur exactly once in original command')
    if identity(plan_path)['sha256']!=BASE_PLAN_SHA or plan['pending_consumer'] is not False:
        raise ValueError('Pinned actual current Flash Graph/GDN closure changed')
    ready=read(BASE_IMAGE/'ready.json');require(ready['link_plan'],plan_path)
    runtime_path=BASE_IMAGE/'runtime-environment.json';require(ready['runtime_environment'],runtime_path)
    if identity(runtime_path)['sha256']!=RUNTIME_SHA:raise ValueError('Pinned corrected mixed-family runtime changed')
    runtime=read(runtime_path)
    if len(runtime['staged_dlls'])!=1 or runtime['staged_dlls'][0]['sha256']!=CPU_MODULE_SHA:
        raise ValueError('B10 must retain the corrected mixed-owning CPU module')
    for info in runtime['staged_dlls']:require(info)
    require(runtime['same_family_native_plan']);require(runtime['native_build_result'])
    old_consumer=read(resolve(plan['consumer_record']['path']))
    require(plan['consumer_record'])
    records=list((BASE/'host1/records').glob('*/identity.json'))+list((BASE/'support1/records').glob('*/identity.json'))
    for row in plan['reused_current_records']:require(row)
    records += [resolve(row['path']) for row in plan['reused_current_records']]
    return plan,ready,runtime_path,old_consumer,list(dict.fromkeys(records))


def compile_one(attempt):
    header,proof,receipt=pins();h=helpers()
    recipe=read(RECIPE);include='/I'+str(header.parent)
    if include not in recipe['command']:recipe['command'].insert(1,include)
    recipe.update(prepared_only=True,actual_pins=identity(header),actual_pin_receipt=identity(proof))
    prepared=S/f'prepared-recipe{attempt}.json'
    if prepared.exists():raise ValueError('Compile attempt already has an immutable prepared recipe')
    save(prepared,recipe)
    h.S=S;h.RECIPES={'glm-pro':prepared};h.SOURCES={'glm-pro':SOURCE}
    h.compile_one('glm-pro',attempt)
    path=S/f'compile{attempt}/glm-pro/identity.json';record=check_record(path)
    if not any(resolve(row['path'])==header.resolve() for row in record['dependencies']):
        raise ValueError('Actual B10 guarded header is missing from compiler source dependencies')
    record.update(actual_pins=identity(header),actual_pin_receipt=identity(proof),actual_static=receipt,
        tool=identity(Path(__file__)),SDK_builds=0,NVCC_builds=0,product_translation_units=0,consumer_translation_units=1)
    save(path,record)


def link(attempt,compile_attempt):
    pins();plan,base_ready,runtime_path,old_consumer,paths=closure()
    fresh_path=S/f'compile{compile_attempt}/glm-pro/identity.json';fresh=check_record(fresh_path)
    old_object=resolve(old_consumer['object']['path']);command=[];replaced=0
    for argument in plan['command']:
        if argument.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:')):continue
        if argument.lower().endswith('.obj') and resolve(argument)==old_object:
            argument=fresh['object']['path'];replaced+=1
        command.append(argument)
    if replaced!=1:raise ValueError('Current Flash test object must be replaced exactly once')
    objects={str(resolve(x)).lower() for x in command if x.lower().endswith('.obj')}
    known={str(resolve(fresh['object']['path'])).lower()};checked=[]
    for row in native_inputs():known.add(str(resolve(row['object']['path'])).lower())
    for info in plan['retained_inputs']:
        require(info);known.add(str(resolve(info['path'])).lower())
    for path in paths:
        record=read(path)
        if str(resolve(record['object']['path'])).lower() in objects:
            check_record(path);checked.append(identity(path));known.add(str(resolve(record['object']['path'])).lower())
    if not objects<=known:raise ValueError('Unaccounted actual object in retained Graph/GDN closure: '+repr(objects-known))
    out=S/f'tests-link{attempt}';out.mkdir(exist_ok=False);(out/'tmp').mkdir()
    image=out/'glm-b10-checks.exe'
    command += ['/OUT:'+str(image),'/MAP:'+str(image.with_suffix('.map')),'/IMPLIB:'+str(image.with_suffix('.lib'))]
    link_plan=dict(command=command,base=identity(BASE/'link-plan.json'),base_ready=identity(BASE_IMAGE/'ready.json'),
        consumer_record=identity(fresh_path),retained_current_records=checked,retained_inputs=plan['retained_inputs'],
        retained_native_inputs=identity(S/'native-inputs.json'),retained_native_objects=[row['object']for row in native_inputs()],
        removed_consumer=plan['consumer_record'],note='Current compiled Graph/GDN/native closure; only one new actual-pinned Pro test TU replaces the Flash test TU.',
        product_translation_units=0,consumer_translation_units=1,SDK_builds=0,NVCC_builds=0)
    save(out/'link-plan.json',link_plan)
    h=helpers();env,_=h.b.environment(command,[],out)
    h.c.execute('link',command,env,out)
    runtime=read(runtime_path)
    for dll in runtime['staged_dlls']:
        require(dll);source=resolve(dll['path']);os.link(source,out/source.name)
    runtime['PATH']=str(out)+os.pathsep+runtime['PATH'].replace(str(BASE_IMAGE),str(out))
    runtime['previous_matched_HC_PRE_worker']=runtime.get('matched_HC_PRE_worker')
    runtime.update(previous=identity(runtime_path),staged_dlls=[identity(p)for p in out.glob('*.dll')],
        host_translation_units=1,product_host_translation_units=0,full_SDK_builds=0,NVCC_builds=0)
    runtime['matched_HC_PRE_worker']=runtime['staged_dlls'][0]
    save(out/'runtime-environment.json',runtime)
    save(out/'ready.json',dict(image=identity(image),link_plan=identity(out/'link-plan.json'),
        runtime_environment=identity(out/'runtime-environment.json'),consumer_record=identity(fresh_path),
        scope='Actual B10 guarded Pro TU with current Graph/GDN/native closure; no B10 native result is implied.'))


def run(args):
    pins();image_dir=S/f'tests-link{args.link_attempt}';ready=read(image_dir/'ready.json')
    consumer=check_record(resolve(ready['consumer_record']['path']))
    q=module('_b10_owned_driver_execute',R/'.scratch/qwen-mtp-quality-20261022/run_quality.py')
    out=S/f'driver-attempt{args.run_attempt}-{args.backend}';out.mkdir(exist_ok=False)
    command=[sys.executable,str(S/'run_with_supply.py'),'--image-dir',str(image_dir),'--backend',args.backend,
        '--attempt',str(args.run_attempt),'--timeout',str(args.timeout)]
    if args.wait_for_batch_summary:command += ['--wait-for-batch-summary',str(args.wait_for_batch_summary.resolve())]
    save(out/'plan.json',dict(command=command,script=identity(S/'run_with_supply.py'),build_script=identity(Path(__file__)),
        image=ready['image'],consumer_record=ready['consumer_record'],actual_static_bytes=2566508544,executed=False))
    process=q.execute(command,os.environ.copy(),out/'run',timeout=args.timeout+120)
    driver_path=S/'driver-runs'/f'checks{args.run_attempt}-{args.backend}'/'driver.json'
    record=read(driver_path) if driver_path.exists() else {}
    passed=process['exit']==0 and not process['timed_out'] and record.get('passed') is True and record.get('exit')==0
    properties=record.get('case',{}).get('properties',{})
    if passed:check_record(resolve(ready['consumer_record']['path']))
    save(out/'summary.json',dict(process=process,passed=passed,driver=identity(driver_path)if driver_path.exists()else None,
        case=record.get('case'),actual_graph_submissions=int(properties['actual_submissions'])if passed else None,
        image=ready['image'],consumer_record=ready['consumer_record'],no_throughput_claim=True))
    if not passed:raise SystemExit(process['exit'] or 1)


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('action',choices=('plan','compile','link','run'))
    parser.add_argument('--compile-attempt',type=int,default=1);parser.add_argument('--link-attempt',type=int,default=1)
    parser.add_argument('--run-attempt',type=int,default=1);parser.add_argument('--backend',choices=('cpu','cuda'),default='cpu')
    parser.add_argument('--timeout',type=int,default=14400);parser.add_argument('--wait-for-batch-summary',type=Path)
    args=parser.parse_args()
    if min(args.compile_attempt,args.link_attempt,args.run_attempt,args.timeout)<=0:raise ValueError('Positive attempts/timeout required')
    if args.action=='compile':compile_one(args.compile_attempt)
    elif args.action=='link':link(args.link_attempt,args.compile_attempt)
    elif args.action=='run':run(args)
    else:
        plan,ready,_,_,records=closure()
        value=dict(preparation_only=True,executed=False,source=identity(SOURCE),base_plan=identity(BASE/'link-plan.json'),
            retained_host_records=len(records),retained_native_inputs=identity(S/'native-inputs.json'),retained_native_objects=[row['object']for row in native_inputs()],actual_pins_present=(DATA/'generated/glm_gguf_b10_artifacts.h').exists(),
            required_static_roles=47,required_static_bytes=2566508544,consumer_translation_units=1,product_translation_units=0,SDK_builds=0,NVCC_builds=0,
            actions=['compile --compile-attempt N','link --compile-attempt N --link-attempt L','run --backend cpu --link-attempt L --run-attempt A','run --backend cuda --link-attempt L --run-attempt B'])
        save(S/'prepared.json',value);print(json.dumps(value))


if __name__=='__main__':main()
