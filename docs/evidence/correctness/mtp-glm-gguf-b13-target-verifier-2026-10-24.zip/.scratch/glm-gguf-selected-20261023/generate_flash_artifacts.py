"""Generate own B12/B13 Fixture only from authenticated headers and COMPLETE static85 receipts.

The frozen B09 validator checks role/range/ETag/chunk SHA and actual manifest.
No payload is rehashed here; missing bodies/receipts cannot generate pins.
"""
from pathlib import Path
import argparse
import hashlib
import importlib.util
import json
import sys
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent
R=S.parents[1]
VALIDATOR=S/'B09/generate_artifacts.py'
VALIDATOR_SHA='c3269d20c925976748f685fcbc290f569c2e7e36eaa5b99a9d8f3e9539608583'

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def module(name,p):
    spec=importlib.util.spec_from_file_location(name,p);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m

def float_literal(value):
    text=format(value,'.9g')
    if '.'not in text and 'e'not in text:text+='.0'
    return text+'F'
def optional(value):return 'std::nullopt'if value is None else 'std::optional<float>{'+float_literal(value)+'}'
def quote(value):return json.dumps(value,ensure_ascii=True)

def main(identity,entry):
    assert identity in ('B12','B13')
    directory=S/identity
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--directory',type=Path,default=directory/'original-static')
    parser.add_argument('--output',type=Path,default=directory/'generated'/f'glm_gguf_{identity.lower()}_artifacts.h')
    args=parser.parse_args()
    # Acquisition thin adapter hard-pins the common configuration implementation.
    acquisition=module('_flash_actual_acquisition',directory/'acquire.py')
    assert sha(VALIDATOR)==VALIDATOR_SHA
    validator=module('_flash_complete_pin_validator',VALIDATOR)
    validator.S,validator.R,validator.acquisition=directory,R,acquisition.configured
    a,record,manifest,expert=validator.validate(args.directory.resolve())
    static=a.read(directory/'static-plan.json');proof=a.read(directory/'fixture-policy.json');p=proof['policy']
    assert proof['source_roles_plan']==a.identity(directory/'roles-plan.json')
    assert len(manifest['roles'])==len(static['roles'])==85 and len(expert['roles'])==9
    primary=next(s for s in static['shards']if s['shard']==1)
    metadata=static['actual_metadata']['1'];assert isinstance(metadata['general.name'],str) and metadata['general.name']
    values=dict(kRepository=a.REPO,kRevision=a.REV,kVariant=a.VARIANT,kFirstFile=primary['file'],
        kStaticPlanSha256=a.identity(directory/'static-plan.json')['sha256'],
        kExpertSourcePlanSha256=a.identity(directory/'expert-source-plan.json')['sha256'],
        kConfigurationSha256=primary['header']['sha256'],
        kStaticAcquisitionSha256=a.identity(args.directory.resolve()/'acquisition.json')['sha256'],
        kStaticManifestSha256=a.identity(args.directory.resolve()/'manifest.json')['sha256'])
    ns=f'glm_gguf_{identity.lower()}_artifacts'
    lines=['#pragma once','#include <array>','#include <optional>','#include <string_view>',
           '#include "glm_gguf_flash_source.h"',
           '// Only complete original own-header/loose-role receipts create this Fixture.',f'namespace {ns} {{']
    lines+=['inline constexpr std::string_view '+k+'='+quote(v)+';'for k,v in values.items()]
    lines+=['inline constexpr std::uint64_t kStaticBytes=1892821552ULL;',
            'inline const std::array<original_named_role_source::PinnedFile,85> kStaticPins85{{']
    lines+=['  {'+quote(r['file'])+','+quote(r['sha256'])+'},'for r in manifest['roles']]
    lines+=['}};']
    for name,rows in [('kStaticSpecs85',static['roles']),('kExpertSpecs9',expert['roles'])]:
        lines+=[f'inline constexpr std::array<glm_gguf_named_parameters::Spec,{len(rows)}> {name}{{{{']
        for row in rows:
            dims=row['gguf_dimensions'];assert 1<=len(dims)<=3
            lines+=['  glm_gguf_named_parameters::Spec{'+quote(row['name'])+','+str(row['dtype_code'])+',{' +','.join(map(str,dims+[0]*(3-len(dims))))+'},'+str(len(dims))+','+str(row['bytes'])+'ULL},']
        lines+=['}};']
    geometry=','.join(map(str,p['geometry'][:12]))+','+','.join(map(float_literal,p['geometry'][12:]))
    moe=['glm_moe_geometry::Geometry{'+','.join(map(str,row[:4]))+','+float_literal(row[4])+','+optional(row[5])+'}'for row in p['moe_geometry']]
    lines+=['inline const glm_gguf_flash_fragment::Policy kPolicy{',
            '  .geometry={'+geometry+'},','  .moe_geometry={'+','.join(moe)+'},',
            '  .shared_swiglu_limit={'+','.join(map(optional,p['shared_swiglu_limit']))+'},',
            '  .gate_lower_bound='+float_literal(p['gate_lower_bound'])+',',
            '  .hc_epsilon='+float_literal(p['hc_epsilon'])+',',
            '  .hc_streams='+str(p['hc_streams'])+',.hc_iterations='+str(p['hc_iterations'])+',.conv_kernel='+str(p['conv_kernel'])+',.kda_depth='+str(p['kda_depth'])+',',
            '  .index_select_tail=true,.sigmoid_gating=true,.normalize_expert_weights=true};',
            'inline constexpr original_named_role_source::Identity kIdentity{kRepository,kRevision,kVariant,kFirstFile};',
            'inline constexpr hyle::compute::ModelArtifactProfileDescription kProfile{',
            '  .model_publisher="unsloth",.model_repository=kRepository,.model_family='+quote(metadata['general.architecture'])+',',
            '  .model_name='+quote(metadata['general.name'])+',.model_revision=kRevision,.configuration_digest=kConfigurationSha256,',
            '  .artifact_repository=kRepository,.artifact_revision=kRevision,.variant=kVariant,.manifest_digest=kStaticPlanSha256,.format_family="GGUF"};',
            'inline const glm_gguf_flash_source::Fixture kFixture{kIdentity,kStaticSpecs85,kExpertSpecs9,kStaticPins85,kStaticBytes,',
            '  kStaticPlanSha256,kExpertSourcePlanSha256,kProfile,kPolicy};',
            'inline const glm_gguf_flash_source::Fixture &fixture() noexcept{return kFixture;}',
            '} // namespace '+ns,'']
    output=args.output.resolve();assert output.is_relative_to(R)
    output.parent.mkdir(parents=True,exist_ok=True);output.write_text('\n'.join(lines),encoding='utf-8',newline='\n')
    evidence=dict(complete=True,repository=a.REPO,revision=a.REV,variant=a.VARIANT,
        original_roles=85,source_bytes=a.BODY,static_plan=a.identity(directory/'static-plan.json'),
        expert_source_plan=a.identity(directory/'expert-source-plan.json'),fixture_policy=a.identity(directory/'fixture-policy.json'),
        acquisition=a.identity(args.directory.resolve()/'acquisition.json'),manifest=a.identity(args.directory.resolve()/'manifest.json'),
        original_headers=[s['header']for s in expert['shards']],generated_header=a.identity(output),generator=a.identity(entry),
        common_generator=a.identity(Path(__file__)),validator=a.identity(VALIDATOR),body_rehashed=False,network_requests=0,
        expert_payload_scope='Only actual missing globalIDs, three original native packed legs/catalog112B each; no whole-bank SHA/payload.')
    a.save(output.with_suffix('.json'),evidence)
    print(json.dumps(evidence),flush=True)
