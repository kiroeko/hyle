"""B13 own-pins entry into the shared Flash build/owned-supply lifecycle."""
from pathlib import Path
import hashlib, importlib.util, sys
sys.dont_write_bytecode = True
COMMON = Path(__file__).resolve().parents[1] / 'build_flash.py'
COMMON_SHA = '7ee59dcddf0964b4adf1a33b534439af7891fcf05ec6ff6f97d07b644ac1fb0e'
if hashlib.sha256(COMMON.read_bytes()).hexdigest() != COMMON_SHA:
    raise ValueError('Frozen shared Flash build helper changed')
spec = importlib.util.spec_from_file_location('_b13_shared_flash_build', COMMON)
common = importlib.util.module_from_spec(spec)
spec.loader.exec_module(common)
if __name__ == '__main__':
    sys.exit(common.main('B13', Path(__file__)))
