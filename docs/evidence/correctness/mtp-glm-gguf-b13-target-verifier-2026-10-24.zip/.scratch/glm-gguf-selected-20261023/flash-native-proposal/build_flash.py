"""Shared B12/B13 cold build overlay; only root executes compile/link/native.

Reuse the frozen B10 host lifecycle, current parity closure and owned-process
driver. This contains no model executor, loader, HTTP implementation or pins.
Existing B12 build.py and its attempts are not modified by this proposal.
"""
from pathlib import Path
import argparse
import hashlib
import importlib.util
import json
import os
import subprocess
import sys
import xml.etree.ElementTree as ET

sys.dont_write_bytecode = True
R = next(p for p in Path(__file__).resolve().parents if (p / 'AGENTS.md').is_file())
ROOT = R / '.scratch/glm-gguf-selected-20261023'
HOST = ROOT / 'B10/native-integration/build.py'
HOST_SHA = '96f154b81677aeeccf2cfb499818e5b0ab3bb24ff6ef8740cc1207e152a4b2d2'
CURRENT = R / '.scratch/mtp-packed-head-20261024/parity-current-integration/build.py'
CURRENT_SHA = '0fc11f36aa9e669ebf3d21876ed4c10fbd863c0ee43ef0c575c07ada96c6cacc'
RUNTIME_OVERRIDE = ROOT / 'runtime_override.py'
RUNTIME_OVERRIDE_SHA = '46414bb5743db1a63c1ac17a631849a5c5688b21a44b366ad49c61503e40568d'
DRIVER = R / '.scratch/dspark-pro-target-draft-20261023/run_with_supply.py'
DRIVER_SHA = 'd3e0749a5b565717582ff33f9f02251faae5309c71b693abfd3a6e8b880be50a'
VALIDATOR = ROOT / 'B09/generate_artifacts.py'
VALIDATOR_SHA = 'c3269d20c925976748f685fcbc290f569c2e7e36eaa5b99a9d8f3e9539608583'
RECIPE = ROOT / 'flash-consumer-proposal/compile2/flash-state/identity.json'
SOURCE = R / 'tests/compute_models/glm_mtp_state_consumer_test.cc'
CONFIG = {
    'B12': ('UD-Q4_K_XL', '394df60f9336be88cf2e5edc30a0ed8745bced7194732bc4e4a6f57320c43ff6'),
    'B13': ('Q8_0', '0e25589790957fe64235035160f85d8de61f61bc2482c48b0a4070e5784c2e51'),
}


def load(name, path, pin=None):
    if pin is not None and hashlib.sha256(path.read_bytes()).hexdigest() != pin:
        raise ValueError('Frozen helper changed: ' + str(path))
    spec = importlib.util.spec_from_file_location(name, path)
    value = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(value)
    return value


class FlashBuild:
    def __init__(self, artifact, entry):
        variant, self.acquire_sha = CONFIG[artifact]
        self.artifact, self.entry = artifact, Path(entry).resolve()
        self.data, self.stage = ROOT / artifact, ROOT / artifact / 'native-integration'
        self.header = self.data / 'generated' / ('glm_gguf_' + artifact.lower() + '_artifacts.h')
        self.contract = dict(repository='unsloth/GLM-5.3-Flash-GGUF',
            revision='621d456e93e926e4b52f85cff5f634358c1828f9', variant=variant,
            original_roles=85, source_bytes=1892821552)

    def acquisition(self):
        return load('_flash_owned_acquisition', self.data / 'acquire.py', self.acquire_sha).configured()

    def pins(self):
        if not self.header.is_file() or not self.header.with_suffix('.json').is_file():
            raise RuntimeError(self.artifact + ' complete real85-role generated pins are required')
        a = self.acquisition()
        validator = load('_flash_complete_source', VALIDATOR, VALIDATOR_SHA)
        validator.S, validator.R, validator.acquisition = self.data, R, lambda: a
        _, _, _, expert = validator.validate(self.data / 'original-static')
        proof = a.read(self.header.with_suffix('.json'))
        if not proof['complete'] or any(proof.get(k) != v for k, v in self.contract.items()):
            raise ValueError('Generated Flash fixture has a different original identity/extent')
        for key, path in [('static_plan', self.data / 'static-plan.json'),
            ('expert_source_plan', self.data / 'expert-source-plan.json'),
            ('fixture_policy', self.data / 'fixture-policy.json'),
            ('acquisition', self.data / 'original-static/acquisition.json'),
            ('manifest', self.data / 'original-static/manifest.json'),
            ('generated_header', self.header), ('generator', self.data / 'generate_artifacts.py'),
            ('common_generator', ROOT / 'generate_flash_artifacts.py'), ('validator', VALIDATOR)]:
            if proof[key] != a.identity(path):
                raise ValueError('Actual Flash fixture/source receipt changed: ' + key)
        if len(expert['roles']) != 9 or expert['typed_catalog']['bytes'] != 112:
            raise ValueError('Flash needs three actual three-leg expert sections')
        return self.header, self.header.with_suffix('.json'), dict(**self.contract,
            static_plan=a.identity(self.data / 'static-plan.json'),
            expert_plan=a.identity(self.data / 'expert-source-plan.json'),
            acquisition=a.identity(self.data / 'original-static/acquisition.json'),
            manifest=a.identity(self.data / 'original-static/manifest.json'), body_rehashed=False)

    def configured(self):
        c = load('_flash_existing_host_lifecycle', HOST, HOST_SHA)
        current = load('_flash_current_parity_closure', CURRENT, CURRENT_SHA)
        runtime_override = load('_flash_actual_cpu_runtime', RUNTIME_OVERRIDE, RUNTIME_OVERRIDE_SHA)
        c.S, c.DATA, c.SOURCE = self.stage, self.data, SOURCE
        c.RECIPE = self.stage / 'prepared-flash-recipe.json'
        c.BASE = c.BASE_IMAGE = CURRENT.parent / 'current-link1'
        def closure():
            result = list(current.closure(consumer_replaced=True))
            c.RETIRED_BASE_CONSUMER = result[0]['retired_base_consumer']
            result[2] = runtime_override.override(result[2], self.stage / 'runtime-avx2.json')
            return tuple(result)
        c.closure, c.native_inputs, c.pins = closure, current.base.native_inputs, self.pins
        # B10.link records this exact manifest at its new stage. Keep bytes
        # unchanged and retain all original object/source/recipe identities.
        native = ROOT / 'B10/native-integration/native-inputs.json'
        self.native_manifest, self.native_manifest_sha = native, c.NATIVE_INPUTS_SHA
        return c

    def compile(self, c, attempt):
        self.pins()
        c.RECIPE = self.stage / f'prepared-flash-recipe{attempt}.json'
        recipe = c.read(RECIPE)
        command = [x for x in recipe['command'] if not x.startswith(
            ('/DHYLE_TEST_GLM_Q30_', '/DHYLE_TEST_GLM_B12_', '/DHYLE_TEST_GLM_B13_'))]
        command.insert(1, '/DHYLE_TEST_GLM_' + self.artifact + '_ARTIFACTS_HEADER="' + self.header.as_posix() + '"')
        prepared = dict(command=command, source=c.identity(SOURCE), historical_recipe=c.identity(RECIPE), prepared_only=True)
        if c.RECIPE.exists():
            if c.read(c.RECIPE) != prepared:
                raise ValueError('Immutable Flash prepared recipe differs')
        else:
            c.save(c.RECIPE, prepared)
        c.compile_one(attempt)
        path = self.stage / f'compile{attempt}/glm-pro/identity.json'
        record = c.check_record(path)
        record.update(artifact=self.artifact, entry=c.identity(self.entry), flash_helper=c.identity(Path(__file__)),
            shared_helper=c.identity(HOST), source_scope='Actual own Flash fixture; shared glm-pro tag only names its output directory.')
        c.save(path, record)

    def link(self, c, attempt, compile_attempt):
        if hashlib.sha256(self.native_manifest.read_bytes()).hexdigest() != self.native_manifest_sha:
            raise ValueError('Original native2 metadata manifest changed')
        target = self.stage / 'native-inputs.json'
        self.stage.mkdir(parents=True, exist_ok=True)
        if target.exists():
            if target.read_bytes() != self.native_manifest.read_bytes():
                raise ValueError('Stage native manifest differs')
        else:
            target.write_bytes(self.native_manifest.read_bytes())
        c.link(attempt, compile_attempt)
        out = self.stage / f'tests-link{attempt}'
        plan = c.read(out / 'link-plan.json')
        plan.update(artifact=self.artifact, entry=c.identity(self.entry), flash_helper=c.identity(Path(__file__)),
            source_contract=self.contract, retired_base_consumer=c.RETIRED_BASE_CONSUMER,
            note='Own Flash fixture on current parity/tail closure; exactly one consumer TU replaces the base Flash consumer.')
        c.save(out / 'link-plan.json', plan)
        ready = c.read(out / 'ready.json')
        ready.update(link_plan=c.identity(out / 'link-plan.json'), artifact=self.artifact,
            scope='Own complete85-role source; linked only, no native result is implied.')
        c.save(out / 'ready.json', ready)

    def run(self, c, args):
        self.pins()
        out = self.stage / f'checks{args.run_attempt}-{args.backend}'
        out.mkdir(exist_ok=False)
        image_dir = self.stage / f'tests-link{args.link_attempt}'
        ready = c.read(image_dir / 'ready.json')
        for key in ('image', 'link_plan', 'runtime_environment', 'consumer_record'):
            c.require(ready[key])
        c.check_record(c.resolve(ready['consumer_record']['path']))
        runtime = c.read(image_dir / 'runtime-environment.json')
        for row in runtime['staged_dlls']:
            c.require(row)
        case = 'GlmMtpStateConsumer.' + args.backend.title() + self.artifact + 'OriginalGgufTarget43And44AndNextNFullVocabularyVerifier'
        command = [sys.executable, str(self.entry), 'owned', '--image', ready['image']['path'],
            '--frontier-file', str(out / 'frontier.json'), '--', '--gtest_filter=' + case,
            '--gtest_throw_on_failure=1', '--gtest_output=xml:' + str(out / 'results.xml')]
        env = {k: v for k, v in os.environ.items() if not k.startswith('HYLE_GLM_')}
        env.update(PATH=runtime['PATH'], OMP_NUM_THREADS='4', MKL_NUM_THREADS='4', OPENBLAS_NUM_THREADS='4')
        env['HYLE_GLM_' + self.artifact + '_ORIGINAL_DIR'] = str(self.data / 'original-static')
        env['HYLE_GLM_' + self.artifact + '_EXPERT_DIR'] = str(self.data / 'original-experts')
        c.save(out / 'plan.json', dict(command=command, image=ready['image'], consumer_record=ready['consumer_record'],
            entry=c.identity(self.entry), flash_helper=c.identity(Path(__file__)), source_contract=self.contract, case=case))
        q = load('_flash_existing_execute', R / '.scratch/qwen-mtp-quality-20261022/run_quality.py')
        process = q.execute(command, env, out / 'run', timeout=args.timeout)
        result = dict(process=process, passed=False, image=ready['image'], consumer_record=ready['consumer_record'],
            throughput_evidence=False, memory_evidence=False)
        try:
            if process['exit'] or process['timed_out']:
                raise RuntimeError('Owned native/supply process failed')
            driver = c.read(out / 'frontier.driver.json')
            if driver['native']['exit'] or driver['native']['stopped_by_driver'] or driver['job_cleanup']['remaining_descendants'] != 0:
                raise ValueError('Native tree did not retire successfully')
            if any(row['exit'] or row.get('stopped_by_driver', False) for row in driver['fetches']):
                raise ValueError('Actual expert supply failed')
            if not (R / '.scratch/mtp-download-budget-20261023/PAUSED').is_file():
                raise ValueError('Budget pause must be restored')
            tree = ET.parse(out / 'results.xml').getroot()
            cases = list(tree.iter('testcase'))
            if len(cases) != 1 or any(int(tree.get(k, '0')) for k in ('failures', 'errors', 'disabled')) or list(tree.iter('skipped')) or list(tree.iter('failure')):
                raise ValueError('Expected exactly one passing own Flash case')
            item = cases[0]
            if item.get('classname') + '.' + item.get('name') != case or item.get('status') != 'run' or item.get('result') != 'completed':
                raise ValueError('Exact own Flash case differs')
            properties = {x.get('name'): x.get('value') for x in item.iter('property')}
            expected = dict(artifact_repository=self.contract['repository'], artifact_revision=self.contract['revision'],
                artifact_variant=self.contract['variant'], static_original_roles='85', static_original_bytes='1892821552',
                expert_domain='288', resident_experts='8', expert_planes='3',
                static_source_plan_sha256=c.identity(self.data / 'static-plan.json')['sha256'],
                expert_source_plan_sha256=c.identity(self.data / 'expert-source-plan.json')['sha256'])
            if any(properties.get(k) != v for k, v in expected.items()) or int(properties['actual_submissions']) <= 0:
                raise ValueError('Actual static/expert identity or graph count differs')
            c.check_record(c.resolve(ready['consumer_record']['path']))
            result.update(passed=True, case=case, tests=1, failures=0, skips=0, properties=properties,
                actual_graph_submissions=int(properties['actual_submissions']), driver=c.identity(out / 'frontier.driver.json'))
        except Exception as error:
            result['error'] = dict(type=type(error).__name__, message=str(error))
        c.save(out / 'summary.json', result)
        if not result['passed']:
            raise SystemExit(process['exit'] or 1)
        print('PASSED actual', self.artifact, args.backend, flush=True)

    def owned(self, argv):
        driver = load('_flash_owned_tree', DRIVER, DRIVER_SHA)
        driver.S, driver.R = self.data, R
        driver.DOMAIN, driver.SECTIONS = 288, ('nextn', 'target43', 'target44')
        driver.FETCH_SCRIPT = self.entry
        driver.WAIT_ENV = 'HYLE_GLM_GGUF_FLASH_WAIT_FOR_EXPERTS'
        driver.FRONTIER_ENV = 'HYLE_GLM_GGUF_FLASH_FRONTIER_FILE'
        sys.argv = [str(self.entry), *argv]
        return driver.main()

    def supply(self, argv):
        parser = argparse.ArgumentParser(description='One actual Flash frontier to existing bounded budget batch')
        parser.add_argument('--frontier-file', type=Path, required=True)
        parser.add_argument('--plan-only', action='store_true')
        args = parser.parse_args(argv)
        raw = args.frontier_file.read_bytes()
        if not 0 < len(raw) <= 65536:
            raise ValueError('Flash frontier exceeds bounded metadata')
        request = json.loads(raw)
        for key in ('missing_ids', 'global_ids'):
            values = request[key]
            if not isinstance(values, list) or not 1 <= len(values) <= 8 or values != sorted(set(values)) or any(type(n) is not int or not 0 <= n < 288 for n in values):
                raise ValueError('Flash needs actual sorted unique1..8 IDs')
        if request['section'] not in ('nextn', 'target43', 'target44') or type(request['stage']) is not int or request['stage'] != 0 or not set(request['missing_ids']) <= set(request['global_ids']):
            raise ValueError('Actual Flash section/stage/IDs differ')
        a = self.acquisition()
        a.checked()
        section, ids = request['section'], request['missing_ids']
        if args.plan_only:
            print(json.dumps(dict(section=section, stage=0, global_ids=ids, roles=3 * len(ids), typed_catalog_bytes_per_id=112,
                maximum_body_bytes=a.SECTION[section][1] * len(ids), source_plan=a.identity(self.data / 'expert-source-plan.json'), network_requests=0)))
            return 0
        label, attempt = section + '-' + '-'.join(map(str, ids)), 1
        while (self.data / 'frontier-plans' / f'{label}-attempt{attempt}.json').exists() or (self.data / 'batches' / f'{label}-attempt{attempt}').exists():
            attempt += 1
        plan = self.data / 'frontier-plans' / f'{label}-attempt{attempt}.json'
        script = self.data / 'acquire.py'
        subprocess.run([sys.executable, str(script), 'experts', '--section', section, '--ids', *map(str, ids),
            '--attempt', str(attempt), '--write-batch-plan', str(plan)], cwd=R, check=True)
        frozen = a.read(plan)
        if frozen['script_sha256'] != hashlib.sha256(script.read_bytes()).hexdigest():
            raise ValueError('Own Flash acquisition adapter changed after plan preparation')
        return subprocess.run([sys.executable, str(R / '.scratch/mtp-download-budget-20261023/run_batch.py'), str(plan)], cwd=R).returncode


def main(artifact, entry):
    job = FlashBuild(artifact, entry)
    argv = sys.argv[1:]
    if argv and argv[0] == '--frontier-file':
        return job.supply(argv)  # Existing owned driver invokes its fixed FETCH_SCRIPT this way.
    if argv and argv[0] == 'owned':
        return job.owned(argv[1:])
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action', choices=('plan', 'compile', 'link', 'run'))
    parser.add_argument('--compile-attempt', type=int, default=1)
    parser.add_argument('--link-attempt', type=int, default=1)
    parser.add_argument('--run-attempt', type=int, default=1)
    parser.add_argument('--backend', choices=('cpu', 'cuda'), default='cpu')
    parser.add_argument('--timeout', type=int, default=14400)
    args = parser.parse_args(argv)
    if min(args.compile_attempt, args.link_attempt, args.run_attempt, args.timeout) <= 0:
        raise ValueError('Positive attempts/timeout required')
    if args.action == 'plan':
        print(json.dumps(dict(artifact=artifact, source_contract=job.contract, header=str(job.header),
            actual_pins_present=job.header.is_file(), stage=str(job.stage), consumer_TUs=1, product_TUs=0,
            SDK_builds=0, NVCC_builds=0, base=str(CURRENT.parent / 'current-link1'),
            builds=0, native_runs=0, HTTP=0)))
        return 0
    c = job.configured()
    if args.action == 'compile':
        job.compile(c, args.compile_attempt)
    elif args.action == 'link':
        job.link(c, args.link_attempt, args.compile_attempt)
    else:
        job.run(c, args)
    return 0
