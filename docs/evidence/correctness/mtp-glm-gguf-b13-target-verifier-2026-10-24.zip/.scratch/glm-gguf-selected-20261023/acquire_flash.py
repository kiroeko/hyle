"""B12/B13 metadata and cold configuration; reuse B09 acquisition unchanged.

No HTTP at import, configured(), --plan-only or --write-batch-plan. Missing
actual headers fail before any transport/downloader can be opened. No complete
expert bank is a payload requirement. Three outer IDs / serial three legs.
"""
from pathlib import Path
import hashlib
import importlib.util
import math
import re
import struct
import sys
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent
R=S.parents[1]
BASE=S/'B09/acquire.py'
BASE_SHA='6c79213014eebd58436e50ce44dc821408431838851ee5c8407d1a36d87761fb'
REPO='unsloth/GLM-5.3-Flash-GGUF'
REV='621d456e93e926e4b52f85cff5f634358c1828f9'
SECTIONS={'target43':43,'target44':44,'nextn':45}
PARSER=R/'.scratch/mtp-artifact-schema-20261023/gguf_metadata.py'
PARSER_SHA='e3204073182c535c03570ad3b13e6ac51dfc8b5f6998f2cc5e6c38a55daf3f8f'
SOURCE={
 'model':('.scratch/inference-single-machine/llama.cpp/src/models/glm5-next.cpp','0617e903bd3949716ace4a7ffe5cade84dc04d8b94cd6c1db5515b5878c22e0a'),
 'defaults':('.scratch/inference-single-machine/llama.cpp/src/llama-hparams.h','dbf87ac4e0b9390a12b48dc1fcd7c082c9225b30221bf0d574ac0923cc5a7575'),
 'keys':('.scratch/inference-single-machine/llama.cpp/src/llama-arch.cpp','7c558709ae432728cb73bef958f25c584dd0cf47cf429122b63c021216c4a65a'),
}

def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def module(name,path):
    spec=importlib.util.spec_from_file_location(name,path)
    m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m

def f32(value):
    assert type(value) in (int,float) and math.isfinite(value)
    return struct.unpack('<f',struct.pack('<f',value))[0]

def derive_policy(metadata):
    """Own raw header values plus named fixed-reader defaults, never dtype inference."""
    assert metadata['general.architecture']=='glm5next'
    used={};defaults={};prefix='glm5next.'
    def get(key):
        name=prefix+key
        assert name in metadata,'Actual GGUF policy key is missing: '+name
        used[name]=metadata[name];return metadata[name]
    layers=get('block_count');assert type(layers) is int and layers==46
    def at(key,layer,default=None,optional=False):
        name=prefix+key
        if name not in metadata:
            assert optional,'Actual GGUF per-layer policy is missing: '+name
            defaults[name]=default;return default
        value=get(key)
        if isinstance(value,list):
            assert len(value)==layers,'Actual per-layer array length differs: '+name
            return value[layer]
        return value
    def integer(key):
        value=get(key);assert type(value) is int and value>=0;return value
    hidden=integer('embedding_length');heads=at('attention.head_count',43)
    assert type(heads) is int and heads==at('attention.head_count',45)
    assert [at('attention.head_count_kv',i)for i in SECTIONS.values()]==[1,0,1]
    assert integer('nextn_predict_layers')==1
    rope=integer('rope.dimension_count');nope=integer('attention.key_length_mla')-rope
    latent=integer('attention.kv_lora_rank');value=integer('attention.value_length_mla')
    assert integer('attention.key_length')==latent+rope and integer('attention.value_length')==latent
    query_rank=integer('attention.q_lora_rank');vocabulary=integer('vocab_size')
    index_depth=integer('attention.indexer.key_length');index_heads=integer('attention.indexer.head_count')
    pool=integer('attention.indexer.kpool');top=integer('attention.indexer.top_k')
    rms=f32(get('attention.layer_norm_rms_epsilon'));index_eps=f32(get('attention.layer_norm_epsilon'))
    geometry=[hidden,query_rank,heads,nope,rope,latent,value,vocabulary,index_depth,index_heads,pool,top,
              rms,index_eps,f32(1/math.sqrt(nope+rope))]
    assert geometry==[4096,1536,64,256,0,512,256,154880,128,32,4,2048,f32(1e-5),f32(1e-6),f32(1/16)],'Actual geometry is outside the current shared Flash pure implementation'
    selected_tail=at('attention.indexer.kpool_select_tail',43,True,True)
    assert type(selected_tail) is bool and selected_tail is True
    if prefix+'attention.indexer.types' in metadata:
        kinds=get('attention.indexer.types')
        if isinstance(kinds,list):
            # The fixed loader reads indexer.types for n_layer(), excluding NextN.
            assert len(kinds)==layers-1
            assert type(kinds[43]) in (int,bool) and kinds[43] in (1,True)
        else:assert type(kinds) in (int,bool) and kinds in (1,True)
    else:
        defaults[prefix+'attention.indexer.types']='all1, fixed model loader initializes full implementations'
    domain=integer('expert_count');slots=integer('expert_used_count')
    assert domain==288 and slots==8 and integer('expert_shared_count')==1
    scale=f32(get('expert_weights_scale'));assert scale>0
    normalize=get('expert_weights_norm');assert type(normalize) is bool and normalize
    gate=at('expert_gating_func',43,0,True)
    assert type(gate) is int and gate in (0,2),'Current pure route requires actual sigmoid gating'
    # Reader treats NONE(0) as SIGMOID(2). This is an explicit source default.
    if gate==0:defaults['expert_gating_func_effective']=2
    def clamp(raw):
        x=f32(raw)
        return x if x>f32(1e-6) else None
    routed=[clamp(at('swiglu_clamp_exp',i))for i in SECTIONS.values()]
    if prefix+'swiglu_clamp_shexp' in metadata:
        shared=[clamp(at('swiglu_clamp_shexp',i))for i in SECTIONS.values()]
    else:
        shared=routed.copy();defaults[prefix+'swiglu_clamp_shexp']='copy original routed clamp array, model loader lines35-36'
    moe=[]
    for i,limit in zip(SECTIONS.values(),routed,strict=True):
        intermediate=at('expert_feed_forward_length',i)
        assert type(intermediate) is int and intermediate==2048
        moe.append([hidden,intermediate,domain,slots,scale,limit])
    hc_eps=f32(get('hyper_connection.epsilon'));streams=integer('hyper_connection.count')
    iterations=integer('hyper_connection.sinkhorn_iterations');conv=integer('ssm.conv_kernel')
    depth=integer('kda.head_dim');bound=f32(get('kda.gate_lower_bound'))
    assert (hc_eps,streams,iterations,conv,depth)==(f32(1e-6),4,20,4,128) and bound<0
    return dict(geometry=geometry,moe_geometry=moe,shared_swiglu_limit=shared,gate_lower_bound=bound,
        hc_epsilon=hc_eps,hc_streams=streams,hc_iterations=iterations,conv_kernel=conv,kda_depth=depth,
        index_select_tail=selected_tail,sigmoid_gating=True,normalize_expert_weights=normalize,
        actual_keys=used,reader_defaults=defaults,
        runtime_storage='Explicit converted-GGUF F32 activation/hidden/journal/main/plain-index runtime; not inferred from weight dtype.')

def configured(identity,entry):
    assert identity in ('B12','B13')
    directory=S/identity
    required=[directory/n for n in ('summary.json','roles-plan.json','static-plan.json')]
    absent=[str(p.relative_to(R))for p in required if not p.is_file()]
    if absent:
        raise FileNotFoundError('Actual independent GGUF headers are required before body planning/HTTP; missing: '+', '.join(absent))
    assert sha(BASE)==BASE_SHA and sha(PARSER)==PARSER_SHA
    common=module('_flash_existing_b09_acquisition',BASE)
    common.S,common.R=directory,R
    common.__file__=str(entry);common.__doc__=__doc__
    common.REPO,common.REV,common.VARIANT=REPO,REV,'UD-Q4_K_XL'if identity=='B12'else'Q8_0'
    common.COUNT,common.BODY,common.DOMAIN=85,1892821552,288
    schema=common.read(directory/'roles-schema.json')
    common.SECTION={name:(layer,schema['expert_bytes_per_id'][f'layer{layer}'])for name,layer in SECTIONS.items()}
    common.HELPERS=dict(common.HELPERS,acquisition_base=(BASE.relative_to(R).as_posix(),BASE_SHA),
                        metadata_parser=(PARSER.relative_to(R).as_posix(),PARSER_SHA),
                        flash_acquisition=(Path(__file__).relative_to(R).as_posix(),sha(Path(__file__))))
    for key,(path,pin)in SOURCE.items():
        assert sha(R/path)==pin,'Fixed reader/default source changed: '+key
    parser=module('_flash_cached_structural_reader',PARSER)
    def checked():
        proof,static,roles,schema,need=[common.read(directory/n)for n in
            ('summary.json','static-plan.json','roles-plan.json','roles-schema.json','headers-needed.json')]
        assert schema['id']==identity and schema['repository']==REPO and schema['revision']==REV and schema['variant']==common.VARIANT
        assert common.identity(R/need['evidence']['path'])==need['evidence']==schema['evidence']
        assert proof['complete'] and proof['metadata_only'] and proof['tensor_payload_bytes']==0
        assert proof['metadata_limit_is_hard_upper_bound'] is True
        assert proof['maximum_metadata_bytes']==need['metadata_upper_bound_bytes']
        assert proof['actual_header_bytes']==sum(x['header']['bytes']for x in proof['headers'])<=proof['maximum_metadata_bytes']
        assert 0<=proof['new_requested_bytes']<=proof['maximum_metadata_bytes']
        assert proof['static_plan']==common.identity(directory/'static-plan.json') and proof['roles_plan']==common.identity(directory/'roles-plan.json')
        assert static['source_schema']==roles['source_schema']==common.identity(directory/'roles-schema.json')
        assert schema['physical_role_count']==roles['original_roles']==len(roles['roles'])==94
        assert schema['static_roles']==static['original_roles']==len(static['roles'])==85
        assert schema['static_bytes']==static['source_bytes']==sum(r['bytes']for r in static['roles'])==common.BODY
        assert static['roles']==[r for r in roles['roles']if not r['selected_source']]
        assert roles['full_expert_banks_acquire'] is False and len({r['name']for r in roles['roles']})==94
        shards,tables,actual_metadata={},{},{}
        for plan in (static,roles):
            assert (plan['repository'],plan['revision'],plan['variant'])==(REPO,REV,common.VARIANT)
            assert plan['complete_absolute_ranges'] and plan['http_identity_authenticated'] and plan['metadata_only']
            assert plan['whole_shards_downloaded'] is False and plan['shards']==proof['headers']
        assert [s['shard']for s in proof['headers']]==[x['shard']for x in need['files']]
        for source in proof['headers']:
            wanted=next(x for x in need['files']if x['shard']==source['shard'])
            assert source['complete'] and source['schema_validated'] and source['http_status']==206 and source['tensor_payload_bytes']==0
            assert (source['repository'],source['revision'])==(REPO,REV) and source['file']==wanted['file']
            assert source['url']==f'https://huggingface.co/{REPO}/resolve/{REV}/{source["file"]}'
            assert re.fullmatch('"[0-9a-f]{64}"',source['etag'])
            for key in ('header','physical_table','acquired_receipt'):
                assert common.identity(R/source[key]['path'])==source[key]
            raw=(R/source['header']['path']).read_bytes();table=common.read(R/source['physical_table']['path'])
            assert source['actual_tensor_count']==wanted['expected_tensor_count']
            metadata,parsed,count=parser.parse_header(raw,source['actual_tensor_count'],len(raw),set(table['metadata']),whole_file_bytes=source['whole_file_bytes'])
            assert metadata==table['metadata'] and count==source['metadata_count']
            parsed_table=[]
            for row in parsed:
                dtype,block,size=common.TYPES[row['dtype_code']]
                assert row['shape'][0]%block==0
                parsed_table.append(dict(row,dtype=dtype,bytes=math.prod(row['shape'])//block*size))
            assert parsed_table==table['tensors']
            assert (source['data_base']==len(raw))if parsed else source['data_base'] is None
            assert len(raw)<=wanted['metadata_limit_bytes'] and len(raw)==source['metadata_bytes']
            tables[source['shard']]={row['name']:row for row in parsed_table};shards[source['shard']]=source
            actual_metadata[str(source['shard'])]=metadata
        assert roles['actual_metadata']==static['actual_metadata']==actual_metadata
        for row,wanted in zip(roles['roles'],schema['roles'],strict=True):
            source=shards[row['source_shard']];physical=tables[row['source_shard']][row['name']]
            for key in ('name','section','dtype','dtype_code','gguf_dimensions','bytes','source_shard','source_file','selected_source','expert_bytes'):
                assert row[key]==wanted[key]
            dtype,block,size=common.TYPES[row['dtype_code']]
            assert (physical['dtype'],physical['dtype_code'],physical['shape'],physical['bytes'])==(dtype,row['dtype_code'],row['gguf_dimensions'],row['bytes'])
            first=source['data_base']+physical['offset']
            assert row['data_relative_half_open']==[physical['offset'],physical['offset']+row['bytes']]
            assert row['absolute_inclusive']==[first,first+row['bytes']-1] and first+row['bytes']<=source['whole_file_bytes']
            assert row['source_file']==source['file'] and row['filename']==row['name']+'.bin' and Path(row['filename']).name==row['filename']
            if row['selected_source']:
                assert len(physical['shape'])==3 and physical['shape'][2]==288
                assert row['expert_bytes']*288==row['bytes'] and row['dtype_code']in(8,12,13,14)
            else:assert row['dtype_code']in(0,8)
        banks=[row for row in roles['roles']if row['selected_source']];assert len(banks)==9
        sections={}
        for section,layer in SECTIONS.items():
            selected=[r for r in banks if r['name'].startswith(f'blk.{layer}.')]
            assert {r['name']for r in selected}=={f'blk.{layer}.ffn_{leg}_exps.weight'for leg in common.LEGS}
            size=sum(r['expert_bytes']for r in selected)
            assert size==schema['expert_bytes_per_id'][f'layer{layer}'];sections[section]=(layer,size)
        common.SECTION=sections
        policy=derive_policy(actual_metadata['1'])
        for key,(path,pin)in common.HELPERS.items():assert common.identity(R/path)['sha256']==pin,'Frozen helper changed: '+key
        expert=dict(repository=REPO,revision=REV,variant=common.VARIANT,source_format='GGUF_ORIGINAL_PACKED',
            original_roles=9,expert_domain=288,runtime_slots=8,stage=0,full_expert_banks_acquire=False,whole_bank_sha256_required=False,
            source_roles_plan=common.identity(directory/'roles-plan.json'),source_schema=roles['source_schema'],shards=roles['shards'],roles=banks,
            leg_order=list(common.LEGS),sections={s:dict(layer=v[0],per_id_payload_bytes=v[1])for s,v in sections.items()},
            typed_catalog=dict(magic='HYDSPT01',version=1,roles=3,bytes=112),scope='Only actual section/global IDs, three original native packed legs; no whole-bank payload/hash.')
        common.retain(directory/'expert-source-plan.json',expert)
        common.retain(directory/'fixture-policy.json',dict(repository=REPO,revision=REV,variant=common.VARIANT,
            source_roles_plan=common.identity(directory/'roles-plan.json'),source_headers=[s['header']for s in roles['shards']],
            policy=policy,reader_sources={k:common.identity(R/v[0])for k,v in SOURCE.items()},network_requests=0))
        return static,expert,shards
    common.checked=checked
    selected_plan=common.per_id_plan
    def per_id_plan(expert,section,global_id,directory):
        result=selected_plan(expert,section,global_id,directory)
        result['source_format']='GGUF_ORIGINAL_PACKED'
        return result
    common.per_id_plan=per_id_plan
    return common

def main(identity,entry):configured(identity,entry).main()
