"""B13 adapter for the same finite publisher; missing actual pins/runs are hard failures."""
from pathlib import Path
import importlib.util
import sys
sys.dont_write_bytecode = True
path = Path(__file__).resolve().parents[2] / 'publish_flash.py'
spec = importlib.util.spec_from_file_location('_b13_flash_publisher', path)
publisher = importlib.util.module_from_spec(spec)
spec.loader.exec_module(publisher)
if __name__ == '__main__': publisher.main('B13')
