"""B13 own-pins entry into the shared Flash build/owned-supply lifecycle."""
from pathlib import Path
import hashlib, importlib.util, sys
sys.dont_write_bytecode = True
COMMON = Path(__file__).resolve().parents[1] / 'build_flash.py'
COMMON_SHA = 'eb4c99fcb60ac98ffb1ea31bacc6987471befa60904137156b2fc1d0ac418084'
if hashlib.sha256(COMMON.read_bytes()).hexdigest() != COMMON_SHA:
    raise ValueError('Frozen shared Flash build helper changed')
spec = importlib.util.spec_from_file_location('_b13_shared_flash_build', COMMON)
common = importlib.util.module_from_spec(spec)
spec.loader.exec_module(common)
if __name__ == '__main__':
    sys.exit(common.main('B13', Path(__file__)))
