"""B13-only orchestration over the frozen Flash metadata/Archive validators."""
import argparse
from datetime import datetime, timezone
import importlib.util
import json
from pathlib import Path
import sys
import zipfile

sys.dont_write_bytecode = True
S = Path(__file__).resolve().parents[2]
R = S.parents[1]
A = S / 'B13'
N = A / 'native-integration'
D = R / 'docs/evidence/correctness'
COMMON = S / 'publish_flash.py'
COMMON_SHA = '99f17352a61de12270b611f3998f176fa641fd7db606154288ccb9be16caa496'
RUNTIME = S / 'runtime_override.py'
RUNTIME_SHA = '46414bb5743db1a63c1ac17a631849a5c5688b21a44b366ad49c61503e40568d'
B10 = D / 'mtp-glm-gguf-b10-target-verifier-2026-10-24.json'
B10_SHA = 'a63e2799b8349923e32a07fc6d1022be55b47febd1dc6d1d2715f7ac7d2e23a9'


def load(name, path, expected):
    import hashlib
    if hashlib.sha256(path.read_bytes()).hexdigest() != expected:
        raise ValueError('Frozen helper/proof changed: ' + str(path))
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def compile_helper(h, info, snapshot, archive):
    current = h.identity(info['path'])
    if all(current[k] == info[k] for k in ('bytes', 'sha256')):
        archive.add(h.resolve(info['path']))
        return dict(recorded=info, source_is_current=True)
    old = h.identity(snapshot)
    if any(old[k] != info[k] for k in ('bytes', 'sha256')):
        raise ValueError('Exact compile-time helper snapshot differs: ' + info['path'])
    archive.add(snapshot)
    return dict(recorded=info, archived_copy=old, source_is_current=False,
                meaning='Original compile helper bytes; current link helper is separately recorded.')


def completed_run(h, backend, attempt, ready, archive, contract):
    folder = N / f'checks{attempt}-{backend}'; path = folder / 'plan.json'
    original_read = h.read; actual = original_read(path)
    for key in ('entry', 'flash_helper'):
        h.require(actual[key]); archive.add(h.resolve(actual[key]['path']))
    command = original_read(folder / 'run/process.json')['command']
    if len(command) < 3 or h.resolve(command[1]) != h.resolve(actual['entry']['path']) or command[2] != 'owned':
        raise ValueError('B13 process did not invoke its actual entry owned subcommand')
    if 'owned_entry' in actual: raise ValueError('Unexpected B13 original run-plan schema')
    # B13 uses one real entry for both commands. Only this in-memory source-key
    # alias adapts the B12 validator; original plan/process/history stay intact.
    adapted = dict(actual, owned_entry=actual['entry'])
    h.read = lambda p: adapted if h.resolve(p) == path.resolve() else original_read(p)
    try: return h.completed_run(A, backend, attempt, ready, archive, contract)
    finally: h.read = original_read


def main():
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument('--cpu-run', type=int, required=True)
    cli.add_argument('--cuda-run', type=int, required=True)
    cli.add_argument('--compile-attempt', type=int, default=1)
    cli.add_argument('--link-attempt', type=int, default=1)
    cli.add_argument('--source-root', type=Path, action='append', default=[])
    args = cli.parse_args()
    if min(args.cpu_run, args.cuda_run, args.compile_attempt, args.link_attempt) <= 0:
        raise ValueError('Positive actual attempts required')
    h = load('_b13_frozen_flash_publisher', COMMON, COMMON_SHA)
    tools = load('_b13_frozen_archive', h.ARCHIVE_TOOL, h.ARCHIVE_SHA)
    tools.S = A
    archive = tools.Archive([p.resolve() for p in args.source_root])
    for path in (Path(__file__), COMMON, h.ARCHIVE_TOOL): archive.add(path)
    contract = h.CONTRACTS['B13']
    static = h.static_set(A, contract, archive)
    image_dir = N / f'tests-link{args.link_attempt}'
    ready = h.read(image_dir / 'ready.json')
    for key in ('link_plan', 'runtime_environment', 'consumer_record'):
        h.require(ready[key]); archive.add(h.resolve(ready[key]['path']))
    h.extent(ready['image'])
    link = h.read(image_dir / 'link-plan.json')
    linked = h.read(image_dir / 'link.result.json')
    record_path = N / f'compile{args.compile_attempt}/glm-pro/identity.json'
    if linked['exit'] != 0 or linked['command'] != link['command'] or h.resolve(ready['consumer_record']['path']) != record_path.resolve():
        raise ValueError('B13 actual link or selected consumer attempt differs')
    compiled = h.read(record_path)
    result = h.read(record_path.parent / 'compile.result.json')
    if result['exit'] != 0 or result['command'] != compiled['command']:
        raise ValueError('Actual single-consumer compilation did not pass')
    before = N / 'runtime-override-source-before'
    compile_helpers = {
        'entry': compile_helper(h, compiled['entry'], before / 'B13-build.py', archive),
        'flash_helper': compile_helper(h, compiled['flash_helper'], before / 'build_flash.py', archive),
    }
    h.require(compiled['shared_helper']); archive.add(h.resolve(compiled['shared_helper']['path']))
    for key in ('entry', 'flash_helper'):
        h.require(link[key]); archive.add(h.resolve(link[key]['path']))
    h.require(compiled['actual_pins'], A / 'generated/glm_gguf_b13_artifacts.h')
    h.require(compiled['actual_pin_receipt'], A / 'generated/glm_gguf_b13_artifacts.json')
    if h.resolve(compiled['actual_pin_receipt']['path']) != h.resolve(static['pins']['path']):
        raise ValueError('Compiled B13 pins are not this own source manifest')
    for key in ('static_plan', 'expert_plan', 'acquisition', 'manifest'):
        h.require(compiled['actual_static'][key])
    if not any(h.resolve(p['path']) == h.resolve(compiled['actual_pins']['path']) and p['sha256'] == compiled['actual_pins']['sha256'] for p in compiled['dependencies']):
        raise ValueError('Actual generated pins missing from compiler dependencies')
    for info in (compiled['source'], *compiled['dependencies']): archive.source(info, record_path)
    archive.metadata_tree(record_path.parent)
    for info in link['retained_current_records']:
        h.require(info); archive.add(h.resolve(info['path']))
    h.require(link['retained_native_inputs']); archive.add(h.resolve(link['retained_native_inputs']['path']))
    native = load('_b13_actual_runtime', RUNTIME, RUNTIME_SHA)
    runtime_proof = native.verify(image_dir / 'runtime-environment.json')
    archive.add(RUNTIME)
    # Reuse B10's published native/RCA source archive; do not duplicate its build tree.
    if h.identity(B10)['sha256'] != B10_SHA: raise ValueError('Published shared runtime evidence changed')
    shared_native = h.read(B10)
    h.require(shared_native['archive'])
    previous = shared_native['build']['runtime_correction']
    if any(runtime_proof[k] != previous[k] for k in ('result', 'plan', 'helper')) or any(runtime_proof['module'][k] != previous['module'][k] for k in ('bytes', 'sha256')):
        raise ValueError('B13 did not stage the exact published complete AVX2 worker')
    archive.add(B10)
    override_path = N / 'runtime-override-result.json'
    override = h.read(override_path)
    h.require(override['ready'], image_dir / 'ready.json')
    if override['consumer_record'] != ready['consumer_record']: raise ValueError('Runtime override consumer differs')
    if override['runtime_verification'] != runtime_proof: raise ValueError('Actual B13 runtime override proof differs')
    archive.add(override_path); archive.metadata_tree(image_dir)
    executions, drivers = [], []
    for backend, attempt in (('cpu', args.cpu_run), ('cuda', args.cuda_run)):
        execution, driver = completed_run(h, backend, attempt, ready, archive, contract)
        executions.append(execution); drivers.append(driver)
    experts = h.expert_sets(A, contract, drivers, archive)
    for path in (A / 'publication-proposal/publication-attempt1.json', A / 'publication-proposal/before-run-plan-schema.py'):
        archive.add(path)
    for path in A.glob('*.py'): archive.add(path)
    for path in N.glob('*.py'): archive.add(path)
    common_driver = R / '.scratch/dspark-pro-target-draft-20261023/run_with_supply.py'
    if h.identity(common_driver)['sha256'] != 'd3e0749a5b565717582ff33f9f02251faae5309c71b693abfd3a6e8b880be50a':
        raise ValueError('Actual owned driver source changed')
    archive.add(common_driver)
    for path in (S / 'acquire_flash.py', S / 'generate_flash_artifacts.py', S / 'B09/acquire.py', S / 'B09/generate_artifacts.py'):
        archive.add(path)
    for folder in (A / 'frontier-plans', A / 'batches'): archive.metadata_tree(folder)
    history = []
    for folder in sorted(N.glob('checks*-*')):
        archive.metadata_tree(folder)
        path = folder / 'summary.json'
        if path.is_file():
            history.append(dict(summary=h.identity(path), passed=h.read(path).get('passed'),
                selected_for_publication=any(x['summary'] == h.identity(path) for x in executions)))
    shared = []
    for name in ('mtp-cpu-native-family-2026-10-24', 'mtp-gdn-output-scale-2026-10-24', 'mtp-batched-f32-bfloat-linear-2026-10-24', 'mtp-packed-mmvq-tail-integration-2026-10-24', 'mtp-gguf-binding-gaps-2026-10-24'):
        path = D / (name + '.json'); archive.add(path); shared.append(h.identity(path))
    name = 'mtp-glm-gguf-b13-target-verifier-2026-10-24'
    destination, output = D / (name + '.json'), D / (name + '.zip')
    if destination.exists() or output.exists(): raise ValueError('Do not overwrite published evidence')
    if sum(p.stat().st_size for p in archive.files.values()) > 67_108_864 or any(p.stat().st_size > 16_777_216 for p in archive.files.values()):
        raise ValueError('Archive must remain a finite source/metadata subset')
    record = dict(created_at=datetime.now(timezone.utc).isoformat(), identity=dict(id='B13', repository=contract[0], revision=contract[1], variant=contract[2]),
        status='Completed finite own Q8_0 target43/44 + NextN45 Flash CPU/CUDA full-vocabulary K1 execution',
        validation=dict(cases=2, failures=0, skips=0, graph_submissions=sum(x['graph_submissions'] for x in executions), executions=executions),
        original_static=static, selected_expert_acquisition=experts, attempt_history=history,
        build=dict(consumer_record=ready['consumer_record'], link_plan=ready['link_plan'], runtime=ready['runtime_environment'], image=ready['image'],
            retained_host_records=len(link['retained_current_records']), fresh_consumer_TUs=1, fresh_product_TUs=0, SDK_builds=0, NVCC_builds=0,
            compiled_source_manifest=list(archive.sources.values()), compile_helper_sources=compile_helpers, shared_proofs=shared,
            runtime_verification=runtime_proof, runtime_override=h.identity(override_path),
            run_plan_schema='Actual B13 entry+flash_helper and process entry owned are directly checked. The frozen B12 validator receives owned_entry=entry in memory only; original run files remain unchanged.',
            shared_native_build_evidence=dict(evidence=h.identity(B10), archive=shared_native['archive'],
                scope='Same complete15-TU AVX2 module and native GDN regression; original build commands/results and RCA retained once in the published B10 archive. B10 graph/state counts are not B13 results.')),
        scope='Own authenticated 85 static roles and original selected Q8_0 experts, domain288/capacity8, target43/44 and NextN45; common Graph/Invocation and accepted-prefix controller with16 draft,12 target43 and4 target44 state resources plus Epoch.',
        limits=['Layer42 upstream fourstream and finite initial histories remain fixtures; this is not a complete trained target engine or task-quality result.',
            'One natural K1 trial and separate controlled match/rejection checks do not measure natural acceptance rate.',
            'Own85-role physical acquisition and actual per-run XML properties are preserved; Pro/B10 resource or graph counts are not borrowed.',
            'State/capacity properties are logical bounds. No TPS, full-model, measured physical memory or all-platform claim.'],
        whole_original_model=False, throughput_evidence=False, memory_evidence=False, weight_bodies_rehashed=False, scope_or_progress_updated=False)
    # Public writes begin only after both actual terminal passes and all metadata checks.
    with zipfile.ZipFile(output, 'x', zipfile.ZIP_DEFLATED, compresslevel=6) as target:
        for entry, path in sorted(archive.files.items()): target.write(path, entry)
        target.writestr('compiled-source-manifest.json', json.dumps(list(archive.sources.values()), indent=2) + '\n')
    record.update(archive=h.identity(output), archived_files=len(archive.files) + 1)
    destination.write_text(json.dumps(record, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(dict(evidence=h.identity(destination), archive=h.identity(output), graphs=record['validation']['graph_submissions'])))


if __name__ == '__main__': main()
