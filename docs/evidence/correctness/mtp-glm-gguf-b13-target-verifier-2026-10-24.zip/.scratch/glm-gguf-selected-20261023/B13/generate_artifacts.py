"""Own B13 Fixture from COMPLETE real receipts only; no HTTP/body rehash."""
from pathlib import Path
import hashlib,importlib.util,sys
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent
COMMON=S.parent/'generate_flash_artifacts.py'
COMMON_SHA='ac7dff39c84f0d7ec8ba7b125023e4c193f3f3f22fb95476e67f50d12bff5d38'
if __name__=='__main__':
    assert hashlib.sha256(COMMON.read_bytes()).hexdigest()==COMMON_SHA,'Frozen common Flash pin generator changed'
    spec=importlib.util.spec_from_file_location('_b13_common_generator',COMMON)
    m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
    m.main('B13',Path(__file__))
