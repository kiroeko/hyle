from pathlib import Path
import os,json,subprocess,time,zipfile,hashlib,sys
route=sys.argv[1];assert route in ['apple','vulkan']
base=Path('/Users/kiro/hyle-scratch/compute-unified');source=base/'source-c8874688'
out=base/f'g01-native-page-{route}-preflight';out.mkdir(exist_ok=True)
assert subprocess.check_output(['sysctl','-n','hw.model'],text=True).strip()=='Mac16,12'
build=base/f'a-{route}/selected-graph/static-sdk-build';hook=out/'project.cmake'
body='''if(PROJECT_NAME STREQUAL "hyle")
function(g01_page_preflight)
  add_library(g01_page_nanobench STATIC "'''+str(source/'bench/nanobench_impl.cc')+'''")
  target_include_directories(g01_page_nanobench SYSTEM PUBLIC "'''+str(source/'third_party/nanobench')+'''")
  add_executable(g01_native_page_bench "'''+str(source/'bench/inference_resident_sdpa/native_page_bench.cc')+'''")
  target_compile_features(g01_native_page_bench PRIVATE cxx_std_23)
  target_compile_options(g01_native_page_bench PRIVATE -Wall -Wextra -Wpedantic -Werror)
  target_link_libraries(g01_native_page_bench PRIVATE hyle::compute g01_page_nanobench)
  hyle_stage_runtime(g01_native_page_bench)
'''
if route=='apple':
    body+='  target_compile_definitions(g01_native_page_bench PRIVATE HYLE_PAGE_APPLE_BENCH=1)\n'
    body+='  target_sources(g01_native_page_bench PRIVATE "'+str(source/'bench/inference_resident_sdpa/apple_page_reference.cc')+'")\n'
else:
    # Reuse the original shader materializer, not the candidate's private page
    # shader. The generated identity binds every borrowed original binary.
    peer=str(base/'g01-original-ggml-peer')
    generated=out/'reference-shaders'
    body+='  find_package(Python3 REQUIRED COMPONENTS Interpreter)\n'
    body+='  add_custom_command(OUTPUT "'+str(generated/'reference_spirv.h')+'"\n'
    body+='    COMMAND "${Python3_EXECUTABLE}" "'+str(source/'bench/inference_resident_sdpa/reference_shaders.py')+'" --peer "'+peer+'" --compiler /opt/homebrew/bin/glslangValidator --output "'+str(generated)+'" VERBATIM)\n'
    body+='  target_sources(g01_native_page_bench PRIVATE "'+str(source/'bench/inference_resident_sdpa/vulkan_page_reference.cc')+'" "'+str(source/'bench/inference_resident_sdpa/reference.cc')+'" "'+str(generated/'reference_spirv.h')+'")\n'
    body+='  target_include_directories(g01_native_page_bench PRIVATE "'+str(source/'src/compute_route_vulkan')+'" "'+str(generated)+'")\n'
body+='endfunction()\ncmake_language(DEFER CALL g01_page_preflight)\nendif()\n';hook.write_text(body)
env=os.environ.copy();env['PATH']='/Users/kiro/hyle-verify-tools/metal-17F109/shim:/opt/homebrew/bin:'+env['PATH'];env['HYLE_BENCH_VERIFY_ONLY']='1'
record=out/'result.json';rows=json.loads(record.read_text())['stages'] if record.exists() else []
def run(stage,args):
    number=1+sum(r['stage']==stage for r in rows);log=out/f'{stage}-{number}.log';start=time.monotonic()
    with log.open('w') as handle:r=subprocess.run(args,env=env,stdout=handle,stderr=subprocess.STDOUT)
    row={'stage':stage,'command':args,'exit_code':r.returncode,'elapsed_seconds':time.monotonic()-start,'log':str(log)}
    rows.append(row);record.write_text(json.dumps({'route':route,'candidate':'520027a57ff41da96ac908ad0d35896e2dda9734','scope':'bench comparator oracle/lifecycle preflight only; no sampling or qualified P1 verdict','stages':rows},indent=2)+'\n');print(json.dumps(row),flush=True)
    if r.returncode:
        with log.open('rb') as data:data.seek(max(0,log.stat().st_size-4000));print(data.read().decode(errors='replace'),flush=True)
        raise SystemExit(r.returncode)
run('configure',['/opt/homebrew/bin/cmake','-S',str(source),'-B',str(build),'-DCMAKE_PROJECT_INCLUDE='+str(hook)])
run('build',['/opt/homebrew/bin/cmake','--build',str(build),'--target','g01_native_page_bench','--parallel','4'])
run('oracle',[str(build/'bin/g01_native_page_bench')])
