from pathlib import Path
import hashlib,json,zipfile
base=Path('/Users/kiro/hyle-scratch/compute-unified');out=base/'g01-native-page-bench-preflight';out.mkdir(exist_ok=True)
receipts=[]
with zipfile.ZipFile(out/'raw.zip','w',zipfile.ZIP_DEFLATED) as archive:
    for route in ['apple','vulkan']:
        directory=base/f'g01-native-page-{route}-preflight'
        row=json.loads((directory/'result.json').read_bytes())
        for stage in ['configure','build','oracle']:
            assert [s for s in row['stages'] if s['stage']==stage][-1]['exit_code']==0
        receipts.append(row)
        for path in directory.rglob('*'):
            if path.is_file():archive.write(path,path.relative_to(base))
    names=['native_page_bench.cc','native_page_reference.h','apple_page_reference.cc','vulkan_page_reference.cc']
    inputs=[]
    for name in names:
        p=base/'source-c8874688/bench/inference_resident_sdpa'/name
        archive.write(p,'consumer/'+name);inputs.append({'path':'bench/inference_resident_sdpa/'+name,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
    for name in ['page_bench_preflight_air.py','collect_page_preflight_air.py']:
        archive.write(base/name,'scripts/'+name)
receipt={'candidate':'520027a57ff41da96ac908ad0d35896e2dda9734','verdict':'PASS_ORACLE_PREFLIGHT_ONLY',
 'scope':'No timed sampling or P1 conclusion. Exact original fused native math and matching prepare/table upload/exact guards/slot/wait/packed result lifecycle; independent double tolerance2e-3 and per-page readonly checks.',
 'runs':receipts,'inputs':inputs,'cumulative_seconds':sum(s['elapsed_seconds'] for r in receipts for s in r['stages']),
 'raw_sha256':hashlib.sha256((out/'raw.zip').read_bytes()).hexdigest()}
(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'verdict':receipt['verdict'],'elapsed':receipt['cumulative_seconds'],'raw':str(out/'raw.zip')}))
