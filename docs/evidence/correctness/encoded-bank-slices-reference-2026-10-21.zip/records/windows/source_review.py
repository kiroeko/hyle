"""Bounded read-only map of GA route -> original A8/W4 FFN -> shared FP8."""
from pathlib import Path
import importlib.util
import hashlib
import zipfile
import sys
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent
P=S.parent
A=P.parent
R=A.parents[1]
spec=importlib.util.spec_from_file_location('ga_ffn_helpers',A/'grouped-shared-activation/build_host.py')
h=importlib.util.module_from_spec(spec)
spec.loader.exec_module(h)
b,c=h.b,h.c
archive=R/'docs/evidence/research/deepseek-v4-ga-2026-10-19.zip'
with zipfile.ZipFile(archive) as z:
    members=[]
    import json
    for name in ['flash-0731/inference-model.py','flash-0731/inference-kernel.py','flash-0731/inference-config.json']:
        payload=z.read(name)
        members.append(dict(member=name,bytes=len(payload),sha256=hashlib.sha256(payload).hexdigest()))
    config=json.loads(z.read('flash-0731/inference-config.json'))
sources=['include/hyle/compute/model_ops.h','include/hyle/compute/low_precision.h',
    'include/hyle/compute/weight_import.h','src/compute_provider_native/torch_cpu_program.cc',
    'src/compute_provider_cuda/deepseek_grouped_fp4_provider.cc','src/compute_provider_cuda/router_provider.cc',
    'src/compute_route_vulkan/vulkan_official.cc','third_party/iree_vulkan_runtime/programs/generate_official.py',
    'tests/compute_models/d5_deepseek_official_fragments.h','tests/compute_models/d5_moe_execution_fragments.h',
    'tests/compute_models/d5_official_fp4_storage.h','tests/compute_models/d5_dynamic_fp8_fragments.h',
    'tests/compute_models/d5_moe_profile_cases.h','tests/compute_route_cpu/d5_qwen38_official_test.cc',
    'tests/compute_route_vulkan/d5_qwen35_execution_test.cc']
current={k:config[k] for k in ['dim','moe_inter_dim','n_routed_experts','n_activated_experts',
                              'n_hash_layers','route_scale','score_func','swiglu_limit','scale_fmt']}
c.save(S/'source-review.json',dict(
    status='read_only_source_design_no_new_arithmetic_product_gap_identified_not_executed',
    source_archive=b.identity(archive),official_members=members,formal_flash_geometry=current,
    official_contract=[
      'Gate projects BF16 source widened to F32 with F32 router weights. sqrt(softplus) gives unbiased scores; optional bias affects TopK selection only. Gather original scores, divide by their sum with no epsilon, multiply route_scale1.5.',
      'Hash first3 layers take six IDs from token table, retaining duplicates and table order; selected unbiased scores use the same normalization and route scale.',
      'Expert gate/up use BF16 input -> dynamic E4M3 group128, floor1e-4, power2 F32 scale -> original E2M1 packed W with group32 scales -> BF16 output. W scale is applied after each group32 code dot, not rounded as a dequantized BF16 weight.',
      'Widen gate/up to F32, clamp gate only above10 and up to[-10,10], compute SiLU(gate)*up in F32, multiply route weight in F32 BEFORE CastBF16 and down dynamic-A8 quantization. Down emits BF16.',
      'Source accumulates routed BF16 outputs in F32 by global expert order, adds shared FFN output then casts final BF16. Shared gate/up/down are dynamic power2 FP8 block128 linears with the same clamp/SwiGLU ordering.'
    ],
    existing_recipe=dict(path='tests/compute_models/d5_deepseek_official_fragments.h:32 moe_chain',
        recommendation='Reuse this existing node composition, FP4/FP8 constructors and independent oracle components. Adapt only exact GA provenance, original typed outputs and bounded original resource bindings/lifetimes; do not duplicate an executor or whole FFN implementation.',
        already_contains=['routed gate/up/down','route weight before down quantization','shared FP8 gate/up/down','source BF16 boundaries','unbiased router weights','global-ID-order host oracle'],
        limitations=['Legacy profile pointer pins older DeepSeek repository revisions, not the fixed current GA source used here.',
                     'Synthetic canonical F32 scale grids and weight payloads are not checkpoint payload execution.',
                     'resident=top_k+1 gives7 local banks; existing selected IDs are intentionally in that small resident prefix, so it does not demonstrate arbitrary global-to-local working-set binding.',
                     'Portable hash helper is artificially single-token; existing generic Gather plus GatherElements can express multiple tokens without a product change.',
                     'Fragment exposes lossless F32 visibility after actual BF16 Casts; a typed state consumer should nominate the original BF16 material result and preserve independent ownership.']),
    backends=dict(
      cpu=dict(grouped4='torch_cpu_program.cc selects Kind::kGrouped4. Quantizes unique A rows to group128 FP8. Packed W and F32 scales remain encoded; decode is bounded to current K block and referenced expert buckets. No whole E*N*K dense bank.',
               shared8='Kind::kLinear uses original Float8BlockLinear power policy and floor.',
               routing='No SqrtSoftplusRouting/HashRouting custom provider found; mature ordinary F32 Softplus/Sqrt/TopK/GatherElements/Reduce/Divide/Mul composition exists.'),
      cuda=dict(grouped4='deepseek_grouped_fp4_provider.cc AOT supports exact Flash gate/up N2048 K4096 and down N4096 K2048, plus Pro shapes. Original quantizer + original FP4 kernel, shared A=1 or distinct A=S.',
                routing='router_provider.cc exposes native SqrtSoftplusRouting (E256/384,top6) and HashRouting(I64 token IDs), prepared/capture-compatible. Hash scale is a separate ordinary multiply.',
                shared8='Existing grouped_fp8_provider/dynamic block128 native provider; no new NVCC requested.'),
      vulkan=dict(grouped4='vulkan_official.cc -> current OfficialGrouped4F32 IREE entry, BF16 A widened exactly then BF16 result Cast. Whole-ID check precedes checked destination publication. Packed words are read inside current group dot; no selected or whole dense W bank.',
                  shared8='Existing OfficialLinearPowerF32 with floor1e-4, original native Cast boundaries.',
                  routing='No custom router lowering; existing ordinary F32 stable Softplus/Sqrt/TopK/GatherElements/Reduce/Divide/Mul route suffices.')),
    representation=dict(
      original_expert='E2M1 even-K low nibble, odd-K high nibble + E8M0[N,K/32].',
      canonical='float4_grouped_weight_description: all [E,N,K/2] code bytes followed by F32[E,N,K/32] scales, not ggml MXFP4 blocks.',
      cold_conversion='Only the small E8M0 scale grid needs lossless F32 widening plus placing selected original code bytes in canonical order. No dense floating weight bank. Existing test constructor handles finite source codes122..124; it is not an all256 raw-code import API.',
      shared_import='Existing import_float8_block128_weight preserves E4 W and widens original macroblock128 scale grid. Do not apply group32 Quark/NVFP4 activation mathematics to this GA A8/W4 contract.'),
    selected_bank_constraint='A true score TopK6 selects six distinct global experts, so arbitrary remapping to only two unrelated local weight banks would change the model. Two resident experts can cover a valid hash-table journey with six repeated IDs. Reuse seven resident banks for the existing full score chain, or keep the two-expert hash chain and score TopK proof separate; do not claim a two-bank general scoreTop6 working set.',
    capacity_example=dict(two_expert_three_fp4_banks_bytes=31457280,
        seven_expert_three_fp4_banks_bytes=110100480,
        explanation='Flash gate/up and down each have8,388,608 elements per expert:4MiB codes+1MiB F32 group32 scales, three banks per expert. Shared three FP8 matrices add about24MiB codes plus small macroblock scales. These are bounded synthetic role allocations, not total device working-set measurements.'),
    stale_tests=[dict(path='tests/compute_route_cpu/d5_qwen38_official_test.cc:1075',
                     finding='D5OfficialFullMoeColdBoundary still expects a missing Float8/Grouped4 prepare and explicitly FAILs if all prepare. Current Torch CPU supports those operations; this rejection sentinel is stale for the equipped default CPU route.'),
                 dict(path='tests/compute_route_vulkan/d5_qwen35_execution_test.cc:1522',
                     finding='Actual test already runs D5OfficialFullMoeNativeExecution. The boundary helper retains old REJECT commentary/helper functions, not an active expected-reject test.')],
    remaining_minimum=['Bind the existing exact ordinary recipe through current canonical Graph/ConstantBinding or working-set source ownership, with true global/local IDs and independent results; exercise native source first before proposing any arithmetic change.',
                       'Preserve whole-backing resource accounting and fixed-output generation constraints learned in ratio4/mHC; do not export private-workspace final Views as independent state or leave borrowed parameters without actual lifetime.',
                       'Replace or isolate the stale CPU rejection sentinel once the same equipped canonical entry actually executes; do not broaden to old all-model matrices.'],
    scope='No compilation, GPU run, model payload download, public/schema/core/product modification, performance, complete checkpoint or cross-system proof in this review.',
    sources=[b.identity(R/x) for x in sources],product_changes=0,compiles=0,GPU_runs=0))
print(b.identity(S/'source-review.json'))
