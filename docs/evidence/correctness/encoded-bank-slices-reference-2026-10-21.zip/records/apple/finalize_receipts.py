"""Freeze Apple encoded weight-fragment transport result; inventory only."""
from pathlib import Path
import hashlib,json,runpy,shutil,xml.etree.ElementTree as ET
ROOT=Path.cwd();A=ROOT/".scratch/architecture-refactor-2026-10-18";P=A/"ga-route-ffn-2026-10-21/apple"
OUT=P/"mac/final";RESULTS=OUT/"results"
def read(p):return json.loads(p.read_text())
def save(p,value):p.write_text(json.dumps(value,indent=2)+"\n")
def identity(p):
 b=p.read_bytes();return dict(path=p.relative_to(ROOT).as_posix(),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
runpy.run_path(str(P/"audit_dependencies.py"))
audit=read(P/"actual-dependencies-canonical-audit.json");assert audit["drift_count"]==0
compiles=read(RESULTS/"compile-summary.json")["compiles"];assert len(compiles)==2
unique={r["current"]["path"]:r["current"]for c in audit["compiles"]for r in c["canonical"]}
ssh = runpy.run_path(str(A / "batch-query-extent/delegated/apple/validate.py"))["ssh"]
remote = read(OUT / "plan.json")["remote"]
inventory = ssh('''from pathlib import Path
import json,sys,hashlib,subprocess
r=Path(json.load(sys.stdin)['root']);assert r.is_absolute() and r.exists() and not r.is_symlink()
def ident(p):
 b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest(),symlink=p.is_symlink())
images=[];objects=[];dsym=[]
for q in sorted(r.rglob('*')):
 if q.is_symlink():continue
 if q.is_dir():
  if q.suffix=='.dSYM':dsym.append(str(q))
  continue
 if q.suffix=='.o':objects.append(ident(q))
 elif q.suffix=='.map':images.append(ident(q))
 else:
  with q.open('rb')as f:magic=f.read(4)
  if magic in [bytes.fromhex(x)for x in ('cffaedfe','feedfacf','cafebabe','bebafeca')]:images.append(ident(q))
ps=subprocess.check_output(['ps','-axo','pid=,command='],text=True)
active=[s for s in ps.splitlines()if str(r)in s and 'python3 -c'not in s and '/usr/bin/ssh'not in s]
lsof=subprocess.run(['lsof','--',*[x['path']for x in images]],capture_output=True,text=True)
print(json.dumps(dict(remote_root=str(r),root_symlink=r.is_symlink(),deletable_files=images,retained_objects=objects,dsym=dsym,active_image_processes=active,lsof_stdout=lsof.stdout,lsof_stderr=lsof.stderr,lsof_exit=lsof.returncode,deleted=False)))
''', dict(root=remote))
assert not inventory["active_image_processes"] and not inventory["lsof_stdout"]
save(P / "cleanup-readonly-inventory.json", inventory)

for rel,row in unique.items():
    assert identity(ROOT/rel)==row
    dest=P/"source"/rel;dest.parent.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(ROOT/rel,dest)
registration="tests/graph_route_apple/CMakeLists.txt"
dest=P/"source"/registration;dest.parent.mkdir(parents=True,exist_ok=True)
shutil.copyfile(ROOT/registration,dest)
freeze=dict(status="actual_two_CXX_sources_and_every_actual_canonical_dependency_equal_final_Windows_bytes",
    sources=sorted(unique.values(),key=lambda r:r["path"]),registration=identity(ROOT/registration),
    compiled_translation_units=[c["source"]for c in compiles],
    canonical_dependency_audit=identity(P/"actual-dependencies-canonical-audit.json"),
    actual_dependency_references=audit["actual_dependency_references"],unique_canonical_files=audit["unique_canonical_files"],
    actual_whole_dependencies_drift=0,source_snapshot="source/",SDK_source_copied=False,
    Apple_header_change=identity(P/"apple-header-change.json"),
    common_functional_change="prepare_weight_slices now permits encoded bank physical bytes only through explicit plain dense U8 source fragments, retaining full coverage, bounds, alias, bank alignment and ownership checks.",
    Apple_inline_helper_owner="src/compute_route_apple/apple_weights.mm; unchanged source, fresh object uses final changed private common header.",
    prior_header_wording=identity(P/"prior-header-wording/preservation.json"))
save(P/"source-freeze.json",freeze)
cases=[dict(name=t.attrib["classname"]+"."+t.attrib["name"],
    properties={v.attrib["name"]:v.attrib["value"]for v in t.findall("./properties/property")})
    for t in ET.parse(RESULTS/"tests.xml").iter("testcase")]
assert len(cases)==2 and len({x["name"]for x in cases})==2
assert cases[0]["properties"]["successful_submissions"]=="3"
assert cases[0]["properties"]["expected_failed_submissions"]=="1"
assert cases[1]["properties"]["actual_graph_submissions"]=="3"
validation=read(RESULTS/"validation.json")
assert validation["tests"]==2 and validation["exit"]==0 and not validation["failed"]and not validation["skipped"]
final=dict(status="actual_Mac16_12_Metal_encoded_resource_bridge_pass",source_freeze=identity(P/"source-freeze.json"),
    hardware=identity(OUT/"hardware.json"),tests=2,new_cases=1,original_neighbors=1,failed=0,skipped=0,cases=cases,
    successful_submissions=6,new_successful_submissions=3,neighbor_successful_submissions=3,
    expected_failed_submissions=1,accepted_missing_map_failure_then_fresh_invocation_recovery=True,
    successful_upload_generations=6,expected_retained_slot_upload_rejections=4,
    new_uploaded_logical_bytes=110103552,neighbor_uploaded_logical_bytes=113252448,
    upload_accounting="Per-native-upload report, not measured bus/DRAM traffic; all reports verify original complete retirement and completed==submitted.",
    CXX_jobs=2,Apple_product_CXX_jobs=1,test_CXX_jobs=1,SDK_jobs=0,
    Apple_native_runtime_or_math_changes=0,common_inline_validator_behavior_changed=True,
    compiles=[dict(source=c["source"],exit=c["exit"],object=c["object_identity"],
        dependency_count=len(c["dependencies"]),source_drifts=c["source_drifts"])for c in compiles],
    actual_whole_dependencies_drift=0,actual_dependency_references=audit["actual_dependency_references"],
    unique_canonical_files=audit["unique_canonical_files"],run=read(RESULTS/"run.result.json"),image=validation["image"],
    artifacts={n:identity(RESULTS/n)for n in ("compile-summary.json","link-inputs.json","link.command.json","link.result.json","run.command.json","run.result.json","tests.xml","validation.json")},
    attempts_preserved=["attempt1: actual2/2 green with initial opaque-bank documentation wording; preserved prior-header-wording.",
        "attempt2/final: documentation says encoded banks consistently with common block/opaque scope; only the same two CXX jobs refreshed, same two runtime cases pass."],
    scope="Encoded WeightSlots raw-byte fragment transport with original E2M1/F32 group32 selected reader: E7 of global256, N2048/K4096, T2/Top6, 16 out-of-order fragments including an offset1 byte split, three bank/map generations, original host source destruction, retained-reader reuse protection, missing-map completion failure and fresh recovery, old outputs after producer teardown. Original plain NVFP4 working-set neighbor remains intact.",
    complete_GA_routed_shared_FFN_validated=False,FFN_status="pending; this package resolves its encoded-bank fragment resource blocker only",
    cleanup_inventory=identity(P/"cleanup-readonly-inventory.json"),no_deletion_performed=True)
save(P/"final-validation.json",final)
for q in (P/"source-freeze.json",P/"final-validation.json",P/"actual-dependencies-canonical-audit.json",P/"cleanup-readonly-inventory.json"):
    print(json.dumps(identity(q)))

