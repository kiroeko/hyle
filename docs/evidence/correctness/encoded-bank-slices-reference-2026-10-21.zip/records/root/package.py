from pathlib import Path
import hashlib,json,zipfile,xml.etree.ElementTree as ET
P=Path(__file__).resolve().parents[1];R=P.parents[2]
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def resolve(p):p=Path(p);return p if p.is_absolute() else R/p
def ident(p):return dict(path=p.relative_to(R).as_posix(),bytes=p.stat().st_size,sha256=sha(p))
def check(d):
 p=resolve(d['path']);assert p.is_file() and p.stat().st_size==d['bytes'] and sha(p)==d['sha256'],str(p)
def save(p,d):p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+chr(10),encoding='utf8')
config=read(P/'root/final-results.json');cases=[];receipts=[]
host_new={
 'WeightAssembly.EncodedBanksUseExplicitByteSlicesWithoutScalarReinterpretation',
 'WeightAssembly.EncodedBanksRejectTypedEncodedAndStridedSources',
 'WeightAssembly.EncodedCoverageAndOriginalBlockAlignmentStayExact'}
host_old={
 'WeightAssembly.UnorderedSlicesUseCatalogBankOrderAndExactAlignment',
 'WeightAssembly.InvalidCoverageTypeOffsetAndCapacityDoNotTouchSources',
 'WeightAssembly.CanonicalHostAddressFactIsRequiredBeforeSourceMapping'}
def collect(arm,p):
 for x in ET.parse(p).findall('.//testcase'):
  assert x.find('failure') is None and x.find('skipped') is None
  name=x.get('classname')+'.'+x.get('name')
  if arm=='cpu':
   assert name in host_new|host_old,name
   neighbor=name in host_old
  else:
   neighbor=name.endswith('.PlainNvfp4Neighbor')
   assert neighbor or name.endswith(('.NewEncodedOriginalFp4','.OriginalFp4EncodedFragmentsKeepMapGeneration')),name
  cases.append(dict(backend=arm,name=name,neighbor=neighbor,
    properties={i.get('name'):i.get('value') for i in x.findall('./properties/property')}))
for arm in ('cpu','cuda','vulkan'):
 p=resolve(config[arm]);d=read(p)
 assert d['passed'] and d['cases']==(6 if arm=='cpu' else 2) and not d['skipped'] and not d['failed']
 for k in ('image','link_plan','xml'):check(d[k])
 for row in read(resolve(d['link_plan']['path']))['inputs']:check(row)
 for row in read(p.parent/'runtime-environment.json').get('private_modules',[]):
  check(row['source']);check(row['destination']);assert row['hardlink'] and row['source']['sha256']==row['destination']['sha256']
 collect(arm,resolve(d['xml']['path']));receipts.append(dict(backend=arm,receipt=ident(p)))
ap=resolve(config['apple']);a=read(ap);assert a['tests']==2 and a['failed']==a['skipped']==0
check(a['source_freeze'])
for row in a['artifacts'].values():check(row)
assert a['run']['exit']==0 and read(resolve(a['artifacts']['link.result.json']['path']))['exit']==0
collect('apple',resolve(a['artifacts']['tests.xml']['path']))
assert len(cases)==12 and sum(not x['neighbor'] for x in cases)==6
assert {x['name'] for x in cases if x['backend']=='cpu'}==host_new|host_old
native=[x for x in cases if x['backend']!='cpu']
new_native=[x for x in native if not x['neighbor']]
old_native=[x for x in native if x['neighbor']]
assert len(new_native)==len(old_native)==3
assert all(x['properties']['successful_submissions']=='3' and x['properties']['expected_failed_submissions']=='1' for x in new_native)
assert all(x['properties']['actual_graph_submissions']=='3' for x in old_native)
successful_submissions=sum(int(x['properties']['successful_submissions']) for x in new_native)+sum(int(x['properties']['actual_graph_submissions']) for x in old_native)
failed_completions=sum(int(x['properties']['expected_failed_submissions']) for x in new_native)
assert successful_submissions==18 and failed_completions==3
catalog=read(R/'docs/implementation/model-quantizations.json');assert len(catalog['artifacts'])==33
assert all(x['provider_coverage']['artifact_execution_verified'] is False for x in catalog['artifacts'])
sources=['src/compute/weight_assembly.h','include/hyle/compute/weight_assembly.h',
 'src/compute_route_cuda/weights.cc','src/compute_route_vulkan/vulkan_weights.cc','src/compute_route_apple/apple_weights.mm',
 'include/hyle/compute/cuda_weights.h','include/hyle/compute/vulkan_weights.h','include/hyle/compute/apple_weights.h',
 'src/graph_route_cuda/weight_binding.cc','src/graph_route_vulkan/weight_binding.cc','src/graph_route_apple/weight_binding.cc',
 'include/hyle/graph/weight_binding.h','include/hyle/graph/result.h','include/hyle/compute/resource_leases.h',
 'include/hyle/compute/model_ops.h','src/compute_ops/low_precision.cc',
 'src/compute_provider_cuda/deepseek_grouped_fp4_provider.cc',
 'tests/compute/weight_import_test.cc','tests/compute/CMakeLists.txt',
 'tests/compute_models/ga_encoded_bank_fixture.h','tests/compute_models/expert_working_set_fixture.h',
 'tests/compute_models/nvfp4_reference_fixture.h','tests/compute_models/ct_packed_grouped_fixture.h',
 'tests/compute_models/ct_packed_graph_fixture.h','tests/compute_route_vulkan/mlx_test_support.h',
 'docs/developer/current-work.md','docs/user/compute.md','docs/user/graph.md',
 'docs/implementation/model-operators.md','docs/implementation/model-quantizations.json']
sources += [f'tests/graph_route_{arm}/{name}' for arm in ('cuda','vulkan','apple') for name in ('ga_encoded_bank_test.cc','CMakeLists.txt')]
entries={'source/'+s:R/s for s in sources}
suffixes={'.json','.py','.log','.txt','.xml','.diff','.cc','.h','.hpp','.md','.mm','.ps1','.cmake','.in','.d','.cu','.cuh','.metal','.comp'}
for p in P.rglob('*'):
 if p.is_file() and p.suffix.lower() in suffixes and not p.name.startswith(('package-summary','cleanup-plan','cleanup-script','final-package')):
  entries['records/'+p.relative_to(P).as_posix()]=p
entries['provenance/deepseek-v4-ga-2026-10-19.zip']=R/'docs/evidence/research/deepseek-v4-ga-2026-10-19.zip'
for name in ('d5_deepseek_official_fragments.h','d5_dynamic_fp8_fragments.h','d5_official_fp4_storage.h'):
 entries['review_source/'+name]=R/'tests/compute_models'/name
archive=R/'docs/evidence/correctness/encoded-bank-slices-reference-2026-10-21.zip'
# Entries are project-relative, deterministic, unique and never escape the ZIP.
from pathlib import PurePosixPath
for name,p in entries.items():
 assert not PurePosixPath(name).is_absolute() and '..' not in PurePosixPath(name).parts and p.is_file(),name
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=8) as z:
 for name,p in sorted(entries.items()):z.write(p,name)
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None and len(z.namelist())==len(entries)
 for name,p in entries.items():assert hashlib.sha256(z.read(name)).hexdigest()==sha(p),name
doc=dict(observed_on='2026-10-21',status='encoded_bank_slice_transport_and_original_FP4_selected_consumer_passed',
 scope='Common copy-only weight-slice assembly supports complete physical byte fragments of already encoded catalog banks. Host metadata and three native original-FP4 resource consumers; this does not complete the formal GA routed/shared FFN role or capability8.',
 contract='Plain banks preserve dense same-scalar-type rules. Valid encoded banks accept explicit dense plainU8 fragments of already formatted physical bytes,including blocked/opaque layouts. No codec interpretation,scale conversion,packing,weight expansion or dtype-based reinterpretation. Original exact bankextent,alignment,completecoverage,capacity,hostidentity andnative preflightalias rules remain.',
 mathematics='The resource consumer uses existing GroupedFloat4Linear onFlash-admitted N2048/K4096,E7,T2,Top6. Original adjacentE2M1 codeplane andF32 group32power2scale tail;BF16onehot6 passes the original dynamicA128 floor1e-4/power2E4 boundary exactly. Independent source-code/table oracle expectsBF16 words without reading staged GPU data;not ModelOptNVFP4.',
 journey='Sevenof256 nonidentityglobalexperts,typedI32 remap atomicallybound with the sameimmutable uploadbatch. Threeuploadgenerations across twooriginal slots;retainedbatch/consumer/output guards reject overwrite,release enablesreuse. Globallyvalid-but-absentID maps to-1,expectedfailedCompletion exposesnoresult,and freshInvocation recovers. Originalsources aredestroyed beforeCompute submit; oldresults survive publicbank/plan/invocation handles.',
 accounting='Each new encodedgeneration transports36700160Bweight plus1024Bmap=36701184Blogical in16totalfragments,includingone-bytecode split andplainmap. The original report validatesstaged/submitted/completed bytes;pending/failed copies do not prove bytes completed. No measuredDRAM/bus/totalprivate-memory claim.',
 fixes=config['fixes'],build=config['build'],
 regression=dict(total=12,new_cases=6,neighbors=6,failed=0,skipped=0,host_metadata_cases=6,
  successful_Graph_submissions=successful_submissions,expected_failed_Graph_completions=failed_completions,
  windows=receipts,apple=ident(ap),cases=cases),
 limitations=['Complete formal GA routed+shared FFN remains pending. The existing originalFP4 primitive and source-bound math are reused;this is one finite encodedresource bridge,not a new operator or fullMoE implementation.',
  'Synthetic original-format bytes and finite onehot data;no checkpointnumericpayload,full256expertbank,wholemodel,quality orperformance claim.',
  'Only the common inlinevalidator andits actual nativeadapter owners needrefresh;no new transfer/Graph/executor implementation orSDK/AOT regeneration. Actualbuildcounts arein retainedreceipts,not inferred fromsourcecount.',
  'Host testscover metadata/type/alignment/range andunchangedsourcebytes; GPUconsumers separately prove originaltransfer/lifetime/numerical behavior. Acceptedrawbytes arenot generalcodecvalidity certification.',
  'No fullcanonical configure/install/Linux/device/dtype matrix. CUDA capture behavior is limited to the actual wrapper assertions recorded here,not a new general capturequalification.',
  'Capability7/8 anddelivery0/3 remainincomplete;all33 artifact_execution_verified flagsremainfalse.'],
 current_sources=[ident(R/s) for s in sorted(sources)],archive=dict(**ident(archive),members=len(entries)),
 archive_entries=[dict(entry=n,bytes=p.stat().st_size,sha256=sha(p)) for n,p in sorted(entries.items())])
save(archive.with_suffix('.json'),doc)
summary=dict(evidence=ident(archive.with_suffix('.json')),archive=doc['archive'],sources=len(sources),cases=12)
save(P/'root/package-summary.json',summary);print(json.dumps(summary,ensure_ascii=False))
