"""Build focused encoded-bank resource tests in the three current Windows closures; no execution."""
from pathlib import Path
import argparse
import concurrent.futures
import importlib.util
import sys

sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
P = S.parent
A = P.parent
R = A.parents[1]
spec = importlib.util.spec_from_file_location('encoded_bank_helpers', A/'grouped-shared-activation/build_host.py')
h = importlib.util.module_from_spec(spec)
spec.loader.exec_module(h)
b, c = h.b, h.c
RECIPES = {
    'cpu': A/'expert-working-set-2026-10-21/common/checks/test1/compute--weight_import_test-e12609/identity.json',
    'cuda': A/'expert-working-set-2026-10-21/cuda/checks/wrapper2/test-identity.json',
    'vulkan': A/'expert-working-set-2026-10-21/vulkan/checks/test2/expert-test-identity.json',
}
FROZEN = {
    'src/compute/weight_assembly.h': '3acee3356f6241ea6bd3f40da5bc357e53d9d20d9652237f52374eeceb82b3ff',
    'include/hyle/compute/weight_assembly.h': 'c085186c2751371d8e642f29d1b338e53962236e50c9935ea1858a4b188ca3ac',
    'tests/compute/weight_import_test.cc': 'fd4551fb7a6a3e616c0aafc223aa6b1d4b73934feb282f375d82ae867f9ff93b',
    'tests/compute_models/ga_encoded_bank_fixture.h': '4a69ed816143bd15ee5b059be621ffb14eabab25c7c1b376dcd0e843f2b4099b',
}


def compile_one(arm, attempt, frozen):
    source = R/('tests/compute/weight_import_test.cc' if arm == 'cpu'
        else f'tests/graph_route_{arm}/ga_encoded_bank_test.cc')
    recipe_path = RECIPES[arm]
    recipe = c.read(recipe_path)
    out = S/arm/'checks'/attempt
    out.mkdir(parents=True, exist_ok=True)
    (out/'tmp').mkdir(exist_ok=True)
    assert not (out/'compile.result.json').exists(), out
    tag = 'weight-assembly-test' if arm == 'cpu' else 'ga-encoded-bank-test'
    command = b.host_command(recipe['command'], source, tag, out)
    source_id = b.identity(source)
    c.save(out/'compile-plan.json', dict(command=command, source=source_id,
        recipe=b.identity(recipe_path), frozen=frozen, test_CXX=1,
        product_CXX=0, SDK_builds=0, NVCC_compiles=0, agent_GPU_runs=0))
    env, _ = b.environment(command, [], out)
    c.execute('compile', command, env, out)
    dep_path = out/(tag+'-deps.json')
    data = c.read(dep_path)['Data']
    deps = [b.identity(p) for p in dict.fromkeys([data['Source'], *data['Includes']])]
    assert all(b.same(x) for x in [source_id,*frozen,*deps])
    record = dict(command=command, source=source_id, recipe=b.identity(recipe_path),
        frozen=frozen, object=b.identity(out/(tag+'.obj')), dependencies=deps,
        source_dependencies=b.identity(dep_path))
    c.save(out/'identity.json', record)
    print('COMPILED TEST', arm, flush=True)
    return arm, record


def link_one(arm, record, folder):
    base_path = A/f'ga-mhc-2026-10-21/{arm}/checks/link4/link-plan.json'
    base = c.read(base_path)
    assert all(b.same(x) for x in base['inputs'])
    old_test = c.read(A/f'ga-mhc-2026-10-21/{arm}/checks/attempt4/identity.json')['object']
    replacements = {c.key(old_test['path']): record['object']}
    product_records = []
    if arm != 'cpu':
        product_path = S/arm/'checks/attempt1/identity.json'
        product = c.read(product_path)
        assert all(b.same(x) for x in [product['source'],product['object'],*product['frozen_shared']])
        replacements[c.key(product['replaces']['path'])] = product['object']
        product_records.append(b.identity(product_path))
    assert all(sum(c.key(x['path']) == old for x in base['inputs']) == 1 for old in replacements)
    inputs = [replacements.get(c.key(x['path']),x) for x in base['inputs']]
    required = [A/'ga-ratio4-producer-2026-10-21/common/checks/root-resources1/graph-resources.obj']
    if arm == 'cuda':
        required.append(A/'ga-ratio4-producer-2026-10-21/common/checks/attempt1/cuda-tensor/cuda-tensor.obj')
    if arm == 'vulkan':
        required.append(A/'ga-ratio4-producer-2026-10-21/vulkan/checks/rowpitch-fix1/vulkan-provider-region.obj')
    assert all(sum(c.key(x['path']) == c.key(path) for x in inputs) == 1 for path in required)
    assert all(b.same(x) for x in [record['object'],*record['frozen'],*inputs])
    command = [replacements.get(c.key(x),{}).get('path',x) for x in base['command']
        if not x.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:'))]
    out = S/arm/'checks'/folder
    out.mkdir(parents=True,exist_ok=True)
    (out/'tmp').mkdir(exist_ok=True)
    assert not (out/'link.result.json').exists(), out
    image = out/(arm+'.exe')
    command += ['/OUT:'+str(image),'/MAP:'+str(image.with_suffix('.map')),
        '/IMPLIB:'+str(image.with_suffix('.lib'))]
    paths = [x for x in command if Path(x).is_absolute() and Path(x).suffix.lower() in ('.obj','.lib')]
    assert list(map(c.key,paths)) == [c.key(x['path']) for x in inputs]
    c.save(out/'link-plan.json',dict(command=command,inputs=inputs,base=b.identity(base_path),
        replaced_test=old_test,new_test=record['object'],product_identities=product_records,
        retained_current_owners=[b.identity(p) for p in required],
        weak_inline_scope='No model operation or Graph ABI change; replace the old mHC test TU, retain original grouped FP4 descriptors, refresh only native shared-assembly template instances.',
        SDK_builds=0,NVCC_compiles=0,agent_GPU_runs=0))
    env, runtime = b.environment(command,[x['path'] for x in inputs],out)
    c.save(out/'runtime-environment.json',dict(PATH=env['PATH'],runtime=runtime))
    c.execute('link',command,env,out)
    c.save(out/'image.json',b.identity(image))
    name = 'Cuda' if arm == 'cuda' else 'Vulkan'
    test_filter = 'WeightAssembly.*' if arm == 'cpu' else name+'GaEncodedBank.*'
    return dict(arm=arm,image=b.identity(image),link_plan=b.identity(out/'link-plan.json'),
        runtime_environment=b.identity(out/'runtime-environment.json'),filter=test_filter,
        expected_tests=6 if arm == 'cpu' else 2)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--attempt',default='test1')
    parser.add_argument('--link-dir',default='link1')
    args = parser.parse_args()
    frozen = [b.identity(R/p) for p in FROZEN]
    assert [x['sha256'] for x in frozen] == list(FROZEN.values())
    snapshot = S/'source'
    for relative in [*FROZEN,'include/hyle/compute/cuda_weights.h','include/hyle/compute/vulkan_weights.h',
        'tests/graph_route_cuda/ga_encoded_bank_test.cc','tests/graph_route_vulkan/ga_encoded_bank_test.cc',
        'tests/graph_route_cuda/CMakeLists.txt','tests/graph_route_vulkan/CMakeLists.txt']:
        dest = snapshot/relative
        dest.parent.mkdir(parents=True,exist_ok=True)
        if dest.exists(): assert dest.read_bytes() == (R/relative).read_bytes()
        else: dest.write_bytes((R/relative).read_bytes())
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
        records = dict(pool.map(lambda arm:compile_one(arm,args.attempt,frozen),['cpu','cuda','vulkan']))
    ready = [link_one(arm,records[arm],args.link_dir) for arm in ['cpu','cuda','vulkan']]
    c.save(S/'ready-for-root-run.json',dict(status='focused_images_compiled_linked_not_executed',
        arms=ready,frozen_shared=frozen,successful_test_CXX=3,successful_product_CXX=2,
        successful_links=3,SDK_builds=0,NVCC_compiles=0,agent_CPU_runs=0,agent_GPU_runs=0,
        scope='Encoded original bank sliced assembly plus existing plain NVFP4 resource neighbor; not complete GA routed/shared FFN.'))
    print(b.identity(S/'ready-for-root-run.json'))


if __name__ == '__main__':
    main()
