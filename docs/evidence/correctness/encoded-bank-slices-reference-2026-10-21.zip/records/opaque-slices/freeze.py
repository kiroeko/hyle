"""Bind completed root Windows runs to the exact compiled sources and current focused closures."""
from pathlib import Path
import difflib
import importlib.util
import os
import sys
import xml.etree.ElementTree as ET

sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
P = S.parent
A = P.parent
R = A.parents[1]
spec = importlib.util.spec_from_file_location('encoded_freeze_helpers', A/'grouped-shared-activation/build_host.py')
h = importlib.util.module_from_spec(spec)
spec.loader.exec_module(h)
b,c = h.b,h.c
sources = [
    'src/compute/weight_assembly.h','include/hyle/compute/weight_assembly.h',
    'include/hyle/compute/cuda_weights.h','include/hyle/compute/vulkan_weights.h',
    'src/compute_route_cuda/weights.cc','src/compute_route_vulkan/vulkan_weights.cc',
    'tests/compute/weight_import_test.cc','tests/compute_models/ga_encoded_bank_fixture.h',
    'tests/compute_models/expert_working_set_fixture.h',
    'tests/graph_route_cuda/ga_encoded_bank_test.cc','tests/graph_route_vulkan/ga_encoded_bank_test.cc',
    'tests/graph_route_cuda/CMakeLists.txt','tests/graph_route_vulkan/CMakeLists.txt',
]
rows=[]
for relative in sources:
    actual=R/relative
    snapshot=S/'source'/relative
    snapshot.parent.mkdir(parents=True,exist_ok=True)
    if snapshot.exists(): assert actual.read_bytes()==snapshot.read_bytes(),relative
    else: snapshot.write_bytes(actual.read_bytes())
    rows.append(dict(source=b.identity(actual),snapshot=b.identity(snapshot)))
c.save(S/'source-freeze.json',dict(status='current_sources_match_compiled_focused_scope',sources=rows,
    source_count=len(rows),description='Root owns common validator and shared fixture; agent changed only two public native comments and two new thin wrappers/CMake registrations. Native backend source bodies, Graph, codecs and math are unchanged.'))

identities=[]
for arm in ['cuda','vulkan']:
    identities.append(S/arm/'checks/attempt1/identity.json')
for arm in ['cpu','cuda','vulkan']:
    identities.append(S/arm/'checks/test1/identity.json')
unique={};owners=[];drift=[];entries=0
for path in identities:
    record=c.read(path)
    assert b.same(record['source']) and b.same(record['object'])
    for dependency in record['dependencies']:
        entries+=1
        key=c.key(dependency['path'])
        if key in unique: assert unique[key]==dependency
        unique[key]=dependency
        if not b.same(dependency): drift.append(dependency)
    owners.append(dict(identity=b.identity(path),source=record['source'],object=record['object'],
        dependency_entries=len(record['dependencies'])))
assert not drift,drift
c.save(S/'current-source-dependency-audit.json',dict(status='all_new_compile_dependencies_match_current_bytes',
    owners=owners,compile_owners=len(owners),dependency_entries=entries,unique_dependencies=len(unique),
    drift=drift,dependencies=list(unique.values()),
    inherited_closure='Current U mHC link4 retains the already-audited T resources, CUDA rank3 RoPE and Vulkan singleton-pitch fixes. No public model operation, inline descriptor or Graph ABI changed in this resource-only extension.'))

actual=[];modules=[]
for arm,expected in [('cpu',6),('cuda',2),('vulkan',2)]:
    folder=P/arm/'validation/final1'
    receipt=c.read(folder/'receipt.json')
    plan_path=S/arm/'checks/link1/link-plan.json'
    plan=c.read(plan_path)
    assert receipt['passed'] and receipt['cases']==expected and not receipt['failed'] and not receipt['skipped']
    assert b.same(receipt['image']) and b.same(receipt['xml']) and b.same(receipt['link_plan'])
    assert c.key(receipt['link_plan']['path'])==c.key(plan_path)
    assert all(b.same(x) for x in plan['inputs'])
    result=c.read(folder/'tests.result.json')
    assert result['exit']==0 and result['terminal']
    cases=ET.parse(receipt['xml']['path']).findall('.//testcase')
    assert len(cases)==expected and all(x.find('failure') is None and x.find('skipped') is None for x in cases)
    actual.append(dict(arm=arm,receipt=b.identity(folder/'receipt.json'),command=b.identity(folder/'tests.command.json'),
        result=b.identity(folder/'tests.result.json'),xml=receipt['xml'],image=receipt['image'],
        link_plan=receipt['link_plan'],input_count=len(plan['inputs']),tests=expected,
        names=receipt['names'],properties=receipt['properties'],GPU_process=arm!='cpu'))
    runtime=c.read(folder/'runtime-environment.json')
    for module in runtime['private_modules']:
        assert b.same(module['source']) and b.same(module['destination'])
        assert module['source']['bytes']==module['destination']['bytes']
        assert module['source']['sha256']==module['destination']['sha256']
        assert module['hardlink'] and os.path.samefile(module['source']['path'],module['destination']['path'])
    modules.append(dict(arm=arm,runtime_record=b.identity(folder/'runtime-environment.json'),
        modules=runtime['private_modules'],identity_and_hardlink_verified=True))
c.save(S/'private-module-staging-proof.json',dict(status='actual_root_runtime_staging_verified',arms=modules,
    reason='The image-selected CPU AVX2 adapter uses application-directory module lookup. Root hardlinked only the exact cached DLL beside the focused images; source cache is unchanged, no SDK copy or loader flag change.',
    root_runner=b.identity(P/'root/run_windows.py'),agent_staging_actions=0,agent_executions=0))

compile_results=[]
for path in identities:
    result_path=path.parent/'compile.result.json'
    result=c.read(result_path)
    assert result['exit']==0
    compile_results.append(b.identity(result_path))
link_results=[]
for arm in ['cpu','cuda','vulkan']:
    path=S/arm/'checks/link1/link.result.json'
    assert c.read(path)['exit']==0
    link_results.append(b.identity(path))
diff=[]
for relative in ['include/hyle/compute/cuda_weights.h','include/hyle/compute/vulkan_weights.h',
                 'tests/graph_route_cuda/CMakeLists.txt','tests/graph_route_vulkan/CMakeLists.txt']:
    before=S/'before'/relative
    diff.extend(difflib.unified_diff(before.read_bytes().decode().splitlines(True),
        (R/relative).read_bytes().decode().splitlines(True),fromfile='before/'+relative,tofile='after/'+relative))
(S/'owned-existing-files.diff').write_text(''.join(diff),encoding='utf-8')
c.save(S/'build-report.json',dict(status='root_windows_actual_10_distinct_passed_zero_skip',
    successful_product_CXX=2,successful_test_CXX=3,successful_links=3,compile_results=compile_results,
    link_results=link_results,SDK_builds=0,NVCC_compiles=0,offline_shader_compiles=0,
    actual_windows=actual,distinct_tests=10,skipped_tests=0,failed_tests=0,
    encoded_original_FP4=dict(backends=['cuda','vulkan'],successful_submissions_per_backend=3,
        expected_failed_submissions_per_backend=1,geometry='7 resident of256 global experts,N2048,K4096,T2,S6',
        logical_upload_bytes_per_generation=36701184,fragments_per_generation=16,
        raw_layout='Original packed E2M1 code plane followed by F32 group32 scale plane; original encoded description retained, typed I32 map bound in the same WeightBatch.',
        resource_proof='Out-of-order byte fragments include a one-byte split. Host sources are destroyed before native submit. Both slots, retained batch/Invocation/output/read leases, same-generation map, failed unmapped global ID, fresh recovery and old results after teardown are exercised.'),
    neighbors=dict(host_previous_WeightAssembly_cases=3,plain_NVFP4_cases=2,
        successful_NVFP4_submissions_per_backend=3),
    baseline='Source-proven rejection in the previous common validator; no old-validator GPU run was manufactured.',
    architecture='Only shared assembly metadata qualification changes. Original selected catalog descriptors, native transfers, InputSource binding, readiness, accepted-prefix retirement, codecs, Graph core and arithmetic remain on existing paths.',
    limits=['This package verifies the encoded original-bank resource bridge, not the complete routed/shared GA FFN.',
        'Synthetic role bytes are not checkpoint payload or full-model execution.',
        'No performance, quality, Linux, whole-global-bank capacity or capture-generalization claim. CUDA wrapper requires and checks the captured route for these actual cases.'],
    source_freeze=b.identity(S/'source-freeze.json'),dependency_audit=b.identity(S/'current-source-dependency-audit.json'),
    private_module_staging=b.identity(S/'private-module-staging-proof.json'),
    agent_CPU_runs=0,agent_GPU_runs=0,actual_execution_owner='root',no_cleanup_performed=True))
for name in ['source-freeze.json','current-source-dependency-audit.json','private-module-staging-proof.json','build-report.json']:
    print(b.identity(S/name))
