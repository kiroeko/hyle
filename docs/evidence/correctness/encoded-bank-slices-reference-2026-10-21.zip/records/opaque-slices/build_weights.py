"""Refresh only the two native WeightSlots assembly-template owners; never link or run."""
from pathlib import Path
import argparse
import concurrent.futures
import difflib
import importlib.util
import sys

sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
P = S.parent
A = P.parent
R = A.parents[1]
spec = importlib.util.spec_from_file_location('opaque_weight_helpers', A/'grouped-shared-activation/build_host.py')
h = importlib.util.module_from_spec(spec)
spec.loader.exec_module(h)
b, c = h.b, h.c
RECIPES = {
    'cuda': A/'expert-working-set-2026-10-21/cuda/checks/attempt3/cuda-weights-identity.json',
    'vulkan': A/'expert-working-set-2026-10-21/vulkan/checks/attempt3/vulkan_weights-identity.json',
}


def plan_one(arm, attempt):
    recipe_path = RECIPES[arm]
    recipe = c.read(recipe_path)
    base_path = A/f'ga-mhc-2026-10-21/{arm}/checks/link4/link-plan.json'
    base = c.read(base_path)
    assert all(b.same(x) for x in base['inputs'])
    old = recipe['object']
    assert sum(c.key(x['path']) == c.key(old['path']) for x in base['inputs']) == 1
    assert b.same(recipe['source']), 'Only the shared validator changes, not the backend source body.'
    source = Path(recipe['source']['path'])
    out = S/arm/'checks'/attempt
    out.mkdir(parents=True, exist_ok=True)
    (out/'tmp').mkdir(exist_ok=True)
    tag = arm+'-weights'
    command = b.host_command(recipe['command'], source, tag, out)
    return dict(arm=arm, command=command, source=b.identity(source), recipe=b.identity(recipe_path),
        replaces=old, actual_base=b.identity(base_path), output=str(out), tag=tag)


def compile_one(item, frozen):
    out = Path(item['output'])
    assert not (out/'compile.result.json').exists(), out
    assert all(b.same(x) for x in frozen)
    env, _ = b.environment(item['command'], [], out)
    c.execute('compile', item['command'], env, out)
    dep_path = out/(item['tag']+'-deps.json')
    data = c.read(dep_path)['Data']
    deps = [b.identity(p) for p in dict.fromkeys([data['Source'], *data['Includes']])]
    assert all(b.same(x) for x in [item['source'], *frozen, *deps])
    assert any(c.key(x['path']) == c.key(R/'src/compute/weight_assembly.h') for x in deps)
    record = dict(command=item['command'], source=item['source'], recipe=item['recipe'],
        replaces=item['replaces'], actual_base=item['actual_base'], frozen_shared=frozen,
        object=b.identity(out/(item['tag']+'.obj')), dependencies=deps,
        source_dependencies=b.identity(dep_path), product_CXX=1, SDK_builds=0,
        NVCC_compiles=0, links=0, agent_GPU_runs=0)
    c.save(out/'identity.json', record)
    print('COMPILED', item['arm'], flush=True)
    return b.identity(out/'identity.json')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--compile', action='store_true')
    parser.add_argument('--assembly-sha')
    parser.add_argument('--attempt', default='attempt1')
    args = parser.parse_args()
    plan = [plan_one(arm, args.attempt) for arm in ['cuda','vulkan']]
    frozen = [b.identity(R/p) for p in ['src/compute/weight_assembly.h',
        'include/hyle/compute/weight_assembly.h', 'include/hyle/compute/cuda_weights.h',
        'include/hyle/compute/vulkan_weights.h']]
    c.save(S/'compile-plan.json', dict(status='prepared_not_compiled', items=plan,
        shared_at_plan=frozen, minimum_product_CXX=2, minimum_new_wrapper_CXX=2,
        expected_focused_links=2, SDK_builds=0, NVCC_compiles=0, agent_GPU_runs=0,
        wrapper_scope='Root-owned new shared fixture, original encoded bank and same-generation I32 map; no full FFN claim.'))
    diffs = []
    for name in ['cuda_weights.h','vulkan_weights.h']:
        relative = Path('include/hyle/compute')/name
        before = S/'before'/relative
        after = R/relative
        snapshot = S/'after'/relative
        snapshot.parent.mkdir(parents=True, exist_ok=True)
        snapshot.write_bytes(after.read_bytes())
        diffs.extend(difflib.unified_diff(before.read_bytes().decode().splitlines(True),
            after.read_bytes().decode().splitlines(True), fromfile='before/'+relative.as_posix(),
            tofile='after/'+relative.as_posix()))
    (S/'header-comments.diff').write_text(''.join(diffs), encoding='utf-8')
    if not args.compile:
        print(b.identity(S/'compile-plan.json'))
        return
    assert args.assembly_sha and frozen[0]['sha256'] == args.assembly_sha
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
        records = list(pool.map(lambda item: compile_one(item, frozen), plan))
    c.save(S/'objects-ready.json', dict(status='two_product_owners_compiled_not_linked_not_executed',
        identities=records, shared=frozen, successful_product_CXX=2, links=0,
        SDK_builds=0, NVCC_compiles=0, agent_GPU_runs=0))
    print(b.identity(S/'objects-ready.json'))


if __name__ == '__main__':
    main()
