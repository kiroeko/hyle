from pathlib import Path
import concurrent.futures,hashlib,json,os,re,struct,subprocess,sys,time
R=Path.cwd();A=R/'.scratch/architecture-refactor-2026-10-18';S=A/'mxfp4-weight-only-reference/vulkan';C=S/'checks';G=S/'shaders'
C.mkdir(exist_ok=True);G.mkdir(exist_ok=True)
BASE=A/'compact-mla-e4-reference/vulkan/checks/link3/link-plan.json'
def read(p):return json.loads(Path(p).read_bytes())
def save(p,x):Path(p).write_text(json.dumps(x,indent=2)+'\n',encoding='utf8')
def ident(p):p=Path(p);b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def recipe(p):
 for f in Path(p).parent.glob('*identity.json'):
  d=read(f)
  if Path(d.get('object',{}).get('path',''))==p:return f
 raise ValueError(p)
base=read(BASE)
def obj(n):
 rows=[Path(x['path']) for x in base['inputs'] if Path(x['path']).name==n];assert len(rows)==1,(n,rows);return rows[0]
env=os.environ.copy();z=subprocess.run(['cmd','/d','/c',str(A/'bf16-nan-cast-contract/compiler-env.bat')],capture_output=True,text=True,check=True)
for line in z.stdout.splitlines():
 if '=' in line and not line.startswith('='):
  k,v=line.split('=',1);env[k.upper()]=v
(S/'tmp').mkdir(exist_ok=True);env['TMP']=env['TEMP']=str(S/'tmp')
def run(tag,cmd):
 t=time.time();z=subprocess.run(cmd,cwd=R,env=env,capture_output=True,text=True,encoding='utf8',errors='replace')
 save(C/(tag+'-command.json'),dict(command=cmd,cwd=str(R),exit_code=z.returncode,seconds=time.time()-t))
 (C/(tag+'-stdout.txt')).write_text(z.stdout,encoding='utf8');(C/(tag+'-stderr.txt')).write_text(z.stderr,encoding='utf8')
 print(tag,z.returncode,flush=True)
 if z.returncode:raise RuntimeError(z.stdout+z.stderr)
 return z.stdout
if sys.argv[1]=='shaders':
 oldobj=obj('shaders.obj');oldreceipt=recipe(oldobj);oldcpp=Path(read(oldreceipt)['source']['path']);oldtext=oldcpp.read_text()
 arrays=re.findall(r'namespace \{ constexpr std::uint32_t (\w+)_words\[\] = \{(.*?)\}; \}',oldtext,re.S)
 assert len(arrays)==25,len(arrays)
 artifacts={name:bytes().join(struct.pack('<I',int(x,16)) for x in re.findall(r'0x([0-9a-f]+)u',body)) for name,body in arrays}
 helper=(R/'src/compute_shader_shared/nvfp4_f32.h').read_text().split('R"HYLE_SHADER(',1)[1].split(')HYLE_SHADER"',1)[0]
 source=R/'src/compute_route_vulkan/shaders/nvfp4.comp';oldsource=S/'before/src/compute_route_vulkan/shaders/nvfp4.comp'
 generated=G/'nvfp4.generated.comp';before=G/'nvfp4.before.generated.comp'
 for inp,out in [(source,generated),(oldsource,before)]:out.write_text(inp.read_text().replace('// HYLE_NVFP4_F32_SOURCE',helper),encoding='utf8')
 compiler='C:/public/tools/glslang/glslangValidator.exe'
 oldvariants={'nvfp4':{},'nvfp4_grouped':dict(HYLE_NVFP4_GROUPED='1'),'nvfp4_local':dict(HYLE_NVFP4_LOCAL='1'),'nvfp4_grouped_local':dict(HYLE_NVFP4_GROUPED='1',HYLE_NVFP4_LOCAL='1'),'mxfp4':dict(HYLE_MXFP4='1'),'mxfp4_grouped':dict(HYLE_MXFP4='1',HYLE_NVFP4_GROUPED='1')}
 proof=[]
 for name,defs in oldvariants.items():
  hashes=[]
  for tag,p in [('before',before),('after',generated)]:
   result=run(name+'-preprocess-'+tag,[compiler,'-E','-S','comp',*['-D'+k+'='+v for k,v in defs.items()],str(p)])
   text='\n'.join(l for l in result.splitlines() if not l.lstrip().startswith('#'))
   tokens=' '.join(re.findall(r'\w+|[^\s]',text));hashes.append(hashlib.sha256(tokens.encode()).hexdigest())
  assert hashes[0]==hashes[1],(name,hashes)
  proof.append(dict(name=name,preprocessed_tokens_sha256=hashes[0],equal=True,not_recompiled=True))
 for name,defs in [('mxfp4_weight_only',dict(HYLE_MXFP4='1',HYLE_MXFP4_WEIGHT_ONLY='1')),('mxfp4_grouped_weight_only',dict(HYLE_MXFP4='1',HYLE_MXFP4_WEIGHT_ONLY='1',HYLE_NVFP4_GROUPED='1'))]:
  out=G/(name+'.spv');run(name+'-shader',[compiler,'-V','--target-env','vulkan1.2','-S','comp',*['-D'+k+'='+v for k,v in defs.items()],'-o',str(out),str(generated)])
  artifacts[name]=out.read_bytes()
 header=['#pragma once','#include <cstdint>','#include <span>','namespace hyle::compute::vulkan::detail::shaders {'];cpp=['#include "vulkan_shaders.h"',header[-1]];inventory=[]
 for name,raw in artifacts.items():
  assert len(raw)%4==0;words=struct.unpack('<'+'I'*(len(raw)//4),raw);assert words[0]==0x07230203 and words[1]<=0x00010500
  at=5
  while at<len(words):
   size,opcode=words[at]>>16,words[at]&65535;assert size and at+size<=len(words)
   if opcode==17:assert size==2 and words[at+1]==1
   at+=size
  header.append('std::span<const std::uint32_t> '+name+'() noexcept;');cpp.append('namespace { constexpr std::uint32_t '+name+'_words[] = {')
  for offset in range(0,len(words),8):cpp.append('  '+', '.join(f'0x{x:08x}u' for x in words[offset:offset+8])+',')
  cpp+=['}; }','std::span<const std::uint32_t> '+name+'() noexcept { return '+name+'_words; }']
  inventory.append(dict(name=name,bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest(),reused=name not in ('mxfp4_weight_only','mxfp4_grouped_weight_only')))
 header.append('} // namespace hyle::compute::vulkan::detail::shaders');cpp.append(header[-1])
 (G/'vulkan_shaders.h').write_text('\n'.join(header)+'\n',encoding='utf8',newline='\n');(G/'vulkan_shaders.cc').write_text('\n'.join(cpp)+'\n',encoding='utf8',newline='\n')
 save(C/'shader-artifacts.json',dict(previous_embed=ident(oldcpp),previous_embed_receipt=ident(oldreceipt),old_variant_count=25,new_variant_count=2,old_arrays_reused_byte_exact=True,old_FP4_preprocessed_tokens=proof,artifacts=inventory,GLSL_compiles=2,preprocess_only=12,SDK=0,GPU=0))
elif sys.argv[1]=='products':
 pairs=[('vulkan_nvfp4',R/'src/compute_route_vulkan/vulkan_nvfp4.cc',obj('vulkan_nvfp4.obj')),('vulkan_operations',R/'src/compute_route_vulkan/vulkan_operations.cc',obj('vulkan_operations.obj')),('shaders',G/'vulkan_shaders.cc',obj('shaders.obj'))]
 plan=[]
 for n,src,old in pairs:
  rp=recipe(old);command=[];skip=False
  for arg in read(rp)['command']:
   if skip:skip=False;continue
   if arg=='/sourceDependencies':skip=True;continue
   if arg.lower().startswith(('/fo','/fd')) or arg.lower().endswith(('.cc','.cpp')):continue
   command.append(arg)
  command.insert(1,'/I'+str(G));command+=['/W4','/WX','/sourceDependencies',str(C/(n+'-deps.json')),str(src),'/Fo'+str(C/(n+'.obj')),'/Fd'+str(C/(n+'.pdb'))]
  plan.append(dict(name=n,source=ident(src),old_object=ident(old),recipe=ident(rp),command=command))
 save(C/'product-plan.json',dict(baseline=ident(BASE),items=plan,CXX=3,GLSL=2,links=0,GPU=0,SDK=0))
 def compile_one(item):
  n=item['name'];run(n+'-compile',item['command']);deps=read(C/(n+'-deps.json'))['Data'];record=dict(source=item['source'],object=ident(C/(n+'.obj')),command=item['command'],recipe=item['recipe'],replaces=item['old_object'],dependencies=[ident(p) for p in dict.fromkeys([deps['Source'],*deps['Includes']])]);save(C/(n+'-identity.json'),record);return ident(C/(n+'-identity.json'))
 with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:records=list(pool.map(compile_one,plan))
 save(C/'objects-ready.json',dict(identities=records,CXX=3,GLSL=2,links=0,GPU=0,SDK=0))
else:raise ValueError(sys.argv[1])
