#include "native_plan.h"
#include "numeric.h"
#include "../compute_packed_shared/static_fp8_linear.h"
#include "hyle/simd/ops.h"

#include <algorithm>
#include <array>
#include <cstddef>
#include <cstdint>
#include <span>
#include <utility>

namespace hyle::compute::native::internal {
namespace {
constexpr std::size_t kTile = 64;
bool bounded(const void *p, std::size_t n) noexcept {
  return p && n <= UINTPTR_MAX - reinterpret_cast<std::uintptr_t>(p);
}
bool overlaps(const void *a, std::size_t na, const void *b, std::size_t nb) noexcept {
  const auto x = reinterpret_cast<std::uintptr_t>(a), y = reinterpret_cast<std::uintptr_t>(b);
  return x < y + nb && y < x + na;
}
struct Mappings final {
  std::array<mem::HostMapping, 4> inputs;
  mem::HostMapping scratch, output;
  bool wrote = false;
  Status finish(Status s, mem::BufferView destination) noexcept {
    if (wrote && !destination.resource().properties().has(mem::MemoryProperty::kHostDeviceCoherent))
      preserve_first_error(s, output.flush());
    preserve_first_error(s, output.close());
    preserve_first_error(s, scratch.close());
    for (auto &m : inputs) preserve_first_error(s, m.close());
    return s;
  }
};
template<class Input> struct Quantize final {
  const Input *a;
  simd::float8_e4m3_t *q;
  float reciprocal;
};
template<class Input>
void quantize(void *state, std::size_t, std::size_t begin, std::size_t end) noexcept {
  const auto &e = *static_cast<const Quantize<Input> *>(state);
  for (auto i = begin; i < end; ++i) {
    // Same separate ordinary F32 Multiply and SATFINITE Cast boundaries.
    volatile float normalized = numeric::decode(e.a[i]) * e.reciprocal;
    e.q[i] = simd::f32_to_f8e4m3(normalized);
  }
}
template<class Output> struct Dot final {
  const NativePlan *plan;
  const simd::float8_e4m3_t *a, *w;
  float sa, sw;
  Output *output;
};
template<class Output>
void dot(void *state, std::size_t, std::size_t begin, std::size_t end) noexcept {
  const auto &e = *static_cast<const Dot<Output> *>(state);
  const auto n = e.plan->parameters[1], k = e.plan->parameters[2];
  std::array<float, kTile> a{}, w{};
  for (auto index = begin; index < end; ++index) {
    const auto row = index / n, column = index % n;
    float sum = 0.F;
    for (std::size_t first = 0; first < k; first += kTile) {
      const auto count = (std::min)(kTile, k - first);
      for (std::size_t lane = 0; lane < count; ++lane) {
        a[lane] = simd::f8e4m3_to_f32(e.a[row * k + first + lane]);
        w[lane] = simd::f8e4m3_to_f32(e.w[column * k + first + lane]);
      }
      sum += simd::dot(a.data(), w.data(), count);
    }
    // Keep both RNEs and their order, including 0*Inf and finite overflow.
    volatile float scaled = sum * e.sa;
    volatile float restored = scaled * e.sw;
    e.output[index] = numeric::encode<Output>(restored);
  }
}
template<class Input, class Output>
detail::EnqueueResult submit(const NativePlan &plan,
    std::span<const ConstTensorView> inputs, std::span<const TensorView> outputs,
    mem::BufferView workspace) noexcept {
  if (inputs.size() != 4 || outputs.size() != 1)
    return completed(Status::Internal("native static FP8 binding count differs"));
  Mappings maps;
  const auto finish = [&](Status s) { return completed(maps.finish(std::move(s), outputs[0].storage())); };
  std::array<std::size_t, 4> sizes{};
  for (std::size_t i = 0; i < inputs.size(); ++i) {
    const auto view = inputs[i].storage();
    if (!view.resource().properties().has(mem::MemoryProperty::kHostDeviceCoherent)) {
      auto status = view.invalidate(); if (!status.ok()) return finish(std::move(status));
    }
    auto mapped = view.map_host(); if (!mapped) return finish(std::move(mapped).error());
    maps.inputs[i] = std::move(*mapped); sizes[i] = *inputs[i].description().required_bytes();
    const auto data = maps.inputs[i].bytes();
    if (data.size() < sizes[i] || !bounded(data.data(), sizes[i]) ||
        !aligned_for_storage(data.data(), inputs[i].description().required_alignment()))
      return finish(Status::FailedPrecondition("native static FP8 input mapping differs"));
  }
  auto mapped = workspace.map_host(mem::HostAccess::kWrite);
  if (!mapped) return finish(std::move(mapped).error());
  maps.scratch = std::move(*mapped); auto scratch = maps.scratch.writable_bytes();
  if (!scratch || scratch->size() < plan.workspace.size || !bounded(scratch->data(), plan.workspace.size))
    return finish(Status::FailedPrecondition("native static FP8 workspace mapping differs"));
  mapped = outputs[0].storage().map_host(mem::HostAccess::kWrite);
  if (!mapped) return finish(std::move(mapped).error());
  maps.output = std::move(*mapped); auto destination = maps.output.writable_bytes();
  const auto bytes = *outputs[0].description().required_bytes();
  if (!destination || destination->size() < bytes || !bounded(destination->data(), bytes) ||
      !aligned_for_storage(destination->data(), alignof(Output)))
    return finish(Status::FailedPrecondition("native static FP8 output mapping differs"));
  if (overlaps(destination->data(), bytes, scratch->data(), plan.workspace.size))
    return finish(Status::InvalidArgument("native static FP8 workspace/output overlaps"));
  for (std::size_t i = 0; i < inputs.size(); ++i)
    if (overlaps(maps.inputs[i].bytes().data(), sizes[i], destination->data(), bytes) ||
        overlaps(maps.inputs[i].bytes().data(), sizes[i], scratch->data(), plan.workspace.size))
      return finish(Status::InvalidArgument("native static FP8 input/output/workspace overlaps"));
  const float sa = numeric::load<float>(maps.inputs[2].bytes().data());
  const float sw = numeric::load<float>(maps.inputs[3].bytes().data());
  volatile float reciprocal = 1.F / sa;
  auto *q = reinterpret_cast<simd::float8_e4m3_t *>(scratch->data());
  Quantize<Input> qepisode{reinterpret_cast<const Input *>(maps.inputs[0].bytes().data()), q, reciprocal};
  parallel_for_ranges(plan, plan.workspace.size, &quantize<Input>, &qepisode);
  Dot<Output> episode{&plan, q,
      reinterpret_cast<const simd::float8_e4m3_t *>(maps.inputs[1].bytes().data()), sa, sw,
      reinterpret_cast<Output *>(destination->data())};
  maps.wrote = true;
  parallel_for_ranges(plan, *outputs[0].description().element_count(), &dot<Output>, &episode);
  return finish(Status::Ok());
}
template<class Input> WorkspaceSubmitRoute output_route(DataType t) noexcept {
  if (t == DataType::kFloat16) return &submit<Input, simd::float16_t>;
  if (t == DataType::kBFloat16) return &submit<Input, simd::bfloat16_t>;
  return &submit<Input, float>;
}
} // namespace
Status prepare_static_fp8(Operation operation, std::span<const TensorDesc> inputs,
                          std::span<const TensorDesc> outputs, NativePlan &plan) noexcept {
  const auto op = operation.custom_as<packed::internal::StaticFloat8Linear>();
  if (!op) return Status::Unimplemented("operation is not static FP8 linear");
  std::array<TensorDesc, 1> inferred;
  HYLE_RETURN_IF_ERROR(op->infer_output_descriptions(inputs, inferred));
  if (outputs.size() != 1 || outputs[0] != inferred[0])
    return Status::InvalidArgument("native static FP8 output description differs");
  plan.parameters = {static_cast<std::size_t>(inputs[0].dimensions()[0]),
      static_cast<std::size_t>(inputs[1].dimensions()[0]),
      static_cast<std::size_t>(inputs[0].dimensions()[1])};
  const auto count = inputs[0].element_count();
  if (!count) return count.error();
  plan.workspace = {.size = *count, .alignment = alignof(simd::float8_e4m3_t)};
  plan.workspace_submit_route = inputs[0].data_type() == DataType::kFloat16
      ? output_route<simd::float16_t>(op->output_type)
      : inputs[0].data_type() == DataType::kBFloat16
      ? output_route<simd::bfloat16_t>(op->output_type) : output_route<float>(op->output_type);
  return Status::Ok();
}
} // namespace hyle::compute::native::internal
