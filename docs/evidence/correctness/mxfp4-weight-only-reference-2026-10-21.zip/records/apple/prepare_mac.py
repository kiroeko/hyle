from pathlib import Path
import json,hashlib,base64,re,runpy
ROOT=Path.cwd();A=ROOT/'.scratch/architecture-refactor-2026-10-18';S=A/'mxfp4-weight-only-reference/apple';S.mkdir(exist_ok=True);O=S/'mac';O.mkdir(exist_ok=True)
REMOTE='/Users/kiro/hyle-scratch/compute-unified/architecture-refactor-20261019-apple-page-invocation/mxfp4-weight-only-reference/apple'
def read(p):return json.loads(Path(p).read_text(encoding='utf-8'))
def save(p,o):Path(p).write_text(json.dumps(o,indent=2)+'\n',encoding='utf-8')
old=A/'compact-mla-e4-reference/apple/mac/remote';oldplan=read(old/'plan.json')
plan=dict(oldplan,remote=REMOTE,image='mxfp4-weight-only',filter='AppleMxfp4WeightOnlyGraph.*:AppleMxfp4ReferenceGraph.*',compile=[],link=read(old/'results/link.command.json')['argv'],inputs=read(old/'results/link-inputs.json'))
recipes=read(A/'batch-query-extent/delegated/apple/recipes-all.json')
q=A/'quark-mxfp4-reference/apple/mac/remote/results'
sources=['src/compute_route_apple/apple_nvfp4.cc','src/compute_route_apple/apple_mature_float.cc','src/compute_route_apple/apple_operations.cc','src/compute_ops/weight_decode.cc','tests/graph_route_apple/mxfp4_reference_test.cc','src/compute_provider_native/native_provider.cc','src/compute_provider_native/ct_packed.cc','src/compute_provider_native/static_fp8.cc','src/compute_provider_native/blockwise_w4a8.cc','src/compute_provider_native/nvfp4.cc']
for source in sources:
 tag=source.replace('/','--');cached=q/(tag+'-compile.command.json')
 recipe=read(cached)['argv']if cached.is_file()else next(x['recipe']['argv']for x in recipes if x['source']=='src/compute_provider_native/native_provider.cc')
 matches=[x for x in plan['link']if x.endswith('/'+tag+'.o') or x.endswith('/'+source.removesuffix('.cc').replace('/','--')+'.o')]
 assert len(matches)<=1 and (matches or source in ['src/compute_provider_native/ct_packed.cc','src/compute_provider_native/static_fp8.cc','src/compute_provider_native/blockwise_w4a8.cc','src/compute_provider_native/nvfp4.cc']),(source,matches)
 plan['compile'].append(dict(source=source,recipe=recipe,old_object=matches[0]if matches else ''))
plan['include_roots']=[x for x in plan['include_roots']if x!='native'];plan['include_roots'].insert(0,oldplan['remote']+'/native')
search=[ROOT,ROOT/'include',*[x for x in(ROOT/'src').iterdir()if x.is_dir()],*[x for x in(ROOT/'third_party').iterdir()if x.is_dir()]]
seen=set();include=re.compile(r'^\s*#\s*include\s*[<"]([^">]+)[">]',re.M)
def visit(path):
 path=path.resolve()
 if path in seen or not path.is_relative_to(ROOT)or not path.is_file():return
 if path.suffix not in ['.h','.hpp','.hh','.cc','.mm','.inc','.inl','.cuh']:return
 seen.add(path)
 for name in include.findall(path.read_text(encoding='utf-8',errors='replace')):
  target=next((base/name for base in [path.parent,*search]if(base/name).is_file()),None)
  if target:visit(target)
for row in plan['compile']:visit(ROOT/row['source'])
files=[]
for path in sorted(seen):
 b=path.read_bytes();files.append(dict(path=path.relative_to(ROOT).as_posix(),bytes=len(b),sha256=hashlib.sha256(b).hexdigest(),data=base64.b64encode(b).decode()))
save(O/'source-manifest.json',[{k:v for k,v in row.items()if k!='data'}for row in files]);save(O/'plan.json',plan)
script=(A/'compact-mla-e4-reference/apple/build_mac.py').read_bytes();(S/'build_mac.py').write_bytes(script)
payload=dict(plan=plan,files=files,script=base64.b64encode(script).decode())
code=r'''
from pathlib import Path
import base64,hashlib,json,sys,subprocess
p=json.load(sys.stdin);r=Path(p['plan']['remote']);r.mkdir(parents=True,exist_ok=True);assert not r.is_symlink()
for row in p['files']:
 b=base64.b64decode(row['data']);assert hashlib.sha256(b).hexdigest()==row['sha256'];q=r/row['path'];q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(b)
(r/'source-manifest.json').write_text(json.dumps([{k:v for k,v in row.items()if k!='data'}for row in p['files']],indent=2)+'\n');(r/'plan.json').write_text(json.dumps(p['plan'],indent=2)+'\n');(r/'build_mac.py').write_bytes(base64.b64decode(p['script']))
for row in p['plan']['inputs']:
 q=Path(row['path']);assert q.stat().st_size==row['bytes'];assert hashlib.sha256(q.read_bytes()).hexdigest()==row['sha256'],row['path']
h={k:subprocess.check_output(v,text=True).strip()for k,v in {'model':['sysctl','-n','hw.model'],'cpu':['sysctl','-n','machdep.cpu.brand_string'],'memory':['sysctl','-n','hw.memsize'],'os':['sw_vers'],'compiler':['clang++','--version'],'space':['df','-h',str(r)]}.items()};assert h['model']=='Mac16,12';(r/'hardware.json').write_text(json.dumps(h,indent=2)+'\n')
print(json.dumps({'remote':str(r),'files':len(p['files']),'bytes':sum(x['bytes']for x in p['files']),'compile_owners':len(p['plan']['compile']),'hardware':h}))
'''
ssh=runpy.run_path(str(A/'batch-query-extent/delegated/apple/validate.py'))['ssh'];result=ssh(code,payload);save(O/'sync.result.json',result);print(json.dumps(result,indent=2))