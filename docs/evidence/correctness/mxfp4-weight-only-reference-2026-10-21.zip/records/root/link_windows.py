from pathlib import Path
import importlib.util,sys
sys.dont_write_bytecode=True
P=Path(__file__).resolve().parents[1];A=P.parent
spec=importlib.util.spec_from_file_location('mx_link',A/'grouped-shared-activation/build_host.py');h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h);b,c=h.b,h.c
arm=sys.argv[1];basepath=Path(c.read(P/'root/common-plan.json')['bases'][arm]['path']);base=c.read(basepath)
replacements={}
for attempt in ['attempt1','attempt2']:
 for row in c.read(P/'common/checks'/attempt/'summary.json')['identities']:
  rec=c.read(row['path'])
  if arm in rec['arms']:replacements[c.key(rec['replaces']['path'])]=rec['object']
if arm=='cuda':
 for rec in c.read(P/'cuda/checks/attempt1/objects-ready.json')['owners']:
  replacements[c.key(rec['old_object']['path'])]=rec['object']
if arm=='vulkan':
 for row in c.read(P/'vulkan/checks/objects-ready.json')['identities']:
  rec=c.read(row['path']);replacements[c.key(rec['replaces']['path'])]=rec['object']
assert all(sum(c.key(x['path'])==k for x in base['inputs'])==1 for k in replacements)
inputs=[replacements.get(c.key(x['path']),x) for x in base['inputs']]
assert all(b.same(row) for row in inputs)
out=P/arm/'checks'/sys.argv[2];out.mkdir(parents=True,exist_ok=True);(out/'tmp').mkdir(exist_ok=True)
assert not (out/'link.result.json').exists()
command=[replacements.get(c.key(x),{}).get('path',x) for x in base['command'] if not x.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:'))]
image=out/(arm+'.exe');command+=['/OUT:'+str(image),'/MAP:'+str(image.with_suffix('.map')),'/IMPLIB:'+str(image.with_suffix('.lib'))]
c.save(out/'link-plan.json',dict(command=command,inputs=inputs,base=b.identity(basepath),replaced=len(replacements),SDK_builds=0))
env,runtime=b.environment(command,[x['path'] for x in inputs],out);c.save(out/'runtime-environment.json',dict(PATH=env['PATH'],runtime=runtime))
c.execute('link',command,env,out);c.save(out/'image.json',b.identity(image));print(out/'link-plan.json')
