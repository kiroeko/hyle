from pathlib import Path
import json,hashlib,zipfile,xml.etree.ElementTree as ET
P=Path(__file__).resolve().parents[1];A=P.parent;R=A.parents[1]
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def resolve(p):
 p=Path(p);return p if p.is_absolute() else R/p
def ident(p):return dict(path=p.relative_to(R).as_posix(),bytes=p.stat().st_size,sha256=sha(p))
def check(row):
 p=resolve(row['path']);assert p.is_file() and p.stat().st_size==row['bytes'] and sha(p)==row['sha256'],str(p)
def save(p,d):p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
cases=[];records=[];successes=0;expected_failures=0
for arm in ['cpu','cuda','vulkan']:
 path=P/arm/'validation/attempt1/receipt.json';d=read(path)
 assert d['passed'] and not d['failed'] and not d['skipped']
 for key in ['xml','image','link_plan']:check(d[key])
 xml=ET.parse(resolve(d['xml']['path'])).findall('.//testcase')
 names=[x.get('classname')+'.'+x.get('name') for x in xml];assert names==d['names']
 for x in xml:
  assert x.find('failure') is None and x.find('skipped') is None
  n=x.get('classname')+'.'+x.get('name');new='WeightOnly' in n or n.startswith('E8M0ScaleImport.')
  props={p.get('name'):p.get('value') for p in x.findall('./properties/property')}
  cases.append(dict(backend=arm,name=n,new=new,properties=props))
  if new:
   successes+=int(props.get('actual_submissions',props.get('successful_submissions','0')))
   expected_failures+=int(props.get('failed_completions','0'))
 records.append(dict(backend=arm,receipt=ident(path)))
ap=P/'apple/final-validation.json';ad=read(ap);assert ad['tests']==4 and ad['failed']==ad['skipped']==0;check(ad['gtest'])
for x in ET.parse(resolve(ad['gtest']['path'])).findall('.//testcase'):
 assert x.find('failure') is None and x.find('skipped') is None
 n=x.get('classname')+'.'+x.get('name');new='WeightOnly' in n
 props={p.get('name'):p.get('value') for p in x.findall('./properties/property')}
 cases.append(dict(backend='apple',name=n,new=new,properties=props))
 if new:
  successes+=int(props.get('actual_submissions',props.get('successful_submissions','0')))
  expected_failures+=int(props.get('failed_completions','0'))
assert len(cases)==26 and sum(x['new'] for x in cases)==12 and successes==192 and expected_failures==40
sources=['include/hyle/compute/model_ops.h','include/hyle/compute/weight_import.h','src/compute/weight_import.cc','src/compute_ops/weight_decode.cc','src/compute_provider_native/nvfp4.cc','src/compute_provider_native/native_provider.cc','src/compute_provider_cuda/nvfp4_provider.cc','src/compute_provider_cuda/nvfp4_kernel.cu','src/compute_provider_cuda/nvfp4_kernel.h','src/compute_provider_cuda/cuda_provider.cc','src/compute_route_apple/apple_nvfp4.cc','src/compute_route_apple/apple_nvfp4.h','src/compute_route_apple/apple_mature_float.cc','src/compute_route_apple/apple_operations.cc','src/compute_route_vulkan/vulkan_nvfp4.cc','src/compute_route_vulkan/vulkan_operations.cc','src/compute_route_vulkan/shaders/nvfp4.comp','src/compute_route_vulkan/build_shaders.py','tests/compute/weight_import_test.cc','tests/compute_models/mxfp4_reference_fixture.h','tests/compute_models/nvfp4_reference_fixture.h','docs/developer/current-work.md','docs/implementation/model-operators.md','docs/implementation/model-quantizations.json','docs/user/compute.md']
sources += [f'tests/graph_route_{a}/mxfp4_reference_test.cc' for a in ['cpu','cuda','vulkan','apple']]
research=R/'docs/evidence/research/inferact-micro32-contract-2026-10-21.json';assert research.exists()
entries={'source/'+s:R/s for s in sorted(sources)}
suffixes={'.json','.py','.log','.txt','.xml','.diff','.cc','.h','.hpp','.cuh','.cpp','.c','.md','.cu','.d','.metal','.sass','.comp'}
for p in P.rglob('*'):
 if p.is_file() and p.suffix.lower() in suffixes and not p.name.startswith(('package-summary','cleanup-plan','cleanup-script','final-package')):
  entries['records/'+p.relative_to(P).as_posix()]=p
archive=R/'docs/evidence/correctness/mxfp4-weight-only-reference-2026-10-21.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=8) as z:
 for name,p in sorted(entries.items()):z.write(p,name)
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None and len(z.namelist())==len(entries)
 for name,p in entries.items():assert hashlib.sha256(z.read(name)).hexdigest()==sha(p),name
catalog=read(R/'docs/implementation/model-quantizations.json');assert len(catalog['artifacts'])==33 and all(x['provider_coverage']['artifact_execution_verified'] is False for x in catalog['artifacts'])
doc=dict(observed_on='2026-10-21',status='four_backend_bounded_MXFP4_W4A16_reference_passed',
 architecture='Existing Mxfp4Linear/GroupedMxfp4Linear add explicit activation_mode, new descriptor ID suffix02 without compatibility. Existing prepare/immutable program/Invocation/Completion/status/result retirement retained. No new executor or full decoded weight bank.',
 math='Original finite BF16 A without QDQ, adjacent low-even/high-odd E2M1 U8 W, unsigned E8M0 group32 SF. Decode E8 scale exactly to BF16, multiply code and round each W to BF16 before original backend F32 dot and final BF16 output. SF0=2^-127; selectedSF255/nonfiniteA fail Completion. All IDs checked before any selected expert address. Legal arithmetic overflow preserves IEEE Inf/NaN.',
 scale_import='encode_e8m0_scales is a cold host-only positive-finite F32->U8 E8M0 GRS-RNE conversion, preserving logical shape and supporting nonnegative source byte strides. Complete-domain and physical alias validation before any output write. Source<=0/NaN/Inf/rounded255 rejected. Canonical host address proof required; caller owns readiness/upload/publication. Flush/unmap errors observable, no rollback after writing. Only scales converted, not W.',
 resource='CPU and CUDA W4A16 activation workspace/repack bytes0; Vulkan no activation QDQ Value; Apple no quantize kernel outputs. Original raw BF16 rows are read with actual token/slot strides, shared and independent slots preserved. Backend output/check/status/runtime storage still exists; no zero-total-workspace/allocation or throughput claim.',
 regression=dict(new_cases=12,neighbors=14,total_cases=26,failed=0,skipped=0,windows=records,apple=ident(ap),cases=cases,
  new_Graph_successful_submissions=successes,new_expected_failed_completions=expected_failures,
  counting='8 new four-backend Graph cases,3 host scale-import tests,1 CPU direct prepare/workspace check.14 neighbors include8 old A4 cases plus CPU old direct/schema and4 old block128 import tests.',
  fixture='Dense/sharedA1/independentAS/real zero-slot-stride plus padded token rows and unused NaNs; duplicate IDs, unselectedSF255, invalid lastID, nonfiniteA, selectedSF255, terminal failed invocation and fresh recovery. Two slots/epochs, cross-slot old results and results after invocation destruction. New A16 result explicitly differs from old A4 oracle per layout.',
  oracle='Independent literal E2M1/FP64 expression with explicit F32/BF16 boundaries. Pre-scaled-W witness Amax*code6*2^-10 is finite, while unscaled code-dot then group scale overflows. TinyBF16 times SF254 and SF0 are separately checked. Original scalar signedzero checks retained, not proof of every internal GPU signedzero bit.',
  cuda_capture='Both new and both old CUDA graph tests require actual kRequireCapture, and assert kCaptured. No capture inferred from ordinary prepare_replay on other backends.'),
 research_evidence=ident(research),
 source_reviews=[ident(P/'vulkan/root-source-review.json'),ident(P/'cuda/review/fixture-review.json'),ident(P/'apple/vulkan-independent-source-review.json')],
 closure='Actual constructors/extractors and original wrappers refreshed for new4B descriptor/ID. Reuse existing SDKs/objects. Windows common11compile commands incl3 refreshed wrappers after CPU direct assertion,CUDA2CXX+1NVCC,Vulkan3CXX+2newSPIRV. Apple10strictCXX. Old25SPIRV arrays preserved byte-for-byte; no vendor patch/SDK rebuild/full build.',
 limitations=['Selected positive-finite reader-reference domain only. Original Inferact exporter/OAS generation and F32 scale payload values unknown. Fixed consumer evidence does not make a producer or whole-artifact quality claim.',
  'No publisher payload/all-shard census, full model/selected artifact, Linux, native hardware FP4 GEMM, quality or throughput acceptance.33 catalog artifact_execution_verified flags remainfalse.',
  'No F16 activation promise or implicit rawF32-scale multiplication. Existing MLX group-postscale arithmetic and default Quark A4 contract are not replaced.',
  'Independent expert working-set resource bridge and complete exact role binding remain. Capability package8 and3deliverypackages not closed by this subtask.'],
 current_sources=[ident(R/s) for s in sorted(sources)],archive=dict(**ident(archive),members=len(entries)),
 archive_entries=[dict(entry=n,bytes=p.stat().st_size,sha256=sha(p)) for n,p in sorted(entries.items())])
save(archive.with_suffix('.json'),doc)
summary=dict(evidence=ident(archive.with_suffix('.json')),archive=doc['archive'],current_sources=len(sources),new_cases=12,neighbors=14)
save(P/'root/package-summary.json',summary);print(json.dumps(summary,ensure_ascii=False))
