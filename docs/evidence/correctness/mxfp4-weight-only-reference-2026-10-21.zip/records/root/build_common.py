from pathlib import Path
import importlib.util,sys,hashlib,concurrent.futures
sys.dont_write_bytecode=True
P=Path(__file__).resolve().parents[1];A=P.parent
spec=importlib.util.spec_from_file_location('mla_common_build',A/'grouped-shared-activation/build_host.py')
h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h);b,c=h.b,h.c
plan=c.read(P/'root/common-plan.json');out=P/'common/checks'/sys.argv[1];out.mkdir(parents=True,exist_ok=True)
def build(row):
 tag=Path(row['source']['path']).parent.name+'--'+Path(row['source']['path']).stem+'-'+hashlib.sha256(c.key(row['old_object']['path']).encode()).hexdigest()[:6]
 job=out/tag;job.mkdir(exist_ok=True);(job/'tmp').mkdir(exist_ok=True)
 command=[x for x in row['command'] if x not in ['/W3','/W0']]
 if '/W4' not in command:command.append('/W4')
 if '/WX' not in command:command.append('/WX')
 command=b.host_command(command,Path(row['source']['path']),tag,job)
 c.save(job/'compile-plan.json',dict(command=command,source=row['source'],recipe=row['recipe']))
 env,_=b.environment(command,[],job);c.execute('compile',command,env,job)
 deps=c.read(job/(tag+'-deps.json'))['Data']
 record=dict(command=command,source=b.identity(row['source']['path']),object=b.identity(job/(tag+'.obj')),
  replaces=row['old_object'],arms=row['arms'],dependencies=[b.identity(p) for p in dict.fromkeys([deps['Source'],*deps['Includes']])])
 c.save(job/'identity.json',record);return b.identity(job/'identity.json')
rows=[r for r in plan['owners'] if len(sys.argv)<3 or Path(r['source']['path']).name==sys.argv[2]]
assert rows
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:records=list(pool.map(build,rows))
c.save(out/'summary.json',dict(identities=records,CXX=len(records),SDK_builds=0,links=0,runs=0));print(out/'summary.json')
