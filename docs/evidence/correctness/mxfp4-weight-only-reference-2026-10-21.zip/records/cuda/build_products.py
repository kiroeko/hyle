"""Compile exactly the three actual CUDA family owners; never link or run GPU."""
from pathlib import Path
import concurrent.futures
import difflib
import importlib.util
import json
import sys
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent
A=S.parents[1]
ROOT=A.parents[1]

def module(name,path):
    spec=importlib.util.spec_from_file_location(name,path)
    m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
    return m

h=module('weight_only_host',A/'grouped-shared-activation/build_host.py')
n=module('weight_only_native',A/'grouped-nvfp4/cuda/build_products.py')
b,c=h.b,h.c

def same(row):
    actual=b.identity(row['path'])
    return actual['bytes']==row['bytes'] and actual['sha256']==row['sha256']

base_path=A/'compact-mla-e4-reference/cuda/checks/link4/link-plan.json'
base=c.read(base_path)
meta=h.metadata({'cuda':base})
out=S/'checks/attempt1'
out.mkdir(parents=True,exist_ok=False)
(out/'tmp').mkdir()
rows=[]
for relative,tag in [
    ('src/compute_provider_cuda/nvfp4_provider.cc','nvfp4-provider'),
    ('src/compute_provider_cuda/nvfp4_kernel.cu','nvfp4-kernel'),
    ('src/compute_provider_cuda/cuda_provider.cc','cuda-provider')]:
    source=ROOT/relative
    matches=[(old,meta[c.key(old['path'])]) for old in base['inputs']
             if c.key(old['path']) in meta and
             c.key(meta[c.key(old['path'])]['source_path'])==c.key(source)]
    assert len(matches)==1,(relative,len(matches))
    old,recipe=matches[0]
    assert same(old),('retained base object changed',old)
    command=n.native_command(recipe['command'],tag,out) if source.suffix=='.cu' else b.host_command(recipe['command'],source,tag,out)
    assert not any('use_fast_math' in x or 'ftz=true' in x for x in command)
    rows.append(dict(source=b.identity(source),tag=tag,old_object=old,
        recipe=b.identity(recipe['recipe']),command=command,object=str(out/(tag+'.obj'))))

frozen=[b.identity(ROOT/p) for p in [
    'include/hyle/compute/model_ops.h','src/compute_provider_cuda/nvfp4_kernel.h',
    'src/compute_provider_cuda/packed_rows.cuh','src/compute_provider_cuda/nvfp4_provider.h']]
source_files=[Path(r['source']['path']) for r in rows]+[ROOT/'src/compute_provider_cuda/nvfp4_kernel.h']
after=[];diff=[]
for p in source_files:
    relative=p.relative_to(ROOT)
    destination=S/'after'/relative
    destination.parent.mkdir(parents=True,exist_ok=True)
    destination.write_bytes(p.read_bytes())
    before=S/'before'/relative
    diff.extend(difflib.unified_diff(before.read_text(encoding='utf-8').splitlines(True),
        p.read_text(encoding='utf-8').splitlines(True),fromfile='before/'+relative.as_posix(),tofile='after/'+relative.as_posix()))
    after.append(b.identity(p))
(S/'implementation.diff').write_text(''.join(diff),encoding='utf-8')
c.save(S/'source-freeze.json',dict(product=after,shared_headers=frozen,
    scope='3 edited private family sources; cuda_provider.cc unchanged but refreshes custom descriptor extraction. No public/CPU/test/docs edits.'))
c.save(out/'plan.json',dict(base=b.identity(base_path),owners=rows,frozen=frozen,
    scope='2 CXX +1 NVCC, no SDK, tests, links or GPU'))
c.save(S/'design.json',dict(
    contract='New kMxfp4BFloat16 keeps BF16 A unquantized. Original kMxfp4 is unchanged W4A4.',
    geometry='Same positive M/N/K and grouped T,S,E with complete K32, original token/slot strides and checked IDs.',
    native_abi='Only append Contract enum value; Program layout/size and public native signature unchanged. Both actual private header consumers refresh together.',
    workspace_bytes=0,repack_bytes=0,
    commands='Original status prefix, full ID check if grouped, finite-A validation, bounded row/group dot. Prepared kernel pointers and cold driver materialization; dense3/grouped4 including status reset.',
    finite_A='Validation reads distinct original activation rows once without writing or expanding them; subsequent dot reads original strides. All IDs checked before selected W/SF addressing.',
    W='Original E2M1 adjacent-nibble signed-zero table, BF16 E8M0 scale then BF16 product before F32 dot and BF16 output. Only selected scale255 fails; scale0/finite overflow remain IEEE.',
    resources='No workspace pointer required when declared workspace size0. Output/input overlap checks remain; no activation shadow/bank/host wait/executor.',
    unchanged='ModelOpt/CT-local/W4A4 math and packed_rows.cuh loaders remain unchanged.',
    outstanding='No GPU numerical/capture/regression run in this task. Root will refresh actual constructor tests/new fixture and link the consistent revision02 closure.'))

env,runtime=b.environment(next(r['command'] for r in rows if r['tag']=='nvfp4-provider'),[],out)
c.save(out/'runtime-environment.json',dict(PATH=env['PATH'],runtime=runtime))

def compile_one(row):
    tag=row['tag'];job=out/'commands'/tag
    job.mkdir(parents=True)
    (job/'source-before-compile.txt').write_bytes(Path(row['source']['path']).read_bytes())
    result=c.execute(tag+'-compile',row['command'],env,job)
    if Path(row['source']['path']).suffix=='.cu':
        dep=out/(tag+'.d');paths=n.native_dependencies(dep)
    else:
        dep=out/(tag+'-deps.json');data=c.read(dep)['Data']
        paths=list(dict.fromkeys([data['Source'],*data['Includes']]))
    record=dict(row,result=result,object=b.identity(row['object']),
        source_dependencies=b.identity(dep),dependencies=[b.identity(p) for p in paths])
    assert same(row['source']) and all(same(x) for x in frozen)
    c.save(out/(tag+'-identity.json'),record)
    print('COMPILED',tag,flush=True)
    return record

records=[];errors=[]
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
    futures=[pool.submit(compile_one,row) for row in rows]
    for f in futures:
        try:records.append(f.result())
        except Exception as e:errors.append(str(e))
c.save(out/'objects-ready.json',dict(owners=records,errors=errors))
c.save(out/'summary.json',dict(passed=not errors,errors=errors,
    CXX_successes=sum(Path(r['source']['path']).suffix=='.cc' for r in records),
    NVCC_successes=sum(Path(r['source']['path']).suffix=='.cu' for r in records),
    SDK=0,links=0,GPU=0))
if errors:raise RuntimeError('; '.join(errors))
print('CUDA_WEIGHT_ONLY_OWNERS_READY',len(records),flush=True)
