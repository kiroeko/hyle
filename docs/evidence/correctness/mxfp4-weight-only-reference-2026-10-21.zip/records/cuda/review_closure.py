"""Bounded symbol inventory of five actual CUDA closure inputs, no linking."""
from pathlib import Path
import hashlib,json,subprocess
S=Path(__file__).resolve().parent
A=S.parents[1];R=A.parents[1]
D=S/'review/closure';D.mkdir(parents=True,exist_ok=True)
B=A/'compact-mla-e4-reference/cuda/checks/link4/link-plan.json'
base=json.loads(B.read_text(encoding='utf-8'))
dumpbin=Path(base['command'][0]).with_name('dumpbin.exe')
def ident(p):
    b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
names=['nvfp4.obj','nvfp4-provider.obj','cuda-provider.obj','hyle_compute_backend_cuda.lib','hyle_compute_provider_torch_cuda.lib']
records=[]
for name in names:
    matches=[x for x in base['inputs'] if Path(x['path']).name.lower()==name.lower()]
    assert len(matches)==1,(name,len(matches))
    old=matches[0];p=Path(old['path'])
    got=ident(p);assert all(got[k]==old[k] for k in ['bytes','sha256'])
    command=[str(dumpbin),'/symbols',str(p)]
    result=subprocess.run(command,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    out=D/(name+'.symbols.txt');err=D/(name+'.stderr.txt')
    out.write_bytes(result.stdout);err.write_bytes(result.stderr)
    text=result.stdout.decode('utf-8',errors='replace')
    lines=[line for line in text.splitlines() if 'Mxfp4Linear' in line]
    records.append(dict(input=got,command=command,exit=result.returncode,
        output=ident(out),stderr=ident(err),matching_lines=lines,
        defined_custom_as=[line for line in lines if 'custom_as' in line and 'UNDEF' not in line and 'External' in line]))
assert all(x['exit']==0 for x in records)
summary=dict(base=ident(B),owners=records,
    observation='Five real linked inputs inspected. Native CPU provider.cc is not a standalone input in this CUDA closure; native nvfp4 leaf is. Symbol conclusions are restricted to these inputs, not all historic archives.',
    native_provider_standalone_present=any('native_provider' in Path(x['path']).name for x in base['inputs']),
    no_compile=True,no_link=True,no_GPU=True)
(D/'summary.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(report=ident(D/'summary.json'),
    rows=[dict(name=Path(x['input']['path']).name,matches=len(x['matching_lines']),defined_custom_as=len(x['defined_custom_as'])) for x in records])))
