# 当前工作计划

当前收敛 Compute/Graph 推理底座重构，范围是 Windows/Linux/macOS 上的单机 CPU、单 GPU、CPU＋一张 GPU。
**架构主干已落地，剩余工作按下面的能力、交付和性能包完成，不再用旧“约75%”估计进度。**

更新：**2026-10-21，北京时间**。当前在第 3 阶段，**第8包进行中：group512 W4A8、CT BF16 block128 普通图、grouped FP8 power2、普通分页 E4 KV、E8M0 block128 冷导入和 uniform compact MLA E4 已补四后端；Inferact micro32所选reader的W4A16与scale冷转换也已补四端；下一项精确角色余项复核与专家working-set桥**。
本轮剩余清单的结项数：能力包 **7／8**，交付包 **0／3**；这是剩余清单的计数，不是整个项目完成度。
每批实现或验证产生实际结果后更新本页；decode 的样本与决策只在[性能计划](performance/decode.md)维护。
用户提供的DeepInfer／deepseek-recipe只读调研已完成，可复用机制已归入下文现有步骤；V4.1 Flash不加入支持范围。
以后确认适用的发现也说明来源、条件与下一动作；必需缺口与待验证优化分别标明。

## 当前重构主线

当前链路为模型语义图→冷编译→不可变计划→独立 Invocation→prepare/bind/layout→严格 submit→Completion／结果／状态发布。
共同核心处理依赖、权限、alias、预算与寿命；各后端处理自己的数学、布局和原生资源。
引擎中间层不判断 Provider 或原生算子，旧 CPU＋GPU 专属 Plan／Invocation／driver 已删除，不保兼容入口。
设计依据见[Compute 设计](../architecture/compute-design.md#推理执行体系的重构形状)。

| 步骤 | 工作与当前状态 | 完成边界 |
| --- | --- | --- |
| 1 | 已完成本批 D1：定位并修复配置更新后重复绑定准备；相关 CPU/CUDA、数值与短长两窗已验证 | 保完整 step、当前权限／seal／旧结果门控；不由局部修复代签全部底座 |
| 2 | Top1 决策已完成：真实 head 后缀 3 个独立进程＋1 次结构 trace，预定配对方向不一致，默认保留 D1 的 F32 Top1；直接 BF16 消费者候选本轮不采用，已结项；详见 [decode 规划](performance/decode.md) | 原始正／负结果和通用 BF16 Top1 测试保留，无挂起候选；不将空间减少或有利中位数代签吞吐收益 |
| 3 | **7／8包已完成，第8包进行中**；E8M0冷导入后，uniform compact MLA E4也已四端闭环，18项新增与10项邻居通过、无跳过。Inferact所选reader W4A16本批12项新增与14项邻居通过；继续精确角色余项复核 | 按精确合同与真实角色／子图闭环，不按模型×dtype×后端或测试数量增加交付项 |
| 4 | 完成下面 3 个交付包 | 当前源码、安装消费者、真实资源寿命和公开范围相互一致 |
| 5 | D4：最终交付比较，统一加载／prefill／cached continuation／decode／内存显存，完成接口与文档收尾 | 必需功能与交付余项完成，比较结论有实际证据；逐角色、子图与整制品执行的证明范围如实区分 |
| 6 | 实现带 MTP 的 Hyle Qwen3.5-2B 测试引擎，与 llama.cpp 的 MTP 路径对比 | 复用已有分支、状态版本与接受前缀能力；同权重／输入／生成策略测端到端 tokens/s、接受率和内存显存，保无 MTP 基线，并核正确性与回退 |
| 7 | 图像 encoder／projector（mmproj）与图像到文本链路 | 在当前纯文本底座收敛后推进 |

当前第 1–5 步是本轮收工范围；MTP 与 mmproj 随后分别推进。Qwen3.5-2B 是校正底座的测试消费者，不扩张为正式推理引擎产品。

**当前下一动作**：复核第8包的精确角色绑定余项，并按交付3推进分立expert到有界working-set的真实资源桥。
Inferact micro32的固定reader已核：F32 SF数值转E8M0，低偶高奇、gate/up连续二半，BF16 A不QDQ；
同一MXFP4入口新增W4A16模式，四端[12项新增与14项邻居](../evidence/correctness/mxfp4-weight-only-reference-2026-10-21.json)通过，无跳过。
原exporter／OAS与整制品payload未取得，所选reader参考、精确制品绑定和资源桥分别记录，不再把reader数学写成未知。
uniform compact MLA E4已接CPU、CUDA、Vulkan、Apple的原paged/ragged路径，缓存512／576字节一行、V同根前512项。
[18项新增与10项相邻回归](../evidence/correctness/compact-mla-e4-reference-2026-10-21.json)通过，无跳过；其中18项包含16个四端Graph、1个CUDA精确scale见证和1个CPU schema检查。
原ModelOpt QDQ与runtime缓存格式的归因保留在[来源复核](../evidence/research/compact-mla-e4-contract-2026-10-21.json)。
CUDA完整kernel在4070实跑，576维共享内存99KiB；Apple用无损原Q存储使共享tile降至27KiB。
原CUDA MLA增长KV仍需冷重规划；原生GPU delegated ragged无公开page-plan报告，只签warm/fresh与寿命，不宣称无冷重规划。
动态per128 scale＋BF16 KPE的656／528字节DSA另合同；本包未验新E4 capture、精确制品payload／全模型、Linux、质量或吞吐。
专门的 [decode 性能规划](performance/decode.md)维护 D1–D4 的动作、对照和停止条件，本页只保留顺序与当前事实。
仍有必需功能或交付遗漏时，当前 goal 保持未完成；说明限制或取得一次局部性能收益不能代替补齐。

### 本轮收工含义

8／8只表示下表当前量化能力包完成，不能单独代表所有算子、融合和架构重构完成。
第1–5步收工还须把旧功能审查遗留与模型总表逐项对齐：目标范围内必需计算、状态、资源与失败行为有可执行路径；
已有Provider提供且数值等价的成熟算子／融合没有漏接。发现仍属目标范围的必需遗漏，就修复并归入相应能力或交付包，不能用当前计数排除它。
抽象与职责收口审实现：模型语义与生成策略留引擎，冷路由／融合／布局留规划，热执行与资源寿命走共同核心，
后端只处理自己的数学和原生资源；普通算子、融合或模型组件扩展不应反复修改共同调度、租约与结果发布。
最终消费者检查再核功能、接口和实际性能。预期结论是“目标范围内已知必需缺口清零，本轮重构完成”；
MTP／mmproj仍按第6／7步交付。新增物理融合、更多几何或硬件专用优化按明确的收益与取舍记录，不能由“能推理”推导已优化完。

步骤 3 的功能覆盖与当前 BF16 Qwen decode 吞吐分别报告。Grouped NVFP4 等专家／其它格式接线补齐后，
当前未使用这些格式的 Qwen 图不会自动提速；只有进入实际执行图的融合／搬运修复才能影响它。
低比特权重可另行比较带宽与质量，不能将不同量化条件的速度混入当前 BF16 基线。

## 8 个模型／量化能力包

范围保持 8 个正式模型、已锁定的 24 个官方／GGUF 基线配置及其 Unsloth/Hugging Face 主流量化；现有 33 条扩展制品来源是当前核查输入，
见[模型—制品—算子总表](../implementation/model-operators.md)和[量化明细](../implementation/model-quantizations.json)。身份表24条基线已附锁定revision的HF链接。
相同格式与计算规则的来源归并验证，不按仓库数量重复计数；确认属于正式模型主流需求的新格式或计算规则仍须补入并说明。
旧 DeepSeek preview 不回归范围。

| 能力包 | 状态 | 当前缺口与收工内容 |
| --- | --- | --- |
| GPTQ INT4／g_idx | **本包已完成** | 原四端口Q/Z/F16 scales/g_idx已接四后端decode及普通闭合packed候选，zero nibble加一且15→16，先F16乘法再转输出；全部ID先检查再寻址。[48项数值／寿命及邻居回归](../evidence/correctness/gptq-reference-2026-10-20.json)通过，含CUDA实际捕获。Q35完整150组、Q27第二分片73组header仅为角色依据；未签payload／整模型、Linux或吞吐 |
| 校准 static FP8 | **本包已完成** | [固定producer／真实header与数学](../evidence/research/static-fp8-stored-scale-contract-2026-10-20.json)及四后端普通FP8 Cast／有界冷候选已接：激活SATFINITE RNE、F32 code-dot、分别乘SA/SW、末端F32/F16/BF16 Cast，直接读原W而不留NK浮点bank。含原图逃逸、IEEE scale、捕获／寿命及邻居的[71项回归](../evidence/correctness/static-fp8-reference-2026-10-20.json)通过；修Apple原图标量FTZ与CUDA相同域默认选路。只签存储scale软件参考，未签payload／整模型、Linux、原生scaled_mm或吞吐；KV／conv仍归精确绑定包 |
| Grouped ModelOpt NVFP4 | **本包已完成** | 原 dense 前五角色 A/W/SF/WG/IG＋IDs 末端；按选中专家的 IG 分别 QDQ。CPU 8 项与三种 GPU 各 4 项通过，[数值／寿命实测](../evidence/correctness/grouped-nvfp4-reference-2026-10-20.json)共用检查，直接读压缩专家 bank，QDQ 本体为 2×T×S×K 字节；[设计与 header](../evidence/research/nvfp4-grouped-expert-contract-2026-10-20.json)只作角色依据，不代签全模型、Linux 或硬件 FP4 GEMM |
| CT local-dynamic NVFP4 | **本包已完成** | [固定header与producer](../evidence/research/ct-local-nvfp4-contract-2026-10-20.json)已核，两种FP4预舍入以数学字段区分；原WG/IG直接除法、BF16局部scale边界和zero→0.125保留。dense＋selected-grouped复用四后端原执行体系，[27项数值／寿命与邻居回归](../evidence/correctness/ct-local-nvfp4-reference-2026-10-20.json)通过。只签有界软件参考；分立expert到working-set的资源桥归交付3，未签整bank／制品、Linux、硬件FP4 GEMM或吞吐 |
| Quark MXFP4 W4A4 | **本包已完成** | [固定来源与数学](../evidence/research/quark-mxfp4-contract-2026-10-20.json)已落实为`Mxfp4Linear`／`GroupedMxfp4Linear`真3／4端口，原U8相邻nibble、E8M0 group32、BF16操作数与明确零／极值规则沿四后端原FP4执行体系承载；共享A1／零slot步幅只QDQ每token一次。含SF0、selected SF255／非法IDs、tiny BF16、双槽和失败重建的[37项数值／寿命及邻居回归](../evidence/correctness/quark-mxfp4-reference-2026-10-20.json)通过，无跳过。只签软件参考，不签原HIP／Triton全域等价、整制品、Linux、硬件FP4或吞吐；分立expert工作集桥仍归交付3 |
| CT channel/token QDQ 的其余底座接线 | **本包已完成** | Apple补普通F32/F16/BF16↔Bool及Select mask归一，Vulkan补同类Bool与BF16/F16↔E4存储转换；沿原普通图保BF16逐token QDQ、逐channel权重舍入后MatMul，不替换为另一FP8点积。[20项四后端数值／寿命及邻居回归](../evidence/correctness/ct-channel-token-cross-backend-2026-10-20.json)通过，含CUDA实际捕获、±0／tiny／NaN原位与广播。只签已核CT BF16合同，不签其它producer、整制品、Linux或吞吐 |
| CT packed grouped／expert 空间承载 | **本包已完成** | 精确Decode[/Cast]→Reshape[E,N,K][/Cast]→GroupedMatMul冷收缩复用四后端原执行体系，直接读选中Q/Z/SF，不展开ENK浮点bank；F32 A／输出、真实W舍入、完整IDs先验与三轴stride保留。含sym128、sym512/F32 scale和noCast的五组见证、双槽、失败恢复与发布decode逃逸，[四后端定向及邻居回归](../evidence/correctness/ct-packed-grouped-space-2026-10-21.json)通过。CPU普通默认即可选择；Apple另修只读borrow与Copy快照。只签原flat EN行Z布局的软件路径，不签各expert独立padding的盲拼；分立expert工作集桥仍归交付3 |
| 固定来源的精确角色绑定与资料收口 | **进行中** | [16条固定来源复核](../evidence/research/fixed-role-binding-2026-10-21.json)已分清真实存储与producer数学；MLX六制品164个header完整核对，Flash全部scale/bias实际F16，46个5bit配置override对应12387个triple。Kimi group512 W4A8 已补四端，[10项新检查及14项邻居](../evidence/correctness/blockwise-w4a8-reference-2026-10-21.json)通过；CT BF16 block128普通图[18项新增及18项邻居](../evidence/correctness/ct-bf16-block128-reference-2026-10-21.json)通过；grouped FP8 power2的[9项新增及10项邻居](../evidence/correctness/grouped-fp8-power2-reference-2026-10-21.json)也通过。普通分页E4 KV的[16项新增及6项邻居](../evidence/correctness/paged-e4-kv-reference-2026-10-21.json)已通过。uniform compact MLA E4的[18项新增与10项邻居](../evidence/correctness/compact-mla-e4-reference-2026-10-21.json)已通过；真实E8M0 macroblock128冷导入已通过[4项单测与4端Graph消费](../evidence/correctness/e8m0-block128-import-reference-2026-10-21.json)，不能套group32格式；所选payload／精确角色绑定仍未签。Inferact U8/F32 micro32已按[固定reader](../evidence/research/inferact-micro32-contract-2026-10-21.json)补四端W4A16及GRS-RNE冷scale转换，[12项新增与14项邻居](../evidence/correctness/mxfp4-weight-only-reference-2026-10-21.json)通过；原exporter／OAS与实际payload绑定未签，不能套Quark W4A4。实际专家working-set与MLX head-bank资源桥归交付3 |

已经落地的四后端 CT packed 线性、MLX affine4/5/6/8／共享A／mixed输入、dense ModelOpt NVFP4参考、
四后端 CT BF16 channel/token QDQ不重新作为缺功能计算。完整普通 mixed-width MoE已在CPU/CUDA/Vulkan执行，Apple完整组合仍未代签。
完整FFN／expert单kernel、更多shape融合、CT tensorcore、NF4 packed和hardware-native FP8/FP4属于另列的优化候选；
不能把未物理融合写成普通图不能推理，也不能以另一量化数学替换现参考来制造覆盖。

33条 `artifact_execution_verified=false` 仍如实保留：这表示未执行这些整制品，不能解释成基础库完成度0%。
当前明确的完整测试引擎交付只有Qwen3.5-2B；其余模型以精确角色、数值、子图和资源旅程证明底座能力。
角色header、算子执行、整制品执行和质量／吞吐是不同证据。

## 3 个交付包

| 交付包 | 剩余工作 |
| --- | --- |
| 当前源码与安装消费者 | 对齐实际公开头、target、宏、安装包与消费者；补 Linux CUDA／mixed 当前闭包，不重建无关SDK |
| GPU 状态与结果寿命 | 对近期 StateWriter／StateClone／slot所有权更改做必要GPU续验，保旧结果、取消、失败、关闭和真实退休边界 |
| 架构、能力域与接口收口 | 对齐旧功能审查与模型总表，修成熟等价算子／融合漏接；审抽象、职责、共同调用链和普通组件扩展点；明确MLA／ragged等具体几何、布局、状态与设备范围，同步公开接口与说明 |

第三包还须承接原R04–R12普通语义旅程：KDA／MLA、正式GA的BF16 indexer／压缩状态／mHC，以及普通MoE组合。
Apple完整mixed-width MoE和GA非CUDA新角色的闭环尚未完成；这是已知待核范围，不能直接判为产品bug，也不能由旧F32／FP4载体替代BF16数学来结项。
CT制品的专家权重原本逐tensor分立，当前grouped入口却要求单dense carrier；强合512个expert会形成4GiB W与512MiB SF。
交付3须用已有catalog／WeightSlots／InputSource补有界working-set绑定、global/local ID映射、实际搬运计数及双槽旧结果／失败退休旅程；
原始buffer容量限制、U32寻址与保守INT32门限分别核，不能用小E算子测试代签整bank或只记为长期限制。
固定来源复核还确认GLM Flash的37152个专家碎片需129组有界bank绑定；GLM另有156个attention head-bank，
不能把rank3直接当成专家路由已接。MLX F16 scale配BF16网络的producer舍入及Apple完整mixed MoE仍须实际闭环。
这些是交付范围，不要求扫描所有硬件组合。原生资源退休以实际Completion为准，Scheduler空闲不能替代GPU退休；
Vulkan固定backing、Apple独立生成Array和CPU/CUDA调用者输出保持各自公开ownership与旧结果保护。

### 新来源的落点

2026-10-20核查了两仓实际固定提交与源码，[调研及来源](../evidence/research/deepseek-runtime-inspiration-2026-10-20.json)保留具体实现、适用限制与下一动作。
下列是设计借鉴与待验证优化，不是新增已确证bug或吞吐收益；没有增加另一套执行器或支持模型。

| 来源机制 | 归入步骤与下一动作 |
| --- | --- |
| DeepInfer：上游直接产出后继所需布局，权重／scale冷准备 | 第3步static FP8／精确角色接线时检查一条真实producer→consumer的Cast／repack与常量复用；等价数学才沿原region/provider收缩 |
| DeepInfer：投影与residual直接落最终输出 | 第5步D4前有限检查一条真实链的等价epilogue与实际搬运；先保原BF16舍入、读者和alias，再按实测决定采用或明确关闭本轮候选 |
| DeepInfer：GPU保留先前token／接受长度并重叠CPU处理 | 第6步先完成真实Qwen MTP与对照，再看metadata往返与空隙；DSpark另需训练的ConfidenceHead，本地Qwen的15个MTP张量没有该头 |
| Recipe：协议／prompt／token流／图片预处理分层 | 第4／5／6步审消费者token-ID、stop／finish与异步关闭边界；第7步另做真实encoder／mmproj，HTTP与模型生成政策留消费者 |
| TensorRT-LLM：冷准备共享量化、按实际形状／设备选择kernel及稳定graph metadata | [固定源码研究](../evidence/research/tensorrt-llm-inspiration-2026-10-20.json)归第3／4／5步；已有FP8共享prologue、有限图族不重做，Quark共享A按实际source独立性复用。D4前只对当前consumer真实热点核选路与搬运；SM89 BF16普通投影仍须实测，不由SM100 low-M或FP8 CUDA-core入口推导收益 |
| TensorRT-LLM：GPU token依赖与CPU结果处理重叠 | 第6步完成真实MTP后核必要同步与状态发布；第5步仅按trace核当前host-token边界的实际空隙。保stop、失败、旧结果与Completion退休，不为重叠越过token依赖 |

有限图族、稳定metadata与小replay入口已与现架构对应，不另开重构；共享池也须保Hyle独立slot和旧结果寿命。
SM100多卡吞吐、Wide-EP及V4.1特定的近似SWA replay不外推为4070单卡Qwen收益。

## 当前事实与依据

- uniform compact MLA E4已沿四端原执行体系接通，Q／输出类型与一种共享cache解释分开；V保持CKV前512项的原行距view。补Apple／Vulkan原ragged单bank入口及共同facts过度限制，没有新executor。18项新增与10项相邻回归通过，含真实KPE敏感性、CUDA精确scale、双槽旧结果和warm/fresh；有限数值及资源边界见[源码与实测](../evidence/correctness/compact-mla-e4-reference-2026-10-21.json)。CUDA原KV长变化cold replan、delegated ragged report缺省、整制品／Linux／capture／吞吐未签均保留，不由测试数量推出目标完成。

- E8M0 macroblock128冷导入已加入compute runtime：原E4字节保留，仅扩宽scale网格，调用者负责host源与canonical输出；几何、容量及跨resource的host地址alias在写前检查，映射／flush／unmap错误显式返回。4项host单测核全部256码、SF0及raw NaN、stride和失败；四后端原dense power2 Graph各1项通过，合计16次成功提交，含CUDA真实捕获、双槽和旧结果。共8项、0跳过；无整W浮点展开。未签精确制品payload绑定、全模型、Linux、质量或吞吐，[源码、固定来源与实测](../evidence/correctness/e8m0-block128-import-reference-2026-10-21.json)。

- 普通分页E4 KV沿原CacheEncode／页读取器补齐CPU、Vulkan、Apple，并与既有CUDA同fixture核对；四端16项新检查、CPU／Vulkan／Apple共6项plain／Q8邻居均通过。原E4字节按引用页解码，K/V各自F32 scale，不展开整套缓存；固定Q1增长与fresh逐字同，双槽和旧结果寿命保留。另修mixed CPU补丁合成的锚点去重与固定计数，以及旧Q8测试先allocate后bind所需双缓冲。只签有界普通页路径，E4成对pending生产者链、compact MLA／制品scale绑定、Linux及吞吐仍未签；[源码、原始失败与实测](../evidence/correctness/paged-e4-kv-reference-2026-10-21.json)。
  封包后按根`test.ps1`回收Windows约1.23GiB、Mac约20MiB测试镜像／映射，保28＋8个增量对象及共享缓存；[清理实录](../evidence/correctness/paged-e4-kv-reference-2026-10-21.cleanup.json)。
- Grouped FP8 power2本批新增9项及邻居10项分实际窗口通过，0跳过；四端新Graph合计44次成功、8次预期失败。共同描述与dense同为显式rounding＋floor，不保旧4B入口；只刷新实际构造／抽取者及新增wrapper，复用SDK与CUDA原BF16 AOT。共享A每token只量化一次，CUDA scale列步幅直接交给原GEMM。另修Vulkan旧None scale的FDiv 1F32 ULP偏差，只改26份SPIR-V中的1份，原power2数学不变。CUDA F32 power在prepare明确拒绝；未签整制品、Linux或吞吐。[源码、独立数值与原始红绿](../evidence/correctness/grouped-fp8-power2-reference-2026-10-21.json)。
  封包后按根`test.ps1`回收Windows约974MiB、Mac约20MiB测试镜像／映射，保19＋3个增量对象、源码、结果和共享缓存；[清理实录](../evidence/correctness/grouped-fp8-power2-reference-2026-10-21.cleanup.json)。
- CT BF16 block128本批18项新检查及18项邻居分实际窗口通过，无跳过；四端新Graph合计116次成功、8次预期失败，另核CUDA三dtype两种广播的24次Direct提交。普通图先Gather选中的原E4 W／BF16 SF再还原，共享A每token只QDQ一次。补CUDA原Gather捕获与cuBLAS冷batch runs，保原SiLU融合并修typed BF16 FTZ；Apple修原BF16乘除tiny，Vulkan保原M1广播，非affine一般批量走原DAG MatMul＋结果concat，明确仍有结果复制。只签有限输入、N/K整128的软件数学／寿命，未测payload／整模型、Linux或吞吐；[源码、原始失败与实测](../evidence/correctness/ct-bf16-block128-reference-2026-10-21.json)。
  封包后按根`test.ps1`回收Windows约2.52GiB、Mac约58MiB镜像／映射，保28＋7个增量对象、源码、结果、PTX和共享缓存；[清理实录](../evidence/correctness/ct-bf16-block128-reference-2026-10-21.cleanup.json)。
- group512 W4A8本批10项新路径与14项邻居分相关窗口通过，无跳过；四后端新Graph各62次成功与20次预期失败，另保CPU Direct/schema。固定source、数值／寿命、初次错误及修复均在[证据包](../evidence/correctness/blockwise-w4a8-reference-2026-10-21.json)；没有新增BF16 Qwen吞吐或整制品结论。封包后按根`test.ps1`回收Windows约734MiB、Mac约19MiB测试镜像／映射，保17＋4增量对象、当前Qwen消费者和共享缓存，[清理实录](../evidence/correctness/blockwise-w4a8-reference-2026-10-21.cleanup.json)。
- 一份不可变有限图族已承载真实128/1及23/4/1请求，无热建图或padding；稳定调用者绑定跨layout保留，配置／投影权限仍重新准备。
  见[有限图族](../evidence/performance/qwen-finite-family-2026-10-20.json)、[绑定寿命](../evidence/correctness/layout-binding-lifetime-2026-10-20.json)和[Linux续验](../evidence/correctness/linux-layout-current-2026-10-20.json)。
- CT普通线性的四后端候选已接通，默认路线按实测保守选择：CPU单向量、Vulkan单行BF16可优先packed，Apple当前保原路线。
  源类型舍入、逃逸原分解与旧结果寿命见[CPU跨系统](../evidence/correctness/ct-packed-cpu-portability-2026-10-20.json)、[Vulkan](../evidence/correctness/ct-packed-vulkan-2026-10-20.json)、[Apple](../evidence/correctness/ct-packed-apple-2026-10-20.json)。
- MLX mixed链已避免额外整bank F32扩宽，合资格Vulkan不可变bank跨槽复用原存储；不合资格View／导入仍沿原复制路径。
  见[普通MoE与布局旅程](../evidence/correctness/mlx-moe-typed-inputs-2026-10-20.json)、[bank复用](../evidence/correctness/vulkan-mlx-constant-bank-reuse-2026-10-20.json)。
- dense NVFP4保留group16当前A块QDQ、scale先乘与BF16操作数边界；四后端参考路径已执行，不能代签native FP4 GEMM或其它producer。
  见[四后端参考](../evidence/correctness/nvfp4-cross-backend-reference-2026-10-20.json)。FP8转换／QDQ的最新CUDA capture续验见[原生storage Cast](../evidence/correctness/cuda-native-storage-cast-2026-10-20.json)。
- Grouped NVFP4本包已完成20项定向回归、0跳过，原dense邻居保留；封包后经根`test.ps1`回收本地约320MiB及Mac约39MiB的测试镜像／映射，保源码、对象、命令和结果，[清理实录](../evidence/correctness/grouped-nvfp4-reference-2026-10-20.cleanup.json)。
- GPTQ本批48项、0跳过；共用packed-artifact识别，prepared映射按实际端口数冷准备，热提交不分配元数据。
  原CT、FP8双输出与indexer邻居已续验。源码、命令、失败及最终结果见[四后端证据](../evidence/correctness/gptq-reference-2026-10-20.json)，不新增当前BF16 Qwen吞吐结论。
  封包核验后通过根`test.ps1`回收本地20项约453MiB与Mac两项约18MiB测试镜像／映射，保源码、增量对象与结果，[清理实录](../evidence/correctness/gptq-reference-2026-10-20.cleanup.json)。
- static FP8本批71项、0跳过；共同冷闭合证明与映射适配复用原执行体系，原图中间值发布仍保真实分解。
  Apple及CUDA标量原图红绿与同测试对象保留在[证据包](../evidence/correctness/static-fp8-reference-2026-10-20.json)；未新增当前BF16 Qwen吞吐结论。
  核验594个归档成员及54份当前源码后，通过根`test.ps1`回收本地40项约1.23GiB与Mac六项约56MiB镜像／映射，保源码、对象及当前Qwen程序，[清理实录](../evidence/correctness/static-fp8-reference-2026-10-20.cleanup.json)。
- CT local NVFP4本批27项、0跳过，含两种FP4预舍入、dense／selected-grouped、32次寿命提交与合法IEEE重建／失败退休。
  原ModelOpt邻居保留，Apple旧FP8 Cast拒绝断言更新为实际数值与非法算术检查；源码、首次失败和结果见[证据包](../evidence/correctness/ct-local-nvfp4-reference-2026-10-20.json)。
  独立核验352个归档成员／35份当前源码后，通过根`test.ps1`回收本地12项约327MiB与Mac四项约38MiB镜像／映射，保源码、对象、当前Qwen程序及SDK，[清理实录](../evidence/correctness/ct-local-nvfp4-reference-2026-10-20.cleanup.json)。

最新 D1 已消除通用配置更新后的重复物理 span 准备，保持当前 lease/seal、未知 identity hook 和原资源门控；
18 CPU＋6 CUDA 回归通过、64 份向量逐字节同。短／长两窗相对修改前都有约 1.1%–1.4% 的 decode 中位提升，
尚不签稳定全面胜出；精确基线、样本与比较边界只在[decode 规划](performance/decode.md)维护。
[本批源码、复测和独立复算](../evidence/performance/qwen-prepare-bindings-2026-10-20.json)。
封包核验后通过根 `test.ps1` 回收 72 个诊断镜像／映射等文件和重复向量，共约 322 MiB；当前程序、对照、对象及 SDK 保留，[清理实录](../evidence/performance/qwen-prepare-bindings-2026-10-20.cleanup.json)。
[本窗原始数据与独立重算](../evidence/performance/qwen-decode-rebenchmark-2026-10-20.json)保留慢样本；比较边界与下一轮方法统一见[decode规划](performance/decode.md)。
已有[首次准备诊断](../evidence/performance/qwen-first-prepare-2026-10-20.json)与[退休查询修复](../evidence/performance/qwen-retirement-query-reuse-2026-10-20.json)作为D1依据，不将它们替代每步准备的剩余归因。

此前独立内存观测中，Hyle／参考专用GPU峰约3895／4041MiB；Hyle private commit反而更高。
映射页、进程驻留集、commit和系统文件缓存不能相加，不能将较低进程驻留集解释为全机RAM节省。
[内存原始口径](../evidence/performance/qwen-memory-current-2026-10-20.json)保采样分辨率与加载方式差异；最终对照另按步骤5执行。

## 已确认范围与由来

2026-10-17的旧八条是本轮工作的由来。旧治理已删除，文档入口、构建配置和初始化脚本已经重整，
不再每轮重列为待办；日常使用[scripts初始化指南](setup/README.md)、[文档导航](../README.md)和[构建设计](../architecture/build-system.md)。
MTP已具备状态版本、分支与接受前缀基础，见[状态版本](../user/state-versions.md#mtp-接受前缀并继续计算)。
按用户2026-10-20补充，第6步须实现MTP版Qwen3.5-2B消费者并与llama.cpp的MTP推理比较。
本地Qwen3.5-2B配置声明一层MTP且共享embedding，实际safetensors/header与index一致，含15个`mtp.*`张量；
现纯文本消费者尚未使用这些权重。比较时核定双方实际MTP实现及草拟长度／接受规则，不把已有状态底座视作MTP引擎完成；mmproj按步骤7推进。
G04/G05按用户决定先视为解决，[公平实测与边界](../evidence/performance/g04-g05-bf16-partials-2026-10-17/same-fp8/README.md)保留。

“多机器”在本项目指多系统上的单机推理，不是多机协同。后端集合、执行模式与静态／动态交付分开表达，
普通用户不决定第三方算子Provider开关。精度、放置与预算由引擎选择；模型格式、tokenizer、生成／接受策略留在引擎，
可复用计算、搬运、执行、存储与状态能力归底座。CPU＋GPU及其它模型不能由一次Qwen单请求成功推导完成。

## 首个 Qwen3.5-2B 消费者的复用材料

[本地输入身份](../implementation/tasks/compute/qwen35-2b-local-input.json)、[独立参考公式](../../tests/compute_models/qwen35_reference.py)和
[早期参考条件](../evidence/correctness/qwen35-cli-preflight/README.md)仍可复用；当前消费者为纯文本、无MTP／视觉。

接线必须保留普通RMS的`1+weight`与GDN gated RMS区别、L2的`sum(x*x)+eps`、按head拆Q/gate及64维partial RoPE；
conv history、F32 recurrent state和KV实际长度逐步反馈，新请求真实重置。prefill、多token续算、decode分别核对，
不能用oracle state替换候选状态来掩盖累计误差。64份保留向量用于回归，不构成独立质量验收。
