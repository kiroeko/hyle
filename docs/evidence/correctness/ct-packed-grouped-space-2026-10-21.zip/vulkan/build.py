from pathlib import Path
import concurrent.futures
import hashlib
import json
import os
import re
import struct
import subprocess
import sys
import threading
import time

ROOT = Path.cwd()
A = ROOT / '.scratch/architecture-refactor-2026-10-18'
STAGE = A / 'ct-packed-grouped-space/vulkan'
BASE = A / 'ct-channel-token-cross-backend/vulkan/checks'
CHECKS, SHADERS = STAGE / 'checks', STAGE / 'shaders'
CHECKS.mkdir(exist_ok=True)
SHADERS.mkdir(exist_ok=True)
PHASE = sys.argv[1]
records, lock = [], threading.Lock()
env = os.environ.copy()
setup = subprocess.run(['cmd', '/d', '/c', str(A / 'bf16-nan-cast-contract/compiler-env.bat')],
                       capture_output=True, text=True, check=True)
for line in setup.stdout.splitlines():
    if '=' in line and not line.startswith('='):
        key, value = line.split('=', 1)
        env[key.upper()] = value


def identity(path):
    path = Path(path)
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())


def load(path):
    return json.loads(Path(path).read_bytes())


def save(path, value):
    Path(path).write_text(json.dumps(value, indent=2) + '\n', encoding='utf8')


def run(label, command):
    started = time.time()
    result = subprocess.run(command, cwd=ROOT, env=env, capture_output=True,
                            text=True, encoding='utf8', errors='replace')
    (CHECKS / (label + '.stdout.log')).write_text(result.stdout, encoding='utf8')
    (CHECKS / (label + '.stderr.log')).write_text(result.stderr, encoding='utf8')
    with lock:
        records.append(dict(label=label, command=command, exit_code=result.returncode,
                            seconds=time.time() - started))
        save(CHECKS / ('commands-' + PHASE + '.json'), records)
    print(label, result.returncode, flush=True)
    if result.returncode:
        raise RuntimeError(label + ': ' + (result.stdout + result.stderr)[-8000:])


def recipe_for(obj):
    for path in Path(obj).parent.glob('*identity.json'):
        data = load(path)
        if str(Path(data.get('object', {}).get('path', ''))).lower() == str(Path(obj)).lower():
            return path
    raise AssertionError(obj)


def command_for(recipe, source, tag):
    command, skip = [], False
    for arg in load(recipe)['command']:
        if skip:
            skip = False
            continue
        if arg == '/sourceDependencies':
            skip = True
            continue
        if arg.startswith(('/Fo', '/Fd')) or arg.lower().endswith(('.cc', '.cpp')):
            continue
        command.append(arg)
    command.insert(1, '-I' + str(SHADERS))
    command += ['/W4', '/WX', '/sourceDependencies', str(CHECKS / (tag + '-deps.json')),
                str(source), '/Fo' + str(CHECKS / (tag + '.obj')),
                '/Fd' + str(CHECKS / (tag + '.pdb'))]
    return command


if PHASE == 'plan':
    linked=load(BASE/'link-plan.json');objects={Path(row['path']).name:row for row in linked['inputs']}
    items=[('vulkan_ct_packed',ROOT/'src/compute_route_vulkan/vulkan_ct_packed.cc'),
        ('vulkan_operations',ROOT/'src/compute_route_vulkan/vulkan_operations.cc'),
        ('native_region',ROOT/'src/graph_route_vulkan/native_region.cc'),
        ('vulkan_shaders',SHADERS/'vulkan_shaders.cc')]
    compiles=[]
    for tag,source in items:
        old=objects[tag+'.obj'];assert identity(old['path'])==old;recipe=recipe_for(old['path'])
        compiles.append(dict(tag=tag,source=str(source),object=str(CHECKS/(tag+'.obj')),
            command=command_for(recipe,source,tag),previous_object=old,recipe=identity(recipe)))
    save(CHECKS/'product-plan.json',dict(baseline=identity(BASE/'link-plan.json'),compile=compiles,
        scope='4 product CXX; one new groupedCT shader and two exact old shader byte checks; no SDK/GPU.'))
    print('planned',len(compiles))
elif PHASE=='shaders':
    old={row['name']:Path(row['artifact']['path']) for row in load(BASE/'shader-artifacts.json')['artifacts']}
    assert len(old)==21
    numerical=(ROOT/'src/compute_shader_shared/nvfp4_f32.h').read_text().split('R"HYLE_SHADER(',1)[1].split(')HYLE_SHADER"',1)[0]
    numerical+='\n'+(ROOT/'src/compute_shader_shared/ct_packed.h').read_text().split('R"HYLE_SHADER(',1)[1].split(')HYLE_SHADER"',1)[0]
    source=(ROOT/'src/compute_route_vulkan/shaders/ct_packed.comp').read_text()
    generated=SHADERS/'ct_packed.generated.comp';generated.write_bytes(source.replace('// HYLE_CT_F32_SOURCE',numerical).encode())
    changed={'ct_packed':{},'gptq_v1':{'HYLE_GPTQ_V1':'1'},'ct_packed_grouped':{'HYLE_CT_GROUPED':'1'}}
    proofs=[]
    for name,defines in changed.items():
        command=['C:/public/tools/glslang/glslangValidator.exe','-V','--target-env','vulkan1.2',
            '--preamble-text','#extension GL_GOOGLE_include_directive : require\n',
            '-I'+str(ROOT/'third_party/ggml_vulkan_shaders/shaders'),'-S','comp']
        command+=['-D'+k+'='+v for k,v in defines.items()]
        command+=['-o',str(SHADERS/(name+'.spv')),str(generated)];run(name+'-shader',command)
        if name in old:
            same=(SHADERS/(name+'.spv')).read_bytes()==old[name].read_bytes()
            proofs.append(dict(name=name,previous=identity(old[name]),rebuilt=identity(SHADERS/(name+'.spv')),byte_equal=same))
            assert same,name
    header=['#pragma once','#include <cstdint>','#include <span>','namespace hyle::compute::vulkan::detail::shaders {']
    cpp=['#include "vulkan_shaders.h"',header[-1]];artifacts=[]
    for name in [*old,'ct_packed_grouped']:
        path=SHADERS/(name+'.spv') if name in changed else old[name]
        raw=path.read_bytes();assert len(raw)%4==0;words=struct.unpack('<'+'I'*(len(raw)//4),raw)
        assert words[0]==0x07230203 and words[1]<=0x00010500
        at=5
        while at<len(words):
            size,opcode=words[at]>>16,words[at]&65535;assert size and at+size<=len(words)
            if opcode==17:assert size==2 and words[at+1]==1
            at+=size
        header.append('std::span<const std::uint32_t> '+name+'() noexcept;')
        cpp.append('namespace { constexpr std::uint32_t '+name+'_words[] = {')
        for at in range(0,len(words),8):cpp.append('  '+', '.join(f'0x{x:08x}u' for x in words[at:at+8])+',')
        cpp+=['}; }','std::span<const std::uint32_t> '+name+'() noexcept { return '+name+'_words; }']
        artifacts.append(dict(name=name,artifact=identity(path),reused=name not in changed))
    header.append('} // namespace hyle::compute::vulkan::detail::shaders');cpp.append(header[-1])
    (SHADERS/'vulkan_shaders.h').write_bytes(('\n'.join(header)+'\n').encode());(SHADERS/'vulkan_shaders.cc').write_bytes(('\n'.join(cpp)+'\n').encode())
    save(CHECKS/'shader-artifacts.json',dict(artifacts=artifacts,new=1,compiled=3,reused=19,
        old_shader_byte_equal=proofs,math_headers=[identity(ROOT/'src/compute_shader_shared/nvfp4_f32.h'),identity(ROOT/'src/compute_shader_shared/ct_packed.h')]))
elif PHASE in ('product','product-retry'):
    def compile_one(item):
        tag=item['tag'];run(tag+'-compile',item['command']);data=load(CHECKS/(tag+'-deps.json'))['Data']
        paths=dict.fromkeys([data['Source'],*data['Includes']]);record=dict(command=item['command'],source=identity(item['source']),object=identity(item['object']),recipe=item['recipe'],dependencies=[identity(p) for p in paths])
        save(CHECKS/(tag+'-identity.json'),record);return dict(tag=tag,receipt=identity(CHECKS/(tag+'-identity.json')))
    items=load(CHECKS/'product-plan.json')['compile']
    if PHASE=='product-retry':items=[x for x in items if x['tag']=='native_region']
    with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:done=list(pool.map(compile_one,items))
    if PHASE=='product-retry':
        done=[dict(tag=x['tag'],receipt=identity(CHECKS/(x['tag']+'-identity.json'))) for x in load(CHECKS/'product-plan.json')['compile']]
    save(CHECKS/'product-build-receipt.json',dict(CXX_successful_owners=4,GLSL=3,SDK=0,GPU=0,receipts=done))
elif PHASE=='tests':
    base=load(BASE/'link-plan.json');old=next(x for x in base['inputs'] if Path(x['path']).name=='ct-test.obj')
    items=[('ct-test',ROOT/'tests/graph_route_vulkan/ct_packed_linear_test.cc',recipe_for(old['path'])),
        ('grouped-test',ROOT/'tests/graph_route_vulkan/ct_packed_grouped_test.cc',BASE/'ct-qdq-test-identity.json')]
    for tag,source,recipe in items:
        command=command_for(recipe,source,tag);run(tag+'-compile',command);data=load(CHECKS/(tag+'-deps.json'))['Data']
        paths=dict.fromkeys([data['Source'],*data['Includes']]);save(CHECKS/(tag+'-identity.json'),dict(command=command,source=identity(source),object=identity(CHECKS/(tag+'.obj')),recipe=identity(recipe),dependencies=[identity(p) for p in paths]))
elif PHASE=='link':
    linked=load(BASE/'link-plan.json');replacements={str(Path(x['previous_object']['path'])).lower():x['object'] for x in load(CHECKS/'product-plan.json')['compile']}
    # Actual carrier definitions in this closure: native_provider + ct_packed.
    shared_root=Path(sys.argv[2]);sources={str(ROOT/p).lower() for p in ('src/compute_provider_native/native_provider.cc','src/compute_provider_native/ct_packed.cc')}
    shared={}
    for path in shared_root.rglob('*identity.json'):
        data=load(path);source=str(Path(data.get('source',{}).get('path',''))).lower()
        if source in sources:
            assert source not in shared;assert identity(data['source']['path'])==data['source'];assert identity(data['object']['path'])==data['object'];shared[source]=dict(receipt=identity(path),source=data['source'],object=data['object'])
    assert set(shared)==sources
    old_ct=next(x for x in linked['inputs'] if Path(x['path']).name=='ct-test.obj');replacements[str(Path(old_ct['path'])).lower()]=str(CHECKS/'ct-test.obj')
    abi=[]
    for item in load(CHECKS/'private-carrier-defined-owner-audit.json')['owners']:
        source=str(Path(item.get('source',{}).get('path',''))).lower()
        if source not in shared:continue
        old=load(item['receipt']['path']);fresh=load(shared[source]['receipt']['path'])
        defines=lambda cmd:sorted({x[2:] for x in cmd if x.startswith(('/D','-D'))});crt=lambda cmd:sorted(x.lower() for x in cmd if x.lower() in ('/md','/mt','/mdd','/mtd'))
        assert defines(old['command'])==defines(fresh['command']) and crt(old['command'])==crt(fresh['command']) and old['command'][0].lower()==fresh['command'][0].lower()
        abi.append(dict(source=source,defines_equal=True,CRT_equal=True,compiler_equal=True));replacements[str(Path(item['object']['path'])).lower()]=shared[source]['object']['path']
    assert len(replacements)==7
    for x in linked['inputs']:assert identity(x['path'])==x
    command=[];seen=set()
    for arg in linked['command']:
        if arg.upper().startswith(('/OUT:','/MAP:','/IMPLIB:')):continue
        key=str(Path(arg)).lower()
        if key in replacements:seen.add(key);command.append(replacements[key])
        else:command.append(arg)
    assert seen==set(replacements);command.insert(1,str(CHECKS/'grouped-test.obj'))
    command+=['/OUT:'+str(CHECKS/'ct-grouped-reference-test.exe'),'/MAP:'+str(CHECKS/'ct-grouped-reference-test.map'),'/IMPLIB:'+str(CHECKS/'ct-grouped-reference-test.lib')]
    temporary=STAGE/'tmp';temporary.mkdir(exist_ok=True);env['TMP']=env['TEMP']=str(temporary);run('link',command)
    save(CHECKS/'link-plan.json',dict(command=command,inputs=[identity(x) for x in command[1:] if Path(x).is_file()],baseline=identity(BASE/'link-plan.json'),replacements=replacements,shared_CPU_overlay=list(shared.values()),shared_CPU_ABI_checks=abi,executable=identity(CHECKS/'ct-grouped-reference-test.exe')))
else:raise ValueError(PHASE)
