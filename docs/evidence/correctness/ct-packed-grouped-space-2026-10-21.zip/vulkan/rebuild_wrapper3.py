from pathlib import Path
import concurrent.futures
import hashlib
import json
import os
import re
import struct
import subprocess
import sys
import threading
import time

ROOT = Path.cwd()
A = ROOT / '.scratch/architecture-refactor-2026-10-18'
STAGE = A / 'ct-packed-grouped-space/vulkan'
BASE = STAGE / 'checks'
CHECKS, SHADERS = STAGE / 'checks/attempt3', STAGE / 'shaders'
CHECKS.mkdir(exist_ok=True)
SHADERS.mkdir(exist_ok=True)
PHASE = sys.argv[1]
records, lock = [], threading.Lock()
env = os.environ.copy()
setup = subprocess.run(['cmd', '/d', '/c', str(A / 'bf16-nan-cast-contract/compiler-env.bat')],
                       capture_output=True, text=True, check=True)
for line in setup.stdout.splitlines():
    if '=' in line and not line.startswith('='):
        key, value = line.split('=', 1)
        env[key.upper()] = value


def identity(path):
    path = Path(path)
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())


def load(path):
    return json.loads(Path(path).read_bytes())


def save(path, value):
    Path(path).write_text(json.dumps(value, indent=2) + '\n', encoding='utf8')


def run(label, command):
    started = time.time()
    result = subprocess.run(command, cwd=ROOT, env=env, capture_output=True,
                            text=True, encoding='utf8', errors='replace')
    (CHECKS / (label + '.stdout.log')).write_text(result.stdout, encoding='utf8')
    (CHECKS / (label + '.stderr.log')).write_text(result.stderr, encoding='utf8')
    with lock:
        records.append(dict(label=label, command=command, exit_code=result.returncode,
                            seconds=time.time() - started))
        save(CHECKS / ('commands-' + PHASE + '.json'), records)
    print(label, result.returncode, flush=True)
    if result.returncode:
        raise RuntimeError(label + ': ' + (result.stdout + result.stderr)[-8000:])


def recipe_for(obj):
    for path in Path(obj).parent.glob('*identity.json'):
        data = load(path)
        if str(Path(data.get('object', {}).get('path', ''))).lower() == str(Path(obj)).lower():
            return path
    raise AssertionError(obj)


def command_for(recipe, source, tag):
    command, skip = [], False
    for arg in load(recipe)['command']:
        if skip:
            skip = False
            continue
        if arg == '/sourceDependencies':
            skip = True
            continue
        if arg.startswith(('/Fo', '/Fd')) or arg.lower().endswith(('.cc', '.cpp')):
            continue
        command.append(arg)
    command.insert(1, '-I' + str(SHADERS))
    command += ['/W4', '/WX', '/sourceDependencies', str(CHECKS / (tag + '-deps.json')),
                str(source), '/Fo' + str(CHECKS / (tag + '.obj')),
                '/Fd' + str(CHECKS / (tag + '.pdb'))]
    return command


fixture=ROOT/'tests/compute_models/ct_packed_grouped_fixture.h'
assert identity(fixture)['sha256']=='dcadf216276544c7145c913200f38dd762f0cb76d41cce0776b165bac1d3b7b9'
recipe=BASE/'grouped-test-identity.json';source=ROOT/'tests/graph_route_vulkan/ct_packed_grouped_test.cc';tag='grouped-test'
command=command_for(recipe,source,tag);run(tag+'-compile',command)
data=load(CHECKS/(tag+'-deps.json'))['Data'];paths=dict.fromkeys([data['Source'],*data['Includes']])
save(CHECKS/(tag+'-identity.json'),dict(command=command,source=identity(source),object=identity(CHECKS/(tag+'.obj')),recipe=identity(recipe),dependencies=[identity(p) for p in paths]))
linked=load(BASE/'link-plan.json');old_object=load(recipe)['object'];assert identity(old_object['path'])==old_object
for row in linked['inputs']:assert identity(row['path'])==row
newcommand=[];replaced=0
for arg in linked['command']:
    if arg.upper().startswith(('/OUT:','/MAP:','/IMPLIB:')):continue
    if str(Path(arg)).lower()==str(Path(old_object['path'])).lower():newcommand.append(str(CHECKS/'grouped-test.obj'));replaced+=1
    else:newcommand.append(arg)
assert replaced==1
newcommand+=['/OUT:'+str(CHECKS/'ct-grouped-reference-test.exe'),'/MAP:'+str(CHECKS/'ct-grouped-reference-test.map'),'/IMPLIB:'+str(CHECKS/'ct-grouped-reference-test.lib')]
tmp=CHECKS/'tmp';tmp.mkdir(exist_ok=True);env['TMP']=env['TEMP']=str(tmp);run('link',newcommand)
inputs=[identity(x) for x in newcommand[1:] if Path(x).is_file()];assert len(inputs)==173
old_inputs={str(Path(x['path'])).lower():x for x in linked['inputs']};common=[x for x in inputs if str(Path(x['path'])).lower() in old_inputs]
assert len(common)==172 and all(x==old_inputs[str(Path(x['path'])).lower()] for x in common)
save(CHECKS/'link-plan.json',dict(command=newcommand,inputs=inputs,baseline=identity(BASE/'link-plan.json'),replaced_wrapper=dict(before=old_object,after=identity(CHECKS/'grouped-test.obj')),unchanged_input_count=172,executable=identity(CHECKS/'ct-grouped-reference-test.exe')))
fixture_snapshot=CHECKS/'ct_packed_grouped_fixture.h';fixture_snapshot.write_bytes(fixture.read_bytes())
save(CHECKS/'source-freeze.json',dict(wrapper=identity(source),fixture=identity(fixture),fixture_snapshot=identity(fixture_snapshot),original_product_freeze=identity(STAGE/'final-source-freeze.json'),scope='Only shared test profiles added: sym128 and sym512; sym512 source scale F32 matches catalog24. Attempt2 compiled but not GPU-run. Product and old-neighbor objects unchanged; old wrapper/image/XML retained.'))
save(CHECKS/'build-receipt.json',dict(status='compiled_linked_ready_for_root_GPU',CXX=1,links=1,GLSL=0,SDK=0,this_agent_GPU=0,
    image=identity(CHECKS/'ct-grouped-reference-test.exe'),link_plan=identity(CHECKS/'link-plan.json'),test_receipt=identity(CHECKS/'grouped-test-identity.json'),
    unchanged_inputs=172,new_filter='VulkanCtPackedGroupedGraph.*',expected_cases=3,expected_lifetime_submissions=20,
    prior_validation=identity(STAGE/'validation/attempt1/receipt.json'),limits='Prior 11-case process validates original products/neighbors. New3-case process validates widened finite fixture using the same products, not14 independent test cases.'))
print('image',identity(CHECKS/'ct-grouped-reference-test.exe'))
print('receipt',identity(CHECKS/'build-receipt.json'))
