"""Publish current source and the exact, bounded windows actually executed."""
from pathlib import Path
import hashlib,json,xml.etree.ElementTree as ET,zipfile
S=Path(__file__).resolve().parent;ROOT=S.parents[2]
DEST=ROOT/'docs/evidence/correctness/ct-packed-grouped-space-2026-10-21'
def load(p):return json.loads(Path(p).read_text(encoding='utf-8'))
def encoded(value):return (json.dumps(value,ensure_ascii=False,indent=2)+'\n').encode('utf-8')
def identity(p):
 p=Path(p);raw=p.read_bytes()
 return dict(path=str(p),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())

windows={
 'Windows CPU': ['cpu-cuda/validation/cpu/tests.xml','cpu-cuda/validation/cpu-default/tests.xml'],
 'Windows CUDA RTX4070': ['cuda/validation/final1/tests.xml','cuda/validation/shared-loader-neighbor/tests.xml'],
 'Windows Vulkan RTX4070': ['vulkan/validation/attempt1/tests.xml','vulkan/validation/final1/tests.xml'],
 'macOS Apple M4': ['apple/first-complete-pass/remote/results/tests.xml','apple/mac/remote/results/tests.xml','apple/mac/remote/results/copy-neighbor.xml'],
}
results=[]
for (backend,paths),expected in zip(windows.items(),[14,11,11,11]):
 unique={};details=[]
 for relative in paths:
  p=S/relative;cases=ET.parse(p).findall('.//testcase')
  assert cases and not any(x.find('failure') is not None or x.find('skipped') is not None for x in cases),relative
  names=[]
  for case in cases:
   name=case.get('classname')+'.'+case.get('name');names.append(name)
   unique[name]=dict(name=name,latest_window=relative,properties={r.get('name'):r.get('value') for r in case.findall('./properties/property')})
  details.append(dict(xml=relative,identity=identity(p),passed=len(cases),failed=0,skipped=0,names=names))
 assert len(unique)==expected,(backend,len(unique))
 assert any(row['properties'].get('actual_submissions')=='20' for row in unique.values())
 assert any(row['properties'].get('expected_failed_completions')=='2' for row in unique.values())
 results.append(dict(backend=backend,different_cases_passed=len(unique),failed=0,skipped=0,windows=details,cases=list(unique.values()),
  counting='Different case names across related windows; later same-name results supersede earlier results, not extra cases or one full final-image rerun'))

sources=[
 'include/hyle/compute/model_ops.h','src/compute_ops/weight_decode.cc','src/compute_ops/operation.cc',
 'src/graph/artifact_packed_region.h','src/compute_packed_shared/artifact_packed_linear.h',
 'src/compute_provider_native/ct_packed.cc','src/compute_provider_native/native_provider.cc',
 'src/compute_provider_torch_cuda/artifact_provider.cc','src/compute_provider_torch_cuda/mlx_packed_kernel.h',
 'src/compute_provider_torch_cuda/mlx_packed_kernel.cu','src/compute_provider_cuda/packed_rows.cuh',
 'src/compute_route_vulkan/vulkan_ct_packed.cc','src/compute_route_vulkan/vulkan_operations.cc',
 'src/graph_route_vulkan/native_region.cc','src/compute_route_vulkan/shaders/ct_packed.comp','src/compute_route_vulkan/build_shaders.py',
 'src/compute_route_apple/apple_ct_packed.cc','src/compute_route_apple/apple_memory.mm','src/compute_route_apple/apple_tensor.cc',
 'src/compute_route_apple/apple_mature_float.cc','src/graph_route_apple/native_region.cc','src/graph_route_apple/apple_lowering.cc',
 'src/compute_shader_shared/ct_packed.h','src/compute_shader_shared/nvfp4_f32.h',
 'tests/compute_models/ct_packed_linear_fixture.h','tests/compute_models/ct_packed_graph_fixture.h','tests/compute_models/ct_packed_grouped_fixture.h',
]
for arm in ['cpu','cuda','vulkan','apple']:
 sources.extend([f'tests/graph_route_{arm}/ct_packed_grouped_test.cc',f'tests/graph_route_{arm}/CMakeLists.txt'])
frozen=[identity(ROOT/p) for p in sources]
(S/'root/final-source-freeze.json').write_bytes(encoded(dict(files=frozen)))
fixture=next(r for r in frozen if r['path'].endswith('ct_packed_grouped_fixture.h'))
assert fixture['sha256']=='dcadf216276544c7145c913200f38dd762f0cb76d41cce0776b165bac1d3b7b9'
catalog_validation=load(S/'catalog-update/validation.json')
catalog=load(ROOT/'docs/implementation/model-quantizations.json')
assert len(catalog['artifacts'])==33 and all(not x['provider_coverage']['artifact_execution_verified'] for x in catalog['artifacts'])
report=dict(
 status='PASS: closed ordinary CT INT4 grouped/expert recipe consumes selected packed rows on four backends',
 public_recipe='Original ArtifactWeightDecode(Q,[Z],SF)->optionalCast->Reshape[E,N,K]->optionalCast->GroupedMatMul(W,A,IDs); at most one Cast. No grouped transpose. Existing public operation vocabulary retained.',
 private_carrier='Same-build ArtifactPackedLinear adds only expert_count. Nonzero denotes the exact public reshape; original ports A,Q,[Z],SF,IDs. No fragmented-bank or new quantizer meaning.',
 numerical_contract=dict(
  original_bank='I32 Q[E*N,K/8], floating SF[E*N,K/group], optional I32 Z[ceil(E*N/8),K/group]. Adjacent K codes are low-nibble first, centered by8 or the original per-row zero nibble.',
  rounding='Preserve source-scale-type multiplication RNE, then declared Decode dtype and actual W operand dtype before backend F32 dot. Public A and output stay F32; W operand is F32 or BF16 under GroupedMatMul. No activation QDQ.',
  parameters='Group32/128/512 use one existing group_size parameter, not producer/model version switches.',
  flat_zero_axis='bank_row=ID*N+n; asymmetric zero word/nibble derives from bank_row/8 and bank_row%8. Independently padded per-expert Z tensors cannot be concatenated blindly.',
  reduction='Existing backend F32 reductions retained. One-hot finite activations independently expose storage rounds without assuming cross-backend reduction-tree equality.'),
 coverage=dict(
  finite_profiles=['symmetric g32 BF16 scale->F16 decode->F32 W with sharedA1',
   'asymmetric g128 F16 scale->BF16 decode/W with independent slots and Cast after reshape',
   'asymmetric g512 BF16 scale->F32 decode->BF16 W, E17/Nodd, zero-slot stride, token padding and Kstride8',
   'symmetric g128 BF16 scale->F32 decode/W with sharedA1, noCast recipe',
   'symmetric g512 F32 scale->BF16 decode/W with independent slots, noCast recipe'],
  lifetime='Per backend20 valid stable-bank/input/ID updates over independent slots; retained output prevents replay, other-slot output stays intact, CompiledGraph owner is dropped and output survives Invocation destruction. Case.graph itself remains alive.',
  domain='Per backend3 successful checked-domain submissions and2 expected failed Completions for invalid last IDs, each using a fresh slot; no selected bank address before complete ID validation.',
  escape='Per backend1 ordinary execution with published original Decode, exact decoded bytes checked and packed policy absent.',
  CUDA='Positive grouped lifetime/domain paths RequireCapture and assert kCaptured; observable-Decode path retains original command decomposition.',
  default='CPU normal default compiler now selects the packed policy without RequirePrepared; CUDA normal compile and Apple/Vulkan space-prioritized closed candidates also select it. Dense old defaults remain unchanged.'),
 resources=dict(
  weights='No full E*N*K floating decoded W in the contracted leaf. Original single packed carrier remains resident; each selected bank row/group is decoded into bounded stack/register work.',
  CPU='Original NativePlan layout and parallel/mapping/Completion machinery;64-value stack tiles and no extra dense workspace.',
  CUDA='Existing checked-ID and packed row kernels; grouped rows do not share W across different expert IDs. Three immutable A byte strides, existing stream/status/capture; no A expansion or new executor.',
  Vulkan='Same Program/Invocation with one checked-ID phase followed by selected dot and existing status barriers; only actual original/output carriers bounded by U32/device ranges. Old dense CT/GPTQ SPV variants recompile byte-identically.',
  Apple='Original Metal codec and lazy native Program. Read-only borrowed whole-element strides preserve physical span and owner; opaque MLX allocator totals remain unknown.',
  pending='Separately stored checkpoint experts/catalog WeightSlots/global-local IDs/working-set residency remain delivery3. This single canonical flat bank does not prove fragmented binding or >=4GiB bank support.'),
 additional_Apple_fixes=dict(
  strided_borrow='Former dense-only borrow rejected valid public strided A before the kernel. Private read-only metadata bridge now admits whole-element strides with original Shared Metal owner, offset/span and allocation limits; no A copy or writable-domain expansion.',
  flags='Actual shape[2,2,2]/elementstrides[1,1,5] has overlapping addresses and holes despite equal count/span. Sorted nonzero physical-stride packed-chain proof prevents false contiguity.',
  Copy='Locked MLX Copy aliases its source, so it cannot implement public dense independent Copy. Same-width integer View plus one original Full/Contiguous copy preserves bits, dense output and snapshot independence; both dense/overlap-hole sources are overwritten after Completion while retained outputs stay exact.',
  tested='Final4 new Apple cases and the Copy-affected old CT escape pass. Earlier7 denseCT/GPTQ neighbors are preserved; other6 were carried without unrelated repeated runs.'),
 architecture='Only common cold recipe/private geometry and actual backend leaves/metadata bridge changed. Shared Graph scheduler, leases, resource retirement, NativePlan layout and public CMake/user switches were not extended.',
 results=results,different_case_count=47,failed=0,skipped=0,
 counting='47 distinct test names across explicit related windows, including unchanged-neighbor carry-forward. This is not47 artifacts or one full final-image test matrix.',
 new_grouped_submissions_per_backend=dict(lifetime_success=20,domain_success=3,expected_failed=2,original_escape_success=1),
 catalog=dict(indices=[22,24],operator_evidence_only=True,artifact_execution_verified_false_count=33,update=catalog_validation,
  limitations='Kimi group128 card lacks full header/dtype binding; custom K512 declares F32 weight scale but no A8 quantizer. Synthetic software tests do not execute publisher payload/importer/whole artifacts.'),
 retained_failures=['Initial shared matcher incorrectly called built-in get_if for custom GroupedMatMul; corrected to custom_as. Strict errors retained.',
  'Apple first actual grouped run passed9/10; existing read-only dense borrow blocked the strided A. The metadata bridge fixes the actual seam.',
  'Apple overlap/hole guard exposed public Copy output without a memory projection; locked SDK source proved Copy aliases. One native storage-exact copy now meets the public contract.',
  'Two CUDA scratch planner/environment assumptions failed before NVCC launch; actual native flags/recipe were then retained, with no SDK rebuild or weakened compile flags.',
  'Final symmetric128 and symmetric512/F32-scale/noCast witnesses were added after exact catalog scope review; only affected wrapper objects were refreshed. Earlier snapshots/windows remain separate.'],
 reviews=['review/vulkan-start.json','review/shared-source-review.json','vulkan/peer-source-review.json','cpu-cuda/final-validation.json','apple/final-validation.json'],
 limits=['No publisher numeric payload, complete artifact/model, import/header qualification or quality result.',
  'No Linux or installed-consumer qualification by this package; Windows CPU/CUDA/Vulkan and M4 Apple were used.',
  'No throughput, peak-memory, energy, tensor-core CT GEMM or full FFN fusion claim; current BF16 Qwen decode uses another path.',
  'Arbitrary strided original Apple GroupedMatMul remains its earlier capability domain; the tested Kstride8 recipe uses the packed candidate.',
  'No cross-backend all-domain bit-equivalent reduction, giant-bank or fragmented-expert resource proof.'],
 progress=dict(capability_packages_complete=7,capability_packages_total=8,delivery_packages_complete=0,delivery_packages_total=3,
  next='Fixed-source exact role binding and documentation closure, then current-source/installed-consumer, GPU lifetime and working-set delivery packages'))

entries={};allowed={'.py','.json','.cc','.cpp','.h','.cu','.cuh','.mm','.metal','.glsl','.comp','.log','.xml','.d','.diff','.txt','.spv','.sh','.ps1'}
for p in sorted(S.rglob('*')):
 if not p.is_file() or '__pycache__' in p.parts or p.name in ['package-receipt.json','cleanup-plan.json'] or p.suffix.lower() not in allowed:continue
 entries[p.relative_to(S).as_posix()]=p.read_bytes()
for relative,row in zip(sources,frozen):
 raw=(ROOT/relative).read_bytes();assert hashlib.sha256(raw).hexdigest()==row['sha256']
 entries['current-source/'+relative]=raw
entries['report-core.json']=encoded(report)
entries['inventory.json']=encoded(dict(members=[dict(member=n,bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest()) for n,raw in sorted(entries.items())],scope='All members except this inventory; binaries, objects, maps, libraries and SDK archives excluded'))
assert not DEST.with_suffix('.json').exists() and not DEST.with_suffix('.zip').exists(),'Preserve published evidence'
with zipfile.ZipFile(DEST.with_suffix('.zip'),'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for n,raw in sorted(entries.items()):
  assert not n.startswith('/') and '..' not in Path(n).parts
  z.writestr(n,raw)
with zipfile.ZipFile(DEST.with_suffix('.zip')) as z:
 assert z.testzip() is None and len(z.namelist())==len(set(z.namelist()))
 for n,raw in entries.items():assert z.read(n)==raw
report['archive']=dict(identity=identity(DEST.with_suffix('.zip')),members=len(entries),current_sources=len(frozen))
DEST.with_suffix('.json').write_bytes(encoded(report))
receipt=dict(report=identity(DEST.with_suffix('.json')),archive=report['archive'],different_passed_cases=47,failed=0,skipped=0)
(S/'package-receipt.json').write_bytes(encoded(receipt));print(json.dumps(receipt,indent=2))
