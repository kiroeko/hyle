$ErrorActionPreference = 'Stop'
$workspaceRoot = 'C:\public\project-hyle\hyle'
$planPath = Join-Path $workspaceRoot '.scratch\architecture-refactor-2026-10-18\ct-packed-grouped-space\root\cleanup-plan.json'
$receiptPath = Join-Path $workspaceRoot 'docs\evidence\correctness\ct-packed-grouped-space-2026-10-21.cleanup.json'
if (Test-Path -LiteralPath $receiptPath) { throw 'This exact cleanup already has a receipt; do not rerun.' }
$plan = Get-Content -LiteralPath $planPath -Raw -Encoding UTF8 | ConvertFrom-Json
$allowedRoot = (Resolve-Path -LiteralPath $plan.root).ProviderPath.TrimEnd('\') + '\'
$expectedRoot = (Join-Path $workspaceRoot '.scratch\architecture-refactor-2026-10-18\ct-packed-grouped-space').TrimEnd('\') + '\'
if ($allowedRoot -ine $expectedRoot) { throw 'Unexpected cleanup root.' }
function Assert-Identity($entry) {
    $item = Get-Item -LiteralPath $entry.path
    if ($item.PSIsContainer -or ($item.Attributes -band [IO.FileAttributes]::ReparsePoint)) { throw 'Expected an ordinary exact file.' }
    if ($item.Length -ne $entry.bytes) { throw "Size changed: $($entry.path)" }
    if ((Get-FileHash -LiteralPath $entry.path -Algorithm SHA256).Hash -ine $entry.sha256) { throw "Hash changed: $($entry.path)" }
}
Assert-Identity $plan.artifact
foreach ($entry in $plan.protected) { Assert-Identity $entry }
foreach ($entry in $plan.targets) {
    $resolved = (Resolve-Path -LiteralPath $entry.path).ProviderPath
    if (-not $resolved.StartsWith($allowedRoot, [StringComparison]::OrdinalIgnoreCase)) { throw 'Target escapes the exact batch directory.' }
    if ([IO.Path]::GetExtension($resolved) -notin @('.exe','.map','.lib','.exp')) { throw 'Unexpected deletion extension.' }
    Assert-Identity $entry
}
foreach ($entry in $plan.targets) { Remove-Item -LiteralPath $entry.path -Force }
foreach ($entry in $plan.protected) { Assert-Identity $entry }
foreach ($entry in $plan.targets) { if (Test-Path -LiteralPath $entry.path) { throw 'Deletion incomplete.' } }
$receipt = [ordered]@{
    status = 'complete'
    removed_files = @($plan.targets).Count
    removed_bytes = $plan.reclaim_bytes
    targets = $plan.targets
    protected = $plan.protected
    archive = $plan.artifact
    cleanup_script_sha256 = (Get-FileHash -LiteralPath $PSCommandPath -Algorithm SHA256).Hash.ToLowerInvariant()
    cleanup_script = Get-Content -LiteralPath $PSCommandPath -Raw
    scope = $plan.scope
}
$receipt | ConvertTo-Json -Depth 10 | Set-Content -LiteralPath $receiptPath -Encoding utf8
Write-Output "Removed $(@($plan.targets).Count) exact rebuildable files, $($plan.reclaim_bytes) bytes; all protected objects and current Qwen consumer remain unchanged."
