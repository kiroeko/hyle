from pathlib import Path
import importlib.util
import shutil
import sys
import xml.etree.ElementTree as ET
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('ct_grouped_observe_helpers',S/'build.py')
h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
b,c=h.b,h.c
target=S/'final-validation.json'
old=c.read(target)
assert old['status']=='CPU14pass_CUDA_image_ready_root_owns_GPU'
revision=S/'revisions/before-root-gpu-receipts';revision.mkdir(parents=True,exist_ok=True)
shutil.copyfile(target,revision/'final-validation.json')
rows=[];names=[]
for name,expected in [('final1',10),('shared-loader-neighbor',1)]:
    out=S.parent/'cuda/validation'/name
    receipt=c.read(out/'receipt.json')
    cases=ET.parse(out/'tests.xml').findall('.//testcase')
    assert len(cases)==expected and receipt['passed'] and receipt['cases']==expected
    assert all(x.find('failure') is None and x.find('skipped') is None for x in cases)
    assert b.same(receipt['xml']) and b.same(receipt['image']) and b.same(receipt['link_plan'])
    actual_names=[x.get('classname')+'.'+x.get('name') for x in cases]
    assert actual_names==receipt['names']
    names.extend(actual_names)
    rows.append(dict(receipt=b.identity(out/'receipt.json'),xml=receipt['xml'],cases=expected,
                     command=b.identity(out/'tests.command.json'),result=b.identity(out/'tests.result.json')))
assert len(set(names))==11
freeze=c.read(S/'source-freeze.json')
assert all(b.identity(x['path'])=={k:x[k] for k in ('path','bytes','sha256')} and
           b.same(x['snapshot']) for x in freeze['files'])
old['status']='CPU14_CUDA11_pass_0skip'
old['CUDA']=dict(cases=11,failed=0,skipped=0,root_GPU_processes=2,executed_by_this_agent=False,
    receipts=rows,names=names,image=old['images']['cuda'],link_plan=old['links']['cuda'],
    new_grouped=dict(cases=3,lifetime_success=20,runtime_success=3,expected_failed_completions=2,escape_success=1),
    capture='Passed original tests require RequireCapture and assert kCaptured for packed life/domain; escape uses Commands.',
    loader_default_neighbor='CudaGroupedShared.PackedSharedInputsRetainOriginalQuantizationAndCapture')
old['limitations']=[
    'GPU executions performed by root, not this implementation/build agent; exact root receipts are referenced.',
    'No throughput, real artifact payload/import, quality, whole-model or Linux claims.',
    'Default packed_rows loaders retain the original address expression through if constexpr; actual original packed shared/capture neighbor passed.',
    'No SDK rebuild, NativePlan layout change, whole floating expert bank, new executor or A quantization.']
c.save(target,old)
print(b.identity(target))
