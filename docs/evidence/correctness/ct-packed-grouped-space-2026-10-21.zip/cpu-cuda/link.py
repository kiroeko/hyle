from pathlib import Path
import importlib.util
import json
import sys
import xml.etree.ElementTree as ET
sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('ct_grouped_build', S/'build.py')
h = importlib.util.module_from_spec(spec); spec.loader.exec_module(h)
b,c = h.b,h.c

def identity(path):
    return c.read(path)

def records(arm):
    files = [S/'checks/products-cpu/attempt1/ct-packed/ct-packed-identity.json',
             S/'checks/products-cpu/attempt1/native-provider/native-provider-identity.json',
             S/f'checks/region-{arm}/attempt1/packed-region/packed-region-identity.json',
             S/f'checks/old-neighbor-{arm}/attempt1/ct-linear-test/ct-linear-test-identity.json']
    if arm == 'cpu':
        files += [S/'checks/direct-neighbors/attempt1/ct-direct-test/ct-direct-test-identity.json',
                  S/'checks/direct-neighbors/attempt1/gptq-direct-test/gptq-direct-test-identity.json']
    else:
        files += [S/'checks/products-cuda/attempt1/artifact-provider/artifact-provider-identity.json',
                  S/'checks/product-native/attempt2/mlx-packed-kernel/mlx-packed-kernel-identity.json']
    return [(p,c.read(p)) for p in files]

def link(arm,attempt='attempt1',test_attempt='attempt2'):
    out = S/f'checks/link-{arm}/{attempt}'
    out.mkdir(parents=True,exist_ok=True); (out/'tmp').mkdir(exist_ok=True)
    assert not (out/'link.result.json').exists()
    basepath=h.BASES[arm]; base=c.read(basepath)
    actual=h.h.metadata({arm:base})
    replacements=[]
    for path,record in records(arm):
        source=record['source']['path']
        matches=[row for row in base['inputs'] if c.key(actual.get(c.key(row['path']),{}).get('source_path',''))==c.key(source)]
        if not matches:
            # CPU provider is absent from some CUDA-only graphs. Never insert a
            # host owner that was not part of that actual baseline.
            assert arm=='cuda' and Path(source).name=='native_provider.cc', source
            continue
        assert len(matches)==1,(source,len(matches))
        assert b.same(record['object']) and b.same(record['source'])
        replacements.append(dict(before=matches[0],after=record['object'],owner=b.identity(path)))
    extra_path=S/f'checks/tests-{arm}/{test_attempt}/grouped-test/grouped-test-identity.json'
    extra=c.read(extra_path)
    assert b.same(extra['object']) and b.same(extra['source'])
    frozen_fixture=next(x for x in extra['dependencies'] if Path(x['path']).name=='ct_packed_grouped_fixture.h')
    assert b.same(frozen_fixture) and frozen_fixture['sha256']=='dcadf216276544c7145c913200f38dd762f0cb76d41cce0776b165bac1d3b7b9'
    swaps={c.key(x['before']['path']):x['after']['path'] for x in replacements}
    image=out/(arm+'.exe')
    command=[swaps.get(c.key(x),x) for x in base['command'] if not x.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:'))]
    command.insert(1,extra['object']['path'])
    command += ['/OUT:'+str(image),'/MAP:'+str(image.with_suffix('.map')),'/IMPLIB:'+str(image.with_suffix('.lib'))]
    ids={c.key(x['path']):x for x in base['inputs']}
    ids.update({c.key(x['after']['path']):x['after'] for x in replacements})
    ids[c.key(extra['object']['path'])]=extra['object']
    paths=[x for x in command if Path(x).is_absolute() and Path(x).suffix.lower() in ('.obj','.lib')]
    assert len(paths)==len(set(map(c.key,paths)))
    inputs=[ids[c.key(x)] for x in paths]
    assert all(b.same(x) for x in inputs)
    plan=dict(command=command,inputs=inputs,base=b.identity(basepath),replacements=replacements,
              added_test=b.identity(extra_path),fixture=frozen_fixture,SDK_builds=0,GPU_runs=0)
    c.save(out/'link-plan.json',plan)
    env,runtime=b.environment(command,[x['path'] for x in inputs],out)
    c.save(out/'runtime-environment.json',dict(PATH=env['PATH'],runtime=runtime))
    c.execute('link',command,env,out)
    c.save(out/'image.json',b.identity(image))
    print(json.dumps(dict(arm=arm,image=b.identity(image),inputs=len(inputs),replacements=len(replacements)),indent=2),flush=True)

def run_cpu(attempt='attempt1',label='cpu',filter='CpuCtPackedGrouped.*:NativeCtPackedLinear.*:NativeGptq.*:CpuCtPackedLinear.*'):
    out=S/'validation'/label; out.mkdir(parents=True,exist_ok=True)
    checks=S/'checks/link-cpu'/attempt
    plan=c.read(checks/'link-plan.json'); image=c.read(checks/'image.json')
    assert b.same(image) and all(b.same(x) for x in plan['inputs'])
    assert not (out/'tests.result.json').exists()
    command=[image['path'],'--gtest_filter='+filter,'--gtest_output=xml:'+str(out/'tests.xml')]
    env,_=b.environment(plan['command'],[x['path'] for x in plan['inputs']],out)
    try:
        c.execute('tests',command,env,out)
    finally:
        if (out/'tests.xml').exists():
            cases=ET.parse(out/'tests.xml').findall('.//testcase')
            failed=[x.attrib for x in cases if x.find('failure') is not None]
            skipped=[x.attrib for x in cases if x.find('skipped') is not None]
            result=dict(passed=bool(cases) and not failed and not skipped,cases=len(cases),failed=failed,skipped=skipped,
                filter=filter,names=[x.get('classname')+'.'+x.get('name') for x in cases],
                properties=[dict(case=x.get('classname')+'.'+x.get('name'),properties=[p.attrib for p in x.findall('./properties/property')]) for x in cases],
                image=image,link_plan=b.identity(checks/'link-plan.json'),xml=b.identity(out/'tests.xml'))
            c.save(out/'summary.json',result)
            print(json.dumps(result,indent=2),flush=True)

if __name__=='__main__':
    mode=sys.argv[1]
    if mode=='cpu-run': run_cpu()
    elif mode=='cpu-default-run': run_cpu('attempt2','cpu-default','CpuCtPackedGrouped.*')
    else: link(mode,*(sys.argv[2:]))
