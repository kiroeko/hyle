from pathlib import Path
import difflib
import importlib.util
import json
import shutil
import sys
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('ct_default_helpers',S/'build.py')
h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
b,c=h.b,h.c
old_freeze=c.read(S/'source-freeze.json')
wrapper=h.ROOT/'tests/graph_route_cpu/ct_packed_grouped_test.cc'
new_rows=[]
for row in old_freeze['files']:
    path=Path(row['path'])
    if path!=wrapper:
        assert b.identity(path)=={k:row[k] for k in ('path','bytes','sha256')}
    relative=path.relative_to(h.ROOT)
    dest=S/'after-default'/relative
    dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(path,dest)
    new_rows.append(dict(b.identity(path),snapshot=b.identity(dest),owner=row['owner']))
old_wrapper=next(x for x in old_freeze['files'] if Path(x['path'])==wrapper)
old_source=Path(old_wrapper['snapshot']['path'])
diff=''.join(difflib.unified_diff(old_source.read_text().splitlines(keepends=True),
    wrapper.read_text().splitlines(keepends=True),fromfile='before-default/'+str(wrapper.relative_to(h.ROOT)),
    tofile='after-default/'+str(wrapper.relative_to(h.ROOT))))
(S/'default-wrapper.diff').write_text(diff,encoding='utf-8',newline='\n')
c.save(S/'source-freeze-final.json',dict(files=new_rows,previous_freeze=b.identity(S/'source-freeze.json'),
    change='CPU wrapper uses ordinary default compile; no forced RequirePrepared. Product sources unchanged.',
    default_diff=b.identity(S/'default-wrapper.diff'),public_ABI_changed=False,NativePlan_layout_changed=False))
counts=c.read(S/'build-counts.json')
extra=c.read(S/'checks/tests-cpu/attempt3/summary.json')['owners'][0]
counts.update(successful_CXX=14,successful_links=3,CPU_test_processes=2)
counts['owners'].append(dict(extra,summary=b.identity(S/'checks/tests-cpu/attempt3/summary.json')))
counts['notes'].append('Final CPU wrapper is attempt3 without RequirePrepared; only its three new cases reran. Distinct CPU cases remain14.')
c.save(S/'build-counts-final.json',counts)
validation_path=S/'final-validation.json'
revision=S/'revisions/before-default-selection';revision.mkdir(parents=True,exist_ok=True)
shutil.copyfile(validation_path,revision/'final-validation.json')
final=c.read(validation_path)
old_cpu=final['CPU'];new_cpu=c.read(S/'validation/cpu-default/summary.json')
assert new_cpu['passed'] and new_cpu['cases']==3
final['source_freeze']=b.identity(S/'source-freeze-final.json')
final['build_counts']=b.identity(S/'build-counts-final.json')
final['CPU']=dict(cases=14,failed=0,skipped=0,distinct_counting='Current default new3 plus retained original11 neighbors; original14-window also preserved.',
    new_default3=b.identity(S/'validation/cpu-default/summary.json'),prior14=old_cpu,
    selection='Ordinary default CPU compile, no RequirePrepared; shared fixture asserts one packed region for closed profiles and zero for escape.',
    new_grouped=dict(cases=3,lifetime_success=20,runtime_success=3,expected_failed_completions=2,escape_success=1))
final['links']['cpu']=b.identity(S/'checks/link-cpu/attempt2/link-plan.json')
final['images']['cpu']=c.read(S/'checks/link-cpu/attempt2/image.json')
c.save(validation_path,final)
print(json.dumps(dict(final_validation=b.identity(validation_path),source_freeze=b.identity(S/'source-freeze-final.json'),
    build_counts=b.identity(S/'build-counts-final.json')),indent=2))
