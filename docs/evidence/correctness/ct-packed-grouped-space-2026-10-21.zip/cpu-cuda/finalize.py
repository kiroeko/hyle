from pathlib import Path
import difflib
import importlib.util
import json
import re
import shutil
import sys
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('ct_grouped_build_final',S/'build.py')
h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
b,c=h.b,h.c
ROOT=h.ROOT

owned=[r['path'] for r in c.read(S/'before.json')['files']]+c.read(S/'before.json')['new_tests']
shared=['src/compute_packed_shared/artifact_packed_linear.h','src/graph/artifact_packed_region.h',
        'tests/compute_models/ct_packed_grouped_fixture.h','tests/compute_models/ct_packed_linear_fixture.h']
sources=[];diff=[]
for name in owned+shared:
    path=ROOT/name; dest=S/'after'/name
    dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(path,dest)
    sources.append(dict(b.identity(path),snapshot=b.identity(dest),owner='cpu-cuda' if name in owned else 'root'))
    if name in owned:
        before=S/'before'/name
        old=before.read_text().splitlines(keepends=True) if before.exists() else []
        new=path.read_text().splitlines(keepends=True)
        diff.extend(difflib.unified_diff(old,new,fromfile='before/'+name,tofile='after/'+name))
(S/'implementation.diff').write_text(''.join(diff),encoding='utf-8',newline='\n')
c.save(S/'source-freeze.json',dict(files=sources,implementation_diff=b.identity(S/'implementation.diff'),
    scope='Six product sources, two wrappers and two CMake lists owned here; four common sources owned by root',
    public_ABI_changed=False,NativePlan_layout_changed=False,private_descriptor_size_bytes=24))

native_dir=S/'checks/product-native/attempt2/mlx-packed-kernel'
native=c.read(native_dir/'mlx-packed-kernel-identity.json')
dep=native_dir/'mlx-packed-kernel.d'
rhs=dep.read_text().split(' : ',1)[1].replace('\\\n',' ')
paths=[Path(x.replace('\\ ',' ')).resolve() for x in re.split(r'(?<!\\)\s+',rhs) if x]
paths=list(dict.fromkeys(paths));assert all(x.is_file() for x in paths)
native_deps=dict(compiler_dependencies=b.identity(dep),owner=b.identity(native_dir/'mlx-packed-kernel-identity.json'),
    source=native['source'],object=native['object'],dependencies=[b.identity(p) for p in paths],
    note='Sidecar enriches the complete actual nvcc .d; original owner receipt is retained unchanged')
c.save(native_dir/'full-dependency-identities.json',native_deps)

owners=[]
for summary in sorted((S/'checks').glob('*/attempt*/summary.json')):
    data=c.read(summary)
    if data.get('owners'):
        owners.extend(dict(row,summary=b.identity(summary)) for row in data['owners'])
# The host compiled successfully before a separate native-planning error; its
# actual identity exists even though that combined mode has no final summary.
host=S/'checks/products-cuda/attempt1/artifact-provider/artifact-provider-identity.json'
record=c.read(host)
assert not any(c.key(r['object']['path'])==c.key(record['object']['path']) for r in owners)
owners.append(dict(source=record['source']['path'],object=record['object'],identity=b.identity(host)))
assert len(owners)==14,len(owners)
assert sum(Path(r['source']).suffix=='.cu' for r in owners)==1
c.save(S/'build-counts.json',dict(successful_CXX=13,successful_NVCC=1,failed_compiler_invocations=0,
    planning_failures_before_native_compiler=2,successful_links=2,CPU_test_processes=1,GPU_processes_by_this_agent=0,
    SDK_builds=0,owners=owners,notes=[
        'Both three-profile wrapper objects remain in attempt1; both final five-profile wrappers are attempt2.',
        'Two scratch native planner/environment assumptions failed before nvcc launched; snapshots retained under revisions.',
        'All six current private descriptor C++ consumers in CPU and five current owners in CUDA are replaced in actual link plans.']))

cpu=c.read(S/'validation/cpu/summary.json')
links={arm:b.identity(S/f'checks/link-{arm}/attempt1/link-plan.json') for arm in ('cpu','cuda')}
images={arm:c.read(S/f'checks/link-{arm}/attempt1/image.json') for arm in ('cpu','cuda')}
assert cpu['passed'] and cpu['cases']==14 and not cpu['failed'] and not cpu['skipped']
c.save(S/'final-validation.json',dict(status='CPU14pass_CUDA_image_ready_root_owns_GPU',
    source_freeze=b.identity(S/'source-freeze.json'),build_counts=b.identity(S/'build-counts.json'),
    CPU=dict(cases=14,failed=0,skipped=0,receipt=b.identity(S/'validation/cpu/summary.json'),
             new_grouped=dict(cases=3,lifetime_success=20,runtime_success=3,expected_failed_completions=2,escape_success=1)),
    CUDA=dict(executed_by_this_agent=False,image=images['cuda'],link_plan=links['cuda'],
        recommended_filter='CudaCtPackedGrouped.*:CudaCtPackedLinear.*'),
    links=links,images=images,native_complete_deps=b.identity(native_dir/'full-dependency-identities.json'),
    limitations=['No CUDA execution by this agent; root owns GPU validation.',
        'No throughput, real artifact payload/import, quality, whole-model or Linux claims.',
        'Default packed_rows loaders retain the original address expression through if constexpr; unrelated native owners reused, no SDK rebuild.']))
print(json.dumps(dict(source_freeze=b.identity(S/'source-freeze.json'),
    final_validation=b.identity(S/'final-validation.json'),native_dependency_count=len(paths),
    counts=b.identity(S/'build-counts.json')),indent=2))
