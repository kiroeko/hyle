from pathlib import Path
import concurrent.futures
import importlib.util
import json
import sys
sys.dont_write_bytecode = True

S = Path(__file__).resolve().parent
A = S.parents[1]
ROOT = A.parents[1]
spec = importlib.util.spec_from_file_location('grouped_ct_helpers', A/'grouped-shared-activation/build_host.py')
h = importlib.util.module_from_spec(spec)
spec.loader.exec_module(h)
b, c = h.b, h.c
BASES = {arm: A/'ct-channel-token-cross-backend'/arm/'checks'/('attempt2' if arm=='cpu' else 'attempt1')/'link-plan.json' for arm in ('cpu','cuda')}


def native_command(recipe, source, tag, out):
    result, skip = [], False
    for arg in recipe:
        if skip:
            skip = False
            continue
        if arg in ('-c', '-o', '-MT', '-MF'):
            skip = True
        elif not arg.startswith('-Xcompiler=-Fd'):
            result.append(arg)
    assert '-std=c++20' in result
    assert '--generate-code=arch=compute_89,code=[compute_89,sm_89]' in result
    return result + ['-MT', str(out/(tag+'.obj')), '-MF', str(out/(tag+'.d')),
        '-c', str(source), '-o', str(out/(tag+'.obj')),
        '-Xcompiler=-Fd'+str(out/(tag+'.pdb'))+',-FS']


def compile_owner(source, tag, old_source, arm, out):
    base = c.read(BASES[arm])
    metadata = h.metadata({arm: base})
    matches = [(row, metadata.get(c.key(row['path']))) for row in base['inputs']
        if c.key(metadata.get(c.key(row['path']), {}).get('source_path', '')) == c.key(old_source)]
    assert len(matches) == 1, (str(old_source), len(matches))
    old, recipe = matches[0]
    out.mkdir(parents=True, exist_ok=True)
    (out/'tmp').mkdir(exist_ok=True)
    assert not (out/'compile.result.json').exists(), 'Keep actual attempts'
    native = source.suffix == '.cu'
    command = (native_command if native else b.host_command)(recipe['command'], source, tag, out)
    source_before = b.identity(source)
    c.save(out/'plan.json', dict(source=source_before, command=command, old_object=old,
        recipe=b.identity(recipe['recipe']), base=b.identity(BASES[arm]), SDK_rebuilt=False))
    env, _ = b.environment(command, [], out)
    c.execute('compile', command, env, out)
    obj = b.identity(out/(tag+'.obj'))
    assert b.same(source_before)
    if native:
        deps = out/(tag+'.d')
        # Preserve the actual native compiler dependency file verbatim; source
        # identities below retain the local changed closure alongside it.
        local = [ROOT/'src/compute_provider_torch_cuda/mlx_packed_kernel.h',
            ROOT/'src/compute_provider_cuda/packed_rows.cuh']
        dependencies = [b.identity(path) for path in [source, *local]]
    else:
        deps = out/(tag+'-deps.json')
        data = c.read(deps)['Data']
        dependencies = [b.identity(path) for path in dict.fromkeys([data['Source'], *data['Includes']])]
    identity = dict(source=source_before, object=obj, command=command, source_dependencies=b.identity(deps),
        dependencies=dependencies, recipe=b.identity(recipe['recipe']), old_object=old)
    c.save(out/(tag+'-identity.json'), identity)
    return dict(source=str(source), tag=tag, identity=b.identity(out/(tag+'-identity.json')), object=obj, old_object=old)


def main():
    mode, attempt = sys.argv[1:3]
    if mode == 'products-cpu':
        rows = [('src/compute_provider_native/ct_packed.cc','ct-packed'),
                ('src/compute_provider_native/native_provider.cc','native-provider')]
        arm = 'cpu'
    elif mode == 'products-cuda':
        rows = [('src/compute_provider_torch_cuda/artifact_provider.cc','artifact-provider'),
                ('src/compute_provider_torch_cuda/mlx_packed_kernel.cu','mlx-packed-kernel')]
        arm = 'cuda'
    elif mode == 'product-native':
        rows = [('src/compute_provider_torch_cuda/mlx_packed_kernel.cu','mlx-packed-kernel')]
        arm = 'cuda'
    elif mode in ('tests-cpu','tests-cuda'):
        arm = mode.removeprefix('tests-')
        rows = [(f'tests/graph_route_{arm}/ct_packed_grouped_test.cc','grouped-test')]
    else:
        raise ValueError(mode)
    out = S/'checks'/mode/attempt
    plans=[]
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
        jobs = []
        for name, tag in rows:
            source = ROOT/name
            old = ROOT/f'tests/graph_route_{arm}/ct_packed_linear_test.cc' if mode.startswith('tests-') else source
            jobs.append(pool.submit(compile_owner, source, tag, old, arm, out/tag))
        for future in jobs:
            plans.append(future.result())
    c.save(out/'summary.json', dict(mode=mode, owners=plans, SDK_builds=0, GPU_runs=0))
    print(json.dumps(dict(path=str(out/'summary.json'), owners=plans), indent=2), flush=True)


if __name__ == '__main__':
    main()
