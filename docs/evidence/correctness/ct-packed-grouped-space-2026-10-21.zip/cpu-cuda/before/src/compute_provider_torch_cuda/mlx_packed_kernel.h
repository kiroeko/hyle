#pragma once

#include <cstdint>
#include <cuda_runtime_api.h>

namespace hyle::compute::torch_cuda::native {
enum class MlxFormat { kAffine, kMxfp4, kMxfp8 };
enum class MlxKind { kLinear, kGrouped, kEmbedding };
enum class Scalar { kFloat16, kBFloat16, kFloat32 };
struct MlxPacked final {
  MlxFormat format;
  MlxKind kind;
  Scalar activation_type, scale_type, output_type;
  std::uint32_t bits, group;
  std::uint64_t rows, columns, depth, experts;
  // Private host/native geometry, in activation elements. IDs/output retain
  // rows=T*S; shared activation slots use a real zero stride.
  std::uint64_t slots, activation_token_stride, activation_slot_stride;
};
enum class ArtifactFormat { kCtSymmetric, kCtAsymmetric, kGptqV1Int4 };
struct ArtifactPacked final {
  ArtifactFormat format;
  Scalar scale_type, decode_type, operand_type;
  std::uint32_t group;
  std::uint64_t rows, columns, depth;
};
struct StaticFloat8 final {
  Scalar activation_type, output_type;
  std::uint64_t rows, columns, depth;
};
cudaError_t static_fp8_prepare(const StaticFloat8 &program) noexcept;
cudaError_t static_fp8_launch(const StaticFloat8 &program,
    const void *const *inputs, void *encoded_activation, void *output,
    cudaStream_t stream) noexcept;
cudaError_t mlx_packed_launch(const MlxPacked &program,
    const void *const *inputs, void *output, unsigned *status,
    cudaStream_t stream) noexcept;
cudaError_t artifact_packed_prepare(const ArtifactPacked &program,
    bool decode_only) noexcept;
cudaError_t artifact_packed_linear_launch(const ArtifactPacked &program,
    const void *const *inputs, void *output, unsigned *status,
    cudaStream_t stream) noexcept;
cudaError_t gptq_decode_launch(const ArtifactPacked &program,
    const void *const *inputs, void *output, unsigned *status,
    cudaStream_t stream) noexcept;
} // namespace hyle::compute::torch_cuda::native
