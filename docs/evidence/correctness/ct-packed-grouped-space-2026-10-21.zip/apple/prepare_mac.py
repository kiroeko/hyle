from pathlib import Path
import base64
import hashlib
import json
import re
import subprocess

S = Path(__file__).resolve().parent
A = S.parents[1]
ROOT = A.parents[1]
O = S / "mac"
O.mkdir(exist_ok=True)
REMOTE = "/Users/kiro/hyle-scratch/compute-unified/architecture-refactor-20261019-apple-page-invocation/ct-packed-grouped-space/apple"


def read(p):
    return json.loads(Path(p).read_text(encoding="utf-8"))


def save(p, value):
    Path(p).write_text(json.dumps(value, indent=2) + "\n", encoding="utf-8")


def identity(p):
    p = Path(p)
    b = p.read_bytes()
    return dict(path=str(p), bytes=len(b), sha256=hashlib.sha256(b).hexdigest())


def main():
    base = A / "ct-channel-token-cross-backend/apple/mac/remote"
    old = read(base / "plan.json")
    plan = dict(old)
    plan["link"] = read(base / "results/link.command.json")["argv"]
    plan["inputs"] = read(base / "results/link-inputs.json")
    plan["compile"] = []
    for source in ["src/compute_route_apple/apple_ct_packed.cc",
                   "src/compute_route_apple/apple_mature_float.cc",
                   "src/graph_route_apple/apple_lowering.cc",
                   "src/graph_route_apple/native_region.cc"]:
        recipe_base = A / ("quark-mxfp4-reference/apple/mac/remote/results" if "apple_mature_float" in source else "gptq-reference/apple/mac/remote/results")
        tag = source.replace("/", "--")
        recipe = read(recipe_base / (tag + "-compile.command.json"))["argv"]
        obj = next(x for x in plan["link"] if x.endswith("/objects/" + tag + ".o"))
        plan["compile"].append(dict(source=source,recipe=recipe,old_object=obj))
    sample = next(r for r in old["compile"] if r["source"].startswith("tests/"))
    plan["compile"].append(dict(sample,source="tests/graph_route_apple/ct_packed_grouped_test.cc",old_object=""))
    # The shared CT fixture constructor gained group_width; refresh its one
    # retained neighbor TU rather than combine old/new header definitions.
    source = "tests/graph_route_apple/ct_packed_linear_test.cc"
    recipe = read(A / "gptq-reference/apple/mac/remote/results/tests--graph_route_apple--ct_packed_linear_test.cc-compile.command.json")["argv"]
    obj = next(x for x in plan["link"] if x.endswith("/objects/" + source.replace("/", "--") + ".o"))
    plan["compile"].append(dict(source=source,recipe=recipe,old_object=obj))
    memory = read(S / "memory-original-recipe.json")
    memory["recipe"] = memory["recipe"]["argv"]
    memory["old_object"] = next(x for x in plan["link"] if "apple_memory" in x and x.endswith(".o"))
    plan["compile"].append(memory)
    source = "src/compute_route_apple/apple_tensor.cc"
    recipe = read(A / "ct-channel-token-cross-backend/apple/mac/remote/results/src--compute_route_apple--apple_tensor.cc-compile.command.json")["argv"]
    obj = next(x for x in plan["link"] if "apple_tensor" in x and x.endswith(".o"))
    plan["compile"].append(dict(source=source,recipe=recipe,old_object=obj))
    plan.update(remote=REMOTE,
                metallib="/Users/kiro/hyle-scratch/compute-unified/architecture-refactor-20261019-apple-page-invocation/f32-partials/mlx.metallib",
                filter="AppleCtPackedGrouped.*",
                source_basis=dict(apple=identity(S / "before.json"),
                    fixture=identity(ROOT / "src/compute_packed_shared/artifact_packed_linear.h"),
                    model_ops=identity(ROOT / "include/hyle/compute/model_ops.h"),
                    weight_decode=identity(ROOT / "src/compute_ops/weight_decode.cc")))
    sources = [x["source"] for x in plan["compile"]]
    search = [ROOT, ROOT / "include", *(p for p in (ROOT / "src").iterdir() if p.is_dir()),
              *(p for p in (ROOT / "third_party").iterdir() if p.is_dir())]
    seen = set()
    include = re.compile(r'^\s*#\s*include\s*[<"]([^">]+)[">]', re.M)

    def visit(path):
        path = path.resolve()
        if path in seen or not path.is_relative_to(ROOT) or not path.is_file():
            return
        if path.suffix not in [".h", ".hpp", ".hh", ".cc", ".mm", ".inc", ".inl", ".cuh"]:
            return
        seen.add(path)
        for name in include.findall(path.read_text(encoding="utf-8", errors="replace")):
            target = next((base / name for base in [path.parent, *search]
                           if (base / name).is_file()), None)
            if target:
                visit(target)
    for source in sources:
        visit(ROOT / source)
    files = []
    for path in sorted(seen):
        row = identity(path)
        row["path"] = path.relative_to(ROOT).as_posix()
        row["data"] = base64.b64encode(path.read_bytes()).decode()
        files.append(row)
    save(O / "source-manifest.json", [{k: v for k, v in row.items() if k != "data"} for row in files])
    save(O / "plan.json", plan)
    payload = dict(plan=plan, files=files,
                   script=base64.b64encode((S / "build_mac.py").read_bytes()).decode())
    code = r'''
from pathlib import Path
import base64,hashlib,json,sys,subprocess
p=json.load(sys.stdin);r=Path(p["plan"]["remote"]);r.mkdir(parents=True,exist_ok=True)
assert r.is_dir() and not r.is_symlink()
for row in p["files"]:
 b=base64.b64decode(row["data"]);assert hashlib.sha256(b).hexdigest()==row["sha256"]
 q=r/row["path"];q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(b)
(r/"source-manifest.json").write_text(json.dumps([{k:v for k,v in x.items() if k!="data"}for x in p["files"]],indent=2)+"\n")
(r/"plan.json").write_text(json.dumps(p["plan"],indent=2)+"\n")
(r/"build_mac.py").write_bytes(base64.b64decode(p["script"]))
for row in p["plan"]["inputs"]:
 q=Path(row["path"]);assert q.stat().st_size==row["bytes"]
 assert hashlib.sha256(q.read_bytes()).hexdigest()==row["sha256"],row["path"]
h={k:subprocess.check_output(v,text=True).strip()for k,v in{
 "model":["sysctl","-n","hw.model"],"cpu":["sysctl","-n","machdep.cpu.brand_string"],
 "memory":["sysctl","-n","hw.memsize"],"os":["sw_vers"],"compiler":["clang++","--version"],
 "space":["df","-h",str(r)]}.items()}
assert h["model"]=="Mac16,12"
(r/"hardware.json").write_text(json.dumps(h,indent=2)+"\n")
print(json.dumps(dict(remote=str(r),files=len(p["files"]),bytes=sum(x["bytes"]for x in p["files"]),
 retained_inputs=len(p["plan"]["inputs"]),compile_owners=len(p["plan"]["compile"]),hardware=h)))
'''
    encoded = base64.b64encode(code.encode()).decode()
    command = ["ssh", "-o", "BatchMode=yes", "kiro@172.22.10.198",
               'python3 -c "import base64;exec(base64.b64decode(\'' + encoded + '\'))"']
    save(O / "sync.command.json", command)
    result = subprocess.run(command, input=json.dumps(payload).encode(), capture_output=True)
    (O / "sync.stdout.log").write_bytes(result.stdout)
    (O / "sync.stderr.log").write_bytes(result.stderr)
    save(O / "sync.result.json", dict(exit=result.returncode))
    print(result.stdout.decode(), result.stderr.decode())
    raise SystemExit(result.returncode)


if __name__ == "__main__":
    main()
