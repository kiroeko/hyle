from pathlib import Path
import argparse
import copy
import difflib
import hashlib
import json
import xml.etree.ElementTree as ET

S=Path(__file__).resolve().parent
ROOT=S.parents[3]
TARGET=ROOT/'docs/implementation/model-quantizations.json'
EVIDENCE='docs/evidence/correctness/ct-packed-grouped-space-2026-10-21.json'
EXPECTED={22:'RedHatAI/Kimi-K3-INT4',24:'open-inference/Kimi-K3-W4A8-K512-GPTQ-Mixed-Cal72-Seq1024'}

def identity(path):
    raw=path.read_bytes()
    return dict(path=str(path),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())

def save(path,value):
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')

def encoded(value):
    return (json.dumps(value,ensure_ascii=False,indent=2)+'\n').replace('\n','\r\n').encode('utf-8')

def update(before,apple_final):
    after=copy.deepcopy(before)
    execution=dict(
        status='bounded_grouped_reference_verified_on_four_backends' if apple_final else 'draft_awaiting_Apple_final_Copy_validation',
        evidence=EVIDENCE,
        original_graph='ArtifactWeightDecode -> optional weight Cast -> exact reshape [E*N,K] to [E,N,K] -> optional weight Cast -> GroupedMatMul; only one weight Cast in total; dense entry points below remain available.',
        ports='Original flat Q I32[E*N,K/8], optional asymmetric Z I32[ceil(E*N/8),K/group_size], SF floating[E*N,K/group_size], plain F32 A[T,1 or S,K] and I32 IDs[T,S]; F32 Y[T,S,N]. Symmetric codes are offset-binary nibble minus8. Asymmetric zero nibbles use the global flattened output-row axis, including odd N.',
        arithmetic='Centered code times scale rounds to the original scale dtype, then the requested decode dtype, then the actual F32/BF16 grouped operand dtype; F32 activation and F32 accumulation/output. No activation QDQ or A8 contract is inferred.',
        layout_and_failure='Shared A1 and AS, real zero-slot stride, token padding and nonunit K stride; repeated expert IDs are preserved. Every current ID is checked before any selected weight/zero/scale addressing; all source banks and IDs are reread on submit.',
        storage='Bounded packed computation retains original packed banks; no full E*N*K floating-point decode or workspace in the contracted recipe. Original independently addressable expert banks and arbitrarily large native buffers still require the delivery3 resource bridge.',
        selection='Exact closed grouped recipes prefer the packed space contract. CPU ordinary default compile selects the packed grouped recipe without RequirePrepared; dense rank/default policies remain as documented by their earlier evidence. No grouped throughput advantage or general crossover is claimed.',
        finite_profiles=[
            'symmetric group32: BF16 scale -> F16 decode -> F32 operand; shared A1',
            'asymmetric group128: F16 scale -> BF16 decode -> BF16 operand; AS and Cast after reshape',
            'asymmetric group512: BF16 scale -> F32 decode -> BF16 operand; E17, odd N, real zero-slot/token padding/K stride',
            'symmetric group128: BF16 scale -> F32 decode -> F32 operand; shared A1 and no Cast',
            'symmetric group512: F32 scale -> BF16 decode -> BF16 operand; AS and no Cast',
        ],
        package_tests=dict(WindowsCPU=14,WindowsCUDA=11,WindowsVulkan=11,
            macOSAppleM4=11 if apple_final else None,total=47 if apple_final else None,skipped=0,
            Apple_status='verified' if apple_final else 'pending_final_strided_import_and_Copy_snapshot_validation'),
        counting='Distinct focused cases across relevant frozen windows include new grouped consumers and retained dense CT/GPTQ/storage-loader neighbors; counts are not artifact executions or all neighbors rerun on one final image. CPU final default new3 reuse prior11 neighbors. Apple final new4 include metadata/Copy, the affected CT escape reran on that image, and other6 neighbors carry the earlier green window.',
        new_grouped_submissions_per_backend=dict(lifetime_success=20,runtime_success=3,expected_failed_Completions=2,original_escape_success=1),
        CUDA_capture='Packed life/domain use RequireCapture and assert kCaptured; the published-decode escape executes the original decomposition without requiring capture.',
        resource_scope='Original Program/Invocation/queue ownership, dynamic source updates, independent slots, retained old results and published-decoder escape. Apple actual read-only strided borrow, packed sorted flags and independent dense Copy snapshots are covered by the final metadata/Copy counterexample and affected escape rerun. No new executor or runtime model/provider whitelist.',
        not_verified=[
            'Exact publisher numeric payload, tensor headers and per-role importer/binding',
            'Whole artifact/model execution, model quality or throughput',
            'Linux execution of this grouped package',
            'Independent expert-span catalog/WeightSlots working-set bridge, native maximum-buffer constraints and global-to-local expert ID mapping (delivery3)',
            'An activation-A8 quantizer or a GPTQ codec inferred from an artifact repository name',
        ])
    entry=dict(
        provider='CPU/CUDA/Apple/Vulkan Graph grouped CT packed software recipe',
        operation='Original flat CT ArtifactWeightDecode[/Cast] -> exact expert reshape[/Cast] -> GroupedMatMul',
        execution='Common cold closed-reader/control proof and original backend Program/Invocation; bounded packed banks, original source/decode/operand RNE and F32 A/Y.',
        exact_requirements='Flat Q[EN,K/8], optional global-axis Z[ceil(EN/8),G], SF[EN,G], complete groups and exact reshape; selected IDs validated first. Independent per-expert Z packs cannot be naively concatenated when N is not a multiple of8.',
        qualification='Five finite synthetic profiles include symmetric group128 and symmetric group512 with F32 scales; publisher binding, working-set bridge and performance remain separate.',
        evidence=EVIDENCE,
        status='four_backend_bounded_reference_verified' if apple_final else 'draft_Apple_final_validation_pending')
    for i,repo in EXPECTED.items():
        assert after['artifacts'][i]['repository']==repo
        coverage=after['artifacts'][i]['provider_coverage']
        coverage['review']='static_artifact_contract_and_bounded_grouped_CT_reference'
        coverage['review_scope']='Preserve exact-revision metadata and previous dense references; add bounded flat-bank CT grouped software operation coverage with five finite group32/128/512 profiles. No publisher tensor-header/import binding, whole artifact execution, Linux or performance acceptance.'
        coverage['reachable_entry_points'].append(copy.deepcopy(entry))
        coverage['grouped_packed_reference_execution']=copy.deepcopy(execution)
        coverage['fusion_coverage'] += ' The subsequent grouped package extends the same cold proof to exact expert reshapes and bounded grouped execution with five finite profiles, including symmetric group128/group512; source/decode/operand RNE and F32 A/Y remain explicit. Its grouped default is a space contract, not measured throughput.'

    c=after['artifacts'][22]['provider_coverage']
    c['mapping_status']='The generic flat-bank symmetric group128 grouped recipe has bounded synthetic coverage; the exact Kimi publisher tensor headers, scale dtype, packed word order and role/import binding remain unknown. Prior dense decode/linear entry points are retained.'
    c['missing_capabilities']=[
        'Exact publisher tensor headers, packed code-word order, scale dtype/shape and per-role importer/binding; synthetic symmetric group128 BF16-scale coverage does not establish those artifact facts',
        'Delivery3: independently addressable expert banks/catalog WeightSlots, bounded working sets and global-to-local expert ID mapping; independent Z packs cannot be concatenated without preserving their actual output-row packing',
        'Whole artifact/model execution, Linux grouped-package execution, quality and throughput acceptance',
    ]
    c=after['artifacts'][24]['provider_coverage']
    c['mapping_status']='The generic flat-bank symmetric group512 grouped recipe has bounded synthetic F32-scale coverage matching the saved scale-dtype field. Actual publisher headers/role import and the independent custom-A8 runtime contract remain unverified; prior dense entry points are retained.'
    c['missing_capabilities']=[
        'Exact publisher tensor headers/word axes and role/import binding; synthetic symmetric group512 F32-scale execution is not publisher payload execution',
        'A separately specified A8 runtime quantizer/scales/rounding if the advertised custom runtime requires one; saved input_activations=null does not define it',
        'Delivery3: independently addressable expert-bank/catalog WeightSlots working sets and global-to-local expert ID mapping, preserving each real zero-pack output-row origin',
        'Whole artifact/model execution, Linux grouped-package execution, quality and throughput acceptance',
    ]
    return after

def validate(before,after):
    changed=[i for i,(a,b) in enumerate(zip(before['artifacts'],after['artifacts'])) if a!=b]
    assert changed==[22,24] and len(after['artifacts'])==33
    assert all(a['provider_coverage']['artifact_execution_verified'] is False for a in after['artifacts'])
    for k in before.keys()-{'artifacts'}: assert before[k]==after[k]
    for i in EXPECTED:
        a,b=before['artifacts'][i],after['artifacts'][i]
        assert {k:v for k,v in a.items() if k!='provider_coverage'}=={k:v for k,v in b.items() if k!='provider_coverage'}
        old,new=a['provider_coverage'],b['provider_coverage']
        assert new['reachable_entry_points'][:-1]==old['reachable_entry_points']
        assert old['artifact_execution_verified']==new['artifact_execution_verified']
        for k in ('metadata_sources','required_format_domain','role_domains','artifact_unaligned_or_unverified',
                  'cpu_packed_graph_evidence','cpu_packed_portability_evidence','cpu_packed_default_policy',
                  'native_packed_graph_evidence','optional_performance','code'):
            assert old.get(k)==new.get(k),(i,k)
    return changed

def main():
    p=argparse.ArgumentParser()
    p.add_argument('--apply',action='store_true')
    p.add_argument('--apple-xml',type=Path)
    args=p.parse_args()
    before_path=S/'before/model-quantizations.json'
    if not before_path.exists():
        before_path.parent.mkdir(parents=True,exist_ok=True)
        before_path.write_bytes(TARGET.read_bytes())
    before_raw=before_path.read_bytes();before=json.loads(before_raw)
    assert TARGET.read_bytes()==before_raw,'Canonical catalog changed; do not overwrite concurrent work'
    if args.apply:
        assert args.apple_xml and args.apple_xml.is_file(),'Require final Apple XML after root all-green instruction'
        cases=ET.parse(args.apple_xml).findall('.//testcase')
        assert len(cases)==4 and all(x.find('failure') is None and x.find('skipped') is None for x in cases)
        life=next(x for x in cases if x.get('name')=='FlatBanksKeepTypedRoundsRealStridesAndOwnedSlots')
        props={x.get('name'):x.get('value') for x in life.findall('./properties/property')}
        assert props.get('actual_submissions')=='20','Final Apple must execute the five-profile fixture'
        old_xml=S.parent/'apple/first-complete-pass/remote/results/tests.xml'
        old_cases=ET.parse(old_xml).findall('.//testcase')
        assert len(old_cases)==10 and all(x.find('failure') is None and x.find('skipped') is None for x in old_cases)
        names={x.get('classname')+'.'+x.get('name') for x in cases+old_cases}
        assert len(names)==11
        receipt=json.loads((S.parent/'apple/final-validation.json').read_bytes())
        assert receipt['status']=='PASS' and receipt['validation']['tests']==4
        assert receipt['copy_neighbor']['exit']==0 and len(receipt['copy_neighbor']['tests'])==1
        assert receipt['previous_neighbor_suite']['ct_dense_tests']==4 and receipt['previous_neighbor_suite']['gptq_tests']==3
    after=update(before,args.apply);changed=validate(before,after)
    after_path=S/('after/model-quantizations.json' if args.apply else 'candidate/model-quantizations.json')
    after_path.parent.mkdir(parents=True,exist_ok=True);after_path.write_bytes(encoded(after))
    diff=''.join(difflib.unified_diff(before_raw.decode().splitlines(keepends=True),
        after_path.read_bytes().decode().splitlines(keepends=True),fromfile='before/model-quantizations.json',
        tofile=('after/' if args.apply else 'candidate/')+'model-quantizations.json',n=3))
    diffpath=S/('model-quantizations.diff' if args.apply else 'candidate.diff')
    diffpath.write_text(diff,encoding='utf-8',newline='')
    validation=dict(status='applied_after_final_Apple11' if args.apply else 'draft_only_canonical_unchanged_Apple_pending',
        changed_zero_based_rows=changed,only_provider_coverage_changed=True,
        other31_artifacts_root_metadata_required_domains_historical_sources_dense_entry_points_unchanged=True,
        artifact_execution_verified_false_count=33,evidence=EVIDENCE,
        builds_tests_GPU_runs_by_this_catalog_task=0,before=identity(before_path),after=identity(after_path),diff=identity(diffpath),
        canonical_before_apply=identity(TARGET),Apple_XML=identity(args.apple_xml) if args.apply else None,
        Apple_windows='Final4 plus earlier7 neighbors; affected CT escape rerun, other6 retained. Eleven distinct cases, not11 on one final image.' if args.apply else None)
    if args.apply:
        assert TARGET.read_bytes()==before_raw
        TARGET.write_bytes(after_path.read_bytes())
    save(S/('validation.json' if args.apply else 'candidate-validation.json'),validation)
    print(json.dumps(validation,ensure_ascii=False,indent=2))

if __name__=='__main__': main()
