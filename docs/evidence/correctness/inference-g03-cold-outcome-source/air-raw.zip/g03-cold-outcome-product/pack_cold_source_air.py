from pathlib import Path
import json, zipfile
base = Path('/Users/kiro/hyle-scratch/compute-unified')
out = base / 'g03-cold-outcome-product'
folders = ['g03-cold-outcome-product', 'g03-cold-outcome-host', 'g03-cold-outcome-sdk']
with zipfile.ZipFile(out / 'complete-raw.zip', 'w', zipfile.ZIP_DEFLATED) as archive:
    for name in folders:
        folder = base / name
        job = json.loads((folder / 'job.json').read_bytes())
        assert job['state'] == 'TERMINAL' and job['exit_code'] == 0
        for path in folder.iterdir():
            if path.is_file() and path.suffix in ['.json', '.log', '.py', '.zip'] and path.name != 'complete-raw.zip':
                archive.write(path, name + '/' + path.name)
    for route in ['apple', 'vulkan']:
        path = out / f'{route}-build/compile_commands.json'
        archive.write(path, 'g03-cold-outcome-product/' + route + '-compiled-inputs.json')
        for mode in ['static', 'shared']:
            folder = base / 'g03-cold-outcome-sdk' / f'{route}-{mode}'
            for name in ['inputs.json', 'public-compile-commands.json']:
                archive.write(folder / name, 'g03-cold-outcome-sdk/' + f'{route}-{mode}/' + name)
print('sealed actual source/host/sdk terminal receipts')
