from pathlib import Path
import hashlib, json, os, subprocess, time
base = Path('/Users/kiro/hyle-scratch/compute-unified')
canonical = base / 'source-c8874688'
out = base / 'g03-cold-outcome-sdk'
out.mkdir(exist_ok=True)
env = os.environ.copy()
env['PATH'] = '/Users/kiro/hyle-verify-tools/metal-17F109/shim:/opt/homebrew/bin:' + env['PATH']
record = out / 'result.json'
rows = json.loads(record.read_bytes()).get('stages', []) if record.exists() else []
def run(route, mode, stage, args):
    attempt = 1 + sum(row['route'] == route and row['mode'] == mode and row['stage'] == stage for row in rows)
    log = out / f'{route}-{mode}-{stage}-{attempt}.log'
    start = time.monotonic()
    with log.open('w') as stream:
        process = subprocess.Popen(args, env=env, stdout=stream, stderr=subprocess.STDOUT)
        (out / 'job.json').write_text(json.dumps({'state': 'RUNNING', 'pid': process.pid, 'route': route, 'mode': mode, 'log': str(log)}))
        print('RUN', route, mode, stage, process.pid, flush=True)
        code = process.wait()
    rows.append({'route': route, 'mode': mode, 'stage': stage, 'command': args, 'exit_code': code, 'elapsed_seconds': time.monotonic() - start, 'log': str(log)})
    record.write_text(json.dumps({'scope': 'installed/relocated original compute result and cold source/observer, actual CPU/F2/suffix 64 replays and original invocation recovery; no repository include paths, static and shared, no native private qualifier export claim', 'stages': rows, 'cumulative_seconds': sum(row['elapsed_seconds'] for row in rows)}, indent=2) + '\n')
    print(json.dumps(rows[-1]), flush=True)
    if code:
        print(log.read_text(errors='replace')[-5500:], flush=True)
        (out / 'job.json').write_text(json.dumps({'state': 'TERMINAL', 'exit_code': code}))
        raise SystemExit(code)
for route in ['apple', 'vulkan']:
    for mode in ['static', 'shared']:
        producer = base / f'a-cpu-{route}/selected-graph/{mode}-sdk-build'
        folder = out / f'{route}-{mode}'
        folder.mkdir(exist_ok=True)
        stage = folder / 'staging'
        prefix = folder / 'relocated'
        if not prefix.exists():
            run(route, mode, 'producer-build', ['/opt/homebrew/bin/cmake', '--build', str(producer), '--target', 'hyle_compute', f'hyle_compute_route_{route}', '--parallel', '4'])
            run(route, mode, 'install', ['/opt/homebrew/bin/cmake', '--install', str(producer), '--prefix', str(stage)])
            stage.rename(prefix)
        assert not stage.exists()
        source = folder / 'consumer'
        source.mkdir(exist_ok=True)
        data = (canonical / 'tests/compute/owned_outcome_sdk_consumer.cc').read_bytes()
        (source / 'main.cc').write_bytes(data)
        headers = ['detail/dependent_completion.h', 'detail/generated_result.h', 'detail/copy_stream_access.h', 'result.h', 'detail/copy_outcome_source.h']
        identities = []
        for index, name in enumerate(headers):
            assert (prefix / 'include/hyle/compute' / name).read_bytes() == (canonical / 'include/hyle/compute' / name).read_bytes()
            (source / f'header-{index}.cc').write_text(f'#include <hyle/compute/{name}>\n')
            identities.append({'path': name, 'sha256': hashlib.sha256((prefix / 'include/hyle/compute' / name).read_bytes()).hexdigest()})
        (folder / 'inputs.json').write_text(json.dumps({'consumer_sha256': hashlib.sha256(data).hexdigest(), 'headers': identities}, indent=2) + '\n')
        body = '''cmake_minimum_required(VERSION 3.25)
project(g03_owned_outcome_sdk LANGUAGES CXX)
find_package(Hyle CONFIG REQUIRED COMPONENTS compute)
add_executable(outcome main.cc)
add_library(headers OBJECT header-0.cc header-1.cc header-2.cc header-3.cc header-4.cc)
foreach(target outcome headers)
 target_compile_features(${target} PRIVATE cxx_std_23)
 target_compile_options(${target} PRIVATE -Wall -Wextra -Wpedantic -Werror)
 target_link_libraries(${target} PRIVATE hyle::compute)
endforeach()
hyle_stage_runtime(outcome)
'''
        (source / 'CMakeLists.txt').write_text(body)
        build = folder / 'build'
        run(route, mode, 'configure', ['/opt/homebrew/bin/cmake', '-S', str(source), '-B', str(build), '-G', 'Ninja', '-DCMAKE_BUILD_TYPE=Release', '-DCMAKE_PREFIX_PATH=' + str(prefix), '-DCMAKE_EXPORT_COMPILE_COMMANDS=ON'])
        run(route, mode, 'build', ['/opt/homebrew/bin/cmake', '--build', str(build), '--target', 'outcome', 'headers', '--parallel', '4'])
        commands = json.loads((build / 'compile_commands.json').read_bytes())
        for item in commands:
            assert str(canonical) not in item['command'] and str(prefix / 'include') in item['command']
        (folder / 'public-compile-commands.json').write_text(json.dumps(commands, indent=2) + '\n')
        run(route, mode, 'outcome', [str(build / 'outcome')])
(out / 'job.json').write_text(json.dumps({'state': 'TERMINAL', 'exit_code': 0}))
