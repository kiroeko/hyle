from pathlib import Path
import hashlib, json, os, subprocess, sys, time, zipfile

base = Path('/Users/kiro/hyle-scratch/compute-unified')
canonical = base / 'source-c8874688'
out = base / 'g03-cold-outcome-product'
out.mkdir(exist_ok=True)
identity = {n: subprocess.check_output(a, text=True).strip() for n, a in [
    ('model', ['/usr/sbin/sysctl', '-n', 'hw.model']), ('arch', ['uname', '-m']),
    ('os', ['sw_vers']), ('compiler', ['xcrun', 'clang', '--version'])]}
assert identity['model'] == 'Mac16,12' and identity['arch'] == 'arm64'
with zipfile.ZipFile(out / sys.argv[1]) as archive:
    inputs = json.loads(archive.read('input-manifest.json'))
    for row in inputs:
        relative = Path(row['path'])
        assert not relative.is_absolute() and '..' not in relative.parts
        data = archive.read(row['path'])
        assert hashlib.sha256(data).hexdigest() == row['sha256']
        destination = canonical / relative
        destination.parent.mkdir(parents=True, exist_ok=True)
        if not destination.exists() or destination.read_bytes() != data:
            destination.write_bytes(data)
env = os.environ.copy()
env['PATH'] = '/Users/kiro/hyle-verify-tools/metal-17F109/shim:/opt/homebrew/bin:' + env['PATH']
record = out / 'result.json'
rows = json.loads(record.read_bytes()).get('stages', []) if record.exists() else []
def run(route, stage, args):
    number = 1 + sum(row['stage'] == stage and row['route'] == route for row in rows)
    log = out / f'{route}-{stage}-{number}.log'
    start = time.monotonic()
    with log.open('w') as stream:
        p = subprocess.Popen(args, env=env, stdout=stream, stderr=subprocess.STDOUT)
        (out / 'job.json').write_text(json.dumps({'state': 'RUNNING', 'pid': p.pid, 'route': route, 'stage': stage, 'log': str(log)}))
        print('RUN', route, stage, p.pid, flush=True)
        try:
            code = p.wait(timeout=1800)
        except subprocess.TimeoutExpired:
            rows.append({'route': route, 'stage': stage, 'command': args, 'exit_code': 'TIMEOUT', 'elapsed_seconds': 1800, 'log': str(log)})
            record.write_text(json.dumps({'identity': identity, 'inputs': inputs, 'stages': rows}, indent=2))
            print('TIMEOUT retained; same process receives authorized one 1800s extension', flush=True)
            code = p.wait(timeout=1800)
    rows.append({'route': route, 'stage': stage, 'command': args, 'exit_code': code, 'elapsed_seconds': time.monotonic() - start, 'log': str(log)})
    record.write_text(json.dumps({'scope': 'AUDITED OO03 cold production source owner, before suffix admission, four allocations/actual retirement; not final Graph/pending/7routes', 'identity': identity, 'inputs': inputs, 'stages': rows, 'cumulative_seconds': sum(row['elapsed_seconds'] for row in rows)}, indent=2) + '\n')
    print(json.dumps(rows[-1]), flush=True)
    if code:
        print(log.read_text(errors='replace')[-5000:], flush=True)
        (out / 'job.json').write_text(json.dumps({'state': 'TERMINAL', 'exit_code': code}))
        raise SystemExit(code)
for route in ['apple', 'vulkan']:
    producer = base / f'a-cpu-{route}/selected-graph/static-sdk-build'
    run(route, 'producer-build', ['/opt/homebrew/bin/cmake', '--build', str(producer), '--target', 'hyle_compute', f'hyle_compute_route_{route}', '--parallel', '4'])
    prefix = out / f'{route}-prefix'
    run(route, 'install', ['/opt/homebrew/bin/cmake', '--install', str(producer), '--prefix', str(prefix)])
    for name in ['include/hyle/compute/detail/dependent_completion.h', 'include/hyle/compute/detail/generated_result.h', 'include/hyle/compute/detail/copy_stream_access.h', 'include/hyle/compute/result.h', 'include/hyle/compute/detail/copy_outcome_source.h']:
        assert (prefix / name).read_bytes() == (canonical / name).read_bytes()
    parent = out / f'{route}-parent'
    parent.mkdir(exist_ok=True)
    build = out / f'{route}-build'
    body = '''cmake_minimum_required(VERSION 3.25)
project(g03_owned_outcome LANGUAGES CXX)
find_package(Hyle CONFIG REQUIRED COMPONENTS compute)
set(INSTALL_GTEST OFF CACHE BOOL "" FORCE)
add_subdirectory(/Users/kiro/Library/Caches/hyle/dependencies/v1/sources/googletest-063de7e9578f-162765170ae6 gtest EXCLUDE_FROM_ALL)
'''
    targets = [('native', f'tests/compute_batch/pending_outcome_owner_{route}_probe.cc', 'hyle::compute'),
               ('completion', 'tests/compute/completion_test.cc', 'hyle::compute GTest::gtest_main'),
               ('copy_cpu', 'tests/compute_backend_cpu/copy_program_test.cc', 'hyle::compute GTest::gtest_main'), ('native_cpu', 'tests/compute_batch/owned_outcome_cpu_consumer.cc', 'hyle::compute')]
    for target, name, links in targets:
        body += f'add_executable({target} "{canonical / name}")\ntarget_compile_features({target} PRIVATE cxx_std_23)\ntarget_compile_options({target} PRIVATE -Wall -Wextra -Wpedantic -Werror)\ntarget_link_libraries({target} PRIVATE {links})\nhyle_stage_runtime({target})\n'
        if route == 'vulkan':
            body += f'target_include_directories({target} SYSTEM PRIVATE /opt/homebrew/include)\n'
    body += f'target_include_directories(completion PRIVATE "{canonical / "src/compute"}")\n'
    (parent / 'CMakeLists.txt').write_text(body)
    run(route, 'configure', ['/opt/homebrew/bin/cmake', '-S', str(parent), '-B', str(build), '-G', 'Ninja', '-DCMAKE_BUILD_TYPE=Release', '-DCMAKE_PREFIX_PATH=' + str(prefix), '-DCMAKE_EXPORT_COMPILE_COMMANDS=ON'])
    run(route, 'build', ['/opt/homebrew/bin/cmake', '--build', str(build), '--target'] + [target for target, _, _ in targets] + ['--parallel', '4'])
    for target, _, _ in targets:
        run(route, target, [str(build / target)])
(out / 'job.json').write_text(json.dumps({'state': 'TERMINAL', 'exit_code': 0}))
