from pathlib import Path
import hashlib,json,subprocess,xml.etree.ElementTree as E,zipfile
root=Path.cwd();base=root/'.scratch/inference-gaps/g06';windows=base/'common-source-9';air=base/'cpu-ragged-air-1'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
w=json.loads((windows/'result.json').read_bytes());a=json.loads((air/'result.json').read_bytes())
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
assert not subprocess.check_output(['git','status','--porcelain'],text=True)
assert w['candidate']==a['candidate']==head and w['state']==a['state']=='TERMINAL_PASS'
assert all(x['exit_code']==0 for r in [w,a] for x in r['stages'])
tests=[]
for target,count in [('hyle_compute_provider_ggml_test',62),('g04_g05_encoded_common_pages',26)]:
 p=windows/(target+'.xml');x=E.parse(p).getroot()
 assert int(x.get('tests'))==count and all(int(x.get(k,'0'))==0 for k in ['failures','errors','disabled']) and not x.findall('.//skipped')
 tests.append(dict(target=target,tests=count,failures=0,skipped=0,testcases=[t.get('classname')+'.'+t.get('name') for t in x.findall('.//testcase')]))
assert any('RuntimeQ1KeepsGraphAcrossPackedKvExtents' in name for t in tests for name in t['testcases'])
for target in ['g04_plain_pending_control','g04_encoded_pending_risks']:assert (windows/(target+'.log')).read_text().count('PASS')==9
for route in ['apple','vulkan']:
 text=(air/(route+'-g06_cpu_q1.log')).read_text()
 assert '[  PASSED  ] 26 tests.' in text and '[  FAILED  ]' not in text and '[  SKIPPED ]' not in text
 assert '[       OK ] GgmlCpuRagged.RuntimeQ1KeepsGraphAcrossPackedKvExtents' in text
manifest=json.loads((air/'input-manifest.json').read_bytes());assert manifest['candidate']==head
for item in manifest['inputs']:assert sha(root/item['path'])==item['sha256'],item['path']
inputs=[dict(path=s,sha256=sha(root/s)) for s in subprocess.check_output(['git','diff','--name-only','518be7fb0',head],text=True).splitlines() if (root/s).is_file()]
artifacts=[]
for name in ['hyle_compute_provider_ggml.dll',*[t+'.exe' for t in w['targets']]]:
 p=Path(w['build'])/'bin'/name;assert p.is_file();artifacts.append(dict(path=str(p),sha256=sha(p),bytes=p.stat().st_size))
dest=root/'evidence/correctness/inference-g06-cpu-ragged-runtime-source';dest.mkdir(parents=True,exist_ok=False)
with zipfile.ZipFile(dest/'raw.zip','w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for folder in [windows,air]:
  for p in sorted(folder.iterdir()):
   if p.is_file():z.write(p,folder.name+'/'+p.name)
 for name in ['run_cpu_q1_source.py','cpu_ragged_air.py','launch_cpu_ragged_air.py','seal_cpu_ragged_source.py','seal_cpu_ragged_source-first-failed.py','cpu-ragged-sealer-failure.json']:z.write(base/name,'helpers/'+name)
 for item in inputs:z.write(root/item['path'],'source/'+item['path'])
r=dict(kind='G06_D4_ORIGINAL_CPU_RAGGED_Q1_RUNTIME_SOURCE',verdict='PASS_WINDOWS_CPU_AND_AIR_MIXED_CORE_SOURCE',candidate=head,
 windows=dict(execution=w,tests=tests,total_tests=88,pending_risk_scenarios=18,artifacts=artifacts),
 air=dict(execution=a,tests_by_build={'cpu_apple':26,'cpu_vulkan':26},artifacts=json.loads((air/'artifacts-after-run.json').read_bytes())),
 source_inputs=inputs,input_manifest_sha256=sha(air/'input-manifest.json'),raw_zip_sha256=sha(dest/'raw.zip'),

 proven=['32 configurations each64 Q1 ragged episodes cover F16/BF16, plain/Q8, single/multi, D64/128/256 and D64/Dv128/window/noncausal. Packed KV grows/shrinks and request start offsets move across the original512 split boundary; request join/end and empty middle change Q topology and cold replan.',
 'Same Q topology preserves original native graph/pool/scratch. Next injected allocation is prohibited during update and workspace stays constant. Per-request actual KV root/permute extents, n_kv_max, input TensorDesc/byte extents and packed offsets update after complete preflight; original checked storage subviews/map/rebinding retain truthful ranges.',
 'Independent uniform-attention oracle consumes nonconstant physical V; unused final KV row has NaN payload/scale. Original old-output exclusion remains and an independent slot retains its first numeric output through all64 updates.',
 'Original masks/kernels/format dispatch remain. Private ragged Q1 zero causal mask was already omitted by lower; its cold lower-bound budget is now consistent. Non-Q1/prefill keeps original cold preparation.',
 'Windows ordinary Provider62 and native/common/Graph26 plus original plain/encoded nine-scenario pending risks pass. Both actual Air mixed library configurations run the same26 CPU tests including the new runtime ragged test, old paged/runtime tests and cold OOM/budget/accepted-failure consumers.'],
 limits=['This is finite CPU ragged Q1 correctness/P0 source evidence, not new P1, native GPU/capture qualification or full G06 acceptance.',
 'No-injected-allocation covers prepared update after caller-created version. Snapshot allocation, native private overhead and unobserved packaging/launch costs retain their original limits/UNKNOWN; stage times overlap outer.',
 'Non-Q1 ragged remains original cold path. Apple/Vulkan ragged runtime, FI Q1/capture and final sanitizer/header/relocated static/shared remain mandatory; G04/G05 CUDA prefill and original failures/UNKNOWN remain.',
 'The reused Windows helper retains its inherited D2 scope label. Actual candidate, commands, source and mandatory named new ragged test are asserted here; no D2 page test is substituted for D4 ragged proof.',
 'Initial proof-packer class-name assertion failed before canonical publication; original failed helper and reason retained. Corrected proof packer ran against the same existing passed logs with no product rerun. Its unmeasured cost is UNKNOWN.',
 'No native math/vendor/runtime/public API/CMake change, global build, CUDA/P1/profile/model/server. Air evidence is CPU work inside mixed builds, not GPU math. No product failures/retries in this D4 batch.'])

(dest/'receipt.json').write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(verdict=r['verdict'],windows_tests=88,pending_scenarios=18,air_tests_by_build=r['air']['tests_by_build'],receipt=str(dest/'receipt.json'))))
