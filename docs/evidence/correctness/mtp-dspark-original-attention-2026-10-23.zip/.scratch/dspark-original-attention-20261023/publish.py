"""Publish actual original DSpark attention/state checks without weight bodies."""
from pathlib import Path
import hashlib
import json
import re
import xml.etree.ElementTree as ET
import zipfile

S = Path(__file__).resolve().parent
R = S.parents[1]
D = R / 'docs/evidence/correctness'


def read(p):
    return json.loads(Path(p).read_text(encoding='utf-8-sig'))


def identity(p):
    p = Path(p)
    return dict(path=str(p.relative_to(R)), bytes=p.stat().st_size,
                sha256=hashlib.sha256(p.read_bytes()).hexdigest())


runs = [read(S / f'checks{i}/summary.json') for i in (1, 2)]
cases = []
for i, run in enumerate(runs, 1):
    assert run['process']['exit'] == 0 and not run['process']['timed_out']
    assert run['tests'] == 2
    assert not any(run[k] for k in ('failures', 'errors', 'disabled', 'skips'))
    tree = ET.parse(S / f'checks{i}/results.xml').getroot()
    assert int(tree.attrib['tests']) == 2
    for case in tree.iter('testcase'):
        assert case.attrib['result'] == 'completed'
        assert case.find('failure') is None and case.find('skipped') is None
    cases.extend(run['cases'])
assert len(cases) == len({(c['attributes']['classname'], c['attributes']['name']) for c in cases}) == 4
assert all(c['properties']['actual_submissions'] == '25' for c in cases)
for case in runs[0]['cases']:
    p = case['properties']
    assert p['original_role_count'] == '68' and p['original_role_bytes'] == '2734976924'
    providers = {k: v for k, v in p.items() if k.endswith('_provider')}
    assert len(providers) == 28
    if case['attributes']['name'].startswith('Cpu'):
        assert set(providers.values()) == {'ggml-cpu'}
    else:
        assert sum(v == 'cublasLt' for v in providers.values()) == 7
        assert sum(v == 'ggml-cuda' for v in providers.values()) == 21
for case in runs[1]['cases']:
    assert case['properties']['original_role_count'] == '56'

freezes = [S / p / 'freeze.json' for p in ('source', 'hooks-source', 'reference-source')]
for p in freezes:
    freeze = read(p)
    for row in freeze['files'] if 'files' in freeze else [freeze['file']]:
        actual = identity(R / row['path'])
        assert actual['bytes'] == row['bytes'] and actual['sha256'] == row['sha256']
compiled = read(S / 'compile1/dspark-state/identity.json')
for row in (compiled['source'], compiled['object'], *compiled['dependencies']):
    p = Path(row['path'])
    assert p.stat().st_size == row['bytes']
    assert hashlib.sha256(p.read_bytes()).hexdigest() == row['sha256']
image = read(S / 'tests-link1/ready.json')['image']
assert identity(Path(image['path']))['sha256'] == image['sha256']
payloads = read(S / 'original-attention/acquisition.json')
assert payloads['complete'] and len(payloads['roles']) == 12
assert payloads['role_payload_bytes'] == payloads['successful_request_body_bytes'] == 334233600
assert len(payloads['requests']) == 3
for row in payloads['roles']:
    assert identity(R / row['payload']['path']) == row['payload']
tail = (R / 'docs/developer/current-work.md').read_text(encoding='utf-8')
tail = tail[tail.index('## 最新完整性能对比'):]
tail_hash = hashlib.sha256(tail.encode()).hexdigest()
assert tail_hash == read(S / 'start.json')['performance_tail_utf8_sha256']

pattern = re.compile(r'^shared-Q8-local role=(\S+) codec=(\d+) outputs=(\d+) '
    r'max_error=(\S+) max_ratio=(\S+) max_quantization_ambiguity=(\S+) '
    r'ambiguous_codes=(\d+) ambiguous_scales=(\d+)$')
numerics = []
for line in (S / 'checks1/stderr.log').read_text(encoding='utf-8').splitlines():
    match = pattern.match(line)
    if match:
        role, codec, count, error, ratio, ambiguity, codes, scales = match.groups()
        numerics.append(dict(role=role, codec=int(codec), values=int(count),
            maximum_absolute_error=float(error), maximum_bound_ratio=float(ratio),
            maximum_quantization_ambiguity=float(ambiguity),
            ambiguous_activation_codes=int(codes), ambiguous_activation_scales=int(scales)))
assert numerics and {r['codec'] for r in numerics} == {0, 2}
for codec in (0, 2):
    assert sum(r['values'] for r in numerics if r['codec'] == codec and '.attn_' in r['role']) == 691200
    assert sum(r['values'] for r in numerics if r['codec'] == codec and '.ffn_' in r['role']) == 122880
assert all(r['maximum_bound_ratio'] <= 1 for r in numerics)
(S / 'numerical-observations.json').write_text(json.dumps(numerics, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')

sources = [R / p for p in (
    'tests/compute_models/d5_deepseek_official_fragments.h',
    'tests/compute_models/d5_deepseek_official_attention.h',
    'tests/compute_models/cpu_c4_model_branches.h',
    'tests/compute_models/dspark_complete_graph_fixture.h',
    'tests/compute_models/dspark_original_attention_roles.h',
    'tests/compute_models/dspark_original_attention_reference.h',
    'tests/compute_models/dspark_original_shared_reference.h',
    'tests/compute_models/dspark_original_state_consumer.h',
    'tests/compute_models/dspark_original_state_consumer_test.cc',
    'docs/developer/current-work.md', 'docs/implementation/model-operators.md')]
metadata = [R / p for p in (
    '.scratch/dspark-original-hc-20261023/review/remaining-original-roles.json',
    '.scratch/dspark-original-shared-20261023/reference-source/source-notes.json',
    '.scratch/dspark-original-shared-20261023/review/cpu-q8-quantizer.json',
    '.scratch/dspark-original-shared-20261023/review/cpu-q8-quantizer.disasm.txt',
    '.scratch/model-scope-2026-10-19/flash-0731/inference-model.py')]
assert all(p.is_file() for p in sources + metadata)
paths = set(sources + metadata)
paths.update(p for p in S.rglob('*') if p.is_file() and p.suffix.lower() in (
    '.h', '.cc', '.py', '.json', '.txt', '.diff', '.log', '.xml', '.ps1'))
paths.discard(S / 'publication.json')
archive = D / 'mtp-dspark-original-attention-2026-10-23.zip'
assert not archive.exists()
with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=7) as z:
    for p in sorted(paths):
        z.write(p, p.relative_to(R).as_posix())

record = dict(date='2026-10-23', stage='BL', goal_complete=False,
    conclusion='All12 original attention Q8_0 banks now run in the existing complete three-stage DSpark accepted-state journey with the previous56 original roles on CPU and CUDA; output-A preserves its original eight-group structure.',
    artifact=dict(original_roles=68, original_payload_bytes=2734976924,
        sidecar_original_roles=66, sidecar_total_roles=81, additional_formal_BF16_vocabulary_roles=2,
        acquisition=payloads, original_payloads_archived=False,
        byte_scope='Original checkpoint payload extents, not physical memory or VRAM peaks.'),
    implementation=dict(
        assembly='One common packed-projection carrier supports independent typed attention and shared-FFN suppliers. Four parent-owned banks per stage map through typed child inputs; no provider dispatch or host computation substitutes a Graph node.',
        layout='Q-A:K4096/N1024; Q-B:K1024/N32768; output-A:original contiguous Q8 rows describe grouped[8,1024,4096], with actual[5,8,4096] input and[5,8] group IDs; output-B:K8192/N4096. Output-A is not a global8192-output dense projection.',
        lifetime='Twelve encoded banks upload once and remain readonly under existing owner/lease. Actual immutable source remains alive for assembly and local checks. No repacking or full F32 weight shadow.',
        mathematics='Original learned Q-rank norm, per-head BF16 query normalization, rotary/inverse rotary, sink attention and output stores remain. Optional metadata exposes actual producer boundaries; default/null suppliers retain existing operation order.',
        state='Same25-Graph journey per case: encoded main-ring bootstrap, complete draft, accepted prefixes0/1/2, wrap, nominated-Head continuation, rejection/cancellation/stale publication, retained results and collection. Proposal KV stays temporary.'),
    validation=dict(unique_tests=4, failures=0, errors=0, skips=0,
        model_graph_submissions=100, new_original_model_graph_submissions=50,
        related_regression_graph_submissions=50, cases=cases,
        attention_projection_values_checked=1382400, existing_shared_projection_values_checked=245760,
        numerical='First-episode original12 attention projections use the existing independent packed-Q8/native-activation oracle. Output-A references select actual group bytes and actual slot inputs. Each episode checks actual per-step query-normalization/RoPE inputs and BF16 stores, originalHC/sinks, sharedFFN, full-V/embedding/greedy/Markov/confidence and state boundaries; no ideal F64 predecessor is propagated through a later BF16 decision.',
        precision_scope='CPU uses the fixed actual AVX Q8_0 quantizer. SM89 M5 output-A GroupedMatMul uses token count5 for MMVQ eligibility, not the40 token/slot rows; its activation remainsQ8_1. Existing CUDA division-envelope assumptions remain explicit and conditional, not a formal all-input guarantee.',
        numerical_observations=numerics,
        commands_and_results=[identity(S / f'checks{i}/summary.json') for i in (1, 2)],
        compiled_host_translation_units=1, SDK_builds=0, native_CPU_builds=0,
        NVCC_builds=0, shaders=0, first_native_run_failures=0),
    source_reviews=[identity(p) for p in freezes], source_metadata=[identity(p) for p in metadata],
    remaining=dict(sidecar_roles=15,
        groups={'router_BF16':3, 'router_bias_F32':3, 'expert_MXFP4':9},
        sidecar_payload_bytes=10273950720,
        constraints='Original router/bias and expert supply must remain coupled to actual global IDs. Existing WeightSlots retains selected immutable uploads and explicit I32 maps; it does not silently remap IDs or support mid-flight Invocation rebinding. Residency and phase scheduling remain explicit consumer work.'),
    limitations=['WindowsCPU/CUDA only; no new Linux/Apple/Vulkan model run.',
        'Router/expert coefficients and target-capture/verifier boundary still generated. No full original trained target/stages, Pro geometry, primaryUD-Q4 vocabulary, natural acceptance or generation-quality claim.',
        'Selected Q8 storage and native activation math do not establish equality to officialFP8/BF16 projections or other codecs.',
        'No new TPS, loading or physical memory/VRAM peak measurement; latestAV performance table retained.',
        'Full MTP and broader architecture/performance/image goal remain incomplete.'],
    next='Actual expert supply/global-ID mapping and router coupling, other actual-role/sharedLM/targettap/Pro/confirmedquant work, then necessary final ordinary/MTP performance comparison before images.',
    final_image=image, sources=[identity(p) for p in sources], performance_tail_sha256=tail_hash,
    cleanup='One executable/map and one host object retained for replay and later incremental linking. No superseded BL image, whole shard or SDK copy was produced; no deletion required.',
    archive=identity(archive), archive_items=len(paths))
out = D / 'mtp-dspark-original-attention-2026-10-23.json'
assert not out.exists()
out.write_text(json.dumps(record, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
(S / 'publication.json').write_text(json.dumps(dict(evidence=identity(out), archive=identity(archive)),
    ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps(dict(evidence=identity(out), archive=identity(archive), tests=4, graphs=100), ensure_ascii=False))
