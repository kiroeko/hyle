"""Fetch only the twelve pinned DSpark attention Q8_0 parameters."""
from pathlib import Path
import datetime
import hashlib
import json
import math
import urllib.request

S = Path(__file__).resolve().parent
R = S.parents[1]


def read(p):
    return json.loads(Path(p).read_text(encoding='utf-8-sig'))


plan_path = R / '.scratch/dspark-original-hc-20261023/review/remaining-original-roles.json'
plan = read(plan_path)['remaining']['groups']['attention_projection']
old = read(R / '.scratch/glm-mtp-catchup-20261022/review/dspark-original-target-roles.json')
headers_path = R / old['header_source']
header = read(headers_path)[old['header_cache_key']]
for key in ('repository', 'revision', 'file', 'tensor_table_sha256'):
    assert header[key] == old[key], key
assert header['tensor_count'] == 81
table = {r['name']: r for r in header['tensors']}
roles = sorted(plan['roles'], key=lambda r: r['absolute_range_inclusive'][0])
assert len(roles) == plan['count'] == 12 and plan['bytes'] == 334233600
for role in roles:
    row = table[role['name']]
    assert row['dtype'] == role['codec'] == 'Q8_0' and row['dtype_code'] == 8
    assert [int(x) for x in row['shape']] == role['gguf_dimensions']
    assert role['gguf_dimensions'][0] % 32 == 0
    extent = math.prod(role['gguf_dimensions']) // 32 * 34
    start = int(header['tensor_data_offset']) + int(row['offset'])
    assert extent == role['payload_bytes']
    assert [start, start + extent - 1] == role['absolute_range_inclusive']

groups = []
for role in roles:
    first, last = role['absolute_range_inclusive']
    if groups and first - groups[-1]['last'] - 1 <= 32:
        groups[-1]['last'] = last
        groups[-1]['roles'].append(role)
    else:
        groups.append(dict(first=first, last=last, roles=[role]))
assert len(groups) == 3

out = S / 'original-attention'
out.mkdir(exist_ok=True)
receipt = out / 'acquisition.json'
record = dict(repository=old['repository'], revision=old['revision'], file=old['file'],
    url=old['url'], whole_file_bytes=old['known_whole_file_bytes'], etag=old['known_etag'],
    tensor_table_sha256=old['tensor_table_sha256'], tensor_data_offset=old['tensor_data_offset'],
    source_plan=str(plan_path.relative_to(R)), complete=False, requests=[], roles=[],
    whole_file_downloaded=False, original_roles=12, expected_role_payload_bytes=334233600)
if receipt.exists():
    previous = read(receipt)
    for key in ('repository', 'revision', 'file', 'etag', 'tensor_table_sha256', 'source_plan'):
        assert previous[key] == record[key], key
    record = previous
    for row in record['roles']:
        body = (R / row['payload']['path']).read_bytes()
        assert len(body) == row['payload']['bytes']
        assert hashlib.sha256(body).hexdigest() == row['payload']['sha256']
    if record['complete']:
        assert len(record['roles']) == 12 and record['role_payload_bytes'] == 334233600
        print('REUSED twelve authenticated attention payloads', flush=True)
        raise SystemExit(0)


def save():
    receipt.write_text(json.dumps(record, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


save()
for group in groups:
    acquired = {row['name'] for row in record['roles']}
    if all(row['name'] in acquired for row in group['roles']):
        continue
    first, last = group['first'], group['last']
    size = last - first + 1
    attempt = dict(first=first, last=last, requested_bytes=size, complete=False,
        started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
    record['requests'].append(attempt)
    save()
    print('REQUEST exact shared role group', first, last, size, flush=True)
    request = urllib.request.Request(old['url'], headers={
        'Range': f'bytes={first}-{last}', 'If-Range': old['known_etag'],
        'Accept-Encoding': 'identity', 'User-Agent': 'hyle-original-role-consumer/1'})
    try:
        with urllib.request.urlopen(request, timeout=60) as response:
            assert response.status == 206, response.status
            assert response.headers.get('Content-Range') == f'bytes {first}-{last}/{old["known_whole_file_bytes"]}'
            assert response.headers.get('ETag') == old['known_etag']
            assert response.headers.get('Content-Length') in (None, str(size))
            body = response.read(size + 1)
            assert len(body) == size, len(body)
            attempt.update(http_status=206, content_range=response.headers['Content-Range'],
                etag=response.headers['ETag'], bytes=len(body), sha256=hashlib.sha256(body).hexdigest())
    except Exception as error:
        attempt.update(error_type=type(error).__name__, error=str(error),
            finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
        save()
        raise
    for role in group['roles']:
        if role['name'] in acquired:
            continue
        begin, end = role['absolute_range_inclusive']
        payload = memoryview(body)[begin-first:end-first+1]
        assert len(payload) == role['payload_bytes']
        path = out / (role['name'] + '.q8_0')
        if path.exists():
            assert path.read_bytes() == payload
        else:
            with path.open('xb') as stream:
                stream.write(payload)
        record['roles'].append(dict(**role, payload=dict(path=str(path.relative_to(R)),
            bytes=len(payload), sha256=hashlib.sha256(payload).hexdigest())))
    attempt.update(complete=True, finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
    save()
    print('ACQUIRED exact Q8_0 roles', len(record['roles']), flush=True)

record.update(complete=True, role_payload_bytes=sum(r['payload']['bytes'] for r in record['roles']),
    successful_request_body_bytes=sum(r['bytes'] for r in record['requests'] if r['complete']))
assert len(record['roles']) == 12 and record['role_payload_bytes'] == 334233600
save()
print(json.dumps(dict(roles=12, payload_bytes=record['role_payload_bytes'],
    request_body_bytes=record['successful_request_body_bytes'])), flush=True)
