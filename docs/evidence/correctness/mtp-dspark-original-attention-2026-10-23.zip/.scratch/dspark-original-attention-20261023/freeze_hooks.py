import hashlib
import json
from pathlib import Path
import shutil
import subprocess

ROOT = Path(__file__).resolve().parents[2]
BASE = ROOT / '.scratch/dspark-original-attention-20261023/hooks-source'
FILES = [
    'tests/compute_models/cpu_c4_model_branches.h',
    'tests/compute_models/d5_deepseek_official_attention.h',
    'tests/compute_models/d5_deepseek_official_fragments.h',
]

def identity(path):
    return dict(path=path.relative_to(ROOT).as_posix(), bytes=path.stat().st_size,
                sha256=hashlib.sha256(path.read_bytes()).hexdigest())

entries = []
for relative in FILES:
    source = ROOT / relative
    before = BASE / 'before' / relative
    frozen = BASE / 'frozen' / relative
    frozen.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(source, frozen)
    delta = subprocess.run(['git', 'diff', '--no-index', '--', str(before), str(source)],
                           cwd=ROOT, capture_output=True)
    if delta.returncode not in (0, 1):
        raise RuntimeError(delta.stderr.decode(errors='replace'))
    diff_path = BASE / 'diff' / (source.name + '.diff')
    diff_path.parent.mkdir(parents=True, exist_ok=True)
    diff_path.write_bytes(delta.stdout)
    entries.append(dict(**identity(source), before=identity(before), frozen=identity(frozen),
                        diff=identity(diff_path)))

record = {
    'scope': 'Source-only immutable packed Q8_0 attention hooks; no native build, execution, download or SSH.',
    'files': entries,
    'carrier': 'PackedProjectionParameter{value,codes,reference}; PackedProjectionReference(span<float>)->raw F32 mathematical vector. Replaces Shared-specific carrier names without compatibility aliases. Actual execution uses Graph operands only.',
    'parameter_interface': 'DraftParameters.attention_projection(parent Fragment,stage,AttentionProjectionRole) with QueryA,QueryB,OutputA,OutputB. Four same-Fragment immutable constants qualified before ordinary child attachment.',
    'geometry': {
        'qa': 'Q8_0 canonical logical RHS[4096,1024]',
        'qb': 'Q8_0 canonical logical RHS[1024,32768]',
        'oa': 'Q8_0 grouped logical/physical[8,1024,4096], original8192row payload metadata only; input[5,8,4096], IDs[5,8] each0..7; output[5,8,1024]',
        'ob': 'Q8_0 canonical logical RHS[8192,4096], consumes actual BF16-stored OA flatten[5,8192]',
        'child_inputs': {'prepared': 10, 'nonprepared': 13},
        'diagnostic_fields': 29,
        'child_outputs': {'prepared': 38, 'nonprepared': 42}
    },
    'boundaries': [
        'QA/QB/OB ordinary F32 MatMul then explicit BF16 store/widen; OA ordinary GroupedMatMul then established BF16 store/widen.',
        'Learned query-rank RMS and sinks use existing original immutable F32 banks and old8 ports.',
        'QueryNormPorts records actual11 values across BF16 square, mean, epsilon shift, rsqrt and multiply; no new computation or ideal-chain output replaces actual edges.',
        'RopePorts records input, raw F32 prefix/rotated concat and actual BF16 stored output for both forward and inverse rotations.',
        'All29 projection diagnostics append after semantic ports and old8 observations; parent maps them in the identical visit_values order, optional absent path is not visited.',
        'Default/generated and previous56-role branches retain original operator order and formulas; renamed shared carrier changes no math.',
        'Packed mode rejects generated standalone replays without parent attachment; no new executor, provider switch, repack or dense F32 weight bank.'
    ],
    'state': 'Existing semantic outputs, encoded histories, state schema and accepted-prefix journey remain unchanged. Caller wrapper materializes actual observations with existing ordinal Copy deduplication.',
    'review': 'Portable independently reviewed prepared/nonprepared binding order, all29 metadata fields, original node order and grouped geometry; no confirmed remaining source issue.',
    'native_status': 'Not executed by this agent; root owns related single-TU validation.'
}
freeze = BASE / 'freeze.json'
freeze.write_text(json.dumps(record, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps(dict(freeze=identity(freeze), files=[identity(ROOT / f) for f in FILES]), indent=2))
