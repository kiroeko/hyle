#include "source/engine/models/qwen35/main.cc"
#include <cstdio>

namespace q=qwen35;
void require(bool value,const char *where) {if(!value)throw std::runtime_error(where);}
template<class F> void rejected(F f) {
  bool failed=false;try{f();}catch(const std::runtime_error&){failed=true;}
  require(failed,"expected cold policy rejection");
}
int main() {
  try {
    q::ModelGeometry geometry;
    geometry.hidden=64;geometry.intermediate=128;geometry.vocabulary=64;
    geometry.query_heads=geometry.kv_heads=1;geometry.key_depth=geometry.value_depth=64;geometry.rotary=16;
    geometry.gdn_key_heads=geometry.gdn_value_heads=1;geometry.gdn_key_depth=geometry.gdn_value_depth=16;
    geometry.conv_kernel=4;geometry.context_limit=64;geometry.rope_theta=10000;geometry.epsilon=1e-6F;geometry.layers="A";
    geometry.validate();
    const q::SamplingConfiguration greedy{},random{true,{.temperature=.7F,.top_k=8,.top_p=.9F}};
    q::validate_sampling_configuration(greedy,64);q::validate_sampling_configuration(random,64);
    auto invalid=random;invalid.policy.temperature=0;rejected([&]{q::validate_sampling_configuration(invalid,64);});
    invalid=random;invalid.policy.top_p=std::numeric_limits<float>::quiet_NaN();rejected([&]{q::validate_sampling_configuration(invalid,64);});
    invalid=random;invalid.policy.top_k=65;rejected([&]{q::validate_sampling_configuration(invalid,64);});
    invalid=greedy;invalid.policy.temperature=.5F;rejected([&]{q::validate_sampling_configuration(invalid,64);});
    require(!q::same_sampling_configuration(greedy,{true,{.top_k=1}}),"greedy was confused with random k1");
    const std::array additional{random};
    auto owner=std::make_shared<q::ColdResources>(geometry,32,q::PrecisionProfile{},greedy,additional);
    const auto *first=&owner->sampling_configuration(0),*second=&owner->sampling_configuration(1);
    require(owner->sampling_index(first)==0&&owner->sampling_index(second)==1,"cold policy ordinal mismatch");
    require(owner->sampling_index(nullptr)==0,"default history binding changed");
    rejected([&]{(void)owner->sampling_configuration(2);});
    auto foreign=std::make_shared<q::ColdResources>(geometry,32,q::PrecisionProfile{},greedy,std::span<const q::SamplingConfiguration>{});
    rejected([&]{(void)owner->sampling_index(&foreign->sampling_configuration(0));});
    rejected([&]{q::ColdResources duplicate(geometry,32,q::PrecisionProfile{},greedy,std::array{greedy});});
    auto retained=owner;owner.reset();require(&retained->sampling_configuration(1)==second,"cold policy address moved");
    q::GenerationLedger ledger(1);const auto strong=retained.use_count();ledger.bind_sampling(*second,retained);
    require(retained.use_count()==strong,"ledger pinned the weight bank");
    ledger.validate_sampling(*second,retained);
    rejected([&]{ledger.validate_sampling(foreign->sampling_configuration(0),foreign);});
    require(!retained->pending()&&!first->frontier&&!second->frontier,"host policy check created an execution carrier");
    const q::FamilyKey a(2,q::GraphRole::kText,0,q::TextCompletion::kEmitNext,0),b(2,q::GraphRole::kText,0,q::TextCompletion::kEmitNext,1);
    require(a!=b,"family policy axis missing");
    require(q::ExecutionShape{2,1,q::GraphRole::kText,q::TextCompletion::kEmitNext,0}!=q::ExecutionShape{2,1,q::GraphRole::kText,q::TextCompletion::kEmitNext,1},"phase policy axis missing");
    static_assert(!std::is_assignable_v<decltype((second->configuration)),q::SamplingConfiguration>);
    const std::array<std::int32_t,1> prompt{1};q::GenerationRequest request("host",prompt,{},2,1);
    require(request.sampling_index==1,"immutable request policy binding missing");
    static_assert(!std::is_assignable_v<decltype((request.sampling_index)),std::size_t>);
    retained.reset();require(ledger.sampling_owner.expired(),"ledger kept a destroyed model bank alive");
    rejected([&]{ledger.validate_sampling(foreign->sampling_configuration(0),foreign);});
    std::printf("PASS: cold validation, greedy/random-k1 identity, finite policy handles, foreign/out-of-range/duplicate rejection, retained stable lifetime, family/phase axes, immutable request choice; no Context/weights/Graph execution\n");
    return 0;
  }catch(const std::exception &error){std::fprintf(stderr,"%s\n",error.what());return 1;}
}
