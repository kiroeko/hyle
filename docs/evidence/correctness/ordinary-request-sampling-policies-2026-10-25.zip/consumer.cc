// Private finite original-geometry A fixture; generated weights, not model quality.
#include "source/engine/models/qwen35/main.cc"
namespace q = qwen35;
using Schedule = hyle::inference::GenerationSessionSchedule;
void require(bool value, const char *where) { if (!value) throw std::runtime_error(where); }
template<class F> void rejected(F f) {
  bool caught = false; try { f(); } catch (const std::runtime_error &error) {
    caught = true; std::cerr << "expected_rejection=" << error.what() << '\n';
  }
  require(caught, "expected explicit preflight rejection");
}
q::ModelGeometry shape() {
  q::ModelGeometry s; s.hidden=64; s.intermediate=128; s.vocabulary=64;
  s.query_heads=s.kv_heads=1; s.key_depth=s.value_depth=s.rotary=64;
  s.gdn_key_heads=s.gdn_value_heads=1; s.gdn_key_depth=s.gdn_value_depth=64;
  s.conv_kernel=4; s.context_limit=16; s.rope_theta=10000; s.epsilon=1e-6F;
  s.tied_head=true; s.layers="A"; s.mtp_layers=1; s.validate(); return s;
}
std::filesystem::path text_manifest(const std::filesystem::path &input, const std::filesystem::path &folder) {
  const auto inventory=q::prepared::parameter_inventory(false,shape()); std::set<std::string> required;
  for (const auto &[name,spec] : inventory) { (void)spec; required.insert(name); }
  std::ifstream source(input); require(bool(source),"cached A fixture is absent");
  const auto output=folder/"text-weights.tsv"; std::ofstream target(output);
  std::string line; for(int i=0;i<3;++i) { require(bool(std::getline(source,line)),"short role preamble"); target<<line<<'\n'; }
  while(std::getline(source,line)) { std::istringstream fields(line); std::string name; fields>>name; if(required.erase(name))target<<line<<'\n'; }
  require(source.eof()&&required.empty()&&bool(target),"incomplete Text-only fixture inventory"); return output;
}
void check_preflight(q::Model &model) {
  const auto attempt=[&](std::int32_t token,std::size_t credit) {
    auto owner=std::make_shared<std::vector<std::int32_t>>(std::initializer_list<std::int32_t>{token});
    q::GenerationRequest r("invalid",*owner,{},1,1); r.warm_inputs.push_back(owner);
    r.ledger=std::make_unique<q::GenerationLedger>(1,1);
    rejected([&] { (void)q::prepare_generation_call(model,r,1,nullptr,{},credit); });
    require(!r.session&&!r.ledger->sampling&&r.ledger->sampling_owner.expired()&&!r.ledger->committed_count,
      "failed request preflight changed ledger identity or admitted a Session");
  };
  attempt(1,0); attempt(64,SIZE_MAX);
}
void boundaries(q::Model &model) {
  auto owner=std::make_shared<std::vector<std::int32_t>>(std::initializer_list<std::int32_t>{1,2});
  q::GenerationRequest r("boundary",*owner,{},2,2); r.warm_inputs.push_back(owner);
  r.progress.initial_sampling={123,9,0}; r.round_emitted.resize(1); r.round_emitted[0].reserve(1);
  r.ledger=std::make_unique<q::GenerationLedger>(2,1);
  std::array calls{q::prepare_generation_call(model,r,2,nullptr,{})}; q::execute_generation_calls(model,calls,false);
  require(r.progress.generated.size()==1&&r.ledger->committed_count==1&&r.session->head->sampling.draw==1,
    "random producer did not publish its one actual sample");
  auto original=r.session->head; const auto canonical=original->state_identity();
  const auto producer_id=original->next_id; const auto producer_cursor=original->sampling;
  const auto empty=std::span<const std::size_t>{}; const std::array one{std::size_t{1}};
  std::int32_t greedy=-1;
  {
    auto selected=model.create_session(empty,original,q::GraphRole::kText,q::cache::SamplingCursor{},true,q::TextCompletion::kEmitNext,0);
    greedy=selected->head->next_id;
    require(selected->head->state_identity()==canonical&&selected->head->carry_hidden.valid()&&selected->head->sampling==q::cache::SamplingCursor{},
      "new greedy full hit copied state or inherited random cursor");
    selected.reset();
  }
  {
    const q::cache::SamplingCursor cursor{456,10,0};
    auto selected=model.create_session(empty,original,q::GraphRole::kText,cursor,true,q::TextCompletion::kEmitNext,1);
    require(selected->head->state_identity()==canonical&&selected->head->next_id==greedy&&selected->head->sampling==cursor.advanced(1),
      "new random-k1 full hit failed to use selected policy/cursor");
    selected.reset();
  }
  {
    auto selected=model.create_session(one,original,q::GraphRole::kText,q::cache::SamplingCursor{},false,q::TextCompletion::kEmitNext,0);
    require(selected->head->sampling==q::cache::SamplingCursor{}&&selected->head->next_id==-1,
      "new greedy partial hit inherited random producer pending/cursor");
    const std::array<std::int32_t,1> suffix{3}; model.prepare_evaluation(*selected,suffix); model.submit_evaluation(*selected);
    (void)q::finish_evaluation(model,*selected,"partial",{},false);
    require(selected->length()==3&&selected->head->sampling==q::cache::SamplingCursor{},"greedy partial suffix sampled or lost context");
    selected.reset();
  }
  const auto historical=(producer_id+1)%64;
  model.restore_pending_boundary(*r.session,producer_cursor,historical);
  auto same=model.create_session(empty,r.session->head,q::GraphRole::kText,{},false,q::TextCompletion::kEmitNext,2);
  require(same->head->next_id==historical&&same->head->sampling==producer_cursor&&same->head->state_identity()==canonical,
    "same-request restore discarded historical pending/cursor"); same.reset();
  require(original->next_id==producer_id&&original->sampling==producer_cursor,"prefix forks mutated an old reader");
  calls={}; q::retire_generation_request(r);
  {
    auto rebuilt=q::rebuild_generation_session(model,*r.ledger);
    require(&rebuilt->sampling_configuration()==&model.sampling_configuration(2)&&rebuilt->head->next_id==producer_id&&rebuilt->head->sampling==producer_cursor,
      "ordinary ledger rebuild lost its selected configuration or historical boundary"); rebuilt.reset();
  }
  original.reset();
  require(model.snapshot_versions.live==0&&!model.active_step&&!model.carrier_borrowed,"boundary checks leaked live state");
  std::cout<<"{\"private_facts\":\"mixed-policy-boundaries\",\"producer\":"<<producer_id<<",\"greedy\":"<<greedy
    <<",\"full_hit_selected\":true,\"partial_hit_zero_cursor\":true,\"same_request_historical\":true,\"ledger_rebuild_policy\":2,\"old_reader_immutable\":true}\n";
}
int main(int argc,char **argv) {
  try {
    require(argc==3,"consumer EXISTING_A_MANIFEST PRIVATE_OUTPUT"); const std::filesystem::path out=argv[2]; std::filesystem::create_directories(out);
    const auto selected=text_manifest(argv[1],out); const auto geometry=shape();
    const auto plan=q::cache::plan(geometry,16,2,5,q::recurrent_bytes(q::state_schema_for(geometry,16),geometry),2,1,false,true);
    const std::array additional{q::SamplingConfiguration{true,{1.F,1,1.F}},q::SamplingConfiguration{true,{.7F,8,.9F}}};
    q::Model model(selected,geometry,16,plan,{},false,q::ReplayPolicy::kCommands,16*1024*1024,
      {.enabled=false,.policy={},.seed=123},0,{.primary=hyle::inference::BackendKind::kCuda},additional);
    require(model.sampling_configuration_count()==3&&model.retains_sampling_frontier(),"finite immutable policy bank not prepared");
    const std::vector<Schedule> schedules{{"g0",{{{1,2},3},{{3},2}}},{"g1",{{{1,2},3},{{3},2}}},
      {"r0",{{{1,2},3},{{3},2}}},{"r1",{{{1,2},3},{{3},2}}},
      {"k0",{{{1,2},3},{{3},2}}},{"k1",{{{1,2},3},{{3},2}}}};
    const std::array<std::size_t,6> policy{0,0,2,2,1,1}; std::vector<q::cache::TokenPlanRef> input;
    for(const auto &request:schedules) input.push_back(q::cache::token_plan(request.turns[0].prompt,16));
    const auto start=q::Clock::now();
    require(q::run_generation_sessions<q::GenerationMode::kText>(model,schedules,{},false,start,start,true,input,policy)==0,"mixed-policy natural requests failed");
    require(model.snapshot_versions.live==0&&!model.active_step&&!model.carrier_borrowed,"natural requests leaked a head/carrier");
    require(!model.cache_plan.draft_cache&&model.physical_mtp_roles==0&&model.draft_programs.empty()&&model.prefix_sampling_programs.empty(),"ordinary policy path prepared NextN");
    for(const auto &[key,family]:model.families)require(family->role==q::GraphRole::kText&&family->sampling==&model.sampling_configuration(key.sampling_index),"family policy binding differs from key");
    check_preflight(model); boundaries(model);
    std::cout<<"{\"private_facts\":\"ordinary-same-model\",\"configurations\":3,\"requests\":6,\"turns\":12,\"N\":2,\"R\":2,\"text_only\":true,\"same_weight_bank\":true,\"preflight_side_effect_free\":true,\"HTTP\":0,\"quality_claim\":false,\"performance_claim\":false}\n";
    return 0;
  } catch(const std::exception &error) { std::cerr<<"mixed-policy consumer: "<<error.what()<<'\n'; return 1; }
}
