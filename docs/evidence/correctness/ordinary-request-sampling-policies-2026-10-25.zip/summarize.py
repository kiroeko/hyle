from pathlib import Path
import json,hashlib
D=Path(__file__).resolve().parent
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def save(p,v):p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8')
def pin(p):return dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
reports=[json.loads(x)for x in(D/'cuda1/run/stdout.log').read_text().splitlines()if x.startswith('{')]
assert len(reports)==3
r,edges,end=reports
assert not r['mtp'] and r['backend']=='cuda' and r['text_tensors']==13 and r['mtp_tensors']==0
assert r['session_count']==6 and r['turn_count']==12 and r['active_sequences']==r['max_sessions']==2
assert r['generated_tokens']==r['requested_output_tokens']==30 and len(r['batches'])==15
assert r['idle_evictions']==6 and r['restore_count']==4 and r['restored_graph_calls']==12 and r['recomputed_decision_changes']==0
assert all(x['role']==0 and x['requests']==2 for x in r['batches'])
expected={'g0':0,'g1':0,'r0':2,'r1':2,'k0':1,'k1':1}
assert all(len({expected[s]for s in batch['session_ids']})==1 for batch in r['batches'])
facts=[]
for s in r['sessions']:
 v=s['result'];index=expected[s['session_id']];ledger=s['ledger']
 assert v['sampling_configuration_index']==index and v['sampling_draw_cursor']==(0 if index==0 else 5)
 assert len(v['generated_ids'])==5 and len(ledger)==5 and len(v['turns'])==2
 assert v['turns'][1]['input_ids']==[v['generated_ids'][2],3]
 assert all(x['role']==0 and not x['draft_rows'] and x['sampling_draw_before']==(0 if index==0 else i) and x['sampling_draw_after']==(0 if index==0 else i+1)for i,x in enumerate(ledger))
 assert [x['after_length']for x in ledger]==[2,3,4,6,7]
 facts.append(dict(id=s['session_id'],index=index,ids=v['generated_ids'],draw=v['sampling_draw_cursor'],restore_count=s['restore_count'],input_turn2=v['turns'][1]['input_ids']))
assert edges['producer']==5 and edges['greedy']==39 and all(edges[k]for k in['full_hit_selected','partial_hit_zero_cursor','same_request_historical','old_reader_immutable'])
assert r['cache_peak_requested_bytes']<=r['cache_requested_byte_limit'] and r['peak_committed_versions']<=2
summary=dict(status='PASS',scope='One same-Model CUDA ordinary generated-weight A fixture, finite three-policy cold bank; no trained artifact/quality/performance claim.',source=pin(D/'source/engine/models/qwen35/main.cc'),image=read(D/'cuda1/ready.json')['image'],compile=read(D/'cuda1/compile/process.json'),link=read(D/'cuda1/link/process.json'),run=read(D/'cuda1/run/process.json'),hardware='Actual stderr: RTX4070 sm89,12281MiB',geometry=dict(H=64,V=64,FFN=128,layers='A',capacity=16,N=2,R=2),weights=dict(physical_text_roles=13,physical_mtp_roles=0,device_bytes=98944,generated=True,original_artifact=False),configurations=[dict(index=0,enabled=False,temperature=1,top_k=0,top_p=1),dict(index=1,enabled=True,temperature=1,top_k=1,top_p=1),dict(index=2,enabled=True,temperature=.7,top_k=8,top_p=.9)],natural=dict(requests=6,turns=12,outputs=30,actual_buckets=15,all_buckets_real_R2=True,all_buckets_single_policy=True,idle_evictions=6,ledger_restores=4,restored_graph_calls=12,decision_changes=0,requests_facts=facts),boundaries=edges,credit_and_tokens_rejected_before_ledger_binding=True,after_boundary_checks_live_versions=0,weak_identity_host=read(D/'host3/summary.json'),strict_CPU_CUDA=read(D/'syntax7-final-cpu-cuda/process.json'),permanent_case=dict(pins=read(D/'registered-case-pins.json'),strict=read(D/'syntax8-registered-case/process.json'),run=False,reason='Generalized existing heavy-executable case; source checked only, no repeated GPU run.'),limits=['Natural run had no directory lookup hits; full-hit/partial-hit selected policy checks directly used original complete Snapshot/hidden with same Model create_session.','Actual CUDA ran exactly the frozen private main; canonical was then integrated byte-identically by root.','Default single greedy zero-hidden preservation is source/host derived, no second Model bank/run.','No nondefault MTP, CPU runtime, other backend, full-model quality or performance claims.'],HTTP=0,SDK_builds=0,GPU_processes=1)
save(D/'cuda1/summary.json',summary)
print(json.dumps(dict(status='PASS',source=summary['source'],requests=facts,boundaries=edges),indent=2))
