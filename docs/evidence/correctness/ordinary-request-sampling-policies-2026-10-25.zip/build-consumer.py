from pathlib import Path
import importlib.util,sys,os,json
sys.dont_write_bytecode=True
R=Path.cwd();D=Path(__file__).resolve().parent
sp=importlib.util.spec_from_file_location('b',R/'.scratch/mtp-extraction-regression-20261024/check.py')
b=importlib.util.module_from_spec(sp);sp.loader.exec_module(b)
base=R/'.scratch/inference-system-review-20261025/schedule-inputs'
out=D/(sys.argv[1] if len(sys.argv)>1 else 'cuda1');out.mkdir(exist_ok=False)
a=b.args(base/'compile/command.json');flags=[];skip=False
for f in a[1:]:
 if skip:skip=False;continue
 if f=='/sourceDependencies':skip=True;continue
 if f.lower().startswith(('/fo','/fd'))or f.lower().endswith(('.cc','.cpp')):continue
 flags.append(f)
env=b.environment(a[0]);source=D/'source/engine/models/qwen35/main.cc';before=b.pin(source)
b.save(out/'before-source.json',before)
b.execute([a[0],*flags,str(D/'consumer.cc'),'/sourceDependencies',str(out/'compile/dependencies.json'),'/Fo'+str(out/'compile/unit.obj')],out/'compile',env,120)
assert before==b.pin(source),'Private main changed during compile'
dep=b.read(out/'compile/dependencies.json')['Data'];actual=[]
for f in [dep['Source'],*dep['Includes']]:
 p=Path(f)
 if p.is_relative_to(R):actual.append(b.pin(p))
b.save(out/'actual-source-pins.json',actual)
old=b.args(base/'link/command.json');args=[];count=0
for f in old[1:]:
 if f.lower()==str(base/'compile/unit.obj').lower():args.append(str(out/'compile/unit.obj'));count+=1
 elif not f.lower().startswith(('/out:','/pdb:','/map:','/implib:')):args.append(f)
assert count==1
b.execute([old[0],*args,'/OUT:'+str(out/'link/consumer.exe'),'/IMPLIB:'+str(out/'link/consumer.lib')],out/'link',env,120)
native=base/'link/hyle_ggml_cpu_gdn_scale_v3.dll';os.link(native,out/'link'/native.name)
b.save(out/'ready.json',dict(image=b.pin(out/'link/consumer.exe'),source=before,native=b.pin(native),SDK=0,HTTP=0,GPU_run=False))
print('READY, not run',flush=True)
