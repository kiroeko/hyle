from pathlib import Path
import importlib.util,sys,os
sys.dont_write_bytecode=True
R=Path.cwd();D=Path(__file__).resolve().parent
sp=importlib.util.spec_from_file_location('b',R/'.scratch/mtp-extraction-regression-20261024/check.py')
b=importlib.util.module_from_spec(sp);sp.loader.exec_module(b)
base=R/'.scratch/qwen-pure-cpu-deployment-20261024/current1'
out=D/(sys.argv[1] if len(sys.argv)>1 else 'host2');out.mkdir(exist_ok=False)
a=b.args(base/'compile-command.json');flags=[];skip=False
for f in a[1:]:
    if skip:skip=False;continue
    if f=='/sourceDependencies':skip=True;continue
    if f.lower().startswith(('/fo','/fd')) or f.lower().endswith(('.cc','.cpp')):continue
    flags.append(f)
env=b.environment(a[0])
b.save(out/'before-source.json',b.pin(D/'source/engine/models/qwen35/main.cc'))
b.execute([a[0],*flags,'/Gy',str(D/'host.cc'),'/Fo'+str(out/'host.obj')],out/'compile',env,120)
link=b.args(base/'link-command.json');args=[]
for f in link[1:]:
    n=f.lower().replace('\\','/')
    if n.endswith(('/engine/main.cc.obj','/current1/main.obj')) or n.startswith(('/out:','/pdb:','/implib:')):continue
    args.append(f)
report=R/'.scratch/mtp-performance-convergence-20261025/current-cuda/report/unit.obj'
b.execute([link[0],*args,str(report),str(out/'host.obj'),'/OPT:REF','/OUT:'+str(out/'host.exe'),'/IMPLIB:'+str(out/'host.lib')],out/'link',env,120)
env=os.environ.copy();env['PATH']=b.read(base/'runtime-environment.json')['PATH']
b.execute([str(out/'host.exe')],out/'run',env,60)
assert b.read(out/'before-source.json')==b.pin(D/'source/engine/models/qwen35/main.cc')
b.save(out/'summary.json',dict(status='PASS',kind='actual CPU host-only cold policy/identity/ownership checks',image=b.pin(out/'host.exe'),source=b.pin(D/'source/engine/models/qwen35/main.cc'),GPU=0,Model_or_weights=0,SDK_build=0))
