from pathlib import Path
import json,hashlib,zipfile
R=Path.cwd();D=Path(__file__).resolve().parent
OUT=R/'docs/evidence/correctness/ordinary-request-sampling-policies-2026-10-25'
def pin(p):return dict(path=str(p.relative_to(R)).replace('\\','/'),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
files={}
def add(p,name=None):
 assert p.is_file(),p
 files[name or p.relative_to(D).as_posix()]=p
for p in (D/'source').rglob('*'):
 if p.is_file():add(p)
for name in ['canonical-2da-main.cc','before-pins.json','after-pins.json','nf4-baseline-delta.patch','candidate.patch','host.cc','consumer.cc','build-host.py','build-consumer.py','summarize.py','publish.py','host-source-bridge.json','source-review.json','registered-case-pins.json']:
 add(D/name)
for folder in ['host1','host2','host3','syntax1','syntax2','syntax3','syntax4-cpu-cuda','syntax5-cpu-cuda','syntax6-merged-cpu-cuda','syntax7-final-cpu-cuda','syntax8-registered-case','cuda1']:
 for p in(D/folder).rglob('*'):
  if p.is_file()and p.suffix in{'.json','.log'}and p.name!='live.json':add(p)
for name in ['tests/tools/qwen_sampling_policy_case.h','tests/tools/qwen_request_lifecycle_test.cc','tests/CMakeLists.txt']:
 add(R/name,'source/'+name)
manifest=[dict(name=name,bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())for name,p in sorted(files.items())]
(D/'archive-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
add(D/'archive-manifest.json')
archive=OUT.with_suffix('.zip')
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9)as z:
 for name,p in sorted(files.items()):z.write(p,name)
with zipfile.ZipFile(archive)as z:
 assert z.testzip()is None
 for row in manifest:
  data=z.read(row['name']);assert len(data)==row['bytes']and hashlib.sha256(data).hexdigest()==row['sha256']
summary=read(D/'cuda1/summary.json')
proof=dict(title='Ordinary requests share one weight bank with finite immutable sampling policies',date='2026-10-25',status='PASS',implementation=dict(main=summary['source'],baseline=pin(D/'canonical-2da-main.cc'),patch=pin(D/'candidate.patch'),scope=['Constructor-only finite immutable configurations; Session direct stable reference; family, child shape, planned slots and natural bucket include selected policy.','Greedy/random probability graphs retain original operations and precision; heterogeneous policies ordinary Text only.','New-request full frontier uses selected policy; same-request restore retains its historical pending/cursor.','GenerationLedger weak identity reuses original ColdResources control block without owning model weights; expired/foreign Model rejected.','Credit/input preflight precedes first ledger policy binding; exact suffix cache retains original N*R shared limit/drain gates.']),actual=summary,host=read(D/'host3/summary.json'),first_failures=[dict(path='syntax1',kind='private strict check: local sampler shadowed old member',fixed=True),dict(path='syntax2',kind='private strict check: three wrong selected-sampler scope references',fixed=True),dict(path='syntax4-cpu-cuda',kind='private harness lacked cached CUDA include path',fixed=True),dict(path='host1/link',kind='private harness initially omitted existing execution_report object',fixed=True)],verification_boundaries=['The only CUDA process used the frozen private main and one generated-weight H64/V64 A-only bank. No trained artifact, full-model quality or throughput result.','The integrated canonical main exactly matched frozen main when permanent test was strict-compiled. A generalized --sampling-policies case was registered in the existing lifecycle executable; it was not separately run.','Natural run had 0 prefix-directory hits. Additional full/partial prefix policy checks directly reused original complete Snapshot/hidden through real same-Model create_session.','Default single greedy zero-hidden path retained by original cold condition and host/source review; no extra full Model was allocated for a duplicate baseline.','Original MTP default graph/math source paths retained; this batch does not add heterogeneous MTP or run another MTP/backend matrix.'],archive=dict(pin(archive),members=len(files),crc_checked=True,member_sha_checked=True,weights_or_binaries_included=False),raw=str(D.relative_to(R)).replace('\\','/'),HTTP=0,SDK_builds=0,GPU_processes=1)
OUT.with_suffix('.json').write_text(json.dumps(proof,indent=2)+'\n')
(D/'publication.json').write_text(json.dumps(dict(public_json=pin(OUT.with_suffix('.json')),archive=pin(archive),members=len(files),CRC='PASS',SHA='PASS'),indent=2)+'\n')
print((D/'publication.json').read_text())
