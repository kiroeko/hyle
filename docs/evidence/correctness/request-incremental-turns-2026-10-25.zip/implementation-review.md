The existing finite bind_turns contract remains closed input and unchanged.
Open binding requires a nonempty complete initial schedule and cold turn/prompt bounds.
One span is borrowed from a stable owner; the owner serializes calls and preserves all exposed turns/prompts.
Extensions validate only the new tail, including cumulative user-token and maximum-output reservations.
All extension publication occurs after local validation; rejection does not change the original span/counters.
Open-input output reservations count actual prior delivery plus the quotas of unfinished known turns.
A real first observed early stop releases only its unused quota; duplicate commits return before refund.
Close is idempotent and does not stop a known active turn. Completed last-known work waits while input is open.
After a valid append the existing advance/begin path consumes the historical pending exactly once.
Prompt budget is cumulative user suffix input, not KV/context capacity. Model admission remains an owner duty.
SamplingCursor/authoritative commit handling is unchanged; no second RNG, request store or turn copy.
This batch tests only the host primitive. No online ingress/CLI/session/Model integration is claimed.
