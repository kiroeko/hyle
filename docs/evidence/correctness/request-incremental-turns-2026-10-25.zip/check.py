from pathlib import Path
import hashlib,importlib.util,json
R=Path.cwd();W=R/'.scratch/inference-incremental-turns-20261025';F=W/'host1';F.mkdir(exist_ok=False)
spec=importlib.util.spec_from_file_location('retained_host_build',R/'.scratch/engine-product-20261024/cpu-build.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
recipe=b.read(R/'.scratch/inference-request-progress-20261025/host/inference_request_progress_test/compile/command.json')['command']
env=b.discover_environment(compiler='msvc',cache={'CMAKE_C_COMPILER':recipe[0],'CMAKE_CXX_COMPILER':recipe[0],'CMAKE_GENERATOR':'Ninja'},backends=()).env
cmd=[]
for i,a in enumerate(recipe):
 if i and recipe[i-1]=='/sourceDependencies':cmd.append(str(F/'dependencies.json'))
 elif a.startswith('/Fo'):cmd.append('/Fo'+str(F/'host.obj'))
 elif a.startswith('/Fe'):cmd.append('/Fe'+str(F/'checks.exe'))
 else:cmd.append(a)
paths=['engine/inference/request_progress.h','tests/tools/inference_request_progress_test.cc','engine/inference/request_window.h','engine/inference/sampling_cursor.h']
def pins():return {n:dict(bytes=(R/n).stat().st_size,sha256=hashlib.sha256((R/n).read_bytes()).hexdigest())for n in paths}
original=pins();(W/'source-pins.json').write_text(json.dumps(original,indent=2)+'\n')
b.execute(cmd,env,F/'compile',60)
b.execute([str(F/'checks.exe')],env,F/'run',30)
assert original==pins()
print((F/'run/stdout.log').read_text())
