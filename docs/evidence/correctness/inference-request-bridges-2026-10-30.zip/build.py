"""Finite architecture publication checks; reuse cached SDK, max two compilers."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import importlib.util,json,os,shutil,subprocess,sys
import xml.etree.ElementTree as ET
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;R=W.parents[1]
spec=importlib.util.spec_from_file_location('prior',R/'.scratch/inference-synchronous-step-driver-20261030/build.py')
past=importlib.util.module_from_spec(spec);spec.loader.exec_module(past)
s=past.b.s;s.W=s.b.W=W
read,save,pin,exact,key=s.read,s.save,s.pin,s.exact,s.key
BASE=R/'.scratch/inference-publication-boundary-20261030/model-link-base.json'

def prepare():
 assert not (W/'plan.json').exists()
 base=read(BASE);prior=read(BASE.parent/'plan.json')
 for item in [*base['retained'],base['runtime']]:exact(item)
 changed={key(R/x) for x in subprocess.check_output(['git','diff','--name-only','--','include','src','engine'],cwd=R,text=True).splitlines()}
 sdk=read(base['sdk_engine_dependencies']['path']);rows={key(x['object']):x for x in [*sdk['inspected'],*sdk['engine_consumers']] if 'dependencies' in x}
 affected=[];missing=[]
 for item in base['retained']:
  obj=Path(item['path']);row=rows.get(key(obj))
  for candidate in [obj.parent/'dependencies.json',obj.parent/(obj.stem+'-deps.json'),obj.with_suffix('.deps.json')]:
   if candidate.is_file() and 'Data' in read(candidate):row=dict(dependencies=pin(candidate));break
  if row is None:missing.append(str(obj));continue
  d=read(row['dependencies']['path'])['Data']
  if any(key(x) in changed for x in [d['Source'],*d['Includes']]):affected.append(d['Source'])
 assert not affected,affected
 wrapper=W/'cli.cc';wrapper.write_text('#include "../../engine/models/qwen35/main.cc"\nint main(int argc,char **argv){return qwen35::run(argc,argv);}\n')
 sources={'cli':wrapper,'tiny':R/'tests/tools/qwen_host_image_test.cc'}
 consumers={name:dict(source=str(src),compile=s.relocated(base['compile'],name,src)) for name,src in sources.items()}
 glm=read(R/'.scratch/inference-glm-math-boundary-20261030/plan.json')
 consumers['glm']=dict(glm['consumers']['glm'],compile=s.relocated(glm['consumers']['glm']['compile'],'glm'))
 fixture=R/'.scratch/inference-paged-frame-20261026/tiny-recursive-input'
 cases={
   'control-cpu':['tiny','--cpu',str(fixture),'--history-control'],
   'history-cuda':['tiny','--cuda',str(fixture),'--history-replay'],
   'natural-cuda':['tiny','--cuda',str(fixture),'--natural-logits'],
   'mtp':['cli',*prior['args']]}
 (W/'bin').mkdir(exist_ok=True);shutil.copyfile(base['runtime']['path'],W/'bin'/Path(base['runtime']['path']).name)
 cli=read(base['current_consumers']['cli']['receipt']['path'])
 save(W/'plan.json',dict(base=pin(BASE),base_commit='ed92cd602',retained=base['retained'],runtime=base['runtime'],
   original_link=base['link'],original_consumer=cli['object']['path'],units={},consumers=consumers,sdk=base['sdk_engine_dependencies'],
   missing_cached_dependency_records=missing,sdk_affected_sources=affected,SDK_CXX=0,NVCC=0,downloads=0,max_compilers=2,
   args=prior['args'],cases=cases,glm_environment=glm['environment'],glm_cases=glm['cases']))
 print('Prepared3 affected consumer TUs, unchanged227 SDK inputs; no SDK CXX/NVCC/downloads.',flush=True)

def compile_group(attempt,names):
 with ThreadPoolExecutor(max_workers=2) as pool:
  jobs=[pool.submit(s.compile_one,name,attempt) for name in names]
  for job in jobs:job.result()

def link(name,attempt):
 p=read(W/'plan.json');receipt=read(W/'compile'/name/'receipt.json')
 for item in [receipt['object'],*receipt['source_identities'],*p['retained']]:exact(item)
 args=[];replaced=0
 for arg in p['original_link']:
  if key(arg)==key(p['original_consumer']):arg=receipt['object']['path'];replaced+=1
  for prefix,suffix in [('/OUT:','.exe'),('/PDB:','.pdb'),('/IMPLIB:','.lib'),('/MAP:','.map')]:
   if arg.upper().startswith(prefix):arg=prefix+str((W/'bin'/name).with_suffix(suffix));break
  args.append(arg)
 assert replaced==1
 if name=='glm':args.extend(str(R/'.scratch/build-compute-v2-dev/lib'/x) for x in ('gtest_main.lib','gtest.lib'))
 s.b.execute(args,W/'link'/name/attempt,240);save(W/('ready-'+name+'.json'),pin(W/'bin'/(name+'.exe')))

def run(name,attempt):
 p=read(W/'plan.json');os.environ.update(HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',HF_DATASETS_OFFLINE='1')
 folder=W/'runs'/name/attempt
 if name in p['glm_cases']:
  os.environ.update(p['glm_environment']);os.environ.update(HYLE_GLM_Q30_WAIT_FOR_EXPERTS='0',HYLE_GLM_MLX_WAIT_FOR_EXPERTS='0',HYLE_GLM_GGUF_FLASH_WAIT_FOR_EXPERTS='0')
  consumer='glm';args=['--gtest_color=no','--gtest_fail_fast','--gtest_filter='+p['glm_cases'][name]['filter'],'--gtest_output=xml:'+str(folder/'results.xml')]
 else:consumer,*args=p['cases'][name]
 image=read(W/('ready-'+consumer+'.json'));exact(image);save(folder/'image.json',image)
 s.b.execute([image['path'],*args],folder,600)
 if consumer=='glm':
  xml=ET.parse(folder/'results.xml').getroot();assert xml.get('tests')=='1' and xml.get('failures')==xml.get('errors','0')=='0' and not xml.findall('.//skipped')
  result=dict(status='PASS',cases=[dict(name=x.get('classname')+'.'+x.get('name'),properties={y.get('name'):y.get('value') for y in x.findall('./properties/property')}) for x in xml.findall('.//testcase')])
 else:
  lines=[json.loads(x) for x in (folder/'stdout.log').read_text(encoding='utf-8-sig').splitlines() if x.strip()]
  result=lines[0] if len(lines)==1 else dict(status='PASS',reports=lines)
  if name=='mtp':assert result['generated_tokens']==64 and result['live_committed_versions']==0
  else:assert all(x.get('status','').startswith('PASS') for x in lines)
 save(folder/'report.json',result);print('PASS',name,flush=True)

if __name__=='__main__':
 action=sys.argv[1]
 if action=='prepare':prepare()
 elif action=='compile':compile_group(sys.argv[2],sys.argv[3:])
 elif action=='link':link(sys.argv[2],sys.argv[3])
 elif action=='run':run(sys.argv[2],sys.argv[3])
 else:raise ValueError(action)
