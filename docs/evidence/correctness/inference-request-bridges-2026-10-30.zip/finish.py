from pathlib import Path
import json,zipfile
W=Path(__file__).resolve().parent;R=W.parents[1]
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
s=read(W/'summary-draft.json');assert s['status']=='FINITE_CHECKS_PASSED' and len(s['checks'])==6
s['cleanup']=read(W/'cleanup-report.json')
s['limits'].append('Joint review identified a separate missing finite check for GLM K1 observer failure inside the common driver; follow-up keeps original native owners and unpublished candidate only.')
text=json.dumps(s,ensure_ascii=False,indent=2)+'\n'
(W/'summary.json').write_bytes(text.encode())
dest=R/'docs/evidence/correctness';(dest/'inference-request-bridges-2026-10-30.json').write_bytes(text.encode())
with zipfile.ZipFile(dest/'inference-request-bridges-2026-10-30.zip','w',compression=zipfile.ZIP_DEFLATED) as out:
 with zipfile.ZipFile(W/'evidence-draft.zip') as prev:
  for item in prev.infolist():out.writestr(item,prev.read(item.filename))
 for name in ['summary.json','finish.py','cleanup.ps1','cleanup-targets.json','cleanup-report.json']:out.write(W/name,name)
print('Archived six finite checks and exact cleanup receipt')
