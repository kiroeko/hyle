"""Collect only existing finite runs; never build, run native code, or download."""
from pathlib import Path
import hashlib,json,re,subprocess,zipfile

W=Path(__file__).resolve().parent
R=W.parents[1]
def read(path):return json.loads(Path(path).read_text(encoding='utf-8-sig'))
def save(path,value):
 path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
 path.write_text(json.dumps(value,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
def pin(path):
 path=Path(path).resolve();b=path.read_bytes()
 return dict(path=str(path),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def exact(item):assert pin(item['path'])==item,item['path']
def stable(value):
 if isinstance(value,dict):return {k:stable(v) for k,v in value.items() if not k.endswith('_seconds') and not k.endswith('_per_second')}
 if isinstance(value,list):return [stable(x) for x in value]
 return value
def parse_values(text):
 decoder=json.JSONDecoder();offset=0;values=[]
 while offset<len(text):
  while offset<len(text) and text[offset].isspace():offset+=1
  if offset==len(text):break
  value,offset=decoder.raw_decode(text,offset);values.append(value)
 return values

plan=read(W/'plan.json')
natural=W/'runs/natural-cuda/attempt1'
if not (natural/'report.json').exists():
 process=read(natural/'process.json')
 assert process['state']=='TERMINAL' and process['exit']==0 and not process['timed_out']
 reports=parse_values((natural/'stdout.log').read_text(encoding='utf-8-sig'))
 assert reports and all(x.get('status','').startswith('PASS') for x in reports)
 save(natural/'report.json',reports[0] if len(reports)==1 else dict(status='PASS',reports=reports))
 save(natural/'postprocess.json',dict(status='PASS',native_rerun=False,input=pin(natural/'stdout.log'),
  method='JSONDecoder.raw_decode consumes consecutive complete JSON values, allowing multiline JSON; same PASS assertion.',
  original_postprocess_failure='build.py split stdout by line and json.loads failed at line1 column24650. Original native exit0 and logs preserved.',
  report=pin(natural/'report.json'),process=process))

cases=['control-cpu','history-cuda','natural-cuda','mtp','greedy-cuda','request-cuda']
checks=[];pending=[]
for name in cases:
 folder=W/'runs'/name/'attempt1'
 if not (folder/'report.json').exists():pending.append(name);continue
 process=read(folder/'process.json');data=read(folder/'report.json')
 assert process['state']=='TERMINAL' and process['exit']==0 and not process['timed_out'],name
 if name=='mtp':assert data['generated_tokens']==64 and data['live_committed_versions']==0
 else:assert data.get('status','').startswith('PASS'),name
 checks.append(dict(name=name,attempt='attempt1',report=pin(folder/'report.json'),
  command=pin(folder/'command.json'),image=read(folder/'image.json'),process=process))

old_mtp=R/'.scratch/inference-publication-boundary-20261030/runs/mtp/attempt1/report.json'
assert stable(read(old_mtp))==stable(read(W/'runs/mtp/attempt1/report.json'))
comparisons=dict(real_K1_all_non_timing_fields_equal=True,real_K1_previous=pin(old_mtp),
 normalization='Recursive exclusion of keys ending _seconds or _per_second, identical to prior finish.py; no other omissions.',glm={})
previous_mtp=read(old_mtp);actual_mtp=read(W/'runs/mtp/attempt1/report.json')
timing_diagnostic={k:dict(previous=previous_mtp[k],current=actual_mtp[k]) for k in
 ('prefill_seconds','decode_seconds','decode_output_tokens_per_second','output_tokens_per_second')}
timing_diagnostic['scope']='Single nonconcurrent diagnostic process against preceding finite check; no performance window, regression causality, or speedup claim.'
for name in ('greedy-cuda','request-cuda'):
 current=W/'runs'/name/'attempt1/report.json'
 if not current.exists():continue
 # Most recent matching validated consumer for each original scenario.
 previous=R/'.scratch'/('inference-publication-boundary-20261030' if name=='greedy-cuda' else 'inference-glm-math-boundary-20261030')/'runs'/name/'attempt1/report.json'
 actual=read(current)['cases'][0]['properties'];expected=read(previous)['cases'][0]['properties']
 assert actual==expected,(name,{k:(expected.get(k),actual.get(k)) for k in expected.keys()|actual.keys() if expected.get(k)!=actual.get(k)})
 comparisons['glm'][name]=dict(equal=True,properties=len(actual),previous=pin(previous))

receipts={}
for name in ('cli','tiny','glm'):
 path=W/'compile'/name/'receipt.json';receipt=read(path)
 for item in [receipt['object'],*receipt['source_identities']]:exact(item)
 exact(receipt['process']);compile_process=read(receipt['process']['path'])
 assert compile_process['state']=='TERMINAL' and compile_process['exit']==0
 receipts[name]=dict(receipt=pin(path),object=receipt['object'],dependencies=receipt['dependencies'],
  compile_process=compile_process,link_process=read(W/'link'/name/'attempt1/process.json'))
for item in plan['retained']:exact(item)
base=read(plan['base']['path']);base['base']=plan['base']
base['compile']=plan['consumers']['cli']['compile']
cli_link=read(W/'link/cli/attempt1/command.json')
base['link']=cli_link if isinstance(cli_link,list) else cli_link['command']
for name,value in list(base.get('current_consumers',{}).items()):
 if name in receipts:continue
 previous_receipt=read(value['receipt']['path']);current=True
 for identity in previous_receipt['source_identities']:
  try:exact(identity)
  except (AssertionError,FileNotFoundError):current=False;break
 if not current:
  # Preserve any older historical identity instead of silently replacing it.
  historical=base.setdefault('historical_consumers',{})
  if name in historical and historical[name]!=value:historical[name+'-previous']=historical[name]
  historical[name]=base['current_consumers'].pop(name)
base['current_consumers'].update({name:dict(receipt=value['receipt'],object=value['object']) for name,value in receipts.items()})
base['note']='Current request-bridge CLI/tiny/GLM source-pinned consumers and unchanged227 retained SDK inputs. Other main-including consumers are historical. No independent performance experiment.'
save(W/'model-link-base.json',base)
sources=['engine/models/qwen35/main.cc','tests/tools/qwen_history_control_case.h','tests/tools/qwen_history_replay_case.h','tests/compute_models/glm_pro_mtp_state_consumer_test.cc']
main=(R/sources[0]).read_text(encoding='utf-8');start=main.index('class Model final {');stop=main.index('\n};\n\n} // namespace qwen35',start)
model=main[start:stop]
model_without_comments=re.sub(r'//[^\n]*|/\*[\s\S]*?\*/','',model)
for term in ('GenerationLedger','GenerationCommitRecord','records','committed_count'):
 assert not re.search(r'\b'+term+r'\b',model_without_comments),term
(W/'source-change.patch').write_bytes(subprocess.check_output(['git','diff','--binary','--',*sources],cwd=R))
summary=dict(schema='hyle.inference-request-bridges.v1',date='2026-10-30',base_commit=plan['base_commit'],
 status='FINITE_CHECKS_PASSED' if not pending else 'CHECKS_IN_PROGRESS',pending=pending,
 implementation=[
  'Sampling identity and authoritative history-count input assembly are request-side free helpers; original ownership checks, condition RAII, pool allocation/write/publication order are retained.',
  'Actual GLM RequestLoop K1 candidate uses the same static drive_steps synchronous branch: preflight in prepare, original verification mathematics in submit, scenario observation in finish. Original Head/publication, acceptance, repair, StateVersion and RNG remain with their existing owners.',
  'Failure recovery drains only actual original in-flight GLM programs and clears unpublished candidate/emitted data only after actual retirement. No new execution owner, resource ledger, callback table or public structure layout.'],
 sources=[pin(R/x) for x in sources],checks=checks,comparisons=comparisons,timing_diagnostic=timing_diagnostic,consumers=receipts,
 model_link_base=pin(W/'model-link-base.json'),
 source_audit=dict(Model_request_ledger_terms=0),
 build=dict(consumer_translation_units=3,retained_sdk_inputs=len(plan['retained']),SDK_CXX=0,NVCC=0,downloads=0,
  max_compiler_concurrency=2,compiled_previous_session=['cli','tiny'],compiled_resumed_session=['glm'],
  missing_cached_dependency_records=len(plan['missing_cached_dependency_records']),
  missing_dependency_scope='Unchanged native kernel/library inputs; affected engine CXX consumer includes checked separately.'),
 corrected_attempts=[dict(kind='postprocess',case='natural-cuda',attempt='attempt1',native_exit=0,native_rerun=False,
  reason='Original line-wise JSON parser rejected multiline output; separately parsed original complete JSON and applied original PASS checks.',
  receipt=pin(natural/'postprocess.json'))],
 limits=[
  'These six finite checks validate this pending slice only; common execution architecture still requires joint review, and the complete goal remains active.',
  'No independent performance candidate, profiler or complete cross-engine speed/memory window was run. Timings are diagnostic observations only.',
  'GLM remains a finite target77/NextN78 original component, not complete GLM inference, cross-pump GLM or a second complete engine model.',
  'Other artifacts/platforms, Apple/Vulkan, complete hybrid, multi-GPU and multi-machine were not run; no model quality claim.'])
if (W/'hardware.json').exists():summary['environment']=read(W/'hardware.json')
save(W/'summary-draft.json',summary)
with zipfile.ZipFile(W/'evidence-draft.zip','w',compression=zipfile.ZIP_DEFLATED) as archive:
 for name in ('build.py','collect.py','plan.json','summary-draft.json','source-change.patch','hardware.json','model-link-base.json'):
  if (W/name).exists():archive.write(W/name,name)
 for path in W.rglob('*'):
  if path.is_file() and path.parts[len(W.parts)] in ('compile','link','runs') and path.suffix in ('.json','.log','.xml'):
   archive.write(path,str(path.relative_to(W)))
print(json.dumps(dict(status=summary['status'],checks=len(checks),pending=pending,comparisons=comparisons),ensure_ascii=False))
