"""Q32 one actual frontier -> fixed budget batch; no HTTP in this adapter."""
import argparse
import importlib.util
import json
from pathlib import Path
import subprocess
import sys
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent;R=S.parents[1]

def source():
    spec=importlib.util.spec_from_file_location('_q32_actual_frontier_supply',S/'fetch_experts.py')
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);return module

def frontier(path):
    raw=path.read_bytes()
    if not 0<len(raw)<=65536:raise ValueError('Q32 frontier must be bounded metadata')
    request=json.loads(raw)
    section=request['section'];stage=request['stage']
    if section not in ('nextn','target43','target44') or type(stage) is not int or stage!=0:
        raise ValueError('Q32 actual source section/stage differs')
    ids,globals_=request['missing_ids'],request['global_ids']
    for values in (ids,globals_):
        if (not isinstance(values,list) or not 1<=len(values)<=8 or
            any(type(i) is not int or not 0<=i<288 for i in values) or values!=sorted(set(values))):
            raise ValueError('Q32 requires sorted unique actual1..8 IDs in original288 domain')
    if not set(ids)<=set(globals_):raise ValueError('Q32 missing IDs are outside the actual route')
    return section,ids

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--frontier-file',type=Path,required=True)
    parser.add_argument('--plan-only',action='store_true')
    args=parser.parse_args();section,ids=frontier(args.frontier_file)
    fetch=source();plan_path,plan,layer=fetch.checked(section)
    # The immutable source-plan and original header checks precede any batch.
    for global_id in ids:fetch.plan_id(plan_path,plan,layer,section,global_id)
    if args.plan_only:
        print(json.dumps(dict(section=section,stage=0,global_ids=ids,roles=9*len(ids),
            maximum_body_bytes=fetch.BODY*len(ids),typed_catalog_bytes_per_id=208,
            source_plan=fetch.a.identity(plan_path),network_requests=0)));return 0
    prefix=section+'-experts-'+ '-'.join(map(str,ids));attempt=1
    while True:
        batch=S/'frontier-plans'/(prefix+'-attempt'+str(attempt)+'.json')
        output=S/'batches'/(prefix+'-attempt'+str(attempt))
        if not batch.exists() and not output.exists():break
        attempt+=1
    command=[sys.executable,str(S/'fetch_experts.py'),'--section',section,'--ids',*map(str,ids),
        '--attempt',str(attempt),'--write-batch-plan',str(batch)]
    subprocess.run(command,cwd=R,check=True)
    frozen=fetch.a.read(batch)
    if frozen['script_sha256']!=fetch.a.identity(S/'fetch_experts.py')['sha256']:
        raise RuntimeError('Q32 body script changed after its fixed batch was prepared')
    # run_batch owns temporary enable/restore of the existing global budget.
    # A failed native run is restarted explicitly; completed intervals/ready
    # files are retained and the next batch has a fresh attempt directory.
    return subprocess.run([sys.executable,str(R/'.scratch/mtp-download-budget-20261023/run_batch.py'),str(batch)],cwd=R).returncode

if __name__=='__main__':sys.exit(main())
