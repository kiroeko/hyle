#pragma once
#include <string_view>
// Generated only after actual static41 complete acquisition. No synthetic payload pins.
namespace glm_mlx_original_artifacts {
inline constexpr std::string_view kRepository="mlx-community/GLM-5.3-Flash-4bit";
inline constexpr std::string_view kRevision="fa04cbc3622b16aa7475404060b05e506d81bd4e";
inline constexpr std::string_view kStaticCatalogueSha256="3f4dbe6d9f2c73cc4798040bc413c373346ba38b877641ab2dfa7a9c06cbace8";
inline constexpr std::string_view kStaticPlanSha256="c1d5a8329eb8f0c7bac7c6361e18a7bd539f62f0b689bf2e151ec6795b42ad50";
inline constexpr std::string_view kExpertSourcePlanSha256="f227abca1b6af48d98a01210ff6afbe050aac89e1e02143885a39347a7a82a8b";
inline constexpr std::string_view kStaticAcquisitionSha256="696258106811fa4d7d0e7cb4564c36e809afdb42f0ef31c306f29c0aea87ed9c";
} // namespace glm_mlx_original_artifacts
