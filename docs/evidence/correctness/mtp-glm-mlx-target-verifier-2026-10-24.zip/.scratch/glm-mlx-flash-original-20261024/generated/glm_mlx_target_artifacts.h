#pragma once
#include <string_view>
// Actual static75+distinct globalnorm1. Original Q32 vocabulary is reused from NextN41.
namespace glm_mlx_target_artifacts {
inline constexpr std::string_view kRepository="mlx-community/GLM-5.3-Flash-4bit";
inline constexpr std::string_view kRevision="fa04cbc3622b16aa7475404060b05e506d81bd4e";
inline constexpr std::string_view kTargetStaticCatalogueSha256="1779b35ecb155bc9591b79d5c35fd9ccc55e2d7f22ca5a61311640df9a5ef134";
inline constexpr std::string_view kTargetStaticPlanSha256="e086b197dfca9941993f269acea3d5ea6e33e04662b691d18c139afdfee24135";
inline constexpr std::string_view kTargetExpertSourcePlanSha256="0e554f336ae1ab9de3b91f4d0541fbf26ad13896560e8343734c86928fa8a6d1";
inline constexpr std::string_view kTargetAcquisitionSha256="cfb633addf3a3db1f52b18bbb7cd9f242265c3d7227504cba389d74c8ef1ec48";
} // namespace glm_mlx_target_artifacts
