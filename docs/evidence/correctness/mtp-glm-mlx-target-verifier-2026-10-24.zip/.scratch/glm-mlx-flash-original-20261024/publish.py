"""Publish only actual Q32 CPU/CUDA finite passes; no fetch, build, native or body hash."""
import argparse
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
import xml.etree.ElementTree as ET
import zipfile

sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
R = S.parents[1]
N = S / 'native-current'
D = R / 'docs/evidence/correctness'
ARCHIVE = R / '.scratch/glm-quark-selected-20261024/Q30/publish.py'
ARCHIVE_SHA = 'aff6d102813826e91729249d0ff6cea1ec6fe45c030abbeb99980f0ff0a2cda5'
REPO, REV = 'mlx-community/GLM-5.3-Flash-4bit', 'fa04cbc3622b16aa7475404060b05e506d81bd4e'

def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec); spec.loader.exec_module(module); return module

def read(path): return json.loads(Path(path).read_text(encoding='utf-8-sig'))
def resolve(path): return (Path(path) if Path(path).is_absolute() else R / path).resolve()
def identity(path):
    path = resolve(path)
    if path.stat().st_size > 16_777_216: raise ValueError('Only small source/metadata may be hashed')
    raw = path.read_bytes()
    return dict(path=path.relative_to(R).as_posix(), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())
def require(info):
    got = identity(info['path'])
    if any(got[k] != info[k] for k in ('bytes', 'sha256')): raise ValueError('Recorded source/metadata changed: ' + info['path'])
def extent(info):
    if resolve(info['path']).stat().st_size != info['bytes'] or len(info['sha256']) != 64:
        raise ValueError('Actual body/image/object extent differs')

def static(archive):
    build = load('_q32_publish_actual_entry', S / 'current-native-proposal/build.py')
    inputs = build.Adapter().artifacts(build.HEADERS[0])
    for info in inputs: require(info); archive.add(resolve(info['path']))
    for plan_path in [S / 'static-plan.json', S / 'target-metadata/static-plan.json']:
        for shard in read(plan_path)['shards']:
            require(shard['header']); archive.add(resolve(shard['header']['path']))
    sets = []
    for directory, generator_name, count, size in [('original-static', 'generate_pins.py', 41, 2732636800),
            ('original-target-static', 'generate_target_pins.py', 76, 429408944)]:
        generator = load('_q32_publish_' + directory.replace('-', '_'), S / 'proposal' / generator_name)
        generator.validate(S / directory)  # Existing complete receipt/catalog/range checks; no body rehash.
        receipt = read(S / directory / 'acquisition.json')
        extent(receipt['bundle']); archive.metadata_tree(S / directory); archive.add(S / directory / 'catalog.bin')
        sets.append(dict(roles=count, bytes=size, acquisition=identity(S / directory / 'acquisition.json'),
            typed_catalog=receipt['typed_catalog'], bundle=receipt['bundle']))
    return inputs, dict(roles=117, source_bytes=3162045744, sets=sets, weight_bodies_rehashed=False)

def completed(backend, attempt, ready, archive):
    folder = N / f'checks{attempt}-{backend}'
    summary, plan, process = (read(folder / name) for name in ('summary.json', 'plan.json', 'run/process.json'))
    if summary.get('passed') is not True or process != summary['process'] or process['exit'] != 0 or process['timed_out']:
        raise ValueError('Q32 run must be an actual successful terminal process')
    case_name = 'GlmMtpStateConsumer.' + backend.title() + 'MlxOriginalTarget43And44AndNextNFullVocabularyVerifier'
    tree = ET.parse(folder / 'results.xml').getroot(); cases = list(tree.iter('testcase'))
    if len(cases) != 1 or list(tree.iter('failure')) or list(tree.iter('skipped')) or any(int(tree.get(k, '0')) for k in ('failures', 'errors', 'disabled')):
        raise ValueError('Exactly one actual passing unskipped Q32 case required')
    case = cases[0]; props = {p.get('name'): p.get('value') for p in case.iter('property')}
    if case.get('classname') + '.' + case.get('name') != case_name or case.get('status') != 'run' or case.get('result') != 'completed':
        raise ValueError('Wrong or unexecuted actual Q32 case')
    if summary['case'] != case_name or summary['properties'] != props or (summary['tests'], summary['failures'], summary['skips']) != (1, 0, 0):
        raise ValueError('Actual summary/XML facts differ')
    expected = dict(artifact_repository=REPO, artifact_revision=REV, static_original_roles='117', static_original_bytes='3162045744',
        expert_domain='288', resident_experts='8', expert_planes='9', component_resources='32', nextn_resources='16', target43_resources='12')
    if any(props.get(k) != v for k, v in expected.items()): raise ValueError('Actual Q32 source/state/plane identity differs')
    if int(props['actual_submissions']) <= 0 or summary['actual_graph_submissions'] != int(props['actual_submissions']): raise ValueError('Missing actual Graph count')
    if int(props['actual_selected_original_bytes']) != 15204352 * int(props['actual_selected_original_experts']): raise ValueError('Actual nine-plane payload count differs')
    if int(props['peak_state_backing_bytes']) > int(props['state_budget_bytes']): raise ValueError('State budget exceeded')
    for k in ('image', 'consumer_record'):
        if summary[k] != ready[k] or plan[k] != ready[k]: raise ValueError('Run/image/compiled source differs')
    if plan['actual_artifact_inputs'] != ready['actual_artifact_inputs'] or summary['actual_artifact_inputs'] != ready['actual_artifact_inputs']:
        raise ValueError('Run actual pins differ')
    driver = None
    if not plan['cached_only']:
        driver = read(folder / 'frontier.driver.json')
        if driver.get('exit') != 0 or driver['native'].get('exit') != 0 or driver['native'].get('stopped_by_driver') or driver.get('error'):
            raise ValueError('Owned native/supply driver failed')
        if driver['job_cleanup']['remaining_descendants'] or any(p['exit'] or p.get('stopped_by_driver') for p in driver['fetches']): raise ValueError('Owned tree did not retire successfully')
        if resolve(driver['native']['command'][0]) != resolve(ready['image']['path']) or '--gtest_filter=' + case_name not in driver['native']['command']:
            raise ValueError('Owned command differs from checked case')
    archive.metadata_tree(folder)
    return dict(backend=backend.upper(), case=case_name, graph_submissions=int(props['actual_submissions']), properties=props,
        image=ready['image'], summary=identity(folder / 'summary.json'), XML=identity(folder / 'results.xml'),
        process=identity(folder / 'run/process.json'), cached_only=plan['cached_only'],
        driver=identity(folder / 'frontier.driver.json') if driver else None), driver

def experts(drivers, archive):
    fetch = load('_q32_publish_original_experts', S / 'fetch_experts.py'); cached = {}; requests = []
    for driver in drivers:
        if driver:
            for item in driver['fetches']:
                request = item['request']; section = request['section']
                if section not in fetch.EXPERTS or request['stage'] != 0 or not set(request['missing_ids']) <= set(request['global_ids']) or any(type(i) is not int or not 0 <= i < 288 for i in request['global_ids']):
                    raise ValueError('Q32 actual frontier differs')
                requests.append(request)
    for path in sorted((S / 'original-experts').glob('*/stage0/expert*/ready.json')):
        ready = read(path); section = ready['section']; ids = ready['global_ids']; directory = path.parent
        if not ready.get('complete') or (ready['repository'], ready['revision'], ready['stage']) != (REPO, REV, 0) or len(ids) != 1 or not 0 <= ids[0] < 288:
            raise ValueError('Incomplete/mismatched own Q32 expert set')
        source_path, source, layer = fetch.checked(section); expected = fetch.plan_id(source_path, source, layer, section, ids[0])
        plan = read(directory / 'plan.json'); receipt = read(directory / 'acquisition.json')
        if plan != expected or ready['source_plan_sha256'] != identity(source_path)['sha256'] or resolve(ready['directory']) != directory.resolve(): raise ValueError('Expert original nine-plane range plan differs')
        if receipt.get('complete') is not True or receipt['original_roles'] != 9 or receipt['role_payload_bytes'] != 15204352 or receipt['source_plan_sha256'] != identity(directory / 'plan.json')['sha256']:
            raise ValueError('Actual expert acquisition incomplete')
        fetch.a.check_catalog(receipt, plan, directory); require(ready['acquisition']); extent(receipt['bundle'])
        if ready['bundle'] != receipt['bundle'] or ready['typed_catalog']['sha256'] != identity(directory / 'catalog.bin')['sha256']: raise ValueError('Expert actual catalog/body pins differ')
        archive.metadata_tree(directory); archive.add(directory / 'catalog.bin')
        cached[(section, ids[0])] = dict(section=section, global_id=ids[0], source_bytes=15204352, ready=identity(path), acquisition=identity(directory / 'acquisition.json'), bundle=receipt['bundle'])
    if any((p['section'], i) not in cached for p in requests for i in p['missing_ids']): raise ValueError('Actual successful frontier lacks its completed own artifact cache')
    archive.metadata_tree(S / 'original-experts')  # Keep failed transport metadata, never roles.bin.
    return dict(complete_cached_sets=list(cached.values()), actual_missing_frontiers=requests,
        cached_payload_bytes=15204352 * len(cached), sections=['nextn', 'target43', 'target44'], planes_per_id=9,
        accounting='Cache totals may include failed-attempt frontiers; successful active-ID counts are native properties, preserved verbatim.', weight_bodies_rehashed=False)

def main():
    p = argparse.ArgumentParser(description=__doc__)
    for arg in ('cpu-run', 'cuda-run'): p.add_argument('--' + arg, type=int, required=True)
    p.add_argument('--link-attempt', type=int)
    p.add_argument('--cpu-link-attempt', type=int); p.add_argument('--cuda-link-attempt', type=int)
    p.add_argument('--source-root', type=Path, action='append', default=[]); args = p.parse_args()
    link_attempts = dict(cpu=args.cpu_link_attempt or args.link_attempt, cuda=args.cuda_link_attempt or args.link_attempt)
    if any(x is None or x <= 0 for x in [args.cpu_run, args.cuda_run, *link_attempts.values()]): raise ValueError('Positive actual run/link attempts required')
    if identity(ARCHIVE)['sha256'] != ARCHIVE_SHA: raise ValueError('Existing small Archive helper changed')
    tools = load('_q32_existing_archive', ARCHIVE); tools.S = S
    archive = tools.Archive([x.resolve() for x in args.source_root]); archive.add(Path(__file__)); archive.add(ARCHIVE)
    inputs, original = static(archive)
    executions, drivers, linked_builds = [], [], []
    shared_proofs = []
    for name in ['mtp-packed-mmq-workspace-2026-10-24', 'mtp-packed-mmvq-tail-integration-2026-10-24']:
        proof = D / (name + '.json'); archive.add(proof); shared_proofs.append(identity(proof))
    consumer_records = []
    for backend, attempt in [('cpu', args.cpu_run), ('cuda', args.cuda_run)]:
        image_dir = N / f'tests-link{link_attempts[backend]}'
        ready = read(image_dir / 'ready.json'); link = read(image_dir / 'link-plan.json')
        if ready['artifact'] != 'Q32' or ready['actual_artifact_inputs'] != inputs: raise ValueError('Actual linked Q32 pins differ')
        for k in ('link_plan', 'runtime_environment', 'consumer_record'): require(ready[k]); archive.add(resolve(ready[k]['path']))
        extent(ready['image']); compiled_path = resolve(ready['consumer_record']['path']); compiled = read(compiled_path)
        linked_process = read(image_dir / 'link.result.json')
        if linked_process['exit'] != 0 or linked_process['command'] != link['command']: raise ValueError('Actual link did not complete successfully')
        compile_process = read(compiled_path.parent / 'compile.result.json')
        if compile_process['exit'] != 0 or compile_process['command'] != compiled['command']: raise ValueError('Actual selected consumer compile failed')
        if compiled['artifact'] != 'Q32' or compiled['artifact_inputs'] != inputs: raise ValueError('Actual compiled pins differ')
        consumer_records.append(ready['consumer_record'])
        for info in [compiled['source'], *compiled['dependencies']]: archive.source(info, compiled_path)
        archive.metadata_tree(compiled_path.parent); archive.metadata_tree(image_dir)
        for info in link['retained_current_records']:
            require(info); archive.add(resolve(info['path']))  # Retained record/hash; shared proof owns the product source closure.
        require(link['native_inputs']); archive.add(resolve(link['native_inputs']['path']))
        execution, driver = completed(backend, attempt, ready, archive); executions.append(execution); drivers.append(driver)
        linked_builds.append(dict(backend=backend.upper(), ready=identity(image_dir / 'ready.json'), consumer_record=ready['consumer_record'],
            link_plan=ready['link_plan'], runtime=ready['runtime_environment'], image=ready['image'],
            retained_host_records=len(link['retained_current_records']), native_inputs=link['native_inputs']))
    if consumer_records[0] != consumer_records[1]: raise ValueError('Selected CPU/CUDA links must share their actual compiled Q32 consumer')
    selected = experts(drivers, archive); history = []
    for folder in sorted(N.glob('checks*-*')):
        archive.metadata_tree(folder); summary = folder / 'summary.json'
        if summary.is_file():
            prior = read(summary); history.append(dict(summary=identity(summary), passed=prior.get('passed')))
            if prior.get('consumer_record'):
                require(prior['consumer_record']); archive.add(resolve(prior['consumer_record']['path']))
    corrections = []
    for folder in sorted(S.glob('cold-admission-fix*')):
        applied = folder / 'applied.json'
        if applied.is_file():
            corrections.append(identity(applied)); archive.add(applied); archive.add(folder / 'source.patch')
            for before_header in (folder / 'before').rglob('*.h'): archive.add(before_header)
    for filename in ['acquire.py', 'fetch_experts.py', 'supply_experts.py', 'run_with_supply.py', 'proposal/generate_pins.py', 'proposal/generate_target_pins.py', 'current-native-proposal/build.py']:
        archive.add(S / filename)
    for folder in ['batches', 'frontier-plans']: archive.metadata_tree(S / folder)
    chains = R / '.scratch/mtp-download-budget-20261023/static-umbrella-20261024/batches'
    for chain in sorted(chains.glob('attempt*/children/Q32')):
        archive.metadata_tree(chain)  # Actual successful/failed own static children, no other artifact payloads.
    destination = D / 'mtp-glm-mlx-target-verifier-2026-10-24.json'; output = destination.with_suffix('.zip')
    if destination.exists() or output.exists(): raise ValueError('Never overwrite published evidence')
    record = dict(created_at=datetime.now(timezone.utc).isoformat(), identity=dict(id='Q32', repository=REPO, revision=REV),
        status='Completed finite own MLX target43/44 + NextN45 CPU/CUDA K1 execution',
        validation=dict(cases=2, failures=0, skips=0, graph_submissions=sum(x['graph_submissions'] for x in executions), executions=executions),
        original_static=original, selected_experts=selected, attempt_history=history, corrections=corrections,
        build=dict(consumer_record=consumer_records[0], executions=linked_builds, shared_runtime_evidence=shared_proofs,
            link_identity_note='CPU and CUDA retain their own actual image/runtime/closure; a later closure is never attributed to an earlier run.',
            fresh_consumer_TUs=1, fresh_product_TUs=0, SDK_builds=0, NVCC_builds=0, compiled_source_manifest=list(archive.sources.values())),
        scope='Own original U32 affine planes and F16 scales/biases, original BF16 head, explicit F32 activation/hidden/raw pool/journal state; same 16 NextN +12 target43 +4 target44 resources and Epoch/K1.',
        limits=['Upstream layer42 and initial histories are fixtures, not a whole trained engine.', 'No model quality, natural acceptance-rate, TPS, physical peak-memory or all-platform claim.'],
        whole_original_model=False, throughput_evidence=False, memory_evidence=False, weight_bodies_rehashed=False, scope_or_progress_updated=False)
    if sum(path.stat().st_size for path in archive.files.values()) > 67_108_864: raise ValueError('Archive exceeds the existing finite small evidence bound')
    with zipfile.ZipFile(output, 'x', zipfile.ZIP_DEFLATED, compresslevel=6) as z:
        for name, path in sorted(archive.files.items()): z.write(path, name)
        z.writestr('compiled-source-manifest.json', json.dumps(list(archive.sources.values()), indent=2) + '\n')
    record.update(archive=identity(output), archived_files=len(archive.files) + 1)
    destination.write_text(json.dumps(record, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(dict(evidence=identity(destination), archive=identity(output), graphs=record['validation']['graph_submissions'])))

if __name__ == '__main__': main()
