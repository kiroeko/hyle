"""Explicit Q32 actual-ID nine-plane cache; never a complete expert bank.

Only root's budget/run_batch may perform HTTP. Requests use the existing
unchanged exact206/ETag/resume bundle downloader (three IDs, one worker/ID).
"""
import argparse
from concurrent.futures import ThreadPoolExecutor,as_completed
import hashlib,importlib.util,json
from pathlib import Path
import sys
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent;R=S.parents[1]
assert hashlib.sha256((S/'acquire.py').read_bytes()).hexdigest()=='c0320b4f37434952c48b95942a1538e14eaade073045c64d6b5f12e1bc6ce8ee'
spec=importlib.util.spec_from_file_location('_q32_static_support',S/'acquire.py');a=importlib.util.module_from_spec(spec);spec.loader.exec_module(a)
EXPERTS={
 'nextn':('expert-source-plan.json','f227abca1b6af48d98a01210ff6afbe050aac89e1e02143885a39347a7a82a8b',45),
 'target43':('target-metadata/expert-source-plan.json','0e554f336ae1ab9de3b91f4d0541fbf26ad13896560e8343734c86928fa8a6d1',43),
 'target44':('target-metadata/expert-source-plan.json','0e554f336ae1ab9de3b91f4d0541fbf26ad13896560e8343734c86928fa8a6d1',44),
}
BODY=15204352
def save(path,value):
 path.parent.mkdir(parents=True,exist_ok=True);tmp=path.with_name(path.name+'.next')
 with tmp.open('w',encoding='utf-8',newline='\n')as f:json.dump(value,f,indent=2);f.write('\n');f.flush();__import__('os').fsync(f.fileno())
 import os,time
 for retry in range(50):
  try:os.replace(tmp,path);return
  except PermissionError:
   if retry==49:raise
   time.sleep(.02)
def checked(section):
 file,pin,layer=EXPERTS[section];path=S/file;assert a.identity(path)['sha256']==pin
 source=a.read(path);assert(source['repository'],source['revision'],source['domain'])==(a.REPO,a.REV,288)
 for s in source['shards']:assert a.identity(R/s['header']['path'])==s['header']
 assert(source.get('bytes_per_expert')==BODY)and(source.get('full_expert_banks_acquire',False)is False)
 return path,source,layer
def selected(args):
 if args.frontier_file:
  assert args.section is None and args.ids is None
  request=a.read(args.frontier_file);section,ids=request['section'],request['missing_ids'];assert type(request['stage'])is int and request['stage']==0
  globals_=request['global_ids'];assert globals_==sorted(set(globals_))and len(globals_)<=8
  assert all(type(i)is int and 0<=i<288 for i in globals_)and ids==sorted(set(ids))and set(ids)<=set(globals_)
 else:section,ids=args.section,args.ids
 assert section in EXPERTS and isinstance(ids,list)and len(ids)<=8 and all(type(i)is int and 0<=i<288 for i in ids)
 return section,sorted(set(ids))
def plan_id(path,source,layer,section,global_id):
 selected=[r for r in source['roles']if r['global_id']==global_id and r['name'].startswith(f'model.language_model.layers.{layer}.')]
 assert len(selected)==9
 rows=[];groups=[];offset=0
 for leg in ('gate','up','down'):
  for plane in ('weight','scales','biases'):
   row=dict(next(r for r in selected if r['leg']==leg and r['plane']==plane))
   i=len(rows);row.update(index=i,bundle_offset=offset)
   shard=source['shards'][row['source_shard']];original=a.read(R/shard['header']['path'])[row['name']]
   assert(row['dtype'],row['shape'],row['data_relative_half_open'])==(original['dtype'],original['shape'],original['data_offsets'])
   first,last=row['absolute_inclusive'];lo,hi=original['data_offsets'];assert first==shard['data_base']+lo and last==shard['data_base']+hi-1 and row['bytes']==hi-lo
   groups.append(dict(index=i,source_shard=row['source_shard'],first=first,last=last,bundle_offset=offset,bytes=row['bytes']))
   rows.append(row);offset+=row['bytes']
 assert offset==BODY
 return dict(repository=a.REPO,revision=a.REV,section=section,stage=0,global_ids=[global_id],original_roles=9,bundle_bytes=BODY,
  whole_shards_downloaded=False,unrequested_bytes=0,source_plan=a.identity(path),typed_order='gate/up/down each original weight/scales/biases',
  source_format='MLX_AFFINE_ORIGINAL_U32_F16_F16',shards=source['shards'],roles=rows,groups=groups)
def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--section',choices=tuple(EXPERTS));p.add_argument('--ids',type=int,nargs='+')
 p.add_argument('--frontier-file',type=Path);p.add_argument('--plan-only',action='store_true');p.add_argument('--write-batch-plan',type=Path);p.add_argument('--attempt',type=int,default=1)
 args=p.parse_args();assert not(args.plan_only and args.write_batch_plan)and args.attempt>0
 section,ids=selected(args);source_path,source,layer=checked(section)
 if args.write_batch_plan:
  assert ids,'Empty frontier needs no fetch batch';out=args.write_batch_plan.resolve();assert out.is_relative_to(S)
  for gid in ids:
   directory=S/'original-experts'/section/'stage0'/f'expert{gid:03d}'
   a.retain(directory/'plan.json',plan_id(source_path,source,layer,section,gid))
  batch=dict(script=a.identity(Path(__file__))['path'],script_sha256=a.identity(Path(__file__))['sha256'],
   arguments=['--section',section,'--ids',*map(str,ids)])
  # Build the directory separately; never let mutable frontier contents change
  # the actual IDs captured by an explicitly reviewed batch.
  batch['out']=(S/'batches'/f'{section}-experts-{"-".join(map(str,ids))}-attempt{args.attempt}').relative_to(R).as_posix()
  batch.update(need_evidence=a.identity(source_path),new_unique_body_bytes=BODY*len(ids),new_unique_body_bytes_is_upper_bound=True,
   whole_bank=False,whole_model=False,timeout_seconds=3600,maximum_http_request_bytes=a.REQUEST,stream_buffer_bytes=a.IO,
   outer_expert_workers=3,per_id_workers=1,maximum_http_streams=3)
  a.retain(out,batch);print(json.dumps(dict(batch_plan=a.identity(out),network_requests=0)));return
 if not args.plan_only:a.transport()
 fetch,locks=a.module('bundle'),a.module('lock')
 fetch.COUNT,fetch.BODY_BYTES,fetch.CHUNK,fetch.IO,fetch.WORKERS=9,BODY,a.REQUEST,a.IO,1
 def acquire(gid):
  directory=S/'original-experts'/section/'stage0'/f'expert{gid:03d}';directory.mkdir(parents=True,exist_ok=True)
  with locks.single_writer(directory/'.fetch.lock'):
   plan=plan_id(source_path,source,layer,section,gid);a.retain(directory/'plan.json',plan)
   if args.plan_only:return dict(global_id=gid,plan=a.identity(directory/'plan.json'),body_bytes=BODY,network_requests=0)
   record=fetch.main(plan_path=directory/'plan.json',out=directory);a.check_catalog(record,plan,directory)
   ready=dict(complete=True,repository=a.REPO,revision=a.REV,section=section,stage=0,global_ids=[gid],
    source_plan_sha256=a.identity(source_path)['sha256'],directory=directory.resolve().as_posix(),
    typed_catalog=dict(file='catalog.bin',bytes=208,sha256=record['typed_catalog']['sha256']),
    acquisition=a.identity(directory/'acquisition.json'),bundle=record['bundle'],per_id_workers=1,outer_expert_workers=3)
   save(directory/'ready.json',ready);return ready
 completed,errors=[],[]
 with ThreadPoolExecutor(max_workers=3)as pool:
  futures={pool.submit(acquire,gid):gid for gid in ids}
  for future in as_completed(futures):
   try:completed.append(future.result())
   except Exception as error:errors.append(dict(global_id=futures[future],type=type(error).__name__,error=str(error)))
 # No success/failure aggregate is emitted until every worker has terminated.
 result=dict(event='frontier_failed'if errors else'frontier_planned'if args.plan_only else'frontier_complete',
  complete=not args.plan_only and not errors,section=section,stage=0,global_ids=ids,caches=completed,errors=errors)
 print(json.dumps(result),flush=True)
 if errors:raise RuntimeError('Q32 actual selected9-plane acquisition failed: '+json.dumps(errors))
if __name__=='__main__':main()
