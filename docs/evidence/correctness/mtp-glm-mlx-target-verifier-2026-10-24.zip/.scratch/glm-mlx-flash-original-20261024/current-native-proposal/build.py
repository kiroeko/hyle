"""Q32 actual-source adapter to the existing one-consumer cold lifecycle.

Only root executes compile/link/run. The shared append linker retains its
historical output-slot names; the actual TU, two guards, pins and cases are MLX.
No model runner, supplier or downloader is implemented here.
"""
from pathlib import Path
import argparse
import json
import os
import sys
import xml.etree.ElementTree as ET

sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
DATA = S.parent
R = DATA.parents[1]
SHARED = R / '.scratch/qwen-gguf-selected-20261023/current-native-proposal/build_current.py'
SHARED_SHA = '59f66fc38ceecdc1b9b54a2535da32c16bbaed5b4419cd19827e4558b4320e0f'
import hashlib
if hashlib.sha256(SHARED.read_bytes()).hexdigest() != SHARED_SHA:
    raise ValueError('Frozen append-link utility changed')
import importlib.util
spec = importlib.util.spec_from_file_location('_q32_actual_flat_link', SHARED)
common = importlib.util.module_from_spec(spec); spec.loader.exec_module(common)
load, identity = common.load, common.identity
SOURCE = R / 'tests/compute_models/glm_mtp_state_consumer_test.cc'
RECIPE = R / '.scratch/glm-gguf-selected-20261023/flash-consumer-proposal/compile2/flash-state/identity.json'
HEADERS = [DATA / 'generated/glm_mlx_original_artifacts.h', DATA / 'generated/glm_mlx_target_artifacts.h']
MACROS = ['HYLE_TEST_GLM_MLX_NEXTN_ARTIFACTS_HEADER', 'HYLE_TEST_GLM_MLX_TARGET_ARTIFACTS_HEADER']
CASES = {backend: 'GlmMtpStateConsumer.' + backend.title() + 'MlxOriginalTarget43And44AndNextNFullVocabularyVerifier'
         for backend in ('cpu', 'cuda')}


def acquisition():
    value = load('_q32_actual_static_schema', DATA / 'acquire.py')
    for path, digest in value.HELPERS.values():
        if identity(R / path)['sha256'] != digest: raise ValueError('Frozen acquisition dependency changed: ' + path)
    for section in ('nextn', 'target'): value.checked(section)
    return value


class Adapter:
    ARTIFACT_TAG = 'Q32'
    S = DATA / 'native-current'
    HEADER = HEADERS[0]  # Existing link utility calls artifacts once; both headers are validated below.

    def artifacts(self, header):
        if Path(header).resolve() != self.HEADER.resolve(): raise ValueError('Wrong Q32 pin entry')
        supplied = load('_q32_existing_static_validator', DATA / 'run_with_supply.py')
        if supplied.actual_static() != dict(static_roles=117, source_bytes=3162045744, network_requests=0):
            raise ValueError('Actual117-role source differs')
        paths = [*HEADERS, *(path.with_suffix('.json') for path in HEADERS),
            DATA / 'acquire.py', DATA / 'proposal/generate_pins.py', DATA / 'proposal/generate_target_pins.py',
            DATA / 'static-plan.json', DATA / 'target-metadata/static-plan.json',
            DATA / 'expert-source-plan.json', DATA / 'target-metadata/expert-source-plan.json',
            DATA / 'run_with_supply.py', DATA / 'supply_experts.py', DATA / 'fetch_experts.py']
        for directory, count, size, header_path, generated_key in (
            (DATA / 'original-static', 41, 2732636800, HEADERS[0], 'generated'),
            (DATA / 'original-target-static', 76, 429408944, HEADERS[1], 'generated_header')):
            proof = json.loads(header_path.with_suffix('.json').read_text(encoding='utf-8-sig'))
            if proof.get('complete') is not True or proof.get('source_bytes') != size:
                raise ValueError('Generated Q32 receipt is incomplete')
            if proof.get('original_roles', proof.get('static_roles')) != count:
                raise ValueError('Generated Q32 role count differs')
            generator = load('_q32_proof_identity', DATA / ('proposal/generate_pins.py' if count == 41 else 'proposal/generate_target_pins.py'))
            if proof[generated_key] != generator.identity(header_path):
                raise ValueError('Generated header differs from its actual proof')
            paths += [directory / name for name in ('acquisition.json', 'catalog.json', 'catalog.bin')]
        return [identity(path) for path in paths]


def prepare(adapter, args):
    a = acquisition()
    actual = adapter.artifacts(adapter.HEADER) if all(path.is_file() for path in HEADERS) else None
    plans = [a.checked(section) for section in ('nextn', 'target')]
    return dict(prepared_only=True, entry=identity(__file__), shared_append_link=identity(SHARED),
        closure_helper=identity(args.closure_helper), source=identity(SOURCE), recipe=identity(RECIPE),
        static_roles=sum(len(plan['roles']) for _, plan, _ in plans), static_bytes=sum(plan['bundle_bytes'] for _, plan, _ in plans),
        repository=a.REPO, revision=a.REV, source_plans=[identity(path) for path, _, _ in plans],
        generated_headers=[str(path) for path in HEADERS], cases=CASES, macros=MACROS,
        actual_artifact_inputs=actual, blocked_pending_actual_body_pins=actual is None,
        expert_domain=288, resident_experts=8, planes_per_ID=9, bytes_per_ID=15204352,
        sections=['nextn', 'target43', 'target44'], consumer_translation_units=1,
        product_translation_units=0, SDK_builds=0, NVCC_builds=0, HTTP_requests=0,
        output_slot_note='Shared cold utility names its directory qwen-state and image qwen-gguf-checks.exe; actual source and case are the GLM Flash MLX TU, not a Qwen model.',
        scope='Own MLX affine/F16 metadata, BF16 original head and explicit F32 activations/states; upstream layer42 and initial histories remain fixtures. No whole-model quality/TPS claim.')


def compile_one(adapter, args):
    actual = adapter.artifacts(adapter.HEADER)
    c, _ = common.context(args)
    recipe = c.read(RECIPE)
    recipe['command'] = [arg for arg in recipe['command'] if not (arg.startswith('/DHYLE_TEST_GLM_') and 'ARTIFACTS_HEADER=' in arg)]
    for macro, header in zip(MACROS, HEADERS, strict=True):
        recipe['command'].insert(1, '/D' + macro + '="' + header.as_posix() + '"')
    if len([arg for arg in recipe['command'] if arg.startswith('/DHYLE_TEST_GLM_') and 'ARTIFACTS_HEADER=' in arg]) != 2:
        raise ValueError('Exactly the actual two MLX guards are required')
    prepared = adapter.S / f'prepared-recipe{args.attempt}.json'
    if prepared.exists(): raise ValueError('Preserve actual compile attempt')
    c.save(prepared, recipe)
    h = c.helpers(); h.S = adapter.S
    h.RECIPES, h.SOURCES = {'qwen-state': prepared}, {'qwen-state': SOURCE}
    h.compile_one('qwen-state', args.attempt)
    path = adapter.S / f'compile{args.attempt}/qwen-state/identity.json'
    record = c.check_record(path)
    for header in HEADERS:
        if not any(c.resolve(row['path']) == header.resolve() for row in record['dependencies']):
            raise ValueError('Actual compiler did not include both Q32 generated headers')
    record.update(artifact='Q32', artifact_inputs=actual, entry=identity(__file__),
        shared_append_link=identity(SHARED), closure_helper=identity(args.closure_helper),
        source_scope='Actual GLM Flash MLX TU; historical qwen-state is only the reused compile-output slot.',
        consumer_translation_units=1, product_translation_units=0, SDK_builds=0, NVCC_builds=0)
    c.save(path, record)


def run(adapter, args):
    actual = adapter.artifacts(adapter.HEADER); c, _ = common.context(args)
    image_dir = adapter.S / f'tests-link{args.link_attempt}'; ready = c.read(image_dir / 'ready.json')
    if ready['artifact'] != 'Q32' or ready['actual_artifact_inputs'] != actual: raise ValueError('Actual compiled Q32 pins differ')
    for key in ('image', 'link_plan', 'runtime_environment', 'consumer_record'): c.require(ready[key])
    c.check_record(c.resolve(ready['consumer_record']['path']))
    runtime = c.read(image_dir / 'runtime-environment.json')
    for row in runtime['staged_dlls']: c.require(row)
    out = adapter.S / f'checks{args.attempt}-{args.backend}'; out.mkdir(exist_ok=False)
    native = [ready['image']['path'], '--gtest_filter=' + CASES[args.backend], '--gtest_throw_on_failure=1',
              '--gtest_output=xml:' + str(out / 'results.xml')]
    env = {key: value for key, value in os.environ.items() if not key.startswith('HYLE_GLM_')}
    env.update(PATH=runtime['PATH'], OMP_NUM_THREADS='4', MKL_NUM_THREADS='4', OPENBLAS_NUM_THREADS='4',
        HYLE_GLM_MLX_NEXTN_DIR=str(DATA / 'original-static'), HYLE_GLM_MLX_TARGET_DIR=str(DATA / 'original-target-static'),
        HYLE_GLM_MLX_EXPERT_DIR=str(DATA / 'original-experts'), HYLE_GLM_MLX_FRONTIER_FILE=str(out / 'frontier.json'),
        HYLE_GLM_MLX_WAIT_FOR_EXPERTS='1' if args.supply else '0')
    command = native
    if args.supply:
        command = [sys.executable, str(DATA / 'run_with_supply.py'), '--image', native[0],
                   '--frontier-file', str(out / 'frontier.json'), '--', *native[1:]]
    c.save(out / 'plan.json', dict(command=command, native_command=native, case=CASES[args.backend],
        image=ready['image'], consumer_record=ready['consumer_record'], actual_artifact_inputs=actual,
        entry=identity(__file__), shared_append_link=identity(SHARED), closure_helper=identity(args.closure_helper),
        environment={key: value for key, value in env.items() if key == 'PATH' or key.startswith('HYLE_GLM_')},
        cached_only=not args.supply, automatic_supply=args.supply,
        driver=identity(DATA / 'run_with_supply.py') if args.supply else None))
    q = load('_q32_existing_process_runner', R / '.scratch/qwen-mtp-quality-20261022/run_quality.py')
    process = q.execute(command, env, out / 'run', timeout=args.timeout)
    result = dict(process=process, passed=False, image=ready['image'], consumer_record=ready['consumer_record'],
        actual_artifact_inputs=actual, cached_only=not args.supply, automatic_supply=args.supply,
        throughput_evidence=False, memory_evidence=False)
    try:
        if process['exit'] or process['timed_out']: raise RuntimeError('Actual Q32 native/supply failed')
        root = ET.parse(out / 'results.xml').getroot(); cases = list(root.iter('testcase'))
        if len(cases) != 1 or list(root.iter('skipped')) or list(root.iter('failure')) or any(int(root.get(key, '0')) for key in ('failures', 'errors', 'disabled')):
            raise ValueError('Require exactly one actual Q32 pass, zero failure/skip')
        node = cases[0]
        if node.get('classname') + '.' + node.get('name') != CASES[args.backend] or node.get('status') != 'run' or node.get('result') != 'completed':
            raise ValueError('Wrong or unexecuted Q32 case')
        props = {row.get('name'): row.get('value') for row in node.iter('property')}
        nr = c.read(DATA / 'original-static/acquisition.json'); tr = c.read(DATA / 'original-target-static/acquisition.json')
        expected = dict(artifact_repository='mlx-community/GLM-5.3-Flash-4bit', artifact_revision='fa04cbc3622b16aa7475404060b05e506d81bd4e',
            static_original_roles='117', static_original_bytes='3162045744', expert_domain='288', resident_experts='8', expert_planes='9',
            component_resources='32', nextn_resources='16', target43_resources='12', verifier_calls='3', target_full_f64_scores='309760',
            nextn_catalogue_sha256=nr['typed_catalog']['sha256'], target_catalogue_sha256=tr['typed_catalog']['sha256'])
        if any(props.get(key) != value for key, value in expected.items()): raise ValueError('Actual Q32 source/state/fullV identity differs')
        for key in ('actual_submissions', 'accepted_target_conditioned_repairs', 'target43_calls', 'target44_calls', 'actual_selected_original_experts'):
            if int(props[key]) <= 0: raise ValueError('Missing actual Q32 execution: ' + key)
        if int(props['actual_selected_original_bytes']) != 15204352 * int(props['actual_selected_original_experts']):
            raise ValueError('Actual nine-plane selected payload differs')
        if int(props['peak_state_backing_bytes']) > int(props['state_budget_bytes']): raise ValueError('Actual state budget exceeded')
        if args.supply:
            driver = c.read(out / 'frontier.driver.json')
            if driver['native']['exit'] or driver['native']['stopped_by_driver'] or driver['job_cleanup']['remaining_descendants'] or any(row['exit'] or row.get('stopped_by_driver', False) for row in driver['fetches']):
                raise ValueError('Owned native/supplier did not retire successfully')
            if not (R / '.scratch/mtp-download-budget-20261023/PAUSED').is_file(): raise ValueError('Budget pause was not restored')
            result['driver'] = identity(out / 'frontier.driver.json')
        c.check_record(c.resolve(ready['consumer_record']['path']))
        result.update(passed=True, tests=1, failures=0, skips=0, case=CASES[args.backend], properties=props,
                      actual_graph_submissions=int(props['actual_submissions']))
    except Exception as error:
        result['error'] = dict(type=type(error).__name__, message=str(error))
    c.save(out / 'summary.json', result)
    if not result['passed']: raise SystemExit(process['exit'] or 1)


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('action', choices=('plan', 'compile', 'link', 'run'))
    p.add_argument('--attempt', type=int, required=True); p.add_argument('--compile-attempt', type=int, default=1)
    p.add_argument('--link-attempt', type=int, default=1); p.add_argument('--backend', choices=('cpu', 'cuda'), default='cpu')
    p.add_argument('--closure-helper', type=Path, default=common.CLOSURE); p.add_argument('--closure-sha', default=common.CLOSURE_SHA)
    p.add_argument('--supply', action='store_true'); p.add_argument('--timeout', type=int, default=14400)
    args = p.parse_args(); args.entry = Path(__file__)
    if min(args.attempt, args.compile_attempt, args.link_attempt, args.timeout) <= 0: raise ValueError('Positive attempts/timeout required')
    adapter = Adapter()
    if args.action == 'plan': print(json.dumps(prepare(adapter, args), indent=2))
    elif args.action == 'compile': compile_one(adapter, args)
    elif args.action == 'link': common.link(adapter, args)
    else: run(adapter, args)
    return 0


if __name__ == '__main__': sys.exit(main())
