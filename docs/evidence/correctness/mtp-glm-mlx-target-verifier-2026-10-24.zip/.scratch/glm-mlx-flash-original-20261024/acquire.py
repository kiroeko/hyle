"""Root-only exact Q32 NextN41 / target75+finalnorm1 static acquisition.

Execute body only through budget/run_batch. No expert bank/body mode exists.
--plan-only and --write-batch-plan perform zero HTTP requests.
"""
import argparse,hashlib,importlib.util,json,struct,sys,urllib.request
from pathlib import Path
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent;R=S.parents[1]
REPO='mlx-community/GLM-5.3-Flash-4bit';REV='fa04cbc3622b16aa7475404060b05e506d81bd4e'
REQUEST,IO,WORKERS=8*1024*1024,1024*1024,3
PLANS={
 'nextn':('static-plan.json','c1d5a8329eb8f0c7bac7c6361e18a7bd539f62f0b689bf2e151ec6795b42ad50',41,2732636800,'original-static'),
 'target':('target-metadata/static-plan.json','e086b197dfca9941993f269acea3d5ea6e33e04662b691d18c139afdfee24135',76,429408944,'original-target-static'),
}
HELPERS={
 'bundle':('.scratch/dspark-pro-target-draft-20261023/fetch_dense.py','37d4414444a565f5b393d6908c63d176996c32cd359f519a60661f702091d5bf'),
 'lock':('.scratch/qwen-bfloat-selected-20261023/fetch_roles.py','1b34877ca22ab16eeaeb508e781dd84d0abf6555a73454b37f48e6d6a7e5cca3'),
 'budget':('.scratch/mtp-download-budget-20261023/budget.py','24b008fb7a91f0eba34739cd4817fbf97b42ca7f435032d76cfb6e97ea398a17'),
}
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def identity(p):
 p=p.resolve();b=p.read_bytes();return dict(path=p.relative_to(R).as_posix(),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def module(key):
 path,digest=HELPERS[key];path=R/path;assert identity(path)['sha256']==digest,'Pinned helper changed: '+key
 spec=importlib.util.spec_from_file_location('_q32_static_'+key,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
def retain(path,data):
 if path.exists():assert read(path)==data,'Immutable metadata plan differs: '+str(path)
 else:
  path.parent.mkdir(parents=True,exist_ok=True);path.write_text(json.dumps(data,indent=2)+'\n',encoding='utf-8',newline='\n')
def checked(section):
 file,digest,count,size,directory=PLANS[section];path=S/file;assert identity(path)['sha256']==digest
 plan=read(path);assert (plan['repository'],plan['revision'],plan['original_roles'],plan['bundle_bytes'])==(REPO,REV,count,size)
 assert len(plan['roles'])==count and len({r['name']for r in plan['roles']})==count
 assert plan['whole_shards_downloaded']is False and sum(r['bytes']for r in plan['roles'])==size
 headers=[]
 for source in plan['shards']:
  assert identity(R/source['header']['path'])==source['header']
  assert source['url']==f"https://huggingface.co/{REPO}/resolve/{REV}/{source['file']}"
  assert source['data_base']==source['header']['bytes']+8 and source['etag'].startswith('"')and source['etag'].endswith('"')
  headers.append(read(R/source['header']['path']))
 for row in plan['roles']:
  assert '.mlp.experts.'not in row['name'],'Complete expert-bank acquisition is forbidden'
  source=plan['shards'][row['source_shard']];actual=headers[row['source_shard']][row['name']]
  assert row['dtype']==actual['dtype']and row['shape']==actual['shape']and row['data_relative_half_open']==actual['data_offsets']
  first,last=row['absolute_inclusive'];a,b=actual['data_offsets']
  assert row['bytes']==b-a==last-first+1 and first==source['data_base']+a and last<source['whole_file_bytes']
 assert sum(g['bytes']for g in plan['groups'])==size
 if section=='target':
  assert sum(r['section']=='target43'for r in plan['roles'])==41
  assert sum(r['section']=='target44'for r in plan['roles'])==34
  assert [r['name']for r in plan['roles']if r['section']=='final']==['model.language_model.norm.weight']
 return path,plan,S/directory
def transport():
 path,digest=HELPERS['budget'];assert identity(R/path)['sha256']==digest
 opener=urllib.request.urlopen
 assert(hasattr(opener,'__code__')and opener.__code__.co_name=='open_range'and
  Path(opener.__code__.co_filename).resolve()==(R/path).resolve()and opener.__globals__.get('MIRROR_HOST')=='hf-mirror.net'), \
  'Run actual acquisition only through the pinned exclusive hf-mirror.net budget opener'
def check_catalog(record,plan,directory):
 assert record['complete']is True and record['role_payload_bytes']==plan['bundle_bytes']
 index=directory/'catalog.bin';raw=index.read_bytes();assert identity(index)==record['typed_catalog']
 magic,version,count,size,reserved,digest=struct.unpack('<8sIIQQ32s',raw[:64])
 assert(magic,version,count,size,reserved)==(b'HYDSPT01',1,plan['original_roles'],plan['bundle_bytes'],0)
 assert len(raw)==64+count*16 and digest.hex()==record['bundle']['sha256']
 for i,row in enumerate(plan['roles']):assert struct.unpack_from('<QQ',raw,64+i*16)==(row['bundle_offset'],row['bytes'])
def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('section',choices=tuple(PLANS))
 p.add_argument('--plan-only',action='store_true');p.add_argument('--write-batch-plan',type=Path);p.add_argument('--attempt',type=int,default=1)
 args=p.parse_args();assert args.attempt>0 and not(args.plan_only and args.write_batch_plan)
 path,plan,directory=checked(args.section)
 for key,(file,digest)in HELPERS.items():assert identity(R/file)['sha256']==digest
 info=dict(section=args.section,roles=plan['original_roles'],body_bytes=plan['bundle_bytes'],typed_catalog_bytes=64+plan['original_roles']*16,
  directory=directory.relative_to(R).as_posix(),source_plan=identity(path),maximum_http_request_bytes=REQUEST,stream_buffer_bytes=IO,workers=WORKERS)
 if args.plan_only:print(json.dumps(dict(info,complete=False,plan_only=True,network_requests=0)));return
 if args.write_batch_plan:
  output=args.write_batch_plan.resolve();assert output.is_relative_to(S)
  value=dict(script=identity(Path(__file__))['path'],script_sha256=identity(Path(__file__))['sha256'],arguments=[args.section],
   out=(S/'batches'/f'{args.section}-static-attempt{args.attempt}').relative_to(R).as_posix(),need_evidence=identity(path),
   new_unique_body_bytes=plan['bundle_bytes'],new_unique_body_bytes_is_upper_bound=True,whole_bank=False,whole_model=False,timeout_seconds=7200,
   maximum_http_request_bytes=REQUEST,stream_buffer_bytes=IO,workers=WORKERS,
   source_helpers={k:identity(R/v[0])for k,v in HELPERS.items()},
   scope='Exact original static roles only; authenticated cached chunks are locally verified and reused; no expert/vocabulary duplication.')
  retain(output,value);print(json.dumps(dict(batch_plan=identity(output),network_requests=0,**info)));return
 transport();fetch,locks=module('bundle'),module('lock')
 fetch.COUNT,fetch.BODY_BYTES,fetch.CHUNK,fetch.IO,fetch.WORKERS=plan['original_roles'],plan['bundle_bytes'],REQUEST,IO,WORKERS
 directory.mkdir(parents=True,exist_ok=True)
 with locks.single_writer(directory/'.fetch.lock'):
  record=fetch.main(plan_path=path,out=directory);check_catalog(record,plan,directory)
 print(json.dumps(dict(info,complete=True,acquisition=identity(directory/'acquisition.json'),typed_catalog=record['typed_catalog'])),flush=True)
if __name__=='__main__':main()
