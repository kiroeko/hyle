"""Actual target43/44 static75 + distinct finalnorm1 typed pin; no fake pins."""
import argparse,hashlib,importlib.util,json,re,struct
from pathlib import Path
S=Path(__file__).resolve().parent.parent;R=S.parents[1]
PLAN='e086b197dfca9941993f269acea3d5ea6e33e04662b691d18c139afdfee24135'
EXPERT='0e554f336ae1ab9de3b91f4d0541fbf26ad13896560e8343734c86928fa8a6d1'
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def identity(p):
 p=p.resolve();raw=p.read_bytes();return dict(path=p.relative_to(R).as_posix(),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def pin(p):return isinstance(p,str)and re.fullmatch('[0-9a-f]{64}',p)is not None
def validate(directory):
 spec=importlib.util.spec_from_file_location('_q32_target_source',S/'acquire.py');a=importlib.util.module_from_spec(spec);spec.loader.exec_module(a)
 path,plan,_=a.checked('target');assert identity(path)['sha256']==PLAN
 assert identity(S/'target-metadata/expert-source-plan.json')['sha256']==EXPERT
 receipt=directory/'acquisition.json';assert receipt.is_file(),'COMPLETE actual target static75+norm1 acquisition required'
 record=read(receipt)
 assert record['complete']is True and (record['repository'],record['revision'])==(a.REPO,a.REV)
 assert record['source_plan']==identity(path)['path'] and record['source_plan_sha256']==PLAN
 assert record['original_roles']==76 and record['bundle_bytes']==record['role_payload_bytes']==429408944
 assert record['whole_shards_downloaded']is False and record['unrequested_bytes']==0
 assert record['groups']==plan['groups']and record['shards']==plan['shards']
 assert (directory/'roles.bin').stat().st_size==429408944
 assert (R/record['bundle']['path']).resolve()==(directory/'roles.bin').resolve()and pin(record['bundle']['sha256'])
 a.check_catalog(record,plan,directory)
 assert identity(directory/'catalog.json')==record['catalog'];catalog=read(directory/'catalog.json')
 assert (catalog['repository'],catalog['revision'],catalog['original_roles'])==(a.REPO,a.REV,76)
 assert catalog['bundle']==dict(file='roles.bin',bytes=429408944,sha256=record['bundle']['sha256'])
 for actual,expected in zip(catalog['roles'],plan['roles'],strict=True):
  assert all(actual[k]==v for k,v in expected.items())and pin(actual['sha256'])
 total=0
 for g in plan['groups']:
  offset=g['bundle_offset']
  for part in sorted((p for p in record['chunks']if p['group']==g['index']),key=lambda p:p['offset']):
   assert part['offset']==offset and 0<part['bytes']<=record['chunk_bytes']and pin(part['sha256'])
   first=g['first']+offset-g['bundle_offset'];assert part['absolute_inclusive']==[first,first+part['bytes']-1]
   offset+=part['bytes'];total+=part['bytes']
  assert offset==g['bundle_offset']+g['bytes']
 assert total==sum(p['bytes']for p in record['chunks'])==429408944
 return a,record
def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--directory',type=Path,default=S/'original-target-static')
 p.add_argument('--output',type=Path,default=S/'generated/glm_mlx_target_artifacts.h');args=p.parse_args()
 directory=args.directory.resolve();a,record=validate(directory)
 values=dict(kRepository=a.REPO,kRevision=a.REV,kTargetStaticCatalogueSha256=record['typed_catalog']['sha256'],
  kTargetStaticPlanSha256=PLAN,kTargetExpertSourcePlanSha256=EXPERT,kTargetAcquisitionSha256=identity(directory/'acquisition.json')['sha256'])
 lines=['#pragma once','#include <string_view>',
  '// Actual static75+distinct globalnorm1. Original Q32 vocabulary is reused from NextN41.',
  'namespace glm_mlx_target_artifacts {']
 lines+=['inline constexpr std::string_view '+k+'='+json.dumps(v)+';'for k,v in values.items()]
 lines+=['} // namespace glm_mlx_target_artifacts','']
 args.output.parent.mkdir(parents=True,exist_ok=True);args.output.write_text('\n'.join(lines),encoding='utf-8',newline='\n')
 result=dict(complete=True,static_roles=76,layer_static_roles=75,distinct_final_norm_roles=1,source_bytes=429408944,
  source_plan=identity(S/'target-metadata/static-plan.json'),expert_source_plan=identity(S/'target-metadata/expert-source-plan.json'),
  acquisition=identity(directory/'acquisition.json'),typed_catalog=record['typed_catalog'],generated_header=identity(args.output),
  body_rehashed=False,network_requests=0,new_vocabulary_bytes=0)
 args.output.with_suffix('.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8');print(json.dumps(result))
if __name__=='__main__':main()
