"""Q32 actual static41 catalogue pin; incomplete/missing payload refuses output.

No body acquisition/rehash. The existing bounded bundle downloader authenticates
each original range and whole body; Data::load validates the body again.
"""
import argparse,hashlib,json,re,struct
from pathlib import Path

S=Path(__file__).resolve().parent.parent
R=S.parents[1]
STATIC_SHA='c1d5a8329eb8f0c7bac7c6361e18a7bd539f62f0b689bf2e151ec6795b42ad50'
EXPERT_SHA='f227abca1b6af48d98a01210ff6afbe050aac89e1e02143885a39347a7a82a8b'
REPO='mlx-community/GLM-5.3-Flash-4bit'
REV='fa04cbc3622b16aa7475404060b05e506d81bd4e'

def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def pin(s):return isinstance(s,str) and re.fullmatch('[0-9a-f]{64}',s) is not None
def identity(p):
    p=p.resolve();b=p.read_bytes()
    return dict(path=p.relative_to(R).as_posix(),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())

def validate(directory):
    assert identity(S/'static-plan.json')['sha256']==STATIC_SHA
    assert identity(S/'expert-source-plan.json')['sha256']==EXPERT_SHA
    plan=read(S/'static-plan.json')
    assert plan['repository']==REPO and plan['revision']==REV and plan['original_roles']==41 and plan['bundle_bytes']==2732636800
    record_path=directory/'acquisition.json'
    assert record_path.is_file(),'Actual COMPLETE static41 acquisition required; cached headers are not payload pins'
    record=read(record_path)
    assert record['complete'] is True and record['source_plan_sha256']==STATIC_SHA
    assert record['repository']==REPO and record['revision']==REV
    assert record['original_roles']==41 and record['bundle_bytes']==record['role_payload_bytes']==plan['bundle_bytes']
    assert record['whole_shards_downloaded'] is False and record['unrequested_bytes']==0
    assert record['groups']==plan['groups'] and record['shards']==plan['shards']
    for shard in plan['shards']:
        assert identity(R/shard['header']['path'])==shard['header']
    for name,key in [('catalog.bin','typed_catalog'),('catalog.json','catalog')]:
        assert identity(directory/name)==record[key]
    body=directory/'roles.bin'
    assert body.is_file() and body.stat().st_size==plan['bundle_bytes']
    assert (R/record['bundle']['path']).resolve()==body.resolve() and pin(record['bundle']['sha256'])
    catalog=read(directory/'catalog.json');typed=(directory/'catalog.bin').read_bytes()
    assert len(typed)==720  #64+41*16, precise role order rather than physical sort.
    magic,version,count,size,reserved,digest=struct.unpack('<8sIIQQ32s',typed[:64])
    assert (magic,version,count,size,reserved)==(b'HYDSPT01',1,41,plan['bundle_bytes'],0)
    assert digest.hex()==record['bundle']['sha256']
    assert catalog['repository']==REPO and catalog['revision']==REV and catalog['original_roles']==41
    assert catalog['bundle']==dict(file='roles.bin',bytes=size,sha256=digest.hex())
    for i,(actual,expected) in enumerate(zip(catalog['roles'],plan['roles'],strict=True)):
        assert all(actual[k]==v for k,v in expected.items()) and pin(actual['sha256'])
        assert struct.unpack_from('<QQ',typed,64+i*16)==(expected['bundle_offset'],expected['bytes'])
    total=0
    for group in plan['groups']:
        cursor=group['bundle_offset']
        for part in sorted((p for p in record['chunks'] if p['group']==group['index']),key=lambda p:p['offset']):
            assert part['offset']==cursor and 0<part['bytes']<=record['chunk_bytes'] and pin(part['sha256'])
            first=group['first']+cursor-group['bundle_offset']
            assert part['absolute_inclusive']==[first,first+part['bytes']-1]
            cursor+=part['bytes'];total+=part['bytes']
        assert cursor==group['bundle_offset']+group['bytes']
    assert total==sum(p['bytes'] for p in record['chunks'])==plan['bundle_bytes']
    return record,plan

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--directory',type=Path,default=S/'original-static')
    p.add_argument('--output',type=Path,default=S/'generated/glm_mlx_original_artifacts.h')
    args=p.parse_args();directory=args.directory.resolve();record,plan=validate(directory)
    values=dict(kRepository=REPO,kRevision=REV,kStaticCatalogueSha256=record['typed_catalog']['sha256'],
        kStaticPlanSha256=STATIC_SHA,kExpertSourcePlanSha256=EXPERT_SHA,
        kStaticAcquisitionSha256=identity(directory/'acquisition.json')['sha256'])
    text=['#pragma once','#include <string_view>',
        '// Generated only after actual static41 complete acquisition. No synthetic payload pins.',
        'namespace glm_mlx_original_artifacts {']
    text+=['inline constexpr std::string_view '+k+'='+json.dumps(v)+';' for k,v in values.items()]
    text+=['} // namespace glm_mlx_original_artifacts','']
    args.output.parent.mkdir(parents=True,exist_ok=True)
    args.output.write_text('\n'.join(text),encoding='utf-8',newline='\n')
    result=dict(complete=True,repository=REPO,revision=REV,original_roles=41,source_bytes=2732636800,
        generated=identity(args.output),acquisition=identity(directory/'acquisition.json'),
        typed_catalog=record['typed_catalog'],source_plan=identity(S/'static-plan.json'),
        expert_source_plan=identity(S/'expert-source-plan.json'),body_rehashed=False,network_requests=0)
    args.output.with_suffix('.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(result))

if __name__=='__main__':main()
