"""Q32 configuration of the existing owned-process driver, with real pins only."""
import importlib.util
import json
import os
from pathlib import Path
import sys
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent;R=S.parents[1]
DRIVER=R/'.scratch/dspark-pro-target-draft-20261023/run_with_supply.py'

def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path)
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);return module

def actual_static():
    for relative in ('generated/glm_mlx_original_artifacts.h','generated/glm_mlx_target_artifacts.h'):
        if not (S/relative).is_file():raise RuntimeError('Q32 actual117 static payload/pins are not ready: '+relative)
    nextn=load('_q32_actual_nextn_pins',S/'proposal/generate_pins.py')
    target=load('_q32_actual_target_pins',S/'proposal/generate_target_pins.py')
    nr,_=nextn.validate(S/'original-static');_,tr=target.validate(S/'original-target-static')
    tables=(
        ('glm_mlx_original_artifacts.h','glm_mlx_original_artifacts',dict(
            kRepository=nextn.REPO,kRevision=nextn.REV,kStaticCatalogueSha256=nr['typed_catalog']['sha256'],
            kStaticPlanSha256=nextn.STATIC_SHA,kExpertSourcePlanSha256=nextn.EXPERT_SHA,
            kStaticAcquisitionSha256=nextn.identity(S/'original-static/acquisition.json')['sha256'])),
        ('glm_mlx_target_artifacts.h','glm_mlx_target_artifacts',dict(
            kRepository=nextn.REPO,kRevision=nextn.REV,kTargetStaticCatalogueSha256=tr['typed_catalog']['sha256'],
            kTargetStaticPlanSha256=target.PLAN,kTargetExpertSourcePlanSha256=target.EXPERT,
            kTargetAcquisitionSha256=target.identity(S/'original-target-static/acquisition.json')['sha256'])))
    for name,namespace,values in tables:
        text=(S/'generated'/name).read_text(encoding='utf-8')
        if ('namespace '+namespace+' {') not in text:raise RuntimeError('Q32 generated source namespace differs: '+name)
        for key,value in values.items():
            if key+'='+json.dumps(value)+';' not in text:raise RuntimeError('Q32 actual generated source/receipt pin differs: '+name)
    return {'static_roles':117,'source_bytes':3162045744,'network_requests':0}

def restore_pause():
    directory=R/'.scratch/mtp-download-budget-20261023';marker=directory/'PAUSED'
    if marker.exists():return
    # Only after the owned driver has retired every native/download child.
    budget=load('_q32_restore_existing_budget',directory/'budget.py')
    with budget.locked() as record:
        if not marker.exists():
            temporary=directory/'PAUSED.q32-next'
            temporary.write_text(json.dumps(dict(paused_at=budget.now(),reason='Q32 owned supply run ended; no implicit prefetch.',
                reserved_request_bytes=record['reserved_request_bytes'],requests=len(record['requests'])))+'\n',encoding='utf-8')
            temporary.replace(marker)

def main():
    if sys.argv[1:]==['--preflight']:
        print(json.dumps(actual_static()));return 0
    if '--help' not in sys.argv[1:]:actual_static()
    driver=load('_q32_existing_owned_driver',DRIVER)
    if not hasattr(driver,'FETCH_SCRIPT'):raise RuntimeError('Current owned driver FETCH_SCRIPT/descendant cleanup update is required')
    driver.S,driver.R=S,R;driver.DOMAIN,driver.SECTIONS=288,('nextn','target43','target44')
    driver.FETCH_SCRIPT=S/'supply_experts.py'
    driver.WAIT_ENV='HYLE_GLM_MLX_WAIT_FOR_EXPERTS';driver.FRONTIER_ENV='HYLE_GLM_MLX_FRONTIER_FILE'
    for key,value in (('HYLE_GLM_MLX_NEXTN_DIR',S/'original-static'),('HYLE_GLM_MLX_TARGET_DIR',S/'original-target-static'),
                      ('HYLE_GLM_MLX_EXPERT_DIR',S/'original-experts')):
        if key in os.environ and Path(os.environ[key]).resolve()!=value.resolve():raise RuntimeError('Q32 actual cache location differs: '+key)
        os.environ[key]=str(value)
    try:return driver.main()
    finally:restore_pause()

if __name__=='__main__':sys.exit(main())
