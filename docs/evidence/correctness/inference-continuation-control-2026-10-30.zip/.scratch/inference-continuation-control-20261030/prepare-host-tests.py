from pathlib import Path
import importlib.util

W=Path(__file__).resolve().parent;R=W.parents[1]
spec=importlib.util.spec_from_file_location('b',W/'build.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
plan=b.read(W/'plan.json');original=plan['units']['host']
for name,file in [('continuation','inference_continuation_test.cc'),('ledger','qwen_generation_ledger_test.cc')]:
    folder=W/'compile'/name;folder.mkdir(parents=True,exist_ok=True)
    source=R/'tests/tools'/file;command=[]
    for index,arg in enumerate(original['compile']):
        if index and original['compile'][index-1].lower()=='/sourcedependencies':arg=str(folder/'dependencies.json')
        elif arg.lower().startswith('/fo'):arg='/Fo'+str(folder/'unit.obj')
        elif arg.lower().startswith('/fd'):arg='/Fd'+str(folder/'unit.pdb')
        elif b.key(arg)==b.key(original['source']):arg=str(source)
        command.append(arg)
    link=[]
    for arg in original['link']:
        if b.key(arg)==b.key(W/'compile/host/unit.obj'):arg=str(folder/'unit.obj')
        for prefix,suffix in [('/OUT:','.exe'),('/PDB:','.pdb'),('/IMPLIB:','.lib'),('/MAP:','.map')]:
            if arg.upper().startswith(prefix):arg=prefix+str((W/'bin'/name).with_suffix(suffix));break
        link.append(arg)
    plan['units'][name]=dict(source=str(source),compile=command,link=link)
    plan['cases'][name]=dict(unit=name,args=[])
plan['cases']['host']['groups']=16
b.save(W/'plan.json',plan)
print('Separated original 16-group error-only owner test from 3-group continuation and original 8-group ledger tests.')
