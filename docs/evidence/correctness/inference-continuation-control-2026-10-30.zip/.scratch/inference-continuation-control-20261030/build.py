from pathlib import Path
import importlib.util
import os
import shutil
import sys

sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;R=W.parents[1]
spec=importlib.util.spec_from_file_location('shared',R/'.scratch/inference-multimodel-observation-20261029/build.py')
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b);b.W=b.b.W=W
read,save,pin,exact,key=b.read,b.save,b.pin,b.exact,b.key

def prepare():
    base_path=R/'.scratch/inference-program-io-consumers-20261030/model-link-base.json'
    base=read(base_path)
    for item in [*base['retained'],base['runtime'],base['sdk_engine_dependencies']]:exact(item)
    for unit in read(base['sdk_engine_dependencies']['path'])['engine_consumers']:
        for item in unit['source_identities']:exact(item)
    old_source=base['consumer_source']['path'];old_object=read(base['previous_consumer']['path'])['object']['path']
    shutil.copyfile(R/'.scratch/inference-paged-append-cohort-20261029/model_consumer.cc',W/'model.cc')
    units={}
    for name,source in [('host',R/'tests/tools/inference_request_loop_test.cc'),
                        ('ordinary',R/'tests/tools/qwen_generation_batch_relay_probe.cc'),('model',W/'model.cc')]:
        folder=W/'compile'/name;folder.mkdir(parents=True,exist_ok=True)
        command=[]
        for i,arg in enumerate(base['compile']):
            if i and base['compile'][i-1].lower()=='/sourcedependencies':arg=str(folder/'dependencies.json')
            elif arg.lower().startswith('/fo'):arg='/Fo'+str(folder/'unit.obj')
            elif arg.lower().startswith('/fd'):arg='/Fd'+str(folder/'unit.pdb')
            elif key(arg)==key(old_source):arg=str(source)
            command.append(arg)
        link=[]
        for arg in base['link']:
            if key(arg)==key(old_object):arg=str(folder/'unit.obj')
            for prefix,suffix in [('/OUT:','.exe'),('/PDB:','.pdb'),('/IMPLIB:','.lib'),('/MAP:','.map')]:
                if arg.upper().startswith(prefix):arg=prefix+str((W/'bin'/name).with_suffix(suffix));break
            link.append(arg)
        assert sum(key(arg)==key(source) for arg in command)==1
        assert sum(key(arg)==key(folder/'unit.obj') for arg in link)==1
        units[name]=dict(source=str(source),compile=command,link=link)
    (W/'bin').mkdir(exist_ok=True);shutil.copyfile(base['runtime']['path'],W/'bin'/Path(base['runtime']['path']).name)
    tiny=R/'.scratch/inference-paged-frame-20261026/tiny-recursive-input'
    original=R/'.scratch/qwen35-unsloth-mtp-20261024/geometry-v2-check/original'
    continuous_source=R/'.scratch/inference-continuous-wave-20261027/inputs/context32'
    continuous=W/'continuous-input';continuous.mkdir(exist_ok=True)
    for name in ('weights.tsv','prompt.ids'):shutil.copyfile(continuous_source/name,continuous/name)
    fixtures={}
    for name,directory in [('tiny',tiny),('original',original),('continuous',continuous)]:
        fixtures[name]=dict(directory=str(directory),manifest=pin(directory/'weights.tsv'),prompt=pin(directory/'prompt.ids'))
    cases={
        'host':dict(unit='host',args=[],groups=19),
        'ordinary-cuda':dict(unit='ordinary',args=['--cuda',str(tiny)]),
        'continuous-cuda':dict(unit='ordinary',args=['--cuda-continuous',str(continuous)]),
        'mixed-cpu':dict(unit='model',args=['mixed-lag','cpu',str(tiny)]),
        'mixed-cuda':dict(unit='model',args=['mixed-lag','cuda',str(tiny)]),
        'natural-cuda':dict(unit='model',args=['natural','cuda',str(original)]),
    }
    save(W/'plan.json',dict(base=pin(base_path),units=units,retained=base['retained'],runtime=base['runtime'],
        sdk=base['sdk_engine_dependencies'],fixtures=fixtures,cases=cases))
    print('Prepared 3 current consumers, 6 finite processes; all 227 SDK/engine inputs reused, no downloads/NVCC.')

def run(name,attempt):
    plan=read(W/'plan.json');case=plan['cases'][name];b.receipt(case['unit'])
    image=read(W/('ready-'+case['unit']+'.json'));exact(image)
    os.environ.update(HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',HF_DATASETS_OFFLINE='1')
    folder=W/'runs'/name/attempt;save(folder/'image.json',image)
    b.b.execute([image['path'],*case['args']],folder,600)
    if name=='host':
        message=(folder/'stdout.log').read_text()
        assert f"{case['groups']} host contract groups passed" in message
        report=dict(status='PASS',host_groups=case['groups'],model_loaded=False)
    else:
        report=read(folder/'stdout.log');assert report['status']=='PASS'
    save(folder/'report.json',report);print('PASS',name)

if __name__=='__main__':
    if sys.argv[1]=='prepare':prepare()
    elif sys.argv[1]=='run':run(sys.argv[2],sys.argv[3] if len(sys.argv)>3 else 'attempt1')
    else:b.main()
