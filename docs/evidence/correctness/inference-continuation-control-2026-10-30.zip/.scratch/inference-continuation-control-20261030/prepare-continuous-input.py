from pathlib import Path
import importlib.util
import shutil

W=Path(__file__).resolve().parent;R=W.parents[1]
spec=importlib.util.spec_from_file_location('b',W/'build.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
plan=b.read(W/'plan.json');old=R/'.scratch/inference-continuous-wave-20261027/inputs/context32'
directory=W/'continuous-input';directory.mkdir(exist_ok=True)
for name in ('weights.tsv','prompt.ids'):
    target=directory/name;assert not target.exists();shutil.copyfile(old/name,target)
plan['fixtures']['continuous']=dict(directory=str(directory),manifest=b.pin(directory/'weights.tsv'),prompt=b.pin(directory/'prompt.ids'))
plan['cases']['continuous-cuda']['args']=['--cuda-continuous',str(directory)]
b.save(W/'plan.json',plan)
print('Prepared two small metadata files referring to original cached weights; no payload copied or downloaded.')
