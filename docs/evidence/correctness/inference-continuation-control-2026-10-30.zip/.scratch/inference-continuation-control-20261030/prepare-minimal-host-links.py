from pathlib import Path
import importlib.util

W=Path(__file__).resolve().parent;R=W.parents[1]
spec=importlib.util.spec_from_file_location('b',W/'build.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
plan=b.read(W/'plan.json');cache=R/'.scratch/build-compute-v2-dev/bin'
libraries=[cache/name for name in ['hyle_container.lib','hyle_mem.lib','hyle_platform.lib','hyle_error.lib','mimalloc_static.lib']]
for path in libraries:assert path.is_file()
system=['bcrypt.lib','PowrProf.lib','kernel32.lib','user32.lib','gdi32.lib','winspool.lib','shell32.lib',
        'ole32.lib','oleaut32.lib','uuid.lib','comdlg32.lib','advapi32.lib']
for name in ('host','continuation','ledger'):
    selected=[cache/'hyle_error.lib'] if name=='host' else libraries
    link=[plan['units'][name]['link'][0],'/NOLOGO','/INCREMENTAL:NO','/SUBSYSTEM:CONSOLE',
          '/OUT:'+str(W/'bin'/(name+'.exe')),str(W/'compile'/name/'unit.obj'),*map(str,selected),*system]
    plan['units'][name]['link']=link
plan['host_link_inputs']=[b.pin(path) for path in libraries]
plan['host_link_basis']=dict(file=b.pin(R/'.scratch/build-compute-v2-dev/build.ninja'),
                            cached_target='hyle_container_hash_seed_probe',scope='Host-only dependency closure, not current generated CMake target execution')
b.save(W/'plan.json',plan)
print('Original request-loop links error only; continuation/ledger link five cached host libraries. No native SDK or CUDA import needed.')
