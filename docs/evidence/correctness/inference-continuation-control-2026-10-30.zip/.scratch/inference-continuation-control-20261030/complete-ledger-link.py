from pathlib import Path
import importlib.util

W=Path(__file__).resolve().parent;R=W.parents[1]
spec=importlib.util.spec_from_file_location('b',W/'build.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
plan=b.read(W/'plan.json')
budget=R/'.scratch/inference-cache-shared-source-20261025/attempt1/budget/unit.obj'
item=next(x for x in plan['retained'] if b.key(x['path'])==b.key(budget));b.exact(item)
plan['units']['ledger']['link'].append(str(budget))
plan['ledger_compute_budget']=item
b.save(W/'plan.json',plan)
print('Original ledger test now includes its actual Compute ResourceBudget dependency; still no Graph/CUDA linkage.')
