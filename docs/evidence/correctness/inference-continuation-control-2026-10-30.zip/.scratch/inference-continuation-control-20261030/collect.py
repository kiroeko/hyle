from pathlib import Path
import importlib.util
import shutil
import subprocess
import zipfile

W=Path(__file__).resolve().parent;R=W.parents[1]
spec=importlib.util.spec_from_file_location('b',W/'build.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
read,save,pin,exact=b.read,b.save,b.pin,b.exact
plan=read(W/'plan.json')
for item in [*plan['retained'],plan['runtime'],plan['sdk'],*plan['host_link_inputs']]:exact(item)
for unit in read(plan['sdk']['path'])['engine_consumers']:
    for item in unit['source_identities']:exact(item)
builds={name:b.b.receipt(name) for name in plan['units']}
current={}
for name in plan['cases']:
    attempt='minimal' if name=='host' else 'attempt2' if name=='continuous-cuda' else 'attempt1'
    folder=W/'runs'/name/attempt;process=read(folder/'process.json');report=read(folder/'report.json')
    assert process['state']=='TERMINAL' and process['exit']==0 and report['status']=='PASS'
    current[name]=dict(process=pin(folder/'process.json'),report=pin(folder/'report.json'))
comparisons={}
for name,old in [('natural-cuda','mtp-natural-cuda'),('mixed-cuda','mixed-lag-cuda'),('continuous-cuda','ordinary-cuda')]:
    path=R/'.scratch/inference-paged-append-cohort-20261029/runs'/old/'current/report.json'
    assert read(current[name]['report']['path'])==read(path)
    comparisons[name]=dict(previous=pin(path),all_report_properties_identical=True)
attempts=[]
for group in ('compile','link','runs','imports'):
    for path in sorted((W/group).rglob('process.json')):
        item=read(path);assert item['state']=='TERMINAL'
        attempts.append(dict(kind=group,path=str(path.relative_to(W)),exit=item['exit'],seconds=item['seconds']))
for name in ('host','continuation','ledger'):
    imported=(W/'imports'/name/'stdout.log').read_text(errors='replace').lower()
    assert not any(x in imported for x in ('cuda','torch','ggml','dnnl'))
save(W/'verification.json',dict(builds=builds,cases=current,comparisons=comparisons,attempts=attempts))
files=['engine/inference/continuation.h','engine/models/qwen35/main.cc','engine/models/qwen35/generation_ledger.h',
       'tests/CMakeLists.txt','tests/tools/inference_continuation_test.cc','tests/tools/qwen_continuous_generation_case.h',
       'tests/tools/inference_request_loop_test.cc','tests/tools/qwen_generation_ledger_test.cc']
for name in files:
    target=W/'sources'/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(R/name,target)
base=dict(schema='hyle.continuation-control.current-link-base.v1',base=plan['base'],
    compile=plan['units']['model']['compile'],link=plan['units']['model']['link'],consumer_source=pin(W/'model.cc'),
    previous_consumer=pin(W/'compile/model/receipt.json'),retained=plan['retained'],runtime=plan['runtime'],sdk_engine_dependencies=plan['sdk'])
save(W/'model-link-base.json',base)
bundle=R/'docs/evidence/correctness/inference-continuation-control-2026-10-30.zip'
with zipfile.ZipFile(bundle,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as archive:
    for path in sorted(W.rglob('*')):
        if not path.is_file() or path.suffix.lower() not in ('.py','.ps1','.json','.log','.xml','.cc','.h','.txt','.tsv','.ids','.bin'):continue
        if any(part in ('bin','tmp','__pycache__') for part in path.relative_to(W).parts):continue
        archive.write(path,str(path.relative_to(R)).replace('\\','/'))
    for name,item in comparisons.items():archive.write(item['previous']['path'],f'.scratch/inference-continuation-control-20261030/previous/{name}.json')
summary=dict(schema='hyle.correctness.continuation-control.v1',date='2026-10-30',status='PASS',
    base_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),
    changes=[
        'Original ordered (RequestKey including Window owner/generation, turn) cohort and drain intent moved to common ContinuationCohort. Native calls, StepSources, Head/boundaries, replay slots and retirement remain with the model.',
        'Pending-cohort regrouping rejects without losing identity. A foreign admission during accepted work requests drain rather than erasing ready/cohort metadata. Ready reset never clears pending calls or acknowledges retirement.',
        'Ordinary width1/K1 width2 quota arithmetic is shared and evaluated once by the original ledger, preserving original boundary checks, error type/message and prepared storage.',
        'Whole-cohort post-publication continuation decisions share actual request facts. A stopped/unpublished/failed predecessor retires all B and preserves A; drain alone may still observe accepted B. Model warm/Source/capacity hints stay model-owned.',
        'Progress projection exceptions preserve their original type through the original catch/abort path. A later actual-retired observe-only Stage clears handled drain intent; an unretired outcome cannot clear pending metadata.',
        'New continuation test links only container/mem host dependencies, preserving the original error-only request-loop test. Minimal linkage exposed an existing ledger ResourceBudget dependency; its CMake target now explicitly links Compute and only exists when that product is available.'
    ],counts=dict(current_consumer_TUs=5,CXX_attempts=sum(a['kind']=='compile' for a in attempts),
        link_attempts=sum(a['kind']=='link' for a in attempts),native_attempts=sum(a['kind']=='runs' for a in attempts),
        current_passed_processes=len(current),host_contract_groups=27,model_consumer_processes=5,
        ordinary_serial_relay_arms=6,continuous_control_candidate_arms=16,
        retained_SDK_engine_inputs=227,SDK_CXX=0,NVCC=0,downloads=0,full_builds=0),
    results=dict(host_groups=dict(request_loop=16,continuation=3,ledger=8),
                 model_cases=['ordinary-cuda','continuous-cuda','mixed-cpu','mixed-cuda','natural-cuda'],
                 prior_complete_reports_identical=list(comparisons),host_PE_imports_exclude_native_SDK=True),
    preserved_attempts=[
        'First continuous invocation refused an existing generated stop fixture in the old shared input directory before model work. Retried once with this batch two small manifest/prompt files referencing the same cached weights; no payload download or copy.',
        'Minimal ledger link failed missing ResourceBudget destructor. Fixed the actual Compute dependency, using the current retained budget object in the finite host link; no SDK rebuild.'
    ],
    reference=dict(engine='local vLLM',revision='276fbcff2717bd934cfa37c8a2e4c391f3e7237b',
        scope='Original future and SchedulerOutput retained together; cancellation intent and actual resource retirement remain separate. Hyle delivery credit is not vLLM token scheduling budget.'),
    reproduction=dict(directory=str(W),details='verification.json, plan.json, source/dependency/command/process receipts and finite 64KiB stop fixture in ZIP'),
    limitations=[
        'No whole GLM/DeepSeek async-engine claim: the existing real GLM consumer is synchronous and already uses common RequestLoop/wave. The new async control consumer remains Qwen ordinary/K1.',
        'Host retirement inputs are contract checks, not fabricated device completion. Native tests exercise actual submissions/control failures; no unknown native fault or delayed-retirement fault was injected.',
        'Pending select conflict is guarded by the common API but current Qwen resumed execution still validates its original pending span directly and does not call select again.',
        'Current sources were compiled and linked against minimal cached host libraries, and PE imports checked; this batch did not regenerate CMake or claim a fresh installation.',
        'No new throughput/VRAM/kernel-count claim. Full cross-model orchestration, multi-draft unification and other roadmap items remain incomplete.'
    ],evidence_bundle=pin(bundle))
save(R/'docs/evidence/correctness/inference-continuation-control-2026-10-30.json',summary)
print(summary['counts'],'bundle_bytes',bundle.stat().st_size)
