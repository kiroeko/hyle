from pathlib import Path
import importlib.util
import shutil
import sys
import zipfile

W=Path(__file__).resolve().parent;R=W.parents[1]
spec=importlib.util.spec_from_file_location('b',W/'build.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
if len(sys.argv)>1 and sys.argv[1]=='finish':
    report=b.read(W/'cleanup-report.json');assert report['status']=='COMPLETE'
    path=R/'docs/evidence/correctness/inference-continuation-control-2026-10-30.json';summary=b.read(path)
    bundle=Path(summary['evidence_bundle']['path'])
    with zipfile.ZipFile(bundle,'a',zipfile.ZIP_DEFLATED,compresslevel=6) as archive:
        archive.write(W/'cleanup-report.json',str((W/'cleanup-report.json').relative_to(R)).replace('\\','/'))
    summary['cleanup']=dict(files=report['files'],bytes=report['bytes'],status=report['status'])
    summary['evidence_bundle']=b.pin(bundle);b.save(path,summary)
    print('Finalized evidence:',bundle.stat().st_size,'bytes')
    raise SystemExit(0)
for path in W.rglob('process.json'):assert b.read(path)['state']=='TERMINAL',str(path)
files=sorted(path for path in (W/'bin').iterdir() if path.is_file())
b.save(W/'cleanup-plan.json',dict(root=str(W/'bin'),files=[b.pin(path) for path in files],bytes=sum(path.stat().st_size for path in files)))
script=r'''param([switch]$Execute)
$ErrorActionPreference = 'Stop'
$TaskRoot = 'C:\public\project-hyle\hyle\.scratch\inference-continuation-control-20261030'
$AllowedRoot = [IO.Path]::GetFullPath((Join-Path $TaskRoot 'bin'))
$Plan = Get-Content -LiteralPath (Join-Path $TaskRoot 'cleanup-plan.json') -Raw | ConvertFrom-Json
if ([IO.Path]::GetFullPath($Plan.root) -ne $AllowedRoot) { throw 'Unexpected cleanup root' }
foreach ($Receipt in Get-ChildItem -LiteralPath $TaskRoot -Filter 'process.json' -File -Recurse) {
    if ((Get-Content -LiteralPath $Receipt.FullName -Raw | ConvertFrom-Json).state -ne 'TERMINAL') { throw "Process still running: $($Receipt.FullName)" }
}
foreach ($Entry in $Plan.files) {
    $TargetPath = [IO.Path]::GetFullPath($Entry.path)
    if ([IO.Path]::GetDirectoryName($TargetPath) -ne $AllowedRoot) { throw "Outside exact cleanup root: $TargetPath" }
    $Item = Get-Item -LiteralPath $TargetPath
    if ($Item.PSIsContainer -or ($Item.Attributes -band [IO.FileAttributes]::ReparsePoint)) { throw "Not an ordinary file: $TargetPath" }
    if ($Item.Length -ne $Entry.bytes -or (Get-FileHash -LiteralPath $TargetPath -Algorithm SHA256).Hash.ToLowerInvariant() -ne $Entry.sha256) { throw "File identity changed: $TargetPath" }
}
if (-not $Execute) {
    [pscustomobject]@{Files=$Plan.files.Count; Bytes=$Plan.bytes; Root=$AllowedRoot}
    return
}
foreach ($Entry in $Plan.files) { Remove-Item -LiteralPath $Entry.path -Force }
$Report = [pscustomobject]@{status='COMPLETE'; files=$Plan.files.Count; bytes=$Plan.bytes; scope='Only this batch native images/link outputs and copied DLL; current consumer objects and 227 SDK/engine inputs retained.'}
$Report | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $TaskRoot 'cleanup-report.json') -Encoding utf8
$Report
'''
(R/'test.ps1').write_text(script,encoding='utf-8-sig');shutil.copyfile(R/'test.ps1',W/'test.ps1')
print('Prepared exact cleanup:',len(files),'files',sum(path.stat().st_size for path in files),'bytes; not executed.')
