from pathlib import Path
source = Path(__file__).resolve().parents[2] / '.scratch/inference-packed-sampling-interface-20261025/check.py'
script = source.read_text().replace('STRICT_NF4_SOURCE_OPERANDS_AND_SAMPLING_INTERFACE_PASS',
    'STRICT_MLX_NF4_SAMPLING_AND_SINGLETON_INTERFACE_PASS')
exec(compile(script, str(source), 'exec'))
