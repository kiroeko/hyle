from pathlib import Path
import json

root = Path(__file__).resolve().parents[2]
path = root / 'docs/implementation/model-quantizations.json'
catalog = json.loads(path.read_text(encoding='utf-8'))
evidence = 'docs/evidence/correctness/mlx-source-resident-ordinary-consumer-2026-10-25.json'
for index in (4, 5, 11, 12):
    artifact = catalog['artifacts'][index]
    assert artifact['codec_domain'] in ('MLX-affine4-g64', 'MLX-affine8-g64')
    small = index in (4, 5)
    coverage = artifact['provider_coverage']
    limits = [
        'Original publisher producer-version/base revision remains unpinned; the selected current mlx-lm/core reader does not establish historical producer identity.',
        'Complete original 2B/27B generation, task quality, throughput and peak-memory comparison are unverified.',
        'This follow-up does not run Linux, Apple or Vulkan original-payload execution or certify cross-provider bit equivalence.',
    ]
    if not small:
        limits.append('Qwen3.8-27B original payload remains unread in this follow-up; its complete text header and ordinary loader metadata are checked, not its original operation output.')
    coverage['review'] = 'ordinary_source_resident_binding_and_bounded_original_components' if small else 'ordinary_source_resident_binding_and_complete_text_metadata'
    coverage['review_scope'] = (
        '2026-10-25: all four fixed text inventories pass prepare/C++ reading. Original Qwen3.5-2B 4/8bit projection, embedding and tied-head components each pass 24,690 CPU/CUDA values against an independent pinned reader. A separate untrained tiny CPU Model passes loading, direct norm/conv semantics, prefill/decode, state/RNG restore and retirement. Canonical combined interfaces pass strict syntax only; no complete original model or performance result.'
        if small else
        '2026-10-25: complete fixed Qwen3.8-27B text inventories pass prepare/C++ reading, including untied head and original physical naming. Consumer code supports selected affine4/8 group64 with original U32/BF16/BF16 inputs and explicit sanitized parameters. Original operation payload was checked only for the distinct Qwen3.5-2B artifacts; no Qwen3.8-27B operation or complete model run.'
    )
    coverage['mapping_status'] = 'Ordinary prepared loader and Recipe bind original affine triples, quantized embedding and tied/untied head. Linear uses F32 affine decoding/dot then BF16 output; embedding keeps BF16 multiply/add rounding. Sanitized norm gamma is direct and [C,kernel,1] conv is descriptor-mapped without changing bytes.'
    coverage['artifact_unaligned_or_unverified'] = limits
    coverage['missing_capabilities'] = [
        'Complete original-artifact runtime integration/quality/performance remains unverified; only the explicitly bounded component and tiny-state scope is closed.',
    ]
    for domain in coverage.get('role_domains', []):
        domain['unresolved'] = limits.copy()
    coverage['ordinary_mlx_followup'] = dict(
        observed_on='2026-10-25', evidence=evidence,
        source_reader='mlx-lm@4cfc6478473b0668ede3eb0cc93f2a9181a15052',
        core_reader='mlx@2b2bb49790158ecd008d1685c94e3ef119792a00',
        original_publisher_producer_version_verified=False,
        original_component_CPU_CUDA_verified=small,
        ordinary_tiny_CPU_fixture_verified=True,
        complete_text_metadata_verified=True,
        original_artifact_execution_verified=False,
        quality_or_performance_claim=False)
    assert coverage['artifact_execution_verified'] is False
catalog['followup_reviews'].append(dict(observed_on='2026-10-25', evidence=evidence,
    artifact_indices=[4, 5, 11, 12],
    scope='Ordinary selected MLX affine4/8 group64 source-resident loader/Recipe, four complete text inventories, original Q35 components CPU/CUDA, separate tiny CPU state journey and combined strict interfaces. Historical primitive and 2026-10-21 metadata facts are retained at their original scope.',
    artifact_execution_verified=False, throughput_claim=False))
path.write_text(json.dumps(catalog, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
print('Updated selected MLX coverage; historical facts and complete-artifact false preserved.')
