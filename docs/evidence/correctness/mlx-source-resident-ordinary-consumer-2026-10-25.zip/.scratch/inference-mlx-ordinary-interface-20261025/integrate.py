from pathlib import Path
import hashlib
import json
import subprocess
import re

root = Path(__file__).resolve().parents[2]
base = Path(__file__).resolve().parent
private = root / '.scratch/mlx-ordinary-qwen-20261025/consumer'
pins = json.loads((private / 'product-final/pins.json').read_text())
original = private / 'changes.patch'
assert hashlib.sha256(original.read_bytes()).hexdigest() == 'cd1463b3e38ed203e1aa614e0bbd8e829fd0bc096fabf06d7ca9c559bbe00851'
patch = base / 'changes-normalized.patch'
patch.write_bytes(original.read_bytes().replace(b'\r\n', b'\n'))
before = []
for pin in pins['files']:
    source = root / pin['path']
    assert source.stat().st_size == pin['bytes']
    assert hashlib.sha256(source.read_bytes()).hexdigest() == pin['sha256']
    path = root / pin['relative_path']
    before.append(dict(path=pin['relative_path'], bytes=path.stat().st_size,
                       sha256=hashlib.sha256(path.read_bytes()).hexdigest()))
assert before[0]['sha256'] == '647967bf47440a94799f8212d5ba8b976ce4cfc1724a70589b80f3ee159d8d93'
# git apply --check rejected the LF patch against CRLF working files without
# modifying anything. Apply exact normalized hunk context, then compare every
# resulting file to the frozen private product before any product write.
sections = re.split(r'(?m)^--- a/', patch.read_text())[1:]
planned = {}
for section in sections:
    lines = section.splitlines(True)
    name = lines[0].rstrip('\n')
    path = root / name
    original_bytes = path.read_bytes()
    source = original_bytes.replace(b'\r\n', b'\n').decode().splitlines(True)
    output, cursor, i = [], 0, 2
    while i < len(lines):
        match = re.fullmatch(r'@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@.*\n', lines[i])
        assert match, lines[i]
        old_start = int(match.group(1)) - 1
        old_count, new_count = int(match.group(2) or 1), int(match.group(4) or 1)
        old, new = [], []
        i += 1
        while i < len(lines) and not lines[i].startswith('@@ '):
            line = lines[i]
            assert line[0] in ' +-'
            if line[0] in ' -': old.append(line[1:])
            if line[0] in ' +': new.append(line[1:])
            i += 1
        assert len(old) == old_count and len(new) == new_count
        assert old_start >= cursor and source[old_start:old_start+old_count] == old, name
        output.extend(source[cursor:old_start]); output.extend(new)
        cursor = old_start + old_count
    output.extend(source[cursor:])
    planned[name] = ''.join(output).encode()
after = []
for pin in pins['files']:
    path = root / pin['relative_path']
    actual = planned[pin['relative_path']]
    expected = (root / pin['path']).read_bytes().replace(b'\r\n', b'\n')
    if pin['relative_path'].endswith('/main.cc'):
        old = b'while (!bucket[0].full_hit && !make_generation_batch_room('
        new = b'while (bucket.size() > 1 && !bucket[0].full_hit && !make_generation_batch_room('
        assert expected.count(old) == 1
        expected = expected.replace(old, new)
        old = b'        if (bucket.size() == 1) throw std::runtime_error("MTP committed budget cannot advance its selected request");\n'
        assert expected.count(old) == 1
        expected = expected.replace(old, b'')
    assert actual == expected, pin['relative_path']
for pin in pins['files']:
    path = root / pin['relative_path']
    actual = planned[pin['relative_path']]
    if b'\r\n' in path.read_bytes(): actual = actual.replace(b'\n', b'\r\n')
    path.write_bytes(actual)
    after.append(dict(path=pin['relative_path'], bytes=path.stat().st_size,
                      sha256=hashlib.sha256(path.read_bytes()).hexdigest()))
(base / 'integration.json').write_text(json.dumps(dict(before=before, after=after,
    original_patch_sha256=hashlib.sha256(original.read_bytes()).hexdigest(),
    preflight_failure='git apply --check rejected LF context against four CRLF files; no product mutation. Exact normalized context and frozen outputs checked before writes.',
    scope='Private MLX seven-file patch applied with existing singleton bucket admission preserved; no runtime claim.'), indent=2)+'\n')
print(json.dumps(dict(status='MLX_PRODUCT_PATCH_APPLIED', files=len(after), main=after[0]), indent=2))
