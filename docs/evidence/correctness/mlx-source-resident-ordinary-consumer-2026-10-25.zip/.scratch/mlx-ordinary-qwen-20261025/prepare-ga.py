from pathlib import Path
R=Path.cwd();W=R/'.scratch/mlx-ordinary-qwen-20261025/consumer'
t=(R/'.scratch/nf4-packed-contraction-20261025/consumer/ga.cc').read_text()
start=t.index('std::pair<std::filesystem::path,std::size_t> weights(');end=t.index('\nBytes read(',start)
weights=r'''std::pair<std::filesystem::path,std::size_t> weights(const std::filesystem::path& folder,const q::ModelGeometry& shape) {
 std::filesystem::create_directories(folder);const auto body=folder/"untrained-mlx.bin",list=folder/"weights.tsv";
 std::ofstream payload(body,std::ios::binary),manifest(list);require(bool(payload)&&bool(manifest),"cannot create MLX fixture");
 manifest<<"HYLE_QWEN_ROLE_FILES_V2\n"<<std::string(64,'7')<<"\ngeometry 64 128 64 1 1 64 64 64 1 1 64 64 4 16 10000 1e-6 1 0 grouped \"GA\"\n"<<q::prepared::mlx_policy_line(4)<<'\n';
 std::size_t offset=0,index=0;
 const auto bf=[](float v){auto bits=std::bit_cast<std::uint32_t>(v);bits+=0x7fffU+((bits>>16)&1U);return static_cast<std::uint16_t>(bits>>16);};
 const auto write=[&](const std::string& logical,const char*dtype,std::span<const std::int64_t>dims,std::span<const std::byte>bytes){
  const auto name=logical.starts_with("model.language_model.")?"language_model.model."+logical.substr(21):"language_model."+logical;
  payload.write(reinterpret_cast<const char*>(bytes.data()),static_cast<std::streamsize>(bytes.size()));manifest<<name<<' '<<dtype<<' '<<dims.size();for(auto d:dims)manifest<<' '<<d;manifest<<' '<<std::quoted(body.generic_string())<<' '<<offset<<' '<<bytes.size()<<'\n';offset+=bytes.size();
 };
 const std::string embedding="model.language_model.embed_tokens.weight",linear="model.language_model.layers.1.self_attn.k_proj.weight";
 for(const auto&[name,p]:q::prepared::parameter_inventory(false,shape)){
  if(name==embedding||name==linear){
   const auto n=p.shape[0],k=p.shape[1];std::vector<std::uint32_t> codes(static_cast<std::size_t>(n*k/8));for(std::size_t i=0;i<codes.size();++i)codes[i]=0x01234567U+static_cast<std::uint32_t>(i*0x1234567U);
   const std::array<std::int64_t,2> wshape{n,k/8},sshape{n,k/64};std::vector<std::uint16_t> scales(static_cast<std::size_t>(n*k/64),bf(.003F)),bias(scales.size(),bf(-.02F));
   write(name,"U32",wshape,std::as_bytes(std::span(codes)));const auto base=name.substr(0,name.size()-7);write(base+".scales","BF16",sshape,std::as_bytes(std::span(scales)));write(base+".biases","BF16",sshape,std::as_bytes(std::span(bias)));continue;
  }
  std::size_t count=1;for(auto d:p.shape)count*=std::size_t(d);auto dims=p.shape;if(name.ends_with(".conv1d.weight"))dims={shape.gdn_qkv_width(),shape.conv_kernel,1};
  if(name.ends_with(".A_log")){std::vector<float> values(count,0.F);write(name,"F32",dims,std::as_bytes(std::span(values)));}
  else {std::vector<std::uint16_t> values(count);for(std::size_t i=0;i<count;++i)values[i]=bf(p.shape.size()==1?(name.ends_with(".dt_bias")?0.F:1.F):.03F*std::sin(float(i+index*17)*.13F));write(name,"BF16",dims,std::as_bytes(std::span(values)));}++index;
 }
 require(bool(payload)&&bool(manifest)&&offset<1024*1024,"MLX fixture exceeds finite scope");return{list,offset};
}'''
t=t[:start]+weights+t[end:]
t=t.replace('// Untrained ordinary F16 GA with source-retaining six-operand NF4 projection.\n// CPU C192 and CUDA C256 are separate legal fixtures, not cross-device numerics.','// Untrained ordinary MLX sanitized-role GA. CPU only; no full original model.')
t=t.replace('.f16"','.bf16"')
t=t.replace('require(argc==4,"ga FIXTURE OUTPUT cpu|cuda");const bool cuda=std::string_view(argv[3])=="cuda";','require(argc==4,"ga FIXTURE OUTPUT cpu");const bool cuda=false;require(std::string_view(argv[3])=="cpu","this finite journey is CPU only");')
start=t.index(' require(model.precision.is_f16()');end=t.index(' const std::array chunks',start)
t=t[:start]+r''' require(!model.precision.is_f16()&&model.state_schema[0].history.data_type()==q::Type::kBFloat16&&model.state_schema[0].recurrent.data_type()==q::Type::kFloat32,"typed MLX GDN state schema differs");
 const std::string principal="model.language_model.layers.1.self_attn.k_proj.weight",embedding="model.language_model.embed_tokens.weight";
 require(model.weights.at(principal).codec==q::prepared::ProjectionCodec::kMlxAffine&&model.weights.at(principal).tensor.description.data_type()==q::Type::kUInt32,"resident MLX source lost original packing");
 require(std::holds_alternative<q::MlxAffineProjection>(model.projections.at(principal))&&std::holds_alternative<q::MlxAffineProjection>(model.projections.at(embedding)),"cold MLX projection/embedding binding missing");
 require(model.weight_meanings.at("model.language_model.norm.weight")==q::prepared::ParameterMeaning::kRmsEffectiveGamma&&model.weight_meanings.at("model.language_model.layers.0.linear_attn.conv1d.weight")==q::prepared::ParameterMeaning::kGdnConvolution,"Model lost sanitized gamma/conv meaning");
 const auto packed_bytes=q::take(model.weights.at(principal).tensor.description.required_bytes())+q::take(model.weights.at(embedding).tensor.description.required_bytes());
 require(packed_bytes==4096,"MLX tiny packed W footprint differs");
 require(model.score_precision_policy()=="mlx_affine_f32_weight_dot_bf16_projection_f32_logits","MLX tied head rounding policy differs");
''' +t[end:]
t=t.replace('model.attention_schema.capacity().query_type==q::Type::kFloat16&&model.attention_schema.capacity().output_type==q::Type::kFloat16','model.attention_schema.capacity().query_type==q::Type::kBFloat16&&model.attention_schema.capacity().output_type==q::Type::kBFloat16')
t=t.replace('"f16-', '"mlx-').replace('F16','MLX').replace('BMLX','BF16')
t=t.replace('untrained_tiny_GA_with_one_NF4_group','untrained_tiny_GA_MLX_packed_embedding_tied_head_and_projection')
t=t.replace('\\"activation\\":\\"MLX\\"','\\"activation\\":\\"BF16\\"').replace('\\"GDN_history\\":\\"MLX\\"','\\"GDN_history\\":\\"BF16\\"').replace('resident_NF4_numeric_bytes','resident_MLX_W_bytes')
(W/'ga.cc').write_bytes(t.encode())
# Build script reuses the exact original component217 closure. One new entry TU.
b=(W/'build.py').read_text().replace("A=W/'attempt3'","A=W/'ga2'").replace("W/'component.cc'","W/'ga.cc'")
b=b[:b.index("if '--run-cpu'")]+"env['PATH']=str(A/'link')+os.pathsep+r['PATH'];b.execute([str(A/'link/mlx.exe'),str(A/'fixture'),str(A/'actual'),'cpu'],A/'cpu-run',env,60)\n"
(W/'build-ga.py').write_bytes(b.encode())
