from pathlib import Path
import shutil,difflib
R=Path.cwd();W=R/'.scratch/mlx-ordinary-qwen-20261025/consumer';S=W/'source';B=W/'before'
for rel in('tests/tools/qwen_prepared_roles_test.cc','tests/tools/qwen_geometry_fixture.h','tests/tooling/qwen_hf_roles_test.py'):
 for d in(S,B):
  p=d/rel;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(R/rel,p)
p=S/'tests/tools/qwen_prepared_roles_test.cc';t=p.read_text();mark='} // namespace\n\nint main'
assert t.count(mark)==1
t=t.replace(mark,r'''void mlx_original_affine_names_and_effective_parameters(const fs::path &directory) {
  for (const unsigned bits : {4u, 8u}) {
    auto model = geometry; model.tied_head = bits == 4;
    const auto expected = p::parameter_inventory(false, model);
    std::string manifest = std::string(p::role_signature) + "\n" + identity + "\n" +
        qwen_test::geometry_line(model) + "\n" + p::mlx_policy_line(bits) + "\n";
    const auto original = [&](const std::string &logical) {
      return logical.starts_with("model.language_model.") ? "language_model.model." + logical.substr(21) : "language_model." + logical;
    };
    for (const auto &[name, parameter] : expected) {
      if (parameter.shape.size() == 2 && (parameter.linear || name == "model.language_model.embed_tokens.weight")) {
        const auto n = parameter.shape[0], k = parameter.shape[1];
        for (const auto &component : std::array<std::pair<std::string,std::vector<std::int64_t>>,3>{{
              {name,{n,k/32*bits}}, {name.substr(0,name.size()-7)+".scales",{n,k/64}},
              {name.substr(0,name.size()-7)+".biases",{n,k/64}}}}) {
          p::Role value; value.name = original(component.first); value.dtype = component.first == name ? "U32" : "BF16";
          value.shape = component.second; value.source = "original-mlx-not-read.bin"; value.bytes = p::physical_bytes(value.dtype,value.shape); manifest += row(value);
        }
      } else {
        p::Role value; value.name=original(name); value.dtype="BF16"; value.shape=parameter.shape;
        if(name.ends_with(".conv1d.weight")) value.shape={model.gdn_qkv_width(),model.conv_kernel,1};
        value.source="original-mlx-not-read.bin"; value.bytes=p::physical_bytes(value.dtype,value.shape); manifest+=row(value);
      }
    }
    const auto path=directory/("mlx-"+std::to_string(bits)+".tsv"); write(path,manifest); const auto parsed=p::read_roles(path,false);
    require(parsed.geometry==model && parsed.mlx_policy.bits==bits,"MLX ordinary geometry/policy differs");
    const auto find=[&](std::string_view name)->const p::Role&{const auto it=std::ranges::find(parsed.selected,name,&p::Role::name);if(it==parsed.selected.end())throw std::runtime_error("missing selected MLX role");return *it;};
    require(find("model.language_model.norm.weight").meaning==p::ParameterMeaning::kRmsEffectiveGamma,"MLX already-sanitized gamma must not get another +1");
    const auto &conv=find("model.language_model.layers.0.linear_attn.conv1d.weight");
    require(conv.shape==std::vector<std::int64_t>{model.gdn_qkv_width(),1,model.conv_kernel} && conv.bytes==static_cast<std::size_t>(model.gdn_qkv_width()*model.conv_kernel*2) && conv.meaning==p::ParameterMeaning::kGdnConvolution,"MLX singleton conv layout must preserve original bytes");
    require(find("model.language_model.layers.0.linear_attn.norm.weight").meaning==p::ParameterMeaning::kGdnEffectiveGamma && conv.physical_name=="language_model.model.layers.0.linear_attn.conv1d.weight","MLX provenance/direct GDN gamma lost");
    const auto &head=find(std::string(model.head_role()));
    require(head.projection_codec==p::ProjectionCodec::kMlxAffine && head.projection_group_size==64 && head.shape==std::vector<std::int64_t>{model.vocabulary,model.hidden/32*bits},"MLX tied/untied head must keep packed original operand");
    auto missing=manifest; const auto at=missing.find("language_model.model.embed_tokens.biases\t");const auto end=missing.find('\n',at);missing.erase(at,end-at+1);write(path,missing);
    rejects([&]{(void)p::read_roles(path,false);},"missing prepared role");
    write(path,manifest);rejects([&]{(void)p::read_roles(path,true);},"MLX reader cannot mix");
  }
}
} // namespace

int main''')
t=t.replace('    full_inventory_and_selection(directory);','    mlx_original_affine_names_and_effective_parameters(directory);\n    full_inventory_and_selection(directory);')
p.write_bytes(t.encode())
p=S/'tests/tooling/qwen_hf_roles_test.py';t=p.read_text();mark='class OriginalHfRolesTest(unittest.TestCase):\n'
assert t.count(mark)==1
t=t.replace(mark,mark+'''    def test_mlx_original_affine_reader_preserves_provenance_and_tied_head_math(self):
        for bits,tied in ((4,True),(8,False)):
            config=source_config();config['text_config']['tie_word_embeddings']=tied
            config['quantization']=dict(group_size=64,bits=bits,mode='affine')
            g=roles.geometry.from_hf(config);physical=[]
            for name,shape in roles.geometry.role_shapes(g,include_mtp=False).items():
                original='language_model.model.'+name[21:] if name.startswith('model.language_model.') else 'language_model.'+name
                if len(shape)==2:
                    n,k=shape
                    entries=((original,'U32',[n,k//32*bits]),(original[:-7]+'.scales','BF16',[n,k//64]),(original[:-7]+'.biases','BF16',[n,k//64]))
                else:
                    stored=[shape[0],shape[2],1] if name.endswith('.conv1d.weight') else list(shape)
                    entries=((original,'BF16',stored),)
                for key,dtype,dims in entries:
                    count=roles.ROLE_SIZES[dtype]
                    for d in dims:count*=d
                    physical.append(dict(name=key,dtype=dtype,shape=dims,bytes=count,path='original-mlx.bin',offset=0,sha256='3'*64))
            source=dict(complete=True,repository='test/original-mlx',revision='b'*40,roles=physical)
            lines,receipt=roles._prepare_role_records(source,False,config,lambda r:(Path(r['path']),None))
            self.assertIn('mlx_affine\\t'+str(bits)+'\\t64\\tBF16\\tF32\\tBF16', '\\n'.join(lines))
            self.assertTrue(any(x.startswith('language_model.model.embed_tokens.weight\\tU32')for x in lines))
            self.assertEqual(receipt['original_role_records'][0]['name'].split('.')[0],'language_model')
            self.assertEqual(receipt['geometry']['tied_head'],tied)
            self.assertEqual(receipt['mlx_affine_policy']['producer_version_verified'],False)
            broken=deepcopy(source);broken['roles']=[r for r in broken['roles']if r['name']!='language_model.model.embed_tokens.biases']
            with self.assertRaisesRegex(ValueError,'incomplete MLX'):roles._prepare_role_records(broken,False,config,lambda r:(Path('x'),None))
            broken=deepcopy(source);conv=next(r for r in broken['roles']if r['name'].endswith('conv1d.weight'));conv['shape']=[conv['shape'][0],1,conv['shape'][1]]
            with self.assertRaisesRegex(ValueError,'already sanitized'):roles._prepare_role_records(broken,False,config,lambda r:(Path('x'),None))

''')
p.write_bytes(t.encode())
patch=[]
for p in S.rglob('*'):
 if p.is_file() and (B/p.relative_to(S)).is_file():
  rel=p.relative_to(S);old=B/rel
  if p.read_bytes()!=old.read_bytes():patch+=difflib.unified_diff(old.read_text().splitlines(True),p.read_text().splitlines(True),fromfile='a/'+rel.as_posix(),tofile='b/'+rel.as_posix())
(W/'changes.patch').write_text(''.join(patch),encoding='utf-8',newline='\n')
