from pathlib import Path
import shutil, hashlib, json, difflib
R=Path.cwd(); W=R/'.scratch/mlx-ordinary-qwen-20261025'; S=W/'consumer/source'; B=W/'consumer/before'
resume=S.exists()
files=[*Path('engine/models/qwen35').glob('*.h'),*Path('engine/models/qwen35').glob('*.py'),*Path('engine/inference').glob('*.h'),*Path('engine/reporting').glob('*.h'),Path('engine/models/qwen35/main.cc')]
if not resume:
 for p in files:
  for d in(S,B):
   (d/p).parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(R/p,d/p)
old=R/'.scratch/nf4-packed-contraction-20261025/consumer/product-final/engine/models/qwen35/main.cc'
assert hashlib.sha256(old.read_bytes()).hexdigest()=='7ac7ae01c4b56632822689f2456fc46eed8f9003c7a7ba0e2ba852e647a18fca'
if not resume:
 for d in(S,B):shutil.copyfile(old,d/'engine/models/qwen35/main.cc')
def change(path, edits):
 p=S/'engine/models/qwen35'/path;t=(B/'engine/models/qwen35'/path).read_text()
 for a,b in edits:
  expected=2 if a=="name.startswith(('model.language_model.','mtp.','lm_head.'))" else 1
  assert t.count(a)==expected,(path,a[:110],t.count(a));t=t.replace(a,b)
 p.write_bytes(t.encode())
change('projection_binding.h',[
 ('struct Nf4Projection final {','struct MlxAffineProjection final {\n  Tensor *codes = nullptr, *scales = nullptr, *biases = nullptr;\n  hyle::compute::model_ops::MlxQuantized equation;\n};\nstruct Nf4Projection final {'),
 ('CtPackedProjection, Nf4Projection,','CtPackedProjection, MlxAffineProjection, Nf4Projection,')])
change('main.cc',[
 ('std::array<std::string_view, 16> known{','std::array<std::string_view, 17> known{'),
 ('".weight.nf4_offset", ".weight.quant_map"};','".weight.nf4_offset", ".weight.quant_map", ".biases"};'),
 ('} else if constexpr (std::is_same_v<Entry, Nf4Projection>) {','} else if constexpr (std::is_same_v<Entry, MlxAffineProjection>) {\n      const auto d = value.scales->description.dimensions(); return {d[0], d[1] * value.equation.group_size};\n    } else if constexpr (std::is_same_v<Entry, Nf4Projection>) {'),
 ('  if (stored->codec == Codec::kNvfp4) {','''  if (stored->codec == Codec::kMlxAffine) {
    detail::auxiliaries(bank, base, {".scales", ".biases"}, name);
    auto &scales = detail::require(bank, base + ".scales", name);
    auto &biases = detail::require(bank, base + ".biases", name);
    detail::matrix(scales, name);
    const auto group = stored->group_size;
    if (group != 64 || scales.description.data_type() != Type::kBFloat16)
      detail::fail(name, "selected MLX source requires original BF16 affine group64");
    const auto k = detail::packed_width(scales.description.dimensions()[1], group, name);
    const auto bits_numerator = detail::packed_width(stored->tensor.description.dimensions()[1], 32, name);
    if (bits_numerator % k || (bits_numerator / k != 4 && bits_numerator / k != 8))
      detail::fail(name, "selected MLX packed width requires exactly four or eight bits");
    const auto equation = ops::mlx_quantized_matmul(ops::MlxWeightFormat::kAffine,
        static_cast<std::uint32_t>(bits_numerator / k), group);
    detail::validate(equation, std::array{detail::activation(k, name), stored->tensor.description,
        scales.description, biases.description}, name);
    return MlxAffineProjection{&stored->tensor, &scales, &biases, equation};
  }
  if (stored->codec == Codec::kNvfp4) {'''),
 ('  if (std::holds_alternative<Nf4Projection>(binding)) return','  if (std::holds_alternative<MlxAffineProjection>(binding)) return "mlx_affine_f32_weight_dot_bf16_projection_f32_logits";\n  if (std::holds_alternative<Nf4Projection>(binding)) return'),
 ('    const auto original = weight_absolute(name);\n    const auto ids = spec(tokens), stored = spec(original);','''    const auto ids = spec(tokens);
    if (const auto found = projections.find(name); found != projections.end())
      if (const auto *mlx = std::get_if<MlxAffineProjection>(&found->second)) {
        if (activation_type() != Type::kBFloat16 || ids.rank() != 1 || ids.data_type() != Type::kInt32)
          throw std::runtime_error("MLX source embedding requires BF16 and checked I32 rows");
        const auto shape = projection_detail::logical_shape(found->second);
        if (shape[1] != hidden) throw std::runtime_error("MLX embedding logical width differs");
        // The embedding has typed BF16 product/add boundaries. Its tied head
        // reuses these original operands as a linear operation, not this table.
        return one(c::Operation::custom(c::model_ops::mlx_quantized_embedding(
            mlx->equation.bits, mlx->equation.group_size)),
            {operand(*mlx->codes), operand(*mlx->scales), operand(*mlx->biases), tokens},
            dense_spec(Type::kBFloat16, {ids.dimensions()[0], f(hidden)}));
      }
    const auto original = weight_absolute(name);
    const auto stored = spec(original);'''),
 ('      } else if constexpr (std::is_same_v<P, Nf4Projection>) {','''      } else if constexpr (std::is_same_v<P, MlxAffineProjection>) {
        if (activation_type() != Type::kBFloat16) throw std::runtime_error("MLX source projection requires BF16 activation");
        dimensions.back() = f(projection.scales->description.dimensions()[0]);
        return one(c::Operation::custom(projection.equation),
            {x, operand(*projection.codes), operand(*projection.scales), operand(*projection.biases)},
            dense_spec(Type::kBFloat16, dimensions));
      } else if constexpr (std::is_same_v<P, Nf4Projection>) {'''),
 ('  if (dtype == "I32") return Type::kInt32;','  if (dtype == "I32") return Type::kInt32;\n  if (dtype == "U32") return Type::kUInt32;'),
 ('  const std::string head(geometry.head_role());','''  // A quantized embedding must have a cold binding even with an untied head.
  const std::string embedding("model.language_model.embed_tokens.weight");
  if (bank.at(embedding).codec == prepared::ProjectionCodec::kMlxAffine && !bindings.contains(embedding))
    add(embedding, inventory.at(embedding));
  const std::string head(geometry.head_role());''')])
change('prepared_roles.h',[
 ('kCtLocalNvfp4, kNf4DoubleQuant, kCtAsymmetric4 };','kCtLocalNvfp4, kNf4DoubleQuant, kCtAsymmetric4, kMlxAffine };'),
 ('struct OriginalSource final {','''// Selected current-reader convention, not the artifact publisher's producer version.
inline constexpr std::string_view mlx_reader = "mlx-lm@4cfc6478473b0668ede3eb0cc93f2a9181a15052";
struct MlxAffinePolicy final { std::uint32_t bits = 0; bool enabled() const noexcept { return bits != 0; } };
inline std::string mlx_policy_line(std::uint32_t bits) {
  if (bits != 4 && bits != 8) throw std::runtime_error("selected MLX reader requires four or eight bits");
  return "mlx_affine\\t" + std::to_string(bits) + "\\t64\\tBF16\\tF32\\tBF16\\tsanitized_norm_conv\\t" + std::string(mlx_reader);
}
struct OriginalSource final {'''),
 ('  CtAsymmetricPolicy ct_asymmetric_policy{};','  CtAsymmetricPolicy ct_asymmetric_policy{};\n  MlxAffinePolicy mlx_policy{};'),
 ('if (dtype == "F32" || dtype == "I32") return 4;','if (dtype == "F32" || dtype == "I32" || dtype == "U32") return 4;'),
 ('// Both prepared file layouts enter through the same physical/logical contract.','''// MLX-LM's selected reader accepts this already-sanitized parameter convention.
// Only names and singleton convolution axes change; the original byte ranges,
// physical names and effective gamma remain intact, without a weight copy.
inline Role normalize_mlx_role(Role role, const ModelGeometry &geometry) {
  const auto original = role.name;
  if (original.starts_with("language_model.model.")) role.name = "model.language_model." + original.substr(21);
  else if (original.starts_with("language_model.lm_head.")) role.name = original.substr(15);
  else throw std::runtime_error("MLX manifest contains a non-text or unsupported role: " + original);
  role.physical_name = original;
  if (role.name.ends_with(".conv1d.weight")) {
    if (role.shape != std::vector<std::int64_t>{geometry.gdn_qkv_width(), geometry.conv_kernel, 1})
      throw std::runtime_error("MLX reader requires already-sanitized [C,kernel,1] convolution");
    role.shape = {geometry.gdn_qkv_width(), 1, geometry.conv_kernel};
    role.meaning = ParameterMeaning::kGdnConvolution;
  } else if (role.name.ends_with("linear_attn.norm.weight")) role.meaning = ParameterMeaning::kGdnEffectiveGamma;
  else if (role.name == "model.language_model.norm.weight" || role.name.ends_with(".input_layernorm.weight") ||
      role.name.ends_with(".post_attention_layernorm.weight") || role.name.ends_with(".q_norm.weight") || role.name.ends_with(".k_norm.weight"))
    role.meaning = ParameterMeaning::kRmsEffectiveGamma;
  return role;
}
// Both prepared file layouts enter through the same physical/logical contract.'''),
 ('                          CtAsymmetricPolicy ct_asymmetric_policy = {}) {','                          CtAsymmetricPolicy ct_asymmetric_policy = {}, MlxAffinePolicy mlx_policy = {}) {'),
 ('  result.ct_asymmetric_policy = ct_asymmetric_policy;','''  result.ct_asymmetric_policy = ct_asymmetric_policy;
  result.mlx_policy = mlx_policy;
  if (mlx_policy.enabled() && (include_mtp || float8_policy.enabled || ct_mixed_policy.enabled || nf4_policy.enabled ||
      ct_asymmetric_policy.enabled || bf16_cache_policy.omit_calibration || (mlx_policy.bits != 4 && mlx_policy.bits != 8)))
    throw std::runtime_error("selected MLX reader cannot mix precision or NextN policies");'''),
 ('    if (!role.physical_name.empty() || role.meaning != ParameterMeaning::kHfRaw || role.original_offset)','    if (!mlx_policy.enabled() && (!role.physical_name.empty() || role.meaning != ParameterMeaning::kHfRaw || role.original_offset))'),
 ('  std::size_t ct_asymmetric_groups = 0;','  std::size_t ct_asymmetric_groups = 0;\n  std::size_t mlx_groups = 0;'),
 ('    if (parameter.linear && (all.contains(name + std::string(nf4_state_suffix)) || nf4_states.contains(name))) {','''    if (all.contains(name) && all.at(name).dtype == "U32") {
      if (!mlx_policy.enabled() || parameter.shape.size() != 2 || (!parameter.linear && name != "model.language_model.embed_tokens.weight"))
        throw std::runtime_error("original MLX affine principal requires its selected reader policy: " + name);
      const auto n = parameter.shape[0], k = parameter.shape[1];
      if (k % 64) throw std::runtime_error("MLX group64 does not partition K");
      take(name, "U32", {n, k / 32 * mlx_policy.bits}, ProjectionCodec::kMlxAffine, 64);
      take(base + ".scales", "BF16", {n, k / 64}); take(base + ".biases", "BF16", {n, k / 64});
      ++mlx_groups;
    } else if (parameter.linear && (all.contains(name + std::string(nf4_state_suffix)) || nf4_states.contains(name))) {'''),
 ('  if (consumed.size() != all.size())','  if (mlx_policy.enabled() && !mlx_groups) throw std::runtime_error("MLX reader has no original affine groups");\n  if (consumed.size() != all.size())'),
 ('  CtAsymmetricPolicy ct_asymmetric_policy;','  CtAsymmetricPolicy ct_asymmetric_policy;\n  MlxAffinePolicy mlx_policy;'),
 ('    if (line.starts_with("nf4_double_quant")) {','''    if (line.starts_with("mlx_affine")) {
      if (line.ends_with('\\r')) line.pop_back();
      if (mlx_policy.enabled() || !all.empty() || float8_policy.enabled || ct_mixed_policy.enabled || nf4_policy.enabled || ct_asymmetric_policy.enabled ||
          (line != mlx_policy_line(4) && line != mlx_policy_line(8))) throw std::runtime_error("invalid or misplaced MLX reader policy");
      mlx_policy.bits = line == mlx_policy_line(4) ? 4u : 8u; continue;
    }
    if (line.starts_with("nf4_double_quant")) {'''),
 ('    role.bytes = bytes;\n    if (!all.emplace','    role.bytes = bytes;\n    if (mlx_policy.enabled()) role = normalize_mlx_role(std::move(role), geometry);\n    if (!all.emplace'),
 ('bf16_cache_policy, nf4_policy, nf4_states, ct_asymmetric_policy);','bf16_cache_policy, nf4_policy, nf4_states, ct_asymmetric_policy, mlx_policy);')])
change('precision_profile.h',[
 ('roles.ct_mixed_policy.enabled || roles.ct_asymmetric_policy.enabled ||','roles.ct_mixed_policy.enabled || roles.ct_asymmetric_policy.enabled || roles.mlx_policy.enabled() ||')])
# Python owns original names in the manifest and source identity. Only metadata
# geometry comparisons use the same selected sanitized reader convention.
change('prepare.py',[
 ('"I32": 4, "I64": 8','"I32": 4, "U32": 4, "I64": 8'),
 ('def ct_packed_groups(roles: dict[str, dict])','''MLX_READER = "mlx-lm@4cfc6478473b0668ede3eb0cc93f2a9181a15052"
MLX_CORE_READER = "mlx@2b2bb49790158ecd008d1685c94e3ef119792a00"

def mlx_affine_roles(roles, config, model_geometry):
    policy = config.get("quantization", {})
    if not any(r["dtype"] == "U32" for r in roles.values()):
        return roles, None
    if policy != dict(group_size=64, bits=policy.get('bits'), mode='affine') or policy.get('bits') not in (4,8) or model_geometry.get('gdn_layout') != 'grouped':
        raise ValueError("selected MLX source requires affine4/8 BF16 group64")
    normalized = {}
    for name,row in roles.items():
        if name.startswith('language_model.model.'):
            logical = 'model.language_model.' + name[21:]
        elif name.startswith('language_model.lm_head.'):
            logical = name[15:]
        else:
            raise ValueError('unsupported MLX text role: '+name)
        actual = dict(row)
        if name.endswith('.conv1d.weight'):
            if actual['shape'] != [2*model_geometry['gdn_key_heads']*model_geometry['gdn_key_depth']+model_geometry['gdn_value_heads']*model_geometry['gdn_value_depth'],model_geometry['conv_kernel'],1]:
                raise ValueError('MLX convolution must be already sanitized: '+name)
            actual['shape'] = [actual['shape'][0],1,actual['shape'][1]]
        if logical in normalized: raise ValueError('duplicate normalized MLX parameter')
        normalized[logical] = actual
    for name,row in normalized.items():
        if row['dtype'] != 'U32': continue
        base = name[:-7] if name.endswith('.weight') else None
        if base is None or len(row['shape']) != 2 or base+'.scales' not in normalized or base+'.biases' not in normalized:
            raise ValueError('incomplete MLX affine source group: '+name)
        sf,bias=normalized[base+'.scales'],normalized[base+'.biases']
        if sf['dtype'] != 'BF16' or bias['dtype'] != 'BF16' or sf['shape'] != bias['shape'] or len(sf['shape']) != 2 or row['shape'] != [sf['shape'][0],sf['shape'][1]*2*policy['bits']]:
            raise ValueError('MLX original affine geometry differs: '+name)
    return normalized, dict(bits=policy['bits'],group_size=64,mode='affine',activation_dtype='BF16',dot='F32 decoded affine weights and accumulation',embedding='BF16 multiply then BF16 add',reader=MLX_READER,core_reader=MLX_CORE_READER,parameters='already sanitized direct gamma and [C,kernel,1] convolution',producer_version_verified=False)

def ct_packed_groups(roles: dict[str, dict])'''),
 ('auxiliary = (".qzeros", ".scales", ".g_idx",','auxiliary = (".qzeros", ".scales", ".biases", ".g_idx",'),
 ('''            if row['dtype'] == 'U8' and len(actual) == 2 and name[:-7]+'.weight_scale_2' in roles:''','''            if row['dtype'] == 'U32' and name[:-7]+'.biases' in roles:
                actual = [roles[name[:-7]+'.scales']['shape'][0],roles[name[:-7]+'.scales']['shape'][1]*64]
            if row['dtype'] == 'U8' and len(actual) == 2 and name[:-7]+'.weight_scale_2' in roles:'''),
 ('not name.startswith(("model.language_model.", "mtp."))','not name.startswith(("model.language_model.", "mtp.", "language_model.model.", "language_model.lm_head."))'),
 ('    mixed = ct_mixed_groups(all_roles, config, model_geometry, fp8_reader, kv_cache_dtype)','''    normalized, mlx_policy = mlx_affine_roles(all_roles, config, model_geometry)
    if mlx_policy and (mtp or fp8_reader or kv_cache_dtype): raise ValueError('MLX reader cannot mix NextN or other precision policies')
    mixed = ct_mixed_groups(normalized, config, model_geometry, fp8_reader, kv_cache_dtype)'''),
 ('    nf4_groups = nf4_state.groups(all_roles, config, geometry.role_shapes(model_geometry))','    nf4_groups = nf4_state.groups(normalized, config, geometry.role_shapes(model_geometry))'),
 ('    validate_role_geometry(all_roles, model_geometry, omitted, nf4_groups)','    validate_role_geometry(normalized, model_geometry, omitted, nf4_groups)'),
 ('        identity["fp8_block128_policy"] = dict(FP8_POLICY)','        identity["fp8_block128_policy"] = dict(FP8_POLICY)'),
 ('    if nf4_groups:\n        identity[\'nf4_double_quant_policy\']','    if mlx_policy:\n        identity["mlx_affine_policy"] = mlx_policy\n    if nf4_groups:\n        identity[\'nf4_double_quant_policy\']'),
 ('    if nf4_groups:\n        policy_lines.append(nf4_state.POLICY_LINE)','    if mlx_policy:\n        policy_lines.append("\\t".join(("mlx_affine",str(mlx_policy["bits"]),"64","BF16","F32","BF16","sanitized_norm_conv",MLX_READER)))\n    if nf4_groups:\n        policy_lines.append(nf4_state.POLICY_LINE)'),
 ('    if fp8_groups:\n        receipt["fp8_block128_policy"]','    if mlx_policy:\n        receipt["mlx_affine_policy"] = mlx_policy\n        receipt["mlx_execution_scope"] = "selected current-reader parameter convention; packed projection/embedding/tied-head component verified separately; full source/model execution unverified"\n    if fp8_groups:\n        receipt["fp8_block128_policy"]'),
 ("name.startswith(('model.language_model.','mtp.','lm_head.'))","name.startswith(('model.language_model.','mtp.','lm_head.','language_model.model.','language_model.lm_head.'))")])
changed=[]
for p in S.rglob('*'):
 if not p.is_file():continue
 rel=p.relative_to(S);before=B/rel
 if p.read_bytes()!=before.read_bytes():
  changed.append(str(rel));
  with (W/'consumer/changes.patch').open('a',encoding='utf-8',newline='\n')as o:
   o.writelines(difflib.unified_diff(before.read_text().splitlines(True),p.read_text().splitlines(True),fromfile='a/'+rel.as_posix(),tofile='b/'+rel.as_posix()))
def pins(folder):return[dict(path=p.relative_to(folder).as_posix(),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())for p in folder.rglob('*')if p.is_file()]
(W/'consumer/source-pins.json').write_text(json.dumps(dict(changed=changed,before=pins(B),after=pins(S)),indent=2)+'\n')
print(json.dumps(dict(changed=changed),indent=2))
