from pathlib import Path
import json,hashlib,shutil,difflib
R=Path.cwd();C=R/'.scratch/mlx-ordinary-qwen-20261025/consumer';I=R/'.scratch/inference-mlx-ordinary-interface-20261025'
def pin(p):return dict(path=p.relative_to(R).as_posix(),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
integration=json.loads((I/'integration.json').read_bytes());summary=json.loads((I/'summary.json').read_bytes());assert summary['status']=='STRICT_MLX_NF4_SAMPLING_AND_SINGLETON_INTERFACE_PASS'
assert json.loads((I/'strict-final/process.json').read_bytes())['exit']==0
snapshot=C/'canonical-source';paths=[]
for row in integration['after']:
 p=R/row['path'];assert pin(p)['sha256']==row['sha256'];out=snapshot/row['path'];out.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,out);paths.append(out)
 private=C/'source'/row['path']
 if row['path']!='engine/models/qwen35/main.cc':assert private.read_text()==out.read_text()
old=(C/'source/engine/models/qwen35/main.cc').read_text();new=(snapshot/'engine/models/qwen35/main.cc').read_text()
changes=list(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='private-actual/main.cc',tofile='canonical-followup/main.cc'))
removed=[x for x in changes if x.startswith('-')and not x.startswith('---')];added=[x for x in changes if x.startswith('+')and not x.startswith('+++')]
assert len(removed)==2 and len(added)==1 and 'bucket.size() > 1' in added[0] and 'MTP committed budget cannot advance its selected request' in removed[1]
(C/'canonical-minus-private.patch').write_text(''.join(changes),encoding='utf-8',newline='\n');paths.append(C/'canonical-minus-private.patch')
for p in I.rglob('*'):
 if p.is_file()and p.suffix.lower()not in('.obj','.exe','.dll','.lib','.exp','.pdb','.map','.pyc'):paths.append(p)
followup=dict(status=summary['status'],canonical_main=next(x for x in integration['after']if x['path']=='engine/models/qwen35/main.cc'),actual_private_main=pin(C/'source/engine/models/qwen35/main.cc'),differences_from_actual_private_image='Only two pre-existing N1 singleton bucket admission source lines, preserved from canonical647; exact diff archived. Other six changed product/test files are normalized-text equal.',interface_summary=summary,interface_process=json.loads((I/'strict-final/process.json').read_bytes()),integration=integration,full_model_or_GPU_rerun=False,pins=[pin(p)for p in paths if p.parent==snapshot])
(C/'canonical-integration.json').write_text(json.dumps(followup,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
(C/'canonical-integration-files.json').write_text(json.dumps([p.relative_to(R).as_posix()for p in paths],indent=2)+'\n')
print(json.dumps(dict(files=len(paths),main=followup['canonical_main'],strict=followup['interface_process']),indent=2))
