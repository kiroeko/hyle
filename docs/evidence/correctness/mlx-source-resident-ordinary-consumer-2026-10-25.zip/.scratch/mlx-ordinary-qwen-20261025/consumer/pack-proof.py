from pathlib import Path
import json,hashlib,zipfile,difflib,sys
R=Path.cwd();W=R/'.scratch/mlx-ordinary-qwen-20261025';C=W/'consumer'
def read(p):return json.loads(p.read_bytes())
def pin(p):return dict(path=p.relative_to(R).as_posix(),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def save(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def result(folder):
 data=(folder/'stdout.log').read_text(encoding='utf-8');return json.loads([line for line in data.splitlines()if line.startswith('{"status":"PASS"')][-1])
cpu=C/'attempt3/cpu-run';cuda=C/'attempt3/cuda-run';ga=C/'ga2/cpu-run'
for p in(cpu,cuda,ga):assert read(p/'process.json')['exit']==0 and result(p)['status']=='PASS'
assert result(cpu)['checked_values']==result(cuda)['checked_values']==24690
assert read(C/'host2/summary.json')['status']=='PASS'
snapshot=[]
base=C/'ga2/actual/base-state';final=C/'ga2/actual/final-state'
for old in base.iterdir():
 if old.is_file():
  new=final/old.name;assert new.is_file();snapshot.append(dict(name=old.name,base=pin(old),after=pin(new),different=old.read_bytes()!=new.read_bytes(),base_nonzero_bytes=sum(b!=0 for b in old.read_bytes()),after_nonzero_bytes=sum(b!=0 for b in new.read_bytes())))
assert any(x['different']for x in snapshot if x['name'].startswith('gdn'))
retained=[]
for rel in ('host1/compute_provider_native--ct_packed/unit.obj','host1/graph_route_cpu--ct_packed_linear_region/unit.obj','host1/graph_route_cuda--ct_packed_linear_region/unit.obj','host1/compute_provider_torch_cuda--artifact_provider/unit.obj','cuda1/unit.obj'):
 retained.append(pin(R/'.scratch/nf4-packed-contraction-20261025'/rel))
baseline=pin(R/'.scratch/mtp-performance-convergence-20261025/baseline/link/hyle.exe');assert baseline['sha256']=='c343db76232c4b5bd34878820433057b8c23789cd1b170b6a3b86cd91bf82fa1'
closure=read(C/'attempt3/link/command.json')['command'];template=read(R/'.scratch/nf4-packed-contraction-20261025/component3/link/command.json')['command']
def normalize(args):return [a for a in args if not a.lower().startswith(('/out:','/pdb:','/map:','/implib:'))]
a=normalize(template);b=normalize(closure);deltas=[dict(position=i,before=x,after=y)for i,(x,y)in enumerate(zip(a,b))if x!=y];assert len(a)==len(b)and len(deltas)==1
summary=dict(status='PASS_ORIGINAL_COMPONENTS_AND_FINITE_ORDINARY_JOURNEY',scope='Ordinary Qwen selected MLX affine4/8 source-resident loader, linear, embedding and tied-head wiring; current selected reader parameter convention; no new MTP functions.',
 source=dict(cached_plan=pin(W/'source-role-plan.json'),payload_receipt=pin(W/'payload/complete.json'),source_archive=pin(R/'docs/evidence/research/fixed-role-binding-2026-10-21.zip'),producer_reader=read(W/'producer-source/receipt.json'),total_original_range_bytes=63232,original_parts=12,new_download_bytes_this_agent=0,full_LFS_hash_verified=False,publisher_producer_version_verified=False),
 metadata=read(C/'metadata-audit.json'),
 independent_oracle=read(C/'oracle/result.json'),
 actual=dict(original_CPU=dict(process=read(cpu/'process.json'),result=result(cpu)),original_CUDA=dict(process=read(cuda/'process.json'),result=result(cuda)),untrained_Model_CPU=dict(process=read(ga/'process.json'),result=result(ga),state=snapshot),host=dict(cpp_checks=370,python_tests=17,processes=read(C/'host2/summary.json'))),
 behavior=dict(activation='BF16',linear='original U32+BF16 affine scale/bias; F32 point multiply/add and dot, final BF16',embedding='checked selected IDs; BF16 product then BF16 add',tied_head='same original operands, independent linear equation; BF16 projection then F32 logits',direct_norm=True,convolution='already-sanitized [C,kernel,1] has the same bytes as [C,1,kernel]; descriptor only',engine_hot_allocation_sites_added=0,engine_cold_full_weight_bank_expansion_added=False,engine_hot_provider_lookup_added=False),
 failures=[dict(stage='private source preparation',kind='replacement-count assertion',effect='No compiler or inference started; fixed exact private text match'),dict(stage='attempt1 compile',kind='private new binding/helper API misuse',paths=['consumer/attempt1/compile'],effect='Operation convenience vs typed descriptor and Buffer create API corrected in private candidate'),dict(stage='attempt2 launch preparation',kind='private runner PATH key spelling',effect='No process launched by build.py; fixed runner uses original runtime PATH'),dict(stage='attempt2 actual CPU',kind='private component omitted independent Recipe dimension binding',paths=['consumer/attempt2/cpu-run'],effect='Graph correctly rejected before numeric submit; final consumer supplies original required exact ShapeBinding, no Graph/provider change'),dict(stage='host1 compile',kind='private test generator escaped newline',effect='Corrected generated C++ fixture only'),dict(stage='host2 first CPP run',kind='private frozen-source closure omitted existing171B NF4 JSON fixture',effect='Copied unchanged original fixture; same compiled host image then passed all370 checks'),dict(stage='ga1 actual CPU',kind='private generated manifest invalid BMLX dtype from text replacement',effect='Prepared parser correctly refused before loading; corrected only fixture text to BF16, product candidate unchanged')],
 execution_accounting=dict(successful_original_component_processes=2,successful_untrained_Model_processes=1,failed_component_CPU_pre_submit_processes=1,failed_untrained_CPU_before_weight_IO_processes=1,GPU_processes=1,GPU_released=True,additional_GPU_runs_planned=False),
 closure=dict(original_baseline=baseline,retained_five_leaves=retained,exact_entry_link_delta=deltas,CUDA_native_kernel_rebuilt=False,SDK_rebuilt=False,canonical_product_modified_by_agent=False,final_private_sources=read(C/'product-final/pins.json')),
 limits=['Q35/Q27 full selected headers/configs are metadata-only; no full original model, full source digest, benchmark or task-quality result.', 'The fixed current MLX-LM reader is authenticated; original artifact publisher producer-version equivalence is unknown.', 'Oracle is an independent source-equation NumPy F32/F64/typed-BF16 implementation, not execution of the upstream MLX runtime.', 'Sparse fixed original projection activations discriminate embedding-vs-linear rounding; they do not certify all arbitrary reduction orders bitwise.', 'CPU/CUDA Graph workspace6/12B is visible workspace only; provider-private transient backing is not measured.', 'A separate CPU untrained GA exercises ordinary Model state/sampling/restore/retirement and sanitized conventions, not original model quality or GPU state journey.', 'Apple/Vulkan MLX availability follows existing public provider support and is not newly executed in this batch.'])
save(C/'raw-summary.json',summary)
(C/'preparation-failures.txt').write_text('First private prepare-private.py stopped on AssertionError: prepare.py replacement ".qzeros", ".scales", ".g_idx", had3 matches. No build/run.\nFirst attempt2 build.py completed strict compile/link, then KeyError: path while constructing runtime env. No process launched by that invocation. Subsequent run.py used original runtime PATH.\nAll compiler and launched process failures have unchanged command/process/stdout/stderr and source snapshots in their original attempt directories.\n',encoding='utf-8')
paths=set()
def include(p):
 if p.is_file():paths.add(p)
def tree(folder):
 for p in folder.rglob('*'):
  if p.is_file() and '__pycache__'not in p.parts and p.suffix.lower()not in('.obj','.exe','.dll','.lib','.exp','.pdb','.map','.pyc'):include(p)
for name in('source-role-plan.json','payload/complete.json','producer-source/receipt.json','producer-source/qwen3_5.py','producer-source/qwen3_next.py','prepare-private.py','prepare-component.py','prepare-host-tests.py','prepare-ga.py'):include(W/name)
for p in read(W/'payload/complete.json')['parts']:include(R/p['path'])
for name in('source','before','oracle','product-final','host1','host2','attempt1','attempt2','attempt3','ga1','ga2'):tree(C/name)
for name in('component.cc','ga.cc','build.py','run.py','build-ga.py','check-host.py','finish-host.py','freeze-final.py','add-integration.py','pack-proof.py','publish-proof.py','changes.patch','metadata-audit.json','component-roles.json','component-roles.tsv','raw-summary.json','preparation-failures.txt'):include(C/name)
if (C/'canonical-integration.json').is_file():
 include(C/'canonical-integration.json');summary['canonical_integration_followup']=read(C/'canonical-integration.json')
 if (C/'canonical-integration-files.json').is_file():
  include(C/'canonical-integration-files.json')
  for name in read(C/'canonical-integration-files.json'):include(R/name)
 save(C/'raw-summary.json',summary)
def preference(p):
 text=p.relative_to(C).as_posix()if p.is_relative_to(C)else p.as_posix()
 return(0 if text.startswith('source/')else 1 if text.startswith('before/')else 2 if text.startswith('oracle/')else 3,text)
by_hash={};payload=[];unique=set()
for p in sorted(paths,key=preference):
 info=pin(p);canonical=by_hash.setdefault(info['sha256'],p);info['archive_path']=canonical.relative_to(R).as_posix();payload.append(info);unique.add(canonical)
save(C/'proof-payloads.json',payload);unique.add(C/'proof-payloads.json')
save(C/'source-payload-aliases.json',dict(method='SHA256+byte-exact aliases of duplicate frozen source/log/input payloads. Every original path is resolved by proof-payloads.json archive_path; no source/command/log semantics are omitted.',references=len(payload),unique_payloads=len(unique)-1,aliases=[dict(path=p['path'],archive_path=p['archive_path'],bytes=p['bytes'],sha256=p['sha256'])for p in payload if p['path']!=p['archive_path']]))
unique.add(C/'source-payload-aliases.json')
archive=C/'proof.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9)as z:
 for p in sorted(unique):z.write(p,p.relative_to(R).as_posix())
with zipfile.ZipFile(archive)as z:
 assert z.testzip()is None
 for item in payload:
  raw=z.read(item['archive_path']);assert len(raw)==item['bytes'] and hashlib.sha256(raw).hexdigest()==item['sha256']
cleanup=[]
for folder in('attempt1','attempt2','attempt3','ga1','ga2','host1','host2'):
 for p in(C/folder).rglob('*'):
  if p.is_file()and p.suffix.lower()in('.obj','.exe','.dll','.lib','.exp','.pdb','.map'):cleanup.append(pin(p))
save(C/'cleanup-candidates.json',dict(performed=False,files=cleanup,logical_bytes=sum(p['bytes']for p in cleanup),scope='Only newly generated MLX private entry/host binaries and private DLL hardlinks; original baseline, original DLL, five reused backend leaves, SDK, source/oracle/logs and model fragments retained.'))
public=dict(summary,archive=dict(path='docs/evidence/correctness/mlx-source-resident-ordinary-consumer-2026-10-25.zip',**{k:v for k,v in pin(archive).items()if k!='path'},CRC_verified=True,payload_count=len(unique),original_path_references=len(payload),duplicate_bytes_resolved_by='proof-payloads.json archive_path and source-payload-aliases.json'),cleanup=read(C/'cleanup-candidates.json'))
save(C/'proof-summary.json',public)
print(json.dumps(dict(archive=pin(archive),cleanup=dict(files=len(cleanup),logical_bytes=sum(p['bytes']for p in cleanup)),payload_count=len(unique),original_path_references=len(payload)),indent=2))
