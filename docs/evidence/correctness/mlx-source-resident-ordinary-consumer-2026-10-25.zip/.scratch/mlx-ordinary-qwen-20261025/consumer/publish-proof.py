from pathlib import Path
import json,hashlib,zipfile,shutil
R=Path.cwd();C=R/'.scratch/mlx-ordinary-qwen-20261025/consumer';proof=json.loads((C/'proof-summary.json').read_bytes());archive=C/'proof.zip'
assert hashlib.sha256(archive.read_bytes()).hexdigest()==proof['archive']['sha256'] and archive.stat().st_size==proof['archive']['bytes']
with zipfile.ZipFile(archive)as z:
 assert z.testzip()is None
 for item in json.loads(z.read('.scratch/mlx-ordinary-qwen-20261025/consumer/proof-payloads.json')):
  raw=z.read(item['archive_path']);assert len(raw)==item['bytes']and hashlib.sha256(raw).hexdigest()==item['sha256']
target=R/proof['archive']['path'];assert not target.exists();wrapper=target.with_suffix('.json');assert not wrapper.exists();shutil.copyfile(archive,target);shutil.copyfile(C/'proof-summary.json',wrapper)
assert hashlib.sha256(target.read_bytes()).hexdigest()==proof['archive']['sha256']
print(json.dumps(dict(wrapper=wrapper.relative_to(R).as_posix(),archive=proof['archive'],cleanup_files=len(proof['cleanup']['files']),cleanup_logical_bytes=proof['cleanup']['logical_bytes']),indent=2))
