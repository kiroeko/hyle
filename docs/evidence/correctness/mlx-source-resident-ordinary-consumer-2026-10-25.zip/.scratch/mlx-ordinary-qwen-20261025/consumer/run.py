from pathlib import Path
import importlib.util,os,sys
sys.dont_write_bytecode=True
R=Path.cwd();W=R/'.scratch/mlx-ordinary-qwen-20261025/consumer';A=W/'attempt3'
spec=importlib.util.spec_from_file_location('b',R/'.scratch/mtp-extraction-regression-20261024/check.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
r=b.read(R/'.scratch/mtp-performance-convergence-20261025/baseline/runtime.json');env=os.environ.copy();env['PATH']=str(A/'link')+os.pathsep+r['PATH'];mode=sys.argv[1]
assert mode in('cpu','cuda')
b.execute([str(A/'link/mlx.exe'),str(W.parent),mode],A/(mode+'-run'),env,60)
