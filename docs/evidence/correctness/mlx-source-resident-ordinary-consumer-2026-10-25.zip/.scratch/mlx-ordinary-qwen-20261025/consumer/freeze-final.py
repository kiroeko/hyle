from pathlib import Path
import json,hashlib,shutil,difflib
R=Path.cwd();W=R/'.scratch/mlx-ordinary-qwen-20261025/consumer';S=W/'source';B=W/'before';F=W/'product-final'
files=['engine/models/qwen35/main.cc','engine/models/qwen35/precision_profile.h','engine/models/qwen35/prepare.py','engine/models/qwen35/prepared_roles.h','engine/models/qwen35/projection_binding.h','tests/tooling/qwen_hf_roles_test.py','tests/tools/qwen_prepared_roles_test.cc']
def pin(p):return dict(path=p.relative_to(R).as_posix(),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
diff=[];pins=[]
for rel in files:
 p=S/rel;out=F/rel;out.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,out);pins.append(dict(relative_path=rel,**pin(p)))
 diff+=difflib.unified_diff((B/rel).read_text().splitlines(True),p.read_text().splitlines(True),fromfile='a/'+rel,tofile='b/'+rel)
(W/'changes.patch').write_text(''.join(diff),encoding='utf-8',newline='\n')
(F/'pins.json').write_text(json.dumps(dict(private_baseline_main='7ac7ae01c4b56632822689f2456fc46eed8f9003c7a7ba0e2ba852e647a18fca',canonical_untouched=True,files=pins),indent=2)+'\n')
print(json.dumps(dict(patch=pin(W/'changes.patch'),files=pins),indent=2))
