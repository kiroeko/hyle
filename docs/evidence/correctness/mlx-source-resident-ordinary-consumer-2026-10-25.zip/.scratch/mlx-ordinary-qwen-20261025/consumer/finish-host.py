from pathlib import Path
import importlib.util,sys,os,shutil
sys.dont_write_bytecode=True
R=Path.cwd();W=R/'.scratch/mlx-ordinary-qwen-20261025/consumer';S=W/'source';A=W/'host2'
fixture=Path('tests/tooling/fixtures/qwen_nf4_quant_state.json');(S/fixture).parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(R/fixture,S/fixture)
spec=importlib.util.spec_from_file_location('b',R/'.scratch/mtp-extraction-regression-20261024/check.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
env=b.environment(b.args(A/'compile/command.json')[0]);b.execute([str(A/'checks.exe'),str(A/'fixtures2')],A/'cpp-run2',env,30)
b.execute([sys.executable,str(S/'tests/tooling/qwen_hf_roles_test.py')],A/'python-run',os.environ.copy(),30)
b.save(A/'summary.json',dict(status='PASS',cpp=b.read(A/'cpp-run2/process.json'),python=b.read(A/'python-run/process.json'),initial_missing_fixture=True,sources=[b.pin(p)for p in (S/'tests/tools/qwen_prepared_roles_test.cc',S/'tests/tooling/qwen_hf_roles_test.py',S/'engine/models/qwen35/prepared_roles.h',S/'engine/models/qwen35/prepare.py')]))
