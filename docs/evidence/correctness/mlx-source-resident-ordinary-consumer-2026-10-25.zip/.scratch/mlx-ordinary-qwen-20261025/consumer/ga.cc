// Untrained ordinary MLX sanitized-role GA. CPU only; no full original model.
#include "engine/models/qwen35/main.cc"
#include "hyle/compute/detail/paged_arena_access.h"

namespace q = qwen35;
namespace c = q::c;
using Bytes = std::vector<std::byte>;
void require(bool yes, const char* message) { if (!yes) throw std::runtime_error(message); }
q::ModelGeometry geometry(bool cuda) {
  q::ModelGeometry s;
  s.hidden=64; s.intermediate=128; s.vocabulary=64;
  s.query_heads=s.kv_heads=1; s.key_depth=s.value_depth=s.rotary=64;
  s.gdn_key_heads=1; s.gdn_value_heads=cuda?2:1; s.gdn_key_depth=s.gdn_value_depth=64;
  s.conv_kernel=4; s.context_limit=16; s.rope_theta=10000; s.epsilon=1.e-6F;
  s.tied_head=true; s.layers="GA"; s.mtp_layers=0; s.validate(); return s;
}
std::pair<std::filesystem::path,std::size_t> weights(const std::filesystem::path& folder,const q::ModelGeometry& shape) {
 std::filesystem::create_directories(folder);const auto body=folder/"untrained-mlx.bin",list=folder/"weights.tsv";
 std::ofstream payload(body,std::ios::binary),manifest(list);require(bool(payload)&&bool(manifest),"cannot create MLX fixture");
 manifest<<"HYLE_QWEN_ROLE_FILES_V2\n"<<std::string(64,'7')<<"\ngeometry 64 128 64 1 1 64 64 64 1 1 64 64 4 16 10000 1e-6 1 0 grouped \"GA\"\n"<<q::prepared::mlx_policy_line(4)<<'\n';
 std::size_t offset=0,index=0;
 const auto bf=[](float v){auto bits=std::bit_cast<std::uint32_t>(v);bits+=0x7fffU+((bits>>16)&1U);return static_cast<std::uint16_t>(bits>>16);};
 const auto write=[&](const std::string& logical,const char*dtype,std::span<const std::int64_t>dims,std::span<const std::byte>bytes){
  const auto name=logical.starts_with("model.language_model.")?"language_model.model."+logical.substr(21):"language_model."+logical;
  payload.write(reinterpret_cast<const char*>(bytes.data()),static_cast<std::streamsize>(bytes.size()));manifest<<name<<' '<<dtype<<' '<<dims.size();for(auto d:dims)manifest<<' '<<d;manifest<<' '<<std::quoted(body.generic_string())<<' '<<offset<<' '<<bytes.size()<<'\n';offset+=bytes.size();
 };
 const std::string embedding="model.language_model.embed_tokens.weight",linear="model.language_model.layers.1.self_attn.k_proj.weight";
 for(const auto&[name,p]:q::prepared::parameter_inventory(false,shape)){
  if(name==embedding||name==linear){
   const auto n=p.shape[0],k=p.shape[1];std::vector<std::uint32_t> codes(static_cast<std::size_t>(n*k/8));for(std::size_t i=0;i<codes.size();++i)codes[i]=0x01234567U+static_cast<std::uint32_t>(i*0x1234567U);
   const std::array<std::int64_t,2> wshape{n,k/8},sshape{n,k/64};std::vector<std::uint16_t> scales(static_cast<std::size_t>(n*k/64),bf(.003F)),bias(scales.size(),bf(-.02F));
   write(name,"U32",wshape,std::as_bytes(std::span(codes)));const auto base=name.substr(0,name.size()-7);write(base+".scales","BF16",sshape,std::as_bytes(std::span(scales)));write(base+".biases","BF16",sshape,std::as_bytes(std::span(bias)));continue;
  }
  std::size_t count=1;for(auto d:p.shape)count*=std::size_t(d);auto dims=p.shape;if(name.ends_with(".conv1d.weight"))dims={shape.gdn_qkv_width(),shape.conv_kernel,1};
  if(name.ends_with(".A_log")){std::vector<float> values(count,0.F);write(name,"F32",dims,std::as_bytes(std::span(values)));}
  else {std::vector<std::uint16_t> values(count);for(std::size_t i=0;i<count;++i)values[i]=bf(p.shape.size()==1?(name.ends_with(".dt_bias")?0.F:1.F):.03F*std::sin(float(i+index*17)*.13F));write(name,"BF16",dims,std::as_bytes(std::span(values)));}++index;
 }
 require(bool(payload)&&bool(manifest)&&offset<1024*1024,"MLX fixture exceeds finite scope");return{list,offset};
}
Bytes read(q::Model& model,const c::ReadLease& lease) {
  if(!lease.valid())return{};
  Bytes result(lease.size());q::check(model.execution.read(q::take(lease.view()),result));return result;
}
void store(const std::filesystem::path& file,const Bytes& bytes) {
  std::filesystem::create_directories(file.parent_path());std::ofstream out(file,std::ios::binary);
  out.write(reinterpret_cast<const char*>(bytes.data()),static_cast<std::streamsize>(bytes.size()));
  require(bool(out),"cannot write actual state bytes");
}
Bytes logical_rows(q::Model& model,const c::PagedArena& arena,const c::PagedArenaRead& frame,std::size_t rows,std::size_t row_bytes) {
  const auto layout=frame.layout().host();const auto pages=(rows+15)/16;
  require(frame.valid()&&layout.page_indices.size()==pages&&frame.page_count()==pages,"logical state page footprint differs");
  Bytes result(rows*row_bytes);std::size_t at=0;
  const auto guards=c::detail::PagedArenaAccess::pages(frame);
  for(std::size_t i=0;i<pages;++i) {
    const c::ReadLease* selected=nullptr;
    for(const auto& guard:guards)if(q::take(c::detail::PagedArenaAccess::page(arena,guard))==static_cast<std::uint32_t>(layout.page_indices[i]))selected=&guard;
    require(selected!=nullptr,"logical page lost original read guard");
    const auto bytes=(std::min)(16*row_bytes,result.size()-at);
    q::check(model.execution.read(q::take(q::take(selected->view()).subview(0,bytes)),std::span(result).subspan(at,bytes)));at+=bytes;
  }
  return result;
}
using Image=std::map<std::string,Bytes>;
Image image(q::Model& model,const q::cache::Snapshot& head) {
  Image result;
  const auto add=[&](std::string name,const c::ReadLease& lease){if(lease.valid())result.emplace(std::move(name),read(model,lease));};
  for(std::size_t i=0;i<head.state.size();++i)if(model.geometry.is_gdn(i)) {
    add("gdn"+std::to_string(i)+".history.bf16",head.state[i].history);
    add("gdn"+std::to_string(i)+".recurrent.f32",head.state[i].recurrent);
  }
  for(std::size_t i=0;i<head.keys.size();++i) {
    result.emplace("target"+std::to_string(i)+".key.bf16",logical_rows(model,model.page_inventory.keys[i],head.keys[i],head.length,static_cast<std::size_t>(model.geometry.key_row_bytes())));
    result.emplace("target"+std::to_string(i)+".value.bf16",logical_rows(model,model.page_inventory.values[i],head.values[i],head.length,static_cast<std::size_t>(model.geometry.value_row_bytes())));
  }
  add("carry.bf16",head.carry_hidden);add("prior.bf16",head.prior_hidden);
  if(head.draft) {
    result.emplace("draft.key.bf16",logical_rows(model,model.draft_inventory.keys[0],head.draft->key,head.draft->frontier,static_cast<std::size_t>(model.geometry.key_row_bytes())));
    result.emplace("draft.value.bf16",logical_rows(model,model.draft_inventory.values[0],head.draft->value,head.draft->frontier,static_cast<std::size_t>(model.geometry.value_row_bytes())));
  }
  std::ostringstream meta;
  meta<<"length="<<head.length<<" next="<<head.next_id<<" seed="<<head.sampling.seed<<" stream="<<head.sampling.stream<<" draw="<<head.sampling.draw;
  if(head.draft)meta<<" frontier="<<head.draft->frontier<<" lag="<<head.draft->lag<<" catchup="<<head.draft->catchup_token;
  const auto text=meta.str();result.emplace("metadata.txt",Bytes(reinterpret_cast<const std::byte*>(text.data()),reinterpret_cast<const std::byte*>(text.data()+text.size())));return result;
}
void dump(const std::filesystem::path& folder,const Image& data){for(const auto& [name,bytes]:data)store(folder/name,bytes);}
void retire(std::shared_ptr<q::Session>& session){q::check(session->stop());q::check(session->drain());require(q::take(session->try_retire()),"session retirement incomplete");session.reset();}
int main(int argc,char**argv){try{
 require(argc==4,"ga FIXTURE OUTPUT cpu");const bool cuda=false;require(std::string_view(argv[3])=="cpu","this finite journey is CPU only");const auto shape=geometry(cuda);const auto fixture=weights(argv[1],shape);const std::filesystem::path out=argv[2];std::filesystem::create_directories(out);
 const auto plan=q::cache::plan(shape,16,4,3,q::recurrent_bytes(q::state_schema_for(shape,16),shape),1,2,false,true);
 q::Model model(fixture.first,shape,16,plan,{},false,q::ReplayPolicy::kCommands,16*1024*1024,{.enabled=true,.policy={1.F,8,.9F},.seed=123},0,{.primary=cuda?hyle::inference::BackendKind::kCuda:hyle::inference::BackendKind::kCpu});
 require(!model.precision.is_f16()&&model.state_schema[0].history.data_type()==q::Type::kBFloat16&&model.state_schema[0].recurrent.data_type()==q::Type::kFloat32,"typed MLX GDN state schema differs");
 const std::string principal="model.language_model.layers.1.self_attn.k_proj.weight",embedding="model.language_model.embed_tokens.weight";
 require(model.weights.at(principal).codec==q::prepared::ProjectionCodec::kMlxAffine&&model.weights.at(principal).tensor.description.data_type()==q::Type::kUInt32,"resident MLX source lost original packing");
 require(std::holds_alternative<q::MlxAffineProjection>(model.projections.at(principal))&&std::holds_alternative<q::MlxAffineProjection>(model.projections.at(embedding)),"cold MLX projection/embedding binding missing");
 require(model.weight_meanings.at("model.language_model.norm.weight")==q::prepared::ParameterMeaning::kRmsEffectiveGamma&&model.weight_meanings.at("model.language_model.layers.0.linear_attn.conv1d.weight")==q::prepared::ParameterMeaning::kGdnConvolution,"Model lost sanitized gamma/conv meaning");
 const auto packed_bytes=q::take(model.weights.at(principal).tensor.description.required_bytes())+q::take(model.weights.at(embedding).tensor.description.required_bytes());
 require(packed_bytes==4096,"MLX tiny packed W footprint differs");
 require(model.score_precision_policy()=="mlx_affine_f32_weight_dot_bf16_projection_f32_logits","MLX tied head rounding policy differs");
 const std::array chunks{std::size_t{2},std::size_t{1}};const std::array decode{std::size_t{1}};model.prepare_family(chunks);model.plan_execution(chunks);model.plan_replay_uses(1,1,2);
 require(model.attention_schema.capacity().query_type==q::Type::kBFloat16&&model.attention_schema.capacity().output_type==q::Type::kBFloat16,"typed attention schema differs");
 auto session=model.create_session(chunks);const std::array<std::int32_t,2> prompt{1,2};const auto first=q::evaluate(model,*session,prompt,"mlx-P2",out,true);auto base=session->head;
 const auto saved=image(model,*base);dump(out/"base-state",saved);require(base->length==2&&base->sampling.draw==1&&!base->draft,"ordinary prefill boundary differs");
 require(std::ranges::any_of(saved.at("gdn0.history.bf16"),[](std::byte b){return b!=std::byte{};})&&std::ranges::any_of(saved.at("gdn0.recurrent.f32"),[](std::byte b){return b!=std::byte{};}),"MLX GA state witness is all zero");
 const std::array pending{first};const auto next=q::evaluate(model,*session,pending,"mlx-T1",out,true);require(session->head->length==3&&session->head->sampling.draw==2,"ordinary decode boundary differs");
 require(saved==image(model,*base),"old MLX Snapshot changed after decode");const auto after=image(model,*session->head);dump(out/"final-state",after);
 auto restored=model.create_session(decode,base);require(restored->head->next_id==first&&restored->head->sampling==base->sampling,"same-request restore lost pending/cursor");const auto repeat=q::evaluate(model,*restored,pending,"mlx-restored-T1",{},false);require(repeat==next&&image(model,*restored->head)==after,"same-request MLX state/RNG restore differs");retire(restored);
 const q::cache::SamplingCursor own{321,99,0};auto fresh=model.create_session(decode,base,q::GraphRole::kText,own,true);require(fresh->head->sampling.seed==321&&fresh->head->sampling.stream==99&&fresh->head->sampling.draw==1&&saved==image(model,*base),"new-request MLX frontier sampling mutated original prefix");retire(fresh);
 const auto peak=model.cache_usage().peak_bytes;require(peak<=16*1024*1024,"MLX cache budget escaped");base.reset();retire(session);require(!model.active_step&&!model.carrier_borrowed&&model.snapshot_versions.live==0,"MLX original resources not retired");
 std::cout<<"{\"status\":\"PASS\",\"backend\":\""<<(cuda?"CUDA":"CPU")<<"\",\"source\":\"untrained_tiny_GA_MLX_packed_embedding_tied_head_and_projection\",\"fixture_bytes\":"<<fixture.second<<",\"activation\":\"BF16\",\"GDN_history\":\"BF16\",\"GDN_recurrent\":\"F32\",\"ordinary_ids\":["<<first<<','<<next<<"],\"actual_decode_replay_same_request\":true,\"fresh_prefix_own_stream\":true,\"old_snapshot_unchanged\":true,\"sampling_draw\":2,\"cache_peak\":"<<peak<<",\"full_original_model\":false,\"source_operands_resident\":true,\"resident_MLX_W_bytes\":"<<packed_bytes<<",\"GPU_runs\":"<<(cuda?1:0)<<"}\n";return 0;
}catch(const std::exception&e){std::cerr<<"MLX GA: "<<e.what()<<'\n';return 1;}}
