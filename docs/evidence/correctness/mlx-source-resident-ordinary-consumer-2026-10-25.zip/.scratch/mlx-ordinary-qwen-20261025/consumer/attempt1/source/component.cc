#include "engine/models/qwen35/main.cc"

namespace q=qwen35;
namespace c=q::c;
namespace g=q::g;
namespace inf=hyle::inference;
using Bytes=std::vector<std::byte>;
void require(bool yes,const char* message){if(!yes)throw std::runtime_error(message);}
Bytes bytes(const std::filesystem::path& file){std::ifstream in(file,std::ios::binary|std::ios::ate);require(bool(in),"cannot open component bytes");const auto n=in.tellg();require(n>=0,"invalid input size");Bytes out(static_cast<std::size_t>(n));in.seekg(0);in.read(reinterpret_cast<char*>(out.data()),n);require(bool(in),"short component read");return out;}
struct OriginalRole {unsigned index,bits;q::prepared::Role role;};
std::vector<OriginalRole> roles(const std::filesystem::path& file){
 std::ifstream input(file);require(bool(input),"cannot open exact role manifest");std::vector<OriginalRole> result;std::string line;
 while(std::getline(input,line)){std::istringstream row(line);OriginalRole item;std::size_t rank;std::string path;row>>item.index>>item.bits>>item.role.name>>item.role.dtype>>rank;for(std::size_t i=0;i<rank;++i){std::int64_t dim;row>>dim;item.role.shape.push_back(dim);}row>>std::quoted(path)>>item.role.bytes;require(bool(row),"invalid exact role manifest");item.role.source=path;require(q::prepared::physical_bytes(item.role.dtype,item.role.shape)==item.role.bytes,"source role physical count differs");result.push_back(std::move(item));}return result;
}
c::ReadLease upload(const inf::Backend& backend,std::span<const std::byte> data){auto buffer=q::take(hyle::mem::Buffer::allocate(backend.device(),data.size(),256));q::check(backend.write(buffer.view(),data));c::ReadLease read;q::check(backend.freeze(buffer,read));return read;}
int main(int argc,char**argv){try{
 require(argc==3,"mlx-component ROOT cpu|cuda");const std::filesystem::path root=argv[1];const bool cuda=std::string_view(argv[2])=="cuda";
 const auto all=roles(root/"consumer/component-roles.tsv");require(all.size()==12,"expected exactly original twelve ranges");
 auto backend=q::take(inf::Backend::create({.primary=cuda?inf::BackendKind::kCuda:inf::BackendKind::kCpu},{256u<<20,256u<<20,64u<<20}));
 const std::string linear="model.language_model.layers.0.linear_attn.in_proj_a.weight",embedding="model.language_model.embed_tokens.weight";
 std::size_t checked=0;std::cout<<"{\"status\":\"PASS\",\"backend\":\""<<(cuda?"CUDA":"CPU")<<"\",\"cases\":[";bool first=true;
 for(unsigned index:{4u,5u}){
  std::ifstream geometry_input(root/"consumer/oracle"/(std::to_string(index)+"-geometry.txt"));std::string geometry_line;std::getline(geometry_input,geometry_line);auto geometry=q::read_model_geometry(geometry_line);
  q::prepared::Roles selected;selected.identity=std::string(64,'e');selected.geometry=geometry;selected.mlx_policy.bits=index==4?4u:8u;
  for(const auto& item:all)if(item.index==index){auto role=q::prepared::normalize_mlx_role(item.role,geometry);if(role.dtype=="U32"){role.projection_codec=q::prepared::ProjectionCodec::kMlxAffine;role.projection_group_size=64;}selected.bytes+=role.bytes;selected.selected.push_back(std::move(role));}
  require(selected.selected.size()==6,"component did not select exactly two affine triples");
  std::map<std::string,q::LoadedWeight> bank;std::vector<c::LeasePool> owners;const auto loading=q::load_selected_weight_roles(selected,backend,bank,owners);
  require(bank.size()==6&&loading.canonical_bytes==selected.bytes,"original MLX loader changed bank/bytes");
  q::ProjectionBindings bindings;bindings.emplace(linear,q::resolve_projection(bank,linear));bindings.emplace(embedding,q::resolve_projection(bank,embedding));
  require(q::projection_detail::logical_shape(bindings.at(linear))==std::array<std::int64_t,2>{16,2048},"original linear logical shape differs");
  require(q::projection_detail::logical_shape(bindings.at(embedding))==std::array<std::int64_t,2>{3,2048},"selected original vocabulary row tile differs");
  const auto activation=bytes(root/"consumer/oracle"/(std::to_string(index)+"-a.bf16"));
  const auto expected_linear=bytes(root/"consumer/oracle"/(std::to_string(index)+"-linear-linear.bf16"));
  const auto expected_head=bytes(root/"consumer/oracle"/(std::to_string(index)+"-embedding-linear.bf16"));
  const auto expected_embedding=bytes(root/"consumer/oracle"/(std::to_string(index)+"-embedding.bf16"));
  for(std::size_t rows=1;rows<=2;++rows){
   q::GraphAssembly assembly(backend);q::Recipe recipe(bank,bindings,assembly,geometry,rows);
   const auto ad=q::dense(q::Type::kBFloat16,{std::int64_t(rows),2048}),id=q::dense(q::Type::kInt32,{3});
   const auto a=recipe.input(ad),ids=recipe.input(id);const auto y=recipe.linear_absolute(a,linear),e=recipe.embedding(ids,embedding),h=recipe.scores(a,embedding);
   for(const auto out:{y,e,h})recipe.publish(out);auto graph=q::take(std::move(recipe.builder).finish());
   auto compiled=q::take(backend.compile(graph,assembly.constants,assembly.options({})));
   const std::array ports{y,e,h};std::array<inf::PreparedOutputFacts,3> facts;std::array<c::LeasePool,3> pools;std::array<c::WriteLease,3> writers;
   for(std::size_t i=0;i<3;++i){facts[i]=q::take(inf::prepare_output(compiled,ports[i]));if(facts[i].caller_owned()){const auto n=q::take(facts[i].description.required_bytes());pools[i]=q::take(c::LeasePool::create(q::take(backend.resource_for(facts[i].storage)),n,{.max_blocks=1}));writers[i]=q::take(pools[i].allocate(n));}}
   auto av=upload(backend,std::span(activation).first(rows*2048*2));const std::array<std::int32_t,3> token_ids{0,1,2};auto iv=upload(backend,std::as_bytes(std::span(token_ids)));
   auto run=q::take(compiled.executable.create_invocation());q::check(run.prepare_resources());q::check(run.bind(a,ad,av));q::check(run.bind(ids,id,iv));for(std::size_t i=0;i<3;++i)if(facts[i].caller_owned())q::check(run.bind(ports[i],facts[i].description,std::move(writers[i])));
   auto prepared=q::take(inf::prepare_queue_bindings(backend.queue_bindings(),compiled.report));const auto queues=inf::queue_span(prepared);q::check(run.prepare_replay(queues,{.mode=g::ReplayMode::kCommands,.host_wait=g::HostWaitPolicy::kAllow}));auto completion=q::take(run.submit(queues));q::check(completion.wait());
   for(std::size_t i=0;i<3;++i){auto result=q::take(inf::retain_output(run,facts[i]));Bytes got(q::take(facts[i].description.required_bytes()));q::check(backend.read(q::take(result.view()),got));
    if(i==0)require(got.size()==rows*16*2&&std::equal(got.begin(),got.end(),expected_linear.begin()),"MLX original linear differs from independent SIMD F32 equation oracle");
    else if(i==1)require(got==expected_embedding,"MLX embedding differs from independent typed BF16 two-round oracle");
    else {require(got.size()==rows*3*4,"MLX tied-head output type/extent differs");for(std::size_t j=0;j<rows*3;++j){std::uint16_t bf;float actual;std::memcpy(&bf,expected_head.data()+j*2,2);std::memcpy(&actual,got.data()+j*4,4);require(std::bit_cast<std::uint32_t>(actual)==std::uint32_t(bf)<<16,"MLX tied head did not use original affine linear BF16->F32 equation");}}
    checked+=got.size()/(i==2?4:2);
   }
   if(!first)std::cout<<',';first=false;std::cout<<"{\"bits\":"<<selected.mlx_policy.bits<<",\"rows\":"<<rows<<",\"original_numeric_tensors\":6,\"original_bytes\":"<<selected.bytes<<",\"workspace\":"<<compiled.executable.workspace_bytes()<<",\"steps\":[";
   for(std::size_t i=0;i<compiled.report.step_count();++i){const auto step=q::take(compiled.report.step(i));if(i)std::cout<<',';std::cout<<"{\"provider\":\""<<step.provider.name<<"\",\"nodes\":"<<step.node_count<<'}';}std::cout<<"]}";
   q::check(run.close());q::check(backend.drain_retired(run));
  }
 }
 std::cout<<"],\"checked_values\":"<<checked<<",\"projection\":\"F32_affine_dot_BF16\",\"embedding\":\"BF16_multiply_then_BF16_add\",\"tied_head\":\"packed_linear_BF16_then_F32\",\"whole_model\":false,\"new_download_bytes\":0}\n";return 0;
}catch(const std::exception&e){std::cerr<<"MLX original component: "<<e.what()<<'\n';return 1;}}
