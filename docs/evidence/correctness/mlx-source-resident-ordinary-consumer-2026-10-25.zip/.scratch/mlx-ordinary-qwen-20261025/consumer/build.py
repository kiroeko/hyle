from pathlib import Path
import importlib.util,json,sys,os,shutil
sys.dont_write_bytecode=True
R=Path.cwd();W=R/'.scratch/mlx-ordinary-qwen-20261025/consumer';A=W/'attempt3';A.mkdir();S=A/'source';shutil.copytree(W/'source',S);shutil.copyfile(W/'component.cc',S/'component.cc')
spec=importlib.util.spec_from_file_location('b',R/'.scratch/mtp-extraction-regression-20261024/check.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
b.save(A/'pins.json',[b.pin(p)for p in S.rglob('*')if p.is_file()])
base=b.args(R/'.scratch/inference-system-review-20261025/text-r2-suffix/compile/command.json');cmd=[base[0],'/I'+str(S)];skip=False
for arg in base[1:]:
 if skip:skip=False;continue
 if arg=='/sourceDependencies':skip=True;continue
 low=arg.lower().replace('\\','/')
 if low.startswith(('/fo','/fd'))or low.endswith(('.cc','.cpp')):continue
 if low.startswith(('/i','-i'))and'/.scratch/'in low and low.endswith('/source'):continue
 cmd.append(arg)
cmd+=['/sourceDependencies',str(A/'compile/dependencies.json'),str(S/'component.cc'),'/Fo'+str(A/'compile/unit.obj'),'/Fd'+str(A/'compile/unit.pdb')]
env=b.environment(base[0]);b.execute(cmd,A/'compile',env,120)
link=[];old=str(R/'.scratch/nf4-packed-contraction-20261025/component3/compile/component.obj');found=0
for arg in b.args(R/'.scratch/nf4-packed-contraction-20261025/component3/link/command.json'):
 if arg.lower().startswith(('/out:','/map:','/pdb:','/implib:')):continue
 if arg==old:arg=str(A/'compile/unit.obj');found+=1
 link.append(arg)
assert found==1
link+=['/OUT:'+str(A/'link/mlx.exe'),'/PDB:'+str(A/'link/mlx.pdb'),'/IMPLIB:'+str(A/'link/mlx.lib')];b.execute(link,A/'link',env,60)
r=b.read(R/'.scratch/mtp-performance-convergence-20261025/baseline/runtime.json');native=Path(r['native']['path']);os.link(native,A/'link'/native.name)
b.save(A/'runtime.json',dict(image=b.pin(A/'link/mlx.exe'),native=b.pin(native),GPU_not_started=True,entry_and_5_Hyle_leaf_replacements=True))
if '--run-cpu' in sys.argv:
 env['PATH']=str(A/'link')+os.pathsep+r['PATH'];b.execute([str(A/'link/mlx.exe'),str(W.parent),'cpu'],A/'cpu-run',env,60)
