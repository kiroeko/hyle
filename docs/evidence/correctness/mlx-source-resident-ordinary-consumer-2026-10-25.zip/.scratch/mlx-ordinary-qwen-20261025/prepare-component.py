from pathlib import Path
import json,hashlib,struct,importlib.util,sys,zipfile,re
import numpy as np
R=Path.cwd();W=R/'.scratch/mlx-ordinary-qwen-20261025';C=W/'consumer';O=C/'oracle';O.mkdir(exist_ok=True)
def save(p,v):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,indent=2)+'\n')
def pin(p):return dict(path=p.relative_to(R).as_posix(),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
sys.path.insert(0,str(C/'source/engine/models/qwen35'))
import prepare as q
receipt=json.loads((W/'payload/complete.json').read_bytes());assert receipt['status']=='EXACT_MLX_4_8_ROLE_COMPONENTS_ACQUIRED'
archive=R/'docs/evidence/research/fixed-role-binding-2026-10-21.zip'
assert pin(archive)['sha256']=='afc43569ab74af8b94fbba9a1f93265e687498cbc943c92f43804d56533268fd'
reader=R/'.scratch/validation/cpu-quant-mtp-c1/non-gguf/mlx-cpu-quantized.cpp'
assert pin(reader)['sha256']=='8890160da0a884b559aad18ce20a2b08170b721c38ce1c800229ae9998ed846d'
up=R/'.scratch/validation/cpu-quant-mtp-c1/non-gguf/mlx-quantized.py'
assert pin(up)['sha256']=='8ca4574a212f14cbec4c446826474583ef0bf1e2cb1630574fd730c77af03b33'
(O/'original-cpu-reader.txt').write_text(reader.read_text()[reader.read_text().index('template <typename T, int bits, int group_size>\nvoid _qmm_t_simd'):reader.read_text().index('template <typename T, int bits, int group_size>\nvoid _qmm_dispatch_transpose')])
(O/'original-embedding-reader.txt').write_text(up.read_text()[up.read_text().index('    def __call__(self, x):'):up.read_text().index('    def _extra_repr(self):',up.read_text().index('    def as_linear(self, x):'))])
def f32bf(x):
 v=np.asarray(x,dtype='<f4').view('<u4');return ((v+np.uint32(0x7fff)+((v>>16)&1))>>16).astype('<u2')
def bf32(v):return (np.asarray(v,dtype='<u2').astype('<u4')<<16).view('<f4')
def original_values(words,s,b,bits):
 k=s.shape[1]*64
 shifts=np.arange(0,32,bits,dtype=np.uint32)
 codes=((words[:,:,None]>>shifts)&np.uint32((1<<bits)-1)).reshape(words.shape[0],k)
 sf=np.repeat(bf32(s),64,axis=1);bias=np.repeat(bf32(b),64,axis=1)
 product=codes.astype('<f4')*sf
 # Original SIMD affine qmm: F32 wf*scale then +bias before F32 dot.
 linear=(product+bias).astype('<f4')
 # Original dequantize result dtype follows scales. Product and sum are two
 # distinct BF16 tensor operations in the source embedding reader.
 embedding=f32bf(bf32(f32bf(product))+bias)
 return linear,embedding
allmeta=[];result=[];manifest=[]
with zipfile.ZipFile(archive)as z:
 for idx,bits in [(4,4),(5,8),(11,4),(12,8)]:
  config=json.loads(z.read(f'mlx/{idx}/config.json'));g=q.geometry.from_hf(config)
  h={}
  for name in z.namelist():
   if name.startswith(f'mlx/{idx}/headers/')and name.endswith('.header.json'):
    part=json.loads(z.read(name));part.pop('__metadata__',None);assert not(set(h)&set(part));h.update(part)
  full={name:dict(dtype=row['dtype'],shape=row['shape'])for name,row in h.items()if name.startswith(('language_model.model.','language_model.lm_head.'))}
  normalized,policy=q.mlx_affine_roles(full,config,g);q.validate_role_geometry(normalized,g)
  dense=[n for n,row in normalized.items()if row['dtype']!='U32'and not n.endswith(('.scales','.biases'))]
  assert all(row['dtype']=='BF16' or name.endswith('.A_log')and row['dtype']=='F32' for name,row in normalized.items()if name in dense)
  allmeta.append(dict(catalog_index=idx,text_physical_roles=len(full),affine_groups=sum(x['dtype']=='U32'for x in full.values()),dense_parameters=len(dense),tied_head=g['tied_head'],policy=policy,logical_inventory=len(q.logical_roles(normalized)),full_header_only=True,payload_verified=False))
  if idx not in(4,5):continue
  parts=[p for p in receipt['parts']if p['catalog_index']==idx]
  roleparts={p['original_role']['role']:p for p in parts};assert len(roleparts)==6
  for p in parts:
   assert pin(R/p['path'])['sha256']==p['sha256'] and pin(R/p['path'])['bytes']==p['bytes']
   manifest.append(dict(index=idx,bits=bits,name=p['original_role']['role'],shape=p['original_role']['selected_shape'],dtype=p['original_role']['dtype'],bytes=p['bytes'],path=p['path'],sha256=p['sha256']))
  a=np.zeros((2,2048),dtype='<f4');a[0,[0,1,2047]]=[.25,-.125,.5];a[1,[0,1,2047]]=[-.5,.125,.25]
  ab=f32bf(a);ab.tofile(O/f'{idx}-a.bf16')
  (O/f'{idx}-geometry.txt').write_text(q.geometry.line(g)+'\n')
  for short,module in [('linear','language_model.model.layers.0.linear_attn.in_proj_a'),('embedding','language_model.model.embed_tokens')]:
   def values(suffix,dtype):
    p=roleparts[module+suffix];return np.frombuffer((R/p['path']).read_bytes(),dtype=dtype).reshape(p['original_role']['selected_shape'])
   w=values('.weight','<u4');s=values('.scales','<u2');b=values('.biases','<u2');d,e=original_values(w,s,b,bits)
   y64=a.astype('<f8')@d.astype('<f8').T;y32=(a@d.T).astype('<f4');y=f32bf(y64.astype('<f4'))
   assert np.array_equal(y,f32bf(y32)), 'Fixed sparse dot had an ambiguous BF16 accumulation boundary'
   y.tofile(O/f'{idx}-{short}-linear.bf16');d.tofile(O/f'{idx}-{short}-affine.f32')
   item=dict(index=idx,bits=bits,kind=short,logical_shape=list(d.shape),linear_values=y.size,f64_vs_f32_final_bf16_equal=True)
   if short=='embedding':
    e.tofile(O/f'{idx}-embedding.bf16')
    wrong=f32bf(a.astype('<f8')@bf32(e).astype('<f8').T)
    item.update(embedding_values=e.size,typed_embedding_vs_qmm_weight_different=int(np.count_nonzero(bf32(e)!=d)),wrong_tied_head_changed=int(np.count_nonzero(wrong!=y)))
    assert item['typed_embedding_vs_qmm_weight_different']>0 and item['wrong_tied_head_changed']>0
   result.append(item)
save(C/'component-roles.json',manifest);save(C/'metadata-audit.json',allmeta)
lines=[]
for r in manifest:
 lines.append('\t'.join((str(r['index']),str(r['bits']),r['name'],r['dtype'],str(len(r['shape'])),*(str(d)for d in r['shape']),json.dumps(str(R/r['path'])),str(r['bytes']))))
(C/'component-roles.tsv').write_text('\n'.join(lines)+'\n')
save(O/'result.json',dict(status='INDEPENDENT_SOURCE_EQUATION_ORACLE_READY',source=[pin(reader),pin(up)],scope='Independent NumPy implementation of fixed source SIMD affine weight math and typed embedding boundaries; not an execution of the MLX runtime, not publisher-version or whole-forward equivalence.',activation='Two fixed sparse BF16 rows; only indices0,1,2047 nonzero. F64 dot and independent F32 dot agree after final BF16 cast.',results=result,inputs=[pin(R/p['path'])for p in receipt['parts']],outputs=[pin(p)for p in O.glob('*')if p.is_file()and p.name!='result.json']))
print(json.dumps(dict(metadata=allmeta,oracle=result),indent=2))
