import difflib,hashlib,json,pathlib,posixpath,re,shlex,subprocess,tarfile
STAGE=pathlib.Path(__file__).resolve().parent
ROOT=STAGE.parents[3]
BASE=ROOT/'.scratch/architecture-refactor-2026-10-18/mlx-affine-widths/apple'
REMOTE='/Users/kiro/hyle-scratch/compute-unified/ct-asymmetric-int4-20261020/apple'
BUILD='/Users/kiro/hyle-scratch/compute-unified/a-cpu-apple/selected-graph/source-build'
def read(p):return json.loads(p.read_text())
def sha(data):return hashlib.sha256(data).hexdigest()
def save(name,x):(STAGE/name).write_text(json.dumps(x,indent=2)+'\n')
records=read(BASE/'validation/checks/complete-object-closure.json')
# Only metadata, actual .d files and source/header identities are read here.
remote_code=r'''import pathlib,json,hashlib,shlex,platform,subprocess
records=RECORDS
prefixes=['/Users/kiro/hyle-scratch/compute-unified/mlx-affine-widths-20261019/apple/current/','/Users/kiro/hyle-scratch/compute-unified/mlx-affine-contract-20261019/current/']
def ident(p):
 p=pathlib.Path(p);d=p.read_bytes();return dict(path=str(p),bytes=len(d),sha256=hashlib.sha256(d).hexdigest())
out={}
for rel,row in records.items():
 p=pathlib.Path(row['object']['path']+'.d');deps=[]
 if p.exists():
  text=p.read_text().replace('\\\n',' ')
  for item in shlex.split(text.split(':',1)[1]):
   for prefix in prefixes:
    if item.startswith(prefix):
     q=pathlib.Path(item);v=ident(q);v['relative']=q.relative_to(prefix).as_posix();deps.append(v);break
 out[rel]=dict(dependencies=deps,dep_text=p.read_text() if p.exists() else None,object=ident(row['object']['path']))
commands=json.loads(pathlib.Path(BUILD+'/compile_commands.json').read_text())
selected={}
for x in commands:
 for directory in ['src/graph/','src/graph_route_apple/']:
  if '/'+directory in x['file']:
   rel=directory+x['file'].split('/'+directory,1)[1]
   if directory=='src/graph_route_apple/' and not rel.endswith('/apple_lowering.cc'):continue
   selected[rel]=x
mlx=pathlib.Path(BUILD+'/hyle/_deps/mlx-490c5876b63c15e8/source/mlx')
proof={}
for rel in ['compile.cpp','ops.cpp','backend/gpu/primitives.cpp']:
 p=mlx/rel;proof[rel]=dict(identity=ident(p),text=p.read_text())
print(json.dumps(dict(records=out,commands=selected,mlx_proof=proof,host=dict(model=subprocess.check_output(['sysctl','-n','hw.model'],text=True).strip(),clang=subprocess.check_output(['/usr/bin/clang++','--version'],text=True).splitlines()[0]))))
'''.replace('RECORDS',repr(records)).replace("BUILD+'/",repr(BUILD)+"+'/")
result=subprocess.run(['ssh','-o','BatchMode=yes','kiro@172.22.10.198','python3','-'],input=remote_code,text=True,capture_output=True)
(STAGE/'remote-inventory.stdout.log').write_text(result.stdout);(STAGE/'remote-inventory.stderr.log').write_text(result.stderr)
assert result.returncode==0,result.stderr
inventory=json.loads(result.stdout);save('remote-inventory.json',inventory)
current={};fresh={};dep_snapshots={}
for rel,row in records.items():
 reasons=[]
 for item in inventory['records'][rel]['dependencies']:
  key=posixpath.normpath(item['relative']);p=ROOT/key
  assert p.is_file(),key
  data=p.read_bytes();current[key]=dict(path=key,bytes=len(data),sha256=sha(data))
  if sha(data)!=item['sha256']:reasons.append(key)
 if (ROOT/rel).is_file():
  data=(ROOT/rel).read_bytes();current[rel]=dict(path=rel,bytes=len(data),sha256=sha(data))
  if sha(data)!=row['source']['sha256']:reasons.append(rel)
 if reasons:fresh[rel]=sorted(set(reasons))
# New Graph owners are actual existing CMake host commands, not a SDK rebuild.
actual_graph=['graph.cc','effect_order.cc','executable.cc','submission.cc','execution_source.cc','view_domain.cc','constant_artifact.cc','resources.cc','lease_submission.cc','region_access.cc','input_sources.cc','resource_report.cc']
extra={k:v for k,v in inventory['commands'].items() if (ROOT/k).is_file() and (k=='src/graph_route_apple/apple_lowering.cc' or k in ['src/graph/'+f for f in actual_graph])}
prototype=inventory['commands']['src/graph/graph.cc']
for f in actual_graph:
 key='src/graph/'+f
 if key not in extra:
  v=prototype.copy();v['file']=prototype['file'].replace('graph.cc',f);v['command']=prototype['command'].replace(prototype['file'],v['file']);v['derived_from_actual_same_target_command']='src/graph/graph.cc';extra[key]=v
for rel in extra:
 fresh[rel]=['required by existing Direct/Graph parity fixture; absent from compute-only 134-object baseline']
 for p in (ROOT/pathlib.PurePosixPath(rel).parent).glob('*.h'):
  key=p.relative_to(ROOT).as_posix();d=p.read_bytes();current[key]=dict(path=key,bytes=len(d),sha256=sha(d))
 d=(ROOT/rel).read_bytes();current[rel]=dict(path=rel,bytes=len(d),sha256=sha(d))
# Product public/private headers are small host inputs, not dependency/SDK trees.
for folder in ['include/hyle','src/graph','src/graph_route_apple']:
 for p in (ROOT/folder).rglob('*.h'):
  key=p.relative_to(ROOT).as_posix();d=p.read_bytes();current[key]=dict(path=key,bytes=len(d),sha256=sha(d))
for key in ['tests/compute_route_apple/parity_delivery/main.cc','tests/compute_models/ct_asymmetric_int4_fixture.h']:
 d=(ROOT/key).read_bytes();current[key]=dict(path=key,bytes=len(d),sha256=sha(d))
# Preserve coherent source/headers actually used by fresh host owners only.
needed=set()
for rel in fresh:
 needed.add(rel)
 if rel in inventory['records']:
  needed.update(posixpath.normpath(x['relative']) for x in inventory['records'][rel]['dependencies'])
needed.update(k for k in current if k.startswith(('include/hyle/','src/graph/','src/graph_route_apple/','tests/')))
# Include new borrowed helper/header whose baseline .d remains a real dependency.
needed.update(['third_party/compressed_tensors_apple/compressed_tensors_apple.h'])
# New Graph owners have private includes absent from the compute-only .d baseline.
queue=list(needed)
while queue:
 key=queue.pop();p=ROOT/key
 if p.suffix not in ('.h','.cc','.inc'):continue
 for quote,name in re.findall(r'#\s*include\s*([<"])([^>"]+)[>"]',p.read_text(encoding='utf-8')):
  candidates=[p.parent/name,ROOT/'include'/name,ROOT/name]
  for candidate in candidates:
   if candidate.is_file() and candidate.resolve().is_relative_to(ROOT):
    item=candidate.resolve().relative_to(ROOT).as_posix()
    if item not in needed:
     needed.add(item);queue.append(item);d=candidate.read_bytes();current[item]=dict(path=item,bytes=len(d),sha256=sha(d))
    break
for key in sorted(needed):
 p=ROOT/key;q=STAGE/'current'/key;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(p.read_bytes())
plan=dict(remote=REMOTE,base_records=records,base_inventory='remote-inventory.json',fresh=fresh,extra_commands=extra,
 old_prefixes=['/Users/kiro/hyle-scratch/compute-unified/mlx-affine-widths-20261019/apple/current','/Users/kiro/hyle-scratch/compute-unified/mlx-affine-contract-20261019/current'],
 original_build=BUILD,test_compile=read(BASE/'validation/checks/test-compile.command.json')['argv'],link=read(BASE/'validation/checks/link.command.json')['argv'],
 sources=[current[k] for k in sorted(needed)],shared_sdk_rebuilt=False)
save('incremental-plan.json',plan)
with tarfile.open(STAGE/'source.tar.gz','w:gz') as a:
 for key in sorted(needed):a.add(STAGE/'current'/key,arcname='current/'+key)
 for name in ['run_incremental.py','incremental-plan.json','source-freeze.json','remote-inventory.json']:a.add(STAGE/name,arcname=name)
print(json.dumps(dict(fresh=len(fresh),extra=len(extra),reuse=len(records)-len(set(fresh)&set(records)),files=len(needed),package_bytes=(STAGE/'source.tar.gz').stat().st_size,fresh_paths=list(fresh)),indent=2))
