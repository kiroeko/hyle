"""Retain actual results and their limits; no additional model or GPU work."""
from pathlib import Path
import datetime as dt
import hashlib
import json
import subprocess
S = Path(__file__).resolve().parent
ROOT = S.parents[2]

def read(p):
    return json.loads(Path(p).read_text(encoding='utf-8-sig'))

def ident(p):
    p = Path(p).resolve()
    raw = p.read_bytes()
    return dict(path=str(p), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())

freeze = read(S / 'source-freeze.json')
for row in freeze['files']:
    assert ident(row['source']['path']) == row['source']
for row in read(S / 'docs-update.json')['files']:
    assert ident(row['source']['path']) == row['source']
checks = []
for name, command in [('dependency-lock', ['cmake', '-P', 'cmake/HyleDependencyVersions.cmake']),
    ('diff', ['git', 'diff', '--check', '--',
        *[str(Path(row['source']['path']).relative_to(ROOT)) for row in freeze['files']],
        *[str(Path(row['source']['path']).relative_to(ROOT)) for row in read(S / 'docs-update.json')['files']]])]:
    result = subprocess.run(command, cwd=ROOT, capture_output=True)
    (S / (name + '.stdout.log')).write_bytes(result.stdout)
    (S / (name + '.stderr.log')).write_bytes(result.stderr)
    receipt = dict(command=command, cwd=str(ROOT), exit=result.returncode,
        stdout=ident(S / (name + '.stdout.log')), stderr=ident(S / (name + '.stderr.log')))
    (S / (name + '.result.json')).write_text(json.dumps(receipt, indent=2) + '\n')
    checks.append(receipt)
    assert result.returncode == 0, result.stderr.decode('utf-8', errors='replace')
tests = {}
for name in ['windows-cpu-direct', 'windows-cpu-graph', 'cuda', 'vulkan']:
    p = S / 'tests' / name / 'summary.json'
    result = read(p)
    assert result['passed'] and result['skipped'] == 0
    tests[name] = dict(summary=ident(p), cases=result['cases'], skipped=0,
        names=result['names'], image=result['image'])
apple = read(S / 'apple/summary.json')
assert apple['passed'] and apple['test']['direct_graph_domains'] == 24
model = read(S / 'correctness/summary.json')
assert model['passed'] and model['observation']['equal_vectors'] == 64
windows = S / 'windows-host/checks/20261019T194607'
vulkan = S / 'vulkan/windows-host/checks/20261019T194520'
result = dict(passed=True, recorded_utc=dt.datetime.now(dt.timezone.utc).isoformat(),
    change='CT asymmetric INT4 on the existing explicit cold ArtifactWeightDecode operation',
    contract=dict(codes='I32[N,K/8]', zero_points='I32[ceil(N/8),K/group]',
        scales='F16/BF16/F32[N,K/group]', packing='W along K, Z along N, low-first signed nibble-8',
        math='Scale-typed subtraction then multiplication, each rounded before final output cast',
        default_output='scale dtype', g_idx=False,
        capacity='CPU checks each expanded I64 codes/padded-zero native allocation before any payload allocation'),
    architecture=dict(new_operation=False, appended_format=True, Graph_executor_changes=False,
        new_shared_runtime_or_owner=False, implicit_hot_decode=False, SDK_rebuild=False),
    source_freeze=ident(S / 'source-freeze.json'), product_files=len(freeze['files']),
    docs_update=ident(S / 'docs-update.json'), checks=checks, windows_tests=tests,
    apple=dict(summary=ident(S / 'apple/summary.json'), model='Mac16,12',
        numeric_domains=24, scope=apple['result_scope'],
        image=apple['test']['image'], actual_compile=apple['actual_compile']),
    build=dict(windows_cpu_cuda=ident(windows / 'build-proof.json'),
        vulkan=ident(vulkan / 'summary.json'),
        windows_distinct_host_TUs=69, windows_actual_cl_processes=72,
        windows_native_CUDA_TUs=0, SDK_rebuilt=False,
        cpu_vulkan_archive_extraction=ident(windows / 'vulkan-archive-extraction.json')),
    model=dict(summary=ident(S / 'correctness/summary.json'), process_count=1,
        equal_finite_vectors=64, same_predictions_and_fixed_inputs=True,
        one_outer_hybrid_range_per_phase=True, quality_acceptance=False, throughput_claim=False),
    header_evidence=dict(archive='docs/evidence/correctness/ct-asymmetric-int4-header-2026-10-20.zip',
        publisher='cyankiwi/Qwen3.8-27B-AWQ-INT4', revision='6e134bae811fb5adac50ee042ae5f029ac6779aa',
        tensors=2396, language_quantized_roles=399, tensor_payload_bytes_read=0),
    retained_failures=[
        'Windows three artifact test TUs failed C4244/WX implicit double-to-float vector conversion; corrected explicit casts only, reused all30 successful owners.',
        'Mac initial minimal source package missed six recursive private headers:20 owners succeeded,10 failed; retried those10 only.',
        'Offline generator import left one pyc in the vendor tree and exposed lock hashing mismatch; exact generated file was removed using root test.ps1, final original CMake audit passes.',
        'Cleanup first attempt removed the pyc then failed Split-Path parameter selection; retained exact script, corrected directory API and completed empty-directory cleanup.'],
    limitations=[
        'Cold dense decode only; packed W4A16 MatMul/grouped/FFN remains absent.',
        'No actual publisher tensor payload was read or executed; no importer or whole quantized model quality, memory or performance claim.',
        'Linux was not rebuilt or run in this batch.',
        'Vulkan new regression uses the public Direct batch route; no new Vulkan Graph journey was run.',
        'Apple24 counts typed Direct/Graph numeric domains, not24 gtest cases.',
        'Full BF16 Qwen regression is unrelated to execution of the selected27B quantized artifact.',
        'No new throughput rotation or physical kernel trace; previous valid performance numbers remain the latest.'],
    next_review=ident(S / 'next-nvfp4-review.json'))
(S / 'summary.json').write_text(json.dumps(result, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')
print('CT_BATCH_PASSED', {k:v['cases'] for k,v in tests.items()}, 'Apple24domains', 'Qwen64vectors')
