import hashlib
import json
from pathlib import Path

STAGE = Path(__file__).resolve().parent
pointer = json.loads((STAGE / "windows-host/current-plan.json").read_text())
plan_path = Path(pointer["path"])
plan = json.loads(plan_path.read_text())
out = plan_path.parent


def identity(path):
    data = path.read_bytes()
    return {"path": str(path), "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}


rows = []
for entry in plan["compile"]:
    receipt_path = out / (entry["tag"] + "-identity.json")
    receipt = json.loads(receipt_path.read_text())
    assert identity(Path(receipt["object"]["path"])) == receipt["object"]
    assert identity(Path(receipt["source"]["path"])) == receipt["source"]
    if entry["source"].endswith("tests\\compute_route_vulkan\\iree_test.cc"):
        continue
    rows.append({"source": receipt["source"]["path"], "source_identity": receipt["source"],
                 "recipe": str(receipt_path), "recipe_identity": identity(receipt_path),
                 "object": receipt["object"], "source_dependencies": receipt["source_dependencies"],
                 "hyle_header_count": len(receipt["hyle_headers"])})
assert len(rows) == 35
result = {"owners": rows, "count": len(rows), "compile_summary": identity(out / "compile-summary.json"),
          "public_header": next(row for row in plan["frozen"] if row["path"].endswith("include\\hyle\\compute\\model_ops.h")),
          "SDK_rebuilt": False, "GPU_run": False,
          "note": "35 current product/generated wrappers; the separate new Direct test owner is intentionally excluded from common CPU links"}
target = out / "current-product-owners.json"
target.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
print(json.dumps(identity(target), indent=2))
