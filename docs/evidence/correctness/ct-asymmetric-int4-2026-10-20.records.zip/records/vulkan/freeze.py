import base64
import difflib
import hashlib
import json
from pathlib import Path
import shutil

ROOT = Path(__file__).resolve().parents[4]
STAGE = Path(__file__).resolve().parent


def identity(path):
    data = path.read_bytes()
    return {"path": str(path), "bytes": len(data),
            "sha256": hashlib.sha256(data).hexdigest()}


def write_json(name, value):
    (STAGE / name).write_text(json.dumps(value, indent=2) + "\n", encoding="utf-8")


before = json.loads((STAGE / "before.json").read_text())
binary = STAGE / "offline/artifacts.vmfb"
encoded = ROOT / "third_party/iree_vulkan_runtime/programs/artifacts.vmfb.b64"
original_encoded = (STAGE / "before/third_party/iree_vulkan_runtime/programs/artifacts.vmfb.b64").read_bytes()
width = max(map(len, original_encoded.splitlines()))
payload = base64.b64encode(binary.read_bytes()).decode("ascii")
encoded.write_text("\n".join(payload[i:i + width] for i in range(0, len(payload), width)) + "\n",
                   encoding="ascii", newline="\n")
assert base64.b64decode(encoded.read_bytes()) == binary.read_bytes()

files, changes = [], []
for row in before["files"]:
    source = Path(row["source"])
    relative = source.relative_to(ROOT)
    after = STAGE / "source" / relative
    after.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(source, after)
    files.append({"source": str(source), "before": row["before"], "after": identity(after)})
    old = Path(row["before"]["path"]).read_text(encoding="utf-8")
    new = after.read_text(encoding="utf-8")
    changes.extend(difflib.unified_diff(old.splitlines(True), new.splitlines(True),
                                      fromfile="before/" + relative.as_posix(),
                                      tofile="after/" + relative.as_posix()))
(STAGE / "changes.diff").write_text("".join(changes), encoding="utf-8", newline="\n")
write_json("source-freeze.json", {"files": files, "phase": "source_and_offline_generation_only",
    "host_build_run": False, "gpu_run": False})

compilation = json.loads((STAGE / "offline/compilation.json").read_text())
old_mlir = (STAGE / "before/third_party/iree_vulkan_runtime/programs/artifacts.mlir").read_bytes()
new_mlir = (ROOT / "third_party/iree_vulkan_runtime/programs/artifacts.mlir").read_bytes()
assert old_mlir.endswith(b"}\n") and new_mlir.startswith(old_mlir[:-2])
assert len(compilation["exports"]) == 21
spirv = sorted((STAGE / "offline/spirv").glob("*.spirv.mlir"))
assert len(spirv) == 21
assert all('"SignedZeroInfNanPreserve", 32' in p.read_text() for p in spirv)
compiler = Path(compilation["commands"][0][0])
version = STAGE / "offline/compiler-version.txt"
write_json("offline-generation.json", {
    "command": ["python", "third_party/iree_vulkan_runtime/programs/compile_artifacts.py",
        "--compiler", str(compiler), "--output", str(STAGE / "offline")],
    "cwd": str(ROOT), "exit_code": 0, "stdout": "", "stderr": "",
    "compiler": identity(compiler), "version": identity(version),
    "version_text": version.read_text(),
    "inputs": [row for row in files if row["source"].endswith((".py", ".mlir"))],
    "compilation_receipt": identity(STAGE / "offline/compilation.json"),
    "binary": identity(binary), "base64": identity(encoded),
    "base64_decodes_to_recorded_binary": True,
    "original_16_export_mlir_bytes_unchanged": True,
    "exports": compilation["exports"], "spirv_modules": len(spirv),
    "workgroup": [64, 1, 1], "ieee32_all_modules": True,
    "private_abi": "ProgramSpecV2 fields and original ProgramKind values unchanged; appended Asymmetric4Decode only",
    "runtime_verified": False})
manifest_path = ROOT / "third_party/iree_vulkan_runtime/programs/manifest.json"
manifest = json.loads(manifest_path.read_text())
entry = next(p for p in manifest["programs"] if p["name"] == "artifacts")
new_entry = dict(entry)
new_entry.update(sha256=identity(binary)["sha256"], bytes=binary.stat().st_size,
    recipe_sha256=hashlib.sha256(new_mlir).hexdigest(), exports_used=compilation["exports"],
    execution_contract="SignedZeroInfNanPreserve 32; original source-typed decode (CT asymmetric W packs K, Z packs padded N, signed nibble-8, source subtraction and multiplication RNE); qualified native final Cast for cross-dtype half sources")
write_json("manifest-update.json", {"path": str(manifest_path), "name": "artifacts",
    "before": entry, "after": new_entry,
    "root_owned_updates": ["programs/manifest.json artifacts entry", "NOTICE.md CT asymmetric description", "HyleDependencyLock.json vendored tree and NOTICE identity"],
    "other_program_payloads_changed": False,
    "compilation_receipt": str(STAGE / "offline/compilation.json")})
write_json("test-plan.json", {
    "new_filter": "VulkanIree.OriginalAsymmetricArtifactKeepsPaddedZerosAndSourceRoundsAcrossSlots",
    "source_scale_types": ["F32", "F16", "BF16"], "output_types": ["F32", "F16", "BF16"],
    "shape": {"N": 9, "K": 64, "group": 32, "Z": [2, 2]},
    "submissions": 27,
    "checks": ["independent shared logical-code oracle with source scalar RNE",
        "exact output bits including signed zeros", "K-packed W versus N-packed Z including garbage padded N lanes",
        "two independent slots with changed packed data/scales", "rebind second slot and preserve first retained result"],
    "neighbors": ["VulkanIree.OriginalArtifactBatchPreservesSourceRoundingAndSixPorts",
                  "VulkanIree.OriginalArtifactChecksFeaturesDomainFailureAndCancellation"],
    "not_run": True})
write_json("application.json", {"files": [{"source": f["source"],
    "before": f["before"], "after": identity(Path(f["source"]))} for f in files],
    "source_freeze": identity(STAGE / "source-freeze.json"),
    "changed_private_layout": False, "changed_public_header": False,
    "modified_shared_lock_notice_manifest": False})
print(json.dumps({"freeze": identity(STAGE / "source-freeze.json"),
                  "binary": identity(binary), "encoded": identity(encoded)}, indent=2))
