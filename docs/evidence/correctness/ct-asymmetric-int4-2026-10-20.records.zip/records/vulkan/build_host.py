"""Increment the selected current Direct Vulkan closure; never run a GPU test."""
import argparse
import ctypes
from ctypes import wintypes
import datetime as dt
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import sys

sys.dont_write_bytecode = True
STAGE = Path(__file__).resolve().parent
ROOT = STAGE.parents[3]
ARCH = STAGE.parents[1]
OLD = ARCH / "mlx-affine-widths/vulkan/checks-20261019T141537/vulkan-link-plan.json"
spec = importlib.util.spec_from_file_location("ct_vulkan_helpers", ARCH / "cuda-grouped-fusion/build.py")
helper = importlib.util.module_from_spec(spec)
spec.loader.exec_module(helper)
b, c = helper.b, helper.c


def windows_argv(text):
    count = ctypes.c_int()
    parse = ctypes.windll.shell32.CommandLineToArgvW
    parse.argtypes = [wintypes.LPCWSTR, ctypes.POINTER(ctypes.c_int)]
    parse.restype = ctypes.POINTER(wintypes.LPWSTR)
    data = parse(text, ctypes.byref(count))
    if not data:
        raise ctypes.WinError()
    result = [data[i] for i in range(count.value)]
    ctypes.windll.kernel32.LocalFree(data)
    return result


def deps(command):
    for i, arg in enumerate(command):
        if arg.lower() == "/sourcedependencies":
            return Path(command[i + 1])
    return None


def local_headers(path):
    if path is None or not path.is_file():
        return []
    result = []
    for value in c.read(path).get("Data", {}).get("Includes", []):
        header = Path(value).resolve()
        if any(header.is_relative_to(ROOT / prefix) for prefix in ("src", "include", "tests")):
            result.append(b.identity(header))
    return result


def verify(identity):
    if not b.same(identity):
        raise ValueError("Input differs: " + identity["path"])


def prepare(out, env):
    command = [sys.executable, "-B", str(ROOT / "src/compute_provider_iree_vulkan/prepare_source.py"),
        "--source", "C:/public/tools/hyle-dependencies/v1/sources/iree_runtime-6ef606b6fa3e-a1d2c997a8d6",
        "--flatcc", "C:/public/tools/hyle-dependencies/v1/sources/iree_flatcc-9362cd00f000-5640fe0b1653",
        "--headers", "C:/public/tools/hyle-dependencies/v1/sources/iree_vulkan_headers-df60f0316899-ee8016d9fd7d",
        "--vendor", str(ROOT / "third_party/iree_vulkan_runtime"),
        "--output", str(ROOT / ".scratch/bench-api-runtime/vulkan/build/native/hyle/_deps/iv/src"),
        "--generated", str(out / "generated")]
    c.execute("prepare-source", command, env, out)
    generated = out / "generated/programs.cc"
    text = generated.read_text()
    arrays = {name: bytes(int(x, 16) for x in re.findall(r"0x([0-9a-fA-F]{2})", body))
              for name, body in re.findall(r"unsigned char (\w+)_bytes\[\] = \{(.*?)\};", text, re.S)}
    modules = []
    for entry in c.read(ROOT / "third_party/iree_vulkan_runtime/programs/manifest.json")["programs"]:
        data = arrays[entry["name"]]
        row = dict(name=entry["name"], bytes=len(data), sha256=hashlib.sha256(data).hexdigest())
        if (row["bytes"], row["sha256"]) != (entry["bytes"], entry["sha256"]):
            raise ValueError("Generated embedded module differs: " + entry["name"])
        modules.append(row)
    if len(modules) != 7:
        raise ValueError("Expected all seven current embedded modules")
    c.save(out / "embedded-module-identities.json", dict(generated=b.identity(generated),
        modules=modules, original_generator=True, SDK_rebuilt=False))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", type=Path)
    parser.add_argument("--build", action="store_true")
    parser.add_argument("--base", type=Path)
    parser.add_argument("--link", action="store_true")
    args = parser.parse_args()
    out = args.out.resolve() if args.out else STAGE / "windows-host/checks" / dt.datetime.now(dt.timezone.utc).strftime("%Y%m%dT%H%M%S")
    out.mkdir(parents=True, exist_ok=True)
    (out / "tmp").mkdir(exist_ok=True)
    old = c.read(OLD)
    rows, originals = [], []
    for entry in old["inputs"][:old["fresh_Vulkan_owners"]]:
        object_path = Path(entry["path"])
        identity_path = object_path.with_name(object_path.stem + "-identity.json")
        identity = c.read(identity_path)
        source = Path(identity["source"]["path"])
        if not (source.is_relative_to(ROOT / "src/compute_provider_iree_vulkan") or
                source.is_relative_to(ROOT / "src/compute_route_vulkan") or
                source == ROOT / "tests/compute_route_vulkan/iree_test.cc" or
                object_path.stem == "embedded-programs"):
            continue
        if object_path.stem == "embedded-programs":
            source = out / "generated/programs.cc"
        tag = object_path.stem
        command = b.host_command(identity["command"], source, tag, out)
        headers = local_headers(deps(identity["command"]))
        reason = [h["path"] for h in headers if h["path"].lower().endswith((
            "include\\hyle\\compute\\model_ops.h", "src\\compute_provider_iree_vulkan\\native_program.h"))]
        rows.append(dict(tag=tag, source=str(source), command=command,
            object=str(out / (tag + ".obj")), recipe=b.identity(identity_path),
            old_object=identity["object"], previous_source_dependencies=b.identity(deps(identity["command"])),
            changing_header_membership=reason,
            reason="Current private/public header owner" if reason else
                ("Current embedded bytecode from original prepare_source.py" if tag == "embedded-programs" else
                 "Current IREE native-device Hyle header closure; earlier receipt did not freeze every Hyle header identity")))
        originals.extend(headers)
    # The cached SDK archive also contains these three Hyle wrappers. Refresh
    # them explicitly so the linker cannot pull pre-current public contracts.
    database = ROOT / ".scratch/bench-api-runtime/vulkan/build/compile_commands.json"
    for entry in c.read(database):
        source = Path(entry["file"]).resolve()
        if not source.is_relative_to(ROOT / "src/compute_provider_ggml_vulkan"):
            continue
        template = windows_argv(entry["command"])
        if "/WX" not in template:
            template.append("/WX")
        tag = "src--compute_provider_ggml_vulkan--" + source.stem
        command = b.host_command(template, source, tag, out)
        rows.append(dict(tag=tag, source=str(source), command=command,
            object=str(out / (tag + ".obj")), recipe=b.identity(database),
            old_object={"path": entry["output"]},
            reason="Fresh Hyle ggml-Vulkan wrapper from cached CMake argv, strict /WX added; no vendor source rebuilt"))
    if len(rows) != 36:
        raise ValueError("Expected 36 selected Direct Vulkan host owners, got " + str(len(rows)))
    env, _ = b.environment(rows[0]["command"], [], out)
    env["PYTHONDONTWRITEBYTECODE"] = "1"
    frozen = [b.identity(ROOT / p) for p in (
        "include/hyle/compute/model_ops.h", "src/compute_provider_iree_vulkan/native_program.h",
        "src/compute_route_vulkan/vulkan_program_internal.h",
        "src/compute_provider_iree_vulkan/prepare_source.py",
        "third_party/iree_vulkan_runtime/programs/manifest.json", "cmake/HyleDependencyLock.json")]
    plan = dict(compile=rows, old_vulkan_plan=b.identity(OLD), frozen=frozen,
        selected="Direct Vulkan artifact test closure; Graph-Vulkan adapters and unrelated Graph/private fixtures omitted",
        fresh_host_owners=len(rows), SDK_rebuilt=False, GPU_run=False,
        actual_previous_header_owners=list({c.key(x["path"]): x for x in originals}.values()))
    c.save(out / "plan.json", plan)
    c.save(STAGE / "windows-host/current-plan.json", dict(path=str(out / "plan.json")))
    print("PLAN", out / "plan.json", flush=True)
    if args.build:
        prepare(out, env)
        for row in rows:
            identity_path = out / (row["tag"] + "-identity.json")
            if identity_path.exists():
                previous = c.read(identity_path)
                if previous["source"] == b.identity(row["source"]) and b.same(previous["object"]) and all(b.same(h) for h in previous["hyle_headers"]):
                    print("REUSE", row["tag"], flush=True)
                    continue
            source = b.identity(row["source"])
            c.execute(row["tag"] + "-compile", row["command"], env, out)
            if not b.same(source):
                raise ValueError("Source changed while compiling: " + row["source"])
            c.save(identity_path, dict(command=row["command"], source=source,
                object=b.identity(row["object"]), source_dependencies=b.identity(deps(row["command"])),
                hyle_headers=local_headers(deps(row["command"]))))
        for entry in frozen:
            verify(entry)
        c.save(out / "compile-summary.json", dict(fresh_host_owners=len(rows), passed=True,
            SDK_rebuilt=False, GPU_run=False))
    if not args.link:
        return
    if not args.base:
        parser.error("--link requires a frozen current CPU --base")
    base = c.read(args.base)
    base_identity = b.identity(args.base)
    common_test_names = {
        "cpu-direct-artifact-explicit-cast.obj", "workspace-test.obj",
        "08-graph-region_provider_test.obj", "test.obj",
        "01-compute_ops-operation_test.obj",
        "02-compute_route_cpu-cpu_mlx_quantized_test.obj",
        "03-compute_route_cpu-cpu_mlx_quantized_test.obj"}
    removed = [entry for entry in base["inputs"] if Path(entry["path"]).name in common_test_names]
    if len(removed) != 7 or {Path(entry["path"]).name for entry in removed} != common_test_names:
        raise ValueError("Expected the seven common CPU test owners")
    removed_keys = {c.key(entry["path"]) for entry in removed}
    inputs = [entry for entry in base["inputs"] if c.key(entry["path"]) not in removed_keys]
    fresh = []
    all_headers = []
    for row in rows:
        receipt = c.read(out / (row["tag"] + "-identity.json"))
        verify(receipt["source"])
        verify(receipt["object"])
        for header in receipt["hyle_headers"]:
            verify(header)
            all_headers.append(header)
        fresh.append(receipt["object"])
    shaders = [b.identity(ROOT / name) for name in (
        ".scratch/inference-foundation-review-2026-10-18/native-row-cache-padded/shaders.obj",
        ".scratch/architecture-refactor-2026-10-18/paged-row-scorer/validation/windows-current/row-cache-paged-shader.obj")]
    existing = {c.key(entry["path"]) for entry in inputs}
    # CPU validation can share these same current wrapper objects. Keep one
    # exact object identity when the released common plan already includes it.
    shared = [entry for entry in fresh + shaders if c.key(entry["path"]) in existing]
    additions = [entry for entry in fresh + shaders if c.key(entry["path"]) not in existing]
    for entry in shared:
        actual = next(row for row in inputs if c.key(row["path"]) == c.key(entry["path"]))
        if actual != entry:
            raise ValueError("Shared common object identity differs")
    # Keep the authenticated current common core, replacing the CPU fixture
    # objects with the selected Direct Vulkan test owner.
    command = [arg for arg in base["command"] if c.key(arg) not in removed_keys and
               not arg.upper().startswith(("/OUT:", "/MAP:", "/IMPLIB:", "/PDB:"))]
    command[1:1] = [entry["path"] for entry in additions]
    image = out / "ct-asymmetric-vulkan.exe"
    command += ["/OUT:" + str(image), "/MAP:" + str(image.with_suffix(".map")),
                "/IMPLIB:" + str(image.with_suffix(".lib"))]
    actual = [arg for arg in command if Path(arg).is_absolute() and Path(arg).suffix.lower() in (".obj", ".lib")]
    inputs = additions + inputs
    if sorted(map(c.key, actual)) != sorted(c.key(x["path"]) for x in inputs):
        raise ValueError("Literal link input set differs from plan")
    for entry in inputs:
        verify(entry)
    env, runtime = b.environment(command, actual, out)
    env["PYTHONDONTWRITEBYTECODE"] = "1"
    c.save(out / "runtime-paths.json", runtime)
    link_plan = dict(command=command, inputs=inputs, base=base_identity,
        fresh_host_owners=len(fresh), shaders=shaders, input_count=len(inputs),
        shared_current_common_objects=shared,
        removed_common_test_objects=removed,
        public_header=b.identity(ROOT / "include/hyle/compute/model_ops.h"),
        hyle_headers=list({c.key(h["path"]): h for h in all_headers}.values()),
        SDK_rebuilt=False, GPU_run=False,
        test_filter=c.read(STAGE / "test-plan.json")["new_filter"] + ":" + ":".join(c.read(STAGE / "test-plan.json")["neighbors"]))
    c.save(out / "vulkan-link-plan.json", link_plan)
    c.execute("vulkan-link", command, env, out)
    for entry in frozen:
        verify(entry)
    verify(base_identity)
    c.save(out / "summary.json", dict(linked=True, image=b.identity(image),
        fresh_host_owners=len(fresh), input_count=len(inputs), SDK_rebuilt=False,
        GPU_run=False, runtime="pending", test_filter=link_plan["test_filter"]))
    print("LINKED", image, flush=True)


if __name__ == "__main__":
    main()
