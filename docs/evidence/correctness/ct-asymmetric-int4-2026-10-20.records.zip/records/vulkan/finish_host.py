import hashlib
import json
from pathlib import Path
import re

STAGE = Path(__file__).resolve().parent
ROOT = STAGE.parents[3]
out = Path(json.loads((STAGE / "windows-host/current-plan.json").read_text())["path"]).parent


def identity(path):
    data = path.read_bytes()
    return {"path": str(path), "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}


plan = json.loads((out / "plan.json").read_text())
link = json.loads((out / "vulkan-link-plan.json").read_text())
summary = json.loads((out / "summary.json").read_text())
map_path = Path(summary["image"]["path"]).with_suffix(".map")
map_text = map_path.read_text(errors="replace")
old_archives = ["hyle_compute_route_vulkan.lib", "hyle_compute_provider_iree_vulkan.lib",
                "hyle_compute_provider_ggml_vulkan.lib"]
archive_lines = {name: [line for line in map_text.splitlines()
                        if re.search(re.escape(name.removesuffix(".lib")) + r"(?:\.lib)?:",
                                     line, re.IGNORECASE)] for name in old_archives}
assert not any(archive_lines.values())
rows = []
for row in plan["compile"]:
    receipt = json.loads((out / (row["tag"] + "-identity.json")).read_text())
    deps_path = Path(receipt["source_dependencies"]["path"])
    includes = json.loads(deps_path.read_text(encoding="utf-8-sig"))["Data"]["Includes"]
    lower = [name.lower().replace("/", "\\") for name in includes]
    rows.append({"source": receipt["source"], "object": receipt["object"],
        "identity_recipe": identity(out / (row["tag"] + "-identity.json")),
        "source_dependencies": receipt["source_dependencies"],
        "model_ops_owner": any(p.endswith("include\\hyle\\compute\\model_ops.h") for p in lower),
        "private_program_owner": any(p.endswith("src\\compute_provider_iree_vulkan\\native_program.h") for p in lower),
        "hyle_header_count": len(receipt["hyle_headers"])})
result = {"status": "HOST_BUILD_AND_LINK_PASS_RUNTIME_PENDING", "SDK_rebuilt": False,
    "GPU_run": False, "compile_count": len(rows), "compile_failures": [],
    "model_ops_owner_count": sum(row["model_ops_owner"] for row in rows),
    "private_program_owner_count": sum(row["private_program_owner"] for row in rows),
    "owners": rows, "link_plan": identity(out / "vulkan-link-plan.json"),
    "image": summary["image"], "map": identity(map_path),
    "old_wrapper_archive_member_lines": archive_lines,
    "old_wrapper_archive_members_extracted": 0,
    "common_base": link["base"], "removed_cpu_fixture_count": len(link["removed_common_test_objects"]),
    "test_filter": link["test_filter"],
    "runtime_paths": identity(out / "runtime-paths.json"),
    "original_prepare_source_result": identity(out / "prepare-source.result.json"),
    "fresh_embedded_modules": identity(out / "embedded-module-identities.json"),
    "compile_summary": identity(out / "compile-summary.json"),
    "link_result": identity(out / "vulkan-link.result.json"),
    "notes": ["No GPU process, gtest invocation or list-tests invocation was run by this host builder",
              "Original prepare_source.py reused the existing module-owned source cache and emitted all seven current authenticated program blobs",
              "All selected Vulkan Hyle wrappers are explicit current objects; named old wrapper archives supplied no linked member"]}
target = out / "host-validation.json"
target.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
print(json.dumps(identity(target), indent=2))
