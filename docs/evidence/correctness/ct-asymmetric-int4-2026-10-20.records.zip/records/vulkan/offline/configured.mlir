module attributes {stream.affinity.default = #hal.device.affinity<@__device_0>} {
  util.global private @__device_0 = #hal.device.target<"vulkan", [#hal.executable.target<"vulkan-spirv", "vulkan-spirv-fb", {iree_codegen.target_info = #iree_gpu.target<arch = "vp_android_baseline_2022", features = "spirv:v1.3,cap:Shader,cap:Int16,cap:Float16,cap:StorageBuffer16BitAccess,cap:SignedZeroInfNanPreserve,ext:SPV_KHR_16bit_storage,ext:SPV_KHR_float_controls", wgp = <compute = fp32|int32, storage = b32, subgroup = none, subgroup_size_choices = [64], max_workgroup_sizes = [128, 128, 64], max_thread_count_per_workgroup = 128, max_workgroup_memory_bytes = 16384, max_workgroup_counts = [65535, 65535, 65535]>>}>]> : !hal.device
  hal.executable private @nf4_f32_dispatch_0 {
    hal.executable.variant public @vulkan_spirv_fb target(<"vulkan-spirv", "vulkan-spirv-fb", {iree_codegen.target_info = #iree_gpu.target<arch = "vp_android_baseline_2022", features = "spirv:v1.3,cap:Shader,cap:Int16,cap:Float16,cap:StorageBuffer16BitAccess,cap:SignedZeroInfNanPreserve,ext:SPV_KHR_16bit_storage,ext:SPV_KHR_float_controls", wgp = <compute = fp32|int32, storage = b32, subgroup = none, subgroup_size_choices = [64], max_workgroup_sizes = [128, 128, 64], max_thread_count_per_workgroup = 128, max_workgroup_memory_bytes = 16384, max_workgroup_counts = [65535, 65535, 65535]>>}>) {
      hal.executable.export public @nf4_f32_dispatch_0_elementwise_broadcast_D_f32 ordinal(0) layout(#hal.pipeline.layout<constants = 12, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) count(%arg0: !hal.device, %arg1: index, %arg2: index, %arg3: index, %arg4: index, %arg5: index, %arg6: index) -> (index, index, index) {
        %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice(%arg1, %arg2, %arg3, %arg4, %arg5, %arg6)
        hal.return %x, %y, %z : index, index, index
      }
      builtin.module {
        func.func @nf4_f32_dispatch_0_elementwise_broadcast_D_f32() attributes {translation_info = #iree_codegen.translation_info<pipeline = #iree_gpu.spirv_pipeline<BaseDistribute> workgroup_size = [64, 1, 1]>} {
          %c32_i64 = arith.constant 32 : i64
          %c15_i32 = arith.constant 15 : i32
          %c4_i32 = arith.constant 4 : i32
          %c2 = arith.constant 2 : index
          %c0 = arith.constant 0 : index
          %0 = hal.interface.constant.load layout(<constants = 12, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(0) : i32
          %1 = hal.interface.constant.load layout(<constants = 12, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(1) : i32
          %2 = hal.interface.constant.load layout(<constants = 12, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(2) : i32
          %3 = hal.interface.constant.load layout(<constants = 12, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(3) : i32
          %4 = hal.interface.constant.load layout(<constants = 12, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(4) : i32
          %5 = hal.interface.constant.load layout(<constants = 12, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(5) : i32
          %6 = hal.interface.constant.load layout(<constants = 12, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(6) : i32
          %7 = hal.interface.constant.load layout(<constants = 12, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(7) : i32
          %8 = hal.interface.constant.load layout(<constants = 12, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(8) : i32
          %9 = hal.interface.constant.load layout(<constants = 12, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(9) : i32
          %10 = hal.interface.constant.load layout(<constants = 12, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(10) : i32
          %11 = hal.interface.constant.load layout(<constants = 12, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(11) : i32
          %12 = arith.extui %1 : i32 to i64
          %13 = arith.shli %12, %c32_i64 : i64
          %14 = arith.extui %0 : i32 to i64
          %15 = arith.ori %14, %13 : i64
          %16 = arith.index_castui %15 : i64 to index
          %17 = arith.extui %3 : i32 to i64
          %18 = arith.shli %17, %c32_i64 : i64
          %19 = arith.extui %2 : i32 to i64
          %20 = arith.ori %19, %18 : i64
          %21 = arith.index_castui %20 : i64 to index
          %22 = arith.extui %5 : i32 to i64
          %23 = arith.shli %22, %c32_i64 : i64
          %24 = arith.extui %4 : i32 to i64
          %25 = arith.ori %24, %23 : i64
          %26 = arith.index_castui %25 : i64 to index
          %27 = arith.extui %7 : i32 to i64
          %28 = arith.shli %27, %c32_i64 : i64
          %29 = arith.extui %6 : i32 to i64
          %30 = arith.ori %29, %28 : i64
          %31 = arith.index_castui %30 : i64 to index
          %32 = arith.extui %9 : i32 to i64
          %33 = arith.shli %32, %c32_i64 : i64
          %34 = arith.extui %8 : i32 to i64
          %35 = arith.ori %34, %33 : i64
          %36 = arith.index_castui %35 : i64 to index
          %37 = arith.extui %11 : i32 to i64
          %38 = arith.shli %37, %c32_i64 : i64
          %39 = arith.extui %10 : i32 to i64
          %40 = arith.ori %39, %38 : i64
          %41 = arith.index_castui %40 : i64 to index
          %42:5 = util.assume.int 
              %16<umin = 0, umax = 9223372036854775807, udiv = 2>, 
              %21<umin = 0, umax = 18014398509481982, udiv = 2>, 
              %31<umin = 0, umax = 9007199254740991>, 
              %36<umin = 0, umax = 9007199254740991>, 
              %41<umin = 0, umax = 9007199254740991>
            : index, index, index, index, index
          %43 = hal.interface.binding.subspan layout(<constants = 12, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(1) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<16xf32>>
          %44 = iree_tensor_ext.dispatch.workload.ordinal %42#0, 0 : index
          %45 = iree_tensor_ext.dispatch.workload.ordinal %42#2, 3 : index
          %46 = iree_tensor_ext.dispatch.workload.ordinal %42#3, 4 : index
          %47 = iree_tensor_ext.dispatch.workload.ordinal %42#4, 5 : index
          %48 = hal.interface.binding.subspan layout(<constants = 12, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(0) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xi8>>{%45, %46}
          %49 = hal.interface.binding.subspan layout(<constants = 12, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(2) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?xf32>>{%47}
          %50 = hal.interface.binding.subspan layout(<constants = 12, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(3) alignment(64) offset(%c0) flags(Indirect) : !iree_tensor_ext.dispatch.tensor<writeonly:tensor<?xf32>>{%44}
          %51 = iree_tensor_ext.dispatch.workload.ordinal %42#1, 1 : index
          %52 = iree_tensor_ext.dispatch.workload.ordinal %26, 2 : index
          %53 = iree_tensor_ext.dispatch.tensor.load %48, offsets = [0, 0], sizes = [%45, %46], strides = [1, 1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xi8>>{%45, %46} -> tensor<?x?xi8>
          %54 = iree_tensor_ext.dispatch.tensor.load %43, offsets = [0], sizes = [16], strides = [1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<16xf32>> -> tensor<16xf32>
          %55 = iree_tensor_ext.dispatch.tensor.load %49, offsets = [0], sizes = [%47], strides = [1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?xf32>>{%47} -> tensor<?xf32>
          %56 = tensor.empty(%44) : tensor<?xf32>
          %57 = linalg.generic {indexing_maps = [affine_map<(d0) -> (d0)>], iterator_types = ["parallel"]} outs(%56 : tensor<?xf32>) attrs =  {lowering_config = #iree_codegen.lowering_config<tile_sizes = [[64], [1]]>} {
          ^bb0(%out: f32):
            %58 = linalg.index 0 : index
            %59 = arith.remsi %58, %51 : index
            %60 = arith.divsi %58, %51 : index
            %61 = arith.divui %59, %c2 : index
            %62 = arith.remui %59, %c2 : index
            %extracted = tensor.extract %53[%60, %61] : tensor<?x?xi8>
            %63 = arith.extui %extracted : i8 to i32
            %64 = arith.cmpi eq, %62, %c0 : index
            %65 = arith.shrui %63, %c4_i32 : i32
            %66 = arith.select %64, %65, %63 : i32
            %67 = arith.andi %66, %c15_i32 : i32
            %68 = arith.index_castui %67 : i32 to index
            %extracted_0 = tensor.extract %54[%68] : tensor<16xf32>
            %69 = arith.muli %60, %51 : index
            %70 = arith.addi %69, %59 : index
            %71 = arith.divui %70, %52 : index
            %extracted_1 = tensor.extract %55[%71] : tensor<?xf32>
            %72 = arith.mulf %extracted_0, %extracted_1 : f32
            linalg.yield %72 : f32
          } -> tensor<?xf32>
          iree_tensor_ext.dispatch.tensor.store %57, %50, offsets = [0], sizes = [%44], strides = [1] : tensor<?xf32> -> !iree_tensor_ext.dispatch.tensor<writeonly:tensor<?xf32>>{%44}
          return
        }
        iree_codegen.dispatch_config @nf4_f32_dispatch_0_elementwise_broadcast_D_f32 {
        ^bb0(%arg0: !hal.device, %arg1: index, %arg2: index, %arg3: index, %arg4: index, %arg5: index, %arg6: index):
          %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice(%arg1, %arg2, %arg3, %arg4, %arg5, %arg6)
          iree_codegen.yield %x, %y, %z : index, index, index
        }
      }
    }
  }
  util.func public @nf4_f32(%arg0: !hal.buffer_view, %arg1: !hal.buffer_view, %arg2: !hal.buffer_view, %arg3: i32, %arg4: !hal.fence, %arg5: !hal.fence) -> !hal.buffer_view attributes {iree.abi.stub, iree.reflection = {iree.abi.declaration = "async func @nf4_f32(%input0: tensor<?x?xi8>, %input1: tensor<?xf32>, %input2: tensor<16xf32>, %input3: i32) -> (%output0: tensor<?x?xf32>)", iree.abi.model = "coarse-fences"}} {
    %c32_i64 = arith.constant 32 : i64
    %c0 = arith.constant 0 : index
    %c64 = arith.constant 64 : index
    %c4 = arith.constant 4 : index
    %c16 = arith.constant 16 : index
    %c2 = arith.constant 2 : index
    %0 = hal.buffer_view.dim<%arg0 : !hal.buffer_view>[0] : index
    %1 = hal.buffer_view.dim<%arg0 : !hal.buffer_view>[1] : index
    %element_type_i8 = hal.element_type<i8> : i32
    %dense_row_major = hal.encoding_type<dense_row_major> : i32
    hal.buffer_view.assert<%arg0 : !hal.buffer_view> message("input0") shape([%0, %1]) type(%element_type_i8) encoding(%dense_row_major)
    %2 = arith.muli %0, %1 : index
    %3 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg0 : !hal.buffer_view -> tensor<?x?xi8>{%0, %1} in !stream.resource<external>{%2}
    %4 = stream.timepoint.import on(#hal.device.affinity<@__device_0>) %arg4 : (!hal.fence) => !stream.timepoint
    %5 = hal.buffer_view.dim<%arg1 : !hal.buffer_view>[0] : index
    %element_type_f32 = hal.element_type<f32> : i32
    hal.buffer_view.assert<%arg1 : !hal.buffer_view> message("input1") shape([%5]) type(%element_type_f32) encoding(%dense_row_major)
    %6 = arith.muli %5, %c4 : index
    %7 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg1 : !hal.buffer_view -> tensor<?xf32>{%5} in !stream.resource<external>{%6}
    hal.buffer_view.assert<%arg2 : !hal.buffer_view> message("input2") shape([%c16]) type(%element_type_f32) encoding(%dense_row_major)
    %8 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg2 : !hal.buffer_view -> tensor<16xf32> in !stream.resource<external>{%c64}
    %9 = arith.muli %1, %c2 : index
    %10 = arith.muli %0, %9 overflow<nsw> : index
    %11 = arith.index_cast %arg3 : i32 to index
    %12 = arith.muli %10, %c4 : index
    %result, %result_timepoint = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) await(%4) => !stream.resource<external>{%12} => !stream.timepoint
    %13 = arith.index_castui %10 : index to i64
    %14 = arith.index_castui %10 : index to i32
    %15 = arith.shrui %13, %c32_i64 : i64
    %16 = arith.trunci %15 : i64 to i32
    %17 = arith.index_castui %9 : index to i64
    %18 = arith.index_castui %9 : index to i32
    %19 = arith.shrui %17, %c32_i64 : i64
    %20 = arith.trunci %19 : i64 to i32
    %21 = arith.index_castui %11 : index to i64
    %22 = arith.index_castui %11 : index to i32
    %23 = arith.shrui %21, %c32_i64 : i64
    %24 = arith.trunci %23 : i64 to i32
    %25 = arith.index_castui %0 : index to i64
    %26 = arith.index_castui %0 : index to i32
    %27 = arith.shrui %25, %c32_i64 : i64
    %28 = arith.trunci %27 : i64 to i32
    %29 = arith.index_castui %1 : index to i64
    %30 = arith.index_castui %1 : index to i32
    %31 = arith.shrui %29, %c32_i64 : i64
    %32 = arith.trunci %31 : i64 to i32
    %33 = arith.index_castui %5 : index to i64
    %34 = arith.index_castui %5 : index to i32
    %35 = arith.shrui %33, %c32_i64 : i64
    %36 = arith.trunci %35 : i64 to i32
    %37 = stream.cmd.execute on(#hal.device.affinity<@__device_0>) await(%result_timepoint) => with(%3 as %arg6: !stream.resource<external>{%2}, %8 as %arg7: !stream.resource<external>{%c64}, %7 as %arg8: !stream.resource<external>{%6}, %result as %arg9: !stream.resource<external>{%12}) {
      stream.cmd.dispatch @nf4_f32_dispatch_0::@vulkan_spirv_fb::@nf4_f32_dispatch_0_elementwise_broadcast_D_f32[%10, %9, %11, %0, %1, %5](%14, %16, %18, %20, %22, %24, %26, %28, %30, %32, %34, %36 : i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32) {
        ro %arg6[%c0 for %2] : !stream.resource<external>{%2},
        ro %arg7[%c0 for %c64] : !stream.resource<external>{%c64},
        ro %arg8[%c0 for %6] : !stream.resource<external>{%6},
        wo %arg9[%c0 for %12] : !stream.resource<external>{%12}
      }
    } => !stream.timepoint
    %38 = arith.muli %0, %c4 : index
    %39 = arith.muli %38, %9 : index
    stream.timepoint.chain_external on(#hal.device.affinity<@__device_0>) %37 => (%arg5 : !hal.fence)
    %40 = stream.tensor.export on(#hal.device.affinity<@__device_0>) %result : tensor<?x?xf32>{%0, %9} in !stream.resource<external>{%39} -> !hal.buffer_view
    util.return %40 : !hal.buffer_view
  }
  hal.executable private @nf4_f16_dispatch_0 {
    hal.executable.variant public @vulkan_spirv_fb target(<"vulkan-spirv", "vulkan-spirv-fb", {iree_codegen.target_info = #iree_gpu.target<arch = "vp_android_baseline_2022", features = "spirv:v1.3,cap:Shader,cap:Int16,cap:Float16,cap:StorageBuffer16BitAccess,cap:SignedZeroInfNanPreserve,ext:SPV_KHR_16bit_storage,ext:SPV_KHR_float_controls", wgp = <compute = fp32|int32, storage = b32, subgroup = none, subgroup_size_choices = [64], max_workgroup_sizes = [128, 128, 64], max_thread_count_per_workgroup = 128, max_workgroup_memory_bytes = 16384, max_workgroup_counts = [65535, 65535, 65535]>>}>) {
      hal.executable.export public @nf4_f16_dispatch_0_elementwise_broadcast_D_f16 ordinal(0) layout(#hal.pipeline.layout<constants = 12, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) count(%arg0: !hal.device, %arg1: index, %arg2: index, %arg3: index, %arg4: index, %arg5: index, %arg6: index) -> (index, index, index) {
        %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice(%arg1, %arg2, %arg3, %arg4, %arg5, %arg6)
        hal.return %x, %y, %z : index, index, index
      }
      builtin.module {
        func.func @nf4_f16_dispatch_0_elementwise_broadcast_D_f16() attributes {translation_info = #iree_codegen.translation_info<pipeline = #iree_gpu.spirv_pipeline<BaseDistribute> workgroup_size = [64, 1, 1]>} {
          %c32_i64 = arith.constant 32 : i64
          %c15_i32 = arith.constant 15 : i32
          %c4_i32 = arith.constant 4 : i32
          %c2 = arith.constant 2 : index
          %c0 = arith.constant 0 : index
          %0 = hal.interface.constant.load layout(<constants = 12, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(0) : i32
          %1 = hal.interface.constant.load layout(<constants = 12, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(1) : i32
          %2 = hal.interface.constant.load layout(<constants = 12, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(2) : i32
          %3 = hal.interface.constant.load layout(<constants = 12, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(3) : i32
          %4 = hal.interface.constant.load layout(<constants = 12, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(4) : i32
          %5 = hal.interface.constant.load layout(<constants = 12, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(5) : i32
          %6 = hal.interface.constant.load layout(<constants = 12, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(6) : i32
          %7 = hal.interface.constant.load layout(<constants = 12, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(7) : i32
          %8 = hal.interface.constant.load layout(<constants = 12, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(8) : i32
          %9 = hal.interface.constant.load layout(<constants = 12, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(9) : i32
          %10 = hal.interface.constant.load layout(<constants = 12, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(10) : i32
          %11 = hal.interface.constant.load layout(<constants = 12, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(11) : i32
          %12 = arith.extui %1 : i32 to i64
          %13 = arith.shli %12, %c32_i64 : i64
          %14 = arith.extui %0 : i32 to i64
          %15 = arith.ori %14, %13 : i64
          %16 = arith.index_castui %15 : i64 to index
          %17 = arith.extui %3 : i32 to i64
          %18 = arith.shli %17, %c32_i64 : i64
          %19 = arith.extui %2 : i32 to i64
          %20 = arith.ori %19, %18 : i64
          %21 = arith.index_castui %20 : i64 to index
          %22 = arith.extui %5 : i32 to i64
          %23 = arith.shli %22, %c32_i64 : i64
          %24 = arith.extui %4 : i32 to i64
          %25 = arith.ori %24, %23 : i64
          %26 = arith.index_castui %25 : i64 to index
          %27 = arith.extui %7 : i32 to i64
          %28 = arith.shli %27, %c32_i64 : i64
          %29 = arith.extui %6 : i32 to i64
          %30 = arith.ori %29, %28 : i64
          %31 = arith.index_castui %30 : i64 to index
          %32 = arith.extui %9 : i32 to i64
          %33 = arith.shli %32, %c32_i64 : i64
          %34 = arith.extui %8 : i32 to i64
          %35 = arith.ori %34, %33 : i64
          %36 = arith.index_castui %35 : i64 to index
          %37 = arith.extui %11 : i32 to i64
          %38 = arith.shli %37, %c32_i64 : i64
          %39 = arith.extui %10 : i32 to i64
          %40 = arith.ori %39, %38 : i64
          %41 = arith.index_castui %40 : i64 to index
          %42:5 = util.assume.int 
              %16<umin = 0, umax = 9223372036854775807, udiv = 2>, 
              %21<umin = 0, umax = 18014398509481982, udiv = 2>, 
              %31<umin = 0, umax = 9007199254740991>, 
              %36<umin = 0, umax = 9007199254740991>, 
              %41<umin = 0, umax = 9007199254740991>
            : index, index, index, index, index
          %43 = hal.interface.binding.subspan layout(<constants = 12, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(1) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<16xf32>>
          %44 = iree_tensor_ext.dispatch.workload.ordinal %42#0, 0 : index
          %45 = iree_tensor_ext.dispatch.workload.ordinal %42#2, 3 : index
          %46 = iree_tensor_ext.dispatch.workload.ordinal %42#3, 4 : index
          %47 = iree_tensor_ext.dispatch.workload.ordinal %42#4, 5 : index
          %48 = hal.interface.binding.subspan layout(<constants = 12, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(0) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xi8>>{%45, %46}
          %49 = hal.interface.binding.subspan layout(<constants = 12, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(2) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?xf32>>{%47}
          %50 = hal.interface.binding.subspan layout(<constants = 12, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(3) alignment(64) offset(%c0) flags(Indirect) : !iree_tensor_ext.dispatch.tensor<writeonly:tensor<?xf16>>{%44}
          %51 = iree_tensor_ext.dispatch.workload.ordinal %42#1, 1 : index
          %52 = iree_tensor_ext.dispatch.workload.ordinal %26, 2 : index
          %53 = iree_tensor_ext.dispatch.tensor.load %48, offsets = [0, 0], sizes = [%45, %46], strides = [1, 1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xi8>>{%45, %46} -> tensor<?x?xi8>
          %54 = iree_tensor_ext.dispatch.tensor.load %43, offsets = [0], sizes = [16], strides = [1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<16xf32>> -> tensor<16xf32>
          %55 = iree_tensor_ext.dispatch.tensor.load %49, offsets = [0], sizes = [%47], strides = [1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?xf32>>{%47} -> tensor<?xf32>
          %56 = tensor.empty(%44) : tensor<?xf16>
          %57 = linalg.generic {indexing_maps = [affine_map<(d0) -> (d0)>], iterator_types = ["parallel"]} outs(%56 : tensor<?xf16>) attrs =  {lowering_config = #iree_codegen.lowering_config<tile_sizes = [[64], [1]]>} {
          ^bb0(%out: f16):
            %58 = linalg.index 0 : index
            %59 = arith.remsi %58, %51 : index
            %60 = arith.divsi %58, %51 : index
            %61 = arith.divui %59, %c2 : index
            %62 = arith.remui %59, %c2 : index
            %extracted = tensor.extract %53[%60, %61] : tensor<?x?xi8>
            %63 = arith.extui %extracted : i8 to i32
            %64 = arith.cmpi eq, %62, %c0 : index
            %65 = arith.shrui %63, %c4_i32 : i32
            %66 = arith.select %64, %65, %63 : i32
            %67 = arith.andi %66, %c15_i32 : i32
            %68 = arith.index_castui %67 : i32 to index
            %extracted_0 = tensor.extract %54[%68] : tensor<16xf32>
            %69 = arith.muli %60, %51 : index
            %70 = arith.addi %69, %59 : index
            %71 = arith.divui %70, %52 : index
            %extracted_1 = tensor.extract %55[%71] : tensor<?xf32>
            %72 = arith.mulf %extracted_0, %extracted_1 : f32
            %73 = arith.truncf %72 : f32 to f16
            linalg.yield %73 : f16
          } -> tensor<?xf16>
          iree_tensor_ext.dispatch.tensor.store %57, %50, offsets = [0], sizes = [%44], strides = [1] : tensor<?xf16> -> !iree_tensor_ext.dispatch.tensor<writeonly:tensor<?xf16>>{%44}
          return
        }
        iree_codegen.dispatch_config @nf4_f16_dispatch_0_elementwise_broadcast_D_f16 {
        ^bb0(%arg0: !hal.device, %arg1: index, %arg2: index, %arg3: index, %arg4: index, %arg5: index, %arg6: index):
          %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice(%arg1, %arg2, %arg3, %arg4, %arg5, %arg6)
          iree_codegen.yield %x, %y, %z : index, index, index
        }
      }
    }
  }
  util.func public @nf4_f16(%arg0: !hal.buffer_view, %arg1: !hal.buffer_view, %arg2: !hal.buffer_view, %arg3: i32, %arg4: !hal.fence, %arg5: !hal.fence) -> !hal.buffer_view attributes {iree.abi.stub, iree.reflection = {iree.abi.declaration = "async func @nf4_f16(%input0: tensor<?x?xi8>, %input1: tensor<?xf32>, %input2: tensor<16xf32>, %input3: i32) -> (%output0: tensor<?x?xf16>)", iree.abi.model = "coarse-fences"}} {
    %c32_i64 = arith.constant 32 : i64
    %c0 = arith.constant 0 : index
    %c64 = arith.constant 64 : index
    %c4 = arith.constant 4 : index
    %c16 = arith.constant 16 : index
    %c2 = arith.constant 2 : index
    %0 = hal.buffer_view.dim<%arg0 : !hal.buffer_view>[0] : index
    %1 = hal.buffer_view.dim<%arg0 : !hal.buffer_view>[1] : index
    %element_type_i8 = hal.element_type<i8> : i32
    %dense_row_major = hal.encoding_type<dense_row_major> : i32
    hal.buffer_view.assert<%arg0 : !hal.buffer_view> message("input0") shape([%0, %1]) type(%element_type_i8) encoding(%dense_row_major)
    %2 = arith.muli %0, %1 : index
    %3 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg0 : !hal.buffer_view -> tensor<?x?xi8>{%0, %1} in !stream.resource<external>{%2}
    %4 = stream.timepoint.import on(#hal.device.affinity<@__device_0>) %arg4 : (!hal.fence) => !stream.timepoint
    %5 = hal.buffer_view.dim<%arg1 : !hal.buffer_view>[0] : index
    %element_type_f32 = hal.element_type<f32> : i32
    hal.buffer_view.assert<%arg1 : !hal.buffer_view> message("input1") shape([%5]) type(%element_type_f32) encoding(%dense_row_major)
    %6 = arith.muli %5, %c4 : index
    %7 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg1 : !hal.buffer_view -> tensor<?xf32>{%5} in !stream.resource<external>{%6}
    hal.buffer_view.assert<%arg2 : !hal.buffer_view> message("input2") shape([%c16]) type(%element_type_f32) encoding(%dense_row_major)
    %8 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg2 : !hal.buffer_view -> tensor<16xf32> in !stream.resource<external>{%c64}
    %9 = arith.muli %1, %c2 : index
    %10 = arith.muli %0, %9 overflow<nsw> : index
    %11 = arith.index_cast %arg3 : i32 to index
    %12 = arith.muli %10, %c2 : index
    %result, %result_timepoint = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) await(%4) => !stream.resource<external>{%12} => !stream.timepoint
    %13 = arith.index_castui %10 : index to i64
    %14 = arith.index_castui %10 : index to i32
    %15 = arith.shrui %13, %c32_i64 : i64
    %16 = arith.trunci %15 : i64 to i32
    %17 = arith.index_castui %9 : index to i64
    %18 = arith.index_castui %9 : index to i32
    %19 = arith.shrui %17, %c32_i64 : i64
    %20 = arith.trunci %19 : i64 to i32
    %21 = arith.index_castui %11 : index to i64
    %22 = arith.index_castui %11 : index to i32
    %23 = arith.shrui %21, %c32_i64 : i64
    %24 = arith.trunci %23 : i64 to i32
    %25 = arith.index_castui %0 : index to i64
    %26 = arith.index_castui %0 : index to i32
    %27 = arith.shrui %25, %c32_i64 : i64
    %28 = arith.trunci %27 : i64 to i32
    %29 = arith.index_castui %1 : index to i64
    %30 = arith.index_castui %1 : index to i32
    %31 = arith.shrui %29, %c32_i64 : i64
    %32 = arith.trunci %31 : i64 to i32
    %33 = arith.index_castui %5 : index to i64
    %34 = arith.index_castui %5 : index to i32
    %35 = arith.shrui %33, %c32_i64 : i64
    %36 = arith.trunci %35 : i64 to i32
    %37 = stream.cmd.execute on(#hal.device.affinity<@__device_0>) await(%result_timepoint) => with(%3 as %arg6: !stream.resource<external>{%2}, %8 as %arg7: !stream.resource<external>{%c64}, %7 as %arg8: !stream.resource<external>{%6}, %result as %arg9: !stream.resource<external>{%12}) {
      stream.cmd.dispatch @nf4_f16_dispatch_0::@vulkan_spirv_fb::@nf4_f16_dispatch_0_elementwise_broadcast_D_f16[%10, %9, %11, %0, %1, %5](%14, %16, %18, %20, %22, %24, %26, %28, %30, %32, %34, %36 : i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32) {
        ro %arg6[%c0 for %2] : !stream.resource<external>{%2},
        ro %arg7[%c0 for %c64] : !stream.resource<external>{%c64},
        ro %arg8[%c0 for %6] : !stream.resource<external>{%6},
        wo %arg9[%c0 for %12] : !stream.resource<external>{%12}
      }
    } => !stream.timepoint
    %38 = arith.muli %0, %c2 : index
    %39 = arith.muli %38, %9 : index
    stream.timepoint.chain_external on(#hal.device.affinity<@__device_0>) %37 => (%arg5 : !hal.fence)
    %40 = stream.tensor.export on(#hal.device.affinity<@__device_0>) %result : tensor<?x?xf16>{%0, %9} in !stream.resource<external>{%39} -> !hal.buffer_view
    util.return %40 : !hal.buffer_view
  }
  hal.executable private @nf4_bf16_dispatch_0 {
    hal.executable.variant public @vulkan_spirv_fb target(<"vulkan-spirv", "vulkan-spirv-fb", {iree_codegen.target_info = #iree_gpu.target<arch = "vp_android_baseline_2022", features = "spirv:v1.3,cap:Shader,cap:Int16,cap:Float16,cap:StorageBuffer16BitAccess,cap:SignedZeroInfNanPreserve,ext:SPV_KHR_16bit_storage,ext:SPV_KHR_float_controls", wgp = <compute = fp32|int32, storage = b32, subgroup = none, subgroup_size_choices = [64], max_workgroup_sizes = [128, 128, 64], max_thread_count_per_workgroup = 128, max_workgroup_memory_bytes = 16384, max_workgroup_counts = [65535, 65535, 65535]>>}>) {
      hal.executable.export public @nf4_bf16_dispatch_0_elementwise_broadcast_D_i16 ordinal(0) layout(#hal.pipeline.layout<constants = 12, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) count(%arg0: !hal.device, %arg1: index, %arg2: index, %arg3: index, %arg4: index, %arg5: index, %arg6: index) -> (index, index, index) {
        %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice(%arg1, %arg2, %arg3, %arg4, %arg5, %arg6)
        hal.return %x, %y, %z : index, index, index
      }
      builtin.module {
        func.func @nf4_bf16_dispatch_0_elementwise_broadcast_D_i16() attributes {translation_info = #iree_codegen.translation_info<pipeline = #iree_gpu.spirv_pipeline<BaseDistribute> workgroup_size = [64, 1, 1]>} {
          %c32_i64 = arith.constant 32 : i64
          %c15_i32 = arith.constant 15 : i32
          %c4_i32 = arith.constant 4 : i32
          %c2 = arith.constant 2 : index
          %c0 = arith.constant 0 : index
          %0 = hal.interface.constant.load layout(<constants = 12, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(0) : i32
          %1 = hal.interface.constant.load layout(<constants = 12, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(1) : i32
          %2 = hal.interface.constant.load layout(<constants = 12, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(2) : i32
          %3 = hal.interface.constant.load layout(<constants = 12, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(3) : i32
          %4 = hal.interface.constant.load layout(<constants = 12, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(4) : i32
          %5 = hal.interface.constant.load layout(<constants = 12, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(5) : i32
          %6 = hal.interface.constant.load layout(<constants = 12, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(6) : i32
          %7 = hal.interface.constant.load layout(<constants = 12, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(7) : i32
          %8 = hal.interface.constant.load layout(<constants = 12, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(8) : i32
          %9 = hal.interface.constant.load layout(<constants = 12, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(9) : i32
          %10 = hal.interface.constant.load layout(<constants = 12, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(10) : i32
          %11 = hal.interface.constant.load layout(<constants = 12, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(11) : i32
          %12 = arith.extui %1 : i32 to i64
          %13 = arith.shli %12, %c32_i64 : i64
          %14 = arith.extui %0 : i32 to i64
          %15 = arith.ori %14, %13 : i64
          %16 = arith.index_castui %15 : i64 to index
          %17 = arith.extui %3 : i32 to i64
          %18 = arith.shli %17, %c32_i64 : i64
          %19 = arith.extui %2 : i32 to i64
          %20 = arith.ori %19, %18 : i64
          %21 = arith.index_castui %20 : i64 to index
          %22 = arith.extui %5 : i32 to i64
          %23 = arith.shli %22, %c32_i64 : i64
          %24 = arith.extui %4 : i32 to i64
          %25 = arith.ori %24, %23 : i64
          %26 = arith.index_castui %25 : i64 to index
          %27 = arith.extui %7 : i32 to i64
          %28 = arith.shli %27, %c32_i64 : i64
          %29 = arith.extui %6 : i32 to i64
          %30 = arith.ori %29, %28 : i64
          %31 = arith.index_castui %30 : i64 to index
          %32 = arith.extui %9 : i32 to i64
          %33 = arith.shli %32, %c32_i64 : i64
          %34 = arith.extui %8 : i32 to i64
          %35 = arith.ori %34, %33 : i64
          %36 = arith.index_castui %35 : i64 to index
          %37 = arith.extui %11 : i32 to i64
          %38 = arith.shli %37, %c32_i64 : i64
          %39 = arith.extui %10 : i32 to i64
          %40 = arith.ori %39, %38 : i64
          %41 = arith.index_castui %40 : i64 to index
          %42:5 = util.assume.int 
              %16<umin = 0, umax = 9223372036854775807, udiv = 2>, 
              %21<umin = 0, umax = 18014398509481982, udiv = 2>, 
              %31<umin = 0, umax = 9007199254740991>, 
              %36<umin = 0, umax = 9007199254740991>, 
              %41<umin = 0, umax = 9007199254740991>
            : index, index, index, index, index
          %43 = hal.interface.binding.subspan layout(<constants = 12, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(1) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<16xf32>>
          %44 = iree_tensor_ext.dispatch.workload.ordinal %42#0, 0 : index
          %45 = iree_tensor_ext.dispatch.workload.ordinal %42#2, 3 : index
          %46 = iree_tensor_ext.dispatch.workload.ordinal %42#3, 4 : index
          %47 = iree_tensor_ext.dispatch.workload.ordinal %42#4, 5 : index
          %48 = hal.interface.binding.subspan layout(<constants = 12, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(0) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xi8>>{%45, %46}
          %49 = hal.interface.binding.subspan layout(<constants = 12, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(2) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?xf32>>{%47}
          %50 = hal.interface.binding.subspan layout(<constants = 12, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(3) alignment(64) offset(%c0) flags(Indirect) : !iree_tensor_ext.dispatch.tensor<writeonly:tensor<?xi16>>{%44}
          %51 = iree_tensor_ext.dispatch.workload.ordinal %42#1, 1 : index
          %52 = iree_tensor_ext.dispatch.workload.ordinal %26, 2 : index
          %53 = iree_tensor_ext.dispatch.tensor.load %48, offsets = [0, 0], sizes = [%45, %46], strides = [1, 1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xi8>>{%45, %46} -> tensor<?x?xi8>
          %54 = iree_tensor_ext.dispatch.tensor.load %43, offsets = [0], sizes = [16], strides = [1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<16xf32>> -> tensor<16xf32>
          %55 = iree_tensor_ext.dispatch.tensor.load %49, offsets = [0], sizes = [%47], strides = [1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?xf32>>{%47} -> tensor<?xf32>
          %56 = tensor.empty(%44) : tensor<?xi16>
          %57 = linalg.generic {indexing_maps = [affine_map<(d0) -> (d0)>], iterator_types = ["parallel"]} outs(%56 : tensor<?xi16>) attrs =  {lowering_config = #iree_codegen.lowering_config<tile_sizes = [[64], [1]]>} {
          ^bb0(%out: i16):
            %58 = linalg.index 0 : index
            %59 = arith.remsi %58, %51 : index
            %60 = arith.divsi %58, %51 : index
            %61 = arith.divui %59, %c2 : index
            %62 = arith.remui %59, %c2 : index
            %extracted = tensor.extract %53[%60, %61] : tensor<?x?xi8>
            %63 = arith.extui %extracted : i8 to i32
            %64 = arith.cmpi eq, %62, %c0 : index
            %65 = arith.shrui %63, %c4_i32 : i32
            %66 = arith.select %64, %65, %63 : i32
            %67 = arith.andi %66, %c15_i32 : i32
            %68 = arith.index_castui %67 : i32 to index
            %extracted_0 = tensor.extract %54[%68] : tensor<16xf32>
            %69 = arith.muli %60, %51 : index
            %70 = arith.addi %69, %59 : index
            %71 = arith.divui %70, %52 : index
            %extracted_1 = tensor.extract %55[%71] : tensor<?xf32>
            %72 = arith.mulf %extracted_0, %extracted_1 : f32
            %73 = arith.truncf %72 : f32 to bf16
            %74 = arith.bitcast %73 : bf16 to i16
            linalg.yield %74 : i16
          } -> tensor<?xi16>
          iree_tensor_ext.dispatch.tensor.store %57, %50, offsets = [0], sizes = [%44], strides = [1] : tensor<?xi16> -> !iree_tensor_ext.dispatch.tensor<writeonly:tensor<?xi16>>{%44}
          return
        }
        iree_codegen.dispatch_config @nf4_bf16_dispatch_0_elementwise_broadcast_D_i16 {
        ^bb0(%arg0: !hal.device, %arg1: index, %arg2: index, %arg3: index, %arg4: index, %arg5: index, %arg6: index):
          %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice(%arg1, %arg2, %arg3, %arg4, %arg5, %arg6)
          iree_codegen.yield %x, %y, %z : index, index, index
        }
      }
    }
  }
  util.func public @nf4_bf16(%arg0: !hal.buffer_view, %arg1: !hal.buffer_view, %arg2: !hal.buffer_view, %arg3: i32, %arg4: !hal.fence, %arg5: !hal.fence) -> !hal.buffer_view attributes {iree.abi.stub, iree.reflection = {iree.abi.declaration = "async func @nf4_bf16(%input0: tensor<?x?xi8>, %input1: tensor<?xf32>, %input2: tensor<16xf32>, %input3: i32) -> (%output0: tensor<?x?xi16>)", iree.abi.model = "coarse-fences"}} {
    %c32_i64 = arith.constant 32 : i64
    %c0 = arith.constant 0 : index
    %c64 = arith.constant 64 : index
    %c4 = arith.constant 4 : index
    %c16 = arith.constant 16 : index
    %c2 = arith.constant 2 : index
    %0 = hal.buffer_view.dim<%arg0 : !hal.buffer_view>[0] : index
    %1 = hal.buffer_view.dim<%arg0 : !hal.buffer_view>[1] : index
    %element_type_i8 = hal.element_type<i8> : i32
    %dense_row_major = hal.encoding_type<dense_row_major> : i32
    hal.buffer_view.assert<%arg0 : !hal.buffer_view> message("input0") shape([%0, %1]) type(%element_type_i8) encoding(%dense_row_major)
    %2 = arith.muli %0, %1 : index
    %3 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg0 : !hal.buffer_view -> tensor<?x?xi8>{%0, %1} in !stream.resource<external>{%2}
    %4 = stream.timepoint.import on(#hal.device.affinity<@__device_0>) %arg4 : (!hal.fence) => !stream.timepoint
    %5 = hal.buffer_view.dim<%arg1 : !hal.buffer_view>[0] : index
    %element_type_f32 = hal.element_type<f32> : i32
    hal.buffer_view.assert<%arg1 : !hal.buffer_view> message("input1") shape([%5]) type(%element_type_f32) encoding(%dense_row_major)
    %6 = arith.muli %5, %c4 : index
    %7 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg1 : !hal.buffer_view -> tensor<?xf32>{%5} in !stream.resource<external>{%6}
    hal.buffer_view.assert<%arg2 : !hal.buffer_view> message("input2") shape([%c16]) type(%element_type_f32) encoding(%dense_row_major)
    %8 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg2 : !hal.buffer_view -> tensor<16xf32> in !stream.resource<external>{%c64}
    %9 = arith.muli %1, %c2 : index
    %10 = arith.muli %0, %9 overflow<nsw> : index
    %11 = arith.index_cast %arg3 : i32 to index
    %12 = arith.muli %10, %c2 : index
    %result, %result_timepoint = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) await(%4) => !stream.resource<external>{%12} => !stream.timepoint
    %13 = arith.index_castui %10 : index to i64
    %14 = arith.index_castui %10 : index to i32
    %15 = arith.shrui %13, %c32_i64 : i64
    %16 = arith.trunci %15 : i64 to i32
    %17 = arith.index_castui %9 : index to i64
    %18 = arith.index_castui %9 : index to i32
    %19 = arith.shrui %17, %c32_i64 : i64
    %20 = arith.trunci %19 : i64 to i32
    %21 = arith.index_castui %11 : index to i64
    %22 = arith.index_castui %11 : index to i32
    %23 = arith.shrui %21, %c32_i64 : i64
    %24 = arith.trunci %23 : i64 to i32
    %25 = arith.index_castui %0 : index to i64
    %26 = arith.index_castui %0 : index to i32
    %27 = arith.shrui %25, %c32_i64 : i64
    %28 = arith.trunci %27 : i64 to i32
    %29 = arith.index_castui %1 : index to i64
    %30 = arith.index_castui %1 : index to i32
    %31 = arith.shrui %29, %c32_i64 : i64
    %32 = arith.trunci %31 : i64 to i32
    %33 = arith.index_castui %5 : index to i64
    %34 = arith.index_castui %5 : index to i32
    %35 = arith.shrui %33, %c32_i64 : i64
    %36 = arith.trunci %35 : i64 to i32
    %37 = stream.cmd.execute on(#hal.device.affinity<@__device_0>) await(%result_timepoint) => with(%3 as %arg6: !stream.resource<external>{%2}, %8 as %arg7: !stream.resource<external>{%c64}, %7 as %arg8: !stream.resource<external>{%6}, %result as %arg9: !stream.resource<external>{%12}) {
      stream.cmd.dispatch @nf4_bf16_dispatch_0::@vulkan_spirv_fb::@nf4_bf16_dispatch_0_elementwise_broadcast_D_i16[%10, %9, %11, %0, %1, %5](%14, %16, %18, %20, %22, %24, %26, %28, %30, %32, %34, %36 : i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32) {
        ro %arg6[%c0 for %2] : !stream.resource<external>{%2},
        ro %arg7[%c0 for %c64] : !stream.resource<external>{%c64},
        ro %arg8[%c0 for %6] : !stream.resource<external>{%6},
        wo %arg9[%c0 for %12] : !stream.resource<external>{%12}
      }
    } => !stream.timepoint
    %38 = arith.muli %0, %c2 : index
    %39 = arith.muli %38, %9 : index
    stream.timepoint.chain_external on(#hal.device.affinity<@__device_0>) %37 => (%arg5 : !hal.fence)
    %40 = stream.tensor.export on(#hal.device.affinity<@__device_0>) %result : tensor<?x?xi16>{%0, %9} in !stream.resource<external>{%39} -> !hal.buffer_view
    util.return %40 : !hal.buffer_view
  }
  hal.executable private @nf4_nested_f32_dispatch_0 {
    hal.executable.variant public @vulkan_spirv_fb target(<"vulkan-spirv", "vulkan-spirv-fb", {iree_codegen.target_info = #iree_gpu.target<arch = "vp_android_baseline_2022", features = "spirv:v1.3,cap:Shader,cap:Int16,cap:Float16,cap:StorageBuffer16BitAccess,cap:SignedZeroInfNanPreserve,ext:SPV_KHR_16bit_storage,ext:SPV_KHR_float_controls", wgp = <compute = fp32|int32, storage = b32, subgroup = none, subgroup_size_choices = [64], max_workgroup_sizes = [128, 128, 64], max_thread_count_per_workgroup = 128, max_workgroup_memory_bytes = 16384, max_workgroup_counts = [65535, 65535, 65535]>>}>) {
      hal.executable.export public @nf4_nested_f32_dispatch_0_elementwise_broadcast_D_f32 ordinal(0) layout(#hal.pipeline.layout<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) count(%arg0: !hal.device, %arg1: index, %arg2: index, %arg3: index, %arg4: index, %arg5: index, %arg6: index, %arg7: index) -> (index, index, index) {
        %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice(%arg1, %arg2, %arg3, %arg4, %arg5, %arg6, %arg7)
        hal.return %x, %y, %z : index, index, index
      }
      builtin.module {
        func.func @nf4_nested_f32_dispatch_0_elementwise_broadcast_D_f32() attributes {translation_info = #iree_codegen.translation_info<pipeline = #iree_gpu.spirv_pipeline<BaseDistribute> workgroup_size = [64, 1, 1]>} {
          %c32_i64 = arith.constant 32 : i64
          %c255 = arith.constant 255 : index
          %c256 = arith.constant 256 : index
          %c15_i32 = arith.constant 15 : i32
          %c4_i32 = arith.constant 4 : i32
          %c2 = arith.constant 2 : index
          %c0 = arith.constant 0 : index
          %0 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(0) : i32
          %1 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(1) : i32
          %2 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(2) : i32
          %3 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(3) : i32
          %4 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(4) : i32
          %5 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(5) : i32
          %6 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(6) : i32
          %7 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(7) : i32
          %8 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(8) : i32
          %9 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(9) : i32
          %10 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(10) : i32
          %11 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(11) : i32
          %12 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(12) : i32
          %13 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(13) : i32
          %14 = arith.extui %1 : i32 to i64
          %15 = arith.shli %14, %c32_i64 : i64
          %16 = arith.extui %0 : i32 to i64
          %17 = arith.ori %16, %15 : i64
          %18 = arith.index_castui %17 : i64 to index
          %19 = arith.extui %3 : i32 to i64
          %20 = arith.shli %19, %c32_i64 : i64
          %21 = arith.extui %2 : i32 to i64
          %22 = arith.ori %21, %20 : i64
          %23 = arith.index_castui %22 : i64 to index
          %24 = arith.extui %5 : i32 to i64
          %25 = arith.shli %24, %c32_i64 : i64
          %26 = arith.extui %4 : i32 to i64
          %27 = arith.ori %26, %25 : i64
          %28 = arith.index_castui %27 : i64 to index
          %29 = arith.extui %7 : i32 to i64
          %30 = arith.shli %29, %c32_i64 : i64
          %31 = arith.extui %6 : i32 to i64
          %32 = arith.ori %31, %30 : i64
          %33 = arith.index_castui %32 : i64 to index
          %34 = arith.extui %9 : i32 to i64
          %35 = arith.shli %34, %c32_i64 : i64
          %36 = arith.extui %8 : i32 to i64
          %37 = arith.ori %36, %35 : i64
          %38 = arith.index_castui %37 : i64 to index
          %39 = arith.extui %11 : i32 to i64
          %40 = arith.shli %39, %c32_i64 : i64
          %41 = arith.extui %10 : i32 to i64
          %42 = arith.ori %41, %40 : i64
          %43 = arith.index_castui %42 : i64 to index
          %44 = arith.extui %13 : i32 to i64
          %45 = arith.shli %44, %c32_i64 : i64
          %46 = arith.extui %12 : i32 to i64
          %47 = arith.ori %46, %45 : i64
          %48 = arith.index_castui %47 : i64 to index
          %49:6 = util.assume.int 
              %18<umin = 0, umax = 9223372036854775807, udiv = 2>, 
              %23<umin = 0, umax = 18014398509481982, udiv = 2>, 
              %33<umin = 0, umax = 9007199254740991>, 
              %38<umin = 0, umax = 9007199254740991>, 
              %43<umin = 0, umax = 9007199254740991>, 
              %48<umin = 0, umax = 9007199254740991>
            : index, index, index, index, index, index
          %50 = hal.interface.binding.subspan layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(1) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<16xf32>>
          %51 = hal.interface.binding.subspan layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(3) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<256xf32>>
          %52 = hal.interface.binding.subspan layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(5) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<f32>>
          %53 = iree_tensor_ext.dispatch.workload.ordinal %49#0, 0 : index
          %54 = iree_tensor_ext.dispatch.workload.ordinal %49#2, 3 : index
          %55 = iree_tensor_ext.dispatch.workload.ordinal %49#3, 4 : index
          %56 = iree_tensor_ext.dispatch.workload.ordinal %49#4, 5 : index
          %57 = iree_tensor_ext.dispatch.workload.ordinal %49#5, 6 : index
          %58 = hal.interface.binding.subspan layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(0) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xi8>>{%54, %55}
          %59 = hal.interface.binding.subspan layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(2) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?xi8>>{%56}
          %60 = hal.interface.binding.subspan layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(4) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?xf32>>{%57}
          %61 = hal.interface.binding.subspan layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(6) alignment(64) offset(%c0) flags(Indirect) : !iree_tensor_ext.dispatch.tensor<writeonly:tensor<?xf32>>{%53}
          %62 = iree_tensor_ext.dispatch.workload.ordinal %49#1, 1 : index
          %63 = iree_tensor_ext.dispatch.workload.ordinal %28, 2 : index
          %64 = iree_tensor_ext.dispatch.tensor.load %58, offsets = [0, 0], sizes = [%54, %55], strides = [1, 1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xi8>>{%54, %55} -> tensor<?x?xi8>
          %65 = iree_tensor_ext.dispatch.tensor.load %50, offsets = [0], sizes = [16], strides = [1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<16xf32>> -> tensor<16xf32>
          %66 = iree_tensor_ext.dispatch.tensor.load %59, offsets = [0], sizes = [%56], strides = [1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?xi8>>{%56} -> tensor<?xi8>
          %67 = iree_tensor_ext.dispatch.tensor.load %51, offsets = [0], sizes = [256], strides = [1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<256xf32>> -> tensor<256xf32>
          %68 = iree_tensor_ext.dispatch.tensor.load %60, offsets = [0], sizes = [%57], strides = [1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?xf32>>{%57} -> tensor<?xf32>
          %69 = iree_tensor_ext.dispatch.tensor.load %52, offsets = [], sizes = [], strides = [] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<f32>> -> tensor<f32>
          %70 = tensor.empty(%53) : tensor<?xf32>
          %71 = linalg.generic {indexing_maps = [affine_map<(d0) -> (d0)>], iterator_types = ["parallel"]} outs(%70 : tensor<?xf32>) attrs =  {lowering_config = #iree_codegen.lowering_config<tile_sizes = [[64], [1]]>} {
          ^bb0(%out: f32):
            %72 = linalg.index 0 : index
            %73 = arith.remsi %72, %62 : index
            %74 = arith.divsi %72, %62 : index
            %75 = arith.divui %73, %c2 : index
            %76 = arith.remui %73, %c2 : index
            %extracted = tensor.extract %64[%74, %75] : tensor<?x?xi8>
            %77 = arith.extui %extracted : i8 to i32
            %78 = arith.cmpi eq, %76, %c0 : index
            %79 = arith.shrui %77, %c4_i32 : i32
            %80 = arith.select %78, %79, %77 : i32
            %81 = arith.andi %80, %c15_i32 : i32
            %82 = arith.index_castui %81 : i32 to index
            %extracted_0 = tensor.extract %65[%82] : tensor<16xf32>
            %83 = arith.muli %74, %62 : index
            %84 = arith.addi %83, %73 : index
            %85 = arith.divui %84, %63 : index
            %86 = arith.divui %85, %c256 : index
            %extracted_1 = tensor.extract %66[%85] : tensor<?xi8>
            %87 = arith.index_cast %extracted_1 : i8 to index
            %88 = arith.andi %87, %c255 : index
            %extracted_2 = tensor.extract %67[%88] : tensor<256xf32>
            %extracted_3 = tensor.extract %68[%86] : tensor<?xf32>
            %extracted_4 = tensor.extract %69[] : tensor<f32>
            %89 = arith.mulf %extracted_2, %extracted_3 : f32
            %90 = arith.addf %89, %extracted_4 : f32
            %91 = arith.mulf %extracted_0, %90 : f32
            linalg.yield %91 : f32
          } -> tensor<?xf32>
          iree_tensor_ext.dispatch.tensor.store %71, %61, offsets = [0], sizes = [%53], strides = [1] : tensor<?xf32> -> !iree_tensor_ext.dispatch.tensor<writeonly:tensor<?xf32>>{%53}
          return
        }
        iree_codegen.dispatch_config @nf4_nested_f32_dispatch_0_elementwise_broadcast_D_f32 {
        ^bb0(%arg0: !hal.device, %arg1: index, %arg2: index, %arg3: index, %arg4: index, %arg5: index, %arg6: index, %arg7: index):
          %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice(%arg1, %arg2, %arg3, %arg4, %arg5, %arg6, %arg7)
          iree_codegen.yield %x, %y, %z : index, index, index
        }
      }
    }
  }
  util.func public @nf4_nested_f32(%arg0: !hal.buffer_view, %arg1: !hal.buffer_view, %arg2: !hal.buffer_view, %arg3: !hal.buffer_view, %arg4: !hal.buffer_view, %arg5: !hal.buffer_view, %arg6: i32, %arg7: !hal.fence, %arg8: !hal.fence) -> !hal.buffer_view attributes {iree.abi.stub, iree.reflection = {iree.abi.declaration = "async func @nf4_nested_f32(%input0: tensor<?x?xi8>, %input1: tensor<?xi8>, %input2: tensor<?xf32>, %input3: tensor<256xf32>, %input4: tensor<1xf32>, %input5: tensor<16xf32>, %input6: i32) -> (%output0: tensor<?x?xf32>)", iree.abi.model = "coarse-fences"}} {
    %c32_i64 = arith.constant 32 : i64
    %c0 = arith.constant 0 : index
    %c64 = arith.constant 64 : index
    %c1024 = arith.constant 1024 : index
    %c4 = arith.constant 4 : index
    %c16 = arith.constant 16 : index
    %c1 = arith.constant 1 : index
    %c256 = arith.constant 256 : index
    %c2 = arith.constant 2 : index
    %0 = hal.buffer_view.dim<%arg0 : !hal.buffer_view>[0] : index
    %1 = hal.buffer_view.dim<%arg0 : !hal.buffer_view>[1] : index
    %element_type_i8 = hal.element_type<i8> : i32
    %dense_row_major = hal.encoding_type<dense_row_major> : i32
    hal.buffer_view.assert<%arg0 : !hal.buffer_view> message("input0") shape([%0, %1]) type(%element_type_i8) encoding(%dense_row_major)
    %2 = arith.muli %0, %1 : index
    %3 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg0 : !hal.buffer_view -> tensor<?x?xi8>{%0, %1} in !stream.resource<external>{%2}
    %4 = stream.timepoint.import on(#hal.device.affinity<@__device_0>) %arg7 : (!hal.fence) => !stream.timepoint
    %5 = hal.buffer_view.dim<%arg1 : !hal.buffer_view>[0] : index
    hal.buffer_view.assert<%arg1 : !hal.buffer_view> message("input1") shape([%5]) type(%element_type_i8) encoding(%dense_row_major)
    %6 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg1 : !hal.buffer_view -> tensor<?xi8>{%5} in !stream.resource<external>{%5}
    %7 = hal.buffer_view.dim<%arg2 : !hal.buffer_view>[0] : index
    %element_type_f32 = hal.element_type<f32> : i32
    hal.buffer_view.assert<%arg2 : !hal.buffer_view> message("input2") shape([%7]) type(%element_type_f32) encoding(%dense_row_major)
    %8 = arith.muli %7, %c4 : index
    %9 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg2 : !hal.buffer_view -> tensor<?xf32>{%7} in !stream.resource<external>{%8}
    hal.buffer_view.assert<%arg3 : !hal.buffer_view> message("input3") shape([%c256]) type(%element_type_f32) encoding(%dense_row_major)
    %10 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg3 : !hal.buffer_view -> tensor<256xf32> in !stream.resource<external>{%c1024}
    hal.buffer_view.assert<%arg4 : !hal.buffer_view> message("input4") shape([%c1]) type(%element_type_f32) encoding(%dense_row_major)
    %11 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg4 : !hal.buffer_view -> tensor<1xf32> in !stream.resource<external>{%c4}
    hal.buffer_view.assert<%arg5 : !hal.buffer_view> message("input5") shape([%c16]) type(%element_type_f32) encoding(%dense_row_major)
    %12 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg5 : !hal.buffer_view -> tensor<16xf32> in !stream.resource<external>{%c64}
    %13 = arith.muli %1, %c2 : index
    %14 = arith.muli %0, %13 overflow<nsw> : index
    %15 = arith.index_cast %arg6 : i32 to index
    %16 = arith.muli %14, %c4 : index
    %result, %result_timepoint = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) await(%4) => !stream.resource<external>{%16} => !stream.timepoint
    %17 = arith.index_castui %14 : index to i64
    %18 = arith.index_castui %14 : index to i32
    %19 = arith.shrui %17, %c32_i64 : i64
    %20 = arith.trunci %19 : i64 to i32
    %21 = arith.index_castui %13 : index to i64
    %22 = arith.index_castui %13 : index to i32
    %23 = arith.shrui %21, %c32_i64 : i64
    %24 = arith.trunci %23 : i64 to i32
    %25 = arith.index_castui %15 : index to i64
    %26 = arith.index_castui %15 : index to i32
    %27 = arith.shrui %25, %c32_i64 : i64
    %28 = arith.trunci %27 : i64 to i32
    %29 = arith.index_castui %0 : index to i64
    %30 = arith.index_castui %0 : index to i32
    %31 = arith.shrui %29, %c32_i64 : i64
    %32 = arith.trunci %31 : i64 to i32
    %33 = arith.index_castui %1 : index to i64
    %34 = arith.index_castui %1 : index to i32
    %35 = arith.shrui %33, %c32_i64 : i64
    %36 = arith.trunci %35 : i64 to i32
    %37 = arith.index_castui %5 : index to i64
    %38 = arith.index_castui %5 : index to i32
    %39 = arith.shrui %37, %c32_i64 : i64
    %40 = arith.trunci %39 : i64 to i32
    %41 = arith.index_castui %7 : index to i64
    %42 = arith.index_castui %7 : index to i32
    %43 = arith.shrui %41, %c32_i64 : i64
    %44 = arith.trunci %43 : i64 to i32
    %45 = stream.cmd.execute on(#hal.device.affinity<@__device_0>) await(%result_timepoint) => with(%3 as %arg9: !stream.resource<external>{%2}, %12 as %arg10: !stream.resource<external>{%c64}, %6 as %arg11: !stream.resource<external>{%5}, %10 as %arg12: !stream.resource<external>{%c1024}, %9 as %arg13: !stream.resource<external>{%8}, %11 as %arg14: !stream.resource<external>{%c4}, %result as %arg15: !stream.resource<external>{%16}) {
      stream.cmd.dispatch @nf4_nested_f32_dispatch_0::@vulkan_spirv_fb::@nf4_nested_f32_dispatch_0_elementwise_broadcast_D_f32[%14, %13, %15, %0, %1, %5, %7](%18, %20, %22, %24, %26, %28, %30, %32, %34, %36, %38, %40, %42, %44 : i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32) {
        ro %arg9[%c0 for %2] : !stream.resource<external>{%2},
        ro %arg10[%c0 for %c64] : !stream.resource<external>{%c64},
        ro %arg11[%c0 for %5] : !stream.resource<external>{%5},
        ro %arg12[%c0 for %c1024] : !stream.resource<external>{%c1024},
        ro %arg13[%c0 for %8] : !stream.resource<external>{%8},
        ro %arg14[%c0 for %c4] : !stream.resource<external>{%c4},
        wo %arg15[%c0 for %16] : !stream.resource<external>{%16}
      }
    } => !stream.timepoint
    %46 = arith.muli %0, %c4 : index
    %47 = arith.muli %46, %13 : index
    stream.timepoint.chain_external on(#hal.device.affinity<@__device_0>) %45 => (%arg8 : !hal.fence)
    %48 = stream.tensor.export on(#hal.device.affinity<@__device_0>) %result : tensor<?x?xf32>{%0, %13} in !stream.resource<external>{%47} -> !hal.buffer_view
    util.return %48 : !hal.buffer_view
  }
  hal.executable private @nf4_nested_f16_dispatch_0 {
    hal.executable.variant public @vulkan_spirv_fb target(<"vulkan-spirv", "vulkan-spirv-fb", {iree_codegen.target_info = #iree_gpu.target<arch = "vp_android_baseline_2022", features = "spirv:v1.3,cap:Shader,cap:Int16,cap:Float16,cap:StorageBuffer16BitAccess,cap:SignedZeroInfNanPreserve,ext:SPV_KHR_16bit_storage,ext:SPV_KHR_float_controls", wgp = <compute = fp32|int32, storage = b32, subgroup = none, subgroup_size_choices = [64], max_workgroup_sizes = [128, 128, 64], max_thread_count_per_workgroup = 128, max_workgroup_memory_bytes = 16384, max_workgroup_counts = [65535, 65535, 65535]>>}>) {
      hal.executable.export public @nf4_nested_f16_dispatch_0_elementwise_broadcast_D_f16 ordinal(0) layout(#hal.pipeline.layout<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) count(%arg0: !hal.device, %arg1: index, %arg2: index, %arg3: index, %arg4: index, %arg5: index, %arg6: index, %arg7: index) -> (index, index, index) {
        %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice(%arg1, %arg2, %arg3, %arg4, %arg5, %arg6, %arg7)
        hal.return %x, %y, %z : index, index, index
      }
      builtin.module {
        func.func @nf4_nested_f16_dispatch_0_elementwise_broadcast_D_f16() attributes {translation_info = #iree_codegen.translation_info<pipeline = #iree_gpu.spirv_pipeline<BaseDistribute> workgroup_size = [64, 1, 1]>} {
          %c32_i64 = arith.constant 32 : i64
          %c255 = arith.constant 255 : index
          %c256 = arith.constant 256 : index
          %c15_i32 = arith.constant 15 : i32
          %c4_i32 = arith.constant 4 : i32
          %c2 = arith.constant 2 : index
          %c0 = arith.constant 0 : index
          %0 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(0) : i32
          %1 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(1) : i32
          %2 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(2) : i32
          %3 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(3) : i32
          %4 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(4) : i32
          %5 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(5) : i32
          %6 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(6) : i32
          %7 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(7) : i32
          %8 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(8) : i32
          %9 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(9) : i32
          %10 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(10) : i32
          %11 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(11) : i32
          %12 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(12) : i32
          %13 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(13) : i32
          %14 = arith.extui %1 : i32 to i64
          %15 = arith.shli %14, %c32_i64 : i64
          %16 = arith.extui %0 : i32 to i64
          %17 = arith.ori %16, %15 : i64
          %18 = arith.index_castui %17 : i64 to index
          %19 = arith.extui %3 : i32 to i64
          %20 = arith.shli %19, %c32_i64 : i64
          %21 = arith.extui %2 : i32 to i64
          %22 = arith.ori %21, %20 : i64
          %23 = arith.index_castui %22 : i64 to index
          %24 = arith.extui %5 : i32 to i64
          %25 = arith.shli %24, %c32_i64 : i64
          %26 = arith.extui %4 : i32 to i64
          %27 = arith.ori %26, %25 : i64
          %28 = arith.index_castui %27 : i64 to index
          %29 = arith.extui %7 : i32 to i64
          %30 = arith.shli %29, %c32_i64 : i64
          %31 = arith.extui %6 : i32 to i64
          %32 = arith.ori %31, %30 : i64
          %33 = arith.index_castui %32 : i64 to index
          %34 = arith.extui %9 : i32 to i64
          %35 = arith.shli %34, %c32_i64 : i64
          %36 = arith.extui %8 : i32 to i64
          %37 = arith.ori %36, %35 : i64
          %38 = arith.index_castui %37 : i64 to index
          %39 = arith.extui %11 : i32 to i64
          %40 = arith.shli %39, %c32_i64 : i64
          %41 = arith.extui %10 : i32 to i64
          %42 = arith.ori %41, %40 : i64
          %43 = arith.index_castui %42 : i64 to index
          %44 = arith.extui %13 : i32 to i64
          %45 = arith.shli %44, %c32_i64 : i64
          %46 = arith.extui %12 : i32 to i64
          %47 = arith.ori %46, %45 : i64
          %48 = arith.index_castui %47 : i64 to index
          %49:6 = util.assume.int 
              %18<umin = 0, umax = 9223372036854775807, udiv = 2>, 
              %23<umin = 0, umax = 18014398509481982, udiv = 2>, 
              %33<umin = 0, umax = 9007199254740991>, 
              %38<umin = 0, umax = 9007199254740991>, 
              %43<umin = 0, umax = 9007199254740991>, 
              %48<umin = 0, umax = 9007199254740991>
            : index, index, index, index, index, index
          %50 = hal.interface.binding.subspan layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(1) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<16xf32>>
          %51 = hal.interface.binding.subspan layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(3) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<256xf32>>
          %52 = hal.interface.binding.subspan layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(5) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<f32>>
          %53 = iree_tensor_ext.dispatch.workload.ordinal %49#0, 0 : index
          %54 = iree_tensor_ext.dispatch.workload.ordinal %49#2, 3 : index
          %55 = iree_tensor_ext.dispatch.workload.ordinal %49#3, 4 : index
          %56 = iree_tensor_ext.dispatch.workload.ordinal %49#4, 5 : index
          %57 = iree_tensor_ext.dispatch.workload.ordinal %49#5, 6 : index
          %58 = hal.interface.binding.subspan layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(0) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xi8>>{%54, %55}
          %59 = hal.interface.binding.subspan layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(2) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?xi8>>{%56}
          %60 = hal.interface.binding.subspan layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(4) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?xf32>>{%57}
          %61 = hal.interface.binding.subspan layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(6) alignment(64) offset(%c0) flags(Indirect) : !iree_tensor_ext.dispatch.tensor<writeonly:tensor<?xf16>>{%53}
          %62 = iree_tensor_ext.dispatch.workload.ordinal %49#1, 1 : index
          %63 = iree_tensor_ext.dispatch.workload.ordinal %28, 2 : index
          %64 = iree_tensor_ext.dispatch.tensor.load %58, offsets = [0, 0], sizes = [%54, %55], strides = [1, 1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xi8>>{%54, %55} -> tensor<?x?xi8>
          %65 = iree_tensor_ext.dispatch.tensor.load %50, offsets = [0], sizes = [16], strides = [1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<16xf32>> -> tensor<16xf32>
          %66 = iree_tensor_ext.dispatch.tensor.load %59, offsets = [0], sizes = [%56], strides = [1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?xi8>>{%56} -> tensor<?xi8>
          %67 = iree_tensor_ext.dispatch.tensor.load %51, offsets = [0], sizes = [256], strides = [1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<256xf32>> -> tensor<256xf32>
          %68 = iree_tensor_ext.dispatch.tensor.load %60, offsets = [0], sizes = [%57], strides = [1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?xf32>>{%57} -> tensor<?xf32>
          %69 = iree_tensor_ext.dispatch.tensor.load %52, offsets = [], sizes = [], strides = [] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<f32>> -> tensor<f32>
          %70 = tensor.empty(%53) : tensor<?xf16>
          %71 = linalg.generic {indexing_maps = [affine_map<(d0) -> (d0)>], iterator_types = ["parallel"]} outs(%70 : tensor<?xf16>) attrs =  {lowering_config = #iree_codegen.lowering_config<tile_sizes = [[64], [1]]>} {
          ^bb0(%out: f16):
            %72 = linalg.index 0 : index
            %73 = arith.remsi %72, %62 : index
            %74 = arith.divsi %72, %62 : index
            %75 = arith.divui %73, %c2 : index
            %76 = arith.remui %73, %c2 : index
            %extracted = tensor.extract %64[%74, %75] : tensor<?x?xi8>
            %77 = arith.extui %extracted : i8 to i32
            %78 = arith.cmpi eq, %76, %c0 : index
            %79 = arith.shrui %77, %c4_i32 : i32
            %80 = arith.select %78, %79, %77 : i32
            %81 = arith.andi %80, %c15_i32 : i32
            %82 = arith.index_castui %81 : i32 to index
            %extracted_0 = tensor.extract %65[%82] : tensor<16xf32>
            %83 = arith.muli %74, %62 : index
            %84 = arith.addi %83, %73 : index
            %85 = arith.divui %84, %63 : index
            %86 = arith.divui %85, %c256 : index
            %extracted_1 = tensor.extract %66[%85] : tensor<?xi8>
            %87 = arith.index_cast %extracted_1 : i8 to index
            %88 = arith.andi %87, %c255 : index
            %extracted_2 = tensor.extract %67[%88] : tensor<256xf32>
            %extracted_3 = tensor.extract %68[%86] : tensor<?xf32>
            %extracted_4 = tensor.extract %69[] : tensor<f32>
            %89 = arith.mulf %extracted_2, %extracted_3 : f32
            %90 = arith.addf %89, %extracted_4 : f32
            %91 = arith.mulf %extracted_0, %90 : f32
            %92 = arith.truncf %91 : f32 to f16
            linalg.yield %92 : f16
          } -> tensor<?xf16>
          iree_tensor_ext.dispatch.tensor.store %71, %61, offsets = [0], sizes = [%53], strides = [1] : tensor<?xf16> -> !iree_tensor_ext.dispatch.tensor<writeonly:tensor<?xf16>>{%53}
          return
        }
        iree_codegen.dispatch_config @nf4_nested_f16_dispatch_0_elementwise_broadcast_D_f16 {
        ^bb0(%arg0: !hal.device, %arg1: index, %arg2: index, %arg3: index, %arg4: index, %arg5: index, %arg6: index, %arg7: index):
          %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice(%arg1, %arg2, %arg3, %arg4, %arg5, %arg6, %arg7)
          iree_codegen.yield %x, %y, %z : index, index, index
        }
      }
    }
  }
  util.func public @nf4_nested_f16(%arg0: !hal.buffer_view, %arg1: !hal.buffer_view, %arg2: !hal.buffer_view, %arg3: !hal.buffer_view, %arg4: !hal.buffer_view, %arg5: !hal.buffer_view, %arg6: i32, %arg7: !hal.fence, %arg8: !hal.fence) -> !hal.buffer_view attributes {iree.abi.stub, iree.reflection = {iree.abi.declaration = "async func @nf4_nested_f16(%input0: tensor<?x?xi8>, %input1: tensor<?xi8>, %input2: tensor<?xf32>, %input3: tensor<256xf32>, %input4: tensor<1xf32>, %input5: tensor<16xf32>, %input6: i32) -> (%output0: tensor<?x?xf16>)", iree.abi.model = "coarse-fences"}} {
    %c32_i64 = arith.constant 32 : i64
    %c0 = arith.constant 0 : index
    %c64 = arith.constant 64 : index
    %c1024 = arith.constant 1024 : index
    %c4 = arith.constant 4 : index
    %c16 = arith.constant 16 : index
    %c1 = arith.constant 1 : index
    %c256 = arith.constant 256 : index
    %c2 = arith.constant 2 : index
    %0 = hal.buffer_view.dim<%arg0 : !hal.buffer_view>[0] : index
    %1 = hal.buffer_view.dim<%arg0 : !hal.buffer_view>[1] : index
    %element_type_i8 = hal.element_type<i8> : i32
    %dense_row_major = hal.encoding_type<dense_row_major> : i32
    hal.buffer_view.assert<%arg0 : !hal.buffer_view> message("input0") shape([%0, %1]) type(%element_type_i8) encoding(%dense_row_major)
    %2 = arith.muli %0, %1 : index
    %3 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg0 : !hal.buffer_view -> tensor<?x?xi8>{%0, %1} in !stream.resource<external>{%2}
    %4 = stream.timepoint.import on(#hal.device.affinity<@__device_0>) %arg7 : (!hal.fence) => !stream.timepoint
    %5 = hal.buffer_view.dim<%arg1 : !hal.buffer_view>[0] : index
    hal.buffer_view.assert<%arg1 : !hal.buffer_view> message("input1") shape([%5]) type(%element_type_i8) encoding(%dense_row_major)
    %6 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg1 : !hal.buffer_view -> tensor<?xi8>{%5} in !stream.resource<external>{%5}
    %7 = hal.buffer_view.dim<%arg2 : !hal.buffer_view>[0] : index
    %element_type_f32 = hal.element_type<f32> : i32
    hal.buffer_view.assert<%arg2 : !hal.buffer_view> message("input2") shape([%7]) type(%element_type_f32) encoding(%dense_row_major)
    %8 = arith.muli %7, %c4 : index
    %9 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg2 : !hal.buffer_view -> tensor<?xf32>{%7} in !stream.resource<external>{%8}
    hal.buffer_view.assert<%arg3 : !hal.buffer_view> message("input3") shape([%c256]) type(%element_type_f32) encoding(%dense_row_major)
    %10 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg3 : !hal.buffer_view -> tensor<256xf32> in !stream.resource<external>{%c1024}
    hal.buffer_view.assert<%arg4 : !hal.buffer_view> message("input4") shape([%c1]) type(%element_type_f32) encoding(%dense_row_major)
    %11 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg4 : !hal.buffer_view -> tensor<1xf32> in !stream.resource<external>{%c4}
    hal.buffer_view.assert<%arg5 : !hal.buffer_view> message("input5") shape([%c16]) type(%element_type_f32) encoding(%dense_row_major)
    %12 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg5 : !hal.buffer_view -> tensor<16xf32> in !stream.resource<external>{%c64}
    %13 = arith.muli %1, %c2 : index
    %14 = arith.muli %0, %13 overflow<nsw> : index
    %15 = arith.index_cast %arg6 : i32 to index
    %16 = arith.muli %14, %c2 : index
    %result, %result_timepoint = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) await(%4) => !stream.resource<external>{%16} => !stream.timepoint
    %17 = arith.index_castui %14 : index to i64
    %18 = arith.index_castui %14 : index to i32
    %19 = arith.shrui %17, %c32_i64 : i64
    %20 = arith.trunci %19 : i64 to i32
    %21 = arith.index_castui %13 : index to i64
    %22 = arith.index_castui %13 : index to i32
    %23 = arith.shrui %21, %c32_i64 : i64
    %24 = arith.trunci %23 : i64 to i32
    %25 = arith.index_castui %15 : index to i64
    %26 = arith.index_castui %15 : index to i32
    %27 = arith.shrui %25, %c32_i64 : i64
    %28 = arith.trunci %27 : i64 to i32
    %29 = arith.index_castui %0 : index to i64
    %30 = arith.index_castui %0 : index to i32
    %31 = arith.shrui %29, %c32_i64 : i64
    %32 = arith.trunci %31 : i64 to i32
    %33 = arith.index_castui %1 : index to i64
    %34 = arith.index_castui %1 : index to i32
    %35 = arith.shrui %33, %c32_i64 : i64
    %36 = arith.trunci %35 : i64 to i32
    %37 = arith.index_castui %5 : index to i64
    %38 = arith.index_castui %5 : index to i32
    %39 = arith.shrui %37, %c32_i64 : i64
    %40 = arith.trunci %39 : i64 to i32
    %41 = arith.index_castui %7 : index to i64
    %42 = arith.index_castui %7 : index to i32
    %43 = arith.shrui %41, %c32_i64 : i64
    %44 = arith.trunci %43 : i64 to i32
    %45 = stream.cmd.execute on(#hal.device.affinity<@__device_0>) await(%result_timepoint) => with(%3 as %arg9: !stream.resource<external>{%2}, %12 as %arg10: !stream.resource<external>{%c64}, %6 as %arg11: !stream.resource<external>{%5}, %10 as %arg12: !stream.resource<external>{%c1024}, %9 as %arg13: !stream.resource<external>{%8}, %11 as %arg14: !stream.resource<external>{%c4}, %result as %arg15: !stream.resource<external>{%16}) {
      stream.cmd.dispatch @nf4_nested_f16_dispatch_0::@vulkan_spirv_fb::@nf4_nested_f16_dispatch_0_elementwise_broadcast_D_f16[%14, %13, %15, %0, %1, %5, %7](%18, %20, %22, %24, %26, %28, %30, %32, %34, %36, %38, %40, %42, %44 : i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32) {
        ro %arg9[%c0 for %2] : !stream.resource<external>{%2},
        ro %arg10[%c0 for %c64] : !stream.resource<external>{%c64},
        ro %arg11[%c0 for %5] : !stream.resource<external>{%5},
        ro %arg12[%c0 for %c1024] : !stream.resource<external>{%c1024},
        ro %arg13[%c0 for %8] : !stream.resource<external>{%8},
        ro %arg14[%c0 for %c4] : !stream.resource<external>{%c4},
        wo %arg15[%c0 for %16] : !stream.resource<external>{%16}
      }
    } => !stream.timepoint
    %46 = arith.muli %0, %c2 : index
    %47 = arith.muli %46, %13 : index
    stream.timepoint.chain_external on(#hal.device.affinity<@__device_0>) %45 => (%arg8 : !hal.fence)
    %48 = stream.tensor.export on(#hal.device.affinity<@__device_0>) %result : tensor<?x?xf16>{%0, %13} in !stream.resource<external>{%47} -> !hal.buffer_view
    util.return %48 : !hal.buffer_view
  }
  hal.executable private @nf4_nested_bf16_dispatch_0 {
    hal.executable.variant public @vulkan_spirv_fb target(<"vulkan-spirv", "vulkan-spirv-fb", {iree_codegen.target_info = #iree_gpu.target<arch = "vp_android_baseline_2022", features = "spirv:v1.3,cap:Shader,cap:Int16,cap:Float16,cap:StorageBuffer16BitAccess,cap:SignedZeroInfNanPreserve,ext:SPV_KHR_16bit_storage,ext:SPV_KHR_float_controls", wgp = <compute = fp32|int32, storage = b32, subgroup = none, subgroup_size_choices = [64], max_workgroup_sizes = [128, 128, 64], max_thread_count_per_workgroup = 128, max_workgroup_memory_bytes = 16384, max_workgroup_counts = [65535, 65535, 65535]>>}>) {
      hal.executable.export public @nf4_nested_bf16_dispatch_0_elementwise_broadcast_D_i16 ordinal(0) layout(#hal.pipeline.layout<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) count(%arg0: !hal.device, %arg1: index, %arg2: index, %arg3: index, %arg4: index, %arg5: index, %arg6: index, %arg7: index) -> (index, index, index) {
        %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice(%arg1, %arg2, %arg3, %arg4, %arg5, %arg6, %arg7)
        hal.return %x, %y, %z : index, index, index
      }
      builtin.module {
        func.func @nf4_nested_bf16_dispatch_0_elementwise_broadcast_D_i16() attributes {translation_info = #iree_codegen.translation_info<pipeline = #iree_gpu.spirv_pipeline<BaseDistribute> workgroup_size = [64, 1, 1]>} {
          %c32_i64 = arith.constant 32 : i64
          %c255 = arith.constant 255 : index
          %c256 = arith.constant 256 : index
          %c15_i32 = arith.constant 15 : i32
          %c4_i32 = arith.constant 4 : i32
          %c2 = arith.constant 2 : index
          %c0 = arith.constant 0 : index
          %0 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(0) : i32
          %1 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(1) : i32
          %2 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(2) : i32
          %3 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(3) : i32
          %4 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(4) : i32
          %5 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(5) : i32
          %6 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(6) : i32
          %7 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(7) : i32
          %8 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(8) : i32
          %9 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(9) : i32
          %10 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(10) : i32
          %11 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(11) : i32
          %12 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(12) : i32
          %13 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(13) : i32
          %14 = arith.extui %1 : i32 to i64
          %15 = arith.shli %14, %c32_i64 : i64
          %16 = arith.extui %0 : i32 to i64
          %17 = arith.ori %16, %15 : i64
          %18 = arith.index_castui %17 : i64 to index
          %19 = arith.extui %3 : i32 to i64
          %20 = arith.shli %19, %c32_i64 : i64
          %21 = arith.extui %2 : i32 to i64
          %22 = arith.ori %21, %20 : i64
          %23 = arith.index_castui %22 : i64 to index
          %24 = arith.extui %5 : i32 to i64
          %25 = arith.shli %24, %c32_i64 : i64
          %26 = arith.extui %4 : i32 to i64
          %27 = arith.ori %26, %25 : i64
          %28 = arith.index_castui %27 : i64 to index
          %29 = arith.extui %7 : i32 to i64
          %30 = arith.shli %29, %c32_i64 : i64
          %31 = arith.extui %6 : i32 to i64
          %32 = arith.ori %31, %30 : i64
          %33 = arith.index_castui %32 : i64 to index
          %34 = arith.extui %9 : i32 to i64
          %35 = arith.shli %34, %c32_i64 : i64
          %36 = arith.extui %8 : i32 to i64
          %37 = arith.ori %36, %35 : i64
          %38 = arith.index_castui %37 : i64 to index
          %39 = arith.extui %11 : i32 to i64
          %40 = arith.shli %39, %c32_i64 : i64
          %41 = arith.extui %10 : i32 to i64
          %42 = arith.ori %41, %40 : i64
          %43 = arith.index_castui %42 : i64 to index
          %44 = arith.extui %13 : i32 to i64
          %45 = arith.shli %44, %c32_i64 : i64
          %46 = arith.extui %12 : i32 to i64
          %47 = arith.ori %46, %45 : i64
          %48 = arith.index_castui %47 : i64 to index
          %49:6 = util.assume.int 
              %18<umin = 0, umax = 9223372036854775807, udiv = 2>, 
              %23<umin = 0, umax = 18014398509481982, udiv = 2>, 
              %33<umin = 0, umax = 9007199254740991>, 
              %38<umin = 0, umax = 9007199254740991>, 
              %43<umin = 0, umax = 9007199254740991>, 
              %48<umin = 0, umax = 9007199254740991>
            : index, index, index, index, index, index
          %50 = hal.interface.binding.subspan layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(1) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<16xf32>>
          %51 = hal.interface.binding.subspan layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(3) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<256xf32>>
          %52 = hal.interface.binding.subspan layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(5) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<f32>>
          %53 = iree_tensor_ext.dispatch.workload.ordinal %49#0, 0 : index
          %54 = iree_tensor_ext.dispatch.workload.ordinal %49#2, 3 : index
          %55 = iree_tensor_ext.dispatch.workload.ordinal %49#3, 4 : index
          %56 = iree_tensor_ext.dispatch.workload.ordinal %49#4, 5 : index
          %57 = iree_tensor_ext.dispatch.workload.ordinal %49#5, 6 : index
          %58 = hal.interface.binding.subspan layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(0) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xi8>>{%54, %55}
          %59 = hal.interface.binding.subspan layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(2) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?xi8>>{%56}
          %60 = hal.interface.binding.subspan layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(4) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?xf32>>{%57}
          %61 = hal.interface.binding.subspan layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(6) alignment(64) offset(%c0) flags(Indirect) : !iree_tensor_ext.dispatch.tensor<writeonly:tensor<?xi16>>{%53}
          %62 = iree_tensor_ext.dispatch.workload.ordinal %49#1, 1 : index
          %63 = iree_tensor_ext.dispatch.workload.ordinal %28, 2 : index
          %64 = iree_tensor_ext.dispatch.tensor.load %58, offsets = [0, 0], sizes = [%54, %55], strides = [1, 1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xi8>>{%54, %55} -> tensor<?x?xi8>
          %65 = iree_tensor_ext.dispatch.tensor.load %50, offsets = [0], sizes = [16], strides = [1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<16xf32>> -> tensor<16xf32>
          %66 = iree_tensor_ext.dispatch.tensor.load %59, offsets = [0], sizes = [%56], strides = [1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?xi8>>{%56} -> tensor<?xi8>
          %67 = iree_tensor_ext.dispatch.tensor.load %51, offsets = [0], sizes = [256], strides = [1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<256xf32>> -> tensor<256xf32>
          %68 = iree_tensor_ext.dispatch.tensor.load %60, offsets = [0], sizes = [%57], strides = [1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?xf32>>{%57} -> tensor<?xf32>
          %69 = iree_tensor_ext.dispatch.tensor.load %52, offsets = [], sizes = [], strides = [] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<f32>> -> tensor<f32>
          %70 = tensor.empty(%53) : tensor<?xi16>
          %71 = linalg.generic {indexing_maps = [affine_map<(d0) -> (d0)>], iterator_types = ["parallel"]} outs(%70 : tensor<?xi16>) attrs =  {lowering_config = #iree_codegen.lowering_config<tile_sizes = [[64], [1]]>} {
          ^bb0(%out: i16):
            %72 = linalg.index 0 : index
            %73 = arith.remsi %72, %62 : index
            %74 = arith.divsi %72, %62 : index
            %75 = arith.divui %73, %c2 : index
            %76 = arith.remui %73, %c2 : index
            %extracted = tensor.extract %64[%74, %75] : tensor<?x?xi8>
            %77 = arith.extui %extracted : i8 to i32
            %78 = arith.cmpi eq, %76, %c0 : index
            %79 = arith.shrui %77, %c4_i32 : i32
            %80 = arith.select %78, %79, %77 : i32
            %81 = arith.andi %80, %c15_i32 : i32
            %82 = arith.index_castui %81 : i32 to index
            %extracted_0 = tensor.extract %65[%82] : tensor<16xf32>
            %83 = arith.muli %74, %62 : index
            %84 = arith.addi %83, %73 : index
            %85 = arith.divui %84, %63 : index
            %86 = arith.divui %85, %c256 : index
            %extracted_1 = tensor.extract %66[%85] : tensor<?xi8>
            %87 = arith.index_cast %extracted_1 : i8 to index
            %88 = arith.andi %87, %c255 : index
            %extracted_2 = tensor.extract %67[%88] : tensor<256xf32>
            %extracted_3 = tensor.extract %68[%86] : tensor<?xf32>
            %extracted_4 = tensor.extract %69[] : tensor<f32>
            %89 = arith.mulf %extracted_2, %extracted_3 : f32
            %90 = arith.addf %89, %extracted_4 : f32
            %91 = arith.mulf %extracted_0, %90 : f32
            %92 = arith.truncf %91 : f32 to bf16
            %93 = arith.bitcast %92 : bf16 to i16
            linalg.yield %93 : i16
          } -> tensor<?xi16>
          iree_tensor_ext.dispatch.tensor.store %71, %61, offsets = [0], sizes = [%53], strides = [1] : tensor<?xi16> -> !iree_tensor_ext.dispatch.tensor<writeonly:tensor<?xi16>>{%53}
          return
        }
        iree_codegen.dispatch_config @nf4_nested_bf16_dispatch_0_elementwise_broadcast_D_i16 {
        ^bb0(%arg0: !hal.device, %arg1: index, %arg2: index, %arg3: index, %arg4: index, %arg5: index, %arg6: index, %arg7: index):
          %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice(%arg1, %arg2, %arg3, %arg4, %arg5, %arg6, %arg7)
          iree_codegen.yield %x, %y, %z : index, index, index
        }
      }
    }
  }
  util.func public @nf4_nested_bf16(%arg0: !hal.buffer_view, %arg1: !hal.buffer_view, %arg2: !hal.buffer_view, %arg3: !hal.buffer_view, %arg4: !hal.buffer_view, %arg5: !hal.buffer_view, %arg6: i32, %arg7: !hal.fence, %arg8: !hal.fence) -> !hal.buffer_view attributes {iree.abi.stub, iree.reflection = {iree.abi.declaration = "async func @nf4_nested_bf16(%input0: tensor<?x?xi8>, %input1: tensor<?xi8>, %input2: tensor<?xf32>, %input3: tensor<256xf32>, %input4: tensor<1xf32>, %input5: tensor<16xf32>, %input6: i32) -> (%output0: tensor<?x?xi16>)", iree.abi.model = "coarse-fences"}} {
    %c32_i64 = arith.constant 32 : i64
    %c0 = arith.constant 0 : index
    %c64 = arith.constant 64 : index
    %c1024 = arith.constant 1024 : index
    %c4 = arith.constant 4 : index
    %c16 = arith.constant 16 : index
    %c1 = arith.constant 1 : index
    %c256 = arith.constant 256 : index
    %c2 = arith.constant 2 : index
    %0 = hal.buffer_view.dim<%arg0 : !hal.buffer_view>[0] : index
    %1 = hal.buffer_view.dim<%arg0 : !hal.buffer_view>[1] : index
    %element_type_i8 = hal.element_type<i8> : i32
    %dense_row_major = hal.encoding_type<dense_row_major> : i32
    hal.buffer_view.assert<%arg0 : !hal.buffer_view> message("input0") shape([%0, %1]) type(%element_type_i8) encoding(%dense_row_major)
    %2 = arith.muli %0, %1 : index
    %3 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg0 : !hal.buffer_view -> tensor<?x?xi8>{%0, %1} in !stream.resource<external>{%2}
    %4 = stream.timepoint.import on(#hal.device.affinity<@__device_0>) %arg7 : (!hal.fence) => !stream.timepoint
    %5 = hal.buffer_view.dim<%arg1 : !hal.buffer_view>[0] : index
    hal.buffer_view.assert<%arg1 : !hal.buffer_view> message("input1") shape([%5]) type(%element_type_i8) encoding(%dense_row_major)
    %6 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg1 : !hal.buffer_view -> tensor<?xi8>{%5} in !stream.resource<external>{%5}
    %7 = hal.buffer_view.dim<%arg2 : !hal.buffer_view>[0] : index
    %element_type_f32 = hal.element_type<f32> : i32
    hal.buffer_view.assert<%arg2 : !hal.buffer_view> message("input2") shape([%7]) type(%element_type_f32) encoding(%dense_row_major)
    %8 = arith.muli %7, %c4 : index
    %9 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg2 : !hal.buffer_view -> tensor<?xf32>{%7} in !stream.resource<external>{%8}
    hal.buffer_view.assert<%arg3 : !hal.buffer_view> message("input3") shape([%c256]) type(%element_type_f32) encoding(%dense_row_major)
    %10 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg3 : !hal.buffer_view -> tensor<256xf32> in !stream.resource<external>{%c1024}
    hal.buffer_view.assert<%arg4 : !hal.buffer_view> message("input4") shape([%c1]) type(%element_type_f32) encoding(%dense_row_major)
    %11 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg4 : !hal.buffer_view -> tensor<1xf32> in !stream.resource<external>{%c4}
    hal.buffer_view.assert<%arg5 : !hal.buffer_view> message("input5") shape([%c16]) type(%element_type_f32) encoding(%dense_row_major)
    %12 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg5 : !hal.buffer_view -> tensor<16xf32> in !stream.resource<external>{%c64}
    %13 = arith.muli %1, %c2 : index
    %14 = arith.muli %0, %13 overflow<nsw> : index
    %15 = arith.index_cast %arg6 : i32 to index
    %16 = arith.muli %14, %c2 : index
    %result, %result_timepoint = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) await(%4) => !stream.resource<external>{%16} => !stream.timepoint
    %17 = arith.index_castui %14 : index to i64
    %18 = arith.index_castui %14 : index to i32
    %19 = arith.shrui %17, %c32_i64 : i64
    %20 = arith.trunci %19 : i64 to i32
    %21 = arith.index_castui %13 : index to i64
    %22 = arith.index_castui %13 : index to i32
    %23 = arith.shrui %21, %c32_i64 : i64
    %24 = arith.trunci %23 : i64 to i32
    %25 = arith.index_castui %15 : index to i64
    %26 = arith.index_castui %15 : index to i32
    %27 = arith.shrui %25, %c32_i64 : i64
    %28 = arith.trunci %27 : i64 to i32
    %29 = arith.index_castui %0 : index to i64
    %30 = arith.index_castui %0 : index to i32
    %31 = arith.shrui %29, %c32_i64 : i64
    %32 = arith.trunci %31 : i64 to i32
    %33 = arith.index_castui %1 : index to i64
    %34 = arith.index_castui %1 : index to i32
    %35 = arith.shrui %33, %c32_i64 : i64
    %36 = arith.trunci %35 : i64 to i32
    %37 = arith.index_castui %5 : index to i64
    %38 = arith.index_castui %5 : index to i32
    %39 = arith.shrui %37, %c32_i64 : i64
    %40 = arith.trunci %39 : i64 to i32
    %41 = arith.index_castui %7 : index to i64
    %42 = arith.index_castui %7 : index to i32
    %43 = arith.shrui %41, %c32_i64 : i64
    %44 = arith.trunci %43 : i64 to i32
    %45 = stream.cmd.execute on(#hal.device.affinity<@__device_0>) await(%result_timepoint) => with(%3 as %arg9: !stream.resource<external>{%2}, %12 as %arg10: !stream.resource<external>{%c64}, %6 as %arg11: !stream.resource<external>{%5}, %10 as %arg12: !stream.resource<external>{%c1024}, %9 as %arg13: !stream.resource<external>{%8}, %11 as %arg14: !stream.resource<external>{%c4}, %result as %arg15: !stream.resource<external>{%16}) {
      stream.cmd.dispatch @nf4_nested_bf16_dispatch_0::@vulkan_spirv_fb::@nf4_nested_bf16_dispatch_0_elementwise_broadcast_D_i16[%14, %13, %15, %0, %1, %5, %7](%18, %20, %22, %24, %26, %28, %30, %32, %34, %36, %38, %40, %42, %44 : i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32) {
        ro %arg9[%c0 for %2] : !stream.resource<external>{%2},
        ro %arg10[%c0 for %c64] : !stream.resource<external>{%c64},
        ro %arg11[%c0 for %5] : !stream.resource<external>{%5},
        ro %arg12[%c0 for %c1024] : !stream.resource<external>{%c1024},
        ro %arg13[%c0 for %8] : !stream.resource<external>{%8},
        ro %arg14[%c0 for %c4] : !stream.resource<external>{%c4},
        wo %arg15[%c0 for %16] : !stream.resource<external>{%16}
      }
    } => !stream.timepoint
    %46 = arith.muli %0, %c2 : index
    %47 = arith.muli %46, %13 : index
    stream.timepoint.chain_external on(#hal.device.affinity<@__device_0>) %45 => (%arg8 : !hal.fence)
    %48 = stream.tensor.export on(#hal.device.affinity<@__device_0>) %result : tensor<?x?xi16>{%0, %13} in !stream.resource<external>{%47} -> !hal.buffer_view
    util.return %48 : !hal.buffer_view
  }
  hal.executable private @awq_f32_f32_dispatch_0 {
    hal.executable.variant public @vulkan_spirv_fb target(<"vulkan-spirv", "vulkan-spirv-fb", {iree_codegen.target_info = #iree_gpu.target<arch = "vp_android_baseline_2022", features = "spirv:v1.3,cap:Shader,cap:Int16,cap:Float16,cap:StorageBuffer16BitAccess,cap:SignedZeroInfNanPreserve,ext:SPV_KHR_16bit_storage,ext:SPV_KHR_float_controls", wgp = <compute = fp32|int32, storage = b32, subgroup = none, subgroup_size_choices = [64], max_workgroup_sizes = [128, 128, 64], max_thread_count_per_workgroup = 128, max_workgroup_memory_bytes = 16384, max_workgroup_counts = [65535, 65535, 65535]>>}>) {
      hal.executable.export public @awq_f32_f32_dispatch_0_elementwise_broadcast_D_f32 ordinal(0) layout(#hal.pipeline.layout<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) count(%arg0: !hal.device, %arg1: index, %arg2: index, %arg3: index, %arg4: index, %arg5: index, %arg6: index, %arg7: index, %arg8: index) -> (index, index, index) {
        %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice(%arg1, %arg2, %arg3, %arg4, %arg5, %arg6, %arg7, %arg8)
        hal.return %x, %y, %z : index, index, index
      }
      builtin.module {
        func.func @awq_f32_f32_dispatch_0_elementwise_broadcast_D_f32() attributes {translation_info = #iree_codegen.translation_info<pipeline = #iree_gpu.spirv_pipeline<BaseDistribute> workgroup_size = [64, 1, 1]>} {
          %c32_i64 = arith.constant 32 : i64
          %c8 = arith.constant 8 : index
          %c2 = arith.constant 2 : index
          %c4 = arith.constant 4 : index
          %c15_i32 = arith.constant 15 : i32
          %c0 = arith.constant 0 : index
          %0 = hal.interface.constant.load layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(0) : i32
          %1 = hal.interface.constant.load layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(1) : i32
          %2 = hal.interface.constant.load layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(2) : i32
          %3 = hal.interface.constant.load layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(3) : i32
          %4 = hal.interface.constant.load layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(4) : i32
          %5 = hal.interface.constant.load layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(5) : i32
          %6 = hal.interface.constant.load layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(6) : i32
          %7 = hal.interface.constant.load layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(7) : i32
          %8 = hal.interface.constant.load layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(8) : i32
          %9 = hal.interface.constant.load layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(9) : i32
          %10 = hal.interface.constant.load layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(10) : i32
          %11 = hal.interface.constant.load layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(11) : i32
          %12 = hal.interface.constant.load layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(12) : i32
          %13 = hal.interface.constant.load layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(13) : i32
          %14 = hal.interface.constant.load layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(14) : i32
          %15 = hal.interface.constant.load layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(15) : i32
          %16 = arith.extui %1 : i32 to i64
          %17 = arith.shli %16, %c32_i64 : i64
          %18 = arith.extui %0 : i32 to i64
          %19 = arith.ori %18, %17 : i64
          %20 = arith.index_castui %19 : i64 to index
          %21 = arith.extui %3 : i32 to i64
          %22 = arith.shli %21, %c32_i64 : i64
          %23 = arith.extui %2 : i32 to i64
          %24 = arith.ori %23, %22 : i64
          %25 = arith.index_castui %24 : i64 to index
          %26 = arith.extui %5 : i32 to i64
          %27 = arith.shli %26, %c32_i64 : i64
          %28 = arith.extui %4 : i32 to i64
          %29 = arith.ori %28, %27 : i64
          %30 = arith.index_castui %29 : i64 to index
          %31 = arith.extui %7 : i32 to i64
          %32 = arith.shli %31, %c32_i64 : i64
          %33 = arith.extui %6 : i32 to i64
          %34 = arith.ori %33, %32 : i64
          %35 = arith.index_castui %34 : i64 to index
          %36 = arith.extui %9 : i32 to i64
          %37 = arith.shli %36, %c32_i64 : i64
          %38 = arith.extui %8 : i32 to i64
          %39 = arith.ori %38, %37 : i64
          %40 = arith.index_castui %39 : i64 to index
          %41 = arith.extui %11 : i32 to i64
          %42 = arith.shli %41, %c32_i64 : i64
          %43 = arith.extui %10 : i32 to i64
          %44 = arith.ori %43, %42 : i64
          %45 = arith.index_castui %44 : i64 to index
          %46 = arith.extui %13 : i32 to i64
          %47 = arith.shli %46, %c32_i64 : i64
          %48 = arith.extui %12 : i32 to i64
          %49 = arith.ori %48, %47 : i64
          %50 = arith.index_castui %49 : i64 to index
          %51 = arith.extui %15 : i32 to i64
          %52 = arith.shli %51, %c32_i64 : i64
          %53 = arith.extui %14 : i32 to i64
          %54 = arith.ori %53, %52 : i64
          %55 = arith.index_castui %54 : i64 to index
          %56:7 = util.assume.int 
              %20<umin = 0, umax = 9223372036854775807, udiv = 8>, 
              %30<umin = 0, umax = 9007199254740991>, 
              %35<umin = 0, umax = 9007199254740991>, 
              %40<umin = 0, umax = 9007199254740991>, 
              %45<umin = 0, umax = 9007199254740991>, 
              %50<umin = 0, umax = 9007199254740991>, 
              %55<umin = 0, umax = 9007199254740991>
            : index, index, index, index, index, index, index
          %57 = iree_tensor_ext.dispatch.workload.ordinal %56#0, 0 : index
          %58 = iree_tensor_ext.dispatch.workload.ordinal %56#1, 2 : index
          %59 = iree_tensor_ext.dispatch.workload.ordinal %56#2, 3 : index
          %60 = iree_tensor_ext.dispatch.workload.ordinal %56#3, 4 : index
          %61 = iree_tensor_ext.dispatch.workload.ordinal %56#4, 5 : index
          %62 = iree_tensor_ext.dispatch.workload.ordinal %56#5, 6 : index
          %63 = iree_tensor_ext.dispatch.workload.ordinal %56#6, 7 : index
          %64 = hal.interface.binding.subspan layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(0) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xi32>>{%58, %59}
          %65 = hal.interface.binding.subspan layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(1) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xi32>>{%60, %61}
          %66 = hal.interface.binding.subspan layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(2) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xf32>>{%62, %63}
          %67 = hal.interface.binding.subspan layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(3) alignment(64) offset(%c0) flags(Indirect) : !iree_tensor_ext.dispatch.tensor<writeonly:tensor<?xf32>>{%57}
          %68 = iree_tensor_ext.dispatch.workload.ordinal %25, 1 : index
          %69 = iree_tensor_ext.dispatch.tensor.load %64, offsets = [0, 0], sizes = [%58, %59], strides = [1, 1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xi32>>{%58, %59} -> tensor<?x?xi32>
          %70 = iree_tensor_ext.dispatch.tensor.load %65, offsets = [0, 0], sizes = [%60, %61], strides = [1, 1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xi32>>{%60, %61} -> tensor<?x?xi32>
          %71 = iree_tensor_ext.dispatch.tensor.load %66, offsets = [0, 0], sizes = [%62, %63], strides = [1, 1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xf32>>{%62, %63} -> tensor<?x?xf32>
          %72 = tensor.empty(%57) : tensor<?xf32>
          %73 = linalg.generic {indexing_maps = [affine_map<(d0) -> (d0)>], iterator_types = ["parallel"]} outs(%72 : tensor<?xf32>) attrs =  {lowering_config = #iree_codegen.lowering_config<tile_sizes = [[64], [1]]>} {
          ^bb0(%out: f32):
            %74 = linalg.index 0 : index
            %75 = arith.remsi %74, %58 : index
            %76 = arith.divsi %74, %58 : index
            %77 = arith.divui %75, %68 : index
            %78 = arith.divui %76, %c8 : index
            %79 = arith.remui %76, %c8 : index
            %80 = arith.divui %79, %c2 : index
            %81 = arith.remui %79, %c2 : index
            %82 = arith.muli %81, %c4 : index
            %83 = arith.addi %80, %82 : index
            %extracted = tensor.extract %69[%75, %78] : tensor<?x?xi32>
            %extracted_0 = tensor.extract %70[%77, %78] : tensor<?x?xi32>
            %84 = arith.muli %83, %c4 : index
            %85 = arith.index_castui %84 : index to i32
            %86 = arith.shrui %extracted, %85 : i32
            %87 = arith.andi %86, %c15_i32 : i32
            %88 = arith.shrui %extracted_0, %85 : i32
            %89 = arith.andi %88, %c15_i32 : i32
            %90 = arith.subi %87, %89 : i32
            %91 = arith.sitofp %90 : i32 to f32
            %extracted_1 = tensor.extract %71[%77, %76] : tensor<?x?xf32>
            %92 = arith.mulf %91, %extracted_1 : f32
            linalg.yield %92 : f32
          } -> tensor<?xf32>
          iree_tensor_ext.dispatch.tensor.store %73, %67, offsets = [0], sizes = [%57], strides = [1] : tensor<?xf32> -> !iree_tensor_ext.dispatch.tensor<writeonly:tensor<?xf32>>{%57}
          return
        }
        iree_codegen.dispatch_config @awq_f32_f32_dispatch_0_elementwise_broadcast_D_f32 {
        ^bb0(%arg0: !hal.device, %arg1: index, %arg2: index, %arg3: index, %arg4: index, %arg5: index, %arg6: index, %arg7: index, %arg8: index):
          %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice(%arg1, %arg2, %arg3, %arg4, %arg5, %arg6, %arg7, %arg8)
          iree_codegen.yield %x, %y, %z : index, index, index
        }
      }
    }
  }
  util.func public @awq_f32_f32(%arg0: !hal.buffer_view, %arg1: !hal.buffer_view, %arg2: !hal.buffer_view, %arg3: i32, %arg4: !hal.fence, %arg5: !hal.fence) -> !hal.buffer_view attributes {iree.abi.stub, iree.reflection = {iree.abi.declaration = "async func @awq_f32_f32(%input0: tensor<?x?xi32>, %input1: tensor<?x?xi32>, %input2: tensor<?x?xf32>, %input3: i32) -> (%output0: tensor<?x?xf32>)", iree.abi.model = "coarse-fences"}} {
    %c32_i64 = arith.constant 32 : i64
    %c32 = arith.constant 32 : index
    %c0 = arith.constant 0 : index
    %c4 = arith.constant 4 : index
    %c8 = arith.constant 8 : index
    %0 = hal.buffer_view.dim<%arg0 : !hal.buffer_view>[0] : index
    %1 = hal.buffer_view.dim<%arg0 : !hal.buffer_view>[1] : index
    %element_type_i32 = hal.element_type<i32> : i32
    %dense_row_major = hal.encoding_type<dense_row_major> : i32
    hal.buffer_view.assert<%arg0 : !hal.buffer_view> message("input0") shape([%0, %1]) type(%element_type_i32) encoding(%dense_row_major)
    %2 = arith.muli %0, %c4 : index
    %3 = arith.muli %2, %1 : index
    %4 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg0 : !hal.buffer_view -> tensor<?x?xi32>{%0, %1} in !stream.resource<external>{%3}
    %5 = stream.timepoint.import on(#hal.device.affinity<@__device_0>) %arg4 : (!hal.fence) => !stream.timepoint
    %6 = hal.buffer_view.dim<%arg1 : !hal.buffer_view>[0] : index
    %7 = hal.buffer_view.dim<%arg1 : !hal.buffer_view>[1] : index
    hal.buffer_view.assert<%arg1 : !hal.buffer_view> message("input1") shape([%6, %7]) type(%element_type_i32) encoding(%dense_row_major)
    %8 = arith.muli %6, %c4 : index
    %9 = arith.muli %8, %7 : index
    %10 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg1 : !hal.buffer_view -> tensor<?x?xi32>{%6, %7} in !stream.resource<external>{%9}
    %11 = hal.buffer_view.dim<%arg2 : !hal.buffer_view>[0] : index
    %12 = hal.buffer_view.dim<%arg2 : !hal.buffer_view>[1] : index
    %element_type_f32 = hal.element_type<f32> : i32
    hal.buffer_view.assert<%arg2 : !hal.buffer_view> message("input2") shape([%11, %12]) type(%element_type_f32) encoding(%dense_row_major)
    %13 = arith.muli %11, %c4 : index
    %14 = arith.muli %13, %12 : index
    %15 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg2 : !hal.buffer_view -> tensor<?x?xf32>{%11, %12} in !stream.resource<external>{%14}
    %16 = arith.muli %1, %c8 : index
    %17 = arith.muli %16, %0 overflow<nsw> : index
    %18 = arith.index_cast %arg3 : i32 to index
    %19 = arith.muli %17, %c4 : index
    %result, %result_timepoint = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) await(%5) => !stream.resource<external>{%19} => !stream.timepoint
    %20 = arith.index_castui %17 : index to i64
    %21 = arith.index_castui %17 : index to i32
    %22 = arith.shrui %20, %c32_i64 : i64
    %23 = arith.trunci %22 : i64 to i32
    %24 = arith.index_castui %18 : index to i64
    %25 = arith.index_castui %18 : index to i32
    %26 = arith.shrui %24, %c32_i64 : i64
    %27 = arith.trunci %26 : i64 to i32
    %28 = arith.index_castui %0 : index to i64
    %29 = arith.index_castui %0 : index to i32
    %30 = arith.shrui %28, %c32_i64 : i64
    %31 = arith.trunci %30 : i64 to i32
    %32 = arith.index_castui %1 : index to i64
    %33 = arith.index_castui %1 : index to i32
    %34 = arith.shrui %32, %c32_i64 : i64
    %35 = arith.trunci %34 : i64 to i32
    %36 = arith.index_castui %6 : index to i64
    %37 = arith.index_castui %6 : index to i32
    %38 = arith.shrui %36, %c32_i64 : i64
    %39 = arith.trunci %38 : i64 to i32
    %40 = arith.index_castui %7 : index to i64
    %41 = arith.index_castui %7 : index to i32
    %42 = arith.shrui %40, %c32_i64 : i64
    %43 = arith.trunci %42 : i64 to i32
    %44 = arith.index_castui %11 : index to i64
    %45 = arith.index_castui %11 : index to i32
    %46 = arith.shrui %44, %c32_i64 : i64
    %47 = arith.trunci %46 : i64 to i32
    %48 = arith.index_castui %12 : index to i64
    %49 = arith.index_castui %12 : index to i32
    %50 = arith.shrui %48, %c32_i64 : i64
    %51 = arith.trunci %50 : i64 to i32
    %52 = stream.cmd.execute on(#hal.device.affinity<@__device_0>) await(%result_timepoint) => with(%4 as %arg6: !stream.resource<external>{%3}, %10 as %arg7: !stream.resource<external>{%9}, %15 as %arg8: !stream.resource<external>{%14}, %result as %arg9: !stream.resource<external>{%19}) {
      stream.cmd.dispatch @awq_f32_f32_dispatch_0::@vulkan_spirv_fb::@awq_f32_f32_dispatch_0_elementwise_broadcast_D_f32[%17, %18, %0, %1, %6, %7, %11, %12](%21, %23, %25, %27, %29, %31, %33, %35, %37, %39, %41, %43, %45, %47, %49, %51 : i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32) {
        ro %arg6[%c0 for %3] : !stream.resource<external>{%3},
        ro %arg7[%c0 for %9] : !stream.resource<external>{%9},
        ro %arg8[%c0 for %14] : !stream.resource<external>{%14},
        wo %arg9[%c0 for %19] : !stream.resource<external>{%19}
      }
    } => !stream.timepoint
    %53 = arith.muli %1, %c32 : index
    %54 = arith.muli %53, %0 : index
    stream.timepoint.chain_external on(#hal.device.affinity<@__device_0>) %52 => (%arg5 : !hal.fence)
    %55 = stream.tensor.export on(#hal.device.affinity<@__device_0>) %result : tensor<?x?xf32>{%16, %0} in !stream.resource<external>{%54} -> !hal.buffer_view
    util.return %55 : !hal.buffer_view
  }
  hal.executable private @awq_f32_f16_dispatch_0 {
    hal.executable.variant public @vulkan_spirv_fb target(<"vulkan-spirv", "vulkan-spirv-fb", {iree_codegen.target_info = #iree_gpu.target<arch = "vp_android_baseline_2022", features = "spirv:v1.3,cap:Shader,cap:Int16,cap:Float16,cap:StorageBuffer16BitAccess,cap:SignedZeroInfNanPreserve,ext:SPV_KHR_16bit_storage,ext:SPV_KHR_float_controls", wgp = <compute = fp32|int32, storage = b32, subgroup = none, subgroup_size_choices = [64], max_workgroup_sizes = [128, 128, 64], max_thread_count_per_workgroup = 128, max_workgroup_memory_bytes = 16384, max_workgroup_counts = [65535, 65535, 65535]>>}>) {
      hal.executable.export public @awq_f32_f16_dispatch_0_elementwise_broadcast_D_f16 ordinal(0) layout(#hal.pipeline.layout<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) count(%arg0: !hal.device, %arg1: index, %arg2: index, %arg3: index, %arg4: index, %arg5: index, %arg6: index, %arg7: index, %arg8: index) -> (index, index, index) {
        %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice(%arg1, %arg2, %arg3, %arg4, %arg5, %arg6, %arg7, %arg8)
        hal.return %x, %y, %z : index, index, index
      }
      builtin.module {
        func.func @awq_f32_f16_dispatch_0_elementwise_broadcast_D_f16() attributes {translation_info = #iree_codegen.translation_info<pipeline = #iree_gpu.spirv_pipeline<BaseDistribute> workgroup_size = [64, 1, 1]>} {
          %c32_i64 = arith.constant 32 : i64
          %c8 = arith.constant 8 : index
          %c2 = arith.constant 2 : index
          %c4 = arith.constant 4 : index
          %c15_i32 = arith.constant 15 : i32
          %c0 = arith.constant 0 : index
          %0 = hal.interface.constant.load layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(0) : i32
          %1 = hal.interface.constant.load layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(1) : i32
          %2 = hal.interface.constant.load layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(2) : i32
          %3 = hal.interface.constant.load layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(3) : i32
          %4 = hal.interface.constant.load layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(4) : i32
          %5 = hal.interface.constant.load layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(5) : i32
          %6 = hal.interface.constant.load layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(6) : i32
          %7 = hal.interface.constant.load layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(7) : i32
          %8 = hal.interface.constant.load layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(8) : i32
          %9 = hal.interface.constant.load layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(9) : i32
          %10 = hal.interface.constant.load layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(10) : i32
          %11 = hal.interface.constant.load layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(11) : i32
          %12 = hal.interface.constant.load layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(12) : i32
          %13 = hal.interface.constant.load layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(13) : i32
          %14 = hal.interface.constant.load layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(14) : i32
          %15 = hal.interface.constant.load layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(15) : i32
          %16 = arith.extui %1 : i32 to i64
          %17 = arith.shli %16, %c32_i64 : i64
          %18 = arith.extui %0 : i32 to i64
          %19 = arith.ori %18, %17 : i64
          %20 = arith.index_castui %19 : i64 to index
          %21 = arith.extui %3 : i32 to i64
          %22 = arith.shli %21, %c32_i64 : i64
          %23 = arith.extui %2 : i32 to i64
          %24 = arith.ori %23, %22 : i64
          %25 = arith.index_castui %24 : i64 to index
          %26 = arith.extui %5 : i32 to i64
          %27 = arith.shli %26, %c32_i64 : i64
          %28 = arith.extui %4 : i32 to i64
          %29 = arith.ori %28, %27 : i64
          %30 = arith.index_castui %29 : i64 to index
          %31 = arith.extui %7 : i32 to i64
          %32 = arith.shli %31, %c32_i64 : i64
          %33 = arith.extui %6 : i32 to i64
          %34 = arith.ori %33, %32 : i64
          %35 = arith.index_castui %34 : i64 to index
          %36 = arith.extui %9 : i32 to i64
          %37 = arith.shli %36, %c32_i64 : i64
          %38 = arith.extui %8 : i32 to i64
          %39 = arith.ori %38, %37 : i64
          %40 = arith.index_castui %39 : i64 to index
          %41 = arith.extui %11 : i32 to i64
          %42 = arith.shli %41, %c32_i64 : i64
          %43 = arith.extui %10 : i32 to i64
          %44 = arith.ori %43, %42 : i64
          %45 = arith.index_castui %44 : i64 to index
          %46 = arith.extui %13 : i32 to i64
          %47 = arith.shli %46, %c32_i64 : i64
          %48 = arith.extui %12 : i32 to i64
          %49 = arith.ori %48, %47 : i64
          %50 = arith.index_castui %49 : i64 to index
          %51 = arith.extui %15 : i32 to i64
          %52 = arith.shli %51, %c32_i64 : i64
          %53 = arith.extui %14 : i32 to i64
          %54 = arith.ori %53, %52 : i64
          %55 = arith.index_castui %54 : i64 to index
          %56:7 = util.assume.int 
              %20<umin = 0, umax = 9223372036854775807, udiv = 8>, 
              %30<umin = 0, umax = 9007199254740991>, 
              %35<umin = 0, umax = 9007199254740991>, 
              %40<umin = 0, umax = 9007199254740991>, 
              %45<umin = 0, umax = 9007199254740991>, 
              %50<umin = 0, umax = 9007199254740991>, 
              %55<umin = 0, umax = 9007199254740991>
            : index, index, index, index, index, index, index
          %57 = iree_tensor_ext.dispatch.workload.ordinal %56#0, 0 : index
          %58 = iree_tensor_ext.dispatch.workload.ordinal %56#1, 2 : index
          %59 = iree_tensor_ext.dispatch.workload.ordinal %56#2, 3 : index
          %60 = iree_tensor_ext.dispatch.workload.ordinal %56#3, 4 : index
          %61 = iree_tensor_ext.dispatch.workload.ordinal %56#4, 5 : index
          %62 = iree_tensor_ext.dispatch.workload.ordinal %56#5, 6 : index
          %63 = iree_tensor_ext.dispatch.workload.ordinal %56#6, 7 : index
          %64 = hal.interface.binding.subspan layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(0) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xi32>>{%58, %59}
          %65 = hal.interface.binding.subspan layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(1) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xi32>>{%60, %61}
          %66 = hal.interface.binding.subspan layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(2) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xf32>>{%62, %63}
          %67 = hal.interface.binding.subspan layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(3) alignment(64) offset(%c0) flags(Indirect) : !iree_tensor_ext.dispatch.tensor<writeonly:tensor<?xf16>>{%57}
          %68 = iree_tensor_ext.dispatch.workload.ordinal %25, 1 : index
          %69 = iree_tensor_ext.dispatch.tensor.load %64, offsets = [0, 0], sizes = [%58, %59], strides = [1, 1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xi32>>{%58, %59} -> tensor<?x?xi32>
          %70 = iree_tensor_ext.dispatch.tensor.load %65, offsets = [0, 0], sizes = [%60, %61], strides = [1, 1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xi32>>{%60, %61} -> tensor<?x?xi32>
          %71 = iree_tensor_ext.dispatch.tensor.load %66, offsets = [0, 0], sizes = [%62, %63], strides = [1, 1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xf32>>{%62, %63} -> tensor<?x?xf32>
          %72 = tensor.empty(%57) : tensor<?xf16>
          %73 = linalg.generic {indexing_maps = [affine_map<(d0) -> (d0)>], iterator_types = ["parallel"]} outs(%72 : tensor<?xf16>) attrs =  {lowering_config = #iree_codegen.lowering_config<tile_sizes = [[64], [1]]>} {
          ^bb0(%out: f16):
            %74 = linalg.index 0 : index
            %75 = arith.remsi %74, %58 : index
            %76 = arith.divsi %74, %58 : index
            %77 = arith.divui %75, %68 : index
            %78 = arith.divui %76, %c8 : index
            %79 = arith.remui %76, %c8 : index
            %80 = arith.divui %79, %c2 : index
            %81 = arith.remui %79, %c2 : index
            %82 = arith.muli %81, %c4 : index
            %83 = arith.addi %80, %82 : index
            %extracted = tensor.extract %69[%75, %78] : tensor<?x?xi32>
            %extracted_0 = tensor.extract %70[%77, %78] : tensor<?x?xi32>
            %84 = arith.muli %83, %c4 : index
            %85 = arith.index_castui %84 : index to i32
            %86 = arith.shrui %extracted, %85 : i32
            %87 = arith.andi %86, %c15_i32 : i32
            %88 = arith.shrui %extracted_0, %85 : i32
            %89 = arith.andi %88, %c15_i32 : i32
            %90 = arith.subi %87, %89 : i32
            %91 = arith.sitofp %90 : i32 to f32
            %extracted_1 = tensor.extract %71[%77, %76] : tensor<?x?xf32>
            %92 = arith.mulf %91, %extracted_1 : f32
            %93 = arith.truncf %92 : f32 to f16
            linalg.yield %93 : f16
          } -> tensor<?xf16>
          iree_tensor_ext.dispatch.tensor.store %73, %67, offsets = [0], sizes = [%57], strides = [1] : tensor<?xf16> -> !iree_tensor_ext.dispatch.tensor<writeonly:tensor<?xf16>>{%57}
          return
        }
        iree_codegen.dispatch_config @awq_f32_f16_dispatch_0_elementwise_broadcast_D_f16 {
        ^bb0(%arg0: !hal.device, %arg1: index, %arg2: index, %arg3: index, %arg4: index, %arg5: index, %arg6: index, %arg7: index, %arg8: index):
          %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice(%arg1, %arg2, %arg3, %arg4, %arg5, %arg6, %arg7, %arg8)
          iree_codegen.yield %x, %y, %z : index, index, index
        }
      }
    }
  }
  util.func public @awq_f32_f16(%arg0: !hal.buffer_view, %arg1: !hal.buffer_view, %arg2: !hal.buffer_view, %arg3: i32, %arg4: !hal.fence, %arg5: !hal.fence) -> !hal.buffer_view attributes {iree.abi.stub, iree.reflection = {iree.abi.declaration = "async func @awq_f32_f16(%input0: tensor<?x?xi32>, %input1: tensor<?x?xi32>, %input2: tensor<?x?xf32>, %input3: i32) -> (%output0: tensor<?x?xf16>)", iree.abi.model = "coarse-fences"}} {
    %c32_i64 = arith.constant 32 : i64
    %c16 = arith.constant 16 : index
    %c0 = arith.constant 0 : index
    %c2 = arith.constant 2 : index
    %c4 = arith.constant 4 : index
    %c8 = arith.constant 8 : index
    %0 = hal.buffer_view.dim<%arg0 : !hal.buffer_view>[0] : index
    %1 = hal.buffer_view.dim<%arg0 : !hal.buffer_view>[1] : index
    %element_type_i32 = hal.element_type<i32> : i32
    %dense_row_major = hal.encoding_type<dense_row_major> : i32
    hal.buffer_view.assert<%arg0 : !hal.buffer_view> message("input0") shape([%0, %1]) type(%element_type_i32) encoding(%dense_row_major)
    %2 = arith.muli %0, %c4 : index
    %3 = arith.muli %2, %1 : index
    %4 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg0 : !hal.buffer_view -> tensor<?x?xi32>{%0, %1} in !stream.resource<external>{%3}
    %5 = stream.timepoint.import on(#hal.device.affinity<@__device_0>) %arg4 : (!hal.fence) => !stream.timepoint
    %6 = hal.buffer_view.dim<%arg1 : !hal.buffer_view>[0] : index
    %7 = hal.buffer_view.dim<%arg1 : !hal.buffer_view>[1] : index
    hal.buffer_view.assert<%arg1 : !hal.buffer_view> message("input1") shape([%6, %7]) type(%element_type_i32) encoding(%dense_row_major)
    %8 = arith.muli %6, %c4 : index
    %9 = arith.muli %8, %7 : index
    %10 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg1 : !hal.buffer_view -> tensor<?x?xi32>{%6, %7} in !stream.resource<external>{%9}
    %11 = hal.buffer_view.dim<%arg2 : !hal.buffer_view>[0] : index
    %12 = hal.buffer_view.dim<%arg2 : !hal.buffer_view>[1] : index
    %element_type_f32 = hal.element_type<f32> : i32
    hal.buffer_view.assert<%arg2 : !hal.buffer_view> message("input2") shape([%11, %12]) type(%element_type_f32) encoding(%dense_row_major)
    %13 = arith.muli %11, %c4 : index
    %14 = arith.muli %13, %12 : index
    %15 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg2 : !hal.buffer_view -> tensor<?x?xf32>{%11, %12} in !stream.resource<external>{%14}
    %16 = arith.muli %1, %c8 : index
    %17 = arith.muli %16, %0 overflow<nsw> : index
    %18 = arith.index_cast %arg3 : i32 to index
    %19 = arith.muli %17, %c2 : index
    %result, %result_timepoint = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) await(%5) => !stream.resource<external>{%19} => !stream.timepoint
    %20 = arith.index_castui %17 : index to i64
    %21 = arith.index_castui %17 : index to i32
    %22 = arith.shrui %20, %c32_i64 : i64
    %23 = arith.trunci %22 : i64 to i32
    %24 = arith.index_castui %18 : index to i64
    %25 = arith.index_castui %18 : index to i32
    %26 = arith.shrui %24, %c32_i64 : i64
    %27 = arith.trunci %26 : i64 to i32
    %28 = arith.index_castui %0 : index to i64
    %29 = arith.index_castui %0 : index to i32
    %30 = arith.shrui %28, %c32_i64 : i64
    %31 = arith.trunci %30 : i64 to i32
    %32 = arith.index_castui %1 : index to i64
    %33 = arith.index_castui %1 : index to i32
    %34 = arith.shrui %32, %c32_i64 : i64
    %35 = arith.trunci %34 : i64 to i32
    %36 = arith.index_castui %6 : index to i64
    %37 = arith.index_castui %6 : index to i32
    %38 = arith.shrui %36, %c32_i64 : i64
    %39 = arith.trunci %38 : i64 to i32
    %40 = arith.index_castui %7 : index to i64
    %41 = arith.index_castui %7 : index to i32
    %42 = arith.shrui %40, %c32_i64 : i64
    %43 = arith.trunci %42 : i64 to i32
    %44 = arith.index_castui %11 : index to i64
    %45 = arith.index_castui %11 : index to i32
    %46 = arith.shrui %44, %c32_i64 : i64
    %47 = arith.trunci %46 : i64 to i32
    %48 = arith.index_castui %12 : index to i64
    %49 = arith.index_castui %12 : index to i32
    %50 = arith.shrui %48, %c32_i64 : i64
    %51 = arith.trunci %50 : i64 to i32
    %52 = stream.cmd.execute on(#hal.device.affinity<@__device_0>) await(%result_timepoint) => with(%4 as %arg6: !stream.resource<external>{%3}, %10 as %arg7: !stream.resource<external>{%9}, %15 as %arg8: !stream.resource<external>{%14}, %result as %arg9: !stream.resource<external>{%19}) {
      stream.cmd.dispatch @awq_f32_f16_dispatch_0::@vulkan_spirv_fb::@awq_f32_f16_dispatch_0_elementwise_broadcast_D_f16[%17, %18, %0, %1, %6, %7, %11, %12](%21, %23, %25, %27, %29, %31, %33, %35, %37, %39, %41, %43, %45, %47, %49, %51 : i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32) {
        ro %arg6[%c0 for %3] : !stream.resource<external>{%3},
        ro %arg7[%c0 for %9] : !stream.resource<external>{%9},
        ro %arg8[%c0 for %14] : !stream.resource<external>{%14},
        wo %arg9[%c0 for %19] : !stream.resource<external>{%19}
      }
    } => !stream.timepoint
    %53 = arith.muli %1, %c16 : index
    %54 = arith.muli %53, %0 : index
    stream.timepoint.chain_external on(#hal.device.affinity<@__device_0>) %52 => (%arg5 : !hal.fence)
    %55 = stream.tensor.export on(#hal.device.affinity<@__device_0>) %result : tensor<?x?xf16>{%16, %0} in !stream.resource<external>{%54} -> !hal.buffer_view
    util.return %55 : !hal.buffer_view
  }
  hal.executable private @awq_f32_bf16_dispatch_0 {
    hal.executable.variant public @vulkan_spirv_fb target(<"vulkan-spirv", "vulkan-spirv-fb", {iree_codegen.target_info = #iree_gpu.target<arch = "vp_android_baseline_2022", features = "spirv:v1.3,cap:Shader,cap:Int16,cap:Float16,cap:StorageBuffer16BitAccess,cap:SignedZeroInfNanPreserve,ext:SPV_KHR_16bit_storage,ext:SPV_KHR_float_controls", wgp = <compute = fp32|int32, storage = b32, subgroup = none, subgroup_size_choices = [64], max_workgroup_sizes = [128, 128, 64], max_thread_count_per_workgroup = 128, max_workgroup_memory_bytes = 16384, max_workgroup_counts = [65535, 65535, 65535]>>}>) {
      hal.executable.export public @awq_f32_bf16_dispatch_0_elementwise_broadcast_D_i16 ordinal(0) layout(#hal.pipeline.layout<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) count(%arg0: !hal.device, %arg1: index, %arg2: index, %arg3: index, %arg4: index, %arg5: index, %arg6: index, %arg7: index, %arg8: index) -> (index, index, index) {
        %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice(%arg1, %arg2, %arg3, %arg4, %arg5, %arg6, %arg7, %arg8)
        hal.return %x, %y, %z : index, index, index
      }
      builtin.module {
        func.func @awq_f32_bf16_dispatch_0_elementwise_broadcast_D_i16() attributes {translation_info = #iree_codegen.translation_info<pipeline = #iree_gpu.spirv_pipeline<BaseDistribute> workgroup_size = [64, 1, 1]>} {
          %c32_i64 = arith.constant 32 : i64
          %c8 = arith.constant 8 : index
          %c2 = arith.constant 2 : index
          %c4 = arith.constant 4 : index
          %c15_i32 = arith.constant 15 : i32
          %c0 = arith.constant 0 : index
          %0 = hal.interface.constant.load layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(0) : i32
          %1 = hal.interface.constant.load layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(1) : i32
          %2 = hal.interface.constant.load layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(2) : i32
          %3 = hal.interface.constant.load layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(3) : i32
          %4 = hal.interface.constant.load layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(4) : i32
          %5 = hal.interface.constant.load layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(5) : i32
          %6 = hal.interface.constant.load layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(6) : i32
          %7 = hal.interface.constant.load layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(7) : i32
          %8 = hal.interface.constant.load layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(8) : i32
          %9 = hal.interface.constant.load layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(9) : i32
          %10 = hal.interface.constant.load layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(10) : i32
          %11 = hal.interface.constant.load layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(11) : i32
          %12 = hal.interface.constant.load layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(12) : i32
          %13 = hal.interface.constant.load layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(13) : i32
          %14 = hal.interface.constant.load layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(14) : i32
          %15 = hal.interface.constant.load layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(15) : i32
          %16 = arith.extui %1 : i32 to i64
          %17 = arith.shli %16, %c32_i64 : i64
          %18 = arith.extui %0 : i32 to i64
          %19 = arith.ori %18, %17 : i64
          %20 = arith.index_castui %19 : i64 to index
          %21 = arith.extui %3 : i32 to i64
          %22 = arith.shli %21, %c32_i64 : i64
          %23 = arith.extui %2 : i32 to i64
          %24 = arith.ori %23, %22 : i64
          %25 = arith.index_castui %24 : i64 to index
          %26 = arith.extui %5 : i32 to i64
          %27 = arith.shli %26, %c32_i64 : i64
          %28 = arith.extui %4 : i32 to i64
          %29 = arith.ori %28, %27 : i64
          %30 = arith.index_castui %29 : i64 to index
          %31 = arith.extui %7 : i32 to i64
          %32 = arith.shli %31, %c32_i64 : i64
          %33 = arith.extui %6 : i32 to i64
          %34 = arith.ori %33, %32 : i64
          %35 = arith.index_castui %34 : i64 to index
          %36 = arith.extui %9 : i32 to i64
          %37 = arith.shli %36, %c32_i64 : i64
          %38 = arith.extui %8 : i32 to i64
          %39 = arith.ori %38, %37 : i64
          %40 = arith.index_castui %39 : i64 to index
          %41 = arith.extui %11 : i32 to i64
          %42 = arith.shli %41, %c32_i64 : i64
          %43 = arith.extui %10 : i32 to i64
          %44 = arith.ori %43, %42 : i64
          %45 = arith.index_castui %44 : i64 to index
          %46 = arith.extui %13 : i32 to i64
          %47 = arith.shli %46, %c32_i64 : i64
          %48 = arith.extui %12 : i32 to i64
          %49 = arith.ori %48, %47 : i64
          %50 = arith.index_castui %49 : i64 to index
          %51 = arith.extui %15 : i32 to i64
          %52 = arith.shli %51, %c32_i64 : i64
          %53 = arith.extui %14 : i32 to i64
          %54 = arith.ori %53, %52 : i64
          %55 = arith.index_castui %54 : i64 to index
          %56:7 = util.assume.int 
              %20<umin = 0, umax = 9223372036854775807, udiv = 8>, 
              %30<umin = 0, umax = 9007199254740991>, 
              %35<umin = 0, umax = 9007199254740991>, 
              %40<umin = 0, umax = 9007199254740991>, 
              %45<umin = 0, umax = 9007199254740991>, 
              %50<umin = 0, umax = 9007199254740991>, 
              %55<umin = 0, umax = 9007199254740991>
            : index, index, index, index, index, index, index
          %57 = iree_tensor_ext.dispatch.workload.ordinal %56#0, 0 : index
          %58 = iree_tensor_ext.dispatch.workload.ordinal %56#1, 2 : index
          %59 = iree_tensor_ext.dispatch.workload.ordinal %56#2, 3 : index
          %60 = iree_tensor_ext.dispatch.workload.ordinal %56#3, 4 : index
          %61 = iree_tensor_ext.dispatch.workload.ordinal %56#4, 5 : index
          %62 = iree_tensor_ext.dispatch.workload.ordinal %56#5, 6 : index
          %63 = iree_tensor_ext.dispatch.workload.ordinal %56#6, 7 : index
          %64 = hal.interface.binding.subspan layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(0) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xi32>>{%58, %59}
          %65 = hal.interface.binding.subspan layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(1) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xi32>>{%60, %61}
          %66 = hal.interface.binding.subspan layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(2) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xf32>>{%62, %63}
          %67 = hal.interface.binding.subspan layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(3) alignment(64) offset(%c0) flags(Indirect) : !iree_tensor_ext.dispatch.tensor<writeonly:tensor<?xi16>>{%57}
          %68 = iree_tensor_ext.dispatch.workload.ordinal %25, 1 : index
          %69 = iree_tensor_ext.dispatch.tensor.load %64, offsets = [0, 0], sizes = [%58, %59], strides = [1, 1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xi32>>{%58, %59} -> tensor<?x?xi32>
          %70 = iree_tensor_ext.dispatch.tensor.load %65, offsets = [0, 0], sizes = [%60, %61], strides = [1, 1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xi32>>{%60, %61} -> tensor<?x?xi32>
          %71 = iree_tensor_ext.dispatch.tensor.load %66, offsets = [0, 0], sizes = [%62, %63], strides = [1, 1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xf32>>{%62, %63} -> tensor<?x?xf32>
          %72 = tensor.empty(%57) : tensor<?xi16>
          %73 = linalg.generic {indexing_maps = [affine_map<(d0) -> (d0)>], iterator_types = ["parallel"]} outs(%72 : tensor<?xi16>) attrs =  {lowering_config = #iree_codegen.lowering_config<tile_sizes = [[64], [1]]>} {
          ^bb0(%out: i16):
            %74 = linalg.index 0 : index
            %75 = arith.remsi %74, %58 : index
            %76 = arith.divsi %74, %58 : index
            %77 = arith.divui %75, %68 : index
            %78 = arith.divui %76, %c8 : index
            %79 = arith.remui %76, %c8 : index
            %80 = arith.divui %79, %c2 : index
            %81 = arith.remui %79, %c2 : index
            %82 = arith.muli %81, %c4 : index
            %83 = arith.addi %80, %82 : index
            %extracted = tensor.extract %69[%75, %78] : tensor<?x?xi32>
            %extracted_0 = tensor.extract %70[%77, %78] : tensor<?x?xi32>
            %84 = arith.muli %83, %c4 : index
            %85 = arith.index_castui %84 : index to i32
            %86 = arith.shrui %extracted, %85 : i32
            %87 = arith.andi %86, %c15_i32 : i32
            %88 = arith.shrui %extracted_0, %85 : i32
            %89 = arith.andi %88, %c15_i32 : i32
            %90 = arith.subi %87, %89 : i32
            %91 = arith.sitofp %90 : i32 to f32
            %extracted_1 = tensor.extract %71[%77, %76] : tensor<?x?xf32>
            %92 = arith.mulf %91, %extracted_1 : f32
            %93 = arith.truncf %92 : f32 to bf16
            %94 = arith.bitcast %93 : bf16 to i16
            linalg.yield %94 : i16
          } -> tensor<?xi16>
          iree_tensor_ext.dispatch.tensor.store %73, %67, offsets = [0], sizes = [%57], strides = [1] : tensor<?xi16> -> !iree_tensor_ext.dispatch.tensor<writeonly:tensor<?xi16>>{%57}
          return
        }
        iree_codegen.dispatch_config @awq_f32_bf16_dispatch_0_elementwise_broadcast_D_i16 {
        ^bb0(%arg0: !hal.device, %arg1: index, %arg2: index, %arg3: index, %arg4: index, %arg5: index, %arg6: index, %arg7: index, %arg8: index):
          %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice(%arg1, %arg2, %arg3, %arg4, %arg5, %arg6, %arg7, %arg8)
          iree_codegen.yield %x, %y, %z : index, index, index
        }
      }
    }
  }
  util.func public @awq_f32_bf16(%arg0: !hal.buffer_view, %arg1: !hal.buffer_view, %arg2: !hal.buffer_view, %arg3: i32, %arg4: !hal.fence, %arg5: !hal.fence) -> !hal.buffer_view attributes {iree.abi.stub, iree.reflection = {iree.abi.declaration = "async func @awq_f32_bf16(%input0: tensor<?x?xi32>, %input1: tensor<?x?xi32>, %input2: tensor<?x?xf32>, %input3: i32) -> (%output0: tensor<?x?xi16>)", iree.abi.model = "coarse-fences"}} {
    %c32_i64 = arith.constant 32 : i64
    %c16 = arith.constant 16 : index
    %c0 = arith.constant 0 : index
    %c2 = arith.constant 2 : index
    %c4 = arith.constant 4 : index
    %c8 = arith.constant 8 : index
    %0 = hal.buffer_view.dim<%arg0 : !hal.buffer_view>[0] : index
    %1 = hal.buffer_view.dim<%arg0 : !hal.buffer_view>[1] : index
    %element_type_i32 = hal.element_type<i32> : i32
    %dense_row_major = hal.encoding_type<dense_row_major> : i32
    hal.buffer_view.assert<%arg0 : !hal.buffer_view> message("input0") shape([%0, %1]) type(%element_type_i32) encoding(%dense_row_major)
    %2 = arith.muli %0, %c4 : index
    %3 = arith.muli %2, %1 : index
    %4 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg0 : !hal.buffer_view -> tensor<?x?xi32>{%0, %1} in !stream.resource<external>{%3}
    %5 = stream.timepoint.import on(#hal.device.affinity<@__device_0>) %arg4 : (!hal.fence) => !stream.timepoint
    %6 = hal.buffer_view.dim<%arg1 : !hal.buffer_view>[0] : index
    %7 = hal.buffer_view.dim<%arg1 : !hal.buffer_view>[1] : index
    hal.buffer_view.assert<%arg1 : !hal.buffer_view> message("input1") shape([%6, %7]) type(%element_type_i32) encoding(%dense_row_major)
    %8 = arith.muli %6, %c4 : index
    %9 = arith.muli %8, %7 : index
    %10 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg1 : !hal.buffer_view -> tensor<?x?xi32>{%6, %7} in !stream.resource<external>{%9}
    %11 = hal.buffer_view.dim<%arg2 : !hal.buffer_view>[0] : index
    %12 = hal.buffer_view.dim<%arg2 : !hal.buffer_view>[1] : index
    %element_type_f32 = hal.element_type<f32> : i32
    hal.buffer_view.assert<%arg2 : !hal.buffer_view> message("input2") shape([%11, %12]) type(%element_type_f32) encoding(%dense_row_major)
    %13 = arith.muli %11, %c4 : index
    %14 = arith.muli %13, %12 : index
    %15 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg2 : !hal.buffer_view -> tensor<?x?xf32>{%11, %12} in !stream.resource<external>{%14}
    %16 = arith.muli %1, %c8 : index
    %17 = arith.muli %16, %0 overflow<nsw> : index
    %18 = arith.index_cast %arg3 : i32 to index
    %19 = arith.muli %17, %c2 : index
    %result, %result_timepoint = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) await(%5) => !stream.resource<external>{%19} => !stream.timepoint
    %20 = arith.index_castui %17 : index to i64
    %21 = arith.index_castui %17 : index to i32
    %22 = arith.shrui %20, %c32_i64 : i64
    %23 = arith.trunci %22 : i64 to i32
    %24 = arith.index_castui %18 : index to i64
    %25 = arith.index_castui %18 : index to i32
    %26 = arith.shrui %24, %c32_i64 : i64
    %27 = arith.trunci %26 : i64 to i32
    %28 = arith.index_castui %0 : index to i64
    %29 = arith.index_castui %0 : index to i32
    %30 = arith.shrui %28, %c32_i64 : i64
    %31 = arith.trunci %30 : i64 to i32
    %32 = arith.index_castui %1 : index to i64
    %33 = arith.index_castui %1 : index to i32
    %34 = arith.shrui %32, %c32_i64 : i64
    %35 = arith.trunci %34 : i64 to i32
    %36 = arith.index_castui %6 : index to i64
    %37 = arith.index_castui %6 : index to i32
    %38 = arith.shrui %36, %c32_i64 : i64
    %39 = arith.trunci %38 : i64 to i32
    %40 = arith.index_castui %7 : index to i64
    %41 = arith.index_castui %7 : index to i32
    %42 = arith.shrui %40, %c32_i64 : i64
    %43 = arith.trunci %42 : i64 to i32
    %44 = arith.index_castui %11 : index to i64
    %45 = arith.index_castui %11 : index to i32
    %46 = arith.shrui %44, %c32_i64 : i64
    %47 = arith.trunci %46 : i64 to i32
    %48 = arith.index_castui %12 : index to i64
    %49 = arith.index_castui %12 : index to i32
    %50 = arith.shrui %48, %c32_i64 : i64
    %51 = arith.trunci %50 : i64 to i32
    %52 = stream.cmd.execute on(#hal.device.affinity<@__device_0>) await(%result_timepoint) => with(%4 as %arg6: !stream.resource<external>{%3}, %10 as %arg7: !stream.resource<external>{%9}, %15 as %arg8: !stream.resource<external>{%14}, %result as %arg9: !stream.resource<external>{%19}) {
      stream.cmd.dispatch @awq_f32_bf16_dispatch_0::@vulkan_spirv_fb::@awq_f32_bf16_dispatch_0_elementwise_broadcast_D_i16[%17, %18, %0, %1, %6, %7, %11, %12](%21, %23, %25, %27, %29, %31, %33, %35, %37, %39, %41, %43, %45, %47, %49, %51 : i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32) {
        ro %arg6[%c0 for %3] : !stream.resource<external>{%3},
        ro %arg7[%c0 for %9] : !stream.resource<external>{%9},
        ro %arg8[%c0 for %14] : !stream.resource<external>{%14},
        wo %arg9[%c0 for %19] : !stream.resource<external>{%19}
      }
    } => !stream.timepoint
    %53 = arith.muli %1, %c16 : index
    %54 = arith.muli %53, %0 : index
    stream.timepoint.chain_external on(#hal.device.affinity<@__device_0>) %52 => (%arg5 : !hal.fence)
    %55 = stream.tensor.export on(#hal.device.affinity<@__device_0>) %result : tensor<?x?xi16>{%16, %0} in !stream.resource<external>{%54} -> !hal.buffer_view
    util.return %55 : !hal.buffer_view
  }
  hal.executable private @awq_f16_f16_dispatch_0 {
    hal.executable.variant public @vulkan_spirv_fb target(<"vulkan-spirv", "vulkan-spirv-fb", {iree_codegen.target_info = #iree_gpu.target<arch = "vp_android_baseline_2022", features = "spirv:v1.3,cap:Shader,cap:Int16,cap:Float16,cap:StorageBuffer16BitAccess,cap:SignedZeroInfNanPreserve,ext:SPV_KHR_16bit_storage,ext:SPV_KHR_float_controls", wgp = <compute = fp32|int32, storage = b32, subgroup = none, subgroup_size_choices = [64], max_workgroup_sizes = [128, 128, 64], max_thread_count_per_workgroup = 128, max_workgroup_memory_bytes = 16384, max_workgroup_counts = [65535, 65535, 65535]>>}>) {
      hal.executable.export public @awq_f16_f16_dispatch_0_elementwise_broadcast_D_f16 ordinal(0) layout(#hal.pipeline.layout<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) count(%arg0: !hal.device, %arg1: index, %arg2: index, %arg3: index, %arg4: index, %arg5: index, %arg6: index, %arg7: index, %arg8: index) -> (index, index, index) {
        %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice(%arg1, %arg2, %arg3, %arg4, %arg5, %arg6, %arg7, %arg8)
        hal.return %x, %y, %z : index, index, index
      }
      builtin.module {
        func.func @awq_f16_f16_dispatch_0_elementwise_broadcast_D_f16() attributes {translation_info = #iree_codegen.translation_info<pipeline = #iree_gpu.spirv_pipeline<BaseDistribute> workgroup_size = [64, 1, 1]>} {
          %c32_i64 = arith.constant 32 : i64
          %c8 = arith.constant 8 : index
          %c2 = arith.constant 2 : index
          %c4 = arith.constant 4 : index
          %c15_i32 = arith.constant 15 : i32
          %c0 = arith.constant 0 : index
          %0 = hal.interface.constant.load layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(0) : i32
          %1 = hal.interface.constant.load layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(1) : i32
          %2 = hal.interface.constant.load layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(2) : i32
          %3 = hal.interface.constant.load layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(3) : i32
          %4 = hal.interface.constant.load layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(4) : i32
          %5 = hal.interface.constant.load layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(5) : i32
          %6 = hal.interface.constant.load layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(6) : i32
          %7 = hal.interface.constant.load layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(7) : i32
          %8 = hal.interface.constant.load layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(8) : i32
          %9 = hal.interface.constant.load layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(9) : i32
          %10 = hal.interface.constant.load layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(10) : i32
          %11 = hal.interface.constant.load layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(11) : i32
          %12 = hal.interface.constant.load layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(12) : i32
          %13 = hal.interface.constant.load layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(13) : i32
          %14 = hal.interface.constant.load layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(14) : i32
          %15 = hal.interface.constant.load layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(15) : i32
          %16 = arith.extui %1 : i32 to i64
          %17 = arith.shli %16, %c32_i64 : i64
          %18 = arith.extui %0 : i32 to i64
          %19 = arith.ori %18, %17 : i64
          %20 = arith.index_castui %19 : i64 to index
          %21 = arith.extui %3 : i32 to i64
          %22 = arith.shli %21, %c32_i64 : i64
          %23 = arith.extui %2 : i32 to i64
          %24 = arith.ori %23, %22 : i64
          %25 = arith.index_castui %24 : i64 to index
          %26 = arith.extui %5 : i32 to i64
          %27 = arith.shli %26, %c32_i64 : i64
          %28 = arith.extui %4 : i32 to i64
          %29 = arith.ori %28, %27 : i64
          %30 = arith.index_castui %29 : i64 to index
          %31 = arith.extui %7 : i32 to i64
          %32 = arith.shli %31, %c32_i64 : i64
          %33 = arith.extui %6 : i32 to i64
          %34 = arith.ori %33, %32 : i64
          %35 = arith.index_castui %34 : i64 to index
          %36 = arith.extui %9 : i32 to i64
          %37 = arith.shli %36, %c32_i64 : i64
          %38 = arith.extui %8 : i32 to i64
          %39 = arith.ori %38, %37 : i64
          %40 = arith.index_castui %39 : i64 to index
          %41 = arith.extui %11 : i32 to i64
          %42 = arith.shli %41, %c32_i64 : i64
          %43 = arith.extui %10 : i32 to i64
          %44 = arith.ori %43, %42 : i64
          %45 = arith.index_castui %44 : i64 to index
          %46 = arith.extui %13 : i32 to i64
          %47 = arith.shli %46, %c32_i64 : i64
          %48 = arith.extui %12 : i32 to i64
          %49 = arith.ori %48, %47 : i64
          %50 = arith.index_castui %49 : i64 to index
          %51 = arith.extui %15 : i32 to i64
          %52 = arith.shli %51, %c32_i64 : i64
          %53 = arith.extui %14 : i32 to i64
          %54 = arith.ori %53, %52 : i64
          %55 = arith.index_castui %54 : i64 to index
          %56:7 = util.assume.int 
              %20<umin = 0, umax = 9223372036854775807, udiv = 8>, 
              %30<umin = 0, umax = 9007199254740991>, 
              %35<umin = 0, umax = 9007199254740991>, 
              %40<umin = 0, umax = 9007199254740991>, 
              %45<umin = 0, umax = 9007199254740991>, 
              %50<umin = 0, umax = 9007199254740991>, 
              %55<umin = 0, umax = 9007199254740991>
            : index, index, index, index, index, index, index
          %57 = iree_tensor_ext.dispatch.workload.ordinal %56#0, 0 : index
          %58 = iree_tensor_ext.dispatch.workload.ordinal %56#1, 2 : index
          %59 = iree_tensor_ext.dispatch.workload.ordinal %56#2, 3 : index
          %60 = iree_tensor_ext.dispatch.workload.ordinal %56#3, 4 : index
          %61 = iree_tensor_ext.dispatch.workload.ordinal %56#4, 5 : index
          %62 = iree_tensor_ext.dispatch.workload.ordinal %56#5, 6 : index
          %63 = iree_tensor_ext.dispatch.workload.ordinal %56#6, 7 : index
          %64 = hal.interface.binding.subspan layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(0) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xi32>>{%58, %59}
          %65 = hal.interface.binding.subspan layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(1) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xi32>>{%60, %61}
          %66 = hal.interface.binding.subspan layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(2) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xf16>>{%62, %63}
          %67 = hal.interface.binding.subspan layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(3) alignment(64) offset(%c0) flags(Indirect) : !iree_tensor_ext.dispatch.tensor<writeonly:tensor<?xf16>>{%57}
          %68 = iree_tensor_ext.dispatch.workload.ordinal %25, 1 : index
          %69 = iree_tensor_ext.dispatch.tensor.load %64, offsets = [0, 0], sizes = [%58, %59], strides = [1, 1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xi32>>{%58, %59} -> tensor<?x?xi32>
          %70 = iree_tensor_ext.dispatch.tensor.load %65, offsets = [0, 0], sizes = [%60, %61], strides = [1, 1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xi32>>{%60, %61} -> tensor<?x?xi32>
          %71 = iree_tensor_ext.dispatch.tensor.load %66, offsets = [0, 0], sizes = [%62, %63], strides = [1, 1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xf16>>{%62, %63} -> tensor<?x?xf16>
          %72 = tensor.empty(%57) : tensor<?xf16>
          %73 = linalg.generic {indexing_maps = [affine_map<(d0) -> (d0)>], iterator_types = ["parallel"]} outs(%72 : tensor<?xf16>) attrs =  {lowering_config = #iree_codegen.lowering_config<tile_sizes = [[64], [1]]>} {
          ^bb0(%out: f16):
            %74 = linalg.index 0 : index
            %75 = arith.remsi %74, %58 : index
            %76 = arith.divsi %74, %58 : index
            %77 = arith.divui %75, %68 : index
            %78 = arith.divui %76, %c8 : index
            %79 = arith.remui %76, %c8 : index
            %80 = arith.divui %79, %c2 : index
            %81 = arith.remui %79, %c2 : index
            %82 = arith.muli %81, %c4 : index
            %83 = arith.addi %80, %82 : index
            %extracted = tensor.extract %69[%75, %78] : tensor<?x?xi32>
            %extracted_0 = tensor.extract %70[%77, %78] : tensor<?x?xi32>
            %84 = arith.muli %83, %c4 : index
            %85 = arith.index_castui %84 : index to i32
            %86 = arith.shrui %extracted, %85 : i32
            %87 = arith.andi %86, %c15_i32 : i32
            %88 = arith.shrui %extracted_0, %85 : i32
            %89 = arith.andi %88, %c15_i32 : i32
            %90 = arith.subi %87, %89 : i32
            %91 = arith.sitofp %90 : i32 to f32
            %extracted_1 = tensor.extract %71[%77, %76] : tensor<?x?xf16>
            %92 = arith.extf %extracted_1 : f16 to f32
            %93 = arith.mulf %91, %92 : f32
            %94 = arith.truncf %93 : f32 to f16
            %95 = arith.extf %94 : f16 to f32
            %96 = arith.truncf %95 : f32 to f16
            linalg.yield %96 : f16
          } -> tensor<?xf16>
          iree_tensor_ext.dispatch.tensor.store %73, %67, offsets = [0], sizes = [%57], strides = [1] : tensor<?xf16> -> !iree_tensor_ext.dispatch.tensor<writeonly:tensor<?xf16>>{%57}
          return
        }
        iree_codegen.dispatch_config @awq_f16_f16_dispatch_0_elementwise_broadcast_D_f16 {
        ^bb0(%arg0: !hal.device, %arg1: index, %arg2: index, %arg3: index, %arg4: index, %arg5: index, %arg6: index, %arg7: index, %arg8: index):
          %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice(%arg1, %arg2, %arg3, %arg4, %arg5, %arg6, %arg7, %arg8)
          iree_codegen.yield %x, %y, %z : index, index, index
        }
      }
    }
  }
  util.func public @awq_f16_f16(%arg0: !hal.buffer_view, %arg1: !hal.buffer_view, %arg2: !hal.buffer_view, %arg3: i32, %arg4: !hal.fence, %arg5: !hal.fence) -> !hal.buffer_view attributes {iree.abi.stub, iree.reflection = {iree.abi.declaration = "async func @awq_f16_f16(%input0: tensor<?x?xi32>, %input1: tensor<?x?xi32>, %input2: tensor<?x?xf16>, %input3: i32) -> (%output0: tensor<?x?xf16>)", iree.abi.model = "coarse-fences"}} {
    %c32_i64 = arith.constant 32 : i64
    %c16 = arith.constant 16 : index
    %c0 = arith.constant 0 : index
    %c2 = arith.constant 2 : index
    %c4 = arith.constant 4 : index
    %c8 = arith.constant 8 : index
    %0 = hal.buffer_view.dim<%arg0 : !hal.buffer_view>[0] : index
    %1 = hal.buffer_view.dim<%arg0 : !hal.buffer_view>[1] : index
    %element_type_i32 = hal.element_type<i32> : i32
    %dense_row_major = hal.encoding_type<dense_row_major> : i32
    hal.buffer_view.assert<%arg0 : !hal.buffer_view> message("input0") shape([%0, %1]) type(%element_type_i32) encoding(%dense_row_major)
    %2 = arith.muli %0, %c4 : index
    %3 = arith.muli %2, %1 : index
    %4 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg0 : !hal.buffer_view -> tensor<?x?xi32>{%0, %1} in !stream.resource<external>{%3}
    %5 = stream.timepoint.import on(#hal.device.affinity<@__device_0>) %arg4 : (!hal.fence) => !stream.timepoint
    %6 = hal.buffer_view.dim<%arg1 : !hal.buffer_view>[0] : index
    %7 = hal.buffer_view.dim<%arg1 : !hal.buffer_view>[1] : index
    hal.buffer_view.assert<%arg1 : !hal.buffer_view> message("input1") shape([%6, %7]) type(%element_type_i32) encoding(%dense_row_major)
    %8 = arith.muli %6, %c4 : index
    %9 = arith.muli %8, %7 : index
    %10 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg1 : !hal.buffer_view -> tensor<?x?xi32>{%6, %7} in !stream.resource<external>{%9}
    %11 = hal.buffer_view.dim<%arg2 : !hal.buffer_view>[0] : index
    %12 = hal.buffer_view.dim<%arg2 : !hal.buffer_view>[1] : index
    %element_type_f16 = hal.element_type<f16> : i32
    hal.buffer_view.assert<%arg2 : !hal.buffer_view> message("input2") shape([%11, %12]) type(%element_type_f16) encoding(%dense_row_major)
    %13 = arith.muli %11, %c2 : index
    %14 = arith.muli %13, %12 : index
    %15 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg2 : !hal.buffer_view -> tensor<?x?xf16>{%11, %12} in !stream.resource<external>{%14}
    %16 = arith.muli %1, %c8 : index
    %17 = arith.muli %16, %0 overflow<nsw> : index
    %18 = arith.index_cast %arg3 : i32 to index
    %19 = arith.muli %17, %c2 : index
    %result, %result_timepoint = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) await(%5) => !stream.resource<external>{%19} => !stream.timepoint
    %20 = arith.index_castui %17 : index to i64
    %21 = arith.index_castui %17 : index to i32
    %22 = arith.shrui %20, %c32_i64 : i64
    %23 = arith.trunci %22 : i64 to i32
    %24 = arith.index_castui %18 : index to i64
    %25 = arith.index_castui %18 : index to i32
    %26 = arith.shrui %24, %c32_i64 : i64
    %27 = arith.trunci %26 : i64 to i32
    %28 = arith.index_castui %0 : index to i64
    %29 = arith.index_castui %0 : index to i32
    %30 = arith.shrui %28, %c32_i64 : i64
    %31 = arith.trunci %30 : i64 to i32
    %32 = arith.index_castui %1 : index to i64
    %33 = arith.index_castui %1 : index to i32
    %34 = arith.shrui %32, %c32_i64 : i64
    %35 = arith.trunci %34 : i64 to i32
    %36 = arith.index_castui %6 : index to i64
    %37 = arith.index_castui %6 : index to i32
    %38 = arith.shrui %36, %c32_i64 : i64
    %39 = arith.trunci %38 : i64 to i32
    %40 = arith.index_castui %7 : index to i64
    %41 = arith.index_castui %7 : index to i32
    %42 = arith.shrui %40, %c32_i64 : i64
    %43 = arith.trunci %42 : i64 to i32
    %44 = arith.index_castui %11 : index to i64
    %45 = arith.index_castui %11 : index to i32
    %46 = arith.shrui %44, %c32_i64 : i64
    %47 = arith.trunci %46 : i64 to i32
    %48 = arith.index_castui %12 : index to i64
    %49 = arith.index_castui %12 : index to i32
    %50 = arith.shrui %48, %c32_i64 : i64
    %51 = arith.trunci %50 : i64 to i32
    %52 = stream.cmd.execute on(#hal.device.affinity<@__device_0>) await(%result_timepoint) => with(%4 as %arg6: !stream.resource<external>{%3}, %10 as %arg7: !stream.resource<external>{%9}, %15 as %arg8: !stream.resource<external>{%14}, %result as %arg9: !stream.resource<external>{%19}) {
      stream.cmd.dispatch @awq_f16_f16_dispatch_0::@vulkan_spirv_fb::@awq_f16_f16_dispatch_0_elementwise_broadcast_D_f16[%17, %18, %0, %1, %6, %7, %11, %12](%21, %23, %25, %27, %29, %31, %33, %35, %37, %39, %41, %43, %45, %47, %49, %51 : i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32) {
        ro %arg6[%c0 for %3] : !stream.resource<external>{%3},
        ro %arg7[%c0 for %9] : !stream.resource<external>{%9},
        ro %arg8[%c0 for %14] : !stream.resource<external>{%14},
        wo %arg9[%c0 for %19] : !stream.resource<external>{%19}
      }
    } => !stream.timepoint
    %53 = arith.muli %1, %c16 : index
    %54 = arith.muli %53, %0 : index
    stream.timepoint.chain_external on(#hal.device.affinity<@__device_0>) %52 => (%arg5 : !hal.fence)
    %55 = stream.tensor.export on(#hal.device.affinity<@__device_0>) %result : tensor<?x?xf16>{%16, %0} in !stream.resource<external>{%54} -> !hal.buffer_view
    util.return %55 : !hal.buffer_view
  }
  hal.executable private @awq_bf16_bf16_dispatch_0 {
    hal.executable.variant public @vulkan_spirv_fb target(<"vulkan-spirv", "vulkan-spirv-fb", {iree_codegen.target_info = #iree_gpu.target<arch = "vp_android_baseline_2022", features = "spirv:v1.3,cap:Shader,cap:Int16,cap:Float16,cap:StorageBuffer16BitAccess,cap:SignedZeroInfNanPreserve,ext:SPV_KHR_16bit_storage,ext:SPV_KHR_float_controls", wgp = <compute = fp32|int32, storage = b32, subgroup = none, subgroup_size_choices = [64], max_workgroup_sizes = [128, 128, 64], max_thread_count_per_workgroup = 128, max_workgroup_memory_bytes = 16384, max_workgroup_counts = [65535, 65535, 65535]>>}>) {
      hal.executable.export public @awq_bf16_bf16_dispatch_0_elementwise_broadcast_D_i16 ordinal(0) layout(#hal.pipeline.layout<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) count(%arg0: !hal.device, %arg1: index, %arg2: index, %arg3: index, %arg4: index, %arg5: index, %arg6: index, %arg7: index, %arg8: index) -> (index, index, index) {
        %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice(%arg1, %arg2, %arg3, %arg4, %arg5, %arg6, %arg7, %arg8)
        hal.return %x, %y, %z : index, index, index
      }
      builtin.module {
        func.func @awq_bf16_bf16_dispatch_0_elementwise_broadcast_D_i16() attributes {translation_info = #iree_codegen.translation_info<pipeline = #iree_gpu.spirv_pipeline<BaseDistribute> workgroup_size = [64, 1, 1]>} {
          %c32_i64 = arith.constant 32 : i64
          %c8 = arith.constant 8 : index
          %c2 = arith.constant 2 : index
          %c4 = arith.constant 4 : index
          %c15_i32 = arith.constant 15 : i32
          %c0 = arith.constant 0 : index
          %0 = hal.interface.constant.load layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(0) : i32
          %1 = hal.interface.constant.load layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(1) : i32
          %2 = hal.interface.constant.load layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(2) : i32
          %3 = hal.interface.constant.load layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(3) : i32
          %4 = hal.interface.constant.load layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(4) : i32
          %5 = hal.interface.constant.load layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(5) : i32
          %6 = hal.interface.constant.load layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(6) : i32
          %7 = hal.interface.constant.load layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(7) : i32
          %8 = hal.interface.constant.load layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(8) : i32
          %9 = hal.interface.constant.load layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(9) : i32
          %10 = hal.interface.constant.load layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(10) : i32
          %11 = hal.interface.constant.load layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(11) : i32
          %12 = hal.interface.constant.load layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(12) : i32
          %13 = hal.interface.constant.load layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(13) : i32
          %14 = hal.interface.constant.load layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(14) : i32
          %15 = hal.interface.constant.load layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(15) : i32
          %16 = arith.extui %1 : i32 to i64
          %17 = arith.shli %16, %c32_i64 : i64
          %18 = arith.extui %0 : i32 to i64
          %19 = arith.ori %18, %17 : i64
          %20 = arith.index_castui %19 : i64 to index
          %21 = arith.extui %3 : i32 to i64
          %22 = arith.shli %21, %c32_i64 : i64
          %23 = arith.extui %2 : i32 to i64
          %24 = arith.ori %23, %22 : i64
          %25 = arith.index_castui %24 : i64 to index
          %26 = arith.extui %5 : i32 to i64
          %27 = arith.shli %26, %c32_i64 : i64
          %28 = arith.extui %4 : i32 to i64
          %29 = arith.ori %28, %27 : i64
          %30 = arith.index_castui %29 : i64 to index
          %31 = arith.extui %7 : i32 to i64
          %32 = arith.shli %31, %c32_i64 : i64
          %33 = arith.extui %6 : i32 to i64
          %34 = arith.ori %33, %32 : i64
          %35 = arith.index_castui %34 : i64 to index
          %36 = arith.extui %9 : i32 to i64
          %37 = arith.shli %36, %c32_i64 : i64
          %38 = arith.extui %8 : i32 to i64
          %39 = arith.ori %38, %37 : i64
          %40 = arith.index_castui %39 : i64 to index
          %41 = arith.extui %11 : i32 to i64
          %42 = arith.shli %41, %c32_i64 : i64
          %43 = arith.extui %10 : i32 to i64
          %44 = arith.ori %43, %42 : i64
          %45 = arith.index_castui %44 : i64 to index
          %46 = arith.extui %13 : i32 to i64
          %47 = arith.shli %46, %c32_i64 : i64
          %48 = arith.extui %12 : i32 to i64
          %49 = arith.ori %48, %47 : i64
          %50 = arith.index_castui %49 : i64 to index
          %51 = arith.extui %15 : i32 to i64
          %52 = arith.shli %51, %c32_i64 : i64
          %53 = arith.extui %14 : i32 to i64
          %54 = arith.ori %53, %52 : i64
          %55 = arith.index_castui %54 : i64 to index
          %56:7 = util.assume.int 
              %20<umin = 0, umax = 9223372036854775807, udiv = 8>, 
              %30<umin = 0, umax = 9007199254740991>, 
              %35<umin = 0, umax = 9007199254740991>, 
              %40<umin = 0, umax = 9007199254740991>, 
              %45<umin = 0, umax = 9007199254740991>, 
              %50<umin = 0, umax = 9007199254740991>, 
              %55<umin = 0, umax = 9007199254740991>
            : index, index, index, index, index, index, index
          %57 = iree_tensor_ext.dispatch.workload.ordinal %56#0, 0 : index
          %58 = iree_tensor_ext.dispatch.workload.ordinal %56#1, 2 : index
          %59 = iree_tensor_ext.dispatch.workload.ordinal %56#2, 3 : index
          %60 = iree_tensor_ext.dispatch.workload.ordinal %56#3, 4 : index
          %61 = iree_tensor_ext.dispatch.workload.ordinal %56#4, 5 : index
          %62 = iree_tensor_ext.dispatch.workload.ordinal %56#5, 6 : index
          %63 = iree_tensor_ext.dispatch.workload.ordinal %56#6, 7 : index
          %64 = hal.interface.binding.subspan layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(0) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xi32>>{%58, %59}
          %65 = hal.interface.binding.subspan layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(1) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xi32>>{%60, %61}
          %66 = hal.interface.binding.subspan layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(2) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xi16>>{%62, %63}
          %67 = hal.interface.binding.subspan layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(3) alignment(64) offset(%c0) flags(Indirect) : !iree_tensor_ext.dispatch.tensor<writeonly:tensor<?xi16>>{%57}
          %68 = iree_tensor_ext.dispatch.workload.ordinal %25, 1 : index
          %69 = iree_tensor_ext.dispatch.tensor.load %64, offsets = [0, 0], sizes = [%58, %59], strides = [1, 1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xi32>>{%58, %59} -> tensor<?x?xi32>
          %70 = iree_tensor_ext.dispatch.tensor.load %65, offsets = [0, 0], sizes = [%60, %61], strides = [1, 1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xi32>>{%60, %61} -> tensor<?x?xi32>
          %71 = iree_tensor_ext.dispatch.tensor.load %66, offsets = [0, 0], sizes = [%62, %63], strides = [1, 1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xi16>>{%62, %63} -> tensor<?x?xi16>
          %72 = tensor.empty(%57) : tensor<?xi16>
          %73 = linalg.generic {indexing_maps = [affine_map<(d0) -> (d0)>], iterator_types = ["parallel"]} outs(%72 : tensor<?xi16>) attrs =  {lowering_config = #iree_codegen.lowering_config<tile_sizes = [[64], [1]]>} {
          ^bb0(%out: i16):
            %74 = linalg.index 0 : index
            %75 = arith.remsi %74, %58 : index
            %76 = arith.divsi %74, %58 : index
            %77 = arith.divui %75, %68 : index
            %78 = arith.divui %76, %c8 : index
            %79 = arith.remui %76, %c8 : index
            %80 = arith.divui %79, %c2 : index
            %81 = arith.remui %79, %c2 : index
            %82 = arith.muli %81, %c4 : index
            %83 = arith.addi %80, %82 : index
            %extracted = tensor.extract %69[%75, %78] : tensor<?x?xi32>
            %extracted_0 = tensor.extract %70[%77, %78] : tensor<?x?xi32>
            %84 = arith.muli %83, %c4 : index
            %85 = arith.index_castui %84 : index to i32
            %86 = arith.shrui %extracted, %85 : i32
            %87 = arith.andi %86, %c15_i32 : i32
            %88 = arith.shrui %extracted_0, %85 : i32
            %89 = arith.andi %88, %c15_i32 : i32
            %90 = arith.subi %87, %89 : i32
            %91 = arith.sitofp %90 : i32 to f32
            %extracted_1 = tensor.extract %71[%77, %76] : tensor<?x?xi16>
            %92 = arith.bitcast %extracted_1 : i16 to bf16
            %93 = arith.extf %92 : bf16 to f32
            %94 = arith.mulf %91, %93 : f32
            %95 = arith.truncf %94 : f32 to bf16
            %96 = arith.extf %95 : bf16 to f32
            %97 = arith.truncf %96 : f32 to bf16
            %98 = arith.bitcast %97 : bf16 to i16
            linalg.yield %98 : i16
          } -> tensor<?xi16>
          iree_tensor_ext.dispatch.tensor.store %73, %67, offsets = [0], sizes = [%57], strides = [1] : tensor<?xi16> -> !iree_tensor_ext.dispatch.tensor<writeonly:tensor<?xi16>>{%57}
          return
        }
        iree_codegen.dispatch_config @awq_bf16_bf16_dispatch_0_elementwise_broadcast_D_i16 {
        ^bb0(%arg0: !hal.device, %arg1: index, %arg2: index, %arg3: index, %arg4: index, %arg5: index, %arg6: index, %arg7: index, %arg8: index):
          %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice(%arg1, %arg2, %arg3, %arg4, %arg5, %arg6, %arg7, %arg8)
          iree_codegen.yield %x, %y, %z : index, index, index
        }
      }
    }
  }
  util.func public @awq_bf16_bf16(%arg0: !hal.buffer_view, %arg1: !hal.buffer_view, %arg2: !hal.buffer_view, %arg3: i32, %arg4: !hal.fence, %arg5: !hal.fence) -> !hal.buffer_view attributes {iree.abi.stub, iree.reflection = {iree.abi.declaration = "async func @awq_bf16_bf16(%input0: tensor<?x?xi32>, %input1: tensor<?x?xi32>, %input2: tensor<?x?xi16>, %input3: i32) -> (%output0: tensor<?x?xi16>)", iree.abi.model = "coarse-fences"}} {
    %c32_i64 = arith.constant 32 : i64
    %c16 = arith.constant 16 : index
    %c0 = arith.constant 0 : index
    %c2 = arith.constant 2 : index
    %c4 = arith.constant 4 : index
    %c8 = arith.constant 8 : index
    %0 = hal.buffer_view.dim<%arg0 : !hal.buffer_view>[0] : index
    %1 = hal.buffer_view.dim<%arg0 : !hal.buffer_view>[1] : index
    %element_type_i32 = hal.element_type<i32> : i32
    %dense_row_major = hal.encoding_type<dense_row_major> : i32
    hal.buffer_view.assert<%arg0 : !hal.buffer_view> message("input0") shape([%0, %1]) type(%element_type_i32) encoding(%dense_row_major)
    %2 = arith.muli %0, %c4 : index
    %3 = arith.muli %2, %1 : index
    %4 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg0 : !hal.buffer_view -> tensor<?x?xi32>{%0, %1} in !stream.resource<external>{%3}
    %5 = stream.timepoint.import on(#hal.device.affinity<@__device_0>) %arg4 : (!hal.fence) => !stream.timepoint
    %6 = hal.buffer_view.dim<%arg1 : !hal.buffer_view>[0] : index
    %7 = hal.buffer_view.dim<%arg1 : !hal.buffer_view>[1] : index
    hal.buffer_view.assert<%arg1 : !hal.buffer_view> message("input1") shape([%6, %7]) type(%element_type_i32) encoding(%dense_row_major)
    %8 = arith.muli %6, %c4 : index
    %9 = arith.muli %8, %7 : index
    %10 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg1 : !hal.buffer_view -> tensor<?x?xi32>{%6, %7} in !stream.resource<external>{%9}
    %11 = hal.buffer_view.dim<%arg2 : !hal.buffer_view>[0] : index
    %12 = hal.buffer_view.dim<%arg2 : !hal.buffer_view>[1] : index
    %element_type_i16 = hal.element_type<i16> : i32
    hal.buffer_view.assert<%arg2 : !hal.buffer_view> message("input2") shape([%11, %12]) type(%element_type_i16) encoding(%dense_row_major)
    %13 = arith.muli %11, %c2 : index
    %14 = arith.muli %13, %12 : index
    %15 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg2 : !hal.buffer_view -> tensor<?x?xi16>{%11, %12} in !stream.resource<external>{%14}
    %16 = arith.muli %1, %c8 : index
    %17 = arith.muli %16, %0 overflow<nsw> : index
    %18 = arith.index_cast %arg3 : i32 to index
    %19 = arith.muli %17, %c2 : index
    %result, %result_timepoint = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) await(%5) => !stream.resource<external>{%19} => !stream.timepoint
    %20 = arith.index_castui %17 : index to i64
    %21 = arith.index_castui %17 : index to i32
    %22 = arith.shrui %20, %c32_i64 : i64
    %23 = arith.trunci %22 : i64 to i32
    %24 = arith.index_castui %18 : index to i64
    %25 = arith.index_castui %18 : index to i32
    %26 = arith.shrui %24, %c32_i64 : i64
    %27 = arith.trunci %26 : i64 to i32
    %28 = arith.index_castui %0 : index to i64
    %29 = arith.index_castui %0 : index to i32
    %30 = arith.shrui %28, %c32_i64 : i64
    %31 = arith.trunci %30 : i64 to i32
    %32 = arith.index_castui %1 : index to i64
    %33 = arith.index_castui %1 : index to i32
    %34 = arith.shrui %32, %c32_i64 : i64
    %35 = arith.trunci %34 : i64 to i32
    %36 = arith.index_castui %6 : index to i64
    %37 = arith.index_castui %6 : index to i32
    %38 = arith.shrui %36, %c32_i64 : i64
    %39 = arith.trunci %38 : i64 to i32
    %40 = arith.index_castui %7 : index to i64
    %41 = arith.index_castui %7 : index to i32
    %42 = arith.shrui %40, %c32_i64 : i64
    %43 = arith.trunci %42 : i64 to i32
    %44 = arith.index_castui %11 : index to i64
    %45 = arith.index_castui %11 : index to i32
    %46 = arith.shrui %44, %c32_i64 : i64
    %47 = arith.trunci %46 : i64 to i32
    %48 = arith.index_castui %12 : index to i64
    %49 = arith.index_castui %12 : index to i32
    %50 = arith.shrui %48, %c32_i64 : i64
    %51 = arith.trunci %50 : i64 to i32
    %52 = stream.cmd.execute on(#hal.device.affinity<@__device_0>) await(%result_timepoint) => with(%4 as %arg6: !stream.resource<external>{%3}, %10 as %arg7: !stream.resource<external>{%9}, %15 as %arg8: !stream.resource<external>{%14}, %result as %arg9: !stream.resource<external>{%19}) {
      stream.cmd.dispatch @awq_bf16_bf16_dispatch_0::@vulkan_spirv_fb::@awq_bf16_bf16_dispatch_0_elementwise_broadcast_D_i16[%17, %18, %0, %1, %6, %7, %11, %12](%21, %23, %25, %27, %29, %31, %33, %35, %37, %39, %41, %43, %45, %47, %49, %51 : i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32) {
        ro %arg6[%c0 for %3] : !stream.resource<external>{%3},
        ro %arg7[%c0 for %9] : !stream.resource<external>{%9},
        ro %arg8[%c0 for %14] : !stream.resource<external>{%14},
        wo %arg9[%c0 for %19] : !stream.resource<external>{%19}
      }
    } => !stream.timepoint
    %53 = arith.muli %1, %c16 : index
    %54 = arith.muli %53, %0 : index
    stream.timepoint.chain_external on(#hal.device.affinity<@__device_0>) %52 => (%arg5 : !hal.fence)
    %55 = stream.tensor.export on(#hal.device.affinity<@__device_0>) %result : tensor<?x?xi16>{%16, %0} in !stream.resource<external>{%54} -> !hal.buffer_view
    util.return %55 : !hal.buffer_view
  }
  hal.executable private @ct_f32_f32_dispatch_0 {
    hal.executable.variant public @vulkan_spirv_fb target(<"vulkan-spirv", "vulkan-spirv-fb", {iree_codegen.target_info = #iree_gpu.target<arch = "vp_android_baseline_2022", features = "spirv:v1.3,cap:Shader,cap:Int16,cap:Float16,cap:StorageBuffer16BitAccess,cap:SignedZeroInfNanPreserve,ext:SPV_KHR_16bit_storage,ext:SPV_KHR_float_controls", wgp = <compute = fp32|int32, storage = b32, subgroup = none, subgroup_size_choices = [64], max_workgroup_sizes = [128, 128, 64], max_thread_count_per_workgroup = 128, max_workgroup_memory_bytes = 16384, max_workgroup_counts = [65535, 65535, 65535]>>}>) {
      hal.executable.export public @ct_f32_f32_dispatch_0_elementwise_broadcast_D_f32 ordinal(0) layout(#hal.pipeline.layout<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) count(%arg0: !hal.device, %arg1: index, %arg2: index, %arg3: index, %arg4: index, %arg5: index, %arg6: index, %arg7: index) -> (index, index, index) {
        %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice(%arg1, %arg2, %arg3, %arg4, %arg5, %arg6, %arg7)
        hal.return %x, %y, %z : index, index, index
      }
      builtin.module {
        func.func @ct_f32_f32_dispatch_0_elementwise_broadcast_D_f32() attributes {translation_info = #iree_codegen.translation_info<pipeline = #iree_gpu.spirv_pipeline<BaseDistribute> workgroup_size = [64, 1, 1]>} {
          %c32_i64 = arith.constant 32 : i64
          %c8 = arith.constant 8 : index
          %c4 = arith.constant 4 : index
          %c15_i32 = arith.constant 15 : i32
          %c8_i32 = arith.constant 8 : i32
          %c0 = arith.constant 0 : index
          %0 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(0) : i32
          %1 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(1) : i32
          %2 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(2) : i32
          %3 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(3) : i32
          %4 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(4) : i32
          %5 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(5) : i32
          %6 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(6) : i32
          %7 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(7) : i32
          %8 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(8) : i32
          %9 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(9) : i32
          %10 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(10) : i32
          %11 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(11) : i32
          %12 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(12) : i32
          %13 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(13) : i32
          %14 = arith.extui %1 : i32 to i64
          %15 = arith.shli %14, %c32_i64 : i64
          %16 = arith.extui %0 : i32 to i64
          %17 = arith.ori %16, %15 : i64
          %18 = arith.index_castui %17 : i64 to index
          %19 = arith.extui %3 : i32 to i64
          %20 = arith.shli %19, %c32_i64 : i64
          %21 = arith.extui %2 : i32 to i64
          %22 = arith.ori %21, %20 : i64
          %23 = arith.index_castui %22 : i64 to index
          %24 = arith.extui %5 : i32 to i64
          %25 = arith.shli %24, %c32_i64 : i64
          %26 = arith.extui %4 : i32 to i64
          %27 = arith.ori %26, %25 : i64
          %28 = arith.index_castui %27 : i64 to index
          %29 = arith.extui %7 : i32 to i64
          %30 = arith.shli %29, %c32_i64 : i64
          %31 = arith.extui %6 : i32 to i64
          %32 = arith.ori %31, %30 : i64
          %33 = arith.index_castui %32 : i64 to index
          %34 = arith.extui %9 : i32 to i64
          %35 = arith.shli %34, %c32_i64 : i64
          %36 = arith.extui %8 : i32 to i64
          %37 = arith.ori %36, %35 : i64
          %38 = arith.index_castui %37 : i64 to index
          %39 = arith.extui %11 : i32 to i64
          %40 = arith.shli %39, %c32_i64 : i64
          %41 = arith.extui %10 : i32 to i64
          %42 = arith.ori %41, %40 : i64
          %43 = arith.index_castui %42 : i64 to index
          %44 = arith.extui %13 : i32 to i64
          %45 = arith.shli %44, %c32_i64 : i64
          %46 = arith.extui %12 : i32 to i64
          %47 = arith.ori %46, %45 : i64
          %48 = arith.index_castui %47 : i64 to index
          %49:6 = util.assume.int 
              %18<umin = 0, umax = 9223372036854775807, udiv = 8>, 
              %23<umin = 0, umax = 72057594037927928, udiv = 8>, 
              %33<umin = 0, umax = 9007199254740991>, 
              %38<umin = 0, umax = 9007199254740991>, 
              %43<umin = 0, umax = 9007199254740991>, 
              %48<umin = 0, umax = 9007199254740991>
            : index, index, index, index, index, index
          %50 = iree_tensor_ext.dispatch.workload.ordinal %49#0, 0 : index
          %51 = iree_tensor_ext.dispatch.workload.ordinal %49#2, 3 : index
          %52 = iree_tensor_ext.dispatch.workload.ordinal %49#3, 4 : index
          %53 = iree_tensor_ext.dispatch.workload.ordinal %49#4, 5 : index
          %54 = iree_tensor_ext.dispatch.workload.ordinal %49#5, 6 : index
          %55 = hal.interface.binding.subspan layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(0) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xi32>>{%51, %52}
          %56 = hal.interface.binding.subspan layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(1) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xf32>>{%53, %54}
          %57 = hal.interface.binding.subspan layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(2) alignment(64) offset(%c0) flags(Indirect) : !iree_tensor_ext.dispatch.tensor<writeonly:tensor<?xf32>>{%50}
          %58 = iree_tensor_ext.dispatch.workload.ordinal %49#1, 1 : index
          %59 = iree_tensor_ext.dispatch.workload.ordinal %28, 2 : index
          %60 = iree_tensor_ext.dispatch.tensor.load %55, offsets = [0, 0], sizes = [%51, %52], strides = [1, 1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xi32>>{%51, %52} -> tensor<?x?xi32>
          %61 = iree_tensor_ext.dispatch.tensor.load %56, offsets = [0, 0], sizes = [%53, %54], strides = [1, 1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xf32>>{%53, %54} -> tensor<?x?xf32>
          %62 = tensor.empty(%50) : tensor<?xf32>
          %63 = linalg.generic {indexing_maps = [affine_map<(d0) -> (d0)>], iterator_types = ["parallel"]} outs(%62 : tensor<?xf32>) attrs =  {lowering_config = #iree_codegen.lowering_config<tile_sizes = [[64], [1]]>} {
          ^bb0(%out: f32):
            %64 = linalg.index 0 : index
            %65 = arith.remsi %64, %58 : index
            %66 = arith.divsi %64, %58 : index
            %67 = arith.divui %65, %59 : index
            %68 = arith.divui %65, %c8 : index
            %69 = arith.remui %65, %c8 : index
            %extracted = tensor.extract %60[%66, %68] : tensor<?x?xi32>
            %70 = arith.muli %69, %c4 : index
            %71 = arith.index_castui %70 : index to i32
            %72 = arith.shrui %extracted, %71 : i32
            %73 = arith.andi %72, %c15_i32 : i32
            %74 = arith.subi %73, %c8_i32 : i32
            %75 = arith.sitofp %74 : i32 to f32
            %extracted_0 = tensor.extract %61[%66, %67] : tensor<?x?xf32>
            %76 = arith.mulf %75, %extracted_0 : f32
            linalg.yield %76 : f32
          } -> tensor<?xf32>
          iree_tensor_ext.dispatch.tensor.store %63, %57, offsets = [0], sizes = [%50], strides = [1] : tensor<?xf32> -> !iree_tensor_ext.dispatch.tensor<writeonly:tensor<?xf32>>{%50}
          return
        }
        iree_codegen.dispatch_config @ct_f32_f32_dispatch_0_elementwise_broadcast_D_f32 {
        ^bb0(%arg0: !hal.device, %arg1: index, %arg2: index, %arg3: index, %arg4: index, %arg5: index, %arg6: index, %arg7: index):
          %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice(%arg1, %arg2, %arg3, %arg4, %arg5, %arg6, %arg7)
          iree_codegen.yield %x, %y, %z : index, index, index
        }
      }
    }
  }
  util.func public @ct_f32_f32(%arg0: !hal.buffer_view, %arg1: !hal.buffer_view, %arg2: i32, %arg3: !hal.fence, %arg4: !hal.fence) -> !hal.buffer_view attributes {iree.abi.stub, iree.reflection = {iree.abi.declaration = "async func @ct_f32_f32(%input0: tensor<?x?xi32>, %input1: tensor<?x?xf32>, %input2: i32) -> (%output0: tensor<?x?xf32>)", iree.abi.model = "coarse-fences"}} {
    %c32_i64 = arith.constant 32 : i64
    %c0 = arith.constant 0 : index
    %c4 = arith.constant 4 : index
    %c8 = arith.constant 8 : index
    %0 = hal.buffer_view.dim<%arg0 : !hal.buffer_view>[0] : index
    %1 = hal.buffer_view.dim<%arg0 : !hal.buffer_view>[1] : index
    %element_type_i32 = hal.element_type<i32> : i32
    %dense_row_major = hal.encoding_type<dense_row_major> : i32
    hal.buffer_view.assert<%arg0 : !hal.buffer_view> message("input0") shape([%0, %1]) type(%element_type_i32) encoding(%dense_row_major)
    %2 = arith.muli %0, %c4 : index
    %3 = arith.muli %2, %1 : index
    %4 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg0 : !hal.buffer_view -> tensor<?x?xi32>{%0, %1} in !stream.resource<external>{%3}
    %5 = stream.timepoint.import on(#hal.device.affinity<@__device_0>) %arg3 : (!hal.fence) => !stream.timepoint
    %6 = hal.buffer_view.dim<%arg1 : !hal.buffer_view>[0] : index
    %7 = hal.buffer_view.dim<%arg1 : !hal.buffer_view>[1] : index
    %element_type_f32 = hal.element_type<f32> : i32
    hal.buffer_view.assert<%arg1 : !hal.buffer_view> message("input1") shape([%6, %7]) type(%element_type_f32) encoding(%dense_row_major)
    %8 = arith.muli %6, %c4 : index
    %9 = arith.muli %8, %7 : index
    %10 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg1 : !hal.buffer_view -> tensor<?x?xf32>{%6, %7} in !stream.resource<external>{%9}
    %11 = arith.muli %1, %c8 : index
    %12 = arith.muli %0, %11 overflow<nsw> : index
    %13 = arith.index_cast %arg2 : i32 to index
    %14 = arith.muli %12, %c4 : index
    %result, %result_timepoint = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) await(%5) => !stream.resource<external>{%14} => !stream.timepoint
    %15 = arith.index_castui %12 : index to i64
    %16 = arith.index_castui %12 : index to i32
    %17 = arith.shrui %15, %c32_i64 : i64
    %18 = arith.trunci %17 : i64 to i32
    %19 = arith.index_castui %11 : index to i64
    %20 = arith.index_castui %11 : index to i32
    %21 = arith.shrui %19, %c32_i64 : i64
    %22 = arith.trunci %21 : i64 to i32
    %23 = arith.index_castui %13 : index to i64
    %24 = arith.index_castui %13 : index to i32
    %25 = arith.shrui %23, %c32_i64 : i64
    %26 = arith.trunci %25 : i64 to i32
    %27 = arith.index_castui %0 : index to i64
    %28 = arith.index_castui %0 : index to i32
    %29 = arith.shrui %27, %c32_i64 : i64
    %30 = arith.trunci %29 : i64 to i32
    %31 = arith.index_castui %1 : index to i64
    %32 = arith.index_castui %1 : index to i32
    %33 = arith.shrui %31, %c32_i64 : i64
    %34 = arith.trunci %33 : i64 to i32
    %35 = arith.index_castui %6 : index to i64
    %36 = arith.index_castui %6 : index to i32
    %37 = arith.shrui %35, %c32_i64 : i64
    %38 = arith.trunci %37 : i64 to i32
    %39 = arith.index_castui %7 : index to i64
    %40 = arith.index_castui %7 : index to i32
    %41 = arith.shrui %39, %c32_i64 : i64
    %42 = arith.trunci %41 : i64 to i32
    %43 = stream.cmd.execute on(#hal.device.affinity<@__device_0>) await(%result_timepoint) => with(%4 as %arg5: !stream.resource<external>{%3}, %10 as %arg6: !stream.resource<external>{%9}, %result as %arg7: !stream.resource<external>{%14}) {
      stream.cmd.dispatch @ct_f32_f32_dispatch_0::@vulkan_spirv_fb::@ct_f32_f32_dispatch_0_elementwise_broadcast_D_f32[%12, %11, %13, %0, %1, %6, %7](%16, %18, %20, %22, %24, %26, %28, %30, %32, %34, %36, %38, %40, %42 : i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32) {
        ro %arg5[%c0 for %3] : !stream.resource<external>{%3},
        ro %arg6[%c0 for %9] : !stream.resource<external>{%9},
        wo %arg7[%c0 for %14] : !stream.resource<external>{%14}
      }
    } => !stream.timepoint
    %44 = arith.muli %2, %11 : index
    stream.timepoint.chain_external on(#hal.device.affinity<@__device_0>) %43 => (%arg4 : !hal.fence)
    %45 = stream.tensor.export on(#hal.device.affinity<@__device_0>) %result : tensor<?x?xf32>{%0, %11} in !stream.resource<external>{%44} -> !hal.buffer_view
    util.return %45 : !hal.buffer_view
  }
  hal.executable private @ct_f32_f16_dispatch_0 {
    hal.executable.variant public @vulkan_spirv_fb target(<"vulkan-spirv", "vulkan-spirv-fb", {iree_codegen.target_info = #iree_gpu.target<arch = "vp_android_baseline_2022", features = "spirv:v1.3,cap:Shader,cap:Int16,cap:Float16,cap:StorageBuffer16BitAccess,cap:SignedZeroInfNanPreserve,ext:SPV_KHR_16bit_storage,ext:SPV_KHR_float_controls", wgp = <compute = fp32|int32, storage = b32, subgroup = none, subgroup_size_choices = [64], max_workgroup_sizes = [128, 128, 64], max_thread_count_per_workgroup = 128, max_workgroup_memory_bytes = 16384, max_workgroup_counts = [65535, 65535, 65535]>>}>) {
      hal.executable.export public @ct_f32_f16_dispatch_0_elementwise_broadcast_D_f16 ordinal(0) layout(#hal.pipeline.layout<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) count(%arg0: !hal.device, %arg1: index, %arg2: index, %arg3: index, %arg4: index, %arg5: index, %arg6: index, %arg7: index) -> (index, index, index) {
        %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice(%arg1, %arg2, %arg3, %arg4, %arg5, %arg6, %arg7)
        hal.return %x, %y, %z : index, index, index
      }
      builtin.module {
        func.func @ct_f32_f16_dispatch_0_elementwise_broadcast_D_f16() attributes {translation_info = #iree_codegen.translation_info<pipeline = #iree_gpu.spirv_pipeline<BaseDistribute> workgroup_size = [64, 1, 1]>} {
          %c32_i64 = arith.constant 32 : i64
          %c8 = arith.constant 8 : index
          %c4 = arith.constant 4 : index
          %c15_i32 = arith.constant 15 : i32
          %c8_i32 = arith.constant 8 : i32
          %c0 = arith.constant 0 : index
          %0 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(0) : i32
          %1 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(1) : i32
          %2 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(2) : i32
          %3 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(3) : i32
          %4 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(4) : i32
          %5 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(5) : i32
          %6 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(6) : i32
          %7 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(7) : i32
          %8 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(8) : i32
          %9 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(9) : i32
          %10 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(10) : i32
          %11 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(11) : i32
          %12 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(12) : i32
          %13 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(13) : i32
          %14 = arith.extui %1 : i32 to i64
          %15 = arith.shli %14, %c32_i64 : i64
          %16 = arith.extui %0 : i32 to i64
          %17 = arith.ori %16, %15 : i64
          %18 = arith.index_castui %17 : i64 to index
          %19 = arith.extui %3 : i32 to i64
          %20 = arith.shli %19, %c32_i64 : i64
          %21 = arith.extui %2 : i32 to i64
          %22 = arith.ori %21, %20 : i64
          %23 = arith.index_castui %22 : i64 to index
          %24 = arith.extui %5 : i32 to i64
          %25 = arith.shli %24, %c32_i64 : i64
          %26 = arith.extui %4 : i32 to i64
          %27 = arith.ori %26, %25 : i64
          %28 = arith.index_castui %27 : i64 to index
          %29 = arith.extui %7 : i32 to i64
          %30 = arith.shli %29, %c32_i64 : i64
          %31 = arith.extui %6 : i32 to i64
          %32 = arith.ori %31, %30 : i64
          %33 = arith.index_castui %32 : i64 to index
          %34 = arith.extui %9 : i32 to i64
          %35 = arith.shli %34, %c32_i64 : i64
          %36 = arith.extui %8 : i32 to i64
          %37 = arith.ori %36, %35 : i64
          %38 = arith.index_castui %37 : i64 to index
          %39 = arith.extui %11 : i32 to i64
          %40 = arith.shli %39, %c32_i64 : i64
          %41 = arith.extui %10 : i32 to i64
          %42 = arith.ori %41, %40 : i64
          %43 = arith.index_castui %42 : i64 to index
          %44 = arith.extui %13 : i32 to i64
          %45 = arith.shli %44, %c32_i64 : i64
          %46 = arith.extui %12 : i32 to i64
          %47 = arith.ori %46, %45 : i64
          %48 = arith.index_castui %47 : i64 to index
          %49:6 = util.assume.int 
              %18<umin = 0, umax = 9223372036854775807, udiv = 8>, 
              %23<umin = 0, umax = 72057594037927928, udiv = 8>, 
              %33<umin = 0, umax = 9007199254740991>, 
              %38<umin = 0, umax = 9007199254740991>, 
              %43<umin = 0, umax = 9007199254740991>, 
              %48<umin = 0, umax = 9007199254740991>
            : index, index, index, index, index, index
          %50 = iree_tensor_ext.dispatch.workload.ordinal %49#0, 0 : index
          %51 = iree_tensor_ext.dispatch.workload.ordinal %49#2, 3 : index
          %52 = iree_tensor_ext.dispatch.workload.ordinal %49#3, 4 : index
          %53 = iree_tensor_ext.dispatch.workload.ordinal %49#4, 5 : index
          %54 = iree_tensor_ext.dispatch.workload.ordinal %49#5, 6 : index
          %55 = hal.interface.binding.subspan layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(0) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xi32>>{%51, %52}
          %56 = hal.interface.binding.subspan layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(1) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xf32>>{%53, %54}
          %57 = hal.interface.binding.subspan layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(2) alignment(64) offset(%c0) flags(Indirect) : !iree_tensor_ext.dispatch.tensor<writeonly:tensor<?xf16>>{%50}
          %58 = iree_tensor_ext.dispatch.workload.ordinal %49#1, 1 : index
          %59 = iree_tensor_ext.dispatch.workload.ordinal %28, 2 : index
          %60 = iree_tensor_ext.dispatch.tensor.load %55, offsets = [0, 0], sizes = [%51, %52], strides = [1, 1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xi32>>{%51, %52} -> tensor<?x?xi32>
          %61 = iree_tensor_ext.dispatch.tensor.load %56, offsets = [0, 0], sizes = [%53, %54], strides = [1, 1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xf32>>{%53, %54} -> tensor<?x?xf32>
          %62 = tensor.empty(%50) : tensor<?xf16>
          %63 = linalg.generic {indexing_maps = [affine_map<(d0) -> (d0)>], iterator_types = ["parallel"]} outs(%62 : tensor<?xf16>) attrs =  {lowering_config = #iree_codegen.lowering_config<tile_sizes = [[64], [1]]>} {
          ^bb0(%out: f16):
            %64 = linalg.index 0 : index
            %65 = arith.remsi %64, %58 : index
            %66 = arith.divsi %64, %58 : index
            %67 = arith.divui %65, %59 : index
            %68 = arith.divui %65, %c8 : index
            %69 = arith.remui %65, %c8 : index
            %extracted = tensor.extract %60[%66, %68] : tensor<?x?xi32>
            %70 = arith.muli %69, %c4 : index
            %71 = arith.index_castui %70 : index to i32
            %72 = arith.shrui %extracted, %71 : i32
            %73 = arith.andi %72, %c15_i32 : i32
            %74 = arith.subi %73, %c8_i32 : i32
            %75 = arith.sitofp %74 : i32 to f32
            %extracted_0 = tensor.extract %61[%66, %67] : tensor<?x?xf32>
            %76 = arith.mulf %75, %extracted_0 : f32
            %77 = arith.truncf %76 : f32 to f16
            linalg.yield %77 : f16
          } -> tensor<?xf16>
          iree_tensor_ext.dispatch.tensor.store %63, %57, offsets = [0], sizes = [%50], strides = [1] : tensor<?xf16> -> !iree_tensor_ext.dispatch.tensor<writeonly:tensor<?xf16>>{%50}
          return
        }
        iree_codegen.dispatch_config @ct_f32_f16_dispatch_0_elementwise_broadcast_D_f16 {
        ^bb0(%arg0: !hal.device, %arg1: index, %arg2: index, %arg3: index, %arg4: index, %arg5: index, %arg6: index, %arg7: index):
          %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice(%arg1, %arg2, %arg3, %arg4, %arg5, %arg6, %arg7)
          iree_codegen.yield %x, %y, %z : index, index, index
        }
      }
    }
  }
  util.func public @ct_f32_f16(%arg0: !hal.buffer_view, %arg1: !hal.buffer_view, %arg2: i32, %arg3: !hal.fence, %arg4: !hal.fence) -> !hal.buffer_view attributes {iree.abi.stub, iree.reflection = {iree.abi.declaration = "async func @ct_f32_f16(%input0: tensor<?x?xi32>, %input1: tensor<?x?xf32>, %input2: i32) -> (%output0: tensor<?x?xf16>)", iree.abi.model = "coarse-fences"}} {
    %c32_i64 = arith.constant 32 : i64
    %c0 = arith.constant 0 : index
    %c2 = arith.constant 2 : index
    %c4 = arith.constant 4 : index
    %c8 = arith.constant 8 : index
    %0 = hal.buffer_view.dim<%arg0 : !hal.buffer_view>[0] : index
    %1 = hal.buffer_view.dim<%arg0 : !hal.buffer_view>[1] : index
    %element_type_i32 = hal.element_type<i32> : i32
    %dense_row_major = hal.encoding_type<dense_row_major> : i32
    hal.buffer_view.assert<%arg0 : !hal.buffer_view> message("input0") shape([%0, %1]) type(%element_type_i32) encoding(%dense_row_major)
    %2 = arith.muli %0, %c4 : index
    %3 = arith.muli %2, %1 : index
    %4 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg0 : !hal.buffer_view -> tensor<?x?xi32>{%0, %1} in !stream.resource<external>{%3}
    %5 = stream.timepoint.import on(#hal.device.affinity<@__device_0>) %arg3 : (!hal.fence) => !stream.timepoint
    %6 = hal.buffer_view.dim<%arg1 : !hal.buffer_view>[0] : index
    %7 = hal.buffer_view.dim<%arg1 : !hal.buffer_view>[1] : index
    %element_type_f32 = hal.element_type<f32> : i32
    hal.buffer_view.assert<%arg1 : !hal.buffer_view> message("input1") shape([%6, %7]) type(%element_type_f32) encoding(%dense_row_major)
    %8 = arith.muli %6, %c4 : index
    %9 = arith.muli %8, %7 : index
    %10 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg1 : !hal.buffer_view -> tensor<?x?xf32>{%6, %7} in !stream.resource<external>{%9}
    %11 = arith.muli %1, %c8 : index
    %12 = arith.muli %0, %11 overflow<nsw> : index
    %13 = arith.index_cast %arg2 : i32 to index
    %14 = arith.muli %12, %c2 : index
    %result, %result_timepoint = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) await(%5) => !stream.resource<external>{%14} => !stream.timepoint
    %15 = arith.index_castui %12 : index to i64
    %16 = arith.index_castui %12 : index to i32
    %17 = arith.shrui %15, %c32_i64 : i64
    %18 = arith.trunci %17 : i64 to i32
    %19 = arith.index_castui %11 : index to i64
    %20 = arith.index_castui %11 : index to i32
    %21 = arith.shrui %19, %c32_i64 : i64
    %22 = arith.trunci %21 : i64 to i32
    %23 = arith.index_castui %13 : index to i64
    %24 = arith.index_castui %13 : index to i32
    %25 = arith.shrui %23, %c32_i64 : i64
    %26 = arith.trunci %25 : i64 to i32
    %27 = arith.index_castui %0 : index to i64
    %28 = arith.index_castui %0 : index to i32
    %29 = arith.shrui %27, %c32_i64 : i64
    %30 = arith.trunci %29 : i64 to i32
    %31 = arith.index_castui %1 : index to i64
    %32 = arith.index_castui %1 : index to i32
    %33 = arith.shrui %31, %c32_i64 : i64
    %34 = arith.trunci %33 : i64 to i32
    %35 = arith.index_castui %6 : index to i64
    %36 = arith.index_castui %6 : index to i32
    %37 = arith.shrui %35, %c32_i64 : i64
    %38 = arith.trunci %37 : i64 to i32
    %39 = arith.index_castui %7 : index to i64
    %40 = arith.index_castui %7 : index to i32
    %41 = arith.shrui %39, %c32_i64 : i64
    %42 = arith.trunci %41 : i64 to i32
    %43 = stream.cmd.execute on(#hal.device.affinity<@__device_0>) await(%result_timepoint) => with(%4 as %arg5: !stream.resource<external>{%3}, %10 as %arg6: !stream.resource<external>{%9}, %result as %arg7: !stream.resource<external>{%14}) {
      stream.cmd.dispatch @ct_f32_f16_dispatch_0::@vulkan_spirv_fb::@ct_f32_f16_dispatch_0_elementwise_broadcast_D_f16[%12, %11, %13, %0, %1, %6, %7](%16, %18, %20, %22, %24, %26, %28, %30, %32, %34, %36, %38, %40, %42 : i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32) {
        ro %arg5[%c0 for %3] : !stream.resource<external>{%3},
        ro %arg6[%c0 for %9] : !stream.resource<external>{%9},
        wo %arg7[%c0 for %14] : !stream.resource<external>{%14}
      }
    } => !stream.timepoint
    %44 = arith.muli %0, %c2 : index
    %45 = arith.muli %44, %11 : index
    stream.timepoint.chain_external on(#hal.device.affinity<@__device_0>) %43 => (%arg4 : !hal.fence)
    %46 = stream.tensor.export on(#hal.device.affinity<@__device_0>) %result : tensor<?x?xf16>{%0, %11} in !stream.resource<external>{%45} -> !hal.buffer_view
    util.return %46 : !hal.buffer_view
  }
  hal.executable private @ct_f32_bf16_dispatch_0 {
    hal.executable.variant public @vulkan_spirv_fb target(<"vulkan-spirv", "vulkan-spirv-fb", {iree_codegen.target_info = #iree_gpu.target<arch = "vp_android_baseline_2022", features = "spirv:v1.3,cap:Shader,cap:Int16,cap:Float16,cap:StorageBuffer16BitAccess,cap:SignedZeroInfNanPreserve,ext:SPV_KHR_16bit_storage,ext:SPV_KHR_float_controls", wgp = <compute = fp32|int32, storage = b32, subgroup = none, subgroup_size_choices = [64], max_workgroup_sizes = [128, 128, 64], max_thread_count_per_workgroup = 128, max_workgroup_memory_bytes = 16384, max_workgroup_counts = [65535, 65535, 65535]>>}>) {
      hal.executable.export public @ct_f32_bf16_dispatch_0_elementwise_broadcast_D_i16 ordinal(0) layout(#hal.pipeline.layout<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) count(%arg0: !hal.device, %arg1: index, %arg2: index, %arg3: index, %arg4: index, %arg5: index, %arg6: index, %arg7: index) -> (index, index, index) {
        %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice(%arg1, %arg2, %arg3, %arg4, %arg5, %arg6, %arg7)
        hal.return %x, %y, %z : index, index, index
      }
      builtin.module {
        func.func @ct_f32_bf16_dispatch_0_elementwise_broadcast_D_i16() attributes {translation_info = #iree_codegen.translation_info<pipeline = #iree_gpu.spirv_pipeline<BaseDistribute> workgroup_size = [64, 1, 1]>} {
          %c32_i64 = arith.constant 32 : i64
          %c8 = arith.constant 8 : index
          %c4 = arith.constant 4 : index
          %c15_i32 = arith.constant 15 : i32
          %c8_i32 = arith.constant 8 : i32
          %c0 = arith.constant 0 : index
          %0 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(0) : i32
          %1 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(1) : i32
          %2 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(2) : i32
          %3 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(3) : i32
          %4 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(4) : i32
          %5 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(5) : i32
          %6 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(6) : i32
          %7 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(7) : i32
          %8 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(8) : i32
          %9 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(9) : i32
          %10 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(10) : i32
          %11 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(11) : i32
          %12 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(12) : i32
          %13 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(13) : i32
          %14 = arith.extui %1 : i32 to i64
          %15 = arith.shli %14, %c32_i64 : i64
          %16 = arith.extui %0 : i32 to i64
          %17 = arith.ori %16, %15 : i64
          %18 = arith.index_castui %17 : i64 to index
          %19 = arith.extui %3 : i32 to i64
          %20 = arith.shli %19, %c32_i64 : i64
          %21 = arith.extui %2 : i32 to i64
          %22 = arith.ori %21, %20 : i64
          %23 = arith.index_castui %22 : i64 to index
          %24 = arith.extui %5 : i32 to i64
          %25 = arith.shli %24, %c32_i64 : i64
          %26 = arith.extui %4 : i32 to i64
          %27 = arith.ori %26, %25 : i64
          %28 = arith.index_castui %27 : i64 to index
          %29 = arith.extui %7 : i32 to i64
          %30 = arith.shli %29, %c32_i64 : i64
          %31 = arith.extui %6 : i32 to i64
          %32 = arith.ori %31, %30 : i64
          %33 = arith.index_castui %32 : i64 to index
          %34 = arith.extui %9 : i32 to i64
          %35 = arith.shli %34, %c32_i64 : i64
          %36 = arith.extui %8 : i32 to i64
          %37 = arith.ori %36, %35 : i64
          %38 = arith.index_castui %37 : i64 to index
          %39 = arith.extui %11 : i32 to i64
          %40 = arith.shli %39, %c32_i64 : i64
          %41 = arith.extui %10 : i32 to i64
          %42 = arith.ori %41, %40 : i64
          %43 = arith.index_castui %42 : i64 to index
          %44 = arith.extui %13 : i32 to i64
          %45 = arith.shli %44, %c32_i64 : i64
          %46 = arith.extui %12 : i32 to i64
          %47 = arith.ori %46, %45 : i64
          %48 = arith.index_castui %47 : i64 to index
          %49:6 = util.assume.int 
              %18<umin = 0, umax = 9223372036854775807, udiv = 8>, 
              %23<umin = 0, umax = 72057594037927928, udiv = 8>, 
              %33<umin = 0, umax = 9007199254740991>, 
              %38<umin = 0, umax = 9007199254740991>, 
              %43<umin = 0, umax = 9007199254740991>, 
              %48<umin = 0, umax = 9007199254740991>
            : index, index, index, index, index, index
          %50 = iree_tensor_ext.dispatch.workload.ordinal %49#0, 0 : index
          %51 = iree_tensor_ext.dispatch.workload.ordinal %49#2, 3 : index
          %52 = iree_tensor_ext.dispatch.workload.ordinal %49#3, 4 : index
          %53 = iree_tensor_ext.dispatch.workload.ordinal %49#4, 5 : index
          %54 = iree_tensor_ext.dispatch.workload.ordinal %49#5, 6 : index
          %55 = hal.interface.binding.subspan layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(0) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xi32>>{%51, %52}
          %56 = hal.interface.binding.subspan layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(1) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xf32>>{%53, %54}
          %57 = hal.interface.binding.subspan layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(2) alignment(64) offset(%c0) flags(Indirect) : !iree_tensor_ext.dispatch.tensor<writeonly:tensor<?xi16>>{%50}
          %58 = iree_tensor_ext.dispatch.workload.ordinal %49#1, 1 : index
          %59 = iree_tensor_ext.dispatch.workload.ordinal %28, 2 : index
          %60 = iree_tensor_ext.dispatch.tensor.load %55, offsets = [0, 0], sizes = [%51, %52], strides = [1, 1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xi32>>{%51, %52} -> tensor<?x?xi32>
          %61 = iree_tensor_ext.dispatch.tensor.load %56, offsets = [0, 0], sizes = [%53, %54], strides = [1, 1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xf32>>{%53, %54} -> tensor<?x?xf32>
          %62 = tensor.empty(%50) : tensor<?xi16>
          %63 = linalg.generic {indexing_maps = [affine_map<(d0) -> (d0)>], iterator_types = ["parallel"]} outs(%62 : tensor<?xi16>) attrs =  {lowering_config = #iree_codegen.lowering_config<tile_sizes = [[64], [1]]>} {
          ^bb0(%out: i16):
            %64 = linalg.index 0 : index
            %65 = arith.remsi %64, %58 : index
            %66 = arith.divsi %64, %58 : index
            %67 = arith.divui %65, %59 : index
            %68 = arith.divui %65, %c8 : index
            %69 = arith.remui %65, %c8 : index
            %extracted = tensor.extract %60[%66, %68] : tensor<?x?xi32>
            %70 = arith.muli %69, %c4 : index
            %71 = arith.index_castui %70 : index to i32
            %72 = arith.shrui %extracted, %71 : i32
            %73 = arith.andi %72, %c15_i32 : i32
            %74 = arith.subi %73, %c8_i32 : i32
            %75 = arith.sitofp %74 : i32 to f32
            %extracted_0 = tensor.extract %61[%66, %67] : tensor<?x?xf32>
            %76 = arith.mulf %75, %extracted_0 : f32
            %77 = arith.truncf %76 : f32 to bf16
            %78 = arith.bitcast %77 : bf16 to i16
            linalg.yield %78 : i16
          } -> tensor<?xi16>
          iree_tensor_ext.dispatch.tensor.store %63, %57, offsets = [0], sizes = [%50], strides = [1] : tensor<?xi16> -> !iree_tensor_ext.dispatch.tensor<writeonly:tensor<?xi16>>{%50}
          return
        }
        iree_codegen.dispatch_config @ct_f32_bf16_dispatch_0_elementwise_broadcast_D_i16 {
        ^bb0(%arg0: !hal.device, %arg1: index, %arg2: index, %arg3: index, %arg4: index, %arg5: index, %arg6: index, %arg7: index):
          %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice(%arg1, %arg2, %arg3, %arg4, %arg5, %arg6, %arg7)
          iree_codegen.yield %x, %y, %z : index, index, index
        }
      }
    }
  }
  util.func public @ct_f32_bf16(%arg0: !hal.buffer_view, %arg1: !hal.buffer_view, %arg2: i32, %arg3: !hal.fence, %arg4: !hal.fence) -> !hal.buffer_view attributes {iree.abi.stub, iree.reflection = {iree.abi.declaration = "async func @ct_f32_bf16(%input0: tensor<?x?xi32>, %input1: tensor<?x?xf32>, %input2: i32) -> (%output0: tensor<?x?xi16>)", iree.abi.model = "coarse-fences"}} {
    %c32_i64 = arith.constant 32 : i64
    %c0 = arith.constant 0 : index
    %c2 = arith.constant 2 : index
    %c4 = arith.constant 4 : index
    %c8 = arith.constant 8 : index
    %0 = hal.buffer_view.dim<%arg0 : !hal.buffer_view>[0] : index
    %1 = hal.buffer_view.dim<%arg0 : !hal.buffer_view>[1] : index
    %element_type_i32 = hal.element_type<i32> : i32
    %dense_row_major = hal.encoding_type<dense_row_major> : i32
    hal.buffer_view.assert<%arg0 : !hal.buffer_view> message("input0") shape([%0, %1]) type(%element_type_i32) encoding(%dense_row_major)
    %2 = arith.muli %0, %c4 : index
    %3 = arith.muli %2, %1 : index
    %4 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg0 : !hal.buffer_view -> tensor<?x?xi32>{%0, %1} in !stream.resource<external>{%3}
    %5 = stream.timepoint.import on(#hal.device.affinity<@__device_0>) %arg3 : (!hal.fence) => !stream.timepoint
    %6 = hal.buffer_view.dim<%arg1 : !hal.buffer_view>[0] : index
    %7 = hal.buffer_view.dim<%arg1 : !hal.buffer_view>[1] : index
    %element_type_f32 = hal.element_type<f32> : i32
    hal.buffer_view.assert<%arg1 : !hal.buffer_view> message("input1") shape([%6, %7]) type(%element_type_f32) encoding(%dense_row_major)
    %8 = arith.muli %6, %c4 : index
    %9 = arith.muli %8, %7 : index
    %10 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg1 : !hal.buffer_view -> tensor<?x?xf32>{%6, %7} in !stream.resource<external>{%9}
    %11 = arith.muli %1, %c8 : index
    %12 = arith.muli %0, %11 overflow<nsw> : index
    %13 = arith.index_cast %arg2 : i32 to index
    %14 = arith.muli %12, %c2 : index
    %result, %result_timepoint = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) await(%5) => !stream.resource<external>{%14} => !stream.timepoint
    %15 = arith.index_castui %12 : index to i64
    %16 = arith.index_castui %12 : index to i32
    %17 = arith.shrui %15, %c32_i64 : i64
    %18 = arith.trunci %17 : i64 to i32
    %19 = arith.index_castui %11 : index to i64
    %20 = arith.index_castui %11 : index to i32
    %21 = arith.shrui %19, %c32_i64 : i64
    %22 = arith.trunci %21 : i64 to i32
    %23 = arith.index_castui %13 : index to i64
    %24 = arith.index_castui %13 : index to i32
    %25 = arith.shrui %23, %c32_i64 : i64
    %26 = arith.trunci %25 : i64 to i32
    %27 = arith.index_castui %0 : index to i64
    %28 = arith.index_castui %0 : index to i32
    %29 = arith.shrui %27, %c32_i64 : i64
    %30 = arith.trunci %29 : i64 to i32
    %31 = arith.index_castui %1 : index to i64
    %32 = arith.index_castui %1 : index to i32
    %33 = arith.shrui %31, %c32_i64 : i64
    %34 = arith.trunci %33 : i64 to i32
    %35 = arith.index_castui %6 : index to i64
    %36 = arith.index_castui %6 : index to i32
    %37 = arith.shrui %35, %c32_i64 : i64
    %38 = arith.trunci %37 : i64 to i32
    %39 = arith.index_castui %7 : index to i64
    %40 = arith.index_castui %7 : index to i32
    %41 = arith.shrui %39, %c32_i64 : i64
    %42 = arith.trunci %41 : i64 to i32
    %43 = stream.cmd.execute on(#hal.device.affinity<@__device_0>) await(%result_timepoint) => with(%4 as %arg5: !stream.resource<external>{%3}, %10 as %arg6: !stream.resource<external>{%9}, %result as %arg7: !stream.resource<external>{%14}) {
      stream.cmd.dispatch @ct_f32_bf16_dispatch_0::@vulkan_spirv_fb::@ct_f32_bf16_dispatch_0_elementwise_broadcast_D_i16[%12, %11, %13, %0, %1, %6, %7](%16, %18, %20, %22, %24, %26, %28, %30, %32, %34, %36, %38, %40, %42 : i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32) {
        ro %arg5[%c0 for %3] : !stream.resource<external>{%3},
        ro %arg6[%c0 for %9] : !stream.resource<external>{%9},
        wo %arg7[%c0 for %14] : !stream.resource<external>{%14}
      }
    } => !stream.timepoint
    %44 = arith.muli %0, %c2 : index
    %45 = arith.muli %44, %11 : index
    stream.timepoint.chain_external on(#hal.device.affinity<@__device_0>) %43 => (%arg4 : !hal.fence)
    %46 = stream.tensor.export on(#hal.device.affinity<@__device_0>) %result : tensor<?x?xi16>{%0, %11} in !stream.resource<external>{%45} -> !hal.buffer_view
    util.return %46 : !hal.buffer_view
  }
  hal.executable private @ct_f16_f16_dispatch_0 {
    hal.executable.variant public @vulkan_spirv_fb target(<"vulkan-spirv", "vulkan-spirv-fb", {iree_codegen.target_info = #iree_gpu.target<arch = "vp_android_baseline_2022", features = "spirv:v1.3,cap:Shader,cap:Int16,cap:Float16,cap:StorageBuffer16BitAccess,cap:SignedZeroInfNanPreserve,ext:SPV_KHR_16bit_storage,ext:SPV_KHR_float_controls", wgp = <compute = fp32|int32, storage = b32, subgroup = none, subgroup_size_choices = [64], max_workgroup_sizes = [128, 128, 64], max_thread_count_per_workgroup = 128, max_workgroup_memory_bytes = 16384, max_workgroup_counts = [65535, 65535, 65535]>>}>) {
      hal.executable.export public @ct_f16_f16_dispatch_0_elementwise_broadcast_D_f16 ordinal(0) layout(#hal.pipeline.layout<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) count(%arg0: !hal.device, %arg1: index, %arg2: index, %arg3: index, %arg4: index, %arg5: index, %arg6: index, %arg7: index) -> (index, index, index) {
        %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice(%arg1, %arg2, %arg3, %arg4, %arg5, %arg6, %arg7)
        hal.return %x, %y, %z : index, index, index
      }
      builtin.module {
        func.func @ct_f16_f16_dispatch_0_elementwise_broadcast_D_f16() attributes {translation_info = #iree_codegen.translation_info<pipeline = #iree_gpu.spirv_pipeline<BaseDistribute> workgroup_size = [64, 1, 1]>} {
          %c32_i64 = arith.constant 32 : i64
          %c8 = arith.constant 8 : index
          %c4 = arith.constant 4 : index
          %c15_i32 = arith.constant 15 : i32
          %c8_i32 = arith.constant 8 : i32
          %c0 = arith.constant 0 : index
          %0 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(0) : i32
          %1 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(1) : i32
          %2 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(2) : i32
          %3 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(3) : i32
          %4 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(4) : i32
          %5 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(5) : i32
          %6 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(6) : i32
          %7 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(7) : i32
          %8 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(8) : i32
          %9 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(9) : i32
          %10 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(10) : i32
          %11 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(11) : i32
          %12 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(12) : i32
          %13 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(13) : i32
          %14 = arith.extui %1 : i32 to i64
          %15 = arith.shli %14, %c32_i64 : i64
          %16 = arith.extui %0 : i32 to i64
          %17 = arith.ori %16, %15 : i64
          %18 = arith.index_castui %17 : i64 to index
          %19 = arith.extui %3 : i32 to i64
          %20 = arith.shli %19, %c32_i64 : i64
          %21 = arith.extui %2 : i32 to i64
          %22 = arith.ori %21, %20 : i64
          %23 = arith.index_castui %22 : i64 to index
          %24 = arith.extui %5 : i32 to i64
          %25 = arith.shli %24, %c32_i64 : i64
          %26 = arith.extui %4 : i32 to i64
          %27 = arith.ori %26, %25 : i64
          %28 = arith.index_castui %27 : i64 to index
          %29 = arith.extui %7 : i32 to i64
          %30 = arith.shli %29, %c32_i64 : i64
          %31 = arith.extui %6 : i32 to i64
          %32 = arith.ori %31, %30 : i64
          %33 = arith.index_castui %32 : i64 to index
          %34 = arith.extui %9 : i32 to i64
          %35 = arith.shli %34, %c32_i64 : i64
          %36 = arith.extui %8 : i32 to i64
          %37 = arith.ori %36, %35 : i64
          %38 = arith.index_castui %37 : i64 to index
          %39 = arith.extui %11 : i32 to i64
          %40 = arith.shli %39, %c32_i64 : i64
          %41 = arith.extui %10 : i32 to i64
          %42 = arith.ori %41, %40 : i64
          %43 = arith.index_castui %42 : i64 to index
          %44 = arith.extui %13 : i32 to i64
          %45 = arith.shli %44, %c32_i64 : i64
          %46 = arith.extui %12 : i32 to i64
          %47 = arith.ori %46, %45 : i64
          %48 = arith.index_castui %47 : i64 to index
          %49:6 = util.assume.int 
              %18<umin = 0, umax = 9223372036854775807, udiv = 8>, 
              %23<umin = 0, umax = 72057594037927928, udiv = 8>, 
              %33<umin = 0, umax = 9007199254740991>, 
              %38<umin = 0, umax = 9007199254740991>, 
              %43<umin = 0, umax = 9007199254740991>, 
              %48<umin = 0, umax = 9007199254740991>
            : index, index, index, index, index, index
          %50 = iree_tensor_ext.dispatch.workload.ordinal %49#0, 0 : index
          %51 = iree_tensor_ext.dispatch.workload.ordinal %49#2, 3 : index
          %52 = iree_tensor_ext.dispatch.workload.ordinal %49#3, 4 : index
          %53 = iree_tensor_ext.dispatch.workload.ordinal %49#4, 5 : index
          %54 = iree_tensor_ext.dispatch.workload.ordinal %49#5, 6 : index
          %55 = hal.interface.binding.subspan layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(0) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xi32>>{%51, %52}
          %56 = hal.interface.binding.subspan layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(1) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xf16>>{%53, %54}
          %57 = hal.interface.binding.subspan layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(2) alignment(64) offset(%c0) flags(Indirect) : !iree_tensor_ext.dispatch.tensor<writeonly:tensor<?xf16>>{%50}
          %58 = iree_tensor_ext.dispatch.workload.ordinal %49#1, 1 : index
          %59 = iree_tensor_ext.dispatch.workload.ordinal %28, 2 : index
          %60 = iree_tensor_ext.dispatch.tensor.load %55, offsets = [0, 0], sizes = [%51, %52], strides = [1, 1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xi32>>{%51, %52} -> tensor<?x?xi32>
          %61 = iree_tensor_ext.dispatch.tensor.load %56, offsets = [0, 0], sizes = [%53, %54], strides = [1, 1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xf16>>{%53, %54} -> tensor<?x?xf16>
          %62 = tensor.empty(%50) : tensor<?xf16>
          %63 = linalg.generic {indexing_maps = [affine_map<(d0) -> (d0)>], iterator_types = ["parallel"]} outs(%62 : tensor<?xf16>) attrs =  {lowering_config = #iree_codegen.lowering_config<tile_sizes = [[64], [1]]>} {
          ^bb0(%out: f16):
            %64 = linalg.index 0 : index
            %65 = arith.remsi %64, %58 : index
            %66 = arith.divsi %64, %58 : index
            %67 = arith.divui %65, %59 : index
            %68 = arith.divui %65, %c8 : index
            %69 = arith.remui %65, %c8 : index
            %extracted = tensor.extract %60[%66, %68] : tensor<?x?xi32>
            %70 = arith.muli %69, %c4 : index
            %71 = arith.index_castui %70 : index to i32
            %72 = arith.shrui %extracted, %71 : i32
            %73 = arith.andi %72, %c15_i32 : i32
            %74 = arith.subi %73, %c8_i32 : i32
            %75 = arith.sitofp %74 : i32 to f32
            %extracted_0 = tensor.extract %61[%66, %67] : tensor<?x?xf16>
            %76 = arith.extf %extracted_0 : f16 to f32
            %77 = arith.mulf %75, %76 : f32
            %78 = arith.truncf %77 : f32 to f16
            %79 = arith.extf %78 : f16 to f32
            %80 = arith.truncf %79 : f32 to f16
            linalg.yield %80 : f16
          } -> tensor<?xf16>
          iree_tensor_ext.dispatch.tensor.store %63, %57, offsets = [0], sizes = [%50], strides = [1] : tensor<?xf16> -> !iree_tensor_ext.dispatch.tensor<writeonly:tensor<?xf16>>{%50}
          return
        }
        iree_codegen.dispatch_config @ct_f16_f16_dispatch_0_elementwise_broadcast_D_f16 {
        ^bb0(%arg0: !hal.device, %arg1: index, %arg2: index, %arg3: index, %arg4: index, %arg5: index, %arg6: index, %arg7: index):
          %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice(%arg1, %arg2, %arg3, %arg4, %arg5, %arg6, %arg7)
          iree_codegen.yield %x, %y, %z : index, index, index
        }
      }
    }
  }
  util.func public @ct_f16_f16(%arg0: !hal.buffer_view, %arg1: !hal.buffer_view, %arg2: i32, %arg3: !hal.fence, %arg4: !hal.fence) -> !hal.buffer_view attributes {iree.abi.stub, iree.reflection = {iree.abi.declaration = "async func @ct_f16_f16(%input0: tensor<?x?xi32>, %input1: tensor<?x?xf16>, %input2: i32) -> (%output0: tensor<?x?xf16>)", iree.abi.model = "coarse-fences"}} {
    %c32_i64 = arith.constant 32 : i64
    %c0 = arith.constant 0 : index
    %c2 = arith.constant 2 : index
    %c4 = arith.constant 4 : index
    %c8 = arith.constant 8 : index
    %0 = hal.buffer_view.dim<%arg0 : !hal.buffer_view>[0] : index
    %1 = hal.buffer_view.dim<%arg0 : !hal.buffer_view>[1] : index
    %element_type_i32 = hal.element_type<i32> : i32
    %dense_row_major = hal.encoding_type<dense_row_major> : i32
    hal.buffer_view.assert<%arg0 : !hal.buffer_view> message("input0") shape([%0, %1]) type(%element_type_i32) encoding(%dense_row_major)
    %2 = arith.muli %0, %c4 : index
    %3 = arith.muli %2, %1 : index
    %4 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg0 : !hal.buffer_view -> tensor<?x?xi32>{%0, %1} in !stream.resource<external>{%3}
    %5 = stream.timepoint.import on(#hal.device.affinity<@__device_0>) %arg3 : (!hal.fence) => !stream.timepoint
    %6 = hal.buffer_view.dim<%arg1 : !hal.buffer_view>[0] : index
    %7 = hal.buffer_view.dim<%arg1 : !hal.buffer_view>[1] : index
    %element_type_f16 = hal.element_type<f16> : i32
    hal.buffer_view.assert<%arg1 : !hal.buffer_view> message("input1") shape([%6, %7]) type(%element_type_f16) encoding(%dense_row_major)
    %8 = arith.muli %6, %c2 : index
    %9 = arith.muli %8, %7 : index
    %10 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg1 : !hal.buffer_view -> tensor<?x?xf16>{%6, %7} in !stream.resource<external>{%9}
    %11 = arith.muli %1, %c8 : index
    %12 = arith.muli %0, %11 overflow<nsw> : index
    %13 = arith.index_cast %arg2 : i32 to index
    %14 = arith.muli %12, %c2 : index
    %result, %result_timepoint = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) await(%5) => !stream.resource<external>{%14} => !stream.timepoint
    %15 = arith.index_castui %12 : index to i64
    %16 = arith.index_castui %12 : index to i32
    %17 = arith.shrui %15, %c32_i64 : i64
    %18 = arith.trunci %17 : i64 to i32
    %19 = arith.index_castui %11 : index to i64
    %20 = arith.index_castui %11 : index to i32
    %21 = arith.shrui %19, %c32_i64 : i64
    %22 = arith.trunci %21 : i64 to i32
    %23 = arith.index_castui %13 : index to i64
    %24 = arith.index_castui %13 : index to i32
    %25 = arith.shrui %23, %c32_i64 : i64
    %26 = arith.trunci %25 : i64 to i32
    %27 = arith.index_castui %0 : index to i64
    %28 = arith.index_castui %0 : index to i32
    %29 = arith.shrui %27, %c32_i64 : i64
    %30 = arith.trunci %29 : i64 to i32
    %31 = arith.index_castui %1 : index to i64
    %32 = arith.index_castui %1 : index to i32
    %33 = arith.shrui %31, %c32_i64 : i64
    %34 = arith.trunci %33 : i64 to i32
    %35 = arith.index_castui %6 : index to i64
    %36 = arith.index_castui %6 : index to i32
    %37 = arith.shrui %35, %c32_i64 : i64
    %38 = arith.trunci %37 : i64 to i32
    %39 = arith.index_castui %7 : index to i64
    %40 = arith.index_castui %7 : index to i32
    %41 = arith.shrui %39, %c32_i64 : i64
    %42 = arith.trunci %41 : i64 to i32
    %43 = stream.cmd.execute on(#hal.device.affinity<@__device_0>) await(%result_timepoint) => with(%4 as %arg5: !stream.resource<external>{%3}, %10 as %arg6: !stream.resource<external>{%9}, %result as %arg7: !stream.resource<external>{%14}) {
      stream.cmd.dispatch @ct_f16_f16_dispatch_0::@vulkan_spirv_fb::@ct_f16_f16_dispatch_0_elementwise_broadcast_D_f16[%12, %11, %13, %0, %1, %6, %7](%16, %18, %20, %22, %24, %26, %28, %30, %32, %34, %36, %38, %40, %42 : i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32) {
        ro %arg5[%c0 for %3] : !stream.resource<external>{%3},
        ro %arg6[%c0 for %9] : !stream.resource<external>{%9},
        wo %arg7[%c0 for %14] : !stream.resource<external>{%14}
      }
    } => !stream.timepoint
    %44 = arith.muli %0, %c2 : index
    %45 = arith.muli %44, %11 : index
    stream.timepoint.chain_external on(#hal.device.affinity<@__device_0>) %43 => (%arg4 : !hal.fence)
    %46 = stream.tensor.export on(#hal.device.affinity<@__device_0>) %result : tensor<?x?xf16>{%0, %11} in !stream.resource<external>{%45} -> !hal.buffer_view
    util.return %46 : !hal.buffer_view
  }
  hal.executable private @ct_bf16_bf16_dispatch_0 {
    hal.executable.variant public @vulkan_spirv_fb target(<"vulkan-spirv", "vulkan-spirv-fb", {iree_codegen.target_info = #iree_gpu.target<arch = "vp_android_baseline_2022", features = "spirv:v1.3,cap:Shader,cap:Int16,cap:Float16,cap:StorageBuffer16BitAccess,cap:SignedZeroInfNanPreserve,ext:SPV_KHR_16bit_storage,ext:SPV_KHR_float_controls", wgp = <compute = fp32|int32, storage = b32, subgroup = none, subgroup_size_choices = [64], max_workgroup_sizes = [128, 128, 64], max_thread_count_per_workgroup = 128, max_workgroup_memory_bytes = 16384, max_workgroup_counts = [65535, 65535, 65535]>>}>) {
      hal.executable.export public @ct_bf16_bf16_dispatch_0_elementwise_broadcast_D_i16 ordinal(0) layout(#hal.pipeline.layout<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) count(%arg0: !hal.device, %arg1: index, %arg2: index, %arg3: index, %arg4: index, %arg5: index, %arg6: index, %arg7: index) -> (index, index, index) {
        %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice(%arg1, %arg2, %arg3, %arg4, %arg5, %arg6, %arg7)
        hal.return %x, %y, %z : index, index, index
      }
      builtin.module {
        func.func @ct_bf16_bf16_dispatch_0_elementwise_broadcast_D_i16() attributes {translation_info = #iree_codegen.translation_info<pipeline = #iree_gpu.spirv_pipeline<BaseDistribute> workgroup_size = [64, 1, 1]>} {
          %c32_i64 = arith.constant 32 : i64
          %c8 = arith.constant 8 : index
          %c4 = arith.constant 4 : index
          %c15_i32 = arith.constant 15 : i32
          %c8_i32 = arith.constant 8 : i32
          %c0 = arith.constant 0 : index
          %0 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(0) : i32
          %1 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(1) : i32
          %2 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(2) : i32
          %3 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(3) : i32
          %4 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(4) : i32
          %5 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(5) : i32
          %6 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(6) : i32
          %7 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(7) : i32
          %8 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(8) : i32
          %9 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(9) : i32
          %10 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(10) : i32
          %11 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(11) : i32
          %12 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(12) : i32
          %13 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(13) : i32
          %14 = arith.extui %1 : i32 to i64
          %15 = arith.shli %14, %c32_i64 : i64
          %16 = arith.extui %0 : i32 to i64
          %17 = arith.ori %16, %15 : i64
          %18 = arith.index_castui %17 : i64 to index
          %19 = arith.extui %3 : i32 to i64
          %20 = arith.shli %19, %c32_i64 : i64
          %21 = arith.extui %2 : i32 to i64
          %22 = arith.ori %21, %20 : i64
          %23 = arith.index_castui %22 : i64 to index
          %24 = arith.extui %5 : i32 to i64
          %25 = arith.shli %24, %c32_i64 : i64
          %26 = arith.extui %4 : i32 to i64
          %27 = arith.ori %26, %25 : i64
          %28 = arith.index_castui %27 : i64 to index
          %29 = arith.extui %7 : i32 to i64
          %30 = arith.shli %29, %c32_i64 : i64
          %31 = arith.extui %6 : i32 to i64
          %32 = arith.ori %31, %30 : i64
          %33 = arith.index_castui %32 : i64 to index
          %34 = arith.extui %9 : i32 to i64
          %35 = arith.shli %34, %c32_i64 : i64
          %36 = arith.extui %8 : i32 to i64
          %37 = arith.ori %36, %35 : i64
          %38 = arith.index_castui %37 : i64 to index
          %39 = arith.extui %11 : i32 to i64
          %40 = arith.shli %39, %c32_i64 : i64
          %41 = arith.extui %10 : i32 to i64
          %42 = arith.ori %41, %40 : i64
          %43 = arith.index_castui %42 : i64 to index
          %44 = arith.extui %13 : i32 to i64
          %45 = arith.shli %44, %c32_i64 : i64
          %46 = arith.extui %12 : i32 to i64
          %47 = arith.ori %46, %45 : i64
          %48 = arith.index_castui %47 : i64 to index
          %49:6 = util.assume.int 
              %18<umin = 0, umax = 9223372036854775807, udiv = 8>, 
              %23<umin = 0, umax = 72057594037927928, udiv = 8>, 
              %33<umin = 0, umax = 9007199254740991>, 
              %38<umin = 0, umax = 9007199254740991>, 
              %43<umin = 0, umax = 9007199254740991>, 
              %48<umin = 0, umax = 9007199254740991>
            : index, index, index, index, index, index
          %50 = iree_tensor_ext.dispatch.workload.ordinal %49#0, 0 : index
          %51 = iree_tensor_ext.dispatch.workload.ordinal %49#2, 3 : index
          %52 = iree_tensor_ext.dispatch.workload.ordinal %49#3, 4 : index
          %53 = iree_tensor_ext.dispatch.workload.ordinal %49#4, 5 : index
          %54 = iree_tensor_ext.dispatch.workload.ordinal %49#5, 6 : index
          %55 = hal.interface.binding.subspan layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(0) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xi32>>{%51, %52}
          %56 = hal.interface.binding.subspan layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(1) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xi16>>{%53, %54}
          %57 = hal.interface.binding.subspan layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(2) alignment(64) offset(%c0) flags(Indirect) : !iree_tensor_ext.dispatch.tensor<writeonly:tensor<?xi16>>{%50}
          %58 = iree_tensor_ext.dispatch.workload.ordinal %49#1, 1 : index
          %59 = iree_tensor_ext.dispatch.workload.ordinal %28, 2 : index
          %60 = iree_tensor_ext.dispatch.tensor.load %55, offsets = [0, 0], sizes = [%51, %52], strides = [1, 1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xi32>>{%51, %52} -> tensor<?x?xi32>
          %61 = iree_tensor_ext.dispatch.tensor.load %56, offsets = [0, 0], sizes = [%53, %54], strides = [1, 1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xi16>>{%53, %54} -> tensor<?x?xi16>
          %62 = tensor.empty(%50) : tensor<?xi16>
          %63 = linalg.generic {indexing_maps = [affine_map<(d0) -> (d0)>], iterator_types = ["parallel"]} outs(%62 : tensor<?xi16>) attrs =  {lowering_config = #iree_codegen.lowering_config<tile_sizes = [[64], [1]]>} {
          ^bb0(%out: i16):
            %64 = linalg.index 0 : index
            %65 = arith.remsi %64, %58 : index
            %66 = arith.divsi %64, %58 : index
            %67 = arith.divui %65, %59 : index
            %68 = arith.divui %65, %c8 : index
            %69 = arith.remui %65, %c8 : index
            %extracted = tensor.extract %60[%66, %68] : tensor<?x?xi32>
            %70 = arith.muli %69, %c4 : index
            %71 = arith.index_castui %70 : index to i32
            %72 = arith.shrui %extracted, %71 : i32
            %73 = arith.andi %72, %c15_i32 : i32
            %74 = arith.subi %73, %c8_i32 : i32
            %75 = arith.sitofp %74 : i32 to f32
            %extracted_0 = tensor.extract %61[%66, %67] : tensor<?x?xi16>
            %76 = arith.bitcast %extracted_0 : i16 to bf16
            %77 = arith.extf %76 : bf16 to f32
            %78 = arith.mulf %75, %77 : f32
            %79 = arith.truncf %78 : f32 to bf16
            %80 = arith.extf %79 : bf16 to f32
            %81 = arith.truncf %80 : f32 to bf16
            %82 = arith.bitcast %81 : bf16 to i16
            linalg.yield %82 : i16
          } -> tensor<?xi16>
          iree_tensor_ext.dispatch.tensor.store %63, %57, offsets = [0], sizes = [%50], strides = [1] : tensor<?xi16> -> !iree_tensor_ext.dispatch.tensor<writeonly:tensor<?xi16>>{%50}
          return
        }
        iree_codegen.dispatch_config @ct_bf16_bf16_dispatch_0_elementwise_broadcast_D_i16 {
        ^bb0(%arg0: !hal.device, %arg1: index, %arg2: index, %arg3: index, %arg4: index, %arg5: index, %arg6: index, %arg7: index):
          %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice(%arg1, %arg2, %arg3, %arg4, %arg5, %arg6, %arg7)
          iree_codegen.yield %x, %y, %z : index, index, index
        }
      }
    }
  }
  util.func public @ct_bf16_bf16(%arg0: !hal.buffer_view, %arg1: !hal.buffer_view, %arg2: i32, %arg3: !hal.fence, %arg4: !hal.fence) -> !hal.buffer_view attributes {iree.abi.stub, iree.reflection = {iree.abi.declaration = "async func @ct_bf16_bf16(%input0: tensor<?x?xi32>, %input1: tensor<?x?xi16>, %input2: i32) -> (%output0: tensor<?x?xi16>)", iree.abi.model = "coarse-fences"}} {
    %c32_i64 = arith.constant 32 : i64
    %c0 = arith.constant 0 : index
    %c2 = arith.constant 2 : index
    %c4 = arith.constant 4 : index
    %c8 = arith.constant 8 : index
    %0 = hal.buffer_view.dim<%arg0 : !hal.buffer_view>[0] : index
    %1 = hal.buffer_view.dim<%arg0 : !hal.buffer_view>[1] : index
    %element_type_i32 = hal.element_type<i32> : i32
    %dense_row_major = hal.encoding_type<dense_row_major> : i32
    hal.buffer_view.assert<%arg0 : !hal.buffer_view> message("input0") shape([%0, %1]) type(%element_type_i32) encoding(%dense_row_major)
    %2 = arith.muli %0, %c4 : index
    %3 = arith.muli %2, %1 : index
    %4 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg0 : !hal.buffer_view -> tensor<?x?xi32>{%0, %1} in !stream.resource<external>{%3}
    %5 = stream.timepoint.import on(#hal.device.affinity<@__device_0>) %arg3 : (!hal.fence) => !stream.timepoint
    %6 = hal.buffer_view.dim<%arg1 : !hal.buffer_view>[0] : index
    %7 = hal.buffer_view.dim<%arg1 : !hal.buffer_view>[1] : index
    %element_type_i16 = hal.element_type<i16> : i32
    hal.buffer_view.assert<%arg1 : !hal.buffer_view> message("input1") shape([%6, %7]) type(%element_type_i16) encoding(%dense_row_major)
    %8 = arith.muli %6, %c2 : index
    %9 = arith.muli %8, %7 : index
    %10 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg1 : !hal.buffer_view -> tensor<?x?xi16>{%6, %7} in !stream.resource<external>{%9}
    %11 = arith.muli %1, %c8 : index
    %12 = arith.muli %0, %11 overflow<nsw> : index
    %13 = arith.index_cast %arg2 : i32 to index
    %14 = arith.muli %12, %c2 : index
    %result, %result_timepoint = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) await(%5) => !stream.resource<external>{%14} => !stream.timepoint
    %15 = arith.index_castui %12 : index to i64
    %16 = arith.index_castui %12 : index to i32
    %17 = arith.shrui %15, %c32_i64 : i64
    %18 = arith.trunci %17 : i64 to i32
    %19 = arith.index_castui %11 : index to i64
    %20 = arith.index_castui %11 : index to i32
    %21 = arith.shrui %19, %c32_i64 : i64
    %22 = arith.trunci %21 : i64 to i32
    %23 = arith.index_castui %13 : index to i64
    %24 = arith.index_castui %13 : index to i32
    %25 = arith.shrui %23, %c32_i64 : i64
    %26 = arith.trunci %25 : i64 to i32
    %27 = arith.index_castui %0 : index to i64
    %28 = arith.index_castui %0 : index to i32
    %29 = arith.shrui %27, %c32_i64 : i64
    %30 = arith.trunci %29 : i64 to i32
    %31 = arith.index_castui %1 : index to i64
    %32 = arith.index_castui %1 : index to i32
    %33 = arith.shrui %31, %c32_i64 : i64
    %34 = arith.trunci %33 : i64 to i32
    %35 = arith.index_castui %6 : index to i64
    %36 = arith.index_castui %6 : index to i32
    %37 = arith.shrui %35, %c32_i64 : i64
    %38 = arith.trunci %37 : i64 to i32
    %39 = arith.index_castui %7 : index to i64
    %40 = arith.index_castui %7 : index to i32
    %41 = arith.shrui %39, %c32_i64 : i64
    %42 = arith.trunci %41 : i64 to i32
    %43 = stream.cmd.execute on(#hal.device.affinity<@__device_0>) await(%result_timepoint) => with(%4 as %arg5: !stream.resource<external>{%3}, %10 as %arg6: !stream.resource<external>{%9}, %result as %arg7: !stream.resource<external>{%14}) {
      stream.cmd.dispatch @ct_bf16_bf16_dispatch_0::@vulkan_spirv_fb::@ct_bf16_bf16_dispatch_0_elementwise_broadcast_D_i16[%12, %11, %13, %0, %1, %6, %7](%16, %18, %20, %22, %24, %26, %28, %30, %32, %34, %36, %38, %40, %42 : i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32) {
        ro %arg5[%c0 for %3] : !stream.resource<external>{%3},
        ro %arg6[%c0 for %9] : !stream.resource<external>{%9},
        wo %arg7[%c0 for %14] : !stream.resource<external>{%14}
      }
    } => !stream.timepoint
    %44 = arith.muli %0, %c2 : index
    %45 = arith.muli %44, %11 : index
    stream.timepoint.chain_external on(#hal.device.affinity<@__device_0>) %43 => (%arg4 : !hal.fence)
    %46 = stream.tensor.export on(#hal.device.affinity<@__device_0>) %result : tensor<?x?xi16>{%0, %11} in !stream.resource<external>{%45} -> !hal.buffer_view
    util.return %46 : !hal.buffer_view
  }
  hal.executable private @ct_asym_f32_f32_dispatch_0 {
    hal.executable.variant public @vulkan_spirv_fb target(<"vulkan-spirv", "vulkan-spirv-fb", {iree_codegen.target_info = #iree_gpu.target<arch = "vp_android_baseline_2022", features = "spirv:v1.3,cap:Shader,cap:Int16,cap:Float16,cap:StorageBuffer16BitAccess,cap:SignedZeroInfNanPreserve,ext:SPV_KHR_16bit_storage,ext:SPV_KHR_float_controls", wgp = <compute = fp32|int32, storage = b32, subgroup = none, subgroup_size_choices = [64], max_workgroup_sizes = [128, 128, 64], max_thread_count_per_workgroup = 128, max_workgroup_memory_bytes = 16384, max_workgroup_counts = [65535, 65535, 65535]>>}>) {
      hal.executable.export public @ct_asym_f32_f32_dispatch_0_elementwise_broadcast_D_f32 ordinal(0) layout(#hal.pipeline.layout<constants = 18, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) count(%arg0: !hal.device, %arg1: index, %arg2: index, %arg3: index, %arg4: index, %arg5: index, %arg6: index, %arg7: index, %arg8: index, %arg9: index) -> (index, index, index) {
        %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice(%arg1, %arg2, %arg3, %arg4, %arg5, %arg6, %arg7, %arg8, %arg9)
        hal.return %x, %y, %z : index, index, index
      }
      builtin.module {
        func.func @ct_asym_f32_f32_dispatch_0_elementwise_broadcast_D_f32() attributes {translation_info = #iree_codegen.translation_info<pipeline = #iree_gpu.spirv_pipeline<BaseDistribute> workgroup_size = [64, 1, 1]>} {
          %c32_i64 = arith.constant 32 : i64
          %c8 = arith.constant 8 : index
          %c4 = arith.constant 4 : index
          %c15_i32 = arith.constant 15 : i32
          %c8_i32 = arith.constant 8 : i32
          %c0 = arith.constant 0 : index
          %0 = hal.interface.constant.load layout(<constants = 18, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(0) : i32
          %1 = hal.interface.constant.load layout(<constants = 18, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(1) : i32
          %2 = hal.interface.constant.load layout(<constants = 18, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(2) : i32
          %3 = hal.interface.constant.load layout(<constants = 18, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(3) : i32
          %4 = hal.interface.constant.load layout(<constants = 18, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(4) : i32
          %5 = hal.interface.constant.load layout(<constants = 18, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(5) : i32
          %6 = hal.interface.constant.load layout(<constants = 18, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(6) : i32
          %7 = hal.interface.constant.load layout(<constants = 18, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(7) : i32
          %8 = hal.interface.constant.load layout(<constants = 18, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(8) : i32
          %9 = hal.interface.constant.load layout(<constants = 18, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(9) : i32
          %10 = hal.interface.constant.load layout(<constants = 18, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(10) : i32
          %11 = hal.interface.constant.load layout(<constants = 18, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(11) : i32
          %12 = hal.interface.constant.load layout(<constants = 18, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(12) : i32
          %13 = hal.interface.constant.load layout(<constants = 18, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(13) : i32
          %14 = hal.interface.constant.load layout(<constants = 18, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(14) : i32
          %15 = hal.interface.constant.load layout(<constants = 18, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(15) : i32
          %16 = hal.interface.constant.load layout(<constants = 18, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(16) : i32
          %17 = hal.interface.constant.load layout(<constants = 18, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(17) : i32
          %18 = arith.extui %1 : i32 to i64
          %19 = arith.shli %18, %c32_i64 : i64
          %20 = arith.extui %0 : i32 to i64
          %21 = arith.ori %20, %19 : i64
          %22 = arith.index_castui %21 : i64 to index
          %23 = arith.extui %3 : i32 to i64
          %24 = arith.shli %23, %c32_i64 : i64
          %25 = arith.extui %2 : i32 to i64
          %26 = arith.ori %25, %24 : i64
          %27 = arith.index_castui %26 : i64 to index
          %28 = arith.extui %5 : i32 to i64
          %29 = arith.shli %28, %c32_i64 : i64
          %30 = arith.extui %4 : i32 to i64
          %31 = arith.ori %30, %29 : i64
          %32 = arith.index_castui %31 : i64 to index
          %33 = arith.extui %7 : i32 to i64
          %34 = arith.shli %33, %c32_i64 : i64
          %35 = arith.extui %6 : i32 to i64
          %36 = arith.ori %35, %34 : i64
          %37 = arith.index_castui %36 : i64 to index
          %38 = arith.extui %9 : i32 to i64
          %39 = arith.shli %38, %c32_i64 : i64
          %40 = arith.extui %8 : i32 to i64
          %41 = arith.ori %40, %39 : i64
          %42 = arith.index_castui %41 : i64 to index
          %43 = arith.extui %11 : i32 to i64
          %44 = arith.shli %43, %c32_i64 : i64
          %45 = arith.extui %10 : i32 to i64
          %46 = arith.ori %45, %44 : i64
          %47 = arith.index_castui %46 : i64 to index
          %48 = arith.extui %13 : i32 to i64
          %49 = arith.shli %48, %c32_i64 : i64
          %50 = arith.extui %12 : i32 to i64
          %51 = arith.ori %50, %49 : i64
          %52 = arith.index_castui %51 : i64 to index
          %53 = arith.extui %15 : i32 to i64
          %54 = arith.shli %53, %c32_i64 : i64
          %55 = arith.extui %14 : i32 to i64
          %56 = arith.ori %55, %54 : i64
          %57 = arith.index_castui %56 : i64 to index
          %58 = arith.extui %17 : i32 to i64
          %59 = arith.shli %58, %c32_i64 : i64
          %60 = arith.extui %16 : i32 to i64
          %61 = arith.ori %60, %59 : i64
          %62 = arith.index_castui %61 : i64 to index
          %63:8 = util.assume.int 
              %22<umin = 0, umax = 9223372036854775807, udiv = 8>, 
              %27<umin = 0, umax = 72057594037927928, udiv = 8>, 
              %37<umin = 0, umax = 9007199254740991>, 
              %42<umin = 0, umax = 9007199254740991>, 
              %47<umin = 0, umax = 9007199254740991>, 
              %52<umin = 0, umax = 9007199254740991>, 
              %57<umin = 0, umax = 9007199254740991>, 
              %62<umin = 0, umax = 9007199254740991>
            : index, index, index, index, index, index, index, index
          %64 = iree_tensor_ext.dispatch.workload.ordinal %63#0, 0 : index
          %65 = iree_tensor_ext.dispatch.workload.ordinal %63#2, 3 : index
          %66 = iree_tensor_ext.dispatch.workload.ordinal %63#3, 4 : index
          %67 = iree_tensor_ext.dispatch.workload.ordinal %63#4, 5 : index
          %68 = iree_tensor_ext.dispatch.workload.ordinal %63#5, 6 : index
          %69 = iree_tensor_ext.dispatch.workload.ordinal %63#6, 7 : index
          %70 = iree_tensor_ext.dispatch.workload.ordinal %63#7, 8 : index
          %71 = hal.interface.binding.subspan layout(<constants = 18, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(0) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xi32>>{%65, %66}
          %72 = hal.interface.binding.subspan layout(<constants = 18, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(1) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xi32>>{%67, %68}
          %73 = hal.interface.binding.subspan layout(<constants = 18, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(2) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xf32>>{%69, %70}
          %74 = hal.interface.binding.subspan layout(<constants = 18, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(3) alignment(64) offset(%c0) flags(Indirect) : !iree_tensor_ext.dispatch.tensor<writeonly:tensor<?xf32>>{%64}
          %75 = iree_tensor_ext.dispatch.workload.ordinal %63#1, 1 : index
          %76 = iree_tensor_ext.dispatch.workload.ordinal %32, 2 : index
          %77 = iree_tensor_ext.dispatch.tensor.load %71, offsets = [0, 0], sizes = [%65, %66], strides = [1, 1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xi32>>{%65, %66} -> tensor<?x?xi32>
          %78 = iree_tensor_ext.dispatch.tensor.load %72, offsets = [0, 0], sizes = [%67, %68], strides = [1, 1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xi32>>{%67, %68} -> tensor<?x?xi32>
          %79 = iree_tensor_ext.dispatch.tensor.load %73, offsets = [0, 0], sizes = [%69, %70], strides = [1, 1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xf32>>{%69, %70} -> tensor<?x?xf32>
          %80 = tensor.empty(%64) : tensor<?xf32>
          %81 = linalg.generic {indexing_maps = [affine_map<(d0) -> (d0)>], iterator_types = ["parallel"]} outs(%80 : tensor<?xf32>) attrs =  {lowering_config = #iree_codegen.lowering_config<tile_sizes = [[64], [1]]>} {
          ^bb0(%out: f32):
            %82 = linalg.index 0 : index
            %83 = arith.remsi %82, %75 : index
            %84 = arith.divsi %82, %75 : index
            %85 = arith.divui %83, %76 : index
            %86 = arith.divui %83, %c8 : index
            %87 = arith.remui %83, %c8 : index
            %extracted = tensor.extract %77[%84, %86] : tensor<?x?xi32>
            %88 = arith.divui %84, %c8 : index
            %89 = arith.remui %84, %c8 : index
            %90 = arith.muli %89, %c4 : index
            %91 = arith.index_castui %90 : index to i32
            %extracted_0 = tensor.extract %78[%88, %85] : tensor<?x?xi32>
            %92 = arith.muli %87, %c4 : index
            %93 = arith.index_castui %92 : index to i32
            %94 = arith.shrui %extracted, %93 : i32
            %95 = arith.andi %94, %c15_i32 : i32
            %96 = arith.shrui %extracted_0, %91 : i32
            %97 = arith.andi %96, %c15_i32 : i32
            %98 = arith.subi %95, %c8_i32 : i32
            %99 = arith.subi %97, %c8_i32 : i32
            %100 = arith.sitofp %98 : i32 to f32
            %101 = arith.sitofp %99 : i32 to f32
            %102 = arith.subf %100, %101 : f32
            %extracted_1 = tensor.extract %79[%84, %85] : tensor<?x?xf32>
            %103 = arith.mulf %102, %extracted_1 : f32
            linalg.yield %103 : f32
          } -> tensor<?xf32>
          iree_tensor_ext.dispatch.tensor.store %81, %74, offsets = [0], sizes = [%64], strides = [1] : tensor<?xf32> -> !iree_tensor_ext.dispatch.tensor<writeonly:tensor<?xf32>>{%64}
          return
        }
        iree_codegen.dispatch_config @ct_asym_f32_f32_dispatch_0_elementwise_broadcast_D_f32 {
        ^bb0(%arg0: !hal.device, %arg1: index, %arg2: index, %arg3: index, %arg4: index, %arg5: index, %arg6: index, %arg7: index, %arg8: index, %arg9: index):
          %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice(%arg1, %arg2, %arg3, %arg4, %arg5, %arg6, %arg7, %arg8, %arg9)
          iree_codegen.yield %x, %y, %z : index, index, index
        }
      }
    }
  }
  util.func public @ct_asym_f32_f32(%arg0: !hal.buffer_view, %arg1: !hal.buffer_view, %arg2: !hal.buffer_view, %arg3: i32, %arg4: !hal.fence, %arg5: !hal.fence) -> !hal.buffer_view attributes {iree.abi.stub, iree.reflection = {iree.abi.declaration = "async func @ct_asym_f32_f32(%input0: tensor<?x?xi32>, %input1: tensor<?x?xi32>, %input2: tensor<?x?xf32>, %input3: i32) -> (%output0: tensor<?x?xf32>)", iree.abi.model = "coarse-fences"}} {
    %c32_i64 = arith.constant 32 : i64
    %c0 = arith.constant 0 : index
    %c4 = arith.constant 4 : index
    %c8 = arith.constant 8 : index
    %0 = hal.buffer_view.dim<%arg0 : !hal.buffer_view>[0] : index
    %1 = hal.buffer_view.dim<%arg0 : !hal.buffer_view>[1] : index
    %element_type_i32 = hal.element_type<i32> : i32
    %dense_row_major = hal.encoding_type<dense_row_major> : i32
    hal.buffer_view.assert<%arg0 : !hal.buffer_view> message("input0") shape([%0, %1]) type(%element_type_i32) encoding(%dense_row_major)
    %2 = arith.muli %0, %c4 : index
    %3 = arith.muli %2, %1 : index
    %4 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg0 : !hal.buffer_view -> tensor<?x?xi32>{%0, %1} in !stream.resource<external>{%3}
    %5 = stream.timepoint.import on(#hal.device.affinity<@__device_0>) %arg4 : (!hal.fence) => !stream.timepoint
    %6 = hal.buffer_view.dim<%arg1 : !hal.buffer_view>[0] : index
    %7 = hal.buffer_view.dim<%arg1 : !hal.buffer_view>[1] : index
    hal.buffer_view.assert<%arg1 : !hal.buffer_view> message("input1") shape([%6, %7]) type(%element_type_i32) encoding(%dense_row_major)
    %8 = arith.muli %6, %c4 : index
    %9 = arith.muli %8, %7 : index
    %10 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg1 : !hal.buffer_view -> tensor<?x?xi32>{%6, %7} in !stream.resource<external>{%9}
    %11 = hal.buffer_view.dim<%arg2 : !hal.buffer_view>[0] : index
    %12 = hal.buffer_view.dim<%arg2 : !hal.buffer_view>[1] : index
    %element_type_f32 = hal.element_type<f32> : i32
    hal.buffer_view.assert<%arg2 : !hal.buffer_view> message("input2") shape([%11, %12]) type(%element_type_f32) encoding(%dense_row_major)
    %13 = arith.muli %11, %c4 : index
    %14 = arith.muli %13, %12 : index
    %15 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg2 : !hal.buffer_view -> tensor<?x?xf32>{%11, %12} in !stream.resource<external>{%14}
    %16 = arith.muli %1, %c8 : index
    %17 = arith.muli %0, %16 overflow<nsw> : index
    %18 = arith.index_cast %arg3 : i32 to index
    %19 = arith.muli %17, %c4 : index
    %result, %result_timepoint = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) await(%5) => !stream.resource<external>{%19} => !stream.timepoint
    %20 = arith.index_castui %17 : index to i64
    %21 = arith.index_castui %17 : index to i32
    %22 = arith.shrui %20, %c32_i64 : i64
    %23 = arith.trunci %22 : i64 to i32
    %24 = arith.index_castui %16 : index to i64
    %25 = arith.index_castui %16 : index to i32
    %26 = arith.shrui %24, %c32_i64 : i64
    %27 = arith.trunci %26 : i64 to i32
    %28 = arith.index_castui %18 : index to i64
    %29 = arith.index_castui %18 : index to i32
    %30 = arith.shrui %28, %c32_i64 : i64
    %31 = arith.trunci %30 : i64 to i32
    %32 = arith.index_castui %0 : index to i64
    %33 = arith.index_castui %0 : index to i32
    %34 = arith.shrui %32, %c32_i64 : i64
    %35 = arith.trunci %34 : i64 to i32
    %36 = arith.index_castui %1 : index to i64
    %37 = arith.index_castui %1 : index to i32
    %38 = arith.shrui %36, %c32_i64 : i64
    %39 = arith.trunci %38 : i64 to i32
    %40 = arith.index_castui %6 : index to i64
    %41 = arith.index_castui %6 : index to i32
    %42 = arith.shrui %40, %c32_i64 : i64
    %43 = arith.trunci %42 : i64 to i32
    %44 = arith.index_castui %7 : index to i64
    %45 = arith.index_castui %7 : index to i32
    %46 = arith.shrui %44, %c32_i64 : i64
    %47 = arith.trunci %46 : i64 to i32
    %48 = arith.index_castui %11 : index to i64
    %49 = arith.index_castui %11 : index to i32
    %50 = arith.shrui %48, %c32_i64 : i64
    %51 = arith.trunci %50 : i64 to i32
    %52 = arith.index_castui %12 : index to i64
    %53 = arith.index_castui %12 : index to i32
    %54 = arith.shrui %52, %c32_i64 : i64
    %55 = arith.trunci %54 : i64 to i32
    %56 = stream.cmd.execute on(#hal.device.affinity<@__device_0>) await(%result_timepoint) => with(%4 as %arg6: !stream.resource<external>{%3}, %10 as %arg7: !stream.resource<external>{%9}, %15 as %arg8: !stream.resource<external>{%14}, %result as %arg9: !stream.resource<external>{%19}) {
      stream.cmd.dispatch @ct_asym_f32_f32_dispatch_0::@vulkan_spirv_fb::@ct_asym_f32_f32_dispatch_0_elementwise_broadcast_D_f32[%17, %16, %18, %0, %1, %6, %7, %11, %12](%21, %23, %25, %27, %29, %31, %33, %35, %37, %39, %41, %43, %45, %47, %49, %51, %53, %55 : i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32) {
        ro %arg6[%c0 for %3] : !stream.resource<external>{%3},
        ro %arg7[%c0 for %9] : !stream.resource<external>{%9},
        ro %arg8[%c0 for %14] : !stream.resource<external>{%14},
        wo %arg9[%c0 for %19] : !stream.resource<external>{%19}
      }
    } => !stream.timepoint
    %57 = arith.muli %2, %16 : index
    stream.timepoint.chain_external on(#hal.device.affinity<@__device_0>) %56 => (%arg5 : !hal.fence)
    %58 = stream.tensor.export on(#hal.device.affinity<@__device_0>) %result : tensor<?x?xf32>{%0, %16} in !stream.resource<external>{%57} -> !hal.buffer_view
    util.return %58 : !hal.buffer_view
  }
  hal.executable private @ct_asym_f32_f16_dispatch_0 {
    hal.executable.variant public @vulkan_spirv_fb target(<"vulkan-spirv", "vulkan-spirv-fb", {iree_codegen.target_info = #iree_gpu.target<arch = "vp_android_baseline_2022", features = "spirv:v1.3,cap:Shader,cap:Int16,cap:Float16,cap:StorageBuffer16BitAccess,cap:SignedZeroInfNanPreserve,ext:SPV_KHR_16bit_storage,ext:SPV_KHR_float_controls", wgp = <compute = fp32|int32, storage = b32, subgroup = none, subgroup_size_choices = [64], max_workgroup_sizes = [128, 128, 64], max_thread_count_per_workgroup = 128, max_workgroup_memory_bytes = 16384, max_workgroup_counts = [65535, 65535, 65535]>>}>) {
      hal.executable.export public @ct_asym_f32_f16_dispatch_0_elementwise_broadcast_D_f16 ordinal(0) layout(#hal.pipeline.layout<constants = 18, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) count(%arg0: !hal.device, %arg1: index, %arg2: index, %arg3: index, %arg4: index, %arg5: index, %arg6: index, %arg7: index, %arg8: index, %arg9: index) -> (index, index, index) {
        %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice(%arg1, %arg2, %arg3, %arg4, %arg5, %arg6, %arg7, %arg8, %arg9)
        hal.return %x, %y, %z : index, index, index
      }
      builtin.module {
        func.func @ct_asym_f32_f16_dispatch_0_elementwise_broadcast_D_f16() attributes {translation_info = #iree_codegen.translation_info<pipeline = #iree_gpu.spirv_pipeline<BaseDistribute> workgroup_size = [64, 1, 1]>} {
          %c32_i64 = arith.constant 32 : i64
          %c8 = arith.constant 8 : index
          %c4 = arith.constant 4 : index
          %c15_i32 = arith.constant 15 : i32
          %c8_i32 = arith.constant 8 : i32
          %c0 = arith.constant 0 : index
          %0 = hal.interface.constant.load layout(<constants = 18, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(0) : i32
          %1 = hal.interface.constant.load layout(<constants = 18, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(1) : i32
          %2 = hal.interface.constant.load layout(<constants = 18, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(2) : i32
          %3 = hal.interface.constant.load layout(<constants = 18, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(3) : i32
          %4 = hal.interface.constant.load layout(<constants = 18, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(4) : i32
          %5 = hal.interface.constant.load layout(<constants = 18, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(5) : i32
          %6 = hal.interface.constant.load layout(<constants = 18, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(6) : i32
          %7 = hal.interface.constant.load layout(<constants = 18, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(7) : i32
          %8 = hal.interface.constant.load layout(<constants = 18, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(8) : i32
          %9 = hal.interface.constant.load layout(<constants = 18, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(9) : i32
          %10 = hal.interface.constant.load layout(<constants = 18, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(10) : i32
          %11 = hal.interface.constant.load layout(<constants = 18, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(11) : i32
          %12 = hal.interface.constant.load layout(<constants = 18, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(12) : i32
          %13 = hal.interface.constant.load layout(<constants = 18, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(13) : i32
          %14 = hal.interface.constant.load layout(<constants = 18, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(14) : i32
          %15 = hal.interface.constant.load layout(<constants = 18, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(15) : i32
          %16 = hal.interface.constant.load layout(<constants = 18, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(16) : i32
          %17 = hal.interface.constant.load layout(<constants = 18, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(17) : i32
          %18 = arith.extui %1 : i32 to i64
          %19 = arith.shli %18, %c32_i64 : i64
          %20 = arith.extui %0 : i32 to i64
          %21 = arith.ori %20, %19 : i64
          %22 = arith.index_castui %21 : i64 to index
          %23 = arith.extui %3 : i32 to i64
          %24 = arith.shli %23, %c32_i64 : i64
          %25 = arith.extui %2 : i32 to i64
          %26 = arith.ori %25, %24 : i64
          %27 = arith.index_castui %26 : i64 to index
          %28 = arith.extui %5 : i32 to i64
          %29 = arith.shli %28, %c32_i64 : i64
          %30 = arith.extui %4 : i32 to i64
          %31 = arith.ori %30, %29 : i64
          %32 = arith.index_castui %31 : i64 to index
          %33 = arith.extui %7 : i32 to i64
          %34 = arith.shli %33, %c32_i64 : i64
          %35 = arith.extui %6 : i32 to i64
          %36 = arith.ori %35, %34 : i64
          %37 = arith.index_castui %36 : i64 to index
          %38 = arith.extui %9 : i32 to i64
          %39 = arith.shli %38, %c32_i64 : i64
          %40 = arith.extui %8 : i32 to i64
          %41 = arith.ori %40, %39 : i64
          %42 = arith.index_castui %41 : i64 to index
          %43 = arith.extui %11 : i32 to i64
          %44 = arith.shli %43, %c32_i64 : i64
          %45 = arith.extui %10 : i32 to i64
          %46 = arith.ori %45, %44 : i64
          %47 = arith.index_castui %46 : i64 to index
          %48 = arith.extui %13 : i32 to i64
          %49 = arith.shli %48, %c32_i64 : i64
          %50 = arith.extui %12 : i32 to i64
          %51 = arith.ori %50, %49 : i64
          %52 = arith.index_castui %51 : i64 to index
          %53 = arith.extui %15 : i32 to i64
          %54 = arith.shli %53, %c32_i64 : i64
          %55 = arith.extui %14 : i32 to i64
          %56 = arith.ori %55, %54 : i64
          %57 = arith.index_castui %56 : i64 to index
          %58 = arith.extui %17 : i32 to i64
          %59 = arith.shli %58, %c32_i64 : i64
          %60 = arith.extui %16 : i32 to i64
          %61 = arith.ori %60, %59 : i64
          %62 = arith.index_castui %61 : i64 to index
          %63:8 = util.assume.int 
              %22<umin = 0, umax = 9223372036854775807, udiv = 8>, 
              %27<umin = 0, umax = 72057594037927928, udiv = 8>, 
              %37<umin = 0, umax = 9007199254740991>, 
              %42<umin = 0, umax = 9007199254740991>, 
              %47<umin = 0, umax = 9007199254740991>, 
              %52<umin = 0, umax = 9007199254740991>, 
              %57<umin = 0, umax = 9007199254740991>, 
              %62<umin = 0, umax = 9007199254740991>
            : index, index, index, index, index, index, index, index
          %64 = iree_tensor_ext.dispatch.workload.ordinal %63#0, 0 : index
          %65 = iree_tensor_ext.dispatch.workload.ordinal %63#2, 3 : index
          %66 = iree_tensor_ext.dispatch.workload.ordinal %63#3, 4 : index
          %67 = iree_tensor_ext.dispatch.workload.ordinal %63#4, 5 : index
          %68 = iree_tensor_ext.dispatch.workload.ordinal %63#5, 6 : index
          %69 = iree_tensor_ext.dispatch.workload.ordinal %63#6, 7 : index
          %70 = iree_tensor_ext.dispatch.workload.ordinal %63#7, 8 : index
          %71 = hal.interface.binding.subspan layout(<constants = 18, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(0) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xi32>>{%65, %66}
          %72 = hal.interface.binding.subspan layout(<constants = 18, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(1) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xi32>>{%67, %68}
          %73 = hal.interface.binding.subspan layout(<constants = 18, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(2) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xf32>>{%69, %70}
          %74 = hal.interface.binding.subspan layout(<constants = 18, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(3) alignment(64) offset(%c0) flags(Indirect) : !iree_tensor_ext.dispatch.tensor<writeonly:tensor<?xf16>>{%64}
          %75 = iree_tensor_ext.dispatch.workload.ordinal %63#1, 1 : index
          %76 = iree_tensor_ext.dispatch.workload.ordinal %32, 2 : index
          %77 = iree_tensor_ext.dispatch.tensor.load %71, offsets = [0, 0], sizes = [%65, %66], strides = [1, 1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xi32>>{%65, %66} -> tensor<?x?xi32>
          %78 = iree_tensor_ext.dispatch.tensor.load %72, offsets = [0, 0], sizes = [%67, %68], strides = [1, 1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xi32>>{%67, %68} -> tensor<?x?xi32>
          %79 = iree_tensor_ext.dispatch.tensor.load %73, offsets = [0, 0], sizes = [%69, %70], strides = [1, 1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xf32>>{%69, %70} -> tensor<?x?xf32>
          %80 = tensor.empty(%64) : tensor<?xf16>
          %81 = linalg.generic {indexing_maps = [affine_map<(d0) -> (d0)>], iterator_types = ["parallel"]} outs(%80 : tensor<?xf16>) attrs =  {lowering_config = #iree_codegen.lowering_config<tile_sizes = [[64], [1]]>} {
          ^bb0(%out: f16):
            %82 = linalg.index 0 : index
            %83 = arith.remsi %82, %75 : index
            %84 = arith.divsi %82, %75 : index
            %85 = arith.divui %83, %76 : index
            %86 = arith.divui %83, %c8 : index
            %87 = arith.remui %83, %c8 : index
            %extracted = tensor.extract %77[%84, %86] : tensor<?x?xi32>
            %88 = arith.divui %84, %c8 : index
            %89 = arith.remui %84, %c8 : index
            %90 = arith.muli %89, %c4 : index
            %91 = arith.index_castui %90 : index to i32
            %extracted_0 = tensor.extract %78[%88, %85] : tensor<?x?xi32>
            %92 = arith.muli %87, %c4 : index
            %93 = arith.index_castui %92 : index to i32
            %94 = arith.shrui %extracted, %93 : i32
            %95 = arith.andi %94, %c15_i32 : i32
            %96 = arith.shrui %extracted_0, %91 : i32
            %97 = arith.andi %96, %c15_i32 : i32
            %98 = arith.subi %95, %c8_i32 : i32
            %99 = arith.subi %97, %c8_i32 : i32
            %100 = arith.sitofp %98 : i32 to f32
            %101 = arith.sitofp %99 : i32 to f32
            %102 = arith.subf %100, %101 : f32
            %extracted_1 = tensor.extract %79[%84, %85] : tensor<?x?xf32>
            %103 = arith.mulf %102, %extracted_1 : f32
            %104 = arith.truncf %103 : f32 to f16
            linalg.yield %104 : f16
          } -> tensor<?xf16>
          iree_tensor_ext.dispatch.tensor.store %81, %74, offsets = [0], sizes = [%64], strides = [1] : tensor<?xf16> -> !iree_tensor_ext.dispatch.tensor<writeonly:tensor<?xf16>>{%64}
          return
        }
        iree_codegen.dispatch_config @ct_asym_f32_f16_dispatch_0_elementwise_broadcast_D_f16 {
        ^bb0(%arg0: !hal.device, %arg1: index, %arg2: index, %arg3: index, %arg4: index, %arg5: index, %arg6: index, %arg7: index, %arg8: index, %arg9: index):
          %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice(%arg1, %arg2, %arg3, %arg4, %arg5, %arg6, %arg7, %arg8, %arg9)
          iree_codegen.yield %x, %y, %z : index, index, index
        }
      }
    }
  }
  util.func public @ct_asym_f32_f16(%arg0: !hal.buffer_view, %arg1: !hal.buffer_view, %arg2: !hal.buffer_view, %arg3: i32, %arg4: !hal.fence, %arg5: !hal.fence) -> !hal.buffer_view attributes {iree.abi.stub, iree.reflection = {iree.abi.declaration = "async func @ct_asym_f32_f16(%input0: tensor<?x?xi32>, %input1: tensor<?x?xi32>, %input2: tensor<?x?xf32>, %input3: i32) -> (%output0: tensor<?x?xf16>)", iree.abi.model = "coarse-fences"}} {
    %c32_i64 = arith.constant 32 : i64
    %c0 = arith.constant 0 : index
    %c2 = arith.constant 2 : index
    %c4 = arith.constant 4 : index
    %c8 = arith.constant 8 : index
    %0 = hal.buffer_view.dim<%arg0 : !hal.buffer_view>[0] : index
    %1 = hal.buffer_view.dim<%arg0 : !hal.buffer_view>[1] : index
    %element_type_i32 = hal.element_type<i32> : i32
    %dense_row_major = hal.encoding_type<dense_row_major> : i32
    hal.buffer_view.assert<%arg0 : !hal.buffer_view> message("input0") shape([%0, %1]) type(%element_type_i32) encoding(%dense_row_major)
    %2 = arith.muli %0, %c4 : index
    %3 = arith.muli %2, %1 : index
    %4 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg0 : !hal.buffer_view -> tensor<?x?xi32>{%0, %1} in !stream.resource<external>{%3}
    %5 = stream.timepoint.import on(#hal.device.affinity<@__device_0>) %arg4 : (!hal.fence) => !stream.timepoint
    %6 = hal.buffer_view.dim<%arg1 : !hal.buffer_view>[0] : index
    %7 = hal.buffer_view.dim<%arg1 : !hal.buffer_view>[1] : index
    hal.buffer_view.assert<%arg1 : !hal.buffer_view> message("input1") shape([%6, %7]) type(%element_type_i32) encoding(%dense_row_major)
    %8 = arith.muli %6, %c4 : index
    %9 = arith.muli %8, %7 : index
    %10 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg1 : !hal.buffer_view -> tensor<?x?xi32>{%6, %7} in !stream.resource<external>{%9}
    %11 = hal.buffer_view.dim<%arg2 : !hal.buffer_view>[0] : index
    %12 = hal.buffer_view.dim<%arg2 : !hal.buffer_view>[1] : index
    %element_type_f32 = hal.element_type<f32> : i32
    hal.buffer_view.assert<%arg2 : !hal.buffer_view> message("input2") shape([%11, %12]) type(%element_type_f32) encoding(%dense_row_major)
    %13 = arith.muli %11, %c4 : index
    %14 = arith.muli %13, %12 : index
    %15 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg2 : !hal.buffer_view -> tensor<?x?xf32>{%11, %12} in !stream.resource<external>{%14}
    %16 = arith.muli %1, %c8 : index
    %17 = arith.muli %0, %16 overflow<nsw> : index
    %18 = arith.index_cast %arg3 : i32 to index
    %19 = arith.muli %17, %c2 : index
    %result, %result_timepoint = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) await(%5) => !stream.resource<external>{%19} => !stream.timepoint
    %20 = arith.index_castui %17 : index to i64
    %21 = arith.index_castui %17 : index to i32
    %22 = arith.shrui %20, %c32_i64 : i64
    %23 = arith.trunci %22 : i64 to i32
    %24 = arith.index_castui %16 : index to i64
    %25 = arith.index_castui %16 : index to i32
    %26 = arith.shrui %24, %c32_i64 : i64
    %27 = arith.trunci %26 : i64 to i32
    %28 = arith.index_castui %18 : index to i64
    %29 = arith.index_castui %18 : index to i32
    %30 = arith.shrui %28, %c32_i64 : i64
    %31 = arith.trunci %30 : i64 to i32
    %32 = arith.index_castui %0 : index to i64
    %33 = arith.index_castui %0 : index to i32
    %34 = arith.shrui %32, %c32_i64 : i64
    %35 = arith.trunci %34 : i64 to i32
    %36 = arith.index_castui %1 : index to i64
    %37 = arith.index_castui %1 : index to i32
    %38 = arith.shrui %36, %c32_i64 : i64
    %39 = arith.trunci %38 : i64 to i32
    %40 = arith.index_castui %6 : index to i64
    %41 = arith.index_castui %6 : index to i32
    %42 = arith.shrui %40, %c32_i64 : i64
    %43 = arith.trunci %42 : i64 to i32
    %44 = arith.index_castui %7 : index to i64
    %45 = arith.index_castui %7 : index to i32
    %46 = arith.shrui %44, %c32_i64 : i64
    %47 = arith.trunci %46 : i64 to i32
    %48 = arith.index_castui %11 : index to i64
    %49 = arith.index_castui %11 : index to i32
    %50 = arith.shrui %48, %c32_i64 : i64
    %51 = arith.trunci %50 : i64 to i32
    %52 = arith.index_castui %12 : index to i64
    %53 = arith.index_castui %12 : index to i32
    %54 = arith.shrui %52, %c32_i64 : i64
    %55 = arith.trunci %54 : i64 to i32
    %56 = stream.cmd.execute on(#hal.device.affinity<@__device_0>) await(%result_timepoint) => with(%4 as %arg6: !stream.resource<external>{%3}, %10 as %arg7: !stream.resource<external>{%9}, %15 as %arg8: !stream.resource<external>{%14}, %result as %arg9: !stream.resource<external>{%19}) {
      stream.cmd.dispatch @ct_asym_f32_f16_dispatch_0::@vulkan_spirv_fb::@ct_asym_f32_f16_dispatch_0_elementwise_broadcast_D_f16[%17, %16, %18, %0, %1, %6, %7, %11, %12](%21, %23, %25, %27, %29, %31, %33, %35, %37, %39, %41, %43, %45, %47, %49, %51, %53, %55 : i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32) {
        ro %arg6[%c0 for %3] : !stream.resource<external>{%3},
        ro %arg7[%c0 for %9] : !stream.resource<external>{%9},
        ro %arg8[%c0 for %14] : !stream.resource<external>{%14},
        wo %arg9[%c0 for %19] : !stream.resource<external>{%19}
      }
    } => !stream.timepoint
    %57 = arith.muli %0, %c2 : index
    %58 = arith.muli %57, %16 : index
    stream.timepoint.chain_external on(#hal.device.affinity<@__device_0>) %56 => (%arg5 : !hal.fence)
    %59 = stream.tensor.export on(#hal.device.affinity<@__device_0>) %result : tensor<?x?xf16>{%0, %16} in !stream.resource<external>{%58} -> !hal.buffer_view
    util.return %59 : !hal.buffer_view
  }
  hal.executable private @ct_asym_f32_bf16_dispatch_0 {
    hal.executable.variant public @vulkan_spirv_fb target(<"vulkan-spirv", "vulkan-spirv-fb", {iree_codegen.target_info = #iree_gpu.target<arch = "vp_android_baseline_2022", features = "spirv:v1.3,cap:Shader,cap:Int16,cap:Float16,cap:StorageBuffer16BitAccess,cap:SignedZeroInfNanPreserve,ext:SPV_KHR_16bit_storage,ext:SPV_KHR_float_controls", wgp = <compute = fp32|int32, storage = b32, subgroup = none, subgroup_size_choices = [64], max_workgroup_sizes = [128, 128, 64], max_thread_count_per_workgroup = 128, max_workgroup_memory_bytes = 16384, max_workgroup_counts = [65535, 65535, 65535]>>}>) {
      hal.executable.export public @ct_asym_f32_bf16_dispatch_0_elementwise_broadcast_D_i16 ordinal(0) layout(#hal.pipeline.layout<constants = 18, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) count(%arg0: !hal.device, %arg1: index, %arg2: index, %arg3: index, %arg4: index, %arg5: index, %arg6: index, %arg7: index, %arg8: index, %arg9: index) -> (index, index, index) {
        %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice(%arg1, %arg2, %arg3, %arg4, %arg5, %arg6, %arg7, %arg8, %arg9)
        hal.return %x, %y, %z : index, index, index
      }
      builtin.module {
        func.func @ct_asym_f32_bf16_dispatch_0_elementwise_broadcast_D_i16() attributes {translation_info = #iree_codegen.translation_info<pipeline = #iree_gpu.spirv_pipeline<BaseDistribute> workgroup_size = [64, 1, 1]>} {
          %c32_i64 = arith.constant 32 : i64
          %c8 = arith.constant 8 : index
          %c4 = arith.constant 4 : index
          %c15_i32 = arith.constant 15 : i32
          %c8_i32 = arith.constant 8 : i32
          %c0 = arith.constant 0 : index
          %0 = hal.interface.constant.load layout(<constants = 18, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(0) : i32
          %1 = hal.interface.constant.load layout(<constants = 18, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(1) : i32
          %2 = hal.interface.constant.load layout(<constants = 18, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(2) : i32
          %3 = hal.interface.constant.load layout(<constants = 18, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(3) : i32
          %4 = hal.interface.constant.load layout(<constants = 18, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(4) : i32
          %5 = hal.interface.constant.load layout(<constants = 18, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(5) : i32
          %6 = hal.interface.constant.load layout(<constants = 18, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(6) : i32
          %7 = hal.interface.constant.load layout(<constants = 18, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(7) : i32
          %8 = hal.interface.constant.load layout(<constants = 18, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(8) : i32
          %9 = hal.interface.constant.load layout(<constants = 18, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(9) : i32
          %10 = hal.interface.constant.load layout(<constants = 18, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(10) : i32
          %11 = hal.interface.constant.load layout(<constants = 18, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(11) : i32
          %12 = hal.interface.constant.load layout(<constants = 18, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(12) : i32
          %13 = hal.interface.constant.load layout(<constants = 18, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(13) : i32
          %14 = hal.interface.constant.load layout(<constants = 18, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(14) : i32
          %15 = hal.interface.constant.load layout(<constants = 18, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(15) : i32
          %16 = hal.interface.constant.load layout(<constants = 18, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(16) : i32
          %17 = hal.interface.constant.load layout(<constants = 18, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(17) : i32
          %18 = arith.extui %1 : i32 to i64
          %19 = arith.shli %18, %c32_i64 : i64
          %20 = arith.extui %0 : i32 to i64
          %21 = arith.ori %20, %19 : i64
          %22 = arith.index_castui %21 : i64 to index
          %23 = arith.extui %3 : i32 to i64
          %24 = arith.shli %23, %c32_i64 : i64
          %25 = arith.extui %2 : i32 to i64
          %26 = arith.ori %25, %24 : i64
          %27 = arith.index_castui %26 : i64 to index
          %28 = arith.extui %5 : i32 to i64
          %29 = arith.shli %28, %c32_i64 : i64
          %30 = arith.extui %4 : i32 to i64
          %31 = arith.ori %30, %29 : i64
          %32 = arith.index_castui %31 : i64 to index
          %33 = arith.extui %7 : i32 to i64
          %34 = arith.shli %33, %c32_i64 : i64
          %35 = arith.extui %6 : i32 to i64
          %36 = arith.ori %35, %34 : i64
          %37 = arith.index_castui %36 : i64 to index
          %38 = arith.extui %9 : i32 to i64
          %39 = arith.shli %38, %c32_i64 : i64
          %40 = arith.extui %8 : i32 to i64
          %41 = arith.ori %40, %39 : i64
          %42 = arith.index_castui %41 : i64 to index
          %43 = arith.extui %11 : i32 to i64
          %44 = arith.shli %43, %c32_i64 : i64
          %45 = arith.extui %10 : i32 to i64
          %46 = arith.ori %45, %44 : i64
          %47 = arith.index_castui %46 : i64 to index
          %48 = arith.extui %13 : i32 to i64
          %49 = arith.shli %48, %c32_i64 : i64
          %50 = arith.extui %12 : i32 to i64
          %51 = arith.ori %50, %49 : i64
          %52 = arith.index_castui %51 : i64 to index
          %53 = arith.extui %15 : i32 to i64
          %54 = arith.shli %53, %c32_i64 : i64
          %55 = arith.extui %14 : i32 to i64
          %56 = arith.ori %55, %54 : i64
          %57 = arith.index_castui %56 : i64 to index
          %58 = arith.extui %17 : i32 to i64
          %59 = arith.shli %58, %c32_i64 : i64
          %60 = arith.extui %16 : i32 to i64
          %61 = arith.ori %60, %59 : i64
          %62 = arith.index_castui %61 : i64 to index
          %63:8 = util.assume.int 
              %22<umin = 0, umax = 9223372036854775807, udiv = 8>, 
              %27<umin = 0, umax = 72057594037927928, udiv = 8>, 
              %37<umin = 0, umax = 9007199254740991>, 
              %42<umin = 0, umax = 9007199254740991>, 
              %47<umin = 0, umax = 9007199254740991>, 
              %52<umin = 0, umax = 9007199254740991>, 
              %57<umin = 0, umax = 9007199254740991>, 
              %62<umin = 0, umax = 9007199254740991>
            : index, index, index, index, index, index, index, index
          %64 = iree_tensor_ext.dispatch.workload.ordinal %63#0, 0 : index
          %65 = iree_tensor_ext.dispatch.workload.ordinal %63#2, 3 : index
          %66 = iree_tensor_ext.dispatch.workload.ordinal %63#3, 4 : index
          %67 = iree_tensor_ext.dispatch.workload.ordinal %63#4, 5 : index
          %68 = iree_tensor_ext.dispatch.workload.ordinal %63#5, 6 : index
          %69 = iree_tensor_ext.dispatch.workload.ordinal %63#6, 7 : index
          %70 = iree_tensor_ext.dispatch.workload.ordinal %63#7, 8 : index
          %71 = hal.interface.binding.subspan layout(<constants = 18, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(0) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xi32>>{%65, %66}
          %72 = hal.interface.binding.subspan layout(<constants = 18, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(1) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xi32>>{%67, %68}
          %73 = hal.interface.binding.subspan layout(<constants = 18, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(2) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xf32>>{%69, %70}
          %74 = hal.interface.binding.subspan layout(<constants = 18, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(3) alignment(64) offset(%c0) flags(Indirect) : !iree_tensor_ext.dispatch.tensor<writeonly:tensor<?xi16>>{%64}
          %75 = iree_tensor_ext.dispatch.workload.ordinal %63#1, 1 : index
          %76 = iree_tensor_ext.dispatch.workload.ordinal %32, 2 : index
          %77 = iree_tensor_ext.dispatch.tensor.load %71, offsets = [0, 0], sizes = [%65, %66], strides = [1, 1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xi32>>{%65, %66} -> tensor<?x?xi32>
          %78 = iree_tensor_ext.dispatch.tensor.load %72, offsets = [0, 0], sizes = [%67, %68], strides = [1, 1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xi32>>{%67, %68} -> tensor<?x?xi32>
          %79 = iree_tensor_ext.dispatch.tensor.load %73, offsets = [0, 0], sizes = [%69, %70], strides = [1, 1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xf32>>{%69, %70} -> tensor<?x?xf32>
          %80 = tensor.empty(%64) : tensor<?xi16>
          %81 = linalg.generic {indexing_maps = [affine_map<(d0) -> (d0)>], iterator_types = ["parallel"]} outs(%80 : tensor<?xi16>) attrs =  {lowering_config = #iree_codegen.lowering_config<tile_sizes = [[64], [1]]>} {
          ^bb0(%out: i16):
            %82 = linalg.index 0 : index
            %83 = arith.remsi %82, %75 : index
            %84 = arith.divsi %82, %75 : index
            %85 = arith.divui %83, %76 : index
            %86 = arith.divui %83, %c8 : index
            %87 = arith.remui %83, %c8 : index
            %extracted = tensor.extract %77[%84, %86] : tensor<?x?xi32>
            %88 = arith.divui %84, %c8 : index
            %89 = arith.remui %84, %c8 : index
            %90 = arith.muli %89, %c4 : index
            %91 = arith.index_castui %90 : index to i32
            %extracted_0 = tensor.extract %78[%88, %85] : tensor<?x?xi32>
            %92 = arith.muli %87, %c4 : index
            %93 = arith.index_castui %92 : index to i32
            %94 = arith.shrui %extracted, %93 : i32
            %95 = arith.andi %94, %c15_i32 : i32
            %96 = arith.shrui %extracted_0, %91 : i32
            %97 = arith.andi %96, %c15_i32 : i32
            %98 = arith.subi %95, %c8_i32 : i32
            %99 = arith.subi %97, %c8_i32 : i32
            %100 = arith.sitofp %98 : i32 to f32
            %101 = arith.sitofp %99 : i32 to f32
            %102 = arith.subf %100, %101 : f32
            %extracted_1 = tensor.extract %79[%84, %85] : tensor<?x?xf32>
            %103 = arith.mulf %102, %extracted_1 : f32
            %104 = arith.truncf %103 : f32 to bf16
            %105 = arith.bitcast %104 : bf16 to i16
            linalg.yield %105 : i16
          } -> tensor<?xi16>
          iree_tensor_ext.dispatch.tensor.store %81, %74, offsets = [0], sizes = [%64], strides = [1] : tensor<?xi16> -> !iree_tensor_ext.dispatch.tensor<writeonly:tensor<?xi16>>{%64}
          return
        }
        iree_codegen.dispatch_config @ct_asym_f32_bf16_dispatch_0_elementwise_broadcast_D_i16 {
        ^bb0(%arg0: !hal.device, %arg1: index, %arg2: index, %arg3: index, %arg4: index, %arg5: index, %arg6: index, %arg7: index, %arg8: index, %arg9: index):
          %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice(%arg1, %arg2, %arg3, %arg4, %arg5, %arg6, %arg7, %arg8, %arg9)
          iree_codegen.yield %x, %y, %z : index, index, index
        }
      }
    }
  }
  util.func public @ct_asym_f32_bf16(%arg0: !hal.buffer_view, %arg1: !hal.buffer_view, %arg2: !hal.buffer_view, %arg3: i32, %arg4: !hal.fence, %arg5: !hal.fence) -> !hal.buffer_view attributes {iree.abi.stub, iree.reflection = {iree.abi.declaration = "async func @ct_asym_f32_bf16(%input0: tensor<?x?xi32>, %input1: tensor<?x?xi32>, %input2: tensor<?x?xf32>, %input3: i32) -> (%output0: tensor<?x?xi16>)", iree.abi.model = "coarse-fences"}} {
    %c32_i64 = arith.constant 32 : i64
    %c0 = arith.constant 0 : index
    %c2 = arith.constant 2 : index
    %c4 = arith.constant 4 : index
    %c8 = arith.constant 8 : index
    %0 = hal.buffer_view.dim<%arg0 : !hal.buffer_view>[0] : index
    %1 = hal.buffer_view.dim<%arg0 : !hal.buffer_view>[1] : index
    %element_type_i32 = hal.element_type<i32> : i32
    %dense_row_major = hal.encoding_type<dense_row_major> : i32
    hal.buffer_view.assert<%arg0 : !hal.buffer_view> message("input0") shape([%0, %1]) type(%element_type_i32) encoding(%dense_row_major)
    %2 = arith.muli %0, %c4 : index
    %3 = arith.muli %2, %1 : index
    %4 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg0 : !hal.buffer_view -> tensor<?x?xi32>{%0, %1} in !stream.resource<external>{%3}
    %5 = stream.timepoint.import on(#hal.device.affinity<@__device_0>) %arg4 : (!hal.fence) => !stream.timepoint
    %6 = hal.buffer_view.dim<%arg1 : !hal.buffer_view>[0] : index
    %7 = hal.buffer_view.dim<%arg1 : !hal.buffer_view>[1] : index
    hal.buffer_view.assert<%arg1 : !hal.buffer_view> message("input1") shape([%6, %7]) type(%element_type_i32) encoding(%dense_row_major)
    %8 = arith.muli %6, %c4 : index
    %9 = arith.muli %8, %7 : index
    %10 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg1 : !hal.buffer_view -> tensor<?x?xi32>{%6, %7} in !stream.resource<external>{%9}
    %11 = hal.buffer_view.dim<%arg2 : !hal.buffer_view>[0] : index
    %12 = hal.buffer_view.dim<%arg2 : !hal.buffer_view>[1] : index
    %element_type_f32 = hal.element_type<f32> : i32
    hal.buffer_view.assert<%arg2 : !hal.buffer_view> message("input2") shape([%11, %12]) type(%element_type_f32) encoding(%dense_row_major)
    %13 = arith.muli %11, %c4 : index
    %14 = arith.muli %13, %12 : index
    %15 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg2 : !hal.buffer_view -> tensor<?x?xf32>{%11, %12} in !stream.resource<external>{%14}
    %16 = arith.muli %1, %c8 : index
    %17 = arith.muli %0, %16 overflow<nsw> : index
    %18 = arith.index_cast %arg3 : i32 to index
    %19 = arith.muli %17, %c2 : index
    %result, %result_timepoint = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) await(%5) => !stream.resource<external>{%19} => !stream.timepoint
    %20 = arith.index_castui %17 : index to i64
    %21 = arith.index_castui %17 : index to i32
    %22 = arith.shrui %20, %c32_i64 : i64
    %23 = arith.trunci %22 : i64 to i32
    %24 = arith.index_castui %16 : index to i64
    %25 = arith.index_castui %16 : index to i32
    %26 = arith.shrui %24, %c32_i64 : i64
    %27 = arith.trunci %26 : i64 to i32
    %28 = arith.index_castui %18 : index to i64
    %29 = arith.index_castui %18 : index to i32
    %30 = arith.shrui %28, %c32_i64 : i64
    %31 = arith.trunci %30 : i64 to i32
    %32 = arith.index_castui %0 : index to i64
    %33 = arith.index_castui %0 : index to i32
    %34 = arith.shrui %32, %c32_i64 : i64
    %35 = arith.trunci %34 : i64 to i32
    %36 = arith.index_castui %1 : index to i64
    %37 = arith.index_castui %1 : index to i32
    %38 = arith.shrui %36, %c32_i64 : i64
    %39 = arith.trunci %38 : i64 to i32
    %40 = arith.index_castui %6 : index to i64
    %41 = arith.index_castui %6 : index to i32
    %42 = arith.shrui %40, %c32_i64 : i64
    %43 = arith.trunci %42 : i64 to i32
    %44 = arith.index_castui %7 : index to i64
    %45 = arith.index_castui %7 : index to i32
    %46 = arith.shrui %44, %c32_i64 : i64
    %47 = arith.trunci %46 : i64 to i32
    %48 = arith.index_castui %11 : index to i64
    %49 = arith.index_castui %11 : index to i32
    %50 = arith.shrui %48, %c32_i64 : i64
    %51 = arith.trunci %50 : i64 to i32
    %52 = arith.index_castui %12 : index to i64
    %53 = arith.index_castui %12 : index to i32
    %54 = arith.shrui %52, %c32_i64 : i64
    %55 = arith.trunci %54 : i64 to i32
    %56 = stream.cmd.execute on(#hal.device.affinity<@__device_0>) await(%result_timepoint) => with(%4 as %arg6: !stream.resource<external>{%3}, %10 as %arg7: !stream.resource<external>{%9}, %15 as %arg8: !stream.resource<external>{%14}, %result as %arg9: !stream.resource<external>{%19}) {
      stream.cmd.dispatch @ct_asym_f32_bf16_dispatch_0::@vulkan_spirv_fb::@ct_asym_f32_bf16_dispatch_0_elementwise_broadcast_D_i16[%17, %16, %18, %0, %1, %6, %7, %11, %12](%21, %23, %25, %27, %29, %31, %33, %35, %37, %39, %41, %43, %45, %47, %49, %51, %53, %55 : i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32) {
        ro %arg6[%c0 for %3] : !stream.resource<external>{%3},
        ro %arg7[%c0 for %9] : !stream.resource<external>{%9},
        ro %arg8[%c0 for %14] : !stream.resource<external>{%14},
        wo %arg9[%c0 for %19] : !stream.resource<external>{%19}
      }
    } => !stream.timepoint
    %57 = arith.muli %0, %c2 : index
    %58 = arith.muli %57, %16 : index
    stream.timepoint.chain_external on(#hal.device.affinity<@__device_0>) %56 => (%arg5 : !hal.fence)
    %59 = stream.tensor.export on(#hal.device.affinity<@__device_0>) %result : tensor<?x?xi16>{%0, %16} in !stream.resource<external>{%58} -> !hal.buffer_view
    util.return %59 : !hal.buffer_view
  }
  hal.executable private @ct_asym_f16_f16_dispatch_0 {
    hal.executable.variant public @vulkan_spirv_fb target(<"vulkan-spirv", "vulkan-spirv-fb", {iree_codegen.target_info = #iree_gpu.target<arch = "vp_android_baseline_2022", features = "spirv:v1.3,cap:Shader,cap:Int16,cap:Float16,cap:StorageBuffer16BitAccess,cap:SignedZeroInfNanPreserve,ext:SPV_KHR_16bit_storage,ext:SPV_KHR_float_controls", wgp = <compute = fp32|int32, storage = b32, subgroup = none, subgroup_size_choices = [64], max_workgroup_sizes = [128, 128, 64], max_thread_count_per_workgroup = 128, max_workgroup_memory_bytes = 16384, max_workgroup_counts = [65535, 65535, 65535]>>}>) {
      hal.executable.export public @ct_asym_f16_f16_dispatch_0_elementwise_broadcast_D_f16 ordinal(0) layout(#hal.pipeline.layout<constants = 18, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) count(%arg0: !hal.device, %arg1: index, %arg2: index, %arg3: index, %arg4: index, %arg5: index, %arg6: index, %arg7: index, %arg8: index, %arg9: index) -> (index, index, index) {
        %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice(%arg1, %arg2, %arg3, %arg4, %arg5, %arg6, %arg7, %arg8, %arg9)
        hal.return %x, %y, %z : index, index, index
      }
      builtin.module {
        func.func @ct_asym_f16_f16_dispatch_0_elementwise_broadcast_D_f16() attributes {translation_info = #iree_codegen.translation_info<pipeline = #iree_gpu.spirv_pipeline<BaseDistribute> workgroup_size = [64, 1, 1]>} {
          %c32_i64 = arith.constant 32 : i64
          %c8 = arith.constant 8 : index
          %c4 = arith.constant 4 : index
          %c15_i32 = arith.constant 15 : i32
          %c8_i32 = arith.constant 8 : i32
          %c0 = arith.constant 0 : index
          %0 = hal.interface.constant.load layout(<constants = 18, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(0) : i32
          %1 = hal.interface.constant.load layout(<constants = 18, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(1) : i32
          %2 = hal.interface.constant.load layout(<constants = 18, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(2) : i32
          %3 = hal.interface.constant.load layout(<constants = 18, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(3) : i32
          %4 = hal.interface.constant.load layout(<constants = 18, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(4) : i32
          %5 = hal.interface.constant.load layout(<constants = 18, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(5) : i32
          %6 = hal.interface.constant.load layout(<constants = 18, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(6) : i32
          %7 = hal.interface.constant.load layout(<constants = 18, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(7) : i32
          %8 = hal.interface.constant.load layout(<constants = 18, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(8) : i32
          %9 = hal.interface.constant.load layout(<constants = 18, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(9) : i32
          %10 = hal.interface.constant.load layout(<constants = 18, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(10) : i32
          %11 = hal.interface.constant.load layout(<constants = 18, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(11) : i32
          %12 = hal.interface.constant.load layout(<constants = 18, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(12) : i32
          %13 = hal.interface.constant.load layout(<constants = 18, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(13) : i32
          %14 = hal.interface.constant.load layout(<constants = 18, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(14) : i32
          %15 = hal.interface.constant.load layout(<constants = 18, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(15) : i32
          %16 = hal.interface.constant.load layout(<constants = 18, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(16) : i32
          %17 = hal.interface.constant.load layout(<constants = 18, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(17) : i32
          %18 = arith.extui %1 : i32 to i64
          %19 = arith.shli %18, %c32_i64 : i64
          %20 = arith.extui %0 : i32 to i64
          %21 = arith.ori %20, %19 : i64
          %22 = arith.index_castui %21 : i64 to index
          %23 = arith.extui %3 : i32 to i64
          %24 = arith.shli %23, %c32_i64 : i64
          %25 = arith.extui %2 : i32 to i64
          %26 = arith.ori %25, %24 : i64
          %27 = arith.index_castui %26 : i64 to index
          %28 = arith.extui %5 : i32 to i64
          %29 = arith.shli %28, %c32_i64 : i64
          %30 = arith.extui %4 : i32 to i64
          %31 = arith.ori %30, %29 : i64
          %32 = arith.index_castui %31 : i64 to index
          %33 = arith.extui %7 : i32 to i64
          %34 = arith.shli %33, %c32_i64 : i64
          %35 = arith.extui %6 : i32 to i64
          %36 = arith.ori %35, %34 : i64
          %37 = arith.index_castui %36 : i64 to index
          %38 = arith.extui %9 : i32 to i64
          %39 = arith.shli %38, %c32_i64 : i64
          %40 = arith.extui %8 : i32 to i64
          %41 = arith.ori %40, %39 : i64
          %42 = arith.index_castui %41 : i64 to index
          %43 = arith.extui %11 : i32 to i64
          %44 = arith.shli %43, %c32_i64 : i64
          %45 = arith.extui %10 : i32 to i64
          %46 = arith.ori %45, %44 : i64
          %47 = arith.index_castui %46 : i64 to index
          %48 = arith.extui %13 : i32 to i64
          %49 = arith.shli %48, %c32_i64 : i64
          %50 = arith.extui %12 : i32 to i64
          %51 = arith.ori %50, %49 : i64
          %52 = arith.index_castui %51 : i64 to index
          %53 = arith.extui %15 : i32 to i64
          %54 = arith.shli %53, %c32_i64 : i64
          %55 = arith.extui %14 : i32 to i64
          %56 = arith.ori %55, %54 : i64
          %57 = arith.index_castui %56 : i64 to index
          %58 = arith.extui %17 : i32 to i64
          %59 = arith.shli %58, %c32_i64 : i64
          %60 = arith.extui %16 : i32 to i64
          %61 = arith.ori %60, %59 : i64
          %62 = arith.index_castui %61 : i64 to index
          %63:8 = util.assume.int 
              %22<umin = 0, umax = 9223372036854775807, udiv = 8>, 
              %27<umin = 0, umax = 72057594037927928, udiv = 8>, 
              %37<umin = 0, umax = 9007199254740991>, 
              %42<umin = 0, umax = 9007199254740991>, 
              %47<umin = 0, umax = 9007199254740991>, 
              %52<umin = 0, umax = 9007199254740991>, 
              %57<umin = 0, umax = 9007199254740991>, 
              %62<umin = 0, umax = 9007199254740991>
            : index, index, index, index, index, index, index, index
          %64 = iree_tensor_ext.dispatch.workload.ordinal %63#0, 0 : index
          %65 = iree_tensor_ext.dispatch.workload.ordinal %63#2, 3 : index
          %66 = iree_tensor_ext.dispatch.workload.ordinal %63#3, 4 : index
          %67 = iree_tensor_ext.dispatch.workload.ordinal %63#4, 5 : index
          %68 = iree_tensor_ext.dispatch.workload.ordinal %63#5, 6 : index
          %69 = iree_tensor_ext.dispatch.workload.ordinal %63#6, 7 : index
          %70 = iree_tensor_ext.dispatch.workload.ordinal %63#7, 8 : index
          %71 = hal.interface.binding.subspan layout(<constants = 18, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(0) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xi32>>{%65, %66}
          %72 = hal.interface.binding.subspan layout(<constants = 18, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(1) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xi32>>{%67, %68}
          %73 = hal.interface.binding.subspan layout(<constants = 18, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(2) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xf16>>{%69, %70}
          %74 = hal.interface.binding.subspan layout(<constants = 18, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(3) alignment(64) offset(%c0) flags(Indirect) : !iree_tensor_ext.dispatch.tensor<writeonly:tensor<?xf16>>{%64}
          %75 = iree_tensor_ext.dispatch.workload.ordinal %63#1, 1 : index
          %76 = iree_tensor_ext.dispatch.workload.ordinal %32, 2 : index
          %77 = iree_tensor_ext.dispatch.tensor.load %71, offsets = [0, 0], sizes = [%65, %66], strides = [1, 1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xi32>>{%65, %66} -> tensor<?x?xi32>
          %78 = iree_tensor_ext.dispatch.tensor.load %72, offsets = [0, 0], sizes = [%67, %68], strides = [1, 1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xi32>>{%67, %68} -> tensor<?x?xi32>
          %79 = iree_tensor_ext.dispatch.tensor.load %73, offsets = [0, 0], sizes = [%69, %70], strides = [1, 1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xf16>>{%69, %70} -> tensor<?x?xf16>
          %80 = tensor.empty(%64) : tensor<?xf16>
          %81 = linalg.generic {indexing_maps = [affine_map<(d0) -> (d0)>], iterator_types = ["parallel"]} outs(%80 : tensor<?xf16>) attrs =  {lowering_config = #iree_codegen.lowering_config<tile_sizes = [[64], [1]]>} {
          ^bb0(%out: f16):
            %82 = linalg.index 0 : index
            %83 = arith.remsi %82, %75 : index
            %84 = arith.divsi %82, %75 : index
            %85 = arith.divui %83, %76 : index
            %86 = arith.divui %83, %c8 : index
            %87 = arith.remui %83, %c8 : index
            %extracted = tensor.extract %77[%84, %86] : tensor<?x?xi32>
            %88 = arith.divui %84, %c8 : index
            %89 = arith.remui %84, %c8 : index
            %90 = arith.muli %89, %c4 : index
            %91 = arith.index_castui %90 : index to i32
            %extracted_0 = tensor.extract %78[%88, %85] : tensor<?x?xi32>
            %92 = arith.muli %87, %c4 : index
            %93 = arith.index_castui %92 : index to i32
            %94 = arith.shrui %extracted, %93 : i32
            %95 = arith.andi %94, %c15_i32 : i32
            %96 = arith.shrui %extracted_0, %91 : i32
            %97 = arith.andi %96, %c15_i32 : i32
            %98 = arith.subi %95, %c8_i32 : i32
            %99 = arith.subi %97, %c8_i32 : i32
            %100 = arith.sitofp %98 : i32 to f32
            %101 = arith.sitofp %99 : i32 to f32
            %102 = arith.subf %100, %101 : f32
            %103 = arith.truncf %102 : f32 to f16
            %104 = arith.extf %103 : f16 to f32
            %extracted_1 = tensor.extract %79[%84, %85] : tensor<?x?xf16>
            %105 = arith.extf %extracted_1 : f16 to f32
            %106 = arith.mulf %104, %105 : f32
            %107 = arith.truncf %106 : f32 to f16
            %108 = arith.extf %107 : f16 to f32
            %109 = arith.truncf %108 : f32 to f16
            linalg.yield %109 : f16
          } -> tensor<?xf16>
          iree_tensor_ext.dispatch.tensor.store %81, %74, offsets = [0], sizes = [%64], strides = [1] : tensor<?xf16> -> !iree_tensor_ext.dispatch.tensor<writeonly:tensor<?xf16>>{%64}
          return
        }
        iree_codegen.dispatch_config @ct_asym_f16_f16_dispatch_0_elementwise_broadcast_D_f16 {
        ^bb0(%arg0: !hal.device, %arg1: index, %arg2: index, %arg3: index, %arg4: index, %arg5: index, %arg6: index, %arg7: index, %arg8: index, %arg9: index):
          %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice(%arg1, %arg2, %arg3, %arg4, %arg5, %arg6, %arg7, %arg8, %arg9)
          iree_codegen.yield %x, %y, %z : index, index, index
        }
      }
    }
  }
  util.func public @ct_asym_f16_f16(%arg0: !hal.buffer_view, %arg1: !hal.buffer_view, %arg2: !hal.buffer_view, %arg3: i32, %arg4: !hal.fence, %arg5: !hal.fence) -> !hal.buffer_view attributes {iree.abi.stub, iree.reflection = {iree.abi.declaration = "async func @ct_asym_f16_f16(%input0: tensor<?x?xi32>, %input1: tensor<?x?xi32>, %input2: tensor<?x?xf16>, %input3: i32) -> (%output0: tensor<?x?xf16>)", iree.abi.model = "coarse-fences"}} {
    %c32_i64 = arith.constant 32 : i64
    %c0 = arith.constant 0 : index
    %c2 = arith.constant 2 : index
    %c4 = arith.constant 4 : index
    %c8 = arith.constant 8 : index
    %0 = hal.buffer_view.dim<%arg0 : !hal.buffer_view>[0] : index
    %1 = hal.buffer_view.dim<%arg0 : !hal.buffer_view>[1] : index
    %element_type_i32 = hal.element_type<i32> : i32
    %dense_row_major = hal.encoding_type<dense_row_major> : i32
    hal.buffer_view.assert<%arg0 : !hal.buffer_view> message("input0") shape([%0, %1]) type(%element_type_i32) encoding(%dense_row_major)
    %2 = arith.muli %0, %c4 : index
    %3 = arith.muli %2, %1 : index
    %4 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg0 : !hal.buffer_view -> tensor<?x?xi32>{%0, %1} in !stream.resource<external>{%3}
    %5 = stream.timepoint.import on(#hal.device.affinity<@__device_0>) %arg4 : (!hal.fence) => !stream.timepoint
    %6 = hal.buffer_view.dim<%arg1 : !hal.buffer_view>[0] : index
    %7 = hal.buffer_view.dim<%arg1 : !hal.buffer_view>[1] : index
    hal.buffer_view.assert<%arg1 : !hal.buffer_view> message("input1") shape([%6, %7]) type(%element_type_i32) encoding(%dense_row_major)
    %8 = arith.muli %6, %c4 : index
    %9 = arith.muli %8, %7 : index
    %10 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg1 : !hal.buffer_view -> tensor<?x?xi32>{%6, %7} in !stream.resource<external>{%9}
    %11 = hal.buffer_view.dim<%arg2 : !hal.buffer_view>[0] : index
    %12 = hal.buffer_view.dim<%arg2 : !hal.buffer_view>[1] : index
    %element_type_f16 = hal.element_type<f16> : i32
    hal.buffer_view.assert<%arg2 : !hal.buffer_view> message("input2") shape([%11, %12]) type(%element_type_f16) encoding(%dense_row_major)
    %13 = arith.muli %11, %c2 : index
    %14 = arith.muli %13, %12 : index
    %15 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg2 : !hal.buffer_view -> tensor<?x?xf16>{%11, %12} in !stream.resource<external>{%14}
    %16 = arith.muli %1, %c8 : index
    %17 = arith.muli %0, %16 overflow<nsw> : index
    %18 = arith.index_cast %arg3 : i32 to index
    %19 = arith.muli %17, %c2 : index
    %result, %result_timepoint = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) await(%5) => !stream.resource<external>{%19} => !stream.timepoint
    %20 = arith.index_castui %17 : index to i64
    %21 = arith.index_castui %17 : index to i32
    %22 = arith.shrui %20, %c32_i64 : i64
    %23 = arith.trunci %22 : i64 to i32
    %24 = arith.index_castui %16 : index to i64
    %25 = arith.index_castui %16 : index to i32
    %26 = arith.shrui %24, %c32_i64 : i64
    %27 = arith.trunci %26 : i64 to i32
    %28 = arith.index_castui %18 : index to i64
    %29 = arith.index_castui %18 : index to i32
    %30 = arith.shrui %28, %c32_i64 : i64
    %31 = arith.trunci %30 : i64 to i32
    %32 = arith.index_castui %0 : index to i64
    %33 = arith.index_castui %0 : index to i32
    %34 = arith.shrui %32, %c32_i64 : i64
    %35 = arith.trunci %34 : i64 to i32
    %36 = arith.index_castui %1 : index to i64
    %37 = arith.index_castui %1 : index to i32
    %38 = arith.shrui %36, %c32_i64 : i64
    %39 = arith.trunci %38 : i64 to i32
    %40 = arith.index_castui %6 : index to i64
    %41 = arith.index_castui %6 : index to i32
    %42 = arith.shrui %40, %c32_i64 : i64
    %43 = arith.trunci %42 : i64 to i32
    %44 = arith.index_castui %7 : index to i64
    %45 = arith.index_castui %7 : index to i32
    %46 = arith.shrui %44, %c32_i64 : i64
    %47 = arith.trunci %46 : i64 to i32
    %48 = arith.index_castui %11 : index to i64
    %49 = arith.index_castui %11 : index to i32
    %50 = arith.shrui %48, %c32_i64 : i64
    %51 = arith.trunci %50 : i64 to i32
    %52 = arith.index_castui %12 : index to i64
    %53 = arith.index_castui %12 : index to i32
    %54 = arith.shrui %52, %c32_i64 : i64
    %55 = arith.trunci %54 : i64 to i32
    %56 = stream.cmd.execute on(#hal.device.affinity<@__device_0>) await(%result_timepoint) => with(%4 as %arg6: !stream.resource<external>{%3}, %10 as %arg7: !stream.resource<external>{%9}, %15 as %arg8: !stream.resource<external>{%14}, %result as %arg9: !stream.resource<external>{%19}) {
      stream.cmd.dispatch @ct_asym_f16_f16_dispatch_0::@vulkan_spirv_fb::@ct_asym_f16_f16_dispatch_0_elementwise_broadcast_D_f16[%17, %16, %18, %0, %1, %6, %7, %11, %12](%21, %23, %25, %27, %29, %31, %33, %35, %37, %39, %41, %43, %45, %47, %49, %51, %53, %55 : i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32) {
        ro %arg6[%c0 for %3] : !stream.resource<external>{%3},
        ro %arg7[%c0 for %9] : !stream.resource<external>{%9},
        ro %arg8[%c0 for %14] : !stream.resource<external>{%14},
        wo %arg9[%c0 for %19] : !stream.resource<external>{%19}
      }
    } => !stream.timepoint
    %57 = arith.muli %0, %c2 : index
    %58 = arith.muli %57, %16 : index
    stream.timepoint.chain_external on(#hal.device.affinity<@__device_0>) %56 => (%arg5 : !hal.fence)
    %59 = stream.tensor.export on(#hal.device.affinity<@__device_0>) %result : tensor<?x?xf16>{%0, %16} in !stream.resource<external>{%58} -> !hal.buffer_view
    util.return %59 : !hal.buffer_view
  }
  hal.executable private @ct_asym_bf16_bf16_dispatch_0 {
    hal.executable.variant public @vulkan_spirv_fb target(<"vulkan-spirv", "vulkan-spirv-fb", {iree_codegen.target_info = #iree_gpu.target<arch = "vp_android_baseline_2022", features = "spirv:v1.3,cap:Shader,cap:Int16,cap:Float16,cap:StorageBuffer16BitAccess,cap:SignedZeroInfNanPreserve,ext:SPV_KHR_16bit_storage,ext:SPV_KHR_float_controls", wgp = <compute = fp32|int32, storage = b32, subgroup = none, subgroup_size_choices = [64], max_workgroup_sizes = [128, 128, 64], max_thread_count_per_workgroup = 128, max_workgroup_memory_bytes = 16384, max_workgroup_counts = [65535, 65535, 65535]>>}>) {
      hal.executable.export public @ct_asym_bf16_bf16_dispatch_0_elementwise_broadcast_D_i16 ordinal(0) layout(#hal.pipeline.layout<constants = 18, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) count(%arg0: !hal.device, %arg1: index, %arg2: index, %arg3: index, %arg4: index, %arg5: index, %arg6: index, %arg7: index, %arg8: index, %arg9: index) -> (index, index, index) {
        %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice(%arg1, %arg2, %arg3, %arg4, %arg5, %arg6, %arg7, %arg8, %arg9)
        hal.return %x, %y, %z : index, index, index
      }
      builtin.module {
        func.func @ct_asym_bf16_bf16_dispatch_0_elementwise_broadcast_D_i16() attributes {translation_info = #iree_codegen.translation_info<pipeline = #iree_gpu.spirv_pipeline<BaseDistribute> workgroup_size = [64, 1, 1]>} {
          %c32_i64 = arith.constant 32 : i64
          %c8 = arith.constant 8 : index
          %c4 = arith.constant 4 : index
          %c15_i32 = arith.constant 15 : i32
          %c8_i32 = arith.constant 8 : i32
          %c0 = arith.constant 0 : index
          %0 = hal.interface.constant.load layout(<constants = 18, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(0) : i32
          %1 = hal.interface.constant.load layout(<constants = 18, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(1) : i32
          %2 = hal.interface.constant.load layout(<constants = 18, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(2) : i32
          %3 = hal.interface.constant.load layout(<constants = 18, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(3) : i32
          %4 = hal.interface.constant.load layout(<constants = 18, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(4) : i32
          %5 = hal.interface.constant.load layout(<constants = 18, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(5) : i32
          %6 = hal.interface.constant.load layout(<constants = 18, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(6) : i32
          %7 = hal.interface.constant.load layout(<constants = 18, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(7) : i32
          %8 = hal.interface.constant.load layout(<constants = 18, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(8) : i32
          %9 = hal.interface.constant.load layout(<constants = 18, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(9) : i32
          %10 = hal.interface.constant.load layout(<constants = 18, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(10) : i32
          %11 = hal.interface.constant.load layout(<constants = 18, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(11) : i32
          %12 = hal.interface.constant.load layout(<constants = 18, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(12) : i32
          %13 = hal.interface.constant.load layout(<constants = 18, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(13) : i32
          %14 = hal.interface.constant.load layout(<constants = 18, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(14) : i32
          %15 = hal.interface.constant.load layout(<constants = 18, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(15) : i32
          %16 = hal.interface.constant.load layout(<constants = 18, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(16) : i32
          %17 = hal.interface.constant.load layout(<constants = 18, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(17) : i32
          %18 = arith.extui %1 : i32 to i64
          %19 = arith.shli %18, %c32_i64 : i64
          %20 = arith.extui %0 : i32 to i64
          %21 = arith.ori %20, %19 : i64
          %22 = arith.index_castui %21 : i64 to index
          %23 = arith.extui %3 : i32 to i64
          %24 = arith.shli %23, %c32_i64 : i64
          %25 = arith.extui %2 : i32 to i64
          %26 = arith.ori %25, %24 : i64
          %27 = arith.index_castui %26 : i64 to index
          %28 = arith.extui %5 : i32 to i64
          %29 = arith.shli %28, %c32_i64 : i64
          %30 = arith.extui %4 : i32 to i64
          %31 = arith.ori %30, %29 : i64
          %32 = arith.index_castui %31 : i64 to index
          %33 = arith.extui %7 : i32 to i64
          %34 = arith.shli %33, %c32_i64 : i64
          %35 = arith.extui %6 : i32 to i64
          %36 = arith.ori %35, %34 : i64
          %37 = arith.index_castui %36 : i64 to index
          %38 = arith.extui %9 : i32 to i64
          %39 = arith.shli %38, %c32_i64 : i64
          %40 = arith.extui %8 : i32 to i64
          %41 = arith.ori %40, %39 : i64
          %42 = arith.index_castui %41 : i64 to index
          %43 = arith.extui %11 : i32 to i64
          %44 = arith.shli %43, %c32_i64 : i64
          %45 = arith.extui %10 : i32 to i64
          %46 = arith.ori %45, %44 : i64
          %47 = arith.index_castui %46 : i64 to index
          %48 = arith.extui %13 : i32 to i64
          %49 = arith.shli %48, %c32_i64 : i64
          %50 = arith.extui %12 : i32 to i64
          %51 = arith.ori %50, %49 : i64
          %52 = arith.index_castui %51 : i64 to index
          %53 = arith.extui %15 : i32 to i64
          %54 = arith.shli %53, %c32_i64 : i64
          %55 = arith.extui %14 : i32 to i64
          %56 = arith.ori %55, %54 : i64
          %57 = arith.index_castui %56 : i64 to index
          %58 = arith.extui %17 : i32 to i64
          %59 = arith.shli %58, %c32_i64 : i64
          %60 = arith.extui %16 : i32 to i64
          %61 = arith.ori %60, %59 : i64
          %62 = arith.index_castui %61 : i64 to index
          %63:8 = util.assume.int 
              %22<umin = 0, umax = 9223372036854775807, udiv = 8>, 
              %27<umin = 0, umax = 72057594037927928, udiv = 8>, 
              %37<umin = 0, umax = 9007199254740991>, 
              %42<umin = 0, umax = 9007199254740991>, 
              %47<umin = 0, umax = 9007199254740991>, 
              %52<umin = 0, umax = 9007199254740991>, 
              %57<umin = 0, umax = 9007199254740991>, 
              %62<umin = 0, umax = 9007199254740991>
            : index, index, index, index, index, index, index, index
          %64 = iree_tensor_ext.dispatch.workload.ordinal %63#0, 0 : index
          %65 = iree_tensor_ext.dispatch.workload.ordinal %63#2, 3 : index
          %66 = iree_tensor_ext.dispatch.workload.ordinal %63#3, 4 : index
          %67 = iree_tensor_ext.dispatch.workload.ordinal %63#4, 5 : index
          %68 = iree_tensor_ext.dispatch.workload.ordinal %63#5, 6 : index
          %69 = iree_tensor_ext.dispatch.workload.ordinal %63#6, 7 : index
          %70 = iree_tensor_ext.dispatch.workload.ordinal %63#7, 8 : index
          %71 = hal.interface.binding.subspan layout(<constants = 18, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(0) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xi32>>{%65, %66}
          %72 = hal.interface.binding.subspan layout(<constants = 18, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(1) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xi32>>{%67, %68}
          %73 = hal.interface.binding.subspan layout(<constants = 18, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(2) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xi16>>{%69, %70}
          %74 = hal.interface.binding.subspan layout(<constants = 18, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(3) alignment(64) offset(%c0) flags(Indirect) : !iree_tensor_ext.dispatch.tensor<writeonly:tensor<?xi16>>{%64}
          %75 = iree_tensor_ext.dispatch.workload.ordinal %63#1, 1 : index
          %76 = iree_tensor_ext.dispatch.workload.ordinal %32, 2 : index
          %77 = iree_tensor_ext.dispatch.tensor.load %71, offsets = [0, 0], sizes = [%65, %66], strides = [1, 1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xi32>>{%65, %66} -> tensor<?x?xi32>
          %78 = iree_tensor_ext.dispatch.tensor.load %72, offsets = [0, 0], sizes = [%67, %68], strides = [1, 1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xi32>>{%67, %68} -> tensor<?x?xi32>
          %79 = iree_tensor_ext.dispatch.tensor.load %73, offsets = [0, 0], sizes = [%69, %70], strides = [1, 1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xi16>>{%69, %70} -> tensor<?x?xi16>
          %80 = tensor.empty(%64) : tensor<?xi16>
          %81 = linalg.generic {indexing_maps = [affine_map<(d0) -> (d0)>], iterator_types = ["parallel"]} outs(%80 : tensor<?xi16>) attrs =  {lowering_config = #iree_codegen.lowering_config<tile_sizes = [[64], [1]]>} {
          ^bb0(%out: i16):
            %82 = linalg.index 0 : index
            %83 = arith.remsi %82, %75 : index
            %84 = arith.divsi %82, %75 : index
            %85 = arith.divui %83, %76 : index
            %86 = arith.divui %83, %c8 : index
            %87 = arith.remui %83, %c8 : index
            %extracted = tensor.extract %77[%84, %86] : tensor<?x?xi32>
            %88 = arith.divui %84, %c8 : index
            %89 = arith.remui %84, %c8 : index
            %90 = arith.muli %89, %c4 : index
            %91 = arith.index_castui %90 : index to i32
            %extracted_0 = tensor.extract %78[%88, %85] : tensor<?x?xi32>
            %92 = arith.muli %87, %c4 : index
            %93 = arith.index_castui %92 : index to i32
            %94 = arith.shrui %extracted, %93 : i32
            %95 = arith.andi %94, %c15_i32 : i32
            %96 = arith.shrui %extracted_0, %91 : i32
            %97 = arith.andi %96, %c15_i32 : i32
            %98 = arith.subi %95, %c8_i32 : i32
            %99 = arith.subi %97, %c8_i32 : i32
            %100 = arith.sitofp %98 : i32 to f32
            %101 = arith.sitofp %99 : i32 to f32
            %102 = arith.subf %100, %101 : f32
            %103 = arith.truncf %102 : f32 to bf16
            %104 = arith.extf %103 : bf16 to f32
            %extracted_1 = tensor.extract %79[%84, %85] : tensor<?x?xi16>
            %105 = arith.bitcast %extracted_1 : i16 to bf16
            %106 = arith.extf %105 : bf16 to f32
            %107 = arith.mulf %104, %106 : f32
            %108 = arith.truncf %107 : f32 to bf16
            %109 = arith.extf %108 : bf16 to f32
            %110 = arith.truncf %109 : f32 to bf16
            %111 = arith.bitcast %110 : bf16 to i16
            linalg.yield %111 : i16
          } -> tensor<?xi16>
          iree_tensor_ext.dispatch.tensor.store %81, %74, offsets = [0], sizes = [%64], strides = [1] : tensor<?xi16> -> !iree_tensor_ext.dispatch.tensor<writeonly:tensor<?xi16>>{%64}
          return
        }
        iree_codegen.dispatch_config @ct_asym_bf16_bf16_dispatch_0_elementwise_broadcast_D_i16 {
        ^bb0(%arg0: !hal.device, %arg1: index, %arg2: index, %arg3: index, %arg4: index, %arg5: index, %arg6: index, %arg7: index, %arg8: index, %arg9: index):
          %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice(%arg1, %arg2, %arg3, %arg4, %arg5, %arg6, %arg7, %arg8, %arg9)
          iree_codegen.yield %x, %y, %z : index, index, index
        }
      }
    }
  }
  util.func public @ct_asym_bf16_bf16(%arg0: !hal.buffer_view, %arg1: !hal.buffer_view, %arg2: !hal.buffer_view, %arg3: i32, %arg4: !hal.fence, %arg5: !hal.fence) -> !hal.buffer_view attributes {iree.abi.stub, iree.reflection = {iree.abi.declaration = "async func @ct_asym_bf16_bf16(%input0: tensor<?x?xi32>, %input1: tensor<?x?xi32>, %input2: tensor<?x?xi16>, %input3: i32) -> (%output0: tensor<?x?xi16>)", iree.abi.model = "coarse-fences"}} {
    %c32_i64 = arith.constant 32 : i64
    %c0 = arith.constant 0 : index
    %c2 = arith.constant 2 : index
    %c4 = arith.constant 4 : index
    %c8 = arith.constant 8 : index
    %0 = hal.buffer_view.dim<%arg0 : !hal.buffer_view>[0] : index
    %1 = hal.buffer_view.dim<%arg0 : !hal.buffer_view>[1] : index
    %element_type_i32 = hal.element_type<i32> : i32
    %dense_row_major = hal.encoding_type<dense_row_major> : i32
    hal.buffer_view.assert<%arg0 : !hal.buffer_view> message("input0") shape([%0, %1]) type(%element_type_i32) encoding(%dense_row_major)
    %2 = arith.muli %0, %c4 : index
    %3 = arith.muli %2, %1 : index
    %4 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg0 : !hal.buffer_view -> tensor<?x?xi32>{%0, %1} in !stream.resource<external>{%3}
    %5 = stream.timepoint.import on(#hal.device.affinity<@__device_0>) %arg4 : (!hal.fence) => !stream.timepoint
    %6 = hal.buffer_view.dim<%arg1 : !hal.buffer_view>[0] : index
    %7 = hal.buffer_view.dim<%arg1 : !hal.buffer_view>[1] : index
    hal.buffer_view.assert<%arg1 : !hal.buffer_view> message("input1") shape([%6, %7]) type(%element_type_i32) encoding(%dense_row_major)
    %8 = arith.muli %6, %c4 : index
    %9 = arith.muli %8, %7 : index
    %10 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg1 : !hal.buffer_view -> tensor<?x?xi32>{%6, %7} in !stream.resource<external>{%9}
    %11 = hal.buffer_view.dim<%arg2 : !hal.buffer_view>[0] : index
    %12 = hal.buffer_view.dim<%arg2 : !hal.buffer_view>[1] : index
    %element_type_i16 = hal.element_type<i16> : i32
    hal.buffer_view.assert<%arg2 : !hal.buffer_view> message("input2") shape([%11, %12]) type(%element_type_i16) encoding(%dense_row_major)
    %13 = arith.muli %11, %c2 : index
    %14 = arith.muli %13, %12 : index
    %15 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg2 : !hal.buffer_view -> tensor<?x?xi16>{%11, %12} in !stream.resource<external>{%14}
    %16 = arith.muli %1, %c8 : index
    %17 = arith.muli %0, %16 overflow<nsw> : index
    %18 = arith.index_cast %arg3 : i32 to index
    %19 = arith.muli %17, %c2 : index
    %result, %result_timepoint = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) await(%5) => !stream.resource<external>{%19} => !stream.timepoint
    %20 = arith.index_castui %17 : index to i64
    %21 = arith.index_castui %17 : index to i32
    %22 = arith.shrui %20, %c32_i64 : i64
    %23 = arith.trunci %22 : i64 to i32
    %24 = arith.index_castui %16 : index to i64
    %25 = arith.index_castui %16 : index to i32
    %26 = arith.shrui %24, %c32_i64 : i64
    %27 = arith.trunci %26 : i64 to i32
    %28 = arith.index_castui %18 : index to i64
    %29 = arith.index_castui %18 : index to i32
    %30 = arith.shrui %28, %c32_i64 : i64
    %31 = arith.trunci %30 : i64 to i32
    %32 = arith.index_castui %0 : index to i64
    %33 = arith.index_castui %0 : index to i32
    %34 = arith.shrui %32, %c32_i64 : i64
    %35 = arith.trunci %34 : i64 to i32
    %36 = arith.index_castui %1 : index to i64
    %37 = arith.index_castui %1 : index to i32
    %38 = arith.shrui %36, %c32_i64 : i64
    %39 = arith.trunci %38 : i64 to i32
    %40 = arith.index_castui %6 : index to i64
    %41 = arith.index_castui %6 : index to i32
    %42 = arith.shrui %40, %c32_i64 : i64
    %43 = arith.trunci %42 : i64 to i32
    %44 = arith.index_castui %7 : index to i64
    %45 = arith.index_castui %7 : index to i32
    %46 = arith.shrui %44, %c32_i64 : i64
    %47 = arith.trunci %46 : i64 to i32
    %48 = arith.index_castui %11 : index to i64
    %49 = arith.index_castui %11 : index to i32
    %50 = arith.shrui %48, %c32_i64 : i64
    %51 = arith.trunci %50 : i64 to i32
    %52 = arith.index_castui %12 : index to i64
    %53 = arith.index_castui %12 : index to i32
    %54 = arith.shrui %52, %c32_i64 : i64
    %55 = arith.trunci %54 : i64 to i32
    %56 = stream.cmd.execute on(#hal.device.affinity<@__device_0>) await(%result_timepoint) => with(%4 as %arg6: !stream.resource<external>{%3}, %10 as %arg7: !stream.resource<external>{%9}, %15 as %arg8: !stream.resource<external>{%14}, %result as %arg9: !stream.resource<external>{%19}) {
      stream.cmd.dispatch @ct_asym_bf16_bf16_dispatch_0::@vulkan_spirv_fb::@ct_asym_bf16_bf16_dispatch_0_elementwise_broadcast_D_i16[%17, %16, %18, %0, %1, %6, %7, %11, %12](%21, %23, %25, %27, %29, %31, %33, %35, %37, %39, %41, %43, %45, %47, %49, %51, %53, %55 : i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32) {
        ro %arg6[%c0 for %3] : !stream.resource<external>{%3},
        ro %arg7[%c0 for %9] : !stream.resource<external>{%9},
        ro %arg8[%c0 for %14] : !stream.resource<external>{%14},
        wo %arg9[%c0 for %19] : !stream.resource<external>{%19}
      }
    } => !stream.timepoint
    %57 = arith.muli %0, %c2 : index
    %58 = arith.muli %57, %16 : index
    stream.timepoint.chain_external on(#hal.device.affinity<@__device_0>) %56 => (%arg5 : !hal.fence)
    %59 = stream.tensor.export on(#hal.device.affinity<@__device_0>) %result : tensor<?x?xi16>{%0, %16} in !stream.resource<external>{%58} -> !hal.buffer_view
    util.return %59 : !hal.buffer_view
  }
}