spirv.module Logical GLSL450 requires #spirv.vce<v1.0, [Shader, StorageBuffer16BitAccess, Float16, SignedZeroInfNanPreserve, Matrix], [SPV_KHR_storage_buffer_storage_class, SPV_KHR_16bit_storage, SPV_KHR_float_controls]> {
  spirv.GlobalVariable @__builtin__NumWorkgroups__ built_in("NumWorkgroups") : !spirv.ptr<vector<3xi32>, Input>
  spirv.GlobalVariable @__builtin__WorkgroupId__ built_in("WorkgroupId") : !spirv.ptr<vector<3xi32>, Input>
  spirv.GlobalVariable @__builtin__LocalInvocationId__ built_in("LocalInvocationId") : !spirv.ptr<vector<3xi32>, Input>
  spirv.GlobalVariable @__push_constant_var__ : !spirv.ptr<!spirv.struct<(!spirv.array<18 x i32, stride=4> [0]), Block>, PushConstant>
  spirv.GlobalVariable @__resource_var_0_0_ bind(0, 0) : !spirv.ptr<!spirv.struct<(!spirv.rtarray<i32, stride=4> [0])>, StorageBuffer>
  spirv.GlobalVariable @__resource_var_0_1_ bind(0, 1) : !spirv.ptr<!spirv.struct<(!spirv.rtarray<i32, stride=4> [0])>, StorageBuffer>
  spirv.GlobalVariable @__resource_var_0_2_ bind(0, 2) : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f16, stride=2> [0])>, StorageBuffer>
  spirv.GlobalVariable @__resource_var_0_3_ bind(0, 3) : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f16, stride=2> [0])>, StorageBuffer>
  spirv.func @ct_asym_f16_f16_dispatch_0_elementwise_broadcast_D_f16() "None" attributes {gpu.known_block_size = array<i32: 64, 1, 1>, hal.executable.target = #hal.executable.target<"vulkan-spirv", "vulkan-spirv-fb", {iree_codegen.target_info = #iree_gpu.target<arch = "vp_android_baseline_2022", features = "spirv:v1.3,cap:Shader,cap:Int16,cap:Float16,cap:StorageBuffer16BitAccess,cap:SignedZeroInfNanPreserve,ext:SPV_KHR_16bit_storage,ext:SPV_KHR_float_controls", wgp = <compute = fp32|int32, storage = b32, subgroup = none, subgroup_size_choices = [64], max_workgroup_sizes = [128, 128, 64], max_thread_count_per_workgroup = 128, max_workgroup_memory_bytes = 16384, max_workgroup_counts = [65535, 65535, 65535]>>}>} {
    %cst16_i32 = spirv.Constant 16 : i32
    %cst14_i32 = spirv.Constant 14 : i32
    %cst12_i32 = spirv.Constant 12 : i32
    %cst10_i32 = spirv.Constant 10 : i32
    %cst6_i32 = spirv.Constant 6 : i32
    %cst2_i32 = spirv.Constant 2 : i32
    %cst4_i32 = spirv.Constant 4 : i32
    %cst64_i32 = spirv.Constant 64 : i32
    %cst8_i32 = spirv.Constant 8 : i32
    %cst15_i32 = spirv.Constant 15 : i32
    %cst0_i32 = spirv.Constant 0 : i32
    %__push_constant_var___addr = spirv.mlir.addressof @__push_constant_var__ : !spirv.ptr<!spirv.struct<(!spirv.array<18 x i32, stride=4> [0]), Block>, PushConstant>
    %0 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst0_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<18 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %1 = spirv.Load "PushConstant" %0 : i32
    %2 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst2_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<18 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %3 = spirv.Load "PushConstant" %2 : i32
    %4 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst4_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<18 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %5 = spirv.Load "PushConstant" %4 : i32
    %6 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst6_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<18 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %7 = spirv.Load "PushConstant" %6 : i32
    %8 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst8_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<18 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %9 = spirv.Load "PushConstant" %8 : i32
    %10 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst10_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<18 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %11 = spirv.Load "PushConstant" %10 : i32
    %12 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst12_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<18 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %13 = spirv.Load "PushConstant" %12 : i32
    %14 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst14_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<18 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %15 = spirv.Load "PushConstant" %14 : i32
    %16 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst16_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<18 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %17 = spirv.Load "PushConstant" %16 : i32
    %__resource_var_0_0__addr = spirv.mlir.addressof @__resource_var_0_0_ : !spirv.ptr<!spirv.struct<(!spirv.rtarray<i32, stride=4> [0])>, StorageBuffer>
    %__resource_var_0_1__addr = spirv.mlir.addressof @__resource_var_0_1_ : !spirv.ptr<!spirv.struct<(!spirv.rtarray<i32, stride=4> [0])>, StorageBuffer>
    %__resource_var_0_2__addr = spirv.mlir.addressof @__resource_var_0_2_ : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f16, stride=2> [0])>, StorageBuffer>
    %__resource_var_0_3__addr = spirv.mlir.addressof @__resource_var_0_3_ : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f16, stride=2> [0])>, StorageBuffer>
    %__builtin__LocalInvocationId___addr = spirv.mlir.addressof @__builtin__LocalInvocationId__ : !spirv.ptr<vector<3xi32>, Input>
    %18 = spirv.Load "Input" %__builtin__LocalInvocationId___addr : vector<3xi32>
    %19 = spirv.CompositeExtract %18[0 : i32] : vector<3xi32>
    %__builtin__WorkgroupId___addr = spirv.mlir.addressof @__builtin__WorkgroupId__ : !spirv.ptr<vector<3xi32>, Input>
    %20 = spirv.Load "Input" %__builtin__WorkgroupId___addr : vector<3xi32>
    %21 = spirv.CompositeExtract %20[0 : i32] : vector<3xi32>
    %__builtin__NumWorkgroups___addr = spirv.mlir.addressof @__builtin__NumWorkgroups__ : !spirv.ptr<vector<3xi32>, Input>
    %22 = spirv.Load "Input" %__builtin__NumWorkgroups___addr : vector<3xi32>
    %23 = spirv.CompositeExtract %22[0 : i32] : vector<3xi32>
    %24 = spirv.IMul %21, %cst64_i32 : i32
    %25 = spirv.IMul %23, %cst64_i32 : i32
    spirv.mlir.loop {
      spirv.Branch ^bb1(%24 : i32)
    ^bb1(%26: i32):  // 2 preds: ^bb0, ^bb2
      %27 = spirv.SLessThan %26, %1 : i32
      spirv.BranchConditional %27, ^bb2, ^bb3
    ^bb2:  // pred: ^bb1
      %28 = spirv.ISub %1, %26 : i32
      %29 = spirv.GL.SMin %28, %cst64_i32 : i32
      %30 = spirv.SGreaterThan %29, %19 : i32
      spirv.mlir.selection {
        spirv.BranchConditional %30, ^bb1, ^bb2
      ^bb1:  // pred: ^bb0
        %32 = spirv.IAdd %26, %19 : i32
        %33 = spirv.GL.SAbs %32 : i32
        %34 = spirv.GL.SAbs %3 : i32
        %35 = spirv.UMod %33, %34 : i32
        %36 = spirv.IEqual %32, %33 : i32
        %37 = spirv.SNegate %35 : i32
        %38 = spirv.Select %36, %35, %37 : i1, i32
        %39 = spirv.SDiv %32, %3 : i32
        %40 = spirv.UDiv %38, %5 : i32
        %41 = spirv.UDiv %38, %cst8_i32 : i32
        %42 = spirv.UMod %38, %cst8_i32 : i32
        %43 = spirv.IMul %39, %9 : i32
        %44 = spirv.IAdd %43, %41 : i32
        %45 = spirv.AccessChain %__resource_var_0_0__addr[%cst0_i32, %44] : !spirv.ptr<!spirv.struct<(!spirv.rtarray<i32, stride=4> [0])>, StorageBuffer>, i32, i32 -> !spirv.ptr<i32, StorageBuffer>
        %46 = spirv.Load "StorageBuffer" %45 : i32
        %47 = spirv.UDiv %39, %cst8_i32 : i32
        %48 = spirv.UMod %39, %cst8_i32 : i32
        %49 = spirv.IMul %48, %cst4_i32 : i32
        %50 = spirv.IMul %47, %13 : i32
        %51 = spirv.IAdd %50, %40 : i32
        %52 = spirv.AccessChain %__resource_var_0_1__addr[%cst0_i32, %51] : !spirv.ptr<!spirv.struct<(!spirv.rtarray<i32, stride=4> [0])>, StorageBuffer>, i32, i32 -> !spirv.ptr<i32, StorageBuffer>
        %53 = spirv.Load "StorageBuffer" %52 : i32
        %54 = spirv.IMul %42, %cst4_i32 : i32
        %55 = spirv.ShiftRightLogical %46, %54 : i32, i32
        %56 = spirv.BitwiseAnd %55, %cst15_i32 : i32
        %57 = spirv.ShiftRightLogical %53, %49 : i32, i32
        %58 = spirv.BitwiseAnd %57, %cst15_i32 : i32
        %59 = spirv.ISub %56, %cst8_i32 : i32
        %60 = spirv.ISub %58, %cst8_i32 : i32
        %61 = spirv.ConvertSToF %59 : i32 to f32
        %62 = spirv.ConvertSToF %60 : i32 to f32
        %63 = spirv.FSub %61, %62 : f32
        %64 = spirv.FConvert %63 : f32 to f16
        %65 = spirv.FConvert %64 : f16 to f32
        %66 = spirv.IMul %39, %17 : i32
        %67 = spirv.IAdd %66, %40 : i32
        %68 = spirv.AccessChain %__resource_var_0_2__addr[%cst0_i32, %67] : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f16, stride=2> [0])>, StorageBuffer>, i32, i32 -> !spirv.ptr<f16, StorageBuffer>
        %69 = spirv.Load "StorageBuffer" %68 : f16
        %70 = spirv.FConvert %69 : f16 to f32
        %71 = spirv.FMul %65, %70 : f32
        %72 = spirv.FConvert %71 : f32 to f16
        %73 = spirv.FConvert %72 : f16 to f32
        %74 = spirv.FConvert %73 : f32 to f16
        %75 = spirv.AccessChain %__resource_var_0_3__addr[%cst0_i32, %32] : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f16, stride=2> [0])>, StorageBuffer>, i32, i32 -> !spirv.ptr<f16, StorageBuffer>
        spirv.Store "StorageBuffer" %75, %74 : f16
        spirv.Branch ^bb2
      ^bb2:  // 2 preds: ^bb0, ^bb1
        spirv.mlir.merge
      }
      %31 = spirv.IAdd %26, %25 : i32
      spirv.Branch ^bb1(%31 : i32)
    ^bb3:  // pred: ^bb1
      spirv.mlir.merge
    }
    spirv.Return
  }
  spirv.EntryPoint "GLCompute" @ct_asym_f16_f16_dispatch_0_elementwise_broadcast_D_f16, @__builtin__LocalInvocationId__, @__builtin__WorkgroupId__, @__builtin__NumWorkgroups__
  spirv.ExecutionMode @ct_asym_f16_f16_dispatch_0_elementwise_broadcast_D_f16 "LocalSize", 64, 1, 1
  spirv.ExecutionMode @ct_asym_f16_f16_dispatch_0_elementwise_broadcast_D_f16 "SignedZeroInfNanPreserve", 32
}