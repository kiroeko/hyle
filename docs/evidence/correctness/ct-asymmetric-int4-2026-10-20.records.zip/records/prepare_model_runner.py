"""Reuse the existing fixed-input model comparison without altering its checks."""
from pathlib import Path
S = Path(__file__).resolve().parent
text = (S.parent / 'view-projection-reuse/run_model.py').read_text()
text = text.replace('View projection metadata reuse regression:', 'CT route addition regression:')
text = text.replace("STAGE / 'build.py'", "ARCH / 'view-projection-reuse/build.py'")
(S / 'run_model.py').write_text(text, encoding='utf-8')
print('MODEL_RUNNER_PREPARED_NO_GPU')
