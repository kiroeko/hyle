"""Retain only the current shared schema/CPU/test edits and exact source snapshots."""
from pathlib import Path
import hashlib
import json
S = Path(__file__).resolve().parent
ROOT = S.parents[2]
def identity(path):
    p = Path(path).resolve()
    data = p.read_bytes()
    return dict(path=str(p), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())
before = json.loads((S / 'root-before.json').read_text(encoding='utf-8-sig'))
rows = []
for row in before:
    if row['source'] == 'cmake/HyleDependencyLock.json':
        continue
    source = ROOT / row['source']
    target = S / 'root-source' / row['source']
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(source.read_bytes())
    rows.append(dict(source=str(source), before={k:row[k] for k in ('path', 'bytes', 'sha256')},
                     after=identity(source), retained_after=identity(target)))
header = ROOT / 'tests/compute_models/ct_asymmetric_int4_fixture.h'
target = S / 'root-source/tests/compute_models/ct_asymmetric_int4_fixture.h'
target.parent.mkdir(parents=True, exist_ok=True)
target.write_bytes(header.read_bytes())
rows.append(dict(source=str(header), before=None, after=identity(header), retained_after=identity(target)))
result = dict(files=rows, enum_append='kCompressedTensorsAsymmetric4=4',
    inputs=['I32 codes[N,K/8]', 'I32 zero[ceilN/8,K/group]', 'float scale[N,K/group]'],
    public_descriptor_layout_changed=False, existing_inline_traits_changed=False,
    source_rounding='scale dtype subtraction/multiplication then requested output conversion',
    fresh_runtime_tests=False)
(S / 'root-source-freeze.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
print('ROOT_SOURCE_FROZEN', len(rows))
