"""Integer coordinate check only; does not import Torch or execute a backend."""
import json
from pathlib import Path

stage = Path(__file__).resolve().parent
cases = []
for n in [1, 7, 8, 9, 16, 17]:
    for groups in [1, 2, 3]:
        logical = [[((row * 7 + g * 3 + 2) % 16) - 8
                    for g in range(groups)] for row in range(n)]
        packed = [[0xdeadbeef for _ in range(groups)] for _ in range((n + 7) // 8)]
        for row in range(n):
            for g in range(groups):
                shift = 4 * (row % 8)
                packed[row // 8][g] = ((packed[row // 8][g] & ~(15 << shift)) |
                                      ((logical[row][g] + 8) << shift))
        # The helper's logical transpose -> 8 lanes -> flatten -> N slice -> transpose.
        unfolded = [[((packed[word][g] >> (4 * lane)) & 15) - 8
                     for word in range(len(packed)) for lane in range(8)][:n]
                    for g in range(groups)]
        actual = [[unfolded[g][row] for g in range(groups)] for row in range(n)]
        assert actual == logical
        signed_words = [[word - (1 << 32) if word >= (1 << 31) else word
                         for word in words] for words in packed]
        signed_unfolded = [[((signed_words[word][g] >> (4 * lane)) & 15) - 8
                            for word in range(len(packed)) for lane in range(8)][:n]
                           for g in range(groups)]
        assert signed_unfolded == unfolded
        cases.append(dict(N=n, groups=groups, logical_zero_points=n * groups,
                          contains_negative_I32=any(x < 0 for words in signed_words for x in words)))
assert any(c["contains_negative_I32"] for c in cases)
result = dict(scope="Offline integer index-map proof only; not ATen execution or a numerical backend test",
              cases=cases, passed=True, tensor_payload_read=False, build_or_GPU=False)
(stage / "cuda-index-map-review.json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
print(json.dumps(dict(cases=len(cases), passed=True)))
