"""Update only the four modified vendored recipes and the IREE artifact entry."""
from pathlib import Path
import copy
import hashlib
import json

S = Path(__file__).resolve().parent
ROOT = S.parents[2]

def read(p):
    return json.loads(Path(p).read_text(encoding='utf-8-sig'))

def ident(p):
    p = Path(p).resolve()
    data = p.read_bytes()
    return dict(path=str(p), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())

def normalized(p):
    data = p.read_bytes().replace(b'\r\n', b'\n').replace(b'\r', b'\n')
    return hashlib.sha256(data).hexdigest()

def tree(p):
    records = []
    for child in sorted(p.rglob('*'), key=lambda v: v.relative_to(p).as_posix()):
        assert not child.is_symlink(), child
        if child.is_file():
            records.append(f'{child.relative_to(p).as_posix()}|{normalized(child)}\n')
    return hashlib.sha256(''.join(records).encode()).hexdigest(), records

lock_path = ROOT / 'cmake/HyleDependencyLock.json'
manifest_path = ROOT / 'third_party/iree_vulkan_runtime/programs/manifest.json'
before = {}
for p in [lock_path, manifest_path]:
    saved = S / 'metadata-before' / p.relative_to(ROOT)
    saved.parent.mkdir(parents=True, exist_ok=True)
    if not saved.exists():
        saved.write_bytes(p.read_bytes())
    before[str(p.relative_to(ROOT))] = ident(saved)
proposal = read(S / 'vulkan/manifest-update.json')
manifest = read(manifest_path)
entry = next(r for r in manifest['programs'] if r['name'] == 'artifacts')
assert entry in [proposal['before'], proposal['after']]
entry.clear()
entry.update(proposal['after'])
manifest_path.write_text(json.dumps(manifest, indent=2) + '\n', encoding='utf-8')

lock = read(S / 'metadata-before/cmake/HyleDependencyLock.json')
actual = read(lock_path)
original = copy.deepcopy(lock)
rows = []
for name in ['compressed_tensors_cpu', 'compressed_tensors_cuda',
             'compressed_tensors_apple', 'iree_vulkan_runtime_patches']:
    entry = next(r for r in lock['dependencies'] if r['name'] == name)
    old = copy.deepcopy(entry)
    root = ROOT / entry['vendored']['path']
    sha, records = tree(root)
    entry['vendored']['tree_sha256'] = sha
    notice = next(r for r in entry['license']['files'] if r['path'].endswith('/NOTICE.md'))
    assert notice['root'] == 'hyle'
    notice['sha256'] = normalized(ROOT / notice['path'])
    rows.append(dict(name=name, before=old, after=copy.deepcopy(entry), tree_records=records))
    if name == 'compressed_tensors_cuda':
        cuda = read(S / 'cuda-lock-proposal.json')
        assert entry['vendored'] == cuda['proposed_replacement']['vendored']
        assert notice['sha256'] == next(r['sha256'] for r in cuda['proposed_replacement']['license']['files'] if r['path'].endswith('/NOTICE.md'))
    if name == 'compressed_tensors_apple':
        apple = read(S / 'apple/dependency-lock-proposal.json')
        assert entry['vendored'] == apple['vendored']
        assert notice['sha256'] == apple['notice']['sha256']

allowed = {r['name'] for r in rows}
for a, b in zip(original['dependencies'], lock['dependencies']):
    if a['name'] not in allowed:
        assert a == b
        assert a == next(r for r in actual['dependencies'] if r['name'] == a['name'])
lock_path.write_text(json.dumps(lock, indent=2) + '\n', encoding='utf-8')
files = []
for p in [lock_path, manifest_path, ROOT / 'third_party/iree_vulkan_runtime/NOTICE.md']:
    saved = S / 'metadata-source' / p.relative_to(ROOT)
    saved.parent.mkdir(parents=True, exist_ok=True)
    saved.write_bytes(p.read_bytes())
    files.append(dict(source=str(p), before=before.get(str(p.relative_to(ROOT))),
                      after=ident(p), retained_after=ident(saved)))
(S / 'metadata-update.json').write_text(json.dumps(dict(files=files, dependencies=rows,
    origin_revisions_changed=False, non_artifact_vmfb_changed=False), indent=2) + '\n', encoding='utf-8')
print('METADATA_UPDATED', ', '.join(r['name'] for r in rows))
