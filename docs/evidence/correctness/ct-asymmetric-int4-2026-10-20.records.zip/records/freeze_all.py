"""Collect the actual shared addition without touching unrelated working-tree edits."""
from pathlib import Path
import difflib
import hashlib
import json
S = Path(__file__).resolve().parent
ROOT = S.parents[2]

def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))

def identity(path):
    p = Path(path).resolve()
    data = p.read_bytes()
    return dict(path=str(p), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())

files = {}
for marker in ['root-source-freeze.json', 'cuda-source-freeze.json',
               'vulkan/source-freeze.json', 'metadata-update.json']:
    for r in read(S / marker)['files']:
        source = Path(r['source']).resolve()
        expected = r['after']
        actual = identity(source)
        assert actual['sha256'] == expected['sha256'] and actual['bytes'] == expected['bytes'], source
        files[source] = dict(source=actual, before=r.get('before'))
apple = read(S / 'apple/source-freeze.json')
for r in apple['after']:
    source = ROOT / r['path']
    actual = identity(source)
    assert (actual['sha256'], actual['bytes']) == (r['sha256'], r['bytes'])
    before = identity(S / 'apple/before' / r['path'])
    files[source.resolve()] = dict(source=actual, before=before)
diffs = []
for path, row in sorted(files.items(), key=lambda t: str(t[0])):
    relative = path.relative_to(ROOT)
    snapshot = S / 'source' / relative
    snapshot.parent.mkdir(parents=True, exist_ok=True)
    snapshot.write_bytes(path.read_bytes())
    row['snapshot'] = identity(snapshot)
    before = row['before']
    if before:
        raw_before = Path(before['path']).read_text(encoding='utf-8-sig').splitlines(keepends=True)
    else:
        raw_before = []
    diffs.extend(difflib.unified_diff(raw_before, path.read_text(encoding='utf-8-sig').splitlines(keepends=True),
        fromfile=('before/' if before else 'unrecorded-before/') + relative.as_posix(),
        tofile='current/' + relative.as_posix()))
(S / 'changes.diff').write_text(''.join(diffs), encoding='utf-8')
(S / 'source-freeze.json').write_text(json.dumps(dict(files=list(files.values()),
    new_descriptor=False, appended_artifact_format=True, graph_executor_changed=False,
    shared_runtime_ABI_changed=False, actual_artifact_payload_read=False,
    scope='Cold dense decode only, not packed INT4 MatMul/FFN'), indent=2) + '\n', encoding='utf-8')
print('CT_SOURCE_FROZEN', len(files))
