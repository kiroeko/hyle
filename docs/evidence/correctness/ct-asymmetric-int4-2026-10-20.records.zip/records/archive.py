"""Archive retained sources, actual commands/results and maps once; never build or delete."""
from pathlib import Path
import hashlib
import json
import zipfile
S = Path(__file__).resolve().parent
ROOT = S.parents[2]
DEST = ROOT / 'docs/evidence/correctness/ct-asymmetric-int4-2026-10-20.zip'
OWN = {'archive-receipt.json', 'archive-inventory.json'}
OMIT = {'.exe', '.obj', '.o', '.lib', '.a', '.exp', '.dll', '.pdb', '.pyc',
        '.bf16', '.f32', '.f16', '.zip', '.gz', '.tmp'}

def sha(data):
    return hashlib.sha256(data).hexdigest()

def ident(p):
    p = Path(p).resolve()
    data = p.read_bytes()
    return dict(path=str(p), bytes=len(data), sha256=sha(data))

assert json.loads((S / 'summary.json').read_text(encoding='utf-8'))['passed']
assert not DEST.exists(), 'No implicit archive overwrite'
paths = [p for p in sorted(S.rglob('*')) if p.is_file() and p.name not in OWN
         and p.suffix.lower() not in OMIT and not any(x in p.relative_to(S).parts for x in ('tmp', '__pycache__'))]
records = []
with zipfile.ZipFile(DEST, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for p in paths:
        key = p.relative_to(S).as_posix()
        data = p.read_bytes()
        archive.writestr(key, data)
        records.append(dict(path=key, bytes=len(data), sha256=sha(data)))
    manifest = json.dumps(dict(files=records, excluded_suffixes=sorted(OMIT),
        source_scope='Current batch, including original failures and final corrections',
        duplicate_vectors='Per-vector exact hashes and retained original reference identities remain in correctness/summary.json'), indent=2).encode()
    archive.writestr('payload-manifest.json', manifest)
# One complete read verifies both zipfile CRC and each payload SHA.
with zipfile.ZipFile(DEST) as archive:
    for row in records:
        data = archive.read(row['path'])
        assert len(data) == row['bytes'] and sha(data) == row['sha256']
    assert archive.read('payload-manifest.json') == manifest
receipt = dict(archive=ident(DEST), payload_entries=len(records),
    manifest_entries=1, CRC_and_each_payload_SHA_verified_once=True,
    retained_maps=True, binaries_and_duplicate_vectors_archived=False)
(S / 'archive-receipt.json').write_text(json.dumps(receipt, indent=2) + '\n', encoding='utf-8')
(ROOT / 'docs/evidence/correctness/ct-asymmetric-int4-2026-10-20-archive.json').write_text(
    json.dumps(receipt, indent=2) + '\n', encoding='utf-8')
public = json.loads((S / 'summary.json').read_text(encoding='utf-8'))
public['archive'] = receipt
(ROOT / 'docs/evidence/correctness/ct-asymmetric-int4-2026-10-20.json').write_text(
    json.dumps(public, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')
print('CT_ARCHIVED', receipt['archive']['bytes'], 'bytes', len(records), 'payloads', receipt['archive']['sha256'])
