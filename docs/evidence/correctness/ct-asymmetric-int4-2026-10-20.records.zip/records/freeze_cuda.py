"""Freeze this CUDA owner only; no compiler, GPU or central lock mutation."""
import difflib
import hashlib
import json
import shutil
from pathlib import Path

STAGE = Path(__file__).resolve().parent
ROOT = STAGE.parents[2]


def identity(path):
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())


def normalized(data):
    return hashlib.sha256(data.replace(b"\r\n", b"\n").replace(b"\r", b"\n")).hexdigest()


def save(name, value):
    (STAGE / name).write_text(json.dumps(value, indent=2) + "\n", encoding="utf-8")


before = json.loads((STAGE / "cuda-before.json").read_text(encoding="utf-8"))
diff = []
rows = []
for row in before["files"]:
    rel = row["source"]
    original = Path(row["before"]["path"])
    assert identity(original) == row["before"]
    source = ROOT / rel
    target = STAGE / "cuda-source" / rel
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(source, target)
    diff += difflib.unified_diff(original.read_text(encoding="utf-8").splitlines(True),
                                source.read_text(encoding="utf-8").splitlines(True),
                                fromfile="before/" + rel, tofile="after/" + rel)
    rows.append(dict(source=str(source), before=row["before"], after=identity(target)))
(STAGE / "cuda-changes.diff").write_text("".join(diff), encoding="utf-8")

vendor = ROOT / "third_party/compressed_tensors_cuda"
tree_files = sorted((p for p in vendor.rglob("*") if p.is_file()),
                    key=lambda p: p.relative_to(vendor).as_posix())
old_manifest, new_manifest, entries = "", "", []
for p in tree_files:
    rel = p.relative_to(vendor).as_posix()
    old_path = STAGE / "cuda-before/third_party/compressed_tensors_cuda" / rel
    old_sha = normalized((old_path if old_path.exists() else p).read_bytes())
    new_sha = normalized(p.read_bytes())
    old_manifest += f"{rel}|{old_sha}\n"
    new_manifest += f"{rel}|{new_sha}\n"
    entries.append(dict(path=rel, normalized_sha256=new_sha, raw=identity(p)))
old_lock = json.loads((STAGE / "cuda-lock-before.json").read_text(encoding="utf-8"))
assert hashlib.sha256(old_manifest.encode()).hexdigest() == old_lock["vendored"]["tree_sha256"]
notice = normalized((vendor / "NOTICE.md").read_bytes())
new_lock = json.loads(json.dumps(old_lock))
new_lock["version"] = "original-cuda-recipes-ac8e2ba82f4e-ct-asymmetric4"
new_lock["vendored"]["tree_sha256"] = hashlib.sha256(new_manifest.encode()).hexdigest()
next(x for x in new_lock["license"]["files"] if x["path"].endswith("/NOTICE.md"))["sha256"] = notice
save("cuda-lock-proposal.json", dict(name=old_lock["name"], before=old_lock,
     proposed_replacement=new_lock, normalized_tree_entries=entries,
     method="HyleDependencyVersions.cmake:214-237; case-sensitive relative path sort, LF-normalized SHA256 files, path|sha\\n manifest.",
     old_tree_matches_existing_lock=True, central_lock_modified=False,
     ggml_CUDA_patch_manifest_modified=False))

helper = (vendor / "compressed_tensors_cuda.h").read_text(encoding="utf-8")
provider = (ROOT / "src/compute_provider_torch_cuda/artifact_provider.cc").read_text(encoding="utf-8")
old_provider = (STAGE / "cuda-before/src/compute_provider_torch_cuda/artifact_provider.cc").read_text(encoding="utf-8")
assert provider.count("decode_asymmetric4(") == 1
assert provider.count("kCompressedTensorsAsymmetric4") == 2
assert provider[provider.index("constexpr ProviderRuntimeProperties kRuntime"):provider.index("struct Context final")] == old_provider[old_provider.index("constexpr ProviderRuntimeProperties kRuntime"):old_provider.index("struct Context final")]
assert "auto centered = signed_codes - signed_zero.unsqueeze(-1);" in helper
assert "return (centered * scale.unsqueeze(-1)).flatten(-2);" in helper
save("cuda-source-freeze.json", dict(files=rows,
    shared_fixture=identity(ROOT / "tests/compute_models/ct_asymmetric_int4_fixture.h"),
    diff=identity(STAGE / "cuda-changes.diff"), lock_proposal=identity(STAGE / "cuda-lock-proposal.json"),
    fresh_translation_units=["src/compute_provider_torch_cuda/artifact_provider.cc", "tests/graph_route_cuda/artifact_test.cc"],
    root_header_owners="Root refreshes all actual model_ops.h owners from the selected CPU/CUDA link closure.",
    tests=["OriginalPrecision/CudaArtifactLifecycle.ChangedPayloadTwoSlotsAndAcceptedWorkSurvivesOwnerClose/12", "OriginalPrecision/CudaArtifactLifecycle.ChangedPayloadTwoSlotsAndAcceptedWorkSurvivesOwnerClose/13", "OriginalPrecision/CudaArtifactLifecycle.ChangedPayloadTwoSlotsAndAcceptedWorkSurvivesOwnerClose/14", "CudaArtifactDecode.CtAsymmetricAxesPaddingAndSourceRoundingSurviveRebinding"],
    source_checks=dict(runtime_and_program_layout_unchanged=True,
                       explicit_asymmetric_case=True, AWQ_order_still_AWQ_only=True,
                       source_type_subtract_then_multiply=True, final_output_conversion_in_provider=True),
    limits="No build, backend execution or GPU. The existing eager ATen source-type operation boundaries are retained; the added numerical/lifetime tests remain unrun."))
print(json.dumps({p: identity(STAGE / p) for p in ["cuda-source-freeze.json", "cuda-changes.diff", "cuda-lock-proposal.json"]}, indent=2))
