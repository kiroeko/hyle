from pathlib import Path
import hashlib
import json
import subprocess

S = Path(__file__).resolve().parent
ROOT = S.parents[2]
source = (ROOT / 'cmake/HyleDependencyVersions.cmake').read_text()
start = source.index('function(_hyle_dependency_normalized_sha256 ')
end = source.index('endfunction()', start) + len('endfunction()')
script = 'cmake_policy(SET CMP0053 NEW)\n' + source[start:end] + '\n'
root = ROOT / 'third_party/iree_vulkan_runtime'
output = S / 'iree-cmake-files.tsv'
script += f'''
file(GLOB_RECURSE files LIST_DIRECTORIES false RELATIVE "{root.as_posix()}" "{root.as_posix()}/*")
list(SORT files)
set(manifest "")
foreach(relative IN LISTS files)
  _hyle_dependency_normalized_sha256("{root.as_posix()}/${{relative}}" sha)
  string(APPEND manifest "${{relative}}|${{sha}}\\n")
endforeach()
file(WRITE "{output.as_posix()}" "${{manifest}}")
string(SHA256 tree "${{manifest}}")
message(STATUS "TREE=${{tree}}")
'''
path = S / 'check-tree.cmake'
path.write_text(script)
result = subprocess.run(['cmake', '-P', str(path)], cwd=ROOT, capture_output=True, text=True)
(S / 'check-tree.stdout.log').write_text(result.stdout)
(S / 'check-tree.stderr.log').write_text(result.stderr)
assert result.returncode == 0, result.stderr
print(result.stdout.strip())
current = json.loads((S / 'metadata-update.json').read_text())
rows = next(r for r in current['dependencies'] if r['name'] == 'iree_vulkan_runtime_patches')
python = {line.strip().rsplit('|', 1)[0]: line.strip().rsplit('|', 1)[1] for line in rows['tree_records']}
cmake = dict(line.rsplit('|', 1) for line in output.read_text().splitlines())
diff = dict(only_python=sorted(set(python) - set(cmake)),
            only_cmake=sorted(set(cmake) - set(python)),
            different=[dict(path=p, python=python[p], cmake=cmake[p])
                for p in python.keys() & cmake.keys() if python[p] != cmake[p]])
(S / 'tree-difference.json').write_text(json.dumps(diff, indent=2) + '\n')
print(json.dumps(diff))
