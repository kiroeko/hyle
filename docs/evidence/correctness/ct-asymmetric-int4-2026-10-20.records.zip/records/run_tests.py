"""Run one selected current closure; Windows GPU callers must serialize this script."""
from pathlib import Path
import argparse
import importlib.util
import sys
import xml.etree.ElementTree as ET

sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('ct_test_helpers', S.parent / 'view-projection-reuse/build.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
b, c = module.b, module.c
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('link_plan', type=Path)
parser.add_argument('image', type=Path)
parser.add_argument('filter')
parser.add_argument('--count', type=int, required=True)
parser.add_argument('--name', required=True)
args = parser.parse_args()
assert Path(args.name).name == args.name
out = S / 'tests' / args.name
out.mkdir(parents=True, exist_ok=False)
(out / 'tmp').mkdir()
link_path = args.link_plan.resolve()
link = c.read(link_path)
image = b.identity(args.image.resolve())
for row in link['inputs']:
    assert b.same(row), row['path']
env, runtime = b.environment(link['command'], [r['path'] for r in link['inputs']], out)
c.save(out / 'runtime.json', dict(link_plan=b.identity(link_path), image=image,
    runtime_library_directories=runtime, selected_closure_only=True))
try:
    c.execute('tests', [image['path'], '--gtest_filter=' + args.filter,
        '--gtest_output=xml:' + str(out / 'results.xml')], env, out)
finally:
    cases = ET.parse(out / 'results.xml').findall('.//testcase') if (out / 'results.xml').exists() else []
    actual = [r.attrib['classname'] + '.' + r.attrib['name'] for r in cases]
    passed = (len(cases) == args.count and len(set(actual)) == len(actual) and
              all(r.find(t) is None for r in cases for t in ('failure', 'error', 'skipped')))
    c.save(out / 'summary.json', dict(passed=passed, cases=len(cases), expected_count=args.count,
        names=actual, skipped=sum(r.find('skipped') is not None for r in cases), image=image,
        link_plan=b.identity(link_path), filter=args.filter))
assert passed, 'Inspect retained actual result XML/logs'
print('CT_TESTS', args.name, len(cases), 'passed', flush=True)
