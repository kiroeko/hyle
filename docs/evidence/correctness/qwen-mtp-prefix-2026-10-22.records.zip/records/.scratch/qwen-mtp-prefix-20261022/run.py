"""Finite real MTP bounded admission/prefix CLI cases, no timing window."""
from pathlib import Path
import argparse,importlib.util,json,os,sys
sys.dont_write_bytecode=True
Y=Path(__file__).resolve().parent;R=Y.parents[1]
s=importlib.util.spec_from_file_location('build',Y/'build_hyle.py');h=importlib.util.module_from_spec(s);s.loader.exec_module(h);b,c=h.b,h.c

def prepare():
 f=Y/'fixtures';f.mkdir(exist_ok=False)
 original=list(map(int,(R/'.scratch/qwen-mtp-weights-20261022/prepared/prompt.ids').read_text().split()))
 for name,ids in [('p15',original[:15]),('p16',original[:15]+[original[16]]),('p23',original[:23])]:
  d=f/name;d.mkdir();os.link(R/'.scratch/qwen-mtp-weights-20261022/prepared/weights.tsv',d/'weights.tsv')
  (d/'prompt.ids').write_text(' '.join(map(str,ids))+'\n')
  (f/(name+'.txt')).write_text(f'prompt {name}/prompt.ids\n')
 (f/'original.txt').write_text('A p15.txt\nB p23.txt\n')
 (f/'repeat.txt').write_text('A p15.txt\nB p15.txt\nC p15.txt\n')
 (f/'partials.txt').write_text('A p15.txt\nB p16.txt\nC p23.txt\n')
 ordinary=f/'ordinary';ordinary.mkdir();os.link(R/'.scratch/qwen-mtp-window-20261022/inputs/text/weights.tsv',ordinary/'weights.tsv')
 (ordinary/'prompt.ids').write_text(' '.join(map(str,original[:23]))+'\n')
 (f/'fixed.txt').write_text('prompt p15/prompt.ids\ndecode p16/prompt.ids\n')

def run(name,args,probe=False):
 ready=c.read(Y/('mtp_session-ready-attempt1.json' if probe else 'qwen-ready-attempt1.json'))
 assert all(h.same(ready[k])for k in('image','source','main'))
 out=Y/('probe-run1'if probe else'cli-runs1/'+name);out.mkdir(parents=True,exist_ok=False)
 command=[ready['image']['path'],*args]
 if probe:command+=['--output',str(out/'vectors')]
 else:command+=['--trace',str(out/'trace'),'--trace-level','full'if name=='queue-prefix-n2'else'decisions']
 env=os.environ.copy();env['PATH']=c.read(ready['runtime_environment']['path'])['PATH']
 c.save(out/'plan.json',dict(command=command,ready=ready,diagnostic=True,timing_evidence=False))
 c.execute('run',command,env,out)
 if not probe:c.save(out/'parsed.json',json.loads((out/'run.stdout.log').read_text().splitlines()[-1]))

def positive():
 f=Y/'fixtures';base=['--inputs',str(f/'p15'),'--mtp','on','--capacity','64','--progress','direct','--replay','auto']
 cases=[
  ('off-original',['--session-schedules',str(f/'original.txt'),'--steps','8','--max-sessions','2','--prefix-cache','off']),
  ('queue-prefix-n2',['--session-schedules',str(f/'repeat.txt'),'--steps','8','--max-sessions','2','--prefix-cache','auto']),
  ('whole-n1',['--session-schedules',str(f/'repeat.txt'),'--steps','1','--max-sessions','1','--prefix-cache','auto']),
  ('budget-queue-n1',['--session-schedules',str(f/'repeat.txt'),'--steps','4','--cache-bytes','59777075','--prefix-cache','auto']),
  ('partials-n3',['--session-schedules',str(f/'partials.txt'),'--steps','4','--max-sessions','3','--prefix-cache','auto']),
 ]
 for name,args in cases:run(name,base+args)
 run('single',['--inputs',str(f/'p15'),'--mtp','on','--capacity','64','--steps','4'])
 run('ordinary',['--inputs',str(f/'ordinary'),'--capacity','64','--steps','4'])

if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('mode',choices=['prepare','positive','probe']);a=p.parse_args()
 if a.mode=='prepare':prepare()
 elif a.mode=='positive':positive()
 else:run('prefix',['--inputs',str(R/'.scratch/qwen-mtp-weights-20261022/prepared'),'--scenario','prefix'],True)
