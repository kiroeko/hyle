"""Source-bound design for MTP admission/prefix aliases. No model execution."""
from pathlib import Path
import hashlib
import json

R = Path(__file__).resolve().parent
ROOT = R.parents[2]
Y = R.parent


def identity(path):
    raw = path.read_bytes()
    return dict(path=str(path.resolve()), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


before = Y / 'before/tools/qwen35_text/main.cc'
assert identity(before)['sha256'] == '48302bd77278df98db8882e32a305800db914089dcb22c1006cf4be2f6c5faeb'
paths = dict(main_before=before,
    prefix=ROOT / 'tools/qwen35_text/prefix_cache.h',
    state=ROOT / 'tools/qwen35_text/session_state.h',
    session_directory=ROOT / 'tools/qwen35_text/session_cache.h')
ids = {name: identity(path) for name, path in paths.items()}


def anchor(name, text):
    found = [i + 1 for i, line in enumerate(paths[name].read_text(encoding='utf-8').splitlines()) if text in line]
    if not found:
        raise ValueError(text)
    return dict(source=name, lines=found, text=text)


report = dict(
    status='Read-only design of the smallest consumer admission/prefix change. No new library mechanism is required for whole prompt and lag0 partial>=2; proposed T1 policy change is described separately, not signed as implemented.',
    reviewed_sources=ids,
    conclusions=[
        'Use one Model/shared families/current original episode helper. Keep unfinished resident Sessions protected and queue the rest. Never evict an unfinished MTP head and claim ordinary token replay can rebuild it.',
        'Directory aliases are expendable even when their Snapshot is an unfinished Session head. Remove the cache entry, not the live Session state. Hit pins are temporary lookup protection, not generation-long state permissions.',
        'At a retired boundary let L=actual VersionCount.live and D=0/1 for the selected R1 base that will really disappear after success. Require L<=N and L-D+1<=N before a graph. Candidate peak may be N+1; post-commit must return<=N.',
        'Whole-hit adopts the original complete lag0 Snapshot, emits its stored next_id and executes0Graph. Partial reuse imports the same complete state with no tail write caps, uses ordinary existing MTP prefill math and original target/draft COW.',
        'Only successful prompt lag0 boundaries enter this directory. No generated/lag1/multiturn checkpoint or generic MTP replay claim is included.'
    ],
    minimal_admission=[
        'Validate every prompt ID/context/output capacity before Model, including queued users. ResolveR=1. Choose effectiveN<=requested max_sessions and input count; explicit cache bytes may reduce N to the largest existing cache::plan(C,N,maxQ,payload,1,2,true) that fits. If even N1 cannot fit, reject before loading weights.',
        'Use existing request indexes and a bounded resident_count/pending cursor. A request becomes resident only after a prior done request has successfully stop/try_retire/reset its Session. Unfinished Sessions stay resident between visits. No separate executor/cache manager is needed.',
        'If the existing SessionCache is reused instead of a direct resident counter, keep its Pin across the entire unfinished request, or make retirement callback reject unfinished entries. Resetting a pin after every episode must not expose unfinished MTP state to LRU eviction. Pin count is admission protection, not simultaneous GPU width.',
        'On admission, resolve a prefix hit before evicting checkpoints. A hit creates no distinct Snapshot/zero-state allocations. A miss needs initial room L+1<=N, made only by unpinned checkpoint eviction and re-reading L. Protect existing unfinished Session heads; if no legal room exists, keep the incoming request queued.',
        'After each terminal episode save all host result/frontier stats. If done, perform original stop and actual try_retire before returning its resident slot. Native pending/error still keeps the same candidate, base and slot charged; queue admission cannot override the Model global loan.'
    ],
    exact_D_proof=dict(
        formula='R1: post_commit_distinct_versions = L + 1 - D, where D is0 or1. Check before constructing the candidate; do not use N+1 storage as a second committed-checkpoint allowance.',
        D1_conditions=[
            'No active_step/native loan exists at preflight.',
            'The selected Session is the only externally retained Session head pointing to this base.',
            'PrefixCache.retains(base) is false after any necessary evictions.',
            'Lookup Hit.snapshot/replay have been reset; no local SnapshotRef or user/probe checkpoint remains outside the enumerated owner set.',
            'The original successful publication drops member.base/old head before the host endpoint, as current Model does.'
        ],
        fallback='If an owner is unknown or intentionally escaped, conservatively useD0. The existing closed consumer can enumerate its Sessions/directory; do not generalize its owner proof to arbitrary external Snapshot handles.',
        prohibition='No shared_ptr/use_count test grants page write authority. D concerns immutable-version lifetime only; PagedPageAppender reservation and native page permissions retain their original independent checks.',
        source=[anchor('main_before', 'const auto make_batch_room ='), anchor('main_before', 'bool retained = prefix_cache->retains(base)'),
                anchor('main_before', 'Dropping a directory alias need not free a version'), anchor('state', 'Counts distinct immutable versions')]),
    alias_and_hit_order=[
        'Lookup pins the exact entry only while validating model/math/draft.lag0/length/next_id and preparing fallible host history/call metadata.',
        'create_session(remaining,prefix,role) adopts the existing Snapshot. Assign the returned Session and then immediately Hit.reset(); also drop any copied local prefix SnapshotRef. Do this before advance-room/D calculation.',
        'Evicting that directory entry is safe after adoption because the Session still owns the complete original Snapshot and page/read leases. It does not revoke any Session state or actual native owner.',
        'Publish by const reference to session->head after successful prompt completion. Avoid an extra generation-lived saved_prompt SnapshotRef in the request record: that would keep the old version even after directory eviction.',
        'Before every required checkpoint eviction repeat real L and the selected-base retainers/D test. evict_one may remove an alias without reducing L; size/eviction count is not a reclaimed-version count.'
    ],
    examples=[
        dict(N=1, case='A prompt head also retained by directory', L=1, D=0, post=2, allowed=False,
             action='Reset Hit/local aliases; evict directory entry only. A Session retains head. L stays1, D becomes1, so candidate peak2/post1 is legal.'),
        dict(N=1, case='Two unfinished Sessions alias the same prompt head', L=1, D=0, post=2, allowed=False,
             action='Never admit both into residentN1 merely because L=1. Queue the second; otherwise neither alias can advance withinN1.'),
        dict(N=2, case='A and B own distinct heads, no old checkpoints', L=2, D=1, post=2, allowed=True,
             action='One original R1 episode advances the selected head. Other unfinished Session remains untouched.'),
        dict(N=2, case='A old prompt checkpoint plus A current head; incoming B misses', L=2, D=None, post=3, allowed=False,
             action='Evict old prompt checkpoint to lowerL1, then create B initial head toL2. If it is externally retained, queue B rather than lying about capacity.'),
        dict(N=2, case='A and B alias one complete prompt; selected A advances', L=1, D=0, post=2, allowed=True,
             action='Shared old state persists for B. After the split, a later selected base may haveD1 only once all directory/Hit/other-head retainers are absent.'),
        dict(N=2, case='Two full resident heads plus any third distinct prompt checkpoint', L=3, D=None, post=None, allowed=False,
             action='That committed state must never be entered. Before the step creating it, release the checkpoint alias/version and recompute; N+1 is candidate-only.')
    ],
    prefix_API=dict(
        sufficient_now=['PrefixCache::lookup exact tokens/domain/longest actual boundary', 'Hit::reset',
                        'PrefixCache::retains', 'PrefixCache::evict_one', 'PrefixCache::publish',
                        'Model::create_session(prefix,role)', 'MtpPrefill existing shift for lag0 suffix>=2'],
        full_lookup='lookup(input,P,P,model,math) finds only a whole prompt checkpoint. Emit storednext_id, mark generated first token and complete metadata without preparing/evaluating a graph or inventing hidden/logits trace files.',
        legal_partial_before_T1_change='After a full miss, lookup(input,P-2,1,...) selects the longest boundary allowing suffix>=2, whenP>=3. A suffix1 longest entry must not accidentally hide an earlier valid partial boundary. Current actual Model can consume lag0 suffix>=2.',
        after_approved_T1_change='Once onlykMtpSingle permits arbitrary prompt IDs through finish_evaluation, use longest<=P; suffix1 uses the existing Single family. Preserve original pending-token policy in finish_mtp_round and CatchupSingle.',
        directory_integrity='Require the adopted head to match this Model/math, draft exists, lag0/frontier==length, valid carry and next_id. Directory keys are complete actual token sequences, never inferred radix split payloads.',
        replay_metadata='Existing ReplayHistory may describe actual prompt-chunk token coverage for publish validation. It is not executed as a generic MTP regeneration plan. Copy a hit history/append the true suffix chunk, or use one full prompt chunk only if that full prompt was actually evaluated as one chunk.',
        proof=[anchor('prefix', 'Hit lookup('), anchor('prefix', 'void reset() noexcept'), anchor('prefix', 'bool retains('),
               anchor('prefix', 'bool evict_one() noexcept'), anchor('prefix', 'bool publish('), anchor('main_before', 'if (prefix) session->head =')]),
    proposed_T1_responsibility_adjustment=dict(
        assessment='Approved minimal policy change is sound for lag0 arbitrary suffixT1; no Compute/Graph math, newGraphRole, device readback or executor is needed.',
        scope='Only kMtpSingle relaxes prepare host token==next_id. T2 draft/verify and kMtpCatchupSingle preserve current pending restriction; lag1 prompt remains out of scope.',
        first_input='StepState records actual validated host ids.front() once. MTP isR1, and this is the same scalar copied to the original fixed token carrier.',
        generation='finish_mtp_round selector after real terminal wait checks first_input==member.base->next_id before selection/publication. finish_evaluation performs teacher-forced prompt commit. A mismatch uses original abort cleanup, preserving oldhead/native retirement/charged permissions.',
        cancel='The scalar owns no resources and does not change14bank transaction, old completion identity, candidate admission, rollback, stop or actual retirement. No pending mismatch can publish a new head.',
        state='Design only in this report. Later final source and actual misuse/retry probe need their own binding; this report does not claim the approved change was run.'),
    library_gaps=dict(
        current_scope='No new public library API or Model math is required for bounded queue admission, prompt complete hits, lag0 partial>=2, or original COW. T1 needs only the approved consumer policy/validation move above.',
        excluded=['Lag1 multi-token prompt catchup', 'MTP multiturn/pending-token semantics',
                  'Eviction/rebuild of unfinished generated MTP state from ordinary history', 'MTP R2/grouped drafts',
                  'Unbounded checkpoints/external owner lifetime inference']),
    memory_and_measurement_limits=[
        'Device cache backings are shared and reserved by Model for its finiteN/R plan. Retiring a head/entry frees lease/page/version reuse, not necessarily the physical arena reservation or measured WDDM bytes.',
        'Weights, executable/provider workspace, capture allocations and OS/driver/other-process memory are not covered by cache backing bytes.',
        'When requests>N, later prefills can occur between earlier requests decode steps. Keep whole-session wall/output throughput and actual episode service accounting; the old last-prefill split is no longer a clean global P/D partition. Quant owns that measurement design.',
        'No product edits, builds, GPU/model computation, new runtime claims or quality thresholds in this review.'
    ])
assert all(identity(paths[name])['sha256'] == ids[name]['sha256'] for name in paths)
out = R / 'prefix-budget-design.json'
out.write_text(json.dumps(report, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')
freeze = R / 'prefix-budget-design-freeze.json'
freeze.write_text(json.dumps(dict(status='Frozen design/old48302 source review; proposed T1/newCLI unbuilt/unrun.',
    files=[identity(out), identity(Path(__file__))]), indent=2) + '\n', encoding='utf-8')
print(json.dumps(dict(report=identity(out), freeze=identity(freeze)), indent=2))
