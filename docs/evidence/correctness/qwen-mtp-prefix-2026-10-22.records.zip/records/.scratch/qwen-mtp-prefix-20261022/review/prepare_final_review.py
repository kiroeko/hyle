"""Final source/record-binding review. Does not rerun C++ or tensor math."""
from pathlib import Path
import hashlib
import json

R = Path(__file__).resolve().parent
ROOT = R.parents[2]
Y = R.parent


def identity(path):
    raw = path.read_bytes()
    return dict(path=str(path.resolve()), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


def unique(items):
    result = {}
    for key, value in items:
        if key in result:
            raise ValueError('duplicate JSON key: ' + key)
        result[key] = value
    return result


def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'), object_pairs_hook=unique)


main = ROOT / 'tools/qwen35_text/main.cc'
probe = ROOT / 'tools/qwen35_text/mtp_session_probe.cc'
main_id, probe_id = identity(main), identity(probe)
assert main_id['sha256'] == '7999f84732801feffa3fcaf99c8796ae810c3b006b06bc54247194d79ed81c77'
assert probe_id['sha256'] == '35b8e49f2013b2da871ddc4d7b9f8de4f60ae2e8e2839bb8fd2568f5e6fdf125'
assert read(Y / 'source-freeze.json')['source']['sha256'] == main_id['sha256']
assert read(Y / 'implementation/source-freeze.json')['source']['sha256'] == probe_id['sha256']
texts = dict(main=main.read_text(encoding='utf-8'), probe=probe.read_text(encoding='utf-8'))
old = (Y / 'before/tools/qwen35_text/main.cc').read_text(encoding='utf-8')
single = lambda text: text[text.index('int run_mtp(Model'):text.index('int run_mtp_sessions(')]
ordinary = '    // These owners are declared after Model'
assert single(old) == single(texts['main'])
assert old[old.index(ordinary):] == texts['main'][texts['main'].index(ordinary):]


def anchor(owner, needle):
    lines = [n + 1 for n, line in enumerate(texts[owner].splitlines()) if needle in line]
    if not lines:
        raise ValueError(f'{owner}: {needle}')
    return dict(file=owner, lines=lines, text=needle)


run = Y / 'probe-run1'
terminal = read(run / 'run.result.json')
assert terminal['terminal'] and terminal['exit'] == 0
stdout = read(run / 'run.stdout.log')
observation_path = run / 'vectors/observation.json'
obs = read(observation_path)
assert stdout['vectors'] == len(obs['vectors']) == 534
assert obs['actual_graph_calls'] == stdout['actual_graph_calls'] == 15
assert obs['full_hits'] == 3 and obs['full_hit_head_vectors'] == 3 * 52
assert obs['negative_rejected'] and obs['negative_bound_banks'] == 14 and obs['retry_same_carrier_slot']
assert (obs['negative_versions_before'], obs['negative_versions_pending'], obs['negative_versions_after']) == (1, 2, 1)
assert obs['final_live_snapshot_versions'] == 0 and obs['peak_live_snapshot_versions'] == 3
assert obs['managed_backing_bytes'] == obs['planned_backing_bytes'] == 80240691
assert all(v['byte_equal'] and v['nonfinite_baseline'] == v['nonfinite_actual'] == 0 for v in obs['vectors'])
categories = dict(baseline_seed_reuse=0, whole_hit_head=0, cached_commits=0)
for record in obs['vectors']:
    name = record['name']
    if name.startswith('baseline_'):
        categories['baseline_seed_reuse'] += 1
    elif '/full_hit/' in name:
        categories['whole_hit_head'] += 1
    else:
        categories['cached_commits'] += 1
assert categories == dict(baseline_seed_reuse=108, whole_hit_head=156, cached_commits=270)

report = dict(
    status='Final narrow static review: no blocking finding. Root actual exit0 and persisted comparison structure are bound; no new native execution or independent tensor recomputation by reviewer.',
    sources=dict(main=main_id, probe=probe_id),
    freezes=[identity(Y / 'source-freeze.json'), identity(Y / 'implementation/source-freeze.json')],
    unchanged=dict(legacy_run_mtp_function_byte_unchanged=True, ordinary_driver_body_byte_unchanged=True),
    main_findings=[
        dict(subject='N/L/D budget and owner set', finding='make_mtp_room uses actual VersionCount.live, rejects non-retired/over-N states, and treats a base as releasable only when neither directory nor another enumerated Session retains it. Every eviction re-evaluates L/D. Its closed owner-set assumption is truthful here: request metadata contains no saved SnapshotRef, and lookup Hit is moved/reset before the gate. Evicting a directory alias never stops an unfinished Session.',
             anchors=[anchor('main','void make_mtp_room('), anchor('main','bool external = prefix->retains'),
                      anchor('main','while (!fits())'), anchor('main','hit.reset(); // No hidden temporary')]),
        dict(subject='Queued admission and real retirement', finding='The active request-index vector is bounded by resident_sessions and unfinished entries are never evicted/replayed. New FIFO admission occurs only with a free resident slot. A done Session performs stop/try_retire/reset before its active entry is erased. Model global admission still prevents a new episode while any old native owner remains. Explicit bytes can resolve a smaller finiteN>=1 before Model, so excess requests queue instead of ordinary replay.',
             anchors=[anchor('main','active.size() < model.cache_plan.resident_sessions'), anchor('main','retire_mtp_request(request); ++completed'),
                      anchor('main','selected_cache = plan_for(low)')]),
        dict(subject='Whole/partial checkpoints and permissions', finding='Lookup uses exact token/domain boundaries. Whole-hit adopts the existing complete lag0 Snapshot without an empty state or Graph; it returns storednext_id and only cache-hit metadata, never fake output tensors. Partial uses create_session(prefix) with no inherited target/draft appender caps and original lag0 MTP family. Common arena/COW and bounded frame guard checks remain authoritative. Only successful prompt-lag0 heads are published; no generated checkpoint or lag1/multiturn path is silently accepted.',
             anchors=[anchor('main','auto hit = prefix->lookup'), anchor('main','std::move(hit.snapshot)'),
                      anchor('main','only a complete lag0 MTP prompt'), anchor('main','tensor_payload_available')]),
        dict(subject='Cold suffix coverage and stable IO', finding='Every nominal prompt shape plus exact suffix from an earlier matching prompt is in the finite union before any carrier. P1/suffix1 uses one Single family; T>=2 uses Prefill. All role use plans precede the first warmup; only first actual prefill is prewarmed and other actual parity slots initialize naturally. No runtime branch creates another executor or per-session weight/plan copy.',
             anchors=[anchor('main','Only earlier real prompt checkpoints'), anchor('main','prefill_uses[tokens == 1'),
                      anchor('main','const std::array first_prefill{')]),
        dict(subject='Single prompt policy versus generation selector', finding='Only kMtpSingle relaxes the prepare pending-token restriction; CatchupSingle/T2 retain it and all lag/frontier/ID checks remain. StepState records the actual validated host first_input copied to the original carrier. finish_mtp_round checks it against the immutable base next_id inside the original post-wait selector, before output export/take/head publication. A mismatch is caught by the original finish abort path; finish_evaluation is the explicit teacher-forced prompt route.',
             anchors=[anchor('main','role != GraphRole::kMtpSingle &&'), anchor('main','step.first_input = requests.front().ids.front()'),
                      anchor('main','if (step.first_input != step.members[0].base->next_id)'),
                      anchor('main','check(step.completion.wait())')]),
        dict(subject='Endpoints and ledger', finding='Legacy single prepare/host-endpoint function is unchanged. Multi P/D now partitions disjoint continuous intervals through actual token-visible endpoints by the episode kind, including coordinator gaps; it no longer pretends the last prefill precedes every decode. Global full wall remains one interval, request latencies are not summed. Full hits count0Graph/0actual prompt rows, while logical prompt/reused tokens remain separately visible. Final stats use saved host fields after Session reset.',
             anchors=[anchor('main','Disjoint continuous intervals'), anchor('main','post_endpoint_seconds'),
                      anchor('main','request.prefill_graph_calls = 1'), anchor('main','logical_prompt_tokens')])
    ],
    probe_findings=[
        dict(subject='Source baseline and complete state oracle', finding='One335 Model/N2/R1 uses an actual P15 directory seed whose producer is truly retired. Checkpoint oracle is CPU HeadImage, not an escaped SnapshotRef. Each independently initialized baseline is retired before the next. Old baseline data are reused only after full byte comparison; metric counts do not imply534 unique tensors.',
             anchors=[anchor('probe','const auto checkpoint = image'), anchor('probe','retire_prefix_session(producer)'),
                      anchor('probe','saved.vectors = cases[0].baseline[0].vectors')]),
        dict(subject='52 head versus54 executed outputs', finding='image reads36conv/GDN leases,12targetKV+2draftKV logical prefixes and2carry/prior leases. logical_rows selects the real guard from the original frame/arena and reads only committed rows in logical order. Full-hit compares only52 head components, no stale shared Phase outputs. An actual commit additionally reads original full hidden/logits after finish and before another prepare, yielding54 components.',
             anchors=[anchor('probe','Bytes logical_rows('), anchor('probe','selected->view()'),
                      anchor('probe','reference_head.vectors.resize(52)'), anchor('probe','auto captured = image')]),
        dict(subject='COW and old bytes', finding='Imported Session target/draft appender arrays are asserted empty, so no mutable tail capability is copied from the checkpoint. Common Graph append must use fresh COW for the partial page. Directory old head metadata/physicalIDs/all52 bytes are rechecked through a temporary Hit which dies before further prepare. Each case uses the same actual input partition, including T1 source[16] instead of monolithicP16/P23 comparisons.',
             anchors=[anchor('probe','prefix adoption imported exclusive tail authority'), anchor('probe','const auto check_old ='),
                      anchor('probe','suffix1 = std::span(source).subspan(16,1)')]),
        dict(subject='Submitted negative and safe same-slot retry', finding='Teacher248045 is intentionally different from cached pending198. All14banks are bound and submitted before misuse of finish_mtp_round. The guard throws after original native wait. Probe verifies no published head, original52 values/metadata, unchanged page-policy counts and parity, empty pending/global loan, and restored version count. A new prepare rebuilds the same carrier-slot object and finish_evaluation commits; this is not reuse of a rejected Completion or an unretired native artifact.',
             anchors=[anchor('probe','observation.negative_bound_banks == 14'), anchor('probe','try { (void)model.finish_mtp_round'),
                      anchor('probe','same(before,image(model,*session->head))'), anchor('probe','session->pending->run == retry_slot')]),
        dict(subject='Evidence on mismatch', finding='The new prefix scenario saves actual vectors plus metadata before rejecting a structural transition mismatch. Numerical differences retain actual raw; byte-equal comparisons reference one saved baseline payload. Existing default sessions scenario is preserved separately; its previously documented failure-evidence limitation is not silently rewritten.',
             anchors=[anchor('probe','output / "transition_differences"'), anchor('probe','write(directory / blob.name')])
    ],
    observed_record_binding=dict(
        terminal=identity(run / 'run.result.json'), stdout=identity(run / 'run.stdout.log'), observation=identity(observation_path),
        note='Read recorded structure/counts and finite/byte-equality flags only; not a second534-raw tensor computation.',
        actual_graph_calls=15, graph_accounting=dict(seed=1, sequential_baselines=8, cached_successful_commits=5, submitted_negative=1),
        metric_pairs=534, metric_accounting=categories, whole_hit_head_vectors=156,
        old_prefix_full_checks=obs['old_prefix_full_byte_checks'], candidate_peak=3, final_versions=0,
        negative_versions=[1,2,1], negative_error=obs['negative_error'], same_slot_retry=True,
        physical_shared_backing_bytes=80240691),
    limits=[
        'L/D proof assumes this consumer-owned closed set. Arbitrary external Snapshot handles are not inferred or authorized by pointer counts.',
        'Directory checkpoints and page permissions remain actual owned resources; dropping metadata does not promise physical VRAM release. Cache budget excludes weights/provider workspace/captures/driver memory.',
        'Only lag0 prompt checkpoints and R1 episodes are supported. No lag1 prompt, multiturn, generated-state replay, MTP R2, multi-device/serving QoS, quality threshold or throughput improvement claim.',
        'Root has separate CLI actual runs. This source review neither reruns nor silently expands them; no build/GPU/product/document modification by reviewer.'
    ],
    prior_design=identity(R / 'prefix-budget-design.json'))
assert identity(main)['sha256'] == main_id['sha256'] and identity(probe)['sha256'] == probe_id['sha256']
out = R / 'final-source-review.json'
out.write_text(json.dumps(report, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')
freeze = R / 'final-source-review-freeze.json'
freeze.write_text(json.dumps(dict(status='Final source/receipt-bound read-only review, no new native validation.',
    files=[identity(out), identity(Path(__file__))]), indent=2) + '\n', encoding='utf-8')
print(json.dumps(dict(report=identity(out), freeze=identity(freeze)), indent=2))
