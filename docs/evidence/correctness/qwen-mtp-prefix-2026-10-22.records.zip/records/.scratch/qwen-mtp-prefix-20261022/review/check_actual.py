"""Host-only raw/ZIP, work-ledger and clock checks of the finite MTP batch."""
from pathlib import Path
import argparse
import hashlib
import json
import math
import zipfile
import numpy as np

HERE = Path(__file__).resolve().parent
Y = HERE.parent
ROOT = Y.parents[1]


def load(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def identity(path):
    raw = path.read_bytes()
    return dict(path=str(path.resolve()), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


def scalar_values(raw, dtype):
    if dtype == 'BF16':
        assert len(raw) % 2 == 0
        return (np.frombuffer(raw,dtype='<u2').astype(np.uint32) << 16).view(np.float32)
    assert dtype == 'F32' and len(raw) % 4 == 0
    return np.frombuffer(raw,dtype='<f4')


def expected(meta):
    h = meta['head']; result = {}
    for layer in range(24):
        if layer % 4 != 3:
            result[f'layer{layer}.conv.bf16'] = ('BF16',36864)
            result[f'layer{layer}.gdn.f32'] = ('F32',1048576)
    for layer in range(6):
        for kind in ['key','value']:
            result[f'target{layer}.{kind}.bf16'] = ('BF16',h['length'] * 1024)
    for kind in ['key','value']:
        result[f'draft.{kind}.bf16'] = ('BF16',h['draft_frontier'] * 1024)
    result['carry.bf16'] = ('BF16',h['carry_bytes'])
    result['prior.bf16'] = ('BF16',h['prior_bytes'])
    rows = 2 if meta['role'] in [3,4] else 1
    result['output.logits.f32'] = ('F32',rows * 248320 * 4)
    result['output.hidden.bf16'] = ('BF16',rows * 4096)
    assert len(result) == 54
    return result


def norm(path):
    return str(path).replace('\\','/').casefold()


class OldArchive:
    def __init__(self):
        self.manifest_path = ROOT / 'docs/evidence/correctness/qwen-mtp-sessions-2026-10-22.json'
        self.manifest = load(self.manifest_path)
        self.zip = zipfile.ZipFile(self.manifest['archives'][0]['path'])
        self.files = {norm(row['path']):row for row in self.manifest['archive_files']}
        self.used = {}
    def read(self,relative):
        path = ROOT / '.scratch/qwen-mtp-sessions-20261022' / relative
        record = self.files[norm(path)]
        raw = self.zip.read(record['entry'])  # ZIP CRC checked by ZipFile.
        assert len(raw) == record['bytes'] and hashlib.sha256(raw).hexdigest() == record['sha256']
        self.used[norm(path)] = record
        return raw
    def json(self,relative):
        return json.loads(self.read(relative))


def timing(row):
    p,d,wall = [row[key] for key in ['prefill_seconds','decode_seconds','session_seconds']]
    assert p > 0 and d >= 0 and abs(p + d - wall) < 1e-12
    assert row['startup_total_seconds'] == row['startup_to_endpoint_seconds']
    assert row['startup_to_ready_seconds'] <= row['first_token_elapsed_seconds'] <= row['startup_to_endpoint_seconds']
    prompt = row.get('logical_prompt_tokens',row['prefill_target_rows'])
    assert math.isclose(row['prefill_tokens_per_second'],prompt/p,rel_tol=1e-12)
    assert math.isclose(row['output_tokens_per_second'],row['generated_tokens']/wall,rel_tol=1e-12)
    assert math.isclose(row['decode_output_tokens_per_second'],row['generated_decode_tokens']/d if d else 0,rel_tol=1e-12,abs_tol=1e-15)
    return dict(P=p,D=d,once_wall=wall,P_plus_D_minus_wall=p+d-wall,diagnostic=True,performance_evidence=False)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--output',type=Path,default=HERE/'actual-analysis.json')
    args = parser.parse_args()
    old = OldArchive()
    raw_manifest, comparisons = {}, []
    def inspect(path,dtype=None):
        path = path.resolve(); raw = path.read_bytes()
        if dtype is None: dtype = 'BF16' if path.suffix == '.bf16' else 'F32'
        vals = scalar_values(raw,dtype); assert np.isfinite(vals).all()
        raw_manifest[str(path)] = dict(**identity(path),dtype=dtype,elements=int(vals.size),nonfinite=0)
        return raw
    def equal(label,new_path,reference,old_reference=False):
        a = inspect(new_path)
        b = old.read(reference) if old_reference else Path(reference).read_bytes()
        assert a == b,(label,str(new_path),str(reference))
        dtype = 'BF16' if new_path.suffix == '.bf16' else 'F32'
        assert np.isfinite(scalar_values(b,dtype)).all()
        comparisons.append(dict(label=label,actual=str(new_path.resolve()),reference=str(reference),
            old_archive=old_reference,bytes=len(a),sha256=hashlib.sha256(a).hexdigest(),byte_equal=True,nonfinite=0))
    probe_dir = Y/'probe-run1'
    probe = load(probe_dir/'vectors/observation.json')
    probe_ready = load(Y/'mtp_session-ready-attempt1.json')
    probe_run = load(probe_dir/'run.result.json')
    assert probe_run['terminal'] and probe_run['exit'] == 0
    assert probe_run['command'][0] == probe_ready['image']['path']
    assert probe['status'] == 'PASS_BYTE_EXACT' and probe['scenario'] == 'prefix'
    assert probe['actual_graph_calls'] == 15 and len(probe['episodes']) == 13
    assert probe['full_hits'] == 3 and probe['full_hit_head_vectors'] == 156
    assert probe['old_prefix_full_byte_checks'] == 7 and probe['peak_live_snapshot_versions'] == 3 and probe['final_live_snapshot_versions'] == 0
    assert probe['managed_backing_bytes'] == probe['planned_backing_bytes'] == 80240691
    assert probe['negative_teacher_forced_input'] == 248045 and probe['cached_pending'] == 198
    assert probe['negative_rejected'] and probe['negative_error'] == 'MTP generation input differs from its original pending token'
    assert probe['negative_bound_banks'] == 14 and probe['retry_same_carrier_slot']
    assert (probe['negative_versions_before'],probe['negative_versions_pending'],probe['negative_versions_after']) == (1,2,1)
    baselines = {row['case']:row['steps'] for row in probe['baselines']}
    assert {key:len(value) for key,value in baselines.items()} == dict(whole=2,T1=3,T8=3)
    vector_records = {}
    for case,steps in baselines.items():
        for index,step in enumerate(steps):
            meta = step['metadata']; h = meta['head']
            assert h['draft_frontier'] + h['lag'] == h['length']
            assert h['carry_bytes'] == 4096 and h['prior_bytes'] == (4096 if h['lag'] else 0)
            inventory = expected(meta)
            assert len(step['vectors']) == 54 and {row['name'] for row in step['vectors']} == set(inventory)
            for row in step['vectors']:
                dtype,size = inventory[row['name']]
                assert (row['dtype'],row['bytes']) == (dtype,size)
                assert len(inspect(Path(row['path']),dtype)) == size
                vector_records[(case,index,row['name'])] = row
    assert len(raw_manifest) == 324
    assert baselines['T1'][1]['metadata']['inputs'] == [248045]
    assert len(baselines['T8'][1]['metadata']['inputs']) == 8
    references = [row for row in probe['episodes'] if row['reference']]
    branches = [row for row in probe['episodes'] if not row['reference']]
    assert len(references) == 8 and len(branches) == 5
    for episode in probe['episodes']:
        assert episode['metadata'] == baselines[episode['case']][episode['step']]['metadata']
    assert {(row['case'],row['step']) for row in branches} == {('whole',1),('T1',1),('T1',2),('T8',1),('T8',2)}
    categories = dict(seed_reuse=0,full_hit=0,branch=0)
    probe_pairs = []
    seen_metric_names = set()
    for metric in probe['vectors']:
        assert metric['name'] not in seen_metric_names
        seen_metric_names.add(metric['name'])
        case_name,part,component = metric['name'].split('/',2)
        case_name = case_name.removeprefix('baseline_')
        index = 0 if part == 'full_hit' else int(part.removeprefix('step'))
        counterpart = vector_records[case_name,index,component]
        assert (metric['baseline'],metric['dtype'],metric['bytes']) == (counterpart['path'],counterpart['dtype'],counterpart['bytes'])
        a,b = Path(metric['baseline']),Path(metric['actual'])
        raw_a,raw_b = a.read_bytes(),b.read_bytes()
        assert raw_a == raw_b and len(raw_a) == metric['bytes']
        assert np.isfinite(scalar_values(raw_a,metric['dtype'])).all()
        assert metric['byte_equal'] and not metric['nonfinite_baseline'] and not metric['nonfinite_actual']
        assert metric['max_abs'] == metric['squared_error'] == 0
        assert metric['actual_reuses_baseline_payload'] and a == b
        category = 'seed_reuse' if metric['name'].startswith('baseline_') else 'full_hit' if '/full_hit/' in metric['name'] else 'branch'
        categories[category] += 1
        if category == 'full_hit': assert 'output.' not in metric['name']
        probe_pairs.append(dict(name=metric['name'],baseline=str(a),actual=str(b),bytes=len(raw_a),
            sha256=hashlib.sha256(raw_a).hexdigest(),canonical_byte_equal=True,actual_reuses_baseline_payload=True))
    assert categories == dict(seed_reuse=108,full_hit=156,branch=270) and len(probe_pairs) == 534
    source_probe = Y/'compile1/mtp_session/source/tools/qwen35_text/mtp_session_probe.cc'
    source_main = Y/'compile1/qwen/source/tools/qwen35_text/main.cc'
    assert identity(source_probe)['sha256'] == probe_ready['source']['sha256'] == '35b8e49f2013b2da871ddc4d7b9f8de4f60ae2e8e2839bb8fd2568f5e6fdf125'
    main_text = source_main.read_text()
    assert 'first_input' in main_text
    guard = main_text.index('MTP generation input differs from its original pending token')
    selector = main_text.rfind('finish_selected_evaluations(',0,guard)
    assert selector >= 0 and '[&]' in main_text[selector:guard]
    assert 'step.first_input' in main_text[selector:guard]

    names = ['off-original','queue-prefix-n2','whole-n1','budget-queue-n1','partials-n3','single','ordinary']
    results,processes = {},[]
    ready = load(Y/'qwen-ready-attempt1.json')
    assert identity(source_main)['sha256'] == ready['source']['sha256'] == probe_ready['main']['sha256']
    for name in names:
        directory = Y/'cli-runs1'/name
        terminal,plan,row = load(directory/'run.result.json'),load(directory/'plan.json'),load(directory/'parsed.json')
        assert terminal['terminal'] and terminal['exit'] == 0 and terminal['command'] == plan['command']
        assert plan['ready'] == ready and plan['diagnostic'] and not plan['timing_evidence']
        assert json.loads((directory/'run.stdout.log').read_text()) == row
        results[name] = row
        processes.append(dict(name=name,terminal=identity(directory/'run.result.json'),parsed=identity(directory/'parsed.json'),
            stdout=identity(directory/'run.stdout.log'),stderr=identity(directory/'run.stderr.log'),timing=timing(row)))
        for file in (directory/'trace').rglob('*'):
            if file.suffix in ['.bf16','.f32']: inspect(file)
        if 'sessions' in row:
            sessions = [r['result'] for r in row['sessions']]
            assert row['admitted_requests'] == row['retired_requests'] == row['session_count']
            assert row['peak_resident_requests'] <= row['max_sessions'] and row['peak_committed_versions'] <= row['max_sessions']
            assert row['live_committed_versions'] <= row['max_sessions']
            assert row['logical_dispatches'] == len(row['dispatch'])
            assert row['actual_graph_calls'] + row['prefix_full_hits'] == row['logical_dispatches']
            assert row['prefill_target_rows'] + row['reused_tokens'] == row['logical_prompt_tokens']
            assert row['phase_timing'] == 'disjoint_continuous_episode_intervals'
            for key in ['generated_tokens','generated_decode_tokens','actual_graph_calls','prefill_graph_calls','decode_graph_calls',
                'prefill_target_rows','prefill_draft_rows','actual_target_rows','actual_draft_rows','committed_target_rows',
                'committed_target_decode_rows','verified_target_rows','draft_rows','agreements','accepted_drafts']:
                assert row[key] == sum(s[key] for s in sessions),(name,key)
            for s in sessions: timing(s)
    def trace(case,sid=None,step=None):
        base = Y/'cli-runs1'/case/'trace'
        return base/(sid or '')/(step or '')
    def outputs_against_old(case,sid,old_case,old_sid,steps,full=False):
        for step in steps:
            directory = trace(case,sid,step)
            files = [p for p in directory.iterdir() if p.suffix in ['.bf16','.f32']]
            assert len(files) == (38 if full else 2)
            for file in files:
                rel = Path('cli-runs1')/old_case/'trace'/(old_sid or '')/step/file.name
                equal(f'{case}/{sid}/{step}/{file.name}',file,rel,True)
    outputs_against_old('off-original','session0_A','multi-current','session0_A',['prefill','mtp1','mtp2','mtp3','mtp4'])
    outputs_against_old('off-original','session1_B','multi-current','session1_B',['prefill','mtp1'])
    for sid,steps in [('session0_A',['prefill','mtp1','mtp2','mtp3','mtp4']),('session1_B',['mtp1','mtp2','mtp3','mtp4']),('session2_C',['prefill','mtp1','mtp2','mtp3','mtp4'])]:
        outputs_against_old('queue-prefix-n2',sid,'multi-current','session0_A',steps,True)
    outputs_against_old('single',None,'p15-current',None,['prefill','mtp1','mtp2'])
    outputs_against_old('ordinary',None,'ordinary-current',None,['prefill','decode1'])
    for sid in ['session0_A','session1_B','session2_C']:
        outputs_against_old('budget-queue-n1',sid,'p15-current',None,['prefill','mtp1','mtp2'])
    outputs_against_old('whole-n1','session0_A','p15-current',None,['prefill'])
    outputs_against_old('partials-n3','session0_A','p15-current',None,['prefill','mtp1','mtp2'])
    # These are exact same P15+suffix partitions, not monolithic P23.
    for owner,case in [('session1_B','T1'),('session2_C','T8')]:
        for cli_step,index in [('prefill',1),('mtp1',2)]:
            for component in ['output.logits.f32','output.hidden.bf16']:
                reference = vector_records[case,index,component]['path']
                equal(f'partials-n3/{owner}/{cli_step}',trace('partials-n3',owner,cli_step)/component.removeprefix('output.'),reference)
    assert len(comparisons) == 590
    # Every remaining raw is finite, but no fabricated later same-partition
    # oracle is claimed for the second natural T1-branch round.
    no_oracle = [identity(p) for p in trace('partials-n3','session1_B','mtp2').iterdir() if p.suffix in ['.bf16','.f32']]
    assert len(no_oracle) == 2
    assert {Path(row['path']).name:row['bytes'] for row in no_oracle} == {'hidden.bf16':8192,'logits.f32':1986560}
    fullhit_records = []
    for case,sid in [('queue-prefix-n2','session1_B'),('whole-n1','session1_B'),('whole-n1','session2_C')]:
        directory = trace(case,sid,'prefill'); assert [p.name for p in directory.iterdir()] == ['cache-hit.json']
        record = load(directory/'cache-hit.json')
        assert record == dict(prefix_hit=True,graph_calls=0,tensor_payload_available=False,reused_tokens=15,next_id=198)
        fullhit_records.append(dict(**identity(directory/'cache-hit.json'),record=record))
    assertions = {
        'queue-prefix-n2':dict(actual_graph_calls=14,logical_dispatches=15,generated_tokens=24,prefill_target_rows=30,reused_tokens=15,prefix_full_hits=1,live_committed_versions=1,prefix_entries=1),
        'whole-n1':dict(actual_graph_calls=1,logical_dispatches=3,generated_tokens=3,prefill_target_rows=15,reused_tokens=30,prefix_full_hits=2,max_sessions=1),
        'budget-queue-n1':dict(actual_graph_calls=9,generated_tokens=12,max_sessions=1,prefix_evictions=3,prefix_hits=0,live_committed_versions=0,shared_backing_bytes=59777075),
        'partials-n3':dict(actual_graph_calls=8,generated_tokens=10,prefill_target_rows=24,reused_tokens=30,prefix_hits=2,prefix_full_hits=0,max_sessions=3)}
    for name,fields in assertions.items(): assert all(results[name][key] == value for key,value in fields.items())
    assert results['budget-queue-n1']['dispatch'] == ['A']*3+['B']*3+['C']*3
    assert results['whole-n1']['dispatch'] == ['A','B','C']
    old_multi = old.json('cli-runs1/multi-current/parsed.json')
    for new,previous in zip(results['off-original']['sessions'],old_multi['sessions']):
        assert new['session_id'] == previous['session_id']
        assert new['result']['generated_ids'] == previous['result']['generated_ids'] and new['result']['rounds'] == previous['result']['rounds']
    for entry in results['queue-prefix-n2']['sessions']:
        assert entry['result']['generated_ids'] == old_multi['sessions'][0]['result']['generated_ids']
        assert entry['result']['rounds'] == old_multi['sessions'][0]['result']['rounds']
    errors = load(HERE/'errors-analysis.json'); assert len(errors['cases']) == 5 and errors['GPU_inference_runs'] == errors['model_weight_loads'] == 0
    error_records=[]
    for case in errors['cases']:
        p = Path(case['terminal']['path']); assert identity(p) == case['terminal']
        terminal = load(p); assert terminal['exit'] == 1 and terminal['terminal'] and case['early_validation']
        command = terminal['command']; assert not (Path(command[command.index('--inputs')+1])/'weights.tsv').exists()
        stderr = (p.parent/'run.stderr.log').read_text(); assert stderr == case['stderr']
        assert 'weights_load_seconds=' not in stderr and 'resident text weights:' not in stderr and 'cannot open weight' not in stderr
        error_records.append(dict(name=case['name'],terminal=identity(p),stderr=identity(p.parent/'run.stderr.log')))
    probe_raw_count = 324
    cli_raw_count = len(raw_manifest)-probe_raw_count
    assert cli_raw_count == 592
    report = dict(status='PASS_INDEPENDENT_HOST_CHECK_OF_8_ACTUAL_NATIVE_PROCESSES',
        sources=[identity(source_probe),identity(source_main)],ready=[identity(Y/'mtp_session-ready-attempt1.json'),identity(Y/'qwen-ready-attempt1.json')],
        probe=dict(terminal=identity(probe_dir/'run.result.json'),observation=identity(probe_dir/'vectors/observation.json'),
            Graph_calls=15,full_hits=3,full_hit_head52_comparisons=156,real_commit54_comparisons=270,baseline_seed_reuse54_comparisons=108,
            total_metrics=534,canonical_raw_files=324,peak_versions=3,final_versions=0,backing_bytes=80240691,
            old_checkpoint_runtime_byte_checks=7,negative=dict(error=probe['negative_error'],bound_banks=14,versions=[1,2,1],same_carrier_retry=True,
            scope='Actual submitted original Graph; generation mismatch is checked inside terminal selector. Old52 head, policy owners, parity and idle gates were successful runtime assertions; same-input finish_evaluation retry compared54.'),canonical_comparisons=probe_pairs),
        CLI_processes=processes,CLI_work={name:{key:row.get(key) for key in ['session_count','max_sessions','shared_backing_bytes','actual_graph_calls','logical_dispatches','generated_tokens','prefill_target_rows','reused_tokens','prefix_full_hits','prefix_evictions','peak_committed_versions','live_committed_versions','session_seconds']} for name,row in results.items()},
        CLI_byte_comparisons=comparisons,CLI_fullhit_metadata_only=fullhit_records,finite_without_equivalent_oracle=no_oracle,
        totals=dict(actual_native_inference_processes=8,CLI_processes=7,probe_processes=1,CLI_numeric_raw_files=cli_raw_count,
            CLI_comparable_raw_pairs=590,CLI_finite_only_vectors=2,probe_metrics=534,unique_probe_raw_files=324,expected_error_processes=5),
        expected_errors=error_records,raw_identities=list(raw_manifest.values()),
        old_archive=dict(manifest=identity(old.manifest_path),archive_record=old.manifest['archives'][0],
            referenced_original_paths_verified=list(old.used.values()),verification='Each referenced canonical ZIP entry read through CRC and independently SHA256/size verified; no extraction, whole archive or SDK rehash.'),
        primary_records=[identity(Path(__file__)),identity(HERE/'errors-analysis.json')],
        limits=['All runs include diagnostic readback/trace costs and are not a performance window. P+D equals one service wall from disjoint continuous dispatch intervals; overlapping request latencies are not summed.',
                'Full-prompt hits have52 complete-head components and cached nextID without a Graph; no fake logits/hidden payload exists. Actual Graph commits have54-component probe coverage.',
                'Probe byteequal actual arrays were compared natively and intentionally reference one canonical saved baseline; offline verifies canonical raw and reuse map, not a second retained actual copy.',
                'Partial T1 andT8 are checked only against identical P15+suffix partitions. The later second T1-branch natural round has2 finite raw outputs without an equivalent independent oracle; no monolithicP23 byte claim.',
                'CLI queue pressure demonstrates bounded admission/retirement and continued correct natural outputs; GPU preemption, multi-request MTP R2, serving isolation and cross-engine quality are not certified.'])
    args.output.write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(dict(status=report['status'],totals=report['totals'],probe_counts={key:report['probe'][key] for key in ['Graph_calls','full_hits','total_metrics','peak_versions','final_versions']},output=str(args.output))))


if __name__ == '__main__':
    main()
