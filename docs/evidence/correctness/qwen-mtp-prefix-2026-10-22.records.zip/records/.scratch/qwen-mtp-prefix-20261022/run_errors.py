"""Expected early validation, with no weight file available to load."""
from pathlib import Path
import importlib.util,os,sys
sys.dont_write_bytecode=True
Y=Path(__file__).resolve().parent
s=importlib.util.spec_from_file_location('build',Y/'build_hyle.py');h=importlib.util.module_from_spec(s);s.loader.exec_module(h);b,c=h.b,h.c
ready=c.read(Y/'qwen-ready-attempt1.json');assert h.same(ready['image'])and h.same(ready['source'])
f=Y/'fixtures';missing=f/'no-weights';missing.mkdir(exist_ok=False);(missing/'prompt.ids').write_text('')
env=os.environ.copy();env['PATH']=c.read(ready['runtime_environment']['path'])['PATH']
base=[ready['image']['path'],'--inputs',str(missing),'--mtp','on','--capacity','64']
manifest=['--session-schedules',str(f/'repeat.txt')]
out=Y/'errors1';out.mkdir(exist_ok=False)
cases=[
 ('empty',[],['nonempty prompt']),
 ('budget-below-one',[*manifest,'--cache-bytes','59777074'],['bytes']),
 ('R2',[*manifest,'--active-sequences','2'],['1']),
 ('fixed-tape',['--schedule',str(f/'fixed.txt')],['prompt']),
 ('prefix-without-schedule',['--prefix-cache','auto'],['schedule']),
]
checks=[]
for name,args,need in cases:
 d=out/name;d.mkdir();command=base+args
 c.save(d/'plan.json',dict(command=command,expected_exit=1,missing_weight_manifest=True,expected_text=need))
 try:c.execute('run',command,env,d)
 except RuntimeError:pass
 result=c.read(d/'run.result.json');stderr=(d/'run.stderr.log').read_text(encoding='utf-8',errors='replace')
 assert result['exit']==1 and result['terminal']and all(s.lower()in stderr.lower()for s in need),(name,result,stderr)
 assert 'weights_load_seconds='not in stderr and'cannot open weight'not in stderr.lower() and not(d/'run.stdout.log').read_bytes()
 checks.append(dict(name=name,command=command,stderr=stderr,terminal=b.identity(d/'run.result.json'),expected_exit=1,early_validation=True))
c.save(Y/'review/errors-analysis.json',dict(status='PASS_EXPECTED_EARLY_VALIDATION',cases=checks,source=ready['source'],image=ready['image'],model_weight_loads=0,GPU_inference_runs=0))
print('EXPECTED_VALIDATION',len(checks))
