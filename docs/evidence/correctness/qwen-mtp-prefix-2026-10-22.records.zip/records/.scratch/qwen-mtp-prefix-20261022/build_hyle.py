"""Natural-generation window host refresh against the retained CUDA closure."""
from pathlib import Path
import argparse,importlib.util,os,sys
sys.dont_write_bytecode=True
U=Path(__file__).resolve().parent;R=U.parents[1];T=R/'.scratch/qwen-mtp-sessions-20261022'
sp=importlib.util.spec_from_file_location('prior',R/'.scratch/qwen-mtp-round-20261022/build.py');h=importlib.util.module_from_spec(sp);sp.loader.exec_module(h);b,c=h.b,h.c
sources={'qwen':R/'tools/qwen35_text/main.cc','mtp_session':R/'tools/qwen35_text/mtp_session_probe.cc'}
def same(x):return b.identity(x['path'])==x
def compile_owner(tag,attempt):
 source=sources[tag];out=U/f'compile{attempt}'/tag;out.mkdir(parents=True,exist_ok=False);(out/'tmp').mkdir()
 recipe=R/'.scratch/qwen-cli-batch-20261022/compile4/qwen/identity.json';prior=c.read(recipe)
 command=b.host_command(prior['command'],source,tag,out);assert all(x in command for x in ('/W4','/WX','/O2','/MD'))
 frozen=b.identity(source);main=b.identity(sources['qwen']);snap=out/'source'/source.relative_to(R);snap.parent.mkdir(parents=True);snap.write_bytes(source.read_bytes())
 c.save(out/'plan.json',dict(source=frozen,main=main,command=command,recipe=b.identity(recipe),SDK_builds=0,native_rebuilds=0))
 env,_=b.environment(command,[],out);c.execute('compile',command,env,out)
 data=c.read(out/f'{tag}-deps.json')['Data'];deps=list(dict.fromkeys([data['Source'],*data['Includes']]))
 assert same(frozen)and same(main)
 c.save(out/'identity.json',dict(source=frozen,main=main,object=b.identity(out/f'{tag}.obj'),command=command,dependencies=[b.identity(x)for x in deps]))
 print('COMPILED',tag,flush=True)
def link(tag,attempt):
 base_path=T/'qwen-link2/link-plan.json';base=c.read(base_path);rec_path=U/f'compile{attempt}'/tag/'identity.json';rec=c.read(rec_path)
 assert all(same(x)for x in(rec['source'],rec['main'],rec['object'],*rec['dependencies']))
 old=c.key(T/'compile2/qwen/qwen.obj');assert sum(c.key(x['path'])==old for x in base['inputs'])==1
 assert all(same(x)for x in base['inputs'])
 inputs=[rec['object']if c.key(x['path'])==old else x for x in base['inputs']]
 command=[rec['object']['path']if c.key(x)==old else x for x in base['command']if not x.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:'))]
 out=U/f'{tag}-link{attempt}';out.mkdir(exist_ok=False);(out/'tmp').mkdir();image=out/f'{tag}.exe'
 command+=['/OUT:'+str(image),'/MAP:'+str(image.with_suffix('.map')),'/IMPLIB:'+str(image.with_suffix('.lib'))]
 c.save(out/'link-plan.json',dict(command=command,inputs=inputs,base=b.identity(base_path),compiled_record=b.identity(rec_path),SDK_builds=0,native_rebuilds=0))
 env,_=b.environment(command,[x['path']for x in inputs],out);c.execute('link',command,env,out)
 for dll in(T/'qwen-link2').glob('*.dll'):os.link(dll,out/dll.name)
 runtime=c.read(T/'qwen-link2/runtime-environment.json');runtime['PATH']=env['PATH'];runtime['staged_dlls']=[b.identity(x)for x in out.glob('*.dll')];c.save(out/'runtime-environment.json',runtime)
 c.save(U/f'{tag}-ready-attempt{attempt}.json',dict(image=b.identity(image),source=rec['source'],main=rec['main'],link_plan=b.identity(out/'link-plan.json'),runtime_environment=b.identity(out/'runtime-environment.json'),SDK_builds=0,native_rebuilds=0))
 print('READY',tag,flush=True)
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('tag',choices=tuple(sources));p.add_argument('--attempt',type=int,default=1);p.add_argument('--link',action='store_true');a=p.parse_args()
 if a.link:link(a.tag,a.attempt)
 else:compile_owner(a.tag,a.attempt)
