from pathlib import Path
import difflib
import hashlib
import json

stage = Path(__file__).resolve().parent
root = stage.parents[1]
relative = Path('tools/qwen35_text/main.cc')
before_path = stage / 'before' / relative
path = root / relative
before = before_path.read_text(encoding='utf-8')
source = path.read_text(encoding='utf-8')
def identity(p):
    return {'path': str(p.relative_to(root)).replace('\\', '/'), 'bytes': p.stat().st_size,
            'sha256': hashlib.sha256(p.read_bytes()).hexdigest()}
ordinary = '    // These owners are declared after Model, including on exception paths.'
assert before[before.index(ordinary):] == source[source.index(ordinary):]
# The legacy single request's cold family/carrier planning and all measurement
# boundaries remain the exact original function; only its shared request helper
# gains real optional cache work and truthful reuse fields for scheduled calls.
begin, end = 'int run_mtp(Model &model,', 'int run_mtp_sessions(Model &model,'
assert before[before.index(begin):before.index(end)] == source[source.index(begin):source.index(end)]
assert 'role != GraphRole::kMtpPrefill && role != GraphRole::kMtpSingle &&' in source
assert source.index('if (step.first_input != step.members[0].base->next_id)') > source.index('MtpRoundResult finish_mtp_round(')
assert 'auto hit = prefix->lookup' in source and 'hit.reset(); // No hidden temporary head' in source
assert 'pending EOS' in source
snapshot = stage / 'source' / relative
snapshot.parent.mkdir(parents=True, exist_ok=True)
snapshot.write_bytes(path.read_bytes())
diff = stage / 'main.cc.diff'
diff.write_text(''.join(difflib.unified_diff(before.splitlines(True), source.splitlines(True),
    fromfile='before/tools/qwen35_text/main.cc', tofile='tools/qwen35_text/main.cc')), encoding='utf-8', newline='\n')
report = {
 'status': 'implementation frozen for root actual build/device validation; source checks only',
 'source': identity(path), 'before': identity(before_path),
 'scope': 'main.cc only, original same Model/Session/shared Phase/14-bank Graph chain; no public API/provider/math edits',
 'admission': {
  'policy': 'FIFO admit into at most N unfinished resident request slots, round-robin one complete original episode; no unfinished Session eviction or ordinary generated-state replay',
  'completion': 'checked stop/try_retire and Session reset precede resident-slot reuse; final counters copied before retirement',
  'bytes': 'original checked cache::plan and byte-cap binary search choose the actual N/R1; at least one resident is required before Model load',
  'committed': 'real VersionCount L<=N; fresh miss requires L+1<=N, R1 advance L-D+1<=N; D=1 only when selected base has no directory or other Session retainer',
  'aliases': 'adopt moves Hit.snapshot into Session, copies only host replay recipe, explicitly resets Hit before the budget gate; request stores no saved-prompt Snapshot',
  'eviction': 'only unpinned prefix directory aliases/checkpoints evicted, recomputing real L and external retainers after each eviction; N1 cannot keep old prompt plus new decode head'
 },
 'prefix': {
  'directory': 'existing bounded PrefixCache with entry limit N, model/math domain and exact token comparison, default auto for multi manifests / off for single schedule unless explicit auto',
  'publication': 'only a successfully completed prompt head with draft lag0, complete target KV/36 conv+GDN/carry/draft KV/frontier/next ID; generation lag1 checkpoints are not published',
  'whole_hit': 'create_session(empty plan, exact prefix), return stored next ID, zero prepare/submit/Graph/parity change; trace cache-hit.json explicitly says tensor payload unavailable',
  'partial': 'real suffix uses existing kMtpPrefill T>=2 carry shift or existing lag0 kMtpSingle T1; no dynamic family/shape compile',
  'cold_union': 'complete miss shapes plus strictly positive differences from earlier prompt boundaries whose exact tokens match; each request contributes a bounded possible per-role/shape use count',
  'provenance': 'copy existing ReplayPrefix actual source chunks then append the actual suffix under current immutable input; this records checkpoint identity, not a claim to replay generated MTP states'
 },
 'single_input_policy': {
  'prepare': 'only lag0 kMtpSingle may consume arbitrary teacher-forced input; T2 roles and CatchupSingle retain original pending-ID checks; all roles retain frontier/lag/capacity checks',
  'record': 'one actual first_input scalar copied after nonempty/vocabulary input validation, no device readback',
  'generation_finish': 'all MTP generation finish roles compare first_input with original step.member.base.next_id inside the existing post-Completion-retirement selector before publication; mismatch uses original abort cleanup',
  'prompt_finish': 'existing finish_evaluation can commit the truthful teacher-forced T1 prompt suffix without claiming a generation acceptance'
 },
 'measurement': {
  'single': 'run_mtp function byte-for-byte unchanged from48302 before snapshot; original flat output values and host endpoints stay comparable with prefix disabled',
  'multi': 'one start before initial coordinator/admission; each P or D bucket receives last endpoint->current original token-visible host endpoint, so intervals are disjoint even after queued P admissions',
  'full_hit_endpoint': 'Clock after exact Snapshot adopt and stored next ID host visibility, before diagnostic trace/log output; no fabricated Graph finish',
  'tail': 'final checkpoint/retire/log coordinator work after last host endpoint reported as post_endpoint_seconds; global speed uses original token endpoint, not aftertrace/cleanup',
  'request_latency': 'request prefill/decode/session endpoints remain per request and include interleaving wait; never sum them as total wall',
  'work': 'logical_prompt_tokens separate from actual suffix target/draft rows, reuse/hit/full-hit counts; actual Graph calls separate from logical dispatches; all prior verify/draft/commit/output ledgers retained'
 },
 'static_checks': {'legacy_single_run_function_byte_equal': True, 'ordinary_driver_body_byte_equal': True,
                   'git_diff_check': 'root command separately recorded; no compiler/device claim'},
 'not_implemented': ['lag1 arbitrary warm/multi-turn prompt catchup', 'R>1 MTP batching', 'rebuilding generated state from ordinary token tape',
                     'prefix entries surviving Model lifetime', 'independent model quality validation'],
 'activity': {'builds': 0, 'GPU_runs': 0, 'product_files': [str(relative).replace('\\', '/')]}
}
report_path = stage / 'review' / 'implementation-review.json'
report_path.write_text(json.dumps(report, indent=2)+'\n', encoding='utf-8')
freeze_path = stage / 'source-freeze.json'
freeze_path.write_text(json.dumps({'status': 'source frozen; root owns actual incremental build and tests',
    'before': identity(before_path), 'source': identity(path), 'snapshot': identity(snapshot),
    'diff': identity(diff), 'review': identity(report_path), 'builds': 0, 'GPU_runs': 0}, indent=2)+'\n', encoding='utf-8')
print(json.dumps({'source': identity(path), 'freeze': identity(freeze_path)}, indent=2))
