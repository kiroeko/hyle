"""Archive the actual bounded MTP prefix implementation and finite checks."""
from pathlib import Path
import difflib,hashlib,json,subprocess,zipfile
Y=Path(__file__).resolve().parent;R=Y.parents[1];O=R/'docs/evidence/correctness';NAME='qwen-mtp-prefix-2026-10-22'
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def save(p,d):p.write_text(json.dumps(d,indent=2,ensure_ascii=False,allow_nan=False)+'\n',encoding='utf-8')
def identity(p):
 p=Path(p);h=hashlib.sha256()
 with p.open('rb')as f:
  for data in iter(lambda:f.read(8<<20),b''):h.update(data)
 return dict(path=str(p.resolve()),bytes=p.stat().st_size,sha256=h.hexdigest())
frozen=[]
for name in ['tools/qwen35_text/main.cc','tools/qwen35_text/mtp_session_probe.cc','tools/qwen35_text/README.md','docs/developer/current-work.md']:
 p=R/name;before=Y/'before'/name;snap=Y/'current'/name;snap.parent.mkdir(parents=True,exist_ok=True);snap.write_bytes(p.read_bytes())
 diff=Y/'product-diffs'/(name.replace('/','--')+'.diff');diff.parent.mkdir(exist_ok=True)
 diff.write_text(''.join(difflib.unified_diff(before.read_text(encoding='utf-8-sig').splitlines(True),p.read_text(encoding='utf-8-sig').splitlines(True),fromfile='before/'+name,tofile=name)),encoding='utf-8')
 result=subprocess.run(['git','diff','--no-index','--check',str(before),str(p)],capture_output=True,text=True,encoding='utf-8',errors='replace')
 assert result.returncode in(0,1)and not result.stdout.strip()and not result.stderr.strip(),(name,result.stdout,result.stderr)
 frozen.append(dict(source=identity(p),snapshot=identity(snap),before=identity(before),diff=identity(diff)))
save(Y/'product-freeze.json',dict(files=frozen))
ready={}
for tag in ['qwen','mtp_session']:
 record=read(Y/f'{tag}-ready-attempt1.json')
 assert all(identity(record[k]['path'])==record[k]for k in('image','source','main'))
 ready[tag]=record
probe=read(Y/'probe-run1/vectors/observation.json');assert probe['status']=='PASS_BYTE_EXACT'and len(probe['vectors'])==534 and probe['actual_graph_calls']==15 and probe['final_live_snapshot_versions']==0
runs=[]
for folder in [Y/'probe-run1',*sorted((Y/'cli-runs1').iterdir())]:
 if not folder.is_dir():continue
 t=read(folder/'run.result.json');assert t['exit']==0 and t['terminal']
 runs.append(dict(terminal=identity(folder/'run.result.json'),stdout=identity(folder/'run.stdout.log'),stderr=identity(folder/'run.stderr.log'),command=t['command'],diagnostic=True,timing_evidence=False))
assert len(runs)==8
reports={p.name:read(p)for p in sorted((Y/'review').glob('*.json'))}
assert 'actual-analysis.json'in reports and reports['actual-analysis.json']['status'].startswith('PASS') and 'final-source-review.json'in reports
summary=dict(status='CUDA R1 MTP bounded admission and prompt prefix reuse implemented; finite checks passed; broader goal active',date='2026-10-22',
 product_freeze=identity(Y/'product-freeze.json'),ready=ready,probe=probe,reports=reports,actual_runs=runs,actual_diagnostic_GPU_processes=8,performance_window_performed=False,
 build_scope=dict(new_library_TUs=0,host_consumer_TUs=2,host_compile_attempts=2,successful_host_compiles=2,successful_links=2,SDK_builds=0,NVCC_builds=0,full_configures=0,reused_link_inputs_per_consumer=194),
 findings=[
 'One shared 335-tensor Model uses FIFO admission into N unfinished resident request slots and R1 round-robin episodes. Completed owners prove real retirement before reuse of a slot. No unfinished generation head is evicted or reconstructed with ordinary ReplayHistory.',
 'The existing bounded Radix PrefixCache now stores only completed lag0 prompt Snapshots with complete target/draft KV,36 conv/GDN states, carry and next ID. Exact whole hits execute0 Graph; partial hits execute only the truthful T1 or multirow suffix. All miss/suffix shapes are cold-compiled from the finite validated prompt set.',
 'Version pressure uses real L and D: fresh admission requires L+1<=N; an R1 advance requires L-D+1<=N, and D counts a selected base only when no directory or other Session retains it. Dropping a directory alias never deletes an unfinished Session. Hit temporaries are reset before this gate.',
 'Only lag0 kMtpSingle input policy is relaxed for actual teacher-forced T1 prompt append. The actual host first_input is checked against the immutable original pending ID inside the original post-Completion selector when generation finish is requested. Graph mathematics, public APIs, native providers,14-bank transactions and retirement mechanisms are unchanged.',
 'The permanent prefix probe actually executes15 Graph calls. Three whole-hit observations compare52 state components without fabricating logits/hidden; real commits compare54 vectors. All534 paired vectors are finite and byte-identical to the same-partition baselines, with7 complete old-prefix byte checks. The teacher-forced input248045 differs from pending198; wrong generation finish rejects after the native terminal, recycles14 bound banks, preserves the old head, and the same slot succeeds on truthful retry.',
 'Actual CLI cases include N1 three-request generation, N2 queued COW/full-hit continuation, N1 three first-token-only requests requiring1 Graph with2 whole hits, byte-cap auto shrink to59,777,075B/N1, and N3 partialT1/T8 with30 reused rows and24 actually computed prefill rows. Logical inputs, reused rows, Graph work and committed/output counts remain distinct.',
 'Independent host checks validate all916 numeric payloads as finite and590 CLI vector pairs byte-exact against the same input partitions. Archived previous-stage payloads are read through original SHA/entry mappings without extraction. Two later partial-request outputs are finite only; no independent same-partition oracle is retained for their later round.',
 'Queued prefill/decode may alternate. Disjoint continuous episode intervals end at the original token-visible host endpoints and sum to one global wall; per-request waiting latencies are not summed. Final tail work is separate. Trace/probe timing is not a speed comparison.'],
 limitations=[
 'Finite CUDA BF16 Qwen3.5-2B tests do not establish all selected model/quant routes, other native backends, GPU serving concurrency or complete model quality.',
 'Prompt checkpoint provenance records the actual input partition. T1/T8 suffix results are compared only with the same partition; they do not prove byte equality with a monolithic prompt or a quality threshold.',
 'Two later partial-request CLI vectors are finite but have no independent byte-equality oracle in this tranche; that scope is explicitly not marked complete.',
 'Generated-state eviction/rebuild and natural multi-turn input with lag1 catchup remain implementation work. Ordinary prompt ReplayHistory is not a complete MTP draft/verify replay recipe.',
 'MTP R>1 grouping, image projector integration, remaining capture invalidations and the full architecture audit remain active.',
 'N1 cannot retain an old prompt checkpoint beside a newer generation head. Directory eviction under this budget is expected and cannot be described as unbounded cross-request prefix retention.',
 'No performance or physical-memory comparison was run. The previous complete four-metric performance window remains authoritative.'],
 previous_evidence=['docs/evidence/correctness/qwen-mtp-sessions-2026-10-22.json','docs/evidence/correctness/qwen-mtp-retirement-2026-10-22.json','docs/evidence/performance/qwen-mtp-divergence-2026-10-22.json'],
 remaining=['Implement faithful generated MTP state recovery and natural multi-turn/lag catchup.', 'Extend applicable real MTP batches; keep actual timing/quality/resource evidence separate.', 'Other systems, selected-model/quant coverage, image projector and architecture/performance scope remain active.'])
save(Y/'actual-summary.json',summary)
excluded={'.exe','.dll','.obj','.map','.lib','.exp','.pdb','.pyc'}
files=sorted(p for p in Y.rglob('*')if p.is_file()and p.suffix.lower()not in excluded and not any(a in('tmp','__pycache__')for a in p.relative_to(Y).parts)and p.name not in('published.json','cleanup-plan.json','cleanup-result.json','cleanup_script.ps1'))
archive=O/(NAME+'.data.zip');assert not archive.exists();entries=[];unique={}
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=6)as z:
 for p in files:
  e=identity(p);key=(e['bytes'],e['sha256']);canonical=unique.get(key)
  if canonical is None:canonical=p.relative_to(R).as_posix();unique[key]=canonical;z.write(p,canonical)
  else:e['identical_content_alias']=True
  e['entry']=canonical;entries.append(e)
with zipfile.ZipFile(archive)as z:
 assert z.testzip()is None and len(z.namelist())==len(unique)
 for (size,sha),entry in unique.items():
  raw=z.read(entry);assert len(raw)==size and hashlib.sha256(raw).hexdigest()==sha
manifest=O/(NAME+'.json');assert not manifest.exists()
save(manifest,dict(**summary,archives=[identity(archive)],archive_files=entries,archive_verified=dict(CRC=True,all_unique_entry_SHA256=True,source_files=len(entries),unique_entries=len(unique),original_bytes=sum(e['bytes']for e in entries),unique_bytes=sum(k[0]for k in unique),content_deduplication='Every original path retains its SHA/size and canonical ZIP entry; identical raw payloads stored once.')))
published=dict(manifest=identity(manifest),archives=[identity(archive)]);save(Y/'published.json',published)
print(json.dumps(dict(**published,source_files=len(entries),unique_entries=len(unique),original_bytes=sum(e['bytes']for e in entries),unique_bytes=sum(k[0]for k in unique)),indent=2))
