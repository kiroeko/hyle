"""Final cold-index forwarding / bounded cohort-q freeze, metadata only."""
from pathlib import Path
import difflib
import hashlib
import importlib.util
import json
import sys

sys.dont_write_bytecode = True
P = Path(__file__).resolve().parent
PREVIOUS, W = P / 'refinement-v3', P / 'refinement-v4'
R = P.parents[1]
assert not W.exists(), 'Never overwrite an actual attempt'
spec = importlib.util.spec_from_file_location('sampling_before_v4', PREVIOUS / 'build.py')
old = importlib.util.module_from_spec(spec); spec.loader.exec_module(old)
t = old.t
relative = 'engine/models/qwen35/main.cc'; source = R / relative
assert t.pin(source)['sha256'] == '43baa527529d7fd801740b06bf824c563406d4461584d5a333ac4aa74f11045e'
previous_product = t.read(P / 'product-retirement-freeze.json')
before = (R / previous_product['source']['snapshot']).read_text(encoding='utf-8')
after = source.read_text(encoding='utf-8')
old_forward = '        const std::array chunk{width}; prepare_family(chunk, diagnostic, requests, role);'
new_forward = '        const std::array chunk{width};\n        prepare_family(chunk, diagnostic, requests, role, admitted_exact, completion, sampling_index, packed_prefill);'
assert before.count(old_forward) == 1
intermediate = before.replace(old_forward, new_forward)
intermediate_sha = hashlib.sha256(intermediate.encode('utf-8')).hexdigest()
assert len(intermediate.encode('utf-8')) == 580133 and intermediate_sha.startswith('d6b14566')
snapshot = P / 'source-final' / relative
snapshot.parent.mkdir(parents=True)
with snapshot.open('xb') as stream: stream.write(source.read_bytes())
delta = P / 'product-cold-q-capacity.diff'
with delta.open('x', encoding='utf-8') as stream:
    stream.write(''.join(difflib.unified_diff(before.splitlines(True), after.splitlines(True),
        fromfile='11e668/' + relative, tofile='43baa5/' + relative)))
forward_delta = P / 'product-recursive-forward.diff'
with forward_delta.open('x', encoding='utf-8') as stream:
    stream.write(''.join(difflib.unified_diff(before.splitlines(True), intermediate.splitlines(True),
        fromfile='11e668/' + relative, tofile='d6b145/' + relative)))
actual = t.pin(source)
t.save(P / 'product-final-freeze.json', dict(status='SOURCE_FROZEN_NO_BUILD', base=previous_product['base'],
    source=dict(path=relative, bytes=actual['bytes'], sha256=actual['sha256'], snapshot=snapshot.relative_to(R).as_posix(), newline='LF'),
    translation_units=[relative], changed_product_headers=[], previous_freeze=t.pin(P / 'product-retirement-freeze.json'),
    delta=t.pin(delta), intermediate=dict(bytes=580133, sha256=intermediate_sha, reconstruction=t.pin(forward_delta), built=False),
    scope=['Keep successful completed-call q retirement from 11e.',
        'Recursive Verify child family forwards original admitted_exact/completion/sampling_index/packed_prefill tail parameters.',
        'Cold probability pool allowance is checked configured active_sequences*candidate_boundaries with byte overflow and uint32 block-index bound; R1 allowance and execution_budget are unchanged.'],
    no_new_owner=True, no_new_executor=True, no_global_budget_increase=True))
W.mkdir()
build = (PREVIOUS / 'build.py').read_text(encoding='utf-8').replace("W.parent / 'product-retirement-freeze.json'", "W.parent / 'product-final-freeze.json'")
(W / 'build.py').write_text(build, encoding='utf-8')
run = (PREVIOUS / 'run.py').read_text(encoding='utf-8')
needle = "    assert manual['completed_q_released'] is True and final['completed_q_released'] is True"
assert needle in run
run = run.replace(needle, needle + "\n    assert manual['actual_B2_simultaneous_q'] == final['actual_B2_simultaneous_q'] == 4")
(W / 'run.py').write_text(run, encoding='utf-8')
spec = importlib.util.spec_from_file_location('sampling_v4', W / 'build.py')
b = importlib.util.module_from_spec(spec); spec.loader.exec_module(b)
t = b.t
expected = t.read(PREVIOUS / 'expected-tests.json')
case = 'tests/tools/qwen_mtp_sampling_case.h'
expected[case] = 'aa3386b6409a1bc51b38f0f8b7c4d274cdd0caabc0900194761a7c892422c2bf'
for path, sha in expected.items(): assert t.pin(R / path)['sha256'] == sha, path
with (W / 'consumer-B2-q.diff').open('x', encoding='utf-8') as stream:
    stream.write(''.join(difflib.unified_diff((PREVIOUS / 'source' / case).read_text(encoding='utf-8').splitlines(True),
        (R / case).read_text(encoding='utf-8').splitlines(True), fromfile='v3/' + case, tofile='v4/' + case)))
t.save(W / 'expected-tests.json', expected)
previous_failure = t.read(PREVIOUS / 'runs/sampler-cpu/process.json')
assert previous_failure['pid'] == 57624 and previous_failure['exit'] == 1 and not previous_failure['timed_out']
t.save(W / 'amendment.json', dict(changed_test_only=False, product=t.pin(P / 'product-final-freeze.json'),
    previous_ready=t.pin(PREVIOUS / 'ready-tiny.json'), previous_failure=t.pin(PREVIOUS / 'runs/sampler-cpu/process.json'),
    previous_partial_success='manual 17 initialized-state comparisons and completed_q_released passed; later natural cold prepare failed.',
    consumer_patch=t.pin(W / 'consumer-B2-q.diff'), new_CXX=1, link=1, planned_processes=3))
b.prepare()
spec = importlib.util.spec_from_file_location('sampling_v4_run', W / 'run.py')
run = importlib.util.module_from_spec(spec); spec.loader.exec_module(run)
run.prepare()
geometry = dict(manual_active_sequences=2, manual_same_policy_B2_simultaneous_q=4, manual_probability_pool_max_blocks=6,
    natural_active_sequences=1, natural_configuration_groups=3, natural_physical_R3=False,
    sampling_models_per_process=2, model_order='manual Model is destroyed before natural Model construction')
for name in ('runtime-plan.json', 'run-plan.json'):
    path = W / name; value = t.read(path); value['planned_consumer_geometry'] = geometry
    path.write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8')
path = W / 'plan.json'; value = t.read(path); value['runtime'] = t.pin(W / 'runtime-plan.json')
path.write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8')
b.freeze()
print('REFINEMENT-V4 READY: final 43baa/aa338 frozen; 0 compiler/linker/inference execution')
