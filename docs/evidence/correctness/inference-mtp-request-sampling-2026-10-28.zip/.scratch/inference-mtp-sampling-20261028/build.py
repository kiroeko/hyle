"""One combined Tiny TU and one 228-input link; actions are explicit, single-use.

prepare reads retained metadata only. freeze waits for the author's final
expected-tests.json; neither action compiles, links or starts a consumer.
"""
from pathlib import Path
import importlib.util
import re
import sys

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = W.parents[1]
BASE = R / '.scratch/inference-mtp-stop-refinement-20261028/final'
spec = importlib.util.spec_from_file_location('retained', R / '.scratch/inference-indexed-store-20261028/build.py')
t = importlib.util.module_from_spec(spec)
spec.loader.exec_module(t)
t.W = W
SOURCE = R / 'tests/tools/qwen_host_image_test.cc'


def prepare():
    ready = t.read(BASE / 'ready-tiny.json')
    t.exact(ready['inputs']); t.exact(ready['compiled']['dependencies'])
    rows = t.read(ready['inputs']['path'])
    assert len(rows) == 228
    old = ready['compiled']['object']
    assert sum(t.key(x['path']) == t.key(old['path']) for x in rows) == 1
    assert t.key(t.read(ready['compiled']['dependencies']['path'])['Data']['Source']) == t.key(SOURCE)
    original = t.command(ready['compiled']['command']['path'])
    command = []
    for at, arg in enumerate(original):
        if at and original[at - 1].casefold() == '/sourcedependencies':
            arg = str(W / 'compile/tiny/dependencies.json')
        elif arg.casefold().startswith('/fo'): arg = '/Fo' + str(W / 'compile/tiny/unit.obj')
        elif arg.casefold().startswith('/fd'): arg = '/Fd' + str(W / 'compile/tiny/unit.pdb')
        command.append(arg)
    assert sum(t.key(a) == t.key(SOURCE) for a in command) == 1
    t.save(W / 'recipe.json', dict(command=command, timeout_seconds=300))
    link = []
    for arg in t.command(ready['recipe']['path']):
        if t.key(arg) == t.key(old['path']): arg = str(W / 'compile/tiny/unit.obj')
        for prefix, suffix in (('/OUT:', '.exe'), ('/PDB:', '.pdb'), ('/MAP:', '.map'), ('/IMPLIB:', '.lib')):
            if arg.upper().startswith(prefix):
                arg = prefix + str((W / 'bin/tiny').with_suffix(suffix)); break
        link.append(arg)
    assert sum(t.key(a) == t.key(W / 'compile/tiny/unit.obj') for a in link) == 1
    t.save(W / 'link-recipe.json', dict(command=link, timeout_seconds=240))
    stats = []
    for row in rows:
        path = Path(row['path']); st = path.stat()
        assert st.st_size == row['bytes'], path
        stats.append(dict(path=str(path), bytes=st.st_size, mtime_ns=st.st_mtime_ns))
    t.save(W / 'input-stats.json', stats)
    env = t.read(BASE / 'environment.json')
    assert set(env) <= {'PATH', 'INCLUDE', 'LIB', 'LIBPATH'}
    env['PATH'] = str(W / 'bin') + ';' + env['PATH']
    t.save(W / 'environment.json', env)
    retained_runtime = t.read(BASE / 'runtime-plan.json')
    t.save(W / 'runtime-plan.json', dict(native=retained_runtime['native'],
        method='Same-file hardlink of the original CPU DLL beside this sampling Tiny; no SDK/DLL payload copy',
        consumer='mtp-sampling', CPU_processes=2, CUDA_processes=1,
        sampling_models_per_process=2, model_order='handwritten finite consumers, then natural request consumer; sequential, not simultaneous; separate CPU stop regression uses its original one Model',
        fixture=str(R / '.scratch/inference-paged-frame-20261026/tiny-recursive-input')))
    t.save(W / 'plan.json', dict(status='PREPARED_NOT_SOURCE_FROZEN', baseline=t.pin(BASE / 'ready-tiny.json'),
        inputs=ready['inputs'], original_object=old, original_dependencies=ready['compiled']['dependencies'],
        recipe=t.pin(W / 'recipe.json'), link_recipe=t.pin(W / 'link-recipe.json'),
        input_stats=t.pin(W / 'input-stats.json'), environment=t.pin(W / 'environment.json'),
        runtime=t.pin(W / 'runtime-plan.json'), CXX=1, links=1, CPU_processes=2, CUDA_processes=1,
        SDK_CXX=0, NVCC=0, downloads=0,
        compatibility='Only main and test sources change inside the replaced include-main TU; original static CPU/CUDA ABI/compiler/runtime flags and the other 227 input identities are retained.'))
    print('PREPARED: 1 canonical Tiny TU, 1 link, 228 inputs; no source freeze or execution')


def prepared():
    plan = t.read(W / 'plan.json')
    for field in ('baseline', 'inputs', 'original_dependencies', 'recipe', 'link_recipe', 'input_stats', 'environment', 'runtime'):
        t.exact(plan[field])
    return plan


def project_paths(plan, expected):
    # Retain prior actual project includes, then follow literal quote includes
    # from this one canonical TU to cover the new case header. No SDK copy.
    paths = {t.key(t.canonical(p)): t.canonical(p) for p in t.dep_paths(plan['original_dependencies']['path'])
             if t.project(t.canonical(p))}
    roots = []
    for arg in t.command(plan['recipe']['path']):
        if arg.lower().startswith('/i'): roots.append(Path(arg[2:]))
        elif arg.lower().startswith('/external:i'): roots.append(Path(arg[11:]))
    pending = [SOURCE, *(R / relative for relative in expected)]
    visited = set()
    while pending:
        path = pending.pop().resolve()
        if t.key(path) in visited: continue
        visited.add(t.key(path)); paths[t.key(path)] = path
        for name in re.findall(r'^\s*#\s*include\s*"([^"\r\n]+)"', path.read_text(encoding='utf-8-sig'), re.M):
            found = next((p.resolve() for root in [path.parent, *roots] if (p := root / name).is_file()), None)
            if found is not None and t.project(found): pending.append(found)
    return [paths[key] for key in sorted(paths)]


def freeze():
    plan = prepared()
    author = t.read(W / 'product-freeze.json')
    product = author['source']; current = R / product['path']
    assert t.pin(current)['sha256'] == product['sha256'], 'product differs from author freeze'
    assert t.pin(R / product['snapshot'])['sha256'] == product['sha256']
    expected = t.read(W / 'expected-tests.json')
    assert 'tests/tools/qwen_host_image_test.cc' in expected
    for relative, sha in expected.items():
        assert t.pin(R / relative)['sha256'] == sha, relative
    project = [t.pin(p) for p in project_paths(plan, expected)]
    t.save(W / 'project-dependencies.json', project)
    snapshots = []
    for relative in expected:
        source = R / relative; target = W / 'source' / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        with target.open('xb') as stream: stream.write(source.read_bytes())
        snapshots.append(dict(original=t.pin(source), snapshot=t.pin(target)))
    t.save(W / 'source-freeze.json', dict(product=t.pin(W / 'product-freeze.json'),
        product_source=t.pin(current), product_snapshot=t.pin(R / product['snapshot']),
        expected_tests=t.pin(W / 'expected-tests.json'), snapshots=snapshots,
        project_dependencies=t.pin(W / 'project-dependencies.json'),
        note='Canonical source compilation preserves quoted fixture lookup; no copied SDK or stale source overlay.'))
    print('SOURCE FROZEN; compile and link remain separate actions')


def validate():
    plan = prepared(); freeze = t.read(W / 'source-freeze.json')
    for field in ('product', 'product_source', 'product_snapshot', 'expected_tests', 'project_dependencies'):
        t.exact(freeze[field])
    for row in freeze['snapshots']:
        t.exact(row['original']); t.exact(row['snapshot'])
    return plan, freeze


def compile_one():
    plan, freeze = validate()
    allowed = {t.key(x['path']): x for x in t.read(freeze['project_dependencies']['path'])}
    for item in allowed.values(): t.exact(item)
    out = W / 'compile/tiny'; out.mkdir(parents=True, exist_ok=False)
    process = t.execute(t.command(plan['recipe']['path']), W / 'logs/tiny', 300)
    validate()
    actual = []
    for path in dict.fromkeys(t.dep_paths(out / 'dependencies.json')):
        if t.project(path):
            assert t.key(path) in allowed, ('unexpected project include', str(path))
            t.exact(allowed[t.key(path)]); actual.append(t.pin(path))
    t.save(out / 'actual-project-dependencies.json', actual)
    t.save(out / 'compiled.json', dict(source=t.pin(SOURCE), object=t.pin(out / 'unit.obj'),
        process=process, command=t.pin(W / 'logs/tiny/command.json'), dependencies=t.pin(out / 'dependencies.json')))
    print('TINY CXX PASS')


def link():
    plan, _ = validate(); compiled = t.read(W / 'compile/tiny/compiled.json'); t.exact(compiled['object'])
    for row in t.read(plan['input_stats']['path']):
        st = Path(row['path']).stat()
        assert (st.st_size, st.st_mtime_ns) == (row['bytes'], row['mtime_ns']), row['path']
    rows = [compiled['object'] if t.key(x['path']) == t.key(plan['original_object']['path']) else x
            for x in t.read(plan['inputs']['path'])]
    assert len(rows) == 228
    (W / 'bin').mkdir(exist_ok=True)
    assert not (W / 'bin/tiny.exe').exists()
    t.save(W / 'inputs-tiny.json', rows)
    process = t.execute(t.command(plan['link_recipe']['path']), W / 'link/tiny', 240)
    t.save(W / 'ready-tiny.json', dict(image=t.pin(W / 'bin/tiny.exe'), inputs=t.pin(W / 'inputs-tiny.json'),
        recipe=t.pin(W / 'link/tiny/command.json'), compiled=compiled, process=process,
        plan=t.pin(W / 'plan.json'), source_freeze=t.pin(W / 'source-freeze.json')))
    print('TINY LINK PASS')


if __name__ == '__main__':
    actions = {'prepare': prepare, 'freeze': freeze, 'compile': compile_one, 'link': link}
    actions[sys.argv[1]]()
