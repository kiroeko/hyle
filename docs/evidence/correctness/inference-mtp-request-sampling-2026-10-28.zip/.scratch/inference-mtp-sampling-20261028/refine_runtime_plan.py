"""Pre-freeze metadata correction only; no compiler, linker or inference."""
from pathlib import Path
import json

W = Path(__file__).resolve().parent
R = W.parents[1]
runtime_path = W / 'runtime-plan.json'
runtime = json.loads(runtime_path.read_text(encoding='utf-8-sig'))
assert set(runtime) == {'native', 'method'}, 'Apply only to the initial metadata preparation'
runtime.update(method='Same-file hardlink of the original CPU DLL beside this sampling Tiny; no SDK/DLL payload copy',
    consumer='mtp-sampling', CPU_processes=1, CUDA_processes=1,
    models_per_process=2, model_order='handwritten finite consumers, then natural request consumer; sequential, not simultaneous',
    fixture=str(R / '.scratch/inference-paged-frame-20261026/tiny-recursive-input'))
runtime_path.write_text(json.dumps(runtime, indent=2) + '\n', encoding='utf-8')
import importlib.util
spec = importlib.util.spec_from_file_location('sampling_build', W / 'build.py')
b = importlib.util.module_from_spec(spec); spec.loader.exec_module(b)
plan_path = W / 'plan.json'
plan = b.t.read(plan_path)
assert plan['status'] == 'PREPARED_NOT_SOURCE_FROZEN' and not (W / 'source-freeze.json').exists()
plan['runtime'] = b.t.pin(runtime_path)
plan_path.write_text(json.dumps(plan, indent=2) + '\n', encoding='utf-8')
print('Sampling-only runtime plan: CPU1/CUDA1, 2 sequential Models per process; 0 execution')
