"""Explicit single-use sampling CPU/CUDA and existing CPU stop regression.

parse is also an independent offline action. A failed process or parser is
retained and never rerun automatically; every arm has its own output directory.
"""
from pathlib import Path
import importlib.util
import json
import os
import sys

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('sampling_build', W / 'build.py')
b = importlib.util.module_from_spec(spec); spec.loader.exec_module(b)
t, R = b.t, b.R
FIXTURE = R / '.scratch/inference-paged-frame-20261026/tiny-recursive-input'
ARMS = {'sampler-cpu': ('cpu', '--mtp-sampling'), 'sampler-cuda': ('cuda', '--mtp-sampling'),
        'stop-cpu': ('cpu', '--mtp-stop')}


def prepare():
    plan_path = W / 'plan.json'; plan = t.read(plan_path)
    assert plan['status'] == 'PREPARED_NOT_SOURCE_FROZEN' and not (W / 'source-freeze.json').exists()
    runtime_path = W / 'runtime-plan.json'; runtime = t.read(runtime_path)
    runtime.update(CPU_processes=2, CUDA_processes=1, sampling_models_per_process=2,
        model_order='handwritten finite consumers then natural request consumer, sequential; separate CPU stop regression uses its original one Model')
    runtime.pop('models_per_process', None)
    runtime_path.write_text(json.dumps(runtime, indent=2) + '\n', encoding='utf-8')
    plan.update(CPU_processes=2, CUDA_processes=1, runtime=t.pin(runtime_path))
    plan_path.write_text(json.dumps(plan, indent=2) + '\n', encoding='utf-8')
    t.save(W / 'run-plan.json', dict(status='PLANNED_NOT_RUN', fixture_manifest=t.pin(FIXTURE / 'weights.tsv'),
        order=list(ARMS), arms={name: dict(backend=backend, flag=flag, output=str(W / 'runs' / name))
                              for name, (backend, flag) in ARMS.items()},
        actual_processes_planned=3, CPU_processes=2, CUDA_processes=1,
        sampling_models_per_process=2, regression_models_per_process=1,
        no_extra_build=True, no_SDK_copy=True, no_download=True))
    print('RUN PLAN PREPARED: sampler CPU/CUDA, then CPU stop; 3 processes, no execution')


def sampler_reports(reports, backend):
    manual = [x for x in reports if x.get('case') == 'mtp-sampling-manual']
    final = [x for x in reports if x.get('case') == 'mtp-sampling-policies']
    natural = [x for x in reports if 'sessions' in x]
    assert len(manual) == len(final) == len(natural) == 1 and len(reports) == 3
    manual, final, natural = manual[0], final[0], natural[0]
    assert all(x['status'] == 'PASS' and x['backend'] == backend for x in (manual, final))
    for field in ('same_loaded_model', 'prefix_new_policy', 'strict_replay', 'same_key_rebuild',
                  'rebuild_sampling_wrapper', 'host_image_identity'):
        assert manual[field] is True, field
    assert (manual['configurations'], manual['interleaved_K1'], manual['interleaved_recursive'],
            manual['state_only_policy'], manual['final_versions']) == (3, 3, 3, 2, 0)
    assert manual['completed_q_released'] is True and final['completed_q_released'] is True
    checks = manual['state_checks']
    assert len(checks) > 0 and final['manual_state_checks'] == len(checks)
    for check in checks:
        assert check['boundary_equal'] and check['numerically_equivalent'] and check['payloads_byte_equal'], check
    assert (final['sequential_models'], final['natural_requests'], final['natural_configurations'],
            final['final_versions']) == (2, 3, 3, 0)
    assert final['natural_outputs_per_request'] == 4 and final['natural_recursive_cold_plan'] is True
    assert final['natural_default_random_extra_greedy'] is True and final['synthetic_untrained'] is True
    assert final['quality_claim'] is False and final['performance_claim'] is False
    sessions = natural['sessions']; assert len(sessions) == 3
    identities = [('natural-random', 'random', 'min_one_p_over_q'),
                  ('natural-greedy', 'greedy', 'equal_greedy_ids'),
                  ('natural-random-extra', 'random', 'min_one_p_over_q')]
    for index, (entry, (name, sampling, acceptance)) in enumerate(zip(sessions, identities)):
        result = entry['result']; ledger = entry['ledger']
        assert entry['session_id'] == name and result['sampling_configuration_index'] == index
        assert result['request_sampling'] == sampling and result['request_mtp_acceptance_policy'] == acceptance
        assert result['mtp'] is True and result['generated_tokens'] == len(result['generated_ids']) == 4
        assert len(ledger) >= 2 and any(x['generation'] for x in ledger)
        for record in ledger:
            draws = record['sampling_draw_after'] - record['sampling_draw_before']
            expected = 0 if sampling == 'greedy' else (2 * (record['verified_rows'] - 1) + 1 if record['generation'] else 1)
            assert expected >= 0 and draws == expected, (name, record, expected)
        assert result['sampling_draw_cursor'] == ledger[-1]['sampling_draw_after']
    return dict(manual=manual, natural=natural, final=final)


def stop_report(reports):
    assert len(reports) == 1
    report = reports[0]
    assert report['status'] == 'PASS' and report['case'] == 'mtp-stop-policy' and report['backend'] == 'cpu'
    for field in ('actual_B2', 'accepted_extra_stop_pending', 'native_rejected_draft_stop', 'fused_K1_stop',
                  'actual_bonus_stop', 'new_request_prefix_policy', 'same_key_rebuild_policy',
                  'old_checkpoints_byte_unchanged', 'full_state_numerically_equivalent',
                  'controlled_target_matching_candidate', 'rebuild_sampling_wrapper'):
        assert report[field] is True, field
    assert report['final_versions'] == 0 and report['greedy_rng_draws'] == 0
    assert report['real_model_EOS_checked'] is False and report['ignoreEOS_host_only'] is True
    assert len(report['state_checks']) == 5
    assert all(x['boundary_equal'] and x['numerically_equivalent'] for x in report['state_checks'])
    return report


def parse(arm):
    backend, flag = ARMS[arm]; out = W / 'runs' / arm
    process = t.read(out / 'process.json')
    assert process['exit'] == 0 and not process['timed_out'], process
    reports = [json.loads(line) for line in (out / 'stdout.log').read_text(encoding='utf-8-sig').splitlines()
               if line.startswith('{')]
    actual = sampler_reports(reports, backend) if flag == '--mtp-sampling' else stop_report(reports)
    t.save(out / 'report.json', actual)
    t.save(out / 'summary.json', dict(status='PASS', arm=arm, backend=backend, process=process,
        report=t.pin(out / 'report.json'), source_freeze=t.pin(W / 'source-freeze.json'),
        quality_claim=False, performance_claim=False))
    print('PASS', arm, 'PID', process['pid'])


def run(arm):
    backend, flag = ARMS[arm]
    b.validate(); run_plan = t.read(W / 'run-plan.json'); t.exact(run_plan['fixture_manifest'])
    ready = t.read(W / 'ready-tiny.json'); t.exact(ready['image']); t.exact(ready['inputs'])
    runtime = t.read(W / 'runtime-plan.json'); t.exact(runtime['native'])
    original = Path(runtime['native']['path']); alias = W / 'bin' / original.name
    if not alias.exists(): os.link(original, alias)
    assert os.path.samefile(original, alias), 'CPU DLL must remain an original same-file hardlink'
    if not (W / 'runtime-actual.json').exists():
        t.save(W / 'runtime-actual.json', dict(source=runtime['native'], alias=str(alias), same_file=True))
    out = W / 'runs' / arm
    assert not out.exists(), 'Existing process output is preserved; use offline parse, never rerun'
    process = t.execute([ready['image']['path'], '--' + backend, str(FIXTURE), flag], out, 300)
    t.save(out / 'as-run.json', dict(image=ready['image'], ready=t.pin(W / 'ready-tiny.json'),
        inputs=ready['inputs'], source_freeze=ready['source_freeze'], run_plan=t.pin(W / 'run-plan.json'),
        fixture=run_plan['fixture_manifest'], runtime=t.pin(W / 'runtime-actual.json'), process=process))
    parse(arm)


if __name__ == '__main__':
    action = sys.argv[1]
    if action == 'prepare': prepare()
    elif action == 'run': run(sys.argv[2])
    elif action == 'parse': parse(sys.argv[2])
    else: raise ValueError(action)
