"""Complete the preserved metadata-only preparation after its literal typo.

The first helper expected host_image_identity() while the real old source says
host_image_identity(0). No compiler/linker/consumer was started by that failure.
"""
from pathlib import Path
import difflib
import importlib.util
import sys

sys.dont_write_bytecode = True
P = Path(__file__).resolve().parent
W, PREVIOUS = P / 'refinement-v2', P / 'refinement'
R = P.parents[1]
assert W.exists() and not (W / 'plan.json').exists()
spec = importlib.util.spec_from_file_location('sampling_v2_resume', W / 'build.py')
b = importlib.util.module_from_spec(spec); spec.loader.exec_module(b)
t = b.t
t.save(W / 'prepare-failure.json', dict(action='prepare_refinement_v2.py', exit=1, stage='metadata only',
    assertion='Old source literal was written as host_image_identity() in the helper; actual is host_image_identity(0).',
    actual_CXX=0, actual_links=0, actual_inference=0, original_script=t.pin(P / 'prepare_refinement_v2.py')))
relative = 'tests/tools/qwen_packed_prefill_case.h'
expected = t.read(PREVIOUS / 'expected-tests.json')
expected[relative] = '6db293d9d96476901cbfd0df35c0afabe9fa6916e8c434d1aaa45a55b33a1f00'
for path, sha in expected.items(): assert t.pin(R / path)['sha256'] == sha, path
old_snapshot = W / 'source-before' / relative
before = old_snapshot.read_text(encoding='utf-8'); after = (R / relative).read_text(encoding='utf-8')
old = '  require(result.identity == model.host_image_identity(0), "prefill export changed its original Model identity");'
new = '  require(result.identity == model.host_image_identity(session.sampling_configuration().index),\n      "prefill export changed its original Model or sampling identity");'
assert before.count(old) == 1 and before.replace(old, new) == after
(W / 'source-refinement.diff').write_text(''.join(difflib.unified_diff(before.splitlines(True), after.splitlines(True),
    fromfile='previous/' + relative, tofile='refinement-v2/' + relative)), encoding='utf-8')
t.save(W / 'expected-tests.json', expected)
t.save(W / 'amendment.json', dict(reason='The existing state-export test helper incorrectly assumed sampling configuration 0.',
    changed_test_only=True, assertion='Retain strict complete identity equality, selecting the actual Session sampling ordinal.',
    product=t.pin(P / 'product-freeze.json'), previous_ready=t.pin(PREVIOUS / 'ready-tiny.json'),
    original_run_failure=t.pin(PREVIOUS / 'runs/sampler-cpu/process.json'), before_source=t.pin(old_snapshot),
    source_patch=t.pin(W / 'source-refinement.diff'), metadata_preparation_failure=t.pin(W / 'prepare-failure.json'),
    original_failure_preserved=True, new_CXX=1, link=1, planned_processes=3))
b.prepare()
run_spec = importlib.util.spec_from_file_location('sampling_v2_run_resume', W / 'run.py')
run = importlib.util.module_from_spec(run_spec); run_spec.loader.exec_module(run)
run.prepare()
b.freeze()
print('REFINEMENT-V2 READY; metadata-only assertion preserved; 0 CXX/link/inference invoked')
