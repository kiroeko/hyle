"""Offline bounded MTP sampling evidence. Run only after all three processes.

No compiler, linker or consumer is invoked. Missing/failed results stop the
archive; they never become PASS, zero counts, skipped checks or automatic runs.
"""
from pathlib import Path
import datetime
import hashlib
import json
import zipfile

W = Path(__file__).resolve().parent
R = W.parents[1]
PREVIOUS = W / 'refinement'
BEFORE_RETIREMENT = W / 'refinement-v2'
RETIREMENT = W / 'refinement-v3'
F = W / 'refinement-v4'
DEST = R / 'docs/evidence/correctness/inference-mtp-request-sampling-2026-10-28'


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def encoded(value):
    return (json.dumps(value, ensure_ascii=False, indent=2) + '\n').encode('utf-8')


def pin(path):
    path = Path(path); value = path.read_bytes()
    return dict(path=path.relative_to(R).as_posix(), bytes=len(value), sha256=hashlib.sha256(value).hexdigest())


def need(value, message):
    if not value: raise RuntimeError(message)


def process(path, expected_exit):
    row = read(path)
    need(row['exit'] == expected_exit and not row['timed_out'], 'Unexpected actual process: ' + str(path))
    return dict(pid=row['pid'], exit=row['exit'], seconds=row['seconds'])


def main():
    need(not DEST.with_suffix('.json').exists() and not DEST.with_suffix('.zip').exists(), 'Evidence exists; never overwrite')
    original_author = read(W / 'product-freeze.json')
    retirement_author = read(W / 'product-retirement-freeze.json')
    author = read(W / 'product-final-freeze.json'); source = author['source']
    source_snapshot = R / source['snapshot']
    need(pin(source_snapshot)['sha256'] == source['sha256'] ==
         '43baa527529d7fd801740b06bf824c563406d4461584d5a333ac4aa74f11045e', 'Wrong frozen final product')
    final_freeze = read(F / 'source-freeze.json')
    final_tests = []
    for entry in final_freeze['snapshots']:
        actual = pin(entry['snapshot']['path'])
        need(actual['sha256'] == entry['original']['sha256'], 'Frozen consumer snapshot drift')
        final_tests.append(actual)
    initial = process(W / 'logs/tiny/process.json', 2)
    need('C3538' in (W / 'logs/tiny/stdout.log').read_text(encoding='utf-8-sig', errors='replace'),
         'Original CXX failure not preserved')
    previous_ready = read(PREVIOUS / 'ready-tiny.json')
    previous_cxx = process(PREVIOUS / 'logs/tiny/process.json', 0)
    previous_link = process(PREVIOUS / 'link/tiny/process.json', 0)
    previous_failure = process(PREVIOUS / 'runs/sampler-cpu/process.json', 1)
    need('prefill export changed its original Model identity' in
         (PREVIOUS / 'runs/sampler-cpu/stderr.log').read_text(encoding='utf-8-sig'),
         'Preserve the real default-index oracle failure')
    before_ready = read(BEFORE_RETIREMENT / 'ready-tiny.json')
    before_cxx = process(BEFORE_RETIREMENT / 'logs/tiny/process.json', 0)
    before_link = process(BEFORE_RETIREMENT / 'link/tiny/process.json', 0)
    q_failure = process(BEFORE_RETIREMENT / 'runs/sampler-cpu/process.json', 1)
    need('lease block capacity' in (BEFORE_RETIREMENT / 'runs/sampler-cpu/stderr.log').read_text(encoding='utf-8-sig'),
         'Preserve the actual bounded-pool failure')
    retirement_ready = read(RETIREMENT / 'ready-tiny.json')
    retirement_cxx = process(RETIREMENT / 'logs/tiny/process.json', 0)
    retirement_link = process(RETIREMENT / 'link/tiny/process.json', 0)
    natural_cold_failure = process(RETIREMENT / 'runs/sampler-cpu/process.json', 1)
    partial = [json.loads(line) for line in (RETIREMENT / 'runs/sampler-cpu/stdout.log').read_text(encoding='utf-8-sig').splitlines()
               if line.startswith('{')]
    need(len(partial) == 1 and partial[0]['case'] == 'mtp-sampling-manual' and partial[0]['status'] == 'PASS' and
         partial[0]['completed_q_released'] is True and len(partial[0]['state_checks']) == 17 and
         all(x['boundary_equal'] and x['payloads_byte_equal'] for x in partial[0]['state_checks']),
         'Preserve the actual v3 manual partial success')
    need('text finite family was already prepared' in
         (RETIREMENT / 'runs/sampler-cpu/stderr.log').read_text(encoding='utf-8-sig'),
         'Preserve the actual natural cold-index failure')
    ready = read(F / 'ready-tiny.json'); compiled = ready['compiled']
    cxx = process(F / 'logs/tiny/process.json', 0)
    link = process(F / 'link/tiny/process.json', 0)
    need(compiled['process']['pid'] == cxx['pid'] and ready['process']['pid'] == link['pid'], 'Ready/process mismatch')
    inputs = read(ready['inputs']['path'])
    need(len(inputs) == 228 and sum(x['path'].casefold() == compiled['object']['path'].casefold() for x in inputs) == 1,
         'Tiny must replace exactly one object in the actual 228-input closure')
    need(read(F / 'amendment.json')['changed_test_only'] is False, 'The third refinement is a real product fix')
    runs = []
    for backend in ('cpu', 'cuda'):
        out = F / 'runs' / ('sampler-' + backend)
        actual = process(out / 'process.json', 0); summary = read(out / 'summary.json')
        need(summary['status'] == 'PASS' and summary['process']['pid'] == actual['pid'], 'Sampling parse is incomplete')
        raw = [json.loads(line) for line in (out / 'stdout.log').read_text(encoding='utf-8-sig').splitlines() if line.startswith('{')]
        manual = [x for x in raw if x.get('case') == 'mtp-sampling-manual']
        final = [x for x in raw if x.get('case') == 'mtp-sampling-policies']
        natural = [x for x in raw if 'sessions' in x]
        need(len(raw) == 3 and len(manual) == len(final) == len(natural) == 1, 'Unexpected real sampling output')
        manual, final, natural = manual[0], final[0], natural[0]
        need(manual['status'] == final['status'] == 'PASS' and manual['backend'] == final['backend'] == backend,
             'Wrong real consumer report')
        checks = manual['state_checks']
        need(len(checks) == final['manual_state_checks'] == 17, 'Actual state comparison count differs')
        need(all(x['boundary_equal'] and x['numerically_equivalent'] and x['payloads_byte_equal'] for x in checks),
             'Same-policy initialized payload/boundary differs')
        for field in ('same_loaded_model', 'prefix_new_policy', 'strict_replay', 'same_key_rebuild',
                      'rebuild_sampling_wrapper', 'host_image_identity', 'completed_q_released'):
            need(manual[field] is True, 'Missing manual fact: ' + field)
        need(final['sequential_models'] == 2 and final['natural_recursive_cold_plan'] is True and
             final['natural_default_random_extra_greedy'] is True and final['natural_requests'] == 3 and
             final['natural_outputs_per_request'] == 4 and final['final_versions'] == manual['final_versions'] == 0,
             'Natural finite scope/resources differ')
        need(final['completed_q_released'] is True, 'Original completed call q leases remain live')
        need(manual['actual_B2_simultaneous_q'] == final['actual_B2_simultaneous_q'] == 4,
             'Real same-policy B2/K2 must retain four simultaneous q rows')
        requests = []
        for index, entry in enumerate(natural['sessions']):
            result, ledger = entry['result'], entry['ledger']
            need(result['sampling_configuration_index'] == index and len(result['generated_ids']) == result['generated_tokens'] == 4,
                 'Natural sampler identity/output count differs')
            expected_sampling = 'greedy' if index == 1 else 'random'
            need(result['request_sampling'] == expected_sampling and result['request_mtp_acceptance_policy'] ==
                 ('equal_greedy_ids' if index == 1 else 'min_one_p_over_q'), 'Wrong natural acceptance policy')
            for record in ledger:
                need(record['requests'] == 1, 'Natural distinct-config groups are R1, never physical R3')
                expected = 0 if index == 1 else 2 * (record['verified_rows'] - 1) + 1 if record['generation'] else 1
                need(record['sampling_draw_after'] - record['sampling_draw_before'] == expected,
                     'Actual ledger RNG reservation differs')
            need(result['sampling_draw_cursor'] == ledger[-1]['sampling_draw_after'], 'Actual request cursor differs')
            requests.append(dict(name=entry['session_id'], sampling_index=index, sampling=expected_sampling,
                acceptance=result['request_mtp_acceptance_policy'], outputs=result['generated_ids'],
                ledger_episodes=len(ledger), final_draw=result['sampling_draw_cursor']))
        need(len(requests) == 3, 'Three natural request configurations required')
        differences = [part for check in checks for part in check['differences']]
        runs.append(dict(backend=backend, **actual, sequential_models=2, manual_state_comparisons=len(checks),
            same_policy_initialized_payloads_byte_equal=True, old_checkpoints_checked=True,
            manual_actual_R=2, actual_B2_simultaneous_q=manual['actual_B2_simultaneous_q'],
            B2_after_submit_asserted_pool_live_blocks=4, B2_after_submit_asserted_pool_max_blocks=6,
            max_recorded_GDN_absolute_difference=max([0.0] + [x['maximum_absolute'] for x in differences]),
            natural_requests=requests, natural_physical_R=1, natural_configuration_groups=3, engine_live_versions=0,
            target_and_draft_page_inventories_fully_free=True, host_images_live=0))
    stop_out = F / 'runs/stop-cpu'; stop_process = process(stop_out / 'process.json', 0)
    stop_summary = read(stop_out / 'summary.json'); stop = read(stop_out / 'report.json')
    need(stop_summary['status'] == 'PASS' and stop['case'] == 'mtp-stop-policy' and stop['backend'] == 'cpu' and
         stop['rebuild_sampling_wrapper'] is True and len(stop['state_checks']) == 5,
         'CPU stop regression incomplete')
    for field in ('accepted_extra_stop_pending', 'native_rejected_draft_stop', 'fused_K1_stop', 'actual_bonus_stop',
                  'new_request_prefix_policy', 'same_key_rebuild_policy', 'old_checkpoints_byte_unchanged',
                  'full_state_numerically_equivalent'):
        need(stop[field] is True, 'Missing stop regression: ' + field)

    members = {}
    allowed = {'.py', '.json', '.log', '.xml', '.cc', '.h', '.diff', '.tsv'}

    def add(path, name=None):
        path = Path(path); name = name or path.relative_to(R).as_posix()
        need(path.is_file() and path.suffix.lower() in allowed, 'Missing/excluded payload: ' + str(path))
        need(name not in members, 'Duplicate archive member: ' + name)
        members[name] = path.read_bytes()

    for root in (W, PREVIOUS, BEFORE_RETIREMENT, RETIREMENT, F):
        for path in sorted(root.iterdir()):
            if path.is_file() and path.suffix.lower() in {'.py', '.json', '.diff'}: add(path)
        for sub in ('compile', 'logs', 'link', 'runs'):
            if (root / sub).exists():
                for path in sorted((root / sub).rglob('*')):
                    if path.is_file() and path.suffix.lower() in {'.json', '.log', '.xml'}: add(path)
        for entry in read(root / 'source-freeze.json')['snapshots']:
            add(entry['snapshot']['path'])
    add(BEFORE_RETIREMENT / 'source-before/tests/tools/qwen_packed_prefill_case.h')
    add(source_snapshot)
    add(R / original_author['source']['snapshot'])
    add(R / retirement_author['source']['snapshot'])
    # Preserve critical unchanged math/stop and byte-oracle dependencies after
    # checking their actual pre/post-CXX dependency pins. The prior archive is
    # the identity reference for the rest, not an SDK/header-tree duplicate.
    deps = {x['path'].casefold(): x for x in read(F / 'compile/tiny/actual-project-dependencies.json')}
    shared = ['engine/inference/sampling_graph.h', 'engine/inference/request_stop_policy.h',
              'engine/inference/mtp_acceptance.h', 'tests/tools/qwen_host_image_case.h',
              'tests/tools/qwen_packed_prefill_case.h', 'tests/tools/qwen_mtp_chunked_prefill_case.h',
              'tests/tools/qwen_mtp_stop_case.h']
    for relative in shared:
        path = R / relative; actual = pin(path); expected = deps[str(path).casefold()]
        need(actual['sha256'] == expected['sha256'], 'Shared dependency drift: ' + relative)
        name = 'shared/' + relative
        add(path, name)
    add(R / '.scratch/inference-indexed-store-20261028/build.py', 'retained-tools/build.py')
    reference_json = R / 'docs/evidence/correctness/inference-mtp-request-stop-2026-10-28.json'
    reference = pin(reference_json); add(reference_json, 'references/' + reference_json.name)
    baseline_ready = R / '.scratch/inference-mtp-stop-refinement-20261028/final/ready-tiny.json'
    add(baseline_ready, 'references/retained-ready-tiny.json')
    baseline = read(baseline_ready)
    add(baseline['inputs']['path'], 'references/retained-inputs-tiny.json')
    fixture = read(F / 'run-plan.json')['fixture_manifest']
    need(pin(fixture['path'])['sha256'] == fixture['sha256'], 'Fixture manifest drift')
    add(fixture['path'], 'fixture/weights.tsv')  # Role/shape/path receipt only, never weight payload.
    report = dict(status='PASS_BOUNDED_MTP_REQUEST_SAMPLING', created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        source_base=author['base'], product=dict(path=source['path'], bytes=source['bytes'], sha256=source['sha256']),
        final_test_sources=final_tests,
        counts=dict(actual_CXX=5, successful_CXX=4, failed_CXX=1, actual_links=4, successful_links=4,
            actual_model_processes=6, successful_model_processes=3, preserved_test_oracle_failures=1,
            preserved_real_resource_failure=1,
            preserved_natural_cold_index_failure=1,
            successful_process_model_instances=5,
            standalone_Model_CXX=0, SDK_CXX=0, NVCC=0, downloads=0),
        build=dict(initial_CXX=initial, initial_failure='C3538 in a test-only declaration of unequal deduced std::array types.',
            first_refinement=dict(CXX=previous_cxx, link=previous_link, image=previous_ready['image']),
            second_refinement=dict(CXX=before_cxx, link=before_link, image=before_ready['image']),
            third_refinement=dict(CXX=retirement_cxx, link=retirement_link, image=retirement_ready['image']),
            final_refinement=dict(CXX=cxx, link=link), inputs=228, original_inputs_reused=227, image=ready['image'],
            corrections=['Split that one declaration into four declarations.',
                'The shared test capture oracle now compares the actual Session sampler identity instead of hardcoding index 0; strict identity equality is retained.',
                'Real product correction: successful Verify finish releases consumed per-call q ReadLeases. Old call objects stay alive through strict replay; no manual test clear.',
                'Real product correction: recursive Verify family preparation forwards its complete original tail parameters, preserving the nondefault sampling index.',
                'Cold probability-pool capacity is checked configured active_sequences*candidate_boundaries; byte arithmetic and the uint32 lease-index limit are checked. R1 allowance and the original execution budget are unchanged.'],
            product_code_revisions_after_first_CXX=2),
        preserved_failures=dict(compile=initial, test_identity_oracle=previous_failure, real_q_pool_capacity=q_failure,
            natural_cold_index=natural_cold_failure,
            v3_partial_success='The same failed process first passed manual17 all-byte state comparisons and completed-q retirement, then failed natural cold preparation; it is never counted as a passed process.',
            metadata_preparation=pin(BEFORE_RETIREMENT / 'prepare-failure.json'),
            note='The metadata literal typo stopped before any compiler/linker/consumer. C3538 and identity-0 were test errors; q retention and dropped cold-recursion configuration were genuine product defects. The B2 cold allowance is additionally proved by the final real four-q consumer.'),
        sampling_runs=runs,
        stop_regression=dict(**stop_process, backend='cpu', existing_state_comparisons=5,
            additional_bonus_comparison='Original strict same_image before PASS.', rebuild_sampling_wrapper=True),
        contracts=['Cold NextN head programs key by (rows,head,sampling index); head=false repair remains shared index 0.',
            'Recursive acceptance programs key by (proposal count,sampling index); K1 and target families use their existing selected configuration.',
            'Per-request immutable greedy/temperature/top-k/top-p without logits modifiers; actual Session, Phase and ledger identities remain original.',
            'Greedy reserves no draws; random prefill/single reserve one, K1 reserves three and recursive reserves 2*proposals+1; StateOnly does not sample.',
            'Same-policy, same-geometry repeatability, interleaving, checkpoint preservation, selected prefix resampling, strict replay, HostImage and same-key rebuild/ACK are finite tested consumers.'],
        permission_retirement='Successful original Verify/prefix finish has retired all q reads before clearing completed call q guards. Throwing/unretired paths retain the original reads and cleanup. Pool allowance now scales only with the configured active cohort (R1 unchanged), within its original execution budget.',
        static_review='Initial bounded diff review found no blocker; subsequent runtime exposed the recorded q-lifetime and cold-index defects. That review is not a substitute for actual consumers or a whole-codebase/platform proof.',
        modifier_followup=dict(status='DESIGN_ONLY_NOT_IMPLEMENTED_OR_TESTED', source='modifier-design.json'),
        limits=['Cached untrained GA/H64/V64/C16 fixture; no model quality, acceptance-rate or target-only random trajectory identity claim.',
            'Different policies use homogeneous configuration cohorts; mixed sampling indices inside one physical graph batch are not claimed.',
            'No modifier support: bias/allowed-mask and per-prefix-dependent policy remain rejected by the existing MTP guards.',
            'CPU/CUDA only; no Apple/Vulkan/cross-native numerical identity, real-model EOS, hardware/native fault or unknown-pending proof.',
            'Initialized state bytes are compared within each backend; inherited GDN-only numeric tolerance remains, with actual equality reported separately.',
            'Engine versions/page inventories/host images are checked; native allocator live-zero is not inferred.',
            'No performance window or TPS claim; process duration is recorded for provenance only.'],
        reference=reference, reproduction=dict(directory=W.relative_to(R).as_posix(),
            build='refinement-v4/build.py compile; refinement-v4/build.py link',
            run='refinement-v4/run.py run sampler-cpu; sampler-cuda; stop-cpu',
            note='Each action is single-use and preserves failure; parse is an independent offline action, never a reason to rerun success.'),
        raw_manifest='manifest.json')
    members['evidence-core.json'] = encoded(report)
    members['manifest.json'] = encoded(dict(files=[dict(path=name, bytes=len(value), sha256=hashlib.sha256(value).hexdigest())
        for name, value in sorted(members.items())], excluded=['binaries/OBJ/PDB/DLL/LIB', 'SDK/header trees', 'model/weights payload', 'unrelated docs/license']))
    DEST.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(DEST.with_suffix('.zip'), 'x', zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for name, value in sorted(members.items()): archive.writestr(name, value)
    with zipfile.ZipFile(DEST.with_suffix('.zip')) as archive:
        need(archive.testzip() is None and set(archive.namelist()) == set(members), 'ZIP CRC/member failure')
        for name, value in members.items(): need(archive.read(name) == value, 'ZIP SHA/readback failure: ' + name)
    report['archive'] = dict(pin(DEST.with_suffix('.zip')), files=len(members), verified_readback=True)
    DEST.with_suffix('.json').write_bytes(encoded(report))
    print(json.dumps(dict(json=pin(DEST.with_suffix('.json')), archive=report['archive'], counts=report['counts']), indent=2))


if __name__ == '__main__':
    main()
