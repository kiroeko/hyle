"""Freeze only the actual-Session identity oracle refinement; no execution."""
from pathlib import Path
import difflib
import hashlib
import importlib.util
import subprocess
import sys

sys.dont_write_bytecode = True
P = Path(__file__).resolve().parent
PREVIOUS = P / 'refinement'
W = P / 'refinement-v2'
R = P.parents[1]
assert not W.exists(), 'Preserve an existing refinement'
W.mkdir()
for name in ('build.py', 'run.py'):
    (W / name).write_bytes((PREVIOUS / name).read_bytes())
spec = importlib.util.spec_from_file_location('sampling_v2_build', W / 'build.py')
b = importlib.util.module_from_spec(spec); spec.loader.exec_module(b)
t = b.t
failed = t.read(PREVIOUS / 'runs/sampler-cpu/process.json')
assert failed['pid'] == 32004 and failed['exit'] == 1 and not failed['timed_out']
expected = t.read(PREVIOUS / 'expected-tests.json')
relative = 'tests/tools/qwen_packed_prefill_case.h'
expected[relative] = '6db293d9d96476901cbfd0df35c0afabe9fa6916e8c434d1aaa45a55b33a1f00'
for path, sha in expected.items(): assert t.pin(R / path)['sha256'] == sha, path
base = t.read(P / 'product-freeze.json')['base']
before_bytes = subprocess.run(['git', 'show', base + ':' + relative], cwd=R, capture_output=True, check=True).stdout
old_pins = {x['path'].casefold(): x for x in t.read(PREVIOUS / 'project-dependencies.json')}
assert hashlib.sha256(before_bytes).hexdigest() == old_pins[str(R / relative).casefold()]['sha256']
old_snapshot = W / 'source-before' / relative
old_snapshot.parent.mkdir(parents=True); old_snapshot.write_bytes(before_bytes)
before = before_bytes.decode('utf-8'); after = (R / relative).read_text(encoding='utf-8')
assert before.replace('  require(result.identity == model.host_image_identity(), "prefill export changed its original Model identity");',
    '  require(result.identity == model.host_image_identity(session.sampling_configuration().index),\n      "prefill export changed its original Model or sampling identity");') == after
(W / 'source-refinement.diff').write_text(''.join(difflib.unified_diff(before.splitlines(True), after.splitlines(True),
    fromfile='previous/' + relative, tofile='refinement-v2/' + relative)), encoding='utf-8')
t.save(W / 'expected-tests.json', expected)
t.save(W / 'amendment.json', dict(reason='The existing state-export test helper incorrectly assumed sampling configuration 0.',
    changed_test_only=True, assertion='Retain strict complete identity equality, selecting the actual Session sampling ordinal.',
    product=t.pin(P / 'product-freeze.json'), previous_ready=t.pin(PREVIOUS / 'ready-tiny.json'),
    original_run_failure=t.pin(PREVIOUS / 'runs/sampler-cpu/process.json'),
    before_source=t.pin(old_snapshot), source_patch=t.pin(W / 'source-refinement.diff'),
    original_failure_preserved=True, new_CXX=1, link=1, planned_processes=3))
b.prepare()
run_spec = importlib.util.spec_from_file_location('sampling_v2_run', W / 'run.py')
run = importlib.util.module_from_spec(run_spec); run_spec.loader.exec_module(run)
run.prepare()
b.freeze()
print('REFINEMENT-V2 READY: oracle identity fix only; no compiler/linker/inference invoked')
