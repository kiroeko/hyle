"""Freeze the real completed-q retirement fix and its finite consumer only."""
from pathlib import Path
import difflib
import importlib.util
import sys

sys.dont_write_bytecode = True
P = Path(__file__).resolve().parent
PREVIOUS, W = P / 'refinement-v2', P / 'refinement-v3'
R = P.parents[1]
assert not W.exists(), 'Never overwrite an actual attempt'
spec = importlib.util.spec_from_file_location('sampling_before_retirement', PREVIOUS / 'build.py')
old = importlib.util.module_from_spec(spec); spec.loader.exec_module(old)
t = old.t
product_relative = 'engine/models/qwen35/main.cc'
source = R / product_relative
expected_product = '11e6683aa9e55dd4cdfa449f561942d3bb28e875864f5231929743de49d6c8f9'
assert t.pin(source)['sha256'] == expected_product
previous_product = t.read(P / 'product-freeze.json')
before = (R / previous_product['source']['snapshot']).read_text(encoding='utf-8')
after = source.read_text(encoding='utf-8')
old_block = '    if (generation && role == GraphRole::kVerify) model.finish_recursive_mtp(std::span(selections.data(), selections.size()), eos,\n        std::span(outputs.data(), outputs.size()), std::span(results.data(), results.size()), observe);'
new_block = '    if (generation && role == GraphRole::kVerify) {\n      model.finish_recursive_mtp(std::span(selections.data(), selections.size()), eos,\n          std::span(outputs.data(), outputs.size()), std::span(results.data(), results.size()), observe);\n      // The original verifier and prefix decision have retired and released\n      // their reads. Completed call records no longer need these private q\n      // leases; retaining them would charge the next episode\'s bounded pool.\n      for (auto &call : calls) call.draft_log_probabilities.clear();\n    }'
assert before.count(old_block) == 1 and before.replace(old_block, new_block) == after
snapshot = P / 'source-retirement' / product_relative
snapshot.parent.mkdir(parents=True)
with snapshot.open('xb') as stream: stream.write(source.read_bytes())
patch = P / 'product-q-retirement.diff'
with patch.open('x', encoding='utf-8') as stream:
    stream.write(''.join(difflib.unified_diff(before.splitlines(True), after.splitlines(True),
        fromfile='f8ab7d/' + product_relative, tofile='q-retirement/' + product_relative)))
source_pin = t.pin(source)
t.save(P / 'product-retirement-freeze.json', dict(status='SOURCE_FROZEN_NO_BUILD', base=previous_product['base'],
    source=dict(path=product_relative, bytes=source_pin['bytes'], sha256=source_pin['sha256'],
        snapshot=snapshot.relative_to(R).as_posix(), newline='LF'),
    translation_units=[product_relative], changed_product_headers=[], previous_freeze=t.pin(P / 'product-freeze.json'),
    delta=t.pin(patch), scope='Release original consumed per-call q ReadLeases only after successful original Verify finish.',
    preserved=['No pool/budget expansion, new owner, executor, queue or RNG/math change.',
        'A throwing/unretired finish keeps the original q reads; cleanup and retirement remain original.']))
W.mkdir()
build = (PREVIOUS / 'build.py').read_text(encoding='utf-8').replace("W.parent / 'product-freeze.json'", "W.parent / 'product-retirement-freeze.json'")
(W / 'build.py').write_text(build, encoding='utf-8')
run = (PREVIOUS / 'run.py').read_text(encoding='utf-8')
needle = '    checks = manual[\'state_checks\']'
assert needle in run
run = run.replace(needle, "    assert manual['completed_q_released'] is True and final['completed_q_released'] is True\n" + needle)
(W / 'run.py').write_text(run, encoding='utf-8')
spec = importlib.util.spec_from_file_location('sampling_q_retirement', W / 'build.py')
b = importlib.util.module_from_spec(spec); spec.loader.exec_module(b)
t = b.t
expected = t.read(PREVIOUS / 'expected-tests.json')
relative = 'tests/tools/qwen_mtp_sampling_case.h'
expected[relative] = 'c4a7907587ccfaca5ecdae17e53bdae93f542d329afe1de54474ed63c72f87b3'
for path, sha in expected.items(): assert t.pin(R / path)['sha256'] == sha, path
old_test = (PREVIOUS / 'source' / relative).read_text(encoding='utf-8')
with (W / 'consumer-q-retirement.diff').open('x', encoding='utf-8') as stream:
    stream.write(''.join(difflib.unified_diff(old_test.splitlines(True), (R / relative).read_text(encoding='utf-8').splitlines(True),
        fromfile='before/' + relative, tofile='q-retirement/' + relative)))
t.save(W / 'expected-tests.json', expected)
failure = t.read(PREVIOUS / 'runs/sampler-cpu/process.json')
assert failure['pid'] == 60876 and failure['exit'] == 1 and not failure['timed_out']
t.save(W / 'amendment.json', dict(reason='Real q permission over-retention by a successful completed PreparedGenerationCall.',
    changed_test_only=False, product=t.pin(P / 'product-retirement-freeze.json'),
    previous_ready=t.pin(PREVIOUS / 'ready-tiny.json'), original_failure=t.pin(PREVIOUS / 'runs/sampler-cpu/process.json'),
    consumer_patch=t.pin(W / 'consumer-q-retirement.diff'),
    fix='Release consumed q only after success; failed/unretired paths retain original reads. Original bounded pool is unchanged.',
    original_call_stays_alive=True, no_manual_test_q_clear=True, new_CXX=1, link=1, planned_processes=3))
b.prepare()
spec = importlib.util.spec_from_file_location('sampling_q_retirement_run', W / 'run.py')
run = importlib.util.module_from_spec(spec); spec.loader.exec_module(run)
run.prepare()
b.freeze()
print('REFINEMENT-V3 READY: distinct real product q-retirement fix; 0 CXX/link/inference invoked')
