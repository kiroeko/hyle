"""Prepare/freeze a distinct test-only retry; never invoke CXX/link/inference."""
from pathlib import Path
import difflib
import importlib.util
import json
import sys

sys.dont_write_bytecode = True
P = Path(__file__).resolve().parent
W = P / 'refinement'
R = P.parents[1]
assert not W.exists(), 'Preserve an existing refinement; do not overwrite or retry automatically'
W.mkdir()
build = (P / 'build.py').read_text(encoding='utf-8')
assert 'R = W.parents[1]' in build
build = build.replace('R = W.parents[1]', 'R = W.parents[2]')
build = build.replace("W / 'product-freeze.json'", "W.parent / 'product-freeze.json'")
(W / 'build.py').write_text(build, encoding='utf-8')
(W / 'run.py').write_text((P / 'run.py').read_text(encoding='utf-8'), encoding='utf-8')
spec = importlib.util.spec_from_file_location('sampling_refinement', W / 'build.py')
b = importlib.util.module_from_spec(spec); spec.loader.exec_module(b)
t = b.t
failed = t.read(P / 'logs/tiny/process.json')
assert failed['pid'] == 35872 and failed['exit'] == 2
expected = t.read(P / 'expected-tests.json')
relative = 'tests/tools/qwen_mtp_sampling_case.h'
expected[relative] = 'e472a3ebd9fc88938930ca050bfd527aafaaae9bdf403fa57699d6c94694af8d'
for path, sha in expected.items(): assert t.pin(R / path)['sha256'] == sha, path
before = (P / 'source' / relative).read_text(encoding='utf-8')
after = (R / relative).read_text(encoding='utf-8')
old_line = '  const std::array prefills{std::size_t{2}, std::size_t{3}}, single{std::size_t{1}}, pair{std::size_t{2}}, verify{std::size_t{3}};'
new_lines = '  const std::array prefills{std::size_t{2}, std::size_t{3}};\n  const std::array single{std::size_t{1}};\n  const std::array pair{std::size_t{2}};\n  const std::array verify{std::size_t{3}};'
assert before.count(old_line) == 1 and before.replace(old_line, new_lines) == after
(W / 'source-refinement.diff').write_text(''.join(difflib.unified_diff(before.splitlines(True), after.splitlines(True),
    fromfile='initial/' + relative, tofile='refinement/' + relative)), encoding='utf-8')
t.save(W / 'expected-tests.json', expected)
t.save(W / 'amendment.json', dict(reason='MSVC C3538: four deduced arrays of unequal lengths cannot share one declaration',
    changed_test_only=True, product=t.pin(P / 'product-freeze.json'), initial_freeze=t.pin(P / 'source-freeze.json'),
    initial_CXX_process=t.pin(P / 'logs/tiny/process.json'), source_patch=t.pin(W / 'source-refinement.diff'),
    initial_CXX_failure_preserved=True, retry_CXX=1, link=1, sampling_CPU=1, sampling_CUDA=1, stop_CPU=1))
b.prepare()
run_spec = importlib.util.spec_from_file_location('sampling_refinement_run', W / 'run.py')
run = importlib.util.module_from_spec(run_spec); run_spec.loader.exec_module(run)
run.prepare()
b.freeze()
print('REFINEMENT READY: original CXX failure retained; 1 new Tiny CXX/link and 3 planned processes only')
