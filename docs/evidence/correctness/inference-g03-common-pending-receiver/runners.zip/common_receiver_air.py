from pathlib import Path
import hashlib,json,os,subprocess,sys,time,zipfile
base=Path('/Users/kiro/hyle-scratch/compute-unified');source=base/'source-c8874688';out=base/'g03-common-receiver';out.mkdir(exist_ok=True)
identity={k:subprocess.check_output(a,text=True).strip() for k,a in [('model',['sysctl','-n','hw.model']),('os',['sw_vers']),('compiler',['clang++','--version'])]};assert identity['model']=='Mac16,12'
with zipfile.ZipFile(out/sys.argv[1]) as z:
 inputs=json.loads(z.read('input-manifest.json'))
 for r in inputs:
  assert r['path'].startswith(('src/','include/','tests/')) and '..' not in Path(r['path']).parts
  data=z.read(r['path']);assert hashlib.sha256(data).hexdigest()==r['sha256'];dest=source/r['path']
  if not dest.exists() or dest.read_bytes()!=data:dest.write_bytes(data)
digest=hashlib.sha256(json.dumps(inputs,sort_keys=True).encode()).hexdigest()
env=os.environ.copy();env['PATH']='/opt/homebrew/bin:'+env['PATH']
env.update(ASAN_OPTIONS='halt_on_error=1:detect_leaks=0',UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1',TSAN_OPTIONS='halt_on_error=1')
rows=json.loads((out/'result.json').read_text())['stages'] if (out/'result.json').exists() else []
cmake='/opt/homebrew/bin/cmake';ninja='/opt/homebrew/bin/ninja'
def run(mode,stage,args):
 attempt=1+sum(r['mode']==mode and r['stage']==stage for r in rows);log=out/f'{mode}-{stage}-{attempt}.log';start=time.monotonic()
 with log.open('w') as f:
  p=subprocess.Popen(args,env=env,stdout=f,stderr=subprocess.STDOUT)
  (out/'job.json').write_text(json.dumps(dict(state='RUNNING',pid=p.pid,mode=mode,stage=stage,log=str(log))))
  print('RUN',mode,stage,p.pid,flush=True);code=p.wait()
 rows.append(dict(mode=mode,stage=stage,command=args,input_manifest_sha256=digest,exit_code=code,elapsed_seconds=time.monotonic()-start,log=str(log)))
 (out/'result.json').write_text(json.dumps(dict(identity=identity,inputs=inputs,stages=rows,cumulative_seconds=sum(r['elapsed_seconds'] for r in rows)),indent=2)+'\n')
 (out/'job.json').write_text(json.dumps(dict(state='TERMINAL',exit_code=code)))
 print(json.dumps(rows[-1]),flush=True)
 if code:print(log.read_text(errors='replace')[-6500:],flush=True);raise SystemExit(code)
targets=[('g03_common_receiver64','pending_paged_receiver_cpu_consumer.cc'),('g03_common_receiver_risks','pending_paged_receiver_cpu_risks.cc')]
for mode in ['asan','ubsan','tsan']:
 folder=base/f'foundation-f5-native-host-vulkan-{mode}';parent=folder/'parent';build=folder/'build';body=(parent/'CMakeLists.txt').read_text()
 for target,name in targets:
  if f'add_executable({target} ' not in body:
   body+=f'\nadd_executable({target} "{source}/tests/compute_batch/{name}")\ntarget_compile_features({target} PRIVATE cxx_std_23)\ntarget_compile_options({target} PRIVATE -Wall -Wextra -Wpedantic -Werror)\ntarget_link_libraries({target} PRIVATE hyle::compute)\nhyle_apply_sanitizer({target})\nhyle_stage_runtime({target})\n'
   if mode=='tsan':body+=f'target_include_directories({target} BEFORE PRIVATE "{base}/g02-refcount-fence-probe/tsan-headers")\n'
 (parent/'CMakeLists.txt').write_text(body)
 run(mode,'configure',[cmake,'-S',str(parent),'-B',str(build)])
 run(mode,'build',[cmake,'--build',str(build),'--target',*[t for t,_ in targets],'--parallel','4'])
 commands=json.loads(subprocess.check_output([ninja,'-C',str(build),'-t','compdb'],env=env,text=True));flag='-fsanitize='+dict(asan='address',ubsan='undefined',tsan='thread')[mode]
 endings=['src/compute_batch/batch_execution.cc',*[f'tests/compute_batch/{n}' for _,n in targets]]
 checked=[r for r in commands if any(r['file'].endswith(n) for n in endings)]
 assert len(checked)==3 and all(flag in r['command'] for r in checked)
 (out/f'{mode}-instrumentation.json').write_text(json.dumps(checked,indent=2)+'\n')
 for target,_ in targets:run(mode,target,[str(build/target)])
for mode in ['static','shared']:
 producer=base/f'a-cpu-vulkan/selected-graph/{mode}-sdk-build';folder=out/mode;folder.mkdir(exist_ok=True);stage=folder/'staging';prefix=folder/'relocated'
 run(mode,'producer-build',[cmake,'--build',str(producer),'--target','hyle_compute_batch','--parallel','4'])
 assert not prefix.exists(),'do not overwrite a sealed SDK'
 run(mode,'install',[cmake,'--install',str(producer),'--prefix',str(stage)]);stage.rename(prefix)
 consumer=folder/'consumer';consumer.mkdir(exist_ok=True);name='pending_paged_receiver_cpu_consumer.cc';(consumer/name).write_bytes((source/'tests/compute_batch'/name).read_bytes())
 assert (prefix/'include/hyle/compute/batch_execution.h').read_bytes()==(source/'include/hyle/compute/batch_execution.h').read_bytes()
 (consumer/'header.cc').write_text('#include <hyle/compute/batch_execution.h>\n')
 (consumer/'CMakeLists.txt').write_text('''cmake_minimum_required(VERSION 3.25)
project(common_receiver_sdk LANGUAGES CXX)
find_package(Hyle CONFIG REQUIRED COMPONENTS compute)
add_executable(receiver pending_paged_receiver_cpu_consumer.cc)
add_library(headers OBJECT header.cc)
foreach(t receiver headers)
 target_compile_features(${t} PRIVATE cxx_std_23)
 target_compile_options(${t} PRIVATE -Wall -Wextra -Wpedantic -Werror)
 target_link_libraries(${t} PRIVATE hyle::compute)
endforeach()
hyle_stage_runtime(receiver)
''')
 build=folder/'build'
 run(mode,'configure',[cmake,'-S',str(consumer),'-B',str(build),'-G','Ninja','-DCMAKE_BUILD_TYPE=Release','-DCMAKE_PREFIX_PATH='+str(prefix),'-DCMAKE_EXPORT_COMPILE_COMMANDS=ON'])
 run(mode,'consumer-build',[cmake,'--build',str(build),'--target','receiver','headers','--parallel','4'])
 commands=json.loads((build/'compile_commands.json').read_text());assert len(commands)==2 and all(str(source) not in r['command'] and str(prefix/'include') in r['command'] for r in commands)
 (out/f'{mode}-compile-commands.json').write_text(json.dumps(commands,indent=2)+'\n');run(mode,'receiver64',[str(build/'receiver')])
receipts=[]
for mode in ['static','shared']:
 for p in (out/mode/'relocated').rglob('*'):
  if p.is_file() and (p.name.startswith('libhyle_compute_batch') or p.name=='batch_execution.h'):
   receipts.append(dict(path=str(p),sha256=hashlib.sha256(p.read_bytes()).hexdigest(),bytes=p.stat().st_size))
model=base/'g02-refcount-fence-probe/tsan-headers/hyle/util/ref_counted.h';model_sha=hashlib.sha256(model.read_bytes()).hexdigest();assert model_sha=='2b90ab655a49ec3b9158a964872cd1fc3395ebf64d8ae430a2e19c4805bf5416'
(out/'artifact-receipts.json').write_text(json.dumps(dict(artifacts=receipts,model=dict(path=str(model),sha256=model_sha)),indent=2)+'\n')
with zipfile.ZipFile(out/'raw.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in out.iterdir():
  if p.is_file() and p.name!='raw.zip':z.write(p,p.name)
 z.write(model,'models/ref_counted.h')
 for mode in ['static','shared']:
  for p in (out/mode/'consumer').iterdir():
   if p.is_file():z.write(p,f'{mode}-consumer/{p.name}')
print('ALL HOST/SDK STAGES TERMINAL',flush=True)
