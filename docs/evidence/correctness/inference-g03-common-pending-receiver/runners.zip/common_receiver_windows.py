from pathlib import Path
import hashlib,json,os,subprocess,time,sys
root=Path.cwd();out=root/'.scratch/inference-gaps/g03/common-receiver-windows';out.mkdir(exist_ok=True)
env=os.environ.copy()
for line in subprocess.check_output(['cmd','/d','/c',str(root/'.scratch/inference-gaps/g01/cpu-ragged-env.cmd')],text=True).splitlines():
 if '=' in line and not line.startswith('='):
  key,value=line.split('=',1);env[key]=value
parent=Path('C:/h7/inference-g01-native-vulkan/parent/CMakeLists.txt');build=parent.parent.parent/'build';body=parent.read_text();target='g03_common_receiver64'
if f'add_executable({target} ' not in body:
 body+=f'\nadd_executable({target} "{root.as_posix()}/tests/compute_batch/pending_paged_receiver_cpu_consumer.cc")\ntarget_compile_features({target} PRIVATE cxx_std_23)\ntarget_compile_options({target} PRIVATE /W4 /WX /wd4324 /utf-8)\ntarget_link_libraries({target} PRIVATE hyle::compute)\nhyle_stage_runtime({target})\n';parent.write_text(body,newline='\n')
risk='g03_common_receiver_risks'
if f'add_executable({risk} ' not in body:
 body+=f'\nadd_executable({risk} "{root.as_posix()}/tests/compute_batch/pending_paged_receiver_cpu_risks.cc")\ntarget_compile_features({risk} PRIVATE cxx_std_23)\ntarget_compile_options({risk} PRIVATE /W4 /WX /wd4324 /utf-8)\ntarget_link_libraries({risk} PRIVATE hyle::compute)\nhyle_stage_runtime({risk})\n';parent.write_text(body,newline='\n')
names=subprocess.check_output(['git','diff','--name-only','5f496b827'],text=True).splitlines()+['tests/compute_batch/pending_paged_receiver_cpu_consumer.cc','tests/compute_batch/pending_paged_receiver_cpu_risks.cc'];inputs=[dict(path=n,sha256=hashlib.sha256((root/n).read_bytes()).hexdigest()) for n in names if n.startswith(('include/','src/','tests/'))]
rows=json.loads((out/'result.json').read_bytes())['stages'] if (out/'result.json').exists() else []
stages=[('risk-build',['cmake','--build',str(build),'--target',risk,'--parallel','4']),('receiver-risks',[str(build/(risk+'.exe'))])] if '--risks-only' in sys.argv else [('build',['cmake','--build',str(build),'--target',target,risk,'g03_prefix_ggml','--parallel','4']),('receiver64',[str(build/(target+'.exe'))]),('receiver-risks',[str(build/(risk+'.exe'))]),('ready-regression',[str(build/'g03_prefix_ggml.exe')])]
for stage,args in stages:
 attempt=1+sum(r['stage']==stage for r in rows);log=out/f'{stage}-{attempt}.log';start=time.monotonic()
 with log.open('w') as f:
  p=subprocess.Popen(args,env=env,stdout=f,stderr=subprocess.STDOUT)
  (out/'job.json').write_text(json.dumps(dict(state='RUNNING',pid=p.pid,stage=stage,log=str(log))));print('RUN',stage,p.pid,flush=True);code=p.wait()
 rows.append(dict(stage=stage,command=args,exit_code=code,elapsed_seconds=time.monotonic()-start,inputs=inputs,log=str(log)))
 (out/'result.json').write_text(json.dumps(dict(scope='Actual native CPU page16 pending receiver; no GPU/model/P1',stages=rows,cumulative_seconds=sum(r['elapsed_seconds'] for r in rows)),indent=2)+'\n',newline='\n')
 (out/'job.json').write_text(json.dumps(dict(state='TERMINAL',exit_code=code)))
 print(json.dumps({k:v for k,v in rows[-1].items() if k!='inputs'}),flush=True)
 if code:print(log.read_text(errors='replace')[-5500:],flush=True);raise SystemExit(code)
