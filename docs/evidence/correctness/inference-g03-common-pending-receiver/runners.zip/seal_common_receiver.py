from pathlib import Path
import hashlib,json,shutil,subprocess,zipfile
root=Path.cwd();task=root/'.scratch/inference-gaps/g03';out=root/'evidence/correctness/inference-g03-common-pending-receiver';out.mkdir(exist_ok=True)
windows=json.loads((task/'common-receiver-windows/result.json').read_bytes())
last={r['stage']:r for r in windows['stages']}
for stage in ['receiver64','receiver-risks','ready-regression']:
 r=last[stage];assert r['exit_code']==0
 for row in r['inputs']:
  if row['path'].startswith(('include/','src/')):assert hashlib.sha256((root/row['path']).read_bytes()).hexdigest()==row['sha256']
assert Path(last['receiver64']['log']).read_text().count('common CPU pending receiver PASS:64')==2
assert Path(last['receiver-risks']['log']).read_text().count('PASS')==7
shutil.copyfile(task/'common-receiver-air/raw.zip',out/'air-raw.zip')
with zipfile.ZipFile(out/'air-raw.zip') as z:
 air=json.loads(z.read('result.json'));latest={(r['mode'],r['stage']):r for r in air['stages']}
 for row in air['inputs']:assert hashlib.sha256((root/row['path']).read_bytes()).hexdigest()==row['sha256']
 for mode in ['asan','ubsan','tsan']:
  for stage,count,marker in [('g03_common_receiver64',2,'common CPU pending receiver PASS:64'),('g03_common_receiver_risks',7,'PASS')]:
   r=latest[mode,stage];assert r['exit_code']==0 and z.read(Path(r['log']).name).decode().count(marker)==count
 for mode in ['static','shared']:
  r=latest[mode,'receiver64'];assert r['exit_code']==0 and z.read(Path(r['log']).name).decode().count('common CPU pending receiver PASS:64')==2
 for name in ['result.json','artifact-receipts.json',*[m+'-instrumentation.json' for m in ['asan','ubsan','tsan']],*[m+'-compile-commands.json' for m in ['static','shared']]]:(out/('air-'+name)).write_bytes(z.read(name))
cuda=json.loads((task/'common-receiver-cuda/result.json').read_bytes());clast={r['stage']:r for r in cuda['stages']}
assert clast['actual-512-byte-native']['exit_code']==0
for row in clast['actual-512-byte-native']['inputs']:assert hashlib.sha256((root/row['path']).read_bytes()).hexdigest()==row['sha256']
assert (task/'common-receiver-cuda'/Path(clast['actual-512-byte-native']['log']).name).read_text().count('PASS')==2
for prefix,data in [('windows',windows),('cuda',cuda)]:
 (out/(prefix+'-result.json')).write_text(json.dumps(data,indent=2)+'\n',newline='\n')
 with zipfile.ZipFile(out/(prefix+'-raw.zip'),'w',zipfile.ZIP_DEFLATED) as z:
  for p in (task/f'common-receiver-{prefix}').iterdir():
   if p.is_file():z.write(p,p.name)
names=['include/hyle/compute/batch_execution.h','src/compute_batch/batch_execution.cc','tests/compute_batch/pending_paged_receiver_cpu_consumer.cc','tests/compute_batch/pending_paged_receiver_cpu_risks.cc','tests/compute_batch/pending_paged_receiver_cuda_consumer.cc']
(out/'product-inputs.json').write_text(json.dumps(dict(baseline='5f496b827',audit='78ee5edcd',inputs=[dict(path=n,sha256=hashlib.sha256((root/n).read_bytes()).hexdigest()) for n in names]),indent=2)+'\n',newline='\n')
summary=dict(scope='BC01-BC04 implemented checkpoint. Native CPU common receiver tested; CUDA small source probe, no complete G03 acceptance',
 passed=['Windows and actual Air mixed456 native CPU F16/BF16, GQA8/2 D256, two requests/two original slots/64 steps, growth and Q1/17, independent double oracle',
 'Seven actual native CPU boundary modes: hole, foreign layout, each cold allocation OOM, original completion capacity, closed context, old external ticket, output/source/ready recovery and reuse',
 'Actual host ASan/UBSan/TSan each same64 and seven boundaries; original exact ref-count fence TSan model, ASan detect_leaks=0',
 'Two relocated static/shared CPU public64 consumers plus standalone batch_execution.h; compile command and library/header receipts retained',
 'Windows original native CPU ready paged/ragged five tests PASS',
 'Actual CUDA 512-byte original gated producer/F2/FlashInfer paged attention, same original shared queue and final-only aggregate, mean .25 numeric oracle and control/output/ready recovery',
 'Original native CPU qualification rejects CUDA pinned resource lacking coherent-host property; no asynchronous CPU import or cross-domain numerical journey signed'],
 cost='Opt-in ref-counted cold receiver plus original CopyOutcomeSource/DependentCompletion/CompletionRetention; original BatchInvocation/PreparedBatch/RetainedCompletion/QueueSequence and provider math. Ready objects unchanged. Warm submit does not allocate source nodes or copy KV. Original prepare metadata waits/native planner and managed CUDA dispatch remain.',
 seconds=dict(windows=windows['cumulative_seconds'],air=air['cumulative_seconds'],cuda=cuda['cumulative_seconds']),
 limits=['AUDITED implementation checkpoint; selected reverse factors/whole BC04/whole G03 are not signed PASS',
 'Current source/SDK CPU tests use mixed456 qualification; closed CPU-only ffa math evidence retained rather than rerun',
 'Host sanitizers do not instrument GPU kernel/driver and do not prove all races or leaks',
 'CUDA source probe uses existing HYLE_TESTING backend tree without new hooks in this public fixture; no CUDA shipping static/shared receiver journey or source64/risk matrix signed',
 'Asynchronous CPU import rejection, accepted-prefix/source-error/unknown/abandon common paths, explicit resource-budget bounds, Graph consumption, native late backing, independent reduction and full seven routes remain'],
 retained_failures=['Windows first CPU64: real empty successful inline-prefix incorrectly sent to native dependency wait; fixed receiver glue pending check',
 'Windows second CPU64: fixture read required capacity-size view; fixed active output subview, original API preserved',
 'CUDA first runtime terminated after111.257s: actual backtrace shows first cudaFuncSetAttribute module load blocked by fixture host callback. Same original controller explicitly warmed before gated submit, original failure retained',
 'CUDA CPU import attempt used stale disposable CPU provider without BatchPlanning. Canonical CLOSED provider files copied one-way for validation, no product reopening',
 'Next CPU crossing fixture assumed CUDA pinned resource has coherent-host property. Actual provider correctly rejected it; final probe explicitly tests only that resource qualification, no async import/retired CPU numerical claim',
 'Initial plain Ninja dry run stops at hypothetical CONFIGURE_DEPENDS regeneration. Snapshot dry-run manifest byte-identical, actual build uses original unmodified tree. Early dry-run log overwritten across two successful retries; original stage/input/time records retained, no claim of separate historical raw snapshots'],
 remaining='Complete common failure/retirement and CUDA acceptance; original Graph/late native producer backing, full seven-route and independent reduction; G01/G02 unresolved gates and G04-G10 unchanged')
(out/'validation-result.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
shutil.copyfile(task/'common-receiver-plan.json',out/'validation-plan.json')
with zipfile.ZipFile(out/'runners.zip','w',zipfile.ZIP_DEFLATED) as z:
 for name in ['common_receiver_windows.py','common_receiver_air.py','run_common_receiver_air.py','common_receiver_cuda.py','common_receiver_cuda_preflight.py','seal_common_receiver.py']:z.write(task/name,name)
card=root/'docs/implementation/tasks/compute/inference-g03-pending-page-consumption.md';s=card.read_text(encoding='utf-8')
s+='''
## BC01–BC04 公共 receiver 实施检查点（2026-10-14）

共同 receiver 已实现，[定向验证记录](../../../../evidence/correctness/inference-g03-common-pending-receiver/validation-result.json)
保产品字节、每阶段输入、原失败/累计、宿主模型与 SDK receipts。Windows/Air 原生 CPU
F16/BF16 两请求/两原 slot/64步和 double oracle、七边界、三宿主 sanitizer、两迁址
static/shared SDK 与独立公共头通过；Windows 原 ready paged/ragged 五测试通过。
CUDA 512-byte 真实 gated producer→原 F2→原 FlashInfer paged 原生数学与最终聚合通过；
原 CPU 数学资格明确拒绝未声明 coherent-host 的 CUDA pinned resource；此负例不签
CPU 异步来源接纳/拒绝或跨域数值旅程。CUDA 只编译 C++ glue/fixture，原 kernel artifact
复用，无 nvcc。

CPU 首次真实 inline 空 prefix 实现失败与第二次 capacity-view fixture 失败保留。
CUDA 首次 native kernel 属性/模块加载与 fixture host gate 互等，原 111.257s 与实际
backtrace保留；同一原 controller 显式预热后通过。WSL旧CPU provider缺 BatchPlanning
的验证副本失败保留，只从canonical同步原已关闭provider，不反向覆盖产品或重开owner。

本批继续 AUDITED，不签完整 BC04/G03、CUDA 三交付/64步或所有 reverse-factor 门。
CPU异步来源拒绝、接纳后来源错误/unknown/abandon、明确资源预算边界、Graph、late native backing与
七路线/正交 reduction 仍必需。原 G01/G02未决门与 G04–G10、失败和 private UNKNOWN
全部保留；只复用本批已证明门，整体粗估20%、完整项目0/10。所有本批 heavy 已terminal。
''';card.write_text(s,encoding='utf-8',newline='\n')
p=root/'docs/implementation/module-status.json';d=json.loads(p.read_bytes())
row=next(r for r in d['modules'] if r['module']=='compute_batch');assert row['state']=='AUDITED'
row['summary']='G03 common and native receivers implemented checkpoints, still AUDITED. Native Apple/Vulkan prior64/risk/san/SDK preserved; common CPU F16/BF16 two-request/two-slot64 +seven boundaries +three hostsan +static/shared public SDKs and Windows ready5 PASS. CUDA actual512-byte paged native probe and original CPU coherent-resource refusal PASS, no new kernels. Full common async/failure/budget/CUDA, Graph, late output and seven-route acceptance remain.'
p.write_bytes((json.dumps(d,ensure_ascii=False,indent=2)+'\n').replace('\n','\r\n').encode('utf-8'))
hp=root/'.scratch/inference-gaps/g01/handoff-current.json';h=json.loads(hp.read_bytes())
h.update(rough_percent=20,whole_items_completed='0/10',live_jobs=[],last_turn_classification='PROGRESS: BC common receiver actual CPU64/risk7/3san/2SDK plus CUDA512 and original CPU coherent-resource refusal checkpoint. Entire main card AUDITED, all heavy terminal; goal active.',next_resume=summary['remaining'])
h['G03_common_pending_receiver']=dict(state='AUDITED_IMPLEMENTED_CHECKPOINT',baseline='5f496b827',audit='78ee5edcd',evidence=out.relative_to(root).as_posix(),verified=summary['passed'],limits=summary['limits'],remaining=summary['remaining'],terminal_sessions=[15837,59766,84234,15208,84678,38540,46863])
hp.write_text(json.dumps(h,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(summary['seconds']))
