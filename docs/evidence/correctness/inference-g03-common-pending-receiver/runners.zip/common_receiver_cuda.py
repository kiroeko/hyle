from pathlib import Path
import hashlib,json,os,subprocess,time
canonical=Path('/mnt/c/public/project-hyle/hyle');base=Path('/root/hyle-scratch/compute-unified');source=base/'source-7a7b4c3b';parent=base/'l-cpu-cuda/selected-graph/source-parent';build=parent.parent/'source-build';out=canonical/'.scratch/inference-gaps/g03/common-receiver-cuda';out.mkdir(exist_ok=True)
inputs=[]
for name in ['include/hyle/compute/batch_execution.h','src/compute_batch/batch_execution.cc','tests/compute_batch/pending_paged_receiver_cuda_consumer.cc',
    'src/compute_provider_ggml/CMakeLists.txt','src/compute_provider_ggml/ggml_cpu_provider.cc',
    'src/compute_provider_ggml/native_batch.cc','src/compute_provider_ggml/native_batch.h']:
 data=(canonical/name).read_bytes();dest=source/name
 if not dest.exists() or dest.read_bytes()!=data:dest.write_bytes(data)
 inputs.append(dict(path=name,sha256=hashlib.sha256(data).hexdigest()))
target='g03_common_receiver_cuda';p=parent/'CMakeLists.txt';body=p.read_text()
if f'add_executable({target} ' not in body:
 body+=f'\nadd_executable({target} "{source}/tests/compute_batch/pending_paged_receiver_cuda_consumer.cc")\ntarget_compile_features({target} PRIVATE cxx_std_23)\ntarget_compile_options({target} PRIVATE -Wall -Wextra -Wpedantic -Werror)\ntarget_link_libraries({target} PRIVATE hyle_compute_batch hyle_compute_backend_cuda hyle_compute_provider_flashinfer hyle_compute_route_cpu)\nhyle_stage_runtime({target})\n';p.write_text(body)
link='target_link_libraries(g03_common_receiver_cuda PRIVATE hyle_compute_batch hyle_compute_backend_cuda hyle_compute_provider_flashinfer)'
if link in body:
 body=body.replace(link,link[:-1]+' hyle_compute_route_cpu)');p.write_text(body)
parent_sha=hashlib.sha256(body.encode()+(source/'src/compute_provider_ggml/CMakeLists.txt').read_bytes()).hexdigest()
env=os.environ.copy();env['PATH']='/usr/local/cuda-13.3/bin:'+env['PATH'];env['LD_LIBRARY_PATH']='/usr/local/cuda-13.3/targets/x86_64-linux/lib:/usr/lib/wsl/lib:'+env.get('LD_LIBRARY_PATH','')
identity=dict(uname=subprocess.check_output(['uname','-a'],text=True).strip(),gpu=subprocess.check_output(['nvidia-smi','--query-gpu=name,driver_version,memory.used,utilization.gpu','--format=csv,noheader'],text=True).strip())
rows=json.loads((out/'result.json').read_text())['stages'] if (out/'result.json').exists() else []
def record(stage,args,code,seconds,log):
 rows.append(dict(stage=stage,command=args,exit_code=code,elapsed_seconds=seconds,inputs=inputs,log=str(log)))
 (out/'result.json').write_text(json.dumps(dict(identity=identity,stages=rows,cumulative_seconds=sum(r['elapsed_seconds'] for r in rows)),indent=2)+'\n')
 (out/'job.json').write_text(json.dumps(dict(state='TERMINAL',exit_code=code)));print(json.dumps(rows[-1]),flush=True)
def run(stage,args):
 attempt=1+sum(r['stage']==stage for r in rows);log=out/f'{stage}-{attempt}.log';start=time.monotonic()
 with log.open('w') as f:
  process=subprocess.Popen(args,env=env,stdout=f,stderr=subprocess.STDOUT)
  (out/'job.json').write_text(json.dumps(dict(state='RUNNING',pid=process.pid,stage=stage,log=str(log))));print('RUN',stage,process.pid,flush=True);code=process.wait()
 record(stage,args,code,time.monotonic()-start,log)
 if code:print(log.read_text(errors='replace')[-6000:],flush=True);raise SystemExit(code)
cache=out/'configured-parent-sha256.txt'
if not cache.exists() or cache.read_text()!=parent_sha:
 run('configure',['cmake','-S',str(parent),'-B',str(build)]);cache.write_text(parent_sha)
# CONFIGURE_DEPENDS has a phony VerifyGlobs input. Ordinary Ninja -n therefore
# stops at a hypothetical CMake regeneration rather than listing build work.
# Dry-run an exact copy under a non-generated manifest name. Actual builds
# always use the original unmodified CMake/Ninja tree, never this snapshot.
snapshot=build/'g03-common-receiver-preflight.ninja';original=(build/'build.ninja').read_bytes();snapshot.write_bytes(original)
args=['ninja','-C',str(build),'-f',str(snapshot),'-n',target];start=time.monotonic();dry=subprocess.run(args,env=env,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
dry_attempt=1+sum(r['stage']=='no-kernel-build-preflight' for r in rows);log=out/f'dry-run-{dry_attempt}.log';log.write_text(dry.stdout)
kernel_lines=[line for line in dry.stdout.splitlines() if '.cu.o' in line or 'nvcc' in line]
assert 'Re-running CMake' not in dry.stdout,'dry run is not definitive until CMake regeneration completes'
artifacts=[]
for path in (build/'hyle/src/compute_provider_flashinfer').glob('libhyle_compute_provider_flashinfer*'):
 if path.is_file():artifacts.append(dict(path=str(path),bytes=path.stat().st_size,sha256=hashlib.sha256(path.read_bytes()).hexdigest()))
(out/f'artifact-preflight-{dry_attempt}.json').write_text(json.dumps(dict(artifacts=artifacts,inputs=inputs,kernel_lines=kernel_lines,original_manifest_sha256=hashlib.sha256(original).hexdigest(),dry_manifest_identical=snapshot.read_bytes()==original,actual_build_uses_original_manifest=True),indent=2)+'\n')
record('no-kernel-build-preflight',args,90 if kernel_lines else dry.returncode,time.monotonic()-start,log)
if kernel_lines:print('UNPROVEN: actual target requires prohibited new CUDA kernel compilation; no build/runtime launched',flush=True);raise SystemExit(90)
if dry.returncode:raise SystemExit(dry.returncode)
run('build',['cmake','--build',str(build),'--target',target,'--parallel','4'])
run('actual-512-byte-native',[str(build/target)])
