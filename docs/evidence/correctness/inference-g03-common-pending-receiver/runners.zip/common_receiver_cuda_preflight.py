from pathlib import Path
import hashlib,json,os,subprocess
canonical=Path('/mnt/c/public/project-hyle/hyle');base=Path('/root/hyle-scratch/compute-unified');source=base/'source-7a7b4c3b';build=base/'l-cpu-cuda/selected-graph/source-build';out=canonical/'.scratch/inference-gaps/g03/common-receiver-cuda-preflight';out.mkdir(exist_ok=True)
inputs=[]
for name in ['include/hyle/compute/batch_execution.h','src/compute_batch/batch_execution.cc']:
 data=(canonical/name).read_bytes();dest=source/name
 if dest.read_bytes()!=data:dest.write_bytes(data)
 inputs.append(dict(path=name,sha256=hashlib.sha256(data).hexdigest()))
env=os.environ.copy();env['PATH']='/usr/local/cuda-13.3/bin:'+env['PATH']
p=subprocess.run(['ninja','-C',str(build),'-n','hyle_compute_batch'],env=env,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
(out/'dry-run.log').write_text(p.stdout)
artifacts=[]
for path in (build/'hyle/src/compute_provider_flashinfer').glob('libhyle_compute_provider_flashinfer*'):
 if path.is_file():artifacts.append(dict(path=str(path),bytes=path.stat().st_size,sha256=hashlib.sha256(path.read_bytes()).hexdigest()))
kernel_lines=[line for line in p.stdout.splitlines() if '.cu.o' in line or 'nvcc' in line]
regen_pending='Re-running CMake' in p.stdout
result=dict(scope='Original FlashInfer CUDA math artifact inventory plus canonical-to-disposable BC inputs and Ninja dry-run; no build/runtime started',inputs=inputs,dry_run_exit=p.returncode,artifacts=artifacts,kernel_build_required=bool(kernel_lines),cmake_regeneration_pending=regen_pending,kernel_lines=kernel_lines,verdict='INCONCLUSIVE_REGENERATION_PENDING' if regen_pending else 'UNPROVEN_NO_BUILD' if kernel_lines or p.returncode else 'NO_KERNEL_BUILD_REQUIRED',state='TERMINAL')
(out/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
