#include <hyle/compute/detail/generated_result.h>
