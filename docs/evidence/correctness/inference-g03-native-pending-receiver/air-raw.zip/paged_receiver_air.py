from pathlib import Path
import hashlib,json,os,subprocess,sys,time,zipfile
base=Path('/Users/kiro/hyle-scratch/compute-unified');source=base/'source-c8874688';out=base/'g03-paged-receiver';out.mkdir(exist_ok=True)
identity={k:subprocess.check_output(a,text=True).strip() for k,a in [('model',['sysctl','-n','hw.model']),('arch',['uname','-m']),('os',['sw_vers']),('compiler',['clang++','--version'])]};assert identity['model']=='Mac16,12'
with zipfile.ZipFile(out/sys.argv[1]) as z:
 inputs=json.loads(z.read('input-manifest.json'))
 for r in inputs:
  assert r['path'].startswith(('src/','include/','tests/')) and '..' not in Path(r['path']).parts
  data=z.read(r['path']);assert hashlib.sha256(data).hexdigest()==r['sha256'];destination=source/r['path']
  if not destination.exists() or destination.read_bytes()!=data:destination.write_bytes(data)
env=os.environ.copy();env['PATH']='/Users/kiro/hyle-verify-tools/metal-17F109/shim:/opt/homebrew/bin:'+env['PATH']
env.update(ASAN_OPTIONS='halt_on_error=1:detect_leaks=0',UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1',TSAN_OPTIONS='halt_on_error=1')
rows=json.loads((out/'result.json').read_text())['stages'] if (out/'result.json').exists() else []
digest=hashlib.sha256(json.dumps(inputs,sort_keys=True).encode()).hexdigest()
def run(route,mode,stage,args):
 attempt=1+sum(r['route']==route and r['mode']==mode and r['stage']==stage for r in rows);log=out/f'{route}-{mode}-{stage}-{attempt}.log';start=time.monotonic()
 with log.open('w') as f:
  p=subprocess.Popen(args,env=env,stdout=f,stderr=subprocess.STDOUT)
  (out/'job.json').write_text(json.dumps(dict(state='RUNNING',pid=p.pid,route=route,mode=mode,stage=stage,log=str(log))))
  print('RUN',route,mode,stage,p.pid,flush=True);code=p.wait()
 rows.append(dict(route=route,mode=mode,stage=stage,command=args,input_manifest_sha256=digest,exit_code=code,elapsed_seconds=time.monotonic()-start,log=str(log)))
 (out/'result.json').write_text(json.dumps(dict(identity=identity,inputs=inputs,stages=rows,cumulative_seconds=sum(r['elapsed_seconds'] for r in rows)),indent=2)+'\n')
 (out/'job.json').write_text(json.dumps(dict(state='TERMINAL',exit_code=code,last_stage=rows[-1])))
 print(json.dumps(rows[-1]),flush=True)
 if code:print(log.read_text(errors='replace')[-6500:],flush=True);raise SystemExit(code)
cmake='/opt/homebrew/bin/cmake'
for route in ([] if '--validation-only' in sys.argv else ['apple','vulkan']):
 producer=base/f'a-cpu-{route}/selected-graph/static-sdk-build';folder=out/f'{route}-source';folder.mkdir(exist_ok=True);prefix=folder/'prefix'
 run(route,'source','producer-build',[cmake,'--build',str(producer),'--target','hyle_compute_batch',f'hyle_compute_route_{route}','--parallel','4'])
 run(route,'source','install',[cmake,'--install',str(producer),'--prefix',str(prefix)])
 parent=folder/'parent';parent.mkdir(exist_ok=True);body=f'''cmake_minimum_required(VERSION 3.25)
project(pending_receiver_source LANGUAGES CXX)
find_package(Hyle CONFIG REQUIRED COMPONENTS compute)
add_executable(receiver "{source}/tests/compute_batch/pending_paged_receiver_native_consumer.cc")
add_executable(risks "{source}/tests/compute_batch/pending_paged_receiver_native_risks.cc")
foreach(t receiver risks)
 target_compile_features(${{t}} PRIVATE cxx_std_23)
 target_compile_options(${{t}} PRIVATE -Wall -Wextra -Wpedantic -Werror)
 target_link_libraries(${{t}} PRIVATE hyle::compute)
 hyle_stage_runtime(${{t}})
endforeach()
'''
 if route=='apple':body+='target_compile_definitions(receiver PRIVATE HYLE_PENDING_RECEIVER_APPLE=1)\ntarget_compile_definitions(risks PRIVATE HYLE_G01_PAGE_RISK_APPLE=1)\n'
 (parent/'CMakeLists.txt').write_text(body);build=folder/'build'
 run(route,'source','configure',[cmake,'-S',str(parent),'-B',str(build),'-G','Ninja','-DCMAKE_BUILD_TYPE=Release','-DCMAKE_PREFIX_PATH='+str(prefix)])
 targets=['risks'] if '--risks-only' in sys.argv else ['receiver','risks']
 run(route,'source','build',[cmake,'--build',str(build),'--target',*targets,'--parallel','4'])
 if '--risks-only' not in sys.argv:run(route,'source','receiver64',[str(build/'receiver')])
 run(route,'source','risks',[str(build/'risks')])
if '--validation-only' in sys.argv:
 for route in ['apple','vulkan']:
  for mode in ['asan','ubsan','tsan']:
   folder=base/f'foundation-f5-native-host-{route}-{mode}';parent=folder/'parent';build=folder/'build';body=(parent/'CMakeLists.txt').read_text()
   targets=[('g03_receiver64','pending_paged_receiver_native_consumer.cc'),('g03_receiver_risks','pending_paged_receiver_native_risks.cc'),('g03_receiver_ready',f'native_paged_{route}_risks.cc')]
   for target,name in targets:
    if f'add_executable({target} ' not in body:
     body+=f'\nadd_executable({target} "{source}/tests/compute_batch/{name}")\ntarget_compile_features({target} PRIVATE cxx_std_23)\ntarget_compile_options({target} PRIVATE -Wall -Wextra -Wpedantic -Werror)\ntarget_link_libraries({target} PRIVATE hyle::compute)\nhyle_apply_sanitizer({target})\nhyle_stage_runtime({target})\n'
     if route=='apple':body+=f'target_compile_definitions({target} PRIVATE '+('HYLE_PENDING_RECEIVER_APPLE' if target=='g03_receiver64' else 'HYLE_G01_PAGE_RISK_APPLE')+'=1)\n'
     if mode=='tsan':
      body+=f'target_include_directories({target} BEFORE PRIVATE "{base}/g02-refcount-fence-probe/tsan-headers")\n'
      if route=='apple':body+=f'target_include_directories({target} BEFORE PRIVATE "{base}/g01-metal-callback-tsan-probe/tsan-metal-cpp")\n'
   (parent/'CMakeLists.txt').write_text(body)
   run(route,mode,'configure',[cmake,'-S',str(parent),'-B',str(build)])
   run(route,mode,'build',[cmake,'--build',str(build),'--target',*[t for t,_ in targets],'--parallel','4'])
   commands=json.loads(subprocess.check_output(['/opt/homebrew/bin/ninja','-C',str(build),'-t','compdb'],env=env,text=True));flag='-fsanitize='+dict(asan='address',ubsan='undefined',tsan='thread')[mode]
   endings=[f'src/compute_route_{route}/{route}_materialized_invocation.cc',f'src/compute_route_{route}/{route}_memory.'+('mm' if route=='apple' else 'cc'),'tests/compute_batch/pending_paged_receiver_native_consumer.cc','tests/compute_batch/pending_paged_receiver_native_risks.cc']
   checked=[r for r in commands if any(r['file'].endswith(n) for n in endings)]
   assert len(checked)==4 and all(flag in r['command'] for r in checked)
   (out/f'{route}-{mode}-instrumentation.json').write_text(json.dumps(checked,indent=2)+'\n')
   for target,_ in targets:run(route,mode,target,[str(build/target)])
 for route in ['apple','vulkan']:
  for mode in ['static','shared']:
   producer=base/f'a-cpu-{route}/selected-graph/{mode}-sdk-build';folder=out/f'{route}-{mode}';folder.mkdir(exist_ok=True);stage=folder/'staging';prefix=folder/'relocated'
   run(route,mode,'producer-build',[cmake,'--build',str(producer),'--target','hyle_compute_batch',f'hyle_compute_route_{route}','--parallel','4'])
   if not prefix.exists():
    run(route,mode,'install',[cmake,'--install',str(producer),'--prefix',str(stage)]);stage.rename(prefix)
   assert not stage.exists()
   consumer=folder/'consumer';consumer.mkdir(exist_ok=True)
   name='pending_paged_receiver_native_consumer.cc';(consumer/name).write_bytes((source/'tests/compute_batch'/name).read_bytes())
   headers=[f'{route}_batch.h','detail/generated_result.h']
   for i,name in enumerate(headers):
    assert (prefix/'include/hyle/compute'/name).read_bytes()==(source/'include/hyle/compute'/name).read_bytes();(consumer/f'header-{i}.cc').write_text(f'#include <hyle/compute/{name}>\n')
   body=f'''cmake_minimum_required(VERSION 3.25)
project(paged_receiver_sdk LANGUAGES CXX)
find_package(Hyle CONFIG REQUIRED COMPONENTS compute)
add_executable(receiver pending_paged_receiver_native_consumer.cc)
add_library(headers OBJECT header-0.cc header-1.cc)
foreach(t receiver headers)
 target_compile_features(${{t}} PRIVATE cxx_std_23)
 target_compile_options(${{t}} PRIVATE -Wall -Wextra -Wpedantic -Werror)
 target_link_libraries(${{t}} PRIVATE hyle::compute)
endforeach()
hyle_stage_runtime(receiver)
'''
   if route=='apple':body+='target_compile_definitions(receiver PRIVATE HYLE_PENDING_RECEIVER_APPLE=1)\n'
   (consumer/'CMakeLists.txt').write_text(body);build=folder/'build'
   run(route,mode,'configure',[cmake,'-S',str(consumer),'-B',str(build),'-G','Ninja','-DCMAKE_BUILD_TYPE=Release','-DCMAKE_PREFIX_PATH='+str(prefix),'-DCMAKE_EXPORT_COMPILE_COMMANDS=ON'])
   run(route,mode,'consumer-build',[cmake,'--build',str(build),'--target','receiver','headers','--parallel','4'])
   commands=json.loads((build/'compile_commands.json').read_text());assert len(commands)==3 and all(str(source) not in r['command'] and str(prefix/'include') in r['command'] for r in commands)
   (out/f'{route}-{mode}-compile-commands.json').write_text(json.dumps(commands,indent=2)+'\n')
   run(route,mode,'receiver64',[str(build/'receiver')])
