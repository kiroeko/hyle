from pathlib import Path
import hashlib,json,zipfile
base=Path('/Users/kiro/hyle-scratch/compute-unified');out=base/'g03-paged-receiver'
paths=[p for p in out.iterdir() if p.is_file() and p.suffix in ('.log','.json','.py','.zip') and p.name!='raw.zip'];receipts=[]
for route in ['apple','vulkan']:
 for mode in ['source','static','shared']:
  folder=out/f'{route}-{mode}';prefix=folder/('prefix' if mode=='source' else 'relocated')
  if not prefix.exists():continue
  for p in prefix.rglob('*'):
   if p.is_file() and ((p.name.startswith('libhyle_compute') and p.suffix in ('.a','.dylib')) or (p.suffix=='.h' and p.name in (f'{route}_batch.h','generated_result.h','materialized_native_controller.h'))):receipts.append(dict(path=str(p),sha256=hashlib.sha256(p.read_bytes()).hexdigest(),bytes=p.stat().st_size))
  consumer=folder/('parent' if mode=='source' else 'consumer')
  paths.extend(p for p in consumer.iterdir() if p.is_file())
models=[]
for name in ['g02-refcount-fence-probe/tsan-headers/hyle/util/ref_counted.h','g01-metal-callback-tsan-probe/tsan-metal-cpp/Metal/MTLCommandBuffer.hpp']:
 p=base/name;models.append(dict(path=name,sha256=hashlib.sha256(p.read_bytes()).hexdigest()))
assert [r['sha256'] for r in models]==['2b90ab655a49ec3b9158a964872cd1fc3395ebf64d8ae430a2e19c4805bf5416','4a58c6e564e3a7efcdf5c7709eeee99ec7b7c40594e2ada5ec5c91012171d504']
(out/'artifact-receipts.json').write_text(json.dumps(dict(artifacts=receipts,models=models),indent=2)+'\n');paths.append(out/'artifact-receipts.json')
with zipfile.ZipFile(out/'raw.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(set(paths)):z.write(p,p.relative_to(out).as_posix())
 for model in models:z.write(base/model['path'],'models/'+model['path'])
print(json.dumps(dict(files=len(set(paths)),artifacts=len(receipts),bytes=(out/'raw.zip').stat().st_size)))
