from pathlib import Path
import hashlib,json,os,subprocess,time
root=Path.cwd();out=root/'.scratch/inference-gaps/g03/paged-receiver-windows';out.mkdir(exist_ok=True)
env=os.environ.copy()
for line in subprocess.check_output(['cmd','/d','/c',str(root/'.scratch/inference-gaps/g01/cpu-ragged-env.cmd')],text=True).splitlines():
 if '=' in line and not line.startswith('='):
  key,value=line.split('=',1);env[key]=value
parent=Path('C:/h7/inference-g01-native-vulkan/parent/CMakeLists.txt');build=parent.parent.parent/'build';body=parent.read_text()
target='g03_pending_receiver_compile'
if f'add_executable({target} ' not in body:
 body+=f'\nadd_executable({target} "{root.as_posix()}/tests/compute_batch/pending_paged_receiver_native_consumer.cc")\ntarget_compile_features({target} PRIVATE cxx_std_23)\ntarget_compile_options({target} PRIVATE /W4 /WX /wd4324 /utf-8)\ntarget_link_libraries({target} PRIVATE hyle::compute)\nhyle_stage_runtime({target})\n';parent.write_text(body,newline='\n')
inputs=[]
for name in subprocess.check_output(['git','diff','--name-only','9b3cd6217'],text=True).splitlines()+['tests/compute_batch/pending_paged_receiver_native_consumer.cc']:
 if name.startswith(('include/','src/','tests/')):inputs.append(dict(path=name,sha256=hashlib.sha256((root/name).read_bytes()).hexdigest()))
rows=json.loads((out/'result.json').read_bytes())['stages'] if (out/'result.json').exists() else []
for stage,args in [('build',['cmake','--build',str(build),'--target',target,'g03_paged_arena_risks','--parallel','4']),('common-page20',[str(build/'g03_paged_arena_risks.exe')])]:
 attempt=1+sum(r['stage']==stage for r in rows);log=out/f'{stage}-{attempt}.log';start=time.monotonic()
 with log.open('w') as f:
  p=subprocess.Popen(args,env=env,stdout=f,stderr=subprocess.STDOUT)
  (out/'job.json').write_text(json.dumps(dict(state='RUNNING',pid=p.pid,stage=stage)));print('RUN',stage,p.pid,flush=True);code=p.wait()
 rows.append(dict(stage=stage,command=args,exit_code=code,elapsed_seconds=time.monotonic()-start,log=str(log)))
 (out/'result.json').write_text(json.dumps(dict(scope='MSVC Vulkan native receiver compile/link and corresponding common-page20 only; no local GPU execution',inputs=inputs,stages=rows,cumulative_seconds=sum(r['elapsed_seconds'] for r in rows)),indent=2)+'\n',newline='\n')
 (out/'job.json').write_text(json.dumps(dict(state='TERMINAL',exit_code=code)))
 print(json.dumps(rows[-1]),flush=True)
 if code:print(log.read_text(errors='replace')[-5000:],flush=True);raise SystemExit(code)
