from pathlib import Path
import hashlib,json,shutil,subprocess,zipfile
root=Path.cwd();task=root/'.scratch/inference-gaps/g03';out=root/'evidence/correctness/inference-g03-native-pending-receiver';out.mkdir(exist_ok=True)
shutil.copyfile(task/'paged-receiver-air/raw.zip',out/'air-raw.zip')
with zipfile.ZipFile(out/'air-raw.zip') as z:
 air=json.loads(z.read('result.json'));latest={(r['route'],r['mode'],r['stage']):r for r in air['stages']};assert all(r['exit_code']==0 for r in latest.values())
 mechanical_rename=[]
 for row in air['inputs']:
  data=(root/row['path']).read_bytes()
  if row['path']=='tests/compute_batch/pending_paged_receiver_native_consumer.cc':
   text=data.decode();before=text.replace('std::array<n::CopyBatchInvocation,2> copy_slots;','std::array<n::CopyBatchInvocation,2> updates;').replace('HYLE_ASSIGN_OR_RETURN(copy_slots[i],','HYLE_ASSIGN_OR_RETURN(updates[i],').replace('auto&update=copy_slots[step%2];','auto&update=updates[step%2];').replace('for(auto&update:copy_slots)','for(auto&update:updates)')
   assert text!=before and hashlib.sha256(before.encode()).hexdigest()==row['sha256']
   mechanical_rename.append(dict(path=row['path'],air_sha256=row['sha256'],final_sha256=hashlib.sha256(data).hexdigest(),change='Only four references to the outer original copy-slot array renamed updates to copy_slots; inner update-count unchanged. MSVC C4456 corrected; no executable behavior changed.'))
  else:assert hashlib.sha256(data).hexdigest()==row['sha256'],row['path']
 for name in ['result.json','artifact-receipts.json',*[f'{r}-{m}-instrumentation.json' for r in ['apple','vulkan'] for m in ['asan','ubsan','tsan']],*[f'{r}-{m}-compile-commands.json' for r in ['apple','vulkan'] for m in ['static','shared']]]:(out/('air-'+name)).write_bytes(z.read(name))
 for route,count in [('apple',8),('vulkan',10)]:
  row=latest[route,'source','risks'];log=z.read(Path(row['log']).name).decode();assert log.count('PASS')==count,(route,log)
 for route in ['apple','vulkan']:
  for mode in ['source','static','shared','asan','ubsan','tsan']:
   stage='receiver64' if mode in ['source','static','shared'] else 'g03_receiver64';row=latest[route,mode,stage]
   text=z.read(Path(row['log']).name).decode();assert text.count('native pending receiver PASS:64')==(2 if route=='apple' else 1)
 windows=json.loads((task/'paged-receiver-windows/result.json').read_bytes());last={r['stage']:r for r in windows['stages']};assert all(r['exit_code']==0 for r in last.values())
 for row in windows['inputs']:assert hashlib.sha256((root/row['path']).read_bytes()).hexdigest()==row['sha256'],row['path']
shutil.copyfile(task/'paged-receiver-windows/result.json',out/'windows-result.json')
with zipfile.ZipFile(out/'windows-raw.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in (task/'paged-receiver-windows').iterdir():
  if p.is_file():z.write(p,p.name)
names=subprocess.check_output(['git','diff','--name-only','9b3cd6217'],text=True).splitlines()+['tests/compute_batch/pending_paged_receiver_native_consumer.cc','tests/compute_batch/pending_paged_receiver_native_risks.cc'];names=sorted(set(n for n in names if n.startswith(('src/','include/','tests/'))))
(out/'product-inputs.json').write_text(json.dumps(dict(baseline='9b3cd6217',scope_audit='e76843367 plus recorded retirement counterexamples',inputs=[dict(path=n,sha256=hashlib.sha256((root/n).read_bytes()).hexdigest()) for n in names]),indent=2)+'\n',newline='\n')
failures=dict(air=[r for r in air['stages'] if r['exit_code']],windows=[r for r in windows['stages'] if r['exit_code']],causes=['Real RC03 error: aggregate proxy settles during wait while old OwnedResult/ResultLease still retains payload; fixed original ResultStorage gate on explicit withdrawal','Fixture C++ Result assignment to empty braces was ambiguous; now releases the actual ResultLease','Fixture unknown check incorrectly demanded immediate OOM; original aggregate remains PENDING until actual retirement and then returns first OOM','Real RC02 rejection error: releasing unsubscribed source protocol abandons its Update; fixed moving caller controls back before release','A native-rejection probe was temporarily classified as an accepted late failure during diagnosis; actual result=error/update=empty identified the same rollback defect; original logs retained','MSVC fixture C4456 local shadowing under /WX; four-reference outer-array rename only, cached native build reused'],preserved='All seven original Air failing stages, Windows compile failure and cumulative time retained; earlier G01-G03 failures/unknowns are unchanged')
(out/'retained-failures.json').write_text(json.dumps(failures,indent=2)+'\n',newline='\n')
summary=dict(scope='RC01-RC04 actual native receiver implementation checkpoint; main four owners still AUDITED',passed=['Actual Apple F16/BF16 and Vulkan F16, GQA8/2 D256, two requests and two original alternating copy/receiver slots, 64 steps, cross-page growth and Q1/17 mixed prefill/decode, independent double numeric oracle','Actual source risk Apple8/Vulkan10: fresh512-byte page coverage and hole, source cancellation before/after accepted suffix, abandonment, every cold receiver allocation failure plus binding OOM/retry, insufficient original completion capacity, closed context, Vulkan unknown/actual final wait and real native rejection with original Update restoration','Six host ASan/UBSan/TSan configurations: same public64, current risk8/10 and original ready-controller regression','Four relocated native static/shared SDKs: same public64 and two standalone headers each; consumer compile commands contain only relocated product headers','Windows MSVC native Vulkan receiver compile/link and common20 page tests; no local GPU execution'],cost='Opt-in owner holds original controller, four-allocation original copy source, one original dependent observer and one borrowed original result storage pointer. No new worker/queue/native invocation/result slot/default ready fields. Page validation/admission scans original referenced pages and accepted ranges; native import remains cold. Original metadata upload host waits and native private unknown retained.',seconds=dict(air=air['cumulative_seconds'],windows=windows['cumulative_seconds']),limits=['Native source risk probes use private original boundary instrumentation; four SDK public consumers have no private headers/test hooks','Host sanitizers do not instrument shader/driver; two original exact TSan models preserved, ASan detect_leaks=0','Ready graph route templates share the edited glue header; full actual Graph pending journey remains unverified','No CPU/CUDA receiver, late native backing, independent reduction or full seven-route acceptance signed by this batch','Selector READY only proves edit ownership; broader selected reverse factors are not reported PASS. This is an AUDITED implementation checkpoint, not aggregate CANDIDATE/CLOSED.'],remaining='Actual CPU/CUDA receiver and original Graph integration, late native producer output, seven-route64/two slots/independent reduction and original G01/G02 gates; G04-G10 unchanged')
summary['mechanical_fixture_rename']=mechanical_rename
(out/'validation-result.json').write_text(json.dumps(summary,indent=2)+'\n',newline='\n')
shutil.copyfile(task/'paged-receiver-plan.json',out/'validation-plan.json')
with zipfile.ZipFile(out/'runners.zip','w',zipfile.ZIP_DEFLATED) as z:
 for name in ['run_paged_receiver_air.py','paged_receiver_air.py','paged_receiver_windows.py','pack_paged_receiver_air.py','seal_paged_receiver.py']:z.write(task/name,name)
card=root/'docs/implementation/tasks/compute/inference-g03-pending-page-consumption.md';s=card.read_text(encoding='utf-8')
s+='''
## RC01–RC04 已验证实施检查点（2026-10-14）

两条 original PagedBatchInvocation 的 opt-in receiver 已实现并通过
[native receiver 记录](../../../../evidence/correctness/inference-g03-native-pending-receiver/validation-result.json)。
Apple F16/BF16 与 Vulkan F16 实际两请求/两原 slot/64步、独立 double 数值 oracle、
fresh prefix/dirty copy/跨页和混合 Q1/17；source 风险 Apple8/Vulkan10；六 host
sanitizer 同 journey/风险/原 ready regression；四 relocated static/shared 同 public64
及八 standalone 头；Windows MSVC 定向 native receiver 编译与 common20 均 PASS。
原 Runtime/queue/结果槽保留，最终 OwnedResult 的 completion/wait/result 同源状态。
接纳拒绝归还 Update，旧结果/尚未回接 source 阻止 slot reuse；两真实实现 FAIL 和
fixture诊断失败在原日志/累计中保留。source 更新期只有最终聚合 wait，metadata
prepare 等待/冷 view 分配/native private unknown 不隐去。宿主风险只签宿主；
SDK journey 无私有头，source风险使用既有边界仪器；两原 TSan 模型未扩张。

四 owner 继续 AUDITED；本批不签完整 G03 或所有 selector reverse-factor gate。
下一步接 common CPU/CUDA 与原 Graph，补 late native producer backing 和七路线/
独立 reduction 最终旅程；原 G01/G02 未决门、G04–G10 与所有失败/成本继续保留。
不重复 PF/IP/source/数学和本批已证明门；所有 heavy 工作按实际 terminal 收尾。
''';card.write_text(s,encoding='utf-8',newline='\n')
p=root/'docs/implementation/module-status.json';d=json.loads(p.read_bytes())
for row in d['modules']:
 if row['module'] in ['compute','compute_batch','compute_route_apple','compute_route_vulkan']:
  assert row['state']=='AUDITED' and row['record'].endswith('inference-g03-pending-page-consumption.md')
  row['summary']='G03 native pending receiver implemented verified checkpoint, still AUDITED. Original Apple F16/BF16 and Vulkan F16: two requests/two original slots/64 steps, actual source8/10 risks, six host sanitizer configurations, four relocated SDKs/eight heads and Windows directed compile/common20 PASS. Original result storage/source withdrawal and rejected suffix rollback fixed; failures retained. CPU/CUDA receiver, Graph, late output and full seven-route acceptance remain.'
p.write_bytes((json.dumps(d,ensure_ascii=False,indent=2)+'\n').replace('\n','\r\n').encode('utf-8'))
hp=root/'.scratch/inference-gaps/g01/handoff-current.json';h=json.loads(hp.read_bytes())
h['G03_native_pending_receiver']=dict(state='AUDITED_IMPLEMENTED_VERIFIED_CHECKPOINT',baseline='9b3cd6217',audit='e76843367',evidence=out.relative_to(root).as_posix(),verified=summary['passed'],limits=summary['limits'],remaining=summary['remaining'],live_sessions=[],terminal_sessions=[15784,30422,8880,24385,5503,47871,42359,74004])
h['next_resume']='Main four owners AUDITED. PF and native receiver implemented/sealed; commit and push then continue actual common CPU/CUDA and original Graph receiver/late output/seven routes in existing main card. No repeat native/PF/IP/source/math gates; all10 goal remains active, rough18-20%,0/10 fully complete.'
h['live_jobs']=[];hp.write_text(json.dumps(h,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(summary['seconds']))
