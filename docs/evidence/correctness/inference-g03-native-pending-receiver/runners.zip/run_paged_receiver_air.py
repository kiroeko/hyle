from pathlib import Path
import hashlib,json,subprocess,sys,zipfile
root=Path.cwd();out=root/'.scratch/inference-gaps/g03/paged-receiver-air';out.mkdir(exist_ok=True)
names=subprocess.check_output(['git','diff','--name-only','9b3cd6217'],text=True).splitlines();names+=['tests/compute_batch/pending_paged_receiver_native_consumer.cc','tests/compute_batch/pending_paged_receiver_native_risks.cc'];names=sorted(set(n for n in names if n.startswith(('src/','include/','tests/'))))
attempt=1
while (out/f'input-{attempt}.zip').exists():attempt+=1
archive=out/f'input-{attempt}.zip';inputs=[]
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for name in names:
  data=(root/name).read_bytes();inputs.append(dict(path=name,sha256=hashlib.sha256(data).hexdigest()));z.writestr(name,data)
 z.writestr('input-manifest.json',json.dumps(inputs,indent=2)+'\n')
host='kiro@172.22.10.198';remote='/Users/kiro/hyle-scratch/compute-unified/g03-paged-receiver';options=['-o','BatchMode=yes','-o','ConnectTimeout=12']
subprocess.run(['ssh',*options,host,'mkdir -p '+remote],check=True)
subprocess.run(['scp',*options,str(archive),str(root/'.scratch/inference-gaps/g03/paged_receiver_air.py'),host+':'+remote+'/'],check=True)
mode=' --validation-only' if '--validation-only' in sys.argv else ''
code=subprocess.run(['ssh',*options,host,f'python3 {remote}/paged_receiver_air.py {archive.name}'+mode]).returncode
subprocess.run(['scp',*options,host+':'+remote+'/result.json',str(out)],check=True)
raise SystemExit(code)
