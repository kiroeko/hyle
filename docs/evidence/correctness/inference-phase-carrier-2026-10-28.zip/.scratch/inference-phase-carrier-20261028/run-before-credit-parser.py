"""Five root-controlled functional processes; parse never starts a consumer."""
from pathlib import Path
import importlib.util
import json
import os
import sys

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('phase_carrier_build', W / 'build.py')
b = importlib.util.module_from_spec(spec); spec.loader.exec_module(b)
t, R = b.t, b.R
PLAIN = R / '.scratch/inference-paged-frame-20261026/tiny-recursive-input'
E4 = R / '.scratch/inference-mtp-e4-20261028/fixture'
LOGITS_PARSER = R / '.scratch/inference-mtp-logits-20261028/refinement/run.py'
E4_PARSER = R / '.scratch/inference-mtp-e4-20261028/validation/run.py'
ARMS = {'logits-cpu': ('tiny', 'cpu', PLAIN, '--mtp-logits'),
    'logits-cuda': ('tiny', 'cuda', PLAIN, '--mtp-logits'),
    'e4-cpu': ('tiny', 'cpu', E4, '--mtp-e4'),
    'preflight-cpu': ('tiny', 'cpu', PLAIN, '--logits-preflight'),
    'relay-cuda': ('relay', 'cuda', PLAIN, None)}


def module(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    value = importlib.util.module_from_spec(spec); spec.loader.exec_module(value)
    return value


def prepare():
    b.prepared()
    t.save(W / 'run-plan.json', dict(status='PLANNED_NOT_RUN', parser=t.pin(W / 'run.py'),
        plain_fixture=t.pin(PLAIN / 'weights.tsv'), E4_fixture=t.pin(E4 / 'weights.tsv'),
        logits_parser=t.pin(LOGITS_PARSER), E4_parser=t.pin(E4_PARSER), order=list(ARMS),
        arms={arm:dict(image=image,backend=backend,fixture=str(fixture),flag=flag,
            output=str(W/'runs'/arm)) for arm,(image,backend,fixture,flag) in ARMS.items()},
        planned_processes=5, planned_Model_instances=5,
        relay_scope='Original R2 normal/member-credit/cancel serial-vs-relay six arms; fourteen outputs, C16. No continuous sixteen-arm or repeated zero-Model carrier run.',
        policy='Single-use outputs, first failure stops. Repair a parser offline, never rerun a completed consumer.'))
    print('RUN PLAN ONLY: four Tiny regressions and one actual CUDA R2 relay process')


def relay_report(reports):
    assert len(reports) == 1
    report = reports[0]
    assert (report['status'],report['backend'],report['sampling']) == ('PASS','cuda','greedy')
    assert (report['requests'],report['resident_sessions'],report['active_sequences'],report['in_flight_batches'],
        report['state_slots'],report['serial_and_relay_arms'],report['outputs_per_live_member'],report['final_versions']) == (2,2,2,2,6,6,14,0)
    for flag in ('distinct_prompt_payloads','complete_initialized_state_equal','ledger_and_rng_equal',
        'actual_batch_keys_checked','real_member_credit1_blocks_b','accepted_b_whole_discard',
        'survivor_r1_continues','peer_not_permanently_stopped'):
        assert report[flag] is True, flag
    assert report['model_eos_run'] is False and report['native_fault_injection'] is False and report['performance_claim'] is False
    assert len(report['relay']) == 3
    assert report['relay'][0]['successor_submissions'] > 0 and report['relay'][1]['successor_submissions'] > 0
    assert report['relay'][2]['successor_discards'] > 0 and report['relay'][2]['survivor_r1'] > 0
    return report


def parse(arm):
    image,backend,fixture,flag = ARMS[arm]; out = W / 'runs' / arm
    process = t.read(out / 'process.json'); assert process['exit'] == 0 and not process['timed_out'], process
    reports = [json.loads(line) for line in (out / 'stdout.log').read_text(encoding='utf-8-sig').splitlines() if line.startswith('{')]
    if image == 'relay': report = relay_report(reports)
    elif flag == '--mtp-e4': report = module(E4_PARSER,'phase_E4_parser').e4_report(reports,backend)
    else:
        old = module(LOGITS_PARSER,'phase_logits_parser')
        report = old.modifiers_report(reports,backend) if flag == '--mtp-logits' else old.preflight_report(reports)
    t.save(out / 'report.json', report)
    t.save(out / 'summary.json', dict(status='PASS',arm=arm,process=process,report=t.pin(out/'report.json'),
        source_freeze=t.pin(W/'source-freeze.json'),performance_claim=False))
    print('PASS',arm,'PID',process['pid'])


def run(arm):
    image,backend,fixture,flag = ARMS[arm]
    b.validate(); plan = t.read(W / 'run-plan.json')
    for field in ('parser','plain_fixture','E4_fixture','logits_parser','E4_parser'): t.exact(plan[field])
    ready = t.read(W / f'ready-{image}.json'); t.exact(ready['image']); t.exact(ready['inputs'])
    native = t.read(W / 'runtime-plan.json')['native']; t.exact(native)
    source = Path(native['path']); alias = W / 'bin' / source.name
    if not alias.exists(): os.link(source,alias)
    assert os.path.samefile(source,alias)
    out = W / 'runs' / arm; assert not out.exists(),'Already attempted; parse existing output instead'
    args = [ready['image']['path'],'--'+backend,str(fixture)]
    if flag: args.append(flag)
    process = t.execute(args,out,300)
    t.save(out / 'as-run.json', dict(ready=t.pin(W/f'ready-{image}.json'),image=ready['image'],inputs=ready['inputs'],
        source_freeze=ready['source_freeze'],run_plan=t.pin(W/'run-plan.json'),
        environment=t.pin(W/'environment.json'),runtime_source=native,runtime_alias=str(alias),same_file=True,process=process))
    parse(arm)


if __name__ == '__main__':
    action = sys.argv[1]
    if action == 'prepare': prepare()
    elif action == 'run': run(sys.argv[2])
    elif action == 'parse': parse(sys.argv[2])
    else: raise ValueError(action)
