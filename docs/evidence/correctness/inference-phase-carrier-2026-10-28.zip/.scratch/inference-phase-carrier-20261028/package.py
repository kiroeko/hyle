"""Offline Phase carrier receipts only; no build, inference or deletion."""
from pathlib import Path
import datetime
import hashlib
import json
import zipfile

W = Path(__file__).resolve().parent
R = W.parents[1]
BASE = R / '.scratch/inference-program-carrier-20261028/refinement'
DEST = R / 'docs/evidence/correctness/inference-phase-carrier-2026-10-28'
ARMS = ('logits-cpu','logits-cuda','e4-cpu','preflight-cpu','relay-cuda')

def read(p): return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def encoded(d): return (json.dumps(d,ensure_ascii=False,indent=2)+'\n').encode()
def pin(p):
    p=Path(p).resolve();raw=p.read_bytes()
    return dict(path=p.relative_to(R).as_posix(),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def exact(row):
    now=pin(row['path']);assert(now['bytes'],now['sha256'])==(row['bytes'],row['sha256']),row['path']
def process(p):
    d=read(p);assert d['exit']==0 and not d['timed_out'],d
    return d

def main():
    assert not DEST.with_suffix('.json').exists() and not DEST.with_suffix('.zip').exists()
    frozen=read(W/'source-freeze.json')
    for row in frozen['snapshots']:exact(row['original']);exact(row['snapshot'])
    expected=read(W/'expected-sources.json');product=read(W/'product/source-freeze.json')
    CXX=[dict(unit=n,**process(W/f'logs/{n}/process.json')) for n in ('tiny','relay')]
    links=[dict(image=n,**process(W/f'link/{n}/process.json')) for n in ('tiny','relay')]
    baseline=read(BASE/'ready-tiny.json');old_rows=read(baseline['inputs']['path']);assert len(old_rows)==228
    weights=read(W/'plan.json')['weights_retained']['object'];images={}
    for name in ('tiny','relay'):
        ready=read(W/f'ready-{name}.json');exact(ready['inputs']);rows=read(ready['inputs']['path'])
        assert len(rows)==228 and weights in rows
        assert [x for x in rows if x!=ready['compiled']['object']]==[x for x in old_rows if x!=baseline['compiled']['object']]
        images[name]=dict(image=ready['image'],inputs=ready['inputs'])
    runs=[]
    for arm in ARMS:
        out=W/'runs'/arm;d=read(out/'report.json');p=process(out/'process.json')
        assert read(out/'summary.json')['status']=='PASS' and d['status']=='PASS'
        if arm.startswith('logits'):
            checks=d['state_checks'];assert len(checks)==10
            assert all(x['payloads_byte_equal'] and not x['differences'] and x['boundary_equal'] for x in checks)
            assert d['final_versions']==0
            facts=dict(models=1,initialized_state_byte_equal_checks=10,actual_differences=0,final_versions=0)
        elif arm=='e4-cpu':
            assert(d['complete_byte_equal_checks'],d['exact_cache_backing_bytes'],d['final_versions'])==(11,314119,0)
            assert d['controlled_B2_accepted_prefixes']==[1,2] and d['controlled_B2_RNG_unchanged'] is True
            facts=dict(models=1,initialized_state_byte_equal_checks=11,target='E4M3FN',draft='BF16',cache_backing_bytes=314119,final_versions=0)
        elif arm=='preflight-cpu':
            for key in ('typed_invalid_argument','original_key','complete_state_unchanged','all_ledger_records_unchanged','same_key_peer_continued'):assert d[key] is True
            assert d['preflight_submissions']==0 and d['final_versions']==0
            facts=dict(models=1,typed_original_key_rejection=True,rejected_native_submissions=0,state_and_ledger_unchanged=True,peer_continued=True,final_versions=0)
        else:
            for key in ('complete_initialized_state_equal','ledger_and_rng_equal','actual_batch_keys_checked',
                'real_member_credit1_blocks_b','accepted_b_whole_discard','survivor_r1_continues','peer_not_permanently_stopped'):assert d[key] is True
            assert(d['requests'],d['serial_and_relay_arms'],d['outputs_per_live_member'],d['final_versions'])==(2,6,14,0)
            counters=[{key:x[key] for key in ('waves','actual_batches','published_members','successor_submissions','successor_publications','successor_discards','successor_refusals','survivor_r1')} for x in d['relay']]
            assert [x['successor_submissions'] for x in counters]==[2,0,1]
            assert counters[2]['successor_discards']==1 and counters[2]['survivor_r1']==5
            assert all(x['successor_refusals']==0 for x in counters)
            facts=dict(models=1,requests=2,serial_and_relay_arms=6,outputs_per_live_member=14,
                complete_state_ledger_and_RNG_equal=True,real_credit1_blocks_B=True,
                credit_arm=dict(only_blocks_successor=True,actual_successor_submissions=0),
                Source_expiry_asserted_by_original_native_probe=True,final_versions=0,
                relay_order=['normal','member_credit','cancel'],relay=counters)
        runs.append(dict(arm=arm,pid=p['pid'],exit=p['exit'],seconds=p['seconds'],facts=facts))
    amendment=read(W/'parser-amendment.json');assert amendment['new_native_or_compiler_processes']==0
    assert amendment['native_process']['pid']==57096 and amendment['consumer_reruns']==0
    evidence=dict(status='PASS_BOUNDED_PHASE_PROGRAM_CARRIER',created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),base=product['base'],
        implementation=['Phase uses three stable embedded ProgramCarrier objects in place of separate Invocation, retention and queue fields. Family/PhaseIo/transaction metadata remain model-owned.',
            'The actual exact child is created directly, with original variant and last_row signature checks before fixed-binding publication. Source submission uses the same Graph API through a direct static action.',
            'Original Source/Append/Store recovery precedes reset; unsubmitted B retains its predecessor gate. Nonblocking retirement remains collection plus original Step recovery, and successful finish keeps the existing run/readback return boundary.',
            'Original native retirement and permanent teardown handoff govern eviction and scope root release; no new Queue, Completion, payload owner, permission table or executor.'],
        counts=dict(actual_CXX=2,successful_CXX=2,actual_links=2,successful_links=2,actual_model_processes=5,successful_native_processes=5,
            failed_native_processes=0,post_success_parser_failures=1,offline_parser_corrections=1,consumer_reruns=0,SDK_CXX=0,NVCC=0,downloads=0),
        builds=dict(CXX=CXX,links=links,images=images,link_inputs_per_image=228,replaced_objects_per_link=1,retained_weights_object=weights),
        runs=runs,source_pins=expected,
        test_adaptations=['Source access and Invocation identity checks use the original carrier borrow/queues interface.',
            'Four unexecuted engine probes also replace the obsolete physical array-size()==1 assertion with logical slot_count==1. The physical array has three entries; this corrects the stale capacity assertion and is not described as zero assertion changes.',
            'The original R2 state/ledger/RNG, cancellation, credit and Source-expiry checks are retained; no consumer oracle was changed to repair the Python parse failure.'],
        parser_correction=dict(receipt=pin(W/'parser-amendment.json'),native_process_pid=57096,native_exit=0,
            cause='The initial Python parser additionally demanded successor_submissions>0 in the member-credit arm; the original compiled consumer never required that.',
            original_contract='At the warmed real [credit1,credit2] boundary no new B may be accepted, and exactly one blocking check must occur. Normal and cancellation arms must still exercise real successors; complete state/ledger/RNG and Source retirement remain checked.',
            correction='Only the Python parser was corrected; original parser/run-plan, assertion reproduction and raw native stdout are preserved. Existing PID 57096 stdout was parsed offline, without rebuilding or rerunning.',
            credit_zero_B='Actual ACK pause/requeue changes the ordered cohort from [A,B] to [B,A]. The existing continuation selection resets warm hints, and fewer than six warm steps remain. Credit-arm zero B is compatible with the original policy, not a Source capability refusal.',
            source_anchors=['qwen_generation_batch_relay_probe.cc:164-168','qwen_generation_batch_relay_probe.cc:231-233','qwen_generation_batch_relay_probe.cc:308','qwen_generation_batch_relay_probe.cc:329-331']),
        dependency_boundary='Both current include-Model consumers use the current Tiny CPU/CUDA compiler flags and 228-input product closure. Only their private OBJ changes; the current independent target/draft weights ABI and all public SDK layouts remain unchanged. Old R2 recipe/dependencies are provenance only; old 223 product objects and copied header overlays are not linked.',
        actual_dependencies={name:pin(W/f'compile/{name}/dependencies.json') for name in ('tiny','relay')},
        source_freeze=pin(W/'source-freeze.json'),
        limits=['Finite CPU/CUDA functional consumers, not a throughput, quality, native-fault, true model EOS or other-platform proof.',
            'Ten MTP logits initialized-state comparisons per backend and eleven E4 CPU comparisons were actually byte-exact. The inherited GDN numerical allowance was retained; this does not establish all shapes/dtypes or cross-backend identity.',
            'The R2 test runs normal, member-credit and cancellation serial/control pairs only; the sixteen-arm continuous suite and generic zero-Model carrier case were not repeated.',
            'retirement_probe.cc, retained_budget_probe.cc, batch_probe.cc, mtp_session_probe.cc and qwen_submission_source_probe.cc received frozen source-only adaptations, including the logical slot-count assertion correction, but were not compiled or run here.',
            'Native fault/unknown retirement and partial failed exact-family eviction were reviewed statically, not fault-injected. A closed partially evicted carrier keeps refusing admission; no new recovery policy is claimed.',
            'Recorded process durations are provenance. No new performance comparison or all-retained-header ABI audit is claimed.'],
        reference=pin(R/'docs/evidence/correctness/inference-program-carrier-2026-10-28.json'),
        reproduction=dict(build=(W/'build.py').relative_to(R).as_posix(),run=(W/'run.py').relative_to(R).as_posix(),
            actions=['build.py prepare','build.py freeze','build.py compile tiny|relay','build.py link tiny|relay',
                'run.py run logits-cpu|logits-cuda|e4-cpu|preflight-cpu|relay-cuda','run.py parse relay-cuda'],
            note='Actual run-plan retains the original as-run parser pin; parser-amendment.json records the offline correction. No further native run is scheduled.'),raw_manifest='manifest.json')
    members={};allowed={'.py','.json','.cc','.h','.diff','.log','.xml'}
    def add(p):
        p=Path(p);assert p.is_file() and p.suffix.lower() in allowed
        name=p.relative_to(R).as_posix();assert name not in members,name
        members[name]=p.read_bytes()
    for root in (W,W/'product'):
        for p in sorted(root.iterdir()):
            if p.is_file() and p.suffix.lower() in allowed:add(p)
    for root in (W/'product/source',W/'source/tests',W/'source/engine/models/qwen35',W/'logs',W/'compile',W/'link',W/'runs'):
        for p in sorted(root.rglob('*')):
            if p.is_file() and p.suffix.lower() in allowed:
                # The authoritative main/header snapshot already lives under product/source.
                if p==W/'source/engine/models/qwen35/main.cc':continue
                add(p)
    for p in (R/evidence['reference']['path'],BASE/'ready-tiny.json',BASE/'inputs-tiny.json',BASE/'plan.json',
        R/'.scratch/inference-indexed-store-20261028/build.py',R/'.scratch/inference-mtp-logits-20261028/refinement/run.py',
        R/'.scratch/inference-mtp-e4-20261028/validation/run.py'):add(p)
    members['evidence-core.json']=encoded(evidence)
    members['manifest.json']=encoded(dict(files=[dict(path=name,bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest()) for name,raw in sorted(members.items())],
        excluded=['EXE/OBJ/EXP/LIB/PDB/DLL','SDK/model payload','whole SDK/header copies','unrelated docs/license']))
    DEST.parent.mkdir(parents=True,exist_ok=True)
    with zipfile.ZipFile(DEST.with_suffix('.zip'),'x',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for name,raw in sorted(members.items()):z.writestr(name,raw)
    with zipfile.ZipFile(DEST.with_suffix('.zip')) as z:
        assert z.testzip() is None
        for row in json.loads(z.read('manifest.json'))['files']:
            raw=z.read(row['path']);assert len(raw)==row['bytes'] and hashlib.sha256(raw).hexdigest()==row['sha256']
    evidence['archive']=dict(**pin(DEST.with_suffix('.zip')),files=len(members),CRC_and_member_SHA256_verified=True)
    DEST.with_suffix('.json').write_bytes(encoded(evidence))
    print(json.dumps(dict(json=pin(DEST.with_suffix('.json')),archive=evidence['archive'],counts=evidence['counts']),indent=2))

if __name__=='__main__':main()
