"""Two canonical include-Model TUs and two explicit current-228 links."""
from pathlib import Path
import importlib.util
import re
import sys

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = W.parents[1]
BASE = R / '.scratch/inference-program-carrier-20261028/refinement'
OLD_RELAY = R / '.scratch/inference-wave-recovery-final-20261027/ready-probe.json'
SOURCES = {'tiny': 'tests/tools/qwen_host_image_test.cc',
           'relay': 'tests/tools/qwen_generation_batch_relay_probe.cc'}
spec = importlib.util.spec_from_file_location('phase_carrier_tools', R / '.scratch/inference-indexed-store-20261028/build.py')
t = importlib.util.module_from_spec(spec); spec.loader.exec_module(t); t.W = W


def prepare():
    ready = t.read(BASE / 'ready-tiny.json'); t.exact(ready['inputs'])
    rows = t.read(ready['inputs']['path']); assert len(rows) == 228
    actual = t.read(ready['compiled']['dependencies']['path'])['Data']
    assert t.key(actual['Source']) == t.key(R / SOURCES['tiny'])
    original = ready['compiled']['object']
    assert sum(t.key(row['path']) == t.key(original['path']) for row in rows) == 1
    weights = t.read(BASE / 'plan.json')['weights_retained']
    assert weights['object'] in rows
    assert t.key(t.read(weights['dependencies']['path'])['Data']['Source']) == t.key(R / 'engine/models/qwen35/weights.cc')
    t.exact(weights['source'])
    old_relay = t.read(OLD_RELAY); relay_deps = old_relay['compiled']['compiler_dependencies']
    assert t.key(t.canonical(t.read(relay_deps['path'])['Data']['Source'])) == t.key(R / SOURCES['relay'])
    units = {}
    for name, source in SOURCES.items():
        args = []; before = t.command(ready['compiled']['command']['path'])
        for at, arg in enumerate(before):
            if t.key(arg) == t.key(actual['Source']): arg = str(R / source)
            elif at and before[at - 1].lower() == '/sourcedependencies': arg = str(W / f'compile/{name}/dependencies.json')
            elif arg.lower().startswith('/fo'): arg = '/Fo' + str(W / f'compile/{name}/unit.obj')
            elif arg.lower().startswith('/fd'): arg = '/Fd' + str(W / f'compile/{name}/unit.pdb')
            args.append(arg)
        assert '/MD' in args and '/O2' in args and sum(t.key(arg) == t.key(R / source) for arg in args) == 1
        t.save(W / f'recipe-{name}.json', dict(command=args, timeout_seconds=300))
        link = []
        for arg in t.command(ready['recipe']['path']):
            if t.key(arg) == t.key(original['path']): arg = str(W / f'compile/{name}/unit.obj')
            for prefix, suffix in (('/OUT:', '.exe'), ('/PDB:', '.pdb'), ('/MAP:', '.map'), ('/IMPLIB:', '.lib')):
                if arg.upper().startswith(prefix): arg = prefix + str((W / 'bin' / name).with_suffix(suffix)); break
            link.append(arg)
        assert sum(t.key(arg) == t.key(W / f'compile/{name}/unit.obj') for arg in link) == 1
        t.save(W / f'link-{name}.json', dict(command=link, timeout_seconds=240))
        units[name] = dict(source=str(R / source), recipe=t.pin(W / f'recipe-{name}.json'),
            link=t.pin(W / f'link-{name}.json'), old_dependencies=ready['compiled']['dependencies'])
    stats = []
    for row in rows:
        path = Path(row['path']); st = path.stat(); assert st.st_size == row['bytes'], path
        stats.append(dict(path=str(path), bytes=st.st_size, mtime_ns=st.st_mtime_ns))
    t.save(W / 'retained-input-stats.json', stats)
    env = t.read(BASE / 'environment.json'); assert set(env) <= {'PATH', 'INCLUDE', 'LIB', 'LIBPATH'}
    env['PATH'] = str(W / 'bin') + ';' + env['PATH']; t.save(W / 'environment.json', env)
    t.save(W / 'runtime-plan.json', dict(native=t.read(BASE / 'runtime-plan.json')['native'],
        method='Original CPU DLL same-file hardlink beside both consumers; no SDK/payload copy',
        planned_processes=5, CPU_processes=3, CUDA_processes=2))
    t.save(W / 'plan.json', dict(status='PREPARED_NOT_SOURCE_FROZEN', baseline=t.pin(BASE / 'ready-tiny.json'),
        inputs=ready['inputs'], original_object=original, units=units, weights_retained=weights,
        actual_R2_recipe_provenance=dict(ready=t.pin(OLD_RELAY), command=old_relay['compiled']['command'], dependencies=relay_deps,
            note='Only the actual R2 source/dependencies are consulted. Use current Tiny compiler flags/includes and current 228 product closure, not old copied overlays or old 223 SDK/weights objects.'),
        retained_stats=t.pin(W / 'retained-input-stats.json'), environment=t.pin(W / 'environment.json'), runtime=t.pin(W / 'runtime-plan.json'),
        counts=dict(CXX=2,links=2,SDK_CXX=0,NVCC=0,downloads=0),
        compatibility='Both TUs include current Model; Phase/ProgramCarrier are engine-private. PreparedWeightSource and public SDK layouts are unchanged. Each 228-input link replaces exactly one Tiny OBJ and retains the current weights plus other 226 input identities.'))
    print('PREPARED ONLY: Tiny+actual R2 relay, 2 CXX / 2 links; no source freeze')


def prepared():
    plan = t.read(W / 'plan.json')
    for field in ('baseline', 'inputs', 'retained_stats', 'environment', 'runtime'): t.exact(plan[field])
    for unit in plan['units'].values():
        for field in ('recipe', 'link', 'old_dependencies'): t.exact(unit[field])
    return plan


def freeze():
    plan = prepared(); expected = t.read(W / 'expected-sources.json')
    assert {'engine/models/qwen35/main.cc', 'engine/inference/program_carrier.h', *SOURCES.values()} <= set(expected)
    for relative, sha in expected.items(): assert t.pin(R / relative)['sha256'] == sha, relative
    paths = {t.key(t.canonical(p)): t.canonical(p) for unit in plan['units'].values()
        for p in t.dep_paths(unit['old_dependencies']['path']) if t.project(t.canonical(p))}
    extra = plan['actual_R2_recipe_provenance']['dependencies']
    paths.update({t.key(t.canonical(p)): t.canonical(p) for p in t.dep_paths(extra['path']) if t.project(t.canonical(p))})
    pending = [R / relative for relative in expected]; seen = set(); roots = [R / 'include', R]
    for unit in plan['units'].values():
        roots += [Path(arg[2:]) for arg in t.command(unit['recipe']['path']) if arg.lower().startswith('/i')]
    while pending:
        path = pending.pop().resolve()
        if t.key(path) in seen: continue
        seen.add(t.key(path)); paths[t.key(path)] = path
        for include in re.findall(r'^\s*#\s*include\s*"([^"\r\n]+)"', path.read_text(encoding='utf-8-sig'), re.M):
            found = next((q.resolve() for root in [path.parent, *roots] if (q := root / include).is_file()), None)
            if found and t.project(found): pending.append(found)
    t.save(W / 'project-dependencies.json', [t.pin(path) for path in paths.values()])
    snapshots = []
    for relative in expected:
        source, target = R / relative, W / 'source' / relative; target.parent.mkdir(parents=True, exist_ok=True)
        with target.open('xb') as stream: stream.write(source.read_bytes())
        snapshots.append(dict(original=t.pin(source), snapshot=t.pin(target)))
    t.save(W / 'source-freeze.json', dict(expected=t.pin(W / 'expected-sources.json'), helper=t.pin(W / 'build.py'),
        snapshots=snapshots, project_dependencies=t.pin(W / 'project-dependencies.json')))
    print('SOURCE FROZEN ONLY')


def validate():
    plan = prepared(); frozen = t.read(W / 'source-freeze.json')
    for field in ('expected', 'helper', 'project_dependencies'): t.exact(frozen[field])
    for row in frozen['snapshots']: t.exact(row['original']); t.exact(row['snapshot'])
    return plan, frozen


def compile_one(name):
    plan, frozen = validate(); assert name in SOURCES
    allowed = {t.key(row['path']): row for row in t.read(frozen['project_dependencies']['path'])}
    for row in allowed.values(): t.exact(row)
    out = W / 'compile' / name; out.mkdir(parents=True, exist_ok=False)
    proc = t.execute(t.command(plan['units'][name]['recipe']['path']), W / 'logs' / name, 300)
    validate(); actual = []
    for path in dict.fromkeys(t.dep_paths(out / 'dependencies.json')):
        if t.project(path):
            assert t.key(path) in allowed, ('unfrozen include',str(path))
            t.exact(allowed[t.key(path)]); actual.append(t.pin(path))
    t.save(out / 'actual-project-dependencies.json', actual)
    t.save(out / 'compiled.json', dict(source=t.pin(R / SOURCES[name]), object=t.pin(out / 'unit.obj'),
        command=t.pin(W / 'logs' / name / 'command.json'), dependencies=t.pin(out / 'dependencies.json'), process=proc))
    print('CXX PASS', name)


def link(name):
    plan, _ = validate(); assert name in SOURCES
    compiled = t.read(W / f'compile/{name}/compiled.json'); t.exact(compiled['object'])
    for row in t.read(plan['retained_stats']['path']):
        st = Path(row['path']).stat(); assert (st.st_size, st.st_mtime_ns) == (row['bytes'], row['mtime_ns']), row['path']
    rows = [compiled['object'] if t.key(row['path']) == t.key(plan['original_object']['path']) else row for row in t.read(plan['inputs']['path'])]
    assert len(rows) == 228 and plan['weights_retained']['object'] in rows
    (W / 'bin').mkdir(exist_ok=True); assert not (W / f'bin/{name}.exe').exists()
    t.save(W / f'inputs-{name}.json', rows)
    proc = t.execute(t.command(plan['units'][name]['link']['path']), W / 'link' / name, 240)
    t.save(W / f'ready-{name}.json', dict(image=t.pin(W / f'bin/{name}.exe'), inputs=t.pin(W / f'inputs-{name}.json'),
        compiled=compiled, recipe=t.pin(W / 'link' / name / 'command.json'), process=proc,
        plan=t.pin(W / 'plan.json'), source_freeze=t.pin(W / 'source-freeze.json')))
    print('LINK PASS', name)


if __name__ == '__main__':
    action = sys.argv[1]
    if action == 'prepare': prepare()
    elif action == 'freeze': freeze()
    elif action == 'compile': compile_one(sys.argv[2])
    elif action == 'link': link(sys.argv[2])
    else: raise ValueError(action)
