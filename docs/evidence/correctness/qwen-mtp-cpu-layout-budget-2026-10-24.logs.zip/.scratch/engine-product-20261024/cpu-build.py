"""Reuse current CPU/native objects; compile only the three new engine TUs.

No dependency build, model download, arithmetic change or performance claim.
"""
from pathlib import Path
import argparse
import hashlib
import json
import os
import subprocess
import sys
import time

sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
R = S.parents[1]
sys.path.insert(0, str(R / "scripts"))
from hyle_environment import discover_environment

BASE = R / ".scratch/qwen-mtp-quality-20261022/current-refresh-20261024/hyle-link2"
RECIPE = R / ".scratch/qwen-mtp-quality-20261022/current-refresh-20261024/compile2/qwen/identity.json"
CURRENT_CPU = R / ".scratch/qwen-gguf-selected-20261023/B07/native-current/tests-link2/link-plan.json"


def read(path):
    return json.loads(Path(path).read_text(encoding="utf-8-sig"))


def save(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


def identity(path):
    path = Path(path).resolve()
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return {"path": str(path), "bytes": path.stat().st_size, "sha256": digest.hexdigest()}


def require(item):
    actual = identity(item["path"])
    if any(actual[key] != item[key] for key in ("bytes", "sha256")):
        raise ValueError("Retained identity differs: " + item["path"])
    return actual


def execute(command, env, folder, timeout=600):
    folder.mkdir(parents=True, exist_ok=False)
    (folder / "tmp").mkdir()
    env = dict(env, TEMP=str(folder / "tmp"), TMP=str(folder / "tmp"))
    record = dict(command=command, cwd=str(R), started=time.time(), timeout_seconds=timeout,
                  throughput_evidence=False, memory_evidence=False)
    save(folder / "command.json", record)
    print("START", folder.name, flush=True)
    start = time.perf_counter()
    with (folder / "stdout.log").open("wb") as out, (folder / "stderr.log").open("wb") as err:
        process = subprocess.Popen(command, cwd=R, env=env, stdout=out, stderr=err,
                                   creationflags=subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0)
        record["pid"] = process.pid
        save(folder / "live.json", record)
        try:
            record["exit"] = process.wait(timeout=timeout)
            record["timed_out"] = False
        except subprocess.TimeoutExpired:
            process.kill()
            record["exit"] = process.wait()
            record["timed_out"] = True
    record.update(finished=time.time(), process_wall_seconds=time.perf_counter() - start)
    save(folder / "process.json", record)
    print("END", folder.name, "exit", record["exit"], "seconds", round(record["process_wall_seconds"], 3), flush=True)
    if record["exit"] or record["timed_out"]:
        raise RuntimeError("Failed native command; inspect " + str(folder))
    return record


def build(attempt, reuse_from=None):
    out = S / f"cpu-build{attempt}"
    out.mkdir(exist_ok=False)
    recipe = read(RECIPE)
    compiler = recipe["command"][0]
    native = discover_environment(compiler="msvc", cache={"CMAKE_C_COMPILER": compiler,
        "CMAKE_CXX_COMPILER": compiler, "CMAKE_GENERATOR": "Ninja"}, backends=())
    if Path(native.cxx).resolve() != Path(compiler).resolve():
        raise ValueError("Must reuse the same recorded MSVC toolset")
    flags = []
    skip = False
    for flag in recipe["command"][1:]:
        if skip:
            skip = False
            continue
        if flag == "/sourceDependencies":
            skip = True
            continue
        if flag.lower().startswith(("/fo", "/fd", "/i", "/external:i")) or flag.lower().endswith(".cc"):
            continue
        if any(name in flag for name in ("GGML_USE_CUDA", "HYLE_COMPUTE_CUDA", "HYLE_COMPUTE_GGML_CUDA")):
            continue
        flags.append(flag)
    flags += ["/DHYLE_COMPUTE_CPU=1", "/I" + str(R / "include"), "/I" + str(R), "/I" + str(R / "engine")]
    objects = []
    records = []
    fresh_engine = 0
    fresh_product = 0
    for name, source in (("entry", R / "engine/main.cc"),
                         ("qwen", R / "engine/models/qwen35/main.cc"),
                         ("cpu-file-stream", R / "src/compute_stream_cpu/file_stream.cc")):
        if reuse_from and name != "qwen":
            old = S / f"cpu-build{reuse_from}" / name / "identity.json"
            record = read(old)
            for item in (record["source"], record["object"], *record["dependencies"]):
                require(item)
            records.append(identity(old))
            objects.append(record["object"]["path"])
            continue
        target = out / name
        obj = target / (name + ".obj")
        frozen = identity(source)
        command = [compiler, *flags, "/sourceDependencies", str(target / "dependencies.json"),
                   str(source), "/Fo" + str(obj), "/Fd" + str(target / (name + ".pdb"))]
        execute(command, native.env, target)
        if identity(source) != frozen:
            raise ValueError("Source changed during compilation")
        deps = read(target / "dependencies.json")["Data"]
        record = dict(source=frozen, object=identity(obj), command=command,
                      dependencies=[identity(p) for p in dict.fromkeys([deps["Source"], *deps["Includes"]])])
        save(target / "identity.json", record)
        records.append(identity(target / "identity.json"))
        objects.append(str(obj))
        if name == "cpu-file-stream":
            fresh_product += 1
        else:
            fresh_engine += 1
    base = read(BASE / "link-plan.json")
    old_main = read(base["compiled_record"]["path"])["object"]["path"]
    cpu_plan = read(CURRENT_CPU)
    old_cpu = cpu_plan["retired_product_records"][0]["object"]["path"]
    cpu_record = read(cpu_plan["fresh_product_records"][0]["path"])
    for item in (cpu_record["source"], cpu_record["object"], *cpu_record["dependencies"]):
        require(item)
    pinned = {str(Path(item["path"]).resolve()).lower(): item for item in base["inputs"]}
    command = [base["command"][0], *objects]
    inputs = [identity(obj) for obj in objects]
    counts = {"main_removed": 0, "cpu_replaced": 0}
    for argument in base["command"][1:]:
        if argument.upper().startswith(("/OUT:", "/MAP:", "/IMPLIB:", "/PDB:")):
            continue
        if argument == old_main:
            counts["main_removed"] += 1
            continue
        if argument == old_cpu:
            argument = cpu_record["object"]["path"]
            counts["cpu_replaced"] += 1
        if Path(argument).is_absolute() and argument.lower().endswith((".obj", ".lib")):
            item = cpu_record["object"] if argument == cpu_record["object"]["path"] else pinned[str(Path(argument).resolve()).lower()]
            inputs.append(require(item))
        command.append(argument)
    if counts != {"main_removed": 1, "cpu_replaced": 1}:
        raise ValueError("Expected exactly the former consumer and former CPU provider")
    link_dir = out / "link"
    image = link_dir / "hyle-cpu.exe"
    command += ["/OUT:" + str(image), "/MAP:" + str(image.with_suffix(".map")), "/IMPLIB:" + str(image.with_suffix(".lib"))]
    save(out / "link-plan.json", dict(command=command, inputs=inputs, base=identity(BASE / "link-plan.json"),
        compiler_recipe=identity(RECIPE), consumer_records=records, current_cpu_record=identity(cpu_plan["fresh_product_records"][0]["path"]),
        source_CPU_provider=cpu_record["source"], fresh_engine_TUs=fresh_engine, fresh_product_TUs=fresh_product,
        reuse_from_attempt=reuse_from,
        SDK_builds=0, NVCC_builds=0, downloads=0, replacements=counts,
        scope="Native entry/model source with CPU macro; retained mixed object closure, selected CPU execution only."))
    execute(command, native.env, link_dir)
    runtime = read(BASE / "runtime-environment.json")
    staged_dlls = []
    for item in runtime["staged_dlls"]:
        require(item)
        source = Path(item["path"])
        sibling = link_dir / source.name
        os.link(source, sibling)
        observed = identity(sibling)
        if any(observed[key] != item[key] for key in ("bytes", "sha256")):
            raise ValueError("Staged native CPU module differs")
        staged_dlls.append(observed)
    runtime.update(PATH=str(link_dir) + os.pathsep + runtime["PATH"],
                   reused_runtime=identity(BASE / "runtime-environment.json"),
                   reused_module_sources=runtime["staged_dlls"], staged_dlls=staged_dlls,
                   staging_method="hardlink_sibling_for_Windows_default_DLL_search",
                   copied_runtime_files=0, selected_engine_backend="cpu")
    save(out / "runtime-environment.json", runtime)
    save(out / "ready.json", dict(image=identity(image), link_plan=identity(out / "link-plan.json"),
        runtime_environment=identity(out / "runtime-environment.json"), source_records=records,
        actual_native_runs=0, performance_claim=False))
    print("CPU_READY", image, flush=True)


def run(attempt, steps):
    out = S / f"cpu-build{attempt}"
    ready = read(out / "ready.json")
    require(ready["image"])
    runtime = read(out / "runtime-environment.json")
    env = dict(os.environ, PATH=runtime["PATH"])
    image = ready["image"]["path"]
    runs = []
    process = execute([image, "--help"], env, S / f"cpu-help{attempt}", timeout=30)
    runs.append(dict(mode="help", process=process, weights_loaded=False))
    save(out / "run-summary.json", dict(image=ready["image"], runs=runs))
    for mode in ("text", "mtp"):
        command = [image, "--inputs", str(R / ".scratch/qwen-mtp-window-20261022/inputs" / mode),
            "--steps", str(steps), "--capacity", "256", "--max-sessions", "1", "--active-sequences", "1",
            "--prefix-cache", "off", "--progress", "direct", "--replay", "commands", "--mtp", "on" if mode == "mtp" else "off"]
        folder = S / f"cpu-{mode}{attempt}"
        try:
            process = execute(command, env, folder, timeout=600)
            raw = json.loads((folder / "stdout.log").read_text(encoding="utf-8").strip().splitlines()[-1])
            save(folder / "parsed.json", raw)
            runs.append(dict(mode=mode, process=process, generated_ids=raw["generated_ids"],
                             source_id=raw["source_id"], quality_claim=False, throughput_claim=False))
        except Exception as error:
            runs.append(dict(mode=mode, process=read(folder / "process.json") if (folder / "process.json").exists() else None,
                             status="FAILED", error=str(error)))
            save(out / "run-summary.json", dict(image=ready["image"], runs=runs))
            continue
        save(out / "run-summary.json", dict(image=ready["image"], runs=runs))
    if any(row.get("status") == "FAILED" for row in runs):
        raise RuntimeError("One or more real CPU mode checks failed; retained all results")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("action", choices=("build", "run"))
    parser.add_argument("--attempt", type=int, default=1)
    parser.add_argument("--steps", type=int, default=2)
    parser.add_argument("--reuse-from", type=int)
    args = parser.parse_args()
    if args.attempt < 1 or args.steps not in (2, 4):
        parser.error("positive attempt and 2 or 4 output tokens required")
    if args.action == "build":
        build(args.attempt, args.reuse_from)
    else:
        run(args.attempt, args.steps)
