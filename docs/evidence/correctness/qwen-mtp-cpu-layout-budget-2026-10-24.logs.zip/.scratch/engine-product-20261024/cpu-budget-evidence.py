"""Archive only source, commands, finite test/native logs and parsed results."""
from pathlib import Path
import hashlib
import json
import re
import zipfile

S=Path(__file__).resolve().parent
R=S.parents[1]
OUT=S/"cpu-budget-fix1"
def identity(path):
    path=Path(path);raw=path.read_bytes()
    return dict(path=path.relative_to(R).as_posix(),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def read(path):return json.loads(path.read_text(encoding="utf-8"))
changed=[R/p for p in ["include/hyle/compute/detail/lease_access.h","src/compute/resource_leases.cc",
    "src/compute/resource_budget.cc","src/compute_batch/batch_layout.cc","tests/compute_batch/batch_layout_test.cc"]]
for name in ["budget","leases","layout","test","qwen"]:
    record=read(OUT/name/"identity.json")
    actual=identity(Path(record["source"]["path"]))
    assert all(actual[k]==record["source"][k] for k in ["bytes","sha256"])
rows=[]
for name in ["ordinary-text","ordinary-mtp-manifest","mtp"]:
    raw=read(OUT/name/"parsed.json")
    stderr=(OUT/name/"stderr.log").read_text(encoding="utf-8")
    count,loaded=map(int,re.search(r"resident text weights: (\d+) tensors, (\d+) bytes",stderr).groups())
    payload=raw["cache_live_requested_bytes"]-raw["cache_metadata_requested_bytes"]
    assert payload==raw["cache_shared_backing_bytes"] and raw["cache_retained_output_backing_bytes"]==0
    assert raw["generated_ids"]==[71093,12305,198,464]
    rows.append(dict(mode=name,process=read(OUT/name/"process.json"),loaded_tensors=count,loaded_bytes=loaded,
        payload_bytes=payload,known_pool_bytes=raw["cache_shared_backing_bytes"],
        metadata_bytes=raw["cache_metadata_requested_bytes"],actual_total_requested_bytes=raw["cache_live_requested_bytes"],
        reported_limit=raw["cache_requested_byte_limit"],generated_ids=raw["generated_ids"],
        draft_rounds=raw["draft_rounds"],accepted_drafts=raw["accepted_drafts"],
        parsed=identity(OUT/name/"parsed.json")))
summary=read(OUT/"summary.json");assert all(row["passed"] for row in summary["runs"])
proof=dict(status="PASS_FINITE_CPU_ENGINE_AND_METADATA_ACCOUNTING",date="2026-10-24",
    problem="CPU payload and host layout snapshots share system_resource. Layout ReadLease bytes were classified as External and made correct cache inventory assertions fail by276/460 bytes.",
    fix="The two BatchLayout readonly backing imports are typed Metadata in the original budget. Shared backing promotion retains that category and the same lifetime/finite limit. Ordinary imports remain External; no public options/layout/old signature changes.",
    previous=dict(ordinary_payload=42418500,ordinary_known=42418224,ordinary_metadata=232696,
        mtp_payload=62530047,mtp_known=62529587,mtp_metadata=267084),
    current=rows,changed_sources=[identity(p) for p in changed],
    model_source=read(OUT/"qwen/identity.json")["source"],
    unit_tests=dict(suite="BatchLayout",tests=30,passed=30,
        added="MetadataBackingKeepsItsCategoryQuotaAndActualReaderLifetime",
        finite_budget_bytes=1048576,process=read(OUT/"tests-run/process.json")),
    negative_tests=[row for row in summary["runs"] if row["name"] in ["quota-one","mtp-without-weights"]],
    visibility_check="python -X utf8 scripts/generate-visibility.py --check:57 API macros checked",
    native_closure=dict(base_link=identity(S/"cpu-build5/link-plan.json"),fresh_TUs=5,
        fresh_product_TUs=3,fresh_test_TUs=1,fresh_model_TUs=1,SDK_builds=0,NVCC_builds=0,downloads=0,
        reused_assembly="Existing mixed native object closure; actual engine selected CPU only. Not a full CMake build or independent no-CUDA deployment."),
    limits=["P154/4 finite original BF16 check; not task quality, other models/backends or throughput evidence.",
        "Host auto limit is reported null; finite quota/escaped-reader/promotion behavior is separately tested, and CLI1 byte rejects before weight loading.",
        "No arithmetic/precision changes; the common source_id literal is historical, actual compiled source and dependency hashes identify this check."])
(OUT/"proof.json").write_text(json.dumps(proof,indent=2,ensure_ascii=False)+"\n",encoding="utf-8")
files=[*changed,R/"engine/models/qwen35/main.cc",R/"engine/models/qwen35/backend.h",
    S/"cpu-build.py",S/"cpu-budget-fix.py",Path(__file__),OUT/"proof.json",OUT/"summary.json",
    OUT/"engine-link-plan.json",OUT/"tests-link-plan.json",OUT/"engine-ready.json",OUT/"tests-ready.json"]
for name in ["budget","leases","layout","test","qwen"]:
    files += [OUT/name/p for p in ["identity.json","command.json","process.json","stdout.log","stderr.log"]]
for name in ["tests-run","ordinary-text","ordinary-mtp-manifest","mtp","quota-one","mtp-without-weights","engine-link","tests-link"]:
    files += [OUT/name/p for p in ["command.json","process.json","stdout.log","stderr.log"]]
    if (OUT/name/"parsed.json").exists():files.append(OUT/name/"parsed.json")
archive=OUT/"evidence.zip"
with zipfile.ZipFile(archive,"x",compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for path in dict.fromkeys(files):z.write(path,path.relative_to(R).as_posix())
with zipfile.ZipFile(archive) as z:assert z.testzip() is None
proof["archive"]=identity(archive)
(OUT/"proof.json").write_text(json.dumps(proof,indent=2,ensure_ascii=False)+"\n",encoding="utf-8")
print(json.dumps(dict(proof=identity(OUT/"proof.json"),archive=identity(archive)),indent=2))
