"""Three accounting owners, one focused test TU and current model TU only."""
from pathlib import Path
import importlib.util
import json
import os
import sys

sys.dont_write_bytecode = True
S=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location("cpu_budget_helpers",S/"cpu-build.py")
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
R=b.R
OUT=S/"cpu-budget-fix1"
BASE=S/"cpu-build5"

def compile_all():
    OUT.mkdir(exist_ok=False)
    old=b.read(BASE/"qwen/identity.json")
    command=old["command"]
    native=b.discover_environment(compiler="msvc",cache={"CMAKE_C_COMPILER":command[0],
        "CMAKE_CXX_COMPILER":command[0],"CMAKE_GENERATOR":"Ninja"},backends=())
    flags=[];skip=False
    for arg in command[1:]:
        if skip:skip=False;continue
        if arg=="/sourceDependencies":skip=True;continue
        if arg.startswith(("/Fo","/Fd")) or arg.lower().endswith(".cc"):continue
        flags.append(arg)
    gtest=b.read(R/".scratch/qwen-gguf-selected-20261023/B07/native-current/compile1/qwen-state/identity.json")
    flags.extend(x for x in gtest["command"] if x.lower().startswith("/external:i") and "googletest" in x.lower())
    units={"budget":R/"src/compute/resource_budget.cc","leases":R/"src/compute/resource_leases.cc",
        "layout":R/"src/compute_batch/batch_layout.cc","test":R/"tests/compute_batch/batch_layout_test.cc",
        "qwen":R/"engine/models/qwen35/main.cc"}
    for name,source in units.items():
        folder=OUT/name;obj=folder/(name+".obj");frozen=b.identity(source)
        cmd=[command[0],*flags,"/sourceDependencies",str(folder/"dependencies.json"),str(source),
             "/Fo"+str(obj),"/Fd"+str(folder/(name+".pdb"))]
        b.execute(cmd,native.env,folder)
        assert b.identity(source)==frozen
        deps=b.read(folder/"dependencies.json")["Data"]
        b.save(folder/"identity.json",dict(source=frozen,object=b.identity(obj),command=cmd,
            dependencies=[b.identity(p) for p in dict.fromkeys([deps["Source"],*deps["Includes"]])]))
    base=b.read(BASE/"link-plan.json")
    replacements={}
    suffixes={"compute--resource_budget.obj":"budget","compute--resource_leases.obj":"leases",
        "batch-layout.obj":"layout"}
    for arg in base["command"]:
        if Path(arg).name in suffixes:replacements[arg]=str(OUT/suffixes[Path(arg).name]/(suffixes[Path(arg).name]+".obj"))
        if arg==str(BASE/"qwen/qwen.obj"):replacements[arg]=str(OUT/"qwen/qwen.obj")
    assert len(replacements)==4
    def link(kind):
        cmd=[]
        for arg in base["command"]:
            if arg.upper().startswith(("/OUT:","/MAP:","/IMPLIB:","/PDB:")):continue
            if kind=="tests" and arg in (str(BASE/"qwen/qwen.obj"),str(S/"cpu-build1/entry/entry.obj")):continue
            cmd.append(replacements.get(arg,arg))
        folder=OUT/(kind+"-link");image=folder/("checks.exe" if kind=="tests" else "hyle-cpu.exe")
        if kind=="tests":cmd += [str(OUT/"test/test.obj"),str(R/".scratch/build-compute-v2-dev/lib/gtest_main.lib"),str(R/".scratch/build-compute-v2-dev/lib/gtest.lib")]
        cmd += ["/OUT:"+str(image),"/MAP:"+str(image.with_suffix(".map")),"/IMPLIB:"+str(image.with_suffix(".lib"))]
        b.save(OUT/(kind+"-link-plan.json"),dict(command=cmd,base=b.identity(BASE/"link-plan.json"),replacements=replacements,
            compiled_TUs=5,SDK_builds=0,NVCC_builds=0,downloads=0,
            ABI="Only an additive private static function declaration; public options, classes and existing function signatures unchanged."))
        b.execute(cmd,native.env,folder)
        runtime=b.read(BASE/"runtime-environment.json")
        for row in runtime["staged_dlls"]:
            b.require(row);os.link(row["path"],folder/Path(row["path"]).name)
        b.save(OUT/(kind+"-ready.json"),dict(image=b.identity(image),PATH=str(folder)+os.pathsep+runtime["PATH"]))
    link("tests");link("engine")

def run_all():
    checks=b.read(OUT/"tests-ready.json");b.require(checks["image"])
    b.execute([checks["image"]["path"],"--gtest_filter=BatchLayout.*"],dict(os.environ,PATH=checks["PATH"]),OUT/"tests-run",120)
    ready=b.read(OUT/"engine-ready.json");b.require(ready["image"])
    env=dict(os.environ,PATH=ready["PATH"]);image=ready["image"]["path"]
    inputs=R/".scratch/qwen-mtp-window-20261022/inputs";results=[]
    for name,source,mtp in (("ordinary-text","text","off"),("ordinary-mtp-manifest","mtp","off"),("mtp","mtp","on")):
        cmd=[image,"--inputs",str(inputs/source),"--steps","4","--capacity","256","--max-sessions","1",
            "--active-sequences","1","--prefix-cache","off","--progress","direct","--replay","commands","--mtp",mtp]
        folder=OUT/name
        try:
            result=b.execute(cmd,env,folder,600)
            raw=json.loads((folder/"stdout.log").read_text(encoding="utf-8").strip().splitlines()[-1]);b.save(folder/"parsed.json",raw)
            results.append(dict(name=name,passed=True,process=result,parsed=b.identity(folder/"parsed.json")))
        except Exception as error:results.append(dict(name=name,passed=False,error=str(error),process=b.read(folder/"process.json")))
        b.save(OUT/"summary.json",dict(runs=results,performance_claim=False,quality_claim=False,full_CMake_build=False))
    for name,opts,wanted in (("quota-one",["--cache-bytes","1"],"--cache-bytes"),
                             ("mtp-without-weights",["--mtp","on"],"MTP")):
        cmd=[image,"--inputs",str(inputs/"text"),"--steps","4","--capacity","256",*opts];folder=OUT/name
        try:b.execute(cmd,env,folder,30)
        except RuntimeError:pass
        result=b.read(folder/"process.json");err=(folder/"stderr.log").read_text(encoding="utf-8")
        passed=result["exit"]!=0 and not result["timed_out"] and wanted.lower() in err.lower() and "resident text weights" not in err
        results.append(dict(name=name,passed=passed,process=result,weights_loaded=False if passed else None))
        b.save(OUT/"summary.json",dict(runs=results,performance_claim=False,quality_claim=False,full_CMake_build=False))
    if not all(row["passed"] for row in results):raise SystemExit(1)

if __name__=="__main__":
    if sys.argv[1]=="compile":compile_all()
    elif sys.argv[1]=="run":run_all()
    else:raise SystemExit("compile or run")
