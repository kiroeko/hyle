from pathlib import Path
import datetime,hashlib,json,re,subprocess,zipfile
root=Path.cwd();base=root/'.scratch/inference-gaps/g06';folder=base/'final-windows-source-1';out=root/'evidence/correctness/inference-g06-final-windows-source'
assert not out.exists();r=json.loads((folder/'result.json').read_text());assert r['state']=='TERMINAL_PASS'
product='0a29d119426b2975d48c238c37a2994675e0ba9f'
assert not subprocess.check_output(['git','diff','--name-only',product,'HEAD','--','include','src','cmake','CMakeLists.txt'],text=True).strip()
assert all(s['exit_code']==0 for s in r['stages'])
tests={};names=set()
for row in r['stages']:
 if row['stage'].startswith(('hyle_','g04_')):
  text=Path(row['log']).read_text();passed=re.search(r'\[  PASSED  \] (\d+) tests\.',text)
  assert passed and '[  FAILED  ]' not in text and '[  SKIPPED ]' not in text
  tests[row['stage']]=int(passed[1]);names.add(Path(row['command'][0]).name)
assert sum(tests.values())==569
artifacts=[]
for p in sorted((Path(r['build'])/'bin').iterdir()):
 if p.is_file() and (p.name in names or p.suffix.lower()=='.dll'):
  artifacts.append(dict(path=str(p),sha256=hashlib.sha256(p.read_bytes()).hexdigest(),bytes=p.stat().st_size))
assert all(hashlib.sha256(Path(x['path']).read_bytes()).hexdigest()==x['sha256'] for x in artifacts)
out.mkdir(parents=True)
with zipfile.ZipFile(out/'raw.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(folder.iterdir()):
  if p.is_file():z.write(p,p.name)
 z.write(Path(__file__),'sealer.py')
receipt={'state':'PASS_FINITE_WINDOWS_CPU_CORE_GRAPH_SOURCE_ONLY','product_candidate':product,'source_snapshot':r['candidate'],
 'record':'docs/implementation/tasks/compute/inference-g06-metadata-decode.md','identity':r['identity'],'tests':tests,
 'stages':r['stages'],'outer_elapsed_seconds':r['outer_elapsed_seconds'],'artifact_rechecks':artifacts,
 'qualification':['Actual Windows MSVC original compute108,batch60,Graph285,graph_batch6,ggml CPU84,original encoded common26 all PASS569, no skips. Original core/Graph exported bridges compiled and consumed.',
 'Native CPU dynamic paged/ragged Q1 and common multi-node/metadata/page/lifetime/encoded paths exercised in original factor suites; unsupported CPU capture explicitly rejected, ordinary path still works.',
 'Same existing Windows incremental CPU tree, selected actual factors/direct consumers, max4 workers and no CUDA compilation. Product include/src/cmake unchanged from frozen candidate; later fixture-only CUDA test fix does not change this product.'],
 'limits':['Source only, not independent headers/relocated static/shared/sanitizers/P1/full G06 acceptance','Native private/driver costs UNKNOWN and G04/G05 unresolved performance remain'],
 'raw_sha256':hashlib.sha256((out/'raw.zip').read_bytes()).hexdigest(),'timestamp_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
(out/'receipt.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'state':receipt['state'],'passed':sum(tests.values()),'artifact_count':len(artifacts)},ensure_ascii=False))
