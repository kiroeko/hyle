"""One selected finite lag1/prior/catchup check; no retries or downloads."""
from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
import time

W = Path(__file__).resolve().parent
R = W.parents[1]
mode = sys.argv[1]
assert mode in ('tiny', 'original')
if mode == 'original':
    assert json.loads((W/'tiny1/summary.json').read_text())['status'] == 'PASS'
fixture = R/('.scratch/mtp-state-ports-20261024/gdn-regression/shared-fixture' if mode == 'tiny'
    else '.scratch/qwen35-unsloth-mtp-20261024/geometry-v2-check/original')
ready_path = W/'ready.json'
ready = json.loads(ready_path.read_text())
runtime = json.loads(Path(ready['runtime']['path']).read_text())
def pin(path):
    path = Path(path)
    with path.open('rb') as stream: digest = hashlib.file_digest(stream,'sha256').hexdigest()
    return dict(path=str(path.resolve()),bytes=path.stat().st_size,sha256=digest)
for field in ('image','runtime','source_freeze'):
    assert pin(ready[field]['path']) == ready[field]
for row in json.loads(Path(ready['source_freeze']['path']).read_text()):
    assert pin(row['path']) == row
environment = os.environ.copy()
environment.update(runtime.get('configured_flags', {}))
environment.update(PATH=str(W/'link')+';'+runtime['PATH'], HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1')
command = [ready['image']['path'],'--cuda',str(fixture),'--mtp-lag1']
out = W/(mode+'1')
assert not out.exists(), 'Preserve actual attempt'
out.mkdir()
record = dict(command=command,cwd=str(R),ready=pin(ready_path),image=ready['image'],
    runtime=ready['runtime'],fixture_manifest=pin(fixture/'weights.tsv'),timeout_seconds=120)
(out/'command.json').write_text(json.dumps(record,indent=2)+'\n')
start = time.perf_counter()
with (out/'stdout.log').open('xb') as stdout,(out/'stderr.log').open('xb') as stderr:
    child = subprocess.Popen(command,cwd=R,env=environment,stdout=stdout,stderr=stderr,
        creationflags=subprocess.CREATE_NO_WINDOW)
    (out/'running.json').write_text(json.dumps(dict(pid=child.pid,command=command),indent=2)+'\n')
    print('LAG1_NATIVE_PID',child.pid,mode,flush=True)
    timed_out = False
    try: code = child.wait(timeout=120)
    except subprocess.TimeoutExpired:
        timed_out = True; child.kill(); code = child.wait(timeout=10)
record.update(pid=child.pid,exit=code,timeout=timed_out,seconds=time.perf_counter()-start,performance_claim=False)
(out/'process.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record),flush=True)
assert code == 0 and not timed_out, 'Keep actual failure and stop'
result = json.loads((out/'stdout.log').read_text(encoding='utf8'))
assert result['status'] == 'PASS' and result['seed_lag'] == 1 and result['prior_nonzero_bytes'] > 0
(out/'summary.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result),flush=True)
