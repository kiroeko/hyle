"""Frozen single-CUDA-Model/wrapper TU build; no model or test execution.

Default: no action. After root SOURCE_FROZEN: plan, then build.
Reuse the current causal-conv CUDA case closure, never a CPU weights closure.
"""
from pathlib import Path
import importlib.util
import json
import os
import sys

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = W.parents[1]
C = R/'.scratch/inference-causal-conv-20261026'
H = R/'.scratch/inference-host-image-20261026'
spec = importlib.util.spec_from_file_location('causal_helpers', C/'build.py')
c = importlib.util.module_from_spec(spec)
spec.loader.exec_module(c)
b = c.b
RECIPE = H/'cuda4/compile/command.json'
SOURCE = R/'tests/tools/qwen_host_image_test.cc'


def plan():
    assert not (W/'plan.json').exists(), 'Preserve each frozen attempt'
    ready = b.read(C/'case/ready.json')
    for field in ('image', 'runtime', 'link_inputs'): b.exact(ready[field])
    inputs = b.read(ready['link_inputs']['path'])
    old_object = b.read(C/'plan.json')['baselines']['case']['object']
    assert sum(b.key(row['path']) == b.key(old_object['path']) for row in inputs) == 1
    assert not any(b.key(row['path']).endswith('engine\\entry\\unit.obj') for row in inputs)
    for row in inputs: b.exact(row)
    b.exact(old_object)
    frozen = c.closure([SOURCE, R/'engine/models/qwen35/main.cc',
        R/'tests/tools/qwen_host_image_case.h'], [RECIPE])
    b.save(W/'source-freeze.json', frozen)
    b.save(W/'link-inputs-before.json', inputs)
    b.save(W/'plan.json', dict(status='SOURCE_FROZEN_NOT_BUILT_OR_RUN', baseline_commit='132a55be8',
        source=b.pin(SOURCE), compile_recipe=b.pin(RECIPE),
        compile_command=b.compile_command(RECIPE, SOURCE, W/'compile'),
        source_freeze=b.pin(W/'source-freeze.json'), baseline_ready=b.pin(C/'case/ready.json'),
        baseline_image=ready['image'], runtime=ready['runtime'], inputs=b.pin(W/'link-inputs-before.json'),
        link_recipe=b.pin(C/'case/link/command.json'), replaced_object=old_object,
        expected_inputs=len(inputs), compiled_TUs=1, archive_rewrites=0,
        scope='Compile canonical qwen_host_image_test.cc including its parameter parser. Replace the unique combined CUDA Model/case-entry OBJ; retain native causal-conv, correct CUDA weights, report, SDK and all other input bytes.',
        adaptation='Use root-frozen canonical test source instead of the prepared private wrapper; no private wrapper compiled.',
        expected_run_arguments=['--cuda', '<prepared_input_directory>', '--mtp-lag1'],
        CPU_execution='NOT_RUN'))
    print('LAGGED_PLAN', json.dumps(b.pin(W/'plan.json')), flush=True)


def build():
    p = b.read(W/'plan.json')
    assert not (W/'compile').exists() and not (W/'ready.json').exists()
    for field in ('source', 'compile_recipe', 'source_freeze', 'baseline_ready',
                  'baseline_image', 'runtime', 'inputs', 'link_recipe', 'replaced_object'): b.exact(p[field])
    frozen = b.read(p['source_freeze']['path'])
    for row in frozen: b.exact(row)
    inputs = b.read(p['inputs']['path'])
    for row in inputs: b.exact(row)
    h = b.helper()
    compiler = p['compile_command'][0]
    env = h.discover_environment(compiler='msvc', cache={'CMAKE_C_COMPILER': compiler,
        'CMAKE_CXX_COMPILER': compiler, 'CMAKE_GENERATOR': 'Ninja'}, backends=()).env
    compiled = h.execute(p['compile_command'], env, W/'compile', timeout=180)
    dep = b.read(W/'compile/dependencies.json')['Data']
    actual = [b.pin(path) for path in dict.fromkeys([dep['Source'], *dep['Includes']])]
    by_key = {b.key(row['path']): row for row in frozen}
    for row in actual:
        path = Path(row['path'])
        if path.is_relative_to(R) and not path.is_relative_to(R/'.scratch'):
            assert b.key(path) in by_key and row['sha256'] == by_key[b.key(path)]['sha256'], str(path)
    b.save(W/'actual-dependencies.json', actual)
    for row in frozen: b.exact(row)
    obj = b.pin(W/'compile/unit.obj')
    image = W/'link/host-image-lagged-consumer.exe'
    command, replaced = [], 0
    for arg in b.read(p['link_recipe']['path'])['command']:
        if b.key(arg) == b.key(p['replaced_object']['path']): arg = obj['path']; replaced += 1
        elif arg.upper().startswith('/OUT:'): arg = '/OUT:'+str(image)
        elif arg.upper().startswith('/PDB:'): arg = '/PDB:'+str(image.with_suffix('.pdb'))
        elif arg.upper().startswith('/IMPLIB:'): arg = '/IMPLIB:'+str(image.with_suffix('.lib'))
        elif arg.upper().startswith('/MAP:'): continue
        command.append(arg)
    assert replaced == 1
    linked = h.execute(command, env, image.parent, timeout=120)
    final = [obj if b.key(row['path']) == b.key(p['replaced_object']['path']) else row for row in inputs]
    assert len(final) == p['expected_inputs']
    b.save(W/'link-inputs.json', final)
    runtime = b.read(p['runtime']['path']); b.exact(runtime['native'])
    alias = image.parent/Path(runtime['native']['path']).name
    os.link(runtime['native']['path'], alias); runtime['native_hardlink'] = b.pin(alias)
    b.save(W/'runtime.json', runtime)
    b.save(W/'ready.json', dict(status='LINKED_NOT_RUN', image=b.pin(image), object=obj,
        runtime=b.pin(W/'runtime.json'), link_inputs=b.pin(W/'link-inputs.json'),
        source_freeze=p['source_freeze'], actual_dependencies=b.pin(W/'actual-dependencies.json'),
        plan=b.pin(W/'plan.json'), compile=compiled, link=linked, compiled_TUs=1,
        native_weight_report_SDK_builds=0, native_consumers=0))
    print('LAGGED_READY', json.dumps(b.pin(W/'ready.json')), flush=True)


if __name__ == '__main__':
    if sys.argv[1:] == ['plan']: plan()
    elif sys.argv[1:] == ['build']: build()
    else: print(__doc__)
