from pathlib import Path
import hashlib
import json
import zipfile

W = Path(__file__).resolve().parent
R = W.parents[1]
D = R/'docs/evidence/correctness'
def read(path): return json.loads(Path(path).read_text(encoding='utf-8-sig'))
def pin(path):
    path = Path(path)
    with path.open('rb') as stream: sha = hashlib.file_digest(stream,'sha256').hexdigest()
    return dict(path=path.relative_to(R).as_posix(),bytes=path.stat().st_size,sha256=sha)

sources = [R/path for path in ('tests/tools/qwen_host_image_case.h',
    'tests/tools/qwen_host_image_test.cc','tests/CMakeLists.txt')]
ready = read(W/'ready.json')
results = {}
for mode in ('tiny','original'):
    process = read(W/(mode+'1/process.json'))
    result = read(W/(mode+'1/summary.json'))
    assert process['exit'] == 0 and not process['timeout'] and result['status'] == 'PASS'
    assert result['seed_lag'] == 1 and result['prior_nonzero_bytes'] > 0
    results[mode] = dict(process=pin(W/(mode+'1/process.json')),fixture=process['fixture_manifest'],result=result)
records = [W/path for path in ('build.py','run.py','publish.py','plan.json','ready.json','source-freeze.json',
    'actual-dependencies.json','runtime.json','preparation.json')]
for folder in ('compile','link','tiny1','original1'):
    records.extend(path for path in (W/folder).iterdir() if path.suffix in ('.json','.log'))
archive = D/'inference-host-image-lag1-2026-10-26.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as output:
    for path in sorted(set(sources+records)):
        output.write(path,path.relative_to(R).as_posix())
report = dict(date='2026-10-26',status='BOUNDED_CUDA_LAG1_PRIOR_ROUNDTRIP_PASSED',baseline_commit='132a55be8',
    sources=[pin(path) for path in sources],archive=pin(archive),
    changes=['Add independently selectable --mtp-lag1 mode to the canonical HostImage consumer and CPU/CUDA CTest entries.',
        'No Model or Compute/Graph implementation changes in this batch.'],
    preparation='Real Verify T2 executes explicit inputs, selects its own completed second candidate and consumes both rows through original finish_selected_evaluations and repair_recursive_draft. This deterministically creates canonical lag1/prior state without changing head metadata or requiring accidental draft agreement.',
    hardware=dict(gpu='NVIDIA GeForce RTX 4070',driver='617.14'),
    build=dict(compiled_TUs=1,source='tests/tools/qwen_host_image_test.cc',record=pin(W/'ready.json'),
        image=ready['image'],reused='Exact 223-input CUDA closure; native providers, weights, report and SDK reused without recompilation.',
        first_compile_and_link_exit=0),
    results=results,
    checked=['Complete byte and logical boundary equality after host export/import/export, including nonzero prior_hidden.',
        'Lag1 draft frontier equals target length minus one; catchup_token remains the final consumed explicit input.',
        'Original kMtpCatchupRound executes on original and restored same-shape branches; all MtpRoundResult fields and complete resulting images match.',
        'Retained old snapshot remains unchanged; independent fresh version on restore; final image/version counts and active native episode return to zero.'],
    limitations=['CUDA only for this new lag1 check. CPU CTest entry is registered but was not run; prior lag0 CPU evidence remains separate.',
        'No native pending/fault injection or Apple/Vulkan state-transfer qualification.',
        'Seed is an explicit verified prefix, not natural speculative acceptance or whole task quality.',
        'Tiny fixture is untrained; original fixture uses existing cached original Qwen3.5-2B roles. No downloads.',
        'No throughput, memory-peak or speedup claim; process durations are diagnostic correctness clocks.'])
(D/'inference-host-image-lag1-2026-10-26.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
print(json.dumps(dict(evidence=pin(D/'inference-host-image-lag1-2026-10-26.json'),archive=pin(archive))))
