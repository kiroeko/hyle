# 当前工作计划

更新：**2026-10-23**。进入“实际推理驱动的性能、功能与架构收敛”阶段。
范围仍是Windows／Linux／macOS的单机CPU、单GPU和CPU＋一张GPU；多模态限图片encoder／projector（mmproj）到文本。
Qwen3.5-2B是检验底座的真实测试消费者；架构还要承载其他已选模型、量化格式、算子和后端。

**当前优先级（用户2026-10-22确认）：先把MTP做完。** Qwen3.5-2B greedy K1主链、列明有限正确性检查及四臂性能对照已有；其它适用制品的原角色／codec和完整状态组合仍在补齐。多模态图片完整链路等前三项完成后开始，连续批处理调度扩展暂后置。

## 现在的位置

旧阶段8个能力包、3个交付包已完成各自列明范围，不代表架构已全量审完、全部模型已完整执行。现有冷编译、不可变计划、独立Invocation、状态版本、分页权限和真实CUDA文本推理基础，继续推进性能、功能与架构三条主线。
旧阶段见[归档](../evidence/planning/current-work-through-2026-10-21.md)；截至AY的数值调查、逐批回归及其限制见[本次归档](../evidence/planning/current-work-through-2026-10-22-ay.md)。源码、日志和数据保留在原证据中，不将历史实验自动重开为任务。

**最新完整性能仍是[页末AV四臂窗口](#最新完整性能对比)**：普通Hyle／llama.cpp prefill为2349.076／1553.955tok/s，decode99.764／105.224；MTP为2137.322／1499.623、123.162／139.532。普通共用成本和MTP增量分别调查，不能用总TPS判定MTP逻辑错误；本次原角色接线没有新TPS或显存数据。

## MTP当前剩项

| 类别 | 当前结论与具体工作 |
| --- | --- |
| 通用机制缺口 | 动态E4量化的codes＋F32 scales两实际输出已有CPU／CUDA／Vulkan／Apple逐bit、失败恢复与寿命检查；GLM显式选PowerOfTwo／floor1e-4。本轮补上CUDA公共I32→F32 Cast，核整数舍入边界、stride、重复提交及原浮点／Bool转换。状态、页权限、租约与StateHead继续共用 |
| 原角色／codec接线 | GLM官方14原角色已进入完整NextN输入／query／indexer及接受后追赶，CPU／CUDA通过；默认ue8m0缓存和原生成路径保留。DSpark已接45份sidecar原角色及正式Flash原BF16全词表embedding／head，共47角色2,320,527,260B，CPU／CUDA实际完整draft通过，无整份F32 LM权重副本；新增norm／sink／HC保原F32。Q27原EH／两norm、Q24原K／V／K norm已进入各自完整NextN。剩余原角色、GLM共享LM、真实target taps及已确认量化供给继续按精确制品身份接入 |
| 完整状态组合 | GLM默认codec＋43→44→NextN共34资源＋epoch、DSpark三stage编码main ring＋完整draft已有CPU／CUDA检查。Q27／Q24本轮也核完整草拟KV、normalized hidden、pending、有效行数／位置六资源同Head，接受0／1／2后各分支继续；两者target主干仍是显式外部边界，不能据此代签完整原模型或全部制品 |
| 覆盖限制 | 未运行完整原模型、尚未核定的MTP存在性和未执行的系统／codec组合均如实保留，不写成通过，也不自动变成“必须另造八套引擎”。Kimi固定原制品无NextN、Qwen3.5两个baseline GGUF明确排除MTP，不凭名称列缺；33条量化发现记录不等于33个已确认MTP任务 |

Q27／Q24单次完整量化head、GLM Flash原14参数及DSpark原13项norm／sink＋21项HC已通过。DSpark sidecar还剩36角色：12份attention投影、9份shared FFN、3份router＋3份bias、9份MXFP4专家bank；精确格式与数据量见[本轮清单](../evidence/correctness/mtp-dspark-original-hc-2026-10-23.json)。下一步按完整计算分支推进其余角色、共享LM、真实target taps与适用量化组合；GLM Pro与Flash的实际几何差异分别处理。DSpark原router／bias需同时处理实际选中expert的驻留，不能沿生成小bank过滤真实ID；GGUF MXFP4的Q8_1激活与官方FP4／E4-A128是不同计算合同。最后做必要回归和普通／MTP完整对照，再进入图片。已通过的有限状态组合不重复列为待接，模型范围见[总表](../implementation/model-operators.md)。

**本轮实际进展**：[DSpark原norm／sink／HC完整接线](../evidence/correctness/mtp-dspark-original-hc-2026-10-23.json)6项相关检查全部通过，无跳过，共150次Graph：新CPU／CUDA两旅程50次，旧编码历史／共享词表回归100次。只新增34份原F32参数9,827,740B，其余复用；七份HC投影、原20轮Sinkhorn、四路head、learned RMS／sink和实际BF16存储逐层核对，接受0／1／2、回绕及各Head续算通过。实际七份fn投影CPU均为ggml-cpu，CUDA均为cuBLAS Lt的F32 pedantic路径。此前[GLM原indexer](../evidence/correctness/mtp-glm-original-indexer-2026-10-23.json)8项／204次Graph、[完整量化head](../evidence/correctness/mtp-full-packed-head-2026-10-23.json)及[共享词表／草拟状态](../evidence/correctness/mtp-shared-vocabulary-state-2026-10-23.json)证据保留。没有新TPS或物理内存／显存峰值数据，页末AV对比保持原样。

已取得的实际边界：

- **Qwen3.5-2B**：原335份权重的greedy K1消费者已接多会话／多轮／B2、完整前缀、有界重建及三平台列明的有限取消／退休与预算恢复。[8项QKV差异调查](../evidence/correctness/qwen-mtp-quality-prefix-2026-10-22.json)指向普通单／双行投影的稳定浮点差异，未发现越过既有判据的计算错误，不再作为MTP逻辑阻塞；不据此宣称所有形状或完整质量通过。
- **Q27／Q24**：[本轮](../evidence/correctness/mtp-shared-vocabulary-state-2026-10-23.json)在完整NextN中复用原Q27 EH／两norm和原Q24 K／V／K norm；公共input／QKV／GQA构图共享，dense FFN与top10 MoE分开。一次Step Graph含完整V248320的embedding／单次head，真实预测ID、normalized hidden和完整cap6 KV租约继续；六状态原子选择prefix0／1／2，各Head续算及旧结果通过。Q27主UD-Q4_K_M身份与独立sidecar分清，Q24为主UD-IQ4_XS；其它参数／词表仍生成，未代签target GDN／conv主干、512原专家、其它量化或自然接受率。旧C5两profile回归保留。输出backing按整根计费；CUDA额外原生参考225次与消费者Graph分开计数，原角色独立F64和局部F32门保留。
- **GLM-Flash**：[官方14原角色](../evidence/correctness/mtp-glm-original-indexer-2026-10-23.json)已在同一完整NextN内贯通EH／norm／动态q_a／qnorm与indexer七参数；fresh、journal和direct catchup借同一组只读权重，同轮skip完全不建indexer。保原BF16投影／LayerNorm存储、F32 weights_proj／APE、q_a显式Divide／floor1e-10与cache PowerOfTwo／floor1e-4；raw key／gate为BF16，持久pool为E4＋F32 scales。17项状态＋epoch的接受1／2、追赶、epoch8 seed及旧结果CPU／CUDA通过。另有[生成参数target43→44→NextN](../evidence/correctness/mtp-encoded-state-2026-10-23.json)34资源＋epoch组合，本轮回归保留，layer43不借用layer45原参数。target hidden／embedding、其余MLA／MoE／head仍生成；原45层模型、共享LM、Pro几何和自然接受率未完成，逻辑codec不代签vendor页ABI。
- **DSpark**：[本轮](../evidence/correctness/mtp-dspark-original-hc-2026-10-23.json)47原角色2,320,527,260B包含正式Flash BF16完整embedding／head、此前十一Q8 sidecar角色及新增34份norm／sink／HC参数；任意实际token读取原embedding行，同一只读owner／lease可供target与draft借用，不逐stage复制或扩为F32大权重。真实共享词表与原三stage编码main历史、完整draft、接受0／1／2及各Head续算CPU／CUDA通过；每端首episode646400个LM值按原BF16系数／实际输入独立F64点积与传播界核，后续仍跑完整全V head。每episode另核原F32 HC投影的乘积／累加误差界、实际前驱上的局部非线性与精确BF16存储；confidence、Markov／IDs及旧生成门保留。attention其余投影、shared／expert／router和target captures／verifier仍生成；不代签完整训练target、Pro几何、main UD-Q4词表或自然接受率。

## 执行顺序与近期进度

| 顺序 | 工作 | 状态与下一动作 |
| --- | --- | --- |
| 1 | 容量参数与初始化 | 消费者已接上下文、缓存会话数、活跃序列数与状态字节预算，支持auto和提前拒绝；状态预算不冒充全显存上限 |
| 2 | 多会话缓存与执行 | Radix／LRU、COW／独占尾权、共享执行资源、完全命中、有界恢复及真实B2已接。三平台有限完整前缀、取消／退休及额度恢复已有；跨形状数值／质量、实际性能和其它模型状态组合仍按真实范围推进 |
| 3 | MTP | 当前优先；GLM编码状态、Q27／Q24完整草拟六资源、DSpark真实全词表＋编码main历史／完整draft已有CPU／CUDA检查。CUDA大head已改为单次；原GLM14角色、DSpark47角色已接，下一步其余角色／共享LM／真实target taps与已确认量化组合，最后完整性能对照 |
| 4 | 图片encoder／projector | 等前三项完成后开完整链路；已有297个BF16视觉张量、24层H1024 encoder及4096→4096→2048 merger身份。后续RGB／patch→视觉Graph→文本embedding、多轴位置／delta、图片前缀身份与寿命；原LayerNorm weight＋bias |
| 并行 | 已知性能慢项 | 普通／MTP decode差距、descriptor上传依赖、随历史增长的页组织、cached-prefill首用与合法拓扑变化继续按实际热点处理，见[性能计划](performance/decode.md) |
| 贯穿 | 架构审查与实现收敛 | 保性能、职责、数值及寿命正确；检查其它已选模型／算子／后端，普通扩展不反复修改共同调度核心 |

用户顺序仍是多会话缓存／推理→MTP→图片；当前先收MTP已有明确剩项。单请求延迟、多人总吞吐、缓存命中和重建成本分别报告，不把一次CUDA结果外推到全部系统／制品，也不把完整KV以外状态丢掉后宣称可任意截断前缀。

**连续批处理调度扩展后置。** 参考llama-server可在线接纳新请求、按token预算混合兼容prompt／decode；当前消费者采用预定wave及T／role／lag桶。引擎负责调度政策，底座仍需承载可变活跃子集、变长计算、完整状态与有界资源复用；当前MTP任务不扩建server或新增多执行器。

## 性能：借鉴成熟实现，落到真实瓶颈

已有[本地7个引擎的优化研究](../evidence/research/local-inference-optimization-2026-10-21.json)，包括TensorRT-LLM、vLLM、SGLang、llama.cpp、ik_llama.cpp、DeepInfer和ds4；其他既有研究由旧计划保留链接。
先查当前准备／重录成本，再试实际热点的少量合法冷算法；量化链再检查保原舍入的融合、packed分块计算及多余转换／搬运。
匹配完整数学、设备和工作量后才采用。量化路线的改进不自动算成BF16 Qwen收益，源码启发也不算实测收益。

最新完整对比固定放在本页末尾；阶段归因与实验决策见[性能计划](performance/decode.md#三轮共享缓存的四项基线2026-10-21)。
此前约22%改善属于一次cached16输入续算，不是整体decode提升。

每次完整对比固定报告**prefill、完整decode、显存变化、多轮综合速度**；加载／冷准备与热执行分列，
测速和显存旁采分开，保同输入、精度、缓存、状态、完成与计时边界，见[统一口径](performance/README.md#推理对比固定报告)。
先排除工作量不等价和测量分辨率，再优化时间复杂度、显存复杂度与实际常数成本。

## 功能：引擎表达意图，底座承载机制

[容量参数研究](../evidence/research/engine-capacity-2026-10-21.json)提出下面四种主要意图，现已在[测试消费者](../../tools/qwen35_text/README.md)提供相应参数及auto解析；它们不是Hyle库要求用户手填的内部字段。

| 用户可表达的意图 | 必须分清的含义 |
| --- | --- |
| 单序列上下文上限 | 一条序列的历史容量，不等于物理KV池 |
| 缓存会话数 | 保留的活跃＋空闲会话，不等于同时执行数 |
| 同时执行序列数 | 正在调度的序列并发，不等于执行槽或用户总数 |
| 缓存字节预算 | 各层KV、conv／GDN、分支写入及保留版本总成本，不等于全进程显存 |

总内存预算可选；步长、执行槽数和常用准备形状通常自动推导。启动报告实际容量、已准备域、已知／未知资源和超限行为。
参数支持预分配与准入，不能承诺固定tokens/s或控制驱动／其他进程的显存。
当前测试消费者按turn接纳活跃请求，空闲会话可按数量或状态字节限制淘汰；再使用时按原输入chunk重建完整状态。默认auto按本次输入与预算解析，没有固定的用户数要求。
上限不预先分配对应数量的会话，单用户decode直达自己的Session，不逐token查询LRU／预算。单序列冷准备由同时执行数表达，不把缓存数量限制误当加速开关。
缓存必须同时受会话数和字节预算约束；共享物理页只计一次，conv／GDN、COW暂存、旧版本和待退休页仍计实际占用，不能把移出目录当作显存已释放。
当前Qwen将12份arena backing及36份状态池统一预留、计费一次，包含最多R份批次候选版本与COW尾页；不再用旧dense每会话公式计算。容量256、R1保留1／2会话时分别预留42,418,224／65,101,872字节，N2／R2为84,836,400字节；IO、workspace与未知原生私有存储另计。保留旧前缀也消耗版本／页额度，缓存数量限制不是无界检查点许可。
先由引擎按最久未使用顺序淘汰空闲缓存；全部在用或在途退休后仍无空间时排队或拒绝，不覆盖活跃状态。Hyle提供预算与真实退休后的安全回收，不承担用户目录和淘汰策略。淘汰设备缓存不等于删除对话记录；重建所需token等输入由引擎保留。
用户的单台DGX Spark四人编码服务属于未来模型选型场景；当前开发验证继续使用已有验证机器。多会话机制支持可配置容量，缓存会话数另计；服务评估需看总吞吐、每路速度、首token和延迟分布，不由单请求速度相乘推算。

- **多会话缓存**：共享只读权重／计划，隔离完整KV、conv／GDN和位置状态；精确前缀匹配、只读共享、显式写时复制，取消／淘汰后仍保护在途与旧读者。
  会话目录、准入／淘汰和批次策略归引擎；状态、页权限、预准备、独立执行槽与退休归Hyle。不能按会话复制整份模型冒充复用，也不以仅有多序列布局算完成。
- **MTP**：模型格式、tokenizer、draft／verify及接受策略归消费者；Hyle提供计算、完整状态、页权限、搬运和真实退休。Qwen当前目标T2与草拟缓存沿同次Graph／Completion，逐成员选择接受边界后原子发布；已消费前缀、fresh预测与未消费pending分开保存。当前剩项见[上表](#mtp当前剩项)，长期合同见[生成记录与缓存重算](../architecture/compute-design.md#生成记录与缓存重算)。
- **图片投影**：预处理和模型图片语义归消费者；Hyle补真实计算、布局、特征与文本绑定、搬运及资源寿命。先做图片，不扩展音频／视频。

既有自然轮次、EOS、取消／丢Completion、B2与有界重建、独立CPU／peer对照和数值调查保留在[AY前归档](../evidence/planning/current-work-through-2026-10-22-ay.md)及其原证据。已确认的完整状态、预算和退休能力继续复用；不同形状浮点差异、未验证的质量或物理资源峰不写成通过。

## 架构审查：性能成立，边界清楚，修改集中

审查目标是**实现是否满足这些边界**，不是再造一套抽象或统一所有原生执行细节。
共同点依据实际计算提取，允许后端保有原生算法、融合、布局和资源；引擎中间层不判断具体Provider／原生算子。

| 审查面 | 要确认并修复的内容 |
| --- | --- |
| 职责与扩展成本 | 模型表达数学／状态，Compute承载算子合同，Provider实现计算，Graph负责计划与依赖；新增算子／融合／后端不反复改共同调度、租约和提交核心，新模型尽量复用已有能力 |
| 冷规划与热执行 | 选路、融合、packing、容量和常见形状尽量冷生成；明确布局变化何时使原计划失效，只有实际依赖变化才重准备，避免隐藏搜索、重复分配／转换／同步 |
| 数值与布局合同 | dtype、量化与scale、累积／舍入、stride、alias、状态副作用可明确描述；融合覆盖真实DAG及读者，跨Provider边界明确import／copy与代价 |
| 不可变共享与可变隔离 | 代码／权重／常量可共享；Invocation、workspace、绑定和会话状态按实际并发要求隔离；分支、批次、旧结果不会相互覆盖 |
| 状态与异步寿命 | KV、recurrent／conv、位置和接受前缀属于完整续算状态；发布、失败、取消、关闭与真实native退休一致，旧版本、结果和设备在途使用都有owner |
| 资源与调度 | 冷／热内存、页池、执行槽、搬运和准备成本可解释；超限行为明确，未知私有内存不记零；混合CPU＋GPU不复制一套执行器，放置／同步按实际依赖处理 |
| 公共接口与可维护性 | 跨系统／设备调用形状一致，错误可定位到层和阶段；普通引擎调用不要求第三方类型、内部宏／Provider开关，明确的原生互操作入口保留；模块可独立升级，支持范围和实现保持一致 |

同时检查Direct与Graph共用合同、依赖和模块方向、缓存／制品身份及失效、能力发现与合法后备，避免隐式全局可变状态和第二套执行路径。
能力声明、路由与支持表应复用事实，减少重复名单和接线；设备或后端的真实限制在准备期说明，不强行抹平差异。
不追求“加算子零改动”：新语义可能需要新公共合同；普通扩展应集中在自己的实现和必要声明，新语义才修改共同合同。
用真实变更检验维护成本：换一个Provider实现、增加一种精度／融合、接入一种不同状态的模型，看改动是否局限于所属层，并检查完整推理速度与资源成本。
长期设计依据在[Compute](../architecture/compute-design.md)和[Graph](../architecture/graph-design.md)；已选模型／量化／角色／融合范围以[总表](../implementation/model-operators.md)为准，原制品未完整执行的条目继续如实标记。

## 工作方式

沿现有公共执行链补缺口，删除重复旧路径，不保兼容分支；不恢复治理、资格或审批流程。
只运行与改动相关的增量构建、数值／状态／寿命检查与真实消费者，复用三平台工具链、依赖和对象缓存，不因计划更新重跑全库。
保留必要源码、命令、失败和结果到[证据目录](../evidence/README.md)；新阶段是否完成按上述实际剩余工作判断，不按旧清单完成数推算总进度。

## 最新完整性能对比

**2026-10-22，MTP消费者接线与共用能力补齐后的完整四臂窗口（AV）。** 北京时间18:15:19～18:15:52；Qwen3.5-2B、RTX 4070、全CUDA、BF16权重，相同P154提示词、自然greedy输出64枚、C1024／N1／R1、前缀关闭、replay auto。每臂3个新进程交错测速，共12次；另各1个独立进程旁采内存，共4次。各臂沿用AU相应模型数学、权重与自然工作；历史窗口不合并。

| 当前模式 | prefill tok/s | 完整decode tok/s | 综合输出 tok/s |
| --- | ---: | ---: | ---: |
| Hyle普通 | 2349.076 | 99.764 | 91.816 |
| Hyle MTP K1 | 2137.322 | 123.162 | 109.669 |
| llama.cpp普通 | 1553.955 | 105.224 | 91.713 |
| llama.cpp MTP K1 | 1499.623 | 139.532 | 115.482 |

普通版Hyle相对参考prefill +51.17%，decode -5.19%，综合 +0.11%；MTP分别 +42.52%／-11.73%／-5.03%。综合为64输出／（完整prefill＋decode），不含加载；本窗单轮，不冒充多轮或多人吞吐。

| 当前模式 | prefill范围 tok/s | decode范围 tok/s | 综合范围 tok/s | 加载s | 入口至ready s | 入口至末输出s |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| Hyle普通 | 2079.09～2407.99 | 99.24～100.37 | 90.28～92.54 | 0.841 | 1.187 | 1.884 |
| Hyle MTP K1 | 2049.64～2207.36 | 116.90～123.31 | 104.22～110.22 | 0.891 | 1.671 | 2.252 |
| llama.cpp普通 | 1545.17～1637.81 | 103.57～105.94 | 90.40～92.93 | 1.555 | 1.584 | 2.282 |
| llama.cpp MTP K1 | 1498.01～1508.31 | 135.85～139.91 | 112.97～115.86 | 1.672 | 1.706 | 2.260 |

速度为3个独立进程比率的中位数并保留最小～最大范围，加载／ready／末输出也各取进程中位数；样本少，不作显著性结论。decode计prefill后63枚新输出的完整host端点，包含准备／捕获／等待／结果处理。加载边界依消费者实现；入口不含OS装载DLL，末输出不含销毁，不将其称为同一加载算法的胜负。

| 当前模式 | GPU dedicated峰 GiB | GPU shared峰 MiB | 同采样GPU总峰 GiB | CPU WS峰 GiB | CPU private commit峰 GiB |
| --- | ---: | ---: | ---: | ---: | ---: |
| Hyle普通 | 3.888 | 92.00 | 3.964 | 1.052 | 5.510 |
| Hyle MTP K1 | 4.048 | 92.00 | 4.124 | 1.142 | 5.784 |
| llama.cpp普通 | 3.728 | 82.00 | 3.808 | 4.071 | 4.673 |
| llama.cpp MTP K1 | 3.896 | 94.00 | 3.987 | 4.220 | 5.081 |

内存是独立Windows PSAPI／PDH旁采观测峰，非精确物理分配或TPS样本。dedicated与shared分列峰不可直接相加，总峰只在同一有效采样点相加；WS／commit／GPU shared也非互斥量。请求间隔10ms，实际间隔中位15.1～15.2ms、最大21.1ms；短prefill只有6～9个样本，ready基线无样本仍为null，GPU无实例时也不填零。四臂GPU采样峰与AU完全相同，不把它当精确分配不变的证明。

**实际工作与可比边界：** 各臂3次输出ID、实际工作及非计时轮次决策均稳定，与AU对应臂保持一致；全部输出64枚，未触发EOS。普通均计算154行prefill＋63行decode。Hyle MTP为34轮、29次接受（85.29%），验证68行、draft decode 62行；peer为33轮、30次接受（90.91%），验证66行、draft decode同为62行，两者最终提交decode均63行。两边MTP prefill各有154行target／draft，但Hyle只算所需draft K/V，peer走原完整MTP块。两对续文仍从第19枚起不同；Hyle中间BF16、末分数F32，peer原生算术／状态／host carry也不同，报告自然性能，不称同token或数学完全一致。

**窗口变化与性能主线：** AU已将普通／MTP decode恢复到91.44／112.29；本窗为99.764／123.162，但peer也从95.08／125.65升到105.224／139.532。两边都更快，不能把Hyle约9%的变化归因为本批优化收益。普通共用路径相对参考的差距继续按实际热点处理，与Qwen K1已列明的MTP状态／接受逻辑检查区分；其它适用MTP制品仍未完成。

**[AV共用能力与检查](../evidence/correctness/mtp-consumer-wiring-2026-10-22.json)：** 输入租约候选表仅在真实native输入需要时构造，原F1权限、alias、seal及退休门不变；F32 Add按实际标量carrier补4B对齐声明，保留V17夹具。owned alias与候选不相容时提前冷拒，保合法后续选路；29项相关回归0失败／0跳过。

[本轮12次计时、4次独立内存旁采及实际命令／结果](../evidence/performance/qwen-mtp-assembly-2026-10-22.json)。[AU有界捕获变体](../evidence/performance/qwen-capture-variants-2026-10-22.json)保留包含active在内的两变体、实际prepared资格与完整tuple／失效门，以及24项检查和15次Graph／534项向量回归；[AT诊断](../evidence/performance/qwen-capture-recording-cost-2026-10-22.json)、[AS可执行更新](../evidence/performance/qwen-capture-rebuild-2026-10-22.json)、[AR单槽回退](../evidence/performance/qwen-mtp-current-carrier-2026-10-22.json)、[AF单槽前窗口](../evidence/performance/qwen-mtp-steady-profile-2026-10-22.json)保留各自历史口径，不混算。
