"""Acquire only fixed DSpark norm/sink/HC roles, reusing the parsed table."""
from pathlib import Path
import datetime
import hashlib
import json
import math
import urllib.request

S = Path(__file__).resolve().parent
R = S.parents[1]
source_plan = R / '.scratch/large-gguf-head-20261023/review/next-original-suppliers.json'
plan = json.loads(source_plan.read_text(encoding='utf-8'))['dspark']
old_plan = R / plan['reuse_acquisition']['plan']
old = json.loads(old_plan.read_text(encoding='utf-8'))
header_path = R / old['header_source']
headers = json.loads(header_path.read_text(encoding='utf-8'))
header = headers[old['header_cache_key']]
for key in ('repository', 'revision', 'file', 'tensor_table_sha256'):
    assert header[key] == plan['identity'][key] == old[key], key
assert int(header['tensor_data_offset']) == int(plan['identity']['tensor_data_offset'])
assert header['tensor_count'] == 81
table = {role['name']: role for role in header['tensors']}
roles = sorted(plan['small_safe_batch']['roles'] + plan['hyperconnection_batch']['roles'],
               key=lambda r: r['absolute_range_inclusive'][0])
assert len(roles) == 34 and sum(r['payload_bytes'] for r in roles) == 9827740
for role in roles:
    actual = table[role['name']]
    assert actual['dtype'] == role['codec'] == 'F32' and actual['dtype_code'] == 0
    assert [int(d) for d in actual['shape']] == role['gguf_dimensions']
    first = int(header['tensor_data_offset']) + int(actual['offset'])
    size = math.prod(role['gguf_dimensions']) * 4
    assert size == role['payload_bytes']
    assert [first, first + size - 1] == role['absolute_range_inclusive']

# Merge only adjacent roles and the original <=32B alignment gaps. No missing
# large bank, router bias or previously acquired tensor body is fetched.
groups = []
for role in roles:
    first, last = role['absolute_range_inclusive']
    if groups and first - groups[-1]['last'] - 1 <= 32:
        groups[-1]['last'] = last
        groups[-1]['roles'].append(role)
    else:
        groups.append(dict(first=first, last=last, roles=[role]))

out = S / 'original-parameters'
out.mkdir(exist_ok=True)
receipt = out / 'acquisition.json'
record = dict(repository=old['repository'], revision=old['revision'], file=old['file'],
    url=old['url'], whole_file_bytes=old['known_whole_file_bytes'], etag=old['known_etag'],
    tensor_table_sha256=old['tensor_table_sha256'], tensor_data_offset=old['tensor_data_offset'],
    source_header=dict(path=str(header_path.relative_to(R)), bytes=header_path.stat().st_size,
        sha256=hashlib.sha256(header_path.read_bytes()).hexdigest()),
    complete=False, requests=[], roles=[], whole_file_downloaded=False)
if receipt.exists():
    previous = json.loads(receipt.read_text(encoding='utf-8'))
    for key in ('repository', 'revision', 'file', 'etag', 'tensor_table_sha256', 'source_header'):
        assert previous[key] == record[key], key
    record = previous
    for row in record['roles']:
        path = R / row['payload']['path']
        body = path.read_bytes()
        assert len(body) == row['payload']['bytes']
        assert hashlib.sha256(body).hexdigest() == row['payload']['sha256']
    if record['complete']:
        assert len(record['roles']) == 34
        print('REUSED34 authenticated DSpark role payloads')
        raise SystemExit(0)


def save():
    receipt.write_text(json.dumps(record, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')


save()
for group in groups:
    acquired = {row['name'] for row in record['roles']}
    if all(row['name'] in acquired for row in group['roles']):
        continue
    first, last = group['first'], group['last']
    size = last - first + 1
    attempt = dict(first=first, last=last, requested_bytes=size, complete=False,
        started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
    record['requests'].append(attempt)
    save()
    print('REQUEST exact role group', first, last, size, flush=True)
    request = urllib.request.Request(old['url'], headers={
        'Range': f'bytes={first}-{last}', 'If-Range': old['known_etag'],
        'Accept-Encoding': 'identity', 'User-Agent': 'hyle-original-role-consumer/1'})
    try:
        with urllib.request.urlopen(request, timeout=45) as response:
            assert response.status == 206, response.status
            assert response.headers.get('Content-Range') == f'bytes {first}-{last}/{old["known_whole_file_bytes"]}'
            assert response.headers.get('ETag') == old['known_etag']
            assert response.headers.get('Content-Length') in (None, str(size))
            body = response.read(size + 1)
            assert len(body) == size, len(body)
            attempt.update(http_status=206, content_range=response.headers['Content-Range'],
                etag=response.headers['ETag'], bytes=len(body), sha256=hashlib.sha256(body).hexdigest())
    except Exception as error:
        attempt.update(error_type=type(error).__name__, error=str(error),
            finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
        save()
        raise
    for role in group['roles']:
        if role['name'] in acquired:
            continue
        begin, end = role['absolute_range_inclusive']
        payload = memoryview(body)[begin-first:end-first+1]
        assert len(payload) == role['payload_bytes']
        path = out / (role['name'] + '.f32')
        if path.exists():
            assert path.read_bytes() == payload
        else:
            with path.open('xb') as stream:
                stream.write(payload)
        record['roles'].append(dict(**role, payload=dict(path=str(path.relative_to(R)),
            bytes=len(payload), sha256=hashlib.sha256(payload).hexdigest())))
    attempt.update(complete=True, finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
    save()
    print('ACQUIRED exact F32 roles', len(record['roles']), flush=True)

record.update(complete=True, role_payload_bytes=sum(row['payload']['bytes'] for row in record['roles']),
    successful_request_body_bytes=sum(row['bytes'] for row in record['requests'] if row['complete']))
assert len(record['roles']) == 34 and record['role_payload_bytes'] == 9827740
save()
print(json.dumps(dict(roles=34, payload_bytes=record['role_payload_bytes'],
    request_body_bytes=record['successful_request_body_bytes']), ensure_ascii=False), flush=True)
