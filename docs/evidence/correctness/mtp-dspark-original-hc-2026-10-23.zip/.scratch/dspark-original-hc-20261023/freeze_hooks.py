from pathlib import Path
import difflib,hashlib,json,shutil

stage=Path('.scratch/dspark-original-hc-20261023/hooks-source')
sources=[Path('tests/compute_models/cpu_c4_model_branches.h'),Path('tests/compute_models/d5_deepseek_official_attention.h'),Path('tests/compute_models/dspark_complete_graph_fixture.h')]
def identity(path):
    body=path.read_bytes()
    return {'path':path.as_posix(),'bytes':len(body),'sha256':hashlib.sha256(body).hexdigest()}
files=[]
for source in sources:
    before=stage/'before'/source
    frozen=stage/'frozen'/source
    frozen.parent.mkdir(parents=True,exist_ok=True)
    shutil.copy2(source,frozen)
    old=before.read_text(encoding='utf-8-sig').splitlines(keepends=True)
    new=source.read_text(encoding='utf-8-sig').splitlines(keepends=True)
    (stage/(source.name+'.diff')).write_text(''.join(difflib.unified_diff(old,new,fromfile=before.as_posix(),tofile=source.as_posix())),encoding='utf-8')
    files.append({**identity(source),'before':identity(before)})
data={
    'source_only':True,'native_build_run_download_ssh':False,'files':files,
    'contract':{
        'supplier':'base::DraftParameters.parameter(Fragment&, size_t stage, DraftParameter) -> ds::ImmutableF32Parameter{ValueId value,span<const float> coefficients}',
        'stage_roles':['kAttentionNorm','kFfnNorm','kQueryNorm','kSinks','kAttentionFn','kAttentionScale','kAttentionBase','kFfnFn','kFfnScale','kFfnBase'],
        'stage_domain':'0,1,2',
        'head_roles':['kOutputNorm','kHeadFn','kHeadScale','kHeadBase'],'head_stage':3,
        'qualification':'Each supplier value must be an actual same-Fragment immutable constant, exact F32 shape and full finite source coefficient extent.',
        'head_geometry':'Six stage HC triples use F32 fn[24,4H],scale[3],base[24]; final head is a separate F32 fn[4,4H],scale[1],base[4].',
        'borrowing':'Model-local runtime owner retains source Data while any borrowed coefficient reference is used. Only original ValueIds compute results; host spans are reference-only.',
        'child_graphs':'Factories are invoked only on the parent Fragment. q_a norm and sink banks travel through ordinary child inputs, then attach remaps all actual values. No external child ValueId is mistaken for a parent identity.'
    },
    'math':[
        'F32 dense fn stays F32 MatMul with original row-major bank transposed as a view; no coefficient conversion to BF16/TF32 is added.',
        'Inverse RMS, explicit scale/base bank slices,20-round Sinkhorn,pre/post gates and actual BF16 pre/post stores remain explicit.',
        'Supplied norm and sink values all enter actual Graph operations; no host literal shadows an unused bank.',
        'Hyper.reference and final-head replay choose independent compensatedF64 dense references against actual supplied coefficients, rather than generated sparse fn weights.',
        'Router bias remains unsupplied; no selected-ID filter, clamp or expert remapping was added.',
        'Default nullptr branch preserves old generated nodes, arithmetic, semantic output order and references; only existing intermediate ValueIds are captured.'
    ],
    'observations':{
        'access':'CompleteProgram.observations optional DraftObservations; visit_values(visitor(ValueId&)) covers137 named fields before optional Copy/dedup by the caller.',
        'stages':'Each records attention/FFN HyperPrePorts and HyperPostPorts,raw/stored attention+FFN norm,actual q_a norm and sink Q/keys/mask/raw/stored.',
        'head':'Separate4-way fn/inverse/mixes/gate/raw/stored collapse and output norm.',
        'lifecycle':'No observation submits a Graph, creates a second executor or changes persistent state. Integration owns explicit caller output Copies and derives physical lease-pool budgets from all actual output extents.'
    },
    'review':'Portable independent source inspection confirmed child input order and diagnostic offsets, stable ordinals through teacher removal, and no changed default math. Found ValueId equality and nested supplied-shadow compile risks were fixed before this freeze.',
    'status':'Frozen for root-owned native validation; no native result is claimed here.'
}
(stage/'freeze.json').write_text(json.dumps(data,indent=2)+'\n',encoding='utf-8')
print(json.dumps(identity(stage/'freeze.json')))
