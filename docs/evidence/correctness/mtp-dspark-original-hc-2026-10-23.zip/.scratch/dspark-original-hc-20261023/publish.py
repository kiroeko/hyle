"""Publish the actual BJ DSpark original-HC/state checks, without weight payloads."""
from pathlib import Path
import hashlib
import json
import re
import xml.etree.ElementTree as ET
import zipfile

S = Path(__file__).resolve().parent
R = S.parents[1]
D = R / 'docs/evidence/correctness'


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def identity(path):
    path = Path(path)
    return dict(path=str(path.relative_to(R)), bytes=path.stat().st_size,
                sha256=hashlib.sha256(path.read_bytes()).hexdigest())


runs = [read(S / f'checks{i}/summary.json') for i in (1, 2)]
cases = []
for i, (run, count) in enumerate(zip(runs, (2, 4)), 1):
    assert run['process']['exit'] == 0 and not run['process']['timed_out']
    assert run['tests'] == count
    assert not any(run[k] for k in ('failures', 'errors', 'disabled', 'skips'))
    tree = ET.parse(S / f'checks{i}/results.xml').getroot()
    assert int(tree.attrib['tests']) == count
    for case in tree.iter('testcase'):
        assert case.attrib['result'] == 'completed'
        assert case.find('failure') is None and case.find('skipped') is None
    cases.extend(run['cases'])
assert len(cases) == len({(c['attributes']['classname'], c['attributes']['name']) for c in cases}) == 6
assert all(c['properties']['actual_submissions'] == '25' for c in cases)
for c in runs[0]['cases']:
    p = c['properties']
    assert p['original_role_count'] == '47' and p['original_role_bytes'] == '2320527260'
    providers = {k: v for k, v in p.items() if k.endswith('_provider')}
    expected = 'ggml-cpu' if c['attributes']['name'].startswith('Cpu') else 'cublasLt'
    assert len(providers) == 7 and set(providers.values()) == {expected}

for name in ('source', 'hooks-source', 'reference-source'):
    freeze = read(S / name / 'freeze.json')
    for row in freeze['files'] if 'files' in freeze else [freeze['file']]:
        path = R / row['path']
        assert path.stat().st_size == row['bytes']
        assert hashlib.sha256(path.read_bytes()).hexdigest() == row['sha256']
compiled = read(S / 'compile1/dspark-state/identity.json')
for row in (compiled['source'], compiled['object'], *compiled['dependencies']):
    path = Path(row['path'])
    assert path.stat().st_size == row['bytes']
    assert hashlib.sha256(path.read_bytes()).hexdigest() == row['sha256']
image = read(S / 'tests-link1/ready.json')['image']
assert identity(Path(image['path']))['sha256'] == image['sha256']

payloads = read(S / 'original-parameters/acquisition.json')
assert payloads['complete'] and payloads['role_payload_bytes'] == 9827740
assert len(payloads['roles']) == 34 and len(payloads['requests']) == 12
assert payloads['successful_request_body_bytes'] == 9827856
for row in payloads['roles']:
    assert identity(R / row['payload']['path']) == row['payload']
tail = (R / 'docs/developer/current-work.md').read_text(encoding='utf-8')
tail = tail[tail.index('## 最新完整性能对比'):]
tail_hash = hashlib.sha256(tail.encode()).hexdigest()
assert tail_hash == read(S / 'start.json')['performance_tail_utf8_sha256']

observations = {}
current = None
for line in (S / 'checks1/stdout.log').read_text(encoding='utf-8').splitlines():
    match = re.match(r'\[ RUN\s+\] (\S+)', line)
    if match:
        current = match.group(1)
        observations[current] = []
    if current and (line.startswith('DSpark original HC ') or
                    line.startswith('DSpark original full-V LM:') or
                    line.startswith('DSpark original confidence F32 dot:')):
        observations[current].append(line)
assert len(observations) == 2 and all(observations.values())
(S / 'numerical-observations.json').write_text(
    json.dumps(observations, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')

source_names = (
    'tests/compute_models/cpu_c4_model_branches.h',
    'tests/compute_models/d5_deepseek_official_attention.h',
    'tests/compute_models/dspark_complete_graph_fixture.h',
    'tests/compute_models/dspark_original_hc_roles.h',
    'tests/compute_models/dspark_original_hc_reference.h',
    'tests/compute_models/dspark_original_state_consumer.h',
    'tests/compute_models/dspark_original_state_consumer_test.cc',
    'tests/compute_models/dspark_original_lm_reference.h',
    'src/compute_provider_cublas/cublas_provider.cc',
    'docs/developer/current-work.md', 'docs/implementation/model-operators.md')
sources = [R / p for p in source_names]
metadata = [R / p for p in (
    '.scratch/large-gguf-head-20261023/review/next-original-suppliers.json',
    '.scratch/qwen-mtp-state-20261023/original-dspark-vocabulary/acquisition.json',
    '.scratch/model-scope-2026-10-19/flash-0731/inference-model.py',
    '.scratch/model-scope-2026-10-19/flash-0731/inference-kernel.py')]
assert all(p.is_file() for p in sources + metadata)
paths = set(sources + metadata)
paths.update(p for p in S.rglob('*') if p.is_file() and p.suffix.lower() in (
    '.h', '.cc', '.py', '.json', '.txt', '.diff', '.log', '.xml', '.ps1'))
paths.discard(S / 'publication.json')
archive = D / 'mtp-dspark-original-hc-2026-10-23.zip'
assert not archive.exists()
with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=7) as z:
    for path in sorted(paths):
        z.write(path, path.relative_to(R).as_posix())

record = dict(date='2026-10-23', stage='BJ', goal_complete=False,
    conclusion='34 original F32 norm/sink/HC parameters now join the existing original11 sidecar and formal BF16 shared vocabulary in the same complete three-stage DSpark accepted-state journey on CPU and CUDA.',
    artifact=dict(original_roles=47, original_payload_bytes=2320527260,
        sidecar_original_roles=45, sidecar_total_roles=81, additional_formal_vocabulary_roles=2,
        acquisition=payloads, original_payloads_archived=False,
        byte_scope='Checkpoint payload extents only, not a physical memory or VRAM measurement.'),
    implementation=dict(
        bank_lifetime='Original F32 coefficients uploaded once through existing readonly StorageOwner/ReadLease; shared immutable host source remains alive for graph assembly and local checks. Full BF16 embedding/head reused without a dense F32 weight shadow.',
        mathematics='Six stage HC matrices retain24 outputs with original3 scales/24 bases and20 Sinkhorn iterations. Final head independently retains4 projections/one scale/four bases. Learned attention/FFN/query/output RMS and per-head sinks use original F32 values.',
        state='Same25-Graph journey per case: encoded main-ring bootstrap, complete three-stage draft, accepted prefixes0/1/2, wrap, independent nominated-Head continuation, rejection/cancellation/stale publication, retained results and collection. Proposal KV remains temporary.',
        observations='137 logical observation fields deduplicate to materialized semantic outputs or independent Copy outputs;133 additional boundary outputs in each new case. No caller-bound required View and no host oracle re-upload.',
        product='No new public API, executor, provider or dispatcher. Existing public Graph, immutable constant, resource and state mechanisms are reused.'),
    validation=dict(unique_tests=6, failures=0, errors=0, skips=0,
        model_graph_submissions=150, new_original_model_graph_submissions=50,
        related_regression_graph_submissions=100, cases=cases,
        precision='Actual CompileReport identifies all seven CPU fn MatMuls as ggml-cpu and all seven CUDA fn MatMuls as cublasLt. Public F32 operands/accumulation are checked; linked Hyle cuBLAS implementation selects CUBLAS_COMPUTE_32F_PEDANTIC for actual F32 operands. Original coefficients are not narrowed to BF16/TF32.',
        numerical='Every episode uses independent compensated F64 dots from actual BF16-representable inputs and original F32 coefficients, with separate F32 multiplication/reduction and F64-oracle bounds. Actual inverseRMS/mix/gates/Sinkhorn/pre/post/head and sink attention are checked locally; actual F32-to-BF16 stores checked exactly. Original full-V LM,4352-term confidence,embedding/greedy and Markov checks retained; generated gates unchanged.',
        numerical_observations=observations,
        commands_and_results=[identity(S / f'checks{i}/summary.json') for i in (1, 2)],
        compiled_host_translation_units=1, SDK_builds=0, native_CPU_builds=0,
        NVCC_builds=0, shaders=0, first_native_run_failures=0),
    source_reviews=[identity(S / p) for p in (
        'source/freeze.json', 'hooks-source/freeze.json', 'reference-source/freeze.json',
        'review/dspark-hc-hooks-independent.json', 'review/hc-reference-cross-review.json',
        'review/dspark-original-hc-state-independent.json', 'review/original-f32-payload-stats.json')],
    remaining_original_roles=read(S / 'review/remaining-original-roles.json'),
    limitations=['WindowsCPU/CUDA only; no new Linux/Apple/Vulkan model run.',
        'Remaining36 sidecar roles, other attention/MoE coefficients, target captures and verifier are not a complete trained model. No full original target/stages, Pro geometry, primaryUD-Q4 vocabulary, natural acceptance or full generation quality claim.',
        'Original router/bias requires actual selected expert IDs resident; never filter IDs to fit generated smallbanks. GGUF MXFP4 expert weights with Q8_1 activation are not numerically equivalent to official FP4/E4-A128.',
        'No new TPS, loading or physical memory/VRAM peak measurement. Latest AV performance table retained.',
        'Full MTP and broader architecture/performance/image goal remain incomplete.'],
    next='Remaining actual roles/sharedLM/targettap/Pro/confirmedquant work, then necessary final ordinary/MTP performance comparison before image chain.',
    final_image=image, sources=[identity(p) for p in sources],
    performance_tail_sha256=tail_hash,
    cleanup='One new executable/map and one host object retained for replay and subsequent incremental linking; no superseded BJ image, whole shard or SDK copy was produced. No deletion required.',
    archive=identity(archive), archive_items=len(paths))
out = D / 'mtp-dspark-original-hc-2026-10-23.json'
assert not out.exists()
out.write_text(json.dumps(record, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
(S / 'publication.json').write_text(json.dumps(dict(evidence=identity(out), archive=identity(archive)),
    ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps(dict(evidence=identity(out), archive=identity(archive), tests=6, graphs=150), ensure_ascii=False))
