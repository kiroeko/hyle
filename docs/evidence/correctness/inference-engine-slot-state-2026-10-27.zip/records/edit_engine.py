from pathlib import Path

root = Path(__file__).resolve().parents[2]
path = root / 'engine/models/qwen35/main.cc'
text = path.read_bytes().decode().replace('\r\n', '\n')

def replace(old, new):
    global text
    assert text.count(old) == 1, old[:160]
    text = text.replace(old, new)

def region(begin, end, new):
    global text
    assert text.count(begin) == 1, begin
    start = text.index(begin)
    finish = text.index(end, start)
    text = text[:start] + new + text[finish:]

replace('#include "hyle/graph/batch.h"', '#include "hyle/graph/batch.h"\n#include "hyle/graph/slots.h"')
region('struct StatePorts final {', 'struct FamilyPorts {', '''struct StatePorts final {
  V pool, source_ids, destination_ids;
  g::NodeId gather, store;
};
struct Ports final {
  V key, value;
  StatePorts history, recurrent;
};
''')
replace('  std::vector<g::NodeId> attention_nodes, append_nodes;', '''  std::vector<g::NodeId> attention_nodes, append_nodes;
  std::vector<g::slots::SourceBinding> state_sources;''')
replace('  g::CompiledGraph compiled; // One immutable selected child shared by every session.', '''  g::CompiledGraph compiled; // One immutable selected child shared by every session.
  // Only needed when the original symbolic graph cannot describe a state row.
  // This is cold metadata with the same IDs, never another executable.
  g::Graph state_graph;''')
replace('struct Phase final : FamilyPorts {', '''struct StateBinding final {
  std::size_t layer = 0;
  bool recurrent = false;
  g::slots::SlotBindings transaction;
  std::vector<c::ReadLease> sources;
  std::vector<c::WriteLease> destinations;
};
struct Phase final : FamilyPorts {''')
replace('  std::array<g::Invocation, execution_slot_count> slots;', '''  std::array<g::Invocation, execution_slot_count> slots;
  std::array<std::vector<StateBinding>, execution_slot_count> state_bindings;
  std::array<std::vector<g::slots::BindRequest>, execution_slot_count> state_requests;
  const g::Graph &state_graph() const noexcept {
    return child->state_graph.valid() ? child->state_graph : family->graph;
  }''')
replace('  bool prepared = false, submitted = false, cancelled = false;', '''  bool prepared = false, submitted = false, cancelled = false;
  std::size_t state_slot = 0;
  bool states_bound = false;''')
replace('      *run = {}; // Release failed state-output writers and old input bindings.', '''      // One batch bind transfers every state transaction together. A partial
      // take on recovery is remembered by the valid caller-owned metadata.
      if (phase) for (std::size_t i = 0; i < phase->state_bindings[state_slot].size(); ++i) {
        auto &bank = phase->state_bindings[state_slot][i];
        if (states_bound && !bank.transaction.valid()) {
          auto recovered = g::slots::take(*run, phase->state_sources[i].store);
          if (!recovered) {
            if (recovered.error().IsUnavailable()) return false;
            return std::unexpected(recovered.error());
          }
          bank.transaction = std::move(*recovered);
        }
        bank.transaction.clear();
        for (auto &source : bank.sources) source = {};
        for (auto &writer : bank.destinations) writer = {};
      }
      states_bound = false;
      *run = {}; // Release failed ordinary outputs and their original bindings.''')
replace('  std::vector<bool> history_writers, recurrent_writers;\n', '')
replace('         history_writers(geometry.layers.size(), false), recurrent_writers(geometry.layers.size(), false),\n', '')
replace('''      const auto history_slots = history_writers[i] ? cache_plan.state_slots : initial_slots;
      const auto recurrent_slots = recurrent_writers[i] ? cache_plan.state_slots : initial_slots;''', '''      const auto history_slots = cache_plan.state_slots;
      const auto recurrent_slots = cache_plan.state_slots;''')
replace('''      check(pools.history_reuse.prepare(history_writers[i] ? cache_plan.active_sequences : 0,
          take(description.history.required_bytes())));
      check(pools.recurrent_reuse.prepare(recurrent_writers[i] ? cache_plan.active_sequences : 0,
          take(description.recurrent.required_bytes())));''', '''      const auto history_payload = take(description.history.required_bytes());
      const auto recurrent_payload = take(description.recurrent.required_bytes());
      pools.history_layout = take(c::LeaseSlotLayout::create(pools.history, description.history,
          history_slots, cache::add(history_payload, cache::state_pool_padding(history_payload))));
      pools.recurrent_layout = take(c::LeaseSlotLayout::create(pools.recurrent, description.recurrent,
          recurrent_slots, cache::add(recurrent_payload, cache::state_pool_padding(recurrent_payload))));
      check(pools.history_reuse.prepare(cache_plan.active_sequences, history_payload));
      check(pools.recurrent_reuse.prepare(cache_plan.active_sequences, recurrent_payload));''')
replace('''    // Generated results keep their original native owners. These pools cover
    // actual initial zero inputs, and only selected caller-written outputs.''', '''    // History and recurrence always use the original versioned state pools.
    // Hidden results keep their actual caller/generated output contract.''')

# Replace the per-session state inputs and history copies with ordinary
# provider-independent Gather/math/Store. The Store descriptor is geometry only.
region('''        ports.sequences.resize(requests);''', '''        auto qkv = r.reshape''', '''        const auto state_port = [&](StatePorts &port, const c::TensorDesc &item) {
          const auto bytes = take(item.required_bytes());
          const auto schema = take(g::slots::Schema::create(item, cache_plan.state_slots,
              cache::add(bytes, cache::state_pool_padding(bytes))));
          port.pool = r.input(take(schema.capacity_description()));
          port.source_ids = r.input(dense(Type::kInt32, {static_cast<std::int64_t>(requests)}));
          port.destination_ids = r.input(dense(Type::kInt32,
              {static_cast<std::int64_t>(cache::multiply(requests, prefix_rows))}));
          auto rows = r.one(c::Gather{.axis = 0, .bounds = c::IndexBoundsPolicy::kChecked},
              {port.pool, port.source_ids}, r.dense_spec(item.data_type(),
                  {batch, f(schema.item_elements())}), &port.gather);
          return std::pair{schema, rows};
        };
        const auto [history_schema, history_rows] = state_port(ports.history, state_schema[i].history);
        const auto [recurrent_schema, recurrent_rows] = state_port(ports.recurrent, state_schema[i].recurrent);
        const auto history = r.reshape(history_rows,
            {batch, f(geometry.conv_kernel - 1), f(geometry.gdn_qkv_width())});
        const auto state = r.reshape(recurrent_rows,
            {batch, f(geometry.gdn_value_heads), f(geometry.gdn_key_depth), f(geometry.gdn_value_depth)});
        const auto store_state = [&](StatePorts &port, const g::slots::Schema &schema, V rows) {
          r.op(c::Operation::custom(g::slots::Store{schema}), {rows, port.destination_ids}, {}, &port.store);
          if (has_prior_append) check(r.builder.depends_on(port.store, prior_append));
          prior_append = port.store; has_prior_append = true;
          definition.state_sources.push_back({port.store, port.gather});
        };
''')
region('''        // Every published state has independent per-session material storage.''', '''        auto convolution = r.one''', '''        // K1 records the final boundary; current K>1 families have T==K.
        // The ordinary graph stores raw history before Cast F32. A single
        // window may have a batch gap and therefore needs real materialization.
        std::vector<V> windows;
        windows.reserve(prefix_rows);
        for (std::size_t row = 0; row < prefix_rows; ++row) {
          const auto boundary = prefix_rows == 1 ? t : f(static_cast<std::int64_t>(row + 1));
          auto window = r.slice(samples, 1, boundary, f(geometry.conv_kernel - 1));
          if (prefix_rows == 1) window = r.one(c::Copy{}, {window},
              r.dense_spec(precision.activation_type(),
                  {batch, f(geometry.conv_kernel - 1), f(geometry.gdn_qkv_width())}));
          else window = r.reshape(window,
              {batch, f(1), f(geometry.conv_kernel - 1), f(geometry.gdn_qkv_width())});
          windows.push_back(window);
        }
        const auto histories = prefix_rows == 1 ? windows[0] : r.concat(windows, 1,
            r.dense_spec(precision.activation_type(), {batch, f(static_cast<std::int64_t>(prefix_rows)),
                f(geometry.conv_kernel - 1), f(geometry.gdn_qkv_width())}));
        store_state(ports.history, history_schema, r.reshape(histories,
            {f(static_cast<std::int64_t>(requests * prefix_rows)), f(history_schema.item_elements())}));
''')
region('''        for (std::size_t request = 0; request < requests; ++request) {
          if (prefix_rows > 1) {
            auto per_request = r.slice(recurrent[1]''', '''        auto y = r.cast(recurrent[0]''', '''        store_state(ports.recurrent, recurrent_schema, r.reshape(recurrent[1],
            {f(static_cast<std::int64_t>(requests * prefix_rows)), f(recurrent_schema.item_elements())}));
''')
region('''        for (const auto &sequence : ports.sequences) {''', '''      } else {
        const auto layer = geometry.attention_slot(i);''', '')

# The original symbol graph often already gives fixed state row metadata.
# Specialize only if an actual queried row description is unresolved.
region('''      for (std::size_t layer = 0; layer < state_schema.size(); ++layer) if (geometry.is_gdn(layer))
        for (const auto &ports : definition.layers[layer].sequences) {''', '''      for (const auto &ports : definition.carry_ports)''', '''      bool concrete_states = true;
      for (const auto &association : definition.state_sources) {
        for (const auto value : {take(definition.graph.node_input(association.gather, 0)),
                 take(definition.graph.node_input(association.gather, 1)),
                 take(definition.graph.result(association.gather, 0)),
                 take(definition.graph.node_input(association.store, 0)),
                 take(definition.graph.node_input(association.store, 1))})
          concrete_states = concrete_states && definition.graph.value_description(value).has_value();
      }
      if (!concrete_states) {
        auto specialized = take(g::specialize_exact(definition.graph, bindings[index]));
        if (specialized.signature != child->compiled.executable.specialization())
          throw std::runtime_error("state graph specialization differs from its selected child");
        child->state_graph = std::move(specialized.graph);
      }
''')
replace('    const auto before_history = history_writers, before_recurrent = recurrent_writers;\n', '')
region('''      for (std::size_t i = 0; i < state_schema.size(); ++i)
        if ((!before_history[i]''', '''      if (!before_hidden && hidden_writers)''', '')
replace('''      families.erase(key); history_writers = before_history; recurrent_writers = before_recurrent;''', '''      families.erase(key);''')

# Prepare stable controls once and keep per-bank scratch with the original Phase.
replace('''    // Cold preparation can also run without a pending StepState.''', '''    if (!phase.state_sources.empty())
      check(g::slots::prepare(run, phase.state_graph(), inference::queue_span(phase.queues), phase.state_sources,
          {.host_workspace = execution.staging(), .resource_budget = execution_budget ? execution_budget : cache_budget}));
    // Cold preparation can also run without a pending StepState.''')
replace('''    phase.family = &definition; phase.variant_index = index;''', '''    phase.family = &definition; phase.variant_index = index;
    for (std::size_t slot = 0; slot < execution_slot_count; ++slot) {
      auto &banks = phase.state_bindings[slot];
      banks.reserve(phase.state_sources.size());
      for (std::size_t layer = 0; layer < state_schema.size(); ++layer) if (geometry.is_gdn(layer))
        for (const bool recurrent : {false, true}) {
          StateBinding bank{.layer = layer, .recurrent = recurrent};
          bank.sources.resize(requests);
          bank.destinations.resize(cache::multiply(requests, phase.prefix_rows));
          banks.push_back(std::move(bank));
        }
      phase.state_requests[slot].resize(banks.size());
      for (std::size_t bank = 0; bank < banks.size(); ++bank)
        phase.state_requests[slot][bank] = {phase.state_sources[bank].store, &banks[bank].transaction};
    }''')
replace('''      step.phase = &phase; step.run = &run; step.nodes.assign''', '''      step.phase = &phase; step.run = &run; step.state_slot = slot; step.nodes.assign''')
region('''      for (std::size_t i = 0; i < state_schema.size(); ++i) if (geometry.is_gdn(i))
        for (std::size_t j = 0; j < width; ++j) {
          const auto &ports = phase.layers[i].sequences[j];''', '''      auto &fixed_output = phase.hidden_output[slot];''', '''      for (auto &bank : phase.state_bindings[slot]) {
        auto &pools = state_pools[bank.layer];
        const auto &description = bank.recurrent ? state_schema[bank.layer].recurrent : state_schema[bank.layer].history;
        const auto bytes = take(description.required_bytes());
        for (std::size_t j = 0; j < width; ++j) {
          const auto &state = step.members[j].base->state[bank.layer];
          bank.sources[j] = bank.recurrent ? state.recurrent : state.history;
        }
        for (auto &writer : bank.destinations)
          writer = take(bank.recurrent ? pools.acquire_recurrent(bytes) : pools.acquire_history(bytes));
        if (bank.transaction.valid()) check(bank.transaction.refill(bank.sources, bank.destinations));
        else bank.transaction = take(g::slots::SlotBindings::create(
            bank.recurrent ? pools.recurrent_layout : pools.history_layout,
            bank.sources, bank.destinations, {.resource_budget = cache_budget}));
        // The transaction now owns these source guards. Do not keep a second
        // Phase reader that would block old-head recovery after take/clear.
        for (auto &source : bank.sources) source = {};
      }
''')
replace('''      const auto batch_end = Clock::now();''', '''      check(g::slots::bind(run, phase.state_graph(), phase.state_requests[slot]));
      step.states_bound = !phase.state_sources.empty();
      const auto batch_end = Clock::now();''')
region('''      for (std::size_t i = 0; i < state_schema.size(); ++i) if (geometry.is_gdn(i))
        for (std::size_t j = 0; j < outputs.size(); ++j) {
          const auto &ports = phase.layers[i].sequences[j];''', '''      copy_selected_hidden_outputs(step);''', '')
replace('''      const auto append_banks = draft_bank + (has_mtp(phase.family->role) ? 2u : 0u);''', '''      // Every ordinary output above must be retained before the first take
      // revokes output-ready. Each bank retains its independent true pool IDs.
      for (std::size_t bank_index = 0; bank_index < phase.state_bindings[step.state_slot].size(); ++bank_index) {
        auto &bank = phase.state_bindings[step.state_slot][bank_index];
        bank.transaction = take(g::slots::take(run, phase.state_sources[bank_index].store));
        for (std::size_t j = 0; j < outputs.size(); ++j) {
          const auto selected = j * phase.prefix_rows + step.members[j].accepted_tokens - 1;
          auto ready = take(bank.transaction.destinations()[selected].publish());
          auto &state = step.members[j].next->state[bank.layer];
          (bank.recurrent ? state.recurrent : state.history) = std::move(ready);
        }
        // Release old source guards before the joint head-commit recycle hook.
        // Unaccepted MTP candidates are discarded, never made visible.
        bank.transaction.clear();
      }
      step.states_bound = false;
      const auto append_banks = draft_bank + (has_mtp(phase.family->role) ? 2u : 0u);''')

assert 'history_prefix' not in text and 'recurrent_prefix' not in text
assert 'history_writers' not in text and 'recurrent_writers' not in text
assert '.sequences' not in text
path.write_bytes(text.replace('\n', '\r\n').encode())
print('updated', path)
