"""Run one explicitly selected tiny CLI case; correctness observations only."""
from pathlib import Path
import importlib.util
import json
import re
import sys
import traceback

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = W.parents[1]
spec = importlib.util.spec_from_file_location('retained_batch_recipe', R / '.scratch/inference-batched-slot-controls-20261027/build.py')
old = importlib.util.module_from_spec(spec)
spec.loader.exec_module(old)
b, _ = old.helpers()


def main(name, label=None):
    assert name in ['ordinary', 'mtp-k2']
    ready = b.read(W / 'formal2-ready.json')
    b.exact(ready['image'])
    selected = next(row for row in b.read(W / 'run-commands.json') if row['name'] == 'cuda-cli-' + name)
    command = list(selected['argv'])
    command[0] = ready['image']['path']
    if name == 'ordinary':
        index = command.index('--mtp-max-drafts')
        del command[index:index + 2]
    label = label or name
    assert label in ['ordinary', 'ordinary2', 'mtp-k2']
    out = W / 'runs' / label
    assert not out.exists(), 'Preserve original run; no automatic retry'
    helper = b.helper()
    cl = b.read(W / 'recipes2/formal.json')['command'][0]
    env = helper.discover_environment(compiler='msvc', cache={
        'CMAKE_C_COMPILER': cl, 'CMAKE_CXX_COMPILER': cl, 'CMAKE_GENERATOR': 'Ninja'}, backends=()).env
    env['PATH'] = b.read(ready['runtime']['path'])['PATH']
    env['HF_HUB_OFFLINE'] = env['TRANSFORMERS_OFFLINE'] = '1'
    process = helper.execute(command, env, out, timeout=90)
    report = json.loads((out / 'stdout.log').read_text(encoding='utf-8-sig'))
    b.save(out / 'report.json', report)
    assert report['backend'] == 'cuda' and report['generated_tokens'] == 8
    assert report['live_committed_versions'] == 0
    assert report['admitted_requests'] == report['retired_requests'] == 1
    assert report['session_count'] == 1 and len(report['sessions']) == 1
    result = report['sessions'][0]['result']
    assert len(result['generated_ids']) == result['generated_tokens'] == 8
    assert bool(report['mtp']) == (name == 'mtp-k2')
    stderr = (out / 'stderr.log').read_text(encoding='utf-8-sig')
    lines = [line for line in stderr.splitlines() if re.search(r'plan|route|provider|slot|retir', line, re.I)]
    (out / 'observable-plan-lines.txt').write_bytes(('\n'.join(lines) + '\n').encode('utf-8'))
    b.save(out / 'facts.json', dict(status='PASS_FINITE_TINY_CLI', mode=name, process=process,
        image=ready['image'], source=ready['source'], report=b.pin(out / 'report.json'),
        generated_ids=result['generated_ids'], generated_tokens=report['generated_tokens'],
        live_committed_versions=report['live_committed_versions'],
        admitted_requests=report['admitted_requests'], retired_requests=report['retired_requests'],
        final_visible_tokens=result['visible_tokens'],
        draft_frontier=result.get('draft_frontier'), draft_lag=result.get('draft_lag'),
        cache={key: value for key, value in report.items() if key.startswith('cache_')},
        native_execution_private_bytes_unknown=report.get('native_execution_private_bytes_unknown'),
        route6=None, route7=None,
        routing_observation='Complete original JSON report and stderr retained. These CLI fields show logical batch roles and replay, not selected region implementation IDs; route6/7 and callback specialization cannot be inferred from success.',
        observable_plan_lines=b.pin(out / 'observable-plan-lines.txt'),
        resource_observation='All admitted requests retired and committed versions reached zero. cache_live_requested_bytes includes persistent Model backing and is not asserted to be zero; the CLI does not expose a post-Model-destruction allocator total.',
        scope='Tiny functional CLI exercise only; no benchmark, quality or memory-performance conclusion.'))
    print('PASS', name, json.dumps(b.pin(out / 'facts.json')), flush=True)


if __name__ == '__main__':
    try:
        main(sys.argv[1], sys.argv[2] if len(sys.argv) == 3 else None)
    except Exception:
        b.save(W / ('run-' + (sys.argv[2] if len(sys.argv) == 3 else sys.argv[1]) + '-failure.json'), dict(error=traceback.format_exc(),
            note='Stopped with original stdout/stderr/process/report retained; no retry.'))
        raise
