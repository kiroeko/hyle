# 原池状态迁移第二轮只读审查

2026-10-27；未改产品、未构建、未运行。
`main.cc` SHA256 `3b1a2c6996a8c7a3cd3c654526abd1bbb9a033a0a809e68ff6063ede8b61812f`；
`session_state.h` SHA256 `e393af9522901f73bab16801054e7c4761ca836f87b15003902f6b7c279ce2bd`。

未发现新的确定 bug。此前 K1 多 token prefill 选错 writer、默认纯 CUDA control payload 误入 cache
budget 两项已修。以下是源码事实，不是未运行的数值或性能通过结论。

- **B>1 / K1**：原 history Gather 是 `[B,E]`；拼 samples `[B,L+T,C]` 后按 axis1 取 start=T、count=L。
  单窗口的 batch 间隔由明确 Copy 物化成 `[B,L,C]`，再 flatten `[B,E]`。源/目标各自按实际 pool 坐标，
  新 finish 对非 verify 选择 `b*K+0`，没有把 T 当成 K；recurrent 也按同 batch 顺序 flatten。
- **MTP K>1**：当前 verify / round 的 target T==K；窗口 row+1 对应同宽完整前缀，Concat axis1 的
  `[B,K,L,C]` 和 GDN `[B,K,H,S,S]` 均按 `b*K+c` flatten。finish 仅 verify 类取 accepted_tokens-1，
  旧输入与未接受候选仍不发布。
- **失败**：prepare 中途 create/refill/分配失败时 states_bound=false，caller metadata/writer scratch
  均由 try_abort 清理。batch bind 成功后才置 states_bound。部分 take 后已取回的 metadata valid，
  clear 保留 valid，故 abort 只补取仍 invalid 的 bank，不会 double take。Unavailable 保留原 episode。
- **成功顺序**：先观察整图成功、读取/保留 ordinary outputs，再 take_appends 保留其成功见证，
  然后 take slots。选中 writer publish 到未提交 candidate，clear 解除原 source refs，之后才进入原
  expected-base/epoch、Frame preflight 和联合 head.commit；任一前置失败仍沿原 abort 回收 candidate。
- **旧状态**：source 是原 committed ReadLease；dest 来自同一 bank 原 pool 的独占 writer。共同
  LeaseSlotLayout 复核 exact block/domain/generation 与 source/write 模式，不能把 source slot 冒充 dest。
  每 bank 两个池与独立 IDs 不合并；不可把 capacity TensorView 当全池初始化权限。源码未见原 snapshot
  字节被写回的路径；真实 bytes 不变仍由有限消费者检查。
- **预算**：execution budget 现在覆盖真实 device/staging/system（含默认纯 CUDA），controls 进执行域；
  原 history/GDN pool 全部按 N+R*K 分配，256B stride/padding 与布局 extent 一致，归 cache payload。
  SlotBindings metadata 仍归 cache 的 Metadata 类，clear 保留该收费，cache backing 对比会排除 metadata。
  有限 cache limit 仍须容纳实际 metadata；真实预算不足是接纳失败，不是扩大已承诺状态容量的理由。
- **具体描述**：当前先查询所需五处值，只对 FailedPrecondition 走 optional specialize_exact，其它错误传播；
  特化 allocator 已用 execution budget。没有因 family 含 symbolic T 就强制每 child 克隆整图。

## 最小 CUDA route6/7 观察方法（测试侧，尚未执行）

现 `CompileStepReport` 已公开 kind、provider、provider_instance、target/lane、implementation、policy、
dispatch_count、copy_bytes、node_count；`CompileReport::step_node(step,n)` 给出真实原 Graph NodeId。
`node_begin/count` 对非连续 region 不足以还原节点集合。

在既有测试消费者的 `prepare_evaluations` 之后，或其正常 select 回调中读取
`step.phase->child->compiled.report`，无需取 outputs、改图、take 或提交第二份图：

1. 按 `phase.state_bindings[state_slot]` 的 layer/recurrent 找对应 StatePorts（history 或 recurrent）。
2. 用 **完整 NodeId 相等**在 `report.step_node` 中找包含该原 Store 的唯一 emitted step；同时核其包含
   同 bank 原 Gather。不要用 native local index 或假定节点连续。
3. 对已知本机支持的 CUDA shape，GDN 应为 policy `{0x48594c4547474355,6,1}` / implementation 7；
   conv 应为同 namespace policy7/version1 / implementation8；两者均 kind=kProviderRegion、dispatch_count=1。
   同时打印实际 provider、target/lane、完整 node 集合、policy 三元组和 fallback_reason。逐层报告 miss，
   不以某一层命中代签全模型。Conv 的节点数随 K/实际 Copy/View 改变，不能套用最小 fixture 的固定节点总数。
4. 和该同一 Phase 原 Invocation 的正常 submit/completion 成功关联，才是“该消费者执行了此已选路线”；
   冷 report 单独只能证明已选择，不能证明速度。原 route.tsv 目前未写 policy/dispatch，不能仅凭 kernel
   总数或 provider 名称当融合命中证据。

没有 `CompileStepReport::preserves_effects` 字段，测试不要编造该查询。Store 的外部 effect 保留由既有
编译合同与实际写值/权限消费者验证；这里仅复用现 report 观察选择，不新增产品 diagnostic API。
