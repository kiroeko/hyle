"""One authorized frozen CUDA Model TU and one formal CLI link; no run."""
from pathlib import Path
import importlib.util
import json
import os
import sys
import traceback

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = W.parents[1]
spec = importlib.util.spec_from_file_location('retained_batch_recipe', R / '.scratch/inference-batched-slot-controls-20261027/build.py')
old = importlib.util.module_from_spec(spec)
spec.loader.exec_module(old)
b, m = old.helpers()


def main():
    assert not (W / 'formal-freeze.json').exists() and not (W / 'formal-ready.json').exists()
    p = b.read(W / 'plan.json')
    unit = next(row for row in p['units'] if row['name'] == 'formal-cuda')
    artifact = next(row for row in p['CUDA']['artifacts'] if row['name'] == 'formal-cuda')
    source = R / 'engine/models/qwen35/main.cc'
    state = R / 'engine/models/qwen35/session_state.h'
    assert b.pin(source)['sha256'] == '4730fdfcf38271c811b608161450e0929c88304b395c11d60dde96e33b40d8c0'
    assert b.pin(state)['sha256'] == 'e393af9522901f73bab16801054e7c4761ca836f87b15003902f6b7c279ce2bd'
    frozen = m.c.closure([source], [unit['command_template']['path']])
    b.save(W / 'formal-source-freeze.json', frozen)
    snapshot = []
    for path in [source, state]:
        target = W / 'formal-source' / path.relative_to(R)
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(path.read_bytes())
        snapshot.append(b.pin(target))
    own = {b.key(row['path']): row for row in frozen}
    reused = artifact['reused_engine_objects']
    deps = [R / '.scratch/inference-reusable-state-20261026/cuda2/compile/weights/actual-dependencies.json',
            R / '.scratch/inference-review-fixes-20261026/product2/report/actual-dependencies.json',
            R / '.scratch/inference-current-closure-20261026/engine/entry/actual-dependencies.json']
    b.save(W / 'formal-freeze.json', dict(source=b.pin(source), state_header=b.pin(state), snapshots=snapshot,
        source_freeze=b.pin(W / 'formal-source-freeze.json'), prepared_plan=b.pin(W / 'plan.json'),
        unit=unit, artifact=artifact, reused_engine_actual_dependencies=[b.pin(path) for path in deps],
        reuse_review='weights source/header and Backend header match the actual cached dependency hashes. weights parses session_state but does not use StatePools; its cache::add/KvRowBytes interfaces are unchanged. Report/entry do not include session_state. Reuse is limited to these original macro-compatible CUDA objects.',
        known_unrun_issue='Root identified missing pure-CUDA execution-budget registration for slot staging; this frozen compile is intentionally not run and will precede the narrow budget source correction.'))
    helper = b.helper()
    command = b.read(unit['command_template']['path'])['command']
    cl = command[0]
    env = helper.discover_environment(compiler='msvc', cache={
        'CMAKE_C_COMPILER': cl, 'CMAKE_CXX_COMPILER': cl, 'CMAKE_GENERATOR': 'Ninja'}, backends=()).env
    out = W / 'compile/formal-cuda'
    process = helper.execute(command, env, out, timeout=180)
    raw = b.read(out / 'dependencies.json')['Data']
    actual = [b.pin(path) for path in dict.fromkeys([raw['Source'], *raw['Includes']])]
    b.save(out / 'actual-dependencies.json', actual)
    for row in actual:
        path = Path(row['path'])
        if path.is_relative_to(R) and not path.is_relative_to(R / '.scratch'):
            assert own[b.key(path)]['sha256'] == row['sha256'], str(path)
    for row in frozen:
        b.exact(row)
    image = Path(artifact['image'])
    image.parent.mkdir(parents=True, exist_ok=True)
    retained = b.read(artifact['retained_inputs']['path'])
    assert len(retained) == 223
    for row in retained:
        b.exact(row)
    linked = helper.execute(b.read(artifact['link_template']['path'])['command'], env, W / 'formal-link', timeout=120)
    inputs = retained + [b.pin(out / 'unit.obj')]
    b.save(W / 'formal-link-inputs.json', inputs)
    runtime = b.read(artifact['runtime']['path'])
    native = runtime['native_cpu']
    b.exact(native)
    alias = image.parent / Path(native['path']).name
    os.link(native['path'], alias)
    runtime['native_cpu_hardlink'] = b.pin(alias)
    runtime['PATH'] = str(image.parent) + ';' + runtime['PATH']
    b.save(W / 'formal-runtime.json', runtime)
    b.save(W / 'formal-ready.json', dict(status='BUILT_INTENTIONALLY_NOT_RUN', image=b.pin(image),
        object=b.pin(out / 'unit.obj'), source=b.pin(source), process=process, link=linked,
        actual_dependencies=b.pin(out / 'actual-dependencies.json'), frozen=b.pin(W / 'formal-freeze.json'),
        inputs=b.pin(W / 'formal-link-inputs.json'), runtime=b.pin(W / 'formal-runtime.json'),
        counts=dict(CXX_TUs=1, links=1, images=1, model_runs=0, SDK=0, NVCC=0, downloads=0)))
    print('READY', json.dumps(b.pin(W / 'formal-ready.json')), flush=True)


if __name__ == '__main__':
    try:
        main()
    except Exception:
        b.save(W / 'formal-failure.json', dict(error=traceback.format_exc(), note='Stopped with original source/command/process/logs retained. No retry.'))
        raise
