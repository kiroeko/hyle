"""Archive only this state migration's sources, recipes, and useful finite results."""
from pathlib import Path
import hashlib
import json
import zipfile

W = Path(__file__).resolve().parent
R = W.parents[1]
D = R / 'docs/evidence/correctness'
NAME = 'inference-engine-slot-state-2026-10-27'


def read(p):
    return json.loads(Path(p).read_text(encoding='utf-8-sig'))


def pin(p):
    p = Path(p)
    data = p.read_bytes()
    return dict(path=str(p), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())


def save(p, value):
    Path(p).write_bytes((json.dumps(value, ensure_ascii=False, indent=2) + '\n').encode('utf-8'))


def main():
    tiny = [read(W / 'runs' / x / 'facts.json') for x in ['ordinary3', 'mtp-k2']]
    mixed = read(W / 'mixed/run-summary.json')
    prefix = read(W / 'prefix-value/run-summary.json')
    sources = [R / x for x in ['engine/models/qwen35/main.cc', 'engine/models/qwen35/session_state.h',
        'tests/tools/qwen_state_reuse_case.h', 'tests/tools/qwen_mtp_prefix_value_probe.cc']]
    evidence = dict(date='2026-10-27', platform='Windows CPU/CUDA',
        status='FINITE_ORIGINAL_POOL_ENGINE_CHECKS', source_base='25f46af43', sources=list(map(pin, sources)),
        implementation=[
            'Original history/recurrent LeasePools, independent LeaseSlotLayouts and real generations; no additional state backing inventory.',
            'Ordinary mathematical Gather/Concat/Copy/Cast/Conv/GDN and external Store effects. Provider selection remains cold and model independent.',
            'One complete original slot-binding cohort per invocation; reusable transaction metadata, independent source/destination IDs per bank.',
            'K1 final boundary and batch-major B*K MTP accepted-prefix selection. Whole-Graph success before append take, slot take proves retirement only.',
            'Original failure, pending/RNG, immutable checkpoint and no-fail joint head publication remain authoritative.',
            'Execution controls use the actual execution resource budget; state payload remains in original cache backing accounting.'],
        tiny=tiny, mixed=mixed, original_complete_model_prefix=prefix,
        work=dict(CXX_attempts=6, distinct_TU_configurations=4, links=4, images=4,
            formal_CXX_attempts=3, mixed_CXX_attempts=2, prefix_CXX_attempts=1,
            SDK_builds=0, NVCC_compiles=0, shader_compiles=0, downloads=0),
        preserved_failures=[
            'Initial compile overlapped a source edit; consistency unproven. Never linked or run.',
            'Initial ordinary command retained MTP-only arguments; parser rejection before model execution.',
            'Formal2 ordinary reached the original append success guard after slot take revoked output-ready. Fixed take order; formal3 is separately frozen and built.'],
        limitations=[
            'Finite functional checks; no complete model quality, universal hardware, native driver fault injection or general-serving claim.',
            'Cold plan counts are selected artifacts; not profiler measurements or speed evidence.',
            'Vulkan non-4-byte row/pitch and Apple/Linux current engine paths were not newly run here.',
            'Current whole-4-byte Vulkan raw I32-word selected-row lowering exists; BF16/F16 storage alone is not a blanket blocker.',
            'Persistent Model cache backing remains allocated after requests retire; zero committed versions is not allocator-zero or VRAM release.'])
    evidence['cleanup'] = read(W / 'cleanup-result.json')
    payload = {}
    allowed = {'.py', '.json', '.log', '.rsp', '.txt', '.cc', '.h', '.md', '.ps1'}
    for p in W.rglob('*'):
        if p.is_file() and p.suffix.lower() in allowed and 'performance' not in p.relative_to(W).parts:
            payload['records/' + p.relative_to(W).as_posix()] = p.read_bytes()
    for p in sources:
        payload['source/' + p.relative_to(R).as_posix()] = p.read_bytes()
    manifest = {k: dict(bytes=len(v), sha256=hashlib.sha256(v).hexdigest()) for k, v in payload.items()}
    payload['member-manifest.json'] = (json.dumps(manifest, indent=2) + '\n').encode()
    archive = D / (NAME + '.zip')
    with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for name, data in sorted(payload.items()):
            z.writestr(name, data)
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None
        for name, expected in manifest.items():
            data = z.read(name)
            assert len(data) == expected['bytes'] and hashlib.sha256(data).hexdigest() == expected['sha256']
    evidence['archive'] = dict(**pin(archive), entries=len(payload),
        uncompressed_bytes=sum(map(len, payload.values())), crc_and_member_sha256_verified=True)
    save(D / (NAME + '.json'), evidence)
    print(json.dumps(pin(D / (NAME + '.json'))))


if __name__ == '__main__':
    main()
