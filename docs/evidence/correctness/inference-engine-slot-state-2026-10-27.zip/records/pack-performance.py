from pathlib import Path
import hashlib
import json
import zipfile

W = Path(__file__).resolve().parent
R = W.parents[1]
P = W / 'performance'
D = R / 'docs/evidence/performance'
NAME = 'inference-engine-slot-state-2026-10-27'


def pin(p):
    data = p.read_bytes()
    return dict(path=str(p), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())


def main():
    read = lambda p: json.loads(p.read_text(encoding='utf-8-sig'))
    summary, plan = read(P / 'summary.json'), read(P / 'plan.json')
    assert summary['status'] == 'EIGHT_FINITE_B2_PROCESSES_PASS'
    assert read(P / 'cross-arm-complete-nontime-differences.json') == []
    memory_comparisons = {}
    for k in summary['memory']['control']['sampled_peaks']:
        a = summary['memory']['control']['sampled_peaks'][k]
        b = summary['memory']['candidate']['sampled_peaks'][k]
        memory_comparisons[k] = dict(control_bytes=a, candidate_bytes=b, candidate_minus_control_bytes=b-a, sampled_lower_bound=True)
    data = dict(date='2026-10-27', status='FINITE_SAME_WINDOW_B2_AB_COMPLETE', plan=plan,
        metrics=summary['metrics'], comparisons=summary['comparisons'], memory=summary['memory'], memory_comparisons=memory_comparisons,
        process_count=8, timing_processes=6, memory_processes=2,
        generated_ids=198, computed_rows=1728, actual_graph_calls=99,
        cross_arm_complete_nontime_differences=0, cross_arm_returned_ID_differences=0,
        new_peer_processes=0, prior_samples_pooled=False, statistical_significance_claim=False,
        result='Decode +2.20%, combined session speed +1.51%; prefill -0.80% with overlapping ranges. Sampled dedicated peak -48MiB. Ready median +44.32ms; shape preparation +52.90ms. No new MTP throughput or cross-engine conclusion.',
        correctness=pin(R / 'docs/evidence/correctness' / (NAME + '.json')),
        limitations=['Three samples per arm, no exclusive GPU/fixed clocks; no statistical significance or universal win claim.',
            'Whole collection change against prior working-frame CLI, not a single-edit causal attribution.',
            'Fixed ordinary equal-T B2 three-turn work; no MTP speed, model quality or general serving result.',
            'Independent sampled RAM/VRAM peaks are lower bounds. Ready memory baselines unknown; model pool release is not VRAM release.',
            'OS page cache retained; startup and ready are separate endpoints, not cold-disk ranking.'])
    entries = {p.relative_to(W).as_posix():p.read_bytes() for p in P.rglob('*') if p.is_file() and p.suffix in ['.json','.log','.txt']}
    for p in [W/'performance.py',Path(__file__)]:
        entries[p.name] = p.read_bytes()
    manifest = {k:dict(bytes=len(v),sha256=hashlib.sha256(v).hexdigest()) for k,v in entries.items()}
    entries['member-manifest.json']=(json.dumps(manifest,indent=2)+'\n').encode()
    archive = D / (NAME + '.zip')
    with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for k,v in sorted(entries.items()):z.writestr(k,v)
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None
        for k,v in manifest.items():assert hashlib.sha256(z.read(k)).hexdigest()==v['sha256']
    data['archive']=dict(**pin(archive),entries=len(entries),uncompressed_bytes=sum(map(len,entries.values())),crc_and_member_sha256_verified=True)
    target=D/(NAME+'.json')
    target.write_bytes((json.dumps(data,ensure_ascii=False,indent=2)+'\n').encode())
    print(json.dumps(pin(target)))


if __name__=='__main__':main()
