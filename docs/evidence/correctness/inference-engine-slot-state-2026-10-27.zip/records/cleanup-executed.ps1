$ErrorActionPreference = 'Stop'
$workspace = [IO.Path]::GetFullPath($PSScriptRoot)
$target = Join-Path $workspace '.scratch\inference-engine-slot-state-20261027\formal-cuda2\hyle.exe'
$resolved = [IO.Path]::GetFullPath($target)
$expectedDirectory = [IO.Path]::GetFullPath((Join-Path $workspace '.scratch\inference-engine-slot-state-20261027\formal-cuda2'))
if ([IO.Path]::GetDirectoryName($resolved) -ne $expectedDirectory -or !$resolved.StartsWith($workspace + '\', [StringComparison]::OrdinalIgnoreCase)) { throw 'Unexpected cleanup target' }
$item = Get-Item -LiteralPath $resolved
$hash = (Get-FileHash -LiteralPath $resolved -Algorithm SHA256).Hash.ToLowerInvariant()
if ($item.Length -ne 142046720 -or $hash -ne '64126541f9707a34a4445d819eb876a13a20d2a3ca8ed6119fcef900db9f9062') { throw 'Superseded image identity changed' }
$kept = @(
 '.scratch\inference-engine-slot-state-20261027\formal-cuda3\hyle.exe',
 '.scratch\inference-engine-slot-state-20261027\mixed\link\host-image-test.exe',
 '.scratch\inference-engine-slot-state-20261027\prefix-value\bin\prefix-value.exe',
 '.scratch\inference-paged-frame-20261026\engine\formal\link\hyle.exe'
)
foreach ($relative in $kept) { if (!(Test-Path -LiteralPath (Join-Path $workspace $relative) -PathType Leaf)) { throw "Required retained image missing: $relative" } }
Write-Output "Verified superseded image: $resolved ($($item.Length) bytes)"
if ($env:HYLE_EXECUTE_CLEANUP -ne '1') { Write-Output 'Preview only; set HYLE_EXECUTE_CLEANUP=1 to execute this exact script'; exit 0 }
Remove-Item -LiteralPath $resolved
[pscustomobject]@{ removed = $resolved; bytes = 142046720; sha256 = $hash; retained = $kept } | ConvertTo-Json -Depth 4 | Set-Content -LiteralPath (Join-Path $workspace '.scratch\inference-engine-slot-state-20261027\cleanup-result.json') -Encoding UTF8
