"""Read cached recipes and prepare engine links. No source freeze/build/run."""
from pathlib import Path
import hashlib
import json

W = Path(__file__).resolve().parent
R = W.parents[1]
B = R / '.scratch/inference-batched-slot-controls-20261027'
E = R / '.scratch/inference-paged-frame-20261026/engine'


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def pin(path):
    path = Path(path)
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())


def save(path, value):
    path = Path(path)
    assert path.is_relative_to(W)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes((json.dumps(value, ensure_ascii=False, indent=2) + '\n').encode('utf-8'))


def key(path):
    return str(path).replace('/', '\\').casefold()


def retarget(recipe, source, out):
    command, dependency = [], False
    for argument in read(recipe)['command']:
        if dependency:
            command.append(str(out / 'dependencies.json')); dependency = False
        elif argument.casefold() == '/sourcedependencies':
            command.append(argument); dependency = True
        elif argument.casefold().startswith('/fo'):
            command.append('/Fo' + str(out / 'unit.obj'))
        elif argument.casefold().startswith('/fd'):
            command.append('/Fd' + str(out / 'unit.pdb'))
        elif argument.casefold().endswith('.cc'):
            command.append(str(R / source))
        else:
            command.append(argument)
    return dict(command=command, cwd=str(R), timeout_seconds=180, status='UNFROZEN_TEMPLATE_NOT_EXECUTED')


def main():
    current = read(B / 'link2-inputs.json')
    assert len(current) == 229
    tests = [
        '.scratch/inference-indexed-state-20261027/graph-integration/compile2/region-test/unit.obj',
        '.scratch/inference-batched-slot-controls-20261027/compile/bindings-test/unit.obj',
        '.scratch/inference-slot-source-fallback-20261027/compile5/cuda-test/unit.obj',
        '.scratch/inference-batched-slot-controls-20261027/compile3/cpu-test/unit.obj',
        '.scratch/inference-indexed-conv-20261027/compile2/test/unit.obj',
        '.scratch/inference-cpu-storage-gather-20261027/compile2/rules-test/unit.obj',
        '.scratch/inference-batched-slot-controls-20261027/compile3/cuda-test/unit.obj',
    ]
    removed = {key(R / path) for path in tests}
    removed |= {key(row['path']) for row in current if Path(row['path']).name.casefold() in ['gtest.lib', 'gtest_main.lib']}
    assert len(removed) == 9 and sum(key(row['path']) in removed for row in current) == 9
    shared = [row for row in current if key(row['path']) not in removed]
    save(W / 'cuda-base-inputs.json', shared)
    engine_objects = {
        'weights': R / '.scratch/inference-reusable-state-20261026/cuda2/compile/weights/unit.obj',
        'report': R / '.scratch/inference-review-fixes-20261026/product2/report/unit.obj',
        'entry': R / '.scratch/inference-current-closure-20261026/engine/entry/unit.obj',
    }
    units = []
    for name, source, recipe in [
        ('formal-cuda', 'engine/models/qwen35/main.cc', E / 'compile/formal/command.json'),
        ('host-cuda', 'tests/tools/qwen_host_image_test.cc', E / 'compile/cuda/command.json'),
        ('host-cpu-vulkan', 'tests/tools/qwen_host_image_test.cc', E / 'compile/cpu-vulkan/command.json'),
        ('lifecycle-cpu-vulkan', 'tests/tools/qwen_request_lifecycle_test.cc', E / 'compile/cpu-vulkan/command.json'),
        ('prefix-value-cuda', 'tests/tools/qwen_mtp_prefix_value_probe.cc', E / 'compile/cuda/command.json'),
    ]:
        template = W / 'recipes' / (name + '.json')
        save(template, retarget(recipe, source, W / 'compile' / name))
        units.append(dict(name=name, source=str(R / source), source_frozen=False,
                          baseline_recipe=pin(recipe), command_template=pin(template),
                          planned_object=str(W / 'compile' / name / 'unit.obj')))
    artifacts = []
    for name, extras in [('formal-cuda', ['weights', 'report', 'entry']),
                         ('host-cuda', ['weights', 'report']),
                         ('prefix-value-cuda', ['weights', 'report'])]:
        unit = next(row for row in units if row['name'] == name)
        image = W / name / ('hyle.exe' if name == 'formal-cuda' else 'consumer.exe')
        args = []
        for arg in read(B / 'link2/command.json')['command']:
            if key(arg) in removed:
                continue
            if arg.upper().startswith('/OUT:'): arg = '/OUT:' + str(image)
            elif arg.upper().startswith('/PDB:'): arg = '/PDB:' + str(image.with_suffix('.pdb'))
            elif arg.upper().startswith('/IMPLIB:'): arg = '/IMPLIB:' + str(image.with_suffix('.lib'))
            elif arg.upper().startswith('/MAP:'): continue
            args.append(arg)
        added = [pin(engine_objects[item]) for item in extras]
        args.extend(row['path'] for row in added)
        args.append(unit['planned_object'])
        link = W / 'recipes' / (name + '-link.json')
        save(link, dict(command=args, cwd=str(R), timeout_seconds=120, status='UNFROZEN_TEMPLATE_NOT_LINKED'))
        save(W / (name + '-retained-inputs.json'), shared + added)
        artifacts.append(dict(name=name, image=str(image), retained_inputs=pin(W / (name + '-retained-inputs.json')),
            input_count=220 + len(added) + 1, new_TUs=1, new_objects=[unit['planned_object']],
            reused_engine_objects=added, link_template=pin(link), runtime=pin(B / 'runtime2.json')))
    cpu = read(E / 'cpu-vulkan/link-inputs.json')
    # Original CPU/Vulkan Backend macro layout and CPU weights stay together.
    pairs = [
        ('.scratch/inference-bulk-append-20261026/compile/resources/unit.obj', '.scratch/inference-batched-slot-controls-20261027/compile/resources/unit.obj'),
        ('.scratch/inference-current-closure-20261026/unresolved-host/compile/graph_batch--batch_cc/unit.obj', '.scratch/inference-slot-store-20261027/attempt1/compile/batch/unit.obj'),
        ('.scratch/inference-storage-freeze-20261026/compile/core/unit.obj', '.scratch/inference-lease-slots-20261026/compile/core/unit.obj'),
        ('.scratch/glm-quark-selected-20261024/Q30/graph-integration-preparation/host1/compute_provider_native--default_rules.obj', '.scratch/inference-cpu-storage-gather-20261027/compile/default_rules/unit.obj'),
        ('.scratch/glm-quark-selected-20261024/Q30/graph-integration-preparation/host1/compute_provider_native--indexing.obj', '.scratch/inference-cpu-storage-gather-20261027/compile/indexing/unit.obj'),
        ('.scratch/glm-quark-selected-20261024/Q30/graph-integration-preparation/host1/compute_provider_native--native_provider.obj', '.scratch/inference-cpu-storage-gather-20261027/compile/native_provider/unit.obj'),
    ]
    replacements = {key(R / before): pin(R / after) for before, after in pairs}
    assert len(cpu) == 137 and all(sum(key(row['path']) == path for row in cpu) == 1 for path in replacements)
    additions = [pin(R / path) for path in [
        '.scratch/inference-batched-slot-controls-20261027/compile/slots/unit.obj',
        '.scratch/inference-batched-slot-controls-20261027/compile2/common/unit.obj']]
    updated_cpu = [replacements.get(key(row['path']), row) for row in cpu] + additions
    assert len(updated_cpu) == 139
    save(W / 'cpu-vulkan-inputs-template.json', updated_cpu)
    fixture = R / '.scratch/mtp-state-ports-20261024/gdn-regression/shared-fixture'
    recursive = R / '.scratch/inference-paged-frame-20261026/tiny-recursive-input'
    commands = []
    for backend in ['cpu', 'cuda']:
        image = W / ('host-cpu-vulkan' if backend == 'cpu' else 'host-cuda') / 'consumer.exe'
        for suffix, args in [('ordinary-and-mtp-images', []), ('lag1-images', ['--mtp-lag1']), ('state-reuse', ['--state-reuse'])]:
            commands.append(dict(name=backend + '-' + suffix, argv=[str(image), '--' + backend, str(fixture), *args],
                fixture_exists=fixture.is_dir(), status='PROPOSED_NOT_RUN', timeout_seconds=90,
                prerequisite='State-reuse direct-port assertions must be adapted before compile/run.' if args == ['--state-reuse'] else 'Root selects a finite run subset after source freeze.'))
    for option in ['--request-loop', '--request-control']:
        commands.append(dict(name=option[2:] + '-cpu', argv=[str(W / 'lifecycle-cpu-vulkan/consumer.exe'), option,
            str(R / '.scratch/inference-e4-model-20261025/fixture-preparation/ct-e4-aa')], status='PROPOSED_NOT_RUN', timeout_seconds=90))
    old = read(R / '.scratch/inference-paged-frame-20261026/recursive-runs/drafts2-candidate/command.json')
    for enabled in [False, True]:
        argv = list(old['command']); argv[0] = str(W / 'formal-cuda/hyle.exe')
        argv[argv.index('--mtp') + 1] = 'on' if enabled else 'off'
        commands.append(dict(name='cuda-cli-' + ('mtp-k2' if enabled else 'ordinary'), argv=argv,
            fixture_exists=recursive.is_dir(), status='PROPOSED_NOT_RUN', timeout_seconds=90,
            baseline=pin(R / '.scratch/inference-paged-frame-20261026/recursive-runs/drafts2-candidate/command.json')))
    save(W / 'run-commands.json', commands)
    save(W / 'plan.json', dict(status='PREPARED_NOT_FROZEN_BUILT_OR_RUN',
        baseline=pin(B / 'ready2.json'), baseline_inputs=pin(B / 'link2-inputs.json'),
        native='Reuse current indexed GDN/conv/dispatcher, providers and DLL identities from the 229-input baseline; zero NVCC/SDK/shader work.',
        CUDA=dict(base_count=220, removed_test_inputs=[row for row in current if key(row['path']) in removed],
                  artifacts=artifacts, minimum='One chosen combined consumer is one CXX TU; formal CLI is a separate Model TU. Do not link both combined probe TU and standalone Model TU.'),
        CPU_Vulkan=dict(baseline=pin(E / 'cpu-vulkan/ready.json'), original_inputs=137, replacement_count=6,
            added_slot_objects=additions, final_inputs=139, inputs=pin(W / 'cpu-vulkan-inputs-template.json'),
            weights=pin(R / '.scratch/inference-stream-padding-20261026/compile/weights/unit.obj'),
            runtime=pin(E / 'cpu-vulkan/runtime.json'),
            status='Prepared alternative using original CPU/Vulkan ABI; final link replaces its one combined host-image entry with the chosen new combined TU.',
            original_combined_object=pin(E / 'compile/cpu-vulkan/unit.obj')),
        units=units, run_commands=pin(W / 'run-commands.json'),
        observations=[
            'tests/tools/qwen_state_reuse_case.h:59-63 directly examines old history/recurrent prefix output ports, child output caller-owned status; later code directly checks reuse caches.',
            'tests/tools/qwen_mtp_prefix_value_probe.cc:53-57 reads old published history/recurrent prefix results as a graph-value oracle; must observe the equivalent exact candidate slot bytes without introducing a new math oracle.',
            'tests/tools/qwen_host_image_case.h:165 drains history_reuse before intentionally exhausting the history pool. Recheck this injection after stable indexed ownership; it is not a direct graph-port consumer.',
            'No other history_prefix/recurrent_prefix references were found outside engine main and these two direct consumers. Batch/session/random probes use committed State/trace boundaries.',
            'Request-loop and request-control cases explicitly choose CPU. Their old mixed CPU+CUDA private wrapper is another valid cached configuration only with its original matching CPU-representative weights; do not transplant CUDA-only weights across Backend macro layouts.',
            'Use the existing prepared fixtures without copying/downloading; commands are candidates, not an instruction to execute the whole matrix.',
            'Reuse recent actual compiler/device identities from indexed-conv public evidence; this preparation performs no new device experiment or version subprocess.'
        ], counts=dict(builds=0, links=0, model_runs=0, downloads=0),
        prior_engine=pin(E / 'ready2.json'),
        toolchain_device_evidence=pin(R / 'docs/evidence/correctness/inference-indexed-conv-graph-2026-10-27.json')))
    print(json.dumps(dict(plan=pin(W / 'plan.json'), CUDA_CLI_inputs=224, CUDA_combined_probe_inputs=223,
                         CPU_Vulkan_inputs=139, builds=0, runs=0)))


if __name__ == '__main__':
    main()
