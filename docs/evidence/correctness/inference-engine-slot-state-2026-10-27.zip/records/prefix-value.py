"""One combined prefix-value CUDA TU, original retained closure, finite original matrix."""
from pathlib import Path
import importlib.util,json,os,sys,traceback,re
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent
R=W.parents[1]
P=W/'prefix-value'
spec=importlib.util.spec_from_file_location('retained_batch_recipe', R/'.scratch/inference-batched-slot-controls-20261027/build.py')
old=importlib.util.module_from_spec(spec);spec.loader.exec_module(old)
b,m=old.helpers()

def environment():
    command=b.read(W/'recipes/prefix-value-cuda.json')['command']
    cl=command[0]
    helper=b.helper()
    env=helper.discover_environment(compiler='msvc',cache={'CMAKE_C_COMPILER':cl,'CMAKE_CXX_COMPILER':cl,'CMAKE_GENERATOR':'Ninja'},backends=()).env
    return helper,env

def build():
    assert not P.exists(),'Preserve original build attempts'
    source=R/'tests/tools/qwen_mtp_prefix_value_probe.cc'
    assert b.pin(R/'engine/models/qwen35/main.cc')['sha256']=='3b1a2c6996a8c7a3cd3c654526abd1bbb9a033a0a809e68ff6063ede8b61812f'
    assert b.pin(R/'engine/models/qwen35/session_state.h')['sha256']=='e393af9522901f73bab16801054e7c4761ca836f87b15003902f6b7c279ce2bd'
    command=b.read(W/'recipes/prefix-value-cuda.json')['command']
    for i,arg in enumerate(command):
        if arg.upper().startswith('/FO'):command[i]='/Fo'+str(P/'compile/unit.obj')
        elif arg.upper().startswith('/FD'):command[i]='/Fd'+str(P/'compile/unit.pdb')
        elif i and command[i-1].lower()=='/sourcedependencies':command[i]=str(P/'compile/dependencies.json')
    b.save(P/'recipe.json',dict(command=command,cwd=str(R),timeout_seconds=180))
    frozen=m.c.closure([source],[P/'recipe.json'])
    b.save(P/'source-freeze.json',frozen)
    for path in [source,R/'engine/models/qwen35/main.cc',R/'engine/models/qwen35/session_state.h',R/'engine/models/qwen35/mtp_session_probe.cc']:
        target=P/'source'/path.relative_to(R);target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(path.read_bytes())
    retained=b.read(W/'prefix-value-cuda-retained-inputs.json')
    formal=b.read(W/'formal3-link-inputs.json')
    old_object=str(W/'compile/prefix-value-cuda/unit.obj')
    current={b.key(x['path']):x for x in retained}
    peer={b.key(x['path']):x for x in formal}
    assert len(retained)==222 and len(formal)==224
    assert set(current)<=set(peer) and all(current[k]==peer[k] for k in current)
    only=[peer[k]['path'] for k in set(peer)-set(current)]
    assert set(map(b.key,only))=={b.key(W/'compile3/formal-cuda/unit.obj'),b.key(R/'.scratch/inference-current-closure-20261026/engine/entry/unit.obj')},only
    for row in retained:b.exact(row)
    b.save(P/'retained-inputs.json',retained)
    b.save(P/'closure-review.json',dict(formal3=b.pin(W/'formal3-link-inputs.json'),prefix_retained=b.pin(P/'retained-inputs.json'),identical_retained=222,removed_formal_only=only,model_object_duplicated=False))
    helper,env=environment()
    process=helper.execute(command,env,P/'compile',timeout=180)
    raw=b.read(P/'compile/dependencies.json')['Data']
    actual=[b.pin(path) for path in dict.fromkeys([raw['Source'],*raw['Includes']])]
    b.save(P/'compile/actual-dependencies.json',actual)
    own={b.key(x['path']):x for x in frozen}
    for row in actual:
        path=Path(row['path'])
        if path.is_relative_to(R) and not path.is_relative_to(R/'.scratch'):
            assert own[b.key(path)]['sha256']==row['sha256'],str(path)
    for row in frozen:b.exact(row)
    image=P/'bin/prefix-value.exe';image.parent.mkdir(parents=True,exist_ok=True)
    link=b.read(W/'recipes/prefix-value-cuda-link.json')['command']
    count=0
    for i,arg in enumerate(link):
        if b.key(arg)==b.key(old_object):link[i]=str(P/'compile/unit.obj');count+=1
        elif arg.upper().startswith('/OUT:'):link[i]='/OUT:'+str(image)
        elif arg.upper().startswith('/PDB:'):link[i]='/PDB:'+str(image.with_suffix('.pdb'))
        elif arg.upper().startswith('/IMPLIB:'):link[i]='/IMPLIB:'+str(image.with_suffix('.lib'))
    assert count==1
    b.save(P/'link-recipe.json',dict(command=link,cwd=str(R),timeout_seconds=120))
    linked=helper.execute(link,env,P/'link',timeout=120)
    inputs=retained+[b.pin(P/'compile/unit.obj')]
    b.save(P/'link-inputs.json',inputs)
    runtime=b.read(W/'formal3-runtime.json')
    native=runtime['native_cpu'];b.exact(native)
    alias=image.parent/Path(native['path']).name;os.link(native['path'],alias)
    runtime['native_cpu_hardlink']=b.pin(alias);runtime['PATH']=str(image.parent)+';'+runtime['PATH']
    b.save(P/'runtime.json',runtime)
    b.save(P/'ready.json',dict(status='BUILT_NOT_RUN',image=b.pin(image),source=b.pin(source),object=b.pin(P/'compile/unit.obj'),process=process,link=linked,actual_dependencies=b.pin(P/'compile/actual-dependencies.json'),source_freeze=b.pin(P/'source-freeze.json'),inputs=b.pin(P/'link-inputs.json'),runtime=b.pin(P/'runtime.json'),counts=dict(CXX_TUs=1,links=1,images=1,NVCC=0,SDK=0,downloads=0)))
    print('READY',json.dumps(b.pin(P/'ready.json')),flush=True)

def run():
    ready=b.read(P/'ready.json');b.exact(ready['image'])
    out=P/'run';assert not out.exists(),'No automatic rerun of original matrix'
    fixture=R/'.scratch/qwen35-unsloth-mtp-20261024/geometry-v2-check/original'
    b.save(P/'run-plan.json',dict(command=[ready['image']['path'],str(fixture)],manifest=b.pin(fixture/'weights.tsv'),prompt=b.pin(fixture/'prompt.ids'),scope='Original complete Qwen3.5-2B finite 17 prefix cases and 7 perturbed suffix pairs; no quality/performance claim. No tiny substitution.',timeout_seconds=300))
    helper,env=environment();env['PATH']=b.read(ready['runtime']['path'])['PATH'];env['HF_HUB_OFFLINE']=env['TRANSFORMERS_OFFLINE']='1'
    process=helper.execute([ready['image']['path'],str(fixture)],env,out,timeout=300)
    stdout=(out/'stdout.log').read_text(encoding='utf-8-sig')
    final=json.loads(next(line for line in reversed(stdout.splitlines()) if line.startswith('{')))
    assert final['prefix_cases']==17 and final['perturbed_suffix_pairs']==7 and final['final_live_versions']==0,final
    assert final['old_complete_state_unchanged'] and final['new_graph_ports']==0
    assert final['cross_width_bit_equality_required'] is False and final['quality_claim'] is False and final['performance_claim'] is False
    plans=[dict(zip(['role','requests','tokens','indexed_gdn_regions','indexed_conv_regions'],map(int,row))) for row in re.findall(r'COLD role=(\d+) requests=(\d+) tokens=(\d+) indexed_gdn_regions=(\d+) indexed_conv_regions=(\d+)',stdout)]
    assert len(plans)==5,plans
    b.save(P/'run-summary.json',dict(status='PASS_ORIGINAL_FINITE_PREFIX_VALUES',process=process,image=ready['image'],source=ready['source'],original_fixture=b.pin(P/'run-plan.json'),result=final,actual_cold_plans=plans,scope='Exact selected candidate slot bytes, accepted KV prefix, independent target-hidden draft repair, suffix perturbation causality and same-T1 continuation. Cold route counts observe selected child artifacts, not GPU profiler data.'))
    print('PASS',json.dumps(b.pin(P/'run-summary.json')),flush=True)

if __name__=='__main__':
    stage=sys.argv[1]
    try:
        {'build':build,'run':run}[stage]()
    except Exception:
        b.save(P/(stage+'-failure.json'),dict(error=traceback.format_exc(),scope='Original source/logs/process retained. Stopped on first failure, no automatic fallback/retry.'))
        raise
