"""Two authorized mixed CPU+CUDA CXX units and finite explicit host-state cases."""
from pathlib import Path
import importlib.util
import json
import os
import sys
import traceback

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = W.parents[1]
M = W / 'mixed'
spec = importlib.util.spec_from_file_location('retained_batch_recipe', R / '.scratch/inference-batched-slot-controls-20261027/build.py')
old = importlib.util.module_from_spec(spec)
spec.loader.exec_module(old)
b, helper_module = old.helpers()


def build():
    assert not (M / 'freeze.json').exists() and not (M / 'ready.json').exists()
    expected = {'engine/models/qwen35/main.cc': '3b1a2c6996a8c7a3cd3c654526abd1bbb9a033a0a809e68ff6063ede8b61812f',
        'engine/models/qwen35/session_state.h': 'e393af9522901f73bab16801054e7c4761ca836f87b15003902f6b7c279ce2bd',
        'tests/tools/qwen_state_reuse_case.h': '03e0df887bb8fb8c30cfee68a7358553c5ef1ffa1c731e5d624730fbe98a0762'}
    for path, digest in expected.items():
        assert b.pin(R / path)['sha256'] == digest, path
    units = []
    for name, source, original in [
        ('weights', 'engine/models/qwen35/weights.cc', '.scratch/inference-cpu-representative-20261026/compile/weights/command.json'),
        ('probe', 'tests/tools/qwen_host_image_test.cc', '.scratch/inference-request-control-20261026/cpu2/compile/command.json')]:
        command = helper_module.command(R / original, R / source, M / 'compile' / name)
        assert not any(arg.startswith(('/I', '-I')) and str(R / '.scratch').casefold() in arg.casefold() for arg in command)
        path = M / 'recipes' / (name + '.json')
        b.save(path, dict(command=command, cwd=str(R), timeout_seconds=180))
        units.append(dict(name=name, source=b.pin(R / source), original_recipe=b.pin(R / original), command=b.pin(path)))
    macros = [[arg for arg in b.read(unit['command']['path'])['command'] if arg.startswith(('/D', '-D', '/U', '-U'))] for unit in units]
    assert macros[0] == macros[1]
    current = b.read(W / 'cuda-base-inputs.json')
    assert len(current) == 220
    pairs = [
        ('src/graph_route_cpu/ggml_region.cc', '.scratch/inference-current-closure-20261026/headers79/graph_route_cpu--ggml_region_cc/unit.obj', '.scratch/inference-cpu-region-views-20261026/validation/candidate1/compile-region'),
        ('src/compute_provider_ggml/ggml_cpu_provider.cc', '.scratch/inference-current-closure-20261026/headers79/compute_provider_ggml--ggml_cpu_provider_cc/unit.obj', '.scratch/inference-cpu-shared-pool-20261026/build1/provider'),
        ('src/compute_ggml_runtime/cpu_execution.cc', '.scratch/glm-mlx-flash-original-20261024/gdn-output-scale-validation/foundation1/cpu-execution.obj', '.scratch/inference-cpu-shared-pool-20261026/poll-default1/compile')]
    replacements, compatibility = {}, []
    layout_names = {'program.h', 'cpu_execution.h', 'region_provider.h', 'provider.h', 'operation.h', 'completion_access.h'}
    for source, previous, directory in pairs:
        directory = R / directory
        deps = b.read(directory / 'actual-dependencies.json')
        compiled_source = deps[0]
        assert compiled_source['sha256'] == b.pin(R / source)['sha256']
        layout = [row for row in deps if Path(row['path']).name in layout_names]
        for row in layout:
            b.exact(row)
        before = str(R / previous)
        assert sum(b.key(row['path']) == b.key(before) for row in current) == 1
        replacement = b.pin(directory / 'unit.obj')
        replacements[b.key(before)] = replacement
        compatibility.append(dict(canonical_source=b.pin(R / source), actual_compiled_source=compiled_source,
            object=replacement, actual_dependencies=b.pin(directory / 'actual-dependencies.json'),
            unchanged_layout_dependencies=layout, original_command=b.pin(directory / 'command.json')))
    retained = [replacements.get(b.key(row['path']), row) for row in current]
    report = b.pin(R / '.scratch/inference-review-fixes-20261026/product2/report/unit.obj')
    retained.append(report)
    frozen = helper_module.c.closure([unit['source']['path'] for unit in units], [unit['command']['path'] for unit in units])
    b.save(M / 'source-freeze.json', frozen)
    snapshots = []
    for path in ['engine/models/qwen35/main.cc', 'engine/models/qwen35/session_state.h',
                 'engine/models/qwen35/weights.cc', 'engine/models/qwen35/weights.h',
                 'tests/tools/qwen_host_image_test.cc', 'tests/tools/qwen_host_image_case.h', 'tests/tools/qwen_state_reuse_case.h']:
        target = M / 'source' / path
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes((R / path).read_bytes())
        snapshots.append(b.pin(target))
    b.save(M / 'freeze.json', dict(units=units, macros=macros[0], source_freeze=b.pin(M / 'source-freeze.json'),
        snapshots=snapshots, reused_cpu_compatibility=compatibility,
        matching_macros='Both new units use the exact mixed CPU+CUDA+GGML CPU/CUDA+ONEDNN definitions. Old mixed weights is deliberately not reused because its Backend/header version differs.',
        no_duplicate_main='The one combined qwen_host_image_test.cc includes Model main.cc and defines its own entry; no standalone Model or engine-entry OBJ is present in the 220-input base.',
        retained_inputs=retained, compiled_TUs=2, SDK=0, NVCC=0, downloads=0))
    own = {b.key(row['path']): row for row in frozen}
    h = b.helper()
    cl = b.read(units[0]['command']['path'])['command'][0]
    env = h.discover_environment(compiler='msvc', cache={'CMAKE_C_COMPILER': cl,
        'CMAKE_CXX_COMPILER': cl, 'CMAKE_GENERATOR': 'Ninja'}, backends=()).env
    compiled = []
    for unit in units:
        out = M / 'compile' / unit['name']
        process = h.execute(b.read(unit['command']['path'])['command'], env, out, timeout=180)
        raw = b.read(out / 'dependencies.json')['Data']
        actual = [b.pin(path) for path in dict.fromkeys([raw['Source'], *raw['Includes']])]
        b.save(out / 'actual-dependencies.json', actual)
        for row in actual:
            path = Path(row['path'])
            if path.is_relative_to(R) and not path.is_relative_to(R / '.scratch'):
                assert own[b.key(path)]['sha256'] == row['sha256'], str(path)
        compiled.append(dict(name=unit['name'], source=unit['source'], object=b.pin(out / 'unit.obj'),
            process=process, actual_dependencies=b.pin(out / 'actual-dependencies.json')))
    for row in frozen:
        b.exact(row)
    image = M / 'link/host-image-test.exe'
    objects = {unit['name']: unit['object'] for unit in compiled}
    old_weights = R / '.scratch/inference-reusable-state-20261026/cuda2/compile/weights/unit.obj'
    old_probe = W / 'compile/host-cuda/unit.obj'
    command = []
    for arg in b.read(W / 'recipes/host-cuda-link.json')['command']:
        if b.key(arg) in replacements: arg = replacements[b.key(arg)]['path']
        elif b.key(arg) == b.key(old_weights): arg = objects['weights']['path']
        elif b.key(arg) == b.key(old_probe): arg = objects['probe']['path']
        elif arg.upper().startswith('/OUT:'): arg = '/OUT:' + str(image)
        elif arg.upper().startswith('/PDB:'): arg = '/PDB:' + str(image.with_suffix('.pdb'))
        elif arg.upper().startswith('/IMPLIB:'): arg = '/IMPLIB:' + str(image.with_suffix('.lib'))
        command.append(arg)
    assert sum(b.key(arg) == b.key(objects['weights']['path']) for arg in command) == 1
    assert sum(b.key(arg) == b.key(objects['probe']['path']) for arg in command) == 1
    linked = h.execute(command, env, M / 'link', timeout=120)
    inputs = retained + [objects['weights'], objects['probe']]
    assert len(inputs) == 223
    b.save(M / 'link-inputs.json', inputs)
    runtime = b.read(W / 'formal3-runtime.json')
    native = runtime['native_cpu']
    b.exact(native)
    alias = image.parent / Path(native['path']).name
    os.link(native['path'], alias)
    runtime['native_cpu_hardlink'] = b.pin(alias)
    runtime['PATH'] = str(image.parent) + ';' + runtime['PATH']
    b.save(M / 'runtime.json', runtime)
    b.save(M / 'ready.json', dict(status='BUILT_NOT_RUN', image=b.pin(image), compiled=compiled, link=linked,
        inputs=b.pin(M / 'link-inputs.json'), runtime=b.pin(M / 'runtime.json'), frozen=b.pin(M / 'freeze.json'),
        counts=dict(CXX_TUs=2, links=1, images=1, SDK=0, NVCC=0, downloads=0)))
    print('READY', json.dumps(b.pin(M / 'ready.json')), flush=True)


def run(backend, mode):
    assert backend in ['cpu', 'cuda'] and mode in ['hostimage', 'lag1', 'state-reuse']
    ready = b.read(M / 'ready.json')
    b.exact(ready['image'])
    out = M / 'runs' / (backend + '-' + mode)
    assert not out.exists(), 'Preserve original result; no automatic retry'
    command = [ready['image']['path'], '--' + backend,
        str(R / '.scratch/mtp-state-ports-20261024/gdn-regression/shared-fixture')]
    if mode != 'hostimage': command.append('--mtp-lag1' if mode == 'lag1' else '--state-reuse')
    h = b.helper()
    cl = b.read(M / 'recipes/probe.json')['command'][0]
    env = h.discover_environment(compiler='msvc', cache={'CMAKE_C_COMPILER': cl,
        'CMAKE_CXX_COMPILER': cl, 'CMAKE_GENERATOR': 'Ninja'}, backends=()).env
    env['PATH'] = b.read(ready['runtime']['path'])['PATH']
    env['HF_HUB_OFFLINE'] = env['TRANSFORMERS_OFFLINE'] = '1'
    process = h.execute(command, env, out, timeout=90)
    b.save(out / 'success.json', dict(process=process, image=ready['image'], backend=backend, mode=mode,
        stdout=b.pin(out / 'stdout.log'), stderr=b.pin(out / 'stderr.log'),
        note='Original consumer assertions and complete outputs retained; no throughput claim.'))
    print('PASS', backend, mode, flush=True)


if __name__ == '__main__':
    try:
        if sys.argv[1] == 'build': build()
        else:
            assert sys.argv[1] == 'run'
            run(sys.argv[2], sys.argv[3])
    except Exception:
        target = M / ('failure-' + '-'.join(sys.argv[1:]) + '.json')
        b.save(target, dict(error=traceback.format_exc(), note='Stopped with original outputs/source retained; no automatic retry.'))
        raise
