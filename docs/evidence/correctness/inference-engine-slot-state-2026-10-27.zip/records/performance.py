"""Finite same-window ordinary B2 comparison; preserves every first failure."""
from pathlib import Path
import importlib.util
import json
import math
import os
import re
import sys

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = W.parents[1]
F = R / '.scratch/inference-b2-reusable-state-20261026'
spec = importlib.util.spec_from_file_location('indexed_state_window', R / '.scratch/inference-b2-current-window-20261026/run.py')
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)


def setup():
    old = m.read(R / '.scratch/inference-paged-frame-20261026/engine/formal/ready.json')
    new = m.read(W / 'formal3-ready.json')
    images = {'control': old['image'], 'candidate': new['image']}
    for row in [*images.values(), old['inputs'], new['inputs'], old['runtime'], new['runtime']]:
        m.verify(row)
    runtime = m.read(new['runtime']['path'])
    before, after = m.read(old['inputs']['path']), m.read(new['inputs']['path'])
    old_map = {x['sha256']: x for x in before}
    unchanged = [x for x in after if x['sha256'] in old_map]
    native = m.read(F / 'pins.json')['harness']
    for row in native.values():
        m.verify(row)
    helper = m.module('indexed_state_runner', native['runner']['path'])
    m.module('indexed_state_observer', native['observer']['path']).install(helper)
    code, parser = m.legacy_phase_parser(native['old_performance_parser']['path'])
    expected = m.read(F / 'expected-work.json')
    for row in [expected['manifest'], expected['schedule'], *[x['file'] for x in expected['tapes']]]:
        m.verify(row)
    argv = m.read(F / 'plan.json')['commands'][0]['command']
    plan = dict(images=images, runtime=new['runtime'], same_runtime_environment=True,
        control='Prior working-KV-frame formal CLI', candidate='Original-pool indexed state formal CLI',
        control_inputs=old['inputs'], candidate_inputs=new['inputs'], unchanged_input_hashes=len(unchanged),
        new_input_hashes=[x for x in after if x['sha256'] not in old_map],
        expected_work=m.identity(F / 'expected-work.json'), parser=parser,
        fixed_teacher_forced_work=True, prior_samples_pooled=False, peer_rerun=False,
        intended_processes=8, timing_processes=6, memory_processes=2,
        note='Collection comparison includes the already landed slot/region foundations. It does not isolate a single line or claim a new llama.cpp comparison.')
    return images, runtime, helper, code, expected, argv, plan


def main():
    assert sys.argv[1:] in [['prepare'], ['run']]
    images, runtime, helper, parse_code, expected, argv, plan = setup()
    if sys.argv[1] == 'prepare':
        helper.save(W / 'performance-plan.json', plan)
        print('PREPARED_NOT_RUN', flush=True)
        return
    out = W / 'performance'
    assert not out.exists(), 'Preserve first run; no automatic retry'
    out.mkdir()
    helper.save(out / 'plan.json', plan)
    helper.gpu_snapshot(out, 'before')
    reports, ids_by_arm, runs, memory = {}, {}, [], {}
    historical = m.read(F / 'runs/timing-01-hyle/observation.json')['raw']
    jobs = [('timing', i, arm) for i, arm in enumerate(['control', 'candidate', 'candidate', 'control', 'control', 'candidate'], 1)]
    jobs += [('memory', i, arm) for i, arm in enumerate(['control', 'candidate'], 1)]
    try:
        for mode, index, arm in jobs:
            m.verify(images[arm])
            command = list(argv)
            command[0] = images[arm]['path']
            folder = out / f'{mode}-{index:02}-{arm}'
            env = os.environ.copy()
            env['PATH'] = runtime['PATH']
            env.update(HF_HUB_OFFLINE='1', TRANSFORMERS_OFFLINE='1')
            print('BEGIN', mode, index, arm, flush=True)
            process = helper.execute(folder, 'hyle', command, env, mode == 'memory')
            raw = json.loads((folder / 'stdout.log').read_text(encoding='utf-8-sig'))
            audit = []
            normalized = m.normalize(raw, audit)
            helper.save(folder / 'normalization-audit.json', audit)
            helper.save(folder / 'complete-nontime-report.json', normalized)
            within = m.differences(reports[arm], normalized) if arm in reports else []
            helper.save(folder / 'within-arm-differences.json', within)
            assert not within, 'Within-arm non-time facts changed'
            ids = m.check_work(raw, 'hyle', expected, historical)
            if arm not in reports:
                reports[arm], ids_by_arm[arm] = normalized, ids
            if len(reports) == 2:
                helper.save(out / 'cross-arm-complete-nontime-differences.json', m.differences(reports['control'], reports['candidate']))
                cross_ids = m.differences(ids_by_arm['control'], ids_by_arm['candidate'])
                helper.save(out / 'cross-arm-output-differences.json', cross_ids)
                assert not cross_ids, 'Returned IDs changed; stop for numerical review'
            ns = dict(folder=folder, raw=raw, waves=raw['waves'], variant='hyle', ids=ids, re=re)
            exec(parse_code, ns)
            observation = ns['observation']
            assert all(math.isfinite(x) and x > 0 for x in observation['metrics'].values())
            helper.save(folder / 'observation.json', observation)
            runs.append(dict(arm=arm, mode=mode, index=index, process=process, metrics=observation['metrics']))
            helper.save(out / 'runs.json', runs)
            if mode == 'memory':
                memory[arm] = m.read(folder / 'memory-summary.json')
                assert memory[arm]['setup_error'] is None and memory[arm]['thread_error'] is None
            print('END', mode, index, arm, observation['metrics'], flush=True)
        metrics = {arm: {key: helper.stats([x['metrics'][key] for x in runs if x['arm'] == arm and x['mode'] == 'timing'])
            for key in runs[0]['metrics']} for arm in images}
        comparisons = {key: dict(candidate_percent=(metrics['candidate'][key]['median'] / metrics['control'][key]['median'] - 1) * 100,
            ranges_overlap=not (metrics['candidate'][key]['min'] > metrics['control'][key]['max'] or metrics['control'][key]['min'] > metrics['candidate'][key]['max']))
            for key in metrics['control']}
        helper.save(out / 'summary.json', dict(status='EIGHT_FINITE_B2_PROCESSES_PASS', runs=runs, metrics=metrics,
            comparisons=comparisons, memory=memory, returned_ID_differences=0,
            non_time_differences='Preserved separately; require explicit review of changed plans and cache facts.',
            statistical_significance_claim=False, peer_rerun=False))
    except BaseException as error:
        helper.save(out / 'failure.json', dict(status='STOPPED_FIRST_FAILURE', completed=len(runs), error=repr(error)))
        raise
    finally:
        helper.gpu_snapshot(out, 'after')


if __name__ == '__main__':
    main()
