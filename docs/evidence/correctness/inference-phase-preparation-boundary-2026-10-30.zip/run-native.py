"""Approved finitePhaseIO plan; rootowns oneCPUcase, bridge serializes25."""
from pathlib import Path
import hashlib,importlib.util,json,os,re,shutil
W=Path(__file__).resolve().parent;R=W.parents[1]
spec=importlib.util.spec_from_file_location('phase_native_build',W/'build.py')
h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
read,save,pin,exact=h.read,h.save,h.pin,h.exact
OLD=R/'.scratch/inference-family-factory-harness-20261030'
def stable(value,output=None):
 if isinstance(value,dict):return {key:stable(item,output) for key,item in value.items() if not key.endswith('_seconds') and not key.endswith('_per_second')}
 if isinstance(value,list):return [stable(item,output) for item in value]
 if isinstance(value,str) and output:return value.replace(str(output),'{OUTPUT_ROOT}')
 return value
def delta(a,z,path='$'):
 if isinstance(a,dict) and isinstance(z,dict):return [row for key in sorted(a.keys()|z.keys()) for row in delta(a.get(key),z.get(key),path+'.'+key)]
 if isinstance(a,list) and isinstance(z,list):
  if len(a)!=len(z):return [dict(path=path,old_length=len(a),new_length=len(z))]
  return [row for at,(x,y) in enumerate(zip(a,z)) for row in delta(x,y,path+'['+str(at)+']')]
 return [] if a==z else [dict(path=path,old=a,new=z)]
def prepare():
 path=W/'run-plan.json'
 if path.exists():return read(path)
 source=read(OLD/'run-plan.json')['cases'];policies=read(OLD/'sampling-supplement-plan.json')['cases'];all_old=source|policies
 tiny=R/'.scratch/inference-paged-frame-20261026/tiny-recursive-input'
 real=source['ordinary-single']['args'][1];cases={}
 cases['program-carrier-cpu']=dict(consumer='tiny',args=['--cpu','--program-carrier'],arms=['baseline','candidate'])
 cases['publication-retirement-cuda']=dict(consumer='tiny',args=['--cuda',str(tiny),'--publication-retirement'],arms=['baseline','candidate'])
 for case in ('packed-cuda','varlen-cuda','e4-cuda','mixed-h64','cpu-ffn-real-cuda','sampling-policies-cpu','mtp-logits-cuda'):
  cases[case]=dict(all_old[case],arms=['candidate'],reference=str(OLD/'runs/candidate'/case/'attempt1/report.json'))
 cases['probe-cpu']=dict(consumer='tiny',args=['--engine','--backend','cpu','--inputs',str(tiny),'--capacity','16','--steps','1',
  '--mtp','off','--replay','commands','--progress','direct','--sampling','greedy','--layer0-probe','{PROBES}'],arms=['baseline','candidate'],probe=True)
 for case in ('ordinary-single','mtp-single','ordinary-two','mtp-two'):cases[case]=dict(source[case],arms=['baseline','candidate'])
 local=W/'session-input';local.mkdir()
 for name in ('weights.tsv','prompt.ids'):shutil.copyfile(OLD/'session-input'/name,local/name)
 cases['session-cuda']=dict(consumer='session',args=['--backend','cuda','--inputs',str(local),'--output','{OUTPUT}','--scenario','sessions'],arms=['baseline','candidate'])
 cases['natural-relay-cuda']=dict(consumer='tiny',args=['--cuda',real,'--mtp-natural-relay'],arms=['baseline','candidate'])
 plan=dict(status='ROOT_AUTHORIZED26_NATIVE',cases=cases,bridge_native_count=25,root_case='phase-preparation-cpu',
  root_receipt=str(W/'runs/candidate/phase-preparation-cpu/attempt1'),total_native_count=26,
  prior_factory_pair_summary=pin(OLD/'pair-summary.json'),prior_policy_summary=pin(OLD/'sampling-supplement-summary.json'),
  scope='Only7unchanged-source historicalbaselines reused;freshdefault/Session/threeIOpairs/probe. No rows/optionalhead/trace/profile/perfwindow.')
 assert sum(len(row['arms']) for row in cases.values())==25
 save(path,plan);return plan
def parse(folder,case,row):
 text=(folder/'stdout.log').read_text(encoding='utf-8-sig');decoder=json.JSONDecoder();offset=0;values=[];observations=[]
 while offset<len(text):
  while offset<len(text) and text[offset].isspace():offset+=1
  if offset==len(text):break
  try:value,offset=decoder.raw_decode(text,offset);values.append(value)
  except json.JSONDecodeError:
   end=text.find('\n',offset);end=len(text) if end<0 else end;line=text[offset:end].strip()
   match=re.fullmatch(r'batched_text_sampling=true flat_identity_rows=2 flat_identity_words=4 families=(\d+) phases=(\d+)',line)
   assert case=='sampling-policies-cpu' and match,('Unexpectedstdout',case,line)
   observations.append(dict(batched_text_sampling=True,flat_identity_rows=2,flat_identity_words=4,families=int(match[1]),phases=int(match[2]),raw=line));offset=end
 assert values
 if case=='sampling-policies-cpu':
  assert len(values)==2 and observations and values[-1]['status']=='PASS' and values[-1]['case']=='sampling-policies'
  result=dict(status='PASS',reports=values,text_observations=observations)
 else:
  result=values[0] if len(values)==1 else dict(status='PASS',reports=values)
  if row.get('outputs'):assert result['generated_tokens']==row['outputs'] and result['live_committed_versions']==0
  elif row.get('probe'):assert result['source_id']=='6'*64 and result['generated_tokens']==1 and result['diagnostic'] is True
  elif case=='session-cuda':assert result['status']=='MTP_SESSION_PROBE_COMPLETED'
  else:assert all(value.get('status')=='PASS' for value in values)
 save(folder/'report.json',result);return result
def run(case,row,arm):
 folder=W/'runs'/arm/case/'attempt1'
 assert not (folder/'process.json').exists(),'Neverduplicateaccepted/failednative;root mustchoosefreshattempt.'
 image=read(W/('ready-'+('baseline-' if arm=='baseline' else '')+row['consumer']+'.json'));exact(image)
 save(folder/'image.json',image)
 args=[str(folder/'vectors') if arg=='{OUTPUT}' else str(folder/'probes') if arg=='{PROBES}' else arg for arg in row['args']]
 os.environ.update(HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',HF_HUB_DISABLE_TELEMETRY='1')
 h.s.b.execute([image['path'],*args],folder,900);return parse(folder,case,row)
def probes():
 inventories={}
 for arm in ('baseline','candidate'):
  root=W/'runs'/arm/'probe-cpu/attempt1/probes'
  inventories[arm]={path.relative_to(root).as_posix():pin(path) for path in sorted(root.rglob('*')) if path.is_file()}
 assert inventories['baseline'].keys()==inventories['candidate'].keys()
 raw=[name for name in inventories['candidate'] if Path(name).suffix in ('.bf16','.f16','.f32','.bin')]
 assert len(raw)==9,raw
 for name in inventories['baseline']:
  first,second=(inventories[arm][name] for arm in ('baseline','candidate'))
  assert first['bytes']==second['bytes'] and Path(first['path']).read_bytes()==Path(second['path']).read_bytes(),name
 save(W/'probe-comparison.json',dict(status='PASS_ALL9_RAW_AND_COMPLETE_ROUTE_BOUNDARIES_EXACT',inventories=inventories,
  raw_count_per_arm=len(raw),raw_bytes_per_arm=sum(inventories['candidate'][name]['bytes'] for name in raw),
  all_files_byte_equal=True,scope='Existingdiagnostic graph,not defaultperf. Fullrelative file sets/rawbytes/route/boundaries compared;not everyproviderinstance export.'))
def main():
 plan=prepare();checks=[]
 for case,row in plan['cases'].items():
  reports={}
  for arm in row['arms']:reports[arm]=run(case,row,arm)
  if 'reference' in row:old=read(Path(row['reference']));old_pin=pin(Path(row['reference']));normal_old=None
  else:old=reports['baseline'];old_pin=pin(W/'runs/baseline'/case/'attempt1/report.json');normal_old=W/'runs/baseline'/case/'attempt1/probes' if row.get('probe') else None
  normal_new=W/'runs/candidate'/case/'attempt1/probes' if row.get('probe') else None
  differences=delta(stable(old,normal_old),stable(reports['candidate'],normal_new))
  result=dict(case=case,status='PASS' if not differences else 'FAIL',all_non_timing_fields_equal=not differences,differences=differences,
   baseline_or_retained_reference=old_pin,candidate=pin(W/'runs/candidate'/case/'attempt1/report.json'),fresh_pair='reference' not in row,
   normalization='Onlytime suffixes,plus explicitknownprobe outputroot whenapplicable. Allother paths/unknown/resource/work fields retained.')
  save(W/('compare-'+case+'.json'),result);assert not differences,differences
  if row.get('probe'):probes()
  checks.append(result);print('PASS PHASE CASE',case,flush=True)
 root_folder=Path(plan['root_receipt']);process=read(root_folder/'process.json');assert process['state']=='TERMINAL' and process['exit']==0
 if not (root_folder/'report.json').exists():parse(root_folder,'phase-preparation-cpu',{})
 root_result=read(root_folder/'report.json');assert root_result['status']=='PASS' and root_result['case']=='phase-preparation'
 save(W/'native-summary.json',dict(status='PASS_APPROVED26_NATIVE',checks=checks,bridge_native=25,root_native=1,total_native=26,
  root_phase_report=pin(root_folder/'report.json'),scope='Allacceptedcasesexit0;Sessioncompletebytes comparedseparately.'))
if __name__=='__main__':main()
