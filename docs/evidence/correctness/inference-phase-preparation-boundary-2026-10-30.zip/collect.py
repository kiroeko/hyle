"""Minimal Phase seal/archive/cleanupinventory. Neverexecute deletion."""
from pathlib import Path
import hashlib,importlib.util,json,subprocess,zipfile
W=Path(__file__).resolve().parent;R=W.parents[1]
spec=importlib.util.spec_from_file_location('phase_collect_build',W/'build.py')
h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
read,save,pin,exact=h.read,h.save,h.pin,h.exact
baseline=read(W/'baseline-plan.json');base=read(W/'model-link-base.json')
assert len(base['retained'])==231
for item in base['retained']:exact(item)
attempts=[]
for directory in ('compile','link','runs'):
 for path in sorted((W/directory).rglob('process.json')):
  p=read(path);assert p['state']=='TERMINAL' and p['exit']==0 and not p['timed_out']
  attempts.append(dict(name=path.parent.relative_to(W).as_posix(),actual=p,process=pin(path),command=pin(path.parent/'command.json')))
counts=dict(total=len(attempts),CXX=sum(row['name'].startswith('compile/') for row in attempts),links=sum(row['name'].startswith('link/') for row in attempts),native=sum(row['name'].startswith('runs/') for row in attempts))
assert counts==dict(total=37,CXX=5,links=6,native=26)
save(W/'process-inventory.json',attempts)
for path in sorted((W/'compile').glob('*/receipt.json')):
 receipt=read(path)
 for item in [receipt['object'],receipt['dependencies'],receipt['process'],*receipt['source_identities']]:exact(item)
source_proofs=[]
for name,row in baseline['consumers'].items():
 receipt=read(row['receipt']['path']);proofs=[]
 for item in receipt['source_identities']:
  path=Path(item['path'])
  if path.is_file() and path.stat().st_size==item['bytes'] and hashlib.sha256(path.read_bytes()).hexdigest()==item['sha256']:continue
  relative=path.relative_to(R);target=W/'baseline-source'/relative
  if not target.is_file():
   data=subprocess.check_output(['git','show',baseline['base_commit']+':'+relative.as_posix()],cwd=R)
   assert len(data)==item['bytes'] and hashlib.sha256(data).hexdigest()==item['sha256'];target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data)
  assert target.stat().st_size==item['bytes'] and hashlib.sha256(target.read_bytes()).hexdigest()==item['sha256']
  proofs.append(dict(original=item,exact_baseline_snapshot=pin(target)))
 source_proofs.append(dict(consumer=name,historical_source_proofs=proofs))
save(W/'baseline-source-proofs.json',source_proofs)
native=read(W/'native-summary.json');assert native['status']=='PASS_APPROVED26_NATIVE'
phase=read(W/'runs/candidate/phase-preparation-cpu/attempt1/report.json')
for key in ('allocation_budget_refusal_retry','failed_phase_unpublished','original_family_unchanged','phase_before_state_layout','state_before_phase_layout','warm_original_invocation','tracked_budget_live_restored'):assert phase[key] is True
assert phase['submitted_graphs']==phase['final_versions']==0
vectors=read(W/'session-vector-manifest.json');assert vectors['file_count_per_arm']==378 and vectors['bytes_per_arm']==150761472
payloads=[]
for name in vectors['arms']['baseline']:
 a,z=(vectors['arms'][arm][name] for arm in ('baseline','candidate'));exact(a);exact(z)
 with Path(a['path']).open('rb') as x,Path(z['path']).open('rb') as y:
  while True:
   u,v=x.read(1048576),y.read(1048576);assert u==v
   if not u:break
 payloads.extend([a,z])
probe=read(W/'probe-comparison.json');assert probe['raw_count_per_arm']==9 and probe['all_files_byte_equal']
for name in probe['inventories']['baseline']:
 a,z=(probe['inventories'][arm][name] for arm in ('baseline','candidate'));exact(a);exact(z)
 assert Path(a['path']).read_bytes()==Path(z['path']).read_bytes()
for arm in ('baseline','candidate'):
 payloads.extend(item for name,item in probe['inventories'][arm].items() if Path(name).suffix in ('.bf16','.f16','.f32','.bin'))
external=[]
for root in (R/'.scratch/inference-phase-preparation-extract-20261030',R/'.scratch/inference-phase-preparation-review-20261030',R/'.scratch/inference-phase-test-20261030'):
 for path in sorted(root.rglob('*')):
  if not path.is_file() or path.suffix not in ('.json','.md','.patch','.py'):continue
  if any(part in ('candidate','base','__pycache__','apply-check') for part in path.relative_to(root).parts):continue
  target=W/'external-evidence'/root.name/path.relative_to(root);target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(path.read_bytes());external.append(pin(target))
for case,row in read(W/'run-plan.json')['cases'].items():
 if not row.get('reference'):continue
 folder=Path(row['reference']).parent
 for name in ('report.json','stdout.log','stderr.log','command.json','process.json'):
  path=folder/name;target=W/'retained-factory-reference'/case/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(path.read_bytes())
whole=read(W/'whole-cli-summary.json');session=read(W/'session-compare.json');assert session['status']=='PASS_EXACT_COMPLETE_SESSION'
sources=read(W/'source-freeze.json')['sources']+read(W/'test-source-freeze.json')['sources']
for item in sources:exact(item)
final=R/'.scratch/inference-phase-preparation-extract-20261030/pending-six-source.json'
summary=dict(schema='hyle.inference-phase-preparation-boundary.v1',status='FINITE_PHASE_IO_CHECKS_PASS',full_goal_complete=False,
 base_commit=baseline['base_commit'],sources=sources,attempts=counts,failed_build_or_native=0,
 closure=dict(original_inputs=230,old_reused=230,new_phase=1,current_inputs=231,SDK_CXX=0,old_cold_CXX=0,consumer_CXX=3,phase_CXX=1,leaf_CXX=1,rows_rebuilt=False),
 native=dict(root_CPU=1,bridge=25,total=26,fresh_pairs=9,retained_reference_candidates=7,
  all_non_time_comparisons_exact=True,phase_CPU=phase),
 Session=dict(files_per_arm=378,bytes_per_arm=150761472,all_rehashed_and_direct_byte_equal=True,observation_equal_only_outputroot_normalized=True,final_versions=0),
 diagnostic_probe=dict(raw_count_per_arm=9,raw_bytes_per_arm=4608,all_raw_and_complete_route_boundaries_exact=True,only_explicit_output_root_normalized=True,default_performance=False),
 default_decode=[dict(case=row['case'],**row['timing_diagnostic']['decode_seconds']) for row in whole['checks']],
 actual_hardware=pin(W/'hardware-toolchain.json'),model_link_base=pin(W/'model-link-base.json'),process_inventory=pin(W/'process-inventory.json'),
 final_six_source_bundle=pin(final),
 limits=['Freshdefaultfourpairtimings arelimitedregression observations,not a stableperformancewindow.',
  'Sevenunchanged Factorycandidate reports/stdout retained as exacthistoricalreferences;theirbaselines notrerun.',
  'PhaseCPUfailure at firstcharged physicalallocation after coldslot/transaction preparation,not deliberately lateReadback failure.',
  'Trackedbudget live restoration,not wholeheap/native-private leak proof;noGraphsubmitted in PhaseCPUcase.',
  'DefaultJSON aggregateonly;probe routeexportsdo notcontain everyproviderinstance/physicalcopy property.',
  'ManualCXX/link,not fullnormalCMake/allplatform validation. No rows/optionalhead/trace/profile/download/NVCC retest.'],
 external_evidence=external)
save(W/'summary-draft.json',summary)
allow={'.py','.json','.log','.txt','.md','.patch','.cc','.h','.cmake','.tsv','.ids','.xml','.ps1'}
files=[path for path in sorted(W.rglob('*')) if path.is_file() and path.suffix in allow
 and not any(part in ('bin','tmp','__pycache__') for part in path.relative_to(W).parts)
 and path.name not in ('archive-receipt.json','cleanup-targets.json')]
archive=W/'evidence-draft.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as out:
 for path in files:out.write(path,path.relative_to(W).as_posix())
with zipfile.ZipFile(archive) as check:
 assert check.testzip() is None and len(check.namelist())==len(files)
 for path in files:assert check.read(path.relative_to(W).as_posix())==path.read_bytes()
save(W/'archive-receipt.json',dict(archive=pin(archive),members=len(files),all_members_readback_equal=True,summary=pin(W/'summary-draft.json'),raw_tensors_archived=False,
 public_names=['inference-phase-preparation-boundary-2026-10-30.json','inference-phase-preparation-boundary-2026-10-30.zip']))
cleanup=[pin(path) for path in sorted((W/'bin').rglob('*')) if path.is_file()]+payloads
save(W/'cleanup-targets.json',dict(status='PREPARED_NOT_EXECUTED',root=str(W),files=cleanup,count=len(cleanup),bytes=sum(item['bytes'] for item in cleanup),
 scope='Generatedbin+verifiedrawSession/probeonly;keepSource/objects/receipts/commands/originalcachedruntime. Rootowns test.ps1 review/deletion.'))
print(json.dumps(dict(processes=counts,retained=231,archive_bytes=archive.stat().st_size,members=len(files),sha256=pin(archive)['sha256'],cleanup_files=len(cleanup),cleanup_bytes=sum(item['bytes'] for item in cleanup)),ensure_ascii=False))
