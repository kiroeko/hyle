"""Phase preparation baseline only; no candidate compile/native authorization yet."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor,as_completed
import importlib.util,json,shutil,subprocess,sys
W=Path(__file__).resolve().parent;R=W.parents[1]
BASE=R/'.scratch/inference-family-factory-harness-20261030/model-link-base.json'
CANDIDATE=R/'.scratch/inference-phase-preparation-extract-20261030/plan.json'
spec=importlib.util.spec_from_file_location('phase_prior_build',BASE.parent/'build.py')
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
s=b.s;s.W=s.b.W=W
read,save,pin,exact,key=b.read,b.save,b.pin,b.exact,b.key
def snapshot():
 assert not (W/'baseline-plan.json').exists()
 base=read(BASE);candidate=read(CANDIDATE)
 head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()
 assert head=='910a094b75286fa57258c84e49be90015aea174e'
 for item in candidate['seven_source_base']:exact(item)
 for relative in ('engine/models/qwen35/phase.h','engine/models/qwen35/phase_preparation.cc'):assert not (R/relative).exists()
 assert not subprocess.check_output(['git','diff','--name-only','--','include','src','engine','tests'],cwd=R,text=True).strip()
 for item in [*base['retained'],base['runtime']]:exact(item)
 assert len(base['retained'])==230
 copies=[]
 for item in candidate['seven_source_base']:
  target=W/'baseline-source'/item['relative'];target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(Path(item['path']).read_bytes())
  copies.append(dict(original=item,snapshot=pin(target)))
 consumers={}
 for name in ('cli','tiny','session','rows'):
  row=base['current_consumers'][name];receipt=read(row['receipt']['path'])
  for item in [row['receipt'],receipt['object'],*receipt['source_identities']]:exact(item)
  consumers[name]=dict(receipt=row['receipt'],object=receipt['object'],source_identities=receipt['source_identities'])
 changed={key(R/item['relative']) for item in candidate['candidate']}
 sdk=read(base['sdk_engine_dependencies']['path']);affected=[]
 for row in sdk['inspected']:
  dep=read(row['dependencies']['path'])['Data']
  if any(key(path) in changed for path in [dep['Source'],*dep['Includes']]):affected.append(row)
 assert not affected,affected
 consumer_changes={name:[item['path'] for item in row['source_identities'] if key(item['path']) in changed] for name,row in consumers.items()}
 assert all(consumer_changes[name] for name in ('cli','tiny','session')) and not consumer_changes['rows']
 save(W/'baseline-plan.json',dict(status='EXACT_BASELINE230_SOURCE_SNAPSHOT_NO_CXX_NATIVE',base_commit=head,base=pin(BASE),
  candidate_plan_at_snapshot=pin(CANDIDATE),candidate_observed_oldHEAD_not_used_as_guard=candidate['observed_product_HEAD'],
  seven_source_base_byte_exact=True,snapshots=copies,retained=base['retained'],runtime=base['runtime'],
  consumers=consumers,original_link=base['link'],original_consumer=base['current_consumers']['cli']['object'],
  predicted_affected_retained=affected,predicted_consumer_changed_pins=consumer_changes,
  available_dependency_rows=len(sdk['inspected']),unavailable_dependency_metadata=sdk['unavailable'],
  predicted_new_phase_objects=1,predicted_candidate_inputs=231,expected_existing_cold_CXX=0,expected_SDK_CXX=0,
  CXX=0,native=0,NVCC=0,downloads=0,scope='Actual current230 andseven sourcepins,neverreject solelybecause planobserved9496. Keeprows exactcurrent object ifits sourceclosure stayssame. Root selects finitePhaseIO cases later;no mechanical34rerun.'))
 (W/'bin').mkdir(exist_ok=True);shutil.copyfile(base['runtime']['path'],W/'bin'/Path(base['runtime']['path']).name)
 print(json.dumps(dict(status='PHASE_BASELINE_SOURCE_READY',HEAD=head,retained=230,source_snapshots=len(copies),
  old_retained_affected=0,consumers_recompile=['cli','tiny','session'],rows_reusable=True,
  source_pins={name:len(row['source_identities']) for name,row in consumers.items()})),flush=True)
def link_baseline(name,attempt):
 baseline=read(W/'baseline-plan.json');consumer=baseline['consumers'][name]
 for item in [consumer['object'],*baseline['retained'],baseline['runtime']]:exact(item)
 args=[];count=0
 for arg in baseline['original_link']:
  if key(arg)==key(baseline['original_consumer']['path']):arg=consumer['object']['path'];count+=1
  for prefix,suffix in [('/OUT:','.exe'),('/PDB:','.pdb'),('/IMPLIB:','.lib'),('/MAP:','.map')]:
   if arg.upper().startswith(prefix):arg=prefix+str((W/'bin'/('baseline-'+name)).with_suffix(suffix));break
  args.append(arg)
 assert count==1
 s.b.execute(args,W/'link'/('baseline-'+name)/attempt,240)
 save(W/('ready-baseline-'+name+'.json'),pin(W/'bin'/('baseline-'+name+'.exe')))
def prepare():
 assert not (W/'plan.json').exists()
 baseline=read(W/'baseline-plan.json');base=read(BASE);candidate=read(CANDIDATE);frozen=[]
 for item in candidate['candidate']:
  exact(item);actual=pin(R/item['relative']);assert all(actual[field]==item[field] for field in ('bytes','sha256'));frozen.append(actual)
 sdk=read(base['sdk_engine_dependencies']['path']);changed={key(item['path']) for item in frozen};affected=[]
 for row in sdk['inspected']:
  dep=read(row['dependencies']['path'])['Data']
  if any(key(path) in changed for path in [dep['Source'],*dep['Includes']]):affected.append(row)
 assert not affected,affected
 phase=R/'engine/models/qwen35/phase_preparation.cc'
 wrapper=W/'cli.cc';wrapper.write_text('#include "../../engine/models/qwen35/main.cc"\nint main(int argc,char **argv){return qwen35::run(argc,argv);}\n')
 leaf=W/'phase-header.cc';leaf.write_text('#include "../../engine/models/qwen35/phase.h"\n')
 sources=dict(phase=phase,leaf=leaf,cli=wrapper,session=R/'engine/models/qwen35/mtp_session_probe.cc',tiny=R/'tests/tools/qwen_host_image_test.cc')
 units={name:dict(source=str(source),compile=s.relocated(base['compile'],name,source)) for name,source in sources.items()}
 copies=[]
 for item in frozen:
  target=W/'source-frozen'/Path(item['path']).relative_to(R);target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(Path(item['path']).read_bytes());copies.append(pin(target))
 save(W/'source-freeze.json',dict(sources=frozen,snapshots=copies,candidate_plan=pin(CANDIDATE)))
 save(W/'plan.json',dict(base=pin(BASE),baseline=pin(W/'baseline-plan.json'),source_freeze=pin(W/'source-freeze.json'),
  units=units,retained=base['retained'],runtime=base['runtime'],actual_affected_retained=affected,
  available_dependency_rows=len(sdk['inspected']),unavailable_dependency_metadata=sdk['unavailable'],
  SDK_CXX=0,existing_model_cold_CXX=0,new_phase_CXX=1,leaf_CXX=1,consumer_CXX=3,max_compilers=2,NVCC=0,downloads=0,
  candidate_inputs=231,original_link=base['link'],original_consumer=base['current_consumers']['cli']['object'],
  tiny_deferred_until_root_test_freeze=True,rows_reused=base['current_consumers']['rows']))
 print('PREPARED0old replacements,newphase1,leaf1,CLI/Session/tiny3;rowsunchanged;no native.',flush=True)
def compile(attempt,names):
 plan=read(W/'plan.json')
 def one(name):
  unit=plan['units'][name];s.b.execute(unit['compile'],W/'compile'/name/attempt,600)
  dep=read(W/'compile'/name/'dependencies.json')['Data']
  paths=sorted({Path(path).resolve() for path in [dep['Source'],*dep['Includes']] if Path(path).is_relative_to(R)})
  save(W/'compile'/name/'receipt.json',dict(object=pin(W/'compile'/name/'unit.obj'),dependencies=pin(W/'compile'/name/'dependencies.json'),
   process=pin(W/'compile'/name/attempt/'process.json'),source_identities=[pin(path) for path in paths]))
  print('COMPILED',name,flush=True)
 with ThreadPoolExecutor(max_workers=2) as pool:
  futures={pool.submit(one,name):name for name in names}
  for future in as_completed(futures):future.result()
def link(name,attempt):
 plan=read(W/'plan.json');consumer=read(W/'compile'/name/'receipt.json');phase=read(W/'compile/phase/receipt.json')
 for item in [consumer['object'],*consumer['source_identities'],phase['object'],*phase['source_identities'],*plan['retained']]:exact(item)
 args=[];count=0
 for arg in plan['original_link']:
  if key(arg)==key(plan['original_consumer']['path']):arg=consumer['object']['path'];count+=1
  for prefix,suffix in [('/OUT:','.exe'),('/PDB:','.pdb'),('/IMPLIB:','.lib'),('/MAP:','.map')]:
   if arg.upper().startswith(prefix):arg=prefix+str((W/'bin'/name).with_suffix(suffix));break
  args.append(arg)
 assert count==1 and not any(key(arg)==key(phase['object']['path']) for arg in args);args.append(phase['object']['path'])
 assert len(plan['retained'])+1==231
 s.b.execute(args,W/'link'/name/attempt,240);save(W/('ready-'+name+'.json'),pin(W/'bin'/(name+'.exe')))
if __name__=='__main__':
 if sys.argv[1]=='snapshot':snapshot()
 elif sys.argv[1]=='link-baseline':link_baseline(sys.argv[2],sys.argv[3])
 elif sys.argv[1]=='prepare':prepare()
 elif sys.argv[1]=='compile':compile(sys.argv[2],sys.argv[3:])
 elif sys.argv[1]=='link':link(sys.argv[2],sys.argv[3])
 else:raise ValueError(sys.argv[1])
