from pathlib import Path
import hashlib,json,subprocess
root=Path(__file__).resolve().parents[2];batch=Path(__file__).resolve().parent
test=json.loads((batch/'plan.json').read_text(encoding='utf-8'))
phase_batch=root/'.scratch/inference-phase-preparation-extract-20261030'
phase=json.loads((phase_batch/'plan.json').read_text(encoding='utf-8'))
pins=[]
for item in phase['candidate']:
    data=(root/item['relative']).read_bytes();assert hashlib.sha256(data).hexdigest()==item['sha256']
    pins.append(dict(relative=item['relative'],bytes=len(data),sha256=item['sha256']))
for item in test['files']:
    data=(root/item['relative']).read_bytes();assert hashlib.sha256(data).hexdigest()==item['candidate_sha256']
    pins.append(dict(relative=item['relative'],bytes=len(data),sha256=item['candidate_sha256']))
artifacts=[]
for path in [batch/'independent-review.json',batch/'independent-review.py',root/'.scratch/inference-phase-preparation-review-20261030/independent-candidate-review.json',root/'.scratch/inference-phase-preparation-review-20261030/review-candidate.py']:
    data=path.read_bytes();artifacts.append(dict(path=str(path),bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
summary=dict(status='STATIC_ROOT_SUMMARY_PREPARED_PENDING_BRIDGE_RUNTIME',head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),
    applied_by_root_exact_six_source_pins=pins,static_reviews=artifacts,
    source_proof=dict(original_Phase_type_layout_tokens_equal=True,original_physical_body_projected_tokens=2989,complete_main_inverse_bytes_equal=True,original_IO_registration_order_equal=True),
    architecture_scope='Direct model-private cold Phase construction only. Model retains admission, state layout timing, route diagnostics, shared preparation scratch, map publication, Invocation initialization and recovery.',
    test_scope='Real original shared requested-byte budget refusal in prepare_child before Invocation initialization, same-key rebuild, late/early real state layouts, warm original Invocation under pressure. Zero model Graph submissions.',
    limits=['Only tracked ResourceBudget live charge restoration, not whole heap/std::vector/native-private leak coverage.','First charged physical allocation failure, not deliberate late readback fault.','Warm/closing/actually-retired base semantics remain covered by existing program-carrier, not duplicated in new case.','No build/native result asserted by this source seal; bridge owns actual receipts.'],
    builds_by_this_agent=0,native_runs_by_this_agent=0,product_edits_by_this_agent=0)
(batch/'root-summary-static.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
permission_root=root/'.scratch/inference-phase-preparation-review-20261030'
permission_files=['engine/models/qwen35/main.cc','engine/models/qwen35/phase.h','engine/models/qwen35/phase_preparation.cc','engine/inference/program_io.h','engine/inference/program_slots.h','engine/inference/program_carrier.h']
permission_pins=[]
for relative in permission_files:
    data=(root/relative).read_bytes();permission_pins.append(dict(relative=relative,bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
(permission_root/'permission-source-pins.json').write_text(json.dumps(dict(status='READ_ONLY_DYNAMIC_PERMISSION_BOUNDARY',line_scope='Observed Phase-applied working tree, not 910a blob',head=summary['head'],sources=permission_pins),indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(status=summary['status'],source_pins=len(pins),review_pins=len(artifacts))))
