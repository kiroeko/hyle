from pathlib import Path
import hashlib,json
W=Path(__file__).resolve().parent;R=W.parents[1]
def pin(p):
 p=Path(p);b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def once(s,a,b):
 if '\r\n' in s:
  a=a.replace('\r\n','\n').replace('\n','\r\n');b=b.replace('\r\n','\n').replace('\n','\r\n')
 assert s.count(a)==1,(s.count(a),a[:100]);return s.replace(a,b,1)
plan=json.loads((W/'plan.json').read_text())
assert pin(W/'phase-test.patch')['sha256']=='eab60fa9b2006742558ec82385c43bc098b7c0c756af26aeddf875b4cbf8efcf'
for e in plan['files']:
 assert pin(W/'candidate'/e['relative'])['sha256']==e['candidate_sha256']
rel='tests/tools/qwen_host_image_test.cc'
old=(W/'base'/rel).read_bytes();new=(W/'candidate'/rel).read_bytes()
s=new.decode()
s=once(s,'#include "qwen_phase_preparation_case.h"\n','')
s=once(s,'    const bool phase_preparation = argc >= 3 && std::string_view(argv[argc - 1]) == "--phase-preparation";\n','')
s=once(s,' || phase_preparation || publication_retirement',' || publication_retirement')
s=once(s,'|--phase-preparation|--publication-retirement','|--publication-retirement')
s=once(s,'''    if (phase_preparation) {
      if (backend != qwen35::BackendKind::kCpu)
        throw std::runtime_error("phase-preparation case requires its CPU budget fixture");
      return qwen_phase_preparation_case::run(input);
    }
''','')
assert s.encode()==old
d=dict(status='PASS_INDEPENDENT_STATIC_PHASE_TEST_REVIEW_NOT_CXX',
 patch=pin(W/'phase-test.patch'),files=[pin(W/'candidate'/e['relative']) for e in plan['files']],
 original_dispatch_inverse_five_changes_bytes_exact=True,
 checks=[
  'CPU memory_resource returns system_resource and test checks actual Backend.device identity before using that resource for budget pressure.',
  'Existing Model(Backend&&,sharedBudget,...) gives real allocation/execution/cache-metadata budget coupling. Full original Family is prepared first; first Phase Tensor/LeasePool charge must genuinely fail under reservation.',
  'Failed physical candidate cannot publish Phase/version/loan or replace original Family/child; only tracked ResourceBudget live restoration is asserted.',
  'GA fixture has actual recurrent and attention layers; state_banks nonempty and writer_bytes0 proves no layout attached before state storage. Actual prepare_state_storage occurs before comparing full plan payload, then a second Phase checks state-first attachment.',
  'Slots prepare is checked complete and uninitialized; real initialize_slot creates original Invocations, then full budget pressure tests same warm object identities and zero new tracked charge without submitting a Graph.',
  'Model/cache/Backend/Scope original lifetime ordering is preserved; no fake native result, new owner or progress callback is installed by the test.',
  'Old dispatcher modes restore exact original bytes. New CPU-only flag does not change their parameter interpretation when absent.'
 ],
 limits=['No native/CXX run by this reviewer; real64MiB fixture sufficiency remains a run result.',
  'Refusal covers first charged physical allocation, not a deliberate late-readback fault.',
  'Tracked-live restoration is not proof for whole heap/native-private allocation leakage.',
  'No submitted Graph; closing/reset/actual retirement require existing program-carrier tests, not these warm assertions.'],
 product_edits=0,candidate_edits=0,builds=0,native_runs=0)
(W/'independent-review.json').write_text(json.dumps(d,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
print(json.dumps(dict(status=d['status'],dispatcher_inverse_exact=True,patch_sha256=d['patch']['sha256'])))
