from pathlib import Path
import hashlib,json,subprocess
root=Path(__file__).resolve().parents[2];batch=Path(__file__).resolve().parent
relative='tests/tools/qwen_host_image_test.cc';original=(root/relative).read_bytes()
newline='\r\n' if b'\r\n' in original else '\n';text=original.decode('utf-8');changes=[]
edits=[
 ('#include "qwen_cold_family_case.h"','#include "qwen_cold_family_case.h"\n#include "qwen_phase_preparation_case.h"'),
 ('    const bool cold_family = argc >= 3 && std::string_view(argv[argc - 1]) == "--cold-family";',
  '    const bool cold_family = argc >= 3 && std::string_view(argv[argc - 1]) == "--cold-family";\n    const bool phase_preparation = argc >= 3 && std::string_view(argv[argc - 1]) == "--phase-preparation";'),
 (' || cold_family || publication_retirement);',' || cold_family || phase_preparation || publication_retirement);'),
 ('|--cold-family|--publication-retirement]','|--cold-family|--phase-preparation|--publication-retirement]'),
 ('    if (cold_family) {','    if (phase_preparation) {\n      if (backend != qwen35::BackendKind::kCpu)\n        throw std::runtime_error("phase-preparation case requires its CPU budget fixture");\n      return qwen_phase_preparation_case::run(input);\n    }\n    if (cold_family) {')]
for before,after in edits:
    after=after.replace('\n',newline);assert text.count(before)==1
    text=text.replace(before,after,1);changes.append((before,after))
restored=text
for before,after in reversed(changes):assert restored.count(after)==1;restored=restored.replace(after,before,1)
assert restored.encode('utf-8')==original
for folder,data in [('base',original),('candidate',text.encode('utf-8'))]:
    target=batch/folder/relative;target.parent.mkdir(parents=True,exist_ok=True)
    if target.exists():assert target.read_bytes()==data
    else:target.write_bytes(data)
items=[];patches=[]
for rel in [relative,'tests/tools/qwen_phase_preparation_case.h']:
    a=batch/'base'/rel;b=batch/'candidate'/rel
    data=b.read_bytes();base=a.read_bytes() if a.exists() else None
    diff=subprocess.run(['git','diff','--no-index','--no-ext-diff','--binary','--',str(a) if a.exists() else 'NUL',str(b)],cwd=root,capture_output=True)
    assert diff.returncode==1
    lines=diff.stdout.decode('utf-8').splitlines(keepends=True)
    for n,line in enumerate(lines):
        if line.startswith('diff --git '):lines[n]=f'diff --git a/{rel} b/{rel}\n'
        elif line.startswith('--- ') and base is not None:lines[n]=f'--- a/{rel}\n'
        elif line.startswith('+++ '):lines[n]=f'+++ b/{rel}\n'
    patches.append(''.join(lines));items.append(dict(relative=rel,base_sha256=hashlib.sha256(base).hexdigest() if base else None,base_bytes=len(base) if base else None,candidate_bytes=len(data),candidate_sha256=hashlib.sha256(data).hexdigest()))
patch=''.join(patches).encode('utf-8');path=batch/'phase-test.patch';path.write_bytes(patch)
check=subprocess.run(['git','apply','--check',str(path)],cwd=root,capture_output=True);assert check.returncode==0,check.stderr.decode('utf-8',errors='replace')
report=dict(status='SCRATCH_TEST_CANDIDATE_UNAPPLIED_UNBUILT',files=items,patch=dict(path=str(path),bytes=len(patch),sha256=hashlib.sha256(patch).hexdigest()),original_dispatcher_inverse_exact=True,git_apply_check=True,flag='--cpu GA_INPUT --phase-preparation',limits=['Tracked ResourceBudget live restoration only, not whole-heap or native-private leak proof.','Refusal happens at first charged physical allocation after cold slot/transaction preparation, not a deliberate late-readback failure.','No Graph submitted; closing/retired recipe details remain covered by existing --program-carrier.'],product_edits=0,builds=0,native_runs=0)
(batch/'plan.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(files=items,patch=report['patch'])))
