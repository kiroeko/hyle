"""Static source proof; do not infer CXX/native success."""
from pathlib import Path
import hashlib,json,re
W=Path(__file__).resolve().parent;R=W.parents[1];REL='engine/models/qwen35/'
def read(root,name):return (root/(REL+name)).read_text(encoding='utf-8-sig')
def part(s,a,b):
 i=s.index(a);return s[i:s.index(b,i)]
def once(s,a,b):
 assert s.count(a)==1,(s.count(a),a[:100]);return s.replace(a,b,1)
def pin(p):
 p=Path(p);raw=p.read_bytes();return dict(path=str(p),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def tokens(s):
 return [m.group() for m in re.finditer(r'"(?:\\.|[^"\\])*"|\'(?:\\.|[^\'\\])*\'|//[^\n]*|/\*[\s\S]*?\*/|[A-Za-z_]\w*|\d+(?:\.\d*)?|\S',s)
  if not m.group().startswith(('//','/*'))]
old=read(W/'base','main.cc');new=read(W/'candidate','main.cc')
header=read(W/'candidate','phase.h');source=read(W/'candidate','phase_preparation.cc')
old_method=part(old,'  Phase &prepare_child(', '  // An engine with a known ordered request')
new_method=part(new,'  Phase &prepare_child(', '  // An engine with a known ordered request')
old_body=part(old_method,'    auto result = std::make_unique<Phase>();','    if (state_storage_prepared) prepare_transaction_layouts(phase);')
body=part(source,'    auto result = std::make_unique<Phase>();','  return result;')
eligibility=part(old_body,'    if (imported_sources) {','    phase.query_rows = tokens;')
restored=once(body,'    auto &phase = *result;\n','    auto &phase = *result;\n    std::size_t physical_slots = 1;\n')
restored=once(restored,'    phase.query_rows = tokens;\n',eligibility+'    phase.query_rows = tokens;\n')
restored=once(restored,'    const auto &planned_slot_uses = preparation.planned_uses;\n',
 '    const auto planned_slot_uses = shape_plan.uses({requests, tokens, role, completion, sampling_index, false, packing});\n')
restored=once(restored,'phase.child = &selection.child;','phase.child = &selected->program;')
restored=once(restored,'      program_slot.replay_mode = preparation.replay_modes[slot];\n',
 '''      program_slot.replay_mode = !selected_sampler.modifiers.history.empty() ? g::ReplayMode::kCommands
          : imported_sources ? g::ReplayMode::kPreferCapture : select_replay_mode(
          replay_policy, program_slot.planned_uses, selected_sampler.enabled);
''')
restored=restored.replace('phase_tensor(allocation_budget, ','caller_tensor(')
assert restored==old_body, 'Physical body projection did not restore exact original text'
types=part(old,'// Physical IO/control carriers are independent of candidate depth.','// One original Graph episode owns all dirty pages')
assert types in header
roundtrip=once(new,'#include "phase.h"\n','')
roundtrip=once(roundtrip,'// One original Graph episode owns all dirty pages',types+'// One original Graph episode owns all dirty pages')
roundtrip=once(roundtrip,new_method,old_method)
assert roundtrip==old,'Complete main inverse failed'
# No original admission/trace/layout/shared-scratch/publish/initialization/recovery body changes.
tail='    if (state_storage_prepared) prepare_transaction_layouts(phase);'
assert new_method[new_method.index(tail):]==old_method[old_method.index(tail):]
for begin,end in (('  Phase::ExecutionSlots::Initialization slot_initialization(', '  Phase &prepare_child('),
                  ('  void prepare_transaction_layouts(', '  bool prepare_family(')):
 assert part(old,begin,end)==part(new,begin,end)
suffix='  // An engine with a known ordered request'
assert old[old.index(suffix):]==new[new.index(suffix):]
# The old pure replay formula is evaluated by Model, not via a callback in factory.
assert '''      replay_modes[slot] = !selected_sampler.modifiers.history.empty() ? g::ReplayMode::kCommands
          : imported_sources ? g::ReplayMode::kPreferCapture : select_replay_mode(
          replay_policy, planned_slot_uses[slot], selected_sampler.enabled);''' in new_method
assert 'scheduler' not in source and 'workers' not in source and 'execution_budget' not in source
assert 'initialize(' not in source and '.submit(' not in source
assert 'std::function' not in header+source and 'virtual ' not in header+source
assert 'struct ColdResources;' in header and 'struct ColdResources final' not in header+source
assert 'return Tensor(resource, description, caller, budget);' in source
assert body.count('phase_tensor(allocation_budget, ')==old_body.count('caller_tensor(')
assert source.index('auto result = std::make_unique<Phase>()')<source.index('phase.slots.prepare(')<source.index('program_slot.io.seal()')<source.index('  return result;')

def closure(rel):
 found,missing={},[]
 def visit(rel):
  rel=Path(rel).as_posix()
  if rel in found:return
  p=W/'candidate'/rel
  if not p.is_file():p=R/rel
  if not p.is_file():missing.append(rel);return
  found[rel]=pin(p)
  for inc in re.findall(r'^\s*#\s*include\s*"([^"]+)"',p.read_text(encoding='utf-8-sig'),re.M):
   dst=R/'include'/inc if inc.startswith('hyle/') else R/Path(rel).parent/inc
   try:child=dst.resolve().relative_to(R).as_posix()
   except ValueError:continue
   visit(child)
 visit(rel)
 assert not missing,missing
 forbidden=[p for p in found if p in (REL+'main.cc',REL+'session_state.h',REL+'session_schedule.h')]
 assert not forbidden,forbidden
 return dict(count=len(found),forbidden_Qwen_runtime_headers=forbidden,pins=list(found.values()))

closures={n:closure(REL+n) for n in ('phase.h','phase_preparation.cc')}
inventory=read(W/'candidate','cold_sources.cmake');old_inventory=read(W/'base','cold_sources.cmake')
assert inventory.replace('  "${CMAKE_CURRENT_LIST_DIR}/family_factory.cc"\n  "${CMAKE_CURRENT_LIST_DIR}/phase_preparation.cc")',
 '  "${CMAKE_CURRENT_LIST_DIR}/family_factory.cc")')==old_inventory
plan=json.loads((W/'plan.json').read_text())
for e in plan['seven_source_base']:
 assert pin(R/e['relative'])['sha256']==e['sha256'],e['relative']
assert all(not (R/e['relative']).exists() for e in plan['new_file_preconditions'])
report=dict(status='PASS_STATIC_PHASE_BODY_LAYOUT_PORT_RESOURCE_ORDER_NOT_CXX',
 source_base=plan['seven_source_base'],candidate=plan['candidate'],
 original_physical_body_exact_after_explicit_fact_projection=True,
 physical_body_tokens=len(tokens(old_body)),
 original_Phase_types_layout_defaults_comments_exact=True,
 complete_main_inverse_original_text_exact=True,
 original_Model_tail_layout_trace_scratch_publication_exact=True,
 original_initialization_and_transaction_layout_functions_exact=True,
 original_remaining_main_suffix_bytes=len(old[old.index(suffix):].encode()),
 original_remaining_main_suffix_exact=True,
 original_tensor_allocation_call_count=old_body.count('caller_tensor('),
 original_add_readback_count=old_body.count('.add_readback('),
 original_fixed_registration_order_and_seal=True,
 selected_output_storage_and_complete_readback_domains_unchanged=True,
 cache_budget_scope='Original SlotTransactionSpec option copied for later SlotBindings; no claim std::vector allocations are newly budget charged.',
 no_Invocation_progress_or_submit_in_factory=True,
 original_ProgramSlots_Scope_and_destruction_order=True,
 closures=closures,
 intentional_host_order_change='Model evaluates imported eligibility/planned uses/pure replay modes before unpublished Phase allocation; no Session/native/cache/head publication.',
 limits=['No CXX/link/native validation. Scope-incomplete compilation must be checked by authorized harness.',
         'Source cold-boundary proof does not establish physical high-water or runtime speed.',
         'This is Qwen physical preparation, not a universal model phase or new recovery/owner mechanism.'])
(W/'static-report.json').write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
print(json.dumps(dict(status=report['status'],tokens=report['physical_body_tokens'],
 closure_counts={k:v['count'] for k,v in closures.items()},tensor_calls=report['original_tensor_allocation_call_count'],
 readbacks=report['original_add_readback_count'])))
