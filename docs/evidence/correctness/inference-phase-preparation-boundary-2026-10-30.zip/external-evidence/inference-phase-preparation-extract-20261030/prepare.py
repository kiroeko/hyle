"""Prepare one Qwen physical Phase factory in scratch; no product mutation."""
from pathlib import Path
import difflib,hashlib,json,subprocess

W=Path(__file__).resolve().parent;R=W.parents[1]
MAIN='engine/models/qwen35/main.cc'
INVENTORY='engine/models/qwen35/cold_sources.cmake'
HEADER='engine/models/qwen35/phase.h'
SOURCE='engine/models/qwen35/phase_preparation.cc'
family_seal=R/'.scratch/inference-family-factory-extract-20261030/pending-seven-source-final.json'
def pin(p):
 p=Path(p);raw=p.read_bytes();return dict(path=str(p),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def part(s,a,b):
 i=s.index(a);return s[i:s.index(b,i)]
def once(s,a,b):
 assert s.count(a)==1,(s.count(a),a[:100]);return s.replace(a,b,1)
def preserve(src,dst):
 dst.parent.mkdir(parents=True,exist_ok=True)
 if dst.exists():assert dst.read_bytes()==src.read_bytes()
 else:dst.write_bytes(src.read_bytes())
def load(rel):
 preserve(R/rel,W/'base'/rel)
 return (R/rel).read_bytes().decode().replace('\r\n','\n')
def write(rel,text):
 p=W/'candidate'/rel;p.parent.mkdir(parents=True,exist_ok=True)
 raw=(R/rel).read_bytes() if (R/rel).is_file() else b'\r\n'
 p.write_bytes(text.replace('\n','\r\n').encode() if b'\r\n' in raw else text.encode())

sourcebase=json.loads(family_seal.read_text())
for entry in sourcebase['final_sources']:
 assert pin(entry['path'])['sha256']==entry['sha256'],entry['relative']
 preserve(R/entry['relative'],W/'base'/entry['relative'])
main,inventory=load(MAIN),load(INVENTORY)
assert not (R/HEADER).exists() and not (R/SOURCE).exists()
types=part(main,'// Physical IO/control carriers are independent of candidate depth.', '// One original Graph episode owns all dirty pages')
original=part(main,'  Phase &prepare_child(', '  // An engine with a known ordered request')
physical=part(original,'    auto result = std::make_unique<Phase>();', '    if (state_storage_prepared) prepare_transaction_layouts(phase);')
eligibility=part(physical,'    if (imported_sources) {','    phase.query_rows = tokens;')
# Eligibility is the first imported block only, before all physical preparation.
assert eligibility.count('physical_slots = execution_slot_count;')==1
planned='    const auto planned_slot_uses = shape_plan.uses({requests, tokens, role, completion, sampling_index, false, packing});\n'
replay='''      program_slot.replay_mode = !selected_sampler.modifiers.history.empty() ? g::ReplayMode::kCommands
          : imported_sources ? g::ReplayMode::kPreferCapture : select_replay_mode(
          replay_policy, program_slot.planned_uses, selected_sampler.enabled);
'''
body=once(physical,'    std::size_t physical_slots = 1;\n','')
body=once(body,eligibility,'')
body=once(body,planned,'    const auto &planned_slot_uses = preparation.planned_uses;\n')
body=once(body,'phase.child = &selected->program;', 'phase.child = &selection.child;')
body=once(body,replay,'      program_slot.replay_mode = preparation.replay_modes[slot];\n')
body=body.replace('caller_tensor(', 'phase_tensor(allocation_budget, ')

header='''#pragma once

// Qwen's original mutable physical carriers and their one cold preparation.
// ColdResources is the existing retirement scope, not a new owner here.
#include <array>
#include <cstddef>
#include <cstdint>
#include <memory>
#include <span>
#include <vector>

#include "family_factory.h"
#include "../../inference/program_slots.h"
#include "hyle/graph/batch.h"

namespace qwen35 {
struct ColdResources;
using inference::PreparedOutputFacts;

'''+types+'''struct PhaseSelection final {
  const Family &family;
  const inference::PreparedProgram &child;
  const SamplingConfiguration &sampling;
};
struct PhasePrepareFacts final {
  std::size_t tokens = 0, physical_slots = 1;
  bool diagnostic = false, imported_sources = false;
  std::array<std::size_t, execution_slot_count> planned_uses{};
  std::array<g::ReplayMode, execution_slot_count> replay_modes{};
};
struct PhaseEnvironment final {
  const inference::Backend &execution;
  const ModelGeometry &geometry;
  std::span<const StateSchema> recurrent_descriptions;
  const c::ResourceBudget &allocation_budget;
  // Original options for later SlotBindings::create; ordinary vector metadata
  // inside SlotTransactions::prepare is not newly charged by this handle.
  const c::ResourceBudget &cache_budget;
};

// Synchronously create the original stable IO/slot group; do not initialize an
// Invocation. Model keeps policy, state-layout attachment, scratch and publish.
std::unique_ptr<Phase> prepare_phase(const PhaseSelection &selection,
    const PhasePrepareFacts &preparation, const PhaseEnvironment &environment);

} // namespace qwen35
'''
source='''// Original Qwen physical Phase construction, separate from model policy and
// per-step admission/submission. Only the existing ProgramSlots are prepared.
#include "phase.h"

#include <algorithm>
#include <cstdint>
#include <optional>
#include <ranges>
#include <utility>

#include "../../inference/backend.h"

namespace qwen35 {
namespace {
Tensor phase_tensor(const c::ResourceBudget &budget, mem::MemoryResourceRef resource,
                   c::TensorDesc description, bool caller = true) {
  return Tensor(resource, description, caller, budget);
}
} // namespace

std::unique_ptr<Phase> prepare_phase(const PhaseSelection &selection,
    const PhasePrepareFacts &preparation, const PhaseEnvironment &environment) {
  const auto &definition = selection.family;
  const auto &selected_sampler = selection.sampling;
  const auto &execution = environment.execution;
  const auto &geometry = environment.geometry;
  const auto state_schema = environment.recurrent_descriptions;
  const auto &allocation_budget = environment.allocation_budget;
  const auto &cache_budget = environment.cache_budget;
  const auto tokens = preparation.tokens, physical_slots = preparation.physical_slots;
  const auto requests = definition.requests;
  const auto role = definition.role;
  const auto completion = definition.completion;
  const auto packing = definition.packing;
  const auto diagnostic = preparation.diagnostic, imported_sources = preparation.imported_sources;
  const bool compact_draft = packs_draft(packing);
  const bool packed_verify = packs_verify(packing), packed_target = packs_target(packing);
'''+body+'''  return result;
}

} // namespace qwen35
'''

prefix=original[:original.index('    auto result = std::make_unique<Phase>();')]
# These three layout booleans belong to the moved physical recipe, not policy.
prefix=once(prefix,'    const bool compact_draft = packs_draft(packing);\n    const bool packed_verify = packs_verify(packing), packed_target = packs_target(packing);\n','')
tail=original[original.index('    if (state_storage_prepared) prepare_transaction_layouts(phase);'):]
replacement=prefix+'''    std::size_t physical_slots = 1;
'''+eligibility+planned+'''    std::array<g::ReplayMode, execution_slot_count> replay_modes{};
    for (std::size_t slot = 0; slot < physical_slots; ++slot)
      replay_modes[slot] = !selected_sampler.modifiers.history.empty() ? g::ReplayMode::kCommands
          : imported_sources ? g::ReplayMode::kPreferCapture : select_replay_mode(
          replay_policy, planned_slot_uses[slot], selected_sampler.enabled);
    auto result = prepare_phase({definition, selected->program, selected_sampler},
        {tokens, physical_slots, diagnostic, imported_sources, planned_slot_uses, replay_modes},
        {execution, geometry, state_schema, allocation_budget, cache_budget});
    auto &phase = *result;
'''+tail
main=once(main,original,replacement)
main=once(main,types,'')
main=once(main,'#include "family_factory.h"\n','#include "family_factory.h"\n#include "phase.h"\n')
inventory=once(inventory,'  "${CMAKE_CURRENT_LIST_DIR}/family_factory.cc")','  "${CMAKE_CURRENT_LIST_DIR}/family_factory.cc"\n  "${CMAKE_CURRENT_LIST_DIR}/phase_preparation.cc")')
for rel,text in ((MAIN,main),(INVENTORY,inventory),(HEADER,header),(SOURCE,source)):write(rel,text)

files=[MAIN,INVENTORY,HEADER,SOURCE];patch=''
for rel in files:
 old=(W/'base'/rel).read_bytes().decode() if (W/'base'/rel).is_file() else ''
 new=(W/'candidate'/rel).read_bytes().decode()
 patch+='diff --git a/'+rel+' b/'+rel+'\n'
 if not old:patch+='new file mode 100644\n'
 patch+=''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='a/'+rel if old else '/dev/null',tofile='b/'+rel))
(W/'phase-preparation.patch').write_bytes(patch.encode())
check=subprocess.run(['git','apply','--check',str(W/'phase-preparation.patch')],cwd=R,capture_output=True,text=True)
assert check.returncode==0,check.stderr
plan=dict(status='SCRATCH_PHASE_PHYSICAL_PREPARATION_CANDIDATE_UNAPPLIED_UNBUILT',
 source_base='Exact seven product source pins, not a future commit.',
 observed_product_HEAD=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),
 seven_source_base=[dict(relative=e['relative'],**pin(R/e['relative'])) for e in sourcebase['final_sources']],
 new_file_preconditions=[dict(relative=HEADER,absent=True),dict(relative=SOURCE,absent=True)],
 candidate=[dict(relative=rel,**pin(W/'candidate'/rel)) for rel in files],
 patch=pin(W/'phase-preparation.patch'),git_apply_check=dict(exit=check.returncode,stderr=check.stderr),
 product_edits=0,builds=0,native_runs=0,downloads=0)
(W/'plan.json').write_text(json.dumps(plan,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
print(json.dumps(dict(status=plan['status'],files=len(files),patch_bytes=plan['patch']['bytes'],patch_sha256=plan['patch']['sha256'])))
