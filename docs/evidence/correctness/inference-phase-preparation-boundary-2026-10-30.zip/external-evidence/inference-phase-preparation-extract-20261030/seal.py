from pathlib import Path
import hashlib,json
W=Path(__file__).resolve().parent;R=W.parents[1]
I=R/'.scratch/inference-phase-preparation-review-20261030/independent-candidate-review.json'
def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def pin(p):
 p=Path(p);b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
plan,report,independent=map(read,(W/'plan.json',W/'static-report.json',I))
assert independent['patch']['sha256']==plan['patch']['sha256']==pin(W/'phase-preparation.patch')['sha256']
for e in plan['seven_source_base']:assert pin(R/e['relative'])['sha256']==e['sha256']
for e in plan['candidate']:assert pin(e['path'])=={k:v for k,v in e.items() if k!='relative'}
for e in plan['new_file_preconditions']:assert not (R/e['relative']).exists()
inputs={}
for closure in report['closures'].values():
 for e in closure['pins']:
  p=Path(e['path'])
  try:rel=p.relative_to(W/'candidate')
  except ValueError:rel=p.relative_to(R)
  actual=R/rel
  inputs[rel.as_posix()]=dict(relative=rel.as_posix(),**pin(actual)) if actual.is_file() else dict(relative=rel.as_posix(),absent=True)
for e in plan['seven_source_base']:inputs[e['relative']]=e
for rel in ('engine/models/qwen35/CMakeLists.txt','tests/CMakeLists.txt'):
 inputs[rel]=dict(relative=rel,**pin(R/rel))
source_pins=dict(status='FROZEN_PHASE_SOURCE_INPUTS_NOT_COMPILER_DEPS',source_base='Seven exact current source files',
 preconditions=[inputs[k] for k in sorted(inputs)])
(W/'source-input-pins.json').write_text(json.dumps(source_pins,indent=2)+'\n',encoding='utf-8')
plan.update(status='FROZEN_PHASE_CANDIDATE_STATIC_REVIEWED_UNAPPLIED_UNBUILT',
 static_report=pin(W/'static-report.json'),independent_review=pin(I),source_input_pins=pin(W/'source-input-pins.json'),
 source_dependency_scope='Quoted include source pins only; actual compiler dependency receipts pending authorized harness.')
(W/'plan.json').write_text(json.dumps(plan,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
print(json.dumps(dict(status=plan['status'],source_inputs=len(inputs),candidate_files=len(plan['candidate']),
 patch_bytes=plan['patch']['bytes'],patch_sha256=plan['patch']['sha256'])))
