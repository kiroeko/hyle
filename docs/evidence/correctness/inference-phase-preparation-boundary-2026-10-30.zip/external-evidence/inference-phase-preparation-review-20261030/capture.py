from pathlib import Path
import hashlib, json, subprocess
root=Path(__file__).resolve().parents[2]
out=Path(__file__).resolve().parent
files=['engine/models/qwen35/main.cc','engine/models/qwen35/family_factory.h','engine/models/qwen35/weights.h',
       'engine/inference/backend.h','engine/inference/program_slots.h','engine/inference/program_carrier.h',
       'engine/inference/program_io.h','engine/inference/readback.h','engine/inference/slot_transactions.h',
       '.scratch/inference-phase-preparation-design-20261030/README.md']
pins=[]
for name in files:
    data=(root/name).read_bytes();pins.append(dict(path=name,bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
(out/'source-pins.json').write_text(json.dumps(dict(status='READ_ONLY_EXISTING_CONTRACT_REVIEW',head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),sources=pins,product_edits=0,builds=0,native_runs=0),indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(sources=len(pins))))
