from pathlib import Path
import difflib, hashlib, json, re
root=Path(__file__).resolve().parents[2]; out=Path(__file__).resolve().parent
batch=root/'.scratch/inference-phase-preparation-extract-20261030'
plan=json.loads((batch/'plan.json').read_text(encoding='utf-8'))
base=(root/'engine/models/qwen35/main.cc').read_text(encoding='utf-8')
new=(batch/'candidate/engine/models/qwen35/main.cc').read_text(encoding='utf-8')
header=(batch/'candidate/engine/models/qwen35/phase.h').read_text(encoding='utf-8')
factory=(batch/'candidate/engine/models/qwen35/phase_preparation.cc').read_text(encoding='utf-8')
def part(s,a,b):
    i=s.index(a);return s[i:s.index(b,i)]
def tokens(s):
    pattern=r'//[^\n]*|/\*.*?\*/|"(?:\\.|[^"\\])*"|\x27(?:\\.|[^\x27\\])*\x27|[A-Za-z_][A-Za-z_0-9]*|[0-9]+|[^\s]'
    return [x for x in re.findall(pattern,s,re.S) if not x.startswith(('//','/*'))]
checks={}
for p in plan['candidate']:
    checks['candidate:'+p['relative']]=hashlib.sha256(Path(p['path']).read_bytes()).hexdigest()==p['sha256']
checks['patch_pin']=hashlib.sha256(Path(plan['patch']['path']).read_bytes()).hexdigest()==plan['patch']['sha256']
old_types=part(base,'// Physical IO/control carriers','// One original Graph episode')
new_types=part(header,'// Physical IO/control carriers','struct PhaseSelection final')
checks['Phase_types_layout_exact']=tokens(old_types)==tokens(new_types)
old=part(base[base.index('  Phase &prepare_child('):],'    auto result = std::make_unique<Phase>();','    if (state_storage_prepared)')
new_body=part(factory,'    auto result = std::make_unique<Phase>();','  return result;')
eligibility=part(old,'    if (imported_sources) {','    phase.query_rows = tokens;')
old=old.replace('    std::size_t physical_slots = 1;\n','').replace(eligibility,'')
transforms=[
 ('const auto planned_slot_uses = shape_plan.uses({requests, tokens, role, completion, sampling_index, false, packing});','const auto &planned_slot_uses = preparation.planned_uses;'),
 ('phase.child = &selected->program;','phase.child = &selection.child;'),
 ('program_slot.replay_mode = !selected_sampler.modifiers.history.empty() ? g::ReplayMode::kCommands\n          : imported_sources ? g::ReplayMode::kPreferCapture : select_replay_mode(\n          replay_policy, program_slot.planned_uses, selected_sampler.enabled);','program_slot.replay_mode = preparation.replay_modes[slot];'),
 ('caller_tensor(', 'phase_tensor(allocation_budget, '),
]
for a,b in transforms:
    assert a in old;a_count=old.count(a);old=old.replace(a,b)
checks['Physical_body_projected_tokens_equal']=tokens(old)==tokens(new_body)
(out/'body-remaining.diff').write_text(''.join(difflib.unified_diff(old.splitlines(True),new_body.splitlines(True))),encoding='utf-8')
checks['Eligibility_exact']=tokens(eligibility)==tokens(part(new[new.index('  Phase &prepare_child('):],'    if (imported_sources) {','    const auto planned_slot_uses'))
restored=new.replace('#include "phase.h"\n','')
marker='// One original Graph episode'
restored=restored.replace(marker,old_types+marker,1)
before=part(base,'  Phase &prepare_child(','  // Actual per-member') if '  // Actual per-member' in base[base.index('  Phase &prepare_child('):] else ''
# Restore only the method prefix through the unchanged layout-attachment tail.
old_prefix=part(base,'  Phase &prepare_child(','    if (state_storage_prepared) prepare_transaction_layouts(phase);')
new_prefix=part(restored,'  Phase &prepare_child(','    if (state_storage_prepared) prepare_transaction_layouts(phase);')
restored=restored.replace(new_prefix,old_prefix,1)
checks['Complete_main_inverse_exact']=restored==base
(out/'main-inverse-remaining.diff').write_text(''.join(difflib.unified_diff(base.splitlines(True),restored.splitlines(True))),encoding='utf-8')
result=dict(status='PASS_STATIC_ONLY' if all(checks.values()) else 'REQUIRES_INSPECTION',checks=checks,
            patch=plan['patch'],physical_body_tokens=len(tokens(new_body)),product_edits=0,builds=0,native_runs=0,
            source_contract='See README.md. Incomplete ColdResources only occurs through original ProgramSlots/ProgramCarrier shared_ptr scope; no field access/sizeof/delete is introduced in phase unit.')
(out/'independent-candidate-review.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(status=result['status'],failed=[k for k,v in checks.items() if not v],body_tokens=result['physical_body_tokens'])))
