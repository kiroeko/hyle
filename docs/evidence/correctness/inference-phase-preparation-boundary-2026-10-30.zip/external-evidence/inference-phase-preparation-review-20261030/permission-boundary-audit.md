# 动态权限与可冷绑定元数据边界

本清单行号来自**HEAD 910a + 已应用Phase候选的工作树main**，不是910a blob；精确hash另见permission-source-pins.json。只读，不profile/build/native，不重开已完成retirement/IO。

不可删除或跨调用缓存的动态合同：

- `prepare_evaluations`现3148–3160：原incoming submission/primary output、实际state/page数量、predecessor submitted/cancelled/owner、candidate slot与独立carrier接纳。冷端口“存在”不能代表这些实际producer权限已交付。
- 现3162起及3238–3263：每Session所属Model、当前Head、停止/pending/epoch/remaining context、MTP lag与重复可变Session检查。每接受步骤换Head/RNG/页帧；不能把Session指针或第一次合法的epoch当永久许可。
- 现3474–3489：OutputSource/StoreSource.reader_binding与append_binding必须针对当前run、当前producer、原ready ReadLease/StoreSource权限构造。Phase只缓存端口ID/Source投影模式；不能把上个Step的reader binding或布局版本绑定到下个Step。
- 现3895的expected-base/epoch/pending/stop核对发生于原数学成功且实际退休之后、Head交换之前，不能因输入曾检查通过而省掉。实际取消/背压/晚观察不是固定图metadata。
- ProgramCarrier仍以pending/in_flight/closing/handed_off检查borrow/init/reset/release，实际retirement和终态Status独立；truthy Invocation、host观察成功或热cache命中都不是可复用许可。原accepted Completion保原Scope，不可冷缓存第二个Model/Session owner。

5项具体元数据范围（不是5个待改造任务）：

1. 可实现小片：packed query_offsets的`dense(I32,width+1)`描述可放原Phase冷事实。每次真实query_offsets lease与run.bind仍动态；不缓存实际layout/version/lease。
2. 可实现小片：同次prepare已经解析的warm Phase/child可在角色/packing与必要exact admission完成后复用，减少重复lookup。不可跨call缓存裸Phase/Family指针；exact eviction会真删原对象。
3. 条件候选：target modifier输入的固定描述/端口handle可接回现ProgramIo.add_input机制；真实输入metadata、lease和数值检查仍每次保留，withdrawal覆盖范围必须同原raw bind路径。默认无modifier无直接收益，不强推为默认性能修复。
4. 已有优化：Phase.state_banks.source_index和Imported普通端口过滤已在冷准备完成；动态Store/OutputSource权限仍必须当次绑定。不能再记为缺少冷缓存。
5. 已有优化：PreparedOutputFacts已由所选child冷索引并被Phase指针借用；ProgramIo.add_input的物理报告扫描在cold注册而非bind；ProgramCarrier的required queue选择也仅cold prepare。Graph batch已有selection缓存，不能宣称热路径每次全图发现。

本清单没有证明调用频次或速度收益；需当前profile决定小片优先级。可冷绑的是原稳定描述与编排索引，不是有效期、权限或退休见证。
