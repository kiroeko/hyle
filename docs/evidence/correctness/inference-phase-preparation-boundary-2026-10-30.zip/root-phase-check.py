from pathlib import Path
import importlib.util,json
W=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('root_phase_build',W/'build.py')
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
ready=b.read(W/'ready-tiny.json');b.exact(ready)
args=[ready['path'],'--cpu',str(b.R/'.scratch/inference-paged-frame-20261026/tiny-recursive-input'),'--phase-preparation']
out=W/'runs/candidate/phase-preparation-cpu/attempt1'
b.s.b.execute(args,out,180)
report=json.loads((out/'stdout.log').read_text(encoding='utf-8'))
assert report['status']=='PASS' and report['submitted_graphs']==report['final_versions']==0
b.save(out/'report.json',report)
print(json.dumps(report))
