"""Compact current231/cache and actualsource dependency seal; no execution."""
from pathlib import Path
import copy,importlib.util,json,re,subprocess
W=Path(__file__).resolve().parent;R=W.parents[1]
spec=importlib.util.spec_from_file_location('phase_seal_build',W/'build.py')
h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
read,save,pin,exact,key=h.read,h.save,h.pin,h.exact,h.key
plan=read(W/'plan.json');baseline=read(W/'baseline-plan.json');base=read(plan['base']['path'])
receipts={}
for name in ('phase','leaf','cli','tiny','session'):
 path=W/'compile'/name/'receipt.json';receipt=read(path)
 for item in [receipt['object'],receipt['dependencies'],receipt['process'],*receipt['source_identities']]:exact(item)
 receipts[name]=dict(receipt=pin(path),object=receipt['object'])
phase=read(receipts['phase']['receipt']['path']);retained=base['retained']+[phase['object']]
assert len(retained)==231 and len({key(item['path']) for item in retained})==231
for item in retained:exact(item)
sdk=copy.deepcopy(read(base['sdk_engine_dependencies']['path']))
sdk['inspected'].append(dict(object=phase['object']['path'],dependencies=phase['dependencies']))
sdk['engine_consumers'].append(dict(object=phase['object']['path'],dependencies=phase['dependencies'],receipt=receipts['phase']['receipt'],
 source_identities=phase['source_identities'],engine_dependencies=[item['path'] for item in phase['source_identities'] if Path(item['path']).is_relative_to(R/'engine')]))
sdk['scope']='Current231:old230 retained byteexact,one newPhase coldobject.162available dependency rows/69historical metadata unavailable. No SDK/oldcold recompile.'
save(W/'sdk-engine-dependencies.json',sdk)
current={};previous={};audit=[]
for name,row in base['current_consumers'].items():
 exact(row['receipt']);exact(row['object']);receipt=read(row['receipt']['path'])
 mismatch=[item for item in receipt['source_identities'] if not Path(item['path']).is_file() or pin(item['path'])!=item]
 if mismatch or name in ('cli','tiny','session'):
  previous[name]=dict(**row,status='HISTORICAL_NOT_CURRENT',mismatched_source_pins=mismatch)
  audit.append(dict(name=name,status='HISTORICAL',mismatched_source_pin_count=len(mismatch)))
 else:current[name]=row;audit.append(dict(name=name,status='CURRENT_EXACT',source_pin_count=len(receipt['source_identities'])))
for name in ('cli','tiny','session'):current[name]=receipts[name]
historical=copy.deepcopy(base['historical_consumers']);historical['before-phase-910a']=previous
args=[];count=0
for arg in base['link']:
 if key(arg)==key(plan['original_consumer']['path']):arg=receipts['cli']['object']['path'];count+=1
 for prefix,suffix in [('/OUT:','.exe'),('/PDB:','.pdb'),('/IMPLIB:','.lib'),('/MAP:','.map')]:
  if arg.upper().startswith(prefix):arg=prefix+str((W/'bin/cli').with_suffix(suffix));break
 args.append(arg)
assert count==1;args.append(phase['object']['path'])
save(W/'model-link-base.json',dict(schema='hyle.current-model-link-base.v1',base=plan['base'],compile=plan['units']['cli']['compile'],link=args,
 consumer_source=str(W/'cli.cc'),previous_consumer=plan['original_consumer']['path'],retained=retained,runtime=base['runtime'],
 sdk_engine_dependencies=pin(W/'sdk-engine-dependencies.json'),current_consumers=current,historical_consumers=historical,
 retained_categories=dict(SDK_and_engine=227,model_cold_objects=4,total_retained=231,old_reused=230,new_phase=1),
 model_cold_objects=base['model_cold_objects']+[dict(source=plan['units']['phase']['source'],**receipts['phase'])],
 current_compile_only=dict(leaf=receipts['leaf']),note='PhaseIO/coldpreparation module;old230 byteexact,onlynewphase object. Currentrows exact andnot rebuilt.'))
save(W/'current-consumer-source-audit.json',audit)
proof=[]
for name in ('phase','leaf'):
 receipt=read(receipts[name]['receipt']['path']);paths=[Path(item['path']).relative_to(R).as_posix() for item in receipt['source_identities']]
 assert 'engine/models/qwen35/main.cc' not in paths and 'engine/models/qwen35/session_state.h' not in paths
 proof.append(dict(unit=name,repo_source_pins=len(paths),sources=paths,no_Model_main_or_Qwen_session_header=True))
inventory=R/'engine/models/qwen35/cold_sources.cmake';sources=re.findall(r'"\$\{CMAKE_CURRENT_LIST_DIR\}/([^\"]+)"',inventory.read_text())
assert sources==['weights.cc','graph_builder.cc','target_graph.cc','family_factory.cc','phase_preparation.cc']
for relative in ('engine/models/qwen35/CMakeLists.txt','tests/CMakeLists.txt'):
 assert (R/relative).read_bytes()==subprocess.check_output(['git','show',baseline['base_commit']+':'+relative],cwd=R)
save(W/'dependency-proof.json',dict(cold=proof,inventory=pin(inventory),cold_sources=sources,old_guards_exact=True,
 full_default_CMake_build=False,SDK_CXX=0,old_cold_CXX=0))
print(json.dumps(dict(retained=231,reused=230,new_phase=1,available_dependencies=162,cold_source_pins={row['unit']:row['repo_source_pins'] for row in proof})))
