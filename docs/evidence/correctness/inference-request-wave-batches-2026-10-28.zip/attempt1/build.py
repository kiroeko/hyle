"""One current Tiny consumer: wave cancellation and unchanged block equations."""
from pathlib import Path
import importlib.util
import sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent
R=Path(r'C:\public\project-hyle\hyle')
spec=importlib.util.spec_from_file_location('wave_original_prepared_family_build',R/'.scratch/inference-prepared-program-family-20261028/validation/build.py')
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
b.W=W;b.__file__=__file__;b.t.W=W
t=b.t
b.SNAPSHOTS=('engine/models/qwen35/main.cc','engine/models/qwen35/mtp_graph.h','engine/models/qwen35/block_graph.h','engine/inference/request_batch_execution.h','tests/tools/qwen_host_image_test.cc','tests/tools/qwen_generation_wave_case.h','tests/tools/qwen_sampling_policy_case.h','tests/tools/qwen_ragged_prefill_case.h','tests/tools/qwen_mtp_sampling_case.h')
if __name__=='__main__':
 action=sys.argv[1]
 if action=='prepare':
  b.prepare()
  p=W/'final-build-plan.json';v=t.read(p);v['scope']='One Tiny CXX/link retaining ON227 SDK/weights. Eight finite CPU/CUDA wave, ragged, natural ordinary policies and MTP sampling processes. No performance, platform matrix or download.'
  p.write_text(__import__('json').dumps(v,indent=2)+'\n',encoding='utf-8')
 elif action=='freeze':b.freeze()
 elif action=='compile':b.compile_unit('tiny')
 elif action=='parse-compile':b.parse_compile('tiny')
 elif action=='link':b.link_unit('tiny')
 elif action=='preflight':b.validate()
 else:raise ValueError(action)
