"""Offline-only eight-case parser/evidence collector. Never imports a native runner action."""
from pathlib import Path
import argparse
import hashlib
import importlib.util
import json
import sys
import zipfile
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent
R=W.parents[1]
DEST=R/'docs/evidence/correctness/inference-request-wave-batches-2026-10-28'
CASES={
 'wave-cpu':('cpu','wave','--generation-wave'), 'wave-cuda':('cuda','wave','--generation-wave'),
 'ragged-cpu':('cpu','ragged','--ragged-prefill'), 'ragged-cuda':('cuda','ragged','--ragged-prefill'),
 'policies-cpu':('cpu','policies','--sampling-policies'), 'policies-cuda':('cuda','policies','--sampling-policies'),
 'sampler-cpu':('cpu','sampler','--mtp-sampling'), 'sampler-cuda':('cuda','sampler','--mtp-sampling'),
}
SOURCES=(
 'engine/inference/request_batch_execution.h','engine/models/qwen35/main.cc',
 'engine/models/qwen35/block_graph.h','engine/models/qwen35/mtp_graph.h',
 'tests/tools/qwen_host_image_test.cc','tests/tools/qwen_generation_wave_case.h',
 'tests/tools/qwen_sampling_policy_case.h','tests/tools/qwen_ragged_prefill_case.h',
 'tests/tools/qwen_mtp_sampling_case.h',
)
PREFILL=R/'.scratch/inference-execution-preparation-20261028/parse.py'
SAMPLER=R/'.scratch/inference-mtp-sampling-20261028/refinement-v4/run.py'

def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def pin(p):
 p=Path(p).resolve();b=p.read_bytes()
 return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def save(p,value):
 p=Path(p);p.parent.mkdir(parents=True,exist_ok=True)
 with p.open('x',encoding='utf-8') as f:f.write(json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
def module(name,p):
 s=importlib.util.spec_from_file_location(name,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
def process(p):
 x=read(p);assert x['exit']==0 and not x.get('timed_out',False),p
 assert x.get('state','TERMINAL')=='TERMINAL',p
 return x
def reports(p):
 return [json.loads(line) for line in Path(p).read_text(encoding='utf-8-sig').splitlines() if line.startswith('{')]

def wave_report(xs,backend):
 assert len(xs)==1
 x=xs[0];assert x['status']=='PASS' and x['case']=='generation-wave' and x['backend']==backend
 assert x['models']==1 and x['native_submissions']==3 and x['final_versions']==0
 for k in ('old_copy_component_failure_reproduced','cancelled_disposition_returned','whole_wave_prepare_before_publish',
           'cancelled_heads_ledger_rng_unchanged','survivor_same_key_retry','prefix_unpublished_on_cancel'):assert x[k] is True,k
 assert x['quality_claim'] is False and x['performance_claim'] is False
 return x

def policy_reports(xs,backend):
 finals=[x for x in xs if x.get('case')=='sampling-policies'];naturals=[x for x in xs if 'sessions' in x]
 assert len(xs)==2 and len(finals)==len(naturals)==1
 final,natural=finals[0],naturals[0]
 assert final['status']=='PASS' and final['ordinary'] and final['same_model']
 assert (final['configurations'],final['requests'],final['turns'],final['N'],final['R'])==(4,6,12,2,2)
 assert final['quality_claim'] is False and final['performance_claim'] is False
 assert natural['backend']==backend and natural['mtp'] is False and natural['active_sequences']==2
 assert natural['session_count']==6 and natural['turn_count']==12
 # The natural endpoint report precedes local PrefixCache destruction; its one
 # real retained checkpoint is charged here. The original case checks zero
 # Model versions after run_generation_sessions returns.
 assert natural['live_committed_versions']==natural['prefix_entries']==1
 assert natural['admitted_requests']==natural['retired_requests']==6
 sessions=natural['sessions'];assert len(sessions)==6
 for entry,index in zip(sessions,(0,0,3,3,1,1)):
  detail=entry['result'];ledger=entry['ledger']
  assert detail['sampling_configuration_index']==index
  assert detail['generated_tokens']==len(detail['generated_ids'])==5
  assert len(detail['turns'])==2 and {x['turn'] for x in ledger}=={1,2}
  for record in ledger:
   delta=record['sampling_draw_after']-record['sampling_draw_before']
   if index==0:assert delta==0,(index,record)
   elif record['imported']:assert delta in (0,1),(index,record)
   else:assert delta==1,(index,record)
 return dict(final=final,natural=natural)

def analyze(attempt):
 prefill=module('reused_current_ragged_parser',PREFILL)
 sampler=module('reused_current_sampler_parser',SAMPLER)
 cases=[];checks=[]
 for name,(backend,kind,flag) in CASES.items():
  folder=attempt/'runs'/name;p=process(folder/'process.json');command=read(folder/'command.json')
  assert '--'+backend in command['command'] and flag in command['command'],name
  xs=reports(folder/'stdout.log')
  if kind=='wave':value=wave_report(xs,backend)
  elif kind=='policies':value=policy_reports(xs,backend)
  elif kind=='ragged':
   assert len(xs)==1;prefill.check_report(xs[0],backend,'ragged');value=xs[0]
   checks.extend(prefill.state_rows(xs[0],'ragged'))
  else:
   value=sampler.sampler_reports(xs,backend)
   assert len(value['manual']['state_checks'])==17
   checks.extend(value['manual']['state_checks'])
  cases.append(dict(name=name,status='PASS',backend=backend,kind=kind,process=p,command=command,reports=value,
   evidence=[pin(folder/f) for f in ('command.json','process.json','stdout.log','stderr.log')]))
 assert len({x['process']['pid'] for x in cases})==8
 assert len(checks)==52
 exact=sum(bool(row['payloads_byte_equal']) for row in checks)
 maximum=max((d['maximum_absolute'] for row in checks for d in row.get('differences',[])),default=0)
 ready=read(attempt/'ready-tiny.json')
 assert ready['process']['exit']==ready['compiled']['process']['exit']==0
 inputs=read(ready['inputs']['path']);assert len(inputs)==228
 first=W/'validation/logs/tiny/process.json'
 failure=read(first);assert failure['exit']!=0
 return dict(schema='hyle.request-wave-batches.correctness.v1',status='PASS_EIGHT_FINITE_CPU_CUDA_CASES',
  native_processes=8,native_reruns=0,structured_state_comparisons=len(checks),byte_exact_state_comparisons=exact,
  maximum_gdn_absolute_difference=maximum,existing_gdn_absolute_budget=0.000003,
  actual_build=dict(CXX_processes=2,failed_first_Tiny_CXX=failure,successful_Tiny_CXX=ready['compiled']['process'],
   links=1,successful_link=ready['process'],link_inputs=228,retained_SDK_weights=227,SDK_CXX=0,NVCC=0),
  ready=ready,ready_pin=pin(attempt/'ready-tiny.json'),cases=cases,
  first_failure=dict(kind='actual_CXX_failure',cause='Tiny driver passed backend to the pre-existing one-argument sampling-policy case. Corrected case now accepts optional BackendKind defaulting to CUDA; no product/math/compile flag workaround.',
   logs=[pin(W/'validation/logs/tiny'/f) for f in ('command.json','process.json','stdout.log','stderr.log')]),
  architecture=dict(common_wave='Cold-reserved call/bucket/index workspace; whole-wave prepare, static compatibility/admission, no-throw original call move-back, actual-bucket RequestKey mapping, then original prompt publication.',
   model_math='Qwen FFN/GDN epilogue equations live in model-local block_graph.h and reuse the original Recipe; Compute/Graph ABI, native owner, arithmetic order and placement remain unchanged.',
   retained='Original Model/Step/Graph/Store/Append/Completion/retirement and prefix/state owners. No new executor, runtime callback table or permission ledger.'),
  boundaries=dict(synthetic_cached_GA_fixture=True,trained_quality=False,performance=False,Apple_tested=False,Vulkan_tested=False,
   whole_RequestLoop_service_test=False,unknown_native_failure_claim=False,
   notes=['Wave case includes an intentionally failing old-copy component recipe caught within the same successful process; it is not a failed native model process.',
    'Structured state comparison subtotal counts ragged9 and sampler17 per backend. Other wave/policy assertions stay in complete original reports and are not invented byte-check counts.',
    'Ordinary natural endpoint reports retain one charged prefix/checkpoint; the original C++ case checks zero versions after the function returns and that directory is destroyed.',
    'Newly computed F32 GDN alone retains the existing3e-6 bound; old checkpoints, boundary/RNG and other payload requirements remain those enforced by each actual consumer.']),
  parser=pin(__file__),reused_parsers=[pin(PREFILL),pin(SAMPLER)])

def archive(attempt,analysis):
 paths={}
 def add(p,label):
  p=Path(p)
  if p.is_file():paths[label.replace('\\','/')]=p
 def add_receipts(root,label):
  for p in sorted(root.rglob('*')):
   if not p.is_file():continue
   rel=p.relative_to(root)
   if rel.parts[0] in ('runs','bin','source','attempt2'):continue
   if p.suffix.lower() in ('.json','.py','.log','.patch','.txt'):
    add(p,label+'/'+rel.as_posix())
  for source in SOURCES:add(root/'source'/source,label+'/source/'+source)
 add_receipts(W/'validation','attempt1')
 if attempt!=W/'validation':add_receipts(attempt,'attempt2')
 for name in CASES:
  for p in sorted((attempt/'runs'/name).iterdir()):
   if p.is_file() and p.suffix.lower() in ('.json','.log'):add(p,'attempt2/runs/'+name+'/'+p.name)
 for p in (Path(__file__),W/'analysis.json',PREFILL,SAMPLER,
           R/'.scratch/inference-execution-episode-20261028/parse.py',
           R/'.scratch/inference-qwen-block-graph-20261028/main-math.patch',
           R/'.scratch/inference-qwen-block-graph-20261028/mtp-ffn.patch',
           R/'.scratch/inference-qwen-block-graph-20261028/node-semantics.json',
           R/'.scratch/inference-qwen-block-graph-20261028/source-freeze.json'):
  add(p,'support/'+p.relative_to(R).as_posix())
 # Metadata-only external link list/recipe. Never copy any binary payload.
 for k in ('inputs','recipe','source_freeze','runtime'):
  row=analysis['ready'].get(k)
  if isinstance(row,dict) and 'path' in row:add(Path(row['path']),'ready-metadata/'+k+Path(row['path']).suffix)
 manifest=[dict(member=member,**{k:v for k,v in pin(p).items() if k!='path'}) for member,p in sorted(paths.items())]
 target=DEST.with_suffix('.zip');target.parent.mkdir(parents=True,exist_ok=True)
 with zipfile.ZipFile(target,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
  for member,p in sorted(paths.items()):z.write(p,member)
  z.writestr('manifest.json',json.dumps(dict(members=manifest),indent=2)+'\n')
 with zipfile.ZipFile(target) as z:
  assert z.testzip() is None
  for row in manifest:
   body=z.read(row['member']);assert len(body)==row['bytes'] and hashlib.sha256(body).hexdigest()==row['sha256']
 result={k:v for k,v in analysis.items() if k not in ('ready','cases')}
 result.update(cases=analysis['cases'],source_freeze=analysis['ready'].get('source_freeze'),
  archive=pin(target),archive_members=len(manifest)+1,archive_readback=dict(CRC=True,member_SHA256=True),
  excludes=['OBJ','EXE','DLL','PDB','LIB','SDK/header copies outside changed source snapshots','weight/model payloads'])
 save(DEST.with_suffix('.json'),result)
 print(json.dumps(dict(status=result['status'],native_processes=8,state_comparisons=52,
  zip=result['archive'],members=result['archive_members']),indent=2))

def main():
 p=argparse.ArgumentParser();p.add_argument('--attempt',required=True,type=Path);p.add_argument('--package',action='store_true')
 args=p.parse_args();attempt=args.attempt.resolve()
 assert attempt.is_relative_to(W) and attempt.is_dir()
 analysis=analyze(attempt)
 out=W/'analysis.json'
 if out.exists():assert read(out)==analysis,'Preserve original analysis; use an explicit offline refinement'
 else:save(out,analysis)
 if args.package:archive(attempt,analysis)
 else:print('OFFLINE_ANALYSIS_SAVED; no archive/native process started')

if __name__=='__main__':main()
