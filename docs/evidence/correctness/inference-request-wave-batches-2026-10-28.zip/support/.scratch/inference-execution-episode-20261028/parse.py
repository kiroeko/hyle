"""Only parse six existing native results; never execute or retry a process."""
from pathlib import Path
import hashlib
import json
import math

W = Path(__file__).resolve().parent
CASES = {
    'logits-cpu': ('cpu', 'logits', '--mtp-logits'),
    'logits-cuda': ('cuda', 'logits', '--mtp-logits'),
    'batch-state-cpu': ('cpu', 'batch-state', '--mtp-batch-state'),
    'batch-state-cuda': ('cuda', 'batch-state', '--mtp-batch-state'),
    'relay-cuda': ('cuda', 'relay', '--cuda'),
    'submission-relay-cuda': ('cuda', 'submission-relay', '--relay'),
}


def read(path):
    return json.loads(path.read_bytes())


def pin(path):
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())


def finite(value):
    if isinstance(value, dict):
        for child in value.values(): finite(child)
    elif isinstance(value, list):
        for child in value: finite(child)
    elif isinstance(value, float):
        assert math.isfinite(value), 'Nonfinite JSON result'


def check_report(report, backend, kind):
    assert report['status'] == 'PASS' and report['backend'] == backend
    assert report['performance_claim'] is False
    assert report['final_live_versions' if kind == 'submission-relay' else 'final_versions'] == 0
    finite(report)
    if kind == 'logits':
        assert report['case'] == 'mtp-logits-modifiers'
        assert report['models'] == 1 and report['configurations'] == report['finite_math_branches'] == report['numeric_q_failures'] == 2
        flags = ['K1_greedy_random', 'recursive_greedy_random', 'already_normalized_q_not_reprocessed',
                 'original_B2_snapshots', 'StateOnly_no_input_or_draw', 'partial_HostImage',
                 'prefix_frontier_numeric_failure', 'new_prefix_policy_payload', 'strict_modifier_replay_rejected',
                 'historical_StateOnly_rebuild', 'known_key_metadata_zero_native', 'same_key_retry', 'synthetic_untrained']
        assert len(report['state_checks']) == 10
        for row in report['state_checks']:
            assert row['boundary_equal'] is True and row['payloads_byte_equal'] is True
            assert row['numerically_equivalent'] is True and row['differences'] == []
            assert row['exact_next'] == row['bucket_next']
        assert report['quality_claim'] is False
    elif kind == 'batch-state':
        assert report['requests'] == report['rounds'] == 2
        assert report['verify_rows'] == report['candidate_prefixes'] == 3
        assert report['accepted'] == [[1, 3], [3, 1]]
        assert report['checked_selected_bytes'] > 0 and report['reclaimed_unselected_slots'] > 0
        assert len(report['banks']) == 4
        for bank in report['banks']:
            assert bank['role'] in ['conv', 'gdn']
            assert len(set(bank['source_slot_ids'])) == 2 and len(set(bank['candidate_slot_ids'])) == 6
        flags = ['same_width_original_candidates', 'old_snapshots_unchanged', 'controlled_prefix_pending',
                 'controlled_rng_unchanged', 'nextn_checked_id_failure_recovered', 'same_program_valid_retry']
        assert report['natural_acceptance_quality_claim'] is False
    elif kind == 'relay':
        assert report['requests'] == report['resident_sessions'] == report['active_sequences'] == report['in_flight_batches'] == 2
        assert report['state_slots'] == report['serial_and_relay_arms'] == 6
        assert report['outputs_per_live_member'] == 14 and len(report['relay']) == 3
        flags = ['distinct_prompt_payloads', 'complete_initialized_state_equal', 'ledger_and_rng_equal',
                 'actual_batch_keys_checked', 'real_member_credit1_blocks_b', 'accepted_b_whole_discard',
                 'survivor_r1_continues', 'peer_not_permanently_stopped']
        assert report['native_fault_injection'] is False and report['model_eos_run'] is False
        for arm in report['relay']:
            assert arm['successor_refusals'] == 0
            assert arm['actual_batches'] == len(arm['batch_facts'])
        assert report['relay'][0]['successor_submissions'] > 0
        assert report['relay'][1]['successor_submissions'] == 0  # Real credit1 deliberately blocks B.
        assert report['relay'][2]['successor_submissions'] > 0
        assert report['relay'][2]['successor_discards'] > 0 and report['relay'][2]['survivor_r1'] > 0
    else:
        assert kind == 'submission-relay' and report['mode'] == 'relay'
        assert report['physical_carriers'] == 3 and report['candidate_depth'] == 2
        assert report['controlled_pending_pairs'] == 1 and report['pending_capture_recorded'] == 0
        assert report['complete_state_bytes_compared'] > 0
        flags = ['successor_prepared_while_predecessor_pending', 'successor_submitted_while_predecessor_pending',
                 'predecessor_published_while_successor_pending', 'rejected_successor_preserved_predecessor',
                 'old_checkpoint_unchanged', 'rng_cursor_unchanged', 'all_source_generations_released']
        assert report['continuous_pipeline'] is False and report['request_scheduler_coverage'] is False
    assert all(report[flag] is True for flag in flags)


def main():
    rows = []
    for name, (backend, kind, option) in CASES.items():
        directory = W / 'runs' / name
        process = read(directory / 'process.json')
        command = read(directory / 'command.json')
        assert process['exit'] == 0 and process['state'] == 'TERMINAL' and not process['timed_out'], name
        assert '--' + backend in command['command'] and option in command['command'], name
        reports = [json.loads(line) for line in (directory / 'stdout.log').read_text().splitlines()
                   if line.startswith('{')]
        assert len(reports) == 1, (name, len(reports))
        check_report(reports[0], backend, kind)
        rows.append(dict(name=name, status='PASS', process=process, command=command,
                         report=reports[0], evidence=[pin(directory / f) for f in
                             ['command.json', 'process.json', 'stdout.log', 'stderr.log']]))
    assert len({row['process']['pid'] for row in rows}) == 6
    result = dict(status='PASS_SIX_FINITE_EPISODE_CASES', native_processes=6, native_retries=0,
                  note='Offline analysis only. Native unknown-retirement faults, cross-platform matrix, quality and performance are not tested by these six cases.',
                  state_byte_checks=sum(len(row['report'].get('state_checks', [])) for row in rows),
                  parser=pin(Path(__file__)), cases=rows)
    (W / 'analysis.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({k: result[k] for k in ['status', 'native_processes', 'state_byte_checks']}))


if __name__ == '__main__':
    main()
