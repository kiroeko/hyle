"""Seven changed product/test TUs; reuse the already linked CPU dependency set."""
from pathlib import Path
import importlib.util
import os
import sys

sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
R = S.parents[1]
spec = importlib.util.spec_from_file_location('cpu_focused_helpers', R/'.scratch/engine-product-20261024/cpu-build.py')
b = importlib.util.module_from_spec(spec)
spec.loader.exec_module(b)
OUT = S/'f32-paged-check/attempt2'
BASE = R/'.scratch/engine-product-20261024/cpu-budget-fix1'
PROVIDER = R/'.scratch/qwen-gguf-selected-20261023/B07/cpu-packed-head-fix/compile1/cpu-provider/identity.json'


def compile_all():
    OUT.mkdir(exist_ok=False)
    source_recipe = b.read(PROVIDER)
    command = source_recipe['command']
    native = b.discover_environment(compiler='msvc', cache={'CMAKE_C_COMPILER': command[0],
        'CMAKE_CXX_COMPILER': command[0], 'CMAKE_GENERATOR': 'Ninja'}, backends=())
    flags = []
    skip = False
    for arg in command[1:]:
        if skip:
            skip = False
            continue
        if arg.lower() == '/sourcedependencies':
            skip = True
            continue
        if arg.lower().startswith(('/fo', '/fd')) or arg.lower().endswith('.cc'):
            continue
        flags.append(arg)
    flags.append('/DHYLE_GGML_CPU_F32_FLASH=1')
    units = {
        'layout': 'src/compute_batch/batch_layout.cc',
        'native-paged': 'src/compute_batch/batch_paged_native.cc',
        'native-batch': 'src/compute_provider_ggml/native_batch.cc',
        'provider': 'src/compute_provider_ggml/ggml_cpu_provider.cc',
        'low-precision': 'src/compute_ops/low_precision.cc',
        'test-layout': 'tests/compute_batch/batch_layout_test.cc',
        'test-metadata': 'tests/compute_batch/native_paged_metadata_test.cc',
        'test-native': 'tests/compute_provider_ggml/native_paged_test.cc',
        'test-precision': 'tests/compute_ops/low_precision_test.cc',
    }
    for name, relative in units.items():
        source = R/relative
        folder = OUT/name
        obj = folder/(name+'.obj')
        frozen = b.identity(source)
        cmd = [command[0], *flags, '/sourceDependencies', str(folder/'dependencies.json'),
               str(source), '/Fo'+str(obj), '/Fd'+str(folder/(name+'.pdb'))]
        b.execute(cmd, native.env, folder, 240)
        if b.identity(source) != frozen:
            raise RuntimeError('Source changed while this TU was compiling')
        dependencies = b.read(folder/'dependencies.json')['Data']
        b.save(folder/'identity.json', dict(source=frozen, object=b.identity(obj), command=cmd,
            dependencies=[b.identity(p) for p in dict.fromkeys([dependencies['Source'], *dependencies['Includes']])]))
    old = b.read(BASE/'tests-link-plan.json')
    replacements = {
        str(BASE/'layout/layout.obj'): str(OUT/'layout/layout.obj'),
        str(BASE/'test/test.obj'): str(OUT/'test-layout/test-layout.obj'),
        source_recipe['object']['path']: str(OUT/'provider/provider.obj'),
    }
    suffixes = {'compute_batch--batch_paged_native.obj': 'native-paged',
                'compute_provider_ggml--native_batch.obj': 'native-batch',
                'compute_ops--low_precision.obj': 'low-precision'}
    for argument in old['command']:
        if Path(argument).name in suffixes:
            name = suffixes[Path(argument).name]
            replacements[argument] = str(OUT/name/(name+'.obj'))
    if len(replacements) != 6 or any(old['command'].count(arg) != 1 for arg in replacements):
        raise RuntimeError('Expected exactly one old object per changed product/test TU')
    cmd = [replacements.get(arg, arg) for arg in old['command']
           if not arg.upper().startswith(('/OUT:', '/MAP:', '/IMPLIB:', '/PDB:'))]
    cmd += [str(OUT/'test-metadata/test-metadata.obj'), str(OUT/'test-native/test-native.obj'),
            str(OUT/'test-precision/test-precision.obj')]
    folder = OUT/'link'
    image = folder/'f32-paged-check.exe'
    cmd += ['/OUT:'+str(image), '/MAP:'+str(image.with_suffix('.map')), '/IMPLIB:'+str(image.with_suffix('.lib'))]
    b.save(OUT/'link-plan.json', dict(command=cmd, base=b.identity(BASE/'tests-link-plan.json'),
        replacements=replacements, compiled_TUs=9, SDK_builds=0, NVCC_builds=0, HTTP=0,
        private_compile_feature='HYLE_GGML_CPU_F32_FLASH=1; actual cached CPU flash tested below'))
    b.execute(cmd, native.env, folder, 120)
    runtime = b.read(R/'.scratch/engine-product-20261024/cpu-build5/runtime-environment.json')
    for row in runtime['staged_dlls']:
        b.require(row)
        os.link(row['path'], folder/Path(row['path']).name)
    ready = b.read(BASE/'tests-ready.json')
    b.save(OUT/'ready.json', dict(image=b.identity(image), PATH=ready['PATH']))


def run_all():
    ready = b.read(OUT/'ready.json')
    b.require(ready['image'])
    selection = 'GgmlCpuPaged.Float32*:GgmlCpuPaged.RuntimeQ1UsesOriginalDecodeSlotAcrossPagesAndTails:NativePagedMetadata.*:BatchLayout.*:ComputeOpsCacheStorage.*'
    result = b.execute([ready['image']['path'], '--gtest_filter='+selection,
        '--gtest_output=json:'+str(OUT/'gtest-results.json')],
        dict(os.environ, PATH=ready['PATH']), OUT/'run', 180)
    b.save(OUT/'summary.json', dict(process=result, tests=b.identity(OUT/'gtest-results.json'),
        result='passed', performance_claim=False, Q27_full_model_execution=False,
        fresh_TUs=9, SDK_builds=0, model_downloads=0))


if __name__ == '__main__':
    if sys.argv[1] == 'compile':
        compile_all()
    elif sys.argv[1] == 'run':
        run_all()
    else:
        raise SystemExit('compile or run')
