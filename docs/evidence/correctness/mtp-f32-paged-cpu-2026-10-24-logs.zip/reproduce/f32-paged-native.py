"""Complete the retained CPU v3 module with current native attention edits only."""
from pathlib import Path
import importlib.util
import os
import sys

sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
R = S.parents[1]
spec = importlib.util.spec_from_file_location('focused_cpu_helpers', R/'.scratch/engine-product-20261024/cpu-build.py')
b = importlib.util.module_from_spec(spec)
spec.loader.exec_module(b)
BASE = S/'f32-paged-check/attempt2'
OUT = S/'f32-paged-check/attempt3'
PATCHED = S/'f32-paged-check/native-paged-current'
NATIVE = R/'.scratch/glm-gguf-selected-20261023/B10/cpu-native-avx2-corrected1/result.json'


def flags_without_output(command, old_source):
    flags = []
    skip = False
    for arg in command[1:]:
        if skip:
            skip = False
            continue
        if arg.lower() == '/sourcedependencies':
            skip = True
            continue
        if arg.lower().startswith(('/fo', '/fd')) or arg == old_source:
            continue
        flags.append(arg)
    return flags


def compile_all():
    OUT.mkdir(exist_ok=False)
    retained = b.read(NATIVE)
    recipe = next(row for row in retained['reused'] if row['name'] == 'cpu-avx2-mixed')
    command = recipe['command']
    native = b.discover_environment(compiler='msvc', cache={'CMAKE_C_COMPILER': command[0],
        'CMAKE_CXX_COMPILER': command[0], 'CMAKE_GENERATOR': 'Ninja'}, backends=())
    source = PATCHED/'ops.cpp'
    folder = OUT/'native-ops'
    obj = folder/'native-ops.obj'
    cmd = [command[0], *flags_without_output(command, recipe['source']['path']),
           '/sourceDependencies', str(folder/'dependencies.json'), str(source),
           '/Fo'+str(obj), '/Fd'+str(folder/'native-ops.pdb')]
    b.execute(cmd, native.env, folder, 240)
    b.save(folder/'identity.json', dict(source=b.identity(source), object=b.identity(obj), command=cmd,
        source_patch=b.identity(PATCHED/'source.json')))
    link = retained['link']['command']
    if link.count(recipe['object']['path']) != 1:
        raise RuntimeError('Expected exactly one retained native Ops object')
    dll_folder = OUT/'native-link'
    dll = dll_folder/'hyle_ggml_cpu_gdn_scale_v3.dll'
    cmd = [str(obj) if arg == recipe['object']['path'] else arg for arg in link
           if not arg.upper().startswith(('/OUT:', '/MAP:', '/IMPLIB:', '/PDB:'))]
    cmd += ['/OUT:'+str(dll), '/MAP:'+str(dll.with_suffix('.map')), '/IMPLIB:'+str(dll.with_suffix('.lib'))]
    b.save(OUT/'native-link-plan.json', dict(command=cmd, base=b.identity(NATIVE),
        fresh_native_TUs=1, reused_native_program_export=True, original_GDN_contract_preserved=True,
        new_native_attention_source=b.identity(source), SDK_builds=0, HTTP=0))
    b.execute(cmd, native.env, dll_folder, 120)
    test = b.read(BASE/'test-native/identity.json')
    folder = OUT/'test-native'
    test_obj = folder/'test-native.obj'
    cmd = [test['command'][0], *flags_without_output(test['command'], test['source']['path']),
        '/sourceDependencies', str(folder/'dependencies.json'), test['source']['path'],
        '/Fo'+str(test_obj), '/Fd'+str(folder/'test-native.pdb')]
    b.execute(cmd, native.env, folder, 120)
    b.save(folder/'identity.json', dict(source=b.identity(test['source']['path']), object=b.identity(test_obj), command=cmd))
    old = b.read(BASE/'link-plan.json')
    cmd = [str(test_obj) if arg == test['object']['path'] else arg for arg in old['command']
           if not arg.upper().startswith(('/OUT:', '/MAP:', '/IMPLIB:', '/PDB:'))]
    folder = OUT/'link'
    image = folder/'f32-paged-check.exe'
    cmd += ['/OUT:'+str(image), '/MAP:'+str(image.with_suffix('.map')), '/IMPLIB:'+str(image.with_suffix('.lib'))]
    b.save(OUT/'link-plan.json', dict(command=cmd, base=b.identity(BASE/'link-plan.json'),
        fresh_test_TUs=1, fresh_native_TUs=1, reused_product_TUs=5))
    b.execute(cmd, native.env, folder, 120)
    os.link(dll, folder/dll.name)
    ready = b.read(BASE/'ready.json')
    b.save(OUT/'ready.json', dict(image=b.identity(image), DLL=b.identity(dll), PATH=ready['PATH']))


def run(name, selection):
    ready = b.read(OUT/'ready.json')
    b.require(ready['image'])
    result = b.execute([ready['image']['path'], '--gtest_filter='+selection,
        '--gtest_output=json:'+str(OUT/(name+'-gtest.json'))],
        dict(os.environ, PATH=ready['PATH']), OUT/name, 90)
    b.save(OUT/(name+'-summary.json'), dict(process=result, tests=b.identity(OUT/(name+'-gtest.json')),
        DLL=ready['DLL'], passed=True, performance_claim=False, full_Q27_execution=False))


if __name__ == '__main__':
    if sys.argv[1] == 'compile':
        compile_all()
    elif sys.argv[1] == 'oracle':
        run('oracle', 'GgmlCpuPaged.Float32Qwen27GeometryPreservesDtypeCausalWindowsAndPartialPageMath:NativePagedMetadata.Float32*:ComputeOpsCacheStorage.*')
    elif sys.argv[1] == 'regression':
        run('regression', 'GgmlCpuPaged.*:NativePagedMetadata.*:BatchLayout.*:ComputeOpsCacheStorage.*')
    else:
        raise SystemExit('compile, oracle or regression')
