Focused Windows CPU F32 native-paged regression evidence.
51 tests passed; the separate 7-test oracle is a subset, not 7 additional cases.
Only one native ggml ops.cpp TU was rebuilt, applying 26 existing product attention edits to the retained v3 closure.
Reproduction scripts require the explicitly recorded local caches and toolchain; this is not a portable SDK or a full rebuild.
The source-review patch also includes the parent agent's pre-existing BatchLayout metadata-budget edits; those were preserved.
CacheStorage remains 8 bytes but has a new semantic tag in former padding. Rebuild matching headers/libraries; no binary-compatibility claim.
No full Q27 inference, full model IQ validation, other-backend F32 qualification, memory peak, or throughput claim.
