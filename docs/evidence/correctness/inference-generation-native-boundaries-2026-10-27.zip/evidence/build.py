from pathlib import Path
import importlib.util, json, os, sys, traceback
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;R=W.parents[1]
B=R/'.scratch/inference-generation-batch-continuation-20261027'
G=R/'.scratch/inference-identical-capture-inputs-20261027'
spec=importlib.util.spec_from_file_location('native_boundaries_previous',B/'build.py')
previous=importlib.util.module_from_spec(spec);spec.loader.exec_module(previous)
m,h,exact=previous.m,previous.h,previous.exact
m.W=W
PROBES={
'r1':dict(file='tests/tools/qwen_generation_relay_probe.cc',bytes=25375,sha256='b8ab52efb40dd4ce6a383344040d144dca4d6575480a80d4ec932fece2acb6c4',baseline='r1-probe1'),
'r2':dict(file='tests/tools/qwen_generation_batch_relay_probe.cc',bytes=29224,sha256='1f71562c83d30367b4811df8c3f55622fe87303d4905672f8016467c0f2f68a7',baseline='probe1')}

def environment():
    env=dict(os.environ);env.update(m.read(B/'environment.json'))
    env['PATH']=str(W/'bin')+';'+m.read(G/'runtime.json')['PATH']
    for k in ['HF_HUB_OFFLINE','HF_DATASETS_OFFLINE','TRANSFORMERS_OFFLINE']:env[k]='1'
    return env

def compile_command(template,snapshot,out):
    argv=[]
    for index,arg in enumerate(template):
        if index and template[index-1].lower()=='/sourcedependencies':arg=str(out/'dependencies.json')
        elif arg.lower().startswith('/fo'):arg='/Fo'+str(out/'unit.obj')
        elif arg.lower().startswith('/fd'):arg='/Fd'+str(out/'unit.pdb')
        elif arg.lower().endswith(('.cc','.cpp','.cxx')):arg=str(snapshot)
        argv.append(arg)
    for p in [R/'engine/models/qwen35',R/'tests/tools']:
        if '/I'+str(p) not in argv:argv.insert(1,'/I'+str(p))
    assert m.build_contract(argv)==m.build_contract(template)
    for prefix in ['/Fo','/Fd']:
        values=[x[len(prefix):] for x in argv if x.lower().startswith(prefix.lower())]
        assert len(values)==1 and Path(values[0]).is_relative_to(W)
    return argv

def freeze():
    assert not (W/'build-plan.json').exists()
    graph=m.read(G/'compile/executable/compiled.json')
    for field in ['object','source','original_source','actual_dependencies']:exact(graph[field])
    assert graph['original_source']['sha256']=='f160c92d3d369de9b469b0976ae4a42a1928f6c4265f13345c2cbff1d1010e6f'
    for row in m.read(graph['actual_dependencies']['path']):exact(row)
    main=m.pin(R/'engine/models/qwen35/main.cc')
    assert (main['bytes'],main['sha256'])==(544472,'e0067b13c7d60ba5bcdb5ca236898bbf12b61b4d96b4411d8b8cd23b40177cb2')
    helper=m.pin(R/'tests/tools/qwen_generation_state_case.h')
    assert (helper['bytes'],helper['sha256'])==(9967,'9baaacac400112fa2af8b6a9be3158f39ed5f6ff4dcb63611cb5579e222787c0')
    geometry=m.pin(R/'tests/tools/qwen_geometry_fixture.h')
    units=[];checked={}
    for name,settings in PROBES.items():
        baseline=m.read(B/('ready-'+settings['baseline']+'.json'))
        rows=m.read(baseline['inputs']['path']);assert len(rows)==223
        for row in rows:
            if m.key(row['path']) not in checked:exact(row);checked[m.key(row['path'])]=row
        index=m.index(rows);old_graph=index[m.key(R/'src/graph/executable.cc')]['object']
        old_probe=baseline['compiled']['object'];assert sum(x==old_probe for x in rows)==1
        weights=index[m.key(R/'engine/models/qwen35/weights.cc')]
        weight_deps=[]
        for path in weights['data']['Includes']:
            if Path(path).resolve().is_relative_to(R):weight_deps.append(m.pin(path))
        # The prior successful combined TU's actual Includes are the starting
        # closure. Add the two changed/new helper headers before any compiler.
        before={}
        for row in m.read(baseline['compiled']['actual_dependencies']['path']):
            if Path(row['path']).suffix.lower() in ['.h','.cc']:
                exact(row);before[m.key(row['path'])]=row
        original=m.pin(R/settings['file'])
        assert (original['bytes'],original['sha256'])==(settings['bytes'],settings['sha256'])
        sources=[];root=W/'source'/name
        for pin,relative in [(original,settings['file']),(helper,'tests/tools/qwen_generation_state_case.h'),
                             (geometry,'tests/tools/qwen_geometry_fixture.h'),(main,'engine/models/qwen35/main.cc')]:
            snapshot=root/relative;snapshot.parent.mkdir(parents=True,exist_ok=True);snapshot.write_bytes(Path(pin['path']).read_bytes())
            sources.append(dict(original=pin,snapshot=m.pin(snapshot)))
            before[m.key(pin['path'])]=pin;before[m.key(snapshot)]=m.pin(snapshot)
        for row in weight_deps:before[m.key(row['path'])]=row
        dependencies=W/(name+'-precompile-dependencies.json');m.save(dependencies,list(before.values()))
        recipe=B/'logs'/settings['baseline']/'command.json'
        out=W/'compile'/name
        unit=dict(name=name,sources=sources,recipe=m.pin(recipe),dependencies=m.pin(dependencies),
            command=compile_command(m.read(recipe)['command'],Path(sources[0]['snapshot']['path']),out),object=str(out/'unit.obj'),
            baseline_ready=m.pin(B/('ready-'+settings['baseline']+'.json')),baseline_inputs=baseline['inputs'],
            original_graph=old_graph,original_probe=old_probe,weights=weights['object'],weights_current_local_dependencies=weight_deps,
            link_recipe=m.pin(B/('link-'+settings['baseline'])/'command.json'))
        m.save(W/('source-freeze-'+name+'.json'),unit);units.append(unit)
    (W/'bin').mkdir(exist_ok=True)
    env=environment();m.save(W/'environment.json',{k:env.get(k,'') for k in ['PATH','INCLUDE','LIB','LIBPATH']})
    m.save(W/'runtime.json',dict(original=m.pin(B/'runtime.json'),graph_runtime=m.pin(G/'runtime.json'),
        original_native_cpu=m.read(B/'runtime.json')['original_native_cpu'],PATH=env['PATH']))
    m.save(W/'build-plan.json',dict(status='FROZEN_NOT_BUILT',units=units,graph=graph,cli_reference=m.pin(G/'ready-cli.json'),
        main=main,helper=helper,geometry=geometry,runtime=m.pin(W/'runtime.json'),
        counts=dict(CXX=2,links=2,inputs_per_image=223,planned_processes=4,SDK=0,NVCC=0,downloads=0),
        boundary='Two original combined probes only. Each original 223-input W6 closure replaces Graph and its combined probe object; no standalone Model/CLI/entry duplication. Frozen relative source trees use the actual original include directories. Local untrained EOS payload is generated by the test, not downloaded.'))
    print('FROZEN R1/R2; 2 CXX / 2 links / 4 planned CUDA processes',flush=True)

def compile_probe(name):
    unit=m.read(W/('source-freeze-'+name+'.json'))
    for row in unit['sources']:exact(row['original']);exact(row['snapshot'])
    exact(unit['recipe']);before={m.key(x['path']):x for x in m.read(unit['dependencies']['path'])}
    for row in before.values():exact(row)
    out=Path(unit['object']).parent;out.mkdir(parents=True,exist_ok=False)
    process=h.execute(unit['command'],environment(),W/'logs'/name,timeout=240)
    data=m.read(out/'dependencies.json')['Data'];assert m.key(data['Source'])==m.key(unit['sources'][0]['snapshot']['path'])
    includes={m.key(x) for x in data['Includes']}
    assert all(m.key(row['snapshot']['path']) in includes for row in unit['sources'][1:])
    deps=[m.pin(x) for x in dict.fromkeys([data['Source'],*data['Includes']])]
    for row in deps:
        old=before.get(m.key(row['path']))
        if old:assert row==old,('dependency changed during CXX',row['path'])
        else:assert not Path(row['path']).resolve().is_relative_to(R),('unfrozen local actual Include',row['path'])
    for row in unit['sources']:exact(row['original']);exact(row['snapshot'])
    m.save(out/'actual-dependencies.json',deps)
    compiled=dict(name=name,sources=unit['sources'],object=m.pin(unit['object']),process=process,
        command=m.pin(W/'logs'/name/'command.json'),compiler_dependencies=m.pin(out/'dependencies.json'),
        actual_dependencies=m.pin(out/'actual-dependencies.json'))
    m.save(out/'compiled.json',compiled);print('COMPILED '+name,flush=True)

def link_probe(name):
    unit=m.read(W/('source-freeze-'+name+'.json'));compiled=m.read(W/'compile'/name/'compiled.json')
    graph=m.read(W/'build-plan.json')['graph']
    for obj in [compiled,graph]:
        exact(obj['object'])
        for row in m.read(obj['actual_dependencies']['path']):exact(row)
    for row in compiled['sources']:exact(row['original']);exact(row['snapshot'])
    rows=m.read(unit['baseline_inputs']['path']);substitutions={m.key(unit['original_graph']['path']):graph['object']['path'],
        m.key(unit['original_probe']['path']):compiled['object']['path']}
    replacement={m.key(unit['original_graph']['path']):graph['object'],m.key(unit['original_probe']['path']):compiled['object']}
    inputs=[replacement.get(m.key(x['path']),x) for x in rows];assert len(inputs)==223
    for row in inputs:exact(row)
    image=W/'bin'/('qwen-generation-'+name+'-boundaries-probe.exe')
    argv=m.link_command(m.read(unit['link_recipe']['path'])['command'],substitutions,[],image)
    manifest=W/(name+'-link-inputs.json');m.save(manifest,inputs)
    process=h.execute(argv,environment(),W/('link-'+name),timeout=180)
    ready=dict(status='LINKED_NOT_RUN',compiled=compiled,graph=graph['object'],image=m.pin(image),link=process,
        inputs=m.pin(manifest),runtime=m.pin(W/'runtime.json'),freeze=m.pin(W/('source-freeze-'+name+'.json')))
    m.save(W/('ready-'+name+'.json'),ready);print('READY '+name+' '+ready['image']['sha256'],flush=True)

def run_probe(name,mode):
    assert mode in ['boundaries','regression']
    ready=m.read(W/('ready-'+name+'.json'));exact(ready['image'])
    for row in m.read(ready['inputs']['path']):exact(row)
    tiny=R/'.scratch/inference-paged-frame-20261026/tiny-recursive-input'
    out=W/'runs'/(name+'-'+mode);assert not out.exists(),'No automatic rerun'
    argv=[ready['image']['path'],'--cuda-boundaries' if mode=='boundaries' else '--cuda',str(tiny)]
    if mode=='boundaries':argv.append(str(W/('eos-'+name)))
    process=h.execute(argv,environment(),out,timeout=240)
    report=json.loads((out/'stdout.log').read_text(encoding='utf-8-sig'));m.save(out/'report.json',report)
    assert report['status']=='PASS' and report['backend']=='cuda' and not report['performance_claim']
    if mode=='boundaries':
        assert report['requests']==(1 if name=='r1' else 2) and report['serial_and_relay_arms']==4
        assert report['model_eos_run'] and not report['extra_stop_ids'] and report['natural_cold_tuple_run']
        assert report['complete_state_ledger_rng_equal'] and report['final_live_versions']==0
        assert report['eos_successor_submissions']>0 and report['eos_successor_discards']>0
        assert report['cold_successor_refusals']>0 and report['cold_tuple_outputs']==14 if 'cold_tuple_outputs' in report else report['cold_successor_refusals']>0
        if name=='r2':assert report['actual_batch_keys_checked'] and report['survivor_r1']
    elif name=='r1':
        assert report['request_loop'] and report['credit1'] and report['credit2'] and report['pause_resume']
        assert report['after_submit_cancel'] and report['complete_state_equal'] and report['final_live_versions']==0
        assert not report['model_eos_run']
    else:
        assert report['requests']==2 and report['serial_and_relay_arms']==6
        assert report['complete_initialized_state_equal'] and report['ledger_and_rng_equal']
        assert report['actual_batch_keys_checked'] and report['real_member_credit1_blocks_b']
        assert report['accepted_b_whole_discard'] and report['survivor_r1_continues'] and report['final_versions']==0
        assert not report['model_eos_run']
    result=dict(status='PASS',name=name,mode=mode,process=process,image=ready['image'],
        report=m.pin(out/'report.json'),ready=m.pin(W/('ready-'+name+'.json')))
    m.save(out/'summary.json',result)
    results=[m.read(p) for p in sorted((W/'runs').glob('*/summary.json'))]
    m.save(W/'run-summary.json',dict(status='PASS' if len(results)==4 else 'PARTIAL_PASS',successful_processes=len(results),results=results,
        boundary='Two controlled untrained complete GA EOS/cold-tuple boundaries and two tiny original R1/R2 regressions; no quality, peer, performance, MTP successor or native-fault claim.'))
    print('PASS '+name+' '+mode+' PID'+str(process['pid']),flush=True)

if __name__=='__main__':
    try:
        action=sys.argv[1]
        if action=='freeze':freeze()
        elif action=='compile':compile_probe(sys.argv[2])
        elif action=='link':link_probe(sys.argv[2])
        elif action=='run':run_probe(sys.argv[2],sys.argv[3])
        else:raise ValueError(action)
    except BaseException:
        (W/('failure-'+'-'.join(sys.argv[1:])+'.log')).write_text(traceback.format_exc(),encoding='utf-8');raise
