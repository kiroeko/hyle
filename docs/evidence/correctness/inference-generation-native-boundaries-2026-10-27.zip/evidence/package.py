"""Offline W8 correctness archive. Run only after the owner releases the GPU.

This imports no runner, executes no model, and never downloads or rebuilds.
Synthetic/original weight payloads and all compiled binaries remain excluded.
"""
from pathlib import Path
from collections import Counter
import hashlib
import json
import shlex
import zipfile

W = Path(__file__).resolve().parent
R = W.parents[1]
B = R / '.scratch/inference-generation-batch-continuation-20261027'
DEST = R / 'docs/evidence/correctness/inference-generation-native-boundaries-2026-10-27.json'
CACHE = {}
ARCHIVE = {}


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def key(path):
    return str(Path(path).resolve()).casefold()


def pin(path):
    path = Path(path).resolve()
    if key(path) not in CACHE:
        digest = hashlib.sha256()
        with path.open('rb') as stream:
            for block in iter(lambda: stream.read(4 << 20), b''):
                digest.update(block)
        CACHE[key(path)] = dict(path=str(path), bytes=path.stat().st_size, sha256=digest.hexdigest())
    return dict(CACHE[key(path)])


def exact(row):
    actual = pin(row['path'])
    assert (actual['bytes'], actual['sha256']) == (row['bytes'], row['sha256']), (row, actual)
    return actual


def encoded(value):
    return (json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + '\n').encode('utf-8')


def add(path, name=None):
    path = Path(path).resolve()
    assert path.suffix.lower() in ('.py', '.json', '.cc', '.h', '.log', '.txt', '.tsv', '.ids', '.diff', '.xml')
    assert path.stat().st_size < 4 << 20, ('Unexpected large archive member', path)
    if name is None:
        name = 'evidence/' + path.relative_to(W).as_posix()
    assert '..' not in Path(name).parts
    if name in ARCHIVE:
        assert pin(ARCHIVE[name])['sha256'] == pin(path)['sha256']
    else:
        ARCHIVE[name] = path


def row_key(row):
    return (key(row['path']), row['bytes'], row['sha256'])


def dependencies(compiled):
    for field in ('object', 'command', 'compiler_dependencies', 'actual_dependencies'):
        exact(compiled[field])
    assert compiled['process']['exit'] == 0
    rows = read(compiled['actual_dependencies']['path'])
    for row in rows:
        exact(row)
        path = Path(row['path']).resolve()
        # Archive only project source/header inputs, never SDK dependencies.
        if path.is_relative_to(R) and not path.is_relative_to(R / '.scratch'):
            assert path.parts[len(R.parts)] in ('include', 'src', 'engine', 'tests')
            add(path, 'repository/' + path.relative_to(R).as_posix())
    return len(rows)


def manifest_roles(path, generated=None):
    lines = Path(path).read_text(encoding='utf-8-sig').splitlines()
    assert lines[0] == 'HYLE_QWEN_ROLE_FILES_V2'
    rows = []
    for line in lines[3:]:
        if not line.strip():
            continue
        fields = shlex.split(line)
        rank = int(fields[2])
        assert len(fields) == rank + 6
        source, offset, size = Path(fields[-3]).resolve(), int(fields[-2]), int(fields[-1])
        assert offset >= 0 and size > 0 and offset + size <= source.stat().st_size
        row = dict(name=fields[0], dtype=fields[1], shape=list(map(int, fields[3:3 + rank])),
                   source=str(source), offset=offset, bytes=size)
        if generated is not None and key(source) == key(generated['path']):
            row['generated_payload_sha256'] = generated['sha256']
        else:
            # These are only the selected, small original tiny roles. Record
            # both complete source identity and the exact reused byte range.
            row['source_identity'] = pin(source)
            with source.open('rb') as stream:
                stream.seek(offset)
                data = stream.read(size)
            assert len(data) == size
            row['range_sha256'] = hashlib.sha256(data).hexdigest()
        rows.append(row)
    assert len({row['name'] for row in rows}) == len(rows)
    return dict(manifest=pin(path), signature=lines[0], test_identity=lines[1], geometry=lines[2], roles=rows)


def main():
    summary = read(W / 'run-summary.json')
    assert summary['status'] == 'PASS' and summary['successful_processes'] == 4
    assert not DEST.exists() and not DEST.with_suffix('.zip').exists(), 'Do not overwrite evidence'
    plan = read(W / 'build-plan.json')
    assert len(plan['units']) == 2
    assert plan['counts'] == dict(CXX=2, links=2, inputs_per_image=223, planned_processes=4, SDK=0, NVCC=0, downloads=0)
    failures = sorted(W.glob('failure-*.log'))
    assert not failures, ('Preserve and report an unexpected failed attempt before archiving', failures)
    graph = plan['graph']
    assert graph['original_source']['sha256'] == 'f160c92d3d369de9b469b0976ae4a42a1928f6c4265f13345c2cbff1d1010e6f'
    graph_dependencies = dependencies(graph)
    add(graph['source']['path'], 'repository/src/graph/executable.cc')
    for field in ('command', 'compiler_dependencies', 'actual_dependencies'):
        add(graph[field]['path'], 'reused-graph/' + Path(graph[field]['path']).name)
    exact(plan['runtime'])
    runtime = read(plan['runtime']['path'])
    for field in ('original', 'graph_runtime', 'original_native_cpu'):
        exact(runtime[field])
    builds = {}
    for unit in plan['units']:
        name = unit['name']
        assert name in ('r1', 'r2') and name not in builds
        ready = read(W / ('ready-' + name + '.json'))
        compiled = read(W / 'compile' / name / 'compiled.json')
        assert ready['compiled'] == compiled and compiled['sources'] == unit['sources']
        verified = dependencies(compiled)
        for pair in unit['sources']:
            assert pair['original']['sha256'] == pair['snapshot']['sha256']
            exact(pair['snapshot'])
        main_source = next(pair for pair in unit['sources'] if pair['original']['path'] == plan['main']['path'])
        assert main_source['snapshot']['sha256'] == 'e0067b13c7d60ba5bcdb5ca236898bbf12b61b4d96b4411d8b8cd23b40177cb2'
        for field in ('image', 'inputs', 'runtime', 'freeze'):
            exact(ready[field])
        assert ready['link']['exit'] == 0 and ready['graph'] == graph['object']
        for field in ('recipe', 'dependencies', 'baseline_ready', 'baseline_inputs', 'link_recipe'):
            exact(unit[field])
            add(unit[field]['path'], 'baseline/' + name + '/' + field + '-' + Path(unit[field]['path']).name)
        before, after = read(unit['baseline_inputs']['path']), read(ready['inputs']['path'])
        assert len(before) == len(after) == 223
        assert before.count(unit['original_graph']) == before.count(unit['original_probe']) == 1
        replacement = {row_key(unit['original_graph']): graph['object'], row_key(unit['original_probe']): compiled['object']}
        assert after == [replacement.get(row_key(row), row) for row in before]
        for row in after:
            exact(row)
        for row in unit['weights_current_local_dependencies']:
            exact(row)
        old, new = Counter(map(row_key, before)), Counter(map(row_key, after))
        builds[name] = dict(ready=pin(W / ('ready-' + name + '.json')), image=ready['image'],
            compiled=compiled, graph=graph['object'], verified_dependencies=verified,
            inputs=ready['inputs'], input_count=len(after), link=ready['link'],
            exactly_two_replacements=True,
            removed=[dict(path=item[0], bytes=item[1], sha256=item[2], count=count) for item, count in (old - new).items()],
            added=[dict(path=item[0], bytes=item[1], sha256=item[2], count=count) for item, count in (new - old).items()])
    expected = [('r1', 'boundaries'), ('r1', 'regression'), ('r2', 'boundaries'), ('r2', 'regression')]
    assert [(row['name'], row['mode']) for row in summary['results']] == expected
    results, reports, comparisons = [], {}, {}
    for record in summary['results']:
        name, mode = record['name'], record['mode']
        folder = W / 'runs' / (name + '-' + mode)
        assert record['status'] == 'PASS' and record['process']['exit'] == 0
        assert read(folder / 'summary.json') == record and read(folder / 'process.json') == record['process']
        exact(record['report']); exact(record['ready'])
        assert record['image'] == builds[name]['image']
        report = read(record['report']['path'])
        assert report == read(folder / 'stdout.log')
        assert report['status'] == 'PASS' and report['backend'] == 'cuda' and not report['performance_claim']
        command = read(folder / 'command.json')['command']
        assert command[0] == record['image']['path']
        assert command[1] == ('--cuda-boundaries' if mode == 'boundaries' else '--cuda')
        if mode == 'boundaries':
            assert report['requests'] == (1 if name == 'r1' else 2) and report['serial_and_relay_arms'] == 4
            for field in ('model_eos_run', 'natural_cold_tuple_run', 'cold_ignores_model_eos', 'complete_state_ledger_rng_equal'):
                assert report[field]
            assert not report['extra_stop_ids'] and not report['model_quality_claim']
            assert report['final_live_versions'] == 0
            assert report['eos_successor_submissions'] == report['eos_successor_discards'] == 1
            assert report['eos_successor_publications'] == report['cold_successor_submissions'] == 0
            assert report['cold_successor_refusals'] == 1
            assert report['eos_outputs'] == (10 if name == 'r1' else 9)
            if name == 'r1':
                assert report['cold_tuple_outputs'] == 14
            else:
                assert report['peer_outputs'] == 14 and report['survivor_r1'] == 5 and report['actual_batch_keys_checked']
        else:
            previous = B / 'probe-runs' / ('r1-probe1-tiny' if name == 'r1' else 'probe1-tiny') / 'report.json'
            old = pin(previous)
            assert report == read(previous) and old['sha256'] == record['report']['sha256']
            add(previous, 'previous-regression/' + name + '-report.json')
            comparisons[name] = dict(previous=old, current=record['report'], complete_reports_byte_identical=True)
            assert not report['model_eos_run']
            if name == 'r1':
                assert report['serial_and_relay_arms'] == 8 and not report['late_extra_stop_run']
                assert report['late_extra_stop_missing_unique_token'] and report['final_live_versions'] == 0
                assert report['request_loop'] and report['pause_resume'] and report['after_submit_cancel'] and report['complete_state_equal']
            else:
                assert report['serial_and_relay_arms'] == 6 and report['final_versions'] == 0
                for field in ('complete_initialized_state_equal', 'ledger_and_rng_equal', 'actual_batch_keys_checked',
                              'real_member_credit1_blocks_b', 'accepted_b_whole_discard', 'survivor_r1_continues', 'peer_not_permanently_stopped'):
                    assert report[field]
        results.append(dict(**record, command=pin(folder / 'command.json'), stdout=pin(folder / 'stdout.log'), stderr=pin(folder / 'stderr.log')))
        reports[name + '-' + mode] = report
    fixtures = read(W / 'fixture-identity.json')
    assert fixtures['status'] == 'LOCAL_SYNTHETIC_FIXTURES_CREATED_AND_RUN'
    fixture_roles = {}
    for fixture in fixtures['fixtures']:
        name = fixture['name']
        assert name in builds and fixture['boundary_report'] == next(row['report'] for row in results if row['name'] == name and row['mode'] == 'boundaries')
        for field in ('manifest', 'prompt'):
            exact(fixture['files'][field])
        payload = fixture['files']['generated_payload']
        # Preserve the CPU owner's actual SHA receipt; do not hash two 64MB
        # generated payloads again, and never add them to the archive.
        assert payload['bytes'] == 63549184 and Path(payload['path']).stat().st_size == payload['bytes']
        assert len(payload['sha256']) == 64
        exact(fixture['generated_by']['header'])
        fixture_roles[name] = manifest_roles(fixture['files']['manifest']['path'], payload)
        assert len(fixture_roles[name]['roles']) == 28
    tiny = Path(fixtures['fixtures'][0]['source_fixture'])
    tiny_roles = manifest_roles(tiny / 'weights.tsv')
    for filename in ('weights.tsv', 'prompt.ids'):
        add(tiny / filename, 'original-tiny/' + filename)
    constructor = R / '.scratch/mtp-state-ports-20261024/gdn-regression/gdn.cc'
    add(constructor, 'fixture-construction/original-tiny-gdn.cc')
    recursive = R / '.scratch/inference-paged-frame-20261026/recursive.py'
    add(recursive, 'fixture-construction/original-tiny-prompt-and-manifest.py')
    # All W8 receipts/source/logs, including any preserved failure output.
    # An explicit type whitelist excludes generated weights and every binary.
    for path in sorted(W.rglob('*')):
        if not path.is_file() or '__pycache__' in path.parts:
            continue
        if path.suffix.lower() in ('.py', '.json', '.cc', '.h', '.log', '.txt', '.tsv', '.ids', '.diff', '.xml'):
            add(path)
    manifest = [dict(archive_path=name, **pin(path)) for name, path in sorted(ARCHIVE.items())]
    receipt = dict(schema_version=1, date='2026-10-27', status='PASS',
        scope='Finite original CUDA R1/R2 RequestLoop model-EOS and cold-capture tuple boundaries, plus unchanged tiny regressions.',
        counts=dict(CXX=2, distinct_TUs=2, links=2, processes=4, first_attempt_passes=4, failed_attempts=0, reruns=0,
                    boundary_processes=2, boundary_serial_and_relay_arms=8, regression_processes=2, regression_serial_and_relay_arms=14,
                    SDK=0, NVCC=0, downloads=0, new_peer_processes=0, MTP_processes=0),
        source=dict(main=plan['main'], graph=graph['original_source'], helper=plan['helper'], geometry=plan['geometry'],
                    frozen_units=[dict(name=unit['name'], sources=unit['sources']) for unit in plan['units']]),
        build=dict(plan=pin(W / 'build-plan.json'), units=builds, reused_graph=graph, reused_graph_verified_dependencies=graph_dependencies,
                   runtime=plan['runtime'], closure='Each original223-input combined-probe closure replaces exactly Graph and its probe object. No SDK rebuild or separate Model/CLI duplicate.'),
        correctness=dict(summary=pin(W / 'run-summary.json'), processes=results, complete_reports=reports, previous_regression_comparison=comparisons,
            EOS='The independent EOS arms use the original default Qwen stop policy, genuine vocabulary IDs248044/248046, and an actually accepted native B. A commits EOS; B retires with no publication. R2 peer survives and continues as R1.',
            cold_tuple='Separate cold-tuple arms intentionally ignore model EOS. After original imported capture is warmed and idle, replace the actual successor output owner, retaining the old backing. Original Graph bind revokes that capture; pending B refuses without recording/submitting; A and the subsequent ordinary path retain correct state.',
            equality='Serial versus relay generated IDs and original committed ledger facts, epochs, initialized KV/GDN/conv payloads, pending and RNG agree at comparable prefixes. Physical pages/padding are excluded. R2 ledger quota is checked against each actual credit and normalized only across serial/relay comparisons; membership is checked against actual batches.',
            unrun=['Original tiny R1 late extra-stop arm remains UNRUN because no unique token occurs at its warmed predecessor boundary. The independent wide-vocabulary default-EOS arm does not change that fact.',
                   'No injected native fault, MTP successor, continuous pipeline, non-CUDA backend, task quality or performance result is claimed.']),
        fixtures=dict(identity_receipt=pin(W / 'fixture-identity.json'), generated=fixtures['fixtures'], selected_roles=fixture_roles,
                      original_tiny=tiny_roles, original_tiny_constructor=pin(constructor), original_prompt_and_manifest_recipe=pin(recursive),
                      payload_hash_validation='Generated body SHA256 values are the actual CPU-build owner receipt, with current size checked here; not recomputed by this package. Reused original source and each selected range SHA256 are verified here.',
                      limitations='Untrained complete GA one-hot fixtures with zero residual output projections. Original state-producing branches still execute, but outputs give no trained-model quality, accuracy or real speed conclusion. Constructor and small manifests are included; all weight payloads excluded.'),
        archive=dict(path=str(DEST.with_suffix('.zip')), files=len(manifest) + 2,
                     member_manifest='archive-manifest.json', binaries_SDK_models=False,
                     boundary='Commands, frozen source/header closure, dependency/link SHA receipts and logs permit reproduction with the retained external toolchain/cache. This archive does not redistribute SDKs, libraries, binaries or weights.'))
    DEST.parent.mkdir(parents=True, exist_ok=True)
    DEST.write_bytes(encoded(receipt))
    with zipfile.ZipFile(DEST.with_suffix('.zip'), 'x', zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
        archive.writestr('receipt.json', encoded(receipt))
        archive.writestr('archive-manifest.json', encoded(manifest))
        for name, path in sorted(ARCHIVE.items()):
            archive.write(path, name)
    with zipfile.ZipFile(DEST.with_suffix('.zip')) as archive:
        assert archive.testzip() is None and len(archive.namelist()) == receipt['archive']['files']
        assert json.loads(archive.read('receipt.json')) == receipt
        assert json.loads(archive.read('archive-manifest.json')) == manifest
        for row in manifest:
            raw = archive.read(row['archive_path'])
            assert len(raw) == row['bytes'] and hashlib.sha256(raw).hexdigest() == row['sha256']
        assert all(Path(name).suffix.lower() not in ('.bin', '.obj', '.exe', '.dll', '.pdb', '.lib', '.gguf', '.safetensors') for name in archive.namelist())
    print(json.dumps(dict(status='ARCHIVED_AND_READ_BACK', receipt=pin(DEST), archive=pin(DEST.with_suffix('.zip')),
                          files=receipt['archive']['files'], new_model_build_or_test_processes=0), indent=2))


if __name__ == '__main__':
    main()
