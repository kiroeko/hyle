from pathlib import Path
import hashlib, json, os, subprocess, sys, time, zipfile

base = Path('/Users/kiro/hyle-scratch/compute-unified')
source = base / 'source-c8874688'
out = base / 'g03-pending-attention-vulkan-probe'
out.mkdir(exist_ok=True)
identity = {name: subprocess.check_output(args, text=True).strip() for name, args in [
    ('model', ['/usr/sbin/sysctl', '-n', 'hw.model']), ('arch', ['uname', '-m']),
    ('os', ['sw_vers']), ('compiler', ['xcrun', 'clang', '--version']),
    ('cpu', ['/usr/sbin/sysctl', '-n', 'hw.ncpu']), ('memory', ['/usr/sbin/sysctl', '-n', 'hw.memsize'])]}
assert identity['model'] == 'Mac16,12' and identity['arch'] == 'arm64'
assert source.is_dir() and not (source / '.git').exists()
# The immutable G01 performance source is a different directory. Do not edit it.
job = base / 'g01-native-page-vulkan-p1-job/job.json'
while json.loads(job.read_bytes())['state'] != 'TERMINAL':
    print('WAIT existing Vulkan P1; no overlapping heavy job', flush=True)
    time.sleep(15)
input_name=sys.argv[1]
with zipfile.ZipFile(out / input_name) as archive:
    manifest = json.loads(archive.read('input-manifest.json'))
    changed = []
    for item in manifest:
        relative = Path(item['path'])
        assert not relative.is_absolute() and '..' not in relative.parts
        data = archive.read(item['path'])
        assert hashlib.sha256(data).hexdigest() == item['sha256']
        destination = source / relative
        if not destination.exists() or destination.read_bytes() != data:
            destination.parent.mkdir(parents=True, exist_ok=True)
            destination.write_bytes(data)
            changed.append(item['path'])
        assert hashlib.sha256(destination.read_bytes()).hexdigest() == item['sha256']
(out / 'synced-inputs.json').write_text(json.dumps({'one_way': True, 'source': str(source),
    'base': '5eda0cc0f', 'candidate': 'SCOPED compute_batch receiver counterexample; immutable productbca/sourceterminal944', 'inputs': manifest, 'changed': changed}, indent=2)+'\n')
env = os.environ.copy()
env['PATH'] = '/Users/kiro/hyle-verify-tools/metal-17F109/shim:/opt/homebrew/bin:' + env['PATH']
record = out / 'result.json'
previous = json.loads(record.read_bytes()) if record.exists() else {}
rows = previous.get('stages', [])
old_digest = hashlib.sha256(json.dumps(previous.get('inputs', []), sort_keys=True).encode()).hexdigest()
new_digest = hashlib.sha256(json.dumps(manifest, sort_keys=True).encode()).hexdigest()
for row in rows:
    row.setdefault('input_manifest_sha256', old_digest)
def run(route, stage, args):
    attempt = 1 + sum(r['route'] == route and r['stage'] == stage for r in rows)
    log = out / f'{route}-{stage}-{attempt}.log'
    start = time.monotonic()
    with log.open('w') as stream:
        process = subprocess.Popen(args, env=env, stdout=stream, stderr=subprocess.STDOUT)
        (out/'job.json').write_text(json.dumps({'state':'RUNNING','route':route,'stage':stage,'pid':process.pid,'log':str(log)}))
        print('RUN',route,stage,'PID',process.pid,flush=True)
        result = subprocess.CompletedProcess(args, process.wait())
    row = {'route': route, 'stage': stage, 'attempt': attempt, 'command': args,
           'exit_code': result.returncode, 'input_manifest_sha256': new_digest, 'elapsed_seconds': time.monotonic()-start, 'log': str(log)}
    rows.append(row)
    record.write_text(json.dumps({'identity': identity, 'candidate': 'SCOPED compute_batch receiver counterexample; immutable productbca/sourceterminal944',
        'scope': 'actual Vulkan pending copy->raw paged attention success/cancelled-source mismatched statuses; no safe public receiver qualification',
        'inputs': manifest, 'stages': rows,
        'cumulative_seconds': sum(r['elapsed_seconds'] for r in rows)}, indent=2)+'\n')
    print(json.dumps(row), flush=True)
    if result.returncode:
        print(log.read_text(errors='replace')[-7000:], flush=True)
        (out/'job.json').write_text(json.dumps({'state':'TERMINAL','exit_code':result.returncode,'route':route,'stage':stage}))
        raise SystemExit(result.returncode)

for route, contract in [('vulkan', 'hyle_h3_contracts')]:
    if len(sys.argv) > 2 and route != sys.argv[2]:
        continue
    parent = out / 'static-source-fixture-parent'
    build = out / 'static-source-fixture-build'
    sdk = base / 'g03-copy-update-vulkan-static-sdk/relocated'
    parent.mkdir(exist_ok=True)
    cmake = parent / 'CMakeLists.txt'
    cmake.write_text('cmake_minimum_required(VERSION 3.25)\n'
        'project(g03_pending_attention_private_source_fixture LANGUAGES CXX)\n'
        'find_package(Hyle CONFIG REQUIRED COMPONENTS compute)\n'
        'add_executable(g03_pending_attention_vulkan "'+str(source/'tests/compute_batch/pending_attention_receiver_vulkan_probe.cc')+'")\n'
        'target_compile_features(g03_pending_attention_vulkan PRIVATE cxx_std_23)\n'
        'target_compile_options(g03_pending_attention_vulkan PRIVATE -Wall -Wextra -Wpedantic -Werror)\n'
        'target_include_directories(g03_pending_attention_vulkan SYSTEM PRIVATE /opt/homebrew/include)\n'
        'target_link_libraries(g03_pending_attention_vulkan PRIVATE hyle::compute)\n'
        'hyle_stage_runtime(g03_pending_attention_vulkan)\n')
    assert (sdk/'lib/libhyle_compute_route_vulkan.a').exists()
    run(route, 'configure', ['/opt/homebrew/bin/cmake', '-S', str(parent), '-B', str(build),
        '-G', 'Ninja', '-DCMAKE_BUILD_TYPE=Release', '-DCMAKE_EXPORT_COMPILE_COMMANDS=ON',
        '-DCMAKE_PREFIX_PATH='+str(sdk)])
    run(route, 'build', ['/opt/homebrew/bin/cmake', '--build', str(build), '--target', 'g03_pending_attention_vulkan', '--parallel', '4'])
    run(route, 'joint', [str(build/'g03_pending_attention_vulkan')])
    commands = json.loads(subprocess.check_output(['/opt/homebrew/bin/ninja','-C',str(build),'-t','compdb'],text=True))
    selected = []
    for suffix in ['tests/compute_batch/pending_attention_receiver_vulkan_probe.cc']:
        found = [item for item in commands if item['file'].endswith(suffix)]
        assert found, suffix
        selected.extend(found)
    assert '-DHYLE_STATIC' in selected[0]['command']
    (out/f'{route}-compiled-inputs.json').write_text(json.dumps(selected,indent=2)+'\n')
with zipfile.ZipFile(out/'raw.zip','w',zipfile.ZIP_DEFLATED) as archive:
    for path in out.iterdir():
        if path.is_file() and path.suffix in ['.json','.log','.py']:
            archive.write(path,path.name)

(out/'job.json').write_text(json.dumps({'state':'TERMINAL','exit_code':0,'cumulative_seconds':sum(r['elapsed_seconds'] for r in rows)}))
