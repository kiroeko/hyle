from pathlib import Path
import hashlib,json,os,subprocess,time,sys
BASE=Path('/Users/kiro/hyle-scratch/compute-unified');SOURCE=BASE/'source-c8874688'
PARENT=BASE/'a-cpu-apple/selected-graph/source-parent';BUILD=PARENT.parent/'source-build'
attempt=sys.argv[1];OUT=BASE/('ce14-apple-diagnostic-'+attempt);OUT.mkdir(exist_ok=False)
ordinary=json.loads((BASE/'g04-g05-apple-cache/result-ce14-3.json').read_text())
assert ordinary['state']=='TERMINAL_PASS'
identity={k:subprocess.check_output(a,text=True).strip() for k,a in (
 ('model',['sysctl','-n','hw.model']),('arch',['uname','-m']),('os',['sw_vers']),('compiler',['xcrun','clang++','--version']))}
assert identity['model']=='Mac16,12' and identity['arch']=='arm64'
inputs=[i for i in ordinary['inputs'] if i['path'].startswith(('include/hyle/','src/compute','src/graph','third_party/mlx_cast/','bench/inference_resident_sdpa/apple_encoded','bench/common/','bench/nanobench_impl.cc','third_party/nanobench/')) or i['path']=='cmake/HyleDependencyLock.json']
for item in inputs:assert hashlib.sha256((SOURCE/item['path']).read_bytes()).hexdigest()==item['sha256'],item['path']
record={'state':'SETUP','identity':identity,'inputs':inputs,'stages':[],'cumulative_seconds':0,
 'limits':'AUDITED source-only bounded P0 diagnostic. Two comparison orders and same-implementation controls; no candidate, A/A qualification, P1, SDK or whole-goal PASS.'}
child=None
def save():(OUT/'result.json').write_text(json.dumps(record,indent=2)+'\n')
save();(OUT/'runner.py').write_bytes(Path(__file__).read_bytes())
def failed(kind,error,tb):
 record.update(state='OBSERVER_ERROR_CHILD_MAY_RUN' if child and child.poll() is None else 'TERMINAL_FAIL',error=repr(error));save();sys.__excepthook__(kind,error,tb)
sys.excepthook=failed
env=os.environ.copy();env['PATH']='/Users/kiro/hyle-verify-tools/metal-17F109/shim:/opt/homebrew/bin:'+env['PATH']
def run(stage,command,add=None):
 global child
 t=time.monotonic();log=OUT/(stage+'.log')
 with log.open('w') as stream:
  child=subprocess.Popen(command,env=dict(env,**(add or {})),stdout=stream,stderr=subprocess.STDOUT)
  record.update(state='RUNNING',active_stage=stage,pid=child.pid);save();print(stage,child.pid,flush=True);code=child.wait()
 elapsed=time.monotonic()-t;record['cumulative_seconds']+=elapsed
 record['stages'].append({'stage':stage,'command':command,'env_additions':add,'exit_code':code,'elapsed_seconds':elapsed,'log':str(log)});save()
 assert code==0,stage+' failed; see '+str(log)
peer=BASE/'g01-original-ggml-peer';bench=SOURCE/'bench/inference_resident_sdpa';generated=OUT/'original-metal'
run('original-source',['python3',str(bench/'apple_encoded_peer/prepare_source.py'),'--original',str(peer),'--output',str(generated)])
target='ce14_apple_diagnostic_'+attempt;nano='ce14_diagnostic_nanobench_'+attempt;file=PARENT/'CMakeLists.txt';text=file.read_text()
assert f'add_executable({target} ' not in text
text+=f'''
add_library({nano} STATIC "{SOURCE}/bench/nanobench_impl.cc")
target_include_directories({nano} SYSTEM PUBLIC "{SOURCE}/third_party/nanobench")
add_executable({target} "{bench}/apple_encoded_page_bench.cc" "{bench}/apple_encoded_page_reference.cc")
target_compile_features({target} PRIVATE cxx_std_23)
target_compile_options({target} PRIVATE -Wall -Wextra -Wpedantic -Werror -Wno-error=overlength-strings)
target_include_directories({target} PRIVATE "{generated}" "{peer}/src/ggml-metal" "{SOURCE}/bench/common")
target_link_libraries({target} PRIVATE hyle::compute hyle::graph mlx {nano})
set_property(TARGET {target} PROPERTY INTERPROCEDURAL_OPTIMIZATION FALSE)
hyle_stage_runtime({target})
'''
file.write_text(text);(OUT/'parent.cmake').write_text(text)
run('configure',['cmake','-S',str(PARENT),'-B',str(BUILD)])
manifest=OUT/'exact-build.ninja';manifest.write_bytes((BUILD/'build.ninja').read_bytes())
run('plan',['ninja','-C',str(BUILD),'-f',str(manifest),'-n',target])
plan=(OUT/'plan.log').read_text();assert not any(x in plan for x in ('Building CUDA object','vulkan-shaders-gen'))
product_compiles=[line for line in plan.splitlines() if 'Building CXX object hyle/' in line]
assert all('hyle/src/simd/' in line for line in product_compiles),product_compiles
record['configure_invalidated_unchanged_simd_compiles']=product_compiles;save()
run('compile',['cmake','--build',str(BUILD),'--target',target,'--parallel','4'])
binary=BUILD/target;record['binary_sha256']=hashlib.sha256(binary.read_bytes()).hexdigest();save()
run('numeric',[str(binary)],{'HYLE_BENCH_VERIFY_ONLY':'1'})
for route in ('native','selected'):
 for order in (0,1):
  addition={'HYLE_BENCH_AA_ROUTE':route}
  if order:addition.update(HYLE_BENCH_RIVAL_FIRST='1',HYLE_BENCH_PEER_ALLOCATION_FIRST='1')
  run('control-'+route+'-'+str(order),[str(binary)],addition)
for order in (0,1):
 addition={'HYLE_BENCH_RIVAL_FIRST':'1','HYLE_BENCH_PEER_ALLOCATION_FIRST':'1'} if order else {}
 run('comparison-'+str(order),[str(binary)],addition)
for item in inputs:assert hashlib.sha256((SOURCE/item['path']).read_bytes()).hexdigest()==item['sha256'],item['path']
record.update(state='TERMINAL_DIAGNOSTIC_ONLY',same_implementation_controls=4,comparison_processes=2);save();print(json.dumps({'state':record['state'],'seconds':record['cumulative_seconds']}),flush=True)
