from pathlib import Path
import hashlib,json,os,subprocess,time,sys
BASE=Path('/Users/kiro/hyle-scratch/compute-unified');SOURCE=BASE/'source-c8874688'
attempt=sys.argv[1];OUT=BASE/('ce14-apple-sdk-diagnostic-'+attempt);OUT.mkdir(exist_ok=False)
shipping=json.loads((BASE/'g04-g05-encoded-sdk/result-apple-static-ce14-1.json').read_text())
assert shipping['state']=='TERMINAL_PASS'
prefix=Path(shipping['prefix']);peer=BASE/'g01-original-ggml-peer';BUILD=OUT/'build'
identity=shipping['identity'];assert identity['model']=='Mac16,12' and identity['arch']=='arm64'
inputs=[i for i in shipping['inputs'] if i['path'].startswith(('include/hyle/','src/compute','src/graph','third_party/mlx_cast/','bench/inference_resident_sdpa/apple_encoded','bench/common/','bench/nanobench_impl.cc','third_party/nanobench/')) or i['path']=='cmake/HyleDependencyLock.json']
for item in inputs:assert hashlib.sha256((SOURCE/item['path']).read_bytes()).hexdigest()==item['sha256'],item['path']
artifacts=json.loads((BASE/'g04-g05-encoded-sdk/artifacts-apple-static-ce14-1.json').read_text())
for item in artifacts:assert hashlib.sha256(Path(item['path']).read_bytes()).hexdigest()==item['sha256']
record={'state':'SETUP','identity':identity,'inputs':inputs,'sdk_artifacts':artifacts,'prefix':str(prefix),'stages':[],'cumulative_seconds':0,
 'limits':'AUDITED static-SDK-only bounded P0 diagnostic. Two comparison orders and same-implementation controls; no candidate, full A/A qualification, P1 or whole-goal PASS.'}
child=None
def save():(OUT/'result.json').write_text(json.dumps(record,indent=2)+'\n')
save();(OUT/'runner.py').write_bytes(Path(__file__).read_bytes())
def failed(kind,error,tb):
 record.update(state='OBSERVER_ERROR_CHILD_MAY_RUN' if child and child.poll() is None else 'TERMINAL_FAIL',error=repr(error));save();sys.__excepthook__(kind,error,tb)
sys.excepthook=failed
env=os.environ.copy();env['PATH']='/Users/kiro/hyle-verify-tools/metal-17F109/shim:/opt/homebrew/bin:'+env['PATH']
def run(stage,command,add=None):
 global child
 t=time.monotonic();log=OUT/(stage+'.log')
 with log.open('w') as stream:
  child=subprocess.Popen(command,env=dict(env,**(add or {})),stdout=stream,stderr=subprocess.STDOUT)
  record.update(state='RUNNING',active_stage=stage,pid=child.pid);save();print(stage,child.pid,flush=True);code=child.wait()
 elapsed=time.monotonic()-t;record['cumulative_seconds']+=elapsed
 record['stages'].append({'stage':stage,'command':command,'env_additions':add,'exit_code':code,'elapsed_seconds':elapsed,'log':str(log)});save()
 assert code==0,stage+' failed; see '+str(log)
run('configure',['cmake','-S',str(SOURCE/'bench/inference_resident_sdpa/apple_encoded_peer'),'-B',str(BUILD),'-G','Ninja','-DCMAKE_BUILD_TYPE=Release','-DCMAKE_OSX_DEPLOYMENT_TARGET=14.4','-DCMAKE_PREFIX_PATH='+str(prefix),'-DHYLE_RESIDENT_REFERENCE_SOURCE='+str(peer)])
manifest=OUT/'exact-build.ninja';manifest.write_bytes((BUILD/'build.ninja').read_bytes());target='g04_apple_encoded_bench'
run('plan',['ninja','-C',str(BUILD),'-f',str(manifest),'-n',target])
plan=(OUT/'plan.log').read_text();assert not any(x in plan for x in ('Building CUDA object','vulkan-shaders-gen','Building CXX object hyle/'))
run('compile',['cmake','--build',str(BUILD),'--target',target,'--parallel','4'])
record['binary_sha256']=hashlib.sha256((BUILD/target).read_bytes()).hexdigest();save()
run('numeric',[str(BUILD/target)],{'HYLE_BENCH_VERIFY_ONLY':'1'})
for route in ('native','selected'):
 for order in (0,1):
  addition={'HYLE_BENCH_AA_ROUTE':route}
  if order:addition.update(HYLE_BENCH_RIVAL_FIRST='1',HYLE_BENCH_PEER_ALLOCATION_FIRST='1')
  run('control-'+route+'-'+str(order),[str(BUILD/target)],addition)
for order in (0,1):
 addition={'HYLE_BENCH_RIVAL_FIRST':'1','HYLE_BENCH_PEER_ALLOCATION_FIRST':'1'} if order else {}
 run('comparison-'+str(order),[str(BUILD/target)],addition)
for item in inputs:assert hashlib.sha256((SOURCE/item['path']).read_bytes()).hexdigest()==item['sha256'],item['path']
for item in artifacts:assert hashlib.sha256(Path(item['path']).read_bytes()).hexdigest()==item['sha256']
record.update(state='TERMINAL_DIAGNOSTIC_ONLY',same_implementation_controls=4,comparison_processes=2);save();print(json.dumps({'state':record['state'],'seconds':record['cumulative_seconds']}),flush=True)
