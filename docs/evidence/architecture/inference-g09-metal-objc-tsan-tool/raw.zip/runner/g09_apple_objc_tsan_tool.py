from pathlib import Path
import hashlib,json,os,subprocess,sys,time
base=Path('/Users/kiro/hyle-scratch/compute-unified')
source=base/'source-c8874688';profile=base/'foundation-f5-native-host-apple-tsan'
parent=profile/'parent/CMakeLists.txt';build=profile/'build'
out=base/'g09-metal-objc-tsan-tool-1'
resume='--resume-preflight' in sys.argv
resume_linked='--resume-linked-binaries' in sys.argv
if not resume and not resume_linked:out.mkdir(exist_ok=False)
else:assert out.is_dir()
manifest=json.loads((base/'g09-host-risk-inputs/inputs.json').read_text())
review=json.loads((base/'g09-host-risk-inputs/g09-metal-objc-model-prospective-review-9.json').read_text())
unit=source/'src/compute_route_apple/apple_weights.mm'
canonical=unit.read_bytes();parent_before=parent.read_bytes()
assert hashlib.sha256(canonical).hexdigest()==next(x['sha256'] for x in manifest['files'] if x['path']=='src/compute_route_apple/apple_weights.mm')
assert subprocess.check_output(['sysctl','-n','hw.model'],text=True).strip()=='Mac16,12'
text=canonical.decode();assert text.count('[command addCompletedHandler:^(id<MTLCommandBuffer> completed) {')==1
assert text.count('    [command commit];')==1
text=text.replace('#import <Metal/Metal.h>','#import <Metal/Metal.h>\n#include <sanitizer/tsan_interface.h>')
text=text.replace('[command addCompletedHandler:^(id<MTLCommandBuffer> completed) {','[command addCompletedHandler:^(id<MTLCommandBuffer> completed) {\n      __tsan_acquire((__bridge void*)completed);')
text=text.replace('    [command commit];','    __tsan_release((__bridge void*)command);\n    [command commit];')
modeled=text.encode();(out/'canonical-apple_weights.mm').write_bytes(canonical);(out/'modeled-apple_weights.mm').write_bytes(modeled)
(out/'original-parent.cmake').write_bytes(parent_before)
targets=['g09_contracts','g09_pipeline','g09_pending']
candidate=parent_before.decode()+'\n# Independent validation-only external Metal ObjC publication observation.\n'
candidate+='set_target_properties('+ ' '.join(targets)+' PROPERTIES RUNTIME_OUTPUT_DIRECTORY "'+str(out/'bin')+'")\n'
(out/'modeled-parent.cmake').write_text(candidate)
os.nice(10);env=dict(os.environ,PATH='/Users/kiro/hyle-verify-tools/metal-17F109/shim:/opt/homebrew/bin:'+os.environ.get('PATH',''),
    TSAN_OPTIONS='halt_on_error=1:report_thread_leaks=0',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1')
r={'state':'AUDITED','task':'T-G09-METAL-OBJC-PUBLICATION','product_modified':False,'source_tree':manifest['tree'],'canonical_head':manifest['head'],
   'prospective_review':review,'modeled_unit':str(unit),'canonical_sha256':hashlib.sha256(canonical).hexdigest(),
   'model_sha256':hashlib.sha256(modeled).hexdigest(),'max_jobs':4,'nice':os.nice(0),'stages':[],
   'scope':'Separate finite tool task: only the original Metal command registration/commit to external completion callback publication edge. Existing RefCounted and Metal-cpp models retained. No G09 internal HB annotation, suppression, math/lifetime/API/Queue change or whole-process race-free claim.',
   'prior_failure':'g09-apple-host-tsan-1/g09_contracts.log remains the negative observation; original tested binaries are preserved at their original paths. New modeled fixtures link under this task bin directory.'}
if resume:
    previous=json.loads((out/'result.json').read_text())
    assert previous['state']=='FAIL_REQUIRES_FINITE_REVIEW' and previous['stage']=='manifest'
    assert not any(s['stage']=='build' for s in previous['stages'])
    for name in ['result.json','dry-run.log']:(out/('initial-preflight-'+name)).write_bytes((out/name).read_bytes())
    r=previous;r.pop('error',None)
    r['retained_preflight']='Original <20-line guard refused 33 edges before any build. Finite correction permits only the one modeled ObjC TU plus configuration-regenerated original SIMD CXX and corresponding archives/staging/three links, under 40 lines. No CUDA or other product compiler work.'
if resume_linked:
    previous=json.loads((out/'result.json').read_text())
    assert previous['state']=='FAIL_REQUIRES_FINITE_REVIEW' and previous['stage']=='object-disassembly'
    assert previous['canonical_source_restored'] and previous['parent_restored']
    (out/'retained-disassembly-guard-result.json').write_bytes((out/'result.json').read_bytes())
    r=previous;r.pop('error',None)
    r['retained_disassembly_guard']='Unlinked Mach-O otool text lists unresolved PC-relative calls without symbol names. Original symbol-string guard refused before tests; nm+relocations retain actual acquire/release callsite identities. Resume exact already linked binaries and object, with no reconfigure/rebuild or source overlay.'
started=time.monotonic()-(r['elapsed_seconds'] if resume or resume_linked else 0)
def save():
    r['elapsed_seconds']=time.monotonic()-started;(out/'result.json').write_text(json.dumps(r,indent=2)+'\n')
def run(stage,args,timeout=600):
    r.update(state='RUNNING',stage=stage);save();print(stage,flush=True);stamp=time.monotonic()
    with (out/(stage+'.log')).open('wb') as log:
        p=subprocess.Popen([str(x) for x in args],cwd=source,env=env,stdout=log,stderr=subprocess.STDOUT);r['child_pid']=p.pid;save()
        while True:
            try:code=p.wait(timeout=timeout);break
            except subprocess.TimeoutExpired:
                if p.poll() is None:r.setdefault('extensions',[]).append({'stage':stage,'pid':p.pid,'seconds':timeout});save();continue
                code=p.returncode;break
    r.pop('child_pid',None);r['stages'].append({'stage':stage,'command':[str(x) for x in args],'exit_code':code,'elapsed_seconds':time.monotonic()-stamp});save()
    if code:
        print((out/(stage+'.log')).read_text(errors='replace')[-10000:],flush=True);raise RuntimeError(stage+' failed')
try:
    if not resume_linked:
        unit.write_bytes(modeled);parent.write_text(candidate)
        run('configure',['/opt/homebrew/bin/cmake','-S',parent.parent,'-B',build],1800)
        run('manifest',['/opt/homebrew/bin/ninja','-C',build,'build.ninja'])
        preview=out/'preview.ninja';preview.write_bytes((build/'build.ninja').read_bytes())
        dry=subprocess.check_output(['/opt/homebrew/bin/ninja','-C',str(build),'-f',str(preview),'-n',*targets],env=env,text=True)
        (out/'dry-run.log').write_text(dry)
        compiled=[line for line in dry.splitlines() if 'Building ' in line]
        assert 'Re-running CMake' not in dry and 'Building CUDA object' not in dry and len(dry.splitlines())<40,dry
        assert compiled and all('/src/simd/' in line or '/apple_weights.mm.o' in line for line in compiled),compiled
        commands=json.loads(subprocess.check_output(['/opt/homebrew/bin/ninja','-C',str(build),'-t','compdb'],env=env,text=True))
        compile_unit=next(c for c in commands if c['file']==str(unit));assert '-fsanitize=thread' in compile_unit['command']
        (out/'modeled-compile-input.json').write_text(json.dumps(compile_unit,indent=2)+'\n')
        run('build',['/opt/homebrew/bin/ninja','-C',build,'-f',preview,'-j','4',*targets],1800)
        obj=build/compile_unit['output'];assert obj.is_file()
        r['object']={'path':str(obj),'sha256':hashlib.sha256(obj.read_bytes()).hexdigest()}
        run('object-disassembly',['otool','-tvV',obj])
    obj=Path(r['object']['path']);assert hashlib.sha256(obj.read_bytes()).hexdigest()==r['object']['sha256']
    run('object-symbols',['nm','-u',obj])
    run('object-relocations',['otool','-rv',obj])
    assert all(symbol in (out/'object-symbols.log').read_text() for symbol in ['___tsan_acquire','___tsan_release'])
    for name in targets:
        binary=out/'bin'/name;r.setdefault('binaries',[]).append({'path':str(binary),'sha256':hashlib.sha256(binary.read_bytes()).hexdigest()})
        run(name,[binary])
    r['state']='EXACT_EXTERNAL_OBJC_PUBLICATION_MODEL_THREE_CONSUMERS_PASS'
except BaseException as error:
    r.update(state='FAIL_REQUIRES_FINITE_REVIEW',error=repr(error));raise
finally:
    if unit.read_bytes()!=canonical:unit.write_bytes(canonical)
    if parent.read_bytes()!=parent_before:parent.write_bytes(parent_before)
    r['canonical_source_restored']=unit.read_bytes()==canonical
    r['parent_restored']=parent.read_bytes()==parent_before
    assert r['canonical_source_restored'] and r['parent_restored']
    save();print(json.dumps({'state':r['state'],'seconds':r['elapsed_seconds']}),flush=True)
