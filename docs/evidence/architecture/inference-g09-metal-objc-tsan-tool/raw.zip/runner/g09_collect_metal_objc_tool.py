from pathlib import Path
import hashlib,json,zipfile
base=Path('/Users/kiro/hyle-scratch/compute-unified');out=base/'g09-metal-objc-tsan-tool-1'
r=json.loads((out/'result.json').read_text());assert r['state']=='EXACT_EXTERNAL_OBJC_PUBLICATION_MODEL_THREE_CONSUMERS_PASS'
manifest=json.loads((base/'g09-host-risk-inputs/inputs.json').read_text());source=base/'source-c8874688'
assert all(hashlib.sha256((source/x['path']).read_bytes()).hexdigest()==x['sha256'] for x in manifest['files'])
old=json.loads((base/'g09-apple-host-tsan-1/result.json').read_text())
assert all(hashlib.sha256(Path(x['path']).read_bytes()).hexdigest()==x['sha256'] for x in old['binaries'])
assert all(hashlib.sha256(Path(x['path']).read_bytes()).hexdigest()==x['sha256'] for x in r['binaries'])
obj=Path(r['object']['path']);assert hashlib.sha256(obj.read_bytes()).hexdigest()==r['object']['sha256']
archive=base/'g09-metal-objc-tsan-tool-checkpoint.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,6) as z:
    for p in sorted(out.iterdir()):
        if p.is_file():z.write(p,p.name)
    z.write(obj,'object/apple_weights.mm.o')
    z.write(base/'g09-host-risk-inputs/g09_apple_objc_tsan_tool.py','runner/g09_apple_objc_tsan_tool.py')
    z.write(base/'g09-host-risk-inputs/inputs.json','inputs/source-inputs.json')
    z.writestr('restoration-and-original-binaries.json',json.dumps({'full_source_tree_matches':manifest['tree'],'original_all_five_binaries_unchanged':old['binaries'],'modeled_binaries':r['binaries']},indent=2)+'\n')
with zipfile.ZipFile(archive) as z:assert z.testzip() is None
print(json.dumps({'path':str(archive),'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'bytes':archive.stat().st_size}))
