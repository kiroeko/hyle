from pathlib import Path
import hashlib
import json
import subprocess
import zipfile

root = Path(__file__).resolve().parents[3]
work = root / '.scratch/inference-gaps/g03/native-producer-shape'
script = root / '.scratch/inference-gaps/g03/native_producer_shape_air.py'
text = script.read_text()
text = text.replace("'base': '06d8a394e', 'candidate': 'AUDITED WORKTREE draft'", "'base': 'cfb883a3bb819cb171325daecc42dfe60f0733bd', 'candidate': 'SCOPED public probe; product unchanged b42832de3ddda21bdc3e98ad4cc87e73622cbba4'")
text = text.replace("'candidate': 'AUDITED WORKTREE draft'", "'candidate': 'SCOPED public probe; product unchanged b42832de3ddda21bdc3e98ad4cc87e73622cbba4'")
text = text.replace("'scope': 'actual native64 two-request dirty update then original page attention; public hyle::compute; no pending/zero-wait claim'", "'scope': 'actual two ready Apple ABS outputs -> readonly export -> original F2 copy; fixed resource identity qualification; not complete pending page attention'")
script.write_text(text)
relative = 'tests/compute_batch/native_producer_copy_shape_probe.cc'
data = (root / relative).read_bytes()
manifest = [{'path': relative, 'sha256': hashlib.sha256(data).hexdigest()}]
number = 1
while (work / f'input-{number}.zip').exists():
    number += 1
archive = work / f'input-{number}.zip'
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED) as package:
    package.writestr(relative, data)
    package.writestr('input-manifest.json', json.dumps(manifest, indent=2)+'\n')
host = 'kiro@172.22.10.198'
remote = '/Users/kiro/hyle-scratch/compute-unified/g03-native-producer-shape'
subprocess.run(['scp', '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=10', str(archive), str(script), f'{host}:{remote}/'], check=True)
result = subprocess.run(['ssh', '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=10', host, f'python3 {remote}/{script.name} {archive.name} apple'])
subprocess.run(['scp', '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=10', f'{host}:{remote}/result.json', f'{host}:{remote}/job.json', str(work)], check=True)
raise SystemExit(result.returncode)
