from pathlib import Path
import ctypes,hashlib,json,os,subprocess,time
root=Path('C:/public/project-hyle/hyle');source=root/'.scratch/inference-gaps/g09-p1-instrument-adapter'
out=root/'.scratch/inference-gaps/g09-p1-instrument-builds/windows-cuda-probe';build=Path('C:/h7/g09-p1-instrument/cuda/probe-build')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();p=source/'source-ledger.json';record=json.loads(p.read_text(encoding='utf8'))
(source/'source-ledger-before-launcher-policy.json').write_bytes(p.read_bytes())
record['sampling_topology']='Windows native-runtime-pair; actual Air single-logical-cpu profile with explicit UI QoS and no hard affinity'
record['sampling_worker_count']=None
record['launcher_policy_clarification']='Before any A/A/performance: keep both original Scheduler2 pools unchanged behind each opaque C table. Use original native-runtime-pair parent two-physical-core budget + caller singleton pin; helpers remain runtime-managed, with no worker singleton/count attestation. No private thread-name pinning, changed scheduler defaults or product/perf-core code. Air uses original QoS profile. Wrapper adds only actual original policy telemetry before existing main.'
record['source_files']=[{'path':x.relative_to(source).as_posix(),'sha256':sha(x),'bytes':x.stat().st_size} for x in sorted(source.rglob('*')) if x.is_file() and not x.name.startswith('source-ledger')]
p.write_text(json.dumps(record,indent=2)+'\n',encoding='utf8')
prior=out/'build-result.json';r=json.loads(prior.read_text(encoding='utf8'));assert r['state']=='P1_ORIGINAL_INSTRUMENT_ARGV_ADAPTER_AND_CONTROLS_BUILT_NOT_SAMPLED'
(out/'initial-argv-build-result.json').write_bytes(prior.read_bytes())
binary=Path(r['driver']['path']);assert sha(binary)==r['driver']['sha256'];(out/'initial-argv-adapter.exe').write_bytes(binary.read_bytes())
setup=subprocess.check_output(['cmd','/d','/c',str(root/'.scratch/inference-gaps/g01/cpu-ragged-env.cmd')],encoding='utf8',errors='replace');env={k.upper():v for k,v in os.environ.items()};env.update((k.upper(),v) for k,v in (x.split('=',1) for x in setup.splitlines() if '=' in x and not x.startswith('=')))
started=time.monotonic()
with (out/'launcher-policy-build.log').open('wb') as log:
 child=subprocess.Popen(['cmake','--build',str(build),'-j','4','--target','g09_pipeline_primary'],env=env,stdout=log,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NO_WINDOW|subprocess.BELOW_NORMAL_PRIORITY_CLASS)
 setmask=ctypes.windll.kernel32.SetProcessAffinityMask;setmask.argtypes=[ctypes.c_void_p,ctypes.c_size_t];assert setmask(ctypes.c_void_p(int(child._handle)),15)
 code=child.wait(timeout=1800)
assert code==0,(out/'launcher-policy-build.log').read_text(errors='replace')
r['stages'].append({'stage':'launcher-policy-incremental-build','exit_code':code,'elapsed_seconds':time.monotonic()-started,'reason':record['launcher_policy_clarification']})
r['elapsed_seconds']+=time.monotonic()-started;r['source_record_sha256']=sha(p);r['wrapper_source_sha256']=sha(source/'wrapper.cc');r['driver']={'path':str(binary),'sha256':sha(binary),'bytes':binary.stat().st_size}
prior.write_text(json.dumps(r,indent=2)+'\n',encoding='utf8');print(r['state'],r['elapsed_seconds'],r['driver']['sha256'])
