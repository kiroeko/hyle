from pathlib import Path
import hashlib,json,struct

root=Path('C:/public/project-hyle/hyle');scratch=root/'.scratch/inference-gaps'
review=json.loads((scratch/'g09-pe-vendor-export-review-13.json').read_text(encoding='utf8'))
digest=lambda data:hashlib.sha256(data).hexdigest()
rows=[]
for kind in ['baseline','candidate']:
 archive=Path('C:/h7')/('g08-sdk' if kind=='baseline' else 'g09-sdk')/'vulkan-static-1/relocated/lib/hyle_compute_provider_native.lib'
 data=archive.read_bytes();assert data[:8]==b'!<arch>\n';offset=8;longnames=b'';found=[]
 while offset<len(data):
  header=data[offset:offset+60];size=int(header[48:58]);body=data[offset+60:offset+60+size];name=header[:16].decode().strip()
  if name=='//':longnames=body
  elif name.startswith('/') and name[1:].isdigit():
   start=int(name[1:]);name=longnames[start:].split(b'\x00',1)[0].split(b'/\n',1)[0].decode()
  if name.endswith('aten_cpu_provider.cc.obj'):found.append((name,body))
  offset+=60+size+size%2
 assert len(found)==1
 name,body=found[0];assert body[:8]==bytes.fromhex('0000ffff02006486')
 count=struct.unpack_from('<I',body,44)[0];sections=[]
 for n in range(count):
  header=body[56+40*n:96+40*n]
  if header[:8].rstrip(b'\x00')==b'.drectve':
   size,start=struct.unpack_from('<II',header,16);sections.append(body[start:start+size])
 assert len(sections)==1;directives=sections[0]
 assert digest(directives)==review['sdk_archive_object_provenance']['directives_sha256']
 rows.append({'image_set':kind,'archive':str(archive),'archive_sha256':digest(data),'member':name,'member_sha256':digest(body),'member_bytes':len(body),'directives_sha256':digest(directives),'directives_bytes':len(directives)})
assert rows[0]['archive_sha256']==rows[1]['archive_sha256']
assert rows[0]['member_sha256']==rows[1]['member_sha256']
r={'schema':'hyle.g09.windows-vulkan-vendor-provenance/v1','state':'EXACT_OLD_NEW_VULKAN_ARCHIVE_OBJECT_AND_R13_DIRECTIVES_BOUND_BEFORE_CONSTRUCTION_NOT_ARTIFACT_PASS',
 'scope':'Finite Windows Vulkan preconstruction envelope derived from actual unchanged old/new static SDK objects and independently reviewed R13 PE isolation reasoning. No wildcard, runtime, performance or private HYLE ABI exception.',
 'rows':rows,'vendor_symbol_allowlist':review['actual_exports']['vendor_symbol_allowlist'],'exact_vendor_name_set_sha256':review['actual_exports']['exact_vendor_name_set_sha256'],
 'cross_route_limit':'Vulkan archive/member bytes differ from CUDA qualification; both actual Vulkan sides match each other and original export .drectve bytes are identical to R13. This is not a claim of equal whole-route object bytes.',
 'next':'Only construct original frozen consumer images, enforce exact77+getter and original object map attribution, reject all HYLE private exports/imports/forwarders. Actual Vulkan PE/import/text/loader/math must still be checked before A/A/formal.'}
p=scratch/'g09-vulkan-pe-vendor-provenance.json';assert not p.exists();p.write_text(json.dumps(r,indent=2)+'\n',encoding='utf8');print(json.dumps({k:v for k,v in r.items() if k!='vendor_symbol_allowlist'},indent=2))
