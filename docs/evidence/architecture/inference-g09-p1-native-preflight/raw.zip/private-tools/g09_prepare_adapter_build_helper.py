from pathlib import Path
import ast,hashlib,json
scratch=Path('.scratch/inference-gaps');source=scratch/'g09-p1-instrument-adapter';ledger=source/'source-ledger.json'
record=json.loads(ledger.read_text(encoding='utf8'))
assert not (source/'source-ledger-initial.json').exists()
(source/'source-ledger-initial.json').write_bytes(ledger.read_bytes())
record['prebuild_resource_clarification']='Before any build or A/A: copy only the original identical1.2MB Windows CPU C-ABI runtime or1.67MB Apple mlx.metallib beside the no-argv executable, as required by original runtime lookup. No source/SDK/native rebuild, DLL path hook or public helper rewrite.'
record['source_files']=[{'path':p.relative_to(source).as_posix(),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size} for p in sorted(source.rglob('*')) if p.is_file() and not p.name.startswith('source-ledger')]
ledger.write_text(json.dumps(record,indent=2)+'\n',encoding='utf8')
text=(scratch/'g09_build_process_lifetime_driver.py').read_text(encoding='utf8')
pairs=[
 ("out=root/'.scratch/inference-gaps/g09-p1-windows-process-lifetime-driver'","source=root/'.scratch/inference-gaps/g09-p1-instrument-adapter';out=root/'.scratch/inference-gaps/g09-p1-instrument-builds/windows-cuda-probe';out.mkdir(parents=True,exist_ok=False)"),
 ('C:/h7/g09-p1/cuda-driver-process-lifetime','C:/h7/g09-p1-instrument/cuda/probe-build'),
 ("sha(out/'source-record.json')","sha(source/'source-ledger.json')"),
 ("sha(out/'driver.cc')","sha(source/'driver.cc')"),
 ("'-S',out,'-B'","'-S',source,'-B'"),
 ("'-DCMAKE_EXPORT_COMPILE_COMMANDS=ON'","'-DCMAKE_EXPORT_COMPILE_COMMANDS=ON','-DG09_ROUTE=cuda'"),
 ('len(commands)==2','len(commands)==3'),
 ("{'driver.cc','nanobench_impl.cc'}","{'wrapper.cc','nanobench_impl.cc','perf_control_bench.cc'}"),
 ('C:/h7/g09-p1/cuda-candidate/bin/g09_pipeline_driver_process_lifetime.exe','C:/h7/g09-p1-instrument/cuda/probe-build/bin/g09_pipeline_primary.exe'),
 ('DRIVER_ONLY_PROCESS_LIFETIME_CORRECTION_BUILT_NO_HYLE_PRODUCT_LINK_OR_EXECUTION','P1_ORIGINAL_INSTRUMENT_ARGV_ADAPTER_AND_CONTROLS_BUILT_NOT_SAMPLED')]
for old,new in pairs:
 assert old in text,old
 text=text.replace(old,new)
ast.parse(text)
(scratch/'g09_build_instrument_adapter_windows.py').write_text(text,encoding='utf8')
print('Finite argv adapter builder prepared, original instrument inputs unchanged')
