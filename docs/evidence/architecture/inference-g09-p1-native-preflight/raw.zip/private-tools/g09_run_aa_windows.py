from pathlib import Path
import hashlib,json,os,re,secrets,statistics,subprocess,sys,time
root=Path('C:/public/project-hyle/hyle');sys.path.insert(0,str(root/'scripts'))
from hyle_perf import evaluate_machine_profile,expected_child_policy,get_machine_profile,load_registry,probe_machine
from hyle_perf.runner import _apply_sampling_policy,_child_environment,_creation_flags,_probe_child_policy
from hyle_perf.nanobench import parse_nanobench,select_pair

route=sys.argv[1];assert os.name=='nt' and route=='cuda'
source=root/'.scratch/inference-gaps/g09-p1-instrument-adapter';build=Path('C:/h7/g09-p1-instrument/cuda/probe-build');exe=build/'bin/g09_pipeline_primary.exe'
folder=root/'.scratch/inference-gaps/g09-p1-instrument-aa'/('windows-'+route);folder.mkdir(parents=True,exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();ledger=json.loads((source/'source-ledger.json').read_text(encoding='utf8'))
for row in ledger['source_files']:assert sha(source/row['path'])==row['sha256']
record=json.loads((root/'.scratch/inference-gaps/g09-p1-instrument-builds/windows-cuda-probe/build-result.json').read_text(encoding='utf8'))
assert sha(exe)==record['driver']['sha256']
ready=exe.parent/'g09_pipeline_aa.ready';ready.write_text('FAIL\n',encoding='ascii')
started=time.monotonic();profile=get_machine_profile(load_registry(),'W1-WIN');host=probe_machine(paths=[('source',source),('build',build)])
gate=evaluate_machine_profile(profile,host,role='engineering',sampling_topology='native-runtime-pair');assert gate['gate']=='PASS',gate
policy=expected_child_policy(profile,sampling_topology='native-runtime-pair',probe=host)
r={'state':'RUNNING','route':route,'runs':[],'binary':{'path':str(exe),'sha256':sha(exe)},'source_ledger_sha256':sha(source/'source-ledger.json'),'host_probe':host,'machine_gate':gate,'sampling_policy':policy,'formal_samples':0,
 'frozen_aa_rule':'Unchanged existing graph/compute workload-AA algorithm: exact four order/allocation factor combinations for baseline and candidate,5% factor medians plus10% gross per-process stop. Same4M F32 workloads/12 exact paired rounds and two facade images. No A/B or calibration tuning.'}
def save():
 r['elapsed_seconds']=time.monotonic()-started;(folder/'result.json').write_text(json.dumps(r,indent=2)+'\n',encoding='utf8')
def invoke(tag,additions):
 env=_child_environment(['HYLE_BENCH_AA_ROUTE','HYLE_BENCH_VERIFY_ONLY','HYLE_BENCH_RIVAL_FIRST','HYLE_BENCH_PEER_ALLOCATION_FIRST'],additions,profile,policy)
 log=folder/(tag+'.log');stamp=time.monotonic()
 with log.open('wb') as output:
  p=subprocess.Popen([str(exe)],env=env,stdout=output,stderr=subprocess.STDOUT,creationflags=_creation_flags(policy));r['child_pid']=p.pid;r['stage']=tag;save()
  while True:
   try:code=p.wait(timeout=1800);break
   except subprocess.TimeoutExpired:r.setdefault('time_extensions',[]).append({'pid':p.pid,'seconds':1800});save()
 r.pop('child_pid',None);text=log.read_text(encoding='utf8',errors='replace');assert code==0,text[-6000:]
 assert len(re.findall(r'^# G09_ORACLE .* before=PASS ',text,re.M))==4 and len(re.findall(r'^# G09_ORACLE .* after=PASS ',text,re.M))==4
 assert len(re.findall(r'^# G09_DEFERRED_DESTROY .* status=0$',text,re.M))==8
 return text,{'log':log.name,'sha256':sha(log),'elapsed_seconds':time.monotonic()-stamp,'exit_code':code}
try:
 with _apply_sampling_policy(policy) as applied:
  r['applied_parent_policy']=applied;r['child_canary']=_probe_child_policy(policy,_creation_flags(policy));save()
  _,r['no_argv_verify']=invoke('no-argv-verify',{'HYLE_BENCH_VERIFY_ONLY':'1','HYLE_PERF_RUN_NONCE':secrets.token_hex(16)})
  for sdk in ['baseline','candidate']:
   for peer_first in [False,True]:
    for allocation_first in [False,True]:
     tag=f'{sdk}-execute-{int(peer_first)}-allocate-{int(allocation_first)}'
     text,item=invoke(tag,{'HYLE_BENCH_AA_ROUTE':sdk,'HYLE_BENCH_RIVAL_FIRST':str(int(peer_first)),'HYLE_BENCH_PEER_ALLOCATION_FIRST':str(int(allocation_first)),'HYLE_PERF_RUN_NONCE':secrets.token_hex(16)})
     rows=parse_nanobench(text);ratios={}
     for shape in ['independent-cpu-first','independent-gpu-first','two-microbatches','serial-holdout']:
      a,b=select_pair(rows,'HYLE G09','HYLE baseline',title=f'G09 {route} {shape} warm');ratios[shape]=a.operations_per_second/b.operations_per_second
     item.update(sdk=sdk,execution_order='peer-first' if peer_first else 'candidate-first',allocation_order='peer-first' if allocation_first else 'candidate-first',ratios=ratios)
     r['runs'].append(item);save();print(tag,ratios,flush=True)
 summaries={};failures=[]
 for sdk in ['baseline','candidate']:
  matching=[x for x in r['runs'] if x['sdk']==sdk]
  for shape in matching[0]['ratios']:
   values=[x['ratios'][shape] for x in matching];medians={'all':statistics.median(values)}
   for factor in ['execution_order','allocation_order']:
    for value in sorted({x[factor] for x in matching}):medians[factor+'='+value]=statistics.median(x['ratios'][shape] for x in matching if x[factor]==value)
   outside={k:v for k,v in medians.items() if not 1/1.05<=v<=1.05};gross=[v for v in values if not 1/1.10<=v<=1.10]
   summaries[sdk+':'+shape]={'factor_medians':medians,'minimum_process_ratio':min(values),'maximum_process_ratio':max(values)}
   if outside or gross:failures.append({'sdk':sdk,'shape':shape,'factor_outside5percent':outside,'gross_process_outside10percent':gross})
 r.update(summaries=summaries,failures=failures,state='WORKLOAD_AA_PASS_NOT_FORMAL_P1' if not failures else 'WORKLOAD_AA_FAIL_NO_AB_AUTHORIZED');save()
 if not failures:ready.write_text('PASS\n',encoding='ascii')
 print(r['state'],r['elapsed_seconds'],json.dumps(failures),flush=True)
 for row in ledger['source_files']:assert sha(source/row['path'])==row['sha256']
except BaseException as error:r.update(state='PREFLIGHT_FAIL',error=repr(error));save();raise
