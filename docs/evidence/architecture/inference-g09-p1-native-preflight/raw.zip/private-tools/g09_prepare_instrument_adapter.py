from pathlib import Path
import hashlib,json,subprocess

root=Path('C:/public/project-hyle/hyle');scratch=root/'.scratch/inference-gaps'
source=scratch/'g09-p1-instrument-adapter';source.mkdir(exist_ok=False)
files={
 'driver.cc':scratch/'g09-p1-windows-process-lifetime-driver/driver.cc',
 'facade_api.h':scratch/'g09-p1-draft/facade_api.h',
 **{'instrument/'+name:root/name for name in ['bench/nanobench_impl.cc','bench/common/perf_process.h','bench/integration/perf_control_bench.cc','third_party/nanobench/nanobench.h']}}
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for name,p in files.items():
 out=source/name;out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(p.read_bytes())
(source/'wrapper.cc').write_text('''// Only argv setup for the unchanged opaque-C-table consumer.
#define main g09_fixed_driver_main
#include "driver.cc"
#undef main
int main(int argc, char **argv) {
  if (argc != 1) return g09_fixed_driver_main(argc, argv);
  char *arguments[]{argv[0], const_cast<char *>(G09_CANDIDATE_1),
      const_cast<char *>(G09_BASELINE_1), const_cast<char *>(G09_CANDIDATE_2),
      const_cast<char *>(G09_BASELINE_2)};
  return g09_fixed_driver_main(5, arguments);
}
''',encoding='utf8',newline='\n')
(source/'CMakeLists.txt').write_text('''cmake_minimum_required(VERSION 3.25)
project(g09_original_instrument_adapter LANGUAGES CXX)
set(CMAKE_CXX_STANDARD 23)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
set(CMAKE_RUNTIME_OUTPUT_DIRECTORY "${CMAKE_BINARY_DIR}/bin")
set(CMAKE_INTERPROCEDURAL_OPTIMIZATION OFF CACHE BOOL "Original no-LTO contract" FORCE)
set(HYLE_STATIC ON CACHE BOOL "The frozen SDKs embedded in both private facades are static")
set(HYLE_SIMD_EXACT_TARGET "" CACHE STRING "Original portable consumer code; native SDK ISA frozen separately")
set(G09_ROUTE "" CACHE STRING "cuda,apple,vulkan")
if(WIN32)
  set(G09_BASE "C:/h7" CACHE PATH "Qualified native artifacts")
  set(_prefix "")
  set(_suffix ".dll")
elseif(APPLE)
  set(G09_BASE "/Users/kiro/hyle-scratch/compute-unified" CACHE PATH "Actual Air native artifacts")
  set(_prefix "lib")
  set(_suffix ".dylib")
else()
  message(FATAL_ERROR "Only the four selected native profile/routes")
endif()
if(NOT G09_ROUTE MATCHES "^(cuda|apple|vulkan)$")
  message(FATAL_ERROR "Bind fixed route")
endif()
set(G09_PEER_SOURCE "" CACHE PATH "Original baseline Git identity, not a product rebuild source")
add_library(g09_nanobench STATIC instrument/bench/nanobench_impl.cc)
target_include_directories(g09_nanobench SYSTEM PUBLIC "${CMAKE_CURRENT_SOURCE_DIR}/instrument/third_party/nanobench")
add_executable(g09_pipeline_primary wrapper.cc)
target_include_directories(g09_pipeline_primary PRIVATE "${CMAKE_CURRENT_SOURCE_DIR}/instrument/bench/common")
target_link_libraries(g09_pipeline_primary PRIVATE g09_nanobench)
target_compile_definitions(g09_pipeline_primary PRIVATE "G09_ROUTE_NAME=\\"${G09_ROUTE}\\"")
foreach(_kind IN ITEMS candidate baseline)
  string(TOUPPER "${_kind}" _role)
  foreach(_copy RANGE 1 2)
    set(_file "${G09_BASE}/g09-p1/${G09_ROUTE}-${_kind}/bin/${_prefix}g09_${G09_ROUTE}_${_kind}_${_copy}${_suffix}")
    if(NOT EXISTS "${_file}")
      message(FATAL_ERROR "Frozen private image missing: ${_file}")
    endif()
    target_compile_definitions(g09_pipeline_primary PRIVATE "G09_${_role}_${_copy}=\\"${_file}\\"")
  endforeach()
endforeach()
add_executable(g09_pipeline_control instrument/bench/integration/perf_control_bench.cc)
# The unchanged control source uses only the original public compiler macros.
target_include_directories(g09_pipeline_control PRIVATE "${G09_BASE}/g09-sdk/${G09_ROUTE}-static-1/relocated/include")
target_link_libraries(g09_pipeline_control PRIVATE g09_nanobench)
if(MSVC)
  target_compile_definitions(g09_pipeline_control PRIVATE _CRT_SECURE_NO_WARNINGS)
endif()
foreach(_target IN ITEMS g09_nanobench g09_pipeline_primary g09_pipeline_control)
  set_property(TARGET ${_target} PROPERTY INTERPROCEDURAL_OPTIMIZATION FALSE)
endforeach()
''',encoding='utf8',newline='\n')
record={'schema':'hyle.g09.original-instrument-argv-adapter/v1','state':'FROZEN_BEFORE_FIRST_AA_OR_FORMAL_SAMPLE',
 'candidate':'3524413272cb52d06af5e64d634edbfef09b9864','baseline':'9e2f25c469634a6f723e76eaf1aa2db5973bca9a','product':'e09f30925c6dba5cf4540669fd3b4874f45bb158',
 'boundary':'Only supply the four original facade paths to the existing main for the unchanged hyle-perf runner no-argv executable interface. No subprocess wrapper, public tool change, timed math/ownership/Sched change, product/SDK/native rebuild or different A/A topology.',
 'workloads':['independent-cpu-first','independent-gpu-first','two-microbatches','serial-holdout'],
 'elements':4194304,'dtype':'F32','workers':2,'epochs':11,'actual_paired_rounds':12,'exact_epoch_iterations':1,'warmups_per_arm':8,
 'sampling_topology':'caller-plus-n-worker-physical-cores','sampling_worker_count':2,
 'strata':'Fixed four execution-order x allocation-and-load-order combinations; same two-image topology for both complete SDK A/A and A/B; ASLR remains OS default enabled.',
 'placement_applicability':'Code-padding/link-order control NOT_APPLICABLE to this fixed bulk4M F32 native/math/transfer journey: the declared short-code risk in benchmark-evidence-standard.md4.5 is absent. No scalar-point performance claim. Address/ownership risk IS applicable and covered by both independent allocation/load orders. This applicability is frozen before any A/A or performance data, not chosen from timing outcomes.',
 'controls':'Original common A/A,delta5,delta10,timer-floor; same-workload complete baseline/candidate two-facade A/A with original5%factor medians and10%gross stop. Original n15->31,5%,tail-alpha0.01 and no iteration/shape tuning.',
 'lifetime':'Existing Windows symmetric process-exit mapping lifetime only; POSIX dlclose code is byte-identical in behavior to the tested original Air driver. All State destructors, step owners, successful result observations/native completion and Scheduler.drain remain in their frozen phases.',
 'input_files':[{'path':name,'source':str(p.relative_to(root)).replace('\\','/'),'sha256':sha(p)} for name,p in files.items()],
 'source_files':[{'path':p.relative_to(source).as_posix(),'sha256':sha(p),'bytes':p.stat().st_size} for p in sorted(source.rglob('*')) if p.is_file()]}
(source/'source-ledger.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf8')
print(record['state'],len(record['source_files']))
