from pathlib import Path
import hashlib,json,os,re,subprocess,sys,time

base=Path('/Users/kiro/hyle-scratch/compute-unified');route=sys.argv[1]
assert sys.platform=='darwin' and route in ['apple','vulkan']
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
review=base/'g09-p1-inputs/g09-p1-air-artifact-review-16.json'
assert sha(review)=='f69ce0f9380dbf2c05acd33b9efa35444c5508bc32012f473d7a82cb438d24e3'
folder=base/'g09-p1-runtime'/route;folder.mkdir(parents=True,exist_ok=False)
started=time.monotonic();os.nice(10)
r={'state':'FREEZING_BEFORE_FIRST_RUNTIME','route':route,'stages':[],'formal_samples':0,'workload_aa_samples':0,'benchmark_compare_calls':0,'review16_sha256':sha(review),
 'scope':'Original fixed4M F32 public consumer: actual two separate static-SDK images, two load/allocation orders, all4 full before/after output oracles, completion/result retirement/State destruction and original Air explicit dlclose. No Windows lifetime exception, A/A or formal sampling.'}
def save():
 r['elapsed_seconds']=time.monotonic()-started;(folder/'result.json').write_text(json.dumps(r,indent=2)+'\n')
try:
 r['identity']={k:subprocess.check_output(v,text=True).strip() for k,v in {'model':['sysctl','-n','hw.model'],'chip':['sysctl','-n','machdep.cpu.brand_string'],'system':['sw_vers']}.items()}
 assert r['identity']['model']=='Mac16,12'
 r['builds']={};r['staged_runtime']={}
 for kind in ['baseline','candidate']:
  p=base/f'g09-p1-builds/air-{route}-{kind}/result.json';record=json.loads(p.read_text())
  assert record['state']=='TWO_PRIVATE_IMAGES_BUILT_C_ONLY_EXPORT_INITIAL_CHECKS_PASS_NOT_FINAL_ARTIFACT_QUALIFICATION'
  for item in record['images']:assert sha(Path(item['path']))==item['sha256']
  r['builds'][kind]={'path':str(p),'sha256':sha(p),'images':record['images'],'driver':record.get('driver')}
  directory=base/'g09-p1'/f'{route}-{kind}'/'bin'
  excluded={f'libg09_{route}_{kind}_{n}.dylib' for n in [1,2]}|{f'g09_{route}_{kind}_runtime_probe','g09_pipeline_driver'}
  r['staged_runtime'][kind]=[{'path':str(p),'name':p.relative_to(directory).as_posix(),'sha256':sha(p),'bytes':p.stat().st_size} for p in sorted(directory.rglob('*')) if p.is_file() and p.name not in excluded]
 assert [{k:x[k] for k in ['name','sha256','bytes']} for x in r['staged_runtime']['baseline']]==[{k:x[k] for k in ['name','sha256','bytes']} for x in r['staged_runtime']['candidate']]
 r['state']='BOTH_STAGED_NATIVE_RUNTIME_SETS_FROZEN_NOT_EXECUTED';save()
 (folder/'freeze.json').write_bytes((folder/'result.json').read_bytes())
 driver=Path(r['builds']['candidate']['driver']['path']);assert sha(driver)==r['builds']['candidate']['driver']['sha256']
 args=[driver,*[Path(r['builds'][k]['images'][n]['path']) for k,n in [('candidate',0),('baseline',0),('candidate',1),('baseline',1)]]]
 env=dict(os.environ,PATH='/Users/kiro/hyle-verify-tools/metal-17F109/shim:/opt/homebrew/bin:'+os.environ.get('PATH',''),HYLE_VULKAN_VALIDATION='0')
 for k in list(env):
  if k.startswith('HYLE_BENCH_') or k=='HYLE_PERF_RUN_NONCE':env.pop(k)
 env['HYLE_BENCH_VERIFY_ONLY']='1'
 for order in ['candidate-first','baseline-first']:
  env['HYLE_BENCH_PEER_ALLOCATION_FIRST']='1' if order=='baseline-first' else '0'
  r.update(state='RUNNING',load_allocation_order=order);save();log=folder/(order+'.log');stamp=time.monotonic()
  with log.open('wb') as output:
   p=subprocess.Popen([str(x) for x in args],env=env,stdout=output,stderr=subprocess.STDOUT);r['child_pid']=p.pid;save()
   while True:
    try:code=p.wait(timeout=1800);break
    except subprocess.TimeoutExpired:r.setdefault('time_extensions',[]).append({'pid':p.pid,'seconds':1800});save()
  r.pop('child_pid',None);text=log.read_text(errors='replace')
  stage={'order':order,'exit_code':code,'elapsed_seconds':time.monotonic()-stamp,'log_sha256':sha(log)};r['stages'].append(stage);save()
  assert code==0,text[-7000:]
  assert len(re.findall(r'^# G09_ORACLE .* before=PASS ',text,re.M))==4
  assert len(re.findall(r'^# G09_ORACLE .* after=PASS ',text,re.M))==4
  assert len(re.findall(r'^# G09_IMAGE ',text,re.M))==2 and '# G09_MEASUREMENT' not in text
  assert len(re.findall(r'^# G09_DEFERRED_DESTROY .* status=0$',text,re.M))==8
  assert len(re.findall(r'^# G09_DEFERRED_DSO_UNLOAD .* status=0 ',text,re.M))==2
  actual=sorted(set(re.findall(r'^# G09_MODULE phase=\S+ path=(.+)$',text,re.M)))
  stage['actual_loaded_modules']=[{'path':p,'sha256':sha(Path(p)) if Path(p).is_file() else None,'bytes':Path(p).stat().st_size if Path(p).is_file() else None,'identity':'FILE' if Path(p).is_file() else 'SYSTEM_DYLD_SHARED_CACHE'} for p in actual]
  # Modern macOS system dylibs may exist only in the dyld shared cache. Keep
  # explicit OS/cache identity rather than invent a per-file SHA for them.
  for item in stage['actual_loaded_modules']:
   if item['sha256'] is None:assert item['path'].startswith(('/System/Library/','/usr/lib/'))
  facades={Path(p).name for p in actual if Path(p).name.startswith('libg09_')}
  assert facades=={f'libg09_{route}_baseline_1.dylib',f'libg09_{route}_candidate_1.dylib'},facades
  stage['actual_cpu_programs']=[p for p in actual if 'hyle_ggml_cpu_' in p]
  print('VERIFY_ONLY_PASS',route,order,stage['elapsed_seconds'],len(actual),flush=True);save()
 r['state']='BOTH_LOAD_ORDERS_FULL_ORACLES_COMPLETION_STATE_DESTROY_ORIGINAL_AIR_DLCLOSE_AND_PROCESS_EXIT_PASS_NOT_AA_OR_PERFORMANCE';save();print(r['state'],flush=True)
except BaseException as error:r.update(state='DIAGNOSTIC_FAIL',error=repr(error));save();raise
