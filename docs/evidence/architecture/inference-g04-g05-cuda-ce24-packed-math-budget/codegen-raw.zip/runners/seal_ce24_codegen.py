from pathlib import Path
import hashlib,json,zipfile

root=Path.cwd();base=root/'.scratch/inference-gaps/g04-g05';run=base/'ce24-fixed-codegen-1'
r=json.loads((run/'result.json').read_text());assert r['state']=='TERMINAL_PASS' and len(r['kernels'])==3
assert r['product_candidate']=='6e57e28ada9e29ed07819fbe9a97b8a7d08271fe'
assert [row['projected_mma_kv'] for row in r['kernels']]==[1,1,4]
dest=root/'evidence/architecture/inference-g04-g05-cuda-ce24-packed-math-budget'
assert (dest/'source-audit.json').exists() and not (dest/'codegen-receipt.json').exists()
with zipfile.ZipFile(dest/'codegen-raw.zip','w',zipfile.ZIP_DEFLATED) as z:
    for p in sorted(run.rglob('*')):
        if p.is_file():z.write(p,p.relative_to(run).as_posix())
    z.write(base/'seal_ce24_codegen.py','runners/seal_ce24_codegen.py')
receipt=dict(kind='G04_G05_CE24_PROJECTED_WORKLOAD_KERNEL_CODEGEN',verdict='EXTRACTION_PASS_STATIC_RESOURCES_ONLY',
 product_candidate=r['product_candidate'],binary_sha256=r['binary_sha256'],header_sha256=r['header_sha256'],
 kernels=r['kernels'],stages=r['stages'],measured_seconds=sum(s['elapsed_seconds'] for s in r['stages']),
 limits=r['limits']+['Projected dispatch identity only; actual runtime profile still required.',
                    'All earlier qualified failures and CE22/23 failed resource hypotheses/costs retained.'],
 raw_zip_sha256=hashlib.sha256((dest/'codegen-raw.zip').read_bytes()).hexdigest())
(dest/'codegen-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n',newline='\n')
print(json.dumps([dict(projected_mma_kv=row['projected_mma_kv'],before=row['before_resource'],after=row['after_resource'],local=row['after_sass']) for row in r['kernels']],indent=2))
