from pathlib import Path
import ctypes,hashlib,json,os,subprocess,time,sys

root=Path(__file__).resolve().parents[2]
out=root/'.scratch/inference-gaps/g09-cold-submission-check-1'
resume='--resume-frontier' in sys.argv
if not resume: out.mkdir(exist_ok=False)
build=Path('C:/h7/w-cpu-cuda/selected-graph/source-build')
parent=Path('C:/h7/w-cpu-cuda/selected-graph/source-parent')
cmake=parent/'CMakeLists.txt'
if resume:
    text=cmake.read_text(encoding='utf8')
    source=(root/'tests/graph/joint_pipeline_test.cc').as_posix()
    if source not in text:
        cmake.write_text(text+'\ntarget_sources(hyle_graph_test PRIVATE "'+source+'")\n',encoding='utf8')
    sources=['graph_test.cc','lease_submission_test.cc','native_variants_test.cc',
             'effect_preflight_test.cc','custom_kernel_test.cc','joint_pipeline_test.cc']
else:
    (out/'original-parent-CMakeLists.txt').write_bytes(cmake.read_bytes())
    text=cmake.read_text(encoding='utf8')
    assert 'g09_cold_submission' not in text
    sources=['graph_test.cc','lease_submission_test.cc','native_variants_test.cc',
             'effect_preflight_test.cc','custom_kernel_test.cc']
    text+='\n# g09_cold_submission: original Graph core/direct custom consumer, shipping interfaces.\n'
    text+='add_executable(hyle_graph_test\n'+''.join('  "'+(root/'tests/graph'/s).as_posix()+'"\n' for s in sources)+')\n'
    text+='target_compile_features(hyle_graph_test PRIVATE cxx_std_23)\n'
    text+='target_link_libraries(hyle_graph_test PRIVATE hyle_graph hyle_compute_backend_cpu GTest::gtest_main)\n'
    text+='hyle_stage_runtime(hyle_graph_test)\n'
    cmake.write_text(text,encoding='utf8')
setup=subprocess.check_output(['cmd','/d','/c',str(root/'.scratch/inference-gaps/g01/cpu-ragged-env.cmd')],text=True,encoding='utf8',errors='replace')
env={k.upper():v for k,v in os.environ.items()}
env.update((k.upper(),v) for k,v in (line.split('=',1) for line in setup.splitlines() if '=' in line and not line.startswith('=')))
env['VSLANG']='1033';env['OMP_NUM_THREADS']='1';env['MKL_NUM_THREADS']='1';env['OPENBLAS_NUM_THREADS']='1'
r={'state':'SETUP','stages':[],'pid':os.getpid(),'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),
   'scope':'Partial implementation check: new native partition unit contracts and existing original Graph compile/submission/custom consumer regressions. No hybrid runtime/overlap/delivery/sanitizer/P1 verdict.',
   'sources':sources,'max_jobs':4,'priority':'BELOW_NORMAL','logical_cpu_limit':4}
if resume:
    prior=json.loads((out/'result.json').read_text(encoding='utf8'))
    (out/'result-initial.json').write_text(json.dumps(prior,indent=2)+'\n',encoding='utf8')
    r['retained_cumulative_seconds']=prior['elapsed_seconds']
    r['retained_initial_verdict']=prior['state']
    r['scope']='Partial common check extended to the new bounded dependency frontier unit contracts; native hybrid implementation is still unverified. Prior 75-test result and full cost retained.'
paths=subprocess.check_output(['git','diff','--name-only'],cwd=root,text=True).splitlines()
paths+=subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=root,text=True).splitlines()
r['input_hashes']=[{'path':p,'sha256':hashlib.sha256((root/p).read_bytes()).hexdigest()} for p in paths if (root/p).is_file()]
started=time.monotonic()
def save():
    r['elapsed_seconds']=r.get('retained_cumulative_seconds',0)+time.monotonic()-started
    (out/'result.json').write_text(json.dumps(r,indent=2)+'\n',encoding='utf8')
def run(stage,args):
    log=out/(stage+('-frontier' if resume else '')+'.log'); stamp=time.monotonic()
    with log.open('wb') as stream:
        job=subprocess.Popen([str(a) for a in args],cwd=root,env=env,stdout=stream,stderr=subprocess.STDOUT,
            creationflags=subprocess.CREATE_NO_WINDOW|subprocess.BELOW_NORMAL_PRIORITY_CLASS)
        kernel=ctypes.windll.kernel32
        kernel.GetProcessAffinityMask.argtypes=[ctypes.c_void_p,ctypes.POINTER(ctypes.c_size_t),ctypes.POINTER(ctypes.c_size_t)]
        kernel.SetProcessAffinityMask.argtypes=[ctypes.c_void_p,ctypes.c_size_t]
        available=ctypes.c_size_t();system=ctypes.c_size_t();handle=ctypes.c_void_p(int(job._handle))
        if not kernel.GetProcessAffinityMask(handle,ctypes.byref(available),ctypes.byref(system)):
            raise OSError('Cannot read process affinity')
        mask=sum([1<<i for i in range(64) if available.value&(1<<i)][:4])
        if not kernel.SetProcessAffinityMask(handle,mask):raise OSError('Cannot bound process affinity')
        r.update(state='RUNNING',stage=stage,child_pid=job.pid);save(); print(stage,job.pid,flush=True)
        code=job.wait()
    r['stages'].append({'stage':stage,'command':[str(a) for a in args],'exit_code':code,'elapsed_seconds':time.monotonic()-stamp})
    r.pop('child_pid',None);save()
    if code:
        r['state']='FAIL';save();print(log.read_text(encoding='utf8',errors='replace')[-7000:],flush=True);raise SystemExit(code)
run('manifest',['ninja','-C',build,'build.ninja'])
preview=out/('preview-frontier.ninja' if resume else 'preview.ninja'); preview.write_bytes((build/'build.ninja').read_bytes())
dry=subprocess.check_output(['ninja','-C',str(build),'-f',str(preview),'-n','hyle_graph_test'],env=env,text=True,encoding='utf8',errors='replace')
(out/('dry-run-frontier.log' if resume else 'dry-run.log')).write_text(dry,encoding='utf8')
r['dry_run_edges']=len(dry.splitlines());r['cuda_edges']=[s for s in dry.splitlines() if 'Building CUDA object' in s];save()
assert not r['cuda_edges'] and len(dry.splitlines())<100 and 'Re-running CMake' not in dry,dry
run('build',['ninja','-C',build,'-f',preview,'-j','4','hyle_graph_test'])
binary=build/'hyle_graph_test.exe'
if not binary.exists():binary=build/'bin/hyle_graph_test.exe'
assert binary.is_file(),binary
run('tests',[binary,'--gtest_output=json:'+str(out/('gtest-frontier.json' if resume else 'gtest.json'))])
result=json.loads((out/('gtest-frontier.json' if resume else 'gtest.json')).read_text(encoding='utf8'))
r.update(state='PARTIAL_COMMON_CHECK_PASS',tests=result['tests'],failures=result['failures'],disabled=result['disabled'],binary=str(binary),binary_sha256=hashlib.sha256(binary.read_bytes()).hexdigest())
assert result['failures']==0
save();print(json.dumps(r),flush=True)
