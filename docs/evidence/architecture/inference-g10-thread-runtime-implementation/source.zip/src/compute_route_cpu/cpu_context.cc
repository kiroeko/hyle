#include "hyle/compute/cpu.h"
#include "default_policy.h"

#include "../compute_provider_native/default_rules.h"
#include "../compute_provider_native/torch_cpu_program.h"
#include <array>

#include "hyle/compute/providers/native.h"
#if defined(HYLE_COMPUTE_GGML_CPU)
#include "hyle/compute/providers/ggml_cpu.h"
#endif
#if defined(HYLE_COMPUTE_ONEDNN)
#include "hyle/compute/providers/onednn.h"
#endif

namespace hyle::compute::cpu {

Status configure_runtime_threads(std::uint32_t intra_op_threads) noexcept {
  return native::internal::configure_thread_runtime(intra_op_threads);
}

Result<RuntimeThreadInfo> runtime_thread_info() noexcept {
  auto result = native::internal::thread_runtime_info();
  if (!result)
    return std::unexpected(std::move(result).error());
  RuntimeThreadBackend backend = RuntimeThreadBackend::kUnavailable;
  switch (result->backend) {
  case native::internal::ThreadRuntimeBackend::kUnavailable:
    break;
  case native::internal::ThreadRuntimeBackend::kOpenMP:
    backend = RuntimeThreadBackend::kOpenMP;
    break;
  case native::internal::ThreadRuntimeBackend::kNative:
    backend = RuntimeThreadBackend::kNative;
    break;
  }
  return RuntimeThreadInfo{
      .backend = backend,
      .configured_intra_op_threads = result->configured_intra_op_threads,
      .intra_op_limit = result->intra_op_limit,
      .inter_op_limit = result->inter_op_limit,
      .configuration_open = result->configuration_open,
      .usage_started = result->usage_started};
}

Result<Context> create_context(DefaultContextOptions options) noexcept {
  // A failed outer metadata allocation must not reopen the startup contract.
  native::internal::mark_thread_runtime_used();
  using internal::DefaultProvider;
  const bool single_thread = options.native_threads == 1 &&
                             options.executor.concurrency() <= 1;
  const auto configured = [single_thread](Provider provider, DefaultProvider family) {
    return internal::with_defaults(std::move(provider), family,
                                   internal::DefaultScope::kDirect, single_thread);
  };
  std::array providers{
#if defined(HYLE_COMPUTE_ONEDNN)
      ProviderBinding{configured(onednn::provider({.executor = options.executor}),
                                 DefaultProvider::kOneDnn), 900},
#endif
#if defined(HYLE_COMPUTE_GGML_CPU)
      ProviderBinding{
          configured(ggml_cpu::provider({.executor = options.executor,
                                        .native_threads = options.native_threads}),
                     DefaultProvider::kGgml),
          900},
#endif
      ProviderBinding{configured(aten_cpu::provider(), DefaultProvider::kAten), 900},
      ProviderBinding{native::internal::default_provider(
                          {.executor = options.executor},
                          native::internal::DefaultRuleScope::kDirect,
                          options.native_threads == 1),
                      1000}};
  auto count = providers.size();
  if (!providers[count - 2].provider.valid()) {
    providers[count - 2] = std::move(providers[count - 1]);
    --count;
  }
  return Context::create(device(),
                         {.metadata_allocator = options.metadata_allocator,
                          .providers = std::span(providers).first(count)});
}

} // namespace hyle::compute::cpu
