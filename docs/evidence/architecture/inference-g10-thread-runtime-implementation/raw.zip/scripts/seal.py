from pathlib import Path
import hashlib, json, os, subprocess, zipfile

root = Path('C:/public/project-hyle/hyle')
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
runs = [root / '.scratch/inference-gaps' / ('g10-windows-targeted-' + str(i)) for i in range(1, 5)]
attempts = [json.loads((p / 'result.json').read_text()) for p in runs]
last = attempts[-1]
assert last['state'] == 'FAIL' and last['stage'] == 'qualified-recipe-drift'
assert next(x for x in last['stages'] if x['stage'] == 'build')['exit'] == 0
assert next(x for x in last['stages'] if x['stage'] == 'test')['exit'] == 0
assert '100% tests passed out of 9' in (runs[-1] / 'test.log').read_text()
for item in last['inputs']:
    assert sha(root / item['path']) == item['sha256'], item['path']
out = root / 'evidence/architecture/inference-g10-thread-runtime-implementation'
out.mkdir(exist_ok=False)
with zipfile.ZipFile(out / 'raw.zip', 'x', zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
    for folder in runs:
        for p in sorted(folder.rglob('*')):
            if p.is_file(): archive.write(p, str(Path(folder.name) / p.relative_to(folder)))
    reuse = root / '.scratch/inference-gaps/g08-windows-static-native-reuse-g10-4'
    for p in sorted(reuse.rglob('*')):
        if p.is_file(): archive.write(p, str(Path(reuse.name) / p.relative_to(reuse)))
    for name in ['g10-code-review-1.json', 'g10-code-review-2.json']:
        archive.write(root / '.scratch/inference-gaps' / name, 'reviews/' + name)
    archive.write(root / '.scratch/validation/g10-implementation-plan.json', 'validation/plan.json')
    archive.write(Path(__file__), 'scripts/seal.py')
with zipfile.ZipFile(out / 'source.zip', 'x', zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
    for item in last['inputs']: archive.write(root / item['path'], item['path'])
receipt = dict(schema='hyle.inference-g10-runtime-implementation-checkpoint/v1',
    verdict='WINDOWS_BUILD_AND_NINE_ISOLATED_RUNTIME_SCENARIOS_PASS_EXTRA_QUALIFIED_RECIPE_PRECONDITION_FAILED',
    owner_state='AUDITED_NOT_ACCEPTED', base_commit=last['head'], host=os.environ.get('COMPUTERNAME'),
    source_inputs=last['inputs'], source_inputs_rechecked=True,
    attempts=[dict(path=p.name, state=r['state'], stage=r['stage'], elapsed_seconds=r['elapsed_seconds']) for p, r in zip(runs, attempts)],
    accumulated_seconds=sum(r['elapsed_seconds'] for r in attempts),
    build_and_runtime=last,
    pending='Actual applicable recipe coverage disposition; CPU-only/Graph/executor direct consumers; nine source/static/shared deliveries on Windows/WSL/Air; feature OFF; new-state sanitizer risks and final review. No G09 performance waiver or engine token/s claim.',
    scope='Windows MSVC static CPU+CUDA shipping-layout test configuration only, not an installed SDK verdict. Original CUDA objects reused only after byte/command/dependency proof; zero CUDA kernel builds. All original setup refusals, test-mode dependency rebuild cost and the extra failed eligibility precondition retained.')
for name in ['raw.zip', 'source.zip']:
    receipt[name] = dict(sha256=sha(out / name), bytes=(out / name).stat().st_size)
(out / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n', encoding='utf8')
print(json.dumps(dict(verdict=receipt['verdict'], receipt=str(out / 'receipt.json'), seconds=receipt['accumulated_seconds'])))
