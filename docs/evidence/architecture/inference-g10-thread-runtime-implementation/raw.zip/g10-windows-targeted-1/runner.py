from pathlib import Path
import ctypes, hashlib, json, os, subprocess, sys, time

root = Path('C:/public/project-hyle/hyle')
build = Path('C:/h7/w-cuda/selected-graph/static-sdk-build')
attempt = sys.argv[1]
assert attempt.isdigit()
out = root / '.scratch/inference-gaps' / ('g10-windows-targeted-' + attempt)
out.mkdir(exist_ok=False)
started = time.monotonic()
receipt = {'state': 'SETUP', 'pid': os.getpid(), 'build': str(build), 'stages': [],
           'scope': 'G10 CPU runtime source, real vendor fixture and isolated public consumer scenarios; no GPU build or performance claim',
           'jobs': 4, 'logical_cpu_limit': 4, 'priority': 'BELOW_NORMAL'}
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()

def save():
    receipt['elapsed_seconds'] = time.monotonic() - started
    (out / 'result.json').write_text(json.dumps(receipt, indent=2) + '\n', encoding='utf8')

try:
    setup = subprocess.check_output(['cmd', '/d', '/c', str(root / '.scratch/inference-gaps/g01/cpu-ragged-env.cmd')], encoding='utf8', errors='replace')
    env = {k.upper(): v for k, v in os.environ.items()}
    env.update((k.upper(), v) for k, v in (x.split('=', 1) for x in setup.splitlines() if '=' in x and not x.startswith('=')))
    env.update(VSLANG='1033', OMP_NUM_THREADS='1', MKL_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1')
    kernel = ctypes.windll.kernel32
    kernel.GetCurrentProcess.restype = ctypes.c_void_p
    handle = kernel.GetCurrentProcess()
    kernel.GetProcessAffinityMask.argtypes = [ctypes.c_void_p, ctypes.POINTER(ctypes.c_size_t), ctypes.POINTER(ctypes.c_size_t)]
    kernel.SetProcessAffinityMask.argtypes = [ctypes.c_void_p, ctypes.c_size_t]
    available, system = ctypes.c_size_t(), ctypes.c_size_t()
    assert kernel.GetProcessAffinityMask(handle, ctypes.byref(available), ctypes.byref(system))
    mask = sum([1 << i for i in range(64) if available.value & (1 << i)][:4])
    assert mask.bit_count() <= 4 and kernel.SetProcessAffinityMask(handle, mask)
    kernel.SetErrorMode(0x0001 | 0x0002 | 0x8000)
    receipt.update(affinity_mask=hex(mask), head=subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip(),
                   compiler=env.get('VCTOOLSVERSION'))
    registry = json.loads((root / 'docs/implementation/module-status.json').read_text())
    assert all(x['state'] == 'AUDITED' for x in registry['modules'] if x['module'] in ['compute_route_cpu', 'compute_provider_native'])
    paths = subprocess.check_output(['git', 'diff', '--name-only', '--', 'include', 'src', 'tests'], cwd=root, text=True).splitlines()
    paths += ['tests/compute_route_cpu/thread_runtime_consumer.cc']
    inputs = [{'path': x, 'sha256': sha(root / x)} for x in sorted(set(paths))]
    receipt['inputs'] = inputs
    (out / 'runner.py').write_bytes(Path(__file__).read_bytes())

    def run(stage, args):
        receipt.update(state='RUNNING', stage=stage)
        save()
        print(stage, flush=True)
        stamp = time.monotonic()
        with (out / (stage + '.log')).open('wb') as log:
            process = subprocess.Popen([str(x) for x in args], cwd=root, env=env, stdout=log, stderr=subprocess.STDOUT,
                                       creationflags=subprocess.CREATE_NO_WINDOW | subprocess.BELOW_NORMAL_PRIORITY_CLASS)
            receipt['child_pid'] = process.pid
            save()
            code = process.wait()
        receipt['stages'].append({'stage': stage, 'argv': [str(x) for x in args], 'exit': code, 'seconds': time.monotonic() - stamp})
        save()
        if code:
            print((out / (stage + '.log')).read_text(encoding='utf8', errors='replace')[-10000:], flush=True)
            raise RuntimeError(stage + ' exited ' + str(code))

    run('configure', ['cmake', '-S', root, '-B', build, '-DHYLE_BUILD_TESTS=ON', '-DHYLE_BUILD_BENCH=OFF'])
    targets = ['hyle_compute_route_cpu_thread_runtime_test', 'hyle_compute_route_cpu_thread_runtime_vendor_test']
    run('dry-run', ['ninja', '-C', build, '-n', *targets])
    dry = (out / 'dry-run.log').read_text(encoding='utf8', errors='replace')
    assert 'Building CUDA object' not in dry and 'vulkan-shaders' not in dry and 'Re-running CMake' not in dry, dry
    assert len(dry.splitlines()) < 150, dry
    receipt['dry_run_edges'] = len(dry.splitlines())
    run('build', ['ninja', '-C', build, '-j', '4', *targets])
    run('test', ['ctest', '--test-dir', build, '-R', '^compute_route_cpu_thread_runtime_', '--output-on-failure', '-j', '1'])
    for item in inputs:
        assert sha(root / item['path']) == item['sha256'], item['path']
    receipt['state'] = 'PASS_TARGETED_CPU_BUILD_AND_ISOLATED_RUNTIME_CONSUMERS'
    save()
    print(receipt['state'], receipt['elapsed_seconds'], flush=True)
except BaseException as error:
    receipt.update(state='FAIL', error=repr(error))
    save()
    raise
