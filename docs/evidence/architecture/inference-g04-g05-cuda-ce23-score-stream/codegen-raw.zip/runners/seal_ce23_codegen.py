from pathlib import Path
import hashlib,json,re,zipfile

root=Path.cwd();base=root/'.scratch/inference-gaps/g04-g05';run=base/'ce23-fixed-codegen-1'
r=json.loads((run/'result.json').read_text());assert r['state']=='TERMINAL_PASS' and len(r['kernels'])==3
assert r['product_candidate']=='8c3491ee17f7bb02204b7f80c34e2cc672e7a288'
dest=root/'evidence/architecture/inference-g04-g05-cuda-ce23-score-stream'
assert (dest/'source-audit.json').exists() and not (dest/'codegen-receipt.json').exists()
def resource(s):return {key:int(value) for key,value in re.findall(r'(REG|STACK|SHARED|LOCAL):(\d+)',s)}
comparisons=[]
for row in r['kernels']:
    comparisons.append(dict(mangled=row['mangled'],qualified9=resource(row['before_resource']),
                            ce22=resource(row['ce22_resource']),ce23=resource(row['after_resource']),
                            qualified9_local=row['before_sass'],ce22_local=row['ce22_sass'],ce23_local=row['after_sass']))
with zipfile.ZipFile(dest/'codegen-raw.zip','w',zipfile.ZIP_DEFLATED) as z:
    for p in sorted(run.rglob('*')):
        if p.is_file():z.write(p,p.relative_to(run).as_posix())
    z.write(base/'seal_ce23_codegen.py','runners/seal_ce23_codegen.py')
receipt=dict(kind='G04_G05_CE23_SAME_THREE_KERNEL_CODEGEN',verdict='EXTRACTION_PASS_STATIC_RESOURCES_ONLY',
 product_candidate=r['product_candidate'],binary_sha256=r['binary_sha256'],header_sha256=r['header_sha256'],
 comparisons=comparisons,kernels=r['kernels'],stages=r['stages'],measured_seconds=sum(s['elapsed_seconds'] for s in r['stages']),
 limits=r['limits']+['Extraction success and source storage reduction do not by themselves establish throughput improvement or full G04/G05 closure.',
                    'All earlier qualified failures, CE22 unmet resource hypothesis and measured costs retained.'],
 raw_zip_sha256=hashlib.sha256((dest/'codegen-raw.zip').read_bytes()).hexdigest())
(dest/'codegen-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n',newline='\n')
print(json.dumps(comparisons,indent=2))
