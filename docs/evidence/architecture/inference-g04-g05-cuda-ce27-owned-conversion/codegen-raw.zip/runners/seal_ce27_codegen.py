from pathlib import Path
import hashlib,json,zipfile

root=Path.cwd();base=root/'.scratch/inference-gaps/g04-g05';run=base/'ce27-fixed-codegen-1'
r=json.loads((run/'result.json').read_text());assert r['state']=='TERMINAL_PASS'
assert r['product_candidate']=='d41431f82a373ae400fb10e97418931031fa48e8'
assert [row['projected_mma_kv'] for row in r['kernels']]==[1,1,4]
for row in r['kernels']+[r['merge']]:
    assert 'STACK:0 ' in row['after_resource'] and row['after_sass']['LDL']==row['after_sass']['STL']==0
dest=root/'evidence/architecture/inference-g04-g05-cuda-ce27-owned-conversion'
assert (dest/'source-audit.json').exists() and not (dest/'codegen-receipt.json').exists()
with zipfile.ZipFile(dest/'codegen-raw.zip','w',zipfile.ZIP_DEFLATED) as z:
    for folder,label in [(run,'current'),(base/'ce26-fixed-codegen-1','baseline')]:
        for p in sorted(folder.rglob('*')):
            if p.is_file():z.write(p,label+'/'+p.relative_to(folder).as_posix())
    z.write(base/'seal_ce27_codegen.py','runners/seal_ce27_codegen.py')
receipt=dict(kind='G04_G05_CE27_PRODUCER_OWNED_FP8_CONVERSION_STATIC_CODEGEN',verdict='EXTRACTION_PASS_STATIC_RESOURCES_ONLY',
    product_candidate=r['product_candidate'],binary_sha256=r['binary_sha256'],header_sha256=r['header_sha256'],cascade_sha256=r['cascade_sha256'],
    kernels=r['kernels'],merge=r['merge'],stages=r['stages'],measured_seconds=sum(s['elapsed_seconds'] for s in r['stages']),
    limits=['Actual same1/1/4 attention and scaled F32 merge from current source-test shared artifact; no local spills in these four kernels.',
            'Producer ownership and barrier coalescing require actual zero-hazard device checks; static opcode counts alone do not prove a speedup.',
            'New SDK, numeric/runtime, host facets and original P1 remain separate gates; all earlier failures/costs retained.'],
    raw_zip_sha256=hashlib.sha256((dest/'codegen-raw.zip').read_bytes()).hexdigest())
(dest/'codegen-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n',newline='\n')
print(json.dumps(dict(attention=[x['after_resource'] for x in r['kernels']],merge=r['merge']),indent=2))
