"""One non-ranking owned WinVk/NVTX trace; no qualification or retry."""
from pathlib import Path
import ctypes
import hashlib
import json
import os
import re
import secrets
import subprocess
import sys
import time

ROOT=Path('C:/public/project-hyle/hyle')
OUT=ROOT/'.scratch/inference-gaps/g09-completion-observation-25'
BUILD=Path('C:/h7/g09-completion-observation-25')
RUN=OUT/'run-admin-retry-1'
NSYS=Path('C:/Program Files/NVIDIA Corporation/Nsight Systems 2026.1.3/target-windows-x64/nsys.exe')
TOOLS=Path('C:/h7/g09-p1-peer-9e2/scripts')
sys.path.insert(0,str(TOOLS))
from hyle_perf import evaluate_machine_profile, expected_child_policy, get_machine_profile, load_registry, probe_machine
from hyle_perf.runner import _apply_sampling_policy, _child_environment, _creation_flags, _probe_child_policy
load=lambda p:json.loads(p.read_text(encoding='utf8'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()

assert not RUN.exists(), 'One fixed process; preserve attempts'
assert bool(ctypes.windll.shell32.IsUserAnAdmin()), 'Authorized retry requires an actually elevated token'
authorization=load(OUT/'retry-authorization.json')
assert authorization['decision']=='ALLOW_ONE_FROZEN_NONRANKING_COMPLETION_OBSERVATION'
for row in authorization['files']:
    assert sha(Path(row['path']))==row['sha256'],('Frozen observation input changed',row['path'])
build=load(OUT/'build-result.json')
assert build['state']=='BUILT_NOT_RUN' and build['compile_units']==4
for row in build['artifacts']+build['runtime']:
    assert sha(Path(row['path']))==row['sha256']
host=probe_machine(paths=[('build',BUILD)])
profile=get_machine_profile(load_registry(),'W1-WIN')
gate=evaluate_machine_profile(profile,host,role='engineering',sampling_topology='native-runtime-pair')
assert gate['gate']=='PASS',gate
policy=expected_child_policy(profile,sampling_topology='native-runtime-pair',probe=host)
controlled=['HYLE_BENCH_AA_ROUTE','HYLE_BENCH_VERIFY_ONLY','HYLE_BENCH_RIVAL_FIRST','HYLE_BENCH_PEER_ALLOCATION_FIRST','HYLE_PERF_APPLE_QOS']
nonce=secrets.token_hex(16)
env=_child_environment(controlled,{'HYLE_BENCH_AA_ROUTE':'candidate','HYLE_BENCH_RIVAL_FIRST':'0',
    'HYLE_BENCH_PEER_ALLOCATION_FIRST':'0','HYLE_PERF_RUN_NONCE':nonce},profile,policy)
env['DISABLE_VULKAN_OBS_CAPTURE']='1'
assert not any(k.upper() in ['CUDA_INJECTION64_PATH','NVTX_INJECTION64_PATH'] for k in env), 'Pre-existing injection is not part of this fixed trace'
RUN.mkdir()
started=time.monotonic()
result=dict(state='RUNNING',stages=[],qualification='DIAGNOSTIC_ONLY',valid_formal_ab=0,
    source_manifest_sha256=sha(OUT/'source-manifest.json'),authorization_sha256=sha(OUT/'retry-authorization.json'),
    physical_machine=gate['physical_host_identity'],policy=policy,math_application_processes=1,
    source_extra_os_threads=0,profiler_threads='UNKNOWN_NONPRODUCT',old_failures_preserved=True)

def save():
    result['elapsed_seconds']=time.monotonic()-started
    (RUN/'result.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8')

def run(stage,command,flags,child_env):
    child=None
    stamp=time.monotonic()
    try:
        with (RUN/(stage+'.log')).open('wb') as log:
            child=subprocess.Popen([str(x) for x in command],env=child_env,cwd=BUILD/'bin',stdout=log,stderr=subprocess.STDOUT,creationflags=flags)
            result.update(stage=stage,child_pid=child.pid);save()
            print(stage,'RUNNING',child.pid,flush=True)
            while True:
                try:code=child.wait(timeout=1800);break
                except subprocess.TimeoutExpired:
                    result.setdefault('extensions',[]).append(dict(stage=stage,pid=child.pid,seconds=1800));save()
        result.pop('child_pid',None)
        result['stages'].append(dict(stage=stage,command=[str(x) for x in command],exit_code=code,elapsed_seconds=time.monotonic()-stamp))
        save()
        if code:raise RuntimeError((RUN/(stage+'.log')).read_text(encoding='utf8',errors='replace')[-7000:])
    except BaseException:
        if child is not None and child.poll() is None:
            cleanup=subprocess.run(['taskkill','/PID',str(child.pid),'/T','/F'],capture_output=True,text=True,encoding='utf8',errors='replace',creationflags=subprocess.CREATE_NO_WINDOW)
            result['owned_cleanup']=dict(pid=child.pid,exit_code=cleanup.returncode,stdout=cleanup.stdout,stderr=cleanup.stderr)
            if child.poll() is None:child.kill()
            child.wait()
        raise

def stop_owned_application_on_failure():
    # Nsight can finish/error independently of its target. Only the nonce-bound
    # PID emitted by this unique diagnostic executable is eligible for cleanup.
    path=RUN/'profile.log'
    if not path.is_file():return
    text=path.read_text(encoding='utf8',errors='replace')
    found=re.findall(r'^# G09_OBSERVATION_ACTUAL_POLICY pid=(\d+) mask=0x14 priority=32768 nonce='+nonce+r'$',text,re.M)
    if not found:return
    assert len(found)==1
    pid=int(found[0]);kernel=ctypes.windll.kernel32
    kernel.OpenProcess.argtypes=[ctypes.c_ulong,ctypes.c_int,ctypes.c_ulong]
    kernel.OpenProcess.restype=ctypes.c_void_p
    kernel.QueryFullProcessImageNameW.argtypes=[ctypes.c_void_p,ctypes.c_ulong,ctypes.c_wchar_p,ctypes.POINTER(ctypes.c_ulong)]
    kernel.GetExitCodeProcess.argtypes=[ctypes.c_void_p,ctypes.POINTER(ctypes.c_ulong)]
    kernel.WaitForSingleObject.argtypes=[ctypes.c_void_p,ctypes.c_ulong]
    kernel.TerminateProcess.argtypes=[ctypes.c_void_p,ctypes.c_uint]
    kernel.CloseHandle.argtypes=[ctypes.c_void_p]
    handle=kernel.OpenProcess(0x1|0x1000|0x100000,False,pid)
    if not handle:
        result['target_cleanup']=dict(pid=pid,state='NO_LONGER_OPENABLE');return
    try:
        code=ctypes.c_ulong()
        assert kernel.GetExitCodeProcess(handle,ctypes.byref(code))
        if code.value!=259:
            result['target_cleanup']=dict(pid=pid,state='ALREADY_EXITED',exit_code=code.value);return
        size=ctypes.c_ulong(32768);image=ctypes.create_unicode_buffer(size.value)
        assert kernel.QueryFullProcessImageNameW(handle,0,image,ctypes.byref(size))
        assert Path(image.value).resolve()==(BUILD/'bin/g09_observed_driver.exe').resolve(), 'PID no longer names owned diagnostic image'
        cleanup=subprocess.run(['taskkill','/PID',str(pid),'/T','/F'],capture_output=True,text=True,
            encoding='utf8',errors='replace',creationflags=subprocess.CREATE_NO_WINDOW)
        result['target_cleanup']=dict(pid=pid,state='OWNED_TREE_TERMINATION_REQUESTED',exit_code=cleanup.returncode,stdout=cleanup.stdout,stderr=cleanup.stderr)
        if kernel.WaitForSingleObject(handle,30000)!=0:
            assert kernel.TerminateProcess(handle,1), 'Cannot stop owned diagnostic'
            assert kernel.WaitForSingleObject(handle,30000)==0, 'Owned diagnostic did not exit'
        assert kernel.GetExitCodeProcess(handle,ctypes.byref(code)) and code.value!=259
        result['target_cleanup']['actual_exit_code']=code.value
    finally:
        kernel.CloseHandle(handle)

try:
    with _apply_sampling_policy(policy) as applied:
        result['applied_policy']=applied
        result['child_canary']=_probe_child_policy(policy,_creation_flags(policy))
        run('profile',[NSYS,'profile','--trace=vulkan,nvtx','--sample=none','--cpuctxsw=none','--backtrace=none',
            '--vulkan-gpu-workload=batch','--wait=primary','--stop-on-exit=true','--kill=true','--show-output=true',
            '--output',RUN/'trace',BUILD/'bin/g09_observed_driver.exe'],_creation_flags(policy),env)
    text=(RUN/'profile.log').read_text(encoding='utf8',errors='replace')
    assert '# G09_OBSERVATION_PROCESS_EXIT code=0' in text
    assert len(re.findall(r'^# G09_ORACLE .* before=PASS ',text,re.M))==4
    assert len(re.findall(r'^# G09_ORACLE .* after=PASS ',text,re.M))==4
    assert len(re.findall(r'^# G09_DEFERRED_DESTROY .* status=0$',text,re.M))==8
    summaries=re.findall(r'^# G09_OBSERVATION tag=(\S+) count=(\d+) capacity=65536 overflow=0 clock=QPC-ns$',text,re.M)
    assert len(summaries)==8 and all(int(x[1])>0 for x in summaries)
    phases={}
    for phase,path in re.findall(r'^# G09_MODULE phase=(\S+) path=(.+)$',text,re.M):phases.setdefault(phase,[]).append(path)
    assert len(phases)==4
    assert not any('obs-studio-hook' in x.lower() or 'graphics-hook64.dll' in x.lower() for v in phases.values() for x in v)
    assert (RUN/'trace.nsys-rep').is_file()
    # Offline export only after native execution has ended; never another app run.
    run('export',[NSYS,'export','--type=sqlite','--output',RUN/'trace.sqlite',RUN/'trace.nsys-rep'],
        subprocess.CREATE_NO_WINDOW|subprocess.BELOW_NORMAL_PRIORITY_CLASS,dict(os.environ))
    assert (RUN/'trace.sqlite').is_file()
    for row in authorization['files']:assert sha(Path(row['path']))==row['sha256']
    result.update(state='CAPTURED_NOT_INTERPRETED',actual_complete_app_exit='PASS',complete_oracles_retirement='PASS',
        original_qualification='UNRESOLVED_UNCHANGED',source_record_count=sum(int(x[1]) for x in summaries),
        outputs=[dict(path=str(p),bytes=p.stat().st_size,sha256=sha(p)) for p in sorted(RUN.iterdir()) if p.is_file() and p.name!='result.json'])
    save();print('CAPTURED_NOT_INTERPRETED',result['elapsed_seconds'],flush=True)
except BaseException as error:
    result.update(state='DIAGNOSTIC_FAIL',error=repr(error))
    try:stop_owned_application_on_failure()
    except BaseException as cleanup_error:result['target_cleanup_error']=repr(cleanup_error)
    save();raise
