"""Freeze only the user-authorized elevated retry; no application execution."""
from pathlib import Path
from datetime import datetime,timezone
import ctypes,hashlib,json,shutil,zipfile
ROOT=Path('C:/public/project-hyle/hyle')
OUT=ROOT/'.scratch/inference-gaps/g09-completion-observation-25'
E=ROOT/'evidence/architecture/inference-g09-completion-observation'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
load=lambda p:json.loads(p.read_text(encoding='utf8'))
assert ctypes.windll.shell32.IsUserAnAdmin()
assert not (OUT/'run-admin-retry-1').exists() and not (OUT/'retry-authorization.json').exists()
review=E/'25.json'
assert sha(review)=='86f1ce9691204a2ca9efbcdaa5d06af497cc66b0b96e0953477c3f37faf37f6e'
original=load(OUT/'observation-authorization.json')
old=ROOT/'.scratch/inference-gaps/g09_run_completion_observation.py'
new=ROOT/'.scratch/inference-gaps/g09_run_completion_observation_admin_retry.py'
text=old.read_text(encoding='utf8').replace("RUN=OUT/'run'","RUN=OUT/'run-admin-retry-1'").replace(
    "authorization=load(OUT/'observation-authorization.json')",
    "assert bool(ctypes.windll.shell32.IsUserAnAdmin()), 'Authorized retry requires an actually elevated token'\nauthorization=load(OUT/'retry-authorization.json')").replace(
    "sha(OUT/'observation-authorization.json')","sha(OUT/'retry-authorization.json')")
assert text==new.read_text(encoding='utf8')
proof=OUT/'admin-retry-delta-proof.json'
assert not proof.exists()
proof.write_text(json.dumps(dict(gate='PASS_STATIC_ONLY',
 original_launcher_sha256=sha(old),retry_launcher_sha256=sha(new),
 exact_delta=['RUN path','authorization path in load and result hash','actual IsUserAnAdmin assertion'],
 original_source_artifact_review_sha256=sha(review),
 authorization='Explicit user-requested retry after actual elevated-token change; original reviewed capture command/cleanup and all source/artifacts unchanged.'),indent=2)+'\n',encoding='utf8')
card=ROOT/'docs/implementation/tasks/tooling/inference-g09-native-workload-aa.md'
files={}
def add(p,expected=None):
 p=Path(p).resolve(); digest=sha(p)
 assert expected is None or digest==expected,(p,expected,digest)
 files[str(p)]=dict(path=str(p),sha256=digest,bytes=p.stat().st_size)
for row in original['files']:
 p=Path(row['path'])
 if p.resolve()==card.resolve():continue
 add(p,row['sha256'])
added=[new,Path(__file__).resolve(),card,review,proof,OUT/'admin-retry-host.json',
       OUT/'run/result.json',OUT/'run/profile.log',OUT/'observation-authorization.json',E/'raw.zip']
assert not (E/'retry-source.zip').exists()
with zipfile.ZipFile(E/'retry-source.zip','x',compression=zipfile.ZIP_DEFLATED) as z:
 for p in added:
  if p.is_relative_to(ROOT):z.write(p,p.relative_to(ROOT).as_posix())
for p in added+[E/'retry-source.zip']:add(p)
authorization=dict(schema='hyle.g09.one-shot-completion-observation-elevated-retry/v1',
 created_utc=datetime.now(timezone.utc).isoformat(),
 decision='ALLOW_ONE_FROZEN_NONRANKING_COMPLETION_OBSERVATION',
 user_authorization='你已经在管理员终端了，重试',
 external_state='Actually elevated current token; IsUserAnAdmin=true and High Mandatory Level verified',
 supersedes='Previous no-retry stop only for this single user-authorized retry; original failure/source/artifacts retained',
 fixed_build='C:/h7/g09-completion-observation-25',fixed_run=str(OUT/'run-admin-retry-1'),
 launcher=str(new),original_authorization_sha256=sha(OUT/'observation-authorization.json'),
 original_restrictions=original['restrictions'],native_rebuilds=0,
 scope='Same artifact/source/workload/NSYS options; only RUN/auth names and actual-admin assertion differ. One retry, then interpret/stop.',
 files=[files[k] for k in sorted(files)])
p=OUT/'retry-authorization.json'
p.write_text(json.dumps(authorization,indent=2)+'\n',encoding='utf8')
shutil.copyfile(p,E/'retry-authorization.json')
print(json.dumps(dict(state='ELEVATED_RETRY_SEALED_NOT_RUN',files=len(files),sha256=sha(p)),indent=2))
