"""Offline PE/map/response-file binding, with no application execution."""
from pathlib import Path
import hashlib
import json
import re
import subprocess

ROOT=Path('C:/public/project-hyle/hyle')
OUT=ROOT/'.scratch/inference-gaps/g09-completion-observation-25'
BUILD=Path('C:/h7/g09-completion-observation-25')
LOGS=OUT/'artifact-logs'
assert not LOGS.exists()
LOGS.mkdir()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
cache=dict(x.split('=',1) for x in (BUILD/'CMakeCache.txt').read_text(encoding='utf8').splitlines() if '=' in x and not x.startswith(('#','//')))
compiler=Path(cache['CMAKE_CXX_COMPILER:FILEPATH'])
dumpbin=compiler.with_name('dumpbin.exe')
rows=[]
for name in ['g09_observed_1.dll','g09_observed_2.dll','g09_observed_driver.exe']:
    path=BUILD/'bin'/name
    row=dict(path=str(path),sha256=sha(path),bytes=path.stat().st_size)
    for option in ['exports','imports','headers','dependents']:
        log=LOGS/(name+'-'+option+'.log')
        with log.open('wb') as output:
            subprocess.run([str(dumpbin),'/nologo','/'+option,str(path)],stdout=output,stderr=subprocess.STDOUT,
                check=True,creationflags=subprocess.CREATE_NO_WINDOW|subprocess.BELOW_NORMAL_PRIORITY_CLASS)
    text=(LOGS/(name+'-exports.log')).read_text(encoding='utf8',errors='replace')
    row['exports']=re.findall(r'^\s+\d+\s+[0-9A-F]+\s+[0-9A-F]+\s+(\S+)',text,re.M)
    assert not any('@hyle@' in x for x in row['exports'])
    if path.suffix=='.dll':
        assert 'hyle_g09_facade_v1' in row['exports']
        mapping=(BUILD/(path.stem+'.map')).read_text(encoding='utf8',errors='replace')
        old=[x for x in mapping.splitlines() if re.search(r'hyle_graph_route_cpu_vulkan[^\s]*:invocation\.cc\.obj',x,re.I)]
        assert not old
        row['observer_bindings']=[x for x in mapping.splitlines() if 'g09_record' in x or ('create_invocation' in x and 'cpu_vulkan' in x)]
        assert row['observer_bindings']
    rows.append(row)
libraries={}
responses=[]
for path in sorted(BUILD.rglob('*.rsp')):
    text=path.read_text(encoding='utf8',errors='replace')
    responses.append(dict(path=str(path),sha256=sha(path)))
    for quoted,plain in re.findall(r'"([^"]+\.lib)"|([^\s"]+\.lib)',text,re.I):
        library=Path(quoted or plain)
        if library.is_absolute() and library.is_file():libraries[str(library.resolve())]=library
assert libraries, 'Link response archives were not retained'
headers=Path('C:/Program Files/NVIDIA GPU Computing Toolkit/CUDA/v13.3/include/nvtx3')
nvtx=[dict(path=str(p),sha256=sha(p),bytes=p.stat().st_size) for p in sorted(headers.rglob('*')) if p.is_file()]
result=dict(state='OFFLINE_ARTIFACTS_BOUND_NOT_RUN',pe=rows,response_files=responses,
    linked_libraries=[dict(path=name,sha256=sha(p),bytes=p.stat().st_size) for name,p in sorted(libraries.items())],
    nvtx_headers=nvtx,nsys=dict(path='C:/Program Files/NVIDIA Corporation/Nsight Systems 2026.1.3/target-windows-x64/nsys.exe',
        version='2026.1.3.425-261338342291v0',sha256=sha(Path('C:/Program Files/NVIDIA Corporation/Nsight Systems 2026.1.3/target-windows-x64/nsys.exe'))))
(OUT/'artifact-binding.json').write_bytes((json.dumps(result,indent=2)+'\n').encode('utf8'))
print(json.dumps(dict(state=result['state'],images=len(rows),linked_libraries=len(libraries),nvtx_headers=len(nvtx),export_counts=[len(x['exports']) for x in rows]),indent=2))
