"""Finish the disposable driver: original body plus actual Windows policy."""
from pathlib import Path
import hashlib
import json

ROOT=Path('C:/public/project-hyle/hyle')
OUT=ROOT/'.scratch/inference-gaps/g09-completion-observation-25'
SOURCE=OUT/'source'
FIXED=ROOT/'.scratch/inference-gaps/g09-p1-instrument-adapter'
assert not (SOURCE/'wrapper.cc').exists()
wrapper=(FIXED/'wrapper.cc').read_text(encoding='utf8')
old='int main(int argc, char **argv) {\n'
assert wrapper.count(old)==1
wrapper=wrapper.replace(old,old+'''  ensure(::SetPriorityClass(::GetCurrentProcess(), ABOVE_NORMAL_PRIORITY_CLASS) != 0, "diagnostic priority setup failed");
  ensure(::SetProcessAffinityMask(::GetCurrentProcess(), DWORD_PTR{0x14}) != 0, "diagnostic process affinity failed");
  DWORD_PTR current_mask=0,system_mask=0;
  ensure(::GetProcessAffinityMask(::GetCurrentProcess(),&current_mask,&system_mask) != 0 && current_mask==0x14, "diagnostic actual mask differs");
  ensure(::GetPriorityClass(::GetCurrentProcess())==ABOVE_NORMAL_PRIORITY_CLASS,"diagnostic actual priority differs");
  std::fprintf(stderr,"# G09_OBSERVATION_ACTUAL_POLICY mask=0x%llx priority=%lu\\n",static_cast<unsigned long long>(current_mask),::GetPriorityClass(::GetCurrentProcess()));
''')
(SOURCE/'wrapper.cc').write_bytes(wrapper.encode('utf8'))
(SOURCE/'driver.cc').write_bytes((FIXED/'driver.cc').read_bytes())
cmake=(SOURCE/'CMakeLists.txt').read_text(encoding='utf8')
cmake+='''
add_library(g09_original_nanobench STATIC IMPORTED)
set_target_properties(g09_original_nanobench PROPERTIES IMPORTED_LOCATION "C:/h7/g09-p1-instrument/vulkan/qualified-build-obs-free-1/g09_nanobench.lib")
add_executable(g09_observed_driver wrapper.cc)
target_include_directories(g09_observed_driver PRIVATE
  "C:/public/project-hyle/hyle/.scratch/inference-gaps/g09-p1-instrument-adapter/instrument/third_party/nanobench"
  "C:/public/project-hyle/hyle/.scratch/inference-gaps/g09-p1-instrument-adapter/instrument/bench/common")
target_compile_definitions(g09_observed_driver PRIVATE "G09_ROUTE_NAME=\\\"vulkan\\\""
  "G09_CANDIDATE_1=\\\"C:/h7/g09-completion-observation-25/bin/g09_observed_1.dll\\\""
  "G09_CANDIDATE_2=\\\"C:/h7/g09-completion-observation-25/bin/g09_observed_2.dll\\\""
  "G09_BASELINE_1=\\\"C:/h7/g09-p1/vulkan-baseline/bin/g09_vulkan_baseline_1.dll\\\""
  "G09_BASELINE_2=\\\"C:/h7/g09-p1/vulkan-baseline/bin/g09_vulkan_baseline_2.dll\\\"")
target_link_libraries(g09_observed_driver PRIVATE g09_original_nanobench)
'''
(SOURCE/'CMakeLists.txt').write_bytes(cmake.encode('utf8'))
manifest=json.loads((OUT/'source-manifest.json').read_text(encoding='utf8'))
manifest['sources']=[dict(path=p.name,sha256=hashlib.sha256(p.read_bytes()).hexdigest(),bytes=p.stat().st_size) for p in sorted(SOURCE.iterdir()) if p.is_file()]
manifest['intended_compile_units']=4
manifest['executable']='C:/h7/g09-completion-observation-25/bin/g09_observed_driver.exe'
manifest['driver_delta']='Unchanged driver.cc and nanobench object; wrapper sets/checks actual Windows AboveNormal and0x14 before original affinity/caller setup. No work/timing/statistics change.'
(OUT/'source-manifest.json').write_bytes((json.dumps(manifest,indent=2)+'\n').encode('utf8'))
print('Finished4TU disposable source; no build/native run')
