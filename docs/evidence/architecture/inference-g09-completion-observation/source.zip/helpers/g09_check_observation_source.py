"""Prove the disposable delta restores exactly to the frozen consumer/source."""
from pathlib import Path
import hashlib
import json

ROOT=Path('C:/public/project-hyle/hyle')
OUT=ROOT/'.scratch/inference-gaps/g09-completion-observation-25'
SOURCE=OUT/'source'
FIXED=ROOT/'.scratch/inference-gaps/g09-p1-instrument-adapter'
read=lambda p:p.read_text(encoding='utf8')
text=read(SOURCE/'invocation.cc')
start=text.index('// Disposable observation only;')
end=text.index('void release_invocation(',start)
text=text[:start]+text[end:]
text=text.replace('#include <cstdint>\nextern "C" void g09_record(unsigned, const void *, const void *, std::uint64_t) noexcept;\n\n','')
text=text.replace('g09_progress_wait(run);','run.progress.wait_for(std::chrono::milliseconds(1));')
text=text.replace('g09_finished_wait(run);','run.finished.wait_for(std::chrono::milliseconds(1));')
text=text.replace('g09_observe(run, completion)','completion.poll()')
text=text.replace('g09_observe(run, slot.pending.completion())','slot.pending.completion().poll()')
text=text.replace('g09_observe(run, value.pending_transfer)','value.pending_transfer.poll()')
text=text.replace('''    if (pending != 0) {
      g09_record(30, &run, nullptr, pending);
      run.pipeline_ready.wait_for(lock, std::chrono::milliseconds(1), changed);
      g09_record(31, &run, nullptr, pending);
    }''','    if (pending != 0) run.pipeline_ready.wait_for(lock, std::chrono::milliseconds(1), changed);')
# The inserted helper block contributed one extra empty separator only.
original=read(ROOT/'src/graph_route_cpu_vulkan/invocation.cc')
if text!=original:
    text=text.replace('using detail::InvocationState;\n\n\n','using detail::InvocationState;\n\n',1)
assert text==original, 'Non-observation invocation delta'
text=read(SOURCE/'facade.cc').replace('#include "recorder.h"\n','')
text=text.replace('''    g09_observation::marker(1,state,full_oracle);
    const auto status = static_cast<State *>(state)->replay(full_oracle != 0);
    g09_observation::marker(3,state,status.ok() ? 0 : 1);
    return status_result(status, error, capacity);''',
    '    return status_result(static_cast<State *>(state)->replay(full_oracle != 0), error, capacity);')
text=text.replace('''  const auto status = state ? state->close() : Status::Ok();
  const auto complete_records = g09_observation::flush();
  if (!complete_records) return status_result(Status::Internal("diagnostic record capacity exceeded"),error,capacity);
  return status_result(status,error,capacity);''',
    '  return state ? status_result(state->close(), error, capacity) : 0;')
assert text==read(FIXED/'retained/facade.cc'), 'Non-observation facade delta'
assert (SOURCE/'driver.cc').read_bytes()==(FIXED/'driver.cc').read_bytes()
assert (SOURCE/'facade_api.h').read_bytes()==(FIXED/'facade_api.h').read_bytes()
text=read(SOURCE/'wrapper.cc')
start=text.index('  ensure(::SetPriorityClass')
end=text.index('  const auto qos =',start)
text=text[:start]+text[end:]
text=text.replace('return finish(g09_fixed_driver_main(argc, argv));','return g09_fixed_driver_main(argc, argv);')
text=text.replace('return finish(g09_fixed_driver_main(5, arguments));','return g09_fixed_driver_main(5, arguments);')
assert text==read(FIXED/'wrapper.cc'), 'Other driver delta'
result=dict(gate='PASS_STATIC_ONLY',scope='Inverse source delta, not native execution/qualification',
    checks=['invocation inverse delta equals product source','facade inverse delta equals frozen facade',
        'driver and C table header byte-identical','wrapper inverse policy/ownership-telemetry delta equals frozen wrapper'],
    files=[dict(path=str(p),sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in sorted(SOURCE.iterdir()) if p.is_file()])
(OUT/'source-proof.json').write_bytes((json.dumps(result,indent=2)+'\n').encode('utf8'))
print(json.dumps(result,indent=2))
