"""Finish explicit recorder linkage and process-exit ownership telemetry."""
from pathlib import Path
import hashlib
import json

OUT=Path('C:/public/project-hyle/hyle/.scratch/inference-gaps/g09-completion-observation-25')
SOURCE=OUT/'source'
path=SOURCE/'invocation.cc'
text=path.read_text(encoding='utf8')
declaration='extern "C" void g09_record(unsigned, const void *, const void *, std::uint64_t) noexcept;\n'
assert text.count(declaration)==1
text=text.replace(declaration,'')
needle='namespace hyle::graph::cpu_vulkan {\n'
assert text.count(needle)==1
text=text.replace(needle,'#include <cstdint>\n'+declaration+'\n'+needle)
path.write_bytes(text.encode('utf8'))
path=SOURCE/'wrapper.cc'
text=path.read_text(encoding='utf8')
old='  std::fprintf(stderr,"# G09_OBSERVATION_ACTUAL_POLICY mask=0x%llx priority=%lu\\n",static_cast<unsigned long long>(current_mask),::GetPriorityClass(::GetCurrentProcess()));'
new='''  std::fprintf(stderr,"# G09_OBSERVATION_ACTUAL_POLICY pid=%lu mask=0x%llx priority=%lu nonce=%s\\n",::GetCurrentProcessId(),static_cast<unsigned long long>(current_mask),::GetPriorityClass(::GetCurrentProcess()),hyle::bench::perf::run_nonce());
  const auto finish=[](int code) { std::fprintf(stderr,"# G09_OBSERVATION_PROCESS_EXIT code=%d\\n",code);return code; };'''
assert text.count(old)==1
text=text.replace(old,new)
assert text.count('return g09_fixed_driver_main(argc, argv);')==1
assert text.count('return g09_fixed_driver_main(5, arguments);')==1
text=text.replace('return g09_fixed_driver_main(argc, argv);','return finish(g09_fixed_driver_main(argc, argv));')
text=text.replace('return g09_fixed_driver_main(5, arguments);','return finish(g09_fixed_driver_main(5, arguments));')
path.write_bytes(text.encode('utf8'))
manifest=json.loads((OUT/'source-manifest.json').read_text(encoding='utf8'))
manifest['sources']=[dict(path=p.name,sha256=hashlib.sha256(p.read_bytes()).hexdigest(),bytes=p.stat().st_size) for p in sorted(SOURCE.iterdir()) if p.is_file()]
manifest.pop('extra_os_threads',None)
manifest.update(source_extra_os_threads=0,profiler_threads='UNKNOWN_NONPRODUCT')
(OUT/'source-manifest.json').write_bytes((json.dumps(manifest,indent=2)+'\n').encode('utf8'))
print('Draft linkage/actual process ownership markers fixed; no build/native run')
