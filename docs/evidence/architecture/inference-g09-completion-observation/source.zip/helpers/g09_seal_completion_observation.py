"""Seal reviewed one-shot diagnostic inputs; no application execution."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import shutil
import zipfile

ROOT=Path('C:/public/project-hyle/hyle')
OUT=ROOT/'.scratch/inference-gaps/g09-completion-observation-25'
BUILD=Path('C:/h7/g09-completion-observation-25')
EVIDENCE=ROOT/'evidence/architecture/inference-g09-completion-observation'
PEER=Path('C:/h7/g09-p1-peer-9e2')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
load=lambda p:json.loads(p.read_text(encoding='utf8'))
review=ROOT/'.scratch/inference-gaps/g09-completion-observation-review-25.json'
assert sha(review)=='86f1ce9691204a2ca9efbcdaa5d06af497cc66b0b96e0953477c3f37faf37f6e'
assert not (OUT/'observation-authorization.json').exists() and not (OUT/'run').exists()
if (EVIDENCE/'25.json').exists():assert sha(EVIDENCE/'25.json')==sha(review)
else:shutil.copyfile(review,EVIDENCE/'25.json')

def archive(target, rows):
    assert not target.exists()
    with zipfile.ZipFile(target,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for p,name in rows:z.write(p,name)

source_rows=[(p,'source/'+p.name) for p in sorted((OUT/'source').iterdir()) if p.is_file()]
helpers=sorted((ROOT/'.scratch/inference-gaps').glob('*observation*.py'))
source_rows += [(p,'helpers/'+p.name) for p in helpers]
help_paths=[ROOT/f'.scratch/inference-gaps/g09-nsys-{s}-help-24.txt' for s in ['profile','export']]
source_rows += [(p,'installed-help/'+p.name) for p in help_paths]
cards=[ROOT/'docs/implementation/tasks/tooling/inference-g09-native-workload-aa.md',
       ROOT/'docs/implementation/tasks/graph/inference-g09-joint-pipeline.md']
source_rows += [(p,'pre-run-cards/'+p.name) for p in cards]
archive(EVIDENCE/'source.zip',source_rows)
metadata=[p for p in sorted(OUT.rglob('*')) if p.is_file() and 'source' not in p.relative_to(OUT).parts]
metadata_rows=[(p,'observation/'+p.relative_to(OUT).as_posix()) for p in metadata]
metadata_rows += [(BUILD/'compile_commands.json','build/compile_commands.json'),
                  (BUILD/'CMakeCache.txt','build/CMakeCache.txt'),
                  (BUILD/'build.ninja','build/build.ninja')]
metadata_rows += [(p,'build/'+p.relative_to(BUILD).as_posix()) for p in sorted(BUILD.rglob('*.rsp'))]
archive(EVIDENCE/'pre-run.zip',metadata_rows)

files={}
def add(p,expected=None):
    p=Path(p)
    if not p.is_absolute():p=OUT/'source'/p
    p=p.resolve(); actual=sha(p)
    assert expected is None or actual==expected,(p,expected,actual)
    files[str(p)]=dict(path=str(p),sha256=actual,bytes=p.stat().st_size)
def rows(value):
    if isinstance(value,dict):
        if 'path' in value and 'sha256' in value:add(value['path'],value['sha256'])
        for x in value.values():rows(x)
    elif isinstance(value,list):
        for x in value:rows(x)

for n in ['source-manifest.json','source-proof.json','build-result.json','artifact-binding.json']:
    p=OUT/n;add(p);rows(load(p))
final=load(review)
# Other-input card hashes are the retained historical review snapshot, not the
# subsequently clarified pre-run card; bind actual cards separately below.
rows(final['artifact_phase']['reviewed_artifact_data'])
for p in helpers+help_paths+cards:add(p)
for p,_ in metadata_rows:add(p)
for p in sorted((PEER/'scripts/hyle_perf').glob('*.py')):add(p)
add(PEER/'scripts/perf-machines.json')
for p in [EVIDENCE/'24.json',EVIDENCE/'25-source.json',EVIDENCE/'25.json',
          EVIDENCE/'source.zip',EVIDENCE/'pre-run.zip',
          ROOT/'evidence/architecture/inference-g09-p1-instrument-attempt/receipt.json',
          ROOT/'src/sched/scheduler.cc',ROOT/'include/hyle/sched/scheduler.h']:add(p)
# Installed headers were independently checked against original qualified SDK.
for p in sorted(Path('C:/h7/g09-sdk/vulkan-static-1/relocated/include/hyle').rglob('*')):
    if p.is_file():add(p)
authorization=dict(schema='hyle.g09.one-shot-completion-observation/v1',
    created_utc=datetime.now(timezone.utc).isoformat(),
    decision='ALLOW_ONE_FROZEN_NONRANKING_COMPLETION_OBSERVATION',
    product_candidate='3524413272cb52d06af5e64d634edbfef09b9864',
    fixed_build=str(BUILD),fixed_run=str(OUT/'run'),
    launcher=str(ROOT/'.scratch/inference-gaps/g09_run_completion_observation.py'),
    scope='Exactly one candidate self-pair process, original four shapes/4M/8warmups/12paired/exact1, candidate-first/allocation-first; diagnostic only.',
    restrictions=['No qualification/P1/ranking or statistical/product correction.',
                  'One Nsight Vulkan/NVTX capture, no CUDA/WDDM/CPU sampling/context switches/admin.',
                  'One original topology; overflow/oracle/identity/capture/attribution failure stops, no retry.',
                  'Same-PID time extensions preserve cost; own-task cleanup only.',
                  'GPU batch end/poll-driven terminal is not independent public native readiness. Unknown stays unknown.'],
    files=[files[k] for k in sorted(files)])
target=OUT/'observation-authorization.json'
target.write_text(json.dumps(authorization,indent=2)+'\n',encoding='utf8')
shutil.copyfile(target,EVIDENCE/'authorization.json')
print(json.dumps(dict(state='SEALED_NOT_RUN',files=len(files),authorization_sha256=sha(target),
    archives=[dict(name=p.name,bytes=p.stat().st_size,sha256=sha(p)) for p in [EVIDENCE/'source.zip',EVIDENCE/'pre-run.zip']]),indent=2))
