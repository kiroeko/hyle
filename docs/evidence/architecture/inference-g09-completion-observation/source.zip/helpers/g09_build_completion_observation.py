"""Four-TU disposable diagnostic build; never launches its application."""
from pathlib import Path
import ctypes
import hashlib
import json
import os
import re
import shutil
import subprocess
import time

ROOT=Path('C:/public/project-hyle/hyle')
OUT=ROOT/'.scratch/inference-gaps/g09-completion-observation-25'
SOURCE=OUT/'source'
BUILD=Path('C:/h7/g09-completion-observation-25')
PREFIX=Path('C:/h7/g09-sdk/vulkan-static-1/relocated')
LOGS=OUT/'build-logs'
assert not BUILD.exists() and not LOGS.exists(), 'Preserve attempts'
manifest=json.loads((OUT/'source-manifest.json').read_text(encoding='utf8'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for row in manifest['sources']:
    assert sha(SOURCE/row['path'])==row['sha256']
subprocess.run(['git','diff','--exit-code','e09f30925c6dba5cf4540669fd3b4874f45bb158','--','src/graph_route_cpu_vulkan'],cwd=ROOT,check=True)
setup=subprocess.check_output(['cmd','/d','/c',str(ROOT/'.scratch/inference-gaps/g01/cpu-ragged-env.cmd')],encoding='utf8',errors='replace')
env={k.upper():v for k,v in os.environ.items()}
env.update((k.upper(),v) for k,v in (x.split('=',1) for x in setup.splitlines() if '=' in x and not x.startswith('=')))
env['VSLANG']='1033'
LOGS.mkdir()
started=time.monotonic()
result=dict(state='BUILDING',stages=[],source_manifest_sha256=sha(OUT/'source-manifest.json'),
    scope='Only4 diagnostic C++ TUs/2facades/1driver; all shipping SDK archives imported unchanged. No application/native GPU execution.')

def save():
    result['elapsed_seconds']=time.monotonic()-started
    (OUT/'build-result.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8')

def run(stage,command):
    child=None
    stamp=time.monotonic()
    try:
        with (LOGS/(stage+'.log')).open('wb') as log:
            child=subprocess.Popen([str(x) for x in command],env=env,cwd=ROOT,stdout=log,stderr=subprocess.STDOUT,
                creationflags=subprocess.CREATE_NO_WINDOW|subprocess.BELOW_NORMAL_PRIORITY_CLASS)
            get=ctypes.windll.kernel32.GetProcessAffinityMask
            get.argtypes=[ctypes.c_void_p,ctypes.POINTER(ctypes.c_size_t),ctypes.POINTER(ctypes.c_size_t)]
            pin=ctypes.windll.kernel32.SetProcessAffinityMask
            pin.argtypes=[ctypes.c_void_p,ctypes.c_size_t]
            available,system=ctypes.c_size_t(),ctypes.c_size_t()
            handle=ctypes.c_void_p(int(child._handle))
            assert get(handle,ctypes.byref(available),ctypes.byref(system))
            assert pin(handle,sum([1<<i for i in range(64) if available.value&(1<<i)][:4]))
            result.update(stage=stage,child_pid=child.pid);save()
            print(stage,'RUNNING',child.pid,flush=True)
            while True:
                try:
                    code=child.wait(timeout=1800);break
                except subprocess.TimeoutExpired:
                    result.setdefault('extensions',[]).append(dict(stage=stage,pid=child.pid,seconds=1800));save()
        result.pop('child_pid',None)
        result['stages'].append(dict(stage=stage,command=[str(x) for x in command],exit_code=code,elapsed_seconds=time.monotonic()-stamp))
        save()
        if code:
            raise RuntimeError((LOGS/(stage+'.log')).read_text(encoding='utf8',errors='replace')[-7000:])
    except BaseException:
        if child is not None and child.poll() is None:
            cleanup=subprocess.run(['taskkill','/PID',str(child.pid),'/T','/F'],capture_output=True,text=True,encoding='utf8',errors='replace',creationflags=subprocess.CREATE_NO_WINDOW)
            result['owned_cleanup']=dict(pid=child.pid,exit_code=cleanup.returncode,stdout=cleanup.stdout,stderr=cleanup.stderr)
            if child.poll() is None:child.kill()
            child.wait()
        raise

try:
    run('configure',['cmake','-S',SOURCE,'-B',BUILD,'-G','Ninja','-DCMAKE_BUILD_TYPE=Release','-DCMAKE_EXPORT_COMPILE_COMMANDS=ON','-DCMAKE_PREFIX_PATH='+str(PREFIX)])
    commands=json.loads((BUILD/'compile_commands.json').read_text(encoding='utf8'))
    assert len(commands)==4 and all(Path(x['file']).resolve().is_relative_to(SOURCE) for x in commands)
    assert {Path(x['file']).name for x in commands}=={'invocation.cc','facade.cc','wrapper.cc'}
    dry=subprocess.check_output(['ninja','-C',str(BUILD),'-n'],env=env,text=True,encoding='utf8',errors='replace')
    (LOGS/'dry-run.log').write_text(dry,encoding='utf8')
    assert len(dry.splitlines())<15 and 'CUDA object' not in dry and 'Re-running CMake' not in dry
    run('build',['ninja','-C',BUILD,'-d','keeprsp','-j','2'])
    runtime=[]
    for path in sorted(Path('C:/h7/g09-p1/vulkan-candidate/bin').glob('*.dll')):
        if path.name.startswith('g09_'):continue
        dest=BUILD/'bin'/path.name
        shutil.copy2(path,dest)
        assert sha(path)==sha(dest)
        runtime.append(dict(path=str(dest),source=str(path),sha256=sha(dest),bytes=dest.stat().st_size))
    artifacts=[]
    for name in ['g09_observed_1.dll','g09_observed_2.dll','g09_observed_driver.exe']:
        path=BUILD/'bin'/name
        artifacts.append(dict(path=str(path),sha256=sha(path),bytes=path.stat().st_size))
    for copy in [1,2]:
        path=BUILD/f'g09_observed_{copy}.map'
        text=path.read_text(encoding='utf8',errors='replace')
        assert 'g09_record' in text and 'invocation.cc.obj' in text
        assert not re.search(r'hyle_graph_route_cpu_vulkan[^\s]*:invocation\.cc\.obj',text,re.I), 'Original invocation object was also extracted'
        (LOGS/path.name).write_bytes(path.read_bytes())
    for row in manifest['sources']:assert sha(SOURCE/row['path'])==row['sha256']
    result.update(state='BUILT_NOT_RUN',artifacts=artifacts,runtime=runtime,compile_units=4)
    save();print('BUILT_NOT_RUN',result['elapsed_seconds'],flush=True)
except BaseException as error:
    result.update(state='BUILD_OR_INSPECTION_FAIL',error=repr(error));save();raise
