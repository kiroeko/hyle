"""Prepare one disposable source-record diagnostic; no build or native run."""
from pathlib import Path
import hashlib
import json

ROOT = Path('C:/public/project-hyle/hyle')
OUT = ROOT/'.scratch/inference-gaps/g09-completion-observation-25'
SOURCE = OUT/'source'
assert not OUT.exists(), 'Do not replace a diagnostic attempt'
SOURCE.mkdir(parents=True)
fixed = ROOT/'.scratch/inference-gaps/g09-p1-instrument-adapter'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
source = ROOT/'src/graph_route_cpu_vulkan/invocation.cc'
original = source.read_text(encoding='utf8')
original_sha = sha(source)

def once(text, old, new):
    assert text.count(old) == 1, old
    return text.replace(old,new)

helpers = '''
// Disposable observation only; no product source or scheduling change.
extern "C" void g09_record(unsigned, const void *, const void *, std::uint64_t) noexcept;
Result<compute::CompletionPoll> g09_observe(RunState &run, const compute::Completion &completion) noexcept {
  g09_record(11, &run, &completion, 0);
  auto result = completion.poll();
  g09_record(12, &run, &completion, !result ? 2 : (*result == compute::CompletionPoll::kPending ? 0 : 1));
  return result;
}
void g09_progress_wait(RunState &run) noexcept {
  g09_record(20, &run, nullptr, 1000000);
  run.progress.wait_for(std::chrono::milliseconds(1));
  g09_record(21, &run, nullptr, 0);
}
void g09_finished_wait(RunState &run) noexcept {
  g09_record(40, &run, nullptr, 1000000);
  run.finished.wait_for(std::chrono::milliseconds(1));
  g09_record(41, &run, nullptr, 0);
}
'''

text = original.replace('run.progress.wait_for(std::chrono::milliseconds(1));','g09_progress_wait(run);')
assert text.count('g09_progress_wait(run);') == 2
text = text.replace('run.finished.wait_for(std::chrono::milliseconds(1));','g09_finished_wait(run);')
assert text.count('g09_finished_wait(run);') == 2
text = once(text,'    const auto ready = completion.poll();','    const auto ready = g09_observe(run, completion);')
text = once(text,'slot.pending.completion().poll()','g09_observe(run, slot.pending.completion())')
text = once(text,'value.pending_transfer.poll()','g09_observe(run, value.pending_transfer)')
text = once(text,'    if (pending != 0) run.pipeline_ready.wait_for(lock, std::chrono::milliseconds(1), changed);',
    '''    if (pending != 0) {
      g09_record(30, &run, nullptr, pending);
      run.pipeline_ready.wait_for(lock, std::chrono::milliseconds(1), changed);
      g09_record(31, &run, nullptr, pending);
    }''')
text = once(text,'using detail::InvocationState;\n','using detail::InvocationState;\n'+helpers)
(SOURCE/'invocation.cc').write_bytes(text.encode('utf8'))

recorder = r'''
#pragma once
#include <atomic>
#include <cstdint>
#include <cstdio>
#include <windows.h>
#include <nvtx3/nvToolsExt.h>
namespace g09_observation {
struct Record { std::uint64_t ns, run, token, value; unsigned kind, thread; };
constexpr unsigned capacity = 65536;
inline Record records[capacity]{};
inline std::atomic<unsigned> used{0};
inline std::uint64_t now() noexcept {
  static const std::uint64_t frequency = [] { LARGE_INTEGER f{}; QueryPerformanceFrequency(&f); return static_cast<std::uint64_t>(f.QuadPart); }();
  LARGE_INTEGER v{}; QueryPerformanceCounter(&v);
  const auto count = static_cast<std::uint64_t>(v.QuadPart);
  return count/frequency*1000000000ULL + count%frequency*1000000000ULL/frequency;
}
inline void marker(unsigned kind, const void *state, std::uint64_t value) noexcept;
inline bool flush() noexcept {
  const auto count = used.load(std::memory_order_acquire);
  std::fprintf(stderr,"# G09_OBSERVATION tag=%s count=%u capacity=%u overflow=%u clock=QPC-ns\n",G09_IMAGE_TAG,count,capacity,count>capacity);
  for (unsigned i=0; i<count && i<capacity; ++i) {
    const auto &r=records[i];
    std::fprintf(stderr,"# G09_RECORD tag=%s ns=%llu kind=%u run=%llu token=%llu value=%llu thread=%u\n",G09_IMAGE_TAG,
      static_cast<unsigned long long>(r.ns),r.kind,static_cast<unsigned long long>(r.run),
      static_cast<unsigned long long>(r.token),static_cast<unsigned long long>(r.value),r.thread);
  }
  used.store(0,std::memory_order_release);
  return count<=capacity;
}
}
extern "C" void g09_record(unsigned kind,const void *run,const void *token,std::uint64_t value) noexcept {
  using namespace g09_observation;
  const auto stamp=now();
  const auto slot=used.fetch_add(1,std::memory_order_relaxed);
  if(slot<capacity) records[slot]={stamp,reinterpret_cast<std::uintptr_t>(run),reinterpret_cast<std::uintptr_t>(token),value,kind,GetCurrentThreadId()};
}
namespace g09_observation {
inline void marker(unsigned kind,const void *state,std::uint64_t value) noexcept {
  g09_record(kind,state,nullptr,value);
  const auto payload=now();
  nvtxEventAttributes_t a{};a.version=NVTX_VERSION;a.size=NVTX_EVENT_ATTRIB_STRUCT_SIZE;
  a.messageType=NVTX_MESSAGE_TYPE_ASCII;a.message.ascii=G09_IMAGE_TAG ":clock-align";
  a.payloadType=NVTX_PAYLOAD_TYPE_UNSIGNED_INT64;a.payload.ullValue=payload;
  nvtxMarkEx(&a);
  // Nsight marker time must lie between payload and this record's clock.
  g09_record(2,state,nullptr,payload);
}
}
'''
(SOURCE/'recorder.h').write_bytes(recorder.lstrip().encode('utf8'))
facade = (fixed/'retained/facade.cc').read_text(encoding='utf8')
facade = once(facade,'#endif\n\nnamespace {','#endif\n#include "recorder.h"\n\nnamespace {')
facade = once(facade,'    return status_result(static_cast<State *>(state)->replay(full_oracle != 0), error, capacity);',
    '''    g09_observation::marker(1,state,full_oracle);
    const auto status = static_cast<State *>(state)->replay(full_oracle != 0);
    g09_observation::marker(3,state,status.ok() ? 0 : 1);
    return status_result(status, error, capacity);''')
facade = once(facade,'  return state ? status_result(state->close(), error, capacity) : 0;',
    '''  const auto status = state ? state->close() : Status::Ok();
  const auto complete_records = g09_observation::flush();
  if (!complete_records) return status_result(Status::Internal("diagnostic record capacity exceeded"),error,capacity);
  return status_result(status,error,capacity);''')
(SOURCE/'facade.cc').write_bytes(facade.encode('utf8'))
(SOURCE/'facade_api.h').write_bytes((fixed/'facade_api.h').read_bytes())
cmake = '''cmake_minimum_required(VERSION 3.25)
project(g09_disposable_completion_observation LANGUAGES CXX)
set(CMAKE_CXX_STANDARD 23)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
set(CMAKE_INTERPROCEDURAL_OPTIMIZATION OFF)
set(CMAKE_RUNTIME_OUTPUT_DIRECTORY "${CMAKE_BINARY_DIR}/bin")
find_package(Hyle CONFIG REQUIRED COMPONENTS compute graph)
if(NOT Hyle_STATIC OR NOT WIN32)
  message(FATAL_ERROR "Only the qualified static Windows SDK")
endif()
add_library(g09_observed_invocation OBJECT invocation.cc)
target_link_libraries(g09_observed_invocation PRIVATE hyle::graph)
target_include_directories(g09_observed_invocation PRIVATE "C:/public/project-hyle/hyle/src/graph_route_cpu_vulkan")
foreach(copy RANGE 1 2)
  set(target g09_observed_${copy})
  add_library(${target} SHARED facade.cc $<TARGET_OBJECTS:g09_observed_invocation>)
  target_compile_definitions(${target} PRIVATE G09_VULKAN=1 "G09_IMAGE_TAG=\\\"candidate-${copy}\\\"")
  target_include_directories(${target} PRIVATE "C:/Program Files/NVIDIA GPU Computing Toolkit/CUDA/v13.3/include")
  target_link_libraries(${target} PRIVATE hyle::compute hyle::graph)
  target_link_options(${target} PRIVATE /INCREMENTAL:NO "/MAP:${CMAKE_BINARY_DIR}/${target}.map")
endforeach()
'''
(SOURCE/'CMakeLists.txt').write_bytes(cmake.encode('utf8'))
manifest = dict(schema='hyle.g09.disposable-observation-source.v1',scope='One non-ranking source-record + Vulkan/NVTX trace; no shipping source/ABI/math/wait policy or statistical correction',
    product_candidate='e09f30925c6dba5cf4540669fd3b4874f45bb158',original_invocation_sha256=original_sha,
    original_facade_sha256=sha(fixed/'retained/facade.cc'),original_driver_sha256=sha(fixed/'driver.cc'),
    sources=[dict(path=p.name,sha256=sha(p),bytes=p.stat().st_size) for p in sorted(SOURCE.iterdir()) if p.is_file()],
    build='C:/h7/g09-completion-observation-25',sdk='C:/h7/g09-sdk/vulkan-static-1/relocated',
    executable='C:/h7/g09-p1-instrument/vulkan/qualified-build-obs-free-1/bin/g09_pipeline_primary.exe',
    intended_compile_units=3,processes=1,extra_os_threads=0,record_capacity_per_image=65536,
    record_kinds={'1':'full public replay enter','2':'NVTX alignment bracket after;value=before QPC-ns','3':'full replay return after internal drain',
      '11':'completion poll begin','12':'poll end value0pending/1complete/2error','20':'unsignaled progress wait begin','21':'progress wait resume',
      '30':'native frontier timed wait begin/pendingcount','31':'native frontier wait resume','40':'signaled finished wait begin','41':'finished wait resume'},
    restrictions=['Only current Vulkan candidate two-image observation; no new AA/P1 qualification.','No independent native-ready claim from poll publication.','GPU work end is not full Completion; attribution/time alignment failure remains UNKNOWN.','No repeat/extra overlay/calibration/threshold/iteration change.'])
(OUT/'source-manifest.json').write_bytes((json.dumps(manifest,indent=2)+'\n').encode('utf8'))
print(json.dumps(manifest,indent=2))
