"""One direct ProcDump launch of the unchanged diagnostic, without Nsight."""
from pathlib import Path
import ast,ctypes,hashlib,json,os,re,secrets,subprocess,sys,time
ROOT=Path('C:/public/project-hyle/hyle')
OUT=ROOT/'.scratch/inference-gaps/g09-av-debug-1'
RUN=OUT/'run'
BUILD=Path('C:/h7/g09-completion-observation-25')
PROC=Path('C:/h7/g09-procdump-1/procdump64.exe')
TOOLS=Path('C:/h7/g09-p1-peer-9e2/scripts')
sys.path.insert(0,str(TOOLS))
from hyle_perf import evaluate_machine_profile,expected_child_policy,get_machine_profile,load_registry,probe_machine
from hyle_perf.runner import _apply_sampling_policy,_child_environment,_creation_flags,_probe_child_policy
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert ctypes.windll.shell32.IsUserAnAdmin()
assert not RUN.exists()
auth=json.loads((OUT/'authorization.json').read_text(encoding='utf8'))
assert auth['decision']=='ALLOW_ONE_OWNED_DEBUGGER_DIAGNOSTIC'
for row in auth['files']:assert sha(Path(row['path']))==row['sha256'],row['path']
host=probe_machine(paths=[('build',BUILD)])
profile=get_machine_profile(load_registry(),'W1-WIN')
gate=evaluate_machine_profile(profile,host,role='engineering',sampling_topology='native-runtime-pair')
assert gate['gate']=='PASS',gate
policy=expected_child_policy(profile,sampling_topology='native-runtime-pair',probe=host)
nonce=secrets.token_hex(16)
env=_child_environment(['HYLE_BENCH_AA_ROUTE','HYLE_BENCH_VERIFY_ONLY','HYLE_BENCH_RIVAL_FIRST','HYLE_BENCH_PEER_ALLOCATION_FIRST','HYLE_PERF_APPLE_QOS'],
 {'HYLE_BENCH_AA_ROUTE':'candidate','HYLE_BENCH_RIVAL_FIRST':'0','HYLE_BENCH_PEER_ALLOCATION_FIRST':'0','HYLE_PERF_RUN_NONCE':nonce},profile,policy)
env['DISABLE_VULKAN_OBS_CAPTURE']='1'
assert not any(k.upper() in ['CUDA_INJECTION64_PATH','NVTX_INJECTION64_PATH'] for k in env)
RUN.mkdir();(RUN/'dumps').mkdir();started=time.monotonic()
result=dict(state='RUNNING',authorization_sha256=sha(OUT/'authorization.json'),native_workload_processes_planned=1,
 qualifier='DIAGNOSTIC_ONLY_NOT_AA_OR_P1',valid_formal_ab=0,stages=[],builds=0,source_changes=0,nsight=False)
def save():
 result['elapsed_seconds']=time.monotonic()-started
 (RUN/'result.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8')
# Reuse the reviewed nonce/PID/full-image cleanup, with one decoding adjustment:
# ProcDump emits UTF16 while the child uses narrow stdio in this same raw log.
old=(ROOT/'.scratch/inference-gaps/g09_run_completion_observation_admin_retry.py').read_text(encoding='utf8')
node=next(n for n in ast.parse(old).body if isinstance(n,ast.FunctionDef) and n.name=='stop_owned_application_on_failure')
cleanup_source=ast.get_source_segment(old,node)
assert cleanup_source.count("text=path.read_text(encoding='utf8',errors='replace')")==1
cleanup_source=cleanup_source.replace("text=path.read_text(encoding='utf8',errors='replace')",
 "text=path.read_text(encoding='utf8',errors='replace').replace(chr(0),'')")
exec(compile(cleanup_source,'<reviewed-owned-cleanup-with-log-decoding>','exec'))
child=None
command=[str(PROC),'-accepteula','-mt','-e','-n','1','-x',str(RUN/'dumps'),str(BUILD/'bin/g09_observed_driver.exe')]
try:
 with _apply_sampling_policy(policy) as applied:
  result['policy']=applied;result['child_canary']=_probe_child_policy(policy,_creation_flags(policy));save()
  with (RUN/'profile.log').open('wb') as log:
   child=subprocess.Popen(command,cwd=BUILD/'bin',env=env,stdout=log,stderr=subprocess.STDOUT,creationflags=_creation_flags(policy))
   result['owned_procdump_pid']=child.pid;save();print('DIRECT_DEBUG_RUNNING',child.pid,flush=True)
   while True:
    try:code=child.wait(timeout=1800);break
    except subprocess.TimeoutExpired:result.setdefault('extensions',[]).append(dict(pid=child.pid,seconds=1800));save()
 result['stages'].append(dict(command=command,exit_code=code,elapsed_seconds=time.monotonic()-started))
 text=(RUN/'profile.log').read_bytes().decode('utf8',errors='replace').replace(chr(0),'')
 (RUN/'ascii-markers-view.log').write_text(text,encoding='utf8')
 normal='# G09_OBSERVATION_PROCESS_EXIT code=0' in text
 before=re.findall(r'^# G09_ORACLE .* before=PASS ',text,re.M)
 after=re.findall(r'^# G09_ORACLE .* after=PASS ',text,re.M)
 retired=re.findall(r'^# G09_DEFERRED_DESTROY .* status=0$',text,re.M)
 blocks=re.findall(r'^# G09_OBSERVATION tag=(\S+) count=(\d+) capacity=65536 overflow=0 clock=QPC-ns$',text,re.M)
 actual_policy=re.findall(r'^# G09_OBSERVATION_ACTUAL_POLICY pid=(\d+) mask=0x14 priority=32768 nonce='+nonce+r'$',text,re.M)
 modules=re.findall(r'^# G09_MODULE phase=(\S+) path=(.+)$',text,re.M)
 phases={phase for phase,_ in modules}
 injected=[path for _,path in modules if any(s in path.lower() for s in ['toolsinjection','nsight','obs-studio-hook','graphics-hook64.dll'])]
 result.update(actual_normal_main_exit=normal,oracles_before=len(before),oracles_after=len(after),retired_states=len(retired),
  recorder_blocks=len(blocks),source_record_count=sum(int(x[1]) for x in blocks),
  dumps=[dict(path=str(p),bytes=p.stat().st_size,sha256=sha(p)) for p in sorted((RUN/'dumps').glob('*.dmp'))])
 result.update(actual_policy_matches=len(actual_policy),module_phases=len(phases),unexpected_profiler_or_obs_modules=injected)
 complete=normal and len(before)==len(after)==4 and len(retired)==len(blocks)==8 and len(actual_policy)==1 and len(phases)==4 and not injected
 result['state']='DIRECT_DEBUG_COMPLETE' if complete else 'DIRECT_DEBUG_INCOMPLETE'
 if not complete:stop_owned_application_on_failure()
 for row in auth['files']:assert sha(Path(row['path']))==row['sha256'],row['path']
 save();print(json.dumps(result,indent=2),flush=True)
except BaseException as error:
 result.update(state='DEBUG_CAPTURE_FAIL',error=repr(error))
 if child is not None and child.poll() is None:
  clean=subprocess.run(['taskkill','/PID',str(child.pid),'/T','/F'],capture_output=True,text=True,encoding='utf8',errors='replace',creationflags=subprocess.CREATE_NO_WINDOW)
  result['owned_cleanup']=dict(pid=child.pid,exit_code=clean.returncode,stdout=clean.stdout,stderr=clean.stderr)
  if child.poll() is None:child.kill()
  child.wait()
 try:stop_owned_application_on_failure()
 except BaseException as clean_error:result['target_cleanup_error']=repr(clean_error)
 save();raise
