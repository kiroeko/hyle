from pathlib import Path
import ctypes,hashlib,json,os,re,subprocess,sys,time

root=Path('C:/public/project-hyle/hyle')
folder=root/'.scratch/inference-gaps/g09-p1-cuda-runtime-preflight'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
freeze='--freeze-only' in sys.argv[1:]
started=time.monotonic()
if freeze:
 folder.mkdir(parents=True,exist_ok=False)
 r={'state':'FREEZING_BEFORE_FIRST_RUNTIME','stages':[],'scope':'Exact original staged DLL identities for both already linked CUDA image sets, then original driver verify-only loader/math/completion diagnostic in both load/allocation orders. No benchmark/A-A/formal sampling and no HYLE product changes.'}
 r['builds']={}
 for kind in ['baseline','candidate']:
  file=root/f'.scratch/inference-gaps/g09-p1-builds/windows-cuda-{kind}/result.json'
  record=json.loads(file.read_text(encoding='utf8'))
  assert record['state']=='TWO_PRIVATE_IMAGES_BUILT_EXPORT_IMPORT_INITIAL_CHECKS_PASS_NOT_FINAL_ARTIFACT_QUALIFICATION'
  for item in record['images']:assert sha(Path(item['path']))==item['sha256']
  if kind=='candidate':assert sha(Path(record['driver']['path']))==record['driver']['sha256']
  r['builds'][kind]={'path':str(file),'sha256':sha(file),'images':record['images'],'driver':record.get('driver')}
 r['staged_runtime']={}
 for kind in ['baseline','candidate']:
  directory=Path(f'C:/h7/g09-p1/cuda-{kind}/bin')
  private={f'g09_cuda_{kind}_{n}.dll' for n in [1,2]}
  r['staged_runtime'][kind]=[{'path':str(p),'name':p.name,'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(directory.glob('*.dll')) if p.name not in private]
 assert [{k:x[k] for k in ['name','bytes','sha256']} for x in r['staged_runtime']['baseline']]==[{k:x[k] for k in ['name','bytes','sha256']} for x in r['staged_runtime']['candidate']]
 r['thread_environment']={k:os.environ.get(k) for k in ['OMP_NUM_THREADS','MKL_NUM_THREADS','OPENBLAS_NUM_THREADS','GGML_N_THREADS','HYLE_BENCH_PEER_ALLOCATION_FIRST','HYLE_BENCH_RIVAL_FIRST']}
 r['gpu']=subprocess.check_output(['nvidia-smi','--query-gpu=name,uuid,driver_version','--format=csv,noheader'],text=True).strip()
 r['state']='BOTH_STAGED_RUNTIME_DLL_SETS_EXACT_IDENTICAL_FROZEN_NOT_EXECUTED'
 r['elapsed_seconds']=time.monotonic()-started
 (folder/'freeze.json').write_text(json.dumps(r,indent=2)+'\n',encoding='utf8')
 (folder/'runner-freeze.py').write_bytes(Path(__file__).read_bytes())
 print(r['state'],len(r['staged_runtime']['baseline']),r['elapsed_seconds'],flush=True)
 raise SystemExit(0)

frozen=folder/'freeze.json';r=json.loads(frozen.read_text(encoding='utf8'))
assert r['state']=='BOTH_STAGED_RUNTIME_DLL_SETS_EXACT_IDENTICAL_FROZEN_NOT_EXECUTED'
review=root/'.scratch/inference-gaps/g09-p1-cuda-artifact-review-14.json'
assert review.is_file(),'Finite independent artifact preflight must finish first'
review_data=json.loads(review.read_text(encoding='utf8'))
# Human-readable independent decision is bound below and must explicitly allow
# this diagnostic before this branch is enabled after reviewing its actual text.
assert '--reviewed-allow-verify' in sys.argv[1:]
assert not (folder/'runtime-result.json').exists()
for kind,data in r['builds'].items():
 assert sha(Path(data['path']))==data['sha256']
 for item in data['images']:assert sha(Path(item['path']))==item['sha256']
 for item in r['staged_runtime'][kind]:assert sha(Path(item['path']))==item['sha256']
driver=Path(r['builds']['candidate']['driver']['path']);assert sha(driver)==r['builds']['candidate']['driver']['sha256']
args=[driver,*[Path(r['builds'][k]['images'][n]['path']) for k,n in [('candidate',0),('baseline',0),('candidate',1),('baseline',1)]]]
run_record={'state':'RUNNING','freeze_sha256':sha(frozen),'review14_sha256':sha(review),'stages':[],'first_runtime':True,'formal_samples':0,'benchmark_compare_calls':0}
ctypes.windll.kernel32.SetErrorMode(0x0001|0x0002|0x8000)
env=dict(os.environ)
for key in list(env):
 if key.startswith('HYLE_BENCH_') or key=='HYLE_PERF_RUN_NONCE':env.pop(key)
env.update(HYLE_BENCH_VERIFY_ONLY='1',HYLE_VULKAN_VALIDATION='0',PATH=str(driver.parent)+';C:/Windows/System32;C:/Windows')
def save():
 run_record['elapsed_seconds']=time.monotonic()-started
 (folder/'runtime-result.json').write_text(json.dumps(run_record,indent=2)+'\n',encoding='utf8')
try:
 for order in ['candidate-first','baseline-first']:
  env['HYLE_BENCH_PEER_ALLOCATION_FIRST']='1' if order=='baseline-first' else '0'
  log=folder/(order+'.log');stamp=time.monotonic()
  with log.open('wb') as output:
   p=subprocess.Popen([str(x) for x in args],cwd=root,env=env,stdout=output,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NO_WINDOW|subprocess.BELOW_NORMAL_PRIORITY_CLASS)
   get=ctypes.windll.kernel32.GetProcessAffinityMask;get.argtypes=[ctypes.c_void_p,ctypes.POINTER(ctypes.c_size_t),ctypes.POINTER(ctypes.c_size_t)]
   setmask=ctypes.windll.kernel32.SetProcessAffinityMask;setmask.argtypes=[ctypes.c_void_p,ctypes.c_size_t]
   allowed=ctypes.c_size_t();system=ctypes.c_size_t();handle=ctypes.c_void_p(int(p._handle))
   assert get(handle,ctypes.byref(allowed),ctypes.byref(system))
   mask=sum([1<<i for i in range(64) if allowed.value&(1<<i)][:4]);assert setmask(handle,mask)
   run_record.update(child_pid=p.pid,load_allocation_order=order,priority='BELOW_NORMAL',logical_cpu_limit=4);save()
   while True:
    try:code=p.wait(timeout=1800);break
    except subprocess.TimeoutExpired:run_record.setdefault('time_extensions',[]).append({'pid':p.pid,'seconds':1800});save()
  run_record.pop('child_pid',None)
  text=log.read_text(encoding='utf8',errors='replace')
  stage={'order':order,'exit_code':code,'elapsed_seconds':time.monotonic()-stamp,'log_sha256':sha(log)}
  run_record['stages'].append(stage);save()
  assert code==0,text[-5000:]
  assert len(re.findall(r'^# G09_ORACLE .* before=PASS ',text,re.M))==4
  assert len(re.findall(r'^# G09_ORACLE .* after=PASS ',text,re.M))==4
  assert '# G09_MEASUREMENT' not in text and len(re.findall(r'^# G09_IMAGE ',text,re.M))==2
  assert len(re.findall(r'^# G09_DEFERRED_DSO_UNLOAD .* status=0 ',text,re.M))==2
  actual=sorted(set(re.findall(r'^# G09_MODULE phase=\S+ path=(.+)$',text,re.M)))
  stage['actual_loaded_modules']=[{'path':p,'sha256':sha(Path(p)),'bytes':Path(p).stat().st_size} for p in actual]
  assert any('hyle_ggml_cpu_' in p.lower() for p in actual),'actual original default CPU native program not observed'
  assert any(Path(p).name.lower()=='nvcuda.dll' for p in actual),'native CUDA driver not observed'
  actual_facades={Path(p).name for p in actual if Path(p).name.startswith('g09_cuda_')}
  assert actual_facades=={'g09_cuda_baseline_1.dll','g09_cuda_candidate_1.dll'},actual_facades
  staged={x['name'].lower():x['sha256'] for x in r['staged_runtime']['baseline']}
  for item in stage['actual_loaded_modules']:
   name=Path(item['path']).name.lower()
   if name in staged:assert item['sha256']==staged[name],name
  print('VERIFY_ONLY_PASS',order,stage['elapsed_seconds'],len(actual),flush=True);save()
 run_record['state']='BOTH_LOAD_ORDERS_VERIFY_ONLY_FULL_ORACLES_DEFAULT_CPU_NATIVE_CUDA_COMPLETION_AND_MODULE_IDENTITIES_PASS_NOT_AA_OR_PERFORMANCE';save()
except BaseException as error:
 run_record.update(state='DIAGNOSTIC_FAIL',error=repr(error));save();raise
