from pathlib import Path
import hashlib,json,os,re,subprocess,sys,time

base=Path('/Users/kiro/hyle-scratch/compute-unified')
route,kind=sys.argv[1:3]
assert sys.platform=='darwin' and route in ['apple','vulkan'] and kind in ['baseline','candidate']
inputs=base/'g09-p1-inputs';source=inputs/'consumer';instrument=inputs/'canonical-instrument'
ledger=json.loads((source/'phase-ledger.json').read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
upload=json.loads((inputs/'upload.json').read_text())
for row in upload['files']:assert sha(inputs/row['path'])==row['sha256']
for row in ledger['source_files']:assert sha(source/row['path'])==row['sha256']
prefix=base/('g08-sdk' if kind=='baseline' else 'g09-sdk')/f'{route}-static-1/relocated'
assert prefix.is_dir()
if kind=='baseline':
 qualified=json.loads((inputs/f'qualified-sdk-{route}.json').read_text())
 assert qualified['candidate']=='5103c13d8ed119b06aa64e799f9768aea45ab913'
 for row in qualified['owner_artifacts']:assert sha(Path(row['path']))==row['sha256'],row['path']
build=base/'g09-p1'/f'{route}-{kind}';assert not build.exists()
out=base/'g09-p1-builds'/f'air-{route}-{kind}';out.mkdir(parents=True,exist_ok=False)
env=dict(os.environ,PATH='/Users/kiro/hyle-verify-tools/metal-17F109/shim:/opt/homebrew/bin:'+os.environ.get('PATH',''),HYLE_VULKAN_VALIDATION='0')
os.nice(10);cmake='/opt/homebrew/bin/cmake';ninja='/opt/homebrew/bin/ninja';started=time.monotonic()
r={'state':'SETUP','pid':os.getpid(),'route':route,'image_set':kind,'prefix':str(prefix),'build':str(build),'stages':[],
   'candidate':ledger['candidate'],'baseline':ledger['baseline'],'product_code_commit':ledger['product'],'source_files':ledger['source_files'],
   'phase_ledger_sha256':sha(source/'phase-ledger.json'),'upload_sha256':sha(inputs/'upload.json'),'max_jobs':4,'nice':os.nice(0),
   'scope':'Only two private original-public-consumer facades linked from qualified unchanged baseline or fixed-candidate static SDK, plus original-instrument driver for candidate. No HYLE product/kernel compilation, diagnostic/A-A/formal sampling or final artifact qualification.'}
def save():
 r['elapsed_seconds']=time.monotonic()-started;(out/'result.json').write_text(json.dumps(r,indent=2)+'\n')
def run(stage,args):
 stamp=time.monotonic();r.update(state='RUNNING',stage=stage);save();print(route,kind,stage,flush=True)
 with (out/(stage+'.log')).open('wb') as log:
  p=subprocess.Popen([str(x) for x in args],env=env,stdout=log,stderr=subprocess.STDOUT);r['child_pid']=p.pid;save()
  while True:
   try:code=p.wait(timeout=1800);break
   except subprocess.TimeoutExpired:r.setdefault('time_extensions',[]).append({'stage':stage,'pid':p.pid,'seconds':1800});save()
 r.pop('child_pid',None);r['stages'].append({'stage':stage,'command':[str(x) for x in args],'exit_code':code,'elapsed_seconds':time.monotonic()-stamp});save()
 if code:r['state']='FAIL';save();print((out/(stage+'.log')).read_text(errors='replace')[-12000:],flush=True);raise SystemExit(code)
try:
 r['identity']={k:subprocess.check_output(v,env=env,text=True).strip() for k,v in {
  'model':['sysctl','-n','hw.model'],'chip':['sysctl','-n','machdep.cpu.brand_string'],
  'system':['sw_vers'],'compiler':['xcrun','clang++','--version'],'metal':['xcrun','-sdk','macosx','metal','--version']}.items()}
 assert r['identity']['model']=='Mac16,12'
 r['sdk_files']=[{'path':p.relative_to(prefix).as_posix(),'sha256':sha(p),'bytes':p.stat().st_size} for p in sorted(prefix.rglob('*')) if p.is_file()]
 r['instrument_files']=[row for row in upload['files'] if row['path'].startswith('canonical-instrument/')]
 (out/'runner.py').write_bytes(Path(__file__).read_bytes());save()
 run('configure',[cmake,'-S',source,'-B',build,'-G','Ninja','-DCMAKE_BUILD_TYPE=Release','-DCMAKE_EXPORT_COMPILE_COMMANDS=ON',
  '-DCMAKE_PREFIX_PATH='+prefix.as_posix(),'-DG09_SOURCE='+instrument.as_posix(),'-DG09_ROUTE='+route,'-DG09_IMAGE_SET='+kind,'-DG09_BUILD_DRIVER='+('ON' if kind=='candidate' else 'OFF')])
 run('manifest',[ninja,'-C',build,'build.ninja'])
 targets=[f'g09_{route}_{kind}_{n}' for n in [1,2]]+(['g09_pipeline_driver'] if kind=='candidate' else [])
 dry=subprocess.check_output([ninja,'-C',str(build),'-n',*targets],env=env,text=True);(out/'dry-run.log').write_text(dry)
 assert len(dry.splitlines())<40 and 'Generate vulkan shaders' not in dry and 'Re-running CMake' not in dry,dry
 commands=json.loads((build/'compile_commands.json').read_text());assert len(commands)==(5 if kind=='candidate' else 3)
 for row in commands:
  assert 'source-c8874688/src/' not in row['command'] and 'HYLE_TESTING' not in row['command'] and '-fsanitize=' not in row['command']
  assert Path(row['file']).name in ['facade.cc','runtime_probe.cc','driver.cc','nanobench_impl.cc']
  if Path(row['file']).name=='facade.cc':assert str(prefix/'include') in row['command']
 (out/'compile-commands.json').write_text(json.dumps(commands,indent=2)+'\n')
 run('build',[ninja,'-C',build,'-j','4',*targets])
 r['images']=[]
 for n in [1,2]:
  name=f'g09_{route}_{kind}_{n}';binary=build/'bin'/('lib'+name+'.dylib');assert binary.is_file()
  run(name+'-exports',['nm','-gU',binary]);run(name+'-load-commands',['otool','-l',binary]);run(name+'-dependencies',['otool','-L',binary]);run(name+'-indirect-symbols',['otool','-Iv',binary])
  lines=(out/(name+'-exports.log')).read_text().splitlines()
  names=[x.split()[-1] for x in lines if re.match(r'^\s*[0-9a-fA-F]+\s+\S\s+',x)]
  assert names==['_hyle_g09_facade_v1'],names
  deps=(out/(name+'-dependencies.log')).read_text()
  assert not re.search(r'/libhyle_(graph|compute|sched|cpu_|core|memory)[^/\s]*\.dylib',deps),deps
  mapfile=build/(name+'.map');assert mapfile.is_file();(out/mapfile.name).write_bytes(mapfile.read_bytes())
  r['images'].append({'path':str(binary),'sha256':sha(binary),'bytes':binary.stat().st_size,'exports':names,'map_sha256':sha(mapfile)})
 if kind=='candidate':
  driver=build/'bin/g09_pipeline_driver';r['driver']={'path':str(driver),'sha256':sha(driver),'bytes':driver.stat().st_size}
 for row in upload['files']:assert sha(inputs/row['path'])==row['sha256']
 r['state']='TWO_PRIVATE_IMAGES_BUILT_C_ONLY_EXPORT_INITIAL_CHECKS_PASS_NOT_FINAL_ARTIFACT_QUALIFICATION';save();print(r['state'],flush=True)
except BaseException as error:
 if r['state']!='FAIL':r.update(state='SETUP_FAIL',error=repr(error));save()
 raise
