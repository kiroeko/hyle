import ctypes,json,time
from pathlib import Path
from ctypes import wintypes as w
class Lock(ctypes.Structure):
 _fields_=[('name',w.WCHAR*128),('timeout',ctypes.c_longlong),('alertable',w.BOOL)]
class Thread(ctypes.Structure):
 _fields_=[('pid',w.DWORD),('tid',w.DWORD),('wait_ms',w.DWORD),('context_switches',w.DWORD)]
class Object(ctypes.Union):
 _fields_=[('lock',Lock),('thread',Thread)]
class Node(ctypes.Structure):
 _anonymous_=['object'];_fields_=[('type',w.DWORD),('status',w.DWORD),('object',Object)]
assert ctypes.sizeof(Node)==280
api=ctypes.WinDLL('advapi32',use_last_error=True)
api.OpenThreadWaitChainSession.argtypes=[w.DWORD,ctypes.c_void_p];api.OpenThreadWaitChainSession.restype=ctypes.c_void_p
api.GetThreadWaitChain.argtypes=[ctypes.c_void_p,ctypes.c_size_t,w.DWORD,w.DWORD,ctypes.POINTER(w.DWORD),ctypes.POINTER(Node),ctypes.POINTER(w.BOOL)]
api.CloseThreadWaitChainSession.argtypes=[ctypes.c_void_p]
session=api.OpenThreadWaitChainSession(0,None);assert session
count=w.DWORD(16);nodes=(Node*16)();cycle=w.BOOL()
ok=api.GetThreadWaitChain(session,0,7,59560,ctypes.byref(count),nodes,ctypes.byref(cycle))
r={'pid':44036,'main_thread':59560,'unix_time':time.time(),'ok':bool(ok),'error':ctypes.get_last_error() if not ok else 0,'cycle':bool(cycle),'nodes':[]}
if ok:
 for n in nodes[:count.value]:
  r['nodes'].append({'type':n.type,'status':n.status,**({'pid':n.thread.pid,'tid':n.thread.tid,'wait_ms':n.thread.wait_ms,'context_switches':n.thread.context_switches} if n.type==8 else {'name':n.lock.name})})
api.CloseThreadWaitChainSession(session)
Path('.scratch/inference-gaps/g09-p1-cuda-runtime-preflight/unload-wait-chain.json').write_text(json.dumps(r,indent=2)+'\n',encoding='utf8')
print(json.dumps(r,indent=2))
