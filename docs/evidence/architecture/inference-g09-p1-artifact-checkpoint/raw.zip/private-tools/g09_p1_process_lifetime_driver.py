from pathlib import Path
import hashlib,json,subprocess,time

root=Path('C:/public/project-hyle/hyle');draft=root/'.scratch/inference-gaps/g09-p1-draft'
out=root/'.scratch/inference-gaps/g09-p1-windows-process-lifetime-driver';out.mkdir(exist_ok=False)
original=(draft/'driver.cc').read_text(encoding='utf8');old=(draft/'driver.cc').read_bytes()
sha=lambda data:hashlib.sha256(data).hexdigest()
assert sha(old)=='8f58350e6b39f051730d47f0565d62b1c3bf449636e3a1885a99deca5719ea25'
(out/'original-driver.cc').write_bytes(old)
start=original.index('  ~Image() {');end=original.index('\n};',start)
destructor='''  ~Image() {
    if (!handle) return;
#if defined(_WIN32)
    // The static CUDA completion reaper owns a process-lifetime thread.
    // Preserve each opaque image until process exit, symmetrically on both
    // arms. All per-replay ownership/drain and Arm::finish stay unchanged.
    std::fprintf(stderr, "# G09_DEFERRED_IMAGE_LIFETIME tag=%s boundary=process-exit explicit_unload=0 private_vendor_cache=UNKNOWN\\n",
        api ? api->image_tag : "unknown");
    handle = nullptr;
#else
    std::array<char, 128> tag{};
    std::snprintf(tag.data(), tag.size(), "%s", api ? api->image_tag : "unknown");
    const auto begin = std::chrono::steady_clock::now();
    const int status = dlclose(handle);
    const auto ns = std::chrono::duration_cast<std::chrono::nanoseconds>(
        std::chrono::steady_clock::now() - begin).count();
    std::fprintf(stderr, "# G09_DEFERRED_DSO_UNLOAD tag=%s nanoseconds=%lld status=%d private_vendor_cache=UNKNOWN\\n",
        tag.data(), static_cast<long long>(ns), status);
#endif
  }'''
updated=original[:start]+destructor+original[end:]
(out/'driver.cc').write_text(updated,encoding='utf8',newline='\n')
assert updated[:start]==original[:start] and updated[start+len(destructor):]==original[end:]
(out/'CMakeLists.txt').write_text('''cmake_minimum_required(VERSION 3.25)
project(g09_process_lifetime_driver LANGUAGES CXX)
set(CMAKE_CXX_STANDARD 23)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
if(NOT WIN32)
  message(FATAL_ERROR "Finite Windows-only driver lifetime correction")
endif()
add_library(g09_nanobench STATIC "C:/public/project-hyle/hyle/bench/nanobench_impl.cc")
target_include_directories(g09_nanobench SYSTEM PUBLIC "C:/public/project-hyle/hyle/third_party/nanobench")
add_executable(g09_pipeline_driver_process_lifetime driver.cc)
target_include_directories(g09_pipeline_driver_process_lifetime PRIVATE
 "C:/public/project-hyle/hyle/bench/common" "C:/public/project-hyle/hyle/.scratch/inference-gaps/g09-p1-draft")
target_compile_definitions(g09_pipeline_driver_process_lifetime PRIVATE "G09_ROUTE_NAME=\\"cuda\\"")
target_link_libraries(g09_pipeline_driver_process_lifetime PRIVATE g09_nanobench)
set_property(TARGET g09_pipeline_driver_process_lifetime PROPERTY INTERPROCEDURAL_OPTIMIZATION FALSE)
set_target_properties(g09_pipeline_driver_process_lifetime PROPERTIES RUNTIME_OUTPUT_DIRECTORY "C:/h7/g09-p1/cuda-candidate/bin")
''',encoding='utf8',newline='\n')
result={'state':'SOURCE_PREPARED_NOT_BUILT','original_driver_sha256':sha(old),'new_driver_source_sha256':sha((out/'driver.cc').read_bytes()),
 'correction':'Only Windows Image final mapping lifetime; both arms retain facade until process exit. Warm math/prepare/submit/native completion/owning results/observations/drain/State destruction and all workloads unchanged. No dynamic-unload or private-global cache reclamation claim.',
 'unload_failure':'../g09-p1-cuda-runtime-preflight/runtime-result.json','wct':'../g09-p1-cuda-runtime-preflight/unload-wait-chain.json',
 'attribution_limit':'Observed main thread waiting for another thread after all State destruction, before first image-unload return. Original baseline/candidate static CUDA CompletionReaper dtor joins thread during CRT detach; consistent loader-lock hazard, not a full native stack attribution or new G09 product bug.',
 'independent_advice':'Existing user-delegated audit agent inspected original unchanged reaper/thread code and approved symmetric Windows process-lifetime facade boundary for finite verification; no A/A/P1 or dynamic-unload PASS.'}
(out/'source-record.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8')
print(json.dumps(result,indent=2))
