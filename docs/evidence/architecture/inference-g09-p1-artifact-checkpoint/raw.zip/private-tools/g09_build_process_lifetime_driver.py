from pathlib import Path
import ctypes,hashlib,json,os,subprocess,time

root=Path('C:/public/project-hyle/hyle');out=root/'.scratch/inference-gaps/g09-p1-windows-process-lifetime-driver'
build=Path('C:/h7/g09-p1/cuda-driver-process-lifetime');assert not build.exists()
setup=subprocess.check_output(['cmd','/d','/c',str(root/'.scratch/inference-gaps/g01/cpu-ragged-env.cmd')],encoding='utf8',errors='replace')
env={k.upper():v for k,v in os.environ.items()};env.update((k.upper(),v) for k,v in (x.split('=',1) for x in setup.splitlines() if '=' in x and not x.startswith('=')))
env['VSLANG']='1033';started=time.monotonic();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
r={'state':'SETUP','stages':[],'source_record_sha256':sha(out/'source-record.json'),'source_driver_sha256':sha(out/'driver.cc'),'max_jobs':4,'logical_cpu_limit':4,'priority':'BELOW_NORMAL','product_or_facade_rebuilds':0}
def save():
 r['elapsed_seconds']=time.monotonic()-started;(out/'build-result.json').write_text(json.dumps(r,indent=2)+'\n',encoding='utf8')
def run(stage,args):
 stamp=time.monotonic();r.update(state='RUNNING',stage=stage);save()
 with (out/(stage+'.log')).open('wb') as log:
  p=subprocess.Popen([str(x) for x in args],cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NO_WINDOW|subprocess.BELOW_NORMAL_PRIORITY_CLASS)
  get=ctypes.windll.kernel32.GetProcessAffinityMask;get.argtypes=[ctypes.c_void_p,ctypes.POINTER(ctypes.c_size_t),ctypes.POINTER(ctypes.c_size_t)]
  setmask=ctypes.windll.kernel32.SetProcessAffinityMask;setmask.argtypes=[ctypes.c_void_p,ctypes.c_size_t]
  available=ctypes.c_size_t();system=ctypes.c_size_t();handle=ctypes.c_void_p(int(p._handle));assert get(handle,ctypes.byref(available),ctypes.byref(system))
  assert setmask(handle,sum([1<<i for i in range(64) if available.value&(1<<i)][:4]))
  r['child_pid']=p.pid;save()
  while True:
   try:code=p.wait(timeout=1800);break
   except subprocess.TimeoutExpired:r.setdefault('time_extensions',[]).append({'stage':stage,'pid':p.pid,'seconds':1800});save()
 r.pop('child_pid',None);r['stages'].append({'stage':stage,'command':[str(x) for x in args],'exit_code':code,'elapsed_seconds':time.monotonic()-stamp});save();assert code==0,(out/(stage+'.log')).read_text(errors='replace')[-5000:]
try:
 run('configure',['cmake','-S',out,'-B',build,'-G','Ninja','-DCMAKE_BUILD_TYPE=Release','-DCMAKE_EXPORT_COMPILE_COMMANDS=ON'])
 commands=json.loads((build/'compile_commands.json').read_text(encoding='utf8'));assert len(commands)==2
 assert {Path(row['file']).name for row in commands}=={'driver.cc','nanobench_impl.cc'}
 assert all('/src/' not in row['file'].replace('\\','/') and (root/'include').as_posix() not in row['command'].replace('\\','/') for row in commands)
 (out/'compile-commands.json').write_text(json.dumps(commands,indent=2)+'\n',encoding='utf8')
 run('build',['cmake','--build',build,'-j','4'])
 binary=Path('C:/h7/g09-p1/cuda-candidate/bin/g09_pipeline_driver_process_lifetime.exe');assert binary.is_file()
 cache=(build/'CMakeCache.txt').read_text(encoding='utf8');compiler=Path(next(x.split('=',1)[1] for x in cache.splitlines() if x.startswith('CMAKE_CXX_COMPILER:')))
 run('imports',[compiler.with_name('dumpbin.exe'),'/nologo','/imports',binary])
 imports=(out/'imports.log').read_text(encoding='utf8',errors='replace');assert '@hyle@' not in imports and 'g09_cuda_' not in imports and 'FreeLibrary' not in imports
 r.update(state='DRIVER_ONLY_PROCESS_LIFETIME_CORRECTION_BUILT_NO_HYLE_PRODUCT_LINK_OR_EXECUTION',driver={'path':str(binary),'sha256':sha(binary),'bytes':binary.stat().st_size});save();print(json.dumps(r,indent=2))
except BaseException as error:r.update(state='FAIL',error=repr(error));save();raise
