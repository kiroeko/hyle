from pathlib import Path
import hashlib,json,subprocess,sys,zipfile

root=Path('C:/public/project-hyle/hyle');draft=root/'.scratch/inference-gaps/g09-p1-draft'
folder=root/'.scratch/inference-gaps/g09-p1-air-upload';folder.mkdir(parents=True,exist_ok=True)
remote='/Users/kiro/hyle-scratch/compute-unified/g09-p1-inputs'
sha=lambda data:hashlib.sha256(data).hexdigest()
files={}
for p in sorted(draft.glob('*')):
 if p.is_file():files['consumer/'+p.name]=p.read_bytes()
for name in ['bench/nanobench_impl.cc','bench/common/perf_process.h','third_party/nanobench/nanobench.h']:
 files['canonical-instrument/'+name]=(root/name).read_bytes()
for route in ['apple','vulkan']:
 p=root/f'.scratch/inference-gaps/g08-p1-draft/qualified-sdk-{route}.json';files[p.name]=p.read_bytes()
files['g09_p1_build_air.py']=(root/'.scratch/inference-gaps/g09_p1_build_air.py').read_bytes()
manifest={'source_snapshot':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),
 'files':[{'path':p,'sha256':sha(data),'bytes':len(data)} for p,data in sorted(files.items())]}
with zipfile.ZipFile(folder/'inputs.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p,data in sorted(files.items()):z.writestr(p,data)
 z.writestr('upload.json',json.dumps(manifest,indent=2)+'\n')
subprocess.run(['ssh','kiro@172.22.10.198','mkdir','-p',remote],check=True)
subprocess.run(['scp',str(folder/'inputs.zip'),'kiro@172.22.10.198:'+remote+'/inputs.zip'],check=True)
subprocess.run(['ssh','kiro@172.22.10.198','python3','-m','zipfile','-e',remote+'/inputs.zip',remote],check=True)
subprocess.run(['ssh','kiro@172.22.10.198','python3',remote+'/g09_p1_build_air.py',*sys.argv[1:]],check=True)
