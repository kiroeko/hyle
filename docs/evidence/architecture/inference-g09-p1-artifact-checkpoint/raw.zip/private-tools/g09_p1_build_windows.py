from pathlib import Path
import ctypes,hashlib,json,os,re,subprocess,sys,time,zipfile
root=Path('C:/public/project-hyle/hyle');route,kind=sys.argv[1:3]
resume='--resume-inspect' in sys.argv[3:]
assert route in ['cuda','vulkan'] and kind in ['baseline','candidate']
qualified=json.loads((root/'evidence/delivery/inference-g09-windows-sdk-checkpoint/receipt.json').read_text())
assert qualified['state']=='SIX_WINDOWS_DELIVERIES_PUBLIC_CONSUMERS_HEADERS_STAGED_IMPORTS_PASS'
source=root/'.scratch/inference-gaps/g09-p1-draft'
ledger=json.loads((source/'phase-ledger.json').read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for item in ledger['source_files']:assert sha(source/item['path'])==item['sha256']
with zipfile.ZipFile(root/'evidence/architecture/inference-g09-p1-consumer-source/raw.zip') as z:
 for item in ledger['source_files']:assert z.read('source/'+item['path'])==(source/item['path']).read_bytes()
prefix=Path('C:/h7')/('g08-sdk' if kind=='baseline' else 'g09-sdk')/f'{route}-static-1/relocated'
assert prefix.is_dir()
build=Path('C:/h7/g09-p1')/f'{route}-{kind}'
out=root/'.scratch/inference-gaps/g09-p1-builds'/f'windows-{route}-{kind}'
review_path=root/'.scratch/inference-gaps/g09-pe-vendor-export-review-13.json'
assert sha(review_path)=='3612325962ad2575e7a5b096a112624393edc72d59545f12c6bb58d0c7abf291'
review=json.loads(review_path.read_text())
vendor_names=review['actual_exports']['vendor_symbol_allowlist'] if route=='cuda' else []
if vendor_names:
 assert len(vendor_names)==77
 assert hashlib.sha256(('\n'.join(sorted(vendor_names))+'\n').encode()).hexdigest()==review['actual_exports']['exact_vendor_name_set_sha256']
 assert sha(prefix/'lib/hyle_compute_provider_native.lib')==review['sdk_archive_object_provenance']['both_actual_archive_sha256']
prior=None;prior_elapsed=0
if resume:
 assert route=='cuda' and kind=='baseline' and build.is_dir()
 original=out/'initial-strict-export-failure.json'
 if not original.exists():original.write_bytes((out/'result.json').read_bytes())
 assert sha(original)==review['original_failure']['sha256']
 prior=json.loads((out/'result.json').read_text());assert prior['state']=='SETUP_FAIL' and all(x['exit_code']==0 for x in prior['stages'])
 for item in review['actual_images']:assert sha(Path(item['path']))==item['sha256']
 attempt=1+len(list(out.glob('inspection-before-*.json')))
 (out/f'inspection-before-{attempt}.json').write_bytes((out/'result.json').read_bytes())
 prior_elapsed=prior['elapsed_seconds']
else:
 assert not build.exists();out.mkdir(parents=True,exist_ok=False)
setup=subprocess.check_output(['cmd','/d','/c',str(root/'.scratch/inference-gaps/g01/cpu-ragged-env.cmd')],encoding='utf8',errors='replace')
env={k.upper():v for k,v in os.environ.items()};env.update((k.upper(),v) for k,v in (x.split('=',1) for x in setup.splitlines() if '=' in x and not x.startswith('=')))
env['VSLANG']='1033';env['HYLE_VULKAN_VALIDATION']='0'
cuda=Path('C:/Program Files/NVIDIA GPU Computing Toolkit/CUDA/v13.3');vk=Path('C:/public/tools/hyle-vulkan/1.4.357.0')
env['PATH']=str(cuda/'bin' if route=='cuda' else vk/'Bin')+';'+env['PATH']
if route=='vulkan':env['VULKAN_SDK']=str(vk)
ctypes.windll.kernel32.SetErrorMode(0x0001|0x0002|0x8000)
started=time.monotonic();jobs=2 if route=='cuda' else 4
r={'state':'SETUP','pid':os.getpid(),'route':route,'image_set':kind,'prefix':str(prefix),'build':str(build),'stages':[],
   'candidate':ledger['candidate'],'baseline':ledger['baseline'],'product_code_commit':ledger['product'],
   'source_files':ledger['source_files'],'phase_ledger_sha256':sha(source/'phase-ledger.json'),'max_jobs':jobs,
   'scope':'Build only two private public-consumer facade images against one already qualified static SDK and original-instrument driver for candidate. No HYLE product source/native kernel compilation, diagnostic/A-A/P1 sampling or automatic artifact qualification.'}
if resume:
 r=prior;r.pop('error',None)
 r['initial_failure']={'path':'initial-strict-export-failure.json','sha256':review['original_failure']['sha256'],'elapsed_seconds':review['original_failure']['retained_elapsed_seconds']}
 r['resume_scope']='Inspection of identical two already linked images only; no configure, compile, relink, or sampling.'
r['vendor_export_review']={'path':str(review_path),'sha256':sha(review_path),'exact_exception_count':len(vendor_names)}

def save():
 r['elapsed_seconds']=prior_elapsed+time.monotonic()-started;(out/'result.json').write_text(json.dumps(r,indent=2)+'\n',encoding='utf8')

def run(stage,args):
 if resume:stage='resume-inspect-'+stage
 stamp=time.monotonic();r.update(state='RUNNING',stage=stage);save();print(route,kind,stage,flush=True)
 with (out/(stage+'.log')).open('wb') as log:
  p=subprocess.Popen([str(x) for x in args],cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NO_WINDOW|subprocess.BELOW_NORMAL_PRIORITY_CLASS)
  get=ctypes.windll.kernel32.GetProcessAffinityMask;get.argtypes=[ctypes.c_void_p,ctypes.POINTER(ctypes.c_size_t),ctypes.POINTER(ctypes.c_size_t)]
  setmask=ctypes.windll.kernel32.SetProcessAffinityMask;setmask.argtypes=[ctypes.c_void_p,ctypes.c_size_t]
  available=ctypes.c_size_t();system=ctypes.c_size_t();handle=ctypes.c_void_p(int(p._handle))
  if not get(handle,ctypes.byref(available),ctypes.byref(system)):p.terminate();p.wait();raise OSError('cannot read affinity')
  mask=sum([1<<i for i in range(64) if available.value&(1<<i)][:4])
  if not setmask(handle,mask):p.terminate();p.wait();raise OSError('cannot bound affinity')
  r.update(child_pid=p.pid,priority='BELOW_NORMAL',logical_cpu_limit=4,affinity_mask=hex(mask));save()
  while True:
   try:code=p.wait(timeout=1800);break
   except subprocess.TimeoutExpired:r.setdefault('time_extensions',[]).append({'stage':stage,'pid':p.pid,'seconds':1800});save()
 r.pop('child_pid',None);r['stages'].append({'stage':stage,'command':[str(x) for x in args],'exit_code':code,'elapsed_seconds':time.monotonic()-stamp});save()
 if code:r['state']='FAIL';save();print((out/(stage+'.log')).read_text(errors='replace')[-14000:],flush=True);raise SystemExit(code)

try:
 r['source_snapshot']=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
 subprocess.run(['git','diff','--exit-code',r['candidate'],'--','src','include','cmake','CMakeLists.txt','bench/nanobench_impl.cc','third_party/nanobench','bench/common/perf_process.h'],cwd=root,check=True,stdout=subprocess.DEVNULL)
 sdk_files=[{'path':p.relative_to(prefix).as_posix(),'sha256':sha(p),'bytes':p.stat().st_size} for p in sorted(prefix.rglob('*')) if p.is_file()]
 if resume:assert sdk_files==r['sdk_files']
 else:r['sdk_files']=sdk_files
 r['instrument_files']=[{'path':x,'sha256':sha(root/x)} for x in ['bench/nanobench_impl.cc','third_party/nanobench/nanobench.h','bench/common/perf_process.h']]
 r['identity']={'host':env.get('COMPUTERNAME'),'compiler':env.get('VCTOOLSVERSION'),'gpu':subprocess.check_output(['nvidia-smi','--query-gpu=name,uuid,driver_version','--format=csv,noheader'],env=env,text=True).strip()}
 (out/('runner-resume-inspect.py' if resume else 'runner.py')).write_bytes(Path(__file__).read_bytes());save()
 args=['cmake','-S',source.as_posix(),'-B',build.as_posix(),'-G','Ninja','-DCMAKE_BUILD_TYPE=Release','-DCMAKE_EXPORT_COMPILE_COMMANDS=ON',
       '-DCMAKE_PREFIX_PATH='+prefix.as_posix(),'-DG09_SOURCE='+root.as_posix(),'-DG09_ROUTE='+route,'-DG09_IMAGE_SET='+kind,'-DG09_BUILD_DRIVER='+('ON' if kind=='candidate' else 'OFF')]
 if route=='cuda':args+=['-DCUDAToolkit_ROOT='+cuda.as_posix()]
 if not resume:run('configure',args);run('manifest',['ninja','-C',build,'build.ninja'])
 targets=[f'g09_{route}_{kind}_1',f'g09_{route}_{kind}_2']+(['g09_pipeline_driver'] if kind=='candidate' else [])
 dry=subprocess.check_output(['ninja','-C',str(build),'-n',*targets],env=env,text=True,encoding='utf8',errors='replace');(out/('resume-dry-run.log' if resume else 'dry-run.log')).write_text(dry,encoding='utf8')
 if resume:
  # Public stager is an always-run copy target. It is not executed here.
  lines=dry.splitlines();expected=f'cmake.exe" -P {build.as_posix()}/hyle-runtime/g09_{route}_{kind}_runtime_probe-Release.cmake'
  assert len(lines)==2 and ('no work to do' in lines[1] or ('[1/1]' in lines[1] and expected in lines[1])),dry
 assert len(dry.splitlines())<40 and 'Building CUDA object' not in dry and 'Re-running CMake' not in dry,dry
 commands=json.loads((build/'compile_commands.json').read_text());assert len(commands)==(5 if kind=='candidate' else 3),len(commands)
 for item in commands:
  command=item['command'].replace('\\','/');assert '/src/' not in item['file'].replace('\\','/') and (root/'src').as_posix() not in command
  assert 'HYLE_TESTING' not in command and '-fsanitize=' not in command
  if Path(item['file']).name=='facade.cc':assert (prefix/'include').as_posix() in command and (root/'include').as_posix() not in command
 (out/'compile-commands.json').write_text(json.dumps(commands,indent=2)+'\n',encoding='utf8')
 if not resume:run('build',['ninja','-C',build,'-j',str(jobs),*targets])
 cache=(build/'CMakeCache.txt').read_text();compiler=Path(next(x.split('=',1)[1] for x in cache.splitlines() if x.startswith('CMAKE_CXX_COMPILER:')));dumpbin=compiler.with_name('dumpbin.exe')
 component_dlls={('hyle_'+x['module']+'.dll').lower() for x in json.loads((root/'docs/implementation/module-status.json').read_text())['modules']}
 r['images']=[]
 for copy in [1,2]:
  name=f'g09_{route}_{kind}_{copy}';binary=build/'bin'/(name+'.dll');assert binary.is_file()
  for option in ['exports','imports','headers','dependents']:run(name+'-'+option,[dumpbin,'/nologo','/'+option,binary])
  stem=('resume-inspect-' if resume else '')+name
  exports=(out/(stem+'-exports.log')).read_text(errors='replace')
  names=re.findall(r'^\s+\d+\s+[0-9A-F]+\s+[0-9A-F]+\s+(\S+)',exports,re.M)
  assert sorted(names)==sorted(['hyle_g09_facade_v1',*vendor_names]),names
  assert not re.search(r'forwarded to|\s=\s',exports,re.I),exports
  imports=(out/(stem+'-imports.log')).read_text(errors='replace')
  assert not re.search(r'@hyle@@|@hyle@',imports),imports[-3000:]
  dependencies=(out/(stem+'-dependents.log')).read_text(errors='replace')
  dlls=re.findall(r'^\s+([^\s]+\.dll)\s*$',dependencies,re.M|re.I)
  assert not any(x.lower() in component_dlls for x in dlls),dlls
  assert not any(x.lower().startswith('g09_') for x in dlls),dlls
  mapfile=build/(name+'.map');assert mapfile.is_file();(out/mapfile.name).write_bytes(mapfile.read_bytes())
  maplines=mapfile.read_text(errors='replace').splitlines()
  for symbol in vendor_names:
   matching=[line for line in maplines if len(line.split())>=2 and line.split()[1]==symbol]
   assert len(matching)==1 and 'hyle_compute_provider_native:aten_cpu_provider.cc.obj' in matching[0],(symbol,matching)
  r['images'].append({'path':str(binary),'sha256':sha(binary),'bytes':binary.stat().st_size,'exports':names,'direct_import_dlls':dlls,'map_sha256':sha(mapfile)})
 if kind=='candidate':
  driver=build/'bin/g09_pipeline_driver.exe';r['driver']={'path':str(driver),'sha256':sha(driver),'bytes':driver.stat().st_size}
 for item in ledger['source_files']:assert sha(source/item['path'])==item['sha256']
 r['state']='TWO_PRIVATE_IMAGES_BUILT_EXPORT_IMPORT_INITIAL_CHECKS_PASS_NOT_FINAL_ARTIFACT_QUALIFICATION';save();print(r['state'],flush=True)
except BaseException as error:
 if r['state']!='FAIL':r.update(state='SETUP_FAIL',error=repr(error));save()
 raise
