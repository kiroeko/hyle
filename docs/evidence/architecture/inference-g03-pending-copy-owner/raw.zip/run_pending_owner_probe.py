from pathlib import Path
import hashlib,json,subprocess,zipfile

root=Path(__file__).resolve().parents[3]
work=root/'.scratch/inference-gaps/g03/pending-owner-probe';work.mkdir(exist_ok=True)
script=work/'pending_owner_air.py'
text=(work.parent/'native_producer_shape_air.py').read_text()
text=text.replace('g03-native-producer-shape','g03-pending-owner-probe')
text=text.replace('g03_native_producer_shape','g03_pending_copy_owner')
text=text.replace('tests/compute_batch/native_producer_copy_shape_probe.cc','tests/compute_batch/pending_copy_owner_probe.cc')
text=text.replace('PRIVATE hyle::compute','PRIVATE hyle::graph')
text=text.replace('cfb883a3bb819cb171325daecc42dfe60f0733bd','f764a1053')
text=text.replace('SCOPED public probe; product unchanged b42832de3ddda21bdc3e98ad4cc87e73622cbba4','SCOPED prototype; product fixed dab23ba92256cad21f2e83af6141eb8ad51264c5')
text=text.replace('actual two ready Apple ABS outputs -> readonly export -> original F2 copy; fixed resource identity qualification; not complete pending page attention','actual pending Apple copy ownership handoff of original invocation/submission; five lifecycle modes; no pending attention claim')
script.write_text(text)
paths=['tests/compute_batch/pending_copy_owner_probe.cc',
       'tests/compute_batch/dirty_page_native_risk_fixture.h',
       'tests/compute_batch/native_paged_risk_fixture.h',
       'tests/compute_batch/native_apple_failure_fixture.h']
number=1
while (work/f'input-{number}.zip').exists(): number+=1
archive=work/f'input-{number}.zip';manifest=[]
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as package:
 for path in paths:
  data=(root/path).read_bytes();manifest.append({'path':path,'sha256':hashlib.sha256(data).hexdigest()})
  package.writestr(path,data)
 package.writestr('input-manifest.json',json.dumps(manifest,indent=2)+'\n')
host='kiro@172.22.10.198';remote='/Users/kiro/hyle-scratch/compute-unified/g03-pending-owner-probe'
subprocess.run(['ssh','-o','BatchMode=yes','-o','ConnectTimeout=10',host,'mkdir -p '+remote],check=True)
subprocess.run(['scp','-o','BatchMode=yes','-o','ConnectTimeout=10',str(archive),str(script),f'{host}:{remote}/'],check=True)
result=subprocess.run(['ssh','-o','BatchMode=yes','-o','ConnectTimeout=10',host,f'python3 {remote}/{script.name} {archive.name} apple'])
subprocess.run(['scp','-o','BatchMode=yes','-o','ConnectTimeout=10',f'{host}:{remote}/result.json',f'{host}:{remote}/job.json',str(work)],check=True)
raise SystemExit(result.returncode)
