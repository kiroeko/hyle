from pathlib import Path
import json,re
root=Path('/mnt/c/public/project-hyle/hyle');r=json.loads((root/'.scratch/inference-gaps/g04-g05/ce28-fixed-codegen-1/result.json').read_text());p=Path(r['header']);lines=p.read_text().splitlines()
for i,line in enumerate(lines):
 if re.search(r'(HYLE_FP8_DIRECT_STAGE|hyle_owned_fp8|hyle_.*convert|fast_dequant|cvt_fp8|float\(\*|vec_cast<)',line):print(i+1,line[:170])
for label in ['void produce_kv(', 'void produce_paged_kv(', 'hyle_fp8_decode', 'hyle_decode']:
 found=next((i for i,x in enumerate(lines) if label in x),None)
 if found is not None:
  print('FUNCTION',label);print('\n'.join(str(i+1)+': '+lines[i] for i in range(found,min(found+95,len(lines)))))
