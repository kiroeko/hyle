from pathlib import Path
import hashlib,json,os,shlex,subprocess,time
root=Path('/mnt/c/public/project-hyle/hyle');out=root/'.scratch/inference-gaps/g04-g05/c1-packed-conversion-1'
probe=json.loads((out/'probe.json').read_text());work=Path(probe['work'])/'product-leaf';work.mkdir(exist_ok=False)
sdk=Path('/root/hyle-scratch/compute-unified/g06-final-sdk/cuda-static-1/relocated');producer=Path('/root/hyle-scratch/compute-unified/l-cpu-cuda/selected-graph/static-sdk-build')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
archive=sdk/'lib/libhyle_compute_provider_flashinfer.a'
members=subprocess.check_output(['ar','t',str(archive)],text=True).splitlines();assert members.count('native_cache.cu.o')==1
control=work/'native_cache_control.o';control.write_bytes(subprocess.check_output(['ar','p',str(archive),'native_cache.cu.o']))
database=json.loads(subprocess.check_output(['ninja','-C',str(producer),'-t','compdb'],text=True));commands=[x for x in database if x.get('file','').endswith('/src/compute_provider_flashinfer/native_cache.cu')];assert len(commands)==1
original=commands[0];args=shlex.split(original['command']);source=Path(original['file'])
assert sha(source)==sha(root/'src/compute_provider_flashinfer/native_cache.cu')
includes=[x[2:] for x in args if x.startswith('-I') and '/cache-source-' in x and x.endswith('/include')];assert len(includes)==1
old_include=includes[0];assert sha(Path(old_include)/'flashinfer/vec_dtypes.cuh')==probe['original_vec_sha256']
assert sha(Path(old_include)/'flashinfer/attention/prefill.cuh')==json.loads((root/'.scratch/inference-gaps/g04-g05/ce28-fixed-codegen-1/result.json').read_text())['header_sha256']
candidate=work/'native_cache_packed.o';args[args.index('-o')+1]=str(candidate)
for flag,value in [('-MF',str(work/'native_cache_packed.d')),('-MT',str(candidate))]:
 if flag in args:args[args.index(flag)+1]=value
args[args.index('-I'+old_include)]='-I'+str(Path(probe['work'])/'include')
base=Path('/root/hyle-scratch/compute-unified/g04-causal-counterfactual-1')
for relative in ['bench/inference_resident_sdpa/cuda_encoded_page_bench.cc','bench/common/perf_process.h']:
 target=work/relative;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes((base/relative).read_bytes())
for relative in ['bench/inference_resident_sdpa/cuda_encoded_page_reference.cc','bench/inference_resident_sdpa/cuda_encoded_page_reference.h','bench/inference_resident_sdpa/cuda_encoded_page_native.h']:
 (work/relative).write_bytes((root/relative).read_bytes())
oldbuild=Path('/root/hyle-scratch/compute-unified/g04-ce28-producer-stage-build-1')
cmake='''cmake_minimum_required(VERSION 3.25)
project(c1_product_leaf LANGUAGES C CXX)
find_package(Hyle CONFIG REQUIRED COMPONENTS compute graph)
foreach(mode IN ITEMS control packed)
 add_executable(product_${mode} bench/inference_resident_sdpa/cuda_encoded_page_bench.cc bench/inference_resident_sdpa/cuda_encoded_page_reference.cc "${CMAKE_CURRENT_SOURCE_DIR}/native_cache_${mode}.o")
 target_compile_features(product_${mode} PRIVATE cxx_std_23)
 target_include_directories(product_${mode} PRIVATE "@ROOT@/src/compute_backend_cuda" "/usr/local/cuda-13.3/include" "@ROOT@/third_party/nanobench")
 target_compile_options(product_${mode} PRIVATE -Wall -Wextra -Wpedantic -Werror)
 target_link_libraries(product_${mode} PRIVATE hyle::compute "@OLD@/original-peer/libg04_cuda_encoded_original.a" "@OLD@/original-peer/libg04_cuda_encoded_nanobench.a" CUDA::cudart dl)
 set_property(TARGET product_${mode} PROPERTY INTERPROCEDURAL_OPTIMIZATION FALSE)
 hyle_stage_runtime(product_${mode})
endforeach()
'''.replace('@ROOT@',str(root)).replace('@OLD@',str(oldbuild));(work/'CMakeLists.txt').write_text(cmake)
r={'state':'DIRECT_PRODUCT_LEAF_SETUP','work':str(work),'original_compile_record':original,'candidate_command':args,'archive':{'path':str(archive),'sha256':sha(archive)},'actual_archive_member':{'path':str(control),'sha256':sha(control)},'source':{'path':str(source),'sha256':sha(source)},'candidate_vec_sha256':probe['candidate_vec_sha256'],'stages':[]}
save=lambda:(out/'product-build.json').write_text(json.dumps(r,indent=2)+'\n')
env=os.environ.copy();env['PATH']='/usr/local/cuda-13.3/bin:'+env['PATH']
for label,command,cwd in [('one-product-native-tuple',args,str(producer)),('consumer-configure',['cmake','-S',str(work),'-B',str(work/'build'),'-G','Ninja','-DCMAKE_CXX_COMPILER=g++-14','-DCMAKE_C_COMPILER=gcc-14','-DCMAKE_BUILD_TYPE=Release','-DCMAKE_PREFIX_PATH='+str(sdk)],str(work)),('consumer-build',['cmake','--build',str(work/'build'),'--parallel','2','--target','product_control','product_packed'],str(work))]:
 start=time.monotonic()
 with (out/(label+'.log')).open('w') as f:
  child=subprocess.Popen(command,cwd=cwd,env=env,stdout=f,stderr=subprocess.STDOUT);r.update(state='RUNNING',active_stage=label,pid=child.pid);save();print(label,child.pid,flush=True);code=child.wait()
 r['stages'].append(dict(stage=label,command=command,exit=code,seconds=time.monotonic()-start));save()
 if code:r['state']='SETUP_FAIL';save();raise RuntimeError(label+' failed')
assert sha(archive)==r['archive']['sha256'] and sha(Path(old_include)/'flashinfer/vec_dtypes.cuh')==probe['original_vec_sha256']
r['builds']=[{'mode':mode,'binary':{'path':str(work/'build'/('product_'+mode)),'sha256':sha(work/'build'/('product_'+mode))}} for mode in ['control','packed']]
r['candidate_object_sha256']=sha(candidate);r['state']='DIRECT_PRODUCT_LEAF_BUILT';r.pop('pid',None);r.pop('active_stage',None);save();print(r['state'],flush=True)
