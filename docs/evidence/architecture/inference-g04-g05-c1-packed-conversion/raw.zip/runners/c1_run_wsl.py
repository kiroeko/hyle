from pathlib import Path
import hashlib,json,os,re,subprocess,time
root=Path('/mnt/c/public/project-hyle/hyle');out=root/'.scratch/inference-gaps/g04-g05/c1-packed-conversion-1'
build=json.loads((out/'math-build.json').read_text());assert build['state']=='C1_CONTROL_AND_CANDIDATE_BUILT'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
env=os.environ.copy();env['CUDA_VISIBLE_DEVICES']='0';available=os.sched_getaffinity(0);cpu=2 if 2 in available else min(available);os.sched_setaffinity(0,{cpu})
for key in ['HYLE_PERF_CALLER_CPU','HYLE_DIAG_TRACE','HYLE_DIAG_MATRIX','HYLE_CAUSAL_VARIANT','HYLE_BENCH_VERIFY_ONLY','HYLE_BENCH_AA_ROUTE','HYLE_BENCH_RIVAL_FIRST','HYLE_BENCH_PEER_ALLOCATION_FIRST','HYLE_PERF_RUN_NONCE']:env.pop(key,None)
r={'state':'C1_SETUP','cpu':cpu,'experiments':[],'commands':[]}
save=lambda:(out/'run.json').write_text(json.dumps(r,indent=2)+'\n')
def run(name,command,changes):
 local=env.copy();local.update(changes);start=time.monotonic()
 with (out/(name+'.log')).open('w') as f:
  child=subprocess.Popen(command,env=local,stdout=f,stderr=subprocess.STDOUT);r.update(state='RUNNING',active_stage=name,pid=child.pid);save();print(name,child.pid,flush=True);code=child.wait()
 row=dict(name=name,command=command,environment=changes,exit=code,seconds=time.monotonic()-start);r['commands'].append(row);save()
 if code:r['state']='TERMINAL_FAIL';save();raise RuntimeError(name+' failed')
 return (out/(name+'.log')).read_text()
for b in build['builds']:
 mode=b['mode'];binary=Path(b['binary']['path']);assert sha(binary)==b['binary']['sha256']
 text=run(mode+'-oracle',[str(binary)],{'HYLE_BENCH_VERIFY_ONLY':'1'})
 errors=[float(x) for x in re.findall(r'CORRECTNESS max_abs_error=([^ ]+)',text)];assert len(errors)==8 and max(errors)<=8e-3
 e={'mode':mode,'variant':mode,'binary':b['binary'],'oracle_max_abs_error':max(errors),'controls':[]};r['experiments'].append(e);save()
 text=run(mode+'-memcheck',['/usr/local/cuda-13.3/bin/compute-sanitizer','--tool','memcheck','--error-exitcode','86',str(binary)],{'HYLE_BENCH_VERIFY_ONLY':'1'})
 assert 'ERROR SUMMARY: 0 errors' in text;e['memcheck']='PASS';save()
 for route in ['selected','native','AB']:
  for alloc in range(2):
   for order in range(2):
    changes={}
    if route!='AB':changes['HYLE_BENCH_AA_ROUTE']=route
    if alloc:changes['HYLE_BENCH_PEER_ALLOCATION_FIRST']='1'
    if order:changes['HYLE_BENCH_RIVAL_FIRST']='1'
    text=run(mode+'-'+route+'-a'+str(alloc)+'-o'+str(order),[str(binary)],changes)
    errors=[float(x) for x in re.findall(r'CORRECTNESS max_abs_error=([^ ]+)',text)];assert len(errors)==10 and max(errors)<=8e-3
    rows=[dict(group=int(x[0]),candidate_us=float(x[1]),peer_us=float(x[2])) for x in re.findall(r'CAUSAL_DIAG shape=prefill group=(\d+) trace=0 candidate_us=([^ ]+) peer_us=([^\n]+)',text)];assert len(rows)==8
    e['controls'].append(dict(route=route,allocation=alloc,order=order,groups=rows));save()
 report=binary.parent.parent/('c1-'+mode)
 text=run(mode+'-timeline',['nsys','profile','--trace=cuda,nvtx','--sample=none','--cpuctxsw=none','--export=sqlite','--force-overwrite=false','--output='+str(report),str(binary)],{'HYLE_DIAG_TRACE':'1','HYLE_DIAG_MATRIX':'1'})
 errors=[float(x) for x in re.findall(r'CORRECTNESS max_abs_error=([^ ]+)',text)];assert len(errors)==40 and max(errors)<=8e-3
 e['timeline']={'sqlite':str(report.with_suffix('.sqlite')),'sha256':sha(report.with_suffix('.sqlite')),'report':str(report.with_suffix('.nsys-rep'))};save()
 assert sha(binary)==b['binary']['sha256']
r.update(state='C1_CONTROL_AND_CANDIDATE_CAPTURED_NOT_P1');r.pop('pid',None);r.pop('active_stage',None);save();print(r['state'],flush=True)
