from pathlib import Path
import datetime, hashlib, json, re, time, zipfile

root = Path('/mnt/c/public/project-hyle/hyle')
out = root / '.scratch/inference-gaps/g04-g05/c1-packed-conversion-1'
dest = root / 'evidence/architecture/inference-g04-g05-c1-packed-conversion'
dest.mkdir(exist_ok=True)
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
load = lambda name: json.loads((out / name).read_text())
probe, cropped_build, direct_build = [load(n) for n in ['probe.json', 'math-build.json', 'product-build.json']]
cropped_run, direct_run = [load(n) for n in ['run.json', 'direct/run.json']]
cropped_sass, direct_sass = [load(n) for n in ['sass.json', 'direct/sass.json']]
cropped_analysis, direct_analysis = [load(n) for n in ['analysis.json', 'direct/analysis.json']]
assert probe['state'] == 'C1_ALL_CODES_BIT_EXACT'
assert direct_build['state'] == 'DIRECT_PRODUCT_LEAF_BUILT'
assert all(r['state'] == 'C1_CONTROL_AND_CANDIDATE_CAPTURED_NOT_P1' for r in [cropped_run, direct_run])
assert 'words=70656 outputs=282624 paired_combinations=65536 bit_mismatch=0 finite_oracle_mismatch=0 special_observations=5160' in (out / 'codes.log').read_text()
work = Path(probe['work'])
original_vec = Path(probe['original_include']) / 'flashinfer/vec_dtypes.cuh'
candidate_vec = work / 'include/flashinfer/vec_dtypes.cuh'
assert sha(original_vec) == probe['original_vec_sha256']
assert sha(candidate_vec) == probe['candidate_vec_sha256']
assert sha(Path(direct_build['archive']['path'])) == direct_build['archive']['sha256']
assert sha(Path(direct_build['source']['path'])) == direct_build['source']['sha256']
assert sha(root / 'src/compute_provider_flashinfer/native_cache.cu') == direct_build['source']['sha256']
deps = work / 'product-leaf/native_cache_packed.d'
assert candidate_vec.resolve() in [Path(s).resolve() for s in re.findall(r'\S*vec_dtypes\.cuh', deps.read_text())]
for run in [cropped_run, direct_run]:
    for e in run['experiments']:
        assert e['memcheck'] == 'PASS' and e['oracle_max_abs_error'] <= 8e-3
        assert len(e['controls']) == 12
        assert sha(Path(e['binary']['path'])) == e['binary']['sha256']
        assert sha(Path(e['timeline']['sqlite'])) == e['timeline']['sha256']
assert direct_run['experiments'][1]['racecheck'] == 'PASS'
kernel = lambda experiment, route: next(k for k in experiment['kernels'] if k['route'] == route)
actual_control = kernel(direct_sass['experiments'][0], 'current')
sdk_control = kernel(cropped_sass['experiments'][0], 'current')
assert actual_control['normalized_sass_sha256'] == sdk_control['normalized_sass_sha256']
assert kernel(direct_sass['experiments'][0], 'peer')['normalized_sass_sha256'] == kernel(direct_sass['experiments'][1], 'peer')['normalized_sass_sha256']
old, new = direct_analysis['experiments']
rows = []
for a, b in zip(old['summary'], new['summary']):
    assert a['case'] == b['case']
    get = lambda r, side: r['sides'][side]['attention']['median_us']
    rows.append(dict(case=a['case'], control_attention_us=get(a, 'candidate'), packed_attention_us=get(b, 'candidate'),
                     control_peer_us=get(a, 'peer'), packed_peer_us=get(b, 'peer'),
                     raw_attention_delta_us=get(b, 'candidate') - get(a, 'candidate'),
                     peer_normalized_packed_over_control=(get(b, 'candidate') / get(b, 'peer')) / (get(a, 'candidate') / get(a, 'peer'))))
assert len(rows) == 4 and all(x['peer_normalized_packed_over_control'] > 1 for x in rows)
raw = []
for p in sorted(out.rglob('*')):
    if p.is_file(): raw.append((p, 'private-records/' + p.relative_to(out).as_posix()))
for p in sorted((root / '.scratch/inference-gaps/g04-g05').glob('c1_*.py')):
    raw.append((p, 'runners/' + p.name))
raw += [(original_vec, 'headers/original/vec_dtypes.cuh'), (candidate_vec, 'headers/packed/vec_dtypes.cuh'),
        (Path(probe['original_include']) / 'flashinfer/attention/prefill.cuh', 'headers/unchanged/prefill.cuh'),
        (work / 'probe.cu', 'sources/probe.cu'), (deps, 'sources/direct/native_cache_packed.d'),
        (root / 'src/compute_provider_flashinfer/native_cache.cu', 'sources/product/native_cache.cu'),
        (root / 'src/compute_provider_flashinfer/native_batch.h', 'sources/product/native_batch.h')]
for label, folder in [('cropped-control', work / 'control'), ('cropped-packed', work / 'packed'), ('direct', work / 'product-leaf')]:
    for p in sorted(folder.rglob('*')):
        if p.is_file() and (p.name == 'CMakeLists.txt' or p.is_relative_to(folder / 'bench')):
            raw.append((p, 'sources/' + label + '/' + p.relative_to(folder).as_posix()))
for label, run in [('cropped', cropped_run), ('direct', direct_run)]:
    for e in run['experiments']:
        for key in ['sqlite', 'report']:
            p = Path(e['timeline'][key]); raw.append((p, 'profiles/' + label + '/' + e['mode'] + '/' + p.name))
contract_sources = ['bench/inference_resident_sdpa/cuda_encoded_p1/contract.json',
                    'bench/inference_resident_sdpa/cuda_encoded_p1/consumer-provenance.md',
                    'bench/inference_resident_sdpa/cuda_encoded_page_bench.cc',
                    'bench/inference_resident_sdpa/cuda_encoded_page_reference.cc']
source_bindings = []
for name in contract_sources:
    p = root / name; raw.append((p, 'comparison-contract/' + name)); source_bindings.append(dict(path=name, sha256=sha(p)))
archive = dest / 'raw.zip'
assert not archive.exists()
manifest = []
start = time.monotonic()
with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as z:
    for p, name in raw:
        assert p.is_file() and name not in {r['name'] for r in manifest}, name
        z.write(p, name); manifest.append(dict(name=name, bytes=p.stat().st_size, sha256=sha(p)))
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for r in manifest: assert hashlib.sha256(z.read(r['name'])).hexdigest() == r['sha256']
receipt = dict(
    state='TERMINAL_REJECTED_NO_PRODUCT_CHANGE', created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    baseline=probe['baseline'], full_product_candidate='669121418669b31f6849c74f64362aaf8d6eb919',
    fi_product_candidate='0a29d119426b2975d48c238c37a2994675e0ba9f', math_candidate='830dd9e01829e3e5850ddff7eaa6355ee7c8fd0d',
    record='docs/implementation/tasks/compute/inference-g04-g05-cache-attention-domain.md',
    product_changed=False, registry_changed=False, formal_p1_run=False, new_product_fix=None, live_job=None,
    candidate=dict(count=1, change='Private BF16/E4M3 packed decoder using native paired FP8-to-half then exact BF16 conversion; original special-code quad fallback retained.',
                   original_vec_sha256=probe['original_vec_sha256'], private_vec_sha256=probe['candidate_vec_sha256']),
    bit_equivalence=dict(quads=70656, outputs=282624, paired_combinations=65536, bit_mismatches=0, finite_oracle_mismatches=0, special_code_observations=5160),
    cropped_stage=dict(disposition='Not a qualified representation of actual product execution; retained for audit, not final adoption decision.',
                       experiments=cropped_run['experiments'], baseline_offset='Unchanged cropped FP8/F32 bridge is about5.6-6.2% slower than the actual SDK kernel in all four orders.'),
    direct_product_stage=dict(build=direct_build, experiments=direct_run['experiments'], phase_results=rows,
                              analysis=direct_analysis, sass=direct_sass,
                              candidate_header_depfile=dict(path=str(deps), sha256=sha(deps), candidate_vec_present=True),
                              normalized_control_sass_matches_sdk=True,
                              control_sass_sha256=actual_control['normalized_sass_sha256']),
    verdict='Reject this single candidate: bit exact and local device checks pass, but attention is slower in all four execution/allocation orders. Diagnostic evidence only; no new formal P1 verdict or old margin change.',
    erratum=dict(supersedes='evidence/architecture/inference-g04-g05-causal-diagnostic/receipt.json: pure causal decomposition in conclusions and disposition',
                 withdrawn=['The previous3.058-3.184us and1.066-1.155us differences identify pure costs of independent representation factors.',
                            'Lowering partial precision has almost no attention effect.',
                            'A particular FP8 conversion instruction or load/compute stall is already proven to cause the gap.'],
                 retained=['Previous raw observations and their source bindings remain historical facts.',
                           'D1 actual-product GPU-stage differences remain valid within their diagnostic scope.',
                           'Attempt14 qualified warm-lifecycle LOSS direction and5% noninferiority UNRESOLVED remain unchanged.'],
                 reason='Cropped unchanged-control execution differs from actual SDK execution; cannot use cropped-path deltas as isolated product costs.'),
    comparison_scope_review=dict(source_bindings=source_bindings,
        original_contract='Explicitly declares immutable warm-lifecycle comparison against a cold-expanded BF16 snapshot; cold seconds/bytes and extra memory are separately reported. No hidden unrecorded expansion was discovered.',
        timing_entry_difference='Candidate retains FP8 and converts on use; peer retains original FP8 plus an additional BF16 snapshot, absorbs fixed scales cold, and uses original BF16 partial/merge.',
        measured_question='Warm latency of these two ready immutable-history strategies under their disclosed storage/precision tradeoffs.',
        invalid_inferences=['Same-resident-memory FP8 implementation superiority/inferiority.', 'Dynamic KV append/growth or refresh-inclusive full-engine throughput.', 'A lower warm rate proves an algorithm defect or identifies an instruction-level root cause.'],
        data_limits='Three finite shapes; main prefill Q64/128 KV1024/768 D256 GQA8/2 page16; repeated immutable contents. Five-code correlated fixture protects numerical load checks, but any value-distribution performance bias is unproven.',
        disposition='Stop algorithm changes driven solely by this cross-representation gap. Preserve original contracts/results and unresolved product gate. A future same-constraint implementation comparison or explicitly refreshed lifecycle comparison requires a new bounded scope, not retrospective relabeling or threshold changes.'),
    costs_seconds=dict(probe_stages=sum(x['seconds'] for x in probe['stages']),
                       cropped_build_stages=sum(s['seconds'] for x in cropped_build['builds'] for s in x['stages']),
                       cropped_run_stages=sum(x['seconds'] for x in cropped_run['commands']),
                       direct_build_stages=sum(x['seconds'] for x in direct_build['stages']),
                       direct_run_stages=sum(x['seconds'] for x in direct_run['commands']),
                       rule='Measured process stages only; do not add overlapping observers or reset prior diagnostic/P1 costs. Source preparation and unmeasured agent wall time remain UNKNOWN.'),
    limitations=['No hardware counters: prior ERR_NVGPUCTRPERM retained; no retry or permission change.',
                 'Profiler perturbation and short controls do not qualify formal P1 or engine token/s.',
                 'Static instruction counts are not dynamic instruction counts, stalls or cycle attribution.',
                 'Exact residual instruction/stall cause remains unproven; no further candidate authorized by this receipt.'],
    setup_failures_retained=['Read-only direct SASS collection initially requested nonexistent Ninja target diag; corrected to actual product binary target. No GPU trial repeated.',
                            'Sealer initially compared a header dependency as a literal path; actual depfile used attention/../vec_dtypes.cuh. Resolved the existing path before comparison; no build or GPU trial repeated.'],
    disposition='Terminal rejected candidate; current product and unresolved G04/G05 acceptance preserved. Old goal cleared by user; no active heavy job or autonomous next optimization.',
    raw_archive=dict(path=archive.relative_to(root).as_posix(), sha256=sha(archive), bytes=archive.stat().st_size,
                     entries=len(manifest), entries_sha256_verified=True, manifest=manifest))
(dest / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(dict(state=receipt['state'], archive_bytes=archive.stat().st_size, entries=len(manifest), archive_verify_seconds=time.monotonic()-start)))
