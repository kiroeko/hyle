from pathlib import Path
import bisect,hashlib,json,sqlite3,statistics
root=Path('/mnt/c/public/project-hyle/hyle');out=root/'.scratch/inference-gaps/g04-g05/c1-packed-conversion-1'
d3=json.loads((out/'run.json').read_text());assert d3['state']=='C1_CONTROL_AND_CANDIDATE_CAPTURED_NOT_P1'
results=[]
for experiment in d3['experiments']:
 trace=Path(experiment['timeline']['sqlite']);db=sqlite3.connect(trace.as_uri()+'?mode=ro',uri=True)
 nv=db.execute('select start,end,text from NVTX_EVENTS where end is not null order by start').fetchall()
 episodes=[x for x in nv if x[2] in ['candidate.episode','peer.episode']];assert len(episodes)==4096
 starts=[x[0] for x in episodes];cases=[x for x in nv if x[2] in ['CF_CF','PF_CF','CF_PF','PF_PF']];assert len(cases)==4
 runtime={}
 for table in ['CUPTI_ACTIVITY_KIND_RUNTIME','CUPTI_ACTIVITY_KIND_DRIVER']:
  if not db.execute('select count(*) from sqlite_master where name=?',(table,)).fetchone()[0]:continue
  for row in db.execute('select start,end,correlationId from '+table):runtime.setdefault(row[2],[]).append(row)
 gpu=db.execute('select k.start,k.end,k.correlationId,s.value,k.registersPerThread,k.dynamicSharedMemory,k.gridX,k.gridY,k.gridZ,k.blockX,k.blockY,k.blockZ,k.localMemoryPerThread from CUPTI_ACTIVITY_KIND_KERNEL k join StringIds s on k.demangledName=s.id order by k.start').fetchall()
 mapped={};resources={}
 for a,b,corr,name,*resource in gpu:
  launches=runtime.get(corr,[])
  if not launches:continue
  launch=min(launches,key=lambda x:x[0]);i=bisect.bisect_right(starts,launch[0])-1
  if i<0 or launch[0]>episodes[i][1]:continue
  side=episodes[i][2].split('.')[0];assert ('hyle_causal_flashinfer_private' in name)==(side=='peer'),name
  if 'BatchPrefillWithPagedKVCacheKernel' in name:kind='attention'
  elif 'MergeStates' in name:kind='merge'
  else:raise AssertionError(name)
  mapped.setdefault(i,[]).append((a,b,kind));resources[(side,kind)]=dict(kernel=name,registers=resource[0],shared=resource[1],grid=resource[2:5],block=resource[5:8],local_bytes=resource[8])
 groups={}
 for i,(begin,end,label) in enumerate(episodes):
  case=next(x[2] for x in cases if x[0]<=begin and end<=x[1]);side=label.split('.')[0];kernels=mapped[i];assert len(kernels)==2
  times={kind:(b-a)/1000 for a,b,kind in kernels};times['gpu_sum']=sum(times.values());times['gpu_gap']=(kernels[1][0]-kernels[0][1])/1000;times['episode']=(end-begin)/1000
  groups.setdefault((case,side),[]).append(times)
 summary=[]
 for case in [x[2] for x in cases]:
  row={'case':case,'sides':{}}
  for side in ['candidate','peer']:
   v=groups[case,side];assert len(v)==512
   row['sides'][side]={k:{'mean_us':statistics.mean(x[k] for x in v),'median_us':statistics.median(x[k] for x in v),'group64_mean_us':[statistics.mean(x[k] for x in v[j:j+64]) for j in range(0,512,64)]} for k in v[0]}
  row['mean_difference_us']={k:row['sides']['candidate'][k]['mean_us']-row['sides']['peer'][k]['mean_us'] for k in v[0]};summary.append(row)
 # Fixed head/requests/CTA/block and planner geometry, not a tile search.
 for kind in ['attention','merge']:
  assert resources['candidate',kind]['grid']==resources['peer',kind]['grid']
  assert resources['candidate',kind]['block']==resources['peer',kind]['block']
 result={'variant':experiment['variant'],'trace_sha256':hashlib.sha256(trace.read_bytes()).hexdigest(),'episodes':len(episodes),'kernels':sum(map(len,mapped.values())),
         'resources':[dict(side=side,kind=kind,**v) for (side,kind),v in resources.items()],'summary':summary}
 results.append(result)
 for row in summary:
  print(experiment['variant'],row['case'],{side:{k:round(v['median_us'],3) for k,v in data.items()} for side,data in row['sides'].items()},flush=True)
final={'state':'C1_PACKED_CONVERSION_DIAGNOSTIC_ONLY','experiments':results,'limits':['Both disposable variants passed original finite independent oracle/readonly checks and memcheck before timings.','Only original prefill fixture is covered, not all public numerical domains.','Same-shape planner/grid/block verified; FP8 carrier and F32 intermediate representation unchanged. Only the one packed conversion candidate differs from its identically built control.','Profiled host wall and short noisy AA do not license P1 or a product FIX.','No new NCU collection; prior driver counter rejection remains. No dynamic stall counter claim.']}
(out/'analysis.json').write_text(json.dumps(final,indent=2)+'\n')
