from pathlib import Path
import hashlib,json,os,shutil,subprocess,time
root=Path('/mnt/c/public/project-hyle/hyle');out=root/'.scratch/inference-gaps/g04-g05/c1-packed-conversion-1';out.mkdir(exist_ok=False)
work=Path('/root/hyle-scratch/compute-unified/g04-c1-packed-conversion-1');work.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
gen=json.loads((root/'.scratch/inference-gaps/g04-g05/ce28-fixed-codegen-1/result.json').read_text());original=Path(gen['header']).parent.parent.parent
assert sha(Path(gen['header']))==gen['header_sha256'];shutil.copytree(original,work/'include')
p=work/'include/flashinfer/vec_dtypes.cuh';text=p.read_text();before=sha(p)
helper='''
__device__ __forceinline__ void hyle_c1_packed_e4m3_bf16(uint32_t q, uint2* output) {
  // Preserve the existing packed decoder's special-code behavior. Its finite
  // values are exact in half and bfloat16; the CUDA packed conversion handles
  // signed zero and every subnormal without data-dependent normalization.
  const uint32_t inverted = (q & 0x7f7f7f7fu) ^ 0x7f7f7f7fu;
  if (((inverted - 0x01010101u) & 0x80808080u) != 0) {
    fast_dequant_f8f16x4<__nv_fp8_e4m3, nv_bfloat16>(&q, output);
    return;
  }
  const __half2_raw low_raw = __nv_cvt_fp8x2_to_halfraw2(static_cast<__nv_fp8x2_storage_t>(q), __NV_E4M3);
  const __half2_raw high_raw = __nv_cvt_fp8x2_to_halfraw2(static_cast<__nv_fp8x2_storage_t>(q >> 16), __NV_E4M3);
  __half2 low, high;
  memcpy(&low, &low_raw, sizeof(low));memcpy(&high, &high_raw, sizeof(high));
  const nv_bfloat162 low_bf = __float22bfloat162_rn(__half22float2(low));
  const nv_bfloat162 high_bf = __float22bfloat162_rn(__half22float2(high));
  memcpy(&output->x, &low_bf, sizeof(output->x));memcpy(&output->y, &high_bf, sizeof(output->y));
}
'''
marker='template <>\nstruct vec_cast<nv_bfloat16, __nv_fp8_e4m3> {';assert marker in text;text=text.replace(marker,helper+'\n'+marker,1)
old='''        fast_dequant_f8f16x4<__nv_fp8_e4m3, nv_bfloat16>((uint32_t*)&src[i * 4],
                                                         (uint2*)&dst[i * 4]);'''
assert old in text;text=text.replace(old,'''        hyle_c1_packed_e4m3_bf16(*reinterpret_cast<const uint32_t*>(&src[i * 4]),
                                    reinterpret_cast<uint2*>(&dst[i * 4]));''',1);p.write_text(text)
source=r'''#include <flashinfer/vec_dtypes.cuh>
#include <cuda_runtime.h>
#include <bit>
#include <cmath>
#include <cstdio>
#include <cstdint>
#include <cstdlib>
#include <vector>
void check(cudaError_t e){if(e!=cudaSuccess){std::fprintf(stderr,"CUDA: %s\n",cudaGetErrorString(e));std::exit(2);}}
__global__ void original_quad(const uint32_t *in,uint2 *out,size_t n){const auto i=size_t(blockIdx.x)*blockDim.x+threadIdx.x;if(i<n){uint32_t q=in[i];flashinfer::fast_dequant_f8f16x4<__nv_fp8_e4m3,nv_bfloat16>(&q,out+i);}}
__global__ void packed_quad(const uint32_t *in,uint2 *out,size_t n){const auto i=size_t(blockIdx.x)*blockDim.x+threadIdx.x;if(i<n)flashinfer::hyle_c1_packed_e4m3_bf16(in[i],out+i);}
uint16_t independent(unsigned code){const auto e=(code&127)>>3,m=code&7;double x=e?std::ldexp(1.+double(m)/8.,int(e)-7):std::ldexp(double(m)/8.,-6);if(code&128)x=-x;return uint16_t(std::bit_cast<uint32_t>(float(x))>>16);}
int main(){
 std::vector<uint32_t> words;
 for(unsigned pair=0;pair<65536;++pair){const unsigned a=pair&255,b=pair>>8;words.push_back(pair|((a^255)<<16)|(((b<<1)|(b>>7))&255)<<24);}
 for(unsigned code=0;code<256;++code)for(unsigned position=0;position<4;++position)for(auto pattern:{0u,0x80808080u,0x38383838u,0x01020304u,0x7f7f7f7fu})words.push_back((pattern&~(255u<<(position*8)))|(code<<(position*8)));
 const auto n=words.size();uint32_t *input;uint2 *old,*candidate;
 check(cudaMalloc(&input,n*4));check(cudaMalloc(&old,n*8));check(cudaMalloc(&candidate,n*8));check(cudaMemcpy(input,words.data(),n*4,cudaMemcpyHostToDevice));
 original_quad<<<unsigned((n+255)/256),256>>>(input,old,n);packed_quad<<<unsigned((n+255)/256),256>>>(input,candidate,n);check(cudaGetLastError());check(cudaDeviceSynchronize());
 std::vector<uint2> a(n),b(n);check(cudaMemcpy(a.data(),old,n*8,cudaMemcpyDeviceToHost));check(cudaMemcpy(b.data(),candidate,n*8,cudaMemcpyDeviceToHost));
 unsigned mismatch=0,finite_mismatch=0,special=0;
 for(size_t i=0;i<n;++i)for(unsigned j=0;j<4;++j){const unsigned code=(words[i]>>(j*8))&255;const uint16_t av=uint16_t((j<2?a[i].x:a[i].y)>>((j%2)*16)),bv=uint16_t((j<2?b[i].x:b[i].y)>>((j%2)*16));
  if(av!=bv){if(mismatch<8)std::printf("DIFF word=%zu lane=%u code=%u old=%04x new=%04x\n",i,j,code,av,bv);++mismatch;}
  if((code&127)==127){++special;continue;}
  const auto expected=independent(code);if(av!=expected||bv!=expected){if(finite_mismatch<8)std::printf("ORACLE code=%u old=%04x new=%04x expected=%04x\n",code,av,bv,expected);++finite_mismatch;}
 }
 std::printf("C1_CODES words=%zu outputs=%zu paired_combinations=65536 bit_mismatch=%u finite_oracle_mismatch=%u special_observations=%u\n",n,n*4,mismatch,finite_mismatch,special);
 check(cudaFree(input));check(cudaFree(old));check(cudaFree(candidate));return mismatch||finite_mismatch?3:0;
}
'''
(work/'probe.cu').write_text(source)
r={'state':'C1_SEMANTIC_PROBE_SETUP','baseline':'1bf3f2c32909152daab1b1aed61ab870c76a789e','work':str(work),'original_include':str(original),'original_vec_sha256':before,'candidate_vec_sha256':sha(p),'candidate_source_sha256':sha(work/'probe.cu'),'stages':[]}
save=lambda:(out/'probe.json').write_text(json.dumps(r,indent=2)+'\n')
env=os.environ.copy();env['PATH']='/usr/local/cuda-13.3/bin:'+env['PATH']
for name,command in [('compile',['/usr/local/cuda-13.3/bin/nvcc','-O3','-std=c++20','-arch=sm_89','--expt-relaxed-constexpr','-ccbin','g++-14','-I'+str(work/'include'),str(work/'probe.cu'),'-o',str(work/'probe')]),('codes',[str(work/'probe')])]:
 save();start=time.monotonic()
 with (out/(name+'.log')).open('w') as f:
  child=subprocess.Popen(command,env=env,stdout=f,stderr=subprocess.STDOUT);r.update(state='RUNNING',active_stage=name,pid=child.pid);save();print(name,child.pid,flush=True);code=child.wait()
 r['stages'].append(dict(name=name,command=command,exit=code,seconds=time.monotonic()-start));save()
 if code:r['state']='TERMINAL_FAIL';save();raise RuntimeError(name+' failed')
r.update(state='C1_ALL_CODES_BIT_EXACT',binary_sha256=sha(work/'probe'));r.pop('pid',None);r.pop('active_stage',None);save();print((out/'codes.log').read_text(),flush=True)
