from pathlib import Path
import json,subprocess
root=Path('/mnt/c/public/project-hyle/hyle')
r=json.loads((root/'.scratch/inference-gaps/g04-g05/ce28-fixed-codegen-1/result.json').read_text())
include=Path(r['header']).parent.parent.parent
p=include/'flashinfer/vec_dtypes.cuh';lines=p.read_text().splitlines()
for i in range(175,283):print(str(i+1)+': '+lines[i])
for p in [Path('/usr/local/cuda-13.3/include/cuda_fp8.hpp')]:
 lines=p.read_text().splitlines()
 for i,line in enumerate(lines):
  if 'cvt.rn.f16x2.e4m3x2' in line:
   print('\n'.join(str(k+1)+': '+lines[k] for k in range(max(0,i-12),i+6)));break
print('include',include)
print('processes',subprocess.check_output(['nvidia-smi','--query-compute-apps=pid,process_name','--format=csv,noheader'],text=True).strip())
