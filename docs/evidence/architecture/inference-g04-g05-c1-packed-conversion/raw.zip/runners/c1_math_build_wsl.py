from pathlib import Path
import hashlib,json,os,re,shutil,subprocess,time
root=Path('/mnt/c/public/project-hyle/hyle');out=root/'.scratch/inference-gaps/g04-g05/c1-packed-conversion-1'
probe=json.loads((out/'probe.json').read_text());assert probe['state']=='C1_ALL_CODES_BIT_EXACT'
work=Path(probe['work']);base=Path('/root/hyle-scratch/compute-unified/g04-causal-counterfactual-1')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
result={'state':'C1_MATH_SETUP','hypothesis':'SM89 native paired FP8 conversion plus exact half2/float2/BF16 packing removes software dequant work while preserving compressed KV and F32 partial/merge. One candidate, with an identically built unchanged-header control.','probe':'probe.json','builds':[]}
save=lambda:(out/'math-build.json').write_text(json.dumps(result,indent=2)+'\n')
env=os.environ.copy();env['PATH']='/usr/local/cuda-13.3/bin:'+env['PATH']
for mode in ['control','packed']:
 source=work/mode;source.mkdir(exist_ok=False);shutil.copytree(base/'bench',source/'bench')
 p=source/'bench/inference_resident_sdpa/counterfactual_native.cu';s=p.read_text()
 s,n=re.subn(r'bool uses_fp8\(\)\{.*?\nvoid \*create_plan', 'bool uses_fp8(){return true;}\nvoid *create_plan',s,flags=re.S);assert n==1
 assert s.count('uses_fp8()?2:4')==2;s=s.replace('uses_fp8()?2:4','4')
 before=''' if(uses_fp8())return run_output<__nv_bfloat16,__nv_fp8_e4m3,256,256,false>(p,spec,q,k,v,metadata,o,floating,integer,stream);
 return run_output<__nv_bfloat16,__nv_bfloat16,256,256,true>(p,spec,q,k,v,metadata,o,floating,integer,stream);'''
 assert before in s;s=s.replace(before,' return run_output<__nv_bfloat16,__nv_fp8_e4m3,256,256,true>(p,spec,q,k,v,metadata,o,floating,integer,stream);');p.write_text(s)
 cmake=(base/'CMakeLists.txt').read_text()
 if mode=='packed':cmake=cmake.replace(probe['original_include'],str(work/'include'))
 (source/'CMakeLists.txt').write_text(cmake)
 r={'mode':mode,'source':str(source),'include':str(work/'include') if mode=='packed' else probe['original_include'],'inputs':[{'path':str(p.relative_to(source)),'sha256':sha(p)} for p in source.rglob('*') if p.is_file()],'stages':[]};result['builds'].append(r);save()
 commands=[('configure',['cmake','-S',str(source),'-B',str(source/'build'),'-G','Ninja','-DCMAKE_CXX_COMPILER=g++-14','-DCMAKE_C_COMPILER=gcc-14','-DCMAKE_CUDA_COMPILER=/usr/local/cuda-13.3/bin/nvcc','-DCMAKE_CUDA_HOST_COMPILER=g++-14','-DCMAKE_BUILD_TYPE=Release','-DCMAKE_PREFIX_PATH=/root/hyle-scratch/compute-unified/g06-final-sdk/cuda-static-1/relocated']),('compile',['cmake','--build',str(source/'build'),'--parallel','2','--target','diag'])]
 for stage,command in commands:
  start=time.monotonic()
  with (out/(mode+'-'+stage+'.log')).open('w') as f:
   child=subprocess.Popen(command,env=env,stdout=f,stderr=subprocess.STDOUT);result.update(state='RUNNING',active_stage=mode+'-'+stage,pid=child.pid);save();print(mode,stage,child.pid,flush=True);code=child.wait()
  r['stages'].append(dict(stage=stage,command=command,exit=code,seconds=time.monotonic()-start));save()
  if code:result['state']='SETUP_FAIL';save();raise RuntimeError(mode+' '+stage+' failed')
 r['binary']={'path':str(source/'build/diag'),'sha256':sha(source/'build/diag')};save()
result['state']='C1_CONTROL_AND_CANDIDATE_BUILT';result.pop('pid',None);result.pop('active_stage',None);save();print(result['state'],flush=True)
