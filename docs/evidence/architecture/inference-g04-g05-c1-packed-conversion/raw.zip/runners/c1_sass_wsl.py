from pathlib import Path
import hashlib,json,re,sqlite3,subprocess
root=Path('/mnt/c/public/project-hyle/hyle');out=root/'.scratch/inference-gaps/g04-g05/c1-packed-conversion-1';run=json.loads((out/'run.json').read_text());result=[]
for e in run['experiments']:
 db=sqlite3.connect(Path(e['timeline']['sqlite']).as_uri()+'?mode=ro',uri=True);names={}
 for m,d in db.execute('select distinct m.value,d.value from CUPTI_ACTIVITY_KIND_KERNEL k join StringIds m on k.mangledName=m.id join StringIds d on k.demangledName=d.id'):
  if 'BatchPrefillWithPagedKVCacheKernel' not in d:continue
  label='private' if 'hyle_causal_flashinfer_private' in d else 'current';assert label not in names;names[label]={'mangled':m,'demangled':d}
 binary=Path(e['binary']['path']);log=out/(e['mode']+'-sass.txt');command=['/usr/local/cuda-13.3/bin/cuobjdump','--dump-sass','--function',','.join(x['mangled'] for x in names.values()),str(binary)]
 with log.open('w') as f:code=subprocess.call(command,stdout=f,stderr=subprocess.STDOUT)
 assert code==0;lookup={v['mangled']:k for k,v in names.items()};current=None;ops={};instructions={}
 for line in log.read_text().splitlines():
  m=re.search(r'Function\s*:\s*(\S+)',line)
  if m:current=lookup.get(m[1]);ops.setdefault(current,{});instructions.setdefault(current,[])
  if current:
   m=re.search(r'/\*[0-9a-fA-F]+\*/\s+((?:@!?P\d+\s+)?([A-Z][A-Z0-9_]*(?:\.[A-Z0-9_]+)*)[^;]*;)',line)
   if m:op=m[2];ops[current][op]=ops[current].get(op,0)+1;instructions[current].append(m[1])
 command_text=subprocess.check_output(['ninja','-C',str(binary.parent),'-t','commands','diag'],text=True)
 (out/(e['mode']+'-commands.txt')).write_text(command_text)
 deps=subprocess.check_output(['ninja','-C',str(binary.parent),'-t','deps'],text=True);(out/(e['mode']+'-deps.txt')).write_text(deps)
 headers=[line.strip() for line in deps.splitlines() if line.strip().endswith('/flashinfer/vec_dtypes.cuh')]
 row={'mode':e['mode'],'binary':e['binary'],'actual_vec_headers':[{'path':p,'sha256':hashlib.sha256(Path(p).read_bytes()).hexdigest()} for p in sorted(set(headers))],'kernels':[dict(route=k,**names[k],total_static_instructions=sum(v.values()),ops=v,normalized_sass_sha256=hashlib.sha256('\n'.join(instructions[k]).encode()).hexdigest()) for k,v in ops.items()]};result.append(row)
 for k in row['kernels']:
  print(e['mode'],k['route'],k['total_static_instructions'],{key:sum(v for op,v in k['ops'].items() if op.split('.')[0]==key) for key in ['F2FP','F2F','HFMA2','PRMT','LOP3','HMMA','LDL','STL','BRA']})
 print('ACTUAL_HEADERS',row['actual_vec_headers'])
(out/'sass.json').write_text(json.dumps({'state':'ACTUAL_KERNEL_SASS_DIAGNOSTIC_NOT_DYNAMIC_COUNTERS','experiments':result},indent=2)+'\n')
