#include <flashinfer/vec_dtypes.cuh>
#include <cuda_runtime.h>
#include <bit>
#include <cmath>
#include <cstdio>
#include <cstdint>
#include <cstdlib>
#include <vector>
void check(cudaError_t e){if(e!=cudaSuccess){std::fprintf(stderr,"CUDA: %s\n",cudaGetErrorString(e));std::exit(2);}}
__global__ void original_quad(const uint32_t *in,uint2 *out,size_t n){const auto i=size_t(blockIdx.x)*blockDim.x+threadIdx.x;if(i<n){uint32_t q=in[i];flashinfer::fast_dequant_f8f16x4<__nv_fp8_e4m3,nv_bfloat16>(&q,out+i);}}
__global__ void packed_quad(const uint32_t *in,uint2 *out,size_t n){const auto i=size_t(blockIdx.x)*blockDim.x+threadIdx.x;if(i<n)flashinfer::hyle_c1_packed_e4m3_bf16(in[i],out+i);}
uint16_t independent(unsigned code){const auto e=(code&127)>>3,m=code&7;double x=e?std::ldexp(1.+double(m)/8.,int(e)-7):std::ldexp(double(m)/8.,-6);if(code&128)x=-x;return uint16_t(std::bit_cast<uint32_t>(float(x))>>16);}
int main(){
 std::vector<uint32_t> words;
 for(unsigned pair=0;pair<65536;++pair){const unsigned a=pair&255,b=pair>>8;words.push_back(pair|((a^255)<<16)|(((b<<1)|(b>>7))&255)<<24);}
 for(unsigned code=0;code<256;++code)for(unsigned position=0;position<4;++position)for(auto pattern:{0u,0x80808080u,0x38383838u,0x01020304u,0x7f7f7f7fu})words.push_back((pattern&~(255u<<(position*8)))|(code<<(position*8)));
 const auto n=words.size();uint32_t *input;uint2 *old,*candidate;
 check(cudaMalloc(&input,n*4));check(cudaMalloc(&old,n*8));check(cudaMalloc(&candidate,n*8));check(cudaMemcpy(input,words.data(),n*4,cudaMemcpyHostToDevice));
 original_quad<<<unsigned((n+255)/256),256>>>(input,old,n);packed_quad<<<unsigned((n+255)/256),256>>>(input,candidate,n);check(cudaGetLastError());check(cudaDeviceSynchronize());
 std::vector<uint2> a(n),b(n);check(cudaMemcpy(a.data(),old,n*8,cudaMemcpyDeviceToHost));check(cudaMemcpy(b.data(),candidate,n*8,cudaMemcpyDeviceToHost));
 unsigned mismatch=0,finite_mismatch=0,special=0;
 for(size_t i=0;i<n;++i)for(unsigned j=0;j<4;++j){const unsigned code=(words[i]>>(j*8))&255;const uint16_t av=uint16_t((j<2?a[i].x:a[i].y)>>((j%2)*16)),bv=uint16_t((j<2?b[i].x:b[i].y)>>((j%2)*16));
  if(av!=bv){if(mismatch<8)std::printf("DIFF word=%zu lane=%u code=%u old=%04x new=%04x\n",i,j,code,av,bv);++mismatch;}
  if((code&127)==127){++special;continue;}
  const auto expected=independent(code);if(av!=expected||bv!=expected){if(finite_mismatch<8)std::printf("ORACLE code=%u old=%04x new=%04x expected=%04x\n",code,av,bv,expected);++finite_mismatch;}
 }
 std::printf("C1_CODES words=%zu outputs=%zu paired_combinations=65536 bit_mismatch=%u finite_oracle_mismatch=%u special_observations=%u\n",n,n*4,mismatch,finite_mismatch,special);
 check(cudaFree(input));check(cudaFree(old));check(cudaFree(candidate));return mismatch||finite_mismatch?3:0;
}
