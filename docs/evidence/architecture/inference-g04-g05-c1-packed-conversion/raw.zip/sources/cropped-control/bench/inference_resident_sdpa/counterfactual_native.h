#pragma once
#include "cuda_encoded_page_native.h"
#include "native_batch.h"
namespace hyle::bench::resident::cuda_counterfactual {
using Spec=cuda_original::Spec;using Facts=cuda_original::Facts;
using BatchSpec=hyle::compute::flashinfer::native::BatchSpec;
bool uses_fp8();
void *create_plan();void destroy_plan(void *) noexcept;
cudaError_t workspace(Spec,const std::int32_t *,const std::int32_t *,cudaStream_t,Facts &);
cudaError_t plan(void *,Spec,const std::int32_t *,const std::int32_t *,void *,std::size_t,void *,void *,std::size_t,cudaStream_t,Facts &);
cudaError_t run(const void *,Spec,const void *,const void *,const void *,const void *,void *,void *,void *,cudaStream_t);
inline cudaError_t decode(const void *p,void *q,const std::uint32_t *valid,unsigned pages,unsigned page_size,unsigned heads,unsigned depth,float,cudaStream_t stream){
 return cuda_original::decode(p,q,valid,pages,page_size,heads,depth,1.F,stream);
}
}
