#include "counterfactual_native.h"
#include <cstdlib>
#include <cstring>

#include <cuda_bf16.h>
#include <cuda_fp16.h>
#include <cuda_fp8.h>
#define flashinfer hyle_causal_flashinfer_private
#include <flashinfer/attention/default_prefill_params.cuh>
#include <flashinfer/attention/cascade.cuh>
#include <flashinfer/attention/scheduler.cuh>
#include <flashinfer/attention/variants.cuh>
#include <algorithm>
#include <stdexcept>
#include <type_traits>

namespace hyle::bench::resident::cuda_counterfactual {
namespace {
template<class Q,unsigned Depth>cudaError_t merge_f32(float *values,float *scores,std::int32_t *indptr,
    Q *output,float *lse,unsigned rows,unsigned *actual_rows,unsigned heads,float scale,cudaStream_t stream){
  // Bind the original persistent merge kernel only for this card's finite
  // depths. The generic upstream host dispatcher also instantiates D512,
  // whose 512-bit async copy is invalid for F32 inputs at the locked revision.
  constexpr unsigned vector=Depth/32>4?Depth/32:4;
  constexpr unsigned x=Depth/vector,y=128/x;
  // Two F32 stages keep D256's byte budget equal to four BF16 stages.
  constexpr unsigned stages=2,shared=stages*y*Depth*sizeof(float)+128*sizeof(float);
  auto kernel=::flashinfer::PersistentVariableLengthMergeStatesKernel<vector,x,y,stages,float,Q,std::int32_t,true>;
  if(!rows || !heads)return cudaSuccess;
  int device=0,sms=0,occupancy=0;
  auto status=cudaGetDevice(&device);if(status!=cudaSuccess)return status;
  status=cudaDeviceGetAttribute(&sms,cudaDevAttrMultiProcessorCount,device);if(status!=cudaSuccess)return status;
  status=cudaOccupancyMaxActiveBlocksPerMultiprocessor(&occupancy,kernel,128,shared);if(status!=cudaSuccess)return status;
  const auto needed=(std::uint64_t(rows)*heads+unsigned(sms)-1)/unsigned(sms);
  const auto blocks=unsigned(sms)*unsigned((std::min)(std::uint64_t(occupancy),needed));
  status=cudaFuncSetAttribute(kernel,cudaFuncAttributeMaxDynamicSharedMemorySize,shared);if(status!=cudaSuccess)return status;
  void *arguments[]{&values,&scores,&indptr,&output,&lse,&rows,&actual_rows,&heads,&scale};
  return cudaLaunchKernel(reinterpret_cast<const void*>(kernel),dim3(blocks),dim3(x,y),arguments,shared,stream);
}
}
}
#include <flashinfer/attention/prefill.cuh>

namespace hyle::bench::resident::cuda_counterfactual {
namespace fi=::flashinfer;

namespace {
template<class Base>struct OutputParams:Base {float v_scale=1.F;};

template<class Base,class Q,unsigned Depth>struct MergeParams:Base {
  Q *final_output=nullptr;
  float final_scale=1.F;
  cudaError_t merge_states(float *values,float *scores,float *final_lse,cudaStream_t stream) const {
    return merge_f32<Q,Depth>(values,scores,this->merge_indptr,final_output,final_lse,
        this->max_total_num_rows,this->total_num_rows,this->num_qo_heads,final_scale,stream);
  }
};

template<class Params>void bind_plan(Params &params,const fi::PrefillPlanInfo &plan,void *integer){
  const auto pointer=[&](std::int64_t offset){return reinterpret_cast<std::int32_t*>(static_cast<char*>(integer)+offset);};
  params.request_indices=pointer(plan.request_indices_offset);
  params.qo_tile_indices=pointer(plan.qo_tile_indices_offset);
  params.kv_tile_indices=pointer(plan.kv_tile_indices_offset);
  params.o_indptr=pointer(plan.o_indptr_offset);
  params.kv_chunk_size_ptr=pointer(plan.kv_chunk_size_ptr_offset);
  params.padded_batch_size=std::uint32_t(plan.padded_batch_size);
  params.max_total_num_rows=std::uint32_t(plan.total_num_rows);
  if(plan.split_kv)params.merge_indptr=pointer(plan.merge_indptr_offset);
}
template<unsigned QK,unsigned VO,bool Paged,fi::MaskMode Mask,class Params>
cudaError_t launch(Params params,const fi::PrefillPlanInfo &plan,void *floating,cudaStream_t stream){
  using Variant=fi::DefaultAttention<false,true,false,false>;
  auto *temporary=plan.split_kv?reinterpret_cast<typename Params::DTypeO*>(static_cast<char*>(floating)+plan.v_offset):nullptr;
  auto *scores=plan.split_kv?reinterpret_cast<float*>(static_cast<char*>(floating)+plan.s_offset):nullptr;
  switch(plan.cta_tile_q){
#define HYLE_CACHE_TILE(tile) case tile: if constexpr(Paged) return fi::BatchPrefillWithPagedKVCacheDispatched<tile,QK,VO,fi::PosEncodingMode::kNone,false,Mask,Variant>(params,temporary,scores,false,stream); else return fi::BatchPrefillWithRaggedKVCacheDispatched<tile,QK,VO,fi::PosEncodingMode::kNone,false,Mask,Variant>(params,temporary,scores,false,stream)
    HYLE_CACHE_TILE(64);
#undef HYLE_CACHE_TILE
  }
  throw std::runtime_error("FlashInfer cache CTA outside qualified dispatch");
}
template<unsigned QK,unsigned VO,bool Paged,class Params>
cudaError_t launch_mask(Params params,const fi::PrefillPlanInfo &plan,BatchSpec spec,void *floating,cudaStream_t stream){
  (void)spec;
  return launch<QK,VO,Paged,fi::MaskMode::kCausal>(params,plan,floating,stream);
}
template<class Q,class KV,unsigned QK,unsigned VO,bool Split>
cudaError_t run_output(const fi::PrefillPlanInfo &plan,BatchSpec spec,const void *q,const void *k,
                     const void *v,const void *metadata,void *output,void *floating,void *integer,cudaStream_t stream){
  constexpr bool fp8=sizeof(KV)==1;
  using O=std::conditional_t<Split,float,Q>;
  // Split kernels write F32 partials; their host merge writes the final Q output.
  auto *native_output=static_cast<O*>(output);
  const auto bind_output=[&](auto &params){
    if constexpr(Split){params.final_output=static_cast<Q*>(output);params.final_scale=spec.value_scale;}
    else params.v_scale=fp8?spec.value_scale:1.F;
  };
  const auto pointer=[&](std::size_t offset){return reinterpret_cast<std::int32_t*>(const_cast<char*>(static_cast<const char*>(metadata))+offset);};
  cudaError_t status;
  if(spec.paged){
    using Base=fi::BatchPrefillPagedParams<Q,KV,O,std::int32_t>;
    std::conditional_t<Split,MergeParams<Base,Q,VO>,OutputParams<Base>> params;
    params.q=const_cast<Q*>(static_cast<const Q*>(q));params.o=native_output;
    params.q_indptr=pointer(spec.query_indptr_offset);
    const std::int64_t ks[]{std::int64_t(spec.page_size)*spec.kv_heads*QK,std::int64_t(spec.kv_heads)*QK,QK,1};
    const std::int64_t vs[]{std::int64_t(spec.page_size)*spec.kv_heads*VO,std::int64_t(spec.kv_heads)*VO,VO,1};
    params.paged_kv=fi::paged_kv_t<KV,std::int32_t>(spec.kv_heads,spec.page_size,QK,spec.requests,fi::QKVLayout::kNHD,
      const_cast<KV*>(static_cast<const KV*>(k)),const_cast<KV*>(static_cast<const KV*>(v)),ks,vs,
      pointer(spec.page_indices_offset),pointer(spec.kv_indptr_offset),pointer(spec.tail_offset));
    params.num_qo_heads=spec.query_heads;params.group_size=fi::uint_fastdiv(spec.query_heads/spec.kv_heads);
    params.q_stride_n=spec.query_heads*QK;params.q_stride_h=QK;
    params.window_left=spec.window_left;params.sm_scale=spec.scale*spec.key_scale;bind_plan(params,plan,integer);bind_output(params);
    status=launch_mask<QK,VO,true>(params,plan,spec,floating,stream);
  }else return cudaErrorNotSupported;
  return status;
}

} // anonymous namespace
bool uses_fp8(){return true;}
void *create_plan(){return new fi::PrefillPlanInfo;}
void destroy_plan(void *p) noexcept{delete static_cast<fi::PrefillPlanInfo*>(p);}
cudaError_t workspace(Spec s,const std::int32_t *q,const std::int32_t *k,cudaStream_t stream,Facts &f){
 return fi::PrefillPlanWorkspaceSize(f.floating,f.integer,const_cast<std::int32_t*>(q),const_cast<std::int32_t*>(k),s.query_rows,s.requests,s.query_heads,s.kv_heads,s.key_depth,s.value_depth,s.page_size,false,4,s.window,-1,false,0,0,stream,1);
}
cudaError_t plan(void *state,Spec s,const std::int32_t *q,const std::int32_t *k,void *floating,std::size_t fb,void *integer,void *host,std::size_t ib,cudaStream_t stream,Facts &f){
 auto &p=*static_cast<fi::PrefillPlanInfo*>(state);
 auto status=fi::PrefillPlan(floating,fb,integer,host,ib,p,const_cast<std::int32_t*>(q),const_cast<std::int32_t*>(k),s.query_rows,s.requests,s.query_heads,s.kv_heads,s.key_depth,s.value_depth,s.page_size,false,4,s.window,-1,false,0,0,stream,1);
 f.tile=unsigned(p.cta_tile_q);f.padded=unsigned(p.padded_batch_size);f.split=p.split_kv;return status;
}
cudaError_t run(const void *state,Spec s,const void *q,const void *k,const void *v,const void *metadata,void *o,void *floating,void *integer,cudaStream_t stream){
 const auto &p=*static_cast<const fi::PrefillPlanInfo*>(state);
 if(s.key_depth!=256 || s.value_depth!=256 || !s.causal || s.window!=-1 || !p.split_kv || p.cta_tile_q!=64)return cudaErrorNotSupported;
 BatchSpec spec{.query_heads=s.query_heads,.kv_heads=s.kv_heads,.qk_head_dim=s.key_depth,.value_head_dim=s.value_depth,.page_size=s.page_size,
 .query_rows=s.query_rows,.requests=s.requests,.query_indptr_offset=s.query_offset,.kv_indptr_offset=s.kv_offset,.page_indices_offset=s.indices_offset,.tail_offset=s.tails_offset,
 .scale=s.scale,.key_scale=.5F,.value_scale=2.F,.window_left=-1,.paged=true,.bfloat16=true,.fp8=uses_fp8(),.causal=true};
 return run_output<__nv_bfloat16,__nv_fp8_e4m3,256,256,true>(p,spec,q,k,v,metadata,o,floating,integer,stream);
}
} // namespace
#undef flashinfer
