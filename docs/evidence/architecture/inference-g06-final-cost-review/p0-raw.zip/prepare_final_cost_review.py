from pathlib import Path
import datetime, hashlib, json, subprocess

ROOT=Path.cwd();BASE=ROOT/'.scratch/inference-gaps/g06'
PRODUCT='669121418669b31f6849c74f64362aaf8d6eb919'
assert not subprocess.check_output(['git','diff','--name-only',PRODUCT,'HEAD','--','include','src','cmake','CMakeLists.txt'],text=True).strip()
assert not subprocess.check_output(['git','diff','--name-only','HEAD','--','include','src','cmake','CMakeLists.txt'],text=True).strip()


def source(path,text):
    file=ROOT/path;data=file.read_bytes();lines=data.decode().splitlines()
    matches=[i+1 for i,line in enumerate(lines) if text in line]
    assert matches,(path,text)
    return {'path':path,'sha256':hashlib.sha256(data).hexdigest(),'lines':matches,'anchor':text}


def evidence(name):
    path=ROOT/name;data=path.read_bytes()
    r=json.loads(data)
    return {'path':name,'sha256':hashlib.sha256(data).hexdigest(),'state':r.get('state',r.get('verdict',r.get('kind')))}


sdk=json.loads((ROOT/'evidence/correctness/inference-g06-final-relocated-sdk/receipt.json').read_text(encoding='utf8'))
assert sdk['state']=='PASS_FOUR_ROUTE_RELOCATED_STATIC_SHARED_SDK'
all_cases={name for config in sdk['configurations'] for test in config['tests'].values() for name in test['cases']}
required=['BatchLayout.ActiveSnapshotIsCompactAndExplicitExportZerosAllInactiveCapacity',
          'BatchLayout.ConcurrentFirstFullExportsShareOneImmutableBacking',
          'BatchLayout.FailedExplicitExportPreservesActiveVersionAndCanRetry',
          'NativePagedMetadata.ActiveVersionDefersFullIndexAllocationUntilExplicitExport',
          'NativePagedMetadata.ConcurrentExplicitExportsShareOneReadonlyTable',
          'GgmlCpuPaged.DeltaMetadataMirrorMatchesIndependentFullWireAcrossGrowShrinkAndEmpty',
          'GgmlCpuPaged.RuntimeQ1UsesOriginalDecodeSlotAcrossPagesAndTails',
          'GgmlCpuRagged.RuntimeQ1KeepsGraphAcrossPackedKvExtents',
          'FlashinferCache.RuntimeScheduleReusesActualTilesAcrossKvExtents',
          'FlashinferBatchReplay.ColdRecordAndRuntimeSchedule',
          'NativeRaggedLayout.PublicRuntimeKvUpdatesKeepIndependentSlotsAndCheckedBoundaries']
assert set(required)<=all_cases,set(required)-all_cases
paths=['src/compute_batch/batch_layout.cc','src/compute_batch/batch_paged_native.cc',
       'src/compute_batch/batch_execution.cc','src/compute_batch/paged_arena.cc',
       'src/graph_batch/batch.cc','src/graph/submission_internal.h','src/graph/lease_submission.cc','src/graph/leased_invocation.cc',
       'src/compute_provider_flashinfer/native_batch.cu','src/compute_provider_flashinfer/flashinfer_provider.cc',
       'include/hyle/compute/detail/materialized_native_controller.h']
anchors=[source(paths[0],'BatchLayoutVersion::metadata()'),source(paths[0],'active_offsets(BatchLayoutFacts'),
         source(paths[2],'std::array<CopyRange,5> ranges'),source(paths[2],'upload_waits+(reused?0u:1u)'),
         source(paths[3],'std::sort(entries_.begin()'),source(paths[4],'prepare_shared(binding.slot->native'),
         source(paths[6],'std::sort(entries_.begin()'),source(paths[7],'permissions.admit(batch)'),
         source(paths[8],'kv_chunk_size_ptr_offset'),source(paths[9],'equal active-request chunk counts'),
         source(paths[10],'const auto extent=std::max(old.size(),pages.size())')]
graph=(ROOT/paths[4]).read_text()
baseline=subprocess.check_output(['git','show','10129b90bbfc4d85c25e1595c823962b5a9c8146:'+paths[4]],text=True,encoding='utf8')
validation=next(line for line in graph.splitlines() if 'for(std::size_t i=0;i<layouts.size();++i){auto found=' in line)
assert validation in baseline
peer=json.loads((ROOT/'evidence/architecture/inference-g06-native-runtime-lengths-intake/intake.json').read_text(encoding='utf8'))['fixed_peer_anchor_reuse']
assert len(peer)==3 and {p['name'] for p in peer}=={'sglang','vllm','llama.cpp'}
ledger=[
 {'id':'M-active/export','changed':'Per immutable version backing is32+8*(requests+1)+4*page_refs+(paged?4*requests:0) bytes, plus the existing allocator/lease/mapping/control ownership. No max-capacity zeroing unless explicit export.','retained_cost':'Each successful version allocates active backing and control, copies active metadata, performs generation CAS and retains owners. Fixed-capacity metadata()/indices() explicitly allocate/zero/copy once and lock their cache on repeated calls; no whole-step allocation-free claim.','proof':required[:5]},
 {'id':'M-delta','changed':'Compare at most the old/new active extent; at most five word ranges for common wire fields, one actual changed-ID interval for the selected native bank. Clear only old active suffix and changed spans.','retained_cost':'CPU scanning remains O(active requests+page refs), an interval may contain unchanged interior words. Cold staging/mirrors have full fixed capacity; native uses two truthful per-bank identities. Common changed upload incurs one original checked F2 host wait.','proof':[required[5]]},
 {'id':'S-shared','changed':'The first prepared node uploads shared metadata once; later same-input/generation/resource nodes use the original checked-ready mirror before their own native planning.','retained_cost':'Each node still owns workspace/planning and its necessary waits. Existing complete-node-set validation has a worst-case cubic node search; the exact line predates G06 at baseline10129. Group/lookup passes remain quadratic in node count, separate from page admission. No linear whole-Graph prepare, all-shape latency or peer parity claim.','proof':['evidence/correctness/inference-g06-common-source-windows-attempt-4/receipt.json two dependent actual attention nodes, reversed NodeLayout order and three numeric/upload episodes']},
 {'id':'L-exact-permissions','changed':'Cold-reserved pointer scratch sorts the full admitted group by lease block identity, validates generation/permission and invokes the original unique/ordered unique F1 primitives once per unique group entry. O(G log G) comparisons plus O(G) original permission operations; warm scratch growth prohibited. Both Graph admission layers included in669.','retained_cost':'Scratch Entry is two pointers (16 bytes on qualified64-bit machines), vector control lives in private owners. Original per-block domain locks/refcounts/atomics, pending validation, lane waits and retirement remain; readonly guards in distinct layers/lanes can remain balanced duplicates. No permission bypass or process/native allocation certificate.','proof':['PagedAdmission.ExactBlocksDeduplicateSubviewsWithoutCollapsingSharedBacking','LeaseSubmission.ReorderedLargeGroupsDeduplicateAllBlocksWithoutWarmAllocation:256 distinct blocks,64 rebind/reorder/shrink episodes and independent active-use census']},
 {'id':'D-CPU','changed':'Q1 fixed-Q topology updates actual paged IDs/tails and ragged extents/packed offsets on the original graph/pool/workspace. O(requests+page refs) facts, no per-token native replan in qualified same-Q domain.','retained_cost':'Caller snapshot creation and metadata delta/wait stay charged. Changed Q topology/request set genuinely cold replans. Original masks/kernels and private scratch semantics remain.','proof':required[6:8]},
 {'id':'D-FI','changed':'O(requests) comparison at the original actual chunk/CTA/window proves schedule equivalence; reads four-byte chunk fact from original planner host shadow, no D2H. Equivalent runtime metadata skips query/plan/integer-plan upload.','retained_cost':'Crossing chunk/CTA schedule boundary replans; changed metadata still uploads/waits. Q0 no-op preserves explicit immediate-completion accounting. No retile or optimal schedule/total native-private cost claim.','proof':[required[8]]},
 {'id':'D-native','changed':'Fixed schema and complete Q topology retain original Apple/Vulkan C++ Program/Invocation/storage while host-known KV lengths and packed offsets update explicitly. Native paged banks upload actual changed IDs, unchanged IDs have zero upload/wait.','retained_cost':'Apple changed-length execution constructs a managed MLX graph; Vulkan changed scalars invalidate recording and re-encode. Ragged Vulkan contract adds cold shared immutable ownership copied by Recorder. Private native/driver allocation and cost remain UNKNOWN; this is not capture or zero native allocation.','proof':[required[10],'evidence/correctness/inference-g06-native-runtime-lengths-source/receipt.json','evidence/correctness/inference-g06-final-native-air-source/receipt.json actual Recorder copy/drop/replay oracle']},
 {'id':'D-capture','changed':'Explicit opt-in cold prepare_replay records original CUDA commands without executing caller tensor work or consuming its run token; exact storage/plan can retain the artifact. Run still takes actual F1/Queue/Completion path, idle capture releases page permissions.','retained_cost':'Cold capture checked wait/control allocation charged; changed storage needs explicit recapture and true replan invalidates artifact. CPU explicitly unsupported, Apple managed and Vulkan Recorder retain their own semantics. Graph outer generic capture flag remains false; internal batch atoms have actual limited capture proof.','proof':[required[9],'evidence/correctness/inference-g06-graph-page-cuda-risks/receipt.json recorded/launch/post-record-OOM failure and pending retirement']}
]
refs=['evidence/correctness/inference-g06-final-relocated-sdk/receipt.json','evidence/correctness/inference-g06-common-source-windows-attempt-4/receipt.json',
      'evidence/correctness/inference-g06-cpu-runtime-q1-source/receipt.json','evidence/correctness/inference-g06-cpu-ragged-runtime-source/receipt.json',
      'evidence/correctness/inference-g06-native-runtime-lengths-source/receipt.json','evidence/correctness/inference-g06-native-ragged-runtime-source/receipt.json',
      'evidence/correctness/inference-g06-fi-schedule-runtime-source/receipt.json','evidence/correctness/inference-g06-capture-replay-source/receipt.json',
      'evidence/correctness/inference-g06-graph-page-admission-windows-source/receipt.json','evidence/correctness/inference-g06-graph-page-cuda-risks/receipt.json',
      'evidence/architecture/inference-g06-graph-page-admission-audit/audit.json','evidence/architecture/inference-g06-final-cost-review/loc.json']
review={'state':'DRAFT_FINAL_COST_REVIEW_NOT_ACCEPTANCE','candidate':PRODUCT,'head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'timestamp_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'reviewer':'Codex/root, separate source/cost/red-team pass; same agent, not a second independent human reviewer','budget':'Original2h checkpoints/standing finite extensions; no new timing experiment or public tool changes.',
        'source_anchors':anchors,'evidence':[evidence(p) for p in refs],'fixed_peers':peer,'actual_required_sdk_cases':required,'cost_ledger':ledger,
        'performance_decision_pending':'Initial G06 declaration is P0/necessary P1. Byte/wait/allocation/schedule/per-page complexity promises have actual structural/oracle evidence. Before closure explicitly decide whether any unresolved timing mechanism needs a new frozen P1 contract; do not transform lack of same-contract peer timing into a parity or throughput verdict. Original G04/G05 kernel P1 remains unresolved and required independently.',
        'negative_space':['No full engine/model execution/tokenizer/server or tokens-per-second certificate.','No arbitrary topology changes without explicit replan, address changes without recapture, new route/provider domains, CPU capture or native Apple/Vulkan capture inferred from plan reuse.','No hard bound on unknown vendor/driver/private memory and no full-step zero allocation/wait.','Existing outer Graph node validation cost is retained explicitly; a real large-node consumer hotspot/material trace is a scoped reopen trigger, not a speculative extra product FIX.'],
        'red_team_findings':[{'id':'RT-L','severity':'major','finding':'Graph two-layer per-page admission remained quadratic after earlier Direct/native optimization.','disposition':'FIXED669; actual256-block independent-use census, source and three WSL host sanitizer qualifications, plus native current-host batch pending.'},{'id':'RT-platform-risk','severity':'major qualification','finding':'WSL sanitizer proof cannot stand for changed Apple/Vulkan native host branches.','disposition':'Original applicable six cached Air profiles are running; no final correctness/closure until their actual terminal proof.'},{'id':'RT-cost-claims','severity':'documentation/cost boundary','finding':'reused_native_plan and no injected HYLE allocation do not imply no managed native graphs/driver cost or no caller snapshot allocation.','disposition':'Keep explicit ledger and update final user guide before usability gate.'},{'id':'RT-node-validation','severity':'retained known cost','finding':'Outer complete-node-set validation has worst-case cubic lookup, distinct from page G.','disposition':'Exact baseline line unchanged; retained in P0 ledger, no newly observed consumer hotspot or material double-key to expand current FIX.'}],
        'remaining':['Finish actual six current Air sanitizer configurations and seal artifact/model/input proof.','Resolve final P0/necessary P1 applicability, seven gates, docs/usability and retained G04/G05 scope before any G06 aggregate acceptance/registry terminal change.']}
(BASE/'final-cost-review-draft.json').write_text(json.dumps(review,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
print(json.dumps({'state':review['state'],'cost_rows':len(ledger),'actual_required_cases':len(required),'source_anchors':len(anchors),'fixed_peers':len(peer)}))
