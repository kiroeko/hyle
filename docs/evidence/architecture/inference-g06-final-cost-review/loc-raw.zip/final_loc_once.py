from pathlib import Path
import hashlib, json, runpy, subprocess, sys, time

root=Path.cwd();out=root/'.scratch/inference-gaps/g06/final-loc';assert not out.exists()
assert json.loads((root/'.scratch/inference-gaps/g06/final-sdk-matrix-5.json').read_text())['state']=='TERMINAL_PASS'
assert not subprocess.check_output(['git','status','--porcelain'],text=True).strip()
product='669121418669b31f6849c74f64362aaf8d6eb919'
assert not subprocess.check_output(['git','diff','--name-only',product,'HEAD','--','include','src','cmake','CMakeLists.txt'],text=True).strip()
loc=runpy.run_path(str(root/'scripts/loc-report.py'))
tracked,missing=loc['tracked_worktree_files'](root);assert not missing
registry=json.loads((root/'docs/implementation/module-status.json').read_text(encoding='utf8'))
owners=[r['module'] for r in registry['modules'] if 'inference-g06' in r.get('record','')]
assert len(owners)==11
graph=loc['snapshot_component_graph'](root,'WORKTREE')
files=loc['files_under'](tracked,loc['SELF_WITHOUT_TESTS_ROOTS'])
files=[p for p in files if Path(p).suffix.lower() in loc['NATIVE_SUFFIXES']]
boundary=[{'path':p,'owner':loc['component_owner'](p,graph['factors']),'sha256':hashlib.sha256((root/p).read_bytes()).hexdigest()} for p in files if loc['component_owner'](p,graph['factors']) in owners]
assert boundary and set(r['owner'] for r in boundary)==set(owners)
args=[sys.executable,'-X','utf8','scripts/loc-report.py','--module','g06-owner-union','--self-check','--json']
for row in boundary:args+=['--module-path',row['path']]
assert len(subprocess.list2cmdline(args))<28000
out.mkdir(parents=True);start=time.monotonic()
with (out/'report.json').open('w',encoding='utf8') as output,(out/'stderr.log').open('w') as errors:
    subprocess.run(args,check=True,stdout=output,stderr=errors)
report=json.loads((out/'report.json').read_text(encoding='utf8'));assert not report['repository']['dirty']
record={'product_candidate':product,'snapshot_head':report['repository']['commit'],'policy':'Official CLI on the clean tracked worktree; all include/src/cmake/root product files are identical to immutable candidate669. A single explicit unique union of the11 current G06 owners is derived from the unchanged official central-component projector, not from a15-owner registry state or sums of historical snapshots. Repository/doc totals refer to this clean evidence HEAD; product implementation totals refer to identical candidate product inputs.','owners':owners,'boundary':boundary,'elapsed_seconds':time.monotonic()-start,'command':args,'report_sha256':hashlib.sha256((out/'report.json').read_bytes()).hexdigest()}
(out/'boundary.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({'owners':len(owners),'boundary_files':len(boundary),'metrics':[(r['id'],r['code'],r['files']) for r in report['metrics']],'elapsed_seconds':record['elapsed_seconds']}))
