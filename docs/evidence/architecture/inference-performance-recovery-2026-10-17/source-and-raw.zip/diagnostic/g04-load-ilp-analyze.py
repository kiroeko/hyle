from pathlib import Path
import bisect,hashlib,json,sqlite3,statistics
root=Path('/mnt/c/public/project-hyle/hyle');out=root/'.scratch/inference-performance-recovery-2026-10-17'
run=json.loads((out/'g04-load-ilp-execution/receipt.json').read_text())
assert run['state']=='FINITE_CAPTURE_COMPLETE_NOT_P1' and run['artifacts_unchanged']
assert len(run['commands'])==13 and len(run['timeline_pairs'])==4
link=json.loads((out/'g04-load-ilp-link-receipt.json').read_text())
expected={name:k['function'] for name,k in link['linked_kernel_review']['kernels']['control'].items()}
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
results=[];paired=[]
for pair in run['timeline_pairs']:
    processes={}
    for process in pair['processes']:
        mode=process['mode'];trace=Path(process['timeline']['sqlite'])
        assert sha(trace)==process['timeline']['sqlite_sha256']
        db=sqlite3.connect(trace.as_uri()+'?mode=ro&immutable=1',uri=True)
        nv=db.execute('select start,end,text from NVTX_EVENTS where end is not null order by start').fetchall()
        episodes=[x for x in nv if x[2] in ['candidate.episode','peer.episode']]
        assert len(episodes)==3072,len(episodes)
        starts=[x[0] for x in episodes]
        shapes=[x for x in nv if x[2] in ['window','prefill','holdout']]
        assert len(shapes)==3
        launches={}
        for table in ['CUPTI_ACTIVITY_KIND_RUNTIME','CUPTI_ACTIVITY_KIND_DRIVER']:
            if not db.execute('select count(*) from sqlite_master where name=?',(table,)).fetchone()[0]:continue
            for row in db.execute('select start,end,correlationId from '+table):launches.setdefault(row[2],[]).append(row)
        gpu=db.execute('select k.start,k.end,k.correlationId,m.value,d.value,k.registersPerThread,k.dynamicSharedMemory,k.gridX,k.gridY,k.gridZ,k.blockX,k.blockY,k.blockZ,k.localMemoryPerThread from CUPTI_ACTIVITY_KIND_KERNEL k join StringIds m on k.mangledName=m.id join StringIds d on k.demangledName=d.id order by k.start').fetchall()
        mapped={};resources={}
        for a,b,corr,mangled,demangled,*resource in gpu:
            candidates=launches.get(corr,[])
            if not candidates:continue
            launch=min(candidates,key=lambda x:x[0]);i=bisect.bisect_right(starts,launch[0])-1
            if i<0 or not episodes[i][0]<=launch[0]<=episodes[i][1]:continue
            begin,end,label=episodes[i]
            shape=next(x[2] for x in shapes if x[0]<=begin and end<=x[1])
            kind='attention' if 'BatchPrefillWithPagedKVCacheKernel' in demangled else ('merge' if 'MergeStates' in demangled else None)
            assert kind and 'hyle_benchmark_original_flashinfer_69ff' not in demangled
            assert mangled==expected[shape if kind=='attention' else 'merge']
            mapped.setdefault(i,[]).append((a,b,kind))
            value={'mangled':mangled,'demangled':demangled,'registers':resource[0],'dynamic_shared':resource[1],'grid':resource[2:5],'block':resource[5:8],'local_bytes':resource[8]}
            key=(shape,label.split('.')[0],kind)
            if key in resources:assert resources[key]==value
            else:resources[key]=value
        assert sum(map(len,mapped.values()))==4096
        groups={}
        for i,(begin,end,label) in enumerate(episodes):
            shape=next(x[2] for x in shapes if x[0]<=begin and end<=x[1]);side=label.split('.')[0]
            kernels=mapped[i];assert len(kernels)==(2 if shape=='prefill' else 1)
            values={kind:(b-a)/1000 for a,b,kind in kernels};values.setdefault('merge',0.)
            values.update(gpu_sum=values['attention']+values['merge'],gpu_gap=(kernels[-1][0]-kernels[0][1])/1000 if len(kernels)==2 else 0.,episode=(end-begin)/1000)
            groups.setdefault((shape,side),[]).append(values)
        summary=[]
        for shape in ['window','prefill','holdout']:
            row={'shape':shape,'contexts':{}}
            for side in ['candidate','peer']:
                values=groups[shape,side];assert len(values)==512
                row['contexts'][side]={key:{'median_us':statistics.median(x[key] for x in values),'mean_us':statistics.mean(x[key] for x in values),'group64_mean_us':[statistics.mean(x[key] for x in values[j:j+64]) for j in range(0,512,64)]} for key in values[0]}
            row['both_contexts']={key:{'median_us':statistics.median([x[key] for side in ['candidate','peer'] for x in groups[shape,side]]),'mean_us':statistics.mean([x[key] for side in ['candidate','peer'] for x in groups[shape,side]])} for key in groups[shape,'candidate'][0]}
            row['same_implementation_peer_over_candidate']={key:row['contexts']['peer'][key]['median_us']/row['contexts']['candidate'][key]['median_us'] for key in ['attention','gpu_sum','episode']}
            for kind in ['attention']+(['merge'] if shape=='prefill' else []):
                assert resources[shape,'candidate',kind]==resources[shape,'peer',kind]
                assert resources[shape,'candidate',kind]['local_bytes']==0
            summary.append(row)
        result={'pair':pair['pair'],'mode':mode,'allocation':pair['allocation'],'execution_order':pair['execution_order'],'sqlite_sha256':sha(trace),'episodes':len(episodes),'raw_trace_kernels':len(gpu),'mapped_timed_kernels':sum(map(len,mapped.values())),'outside_timed_episodes_kernels':len(gpu)-sum(map(len,mapped.values())),'resources':[dict(shape=shape,context=side,kind=kind,**v) for (shape,side,kind),v in resources.items()],'summary':summary}
        results.append(result);processes[mode]=result
        db.close()
    comparison={'pair':pair['pair'],'allocation':pair['allocation'],'execution_order':pair['execution_order'],'process_order':pair['process_order'],'shapes':[]}
    for shape in ['window','prefill','holdout']:
        c=next(r for r in processes['control']['summary'] if r['shape']==shape)
        t=next(r for r in processes['treatment']['summary'] if r['shape']==shape)
        row={'shape':shape,'delta_treatment_minus_control_us':{},'latency_change_percent':{},'contexts':{}}
        for key in ['attention','merge','gpu_sum','episode']:
            cv=c['both_contexts'][key]['median_us'];tv=t['both_contexts'][key]['median_us']
            row['delta_treatment_minus_control_us'][key]=tv-cv
            row['latency_change_percent'][key]=100*(tv/cv-1) if cv else None
        for side in ['candidate','peer']:
            row['contexts'][side]={key:{'control_median_us':c['contexts'][side][key]['median_us'],'treatment_median_us':t['contexts'][side][key]['median_us'],'latency_change_percent':100*(t['contexts'][side][key]['median_us']/c['contexts'][side][key]['median_us']-1)} for key in ['attention','gpu_sum','episode']}
        # Launch geometry and all resources except the expected prefill register delta match.
        for kind in ['attention']+(['merge'] if shape=='prefill' else []):
            cr=next(x for x in processes['control']['resources'] if x['shape']==shape and x['context']=='candidate' and x['kind']==kind)
            tr=next(x for x in processes['treatment']['resources'] if x['shape']==shape and x['context']=='candidate' and x['kind']==kind)
            for key in ['mangled','dynamic_shared','grid','block','local_bytes']:assert cr[key]==tr[key]
            assert (cr['registers'],tr['registers'])==((248,250) if shape=='prefill' and kind=='attention' else (cr['registers'],cr['registers']))
        comparison['shapes'].append(row)
    paired.append(comparison)
analysis={'state':'FINITE_LOAD_ILP_DIAGNOSTIC_ANALYZED_NOT_P1','source_run_sha256':sha(out/'g04-load-ilp-execution/receipt.json'),'all_artifacts_unchanged':True,'bf16_peer_linked':False,'implementation_comparison':'separate full-TU-linked processes; two same-implementation contexts in each process','total_episodes':sum(x['episodes'] for x in results),'total_raw_trace_kernels':sum(x['raw_trace_kernels'] for x in results),'total_mapped_timed_kernels':sum(x['mapped_timed_kernels'] for x in results),'total_outside_timed_episodes_kernels':sum(x['outside_timed_episodes_kernels'] for x in results),'kernel_count_scope':'Only kernels correlated to measured candidate.episode/peer.episode NVTX ranges are timed below. Raw traces also contain initialization/oracle/warmup launches outside those ranges.','processes':results,'paired_processes':paired,'limits':['All four pairs and both contexts retained; no favorable selection or new samples.','Unchanged window/holdout drift establishes an unresolved cross-process timing/resource perturbation; no runtime frequency/power telemetry was collected, so no clock cause is established. No negative-control subtraction, statistical qualification or pure-ILP attribution.','Host episode durations and GPU kernel durations are separate; no wall-minus-kernel-sum CPU claim.','Original attempt14 contract/verdict and old cropped-bridge erratum remain unchanged.']}
(out/'g04-load-ilp-runtime-analysis.json').write_text(json.dumps(analysis,indent=2)+'\n')
for comparison in paired:
    print('pair',comparison['pair'],'allocation',comparison['allocation'],'execution',comparison['execution_order'])
    for row in comparison['shapes']:print(row['shape'],json.dumps(row['latency_change_percent']),json.dumps(row['delta_treatment_minus_control_us']))
print('TOTAL episodes/raw kernels/mapped timed kernels/outside timed',analysis['total_episodes'],analysis['total_raw_trace_kernels'],analysis['total_mapped_timed_kernels'],analysis['total_outside_timed_episodes_kernels'])
