from pathlib import Path
import hashlib,json,os,subprocess,time
root=Path('/mnt/c/public/project-hyle/hyle');out=root/'.scratch/inference-performance-recovery-2026-10-17'
record=json.loads((out/'g04-load-ilp-link-receipt.json').read_text());work=Path(record['work'])
assert 'boundary_amendment' in record and 'final_review_markers' not in record
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
source=work/'bench/inference_resident_sdpa/cuda_encoded_page_bench.cc'
assert sha(source)==record['source_diagnostic_sha256']
old=source.read_text();anchor='  if(verify_only)measure(64,128,1023,767,256,256,true,-1);'
assert old.count(anchor)==1
source.write_text(old.replace(anchor,'''  if(verify_only){
    std::fprintf(stderr,"# LOAD_ILP_VERIFY_TAIL Q=64,128 KV=1023,767 D=256 causal=1 window=-1\\n");
    measure(64,128,1023,767,256,256,true,-1);
  }
  std::fprintf(stderr,"# LOAD_ILP_APP_EXIT code=0\\n");
  return 0;'''))
record['final_review_markers']={'source_before_sha256':record['source_diagnostic_sha256'],'source_after_sha256':sha(source),'old_binaries':record['binaries']}
record['source_diagnostic_sha256']=sha(source)
allowed=sorted(os.sched_getaffinity(0));os.sched_setaffinity(0,allowed[:4]);os.nice(10)
cmd=['cmake','--build',str(work/'build'),'--parallel','2','--target','load_ilp_control','load_ilp_treatment'];start=time.monotonic()
with (out/'g04-load-ilp-final-relink.log').open('w') as log:p=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT)
record['final_review_markers'].update(command=cmd,exit_code=p.returncode,seconds=time.monotonic()-start);assert p.returncode==0
for b in record['binaries']:
    assert sha(work/f"native_cache_{b['mode']}.o")==b['native_object_sha256']
    b['sha256']=sha(b['path'])
    mapping=work/'build'/f"load_ilp_{b['mode']}.map"
    assert f"native_cache_{b['mode']}.o" in mapping.read_text()
    assert 'libhyle_compute_provider_flashinfer.a(native_cache.cu.o)' not in mapping.read_text()
    b['map_sha256']=sha(mapping)
(out/'g04-load-ilp-link-receipt.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({'state':record['state'],'binaries':record['binaries'],'source_sha256':record['source_diagnostic_sha256'],'final_link_seconds':record['final_review_markers']['seconds']},indent=2))
