from pathlib import Path
import argparse, hashlib, json, os, platform, re, signal, subprocess, time

parser=argparse.ArgumentParser()
parser.add_argument('--execute-reviewed-gpu',action='store_true')
args=parser.parse_args()
assert args.execute_reviewed_gpu, 'Preparation only; coordinating-owner execution review required'
root=Path('/mnt/c/public/project-hyle/hyle')
out=root/'.scratch/inference-performance-recovery-2026-10-17'
link=json.loads((out/'g04-load-ilp-link-receipt.json').read_text())
assert link['state']=='LINK_ONLY_PASS_PENDING_EXECUTION_REVIEW'
run_dir=out/'g04-load-ilp-execution'
assert not run_dir.exists(), 'Do not overwrite or repeat this finite execution'
run_dir.mkdir()
work=Path(link['work'])
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
binaries={b['mode']:b for b in link['binaries']}
for b in binaries.values(): assert sha(b['path'])==b['sha256']
compiled=json.loads((out/'g04-load-ilp-compile-receipt.json').read_text())
for mode,b in binaries.items():
    expected=compiled['control_object']['sha256'] if mode=='control' else compiled['candidate_object_sha256']
    assert b['native_object_sha256']==expected and sha(work/f'native_cache_{mode}.o')==expected
frozen_paths=[Path(__file__),out/'g04-load-ilp-compile-receipt.json',out/'g04-load-ilp-link-receipt.json',out/'g04-load-ilp-variant.patch',work/'CMakeLists.txt',work/'bench/inference_resident_sdpa/cuda_encoded_page_bench.cc',work/'bench/inference_resident_sdpa/cuda_encoded_page_reference.h',work/'bench/common/perf_process.h',Path(compiled['original_compile_record']['file']),Path(compiled['work'])/'include/flashinfer/attention/prefill.cuh']
frozen_paths += [Path(b['path']) for b in binaries.values()] + [work/f'native_cache_{mode}.o' for mode in binaries]
frozen={str(p):sha(p) for p in frozen_paths}
available=os.sched_getaffinity(0);assert 2 in available
os.sched_setaffinity(0,{2})
env=os.environ.copy()
for key in ['HYLE_PERF_CALLER_CPU','HYLE_DIAG_TRACE','HYLE_DIAG_MATRIX','HYLE_CAUSAL_VARIANT','HYLE_BENCH_VERIFY_ONLY','HYLE_BENCH_AA_ROUTE','HYLE_BENCH_RIVAL_FIRST','HYLE_BENCH_PEER_ALLOCATION_FIRST','HYLE_PERF_RUN_NONCE']:
    env.pop(key,None)
env.update(CUDA_VISIBLE_DEVICES='0',HYLE_BENCH_AA_ROUTE='selected')
record={'state':'EXECUTION_STARTED','kind':'DIAGNOSTIC_ONLY_NOT_P1','host':{'platform':platform.platform(),'affinity':sorted(os.sched_getaffinity(0)),'nice':os.nice(0)},'artifacts_before':frozen,'implementation_comparison':'separate processes; each process has two instances of the same FP8/F32 implementation','binaries':link['binaries'],'bf16_peer_linked':False,'commands':[],'formal_p1_run':False,'product_changed':False,'gpu_executed':False}
record['host']['nvidia_smi_identity']=subprocess.check_output(['/usr/lib/wsl/lib/nvidia-smi','--query-gpu=name,uuid,driver_version,pci.bus_id','--format=csv,noheader'],text=True).strip()
record['host']['tool_versions']={name:subprocess.check_output(command,text=True,stderr=subprocess.STDOUT).strip() for name,command in {'nvcc':['/usr/local/cuda-13.3/bin/nvcc','--version'],'nsys':['nsys','--version'],'compute_sanitizer':['/usr/local/cuda-13.3/bin/compute-sanitizer','--version']}.items()}
save=lambda:(run_dir/'receipt.json').write_text(json.dumps(record,indent=2)+'\n')
save()
def terminate_owned_group(child):
    # start_new_session makes this exact child PID our owned process-group ID.
    cleanup={'owned_process_group':child.pid,'reason':'abnormal profiler/application termination','signals':[]}
    try:os.killpg(child.pid,signal.SIGTERM)
    except ProcessLookupError:pass
    else:cleanup['signals'].append('SIGTERM')
    try:child.wait(timeout=15)
    except subprocess.TimeoutExpired:
        try:os.killpg(child.pid,signal.SIGKILL)
        except ProcessLookupError:pass
        else:cleanup['signals'].append('SIGKILL')
        child.wait()
    # The profiler may exit before its application; kill any remaining owned group.
    try:os.killpg(child.pid,signal.SIGKILL)
    except ProcessLookupError:pass
    else:cleanup['signals'].append('SIGKILL-remaining-owned-group')
    cleanup['wait_returncode']=child.returncode
    record.setdefault('owned_group_cleanup',[]).append(cleanup);save()
def run(label,command,changes):
    local=env.copy();local.update(changes)
    start=time.monotonic();log=run_dir/(label+'.log')
    record.update(active_stage=label);save()
    with log.open('w') as stream:
        child=subprocess.Popen(command,env=local,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
        try:
            assert os.getsid(child.pid)==child.pid and os.getpgid(child.pid)==child.pid
            record['gpu_executed']=True
            record['active_pid']=child.pid;save()
            code=child.wait(timeout=180)
        except BaseException:
            terminate_owned_group(child)
            record.update(state='TERMINAL_TIMEOUT_NATIVE_RETIREMENT_UNPROVEN');save();raise
    row={'stage':label,'command':command,'environment':changes,'exit_code':code,'seconds':time.monotonic()-start,'log_sha256':sha(log)}
    record['commands'].append(row);save();print(label,code,round(row['seconds'],3),flush=True)
    text=log.read_text()
    if code or text.count('LOAD_ILP_APP_EXIT code=0')!=1:
        terminate_owned_group(child)
        record['state']='TERMINAL_FAIL';save();raise RuntimeError(label+' abnormal application/profiler exit')
    return text,row
def check_oracles(text,count):
    errors=[float(x) for x in re.findall(r'CORRECTNESS max_abs_error=([^ ]+)',text)]
    assert len(errors)==count and max(errors)<=8e-3, (len(errors),max(errors) if errors else None)
    shapes=4 if count==32 else 3
    assert text.count('CUDA_ENCODED_TEARDOWN')==2*shapes
    assert text.count('CUDA_FP8_PAIR')==shapes
    assert text.count('LOAD_ILP_APP_EXIT code=0')==1
    assert text.count('LOAD_ILP_VERIFY_TAIL')==(1 if count==32 else 0)
    cuda_lines=sorted(set(re.findall(r'# CUDA_ENCODED_ENV ([^\n]+)',text)))
    assert len(cuda_lines)==1 and 'sm=89' in cuda_lines[0]
    if 'cuda_environment' not in record:record['cuda_environment']=cuda_lines
    else:assert cuda_lines==record['cuda_environment']
    return max(errors)
try:
    for mode in ['control','treatment']:
        binary=binaries[mode]['path']
        text,row=run(mode+'-oracle',[binary],{'HYLE_BENCH_VERIFY_ONLY':'1'})
        row['oracle_max_abs_error']=check_oracles(text,32);save()
        text,row=run(mode+'-memcheck',['/usr/local/cuda-13.3/bin/compute-sanitizer','--tool','memcheck','--error-exitcode','86',binary],{'HYLE_BENCH_VERIFY_ONLY':'1'})
        row['oracle_max_abs_error']=check_oracles(text,32)
        assert 'ERROR SUMMARY: 0 errors' in text;row['memcheck']='PASS';save()
        if mode=='treatment':
            text,row=run(mode+'-racecheck',['/usr/local/cuda-13.3/bin/compute-sanitizer','--tool','racecheck','--racecheck-num-workers','4','--error-exitcode','86',binary],{'HYLE_BENCH_VERIFY_ONLY':'1'})
            row['oracle_max_abs_error']=check_oracles(text,32)
            assert 'RACECHECK SUMMARY: 0 hazards displayed (0 errors, 0 warnings)' in text
            row['racecheck']='PASS';save()
    record['timeline_pairs']=[];save()
    matrix=[(0,0,['control','treatment']),(0,1,['treatment','control']),(1,0,['treatment','control']),(1,1,['control','treatment'])]
    for pair,(allocation,order,modes) in enumerate(matrix):
        group={'pair':pair,'allocation':allocation,'execution_order':order,'process_order':modes,'processes':[]};record['timeline_pairs'].append(group);save()
        for mode in modes:
            report=work/f'load-ilp-pair{pair}-{mode}'
            assert not report.with_suffix('.nsys-rep').exists()
            changes={'HYLE_DIAG_TRACE':'1','HYLE_PERF_RUN_NONCE':f'g04-load-ilp-20261017-{pair}-{mode}'}
            if allocation: changes['HYLE_BENCH_PEER_ALLOCATION_FIRST']='1'
            if order:changes['HYLE_BENCH_RIVAL_FIRST']='1'
            text,row=run(f'pair{pair}-{mode}',['nsys','profile','--trace=cuda,nvtx','--sample=none','--cpuctxsw=none','--export=sqlite','--force-overwrite=false','--output='+str(report),binaries[mode]['path']],changes)
            row['oracle_max_abs_error']=check_oracles(text,30)
            points=re.findall(r'CAUSAL_DIAG shape=(\S+) group=(\d+) trace=1 candidate_us=([^ ]+) peer_us=([^\n]+)',text)
            assert len(points)==24 and sorted(set(x[0] for x in points))==['holdout','prefill','window']
            row['timeline']={'sqlite':str(report.with_suffix('.sqlite')),'sqlite_sha256':sha(report.with_suffix('.sqlite')),'nsys_report':str(report.with_suffix('.nsys-rep'))}
            group['processes'].append({'mode':mode,'stage':row['stage'],'timeline':row['timeline']});save()
    for b in binaries.values():assert sha(b['path'])==b['sha256']
    record.update(state='FINITE_CAPTURE_COMPLETE_NOT_P1',gpu_executed=True)
except Exception as error:
    if not record['state'].startswith('TERMINAL_'):record['state']='TERMINAL_ASSERTION_FAIL'
    record['failure']=repr(error);save();raise
finally:
    record['artifacts_after']={str(p):sha(p) for p in frozen_paths}
    record['artifacts_unchanged']=record['artifacts_after']==record['artifacts_before']
    if not record['artifacts_unchanged']:record['state']='TERMINAL_ARTIFACT_CHANGED'
    record.pop('active_pid',None);record.pop('active_stage',None);save()
print(record['state'],flush=True)
