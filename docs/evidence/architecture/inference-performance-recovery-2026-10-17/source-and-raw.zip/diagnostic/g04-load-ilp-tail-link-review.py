from pathlib import Path
import hashlib,json,os,re,subprocess,time
root=Path('/mnt/c/public/project-hyle/hyle');out=root/'.scratch/inference-performance-recovery-2026-10-17'
record=json.loads((out/'g04-load-ilp-link-receipt.json').read_text());work=Path(record['work'])
assert record['state']=='LINK_ONLY_PASS_PENDING_EXECUTION_REVIEW' and 'boundary_amendment' not in record
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
source=work/'bench/inference_resident_sdpa/cuda_encoded_page_bench.cc'
assert sha(source)==record['source_diagnostic_sha256']
old=source.read_text();anchor='''  }else all_shapes();
}''';assert old.count(anchor)==1
source.write_text(old.replace(anchor,'''  }else all_shapes();
  // Review-mandated D256 tail: numerical/tool validation only, never timing.
  if(verify_only)measure(64,128,1023,767,256,256,true,-1);
}'''))
record['boundary_amendment']={'source_before_sha256':record['source_diagnostic_sha256'],'source_after_sha256':sha(source),'shape':'VERIFY_ONLY/sanitizer Q64/128 KV1023/767 D256 causal/unbounded only','old_binaries':record['binaries']}
record['source_diagnostic_sha256']=sha(source)
allowed=sorted(os.sched_getaffinity(0));os.sched_setaffinity(0,allowed[:4]);os.nice(10)
cmd=['cmake','--build',str(work/'build'),'--parallel','2','--target','load_ilp_control','load_ilp_treatment']
start=time.monotonic()
with (out/'g04-load-ilp-tail-relink.log').open('w') as log: proc=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT)
record['boundary_amendment'].update(command=cmd,exit_code=proc.returncode,seconds=time.monotonic()-start)
assert proc.returncode==0
compile_record=json.loads((out/'g04-load-ilp-compile-receipt.json').read_text())
runtime=json.loads((root/'evidence/architecture/inference-g04-g05-cuda-ce28-producer-stage/runtime-receipt.json').read_text())
targets={name:k['mangled'] for name,k in zip(['window','prefill','holdout'],runtime['actual_kernels'])}
targets['merge']=runtime['actual_merge']['mangled']
object_shas={'control':compile_record['control_object']['sha256'],'treatment':compile_record['candidate_object_sha256']}
by_mode={};record['binaries']=[]
for mode in ['control','treatment']:
    binary=work/'build'/f'load_ilp_{mode}';obj=work/f'native_cache_{mode}.o'
    assert sha(obj)==object_shas[mode]
    map_path=work/'build'/f'load_ilp_{mode}.map';mapping=map_path.read_text()
    assert f'native_cache_{mode}.o' in mapping
    assert not re.search(r'libhyle_compute_provider_flashinfer\.a\(native_cache\.cu\.o\)',mapping)
    assert 'libg04_cuda_encoded_original' not in mapping
    sass=subprocess.check_output(['/usr/local/cuda-13.3/bin/cuobjdump','--dump-sass','--function',','.join(targets.values()),str(binary)],text=True)
    (out/f'g04-load-ilp-linked-{mode}-sass.txt').write_text(sass)
    kernels={};current=None
    for line in sass.splitlines():
        m=re.search(r'Function\s*:\s*(\S+)',line)
        if m:
            current=next((name for name,target in targets.items() if target==m[1]),None)
            assert current not in kernels
            if current:kernels[current]={'instructions':[],'function':m[1]}
        if current:
            m=re.search(r'/\*([0-9a-fA-F]+)\*/\s+((?:@!?P\d+\s+)?([A-Z][A-Z0-9_]*(?:\.[A-Z0-9_]+)*)[^;]*;)',line)
            if m:kernels[current]['instructions'].append(m[2])
    assert set(kernels)==set(targets)
    for name,k in kernels.items():
        k.update(normalized_sass_sha256=hashlib.sha256('\n'.join(k['instructions']).encode()).hexdigest(),static_instructions=len(k['instructions']))
        k.pop('instructions')
    by_mode[mode]=kernels
    record['binaries'].append({'mode':mode,'path':str(binary),'sha256':sha(binary),'native_object_sha256':sha(obj),'no_bf16_peer_symbol_or_link':True,'explicit_native_object_in_map':True,'sdk_native_cache_archive_member_not_extracted':True,'map_sha256':sha(map_path)})
assert by_mode['control']['prefill']['normalized_sass_sha256']=='3e3ea55d912657cf12b7873dc7f06d84de1689069fad126fcdffd83033615ea9'
assert by_mode['treatment']['prefill']['normalized_sass_sha256']=='7f555eae49d6c662123410e3d7e423c4d7227ae9e4ab054fd60a700aa7af15a6'
record['linked_kernel_review']={'kernels':by_mode,'unchanged_negative_controls':{name:by_mode['control'][name]['normalized_sass_sha256']==by_mode['treatment'][name]['normalized_sass_sha256'] for name in ['window','holdout','merge']},'runtime_dispatch_pending':True}
assert all(record['linked_kernel_review']['unchanged_negative_controls'].values())
(out/'g04-load-ilp-link-receipt.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({'state':record['state'],'boundary_amendment':record['boundary_amendment'],'binaries':record['binaries'],'linked_kernel_review':record['linked_kernel_review']},indent=2))
