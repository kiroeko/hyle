from pathlib import Path
import hashlib, json, os, shutil, subprocess, time, zipfile

root=Path('/mnt/c/public/project-hyle/hyle')
out=root/'.scratch/inference-performance-recovery-2026-10-17'
compile_record=json.loads((out/'g04-load-ilp-compile-receipt.json').read_text())
assert compile_record['state']=='COMPILE_ONLY_PASS' and not compile_record['gpu_executed']
work=Path(compile_record['work'])/'consumer'
assert not work.exists()
work.mkdir()
allowed=sorted(os.sched_getaffinity(0));os.sched_setaffinity(0,allowed[:4]);os.nice(10)
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
z=zipfile.ZipFile(root/'evidence/architecture/inference-g04-g05-c1-packed-conversion/raw.zip')
bench=z.read('sources/direct/bench/inference_resident_sdpa/cuda_encoded_page_bench.cc').decode()
source_original_sha=hashlib.sha256(bench.encode()).hexdigest()
changes=[
 ('  std::unique_ptr<hyle::bench::resident::CudaEncodedReferenceData> reference;\n',''),
 ('    if(original)reference=std::make_unique<hyle::bench::resident::CudaEncodedReferenceData>();\n',''),
 ('''    context=take(c::Context::create(take(c::cuda::device(0)),original?
        hyle::bench::resident::cuda_encoded_reference_provider(reference.get()):c::flashinfer::provider()));''',
  '''    context=take(c::Context::create(take(c::cuda::device(0)),c::flashinfer::provider()));'''),
 ('    if(original)check(hyle::bench::resident::prepare_cuda_encoded_reference(*reference,queue,layout,key_frame,value_frame,memory.ref()));\n',''),
 ('keys={};values={};reference.reset();','keys={};values={};'),
 ('  const auto all_shapes=[](){measure(64,128,1024,768,256,256,true,-1);};',
  '  const auto all_shapes=[](){measure(1,17,1024,768,256,256,true,16);measure(64,128,1024,768,256,256,true,-1);measure(17,1,7,47,64,128,false,-1);};'),
 ('paired_mode=nanobench-compare paired_rounds=16','paired_mode=two-identical-instance-control paired_rounds=8'),
 ('arithmetic_group_size=2048','arithmetic_group_size=64'),
]
for old,new in changes:
    assert bench.count(old)==1, old
    bench=bench.replace(old,new)
assert 'cuda_encoded_reference_provider' not in bench and 'prepare_cuda_encoded_reference' not in bench
for relative,data in [
 ('bench/inference_resident_sdpa/cuda_encoded_page_bench.cc',bench.encode()),
 ('bench/inference_resident_sdpa/cuda_encoded_page_reference.h',z.read('sources/direct/bench/inference_resident_sdpa/cuda_encoded_page_reference.h')),
 ('bench/common/perf_process.h',z.read('sources/direct/bench/common/perf_process.h')),
]:
    path=work/relative;path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(data)
for mode,path in [('control',Path(compile_record['control_object']['path'])),('treatment',Path(compile_record['work'])/'native_cache_load_ilp.o')]:
    shutil.copy2(path,work/f'native_cache_{mode}.o')
sdk=Path('/root/hyle-scratch/compute-unified/g06-final-sdk/cuda-static-1/relocated')
cmake='''cmake_minimum_required(VERSION 3.25)
project(g04_load_ilp_consumer LANGUAGES C CXX)
find_package(Hyle CONFIG REQUIRED COMPONENTS compute graph)
foreach(mode IN ITEMS control treatment)
 add_executable(load_ilp_${mode} bench/inference_resident_sdpa/cuda_encoded_page_bench.cc "${CMAKE_CURRENT_SOURCE_DIR}/native_cache_${mode}.o")
 target_compile_features(load_ilp_${mode} PRIVATE cxx_std_23)
 target_include_directories(load_ilp_${mode} PRIVATE "@ROOT@/src/compute_backend_cuda" "/usr/local/cuda-13.3/include" "@ROOT@/third_party/nanobench")
 target_compile_options(load_ilp_${mode} PRIVATE -Wall -Wextra -Wpedantic -Werror)
 target_link_libraries(load_ilp_${mode} PRIVATE hyle::compute CUDA::cudart dl)
 target_link_options(load_ilp_${mode} PRIVATE "-Wl,-Map=${CMAKE_CURRENT_BINARY_DIR}/load_ilp_${mode}.map")
 set_property(TARGET load_ilp_${mode} PROPERTY INTERPROCEDURAL_OPTIMIZATION FALSE)
 hyle_stage_runtime(load_ilp_${mode})
endforeach()
'''.replace('@ROOT@',str(root))
(work/'CMakeLists.txt').write_text(cmake)
record={'state':'LINK_SETUP','work':str(work),'sdk':str(sdk),'affinity':sorted(os.sched_getaffinity(0)),'nice':os.nice(0),'source_original_sha256':source_original_sha,'source_diagnostic_sha256':sha(work/'bench/inference_resident_sdpa/cuda_encoded_page_bench.cc'),'gpu_executed':False,'bf16_peer_linked':False,'stages':[]}
env=os.environ.copy();env['PATH']='/usr/local/cuda-13.3/bin:'+env['PATH']
save=lambda:(out/'g04-load-ilp-link-receipt.json').write_text(json.dumps(record,indent=2)+'\n')
for label,cmd in [
 ('configure',['cmake','-S',str(work),'-B',str(work/'build'),'-G','Ninja','-DCMAKE_CXX_COMPILER=g++-14','-DCMAKE_C_COMPILER=gcc-14','-DCMAKE_BUILD_TYPE=Release','-DCMAKE_PREFIX_PATH='+str(sdk)]),
 ('link',['cmake','--build',str(work/'build'),'--parallel','2','--target','load_ilp_control','load_ilp_treatment'])]:
    start=time.monotonic()
    with (out/f'g04-load-ilp-{label}.log').open('w') as log:
        p=subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT)
    record['stages'].append({'label':label,'command':cmd,'seconds':time.monotonic()-start,'exit_code':p.returncode});save()
    if p.returncode:record['state']='LINK_FAIL';save();raise RuntimeError(label)
record['binaries']=[]
for mode in ['control','treatment']:
    binary=work/'build'/f'load_ilp_{mode}'
    symbols=subprocess.check_output(['nm','-C',str(binary)],text=True)
    assert 'hyle_benchmark_original_flashinfer_69ff' not in symbols
    commands=subprocess.check_output(['ninja','-C',str(binary.parent),'-t','commands',binary.name],text=True)
    assert 'libg04_cuda_encoded_original' not in commands and 'cuda_encoded_page_reference.cc.o' not in commands
    (out/f'g04-load-ilp-{mode}-link-command.txt').write_text(commands)
    record['binaries'].append({'mode':mode,'path':str(binary),'sha256':sha(binary),'native_object_sha256':sha(work/f'native_cache_{mode}.o'),'no_bf16_peer_symbol_or_link':True})
record['state']='LINK_ONLY_PASS_PENDING_EXECUTION_REVIEW';save();print(json.dumps(record,indent=2))
