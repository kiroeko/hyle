from pathlib import Path
import hashlib,json,os,shlex,time,zipfile

root=Path('/mnt/c/public/project-hyle/hyle')
scratch=root/'.scratch/inference-performance-recovery-2026-10-17'
evidence=root/'evidence/architecture/inference-performance-recovery-2026-10-17'
archive=evidence/'source-and-raw.zip'
receipt_path=evidence/'g04-load-ilp-receipt.json'
assert not archive.exists() and not receipt_path.exists(), 'Do not overwrite sealed evidence'
os.sched_setaffinity(0,sorted(os.sched_getaffinity(0))[:4]);os.nice(10)
sha=lambda data:hashlib.sha256(data).hexdigest()
compile_record=json.loads((scratch/'g04-load-ilp-compile-receipt.json').read_text())
link=json.loads((scratch/'g04-load-ilp-link-receipt.json').read_text())
run=json.loads((scratch/'g04-load-ilp-execution/receipt.json').read_text())
analysis=json.loads((scratch/'g04-load-ilp-runtime-analysis.json').read_text())
assert run['state']=='FINITE_CAPTURE_COMPLETE_NOT_P1' and run['artifacts_unchanged']
assert len(run['commands'])==13 and len(run['timeline_pairs'])==4
assert (analysis['total_raw_trace_kernels'],analysis['total_mapped_timed_kernels'],analysis['total_episodes'])==(37184,32768,24576)
review=json.loads((evidence/'g04-load-ilp-independent-review.json').read_text())
assert review['inputs']['derived_analysis_sha256']==sha((scratch/'g04-load-ilp-runtime-analysis.json').read_bytes())
assert review['inputs']['derived_analyzer_sha256']==sha((scratch/'g04-load-ilp-analyze.py').read_bytes())
targets={b['path'] for b in run['binaries']}
live=[]
for p in Path('/proc').iterdir():
    if not p.name.isdecimal() or int(p.name)==os.getpid():continue
    try:args=(p/'cmdline').read_bytes().decode(errors='replace').split('\0')
    except (OSError,PermissionError):continue
    if any(t in args for t in targets):live.append({'pid':int(p.name),'args':args})
assert not live,live
entries={}
def add(path,name):
    path=Path(path);assert path.is_file(),str(path)
    assert name not in entries,name
    entries[name]=path
for p in sorted(scratch.glob('g04-load-ilp-*')):
    if p.is_file():add(p,'diagnostic/'+p.name)
for p in sorted((scratch/'g04-load-ilp-execution').rglob('*')):
    if p.is_file():add(p,'diagnostic/execution/'+str(p.relative_to(scratch/'g04-load-ilp-execution')))
work=Path(compile_record['work']);consumer=work/'consumer'
for name in ['CMakeLists.txt','bench/inference_resident_sdpa/cuda_encoded_page_bench.cc','bench/inference_resident_sdpa/cuda_encoded_page_reference.h','bench/common/perf_process.h']:
    add(consumer/name,'consumer/'+name)
for mode in ['control','treatment']:add(consumer/'build'/f'load_ilp_{mode}.map',f'consumer/maps/load_ilp_{mode}.map')
for pair in run['timeline_pairs']:
    for p in pair['processes']:
        for suffix in ['.sqlite','.nsys-rep']:
            source=Path(p['timeline']['sqlite']).with_suffix(suffix)
            add(source,'raw/'+source.name)
assert len([n for n in entries if n.startswith('raw/') and n.endswith('.sqlite')])==8
# The complete disposable FI include tree is small source, not an SDK/build tree.
for p in sorted((work/'include').rglob('*')):
    if p.is_file():add(p,'headers/treatment/'+str(p.relative_to(work/'include')))
original_include=Path(next(x[2:] for x in shlex.split(compile_record['original_compile_record']['command']) if x.startswith('-I') and 'cache-source-' in x))
for name in ['flashinfer/attention/prefill.cuh','flashinfer/attention/cascade.cuh']:
    add(original_include/name,'headers/control/'+name)
source_root=Path('/root/hyle-scratch/compute-unified/source-7a7b4c3b')
dependency=work/'native_cache_load_ilp.d';add(dependency,'compile/native_cache_load_ilp.d')
deps=shlex.split(dependency.read_text().replace('\\\n',' '))
for p in sorted(set(Path(s) for s in deps[1:] if s.startswith(str(source_root)+'/'))):
    add(p,'source-original/'+str(p.relative_to(source_root)))
add(source_root/'src/compute_provider_flashinfer/native_cache.cu','source-original/src/compute_provider_flashinfer/native_cache.cu') if 'source-original/src/compute_provider_flashinfer/native_cache.cu' not in entries else None
for p in sorted((root/'include/hyle').rglob('*')):
    if p.is_file():add(p,'consumer-product-headers/'+str(p.relative_to(root/'include')))
for p in sorted((root/'src/compute_backend_cuda').glob('*.h')):add(p,'consumer-product-headers/src/compute_backend_cuda/'+p.name)
for name in ['g04-g05-load-ilp-analysis.md','g04-load-ilp-execution-review.json','g04-load-ilp-independent-review.json']:
    add(evidence/name,'reviews/'+name)
start=time.monotonic();manifest=[]
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=1) as z:
    for name,p in sorted(entries.items()):
        data=p.read_bytes();manifest.append({'archive_path':name,'source_path':str(p),'bytes':len(data),'sha256':sha(data)});z.writestr(name,data)
    z.writestr('manifest.json',json.dumps({'files':manifest,'exclusions':['Repeated SDK and prior artifact archives','CUDA objects/executables; their exact hashes and source binding remain in receipts','System/compiler/CUDA-toolkit headers; fixed tool identity is recorded'],'gpu_execution_performed_by_archiver':False},indent=2)+'\n')
archive_seconds=time.monotonic()-start
# Verify every retained member, including all raw traces, without executing it.
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for item in manifest:
        data=z.read(item['archive_path']);assert len(data)==item['bytes'] and sha(data)==item['sha256']
costs={'compile_seconds':compile_record['compile_seconds'],'configure_seconds':link['stages'][0]['seconds'],'initial_host_link_seconds':link['stages'][1]['seconds'],'tail_validation_host_relink_seconds':link['boundary_amendment']['seconds'],'exit_marker_host_relink_seconds':link['final_review_markers']['seconds'],'runtime_commands_seconds':sum(c['seconds'] for c in run['commands']),'archive_create_seconds':archive_seconds,'offline_analysis_and_review_seconds':None,'offline_analysis_and_review_cost_note':'Not separately timed; not reported as zero'}
result={'schema':'hyle.g04-load-ilp-finite-diagnostic-receipt/v1','state':'SEALED_DIAGNOSTIC_NOT_P1_CAUSAL_ATTRIBUTION_UNRESOLVED','canonical_head':'8e04eb0c0','archive':{'path':str(archive.relative_to(root)),'sha256':sha(archive.read_bytes()),'bytes':archive.stat().st_size,'payload_files':len(manifest),'payload_uncompressed_bytes':sum(x['bytes'] for x in manifest),'all_members_readback_verified':True,'files':manifest},'runtime_receipt_sha256':sha((scratch/'g04-load-ilp-execution/receipt.json').read_bytes()),'analysis_sha256':sha((scratch/'g04-load-ilp-runtime-analysis.json').read_bytes()),'analyzer_sha256':sha((scratch/'g04-load-ilp-analyze.py').read_bytes()),'independent_review_sha256':sha((evidence/'g04-load-ilp-independent-review.json').read_bytes()),'launcher_sha256':sha((scratch/'g04-load-ilp-run.py').read_bytes()),'finite_costs':costs,'counts':{'compile_variants':1,'cuda_full_tu_compiles':1,'host_configures':1,'initial_host_links':1,'necessary_host_relinks':2,'numerical_tool_processes':5,'timeline_processes':8,'timeline_pairs':4,'raw_trace_kernels':37184,'mapped_timed_kernels':32768,'measured_episodes':24576,'gpu_retries':0,'extra_samples':0,'formal_ab_runs':0},'failures':{'compile':[],'link':[],'gpu_runtime':[],'numerical_permissions_lifecycle':[],'readonly_setup':['Initial query of absent WSL distro Ubuntu returned DISTRO_NOT_FOUND; actual work used Ubuntu-24.04.','WSL rg was unavailable; available readers were used.'],'warnings':['cuobjdump reported requested-function-not-found for other embedded fatbins; each four actual requested nonempty functions independently matched and is retained.']},'cleanup':{'runtime_timeout_cleanup_invocations':0,'all_13_processes_exited_zero_with_unique_application_exit_and_expected_teardowns':True,'archive_time_owned_target_process_scan':live,'all_owned_math_profiler_sanitizer_processes_completed':True},'verdict':'Actual paired-load codegen and numerical/permission/lifecycle validity proven in this bounded domain. All four raw prefill pairs improved, but unchanged negative controls drift together and host controls vary greatly. Cross-process timing/resource perturbation remains unresolved; no clock cause, pure ILP gain, normalization, adoption or original-attempt14 recovery claimed. One variant stopped without further GPU work.','product_registry_sdk_modified':False}
receipt_path.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'archive_sha256':result['archive']['sha256'],'archive_bytes':result['archive']['bytes'],'payload_files':len(manifest),'receipt_sha256':sha(receipt_path.read_bytes()),'finite_costs':costs,'owned_target_processes_remaining':live},indent=2))
