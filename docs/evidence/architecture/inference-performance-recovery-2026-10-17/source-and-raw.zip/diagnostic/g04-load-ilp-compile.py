from pathlib import Path
import difflib, hashlib, json, os, re, shlex, shutil, subprocess, time

canonical = Path('/mnt/c/public/project-hyle/hyle')
out = canonical / '.scratch/inference-performance-recovery-2026-10-17'
work = Path('/root/hyle-scratch/compute-unified/g04-load-ilp-2026-10-17')
assert not work.exists(), 'Owned diagnostic directory already exists; do not overwrite'
work.mkdir(parents=True)
allowed = sorted(os.sched_getaffinity(0))
os.sched_setaffinity(0, allowed[:4])
os.nice(10)
receipt = json.loads((canonical / 'evidence/architecture/inference-g04-g05-c1-packed-conversion/receipt.json').read_text())
original = receipt['direct_product_stage']['build']['original_compile_record']
args = shlex.split(original['command'])
include_index = next(i for i,x in enumerate(args) if x.startswith('-I') and 'cache-source-' in x)
original_include = Path(args[include_index][2:])
assert original_include.is_dir()
include = work / 'include'
shutil.copytree(original_include, include)
header = include / 'flashinfer/attention/prefill.cuh'
before = header.read_text()
def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
assert sha(original['file']) == '62ace94e0809144aca540fa317f72e9a2bc2b1d29b5099ef15048d3da6b92858'
assert sha(header) == '8146bd05db566d6f3c999a3aa3b83d91f7a565a343d06780edf2abd5faa0840f'
anchor = '''  if constexpr (KTraits::HYLE_FP8_DIRECT_STAGE) {
    constexpr uint32_t HEAD_DIM = produce_v ? KTraits::HEAD_DIM_VO : KTraits::HEAD_DIM_QK;
#pragma unroll
    for (uint32_t i = 0; i < NUM_MMA_KV * 4 / NUM_WARPS_Q; ++i) {
      const uint32_t row = warp_idx * 4 + lane_idx / 8 + i * NUM_WARPS * 4;
#pragma unroll
      for (uint32_t j = 0; j < HEAD_DIM / 128; ++j) {
        hyle_load_fp8_native_stage<fill_mode, KTraits, HEAD_DIM>(
            smem, kv_ptr + thr_local_kv_offset[i] + j * 128,
            row, lane_idx % 8 + j * 8, kv_idx_base + row < kv_len);
      }
    }
    return;
  }'''
replacement = '''  if constexpr (KTraits::HYLE_FP8_DIRECT_STAGE) {
    constexpr uint32_t HEAD_DIM = produce_v ? KTraits::HEAD_DIM_VO : KTraits::HEAD_DIM_QK;
#pragma unroll
    for (uint32_t i = 0; i < NUM_MMA_KV * 4 / NUM_WARPS_Q; ++i) {
      const uint32_t row = warp_idx * 4 + lane_idx / 8 + i * NUM_WARPS * 4;
      if constexpr (!produce_v && HEAD_DIM == 256) {
        // Diagnostic only: one common NoFill predicate, both original loads first.
        if (kv_idx_base + row < kv_len) {
          const auto* source = kv_ptr + thr_local_kv_offset[i];
          b128_t packed[2];
          packed[0] = *reinterpret_cast<const b128_t*>(source);
          packed[1] = *reinterpret_cast<const b128_t*>(source + 128);
#pragma unroll
          for (uint32_t j = 0; j < 2; ++j) {
            alignas(16) typename KTraits::DTypeQ converted[16];
            vec_cast<typename KTraits::DTypeQ, typename KTraits::DTypeKV>::template cast<16>(
                converted, reinterpret_cast<typename KTraits::DTypeKV*>(&packed[j]));
            constexpr uint32_t STRIDE = HEAD_DIM / upcast_size<typename KTraits::DTypeQ>();
            const uint32_t col = lane_idx % 8 + j * 8;
            smem.base[get_permuted_offset<KTraits::SWIZZLE_MODE_KV, STRIDE>(row, 2 * col)] =
                *reinterpret_cast<b128_t*>(converted);
            smem.base[get_permuted_offset<KTraits::SWIZZLE_MODE_KV, STRIDE>(row, 2 * col + 1)] =
                *reinterpret_cast<b128_t*>(converted + 8);
          }
        }
      } else {
#pragma unroll
        for (uint32_t j = 0; j < HEAD_DIM / 128; ++j) {
          hyle_load_fp8_native_stage<fill_mode, KTraits, HEAD_DIM>(
              smem, kv_ptr + thr_local_kv_offset[i] + j * 128,
              row, lane_idx % 8 + j * 8, kv_idx_base + row < kv_len);
        }
      }
    }
    return;
  }'''
assert before.count(anchor) == 1
header.write_text(before.replace(anchor,replacement))
(out / 'g04-load-ilp-variant.patch').write_text(''.join(difflib.unified_diff(before.splitlines(True),header.read_text().splitlines(True),fromfile='control/prefill.cuh',tofile='load-ilp/prefill.cuh')))
obj = work / 'native_cache_load_ilp.o'
args[include_index] = '-I' + str(include)
for flag,value in [('-MT',obj),('-MF',work/'native_cache_load_ilp.d'),('-o',obj)]: args[args.index(flag)+1]=str(value)
args += ['--ptxas-options=-v']
result = {'state':'COMPILE_ONLY_STARTED','canonical_head':'8e04eb0c0','work':str(work),'affinity':sorted(os.sched_getaffinity(0)),'nice':os.nice(0),'command':args,'original_compile_record':original,'source_sha256':sha(original['file']),'original_prefill_sha256':hashlib.sha256(before.encode()).hexdigest(),'candidate_prefill_sha256':sha(header),'gpu_executed':False,'product_changed':False,'control_object':receipt['direct_product_stage']['build']['actual_archive_member']}
(out/'g04-load-ilp-compile-receipt.json').write_text(json.dumps(result,indent=2)+'\n')
start=time.monotonic()
with (out/'g04-load-ilp-compile.log').open('w') as log:
    proc = subprocess.run(args,cwd=original['directory'],stdout=log,stderr=subprocess.STDOUT)
result.update(state='COMPILE_ONLY_PASS' if proc.returncode==0 else 'COMPILE_ONLY_FAIL',exit_code=proc.returncode,compile_seconds=time.monotonic()-start)
if proc.returncode==0:
    result['candidate_object_sha256']=sha(obj)
    kernels=json.loads((canonical/'evidence/architecture/inference-g04-g05-cuda-ce28-producer-stage/runtime-receipt.json').read_text())
    target=kernels['actual_kernels'][1]['mangled']
    result['target_kernel']=target
    for mode,object_path in [('control',result['control_object']['path']),('candidate',str(obj))]:
        assert Path(object_path).is_file()
        for kind,flags in [('sass',['--dump-sass','--function',target]),('resources',['--dump-resource-usage'])]:
            command=['/usr/local/cuda-13.3/bin/cuobjdump',*flags,object_path]
            with (out/f'g04-load-ilp-{mode}-{kind}.txt').open('w') as log:
                code=subprocess.call(command,stdout=log,stderr=subprocess.STDOUT)
            assert code==0, (mode,kind,code)
    result['control_sha256_verified']=sha(result['control_object']['path'])==result['control_object']['sha256']
(out/'g04-load-ilp-compile-receipt.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ['command','original_compile_record']},indent=2))
