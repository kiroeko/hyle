from pathlib import Path
import hashlib,json,subprocess,zipfile

root=Path.cwd();base=root/'.scratch/inference-gaps/g04-g05';run=base/'ce28-runtime-profile-1'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
r=json.loads((run/'result.json').read_text());assert r['state']=='TERMINAL_DISPATCH_IDENTITY_PASS'
candidate='830dd9e01829e3e5850ddff7eaa6355ee7c8fd0d';assert r['product_candidate']==candidate
numeric=root/'evidence/correctness/inference-g04-g05-cuda-ce28-direct-stage-numeric-rebind/receipt.json'
assert sha(numeric)==r['numeric_receipt_sha256'];n=json.loads(numeric.read_text())
assert n['state']=='TERMINAL_PASS' and n['product_candidate']==candidate
binary=n['successful_run']['binary'];assert binary['sha256']==r['binary_sha256']
assert subprocess.check_output(['wsl','-e','sha256sum',binary['path']],text=True).split()[0]==binary['sha256']
assert sorted((row['projected_mma_kv'],row['dynamic_shared']) for row in r['kernels'])==[(1,49152),(1,49152),(4,40960)]
dest=root/'evidence/architecture/inference-g04-g05-cuda-ce28-producer-stage'
assert not (dest/'runtime-receipt.json').exists()
with zipfile.ZipFile(dest/'runtime-raw.zip','w',zipfile.ZIP_DEFLATED) as z:
    for p in sorted(run.rglob('*')):
        if p.is_file():z.write(p,p.relative_to(run).as_posix())
    z.write(base/'seal_ce28_runtime_profile.py','runners/seal_ce28_runtime_profile.py')
receipt=dict(kind='G04_G05_CE28_ACTUAL_RUNTIME_KERNEL_IDENTITY',verdict='PASS_RUNTIME_DISPATCH_AND24_ORACLES_ONLY',
 product_candidate=candidate,numeric_receipt_sha256=sha(numeric),binary_sha256=r['binary_sha256'],
 actual_kernels=r['kernels'],actual_merge=r['merge'],max_abs_error=r['max_abs_error'],measured_seconds=r['elapsed_seconds'],
 nsys_version=r['nsys_version'],limits=r['limits'],raw_zip_sha256=sha(dest/'runtime-raw.zip'))
(dest/'runtime-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n',newline='\n')
print(json.dumps(dict(path=str(dest/'runtime-receipt.json'),seconds=r['elapsed_seconds'])))
