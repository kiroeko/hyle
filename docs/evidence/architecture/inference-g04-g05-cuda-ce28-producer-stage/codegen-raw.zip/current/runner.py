from pathlib import Path
import hashlib,json,re,subprocess,time

root=Path('/mnt/c/public/project-hyle/hyle');base=root/'.scratch/inference-gaps/g04-g05'
candidate='830dd9e01829e3e5850ddff7eaa6355ee7c8fd0d'
source=json.loads((base/'ce28-source-1/result.json').read_text())
device=json.loads((base/'ce28-device-risks-1/result.json').read_text())
assert source['state']==device['state']=='TERMINAL_PASS' and device['product_commit']==candidate
baseline_path=base/'ce27-fixed-codegen-1/result.json';prior=json.loads(baseline_path.read_text())
assert prior['product_candidate']=='d41431f82a373ae400fb10e97418931031fa48e8'
build=Path(source['build']);binary=build/'bin/libhyle_compute_provider_flashinfer.so.0.1.0'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
before=sha(binary);assert before==device['artifacts'][str(binary)]
out=base/'ce28-fixed-codegen-1';out.mkdir(exist_ok=False)
names=[x['mangled'] for x in prior['kernels']]+[prior['merge']['mangled']]
tool='/usr/local/cuda-13.3/bin/cuobjdump';stages=[]
def run(label,command):
    start=time.monotonic()
    with (out/(label+'.log')).open('w') as f:p=subprocess.run(command,stdout=f,stderr=subprocess.STDOUT)
    stages.append(dict(stage=label,command=command,exit_code=p.returncode,elapsed_seconds=time.monotonic()-start))
    assert p.returncode==0
run('resources',[tool,'--dump-resource-usage',str(binary)])
resources={};name=None
for line in (out/'resources.log').read_text().splitlines():
    if line.strip().startswith('Function ') and line.endswith(':'):name=line.strip()[9:-1]
    elif name and 'REG:' in line:resources.setdefault(name,[]).append(line.strip())
assert all(name in resources and len(resources[name])==1 for name in names)
run('selected-sass',[tool,'--dump-sass','--function',','.join(names),str(binary)])
counts={};current=None
for line in (out/'selected-sass.log').read_text().splitlines():
    found=re.search(r'Function\s*:\s*(\S+)',line)
    if found:
        current=found.group(1);assert current not in counts
        counts[current]=dict(LDL=0,STL=0,STG=0,BAR=0)
    if current:
        for op in counts[current]:counts[current][op]+=len(re.findall(r'\b'+op+r'\b',line))
assert set(counts)==set(names)
rows=[]
for previous in prior['kernels']:
    name=previous['mangled']
    rows.append(dict(mangled=name,projected_mma_kv=previous['projected_mma_kv'],
        before_resource=previous['after_resource'],before_sass=previous['after_sass'],
        after_resource=resources[name][0],after_sass=counts[name]))
name=prior['merge']['mangled']
merge=dict(mangled=name,baseline_resource=prior['merge']['after_resource'],baseline_sass=prior['merge']['after_sass'],
    after_resource=resources[name][0],after_sass=counts[name],baseline_binary_sha256=prior['binary_sha256'],baseline_record_sha256=sha(baseline_path))
commands=json.loads(subprocess.check_output(['ninja','-C',str(build),'-t','compdb'],text=True))
command=next(x for x in commands if x['file'].endswith('/native_cache.cu'))
include=re.search(r'-I(\S*cache-source-\S*/include)',command['command']).group(1)
header=Path(include)/'flashinfer/attention/prefill.cuh';cascade=header.parent/'cascade.cuh'
manifest=json.loads((root/'third_party/flashinfer_cache/patches.json').read_text())
for p in (header,cascade):
    expected=next(x['after_sha256'] for x in manifest['files'] if x['path']=='include/flashinfer/attention/'+p.name)
    assert sha(p)==expected
assert sha(binary)==before and sha(cascade)==prior['cascade_sha256']
r=dict(kind='CE28_DIRECT_FP8_PRODUCER_STAGE_SAME_ATTENTION_AND_MERGE_STATIC_CODEGEN_ONLY',state='TERMINAL_PASS',
    product_candidate=candidate,binary=str(binary),binary_sha256=before,header=str(header),header_sha256=sha(header),
    cascade=str(cascade),cascade_sha256=sha(cascade),compile_command=command,stages=stages,kernels=rows,merge=merge,
    baseline_codegen_sha256=sha(baseline_path),
    limits=['Same original three attention MMA1/1/4 and unchanged scaled F32 merge; compare actual CE27 static resource/instruction records.',
            'Static barrier counts do not prove asynchronous safety, runtime dispatch or a speedup; fresh device risks and original P1 are separate gates.'])
(out/'result.json').write_text(json.dumps(r,indent=2)+'\n');(out/'runner.py').write_bytes(Path(__file__).read_bytes())
print(json.dumps(dict(attention=rows,merge=merge),indent=2))
