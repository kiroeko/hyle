from pathlib import Path
import hashlib,json,os,shlex,subprocess,time
root=Path('/mnt/c/public/project-hyle/hyle');ext=Path('/root/hyle-scratch/compute-unified')
old=ext/'g04-cuda-encoded-p1-fresh-6';source=ext/'g04-cuda-encoded-p1-source-6'
m=json.loads((ext/'g04-cuda-encoded-p1-output-6/manifest.json').read_text())
out=ext/'ce19-cuda-isa-attestation-1';out.mkdir(exist_ok=False)
contract=json.loads((root/'bench/inference_resident_sdpa/cuda_encoded_p1/contract.json').read_text())
assert 'HYLE_SIMD_EXACT_TARGET' not in m['build']['details']['cmake_cache']
assert contract['extensions']['runner']['cmake']['cache']['HYLE_SIMD_EXACT_TARGET']==''
old_cache_sha=hashlib.sha256((old/'CMakeCache.txt').read_bytes()).hexdigest()
assert old_cache_sha==m['build']['details']['cmake_cache_sha256']
cache=dict(m['build']['details']['requested_cache']);cache['HYLE_SIMD_EXACT_TARGET']=''
cmd=['cmake','-S',str(source/'bench/inference_resident_sdpa/cuda_encoded_p1'),'-B',str(out/'build'),'-G','Ninja']
cmd+=['-D'+key+'='+str(cache[key]) for key in sorted(cache)]
env=os.environ.copy();env['PATH']='/usr/local/cuda-13.3/bin:'+env['PATH']
start=time.monotonic()
with (out/'configure.log').open('w') as f:code=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT).returncode
elapsed=time.monotonic()-start;assert code==0
actual=dict(x.split('=',1) for x in (out/'build/CMakeCache.txt').read_text().splitlines() if '=' in x and not x.startswith(('#','//')))
exact=[v for k,v in actual.items() if k.split(':')[0]=='HYLE_SIMD_EXACT_TARGET'];assert exact==['']
before=json.loads((old/'compile_commands.json').read_text());after=json.loads((out/'build/compile_commands.json').read_text())
def normalized(rows,build):
 return sorted((r['file'],[a.replace(str(build),'<BUILD>') for a in shlex.split(r['command'])]) for r in rows)
assert normalized(before,old)==normalized(after,out/'build'),'Compile command changed beyond build path'
flags=[]
for row in after:
 if not row['file'].endswith(('.cc','.c','.cpp')):continue
 args=shlex.split(row['command']);specific=[a for a in args if a.startswith(('-march=','-mcpu=','-mavx','-msse','/arch:'))]
 assert not specific,(row['file'],specific);flags.append(dict(file=row['file'],explicit_cpu_isa_flags=specific))
default=subprocess.check_output(['/usr/bin/g++-14','-Q','-O3','--help=target'],text=True)
(out/'gcc-default-target.txt').write_text(default)
assert 'x86-64' in next(x for x in default.splitlines() if '-march=' in x)
assert hashlib.sha256((old/'CMakeCache.txt').read_bytes()).hexdigest()==old_cache_sha
for name in ('CMakeCache.txt','compile_commands.json'):(out/name).write_bytes((out/'build'/name).read_bytes())
(out/'runner.py').write_bytes(Path(__file__).read_bytes())
result=dict(state='PASS_CONFIGURE_ONLY_ISA_ATTESTATION_NO_NEW_PERFORMANCE',command=cmd,elapsed_seconds=elapsed,
 old_isa='unknown_from_missing_cache_key',new_isa='portable_from_explicit_empty_exact_target',
 old_cache_unchanged_sha256=old_cache_sha,compile_command_count=len(after),normalized_compile_commands_unchanged=True,
 host_flags=flags,compiler_default_march=next(x.strip() for x in default.splitlines() if '-march=' in x),
 new_contract_sha256=hashlib.sha256((root/'bench/inference_resident_sdpa/cuda_encoded_p1/contract.json').read_bytes()).hexdigest(),
 limits=['Configure only plus CMake compiler identification; no product/peer target built,no GPU workload or P1 resampling','Original6 manifest remains DIAGNOSTIC and unchanged; this is a prospective declaration check,not retrospective qualification'])
(out/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
