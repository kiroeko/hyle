from pathlib import Path
import hashlib, json, re, subprocess, time

root=Path('/mnt/c/public/project-hyle/hyle');base=root/'.scratch/inference-gaps/g04-g05'
candidate='1e343ee3b440af5d522c6bfbdf12f9c6f37f0811'
source=json.loads((base/'ce26-source-1/result.json').read_text())
device=json.loads((base/'ce26-device-risks-1/result.json').read_text())
assert source['state']==device['state']=='TERMINAL_PASS' and device['product_commit']==candidate
build=Path(source['build']);binary=build/'bin/libhyle_compute_provider_flashinfer.so.0.1.0'
out=base/'ce26-fixed-codegen-1';out.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
before=sha(binary);assert before==device['artifacts'][str(binary)]
oldpath=Path('/root/hyle-scratch/compute-unified/ce22-cuda-product-profile-9/actual-kernel-resources.json')
old=json.loads(oldpath.read_text())
selected=[row for row in old['kernels'] if row['mangled'].startswith('_ZN10flashinfer')]
assert len(selected)==3
for row in selected:
    old_name=row['mangled'];row['baseline_mangled']=old_name
    pattern=r'(KernelTraitsILNS_8MaskModeE[01]ELj64ELj1ELj)(2|8)(ELj)'
    found=re.search(pattern,old_name);assert found,old_name
    expected=1 if found.group(2)=='2' else 4
    row['projected_mma_kv']=expected
    row['mangled']=re.sub(pattern,lambda m:m.group(1)+str(expected)+m.group(3),old_name,count=1)
tool='/usr/local/cuda-13.3/bin/cuobjdump';stages=[]
def run(label,command):
    started=time.monotonic()
    with (out/(label+'.log')).open('w') as stream:
        p=subprocess.run(command,stdout=stream,stderr=subprocess.STDOUT)
    stages.append(dict(stage=label,command=command,exit_code=p.returncode,elapsed_seconds=time.monotonic()-started))
    assert p.returncode==0
run('resources',[tool,'--dump-resource-usage',str(binary)])
resources={};name=None
for line in (out/'resources.log').read_text().splitlines():
    if line.strip().startswith('Function ') and line.endswith(':'):name=line.strip()[9:-1]
    elif name and 'REG:' in line:resources.setdefault(name,[]).append(line.strip())
for row in selected:assert row['mangled'] in resources,row['mangled']
baseline_merge=json.loads((base/'ce26-baseline-merge-codegen/result.json').read_text())
merge_name=baseline_merge['mangled']
assert merge_name in resources and len(resources[merge_name])==1

run('selected-sass',[tool,'--dump-sass','--function',','.join([row['mangled'] for row in selected]+[merge_name]),str(binary)])
counts={};current=None
for line in (out/'selected-sass.log').read_text().splitlines():
    found=re.search(r'Function\s*:\s*(\S+)',line)
    if found:
        current=found.group(1)
        assert current not in counts, 'Duplicate image requires explicit architecture mapping'
        counts[current]=dict(LDL=0,STL=0,STG=0,BAR=0)
    if current:
        for instruction in ('LDL','STL','STG','BAR'):counts[current][instruction]+=len(re.findall(r'\b'+instruction+r'\b',line))
prior=json.loads((base/'ce25-fixed-codegen-1/result.json').read_text());prior_rows={r['mangled']:r for r in prior['kernels']}
rows=[]
for row in selected:
    name=row['mangled'];assert len(resources[name])==1 and name in counts
    rows.append(dict(mangled=name,baseline_mangled=row['baseline_mangled'],baseline_demangled=row['demangled'],
                     projected_mma_kv=row['projected_mma_kv'],before_resource=row['resource'],
                     ce25_same_mma_resource=prior_rows[name]['after_resource'],ce25_same_mma_sass=prior_rows[name]['after_sass'],
                     after_resource=resources[name][0],before_sass=row['sass_local_instructions'],after_sass=counts[name]))
commands=json.loads(subprocess.check_output(['ninja','-C',str(build),'-t','compdb'],text=True))
command=next(row for row in commands if row['file'].endswith('/native_cache.cu'))
include=re.search(r'-I(\S*cache-source-\S*/include)',command['command']).group(1)
header=Path(include)/'flashinfer/attention/prefill.cuh'
manifest=json.loads((root/'third_party/flashinfer_cache/patches.json').read_text())
expected=next(row for row in manifest['files'] if row['path']=='include/flashinfer/attention/prefill.cuh')['after_sha256']
assert sha(header)==expected and sha(binary)==before
cascade=header.parent/'cascade.cuh'
cascade_expected=next(row for row in manifest['files'] if row['path']=='include/flashinfer/attention/cascade.cuh')['after_sha256']
assert sha(cascade)==cascade_expected
merge=dict(mangled=merge_name,baseline_resource=baseline_merge['resource'],baseline_sass=baseline_merge['sass_instruction_counts'],
           after_resource=resources[merge_name][0],after_sass=counts[merge_name],
           baseline_binary_sha256=baseline_merge['binary_sha256'],baseline_record_sha256=sha(base/'ce26-baseline-merge-codegen/result.json'))

record=dict(kind='CE26_SINGLE_OUTPUT_MERGE_AND_SAME_ATTENTION_STATIC_CODEGEN_ONLY',state='TERMINAL_PASS',
 product_candidate=candidate,binary=str(binary),binary_sha256=before,old_codegen_sha256=sha(oldpath),
 header=str(header),header_sha256=sha(header),cascade=str(cascade),cascade_sha256=sha(cascade),compile_command=command,stages=stages,kernels=rows,merge=merge,
 limits=['Actual source-test shared artifact,WSL SM89; new projected MMA_KV1/1/4 specializations for the original three workloads.',
         'Only static resource and instruction counts; no runtime timing, occupancy or throughput verdict.',
         'Only scaled F32 merge final output owner changed; all attention CTA_Q/warp/MMA1/1/4/exact row guard/native16 bound preserved. Runtime dispatch trace,SDK and fresh numeric/P1 remain separate gates.'])
(out/'result.json').write_text(json.dumps(record,indent=2)+'\n')
(out/'runner.py').write_bytes(Path(__file__).read_bytes())
print(json.dumps(dict(attention=rows,merge=merge),indent=2))
