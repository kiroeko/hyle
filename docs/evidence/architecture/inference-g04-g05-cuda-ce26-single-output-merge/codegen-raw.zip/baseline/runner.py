from pathlib import Path
import hashlib,json,os,re,sqlite3,subprocess,time

root=Path('/mnt/c/public/project-hyle/hyle');base=root/'.scratch/inference-gaps/g04-g05'
numeric=json.loads((root/'evidence/correctness/inference-g04-g05-cuda-ce25-native-prefill-numeric-rebind/receipt.json').read_text())
binary=Path(numeric['successful_run']['binary']['path']);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(binary)==numeric['successful_run']['binary']['sha256']
rows=sqlite3.connect(base/'ce25-runtime-profile-1/dispatch.sqlite').execute('''select distinct m.value,d.value,k.registersPerThread,k.dynamicSharedMemory
 from CUPTI_ACTIVITY_KIND_KERNEL k join StringIds m on k.mangledName=m.id join StringIds d on k.demangledName=d.id
 where m.value like '_ZN10flashinfer%' and d.value like '%PersistentVariableLengthMergeStatesKernel%' ''').fetchall()
assert len(rows)==1;name,demangled,reg,shared=rows[0];assert reg==43 and shared==8704
out=base/'ce26-baseline-merge-codegen';out.mkdir(exist_ok=False);stages=[]
for label,command in [('resources',['/usr/local/cuda-13.3/bin/cuobjdump','--dump-resource-usage','--function',name,str(binary)]),
                       ('sass',['/usr/local/cuda-13.3/bin/cuobjdump','--dump-sass','--function',name,str(binary)])]:
    started=time.monotonic()
    with (out/(label+'.log')).open('w') as f:code=subprocess.run(command,stdout=f,stderr=subprocess.STDOUT).returncode
    stages.append(dict(stage=label,elapsed_seconds=time.monotonic()-started,exit_code=code));assert code==0
text=(out/'resources.log').read_text();resource=[line.strip() for line in text.splitlines() if 'REG:' in line]
assert len(resource)==1
sass=(out/'sass.log').read_text();counts={x:len(re.findall(r'\b'+x+r'\b',sass)) for x in ('LDL','STL','STG','BAR')}
assert sha(binary)==numeric['successful_run']['binary']['sha256']
r=dict(state='TERMINAL_STATIC_EXTRACTION_PASS',baseline=numeric['product_candidate'],binary=str(binary),binary_sha256=sha(binary),
       mangled=name,demangled=demangled,actual_runtime_registers=reg,actual_runtime_shared=shared,resource=resource[0],
       sass_instruction_counts=counts,stages=stages,limits=['Static extraction from immutable qualified11 candidate numeric artifact; no new profile or runtime/performance sample.'])
(out/'result.json').write_text(json.dumps(r,indent=2)+'\n');(out/'runner.py').write_bytes(Path(__file__).read_bytes())
print(json.dumps(dict(resource=resource,counts=counts,seconds=sum(x['elapsed_seconds'] for x in stages)),indent=2))
