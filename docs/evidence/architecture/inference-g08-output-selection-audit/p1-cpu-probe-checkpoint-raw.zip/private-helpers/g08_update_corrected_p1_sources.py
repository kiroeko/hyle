from pathlib import Path
import argparse,hashlib,json,subprocess,sys,time
p=argparse.ArgumentParser();p.add_argument('--bundle',type=Path,required=True);a=p.parse_args();air=sys.platform=='darwin';assert air or sys.platform=='linux'
base=Path('/Users/kiro' if air else '/root')/'hyle-scratch/compute-unified';out=base/'g08-p1-corrected-source-1';out.mkdir(exist_ok=False)
revision='5fbc13992137af26d0766f026415d5a80c7f2dd8';old='df7ca0271cc0cc457ec5b1a54f47a34880e5fae6';r={'state':'RUNNING','revision':revision,'bundle_sha256':hashlib.sha256(a.bundle.read_bytes()).hexdigest(),'routes':{}};started=time.monotonic()
if air:assert subprocess.check_output(['/usr/sbin/sysctl','-n','hw.model'],text=True).strip()=='Mac16,12'
for route in (['apple','vulkan'] if air else ['cuda']):
 source=base/('g08-p1-'+route)/'source';git=lambda args:subprocess.check_output(['git','-C',str(source),*args],text=True,stderr=subprocess.PIPE).strip()
 assert git(['rev-parse','HEAD'])==old and not git(['status','--porcelain','--untracked-files=all'])
 for stage,args in [('fetch',['fetch',str(a.bundle),'HEAD']),('fast-forward',['merge','--ff-only','FETCH_HEAD'])]:
  command=['git','-C',str(source),*args];result=subprocess.run(command,capture_output=True,text=True);(out/(route+'-'+stage+'.log')).write_text(result.stdout+result.stderr);assert result.returncode==0,(route,stage)
 assert git(['rev-parse','HEAD'])==revision and not git(['status','--porcelain','--untracked-files=all'])
 assert not git(['diff','--name-only',old,revision,'--','include','src','cmake','third_party','scripts'])
 cache=source.parent/'probe-build/CMakeCache.txt';assert cache.is_file()
 r['routes'][route]={'state':'CLEAN_CORRECTED_SOURCE_READY_NO_PROBE_STARTED','source':str(source),'retained_original_probe_configure':str(cache),'cache_sha256':hashlib.sha256(cache.read_bytes()).hexdigest(),'benchmark_directory':'bench/compute_ops','product_or_public_tool_paths_changed':[]}
r.update(state='ALL_LOCAL_CORRECTED_P1_SOURCES_READY',elapsed_seconds=time.monotonic()-started);(out/'result.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r))
