"""Run the existing performance instrument after the fixed delivery matrix passes."""
from pathlib import Path
import argparse,ctypes,hashlib,json,os,subprocess,sys,time

p=argparse.ArgumentParser();p.add_argument('--route',choices=['cpu','cuda','apple','vulkan'],required=True);p.add_argument('--mode',choices=['probe','qualify'],required=True);p.add_argument('--delivery-proof',type=Path,required=True);p.add_argument('--revision',required=True);p.add_argument('--setup-resume',type=int,choices=[1]);a=p.parse_args()
air=sys.platform=='darwin';windows=sys.platform=='win32';route=a.route;assert (windows and route=='cpu') or (sys.platform=='linux' and route=='cuda') or (air and route in ['apple','vulkan'])
delivery=json.loads(a.delivery_proof.read_text());assert delivery['verdict']=='ALL_18_SOURCE_STATIC_SHARED_DELIVERIES_PASS' and delivery['configs']==18 and delivery['candidate']=='5103c13d8ed119b06aa64e799f9768aea45ab913'
base=Path('C:/h7') if windows else Path('/Users/kiro' if air else '/root')/'hyle-scratch/compute-unified';folder=base/('g08-p1-'+route);source=folder/'source';peer=folder/'original85';bench=source/'bench/compute_ops';contract=bench/('contract-'+route+'.json')
assert subprocess.check_output(['git','-C',str(source),'rev-parse','HEAD'],text=True).strip()==a.revision
assert not subprocess.check_output(['git','-C',str(source),'status','--porcelain','--untracked-files=all'],text=True).strip()
assert subprocess.check_output(['git','-C',str(peer),'rev-parse','HEAD'],text=True).strip()=='85bcfa4ebc29cc4d2ed5fb122074204aca675d58'
if air:assert subprocess.check_output(['/usr/sbin/sysctl','-n','hw.model'],text=True).strip()=='Mac16,12'
resume=a.setup_resume==1
probe_name='probe-setup-resume-1' if resume else 'probe-1'
probe_job='probe-job-setup-resume-1.json' if resume else 'probe-job-1.json'
probe_build='probe-build-setup-resume-1' if resume else 'probe-build'
build=folder/(probe_build if a.mode=='probe' else 'qualified-build-1');out=folder/(probe_name if a.mode=='probe' else 'qualification-1');job=folder/(probe_job if a.mode=='probe' else 'qualify-job-1.json')
assert not job.exists() and not out.exists(),'Preserve the existing finite run; inspect and resume the original failure, never reset it.'
retained_setup={}
if resume and a.mode=='probe':
    assert (folder/'probe-build/CMakeCache.txt').is_file() and not build.exists()
    retained_setup={'prior_configure_tree':str(folder/'probe-build'),'reason':'Canonical benchmark ownership relocation and finite CPU original-provider native include wiring; no product or algorithm change. Old setup inputs/trees and any failure cost retained.'}
    if route=='cpu':
        old=json.loads((folder/'probe-job-1.json').read_text());log=(folder/'probe-1.log').read_text();assert old['state']=='TERMINAL' and old['exit_code']==1 and not (folder/'probe-1/manifest.json').exists()
        assert 'ggml.h' in log and 'ggml-cpu.h' in log and 'fatal error C1083' in log
        retained_setup.update(prior_job=str(folder/'probe-job-1.json'),prior_elapsed_seconds=old['elapsed_seconds'],prior_source_revision=old['source_revision'])
    else:assert not (folder/'probe-job-1.json').exists() and not (folder/'probe-1').exists()
if a.mode=='qualify':
    prior=json.loads((folder/probe_job).read_text());assert prior['state']=='TERMINAL' and prior['exit_code']==0 and prior.get('verify_exit_code')==0 and prior['source_revision']==a.revision
    assert json.loads((folder/probe_name/'topk-aa.json').read_text())['gate']=='PASS'
    assert not build.exists()
env={k.upper():v for k,v in os.environ.items()} if windows else dict(os.environ)
if windows:
    canonical=Path('C:/public/project-hyle/hyle');setup=subprocess.check_output(['cmd','/d','/c',str(canonical/'.scratch/inference-gaps/g01/cpu-ragged-env.cmd')],encoding='utf-8',errors='replace')
    env.update((k.upper(),v) for k,v in (x.split('=',1) for x in setup.splitlines() if '=' in x and not x.startswith('=')));env['VSLANG']='1033'
else:
    env['PATH']=('/Users/kiro/hyle-verify-tools/metal-17F109/shim:/opt/homebrew/bin:' if air else '/usr/local/cuda-13.3/bin:')+env['PATH']
    if not air:env['LD_LIBRARY_PATH']='/usr/local/cuda-13.3/targets/x86_64-linux/lib:/usr/lib/wsl/lib:'+env.get('LD_LIBRARY_PATH','')
machine='W1-WIN' if windows else 'M1-MAC' if air else 'W1-WSL';cmd=[sys.executable,str(source/'scripts/hyle-perf.py'),'probe' if a.mode=='probe' else 'qualify-platform','--source',str(bench),'--contract',str(contract),'--machine',machine,'--peer','original85='+str(peer),'--build',str(build),'--output',str(out)]
sys.path.insert(0,str(source/'scripts'))
from hyle_perf import expected_child_policy,get_machine_profile,load_registry,probe_machine
from hyle_perf.runner import _apply_sampling_policy,_creation_flags,_probe_child_policy
profile=get_machine_profile(load_registry(),machine);host=probe_machine(paths=[('source',source)],expected_qos='interactive' if air else None);policy=expected_child_policy(profile,sampling_topology='single-logical-cpu',probe=host)
r=dict(state='RUNNING',pid=os.getpid(),route=route,mode=a.mode,source_revision=a.revision,command=cmd,delivery_proof_sha256=hashlib.sha256(a.delivery_proof.read_bytes()).hexdigest(),scope='Existing instrument and unchanged5%/n15-31. Probe is diagnostic only. Same registered process topology surrounds A/A and product children; no public statistics/instrument change.');started=time.monotonic();r['retained_setup']=retained_setup
def save():r['elapsed_seconds']=time.monotonic()-started;r['cumulative_elapsed_seconds']=r['elapsed_seconds']+retained_setup.get('prior_elapsed_seconds',0);job.write_bytes((json.dumps(r,indent=2)+'\n').encode())
save()
with _apply_sampling_policy(policy) as applied:
    flags=_creation_flags(policy);r['applied_parent_sampling_policy']=applied;r['inherited_child_canary']=_probe_child_policy(policy,flags);save()
    with (folder/((probe_name if a.mode=='probe' else 'qualify-1')+'.log')).open('wb') as log:
        child=subprocess.Popen(cmd,env=env,stdout=log,stderr=subprocess.STDOUT,creationflags=flags);r['child_pid']=child.pid;save();status=child.wait()
r.update(state='TERMINAL',exit_code=status);r.pop('child_pid',None)
if (out/'manifest.json').is_file():
    verify=subprocess.run([sys.executable,str(source/'scripts/hyle-perf.py'),'verify','--contract',str(contract),'--manifest',str(out/'manifest.json')],env=env,capture_output=True,text=True)
    (folder/((probe_name if a.mode=='probe' else 'qualify-1')+'-verify.log')).write_bytes((verify.stdout+verify.stderr).encode());r['verify_exit_code']=verify.returncode
save();print(json.dumps({k:v for k,v in r.items() if k not in ['command','applied_parent_sampling_policy','inherited_child_canary']}));raise SystemExit(status)
