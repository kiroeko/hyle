from pathlib import Path
import json,os,subprocess,sys,time
root=Path(__file__).resolve().parents[2];out=root/'.scratch/inference-gaps/g08-p1-remaining-probes-1';out.mkdir(exist_ok=False);r={'state':'RUNNING','pid':os.getpid(),'stage':'WAIT_CPU_PROBE_TERMINAL','cases':[],'scope':'Finite diagnostic probes only, serial across Windows/WSL/Air. Retain CPU original14.016s setup failure and all configured trees. No formal qualification or product change.'};started=time.monotonic()
def save():r['elapsed_seconds']=time.monotonic()-started;(out/'result.json').write_bytes((json.dumps(r,indent=2)+'\n').encode())
save();cpu=Path('C:/h7/g08-p1-cpu/probe-job-setup-resume-1.json')
while True:
 current=json.loads(cpu.read_text())
 if current['state']=='TERMINAL':break
 assert current['state']=='RUNNING'
 try:
  import ctypes
  handle=ctypes.windll.kernel32.OpenProcess(0x1000,False,current['pid']);assert handle,'CPU controller disappeared before terminal record';ctypes.windll.kernel32.CloseHandle(handle)
 except Exception as e:r.update(state='WAIT_FAILED',error=repr(e));save();raise
 save();time.sleep(5)
r['cpu_observed']={k:current.get(k) for k in ['state','source_revision','exit_code','verify_exit_code','cumulative_elapsed_seconds']};save()
revision='5fbc13992137af26d0766f026415d5a80c7f2dd8';base='/Users/kiro/hyle-scratch/compute-unified/'
commands=[('cuda',['wsl','-d','Ubuntu-24.04','--','python3','/mnt/c/public/project-hyle/hyle/.scratch/inference-gaps/g08_run_p1.py','--route','cuda','--mode','probe','--setup-resume','1','--delivery-proof','/root/hyle-scratch/compute-unified/g08-p1-cuda/source/evidence/delivery/inference-g08-sdk-final/receipt.json','--revision',revision])]
for route in ['apple','vulkan']:
 command='python3 '+base+'g08_run_p1.py --route '+route+' --mode probe --setup-resume 1 --delivery-proof '+base+'g08-p1-'+route+'/source/evidence/delivery/inference-g08-sdk-final/receipt.json --revision '+revision
 commands.append((route,['ssh','kiro@172.22.10.198',command]))
for route,command in commands:
 r['stage']=route+'_DIAGNOSTIC_PROBE';save();print(r['stage'],flush=True)
 with (out/(route+'.log')).open('wb') as log:
  child=subprocess.Popen(command,cwd=root,stdout=log,stderr=subprocess.STDOUT);r['child_pid']=child.pid;save();status=child.wait()
 r['cases'].append({'route':route,'exit_code':status,'log':route+'.log'});r.pop('child_pid',None);save()
r['state']='TERMINAL_ALL_THREE_DIAGNOSTIC_PROBES_OBSERVED';save();print(json.dumps(r))
