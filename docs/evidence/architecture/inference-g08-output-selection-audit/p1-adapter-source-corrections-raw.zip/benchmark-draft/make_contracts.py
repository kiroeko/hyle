"""Materialize the four fixed G08 contracts from the existing G07 schema recipe."""
import copy,hashlib,json
from pathlib import Path

here=Path(__file__).resolve().parent;root=here.parents[2]
boundary=root/'evidence/architecture/inference-g08-output-selection-audit/p1-boundary.json'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
owners={'cpu':'compute_provider_ggml','cuda':'compute_provider_cuda','apple':'compute_route_apple','vulkan':'compute_route_vulkan'}
p1_folders={'cpu':'C:/h7/g08-p1-cpu','cuda':'/root/hyle-scratch/compute-unified/g08-p1-cuda','apple':'/Users/kiro/hyle-scratch/compute-unified/g08-p1-apple','vulkan':'/Users/kiro/hyle-scratch/compute-unified/g08-p1-vulkan'}
prefixes={'cpu':'C:/h7/g08-sdk/cpu-static-1/relocated','cuda':'/root/hyle-scratch/compute-unified/g08-sdk/cuda-static-1/relocated','apple':'/Users/kiro/hyle-scratch/compute-unified/g08-sdk/apple-static-1/relocated','vulkan':'/Users/kiro/hyle-scratch/compute-unified/g08-sdk/vulkan-static-1/relocated'}
for route,owner in owners.items():
    air=route in ['apple','vulkan'];machine='M1-MAC' if air else 'W1-WIN' if route=='cpu' else 'W1-WSL'
    template=root/('bench/inference_packed_weights/contract-apple.json' if air else 'bench/inference_packed_weights/contract-cuda.json')
    c=json.loads(template.read_text());c['id']='inference-g08-'+route+'-topk-p1-v1';c['module']=owner
    c['claim']='Complete warm public TopK against pinned original85 on nine predeclared finite normal-F32 output-selection shapes. Includes both values and I32 indices, actual completion, both host reads and step-local owner release. Engineering comparison only; no categorical/RNG speed, engine token/s or llama.cpp claim.'
    c['candidate'].update(target='g08_topk_primary',component=owner,entrypoint='topk_bench.cc')
    c['peers']=[dict(id='original85',revision='85bcfa4ebc29cc4d2ed5fb122074204aca675d58',configuration=dict(delivery_shape='source',role='Original full provider/lowering/route with private symbol or namespace isolation only',precision='Identical stored normal F32 inputs and outputs; first-index tie and source bits oracle',scope='Same route ownership, checked native completion and two small result reads'))]
    shapes=[(1,1),(16,1)]+([(16,3)] if route=='apple' else [])
    provenance=dict(consumer='Single-machine resident logits output selection, one or16active rows, Qwen3.5 vocabulary248320; finite S1 card shapes',scope=dict(rows=[x[0] for x in shapes],count=[x[1] for x in shapes],vocabulary=248320),source='topk_bench.cc',sha256=sha(here/'topk_bench.cc'),peer_revision=c['peers'][0]['revision'],source_boundary=dict(path='../../evidence/architecture/inference-g08-output-selection-audit/p1-boundary.json',sha256=sha(boundary)),limitation='Frozen provisional output-selection consumer fragment. No measured full-engine frequency, logits upload in warm, categorical/RNG performance or engine token/s claim.')
    provenance_path=here/('consumer-provenance-'+route+'.json');provenance_path.write_text(json.dumps(provenance,indent=2)+'\n')
    original_workload=c['workloads'][0];c['workloads']=[]
    for rows,count in shapes:
        w=copy.deepcopy(original_workload);w.update(id=f'topk-r{rows}-k{count}',consumer_key=f'inference-{route}-output-selection/r{rows}-k{count}',peer_id='original85')
        w['provenance']=dict(path=provenance_path.name,sha256=sha(provenance_path))
        w['ownership_topology']=dict(candidate='Resident input and prepared invocation; public submit, checked actual native completion, both small outputs read, step-local Completion/OwnedResult/lease release',peer='Same original route lifecycle and result boundary; entire original selection or full sort remains inside replay',equivalence='Invocation retains its original native allocations/last result until replacement/final teardown as frozen in the source timing ledger. Both steady replacement tails are charged; final retained owner and runtime cache destruction deferred symmetrically.')
        w['material_contribution']=dict(frequency=1,value=1,unit='complete-output-selection',budget=5,denominator='one complete public TopK invocation with values, indices and host readback',derivation='One output-selection consumer fragment; no measured full-engine share')
        w['semantic_contract']=f'Dense last-axis F32[{rows},248320], TopK({count}) values plus I32 indices; exact stored value bits and earliest-index ordering for normal finite maxima/ties'
        w['input']=dict(distribution='Fixed 32-bit integer mix generates normal signed F32 with full mantissa entropy; explicit9,8.5,9maxima yield independent closed-form oracle. Same bytes per arm, three complete numerical cycles and eight completed warm cycles before sampling.',scale=dict(R=rows,V=248320,K=count))
        w['setup']='Context, resident inputs/upload, public Program/Invocation, caller workspace where applicable and host readback buffers are cold. Actual selection/full sort, native status/completion, both reads and step-local handle release are charged. Final retained invocation result, Program/Invocation/runtime/cache destruction deferred as source ledger specifies; private driver cache upper UNKNOWN.'
        w['charged_phases']=['public submit/admission and original queue/worker/dispatch','all selected reduction or complete original sorting and intermediate runtime work','actual checked native completion and both values/indices host readback including Vulkan staging/fences','step-local Completion/OwnedResult/lease release and previous invocation-native result replacement in steady replay']
        w['pair']=dict(candidate='HYLE TopK',peer='Original85 TopK');c['workloads'].append(w)
    c['artifacts']['validators']=['artifact-identity','build-contract','topk-aa']
    platform_name='macos' if air else 'windows' if route=='cpu' else 'wsl2'
    c['hosts']['allowed_platforms']=[platform_name];c['hosts']['certification_platforms']=[platform_name];c['hosts']['requirements']['machine_profiles']=[machine]
    runner=c['extensions']['runner'];cache=runner['cmake']['cache']
    cache.pop('HYLE_G07_ROUTE',None);cache['HYLE_G08_ROUTE']=route;cache['HYLE_G08_SOURCE']=p1_folders[route]+'/source';cache['HYLE_G08_REFERENCE_DIR']=p1_folders[route]+'/reference85';cache['CMAKE_PREFIX_PATH']=prefixes[route]
    cache['HYLE_COMPUTE_ROUTES']='cpu' if route=='cpu' else 'cpu;'+route
    if route=='cpu':
        cache.pop('CUDAToolkit_ROOT',None);cache.pop('CMAKE_C_COMPILER',None);cache.pop('CMAKE_CXX_COMPILER',None)
        runner['profiles']=json.loads((root/'bench/inference_resident_sdpa/cpu_p1/contract.json').read_text())['extensions']['runner']['profiles']
    if route=='vulkan':
        cache['HYLE_G08_VULKAN_PRODUCER']='/Users/kiro/hyle-scratch/compute-unified/a-cpu-vulkan/selected-graph/static-sdk-build/src/compute_route_vulkan'
        cache['HYLE_G08_GLSLANG']='/opt/homebrew/bin/glslangValidator'
    runner['cmake']['peer_cache']={'original85':'HYLE_G08_REFERENCE_SOURCE'}
    for executable in runner['executables']:
        variant=executable['target_variant'];executable.update(id='topk-'+variant,target='g08_topk_'+variant,stem='g08_topk_'+variant,telemetry_prefixes=['# HYLE_TOPK_RUN '])
        executable['workloads']=[dict(id=f'topk-r{rows}-k{count}',title=f'{route} TopK R={rows} V=248320 K={count}') for rows,count in shapes]
    runner['control_executable']=dict(target='g08_topk_control',stem='g08_topk_control')
    runner['validators'][-1]['id']='topk-aa'
    c['extensions']['measurement_recipe'].update(paired_rounds=104 if route=='cuda' else 16,reason='Frozen before G08 samples: three complete oracle cycles and eight warm cycles, paired cyclic complete public calls; existing n15/31,5%,controls and two execution/allocation orders with pure placement replica unchanged.')
    (here/('contract-'+route+'.json')).write_text(json.dumps(c,indent=2)+'\n')
print('Four private G08 contract drafts materialized; runtime/SDK/native config qualification remains required.')
