set(G08_ORIGINAL_SOURCES
  "${HYLE_G08_REFERENCE_DIR}/src/compute_route_apple/apple_tensor.cc"
  "${HYLE_G08_REFERENCE_DIR}/src/compute_route_apple/apple_mature_indexing.cc"
)
