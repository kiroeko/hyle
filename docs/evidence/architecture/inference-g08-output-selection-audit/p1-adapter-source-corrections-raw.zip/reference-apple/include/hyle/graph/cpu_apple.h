#pragma once

#include "hyle/compute/apple_weights.h"
#include "hyle/compute/resource_leases.h"
#include "hyle/graph/apple.h"
#include "hyle/graph/batch.h"
#include "hyle/graph/executable.h"
#include "hyle/visibility.h"

#if defined(HYLE_STATIC)
#define HYLE_GRAPH_ROUTE_CPU_APPLE_API
#elif defined(HYLE_GRAPH_ROUTE_CPU_APPLE_BUILD)
#define HYLE_GRAPH_ROUTE_CPU_APPLE_API HYLE_EXPORT
#else
#define HYLE_GRAPH_ROUTE_CPU_APPLE_API HYLE_IMPORT
#endif

#if defined(HYLE_COMPUTE_APPLE)
#include <array>
#include <memory>
#include <span>
#include <vector>

namespace hyle::sched { class Scheduler; }

namespace hyle::graph::cpu_apple {
inline constexpr ExecutionTargetId kAppleTarget{0};
inline constexpr ExecutionTargetId kCpuTarget{1};

struct Environment final {
  const compute::Context *cpu = nullptr;
  const compute::apple::Context *apple = nullptr;
  const compute::apple::MemoryResource *native = nullptr;
  mem::MemoryResourceRef host = mem::system_resource();
  std::size_t host_workspace_budget_bytes = SIZE_MAX;
  std::size_t native_boundary_budget_bytes = SIZE_MAX;
};

struct CompileOptions final {
  std::span<const NodePlacement> node_placements{};
  std::span<const ConstantBinding> constants{};
  compute::WorkloadContext workload{};
  compute::ResourceBudget resource_budget{};
  mem::AllocatorRef allocator = mem::system_allocator();
  apple::CustomLowering custom{};
  std::span<const ShapeBinding> shape{};
  // Fixed borrowed footprints for effects placed explicitly on the CPU.
  // GPU effects require an actual qualified native carrier and are rejected.
  std::span<const EffectResourceBinding> effect_bindings{};
  // Cold owned page recipes/layouts for the corresponding native-only nodes.
  // The span is borrowed only through compile; ordinary graphs keep it empty.
  std::span<const batch::NativePagedNodeBinding> paged_nodes{};
};

struct FragmentReport final {
  ExecutionTargetId target{};
  std::size_t node_count = 0;
  graph::CompileReport cpu{};
  apple::CompileReport apple{};
};
// Independent cold diagnostics. Provider-private bytes remain unknown; neither
// declared view bytes nor observed MTLBuffer lengths prove a total memory cap.
struct CompileReport final {
  std::vector<FragmentReport> fragments;
  std::size_t host_workspace_bytes = 0;
  bool has_unknown_native_storage = false;
};
struct ReplayReport final {
  std::size_t cpu_fragments = 0, apple_fragments = 0;
  std::size_t host_copy_count = 0, host_copy_bytes = 0;
  std::size_t host_repack_count = 0;
  std::size_t native_completion_wait_count = 0;
  std::size_t weight_preparation_wait_count = 0;
  std::size_t paged_fragments = 0, paged_metadata_uploaded_bytes = 0;
  std::size_t paged_metadata_backing_bytes = 0, paged_metadata_host_waits = 0;
};
struct ResourceReport final {
  // Requested managed bytes in the same scope, including other invocations,
  // migration pools and old leases. A native backing is never charged per view.
  std::array<compute::ResourceBudgetUsage, 2> storage{}; // host, shared Metal
  bool has_shared_budget = false;
  bool has_unknown_native_storage = false;
  std::size_t managed_host_workspace_bytes = 0;
  std::size_t managed_native_boundary_bytes = 0;
  compute::UnattributedStorageUsage unattributed{};
  std::size_t other_resource_count = 0, other_live_bytes = 0;
  std::size_t observed_native_backing_bytes = 0;
  std::size_t observed_native_backing_count = 0;
};

namespace detail { struct Plan; struct RunState; struct InvocationState; }
class Invocation;

// Immutable coarse plan. Apple is the default; kCpuTarget is an explicit
// placement, never a fallback for a GPU preparation/execution failure. CPU
// fragments keep original CPU Graph rules and Apple fragments keep whole native
// regions. Pure DAGs use fixed or cold exact shape bindings/finite variants.
// Explicit control/effect endpoints form separate, ordered fragments. CPU
// effects keep the common compiler's resource/alias rules; GPU effects need a
// qualified native carrier and are rejected by the current native admission.
class Executable final {
public:
  Executable() noexcept = default;
  bool valid() const noexcept { return state_ != nullptr; }
  HYLE_GRAPH_ROUTE_CPU_APPLE_API Result<Invocation>
  create_invocation(sched::Scheduler &scheduler, compute::Queue &cpu_queue) const noexcept;
private:
  friend struct detail::Plan;
  friend HYLE_GRAPH_ROUTE_CPU_APPLE_API Result<Executable>
  compile(const Graph &, Environment, CompileOptions, CompileReport *) noexcept;
  explicit Executable(std::shared_ptr<const detail::Plan> state) noexcept
      : state_(std::move(state)) {}
  std::shared_ptr<const detail::Plan> state_;
};

HYLE_GRAPH_ROUTE_CPU_APPLE_API Result<Executable>
compile(const Graph &graph, Environment environment, CompileOptions options = {},
        CompileReport *report = nullptr) noexcept;

using Variants = ExactNativeVariants<Executable>;
inline Result<Variants> compile_variants(
    const Graph &graph, Environment environment,
    std::span<const ExactShapeVariant> variants, CompileOptions options = {}) noexcept {
  if (!options.shape.empty())
    return std::unexpected(Status::InvalidArgument("variant table supplies its own exact shapes"));
  auto allocator = options.allocator;
  if (options.resource_budget) {
    HYLE_ASSIGN_OR_RETURN(allocator, options.resource_budget.metadata_allocator());
  }
  return Variants::prepare(graph, variants, [&](const Graph &point) {
    return compile(point, environment, options);
  }, allocator);
}

// Output references are borrowed through the successful ResultLease. Retain
// that lease through CPU reads or GPU use; copying an array does not authorize
// overwriting a shared boundary. Caller inputs/resources stay borrowed.
class Results final {
public:
  Results() noexcept = default;
  Results(const Results &) = delete;
  Results &operator=(const Results &) = delete;
  HYLE_GRAPH_ROUTE_CPU_APPLE_API Results(Results &&) noexcept;
  HYLE_GRAPH_ROUTE_CPU_APPLE_API Results &operator=(Results &&) noexcept;
  HYLE_GRAPH_ROUTE_CPU_APPLE_API ~Results();
  HYLE_GRAPH_ROUTE_CPU_APPLE_API Result<compute::ConstTensorView>
  output(ValueId value) const noexcept;
  HYLE_GRAPH_ROUTE_CPU_APPLE_API Result<const mlx::core::array &>
  array(ValueId value) const noexcept;
private:
  friend class Invocation;
  explicit Results(detail::RunState *state) noexcept;
  detail::RunState *state_ = nullptr;
};

// One mutable slot. Independent slots share only the immutable plan. The
// borrowed Scheduler drives CPU coarse progress; GPU stays on the original
// Apple Context owner/stream. No private thread pool or universal Queue.
// Bind/reset invalidate preparation. Pending work and old leases prevent slot
// reuse. Destruction never waits; close cancels successors and drains this slot.
// Context/resources/allocator/Scheduler/CPU Queue outlive pending work; backing
// resources/allocator additionally outlive retained result leases.
class Invocation final {
public:
  Invocation() noexcept = default;
  Invocation(const Invocation &) = delete;
  Invocation &operator=(const Invocation &) = delete;
  HYLE_GRAPH_ROUTE_CPU_APPLE_API Invocation(Invocation &&) noexcept;
  HYLE_GRAPH_ROUTE_CPU_APPLE_API Invocation &operator=(Invocation &&) noexcept;
  HYLE_GRAPH_ROUTE_CPU_APPLE_API ~Invocation();
  bool valid() const noexcept { return state_ != nullptr; }
  HYLE_GRAPH_ROUTE_CPU_APPLE_API Status bind(ValueId, compute::ConstTensorView) noexcept;
  // Opt-in readonly permission. This input and its accepted native prefixes
  // retain the lease through Results/source aliases. Other borrowed bindings
  // keep their original lifetime contract. Bind/replay control is serialized.
  HYLE_GRAPH_ROUTE_CPU_APPLE_API Status bind(ValueId, compute::TensorDesc, compute::ReadLease) noexcept;
  // Only exact page inputs of qualified native page fragments. All actual
  // readers use the same owned layout; no ordinary capacity permission.
  HYLE_GRAPH_ROUTE_CPU_APPLE_API Status bind(ValueId, compute::PagedArenaRead) noexcept;
  // Explicit cold source capacity. Reserve before pending frame bindings;
  // one original Update supplies all qualified native paged nodes.
  HYLE_GRAPH_ROUTE_CPU_APPLE_API Status reserve_pending_sources(std::size_t)noexcept;
  HYLE_GRAPH_ROUTE_CPU_APPLE_API Status bind(ValueId,compute::PagedArenaPendingRead)noexcept;
  HYLE_GRAPH_ROUTE_CPU_APPLE_API Status bind(ValueId, const mlx::core::array &) noexcept;
  HYLE_GRAPH_ROUTE_CPU_APPLE_API Status
  bind(ValueId, const compute::apple::WeightBatch &, std::uint64_t id) noexcept;
  HYLE_GRAPH_ROUTE_CPU_APPLE_API Status reset() noexcept;
  // Complete live page-node set. Active packed output shape stays fixed;
  // other topology changes are explicit cold native/table preparation.
  // Call before binding this episode; old work/results prevent reuse.
  HYLE_GRAPH_ROUTE_CPU_APPLE_API Status prepare_batch(std::span<const batch::NodeLayout>) noexcept;
  HYLE_GRAPH_ROUTE_CPU_APPLE_API Status prepare_replay(ReplayOptions options = {}) noexcept;
  HYLE_GRAPH_ROUTE_CPU_APPLE_API Result<ReplayReport> replay_report() const noexcept;
  HYLE_GRAPH_ROUTE_CPU_APPLE_API Result<ResourceReport> resource_report() const noexcept;
  HYLE_GRAPH_ROUTE_CPU_APPLE_API Result<compute::OwnedResult<Results>> submit() noexcept;
  HYLE_GRAPH_ROUTE_CPU_APPLE_API Result<compute::OwnedResult<Results>> submit(compute::apple::CopyBatchUpdate&&)noexcept;
  // Release old Graph result/completion first; actual retirement and failed
  // source permission remain governed by the original Update.
  HYLE_GRAPH_ROUTE_CPU_APPLE_API Result<compute::apple::CopyBatchUpdate> take_update()noexcept;
  HYLE_GRAPH_ROUTE_CPU_APPLE_API Result<compute::ResultLease<Results>> run() noexcept;
  HYLE_GRAPH_ROUTE_CPU_APPLE_API Status close() noexcept;
private:
  friend class Executable;
  explicit Invocation(detail::InvocationState *state) noexcept : state_(state) {}
  detail::InvocationState *state_ = nullptr;
};
} // namespace hyle::graph::cpu_apple
#endif
