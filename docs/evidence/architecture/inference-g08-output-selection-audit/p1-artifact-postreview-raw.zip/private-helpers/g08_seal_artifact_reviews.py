from pathlib import Path
import hashlib,json,zipfile

repo=Path.cwd()
root=repo/'.scratch/inference-gaps/g08-artifact-postreview-1'
dest=repo/'evidence/architecture/inference-g08-output-selection-audit'
receipt=dest/'p1-artifact-postreview.json';archive=dest/'p1-artifact-postreview-raw.zip'
assert not receipt.exists() and not archive.exists(), 'Do not replace sealed evidence'
def sha(path):
 h=hashlib.sha256()
 with path.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
reviews=[];retained=[]
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for route in ['cpu','cuda','apple','vulkan']:
  folder=root/route;d=json.loads((folder/'capture.json').read_text())
  assert d['state']=='PASS_RETROSPECTIVE_ENGINEERING_SUPPLEMENT', route
  for f in sorted(folder.rglob('*')):
   if not f.is_file():continue
   if route=='cpu' and f.name in ['primary-disasm.txt','placement-disasm.txt']:
    retained.append({'route':route,'path':str(f),'sha256':sha(f),'bytes':f.stat().st_size,'reason':'Full final executable disassembly is retained live; archived linked execute snippets plus exact relocation-aware matching and object libraries provide the finite review.'})
   else:z.write(f,route+'/'+f.relative_to(folder).as_posix())
  reviews.append({'route':route,'state':d['state'],'capture_sha256':sha(folder/'capture.json'),'text_sizes':[b['text']['bytes'] for b in d['binaries']],'text_delta_bytes':d['text_delta_bytes'],'manual_review':d['manual_review']})
  if route=='cpu':
   build=Path('C:/h7/g08-p1-cpu/qualified-build-1')
   for role in ['candidate','reference']:
    z.write(build/('g08_'+role+'_arm.lib'),'cpu/build/g08_'+role+'_arm.lib')
    z.write(build/'CMakeFiles'/('g08_'+role+'_arm.dir')/'generic_arm.cc.obj','cpu/build/g08_'+role+'_arm.obj')
 for name in ['g08_artifact_postreview.py','g08_cpu_linked_function_review.py','g08_cuda_linked_function_review.py','g08_air_linked_function_review.py','g08_seal_artifact_reviews.py']:
  z.write(repo/'.scratch/inference-gaps'/name,'private-helpers/'+name)
z=zipfile.ZipFile(archive);assert z.testzip() is None;z.close()
result={'schema':'hyle.inference-g08-artifact-postreview/v1','verdict':'PASS_RETROSPECTIVE_ENGINEERING_SUPPLEMENT','candidate':'5103c13d8ed119b06aa64e799f9768aea45ab913','reviews':reviews,'retained_large_disassembly':retained,'timing':'All captures and the independent consumer review took place after formal sampling started. No backdated preflight sign-off; full completion/cost/source ledger and workload-matched A/A retain their own earlier timestamps. This finite terminal supplement changed no executed binary, sample, contract, peer or statistics.','scope':'Actual immutable host section sizes, selected linked symbols and arm disassembly; static public calls/native entry points remain, same Release/LTO-off policy, no material text inflation or hot prefix work. No inspected-all-vendor-code, hardware-counter, GPU-code-placement or Formal-release procedural claim.','engineering_disposition':'Accepted as a retrospective engineering evidence correction because actual frozen artifacts satisfy the finite structural/codegen properties and no comparability-invalidating finding was found. The late recording/independent-review timing is a retained procedural deviation; it is not represented as prospective full Formal preflight compliance.','raw':{'path':archive.name,'sha256':sha(archive),'bytes':archive.stat().st_size}}
receipt.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'verdict':result['verdict'],'raw_bytes':archive.stat().st_size,'text_sizes':[{k:r[k] for k in ['route','text_sizes','text_delta_bytes']} for r in reviews]}))
