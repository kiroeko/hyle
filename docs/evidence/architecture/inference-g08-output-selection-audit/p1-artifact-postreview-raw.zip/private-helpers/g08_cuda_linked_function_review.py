from pathlib import Path
import collections,hashlib,json,subprocess
base=Path('/root/hyle-scratch/compute-unified/g08-p1-cuda/qualified-build-1')
out=Path('/mnt/c/public/project-hyle/hyle/.scratch/inference-gaps/g08-artifact-postreview-1/cuda')
assert not (out/'linked-functions.json').exists()
def symbols(variant):
 d=collections.defaultdict(list)
 for line in (out/(variant+'-symbols.txt')).read_text().splitlines():
  s=line.split(maxsplit=3)
  if len(s)==4 and s[2] in 'tT':d[s[3]].append({'address':int(s[0],16),'bytes':int(s[1],16)})
 return dict(d)
x,y=symbols('primary'),symbols('placement')
changes=[{'symbol':k,'primary':v,'placement':y.get(k)} for k,v in x.items() if y.get(k)!=v]
callbacks=[c for c in changes if 'runErasedOp' in c['symbol']]
assert len(callbacks)==2 and all(c['placement'][0]['address']-c['primary'][0]['address']==16 for c in callbacks)
execute='_ZN3g0812_GLOBAL__N_110GenericArm7executeEv'
assert len(x[execute])==len(y[execute])==2
captures=[]
for variant in ['primary','placement']:
 for index,symbol in enumerate([execute]+[c['symbol'] for c in callbacks]+(['g08_topk_placement_prefix'] if variant=='placement' else [])):
  target=out/(variant+'-linked-function-'+str(index)+'.txt')
  cmd=['objdump','-d','--disassemble='+symbol,str(base/'bin'/('g08_topk_'+variant))]
  r=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,check=True)
  assert ('<'+symbol+'>:').encode() in r.stdout
  target.write_bytes(r.stdout)
  captures.append({'path':target.name,'argv':cmd,'sha256':hashlib.sha256(r.stdout).hexdigest(),'bytes':len(r.stdout)})
  if symbol==execute:
   assert b'OperationInvocation6submit' in r.stdout and b'Completion4wait' in r.stdout
   assert b'CompletionD' in r.stdout
   assert not any(b'@plt' in l for l in r.stdout.splitlines() if b'OperationInvocation6submit' in l or b'Completion4wait' in l)
result={'state':'PASS','scope':'Retrospective actual ELF executable symbols/disassembly; full headers and object arm disassembly separate. Timed erased callbacks each move +16B without changing size; GenericArm bodies do not move and that stronger perturbation is not claimed. Cold12B prefix replaces previous link padding so total .text size stays identical. Both arm execute bodies call same static submit/wait and use two native Buffer::read dispatches plus completion destruction, with identical optimized byte sizes.','changed_text_symbols':changes,'execute_bodies':{'primary':x[execute],'placement':y[execute]},'captures':captures,'limits':'This verifies host loop placement, not GPU kernel address sensitivity or every vendor instruction. No hardware-counter causal claim.'}
(out/'linked-functions.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'state':'PASS','changed_symbols':len(changes),'timed_callback_delta_bytes':16,'execute_bytes':[v['bytes'] for v in x[execute]]}))
