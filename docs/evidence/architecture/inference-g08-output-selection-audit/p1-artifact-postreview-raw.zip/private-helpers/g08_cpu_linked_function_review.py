from pathlib import Path
import hashlib,json,struct

base=Path('C:/h7/g08-p1-cpu/qualified-build-1')
out=Path('.scratch/inference-gaps/g08-artifact-postreview-1/cpu')
assert not (out/'linked-functions.json').exists()
def object_function(path, contains):
 b=path.read_bytes();machine,n,_,symoff,count,optional,_=struct.unpack_from('<HHIIIHH',b)
 assert machine==0x8664 and optional==0
 strings=b[symoff+count*18:]
 symbols={};found=[];i=0
 while i<count:
  s=b[symoff+i*18:symoff+(i+1)*18]
  name=(strings[struct.unpack_from('<I',s,4)[0]:].split(b'\0',1)[0] if s[:4]==b'\0'*4 else s[:8].rstrip(b'\0')).decode()
  value,sec,typ,storage,aux=struct.unpack_from('<IhHBB',s,8)
  symbols[i]=name
  if name.startswith(contains) and sec>0 and typ==0x20: found.append((name,value,sec))
  i+=1+aux
 assert len(found)==1, found
 name,value,sec=found[0]
 sh=struct.unpack_from('<8sIIIIIIHHI',b,20+(sec-1)*40)
 assert value==0
 code=b[sh[4]:sh[4]+sh[3]];rel=[]
 for j in range(sh[7]):
  offset,index,kind=struct.unpack_from('<IIH',b,sh[5]+j*10)
  assert kind==4, ('Unexpected instruction relocation',kind)
  rel.append({'offset':offset,'symbol':symbols[index]})
 return name,code,rel

def pe_text(path):
 b=path.read_bytes();off=struct.unpack_from('<I',b,60)[0]
 n,opt=struct.unpack_from('<H',b,off+6)[0],struct.unpack_from('<H',b,off+20)[0]
 for i in range(n):
  s=struct.unpack_from('<8sIIIIIIHHI',b,off+24+opt+i*40)
  if s[0].rstrip(b'\0')==b'.text': return b[s[4]:s[4]+s[1]],s[2]
 raise AssertionError('Missing .text')

rows=[]
for arm in ['candidate','reference']:
 obj=base/'CMakeFiles'/('g08_'+arm+'_arm.dir')/'generic_arm.cc.obj'
 name,code,rel=object_function(obj,'?execute@GenericArm@')
 ignore={p for r in rel for p in range(r['offset'],r['offset']+4)}
 ranges=[];start=0
 for r in rel:
  if r['offset']>start:ranges.append((start,r['offset']))
  start=r['offset']+4
 if start<len(code):ranges.append((start,len(code)))
 for variant in ['primary','placement']:
  exe=base/'bin'/('g08_topk_'+variant+'.exe');text,rva=pe_text(exe)
  first=code[:ranges[0][1]];positions=[];cursor=0
  while True:
   pos=text.find(first,cursor)
   if pos<0:break
   if all(text[pos+l:pos+r]==code[l:r] for l,r in ranges): positions.append(pos)
   cursor=pos+1
  assert len(positions)==1, (arm,variant,positions)
  pos=positions[0];calls=[]
  for r in rel:
   off=r['offset']
   if off and code[off-1]==0xe8:
    target=rva+pos+off+4+struct.unpack_from('<i',text,pos+off)[0]
    calls.append({'instruction_offset':off-1,'target_rva':target,'symbol':r['symbol']})
  assert any('submit@OperationInvocation' in c['symbol'] for c in calls)
  assert any('wait@Completion' in c['symbol'] for c in calls)
  assert sum('read@BufferView' in c['symbol'] for c in calls)==2
  rows.append({'arm':arm,'variant':variant,'symbol':name,'object_sha256':hashlib.sha256(obj.read_bytes()).hexdigest(),'matched_linked_rva':rva+pos,'code_bytes':len(code),'verified_nonrelocated_bytes':len(code)-len(ignore),'calls':calls})
result={'state':'PASS','scope':'Same already-executed immutable PE files; actual GenericArm execute bytes match each independently compiled COFF object excluding only documented linker relocation fields. Full final disassembly retained separately. Both arms call the same static public submit/wait/two reads and step completion destructor. This does not inspect every vendor instruction.','functions':rows}
(out/'linked-functions.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'state':'PASS','matched_rvas':[{k:r[k] for k in ['arm','variant','matched_linked_rva','code_bytes']} for r in rows]}))
