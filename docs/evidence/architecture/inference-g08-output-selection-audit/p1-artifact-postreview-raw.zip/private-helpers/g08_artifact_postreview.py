"""Read-only retrospective evidence for the exact already-executed G08 artifacts."""
from pathlib import Path
import argparse, hashlib, json, os, re, struct, subprocess, sys

p = argparse.ArgumentParser()
p.add_argument('--route', choices=['cpu', 'cuda', 'apple', 'vulkan'], required=True)
p.add_argument('--output', type=Path, required=True)
a = p.parse_args()
win, mac = sys.platform == 'win32', sys.platform == 'darwin'
base = Path('C:/h7') if win else Path('/Users/kiro' if mac else '/root') / 'hyle-scratch/compute-unified'
folder = base / ('g08-p1-' + a.route)
build, source = folder / 'qualified-build-1', folder / 'source'
out = a.output
out.mkdir(parents=True, exist_ok=True)
assert not any(out.iterdir()), 'Preserve previous evidence'
job = json.loads((folder / 'qualify-job-1.json').read_text())
assert job['state'] == 'TERMINAL', 'Do not add same-host work during formal sampling'
manifest = json.loads((folder / 'qualification-1/manifest.json').read_text())

def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for b in iter(lambda: f.read(1048576), b''):
            h.update(b)
    return h.hexdigest()

def sections(path):
    with path.open('rb') as f:
        first = f.read(64)
        if first[:2] == b'MZ':
            f.seek(struct.unpack_from('<I', first, 60)[0])
            pe = f.read(24)
            assert pe[:4] == b'PE\0\0'
            n, optional = struct.unpack_from('<H', pe, 6)[0], struct.unpack_from('<H', pe, 20)[0]
            f.seek(optional, 1)
            result = []
            for _ in range(n):
                s = f.read(40)
                name = s[:8].rstrip(b'\0').decode()
                virtual, rva, raw = struct.unpack_from('<III', s, 8)
                result.append({'name': name, 'bytes': virtual, 'file_bytes': raw, 'virtual_address': rva})
            return result
        if first[:4] == b'\x7fELF':
            assert first[4:6] == b'\x02\x01', 'Expected little-endian ELF64'
            off = struct.unpack_from('<Q', first, 40)[0]
            entry, count, strings = struct.unpack_from('<HHH', first, 58)
            f.seek(off)
            headers = [f.read(entry) for _ in range(count)]
            st = struct.unpack_from('<IIQQQQIIQQ', headers[strings])
            f.seek(st[4]); names = f.read(st[5])
            result = []
            for s in headers:
                v = struct.unpack_from('<IIQQQQIIQQ', s)
                result.append({'name': names[v[0]:].split(b'\0', 1)[0].decode(), 'bytes': v[5], 'virtual_address': v[3]})
            return result
        assert first[:4] == b'\xcf\xfa\xed\xfe', 'Expected thin little-endian Mach-O64'
        count = struct.unpack_from('<I', first, 16)[0]
        f.seek(32)
        result = []
        for _ in range(count):
            start = f.tell(); cmd, length = struct.unpack('<II', f.read(8))
            f.seek(start); data = f.read(length)
            if cmd == 0x19:
                nsects = struct.unpack_from('<I', data, 64)[0]
                for i in range(nsects):
                    v = struct.unpack_from('<16s16sQQIIIIIIII', data, 72 + i * 80)
                    result.append({'name': v[0].rstrip(b'\0').decode(), 'segment': v[1].rstrip(b'\0').decode(), 'bytes': v[3], 'virtual_address': v[2]})
        return result

commands = []
def capture(name, args):
    target = out / name
    env = dict(os.environ, VSLANG='1033', LC_ALL='C')
    with target.open('wb') as f:
        r = subprocess.run([str(x) for x in args], stdout=f, stderr=subprocess.STDOUT, env=env)
    commands.append({'output': name, 'argv': [str(x) for x in args], 'exit_code': r.returncode, 'sha256': sha(target), 'bytes': target.stat().st_size})
    assert r.returncode == 0, (name, r.returncode)
    return target

binaries = []
for role in ['primary', 'placement']:
    exe = build / 'bin' / ('g08_topk_' + role + ('.exe' if win else ''))
    artifact = next(x for x in manifest['artifacts'] if x['id'] == 'topk-' + role)
    digest = sha(exe)
    assert digest == artifact['file']['sha256'], 'Executed artifact changed'
    ss = sections(exe)
    text = next(x for x in ss if x['name'] in ['.text', '__text'])
    binaries.append({'role': role, 'path': str(exe), 'sha256': digest, 'bytes': exe.stat().st_size, 'text': text, 'sections': ss})

if win:
    tool = Path('C:/Program Files/Microsoft Visual Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/bin/Hostx64/x64/dumpbin.exe')
    for b in binaries:
        for option, suffix in [('/HEADERS', 'headers'), ('/IMPORTS', 'imports'), ('/DISASM:NOBYTES', 'disasm')]:
            capture(b['role'] + '-' + suffix + '.txt', [tool, option, b['path']])
    for role in ['candidate', 'reference']:
        lib = build / ('g08_' + role + '_arm.lib')
        capture(role + '-arm-disasm.txt', [tool, '/DISASM:NOBYTES', '/SYMBOLS', '/RELOCATIONS', lib])
else:
    for b in binaries:
        if mac:
            capture(b['role'] + '-headers.txt', ['/usr/bin/otool', '-l', b['path']])
            capture(b['role'] + '-dependencies.txt', ['/usr/bin/otool', '-L', b['path']])
            capture(b['role'] + '-symbols.txt', ['/usr/bin/nm', '-n', b['path']])
        else:
            capture(b['role'] + '-headers.txt', ['readelf', '--wide', '--sections', b['path']])
            capture(b['role'] + '-dependencies.txt', ['readelf', '--dynamic', b['path']])
            capture(b['role'] + '-symbols.txt', ['nm', '-n', '-S', b['path']])
    for role in ['candidate', 'reference']:
        lib = build / ('libg08_' + role + '_arm.a')
        capture(role + '-arm-disasm.txt', ['/usr/bin/otool', '-tvV', lib] if mac else ['objdump', '-C', '-dr', lib])
        capture(role + '-arm-symbols.txt', ['/usr/bin/nm', '-u', lib] if mac else ['nm', '-C', '-u', lib])

compile_commands = json.loads((build / 'compile_commands.json').read_text())
selected = [x for x in compile_commands if Path(x['file']).name in ['generic_arm.cc', 'apple_arm.cc', 'vulkan_arm.cc', 'placement.cc', 'topk_bench.cc']]
assert len(selected) == 5
(out / 'selected-compile-commands.json').write_text(json.dumps(selected, indent=2) + '\n')
delta = binaries[1]['text']['bytes'] - binaries[0]['text']['bytes']
receipt = {'schema': 'hyle.g08-retrospective-artifact-review/v1', 'state': 'CAPTURED_MANUAL_REVIEW_PENDING', 'route': a.route,
 'candidate': '5103c13d8ed119b06aa64e799f9768aea45ab913', 'benchmark_revision': job['source_revision'],
 'timing': 'Retrospective read-only review of identical executed immutable binaries after formal P1. Missing section sizes/disassembly were not recorded at preflight; this evidence does not backdate them or the independent review.',
 'binaries': binaries, 'text_delta_bytes': delta, 'text_delta_fraction': delta / binaries[0]['text']['bytes'],
 'placement_source': {'path': str(source / 'bench/compute_ops/placement.cc'), 'sha256': sha(source / 'bench/compute_ops/placement.cc'), 'text': (source / 'bench/compute_ops/placement.cc').read_text()},
 'commands': commands, 'hardware_counters': 'NOT_COLLECTED; no cache, instruction-count, or hardware-counter causal claim',
 'limits': 'Host code/section/import evidence and shared optimization settings only. Runtime numerical/actual device/sanitizer results are separate. No claim to inspect every vendor instruction or to have repeated the formal experiment.'}
(out / 'capture.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({'route': a.route, 'text_sizes': [b['text']['bytes'] for b in binaries], 'delta': delta, 'outputs': len(commands), 'state': receipt['state']}))
