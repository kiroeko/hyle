from pathlib import Path
import collections,hashlib,json,re,subprocess

root=Path('.scratch/inference-gaps/g08-artifact-postreview-1')
for route,cls in [('apple','AppleArm'),('vulkan','VulkanArm')]:
 out=root/route;assert not (out/'linked-functions.json').exists()
 def symbols(variant):
  result=collections.defaultdict(list);all_text=[]
  for line in (out/(variant+'-symbols.txt')).read_text().splitlines():
   s=line.split(maxsplit=2)
   if len(s)==3 and s[1] in 'tT':
    address=int(s[0],16);result[s[2]].append(address);all_text.append(address)
  return dict(result),sorted(set(all_text))
 variants={v:symbols(v) for v in ['primary','placement']}
 execute='__ZN3g0812_GLOBAL__N_1'+str(len(cls))+cls+'7executeEv'
 first=variants['primary'][0];second=variants['placement'][0]
 names=[execute]+[n for n in first if 'runErasedOp' in n]
 assert len(names)==3 and len(first[execute])==len(second[execute])==2
 assert all([b-a for a,b in zip(first[n],second[n])]==[20]*len(first[n]) for n in names)
 captures=[];functions=[]
 def remote(name,args):
  command=['ssh','-o','BatchMode=yes','-o','ConnectTimeout=10','kiro@172.22.10.198']+args
  data=subprocess.check_output(command,stderr=subprocess.STDOUT)
  (out/name).write_bytes(data)
  captures.append({'path':name,'argv':command,'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)})
  return data.decode()
 for variant in ['primary','placement']:
  binary='/Users/kiro/hyle-scratch/compute-unified/g08-p1-'+route+'/qualified-build-1/bin/g08_topk_'+variant
  indirect=remote(variant+'-indirect-symbols.txt',['/usr/bin/otool','-Iv',binary])
  for i,name in enumerate(names+(['_g08_topk_placement_prefix'] if variant=='placement' else [])):
   for j,start in enumerate(variants[variant][0][name]):
    end=next(x for x in variants[variant][1] if x>start)
    output=variant+'-linked-function-'+str(i)+'-'+str(j)+'.txt'
    text=remote(output,['/Library/Developer/CommandLineTools/usr/bin/llvm-objdump','-d','--no-show-raw-insn','--start-address='+str(start),'--stop-address='+str(end),binary])
    assert name in text
    if name==execute:
     assert 'Invocation6submit' in text and 'Completion4wait' in text
     if route=='vulkan':assert sum('Context8download' in l for l in text.splitlines() if '\tbl\t' in l)==2
    functions.append({'variant':variant,'symbol':name,'address':start,'bytes_until_next_text_symbol':end-start,'disassembly':output})
 result={'state':'PASS','scope':'Exact already-executed Mach-O binaries. Both independently compiled execute bodies and both timed nanobench erased callbacks move20B. Actual static submit/Completion.wait retained; Vulkan two namespace-correct Context.download calls, Apple native result data after checked completion and two memcpy readbacks, plus result/lease destruction retained. Import stub mapping is saved separately; generic llvm-objdump labels for dylib stubs are not treated as real imported-symbol names.','functions':functions,'captures':captures,'limits':'Finite host codegen/placement review only, no Metal/SPIR-V address-control or every-vendor-instruction claim; no new runtime tests or hardware counters.'}
 (out/'linked-functions.json').write_text(json.dumps(result,indent=2)+'\n')
 print(json.dumps({'route':route,'state':'PASS','functions':len(functions),'execute_bytes':[f['bytes_until_next_text_symbol'] for f in functions if f['symbol']==execute],'address_delta_bytes':20}))
