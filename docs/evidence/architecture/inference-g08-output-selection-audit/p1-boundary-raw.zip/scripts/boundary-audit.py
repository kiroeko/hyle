from pathlib import Path
import hashlib,json,subprocess,zipfile
root=Path(__file__).resolve().parents[2]
intake=root/'.scratch/inference-gaps/g08-p1-source-intake'
data=json.loads((intake/'receipt.json').read_text())
out=root/'evidence/architecture/inference-g08-output-selection-audit'
assert not (out/'p1-boundary.json').exists()
assert not (root/'bench/inference_output_selection').exists(),'Boundary must precede benchmark construction'
baseline=data['baseline'];candidate=data['candidate']
def anchor(path,*symbols):
    result=dict(path=path,versions={})
    for version in ['baseline','candidate']:
        content=(intake/version/path).read_bytes();lines=content.decode('utf-8').splitlines()
        found={s:[i+1 for i,line in enumerate(lines) if s in line] for s in symbols}
        assert all(found.values()),(path,version,found)
        result['versions'][version]=dict(sha256=hashlib.sha256(content).hexdigest(),symbols=found)
    return result
common=anchor('src/compute/operation.cc','OperationInvocation::submit','create_invocation(')
completion=anchor('src/compute/completion.cc','Completion::wait','Completion::reset')
cpu=anchor('src/compute_provider_ggml/standard_index.cc','void top_k(','Status run(','Status create_invocation(')
cuda=anchor('src/compute_provider_cuda/collectives_provider.cc','detail::EnqueueResult submit(','Provider cccl_provider(')
cuda_math=anchor('src/compute_provider_cuda/collectives.cu','configure_typed(','submit_typed(')
cuda_wait=anchor('src/compute_backend_cuda/cuda_backend.cc','Status wait_slot(','Status completion_wait(')
cuda_read=anchor('src/compute_backend_cuda/cuda_memory.cc','Status CudaResourceBase::read(')
apple=anchor('src/compute_route_apple/apple_context.cc','Status evaluate_mlx(','void finish(','void execute_with(','Invocation::submit_guarded(','Context::compile(')
apple_lower=anchor('src/compute_route_apple/apple_tensor.cc','lower_tensor(')
apple_prepare=anchor('src/compute_route_apple/apple_operations.cc','Context::prepare(','return detail::lower_tensor(')
vulkan=anchor('src/compute_route_vulkan/vulkan_program.cc','Invocation::submit_guarded(','prepare_plan(')
vulkan_wait=anchor('src/compute_route_vulkan/vulkan_run.cc','retire_regions(','WaitForFences(','completion_vtable')
vulkan_read=anchor('src/compute_route_vulkan/vulkan_transfer.cc','Status transfer(','completion->wait()','Context::download(')
phases=[
 dict(phase='Context/Queue/program/slot construction and fixed input/host readback buffer allocation',candidate='DEFERRED',peer='DEFERRED',reason='Persistent single-step decode/batch consumer. Both arms have one independent invocation, queue/native context and stable resident input, two output ports, original workspace and native owners. Cold costs remain in P0; do not move old per-call sort work into construction.',anchors=[common,apple,vulkan]),
 dict(phase='Input upload and original compile/JIT/library warmup',candidate='DEFERRED',peer='DEFERRED',reason='Upload the exact same normal-F32 bytes once per arm; complete all uploads and cold compilation before timing. Three independent-oracle cycles and eight complete warm iterations per arm precede samples. No logits upload is hidden in one arm only.',anchors=[apple,common,vulkan_read]),
 dict(phase='Stable native input bind',candidate='DEFERRED',peer='DEFERRED',reason='Apple/Vulkan bind original resident input once; CPU/CUDA still pass identical borrowed input/output views at every submit. Bound payload is not preselected, repacked or cached by value.',anchors=[apple,vulkan,common]),
 dict(phase='Per-step public admission and native enqueue',candidate='CHARGED',peer='CHARGED',reason='CPU/CUDA OperationInvocation.submit and real QueueSequence/phase/alias checks; Apple/Vulkan Invocation.submit, original result slot and worker/native admission. No Graph Copy adapters added to this one-operation S1 comparison.',anchors=[common,cuda,apple,vulkan]),
 dict(phase='All selection, original full-sort work, keys, conversions and result production',candidate='CHARGED',peer='CHARGED',reason='Both output ports are computed each iteration. Original CPU fills all Entry values and partial_sorts; original CUDA builds/sorts keys+indices and extracts both outputs; original Apple stable argsort/slice/gather; original Vulkan ordinary managed/fallback lowering and full sorting. Candidate original S1 scan/reductions remain hot. All native per-call temporaries and their natural replacement/free are charged.',anchors=[cpu,cuda_math,apple_lower]),
 dict(phase='Checked completion, native retirement and result/error visibility',candidate='CHARGED',peer='CHARGED',reason='Wait through actual public Completion/OwnedResult. CPU shared submit completes inline; CUDA event synchronization/retire_slot precedes success; Apple evaluates, synchronizes stream and waits every output before done; Vulkan waits fence and retires every managed region before terminal success. No event-record-only or result-submission-only timing.',anchors=[completion,cuda_wait,apple,vulkan_wait]),
 dict(phase='Read both selected values and indices to preallocated host result buffers',candidate='CHARGED',peer='CHARGED',reason='F32 values plus I32 indices, exactly8*R*K bytes. CPU BufferView reads; CUDA two actual device-resource reads; Apple native array data+memcpy after successful evaluation; Vulkan two Context.download calls including their staging allocation, command/fence waits, mapping/invalidate/copy and temporary owner destruction. No full-vocabulary D2H; no first-arm-only readback.',anchors=[cuda_read,apple,vulkan_read]),
 dict(phase='Step-local Completion, successful owned result and temporary public handle release',candidate='CHARGED',peer='CHARGED',reason='All step-local objects leave scope before the measured callback returns. Original invocation/program/context owners remain alive. No abandoned completion, cancellation retention or external callback owner is used in these success-only S1 rows.',anchors=[completion,apple,vulkan_wait]),
 dict(phase='Prior retained native result replacement / worker tail in steady replay',candidate='CHARGED',peer='CHARGED',reason='Apple clears prior arrays at each submit and the single runtime worker cannot execute the next job until the prior admitted reference tail returns. Full warm cycles place this cost inside steady replay in both arms. Vulkan buffers are original invocation-owned allocations and wait observes retirement. No per-step Context close is invented.',anchors=[apple,vulkan,vulkan_wait]),
 dict(phase='Last retained result, program/workspace/invocation destruction, runtime/library/allocator caches and final Context/Queue close',candidate='DEFERRED',peer='DEFERRED',reason='One terminal retained native result and Apple post-done wake/deliver(empty)/worker-reference tail may outlive a step wait; the Invocation remains owned, so this tail cannot destroy it. Do not claim all host callbacks or private native caches are freed at step return. Teardown is executed after the timed block, separately recorded, and is the same persistence policy on both sides.',anchors=[apple,common,completion,vulkan_wait]),
 dict(phase='Cancellation, error/OOM/recreation and concurrent slots',candidate='NOT_APPLICABLE',peer='NOT_APPLICABLE',reason='This is the fixed success-only S1 performance workload, not the correctness/risk domain; original ordinary and risk evidence separately cover those required journeys. No applicable unrun risk is changed to N/A here.')
]
receipt=dict(schema='hyle.inference-g08-p1-source-boundary/v1',
 state='SOURCE_BOUNDARY_FROZEN_ADAPTER_BUILD_AND_RUNTIME_QUALIFICATION_PENDING',
 baseline=baseline,candidate=candidate,scope='S1 only. No performance comparison or speed parity claim for RandomBits/Categorical. No engine token/s claim.',
 source_intake=dict(path='p1-boundary-raw.zip',source_files=len(data['sources']),unchanged_files=sum(x['byte_identical'] for x in data['sources'])),
 semantic_contract='Same normal F32 dense last-axis TopK, largest, K1; both original value bits and first-index I32 outputs, successful checked completion and both small host readbacks. Apple additionally K3 holdout. Inputs remain resident; no sampling policies or arithmetic-precision substitution.',
 shapes=[dict(route=route,rows=rows,vocabulary=248320,count=1) for route in ['cpu','cuda','apple','vulkan'] for rows in [1,16]]+[dict(route='apple',rows=16,vocabulary=248320,count=3)],
 input_distribution='Shared fixed integer hash generates normal F32 sign/exponent/mantissa values with full mantissa entropy, bounded magnitudes and explicit normal maxima/ties. No NaN/subnormal/Inf cases where the original Apple baseline is already known wrong. Independent stored-F32 ordering/value-bit/first-index oracle checks both ports before timing. Exact generator/bytes are locked with the benchmark contract before build.',
 topology='Existing same-process nanobench Bench.compare, same iteration counts, cyclic interleaving and both initial execution orders, two independently constructed arm owners, both allocation orders and a pure link/section-placement replica. No new public runner/statistics adapter.',
 references=dict(
  cpu='Compile complete original GGML CPU provider factory, standard_index.cc and native_batch.cc with its original private headers and fixed native dependency, isolated by private ggml_cpu namespace alias. Public explicit ProviderBinding/prepare/Queue/Completion, same backend as candidate. Preflight must confirm the ordinary default route selects this provider/implementation and both explicit arms match it; no cold-route speed claim.',
  cuda='Compile exact original collectives_provider.cc and collectives.cu/private header with private cuda_native namespace alias; original cccl_provider factory, same original backend primary context and public ProviderBinding/prepare/Queue/Completion. Preserve original toolkit/architecture/flags and per-call key construction, sorting and transforms. Ordinary-route provider/implementation identity must match before sampling.',
  apple='Compile original apple_tensor.cc and its original headers with only exported lower_tensor symbol isolated. Call its full typed lowerer through public Context.compile with the original operation/specs/workload/stream; original Context.prepare takes this same compile/lower route. Candidate uses ordinary Context.prepare. Current runtime differs from baseline only in an unrelated invalid numeric error message; TopK success execution is unchanged.',
  vulkan='Compile the complete original compute_route_vulkan module and its owned public/private headers under an isolated Vulkan route namespace, retaining natural public Context/prepare/Invocation/OwnedResult/download and all original ordinary region choices. Common dependency bytes/toolchains and original shader input/generated-payload identity must be verified. Do not force a fallback, copy a benchmark sorting implementation, or inject current S1 lowering into reference.'),
 phase_ledger=phases,
 resource_ledger=dict(
  cpu='Original Entry has double key+I32 index,16bytes on these ABIs:3,973,120 bytes per invocation at V248320, reused across rows; candidate K1 has no V-sized Entry scratch. Both O(RV), serial rows under the original caller-thread executor, two fixed output buffers, original map/flush and Queue/Completion bookkeeping. Creation/free is cold; every old Entry fill/partial_sort and both output copies remain hot.',
  cuda='Old two RV-sized key arrays, two RV-sized I32 index arrays and original CUB temporary workspace; candidate R*sizeof(ArgPair<Acc>) plus original CUB temporary workspace. Record actual public workspace bytes/alignment and owner metadata during preflight. Both use original shared queue and native event pool; no new private threads/capture promise. Full radix sorting is linear in fixed key width but performs more passes; do not describe it as comparison-sort O(VlogV).',
  apple='Original full argsort/key and layout intermediates versus K1 integer ordered-key native arg reduction; K3 still stable argsort/slice/gather with corrected integer keys. MLX owns its allocations/fusion and private caches; all per-call native arrays are hot, final retained owner/caches are cold. Original runtime job mutex/wake/refcounts and result-slot lifetime stay on both sides.',
  vulkan='Original full sorting region/managed runtime and its cold invocation buffers remain intact. Candidate uses two bounded pair-reduction dispatches and8*R*ceil(V/4096) scratch bytes:488B at R1 and7808B at R16. Original queue mutex/fence/managed-retirement overhead is charged; both selected-output download staging allocations and native command/fence/memcpy teardown are charged. Driver/private pools remain separately unknown.',
  common='Same persistent input/output descriptors/owners and public framework. Record actual provider/implementation/runtime properties, declared workspace/persistent/private bytes, native output arity and exact readback bytes. No shared-atomic/lock/wake/syscall count or allocator-zero promise is inferred from a timer. Source anchors define where those existing operations occur.'),
 qualification=dict(practical_margin_percent=5,noninferiority_margin_percent=5,sample_schedule=[15,31],measurement_batch=1,
  numerical='Three complete oracle cycles per arm and eight completed warm cycles. Both outputs and selected source bits must agree on the fixed normal input domain.',
  controls='Existing unified instrument: workload/topology-matched selected-selected and original-original A/A in both orders, original allocation-order control, timer/floor and known-delta controls, primary and pure placement replica. Preserve all failures. No samples upgraded to hide order/placement bias or changed boundaries.',
  machines='CPU Windows/MSVC W1-WIN; CUDA same RTX4070 under W1-WSL and CUDA13.3; Apple and Vulkan actual Air Mac16,12 M1-MAC explicit unbound engineering QoS. Exact profile/toolchain/runtime identities are locked by each future contract; do not infer native Linux, Mac mini, or Windows Vulkan P1 from them.'),
 remaining_qualification=['Independent source/adapter review must follow these anchors and verify all copied source transforms, unchanged dependency inputs and actual factory routes. This freeze is not a runtime comparability PASS.',
  'Build/compile/link audit, original native shader payload and public-port oracle, same-topology A/A/placement and all required instrument controls must PASS before qualified P1.',
  'A product/API/algorithm/normal-cost change requires retreat from CANDIDATE to AUDITED. Failed comparability cannot be repaired by weakening margin, choosing another peer/domain, or moving fees outside the timer.'])
with zipfile.ZipFile(out/'p1-boundary-raw.zip','x',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for p in intake.rglob('*'):
        if p.is_file():z.write(p,p.relative_to(intake))
    z.write(Path(__file__),'scripts/boundary-audit.py')
receipt['source_intake']['sha256']=hashlib.sha256((out/'p1-boundary-raw.zip').read_bytes()).hexdigest()
(out/'p1-boundary.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(state=receipt['state'],shapes=len(receipt['shapes']),phases=len(phases),source_files=len(data['sources']))))
