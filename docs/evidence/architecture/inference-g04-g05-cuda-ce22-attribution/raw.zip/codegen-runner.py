from pathlib import Path
import hashlib,json,re,sqlite3,subprocess,time

root=Path('/mnt/c/public/project-hyle/hyle');base=root/'.scratch/inference-gaps/g04-g05'
out=Path('/root/hyle-scratch/compute-unified/ce22-cuda-product-profile-9')
binary=Path('/root/hyle-scratch/compute-unified/g04-cuda-encoded-p1-fresh-9/bin/g04_cuda_encoded_bench')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
profile=json.loads((out/'result.json').read_text())
assert profile['state']=='TERMINAL_FINITE_DIAGNOSTIC_PASS' and sha(binary)==profile['binary_sha256']
lines=(out/'resource-usage.log').read_text().splitlines();resources={};name=None
for line in lines:
    if line.strip().startswith('Function ') and line.endswith(':'):
        name=line.strip()[len('Function '):-1]
    elif name and 'REG:' in line:resources[name]=line.strip()
db=sqlite3.connect(out/'product.sqlite')
query='''select distinct d.value,m.value,k.registersPerThread
from CUPTI_ACTIVITY_KIND_KERNEL k join StringIds d on k.demangledName=d.id
join StringIds m on k.mangledName=m.id where d.value like ?'''
rows=db.execute(query,('%BatchPrefillWithPagedKVCacheKernel%',)).fetchall()
result=[]
for demangled,mangled,registers in rows:
    assert mangled in resources,mangled
    result.append(dict(demangled=demangled,mangled=mangled,registers=registers,resource=resources[mangled]))
tool='/usr/local/cuda-13.3/bin/cuobjdump';started=time.monotonic()
command=[tool,'--dump-sass','--function',','.join(r['mangled'] for r in result),str(binary)]
with (out/'actual-kernels.sass').open('w') as stream:
    subprocess.run(command,stdout=stream,stderr=subprocess.STDOUT,check=True)
sass=(out/'actual-kernels.sass').read_text();current=None;counts={}
for line in sass.splitlines():
    m=re.search(r'Function\s*:\s*(\S+)',line)
    if m:current=m.group(1);counts.setdefault(current,dict(LDL=0,STL=0))
    if current:
        for instruction in ('LDL','STL'):
            counts[current][instruction]+=len(re.findall(r'\b'+instruction+r'\b',line))
for row in result:row['sass_local_instructions']=counts.get(row['mangled'])
shipping=json.loads((base/'sdk/shipping-cuda-static-ce21-1.json').read_text())
compile_row=next(r for r in shipping if r['file'].endswith('/native_cache.cu'))
include=re.search(r'-I(\S*cache-source-\S*/include)',compile_row['command']).group(1)
header=Path(include)/'flashinfer/attention/prefill.cuh'
text=header.read_text().splitlines();line_ids=set()
needles=('kUseRepack','kMinValidMmaKV','kFixedSmem','kKVSmemPerMmaKV','max_num_mma_kv_reg')
for i,line in enumerate(text):
    if any(n in line for n in needles):line_ids.update(range(max(0,i-3),min(len(text),i+8)))
(out/'actual-dispatch-source.txt').write_text('\n'.join(str(i+1)+':'+text[i] for i in sorted(line_ids))+'\n')
assert sha(binary)==profile['binary_sha256']
record=dict(kind='READ_ONLY_CURRENT_CANDIDATE_CODEGEN_NO_VARIANTS',binary_sha256=sha(binary),
    command=command,elapsed_seconds=time.monotonic()-started,header=str(header),header_sha256=sha(header),
    kernels=result,limits=['Static resources/instruction counts and short trace are mechanism evidence only; no new throughput verdict.'])
(out/'actual-kernel-resources.json').write_text(json.dumps(record,indent=2)+'\n')
(out/'codegen-runner.py').write_bytes(Path(__file__).read_bytes())
print(json.dumps([dict(registers=r['registers'],resource=r['resource'],sass_local_instructions=r['sass_local_instructions'],name=r['demangled'][:110]) for r in result],indent=2))
