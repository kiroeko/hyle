from pathlib import Path
import hashlib,json,zipfile

root=Path('/mnt/c/public/project-hyle/hyle');base=root/'.scratch/inference-gaps/g04-g05'
run=Path('/root/hyle-scratch/compute-unified/ce22-cuda-product-profile-9')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
r=json.loads((run/'result.json').read_text());codegen=json.loads((run/'actual-kernel-resources.json').read_text())
assert r['state']=='TERMINAL_FINITE_DIAGNOSTIC_PASS' and r['max_abs_error']<=8e-3
assert r['qualifier_job']['snapshot']['product_candidate']=='9c9ab88bba3fca5dcc981a2a42100b08af1a45ae'
assert codegen['binary_sha256']==r['binary_sha256']
assert all(row['sass_local_instructions'] is not None for row in codegen['kernels'])
dest=root/'evidence/architecture/inference-g04-g05-cuda-ce22-attribution';dest.mkdir(exist_ok=False)
with zipfile.ZipFile(dest/'raw.zip','w',zipfile.ZIP_DEFLATED) as z:
    for p in sorted(run.rglob('*')):
        if p.is_file():z.write(p,p.relative_to(run).as_posix())
    for name in ['profile_cuda_product9_wsl.py','ce22_codegen_wsl.py','seal_ce22_attribution_wsl.py']:
        z.write(base/name,'runners/'+name)
receipt=dict(kind='CURRENT_CE21_CANDIDATE_QUALIFIED_LOSS_CE22_ATTRIBUTION',
    verdict='PASS_FINITE_READ_ONLY_DIAGNOSTIC_NOT_NEW_PERFORMANCE',product_candidate=r['qualifier_job']['snapshot']['product_candidate'],
    qualified_failure='evidence/performance/inference-g04-g05-cuda-encoded-w1-wsl-p1-attempt-9/receipt.json',
    independent_oracles=24,max_abs_error=r['max_abs_error'],profile_seconds=r['elapsed_seconds'],
    binary_sha256=r['binary_sha256'],shapes=r['shapes'],codegen=codegen,
    facts=['Actual D256 FP8 MMA_KV2/register255/shared49152 versus BF16 MMA_KV1/register240/shared49152.',
        'Actual unequal D64/Dv128 FP8 MMA_KV8/register255/shared40960 versus BF16 MMA_KV4/register177/shared32768.',
        'Codegen shows product window/prefill/holdout stack40/48/120 and8/10/27LDL plus same STL; actual reference stack0 with no LDL/STL.',
        'Current shipping compile command selects cache-source-cf631 private header, not an obsolete generated cache. FP8 minimum valid MMA_KV depends on packed alignment; any resource correction must preserve this constraint.'],
    limits=['One immutable existing artifact, no product changes, variant trials, new sampling or performance verdict.',
        'Trace point times and static instruction counts explain costs but cannot sign a new throughput win.',
        'FI remains CANDIDATE9c9 until an actual finite source-level correction is audited; no G04/G05 or goal closure.'],
    raw_zip_sha256=sha(dest/'raw.zip'))
(dest/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(dict(path=str(dest),profile_seconds=r['elapsed_seconds'],codegen_seconds=codegen['elapsed_seconds'])))
