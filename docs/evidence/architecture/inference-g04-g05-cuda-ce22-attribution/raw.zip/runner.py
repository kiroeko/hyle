from pathlib import Path
from collections import defaultdict
from statistics import median,mean
import hashlib,json,os,re,sqlite3,subprocess,time,uuid
root=Path('/mnt/c/public/project-hyle/hyle')
ext=Path('/root/hyle-scratch/compute-unified')
job=json.loads((root/'.scratch/inference-gaps/g04-g05/cuda-encoded-p1/9/job.json').read_text())
assert job['state']=='TERMINAL' and job['verify_exit']==0,'Wait for actual same parent terminal/strict verify'
cmdline=Path('/proc')/str(job['pid'])/'cmdline'
assert not cmdline.exists() or b'g04-cuda-encoded-p1-output-9' not in cmdline.read_bytes(),'Original qualifier still live'
p=ext/'g04-cuda-encoded-p1-output-9';summary=json.loads((p/'summary.json').read_text())
manifest=json.loads((p/'manifest.json').read_text())
purpose='QUALIFIED_MATERIAL_LOSS_ATTRIBUTION'
assert summary['qualification']=='QUALIFIED' and any(w['combined_noninferiority_gate']=='FAIL' for w in summary['workloads'])
binary=ext/'g04-cuda-encoded-p1-fresh-9/bin/g04_cuda_encoded_bench'
out=ext/'ce22-cuda-product-profile-9';out.mkdir(exist_ok=False)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
aa=json.loads((p/'cuda-encoded-aa.json').read_text());assert aa['gate']=='PASS' and sha(binary)==aa['identity']['artifacts']['primary']
env=os.environ.copy();env.pop('HYLE_BENCH_AA_ROUTE',None);env.update(HYLE_BENCH_VERIFY_ONLY='1',HYLE_PERF_RUN_NONCE=uuid.uuid4().hex)
command=['nsys','profile','--trace=cuda','--sample=none','--cpuctxsw=none','--export=sqlite','--force-overwrite=false','--output='+str(out/'product'),str(binary)]
record=dict(state='SETUP',purpose=purpose,command=command,binary_sha256=sha(binary),qualifier_job=job,original_summary_sha256=sha(p/'summary.json'),nsys_version=subprocess.check_output(['nsys','--version'],text=True).strip())
(out/'runner.py').write_bytes(Path(__file__).read_bytes())
def save():(out/'result.json').write_text(json.dumps(record,indent=2)+'\n')
save();started=time.monotonic()
with (out/'profile.log').open('w') as f:
 child=subprocess.Popen(command,env=env,stdout=f,stderr=subprocess.STDOUT);record.update(state='RUNNING',pid=child.pid);save();print('profile',child.pid,flush=True);code=child.wait()
record.update(exit_code=code,elapsed_seconds=time.monotonic()-started,state='TERMINAL_CAPTURE_PASS' if code==0 else 'TERMINAL_CAPTURE_FAIL');save()
assert code==0 and sha(binary)==record['binary_sha256']
log=(out/'profile.log').read_text();errors=re.findall(r'# CUDA_ENCODED_CORRECTNESS max_abs_error=([^ ]+)',log)
assert len(errors)==24 and max(map(float,errors))<=8e-3 and log.count('# CUDA_FP8_PAIR ')==3
numeric=json.loads((root/'evidence/correctness/inference-g04-g05-cuda-ce21-register-numeric-rebind/receipt.json').read_text())['successful_run']
facts=[re.sub(r' original=[01]$','',line) for line in log.splitlines() if line.startswith('# CUDA_ENCODED_ENV ')]
assert len(facts)==6 and set(facts)=={numeric['native_environment']}
c=sqlite3.connect(out/'product.sqlite')
kernels=c.execute('select k.start,k.end,s.value,k.gridX,k.gridY,k.gridZ,k.blockX,k.blockY,k.blockZ,k.registersPerThread,k.dynamicSharedMemory,k.correlationId from CUPTI_ACTIVITY_KIND_KERNEL k join StringIds s on k.demangledName=s.id order by k.start').fetchall()
launches=defaultdict(list)
for correlation,start,end,name in c.execute('select r.correlationId,r.start,r.end,s.value from CUPTI_ACTIVITY_KIND_RUNTIME r join StringIds s on r.nameId=s.id'):
 if 'LaunchKernel' in name:launches[correlation].append(dict(name=name,ns=end-start))
rows=[];decoder=0;shape=-1
for begin,end,name,gx,gy,gz,bx,by,bz,regs,shared,correlation in kernels:
 if 'cuda_original' in name and 'decode_rows' in name:
  if decoder%2==0:shape+=1
  decoder+=1;kind='cold_decoder'
 elif 'hyle_benchmark_original_flashinfer_69ff' in name:kind='original_merge' if 'MergeStates' in name else 'original_attention'
 elif 'scale_cast<' in name:kind='selected_scale_cast'
 elif 'MergeStates' in name:kind='selected_merge'
 elif 'BatchPrefillWithPagedKVCacheKernel' in name:kind='selected_attention'
 else:kind='other'
 rows.append(dict(shape=shape,kind=kind,start_ns=begin,duration_ns=end-begin,name=name,grid=[gx,gy,gz],block=[bx,by,bz],registers=regs,dynamic_shared=shared,launch_api=launches[correlation]))
assert decoder==6 and shape==2
facts=[]
for shape in range(3):
 kinds=defaultdict(list)
 for row in rows:
  if row['shape']==shape:kinds[row['kind']].append(row)
 assert len(kinds['selected_attention'])==8 and len(kinds['original_attention'])==8
 facts.append({kind:dict(count=len(rs),median_ns=median(r['duration_ns'] for r in rs),mean_ns=mean(r['duration_ns'] for r in rs),registers=sorted({r['registers'] for r in rs}),dynamic_shared=sorted({r['dynamic_shared'] for r in rs}),grids=sorted({tuple(r['grid']) for r in rs})) for kind,rs in kinds.items()})
(out/'kernel-attribution.json').write_text(json.dumps(dict(state='DIAGNOSTIC_ONLY_NO_NEW_PERFORMANCE_VERDICT',shapes=facts,kernels=rows),indent=2)+'\n')
record.update(state='TERMINAL_FINITE_DIAGNOSTIC_PASS',max_abs_error=max(map(float,errors)),shapes=facts);record.pop('pid',None);save();print(json.dumps(facts),flush=True)
