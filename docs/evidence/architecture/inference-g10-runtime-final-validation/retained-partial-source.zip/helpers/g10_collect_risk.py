from pathlib import Path
import json,shlex,subprocess,zipfile

root=Path('C:/public/project-hyle/hyle')
for host,base,names in [('air','/Users/kiro/hyle-scratch/compute-unified',['g10-host-tsan-1','g10-host-tsan-2']),('wsl','/root/hyle-scratch/compute-unified',['g10-host-asan-1','g10-host-ubsan-1'])]:
 out=root/'.scratch/inference-gaps/g10-host-risks'/host
 out.mkdir(parents=True,exist_ok=False)
 code='''from pathlib import Path
import sys,zipfile
base=Path(BASE)
with zipfile.ZipFile(sys.stdout.buffer,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for name in NAMES:
  folder=base/name
  assert folder.is_dir(),folder
  for p in sorted(folder.rglob('*')):
   if p.is_file():z.write(p,name+'/'+p.relative_to(folder).as_posix())
'''.replace('BASE',repr(base)).replace('NAMES',repr(names))
 args=['ssh','kiro@172.22.10.198','python3','-c',shlex.quote(code)] if host=='air' else ['wsl','-d','Ubuntu-24.04','--','python3','-c',code]
 with (out/'raw.zip').open('xb') as stream:p=subprocess.run(args,stdout=stream,stderr=subprocess.PIPE)
 assert p.returncode==0,p.stderr.decode(errors='replace')
 with zipfile.ZipFile(out/'raw.zip') as z:
  for item in z.infolist():
   path=Path(item.filename);assert not path.is_absolute() and '..' not in path.parts
  z.extractall(out/'collected')
 print(json.dumps(dict(host=host,rows=[{k:json.loads((out/'collected'/n/'result.json').read_text()).get(k) for k in ['state','mode','elapsed_seconds','error']} for n in names])),flush=True)
