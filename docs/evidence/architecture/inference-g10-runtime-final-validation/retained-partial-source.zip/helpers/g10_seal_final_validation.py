from pathlib import Path
import hashlib,json,subprocess,zipfile

root=Path('C:/public/project-hyle/hyle')
private=root/'.scratch/inference-gaps'
inputs=private/'g10-delivery-inputs'
manifest=json.loads((inputs/'inputs.json').read_text())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for item in manifest['files']:assert sha(root/item['path'])==item['sha256'],item['path']
out=root/'evidence/architecture/inference-g10-runtime-final-validation'
out.mkdir(exist_ok=False)
folders=[('windows/cpu-cuda-1',private/'g10-windows-cpu-cuda-1'),('windows/cpu-cuda-2',private/'g10-windows-cpu-cuda-2'),
 ('windows/off-1',private/'g10-windows-host-disabled-1'),('windows/off-2',private/'g10-windows-host-disabled-2'),
 ('windows/asan-preflight-1',private/'g10-windows-host-asan-1'),
 ('wsl/asan-1',private/'g10-host-risks/wsl/collected/g10-host-asan-1'),
 ('wsl/ubsan-1',private/'g10-host-risks/wsl/collected/g10-host-ubsan-1'),
 ('air/tsan-1',private/'g10-host-risks/air/collected/g10-host-tsan-1'),
 ('air/tsan-2',private/'g10-host-risks/air/collected/g10-host-tsan-2')]
rows=[];raw=[]
for name,folder in folders:
 r=json.loads((folder/'result.json').read_text())
 rows.append(dict(path=name,state=r['state'],stage=r.get('stage'),seconds=r['elapsed_seconds'],result_sha256=sha(folder/'result.json')))
 for p in sorted(folder.rglob('*')):
  if p.is_file():raw.append((p,name+'/'+p.relative_to(folder).as_posix()))
joint=json.loads((folders[1][1]/'result.json').read_text())
assert joint['state']=='PUBLIC_CPU_CUDA_MATH_LIFECYCLE_WITH_SHARED_STARTUP_LIMIT_PASS'
assert 'G10 startup + original public math/lifecycle/executor consumer PASS' in (folders[1][1]/'public-joint.log').read_text()
assert 'CPU+CUDA inference: CPU norm/casts, CUDA gated FFN, FP16 weight fragments passed' in (folders[1][1]/'public-joint.log').read_text()
for name,folder in [folders[5],folders[6],folders[8]]:
 r=json.loads((folder/'result.json').read_text())
 assert r['state']=='FEATURE_ON_INSTRUMENTED_G10_STATE_AND_PUBLIC_CONSUMERS_PASS'
 assert 'torch=TRUE' in r['features']
 core=json.loads((folder/'instrumented-core-commands.json').read_text())
 apps=json.loads((folder/'instrumented-app-commands.json').read_text())
 assert len(core)==4 and len(apps)==3
 flag='-fsanitize='+{'asan':'address','ubsan':'undefined','tsan':'thread'}[r['mode']]
 assert all(flag in c['command'] for c in core+apps)
 assert len(r['stages'])==14
 assert all(s['exit']==0 for s in r['stages'])
 if r['mode']=='tsan':
  assert r['original_fence_model']['sha256']=='2b90ab655a49ec3b9158a964872cd1fc3395ebf64d8ae430a2e19c4805bf5416'
  assert all(r['original_fence_model']['path'].rsplit('/hyle/',1)[0] in c['command'] for c in core+apps)
 for x in ['startup','query-first','late-native','late-aten','race-use','race-config','metadata-oom','graph-executor']:
  assert next(s for s in r['stages'] if s['stage']=='public-'+x)['exit']==0
for label in ['1','2']:
 folder=private/('g08-windows-static-native-reuse-g10-joint-'+label)
 for p in sorted(folder.rglob('*')):
  if p.is_file():raw.append((p,'cuda-reuse-'+label+'/'+p.relative_to(folder).as_posix()))
review=private/'g10-delivery-risk-review-3.json'
assert sha(review)=='5fb52ec37d506de87a90551dc5cfebca69946f86d9739fd2e6e7388d226fc351'
(out/'review.json').write_bytes(review.read_bytes())
obj='/root/hyle-scratch/compute-unified/l-cpu-cuda/selected-graph/static-sdk-build/src/compute_provider_native/CMakeFiles/hyle_compute_provider_native.dir/aten_cpu_provider.cc.o'
nm=subprocess.check_output(['wsl','-d','Ubuntu-24.04','--','nm','-S','--defined-only','--demangle',obj],text=True)
lines=[line for line in nm.splitlines() if 'thread_runtime' in line or 'thread_state' in line]
state=next(line for line in lines if line.endswith('thread_state()::value'))
assert int(state.split()[1],16)==48,state
(out/'p0-symbols.txt').write_text('\n'.join(lines)+'\n',encoding='utf8')
objhash=subprocess.check_output(['wsl','-d','Ubuntu-24.04','--','sha256sum',obj],text=True).split()[0]
before=subprocess.check_output(['git','show','0f852b231:include/hyle/compute/cpu.h'],cwd=root).decode()
after=(root/'include/hyle/compute/cpu.h').read_text()
options=lambda text:text.split('struct DefaultContextOptions final {',1)[1].split('};',1)[0]
assert options(before)==options(after)
for name in ['g10-loc-cpu.txt','g10-loc-native.txt']:
 assert 'self-check: PASS' in (private/name).read_text()
 (out/name.replace('g10-','')).write_bytes((private/name).read_bytes())
p0=dict(verdict='PASS_P0_COMMON_COLD_STATE',source_commit=manifest['head'],symbol_object=dict(path=obj,sha256=objhash),
 fixed_state_bytes_on_observed_linux_gcc14_x86_64=48,
 hyle_storage='One fixed std::mutex + requested uint32 + three bools per loaded native code image; original DefaultContextOptions unchanged; no new Program/Invocation/Queue/replay fields or explicit HYLE pool/heap owner.',
 configure='Cold only. Invalid count returns before runtime access. One mutex; first request closes window before original ATen setter then checks getter before publishing. Same value is getter-only. Failure closes conservatively without rollback.',
 observation='Cold only. One mutex. Open query never calls ATen getters; closed query calls original intra/inter-op getters and observes drift without setting.',
 first_use='Bounded cold mutex/state updates at ordinary CPU factory admission, actual Native/ATen provider admission and Native low-precision prepare before original warmup; qualified premise checked only on cold rule/propose paths.',
 hot_math='No setter/reset/lock or new state in math/replay; existing provider algorithms, data/workspaces and executor/ggml budget fields unchanged.',
 unknown='ATen/OpenMP/BLAS/platform startup allocation/private pools and contended mutex OS costs remain vendor/platform costs, not zero or a process live-thread cap.',
 loc='Unified loc-report.py --module ... --commit 0022... --self-check both PASS; conventional module implementation boundaries count src only (CPU252/4files, Native5343/17files), not split public-header ownership. No manual addition or new whole-repository report.')
(out/'p0.json').write_text(json.dumps(p0,indent=2)+'\n',encoding='utf8')
with zipfile.ZipFile(out/'raw.zip','x',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p,name in raw:z.write(p,name)
with zipfile.ZipFile(out/'source.zip','x',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for name in ['g10_host_risk.py','g10_windows_joint.py','g10_collect_risk.py','g10_seal_final_validation.py']:
  z.write(private/name,'helpers/'+name)
 for name in ['samples/package/graph/cpu_cuda/main.cc','samples/package/graph/cpu_cuda/inference.h','samples/package/compute/cpp/workload.h','samples/package/compute/cpp/inference.h']:
  z.write(root/name,'product/'+name)
 z.write(inputs/'inputs.json','inputs.json')
receipt=dict(schema='hyle.g10-runtime-final-validation/v1',verdict='PUBLIC_CPU_CUDA_AND_FEATURE_ON_ASAN_UBSAN_TSAN_PASS',
 owner_state='PENDING_CANDIDATE_AND_FINAL_MAINTENANCE_GATES',source_commit=manifest['head'],source_tree=manifest['tree'],
 source_archive_sha256=manifest['archive_sha256'],all_source_cohort_hashes_rechecked=True,
 attempts=rows,retained_elapsed_seconds=sum(r['seconds'] for r in rows),
 direct_consumer=dict(verdict='PASS',result='windows/cpu-cuda-2/result.json',binary=joint['binary'],
  scope='Actual RTX4070 CPU normalization/casts around CUDA gated FFN, two real slots, weight fragment DMA, leases/native completion/replay and close/drain after startup limit2. TESTS ON/instrumentation OFF tree; no installed SDK or P1 claim.'),
 sanitizers=[dict(host=name.split('/')[0],mode=json.loads((folder/'result.json').read_text())['mode'],verdict='PASS',result=name+'/result.json') for name,folder in [folders[5],folders[6],folders[8]]],
 applicability=dict(off_current_public_cpu='NOT_APPLICABLE: CPU route derives required Torch ON; old option is rejected; GPU-only removes CPU facade. Both OFF config failures retained, no forced macro/new feature switch and no OFF runtime PASS.',
  native_thread_backend='NOT_APPLICABLE on the current three qualified SDKs: each actual backend=OpenMP. Real Native provider/lowprecision admission remains actually exercised, distinct from the ATen Native threading backend.',
  positive_f4_cached_recipe='Previously sealed NOT_APPLICABLE source identity precondition retained; no positive cached runtime claim.',
  foreign_setter_exceptions='SOURCE_REVIEW/NOT_EXERCISED: actual vendor setter/getter bad_alloc/c10/std::exception paths were not induced. Source verifies close-before-set, publish-after-check and conservative failure; metadata OOM is a separate actual HYLE entry test.'),
 preserved_failures=['Windows joint wrapper missing original relative headers, repaired by including the unchanged canonical sample with its natural relative header layout.',
  'OFF configure1 rejects two defined selectors; configure2 rejects retired provider option. Actual CPU-only ordinary product derives Torch ON.',
  'Windows ASan preflight618edges rejected before build; no identified Windows-specific new memory mechanism; common state memory on warm WSL ASan, UB on WSL UBSan, concurrency on Air TSan per independent review.',
  'Air TSan parent initially omitted original explicit macOS14.4 deployment requirement; restored in private parent, same product/build/toolchain/model; failure and elapsed retained.'],
 limits=['No leak sanitizer/private Torch/OpenMP/BLAS pool/GPU-driver instrumentation claim. Original refcount final-fence TSan model only, exact hash/source-equivalence verified; no annotation or suppression for the new mutex/state.',
  'No G09 A/A recovery, P1 qualification, or engine token/s conclusion.'],
 archives=[dict(path=p.name,bytes=p.stat().st_size,sha256=sha(p)) for p in [out/'raw.zip',out/'source.zip']],
 files=[dict(path=p.name,sha256=sha(p)) for p in [out/'review.json',out/'p0.json',out/'p0-symbols.txt',out/'loc-cpu.txt',out/'loc-native.txt']])
(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf8')
print(json.dumps(dict(verdict=receipt['verdict'],seconds=receipt['retained_elapsed_seconds'],archives=receipt['archives'])),flush=True)
