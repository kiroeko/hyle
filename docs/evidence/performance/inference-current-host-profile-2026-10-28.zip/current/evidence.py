"""One offline evidence archive. Never imports/runs builders or native tools."""
from pathlib import Path
from collections import Counter
import hashlib
import json
import sqlite3
import sys
import zipfile
W=Path(__file__).resolve().parent
R=W.parent.parent
DEST=R/'docs/evidence/performance/inference-current-host-profile-2026-10-28'
NAMES=('r1-auto','r1-peer','mtp-hyle','mtp-peer')
PEER=R/'.scratch/inference-cuda-current-attribution-20261026/peer'
OLD=R/'.scratch/inference-current-review-profile-20261027'


def read(p):return json.loads(Path(p).read_bytes())
def pin(p):
    p=Path(p).resolve();h=hashlib.sha256()
    with p.open('rb') as f:
        while data:=f.read(1<<20):h.update(data)
    return dict(path=str(p),bytes=p.stat().st_size,sha256=h.hexdigest())
def exact(row):assert pin(row['path'])==row,row['path']
def save(p,value):
    with Path(p).open('x',encoding='utf-8') as f:f.write(json.dumps(value,indent=2)+'\n')


def main():
    assert not DEST.with_suffix('.json').exists() and not DEST.with_suffix('.zip').exists()
    ready=read(W/'ready-model.json');plan=read(W/'plan-parser2.json');oldplan=read(W/'plan.json')
    expected=dict(oldplan);expected['parser']=plan['parser'];assert plan==expected
    for key in ('original_plan','old_parser','preserved_parser','new_parser','new_plan','normalization_source'):
        row=read(W/'parser-amendment2.json')[key]
        if key!='old_parser':exact(row)
    assert read(W/'parser-amendment2.json')['old_parser']['sha256']==pin(W/'parse-attempt1.py')['sha256']
    for row in (ready['inputs'],ready['compiled']['snapshot'],ready['compiled']['command'],ready['compiled']['dependencies'],
                ready['compiled']['actual_dependencies'],ready['recipe'],ready['source_freeze']):exact(row)
    frozen=read(ready['source_freeze']['path']);exact(frozen['helper']);exact(frozen['project_dependencies']);exact(frozen['instrumentation'])
    instrument=read(W/'instrumentation.json')
    assert instrument['source']==ready['compiled']['source'] and instrument['source']['sha256']==pin(instrument['before']['path'])['sha256']
    for k in ('before','snapshot','helper','patch','expected_header'):exact(instrument[k])
    baseline=read(read(W/'build-plan.json')['baseline']['path'])
    inputs=read(ready['inputs']['path']);previous=read(baseline['inputs']['path'])
    assert len(inputs)==229 and [(x,y) for x,y in zip(previous,inputs) if x!=y]==[(baseline['compiled']['object'],ready['compiled']['object'])]
    assert ready['compiled']['process']['exit']==ready['process']['exit']==0
    analysis=read(W/'analysis-summary.json');details=read(W/'summary-details.json');proof=read(W/'peer-nvtx-proof.json')
    assert proof['unchanged_nonconsumer_inputs']==8 and len(proof['schedule_headers'])==3
    assert analysis['B2_covered'] is False and details['native_consumer_processes']==4
    profiles={};source_tables={};trace_receipts={}
    for name in NAMES:
        f=W/'runs'/name;process=read(f/'process.json');quality=read(f/'quality.json');report=read(f/'report.json');roots=read(f/'roots.json')
        assert process['exit']==0 and quality['status']=='PASS_REPORT_AND_ACTUAL_ROOT_MAPPING'
        assert quality['unmapped_GPU_in_root_envelope']==0
        assert len(read(f/'retained-non-time-differences.json')['differences'])==0
        command=read(f/'command.json')['command'];assert command==next(x['profile'] for x in plan['commands'] if x['name']==name)
        d=details['arms'][name]
        db=sqlite3.connect((f/'trace.sqlite').resolve().as_uri()+'?mode=ro&immutable=1',uri=True);db.row_factory=sqlite3.Row
        device=[dict(x) for x in db.execute('SELECT * FROM TARGET_INFO_CUDA_DEVICE')]
        contexts=[dict(x) for x in db.execute('SELECT * FROM TARGET_INFO_CUDA_CONTEXT_INFO')]
        pids={x['pid'] for x in device}&{x['processId'] for x in contexts}
        assert pids=={d['actual_CUDA_consumer_pid']} and process['pid']==d['nsys_controller_pid']
        source_tables[name]=dict(cuda_devices=device,cuda_contexts=contexts)
        db.close()
        captures=Counter()
        for root in roots:captures.update(root['recording_API_counts'])
        begin=sum(v for k,v in captures.items() if 'BeginCapture' in k)
        if name.startswith('mtp'):
            metrics=analysis['mtp'][name]['metrics'];work=analysis['mtp'][name]['actual_work']
            cycles=d['decode_native_roots'] if name=='mtp-hyle' else report['target_decode_calls']
        else:
            metrics=analysis['ordinary']['common63']['arms'][name];work={k:report[k] for k in ('actual_target_rows','verified_target_rows')};cycles=63
        profiles[name]=dict(consumer_pid=d['actual_CUDA_consumer_pid'],nsys_controller_pid=process['pid'],exit=0,
            roots=len(roots),decode_roots=d['decode_native_roots'],decode_cycles=cycles,generated_outputs=report['generated_tokens'],
            root_scoped_begin_capture=begin,root_scoped_record_API_counts=dict(captures),retained_full_non_time_differences=0,
            decode_envelope_ms=metrics['envelope_ms'],decode_root_union_ms=metrics['root_wall_union_ms'],
            decode_assigned_GPU_union_ms=metrics['gpu_union_ms'],decode_physical_process_GPU_union_ms=metrics['physical_gpu_union_in_envelope_ms'],
            decode_process_GPU_idle_ms=metrics['physical_gpu_idle_in_envelope_ms'],decode_graph_launches=metrics['graph_launches'],actual_work=work)
        trace_receipts[name]={k:pin(f/k) for k in ('trace.sqlite','trace.nsys-rep')}
    assert profiles['mtp-hyle']['root_scoped_begin_capture']==2 and profiles['mtp-peer']['root_scoped_begin_capture']==5
    save(W/'sqlite-target-identities.json',source_tables)

    # Keep all four small SQLite exports; Nsight GUI reports remain in scratch.
    forbidden={'.exe','.obj','.pdb','.lib','.exp','.dll','.nsys-rep','.gguf','.bin','.safetensors'}
    allowed={'.py','.json','.h','.cc','.diff','.log','.sqlite','.rsp','.txt'}
    files={}
    for p in W.rglob('*'):
        if p.is_file() and p.suffix.lower() in allowed and p.suffix.lower() not in forbidden:
            if p.name.startswith(('archive-manifest','package-result')):continue
            files['current/'+p.relative_to(W).as_posix()]=p
    # Needed borrowed source/tooling, not their SDK/lib/model payloads.
    extra=[OLD/'analyze.py',OLD/'build.py',OLD/'prepare.py',OLD/'source/logical_trace.h',
        R/'.scratch/mtp-performance-convergence-20261025/baseline/window.py',
        PEER/'ready.json',PEER/'source/peer_multiturn.cc',PEER/'compile/command.json',PEER/'compile/process.json',
        PEER/'compile/dependencies.json',PEER/'compile/actual-dependencies.json',PEER/'link-inputs.json',PEER/'runtime.json',
        PEER.parent/'logical_trace.h',R/'.scratch/qwen-mtp-final-window-20261024/source/peer_multiturn.cc',
        R/'.scratch/qwen-mtp-final-window-20261024/compile1/peer/identity.json',
        R/'.scratch/qwen-mtp-final-window-20261024/peer-link1/link-plan.json',
        R/'.scratch/inference-uniform-prefill-20261028/ready-model.json',
        R/'.scratch/inference-uniform-prefill-20261028/inputs-model.json']
    for row in proof['schedule_headers']:
        exact(row['actual']);extra.append(Path(row['actual']['path']))
    for row in read(ready['compiled']['actual_dependencies']['path']):
        p=Path(row['path'])
        if p.is_relative_to(R/'engine'):
            exact(row);extra.append(p)
    for path in extra:
        assert path.is_file(),path
        assert path.suffix.lower() not in forbidden
        files['borrowed/'+path.relative_to(R).as_posix()]=path
    manifest=[dict(member=name,**pin(path)) for name,path in sorted(files.items())]
    sqlite_bytes=sum(v['trace.sqlite']['bytes'] for v in trace_receipts.values())
    print('ARCHIVE_INPUT_BYTES',sum(row['bytes'] for row in manifest),'SQLITE_BYTES',sqlite_bytes,'FILES',len(manifest),flush=True)
    manifest_bytes=(json.dumps(dict(files=manifest,trace_receipts=trace_receipts,Nsight_report_payloads='Retained only in scratch; all four SQLite exports are included'),indent=2)+'\n').encode()
    manifest_sha=hashlib.sha256(manifest_bytes).hexdigest()
    zip_path=DEST.with_suffix('.zip');zip_path.parent.mkdir(parents=True,exist_ok=True)
    with zipfile.ZipFile(zip_path,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as archive:
        for row in manifest:archive.write(row['path'],row['member'])
        archive.writestr('manifest.json',manifest_bytes)
    with zipfile.ZipFile(zip_path) as archive:
        assert archive.testzip() is None
        assert len(archive.infolist())==len(manifest)+1
        for row in manifest:
            data=archive.read(row['member']);assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256']
        assert hashlib.sha256(archive.read('manifest.json')).hexdigest()==manifest_sha
    common=analysis['ordinary']['common_after_first8']
    warm={name:{k:row[k] for k in ('roots','envelope_ms','root_wall_union_ms','gpu_union_ms','physical_gpu_union_in_envelope_ms',
        'physical_gpu_idle_in_envelope_ms','nonselected_or_unmapped_process_GPU_in_window','unmapped_process_GPU_in_window')}
        for name,row in common['arms'].items()}
    def ids(name):
        raw=read(W/f'runs/{name}/report.json')
        return raw['sessions'][0]['result']['generated_ids'] if 'sessions' in raw else raw['generated_ids']
    cross_ids={label:dict(equal=ids(left)==ids(right),first_difference_index=next((i for i,(x,y) in enumerate(zip(ids(left),ids(right))) if x!=y),None))
        for label,left,right in [('ordinary','r1-auto','r1-peer'),('MTP','mtp-hyle','mtp-peer')]}
    summary=dict(schema='hyle.inference.current-host-profile.v1',status='FOUR_R1_DIAGNOSTIC_TRACES_VERIFIED',
        scope='Frozen current execution-preparation Model2434c27c with NVTX-only scratch delta, successful latest229 CUDA CLI closure; retained433e native peer core via its89e7 NVTX-only consumer. Not latest upstream.',
        workload='One natural P154 turn,greedy,64 outputs,C1024,R1,prefix off. Hyle ordinary auto and MTP K1; peer ordinary and MTP K1. No artificial warmup.',
        counts=dict(Model_CXX=1,links=1,SDK_builds=0,NVCC=0,native_consumers=4,profiler_controllers=4,native_failures=0,native_reruns=0,
            offline_parser_failures=1,pre_CXX_preparation_metadata_failures=1),
        identities=dict(canonical_main=ready['compiled']['source'],NVTX_main=ready['compiled']['snapshot'],Hyle_image=ready['image'],peer_image=plan['peer'],
            profiler=plan['profiler'],closure_inputs=229,only_Model_object_replaced=True,retained_peer_native_inputs=8),
        profiles=profiles,cross_engine_output_ID_observation=cross_ids,ordinary_common_after_first8=dict(context_before_range=[common['context_before'][0],common['context_before'][-1]],arms=warm),
        parser_amendment='Initial aggregate KeyError generated_ids happened after successful nsys/SQLite. Original parser and plan retained; parser-only second plan normalizes complete sole-session result, preserving aggregate fields and raw reports. All four full non-time historical diffs0.',
        boundaries=['One profile per arm is attribution evidence, not a new TPS benchmark, significance test or across-version code gain; formal TPS unchanged.',
            'Ordinary roots overlap; root/step sums cannot be wall or throughput. Warm-window physical GPU includes the excluded predecessor; assigned GPU remains separate.',
            'Physical GPU means all traced-process KERNEL/MEMCPY/MEMSET clipped to envelope. Its idle complement is not CPU busy/self-time or device-wide idle; inclusive host buckets are nested and not additive.',
            'Hyle MTP34 combined decode episodes versus peer33 cycles/66 calls have different accepted drafts29/30 and verified target rows68/66. No one-to-one MTP roots or equal-math-work comparison.',
            'Current root-scoped MTP capture2/5 is not the historical27/7. Generic kernel names/grid/block do not uniquely identify N16 mathematical nodes.',
            'Four complete same-mode historical non-time reports match; cross-engine continuations are not asserted identical. B2,trained quality,other platforms and new memory peaks are not covered.'],
        archive=dict(**pin(zip_path),members=len(manifest)+1,sqlite_bytes=sqlite_bytes,uncompressed_input_bytes=sum(row['bytes'] for row in manifest),
            manifest_sha256=manifest_sha,CRC_and_every_member_SHA256_verified=True,Nsight_reports_retained_in_scratch=True))
    save(DEST.with_suffix('.json'),summary)
    save(W/'package-result.json',dict(JSON=pin(DEST.with_suffix('.json')),ZIP=pin(zip_path),members=len(manifest)+1,verified=True))
    print(json.dumps(read(W/'package-result.json'),indent=2))


if __name__=='__main__':main()
