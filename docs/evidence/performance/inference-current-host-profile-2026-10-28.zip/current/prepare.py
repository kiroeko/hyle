"""NVTX-only source preparation. Never starts a compiler, profiler or model."""
from pathlib import Path
import difflib
import hashlib
import importlib.util
import json
import sys
sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = W.parent.parent
OLD = R / '.scratch/inference-current-review-profile-20261027'
spec = importlib.util.spec_from_file_location('current_profile_build', W/'build.py')
b = importlib.util.module_from_spec(spec); spec.loader.exec_module(b)
t = b.t


def replace(s, a, z):
    assert s.count(a) == 1, (a[:100], s.count(a))
    return s.replace(a, z)


def main():
    assert not (W/'instrumentation.json').exists(), 'Preserve the original freeze'
    source = R/'engine/models/qwen35/main.cc'
    raw = source.read_bytes()
    assert hashlib.sha256(raw).hexdigest() == '2434c27c9c49f34bcf73269b831b610af9c396ffc8f1c5d9951f04e010742f5b'
    assert t.pin(R/'engine/inference/execution_episode.h')['sha256'] == 'd719158be06da504f1f1b9d4e54655a1493c7d771f81e67bccd23c450123f57f'
    out = W/'source/engine/models/qwen35/main.cc'
    out.parent.mkdir(parents=True, exist_ok=True)
    helper = out.with_name('logical_trace.h')
    with helper.open('xb') as f: f.write((OLD/'source/logical_trace.h').read_bytes())
    s = raw.decode('utf-8')
    assert '\r' not in s, 'Preserve canonical LF'
    s = replace(s, '#include <algorithm>', '#include "logical_trace.h"\n#include <algorithm>')
    s = replace(s, 'int qwen35::run(int argc, char **argv) {',
        'int qwen35::run(int argc, char **argv) {\n  [[maybe_unused]] logical_trace::RunScope trace_process;')
    s = replace(s, 'struct StepState final {', 'struct StepState final {\n  unsigned long long diagnostic_sequence = 0;')
    s = replace(s, '    const auto step_start = Clock::now();', '''    const auto step_start = Clock::now();
    const auto trace_context = [&](std::size_t member) {
      return predecessor ? predecessor->members[member].next->length : requests[member].session->head->length;
    };
    const auto trace_sequence = logical_trace::begin_model(static_cast<unsigned>(role), tokens,
        has_mtp(role) ? (is_mtp_prefill(role) ? tokens + draft_lag(role) : draft_lag(role) + 1) : 0,
        requests.size(), relay ? physical_slot : slot_index, relay,
        trace_context(0), trace_context(requests.size() > 1 ? 1 : 0));
    logical_trace::Range trace_prepare("hyle/prepare", trace_sequence);''')
    s = replace(s, '    auto candidate = std::make_shared<StepState>(); candidate->execution.configure(draft_bank + 2);',
        '    auto candidate = std::make_shared<StepState>(); candidate->diagnostic_sequence = trace_sequence; candidate->execution.configure(draft_bank + 2);')
    s = replace(s, '      const auto batch_end = Clock::now();\n      check(step.execution.prepare_replay',
        '      const auto batch_end = Clock::now();\n      logical_trace::Range trace_replay("hyle/prepare_replay", step.diagnostic_sequence);\n      check(step.execution.prepare_replay')
    s = replace(s, '      const auto replay_end = Clock::now();',
        '      const auto replay_end = Clock::now();\n      trace_replay.finish();')
    s = replace(s, '    step.start = Clock::now(); step.submitted = true;',
        '    step.start = Clock::now(); step.submitted = true;\n    logical_trace::Range trace_submit("hyle/submit", step.diagnostic_sequence);')
    s = replace(s, '    const auto step_start = step.step_start, start = step.start;', '''    const auto trace_sequence = step.diagnostic_sequence;
    logical_trace::Range trace_finish("hyle/wait_publish", trace_sequence);
    logical_trace::Range trace_postwait;
    const auto step_start = step.step_start, start = step.start;''')
    s = replace(s, '      check(step.execution.wait_success());', '''      {
        logical_trace::Range trace_wait("hyle/completion_wait", trace_sequence);
        check(step.execution.wait_success());
      }
      trace_postwait.start("hyle/postwait_publish", trace_sequence);''')
    s = replace(s, '    const auto finished = Clock::now();\n    for (std::size_t j = 0; j < outputs.size(); ++j) if',
        '    const auto finished = Clock::now();\n    trace_postwait.finish(); trace_finish.finish(); logical_trace::end_model(trace_sequence);\n    for (std::size_t j = 0; j < outputs.size(); ++j) if')
    with out.open('xb') as f: f.write(s.encode('utf-8'))
    before = W/'source-base/main.cc'; before.parent.mkdir(exist_ok=True)
    with before.open('xb') as f: f.write(raw)
    patch = W/'model-nvtx.diff'
    patch.write_text(''.join(difflib.unified_diff(raw.decode().splitlines(True), s.splitlines(True),
        fromfile='base/main.cc', tofile='source/main.cc')), encoding='utf-8', newline='\n')
    t.save(W/'instrumentation.json', dict(source=t.pin(source), before=t.pin(before), snapshot=t.pin(out),
        helper=t.pin(helper), original_helper=t.pin(OLD/'source/logical_trace.h'), patch=t.pin(patch),
        expected_header=t.pin(R/'engine/inference/execution_episode.h'),
        endpoints='Original step_start and finished clocks remain in place. Root ends after finished before ledger/observer. Root IDs are independent and may overlap; first eight actual decode ordinals remain in the trace.',
        original_step_sum_is_not_wall=True, maximum_roots=2047, native_algorithm_changes=0))
    b.prepare(); b.freeze(); b.validate()
    print('READY: one Model CXX/link; four R1 profiles planned; no native process started')


if __name__ == '__main__': main()
