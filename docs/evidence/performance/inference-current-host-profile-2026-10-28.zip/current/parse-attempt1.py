"""Offline reuse of W13 correlation parser with current64-output report gates."""
from pathlib import Path
from collections import Counter
import importlib.util
import json
import sqlite3
import sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent
R=W.parent.parent
OLD=R/'.scratch/inference-current-review-profile-20261027'
spec=importlib.util.spec_from_file_location('retained_successful_root_parser',OLD/'analyze.py')
a=importlib.util.module_from_spec(spec);spec.loader.exec_module(a);a.W=W
NAMES=('r1-auto','r1-peer','mtp-hyle','mtp-peer')


def read(path):return json.loads(Path(path).read_bytes())
def save(path,x):Path(path).write_bytes((json.dumps(x,indent=2)+'\n').encode())


def validate_report(name,report):
    assert report['mtp']==name.startswith('mtp')
    assert report['generated_tokens']==len(report['generated_ids'])==64
    assert report['requested_steps']==64
    if name in ('r1-auto','mtp-hyle'):assert report['sampling_draw_cursor']==0
    if name in ('r1-auto','mtp-hyle'):
        assert report['backend']=='cuda' and report['sampling']=='greedy' and report['prefix_cache'] is False
        assert report['session_count']==1 and report['active_sequences']==1 and report['turn_count']==1
        assert report['requested_output_tokens']==64 and report['logical_user_prompt_tokens']==154
        assert report['live_committed_versions']==0 and report['retired_requests']==1
        assert len(report['batches'])==report['actual_graph_calls']
        assert report['sessions'][0]['result']['generated_ids']==report['generated_ids']
        assert report['prefill_target_rows']==154 and report['generated_decode_tokens']==63
        assert len(report['sessions'][0]['ledger'])==len(report['batches'])
        if name=='r1-auto':
            assert report['decode_overlap'] and report['overlap_successor_publications']>0
        else:assert report['mtp_max_drafts']==1 and not report['decode_overlap']
    else:
        assert report['requested_context']==1024 and report['memory_snapshots_enabled'] is False
        assert report['session_count']==report['turn_count']==1
        outputs=[report['prefill_first_id']]
        for row in report['rounds']:
            assert row['pending']==outputs[-1]
            assert row['target_after']-row['target_before']==row['committed_target_rows']==len(row['emitted'])
            assert row['native_target_pos_max']==row['target_after']-1
            outputs.extend(row['emitted'])
        assert outputs==report['generated_ids']
    return dict(complete_raw_report_retained=True,actual_output_count=64,actual_prompt_rows=154,
        cross_engine_ID_equality_required=False,profile_TPS_claim=False)


a.validate_report=validate_report


def differences(x,y,path='$'):
    if type(x)!=type(y):return [dict(path=path,reference=x,actual=y)]
    if isinstance(x,dict):
        out=[]
        for k in sorted(x.keys()|y.keys()):
            if k not in x or k not in y:out.append(dict(path=path+'.'+k,reference=x.get(k),actual=y.get(k)))
            else:out+=differences(x[k],y[k],path+'.'+k)
        return out
    if isinstance(x,list):
        if len(x)!=len(y):return [dict(path=path,reference=x,actual=y)]
        return [d for i,(u,v) in enumerate(zip(x,y)) for d in differences(u,v,f'{path}[{i}]')]
    return [] if x==y else [dict(path=path,reference=x,actual=y)]


def parse(name):
    assert name in NAMES
    quality=a.parse(name,W/'runs'/name)
    references={
      'r1-auto':R/'.scratch/inference-uniform-prefill-20261028/single-ordinary-timing/02-candidate/consumer-result.json',
      'mtp-hyle':R/'.scratch/inference-uniform-prefill-20261028/single-mtp-timing/02-candidate/consumer-result.json',
      'r1-peer':R/'.scratch/inference-program-io-window-20261028/single-timing/04-peer_plain/consumer-result.json',
      'mtp-peer':R/'.scratch/inference-program-io-window-20261028/single-timing/05-peer_mtp/consumer-result.json'}
    report=read(W/f'runs/{name}/report.json');actual=a.non_time(report)
    save(W/f'runs/{name}/non-time-report.json',actual)
    diffs=differences(a.non_time(read(references[name])),actual)
    save(W/f'runs/{name}/retained-non-time-differences.json',dict(reference=str(references[name]),differences=diffs,
        note='Full non-time differences retained. Historical report is a reference, not another current sample or forced equality across Model revisions.'))
    print('MAPPED',name,quality['root_count'],'retained non-time differences',len(diffs))
    return quality


def gpu_rows(name):
    """Same actual API/phase/correlation ownership as the retained W13 parser."""
    root=read(W/f'runs/{name}/roots.json')
    con=sqlite3.connect((W/f'runs/{name}/trace.sqlite').resolve().as_uri()+'?mode=ro&immutable=1',uri=True)
    con.row_factory=sqlite3.Row
    strings=dict(con.execute('SELECT id,value FROM StringIds'))
    nvtx=[dict(x) for x in con.execute('SELECT n.*,COALESCE(n.text,s.value) label FROM NVTX_EVENTS n LEFT JOIN StringIds s ON s.id=n.textId')]
    tids={int(n['uint64Value']):n['globalTid'] for n in nvtx if (n['label'] or '').startswith(('hyle/episode ','peer/target_','peer/draft_')) and ' seq=' in n['label']}
    tables={x[0] for x in con.execute("SELECT name FROM sqlite_master WHERE type='table'")}
    owner={}
    for r in root:
        bounds=[(p['start_ns'],p['end_ns']) for p in r['phases']]
        if name.endswith('peer'):bounds.append((r['start_ns'],r['end_ns']))
        for kind in ('RUNTIME','DRIVER'):
            table='CUPTI_ACTIVITY_KIND_'+kind
            if table not in tables:continue
            for begin,end in a.union(bounds):
                for api in con.execute('SELECT * FROM '+table+' WHERE start>=? AND end<=? AND globalTid=?',(begin,end,tids[r['seq']])):
                    cid=api['correlationId']
                    if cid:
                        assert cid not in owner or owner[cid]==r['seq']
                        owner[cid]=r['seq']
    result=[];physical=[]
    process=next(iter(tids.values())) & ~((1 << 24)-1)
    assert all(tid & ~((1 << 24)-1)==process for tid in tids.values())
    for kind in ('KERNEL','MEMCPY','MEMSET'):
        for row in con.execute('SELECT * FROM CUPTI_ACTIVITY_KIND_'+kind):
            if row['globalPid']==process:physical.append(dict(row,kind=kind,seq=owner.get(row['correlationId'])))
            if row['correlationId'] in owner:
                result.append(dict(row,kind=kind,seq=owner[row['correlationId']],
                    kernel=strings.get(row['shortName']) if kind=='KERNEL' else None))
    con.close()
    counts=Counter(x['seq'] for x in result)
    assert all(counts[r['seq']]==r['gpu_activity_count'] for r in root)
    return root,result,physical


def summary():
    data={name:gpu_rows(name) for name in NAMES}
    maps={}
    for name in ('r1-auto','r1-peer'):
        roots,_,_=data[name];report=read(W/f'runs/{name}/report.json')
        selected=[r for i,r in enumerate(roots) if report['batches'][i]['generation']] if name=='r1-auto' else [r for r in roots if r['label'].startswith('peer/target_decode ')]
        maps[name]={r['meta'].get('c0',r['meta'].get('context')):r for r in selected}
        assert len(maps[name])==len(selected)
    common=sorted(set.intersection(*(set(m) for m in maps.values())))
    assert len(common)==63
    steady=common[8:]

    def totals(name,selected):
        rr,ys,physical=data[name];seq={r['seq'] for r in selected};ys=[y for y in ys if y['seq'] in seq]
        kernel=[y for y in ys if y['kind']=='KERNEL'];copies=[y for y in ys if y['kind']=='MEMCPY']
        left=min(r['start_ns'] for r in selected);right=max(r['end_ns'] for r in selected)
        gu=a.measure((y['start'],y['end']) for y in ys);ru=a.measure((r['start_ns'],r['end_ns']) for r in selected)
        window=[y for y in physical if y['start']<right and left<y['end']]
        physical_union=a.measure((max(y['start'],left),min(y['end'],right)) for y in window)
        unknown=[y for y in window if y['seq'] is None]
        nonselected=[y for y in window if y['seq'] not in seq]
        def activity_facts(rows):
            return dict(count=len(rows),bytes=sum(y.get('bytes',0) for y in rows),by_kind=dict(Counter(y['kind'] for y in rows)),
                clipped_union_ms=a.measure((max(y['start'],left),min(y['end'],right)) for y in rows)/1e6)
        return dict(roots=len(selected),root_wall_union_ms=ru/1e6,root_wall_sum_ms_diagnostic_only=sum(r['wall_ns'] for r in selected)/1e6,
            envelope_ms=(right-left)/1e6,gpu_union_ms=gu/1e6,kernel_union_ms=a.measure((y['start'],y['end']) for y in kernel)/1e6,
            envelope_minus_selected_assigned_gpu_union_ms_not_cpu=(right-left-gu)/1e6,root_gap_ms=(right-left-ru)/1e6,kernels=len(kernel),
            physical_gpu_union_in_envelope_ms=physical_union/1e6,physical_gpu_idle_in_envelope_ms=(right-left-physical_union)/1e6,
            unmapped_process_GPU_in_window=activity_facts(unknown),nonselected_or_unmapped_process_GPU_in_window=activity_facts(nonselected),
            physical_scope='All traced-process KERNEL/MEMCPY/MEMSET, clipped to selected-root envelope. Counts/bytes describe full overlapping events; durations are clipped. Other processes are not observed.',
            graph_launches=sum(r['native_graph_launches'] for r in selected),
            native_kernel_families=[dict(name=k,count=sum(y['kernel']==k for y in kernel),sum_ms=sum(y['end']-y['start'] for y in kernel if y['kernel']==k)/1e6) for k in sorted({y['kernel'] for y in kernel},key=lambda k:-sum(y['end']-y['start'] for y in kernel if y['kernel']==k))],
            record_API_counts=dict(Counter({k:sum(r['recording_API_counts'].get(k,0) for r in selected) for k in {k for r in selected for k in r['recording_API_counts']}})),
            copies={str(k):dict(count=sum(y['copyKind']==k for y in copies),bytes=sum(y['bytes'] for y in copies if y['copyKind']==k),
                sum_ms=sum(y['end']-y['start'] for y in copies if y['copyKind']==k)/1e6) for k in sorted({y['copyKind'] for y in copies})},
            phase_wall_union_ms_inclusive_do_not_add={label:a.measure((p['start_ns'],p['end_ns']) for r in selected for p in r['phases'] if p['label']==label)/1e6 for label in sorted({p['label'] for r in selected for p in r['phases']})})
    ordinary={scope:dict(context_before=contexts,arms={n:totals(n,[maps[n][c] for c in contexts]) for n in maps})
              for scope,contexts in [('common63',common),('common_after_first8',steady)]}
    mtp={}
    for name in ('mtp-hyle','mtp-peer'):
        roots,_,_=data[name];report=read(W/f'runs/{name}/report.json')
        selected=[r for i,r in enumerate(roots) if report['batches'][i]['generation']] if name=='mtp-hyle' else [r for r in roots if '_decode ' in r['label']]
        mtp[name]=dict(metrics=totals(name,selected),actual_work={k:report[k] for k in ('generated_tokens','generated_decode_tokens','actual_target_rows','actual_draft_rows','verified_target_rows','agreements','accepted_drafts','consumed_drafts','target_decode_calls','draft_decode_calls','proposals') if k in report})
    producer_phases={name:{k:read(W/f'runs/{name}/report.json')[k] for k in ('prefill_seconds','decode_seconds','session_seconds')} for name in NAMES}
    save(W/'analysis-summary.json',dict(status='FOUR_R1_ACTUAL_TRACES_OFFLINE_ANALYZED',ordinary=ordinary,mtp=mtp,producer_phase_seconds_observed_not_benchmark=producer_phases,B2_covered=False,
        limits=['One trace per arm; no new TPS/causal speed or trained-quality claim.',
          'A/B roots overlap: root union/envelope are wall; step/root sums are diagnostic only.',
          'Assigned GPU uses actual correlation ownership. All traced-process activities are separately clipped to the window, including excluded predecessors or unassigned workers. Their complement is process-activity idle, not CPU self-time or device-wide idle.',
          'Inclusive prepare/replay/wait/postwait buckets cannot be added. Envelope residual includes helper/source/ledger/observer gaps and profiling overhead.',
          'MTP Hyle combined native graph versus peer separate target/draft calls: no one-to-one root comparison or invented Hyle role split.']))
    print('FOUR_R1_OFFLINE_SUMMARY_READY')


if __name__=='__main__':
    if sys.argv[1]=='summary':summary()
    else:parse(sys.argv[1])
