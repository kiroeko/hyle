"""Parser-only plan amendment; never repeats an existing native directory."""
from pathlib import Path
import importlib.util
import sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('unchanged_profile_runner',W/'profile.py')
p=importlib.util.module_from_spec(spec);spec.loader.exec_module(p)
read=p.t.read


def amended_read(path):
    if Path(path).resolve()==(W/'plan.json').resolve():return read(W/'plan-parser2.json')
    return read(path)


if __name__=='__main__':
    receipt=read(W/'parser-amendment2.json')
    for key in ('original_plan','preserved_parser','new_parser','new_plan'):p.t.exact(receipt[key])
    assert read(W/'plan.json')['commands']==read(W/'plan-parser2.json')['commands']
    p.t.read=amended_read
    if sys.argv[1]=='parse':
        name=sys.argv[2];process=read(W/f'runs/{name}/process.json')
        assert process['exit']==0
        parser=p.module('amended_offline_profile_parser',W/'parse.py');parser.parse(name)
    elif sys.argv[1]=='run':
        assert sys.argv[2]!='r1-auto','The first successful native process must never be repeated'
        p.run(sys.argv[2])
    else:raise ValueError(sys.argv[1])
