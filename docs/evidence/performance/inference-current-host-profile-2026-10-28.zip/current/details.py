"""Offline geometry/PID supplement. Does not mutate the frozen capture parser."""
from pathlib import Path
from collections import defaultdict
import importlib.util
import json
import sqlite3
import statistics
import sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('frozen_current_capture_parser',W/'parse.py')
p=importlib.util.module_from_spec(spec);spec.loader.exec_module(p)


def details(name):
    roots,assigned,_=p.gpu_rows(name)
    report=p.read(W/f'runs/{name}/report.json')
    if name in ('r1-auto','mtp-hyle'):
        seq={r['seq'] for i,r in enumerate(roots) if report['batches'][i]['generation']}
    else:seq={r['seq'] for r in roots if '_decode ' in r['label']}
    selected=[y for y in assigned if y['seq'] in seq]
    groups=defaultdict(list)
    for y in selected:
        if y['kind']!='KERNEL':continue
        key=(y['kernel'],tuple(y[k] for k in ('gridX','gridY','gridZ')),tuple(y[k] for k in ('blockX','blockY','blockZ')))
        groups[key].append((y['end']-y['start'])/1000)
    top=[dict(kernel_name=k[0],grid=list(k[1]),block=list(k[2]),count=len(xs),sum_us=sum(xs),median_us=statistics.median(xs))
         for k,xs in sorted(groups.items(),key=lambda item:-sum(item[1]))[:12]]
    con=sqlite3.connect((W/f'runs/{name}/trace.sqlite').resolve().as_uri()+'?mode=ro&immutable=1',uri=True)
    tables={x[0] for x in con.execute("SELECT name FROM sqlite_master WHERE type='table'")}
    assert {'TARGET_INFO_CUDA_DEVICE','TARGET_INFO_CUDA_CONTEXT_INFO'}<=tables
    cuda_pids={int(x[0]) for x in con.execute('SELECT DISTINCT pid FROM TARGET_INFO_CUDA_DEVICE')}
    context_pids={int(x[0]) for x in con.execute('SELECT DISTINCT processId FROM TARGET_INFO_CUDA_CONTEXT_INFO')}
    streams={int(x[0]) for x in con.execute('SELECT DISTINCT globalPid FROM ProcessStreams')}
    pid_candidates=cuda_pids&context_pids
    assert len(pid_candidates)==1,('Target process identity needs offline resolution',cuda_pids,context_pids)
    target_pid=next(iter(pid_candidates))
    # Encoded globalPid includes a VM identifier above the original24-bit PID.
    assert any(((global_pid>>24)&((1<<24)-1))==target_pid for global_pid in streams)
    process=p.read(W/f'runs/{name}/process.json')
    con.close()
    return dict(nsys_controller_pid=process['pid'],nsys_controller_exit=process['exit'],
        actual_CUDA_consumer_pid=target_pid,consumer_pid_evidence='TARGET_INFO_CUDA_DEVICE.pid intersect CUDA_CONTEXT_INFO.processId, cross-checked against ProcessStreams encoded globalPid',
        decode_native_roots=len(seq),top12_decode_kernel_name_grid_block=top,
        limitation='Kernel duration sums and medians characterize actual traced native families; sums are not GPU busy union. Generic kernel names/geometry alone do not uniquely identify N16 projections or model nodes.')


def main():
    p.summary()
    rows={name:details(name) for name in p.NAMES}
    p.save(W/'summary-details.json',dict(status='FOUR_R1_OFFLINE_NATIVE_IDENTITIES_AND_KERNEL_GEOMETRIES',arms=rows,
        native_consumer_processes=4,profiler_controllers=4,native_reruns=0,B2_covered=False))
    for name,row in rows.items():print(name,'nsys',row['nsys_controller_pid'],'consumer',row['actual_CUDA_consumer_pid'],'decode roots',row['decode_native_roots'])


if __name__=='__main__':main()
