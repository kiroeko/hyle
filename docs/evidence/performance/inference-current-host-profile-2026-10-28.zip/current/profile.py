"""Four explicit R1 profiles; no automatic retries, no benchmark or B2 arm."""
from pathlib import Path
import importlib.util
import json
import os
import sys
sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = W.parent.parent
OLD = R/'.scratch/inference-current-review-profile-20261027'
PEER = R/'.scratch/inference-cuda-current-attribution-20261026/peer'
WINDOW = R/'.scratch/inference-program-io-window-20261028'
NSYS = Path('C:/Program Files/NVIDIA Corporation/Nsight Systems 2026.1.3/target-windows-x64/nsys.exe')
NAMES = ('r1-auto', 'r1-peer', 'mtp-hyle', 'mtp-peer')


def module(name, path):
    spec=importlib.util.spec_from_file_location(name,path)
    value=importlib.util.module_from_spec(spec); spec.loader.exec_module(value); return value


b=module('host_profile_build', W/'build.py'); t=b.t
driver=module('successful_profile_driver', OLD/'build.py')


def rows():
    source=t.read(WINDOW/'single-timing-plan.json')['commands']
    mapping={'r1-auto':'hyle_auto', 'r1-peer':'peer_plain', 'mtp-hyle':'hyle_mtp', 'mtp-peer':'peer_mtp'}
    peer=t.read(PEER/'ready.json')['image']['path']
    result=[]
    for name in NAMES:
        original=next(x for x in source if x['arm']==mapping[name])
        command=list(original['command']); command[0]=str(W/'bin/hyle-current.exe') if 'hyle' in mapping[name] else peer
        if '--output' in command: command[command.index('--output')+1]=str(W/f'runs/{name}/report.json')
        assert command[command.index('--steps')+1]=='64' and command[command.index('--capacity')+1]=='1024'
        assert ('--mtp-max-drafts' not in command or command[command.index('--mtp-max-drafts')+1]=='1')
        assert '--trace' not in command
        profile=[str(NSYS),'profile','--trace=cuda,cublas,nvtx','--cuda-graph-trace=node',
            '--sample=none','--cpuctxsw=none','--discard-environment=true',
            '--nvtx-domain-include=HyleLogicalCalls','--duration=60','--kill=true','--wait=all',
            '--stats=false','--export=sqlite','--output='+str(W/f'runs/{name}/trace'),*command]
        result.append(dict(name=name,consumer=command,profile=profile,timeout_seconds=120,
            runtime=str(W/'runtime.json') if name in ('r1-auto','mtp-hyle') else str(PEER/'runtime.json'),
            original_window_command=original['command'], expected=dict(prompt_rows=154,output_quota=64,capacity=1024,
                active_sequences=1,greedy=True,prefix_cache=False,mtp=name.startswith('mtp'))))
    return result


def prepare():
    b.validate();ready=t.read(W/'ready-model.json');peer=t.read(PEER/'ready.json')
    for row in (ready['image'],ready['inputs'],peer['image'],peer['source'],peer['link_inputs'],peer['runtime']): t.exact(row)
    old=t.read(OLD/'plan.json')['profiler'];t.exact(old)
    assert old['path']==str(NSYS)
    commands=rows()
    for row in commands: assert Path(row['runtime']).is_file()
    t.save(W/'plan.json',dict(script=t.pin(__file__),parser=t.pin(W/'parse.py'),build=t.pin(W/'ready-model.json'),
        Model=ready['image'],peer=peer['image'],peer_ready=t.pin(PEER/'ready.json'),profiler=old,
        peer_proof=t.pin(W/'peer-nvtx-proof.json'),nvtx_headers=t.pin(W/'nvtx-precompile-pins.json'),
        old_parser=t.pin(OLD/'analyze.py'),old_driver=t.pin(OLD/'build.py'),
        commands=commands,native_processes=4,retries=0,B2_covered=False,
        scope='Current frozen Model NVTX-only scratch derivative versus retained433e native core with its existing89e7 NVTX-only consumer; one natural P154 turn,64 outputs,C1024. No new TPS/quality or across-version speed claim.'))
    print('FOUR_PROFILE_PLAN_READY; no profiler/model started')


def run(name):
    assert name in NAMES
    b.validate();plan=t.read(W/'plan.json')
    for key in ('script','parser','build','peer_ready','peer_proof','nvtx_headers','old_parser','old_driver'):t.exact(plan[key])
    for row in t.read(W/'nvtx-precompile-pins.json'):t.exact(row)
    for other in NAMES[:NAMES.index(name)]:
        assert t.read(W/f'runs/{other}/process.json')['exit']==0
        assert t.read(W/f'runs/{other}/quality.json')['status']=='PASS_REPORT_AND_ACTUAL_ROOT_MAPPING'
    row=next(x for x in plan['commands'] if x['name']==name)
    folder=W/'runs'/name
    assert not folder.exists(),'Preserve every attempt; parse existing output offline instead of rerunning'
    image=plan['Model'] if name in ('r1-auto','mtp-hyle') else plan['peer']
    assert row['consumer'][0]==image['path'] and Path(image['path']).stat().st_size==image['bytes']
    assert NSYS.stat().st_size==plan['profiler']['bytes']
    runtime=t.read(row['runtime']);env=os.environ.copy()
    env['PATH']=str(Path(image['path']).parent)+';'+runtime['PATH']
    env.update(runtime.get('configured_flags',{}));env['HF_HUB_OFFLINE']='1';env['TRANSFORMERS_OFFLINE']='1'
    process=driver.execute(row['profile'],folder,env,row['timeout_seconds'])
    assert process['exit']==0,process
    parse=module('current_offline_profile',W/'parse.py');parse.parse(name)


if __name__=='__main__':
    if sys.argv[1]=='template':t.save(W/'command-template.json',rows())
    elif sys.argv[1]=='prepare':prepare()
    elif sys.argv[1]=='run':run(sys.argv[2])
    else:raise ValueError(sys.argv[1])
