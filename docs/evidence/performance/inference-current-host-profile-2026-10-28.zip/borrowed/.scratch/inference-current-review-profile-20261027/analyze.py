"""Offline W13 parsing. Root overlap never assigns a GPU operation twice."""
from pathlib import Path
from collections import Counter, defaultdict
import bisect
import json
import re
import sqlite3
import sys
sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent


def read(p): return json.loads(p.read_bytes())
def save(p, x): p.write_bytes((json.dumps(x, indent=2)+'\n').encode())


def union(xs):
    out = []
    for a, b in sorted(xs):
        if b <= a: continue
        if out and a <= out[-1][1]: out[-1][1] = max(out[-1][1], b)
        else: out.append([a, b])
    return out


def measure(xs): return sum(b-a for a, b in union(xs))


def non_time(x):
    if isinstance(x, list): return [non_time(v) for v in x]
    if isinstance(x, dict):
        return {k: non_time(v) for k, v in x.items() if not any(s in k for s in
                ('seconds', 'per_second', 'clock_unix', 'unix_ns', 'unix_ms'))}
    return x


def validate_report(name, report):
    hyle = name not in ('r1-peer', 'b2-peer', 'mtp-peer')
    if hyle:
        assert report['live_committed_versions'] == 0
        assert report['requested_output_tokens'] == (194 if name.startswith('b2') else 97)
        assert report['generated_tokens'] <= report['requested_output_tokens']
        assert report['session_count'] == (2 if name.startswith('b2') else 1)
        assert report['sampling'] == 'greedy' and report['prefix_cache'] is False
        assert report['mtp'] == name.startswith('mtp')
        assert len(report['batches']) == report['actual_graph_calls']
        if name.endswith('auto'):
            assert report['decode_overlap'] and report['decode_overlap_available']
            assert report['overlap_successor_publications'] > 0
            assert report['overlap_successor_refusals'] == report['overlap_successor_discards'] == 0
        elif not name.startswith('mtp'):
            assert not report['decode_overlap']
        for session in report['sessions']:
            result = session['result']
            ids = result['generated_ids']
            assert len(ids) <= 97 and ids
            assert len(session['ledger']) > 0
        if name in ('r1-off', 'r1-auto'):
            reference = W.parent/'inference-identical-capture-inputs-20261027/screen'/(
                '02-candidate-off' if name.endswith('off') else '03-candidate-auto')/'report.json'
            assert non_time(report) == non_time(read(reference)), 'Full same-mode non-time report changed'
            return dict(full_same_mode_non_time_equal=True, reference=str(reference))
        if name == 'b2-auto':
            # Real serial/relay comparison keeps all semantic session facts;
            # exact cache/capture/relay diagnostics remain in both raw reports.
            old = read(W/'runs/b2-off/report.json')
            # D1 and D2 have different explicit pool formulae; ordinary host
            # ahead and device Source relay expose different diagnostic counts.
            # Keep exactly these six top-level mode facts visible, and compare
            # every remaining non-time result field (including all IDs) exactly.
            mode_fields = ('cache_live_requested_bytes', 'cache_peak_requested_bytes',
                'cache_requested_byte_limit', 'cache_shared_backing_bytes',
                'cpu_ahead_hits', 'cpu_ahead_prepared')
            differences = []
            for j,(new_session,old_session) in enumerate(zip(report['sessions'],old['sessions'])):
                new,previous=non_time(new_session['result']),non_time(old_session['result'])
                for k in mode_fields:
                    if new[k]!=previous[k]: differences.append(dict(member=j,field=k,off=previous[k],auto=new[k]))
                    new.pop(k);previous.pop(k)
                assert new==previous, 'Unexplained complete per-session semantic difference'
            for k in ('generated_tokens', 'actual_graph_calls', 'actual_target_rows', 'committed_target_rows', 'graph_participations'):
                assert report[k] == old[k], k
            return dict(complete_per_session_semantics_equal_to_off=True,
                        explicit_mode_fact_differences=differences,
                        compared_totals=['generated_tokens', 'actual_graph_calls', 'actual_target_rows', 'committed_target_rows', 'graph_participations'])
        return dict(self_invariants=True, retained_complete_report=True)
    if name == 'b2-peer':
        assert report['natural_greedy'] and report['active_sequences'] == 2
        assert len(report['sessions']) == 2
        assert report['actual_graph_calls'] == len(report['episodes'])
        for s in report['sessions']:
            ids, inputs = s['generated_ids'], s['actual_input_ids']
            assert ids and len(ids) <= 97
            assert inputs[154:] == ids[:-1]
            assert len(inputs) == s['visible_tokens'] == 154 + len(ids) - 1
        assert report['actual_graph_requests'] == report['generated_tokens']
        return dict(natural_own_greedy_inputs=True, no_cross_engine_ID_equality_claim=True)
    assert report['requested_steps'] == 97 and report['requested_context'] == 256
    assert report['mtp'] == name.startswith('mtp')
    assert report['generated_ids'] and len(report['generated_ids']) == report['generated_tokens'] <= 97
    assert report['memory_snapshots_enabled'] is False
    rounds = report['rounds']
    outputs = [report['prefill_first_id']]
    for r in rounds:
        assert r['pending'] == outputs[-1]
        assert r['target_after'] - r['target_before'] == r['committed_target_rows']
        assert len(r['emitted']) == r['committed_target_rows']
        assert r['native_target_pos_max'] == r['target_after'] - 1
        outputs += r['emitted']
    assert outputs == report['generated_ids']
    return dict(complete_own_greedy_ledger=True, no_cross_engine_ID_equality_claim=True)


def parse(name, folder=None):
    f = folder or W/'runs'/name
    con = sqlite3.connect((f/'trace.sqlite').resolve().as_uri()+'?mode=ro&immutable=1', uri=True)
    con.row_factory = sqlite3.Row
    tables = {r[0] for r in con.execute("SELECT name FROM sqlite_master WHERE type='table'")}
    assert {'NVTX_EVENTS', 'CUPTI_ACTIVITY_KIND_KERNEL', 'CUPTI_ACTIVITY_KIND_RUNTIME', 'ProcessStreams'} <= tables
    streams = defaultdict(list)
    for row in con.execute('SELECT f.value filename,c.value body FROM ProcessStreams p JOIN StringIds f ON f.id=p.filenameId JOIN StringIds c ON c.id=p.contentId'):
        if 'stdout_' in row['filename']: streams['stdout'].append(row['body'])
        elif 'stderr_' in row['filename']: streams['stderr'].append(row['body'])
    for kind, text in streams.items(): (f/('native-'+kind+'.log')).write_text(''.join(text), encoding='utf-8')
    hyle = name not in ('r1-peer', 'b2-peer', 'mtp-peer')
    if hyle:
        report = json.loads((f/'native-stdout.log').read_text(encoding='utf-8-sig'))
        save(f/'report.json', report)
    else: report = read(f/'report.json')
    gates = validate_report(name, report)
    nvtx = [dict(r) for r in con.execute('SELECT n.*,COALESCE(n.text,s.value) label FROM NVTX_EVENTS n LEFT JOIN StringIds s ON s.id=n.textId ORDER BY n.start') if r['label']]
    prefix = 'hyle/episode ' if hyle else 'peer/b2_episode ' if name == 'b2-peer' else 'peer/'
    if hyle or name == 'b2-peer': roots = [r for r in nvtx if r['label'].startswith(prefix)]
    else: roots = [r for r in nvtx if re.match(r'peer/(target|draft)_(prefill|decode) seq=', r['label'])]
    assert roots and all(r['end'] is not None for r in roots)
    assert len({r['uint64Value'] for r in roots}) == len(roots)
    process = roots[0]['globalTid'] & ~((1 << 24)-1)
    assert all(r['globalTid'] & ~((1 << 24)-1) == process for r in roots)
    api = []
    for table in ('RUNTIME', 'DRIVER'):
        if 'CUPTI_ACTIVITY_KIND_'+table in tables:
            api += [dict(r) for r in con.execute('SELECT a.*,s.value api FROM CUPTI_ACTIVITY_KIND_'+table+' a JOIN StringIds s ON s.id=a.nameId ORDER BY a.start')]
    gpu = []
    for kind in ('KERNEL', 'MEMCPY', 'MEMSET'):
        for r in con.execute('SELECT * FROM CUPTI_ACTIVITY_KIND_'+kind+' ORDER BY start'):
            if r['globalPid'] == process: gpu.append(dict(r, kind=kind, index=len(gpu)))
    assert gpu
    con.close()
    api.sort(key=lambda r:r['start']); starts=[r['start'] for r in api]
    owner = {}; records = []
    for i, root in enumerate(roots):
        seq = root['uint64Value']
        meta = {k:int(v) for k,v in re.findall(r'(\w+)=(\d+)', root['label'])}
        assert meta['seq'] == seq
        phases = [n for n in nvtx if n['uint64Value'] == seq and n is not root and
                  n['label'].startswith('hyle/' if hyle else 'peer/') and ' seq=' not in n['label']]
        assert all(n['end'] is not None for n in phases)
        # Peer prepare ranges begin just before its existing native-call root.
        # Label/payload, not containment, makes that relation explicit.
        bounds = [(root['start'], root['end'])] if not hyle else []
        bounds += [(n['start'], n['end']) for n in phases]
        calls = []
        for a,b in union(bounds):
            j=bisect.bisect_left(starts,a)
            while j<len(api) and api[j]['start']<b:
                row=api[j]
                if row['globalTid']==root['globalTid'] and row['end']<=b: calls.append(row)
                j+=1
        for row in calls:
            cid=row['correlationId']
            if cid:
                assert cid not in owner or owner[cid]==seq, ('Ambiguous native API correlation',cid,owner.get(cid),seq)
                owner[cid]=seq
        if hyle:
            assert i < len(report['batches'])
            batch=report['batches'][i]
            assert (meta['R'],meta['target_T'],meta['role']) == (batch['requests'],batch['tokens'],batch['role'])
        elif name=='b2-peer':
            batch=report['episodes'][i]
            assert (meta['R'],meta['T'])==(batch['requests'],batch['T'])
        records.append(dict(label=root['label'], seq=seq, meta=meta, start_ns=root['start'], end_ns=root['end'],
            wall_ns=root['end']-root['start'], phases=[dict(label=n['label'],start_ns=n['start'],end_ns=n['end'],wall_ns=n['end']-n['start']) for n in phases],
            native_graph_launches=sum('GraphLaunch' in r['api'] for r in calls),
            recording_API_counts=dict(Counter(r['api'] for r in calls if any(k in r['api'] for k in ('BeginCapture','EndCapture','GraphInstantiate','GraphExecUpdate'))))))
    if hyle: assert len(roots)==report['actual_graph_calls']
    elif name=='b2-peer': assert len(roots)==report['actual_graph_calls']
    else:
        assert sum('/target_' in r['label'] for r in roots)==report['target_compute_calls']
        assert sum('/draft_' in r['label'] for r in roots)==report['draft_compute_calls']
        assert sum(int(re.search(r' T=(\d+)',r['label'])[1]) for r in roots if '/target_' in r['label'])==report['actual_target_rows']
        assert sum(int(re.search(r' T=(\d+)',r['label'])[1]) for r in roots if '/draft_' in r['label'])==report['actual_draft_rows']
    assigned=defaultdict(list)
    for row in gpu:
        if row['correlationId'] in owner: assigned[owner[row['correlationId']]].append(row)
    left=min(r['start_ns'] for r in records); right=max(r['end_ns'] for r in records)
    unmapped=[r for r in gpu if r['start']<right and left<r['end'] and r['correlationId'] not in owner]
    save(f/'unmapped-gpu.json',unmapped)
    for r in records:
        ys=assigned[r['seq']]
        r['gpu_activity_count']=len(ys)
        r['gpu_union_ns']=measure((y['start'],y['end']) for y in ys)
        ks=[y for y in ys if y['kind']=='KERNEL']; cp=[y for y in ys if y['kind']=='MEMCPY']
        r['kernel_count']=len(ks);r['kernel_union_ns']=measure((y['start'],y['end']) for y in ks)
        r['memcpy']={str(k):dict(count=sum(y['copyKind']==k for y in cp),bytes=sum(y['bytes'] for y in cp if y['copyKind']==k),sum_ns=sum(y['end']-y['start'] for y in cp if y['copyKind']==k)) for k in sorted({y['copyKind'] for y in cp})}
    save(f/'roots.json',records)
    assert not unmapped, 'Native root attribution unresolved; offline parser correction only, never rerun this process'
    summary=dict(status='PASS_REPORT_AND_ACTUAL_ROOT_MAPPING',name=name,root_count=len(records),
        report_gates=gates,unique_native_correlation_owner=True,unmapped_GPU_in_root_envelope=len(unmapped),
        root_wall_sum_ns=sum(r['wall_ns'] for r in records),root_wall_union_ns=measure((r['start_ns'],r['end_ns']) for r in records),
        root_envelope_ns=right-left,
        root_between_or_outer_envelope_residual_ns=right-left-measure((r['start_ns'],r['end_ns']) for r in records),
        warnings=['Root sum is not user wall; A/B may overlap. Root endpoint is original Model finished clock before outer ledger/report/delivery.',
                  'Native GPU activity is assigned by actual API correlation from seq-labelled phases, not by overlapping root wall containment.',
                  'GPU union/call wall/CPU self-time are distinct. No profile TPS or cross-engine equal continuation-ID assertion.'])
    save(f/'quality.json',summary)
    return summary


if __name__=='__main__': print(json.dumps(parse(sys.argv[1]),indent=2))
