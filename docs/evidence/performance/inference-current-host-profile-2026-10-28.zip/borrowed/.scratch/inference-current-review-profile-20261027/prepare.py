"""Freeze W13 diagnostic sources/commands only. Never compiles or starts a model."""
from pathlib import Path
import difflib
import hashlib
import json
import os
import subprocess

W = Path(__file__).resolve().parent
R = W.parent.parent
V = R/'.scratch/inference-generic-output-source-20261027'
M = R/'.scratch/inference-generation-batch-continuation-20261027'
B = R/'.scratch/inference-b2-current-attribution-20261026'
P = R/'.scratch/inference-cuda-current-attribution-20261026'
NSYS = Path('C:/Program Files/NVIDIA Corporation/Nsight Systems 2026.1.3/target-windows-x64/nsys.exe')


def read(p):
    return json.loads(Path(p).read_bytes())


def save(p, x):
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_bytes((json.dumps(x, indent=2)+'\n').encode())


def pin(p):
    p = Path(p).resolve()
    b = p.read_bytes()
    return dict(path=str(p), bytes=len(b), sha256=hashlib.sha256(b).hexdigest())


def exact(x):
    assert pin(x['path']) == x, x['path']


def replace(s, old, new):
    assert s.count(old) == 1, (old[:100], s.count(old))
    return s.replace(old, new)


def snapshot(relative, raw):
    p = W/'source'/relative
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_bytes(raw)
    return pin(p)


def freeze_headers():
    # The validated Model precedes active RequestLoop/range edits. Read its
    # actual Includes, recover exact committed headers at2fe, and put those
    # small project files ahead of every canonical include directory.
    rows = read(M/'compile/model1/actual-dependencies.json')
    output = []
    for original in rows[1:]:
        p = Path(original['path'])
        local = p.is_relative_to(R) and not p.is_relative_to(R/'.scratch')
        if local:
            rel = p.relative_to(R).as_posix()
            data = subprocess.run(['git', 'show', '2fe2916cf:'+rel], cwd=R,
                                  check=True, capture_output=True).stdout
            actual = snapshot(rel, data)
            same = (actual['bytes'], actual['sha256']) == (original['bytes'], original['sha256'])
            # The one already-reviewed comment-only OutputSource update is
            # explicitly preserved instead of claiming unchanged bytes.
            if not same:
                assert rel == 'include/hyle/graph/detail/output_source.h', rel
                assert actual['sha256'] == 'cd6c66d50ad62ac78f51b31b64581f1ed7dbc9c3f62de483cfc62a0c9ed01799'
            output.append(dict(original=original, snapshot=actual, same_bytes=same,
                               exception=None if same else 'W9 retained comment-only token-equivalence receipt'))
        else:
            exact(original)
            output.append(dict(original=original, snapshot=original, same_bytes=True))
    # Existing successful NVTX consumer's actual additional headers.
    nvtx = [x for x in read(P/'peer/compile/actual-dependencies.json')
            if 'nvtx3' in x['path'].lower()]
    assert nvtx
    for row in nvtx:
        exact(row)
    save(W/'model-precompile-dependencies.json', dict(original=pin(M/'compile/model1/actual-dependencies.json'),
        headers=output, nvtx=nvtx, source_git='2fe2916cf',
        comment_exception=pin(V/'header-reuse-exception.json') if (V/'header-reuse-exception.json').exists()
                          else pin(R/'.scratch/inference-source-bind-attribution-20261027/header-reuse-exception.json')))
    return output, nvtx


def make_helper():
    raw = (B/'logical_trace.h').read_text(encoding='utf-8-sig').replace('\r\n', '\n')
    raw = replace(raw, 'inline Range episode;', '''// Independent Model roots may overlap; this is NVTX metadata only.
inline Range roots[2048];
inline Range episode;
inline unsigned long long begun_roots = 0, ended_roots = 0;
inline unsigned long long begin_model(unsigned role, std::size_t target_rows,
    std::size_t draft_rows, std::size_t width, std::size_t slot, bool imported,
    std::size_t context0, std::size_t context1) noexcept {
  const auto seq = ++sequence;
  if (seq >= 2048) { std::fputs("LOGICAL_NVTX_OVERFLOW\\n", stderr); std::abort(); }
  char text[512]{};
  std::snprintf(text, sizeof(text),
      "hyle/episode seq=%llu role=%u target_T=%zu draft_T=%zu R=%zu slot=%zu imported=%u c0=%zu c1=%zu",
      seq, role, target_rows, draft_rows, width, slot, unsigned(imported), context0, context1);
  roots[seq].start(text, seq); ++begun_roots; return seq;
}
inline void end_model(unsigned long long seq) noexcept {
  roots[seq].finish(); ++ended_roots;
}''')
    raw = replace(raw, '#include <cstdint>', '#include <cstdint>\n#include <cstdlib>')
    raw = replace(raw, '  ~RunScope() { episode.finish(); dump(); }', '''  ~RunScope() {
    episode.finish();
    std::fprintf(stderr, "MODEL_NVTX begun=%llu ended=%llu\\n", begun_roots, ended_roots);
    for (auto &root : roots) root.finish();
    dump();
  }''')
    return snapshot('logical_trace.h', raw.encode())


def make_model():
    base = M/'source/model1/main.cc'
    assert pin(base)['sha256'] == 'e0067b13c7d60ba5bcdb5ca236898bbf12b61b4d96b4411d8b8cd23b40177cb2'
    raw = base.read_bytes()
    s = raw.decode().replace('\r\n', '\n')
    s = replace(s, '#include <algorithm>', '#include "logical_trace.h"\n#include <algorithm>')
    s = replace(s, 'int qwen35::run(int argc, char **argv) {',
        'int qwen35::run(int argc, char **argv) {\n  [[maybe_unused]] logical_trace::RunScope trace_process;')
    s = replace(s, 'struct StepState final {', 'struct StepState final {\n  unsigned long long diagnostic_sequence = 0;')
    s = replace(s, '    const auto step_start = Clock::now();', '''    const auto step_start = Clock::now();
    const auto trace_context = [&](std::size_t member) {
      return predecessor ? predecessor->members[member].next->length : requests[member].session->head->length;
    };
    const auto trace_sequence = logical_trace::begin_model(static_cast<unsigned>(role), tokens,
        has_mtp(role) ? (is_mtp_prefill(role) ? tokens + draft_lag(role) : draft_lag(role) + 1) : 0,
        requests.size(), physical_slot, relay, trace_context(0), trace_context(requests.size() > 1 ? 1 : 0));
    logical_trace::Range trace_prepare("hyle/prepare", trace_sequence);''')
    s = replace(s, '    auto candidate = std::make_shared<StepState>(); candidate->configure(draft_bank + 2);',
        '    auto candidate = std::make_shared<StepState>(); candidate->diagnostic_sequence = trace_sequence; candidate->configure(draft_bank + 2);')
    s = replace(s, '      const auto batch_end = Clock::now();\n      if (relay)',
        '      const auto batch_end = Clock::now();\n      logical_trace::Range trace_replay("hyle/prepare_replay", step.diagnostic_sequence);\n      if (relay)')
    s = replace(s, '      const auto replay_end = Clock::now();',
        '      const auto replay_end = Clock::now();\n      trace_replay.finish();')
    s = replace(s, '    step.start = Clock::now(); step.submitted = true;',
        '    step.start = Clock::now(); step.submitted = true;\n    logical_trace::Range trace_submit("hyle/submit", step.diagnostic_sequence);')
    s = replace(s, '    const auto step_start = step.step_start, start = step.start;', '''    const auto trace_sequence = step.diagnostic_sequence;
    logical_trace::Range trace_finish("hyle/wait_publish", trace_sequence);
    logical_trace::Range trace_postwait;
    const auto step_start = step.step_start, start = step.start;''')
    s = replace(s, '      check(step.wait()); step.completion = {};', '''      {
        logical_trace::Range trace_wait("hyle/completion_wait", trace_sequence);
        check(step.wait()); step.completion = {};
      }
      trace_postwait.start("hyle/postwait_publish", trace_sequence);''')
    s = replace(s, '    const auto finished = Clock::now();\n    for (std::size_t j = 0; j < outputs.size(); ++j) if',
        '    const auto finished = Clock::now();\n    trace_postwait.finish(); trace_finish.finish(); logical_trace::end_model(trace_sequence);\n    for (std::size_t j = 0; j < outputs.size(); ++j) if')
    newline = '\r\n' if b'\r\n' in raw else '\n'
    after = snapshot('engine/models/qwen35/main.cc', s.replace('\n', newline).encode())
    before = W/'source-base/main.cc'; before.parent.mkdir(parents=True, exist_ok=True); before.write_bytes(raw)
    patch = W/'model.patch'
    patch.write_text(''.join(difflib.unified_diff(raw.decode().splitlines(True),
        Path(after['path']).read_text().splitlines(True), fromfile='base/main.cc', tofile='source/main.cc')), encoding='utf-8')
    return dict(original=pin(base), before=pin(before), source=after, patch=pin(patch))


def make_peer():
    base = B/'peer/source/peer-batch.cc'
    raw = base.read_bytes()
    s = raw.decode().replace('\r\n', '\n')
    s = replace(s, '#include "../architecture-refactor-2026-10-18/d4-windows-preparation-2026-10-21/peer-continuation/peer_benchmark.cpp"',
        '#include "'+str((R/'.scratch/architecture-refactor-2026-10-18/d4-windows-preparation-2026-10-21/peer-continuation/peer_benchmark.cpp').resolve()).replace('\\', '/')+'"')
    s = replace(s, '#include "../architecture-refactor-2026-10-18/llama-matched-consumer/source/src/llama-memory.h"',
        '#include "'+str((R/'.scratch/architecture-refactor-2026-10-18/llama-matched-consumer/source/src/llama-memory.h').resolve()).replace('\\', '/')+'"')
    s = replace(s, '    std::size_t visible = 0;\n    Point start{}, endpoint{};',
        '    std::size_t visible = 0;\n    bool stopped = false;\n    Point start{}, endpoint{};')
    s = replace(s, '    const auto schedules = schedule::read_session_schedules(manifest, vocabulary, capacity, committed, true);', '''    const auto schedules = schedule::read_session_schedules(manifest, vocabulary, capacity, committed, true);
    if (prefix_enabled || width != 2 || schedules.size() != 2)
        throw std::runtime_error("W13 natural wrapper requires two requests and no prefix cache");
    for (const auto &session : schedules) {
        if (session.phases.size() != 2 || session.phases[0].kind != schedule::PhaseKind::kPrompt ||
            session.phases[1].kind == schedule::PhaseKind::kPrompt ||
            session.phases[0].ids.size() != 154 || session.phases[1].ids.size() != 96)
            throw std::runtime_error("W13 natural wrapper requires P154 plus97 output quota per member");
    }''')
    s = replace(s, '        p.consumed = true;\n    };', '''        if (o.next == 248044 || o.next == 248046) {
            run.stopped = true;
            summary.after = p.target; summary.seconds = seconds(run.endpoint, summary.start);
        }
        p.consumed = true;
    };''')
    s = replace(s, '            for (const auto & call : wave) {\n                auto & run = runs[call.session]; const auto & phase',
        '            for (const auto & call : wave) {\n                if (runs[call.session].stopped) continue;\n                auto & run = runs[call.session]; const auto & phase')
    s = replace(s, '                const auto start = Clock::now(); const auto target = run.visible + call.count;', '''                const auto start = Clock::now(); const auto target = run.visible + call.count;
                // Natural continuation: the placeholder tape fixes only quota.
                // Every executed decode consumes its own previous GPU greedy ID.
                if (phase.kind != schedule::PhaseKind::kPrompt) {
                    if (!run.head || run.head->next < 0 || run.head->next >= vocabulary || call.count != 1)
                        throw std::runtime_error("natural decode has no exact previous greedy token");
                    run.tokens[call.first] = run.head->next;
                }''')
    s = replace(s, '            // Stable equal actual-T + phase-kind buckets.',
        '            if (pending.empty()) continue;\n            // Stable equal actual-T + phase-kind buckets.')
    s = replace(s, '            for (const auto & call : wave) wave_tokens += call.count;',
        '            for (const auto & item : pending) wave_tokens += item.call.count;')
    s = replace(s, '{"outputs", wave.size()}, {"logical_tokens", wave_tokens}',
        '{"outputs", pending.size()}, {"logical_tokens", wave_tokens}')
    s = replace(s, '        result["processed_tokens"] = logical_tokens;',
        '        logical_tokens = 0; for (const auto &item : observations) logical_tokens += item.logical_tokens;\n        result["natural_greedy"] = true;\n        result["processed_tokens"] = logical_tokens;')
    s = replace(s, 'item["id"] = schedules[s].id; item["generated_ids"] = run.predictions; item["visible_tokens"] = run.visible;',
        'item["id"] = schedules[s].id; item["generated_ids"] = run.predictions; item["visible_tokens"] = run.visible;\n            item["eos"] = run.stopped; item["actual_input_ids"] = Tokens(run.tokens.begin(), run.tokens.begin() + static_cast<std::ptrdiff_t>(run.visible));')
    after = snapshot('peer-natural-b2.cc', s.replace('\n', '\r\n').encode())
    patch = W/'peer-natural.patch'
    patch.write_text(''.join(difflib.unified_diff(raw.decode().replace('\r\n', '\n').splitlines(True), s.splitlines(True),
        fromfile='base/peer-batch.cc', tofile='source/peer-natural-b2.cc')), encoding='utf-8')
    # Same successful old schedule parser bytes, recovered locally.
    for rel in ('tools/qwen35_text/schedule.h', 'tools/qwen35_text/session_schedule.h'):
        snapshot(rel, (B/'peer/source'/rel).read_bytes())
    return dict(original=pin(base), source=after, patch=pin(patch),
        limitation='One natural turn, no prefix cache. Real EOS stops a member; reduced width is reported, not padded.')


def main():
    assert not (W/'plan.json').exists(), 'Keep the first frozen plan; no implicit regeneration'
    ready = read(V/'ready-cli.json')
    assert ready['image']['sha256'] == 'f0296307dbc0fe967e79b8e67395face3bb18600acfb7068d6c15566bbc256f3'
    for key in ('image', 'inputs', 'runtime', 'recipe'):
        exact(ready[key])
    headers, nvtx = freeze_headers()
    helper, model, peer = make_helper(), make_model(), make_peer()
    fixture = R/'.scratch/qwen35-unsloth-mtp-20261024/geometry-v2-check/original'
    prompt = (fixture/'prompt.ids').read_bytes()
    assert len(prompt.split()) == 154
    case = W/'inputs'; case.mkdir(parents=True, exist_ok=True)
    (case/'prompt.ids').write_bytes(prompt)
    (case/'natural.schedule').write_bytes(b'prompt prompt.ids\ngenerate 97\n')
    (case/'natural-sessions.tsv').write_bytes(b'A natural.schedule\nB natural.schedule\n')
    (case/'quota-only.ids').write_bytes((' '.join(['0']*96)+'\n').encode())
    (case/'peer-quota.schedule').write_bytes(b'prompt prompt.ids\ndecode quota-only.ids\n')
    (case/'peer-sessions.tsv').write_bytes(b'A peer-quota.schedule\nB peer-quota.schedule\n')
    peer_ready = read(P/'peer/ready.json')
    for k in ('image', 'source', 'runtime', 'link_inputs'):
        exact(peer_ready[k])
    inputs = str(fixture)
    hyle_exe = str(W/'hyle/bin/hyle.exe')
    peer_r1 = peer_ready['image']['path']
    peer_b2 = str(W/'peer-b2/bin/consumer.exe')
    gguf = str(R/'.scratch/architecture-refactor-2026-10-18/llama-matched-consumer/Qwen3.5-2B-text-MTP-BF16.gguf')
    text_gguf = str(R/'.scratch/architecture-refactor-2026-10-18/llama-matched-consumer/Qwen3.5-2B-text-BF16.gguf')
    hbase = [hyle_exe, '--inputs', inputs, '--backend', 'cuda', '--capacity', '256', '--sampling', 'greedy', '--prefix-cache', 'off']
    single = ['--schedule', str(case/'natural.schedule'), '--max-sessions', '1', '--active-sequences', '1']
    batch = ['--session-schedules', str(case/'natural-sessions.tsv'), '--max-sessions', '2', '--active-sequences', '2']
    commands = []
    for name, args in (
        ('r1-off', hbase+single+['--mtp', 'off', '--decode-overlap', 'off']),
        ('r1-auto', hbase+single+['--mtp', 'off', '--decode-overlap', 'auto']),
        ('r1-peer', [peer_r1, '--model', gguf, '--inputs', inputs, '--capacity', '256', '--steps', '97', '--mtp', 'off', '--memory-snapshots', 'off']),
        ('b2-off', hbase+batch+['--mtp', 'off', '--decode-overlap', 'off']),
        ('b2-auto', hbase+batch+['--mtp', 'off', '--decode-overlap', 'auto']),
        ('b2-peer', [peer_b2, text_gguf, '--session-schedules', str(case/'peer-sessions.tsv'), '--capacity', '256', '--cache-slots', '2', '--active-sequences', '2', '--pool-tokens', '512', '--prefix-cache', 'off']),
        ('mtp-hyle', hbase+single+['--mtp', 'on', '--mtp-max-drafts', '1']),
        ('mtp-peer', [peer_r1, '--model', gguf, '--inputs', inputs, '--capacity', '256', '--steps', '97', '--mtp', 'on', '--memory-snapshots', 'off'])):
        folder = W/'runs'/name
        if name == 'b2-peer': args += ['--result', str(folder/'report.json')]
        elif name.endswith('peer'): args += ['--output', str(folder/'report.json')]
        profile = [str(NSYS), 'profile', '--trace=cuda,cublas,nvtx', '--cuda-graph-trace=node',
            '--sample=none', '--cpuctxsw=none', '--discard-environment=true',
            '--nvtx-domain-include=HyleLogicalCalls', '--duration=60', '--kill=true', '--wait=all',
            '--stats=false', '--export=sqlite', '--output='+str(folder/'trace'), *args]
        commands.append(dict(name=name, consumer=args, profile=profile, timeout_seconds=120,
            expected_nominal=dict(outputs_per_member=97, prompt_rows=154, decode_inputs_per_member=96,
                width=2 if name.startswith('b2') else 1,
                physical_ordinary_roots=97 if not name.startswith('mtp') else None),
            no_automatic_retry=True, reference_status='Retained per-mode reference plus original ledger/state predicate; new P154 R2 long horizon requires full per-member invariants and off/auto comparison'))
    save(W/'plan.json', dict(status='PREPARED_SOURCES_AND_COMMANDS_NOT_BUILT_NOT_RUN',
        baseline_ready=pin(V/'ready-cli.json'), baseline_image=ready['image'], baseline_inputs=ready['inputs'],
        Model='e0067b13c7d60ba5bcdb5ca236898bbf12b61b4d96b4411d8b8cd23b40177cb2',
        Graph='f160c92d3d369de9b469b0976ae4a42a1928f6c4265f13345c2cbff1d1010e6f',
        source_git='2fe2916cf', frozen_project_headers=len([x for x in headers if x['snapshot']!=x['original']]),
        sources=dict(helper=helper, model=model, peer_b2=peer),
        existing_peer=pin(P/'peer/ready.json'), profiler=pin(NSYS),
        hardware=dict(name='NVIDIA GeForce RTX4070', uuid='GPU-e7376560-6f5d-ec19-6ee4-3dd3a2c81ef8', driver='617.14', memory_MiB=12282),
        tool_version='NVIDIA Nsight Systems2026.1.3.425-261338342291v0',
        commands=commands, compile_budget=dict(host_CXX=2, links=2, SDK=0, NVCC=0, downloads=0),
        root_contract=[
            'Model roots use unique actual StepState sequence/role/R/T/slot/imported/base contexts and can overlap for A/B.',
            'GPU activities must be assigned by actual submit/API correlation/native launch identity, never merely every activity enclosed by overlapping wall roots.',
            'Compare exact common logical ordinals and actual per-root native route/record/launch signatures; independent not-record predicates are forbidden.',
            'R1 and natural B2: nominal1prefill+96decode if noEOS; natural B2 is not the old99-root teacher-forced trace.',
            'MTP target/draft work and accepted work are recorded separately. Actual completion/rows/acceptance come from reports; no assumed fixed episode count.',
            'Both engines consume own actual greedy predictions. Same prompt/quota/shape is not equal continuation IDs or bitwise numerical work.',
            'Full producer reports retained; only original time/native replay metadata normalized. No new memory/TPS/performance-statistical window.'
        ]))
    print('PREPARED_ONLY', pin(W/'plan.json'))


if __name__ == '__main__':
    main()
