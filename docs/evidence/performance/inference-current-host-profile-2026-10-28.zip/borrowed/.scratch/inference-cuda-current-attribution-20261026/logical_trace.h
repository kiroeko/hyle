#pragma once
#include <nvtx3/nvToolsExt.h>
#include <cstddef>
#include <cstdio>
#include <cstdint>
namespace logical_trace {
inline nvtxDomainHandle_t domain=nullptr;
inline unsigned long long sequence=0,finished_ranges=0,overlapping_episodes=0;
inline void initialize() noexcept { domain=nvtxDomainCreateA("HyleLogicalCalls"); }
class Range final {
 nvtxRangeId_t id_=0; bool active_=false;
 public:
 Range() noexcept=default;
 explicit Range(const char *text,unsigned long long payload=0) noexcept {start(text,payload);}
 Range(const Range &)=delete;Range &operator=(const Range &)=delete;
 ~Range(){finish();}
 void start(const char *text,unsigned long long payload=0) noexcept {
  if(active_){++overlapping_episodes;finish();}
  nvtxEventAttributes_t event{};event.version=NVTX_VERSION;event.size=NVTX_EVENT_ATTRIB_STRUCT_SIZE;
  event.messageType=NVTX_MESSAGE_TYPE_ASCII;event.message.ascii=text;
  event.payloadType=NVTX_PAYLOAD_TYPE_UNSIGNED_INT64;event.payload.ullValue=payload;
  id_=nvtxDomainRangeStartEx(domain,&event);active_=true;
 }
 void finish() noexcept {if(active_){nvtxDomainRangeEnd(domain,id_);active_=false;++finished_ranges;}}
};
inline Range episode;
inline char episode_text[256]{};
inline void hyle_begin(unsigned role,std::size_t target_rows,std::size_t draft_rows,std::size_t width,std::size_t context,std::size_t frontier,std::size_t lag) noexcept {
 ++sequence;std::snprintf(episode_text,sizeof(episode_text),"hyle/episode seq=%llu role=%u target_T=%zu draft_T=%zu R=%zu context=%zu frontier=%zu lag=%zu",sequence,role,target_rows,draft_rows,width,context,frontier,lag);episode.start(episode_text,sequence);
}
inline void dump() noexcept { std::fprintf(stderr,"LOGICAL_NVTX sequence=%llu completed_ranges=%llu overlapping_episodes=%llu\n",sequence,finished_ranges,overlapping_episodes); }
struct RunScope final {
 RunScope() noexcept { initialize(); }
 ~RunScope() { episode.finish(); dump(); }
};
}
