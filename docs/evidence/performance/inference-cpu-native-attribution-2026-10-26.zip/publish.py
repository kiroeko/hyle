"""Publish the sole retained CPU attribution diagnostic; no runtime/build."""
from pathlib import Path
import datetime,hashlib,json,zipfile
W=Path(__file__).resolve().parent;B=W.parent;R=B.parents[1]
PUBLIC=R/'docs/evidence/performance/inference-cpu-native-attribution-2026-10-26.json';ZIP=PUBLIC.with_suffix('.zip')
def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def pin(p):
 p=Path(p).resolve();b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def save(p,x):
 p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((json.dumps(x,indent=2,ensure_ascii=False,allow_nan=False)+'\n').encode())

def main():
 run=read(W/'run/summary.json');ready=read(W/'ready.json');memo=read(W/'memo.json');facts=read(W/'facts.json')
 assert run['process']['exit']==0 and not run['process']['timed_out']
 assert run['full_nontime_differences']==0 and read(W/'run/nontime-diff.json')==[]
 assert facts['store']['seen']==facts['store']['stored']==9104
 assert facts['store']['graphs']==1144 and facts['store']['nodes']==10554
 assert not any(facts['store'][k] for k in ['event_overflow','graph_overflow','node_overflow'])
 assert facts['coverage']['native_errors']==0 and facts['coverage']['outside_or_crossing_observed_windows']==0
 assert facts['coverage']['compute_intervals_nonoverlapping'] and facts['coverage']['union_equals_sum']
 assert memo['raw']==pin(W/'facts.json')
 source=read(W/'source-pins.json');assert pin(source['after']['path'])==source['after']
 files={}
 def add(name,path):
  p=Path(path);assert p.is_file(),p
  assert p.suffix.lower() in {'.json','.py','.patch','.cc','.log','.txt'},p
  assert name not in files;files[name]=p
 for name in ['source.patch','source-pins.json','build.py','run.py','ready.json','runtime.json','link-inputs.json',
              'analyze.py','facts.json','memo.json','publish.py']:
  add(name,W/name)
 for folder in ['compile','link']:
  for leaf in ['command.json','process.json','stdout.log','stderr.log','actual-dependencies.json']:
   p=W/folder/leaf
   if p.is_file():add(folder+'/'+leaf,p)
 for leaf in ['command.json','process.json','stdout.log','stderr.log','phase-receive.json','nontime-diff.json','summary.json']:
  add('run/'+leaf,W/'run'/leaf)
 for name in ['cpu-remaining-source-review.json','cpu-loading-source-review.json']:
  add('source-review/'+name,B/name)
 add('reference/behavior1-stdout.log',B/'behavior1/stdout.log')
 add('reference/behavior1-summary.json',B/'behavior1/summary.json')
 add('reference/context-team-source-pins.json',B/'source-pins.json')
 add('reference/context-team-ready.json',B/'build1/ready.json')
 report=dict(schema='hyle.cpu-native-attribution.v1',status='SOLE_WINDOWS_CPU_DIAGNOSTIC_COMPLETE_NOT_A_THROUGHPUT_RESULT',
  generated_UTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),
  scope='One normal Windows CPU P154/16/C256/N1/R1 greedy process: shared563 consumer plus only a private CpuExecution runtime OBJ. Native SDK,Model/app/provider/weights/thread4 unchanged. No repeat,warmup,profiler,peer or GPU model run.',
  process=run['process'],behavior=dict(full_nontime_differences=0,clock_keys_only_excluded=True,
   reference=run['normal_reference'],raw_comparison=pin(W/'run/nontime-diff.json'),
   same154prompt16outputIDs169target15decode=True),
  recorded_failures=dict(compile=0,link=0,model=0,timeouts=0,native_errors=0,
   event_overflow=0,graph_overflow=0,node_overflow=0,
   scope='The sole diagnostic compiled,linked and ran successfully on its first recorded attempt. No diagnostic failure/retry is reported; older Context-team test-link failures remain separate historical evidence.'),
  measured_findings=memo,analysis_facts=pin(W/'facts.json'),analysis_script=pin(W/'analyze.py'),
  build=dict(ready=ready,runtime=pin(W/'runtime.json'),source=source,
   closure='Exactly1runtimehostTU+link;oneold563runtimeOBJ replaced,allotherlinkinputs unchanged. Ready retains originalbuild-only status text;laterprocess record proves actualrun. NoSDK/nativeCUDA/vendor rebuild.'),
  phase_and_clock=dict(markers=read(W/'run/phase-receive.json'),
   limits='Markers are parent stderr receipt timestamps,not producer/model endpoint instants. The exit steadyClock/QPC bridge brackets mapping uncertainty. Unknown pipe/scheduling delay remains. Actual graph identity,call ordering and shape support phase assignment; M1 alone is insufficient because the prefill head also has M1.'),
  instrumentation_boundaries=[
   'Three originalrun ticks bracket team admission and actualnativecompute. Admission includes originalgate/TLS/lock work;nativecompute includes native CPU implementation,workers/synchronization,not just arithmetic.',
   'FixedPOD graph/signature/descriptor/event recording runs after measuredcompute but still inside the originalmodelrun andheldteamgate. This overhead is not in compute buckets;remainingwall must not be called pureHyle overhead or recoverabletime.',
   'Tensorfacts are metadata snapshots,not tensorcontent reads. Only source0/source1 descriptions/spans/addresses recorded;source_count preserves additionalunknownsources. Operandspan is not measuredDRAMtraffic.',
   'Composite native graph elapsed stays composite. Never distribute its whole wall interval to each contained op or sum overlapping labels. The offline script verifies nonoverlapping compute intervals,so union equals sum in this run.',
   'Dump is at normalprocess exit after originalmodelendpoints,no pernativefprintf. Counts/overflow/normalcompletion bound use;diagnosticTPS/processwall are not speed or baseline samples.'
  ],
  source_only_reviews=dict(remaining=read(B/'cpu-remaining-source-review.json'),loading=read(B/'cpu-loading-source-review.json'),
   limit='These files are independent source hypotheses/byteextents and loading proposals,not measuredperleafcosts or implementations. Loading/mmap/staging effects cannot be creditedto decode.'),
  related_public_evidence=dict(context_team=pin(R/'docs/evidence/performance/inference-cpu-context-team-2026-10-26.json'),
   CPU_AVX2_window=pin(R/'docs/evidence/performance/inference-cpu-avx2-window-2026-10-26.json'),
   old_samples_pooled=False),
  limits=['CPU only on Windows; no macOS/Linux runtime coverage.','No current peer per-op trace: this cannot assign the previous14.28% CPU throughput gap to an identical task or subtract buckets from different processes.','No whole-bank F32 expansion,leak,DRAM bandwidth,quality,bit identity or recoverable gain inferred from spans/times.','Original fa7 app predates R>1 sampling; N1 greedy here is unchanged. The private observer is not canonical product code.','No model/build during offline analysis/publication.'])
 save(W/'public-summary.json',report);add('summary.json',W/'public-summary.json')
 manifest=[dict(name=n,bytes=p.stat().st_size,sha256=pin(p)['sha256']) for n,p in sorted(files.items())]
 save(W/'archive-manifest.json',manifest);add('archive-manifest.json',W/'archive-manifest.json')
 ZIP.parent.mkdir(parents=True,exist_ok=True)
 with zipfile.ZipFile(ZIP,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
  for name,path in sorted(files.items()):z.writestr(name,path.read_bytes())
 with zipfile.ZipFile(ZIP) as z:
  assert z.testzip() is None and len(z.namelist())==len(files)
  for x in manifest:
   b=z.read(x['name']);assert len(b)==x['bytes'] and hashlib.sha256(b).hexdigest()==x['sha256']
 report['archive']=dict(**pin(ZIP),members=len(files),CRC_PASS=True,member_SHA256_PASS=True,
  exclusions='NoEXE/OBJ/LIB/DLL/map/SDK/model,fullsource/vendor tree oroldlargearchive.')
 report['archive']['path']=ZIP.relative_to(R).as_posix();save(PUBLIC,report)
 print(json.dumps(dict(report=pin(PUBLIC),archive=report['archive']),indent=2))

if __name__=='__main__':main()
