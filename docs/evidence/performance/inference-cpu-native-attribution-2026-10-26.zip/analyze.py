"""Offline, one-run native graph envelopes. Graph time is never per-node time."""
from pathlib import Path
import collections,hashlib,json
W=Path(__file__).resolve().parent
read=lambda p:json.loads(Path(p).read_text(encoding='utf-8-sig'))
def pin(p):
 p=Path(p).resolve();b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def save(p,x):p.write_text(json.dumps(x,indent=2,allow_nan=False)+'\n')
rows=[json.loads(x[len('HYLE_CPU_NATIVE_CLOCK '):]) for x in (W/'run/stderr.log').read_text().splitlines() if x.startswith('HYLE_CPU_NATIVE_CLOCK ')]
summary=next(x for x in rows if x['tag']=='summary');bridge=next(x for x in rows if x['tag']=='bridge');assert bridge['known']
events=[x for x in rows if x['tag']=='event'];graphs={x['id']:x for x in rows if x['tag']=='graph'};nodes=collections.defaultdict(list)
for x in rows:
 if x['tag']=='node':nodes[x['graph']].append(x)
assert summary['seen']==summary['stored']==len(events)==9104
assert not any(summary[k] for k in ['event_overflow','graph_overflow','node_overflow'])
assert all(e['native_status']==0 and e['before_lock_ns']<=e['after_lock_ns']<=e['after_compute_ns'] for e in events)
assert all(a['after_compute_ns']<=b['before_lock_ns'] for a,b in zip(events,events[1:]))
assert all(g['nodes']==g['stored_nodes']==len(nodes[i]) for i,g in graphs.items())
receive=read(W/'run/phase-receive.json');assert receive['qpc_frequency']==bridge['qpc_frequency'];freq=bridge['qpc_frequency'];steady_mid=(bridge['steady_before_ns']+bridge['steady_after_ns'])/2
# All clocks use Windows QPC; this explicit sample relates the native steady
# epoch to QPC. Marker receipt is later than the producer's fprintf and is not
# silently promoted to an exact writer timestamp.
markers={m['line'].split('=')[1]:dict(**m,estimated_steady_ns=steady_mid+(m['receive_qpc']-bridge['qpc'])*1e9/freq) for m in receive['markers']};assert len(markers)==4 and all(m['qpc_ok'] for m in markers.values())
phases={};all_indices=[];phase_graphs={}
report=read(W/'run/stdout.log')
heavy_names={'MUL_MAT','MUL_MAT_ID','GATED_DELTA_NET','SSM_CONV','FLASH_ATTN_EXT'}
for phase,episodes in [('prefill',1),('decode',15)]:
 lo=markers['generation_default_'+phase+'_begin']['estimated_steady_ns'];hi=markers['generation_default_'+phase+'_end']['estimated_steady_ns'];es=[e for e in events if lo<=e['before_lock_ns'] and e['after_compute_ns']<=hi];all_indices += [e['index'] for e in es];phase_graphs[phase]=set(e['graph'] for e in es)
 families=collections.defaultdict(lambda:dict(calls=0,native_ns=0));composites=collections.defaultdict(lambda:dict(calls=0,native_ns=0));matrices=collections.defaultdict(lambda:dict(calls=0,native_ns=0));weights={}
 for e in es:
  ns=e['after_compute_ns']-e['after_lock_ns'];nslist=nodes[e['graph']];heavy=[n for n in nslist if n['op_name'] in heavy_names];family='+'.join(n['op_name'] for n in heavy)+'_graph' if heavy else 'other_native_graph'
  z=families[family];z['calls']+=1;z['native_ns']+=ns
  signature=tuple(n['op_name'] for n in nslist);z=composites[signature];z['calls']+=1;z['native_ns']+=ns
  if len(heavy)==1 and heavy[0]['op_name']=='MUL_MAT':
   n=heavy[0];a,b=n['source0'],n['source1'];o=n['output'];key=(a['type'],tuple(a['ne']),tuple(a['nb']),a['span'],b['type'],tuple(b['ne']),o['type'],tuple(o['ne']))
   z=matrices[key];z['calls']+=1;z['native_ns']+=ns;weights[(a['address'],a['span'],tuple(a['ne']))]=a['span']
 native_ns=sum(e['after_compute_ns']-e['after_lock_ns'] for e in es);gate_ns=sum(e['after_lock_ns']-e['before_lock_ns'] for e in es);wall=report[phase+'_seconds']
 def duration(z):return dict(calls=z['calls'],native_ms=z['native_ns']/1e6,per_episode_native_ms=z['native_ns']/1e6/episodes)
 mat=[dict(weight_type=k[0],weight_ne=k[1],weight_nb=k[2],weight_nominal_span_bytes=k[3],activation_type=k[4],activation_ne=k[5],output_type=k[6],output_ne=k[7],**duration(v)) for k,v in sorted(matrices.items(),key=lambda x:-x[1]['native_ns'])]
 phases[phase]=dict(episodes=episodes,calls=len(es),native_ms=native_ns/1e6,native_ms_per_episode=native_ns/1e6/episodes,team_admission_ms=gate_ns/1e6,reported_endpoint_ms=wall*1000,reported_endpoint_ms_per_episode=wall*1000/episodes,native_envelope_fraction_of_reported_endpoint=native_ns/(wall*1e9),remainder_ms=wall*1000-(native_ns+gate_ns)/1e6,remainder_scope='Includes all unobserved providers/Graph/host work and this observer metadata overhead; not a measured recoverable host cost.',first_event_index=es[0]['index'],last_event_index=es[-1]['index'],distinct_graph_signatures=len(phase_graphs[phase]),first_begin_after_marker_ms=(es[0]['before_lock_ns']-lo)/1e6,last_end_before_marker_ms=(hi-es[-1]['after_compute_ns'])/1e6,exclusive_families={k:duration(v) for k,v in sorted(families.items(),key=lambda x:-x[1]['native_ns'])},matrix_graph_shapes=mat,top_complete_graph_sequences=[dict(ops=list(k),**duration(v)) for k,v in sorted(composites.items(),key=lambda x:-x[1]['native_ns'])[:15]],unique_matrix_binding_spans=dict(bindings=len(weights),nominal_bytes=sum(weights.values()),meaning='Native MUL_MAT source0 descriptors/addresses; nominal bounding spans, not measured memory traffic.'))
 assert sum(v['native_ns'] for v in families.values())==native_ns
assert sorted(all_indices)==list(range(len(events))) and phase_graphs['prefill'].isdisjoint(phase_graphs['decode'])
assert phases['prefill']['calls']==569 and phases['decode']['calls']==15*569
native_header=next(Path(x['path']) for x in read(W/'compile/actual-dependencies.json') if Path(x['path']).name=='ggml.h')
header_lines=native_header.read_text().splitlines()
type_lines=[dict(line=i+1,text=line.strip()) for i,line in enumerate(header_lines) if 'GGML_TYPE_F32     = 0,' in line or 'GGML_TYPE_BF16    = 30,' in line]
assert len(type_lines)==2
facts=dict(status='ONE_CPU_NATIVE_OBSERVATION_WORK_PASS',dtype_evidence=dict(header=pin(native_header),definitions=type_lines),process=read(W/'run/process.json'),semantic_gate=read(W/'run/summary.json'),store=summary,bridge=bridge,markers=markers,coverage=dict(seen=len(events),recorded=len(events),classified_by_observed_phase_windows=len(all_indices),outside_or_crossing_observed_windows=0,native_errors=0,phase_graph_sets_disjoint=True,complete_graph_node_sequences=True,source_descriptors_recorded_per_node=2,extra_source_count_exposed=True,compute_intervals_nonoverlapping=True,union_equals_sum=True),phases=phases,stage_boundary_limits=['QPC/steady bridge explicitly uses the same Windows monotonic device. Native bridge bracket is '+str(bridge['steady_after_ns']-bridge['steady_before_ns'])+' ns.','stderr markers are receive timestamps, so unknown pipe/scheduling latency remains; no exact producer timestamp is invented. Every event is contained, first/last native events are separated from receive boundaries, and distinct cold graph groups plus 569/15*569 ordering support this phase assignment.','M1 alone does not identify decode: prefill has its own independently recorded tied-head M1 graph and one call, decode has 15.'],inputs=dict(ready=pin(W/'ready.json'),normal_reference=pin(W.parent/'behavior1/stdout.log'),source_pins=pin(W/'source-pins.json'),analyzer=pin(__file__)),scope=['One private CpuExecution runtime OBJ only; all remaining563 consumer link inputs unchanged.','Three clocks observe team admission and the synchronous original CpuProgram.compute envelope. Admission includes TLS/mutex overhead and is not a proof of contended wait.','A native graph containing MUL_MAT includes its wrapper nodes; no entire envelope is assigned independently to every node.','No native kernel internal threading, actual DRAM/PMU counters, other providers, cross-engine time match, quality or fault injection is observed.','Approximately10.1MB fixed store plus registration/hash work and exit dump are diagnostic overhead; this run TPS is not a performance sample. No callback/percall fprintf, hot allocation or owner storage added.'])
save(W/'facts.json',facts)
d=phases['decode'];p=phases['prefill'];mm=d['exclusive_families']['MUL_MAT_graph'];memo=dict(status='ATTRIBUTION_COMPLETE_NO_FURTHER_RUN',strongest_fact='The original native BF16 matrix graph envelopes dominate decode; team admission is negligible in this single serial CPU4 run.',decode=dict(calls=d['calls'],episodes=15,native_compute_ms_per_output=d['native_ms_per_episode'],endpoint_ms_per_output=d['reported_endpoint_ms_per_episode'],team_admission_total_ms=d['team_admission_ms'],matrix_graph_ms_per_output=mm['per_episode_native_ms'],matrix_graph_fraction_of_native=mm['native_ms']/d['native_ms'],matrix_graph_fraction_of_same_run_decode_wall=mm['native_ms']/d['reported_endpoint_ms'],outside_native_compute_total_ms=d['reported_endpoint_ms']-d['native_ms'],outside_native_compute_ms_per_output=(d['reported_endpoint_ms']-d['native_ms'])/15,outside_native_scope='Includes the0.6421ms team admission as well as other providers/Graph/host/observer work; not an attributed recoverable bucket.',top_matrix_graphs=d['matrix_graph_shapes'][:3]),prefill=dict(calls=p['calls'],native_compute_ms=p['native_ms'],endpoint_ms=p['reported_endpoint_ms'],matrix_graph_ms=p['exclusive_families']['MUL_MAT_graph']['native_ms'],tied_head_M1_graph=next(x for x in p['matrix_graph_shapes'] if x['weight_ne'][1]==248320)),priority='If another CPU optimization is pursued, first inspect the actual same-program BF16 M1 MUL_MAT inner path / eligible existing projection provider for the 66 wide matrices and tied head. This is an unimplemented research direction, not a measured counterfactual or promise of gain. Do not lower all native threads or infer bandwidth from nominal spans.',not_conclusions=['This does not locate a13.8ms Hyle-peer difference: peer was not observed in this run.','The182ms decode endpoint remainder includes unobserved providers/host and observer overhead; it is not wholly recoverable.','BF16 arithmetic/storepoints and full output semantics remain the frozen contract; no change or reduced precision was tested.'],raw=pin(W/'facts.json'),model_processes=1,new_builds=dict(runtime_TU=1,link=1),new_GPU_runs=0)
save(W/'memo.json',memo);print(json.dumps(dict(facts=pin(W/'facts.json'),memo=pin(W/'memo.json'),decode=memo['decode']),indent=2))
