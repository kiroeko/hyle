# Qwen3.5-2B 推理架构实验消费者

这是检验 Compute/Graph 架构的独立测试产物，不是已交付的推理引擎。使用本地官方权重运行完整24层CUDA纯文本计算，关闭MTP和视觉。
消费者只调用公共接口，模型格式、tokenizer和生成策略仍由消费者负责。

`prepare.py` 校验原输入清单的13个文件，输出权重偏移和token IDs；Python只做输入准备与独立参考。
`main.cc` 用一份模型语义图表达prefill、带状态的多token continuation和decode，在启动时预列本次调用序列，
以有限shape图族一次冷编译。每个实际child有两个Invocation槽；运行时只查找已准备入口，不临时建图、编译或padding。
conv/GDN状态真实反馈，KV使用固定容量且只更新新增行；失败使当前请求失效。

六个BF16 GQA attention共用一份BatchSchema，每次执行共享同一owned layout与metadata输入。
schema容量为最大预列chunk，具体Q/output行数等于当前chunk，KV可见长度由layout和positions表达。
例如23-token prefill→4-token continuation→单token decode使用同图族的23/4/1三个child；head深度等模型常数保持固定。
每槽冷绑定输入、输出和状态；每步更新token、position与layout，沿原Invocation执行`graph::batch::prepare`→`prepare_replay`→submit→Completion，再反馈状态和读取token。
两个槽不授权并发覆盖同一个Model的tokens、KV或状态；`evaluate`须顺序调用。退出先drain槽，再结束运行时和释放数据。

构建消费者的已安装SDK须包含CUDA `compute;graph;graph_progress;compute_stream;mem` 产品。
CMake只查包和链接，不构建原生依赖。`--inputs DIR` 指向准备后的输入；可用选项：

- `--continuation IDS`：prefill后追加多token输入；`--steps N`指定生成阶段数。
- `--schedule FILE`：执行固定输入的多轮prompt／decode；与`--continuation`、`--decode-ids`及显式`--steps`互斥。所有ID和完整会话容量在创建Model前校验。
- `--progress direct|scheduler`：默认direct；scheduler在原槽上准备进度驱动，复用同一提交机制。
- `--replay auto|commands|prefer-capture`：默认auto，按本次调用计划冷统计每个child／槽的使用次数，只用一次走commands，预计复用才prefer-capture；也可显式固定其中一种模式。生成可能提前结束，计划次数是请求上界，不保证每份capture都会复用。`planned_replay`记录冷选择，逐步日志记录实际录制与复用；不做虚假预热或把首次执行移出计时。
- `--decode-ids FILE`：固定单token输入带，允许跨过预测EOS；若同时给steps，须等于输入数加一。正常生成遇到endoftext或im_end停止。
- `--trace DIR --trace-level decisions`：仅导出logits与最后hidden；默认full还导出状态。路由写入DIR/routes，不增加图输出。
- `--layer0-probe DIR`：诊断时另行发布layer0边界并比较实际路由；诊断图会影响合法融合，因此与普通图分别冷准备，均计入启动时间。

多轮manifest每行是`prompt IDSFILE`或`decode IDSFILE`，须从prompt开始并按完整prompt／decode对交替。
ID文件路径相对manifest所在目录；含空格的路径用双引号，ID文件使用空白分隔的整数。例如：

```text
prompt prompt1.ids
decode decode1.ids
prompt prompt2.ids
decode decode2.ids
```

```text
hyle_qwen35_text --inputs DIR --schedule session/manifest.txt --capacity 1024
```

每个prompt块执行一次，每个decode ID执行一次单token调用，固定输入允许跨过预测EOS。
后续prompt沿同一个Model及原KV、conv/GDN状态追加，不重新加载或重置缓存。
图族按整个会话的调用顺序冷统计两个实际槽的使用次数；轮次边界不重置parity，也不执行预热。
日志标签为`round1_prefill`、`round1_decode1`等；每个阶段另有
`memory_phase=roundX_prefill_begin/end`或`roundX_decode_begin/end`标记，供独立显存旁采定位，不代表消费者已测得显存数值。

仅schedule模式的stdout追加`phase_count`、`turn_count`、`processed_tokens`、`generated_tokens`和`phases`摘要。
`processed_tokens`是实际输入总数；`generated_tokens`是每个prompt末尾返回的一枚首token，加上每次decode返回的一枚token。
每phase记录上下文范围、完整阶段`seconds`及原逐调用`step_sum_seconds`。
逐调用记录和标签在冷端预分配，执行时只填原计时、capture和token字段；最后一个host端点之后，才按原两行格式顺序打印日志。
`session_seconds`从首阶段输入准备前至最后token在host可见，保留实时阶段标记和控制间隙；
`startup_total_seconds`还包括输入解析、权重加载和冷图准备。最后调用端点之后的日志不计入这两个时间。
首用layout准备、capture和实例化均留在原完整调用计时内，不能只报重放段或平均各阶段TPS；
综合有效输出率使用`generated_tokens / session_seconds`；另列`processed_tokens / session_seconds`为总输入处理率，decode率按其实际调用数除以对应完整时间另报。
trace或layer0 probe会标记`diagnostic=true`，其中间导出可能拖长会话时间，不作为速度窗口。
未给schedule时保留原CLI结果和日志格式。

加载沿现有FileResourcePipeline，用两个8MiB pinned暂存读取原权重范围并上传，保留320个device分配和持久目标租约。
完整Model／ready／首token计时包含文件关闭、管线退休和临时运行时销毁。新进程未清OS页缓存，不能称冷盘加载。
`step_seconds`包含输入上传、layout准备、绑定、replay准备、提交、等待及token读回；首次shape编译在启动时完成，trace导出不在step内。
`seconds`和`submit_seconds`是更窄子段，不可直接与另一引擎的完整decode相比；完整启动至首token看`first_token_elapsed_seconds`。

本次有限图族已完成原128+31旅程的64份hidden/logits逐byte对照，以及23/4/1 scheduler＋capture旅程的6份对照。
两组独立性能窗口确认准备开销减少；decode小差异反向，未证明稳定提速。详见[有限图族实测](../../docs/evidence/performance/qwen-finite-family-2026-10-20.json)，
最新同窗指标见[当前工作](../../docs/developer/current-work.md)。报告中的compiled storage保留unknown计数，不等于完整显存峰值。
默认auto及其一次性chunk／重复槽选择见[最新实测与完整证据](../../docs/evidence/performance/qwen-auto-replay-policy-2026-10-21.json)；该策略修复了首次缓存续算损项，完整短decode的首次准备成本仍在排查。
另有独立的[进程内存／显存采样](../../docs/evidence/performance/qwen-memory-current-2026-10-20.json)：GPU峰值为采样下界，
驻留集、private commit和GPU共享内存分别记录；mmap与文件缓存会影响归属，不能将进程差直接当作全机RAM节省。

`reference.py`是独立Torch参考，候选不会读取参考状态或结果。固定输入与向量相同属于回归检查，独立质量验收仍未完成；
BF16舍入、归约和RoPE诊断见[底座审查证据](../../docs/evidence/correctness/inference-foundation-review-2026-10-18/README.md)。
原输入位于仓库`.scratch/inference-execution-refactor-2026-10-18/qwen35-text/`，不复制权重或SDK。
