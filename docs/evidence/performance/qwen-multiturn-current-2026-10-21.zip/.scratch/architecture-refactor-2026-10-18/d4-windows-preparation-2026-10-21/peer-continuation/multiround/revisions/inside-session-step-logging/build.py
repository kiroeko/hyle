"""Only the multi-turn peer consumer TU plus original reference libraries; no run."""
from pathlib import Path
import importlib.util
import os
import sys

sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
P = S.parent
D = P.parent
A = D.parent
R = A.parents[1]
spec = importlib.util.spec_from_file_location('peer_multiround_existing_helpers', P / 'build.py')
h = importlib.util.module_from_spec(spec)
spec.loader.exec_module(h)
b, c = h.b, h.c


def same(row):
    return all(b.identity(row['path'])[k] == row[k] for k in ('bytes', 'sha256'))


def main():
    recipe_path = P / 'checks/attempt2/identity.json'
    base_path = P / 'checks/attempt2/link-plan.json'
    recipe, base = c.read(recipe_path), c.read(base_path)
    frozen = c.read(S / 'source-freeze.json')
    assert same(frozen['source']) and same(frozen['shared_header'])
    assert all(same(x) for x in base['inputs'])
    out = S / 'checks/attempt1'
    out.mkdir(parents=True, exist_ok=True)
    (out / 'tmp').mkdir(exist_ok=True)
    assert not (out / 'compile.result.json').exists(), 'Preserve actual attempts.'
    source = P / 'peer_benchmark.cpp'
    # The reference adapter intentionally retains its own original flags;
    # Hyle's strict-host helper requires a different /W4 /WX recipe.
    command = []
    skip = False
    for arg in recipe['command']:
        if skip:
            skip = False
            continue
        if arg.lower() == '/sourcedependencies':
            skip = True
            continue
        if c.key(arg) == c.key(recipe['source']['path']) or arg.lower().startswith(('/fo', '/fd')):
            continue
        command.append(arg)
    command += ['/sourceDependencies', str(out / 'peer-deps.json'), str(source),
                '/Fo' + str(out / 'peer.obj'), '/Fd' + str(out / 'peer.pdb')]
    command.insert(1, '/I' + str(R))
    def flags(cmd):
        return [x for x in cmd if x.startswith('/') and not x.lower().startswith(('/fo', '/fd', '/i'))
                and x.lower() != '/sourcedependencies']
    assert flags(command) == flags(recipe['command'])
    env, runtime = b.environment(command, [x['path'] for x in base['inputs']], out)
    old_runtime = c.read(P / 'checks/attempt2/runtime-environment.json')['runtime']
    runtime = list(dict.fromkeys([*old_runtime, *runtime]))
    env['PATH'] = os.pathsep.join([*runtime, env['PATH']])
    c.save(out / 'compile-plan.json', dict(command=command, source=frozen['source'],
        shared_header=frozen['shared_header'], recipe=b.identity(recipe_path),
        unchanged_original_non_include_flags=True, added_include=str(R), GPU_runs=0, SDK_builds=0))
    c.execute('compile', command, env, out)
    deps_path = out / 'peer-deps.json'
    deps = c.read(deps_path)['Data']
    dependencies = [b.identity(p) for p in dict.fromkeys([deps['Source'], *deps['Includes']])]
    assert all(same(x) for x in dependencies) and same(frozen['source']) and same(frozen['shared_header'])
    assert frozen['shared_header'] in dependencies
    obj = b.identity(out / 'peer.obj')
    c.save(out / 'identity.json', dict(command=command, source=frozen['source'], object=obj,
        dependencies=dependencies, source_dependencies=b.identity(deps_path),
        recipe=b.identity(recipe_path), original_non_include_flags_unchanged=True,
        dependency_drift=0, SDK_builds=0, GPU_runs=0))
    old = recipe['object']
    assert sum(c.key(x['path']) == c.key(old['path']) for x in base['inputs']) == 1
    inputs = [obj if c.key(x['path']) == c.key(old['path']) else x for x in base['inputs']]
    assert all(same(x) for x in inputs)
    image = out / 'peer.exe'
    link = [obj['path'] if c.key(x) == c.key(old['path']) else x
            for x in base['command'] if not x.upper().startswith(('/OUT:', '/MAP:', '/IMPLIB:', '/PDB:'))]
    link += ['/OUT:' + str(image), '/MAP:' + str(image.with_suffix('.map')), '/IMPLIB:' + str(image.with_suffix('.lib'))]
    c.save(out / 'link-plan.json', dict(command=link, inputs=inputs, base=b.identity(base_path),
        source=frozen['source'], original_reference_input_count=len(inputs) - 1,
        replaced_object=old, CXX=1, links=1, GPU_runs=0, SDK_builds=0))
    c.execute('link', link, env, out)
    c.save(out / 'runtime-environment.json', dict(PATH=env['PATH'], runtime=runtime))
    c.save(S / 'ready-for-root.json', dict(status='multi_turn_peer_compiled_linked_not_run',
        image=b.identity(image), compile_identity=b.identity(out / 'identity.json'),
        link_plan=b.identity(out / 'link-plan.json'), runtime_environment=b.identity(out / 'runtime-environment.json'),
        source_freeze=b.identity(S / 'source-freeze.json'),
        exact_command=[str(image), 'MODEL.gguf', '--schedule', 'SCHEDULE.txt', '--capacity', 'CAPACITY', '--result', 'RESULT.json'],
        legacy_command=[str(image), 'MODEL.gguf', 'FIXED_INPUTS.json', 'RESULT.json'],
        previous_image=b.identity(P / 'checks/attempt2/peer.exe'),
        CXX=1, links=1, NVCC=0, SDK_builds=0, GPU_runs=0,
        limits='Build-only. Same original model/context/greedy APIs and reference libraries. Schedule numerics/performance await root execution.'))
    print('READY', image, flush=True)


if __name__ == '__main__':
    main()
