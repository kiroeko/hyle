from pathlib import Path
import collections, csv, hashlib, json, math
import numpy as np
OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[4]
PREFIX = OUT / "validation/short-prefix/attempt1"
def identity(path):
    path = Path(path)
    return dict(path=str(path.relative_to(ROOT)).replace("\\", "/"), bytes=path.stat().st_size, sha256=hashlib.sha256(path.read_bytes()).hexdigest())
summary = json.loads((PREFIX / "summary.json").read_text())
verified = []
for row in summary["vectors"]:
    pa, pb = Path(row["actual"]["path"]), Path(row["reference"]["path"])
    ba, bb = pa.read_bytes(), pb.read_bytes()
    assert hashlib.sha256(ba).hexdigest() == row["actual"]["sha256"]
    assert hashlib.sha256(bb).hexdigest() == row["reference"]["sha256"]
    bf16 = "hidden" in row["name"]
    def decode(data):
        if bf16:
            return (np.frombuffer(data, dtype="<u2").astype(np.uint32) << 16).view(np.float32).astype(np.float64)
        return np.frombuffer(data, dtype="<f4").astype(np.float64)
    a, b = decode(ba), decode(bb)
    assert np.isfinite(a).all() and np.isfinite(b).all()
    delta = a - b
    maximum = float(np.max(np.abs(delta)))
    norm = float(np.sqrt(np.sum(delta * delta)))
    reference_norm = float(np.sqrt(np.sum(b * b)))
    relative = norm / reference_norm
    changed = int(np.count_nonzero(a != b))
    assert changed == row.get("different_elements", 0)
    assert (ba == bb) == row["byte_equal"]
    assert math.isclose(maximum, row.get("finite_max_abs", 0), rel_tol=1e-12, abs_tol=1e-15)
    assert math.isclose(relative, row.get("finite_relative_l2", 0), rel_tol=1e-12, abs_tol=1e-15)
    verified.append(dict(visible_tokens=row["visible_tokens"], kind="hidden_bf16" if bf16 else "logits_f32", byte_equal=ba == bb, different_elements=changed, finite_max_abs=maximum, finite_relative_l2=relative))
verified.sort(key=lambda x: (x["visible_tokens"], x["kind"]))
aggregate = {}
for kind in ("hidden_bf16", "logits_f32"):
    rows = [x for x in verified if x["kind"] == kind]
    changed = [x for x in rows if not x["byte_equal"]]
    aggregate[kind] = dict(total_vectors=len(rows), equal_vectors=len(rows)-len(changed), changed_vectors=len(changed), all_values_finite=True, first_changed_visible_tokens=min(x["visible_tokens"] for x in changed), changed_relative_l2_min=min(x["finite_relative_l2"] for x in changed), changed_relative_l2_max=max(x["finite_relative_l2"] for x in changed), changed_max_abs=max(x["finite_max_abs"] for x in changed))
route_paths = {t: PREFIX / "schedule/trace/routes" / ("default-T" + t + ".route.tsv") for t in ("1", "16", "128")}
routes = {t: list(csv.DictReader(path.open(), delimiter="\t")) for t, path in route_paths.items()}
def nodes(rows):
    result = {}
    for row in rows:
        for token in row["nodes"].split(","):
            number, operation = token.split(":")
            result[int(number)] = (operation, row["provider"], row["implementation"])
    return result
n1, n16 = nodes(routes["1"]), nodes(routes["16"])
assert n1.keys() == n16.keys()
assert all(n1[i][0] == n16[i][0] for i in n1)
transitions = collections.Counter((n1[i], n16[i]) for i in n1 if n1[i] != n16[i])
route_report = dict(same_node_ids_and_operations=True, nodes=len(n1), per_shape={t: dict(steps=len(rows), providers=dict(collections.Counter(x["provider"] or "metadata-view" for x in rows)), identity=identity(route_paths[t])) for t, rows in routes.items()}, node_assignment_changes=[dict(operation=a[0], from_provider=a[1], from_implementation=a[2], to_provider=b[1], to_implementation=b[2], count=count) for (a,b), count in transitions.items()], T16_T128_route_file_identical=route_paths["16"].read_bytes() == route_paths["128"].read_bytes())
route_report["legacy_schedule_same_shape_files_identical"] = {t: (PREFIX / "legacy/trace/routes" / ("default-T"+t+".route.tsv")).read_bytes() == route_paths[t].read_bytes() for t in ("1", "128")}
source = ROOT / "tools/qwen35_text/main.cc"
before = ROOT / ".scratch/architecture-refactor-2026-10-18/d4-windows-preparation-2026-10-21/multiturn-consumer/hyle/before/tools/qwen35_text/main.cc"
a,b = source.read_text(),before.read_text()
preservation = {}
for name,start,end in [("prepare_family", "  void prepare_family(", "  Phase &prepare_child("), ("prepare_child", "  Phase &prepare_child(", "  Phase &prepare("), ("evaluate_through_host_endpoint", '    if (failed) throw', '    const auto finished = Clock::now();')]:
    preservation[name] = a[a.index(start):a.index(end)] == b[b.index(start):b.index(end)]
assert all(preservation.values())
short_correctness = OUT / "short-correctness/attempt1/summary.json"
peer = json.loads(short_correctness.read_text())
single = OUT / "validation/single/attempt1/summary.json"
single_data = json.loads(single.read_text())
report = dict(status="read_only_source_and_existing_raw_vector_review_not_numerical_acceptance", scope="One actual short schedule 128P + 8D + 16P + 15D versus the same 39-token continuation tape consumed sequentially; no new model execution.", summary_identity=identity(PREFIX / "summary.json"), raw_recomputation=dict(vectors=50, hashes_verified=50, all_values_finite=True, method="Decode original little-endian BF16 hidden / F32 logits; recompute full-vector F64 norm statistics. The 1e-12 statistic crosscheck only verifies the saved analysis, not model tolerance acceptance.", aggregate=aggregate, by_endpoint=verified), predictions=dict(common_endpoints=25, legacy_schedule_all_equal=summary["all_predictions_equal"], peer_schedule_all_equal=peer["between_arm_predictions_equal"], independent_quality_acceptance=False), unchanged_single_call_sequence=dict(identity=identity(single), vector_count=single_data["vector_count"], passed=single_data["passed"]), actual_routes=route_report, source_preservation=dict(current=identity(source), before=identity(before), byte_identical_regions=preservation), source_mechanisms=[dict(anchor="tools/qwen35_text/main.cc:621-664,827-840,875-908", fact="All exact-shape children bind the same model history/recurrent and KV buffers. Calls use absolute positions length+row, same cache prefix length and global call parity; each completed call flips parity. The second prompt does not construct/reset a Model or zero/import state."), dict(anchor="tools/qwen35_text/main.cc:1068-1110", fact="Schedule constructs one Model before all phases, then directly invokes its existing evaluate with each supplied phase ID sequence. Predictions never become schedule inputs."), dict(anchor="tools/qwen35_text/main.cc:266-304,638-661; src/compute_provider_cublas/cublas_provider.cc:466-498", fact="BF16 MatMul outputs feed explicit low-dtype nonlinear/normalization boundaries. Lt uses BF16 operands/output with F32 compute. GGML row-pair/gate-up native fusions and Lt need not have identical reduction trees; the observed 84 changed MatMul node assignments are a real pre-existing shape-dependent arithmetic boundary, not proof of an allowed error magnitude."), dict(anchor="src/compute_provider_ggml_cuda/tensor_program.cc:1101-1150; src/compute_provider_flashinfer/native_batch.cu:18-75", fact="GDN retains explicit prior state; its selected provider/implementation is unchanged for all 18 layers. Six causal ragged-attention nodes also retain their provider/implementation, while query rows/visible KV and native scheduling geometry differ. Equal provider IDs do not establish equal kernel arithmetic across chunk lengths.")], conclusion=dict(driver_state_reset_found=False, preexisting_multirow_route_difference_confirmed=True, first_divergent_layer_or_operation_identified=False, block_state_bug_excluded=False, numeric_pass=False, quality_pass=False, explanation="Evidence favors entry into the existing multirow arithmetic path over a new schedule reset. It does not establish that approximately 1% hidden/logit relative differences are benign, or rule out an underlying chunk/state implementation defect."), required_disclosure=["All 64 original single-schedule regression vectors are byte-equal, but this is a different call sequence from the two-turn chunk test.", "Of 50 full vectors at 25 common short endpoints, 18 are equal through visible136 and 32 differ starting at visible152. All observed predictions match, including the peer's 25 IDs; matching argmax is not full-vector or independent quality acceptance.", "New long/short performance may be reported as regression/performance observations with numerical divergence disclosed and independent quality unvalidated. No post-hoc numerical threshold is introduced.", "Compare this same finite schedule against the independent fixed-recurrent Torch reference before accepting its numerical behavior. Preserve raw error metrics; if deviations require attribution, use first divergent existing layer boundaries rather than accepting them by route explanation."], independent_reference=dict(status="driver_static_ready_not_run_by_reviewer", ready=identity(OUT / "reference/ready-for-root.json"), math_preserved=True, requested_scope="same input tape, same chunk schedule, one independent cache, 25 hidden/logit endpoints; no Hyle state/predictions used"), sources=[identity(ROOT / p) for p in ("src/compute_provider_cublas/cublas_provider.cc", "src/compute_provider_ggml_cuda/tensor_program.cc", "src/compute_provider_flashinfer/native_batch.cu", "tools/qwen35_text/schedule.h")], operations=dict(model_runs=0, gpu_runs=0, builds=0, product_edits=0))
(OUT / "prefix-numerical-source-review.json").write_text(json.dumps(report,indent=2) + "\n",encoding="utf-8")
print(json.dumps(dict(report=identity(OUT / "prefix-numerical-source-review.json"), aggregate=aggregate, route_changes=route_report["node_assignment_changes"]),indent=2))
