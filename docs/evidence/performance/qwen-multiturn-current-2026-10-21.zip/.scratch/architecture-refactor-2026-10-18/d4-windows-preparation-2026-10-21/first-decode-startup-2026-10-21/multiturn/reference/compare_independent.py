from pathlib import Path
import hashlib, json, statistics
import numpy as np
R = Path(__file__).resolve().parent
M = R.parent
ROOT = M.parents[4]
O = R / "short/attempt1"
PREFIX = M / "validation/short-prefix/attempt1"
def identity(path):
    path = Path(path)
    return dict(path=str(path.relative_to(ROOT)).replace("\\", "/"), bytes=path.stat().st_size, sha256=hashlib.sha256(path.read_bytes()).hexdigest())
original = json.loads((PREFIX / "summary.json").read_text())
oracle = json.loads((O / "reference.json").read_text())
execution = json.loads((R / "execution/result.json").read_text())
assert execution["exit"] == 0 and execution["terminal"]
assert oracle["reference_sha256"] == identity(ROOT / "tools/qwen35_text/reference.py")["sha256"]
assert len(oracle["steps"]) == 25 and oracle["processed_tokens"] == 167
assert oracle["trace_level"] == "decisions" and oracle["capacity"] == 256
assert oracle["generated_ids"] == [x["schedule_id"] for x in original["endpoints"]]
assert oracle["generated_ids"] == [x["legacy_id"] for x in original["endpoints"]]
lookup = {(x["visible_tokens"], "hidden_bf16" if "hidden" in x["name"] else "logits_f32"): x for x in original["vectors"]}
raw_inventory = []
values_per_arm = {"schedule": 0, "legacy": 0, "torch": 0}
nonfinite_per_arm = dict.fromkeys(values_per_arm, 0)
def decode(path, kind, arm, expected=None):
    info = identity(path)
    if expected:
        assert info["sha256"] == expected["sha256"] and info["bytes"] == expected["bytes"]
    raw = Path(path).read_bytes()
    if kind == "hidden_bf16":
        value = (np.frombuffer(raw, dtype="<u2").astype(np.uint32) << 16).view(np.float32).astype(np.float64)
        assert value.size == 2048
    else:
        value = np.frombuffer(raw, dtype="<f4").astype(np.float64)
        assert value.size == 248320
    values_per_arm[arm] += int(value.size)
    nonfinite_per_arm[arm] += int(np.count_nonzero(~np.isfinite(value)))
    raw_inventory.append(dict(arm=arm, **info))
    return value
# Relative L2 denominator is always the named reference/right-hand operand.
def compare(a, b):
    delta = a - b
    return dict(max_abs=float(np.max(np.abs(delta))), relative_l2=float(np.linalg.norm(delta) / np.linalg.norm(b)), l2=float(np.linalg.norm(delta)), different_elements=int(np.count_nonzero(a != b)), elements=int(a.size), all_finite=bool(np.isfinite(a).all() and np.isfinite(b).all()))
rows = []
for step in oracle["steps"]:
    position = step["visible_tokens"]
    row = dict(name=step["name"], visible_tokens=position, torch_id=step["next_id"])
    endpoint = next(x for x in original["endpoints"] if x["visible_tokens"] == position)
    row.update(schedule_id=endpoint["schedule_id"], legacy_id=endpoint["legacy_id"])
    for kind, filename in (("hidden_bf16", "hidden.bf16"), ("logits_f32", "logits.f32")):
        old = lookup[position, kind]
        assert old["name"] == step["name"] + "/" + filename
        reference = decode(O / step["name"] / filename, kind, "torch")
        candidate = decode(old["actual"]["path"], kind, "schedule", old["actual"])
        legacy = decode(old["reference"]["path"], kind, "legacy", old["reference"])
        row[kind] = dict(schedule_vs_torch=compare(candidate, reference), legacy_vs_same_chunked_torch=compare(legacy, reference), schedule_vs_legacy=compare(candidate, legacy))
    rows.append(row)
assert all(n == 0 for n in nonfinite_per_arm.values())
aggregates = {}
for window in ("before_second_prompt", "after_second_prompt"):
    selected = [x for x in rows if (x["visible_tokens"] <= 136) == (window == "before_second_prompt")]
    values = {}
    for kind in ("hidden_bf16", "logits_f32"):
        values[kind] = {}
        for pair in ("schedule_vs_torch", "legacy_vs_same_chunked_torch", "schedule_vs_legacy"):
            metric = [x[kind][pair] for x in selected]
            values[kind][pair] = dict(vectors=len(metric), relative_l2_min=min(x["relative_l2"] for x in metric), relative_l2_median=statistics.median(x["relative_l2"] for x in metric), relative_l2_max=max(x["relative_l2"] for x in metric), max_abs=max(x["max_abs"] for x in metric))
    aggregates[window] = values
window_observation = {}
for kind in ("hidden_bf16", "logits_f32"):
    before = aggregates["before_second_prompt"][kind]["schedule_vs_torch"]
    after = aggregates["after_second_prompt"][kind]["schedule_vs_torch"]
    window_observation[kind] = dict(observed_post_relative_l2_range_inside_observed_pre_range=after["relative_l2_min"] >= before["relative_l2_min"] and after["relative_l2_max"] <= before["relative_l2_max"], observed_post_max_abs_not_above_observed_pre_max=after["max_abs"] <= before["max_abs"], interpretation="Descriptive comparison of this finite tape, not a tolerance or significance test.")
report = dict(status="independent_reference_completed_diagnostic_comparison_no_quality_gate", scope="One short schedule: 128 prompt + 8 forced decode + 16 prompt + 15 forced decode, context167/capacity256; compare all hidden/logit elements at the 25 common visible-prefix endpoints.", sources=dict(reference_receipt=identity(O / "reference.json"), reference_execution=identity(R / "execution/result.json"), hyle_prefix_summary=identity(PREFIX / "summary.json"), source=identity(ROOT / "tools/qwen35_text/reference.py"), source_model=dict(path=oracle["model_source"],sha256=oracle["model_source_sha256"]), torch=oracle["torch"], gpu=oracle["gpu"], source_id=oracle["source_id"], text_tensors=oracle["text_tensors"],text_weight_bytes=oracle["text_weight_bytes"]), protocol=dict(reference_uses_hyle_values=False, reference_uses_its_own_original_cache=True, fixed_recurrent_formula_unchanged=True, forced_input_ids=True, model_runs_by_reviewer=0, original_single_schedule_64_vector_check_not_replaced=True, relative_l2_denominator="named reference/right-hand vector", numeric_acceptance_threshold=None), predicted_ids=dict(count=25,all_three_equal=True,torch=oracle["generated_ids"]), finite=dict(vectors_per_arm=50,values_per_arm=values_per_arm,nonfinite_per_arm=nonfinite_per_arm,raw_streams_hashed=150), windows=aggregates,selected_endpoints=[x for x in rows if x["visible_tokens"] in (128,136,152,153,167)],all_endpoints=rows,descriptive_window_observation=window_observation,conclusion=["Torch-vs-Hyle differences already exist before the new second prompt: hidden relative L2 1.0814%-1.4138%, logits 0.9311%-1.6364%. Both Hyle runs are byte-identical to one another there.","After the second prompt, schedule-vs-Torch hidden relative L2 is 1.0334%-1.3162%, logits 0.9733%-1.4978%. The observed post-window relative-L2 maxima remain below their initial-window maxima; these are descriptive ranges, not acceptance thresholds. Logits maxabs nevertheless increases from0.15625 to0.1875 and its relative-L2 median increases from1.13385% to1.21826%; hidden maxabs falls from0.5 to0.25 and its relative-L2 median is approximately1.14949% versus1.14512%. No global improvement is claimed.","At visible136/152/167, schedule-vs-Torch hidden relative L2 is approximately1.1495%/1.1052%/1.2016%, logits1.0098%/1.0821%/1.1737%. At167 legacy-vs-the-same-chunked-Torch hidden/logit is1.4123%/1.5656%; old sequential Hyle is not an exact reference.","All25 argmax IDs match and all18777600 decoded values are finite. This is independent finite numeric evidence; it does not establish mathematical or bitwise equivalence, model quality, or a permissible full-domain error envelope.","The actual same-shape Hyle source/route preservation and this independent same-schedule reference give no observed evidence of a new driver reset. The first divergent layer/operation is not localized; an underlying block/state bug is not proved or exhaustively excluded."],limits=["Only one independent Torch run and one finite teacher-forced short tape; no statistical or quality evaluation.","Legacy after the split is compared to the same chunked Torch cache, not a separately executed sequential Torch cache. Do not treat these metrics as each algorithm's error against its own exact-matching grouping.","Torch uses the original fixed-recurrent forward, eager attention and its own backend arithmetic; it is not a claimed bit-exact implementation of every Hyle low-dtype or fusion boundary.","Long performance remains measurement/regression evidence; no model-quality pass or global tolerance has been inferred."],raw_vector_inventory=raw_inventory)
details = dict(all_endpoints=report.pop("all_endpoints"), raw_vector_inventory=report.pop("raw_vector_inventory"))
(R / "independent-comparison-details.json").write_text(json.dumps(details,indent=2) + "\n",encoding="utf-8")
report["full_details"] = identity(R / "independent-comparison-details.json")
report["analysis_script"] = identity(Path(__file__))
(R / "independent-comparison.json").write_text(json.dumps(report,indent=2) + "\n",encoding="utf-8")
print(json.dumps(dict(report=identity(R / "independent-comparison.json"),ids_equal=True,finite=report["finite"],windows=aggregates),indent=2))
