"""Independent host-only recomputation from raw multi-turn files.

Does not import the runner, change its results, construct a memory sampler,
start a consumer, build, or make a GPU query.
"""
from pathlib import Path
import hashlib
import json
import math
import re
import statistics

S = Path(__file__).resolve().parent
T = S / 'long-timing/attempt1'
M = S / 'long-memory/attempt1'
SOURCES = {}


def identity(path):
    path = Path(path).resolve()
    h = hashlib.sha256(path.read_bytes()).hexdigest()
    return dict(path=str(path), bytes=path.stat().st_size, sha256=h)


def track(path):
    path = Path(path).resolve()
    SOURCES[str(path)] = identity(path)
    return path


def read(path):
    return json.loads(track(path).read_text(encoding='utf-8-sig'))


def text(path):
    return track(path).read_text(encoding='utf-8', errors='replace')


def stats(values):
    assert values
    result = dict(n=len(values), median=statistics.median(values), min=min(values), max=max(values))
    if len(values) <= 3:
        result['samples'] = values
    return result


def same(a, b):
    assert math.isclose(a, b, rel_tol=1e-11, abs_tol=1e-10), (a, b)


def raw_run(folder, arm):
    raw = read(folder / 'peer-result.json') if arm == 'peer' else json.loads(
        next(x for x in reversed(text(folder / 'stdout.log').splitlines()) if x.startswith('{')))
    result = read(folder / 'result.json')
    command = read(folder / 'command.json')
    stderr = text(folder / 'stderr.log')
    assert result['exit'] == 0 and not result.get('timeout') and not result['reader_errors']
    assert result['image'] == command['image']
    assert result['command'][0] == result['image']['path']
    assert result['command'][result['command'].index('--capacity') + 1] == '1024'
    assert raw['processed_tokens'] == 864 and raw['generated_tokens'] == 99
    assert raw['phase_count'] == 6 and raw['turn_count'] == 3
    assert raw['session_seconds'] > 0 and raw['startup_total_seconds'] > raw['session_seconds']
    if arm == 'peer':
        assert raw['context_capacity'] == raw['requested_context_capacity'] == 1024
    steps, pending = [], None
    for line in stderr.splitlines():
        if line.startswith('prepared T='):
            pending = dict(re.findall(r'(\w+)=([^\s]+)', line))
        match = re.match(r'^(round(\d+)_(prefill|decode(\d+))) tokens=', line)
        if match:
            f = dict(re.findall(r'(\w+)=([^\s]+)', line))
            row = dict(name=match[1], turn=int(match[2]), kind='prefill' if match[3] == 'prefill' else 'decode',
                input_tokens=int(f['tokens']), visible=int(f['visible']),
                predicted_id=int(f.get('next', f.get('predicted'))), seconds=float(f['step_seconds']))
            for key in ('seconds', 'submit_seconds'):
                if key in f:
                    row['submit_to_token_seconds' if key == 'seconds' else key] = float(f[key])
            if pending is not None:
                assert int(pending['T']) == row['input_tokens'] and int(pending['visible']) == row['visible']
                row['prepared'] = pending
                pending = None
            steps.append(row)
    assert len(steps) == 99
    ids = raw.get('generated_ids', raw.get('predicted_ids'))
    assert len(ids) == 99 and [x['predicted_id'] for x in steps] == ids
    expected_visible = []
    cursor = 0
    phase_rows = {}
    for index, phase in enumerate(raw['phases']):
        turn = index // 2 + 1
        kind = 'prefill' if index % 2 == 0 else 'decode'
        count = 256 if kind == 'prefill' else 32
        assert phase['turn'] == turn and phase['kind'] == kind and phase['input_tokens'] == count
        assert phase['context_before'] == cursor and phase['context_after'] == cursor + count
        calls = [x for x in steps if x['turn'] == turn and x['kind'] == kind]
        assert len(calls) == (1 if kind == 'prefill' else 32)
        expected_visible.extend([cursor + count] if kind == 'prefill' else range(cursor + 1, cursor + count + 1))
        cursor += count
        assert abs(sum(x['seconds'] for x in calls) - phase['step_sum_seconds']) < 5e-6
        entry = dict(tokens_per_second=count / phase['seconds'], phase_seconds=phase['seconds'],
            phase_step_sum_seconds=phase['step_sum_seconds'],
            within_phase_gap_seconds=phase['seconds'] - phase['step_sum_seconds'])
        if kind == 'decode':
            entry.update(stable_decode7_through32_tokens_per_second=26 / sum(x['seconds'] for x in calls[6:]),
                         first_two_seconds=sum(x['seconds'] for x in calls[:2]))
        if arm == 'hyle':
            entry.update(cold_batch_seconds=sum(float(x['prepared']['cold_batch_seconds']) for x in calls),
                submit_to_token_seconds=sum(x['submit_to_token_seconds'] for x in calls),
                submit_seconds_nested=sum(x['submit_seconds'] for x in calls),
                capture_recorded=sum(int(x['prepared']['capture_recorded']) for x in calls),
                capture_reused=sum(int(x['prepared']['capture_reused']) for x in calls))
        phase_rows[phase['name']] = entry
    assert [x['visible'] for x in steps] == expected_visible and cursor == 864
    loading = dict(raw.get('loading', {}))
    for line in stderr.splitlines():
        if line.startswith('weights_load_seconds='):
            loading['model_load_seconds'] = float(line.split('=', 1)[1])
        elif line.startswith('first_token_elapsed_seconds='):
            loading['first_token_elapsed_seconds'] = float(line.split('=', 1)[1])
        elif line.startswith('initialized '):
            loading.update({k: float(v) for k, v in re.findall(r'(\w+)=([^\s]+)', line)})
    total_phase = sum(x['seconds'] for x in raw['phases'])
    total_step = sum(x['step_sum_seconds'] for x in raw['phases'])
    metrics = dict(session_seconds=raw['session_seconds'], startup_total_seconds=raw['startup_total_seconds'],
        processed_tokens_per_second=864 / raw['session_seconds'], output_tokens_per_second=99 / raw['session_seconds'],
        cold_processed_tokens_per_second=864 / raw['startup_total_seconds'],
        cold_output_tokens_per_second=99 / raw['startup_total_seconds'],
        phase_wall_sum_seconds=total_phase, step_sum_seconds=total_step,
        session_minus_phase_wall_seconds=raw['session_seconds'] - total_phase,
        session_minus_step_sum_seconds=raw['session_seconds'] - total_step,
        after_ready_before_first_input_seconds=raw['startup_total_seconds'] - raw['session_seconds'] - loading['startup_to_ready_seconds'])
    return dict(folder=str(folder), arm=arm, image=result['image'], process_wall_seconds=result['process_wall_seconds'],
        source_session_seconds=raw['session_seconds'], metrics=metrics, phases=phase_rows,
        loading={k: v for k, v in loading.items() if isinstance(v, (int, float))}, ids=ids,
        requested_capacity=1024, peer_actual_capacity=raw.get('context_capacity'),
        planned_replay=re.findall(r'^planned_replay .+$', stderr, re.M))


hyle_ready = read(S / 'hyle/ready-for-root.json')
hyle_source = hyle_ready['source']
assert identity(hyle_source['path']) == hyle_source
track(hyle_source['path'])
timing_config = read(T / 'inputs.json')
published_summary = read(T / 'summary.json')
timing = []
for folder in ('01-hyle', '02-peer', '03-peer', '04-hyle', '05-hyle', '06-peer'):
    timing.append(raw_run(T / folder, folder.split('-', 1)[1]))
assert timing_config['order'] == [x['arm'] for x in timing]
assert hyle_ready['image'] == timing_config['images']['hyle']
assert all(x['image'] == timing_config['images'][x['arm']] for x in timing)
assert not timing_config['memory_monitor'] and not timing_config['profiler']
assert all(x['ids'] == timing[0]['ids'] for x in timing)
groups = {}
for arm in ('hyle', 'peer'):
    runs = [x for x in timing if x['arm'] == arm]
    group = dict(metrics={key: stats([x['metrics'][key] for x in runs]) for key in runs[0]['metrics']},
                 loading={key: stats([x['loading'][key] for x in runs]) for key in runs[0]['loading']}, phases={})
    for name, phase in runs[0]['phases'].items():
        group['phases'][name] = {key: stats([x['phases'][name][key] for x in runs]) for key in phase}
    groups[arm] = group
    for key, values in published_summary['groups'][arm].items():
        mapped = 'step_sum_seconds' if key == 'compute_step_sum_seconds' else key
        same(group['metrics'][mapped]['median'], values['median'])
        same(group['metrics'][mapped]['min'], values['min'])
        same(group['metrics'][mapped]['max'], values['max'])
    for turn in ('1', '2', '3'):
        for kind in ('prefill', 'decode'):
            summary_phase = published_summary['rounds'][arm][turn][kind]
            mine = group['phases'][f'round{turn}_{kind}']
            same(mine['tokens_per_second']['median'], summary_phase['tokens_per_second']['median'])
            same(mine['phase_seconds']['median'], summary_phase['complete_segment_seconds']['median'])


def comparison(key, category='metrics'):
    a, b = groups['hyle'][category][key], groups['peer'][category][key]
    return dict(hyle=a, peer=b, hyle_over_peer=a['median'] / b['median'],
                hyle_change_percent=(a['median'] / b['median'] - 1) * 100)


table = [dict(label='After-load session output TPS (99/session)', units='tokens/s', **comparison('output_tokens_per_second')),
         dict(label='After-load session processed TPS (864/session)', units='tokens/s', **comparison('processed_tokens_per_second')),
         dict(label='After-load session wall', units='seconds', **comparison('session_seconds')),
         dict(label='Cold startup through final endpoint', units='seconds', **comparison('startup_total_seconds'))]
losses = []
for turn in (1, 2, 3):
    for kind in ('prefill', 'decode'):
        name = f'round{turn}_{kind}'
        a, b = groups['hyle']['phases'][name]['tokens_per_second'], groups['peer']['phases'][name]['tokens_per_second']
        seconds_a, seconds_b = groups['hyle']['phases'][name]['phase_seconds'], groups['peer']['phases'][name]['phase_seconds']
        row = dict(label=name + (' P256' if kind == 'prefill' else ' D32'), units='tokens/s', hyle=a, peer=b,
            hyle_change_percent=(a['median'] / b['median'] - 1) * 100,
            hyle_wall_ms={k: seconds_a[k] * 1000 for k in ('median', 'min', 'max')},
            peer_wall_ms={k: seconds_b[k] * 1000 for k in ('median', 'min', 'max')})
        if kind == 'decode':
            row['stable_decode7_through32'] = dict(hyle=groups['hyle']['phases'][name]['stable_decode7_through32_tokens_per_second'],
                peer=groups['peer']['phases'][name]['stable_decode7_through32_tokens_per_second'])
        table.append(row)
        if a['median'] < b['median']:
            losses.append(dict(phase=name, hyle_tps=a, peer_tps=b,
                hyle_tps_change_percent=row['hyle_change_percent'],
                hyle_wall_minus_peer_ms=(seconds_a['median'] - seconds_b['median']) * 1000,
                all_three_hyle_slower_than_all_three_peer=seconds_a['min'] > seconds_b['max'],
                priority='repeatable_prefill_loss' if kind == 'prefill' and seconds_a['min'] > seconds_b['max'] else 'small_overlapping_observation',
                stage_decomposition_hyle={key: groups['hyle']['phases'][name][key] for key in
                    ('cold_batch_seconds', 'submit_to_token_seconds', 'capture_recorded', 'capture_reused')},
                inference='Finite repeatable loss candidate in this window; host/provider/kernel cause not identified by these timers.'))
losses.sort(key=lambda x:x['hyle_tps_change_percent'])

MEM_KEYS = ('working_set_bytes', 'private_commit_bytes', 'gpu_dedicated_bytes', 'gpu_shared_bytes', 'gpu_total_bytes')
mem_config = read(M / 'inputs.json')
old_mem_summary = read(M / 'summary.json')
assert mem_config['requested_memory_interval_seconds'] == 0.01 and mem_config['memory_monitor']
memory = {}
for arm, folder_name in [('hyle', '01-hyle'), ('peer', '02-peer')]:
    folder = M / folder_name
    model = raw_run(folder, arm)
    assert model['ids'] == timing[0]['ids']
    assert model['image'] == next(x['image'] for x in timing if x['arm'] == arm)
    data = read(folder / 'memory.json')
    result = read(folder / 'result.json')
    rows = data['samples']
    running = [x for x in rows if x.get('process_running')]
    assert data['requested_interval_s'] == 0.01
    assert not data['thread_error'] and not result['reader_errors']
    markers = result['markers']
    names = {x['name']: x['timestamp_ns'] for x in markers}
    stderr_markers = re.findall(r'memory_phase=(round\d+_(?:prefill|decode)_(?:begin|end))', text(folder / 'stderr.log'))
    assert stderr_markers == [x['name'] for x in markers if x['name'].startswith('round')]
    missing = {}
    for key in MEM_KEYS:
        valid = [i for i, row in enumerate(rows) if row.get(key) is not None]
        null_indices = [i for i, row in enumerate(rows) if row.get(key) is None]
        missing[key] = dict(total_null=len(null_indices), valid_samples=len(valid),
            initial_null=sum(i < valid[0] for i in null_indices) if valid else len(rows),
            interior_null=sum(valid[0] < i < valid[-1] for i in null_indices) if valid else 0,
            trailing_null=sum(i > valid[-1] for i in null_indices) if valid else 0)
    peaks = {key: max((x[key] for x in rows if x.get(key) is not None), default=None) for key in
             (*MEM_KEYS, 'os_peak_working_set_bytes', 'os_peak_commit_bytes')}
    for raw_key, saved_key in [('working_set_bytes','sampled_max_working_set_bytes'),
        ('private_commit_bytes','sampled_max_private_commit_bytes'),('gpu_dedicated_bytes','sampled_peak_gpu_dedicated_bytes'),
        ('gpu_shared_bytes','sampled_peak_gpu_shared_bytes'),('gpu_total_bytes','sampled_peak_gpu_total_bytes'),
        ('os_peak_working_set_bytes','observed_os_peak_working_set_bytes'),('os_peak_commit_bytes','observed_os_peak_commit_bytes')]:
        assert peaks[raw_key] == data['peaks'][saved_key] == old_mem_summary['arms'][arm]['sampled_peaks'][saved_key]
    gaps = [(b['timestamp_ns'] - a['timestamp_ns']) / 1e6 for a, b in zip(running, running[1:])]
    costs = [x['sample_duration_ns'] / 1e6 for x in running]
    phases = {}
    for turn in (1, 2, 3):
        for kind in ('prefill', 'decode'):
            phase = f'round{turn}_{kind}'
            begin, end = names[phase + '_begin'], names[phase + '_end']
            selected = [x for x in running if begin <= x['timestamp_ns'] <= end]
            before = max((x for x in running if x['timestamp_ns'] <= begin), key=lambda x:x['timestamp_ns'], default=None)
            after = min((x for x in running if x['timestamp_ns'] >= end), key=lambda x:x['timestamp_ns'], default=None)
            next_begin = min((v for key,v in names.items() if key.startswith('round') and key.endswith('_begin') and v > end), default=None)
            previous_end = max((v for key,v in names.items() if key.startswith('round') and key.endswith('_end') and v < begin), default=None)
            def compact(row):
                return dict(timestamp_ns=row['timestamp_ns'], **{key:row.get(key) for key in MEM_KEYS}) if row else None
            deltas = {key: after[key]-before[key] if before and after and before.get(key) is not None and after.get(key) is not None else None for key in MEM_KEYS}
            phases[phase] = dict(parent_marker_span_ms=(end-begin)/1e6,
                interior_samples=len(selected), null_samples={key:sum(x.get(key) is None for x in selected) for key in MEM_KEYS},
                values={key:dict(min=min(v),max=max(v),first=v[0],last=v[-1],n=len(v)) if
                    (v := [x[key] for x in selected if x.get(key) is not None]) else None for key in MEM_KEYS},
                boundary_before=compact(before), boundary_after=compact(after), bracket_delta_bytes=deltas,
                strict_phase_boundary_delta_bytes=None,
                before_sample_overlaps_previous_phase=bool(before and previous_end and before['timestamp_ns'] < previous_end),
                after_sample_overlaps_next_phase=bool(after and next_begin and after['timestamp_ns'] >= next_begin),
                final_after_sample_can_include_deferred_logs_or_context_teardown=next_begin is None,
                bracket_age_ms=dict(before=(begin-before['timestamp_ns'])/1e6 if before else None,
                                    after=(after['timestamp_ns']-end)/1e6 if after else None))
            assert len(selected) == old_mem_summary['arms'][arm]['phase_windows'][phase]['sample_count']
            assert deltas == old_mem_summary['arms'][arm]['phase_windows'][phase]['bracket_delta_bytes']
    ready = [x for x in running if names['ready_before_prefill'] <= x['timestamp_ns'] <= names['round1_prefill_begin']]
    assert (not ready) == old_mem_summary['arms'][arm]['ready_baseline']['unknown']
    reasons = {}
    for row in rows:
        for field in ('gpu_dedicated_unavailable_reason', 'gpu_shared_unavailable_reason'):
            if field in row:
                reason = field + ':' + row[field]
                reasons[reason] = reasons.get(reason, 0) + 1
    memory[arm] = dict(image=model['image'], samples=len(rows), running_samples=len(running),
        requested_interval_ms=10, actual_gap_ms=stats(gaps), collection_cost_ms=stats(costs),
        peaks_bytes=peaks, missing=missing, unavailable_reasons=reasons,
        ready_baseline_available=bool(ready), ready_to_first_prefill_marker_gap_ns=names['round1_prefill_begin']-names['ready_before_prefill'],
        phases=phases, throughput_evidence=False, gpu_setup_error=data['gpu_setup_error'])

hardware = {}
for label, window in [('timing', T), ('memory', M)]:
    hardware[label] = {}
    for side in ('before', 'after'):
        meta = read(window / f'window-{side}.json')
        hardware[label][side] = dict(metadata=meta,
            gpu_csv=text(window / f'window-{side}-gpu.stdout.log').strip(),
            compute_apps_csv=text(window / f'window-{side}-compute_apps.stdout.log').strip())

for ident in list(SOURCES.values()):
    assert identity(ident['path']) == ident, 'Raw input changed during review'

report = dict(schema='hyle.multiturn.independent-measurement-review.v1', date='2026-10-21',
    scope=dict(timing_processes=6, timing_processes_per_arm=3, independent_memory_processes=2,
        GPU_runs_by_reviewer=0, builds_by_reviewer=0, workload='(256P + 32D) x3, one persistent native context, capacity1024',
        processed_tokens=864, returned_generated_tokens=99, M1_decode_calls=96,
        initial_prompt='Original128 prompt IDs repeated twice',
        remaining_inputs='Original31 fixed decode tape repeated; synthetic teacher-forced, not natural conversation',
        precision='Same BF16 source weights and BF16 KV; intermediate arithmetic/greedy transfers differ.'),
    checks=dict(all_eight_processes_exit0=True, all_six_timing_and_two_memory_predictions_99_equal=True,
        phase_contexts=[0,256,288,544,576,832,864], all_timing_capacity_arguments_1024=True,
        peer_runtime_requested_and_actual_capacity_1024=True,
        hyle_capacity_evidence='CLI1024, Model stores selected_capacity directly and uses it for cache Tensor extent/max_kv_rows (main.cc:502-532,594-603,1068); no separate runtime actual-capacity field emitted.',
        original_runner_timing_medians_and_ranges_recomputed_equal=True,
        original_memory_peaks_counts_and_bracket_deltas_recomputed_equal=True,
        raw_sources_unchanged_during_review=True),
    metric_definitions=dict(session='Direct first input preparation -> final selected host token endpoint; includes interphase/control markers; not sum of phase TPS.',
        session_output_TPS='99/session_seconds: 3 prompt-end first tokens + 96 teacher-forced decode call endpoints.',
        session_processed_TPS='864/session_seconds: 768 prompt/append input tokens +96 decode inputs; cached prefix counted once.',
        startup_total='Source run entry -> final host token endpoint; startup_to_ready and model load shown separately, not added twice.',
        phase='Direct first input preparation -> last host token endpoint of this segment.',
        stable_decode='Each round decode7..32:26/sum(the26 complete step timers); supplemental diagnostic, never a replacement for full D32.',
        nested_timers='submit_seconds is contained in submit_to_token_seconds. cold_batch+submit_to_token is a component view, not an additional total.',
        distributions='Per-process rate first, then median/min/max of3 processes. No pooling across old windows, no arithmetic mean of phase rates.'),
    publication_table=table, groups=groups,
    run_records=[{key:value for key,value in x.items() if key not in ('ids','phases')} for x in timing],
    next_truth_loss_candidates=losses,
    independent_memory=memory, hardware_snapshots=hardware,
    limits=['Three timing processes per arm in one ordinary nonexclusive Windows desktop window; no statistical significance/equivalence claim.',
        'Session advantage does not erase round2/round3 prefill losses. No GPU kernel/host causal attribution without separate evidence.',
        'Predicted endpoints equal for this fixed tape; this is not model-quality, arbitrary-context, natural-chat or full-engine acceptance.',
        'Memory processes are separate current-image/same-workload observations,1 per arm; their elapsed times are not throughput samples.',
        '10ms is requested, actual gaps/costs reported. GPU peaks are sampled lower bounds, not exact physical allocations.',
        'Dedicated/shared individual peaks can occur at different timestamps; use simultaneous gpu_total, not their sum.',
        'Phase deltas compare neighboring external samples, with explicit ages, not exact GPU boundary reads or leak attribution.',
        'Neighbor brackets can straddle the previous/next phase. Final peer dedicated delta -2315280384 bytes can include teardown; it is not evidence that the decode segment released that amount.',
        'Ready baseline is unknown where no sample fits between ready and first prefill; null is never filled with zero.',
        'CPU WorkingSet includes mapped/shared pages; private commit and GPU shared overlap, so these are not additive physical memory.',
        'Prior short/long/cached16 and older-image memory observations are not pooled into this window.'],
    sources=list(SOURCES.values()), review_script=identity(__file__))
path = S / 'independent-measurement-review.json'
path.write_text(json.dumps(report, indent=2, allow_nan=False) + '\n', encoding='utf-8')
print(json.dumps(dict(report=identity(path), table=table, memory={arm:dict(samples=x['samples'], peaks=x['peaks_bytes'],
    ready_baseline_available=x['ready_baseline_available']) for arm,x in memory.items()}), indent=2))
