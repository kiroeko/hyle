#include "schedule.h"
#include <iostream>

int main(int argc, char **argv) {
  if (argc != 2) return 2;
  const std::filesystem::path root = argv[1];
  const auto valid = qwen35::benchmark::read_schedule(root / "valid.txt", 248320, 8);
  if (valid.size() != 4 || valid[0].ids.size() != 2 || valid[2].turn != 2 ||
      valid[3].ids[0] != 4 || qwen35::benchmark::phase_name(valid[3], 0) != "round2_decode1") return 3;
  for (const auto *name : {"empty.txt", "bad-order.txt", "incomplete.txt", "overflow.txt", "bad-id.txt", "extra.txt"}) {
    bool rejected = false;
    try { (void)qwen35::benchmark::read_schedule(root / name, 248320, 8); }
    catch (const std::runtime_error &) { rejected = true; }
    if (!rejected) { std::cerr << "accepted " << name << '\n'; return 4; }
  }
  std::cout << "SCHEDULE_VALID_AND_6_INVALID_CASES_PASS\n";
}
