from pathlib import Path
import ast, difflib, hashlib, importlib.util, json, py_compile, sys
ROOT = Path(__file__).resolve().parents[6]
OUT = Path(__file__).resolve().parent
F = OUT.parent
SOURCE = ROOT / "tools/qwen35_text/reference.py"
BEFORE = OUT / "before/reference.py"
py_compile.compile(str(SOURCE), cfile=str(OUT / "reference.pyc"), doraise=True)
spec = importlib.util.spec_from_file_location("schedule_reference_driver", SOURCE)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
checks = []
for name, capacity, expected in [("single", 256, (2, 159, 32)), ("short", 256, (4, 167, 25)), ("long", 1024, (6, 864, 99))]:
    phases = module.read_schedule(F / "inputs" / name / "schedule.txt", 248320, capacity)
    actual = (len(phases), sum(len(x["ids"]) for x in phases), sum(1 if x["kind"] == "prompt" else len(x["ids"]) for x in phases))
    assert actual == expected, (name, actual)
    names = [module.phase_name(x, i) for x in phases for i in range(1 if x["kind"] == "prompt" else len(x["ids"]))]
    assert len(names) == len(set(names))
    checks.append(dict(name=name, phases=actual[0], processed_tokens=actual[1], calls=actual[2], unique_names=True))
short = module.read_schedule(F / "inputs/short/schedule.txt", 248320, 256)
assert [i for x in short[1:] for i in x["ids"]] == list(map(int, (F / "inputs/short/flattened39.ids").read_text().split()))
tests = OUT / "parser-inputs"
tests.mkdir(exist_ok=True)
for name, text in [("one", "1"), ("empty", ""), ("bad", "248320"), ("malformed", "1.0")]:
    (tests / (name + ".ids")).write_text(text)
negative = []
for name, text, capacity in [("first-decode", "decode one.ids\n", 8), ("incomplete", "prompt one.ids\n", 8), ("empty", "prompt empty.ids\ndecode one.ids\n", 8), ("vocab", "prompt bad.ids\ndecode one.ids\n", 8), ("malformed", "prompt malformed.ids\ndecode one.ids\n", 8), ("capacity", "prompt one.ids\ndecode one.ids\n", 1), ("zero-capacity", "prompt one.ids\ndecode one.ids\n", 0)]:
    path = tests / (name + ".txt")
    path.write_text(text)
    try:
        module.read_schedule(path, 248320, capacity)
    except ValueError as error:
        negative.append(dict(name=name, rejected=True, message=str(error)))
    else:
        raise AssertionError(name)
a, b = SOURCE.read_text(), BEFORE.read_text()
start, end = "def fixed_recurrent_forward(", "\ndef main()"
assert a[a.index(start):a.index(end)] == b[b.index(start):b.index(end)]
def main(tree):
    return next(node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name == "main")
old_context = [node for node in main(ast.parse(b)).body if isinstance(node, ast.With)][-1]
new_context = [node for node in main(ast.parse(a)).body if isinstance(node, ast.With)][-1]
assert isinstance(new_context.body[0], ast.If)
normalize = lambda body: ast.dump(ast.Module(body=body, type_ignores=[]), include_attributes=False)
assert normalize(old_context.body) == normalize(new_context.body[0].orelse)
start, end = "        directory = args.output / name", '        raw(directory / "hidden.bf16", captured.pop())'
assert a[a.index(start):a.index(end)+len(end)] == b[b.index(start):b.index(end)+len(end)]
assert "torch" not in sys.modules
identity = lambda path: dict(path=str(path.relative_to(ROOT)), bytes=path.stat().st_size, sha256=hashlib.sha256(path.read_bytes()).hexdigest())
(OUT / "source.diff").write_text("".join(difflib.unified_diff(b.splitlines(True), a.splitlines(True), fromfile="before/reference.py", tofile="tools/qwen35_text/reference.py")), encoding="utf-8")
report = dict(status="static_python_driver_validation_passed_no_model_run", source=identity(SOURCE), before=identity(BEFORE), checks=checks, negative_cases=negative, short_tape_matches_original_39=True, fixed_recurrent_forward_byte_identical=True, legacy_inference_statement_AST_identical=True, evaluate_math_to_hidden_dump_byte_identical=True, torch_imported=False, builds=0, gpu_runs=0, quality_acceptance=False)
(OUT / "static-checks.json").write_text(json.dumps(report, indent=2) + "\n")
print(json.dumps(report, indent=2))
