"""Publish one bounded multi-turn consumer comparison and its unresolved costs."""
from pathlib import Path
import hashlib
import json
import zipfile

S=Path(__file__).resolve().parent
F=S.parent
D=F.parent
R=next(x for x in S.parents if (x/'AGENTS.md').is_file() and (x/'src').is_dir())
E=R/'docs/evidence/performance'
def read(path): return json.loads(path.read_text(encoding='utf-8-sig'))
def ident(path): return dict(path=path.relative_to(R).as_posix(),bytes=path.stat().st_size,
    sha256=hashlib.sha256(path.read_bytes()).hexdigest())
review=read(S/'independent-measurement-review.json')
timing=read(S/'long-timing/attempt1/summary.json')
memory=read(S/'long-memory/attempt1/summary.json')
single=read(S/'validation/single/attempt1/summary.json')
prefix=read(S/'validation/short-prefix/attempt1/summary.json')
oracle=read(S/'reference/independent-comparison.json')
assert single['passed'] and single['vector_count']==64
assert prefix['all_predictions_equal'] and prefix['byte_different_vectors']==32
assert timing['within_arm_predictions_equal']=={'hyle':True,'peer':True} and timing['between_arm_predictions_equal']
assert (S/'cached-prefill-source-review.json').is_file()
sources=[R/p for p in ['tools/qwen35_text/main.cc','tools/qwen35_text/schedule.h',
    'tools/qwen35_text/reference.py','tools/qwen35_text/README.md']]
peer=D/'peer-continuation'
roots=[S,D/'multiturn-consumer/hyle',peer/'multiround']
suffixes={'.json','.log','.py','.cc','.cpp','.h','.txt','.ids','.diff'}
selected=sorted({p for root in roots for p in root.rglob('*')
    if p.is_file() and p.suffix in suffixes and '__pycache__' not in p.parts})
selected += [peer/'peer_benchmark.cpp',*sources]
archive=E/'qwen-multiturn-current-2026-10-21.zip'
assert not archive.exists()
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for path in selected: z.write(path,path.relative_to(R).as_posix())
    z.writestr('manifest.json',json.dumps([ident(x) for x in selected],indent=2))
report=dict(schema='hyle.qwen.multiturn-current.v1',date='2026-10-21',
    status='Shared-schedule comparison complete; two cached-prefill losses remain; D4/goal open',
    implementation='Consumer-only ordered prompt/decode schedule and explicit context capacity. One original cache per arm; no provider/kernel/API change. Per-call diagnostic logs are preallocated and emitted after the last host-token endpoint.',
    source_inventory=[ident(x) for x in sources],
    current_images=dict(hyle=read(S/'hyle/ready-for-root.json')['image'],
        peer=read(peer/'multiround/ready-for-root.json')['image']),
    source_reference_peer_commit='d9e03f1074dbd2979126d91dce1b5d304ec8394e',
    workload=review['scope'],
    context_boundaries=[0,256,288,544,576,832,864],
    primary_metrics=review['publication_table'],
    memory={arm:dict(sampled_peaks=row['sampled_peaks'],
        ready_baseline_unknown=row['ready_baseline']['unknown'],
        phase_sampled_peaks={name:{key:values['max'] for key,values in phase['values'].items()}
            for name,phase in row['phase_windows'].items()},
        requested_interval_ms=10,actual_gap_ms={key:row['actual_sample_gaps_ms'][key] for key in ('median','min','max')},
        strict_phase_boundary_delta=None)
        for arm,row in memory['arms'].items()},
    correctness=dict(single_original_64_vectors_byte_equal=True,
        short25_predictions_equal_across_new_and_old=True,
        short_prefix_vectors_byte_equal=False,short_prefix_changed_vectors=32,
        all_long_99_predictions_equal=True,
        independent_Torch=oracle,
        quality_threshold=None,independent_quality_acceptance=False),
    build=dict(hyle_CXX=1,hyle_links=1,peer_CXX=3,peer_links=3,
        Linux_header_CXX17_parser_cases=7,SDK_rebuilds=0,product_NVCC=0,
        scope='Original reference flags; Hyle strict /W4 /WX /MD /O2. Three peer consumer revisions retain actual first builds and timer-field fix. No CUDA/CPU/native SDK compilation.'),
    observed_costs=dict(second_prefill_cold_prepare_ms=[5.0935,5.1533,5.1242],
        P256_capture_recorded_per_round=[1,0,1],P256_capture_reused_per_round=[0,0,0],
        each_D32_capture_recorded=2,each_D32_capture_reused=30,
        scope='Same counts in all three Hyle timing processes; batches switch shape and visible history. Original FlashInfer reuse proof may require replanning. Actual reuse rejection gate is not yet instrumented.'),
    next_action='One diagnostic consumer compile/run splits batch::prepare from prepare_replay and records the six existing public BatchPlanReports. Determine actual topology/workspace/metadata changes before altering reuse. Tactic tuning follows this concrete preparation issue.',
    limits=[
        'Each arm has3 interleaved fresh timing processes and1 separate memory process; no statistical-significance or stable-winner claim.',
        'Synthetic repeated fixed IDs,3 rounds, actual context grows to864 with capacity1024. Not natural chat or arbitrary long-context validation.',
        'Same original BF16 weights/KV, but intermediate arithmetic and natural sampled-logits transfers differ between engines.',
        'Source session ends at the last host-token endpoint. Internal startup timer begins at Hyle main / peer run entry, not OS process creation; process wall includes DLL startup and teardown and is separate.',
        'GPU sampled peaks are lower bounds. Both ready baselines and strict phase-boundary deltas are unknown. Adjacent samples may cross the next phase or final teardown; do not infer phase allocation changes from them.',
        'Dedicated/shared independent peaks must not be added. The total is the peak of simultaneous values. CPU commit and resident WS remain separate.',
        'No memory observer/profiler/build in the timing window. Desktop GPU use is retained, not exclusive or fixed-clock.',
        '64 same-shape byte regressions and25/99 sampled IDs do not replace independent model quality acceptance. Chunk/sequential vector differences and finite Torch errors are preserved.'
    ],
    independent_review=ident(S/'independent-measurement-review.json'),
    archive={**ident(archive),'members':len(selected)+1},D4_complete=False,goal_complete=False)
out=E/'qwen-multiturn-current-2026-10-21.json'
assert not out.exists()
out.write_text(json.dumps(report,indent=2,ensure_ascii=False,allow_nan=False)+'\n',encoding='utf-8')
cache_source=S/'multi-session-cache-review.json'
cache_report=R/'docs/evidence/research/multi-session-cache-2026-10-21.json'
assert not cache_report.exists()
cache_report.write_bytes(cache_source.read_bytes())
print(json.dumps(dict(report=ident(out),archive=report['archive'],cache_review=ident(cache_report)),indent=2))
