"""Synthetic parser checks only. Does not construct sampler or launch a model."""
import ast
from pathlib import Path
import sys
sys.dont_write_bytecode = True
import multiturn_run as m
import correctness

S = Path(__file__).resolve().parent
for filename in ('multiturn_run.py', 'correctness.py', 'host_check.py'):
    ast.parse((S / filename).read_text(encoding='utf-8'), filename=filename)
inputs = m.prepare_inputs()
assert inputs['plans']['short']['processed_tokens'] == 167
assert inputs['plans']['short']['generated_tokens'] == 25
assert inputs['plans']['long']['processed_tokens'] == 864
assert inputs['plans']['long']['generated_tokens'] == 99
correctness.inputs()
folder = S / 'host-checks/synthetic'
folder.mkdir(parents=True, exist_ok=True)
plan = inputs['plans']['short']
phases, log, predictions = [], [], []
step_sum = 0.0
for phase in plan['phases']:
    count = phase['calls']
    times = [float(i + 1) / 100 for i in range(count)]
    for i, seconds in enumerate(times):
        name = phase['name'] if phase['kind'] == 'prefill' else phase['name'] + str(i + 1)
        visible = phase['visible_tokens'] if phase['kind'] == 'prefill' else phase['visible_before'] + i + 1
        token = visible + 10
        predictions.append(token)
        log.append(f'{name} tokens={phase["input_tokens"] if phase["kind"] == "prefill" else 1} '
                   f'visible={visible} seconds={seconds/2} submit_seconds=0.001 step_seconds={seconds} next={token}')
    phases.append(dict(turn=phase['turn'], kind=phase['kind'], name=phase['name'],
        input_tokens=phase['input_tokens'], context_before=phase['visible_before'],
        context_after=phase['visible_tokens'], seconds=sum(times) + 0.001, step_sum_seconds=sum(times)))
    step_sum += sum(times)
raw = dict(processed_tokens=167, generated_tokens=25, phase_count=4, turn_count=2,
    session_seconds=step_sum + 0.01, startup_total_seconds=step_sum + 1,
    generated_ids=predictions, phases=phases)
m.save(folder / 'raw.json', raw)
(folder / 'stdout.log').write_text(m.json.dumps(raw) + '\n', encoding='utf-8')
(folder / 'stderr.log').write_text('\n'.join(log) + '\n', encoding='utf-8')
parsed = m.parse_observation(folder, 'hyle', plan)
assert len(parsed['steps']) == 25
assert abs(parsed['rounds']['1']['decode']['stable_decode_seconds'] - (0.07 + 0.08)) < 1e-12
assert abs(parsed['metrics']['processed_tokens_per_second'] - 167 / raw['session_seconds']) < 1e-12
peer_folder = S / 'host-checks/synthetic-peer'
peer_folder.mkdir(parents=True, exist_ok=True)
peer_raw = dict(raw)
peer_raw['predicted_ids'] = peer_raw.pop('generated_ids')
m.save(peer_folder / 'peer-result.json', peer_raw)
(peer_folder / 'stderr.log').write_text('\n'.join(log).replace('next=', 'predicted=') + '\n', encoding='utf-8')
peer_parsed = m.parse_observation(peer_folder, 'peer', plan)
assert peer_parsed['predicted_ids'] == parsed['predicted_ids']
assert m.marker('memory_phase=round2_decode_end') == 'round2_decode_end'
assert m.marker('measure_memory name=inference_complete') == 'inference_complete'
sampled = dict(samples=[dict(timestamp_ns=10, process_running=True,
    working_set_bytes=100, private_commit_bytes=200, gpu_dedicated_bytes=None,
    gpu_shared_bytes=None, gpu_total_bytes=None,
    gpu_dedicated_unavailable_reason='no_pid_instance')],
    peaks={}, gpu_setup_error=None, thread_error=None)
record = dict(markers=[dict(name='round1_prefill_begin', timestamp_ns=11),
                       dict(name='round1_prefill_end', timestamp_ns=12)])
memory = m.memory_summary(sampled, record)
assert memory['phase_windows']['round1_prefill']['sample_count'] == 0
assert memory['phase_windows']['round1_prefill']['bracket_delta_bytes']['gpu_dedicated_bytes'] is None
assert memory['ready_baseline']['unknown']
result = dict(schema='hyle.multiturn.synthetic-host-check.v1', passed=True,
    builds=0, GPU_runs=0, model_processes=0, sampler_instances=0,
    parsed_steps=len(parsed['steps']), input_counts=dict(short=[167,25], long=[864,99]),
    checks=['Python syntax', 'Original prompt/decode exact IDs', 'Text schedule/capacity accounting',
        'Final phase JSON contract without redundant fields', 'Per-round stable decode7..end',
        'Hyle next= and peer predicted= step records',
        'Count divided by source session timer', 'Phase marker/legacy snapshot parsing',
        'Missing memory bracket stays null; no-sample ready baseline unknown'],
    sources=[m.identity(S / x) for x in ('multiturn_run.py', 'correctness.py', 'host_check.py')])
m.save(S / 'host-checks/result.json', result)
print('SYNTHETIC_HOST_CHECKS_PASS: 0 model processes, 0 sampler instances')
