"""One consumer CXX compile/link against the current retained190-input closure."""
from pathlib import Path
import argparse
import importlib.util
import os
import sys

sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent
F=S.parent
D=F.parent
R=next(x for x in S.parents if (x/'AGENTS.md').is_file() and (x/'src').is_dir())
spec=importlib.util.spec_from_file_location('multiturn_original_build_helpers',D/'build.py')
h=importlib.util.module_from_spec(spec)
spec.loader.exec_module(h)
b,c=h.b,h.c
def same(row):
    return all(b.identity(row['path'])[k]==row[k] for k in ('bytes','sha256'))

def main():
    p=argparse.ArgumentParser()
    p.add_argument('--attempt',default='attempt1')
    args=p.parse_args()
    out=S/'hyle/checks'/args.attempt
    out.mkdir(parents=True,exist_ok=False)
    (out/'tmp').mkdir()
    recipe_path=D/'auto-replay-policy/checks/attempt1/identity.json'
    recipe=c.read(recipe_path)
    source=R/'tools/qwen35_text/main.cc'
    frozen=b.identity(source)
    header=b.identity(R/'tools/qwen35_text/schedule.h')
    command=b.host_command(recipe['command'],source,'main',out)
    assert all(x in command for x in ['/WX','/W4','/MD','/O2'])
    c.save(out/'compile-plan.json',dict(command=command,source=frozen,header=header,
        recipe=b.identity(recipe_path),CXX=1,SDK_builds=0,GPU_runs=0))
    env,_=b.environment(command,[],out)
    c.execute('compile',command,env,out)
    deps=c.read(out/'main-deps.json')['Data']
    dependencies=[b.identity(x) for x in dict.fromkeys([deps['Source'],*deps['Includes']])]
    assert same(frozen) and same(header) and all(same(x) for x in dependencies)
    assert any(c.key(x['path'])==c.key(header['path']) for x in dependencies)
    obj=b.identity(out/'main.obj')
    c.save(out/'identity.json',dict(command=command,source=frozen,header=header,object=obj,
        dependencies=dependencies,replaced_object=recipe['object'],CXX=1,SDK_builds=0,GPU_runs=0))
    for path in [source,R/'tools/qwen35_text/schedule.h']:
        snapshot=out/'source'/path.relative_to(R)
        snapshot.parent.mkdir(parents=True,exist_ok=True)
        snapshot.write_bytes(path.read_bytes())
    base_path=F/'native-fix/checks/attempt1/link/link-plan.json'
    base=c.read(base_path)
    assert len(base['inputs'])==190 and all(same(x) for x in base['inputs'])
    old=c.key(recipe['object']['path'])
    assert sum(c.key(x['path'])==old for x in base['inputs'])==1
    inputs=[obj if c.key(x['path'])==old else x for x in base['inputs']]
    image=out/'qwen.exe'
    link=[obj['path'] if c.key(x)==old else x for x in base['command']
        if not x.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:'))]
    link+=['/OUT:'+str(image),'/MAP:'+str(image.with_suffix('.map')),'/IMPLIB:'+str(image.with_suffix('.lib'))]
    c.save(out/'link-plan.json',dict(command=link,inputs=inputs,base=b.identity(base_path),
        CXX=1,links=1,NVCC=0,SDK_builds=0,GPU_runs=0))
    env,runtime=b.environment(link,[x['path'] for x in inputs],out)
    c.execute('link',link,env,out)
    original=next((F/'native-fix/checks/attempt1/link').glob('hyle_ggml_cpu_avx2_*.dll'))
    target=out/original.name
    os.link(original,target)
    assert os.path.samefile(original,target)
    c.save(out/'runtime-environment.json',dict(PATH=env['PATH'],runtime=runtime,
        staged_CPU_modules=[dict(source=b.identity(original),destination=b.identity(target),hardlink=True)]))
    c.save(S/'hyle/ready-for-root.json',dict(image=b.identity(image),source=frozen,header=header,
        link_plan=b.identity(out/'link-plan.json'),runtime_environment=b.identity(out/'runtime-environment.json'),
        CXX=1,links=1,NVCC=0,SDK_builds=0,GPU_runs=0))
    print('MULTITURN_HYLE_READY',image,flush=True)

if __name__=='__main__': main()
