"""One small C++17 parser check on the retained Linux toolchain; no SDK/GPU."""
from pathlib import Path
import hashlib
import json
import subprocess

P=Path(__file__).resolve().parent
R=next(x for x in P.parents if (x/'AGENTS.md').is_file() and (x/'src').is_dir())
assert str(R).startswith('/mnt/c/')
out=Path('/root/hyle-scratch/active-cpu-z/d4-multiturn-parser-2026-10-21')
out.mkdir(parents=True,exist_ok=False)
data=out/'data'
data.mkdir()
files={'a ids.txt':'1 2\n','b.ids':'3\n','c.ids':'4\n','invalid.ids':'9223372036854775808\n',
       'valid.txt':'# quoted path and two complete turns\nprompt "a ids.txt"\ndecode b.ids\nprompt b.ids\ndecode c.ids\n',
       'empty.txt':'# no inputs\n','bad-order.txt':'decode b.ids\n',
       'incomplete.txt':'prompt b.ids\n','overflow.txt':'prompt "a ids.txt"\ndecode "a ids.txt"\nprompt "a ids.txt"\ndecode "a ids.txt"\nprompt b.ids\ndecode b.ids\n',
       'bad-id.txt':'prompt invalid.ids\ndecode b.ids\n','extra.txt':'prompt b.ids unexpected\ndecode c.ids\n'}
for name,text in files.items(): (data/name).write_text(text)
commands=[['g++','-std=c++17','-O2','-Wall','-Wextra','-Werror','-I'+str(R/'tools/qwen35_text'),str(P/'parser_check.cc'),'-o',str(out/'parser')],
          [str(out/'parser'),str(data)]]
runs=[]
for tag,command in zip(['compile','run'],commands):
    result=subprocess.run(command,cwd=out,capture_output=True,text=True,timeout=60)
    (P/(tag+'.stdout.log')).write_text(result.stdout)
    (P/(tag+'.stderr.log')).write_text(result.stderr)
    runs.append(dict(command=command,exit_code=result.returncode))
    (P/'parser-result.json').write_text(json.dumps(dict(runs=runs,header_sha256=hashlib.sha256((R/'tools/qwen35_text/schedule.h').read_bytes()).hexdigest(),SDK_builds=0,GPU_runs=0),indent=2))
    print(tag,result.returncode,flush=True)
    assert result.returncode==0, result.stderr
