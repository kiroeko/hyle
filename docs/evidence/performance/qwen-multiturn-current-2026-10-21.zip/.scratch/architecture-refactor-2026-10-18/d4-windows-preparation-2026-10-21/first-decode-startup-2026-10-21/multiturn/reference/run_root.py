"""One root-owned independent reference journey, never a speed measurement."""
from pathlib import Path
import hashlib
import json
import subprocess
import time

P=Path(__file__).resolve().parent
R=next(x for x in P.parents if (x/'AGENTS.md').is_file() and (x/'src').is_dir())
ready=json.loads((P/'ready-for-root.json').read_text())
source=R/ready['source']['path']
assert source.stat().st_size==ready['source']['bytes']
assert hashlib.sha256(source.read_bytes()).hexdigest()==ready['source']['sha256']
assert not Path(ready['command'][ready['command'].index('--output')+1]).exists()
out=P/'execution'
out.mkdir(exist_ok=False)
record=dict(command=ready['command'],source=ready['source'],started=time.time(),
    execution_owner='root',model_runs=1,throughput_evidence=False,quality_threshold=None)
(out/'command.json').write_text(json.dumps(record,indent=2))
with (out/'stdout.log').open('w') as so,(out/'stderr.log').open('w') as se:
    child=subprocess.Popen(record['command'],cwd=R,stdout=so,stderr=se,
                           creationflags=subprocess.CREATE_NO_WINDOW)
    record['pid']=child.pid
    (out/'live.json').write_text(json.dumps(record,indent=2))
    try:
        code=child.wait(timeout=300)
        record['timeout']=False
    except subprocess.TimeoutExpired:
        child.kill()
        code=child.wait()
        record['timeout']=True
record.update(exit=code,finished=time.time(),terminal=True)
(out/'result.json').write_text(json.dumps(record,indent=2))
print('INDEPENDENT_REFERENCE_EXIT',code,flush=True)
print((out/'stdout.log').read_text()[-1200:],flush=True)
if code: print((out/'stderr.log').read_text()[-3000:],flush=True)
raise SystemExit(code if code>=0 else 1)
