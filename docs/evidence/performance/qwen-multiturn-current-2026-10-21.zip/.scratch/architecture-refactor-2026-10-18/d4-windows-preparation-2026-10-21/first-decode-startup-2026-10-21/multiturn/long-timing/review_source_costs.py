"""Read existing unprofiled logs and source identities; never execute a model."""
import hashlib
import json
import re
import statistics
from pathlib import Path

ROOT = Path(__file__).resolve().parents[6]
HERE = Path(__file__).resolve().parent
DATA = HERE / 'attempt1'


def identity(path):
    path = Path(path)
    raw = path.read_bytes()
    return {'path': path.relative_to(ROOT).as_posix(), 'bytes': len(raw),
            'sha256': hashlib.sha256(raw).hexdigest()}


def fields(line):
    return dict(re.findall(r'([\w]+)=([^ ]+)', line))


def hyle(name):
    folder = DATA / name
    lines = (folder / 'stderr.log').read_text().splitlines()
    calls = []
    previous = None
    for number, line in enumerate(lines, 1):
        if line.startswith('prepared T='):
            previous = (number, fields(line))
        elif re.match(r'round\d+_(prefill|decode\d+) tokens=', line):
            assert previous
            n, prep = previous
            vals = fields(line)
            phase_name = line.split()[0]
            calls.append({'name': phase_name,
                          'turn': int(re.search(r'round(\d+)', phase_name)[1]),
                          'kind': 'prefill' if 'prefill' in phase_name else 'decode',
                          'stderr_lines': [n, number],
                          'input_tokens': int(vals['tokens']),
                          'visible': int(vals['visible']),
                          'replay': prep['replay'],
                          'capture_recorded': int(prep['capture_recorded']),
                          'capture_reused': int(prep['capture_reused']),
                          'cold_prepare_combined_seconds': float(prep['cold_batch_seconds']),
                          'submit_to_host_token_seconds': float(vals['seconds']),
                          'submit_call_seconds_subset': float(vals['submit_seconds']),
                          'step_seconds': float(vals['step_seconds'])})
            previous = None
    assert len(calls) == 99
    prefill = [x for x in calls if x['kind'] == 'prefill']
    assert len(prefill) == 3
    decodes = []
    for turn in range(1, 4):
        part = [x for x in calls if x['turn'] == turn and x['kind'] == 'decode']
        assert len(part) == 32
        decodes.append({'turn': turn, 'calls': len(part),
                        'capture_recorded': sum(x['capture_recorded'] for x in part),
                        'capture_reused': sum(x['capture_reused'] for x in part),
                        'first_two_calls': part[:2]})
    result = json.loads((folder / 'stdout.log').read_text())
    assert result['processed_tokens'] == 864 and result['generated_tokens'] == 99
    return {'process': name, 'planned_modes': [
        {'stderr_line': i, 'text': line} for i, line in enumerate(lines, 1)
        if line.startswith('planned_replay ')], 'prefills': prefill,
        'decode_phases': decodes,
        'input_files': [identity(folder / f) for f in ('stderr.log', 'stdout.log', 'result.json')]}, result['generated_ids']


def peer(name):
    folder = DATA / name
    result = json.loads((folder / 'peer-result.json').read_text())
    lines = (folder / 'stderr.log').read_text().splitlines()
    prefill = []
    for step in result['steps']:
        if step['kind'] != 'prefill':
            continue
        label = step['name']
        begin = next(i for i, s in enumerate(lines) if s == 'memory_phase=' + label + '_begin')
        end = next(i for i, s in enumerate(lines[begin + 1:], begin + 1)
                   if s == 'memory_phase=' + label + '_end')
        prefill.append({**step, 'phase_native_messages': [
            {'stderr_line': i + 1, 'text': lines[i]} for i in range(begin, end + 1)]})
    assert len(prefill) == 3
    return {'process': name, 'prefills': prefill,
            'input_files': [identity(folder / f) for f in ('stderr.log', 'peer-result.json', 'result.json')]}, result['predicted_ids']


def source(path, ranges, fact):
    return {**identity(ROOT / path), 'line_ranges': ranges, 'fact': fact}


def main():
    hs, ps, ids = [], [], []
    for name in ('01-hyle', '04-hyle', '05-hyle'):
        row, predicted = hyle(name)
        hs.append(row)
        ids.append(predicted)
    for name in ('02-peer', '03-peer', '06-peer'):
        row, predicted = peer(name)
        ps.append(row)
        ids.append(predicted)
    assert all(x == ids[0] for x in ids) and len(ids[0]) == 99
    means = []
    for index in range(3):
        h = [x['prefills'][index] for x in hs]
        p = [x['prefills'][index] for x in ps]
        mean = lambda rows, key: statistics.mean(x[key] for x in rows)
        full_h, full_p = mean(h, 'step_seconds'), mean(p, 'step_seconds')
        cold = mean(h, 'cold_prepare_combined_seconds')
        post = mean(h, 'submit_to_host_token_seconds')
        means.append({'turn': index + 1, 'hyle_step_seconds': full_h,
                      'peer_step_seconds': full_p, 'difference_seconds': full_h - full_p,
                      'hyle_combined_cold_seconds': cold,
                      'hyle_submit_to_host_token_seconds': post,
                      'hyle_post_minus_peer_full_seconds': post - full_p,
                      'hyle_input_control_remainder_seconds': full_h - cold - post,
                      'peer_decode_call_return_seconds': mean(p, 'decode_return_seconds'),
                      'peer_explicit_synchronize_seconds': mean(p, 'synchronize_seconds')})
    report = {
        'schema': 'hyle.multiturn.prefill-source-cost-review.v1',
        'scope': 'Read existing three-process-per-arm unprofiled logs and current source only; no build, GPU, new trace, product edits or SDK changes.',
        'script': identity(__file__), 'data_directory': DATA.relative_to(ROOT).as_posix(),
        'matched_predictions': {'processes': 6, 'ids_per_process': 99, 'all_equal': True},
        'hyle': hs, 'peer': ps, 'per_turn_arithmetic_means': means,
        'established': [
            'All three Hyle P2 calls are Commands; T256 slot1 is planned for one use.',
            'All three Hyle P3 calls record one capture range and reuse zero. PreferCapture selects a policy, not a guarantee that a previous artifact remains valid.',
            'Each D32 phase in every Hyle process records two ranges and reuses thirty: the first two T1 slot uses after each prefill re-record.',
            'P2 mean Hyle-minus-peer step wall is 5.043 ms; Hyle combined cold preparation is 5.124 ms. After that cold bucket, Hyle submit-to-host-token wall is 0.112 ms below peer full P2 step wall. The observed regression is concentrated in cold preparation, not established as GPU throughput loss.',
            'P3 is also a new recording, with mean 3.823 ms combined cold wall. This does not quantify separately native batch planning versus outer capture/instantiate.',
            'Peer P2/P3 log CUDA graph warmup reset. Its retained native source explicitly leaves use_cuda_graph=false on that branch, so the source-backed interpretation is direct execution for those calls; there is no new API trace count.',
        ],
        'minimal_source_attribution': [
            'There is no schema-global shared device mirror implied by Family.attention_schema. The existing graph/native BatchInvocation owns retained metadata mirrors and high-water workspaces per exact child/slot; the six attention regions share the first metadata owner within that invocation.',
            'FI can_reuse_batch_plan requires unchanged query partition and, for changed KV lengths, unchanged ceil(KV length / original kv_chunk_rows) for every active request. A fresh native plan can change tile-index arrays, padded grid and merge offsets even when workspace addresses stay fixed.',
            'Native plan nonreuse, workspace growth, or metadata physical-carrier replacement invokes the existing before-change gate before resource mutation; its callback invalidates the affected attention step and dependent metadata consumers.',
            'Graph invalidates only the retained captured range covering that step, not blindly every independent range. A range containing otherwise unchanged GDN/GEMM steps must still be discarded if it includes a changed attention step.',
            'No existing long-timing file contains actual BatchPlanReport, KV chunk rows, plan signature, or invalidation-reason records. Which gate fired in these runs remains unproven; do not relax validity or add a new cache based on buffer-address guesses.'
        ],
        'available_without_new_public_api': {
            'existing_report': 'graph::batch::report(invocation, attention_node)',
            'fields': ['layout_generation', 'metadata_staging_bytes', 'float_workspace_bytes',
                       'int_workspace_bytes', 'cta_tile_q', 'padded_batch_size', 'split_kv',
                       'bf16_partials', 'reused_native_plan', 'host_waits', 'metadata_upload'],
            'not_available': ['plan_signature', 'kv_chunk_rows', 'exact invalidation reason'],
            'existing_logs_sufficient_to_reconstruct_report': False,
            'native_report_warning': 'graph::batch::native_report is the delegated paged report and is not the FlashInfer shared-native report needed here.'
        },
        'next_minimal_root_action': {
            'first': 'One diagnostic consumer TU, same finite session: measure batch::prepare and Invocation::prepare_replay separately. Preallocate per-call/per-six-attention report records and collect the existing batch::report after preparation; print only after final host-token endpoint. Do not add CUDA queries, syncs, warmup, math or replay-policy changes.',
            'interpretation': [
                'reused_native_plan=false plus batch_prepare wall identifies actual original native replan cost; report host_waits includes metadata transfer waits plus one native planning-retirement wait on nonreuse.',
                'If plans reuse but capture is rerecorded, the report alone does not prove physical bindings unchanged: use a narrowly scoped diagnostic copy of the existing before-change/storage gates to record reason and resource/handle/offset/size identity, not a new public cache contract.',
                'Only if required, record original FI kv_chunk_rows and old/new chunk counts from its private slot in a validation-only hook; the public report does not expose them.',
                'If a needed attention topology change invalidates a larger capture, investigate original capture partition granularity after actual cause proof. No proposed permission relaxation, alias inference, shared independent-invocation state, or numerical substitution.'
            ],
            'full_99_call_node_trace_needed_now': False,
            'limits': 'Extra diagnostic timer/report overhead must be identified. Do not treat the entire measured cold bucket or capture API sum as recoverable benefit.'
        },
        'source_anchors': [
            source('tools/qwen35_text/main.cc', [[573,604],[811,847],[865,920]], 'Known ordered exact-child/global-parity planning; fixed caller bindings; existing cold timer combines layout version, batch preparation, replay preparation and replay report.'),
            source('src/graph_batch/batch.cc', [[319,327],[394,397],[415,424],[465,496],[506,517],[611,637],[782,819],[870,936],[1009,1011]], 'Original per-invocation metadata ownership, reuse qualification, dependent before-change invalidation, retained shared native reports and public report entry.'),
            source('src/compute_batch/batch_execution.cc', [[128,163],[430,469],[521,539],[802,804],[819,824]], 'Original native plan/workspace/mirror high-water reuse; exact physical metadata check; nonreuse invalidation before original planning and wait; report semantics.'),
            source('src/compute_provider_flashinfer/flashinfer_provider.cc', [[234,283],[293,335],[382,397]], 'Original chunk-count-preserving native update proof; failure forces original plan; capture compatibility does not promise all layouts share topology.'),
            source('src/compute_provider_flashinfer/native_batch.cu', [[17,35],[38,53]], 'Actual planner materializes original kv_chunk_rows; dispatch/temporary/merge tile parameters come from native plan.'),
            source('include/hyle/compute/batch_execution.h', [[25,37]], 'Current public report has no plan_signature or kv_chunk_rows.'),
            source('src/graph/executable.cc', [[1060,1100],[1213,1279],[7873,7900],[9158,9173],[9434,9444]], 'Dormant capture retention, stable physical bindings gate, affected-range invalidation and exact retained-range reuse.'),
            source('src/graph/resources.cc', [[245,302]], 'Configuration reset preserves caller owners and can preserve proven physical spans; permission/readiness must be renewed.'),
            source('.scratch/legacy-root/hyle-scratch/ggml-native-static/src/compute_ggml_runtime/source-4e1a7b2f39afe15d/src/ggml-cuda/ggml-cuda.cu', [[4463,4513]], 'Retained native peer source: warmup reset leaves graph disabled for that call.'),
        ],
        'claims_not_made': ['Actual FI chunk threshold values in these processes', 'Physical allocation counts or a metadata reallocation', 'Capture API costs fully recoverable', 'Significant throughput change from three process means', 'Entire-model or multi-session cache support']
    }
    target = HERE.parent / 'cached-prefill-source-review.json'
    target.write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps(identity(target), indent=2))
    print(json.dumps(means, indent=2))


if __name__ == '__main__':
    main()
