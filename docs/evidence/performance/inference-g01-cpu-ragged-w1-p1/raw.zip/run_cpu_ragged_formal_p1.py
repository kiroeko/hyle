from pathlib import Path
import subprocess,os,json,time
canonical=Path.cwd();out=canonical/'.scratch/inference-gaps/g01'
repo=Path('C:/h7/g01-ragged-p1-source');build=Path('C:/h7/g01-ragged-p1-fresh-1');evidence=out/'cpu-ragged-p1-qualification-1'
assert not build.exists() and not evidence.exists(),'preserve all previous attempts'
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
if not repo.exists():
 subprocess.run(['git','clone','--shared','--no-checkout',str(canonical),str(repo)],check=True)
 subprocess.run(['git','-C',str(repo),'checkout','--detach',head],check=True)
assert subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip()==head
assert not subprocess.check_output(['git','-C',str(repo),'status','--porcelain'],text=True).strip(),'qualified source must be clean'
candidate='973d3ffbf642aff06f6316fcec4b3cc99eba2e4d'
for name in ['src/compute_provider_ggml/native_batch.cc','src/compute_provider_ggml/ggml_cpu_provider.cc','include/hyle/compute/providers/ggml_cpu.h','cmake/HyleComponents.cmake','src/graph_batch/batch.cc']:
 assert subprocess.check_output(['git','-C',str(repo),'show',candidate+':'+name])==(repo/name).read_bytes(),name
env=os.environ.copy()
for line in subprocess.check_output(['cmd','/d','/c',str(out/'cpu-ragged-env.cmd')],text=True).splitlines():
 if '=' in line and not line.startswith('='):
  k,v=line.split('=',1);env[k]=v
source=repo/'bench/inference_resident_sdpa/cpu_ragged_p1';peer=out/'original-ggml-cpu-peer'
assert subprocess.check_output(['git','-C',str(peer),'rev-parse','HEAD'],text=True).strip()=='ffa4e8b80930029a35991f94e7c8a93cd67730ab'
assert not subprocess.check_output(['git','-C',str(peer),'status','--porcelain'],text=True).strip()
args=['python',str(repo/'scripts/hyle-perf.py'),'qualify-platform','--contract',str(source/'contract.json'),'--source',str(source),'--machine','W1-WIN','--peer','original-ggml-cpu-flash='+str(peer),'--build',str(build),'--output',str(evidence)]
log=out/'cpu-ragged-p1-qualification-1.log';start=time.monotonic()
with log.open('w',encoding='utf-8') as f:
 process=subprocess.Popen(args,env=env,stdout=f,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NO_WINDOW)
 status={'pid':process.pid,'command':args,'state':'RUNNING','cpu_product_candidate':candidate,'graph_batch_candidate':'a0c047ea45cb46884da7f578684ff416ccfdefa5','source_commit':head,'log':str(log)}
 (out/'cpu-ragged-p1-job-1.json').write_text(json.dumps(status,indent=2)+'\n');print(json.dumps(status),flush=True)
 code=process.wait()
status.update(state='TERMINAL',exit_code=code,elapsed_seconds=time.monotonic()-start)
(out/'cpu-ragged-p1-job-1.json').write_text(json.dumps(status,indent=2)+'\n');print(json.dumps(status),flush=True)
with log.open('rb') as f:f.seek(max(0,log.stat().st_size-2400));print(f.read(2400).decode(errors='replace'))
raise SystemExit(code)
