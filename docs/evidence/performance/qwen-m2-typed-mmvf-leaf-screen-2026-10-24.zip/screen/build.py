"""Explicit two-TU leaf actions; reuse original inputs and process helpers."""
from pathlib import Path
import argparse, hashlib, importlib.util, json, os, sys
sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('_old_m2_leaf', S.parent / 'm2-down-leaf-proposal/build.py')
b = importlib.util.module_from_spec(spec); spec.loader.exec_module(b)
R = b.R
N = R / '.scratch/architecture-refactor-2026-10-18/paired-projection-route'
RECIPE = N / 'checks/native1/mmvf-compile.command.json'
KERNEL = N / 'native-source/src/ggml-cuda/mmvf.cuh'
RANGE_SHA = 'fbafb4be6b6a3e93fb969b1679f7430a824cd912db98a83a7c4b9658e511d766'


def prepare(attempt):
    prior_path, prior = b.checked(2)
    if b.identity(KERNEL)['sha256'] != 'b579560db787fd1df1b67d9c2b631197670e25d5071be35facc46ccf9c20a604':
        raise ValueError('Original owning MMVF body differs')
    sources = {k: b.identity(S / v) for k, v in [('host', 'm2_typed_leaf.cc'), ('native', 'typed_mmvf_m2.cu')]}
    old_text = Path(prior['source']['path']).read_text(encoding='utf-8')
    new_text = Path(sources['host']['path']).read_text(encoding='utf-8')
    a, z = 'double gamma(', '\nstruct Device {'
    if old_text[old_text.index(a):old_text.index(z)] != new_text[new_text.index(a):new_text.index(z)]:
        raise ValueError('Original fixed independent mathematical gate changed')
    host = list(prior['compile_command']); host_dir = S / f'host{attempt}'; native_dir = S / f'native{attempt}'
    host[host.index('/sourceDependencies') + 1] = str(host_dir / 'dependencies.json')
    for i, arg in enumerate(host):
        if arg == prior['source']['path']: host[i] = sources['host']['path']
        elif arg.startswith('/Fo'): host[i] = '/Fo' + str(host_dir / 'probe.obj')
        elif arg.startswith('/Fd'): host[i] = '/Fd' + str(host_dir / 'probe.pdb')
    native = list(b.read(RECIPE)['command'])
    for option, value in [('-MT', native_dir / 'typed.obj'), ('-MF', native_dir / 'typed.d'),
                           ('-c', sources['native']['path']), ('-o', native_dir / 'typed.obj')]:
        if native.count(option) != 1: raise ValueError('Original native recipe option not unique: ' + option)
        native[native.index(option) + 1] = str(value)
    pdb = [i for i, x in enumerate(native) if x.startswith('-Xcompiler=-Fd')]
    if len(pdb) != 1: raise ValueError('Original native PDB option not unique')
    native[pdb[0]] = '-Xcompiler=-Fd' + str(native_dir / 'typed.pdb') + ',-FS'
    original_link = b.read(prior['actual_current_link']['path'])['command']
    cudart = [x for x in original_link if Path(x).name.lower() == 'cudart.lib']
    if len(cudart) != 1: raise ValueError('Actual CUDA runtime import library missing')
    libraries = [*prior['libraries'], b.identity(cudart[0])]
    image = S / f'link{attempt}/typed-mmvf-m2.exe'
    link = [original_link[0], '/NOLOGO', '/MACHINE:X64', '/SUBSYSTEM:CONSOLE',
            str(host_dir / 'probe.obj'), str(native_dir / 'typed.obj'), *[x['path'] for x in libraries],
            '/OUT:' + str(image), '/MAP:' + str(image.with_suffix('.map'))]
    value = dict(tool=b.identity(__file__), sources=sources, original_leaf_plan=b.identity(prior_path),
                 owning_kernel=b.identity(KERNEL), native_recipe=b.identity(RECIPE), libraries=libraries,
                 host=host, native=native, link=link, run=[str(image), *prior['native_command'][1:]],
                 scope='Only original request1 Lt versus one whole-M2 typed MMVF. Same original W/first2 real T23 A rows/fixed gate/4banks/64serial/5 interleaved trials. No model performance claim.')
    p = S / f'commands{attempt}.json'
    if p.exists() and b.read(p) != value: raise ValueError('Preserve unique attempt')
    if not p.exists(): b.save(p, value)
    return p, value, prior


def execute(command, out, value, prior, runtime=False):
    q = b.load('_existing_leaf_process', R / '.scratch/qwen-mtp-quality-20261022/run_quality.py')
    if runtime:
        env = os.environ.copy(); env['PATH'] = b.read(prior['runtime_environment']['path'])['PATH']
    else:
        h = b.load('_existing_leaf_compiler_environment', R / '.scratch/native-paged-effects-20261022/build_windows.py')
        # Always derive MSVC environment from known cl, never nvcc or exe.
        env, _ = h.b.environment(value['host'], [], out)
        env['PATH'] = str(Path(value['native'][0]).parent) + os.pathsep + env['PATH']
    return q.execute(command, env, out / 'run', timeout=600)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action', choices=['prepare', 'compile-native', 'compile-host', 'link', 'run'])
    parser.add_argument('--attempt', type=int, default=1); args = parser.parse_args()
    if args.attempt <= 0: raise ValueError('Positive unique attempt required')
    p, value, prior = prepare(args.attempt)
    if args.action == 'prepare':
        print(json.dumps(dict(commands=b.identity(p), actual_compiles=0, native_runs=0, HTTP=0))); return 0
    action = args.action.removeprefix('compile-'); out = S / f'{action}{args.attempt}'; out.mkdir(exist_ok=False)
    if args.action.startswith('compile-'):
        (out / 'tmp').mkdir(); result = execute(value[action], out, value, prior)
        if result['exit'] or result['timed_out']: return result['exit'] or 1
        obj = out / ('probe.obj' if action == 'host' else 'typed.obj')
        b.require(value['sources'][action]); b.require(value['owning_kernel'])
        b.save(out / 'identity.json', dict(source=value['sources'][action], object=b.identity(obj), process=result,
            commands=b.identity(p), dependency_file=b.identity(out / ('dependencies.json' if action == 'host' else 'typed.d'))))
    elif action == 'link':
        records = []
        for kind in ('host', 'native'):
            record_path = S / f'{kind}{args.attempt}/identity.json'; record = b.read(record_path)
            for key in ('source', 'object', 'commands', 'dependency_file'): b.require(record[key])
            if record['process']['exit'] or record['process']['timed_out']: raise ValueError('Compile failed')
            records.append(b.identity(record_path))
        (out / 'tmp').mkdir(); result = execute(value['link'], out, value, prior)
        if result['exit'] or result['timed_out']: return result['exit'] or 1
        b.save(out / 'ready.json', dict(image=b.identity(out / 'typed-mmvf-m2.exe'), commands=b.identity(p), compiles=records, process=result))
    else:
        ready = b.read(S / f'link{args.attempt}/ready.json')
        for row in [ready['image'], ready['commands'], *ready['compiles']]: b.require(row)
        w = prior['original_weight']
        with Path(w['path']).open('rb') as stream:
            stream.seek(w['offset']); raw = stream.read(w['bytes'])
        digest = hashlib.sha256(raw).hexdigest(); del raw
        if digest != RANGE_SHA: raise ValueError('Original 24MiB W range hash differs')
        b.save(out / 'inputs.json', dict(original_plan=value['original_leaf_plan'],
            original_weight_range=dict(w, actual_sha256=digest), activation=prior['activation'],
            note=prior['activation_note'], selected_activation_range=prior['activation_selected_range']))
        result = execute(value['run'], out, value, prior, runtime=True)
        summary = dict(passed=False, process=result, scope=value['scope'])
        if not result['exit'] and not result['timed_out']:
            actual = b.read(out / 'run/stdout.log')
            if [x['kind'] for x in actual['choices']] != ['Lt_production_request1', 'whole_M2_typed_MMVF']:
                raise ValueError('Unexpected choice set')
            summary.update(passed=actual['passed'] is True, actual=actual)
        b.save(out / 'summary.json', summary); print(json.dumps(summary))
        if not summary['passed']: return result['exit'] or 1
    return 0


if __name__ == '__main__': sys.exit(main())
