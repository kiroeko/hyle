"""Reuse successful native1/host1; add the existing abort owner and CRT rule."""
from pathlib import Path
import argparse, hashlib, importlib.util, json, sys
sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('_typed_leaf_build1', S / 'build.py')
m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
b = m.b


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action', choices=['prepare', 'link', 'run']); args = parser.parse_args()
    old_path, value, prior = m.prepare(1)
    records = []
    for kind in ('host', 'native'):
        p = S / f'{kind}1/identity.json'; record = b.read(p)
        for key in ('source', 'object', 'commands', 'dependency_file'): b.require(record[key])
        if record['process']['exit'] or record['process']['timed_out']: raise ValueError('Original compile failed')
        records.append(b.identity(p))
    original = b.read(prior['actual_current_link']['path'])['command']
    base = [x for x in original if Path(x).name.lower() == 'ggml-base.lib']
    if len(base) != 1 or '/NODEFAULTLIB:LIBCMT' not in original: raise ValueError('Actual original link contract missing')
    archive = b.identity(base[0])
    if archive['sha256'] != 'c17aa8b55587caf8ad1aa07dc8c11dcad703a5e4335fc2471bef3c7615e7f20f':
        raise ValueError('Actual abort owner archive differs')
    out = S / 'link2'; image = out / 'typed-mmvf-m2.exe'
    command = [x for x in value['link'] if not x.startswith(('/OUT:', '/MAP:'))]
    command += ['/NODEFAULTLIB:LIBCMT', archive['path'], '/OUT:' + str(image), '/MAP:' + str(image.with_suffix('.map'))]
    path = S / 'link2-command.json'
    plan = dict(command=command, runner=b.identity(__file__), original_commands=b.identity(old_path),
        compiles=records, additional_archive=archive,
        correction='Resolve existing init_fastdiv_values abort branch using original GGML base owner. Both compiled TUs are MD; CUDA13.3 cuda.lib requests LIBCMT, so retain the actual Hyle NODEFAULTLIB:LIBCMT rule. No recompile or kernel/math change.')
    if path.exists() and b.read(path) != plan: raise ValueError('Preserve immutable link2 command')
    if not path.exists(): b.save(path, plan)
    if args.action == 'prepare': print(json.dumps(plan)); return 0
    if args.action == 'link':
        out.mkdir(exist_ok=False); (out / 'tmp').mkdir()
        result = m.execute(command, out, value, prior)
        if result['exit'] or result['timed_out']: return result['exit'] or 1
        b.save(out / 'ready.json', dict(image=b.identity(image), command=b.identity(path), compiles=records, process=result))
    else:
        ready = b.read(out / 'ready.json')
        for row in [ready['image'], ready['command'], *ready['compiles']]: b.require(row)
        run_out = S / 'run2'; run_out.mkdir(exist_ok=False)
        w = prior['original_weight']
        with Path(w['path']).open('rb') as stream:
            stream.seek(w['offset']); raw = stream.read(w['bytes'])
        digest = hashlib.sha256(raw).hexdigest(); del raw
        if digest != m.RANGE_SHA: raise ValueError('Original 24MiB W range hash differs')
        b.save(run_out / 'inputs.json', dict(original_plan=value['original_leaf_plan'],
            original_weight_range=dict(w, actual_sha256=digest), activation=prior['activation'],
            selected_activation_range=prior['activation_selected_range'], note=prior['activation_note']))
        result = m.execute([str(image), *value['run'][1:]], run_out, value, prior, runtime=True)
        summary = dict(passed=False, process=result, scope=value['scope'], link=b.identity(out / 'ready.json'))
        if not result['exit'] and not result['timed_out']:
            actual = b.read(run_out / 'run/stdout.log')
            if [x['kind'] for x in actual['choices']] != ['Lt_production_request1', 'whole_M2_typed_MMVF']:
                raise ValueError('Unexpected choice set')
            summary.update(passed=actual['passed'] is True, actual=actual)
        b.save(run_out / 'summary.json', summary); print(json.dumps(summary))
        if not summary['passed']: return result['exit'] or 1
    return 0


if __name__ == '__main__': sys.exit(main())
