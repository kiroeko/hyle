// Fixed leaf only: instantiate the original MMVF body once for whole M2.
// No dispatcher changes, split rows, copied kernel math, F32 shadows or Cast.
#include "mmvf.cuh"
#include <cstdint>

extern "C" int hyle_mmvf_m2_launch(
    const void *weight, const void *activation, void *output, void *stream) noexcept {
    if (!weight || !activation || !output || !stream ||
        (reinterpret_cast<std::uintptr_t>(weight) & 15) != 0 ||
        (reinterpret_cast<std::uintptr_t>(activation) & 15) != 0 ||
        (reinterpret_cast<std::uintptr_t>(output) & 15) != 0) {
        return int(cudaErrorInvalidValue);
    }
    constexpr int K = 6144, N = 2048, M = 2, Block = 256;
    const auto one = init_fastdiv_values(1);
    const ggml_cuda_mm_fusion_args_device fusion{};
    // Each block handles one W row. W is loaded once for both A rows by the
    // existing ncols_dst loop, accumulated/reduced in F32, then BF16 RN stored.
    mul_mat_vec_f<nv_bfloat16, float, M, Block, false, false, nv_bfloat16, nv_bfloat16>
        <<<dim3(N, 1, 1), dim3(Block, 1, 1), 32 * sizeof(float),
           reinterpret_cast<cudaStream_t>(stream)>>>(
            static_cast<const nv_bfloat16 *>(weight),
            static_cast<const nv_bfloat16 *>(activation), nullptr, fusion,
            static_cast<nv_bfloat16 *>(output),
            K / 2, one, K, K / 2, N,
            one, N * K, M * K, M * N,
            one, N * K, M * K, M * N,
            0, nullptr);
    return int(cudaGetLastError());
}
