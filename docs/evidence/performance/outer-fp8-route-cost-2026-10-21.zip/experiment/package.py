"""Publish only this bounded local-role experiment and prepare an exact, nonexecuting cleanup list."""
from pathlib import Path
import hashlib
import json
import statistics as stats
import xml.etree.ElementTree as ET
import zipfile
import zlib

P=Path(__file__).resolve().parent
R=P.parents[2]
A=P.parent
Y=A/'quark-fp8-side-2026-10-21'
OUT=R/'docs/evidence/performance'
STEM='outer-fp8-route-cost-2026-10-21'

def ident(path):
    path=Path(path);data=path.read_bytes()
    return dict(path=str(path),bytes=len(data),sha256=hashlib.sha256(data).hexdigest())
def read(path):return json.loads(Path(path).read_text(encoding='utf-8-sig'))
def save(path,obj):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n',encoding='utf8')

def parse():
    processes=[];names=set();pids=set()
    for backend,attempts in [('cpu',[1]),('cuda',[1,2,3])]:
        for attempt in attempts:
            directory=P/backend/'validation'/f'attempt{attempt}'
            receipt=read(directory/'receipt.json');result=read(directory/'tests.result.json')
            assert receipt['passed'] and receipt['cases']==2 and not receipt['failed'] and not receipt['skipped']
            assert result['exit']==0 and result['terminal']
            assert result['pid'] not in pids;pids.add(result['pid'])
            rows=[]
            for case in ET.parse(directory/'tests.xml').iter('testcase'):
                assert case.find('failure') is None and case.find('skipped') is None
                assert case.get('status','run')=='run'
                name=case.get('classname')+'.'+case.get('name');names.add(name)
                props={p.get('name'):p.get('value') for p in case.iter('property')}
                assert not any(k.startswith('forced_recipe') for k in props)
                arms={}
                for tag in ['default','budget3MiB']:
                    raw=[float(x) for x in props[tag+'_complete_samples_us'].split(',') if x]
                    median=stats.median(raw)
                    assert len(raw)==11 and median==float(props[tag+'_complete_median_us'])
                    assert props[tag+'_forced']=='false' and props[tag+'_compile_status']=='0'
                    assert props[tag+'_optimization_limited']=='false' and props[tag+'_route_state_limit']=='65536'
                    assert int(props[tag+'_materialized'])==917504
                    arms[tag]=dict(
                        complete_call_us=dict(raw_11_samples=raw,median=median,mean=stats.mean(raw),minimum=min(raw),maximum=max(raw)),
                        cold_us=dict(compile=float(props[tag+'_compile_us']),allocate_bind=float(props[tag+'_allocate_bind_us']),
                            prepare_slots=[float(props[tag+'_prepare_slot0_us']),float(props[tag+'_prepare_slot1_us'])],
                            first_complete_call=float(props[tag+'_first_complete_call_us'])),
                        compile=dict(forced=False,workspace_budget_bytes=int(props[tag+'_budget']),workspace_bytes=int(props[tag+'_workspace']),
                            original_E4_materialized_bytes=int(props[tag+'_materialized']),provider_persistent_known_bytes=int(props[tag+'_persistent_known']),
                            unknown_provider_private_count=int(props[tag+'_private_unknown_providers']),packed_steps=int(props[tag+'_packed_steps']),
                            search_states=int(props[tag+'_route_states']),plan_rejections=int(props[tag+'_plan_rejections']),
                            placement_attempts=int(props[tag+'_placement_attempts']),optimization_limited=False))
                assert arms['default']['compile']['packed_steps']==0
                assert arms['budget3MiB']['compile']['packed_steps']==1
                assert arms['budget3MiB']['compile']['workspace_budget_bytes']==3145728
                original=arms['default']['complete_call_us'];bounded=arms['budget3MiB']['complete_call_us']
                diffs=[v-u for u,v in zip(original['raw_11_samples'],bounded['raw_11_samples'])]
                rows.append(dict(test=name,M=1 if case.get('name')=='M1' else 2,arms=arms,
                    comparison=dict(budget_minus_default_median_us=bounded['median']-original['median'],
                        median_change_percent=100*(bounded['median']/original['median']-1),
                        mean_change_percent=100*(bounded['mean']/original['mean']-1),
                        same_repetition_budget_minus_default_us=diffs,paired_difference_median_us=stats.median(diffs))))
            assert len(rows)==2
            processes.append(dict(backend=backend,process=attempt,pid=result['pid'],start_unix=result['started'],end_unix=result['finished'],
                result=ident(directory/'tests.result.json'),xml=ident(directory/'tests.xml'),receipt=ident(directory/'receipt.json'),cases=rows))
    assert len(processes)==4 and len(names)==4
    return processes

def cleanup():
    mandatory=[];optional=[];objects=[]
    for backend in ['cpu','cuda']:
        directory=(P/backend/'checks/link1').resolve()
        for path in sorted(directory.iterdir()):
            if not path.is_file():continue
            resolved=path.resolve();assert resolved.is_relative_to(P.resolve())
            if path.suffix.lower() in ['.exe','.map','.dll']:mandatory.append(ident(path))
            elif path.suffix.lower() in ['.lib','.exp','.pdb']:optional.append(ident(path))
        objects.append(read(P/backend/'checks/attempt1/identity.json')['object'])
    assert sum(Path(x['path']).suffix=='.exe' for x in mandatory)==2
    for row in objects:assert ident(row['path'])==row
    result=dict(status='inventory_only_nothing_deleted_test_ps1_not_modified',workspace=str(P.resolve()),
        rebuildable_images_maps_and_staged_DLLs=mandatory,logical_bytes=sum(x['bytes'] for x in mandatory),
        optional_generated_import_sidecars=optional,optional_logical_bytes=sum(x['bytes'] for x in optional),
        preserve_test_objects=objects,preserve='All other product/test objects and shared dependency/cache files, including the original CPU module DLL outside this stage.',
        execution='Root must first write and check exact deletion paths in repository test.ps1; this script never deletes files. Logical bytes do not imply physical reclaimed bytes for hardlinks.')
    save(P/'cleanup-windows-inventory.json',result)
    return result

def main():
    OUT.mkdir(parents=True,exist_ok=True)
    public=OUT/(STEM+'.json');archive=OUT/(STEM+'.zip')
    assert not public.exists() and not archive.exists()
    processes=parse();clean=cleanup()
    frozen=read(P/'benchmark-source-freeze.json')
    for row in frozen['sources']:assert ident(row['source']['path'])==row['source']
    source_names=[
        'tests/compute_models/fp8_outer_scale_fixture.h','tests/compute_models/static_fp8_reference_fixture.h',
        'tests/compute_provider_native/half_test_support.h','src/compute_packed_shared/static_fp8_linear.h',
        'src/graph/static_fp8_region.h','src/graph/closed_region.h','src/graph/mapped_pattern_region.h',
        'src/graph/region_discovery.h','src/graph/executable.cc','src/graph/resources.cc',
        'src/graph_route_cpu/ggml_region.cc','src/graph_provider_ggml_cuda/ggml_cuda_region.cc',
        'src/compute_provider_native/static_fp8.cc','src/compute_provider_torch_cuda/artifact_provider.cc',
        'src/compute_provider_torch_cuda/mlx_packed_kernel.cu','src/compute_provider_torch_cuda/mlx_packed_kernel.h',
        'src/compute_route_cpu/default_policy.cc','src/compute_route_cuda/default_policy.cc',
        'include/hyle/graph/executable.h','include/hyle/graph/result.h','include/hyle/compute/model_ops.h']
    current=[dict(repository_path=name,**ident(R/name)) for name in source_names]
    review=dict(status='source_math_and_lifetime_consistent_all_actual_cases_pass',benchmark_source=ident(P/'role_bench.cc'),
        math=['Same finite artificial BF16 A/E4 W/F32 SW bytes at pinned f_a_proj geometry for both arms; source bank materialization policy and ownership identical.',
            'Explicit no-floor F32 row maximum times F32 reciprocal448, strict F32 reciprocal-normalization, SATFINITE E4, F32 code dot, SW then SA with separate F32 products, BF16 output.',
            'Independent existing scalar oracle uses sparse one-term weight rows so this declared finite dot domain has no ambiguous reduction tree. Actual output comparisons are exact bytes. No numeric checkpoint payload or universal AMD rcpf equivalence.'],
        lifetime=['Two original Invocation slots and output blocks per arm; slot1 uses different generation while old slot0 result is read and blocks slot0 submit.',
            'Both arms reset dynamic inputs to identical bytes before timing. Old result release, submit, Completion wait, GraphOutput/tensor and exact-range result read are inside the timer; assertions/input writes are outside.',
            'Retained results are read after Invocation/program/input/pool owners are cleared. Backend Context/StorageOwner remain alive through those reads, so this is not a Context-close escape proof.'],
        cold=['Context/device setup is excluded. Compile, resource allocate/bind, each prepare and first complete invocation are separate raw observations.',
            'Default compiles before budget; M1 executes before M2. Modules/ATen/thread state are warmed asymmetrically. Cold buckets are not fair randomized startup comparisons and must not be merged into warm samples.'],
        post_probe_correction='The pre-probe report proposed candidate cutting/ranking as a possible direction. Actual public 3MiB resource limits already trigger complete-cover backtracking to the bounded candidate, without source/rank changes. Do not present the earlier design as a required applied fix.')
    save(P/'post-probe-source-review.json',review)
    summary=dict(date='2026-10-21',status='finite_local_role_cost_observation_complete_no_product_change',
        scope='Windows CPU and CUDA, M1/M2 N128 K7168 fixed-header f_a_proj geometry; finite artificial bytes and original ordinary graph. No Qwen decode or model throughput claim.',
        question='Can the existing public workspace budget naturally recover the admitted bounded static FP8 candidate, and what are the local complete-call costs?',
        result=dict(natural_budget_selection=True,workspace_budget_bytes=3145728,forced_candidate_used=False,all_optimization_limited=False,
            product_changes=0,priority_changes=0,independent_processes=dict(cpu=1,cuda=3,total=4),
            case_executions=8,distinct_backend_geometry_cases=4,unique_numeric_geometries=2,failed=0,skipped=0,
            per_process_warm_samples_per_arm_and_geometry=11),
        space=dict(default_to_budget_workspace_bytes=dict(cpu_M1=[3763328,35848],cpu_M2=[3856512,71692],cuda_M1=[3771392,43008],cuda_M2=[3872256,86016]),
            original_materialized_E4_constant_bytes_both_arms=917504,removed_NK_F32_intermediate_bytes=3670016,
            alias='Default transpose aliases the W Cast span; do not count it as a second allocation.',
            private='Known provider persistent metadata is recorded per process. Unknown-private counts remain CPU2 and CUDA2 after budgeting; workspace is not total private bytes/RSS/physical traffic.'),
        interpretation=[
            'The existing natural resource-limited compile selects exactly one bounded static policy for every backend/shape/process. No forced constraint was needed. This is a resource policy, not a product/default-routing fix.',
            'CPU has one process only: M1 median1523.8->1440.4us (-5.47%), M2 median2182.7->2915.6us (+33.58%, slower). Bounded storage has a real CPU tradeoff; do not globally promote the candidate.',
            'CUDA arm medians are lower in all three processes for M1 and M2, but budget M1 has 431.6/543.4/363.2us tail samples. Its means are slightly slower in processes1 and2. All raw samples, means and paired differences are retained.',
            'CUDA process3 M2 is slower for both arms (180.2->117.4us medians) than earlier processes. Keep processes separate; no pooled latency, stable tail or whole-model speedup claim.',
            'Cold order is not randomized and includes first module/thread/library effects. Preserve compile/prepare/first-call buckets separately; do not call the M1 cold difference a proven cold-start benefit.',
            'No global default, provider rank, graph candidate cut, numerical contract or executor changed. The observation supports using the explicit existing workspace limit when this finite role must meet a small workspace requirement.'],
        measurement=dict(replay='Commands on both arms; no capture claim',order='Within each process M1 then M2; compile default before budget; warm calls alternate arm order by repetition; slots alternate.',
            boundary='Old result release + complete submit + Completion.wait + GraphOutput/tensor + exact output read; no device-only event substitution.',
            cold='compile / allocate-bind / prepare slot0 / prepare slot1 / first complete call all separate',
            pairing='Same repetition index is a nearby interleaved comparison, not an independent process. No raw samples are pooled across processes.'),
        processes=processes,current_sources=current,
        related_evidence=[dict(path='../correctness/fp8-outer-scale-reference-2026-10-21.json',identity=ident(R/'docs/evidence/correctness/fp8-outer-scale-reference-2026-10-21.json'))],
        limitations=['CPU n=1 process; CUDA n=3 short processes. No steady clocks, wide shape sweep or tail guarantee.',
            'No complete model/checkpoint/Linux/quality/AMD tuned-kernel equivalence or Qwen decode conclusion.',
            'No SDK/NVCC/product build for this experiment: two focused test CXX and two links against recorded current Z closures.'],
        source_review='analysis/post-probe-source-review.json',cleanup_inventory='cleanup/cleanup-windows-inventory.json')
    save(P/'independent-analysis.json',summary)
    members={}
    def add(path,name):
        path=Path(path);assert path.is_file(),path
        assert name not in members,name
        assert path.suffix.lower() not in ['.exe','.obj','.dll','.map','.lib','.exp','.pdb','.cubin','.spv','.metallib']
        members[name]=path.read_bytes()
    for name in ['role_bench.cc','build_bench.py','package.py','benchmark-source-freeze.json','benchmark-compiles.json','benchmark-ready-for-root-run.json']:
        add(P/name,'experiment/'+name)
    for name in ['review.json','default-compile-observations.json','post-probe-source-review.json','independent-analysis.json']:
        add(P/name,'analysis/'+name)
    add(P/'cleanup-windows-inventory.json','cleanup/cleanup-windows-inventory.json')
    add(P/'root/run_windows.py','experiment/root/run_windows.py')
    for backend in ['cpu','cuda']:
        for directory in [P/backend/'checks/attempt1',P/backend/'checks/link1',P/backend/'validation']:
            for path in sorted(directory.rglob('*')):
                if path.is_file() and path.suffix.lower() in ['.json','.log','.xml']:
                    add(path,str(path.relative_to(P)).replace('\\','/'))
    for name in source_names:add(R/name,'sources/'+name)
    for name in ['selected-reader-contract.json','default-route-source-review.json']:
        add(Y/'review'/name,'research/'+name)
    add(Y/'outer-scale/source-role-freeze.json','research/source-role-freeze.json')
    add(A/'quark-mxfp4-contract-review/artifact/23/model-00001-of-000096.safetensors/header.json','research/fixed-header.json')
    inventory=[dict(name=name,bytes=len(data),sha256=hashlib.sha256(data).hexdigest(),crc32=f'{zlib.crc32(data)&0xffffffff:08x}') for name,data in sorted(members.items())]
    manifest=dict(payload_members=inventory,payload_member_count=len(inventory),
        manifest_scope='All other ZIP members; manifest cannot include its own hash.',source_count=len(current),
        binaries_SDK_models_excluded=True)
    members['manifest.json']=(json.dumps(manifest,indent=2)+'\n').encode()
    with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as zipout:
        for name,data in sorted(members.items()):zipout.writestr(name,data)
    with zipfile.ZipFile(archive) as zipin:
        assert zipin.testzip() is None and len(zipin.namelist())==len(members)
        for entry in inventory:
            data=zipin.read(entry['name']);info=zipin.getinfo(entry['name'])
            assert hashlib.sha256(data).hexdigest()==entry['sha256'] and len(data)==entry['bytes']
            assert f'{info.CRC:08x}'==entry['crc32']
    summary['archive']=dict(file=archive.name,**ident(archive),members=len(members),manifest='manifest.json',sources=len(current))
    save(public,summary)
    receipt=dict(public_json=ident(public),archive=ident(archive),members=len(members),sources=len(current),
        CRC_SHA_all_members_verified=True,cleanup_inventory=ident(P/'cleanup-windows-inventory.json'),deleted_files=0,
        product_changes=0,new_builds_or_GPU_runs_by_packager=0)
    save(P/'publication.json',receipt)
    print(json.dumps(receipt,indent=2))

if __name__=='__main__':main()
