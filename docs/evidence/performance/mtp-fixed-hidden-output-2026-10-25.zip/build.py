"""One private CUDA app TU, exact current Ready link closure; no model execution."""
from pathlib import Path
import hashlib
import importlib.util
import json
import os
import sys

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parents[2]
WORK = Path(__file__).resolve().parent
BASE = ROOT / '.scratch/inference-current-cuda-20261025'
spec = importlib.util.spec_from_file_location('finite', ROOT / '.scratch/inference-e4-append-implementation-20261025/check_finite.py')
finite = importlib.util.module_from_spec(spec)
spec.loader.exec_module(finite)
read, save, pin, execute = finite.read, finite.save, finite.pin, finite.execute

def exact(row):
    current = pin(Path(row['path']))
    assert current == row, (current, row)

attempt = WORK / (sys.argv[1] if len(sys.argv) > 1 else 'candidate1')
assert not attempt.exists(), 'Preserve original process/raw; choose a new attempt name'
source_pins = read(WORK / 'source-pins.json')
assert len(source_pins['files']) == 1
changed = source_pins['files'][0]
assert changed['path'] == 'engine/models/qwen35/main.cc'
original = ROOT / changed['path']
source = WORK / 'source' / changed['path']
assert {k: pin(original)[k] for k in ('bytes', 'sha256')} == changed['before']
assert {k: pin(source)[k] for k in ('bytes', 'sha256')} == changed['after']
ready = read(BASE / 'ready.json')
assert ready['image']['sha256'] == '9d5bee3b9a633c29578b50343ee6002207ca8e85328a32663b1a20b22a9c8165'
exact(ready['image'])
baseline_deps = read(BASE / 'actual-project-dependencies.json')
for row in baseline_deps: exact(row)
review = read(WORK / 'implementation-review.json')
for row in review['dependency_pins']:
    row = dict(row, path=str(ROOT / row['path']))
    exact(row)

old_command = read(BASE / 'app/command.json')['command']
compiler, flags, skip = old_command[0], [], False
for word in old_command[1:]:
    if skip:
        skip = False
        continue
    if word.lower() == '/sourcedependencies':
        skip = True
        continue
    if word.lower().startswith(('/fo', '/fd')) or word.lower().endswith(('.cc', '.cpp')):
        continue
    flags.append(word)
# Resolve original quoted local and ../../inference includes from the actual
# canonical model directory. Actual sourceDependencies verifies no stale tree.
flags = ['/I' + str(ROOT / 'engine/models/qwen35'), *flags]
for required in ['/W4', '/WX', '/DHYLE_COMPUTE_CUDA=1', '/DHYLE_COMPUTE_GGML_CUDA=1', '/DGGML_USE_CUDA']:
    assert required in flags, required
assert '/DHYLE_COMPUTE_CPU=1' not in flags
env = finite.discover_environment(compiler='msvc', cache={
    'CMAKE_C_COMPILER': compiler, 'CMAKE_CXX_COMPILER': compiler,
    'CMAKE_GENERATOR': 'Ninja'}, backends=()).env

link = read(BASE / 'link/command.json')['command']
old_app = str(BASE / 'app/unit.obj')
assert link.count(old_app) == 1
before_inputs = read(BASE / 'link-inputs.json')
for row in before_inputs: exact(row)
assert len(before_inputs) == 221
for leaf in ('compute--batch_transfer.obj', 'compute_backend_cuda--cuda_batch_transfer.obj'):
    assert any(Path(row['path']).name == leaf for row in before_inputs)
weights = str(BASE / 'weights/unit.obj')
assert link.count(weights) == 1
attempt.mkdir(parents=True)
entry = attempt / 'entry.cc'
entry.write_text('#include "' + source.as_posix() + '"\nint main(int argc, char **argv) { return qwen35::run(argc, argv); }\n', encoding='utf-8')
save(attempt / 'source-before.json', dict(candidate=pin(source), canonical_main=pin(original),
    baseline_ready=pin(BASE / 'ready.json'), baseline_dependencies=baseline_deps,
    reviewed_dependencies=review['dependency_pins']))
folder = attempt / 'app'
command = [compiler, *flags, str(entry), '/sourceDependencies', str(folder / 'dependencies.json'),
           '/Fo' + str(folder / 'unit.obj'), '/Fd' + str(folder / 'unit.pdb')]
compiled = execute(command, env, folder)
processes = {'app': compiled}
if compiled['exit']:
    save(attempt / 'summary.json', dict(status='COMPILE_FAILED_NO_GPU_RUN', processes=processes,
        source=pin(source), source_pins=source_pins))
    raise SystemExit(1)

deps = read(folder / 'dependencies.json')['Data']
actual = [Path(p).resolve() for p in dict.fromkeys([deps['Source'], *deps['Includes']])]
assert source.resolve() in actual and original.resolve() not in actual
assert (ROOT / 'engine/models/qwen35/weights.h').resolve() in actual
for p in actual:
    try: rel = p.relative_to(ROOT)
    except ValueError: continue
    if rel.parts[0] == '.scratch' and p not in (source.resolve(), entry.resolve()):
        assert '/include/hyle/' not in p.as_posix().lower(), 'Stale Hyle public header: ' + str(p)
        assert '/engine/' not in p.as_posix().lower(), 'Stale engine header: ' + str(p)
save(folder / 'actual-dependencies.json', [pin(p) for p in actual])

args = [str(folder / 'unit.obj') if word == old_app else word for word in link
        if not word.lower().startswith(('/out:', '/pdb:', '/implib:', '/map:'))]
inputs = [Path(word) for word in args[1:] if Path(word).is_absolute() and Path(word).suffix.lower() in ('.obj', '.lib')]
assert len(inputs) == 221 and all(p.is_file() for p in inputs)
after_inputs = [pin(p) for p in inputs]
assert sum(a != b for a, b in zip(before_inputs, after_inputs)) == 1
assert [x for x in before_inputs if x['path'] != old_app] == [x for x in after_inputs if x['path'] != str(folder / 'unit.obj')]
save(attempt / 'link-inputs.json', after_inputs)
save(attempt / 'object-map.json', [dict(before=pin(BASE / 'app/unit.obj'), after=pin(folder / 'unit.obj'))])
image = attempt / 'link/hyle.exe'
linked = execute([*args, '/OUT:' + str(image), '/IMPLIB:' + str(image.with_suffix('.lib')),
    '/PDB:' + str(image.with_suffix('.pdb'))], env, image.parent)
processes['link'] = linked
if linked['exit']:
    save(attempt / 'summary.json', dict(status='LINK_FAILED_NO_GPU_RUN', processes=processes,
        source=pin(source), source_pins=source_pins, linked_absolute_inputs=len(inputs)))
    raise SystemExit(1)

native = Path(ready['native']['path'])
exact(ready['native'])
os.link(native, image.parent / native.name)
runtime = read(BASE / 'smoke-runtime.json')
runtime['PATH'] = str(image.parent) + os.pathsep + runtime['PATH']
runtime['native_hardlink'] = pin(image.parent / native.name)
runtime['original_runtime_record'] = pin(BASE / 'smoke-runtime.json')
save(attempt / 'runtime.json', runtime)
for row in baseline_deps: exact(row)
for row in before_inputs: exact(row)
assert {k: pin(source)[k] for k in ('bytes', 'sha256')} == changed['after']
summary = dict(status='READY_PRIVATE_HIDDEN_OUTPUT_CUDA_NOT_RUN', processes=processes,
    image=pin(image), app=pin(folder / 'unit.obj'), weights=pin(Path(weights)),
    source=pin(source), canonical_main=pin(original),
    source_pins=[pin(source), pin(ROOT / 'engine/models/qwen35/weights.h'),
        pin(ROOT / 'engine/models/qwen35/weights.cc'), pin(ROOT / 'engine/inference/backend.h')],
    private_source_manifest=source_pins,
    source_dependencies=pin(folder / 'actual-dependencies.json'),
    link_inputs=pin(attempt / 'link-inputs.json'), linked_absolute_inputs=221,
    inherited_system_libraries=13, total_inputs=234, unchanged_inputs=233,
    object_map=read(attempt / 'object-map.json'), baseline_image=ready['image'],
    native=pin(native), runtime=pin(attempt / 'runtime.json'),
    commands={'app': pin(folder / 'command.json'), 'link': pin(image.parent / 'command.json')},
    strict_flags=['/W4', '/WX', '/DHYLE_COMPUTE_CUDA=1', '/DHYLE_COMPUTE_GGML_CUDA=1', '/DGGML_USE_CUDA'],
    new_TUs=1, weights_core_SDK_provider_device_rebuilds=0, GPU_runs=0,
    scope='Private frozen main only; all other objects/weights/runtime reused from exact current CUDA Ready. Compile/link evidence only, no behavior or performance claim.')
save(attempt / 'summary.json', summary)
save(attempt / 'ready.json', summary)
print(json.dumps({k: summary[k] for k in ('status', 'processes', 'image', 'total_inputs', 'unchanged_inputs')}, indent=2))
