"""Private source preparation only. No compiler, device work or canonical writes."""
from pathlib import Path
import difflib
import hashlib
import json

ROOT = Path(__file__).resolve().parents[2]
WORK = Path(__file__).resolve().parent
REL = 'engine/models/qwen35/main.cc'
before = (ROOT / REL).read_bytes()
assert hashlib.sha256(before).hexdigest() == '15d43f87182446fec8696d95142fa41a8c4b367ce8b83f927e6a286d3be64e9f'
text = before.decode()
newline = '\r\n' if b'\r\n' in before else '\n'

def change(old, new):
    global text
    old, new = old.replace('\n', newline), new.replace('\n', newline)
    assert text.count(old) == 1, old[:120]
    text = text.replace(old, new)

change('#include "weights.h"', '#include "weights.h"\n#include "hyle/compute/batch_transfer.h"\n#include "hyle/compute/detail/copy_stream_access.h"\n#include "hyle/core/assert.h"')
change('using ResourceRetention = inference::RetainedResources<ColdResources>;\nstruct Phase final', r'''using ResourceRetention = inference::RetainedResources<ColdResources>;
// Private experiment only. Production canonical has no option or branch.
constexpr bool fixed_hidden_output_experiment = true;
struct HiddenOutputCopy final {
  std::vector<Tensor> scratch;
  std::vector<c::ReadLease> readers;
  std::vector<c::CopyRange> ranges;
  c::CopyBatchProgram program;
  c::CopyBatchInvocation invocation;
  c::CopyBatchUpdate update;
  ResourceRetention retirement;

  // Copy controls borrow the original Queue. Their accepted Completion, not
  // a lease or observed error, retains ColdResources until actual retirement.
  hyle::Result<bool> recover(hyle::Status &terminal) noexcept {
    bool failed = false;
    if (update.valid()) {
      const auto observed = update.observe();
      inference::record_retirement_status(terminal, observed);
      if (update.in_flight()) return false;
      failed = !observed.ok();
      HYLE_ASSIGN_OR_RETURN(invocation, update.release_invocation());
    }
    if (invocation.valid()) {
      if (invocation.in_flight()) return false;
      HYLE_RETURN_IF_ERROR(invocation.reset());
      // reset cannot reopen a closed failed slot. Recreate only after the
      // original controls and every accepted native use actually retire.
      if (failed) invocation = {};
    }
    return !retirement.pending();
  }
  // Call only after original Graph unbind/reset AND copy binding withdrawal.
  // A native/escaped alias rejects promotion instead of exposing a writer.
  hyle::Status restore_writers() noexcept {
    for (std::size_t i = 0; i < scratch.size(); ++i) if (!scratch[i].writer) {
      if (readers[i]) {
        HYLE_ASSIGN_OR_RETURN(scratch[i].writer, readers[i].try_write());
      } else {
        // Abort before result export: Graph reset returned the original range.
        HYLE_ASSIGN_OR_RETURN(const auto bytes, scratch[i].description.required_bytes());
        HYLE_ASSIGN_OR_RETURN(scratch[i].writer, scratch[i].pool.allocate(bytes, cache::state_pool_alignment));
      }
    }
    return hyle::Status::Ok();
  }
};
struct Phase final''')
change('  std::array<ResourceRetention, execution_slot_count> retirement;\n  std::array<std::size_t, execution_slot_count> planned_slot_uses{};',
       '  std::array<ResourceRetention, execution_slot_count> retirement;\n  std::array<HiddenOutputCopy, execution_slot_count> hidden_output;\n  std::array<std::size_t, execution_slot_count> planned_slot_uses{};')
change('  bool *candidate_admission = nullptr;\n  void release_admission()',
       '  bool *candidate_admission = nullptr;\n  HiddenOutputCopy *hidden_output = nullptr;\n  void release_admission()')
change('    if (run) {\n      if (run->in_flight()) return false;',
       '    if (hidden_output) {\n      HYLE_ASSIGN_OR_RETURN(auto retired, hidden_output->recover(terminal));\n      if (!retired) return false;\n    }\n    if (run) {\n      if (run->in_flight()) return false;')
change('      *run = {}; // Release failed state-output writers and old input bindings.\n    }\n    const auto recover',
       '      *run = {}; // Release failed state-output writers and old input bindings.\n    }\n    if (hidden_output) {\n      const auto restored = hidden_output->restore_writers();\n      if (restored.IsUnavailable()) return false;\n      HYLE_RETURN_IF_ERROR(restored);\n      hidden_output = nullptr;\n    }\n    const auto recover')
change('        for (const auto &pin : phase->retirement) if (pin.pending()) return true;',
       '        for (const auto &pin : phase->retirement) if (pin.pending()) return true;\n        for (const auto &copy : phase->hidden_output) if (copy.retirement.pending()) return true;')
change('        (void)shape; for (auto &run : phase->slots) run = {};',
       '        (void)shape; for (auto &run : phase->slots) run = {};\n        for (auto &copy : phase->hidden_output) { copy.update = {}; copy.invocation = {}; }')
change('  void initialize_slot(Phase &phase, std::size_t slot) {\n    if (phase.slots[slot].valid()) return;', r'''  void initialize_hidden_output(Phase &phase, std::size_t slot) {
    if (!fixed_hidden_output_experiment || !drafts_token(phase.family->role) ||
        recursive_mtp() || max_drafts() != 1 ||
        phase.replay_modes[slot] != g::ReplayMode::kPreferCapture) return;
    auto &copy = phase.hidden_output[slot];
    // Gate before touching a writer or a Graph binding, even on recovery.
    if (copy.retirement.pending() || copy.update.in_flight() || copy.invocation.in_flight())
      throw std::runtime_error("fixed hidden output still retains original copy work");
    if (!copy.program.valid()) {
      const auto description = dense(precision.activation_type(), {1, hidden});
      const auto bytes = take(description.required_bytes());
      const auto count = cache::multiply(phase.family->requests, phase.prefix_rows);
      if (!count || count > UINT32_MAX / 2) throw std::runtime_error("fixed hidden output capacity overflow");
      // Ownership and actual resource are compiled facts, not backend names.
      for (const auto &ports : phase.carry_ports) for (auto port : ports) {
        const auto &output = phase.child->output(port);
        if (!output.caller_owned()) return;
        validate_state_output(output, description);
      }
      auto context = execution.common_context(); auto queue = execution.common_queue();
      if (!context || !queue) return; // No selected common CopyBatch endpoint.
      std::vector<Tensor> scratch; std::vector<c::CopyResourceSpec> specs;
      scratch.reserve(count); specs.reserve(count * 2);
      for (std::size_t i = 0; i < count; ++i) {
        Tensor value; value.description = description;
        value.pool = take(c::LeasePool::create(execution.device(), bytes,
            {.max_blocks = 1, .backing_alignment = cache::state_pool_alignment,
             .resource_budget = execution_budget}));
        value.writer = take(value.pool.allocate(bytes, cache::state_pool_alignment));
        scratch.push_back(std::move(value)); specs.push_back({execution.device(), bytes});
      }
      for (std::size_t i = 0; i < count; ++i) specs.push_back({execution.device(), bytes});
      auto program = take(c::CopyBatchProgram::prepare(**context, specs,
          {.max_resources = static_cast<std::uint32_t>(count * 2),
           .max_copies = static_cast<std::uint32_t>(count), .max_phases = 1,
           .max_bytes = cache::multiply(count, bytes), .resource_budget = execution_budget}));
      auto invocation = take(c::CopyBatchInvocation::create(program, **queue));
      copy.readers.resize(count); copy.ranges.reserve(count);
      copy.scratch = std::move(scratch); copy.program = std::move(program); copy.invocation = std::move(invocation);
    } else if (!copy.invocation.valid())
      copy.invocation = take(c::CopyBatchInvocation::create(copy.program, *take(execution.common_queue())));
    check(copy.restore_writers());
  }

  void initialize_slot(Phase &phase, std::size_t slot) {
    initialize_hidden_output(phase, slot);
    if (phase.slots[slot].valid()) return;''')
change('''      if (verifies_prefix(role) || has_mtp(role) || retains_sampling_frontier()) for (const auto &ports : phase.carry_ports)
        for (std::size_t i = 0; i < phase.prefix_rows; ++i)
          if (const auto &output = phase.child->output(ports[i]); output.caller_owned())
            check(run.bind(output.value, output.description, take(hidden_pool.allocate(geometry.hidden_bytes(), cache::state_pool_alignment))));''',
'''      auto &fixed_output = phase.hidden_output[slot];
      if (fixed_output.program.valid()) step.hidden_output = &fixed_output;
      std::size_t carry_index = 0;
      if (verifies_prefix(role) || has_mtp(role) || retains_sampling_frontier()) for (const auto &ports : phase.carry_ports)
        for (std::size_t i = 0; i < phase.prefix_rows; ++i, ++carry_index)
          if (const auto &output = phase.child->output(ports[i]); output.caller_owned()) {
            // Still a leased Graph OUTPUT: original write/native-use admission
            // owns it until retirement/publication. Never bind writer.view().
            auto writer = fixed_output.program.valid() ? std::move(fixed_output.scratch[carry_index].writer)
                : take(hidden_pool.allocate(geometry.hidden_bytes(), cache::state_pool_alignment));
            check(run.bind(output.value, output.description, std::move(writer)));
          }''')
change('  void validate_mtp_snapshot(const cache::Snapshot &head) const {', r'''  void copy_selected_hidden_outputs(StepState &step) {
    if (!step.hidden_output) return;
    auto &copy = *step.hidden_output; auto &phase = *step.phase; auto &run = *step.run;
    const auto count = copy.scratch.size();
    copy.ranges.clear();
    // Export ALL fixed outputs before take_append revokes results. The unused
    // rows are retained only until Graph withdrawal to recover their writer.
    for (std::size_t j = 0; j < step.members.size(); ++j)
      for (std::size_t row = 0; row < phase.prefix_rows; ++row) {
        const auto index = j * phase.prefix_rows + row;
        copy.readers[index] = take(inference::retain_output(run, phase.child->output(phase.carry_ports[j][row])));
      }
    for (std::size_t j = 0; j < step.members.size(); ++j) {
      const auto last = verifies_prefix(phase.family->role) ? step.members[j].accepted_tokens - 1 : 0;
      const auto bind = [&](std::size_t row) {
        const auto index = j * phase.prefix_rows + row;
        const auto bytes = take(copy.scratch[index].description.required_bytes());
        check(copy.invocation.bind_source({static_cast<std::uint32_t>(index)}, copy.readers[index]));
        check(copy.invocation.bind_mutable({static_cast<std::uint32_t>(count + index)},
            take(hidden_pool.allocate(bytes, cache::state_pool_alignment))));
        copy.ranges.push_back({{static_cast<std::uint32_t>(index)}, {static_cast<std::uint32_t>(count + index)}, {0}, 0, 0, bytes});
      };
      bind(last);
      if (verifies_prefix(phase.family->role) && step.members[j].accepted_tokens > 1) bind(last - 1);
    }
    constexpr std::array<c::CopyPhase, 1> copy_phases{};
    check(copy.invocation.prepare_replay(copy_phases, copy.ranges));
    check(copy.retirement.reserve(resources_));
    auto submitted = copy.invocation.submit();
    if (!submitted) { copy.retirement.reject(); (void)take(std::move(submitted)); }
    // One original phase, no producer bindings, sole move-only observer:
    // these accepted-control attachments are capacity-proven and nonallocating.
    auto update = c::CopyBatchUpdate::take(std::move(copy.invocation), std::move(*submitted));
    HYLE_FATAL_ASSERT(update.has_value()); copy.update = std::move(*update);
    std::array<c::Completion *, 1> original;
    const auto sources = c::detail::CopyStreamAccess::retirement_sources(copy.update, original);
    HYLE_FATAL_ASSERT(sources && *sources == 1);
    HYLE_FATAL_ASSERT(copy.retirement.attach(*original[0]).ok());
    check(copy.update.wait());
    for (std::size_t j = 0; j < step.members.size(); ++j) {
      auto &member = step.members[j];
      const auto last = verifies_prefix(phase.family->role) ? member.accepted_tokens - 1 : 0;
      const auto ready = [&](std::size_t row) {
        auto writer = take(copy.update.take_mutable({static_cast<std::uint32_t>(count + j * phase.prefix_rows + row)}));
        // The exact full row was copied and actually retired; no padding or
        // untouched half is published as initialized canonical state.
        return take(writer.publish());
      };
      member.next->carry_hidden = ready(last);
      if (verifies_prefix(phase.family->role) && member.accepted_tokens > 1) member.next->prior_hidden = ready(last - 1);
    }
    hyle::Status terminal;
    if (!take(copy.recover(terminal))) throw std::runtime_error("fixed hidden output copy retirement is pending");
    check(terminal);
    // readers stay readonly until original Graph unbind below. In particular,
    // copy completion alone does not permit their promotion/reuse.
  }

  void validate_mtp_snapshot(const cache::Snapshot &head) const {''')
change('''      if (verifies_prefix(phase.family->role) || has_mtp(phase.family->role) || retains_sampling_frontier())
        for (std::size_t j = 0; j < outputs.size(); ++j) {''',
'''      copy_selected_hidden_outputs(step);
      if (!step.hidden_output && (verifies_prefix(phase.family->role) || has_mtp(phase.family->role) || retains_sampling_frontier()))
        for (std::size_t j = 0; j < outputs.size(); ++j) {''')
change('''      check(run.unbind(phase.state_resource_ports));
      for (const auto &member : step.members)''',
'''      check(run.unbind(phase.state_resource_ports));
      if (step.hidden_output) {
        check(step.hidden_output->restore_writers());
        step.hidden_output = nullptr;
      }
      for (const auto &member : step.members)''')

after = text.encode()
for folder, raw in [('before', before), ('source', after)]:
    path = WORK / folder / REL
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(raw)
patch = ''.join(difflib.unified_diff(before.decode().splitlines(True), text.splitlines(True), fromfile='a/' + REL, tofile='b/' + REL))
(WORK / 'source.patch').write_text(patch, encoding='utf-8', newline='')
def pin(raw):
    return dict(bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())
pins = dict(status='PRIVATE_SOURCE_ONLY_NOT_COMPILED_OR_RUN', files=[dict(path=REL, before=pin(before), after=pin(after))], patch=pin((WORK / 'source.patch').read_bytes()))
(WORK / 'source-pins.json').write_text(json.dumps(pins, indent=2) + '\n')
print(json.dumps(pins, indent=2))
