"""Parse existing original formatter rows only; never run a model/profiler."""
from pathlib import Path
import hashlib
import json
import re

ROOT = Path.cwd()
WORK = Path(__file__).resolve().parent
PATTERN = re.compile(r'^prepared T=(\d+) visible=(\d+) replay=(\w+) cold_batch_seconds=(\S+) capture_recorded=(\d+) capture_reused=(\d+)$')

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def pin(path):
    return {'path': path.relative_to(ROOT).as_posix(), 'bytes': path.stat().st_size,
            'sha256': sha(path.read_bytes())}

runs = json.loads((WORK / 'screen/runs.json').read_bytes())
sequences, observations = {}, []
for run in runs:
    folder = Path(run['folder'])
    if not folder.is_absolute():
        folder = ROOT / folder
    path = folder / 'stderr.log'
    rows = []
    for line in path.read_text(encoding='utf-8').splitlines():
        if not line.startswith('prepared '):
            continue
        found = PATTERN.fullmatch(line)
        assert found, line
        T, visible, route, cold, recorded, reused = found.groups()
        rows.append({'seq': len(rows) + 1, 'T': int(T), 'visible': int(visible),
                     'replay': route, 'recorded': int(recorded), 'reused': int(reused)})
    assert len(rows) == 68
    arm = run['arm']
    if arm in sequences:
        assert rows == sequences[arm], (arm, run['mode'], run['index'])
    else:
        sequences[arm] = rows
    observations.append({'arm': arm, 'mode': run['mode'], 'index': run['index'],
                         'stderr': pin(path), 'prepared_rows': len(rows),
                         'recorded': sum(r['recorded'] for r in rows),
                         'reused': sum(r['reused'] for r in rows),
                         'sequence_sha256': sha(json.dumps(rows, sort_keys=True).encode())})

differences = []
for control, candidate in zip(sequences['control'], sequences['candidate']):
    for key in ['seq', 'T', 'visible', 'replay']:
        assert control[key] == candidate[key]
    if control != candidate:
        differences.append({'seq': control['seq'], 'T': control['T'], 'visible': control['visible'],
                            'control': {k: control[k] for k in ['recorded', 'reused']},
                            'candidate': {k: candidate[k] for k in ['recorded', 'reused']}})
assert [r['seq'] for r in differences] == [13, 14, 15, 16, 41]
assert all(r['control'] == {'recorded': 2, 'reused': 0} and
           r['candidate'] == {'recorded': 1, 'reused': 1} for r in differences)
assert len(observations) == 8
result = {
    'status': 'ACTUAL_EXISTING_EIGHT_PROCESS_FORMATTER_COUNTS_PASS',
    'new_GPU_compile_profile_HTTP': 0, 'parser': pin(Path(__file__).resolve()),
    'input_runs': pin(WORK / 'screen/runs.json'),
    'observations': observations, 'all4_within_each_arm_sequences_identical': True,
    'totals_control': {'recorded': 32, 'reused': 100},
    'totals_candidate': {'recorded': 27, 'reused': 105},
    'total_range_decisions_each': 132, 'per_call_counter_differences': differences,
    'complete_sequences': sequences,
    'source_contract': 'engine/reporting/execution_report.cc:14-19 prints StepObservation capture counters from original Invocation.replay_report; no new instrumentation.',
    'conclusion': 'Five fewer actual recorded ranges in every candidate process at exactly the five predicted logical call positions. Existing logs suffice; no new API-only trace is necessary.',
    'limits': ['Formatter has no range_begin/count/native graph ID. Body15->10 and unchanged front17 are not directly measured subcounts here.',
               'Agreement with prior full-key counterfactual is corroboration, not permission to relabel it as a new per-body trace.',
               'No Instantiate/ExecUpdate API counts or native-copy counters are inferred from these range totals.',
               'Three timing samples per arm remain descriptive; capture reduction alone is not throughput or statistical-significance proof.']}
(WORK / 'capture-counts.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
print(json.dumps({k: v for k, v in result.items() if k in ['status', 'totals_control', 'totals_candidate', 'per_call_counter_differences']}, indent=2))
