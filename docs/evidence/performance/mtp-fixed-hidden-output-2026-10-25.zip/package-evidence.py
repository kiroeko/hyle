"""Package existing facts only. No compiler/model/profiler invocation."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import zipfile

ROOT = Path.cwd()
WORK = Path(__file__).resolve().parent
OUT = WORK / 'archive-draft'
OUT.mkdir(exist_ok=True)
STEM = 'mtp-fixed-hidden-output-2026-10-25'

def read(path):
    return json.loads(path.read_bytes())

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def pin(path):
    return {'path': path.relative_to(ROOT).as_posix(), 'bytes': path.stat().st_size,
            'sha256': sha(path.read_bytes())}

files = {}
def add(path, member=None):
    assert path.is_file(), path
    name = member or path.relative_to(WORK).as_posix()
    assert name not in files, name
    assert path.suffix.lower() not in ['.obj', '.exe', '.dll', '.lib', '.exp', '.pdb']
    files[name] = path

for name in ['source.patch', 'source-pins.json', 'implementation-review.json',
             'independent-review-performance.json', 'parse-capture-counts.py',
             'capture-counts.json', 'screen.py', 'screen-driver.stdout.log',
             'screen-driver.stderr.log', 'build.py', 'freeze.py', 'prepare.py',
             'r1/source.patch', 'r1/source-pins.json',
             'candidate1/summary.json', 'candidate1/source-before.json',
             'candidate1/app/command.json', 'candidate1/app/dependencies.json',
             'candidate1/app/process.json', 'candidate1/app/stdout.log', 'candidate1/app/stderr.log',
             'candidate2/ready.json', 'candidate2/compile-correction.json',
             'candidate2/app/actual-dependencies.json', 'candidate2/source-before.json',
             'candidate2/link-inputs.json', 'candidate2/object-map.json', 'candidate2/runtime.json',
             'candidate2/app/command.json', 'candidate2/app/process.json',
             'candidate2/app/stdout.log', 'candidate2/app/stderr.log',
             'candidate2/link/command.json', 'candidate2/link/process.json',
             'candidate2/link/stdout.log', 'candidate2/link/stderr.log',
             'integrated/product-pins.json', 'integrated/product.patch', 'integrated/screened-to-final.patch',
             'integrated/ready.json', 'screen/plan.json', 'screen/runs.json', 'screen/summary.json']:
    add(WORK / name)
integrated = read(WORK / 'integrated/ready.json')
for group in integrated['commands'].values():
    path = Path(group['path'])
    add(path)
    for name in ['process.json', 'stdout.log', 'stderr.log']:
        candidate = path.parent / name
        if candidate.is_file():
            add(candidate)
for key in ['actual_dependencies', 'link_inputs', 'object_map']:
    value = integrated.get(key)
    if isinstance(value, dict) and 'path' in value:
        path = Path(value['path'])
        if path not in files.values():
            add(path)

runs = read(WORK / 'screen/runs.json')
assert len(runs) == 8
for run in runs:
    folder = Path(run['folder'])
    if not folder.is_absolute():
        folder = ROOT / folder
    for name in ['command.json', 'result.json', 'nontime-differences.json', 'stdout.log', 'stderr.log']:
        add(folder / name)
    assert read(folder / 'nontime-differences.json') == []
    if run['mode'] == 'memory':
        add(folder / 'memory.json')
        add(folder / 'memory-summary.json')

cause = ROOT / '.scratch/mtp-body-recapture-cause-20261025'
for name in ['peer-state-dataflow.json', 'vllm-fixed-buffer-anchor.json', 'terminal-copy-boundary-note.md']:
    add(cause / name, 'reference-mechanisms/' + name)
add(ROOT / '.scratch/inference-current-cuda-20261025/ready.json', 'control/current-ready.json')
add(ROOT / '.scratch/inference-current-cuda-20261025/actual-project-dependencies.json', 'control/actual-project-dependencies.json')
add(ROOT / '.scratch/inference-current-cuda-20261025/link-inputs.json', 'control/link-inputs.json')
add(ROOT / '.scratch/inference-current-cuda-20261025/smoke-runtime.json', 'control/screen-runtime.json')
add(Path(__file__).resolve())

manifest = {'members': [{'name': name, 'bytes': path.stat().st_size,
                         'sha256': sha(path.read_bytes())} for name, path in sorted(files.items())]}
manifest_path = OUT / 'member-sha256.json'
manifest_path.write_text(json.dumps(manifest, indent=2) + '\n', encoding='utf-8')
archive = OUT / (STEM + '.zip')
with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for name, path in sorted(files.items()):
        z.write(path, name)
    z.write(manifest_path, 'member-sha256.json')
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for row in manifest['members']:
        raw = z.read(row['name'])
        assert len(raw) == row['bytes'] and sha(raw) == row['sha256']

screen = read(WORK / 'screen/summary.json')
counts = read(WORK / 'capture-counts.json')
candidate = read(WORK / 'candidate2/ready.json')
# Keep sampled raw facts once in the archive; the public JSON contains summaries.
def statistics_without_samples(value):
    return {key: item for key, item in value.items() if key != 'samples'}

memory_summary = {}
for arm, value in screen['memory'].items():
    selected = {key: value[key] for key in ['path', 'sampled_peaks', 'sample_count',
                'ready_baseline', 'null_sample_counts', 'unavailable_reasons']}
    for key in ['actual_sample_gaps_ms', 'sample_cost_ms']:
        selected[key] = statistics_without_samples(value[key])
    selected['phase_windows'] = {
        phase: {key: row[key] for key in ['begin_ns', 'end_ns', 'received_boundary_counts',
                 'missing_boundary', 'ambiguous_boundary', 'invalid_boundary_order',
                 'sample_count', 'exact_phase_boundary_values', 'null_sample_counts',
                 'bracket_ages_ns', 'bracket_delta_bytes']}
        for phase, row in value['phase_windows'].items()}
    memory_summary[arm] = selected
screen_summary = {key: screen[key] for key in ['status', 'timing_processes',
                  'independent_memory_processes', 'all_exit0', 'source_work_equal',
                  'metrics', 'comparisons', 'work', 'historical_samples_pooled',
                  'latest_llama_comparison', 'profiler']}
screen_summary['memory'] = memory_summary
screen_summary['raw_summary'] = pin(WORK / 'screen/summary.json')
actual_processes = []
for run in runs:
    folder = Path(run['folder'])
    if not folder.is_absolute():
        folder = ROOT / folder
    result = read(folder / 'result.json')
    assert result['exit'] == 0 and not result['reader_errors']
    actual_processes.append({key: result[key] for key in
        ['arm', 'memory_only', 'started_unix_ns', 'finished_unix_ns',
         'process_wall_seconds', 'exit']})
screen_summary['actual_processes'] = actual_processes
screen_summary['non_time_comparison'] = {
    'all8_differences': 0,
    'reference': 'First actual current control report; complete recursive JSON comparison.',
    'excluded_field_name_substrings': ['seconds', 'tokens_per_second', 'clock_unix',
                                       'unix_ns', 'unix_ms'],
    'new_cache_state_work_metadata_exclusions': [],
    'capture_counts_source': 'Original stderr formatter, separately compared in capture-counts.json.'}
screen_summary['protocol'] = {
    'timing_order': ['control', 'candidate', 'candidate', 'control', 'control', 'candidate'],
    'memory_order': ['control', 'candidate'],
    'warmup': False, 'fixed_clocks': False,
    'endpoints': 'Original P+D=session reporting endpoints; prefill309 rows, decode126 output tokens, combined128 output tokens. Process wall is retained but not used as reported TPS.',
    'sampling': 'Original PSAPI RAM and process-PDH dedicated/shared VRAM; requested10ms interval, actual gaps and unavailable samples retained.'}
report = {
    'status': 'BOUNDED_SCREEN_PASS_CANONICAL_BUILD_PASS',
    'generated_UTC': datetime.now(timezone.utc).isoformat(),
    'scope': 'One current Hyle K1 real-two-turn before/after candidate screen: 6 unprofiled timing and 2 independent memory processes. No peer/new profiler run. Final canonical bridge has its own strict compile/link evidence. The root-owned current 32-process full window is separate and excluded from this report.',
    'implementation': {
        'control_image': candidate['baseline_image'], 'screened_candidate_image': candidate['image'],
        'screened_source': candidate['source'], 'canonical_final_source': integrated['source_pins'][0],
        'canonical_final_image_build_only': integrated['image'],
        'canonical_build': integrated['processes'],
        'canonical_bridge': pin(WORK / 'integrated/screened-to-final.patch'),
        'mechanism': 'Only eligible captured K1 body caller-owned hidden OUTPUTs use fixed work leases. After original selection, CopyBatch copies selected carry/prior full rows into original canonical hidden_pool; actual completion+binding withdrawal+Graph unbind precede unique try_write. GDN/ingress/selection/math unchanged.',
        'cost': 'Original terminal Graph copies remain. Additional scratch payload16KiB for the two prepared R1/H2048/BF16 roles plus control metadata; additional selected4/8KiB copy/submit/wait remains inside endpoints.',
        'default_route_scope': 'Ordinary, prefill, T1 tail, Verify, generated outputs and Commands sampling do not enter this finite candidate route.'},
    'first_failure': {
        'status': 'ACTUAL_STRICT_COMPILE_FAILED_NO_LINK_OR_GPU',
        'reason': 'C4458 /W4 /WX: local phases shadows Model::phases.',
        'evidence': pin(WORK / 'candidate1/summary.json'),
        'correction': 'Only rename to copy_phases; exact reverse replacement reproduces r1 source SHA. candidate2 strict app compile and original closure link passed.'},
    'screen': screen_summary,
    'actual_mechanism_counts': {
        'source': pin(WORK / 'capture-counts.json'),
        'all8_actual_stderr': True, 'each_arm4_sequences_identical': True,
        'control_record_reuse': [32, 100], 'candidate_record_reuse': [27, 105],
        'logical_calls': 68, 'range_decisions': 132,
        'changed_calls': counts['per_call_counter_differences'],
        'not_directly_recorded': ['range_begin/count and body-only total', 'CUDA Instantiate/ExecUpdate and physical copy counts'],
        'no_new_API_trace_needed': True},
    'peer_mechanism': {
        'source': pin(cause / 'peer-state-dataflow.json'),
        'fact': 'Matched llama persistent state banks+index gathers+snapshot copyback and bounded rollback; normalized carry workspace is D2H exported, selected onhost and uploaded to fixed draft input. TRT fixed pools/spec intermediate also gather/promote; vLLM graph buckets/persistent buffers reuse nonowning outputs.',
        'limit': 'Source mechanisms and distinct lifetime/math contracts, not a new peer benchmark or proof all capture property changes are known.'},
    'independent_review': pin(WORK / 'independent-review-performance.json'),
    'throughput_interpretation': 'Decode+1.288% and combined+.994% descriptive medians for3 samples per arm; decode ranges did not overlap in this one screen. Prefill ranges overlap. No statistical-significance claim, historical pooling, or new llama performance conclusion.',
    'canonical_full_window': None,
    'canonical_full_window_scope': 'Separate root-owned evidence; no formal-window sample or peer performance claim is included here.',
    'limits': ['The 8 actual processes used private source38a216 and imagef4fc1f57; final source1892e2d1/imagebe3c210e only removes the true experiment gate/comment and has separate strict build evidence. No final-image runtime is claimed by this package.',
               'No new arbitrary old-output fault/cancellation matrix or physical VRAM hard-cap proof.',
               'Memory1process per arm PSAPI/PDH sampled peaks are lower bounds; ready null/gaps retained, not zeroed.',
               'No time is subtracted from earlier profiler1.5423ms/episode or19.474001ms candidate window to claim recoverable speed.'],
    'archive': pin(archive),
    'archive_verification': {'members': len(files) + 1, 'CRC': 'PASS', 'member_SHA256': 'PASS',
                             'binary_SDK_model_or_full_main_tree_included': False}}
(OUT / (STEM + '.json')).write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'report': pin(OUT / (STEM + '.json')), 'archive': pin(archive),
                  'members': len(files) + 1}, indent=2))
