"""Pin and record the private source proposal; does not build or execute a model."""
from pathlib import Path
import hashlib
import json

WORK = Path(__file__).resolve().parent
ROOT = WORK.parents[1]
REL = 'engine/models/qwen35/main.cc'
old = (WORK / 'before' / REL).read_bytes()
new = (WORK / 'source' / REL).read_bytes()
baseline, candidate = old.decode(), new.decode()

def pin(path):
    raw = path.read_bytes()
    return {'path': path.relative_to(ROOT).as_posix(), 'bytes': len(raw),
            'sha256': hashlib.sha256(raw).hexdigest()}

def between(text, first, last):
    return text[text.index(first):text.index(last, text.index(first))]

unchanged = {
    'family_equations_graph_nodes_ports_and_publication_order': between(baseline, '  void prepare_family(', '  Family *find_family(') == between(candidate, '  void prepare_family(', '  Family *find_family('),
    'original_selection_validation_and_accepted_boundary': between(baseline, '      // Selection observes only retired original Graph results.', '      // Export every participant') == between(candidate, '      // Selection observes only retired original Graph results.', '      // Export every participant'),
    'noexcept_head_and_ledger_commit_tail': between(baseline, '      // All fallible native/export/metadata work is complete.', '    } catch (inference::EvaluationFailure') == between(candidate, '      // All fallible native/export/metadata work is complete.', '    } catch (inference::EvaluationFailure'),
    'canonical_main_untouched': (ROOT / REL).read_bytes() == old,
    'scratch_export_does_not_use_cache_retention': 'copy.readers[index] = take(inference::retain_output(run, phase.child->output(phase.carry_ports[j][row])))' in candidate,
    'graph_output_is_original_writelease_binding': 'check(run.bind(output.value, output.description, std::move(writer)))' in candidate,
    'body_only_private_gate': '!drafts_token(phase.family->role)' in candidate and 'recursive_mtp() || max_drafts() != 1' in candidate,
}
assert all(unchanged.values()), unchanged
dependencies = [
    'engine/models/qwen35/weights.h', 'engine/models/qwen35/weights.cc',
    'engine/models/qwen35/session_state.h', 'engine/inference/backend.h',
    'engine/inference/execution_resources.h', 'engine/inference/prepared_output.h',
    'include/hyle/compute/batch_transfer.h',
    'include/hyle/compute/detail/copy_stream_access.h',
    'include/hyle/compute/resource_leases.h',
    'src/compute/batch_transfer.cc', 'src/compute/resource_leases.cc',
    'src/compute/completion.cc', 'src/graph/resources.cc',
]
report = {
    'status': 'PRIVATE_SOURCE_ONLY_NOT_COMPILED_OR_RUN',
    'baseline': pin(WORK / 'before' / REL),
    'candidate': pin(WORK / 'source' / REL),
    'patch': pin(WORK / 'source.patch'),
    'source_assertions': unchanged,
    'scope': 'One private main.cc delta. No canonical, public API, Graph/Compute implementation, math, pool capacity, CLI option, manager or executor change.',
    'qualification': 'Only actual caller-owned carry outputs of existing nonrecursive K1 drafts_token roles (kMtpRound/kMtpCatchupRound), on already chosen PreferCapture slot and existing common Context/Queue. All ports must have original exact dense activation[1,H] and execution.device resource. Ordinary, prefill, single-row tail, Verify, random Commands and generated/source-alias outputs retain the original route.',
    'lifecycle': [
        'Cold single-full-block scratch writer per original carry port; original Graph run.bind receives WriteLease&&, so Graph owns the normal async write/native admission. Never bind writer.view().',
        'After original Graph success, original predicates/selection/accepted validation, export all fixed carry outputs as original ready ReadLeases before first take_append. Only selected carry and required preceding prior become CopyBatch sources. Unselected readers are local recovery handles only.',
        'Original hidden_pool supplies exact destination writers. One preprepared original CopyBatch phase performs byte copy outside target capture. Every accepted original Completion immediately retains ColdResources before wait; copy itself must actually succeed/retire before destination writer publication.',
        'After destination withdrawal, release/reset the original copy invocation to withdraw source aliases. Keep scratch readers through original state/take_append/complete/expected checks. Original run.unbind then strictly unique ReadLease.try_write returns the fixed writer before head publication. An alias/native use rejects promotion and retains the episode; no overwrite.',
        'Abort first observes original Graph and copy retirement. Unknown/pending copy keeps update, source/destination guards, original Queue wrapper and scope. Only actual retirement permits original Graph reset and writer recovery. Model teardown moves the original Backend into ColdResources, then drops application Graph/copy controls; original native phase retention and Completion attachment hold late work without new drain.',
    ],
    'permission_choice': {
        'anchors': ['src/graph/resources.cc:1569', 'src/graph/resources.cc:1608', 'src/graph/resources.cc:1718', 'src/graph/resources.cc:240', 'src/compute/resource_leases.cc:751'],
        'not_chosen': 'RegionAccess.take_write is trusted and requires Idle before any readonly publication. Invocation.result first publishes all bound writers, including ordinary GDN/result/readback paths. Keeping the normal result order and ready-reader/unbind/try_write path avoids moving those boundaries or introducing a new trusted output withdrawal seam.',
        'old_private_memo': 'Supersedes the raw TensorView/mutable-source sketch in mtp-body-variant-design-20261025/hidden-output-lifecycle-review.json. That sketch is not the final permission implementation.',
    },
    'retirement_proof': {
        'anchors': ['src/compute/batch_transfer.cc:452', 'src/compute/batch_transfer.cc:515', 'src/compute/batch_transfer.cc:522', 'include/hyle/compute/batch_transfer.h:178', 'src/compute/batch_transfer.cc:657', 'src/compute/completion.cc:18', 'engine/inference/execution_resources.h:20'],
        'accepted_attachment': 'Exactly one phase, at least one nonzero copy, no producer binding, and no copied observer: CopyBatchUpdate.take qualification, one retirement source, and original Completion attach are capacity-proven nonallocating invariants (fatal assertions, as in original CopyBatch accepted ticket attachments). Submit rejection before any accepted native prefix rejects the reserved scope. No reserved self-owner is left unattached along a fallible return.',
        'reset_closed': 'CopyBatchInvocation.reset checks sole observer/native busy, not closed; it clears bindings/status but does not reopen closed admission. recover calls reset only after actual in_flight=false, then discards failed control; later cold initialize recreates from original program/Queue. No reset rejection based solely on closed can prevent reaching recreate.',
        'handoff': 'CopyInvocationState.release_user drops observation Completion roots at last public user; accepted native guards still retain original slot/program. RetainedResources is outer Completion retention: inherited release runs before its own scope release. ColdResources.release_invocation_roots also clears update/invocation, while the original Backend handoff owns borrowed Queue/Context wrappers until actual copy retirement.',
    },
    'budget_and_cost': {
        'scratch_and_control': 'Scratch LeasePool and CopyBatch cold control use existing execution_budget; it is the same global allocation scope when supplied. No cache scope is attached to scratch exports. Default CUDA empty workspace budget retains original unbounded convention; this proposal does not fabricate a physical cap.',
        'canonical': 'Selected destination still comes from original hidden_pool/cache+additional shared source admission. Original N+K*R state and 2N+K*R hidden bank capacities unchanged. Scratch never becomes Snapshot/prefix backing.',
        'cold_payload_formula': 'sum over eligible prepared Phase/slot: R * prefix_rows(2) * required_bytes(dense activation[1,H]); separate actual CopyBatch metadata/native control. For H2048 BF16, 8192B per R1 role/slot; two actually prepared lag roles imply16384B, not multiplied by all waiting sessions.',
        'per_episode_payload': '4096B when original selection retains one hidden row, 8192B when it retains carry+prior; generalized exact row bytes for other geometry. Both original two-row Graph carry copies remain. One additional CopyBatch submit/completion/wait per eligible episode; no GDN or ingress copy. Physical API count/bandwidth/benefit not measured.',
    },
    'bounded_followup_plan_not_executed': {
        'baseline_ready': '.scratch/inference-current-cuda-20261025/ready.json',
        'baseline_image_sha256': '9d5bee3b9a633c29578b50343ee6002207ca8e85328a32663b1a20b22a9c8165',
        'build': 'After root source review/authorization, only candidate app TU strict compile plus relink current234-input closure, replacing app only. Reuse same current weights.obj/core/resources/native/vendor/report objects. Existing CopyBatch and CUDA CopyBatch leaves are already present. No SDK/core/provider rebuild.',
        'first_behavior': 'Existing cached BF16 original natural two-turn P154/64 case, same arguments/runtime/endpoints, baseline/candidate pair only when granted. Compare all normal non-time IDs, selection/EOS/quota, ledger/RNG/frontier/lag/work/state facts; list expected replay/capture and extra workspace differences specifically. Missing unreported tensors/old-reader fault observations remain unknown.',
        'performance': 'Only after behavior and retirement pass, root/performance agent owns same-case finite paired unprofiled screen. New cold scratch and copy/host-wait costs stay inside endpoints/memory. Offline normalize15->10 and observed windows19.474001ms are counterfactual mechanism evidence, not measured savings or TPS. No new matrix.',
        'stop': 'Different output/state/ledger/RNG, permission or unknown retirement failure stops before throughput; preserve first failure. Do not relax permissions, enlarge pools, force generated outputs, add Graph API, or substitute blanket non-time normalization.',
    },
    'dependency_pins': [pin(ROOT / p) for p in dependencies],
}
(WORK / 'implementation-review.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'review': pin(WORK / 'implementation-review.json'), 'assertions': unchanged}, indent=2))
