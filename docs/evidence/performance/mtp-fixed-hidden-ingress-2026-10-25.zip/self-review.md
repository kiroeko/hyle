# Source-only review of fixed hidden ingress

- Canonical baseline and private `before` main are both `75d4d9cb214602a5971fd5f8abe5d9563b86bcbb2575fa7d7ce76e12ce8035c9`. The two-line pending-frontier admission fix is in both sides, not a staging change. Initial eb156 source-preparation pins/patch remain in `history/`.
- Candidate main is `1f62dbdc38a4fab786aea475c971de07382e5c47582a3b8a548e04f259bde31b`. Only main differs among 39 frozen engine files. Initial source-only review used no compiler/linker. The subsequent authorized pair now passed strict app compilation/linking; candidate first C4458 and its name-only correction remain in build1. No canonical write, model process, GPU, or HTTP was used.
- Valid warmed slots keep the original immediate return in `initialize_slot`; the candidate does not rebuild descriptions/programs or reallocate its destination pools on each episode. Row pools/program/ranges are prepared only while the actual slot is uninitialized. Cold rearm after a retired failure is explicit.
- Input destination payloads are whole independent one-block pools in the actual device resource. Payload/metadata use the original allocation budget contract; CopyBatch metadata/native unknown costs use execution budget. No cache scope substitution, source-backing re-adoption, conversion, Snapshot field, output writer, or accepted-prefix change occurs.
- Destination publication is deliberately absent. The successful copy returns its original writer; Graph borrows a const TensorView only after copy retirement, exactly within the original serial admission. Source ReadLeases stay actual Snapshot inputs, and no trace/observer can escape the destination or release admission early.

## Reset and failed writer recovery

`CopyBatchInvocation::reset` (`src/compute/batch_transfer.cc:512-519`) rejects only a live public submission or native work. It clears failed/tail/bindings, **does not reject closed**, and does not reopen closed admission. `HiddenIngress::recover` first releases its original submission, recovers writers only on real success of an open control (a cancelled/failed control skips withdrawal and drops its writer at reset), and resets after `in_flight()==false`. A failed/cancelled control sets `recreate`; reset can complete and the old invocation is then discarded. The next uninitialized Graph slot cold-creates an original copy invocation and, only where failed bindings returned their block to the pool, reacquires the same whole scratch allocation. There is no reset-as-success or reopening a closed F2 control.

## Accepted copy to scope attachment: no fallible gap in this construction

1. `submit` succeeds here with exactly one submitted phase. Its success tail increments `users` once (`batch_transfer.cc:498-510`); only the original invocation and returned submission observe it. No producer is ever bound and no output ReadLease is published.
2. `CopyBatchUpdate::take` calls the existing `qualify` checks: the two controls share the same state, `users==2`, and `submitted>0` (`:584-591`). Those facts follow directly from step 1; take then performs noexcept moves and allocates nothing.
3. `retirement_sources` (`:657-680`) repeats that qualification, computes `submitted + used_producers == 1`, and writes the one pre-sized Completion pointer. There is no capacity miss, allocation, poll, native call, or new owner.
4. The original Phase retention node was reserved before submit and has no active predecessor. Its own/inherited/attachment fields were cleared by the original prior completion release (`completion.cc:20-29`); the copy phase supplies a valid original Completion. These are precisely `CompletionAccess::attach_retention`'s checks (`:52-74`). Attaching moves no payload and performs no allocation. A synchronously completed phase releases the reservation inline; otherwise the actual original completion owns it.

Thus the checked status branches are defensive invariant checks, not user-input/resource-failure opportunities after native acceptance. No successful path leaves an unattached self-reservation cycle. Actual failures from bind/prepare/submit/wait still use the original StepState abort and native retirement contract.

## Exact late-work handoff

- Copy submit retains the CopyInvocationState and attaches `phase_terminal/phase_release` to the original phase Completion (`batch_transfer.cc:498-505`). Its bindings hold both source ReadLeases and destination writers.
- Dropping application update/invocation roots calls `CopyInvocationState::release_user` (`:88-96`), which resets public Completion observers while native reference(s) retain the descriptor owner.
- `Completion::reset/settle` forward the complete retention chain into the original backend `destroy` (`completion.cc:174-215`). CUDA `completion_destroy` (`cuda_backend.cc:993-1011`) sends an unretired slot and its lifetime chain to `CompletionReaper::retire`; it does not release a pending/error slot. Only `finish_abandoned` after the original retired fence releases that chain (`:583-598`).
- The candidate's ColdResources handoff drops both copy application controls alongside Graph roots. The attached Phase retention continues to pin ColdResources, its endpoint/Queue wrapper, source/destination pools, and metadata until actual release. Existing `pending/retire` observes that same Phase node. No extra registry or retirement executor was added.

All output-state capture, acceptance/repair, expected-base commit, ledger/RNG fields, request dispatch, and synchronous output observation code are text-identical to baseline, as recorded by `source-checks.json`. This is a source-level conclusion, not a compiled/runtime correctness or performance result.
