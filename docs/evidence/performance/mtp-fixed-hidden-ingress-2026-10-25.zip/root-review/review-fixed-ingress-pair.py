from pathlib import Path
import hashlib
import json

R = Path.cwd()
W = R / '.scratch/mtp-fixed-hidden-ingress-20261025'

def load(p):
    return json.loads(p.read_bytes())

def pin(p):
    return dict(path=p.relative_to(R).as_posix(), bytes=p.stat().st_size,
                sha256=hashlib.sha256(p.read_bytes()).hexdigest())

def normalize(v):
    if isinstance(v, list):
        return [normalize(x) for x in v]
    if isinstance(v, dict):
        return {k: normalize(x) for k, x in v.items()
                if not any(t in k for t in ['seconds', 'tokens_per_second', 'clock_unix', 'unix_ns', 'unix_ms'])}
    return v

def differences(a, b, path=''):
    if type(a) != type(b):
        return [path + ':type']
    if isinstance(a, dict):
        return [path + '/' + k + ':key' for k in a.keys() ^ b.keys()] + [
            x for k in a.keys() & b.keys() for x in differences(a[k], b[k], path + '/' + k)]
    if isinstance(a, list):
        return [path + ':length'] if len(a) != len(b) else [
            x for i, (v, w) in enumerate(zip(a, b)) for x in differences(v, w, path + '/' + str(i))]
    return [] if a == b else [path]

r = load(W / 'ready.json')
for arm in ['baseline', 'candidate']:
    for k in ['image', 'app', 'native', 'main', 'link_inputs', 'dependency_pins', 'runtime']:
        q = r[arm][k]
        p = Path(q['path'])
        actual = pin(p)
        assert (actual['bytes'], actual['sha256']) == (q['bytes'], q['sha256']), (arm, k)
maps = [load(Path(r[arm]['link_inputs']['path']))['actual_inputs'] for arm in ['baseline', 'candidate']]
assert len(maps[0]) == len(maps[1]) == 231
assert [i for i, (a, b) in enumerate(zip(*maps)) if a != b] == [229]
reports = []
raw = []
for arm in ['baseline', 'candidate']:
    p = W / 'pair1' / arm / 'stdout.log'
    text = p.read_text(encoding='utf-8')
    reports.append(json.JSONDecoder().raw_decode(text[text.index('{"source_id"'):])[0])
    raw.append(pin(p))
    assert load(W / 'pair1' / arm / 'process.json')['exit'] == 0
d = differences(*[normalize(x) for x in reports])
assert d == [], d
assert hashlib.sha256((R / 'engine/models/qwen35/main.cc').read_bytes()).hexdigest() == r['baseline']['main']['sha256']
out = dict(status='PASS_FINITE_READY_AND_VISIBLE_WORK_REVIEW', raw=raw,
           all_non_time_report_differences=d, retained_time_exclusions=[
               'seconds', 'tokens_per_second', 'clock_unix', 'unix_ns', 'unix_ms'],
           non_time_exclusions=[], common_link_inputs=230,
           canonical_unchanged=True, no_extra_native_process=True,
           limitations=[
               'Full reported IDs, ledger, RNG cursors and visible state facts agree; unreported tensor values and old-reader fault behavior are not certified.',
               'Same diagnostic Graph on both sides. No TPS claim from these two processes; no new stochastic coverage.'])
target = Path(__file__).with_name('fixed-ingress-pair-root-review.json')
target.write_text(json.dumps(out, indent=2) + '\n', encoding='utf-8', newline='\n')
print(json.dumps(out, indent=2))
