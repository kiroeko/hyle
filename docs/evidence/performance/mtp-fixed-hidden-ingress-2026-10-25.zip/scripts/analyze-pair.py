"""Offline normal CLI and complete BIND comparison. No native work."""
from collections import Counter, defaultdict
from pathlib import Path
import hashlib
import json
import re

R=Path.cwd(); W=Path(__file__).resolve().parent; P=W/'pair1'
def save(p,v):p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8',newline='\n')
def pin(p):return dict(path=p.relative_to(R).as_posix(),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def report(p):
    s=p.read_text();return json.JSONDecoder().raw_decode(s[s.index('{"source_id"'):])[0]
def normalize(v,path='',removed=None):
    if isinstance(v,dict):
        result={}
        for k,x in v.items():
            key=path+'.'+k
            if any(t in k for t in ('seconds','tokens_per_second','clock_unix','unix_ns','unix_ms')):
                if removed is not None:removed.append(key)
            else:result[k]=normalize(x,key,removed)
        return result
    if isinstance(v,list):return [normalize(x,path+'['+str(i)+']',removed)for i,x in enumerate(v)]
    return v
def diff(a,b,path=''):
    if type(a)!=type(b):return [dict(path=path,baseline=a,candidate=b)]
    if isinstance(a,dict):
        out=[]
        for k in sorted(set(a)|set(b)):
            if k not in a or k not in b:out.append(dict(path=path+'.'+k,baseline=a.get(k),candidate=b.get(k)))
            else:out.extend(diff(a[k],b[k],path+'.'+k))
        return out
    if isinstance(a,list):
        if len(a)!=len(b):return [dict(path=path+'.length',baseline=len(a),candidate=len(b))]
        return [v for i,(x,y)in enumerate(zip(a,b))for v in diff(x,y,path+'['+str(i)+']')]
    return [] if a==b else [dict(path=path,baseline=a,candidate=b)]
def kv(line):
    result={}
    for key,value in re.findall(r'(\w+)=([^\s]*)',line):
        if key in ('dims','strides'):result[key]=[int(v)for v in value.split(',')if v]
        else:
            try:result[key]=int(value)
            except ValueError:result[key]=value
    return result
def read_bind(side):
    folder=P/side
    lines=(folder/'stderr.log').read_text().splitlines()
    header=next(kv(x)for x in lines if x.startswith('BIND_POD '))
    end=next(kv(x)for x in lines if x.startswith('BIND_END '))
    events=[kv(x)for x in lines if x.startswith('BIND_EVENT ')]
    ports=[kv(x)for x in lines if x.startswith('BIND_PORT ')]
    descriptions=defaultdict(dict)
    for x in lines:
        if x.startswith('BIND_DESC '):
            d=kv(x);side_name=d.pop('side');descriptions[d['diff']][side_name]=d
    for port in ports:
        assert set(descriptions[port['i']])=={'old','new'}
        port.update(descriptions[port['i']])
    assert header['event_overflow']==header['difference_overflow']==header['concurrent_skips']==0
    assert len(events)==header['events']==end['events']
    assert len(ports)==header['differences']==end['differences']
    assert [x['i']for x in events]==list(range(len(events)))
    assert [x['i']for x in ports]==list(range(len(ports)))
    by_event=defaultdict(list)
    for port in ports:by_event[port['event']].append(port)
    for event in events:
        if event['kind']==3:
            assert event['expected_ports']==event['cached_ports']==event['examined']
            assert event['equal']+event['changed']==event['examined']
            assert not event['missing_old'] and not event['extra_old']
            assert event['changed']==len(by_event[event['i']])
    # seq is zero in these normal apps. A range-candidate starts a distinct
    # decision; only its original invocation/range and terminal outcome bind it.
    opened={};decisions=[]
    for event in events:
        key=(event['inv'],event['begin'],event['count'])
        kind=event['kind']
        if kind==0:
            assert key not in opened, (key,event['i'])
            opened[key]=[event]
        elif kind in (1,2,3,4,5,8,9):
            # prepare_replay's already-retained fast path returns before the
            # candidate-loop start event (executable.cc:9793-9801).
            if kind==5 and key not in opened:opened[key]=[]
            assert key in opened,(key,event['i'],kind)
            opened[key].append(event)
            if kind in (4,5,9):
                group=opened.pop(key)
                decisions.append(dict(inv=key[0],begin=key[1],count=key[2],
                    first_event=group[0]['i'],last_event=event['i'],
                    outcome={4:'variant_hit',5:'retained_hit',9:'recorded'}[kind],
                    mismatch_events=[x['i']for x in group if x['kind']==3],
                    record_seed=[x['seed']for x in group if x['kind']==8]))
    assert not opened,opened
    ranges={}
    for begin,count in sorted({(d['begin'],d['count'])for d in decisions}):
        ds=[d for d in decisions if(d['begin'],d['count'])==(begin,count)]
        invalid=[e for e in events if e['kind']==7 and(e['begin'],e['count'])==(begin,count)]
        ranges[str((begin,count))]=dict(decisions=len(ds),outcomes=dict(Counter(d['outcome']for d in ds)),
            invocations={str(inv):dict(Counter(d['outcome']for d in ds if d['inv']==inv))for inv in sorted({d['inv']for d in ds})},
            invalidations_by_disposition=dict(Counter(e['aux']for e in invalid)),
            comparable_mismatch_events=sum(len(d['mismatch_events'])for d in ds),
            recorded_seed=dict(Counter(str(v)for d in ds if d['outcome']=='recorded'for v in d['record_seed'])))
    def shape(port):
        d=port['new'];return ('output' if port['output']else'input')+'/'+str(d['type'])+'/'+str(d['dims'])
    front_ports=[port for port in ports if events[port['event']]['begin']==0]
    full=dict(header=header,end=end,events=events,ports=ports,decisions=decisions)
    save(P/(side+'-bind-records.json'),full)
    return dict(header=header,end=end,outcomes=dict(Counter(d['outcome']for d in decisions)),
        decision_count=len(decisions),ranges=ranges,front_changed_port_classes=dict(Counter(shape(p)for p in front_ports)),
        all_changed_port_classes=dict(Counter(shape(p)for p in ports)),
        events_by_kind=dict(Counter(e['kind']for e in events)),FINISH_META_count=sum(x.startswith('FINISH_META ')for x in lines),
        logical_sequences=sorted({e['seq']for e in events}),
        records=pin(P/(side+'-bind-records.json')))

a=report(P/'baseline/stdout.log');b=report(P/'candidate/stdout.log')
removed=[];na=normalize(a,removed=removed);nb=normalize(b)
differences=diff(na,nb)
capture_names={'capture_recorded','capture_reused','recorded_capture_range_count','reused_capture_range_count'}
allowed=[x for x in differences if x['path'].rsplit('.',1)[-1]in capture_names]
unexpected=[x for x in differences if x not in allowed]
save(P/'cli-comparison.json',dict(status='PASS'if not unexpected else'FAIL',difference_count=len(differences),
    allowed_capture_statistics=allowed,unexpected=unexpected,excluded_time_paths=removed,
    exclusion_rules=['seconds','tokens_per_second','clock_unix','unix_ns','unix_ms'],
    no_payload_or_state_exclusions=True,baseline_raw=pin(P/'baseline/stdout.log'),candidate_raw=pin(P/'candidate/stdout.log')))
binds={side:read_bind(side)for side in ('baseline','candidate')}
facts={k:a[k]for k in ['source_id','generated_tokens','actual_graph_calls','prefill_graph_calls','decode_graph_calls',
    'logical_prompt_tokens','actual_target_rows','committed_target_rows','actual_draft_rows','agreements','consumed_drafts',
    'cache_live_requested_bytes','cache_peak_requested_bytes']}
sessions=a.get('sessions',[])
out=dict(status='PASS_VISIBLE_CLI_AND_MECHANISM'if not unexpected else'FAILED_VISIBLE_COMPARISON',
    GPU_processes=2,GPU_released=True,additional_runs=0,profiler_runs=0,TPS_claim=False,
    processes={s:json.loads((P/s/'process.json').read_text())for s in binds},
    CLI=dict(unexpected_non_time_differences=unexpected,allowed_capture_statistics=allowed,
             facts=facts,session_count=len(sessions),all_other_non_time_fields_equal=not unexpected),
    binding=binds,
    state_evidence=dict(visible='All normally emitted nested session/turn/episode ledger fields, committed input IDs, pending IDs, target/draft frontier/lag, quotas and RNG identities/cursors compared recursively.',
        payload_bitwise_equality='UNKNOWN: no complete KV/GDN/hidden device payload hashes or dumps requested.',
        old_reader_cancel_unknown_native_failure='NOT_EXERCISED by this unchanged two-turn case; source-only contracts, no fault injection.',
        no_FINISH_META_required=True),
    copy_bytes=dict(source_derived_only=True,programmed_per_R1_no_lag_round=4096,
        programmed_per_R1_lag1_round=8192,R1_both_round_slots_cold_payload=12288,
        physical_API_calls_or_bandwidth_sampled=False))
save(P/'summary.json',out)
print(json.dumps(dict(status=out['status'],CLI_difference_count=len(differences),
    allowed_capture_difference_count=len(allowed),unexpected_non_time_count=len(unexpected),facts=facts,
    binding={s:{k:d[k]for k in ['decision_count','outcomes','ranges','front_changed_port_classes','logical_sequences','FINISH_META_count']}for s,d in binds.items()},
    state_evidence=out['state_evidence']),indent=2))
assert not unexpected,unexpected
