"""One authorized six-process alternating clean screen; stop on first failure."""
from pathlib import Path
import datetime
import importlib.util
import json
import os
import re
import statistics
import subprocess
import sys

sys.dont_write_bytecode=True
R=Path.cwd();W=Path(__file__).resolve().parent;D=W/'screen1'
spec=importlib.util.spec_from_file_location('retained',R/'.scratch/mtp-extraction-regression-20261024/check.py')
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
ready=b.read(W/'clean-ready.json')
def read_report(p):
    s=p.read_text();return json.JSONDecoder().raw_decode(s[s.index('{"source_id"'):])[0]
def normalize(v):
    if isinstance(v,dict):return {k:normalize(x)for k,x in v.items()if not any(t in k for t in('seconds','tokens_per_second','clock_unix','unix_ns','unix_ms'))}
    if isinstance(v,list):return [normalize(x)for x in v]
    return v
def differences(a,c,path=''):
    if type(a)!=type(c):return [dict(path=path,baseline=a,candidate=c)]
    if isinstance(a,dict):
        out=[]
        for k in sorted(set(a)|set(c)):
            if k not in a or k not in c:out.append(dict(path=path+'.'+k,baseline=a.get(k),candidate=c.get(k)))
            else:out.extend(differences(a[k],c[k],path+'.'+k))
        return out
    if isinstance(a,list):
        if len(a)!=len(c):return [dict(path=path+'.length',baseline=len(a),candidate=len(c))]
        return [v for i,(x,y)in enumerate(zip(a,c))for v in differences(x,y,path+'['+str(i)+']')]
    return []if a==c else[dict(path=path,baseline=a,candidate=c)]
D.mkdir(exist_ok=False)
base=normalize(read_report(W/'pair1/baseline/stdout.log'))
template=R/'.scratch/mtp-complete-binding-diff-20261025/run2/command.json'
original=b.args(template)
runtime=R/'.scratch/mtp-performance-convergence-20261025/baseline/runtime.json'
order=['baseline','candidate','candidate','baseline','baseline','candidate']
b.save(D/'plan.json',dict(order=order,case=b.pin(template),runtime=b.pin(runtime),
    ready=b.pin(W/'clean-ready.json'),watchdog_seconds=120,per_process_same_argv_tail=True,
    baseline_behavior=b.pin(W/'pair1/baseline/stdout.log'),profiler=False,memory_side_sampling=False,
    time_exclusions=['seconds','tokens_per_second','clock_unix','unix_ns','unix_ms'],non_time_exclusions=[]))
for side in ('baseline','candidate'):
    for key in('image','main','app','native','graph'):
        row=ready[side][key];assert b.pin(Path(row['path']))==row
rows=[]
for index,side in enumerate(order,1):
    command=original.copy();command[0]=ready[side]['image']['path']
    env=os.environ.copy();env['PATH']=str(Path(command[0]).parent)+';'+b.read(runtime)['PATH']
    env.update(HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1')
    gpu_command=['nvidia-smi','--query-compute-apps=pid,process_name,used_gpu_memory','--format=csv,noheader']
    gpu=subprocess.run(gpu_command,env=env,capture_output=True,text=True,creationflags=subprocess.CREATE_NO_WINDOW,timeout=20)
    assert gpu.returncode==0,gpu.stderr
    known={'hyle.exe','peer.exe','consumer.exe','probe.exe','recursive-probe.exe','llama-cli.exe','llama-server.exe','llama-bench.exe','python.exe','pythonw.exe'}
    active=[s for s in gpu.stdout.splitlines()if len(s.split(','))>=2 and(
        Path(s.split(',')[1].strip()).name.lower()in known or str(R).lower()in s.lower())]
    assert not active,active
    folder=D/(str(index).zfill(2)+'-'+side)
    b.save(D/(str(index).zfill(2)+'-start.json'),dict(start_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        side=side,image=ready[side]['image'],gpu_preflight=dict(exit=gpu.returncode,inference=active),
        template=b.pin(template),ready=b.pin(W/'clean-ready.json')))
    b.execute(command,folder,env,120)
    actual=read_report(folder/'stdout.log');delta=differences(base,normalize(actual))
    stderr=(folder/'stderr.log').read_text(errors='replace')
    assert 'BIND_POD 'not in stderr and 'FINISH_META 'not in stderr
    gate=dict(status='PASS'if not delta else'FAIL',all_non_time_differences=delta,
        stdout=b.pin(folder/'stdout.log'),stderr=b.pin(folder/'stderr.log'),
        only_time_exclusions=True,unreported_tensor_values='UNKNOWN',
        process=b.read(folder/'process.json'))
    b.save(folder/'gate.json',gate)
    if delta:raise SystemExit('STOP: non-time behavior differs; see '+str(folder/'gate.json'))
    keys=['prefill_seconds','decode_seconds','session_seconds','prefill_tokens_per_second',
          'decode_output_tokens_per_second','output_tokens_per_second']
    row=dict(index=index,side=side,**{k:actual[k]for k in keys},process_seconds=gate['process']['seconds'],
        source_stdout=gate['stdout'],source_stderr=gate['stderr'],non_time_difference_count=0)
    rows.append(row);b.save(D/'rows.json',rows)
groups={}
for side in('baseline','candidate'):
    selected=[r for r in rows if r['side']==side]
    groups[side]={key:dict(values=[r[key]for r in selected],median=statistics.median(r[key]for r in selected),
        minimum=min(r[key]for r in selected),maximum=max(r[key]for r in selected))for key in keys}
change={key:100*(groups['candidate'][key]['median']/groups['baseline'][key]['median']-1)
    for key in keys if key.endswith('per_second')}
summary=dict(status='SIX_PROCESS_FINITE_SCREEN_PASS',order=order,rows=rows,groups=groups,
    median_throughput_change_percent=change,non_time_differences=0,GPU_processes=6,GPU_released=True,
    profiler=False,memory_side_sampling=False,peer_comparison=False,full_four_metric_window=False,
    copy_submission_wait_and_default_logging_included=True,
    limitations=['Only three samples per current arm, one original case; no stable speed or broad-context claim.',
                'No new VRAM/RAM observation or peer runs.',
                'Complete unreported device tensor values/old-reader cancellation faults remain unverified.'])
b.save(D/'summary.json',summary)
print(json.dumps(dict(status=summary['status'],median_throughput_change_percent=change,
    groups=groups,GPU_released=True),indent=2))
