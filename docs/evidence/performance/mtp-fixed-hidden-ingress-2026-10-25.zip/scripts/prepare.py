from pathlib import Path
import difflib
import hashlib
import json
import shutil

R = Path.cwd()
W = R / '.scratch/mtp-fixed-hidden-ingress-20261025'
B, S = W / 'before', W / 'source'
expected = '75d4d9cb214602a5971fd5f8abe5d9563b86bcbb2575fa7d7ce76e12ce8035c9'
main = R / 'engine/models/qwen35/main.cc'
assert hashlib.sha256(main.read_bytes()).hexdigest() == expected
assert not B.exists() and not S.exists()

files = [main, *(R/'engine/models/qwen35').glob('*.h'),
         *(R/'engine/inference').glob('*.h'), R/'engine/reporting/execution_report.h',
         R/'engine/reporting/execution_report.cc']
def pin(p):
    return dict(path=str(p.relative_to(R)), bytes=p.stat().st_size,
                sha256=hashlib.sha256(p.read_bytes()).hexdigest())
for p in files:
    for dest in (B, S):
        q = dest / p.relative_to(R)
        q.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(p, q)
(W/'before-pins.json').write_text(json.dumps([pin(p) for p in files], indent=2)+'\n')

p = S/'engine/models/qwen35/main.cc'
t = p.read_text(encoding='utf-8')
old = t
def replace(a, b):
    global t
    assert t.count(a) == 1, a[:100]
    t = t.replace(a, b)

replace('#include "hyle/compute/model_ops.h"',
'''#include "hyle/compute/model_ops.h"
#include "hyle/compute/batch_transfer.h"
#include "hyle/compute/detail/copy_stream_access.h"''')

replace('''using ResourceRetention = inference::RetainedResources<ColdResources>;
struct Phase final : FamilyPorts {''',
'''using ResourceRetention = inference::RetainedResources<ColdResources>;
void record_retirement_status(hyle::Status &, const hyle::Status &) noexcept;

// Fixed caller scratch only, never a Snapshot or a cache state owner. The
// original copy control owns its writers until actual successful retirement.
struct HiddenIngress final {
  std::vector<Tensor> inputs;
  std::vector<c::CopyRange> ranges;
  c::CopyBatchProgram program;
  c::CopyBatchInvocation invocation;
  c::CopyBatchUpdate update;
  bool recreate = false;

  hyle::Result<bool> recover(hyle::Status &terminal) noexcept {
    if (update.valid()) {
      const auto observed = update.observe();
      record_retirement_status(terminal, observed);
      if (update.in_flight()) return false;
      recreate = recreate || !observed.ok();
      HYLE_ASSIGN_OR_RETURN(invocation, update.release_invocation());
    }
    if (!invocation.valid()) return true;
    if (invocation.in_flight()) return false;
    for (std::size_t i = 0; i < inputs.size(); ++i) if (!recreate && !inputs[i].writer) {
      auto returned = invocation.unbind_mutable(ranges[i].destination);
      if (returned) inputs[i].writer = std::move(*returned);
      else {
        if (returned.error().IsUnavailable()) return false;
        record_retirement_status(terminal, returned.error());
        recreate = true;
      }
    }
    HYLE_RETURN_IF_ERROR(invocation.reset());
    // A failed/closed F2 control cannot be reopened by reset. Cold recreation
    // uses the same program/pools only after every original use has retired.
    if (recreate) invocation = {};
    return true;
  }
};
struct Phase final : FamilyPorts {''')

replace('''  std::array<ResourceRetention, execution_slot_count> retirement;
  std::array<std::size_t, execution_slot_count> planned_slot_uses{};''',
'''  std::array<ResourceRetention, execution_slot_count> retirement;
  std::array<HiddenIngress, execution_slot_count> hidden_ingress;
  std::array<std::size_t, execution_slot_count> planned_slot_uses{};''')

replace('''  Phase *phase = nullptr;
  c::Completion completion;''',
'''  Phase *phase = nullptr;
  HiddenIngress *hidden_ingress = nullptr;
  c::Completion completion;''')

replace('''  hyle::Result<bool> try_abort() noexcept {
    if (completion.valid()) {''',
'''  hyle::Result<bool> try_abort() noexcept {
    if (hidden_ingress) {
      HYLE_ASSIGN_OR_RETURN(auto retired, hidden_ingress->recover(terminal));
      if (!retired) return false;
      hidden_ingress = nullptr;
    }
    if (completion.valid()) {''')

replace('''        (void)shape; for (auto &run : phase->slots) run = {};
      }
    for (auto &[shape, program] : draft_programs)''',
'''        (void)shape; for (auto &run : phase->slots) run = {};
        // Original copy retirement owns late descriptors/writers and its
        // attached cold scope after these application roots are withdrawn.
        for (auto &ingress : phase->hidden_ingress) { ingress.update = {}; ingress.invocation = {}; }
      }
    for (auto &[shape, program] : draft_programs)''')

replace('''  void initialize_slot(Phase &phase, std::size_t slot) {
    if (phase.slots[slot].valid()) return;''',
'''  void initialize_hidden_ingress(Phase &phase, std::size_t slot) {
    // This private counterfactual targets only the observed CUDA K1 capture
    // ingress. Ordinary/prefill/recursive roles and all output storage stay
    // on their original routes, including explicit commands-only execution.
    if (!drafts_token(phase.family->role) || execution.kind() != BackendKind::kCuda ||
        phase.replay_modes[slot] != g::ReplayMode::kPreferCapture) return;
    auto &ingress = phase.hidden_ingress[slot];
    const auto description = dense(precision.activation_type(), {1, hidden});
    const auto bytes = take(description.required_bytes());
    const auto count = cache::multiply(phase.family->requests, 1 + draft_lag(phase.family->role));
    if (count > UINT32_MAX / 2) throw std::runtime_error("hidden ingress copy capacity overflow");
    if (!ingress.program.valid()) {
      std::vector<Tensor> inputs;
      std::vector<c::CopyRange> ranges;
      std::vector<c::CopyResourceSpec> specs;
      inputs.reserve(count); ranges.reserve(count); specs.reserve(count * 2);
      for (std::size_t i = 0; i < count; ++i) {
        Tensor value;
        value.description = description;
        value.pool = take(c::LeasePool::create(execution.device(), bytes,
            {.max_blocks = 1, .backing_alignment = cache::state_pool_alignment,
             .resource_budget = allocation_budget}));
        value.writer = take(value.pool.allocate(bytes, cache::state_pool_alignment));
        inputs.push_back(std::move(value));
        specs.push_back({execution.device(), bytes}); specs.push_back({execution.device(), bytes});
        ranges.push_back({{static_cast<std::uint32_t>(i * 2)}, {static_cast<std::uint32_t>(i * 2 + 1)}, {0}, 0, 0, bytes});
      }
      auto program = take(c::CopyBatchProgram::prepare(*take(execution.common_context()), specs,
          {.max_resources = static_cast<std::uint32_t>(count * 2),
           .max_copies = static_cast<std::uint32_t>(count), .max_phases = 1,
           .max_bytes = cache::multiply(count, bytes), .resource_budget = execution_budget}));
      auto invocation = take(c::CopyBatchInvocation::create(program, *take(execution.common_queue())));
      ingress.inputs = std::move(inputs); ingress.ranges = std::move(ranges);
      ingress.program = std::move(program); ingress.invocation = std::move(invocation);
    } else if (!ingress.invocation.valid()) {
      ingress.invocation = take(c::CopyBatchInvocation::create(ingress.program, *take(execution.common_queue())));
      ingress.recreate = false;
    }
    for (auto &value : ingress.inputs) if (!value.writer)
      value.writer = take(value.pool.allocate(bytes, cache::state_pool_alignment));
  }

  void initialize_slot(Phase &phase, std::size_t slot) {
    if (phase.slots[slot].valid()) return;
    initialize_hidden_ingress(phase, slot);''')

replace('''    hyle::Status terminal;
    if (active_step->run) terminal = execution.drain_retired(*active_step->run);''',
'''    hyle::Status terminal;
    if (active_step->hidden_ingress && active_step->hidden_ingress->update.valid())
      record_retirement_status(terminal, active_step->hidden_ingress->update.wait());
    if (active_step->run) record_retirement_status(terminal, execution.drain_retired(*active_step->run));''')

replace('''  void prepare_draft_append(StepState &step, GraphRole role) {
    auto &phase = *step.phase; auto &run = *step.run;''',
'''  void copy_hidden_ingress(StepState &step, GraphRole role) {
    auto &phase = *step.phase;
    auto &ingress = phase.hidden_ingress[slot_index];
    if (!ingress.program.valid()) return;
    step.hidden_ingress = &ingress;
    std::size_t index = 0;
    for (const auto &member : step.members) {
      check(ingress.invocation.bind_source(ingress.ranges[index].source, member.base->carry_hidden));
      check(ingress.invocation.bind_mutable(ingress.ranges[index].destination, std::move(ingress.inputs[index].writer)));
      ++index;
      if (draft_lag(role)) {
        check(ingress.invocation.bind_source(ingress.ranges[index].source, member.base->prior_hidden));
        check(ingress.invocation.bind_mutable(ingress.ranges[index].destination, std::move(ingress.inputs[index].writer)));
        ++index;
      }
    }
    constexpr std::array<c::CopyPhase, 1> copy_phases{};
    check(ingress.invocation.prepare_replay(copy_phases, ingress.ranges));
    auto &retention = phase.retirement[slot_index];
    check(retention.reserve(resources_));
    auto submitted = ingress.invocation.submit();
    if (!submitted) { retention.reject(); (void)take(std::move(submitted)); }
    ingress.update = take(c::CopyBatchUpdate::take(std::move(ingress.invocation), std::move(*submitted)));
    std::array<c::Completion *, 1> source;
    if (take(c::detail::CopyStreamAccess::retirement_sources(ingress.update, source)) != 1)
      throw std::runtime_error("hidden ingress requires its original one-phase completion");
    check(retention.attach(*source[0]));
    check(ingress.update.wait());
    hyle::Status terminal;
    if (!take(ingress.recover(terminal))) throw std::runtime_error("hidden ingress still retains native work");
    check(terminal);
    step.hidden_ingress = nullptr;
  }

  void prepare_draft_append(StepState &step, GraphRole role) {
    auto &phase = *step.phase; auto &run = *step.run;
    copy_hidden_ingress(step, role);''')

replace('''      const auto &ports = phase.draft_hidden_inputs[j];
      check(run.bind(ports[0], dense(precision.activation_type(), {1, hidden}), member.base->carry_hidden));
      if (draft_lag(role)) {
        catchups.push_back(old.catchup_token);
        check(run.bind(ports[1], dense(precision.activation_type(), {1, hidden}), member.base->prior_hidden));
      }''',
'''      const auto &ports = phase.draft_hidden_inputs[j];
      auto &ingress = phase.hidden_ingress[slot_index];
      if (ingress.program.valid()) check(run.bind(ports[0], ingress.inputs[j * (1 + draft_lag(role))].read()));
      else check(run.bind(ports[0], dense(precision.activation_type(), {1, hidden}), member.base->carry_hidden));
      if (draft_lag(role)) {
        catchups.push_back(old.catchup_token);
        if (ingress.program.valid()) check(run.bind(ports[1], ingress.inputs[j * 2 + 1].read()));
        else check(run.bind(ports[1], dense(precision.activation_type(), {1, hidden}), member.base->prior_hidden));
      }''')

replace('''    pending->cancelled = true;
    if (pending->completion.valid()) {''',
'''    pending->cancelled = true;
    if (pending->hidden_ingress && pending->hidden_ingress->update.valid()) {
      pending->hidden_ingress->recreate = true;
      const auto cancelled = pending->hidden_ingress->update.request_cancel();
      if (!cancelled.IsUnimplemented()) record_retirement_status(retirement_status, cancelled);
    }
    if (pending->completion.valid()) {''')

p.write_text(t, encoding='utf-8', newline='\n')
(W/'source.patch').write_text(''.join(difflib.unified_diff(old.splitlines(True), t.splitlines(True),
    fromfile='a/engine/models/qwen35/main.cc', tofile='b/engine/models/qwen35/main.cc')), encoding='utf-8', newline='\n')
(W/'after-pins.json').write_text(json.dumps([pin(S/q.relative_to(R)) for q in files], indent=2)+'\n')

def section(text, start, end):
    return text[text.index(start):text.index(end, text.index(start))]
checks = {}
for name, start, end in [
    ('family_math', '  void prepare_family(', '  void admit_exact_shape('),
    ('completed_publication', '  template<class Select, class Complete, class Observe>', '\n// Entry IO runs synchronously'),
    ('request_runner', 'PreparedGenerationCall prepare_generation_call(', '\nbool make_generation_batch_room('),
]:
    try:
        checks[name] = section(old, start, end) == section(t, start, end)
    except ValueError:
        checks[name] = 'manual section anchors required'
checks['canonical_unchanged'] = hashlib.sha256(main.read_bytes()).hexdigest() == expected
checks['only_main_changed'] = all((S/f.relative_to(R)).read_bytes() == (B/f.relative_to(R)).read_bytes() for f in files if f != main)
(W/'source-checks.json').write_text(json.dumps(checks, indent=2)+'\n')
print(json.dumps({'changed_source': pin(p), 'closure_files': len(files), 'checks': checks}, indent=2))
