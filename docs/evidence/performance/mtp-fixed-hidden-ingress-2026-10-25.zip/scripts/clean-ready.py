from pathlib import Path
import importlib.util
import sys
sys.dont_write_bytecode=True
R=Path.cwd();W=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('retained',R/'.scratch/mtp-extraction-regression-20261024/check.py')
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
ready={s:b.read(W/'clean1'/s/'ready.json')for s in('baseline','candidate')}
maps={s:b.read(W/'clean1'/s/'link-inputs.json')for s in ready}
differences=[]
for i,(x,y)in enumerate(zip(maps['baseline']['actual_inputs'],maps['candidate']['actual_inputs'])):
    if x!=y:differences.append(dict(index=i,baseline=x,candidate=y))
assert len(differences)==1
for s in ready:
    for key in('image','app','main','native','graph','graph_source'):
        p=ready[s][key];assert b.pin(Path(p['path']))==p
    assert ready[s]['compile_processes']==0 and ready[s]['link_process']['exit']==0
b.save(W/'clean-ready.json',dict(status='CLEAN_LINK_READY_GPU_NOT_RUN',**ready,
    link_input_count=231,common_non_app_inputs=230,differing_inputs=differences,
    retained_app_objects_from_diagnostic_pair=True,compiled_app_instrumentation=False,
    new_compile_processes=0,new_link_processes=2,new_GPU_processes=0,
    graph2_source_equals_canonical=True,TPS_result=False))
print('CLEAN_READY')
