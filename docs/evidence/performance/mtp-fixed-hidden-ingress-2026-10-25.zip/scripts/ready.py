"""Freeze the checked pair. Does not execute either image."""
from pathlib import Path
import difflib
import hashlib
import importlib.util
import json
import shutil
import sys

sys.dont_write_bytecode = True
R = Path.cwd()
W = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('retained', R/'.scratch/mtp-extraction-regression-20261024/check.py')
b = importlib.util.module_from_spec(spec)
spec.loader.exec_module(b)
base = W/'build1/baseline'
cand = W/'build2/candidate'
relative = Path('engine/models/qwen35/main.cc')
canonical = R/relative
assert b.pin(canonical)['sha256'] == '75d4d9cb214602a5971fd5f8abe5d9563b86bcbb2575fa7d7ce76e12ce8035c9'

old_summary = W/'history/df24-source-only-summary.json'
if not old_summary.exists():
    shutil.copyfile(W/'summary.json', old_summary)
before = (W/'before'/relative).read_text(encoding='utf-8')
after = (W/'source'/relative).read_text(encoding='utf-8')
assert b.pin(W/'source'/relative)['sha256'] == '1f62dbdc38a4fab786aea475c971de07382e5c47582a3b8a548e04f259bde31b'
assert before == canonical.read_text(encoding='utf-8')
(W/'source.patch').write_text(''.join(difflib.unified_diff(before.splitlines(True), after.splitlines(True),
    fromfile='a/'+relative.as_posix(), tofile='b/'+relative.as_posix())), encoding='utf-8', newline='\n')
sources = sorted(q for q in (W/'source').rglob('*') if q.is_file())
b.save(W/'after-pins.json', [b.pin(q) for q in sources])

ready = {'baseline': b.read(base/'ready.json'), 'candidate': b.read(cand/'ready.json')}
maps = [b.read(q/'link-inputs.json') for q in (base,cand)]
assert len(maps[0]['actual_inputs']) == len(maps[1]['actual_inputs']) == 231
differences = []
for i, (x, y) in enumerate(zip(maps[0]['actual_inputs'], maps[1]['actual_inputs'])):
    if x != y:
        differences.append(dict(index=i, baseline=x, candidate=y))
    for row in (x,y):
        assert all(b.pin(Path(row['path']))[key] == row[key] for key in ('path','bytes','sha256'))
assert len(differences) == 1, differences
assert differences[0]['baseline']['path'] == ready['baseline']['app']['path']
assert differences[0]['candidate']['path'] == ready['candidate']['app']['path']

runtime = R/'.scratch/mtp-performance-convergence-20261025/baseline/runtime.json'
runtime_base = b.read(runtime)
for name, folder in [('baseline',base),('candidate',cand)]:
    value = ready[name]
    for key in ('image','app','native','main'):
        assert b.pin(Path(value[key]['path'])) == value[key]
    for row in b.read(folder/'compile/repository-inputs.json'):
        assert b.pin(Path(row['path'])) == row
    b.save(folder/'runtime.json', dict(PATH=str(folder/'link')+';'+runtime_base['PATH'],
        parent=b.pin(runtime), native=value['native'], offline_only=True, GPU_executed=False))
    value['runtime'] = b.pin(folder/'runtime.json')
    value['compile'] = b.read(folder/'compile/process.json')
    value['link'] = b.read(folder/'link/process.json')

checks = b.read(W/'source-checks.json')
checks['source_only_rename_after_first_compile'] = (
    (W/'build1/candidate/failed-input-main.cc').read_text(encoding='utf-8').replace(
        'constexpr std::array<c::CopyPhase, 1> phases{};',
        'constexpr std::array<c::CopyPhase, 1> copy_phases{};').replace(
        'ingress.invocation.prepare_replay(phases, ingress.ranges)',
        'ingress.invocation.prepare_replay(copy_phases, ingress.ranges)') == after)
assert all(checks.values()), checks
b.save(W/'source-checks.json', checks)
summary = dict(status='READY_COMPILED_LINKED_GPU_NOT_RUN', baseline=ready['baseline'],
    candidate=ready['candidate'], baseline_canonical=b.pin(canonical),
    strict='MSVC /W4 /WX /O2; same flags on both current app TUs',
    link_input_count=231, shared_non_app_inputs=230, common_object_count=maps[0]['object_count'],
    differing_link_inputs=differences, common_graph=maps[0]['diagnostic_graph'],
    common_template=maps[0]['template'], same_diagnostic_graph_on_both=True,
    source_checks=checks,
    first_failure=dict(kind='candidate local CopyPhase variable phases shadows Model::phases; C4458 under /WX',
        process=b.read(W/'build1/candidate/compile/process.json'),
        input=b.pin(W/'build1/candidate/failed-input-main.cc'),
        correction='Rename only to copy_phases; no logic/geometry/precision/ownership change'),
    SDK_builds=0, core_builds=0, graph_builds=0, CUDA_provider_builds=0,
    app_compile_processes=3, app_link_processes=2, GPU_processes=0, HTTP_requests=0,
    claim='Behavior/mechanism images only; no throughput result',
    parser_contract='Current non-instrumented app: no old FINISH_META requirement, logical sequence may be zero. Compare full same-Graph BIND geometry and normal CLI state/ledger/RNG/output facts.',
    source_derived_copy_bytes=dict(no_lag_per_R1_round=4096, lag1_per_R1_round=8192,
        R1_both_round_slots_cold_payload=12288, physical_API_calls_or_bandwidth_measured=False))
b.save(W/'ready.json', summary)
b.save(W/'summary.json', summary)
review = W/'self-review.md'
x = review.read_text().replace('df24a6a05a7e5cb2d65c342005523d056d47c4613263d5f339d374912e1cd05c',
    '1f62dbdc38a4fab786aea475c971de07382e5c47582a3b8a548e04f259bde31b')
x = x.replace('No canonical write, compiler, linker, model process, GPU, or HTTP was used.',
    'Initial source-only review used no compiler/linker. The subsequent authorized pair now passed strict app compilation/linking; candidate first C4458 and its name-only correction remain in build1. No canonical write, model process, GPU, or HTTP was used.')
review.write_text(x, encoding='utf-8', newline='\n')
print(json.dumps(dict(status=summary['status'], baseline=ready['baseline']['image'],
    candidate=ready['candidate']['image'], inputs=231, objects=maps[0]['object_count'],
    differing_inputs=len(differences), graph=maps[0]['diagnostic_graph'], GPU_processes=0),indent=2))
