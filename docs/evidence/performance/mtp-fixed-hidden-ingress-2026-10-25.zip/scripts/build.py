"""Two app TUs only; links reuse one fixed existing diagnostic closure. No run."""
from pathlib import Path
import hashlib
import importlib.util
import json
import os
import sys

sys.dont_write_bytecode = True
R = Path.cwd()
W = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('retained', R/'.scratch/mtp-extraction-regression-20261024/check.py')
b = importlib.util.module_from_spec(spec)
spec.loader.exec_module(b)
EXPECTED = {
    'baseline': ('before', '75d4d9cb214602a5971fd5f8abe5d9563b86bcbb2575fa7d7ce76e12ce8035c9'),
    'candidate': ('source', '1f62dbdc38a4fab786aea475c971de07382e5c47582a3b8a548e04f259bde31b'),
}
REL = Path('engine/models/qwen35/main.cc')
BUILD = W/(sys.argv[3] if len(sys.argv) == 4 else 'build1')
COMPILE_TEMPLATE = R/'.scratch/mtp-performance-convergence-20261025/baseline/compile/command.json'
LINK_TEMPLATE = R/'.scratch/mtp-complete-binding-diff-20261025/link4/command.json'

def norm(s):
    return str(s).lower().replace('\\', '/')

def source(side):
    directory, digest = EXPECTED[side]
    p = W/directory/REL
    assert b.pin(p)['sha256'] == digest
    return W/directory

def compile_one(side):
    root = source(side)
    out = BUILD/side
    out.mkdir(parents=True, exist_ok=True)
    entry = out/'app.cc'
    entry.write_text('#include "engine/models/qwen35/main.cc"\n'
                     'int main(int argc, char **argv) { return qwen35::run(argc, argv); }\n',
                     encoding='utf-8', newline='\n')
    old = b.args(COMPILE_TEMPLATE)
    flags = []
    skip = False
    for word in old[1:]:
        if skip:
            skip = False
            continue
        if word == '/sourceDependencies':
            skip = True
            continue
        n = norm(word)
        if n.startswith(('/fo', '/fd')) or n.endswith(('.cc', '.cpp')):
            continue
        flags.append(word)
    assert '/W4' in flags and '/WX' in flags
    env = b.environment(old[0])
    command = [old[0], '/I'+str(root), *flags, str(entry), '/sourceDependencies',
               str(out/'compile/dependencies.json'), '/Fo'+str(out/'compile/unit.obj'),
               '/Fd'+str(out/'compile/unit.pdb')]
    b.execute(command, out/'compile', env, 180)
    deps = b.read(out/'compile/dependencies.json')['Data']
    repository = [Path(v) for v in [deps['Source'], *deps['Includes']]
                  if Path(v).resolve().is_relative_to(R)]
    leaks = [str(p) for p in repository if p.resolve().is_relative_to(R/'engine')]
    assert not leaks, leaks
    actual_main = [p for p in repository if norm(p).endswith('/engine/models/qwen35/main.cc')]
    assert actual_main == [root/REL], actual_main
    b.save(out/'compile/repository-inputs.json', [b.pin(p) for p in repository])
    b.save(out/'compile/source-identity.json', dict(main=b.pin(root/REL), entry=b.pin(entry),
        template=b.pin(COMPILE_TEMPLATE), compiler=b.pin(Path(old[0])), canonical_engine_leaks=leaks,
        macros=[s for s in flags if s.startswith('/D')], strict_W4_WX=True, SDK_builds=0))

def replacement_map():
    host = R/'.scratch/glm-quark-selected-20261024/Q30/graph-integration-preparation/host1'
    cache = R/'.scratch/inference-cache-shared-source-20261025/attempt1'
    old_core = R/'.scratch/lease-budget-deallocation-order-20261025/implementation/attempt1'
    return {
        norm(R/'.scratch/mtp-finish-phase-20261025/compile/unit.obj'): 'APP',
        norm(old_core/'budget/unit.obj'): str(cache/'budget/unit.obj'),
        norm(old_core/'leases/unit.obj'): str(cache/'leases/unit.obj'),
        norm(host/'compute_batch--paged_arena.obj'): str(cache/'arena/unit.obj'),
        norm(host/'graph--resources.obj'): str(R/'.scratch/inference-native-retention-scopes-20261025/attempt1/resources/unit.obj'),
    }

def link_one(side):
    root = source(side)
    out = BUILD/side
    assert b.read(out/'compile/process.json')['exit'] == 0
    old = b.args(LINK_TEMPLATE)
    replacements = replacement_map()
    seen = {p: 0 for p in replacements}
    flags = []
    mappings = []
    for index, word in enumerate(old[1:], 1):
        n = norm(word)
        if n.startswith(('/out:', '/map:', '/pdb:', '/implib:')):
            continue
        if n in replacements:
            actual = str(out/'compile/unit.obj') if replacements[n] == 'APP' else replacements[n]
            seen[n] += 1
            mappings.append(dict(index=index, before=word, after=b.pin(Path(actual))))
            word = actual
        flags.append(word)
    assert all(v == 1 for v in seen.values()), seen
    objects = [Path(s) for s in flags if s.lower().endswith('.obj')]
    for p in objects:
        assert p.is_file(), str(p)
    graph = R/'.scratch/mtp-complete-binding-diff-20261025/graph4/unit.obj'
    assert sum(norm(p) == norm(graph) for p in objects) == 1
    old_compile = b.args(COMPILE_TEMPLATE)
    env = b.environment(old_compile[0])
    lib_paths = [Path(s) for s in env.get('LIB', '').split(';') if s]
    inputs = []
    for word in flags:
        if not word.lower().endswith(('.obj', '.lib')):
            continue
        p = Path(word)
        if not p.is_file() and not p.is_absolute():
            matches = [q/p for q in lib_paths if (q/p).is_file()]
            if matches:
                p = matches[0]
        assert p.is_file(), word
        inputs.append(dict(argument=word, **b.pin(p)))
    b.save(out/'link-inputs.json', dict(template=b.pin(LINK_TEMPLATE), replacements=mappings,
        diagnostic_graph=b.pin(graph), actual_inputs=inputs, object_count=len(objects),
        input_count=len(inputs), same_common_closure=True, new_app_TUs=1,
        SDK_builds=0, core_builds=0, native_provider_builds=0))
    command = [old[0], *flags, '/OUT:'+str(out/'link/hyle.exe'),
               '/PDB:'+str(out/'link/hyle.pdb'), '/IMPLIB:'+str(out/'link/hyle.lib')]
    b.execute(command, out/'link', env, 120)
    native = R/'.scratch/inference-system-review-20261025/schedule-inputs/link/hyle_ggml_cpu_gdn_scale_v3.dll'
    assert native.is_file()
    os.link(native, out/'link'/native.name)
    b.save(out/'ready.json', dict(image=b.pin(out/'link/hyle.exe'), app=b.pin(out/'compile/unit.obj'),
        native=b.pin(native), main=b.pin(root/REL), link_inputs=b.pin(out/'link-inputs.json'),
        dependency_pins=b.pin(out/'compile/repository-inputs.json'), GPU_run=False,
        diagnostic=True, TPS_claim=False))

assert len(sys.argv) in {3, 4} and sys.argv[1] in {'compile', 'link'} and sys.argv[2] in EXPECTED
if sys.argv[1] == 'compile':
    compile_one(sys.argv[2])
else:
    link_one(sys.argv[2])
