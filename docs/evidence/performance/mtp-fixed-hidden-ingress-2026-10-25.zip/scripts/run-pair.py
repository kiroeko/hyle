"""Exactly one original direct case per ready image. No build/profile/retry."""
from pathlib import Path
import datetime
import importlib.util
import json
import os
import re
import subprocess
import sys

sys.dont_write_bytecode = True
R = Path.cwd()
W = Path(__file__).resolve().parent
P = W/'pair1'
spec = importlib.util.spec_from_file_location('retained', R/'.scratch/mtp-extraction-regression-20261024/check.py')
b = importlib.util.module_from_spec(spec)
spec.loader.exec_module(b)
ready = b.read(W/'ready.json')
assert len(sys.argv) == 2 and sys.argv[1] in {'baseline','candidate'}
side = sys.argv[1]
P.mkdir(exist_ok=True)
assert not (P/side).exists()
for name in ('baseline','candidate'):
    for key in ('image','main','app','native'):
        p = ready[name][key]
        assert b.pin(Path(p['path'])) == p
assert b.pin(Path(ready['common_graph']['path'])) == ready['common_graph']
if side == 'candidate':
    assert b.read(P/'baseline/process.json')['exit'] == 0
    assert b.read(P/'baseline-gate.json')['allow_candidate']
template = R/'.scratch/mtp-complete-binding-diff-20261025/run2/command.json'
original = b.args(template)
command = original.copy()
command[0] = ready[side]['image']['path']
assert command[1:] == original[1:]
old_runtime = R/'.scratch/mtp-performance-convergence-20261025/baseline/runtime.json'
env = os.environ.copy()
env['PATH'] = str(Path(command[0]).parent)+';'+b.read(old_runtime)['PATH']
env.update(HF_HUB_OFFLINE='1', TRANSFORMERS_OFFLINE='1')
gpu_command = ['nvidia-smi','--query-compute-apps=pid,process_name,used_gpu_memory','--format=csv,noheader']
gpu = subprocess.run(gpu_command, env=env, capture_output=True, text=True,
    creationflags=subprocess.CREATE_NO_WINDOW, timeout=20)
assert gpu.returncode == 0, gpu.stderr
known = {'hyle.exe','peer.exe','consumer.exe','probe.exe','recursive-probe.exe',
         'llama-cli.exe','llama-server.exe','llama-bench.exe','python.exe','pythonw.exe'}
lines = [v for v in gpu.stdout.splitlines() if v.strip()]
compute = [v for v in lines if len(v.split(',')) >= 2 and (
    Path(v.split(',')[1].strip()).name.lower() in known or str(R).lower() in v.lower())]
assert not compute, compute
schedule = Path(command[command.index('--schedule')+1])
inputs = Path(command[command.index('--inputs')+1])
b.save(P/(side+'-start.json'), dict(start_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    image=ready[side]['image'], ready=b.pin(W/'ready.json'), original_command=b.pin(template),
    runtime_plan=b.pin(old_runtime), argv_tail_identical=True, schedule=b.pin(schedule),
    input_metadata=[b.pin(p) for p in inputs.iterdir() if p.is_file() and p.stat().st_size < 1024*1024],
    gpu=dict(command=gpu_command, exit=gpu.returncode, reported_rows=len(lines), inference=compute,
             WDDM_desktop_rows_allowed=True), scope='One direct original K1 two-turn mechanism/behavior case; no TPS/profile.'))
b.execute(command, P/side, env, 120)
stderr = (P/side/'stderr.log').read_text(errors='replace')
pods = [v for v in stderr.splitlines() if v.startswith('BIND_POD ')]
ends = [v for v in stderr.splitlines() if v.startswith('BIND_END ')]
assert len(pods) == len(ends) == 1, (len(pods),len(ends))
def kv(s):
    return {k:int(v) for k,v in re.findall(r'(\w+)=(\d+)',s)}
pod = kv(pods[0])
assert pod['event_overflow'] == pod['difference_overflow'] == pod['concurrent_skips'] == 0, pod
assert kv(ends[0])['events'] == pod['events'] and kv(ends[0])['differences'] == pod['differences']
text = (P/side/'stdout.log').read_text()
report = json.JSONDecoder().raw_decode(text[text.index('{"source_id"'):])[0]
b.save(P/(side+'-gate.json'), dict(allow_candidate=True, process=b.read(P/side/'process.json'),
    BIND_POD=pod, BIND_END=kv(ends[0]), report_top_level_keys=list(report),
    raw_stdout=b.pin(P/side/'stdout.log'), raw_stderr=b.pin(P/side/'stderr.log')))
b.save(P/(side+'-terminal.json'),dict(end_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    process=b.read(P/side/'process.json'), baseline_or_candidate=side, GPU_process_terminal=True))
print(json.dumps({'side':side,'process':b.read(P/side/'process.json'),'BIND_POD':pod,
                  'generated_tokens':report['generated_tokens'],'actual_graph_calls':report['actual_graph_calls']},indent=2))
