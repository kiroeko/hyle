"""Relink one current app with the cached canonical, uninstrumented Graph2."""
from pathlib import Path
import importlib.util
import os
import sys

sys.dont_write_bytecode=True
R=Path.cwd();W=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('retained',R/'.scratch/mtp-extraction-regression-20261024/check.py')
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
assert len(sys.argv)==2 and sys.argv[1]in{'baseline','candidate'}
side=sys.argv[1]
old=W/('build1/baseline'if side=='baseline'else'build2/candidate')
out=W/'clean1'/side
ready=b.read(old/'ready.json')
for key in('image','app','main','native'):
    assert b.pin(Path(ready[key]['path']))==ready[key]
graph4=R/'.scratch/mtp-complete-binding-diff-20261025/graph4/unit.obj'
graph2=R/'.scratch/mtp-native-seed-candidate-20261025/graph2/unit.obj'
graph_source=R/'.scratch/mtp-native-seed-candidate-20261025/source/executable.cc'
canonical=R/'src/graph/executable.cc'
assert b.pin(graph_source)['sha256']==b.pin(canonical)['sha256']=='6476518eaf59eef59d46fc1b0ad770024c0bee99a616663b1032ea33c2d8cf59'
assert b.pin(graph2)['sha256']=='a55d0fa90a071b5fcb27407c60accac02ee5dfd28ed510da57997722c0432cb9'
command=b.args(old/'link/command.json');args=[];changed=0
for word in command[1:]:
    n=word.lower().replace('\\','/')
    if n.startswith(('/out:','/pdb:','/map:','/implib:')):continue
    if n==str(graph4).lower().replace('\\','/'):
        word=str(graph2);changed+=1
    args.append(word)
assert changed==1
old_map=b.read(old/'link-inputs.json')
actual=[]
for row in old_map['actual_inputs']:
    copy=row.copy()
    if copy['path'].lower()==str(graph4).lower():
        copy={'argument':str(graph2),**b.pin(graph2)}
    else:
        pin=b.pin(Path(copy['path']))
        assert all(copy[k]==pin[k]for k in('path','bytes','sha256'))
    actual.append(copy)
out.mkdir(parents=True,exist_ok=False)
b.save(out/'link-inputs.json',dict(template=b.pin(old/'link/command.json'),
    changed_graph=dict(before=b.pin(graph4),after=b.pin(graph2)),
    app=ready['app'],actual_inputs=actual,input_count=len(actual),new_compile_processes=0,
    graph_source=b.pin(graph_source),canonical_graph=b.pin(canonical),diagnostic=False))
compile_template=b.args(R/'.scratch/mtp-performance-convergence-20261025/baseline/compile/command.json')
env=b.environment(compile_template[0])
b.execute([command[0],*args,'/OUT:'+str(out/'link/hyle.exe'),'/PDB:'+str(out/'link/hyle.pdb'),
    '/IMPLIB:'+str(out/'link/hyle.lib')],out/'link',env,120)
os.link(Path(ready['native']['path']),out/'link'/Path(ready['native']['path']).name)
runtime=R/'.scratch/mtp-performance-convergence-20261025/baseline/runtime.json'
b.save(out/'runtime.json',dict(PATH=str(out/'link')+';'+b.read(runtime)['PATH'],
    parent=b.pin(runtime),native=ready['native'],offline_only=True,GPU_executed=False))
b.save(out/'ready.json',dict(image=b.pin(out/'link/hyle.exe'),app=ready['app'],main=ready['main'],native=ready['native'],
    original_current_app_ready=b.pin(old/'ready.json'),link_inputs=b.pin(out/'link-inputs.json'),
    graph=b.pin(graph2),graph_source=b.pin(graph_source),runtime=b.pin(out/'runtime.json'),
    compile_processes=0,link_process=b.read(out/'link/process.json'),GPU_executed=False,
    diagnostic=False,profiler=False,TPS_result=False))
