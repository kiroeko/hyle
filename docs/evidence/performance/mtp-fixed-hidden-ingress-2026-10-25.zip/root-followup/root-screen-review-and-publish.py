from pathlib import Path
import hashlib
import json
import statistics
import zipfile

R = Path.cwd()
S = Path(__file__).resolve().parent
W = R / '.scratch/mtp-fixed-hidden-ingress-20261025'
C = S / 'fixed-ingress-cleanup'
J = R / 'docs/evidence/performance/mtp-fixed-hidden-ingress-2026-10-25.json'
Z = J.with_suffix('.zip')

def load(p): return json.loads(p.read_bytes())
def pin(p):
    return dict(path=p.relative_to(R).as_posix(), bytes=p.stat().st_size,
                sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def normalize(v):
    if isinstance(v, list): return [normalize(x) for x in v]
    if isinstance(v, dict):
        return {k:normalize(x) for k,x in v.items() if not any(t in k for t in [
            'seconds','tokens_per_second','clock_unix','unix_ns','unix_ms'])}
    return v
def report(p):
    t=p.read_text(encoding='utf-8'); return json.JSONDecoder().raw_decode(t[t.index('{"source_id"'):])[0]
def near(a,b): assert abs(a-b)<1e-8,(a,b)

d=load(J); old_archive=d['archive'].copy()
screen=load(W/'screen1/summary.json')
reference=normalize(report(W/'pair1/baseline/stdout.log'))
assert screen['order']==['baseline','candidate','candidate','baseline','baseline','candidate']
recomputed={a:{} for a in ['baseline','candidate']}
raw=[]
for row in screen['rows']:
    p=Path(row['source_stdout']['path']); q=pin(p)
    assert (q['bytes'],q['sha256'])==(row['source_stdout']['bytes'],row['source_stdout']['sha256'])
    r=report(p); assert normalize(r)==reference
    assert load(p.with_name('process.json'))['exit']==0
    near(r['prefill_tokens_per_second'],r['prefill_target_rows']/r['prefill_seconds'])
    near(r['decode_output_tokens_per_second'],r['generated_decode_tokens']/r['decode_seconds'])
    near(r['output_tokens_per_second'],r['generated_tokens']/r['session_seconds'])
    for key in ['prefill_tokens_per_second','decode_output_tokens_per_second','output_tokens_per_second']:
        near(r[key],row[key]); recomputed[row['side']].setdefault(key,[]).append(r[key])
    raw.append(q)
for side, fields in recomputed.items():
    for key, values in fields.items():
        near(statistics.median(values),screen['groups'][side][key]['median'])
changes={k:(statistics.median(recomputed['candidate'][k])/statistics.median(v)-1)*100
         for k,v in recomputed['baseline'].items()}
for k,v in changes.items(): near(v,screen['median_throughput_change_percent'][k])
cleanup=load(C/'removed.json'); assert cleanup['applied'] and len(cleanup['files'])==8
assert cleanup['logical_bytes']==285599377
assert all(not Path(x['path']).exists() for x in cleanup['files'])
retained=load(W/'cleanup-candidates.json')['retain']
for x in retained:
    q=pin(R/x['path']);assert (q['bytes'],q['sha256'])==(x['bytes'],x['sha256'])
review=dict(status='PASS_ALL_SIX_RAW_REPORTS_AND_ARITHMETIC',
            raw=raw, time_only_normalization=True, non_time_exclusions=[],
            complete_visible_non_time_differences=0, median_change_percent=changes,
            scope='Finite three-per-arm current consumer screen; no new peer/memory profile or stable-speed claim',
            cleanup_files_absent=8, retained_shared_and_clean_input_pins_verified=len(retained))
review_path=S/'fixed-ingress-screen-root-review.json'
review_path.write_text(json.dumps(review,indent=2)+'\n',encoding='utf-8',newline='\n')
files={
    'root-followup/root-screen-review.json':review_path,
    'root-followup/root-screen-review-and-publish.py':Path(__file__).resolve(),
    'root-followup/cleanup/plan.json':C/'plan.json',
    'root-followup/cleanup/preview.json':C/'preview.json',
    'root-followup/cleanup/removed.json':C/'removed.json',
    'root-followup/cleanup/delete-commands.ps1.txt':R/'test.ps1',
}
manifest=dict(previous_archive=old_archive,cleanup_performed=True,files=8,
              logical_bytes=285599377,physical_freed_bytes_unknown=True,
              retained_clean_images_app_and_shared_cores=True,
              members={name:pin(p) for name,p in files.items()})
manifest_path=C/'manifest.json'
manifest_path.write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8',newline='\n')
files['root-followup/manifest.json']=manifest_path
with zipfile.ZipFile(Z) as src: data={n:src.read(n) for n in src.namelist()}
assert not set(files)&set(data),'Already appended'
data.update({name:p.read_bytes() for name,p in files.items()})
with zipfile.ZipFile(Z,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as out:
    for name,payload in data.items():out.writestr(name,payload)
with zipfile.ZipFile(Z) as check: assert check.testzip() is None
d['archive'].update(pin(Z),members=len(data),logical_bytes=sum(map(len,data.values())))
d['root_followup']=dict(screen_review=review,cleanup=manifest,evidence='archive:root-followup/manifest.json')
J.write_text(json.dumps(d,indent=2,ensure_ascii=False)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(dict(status=review['status'],archive=d['archive']),ensure_ascii=False))
