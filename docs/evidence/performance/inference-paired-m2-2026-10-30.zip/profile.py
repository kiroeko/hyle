from pathlib import Path
import importlib.util
import sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('build',W/'build.py')
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
variant=sys.argv[1]
assert variant in ('control','candidate')
nsys=Path('C:/Program Files/NVIDIA Corporation/Nsight Systems 2026.1.3/target-windows-x64/nsys.exe')
command=b.read(W/'speed/single-mtp'/variant/'attempt1/command.json')
b.exact(b.read(W/('ready-'+variant+'.json')))
folder=W/'profile'/variant
folder.mkdir(parents=True,exist_ok=True)
b.save(folder/'profiler.json',b.pin(nsys))
b.b.execute([str(nsys),'profile','--trace=cuda,cublas','--cuda-graph-trace=node',
    '--sample=none','--cpuctxsw=none','--discard-environment=true','--duration=60',
    '--kill=true','--wait=all','--stats=false','--export=sqlite','--output='+str(folder/'trace'),
    *command],folder/'attempt1',180)
b.save(folder/'artifacts.json',[b.pin(p) for p in folder.iterdir() if p.suffix in ('.sqlite','.nsys-rep','.qdstrm')])
print('Profiled',variant)
