from pathlib import Path
from datetime import datetime, timezone, timedelta
import importlib.util
import sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('build',W/'build.py')
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
read,save,pin=b.read,b.save,b.pin
root=W/'peer-window';summary=read(root/'summary.json')
assert summary['status']=='COMPLETE32_FOUR_ARMS_STABLE'
processes=[]
for scenario in ('single','two-turn'):
    for mode in ('timing','memory'):
        for row in read(root/(scenario+'-'+mode)/'runs.json'):
            folder=Path(row['folder']);result=read(folder/'result.json')
            assert result['exit']==0 and result['finished_unix_ns']>=result['started_unix_ns']
            processes.append(dict(scenario=scenario,mode=mode,arm=row['arm'],pid=result['pid'],
                started_unix_ns=result['started_unix_ns'],finished_unix_ns=result['finished_unix_ns'],
                process=pin(folder/'result.json'),producer=pin(folder/'consumer-result.json')))
assert len(processes)==32
metrics=[dict(scenario=row['scenario'],arm=row['arm'],timing=row['timing'],
    independent_memory=dict(sample_count=row['independent_memory']['sample_count'],
        sampled_peaks=row['independent_memory']['sampled_peaks'])) for row in summary['table']]
work=[]
for row in summary['cross_engine_work']:
    reports=row['complete_non_time_reports']
    work.append(dict(scenario=row['scenario'],role=row['role'],common_output_prefix=row['common_output_prefix'],
        first_differing_output_1based=row['first_differing_output_1based'], arms={arm:{k:r.get(k) for k in
            ['generated_tokens','actual_graph_calls','actual_target_rows','actual_draft_rows','draft_rounds',
             'agreements','overlap_successor_submissions','overlap_successor_publications',
             'overlap_successor_discards','overlap_successor_refusals']} for arm,r in reports.items()}))
tz=timezone(timedelta(hours=8));format_time=lambda ns:datetime.fromtimestamp(ns/1e9,tz).isoformat(timespec='seconds')
start=min(p['started_unix_ns'] for p in processes);end=max(p['finished_unix_ns'] for p in processes)
value=dict(schema='hyle.performance.current-auto-window.v1',date='2026-10-30',status=summary['status'],
    time_window=dict(started_china=format_time(start),finished_china=format_time(end)),
    current_candidate=read(root/'ready.json'),peer=read(root/'peer-ready.json'),
    counts=dict(actual_processes=32,timing=24,independent_memory=8,timing_samples_per_arm_scenario=3,
        memory_samples_per_arm_scenario=1,downloads=0,automatic_retries=0),
    hyle_configuration='Current default auto for both ordinary and greedy K1 MTP; N1/R1/C1024; P154 with64 outputs per turn.',
    metrics=metrics,cross_engine_actual_work=work,process_index=processes,
    original_protocol=dict(plan=pin(root/'plan.json'),binding=pin(root/'binding.json'),summary=pin(root/'summary.json'),runner=pin(W/'window.py')),
    limits=[*summary['limits'],'Frozen peer433e is not latest upstream. Different generated IDs/verification rows are retained; no equal-work causal claim.',
        'Previous2026-10-28 MTP table used overlap off; this table uses default auto. Do not interpret the difference as a paired-M2 regression.',
        'Current auto MTP is slower than its same-image synchronous diagnostic: capture churn and speculative discarded work remain open.'],
    evidence_archive='inference-paired-m2-2026-10-30.zip')
out=b.R/'docs/evidence/performance/inference-current-auto-window-2026-10-30.json';save(out,value)
for scenario in ('single','two-turn'):
    for role,left,right in [('ordinary','hyle_auto','peer_plain'),('mtp','hyle_mtp','peer_mtp')]:
        pair=[next(r for r in metrics if r['scenario']==scenario and r['arm']==arm) for arm in (left,right)]
        print(scenario,role,' '.join('/'.join(f'{r["timing"][key]["median"]:.2f}' for r in pair) for key in
            ('prefill_tokens_per_second','full_decode_tokens_per_second','session_output_tokens_per_second')),
            '/'.join(f'{r["independent_memory"]["sampled_peaks"]["sampled_peak_gpu_dedicated_bytes"]/2**30:.3f}' for r in pair))
print(value['time_window'])
