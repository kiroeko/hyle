"""Preserve a small reproducible record; native processes are started elsewhere."""
from pathlib import Path
import importlib.util
import json
import re
import zipfile
import sys

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = W.parents[1]
spec = importlib.util.spec_from_file_location('build', W / 'build.py')
b = importlib.util.module_from_spec(spec); spec.loader.exec_module(b)
read, save, pin, exact, key = b.read, b.save, b.pin, b.exact, b.key
OUT = R / 'docs/evidence/performance/inference-paired-m2-2026-10-30.json'


def report():
    plan = read(W / 'plan.json'); base = read(plan['base']['path'])
    sdk = read(base['sdk_engine_dependencies']['path'])
    for name, unit in plan['units'].items():
        receipt = read(W / 'compile' / name / 'receipt.json')
        exact(receipt['object'])
        for item in receipt['source_identities']: exact(item)
        if 'original_object' not in unit: continue
        old = key(unit['original_object']['path'])
        if unit['native']:
            dependencies = W / 'compile' / name / 'unit.d'
            text = dependencies.read_text().split(' : ', 1)[1].replace('\\\n', ' ')
            tokens = re.findall(r'(?:\\.|[^\s])+', text)
            paths = sorted({Path(t.replace('\\ ', ' ')).resolve() for t in tokens})
            assert all(p.is_file() for p in paths)
            actual = [pin(p) for p in paths]
            save(W / 'compile' / name / 'native-dependencies.json', actual)
            receipt['dependencies'] = pin(dependencies)
            receipt['actual_dependencies'] = pin(W / 'compile' / name / 'native-dependencies.json')
            save(W / 'compile' / name / 'receipt.json', receipt)
            sdk['native_consumers'].append(dict(object=receipt['object']['path'],
                receipt=pin(W / 'compile' / name / 'receipt.json')))
            sdk['unavailable'] = [x for x in sdk['unavailable'] if key(x) != old]
        else:
            selected = [x for x in sdk['inspected'] if key(x['object']) == old]
            assert len(selected) == 1
            selected[0].update(object=receipt['object']['path'],
                dependencies=pin(W / 'compile' / name / 'dependencies.json'))
    save(W / 'sdk-engine-dependencies.json', sdk)
    current = dict(base)
    current.update(schema='hyle.paired-m2.current-link-base.v1', base=plan['base'],
        retained=plan['candidate_retained'], sdk_engine_dependencies=pin(W / 'sdk-engine-dependencies.json'),
        link=[plan['replacements'][key(arg)]['path'] if key(arg) in plan['replacements'] else arg for arg in base['link']])
    save(W / 'model-link-base.json', current)
    finite = {}
    for name, attempt in [('paired','attempt1'), ('grouped','attempt1'), ('natural','attempt1'), ('continuous','attempt2')]:
        path = W / 'runs' / name / attempt / 'report.json'
        value = read(path); assert value['status'] == 'PASS'
        finite[name] = dict(report=pin(path), result=value)
    prior = R / '.scratch/inference-source-preparation-20261030/runs'
    equal = {}
    for name, old_name, attempt in [('natural','natural-cuda','attempt1'), ('continuous','continuous-cuda','attempt2')]:
        old = prior / old_name / 'attempt1/report.json'
        equal[name] = dict(prior=pin(old), complete_report_equal=read(old) == finite[name]['result'])
        assert equal[name]['complete_report_equal']
    processes = []
    for p in sorted(W.rglob('process.json')):
        value = read(p); assert value['state'] == 'TERMINAL'
        processes.append(dict(receipt=pin(p), **value))
    speeds = []
    for p in sorted((W / 'speed').rglob('consumer-result.json')):
        j = read(p); speeds.append(dict(report=pin(p), condition=p.parents[2].name,
            arm=p.parents[1].name, attempt=p.parent.name, prefill_seconds=j['prefill_seconds'],
            decode_seconds=j['decode_seconds'], session_seconds=j['session_seconds'],
            generated_tokens=j['generated_tokens'], non_time=pin(p.with_name('non-time.json'))))
    facts = [read(x['non_time']['path']) for x in speeds if x['condition'] == 'single-mtp']
    equal_speed = bool(facts) and all(x == facts[0] for x in facts)
    artifact = dict(schema='hyle.performance.paired-m2.v1', date='2026-10-30',
        status='IMPLEMENTED_FINITE_NATIVE_CHECKS_AND_ISOLATED_SCREEN_COMPLETE',
        source_base_commit='2f00b9715',
        change='Cold-proven same-A BF16 M1/M2 paired MatMul with two original weights and independent dense outputs; M2 standalone fallback uses original precise MMVF template. Ordinary M2 F32+Cast and M1 remain.',
        implementation=dict(research=pin(W / 'research.json'), materialization=pin(W / 'materialization.json'),
            native_audit=pin(W / 'native-replay.json'), lock=pin(W / 'lock-update.json'),
            current_link_base=pin(W / 'model-link-base.json'), replaced_sdk_objects=6, unchanged_sdk_objects=221),
        finite=finite, prior_complete_report_comparison=equal, isolated_screen=dict(samples=[x for x in speeds if x['condition']=='single-mtp'],
            complete_non_time_reports_equal=equal_speed, samples_per_arm=2,
            mtp_overlap='off for both arms: isolates this paired-projection change; current default-auto is a separate complete-window measurement.'),
        processes=processes, downloads=0,
        limits=['Two timing samples per arm are screening evidence, not a stable speedup estimate.',
            'Finite tests do not individually force native single-node M2 fallback or ordinary native M2 F32+Cast lowering.',
            'Graph route/dispatch reports alone do not establish actual native launch counts.',
            'No cross-engine same-output or quality equivalence is inferred from the isolated screen.'],
        recovery=[dict(action='Paired test compile attempt1', result='FAILED: std::bind ADL from the added std::array* argument; helper renamed; attempt2 PASS.'),
            dict(action='Initial generated vendored tree digest', result='CMake rejected Windows case-insensitive ordering; regenerated with case-sensitive portable path ordering and verified by owning CMake audit.'),
            dict(action='Continuous test attempt1', result='FAILED before checks because the prior fixture already contained generated stop fixtures; attempt2 used only original metadata copied to a new batch-local directory and PASS.')])
    artifact['profile'] = dict(summary=pin(W / 'profile/analysis-summary.json'),
        results=read(W / 'profile/analysis-summary.json'),
        interpretation='34 actual GraphLaunch correlation buckets each replace36 old small grid1/block32 Kernel2 kernels by18 BF16 paired M2 kernels. No logical-episode/NVTX mapping is inferred; native copy counts/bytes remain equal.')
    artifact['default_auto_window'] = pin(R / 'docs/evidence/performance/inference-current-auto-window-2026-10-30.json')
    if (W / 'auto-diagnostic.json').exists(): artifact['default_auto_open_issue']=read(W / 'auto-diagnostic.json')
    save(OUT, artifact)
    print('Saved finite results, exact input base and every terminal process; no speed overclaim.')


def cleanup_plan():
    # Flat known image outputs only. Root reviews this manifest before execution.
    targets = [pin(p) for p in sorted((W / 'bin').iterdir()) if p.is_file()]
    save(W / 'cleanup-plan.json', targets)
    script = "$ErrorActionPreference = 'Stop'\n$workspace = [IO.Path]::GetFullPath($PSScriptRoot)\n"
    script += "$batch = [IO.Path]::GetFullPath((Join-Path $workspace '.scratch/inference-paired-m2-20261030'))\n"
    script += "$bin = [IO.Path]::GetFullPath((Join-Path $batch 'bin'))\n"
    script += "$targets = Get-Content -LiteralPath (Join-Path $batch 'cleanup-plan.json') -Raw | ConvertFrom-Json\n"
    script += "foreach ($target in $targets) {\n  $path = [IO.Path]::GetFullPath($target.path)\n"
    script += "  if ([IO.Path]::GetDirectoryName($path) -cne $bin -or -not $path.StartsWith($workspace + [IO.Path]::DirectorySeparatorChar)) { throw ('Unexpected cleanup target: ' + $path) }\n"
    script += "  $item = Get-Item -LiteralPath $path\n  if ($item.PSIsContainer -or $item.Length -ne $target.bytes -or (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLowerInvariant() -ne $target.sha256) { throw ('Changed cleanup target: ' + $path) }\n}\n"
    script += "$removed = @()\nforeach ($target in $targets) {\n  Remove-Item -LiteralPath $target.path -Force\n  $removed += $target\n}\n"
    script += "$report = @{ status='REMOVED_EXACT_FLAT_BATCH_IMAGES'; files=$removed.Count; bytes=($removed | Measure-Object -Property bytes -Sum).Sum; targets=$removed }\n"
    script += "$report | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath (Join-Path $batch 'cleanup-report.json') -Encoding utf8\n$report | Select-Object status,files,bytes | Format-List\n"
    (R / 'test.ps1').write_text(script, encoding='utf-8')
    print('Prepared exact flat image cleanup:', len(targets), sum(p['bytes'] for p in targets), 'bytes.')


def pack():
    value = read(OUT); cleanup = read(W / 'cleanup-report.json')
    archive = OUT.with_suffix('.zip')
    paths = [p for p in W.rglob('*') if p.is_file() and p.suffix in ('.json','.py','.log','.xml','.cc','.cu','.cuh','.h','.d','.cmake','.txt','.sqlite')
        and not any(x in p.parts for x in ('tmp','bin','__pycache__'))]
    source = [R / p for p in ['cmake/HyleDependencyLock.json','third_party/ggml_cuda_runtime/patches.json',
        'src/compute_provider_ggml_cuda/program.h','src/compute_provider_ggml_cuda/ggml_cuda_provider.cc',
        'src/compute_provider_ggml_cuda/native_bridge.h','src/compute_provider_ggml_cuda/native_bridge_impl.h',
        'src/compute_provider_ggml_cuda/tensor_program.cc','src/graph_provider_ggml_cuda/ggml_cuda_region.cc',
        'tests/graph_provider_ggml_cuda/paired_projection_test.cc']]
    members = {}
    with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED) as z:
        for p in [*paths,*source,R/'test.ps1']:
            name = p.relative_to(W).as_posix() if p.is_relative_to(W) else 'product/' + p.relative_to(R).as_posix()
            z.write(p, name); members[name] = pin(p)['sha256']
        z.writestr('archive-manifest.json', json.dumps(members, indent=2))
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None
        for name, digest in members.items(): assert b.b.hashlib.sha256(z.read(name)).hexdigest() == digest
    value.update(cleanup=cleanup, archive=dict(**pin(archive), members=len(members)+1,
        CRC='PASS', all_member_SHA256='PASS'))
    save(OUT, value)
    print('Packed and checked evidence archive:', archive.name, archive.stat().st_size)


if __name__ == '__main__': globals()[sys.argv[1]]()
