"""Explicit finite model checks and same-CLI-object A/B; never runs on import.

Root entry points (each is a separate explicit action):
  python model.py prepare
  python model.py link validation attempt1
  python model.py run natural attempt1
  python model.py link ordinary attempt1
  python model.py run continuous attempt1
  python model.py compile-cli attempt1
  python model.py link control attempt1
  python model.py link candidate attempt1
  python model.py speed single-mtp control attempt1
  python model.py speed single-mtp candidate attempt1
  python model.py speed single-mtp candidate attempt2
  python model.py speed single-mtp control attempt2
The other three speed conditions are prepared, not automatically executed.
"""
from pathlib import Path
import importlib.util
import os
import shutil
import sys

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = W.parents[1]
spec = importlib.util.spec_from_file_location('paired_build', W / 'build.py')
build = importlib.util.module_from_spec(spec)
spec.loader.exec_module(build)
b = build.b
read, save, pin, exact, key = build.read, build.save, build.pin, build.exact, build.key
SOURCE_PREP = R / '.scratch/inference-source-preparation-20261030'
PEER = R / '.scratch/inference-small-projection-20261028/current-peer-window'


def non_time(value):
    # Exact existing predicate from inference-current-review-profile/analyze.py.
    if isinstance(value, list):
        return [non_time(item) for item in value]
    if isinstance(value, dict):
        return {name: non_time(item) for name, item in value.items()
                if not any(part in name for part in
                           ('seconds', 'per_second', 'clock_unix', 'unix_ns', 'unix_ms'))}
    return value


def link_command(plan, unit_object, output, candidate):
    old = read(plan['original_consumer']['path'])['object']['path']
    args = []
    for original in plan['original_link']:
        arg = original
        if key(arg) == key(old):
            arg = str(unit_object)
        elif candidate and key(arg) in plan['replacements']:
            arg = plan['replacements'][key(arg)]['path']
        for prefix, suffix in [('/OUT:', '.exe'), ('/PDB:', '.pdb'),
                               ('/IMPLIB:', '.lib'), ('/MAP:', '.map')]:
            if arg.upper().startswith(prefix):
                arg = prefix + str((W / 'bin' / output).with_suffix(suffix))
                break
        args.append(arg)
    assert sum(key(arg) == key(unit_object) for arg in args) == 1
    return args


def prepare():
    plan = read(W / 'plan.json')
    assert len(plan['retained']) == len(plan['candidate_retained']) == 227
    assert len(plan['replacements']) == 6
    exact(plan['base'])
    base = read(plan['base']['path'])
    prior = read(SOURCE_PREP / 'plan.json')
    receipts = {name: read(SOURCE_PREP / 'compile' / name / 'receipt.json')
                for name in ('model', 'ordinary')}
    for receipt in receipts.values():
        exact(receipt['object'])
    (W / 'bin').mkdir(exist_ok=True)
    exact(plan['runtime'])
    runtime = W / 'bin' / Path(plan['runtime']['path']).name
    if not runtime.exists():
        shutil.copyfile(plan['runtime']['path'], runtime)
    assert pin(runtime)['sha256'] == plan['runtime']['sha256']

    source = W / 'cli.cc'
    source.write_text('#include "../../engine/models/qwen35/main.cc"\n'
                      'int main(int argc, char **argv) { return qwen35::run(argc, argv); }\n',
                      encoding='utf-8')
    folder = W / 'compile' / 'cli'
    folder.mkdir(parents=True, exist_ok=True)
    compile_args = []
    for index, original in enumerate(base['compile']):
        arg = original
        if index and base['compile'][index - 1].lower() == '/sourcedependencies':
            arg = str(folder / 'dependencies.json')
        elif arg.lower().startswith('/fo'):
            arg = '/Fo' + str(folder / 'unit.obj')
        elif arg.lower().startswith('/fd'):
            arg = '/Fd' + str(folder / 'unit.pdb')
        elif key(arg) == key(base['consumer_source']['path']):
            arg = str(source)
        compile_args.append(arg)
    assert sum(key(arg) == key(source) for arg in compile_args) == 1
    units = {
        'validation': dict(object=receipts['model']['object'], candidate=True),
        'ordinary': dict(object=receipts['ordinary']['object'], candidate=True),
        'control': dict(object_path=str(folder / 'unit.obj'), candidate=False),
        'candidate': dict(object_path=str(folder / 'unit.obj'), candidate=True)}
    for name, unit in units.items():
        obj = unit['object']['path'] if 'object' in unit else unit['object_path']
        unit['link'] = link_command(plan, obj, name, unit['candidate'])
    cases = {
        'natural': dict(unit='validation', args=prior['cases']['natural-cuda']['args'],
                        expected=dict(prompt_tokens=154, output_limit=40, outputs=40)),
        'continuous': dict(unit='ordinary', args=prior['cases']['continuous-cuda']['args'],
                           expected=dict(control_and_candidate_arms=16))}
    continuous = W / 'continuous-input'
    continuous.mkdir(exist_ok=True)
    for filename in ('weights.tsv', 'prompt.ids'):
        shutil.copyfile(SOURCE_PREP / 'continuous-input' / filename, continuous / filename)
    cases['continuous']['args'] = [*cases['continuous']['args'][:-1], str(continuous)]

    speeds = {}
    for scenario, stem in [('single', 'single'), ('two-turn', 'two-turn')]:
        reference = PEER / (stem + '-timing-plan.json')
        old = read(reference)
        for mode, arm in [('ordinary', 'hyle_auto'), ('mtp', 'hyle_mtp')]:
            row = next(item for item in old['commands'] if item['arm'] == arm)
            name = scenario + '-' + mode
            speeds[name] = dict(argument_recipe=pin(reference), reference_environment=row['environment'],
                args=row['command'][1:], commands={variant: [str(W / 'bin' / (variant + '.exe')),
                    *row['command'][1:]] for variant in ('control', 'candidate')})
    abba = [dict(condition='single-mtp', variant=variant, attempt=attempt,
                  command=speeds['single-mtp']['commands'][variant])
            for variant, attempt in [('control', 'attempt1'), ('candidate', 'attempt1'),
                                     ('candidate', 'attempt2'), ('control', 'attempt2')]]
    save(W / 'model-plan.json', dict(status='PREPARED_NO_COMPILE_LINK_OR_NATIVE_STARTED',
        sdk_plan=pin(W / 'plan.json'), base=plan['base'], retained=plan['retained'],
        candidate_retained=plan['candidate_retained'], replacements=plan['replacements'],
        reused_receipts={name: pin(SOURCE_PREP / 'compile' / name / 'receipt.json') for name in receipts},
        units=units, cli=dict(source=pin(source), compile=compile_args), cases=cases, speed=speeds,
        mtp_single_abba=abba, runtime=pin(runtime), environment=prior['environment'],
        comparison=dict(predicate_source=pin(R / '.scratch/inference-current-review-profile-20261027/analyze.py'),
            predicate='Recursively omit only key names containing seconds/per_second/clock_unix/unix_ns/unix_ms; compare every remaining field.',
            preserve=['generated_ids, visible_tokens and per-session/turn IDs',
                'actual_graph_calls, target/draft/verified/committed rows and all graph participation records',
                'accepted_drafts, draft_rounds, consumed_drafts, agreements, frontier/lag and decision changes',
                'sampling policy/seed/RNG cursor, cache/admission/retirement, Source/replay and complete batch/session/turn records'],
            rule='Keep raw reports. Any non-time difference blocks a same-work speed claim; report differences rather than deleting fields. Finite PASS does not establish speed.'),
        scope='One new CLI CXX object, four links total, two finite consumer processes. Initial speed screening is optional explicit MTP single-turn ABBA; remaining three conditions are command plans only. No peer binary or download.'))
    print('Prepared finite links, one CLI CXX recipe, same-object control/candidate links and four speed command pairs; no process launched.')


def compile_cli(attempt):
    plan = read(W / 'model-plan.json')
    exact(plan['cli']['source'])
    b.execute(plan['cli']['compile'], W / 'compile' / 'cli' / attempt, 600)
    folder = W / 'compile' / 'cli'
    deps = read(folder / 'dependencies.json')['Data']
    files = sorted({Path(p).resolve() for p in [deps['Source'], *deps['Includes']]
                    if Path(p).is_relative_to(R)})
    save(folder / 'receipt.json', dict(object=pin(folder / 'unit.obj'),
        source_identities=[pin(path) for path in files], process=pin(folder / attempt / 'process.json')))


def link(name, attempt):
    plan = read(W / 'model-plan.json')
    unit = plan['units'][name]
    for item in plan['candidate_retained'] if unit['candidate'] else plan['retained']:
        exact(item)
    obj = unit['object'] if 'object' in unit else read(W / 'compile/cli/receipt.json')['object']
    exact(obj)
    b.execute(unit['link'], W / 'link' / name / attempt, 300)
    save(W / ('ready-' + name + '.json'), pin(W / 'bin' / (name + '.exe')))


def run(name, attempt):
    plan = read(W / 'model-plan.json')
    case = plan['cases'][name]
    image = read(W / ('ready-' + case['unit'] + '.json'))
    exact(image)
    os.environ.update(plan['environment'], HF_HUB_OFFLINE='1', TRANSFORMERS_OFFLINE='1', HF_DATASETS_OFFLINE='1')
    folder = W / 'runs' / name / attempt
    b.execute([image['path'], *case['args']], folder, 900)
    report = read(folder / 'stdout.log')
    assert report['status'] == 'PASS'
    for field, expected in case['expected'].items():
        assert report[field] == expected, (field, report[field], expected)
    if name == 'natural':
        for field in ('original_ledger_equal', 'generated_ids_equal', 'greedy_rng_unchanged', 'all_sources_expired'):
            assert report[field] is True, field
    else:
        for field in ('complete_prefix_state_epoch_rng_equal', 'actual_owner_credit_checked',
                      'all_source_session_page_owners_retired'):
            assert report[field] is True, field
    save(folder / 'report.json', report)
    print('PASS', name)


def speed(name, variant, attempt):
    plan = read(W / 'model-plan.json')
    assert variant in ('control', 'candidate')
    image = read(W / ('ready-' + variant + '.json'))
    exact(image)
    os.environ.update(HF_HUB_OFFLINE='1', TRANSFORMERS_OFFLINE='1', HF_DATASETS_OFFLINE='1')
    folder = W / 'speed' / name / variant / attempt
    b.execute([image['path'], *plan['speed'][name]['args']], folder, 900)
    report = read(folder / 'stdout.log')
    save(folder / 'consumer-result.json', report)
    save(folder / 'non-time.json', non_time(report))
    print('Recorded', name, variant, attempt, '; compare complete non-time reports before speed claims.')


if __name__ == '__main__':
    action = sys.argv[1]
    if action == 'prepare':
        prepare()
    elif action == 'compile-cli':
        compile_cli(sys.argv[2] if len(sys.argv) > 2 else 'attempt1')
    elif action in ('link', 'run'):
        globals()[action](sys.argv[2], sys.argv[3] if len(sys.argv) > 3 else 'attempt1')
    elif action == 'speed':
        speed(sys.argv[2], sys.argv[3], sys.argv[4] if len(sys.argv) > 4 else 'attempt1')
    else:
        raise SystemExit('Expected prepare, compile-cli, link, run or speed')
