"""Offline exact-context native M2 manifest edit; no build or shared-cache write."""
import hashlib
import json
from pathlib import Path

ROOT = Path(r"C:\public\project-hyle\hyle")
UPSTREAM = Path(r"C:\Users\kiro\AppData\Local\hyle\dependencies\v1\sources\ggml-456172ec733a-41b7e10fd424")
WORK = ROOT / ".scratch/inference-paired-m2-20261030"
MANIFEST = ROOT / "third_party/ggml_cuda_runtime/patches.json"
BASELINE = "871bcdf3bc0001c188fcd5a7cbde4163e3e3ff05dd772795c59725b5088b55bb"


def sha(data):
    return hashlib.sha256(data).hexdigest()


def replace_once(text, before, after):
    assert before and text.count(before) == 1, (before[:150], text.count(before))
    return text.replace(before, after, 1)


original_manifest = MANIFEST.read_bytes()
assert sha(original_manifest) == BASELINE, "manifest differs from recorded native baseline"
manifest = json.loads(original_manifest)
paths = ["src/ggml-cuda/ggml-cuda.cu", "src/ggml-cuda/unary.cu",
         "src/ggml-cuda/mmvf.cuh", "src/ggml-cuda/mmvf.cu", "src/ggml-cuda/unary.cuh"]
patches = {entry["path"]: entry for entry in manifest["files"] if entry["path"] in paths}
texts = {}
baseline_hashes = {}
for path, patch in patches.items():
    data = (UPSTREAM / path).read_bytes().replace(b"\r\n", b"\n")
    assert sha(data) == patch["before_sha256"], path
    text = data.decode()
    for edit in patch["edits"]:
        text = replace_once(text, edit["before"], edit["after"])
    assert sha(text.encode()) == patch["after_sha256"], path
    texts[path] = text
    baseline_hashes[path] = patch["after_sha256"]


def edit(path, before, after):
    texts[path] = replace_once(texts[path], before, after)
    patches[path]["edits"].append({"before": before, "after": after})


dispatcher = "src/ggml-cuda/ggml-cuda.cu"
edit(dispatcher,
     "bool ggml_cuda_supports_bf16_paired_projection_geometry(int device, uint64_t inner, uint64_t rows) {",
     "bool ggml_cuda_supports_bf16_paired_projection_geometry(int device, uint64_t inner, uint64_t rows, uint64_t columns) {")
edit(dispatcher,
     "    GGML_UNUSED_VARS(device, inner, rows);\n",
     "    GGML_UNUSED_VARS(device, inner, rows, columns);\n")
edit(dispatcher,
     "    if (device < 0 || device >= info.device_count || !inner || (inner & 1) || !rows ||\n"
     "            inner > uint64_t(INT_MAX) || rows > uint64_t(INT_MAX) / inner) return false;",
     "    if (device < 0 || device >= info.device_count || !inner || (inner & 1) || !rows ||\n"
     "            (columns != 1 && columns != 2) || inner > uint64_t(INT_MAX) / columns ||\n"
     "            rows > uint64_t(INT_MAX) / columns || rows > uint64_t(INT_MAX) / inner) return false;")
edit(dispatcher,
     "    return ggml_cuda_should_use_mmvf(GGML_TYPE_BF16, caps.cc, ne, nb, 1);\n",
     "    // M1 keeps the original native preference. The same small-row carrier\n"
     "    // can consume two dense BF16 columns directly; ordinary F32-result M2\n"
     "    // dispatch still uses its own original preference and implementation.\n"
     "    return ggml_cuda_should_use_mmvf(GGML_TYPE_BF16, caps.cc, ne, nb, 1);\n")
edit(dispatcher,
     "        src1->ne[1] == 1 && dst->ne[1] == 1 &&\n",
     "        src1->ne[1] == dst->ne[1] &&\n"
     "        (src1->ne[1] == 1 || (src1->ne[1] == 2 &&\n"
     "            ggml_cuda_supports_bf16_paired_projection_geometry(device,\n"
     "                uint64_t(src0->ne[0]), uint64_t(src0->ne[1]), 2))) &&\n")

header = "src/ggml-cuda/mmvf.cuh"
edit(header,
     "bool ggml_cuda_supports_bf16_paired_projection_geometry(int device, uint64_t inner, uint64_t rows);",
     "bool ggml_cuda_supports_bf16_paired_projection_geometry(int device, uint64_t inner, uint64_t rows, uint64_t columns);")
edit(header,
     "        static_assert(has_fusion && ncols_dst == 1 && !is_multi_token_id && !strict_f32_ids);",
     "        static_assert(has_fusion && (ncols_dst == 1 || ncols_dst == 2) && !is_multi_token_id && !strict_f32_ids);")
edit(header,
     "        static_assert(ncols_dst == 1 && !is_multi_token_id && !strict_f32_ids && std::is_void_v<Epilogue>);",
     "        static_assert((ncols_dst == 1 || ncols_dst == 2) && !is_multi_token_id && !strict_f32_ids && std::is_void_v<Epilogue>);")

unary_header = "src/ggml-cuda/unary.cuh"
edit(unary_header,
     "#include \"common.cuh\"\n",
     "#include \"common.cuh\"\n\n"
     "// The BF16-result M2 fallback shares the precise MMVF instantiation,\n"
     "// independently of whether two original projections can be paired.\n"
     "void ggml_cuda_op_bf16_matvec_m2(ggml_backend_cuda_context & ctx,\n"
     "    const ggml_tensor * weight, const ggml_tensor * activation, ggml_tensor * dst);\n")

mmvf = "src/ggml-cuda/mmvf.cu"
edit(mmvf,
     "        GGML_ASSERT(ne1 == 1 && ne11 == 1 && precision == GGML_PREC_F32);",
     "        GGML_ASSERT(ne1 == ne11 && (ne1 == 1 || ne1 == 2) && precision == GGML_PREC_F32);")
edit(mmvf,
     "        GGML_ASSERT(ggml_cuda_should_use_mmvf(src0->type, cc, src0->ne, src0->nb, 1));\n",
     "        if (ne1 == 2) {\n"
     "            GGML_ASSERT(ggml_cuda_supports_bf16_paired_projection_geometry(\n"
     "                ctx.device, uint64_t(ne00), uint64_t(ne01), 2));\n"
     "            ggml_cuda_op_bf16_matvec_m2(ctx, src0, src1, dst);\n"
     "            return;\n"
     "        }\n"
     "        GGML_ASSERT(ggml_cuda_should_use_mmvf(src0->type, cc, src0->ne, src0->nb, 1));\n")

unary = "src/ggml-cuda/unary.cu"
edit(unary,
     "            x->ne[0] != k || x->ne[1] != 1 || first->ne[0] != n || first->ne[1] != 1 ||\n"
     "            !ggml_are_same_shape(first, second) ||\n"
     "            !ggml_cuda_supports_bf16_paired_projection_geometry(device, uint64_t(k), uint64_t(n))) return false;",
     "            x->ne[0] != k || first->ne[0] != n || first->ne[1] != x->ne[1] ||\n"
     "            !ggml_are_same_shape(first, second) ||\n"
     "            !ggml_cuda_supports_bf16_paired_projection_geometry(\n"
     "                device, uint64_t(k), uint64_t(n), uint64_t(x->ne[1]))) return false;")
old_launcher = """void ggml_cuda_op_bf16_paired_matvec(ggml_backend_cuda_context & ctx,
        const ggml_tensor * first, ggml_tensor * second) {
    GGML_ASSERT(ggml_cuda_can_fuse_bf16_paired_matvec(first, second, ctx.device, true));
#if !defined(GGML_USE_HIP) && !defined(GGML_USE_MUSA)
    const auto * w0 = first->src[0];
    const auto * w1 = second->src[0];
    const auto * x = first->src[1];
    const auto bytes = sizeof(nv_bfloat16);
    ggml_cuda_mm_fusion_args_device fusion{};
    fusion.gate = w1->data;
    launch_mul_mat_vec_f_cuda<nv_bfloat16, float, 1, false,
        nv_bfloat16, nv_bfloat16, void, false, true>(
            static_cast<const nv_bfloat16 *>(w0->data),
            static_cast<const nv_bfloat16 *>(x->data), nullptr, fusion,
            static_cast<nv_bfloat16 *>(first->data), w0->ne[0], w0->ne[1],
            w0->nb[1] / bytes, x->nb[1] / bytes, first->nb[1] / bytes,
            1, 1, 1, w0->nb[2] / bytes, x->nb[2] / bytes, first->nb[2] / bytes,
            1, 1, w0->nb[3] / bytes, x->nb[3] / bytes, first->nb[3] / bytes,
            1, 0, ctx.stream(), static_cast<nv_bfloat16 *>(second->data));
#else
    GGML_UNUSED_VARS(ctx, first, second);
#endif
}
"""
new_launcher = """#if !defined(GGML_USE_HIP) && !defined(GGML_USE_MUSA)
template<int columns>
static void ggml_cuda_launch_bf16_paired_matvec(ggml_backend_cuda_context & ctx,
        const ggml_tensor * first, ggml_tensor * second) {
    static_assert(columns == 1 || columns == 2);
    const auto * w0 = first->src[0];
    const auto * w1 = second->src[0];
    const auto * x = first->src[1];
    const auto bytes = sizeof(nv_bfloat16);
    ggml_cuda_mm_fusion_args_device fusion{};
    fusion.gate = w1->data;
    launch_mul_mat_vec_f_cuda<nv_bfloat16, float, columns, false,
        nv_bfloat16, nv_bfloat16, void, false, true>(
            static_cast<const nv_bfloat16 *>(w0->data),
            static_cast<const nv_bfloat16 *>(x->data), nullptr, fusion,
            static_cast<nv_bfloat16 *>(first->data), w0->ne[0], w0->ne[1],
            w0->nb[1] / bytes, x->nb[1] / bytes, first->nb[1] / bytes,
            1, 1, 1, w0->nb[2] / bytes, x->nb[2] / bytes, first->nb[2] / bytes,
            1, 1, w0->nb[3] / bytes, x->nb[3] / bytes, first->nb[3] / bytes,
            1, 0, ctx.stream(), static_cast<nv_bfloat16 *>(second->data));
}
#endif

void ggml_cuda_op_bf16_paired_matvec(ggml_backend_cuda_context & ctx,
        const ggml_tensor * first, ggml_tensor * second) {
    GGML_ASSERT(ggml_cuda_can_fuse_bf16_paired_matvec(first, second, ctx.device, true));
#if !defined(GGML_USE_HIP) && !defined(GGML_USE_MUSA)
    if (first->ne[1] == 1) ggml_cuda_launch_bf16_paired_matvec<1>(ctx, first, second);
    else ggml_cuda_launch_bf16_paired_matvec<2>(ctx, first, second);
#else
    GGML_UNUSED_VARS(ctx, first, second);
#endif
}

// Native BF16-result M2 nodes remain independently executable if pairing is
// unavailable. Use this precise TU's original MMVF dot/reduction and BF16 RNE,
// never the ordinary F32-result matrix dispatch or a temporary output bank.
void ggml_cuda_op_bf16_matvec_m2(ggml_backend_cuda_context & ctx,
        const ggml_tensor * weight, const ggml_tensor * activation, ggml_tensor * dst) {
#if !defined(GGML_USE_HIP) && !defined(GGML_USE_MUSA)
    GGML_ASSERT(weight->type == GGML_TYPE_BF16 && activation->type == GGML_TYPE_BF16 &&
        dst->type == GGML_TYPE_BF16 && ggml_is_contiguous(weight) &&
        ggml_is_contiguous(activation) && ggml_is_contiguous(dst));
    GGML_ASSERT(weight->ne[2] == 1 && weight->ne[3] == 1 && activation->ne[2] == 1 &&
        activation->ne[3] == 1 && dst->ne[2] == 1 && dst->ne[3] == 1 &&
        activation->ne[0] == weight->ne[0] && dst->ne[0] == weight->ne[1] &&
        activation->ne[1] == 2 && dst->ne[1] == 2);
    GGML_ASSERT(ggml_cuda_supports_bf16_paired_projection_geometry(ctx.device,
        uint64_t(weight->ne[0]), uint64_t(weight->ne[1]), 2));
    const auto bytes = sizeof(nv_bfloat16);
    const ggml_cuda_mm_fusion_args_device fusion{};
    launch_mul_mat_vec_f_cuda<nv_bfloat16, float, 2, false, nv_bfloat16, nv_bfloat16>(
        static_cast<const nv_bfloat16 *>(weight->data),
        static_cast<const nv_bfloat16 *>(activation->data), nullptr, fusion,
        static_cast<nv_bfloat16 *>(dst->data), weight->ne[0], weight->ne[1],
        weight->nb[1] / bytes, activation->nb[1] / bytes, dst->nb[1] / bytes,
        1, 1, 1, weight->nb[2] / bytes, activation->nb[2] / bytes, dst->nb[2] / bytes,
        1, 1, weight->nb[3] / bytes, activation->nb[3] / bytes, dst->nb[3] / bytes,
        1, 0, ctx.stream());
#else
    GGML_UNUSED_VARS(ctx, weight, activation, dst);
#endif
}
"""
edit(unary, old_launcher, new_launcher)

audit = []
for path in paths:
    patch = patches[path]
    result = texts[path].encode()
    patch["after_sha256"] = sha(result)
    # Replay the complete new edit chain from authenticated original bytes.
    original = (UPSTREAM / path).read_bytes().replace(b"\r\n", b"\n")
    replay = original.decode()
    for change in patch["edits"]:
        replay = replace_once(replay, change["before"], change["after"])
    assert replay.encode() == result
    target = WORK / "native-canonical" / path
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(result)
    audit.append({"path": path, "upstream_source": str(UPSTREAM / path),
                  "before_sha256": sha(original), "baseline_after_sha256": baseline_hashes[path],
                  "candidate_after_sha256": sha(result), "candidate_source": str(target),
                  "bytes": len(result), "edits": len(patch["edits"])})

# Preserve the owning JSON's established two-space format and line endings.
serialized = json.dumps(manifest, indent=2, ensure_ascii=False) + "\n"
if b"\r\n" in original_manifest:
    serialized = serialized.replace("\n", "\r\n")
MANIFEST.write_bytes(serialized.encode())
audit_record = {"status": "EXACT_OFFLINE_REPLAY_VERIFIED_NO_BUILD_OR_NATIVE",
                "upstream_root": str(UPSTREAM), "manifest_before_sha256": BASELINE,
                "manifest_after_sha256": sha(MANIFEST.read_bytes()), "files": audit}
(WORK / "native-replay.json").write_text(json.dumps(audit_record, indent=2) + "\n", encoding="utf-8")
print(json.dumps(audit_record, indent=2))
