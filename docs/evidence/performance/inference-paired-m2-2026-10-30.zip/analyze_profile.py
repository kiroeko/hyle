"""Offline only: analyze the two completed original-image Nsight profiles.

Run after the timing window: python analyze_profile.py
No profiler, consumer, compiler, download or cleanup is started here. Without
NVTX, correlation buckets are native API observations, never target episodes.
"""
from pathlib import Path
from collections import defaultdict
import hashlib
import json
import re
import sqlite3
import sys

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
MASK = (1 << 24) - 1
KINDS = ("KERNEL", "MEMCPY", "MEMSET")


def save(path, value):
    path.write_text(json.dumps(value, indent=2) + "\n", encoding="utf-8")


def union_ns(intervals):
    total = 0
    end = None
    for first, last in sorted(intervals):
        if last < first:
            raise ValueError("GPU interval has negative duration")
        if end is None or first > end:
            total += last - first
        elif last > end:
            total += last - end
        end = last if end is None else max(end, last)
    return total


def facts(rows):
    return dict(count=len(rows), duration_sum_ns=sum(r["end"] - r["start"] for r in rows),
        duration_union_ns=union_ns((r["start"], r["end"]) for r in rows),
        bytes=sum(r.get("bytes", 0) or 0 for r in rows))


def activity_facts(rows):
    return dict(all=facts(rows), by_kind={k: facts([r for r in rows if r["kind"] == k]) for k in KINDS})


def template_args(name):
    match = re.search(r"\bmul_mat_vec_f\s*<", name)
    if not match:
        return None
    start = match.end()
    depth = 0
    args = []
    for at in range(start, len(name)):
        ch = name[at]
        if ch == "<":
            depth += 1
        elif ch == ">":
            if depth == 0:
                return args + [name[start:at].strip()]
            depth -= 1
        elif ch == "," and depth == 0:
            args.append(name[start:at].strip())
            start = at + 1
    return []


def literal(value):
    value = re.sub(r"^\([^)]*\)\s*", "", value.strip()).lower()
    if value in ("true", "false"):
        return value == "true"
    try:
        return int(value)
    except ValueError:
        return value


def boolean(value):
    parsed = literal(value)
    return bool(parsed) if parsed in (0, 1) else parsed


def classify(name, short, geometry):
    args = template_args(name)
    category = "other"
    parsed = None
    if args is not None:
        category = "mmvf_unclassified"
        if len(args) == 11:
            parsed = dict(columns=literal(args[2]), block_size=literal(args[3]),
                has_fusion=boolean(args[4]), multi_token_ids=boolean(args[5]),
                strict_f32_ids=boolean(args[9]), paired_output=boolean(args[10]),
                types=[args[i] for i in (0, 1, 6, 7, 8)])
            bf16 = all("bfloat16" in args[i].lower() for i in (0, 6, 7))
            if (bf16 and args[1] == "float" and args[8] == "void" and parsed["columns"] in (1, 2)
                    and parsed["multi_token_ids"] is False and parsed["strict_f32_ids"] is False):
                if parsed["paired_output"] is True and parsed["has_fusion"] is True:
                    category = "bf16_paired_true_m" + str(parsed["columns"])
                elif parsed["paired_output"] is False and parsed["has_fusion"] is False:
                    category = "bf16_single_result_paired_false_m" + str(parsed["columns"])
                else:
                    category = "bf16_mmvf_other_flags"
    short_base = short.split("<", 1)[0].rsplit("::", 1)[-1].strip()
    old_small = short_base == "Kernel2" and geometry == (1, 1, 1, 32, 1, 1)
    return category, parsed, old_small


def analyze(variant):
    folder = W / "profile" / variant
    database = folder / "trace.sqlite"
    con = sqlite3.connect(database.resolve().as_uri() + "?mode=ro&immutable=1", uri=True)
    con.row_factory = sqlite3.Row
    tables = {r[0] for r in con.execute("SELECT name FROM sqlite_master WHERE type='table'")}

    def columns(table):
        return {r[1].lower(): r[1] for r in con.execute('PRAGMA table_info("' + table + '")')}

    def pid_values(table, field):
        if table not in tables:
            return set()
        actual = columns(table).get(field.lower())
        if not actual:
            return set()
        return {int(r[0]) for r in con.execute('SELECT DISTINCT "' + actual + '" FROM "' + table + '"') if r[0] is not None}

    gpu_tables = ["CUPTI_ACTIVITY_KIND_" + k for k in KINDS if "CUPTI_ACTIVITY_KIND_" + k in tables]
    if "StringIds" not in tables or "CUPTI_ACTIVITY_KIND_KERNEL" not in gpu_tables:
        raise ValueError("Missing CUDA/StringIds tables: " + str(sorted(tables)))
    encoded = set().union(*(pid_values(t, "globalPid") for t in gpu_tables))
    device_pids = pid_values("TARGET_INFO_CUDA_DEVICE", "pid")
    context_pids = pid_values("TARGET_INFO_CUDA_CONTEXT_INFO", "processId")
    candidates = device_pids & context_pids
    candidates &= {((p >> 24) & MASK) for p in encoded} | encoded
    if len(candidates) != 1:
        raise ValueError("CUDA consumer PID needs explicit resolution: " + repr(dict(
            device_pids=sorted(device_pids), context_pids=sorted(context_pids),
            activity_global_pids=sorted(encoded), candidates=sorted(candidates))))
    consumer_pid = next(iter(candidates))
    consumer_global_pids = {p for p in encoded if p == consumer_pid or ((p >> 24) & MASK) == consumer_pid}
    stream_pids = pid_values("ProcessStreams", "globalPid")
    if stream_pids and not any(p == consumer_pid or ((p >> 24) & MASK) == consumer_pid for p in stream_pids):
        raise ValueError("ProcessStreams does not confirm the selected CUDA consumer PID")
    strings = dict(con.execute("SELECT id,value FROM StringIds"))
    rows = []
    for kind in KINDS:
        table = "CUPTI_ACTIVITY_KIND_" + kind
        if table not in tables:
            continue
        selected = sorted(consumer_global_pids)
        query = "SELECT * FROM " + table + " WHERE globalPid IN (" + ",".join("?" for _ in selected) + ") ORDER BY start"
        for row in con.execute(query, selected):
            item = dict(row, kind=kind)
            item["correlationId"] = int(item.get("correlationId") or 0)
            if kind == "KERNEL":
                name = strings.get(item.get("demangledName"), "")
                short = strings.get(item.get("shortName"), "")
                geometry = tuple(item.get(k) for k in ("gridX", "gridY", "gridZ", "blockX", "blockY", "blockZ"))
                category, parsed, old_small = classify(name, short, geometry)
                item.update(full_name=name, short_name=short, geometry=geometry,
                    category=category, template=parsed, old_small_kernel2=old_small)
            rows.append(item)

    apis = defaultdict(list)
    for kind in ("RUNTIME", "DRIVER"):
        table = "CUPTI_ACTIVITY_KIND_" + kind
        if table not in tables:
            continue
        query = "SELECT * FROM " + table + " WHERE ((globalTid >> 24) & ?) = ? ORDER BY start"
        for row in con.execute(query, (MASK, consumer_pid)):
            cid = int(row["correlationId"] or 0)
            if cid:
                apis[cid].append(dict(table=kind, name=strings.get(row["nameId"], ""),
                    start=row["start"], end=row["end"], globalTid=row["globalTid"]))
    launches = {cid: [a for a in aa if "GraphLaunch" in a["name"]] for cid, aa in apis.items()}
    launches = {cid: aa for cid, aa in launches.items() if aa}
    grouped = defaultdict(list)
    unmapped = defaultdict(list)
    for row in rows:
        cid = row["correlationId"]
        if cid in launches:
            grouped[cid].append(row)
        else:
            reason = "zero_correlation" if not cid else "non_graph_api" if cid in apis else "no_consumer_api_correlation"
            unmapped[(reason, cid)].append(row)

    kernels = [r for r in rows if r["kind"] == "KERNEL"]
    categories = sorted({r["category"] for r in kernels})

    def kernel_classes(items):
        kk = [r for r in items if r["kind"] == "KERNEL"]
        result = {key: facts([r for r in kk if r["category"] == key]) for key in categories}
        result["old_small_Kernel2_grid1_block32"] = facts([r for r in kk if r["old_small_kernel2"]])
        return result

    inventory = defaultdict(list)
    for row in kernels:
        inventory[(row["full_name"], row["short_name"], row["geometry"])].append(row)
    kernel_inventory = [dict(demangled_name=key[0], short_name=key[1], grid=key[2][:3], block=key[2][3:],
        category=rr[0]["category"], template=rr[0]["template"], old_small_kernel2=rr[0]["old_small_kernel2"],
        **facts(rr)) for key, rr in inventory.items()]
    kernel_inventory.sort(key=lambda r: -r["duration_sum_ns"])
    copies = [r for r in rows if r["kind"] == "MEMCPY"]
    launch_buckets = [dict(consumer_pid=consumer_pid, correlation_id=cid,
        launch_api_events=launches[cid], multiple_api_events_same_correlation=len(launches[cid]) != 1,
        activity=activity_facts(grouped[cid]), kernel_classes=kernel_classes(grouped[cid]))
        for cid in sorted(launches, key=lambda c: min(a["start"] for a in launches[c]))]
    unmapped_groups = [dict(reason=reason, correlation_id=cid, consumer_api_events=apis.get(cid, []),
        activity=activity_facts(rr), kernel_classes=kernel_classes(rr))
        for (reason, cid), rr in sorted(unmapped.items())]
    con.close()
    result = dict(status="OFFLINE_NATIVE_CORRELATION_ANALYZED_NOT_LOGICAL_EPISODES", variant=variant,
        database=dict(path=str(database), bytes=database.stat().st_size),
        consumer=dict(pid=consumer_pid, activity_global_pids=sorted(consumer_global_pids),
            device_pids=sorted(device_pids), context_pids=sorted(context_pids),
            ProcessStreams_global_pids=sorted(stream_pids)),
        full_process=activity_facts(rows), kernel_classes=kernel_classes(rows),
        memcpy_by_copy_kind={str(k): facts([r for r in copies if r.get("copyKind") == k])
            for k in sorted({r.get("copyKind") for r in copies}, key=str)},
        kernel_inventory=kernel_inventory,
        graph_launch_api_events=sum(len(aa) for aa in launches.values()),
        graph_launch_correlation_buckets=len(launches),
        graph_launch_correlation_buckets_with_gpu=sum(bool(grouped[cid]) for cid in launches),
        graph_launch_assigned=activity_facts([r for rr in grouped.values() for r in rr]),
        graph_launch_buckets=launch_buckets,
        not_assigned_to_graph_launch=activity_facts([r for rr in unmapped.values() for r in rr]),
        not_assigned_to_graph_launch_by_reason_and_correlation=unmapped_groups,
        limits=["No NVTX: no target-episode, layer, role, warmup or decode attribution is claimed.",
            "Buckets use the actual consumer PID and matching API correlation IDs only; no time-nearest matching or graphNodeId ownership is invented.",
            "Runtime/driver GraphLaunch API rows and unique correlation buckets are reported separately; nested wrappers are not counted as independent GPU launches.",
            "A paired-false M2 kernel is the single-result fallback family; its name does not prove why that path ran.",
            "Kernel2 grid1/block32 is an observed kernel family, not proof of a particular N16 model node.",
            "Duration sums can overlap. Interval unions are traced-consumer GPU activity, not device-wide busy time or CPU self-time.",
            "Whole-process counts include cold preparation. These instrumented runs are not throughput estimates.",
            "All original SQLite rows remain retained, including unmatched/non-Graph API activity."])
    save(folder / "analysis.json", result)
    return result


def main():
    variants = sys.argv[1:] or ["control", "candidate"]
    if not variants or any(v not in ("control", "candidate") for v in variants):
        raise SystemExit("usage: analyze_profile.py [control] [candidate]")
    arms = {variant: analyze(variant) for variant in variants}
    summary = dict(script=dict(path=str(Path(__file__).resolve()),
        sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()),
        arms={v: {k: arm[k] for k in ("consumer", "full_process", "kernel_classes", "memcpy_by_copy_kind",
            "graph_launch_api_events", "graph_launch_correlation_buckets", "graph_launch_correlation_buckets_with_gpu",
            "graph_launch_assigned", "not_assigned_to_graph_launch")} for v, arm in arms.items()},
        detail_files={v: str(W / "profile" / v / "analysis.json") for v in variants},
        interpretation="No logical-episode mapping, no warmup filtering, no speed claim; full templates and all correlation buckets are in arm details.")
    save(W / "profile" / "analysis-summary.json", summary)
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
