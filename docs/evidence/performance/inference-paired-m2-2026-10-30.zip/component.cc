#include "../../tests/graph_provider_ggml_cuda/paired_projection_test.cc"
