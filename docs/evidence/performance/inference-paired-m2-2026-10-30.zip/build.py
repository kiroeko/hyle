"""Finite paired-projection build using the existing SDK/link cache, offline."""
from pathlib import Path
import importlib.util
import json
import os
import shutil
import sys
import xml.etree.ElementTree as ET

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = W.parents[1]
spec = importlib.util.spec_from_file_location('process', R / '.scratch/inference-program-identity-20261029/build.py')
b = importlib.util.module_from_spec(spec)
spec.loader.exec_module(b)
b.W = W
read, save, pin, exact, key = b.read, b.save, b.pin, b.exact, b.key


def load_module(file, name):
    spec = importlib.util.spec_from_file_location(name, file)
    value = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(value)
    return value


def refresh_lock():
    manifest = R / 'third_party/ggml_cuda_runtime/patches.json'
    raw = manifest.read_bytes().replace(b'\r\n', b'\n')
    manifest.write_bytes(raw.replace(b'\n', b'\r\n'))
    lock = R / 'cmake/HyleDependencyLock.json'
    data = read(lock)
    entries = {x['name']: x for x in data['dependencies']}
    vendor = R / 'third_party/ggml_cuda_runtime'
    contents = ''.join(p.relative_to(vendor).as_posix() + '|' +
        b.hashlib.sha256(p.read_bytes().replace(b'\r\n', b'\n').replace(b'\r', b'\n')).hexdigest() + '\n'
        for p in sorted((p for p in vendor.rglob('*') if p.is_file()),
                        key=lambda p: p.relative_to(vendor).as_posix()))
    digest = b.hashlib.sha256(contents.encode()).hexdigest()
    old = entries['ggml_cuda_runtime_patches']['vendored']['tree_sha256']
    text = lock.read_bytes().decode()
    assert text.count(old) == 1
    text = text.replace(old, digest).replace('hyle-ggml-cuda-resource-iq1-inference-v38', 'hyle-ggml-cuda-resource-iq1-inference-v39')
    lock.write_bytes(text.encode())
    entries['ggml_cuda_runtime_patches']['vendored']['tree_sha256'] = digest
    identity = entries['ggml_runtime_patches']['vendored']['tree_sha256']
    identity += entries['ggml_cpu_runtime_patches']['vendored']['tree_sha256']
    identity += pin(R / 'src/compute_ggml_runtime/prepare_mixed_cpu_manifest.py')['sha256']
    identity += pin(R / 'src/compute_ggml_runtime/prepare_cuda_iq1_manifest.py')['sha256']
    identity += digest
    identity += pin(R / 'src/compute_ggml_runtime/gated_delta_scale.h')['sha256']
    source_id = b.hashlib.sha256(identity.encode()).hexdigest()[:16]
    version = '456172ec+iq1-46cbf0e9-resource-' + source_id
    (W / 'provider-version.h').write_text('#pragma once\n#define HYLE_GGML_CUDA_PROVIDER_VERSION "' + version + '"\n')
    save(W / 'lock-update.json', dict(before_tree=old, after_tree=digest, provider_version=version,
        manifest=pin(manifest), lock=pin(lock)))
    print('Refreshed locked native content and provider identity:', version)


def materialize():
    upstream = Path('C:/Users/kiro/AppData/Local/hyle/dependencies/v1/sources/ggml-456172ec733a-41b7e10fd424')
    mixed = W / 'mixed-cpu-patches.json'
    combined = W / 'cuda-iq1-patches.json'
    load_module(R / 'src/compute_ggml_runtime/prepare_mixed_cpu_manifest.py', 'mixed').derive(
        upstream, R / 'third_party/ggml_runtime/patches.json', R / 'third_party/ggml_cpu_runtime/patches.json', mixed)
    load_module(R / 'src/compute_ggml_runtime/prepare_cuda_iq1_manifest.py', 'cuda').derive(
        upstream, mixed, R / 'third_party/ggml_cuda_runtime/patches.json',
        R / 'third_party/ggml_cuda_runtime/iq1-patches.json', combined)
    names = ['ggml-cuda.cu', 'mmvf.cu', 'mmvf.cuh', 'unary.cu', 'unary.cuh']
    manifest = read(combined)
    rows = []
    for name in names:
        entry = next(x for x in manifest['files'] if x['path'] == 'src/ggml-cuda/' + name)
        source = upstream / entry['path']
        before = source.read_bytes().replace(b'\r\n', b'\n')
        assert b.hashlib.sha256(before).hexdigest() == entry['before_sha256']
        after = before
        for edit in entry['edits']:
            old, new = edit['before'].encode(), edit['after'].encode()
            assert after.count(old) == 1
            after = after.replace(old, new, 1)
        assert b.hashlib.sha256(after).hexdigest() == entry['after_sha256']
        target = W / 'native' / entry['path']
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(after)
        rows.append(dict(original=pin(source), candidate=pin(target)))
    save(W / 'materialization.json', dict(combined=pin(combined), mixed=pin(mixed),
        inputs=[pin(R / p) for p in ['third_party/ggml_runtime/patches.json',
            'third_party/ggml_cpu_runtime/patches.json', 'third_party/ggml_cuda_runtime/patches.json',
            'third_party/ggml_cuda_runtime/iq1-patches.json', 'src/compute_ggml_runtime/prepare_mixed_cpu_manifest.py',
            'src/compute_ggml_runtime/prepare_cuda_iq1_manifest.py']], files=rows))
    print('Materialized five exact native texts; no SDK tree copy or download.')


def prepare():
    base_path = R / '.scratch/inference-source-preparation-20261030/model-link-base.json'
    base = read(base_path)
    for item in [*base['retained'], base['runtime'], base['sdk_engine_dependencies']]:
        exact(item)
    units = {}
    research = read(W / 'research.json')
    for unit in research['current_closure']['units']:
        name = unit['name']
        folder = W / 'compile' / name
        folder.mkdir(parents=True, exist_ok=True)
        original = read(unit['compile_recipe']['path'])['command']
        native = name.startswith('native_')
        args = [original[0]]
        if native:
            args += ['-I' + str(W / 'native/src/ggml-cuda'), '-I' + str(W / 'native/src')]
        for index, arg in enumerate(original[1:], 1):
            prior = original[index - 1].lower()
            if native:
                if prior in ('-o', '-mt'): arg = str(folder / 'unit.obj')
                elif prior == '-mf': arg = str(folder / 'unit.d')
                elif arg.endswith('.cu'): arg = str(W / 'native/src/ggml-cuda' / Path(arg).name)
                elif arg.startswith('-Xcompiler=-Fd'): arg = '-Xcompiler=-Fd' + str(folder / 'unit.pdb') + ',-FS'
            else:
                if prior == '/sourcedependencies': arg = str(folder / 'dependencies.json')
                elif arg.lower().startswith('/fo'): arg = '/Fo' + str(folder / 'unit.obj')
                elif arg.lower().startswith('/fd'): arg = '/Fd' + str(folder / 'unit.pdb')
                # Prior Graph receipt used a source snapshot. Compile the product tree now.
                snapshot = str(R / '.scratch/inference-indexed-store-20261028/source')
                arg = arg.replace(snapshot, str(R))
                if arg.lower().startswith('/fi') and arg.endswith('provider-version.h'):
                    arg = '/FI' + str(W / 'provider-version.h')
            args.append(arg)
        source = next(a for a in args if a.lower().endswith('.cu' if native else '.cc'))
        units[name] = dict(source=source, compile=args, original_object=unit['original_object'], native=native)
    # One TU for both directed public/recipe regressions, with original GTest entry.
    source = W / 'component.cc'
    source.write_text('#include "../../tests/graph_provider_ggml_cuda/paired_projection_test.cc"\n', encoding='utf-8')
    for name, source in [('paired', source), ('grouped', R / 'tests/graph_route_cuda/grouped_shared_activation_test.cc')]:
        folder = W / 'compile' / name
        folder.mkdir(parents=True, exist_ok=True)
        args = []
        for index, arg in enumerate(base['compile']):
            if index and base['compile'][index - 1].lower() == '/sourcedependencies': arg = str(folder / 'dependencies.json')
            elif arg.lower().startswith('/fo'): arg = '/Fo' + str(folder / 'unit.obj')
            elif arg.lower().startswith('/fd'): arg = '/Fd' + str(folder / 'unit.pdb')
            elif key(arg) == key(base['consumer_source']['path']): arg = str(source)
            args.append(arg)
        units[name] = dict(source=str(source), compile=args, native=False)
    (W / 'bin').mkdir(exist_ok=True)
    shutil.copyfile(base['runtime']['path'], W / 'bin' / Path(base['runtime']['path']).name)
    save(W / 'plan.json', dict(base=pin(base_path), units=units, retained=base['retained'], runtime=base['runtime'],
        sdk=base['sdk_engine_dependencies'], original_link=base['link'], original_consumer=base['previous_consumer'],
        materialization=pin(W / 'materialization.json'),
        cases={'paired': dict(filter='GgmlCudaPairedProjection.*', tests=6),
               'grouped': dict(filter='CudaGroupedShared.*', tests=7)}))
    print('Prepared six SDK TUs and two finite test TUs; no compile/run.')


def compile_unit(name, attempt):
    plan = read(W / 'plan.json')
    unit = plan['units'][name]
    folder = W / 'compile' / name
    b.execute(unit['compile'], folder / attempt, 1800 if unit['native'] else 300)
    files = [Path(unit['source'])]
    if not unit['native']:
        deps = read(folder / 'dependencies.json')['Data']
        files = [Path(deps['Source']), *map(Path, deps['Includes'])]
    else:
        files += [W / 'native/src/ggml-cuda/mmvf.cuh', W / 'native/src/ggml-cuda/unary.cuh',
                  R / 'src/compute_provider_ggml_cuda/native_bridge.h',
                  R / 'src/compute_provider_ggml_cuda/native_bridge_impl.h']
    files = sorted({p.resolve() for p in files if p.is_relative_to(R)})
    save(folder / 'receipt.json', dict(object=pin(folder / 'unit.obj'),
        source_identities=[pin(p) for p in files], process=pin(folder / attempt / 'process.json')))


def seal():
    plan = read(W / 'plan.json')
    replaces = {}
    for name, unit in plan['units'].items():
        if 'original_object' not in unit: continue
        receipt = read(W / 'compile' / name / 'receipt.json')
        exact(receipt['object'])
        replaces[key(unit['original_object']['path'])] = receipt['object']
    assert len(replaces) == 6
    plan['candidate_retained'] = [replaces.get(key(item['path']), item) for item in plan['retained']]
    assert len(plan['candidate_retained']) == 227
    plan['replacements'] = replaces
    save(W / 'plan.json', plan)
    print('Sealed six replaced SDK objects, 221 unchanged.')


def link(name, attempt):
    plan = read(W / 'plan.json')
    for item in plan['candidate_retained']: exact(item)
    old_consumer = read(plan['original_consumer']['path'])['object']['path']
    args = []
    for arg in plan['original_link']:
        if key(arg) in plan['replacements']: arg = plan['replacements'][key(arg)]['path']
        elif key(arg) == key(old_consumer): arg = str(W / 'compile' / name / 'unit.obj')
        for prefix, suffix in [('/OUT:', '.exe'), ('/PDB:', '.pdb'), ('/IMPLIB:', '.lib'), ('/MAP:', '.map')]:
            if arg.upper().startswith(prefix): arg = prefix + str((W / 'bin' / name).with_suffix(suffix)); break
        args.append(arg)
    for library in ('gtest_main.lib', 'gtest.lib'):
        path = R / '.scratch/build-compute-v2-dev/lib' / library
        if not any(key(arg) == key(path) for arg in args): args.append(str(path))
    b.execute(args, W / 'link' / name / attempt, 240)
    save(W / ('ready-' + name + '.json'), pin(W / 'bin' / (name + '.exe')))


def run(name, attempt):
    plan = read(W / 'plan.json'); case = plan['cases'][name]
    image = read(W / ('ready-' + name + '.json')); exact(image)
    os.environ.update(HF_HUB_OFFLINE='1', TRANSFORMERS_OFFLINE='1', HF_DATASETS_OFFLINE='1')
    folder = W / 'runs' / name / attempt
    b.execute([image['path'], '--gtest_color=no', '--gtest_filter=' + case['filter'],
               '--gtest_output=xml:' + str(folder / 'results.xml')], folder, 600)
    result = ET.parse(folder / 'results.xml').getroot()
    assert result.get('tests') == str(case['tests']) and result.get('failures') == '0' and result.get('errors', '0') == '0'
    assert not result.findall('.//skipped')
    save(folder / 'report.json', dict(status='PASS', tests=case['tests'], cases=[
        dict(name=t.get('classname') + '.' + t.get('name'), properties={
            p.get('name'):p.get('value') for p in t.findall('./properties/property')}) for t in result.findall('.//testcase')]))
    print('PASS', name)


if __name__ == '__main__':
    action = sys.argv[1]
    if action in ('materialize', 'prepare', 'seal', 'refresh_lock'): globals()[action]()
    else:
        name = sys.argv[2]; attempt = sys.argv[3] if len(sys.argv) > 3 else 'attempt1'
        {'compile': compile_unit, 'link': link, 'run': run}[action](name, attempt)
