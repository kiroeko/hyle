from pathlib import Path
from statistics import median,mean
from collections import defaultdict
import json,re,sqlite3
p=Path('/root/hyle-scratch/compute-unified/ce17-cuda-episode-diagnostic-1')
result=json.loads((p/'result.json').read_text())
analysis={'state':result['state'],'stages':[{k:s[k] for k in ('stage','elapsed_seconds','exit_code')} for s in result['stages']],'runs':[],'trace_schema':{}}
keys='schedule round side slot begin update submit wait output end cpu_begin cpu_end voluntary involuntary cpu_first cpu_last'.split()
rx=re.compile(r'DIAG,'+','.join([r'(-?\d+)']*16))
def summary(rows):
 return dict(n=len(rows),wall_median_ns=median(r['end']-r['begin'] for r in rows),wall_mean_ns=mean(r['end']-r['begin'] for r in rows),
  segments_median_ns={k:median(r[b]-r[a] for r in rows) for k,a,b in [('update','begin','update'),('submit','update','submit'),('wait','submit','wait'),('output','wait','output'),('release','output','end')]},
  segments_mean_ns={k:mean(r[b]-r[a] for r in rows) for k,a,b in [('update','begin','update'),('submit','update','submit'),('wait','submit','wait'),('output','wait','output'),('release','output','end')]},
  thread_cpu_mean_ns=mean(r['cpu_end']-r['cpu_begin'] for r in rows),voluntary=sum(r['voluntary'] for r in rows),involuntary=sum(r['involuntary'] for r in rows),
  cpu_ids=sorted({r['cpu_first'] for r in rows}|{r['cpu_last'] for r in rows}),migrations=sum(r['cpu_first']!=r['cpu_last'] for r in rows))
for run in result['runs']:
 raw=(p/(run['stage']+'.log')).read_text()
 # The original benchmark uses unbuffered stderr and buffered stdout in one
 # file. Remove only its complete diagnostic lines to rejoin split CSV rows;
 # preserve the unmodified combined log as evidence.
 text=re.sub(r'#[^\n]*\n','',raw)
 for part in text.split('DIAG_SHAPE ')[1:]:
  title=part.splitlines()[0]
  rows=[dict(zip(keys,map(int,m.groups()))) for m in rx.finditer(part)]
  assert len(rows)==12288,(run['stage'],title,len(rows))
  item={'stage':run['stage'],'shape':title,'schedules':{}}
  for schedule in (0,1):
   group=[r for r in rows if r['schedule']==schedule]
   sides={s:[r for r in group if r['side']==s] for s in (0,1)}
   rounds=defaultdict(lambda:defaultdict(list))
   for r in group:rounds[r['round']][r['side']].append(r['end']-r['begin'])
   pairs=[mean(v[0])/mean(v[1]) for v in rounds.values()]
   item['schedules'][schedule]={'sides':{s:summary(rs) for s,rs in sides.items()},'slots':{f'{s}-{slot}':summary([r for r in rs if r['slot']==slot]) for s,rs in sides.items() for slot in (0,1)},'paired_ratio_median':median(pairs),'paired_ratio_mean':mean(pairs),'paired_ratio_minmax':[min(pairs),max(pairs)]}
   if schedule==1:
    aggregated={s:[sum(mean(rounds[k][s]) for k in range(first,first+128))/128 for first in range(0,2048,128)] for s in (0,1)}
    item['schedules'][schedule]['sixteen_128_pair_groups']={'means_ns':aggregated,'marginal_ratio':median(aggregated[0])/median(aggregated[1]),'paired_ratio_median':median(a/b for a,b in zip(aggregated[0],aggregated[1]))}
  analysis['runs'].append(item)
for s in p.glob('*.sqlite'):
 c=sqlite3.connect(s)
 tables=[r[0] for r in c.execute('select name from sqlite_master where type=?',('table',))]
 api={}
 for name,durations in __import__('itertools').groupby(sorted(c.execute('select s.value,r.end-r.start from CUPTI_ACTIVITY_KIND_RUNTIME r join StringIds s on r.nameId=s.id').fetchall()),lambda x:x[0]):
  values=[x[1] for x in durations];api[name]={'n':len(values),'median_ns':median(values),'mean_ns':mean(values),'max_ns':max(values)}
 kernels={}
 for name,durations in __import__('itertools').groupby(sorted(c.execute('select s.value,k.end-k.start from CUPTI_ACTIVITY_KIND_KERNEL k join StringIds s on k.demangledName=s.id').fetchall()),lambda x:x[0]):
  values=[x[1] for x in durations];kernels[name]={'n':len(values),'median_ns':median(values),'mean_ns':mean(values),'max_ns':max(values)}
 analysis['trace_schema'][s.name]={'api':api,'kernels':kernels,'copies':c.execute('select copyKind,bytes,count(*),avg(end-start),min(end-start),max(end-start) from CUPTI_ACTIVITY_KIND_MEMCPY group by copyKind,bytes').fetchall()}
(p/'episode-analysis.json').write_text(json.dumps(analysis,indent=2)+'\n')
print(json.dumps({k:v for k,v in analysis.items() if k not in ('runs','trace_schema')},indent=2))
for item in analysis['runs']:
 print(item['stage'],item['shape'])
 for k,v in item['schedules'].items():
  print('schedule',k,'paired_ratio',round(v['paired_ratio_median'],5),'coalesced',json.dumps(v.get('sixteen_128_pair_groups',{})))
print('TRACE_SUMMARY',json.dumps(analysis['trace_schema']))
