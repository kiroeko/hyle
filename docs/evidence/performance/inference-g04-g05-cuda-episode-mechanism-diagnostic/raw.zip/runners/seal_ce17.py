from pathlib import Path
import hashlib,json,shutil,zipfile
p=Path('/root/hyle-scratch/compute-unified/ce17-cuda-episode-diagnostic-1')
root=Path('/mnt/c/public/project-hyle/hyle')
dest=root/'evidence/performance/inference-g04-g05-cuda-episode-mechanism-diagnostic'
dest.mkdir(exist_ok=False)
r=json.loads((p/'result.json').read_text());a=json.loads((p/'episode-analysis.json').read_text())
assert r['state']=='TERMINAL_DIAGNOSTIC_ONLY' and len(r['runs'])==4 and all(x['exit_code']==0 for x in r['stages'])
assert len(a['runs'])==8 and len(a['trace_schema'])==2
with zipfile.ZipFile(p/'raw.zip','w',zipfile.ZIP_DEFLATED) as z:
 for f in sorted(p.iterdir()):
  if f.is_file() and f.name not in ('raw.zip','episode','episode.o','episode.d'):
   z.write(f,f.name)
 for name in ('ce17_cuda_episode_diagnostic_wsl.py','analyze_ce17.py','seal_ce17.py'):
  z.write(root/'.scratch/inference-gaps/g04-g05'/name,'runners/'+name)
shutil.copyfile(p/'raw.zip',dest/'raw.zip')
rows=[]
for item in a['runs']:
 b=item['schedules']['0'];i=item['schedules']['1']
 rows.append(dict(stage=item['stage'],shape=item['shape'],blocked_paired_median=b['paired_ratio_median'],
  individual_paired_median=i['paired_ratio_median'],sixteen_groups_of_128_marginal_ratio=i['sixteen_128_pair_groups']['marginal_ratio'],
  blocked_sides=b['sides'],blocked_slots_median_ns={k:v['wall_median_ns'] for k,v in b['slots'].items()}))
receipt=dict(kind='G04_G05_CUDA_COMPLETE_EPISODE_MECHANISM_DIAGNOSTIC',verdict='DIAGNOSTIC_ONLY_INSTRUMENT_STILL_UNQUALIFIED',
 product_candidate='2b60d9a34be12fda9a9e3fdc26f7a61b495c3be7',source_head='1b3b5bda2',identity=r['identity'],
 stages=a['stages'],sampling_policy=r['sampling_policy'],binary_sha256=r['binary_sha256'],rows=rows,
 trace=a['trace_schema'],measured_worker_seconds=sum(x['elapsed_seconds'] for x in r['stages']),
 conclusion='Same implementation blocked holdout1.11368 versus micro-paired median0.99912, but coalescing all observed tails into16x128 arithmetic groups still gives marginal0.92292. Individual medians cannot substitute for original complete-episode mean throughput; no qualification/PASS from favorable individual medians. Trace confirms tiny GPU service plus variable host/API completion observation; OS context switches are sparse and slots lack persistent separation. Exact Windows-driver/hypervisor cause remains unresolved.',
 next='A finite workload-local per-episode interleave with larger fixed groups may test cancellation of temporal/API tails while preserving every elapsed sample and original mean-episode estimand. Requires predeclared scope; no product or shared instrumentation mutation based on this diagnostic.',
 limits=['Four processes,73728 unprofiled and24576 profiled full episodes; original3 shapes retained unprofiled,holdout-only profiler',
 'Profiler perturbs timings;GPU/API trace is mechanism evidence only,not product performance',
 'Raw combined stdout/stderr retained;analysis removes only complete hash-prefixed benchmark diagnostic lines to rejoin buffered CSV; all8x12288 rows recovered exactly',
 'Original4ms/40ms full A/A and200/500ms failures remain; all SDK/native/object SHAs verified unchanged',
 'No CUDA TU or product change; one benchmark CXX plus link only; no sanitizer or SDK rerun; private pools UNKNOWN'],
 raw_zip_sha256=hashlib.sha256((dest/'raw.zip').read_bytes()).hexdigest())
(dest/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'path':str(dest),'seconds':receipt['measured_worker_seconds'],'zip_bytes':(dest/'raw.zip').stat().st_size}))
