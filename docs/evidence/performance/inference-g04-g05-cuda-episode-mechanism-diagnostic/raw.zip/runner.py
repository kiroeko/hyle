from pathlib import Path
import hashlib,json,os,shlex,subprocess,sys,time,uuid

canonical=Path('/mnt/c/public/project-hyle/hyle')
ext=Path('/root/hyle-scratch/compute-unified')
old=ext/'g04-cuda-encoded-p1-fresh-4'
source=ext/'g04-cuda-encoded-p1-source-4'
out=ext/'ce17-cuda-episode-diagnostic-1'
out.mkdir(exist_ok=False)
name='bench/inference_resident_sdpa/cuda_encoded_page_bench.cc'
assert (canonical/name).read_bytes()==(source/name).read_bytes()
sys.path.insert(0,str(source/'scripts'))
from hyle_perf.environment import PERF_ENVIRONMENT_BLOCKLIST,PERF_ENVIRONMENT_FIXED,PERF_ENVIRONMENT_PREFIXES
from hyle_perf.machine import get_machine_profile,load_registry,expected_child_policy
from hyle_perf.runner import _apply_sampling_policy
env=os.environ.copy();env['PATH']='/usr/local/cuda-13.3/bin:'+env['PATH']
record=dict(state='SETUP',stages=[],runs=[],scope='Finite complete-episode mechanism diagnostic; no product verdict or A/A qualification.')
(out/'runner.py').write_bytes(Path(__file__).read_bytes())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save():(out/'result.json').write_text(json.dumps(record,indent=2)+'\n')
def failed(kind,error,tb):
 record.update(state='TERMINAL_SETUP_OR_ANALYSIS_FAIL',error=repr(error));save();sys.__excepthook__(kind,error,tb)
sys.excepthook=failed
record['identity']={k:subprocess.check_output(c,text=True).strip() for k,c in (
 ('host',['uname','-a']),('compiler',['g++-14','--version']),('profiler',['nsys','--version']),
 ('gpu',['nvidia-smi','--query-gpu=name,driver_version,uuid,compute_cap','--format=csv,noheader']))}
assert 'RTX 4070' in record['identity']['gpu'] and '8.9' in record['identity']['gpu']
def run(stage,cmd,environment=None,cwd=old,required=True):
 started=time.monotonic();log=out/(stage+'.log')
 with log.open('w') as f:
  p=subprocess.Popen(cmd,cwd=cwd,env=environment or env,stdout=f,stderr=subprocess.STDOUT)
  record.update(state='RUNNING',stage=stage,pid=p.pid);save();print(stage,p.pid,flush=True);code=p.wait()
 record['stages'].append(dict(stage=stage,command=cmd,exit_code=code,elapsed_seconds=time.monotonic()-started));save()
 if code and required:record['state']='TERMINAL_FAIL';save();raise SystemExit(code)
 return code
rows=json.loads(subprocess.check_output(['ninja','-C',str(old),'-t','compdb'],env=env,text=True))
row=next(r for r in rows if r['file'].endswith('cuda_encoded_page_bench.cc') and 'g04_cuda_encoded_bench_placement.dir' in r['output'])
compile_args=shlex.split(row['command']);link=[]
for line in subprocess.check_output(['ninja','-C',str(old),'-t','commands','g04_cuda_encoded_bench_placement'],env=env,text=True).splitlines():
 parts=shlex.split(line)
 if '-o' in parts and Path(parts[parts.index('-o')+1]).name=='g04_cuda_encoded_bench_placement':
  link=parts[parts.index(compile_args[0]):]
  if '&&' in link:link=link[:link.index('&&')]
assert link and row['output'] in link
reuse=sorted({(old/a).resolve() for a in link if a.endswith(('.o','.a')) and a!=row['output']})
assert len(reuse)>=3 and all(p.is_file() for p in reuse)
record.update(original_benchmark_sha256=sha(source/name),reused_objects=[dict(path=str(p),sha256=sha(p)) for p in reuse]);save()
text=(source/name).read_text()
marker='struct Harness {'
assert text.count(marker)==1
diag=r'''
struct DiagSample {
  unsigned schedule=0,round=0,side=0,slot=0;
  long long begin=0,update=0,submit=0,wait=0,output=0,end=0,cpu_begin=0,cpu_end=0;
  long voluntary=0,involuntary=0;int cpu_first=-1,cpu_last=-1;
};
DiagSample *active_sample=nullptr;
long long diag_wall(){return std::chrono::steady_clock::now().time_since_epoch().count();}
long long diag_cpu(){timespec t{};clock_gettime(CLOCK_THREAD_CPUTIME_ID,&t);return t.tv_sec*1000000000LL+t.tv_nsec;}
'''
text=text.replace(marker,diag+marker)
text='#include <time.h>\n#include <sys/resource.h>\n#include <sched.h>\n'+text
start=text.index('  c::ReadLease execute(){')
end=text.index('  std::vector<std::uint16_t> verify',start)
text=text[:start]+r'''  c::ReadLease execute(){
    const auto index=next++%slots.size();auto &slot=slots[index];
    auto prepared=take(slot.update_batch(layout));
    if(active_sample){active_sample->slot=index;active_sample->update=diag_wall();}
    if(!slot.report().reused_native_plan)fail(hyle::Status::Internal("paged warm topology rebuilt"));
    auto completion=take(prepared.run(query,key_frame,value_frame));
    if(active_sample)active_sample->submit=diag_wall();
    check(completion.wait());if(active_sample)active_sample->wait=diag_wall();
    auto result=take(slot.output());if(active_sample)active_sample->output=diag_wall();return result;
  }
'''+text[end:]
start=text.index('  // The original 4ms segments')
end=text.index('\n}\n}\nint main',start)
text=text[:start]+r'''
  std::vector<DiagSample> samples;samples.reserve(12288);
  const auto one=[&](unsigned schedule,unsigned round,unsigned side){
    DiagSample s;s.schedule=schedule;s.round=round;s.side=side;
    rusage before{},after{};getrusage(RUSAGE_THREAD,&before);s.cpu_first=sched_getcpu();
    s.cpu_begin=diag_cpu();s.begin=diag_wall();active_sample=&s;
    {auto result=(side?candidate:peer)->execute();nb::doNotOptimizeAway(result);}
    s.end=diag_wall();s.cpu_end=diag_cpu();s.cpu_last=sched_getcpu();
    getrusage(RUSAGE_THREAD,&after);active_sample=nullptr;
    s.voluntary=after.ru_nvcsw-before.ru_nvcsw;s.involuntary=after.ru_nivcsw-before.ru_nivcsw;samples.push_back(s);
  };
  for(unsigned round=0;round<8;++round){
    unsigned first=(round/2+round)%2;
    for(unsigned which=0;which<2;++which)for(unsigned i=0;i<512;++i)one(0,round,(first+which)%2);
  }
  for(unsigned round=0;round<2048;++round){
    unsigned first=(round/2+round)%2;one(1,round,first);one(1,round,1-first);
  }
  std::printf("DIAG_SHAPE q=%d,%d kv=%d,%d d=%d,%d causal=%d window=%d route=%s samples=%zu\n",q1,q2,k1,k2,dk,dv,causal,window,route.c_str(),samples.size());
  std::printf("DIAG_HEADER schedule,round,side,slot,begin,update,submit,wait,output,end,cpu_begin,cpu_end,voluntary,involuntary,cpu_first,cpu_last\n");
  for(const auto&s:samples)std::printf("DIAG,%u,%u,%u,%u,%lld,%lld,%lld,%lld,%lld,%lld,%lld,%lld,%ld,%ld,%d,%d\n",s.schedule,s.round,s.side,s.slot,s.begin,s.update,s.submit,s.wait,s.output,s.end,s.cpu_begin,s.cpu_end,s.voluntary,s.involuntary,s.cpu_first,s.cpu_last);
'''+text[end:]
before='  measure(1,17,1024,768,256,256,true,16);measure(64,128,1024,768,256,256,true,-1);measure(17,1,7,47,64,128,false,-1);'
assert text.count(before)==1
text=text.replace(before,'  if(!set("HYLE_DIAG_HOLDOUT_ONLY")){measure(1,17,1024,768,256,256,true,16);measure(64,128,1024,768,256,256,true,-1);}measure(17,1,7,47,64,128,false,-1);')
cpp=out/'episode.cc';obj=out/'episode.o';binary=out/'episode';cpp.write_text(text)
args=list(compile_args);args[args.index('-o')+1]=str(obj)
for switch,value in [('-MF',str(out/'episode.d')),('-MT',str(obj))]:
 if switch in args:args[args.index(switch)+1]=value
args[next(i for i,a in enumerate(args) if a.endswith('cuda_encoded_page_bench.cc'))]=str(cpp)
args[1:1]=['-iquote',str((source/name).parent)]
run('compile',args)
args=[str(obj) if a==row['output'] else a for a in link];args[args.index('-o')+1]=str(binary)
for i,a in enumerate(args):
 for prefix in ('-Wl,--dependency-file=','-Wl,-Map='):
  if a.startswith(prefix):args[i]=prefix+str(out/'episode-link.map')
run('link',args)
record['binary_sha256']=sha(binary)
policy=expected_child_policy(get_machine_profile(load_registry(),'W1-WSL'));record['sampling_policy']=policy;save()
with _apply_sampling_policy(policy):
 for profile in (False,True):
  for route in ('native','selected'):
   clean={k:v for k,v in env.items() if k not in PERF_ENVIRONMENT_BLOCKLIST and not any(k.startswith(p) for p in PERF_ENVIRONMENT_PREFIXES)}
   clean.update(PERF_ENVIRONMENT_FIXED)
   clean.update(HYLE_BENCH_AA_ROUTE=route,HYLE_PERF_RUN_NONCE=uuid.uuid4().hex,HYLE_BENCH_RIVAL_FIRST='1',HYLE_BENCH_PEER_ALLOCATION_FIRST='1')
   stage=('profile-' if profile else 'plain-')+route;cmd=[str(binary)]
   if profile:
    clean['HYLE_DIAG_HOLDOUT_ONLY']='1'
    cmd=['nsys','profile','--trace=cuda','--sample=none','--cpuctxsw=none','--export=sqlite','--force-overwrite=true','--output='+str(out/stage),str(binary)]
   code=run(stage,cmd,clean,required=not profile)
   record['runs'].append(dict(stage=stage,route=route,profiled=profile,exit_code=code));save()
for p in reuse:assert sha(p)==next(x['sha256'] for x in record['reused_objects'] if x['path']==str(p))
record['state']='TERMINAL_DIAGNOSTIC_ONLY';record.pop('pid',None);save();print(record['state'],flush=True)
