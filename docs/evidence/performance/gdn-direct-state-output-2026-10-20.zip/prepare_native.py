"""Extend canonical main only; compose the accepted CPU/CUDA/IQ1 source."""
from pathlib import Path
import difflib
import hashlib
import importlib.util
import json
import sys

sys.dont_write_bytecode = True
STAGE = Path(__file__).resolve().parent
ROOT = STAGE.parents[2]
UPSTREAM = Path('C:/public/tools/hyle-dependencies/v1/sources/ggml-456172ec733a-41b7e10fd424')
PATCH = ROOT / 'third_party/ggml_cuda_runtime/patches.json'
NOTICE = ROOT / 'third_party/ggml_cuda_runtime/NOTICE.md'
LOCK = ROOT / 'cmake/HyleDependencyLock.json'
TEST = ROOT / 'tests/graph_provider_ggml_cuda/gdn_typed_load_test.cc'
NAME = 'src/ggml-cuda/ggml-cuda.cu'

def sha(data):
    return hashlib.sha256(data).hexdigest()

def identity(path):
    data = path.read_bytes()
    return dict(path=str(path.resolve()), bytes=len(data), sha256=sha(data))

def save(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8')

def replay(row):
    data = (UPSTREAM / row['path']).read_bytes().replace(b'\r\n', b'\n')
    assert sha(data) == row['before_sha256'], row['path']
    for edit in row['edits']:
        before, after = edit['before'].encode(), edit['after'].encode()
        assert data.count(before) == 1, (row['path'], before[:100])
        data = data.replace(before, after, 1)
    assert sha(data) == row['after_sha256'], row['path']
    return data

def load(name):
    spec = importlib.util.spec_from_file_location(name, ROOT / 'src/compute_ggml_runtime' / (name + '.py'))
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module

def tree(root):
    rows = []
    for path in sorted((p for p in root.rglob('*') if p.is_file()), key=lambda p: p.relative_to(root).as_posix()):
        assert not path.is_symlink()
        content = path.read_bytes().replace(b'\r\n', b'\n').replace(b'\r', b'\n')
        rows.append(path.relative_to(root).as_posix() + '|' + sha(content) + '\n')
    return sha(''.join(rows).encode())

def source_id(lock):
    deps = {row['name']: row for row in lock['dependencies']}
    text = (deps['ggml_runtime_patches']['vendored']['tree_sha256'] +
        deps['ggml_cpu_runtime_patches']['vendored']['tree_sha256'] +
        sha((ROOT/'src/compute_ggml_runtime/prepare_mixed_cpu_manifest.py').read_bytes()) +
        sha((ROOT/'src/compute_ggml_runtime/prepare_cuda_iq1_manifest.py').read_bytes()) +
        deps['ggml_cuda_runtime_patches']['vendored']['tree_sha256'])
    return sha(text.encode())[:16]

def main():
    assert not (STAGE/'native-source-freeze.json').exists(), 'Already frozen'
    assert sha(PATCH.read_bytes()) == 'a63da1ac2d16f5fccba6f5d62524db3b597a65127d7eca9b1cabe304695fb269'
    before = {}
    for path in (PATCH, NOTICE, LOCK):
        output = STAGE/'before'/path.relative_to(ROOT)
        output.parent.mkdir(parents=True, exist_ok=True)
        output.write_bytes(path.read_bytes())
        before[path] = output
    # This test addition is the sole test delta. Retain its exact inverse;
    # the fixture already contains unrelated accepted cross-frontier fixes.
    test_text = TEST.read_text()
    start = test_text.index('TEST(GgmlCudaGdnTypedLoad, SingleSnapshotEndpointsKeepOldStateAcrossInvocations)')
    assert test_text[:start].endswith('\n}\n\n')
    old_test = test_text[:start][:-1] + '} // namespace\n'
    test_before = STAGE/'before'/TEST.relative_to(ROOT)
    test_before.parent.mkdir(parents=True, exist_ok=True)
    test_before.write_text(old_test, encoding='utf-8', newline='\n')
    before[TEST] = test_before

    lock = json.loads(LOCK.read_text())
    deps = {row['name']: row for row in lock['dependencies']}
    dep = deps['ggml_cuda_runtime_patches']
    assert dep['version'] == 'hyle-ggml-cuda-resource-iq1-inference-v32'
    assert tree(PATCH.parent) == dep['vendored']['tree_sha256']
    assert source_id(lock) == '2f8fc1100460ff60'
    manifest = json.loads(PATCH.read_text())
    row = next(row for row in manifest['files'] if row['path'] == NAME)
    original = replay(row).decode()
    source = original
    edits = []
    def edit(old, new):
        nonlocal source
        assert source.count(old) == 1, old[:120]
        source = source.replace(old, new, 1)
        edits.append(dict(before=old, after=new))

    anchor = '// match gated_delta_net + the strided cpy that scatters its state snapshots into the cache\n'
    edit(anchor, (STAGE/'gdn-matcher.inc').read_text() + '\n' + anchor)
    anchor = '''static void ggml_cuda_collect_fusion_alloc_deps(ggml_backend_cuda_context * cuda_ctx,
        ggml_cgraph * cgraph, Add && add) {
'''
    edit(anchor, anchor + '''    // Re-preparation and metadata probes never inherit a stale qualification,
    // including when fusion is disabled. Each Invocation owns these tensors.
    for (int i = 0; i < cgraph->n_nodes; ++i) {
        if (cgraph->nodes[i]->op == GGML_OP_GATED_DELTA_NET) {
            ggml_set_op_params_i32(cgraph->nodes[i], 1, 0);
        }
    }
''')
    anchor = '''    for (int i = 0; i < cgraph->n_nodes; ++i) {
#if !defined(GGML_USE_HIP) && !defined(GGML_USE_MUSA)
        // Match encoder priority before considering the two-output prefix.
'''
    cold = '''    for (int i = 0; i < cgraph->n_nodes; ++i) {
        ggml_cuda_gdn_state_output_match direct_state;
        if (ggml_cuda_match_gdn_state_output(cgraph, i, cuda_ctx->device, false, direct_state)) {
            const int terminal = i + direct_state.count - 1;
            for (int port = 0; port < 6; ++port) keep(cgraph->nodes[i]->src[port], terminal);
            // Packed Y is still read by the retained ordinary score CONT.
            keep(cgraph->nodes[i], terminal);
            ggml_set_op_params_i32(cgraph->nodes[i], 1, ggml_cuda_gdn_state_output_contract);
            continue;
        }
#if !defined(GGML_USE_HIP) && !defined(GGML_USE_MUSA)
        // Match encoder priority before considering the two-output prefix.
'''
    edit(anchor, cold)
    anchor = '''    if (node->op == GGML_OP_GATED_DELTA_NET) {
        ggml_cuda_gated_delta_net_fused_cache fused_state_cpy;
'''
    encode = '''    if (node->op == GGML_OP_GATED_DELTA_NET) {
        ggml_cuda_gdn_state_output_match direct_state;
        if (ggml_cuda_match_gdn_state_output(cgraph, i, cuda_ctx->device, true, direct_state)) {
            ggml_cuda_gated_delta_net_fused_cache state{
                static_cast<float *>(direct_state.state->data), 0};
            ggml_cuda_op_gated_delta_net_fused_cache(*cuda_ctx, node, state);
            // Preserve the original score payload and CONT implementation.
            ggml_cuda_dup(*cuda_ctx, direct_state.scores);
            return direct_state.count - 1;
        }
        ggml_cuda_gated_delta_net_fused_cache fused_state_cpy;
'''
    edit(anchor, encode)
    row['edits'].extend(edits)
    row['after_sha256'] = sha(source.encode())
    assert replay(row) == source.encode()
    PATCH.write_text(json.dumps(manifest, indent=2) + '\n', encoding='utf-8')
    notice = NOTICE.read_text()
    NOTICE.write_text(notice + '''
For a cold-closed single-snapshot GDN split, the existing native fused-cache
carrier may write directly into the real independently bound F32 state CONT
output. The original packed allocation and score CONT copy remain; only the
state payload copy is omitted. Both real endpoints may be published or have
additional readers. Other packed-root/tail observers, intervening math or CPY,
unsupported layouts/devices and every input/output or output/output overlap
retain the original operations. The old rollback-cache CPY route is unchanged.

Cold preparation clears and recomputes an Invocation-local private qualifier
in GDN op-parameter slot one; slot zero remains the original snapshot count,
and the unchanged GDN kernel never reads slot one. Cold closure retains all
six actual input storage roots and packed score source through the terminal
CONT. Encoding checks the local pattern, qualifier and actual CUDA storage
again, without rediscovering graph-wide consumers. The original kernel math,
typed loads, reduction, nonfinite behavior and F32 stores are unchanged. New
state storage must be disjoint from old state. Existing Invocation, capture,
Completion and failed-prefix retirement ownership remain in effect; no new
public API, executor, state version or peak-memory reduction is introduced.
''', encoding='utf-8')
    dep['version'] = 'hyle-ggml-cuda-resource-iq1-inference-v33'
    dep['vendored']['tree_sha256'] = tree(PATCH.parent)
    notice_row = next(value for value in dep['license']['files'] if value['path'].endswith('NOTICE.md'))
    notice_row['sha256'] = sha(NOTICE.read_bytes())
    LOCK.write_text(json.dumps(lock, indent=2) + '\n', encoding='utf-8')
    stamp = source_id(lock)
    (STAGE/'provider-version.h').write_text('#pragma once\n#define HYLE_GGML_CUDA_PROVIDER_VERSION "456172ec+iq1-46cbf0e9-resource-' + stamp + '"\n', encoding='utf-8')

    mixed = STAGE/'mixed-cpu-manifest.json'
    load('prepare_mixed_cpu_manifest').derive(UPSTREAM,
        ROOT/'third_party/ggml_runtime/patches.json', ROOT/'third_party/ggml_cpu_runtime/patches.json', mixed)
    composer = load('prepare_cuda_iq1_manifest')
    iq1 = ROOT/'third_party/ggml_cuda_runtime/iq1-patches.json'
    for side, product in [('before', before[PATCH]), ('source', PATCH)]:
        combined = STAGE/(side + '-combined-manifest.json')
        composer.derive(UPSTREAM, mixed, product, iq1, combined)
        target_row = next(value for value in json.loads(product.read_text())['files'] if value['path'] == NAME)
        composed_row = next(value for value in json.loads(combined.read_text())['files'] if value['path'] == NAME)
        target = STAGE/('manifest-target-' + side)/NAME
        composed = STAGE/('native-' + side)/NAME
        for path, data in [(target, replay(target_row)), (composed, replay(composed_row))]:
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(data)
    old_main = STAGE.parent/'paired-projection-route/native-source'/NAME
    assert (STAGE/'native-before'/NAME).read_bytes() == old_main.read_bytes()
    previous = STAGE.parent/'paired-projection-route/native-source'
    headers = []
    for path in sorted(previous.rglob('*')):
        if path.is_file() and path.suffix in ('.h', '.cuh'):
            relative = path.relative_to(previous)
            target = STAGE/'native-source'/relative
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(path.read_bytes())
            headers.append(dict(path=relative.as_posix(), **{key: value for key, value in identity(target).items() if key != 'path'}, source=str(target.resolve()), changed=False))
    assert len(headers) == 90
    save(STAGE/'native-header-closure.json', dict(headers=headers, canonical=str((STAGE/'native-source').resolve()), note='All 90 accepted v32 headers byte-identical; no SDK or shared cache mutation.'))
    diff = ''.join(difflib.unified_diff((STAGE/'native-before'/NAME).read_text().splitlines(True),
        (STAGE/'native-source'/NAME).read_text().splitlines(True), fromfile='before/'+NAME, tofile='after/'+NAME))
    (STAGE/'native-changes.diff').write_text(diff, encoding='utf-8', newline='\n')
    product_files = []
    product_diff = ''
    for path in (PATCH, NOTICE, LOCK, TEST):
        relative = path.relative_to(ROOT)
        snapshot = STAGE/'source'/relative
        snapshot.parent.mkdir(parents=True, exist_ok=True)
        snapshot.write_bytes(path.read_bytes())
        product_files.append(dict(name=relative.as_posix(), before=identity(before[path]), after=identity(path), snapshot=identity(snapshot)))
        product_diff += ''.join(difflib.unified_diff(before[path].read_text().splitlines(True), path.read_text().splitlines(True), fromfile='before/'+relative.as_posix(), tofile='after/'+relative.as_posix()))
    (STAGE/'product-changes.diff').write_text(product_diff, encoding='utf-8', newline='\n')
    save(STAGE/'native-product-source-freeze.json', dict(status='Source stopped; root alone owns build/GPU validation.', version=dep['version'], source_id=stamp, files=product_files, diff=identity(STAGE/'product-changes.diff'), compiled=False, GPU_executed=False))
    save(STAGE/'native-source-freeze.json', dict(
        scope='Canonical main-only edits, actual mixed CPU + CUDA + independent IQ1 composition. Source only.',
        version=dep['version'], source_id=stamp, product_before=identity(before[PATCH]), product_after=identity(PATCH),
        files=[dict(name=NAME, before=identity(STAGE/'native-before'/NAME), after=identity(STAGE/'native-source'/NAME), manifest_target_before=identity(STAGE/'manifest-target-before'/NAME), manifest_target_after=identity(STAGE/'manifest-target-source'/NAME), added_edits=len(edits))],
        native_header_closure=identity(STAGE/'native-header-closure.json'), provider_version=identity(STAGE/'provider-version.h'),
        composition_inputs=[identity(path) for path in (mixed, iq1, STAGE/'before-combined-manifest.json', STAGE/'source-combined-manifest.json')],
        source_generator=identity(Path(__file__)), diff=identity(STAGE/'native-changes.diff'),
        affected_native_owners=[NAME], affected_host_owners=['src/compute_provider_ggml_cuda/ggml_cuda_provider.cc (provider version refresh only)', 'tests/graph_provider_ggml_cuda/gdn_typed_load_test.cc'],
        compiled=False, GPU_executed=False))
    print(json.dumps(dict(source_id=stamp, native=identity(STAGE/'native-source'/NAME), freeze=identity(STAGE/'native-source-freeze.json'), product_freeze=identity(STAGE/'native-product-source-freeze.json')), indent=2))

if __name__ == '__main__':
    main()
