"""Read-only source review. Writes only this scratch stage; no build/GPU work."""
from pathlib import Path
import hashlib
import json
import shutil

ROOT = Path(__file__).resolve().parents[3]
STAGE = Path(__file__).resolve().parent
ARCH = STAGE.parent

def identity(path):
    path = Path(path)
    data = path.read_bytes()
    return {"path": str(path), "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}

sources = {
    "lowering": ROOT / "src/compute_provider_ggml_cuda/tensor_program.cc",
    "invocation": ROOT / "src/compute_provider_ggml_cuda/ggml_cuda_provider.cc",
    "graph_region": ROOT / "src/graph_provider_ggml_cuda/ggml_cuda_region.cc",
    "native_main": ARCH / "paired-projection-route/native-source/src/ggml-cuda/ggml-cuda.cu",
    "native_gdn": ARCH / "decode-major-hotspots/gated_delta_net-source.cu",
    "native_gdn_header": ARCH / "paired-projection-route/native-source/src/ggml-cuda/gated_delta_net.cuh",
    "native_copy": Path("C:/public/tools/hyle-dependencies/v1/sources/ggml-456172ec733a-41b7e10fd424/src/ggml-cuda/cpy.cu"),
    "native_metadata": Path("C:/public/tools/hyle-dependencies/v1/sources/ggml-456172ec733a-41b7e10fd424/src/ggml.c"),
    "consumer": ROOT / "tools/qwen35_text/main.cc",
    "manifest": ROOT / "third_party/ggml_cuda_runtime/patches.json",
}
pins = {name: identity(path) for name, path in sources.items()}
assert pins["native_main"]["sha256"] == "00e1870264c806ade3af3fd3372fb28caacbb59d50b99d579dba362df9f50046"
assert pins["native_gdn"]["sha256"] == "98005dfd3a78869416024c4a2f7372063887eed97bdb456285e93a71adf895b6"
for name, path in sources.items():
    if name == "manifest":
        continue
    target = STAGE / "source-before" / (name + path.suffix)
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(path, target)
    pins[name]["snapshot"] = identity(target)

review = {
  "status": "design_complete_source_only_no_product_mutation",
  "scope": "A small resource-wiring correction, not a newly identified major decode bottleneck.",
  "baseline": {
    "consumer_image_receipt": str(ARCH / "projected-bind-cold-index/checks/host1/qwen-image.json"),
    "consumer_image": json.loads((ARCH / "projected-bind-cold-index/checks/host1/qwen-image.json").read_text()),
    "native_version": "v32 source_id 2f8fc1100460ff60, mixed CPU + CUDA + independent IQ1 composed source",
    "profile": identity(ARCH / "paired-projection-route/profile/capture.sqlite"),
    "phase": "25 warm decode7..31; 596 kernels = 145 projection + 451 nonprojection",
    "state_stage_out": {"copies_per_step": 18, "bytes_per_copy": 1048576, "payload_bytes_per_step": 18874368, "profiled_sum_median_us": 30.016},
    "interpretation": "Extra payload copy is proven. Its duration sum is not recoverable wall time; no throughput gain or DRAM traffic reduction is measured here. The most recent trace predates the host-only projected-bind cold-index correction, whose current image receipt is pinned above.",
  },
  "source_identities": pins,
  "recommendation": {
    "name": "Reuse existing fused_cache state destination; preserve original score CONT",
    "smallest_product_owner": "third_party/ggml_cuda_runtime/patches.json -> src/ggml-cuda/ggml-cuda.cu only",
    "math_and_native_abi": "No GDN kernel, GDN header, public operation, Graph route, public option, executor, or tensor lowering change is required. Keep original packed allocation and original Y copy.",
    "why": "Existing GDN launch already has independent dst_d (Y) and state_d (state). Its fused_cache wrapper only changes state_d/slot stride and calls exactly the existing dispatch/template/kernel. After it, directly invoke the existing ggml_cuda_dup on the original Y CONT; this is exactly its old GGML_OP_CONT dispatcher and preserves the original F32 byte copy.",
    "encode": [
      "At the GDN try_fuse branch, first try one address-free/bound-shared matcher for the exact closed packed/View/CONT split.",
      "On success, call ggml_cuda_op_gated_delta_net_fused_cache(ctx,gdn,{float*(state_cont->data),0}), then ggml_cuda_dup(ctx,score_cont), on ctx.stream(). Return terminal_index-begin to skip the original CONT nodes and only proven intervening metadata.",
      "On failure, leave the original typed-bound validation, existing rollback-cache CPY matcher, and original GDN/CONT execution unchanged. Never dispatch a new path then return 0.",
    ],
    "cold": "The identical structural matcher with require_bound=false runs in ggml_cuda_collect_fusion_alloc_deps. Keep all six actual GDN source storage roots until its terminal CONT, and keep the packed root until that terminal as well. The latter conservatively protects the retained Y-copy source if native root ordering is state-first. This pass grants no execution eligibility; encode repeats owners, ranges, alignment and disjointness with require_bound=true.",
    "priority": "New closed CONT split is considered before old cache-CPY fusion in both allocation collection and encoder. The domains are disjoint (new path accepts CONT only; old path retains CPY). Other complete FFN/pair/cast matcher priority is unchanged.",
    "complexity": "No payload allocation/packing, no copied weights, no hot CUDA pointer query, no new retained mutable state. Use fixed matcher fields/arrays. Closure scan O(graph nodes + leafs) per structurally eligible GDN; the native managed program's capture path is the existing one.",
  },
  "exact_match_domain": {
    "operation": "GGML_OP_GATED_DELTA_NET F32, compute flag set, packed root not OUTPUT and not a view. Snapshot_count K==1. Reuse supports_gated_delta_net_typed for all current supported F32/BF16 V/beta combinations, including the all-F32 case; retain its original native S/head/batch/stride/integer-offset limits. No token-count or model/shape whitelist.",
    "device": "Initial qualification uses existing ggml_cuda_gdn_typed_bound on the packed GDN plus final state CONT (and additional score/output disjointness), so original NVIDIA/cached grid-y limits remain. Other native/device cases fall back. No SDK/device query is added.",
    "packed_sizes": "Compute score_count=S*H*T*B, state_count=S*S*H*B with checked arithmetic after original GDN metadata qualification. Require packed bytes=(score_count+state_count)*4. Scores are the exact dense F32 one-dimensional VIEW at offset 0; state is the exact dense F32 one-dimensional VIEW at score_count*4. Each has src[0]==gdn and view_src==gdn, exact counts, no other src ports, and no OUTPUT flag.",
    "real_math_span": "From GDN through the second matching CONT, the only real math is the two GGML_OP_CONT nodes, in either score/state order. Both are F32 dense independent non-view producers, with src[0] exactly their corresponding packed VIEW, equal element count/shape and no additional src ports. Require compute flags. Never cross other math, Cast, CPY, control-like work, another GDN, unrelated no-op/leaf, or an arbitrary metadata node.",
    "metadata_inside_span": "Admit only the two exact packed slice VIEWs and dense zero-offset type/count-preserving RESHAPE chains rooted at a score/state CONT already present in this span. A metadata reshape is not a CONT: the latter allocates/copies payload. No transpose, permute, strided view, offset reshape or broad is_view_or_noop skipping. Metadata after the terminal CONT can remain in the graph and execute as its original no-op.",
    "endpoint_outputs": "Both CONT endpoints, and metadata reshapes of them, may be OUTPUT and may have arbitrary later readers. Those real buffers are fully written. Do not apply private_fusion_closed blindly: it rejects a nonterminal published endpoint and requires every earlier result private.",
    "closure": "For packed GDN and the two packed-slice VIEWs only, scan every graph node/leaf's src[] and full view_src ancestry. Permit exactly gdn->two views and each view->its own CONT. Reject every other source, alias, publication, or observer of the private packed root/tail, even if it is a metadata-only OP_NONE alias. This narrower rejection also declines separately exposed packed Y views although retaining them could be mathematically safe; public Y means the actual CONT endpoint.",
    "raw_alias": "At bound encode additionally reject OP_NONE/leaf source ranges that overlap the elided packed tail without the above proven graph identity. Do not blindly reject every later produced workspace tensor with a reused numeric address: that is ordinary gallocr reuse, not an escaping observer. Unknown/raw read provenance is a fallback, never permission to elide the copy.",
    "CPY": "No CPY is admitted or skipped in this new span. An outside CPY reading packed/tail rejects it. A CPY that later reads a real CONT output is an ordinary permitted reader. CPY src[1] may be its destination/self-reference; count actual src references, do not mistake self src[1] for a private packed observer or an extra data reader. The original rollback-cache CPY matcher is unchanged.",
    "K_greater_than_one": "Fallback. Its snapshot permutation/get_rows ordering and partially written slots require a different proof; never bypass snapshot_order, retarget old rollback slots, or claim current K1 design covers MTP snapshots.",
    "Y_only_or_state_only": "If one endpoint is not in the native graph or an intervening consumer appears before the second CONT, decline. Do not force cross-branch scheduling or add public graph outputs just to match.",
  },
  "bound_read_write_contract": {
    "reads": "Actual q,k,v,decay,beta,initial-state tensors including their actual byte strides, view roots and BF16 typed-load identity. Do not bypass custom RecurrentGatedDeltaNet's F32 softplus/add/mul/sigmoid producers.",
    "writes": "GDN writes Y prefix to original packed allocation and full new state to final state CONT storage; original ggml_cuda_dup then copies packed Y prefix to real score CONT. Packed state tail becomes deliberately unwritten and therefore must remain unobservable.",
    "bounds": "Validate nonnull buffer/data, CUDA native owner/device/dev_ptr, checked strided byte extent, capacity/base/range overflow, and native element alignment for all six reads, the existing full packed allocation and both real CONT outputs. Only declared bytes are writable; public state buffer is not asserted to have packed capacity.",
    "aliases": "Reject exact or partial write/read overlaps for the state CONT versus every six GDN reads, packed allocation and score CONT. Reject score CONT overlap with packed source, state CONT or any GDN read as a conservative initial contract. Explicitly reject old initial-state == new state, even though the old rollback-cache path has a narrow in-place exception. Retain read/read aliases that original math permits.",
    "temporal": "New-state write moves from its old CONT point into GDN. There is no intervening real math in the accepted span, and every actual GDN read root is conservatively live through terminal. Bound guards reject output overlap with a read or the other output. Thus early write cannot clobber a read that original ordering needed.",
    "no_memory_claim": "Packed allocation still exists and is checked at its original full size. This proposal only deletes a state memcpy. Do not advertise reduced peak VRAM, remove gallocr storage, or bind a state-sized allocation as the packed tensor.",
  },
  "math_contract": {
    "unchanged": "Same exact compiled GDN kernel/templates, F32 state/input/output arithmetic, typed BF16 widening sites, reduction tree, exp/scale, update loop, per-token state sequencing and final F32 store. Only final state destination address changes. No precision relaxation or extra cast, no altered accumulation, no fusion of custom decay/beta preparation.",
    "nonfinite": "Y and state use the original compiled arithmetic. The removed F32-to-F32 contiguous state copy performed raw cudaMemcpyAsync and had no NaN payload/sign, signed-zero, subnormal or rounding transformation. New direct F32 store writes the same kernel result bytes to the new destination. Validate bits/NaN classes with the original path; this source proof is not an executed numeric result.",
    "oracle": "Fusion-disabled/native original packed+twoCONT, same inputs/current kernel, no Torch substitute or different reduction. Keep bitwise F32 comparison as the expected contract, including nonfinite result classes and payload where stable across identical kernel runs.",
  },
  "publication_and_lifetimes": {
    "consumer": "Current qwen consumer already owns two disjoint state tensors and binds old parity read and other parity write, waits Completion, then flips parity. No StateStore requirement explains its extra copy. The proposed destination is the existing admitted other buffer, not a new one and never old state.",
    "StateStore": "For a StateStore user bind its existing acquired new WriteLease/page as output; retain old version/read lease and commit only after existing successful Completion. Do not change version semantics or use in-place old state merely because the original cache kernel can do so.",
    "published_multi_read": "Both real Y/state endpoint buffers survive unchanged. Subsequent readers, published final reshapes, held prior-result guards and provider binding permissions remain the Graph/core contract. A held old result cannot be overwritten by a later invocation merely because two slots exist.",
    "two_invocations": "No destination pointer in immutable Program/global cache. Each existing Invocation owns its own native tensors, binding buffers and actual destinations. Match/encode uses that slot's currently bound state CONT. Existing binding-changed/capture re-record behavior, read leases, native retirement and Completion retention remain untouched.",
    "failure": "No new manual fence/early publication. Existing accepted-prefix, failed-invocation, unfinished-recording guard, drain/native-retirement and checked-region publish logic remain. A failed partially executed new output is not committed as a valid StateStore version; old state remains read-only.",
  },
  "minimal_validation_next_not_run": [
    "Parent first confirms actual current lowered GDN span/source order under the pinned image or a focused probe. Source lowering predicts Y VIEW/CONT plus state VIEW/CONT for ordinary two-output GDN and typed-load suffixes; this review did not inspect a live graph or assert 18 actual matcher hits.",
    "One focused existing GDN TU: K1 T1 and T>1, group/broadcast batch, scalar/KDA decay, all original native widths and F32/BF16 V/beta load combinations. Public Y+state outputs both read/published; compare exact old-path output bits. Keep K>1/snapshot-order existing tests as fallback neighbors.",
    "Negative closure: separately expose packed/root/tail view or raw OP_NONE tail alias; insert other math/CPY; state-only/Y-only graph; require original path and correct outputs. CPY endpoint self-reference must not cause a false positive fusion or break a valid final-output reader.",
    "Negative bound/resource: exact/partial old-state/new-state alias, score/state overlap, misalignment, wrong owner/device/range, too-small outputs. Native helper must decline/reject before new writes, with original binding contract unchanged.",
    "Two actual Invocations with distinct destinations and retained old output/Completion; exercise capture/replay/rebinding. Do not reuse live outputs across slots without original permission. Use existing retirement/accepted-prefix neighbors; no new scheduler abstraction.",
    "Actual parent build only native main plus provider version host refresh after manifest/source ID bump, and one focused test owner. No GDN/mmvf/unary/cpy native TU or header rebuild is implied by this plan.",
    "One current fixed-token Qwen64 correctness run and same-window unprofiled sample. If profiling is used, expected state D2D 18->0 and score D2D unchanged; kernel total may stay596 because these are memcpy graph nodes, not kernel launches. Report copies/bytes and actual wall separately.",
  ],
  "alternatives_rejected": [
    "Merely remove old matcher OUTPUT guard or treat CONT as VIEW: loses Y or exposes unwritten packed state; not correct.",
    "Delete state CONT in lowering: view's physical root stays packed, so current caller binding would replace the packed base/capacity. Cannot bind independent outputs that way.",
    "Make state first by changing public output order, add hidden CPY destination tensors or special provider output bindings: more moving parts than preserving the original native CONT recipe.",
    "Add a new both-Y-and-state explicit native API: possible, but unnecessary for the18MiB issue and would widen math/header owner closure; Ycopy removal can be separately justified later.",
    "New kernel/executor/StateStore mode, model whitelist, in-place old page, or early Completion: unnecessary and contrary to the required boundaries.",
  ],
  "verification_performed_here": {"read_only_source_review": True, "source_snapshots": True, "product_modified": False, "manifest_or_version_modified": False, "SDK_cache_modified": False, "compilation": False, "GPU": False, "tests": False},
}
for name, path in sources.items():
    assert identity(path)["sha256"] == pins[name]["sha256"], ("source changed during review", name)
(STAGE / "review.json").write_text(json.dumps(review, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
print(json.dumps(identity(STAGE / "review.json"), ensure_ascii=False))
