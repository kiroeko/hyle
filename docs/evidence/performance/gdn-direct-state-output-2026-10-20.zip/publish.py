"""Seal actual v33 source, narrow regressions and structural model trace evidence."""
import hashlib
import json
from pathlib import Path
import zipfile

S = Path(__file__).resolve().parent
ROOT = S.parents[2]


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))


def identity(path):
    path = Path(path).resolve()
    return dict(path=str(path), bytes=path.stat().st_size,
                sha256=hashlib.sha256(path.read_bytes()).hexdigest())


def save(path, value):
    Path(path).write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')


product = read(S / 'native-product-source-freeze.json')
native = read(S / 'native-source-freeze.json')
for row in product['files']:
    assert identity(ROOT / row['name']) == row['after']
    assert identity(row['snapshot']['path']) == row['snapshot']
    assert row['after']['sha256'] == row['snapshot']['sha256']
for row in native['files']:
    for key in ('before', 'after', 'manifest_target_before', 'manifest_target_after'):
        assert identity(row[key]['path']) == row[key]
build = read(S / 'checks/native1/summary.json')
tests = read(S / 'tests-final/summary.json')
model = read(S / 'correctness/summary.json')
profile = read(S / 'profile/summary.json')
assert build['passed'] and build['native_TUs'] == 1 and build['host_TUs'] == 3
assert tests['passed'] and tests['cases'] == 13 and tests['skipped'] == 0
assert model['passed'] and model['observation']['equal_vectors'] == 64
assert profile['passed'] and profile['official_CSV_SQLite_symbol_counts_equal']
assert profile['predictions_and_forced_tape_equal'] and not profile['throughput_claim']
warm = [row for row in profile['current_phases'] if row['index'] >= 7]
before = [row for row in profile['before_phases'] if row['index'] >= 7]
assert len(warm) == len(before) == 25
for row in warm:
    assert (row['kernels'], row['graph_launches'], row['graph_kernel_nodes'],
            row['D2D_copies'], row['D2D_bytes'], row['state_sized_D2D_copies']) == (596, 1, 591, 55, 888832, 0)
for row in before:
    assert (row['kernels'], row['D2D_copies'], row['D2D_bytes'],
            row['state_sized_D2D_copies']) == (596, 73, 19763200, 18)
for row in model['observation']['vectors']:
    assert row['byte_equal'] and row['actual']['sha256'] == row['reference']['sha256']
    assert identity(row['actual']['path']) == row['actual']
    assert identity(row['reference']['path']) == row['reference']

allowed = {'.py', '.cc', '.c', '.cu', '.h', '.cuh', '.json', '.log', '.xml',
           '.diff', '.md', '.inc', '.csv', '.tsv', '.d'}
files = sorted(p for p in S.rglob('*') if p.is_file()
               and 'tmp' not in p.relative_to(S).parts
               and not p.name.startswith('cleanup')
               and (p.suffix.lower() in allowed or p == S / 'profile/capture.sqlite'))
archive_path = ROOT / 'docs/evidence/performance/gdn-direct-state-output-2026-10-20.zip'
rows = []
with zipfile.ZipFile(archive_path, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
    for path in files:
        row = identity(path)
        row['member'] = path.relative_to(S).as_posix()
        rows.append(row)
        archive.writestr(row['member'], path.read_bytes())
    archive.writestr('payload-sha256.json', json.dumps(rows, indent=2))
with zipfile.ZipFile(archive_path) as archive:
    assert archive.testzip() is None
    for row in rows:
        data = archive.read(row['member'])
        assert len(data) == row['bytes'] and hashlib.sha256(data).hexdigest() == row['sha256']

body = dict(
    date='2026-10-20',
    scope='Windows CUDA single-snapshot GDN state destination in the existing native program; full Qwen3.5-2B BF16 text regression and structural copy trace.',
    source_id=native['source_id'], version=native['version'],
    change='Cold preparation recognizes the closed packed GDN plus score/state VIEW/CONT span and retains its actual read roots. Invocation-local qualification rechecks current ranges, owners, capacity, device and non-overlap. The original mathematical fused_cache kernel writes directly to the actual separate state CONT allocation; the original score copy remains.',
    boundaries=[
        'Only K=1; real score/state CONT endpoints may be published or have multiple readers. Escaped private packed/slice intermediates, invalid geometry and other snapshot counts retain the original path.',
        'The original mathematical GDN TU and all90 native headers are unchanged. No lowering change, public ABI or second executor was introduced.',
        'The original full packed allocation is retained; no workspace or model memory-peak saving is claimed.',
        'Cold closure is not cached permission: each invocation retains current bound-range checks, including a leaf address scan. The hot path is not claimed O(1).'],
    product_freeze=product, native_freeze=native,
    source_freeze_interpretation='compiled/GPU_executed=false fields in original source-only freezes describe their creation time. The actual later build, tests, model and profiler results below supersede those observation fields without rewriting their hashes.',
    independent_review=read(S / 'independent-review.json'),
    actual_build=build, actual_tests=tests,
    initial_neighbor_inventory_correction=read(S / 'neighbor-inventory-correction.json'),
    correctness=dict(passed=True, equal_vectors=64,
        image=model['observation']['image'],
        same_greedy_ids_as_reference=model['observation']['same_greedy_ids_as_reference'],
        same_fixed_decode_inputs=model['observation']['same_fixed_decode_inputs'],
        summary=identity(S / 'correctness/summary.json'),
        note='The new endpoint test uses the same current provider for its direct reference, so that arm is not a forced legacy-path comparison. It also uses an independent recurrence oracle and checks old states; the full-model vectors compare to separately retained pre-change observations. Neither establishes independent model quality acceptance.'),
    structural_trace=dict(passed=True, warm_phases=25,
        retained_before=profile['before_decode7'], current=profile['current_decode7'],
        eliminated_state_copies_per_decode=18,
        eliminated_state_payload_bytes_per_decode=18874368,
        unchanged_kernels_per_decode=596, unchanged_GraphLaunches_per_decode=1,
        remaining_D2D_size_histogram={'36864':18, '8192':18, '4096':19},
        score_8192B_copies_retained_per_decode=18,
        official_CSV_SQLite_symbol_counts_equal=True,
        summary=identity(S / 'profile/summary.json'),
        capture_sqlite=identity(S / 'profile/capture.sqlite'),
        original_nsys_report_retained_outside_archive=identity(S / 'profile/capture.nsys-rep')),
    archive=identity(archive_path), payloads=rows,
    archive_verified=dict(CRC=True, all_payload_SHA256=True),
    throughput_claim=False, model_memory_peak_claim=False,
    limits=[
        'One fresh software-instrumented process versus a retained earlier trace provides structural copy/kernel counts. Driver13.4 against Nsight driver13.3 fallback diagnostics are retained; durations are neither throughput nor recoverable wall time.',
        'No fresh unprofiled throughput window or full model memory-peak measurement was run for this batch. Prior per-copy cumulative duration is a diagnostic budget, not a promised speedup.',
        'Initial9 actually linked CUDA cases passed, but the wrapper correctly failed its intended13-case count because4 older L2 cases were absent. Their current owner was freshly compiled and the final13-case image ran successfully. Both records are retained.',
        'Build reused the current source/object closure and refreshed1 NVCC plus3 CXX owners; final model/tests links also retain the separately verified StateWriter extent fix. No SDK rebuild, Linux/macOS execution or cross-model completion is claimed.',
        'Archive contains source/commands/results and full structural SQLite, but excludes executables, objects, libraries, SDKs and duplicate64 vector payloads; exact binary/vector identities remain in archived JSON.'])
save(archive_path.with_suffix('.json'), body)
print(json.dumps(dict(published=True, payloads=len(rows), archive=identity(archive_path)), indent=2), flush=True)
