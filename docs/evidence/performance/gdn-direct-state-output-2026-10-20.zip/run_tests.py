"""New K1 state endpoints, existing typed/snapshot paths and shared-route neighbors."""
import importlib.util
import argparse
from pathlib import Path
import sys
import xml.etree.ElementTree as ET
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('gdn_state_test_helpers',S/'build.py')
h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
b,c=h.b,h.c;build=S/'checks/native1'
parser=argparse.ArgumentParser();parser.add_argument('--destination',default='tests-final');args=parser.parse_args()
assert Path(args.destination).name==args.destination and args.destination.startswith('tests')
out=S/args.destination;out.mkdir(exist_ok=False);(out/'tmp').mkdir()
image=c.read(build/'tests-image.json');assert b.same(image)
link=c.read(build/'tests-link-plan.json');env,runtime=b.environment(link['command'],[r['path'] for r in link['inputs']],out)
filters=['GgmlCudaGdnTypedLoad.*','GgmlCudaPairedProjection.*','GgmlCudaGdnL2Fusion.*']
c.save(out/'inputs.json',dict(image=image,filters=filters,expected_cases=13,runtime=runtime))
try:c.execute('tests',[image['path'],'--gtest_filter='+':'.join(filters),'--gtest_output=xml:'+str(out/'results.xml')],env,out)
finally:
    cases=ET.parse(out/'results.xml').findall('.//testcase') if (out/'results.xml').exists() else []
    failures=[dict(name=r.attrib['classname']+'.'+r.attrib['name'],details=[f.text for f in r.findall('failure')]) for r in cases if r.find('failure') is not None]
    skipped=sum(r.find('skipped') is not None for r in cases)
    actual=[r.attrib['classname']+'.'+r.attrib['name'] for r in cases]
    passed=len(cases)==13 and not failures and not skipped
    c.save(out/'summary.json',dict(passed=passed,cases=len(cases),skipped=skipped,failures=failures,image=image,actual=actual))
assert passed
print('GDN_DIRECT_STATE_TESTS',len(cases),'passed',flush=True)
