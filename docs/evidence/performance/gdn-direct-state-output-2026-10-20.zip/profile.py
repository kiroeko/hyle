"""One structural trace: retain kernels/math while eliminating the state stage-out."""
import argparse
import collections
import csv
import importlib.util
import json
from pathlib import Path
import sys
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent;A=S.parent
spec=importlib.util.spec_from_file_location('gdn_output_profile_common',A/'cold-prepare-review/profile.py')
p=importlib.util.module_from_spec(spec);spec.loader.exec_module(p)
b,c=p.b,p.c
parser=argparse.ArgumentParser();parser.add_argument('--analyze-only',action='store_true');args=parser.parse_args()
build=S/'checks/native1';out=S/'profile';stem=out/'capture'
image=c.read(build/'qwen-image.json');assert b.same(image)
numeric=c.read(S/'correctness/summary.json');assert numeric['passed'] and numeric['observation']['image']==image
link=c.read(build/'qwen-link-plan.json');old=c.read(A/'cold-prepare-review/profile/plan.json')
command=old['consumer_command'].copy();command[0]=image['path'];assert '--trace' not in command
baseline=A/'paired-projection-route/profile/capture.sqlite'
if not args.analyze_only:
    out.mkdir(exist_ok=False);(out/'tmp').mkdir()
    env,runtime=b.environment(link['command'],[row['path'] for row in link['inputs']],out)
    nsys=old['commands']['profile'][0]
    commands=dict(profile=[nsys,'profile','--trace=cuda','--sample=none','--cpuctxsw=none','--cuda-trace-all-apis=true',
        '--cuda-graph-trace=node:host-only','--discard-environment=true','--output='+str(stem),*command],
        export=[nsys,'export','--type=sqlite','--output='+str(stem)+'.sqlite',str(stem)+'.nsys-rep'],
        stats=[nsys,'stats','--report=cuda_gpu_kern_sum','--format=csv','--output='+str(stem),str(stem)+'.sqlite'])
    c.save(out/'plan.json',dict(image=image,commands=commands,consumer_command=command,runtime=runtime,
        baseline=b.identity(baseline),correctness=b.identity(S/'correctness/summary.json'),script=b.identity(Path(__file__)),throughput_claim=False))
    for tag,argv in commands.items():c.execute(tag,argv,env,out)
data=p.trace(stem.with_suffix('.sqlite'));old_data=p.trace(baseline)
official=collections.Counter()
with (out/'capture_cuda_gpu_kern_sum.csv').open(encoding='utf-8-sig',newline='') as f:
    for row in csv.DictReader(f):official[row['Name']]+=int(row['Instances'].replace(',',''))
assert official==collections.Counter(row['name'] for row in data['kernels'])

def phases(trace):
    tokens=sorted((row for row in trace['copies'] if row['copyKind']==2 and row['bytes']==4),key=lambda row:row['end'])
    assert len(tokens)==32
    result=[]
    for index in range(1,32):
        lo,hi=tokens[index-1]['end'],tokens[index]['end']
        kernels=[row for row in trace['kernels'] if lo<row['start'] and row['end']<=hi]
        copies=[row for row in trace['copies'] if lo<row['start'] and row['end']<=hi]
        runtime=[row for row in trace['runtime'] if lo<row['start'] and row['end']<=hi]
        dtod=[row for row in copies if row['copyKind']==8]
        result.append(dict(index=index,**p.summarize_kernels(kernels),
            graph_launches=sum(p.api_name(row['name'])=='cudaGraphLaunch' for row in runtime),
            graph_kernel_nodes=sum(bool(row.get('graphNodeId')) for row in kernels),
            D2D_copies=len(dtod),D2D_bytes=sum(row['bytes'] for row in dtod),
            state_sized_D2D_copies=sum(row['bytes']==1048576 for row in dtod),
            D2D_size_histogram=dict(collections.Counter(row['bytes'] for row in dtod))))
    return result
current=phases(data);before=phases(old_data);warm=current[6:];old_warm=before[6:]
for kind,value in data['streams'].items():(out/('target.'+kind+'.log')).write_text(value,encoding='utf-8')
targets=[json.loads(line) for line in data['streams'].get('stdout','').splitlines() if line.startswith('{') and 'generated_ids' in line]
assert len(targets)==1 and targets[0]['generated_ids']==numeric['observation']['generated_ids']
expected_decode=list(map(int,Path(command[command.index('--decode-ids')+1]).read_text().split()))
assert targets[0]['decode_input_ids']==expected_decode
passed=all(new['kernels']==596 and new['graph_launches']==1 and sum(new['casts'].values())==55 and
    old['state_sized_D2D_copies']==18 and new['state_sized_D2D_copies']==0 and
    old['D2D_copies']-new['D2D_copies']==18 and old['D2D_bytes']-new['D2D_bytes']==18874368
    for old,new in zip(old_warm,warm))
c.save(out/'diagnostics.json',data['diagnostics'])
c.save(out/'summary.json',dict(passed=passed,current_decode7=warm[0],before_decode7=old_warm[0],
    current_phases=current,before_phases=before,official_CSV_SQLite_symbol_counts_equal=True,
    predictions_and_forced_tape_equal=True,throughput_claim=False,diagnostics=data['diagnostics'],
    limits='One fresh instrumented process versus a retained earlier trace for structural copy/kernel counts. Durations are not throughput or recoverable wall time; unsupported-driver/software-trace diagnostics retained.'))
assert passed
print('GDN_DIRECT_STATE_PHYSICAL',warm[0],flush=True)
