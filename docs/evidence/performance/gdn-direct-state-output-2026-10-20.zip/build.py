"""Main-only CUDA routing delta; retain all existing mathematical objects."""
import argparse
import concurrent.futures
import importlib.util
from pathlib import Path
import sys
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent;A=S.parent;ROOT=S.parents[2]
spec=importlib.util.spec_from_file_location('gdn_output_helpers',A/'paired-projection-route/build.py')
h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
b,c=h.b,h.c

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--build',action='store_true');parser.add_argument('--resume',action='store_true');args=parser.parse_args()
    out=S/'checks/native1';out.mkdir(parents=True,exist_ok=True);(out/'tmp').mkdir(exist_ok=True)
    paths={arm:A/'projected-bind-cold-index/checks/host1'/(arm+'-link-plan.json') for arm in ('tests','qwen')}
    bases={arm:c.read(path) for arm,path in paths.items()};meta=h.h.h.metadata(bases)
    owners={arm:{Path(meta[c.key(row['path'])]['source_path']).name:dict(meta[c.key(row['path'])],old_object=row)
        for row in base['inputs'] if c.key(row['path']) in meta} for arm,base in bases.items()}
    rows=[]
    owner=owners['qwen']['ggml_cuda_provider.cc'];source=ROOT/'src/compute_provider_ggml_cuda/ggml_cuda_provider.cc';tag='provider'
    command=b.host_command(owner['command'],source,tag,out)
    command=['/FI'+str(S/'provider-version.h') if arg.lower().startswith('/fi') and Path(arg[3:]).name=='provider-version.h' else arg for arg in command]
    rows.append(dict(tag=tag,kind='host',source=b.identity(source),source_name=source.name,command=command,object=str(out/(tag+'.obj'))))
    owner=owners['qwen']['ggml-cuda.cu'];source=S/'native-source/src/ggml-cuda/ggml-cuda.cu';tag='native-main'
    recipe=[];skip=False
    for arg in owner['command']:
        if skip:skip=False
        elif arg in ('-ccbin','--compiler-bindir'):skip=True
        elif not(arg.startswith(('-ccbin=','--compiler-bindir=')) or arg.startswith('-I') and ('.scratch' in arg or 'reference-windows' in arg)):recipe.append(arg)
    command=b.native_command(recipe,source,tag,out)
    command[1:1]=['-I'+str(S/'native-source'/part) for part in ('src/ggml-cuda','src','include')]
    rows.append(dict(tag=tag,kind='native',source=b.identity(source),source_name=source.name,command=command,object=str(out/(tag+'.obj'))))
    assert 'gdn_typed_load_test.cc' not in owners['tests']
    recipe=c.read(A/'bf16-grouped-bank/checks/native1/grouped-test-identity.json')['command']
    source=ROOT/'tests/graph_provider_ggml_cuda/gdn_typed_load_test.cc';tag='gdn-output-test'
    rows.append(dict(tag=tag,kind='host',source=b.identity(source),command=b.host_command(recipe,source,tag,out),object=str(out/(tag+'.obj'))))
    assert 'gdn_l2_fusion_test.cc' not in owners['tests']
    source=ROOT/'tests/graph_provider_ggml_cuda/gdn_l2_fusion_test.cc';tag='gdn-l2-neighbor-test'
    rows.append(dict(tag=tag,kind='host',source=b.identity(source),command=b.host_command(recipe,source,tag,out),object=str(out/(tag+'.obj'))))
    frozen=[b.identity(S/name) for name in ('native-source-freeze.json','native-product-source-freeze.json','native-header-closure.json','provider-version.h')]
    for row in c.read(S/'native-product-source-freeze.json')['files']:frozen.extend((row['after'],row['snapshot']))
    frozen.extend(row['source'] for row in rows)
    headers=c.read(S/'native-header-closure.json')['headers'];assert len(headers)==90 and not any(row['changed'] for row in headers)
    frozen.extend(dict(path=row['source'],bytes=row['bytes'],sha256=row['sha256']) for row in headers)
    state=A/'state-writer-slice-fix/checks';state_object=c.read(state/'after-state-identity.json')['object'];assert b.same(state_object)
    frozen.append(state_object)
    plan=dict(compile=rows,base_paths={k:str(v) for k,v in paths.items()},frozen=frozen,links={},host_TUs=3,native_TUs=1,
        SDK_rebuild=False,consumer_main_reused=True,unchanged_native_headers=90,retained_state_fix_object=state_object)
    c.save(out/'plan.json',plan);print('GDN_DIRECT_STATE_PLAN',len(rows),flush=True)
    if not args.build:return
    def check():
        for row in frozen:assert b.same(row),row['path']
    for base in bases.values():
        for row in base['inputs']:assert b.same(row),row['path']
    env,runtime=b.environment(bases['qwen']['command'],[r['path'] for r in bases['qwen']['inputs']],out)
    c.save(out/'runtime-environment.json',dict(runtime=runtime,PATH=env['PATH']))
    def compile_one(row):
        check();receipt=out/(row['tag']+'-identity.json')
        if args.resume and receipt.exists():
            old=c.read(receipt)
            if old['command']==row['command'] and b.same(old['object']) and all(b.same(d) for d in old['dependencies']):
                print('REUSE',row['tag'],flush=True);return row['tag'],old
        c.execute(row['tag']+'-compile',row['command'],env,out);check()
        if row['kind']=='host':
            dep=c.read(out/(row['tag']+'-deps.json'))['Data'];paths=[dep['Source'],*dep['Includes']]
        else:
            paths=[row['source']['path']]
            for line in (out/(row['tag']+'.d')).read_text(encoding='utf-8').splitlines()[1:]:
                value=line.strip().removesuffix('\\').strip().replace('\\ ',' ')
                if value:paths.append(value)
        result=dict(command=row['command'],source=row['source'],object=b.identity(row['object']),dependencies=[b.identity(p) for p in dict.fromkeys(paths)])
        c.save(receipt,result);return row['tag'],result
    finished={};errors=[]
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
        for future in concurrent.futures.as_completed([pool.submit(compile_one,row) for row in rows]):
            try:
                tag,result=future.result();finished[tag]=result
            except Exception as e:errors.append(repr(e))
    c.save(out/'compile-summary.json',dict(passed=not errors,errors=errors))
    if errors:raise RuntimeError(errors)
    for arm,base in bases.items():
        replaced={c.key(owners[arm][row['source_name']]['old_object']['path']):finished[row['tag']]['object'] for row in rows if 'source_name' in row}
        old_state=[row for row in base['inputs'] if Path(row['path']).name.lower()=='hyle_compute_state.lib'];assert len(old_state)==1
        replaced[c.key(old_state[0]['path'])]=state_object
        lookup={c.key(row['path']):row for row in base['inputs']};lookup.update({c.key(row['path']):row for row in replaced.values()})
        command=[replaced.get(c.key(arg),{}).get('path',arg) for arg in base['command'] if not arg.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:'))]
        if arm=='tests':
            for test_tag in ('gdn-output-test','gdn-l2-neighbor-test'):
                obj=finished[test_tag]['object'];command.insert(1,obj['path']);lookup[c.key(obj['path'])]=obj
        image=out/(arm+'.exe');command+=['/OUT:'+str(image),'/MAP:'+str(image.with_suffix('.map')),'/IMPLIB:'+str(image.with_suffix('.lib'))]
        inputs=[lookup[c.key(arg)] for arg in command if Path(arg).is_absolute() and Path(arg).suffix.lower() in ('.obj','.lib')]
        assert len(inputs)==len({c.key(row['path']) for row in inputs})
        for row in inputs:assert b.same(row),row['path']
        check();link=dict(command=command,inputs=inputs);prior=out/(arm+'-link-plan.json');imagepath=out/(arm+'-image.json')
        reuse=args.resume and prior.exists() and imagepath.exists() and c.read(prior)==link and b.same(c.read(imagepath))
        if reuse:print('REUSE_LINK',arm,flush=True)
        else:c.execute(arm+'-link',command,env,out)
        check();c.save(prior,link);c.save(imagepath,b.identity(image));plan['links'][arm]=dict(**link,image=str(image))
    # CPU has no CUDA owner; reuse the tested state-fix image with all common
    # Plan owners from the previous batch, without another duplicate image.
    cpu=c.read(state/'after-link-plan.json');cpu_image=c.read(state/'after-image.json');assert b.same(cpu_image)
    c.save(out/'cpu-link-plan.json',cpu);c.save(out/'cpu-image.json',cpu_image)
    plan['links']['cpu']=dict(**cpu,image=cpu_image['path'])
    c.save(out/'plan.json',plan);c.save(S/'latest-plan.json',dict(plan=str(out/'plan.json')))
    c.save(out/'summary.json',dict(passed=True,host_TUs=3,native_TUs=1,SDK_rebuild=False,consumer_main_reused=True,CPU_image_reused=True))
    print('GDN_DIRECT_STATE_BUILT',flush=True)

if __name__=='__main__':main()
