"""List this batch's private benchmark link outputs; never deletes files."""
import hashlib
import json
from pathlib import Path

S = Path(__file__).resolve().parent


def identity(path):
    return dict(path=str(path), bytes=path.stat().st_size,
                sha256=hashlib.sha256(path.read_bytes()).hexdigest())


def main():
    publication = json.loads((S / 'publication.json').read_text())
    receipt = publication['archive']
    assert receipt['crc_verified'] and receipt['payload_sha256_verified']
    assert identity(Path(receipt['path'])) == {key: receipt[key] for key in ('path', 'bytes', 'sha256')}
    directory = (S / 'benchmark/build').resolve()
    candidates = []
    for arm in ('control', 'new'):
        for suffix in ('.exe', '.map', '.lib', '.exp', '.pdb'):
            path = (directory / (arm + suffix)).resolve()
            assert path.parent == directory and path.is_relative_to(S)
            if path.exists():
                candidates.append(identity(path))
    plan = dict(planning_only=True, deletion_executed=False,
                prerequisite_archive=receipt, candidates=candidates,
                total_bytes=sum(row['bytes'] for row in candidates),
                retained='All objects, source, recipes, raw results, profile data, and checks/host1/tests.exe plus tests.map.',
                next_step='Root may copy these exact checked targets into root test.ps1; this helper never edits test.ps1 or deletes.')
    (S / 'cleanup-plan.json').write_text(json.dumps(plan, indent=2) + '\n')
    print(json.dumps(dict(candidates=len(candidates), total_bytes=plan['total_bytes'], deletion_executed=False)))


if __name__ == '__main__':
    main()
