"""Freeze the native C++ pair adapter; no build or GPU operations."""
from pathlib import Path
import difflib
import hashlib
import json

STAGE = Path(__file__).resolve().parent
ROOT = STAGE.parents[2]
FILES = ['src/compute_provider_cuda/' + name for name in
         ('fp8_provider.cc', 'fp8_provider.h', 'cuda_provider.cc', 'fp8_shared_linear.h')]


def identity(path):
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())


def save(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8')


def main():
    rows, diff = [], []
    for rel in FILES:
        before = STAGE / 'native-before' / rel
        product = ROOT / rel
        snapshot = STAGE / 'native-source' / rel
        snapshot.parent.mkdir(parents=True, exist_ok=True)
        snapshot.write_bytes(product.read_bytes())
        old = before.read_text() if before.exists() else ''
        diff.extend(difflib.unified_diff(old.splitlines(True), product.read_text().splitlines(True),
                                       'before/' + rel, 'after/' + rel))
        rows.append(dict(source=rel, before=identity(before) if before.exists() else None,
                         after=identity(product), snapshot=identity(snapshot)))
    (STAGE / 'native-changes.diff').write_text(''.join(diff), encoding='utf-8')
    old = (STAGE / 'native-before/src/compute_provider_cuda/fp8_provider.cc').read_text()
    new = (ROOT / 'src/compute_provider_cuda/fp8_provider.cc').read_text()
    old_select = old[old.index('Result<Shape> select('):old.index('Status qualify_device(')]
    new_select = new[new.index('Result<Shape> select_one('):new.index('Result<Shape> select(')]
    assert old_select.replace('select(Operation', 'select_one(Operation').split() == new_select.split()
    save(STAGE / 'native-source-freeze.json', dict(
        status='native C++ source frozen; no build/GPU validation by owner',
        files=rows, diff=identity(STAGE / 'native-changes.diff'),
        public_API_changed=False, native_CUDA_source_changed=False,
        AOT_cubins_vendor_lock_changed=False,
        cuda_provider_before='Snapshot taken after qualified-entry cleanup by separate owner, SHA724200e41e15c2078029a3fe6788cd13cf49092f0250c31ce3e54862fccf26ad.',
        API=dict(header='src/compute_provider_cuda/fp8_shared_linear.h',
                 descriptor='hyle::compute::cuda_native::internal::Float8BlockLinearPair',
                 fields=['scale_rounding', 'absmax_floor'],
                 operation_id=['0x48594c4543554441', '0x4650385041490001'],
                 inputs=['A', 'W0', 'W1'], outputs=['Y0', 'Y1'], native_route=22),
        standalone_select_unchanged_except_function_name=True,
        native_owners_to_refresh=['src/compute_provider_cuda/fp8_provider.cc',
                                 'src/compute_provider_cuda/cuda_provider.cc'],
        build_run=False, GPU_run=False))
    print(json.dumps(identity(STAGE / 'native-source-freeze.json'), indent=2))


if __name__ == '__main__':
    main()
