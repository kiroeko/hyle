// Same public Graph and Commands submit->wait boundary in both linked images.
// Only graph_route_cuda/cuda_context.cc differs (plain vs decorated SGLang).
#include "hyle/compute/backends/cuda.h"
#include "hyle/compute/providers/cuda.h"
#include "hyle/compute/model_ops.h"
#include "hyle/graph/cuda.h"
#include "hyle/platform/thread.h"
#include <cuda_profiler_api.h>

#include <algorithm>
#include <array>
#include <chrono>
#include <cmath>
#include <cstdint>
#include <cstring>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <span>
#include <stdexcept>
#include <string>
#include <vector>

namespace c = hyle::compute;
namespace g = hyle::graph;
namespace m = hyle::mem;
template<class T> T take(hyle::Result<T> result) {
  if (!result) throw std::runtime_error(std::string(result.error().message()));
  return std::move(*result);
}
void check(hyle::Status status) {
  if (!status.ok()) throw std::runtime_error(std::string(status.message()));
}
void profiler(cudaError_t status) {
  if (status != cudaSuccess) throw std::runtime_error(cudaGetErrorString(status));
}
struct Drain final { c::Queue &queue; ~Drain() { (void)queue.drain(); } };
constexpr std::int64_t M = 32, K = 1024;
constexpr std::array<std::int64_t, 2> N{512, 768};
constexpr float kFloor = 1.0e-10F;
using Bytes = std::vector<std::byte>;

// Original E4M3FN code/scale payload layout; values are finite dyadics.
// No decoded full-W bank or CPU GEMM is constructed for this timing workload.
Bytes weight(const c::TensorDesc &description, std::int64_t n, unsigned seed) {
  Bytes bytes(take(description.required_bytes()));
  constexpr std::array<std::uint8_t, 8> codes{0x30,0x38,0x3c,0x40,0xb0,0xb8,0xbc,0xc0};
  for (std::int64_t row = 0; row < n; ++row)
    for (std::int64_t col = 0; col < K; ++col)
      bytes[static_cast<std::size_t>(row * K + col)] = std::byte{codes[(row * 7 + col * 11 + seed) % 8]};
  for (std::int64_t row = 0; row < n / 128; ++row)
    for (std::int64_t group = 0; group < K / 128; ++group) {
      const float scale = std::ldexp(1.F, -7 + int((row + group + seed) % 3));
      std::memcpy(bytes.data() + n * K + (row * (K / 128) + group) * sizeof(float), &scale, sizeof(float));
    }
  return bytes;
}
m::Buffer upload(m::MemoryResourceRef memory, std::span<const std::byte> bytes) {
  auto buffer = take(m::Buffer::create(memory, bytes.size(), 256));
  check(buffer.view().write(bytes));
  return buffer;
}
double median(std::vector<double> values) {
  std::ranges::sort(values);
  return (values[(values.size()-1)/2] + values[values.size()/2]) / 2;
}

int main(int argc, char **argv) try {
  int iterations = 256, warmup = 64, expected_shared = -1, trace = 0, cpu = -1;
  std::string output_prefix;
  for (int i = 1; i < argc; i += 2) {
    if (i + 1 == argc) throw std::runtime_error("option requires value");
    const std::string flag(argv[i]);
    if (flag == "--output-prefix") output_prefix = argv[i+1];
    else if (flag == "--iterations") iterations = std::stoi(argv[i+1]);
    else if (flag == "--warmup") warmup = std::stoi(argv[i+1]);
    else if (flag == "--expect-shared") expected_shared = std::stoi(argv[i+1]);
    else if (flag == "--trace") trace = std::stoi(argv[i+1]);
    else if (flag == "--cpu") cpu = std::stoi(argv[i+1]);
    else throw std::runtime_error("unknown option: " + flag);
  }
  if (iterations < 1 || warmup < 0 || output_prefix.empty() ||
      (expected_shared != 0 && expected_shared != 1) || (trace && (iterations != 1 || warmup != 1)))
    throw std::runtime_error("invalid benchmark arguments");
  if (cpu >= 0) check(hyle::platform::this_thread::set_affinity(
      hyle::platform::CpuAffinity(static_cast<unsigned>(cpu))));
  auto context = take(g::cuda::create_context());
  auto memory = take(c::cuda::MemoryResource::create(context, c::cuda::MemoryKind::kDevice));
  auto queue = take(context.create_queue());
  check(queue.reserve_completions(2));
  const auto ad = take(c::TensorDesc::dense(c::DataType::kBFloat16, std::array{M,K}));
  std::vector<std::uint16_t> activation(static_cast<std::size_t>(M*K));
  for (std::size_t i = 0; i < activation.size(); ++i)
    activation[i] = static_cast<std::uint16_t>(0x3c00 + (i * 13 + i / K) % 96 + ((i & 1) ? 0x8000 : 0));
  auto input = upload(memory.ref(), std::as_bytes(std::span(activation)));
  auto builder = take(g::GraphBuilder::create());
  const auto a = take(builder.input(ad));
  std::array<c::TensorDesc, 2> wd, yd;
  std::array<m::Buffer, 2> weights, outputs;
  std::array<g::ValueId, 2> w, y;
  for (std::size_t branch = 0; branch < 2; ++branch) {
    wd[branch] = take(c::float8_weight_description(K, N[branch], c::Float8ScaleMode::kFloat32Block128));
    yd[branch] = take(c::TensorDesc::dense(c::DataType::kBFloat16, std::array{M,N[branch]}));
    weights[branch] = upload(memory.ref(), weight(wd[branch], N[branch], unsigned(branch)));
    outputs[branch] = take(m::Buffer::create(memory.ref(), take(yd[branch].required_bytes()), 256));
    w[branch] = take(builder.input(wd[branch]));
    const auto node = take(builder.add_node(c::model_ops::float8_block_linear(
        c::model_ops::Float8ScaleRounding::kNone, kFloor), std::array{a, w[branch]}));
    y[branch] = take(builder.result(node));
  }
  check(builder.publish(y[1])); check(builder.publish(y[0]));
  auto compiled = take(g::cuda::compile(take(std::move(builder).finish()), context, memory.ref()));
  if (compiled.report.step_count() != (expected_shared ? 1u : 2u))
    throw std::runtime_error("unexpected standalone/shared Graph step count");
  std::size_t dispatches = 0, step_workspace = 0;
  for (std::size_t i = 0; i < compiled.report.step_count(); ++i) {
    const auto step = take(compiled.report.step(i));
    if (step.provider.id != c::cuda_native::kSglangProviderId)
      throw std::runtime_error("benchmark must retain original SGLang provider");
    dispatches += step.dispatch_count;
    step_workspace += step.workspace.size;
  }
  if (dispatches != (expected_shared ? 3u : 4u)) throw std::runtime_error("unexpected declared dispatch count");
  auto slot = take(compiled.executable.create_invocation());
  Drain drain{queue};
  check(slot.bind(a, take(c::ConstTensorView::create(ad, input.view()))));
  for (std::size_t branch = 0; branch < 2; ++branch) {
    check(slot.bind(w[branch], take(c::ConstTensorView::create(wd[branch], weights[branch].view()))));
    check(slot.bind(y[branch], take(c::TensorView::create(yd[branch], outputs[branch].view()))));
  }
  check(g::cuda::prepare_replay(slot, queue, {.mode=g::ReplayMode::kCommands, .host_wait=g::HostWaitPolicy::kReject}));
  if (slot.replay_route() != g::ReplayRoute::kCommands) throw std::runtime_error("expected Commands replay");
  const auto run = [&] { auto done = take(slot.submit(queue)); check(done.wait()); };
  for (int i = 0; i < warmup; ++i) run();
  std::vector<double> samples; samples.reserve(static_cast<std::size_t>(iterations));
  if (trace) profiler(cudaProfilerStart());
  for (int i = 0; i < iterations; ++i) {
    const auto start = std::chrono::steady_clock::now();
    run();
    samples.push_back(std::chrono::duration<double, std::micro>(std::chrono::steady_clock::now()-start).count());
  }
  if (trace) profiler(cudaProfilerStop());
  // D2H, finite checking and output serialization are outside the hot interval.
  for (std::size_t branch = 0; branch < 2; ++branch) {
    Bytes bytes(take(yd[branch].required_bytes()));
    check(outputs[branch].view().read(bytes));
    for (std::size_t i = 0; i < bytes.size(); i += 2) {
      std::uint16_t bits; std::memcpy(&bits, bytes.data()+i, 2);
      if ((bits & 0x7f80) == 0x7f80) throw std::runtime_error("nonfinite BF16 output");
    }
    std::ofstream file(output_prefix + ".y" + std::to_string(branch) + ".bin", std::ios::binary);
    file.write(reinterpret_cast<const char *>(bytes.data()), static_cast<std::streamsize>(bytes.size()));
    if (!file) throw std::runtime_error("output serialization failed");
  }
  std::cout << std::setprecision(12) << "{\"passed\":true,\"M\":32,\"K\":1024,\"N\":[512,768],"
      << "\"dtype\":\"BF16\",\"accum\":\"F32\",\"floor\":1e-10,\"rounding\":\"none\","
      << "\"shared\":" << (expected_shared ? "true" : "false") << ",\"commands\":true,\"trace\":" << (trace ? "true" : "false")
      << ",\"warmup\":" << warmup << ",\"iterations\":" << iterations << ",\"declared_dispatches\":" << dispatches
      << ",\"graph_workspace_bytes\":" << compiled.report.workspace_bytes() << ",\"sum_step_workspace_bytes\":" << step_workspace
      << ",\"submit_wait_us_median\":" << median(samples) << ",\"samples_us\":[";
  for (std::size_t i = 0; i < samples.size(); ++i) std::cout << (i ? "," : "") << samples[i];
  std::cout << "]}\n";
  return 0;
} catch (const std::exception &error) {
  std::cerr << "FP8_SHARED_BENCH_FAILURE " << error.what() << '\n'; return 1;
}
