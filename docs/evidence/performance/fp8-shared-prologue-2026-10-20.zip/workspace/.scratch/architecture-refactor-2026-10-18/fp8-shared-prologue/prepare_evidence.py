"""Record final source snapshots and the actual focused run, without rebuilding."""
import difflib
import importlib.util
from pathlib import Path
import shutil
import sys
sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("fp8_evidence_build", S / "build.py")
h = importlib.util.module_from_spec(spec)
spec.loader.exec_module(h)
b, c, ROOT = h.b, h.c, h.ROOT

names = ["src/graph_route_cuda/" + name for name in (
    "fp8_shared_prologue_region.cc", "fp8_shared_prologue_region.h",
    "mapped_native_region.h", "cuda_context.cc", "CMakeLists.txt")]
rows, diffs = [], []
for name in names:
    source = ROOT / name
    before = S / "graph-before" / name
    snapshot = S / "graph-source" / name
    snapshot.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(source, snapshot)
    rows.append(dict(source=name, before=b.identity(before) if before.is_file() else None,
                     after=b.identity(source), snapshot=b.identity(snapshot)))
    diffs.extend(difflib.unified_diff(
        before.read_text().splitlines(keepends=True) if before.is_file() else [],
        source.read_text().splitlines(keepends=True), fromfile="before/" + name,
        tofile="after/" + name))
(S / "graph-changes.diff").write_text("".join(diffs), encoding="utf-8")
c.save(S / "graph-source-freeze.json", dict(files=rows,
    verification="Final source snapshots; actual build/test evidence is separately linked below"))

run = c.read(S / "runs/actual-report-macro-fixed/summary.json")
assert run["passed"] and run["cases"] == 16 and not run["skipped"]
assert b.same(run["image"])
for name in ("tests-manifest.json", "tests-source-freeze.json"):
    path = S / name
    historical = S / "before-final-runtime" / name
    if not historical.is_file():
        historical.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(path, historical)
    record = c.read(path)
    record["status"] = "Final source compiled by root; focused CUDA run passed16/16, zero skips"
    record["root_actual_run"] = b.identity(S / "runs/actual-report-macro-fixed/summary.json")
    if name == "tests-manifest.json":
        for case in record["negative_cases"]:
            case["executed"] = True
        record["verification"].update(build=True, gpu=True, cases=16, skipped=0)
    else:
        record["root_correction"] = "Rename free bind helper to bind_case to avoid std::bind ADL; only three identifier sites changed. Final product source compiled and all16 tests passed after leaf report and validation macro fixes."
    c.save(path, record)

plan = c.read(S / "checks/host1/plan.json")
for row in plan["frozen"]:
    assert b.same(row), row["path"]
for row in c.read(S / "checks/host1/tests-link-plan.json")["inputs"]:
    assert b.same(row), row["path"]
c.save(S / "actual-verification.json", dict(
    compile=c.read(S / "checks/host1/compile-summary.json"), run=run,
    native_builds=0, SDK_builds=0,
    description="17 C++ owners in the final closure; second build reused15 and compiled only the Graph report owner plus context test feature macro correction.",
    source_changes="FP8 provider-local two-output sharing, mapped adapter extension, dead CUDA qualification wrapper deletion, selected leaf dispatch report propagation.",
    failures_retained=["checks/host1/attempt1-test-API-failed",
        "checks/host1/attempt2-bind-ADL-failed", "checks/host1/attempt3-link-missing-weight-module",
        "runs/actual-after-link"],
    limits=["No tensor payload or complete FP8 model execution.",
        "Two slots execute sequential completed journeys, not simultaneous in-flight stress.",
        "No new Qwen whole-model throughput, quality or device/process peak from this focused test run."]
))
print("FP8_FINAL_SOURCE_AND_RUN_RECORDED", flush=True)
