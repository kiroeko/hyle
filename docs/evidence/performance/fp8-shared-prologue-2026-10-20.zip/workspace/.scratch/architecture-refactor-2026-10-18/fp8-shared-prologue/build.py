"""Refresh only changed C++ owners on the accepted v30 CUDA closure."""
import argparse
import concurrent.futures
import difflib
import importlib.util
from pathlib import Path
import shutil
import sys
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent;ROOT=S.parents[2]
spec=importlib.util.spec_from_file_location("fp8_shared_helpers",S.parent / "grouped-shared-activation/build_host.py")
h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
b,c=h.b,h.c
BASE=S.parent / "bf16-grouped-bank/checks/native1/tests-link-plan.json"

def main():
    p=argparse.ArgumentParser();p.add_argument("--build",action="store_true");p.add_argument("--resume",action="store_true")
    args=p.parse_args()
    out=S / "checks/host1";out.mkdir(parents=True,exist_ok=True);(out / "tmp").mkdir(exist_ok=True)
    route=c.read(S.parent / "cuda-version-route/source-freeze.json")
    native=c.read(S / "native-source-freeze.json")
    graph_names=["src/graph_route_cuda/"+name for name in ("mapped_native_region.h","cuda_context.cc","CMakeLists.txt",
        "fp8_shared_prologue_region.cc","fp8_shared_prologue_region.h")]
    changed=set(graph_names)|{row["path"] for row in route["files"]}|{row["source"] for row in native["files"]}
    changed |= {"src/graph/executable.cc", "tests/graph_route_cuda/fp8_shared_prologue_test.cc","tests/graph_route_cuda/CMakeLists.txt"}
    removed={c.key(ROOT / row["path"]) for row in route["files"] if row["action"]=="deleted"}
    headers={c.key(ROOT / name) for name in changed if Path(name).suffix==".h"}
    sources={c.key(ROOT / name) for name in changed if Path(name).suffix==".cc" and (ROOT / name).is_file()}
    base=c.read(BASE)
    ct_base=c.read(S.parent / "ct-packed-linear/checks/mapped-prepared/link-plan.json")
    metadata=h.metadata(dict(current=base,ct=ct_base))
    owners=[];retired=[];unknown=[]
    native_evidence=[]
    def dependencies(row):
        command=row["command"]
        for n,arg in enumerate(command):
            if arg.lower()=="/sourcedependencies" and Path(command[n+1]).is_file():
                dep=c.read(command[n+1]).get("Data",{})
                return [{"path":path} for path in dep.get("Includes",[])]
        if "-MF" in command and Path(command[command.index("-MF")+1]).is_file():
            depfile=Path(command[command.index("-MF")+1])
            result=[]
            for line in depfile.read_text().splitlines()[1:]:
                path=line.strip().removesuffix("\\").strip().replace("\\ "," ")
                if path:result.append({"path":path})
            native_evidence.append(dict(source=row["source_path"],actual_dependency_file=str(depfile),
                actual_changed_headers=[item for item in result if c.key(item["path"]) in headers],
                aggregate_receipt_hits=[item for item in row["dependencies"] if c.key(item["path"]) in headers]))
            return result
        return row["dependencies"]
    for item in base["inputs"]:
        if Path(item["path"]).suffix.lower()!=".obj":continue
        row=metadata.get(c.key(item["path"]))
        if not row:unknown.append(item);continue
        if c.key(row["source_path"]) in removed:
            retired.append(dict(object=item,source=row["source_path"]));continue
        hit=c.key(row["source_path"]) in sources or any(c.key(dep["path"]) in headers for dep in dependencies(row))
        if hit:owners.append(dict(row,old_object=item))
    native_hits=[dict(source=row["source_path"],recipe=row["recipe"],hits=[dep for dep in row["dependencies"] if c.key(dep["path"]) in headers]) for row in owners if Path(row["source_path"]).suffix==".cu"]
    c.save(S / "native-header-hits.json",dict(actual_native_evidence=native_evidence,actual_affected=native_hits))
    assert not native_hits,"Inspect affected native recipe instead of treating it as C++"
    graph_recipe=next(row for row in owners if row["source_path"].replace("\\","/").endswith("src/graph_route_cuda/cuda_context.cc"))
    test_recipe=c.read(S.parent / "bf16-grouped-bank/checks/native1/grouped-test-identity.json")
    existing={c.key(row["source_path"]) for row in owners}
    for name,recipe in (("src/graph_route_cuda/fp8_shared_prologue_region.cc",graph_recipe),
        ("src/compute_route_cuda/weights.cc",next(row for row in owners if row["source_path"].replace("\\","/").endswith("src/compute_route_cuda/cuda_context.cc"))),
        ("tests/graph_route_cuda/fp8_shared_prologue_test.cc",test_recipe),
        ("tests/compute_route_cuda/context_test.cc",test_recipe)):
        if c.key(ROOT / name) not in existing:
            owners.append(dict(source_path=str(ROOT / name),command=recipe["command"],old_object=None))
    dense_receipts=[row for row in c.read(S.parent / "ct-packed-linear/checks/mapped-prepared/cached-tests.json")
        if "ga_dense_indexer_test.cc" in row["source"]["path"]]
    assert len(dense_receipts)==1
    cached=dense_receipts[0]
    assert b.same(cached["source"]) and b.same(cached["object"])
    cached_depfile=next(Path(cached["command"][n+1]) for n,arg in enumerate(cached["command"]) if arg.lower()=="/sourcedependencies")
    cached_actual=c.read(cached_depfile)["Data"]["Includes"]
    recorded={c.key(item["path"]):item for item in cached["dependencies"]}
    for path in cached_actual:
        member=Path(path)
        if member.is_relative_to(ROOT / "src") or member.is_relative_to(ROOT / "include"):
            assert c.key(path) not in headers and c.key(path) in recorded,path
            assert b.same(recorded[c.key(path)]),path
    rows=[]
    for owner in owners:
        source=Path(owner["source_path"])
        tag=source.parent.name+"--"+source.stem
        command=b.host_command(owner["command"],source,tag,out)
        if source==ROOT / "tests/compute_route_cuda/context_test.cc":
            assembled=next(item for item in owners if item["source_path"].replace("\\","/").endswith("src/compute_route_cuda/cuda_context.cc"))
            for arg in assembled["command"]:
                if arg.startswith("/DHYLE_COMPUTE_FLASHINFER") and arg not in command: command.insert(1,arg)
        rows.append(dict(tag=tag,source=b.identity(source),command=command,
            object=str(out / (tag+".obj")),old_object=owner.get("old_object")))
    frozen=[b.identity(ROOT / name) for name in sorted(changed) if (ROOT / name).is_file()]
    frozen += [row["source"] for row in rows]
    for item in frozen:
        target=out / "compiled-source" / Path(item["path"]).relative_to(ROOT)
        target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(item["path"],target)
    c.save(S / "build-inventory.json",dict(base=str(BASE),owners=rows,removed=retired,unknown_unchanged=unknown,
        cached_dense_test=cached["object"],no_SDK_build=True,no_CUDA_compile=True))
    c.save(out / "plan.json",dict(compile=rows,frozen=frozen,removed=[str(ROOT / row["path"]) for row in route["files"] if row["action"]=="deleted"],
        base=str(BASE),no_SDK_build=True,no_CUDA_compile=True))
    print("FP8_SHARED_PLAN",len(rows),"C++ owners",len(retired),"retired",len(unknown),"unchanged unresolved native owners",flush=True)
    if not args.build:return
    def check():
        for item in frozen:assert b.same(item),item["path"]
        assert all(not Path(path).exists() for path in removed)
    check()
    for item in base["inputs"]:assert b.same(item),item["path"]
    env,runtime=b.environment(base["command"],[r["path"] for r in base["inputs"]],out)
    c.save(out / "runtime-environment.json",dict(runtime=runtime,PATH=env["PATH"]))
    def compile_one(row):
        path=out / (row["tag"]+"-identity.json")
        if args.resume and path.is_file():
            previous=c.read(path)
            if previous["command"]==row["command"] and b.same(previous["source"]) and b.same(previous["object"]) and all(b.same(item) for item in previous["dependencies"]):
                print("REUSE",row["tag"],flush=True);return row["tag"],previous
        c.execute(row["tag"]+"-compile",row["command"],env,out);check()
        dep=c.read(out / (row["tag"]+"-deps.json"))["Data"]
        receipt=dict(command=row["command"],source=row["source"],object=b.identity(row["object"]),
            dependencies=[b.identity(p) for p in dict.fromkeys([dep["Source"],*dep["Includes"]])])
        c.save(path,receipt);return row["tag"],receipt
    finished,errors={},[]
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
        for future in concurrent.futures.as_completed([pool.submit(compile_one,row) for row in rows]):
            try:tag,row=future.result();finished[tag]=row
            except BaseException as error:errors.append(repr(error))
    c.save(out / "compile-summary.json",dict(passed=not errors,owners=len(rows),errors=errors,no_SDK_build=True,no_CUDA_compile=True))
    if errors:raise SystemExit(repr(errors))
    replacements={c.key(row["old_object"]["path"]):finished[row["tag"]]["object"] for row in rows if row["old_object"]}
    retired_paths={c.key(row["object"]["path"]) for row in retired}
    lookup={c.key(row["path"]):row for row in base["inputs"]}
    lookup.update({c.key(row["object"]["path"]):row["object"] for row in finished.values()})
    lookup[c.key(cached["object"]["path"])]=cached["object"]
    command=[]
    for arg in base["command"]:
        if arg.upper().startswith(("/OUT:","/MAP:","/IMPLIB:","/PDB:")) or c.key(arg) in retired_paths:continue
        command.append(replacements[c.key(arg)]["path"] if c.key(arg) in replacements else arg)
    command[1:1]=[finished[row["tag"]]["object"]["path"] for row in rows if row["old_object"] is None]
    if c.key(cached["object"]["path"]) not in set(map(c.key,command)):command.insert(1,cached["object"]["path"])
    image=out / "tests.exe";command += ["/OUT:"+str(image),"/MAP:"+str(image.with_suffix(".map")),"/IMPLIB:"+str(image.with_suffix(".lib"))]
    inputs=[arg for arg in command if Path(arg).is_absolute() and Path(arg).suffix.lower() in (".obj",".lib")]
    assert len(inputs)==len(set(map(c.key,inputs)))
    for path in inputs:assert b.same(lookup[c.key(path)]),path
    c.execute("tests-link",command,env,out);check()
    c.save(out / "tests-link-plan.json",dict(command=command,inputs=[lookup[c.key(path)] for path in inputs]))
    c.save(out / "tests-image.json",b.identity(image))
    print("FP8_SHARED_BUILT",out,flush=True)

if __name__=="__main__":main()
