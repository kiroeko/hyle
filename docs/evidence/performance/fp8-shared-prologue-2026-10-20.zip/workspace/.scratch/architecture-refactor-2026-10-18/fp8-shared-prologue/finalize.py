"""Publish bounded, actual FP8/C2/report evidence. No build, GPU or deletion."""
import datetime as dt
import hashlib
import importlib.util
import json
from pathlib import Path
import shutil
import sys
import types
import xml.etree.ElementTree as ET
import zipfile
sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
ROOT = S.parents[2]
C2 = S.parent / 'cuda-version-route'
spec = importlib.util.spec_from_file_location('fp8_publication_helpers', S / 'build.py')
h = importlib.util.module_from_spec(spec); spec.loader.exec_module(h)
b, c = h.b, h.c
PUBLIC = ROOT / 'docs/evidence/performance/fp8-shared-prologue-2026-10-20.json'
ZIP = PUBLIC.with_suffix('.zip')
BUILD = S / 'checks/host1'


def digest(data): return hashlib.sha256(data).hexdigest()
def save(path, value): c.save(path, value)
def owned(path): return any(path.is_relative_to(ROOT / d) for d in ('src', 'include', 'tests', 'third_party', 'cmake'))


def main():
    assert not ZIP.exists(), 'Do not overwrite already published evidence'
    plan, link = c.read(BUILD / 'plan.json'), c.read(BUILD / 'tests-link-plan.json')
    for row in plan['frozen']: assert b.same(row), row['path']
    actual = c.read(S / 'actual-verification.json')
    tests = c.read(S / 'runs/actual-report-macro-fixed/summary.json')
    assert actual['compile']['passed'] and actual['compile']['owners'] == 17
    assert tests['passed'] and tests['cases'] == 16 and tests['skipped'] == 0 and b.same(tests['image'])
    cases = ET.parse(S / 'runs/actual-report-macro-fixed/results.xml').findall('.//testcase')
    assert len(cases) == 16 and all(case.find(x) is None for case in cases for x in ('failure', 'error', 'skipped'))
    bp = c.read(S / 'benchmark/build/plan.json')
    assert bp['passed']
    for arm in ('control', 'new'): assert b.same(bp['links'][arm]['image'])
    strip = lambda xs: [x for x in xs if not x.upper().startswith(('/OUT:', '/MAP:', '/IMPLIB:', '/PDB:'))]
    left, right = strip(bp['links']['control']['command']), strip(bp['links']['new']['command'])
    delta = [dict(index=i, control=a, new=d) for i, (a, d) in enumerate(zip(left, right)) if a != d]
    assert len(left) == len(right) and len(delta) == 1
    rotation = c.read(S / 'benchmark/rotation1/summary.json')
    trace = c.read(S / 'benchmark/profile1/summary.json')
    assert rotation['passed'] and rotation['raw_outputs_byte_equal'] and len(rotation['processes']) == 6
    assert trace['passed'] and [(x['quantizers'], x['gemms']) for x in trace['arms']] == [(2, 2), (1, 2)]
    reference = rotation['processes'][0]['result']['outputs']
    for row in rotation['processes']:
        r = row['result']
        assert r['warmup'] == 64 and r['iterations'] == 256 and r['graph_workspace_bytes'] == 33792
        assert r['sum_step_workspace_bytes'] == (67584 if row['arm'] == 'control' else 33792)
        for a, d in zip(reference, r['outputs']): assert Path(a['path']).read_bytes() == Path(d['path']).read_bytes()
    for row in trace['arms']:
        assert row['passed'] and row['result']['outputs_byte_equal_to_timing']
        assert not row['result']['target_json_forwarded'] and row['result']['nsys_process_exit'] == 0
        for a, d in zip(reference, row['result']['outputs']): assert Path(a['path']).read_bytes() == Path(d['path']).read_bytes()

    products, deleted = {}, []
    for seal in (C2 / 'source-freeze.json', S / 'native-source-freeze.json', S / 'graph-source-freeze.json', S / 'tests-source-freeze.json'):
        for row in c.read(seal)['files']:
            name = row.get('source', row.get('path'))
            path = Path(name)
            if not path.is_absolute(): path = ROOT / path
            if row.get('action') == 'deleted':
                assert not path.exists(); deleted.append(dict(path=str(path), before_sha256=row['before_sha256'])); continue
            expected = row.get('after') or dict(sha256=row['sha256'], bytes=row['bytes'])
            products[str(path)] = dict(path=str(path), sha256=expected['sha256'], bytes=expected['bytes'])
    leaf = c.read(S / 'leaf-report-source-freeze.json')
    products[str(ROOT / leaf['source'])] = dict(path=str(ROOT / leaf['source']), sha256=leaf['sha256'], bytes=leaf['bytes'])
    for row in products.values(): assert b.same(row), row['path']

    # Preserve actual current project dependencies, not SDK/cache trees. The
    # old C2-only cuda_provider snapshot remains historical, then FP8 supersedes it.
    dependencies = {}
    receipts = [BUILD / (r['tag'] + '-identity.json') for r in plan['compile']]
    receipts += list((S / 'benchmark/build').glob('*-identity.json'))
    assert len(receipts) == 19
    for path in receipts:
        receipt = c.read(path)
        assert b.same(receipt['object']) and b.same(receipt['source']), path
        for row in receipt['dependencies']:
            member = Path(row['path'])
            if owned(member):
                if row['path'] in dependencies: assert dependencies[row['path']]['sha256'] == row['sha256']
                assert b.same(row), row['path']
                dependencies[row['path']] = row
    for row in dependencies.values():
        path = Path(row['path']); snapshot = S / 'dependency-source' / path.relative_to(ROOT)
        snapshot.parent.mkdir(parents=True, exist_ok=True); shutil.copyfile(path, snapshot)
    save(S / 'dependency-source-freeze.json', dict(files=list(dependencies.values()), actual_receipts=[b.identity(p) for p in receipts],
        SDK='External SDK/library definitions retained by actual command/dependency identity; not copied or rebuilt.'))

    medians = {arm: [x['result']['submit_wait_us_median'] for x in rotation['processes'] if x['arm'] == arm] for arm in ('control', 'new')}
    raw = {arm: [v for x in rotation['processes'] if x['arm'] == arm for v in x['result']['samples_us']] for arm in ('control', 'new')}
    paired = []
    for pair in range(3):
        arms = {x['arm']: x['result']['submit_wait_us_median'] for x in rotation['processes'] if x['pair'] == pair}
        paired.append(dict(pair=pair, **arms, change_percent=(arms['new']/arms['control']-1)*100))
    assert all(x['new'] < x['control'] for x in paired)
    report = dict(date_utc=dt.datetime.now(dt.timezone.utc).isoformat(),
        scope='Ordinary CUDA Graph sharing one dynamic group128 FP8 activation producer between two independent Float8BlockLinear siblings; fixed microbenchmark, not Qwen BF16/model validation.',
        implementation=dict(private_op='Float8BlockLinearPair [A,W0,W1]->[Y0,Y1], native SGLang route22',
            Graph='Original SGLang provider decorated once; same logical A, floor bits and rounding; canonical native admission and original output boundaries, N may differ.',
            native='One unchanged quantizer and two unchanged original AOT GEMMs in the original QueueSequence. No concatenated W, payload cache, hot allocation, new executor or public API.',
            numerical='Standalone F32/BF16 output and BF16 power2 colmajor scales remain distinct original contracts; all actual ports validated before first launch and launch-stage errors retain accepted-prefix semantics.',
            ancillary=['Delete unreachable historical C2 qualified-provider wrapper; preserve ordinary native admission/math/resources and roster.',
                       'Forward known selected leaf dispatch counts into compile reports; unknown/default, selection and execution remain unchanged.']),
        source_fingerprints=list(products.values()), removed_C2_files=deleted,
        actual_build=dict(unique_main_closure_Cpp_owners=17, additional_benchmark_Cpp_owners=2, native_compiles=0, SDK_builds=0,
            main_plan=b.identity(BUILD / 'plan.json'), tests_image=tests['image'], benchmark_plan=b.identity(S / 'benchmark/build/plan.json'),
            common_benchmark_object=bp['common_object'], only_arm_link_delta_excluding_output_paths=delta,
            history=actual['description']),
        correctness=dict(actual_cases=16, skipped=0, names=tests['names'],
            summary=b.identity(S / 'runs/actual-report-macro-fixed/summary.json'),
            math='4 FP8 tests compare both outputs bytewise with original standalone Direct linears for F32, BF16 and BF16power2; exact contract/ValueId mismatch and existing packed-single controls remain standalone. 4 CT,4 Dense and4 default-context neighbours pass.',
            lifetime='Two independently owned slots/Queues and changed A through real permissions, captured replay, old GraphOutput gate and exported output ownership. Sequential completed journeys; no simultaneous in-flight stress claim.'),
        microbenchmark=dict(shape=dict(M=32,K=1024,N=[512,768],activation_output='BF16',accumulation='F32',floor=1e-10,rounding='none'),
            metric='Same public Graph, one common benchmark object; Commands Invocation.submit through Completion.wait; upload/compile/prepare/D2H/file writes excluded.',
            runs='3 pairs AB/BA/AB,64 warmups and256 raw samples per process', process_medians_us=medians, pairs=paired,
            median_of_process_medians_us=rotation['median_submit_wait_us'], change_percent=(rotation['latency_ratio_new_over_control']-1)*100,
            process_median_ranges_overlap=not(max(medians['new']) < min(medians['control']) or max(medians['control']) < min(medians['new'])),
            raw_iteration_ranges_overlap=not(max(raw['new']) < min(raw['control']) or max(raw['control']) < min(raw['new'])),
            interpretation='All3 paired process medians are lower in this fixed window (~1.00% median reduction); no inference of long-term significance, other-shape or full-model benefit.',
            outputs_byte_equal=True, output_identities=reference, raw_results=b.identity(S / 'benchmark/rotation1/summary.json')),
        workspace=dict(graph_caller_bytes_control=33792,graph_caller_bytes_new=33792,
            sum_step_declarations_control=67584,sum_step_declarations_new=33792,
            interpretation='One encoded activation workspace per pair; ordinary Graph allocation already reuses sequential leaf scratch. Not whole-Graph peak halving, total device peak or zero unknown native storage.'),
        physical_trace=dict(control_kernel_count=4,new_kernel_count=3,control_quantizers=2,new_quantizers=1,original_GEMMs_each=2,
            scope='One warmup submit outside cudaProfilerApi range, then exactly one submit/wait per arm inside. Counts only; profiler duration is not the warm latency result.',
            both_outputs_equal_to_timing=True, target_JSON_forwarded=False,
            status='Nsight collection/export/stats exit0; target JSON was not forwarded. No independent target exit or profile timing is invented.', summary=b.identity(S / 'benchmark/profile1/summary.json')),
        retained_failures=['Original optional-vs-null source review/compile defect and corrected source identity before-optional-fix.',
            'First fixture compile API errors; second std::bind ADL error; missing existing weights-module link owner.',
            'Initial16 run14pass/2fail: leaf dispatch report default1 instead of native2, and context fixture compiled without actual factory FlashInfer macro. Raw assertions were preserved, not relaxed.',
            'Profile parser StopIteration after successful control collection because child JSON was not forwarded; valid control trace reused, outputs verified and new collected once.'],
        not_claimed=['No full FP8 artifact/model or quality validation and no new Qwen BF16 throughput result.',
            'No broader matrix, other device/platform, stable long-run performance or total CPU/GPU peak-memory assertion.',
            'No inference that the old C2 measured23 shapes are new current winners or a runtime capability whitelist.'],
        evidence=dict(archive=ZIP.name, hardware_snapshot=b.identity(S / 'hardware-before.csv'),
            source_dependency_snapshot=b.identity(S / 'dependency-source-freeze.json'),
            reproduce=['python .scratch/architecture-refactor-2026-10-18/fp8-shared-prologue/build.py --build --resume',
                'python .scratch/architecture-refactor-2026-10-18/fp8-shared-prologue/run_cases.py NEW_RUN_NAME',
                'python .scratch/architecture-refactor-2026-10-18/fp8-shared-prologue/bench.py --build',
                'python .scratch/architecture-refactor-2026-10-18/fp8-shared-prologue/bench.py --run --name NEW_ROTATION_NAME',
                'python .scratch/architecture-refactor-2026-10-18/fp8-shared-prologue/bench.py --profile --name profile1 --resume']),
        goal='Active; this batch does not complete the architecture/model/operator/quantization work.')
    save(S / 'summary.json', report)

    files = {}
    ignored = {'.exe','.obj','.lib','.exp','.map','.pdb','.dll','.pyc','.tmp'}
    def add(path):
        if path.is_file() and path.suffix.lower() not in ignored and not {'tmp','__pycache__'}.intersection(path.relative_to(ROOT).parts):
            assert path.stat().st_size < 8_000_000, 'No large cache/library payload: ' + str(path)
            files['workspace/' + path.relative_to(ROOT).as_posix()] = path
    for stage in (S,C2):
        for path in stage.rglob('*'):
            if path.name not in ('archive-manifest.json','publication.json','cleanup-plan.json'): add(path)
    # The frozen copies above carry exact owner headers/sources. Retain small
    # source/provenance of the unchanged embedded FP8 mathematics as well.
    for row in dependencies.values(): add(Path(row['path']))
    for row in products.values(): add(Path(row['path']))
    vendor = ROOT / 'third_party/sglang_activation'
    for glob in ('*.json','*.py','original_cuda_quant.cu'):
        for path in (vendor / 'fp8').glob(glob): add(path)
    for name in ('NOTICE','LICENSE','TRITON-LICENSE'): add(vendor / name)
    seen = set()
    def helper(module):
        if id(module) in seen: return
        seen.add(id(module)); path = getattr(module,'__file__',None)
        if not path or not Path(path).is_relative_to(ROOT): return
        add(Path(path))
        for value in vars(module).values():
            if isinstance(value,types.ModuleType): helper(value)
    helper(h)
    # Preserve actual small prerequisite plans/receipts, never their SDK/objects.
    for path in (h.BASE, S.parent / 'ct-packed-linear/checks/mapped-prepared/cached-tests.json',
                 S.parent / 'ct-packed-linear/checks/mapped-prepared/link-plan.json',
                 ROOT / 'docs/evidence/performance/bf16-grouped-bank-2026-10-20.json'):
        add(Path(path))
    payloads = [dict(name=name,bytes=path.stat().st_size,sha256=digest(path.read_bytes())) for name,path in sorted(files.items())]
    manifest = (json.dumps(dict(payloads=payloads,excluded='SDK, rebuildable binaries/objects/maps, temp and large scan caches'),indent=2)+'\n').encode()
    ZIP.parent.mkdir(parents=True,exist_ok=True)
    with zipfile.ZipFile(ZIP,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for name,path in sorted(files.items()): z.write(path,name)
        z.writestr('manifest.json',manifest)
    # ZipFile.read checks each entry CRC; pair that same read with SHA256 once.
    with zipfile.ZipFile(ZIP) as z:
        assert z.read('manifest.json') == manifest
        for row in payloads:
            data = z.read(row['name']); assert len(data)==row['bytes'] and digest(data)==row['sha256']
    receipt = dict(**b.identity(ZIP), payload_count=len(payloads), entry_count=len(payloads)+1,
        crc_verified=True,payload_sha256_verified=True,one_read_CRC_and_SHA_per_payload=True)
    save(S / 'archive-manifest.json', dict(payloads=payloads,receipt=receipt))
    report['evidence']['archive'] = receipt
    save(PUBLIC,report)
    save(S / 'publication.json',dict(report=b.identity(PUBLIC),archive=receipt))
    print('FP8_SHARED_PUBLISHED', json.dumps(dict(report=b.identity(PUBLIC),archive=receipt)), flush=True)


if __name__ == '__main__': main()
