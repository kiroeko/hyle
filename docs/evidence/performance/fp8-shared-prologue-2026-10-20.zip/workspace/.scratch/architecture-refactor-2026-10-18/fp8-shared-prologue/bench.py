"""Prepare/build two C++ benchmark images, then optional serial timing/trace.

No action compiles or runs a model unless --build/--run/--profile is supplied.
Reuses host1 exactly; control replaces only Graph's SGLang decorator argument.
"""
import argparse
import importlib.util
from pathlib import Path
import sqlite3
import statistics
import sys
sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
ROOT = S.parents[2]
spec = importlib.util.spec_from_file_location('fp8_benchmark_helpers', S / 'build.py')
h = importlib.util.module_from_spec(spec); spec.loader.exec_module(h)
b, c = h.b, h.c
B = S / 'benchmark/build'
BASE = S / 'checks/host1/tests-link-plan.json'
NSYS = Path('C:/Program Files/NVIDIA Corporation/Nsight Systems 2026.1.3/target-windows-x64/nsys.exe')


def prepare(build):
    B.mkdir(parents=True, exist_ok=True); (B / 'tmp').mkdir(exist_ok=True)
    base = c.read(BASE)
    context = c.read(S / 'checks/host1/graph_route_cuda--cuda_context-identity.json')
    recipe = c.read(S / 'checks/host1/graph_route_cuda--fp8_shared_prologue_test-identity.json')
    assert b.same(context['source']) and b.same(context['object'])
    source = ROOT / 'src/graph_route_cuda/cuda_context.cc'
    text = source.read_text()
    old = 'internal::fp8_shared_prologue_provider()'
    assert text.count(old) == 1
    control = B / 'control-cuda-context.cc'
    control.write_text(text.replace(old, 'compute::Provider{}'), encoding='utf-8')
    bench = S / 'shared_prologue_bench.cc'
    rows = []
    for tag, path, command in [('common-bench', bench, recipe['command']),
                               ('control-context', control, context['command'])]:
        command = b.host_command(command, path, tag, B)
        if tag == 'control-context': command.insert(1, '/I' + str(ROOT / 'src/graph_route_cuda'))
        rows.append(dict(tag=tag, source=b.identity(path), command=command, object=str(B / (tag + '.obj'))))
    frozen = [b.identity(bench), b.identity(control), b.identity(source), b.identity(BASE)]
    plan = dict(base=b.identity(BASE), compile=rows, frozen=frozen,
        reused_context=context['object'], native_compiles=0, SDK_build=False,
        only_arm_difference='control Graph context passes an empty SGLang override, so original roster supplies the raw SGLang provider; new uses current decorator',
        inherited_unexecuted_tests='Keep current test objects and gtest.lib; remove only gtest_main.lib and supply one common benchmark main object.',
        limitation='One fixed BF16 ordinary FP8 sample, not Qwen BF16 throughput or device peak-memory evidence.')
    c.save(B / 'plan.json', plan)
    print('FP8_BENCH_PLAN', B / 'plan.json', '2 host compiles, 2 links, 0 CUDA/SDK', flush=True)
    if not build: return
    for item in base['inputs']: assert b.same(item), item['path']
    env, runtime = b.environment(base['command'], [x['path'] for x in base['inputs']], B)
    c.save(B / 'runtime.json', dict(runtime=runtime, PATH=env['PATH']))
    finished = {}
    for row in rows:
        c.execute(row['tag'] + '-compile', row['command'], env, B)
        deps = c.read(B / (row['tag'] + '-deps.json'))['Data']
        receipt = dict(command=row['command'], source=row['source'], object=b.identity(row['object']),
            dependencies=[b.identity(p) for p in dict.fromkeys([deps['Source'], *deps['Includes']])])
        c.save(B / (row['tag'] + '-identity.json'), receipt); finished[row['tag']] = receipt
    lookup = {c.key(x['path']): x for x in base['inputs']}
    lookup.update({c.key(x['object']['path']): x['object'] for x in finished.values()})
    assert c.key(context['object']['path']) in lookup
    plan['links'] = {}
    for arm in ('control', 'new'):
        command = [arg for arg in base['command'] if not arg.upper().startswith(('/OUT:', '/MAP:', '/IMPLIB:', '/PDB:'))
                   and Path(arg).name.lower() != 'gtest_main.lib']
        command.insert(1, finished['common-bench']['object']['path'])
        if arm == 'control':
            command = [finished['control-context']['object']['path'] if c.key(arg) == c.key(context['object']['path']) else arg for arg in command]
        image = B / (arm + '.exe')
        command += ['/OUT:' + str(image), '/MAP:' + str(image.with_suffix('.map')), '/IMPLIB:' + str(image.with_suffix('.lib'))]
        inputs = [x for x in command if Path(x).is_absolute() and Path(x).suffix.lower() in ('.obj', '.lib')]
        assert len(inputs) == len(set(map(c.key, inputs)))
        c.execute(arm + '-link', command, env, B)
        link = dict(command=command, inputs=[lookup[c.key(x)] for x in inputs])
        c.save(B / (arm + '-link-plan.json'), link)
        c.save(B / (arm + '-image.json'), b.identity(image))
        plan['links'][arm] = dict(command=command, image=b.identity(image), inputs=inputs)
    for item in frozen: assert b.same(item), item['path']
    for item in base['inputs']:
        if Path(item['path']).suffix.lower() == '.obj': assert b.same(item), item['path']
    plan['passed'] = True; plan['common_object'] = finished['common-bench']['object']
    c.save(B / 'plan.json', plan)
    c.save(B / 'summary.json', dict(passed=True, host_compiles=2, native_compiles=0, links=plan['links']))


def command(arm, out, args, trace=False):
    link = c.read(B / (arm + '-link-plan.json')); image = c.read(B / (arm + '-image.json'))
    assert b.same(image)
    for item in link['inputs']:
        if Path(item['path']).suffix.lower() == '.obj': assert b.same(item), item['path']
    env, runtime = b.environment(link['command'], [x['path'] for x in link['inputs']], out)
    argv = [image['path'], '--expect-shared', '1' if arm == 'new' else '0',
        '--warmup', '1' if trace else '64', '--iterations', '1' if trace else str(args.iterations),
        '--cpu', str(args.cpu), '--trace', str(int(trace)), '--output-prefix', str(out / 'output')]
    c.save(out / 'runtime.json', dict(image=image, link=b.identity(B / (arm + '-link-plan.json')), runtime=runtime, argv=argv))
    return argv, env


def result(out, tag):
    import json
    docs = [json.loads(line) for line in (out / (tag + '.stdout.log')).read_text().splitlines() if line.startswith('{')]
    if docs:
        doc = docs[0]
        assert doc['passed'] and doc['commands'] and doc['dtype'] == 'BF16'
    else:
        assert tag == 'profile', 'ordinary timing requires actual target JSON'
        doc = dict(target_json_forwarded=False,
            nsys_process_exit=c.read(out / 'profile.result.json')['exit'],
            note='Nsight did not forward target JSON. No target exit code or profile timing is inferred.')
    doc['outputs'] = [b.identity(out / ('output.y' + str(i) + '.bin')) for i in range(2)]
    if tag == 'profile':
        reference_path = S / 'benchmark/rotation1/summary.json'
        reference = c.read(reference_path)['processes'][0]['result']
        doc['timing_reference'] = b.identity(reference_path)
        doc['outputs_byte_equal_to_timing'] = same_outputs(doc, reference)
        assert doc['outputs_byte_equal_to_timing']
    c.save(out / 'result.json', doc)
    return doc


def same_outputs(a, d):
    return all(Path(x['path']).read_bytes() == Path(y['path']).read_bytes() for x, y in zip(a['outputs'], d['outputs']))


def run(args):
    out = S / 'benchmark' / args.name; out.mkdir(parents=True, exist_ok=False)
    rows = []
    for pair in range(args.pairs):
        for arm in (('control', 'new') if pair % 2 == 0 else ('new', 'control')):
            directory = out / (str(pair) + '-' + arm); directory.mkdir(); (directory / 'tmp').mkdir()
            argv, env = command(arm, directory, args)
            c.execute('run', argv, env, directory)
            rows.append(dict(pair=pair, arm=arm, result=result(directory, 'run')))
    for row in rows: assert same_outputs(rows[0]['result'], row['result']), 'paired raw outputs differ'
    medians = {arm: statistics.median(x['result']['submit_wait_us_median'] for x in rows if x['arm'] == arm) for arm in ('control', 'new')}
    c.save(out / 'summary.json', dict(passed=True, raw_outputs_byte_equal=True, processes=rows, median_submit_wait_us=medians,
        latency_ratio_new_over_control=medians['new']/medians['control'],
        limits='Fixed warm sample in Commands mode; profiler-free timing includes Graph admission and Completion.wait. Not a model result or peak 2B-to-B memory proof.'))


def profile(args):
    out = S / 'benchmark' / args.name; out.mkdir(parents=True, exist_ok=args.resume)
    rows = []
    for arm in ('control', 'new'):
        directory = out / arm; directory.mkdir(exist_ok=args.resume); (directory / 'tmp').mkdir(exist_ok=args.resume)
        argv, env = command(arm, directory, args, True); prefix = directory / 'trace'
        completed = all((directory / name).is_file() for name in (
            'trace.nsys-rep', 'trace.sqlite', 'profile.result.json', 'export.result.json', 'stats.result.json',
            'output.y0.bin', 'output.y1.bin'))
        reuse = args.resume and completed and all(c.read(directory / (tag + '.result.json'))['exit'] == 0
                                                  for tag in ('profile', 'export', 'stats'))
        if not reuse:
            assert not prefix.with_suffix('.nsys-rep').exists(), 'retain partial collection; choose another output name'
            c.execute('profile', [str(NSYS), 'profile', '--trace=cuda', '--sample=none', '--cpuctxsw=none',
                '--cuda-graph-trace=node', '--capture-range=cudaProfilerApi', '--capture-range-end=stop',
                '--output=' + str(prefix), *argv], env, directory)
            c.execute('export', [str(NSYS), 'export', '--type=sqlite', '--output=' + str(prefix.with_suffix('.sqlite')),
                str(prefix.with_suffix('.nsys-rep'))], env, directory)
            c.execute('stats', [str(NSYS), 'stats', '--report=cuda_gpu_kern_sum', '--format=csv',
                '--output=' + str(directory / 'stats'), str(prefix.with_suffix('.sqlite'))], env, directory)
        with sqlite3.connect(prefix.with_suffix('.sqlite')) as db:
            strings = dict(db.execute('select id,value from StringIds'))
            kernels = [strings[x[0]] for x in db.execute('select demangledName from CUPTI_ACTIVITY_KIND_KERNEL order by start')]
        quant = sum('per_token_group_quant_8bit' in x for x in kernels)
        gemm = sum('_w8a8_block_fp8_matmul' in x for x in kernels)
        expected = 3 if arm == 'new' else 4
        row = dict(arm=arm, kernels=kernels, quantizers=quant, gemms=gemm, result=result(directory, 'profile'),
            reused_completed_collection=reuse, sqlite=b.identity(prefix.with_suffix('.sqlite')),
            passed=len(kernels)==expected and quant==(1 if arm=='new' else 2) and gemm==2)
        c.save(directory / 'analysis.json', row); rows.append(row)
    c.save(out / 'summary.json', dict(passed=all(x['passed'] for x in rows) and same_outputs(rows[0]['result'], rows[1]['result']),
        arms=rows, limits='One warm submit per arm selected by cudaProfilerApi capture range after one untraced warmup submit; profiler durations are diagnostic, not benchmark throughput.'))
    assert all(x['passed'] for x in rows) and same_outputs(rows[0]['result'], rows[1]['result'])


if __name__ == '__main__':
    p = argparse.ArgumentParser(); p.add_argument('--build', action='store_true'); p.add_argument('--run', action='store_true')
    p.add_argument('--resume', action='store_true')
    p.add_argument('--profile', action='store_true'); p.add_argument('--name', default='rotation1')
    p.add_argument('--pairs', type=int, default=3); p.add_argument('--iterations', type=int, default=256); p.add_argument('--cpu', type=int, default=2)
    args = p.parse_args(); assert Path(args.name).name == args.name and args.pairs > 0 and args.iterations > 0
    if args.build or not (args.run or args.profile): prepare(args.build)
    if args.run: run(args)
    if args.profile: profile(args)
