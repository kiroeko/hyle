from pathlib import Path
import datetime as dt
import hashlib,json,zipfile
S=Path(__file__).resolve().parent;A=S.parent;ROOT=A.parents[1]
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def identity(p):
 p=p.resolve();data=p.read_bytes();return dict(path=str(p),bytes=len(data),sha256=hashlib.sha256(data).hexdigest())
summary=read(S/'timing/summary.json');correct=read(S/'correctness/summary.json');link=read(S/'build/link-plan.json')
review=read(S/'review.json')
assert summary['terminal_zero']==9 and correct['passed'] and correct['equal_vectors']==64
for arm,row in summary['images'].items():assert identity(Path(row['path']))==row
for row in link['inputs']:assert identity(Path(row['path']))==row
report=dict(date='2026-10-20',status='one_rotated_window_complete',
 local_window=dict(start=dt.datetime.fromtimestamp(summary['started_unix']).isoformat(),end=dt.datetime.fromtimestamp(summary['finished_unix']).isoformat(),timezone='Asia/Shanghai'),
 scope='Qwen3.5-2B BF16 pure text, full CUDA, no MTP/multimodal; same128-token prompt and31 forced decode inputs, context256. Three fresh processes per arm, one Latin rotation, no old samples pooled.',
 change='Current uninstrumented GGML CUDA retirement-query reuse provider object on the exact retained Qwen main and other link inputs. New NVFP4 software-reference capability is not invoked by this graph or counted as this speedup.',
 observation=summary,
 conclusion='Current window median full31 is94.1291 vs peer94.9819 tok/s (-0.8979%); warm7..31 is96.7416 vs96.7948 (-0.0550%). Current vs same-window retained Hyle medians +3.4279% full/+2.5537% warm, but one current process slowed to85.8533/86.1725 tok/s. Overlapping ranges and three processes per arm do not establish stable equality or causal warm improvement from a cold-retirement optimization. No sample removed.',
 correctness=dict(equal_vectors=64,finite=True,same_greedy_and_forced_inputs=True,receipt=identity(S/'correctness/summary.json'),scope='One separate trace process outside timing. Exact retained hidden/logit regression, not independent model quality.'),
 build=dict(CXX=0,NVCC=0,SDK=0,links=1,correctness_processes=1,timing_processes=9,all_terminal_zero=True,link_plan=identity(S/'build/link-plan.json'),new_image=identity(S/'build/qwen.exe')),
 review=dict(receipt=identity(S/'review.json'),result=review),
 hardware=dict(receipt=identity(S/'hardware-after.csv'),scope='Actual post-window query, no sampler during timed processes; RTX4070/driver617.14. No locked clocks or exclusive GPU proof.'),
 boundaries=['Hyle projection A/Y BF16 with F32 accumulation, peer A/Y mostly F32. Same BF16 weights and predictions do not establish identical intermediate arithmetic or independent quality.',
 'Peer also downloads248320F32 logits (993280B) per phase; Hyle returns the selected4B token. Consumer wall times retain this difference.',
 'Full31 includes first two parity capture preparations; warm7..31 covers25steps. Startup/load/prepare sub-boundaries differ; do not compare load sub-timers as identical work.',
 'No profiler, external memory/power sampler, OS cache flush or new peak-memory measurement. Three samples/arm, no statistical-significance or stable causal-speedup claim.',
 'Inherited old6process limit label was corrected after the9process run; raw logs, inputs, commands and timing statistics were not changed.'])
(S/'final-validation.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
payload={}
for p in S.rglob('*'):
 if p.is_file() and p.suffix.lower() in {'.json','.py','.log','.xml','.csv'} and p.stat().st_size<3_000_000 and not any(x in p.relative_to(S).parts for x in ('tmp','cleanup')):
  payload['work/'+p.relative_to(S).as_posix()]=p.read_bytes()
for name in ['src/compute_provider_ggml_cuda/ggml_cuda_provider.cc','tools/qwen35_text/main.cc','docs/developer/current-work.md']:
 payload['source/'+name]=(ROOT/name).read_bytes()
manifest=[dict(member=k,bytes=len(v),sha256=hashlib.sha256(v).hexdigest()) for k,v in sorted(payload.items())]
payload['payload-manifest.json']=(json.dumps(manifest,indent=2)+'\n').encode()
dest=ROOT/'docs/evidence/performance';archive=dest/'qwen-decode-rebenchmark-2026-10-20.zip';assert not archive.exists()
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9)as z:
 for name,data in sorted(payload.items()):z.writestr(name,data)
with zipfile.ZipFile(archive)as z:
 assert z.testzip()is None
 for row in manifest:
  data=z.read(row['member']);assert len(data)==row['bytes']and hashlib.sha256(data).hexdigest()==row['sha256']
report['archive']=dict(**identity(archive),payloads=len(manifest),CRC_checked=True,all_payload_SHA256_checked=True)
out=dest/'qwen-decode-rebenchmark-2026-10-20.json';out.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(dict(report=identity(out),archive=identity(archive),payloads=len(manifest)),indent=2))
