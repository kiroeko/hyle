"""Retained baseline / uninstrumented current / unchanged llama, one window."""
from pathlib import Path
import importlib.util
import re
import statistics
import sys
import time
sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
A = S.parent
ROOT = A.parents[1]
def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m)
    return m
h = load('rebenchmark_helpers', A / 'grouped-shared-activation/build_host.py')
q = load('rebenchmark_rotation', A / 'qwen-finite-family/compare.py')
b,c,r = h.b,h.c,q.r
BASE = A / 'decode-stable-bind/ab/current/link-plan.json'
OLD = c.read(BASE)
PEER = c.read(A / 'decode-stable-bind/peer-prepared/plan.json')
OUT = S / 'timing'
WINDOW_LIMITS = ['One new9process Latin rotation,3 fresh processes per image; no old samples pooled.'] + PEER['limits'][1:]

def environment(out, plan):
    out.mkdir(exist_ok=True)
    (out / 'tmp').mkdir(exist_ok=True)
    env,runtime = b.environment(plan['command'], [x['path'] for x in plan['inputs']] + [x['path'] for x in PEER['peer_inputs']],out)
    for key in r.FORBIDDEN_ENV:
        assert key not in env,key
    return env,runtime

def build():
    out = S / 'build'
    out.mkdir(exist_ok=True)
    metadata = h.metadata({'qwen':OLD})
    matches = [x for x in OLD['inputs'] if c.key(x['path']) in metadata and Path(metadata[c.key(x['path'])]['source_path']).name == 'ggml_cuda_provider.cc']
    assert len(matches) == 1
    before = matches[0]
    after = c.read(A / 'decode-retirement-query-reuse/checks/provider-identity.json')['object']
    assert c.read(A / 'decode-retirement-query-reuse/checks/provider-identity.json')['source'] == b.identity(ROOT / 'src/compute_provider_ggml_cuda/ggml_cuda_provider.cc')
    inputs = [after if c.key(x['path']) == c.key(before['path']) else x for x in OLD['inputs']]
    for row in [*OLD['inputs'],*inputs]:
        assert h.same_identity(row),row['path']
    main = c.read(A / 'decode-stable-bind/checks/main-identity.json')
    assert h.same_identity(main['source']) and h.same_identity(main['object'])
    image = out / 'qwen.exe'
    command = [after['path'] if c.key(arg) == c.key(before['path']) else arg for arg in OLD['command']
               if not arg.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:'))]
    command += ['/OUT:'+str(image),'/MAP:'+str(image.with_suffix('.map')),'/IMPLIB:'+str(image.with_suffix('.lib'))]
    plan = dict(command=command, inputs=inputs, source=b.identity(ROOT / 'tools/qwen35_text/main.cc'), main=main['object'], base=b.identity(BASE), replacements=[dict(before=before,after=after)], diagnostic=False)
    c.save(out / 'link-plan.json',plan)
    env,runtime = environment(out,plan)
    c.execute('link',command,env,out)
    c.save(out / 'image.json',b.identity(image))

def correctness():
    out = S / 'correctness'
    plan = c.read(S / 'build/link-plan.json')
    env,runtime = environment(out,plan)
    n = load('rebenchmark_vectors',A / 'cuda-bf16-dual-projection/compare_numerics.py')
    ref = A / 'batch-graph-capture/correctness-final'
    vectors = {p.relative_to(ref/'trace'):n.identity(p) for p in sorted((ref/'trace').rglob('*')) if p.suffix in ('.bf16','.f32')}
    assert len(vectors) == 64
    image = c.read(S / 'build/image.json')
    command = c.read(ref / 'qwen.command.json')['command'].copy()
    command[0] = image['path']
    command[command.index('--trace')+1] = str(out / 'trace')
    c.execute('qwen',command,env,out)
    obs = n.analyze_arm('current',image,out,vectors,n.final_json(ref / 'qwen.stdout.log'))
    assert obs['equal_vectors'] == 64 and obs['all_outputs_finite'] and obs['same_greedy_ids_as_reference'] and obs['same_fixed_decode_inputs']
    captures = [[x['recorded'],x['reused']] for x in obs['capture_counts']]
    assert captures == [[1,0]]*3+[[0,1]]*29,captures
    c.save(out / 'summary.json',dict(passed=True, equal_vectors=64, independent_quality_acceptance=False, image=image, observation=obs))

def timing():
    assert c.read(S / 'correctness/summary.json')['passed']
    assert not (OUT / 'runs.json').exists()
    plan = c.read(S / 'build/link-plan.json')
    env,runtime = environment(OUT,plan)
    images = dict(baseline=b.identity(A / 'decode-stable-bind/ab/current/qwen.exe'),current=c.read(S / 'build/image.json'),llama=PEER['images']['llama'])
    # Hash all inputs outside the timed window, including original weight files.
    for row in [*PEER['frozen'],*PEER['peer_inputs'],*images.values(),*plan['inputs']]:
        r.require_same(row)
    order = ['baseline','current','llama','llama','baseline','current','current','llama','baseline']
    hc = next(x['command'] for x in PEER['requests'] if x['arm']=='current')
    pc = next(x['command'] for x in PEER['requests'] if x['arm']=='llama')
    c.save(OUT/'inputs.json',dict(order=order, images=images, runtime=runtime, link_plan=b.identity(S/'build/link-plan.json'), frozen=PEER['frozen'], metric_contract=PEER['metric_contract'], limits=WINDOW_LIMITS, profiler=False, external_memory_monitor=False, build_or_link_during_timing=False, change='Only uninstrumented GGML CUDA retirement observer object differs from retained Hyle baseline; same main and all other link inputs. New NVFP4 reference capability is not invoked by this BF16 graph.'))
    start = time.time()
    runs = []
    for index,arm in enumerate(order,1):
        tag = f'{index:02}-{arm}'
        command = (pc if arm=='llama' else hc).copy()
        command[0] = images[arm]['path']
        if arm=='llama':
            command[-1] = str(OUT / (tag+'-peer-result.json'))
        request = dict(tag=tag,arm=arm,command=command)
        process = r.execute(tag,command,env,OUT)
        obs = r.peer_result(Path(command[-1]),PEER) if arm=='llama' else r.hyle_result(OUT,request,PEER)
        assert obs['same_baseline_predictions']
        if arm!='llama':
            assert obs['capture_counts'] == [[1,0]]*3+[[0,1]]*29
            text = (OUT / (tag+'.stderr.log')).read_text(encoding='utf-8')
            cold = [float(x) for x in re.findall(r'prepared T=1 visible=\d+ replay=\w+ cold_batch_seconds=([0-9.e+-]+)',text)]
            assert len(cold)==31
            obs['first2_cold_batch_seconds'] = sum(cold[:2])
        runs.append(dict(arm=arm,tag=tag,pid=process['pid'],exit=process['exit'],command=command,**obs))
        c.save(OUT/'runs.json',runs)
    end = time.time()
    groups = {arm:{k:dict(samples=[x['metrics'][k] for x in runs if x['arm']==arm],median=statistics.median(x['metrics'][k] for x in runs if x['arm']==arm),min=min(x['metrics'][k] for x in runs if x['arm']==arm),max=max(x['metrics'][k] for x in runs if x['arm']==arm)) for k in r.COMMON_METRICS} for arm in ['baseline','current','llama']}
    cold = {arm:[x['first2_cold_batch_seconds'] for x in runs if x['arm']==arm] for arm in ['baseline','current']}
    summary = dict(status='nine_fresh_unprofiled_processes_terminal_zero',terminal_zero=9, started_unix=start,finished_unix=end,order=order, images=images,groups=groups,current_over_baseline={k:groups['current'][k]['median']/groups['baseline'][k]['median'] for k in r.COMMON_METRICS},current_over_llama={k:groups['current'][k]['median']/groups['llama'][k]['median'] for k in r.COMMON_METRICS},first2_cold_batch_seconds=cold,same_baseline_predictions_all9=True,profiler=False,external_memory_monitor=False,statistical_significance=False,independent_quality_acceptance=False,metric_contract=PEER['metric_contract'],limits=WINDOW_LIMITS)
    c.save(OUT/'summary.json',summary)
    print('NINE_PROCESS_WINDOW_COMPLETE',flush=True)

if __name__=='__main__':
    {'build':build,'correctness':correctness,'timing':timing}[sys.argv[1]]()
