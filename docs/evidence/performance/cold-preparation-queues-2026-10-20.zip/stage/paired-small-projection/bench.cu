// Scratch-only paired-small-MatMul experiment. No product routing is changed.
// Both arms execute one captured chunk on the same stream, then synchronize.
#ifndef NOMINMAX
#define NOMINMAX
#endif
#include "paired-kernel.cuh"
#include <cublasLt.h>
#if defined(_WIN32)
#include <windows.h>
#elif defined(__linux__)
#include <pthread.h>
#include <sched.h>
#endif

#include <algorithm>
#include <array>
#include <chrono>
#include <cmath>
#include <cstdint>
#include <cstring>
#include <filesystem>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <map>
#include <stdexcept>
#include <string>
#include <vector>

namespace {
constexpr int kPairs = 18, kK = 2048, kN = 16, kBlock = 256;
constexpr std::size_t kWeightBytes = std::size_t(kN) * kK * sizeof(nv_bfloat16);
constexpr std::uint64_t kHashSeed = 14695981039346656037ULL;
void check(cudaError_t status) {
    if (status != cudaSuccess) throw std::runtime_error(cudaGetErrorString(status));
}
void blas(cublasStatus_t status) {
    if (status != CUBLAS_STATUS_SUCCESS)
        throw std::runtime_error("cublasLt status " + std::to_string(int(status)));
}
std::uint64_t hash(std::uint64_t value, const void * bytes, std::size_t size) {
    const auto * source = static_cast<const unsigned char *>(bytes);
    for (std::size_t i = 0; i < size; ++i) { value ^= source[i]; value *= 1099511628211ULL; }
    return value;
}
float decode(std::uint16_t bits) {
    const std::uint32_t raw = std::uint32_t(bits) << 16;
    float result; std::memcpy(&result, &raw, sizeof(result)); return result;
}
double median(std::vector<double> samples) {
    std::sort(samples.begin(), samples.end());
    return (samples[(samples.size()-1)/2] + samples[samples.size()/2]) / 2;
}
std::vector<std::string> split(const std::string &line) {
    std::vector<std::string> result;
    std::size_t begin = 0;
    for (;;) {
        const auto next = line.find('\t', begin);
        result.push_back(line.substr(begin, next == std::string::npos ? next : next-begin));
        if (next == std::string::npos) return result;
        begin = next + 1;
    }
}
struct Weight final { std::string name; std::uint64_t offset = 0, bytes = 0; bool present = false; };
struct Manifest final {
    std::filesystem::path source;
    std::string source_sha;
    std::vector<std::array<Weight, 2>> pairs;
};
Manifest load_manifest(const std::filesystem::path &path) {
    std::ifstream file(path);
    if (!file) throw std::runtime_error("cannot open existing Qwen manifest");
    std::string line;
    std::getline(file, line);
    if (line != "HYLE_QWEN35_TEXT_V1") throw std::runtime_error("unexpected existing manifest version");
    Manifest result;
    std::getline(file, line); result.source = line;
    std::getline(file, result.source_sha);
    if (result.source.is_relative()) result.source = path.parent_path() / result.source;
    std::map<int, std::array<Weight, 2>> layers;
    const std::string prefix = "model.language_model.layers.";
    while (std::getline(file, line)) {
        const auto fields = split(line);
        if (fields.empty() || fields[0].rfind(prefix, 0) != 0) continue;
        const auto dot = fields[0].find('.', prefix.size());
        if (dot == std::string::npos) continue;
        const auto suffix = fields[0].substr(dot);
        const int port = suffix == ".linear_attn.in_proj_a.weight" ? 0
            : suffix == ".linear_attn.in_proj_b.weight" ? 1 : -1;
        if (port < 0) continue;
        if (fields.size() != 7 || fields[1] != "BF16" || fields[2] != "2" ||
                fields[3] != "16" || fields[4] != "2048")
            throw std::runtime_error("a/b actual weight layout is not BF16[16,2048]");
        auto &weight = layers[std::stoi(fields[0].substr(prefix.size(), dot-prefix.size()))][port];
        if (weight.present) throw std::runtime_error("duplicate a/b weight");
        weight = {fields[0], std::stoull(fields[5]), std::stoull(fields[6]), true};
        if (weight.bytes != kWeightBytes) throw std::runtime_error("unexpected a/b weight bytes");
    }
    for (const auto &layer : layers) {
        if (!layer.second[0].present || !layer.second[1].present)
            throw std::runtime_error("incomplete actual a/b pair");
        result.pairs.push_back(layer.second);
    }
    if (result.pairs.size() != kPairs) throw std::runtime_error("expected exactly18 formal a/b layer pairs");
    return result;
}
struct Buffer final {
    void *data = nullptr;
    explicit Buffer(std::size_t bytes) { check(cudaMalloc(&data, bytes)); }
    ~Buffer() { if (data) (void)cudaFree(data); }
    Buffer(const Buffer &) = delete; Buffer &operator=(const Buffer &) = delete;
};
struct Pair final {
    Buffer w0{kWeightBytes}, w1{kWeightBytes}, x{std::size_t(kK)*2};
    Buffer control0{std::size_t(kN)*2}, control1{std::size_t(kN)*2};
    Buffer paired0{std::size_t(kN)*2}, paired1{std::size_t(kN)*2};
};
struct Graph final {
    cudaGraph_t graph = nullptr; cudaGraphExec_t exec = nullptr;
    std::size_t kernel_nodes = 0, memcpy_nodes = 0, total_nodes = 0;
    std::array<unsigned, 6> first_kernel_geometry{};
    ~Graph() { if (exec) (void)cudaGraphExecDestroy(exec); if (graph) (void)cudaGraphDestroy(graph); }
    void finish(cudaStream_t stream) {
        check(cudaStreamEndCapture(stream, &graph));
        check(cudaGraphInstantiateWithFlags(&exec, graph, 0));
        check(cudaGraphGetNodes(graph, nullptr, &total_nodes));
        std::vector<cudaGraphNode_t> nodes(total_nodes);
        check(cudaGraphGetNodes(graph, nodes.data(), &total_nodes));
        for (const auto node : nodes) {
            cudaGraphNodeType type; check(cudaGraphNodeGetType(node, &type));
            if (type == cudaGraphNodeTypeKernel) {
                if (kernel_nodes++ == 0) {
                    cudaKernelNodeParams params{}; check(cudaGraphKernelNodeGetParams(node, &params));
                    first_kernel_geometry = {params.gridDim.x, params.gridDim.y, params.gridDim.z,
                        params.blockDim.x, params.blockDim.y, params.blockDim.z};
                }
            }
            if (type == cudaGraphNodeTypeMemcpy) ++memcpy_nodes;
        }
    }
};
// Exactly the current ordinary Hyle BF16 MatMul leaf configuration:
// A=[1,K] row-major, W logical=[K,N] column-major view of stored W[N,K],
// Y=[1,N] row-major; F32 compute/scale, alpha1 beta0; original preferences.
struct Blas final {
    cublasLtHandle_t handle = nullptr;
    cublasLtMatmulDesc_t operation = nullptr;
    cublasLtMatrixLayout_t a = nullptr, w = nullptr, y = nullptr;
    cublasLtMatmulPreference_t preference = nullptr;
    cublasLtMatmulHeuristicResult_t selected{};
    void *workspace = nullptr;
    Blas() {
        blas(cublasLtCreate(&handle));
        blas(cublasLtMatmulDescCreate(&operation, CUBLAS_COMPUTE_32F, CUDA_R_32F));
        blas(cublasLtMatrixLayoutCreate(&a, CUDA_R_16BF, 1, kK, kK));
        blas(cublasLtMatrixLayoutCreate(&w, CUDA_R_16BF, kK, kN, kK));
        blas(cublasLtMatrixLayoutCreate(&y, CUDA_R_16BF, 1, kN, kN));
        const cublasLtOrder_t row = CUBLASLT_ORDER_ROW, col = CUBLASLT_ORDER_COL;
        blas(cublasLtMatrixLayoutSetAttribute(a, CUBLASLT_MATRIX_LAYOUT_ORDER, &row, sizeof(row)));
        blas(cublasLtMatrixLayoutSetAttribute(w, CUBLASLT_MATRIX_LAYOUT_ORDER, &col, sizeof(col)));
        blas(cublasLtMatrixLayoutSetAttribute(y, CUBLASLT_MATRIX_LAYOUT_ORDER, &row, sizeof(row)));
        blas(cublasLtMatmulPreferenceCreate(&preference));
        const std::size_t maximum = 32U * 1024U * 1024U;
        blas(cublasLtMatmulPreferenceSetAttribute(preference, CUBLASLT_MATMUL_PREF_MAX_WORKSPACE_BYTES,
            &maximum, sizeof(maximum)));
        const std::uint32_t reduction = CUBLASLT_REDUCTION_SCHEME_COMPUTE_TYPE;
        blas(cublasLtMatmulPreferenceSetAttribute(preference, CUBLASLT_MATMUL_PREF_REDUCTION_SCHEME_MASK,
            &reduction, sizeof(reduction)));
        const std::uint32_t alignment = 16;
        for (const auto attribute : {CUBLASLT_MATMUL_PREF_MIN_ALIGNMENT_A_BYTES,
                CUBLASLT_MATMUL_PREF_MIN_ALIGNMENT_B_BYTES, CUBLASLT_MATMUL_PREF_MIN_ALIGNMENT_C_BYTES,
                CUBLASLT_MATMUL_PREF_MIN_ALIGNMENT_D_BYTES})
            blas(cublasLtMatmulPreferenceSetAttribute(preference, attribute, &alignment, sizeof(alignment)));
        int count = 0;
        blas(cublasLtMatmulAlgoGetHeuristic(handle, operation, a, w, y, y, preference, 1, &selected, &count));
        if (count != 1) throw std::runtime_error("original cuBLAS leaf found no algorithm");
        blas(selected.state);
        if (selected.workspaceSize) check(cudaMalloc(&workspace, selected.workspaceSize));
    }
    ~Blas() {
        if (workspace) (void)cudaFree(workspace);
        if (preference) (void)cublasLtMatmulPreferenceDestroy(preference);
        if (a) (void)cublasLtMatrixLayoutDestroy(a);
        if (w) (void)cublasLtMatrixLayoutDestroy(w);
        if (y) (void)cublasLtMatrixLayoutDestroy(y);
        if (operation) (void)cublasLtMatmulDescDestroy(operation);
        if (handle) (void)cublasLtDestroy(handle);
    }
    void run(const Pair &pair, cudaStream_t stream) {
        const float alpha = 1, beta = 0;
        for (const auto bank : {0, 1}) {
            const auto &weight = bank ? pair.w1 : pair.w0;
            const auto &output = bank ? pair.control1 : pair.control0;
            blas(cublasLtMatmul(handle, operation, &alpha, pair.x.data, a, weight.data, w, &beta,
                output.data, y, output.data, y, &selected.algo, workspace, selected.workspaceSize, stream));
        }
    }
};
void paired(const Pair &pair, cudaStream_t stream) {
    ggml_cuda_mm_fusion_args_device fusion{};
    fusion.gate = pair.w1.data;
    paired_small_mul_mat_vec_f<nv_bfloat16, float, 1, kBlock, true, false,
        nv_bfloat16, nv_bfloat16><<<dim3(kN), dim3(kBlock), 2*32*sizeof(float), stream>>>(
            static_cast<const nv_bfloat16 *>(pair.w0.data), static_cast<const nv_bfloat16 *>(pair.x.data),
            nullptr, fusion, static_cast<nv_bfloat16 *>(pair.paired0.data),
            static_cast<nv_bfloat16 *>(pair.paired1.data), kK/2, make_uint3(0,0,0), kK, kK/2, kN,
            init_fastdiv_values(1), kK*kN, kK, kN, init_fastdiv_values(1), kK*kN, kK, kN, 0);
    check(cudaGetLastError());
}
void affinity(int cpu) {
    if (cpu < 0) return;
#if defined(_WIN32)
    if (cpu >= int(sizeof(DWORD_PTR)*8) || !SetThreadAffinityMask(GetCurrentThread(), DWORD_PTR(1) << cpu))
        throw std::runtime_error("could not apply caller CPU affinity in current processor group");
#elif defined(__linux__)
    if (cpu >= CPU_SETSIZE) throw std::runtime_error("caller CPU exceeds affinity set capacity");
    cpu_set_t set; CPU_ZERO(&set); CPU_SET(cpu, &set);
    if (pthread_setaffinity_np(pthread_self(), sizeof(set), &set)) throw std::runtime_error("CPU affinity failed");
#else
    throw std::runtime_error("caller CPU affinity unsupported on this scratch host");
#endif
}
} // namespace

int main(int argc, char **argv) try {
    std::string arm, manifest_path;
    int warmup = 128, iterations = 512, cpu = -1;
    for (int i = 1; i < argc; i += 2) {
        if (i+1 == argc) throw std::runtime_error("every option needs a value");
        const std::string flag = argv[i], value = argv[i+1];
        if (flag == "--arm") arm = value;
        else if (flag == "--weights-manifest") manifest_path = value;
        else if (flag == "--warmup") warmup = std::stoi(value);
        else if (flag == "--iterations") iterations = std::stoi(value);
        else if (flag == "--cpu") cpu = std::stoi(value);
        else throw std::runtime_error("unknown option: " + flag);
    }
    if ((arm != "cublas" && arm != "paired") || manifest_path.empty() || warmup < 0 || iterations < 1 || cpu < -1)
        throw std::runtime_error("requires --arm cublas|paired --weights-manifest PATH, positive iterations, nonnegative warmup");
    affinity(cpu);
    const auto manifest = load_manifest(manifest_path);
    check(cudaSetDevice(0));
    cudaDeviceProp props{}; check(cudaGetDeviceProperties(&props, 0));
    cudaStream_t stream = nullptr; check(cudaStreamCreateWithFlags(&stream, cudaStreamNonBlocking));
    struct Stream final { cudaStream_t value; ~Stream() { (void)cudaStreamSynchronize(value); (void)cudaStreamDestroy(value); } } held{stream};
    std::array<Pair, kPairs> pairs;
    Blas control;
    std::ifstream source(manifest.source, std::ios::binary);
    if (!source) throw std::runtime_error("cannot open retained original model weight source");
    std::uint64_t input_hash = kHashSeed;
    std::uint32_t state = 0x5cb31827U;
    for (std::size_t i = 0; i < pairs.size(); ++i) {
        const auto &pair = pairs[i];
        for (int bank = 0; bank < 2; ++bank) {
            const auto &entry = manifest.pairs[i][bank];
            std::vector<std::uint16_t> weight(kWeightBytes/2);
            source.seekg(static_cast<std::streamoff>(entry.offset));
            source.read(reinterpret_cast<char *>(weight.data()), static_cast<std::streamsize>(entry.bytes));
            if (!source) throw std::runtime_error("short read for actual a/b model weight");
            for (const auto bits : weight)
                if ((bits & 0x7f80U) == 0x7f80U) throw std::runtime_error("nonfinite actual BF16 weight");
            input_hash = hash(input_hash, weight.data(), kWeightBytes);
            check(cudaMemcpy(bank ? pair.w1.data : pair.w0.data, weight.data(), kWeightBytes, cudaMemcpyHostToDevice));
        }
        std::array<std::uint16_t, kK> activation{};
        for (auto &bits : activation) {
            state ^= state << 13; state ^= state >> 17; state ^= state << 5;
            bits = std::uint16_t((state & 0x807fU) | ((125U + ((state >> 8) % 4U)) << 7));
        }
        input_hash = hash(input_hash, activation.data(), activation.size()*2);
        check(cudaMemcpy(pair.x.data, activation.data(), activation.size()*2, cudaMemcpyHostToDevice));
    }
    check(cudaDeviceSynchronize()); // Cold upload completion only, before either capture.
    const auto commands = [&](bool use_pair) {
        for (const auto &pair : pairs) { if (use_pair) paired(pair, stream); else control.run(pair, stream); }
    };
    // Cold lazy module/algorithm preparation is outside both captures/timing.
    commands(false); commands(true); check(cudaStreamSynchronize(stream));
    Graph baseline, candidate;
    check(cudaStreamBeginCapture(stream, cudaStreamCaptureModeThreadLocal));
    commands(false); baseline.finish(stream);
    check(cudaStreamBeginCapture(stream, cudaStreamCaptureModeThreadLocal));
    commands(true); candidate.finish(stream);
    check(cudaGraphLaunch(baseline.exec, stream)); check(cudaStreamSynchronize(stream));
    check(cudaGraphLaunch(candidate.exec, stream)); check(cudaStreamSynchronize(stream));
    std::vector<std::uint16_t> reference, actual;
    double max_absolute = 0, max_relative = 0, squared_error = 0;
    std::size_t mismatches = 0;
    for (const auto &pair : pairs) for (int bank = 0; bank < 2; ++bank) {
        std::array<std::uint16_t, kN> a{}, b{};
        check(cudaMemcpy(a.data(), bank ? pair.control1.data : pair.control0.data, sizeof(a), cudaMemcpyDeviceToHost));
        check(cudaMemcpy(b.data(), bank ? pair.paired1.data : pair.paired0.data, sizeof(b), cudaMemcpyDeviceToHost));
        for (int i = 0; i < kN; ++i) {
            if ((a[i] & 0x7f80U) == 0x7f80U || (b[i] & 0x7f80U) == 0x7f80U)
                throw std::runtime_error("nonfinite actual projection result");
            const double expected = decode(a[i]), value = decode(b[i]);
            const double error = std::abs(value-expected);
            max_absolute = std::max(max_absolute, error);
            if (expected != 0) max_relative = std::max(max_relative, error/std::abs(expected));
            squared_error += error*error;
            mismatches += a[i] != b[i];
        }
        reference.insert(reference.end(), a.begin(), a.end());
        actual.insert(actual.end(), b.begin(), b.end());
    }
    const auto &selected = arm == "paired" ? candidate : baseline;
    const auto run = [&] { check(cudaGraphLaunch(selected.exec, stream)); check(cudaStreamSynchronize(stream)); };
    for (int i = 0; i < warmup; ++i) run();
    std::vector<double> samples; samples.reserve(std::size_t(iterations));
    for (int i = 0; i < iterations; ++i) {
        const auto start = std::chrono::steady_clock::now(); run();
        samples.push_back(std::chrono::duration<double, std::micro>(std::chrono::steady_clock::now()-start).count());
    }
    std::cout << std::setprecision(12) << "{\"completed\":true,\"arm\":\"" << arm
        << "\",\"pairs\":18,\"M\":1,\"N\":16,\"K\":2048,\"dtype\":\"BF16\",\"accumulator\":\"F32\","
        << "\"weight_corpus\":\"original-formal-model-a-b\",\"activation_corpus\":\"fixed-normal-finite-v1\","
        << "\"timing\":\"one-native-captured-chunk-launch-through-stream-completion\","
        << "\"caller_cpu\":" << cpu << ",\"warmup\":" << warmup << ",\"iterations\":" << iterations
        << ",\"resident_weight_bytes\":" << kPairs*2*kWeightBytes
        << ",\"resident_activation_bytes\":" << kPairs*kK*2 << ",\"device_L2_bytes\":" << props.l2CacheSize
        << ",\"cublas_workspace_bytes\":" << control.selected.workspaceSize
        << ",\"cublas_kernel_nodes\":" << baseline.kernel_nodes
        << ",\"paired_kernel_nodes\":" << candidate.kernel_nodes
        << ",\"cublas_memcpy_nodes\":" << baseline.memcpy_nodes
        << ",\"paired_memcpy_nodes\":" << candidate.memcpy_nodes
        << ",\"cublas_first_grid_block\":[";
    for (std::size_t i = 0; i < 6; ++i) std::cout << (i ? "," : "") << baseline.first_kernel_geometry[i];
    std::cout << "],\"paired_first_grid_block\":[";
    for (std::size_t i = 0; i < 6; ++i) std::cout << (i ? "," : "") << candidate.first_kernel_geometry[i];
    std::cout << "],\"output_elements\":" << actual.size() << ",\"bf16_bit_mismatches\":" << mismatches
        << ",\"exact_equal\":" << (mismatches ? "false" : "true")
        << ",\"max_abs_error_vs_cublas\":" << max_absolute << ",\"max_relative_error_nonzero_vs_cublas\":" << max_relative
        << ",\"rmse_vs_cublas\":" << std::sqrt(squared_error/double(actual.size()))
        << ",\"submit_wait_us_median\":" << median(samples)
        << ",\"input_fnv1a64\":\"" << std::hex << input_hash
        << "\",\"cublas_output_fnv1a64\":\"" << hash(kHashSeed, reference.data(), reference.size()*2)
        << "\",\"paired_output_fnv1a64\":\"" << hash(kHashSeed, actual.data(), actual.size()*2)
        << "\",\"manifest_source_sha256_recorded\":\"" << manifest.source_sha << std::dec
        << "\",\"reference_bf16_bits\":[";
    for (std::size_t i = 0; i < reference.size(); ++i) std::cout << (i ? "," : "") << reference[i];
    std::cout << "],\"paired_bf16_bits\":[";
    for (std::size_t i = 0; i < actual.size(); ++i) std::cout << (i ? "," : "") << actual[i];
    std::cout << "],\"samples_us\":[";
    for (std::size_t i = 0; i < samples.size(); ++i) std::cout << (i ? "," : "") << samples[i];
    std::cout << "]}\n";
    return 0;
} catch (const std::exception &error) {
    std::cerr << "PAIRED_SMALL_PROJECTION_BENCH_FAILURE " << error.what() << '\n';
    return 1;
}
