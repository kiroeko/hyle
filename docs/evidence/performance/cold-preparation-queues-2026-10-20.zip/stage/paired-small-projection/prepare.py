"""Derive a scratch two-output MMVF experiment without product/cache edits."""
from pathlib import Path
import difflib
import hashlib
import json

STAGE = Path(__file__).resolve().parent
ROOT = STAGE.parents[2]
SOURCE = STAGE.parent / 'typed-gating-suffix/native-source/src/ggml-cuda/mmvf.cuh'


def identity(path):
    data = path.read_bytes()
    return dict(path=str(path.resolve()), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())


def save(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8')


def main():
    assert not (STAGE / 'kernel-source-freeze.json').exists(), 'Already prepared'
    original = SOURCE.read_text(encoding='utf-8')
    assert hashlib.sha256(original.encode()).hexdigest() == '3bbb18c263d1479dc6f445f539460e561f7330cf643c978fc1678f73881bcaa0'
    start = original.index('template<bool strict_f32_ids>')
    end = original.index('template<typename T, typename type_acc, int ncols_dst, int block_size, bool is_multi_token_id = false,')
    body = original[start:end]
    before = STAGE / 'original-kernel.cuh'
    before.write_text(body, encoding='utf-8', newline='\n')
    edits = []

    def replace(old, new):
        nonlocal body
        assert body.count(old) == 1, old[:120]
        body = body.replace(old, new, 1)
        edits.append(dict(before=old, after=new))

    replace('static __global__ void mul_mat_vec_f(', 'static __global__ void paired_small_mul_mat_vec_f(')
    replace('const ggml_cuda_mm_fusion_args_device fusion, Dst * dst_ptr,',
            'const ggml_cuda_mm_fusion_args_device fusion, Dst * dst_ptr, Dst * other_dst_ptr,')
    replace('    Dst           * GGML_CUDA_RESTRICT dst = dst_ptr;',
            '    Dst           * GGML_CUDA_RESTRICT dst = dst_ptr;\n    Dst           * GGML_CUDA_RESTRICT other_dst = other_dst_ptr;')
    replace('    dst += int64_t(sample_dst)*stride_sample_dst + channel_dst*stride_channel_dst;',
            '    dst += int64_t(sample_dst)*stride_sample_dst + channel_dst*stride_channel_dst;\n    other_dst += int64_t(sample_dst)*stride_sample_dst + channel_dst*stride_channel_dst;')
    replace('        dst += token_idx*stride_col_dst;',
            '        dst += token_idx*stride_col_dst;\n        other_dst += token_idx*stride_col_dst;')
    epilogue_start = body.index('    float value = sumf[tid];')
    epilogue_end = body.index('\n}\n', epilogue_start)
    old = body[epilogue_start:epilogue_end]
    new = '''    // Scratch experiment: two real independent BF16 projection outputs.
    // All pair loads, F32 accumulations and original warp/shared reductions
    // above are byte-for-byte from the current shared MMVF carrier. No SiLU,
    // Multiply, bias reinterpretation, joined weight bank or second executor.
    static_assert(has_fusion && ncols_dst == 1 && !is_multi_token_id);
    static_assert(std::is_same_v<T, nv_bfloat16> && std::is_same_v<type_acc, float> &&
                  std::is_same_v<Y, nv_bfloat16> && std::is_same_v<Dst, nv_bfloat16> &&
                  std::is_void_v<Epilogue> && !strict_f32_ids);
    dst[tid*stride_col_dst + row] = __float2bfloat16_rn(sumf[tid]);
    other_dst[tid*stride_col_dst + row] = __float2bfloat16_rn(sumf_gate[tid]);
    GGML_UNUSED_VARS(use_bias, use_gate_bias, glu_op, glu_limit, x_bias, gate_bias);'''
    replace(old, new)
    prefix = '''// Scratch-only, mechanically derived from the accepted MMVF kernel.
// See prepare.py / kernel-source-freeze.json for exact source and edits.
#pragma once
#include "common.cuh"
#include "convert.cuh"
#include <type_traits>

'''
    after = STAGE / 'paired-kernel.cuh'
    after.write_text(prefix + body, encoding='utf-8', newline='\n')
    (STAGE / 'kernel-changes.diff').write_text(''.join(difflib.unified_diff(
        before.read_text().splitlines(True), body.splitlines(True),
        fromfile='accepted-MMVF-kernel', tofile='scratch-two-output-MMVF-kernel')),
        encoding='utf-8', newline='\n')
    # One existing precise-unary command, with the scratch TU/output switched.
    # No command is executed here; root owns compiler environment/link/runtime.
    recipe_path = STAGE.parent / 'typed-gating-suffix/checks/native1/unary-identity.json'
    recipe = json.loads(recipe_path.read_text(encoding='utf-8'))
    source, output, dep, pdb = STAGE / 'bench.cu', STAGE / 'bench.obj', STAGE / 'bench.d', STAGE / 'bench.pdb'
    command, skip = [], False
    for arg in recipe['command']:
        if skip:
            skip = False
            continue
        if arg in ('-MT', '-MF', '-o'):
            skip = True
        elif arg.startswith('-Xcompiler=-Fd'):
            continue
        elif arg.casefold().endswith(('.cu', '.cc', '.cpp')):
            continue
        else:
            command.append(arg)
    command += ['-MT', str(output), '-MF', str(dep), str(source), '-o', str(output),
                '-Xcompiler=-Fd' + str(pdb) + ',-FS']
    save(STAGE / 'compile-recipe.json', dict(command=command,
        source_recipe=identity(recipe_path), source=str(source), object=str(output),
        flags='Existing precise-unary sm_89/native headers/MSVC/CUDA cache, no use_fast_math; no command executed',
        link='Reuse the current Qwen ordinary link closure, remove its one main object, add bench.obj. Existing CUDA/cublasLt libraries and compiler environment. Do not build SDKs or other TUs.'))
    save(STAGE / 'kernel-source-freeze.json', dict(
        original_header=identity(SOURCE), original_kernel=identity(before),
        scratch_kernel=identity(after), driver=identity(Path(__file__)),
        diff=identity(STAGE / 'kernel-changes.diff'), edits=edits,
        arithmetic='Original BF16 pair dot and F32 warp/shared tree retained verbatim. Only terminal epilogue replaced by two independent BF16 RN stores. This tree can differ from cuBLAS; no bit-equality or quality acceptance claimed.',
        launch='N16 grid, original selected block256 for K2048, two original 32-float shared reduction arrays (256 bytes).',
        product_changed=False, compiled=False, executed=False))
    print(identity(after))


if __name__ == '__main__':
    main()
