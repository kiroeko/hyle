"""Execute only this bounded two-output carrier experiment, no product edits."""
import argparse
import importlib.util
import json
from pathlib import Path
import statistics
import shutil
import sys
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('paired_probe_build',S.parent/'typed-gating-suffix/build.py')
h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
b,c=h.b,h.c
def main():
 p=argparse.ArgumentParser();p.add_argument('--build',action='store_true');p.add_argument('--run',action='store_true');a=p.parse_args()
 out=S/'build';out.mkdir(exist_ok=True);(out/'tmp').mkdir(exist_ok=True)
 base=c.read(S.parent/'typed-gating-suffix/checks/native1/qwen-link-plan.json')
 recipe=c.read(S/'compile-recipe.json')
 changes={str(S/('bench'+ext)):str(out/('bench'+ext)) for ext in ('.obj','.d','.pdb')}
 command=[changes.get(arg,arg) for arg in recipe['command']]
 command=[arg.replace(str(S/'bench.pdb'),str(out/'bench.pdb')) if arg.startswith('-Xcompiler=-Fd') else arg for arg in command]
 # native_command supplies the one actual current compiler host path.
 clean=[];skip=False
 for arg in command:
  if skip:skip=False
  elif arg=='-ccbin':skip=True
  else:clean.append(arg)
 compiler=c.read(S.parent/'qwen-current-retest/checks/main1/qwen-main-identity.json')['command'][0]
 command=clean+['-ccbin',str(Path(compiler).parent)]
 meta=h.h.metadata(dict(current=base))
 main=[row for row in base['inputs'] if c.key(row['path']) in meta and meta[c.key(row['path'])]['source_path'].replace('\\','/').endswith('/tools/qwen35_text/main.cc')]
 assert len(main)==1
 obj=out/'bench.obj';image=out/'bench.exe'
 link=[arg for arg in base['command'] if c.key(arg)!=c.key(main[0]['path']) and not arg.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:'))]
 link.insert(1,str(obj));link+=['/OUT:'+str(image),'/MAP:'+str(image.with_suffix('.map')),'/IMPLIB:'+str(image.with_suffix('.lib'))]
 env,runtime=b.environment(base['command'],[row['path'] for row in base['inputs']],out)
 if a.build:
  if (out/'compile.result.json').exists() and c.read(out/'compile.result.json')['exit']:
   for path in [out/'plan.json',*out.glob('compile.*')]:
    if path.is_file():shutil.copyfile(path,out/('first-failed-'+path.name))
  assert b.identity(S/'bench.cu')['sha256']=='099ad6209af10957b70997dc1a00dee290f878172b53b33ef58e80dc3d1c5a8d'
  c.save(out/'plan.json',dict(command=command,link=link,source=b.identity(S/'bench.cu'),kernel=b.identity(S/'paired-kernel.cuh'),runtime=runtime,native_TUs=1,SDK=0))
  c.execute('compile',command,env,out);c.execute('link',link,env,out)
  c.save(out/'image.json',b.identity(image))
  data=[b.identity(obj),*(row for row in base['inputs'] if row!=main[0])]
  c.save(out/'link-plan.json',dict(command=link,inputs=data))
 if a.run:
  assert b.same(c.read(out/'image.json'))
  obs=S/'timing';obs.mkdir(exist_ok=False);rows=[]
  manifest=S.parent/'qwen-gpu-comparison/128-prefill/inputs/weights.tsv'
  for i,arm in enumerate(('cublas','paired','paired','cublas','cublas','paired'),1):
   d=obs/(str(i)+'-'+arm);d.mkdir();(d/'tmp').mkdir()
   cmd=[str(image),'--arm',arm,'--weights-manifest',str(manifest),'--warmup','128','--iterations','512','--cpu','2']
   c.execute('bench',cmd,env,d)
   docs=[json.loads(line) for line in (d/'bench.stdout.log').read_text().splitlines() if line.startswith('{')]
   assert len(docs)==1 and docs[0]['completed'];r=docs[0]
   assert r['cublas_kernel_nodes']==36 and r['paired_kernel_nodes']==18
   assert r['cublas_first_grid_block']==[4,1,1,32,4,1]
   rows.append(dict(arm=arm,result=r));c.save(d/'observation.json',rows[-1])
  for row in rows:
   for key in ('input_fnv1a64','reference_bf16_bits','paired_bf16_bits'):
    assert row['result'][key]==rows[0]['result'][key],key
  med={arm:statistics.median(r['result']['submit_wait_us_median'] for r in rows if r['arm']==arm) for arm in ('cublas','paired')}
  summary=dict(completed=True,product_changes=False,processes=rows,medians_us=med,
    ratio_paired_over_cublas=med['paired']/med['cublas'],exact_outputs=rows[0]['result']['exact_equal'],
    raw_BF16_mismatches=rows[0]['result']['bf16_bit_mismatches'],
    limits='Fixed normal BF16 activations and real resident2.25MiB model a/b weights, hot-cache captured18pairs. RawGraphLaunch->StreamSynchronize, not Hyle Graph admission or full-model speed/quality. Distinct cuBLAS/MMVF reduction trees, no tolerance acceptance.')
  c.save(obs/'summary.json',summary);print('PAIRED_SMALL_PROJECTION',med,summary['raw_BF16_mismatches'],flush=True)
if __name__=='__main__':main()
