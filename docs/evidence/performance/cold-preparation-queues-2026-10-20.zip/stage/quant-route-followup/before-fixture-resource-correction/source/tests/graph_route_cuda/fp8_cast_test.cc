#include "../compute_provider_native/aten_cast_reference.h"
#include "hyle/compute/backends/cuda.h"
#include "hyle/compute/prepared_operation.h"
#include "hyle/compute/providers/torch_cuda.h"
#include "hyle/compute/storage_owner.h"
#include "hyle/graph/cuda.h"

#include <algorithm>
#include <array>
#include <bit>
#include <cmath>
#include <cstdint>
#include <cstring>
#include <limits>
#include <span>
#include <stdexcept>
#include <string>
#include <string_view>
#include <utility>
#include <vector>

#include <gtest/gtest.h>

#if defined(HYLE_COMPUTE_TORCH_CUDA)
namespace {
namespace c = hyle::compute;
namespace g = hyle::graph;
namespace m = hyle::mem;
namespace ref = cast_reference;
using Type = c::DataType;
using Bytes = std::vector<std::byte>;

template <class T> T take(hyle::Result<T> result, std::string_view where) {
  if (!result) throw std::runtime_error(std::string(where) + ": " + std::string(result.error().message()));
  return std::move(*result);
}
void check(hyle::Status status, std::string_view where) {
  if (!status.ok()) throw std::runtime_error(std::string(where) + ": " + std::string(status.message()));
}
c::TensorDesc dense(Type type, std::size_t count) {
  return c::TensorDesc::dense(type, std::array{static_cast<std::int64_t>(count)}).value();
}
Bytes payload(std::span<const std::uint32_t> codes, int width) {
  Bytes bytes(codes.size() * static_cast<std::size_t>(width));
  for (std::size_t i = 0; i < codes.size(); ++i)
    std::memcpy(bytes.data() + i * static_cast<std::size_t>(width), &codes[i], width);
  return bytes;
}
Bytes read(c::ConstTensorView view) {
  Bytes result(view.description().required_bytes().value());
  check(view.storage().read(result), "BufferView::read");
  return result;
}
std::uint32_t expected(std::uint32_t bits, const ref::Format &source, const ref::Format &target) {
  if (source.type == target.type) return bits;
  const auto wide = ref::float_bits(bits, source);
  return target.width == 4 ? wide : ref::encode(std::bit_cast<float>(wide), target, (wide >> 31) != 0);
}
void exact(const Bytes &bytes, std::span<const std::uint32_t> codes,
           const ref::Format &source, const ref::Format &target) {
  ASSERT_EQ(bytes.size(), codes.size() * static_cast<std::size_t>(target.width));
  for (std::size_t i = 0; i < codes.size(); ++i) {
    std::uint32_t actual = 0;
    std::memcpy(&actual, bytes.data() + i * static_cast<std::size_t>(target.width), target.width);
    ASSERT_EQ(actual, expected(codes[i], source, target))
        << "index=" << i << " source=" << int(source.type) << " target=" << int(target.type)
        << " raw=" << codes[i];
  }
}
std::vector<std::uint32_t> all_codes(unsigned count) {
  std::vector<std::uint32_t> result(count);
  for (unsigned i = 0; i < count; ++i) result[i] = i;
  return result;
}
Bytes direct(c::Context &context, c::Queue &queue, m::MemoryResourceRef memory,
             const ref::Format &source, const ref::Format &target,
             std::span<const std::uint32_t> codes) {
  const auto in = dense(source.type, codes.size()), out = dense(target.type, codes.size());
  auto source_buffer = take(m::Buffer::create(memory, in.required_bytes().value(), 256), "Direct input buffer");
  const auto bytes = payload(codes, source.width);
  check(source_buffer.view().write(bytes), "Direct source upload");
  auto destination = take(m::Buffer::create(memory, out.required_bytes().value(), 256), "Direct output buffer");
  const auto a = c::ConstTensorView::create(in, source_buffer.view()).value();
  const auto y = c::TensorView::create(out, destination.view()).value();
  auto prepared = take(c::prepare(context, c::Cast{target.type}, in), "FP8 Cast prepare");
  EXPECT_EQ(prepared.provider().id, c::torch_cuda::kProviderId);
  EXPECT_FALSE(prepared.alias_support(0, 0)->supported);
  EXPECT_FALSE(prepared.runtime_properties().capture_compatible);
  EXPECT_EQ(prepared.runtime_properties().replay_class, c::ProviderReplayClass::kManaged);
  auto call = take(prepared.create_invocation(), "FP8 Cast invocation");
  auto done = take(call.submit(queue, a, y), "FP8 Cast submit");
  check(done.wait(), "FP8 Cast Completion::wait");
  EXPECT_EQ(read(a), bytes);
  return read(y.as_const());
}

TEST(CudaFp8Cast, EveryFp8StorageCodeWidensAndSameTypeCopyKeepsBits) {
  auto context = g::cuda::create_context().value();
  auto memory = c::cuda::MemoryResource::create(context, c::cuda::MemoryKind::kDevice).value();
  auto queue = context.create_queue().value();
  const auto codes = all_codes(256);
  for (const auto &source : std::span(ref::formats).subspan(3)) {
    for (const auto &target : std::span(ref::formats).first(3)) {
      const auto actual = direct(context, queue, memory.ref(), source, target, codes);
      exact(actual, codes, source, target);
    }
    EXPECT_EQ(direct(context, queue, memory.ref(), source, source, codes), payload(codes, 1));
  }
}

TEST(CudaFp8Cast, Float32MidpointsNeighborsOverflowInfinitiesAndNanBits) {
  auto context = g::cuda::create_context().value();
  auto memory = c::cuda::MemoryResource::create(context, c::cuda::MemoryKind::kDevice).value();
  auto queue = context.create_queue().value();
  for (const auto &target : std::span(ref::formats).subspan(3)) {
    std::vector<std::uint32_t> codes{0, 0x80000000, 1, 0x80000001,
        0x7f7fffff, 0xff7fffff, 0x7f800000, 0xff800000,
        0x7f800001, 0xff800001, 0x7fc12345, 0xffc12345};
    const unsigned maximum = target.infinity ? 0x7bU : 0x7eU;
    for (unsigned i = 0; i < maximum; ++i) {
      const auto midpoint = static_cast<float>((ref::decode(i, target) + ref::decode(i + 1, target)) / 2);
      for (const float x : {std::nextafter(midpoint, -INFINITY), midpoint, std::nextafter(midpoint, INFINITY)})
        for (const float y : {x, -x}) codes.push_back(std::bit_cast<std::uint32_t>(y));
    }
    for (const float value : {448.F, 449.F, 464.F, 57344.F, 61440.F, 65504.F})
      for (const float signed_value : {value, -value}) codes.push_back(std::bit_cast<std::uint32_t>(signed_value));
    exact(direct(context, queue, memory.ref(), ref::formats[0], target, codes), codes, ref::formats[0], target);
  }
}

TEST(CudaFp8Cast, LowPrecisionPatternsAndCrossFp8UseThePublicStorageOracle) {
  auto context = g::cuda::create_context().value();
  auto memory = c::cuda::MemoryResource::create(context, c::cuda::MemoryKind::kDevice).value();
  auto queue = context.create_queue().value();
  const auto low_codes = all_codes(65536), fp8_codes = all_codes(256);
  for (const auto &source : std::span(ref::formats).subspan(1, 2))
    for (const auto &target : std::span(ref::formats).subspan(3))
      exact(direct(context, queue, memory.ref(), source, target, low_codes), low_codes, source, target);
  for (const auto &source : std::span(ref::formats).subspan(3))
    for (const auto &target : std::span(ref::formats).subspan(3))
      if (source.type != target.type)
        exact(direct(context, queue, memory.ref(), source, target, fp8_codes), fp8_codes, source, target);
}

c::ReadLease upload(const c::StorageOwner &owner, const Bytes &bytes) {
  auto buffer = take(m::Buffer::create(owner.ref(), bytes.size(), 256), "owned input buffer");
  check(buffer.view().write(bytes), "owned input upload");
  return take(owner.adopt_buffer(std::move(buffer)), "adopt owned input");
}

TEST(CudaFp8Cast, PublicClipGraphRebindsTwoOwnedSlotsAndRejectsRequireCapture) {
  auto context = g::cuda::create_context().value();
  auto owner = c::StorageOwner::adopt(context,
      c::cuda::MemoryResource::create(context, c::cuda::MemoryKind::kDevice).value()).value();
  constexpr std::size_t count = 9;
  const auto input = dense(Type::kFloat32, count), limit = dense(Type::kFloat32, 1);
  const auto fp8 = dense(Type::kFloat8E4M3FN, count);
  auto builder = g::GraphBuilder::create().value();
  const auto x = builder.input(input).value(), lo = builder.input(limit).value(), hi = builder.input(limit).value();
  const auto lower = builder.add_node(c::Operation(c::Binary{c::BinaryKind::kMaximum}), std::array{x, lo}).value();
  const auto upper = builder.add_node(c::Operation(c::Binary{c::BinaryKind::kMinimum}), std::array{builder.result(lower).value(), hi}).value();
  const auto narrow = builder.add_node(c::Operation(c::Cast{Type::kFloat8E4M3FN}), std::array{builder.result(upper).value()}).value();
  const auto encoded = builder.result(narrow).value();
  const auto widen = builder.add_node(c::Operation(c::Cast{Type::kFloat32}), std::array{encoded}).value();
  const auto y = builder.result(widen).value();
  check(builder.publish(encoded), "publish encoded storage"); check(builder.publish(y), "publish decoded storage");
  const auto graph = std::move(builder).finish().value();
  auto program = take(g::cuda::compile(graph, context, owner), "public clip/Cast Graph compile");
  std::size_t managed_casts = 0;
  for (std::size_t i = 0; i < program.report.step_count(); ++i)
    managed_casts += program.report.step(i)->provider.id == c::torch_cuda::kProviderId;
  EXPECT_EQ(managed_casts, 2U);
  std::array queues{context.create_queue().value(), context.create_queue().value()};
  std::array slots{
      program.executable.create_invocation({.resources = g::ResourceOptions{}}).value(),
      program.executable.create_invocation({.resources = g::ResourceOptions{}}).value()};
  const std::array lower_bits{std::bit_cast<std::uint32_t>(-448.F)}, upper_bits{std::bit_cast<std::uint32_t>(448.F)};
  auto low = upload(owner, payload(lower_bits, 4)), high = upload(owner, payload(upper_bits, 4));
  std::array<c::ReadLease, 2> sources;
  std::array<Bytes, 2> first;
  g::GraphOutput old;
  for (unsigned round = 0; round < 2; ++round)
    for (const unsigned lane : {1U, 0U}) {
      if (round) { if (lane == 0) old.reset(); check(slots[lane].reset(), "reset completed Graph episode"); }
      std::vector<std::uint32_t> codes;
      for (const float value : {-INFINITY, -449.F, -1.0625F, -0.F, 0.F, .1F, 1.1875F, 449.F, INFINITY})
        codes.push_back(std::bit_cast<std::uint32_t>(std::isfinite(value) && value != 0
            ? value * (round ? .5F : 1.F) * (lane ? -1.F : 1.F) : value));
      auto fresh = upload(owner, payload(codes, 4));
      if (round) {
        const auto before = take(sources[lane].view(), "old source backing"), after = take(fresh.view(), "fresh source backing");
        EXPECT_TRUE(before.native_handle() != after.native_handle() || before.offset() != after.offset());
      }
      sources[lane] = std::move(fresh);
      check(slots[lane].bind(x, input, sources[lane]), "bind current input permission");
      check(slots[lane].bind(lo, limit, low), "bind lower limit");
      check(slots[lane].bind(hi, limit, high), "bind upper limit");
      if (round == 0 && lane == 1)
        EXPECT_FALSE(g::cuda::prepare_replay(slots[lane], queues[lane], {.mode = g::ReplayMode::kCommands}).ok());
      auto p8 = take(c::LeasePool::create(owner.ref(), count, {.max_blocks = 1, .backing_alignment = 256}), "encoded LeasePool");
      auto p32 = take(c::LeasePool::create(owner.ref(), count * 4, {.max_blocks = 1, .backing_alignment = 256}), "decoded LeasePool");
      check(slots[lane].bind(encoded, fp8, take(p8.allocate(count, 256), "encoded WriteLease")), "bind encoded output");
      check(slots[lane].bind(y, input, take(p32.allocate(count * 4, 256), "decoded WriteLease")), "bind decoded output");
      const auto capture = g::cuda::prepare_replay(slots[lane], queues[lane], {.mode = g::ReplayMode::kRequireCapture});
      EXPECT_FALSE(capture.ok()); // Managed ATen temporary allocation is not capture-compatible.
      check(g::cuda::prepare_replay(slots[lane], queues[lane], {.mode = g::ReplayMode::kCommands}), "prepare managed Commands retry");
      EXPECT_EQ(slots[lane].replay_route(), g::ReplayRoute::kCommands);
      auto done = take(slots[lane].submit(queues[lane]), "managed Graph submit"); check(done.wait(), "managed Graph wait");
      auto code_result = take(slots[lane].result(encoded), "encoded GraphOutput");
      auto decoded_result = take(slots[lane].result(y), "decoded GraphOutput");
      const auto code_bytes = read(take(code_result.tensor(), "encoded output tensor"));
      std::vector<std::uint32_t> clipped, encoded_codes;
      for (const auto bits : codes) {
        const float value = std::bit_cast<float>(bits);
        clipped.push_back(std::bit_cast<std::uint32_t>((std::min)(448.F, (std::max)(-448.F, value))));
        encoded_codes.push_back(expected(clipped.back(), ref::formats[0], ref::formats[3]));
      }
      exact(code_bytes, clipped, ref::formats[0], ref::formats[3]);
      exact(read(take(decoded_result.tensor(), "decoded output tensor")), encoded_codes, ref::formats[3], ref::formats[0]);
      EXPECT_TRUE(slots[lane].reset().IsUnavailable()); // A real result(), not the borrowed output() view.
      if (!round) first[lane] = code_bytes;
      else {
        EXPECT_NE(code_bytes, first[lane]);
        if (lane == 1) EXPECT_EQ(read(take(old.tensor(), "other slot retained GraphOutput")), first[0]);
      }
      if (!round && lane == 0) old = std::move(code_result);
    }
}

TEST(CudaFp8Cast, NativeAdmissionRejectsStridesAndOverlapButHandlesEmptyAndScalar) {
  const std::array bindings{c::ProviderBinding{c::torch_cuda::provider(), 100}};
  auto context = c::Context::create(c::cuda::device(0).value(), {.providers = bindings}).value();
  auto memory = c::cuda::MemoryResource::create(context, c::cuda::MemoryKind::kDevice).value();
  auto queue = context.create_queue().value();
  const auto strided = c::TensorDesc::strided_bytes(Type::kFloat8E4M3FN,
      std::array<std::int64_t, 1>{3}, std::array<std::int64_t, 1>{2}).value();
  auto unsupported = c::prepare(context, c::Cast{Type::kFloat32}, strided);
  ASSERT_FALSE(unsupported); EXPECT_TRUE(unsupported.error().IsUnimplemented());
  const auto d = dense(Type::kFloat8E4M3FN, 4);
  auto storage = take(m::Buffer::create(memory.ref(), 4, 256), "alias input buffer");
  const auto codes = std::array<std::uint32_t, 4>{0, 0x80, 0x7f, 0xff};
  check(storage.view().write(payload(codes, 1)), "alias input upload");
  auto prepared = take(c::prepare(context, c::Cast{Type::kFloat8E4M3FN}, d), "same-type Cast prepare");
  auto call = take(prepared.create_invocation(), "same-type Cast invocation");
  EXPECT_FALSE(call.submit(queue, c::ConstTensorView::create(d, storage.view()).value(),
      c::TensorView::create(d, storage.view()).value()));
  EXPECT_EQ(read(c::ConstTensorView::create(d, storage.view()).value()), payload(codes, 1));
  for (const auto &shape : std::array<std::vector<std::int64_t>, 2>{std::vector<std::int64_t>{}, {0}}) {
    const auto source = c::TensorDesc::dense(Type::kFloat8E4M3FN, shape).value();
    auto p = take(c::prepare(context, c::Cast{Type::kFloat32}, source), "scalar/empty Cast prepare");
    const auto target = p.output_description(0).value();
    auto a = take(m::Buffer::create(memory.ref(), source.required_bytes().value(), 256), "scalar/empty source");
    auto y = take(m::Buffer::create(memory.ref(), target.required_bytes().value(), 256), "scalar/empty output");
    const auto av = c::ConstTensorView::create(source, a.view()).value();
    if (!shape.empty()) EXPECT_EQ(source.element_count().value(), 0U);
    else check(a.view().write(payload(std::array<std::uint32_t, 1>{0x80}, 1)), "scalar signed-zero upload");
    auto invocation = take(p.create_invocation(), "scalar/empty invocation");
    auto done = take(invocation.submit(queue, av, c::TensorView::create(target, y.view()).value()), "scalar/empty submit");
    check(done.wait(), "scalar/empty wait");
    const auto actual = read(c::ConstTensorView::create(target, y.view()).value());
    if (shape.empty()) exact(actual, std::array<std::uint32_t, 1>{0x80}, ref::formats[3], ref::formats[0]);
    else EXPECT_TRUE(actual.empty());
  }
}
} // namespace
#endif
