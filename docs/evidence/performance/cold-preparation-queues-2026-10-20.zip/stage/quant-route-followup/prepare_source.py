from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
STAGE = Path(__file__).resolve().parent


def replace(text, old, new):
    assert text.count(old) == 1, old
    return text.replace(old, new)


cpu_path = ROOT / 'src/compute_provider_native/aten_cpu_provider.cc'
cpu = (STAGE / 'before/src/compute_provider_native/aten_cpu_provider.cc').read_text()
start = cpu.index('// Original ATen conversion followed by public NaN/finite-overflow semantics.')
end = cpu.index('\nat::Tensor activation(', start)
helper = cpu[start:end]
helper = replace(helper, 'at::Tensor storage_cast(', 'inline at::Tensor storage_cast(')
helper = replace(helper,
                 '  auto nan = at::where(value.flatten().signbit(), at::full_like(bits, negative),\n'
                 '                       at::full_like(bits, positive));',
                 '''  // Arithmetic widening can canonicalize a negative signalling NaN on CUDA.
  // The storage Cast contract instead preserves the original input sign.
  const auto source_type = input.scalar_type();
  const bool byte_source = source_type == at::kFloat8_e4m3fn || source_type == at::kFloat8_e5m2;
  const auto source_bits = input.flatten().view(byte_source ? at::kByte
      : source_type == at::kFloat ? at::kInt : at::kShort);
  const auto negative_source = byte_source ? source_bits.bitwise_and(0x80).ne(0)
                                          : source_bits.lt(0);
  auto nan = at::where(negative_source, at::full_like(bits, negative),
                       at::full_like(bits, positive));''')
header = ROOT / 'src/compute_torch_shared/storage_cast.h'
header.parent.mkdir(parents=True, exist_ok=True)
header.write_text('#pragma once\n\n#include <ATen/ATen.h>\n\nnamespace hyle::compute::torch_shared {\n\n'
                  + helper + '\n} // namespace hyle::compute::torch_shared\n')
cpu = cpu[:start] + cpu[end:]
cpu = replace(cpu, '#include <ATen/ATen.h>', '#include <ATen/ATen.h>\n\n#include "../compute_torch_shared/storage_cast.h"')
cpu = replace(cpu, 'result = storage_cast(first, native_type(p.output.data_type()));',
              'result = torch_shared::storage_cast(first, native_type(p.output.data_type()));')
cpu_path.write_text(cpu)

path = ROOT / 'src/compute_provider_torch_cuda/artifact_provider.cc'
text = (STAGE / 'before/src/compute_provider_torch_cuda/artifact_provider.cc').read_text()
text = replace(text, '#include "native_context.h"',
               '#include "../compute_torch_shared/storage_cast.h"\n#include "native_context.h"')
text = replace(text, '  bool is_attention = false;', '  bool is_attention = false;\n  bool is_cast = false;')
text = replace(text, '  case DataType::kBFloat16: return at::kBFloat16;',
               '  case DataType::kBFloat16: return at::kBFloat16;\n'
               '  case DataType::kFloat8E4M3FN: return at::kFloat8_e4m3fn;\n'
               '  case DataType::kFloat8E5M2: return at::kFloat8_e5m2;')
text = replace(text, '  const bool softplus = unary && unary->kind == UnaryKind::kSoftplus;\n'
               '  if (!operation.custom_as<model_ops::ArtifactWeightDecode>() && !mlx && !ct && !softplus && !attention)',
               '''  const bool softplus = unary && unary->kind == UnaryKind::kSoftplus;
  const auto *cast = operation.get_if<Cast>();
  if (!operation.custom_as<model_ops::ArtifactWeightDecode>() && !mlx && !ct && !softplus && !attention && !cast)''')
text = replace(text, '  if (attention) {', '''  if (cast) {
    const auto floating = [](DataType type) {
      return type == DataType::kFloat32 || type == DataType::kFloat16 ||
          type == DataType::kBFloat16 || type == DataType::kFloat8E4M3FN ||
          type == DataType::kFloat8E5M2;
    };
    const auto fp8 = [](DataType type) {
      return type == DataType::kFloat8E4M3FN || type == DataType::kFloat8E5M2;
    };
    if (inputs.size() != 1 || outputs.size() != 1 ||
        !inputs[0].is_plain() || !inputs[0].is_dense() ||
        !outputs[0].is_plain() || !outputs[0].is_dense() ||
        !floating(inputs[0].data_type()) || !floating(outputs[0].data_type()) ||
        (!fp8(inputs[0].data_type()) && !fp8(outputs[0].data_type())))
      return Status::Unimplemented("CUDA ATen FP8 Cast requires dense floating storage and an FP8 port");
  }
  if (attention) {''')
text = replace(text, '  for (const auto &desc : inputs) {\n    HYLE_ASSIGN_OR_RETURN(const auto bytes, desc.required_bytes());',
               '''  if (cast) {
    // The shared Cast helper's largest materialized element is F32/I32.
    // Keep this native allocation bound separate from public shape inference.
    HYLE_ASSIGN_OR_RETURN(const auto count, outputs[0].element_count());
    if (count > std::uint64_t{INT64_MAX / 4})
      return Status::OutOfRange("CUDA ATen FP8 Cast temporary capacity overflows");
    return Status::Ok();
  }
  for (const auto &desc : inputs) {
    HYLE_ASSIGN_OR_RETURN(const auto bytes, desc.required_bytes());''')
text = replace(text, ': unary ? 0x200ULL : mlx ? packed_route(*mlx) : ct ? ct_route(*ct)',
               ': request.operation.get_if<Cast>() ? 0x400ULL\n      : unary ? 0x200ULL : mlx ? packed_route(*mlx) : ct ? ct_route(*ct)')
text = replace(text, '  if ((program.is_mlx || program.is_ct) && *program.output.element_count() == 0)',
               '  if ((program.is_mlx || program.is_ct || program.is_cast) && *program.output.element_count() == 0)')
text = replace(text, '    if (program.is_attention) {\n      invocation.result = attention_result(program, tensors);',
               '''    if (program.is_cast) {
      // Original ATen CUDA kernels plus the same storage semantics as CPU:
      // FP8 finite saturation and explicit NaN bits, not bare Tensor::to.
      invocation.result = torch_shared::storage_cast(tensors[0], type);
    } else if (program.is_attention) {
      invocation.result = attention_result(program, tensors);''')
text = replace(text, '      .is_attention = attention != nullptr,',
               '      .is_attention = attention != nullptr,\n      .is_cast = request.operation.get_if<Cast>() != nullptr,')
# Cast prepares no native constant tensors and does not need a BLAS handle.
text = text.replace('!program->is_attention && !program->is_softplus',
                    '!program->is_attention && !program->is_softplus && !program->is_cast')
text = replace(text, '!program->is_attention && !program->is_mlx && !program->is_softplus',
               '!program->is_attention && !program->is_mlx && !program->is_softplus && !program->is_cast')
text = replace(text, '+stable-softplus+bf16-efficient-sdpa"',
               '+stable-softplus+bf16-efficient-sdpa+fp8-storage-cast"')
path.write_text(text)
print('prepared shared helper, CPU extraction and CUDA Cast')
