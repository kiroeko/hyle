"""Refresh the two actual readers of storage_cast and focused CPU/CUDA tests."""
import argparse
import concurrent.futures
import importlib.util
from pathlib import Path
import sys
sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
A = S.parent
ROOT = S.parents[2]
spec = importlib.util.spec_from_file_location('fp8_cast_build_helpers', A/'typed-gating-suffix/build.py')
h = importlib.util.module_from_spec(spec); spec.loader.exec_module(h)
b, c = h.b, h.c

def main():
    p = argparse.ArgumentParser(); p.add_argument('--build', action='store_true'); p.add_argument('--resume', action='store_true')
    args = p.parse_args()
    out = S/'checks/host1'; out.mkdir(parents=True, exist_ok=True); (out/'tmp').mkdir(exist_ok=True)
    queue = A/'cold-prepare-review/checks/queue1'
    paths = dict(cpu=queue/'cpu-link-plan.json', qwen=queue/'qwen-link-plan.json',
                 tests=A/'typed-gating-suffix/checks/native1/tests-link-plan.json')
    bases = {arm:c.read(path) for arm,path in paths.items()}
    meta = h.h.metadata(bases)
    owners = {arm:{c.key(meta[c.key(row['path'])]['source_path']):dict(meta[c.key(row['path'])], old_object=row)
        for row in base['inputs'] if c.key(row['path']) in meta} for arm,base in bases.items()}
    rows = []
    for arm, rel, tag in [('cpu','src/compute_provider_native/aten_cpu_provider.cc','aten-cpu'),
                          ('qwen','src/compute_provider_torch_cuda/artifact_provider.cc','torch-cuda-artifact')]:
        source = ROOT/rel; owner = owners[arm][c.key(source)]
        rows.append(dict(tag=tag, source=b.identity(source), source_name=str(source), object=str(out/(tag+'.obj')),
                         command=b.host_command(owner['command'],source,tag,out)))
    lease = Path(c.read(A/'lease-read-filter/latest-plan.json')['plan']).parent
    recipes = dict(cpu=c.read(lease/'region-test-identity.json')['command'],
                   tests=c.read(A/'bf16-grouped-bank/checks/native1/grouped-test-identity.json')['command'])
    for arm, rel, tag in [('cpu','tests/compute_provider_native/aten_cast_test.cc','cpu-cast-test'),
                          ('tests','tests/graph_route_cuda/fp8_cast_test.cc','cuda-cast-test')]:
        source = ROOT/rel; command = b.host_command(recipes[arm],source,tag,out)
        if arm=='tests' and not any(a.startswith('/DHYLE_COMPUTE_TORCH_CUDA') for a in command):
            assert c.key(ROOT/'src/compute_provider_torch_cuda/artifact_provider.cc') in owners['tests']
            command.insert(1,'/DHYLE_COMPUTE_TORCH_CUDA=1')
        rows.append(dict(tag=tag, source=b.identity(source), object=str(out/(tag+'.obj')), command=command, test_arm=arm))
    freeze_path=S/'source-freeze.json'; frozen=[b.identity(freeze_path)]
    for row in c.read(freeze_path)['files']:
        frozen.extend((row['current'],row['after']))
    frozen.extend(row['source'] for row in rows)
    plan=dict(compile=rows,frozen=frozen,base_paths={k:str(v) for k,v in paths.items()},links={},host_TUs=4,native_TUs=0,SDK_rebuild=False)
    c.save(out/'plan.json',plan);c.save(S/'latest-plan.json',dict(plan=str(out/'plan.json')))
    print('FP8_CAST_PLAN',len(rows),flush=True)
    if not args.build:return
    def check():
        for row in frozen:assert b.same(row),row['path']
    for base in bases.values():
        for row in base['inputs']:assert b.same(row),row['path']
    env,runtime=b.environment(bases['qwen']['command'],[r['path'] for base in bases.values() for r in base['inputs']],out)
    c.save(out/'runtime-environment.json',dict(runtime=runtime,PATH=env['PATH']))
    def compile_one(row):
        check(); receipt_path=out/(row['tag']+'-identity.json')
        if args.resume and receipt_path.exists():
            old=c.read(receipt_path)
            if old['command']==row['command'] and b.same(old['object']) and all(b.same(d) for d in old['dependencies']):
                print('REUSE',row['tag'],flush=True);return row['tag'],old
        c.execute(row['tag']+'-compile',row['command'],env,out);check()
        deps=c.read(out/(row['tag']+'-deps.json'))['Data']
        result=dict(command=row['command'],source=row['source'],object=b.identity(row['object']),
                    dependencies=[b.identity(p) for p in dict.fromkeys([deps['Source'],*deps['Includes']])])
        c.save(receipt_path,result);return row['tag'],result
    finished={}; errors=[]
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
        for future in concurrent.futures.as_completed([pool.submit(compile_one,row) for row in rows]):
            try:
                tag,result=future.result();finished[tag]=result
            except Exception as error:errors.append(repr(error))
    c.save(out/'compile-summary.json',dict(passed=not errors,errors=errors))
    if errors:raise RuntimeError(errors)
    for arm,base in bases.items():
        replacements={}
        for row in rows:
            if 'source_name' in row and c.key(row['source_name']) in owners[arm]:
                replacements[c.key(owners[arm][c.key(row['source_name'])]['old_object']['path'])]=finished[row['tag']]['object']
        # GPU tests had the previous private cache layout; use the freshly compiled definition AND sole owner.
        if arm=='tests':
            for name in ('constant_artifact.cc','executable.cc'):
                source=c.key(ROOT/'src/graph'/name)
                replacements[c.key(owners[arm][source]['old_object']['path'])]=c.read(queue/(Path(name).stem+'-identity.json'))['object']
        lookup={c.key(r['path']):r for r in base['inputs']};lookup.update({c.key(r['path']):r for r in replacements.values()})
        command=[replacements.get(c.key(a),{}).get('path',a) for a in base['command'] if not a.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:'))]
        for row in rows:
            if row.get('test_arm')!=arm:continue
            assert c.key(row['source']['path']) not in owners[arm], 'Fixture already present in base'
            obj=finished[row['tag']]['object'];command.insert(1,obj['path']);lookup[c.key(obj['path'])]=obj
        image=out/(arm+'.exe');command+=['/OUT:'+str(image),'/MAP:'+str(image.with_suffix('.map')),'/IMPLIB:'+str(image.with_suffix('.lib'))]
        inputs=[lookup[c.key(arg)] for arg in command if Path(arg).is_absolute() and Path(arg).suffix.lower() in ('.obj','.lib')]
        assert len(inputs)==len(set(c.key(row['path']) for row in inputs))
        for row in inputs:assert b.same(row),row['path']
        check()
        prior_path=out/(arm+'-link-plan.json'); image_path=out/(arm+'-image.json')
        unchanged=(args.resume and prior_path.exists() and image_path.exists()
                   and c.read(prior_path)==dict(command=command,inputs=inputs) and b.same(c.read(image_path)))
        if unchanged:print('REUSE_LINK',arm,flush=True)
        else:c.execute(arm+'-link',command,env,out)
        check()
        c.save(out/(arm+'-link-plan.json'),dict(command=command,inputs=inputs));c.save(out/(arm+'-image.json'),b.identity(image))
        plan['links'][arm]=dict(command=command,inputs=inputs,image=str(image))
    c.save(out/'plan.json',plan);c.save(out/'summary.json',dict(passed=True,host_TUs=4,native_TUs=0,SDK_rebuild=False,consumer_main_reused=True))
    print('FP8_CAST_BUILT',out,flush=True)

if __name__=='__main__':main()
