from pathlib import Path
import ast
import collections
import difflib
import hashlib
import json

ROOT = Path(__file__).resolve().parents[3]
STAGE = Path(__file__).resolve().parent


def identity(path):
    data = path.read_bytes()
    return dict(path=str(path.resolve()), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())


paths = ['src/compute_provider_torch_cuda/artifact_provider.cc',
         'src/compute_provider_native/aten_cpu_provider.cc',
         'src/compute_torch_shared/storage_cast.h',
         'tests/graph_route_cuda/fp8_cast_test.cc',
         'tests/graph_route_cuda/CMakeLists.txt']
rows, diffs = [], []
for name in paths:
    product = ROOT / name
    before = STAGE / 'before' / name
    after = STAGE / 'source' / name
    after.parent.mkdir(parents=True, exist_ok=True)
    after.write_bytes(product.read_bytes())
    rows.append(dict(product=name, before=identity(before) if before.exists() else None,
                     after=identity(after), current=identity(product)))
    diffs.extend(difflib.unified_diff(before.read_text().splitlines(True) if before.exists() else [],
                                    product.read_text().splitlines(True),
                                    fromfile='before/' + name, tofile='after/' + name))
(STAGE / 'changes.diff').write_text(''.join(diffs))

old_cpu = (STAGE / 'before/src/compute_provider_native/aten_cpu_provider.cc').read_text()
begin = old_cpu.index('at::Tensor storage_cast(')
end = old_cpu.index('\nat::Tensor activation(', begin)
original = old_cpu[begin:end].strip()
shared = (ROOT / 'src/compute_torch_shared/storage_cast.h').read_text()
new = shared[shared.index('inline at::Tensor storage_cast('):shared.index('\n} // namespace')].strip()
initial_header = STAGE / 'before-nan-sign-correction/source/src/compute_torch_shared/storage_cast.h'
initial_shared = initial_header.read_text() if initial_header.exists() else shared
initial = initial_shared[initial_shared.index('inline at::Tensor storage_cast('):initial_shared.index('\n} // namespace')].strip()
assert original == initial.removeprefix('inline ')
old_normalized = old_cpu[:begin] + old_cpu[end:]
new_cpu = (ROOT / 'src/compute_provider_native/aten_cpu_provider.cc').read_text()
assert 'result = torch_shared::storage_cast(first, native_type(p.output.data_type()));' in new_cpu

sdk = Path('C:/public/tools/hyle-dependencies/v1/sdks/torch-cuda-leaf/Windows-2bc729898e422b9f3da54349eed98f2f0b5dd415434508ee2ab2a13fb021815d/torch/include')
headers = ['c10/util/Float8_e4m3fn.h', 'c10/util/Float8_e4m3fn-inl.h',
           'c10/util/Float8_e5m2.h', 'c10/util/Float8_e5m2-inl.h',
           'c10/core/DynamicCast.h', 'c10/core/ScalarType.h',
           'ATen/native/cuda/Loops.cuh', 'ATen/native/cuda/MemoryAccess.cuh']
sdk_rows = [dict(relative=name, **identity(sdk / name)) for name in headers]
for script in [STAGE / 'prepare_source.py', STAGE / 'freeze.py']:
    ast.parse(script.read_text())
report = dict(files=rows, private_math=dict(
    initial_extraction_body_identical=True,
    original_body_sha256=hashlib.sha256(original.encode()).hexdigest(),
    current_body_sha256=hashlib.sha256(new.encode()).hexdigest(),
    current_body_identical_to_original=new.removeprefix('inline ') == original,
    correction='NaN narrowing sign now comes from original input storage bits, not arithmetic F32 widening; same helper on CPU/CUDA.',
    helper='hyle::compute::torch_shared::storage_cast',
    only_actual_header_owners=['compute_provider_native/aten_cpu_provider.cc',
                              'compute_provider_torch_cuda/artifact_provider.cc']),
    locked_torch_cuda_headers=sdk_rows,
    tests=dict(filter='CudaFp8Cast.*', cases=5,
               additional_cpu_filters='AtenCpuCast.*', cpu_cases=4),
    status='source prepared; no compilation, test execution or GPU operation performed',
    limits=['CUDA Cast requires dense plain input/output with at least one FP8 port.',
            'All transformations use original ATen kernels and managed temporaries; no external capture claim.',
            'No token/channel scaled GEMM or complete artifact/model validation.',
            'Initial CPU extraction was body-identical. Current raw-storage NaN-sign correction changes the shared body; CPU/CUDA runtime regression remains pending.'])
(STAGE / 'source-freeze.json').write_text(json.dumps(report, indent=2) + '\n')

header = json.loads((STAGE / 'model.safetensors.header.json').read_text())
tensors = {name: row for name, row in header.items() if name != '__metadata__'}
weights = {name: row for name, row in tensors.items() if row['dtype'] == 'F8_E4M3'}
roles = []
for name, row in weights.items():
    assert name.endswith('.weight'), name
    scale_name = name.removesuffix('.weight') + '.weight_scale'
    scale = tensors[scale_name]
    assert scale['dtype'] == 'BF16' and scale['shape'] == [row['shape'][0], 1]
    roles.append(dict(weight=name, dtype=row['dtype'], shape=row['shape'], offsets=row['data_offsets'],
                      scale=scale_name, scale_dtype=scale['dtype'], scale_shape=scale['shape'],
                      scale_offsets=scale['data_offsets']))
assert len(roles) == 186
facts = dict(artifact='Freesolo-Co/Qwen3.5-2B-FP8', revision='e200465690a076860468c19bec107ac54a257953',
             header=identity(STAGE / 'model.safetensors.header.json'),
             recipe=identity(STAGE / 'recipe.yaml'),
             http_receipt=identity(STAGE / 'http-receipt.json'),
             tensor_count=len(tensors), dtypes=dict(collections.Counter(row['dtype'] for row in tensors.values())),
             fp8_weight_roles=roles, application_weight_payload_bytes_read=0,
             numeric_limits=['Header/recipe identify E4M3FN per-channel BF16 scales; no weight or scale payload read.',
                             'Server ETag is publisher object metadata, not a local payload SHA.',
                             'Recipe dynamic FP8 naming does not define an exact staged channel/token GEMM numerical contract.',
                             'This implementation closes the ordinary public Cast leaf gap only. Existing block128 FP8 AOT is not a channel/token substitute.'])
(STAGE / 'artifact-header-facts.json').write_text(json.dumps(facts, indent=2) + '\n')
print(json.dumps(dict(source_freeze=identity(STAGE / 'source-freeze.json'),
                      diff=identity(STAGE / 'changes.diff'),
                      test_source=identity(ROOT / 'tests/graph_route_cuda/fp8_cast_test.cc'))))
