"""One timed consumer copy; no product edits or model math changes."""
import argparse
import importlib.util
from pathlib import Path
import sys
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent;ROOT=S.parents[2]
spec=importlib.util.spec_from_file_location('cold_probe_helpers',S.parent/'typed-gating-suffix/build.py')
h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
b,c=h.b,h.c

def main():
 p=argparse.ArgumentParser();p.add_argument('--build',action='store_true');p.add_argument('--run',action='store_true');a=p.parse_args()
 out=S/'probe';out.mkdir(parents=True,exist_ok=True);(out/'tmp').mkdir(exist_ok=True)
 base_path=S.parent/'typed-gating-suffix/checks/native1/qwen-link-plan.json';base=c.read(base_path)
 original=ROOT/'tools/qwen35_text/main.cc';text=original.read_text(encoding='utf-8');edits=[]
 def edit(old,new):
  nonlocal text
  assert text.count(old)==1,old[:120];text=text.replace(old,new,1);edits.append(dict(before=old,after=new))
 edit('    auto payload = take(mem::FileMapping::open(shard.c_str(),',
      '    const auto mapping_open_start = Clock::now();\n    double diag_allocate_seconds = 0, diag_upload_seconds = 0;\n    auto payload = take(mem::FileMapping::open(shard.c_str(),')
 edit('        mem::MappingAccess::kReadOnly));\n    std::string line;',
      '        mem::MappingAccess::kReadOnly));\n    std::cerr << "diag_mapping_open_seconds=" << std::chrono::duration<double>(Clock::now()-mapping_open_start).count() << "\\n";\n    std::string line;')
 edit('      Tensor tensor(memory.ref(), desc);\n      check(tensor.buffer.view().write(host));',
      '      auto diag_begin = Clock::now();\n      Tensor tensor(memory.ref(), desc);\n      diag_allocate_seconds += std::chrono::duration<double>(Clock::now()-diag_begin).count();\n      diag_begin = Clock::now();\n      check(tensor.buffer.view().write(host));\n      diag_upload_seconds += std::chrono::duration<double>(Clock::now()-diag_begin).count();')
 edit('    std::cerr << "weights_load_seconds=" << weight_load_seconds << \'\\n\';',
      '    std::cerr << "weights_load_seconds=" << weight_load_seconds << \'\\n\';\n    std::cerr << "diag_weight_allocate_seconds=" << diag_allocate_seconds << " diag_weight_upload_seconds=" << diag_upload_seconds << "\\n";\n    const auto state_start = Clock::now();')
 edit('  }\n\n  ~Model() {',
      '    std::cerr << "diag_state_seconds=" << std::chrono::duration<double>(Clock::now()-state_start).count() << "\\n";\n    const auto release_start = Clock::now();\n    payload = mem::FileMapping{};\n    std::cerr << "diag_mapping_release_seconds=" << std::chrono::duration<double>(Clock::now()-release_start).count() << "\\n";\n  }\n\n  ~Model() {')
 edit('    auto graph = take(std::move(r.builder).finish());',
      '    const auto build_end = Clock::now();\n    auto graph = take(std::move(r.builder).finish());\n    const auto finish_end = Clock::now();')
 edit('    phase.compiled = take(g::cuda::compile(graph, context, memory, {.constants = r.constants}));',
      '    const auto compile_begin = Clock::now();\n    phase.compiled = take(g::cuda::compile(graph, context, memory, {.constants = r.constants}));\n    const auto compile_end = Clock::now();')
 edit('    if (layer0_probe.empty() || diagnostic) for (std::size_t slot = 0; slot < 2; ++slot) {',
      '    const auto slots_begin = Clock::now();\n    if (layer0_probe.empty() || diagnostic) for (std::size_t slot = 0; slot < 2; ++slot) {')
 edit('    std::cerr << "compiled T=" << tokens << " steps="',
      '    std::cerr << "diag_phase T=" << tokens\n      << " build_seconds=" << std::chrono::duration<double>(build_end-start).count()\n      << " finish_seconds=" << std::chrono::duration<double>(finish_end-build_end).count()\n      << " compile_seconds=" << std::chrono::duration<double>(compile_end-compile_begin).count()\n      << " slots_seconds=" << std::chrono::duration<double>(Clock::now()-slots_begin).count() << "\\n";\n    std::cerr << "compiled T=" << tokens << " steps="')
 source=out/'main.cc'
 if source.exists():assert source.read_text(encoding='utf-8')==text
 else:source.write_text(text,encoding='utf-8',newline='\n')
 recipe=c.read(S.parent/'qwen-current-retest/checks/main1/qwen-main-identity.json')
 old=recipe['object'];assert any(c.key(r['path'])==c.key(old['path']) for r in base['inputs'])
 command=b.host_command(recipe['command'],source,'main',out)
 command.insert(1,'/I'+str(ROOT/'tools/qwen35_text'))
 image=out/'qwen.exe';obj=out/'main.obj'
 link_command=[str(obj) if c.key(x)==c.key(old['path']) else x for x in base['command'] if not x.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:'))]
 link_command+=['/OUT:'+str(image),'/MAP:'+str(image.with_suffix('.map')),'/IMPLIB:'+str(image.with_suffix('.lib'))]
 env,runtime=b.environment(base['command'],[r['path'] for r in base['inputs']],out)
 c.save(out/'plan.json',dict(original=b.identity(original),source=b.identity(source),edits=edits,command=command,link_command=link_command,base=b.identity(base_path),runtime=runtime,product_changes=False,math_changes=False,throughput_claim=False))
 if a.build:
  for row in base['inputs']:assert b.same(row),row['path']
  c.execute('compile',command,env,out);c.execute('link',link_command,env,out)
  inputs=[b.identity(obj) if c.key(r['path'])==c.key(old['path']) else r for r in base['inputs']]
  c.save(out/'qwen-link-plan.json',dict(command=link_command,inputs=inputs));c.save(out/'qwen-image.json',b.identity(image))
  c.save(out/'summary.json',dict(passed=True,fresh_CXX=1,native=0,SDK=0))
 if a.run:
  assert b.same(c.read(out/'qwen-image.json'))
  runner=S.parent/'typed-gating-suffix/correctness'
  run=S/'observation';run.mkdir(exist_ok=False);(run/'tmp').mkdir()
  cmd=c.read(runner/'inputs.json')['command'].copy();cmd[0]=str(image)
  cmd[cmd.index('--trace')+1]=str(run/'trace');c.execute('qwen',cmd,env,run)
  reference=runner/'trace'
  # The immediately preceding duplicate payloads were reclaimed; use the
  # retained accepted64 observations already byte-equal to this product.
  reference=S.parent/'qwen-current-retest/correctness/trace'
  wanted={p.relative_to(reference):b.identity(p) for p in reference.rglob('*') if p.suffix in ('.bf16','.f32')}
  got={p.relative_to(run/'trace'):b.identity(p) for p in (run/'trace').rglob('*') if p.suffix in ('.bf16','.f32')}
  assert len(wanted)==64 and wanted.keys()==got.keys()
  assert all(wanted[k]['sha256']==got[k]['sha256'] for k in wanted)
  lines=[line for line in (run/'qwen.stderr.log').read_text().splitlines() if line.startswith('diag_')]
  c.save(run/'summary.json',dict(passed=True,equal_vectors=64,diagnostic_lines=lines,image=b.identity(image),throughput_claim=False))
  for line in lines:print(line,flush=True)
if __name__=='__main__':main()
