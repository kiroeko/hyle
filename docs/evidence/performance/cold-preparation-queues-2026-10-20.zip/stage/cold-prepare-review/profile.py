"""One existing-recipe CUDA trace; cold API counts, never a throughput test.

Run normally once after final combined64 correctness. --analyze-only reuses
that same capture and never launches the model, profiler or any GPU work.
"""
import argparse
import collections
import csv
import importlib.util
import json
from pathlib import Path
import re
import sqlite3
import sys

sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
ARCH = S.parent
OUT = S / "profile"


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


h = load("cold_profile_existing_build_helpers", S / "build.py")
b, c = h.b, h.c
symbols = load("cold_profile_existing_symbols", ARCH / "cuda-stable-silu/profile-analysis-stable.py")


def trace(path):
    connection = sqlite3.connect("file:" + path.resolve().as_posix() + "?mode=ro", uri=True)
    connection.row_factory = sqlite3.Row
    strings = dict(connection.execute("SELECT id,value FROM StringIds"))
    tables = {r[0] for r in connection.execute("SELECT name FROM sqlite_master WHERE type='table'")}
    runtime = [dict(r, name=strings[r["nameId"]]) for r in connection.execute(
        "SELECT * FROM CUPTI_ACTIVITY_KIND_RUNTIME ORDER BY start")]
    kernels = [dict(r, name=strings[r["demangledName"]]) for r in connection.execute(
        "SELECT * FROM CUPTI_ACTIVITY_KIND_KERNEL ORDER BY start")]
    copies = [dict(r) for r in connection.execute(
        "SELECT * FROM CUPTI_ACTIVITY_KIND_MEMCPY ORDER BY start")]
    diagnostics = [dict(r) for r in connection.execute("SELECT * FROM DIAGNOSTIC_EVENT")] if "DIAGNOSTIC_EVENT" in tables else []
    streams = {}
    if "ProcessStreams" in tables:
        for row in connection.execute("SELECT * FROM ProcessStreams"):
            filename = strings[row["filenameId"]]
            if "/streams/" in filename.replace("\\", "/"):
                streams["stderr" if "stderr_" in filename else "stdout"] = strings[row["contentId"]]
    elif "ANALYSIS_FILE" in tables:
        for row in connection.execute("SELECT * FROM ANALYSIS_FILE"):
            if "/streams/" in row["filename"].replace("\\", "/"):
                streams["stderr" if "stderr_" in row["filename"] else "stdout"] = strings[row["contentId"]]
    connection.close()
    return dict(runtime=runtime, kernels=kernels, copies=copies,
                diagnostics=diagnostics, streams=streams)


def api_name(name):
    return re.sub(r"_v[0-9]+$", "", name)


def window(data, label, lo, hi):
    rows = [r for r in data["runtime"] if lo <= r["start"] and r["end"] <= hi]
    grouped = collections.defaultdict(list)
    for row in rows:
        grouped[api_name(row["name"])].append(row)
    watched = ("cudaExecutionCtxStreamCreate", "cudaStreamCreate", "cudaStreamCreateWithFlags",
               "cudaStreamDestroy", "cudaHostAlloc", "cudaFreeHost", "cudaEventCreateWithFlags",
               "cudaEventDestroy", "cudaEventSynchronize", "cudaDeviceSynchronize",
               "cudaStreamSynchronize", "cuStreamSynchronize", "cudaMalloc", "cudaFree",
               "cuMemAlloc", "cuMemFree", "cuMemcpyHtoD", "cudaMemcpyAsync",
               "cuDeviceGetAttribute", "cudaDeviceGetAttribute", "cudaGetDeviceProperties",
               "cudaFuncGetAttributes", "cudaFuncSetAttribute")
    copies = [r for r in data["copies"] if lo <= r["start"] and r["end"] <= hi]
    kernels = [r for r in data["kernels"] if lo <= r["start"] and r["end"] <= hi]
    htod = [r for r in copies if r["copyKind"] == 1]
    return dict(label=label, start_ns=lo, end_ns=hi, anchor_wall_ms=(hi-lo)/1e6,
        APIs={name: dict(calls=len(grouped[name]),
                        duration_sum_ms=sum(r["end"]-r["start"] for r in grouped[name])/1e6)
              for name in watched},
        fully_contained_runtime_calls=len(rows),
        boundary_straddling_runtime_calls=[dict(name=r["name"], start=r["start"], end=r["end"])
            for r in data["runtime"] if r["start"] < hi and r["end"] > lo and not (lo <= r["start"] and r["end"] <= hi)],
        HtoD=dict(copies=len(htod), bytes=sum(r["bytes"] for r in htod),
                  duration_sum_ms=sum(r["end"]-r["start"] for r in htod)/1e6),
        GPU_kernels=dict(count=len(kernels), duration_sum_ms=sum(r["end"]-r["start"] for r in kernels)/1e6))


def resolve_upload(data, copy):
    rows = [r for r in data["runtime"] if r["correlationId"] == copy["correlationId"]]
    preferred = [r for r in rows if "MemcpyHtoD" in r["name"]]
    if len(preferred) == 1:
        return preferred[0]
    return rows[0] if len(rows) == 1 else None


def cold(data, weight_sizes):
    runtime = data["runtime"]
    all_window = window(data, "All recorded CUDA API activity, including shutdown; not main-entry wall time",
                        min(r["start"] for r in runtime), max(r["end"] for r in runtime))
    result = dict(whole_process_API_span=all_window, cold_shape_inference_reliable=False,
                  fallback_reason=None, cold_shape_windows=[])
    htod = [r for r in data["copies"] if r["copyKind"] == 1]
    tokens = sorted((r for r in data["copies"] if r["copyKind"] == 2 and r["bytes"] == 4), key=lambda r:r["end"])
    if len(htod) < len(weight_sizes) or [r["bytes"] for r in htod[:len(weight_sizes)]] != weight_sizes:
        result["fallback_reason"] = "First ordered HtoD copy sizes do not exactly match the320-tensor weight inventory; no guessed last-weight or per-shape boundary."
        return result
    first_weight, last_weight = resolve_upload(data, htod[0]), resolve_upload(data, htod[len(weight_sizes)-1])
    first_token = resolve_upload(data, tokens[0]) if tokens else None
    if not first_weight or not last_weight or not first_token:
        result["fallback_reason"] = "A weight/token copy has no unique correlated runtime upload API; keep full-process counts only."
        return result
    result["weights"] = window(data, "Exact320 weight upload API boundaries", first_weight["start"], last_weight["end"])
    result["last_weight_through_first_token"] = window(data,
        "Last weight upload end through first synchronous host token read; includes state, both prepares and prefill",
        last_weight["end"], first_token["end"])
    post = htod[len(weight_sizes):]
    result["postweight_HtoD"] = dict(copies=len(post), bytes=sum(r["bytes"] for r in post),
                                     largest_bytes=max((r["bytes"] for r in post), default=0))
    literals = [r for r in post if r["bytes"] == 128 and r["end"] <= tokens[0]["end"]]
    if len(literals) != 2:
        result["fallback_reason"] = "Expected exactly two128B cold RoPE literal uploads before first token; keep whole-process and last-weight-to-first-token counts."
        return result
    later = [r for r in post if r["bytes"] == 512 and r["start"] > literals[1]["end"]]
    anchors = [resolve_upload(data, r) for r in literals + later[:1]]
    if len(anchors) != 3 or any(r is None for r in anchors):
        result["fallback_reason"] = "No unique correlated first-prefill512B token upload anchor; no inferred per-shape split."
        return result
    lo, split, hi = (r["start"] for r in anchors)
    if not (last_weight["end"] < lo < split < hi < first_token["end"]):
        result["fallback_reason"] = "Cold anchors are not ordered inside startup; use broad fallback windows."
        return result
    windows = [window(data, "T128 first literal API through T1 first literal API", lo, split),
               window(data, "T1 first literal API through first prefill token upload API", split, hi)]
    kernel_keys = ("name", "gridX", "gridY", "gridZ", "blockX", "blockY", "blockZ")
    signatures = [[tuple(r[k] for k in kernel_keys) for r in data["kernels"] if a <= r["start"] and r["end"] <= z]
                  for a,z in ((lo,split),(split,hi))]
    copy_sequences = [[r["bytes"] for r in htod if a <= r["start"] and r["end"] <= z]
                      for a,z in ((lo,split),(split,hi))]
    checks = dict(each194cold_kernels=all(len(x)==194 for x in signatures),
                  ordered_symbol_grid_block_equal=signatures[0]==signatures[1],
                  each170small_HtoD=all(len(x)==170 for x in copy_sequences),
                  each732small_HtoD_bytes=all(sum(x)==732 for x in copy_sequences),
                  ordered_small_HtoD_sizes_equal=copy_sequences[0]==copy_sequences[1])
    result["anchor_validation"] = checks
    result["candidate_anchor_ns"] = dict(T128_literal=lo,T1_literal=split,prefill_upload=hi)
    if not all(checks.values()):
        result["fallback_reason"] = "Cold194kernel/170HtoD sequence validation differs; do not force182->2. Broad windows remain usable."
        return result
    result.update(cold_shape_inference_reliable=True, cold_shape_windows=windows,
                  prefill_input_through_first_token=window(data,
                      "First prefill input upload through first synchronous host token read", hi, first_token["end"]))
    return result


def summarize_kernels(rows):
    casts = collections.Counter()
    typed = 0
    for row in rows:
        args = symbols.template_arguments(row["name"], "cpy_scalar_contiguous")
        if len(args) == 2:
            casts[symbols.dtype(args[0])+"->"+symbols.dtype(args[1])] += 1
        args = symbols.template_arguments(row["name"], "unary_gated_op_kernel")
        if len(args) == 6 and [symbols.dtype(args[i]) for i in (1,3,4,5)] == ["bf16","f32","bf16","f32"]:
            typed += 1
    return dict(kernels=len(rows), casts=dict(casts), typed_stable_gating=typed)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--analyze-only", action="store_true")
    args = parser.parse_args()
    combined = ARCH / "quant-route-followup/checks/host1"
    image = c.read(combined / "qwen-image.json")
    link_path = combined / "qwen-link-plan.json"
    link = c.read(link_path)
    assert b.same(image), "Final combined Qwen image changed"
    correctness = c.read(S / "correctness/summary.json")["observation"]
    assert correctness["equal_vectors"] == 64
    assert correctness["image"]["sha256"] == image["sha256"], "cold correctness64 is not the final combined image"
    previous_plan = c.read(ARCH / "typed-gating-suffix/profile/plan.json")
    command = previous_plan["consumer_command"].copy()
    command[0] = image["path"]
    assert "--trace" not in command
    manifest = Path(command[command.index("--inputs")+1]) / "weights.tsv"
    weight_sizes = [int(line.split()[-1]) for line in manifest.read_text().splitlines()[3:] if line.strip()]
    assert len(weight_sizes) == 320 and sum(weight_sizes) == 3763655360
    baseline_sql = ARCH / "typed-gating-suffix/profile/capture.sqlite"
    stem = OUT / "capture"
    if not args.analyze_only:
        OUT.mkdir(exist_ok=False)
        (OUT / "tmp").mkdir()
        env, runtime = b.environment(link["command"], [r["path"] for r in link["inputs"]], OUT)
        nsys = previous_plan["commands"]["profile"][0]
        commands = dict(profile=[nsys,"profile","--trace=cuda","--sample=none","--cpuctxsw=none",
            "--cuda-trace-all-apis=true","--cuda-graph-trace=node:host-only","--discard-environment=true",
            "--output="+str(stem),*command],
            export=[nsys,"export","--type=sqlite","--output="+str(stem)+".sqlite",str(stem)+".nsys-rep"],
            stats=[nsys,"stats","--report=cuda_gpu_kern_sum","--format=csv","--output="+str(stem),str(stem)+".sqlite"])
        c.save(OUT/"plan.json",dict(image=image,link=b.identity(link_path),commands=commands,
            consumer_command=command,runtime=runtime,profiler=True,throughput_claim=False,
            baseline_SQLite=b.identity(baseline_sql),correctness=b.identity(S/"correctness/summary.json"),
            fixed=previous_plan["fixed"],script=b.identity(Path(__file__))))
        for tag, argv in commands.items():
            c.execute(tag, argv, env, OUT)
    current = trace(stem.with_suffix(".sqlite"))
    baseline = trace(baseline_sql)
    official = collections.Counter()
    with (OUT/"capture_cuda_gpu_kern_sum.csv").open(encoding="utf-8-sig",newline="") as stream:
        for row in csv.DictReader(stream): official[row["Name"]] += int(row["Instances"].replace(",", ""))
    assert official == collections.Counter(r["name"] for r in current["kernels"])
    tokens = sorted((r for r in current["copies"] if r["copyKind"]==2 and r["bytes"]==4),key=lambda r:r["end"])
    assert len(tokens) == 32, "Expected actual prefill plus31decode host-token endpoints"
    phases = []
    for index in range(1,32):
        lo,hi = tokens[index-1]["end"],tokens[index]["end"]
        rows = [r for r in current["kernels"] if lo < r["start"] and r["end"] <= hi]
        assert not any(r["start"] < hi and r["end"] > lo and not (lo < r["start"] and r["end"] <= hi) for r in current["kernels"])
        phases.append(dict(index=index,**summarize_kernels(rows)))
    warm = phases[6:]
    assert len(warm)==25 and all(r["kernels"]==614 and r["typed_stable_gating"]==18 for r in warm)
    for kind,value in current["streams"].items():
        (OUT/("target."+kind+".log")).write_text(value,encoding="utf-8")
    targets = [json.loads(line) for line in current["streams"].get("stdout", "").splitlines()
               if line.startswith("{") and "generated_ids" in line]
    assert len(targets)==1 and targets[0]["generated_ids"]==correctness["generated_ids"]
    assert targets[0]["decode_input_ids"]==previous_plan["fixed"]["decode_input_ids"]
    before,after = cold(baseline,weight_sizes),cold(current,weight_sizes)
    comparison = []
    if before["cold_shape_inference_reliable"] and after["cold_shape_inference_reliable"]:
        for old,new in zip(before["cold_shape_windows"],after["cold_shape_windows"]):
            comparison.append(dict(shape="T128" if not comparison else "T1",
                API_counts={name:dict(before=old["APIs"][name]["calls"],after=row["calls"])
                            for name,row in new["APIs"].items()}))
    c.save(OUT/"diagnostics.json",current["diagnostics"])
    c.save(OUT/"summary.json",dict(passed=True,decode7=warm[0],warm_phases=warm,
        token_DtoH_anchors=32,official_CSV_SQLite_symbol_counts_equal=True,
        target_predictions_and_fixed_tape_equal=True,baseline=before,current=after,
        matched_semantic_cold_count_comparison=comparison,
        diagnostic_severity_ge_2=[r for r in current["diagnostics"] if r["severity"]>=2],
        throughput_claim=False,
        limits=["One new software-instrumented process versus a retained earlier trace; structural counts, not matched timing or CPU sampling.",
                "API sums may nest/overlap and cannot be subtracted from wall time as recovered startup time.",
                "Per-shape cold API windows are used only after exact194kernel/170HtoD semantic checks; otherwise use full-process and last-weight-to-first-token windows.",
                "Keep driver compatibility warnings. Mapping release remains in model/ready/TTFT; this script does not relocate close.",
                "No independent model-quality or peak-memory acceptance; cold correctness64 remains the numerical regression evidence."]))
    print("COLD_PREPARE_PROFILE_ANALYZED", "precise_cold_windows="+str(bool(comparison)), flush=True)


if __name__ == "__main__":
    main()
