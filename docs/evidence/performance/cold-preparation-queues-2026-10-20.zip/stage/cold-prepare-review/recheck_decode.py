"""One bounded B/C/C/B followup for the non-overlapping decode samples; no compilation/profiler."""
import importlib.util
from pathlib import Path
import statistics
import sys
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('cold_decode_followup',S/'compare.py')
h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
r=h.r.rotation.r;b,c=r.b,r.c
plan=c.read(S/'performance-prepared/plan.json');out=S/'decode-followup';out.mkdir(exist_ok=False);(out/'tmp').mkdir()
for row in plan['frozen']+list(plan['images'].values()):r.require_same(row)
build=c.read(plan['build_plan']['path']);env,runtime=r.runtime_environment(build,c.read(r.PEER_PLAN),out)
requests={arm:next(x for x in plan['requests'] if x['arm']==arm) for arm in ('baseline','current')}
c.save(out/'inputs.json',dict(images=plan['images'],order=['baseline','current','current','baseline'],
    runtime=runtime,reason='First9-process window current warm range did not overlap old; investigate, do not replace or pool the first window.',
    profiler=False,compilation=False,external_monitor=False))
runs=[]
for i,arm in enumerate(['baseline','current','current','baseline'],1):
    request={**requests[arm],'tag':f'{i:02d}-{arm}'}
    for row in plan['images'].values():r.require_same(row)
    process=r.execute(request['tag'],request['command'],env,out)
    observed=r.hyle_result(out,request,plan)
    runs.append(dict(arm=arm,tag=request['tag'],pid=process['pid'],exit=process['exit'],**observed))
    c.save(out/'runs.json',runs)
groups={arm:{key:dict(samples=[x['metrics'][key] for x in runs if x['arm']==arm],
    median=statistics.median(x['metrics'][key] for x in runs if x['arm']==arm)) for key in r.COMMON_METRICS}
    for arm in ('baseline','current')}
c.save(out/'summary.json',dict(completed=True,processes=4,groups=groups,
    same_predictions=all(x['same_baseline_predictions'] for x in runs),
    current_over_baseline={key:groups['current'][key]['median']/groups['baseline'][key]['median'] for key in r.COMMON_METRICS},
    limits='Two processes per image, one post-profile B/C/C/B window. Keep separate from original9; no statistical or clock-normalized causality claim.'))
print('DECODE_FOLLOWUP_COMPLETE',flush=True)
