"""Publish this batch's actual source, failures, diagnostics and final runtime evidence."""
import datetime as dt
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import sys
import zipfile
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent; A=S.parent; ROOT=S.parents[2]
spec=importlib.util.spec_from_file_location('cold_prepare_publish',S/'build.py')
h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
b,c=h.b,h.c
Q=A/'quant-route-followup'; P=A/'paired-small-projection'
queue_tests=c.read(S/'tests-final/summary.json')
fp8_tests=c.read(Q/'tests-complete/summary.json')
numeric=c.read(S/'correctness/summary.json');profile=c.read(S/'profile/summary.json')
rotation=c.read(S/'performance-rotation/summary.json')
assert queue_tests['passed'] and queue_tests['cases']==16 and queue_tests['skipped']==0
assert fp8_tests['passed'] and sum(r['cases'] for r in fp8_tests['arms'].values())==9
assert numeric['passed'] and numeric['observation']['equal_vectors']==64
assert profile['passed'] and rotation['terminal_zero']==9 and rotation['same_baseline_predictions_all9']
build=Q/'checks/host1'
assert c.read(build/'summary.json')['passed']
for row in c.read(build/'plan.json')['frozen']:assert b.same(row),row['path']
for arm in ('cpu','tests','qwen'):
    assert b.same(c.read(build/(arm+'-image.json')))
    for row in c.read(build/(arm+'-link-plan.json'))['inputs']:assert b.same(row),row['path']
names=['src/graph/constant_artifact.h','src/graph/constant_artifact.cc','tests/graph/constant_artifact_cache_test.cc',
       'src/compute_provider_native/aten_cpu_provider.cc','src/compute_provider_torch_cuda/artifact_provider.cc',
       'src/compute_torch_shared/storage_cast.h','tests/graph_route_cuda/fp8_cast_test.cc','tests/graph_route_cuda/CMakeLists.txt',
       'docs/architecture/compute-design.md','docs/developer/current-work.md','docs/implementation/model-operators.md',
       'docs/evidence/performance/qwen35-full-cuda-2026-10-19/README.md']
c.execute('diff-check',['git','diff','--check','--',*names],dict(os.environ),S)
zone=dt.timezone(dt.timedelta(hours=8))
first=c.read(S/'performance-rotation/01-baseline.result.json');last=c.read(S/'performance-rotation/09-baseline.result.json')
window=dict(start=dt.datetime.fromtimestamp(first['started'],zone).isoformat(),end=dt.datetime.fromtimestamp(last['finished'],zone).isoformat())
cold=dict(date_utc=dt.datetime.now(dt.timezone.utc).isoformat(),
    result='Compile/family-local constant preparation reuses original retired Queue owners by actual Context endpoint. Every artifact retains its own original sequence/Completion observation and transactional publication.',
    queue_source=c.read(S/'queue-reuse/source-freeze.json'),review=c.read(S/'queue-reuse/independent-review.json'),
    diagnostic=c.read(S/'observation/summary.json'),baseline_attribution=c.read(S/'initial-review.json'),
    cold_mapping_limit='One diagnostic copy measured372.975ms at the original mapping-release point. No flush exists in FileMapping::reset; this is not proof of an Hyle OS-unmap bug or removable wall time. Cleanup has not been deferred outside TTFT.',
    tests=queue_tests,full_model=numeric,physical=profile,
    performance=dict(window_beijing=window,rotation=rotation,decode_followup=c.read(S/'decode-followup/summary.json'),
        followup_analysis=c.read(S/'perf-followup.json'),statistical_significance=False,
        boundary='Same original BF16 Hyle consumer and inputs; peer intermediate math and load/prepare sub-boundaries still differ. API-duration sums are not wall-time savings.'),
    small_projection_experiment=dict(summary=c.read(P/'timing/summary.json'),product_changes=False,
        limits='18 actual weight pairs with fixed normal activations,576 BF16 outputs. Only2.25MiB weights versus36MiB L2. Native captured microchunk has no whole Graph/Completion overhead. Not an end-to-end throughput claim.'),
    build=dict(queue_product_CXX=2,queue_test_CXX=1,fp8_product_CXX=2,fp8_test_CXX=2,native=0,SDK=0,
        probe_CXX=1,small_projection_NVCC=1,main_object_reused_for_final=True,
        final_images={arm:c.read(build/(arm+'-image.json')) for arm in ('cpu','tests','qwen')}),
    first_failures='Initial new queue fixtures lacked native-source capability; subsequent strict C4458 failures were corrected in the fixture. FP8 fixture explicit Operation/resource mistakes and negative signalling-NaN runtime failure are preserved. None are represented as passes.',
    remaining='Generic small-projection product integration, selected quantized GEMM/FFN routes, other model/profile/platform journeys and startup loader/resource work remain. No architecture/MTP/mmproj completion or new peak-memory acceptance.')
fp8=dict(date_utc=cold['date_utc'],
    result='Dense public CUDA Cast to/from E4M3FN/E5M2 uses shared ATen storage semantics with CPU; raw source storage chooses NaN sign because CUDA Half->F32 may canonicalize a negative signalling NaN.',
    source=c.read(Q/'source-freeze.json'),review=c.read(Q/'independent-review.json'),test_review=c.read(Q/'tests-independent-review.json'),
    tests=fp8_tests,artifact_header=c.read(Q/'artifact-header-facts.json'),
    contract='RNE and finite FP8 saturation; E5 preserves true infinity; declared F32 widening NaN payload and narrow NaN sign; same-type out-of-place copies preserve storage codes. Empty operations are no-ops; scalar works. Public range/alias validation stays in the existing core.',
    execution='Existing original ATen CUDA kernels and Invocation result lifetime, managed and not capture-compatible, with unknown provider-private workspace. Non-dense storage is declined. No new public operation, executor, native kernel, SDK or model-name switch.',
    full_model=c.read(S/'correctness/summary.json'),
    limits='The BF16 Qwen does not use this FP8 route. Header-only selected CT artifact facts do not prove its payload or whole-model execution. BF16 per-channel weight scales and dynamic per-token activation GEMM remain unsupported by the block128 carrier; Cast is not scaled GEMM.',
    failures_retained=True,quality_acceptance=False,platform_matrix=False)
files={}; allowed={'.py','.cc','.h','.cu','.cuh','.json','.diff','.log','.txt','.xml','.tsv','.csv','.sqlite','.nsys-rep','.ps1'}
for stage in (S,Q,P):
    for path in stage.rglob('*'):
        if not path.is_file() or path.suffix not in allowed:continue
        rel=path.relative_to(stage)
        if any(p in ('tmp','__pycache__') for p in rel.parts):continue
        if len(rel.parts)==1 and path.name in ('summary.json','archive-manifest.json','publication.json','cleanup-plan.json','cleanup-receipt.json'):continue
        files['stage/'+stage.name+'/'+rel.as_posix()]=path
for name in names:files['product/'+name]=ROOT/name
manifest=[]
for name,path in sorted(files.items()):
    data=path.read_bytes();manifest.append(dict(name=name,bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
public=ROOT/'docs/evidence/performance';archive=public/'cold-preparation-queues-2026-10-20.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for name,path in sorted(files.items()):z.write(path,name)
    z.writestr('archive-manifest.json',json.dumps(manifest,indent=2)+'\n')
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for row in manifest:
        data=z.read(row['name']);assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256']
receipt=dict(**b.identity(archive),payloads=len(manifest),crc_verified=True,payload_sha256_verified=True)
cold['archive']=fp8['archive']=receipt
cold_path=archive.with_suffix('.json');fp8_path=ROOT/'docs/evidence/correctness/cuda-fp8-storage-cast-2026-10-20.json'
c.save(cold_path,cold);c.save(fp8_path,fp8);c.save(S/'summary.json',cold);c.save(Q/'summary.json',fp8)
c.save(S/'archive-manifest.json',manifest);c.save(S/'publication.json',dict(cold_report=b.identity(cold_path),fp8_report=b.identity(fp8_path),archive=receipt))
print('COLD_AND_FP8_PUBLISHED',receipt['bytes'],len(manifest),flush=True)
