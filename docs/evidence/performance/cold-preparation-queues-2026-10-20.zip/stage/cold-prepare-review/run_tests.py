"""Relevant constant/factory/retirement regressions only."""
import importlib.util
from pathlib import Path
import xml.etree.ElementTree as ET
import sys
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('cold_queue_tests',S/'build.py')
h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
b,c=h.b,h.c
out=S/'tests-final';out.mkdir(exist_ok=False);(out/'tmp').mkdir()
build=S/'checks/queue1';image=c.read(build/'cpu-image.json');assert b.same(image)
link=c.read(build/'cpu-link-plan.json')
filters=['CanonicalConstantCache.*','ConstantArtifactCache.*','StorageOwner.*',
 'GraphPacking.UnknownPreparationObservationRetainsOwnersUntilNativeRetirement',
 'GraphPacking.ExactVariantsShareWeightsAndSurviveParentAndSource',
 'GraphPacking.BoundsAndPartialFactoryFailuresAreTransactional',
 'GraphPacking.EveryMetadataAllocationFailureReleasesPackingAndCanRetry']
env,runtime=b.environment(link['command'],[r['path'] for r in link['inputs']],out)
c.save(out/'inputs.json',dict(image=image,filters=filters,runtime=runtime,expected_cases=16))
try:c.execute('tests',[image['path'],'--gtest_filter='+':'.join(filters),'--gtest_output=xml:'+str(out/'results.xml')],env,out)
finally:
 cases=ET.parse(out/'results.xml').findall('.//testcase') if (out/'results.xml').exists() else []
 failures=[dict(name=r.attrib['classname']+'.'+r.attrib['name'],details=[f.text for f in r.findall('failure')]) for r in cases if r.find('failure') is not None]
 skipped=sum(r.find('skipped') is not None for r in cases)
 passed=len(cases)==16 and not failures and not skipped
 c.save(out/'summary.json',dict(passed=passed,cases=len(cases),skipped=skipped,failures=failures,image=image,
    actual=[r.attrib['classname']+'.'+r.attrib['name'] for r in cases]))
assert passed
print('COLD_QUEUE_TESTS',len(cases),'passed',flush=True)
