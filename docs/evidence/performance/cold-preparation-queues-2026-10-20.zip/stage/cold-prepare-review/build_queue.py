"""Refresh the private cache definition, its only product stack owner and fixture."""
import argparse
import concurrent.futures
import importlib.util
from pathlib import Path
import sys
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent;ROOT=S.parents[2]
spec=importlib.util.spec_from_file_location('cold_queue_build',S.parent/'typed-gating-suffix/build.py')
h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
b,c=h.b,h.c
def main():
 p=argparse.ArgumentParser();p.add_argument('--build',action='store_true');p.add_argument('--resume',action='store_true');a=p.parse_args()
 out=S/'checks/queue1';out.mkdir(parents=True,exist_ok=True);(out/'tmp').mkdir(exist_ok=True)
 lease=Path(c.read(S.parent/'lease-read-filter/latest-plan.json')['plan']).parent
 paths=dict(cpu=lease/'cpu-link-plan.json',qwen=S.parent/'typed-gating-suffix/checks/native1/qwen-link-plan.json')
 bases={arm:c.read(path) for arm,path in paths.items()};meta=h.h.metadata(bases)
 owners={arm:{Path(meta[c.key(row['path'])]['source_path']).name:dict(meta[c.key(row['path'])],old_object=row)
    for row in base['inputs'] if c.key(row['path']) in meta} for arm,base in bases.items()}
 rows=[]
 for name in ('constant_artifact.cc','executable.cc'):
  owner=owners['qwen'][name];source=Path(owner['source_path']);tag=source.stem
  rows.append(dict(tag=tag,source=b.identity(source),source_name=name,object=str(out/(tag+'.obj')),
    command=b.host_command(owner['command'],source,tag,out)))
 source=ROOT/'tests/graph/constant_artifact_cache_test.cc';tag='constant-cache-test'
 recipe=c.read(lease/'region-test-identity.json')['command']
 rows.append(dict(tag=tag,source=b.identity(source),object=str(out/(tag+'.obj')),
   command=b.host_command(recipe,source,tag,out)))
 freeze_path=S/'queue-reuse/source-freeze.json';freeze=c.read(freeze_path)
 frozen=[b.identity(freeze_path)]
 for row in freeze['files']:
  assert b.same(row['after']) and b.same(row['snapshot']);frozen.extend((row['after'],row['snapshot']))
 frozen.extend(row['source'] for row in rows)
 plan=dict(compile=rows,frozen=frozen,links={},CXX=3,native=0,SDK=0,
   refresh_reason='Definition and sole by-value product owner; other PlanState consumers do not instantiate/copy this private Cache')
 c.save(out/'plan.json',plan);c.save(S/'latest-queue-plan.json',dict(plan=str(out/'plan.json')))
 if not a.build:print('QUEUE_BUILD_PLAN',len(rows));return
 def check():
  for row in frozen:assert b.same(row),row['path']
 for base in bases.values():
  for row in base['inputs']:assert b.same(row),row['path']
 env,runtime=b.environment(bases['qwen']['command'],[r['path'] for r in bases['qwen']['inputs']],out)
 c.save(out/'runtime.json',dict(runtime=runtime,PATH=env['PATH']))
 def compile_one(row):
  receipt_path=out/(row['tag']+'-identity.json');check()
  if a.resume and receipt_path.exists():
   old=c.read(receipt_path)
   if old['command']==row['command'] and b.same(old['object']) and all(b.same(d) for d in old['dependencies']):
    print('REUSE',row['tag'],flush=True);return row['tag'],old
  c.execute(row['tag']+'-compile',row['command'],env,out);check()
  d=c.read(out/(row['tag']+'-deps.json'))['Data']
  result=dict(command=row['command'],source=row['source'],object=b.identity(row['object']),
      dependencies=[b.identity(p) for p in dict.fromkeys([d['Source'],*d['Includes']])])
  c.save(receipt_path,result);return row['tag'],result
 finished={};errors=[]
 with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
  for future in concurrent.futures.as_completed([pool.submit(compile_one,row) for row in rows]):
   try:
    tag,r=future.result();finished[tag]=r
   except Exception as error:errors.append(repr(error))
 c.save(out/'compile-summary.json',dict(passed=not errors,errors=errors))
 if errors:raise RuntimeError(errors)
 for arm,base in bases.items():
  replace={c.key(owners[arm][row['source_name']]['old_object']['path']):finished[row['tag']]['object'] for row in rows if 'source_name' in row}
  lookup={c.key(r['path']):r for r in base['inputs']};lookup.update({c.key(r['path']):r for r in replace.values()})
  cmd=[replace.get(c.key(arg),{}).get('path',arg) for arg in base['command'] if not arg.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:'))]
  if arm=='cpu':
   # This focused CPU closure does not previously carry the cache fixture.
   assert 'constant_artifact_cache_test.cc' not in owners['cpu']
   obj=finished['constant-cache-test']['object'];cmd.insert(1,obj['path']);lookup[c.key(obj['path'])]=obj
  image=out/(arm+'.exe');cmd+=['/OUT:'+str(image),'/MAP:'+str(image.with_suffix('.map')),'/IMPLIB:'+str(image.with_suffix('.lib'))]
  inputs=[lookup[c.key(arg)] for arg in cmd if Path(arg).is_absolute() and Path(arg).suffix.lower() in ('.obj','.lib')]
  assert len(inputs)==len(set(c.key(r['path']) for r in inputs))
  for row in inputs:assert b.same(row),row['path']
  check();c.execute(arm+'-link',cmd,env,out);check()
  c.save(out/(arm+'-link-plan.json'),dict(command=cmd,inputs=inputs));c.save(out/(arm+'-image.json'),b.identity(image))
  plan['links'][arm]=dict(command=cmd,inputs=inputs,image=str(image))
 c.save(out/'plan.json',plan);c.save(out/'summary.json',dict(passed=True,CXX=3,native=0,SDK=0,main_reused=True))
 print('QUEUE_BUILT',out,flush=True)
if __name__=='__main__':main()
