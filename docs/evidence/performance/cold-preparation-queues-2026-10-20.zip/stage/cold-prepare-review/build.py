import importlib.util
from pathlib import Path
spec=importlib.util.spec_from_file_location('cold_queue_increment',Path(__file__).with_name('build_queue.py'))
h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
b,c=h.b,h.c
if __name__=='__main__':h.main()
