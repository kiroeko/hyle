"""One interleaved unprofiled old/current/peer window after the combined64-vector check."""
import argparse
import importlib.util
from pathlib import Path
import sys
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('cold_prepare_rotation',S.parent/'qwen-current-retest/compare.py')
r=importlib.util.module_from_spec(spec);spec.loader.exec_module(r)
r.S=r.rotation.STAGE=S;r.r.PREPARED=S/'performance-prepared'
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--run',action='store_true');a=p.parse_args()
    if a.run:r.rotation.run(r.r.PREPARED/'plan.json',S/'performance-rotation')
    else:
        old=S.parent/'typed-gating-suffix/checks/native1'
        image=r.c.read(old/'qwen-image.json');assert r.b.same(image)
        peer=r.c.read(S.parent/'qwen-current-retest/retest-plan.json')['retained_llama_image']
        r.c.save(S/'retest-plan.json',dict(retained_old_image=image,retained_llama_image=peer))
        r.prepare(S.parent/'quant-route-followup/checks/host1/plan.json')
        plan=r.c.read(r.r.PREPARED/'plan.json')
        plan['baseline']='Immediately preceding typed-gating-suffix v31 BF16 main, weights and math. Current changes compile-local preparation queue reuse and adds an unused-in-this-model FP8 Cast route.'
        plan['frozen'].append(r.b.identity(Path(__file__)));r.c.save(r.r.PREPARED/'plan.json',plan)
