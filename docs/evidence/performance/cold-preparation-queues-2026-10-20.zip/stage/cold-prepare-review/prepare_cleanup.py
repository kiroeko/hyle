"""Write the user's root test.ps1 with exact, hashed, rebuildable targets; do not delete."""
import hashlib
import importlib.util
import json
from pathlib import Path
import shutil
import sys
import zipfile
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent;A=S.parent;ROOT=S.parents[2]
spec=importlib.util.spec_from_file_location('cold_prepare_reclaim',S/'build.py')
h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
b,c=h.b,h.c
public=ROOT/'docs/evidence/performance/cold-preparation-queues-2026-10-20.json'
report=c.read(public);archive=report['archive'];assert b.same(archive)
with zipfile.ZipFile(archive['path']) as z:
    assert z.testzip() is None
    for row in json.loads(z.read('archive-manifest.json')):
        data=z.read(row['name']);assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256']
protected={}
for folder,arms in [(A/'quant-route-followup/checks/host1',('cpu','tests','qwen')),
                    (A/'typed-gating-suffix/checks/native1',('qwen',))]:
    for arm in arms:
        image=c.read(folder/(arm+'-image.json'));assert b.same(image);protected[c.key(image['path'])]=image
        for row in c.read(folder/(arm+'-link-plan.json'))['inputs']:
            assert b.same(row);protected[c.key(row['path'])]=row
peer=c.read(A/'qwen-current-retest/retest-plan.json')['retained_llama_image'];assert b.same(peer);protected[c.key(peer['path'])]=peer
targets=[]
for folder,names in [(S/'probe',('qwen',)),(S/'checks/queue1',('cpu','qwen')),
                     (A/'paired-small-projection/build',('bench',)),(A/'typed-gating-suffix/checks/native1',('tests',))]:
    for name in names:
        for suffix in ('.exe','.map','.lib','.exp'):
            path=folder/(name+suffix)
            if not path.is_file():continue
            assert c.key(path) not in protected,str(path)
            targets.append(dict(**b.identity(path),reason='Superseded diagnostic/microbenchmark/test image or image sidecar; all actual object/library inputs retained'))
reference=A/'batch-graph-capture/correctness-final/trace'
for folder in (S/'observation/trace',S/'correctness/trace'):
    for path in sorted(folder.rglob('*')):
        if not path.is_file() or path.suffix not in ('.f32','.bf16'):continue
        keep=reference/path.relative_to(folder);observed=b.identity(path);retained=b.identity(keep)
        assert observed['bytes']==retained['bytes'] and observed['sha256']==retained['sha256']
        protected[c.key(keep)]=retained
        targets.append(dict(**observed,reason='Byte-identical duplicate of retained accepted64 model observation',retained=retained))
assert len({c.key(r['path']) for r in targets})==len(targets)
for row in targets:
    path=Path(row['path']).resolve();assert path.is_relative_to(ROOT) and path!=ROOT
    assert path.suffix not in ('.obj',),str(path)
plan=dict(targets=targets,files=len(targets),bytes=sum(r['bytes'] for r in targets),archive=archive,
          protected=list(protected.values()),executed=False)
plan_path=S/'cleanup-plan.json';c.save(plan_path,plan)
prior=ROOT/'test.ps1';saved=S/'test-before-cold-reclaim.ps1'
if prior.exists():
    assert not saved.exists();shutil.copyfile(prior,saved)
script="""# Exact rebuildable targets for the completed cold preparation / FP8 batch.
# This script is single-use. Read cleanup-plan.json for every target and retained owner.
$ErrorActionPreference = 'Stop'
$taskRoot = (Resolve-Path -LiteralPath $PSScriptRoot).Path
$taskPlan = Get-Content -LiteralPath '__PLAN__' -Encoding utf8 -Raw | ConvertFrom-Json
foreach ($taskTarget in $taskPlan.targets) {
  $taskResolved = (Resolve-Path -LiteralPath $taskTarget.path).Path
  if (-not $taskResolved.StartsWith($taskRoot + [IO.Path]::DirectorySeparatorChar, [StringComparison]::OrdinalIgnoreCase)) { throw 'Target escapes repository' }
  $taskFile = Get-Item -LiteralPath $taskResolved
  if ($taskFile.PSIsContainer -or $taskFile.Length -ne $taskTarget.bytes) { throw ('Target identity differs: ' + $taskResolved) }
  if ((Get-FileHash -LiteralPath $taskResolved -Algorithm SHA256).Hash.ToLowerInvariant() -ne $taskTarget.sha256) { throw ('Target hash differs: ' + $taskResolved) }
}
foreach ($taskProtected in $taskPlan.protected) {
  $taskKeep = Get-Item -LiteralPath $taskProtected.path
  if ($taskKeep.Length -ne $taskProtected.bytes -or (Get-FileHash -LiteralPath $taskProtected.path -Algorithm SHA256).Hash.ToLowerInvariant() -ne $taskProtected.sha256) { throw ('Retained input differs: ' + $taskProtected.path) }
}
foreach ($taskTarget in $taskPlan.targets) { Remove-Item -LiteralPath $taskTarget.path -Force }
[pscustomobject]@{executed=$true; files=$taskPlan.files; bytes=$taskPlan.bytes; finished_utc=[DateTime]::UtcNow.ToString('O'); targets=$taskPlan.targets} |
  ConvertTo-Json -Depth 8 | Set-Content -LiteralPath '__RECEIPT__' -Encoding utf8
Write-Output ('RECLAIMED ' + $taskPlan.files + ' files, ' + $taskPlan.bytes + ' bytes')
""".replace('__PLAN__',str(plan_path)).replace('__RECEIPT__',str(S/'cleanup-receipt.json'))
prior.write_text(script,encoding='utf-8');(S/'prepared-reclaim.ps1').write_text(script,encoding='utf-8')
print('EXACT_RECLAIM_PREPARED',len(targets),plan['bytes'],flush=True)
