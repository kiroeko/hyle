"""Physical-batch accounting from the completed timing window; no native execution."""
from pathlib import Path
from collections import defaultdict
from statistics import median
import json
import re

ROOT = Path(__file__).resolve().parents[3]
TIMING = ROOT / ".scratch/qwen-cli-batch-20261022/performance/timing"
OUTPUT = Path(__file__).with_name("host-cost-review.json")


def read(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def labels(session):
    return [phase["name"] + (str(i + 1) if phase["kind"] == "decode" else "")
            for phase in session["phases"]
            for i in range(phase["input_tokens"] if phase["kind"] == "decode" else 1)]


def logs(path):
    current, prepared, entries = None, None, {}
    for line in path.read_text(encoding="utf-8").splitlines():
        if line.startswith("session_steps id="):
            current = line.split("=", 1)[1]
        elif line.startswith("prepared "):
            prepared = dict(re.findall(r"(\w+)=([^ ]+)", line))
        elif re.match(r"round\d+_(?:prefill|decode\d+) ", line):
            name = line.split()[0]
            assert current and prepared and (current, name) not in entries
            step = dict(re.findall(r"(\w+)=([^ ]+)", line))
            entries[(current, name)] = {
                "cold": float(prepared["cold_batch_seconds"]),
                "model_span": float(step["seconds"]), "submit": float(step["submit_seconds"]),
                "member_step": float(step["step_seconds"]),
                "recorded": int(prepared["capture_recorded"]),
                "reused": int(prepared["capture_reused"]), "route": prepared["replay"]}
            prepared = None
    return entries


def summary(records, waves, kind, turn=None):
    chosen = [r for r in records if r["kind"] == kind and (turn is None or r["turn"] == turn)]
    selected_waves = [w for w in waves if w["kind"] == kind and (turn is None or w["turn"] == turn)]
    assert chosen
    total = lambda key: sum(r[key] for r in chosen)
    result = {"physical_batches": len(chosen), "input_tokens": total("input_tokens"),
              "wave_wall_seconds": sum(w["seconds"] for w in selected_waves),
              "batch_outer_seconds": total("outer"),
              "mean_batch_outer_ms": total("outer") * 1000 / len(chosen)}
    if "cold" in chosen[0]:
        result.update({"cold_bucket_seconds": total("cold"), "submit_API_span_seconds": total("submit"),
                       "submit_to_endpoint_including_submit_seconds": total("model_span"),
                       "logged_member_step_max_once_seconds": sum(r["member_step_max"] for r in chosen),
                       "largest_shared_member_latency_spread_us": max(r["member_step_max"] - r["member_step_min"] for r in chosen) * 1e6,
                       "recorded_capture_ranges": total("recorded"), "reused_capture_ranges": total("reused"),
                       "recording_batches": sum(r["recorded"] > 0 for r in chosen),
                       "cold_in_recording_batches_seconds": sum(r["cold"] for r in chosen if r["recorded"]),
                       "warm_reuse_batches": sum(not r["recorded"] and r["reused"] > 0 for r in chosen),
                       "cold_in_warm_reuse_batches_seconds": sum(r["cold"] for r in chosen if not r["recorded"] and r["reused"] > 0)})
        # cold is a subset of pre-submit, not an additional independent cost.
        result["pre_submit_outer_inferred_seconds"] = result["batch_outer_seconds"] - total("model_span")
        result["wave_minus_batches_seconds"] = result["wave_wall_seconds"] - total("outer")
        result["optimistic_prepare_plus_submit_upper_seconds"] = (
            result["wave_wall_seconds"] - total("model_span") + total("submit"))
    else:
        result.update({key + "_seconds": total(key) for key in
                       ["input_prepare", "decode_return", "synchronize", "sampling"]})
        result["recorded_capture_ranges"] = None
        result["reused_capture_ranges"] = None
    return result


def process(folder):
    terminal = read(folder / "result.json")
    assert terminal["exit"] == 0
    observation = read(folder / "observation.json")
    raw, arm = observation["raw"], folder.name.split("-", 1)[1]
    records = []
    if arm != "peer":
        parsed = logs(folder / "stderr.log")
        assert len(parsed) == raw["graph_participations"] == 198
        names = {s["session_id"]: labels(s) for s in raw["sessions"]}
        cursors = defaultdict(int)
        for batch in raw["batches"]:
            assert not batch["restore"]
            members = [parsed[(sid, names[sid][cursors[sid]])] for sid in batch["session_ids"]]
            member_names = [names[sid][cursors[sid]] for sid in batch["session_ids"]]
            turns = {int(re.match(r"round(\d+)_", name)[1]) for name in member_names}
            assert len(turns) == 1
            for item in members[1:]:
                assert all(item[k] == members[0][k] for k in ["cold", "model_span", "submit", "recorded", "reused", "route"])
            for sid in batch["session_ids"]:
                cursors[sid] += 1
            result = {**members[0], "turn": next(iter(turns)), "kind": batch["kind"],
                      "input_tokens": batch["query_rows"] * batch["requests"], "outer": batch["seconds"],
                      "member_step_max": max(m["member_step"] for m in members),
                      "member_step_min": min(m["member_step"] for m in members)}
            records.append(result)
        waves = []
        position = 0
        for wave in raw["waves"]:
            group = records[position:position + wave["graph_calls"]]
            assert len(group) == 1  # This timing workload has one equal-T bucket per wave.
            waves.append({**wave, "turn": group[0]["turn"]})
            position += len(group)
        assert position == len(records)
    else:
        for episode in raw["episodes"]:
            turns = {int(re.match(r"round(\d+)_", m["name"])[1]) for m in episode["members"]}
            assert len(turns) == 1
            records.append({"turn": next(iter(turns)), "kind": episode["kind"],
                            "input_tokens": episode["input_tokens"], "outer": episode["seconds"],
                            **{k: episode[k + "_seconds"] for k in
                               ["input_prepare", "decode_return", "synchronize", "sampling"]}})
        assert len(raw["steps"]) == 198  # Do not sum the duplicated per-Session components.
        assert len(raw["waves"]) == len(records)
        waves = [{**w, "turn": r["turn"]} for w, r in zip(raw["waves"], records)]
    assert len(records) == raw["actual_graph_calls"]
    assert sum(r["input_tokens"] for r in records) == raw["actual_graph_tokens"] == 1728
    all_phases = {kind: summary(records, waves, kind) for kind in ["prefill", "decode"]}
    for kind in ["prefill", "decode"]:
        assert abs(all_phases[kind]["wave_wall_seconds"] - observation["phase_seconds"][kind]) < 1e-9
    return {"folder": folder.name, "arm": arm, "image": terminal.get("image"),
            "phase": all_phases, "turns": {str(t): {k: summary(records, waves, k, t)
                                                     for k in ["prefill", "decode"]} for t in [1, 2, 3]}}


def distribution(samples):
    return {"median": median(samples), "min": min(samples), "max": max(samples)}


def main():
    processes = [process(p) for p in sorted(TIMING.iterdir()) if (p / "observation.json").exists()]
    assert len(processes) == 9
    grouped = {}
    for arm in ["serial", "batch", "peer"]:
        chosen = [p for p in processes if p["arm"] == arm]
        assert len(chosen) == 3
        grouped[arm] = {}
        for segment in ["all", "1", "2", "3"]:
            phases = {}
            for kind in ["prefill", "decode"]:
                items = [(p["phase"] if segment == "all" else p["turns"][segment])[kind] for p in chosen]
                phases[kind] = {key: distribution([x[key] for x in items]) for key in items[0]
                                if items[0][key] is not None}
                phases[kind]["token_TPS"] = distribution([x["input_tokens"] / x["wave_wall_seconds"] for x in items])
            grouped[arm][segment] = phases
    bounds = {}
    for segment in ["all", "1", "2", "3"]:
        batch, peer, serial = (grouped[arm][segment]["decode"] for arm in ["batch", "peer", "serial"])
        gap = batch["wave_wall_seconds"]["median"] - peer["wave_wall_seconds"]["median"]
        cold = batch["cold_bucket_seconds"]["median"]
        both = median([p["phase"]["decode"]["cold_bucket_seconds"] + p["phase"]["decode"]["submit_API_span_seconds"]
                       if segment == "all" else p["turns"][segment]["decode"]["cold_bucket_seconds"] +
                       p["turns"][segment]["decode"]["submit_API_span_seconds"]
                       for p in processes if p["arm"] == "batch"])
        broad = batch["optimistic_prepare_plus_submit_upper_seconds"]["median"]
        batch_items = [(p["phase"] if segment == "all" else p["turns"][segment])["decode"]
                       for p in processes if p["arm"] == "batch"]
        counterfactual = {}
        for name, cost in [
            ("cold_removed", lambda x: x["cold_bucket_seconds"]),
            ("cold_and_submit_removed", lambda x: x["cold_bucket_seconds"] + x["submit_API_span_seconds"]),
            ("all_pre_submit_submit_wave_overhead_removed", lambda x: x["optimistic_prepare_plus_submit_upper_seconds"])
        ]:
            reduced = [x["wave_wall_seconds"] - cost(x) for x in batch_items]
            reduction = batch["wave_wall_seconds"]["median"] - median(reduced)
            counterfactual[name] = {"B2_decode_seconds": distribution(reduced),
                                    "reduction_from_actual_B2_median_seconds": reduction,
                                    "fraction_of_median_gap": reduction / gap if gap > 0 else None,
                                    "remaining_vs_peer_median_seconds": median(reduced) - peer["wave_wall_seconds"]["median"]}
        calls = batch["physical_batches"]["median"]
        bounds[segment] = {
            "B2_minus_peer_decode_wavewall_seconds_unpaired_medians": gap,
            "gap_ms_per_R2_batch": gap * 1000 / calls,
            "B2_cold_bucket_seconds_median": cold,
            "B2_cold_plus_submit_buckets_seconds_median": both,
            "B2_all_pre_submit_submit_wave_overhead_bucket_seconds_median": broad,
            "counterfactual_each_process_then_median": counterfactual,
            "B2_decode_aggregate_speedup_vs_R1_serial": serial["wave_wall_seconds"]["median"] / batch["wave_wall_seconds"]["median"],
            "B2_physical_mean_step_ms": batch["mean_batch_outer_ms"]["median"],
            "R1_physical_mean_step_ms": serial["mean_batch_outer_ms"]["median"]}
    kept_fields = {"physical_batches", "input_tokens", "wave_wall_seconds",
                   "cold_bucket_seconds", "submit_API_span_seconds",
                   "recorded_capture_ranges", "reused_capture_ranges", "cold_in_recording_batches_seconds",
                   "cold_in_warm_reuse_batches_seconds",
                   "input_prepare_seconds", "decode_return_seconds", "synchronize_seconds", "sampling_seconds", "token_TPS"}
    compact_groups = {a: {s: {kind: {k: v for k, v in data.items() if k in kept_fields}
                                    for kind, data in segment.items()} for s, segment in arm.items()}
                      for a, arm in grouped.items()}
    result = {"status": "Read-only physical host-timer accounting of completed nine-process timing window",
              "source_window": str(TIMING.relative_to(ROOT)),
              "processes": [{"folder": p["folder"], "arm": p["arm"], "image_sha256": p["image"]["sha256"]}
                            for p in processes],
              "grouped_3samples": compact_groups, "optimistic_decode_gap_bounds": bounds,
              "method": ["Hyle stderr has 198 logical Session entries in each process. Assign them by Session call order to actual JSON batches; shared cold/submit/model-span/capture fields must exactly agree. Count each physical batch once (99 B2 or 198 serial), using batches.seconds as its outer interval.",
                         "Per-Session step_seconds differ with admission time and duplicate the common batch. Their maximum/minimum characterize one batch only; sums over Sessions are never a physical cost. This fixed timing workload has one equal-T physical bucket per wave, checked explicitly.",
                         "Hyle seconds begins at submit and includes the submit API span, device work/wait, exports, page readiness/unbind and head publication. Do not add submit to that complete span as a separate elapsed interval.",
                         "cold_batch_seconds includes layout/permission/native preparation, metadata transfers and capture recording. It is not a pure CPU or capture-exclusive measurement and omits earlier carrier construction and ID/position upload. Outer batch minus model seconds estimates all pre-submit cost; it overlaps cold.",
                         "The broad optimistic bound = decode wavewall - deduplicated submit-to-endpoint span + deduplicated submit span. It assumes removing all pre-submit work, all submit cost and intervening wave overhead, without affecting any dependency. It is a counterfactual upper attribution bound, not an achievable optimization or speed forecast.",
                         "Peer uses original episodes once, not duplicated per-Session steps. Its decode_return/synchronize/sampling decomposition has different API boundaries; no peer cold/recording count is fabricated.",
                         "Each process first sums its three real turns; then median/min/max across three processes per arm. Per-turn statistics are separate. Counterfactuals subtract the same process's complete cost before taking medians; cost-median/gap ratios are only bucket magnitude comparisons. Gap comparisons are unpaired medians, not pooled tokens/times or a statistical significance claim."],
              "limits": ["Nine already completed timing processes, no new profiling, inference, GPU calls or builds.",
                         "No old/new native kernel counts or profile durations enter this report. Root owns the separate B2 native profile.",
                         "No native-vs-host causal split is available inside submit-to-endpoint; remaining time cannot be labeled entirely GPU. Cold/broad bounds may also contain device waits and so overstate purely removable host work.",
                         "Three samples per arm in a normal desktop window; ranges and background variation limit attribution. Printed stderr timers have finite decimal precision."],
              "activity": {"native_processes": 0, "GPU_runs": 0, "builds": 0, "product_edits": 0}}
    OUTPUT.write_text(json.dumps(result, indent=2, allow_nan=False) + "\n", encoding="utf-8")
    print(json.dumps({"report": str(OUTPUT.relative_to(ROOT)), "bounds": bounds}, indent=2))


if __name__ == "__main__":
    main()
