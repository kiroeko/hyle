"""Pure-host raw final-window and SQLite evidence checker. No native calls."""
from pathlib import Path
import bisect, collections, hashlib, importlib.util, json, re, sqlite3, statistics, sys
sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent.parent
R = S.parents[1]
D = R / '.scratch/qwen-cli-batch-20261022'
helper_path = D / 'review/recompute_performance.py'
spec = importlib.util.spec_from_file_location('previous_host_checker', helper_path)
h = importlib.util.module_from_spec(spec); spec.loader.exec_module(h)
read, identity, stats = h.read, h.identity, h.stats
P = S / 'performance2'


def pct(a, b): return (a/b-1)*100


def union(rows):
    total = 0; previous_end = -1
    for start, end in sorted(rows):
        assert end >= start
        if end > previous_end:
            total += end-max(start, previous_end)
            previous_end = end
    return total


def performance():
    runs=[]; ids_ref={}; physical_ref=None; memory={}
    ready = dict(before=read(D/'qwen-ready-attempt3.json'), batch=read(S/'qwen-ready-attempt2.json'), peer=read(D/'peer-ready.json'))
    for mode in ('timing','memory'):
        entries=read(P/mode/'inputs.json')['commands']
        assert len(entries)==(9 if mode=='timing' else 3)
        for entry in entries:
            arm=entry['variant']; folder=Path(entry['folder']); result=read(folder/'result.json')
            assert result['exit']==0 and result['reader_errors']==[]
            assert result['image']==ready[arm]['image']
            assert result['memory_only']==(mode=='memory')
            raw_path=folder/('peer-result.json'if arm=='peer'else'stdout.log');raw=read(raw_path)
            assert raw['processed_tokens']==raw['actual_graph_tokens']==1728 and raw['generated_tokens']==198
            assert raw['actual_graph_calls']==99 and raw['prefix_cache']=='off' and raw['reused_tokens']==0
            waves=raw['waves'];units=raw['episodes']if arm=='peer'else raw['batches']
            assert len(waves)==len(units)==99
            physical=[];phase=dict(prefill=0.,decode=0.);rounds=[dict(prefill=0.,decode=0.)for _ in range(3)]
            for i,(wave,unit)in enumerate(zip(waves,units)):
                t=unit['T']if arm=='peer'else unit['query_rows']
                names=tuple(x['session']for x in unit['members'])if arm=='peer'else tuple(unit['session_ids'])
                kind='prefill'if i%33==0 else'decode';expected_t=256 if kind=='prefill'else 1
                assert unit['kind']==wave['kind']==kind and t==expected_t
                assert unit['requests']==wave['outputs']==2 and names==('alice','bob')
                assert wave['logical_tokens']==wave['actual_tokens']==2*t and wave['graph_calls']==1
                phase[kind]+=wave['seconds'];rounds[i//33][kind]+=wave['seconds']
                physical.append((kind,t,names))
            if physical_ref is None:physical_ref=physical
            else:assert physical_ref==physical
            assert sum(w['logical_tokens']for w in waves)==1728 and sum(w['outputs']for w in waves)==198
            ids={}
            for session in raw['sessions']:
                name=session['id'if arm=='peer'else'session_id'];ids[name]=session['generated_ids']
                assert len(ids[name])==99 and session['visible_tokens']==864
                for p,expected_before in zip(session['phases'],(0,256,288,544,576,832)):
                    assert p['context_before']==expected_before
                    assert p['context_after']==expected_before+(256 if p['kind']=='prefill'else 32)
                if arm!='peer':assert session['restored_tokens']==0 and session['recomputed_decision_changes']==[]
            if arm in ids_ref:assert ids_ref[arm]==ids
            else:ids_ref[arm]=ids
            wall=raw['session_seconds'if arm=='peer'else'interleaved_seconds']
            assert 0<=wall-sum(phase.values())<0.001
            stderr=(folder/'stderr.log').read_text(encoding='utf-8-sig')
            if arm=='peer':
                load=raw['model_load_seconds'];ready_seconds=raw['ready_seconds']
                assert raw['native_sequence_quota']==4 and raw['cache_backing_bytes']==105971712
            else:
                load=float(re.search(r'^weights_load_seconds=(\S+)',stderr,re.M)[1])
                ready_seconds=float(re.search(r'startup_to_ready_seconds=(\S+)',stderr)[1])
                assert raw['cache_shared_backing_bytes']==103710768
            metrics=dict(prefill_tps=1536/phase['prefill'],decode_tps=192/phase['decode'],total_output_tps=198/wall,
                startup_inclusive_output_tps=198/raw['startup_total_seconds'],prefill_seconds=phase['prefill'],
                decode_seconds=phase['decode'],request_wall_seconds=wall,startup_total_seconds=raw['startup_total_seconds'],
                weights_or_model_load_seconds=load,ready_seconds=ready_seconds,outside_waves_seconds=wall-sum(phase.values()))
            row=dict(arm=arm,folder=str(folder),result=identity(folder/'result.json'),raw=identity(raw_path),metrics=metrics,rounds=rounds)
            if mode=='timing':runs.append(row)
            else:memory[arm]=h.check_memory(folder)
    assert ids_ref['before']==ids_ref['batch']==ids_ref['peer']
    groups={arm:[x for x in runs if x['arm']==arm]for arm in ('before','batch','peer')}
    table={arm:{key:stats([x['metrics'][key]for x in rows])for key in rows[0]['metrics']}for arm,rows in groups.items()}
    changes={arm:{key:pct(table['batch'][key]['median'],table[arm][key]['median'])for key in ('prefill_tps','decode_tps','total_output_tps','startup_inclusive_output_tps')}for arm in ('before','peer')}
    decomposition={key:statistics.mean(x['metrics'][key]for x in groups['batch'])-statistics.mean(x['metrics'][key]for x in groups['peer'])
        for key in ('prefill_seconds','decode_seconds','request_wall_seconds','outside_waves_seconds')}
    return dict(runs=runs,process_statistics=table,final_vs_other_median_rate_change_percent=changes,memory=memory,
        mean_final_minus_peer_decomposition_seconds=decomposition,ready_receipts=ready,
        all12processes_work_and_ids_verified=True,actual_input_tokens=1728,prefill_input_tokens=1536,decode_input_tokens=192,
        outputs=198,physical_B2_episodes=99,final_context_per_session=864)


def native(folder,arm,published):
    plan=read(folder/'plan.json')
    for kind in ('profile','export'):
        receipt=read(folder/(kind+'.result.json'))
        assert receipt['exit']==0 and receipt['terminal'] and receipt['command']==plan['commands'][kind]
    db=folder/'capture.sqlite';c=sqlite3.connect(db.resolve().as_uri()+'?mode=ro',uri=True);c.row_factory=sqlite3.Row
    names=dict(c.execute('select id,value from StringIds'))
    logs={}
    for row in c.execute('select filenameId,contentId from ProcessStreams'):
        name=names[row['filenameId']].replace('\\','/')
        for kind in ('stdout','stderr'):
            if '/streams/'+kind+'_'in name:assert kind not in logs;logs[kind]=names[row['contentId']]
    raw=json.loads(logs['stdout'])if arm=='batch'else read(folder/'peer-result.json')
    assert raw['processed_tokens']==raw['actual_graph_tokens']==1728 and raw['generated_tokens']==198 and raw['actual_graph_calls']==99
    assert [s['generated_ids']for s in raw['sessions']]==[s['generated_ids']for s in published['observations']['sessions']]
    def rows(name):return [dict(x)for x in c.execute('select * from '+name+' order by start')]
    kernels,copies,sets,apis=[rows(t)for t in ('CUPTI_ACTIVITY_KIND_KERNEL','CUPTI_ACTIVITY_KIND_MEMCPY','CUPTI_ACTIVITY_KIND_MEMSET','CUPTI_ACTIVITY_KIND_RUNTIME')]
    diagnostics=[dict(x)for x in c.execute('select * from DIAGNOSTIC_EVENT')];c.close()
    for k in kernels:k['name']=names[k['demangledName']]
    for a in apis:a['name']=names[a['nameId']]
    corr=collections.defaultdict(list)
    for a in apis:corr[a['correlationId']].append(a)
    dtoh=[x for x in copies if x['copyKind']==2 and x['bytes']==(8 if arm=='batch'else 4)]
    assert len(dtoh)==(99 if arm=='batch'else 198)
    if arm=='peer':dtoh=dtoh[1::2]
    anchors=[]
    for copy in dtoh:
        matches=[x for x in corr[copy['correlationId']]if 'Memcpy'in x['name']];assert len(matches)==1
        endpoint=matches[0]
        if endpoint['end']<copy['end']:
            endpoint=next(x for x in apis if x['globalTid']==endpoint['globalTid']and x['start']>=endpoint['end']and x['end']>=copy['end']and 'StreamSynchronize'in x['name'])
        assert endpoint['end']>=copy['end'];anchors.append(endpoint['end'])
    assert len(anchors)==99 and all(b>a for a,b in zip(anchors,anchors[1:]))
    starts={id(data):[x['start']for x in data]for data in (kernels,copies,sets,apis)}
    env=[];decode_kernels=[]
    for i in range(1,99):
        if i%33==0:continue
        lo,hi=anchors[i-1],anchors[i];selected=[]
        for data in (kernels,copies,sets,apis):
            rr=data[bisect.bisect_left(starts[id(data)],lo):bisect.bisect_left(starts[id(data)],hi)]
            assert all(x['end']<=hi for x in rr)
            if data is not apis:assert not any(x['start']<lo<x['end']for x in data)
            selected.append(rr)
        kk,cc,zz,aa=selected;decode_kernels+=kk
        device=union((x['start'],x['end'])for x in kk+cc+zz)
        row=dict(episode=i,wall_ns=hi-lo,kernel_count=len(kk),kernel_union_ns=union((x['start'],x['end'])for x in kk),
            device_busy_ns=device,device_idle_ns=hi-lo-device,graph_launches=sum('GraphLaunch'in x['name']for x in aa))
        previous=published['envelopes'][len(env)]
        assert row=={k:previous[k]for k in row}
        env.append(row)
    assert len(env)==96
    totals={key:{k:v for k,v in stats([x[key]for x in env]).items() if k!='samples'}for key in env[0]if key!='episode'}
    for key in totals:
        assert math_close(totals[key]['median'],published['all96'][key]['median'])
        assert sum(x[key]for x in env)==published['all96'][key]['sum']
    def is_top(k):return ('ArgPair<'in k['name'])or('argmax_f32'in k['name'])
    def geometry(data):
        grouped=collections.defaultdict(list)
        for x in data:
            if is_top(x):grouped[(x['name'],x['gridX'],x['gridY'],x['gridZ'],x['blockX'],x['blockY'],x['blockZ'])].append(x['end']-x['start'])
        return [dict(name=k[0],grid=k[1:4],block=k[4:7],count=len(v),duration_ns=stats(v),total_ns=sum(v))for k,v in grouped.items()]
    warns=collections.Counter(x['text']for x in diagnostics if x['severity']>=2)
    return dict(folder=str(folder),image=plan['image'],physical_id_anchors=99,decode_envelopes=96,
        observations_match_published=True,diagnostic_count=len(diagnostics),warnings=dict(warns),
        software_trace=any('software instrumented'in x['text']for x in diagnostics),
        all96=totals,all96_totals_ns={k:sum(x[k]for x in env)for k in ('wall_ns','kernel_union_ns','device_busy_ns','device_idle_ns')},
        graph_launches=sum(x['graph_launches']for x in env),
        topone_all99_geometry=geometry(kernels),topone_96decode_geometry=geometry(decode_kernels),
        topone_96decode_total_ns=sum(x['end']-x['start']for x in decode_kernels if is_top(x)),
        sql_bytes=db.stat().st_size,analysis_raw_diagnostic_equality=diagnostics==published['diagnostics'])


def math_close(a,b):return abs(a-b)<1e-6


def main():
    perf=performance()
    old=read(S/'analysis.json');after=read(S/'analysis-after2.json')
    trace=dict(before=native(S/'batch','batch',old['arms']['batch']),
        final=native(S/'after-batch2','batch',after['arms']['batch']),
        peer=native(S/'peer','peer',old['arms']['peer']))
    assert old['arms']['peer']==after['arms']['peer']
    for t in trace.values():assert t['analysis_raw_diagnostic_equality']
    old_top=trace['before']['topone_96decode_total_ns'];new_top=trace['final']['topone_96decode_total_ns']
    top=dict(before_per_physical_decode_us=old_top/96/1000,final_per_physical_decode_us=new_top/96/1000,
        duration_reduction_percent=(1-new_top/old_top)*100,
        note='TopK inclusive kernel durations; these tiny same-stream phases do not overlap. Not unprofiled TPS or a claim that all host-to-host envelope changes are caused by this one kernel.')
    report=dict(status='PASS independent final-window raw process+memory and three SQLite envelope/geometry checks; no cross-engine numerical quality acceptance',
        checker=identity(Path(__file__)),reused_host_memory_checker=identity(helper_path),
        final_window_only='Only performance2 timing9+memory3. performance/iteration1 remains separate historical data and was never pooled.',
        final_performance=perf,native_trace=trace,topone_delta=top,
        metric_definitions=dict(prefill='1536 actual prefill inputs / measured prefill wave wall',decode='192 actual decode inputs / measured decode wave wall; aggregate B2 throughput',
            total='198 host greedy outputs / complete request journey wall',startup='198 / startup-to-final-publication, excluding process teardown',
            aggregation='Median/min/max across3 independent processes per arm; never mean-of-TPS or sum-of-overlapping per-Session latencies'),
        fair_scope=['All3 arms B2 with identical2-session3turn fixed-token inputs, logical C1024/N2, prefixoff, no eviction/recompute. Actual99episodes/198outputs/1728input verified in all12 final processes. Graph/kernel counts measure different levels.',
            'Before/final use the same unchanged Hyle main/model math; change is generic private CUDA TopK1 program/kernel host owner. Peer retains original d9e03 model/ggml CUDA library, no MTP, no low-bit weight quantization.',
            'Same original320text checkpoint tensors, but Safetensors BF16/F32 vs GGUF187BF16+133F32 (97small BF16 tensors promoted under original converter); exact intermediate math not promised. Hyle history BF16/GDN F32 vs peer original R/S F32. All198 greedy IDs match here, but tensor quality not accepted.',
            'Hyle uses103710768B state backing with130x16=2080KV rows and N+R snapshot pools. Peer105971712B KV+RS with2048tokens/4native IDs, may update unretained sequence state in place. Allocation footprint/failure-cancel atomicity differ and are not neutralized by equal token counts.'],
        limits=['One instrumented process per before/final plus reused single peer trace: native durations are attribution evidence, not a stable throughput comparison. Profiler software-trace overhead and noncontemporaneous GPU clocks cannot be removed by matching IDs.',
            'Nsight collector usesCUDA13.3 libraries with installed13.4 driver; software instrumentation and peer graph-ID/CUPTI mapping warnings are counted and raw diagnostics preserved. Native graphNode attribution is not assumed complete.',
            '96decode envelopes are consecutive completed host ID-readback anchors (Hyle8B, peer second4B plus actual native synchronize), excluding3prefill episodes. Envelope includes preceding host preparation/capture/device work/readback but ends before later host result publication; it is not full benchmark decode-wave wall.',
            'Device busy is interval union of kernels/memcpy/memset, without double counting overlap. Idle means no activity from this profiled process, not physical GPU idle or attribution to one CPU function. Kernel symbol duration sums are inclusive and must not be added as a wall-speedup claim.',
            'Final unprofiled3process medians/ranges are the performance claim. Single memory process per arm uses requested10msPSAPI/PDH; actual sample gaps/boundary ages and unknown ready baseline are retained. GPU peaks are sampled lower bounds; CPU mmap working-set/commit semantics differ.',
            'Final nativeTopK244+2CTAs describes this248320-column,R2 input only; implementation is generic. Before all99oldTopK kernels include3prefill.96decode totals must not be confused with99-workload totals.'],
        remaining_gap='Final median decode remains below peer despite the generic TopK gain. Remaining union/envelope and projection/state/launch gaps are candidates for the next bounded investigation; neither earlier state72MiB arithmetic nor kernel count proves their runtime share.')
    out=S/'review/final-performance-review.json';out.write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(dict(report=identity(out),medians={a:{k:v['median']for k,v in row.items()if k.endswith('tps')}for a,row in perf['process_statistics'].items()},changes=perf['final_vs_other_median_rate_change_percent'],topone=top),indent=2))


if __name__=='__main__':main()
