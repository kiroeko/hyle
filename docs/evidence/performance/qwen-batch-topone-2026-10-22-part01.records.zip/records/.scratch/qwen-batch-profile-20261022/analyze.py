"""Offline actual B2 token envelopes; no native target is launched."""
from pathlib import Path
from collections import Counter,defaultdict
import argparse,bisect,hashlib,json,re,sqlite3,statistics
S=Path(__file__).resolve().parent;R=S.parents[1];D=R/'.scratch/qwen-cli-batch-20261022'
read=lambda p:json.loads(Path(p).read_text(encoding='utf-8-sig'))
def save(p,x):p.write_text(json.dumps(x,indent=2,allow_nan=False)+'\n')
def stats(v):
    v=list(v);return dict(n=len(v),sum=sum(v),min=min(v),median=statistics.median(v),max=max(v),mean=statistics.mean(v))if v else None
def merged(intervals):
    out=[]
    for lo,hi in sorted(intervals):
        if hi<=lo:continue
        if out and lo<=out[-1][1]:out[-1][1]=max(out[-1][1],hi)
        else:out.append([lo,hi])
    return out
def union(intervals):return sum(hi-lo for lo,hi in merged(intervals))
def family(n):
    if 'ArgPair<'in n or 'argmax'in n or 'arg_max'in n or 'arg_max'in n or 'top_k'in n:return'argmax'
    if 'gated_delta_net'in n:return'GDN'
    if 'ssm_conv'in n:return'conv'
    if 'concat_cont'in n:return'concat'
    if any(x in n for x in('gemm','gemvx','mul_mat_f','mul_mat_vec')):return'projection'
    if any(x in n for x in('flashinfer','flash_attn')):return'attention'
    if any(x in n for x in('convert_unary','cpy_','copy_')):return'conversion_copy'
    return'other'
def grouped(rows,key):
    acc=defaultdict(lambda:[0,0])
    for x in rows:a=acc[key(x)];a[0]+=1;a[1]+=x['end']-x['start']
    return sorted([dict(name=k,count=v[0],ns=v[1])for k,v in acc.items()],key=lambda x:-x['ns'])
parser=argparse.ArgumentParser();parser.add_argument('--after',type=int,default=0);args=parser.parse_args()
reports={}
for arm in('batch','peer'):
    folder=('after-batch'+(str(args.after)if args.after>1 else''))if arm=='batch'and args.after else arm
    out=S/folder;plan=read(out/'plan.json')
    for tag in('profile','export'):
        x=read(out/f'{tag}.result.json');assert x['exit']==0 and x['terminal']and x['command']==plan['commands'][tag]
    c=sqlite3.connect((out/'capture.sqlite').resolve().as_uri()+'?mode=ro',uri=True);c.row_factory=sqlite3.Row
    strings=dict(c.execute('select id,value from StringIds'));logs={}
    for x in c.execute('select *from ProcessStreams'):
        path=strings[x['filenameId']].replace('\\','/')
        for kind in('stdout','stderr'):
            if '/streams/'+kind+'_'in path:assert kind not in logs;logs[kind]=strings[x['contentId']];(out/f'model.{kind}.log').write_text(logs[kind])
    raw=json.loads(logs['stdout'])if arm=='batch'else read(out/'peer-result.json')
    baseline=read(D/'performance/timing'/('02-batch'if arm=='batch'else'03-peer')/'observation.json')['raw']
    assert raw['processed_tokens']==raw['actual_graph_tokens']==1728 and raw['generated_tokens']==198 and raw['actual_graph_calls']==99
    assert [x['generated_ids']for x in raw['sessions']]==[x['generated_ids']for x in baseline['sessions']]
    def rows(table):return[dict(x)for x in c.execute('select *from '+table+' order by start')]
    kernels,copies,sets,api=[rows(t)for t in('CUPTI_ACTIVITY_KIND_KERNEL','CUPTI_ACTIVITY_KIND_MEMCPY','CUPTI_ACTIVITY_KIND_MEMSET','CUPTI_ACTIVITY_KIND_RUNTIME')]
    for x in kernels:x['name']=strings[x['demangledName']];x['family']=family(x['name'])
    for x in api:x['name']=strings[x['nameId']]
    diag=rows('DIAGNOSTIC_EVENT')if False else[dict(x)for x in c.execute('select *from DIAGNOSTIC_EVENT')]
    c.close()
    corr=defaultdict(list)
    for x in api:corr[x['correlationId']].append(x)
    dtoh=[x for x in copies if x['copyKind']==2 and x['bytes']==(8 if arm=='batch'else 4)]
    assert len(dtoh)==(99 if arm=='batch'else 198)
    dtoh=dtoh if arm=='batch'else dtoh[1::2]
    anchors=[]
    for x in dtoh:
        aa=[a for a in corr[x['correlationId']]if 'Memcpy'in a['name']]
        assert len(aa)==1
        endpoint=aa[0]
        if endpoint['end']<x['end']:
            # The peer enqueues both IDs and logits asynchronously, then its
            # real stream synchronize makes them host-visible. Enqueue return
            # is not a token-completion boundary.
            waits=[a for a in api if a['globalTid']==endpoint['globalTid']and a['start']>=endpoint['end']and a['end']>=x['end']and 'StreamSynchronize'in a['name']]
            assert waits;endpoint=waits[0]
        assert endpoint['end']>=x['end'];anchors.append(dict(device=x,api=endpoint))
    assert len(anchors)==99 and all(b['api']['end']>a['api']['end']for a,b in zip(anchors,anchors[1:]))
    physical=raw['batches']if arm=='batch'else raw['episodes'];assert len(physical)==99
    envelopes=[];all_decode=[];all_decode_api=[];all_decode_copies=[]
    starts={id(data):[x['start']for x in data]for data in(kernels,copies,sets,api)}
    for i in range(1,99):
        if physical[i]['kind']!='decode':continue
        lo,hi=anchors[i-1]['api']['end'],anchors[i]['api']['end']
        selected=[]
        for data in(kernels,copies,sets,api):
            rr=[x for x in data[bisect.bisect_left(starts[id(data)],lo):bisect.bisect_left(starts[id(data)],hi)]if x['end']<=hi]
            selected.append(rr)
        kk,cc,zz,aa=selected
        busy=union([(x['start'],x['end'])for x in kk+cc+zz]);kernel_union=union([(x['start'],x['end'])for x in kk])
        assert kk and all(x['end']<=hi for x in kk+cc+zz)
        all_decode+=kk;all_decode_api+=aa;all_decode_copies+=cc
        env=dict(episode=i,turn=i//33+1,local_decode=i%33,lo=lo,hi=hi,wall_ns=hi-lo,kernel_count=len(kk),kernel_union_ns=kernel_union,device_busy_ns=busy,device_idle_ns=hi-lo-busy,
            graph_launches=sum('GraphLaunch'in x['name']for x in aa),graph_instantiates=sum('GraphInstantiate'in x['name']for x in aa),families=grouped(kk,lambda x:x['family']),
            copies=[dict(kind=k,count=len(v),bytes=sum(x['bytes']for x in v),ns=union([(x['start'],x['end'])for x in v]))for k in sorted({x['copyKind']for x in cc})if(v:=[x for x in cc if x['copyKind']==k])])
        envelopes.append(env)
    assert len(envelopes)==96
    warm=[x for x in envelopes if x['local_decode']>=7 and x['graph_instantiates']==0]
    def summary(envs):
        return{key:stats(x[key]for x in envs)for key in('wall_ns','kernel_count','kernel_union_ns','device_busy_ns','device_idle_ns','graph_launches','graph_instantiates')}
    arg=[x for x in all_decode if x['family']=='argmax']
    reports[arm]=dict(image=plan['image'],sql_path=str(out/'capture.sqlite'),anchor_definition='8B ID vector host-copy per Hyle batch'if arm=='batch'else'last of two4B sampled token host copies per peer batch; automatic993280B/row logits copies included',
        observations=raw,diagnostics=diag,envelopes=envelopes,all96=summary(envelopes),warm=summary(warm),rounds={str(t):summary([x for x in envelopes if x['turn']==t])for t in(1,2,3)},
        kernel_families=grouped(all_decode,lambda x:x['family']),kernel_symbols=grouped(all_decode,lambda x:x['name']),runtime_api=grouped(all_decode_api,lambda x:x['name']),
        argmax_geometries=[dict(name=k[0],grid=k[1:4],block=k[4:7],count=len(v),ns=stats(x['end']-x['start']for x in v))for k,v in ((k,[x for x in arg if(x['name'],x['gridX'],x['gridY'],x['gridZ'],x['blockX'],x['blockY'],x['blockZ'])==k])for k in sorted({(x['name'],x['gridX'],x['gridY'],x['gridZ'],x['blockX'],x['blockY'],x['blockZ'])for x in arg}))])
save(S/('analysis.json'if not args.after else f'analysis-after{args.after}.json'),dict(arms=reports,throughput_evidence=False,limits=['One instrumented process per arm; counts/attribution only, not stable unprofiled TPS.','Nsight2026.1 usesCUDA13.3 CUPTI on installed13.4 driver and reports compatibility/software-trace warnings. Peer additionally reports graph-ID mapping warnings; original diagnostics retained. No assumption that graphNode IDs are universally available.','Envelopes from consecutive host sampled-token readback anchors; include all input/prepare/capture/submit/GPU/readback since previous completion. Last native readback is before remaining host publication, so it is not the full benchmark phase wall.','GPU kernels/copies may overlap; unions measure device-busy and idle, symbol ns are inclusive. No summing overlapping duration as wall or as a speedup claim.']))
for arm,x in reports.items():print(arm,{k:v['median']for k,v in x['all96'].items()},'families',[(y['name'],round(y['ns']/96/1e3,2))for y in x['kernel_families']])
