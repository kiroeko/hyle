from pathlib import Path
import json
S=Path(__file__).resolve().parent;R=S.parents[1]
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
t=read(S/'performance2/timing/summary.json');mem=read(S/'performance2/memory/summary.json');g=t['groups'];arms=('before','batch','peer')
ev='../evidence/performance/qwen-batch-topone-2026-10-22.json'
def med(a,k):return g[a][k]['median']
def row(label,key,n=2):return '| '+label+' | '+' | '.join(f'{med(a,key):.{n}f}'for a in arms)+' |\n'
def mrow(label,key):return '| '+label+' | '+' | '.join(f'{mem["groups"][a]["sampled_peaks"][key]/2**30:.3f}'for a in arms)+' |\n'
p=R/'docs/developer/current-work.md';s=p.read_text(encoding='utf-8')
a=s.index('**当前正在做：');b=s.index('\n当前每进程',a)
s=s[:a]+'''**当前正在做：真实CLI批次与首轮对照后，已定位并修复通用CUDA宽多行TopK1慢项。** 新双路完整decode169.56对参考186.77tok/s，差约9.22%；相对本轮修改前提高10.67%，完整综合输出提高10.06%。Model和公共接口未新增接线，修改集中在Provider。下一步将已冷准备的宽TopK1能力如实接入Graph capture，作为真实MTP图链的前置；随后接真实草拟／验证／接受状态。其它系统原生路径、已选模型完整覆盖和图片仍未完成。'''+s[b:]
s=s.replace('新窗口B2合计decode153.64对参考186.58tok/s，仍慢17.65%',
'''首窗B2合计decode153.64对参考186.58tok/s；修复宽多行TopK1后新窗169.56对186.77，仍慢9.22%''')
s=s.replace('→ 定量拆分批次decode余差 → MTP真实消费者 → 图片链路',
'''→ 已定位并修复宽多行TopK1 → 按冷事实接Graph capture及MTP真实消费者 → 图片链路''')
old='先接真实K1草拟／T2验证，再保接受／拒绝后的完整状态；普通peer GGUF为no-mtp，须另备可比MTP制品'
new='''[下一批接入方案](../evidence/research/qwen35-mtp-next-2026-10-22.json)已核原15张量元数据；ready页帧reframe已补旧KV投影缺口。先在同一Graph做真实K1草拟→T2验证，选择接受边界后一次提交target／MTP／hidden状态；不能以截断length冒充恢复。普通peer GGUF为no-mtp，须另备可比MTP制品'''
assert old in s;s=s.replace(old,new)
s=s.replace('下一步用一次实际GPU分析拆分B2状态收集／回写、准备／录制与原生计算，确认17.65%余差的组成再改；',
'''该窗口之后已完成一次有限GPU分析并修复宽多行TopK1，见下；''')
assert '### 宽多行TopK1修复：2026-10-22'not in s
s+='''
### 宽多行TopK1修复：2026-10-22

保持上一窗两会话、三轮固定输入、C1024／N2／R2、1728实际token／198结果，关闭前缀，无MTP／图片／淘汰。修改前、当前、同一固定llama参考各3新进程交错测速，另各1进程内存旁采；每进程均99次真实B2、输入／顺序／上下文／198个ID相同。只替换一个CUDA对象和其私有Program的host调用方，复用其它193个对象／库及全部SDK；Model、公共API、模型数学和精度策略未改。第一版含中间结果整理的独立窗口仅作历史，未与本表合池。

| 指标 | 修改前Hyle B2 | 当前Hyle B2 | llama.cpp B2 |
| --- | ---: | ---: | ---: |
'''
s+=row('合计prefill tok/s（1536／P波次总wall）','prefill_tps')
s+=row('合计完整decode tok/s（192／D波次总wall）','full_decode_tps')
s+=row('综合输出 tok/s（198／全程wall）','session_output_tps')
s+=row('推理全程wall s','session_seconds',5)
s+=row('入口至末输出 s','startup_total_seconds',5)
s+=row('启动至ready s','ready_seconds',5)
s+=row('权重加载 s（非冷盘）','load_seconds',5)
s+=mrow('GPU dedicated观测峰 GiB','sampled_peak_gpu_dedicated_bytes')
s+=mrow('GPU shared观测峰 GiB','sampled_peak_gpu_shared_bytes')
s+=mrow('GPU同点总量观测峰 GiB','sampled_peak_gpu_total_bytes')
s+=mrow('CPU working set观测峰 GiB','sampled_max_working_set_bytes')
s+=mrow('进程private commit观测峰 GiB','sampled_max_private_commit_bytes')
s+='''
相对本轮前prefill＋4.84%、完整decode＋10.67%、综合＋10.06%；相对参考分别＋19.68%、－9.22%、－4.99%。**真实双路吞吐继续改善，尚未追平参考，不推算为单用户收益。** 修改前／当前／参考decode范围为152.79–153.75／169.36–169.62／186.60–187.06tok/s；综合134.64–136.24／148.05–148.80／155.89–156.51。保全部样本；只3进程，prefill的变化也包含背景／时钟波动，不把所有变化归于归约。

有限Nsight时间线核99批结果／96次decode：旧分段TopK1用2个256线程CTA处理两行词表，每次归约inclusive约1.200ms；当前先244个CTA分块，再2个CTA合并并写原始值／索引，合计约32.72µs。不再另存selection并发两次整理kernel。归约保持原ArgBest的NaN／稳定tie顺序、I32宽比较与原T重读，支持通用axis／byte strides，不写死Qwen或R2。单行保原设备级归约。最终decode中位759个kernel、1次Graph launch，参考709个kernel；这些是本批实测而非沿用旧计数，数量本身不作为收益证明。

状态concat在旧时间线约0.221ms／批、当前约0.215ms，远小于旧TopK1，未作为本次主因。当前与参考projection inclusive均约9.3ms／批，设备无活动区间中位约1.93ms对0.88ms；其中有主机准备、排队和工具扰动，不能把差额全称CPU函数自耗时。Nsight软件trace使用CUDA13.3库收集13.4驱动，参考还有graph-ID映射警告，完整诊断保留；只用来选方向，性能表采用未插桩进程。

12项相关Direct／Graph测试通过，包括四类型、宽中轴／strides、末tile、tie、NaN payload／signed zero、I32精度、workspace与原完成寿命。真实R1的18份、B2的72份向量与各自同批宽基线逐字节一致且有限；这次没有跨B比较。首次测试暴露原空Scan断言把无工作也当managed／host-blocking，已按原Provider的no-op合同修正并重跑，保留失败记录。

实际内存采样间隔中位约15.2ms、三个ready基线均未知；本窗前后dedicated峰相同，TopK1临时workspace增加2048字节且受原caller workspace／Invocation隔离。KV／recurrent backing不变，不能把GPU观测峰解释为精确新增分配。BF16/F32小权重、conv历史精度、物理池和失败合同的跨引擎差别仍同上窗。

下一步收敛到MTP前置：新宽TopK1的两个kernel已在冷端materialize，但Provider仍按整个TopK种类声明managed、拒绝external capture。只对确实已准备的Program修正能力事实，并核普通Graph／独立Invocation／错误退休；不能把其它CUB路径一起改标prepared。随后使用真实15个MTP张量，同一Graph草拟→验证、接受边界状态选择和一次composite提交，保无MTP基线。详见[本轮证据]('''+ev+''')；已知状态收集／回写和small-M投影融合候选继续有记录，暂不扩成新一轮性能试验。
'''
p.write_text(s,encoding='utf-8')
p=R/'docs/developer/performance/decode.md';s=p.read_text(encoding='utf-8');a=s.index('**当前优先项');b=s.index('\n\n',a)
s=s[:a]+'''**当前优先项（2026-10-22）：真实批次的宽多行TopK1慢项已定量定位并修复，转入MTP前置。** 同窗修改前／当前／参考B2完整decode153.22／169.56／186.77tok/s，综合135.08／148.66／156.47；当前decode＋10.67%、综合＋10.06%，对参考仍慢9.22%／4.99%。[完整四项及限制](../current-work.md#宽多行topk1修复2026-10-22)与[证据](../../evidence/performance/qwen-batch-topone-2026-10-22.json)已更新。单行原路线保留，90份同批宽向量逐字节相同。下一步先如实声明新宽TopK1的已准备能力、接入普通Graph capture，随后接真实MTP；不为追逐TPS无限重复当前窗口。'''+s[b:]
s=s.replace('→ 定量拆分B2 decode余差 → 真实MTP消费者',
'''→ 宽多行TopK1慢项已修 → 已准备能力接线与真实MTP消费者''')
s=s.replace('| 剩余项 | 已知事实与下一步 |','''| 剩余项 | 已知事实与下一步 |
| 宽多行TopK1 | **已修**：旧2CTA分段归约约1.2ms，新分块＋末级直接写原值／索引约32.72µs；12相关测试和90份同B向量通过。只在Provider内改算法，Model／公共接口不加专线；prepared能力声明是下一批前置 |
| B2后续归因 | 当前GPU无活动区间仍比参考长，状态concat约0.215ms，small-M融合也有候选；已有实测和源码记录，尚不把整个余差归为某函数或状态复制 |''')
p.write_text(s,encoding='utf-8')
research=R/'docs/evidence/research/qwen35-mtp-next-2026-10-22.json'
assert not research.exists();research.write_bytes((S/'review/mtp-next-implementation.json').read_bytes())
print('updated current-work/decode; published MTP next-step research (not implementation)')
