"""Two serial native timelines of the measured B2 workload, never TPS samples."""
from pathlib import Path
import importlib.util,os,sys
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent;R=S.parents[1];D=R/'.scratch/qwen-cli-batch-20261022'
sp=importlib.util.spec_from_file_location('helpers',D/'build.py');h=importlib.util.module_from_spec(sp);sp.loader.exec_module(h)
b,c=h.h.b,h.h.c
prior=c.read(D/'performance/timing/inputs.json')
nsys=Path('C:/Program Files/NVIDIA Corporation/Nsight Systems 2026.1.3/target-windows-x64/nsys.exe')
for arm in ('batch','peer'):
    ready_path=D/('qwen-ready-attempt3.json'if arm=='batch'else'peer-ready.json');ready=c.read(ready_path)
    assert b.identity(ready['image']['path'])==ready['image']
    command=next(x['command'].copy()for x in prior['commands']if x['variant']==arm)
    assert command[0]==ready['image']['path']and '--trace'not in command
    out=S/arm;out.mkdir(parents=True,exist_ok=False);(out/'tmp').mkdir()
    if '--result'in command:command[command.index('--result')+1]=str(out/'peer-result.json')
    stem=out/'capture'
    commands=dict(profile=[str(nsys),'profile','--trace=cuda','--sample=none','--cpuctxsw=none',
        '--cuda-trace-all-apis=true','--cuda-graph-trace=node:host-only','--discard-environment=true',
        '--output='+str(stem),*command],
        export=[str(nsys),'export','--type=sqlite','--output='+str(stem)+'.sqlite',str(stem)+'.nsys-rep'])
    env=os.environ.copy();env['PATH']=c.read(ready['runtime_environment']['path'])['PATH'];env['TEMP']=env['TMP']=str(out/'tmp')
    c.save(out/'plan.json',dict(arm=arm,ready=b.identity(ready_path),image=ready['image'],runtime_environment=ready['runtime_environment'],commands=commands,
        source_workload=b.identity(D/'performance/timing/inputs.json'),profiler=b.identity(nsys),throughput_evidence=False,concurrent_GPU=False,
        purpose='Actual two-session3turns256+32,99 B2 episodes,198returned IDs. Attribute native GPU activities/API/capture and gaps; no profiled TPS claim.'))
    for tag,argv in commands.items():c.execute(tag,argv,env,out)
    print('B2_TRACE_READY',arm,flush=True)
