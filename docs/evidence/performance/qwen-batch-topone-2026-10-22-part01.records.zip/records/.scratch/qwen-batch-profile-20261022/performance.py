"""Matched before/after/peer B2 window; reuse input/runtime/observer caches."""
from pathlib import Path
import argparse,importlib.util,os,sys
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent;R=S.parents[1];D=R/'.scratch/qwen-cli-batch-20261022'
p=argparse.ArgumentParser();p.add_argument('mode',choices=('timing','memory'));p.add_argument('--iteration',type=int,default=1);args=p.parse_args()
source=(D/'performance.py').read_text(encoding='utf-8')
edits=[
    ("p=argparse.ArgumentParser();p.add_argument('mode',choices=('timing','memory'));a=p.parse_args()",'a=args'),
    ("out=D/'performance'/a.mode", "out=S/('performance' if args.iteration==1 else 'performance'+str(args.iteration))/a.mode"),
    ("receipts=dict(serial=D/'qwen-ready-attempt3.json',batch=D/'qwen-ready-attempt3.json',peer=D/'peer-ready.json')", "receipts=dict(before=D/'qwen-ready-attempt3.json',batch=S/f'qwen-ready-attempt{args.iteration}.json',peer=D/'peer-ready.json')"),
    ("['serial','batch','peer','peer','batch','serial','batch','serial','peer']if a.mode=='timing'else['serial','batch','peer']", "['before','batch','peer','peer','batch','before','batch','before','peer']if a.mode=='timing'else['before','batch','peer']"),
    ("'1'if variant=='serial'else'2'", "'2'"),
    ("expected_calls=198 if variant=='serial' else 99",'expected_calls=99'),
    ("(1 if variant=='serial' else 2)",'2'),
    ("if variant in('peer','batch'):", "if variant in('peer','batch','before'):"),
    ("for v in('serial','peer'):","for v in('before','peer'):"),
    ("Serial HyleR1 is same source/image; HyleB2 and llamaB2 use same equal-T wave order.","Before/after Hyle differ in the generic CUDA TopK1 implementation/private Program host owner; all three arms are actualB2 with the same equal-T wave order."),
]
for old,new in edits:
    assert source.count(old)==1,old;source=source.replace(old,new)
# The retained controller derives its own stage from __file__; bind that D to
# the prior stage explicitly. Outputs remain under the new stage S.
old="D=Path(__file__).resolve().parent;R=D.parents[1]"
assert source.count(old)==1
source=source.replace(old,"D=R/'.scratch/qwen-cli-batch-20261022'")
exec(compile(source,str(Path(__file__).resolve()),'exec'),globals())
