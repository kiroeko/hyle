from pathlib import Path
import argparse,importlib.util,os,sys
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent;R=S.parents[1];D=R/'.scratch/qwen-cli-batch-20261022'
sp=importlib.util.spec_from_file_location('helpers',S/'build.py');h=importlib.util.module_from_spec(sp);sp.loader.exec_module(h)
b,c=h.b,h.c
p=argparse.ArgumentParser();p.add_argument('case',choices=('tests','r1','batch'));p.add_argument('--attempt',type=int,default=1);p.add_argument('--ready-attempt',type=int,default=1);a=p.parse_args()
ready=c.read(S/f'{"tests"if a.case=="tests"else"qwen"}-ready-attempt{a.ready_attempt}.json');assert b.identity(ready['image']['path'])==ready['image']
out=S/f'{a.case}-run{a.attempt}';out.mkdir(exist_ok=False)
if a.case=='tests':command=[ready['image']['path'],'--gtest_filter=CudaCccl.*:CudaDefaultGraph.SoftmaxTopKAndRenormalizationCaptureBothOutputs','--gtest_output=xml:'+str(out/'gtest.xml')]
else:
    old=c.read(D/f'{a.case}-run{2 if a.case=="batch"else 1}/command.json')
    command=old['command'].copy();command[0]=ready['image']['path'];command[command.index('--trace')+1]=str(out/'trace')
env=os.environ.copy();env['PATH']=c.read(ready['runtime_environment']['path'])['PATH']
c.save(out/'plan.json',dict(command=command,image=ready['image'],runtime_environment=ready['runtime_environment'],throughput_evidence=False))
c.execute('run',command,env,out)
print('CHECK_COMPLETED',a.case,flush=True)
