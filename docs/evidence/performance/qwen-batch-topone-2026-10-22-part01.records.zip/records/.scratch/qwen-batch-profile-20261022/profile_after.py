from pathlib import Path
import argparse,importlib.util,os,sys
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent
sp=importlib.util.spec_from_file_location('helper',S/'build.py');h=importlib.util.module_from_spec(sp);sp.loader.exec_module(h)
b,c=h.b,h.c
p=argparse.ArgumentParser();p.add_argument('--iteration',type=int,default=1);args=p.parse_args()
ready=c.read(S/f'qwen-ready-attempt{args.iteration}.json');assert b.identity(ready['image']['path'])==ready['image']
old=c.read(S/'batch/plan.json');out=S/('after-batch'if args.iteration==1 else'after-batch'+str(args.iteration));out.mkdir(exist_ok=False);(out/'tmp').mkdir()
command=old['commands']['profile'].copy();command[command.index('--output='+str(S/'batch/capture'))]='--output='+str(out/'capture')
command[command.index(old['image']['path'])]=ready['image']['path']
export=[command[0],'export','--type=sqlite','--output='+str(out/'capture.sqlite'),str(out/'capture.nsys-rep')]
c.save(out/'plan.json',dict(arm='batch',image=ready['image'],runtime_environment=ready['runtime_environment'],commands=dict(profile=command,export=export),throughput_evidence=False))
env=os.environ.copy();env['PATH']=c.read(ready['runtime_environment']['path'])['PATH'];env['TEMP']=env['TMP']=str(out/'tmp')
for tag,argv in(('profile',command),('export',export)):c.execute(tag,argv,env,out)
print('AFTER_B2_TRACE_READY')
