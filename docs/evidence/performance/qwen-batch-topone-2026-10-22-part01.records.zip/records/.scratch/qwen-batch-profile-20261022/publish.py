"""Publish finite CUDA change, raw timelines, numerical and timing evidence."""
from pathlib import Path
import hashlib,json,zipfile
S=Path(__file__).resolve().parent;R=S.parents[1];P=R/'docs/evidence/performance';stem='qwen-batch-topone-2026-10-22'
read=lambda p:json.loads(Path(p).read_text(encoding='utf-8-sig'))
def ident(p):
    p=Path(p).resolve();h=hashlib.sha256()
    with p.open('rb')as f:
        for block in iter(lambda:f.read(8<<20),b''):h.update(block)
    return dict(path=str(p),bytes=p.stat().st_size,sha256=h.hexdigest())
def save(p,x):p.write_text(json.dumps(x,indent=2,ensure_ascii=False,allow_nan=False)+'\n',encoding='utf-8')
sources=[R/x for x in('src/compute_provider_cuda/collectives.cu','src/compute_provider_cuda/collectives.h','tests/compute_provider_cuda/collectives_test.cc','tests/compute_provider_cuda/collectives_test_support.h','docs/user/graph.md','tools/qwen35_text/main.cc')]
native=read(S/'compile3/native/identity.json');provider=read(S/'compile1/provider/identity.json');ready=read(S/'qwen-ready-attempt2.json')
assert ident(sources[0])==native['source']and ident(sources[1])in native['dependencies']and ident(sources[1])in provider['dependencies']
assert ident(ready['image']['path'])==ready['image']and ident(sources[-1])==ready['source']
assert read(S/'tests-run3/run.result.json')['exit']==0 and '12 tests.'in(S/'tests-run3/run.stdout.log').read_text(encoding='utf-8')
review=read(S/'review/final-performance-review.json');math=read(S/'review/topone-model-regression.json')
timing=read(S/'performance2/timing/summary.json');memory=read(S/'performance2/memory/summary.json')
assert timing['processes']==9 and memory['processes']==3 and not any(timing['greedy_id_differences'].values())
paths=sources+[R/'docs/developer/current-work.md',R/'docs/developer/performance/decode.md',R/'docs/evidence/research/qwen35-mtp-next-2026-10-22.json']
for p in S.rglob('*'):
    if not p.is_file():continue
    rel=p.relative_to(S)
    if any(x in('tmp','__pycache__')for x in rel.parts):continue
    if p.suffix.lower()in('.obj','.exe','.dll','.lib','.exp','.pdb','.map'):continue
    if rel.parts[0]in('published','archive'):continue
    paths.append(p)
paths=sorted(set(paths),key=lambda p:p.relative_to(R).as_posix());files=[dict(**ident(p),entry=p.relative_to(R).as_posix())for p in paths]
archives=[];z=None;current=None
try:
    for p,row in zip(paths,files):
        if z is None or z.fp.tell()>80_000_000:
            if z is not None:z.close();archives.append(ident(current))
            current=P/f'{stem}.data.part{len(archives)+1:02}.zip';assert not current.exists()
            z=zipfile.ZipFile(current,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6)
        z.write(p,row['entry'])
    if z is not None:z.close();z=None;archives.append(ident(current))
finally:
    if z is not None:z.close()
entries={}
for a in archives:
    assert a['bytes']<100*2**20
    with zipfile.ZipFile(a['path'])as z:
        assert z.testzip()is None
        for item in z.infolist():
            assert item.filename not in entries;data=z.read(item.filename);entries[item.filename]=(len(data),hashlib.sha256(data).hexdigest())
assert len(entries)==len(files)and all(entries[x['entry']]==(x['bytes'],x['sha256'])for x in files)
before=read(S/'analysis.json');after=read(S/'analysis-after2.json')
manifest=dict(schema='hyle.qwen-batch-topone.v1',date='2026-10-22',status='Generic CUDA wide multirow TopK1 optimization and this finite window completed; broad goal remains incomplete',
    sources=[ident(p)for p in sources],final_image=ready,archives=archives,archive_files=files,archive_layout='Ordinary ZIP volumes below100MiB; extract all volumes to one directory. Entries are repository-relative. No model/SDK/dependency cache copy.',
    change=['Two-stage generic TopK1 when there is more than one row and the reduction axis spans multiple tiles. No model/batch/vocabulary whitelist. Single-row device reduction and short segmented/K>1/Scan/Gather algorithms retain their existing paths.',
      'Original associative ArgBest carries original row-local index, prefers numbers overNaN, resolves ties/allNaNs/signedzero by earliest index. I32 compares inI64. Final kernel rereads originalT bytes and writes value/index together; no extra selected-pair materialization or two DeviceTransform passes.',
      'Cold checked grid/workspace sizing and native kernel materialization; perInvocation caller workspace, same stream. No hot allocation or host synchronization added. Private Program ABI requires both CUDA TU and its sole host provider owner to rebuild; no public ABI/API or Model wiring change.',
      'Empty Scan test fixture now expects the already existing no-work prepared/nonblocking contract; nonempty managed and I32 host-validation expectations remain. Initial failing test is preserved.'],
    correctness=dict(unit_run=ident(S/'tests-run3/run.result.json'),unit_xml=ident(S/'tests-run3/gtest.xml'),unit_tests=12,math_review=math,same_B_byte_identical_vectors=90,R1_vectors=18,B2_vectors=72,
      review=read(S/'review/topone-implementation-review-final.json')),
    native_profile=dict(before_analysis=ident(S/'analysis.json'),final_analysis=ident(S/'analysis-after2.json'),unprofiled_throughput_evidence=False,
      actual_decode_batches=96,returned_decisions=198,graph_calls=99,
      before=dict(reduction_CTA=2,threads_per_CTA=256,argmax_inclusive_ns_per_batch=sum(x['ns']for x in before['arms']['batch']['kernel_families']if x['name']=='argmax')/96,kernel_count_median=before['arms']['batch']['all96']['kernel_count']['median']),
      current=dict(tile_CTA=244,finish_CTA=2,threads_per_CTA=256,argmax_inclusive_ns_per_batch=sum(x['ns']for x in after['arms']['batch']['kernel_families']if x['name']=='argmax')/96,kernel_count_median=after['arms']['batch']['all96']['kernel_count']['median']),
      limits=after['limits']),
    final_performance=dict(timing=timing,memory=memory,independent_review=review,
      scope='Same two independent retained teacherforced3rounds256+32 sessions,C1024/N2/R2,prefixoff,no eviction.1728actual input tokens,198decisions,1536P+192D,99actualB2 episodes. Three fresh timing processes/arm, separate one memory process/arm. Previous intermediate performance window is retained but not pooled.'),
    pending=['Native wide TopK1 is still declared managed by kind in provider runtime/submit. Capability must be specialized on immutable prepared facts and checked with actual ordinary capture/RequirePrepared/replay/failure retirement before calling it prepared.',
      'RemainingB2 decode gap not fully attributed; host/device idle and state collection/small-M fusion candidates are recorded, not yet claimed fixes.',
      'Real15-tensor MTP loader/graph/draft/verify/accepted-state composite publication and matched real MTP peer.',
      'Image encoder/projector,text chain; native Apple/Vulkan paged consumers; all selected models/quants and full architecture/three-OS goal.'],
    research=dict(next_MTP=ident(R/'docs/evidence/research/qwen35-mtp-next-2026-10-22.json'),status='Read-only design/header audit, not real MTP execution. Existing reframe closes former KV projection gap; actual remaining integration is explicit.'),
    incidents=['Native compile attempt1 did not start NVCC because retained environment helper was passed nvcc as the CXX selector. Corrected helper uses matching MSVC recipe; native compile2 and final3 actually exit0.',
      'First actual unit run exited1 on the pre-existing emptyScan runtime-property assertions; all math tests passed. Corrected only no-work fixture, retained failed logs, final12-test run exits0.',
      'Profile offline parser initially assumed the peer async memcpy enqueue was host completion. Corrected to the actual following stream synchronize after both sampled tokens/logits; original APIs/copies and warnings are retained. No native process restarted for parser correction.'],
    previous='docs/evidence/performance/qwen-cli-batch-2026-10-22.json; baseline math vectors read and hashed directly from its two archive volumes, without full extraction.')
save(P/f'{stem}.json',manifest);save(S/'published.json',dict(manifest=ident(P/f'{stem}.json'),archives=archives,archive_verified_entries=len(entries),archived_bytes=sum(x['bytes']for x in files)))
print('PUBLISHED',len(files),'entries',sum(x['bytes']for x in archives),'compressed bytes',len(archives),'volumes')
