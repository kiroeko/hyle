"""One changed CUDA TU and its private Program host owner; retained SDK/closure."""
from pathlib import Path
import argparse,importlib.util,os,sys
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent;R=S.parents[1];D=R/'.scratch/qwen-cli-batch-20261022';A=R/'.scratch/architecture-refactor-2026-10-18'
sp=importlib.util.spec_from_file_location('helpers',D/'build.py');h=importlib.util.module_from_spec(sp);sp.loader.exec_module(h)
b,c=h.h.b,h.h.c
N=A/'ct-bf16-block128-reference/cuda-gather-capture/checks/attempt1/native-identity.json'
P=A/'ga-bf16-indexer-state-2026-10-21/common/checks/attempt1/cuda-collectives/identity.json'
T=A/'cccl-single-row-topk/checks/20261019T185912-host'
recipes={'provider':P,'direct-test':T/'direct-test-identity.json','graph-test':T/'graph-test-identity.json'}
sources={'provider':'src/compute_provider_cuda/collectives_provider.cc','direct-test':'tests/compute_provider_cuda/collectives_test.cc','graph-test':'tests/graph_route_cuda/topk_test.cc'}
def same(x):return b.identity(x['path'])==x
def compile_owner(tag,attempt):
    out=S/f'compile{attempt}'/tag;out.mkdir(parents=True,exist_ok=False);(out/'tmp').mkdir()
    recipe=N if tag=='native'else recipes[tag];prior=c.read(recipe)
    source=R/('src/compute_provider_cuda/collectives.cu'if tag=='native'else sources[tag])
    frozen=b.identity(source);frozen_header=b.identity(R/'src/compute_provider_cuda/collectives.h')
    if tag=='native':
        command=[];skip=False
        for arg in prior['command']:
            if skip:skip=False
            elif arg in('-c','-MT','-MF','-o'):skip=True
            else:command.append(arg)
        command+=['-c',str(source),'-MT',str(out/'native.obj'),'-MF',str(out/'native.d'),'-o',str(out/'native.obj')]
    else:
        command=b.host_command(prior['command'],source,tag,out)
        if '/WX'not in command:command.append('/WX')
        assert '/W4'in command and '/O2'in command and '/MD'in command
    snap=out/'source'/source.relative_to(R);snap.parent.mkdir(parents=True,exist_ok=True);snap.write_bytes(source.read_bytes())
    c.save(out/'plan.json',dict(command=command,source=frozen,private_header=frozen_header,recipe=b.identity(recipe),SDK_builds=0))
    environment_command=c.read(P)['command']if tag=='native'else command
    env,_=b.environment(environment_command,[],out);c.execute('compile',command,env,out)
    if tag=='native':deps=[source,R/'src/compute_provider_cuda/collectives.h',R/'src/compute_backend_cuda/device_status_kernel.h']
    else:
        rec=c.read(out/f'{tag}-deps.json')['Data'];deps=list(dict.fromkeys([rec['Source'],*rec['Includes']]))
    assert same(frozen)and same(frozen_header)
    record=dict(source=frozen,object=b.identity(out/f'{tag}.obj'),command=command,dependencies=[b.identity(x)for x in deps])
    if tag=='native':record['compiler_dependency_file']=b.identity(out/'native.d')
    c.save(out/'identity.json',record);print('COMPILED',tag,flush=True)
def link(mode,attempt,native_attempt,host_attempt,direct_attempt=None):
    base=c.read(D/'qwen-link3/link-plan.json');inputs=base['inputs']
    records=[S/f'compile{native_attempt}/native/identity.json',S/f'compile{host_attempt}/provider/identity.json']
    rr=[c.read(p)for p in records];assert all(same(x)for rec in rr for x in(rec['source'],rec['object'],*rec['dependencies']))
    replacements={c.key(c.read(N)['object']['path']):rr[0]['object'],c.key(c.read(P)['object']['path']):rr[1]['object']}
    assert all(sum(c.key(x['path'])==k for x in inputs)==1 for k in replacements)
    assert all(same(x)for x in inputs)
    command=[replacements.get(c.key(x),{}).get('path',x)for x in base['command']if not x.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:'))]
    inputs=[replacements.get(c.key(x['path']),x)for x in inputs]
    if mode=='tests':
        old_main=c.key(D/'compile4/qwen/qwen.obj')
        assert sum(c.key(x['path'])==old_main for x in inputs)==1
        command=[x for x in command if c.key(x)!=old_main];inputs=[x for x in inputs if c.key(x['path'])!=old_main]
        for tag in('direct-test','graph-test'):
            owner_attempt=direct_attempt if tag=='direct-test'and direct_attempt else host_attempt
            recpath=S/f'compile{owner_attempt}/{tag}/identity.json';rec=c.read(recpath)
            assert all(same(x)for x in(rec['source'],rec['object'],*rec['dependencies']))
            records.append(recpath);inputs.append(rec['object']);command.append(rec['object']['path'])
        gtest=c.read(R/'.scratch/multisequence-batch-20261021/arena-tests-link2/link-plan.json')
        extras=[x for x in gtest['inputs']if Path(x['path']).name in('gtest.lib','gtest_main.lib')]
        assert len(extras)==2 and all(same(x)for x in extras)
        inputs+=extras;command +=[x['path']for x in extras]
    out=S/f'{mode}-link{attempt}';out.mkdir(exist_ok=False);(out/'tmp').mkdir();image=out/f'{mode}.exe'
    command+=['/OUT:'+str(image),'/MAP:'+str(image.with_suffix('.map')),'/IMPLIB:'+str(image.with_suffix('.lib'))]
    c.save(out/'link-plan.json',dict(command=command,inputs=inputs,base=b.identity(D/'qwen-link3/link-plan.json'),compiled_records=[b.identity(p)for p in records],SDK_builds=0))
    env,_=b.environment(command,[x['path']for x in inputs],out);c.execute('link',command,env,out)
    for dll in(D/'qwen-link3').glob('*.dll'):os.link(dll,out/dll.name)
    runtime=c.read(D/'qwen-link3/runtime-environment.json');runtime['PATH']=env['PATH'];runtime['staged_dlls']=[b.identity(x)for x in out.glob('*.dll')];c.save(out/'runtime-environment.json',runtime)
    c.save(S/f'{mode}-ready-attempt{attempt}.json',dict(image=b.identity(image),source=b.identity(R/'tools/qwen35_text/main.cc')if mode=='qwen'else rr[0]['source'],changed_sources=[rec['source']for rec in rr],link_plan=b.identity(out/'link-plan.json'),runtime_environment=b.identity(out/'runtime-environment.json'),SDK_builds=0))
    print('READY',mode,flush=True)
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('mode',choices=('native','provider','direct-test','graph-test','qwen','tests'));p.add_argument('--attempt',type=int,default=1);p.add_argument('--native-attempt',type=int,default=1);p.add_argument('--host-attempt',type=int,default=1);p.add_argument('--direct-attempt',type=int);p.add_argument('--link',action='store_true');a=p.parse_args()
    if a.link:link(a.mode,a.attempt,a.native_attempt,a.host_attempt,a.direct_attempt)
    else:compile_owner(a.mode,a.attempt)
