"""Root-only one peer host TU/link; native libraries and model retained."""
from pathlib import Path
import importlib.util,os,sys
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent;R=S.parents[1]
sp=importlib.util.spec_from_file_location('retained_build',R/'.scratch/paged-host-prepare-20261021/build.py');h=importlib.util.module_from_spec(sp);sp.loader.exec_module(h)
b,c=h.b,h.c
plan=c.read(S/'peer/build-plan.json');out=S/'peer/checks/attempt1';out.mkdir(parents=True,exist_ok=False);(out/'tmp').mkdir()
source=S/'peer/peer_prefix_benchmark.cpp';frozen=b.identity(source)
for row in plan['preserved_library_inputs']:assert b.identity(row['path'])==row
c.save(out/'plan.json',plan);env,_=b.environment(plan['compile'],[],out);c.execute('compile',plan['compile'],env,out)
deps=c.read(out/'peer-deps.json')['Data'];record=dict(source=frozen,object=b.identity(out/'peer.obj'),command=plan['compile'],dependencies=[b.identity(p)for p in dict.fromkeys([deps['Source'],*deps['Includes']])])
assert h.h.same(frozen)and all(h.h.same(x)for x in record['dependencies']);c.save(out/'identity.json',record)
inputs=[record['object'],*plan['preserved_library_inputs']];c.save(out/'link-plan.json',dict(command=plan['link'],inputs=inputs,SDK_builds=0,NVCC=0))
env,_=b.environment(plan['link'],[x['path']for x in inputs],out);c.execute('link',plan['link'],env,out)
runtime=c.read(plan['original_runtime_environment']['path']);runtime['PATH']=env['PATH']
peer_dir=Path(c.read(plan['original_compile_identity']['path'])['object']['path']).parent
for dll in peer_dir.glob('*.dll'):os.link(dll,out/dll.name)
runtime['staged_dlls']=[b.identity(p)for p in out.glob('*.dll')];c.save(out/'runtime-environment.json',runtime)
c.save(S/'peer-ready-attempt1.json',dict(image=b.identity(out/'peer.exe'),source=frozen,compile_identity=b.identity(out/'identity.json'),link_plan=b.identity(out/'link-plan.json'),runtime_environment=b.identity(out/'runtime-environment.json'),SDK_builds=0,NVCC=0,CXX=1,links=1))
print('Peer ready; no native SDK/kernel/model build or GPU run.')
