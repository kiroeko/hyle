"""One actual long shared-prefix journey; no trace and no throughput conclusion."""
from pathlib import Path
import importlib.util,json,os,sys
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent;R=S.parents[1]
F=R/'.scratch/architecture-refactor-2026-10-18/d4-windows-preparation-2026-10-21/first-decode-startup-2026-10-21'
sp=importlib.util.spec_from_file_location('retained_multi_runner',F/'multiturn/multiturn_run.py');m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m)
ready_path=R/'.scratch/paged-host-prepare-20261021/qwen-ready-attempt3.json';ready=m.read(ready_path);image=m.ready_image(ready_path);plan=m.read(S/'inputs/plan.json')
original,_=m.original_commands();inputs=original[original.index('--inputs')+1]
out=S/'hyle-probe1'
command=[image['path'],'--inputs',inputs,'--session-schedules',plan['manifest']['path'],'--max-sessions','4','--active-sequences','1','--prefix-cache','auto','--capacity','256','--progress','direct','--replay','auto']
env=os.environ.copy();env['PATH']=m.read(ready['runtime_environment']['path'])['PATH']
m.execute(out,'hyle',command,env,False)
data=json.loads((out/'stdout.log').read_text(encoding='utf-8').splitlines()[-1]);m.save(out/'observation.json',data)
assert data['processed_tokens']==645 and data['generated_tokens']==102
assert data['actual_graph_calls']==101 and data['actual_graph_tokens']==258
assert data['prefix_hits']==3 and data['prefix_full_hits']==1 and data['reused_tokens']==387
assert sum(s['restored_calls']for s in data['sessions'])==0
assert sum(len(s['generated_ids'])for s in data['sessions'])==102
m.save(out/'summary.json',dict(passed=True,logical_tokens=645,outputs=102,actual_tokens=258,actual_graph_calls=101,prefix_hits=3,full_hits=1,reused_tokens=387,ready=m.identity(ready_path),input_plan=m.identity(S/'inputs/plan.json'),throughput_evidence=False))
print('Long shared-prefix actual journey passed:645logical/102IDs/258actual/101Graph/3hits/1fullhit/0restore.')
