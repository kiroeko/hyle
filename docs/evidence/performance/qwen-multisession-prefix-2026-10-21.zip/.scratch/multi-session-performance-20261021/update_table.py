"""Append independently recomputed prefix workload, separate from single-session table."""
from pathlib import Path
import json
S=Path(__file__).resolve().parent;R=S.parents[1]
t=json.loads((S/'performance/public-table.json').read_text(encoding='utf-8'));arms=('current','before','peer')
f=lambda a,k:t['arms'][a]['metrics'][k]['median']
lines=['### 多会话共享前缀：首轮完整对照','','**2026-10-21，4个命名会话、active1，按turn串行执行。** 一份权重／模型；真实P128＋D1检查点129，A／B分别补1／16token后各D32，完整命中129不执行模型，原seed再P16＋D32。两端逻辑645输入、102输出，实际161个prefill＋97个decode token、101次模型调用，3次前缀命中／1次完整命中，复用387token；无淘汰重建。本窗每臂3新进程交错，显存另各1进程。不是同时GPU批处理或多人线上吞吐。','',
'Hyle使用上表当前`e7a7597d…`与本批前`8a400ecf…`；参考新建有限多会话消费者，复用同一`d9e03f1074db…`库／模型，真实共享完整KV＋conv／GDN，逐序列保存next ID。短12输出／长102输出均已实测一致，长窗12个进程逐项核实际工作量和ID。参考使用统一1024物理KV行／5个native seq ID，单请求容量显式限256；Hyle池1040行／4份committed＋1份candidate，状态backing分别113,590,272／110,469,168字节，**不是相同字节配额**。','',
'| 指标 | 当前Hyle | 本批前Hyle | llama.cpp多会话消费者 |','| --- | ---: | ---: | ---: |']
def add(label,fn,digits=2):lines.append('| '+label+' | '+' | '.join(f'{fn(a):.{digits}f}'for a in arms)+' |')
for label,k in [('逻辑prefill tok/s（548／包含查询与准备的P墙时）','logical_prefill_tps'),('实际prefill tok/s（161／同一P墙时）','actual_prefill_tps'),('完整decode tok/s（97／D墙时）','decode_tps'),('综合输出 tok/s（102／全程墙时）','output_tps'),('逻辑处理 tok/s（645／全程墙时）','logical_session_tps')]:add(label,lambda a,k=k:f(a,k))
add('推理全程墙时 s',lambda a:f(a,'wall_seconds'),5)
add('含加载／启动至末输出 s',lambda a:f(a,'startup_total_seconds'),5)
add('权重加载 s',lambda a:f(a,'model_load_seconds'if a=='peer'else'weight_load_seconds'),5)
add('启动至ready s',lambda a:f(a,'ready_seconds'),5)
for label,k in [('GPU dedicated观测峰 GiB','gpu_dedicated_bytes'),('GPU shared观测峰 GiB','gpu_shared_bytes'),('GPU同点总量观测峰 GiB','gpu_total_bytes'),('CPU working set观测峰 GiB','working_set_bytes'),('进程private commit观测峰 GiB','private_commit_bytes')]:add(label,lambda a,k=k:t['memory'][a]['peaks_bytes'][k]/(1<<30),3)
lines+=['','当前相对本批前，实际prefill＋0.72%、decode＋2.33%、综合＋2.00%；相对参考，实际prefill慢39.72%、decode慢1.70%、综合慢8.66%。这是这一有限共享前缀窗口，不能与上面的单会话速率混算。含启动总完成时间当前约2.399s／参考2.689s，与推理阶段1.169s／1.067s是不同口径，均保留。','',
'按各臂3进程平均时长作可加分解，当前相对参考总墙差约106.1ms：prefill多88.0ms、decode多17.9ms、跨phase区间多0.1ms。prefill占约83%，**本场景的主要损项是输入与准备，不是decode**。','',
'| Prefill阶段（含各自真实查询／接纳／准备） | 当前Hyle ms | llama.cpp ms |','| --- | ---: | ---: |']
for label,key in [('seed实际P128','seed_round1_prefill'),('A命中129后实际T1','branch_a_round1_prefill'),('B命中129后实际T16','branch_b_round1_prefill'),('完整命中129／0Graph','full_hit_round1_prefill'),('seed第二轮实际T16','seed_round2_prefill')]:lines.append('| '+label+' | '+' | '.join(f"{t['arms'][a]['phases_seconds'][key]['median']*1000:.3f}"for a in ('current','peer'))+' |')
lines+=['','源码及日志均确认：active1仍在`create_session`为各驻留会话分别创建Phase／Invocation／IO／workspace。current的child准备桶中位seed约57.1ms、A约20.5ms、B约39.8ms。这些桶是阶段墙时的子区间，不能重复相加；源码中的重复构造可优先消除，不表示整桶都可省。下一批让完整状态留在Session，执行载体由Model按实际并发有界借用；不把必要工作移出总计时来制造改善。','',
'内存旁采请求10ms，实际间隔中位current／before／参考约'+'／'.join(f"{t['memory'][a]['actual_gaps_ms']['median']:.2f}"for a in arms)+'ms。每会话phase标记未被本轮采样器接收，**精确P／D显存变化未知**；ready两侧邻样也不是可靠phase基线。表中只报全程观测峰及同点总量，峰是采样下界，不将全局free变化或末尾退出当作进程分配收益。','',
'参考消费者首版不验证与Hyle等价的取消／失败回退，不测淘汰恢复；当前测量均成功完成。固定teacher-forced历史、原中间精度／logits回传差异继续明示，ID一致不作为独立质量证明。',
'[源码、完整命令、两组实际复用检查、12进程原始数据与独立复算](../evidence/performance/qwen-multisession-prefix-2026-10-21.json)。','']
p=R/'docs/developer/current-work.md';old=p.read_text(encoding='utf-8');assert '### 多会话共享前缀：首轮完整对照'not in old;p.write_text(old+'\n'+'\n'.join(lines),encoding='utf-8')
print('Appended real same-work prefix comparison; unknown phase memory remains unknown.')
