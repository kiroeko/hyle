"""Root serial real peer prefix check; no throughput conclusion."""
from pathlib import Path
import importlib.util,json,os,sys
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent;R=S.parents[1]
F=R/'.scratch/architecture-refactor-2026-10-18/d4-windows-preparation-2026-10-21/first-decode-startup-2026-10-21'
sp=importlib.util.spec_from_file_location('retained_runner',F/'multiturn/multiturn_run.py');m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m)
ready_path=S/'peer-ready-attempt1.json';ready=m.read(ready_path);image=m.ready_image(ready_path)
long=len(sys.argv)>1 and sys.argv[1]=='long'
manifest=S/'inputs/long/sessions.txt'if long else R/'.scratch/qwen-prefix-20261021/inputs/branches.txt'
out=S/('peer-long-probe1'if long else'peer-short-probe1')
_,original=m.original_commands();model=original[1]
command=[image['path'],model,'--session-schedules',str(manifest),'--capacity','256','--cache-slots','4','--pool-tokens','1024','--result',str(out/'peer.json')]
env=os.environ.copy();env['PATH']=m.read(ready['runtime_environment']['path'])['PATH']
m.execute(out,'peer',command,env,False)
data=m.read(out/'peer.json');before=m.read(S/'hyle-probe1/observation.json'if long else R/'.scratch/paged-exclusive-20261021/main-run1/observation.json')
fields=['processed_tokens','generated_tokens','actual_graph_calls','actual_graph_tokens','prefix_hits','prefix_misses','prefix_full_hits','reused_tokens']
assert all(data[k]==before[k]for k in fields),{k:(data[k],before[k])for k in fields}
for a,b in zip(data['sessions'],before['sessions']):assert a['id']==b['session_id']and a['visible_tokens']==b['visible_tokens']and a['generated_ids']==b['generated_ids'],(a['id'],a['generated_ids'],b['generated_ids'])
m.save(out/'summary.json',dict(passed=True,same_work={k:data[k]for k in fields},same_all_session_ids_and_predictions=True,native_n_ctx=data['native_n_ctx'],native_n_ctx_seq=data['native_n_ctx_seq'],native_sequence_quota=data['native_sequence_quota'],native_cache_bytes=data['cache_backing_bytes'],current_hyle_state_backing=before['cache_shared_backing_bytes'],throughput_evidence=False))
print(json.dumps(m.read(out/'summary.json'),indent=2))
