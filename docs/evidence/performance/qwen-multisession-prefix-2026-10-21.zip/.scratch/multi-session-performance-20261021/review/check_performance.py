"""Independent pure-host review of retained raw results; never starts a consumer."""
from pathlib import Path
import collections, hashlib, json, re, statistics

M = Path(__file__).resolve().parents[1]
R = M.parents[1]
P = M / 'performance'
ARMS = ('current', 'before', 'peer')
EXPECT = dict(processed_tokens=645, generated_tokens=102, actual_graph_calls=101,
              actual_graph_tokens=258, prefix_hits=3, prefix_misses=2,
              prefix_full_hits=1, reused_tokens=387)
RECEIPTS = dict(current=R/'.scratch/paged-host-prepare-20261021/qwen-ready-attempt3.json',
                before=R/'.scratch/paged-exclusive-20261021/qwen-ready-attempt1.json',
                peer=M/'peer-ready-attempt1.json')

def read(p): return json.loads(Path(p).read_text(encoding='utf-8'))
def ident(p):
    p = Path(p); b = p.read_bytes()
    return dict(path=str(p.relative_to(R)), bytes=len(b), sha256=hashlib.sha256(b).hexdigest())
def stats(xs):
    return dict(count=len(xs), min=min(xs), median=statistics.median(xs), max=max(xs), samples=xs)
def save(p, v): p.write_text(json.dumps(v, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
def raw(folder, arm):
    return read(folder/'peer-result.json') if arm == 'peer' else json.loads((folder/'stdout.log').read_text().splitlines()[-1])

def hyle_steps(text):
    session = None; prepared = None; result = []; cold = collections.defaultdict(list); active = None
    for line in text.splitlines():
        m = re.fullmatch(r'memory_phase=(.+)_begin', line)
        if m: active = m[1]
        m = re.fullmatch(r'memory_phase=(.+)_end', line)
        if m: active = None
        m = re.search(r'^compiled T=(\d+).*child_prepare_seconds=([\deE.+-]+)$', line)
        if m:
            assert active is not None
            cold[active].append(dict(T=int(m[1]), seconds=float(m[2])))
        m = re.fullmatch(r'session_steps id=(\S+)', line)
        if m: session = m[1]
        m = re.fullmatch(r'prepared T=(\d+) visible=(\d+) replay=(\S+) cold_batch_seconds=([\deE.+-]+) capture_recorded=(\d+) capture_reused=(\d+)', line)
        if m: prepared = dict(T=int(m[1]), visible=int(m[2]), replay=m[3], cold=float(m[4]), recorded=int(m[5]), reused=int(m[6]))
        m = re.fullmatch(r'(round\d+_(?:prefill|decode\d+)) tokens=(\d+) visible=(\d+) seconds=([\deE.+-]+) submit_seconds=([\deE.+-]+) step_seconds=([\deE.+-]+) progress=(\S+) next=(\d+)', line)
        if m:
            assert session is not None
            result.append(dict(session=session, name=m[1], logical=int(m[2]), visible=int(m[3]),
                submitted_execution_publish_seconds=float(m[4]), submit_seconds=float(m[5]),
                step_seconds=float(m[6]), next=int(m[8]), graph=prepared is not None,
                graph_tokens=prepared['T'] if prepared else 0, preparation=prepared))
            prepared = None
    return result, dict(cold)

reference = None
rows = []
image_receipts = {a:read(p) for a,p in RECEIPTS.items()}
for source in image_receipts['current']['fresh_sources']:
    assert ident(source['path'])['sha256'] == source['sha256']
assert ident(image_receipts['peer']['source']['path'])['sha256'] == image_receipts['peer']['source']['sha256']
for mode, expected_order in [('timing',['current','before','peer','peer','before','current','before','current','peer']),
                              ('memory',['before','current','peer'])]:
    folders = sorted(p for p in (P/mode).iterdir() if p.is_dir())
    assert [p.name.split('-',1)[1] for p in folders] == expected_order
    previous_end = 0
    for folder in folders:
        arm = folder.name.split('-',1)[1]; proc = read(folder/'result.json'); d = raw(folder, arm)
        assert proc['exit'] == 0 and not proc['reader_errors']
        assert proc['memory_only'] == (mode == 'memory') and not proc['profiler']
        assert proc['started_unix_ns'] >= previous_end
        previous_end = proc['finished_unix_ns']
        assert proc['image'] == image_receipts[arm]['image']
        assert all(d[k] == v for k,v in EXPECT.items())
        ids = {s.get('session_id',s.get('id')):s['generated_ids'] for s in d['sessions']}
        if reference is None: reference = ids
        assert ids == reference and sum(map(len,ids.values())) == 102
        phase_map = {s.get('session_id',s.get('id'))+'_'+p['name']:p for s in d['sessions'] for p in s['phases']}
        assert len(phase_map) == 9
        assert sum(p['input_tokens'] for p in phase_map.values() if p['kind']=='prefill') == 548
        assert sum(p['input_tokens'] for p in phase_map.values() if p['kind']=='decode') == 97
        assert {k:(v['context_before'],v['context_after']) for k,v in phase_map.items()} == {
            'seed_round1_prefill':(0,128),'seed_round1_decode':(128,129),
            'seed_round2_prefill':(129,145),'seed_round2_decode':(145,177),
            'branch_a_round1_prefill':(0,130),'branch_a_round1_decode':(130,162),
            'branch_b_round1_prefill':(0,145),'branch_b_round1_decode':(145,177),
            'full_hit_round1_prefill':(0,129)}
        pref = sum(v['seconds'] for v in phase_map.values() if v['kind']=='prefill')
        dec = sum(v['seconds'] for v in phase_map.values() if v['kind']=='decode')
        wall = d['session_seconds' if arm=='peer' else 'interleaved_seconds']
        stderr = (folder/'stderr.log').read_text()
        if arm == 'peer':
            steps = d['steps']; cold = {}
            assert len(steps)==102 and sum(v['graph_tokens']>0 for v in steps)==101
            assert sum(v['graph_tokens'] for v in steps)==258
            assert sum(v['reused_tokens'] for v in steps)==387
            full = [v for v in steps if v['full_hit']]
            assert len(full)==1 and full[0]['session']=='full_hit' and full[0]['graph_tokens']==0
            assert full[0]['predicted_id']==ids['seed'][1] and full[0]['sampled_logits_elements']==0
            assert d['native_n_ctx_seq']==1024 and d['native_sequence_quota']==5 and d['kv_unified']
            assert d['cache_backing_bytes']==113590272 and d['peak_native_versions']<=5
            assert d['restored_calls']==d['restored_tokens']==0
            graph_by_session = {s:sum(v['graph_tokens'] for v in steps if v['session']==s) for s in ids}
            native_details = dict(seq_copy_calls=d['seq_copy_api_calls'], prefix_entry_evictions=d['directory_evictions'],
                                  peak_native_versions=d['peak_native_versions'])
        else:
            steps,cold = hyle_steps(stderr)
            assert len(steps)==102 and sum(v['graph'] for v in steps)==101
            assert sum(v['graph_tokens'] for v in steps)==258
            assert [v for v in steps if not v['graph']][0]['session']=='full_hit'
            assert [v for v in steps if not v['graph']][0]['next']==ids['seed'][1]
            assert d['cache_shared_backing_bytes']==110469168 and d['cache_max_physical_pages']==65
            assert d['cache_peak_committed_versions']<=4 and not d['evicted_session_ids']
            assert all(s['restored_calls']==s['restored_tokens']==0 for s in d['sessions'])
            assert d['cache_live_requested_bytes']==d['cache_peak_requested_bytes']==110469168
            assert {s:[v['next'] for v in steps if v['session']==s] for s in ids}==ids
            graph_by_session = {s:sum(v['graph_tokens'] for v in steps if v['session']==s) for s in ids}
            native_details = dict(capture_recorded=sum(v['preparation']['recorded'] for v in steps if v['graph']),
                capture_reused=sum(v['preparation']['reused'] for v in steps if v['graph']),
                prefix_entry_evictions=d['prefix_evictions'],
                pure_decode_reuse_cold_seconds=[v['preparation']['cold'] for v in steps if 'decode' in v['name'] and v['graph'] and not v['preparation']['recorded'] and v['preparation']['reused']])
        assert graph_by_session == dict(seed=177,branch_a=33,branch_b=48,full_hit=0)
        loads = dict(startup_total_seconds=d['startup_total_seconds'])
        if arm=='peer': loads.update(model_load_seconds=d['model_load_seconds'], context_seconds=d['context_seconds'], ready_seconds=d['ready_seconds'])
        else:
            m=re.search(r'weights_load_seconds=([\deE.+-]+)',stderr); loads['weight_load_seconds']=float(m[1])
            m=re.search(r'initialized model_seconds=([\deE.+-]+) shape_prepare_seconds=([\deE.+-]+) startup_to_ready_seconds=([\deE.+-]+)',stderr)
            loads.update(model_seconds=float(m[1]), shape_prepare_seconds=float(m[2]), ready_seconds=float(m[3]))
        rows.append(dict(mode=mode,arm=arm,folder=str(folder.relative_to(R)),result=ident(folder/'result.json'),
            raw=ident(folder/('peer-result.json' if arm=='peer' else 'stdout.log')),stderr=ident(folder/'stderr.log'),
            metrics=dict(logical_prefill_tps=548/pref,actual_prefill_tps=161/pref,decode_tps=97/dec,
                         output_tps=102/wall,logical_session_tps=645/wall,actual_session_tps=258/wall,
                         prefill_seconds=pref,decode_seconds=dec,wall_seconds=wall,between_phase_seconds=wall-pref-dec,**loads),
            phases={k:v['seconds'] for k,v in phase_map.items()},children=cold,
            session_wall_seconds={s.get('session_id',s.get('id')):s.get('session_wall_seconds',s.get('session_seconds')) for s in d['sessions']},
            native_details=native_details))

timing = [r for r in rows if r['mode']=='timing']
arms = {}
for arm in ARMS:
    rs=[r for r in timing if r['arm']==arm]
    arms[arm]=dict(metrics={k:stats([r['metrics'][k] for r in rs]) for k in rs[0]['metrics']},
        phases_seconds={k:stats([r['phases'][k] for r in rs]) for k in rs[0]['phases']},
        pooled_rates=dict(logical_prefill_tps=1644/sum(r['metrics']['prefill_seconds'] for r in rs),
                          actual_prefill_tps=483/sum(r['metrics']['prefill_seconds'] for r in rs),
                          decode_tps=291/sum(r['metrics']['decode_seconds'] for r in rs),
                          output_tps=306/sum(r['metrics']['wall_seconds'] for r in rs)))
    if arm!='peer':
        arms[arm]['child_prepare_seconds_by_phase']={k:stats([sum(c['seconds'] for c in r['children'].get(k,[])) for r in rs]) for k in ('seed_round1_prefill','branch_a_round1_prefill','branch_b_round1_prefill')}

memory={}
for row in (r for r in rows if r['mode']=='memory'):
    folder=R/row['folder']; mem=read(folder/'memory.json'); proc=read(folder/'result.json')
    samples=[s for s in mem['samples'] if s['process_running']]
    fields=['working_set_bytes','os_peak_working_set_bytes','private_commit_bytes','os_peak_commit_bytes','gpu_dedicated_bytes','gpu_shared_bytes','gpu_total_bytes']
    peaks={k:max((s[k] for s in samples if s.get(k) is not None),default=None) for k in fields}
    gaps=[(b['timestamp_ns']-a['timestamp_ns'])/1e6 for a,b in zip(samples,samples[1:])]
    name='ready_before_first' if row['arm']=='peer' else 'ready_before_prefill'
    ready=next(v['timestamp_ns'] for v in proc['markers'] if v['name']==name)
    before=[s for s in samples if s['timestamp_ns']<=ready];after=[s for s in samples if s['timestamp_ns']>=ready]
    def adjacent(s):return dict(distance_ms=(s['timestamp_ns']-ready)/1e6,**{k:s.get(k) for k in fields}) if s else None
    memory[row['arm']]=dict(raw=ident(folder/'memory.json'),running_samples=len(samples),requested_interval_seconds=mem['requested_interval_s'],
        actual_gaps_ms=stats(gaps),peaks_bytes=peaks,ready_adjacent_before=adjacent(before[-1] if before else None),
        ready_adjacent_after=adjacent(after[0] if after else None),ready_phase_delta_bytes=None,
        phase_delta_limit='No received per-session phase markers in retained process result. Adjacent ready samples are not a proven prefill baseline; no precise per-phase VRAM delta is reported.')

changes={other:{k:(arms['current']['metrics'][k]['median']/arms[other]['metrics'][k]['median']-1)*100 for k in ('logical_prefill_tps','actual_prefill_tps','decode_tps','output_tps')} for other in ('before','peer')}
mean={a:{k:statistics.mean(r['metrics'][k] for r in timing if r['arm']==a) for k in ('prefill_seconds','decode_seconds','wall_seconds','between_phase_seconds')} for a in ARMS}
delta={k:mean['current'][k]-mean['peer'][k] for k in mean['current']}
delta['prefill_fraction_of_mean_wall_gap']=delta['prefill_seconds']/delta['wall_seconds']
table=dict(workload=EXPECT,logical_prefill_tokens=548,actual_prefill_tokens=161,decode_tokens=97,whole_wall_outputs=102,
    timing_processes_per_arm=3,memory_processes_per_arm=1,arms=arms,memory=memory,
    current_vs_other_median_rate_change_percent=changes,mean_current_minus_peer_seconds=delta,
    source_rows=rows,
    limits=['Teacher-forced fixed tokens; four named resident sessions, serial active1 turn cohorts. No simultaneous-user throughput claim.',
      'Whole-session output rate is 102 / one global wall. Per-session residence walls overlap and must never be summed.',
      'Logical P rate includes 387 reused tokens. Actual P uses161; neither is pure kernel/device throughput.',
      'Native backing is113590272B with1024 unified KV token cells; Hyle backing110469168B with65*16=1040 physical page rows. Equal logical capacity/N, different physical provisioning.',
      'One process memory run per arm; current CPU/GPU peaks are sampled lower bounds, not synchronized exact allocation deltas. CPU commit/WS and GPU shared must not be added.',
      'Only3 timing processes per arm, one serial window, uncontrolled system/driver clocks. No universal/stable performance ranking.',
      'Prefix-directory entry evictions occur, but no resident-session eviction/restore or failure/cancellation workload is exercised.',
      'Peer optional cache-byte limit is0 in this workload; its fixed pool sizes are checked after context allocation. This comparison does not certify Hyle-equivalent early budget rejection/rollback.'])
save(P/'public-table.json',table)

current_plan=read(image_receipts['current']['link_plan']['path']);before_plan=read(image_receipts['before']['link_plan']['path'])
assert len(current_plan['inputs'])==len(before_plan['inputs'])==195
changed=[dict(before=a,after=b) for a,b in zip(before_plan['inputs'],current_plan['inputs']) if a['sha256']!=b['sha256']]
assert len(changed)==2
for name,calls,tokens,outputs in [('hyle-probe1',101,258,102),('peer-short-probe1',11,168,12),('peer-long-probe1',101,258,102)]:
    folder=M/name
    assert read(folder/'result.json')['exit']==0 and read(folder/'summary.json')['passed']
    d=read(folder/('peer.json' if name.startswith('peer') else 'observation.json'))
    assert (d['actual_graph_calls'],d['actual_graph_tokens'],d['generated_tokens'])==(calls,tokens,outputs)
    if outputs==102: assert {s.get('session_id',s.get('id')):s['generated_ids'] for s in d['sessions']}==reference
review=dict(status='All nine timing and three memory raw processes independently checked; all exit0, same102 IDs and work counters. No additional GPU/build/model execution.',
    table=ident(P/'public-table.json'),checker=ident(Path(__file__)),images={a:image_receipts[a]['image'] for a in ARMS},
    changed_hyle_link_inputs=changed,all_ids=reference,
    primary_findings=[
      'Mean duration differences are additive host service buckets, not kernel attribution. Prefill dominates the current/peer global-wall gap in this window; per-phase values remain available.',
      'Hyle create_session cold-prepares every unique remaining T for that Session and prepare_child initializes both Invocation parity slots. Immutable state sharing does not yet share these execution carriers across idle resident Sessions.',
      'Actual child_prepare_seconds are measured inside seed/A/B request phase walls. They include private Phase IO/Invocation setup; they are not model Graph compilation, which completed before ready.',
      'Peer uses one native context. llama_memory_hybrid::seq_cp delegates to both attention and recurrent stores. Recurrent seq_cp preserves tail ownership; subsequent find_slot selects a distinct cell for a shared tail and materializes source mapping in real decode.',
      'Peer prefix copy API time alone is not full recurrent-copy cost. Deferred native copying stays in subsequent llama_decode and synchronized request/phase/global timing.',
      'Fullhit returns the stored129 checkpoint next ID with zero Graph/decode and zero fake tensor payload. This was checked from raw steps/counters, not merely common IDs.',
      'No new claim of full numerical equivalence: this comparison checks host greedy IDs and actual work/callback fields, plus retained earlier correctness/probe evidence. It does not compare all model tensors between engines.'
    ],
    narrow_next_candidate='Separate Session immutable Snapshot/history/tail authority from reusable execution carriers. Size original Invocation/IO/workspace sets by actual in-flight concurrency and finite T, rebind fresh state permissions after original take/unbind/retirement; preserve independent old snapshots and prohibit simultaneous use of one slot. Do not add another executor or a provider/model-special fast path.',
    source_anchors=[
      dict(source=ident(R/'tools/qwen35_text/main.cc'),anchors='1051-1095;1101-1117;1120-1213;1933-2076',fact='Per-session unique-T cold preparation, two slots, original request timing and post-endpoint checkpoint publication.'),
      dict(source=ident(M/'peer/peer_prefix_benchmark.cpp'),anchors='31-104;228-321;343-378',fact='Bounded real Version owners, native seq copy/decode/synchronize, same request/global timer, directory publication after endpoint.'),
      dict(source=ident(R/'.scratch/architecture-refactor-2026-10-18/llama-matched-consumer/source/src/llama-memory-hybrid.cpp'),anchors='152-154',fact='Actual hybrid sequence copy includes both attention and recurrent cache.'),
      dict(source=ident(R/'.scratch/architecture-refactor-2026-10-18/llama-matched-consumer/source/src/llama-memory-recurrent.cpp'),anchors='249-283;588-622;674-702',fact='Real recurrent tail sharing, copy-on-write and deferred source mapping.')],
    retained_probe_results=[ident(M/'hyle-probe1/result.json'),ident(M/'hyle-probe1/summary.json'),
      ident(M/'peer-short-probe1/result.json'),ident(M/'peer-short-probe1/summary.json'),
      ident(M/'peer-long-probe1/result.json'),ident(M/'peer-long-probe1/summary.json')],
    gpu_window_snapshots={mode:{side:(P/mode/f'window-{side}-gpu.stdout.log').read_text().strip() for side in ('before','after')} for mode in ('timing','memory')},
    window_limit='Before/after GPU utilization are rolling snapshots, not per-process external-load measurements. SM clocks rose210 to2820/2835MHz; clocks were not fixed. No causal attribution from these snapshots.',
    memory_limit='Retained marker parser records ready but not per-session phase markers. Phase-specific memory changes are unavailable, not zero. Adjacent ready samples are shown only with their actual time distance.')
save(M/'review/performance-review.json',review)
print(json.dumps(dict(table=ident(P/'public-table.json'),review=ident(M/'review/performance-review.json'),median={a:{k:arms[a]['metrics'][k]['median'] for k in ('actual_prefill_tps','decode_tps','output_tps')} for a in ARMS},current_vs_other=changes,mean_gap=delta),ensure_ascii=False))
