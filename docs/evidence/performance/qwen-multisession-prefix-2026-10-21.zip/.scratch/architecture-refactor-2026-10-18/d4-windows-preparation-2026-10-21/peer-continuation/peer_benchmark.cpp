// Measurement consumer only: public llama/ggml APIs, original model/runtime/math.
// Teacher-forced input tokens keep observations on the same fixed prefix; bounded extended loop.
#include "llama.h"
#include "ggml-backend.h"
#include "nlohmann/json.hpp"
#include "tools/qwen35_text/schedule.h"

#include <algorithm>
#include <array>
#include <chrono>
#include <cstdint>
#include <cstdlib>
#include <fstream>
#include <iostream>
#include <memory>
#include <limits>
#include <stdexcept>
#include <string>
#include <vector>

#if defined(_WIN32)
#define NOMINMAX
#define WIN32_LEAN_AND_MEAN
#define PSAPI_VERSION 2
#include <windows.h>
#include <psapi.h>
#endif

using json = nlohmann::ordered_json;
using Clock = std::chrono::steady_clock;
using Point = Clock::time_point;

struct Backend {
    Backend() { llama_backend_init(); }
    ~Backend() { llama_backend_free(); }
};
struct Batch {
    llama_batch value;
    explicit Batch(int32_t capacity) : value(llama_batch_init(capacity, 0, 1)) {}
    ~Batch() { llama_batch_free(value); }
};
struct Step {
    int index = 0, input_count = 0, visible_tokens = 0;
    llama_token predicted = LLAMA_TOKEN_NULL;
    double input_prepare = 0, decode_return = 0, synchronize = 0;
    double logits_access = 0, greedy_select = 0, total = 0;
    std::uint32_t sampled_logits_count = 0;
};
struct Memory {
    const char * name = "";
    double elapsed = 0, snapshot_seconds = 0;
    std::uint64_t unix_ms = 0;
    bool process_available = false, device_available = false;
    std::uint64_t working_set = 0, peak_working_set = 0, private_commit = 0, peak_commit = 0;
    std::uint64_t device_free = 0, device_total = 0;
    unsigned long process_error = 0;
};
static double seconds(Point end, Point start) {
    return std::chrono::duration<double>(end - start).count();
}
static Memory memory(const char * name, Point start, ggml_backend_dev_t device = nullptr) {
    const auto begin = Clock::now();
    Memory result;
    result.name = name;
    result.elapsed = seconds(begin, start);
    result.unix_ms = std::chrono::duration_cast<std::chrono::milliseconds>(
        std::chrono::system_clock::now().time_since_epoch()).count();
#if defined(_WIN32)
    PROCESS_MEMORY_COUNTERS_EX counters{};
    counters.cb = sizeof(counters);
    if (GetProcessMemoryInfo(GetCurrentProcess(), reinterpret_cast<PROCESS_MEMORY_COUNTERS *>(&counters), sizeof(counters))) {
        result.process_available = true;
        result.working_set = counters.WorkingSetSize;
        result.peak_working_set = counters.PeakWorkingSetSize;
        result.private_commit = counters.PrivateUsage;
        result.peak_commit = counters.PeakPagefileUsage;
    } else {
        result.process_error = GetLastError();
    }
#endif
    if (device) {
        size_t free = 0, total = 0;
        ggml_backend_dev_memory(device, &free, &total);
        result.device_available = total != 0 && free <= total;
        result.device_free = free;
        result.device_total = total;
    }
    std::cerr << "measure_memory name=" << name << " elapsed_seconds=" << result.elapsed
              << " unix_ms=" << result.unix_ms << '\n';
    result.snapshot_seconds = seconds(Clock::now(), begin);
    return result;
}

static int run(const char * model_path, const char * fixed_path, const char * output_path) {
    const auto startup = Clock::now();
    std::array<Memory, 8> snapshots{};
    size_t snapshot_count = 0;
    snapshots[snapshot_count++] = memory("run_entry", startup);
    std::ifstream input(fixed_path);
    if (!input) throw std::runtime_error("cannot open fixed inputs");
    const auto fixed = json::parse(input);
    const auto prompt = fixed.at("prompt_ids").get<std::vector<llama_token>>();
    const auto decode = fixed.at("decode_input_ids").get<std::vector<llama_token>>();
    const auto continuation = fixed.value("continuation_ids", std::vector<llama_token>{});
    const auto targets = fixed.value("target_ids", std::vector<llama_token>{});
    const auto continuation_phases = continuation.empty() ? std::size_t{0} : std::size_t{1};
    if (prompt.empty() || prompt.size() > 224 || decode.empty() || decode.size() > 127 ||
        continuation.size() > 224 || prompt.size() + continuation.size() + decode.size() > 256 ||
        (!targets.empty() && targets.size() != decode.size() + 1 + continuation_phases))
        throw std::runtime_error("expected bounded prompt, optional continuation, and 1..127 fixed decode IDs within context256");
    const auto batch_capacity = static_cast<std::uint32_t>(
        std::max({std::size_t{64}, prompt.size(), continuation.size()}));

    const auto backend_start = Clock::now();
    Backend backend;
    auto * device = ggml_backend_dev_by_name("CUDA0");
    if (!device || ggml_backend_dev_type(device) != GGML_BACKEND_DEVICE_TYPE_GPU)
        throw std::runtime_error("CUDA0 GPU is required");
    ggml_backend_dev_t devices[] = {device, nullptr};
    const auto backend_end = Clock::now();
    snapshots[snapshot_count++] = memory("backend_ready_before_model", startup, device);
    auto model_params = llama_model_default_params();
    model_params.devices = devices;
    model_params.n_gpu_layers = 999;
    // Original public override: input embedding and its tied output use the same CUDA buffer type.
    // The original loader reuses the existing tensor when TENSOR_DUPLICATED resolves to that same context.
    const llama_model_tensor_buft_override overrides[] = {
        {"^token_embd\\.weight$", ggml_backend_dev_buffer_type(device)}, {nullptr, nullptr}};
    model_params.tensor_buft_overrides = overrides;
    using Model = std::unique_ptr<llama_model, decltype(&llama_model_free)>;
    const auto model_start = Clock::now();
    Model model(llama_model_load_from_file(model_path, model_params), &llama_model_free);
    const auto model_end = Clock::now();
    if (!model || llama_model_n_layer(model.get()) != 24)
        throw std::runtime_error("expected the full 24-layer Qwen3.5-2B model");
    snapshots[snapshot_count++] = memory("model_loaded", startup, device);

    // Original public chain reuses its candidate buffer after the first sample.
    // Original public backend sampling attaches this chain before native context reserve.
    using Sampler = std::unique_ptr<llama_sampler, decltype(&llama_sampler_free)>;
    Sampler sampler(llama_sampler_chain_init(llama_sampler_chain_default_params()), &llama_sampler_free);
    llama_sampler_chain_add(sampler.get(), llama_sampler_init_greedy());
    auto context_params = llama_context_default_params();
    context_params.n_ctx = 256;
    context_params.n_batch = batch_capacity;
    context_params.n_ubatch = batch_capacity;
    context_params.n_seq_max = 1;
    context_params.n_threads = 24;
    context_params.n_threads_batch = 24;
    context_params.type_k = GGML_TYPE_BF16;
    context_params.type_v = GGML_TYPE_BF16;
    context_params.flash_attn_type = LLAMA_FLASH_ATTN_TYPE_ENABLED;
    llama_sampler_seq_config sampler_config{0, sampler.get()};
    context_params.samplers = &sampler_config;
    context_params.n_samplers = 1;
    // Do not enable nextn/embedding taps or masked early row slicing.
    using Context = std::unique_ptr<llama_context, decltype(&llama_free)>;
    const auto context_start = Clock::now();
    Context context(llama_init_from_model(model.get(), context_params), &llama_free);
    const auto context_end = Clock::now();
    if (!context || llama_n_ctx(context.get()) != 256)
        throw std::runtime_error("context creation did not preserve capacity 256");
    const auto * vocab = llama_model_get_vocab(model.get());
    const int vocabulary = llama_vocab_n_tokens(vocab);
    for (const auto & ids : {prompt, continuation, decode})
        for (const auto token : ids)
            if (token < 0 || token >= vocabulary) throw std::runtime_error("input token out of vocabulary");

    Batch batch(static_cast<int32_t>(batch_capacity));
    std::vector<Step> steps(decode.size() + 1 + continuation_phases);
    double first_token_elapsed_seconds = 0;
    const auto actual_context = llama_n_ctx(context.get());
    const auto ready = Clock::now();
    snapshots[snapshot_count++] = memory("ready_before_prefill", startup, device);
    int position = 0;
    for (int phase = 0; phase != int(steps.size()); ++phase) {
        const bool is_continuation = continuation_phases != 0 && phase == 1;
        const auto decode_index = phase - 1 - static_cast<int>(continuation_phases);
        const int count = phase == 0 ? int(prompt.size()) : is_continuation ? int(continuation.size()) : 1;
        const auto start = Clock::now(); // before any input batch preparation
        batch.value.n_tokens = count;
        for (int i = 0; i != count; ++i) {
            batch.value.token[i] = phase == 0 ? prompt[size_t(i)]
                : is_continuation ? continuation[size_t(i)] : decode[size_t(decode_index)];
            batch.value.pos[i] = position + i;
            batch.value.n_seq_id[i] = 1;
            batch.value.seq_id[i][0] = 0;
            batch.value.logits[i] = i == count - 1;
        }
        const auto prepared = Clock::now();
        const auto status = llama_decode(context.get(), batch.value);
        const auto decoded = Clock::now();
        if (status != 0) throw std::runtime_error("llama_decode failed: " + std::to_string(status));
        llama_synchronize(context.get());
        const auto synchronized = Clock::now();
        const auto backend_token = llama_get_sampled_token_ith(context.get(), -1);
        if (backend_token == LLAMA_TOKEN_NULL) throw std::runtime_error("backend greedy did not produce a token; CPU fallback rejected");
        const auto token_access = Clock::now();
        const auto predicted = llama_sampler_sample(sampler.get(), context.get(), -1);
        if (predicted != backend_token) throw std::runtime_error("public sample differs from backend token");
        const auto selected = Clock::now(); // actual greedy token already selected on host
        if (phase == 0) first_token_elapsed_seconds = seconds(selected, startup);
        position += count;
        steps[size_t(phase)] = Step{phase, count, position, predicted,
            seconds(prepared, start), seconds(decoded, prepared), seconds(synchronized, decoded),
            seconds(token_access, synchronized), seconds(selected, token_access), seconds(selected, start)};
        // Metadata query after the endpoint-complete timer; decode already synchronized all readbacks.
        steps[size_t(phase)].sampled_logits_count = llama_get_sampled_logits_count_ith(context.get(), -1);
        if (phase == 0) snapshots[snapshot_count++] = memory("prefill_complete", startup, device);
    }
    snapshots[snapshot_count++] = memory("inference_complete", startup, device);
    context.reset();
    sampler.reset();
    model.reset();
    snapshots[snapshot_count++] = memory("model_context_released_backend_alive", startup, device);

    // Reporting and all filesystem I/O occur outside the measured step windows.
    json result;
    result["llama_commit"] = "d9e03f1074dbd2979126d91dce1b5d304ec8394e";
    result["model"] = model_path;
    result["fixed_inputs"] = fixed_path;
    result["device"] = ggml_backend_dev_name(device);
    result["device_description"] = ggml_backend_dev_description(device);
    result["context_capacity"] = actual_context;
    result["configured_batch_capacity"] = batch_capacity;
    result["quality_targets_available"] = !targets.empty();
    result["full_cuda_embedding_override"] = "^token_embd\\.weight$ -> CUDA0 buffer, original public tensor_buft_overrides";
    result["tied_embedding_source_proof"] = "Original qwen35 loader uses TENSOR_DUPLICATED; same CUDA buffer type context returns existing token_embd tensor before creating a duplicate.";
    result["loading"] = {{"backend_setup_seconds", seconds(backend_end, backend_start)},
        {"model_load_seconds", seconds(model_end, model_start)},
        {"context_prepare_seconds", seconds(context_end, context_start)},
        {"startup_to_ready_seconds", seconds(ready, startup)},
        {"first_token_elapsed_seconds", first_token_elapsed_seconds},
        {"model_load_boundary", "llama_model_load_from_file call; original loader synchronizes async uploads before return, mmap/lazy defaults preserved"},
        {"ready_boundary", "run entry before JSON read -> original model/context/sampler/batch ready, excluding following ready snapshot"}};
    result["memory"] = json::array();
    for (size_t i = 0; i != snapshot_count; ++i) {
        const auto & sample = snapshots[i];
        result["memory"].push_back({{"name", sample.name}, {"elapsed_seconds", sample.elapsed},
            {"unix_ms", sample.unix_ms}, {"snapshot_seconds", sample.snapshot_seconds},
            {"process_available", sample.process_available}, {"process_error", sample.process_error},
            {"working_set_bytes", sample.working_set}, {"peak_working_set_bytes", sample.peak_working_set},
            {"private_commit_bytes", sample.private_commit}, {"peak_commit_bytes", sample.peak_commit},
            {"device_available", sample.device_available}, {"device_free_bytes", sample.device_free},
            {"device_total_bytes", sample.device_total},
            {"device_global_used_bytes", sample.device_available ? sample.device_total - sample.device_free : 0}});
    }
    result["memory_scope"] = "PSAPI working set is resident process RAM; private/peak commit are commit charge. Original ggml device free/total is device-global, not private process VRAM. External PDH sampler is authoritative for per-process WDDM GPU accounting.";
    result["kv_dtype"] = "BF16";
    result["flash_attention"] = "enabled";
    result["sampler"] = "original public backend greedy chain; native ggml_argmax and public sampled_token fast path";
    result["sampling_transfer_scope"] = "Original d9e backend greedy leaves data.logits active; engine also copies sampled_logits. Observed element counts reported per phase. Consumer never requests raw logits or does CPU argmax.";
    result["cuda_disable_graphs_env"] = std::getenv("GGML_CUDA_DISABLE_GRAPHS") ? std::getenv("GGML_CUDA_DISABLE_GRAPHS") : "<absent>";
    result["prefix_mode"] = "fixed teacher-forced inputs; predictions never feed the next input";
    result["step_boundary"] = "before batch preparation -> greedy token selected on host";
    result["cold_boundary"] = "input JSON parsing, backend/model/context/batch/sampler creation excluded; no synthetic warmup";
    result["prompt_ids"] = prompt;
    result["decode_input_ids"] = decode;
    result["continuation_ids"] = continuation;
    result["continuation_boundary"] = "same native context after original prefill; one llama_decode for the full continuation, last-row greedy token only";
    result["target_ids"] = targets;
    result["predicted_ids"] = json::array();
    result["phases"] = json::array();
    for (const auto & step : steps) {
        result["predicted_ids"].push_back(step.predicted);
        const bool is_continuation = continuation_phases != 0 && step.index == 1;
        const char * kind = step.index == 0 ? "prefill" : is_continuation ? "continuation" : "decode";
        const auto decode_index = step.index - static_cast<int>(continuation_phases);
        const auto name = step.index == 0 || is_continuation ? std::string(kind)
            : std::string("decode") + std::to_string(decode_index);
        result["phases"].push_back({{"phase", step.index}, {"kind", kind}, {"name", name}, {"input_tokens", step.input_count},
            {"visible_tokens", step.visible_tokens}, {"predicted_id", step.predicted},
            {"input_prepare_seconds", step.input_prepare}, {"decode_return_seconds", step.decode_return},
            {"synchronize_seconds", step.synchronize}, {"token_access_seconds", step.logits_access},
            {"sample_fastpath_seconds", step.greedy_select}, {"sampled_logits_elements", step.sampled_logits_count}, {"step_seconds", step.total},
            {"stable_window_candidate", decode_index >= 7 && !is_continuation}});
    }
    std::ofstream output(output_path, std::ios::binary);
    if (!output) throw std::runtime_error("cannot open result output");
    output << result.dump(2) << '\n';
    if (!output) throw std::runtime_error("failed writing result output");
    return 0;
}

static int run_schedule(const char * model_path, const char * schedule_path,
                        std::uint32_t capacity, const char * output_path) {
    namespace schedule = qwen35::benchmark;
    const auto startup = Clock::now();
    // This fixed Qwen consumer validates IDs before loading the model, then
    // checks the original model vocabulary again before creating a context.
    constexpr int vocabulary_expected = 248320;
    const auto phases = schedule::read_schedule(schedule_path, vocabulary_expected, capacity);
    struct PhaseRecord {
        std::string name, begin_marker, end_marker;
        std::size_t first_step = 0, step_count = 0;
        int context_before = 0, context_after = 0;
        double total = 0, step_sum = 0;
    };
    struct CallRecord {
        std::size_t phase = 0, local = 0;
        std::string name;
    };
    std::size_t call_count = 0, batch_capacity_size = 0, processed_tokens = 0;
    for (const auto & phase : phases) {
        const bool prompt = phase.kind == schedule::PhaseKind::kPrompt;
        call_count += prompt ? 1 : phase.ids.size();
        processed_tokens += phase.ids.size();
        if (prompt) batch_capacity_size = std::max(batch_capacity_size, phase.ids.size());
    }
    const auto batch_capacity = static_cast<std::uint32_t>(batch_capacity_size);
    std::vector<Step> steps(call_count);
    std::vector<PhaseRecord> phase_records(phases.size());
    std::vector<CallRecord> calls;
    calls.reserve(call_count);
    for (std::size_t index = 0; index != phases.size(); ++index) {
        const auto & phase = phases[index];
        const bool prompt = phase.kind == schedule::PhaseKind::kPrompt;
        auto & record = phase_records[index];
        record.name = "round" + std::to_string(phase.turn) + (prompt ? "_prefill" : "_decode");
        record.begin_marker = record.name + "_begin";
        record.end_marker = record.name + "_end";
        record.first_step = calls.size();
        record.step_count = prompt ? 1 : phase.ids.size();
        for (std::size_t local = 0; local != record.step_count; ++local)
            calls.push_back({index, local, schedule::phase_name(phase, local)});
    }
    // All native snapshots are outside the measured session. Phase markers
    // below only write stderr; they never query device memory or synchronize.
    std::vector<Memory> snapshots(6);
    std::size_t snapshot_count = 0;
    snapshots[snapshot_count++] = memory("run_entry", startup);
    const auto backend_start = Clock::now();
    Backend backend;
    auto * device = ggml_backend_dev_by_name("CUDA0");
    if (!device || ggml_backend_dev_type(device) != GGML_BACKEND_DEVICE_TYPE_GPU)
        throw std::runtime_error("CUDA0 GPU is required");
    ggml_backend_dev_t devices[] = {device, nullptr};
    const auto backend_end = Clock::now();
    snapshots[snapshot_count++] = memory("backend_ready_before_model", startup, device);
    auto model_params = llama_model_default_params();
    model_params.devices = devices;
    model_params.n_gpu_layers = 999;
    const llama_model_tensor_buft_override overrides[] = {
        {"^token_embd\\.weight$", ggml_backend_dev_buffer_type(device)}, {nullptr, nullptr}};
    model_params.tensor_buft_overrides = overrides;
    using Model = std::unique_ptr<llama_model, decltype(&llama_model_free)>;
    const auto model_start = Clock::now();
    Model model(llama_model_load_from_file(model_path, model_params), &llama_model_free);
    const auto model_end = Clock::now();
    if (!model || llama_model_n_layer(model.get()) != 24)
        throw std::runtime_error("expected the full 24-layer Qwen3.5-2B model");
    const auto * vocab = llama_model_get_vocab(model.get());
    if (llama_vocab_n_tokens(vocab) != vocabulary_expected)
        throw std::runtime_error("model vocabulary differs from the validated Qwen schedule vocabulary");
    snapshots[snapshot_count++] = memory("model_loaded", startup, device);
    using Sampler = std::unique_ptr<llama_sampler, decltype(&llama_sampler_free)>;
    Sampler sampler(llama_sampler_chain_init(llama_sampler_chain_default_params()), &llama_sampler_free);
    llama_sampler_chain_add(sampler.get(), llama_sampler_init_greedy());
    auto context_params = llama_context_default_params();
    context_params.n_ctx = capacity;
    context_params.n_batch = batch_capacity;
    context_params.n_ubatch = batch_capacity;
    context_params.n_seq_max = 1;
    context_params.n_threads = 24;
    context_params.n_threads_batch = 24;
    context_params.type_k = GGML_TYPE_BF16;
    context_params.type_v = GGML_TYPE_BF16;
    context_params.flash_attn_type = LLAMA_FLASH_ATTN_TYPE_ENABLED;
    llama_sampler_seq_config sampler_config{0, sampler.get()};
    context_params.samplers = &sampler_config;
    context_params.n_samplers = 1;
    using Context = std::unique_ptr<llama_context, decltype(&llama_free)>;
    const auto context_start = Clock::now();
    Context context(llama_init_from_model(model.get(), context_params), &llama_free);
    const auto context_end = Clock::now();
    if (!context || llama_n_ctx(context.get()) < capacity)
        throw std::runtime_error("context creation did not preserve requested capacity");
    const auto actual_context = llama_n_ctx(context.get());
    Batch batch(static_cast<int32_t>(batch_capacity));
    const auto ready = Clock::now();
    snapshots[snapshot_count++] = memory("ready_before_prefill", startup, device);
    int position = 0;
    Point session_start{}, session_end{};
    double first_token_elapsed_seconds = 0;
    for (std::size_t phase_index = 0; phase_index != phases.size(); ++phase_index) {
        const auto & phase = phases[phase_index];
        auto & summary = phase_records[phase_index];
        const bool prompt = phase.kind == schedule::PhaseKind::kPrompt;
        summary.context_before = position;
        std::cerr << "memory_phase=" << summary.begin_marker << '\n';
        Point phase_start{}, phase_end{};
        for (std::size_t local = 0; local != summary.step_count; ++local) {
            const auto call_index = summary.first_step + local;
            const int count = prompt ? static_cast<int>(phase.ids.size()) : 1;
            const auto start = Clock::now(); // before any input batch preparation
            if (local == 0) phase_start = start;
            if (call_index == 0) session_start = start;
            batch.value.n_tokens = count;
            for (int i = 0; i != count; ++i) {
                batch.value.token[i] = phase.ids[prompt ? static_cast<std::size_t>(i) : local];
                batch.value.pos[i] = position + i;
                batch.value.n_seq_id[i] = 1;
                batch.value.seq_id[i][0] = 0;
                batch.value.logits[i] = i == count - 1;
            }
            const auto prepared = Clock::now();
            const auto status = llama_decode(context.get(), batch.value);
            const auto decoded = Clock::now();
            if (status != 0) throw std::runtime_error("llama_decode failed: " + std::to_string(status));
            llama_synchronize(context.get());
            const auto synchronized = Clock::now();
            const auto backend_token = llama_get_sampled_token_ith(context.get(), -1);
            if (backend_token == LLAMA_TOKEN_NULL)
                throw std::runtime_error("backend greedy did not produce a token; CPU fallback rejected");
            const auto token_access = Clock::now();
            const auto predicted = llama_sampler_sample(sampler.get(), context.get(), -1);
            if (predicted != backend_token) throw std::runtime_error("public sample differs from backend token");
            const auto selected = Clock::now(); // same host-token endpoint as the original consumer
            phase_end = session_end = selected;
            if (call_index == 0) first_token_elapsed_seconds = seconds(selected, startup);
            position += count;
            steps[call_index] = Step{static_cast<int>(call_index), count, position, predicted,
                seconds(prepared, start), seconds(decoded, prepared), seconds(synchronized, decoded),
                seconds(token_access, synchronized), seconds(selected, token_access), seconds(selected, start)};
            summary.step_sum += steps[call_index].total;
            steps[call_index].sampled_logits_count = llama_get_sampled_logits_count_ith(context.get(), -1);
        }
        summary.total = seconds(phase_end, phase_start);
        summary.context_after = position;
        std::cerr << "memory_phase=" << summary.end_marker << '\n';
    }
    const auto session_seconds = seconds(session_end, session_start);
    for (std::size_t index = 0; index != steps.size(); ++index) {
        const auto & step = steps[index];
        std::cerr << calls[index].name << " tokens=" << step.input_count
                  << " visible=" << step.visible_tokens << " predicted=" << step.predicted
                  << " step_seconds=" << step.total << '\n';
    }
    snapshots[snapshot_count++] = memory("inference_complete", startup, device);
    context.reset();
    sampler.reset();
    model.reset();
    snapshots[snapshot_count++] = memory("model_context_released_backend_alive", startup, device);
    json result;
    result["llama_commit"] = "d9e03f1074dbd2979126d91dce1b5d304ec8394e";
    result["model"] = model_path;
    result["schedule"] = schedule_path;
    result["device"] = ggml_backend_dev_name(device);
    result["device_description"] = ggml_backend_dev_description(device);
    result["context_capacity"] = actual_context;
    result["requested_context_capacity"] = capacity;
    result["configured_batch_capacity"] = batch_capacity;
    result["session_seconds"] = session_seconds;
    result["startup_total_seconds"] = seconds(session_end, startup);
    result["processed_tokens"] = processed_tokens;
    result["generated_tokens"] = steps.size();
    result["phase_count"] = phases.size();
    result["turn_count"] = phases.back().turn;
    result["quality_targets_available"] = false;
    result["kv_dtype"] = "BF16";
    result["flash_attention"] = "enabled";
    result["sampler"] = "original public backend greedy chain; native ggml_argmax and public sampled_token fast path";
    result["sampling_transfer_scope"] = "Original d9e backend greedy leaves data.logits active; engine also copies sampled_logits. Observed element counts reported per call. Consumer never requests raw logits or does CPU argmax.";
    result["full_cuda_embedding_override"] = "^token_embd\\.weight$ -> CUDA0 buffer, original public tensor_buft_overrides";
    result["cuda_disable_graphs_env"] = std::getenv("GGML_CUDA_DISABLE_GRAPHS") ? std::getenv("GGML_CUDA_DISABLE_GRAPHS") : "<absent>";
    result["prefix_mode"] = "one native context, global positions never reset; teacher-forced schedule inputs, predictions never feed the next input";
    result["session_boundary"] = "first input batch-fill start -> final native greedy token selected on host; includes phase markers/control gaps; per-call logs deferred after the endpoint; measured directly, not summed steps";
    result["phase_boundary"] = "first input batch-fill start -> last native greedy token selected on host, before that call's logging";
    result["step_boundary"] = "before batch preparation -> native greedy token selected on host";
    result["memory_scope"] = "All six native memory snapshots are before first input batch fill or after final host-token endpoint. Phase markers are stderr-only with no device-memory query or additional synchronization. PSAPI is process RAM/commit; original ggml device free/total is device-global.";
    result["loading"] = {{"backend_setup_seconds", seconds(backend_end, backend_start)},
        {"model_load_seconds", seconds(model_end, model_start)},
        {"context_prepare_seconds", seconds(context_end, context_start)},
        {"startup_to_ready_seconds", seconds(ready, startup)},
        {"first_token_elapsed_seconds", first_token_elapsed_seconds},
        {"ready_boundary", "run entry including schedule validation -> model/context/sampler/batch and preallocated reports ready; excluding following ready memory snapshot"}};
    result["phases"] = json::array();
    for (std::size_t index = 0; index != phases.size(); ++index) {
        const auto & phase = phases[index];
        const auto & summary = phase_records[index];
        result["phases"].push_back({{"phase", index}, {"turn", phase.turn},
            {"kind", phase.kind == schedule::PhaseKind::kPrompt ? "prefill" : "decode"},
            {"name", summary.name}, {"input_tokens", phase.ids.size()},
            {"context_before", summary.context_before}, {"context_after", summary.context_after},
            {"generated_tokens", summary.step_count}, {"seconds", summary.total},
            {"step_sum_seconds", summary.step_sum}});
    }
    result["steps"] = json::array();
    result["predicted_ids"] = json::array();
    for (std::size_t index = 0; index != steps.size(); ++index) {
        const auto & step = steps[index];
        const auto & call = calls[index];
        const auto & phase = phases[call.phase];
        result["predicted_ids"].push_back(step.predicted);
        result["steps"].push_back({{"step", index}, {"phase", call.phase}, {"turn", phase.turn},
            {"kind", phase.kind == schedule::PhaseKind::kPrompt ? "prefill" : "decode"},
            {"name", call.name}, {"local_index", call.local}, {"input_tokens", step.input_count},
            {"visible_tokens", step.visible_tokens}, {"predicted_id", step.predicted},
            {"input_prepare_seconds", step.input_prepare}, {"decode_return_seconds", step.decode_return},
            {"synchronize_seconds", step.synchronize}, {"token_access_seconds", step.logits_access},
            {"sample_fastpath_seconds", step.greedy_select},
            {"sampled_logits_elements", step.sampled_logits_count}, {"step_seconds", step.total}});
    }
    result["memory"] = json::array();
    for (std::size_t index = 0; index != snapshot_count; ++index) {
        const auto & sample = snapshots[index];
        result["memory"].push_back({{"name", sample.name}, {"elapsed_seconds", sample.elapsed},
            {"unix_ms", sample.unix_ms}, {"snapshot_seconds", sample.snapshot_seconds},
            {"process_available", sample.process_available}, {"process_error", sample.process_error},
            {"working_set_bytes", sample.working_set}, {"peak_working_set_bytes", sample.peak_working_set},
            {"private_commit_bytes", sample.private_commit}, {"peak_commit_bytes", sample.peak_commit},
            {"device_available", sample.device_available}, {"device_free_bytes", sample.device_free},
            {"device_total_bytes", sample.device_total},
            {"device_global_used_bytes", sample.device_available ? sample.device_total - sample.device_free : 0}});
    }
    std::ofstream output(output_path, std::ios::binary);
    if (!output) throw std::runtime_error("cannot open result output");
    output << result.dump(2) << '\n';
    if (!output) throw std::runtime_error("failed writing result output");
    return 0;
}

int main(int argc, char ** argv) {
    try {
        // Original positional interface and complete execution branch are unchanged.
        if (argc == 4 && std::string(argv[2]).rfind("--", 0) != 0)
            return run(argv[1], argv[2], argv[3]);
        const char * schedule_path = nullptr;
        const char * output_path = nullptr;
        std::uint32_t capacity = 0;
        if (argc < 2) throw std::runtime_error("missing model path");
        for (int index = 2; index < argc; ++index) {
            const std::string option = argv[index];
            if (++index >= argc) throw std::runtime_error("option requires a value: " + option);
            if (option == "--schedule" && schedule_path == nullptr)
                schedule_path = argv[index];
            else if (option == "--result" && output_path == nullptr)
                output_path = argv[index];
            else if (option == "--capacity" && capacity == 0) {
                const std::string value = argv[index];
                std::uint64_t parsed = 0;
                const auto converted = std::from_chars(value.data(), value.data() + value.size(), parsed);
                if (converted.ec != std::errc{} || converted.ptr != value.data() + value.size() ||
                    parsed == 0 || parsed > static_cast<std::uint64_t>((std::numeric_limits<int32_t>::max)()))
                    throw std::runtime_error("capacity must be positive and within I32 positions");
                capacity = static_cast<std::uint32_t>(parsed);
            } else throw std::runtime_error("unknown, duplicate, or mixed positional option: " + option);
        }
        if (schedule_path == nullptr || output_path == nullptr || capacity == 0)
            throw std::runtime_error("schedule, capacity and result are required together");
        return run_schedule(argv[1], schedule_path, capacity, output_path);
    } catch (const std::exception & error) {
        std::cerr << error.what() << '\n'
                  << "usage: peer model.gguf fixed-inputs.json result.json\n"
                  << "   or: peer model.gguf --schedule schedule.txt --capacity N --result result.json\n";
        return 1;
    }
}
