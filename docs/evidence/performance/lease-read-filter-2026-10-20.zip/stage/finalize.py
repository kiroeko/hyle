"""Publish the scoped read-candidate fix with actual ownership, model, counter and timing evidence."""
import datetime as dt
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import sys
import zipfile
sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
ROOT = S.parents[2]
spec = importlib.util.spec_from_file_location("lease_filter_finalization", S / "build.py")
h = importlib.util.module_from_spec(spec)
spec.loader.exec_module(h)
b, c = h.b, h.c
build = Path(c.read(S / "latest-plan.json")["plan"]).parent
assert c.read(build / "summary.json")["passed"]
for name in ("source-freeze.json", "tests-source-freeze.json"):
    for row in c.read(S / name)["files"]:
        assert b.same(row["after"]) and b.same(row["snapshot"])
tests = c.read(S / "tests/summary.json")
numeric = c.read(S / "correctness/summary.json")
counter = c.read(S / "counter-probe/run/summary.json")
rotation = c.read(S / "performance-rotation/summary.json")
prep = c.read(S / "prepare-results.json")
assert tests["passed"] and tests["cases"] == 7 and not tests["skipped"]
assert numeric["passed"] and numeric["observation"]["equal_vectors"] == 64
assert counter["passed"] and counter["equal_vectors"] == 64 and not counter["overflow_calls"]
assert rotation["terminal_zero"] == 9 and rotation["same_baseline_predictions_all9"]
assert not rotation["profiler"] and not rotation["external_memory_monitor"]
for arm in ("cpu", "qwen"):
    assert b.same(c.read(build / (arm + "-image.json")))
    for row in c.read(build / (arm + "-link-plan.json"))["inputs"]:
        assert b.same(row), row["path"]
totals = {key: sum(row[key] for row in counter["groups"]) for key in (
    "collect_calls", "collect_visited", "collected", "lookup_calls", "lookup_visited", "hits")}
assert totals == dict(collect_calls=32, collect_visited=3264, collected=32,
    lookup_calls=21736, lookup_visited=21736, hits=0)
zone = dt.timezone(dt.timedelta(hours=8))
first = c.read(S / "performance-rotation/01-baseline.result.json")
last = c.read(S / "performance-rotation/09-baseline.result.json")
products = ["src/graph/resources.cc", "src/graph/resource_episode.h", "src/graph/executable.cc",
    "tests/graph/region_provider_test.cc", "docs/architecture/compute-design.md", "docs/developer/current-work.md",
    "docs/evidence/performance/qwen35-full-cuda-2026-10-19/README.md"]
c.execute("diff-check", ["git", "diff", "--check", "--", *products], dict(os.environ), S)
report = dict(date_utc=dt.datetime.now(dt.timezone.utc).isoformat(),
    scope="Common Compute/Graph native input ownership lookup; no model/provider branch, public API change or GPU math change",
    result="A guarded uncached binding-preparation pass collects nonexclusive owned-read record ordinals once in original order; each lookup retains the original live view/resource/handle/range check. Scope exit/failure clears ordinals.",
    source=c.read(S / "source-freeze.json"),
    design=dict(implementation=c.read(S / "implementation-notes.json"),
        independent_review=c.read(S / "product-independent-review.json"),
        complexity="O(B+P*R) record visits for B bindings/P queries/R eligible reads; worst R=B remains O(P*B). No permission/readiness/match cache and no lease retained by the integer scratch.",
        allocation="Original ResourceEpisode allocator and cold prepare_resources/reserve_reads capacity; collection checks capacity and never grows it. No new device buffer or executor; this is not a global no-allocation claim."),
    actual_build=dict(product_CXX_owners=2, test_CXX_owners=1, shared_product_objects_between_CPU_and_CUDA=True,
        refreshed_CUDA_owners=0, SDK_builds=0, consumer_main_object_reused=True,
        CPU_test_closure_inputs=115, Qwen_closure_inputs=135,
        counter_only_extra_CXX_owners=1,
        private_header_boundary="Only declarations/private lookup signature changed; sole protocol caller and definition refreshed. No inline body or visible owner/PlanState/InvocationState layout change requiring unrelated consumers to refresh."),
    correctness=dict(CPU=tests, full_model=numeric, counter_model_equal_vectors=64),
    physical_work=dict(counter=counter, totals=totals,
        baseline_counter="qwen-lease-lookup-probe-2026-10-20.json",
        original_total_record_visits=2217072,
        current_collect_plus_lookup_record_visits=totals["collect_visited"] + totals["lookup_visited"],
        original_record_visits_per_decode=69360, current_record_visits_per_decode=782,
        explanation="Each decode has one102-record collection and680 single-candidate lookups. Original eligible live-view matching count remains one per lookup; only repeated no-read record visits are eliminated.",
        timing_claim=False),
    performance=dict(window_beijing={"start": dt.datetime.fromtimestamp(first["started"], zone).isoformat(),
        "end": dt.datetime.fromtimestamp(last["finished"], zone).isoformat()},
        rotation=rotation, existing_preparation_boundary=prep,
        conclusion="No stable throughput or total preparation improvement established: warm+0.407%, full31-0.090%, and preparation201.9->196.3us have strongly overlapping process ranges. Preserve the actual negative/uncertain result; do not infer speed from fewer record visits."),
    not_claimed=["No new independent model quality, whole-model GPU trace, memory sampling, Linux/macOS or mixed-mode validation from this batch.",
        "No new per-lookup timing, global linear-time search, all-provider allocation bound, or permission fact retained across episodes.",
        "CPU closure is a focused retained test closure refreshed for these exact Graph owners, not a new full CPU delivery build.",
        "Hyle BF16 and reference F32 decode intermediates/load/prepare sub-boundaries retain their documented differences."],
    evidence=dict(stage=str(S), archive="lease-read-filter-2026-10-20.zip",
        products=[b.identity(ROOT / name) for name in products],
        reproduce=["python -B .scratch/architecture-refactor-2026-10-18/lease-read-filter/build.py --build --resume " + str(build / "plan.json"),
            "python -B .scratch/architecture-refactor-2026-10-18/lease-read-filter/run_tests.py",
            "python -B .scratch/architecture-refactor-2026-10-18/lease-read-filter/run_model.py " + str(build / "plan.json"),
            "python -B .scratch/architecture-refactor-2026-10-18/lease-read-filter/compare.py --run"],
        reproduction_limit="Completed output directories are not silently overwritten; use a fresh destination or the retained exact commands. Existing SDKs, source checkout, models and cached objects are reused, not bundled."),
    goal="Active; original model/quantization/platform/lifecycle and architecture scope remains")
c.save(S / "summary.json", report)
public = ROOT / "docs/evidence/performance/lease-read-filter-2026-10-20.json"
archive = public.with_suffix(".zip")
assert not archive.exists()
ignored = {".exe", ".obj", ".lib", ".exp", ".pdb", ".map", ".pyc", ".bf16", ".f32"}
files = {"stage/" + path.relative_to(S).as_posix(): path for path in S.rglob("*")
    if path.is_file() and path.suffix.lower() not in ignored and "tmp" not in path.relative_to(S).parts and
    path.name not in {"archive-manifest.json", "publication.json"}}
files.update({"product/" + name: ROOT / name for name in products})
manifest = [dict(name=name, bytes=path.stat().st_size, sha256=hashlib.sha256(path.read_bytes()).hexdigest())
            for name, path in sorted(files.items())]
with zipfile.ZipFile(archive, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as z:
    for name, path in sorted(files.items()):
        z.write(path, name)
    z.writestr("manifest.json", json.dumps(dict(payloads=manifest,
        excluded="Rebuildable binaries/maps, SDK/model/cache copies and duplicated byte-identical observations"), ensure_ascii=False, indent=2))
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for row in manifest:
        raw = z.read(row["name"])
        assert len(raw) == row["bytes"] and hashlib.sha256(raw).hexdigest() == row["sha256"]
receipt = dict(archive=b.identity(archive), payload_count=len(manifest), CRC_checked=True, all_payload_SHA256_checked=True)
report["evidence"]["archive_receipt"] = receipt
c.save(public, report)
c.save(S / "archive-manifest.json", dict(payloads=manifest, receipt=receipt))
c.save(S / "publication.json", dict(report=b.identity(public), **receipt))
print("LEASE_FILTER_PUBLISHED", receipt["archive"]["bytes"], "bytes", len(manifest), "payloads", flush=True)
