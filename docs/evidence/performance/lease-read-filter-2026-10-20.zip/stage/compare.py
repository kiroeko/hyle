"""Reuse the accepted nine-process rotation, with the most recent Qwen image as baseline."""
import argparse
import importlib.util
from pathlib import Path
import sys
sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("lease_filter_rotation", S.parent / "qwen-current-retest/compare.py")
r = importlib.util.module_from_spec(spec)
spec.loader.exec_module(r)
r.S = r.rotation.STAGE = S
r.r.PREPARED = S / "performance-prepared"

if __name__ == "__main__":
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--build-plan", type=Path)
    p.add_argument("--run", action="store_true")
    args = p.parse_args()
    if args.run:
        assert args.build_plan is None
        r.rotation.run(r.r.PREPARED / "plan.json", S / "performance-rotation")
    else:
        assert args.build_plan is not None
        old = S.parent / "qwen-current-retest"
        image = r.c.read(old / "checks/main1/qwen-image.json")
        assert r.b.same(image)
        peer = r.c.read(old / "retest-plan.json")["retained_llama_image"]
        r.c.save(S / "retest-plan.json", dict(retained_old_image=image,
            retained_llama_image=peer, source="Previously accepted same-main Qwen product closure"))
        r.prepare(args.build_plan)
        plan = r.c.read(r.r.PREPARED / "plan.json")
        plan["baseline"] = "Previous accepted qwen-current-retest same-main image0e240734; only the two shared Graph product owners differ."
        plan["frozen"].append(r.b.identity(Path(__file__)))
        r.c.save(r.r.PREPARED / "plan.json", plan)
