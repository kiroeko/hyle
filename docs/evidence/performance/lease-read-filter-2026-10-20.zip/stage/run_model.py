"""Run the existing64-observation consumer against this focused product increment."""
import importlib.util
from pathlib import Path
import sys
sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("lease_filter_numerical_runner", S.parent / "view-projection-reuse/run_model.py")
r = importlib.util.module_from_spec(spec)
spec.loader.exec_module(r)
r.STAGE, r.ARCH, r.ROOT = S, S.parent, S.parents[2]
if __name__ == "__main__":
    r.main()
