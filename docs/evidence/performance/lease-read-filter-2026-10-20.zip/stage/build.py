"""Plan the three-TU host increment; --build compiles/links, never runs images.

Default: create a fresh plan.  --build --resume PATH resumes that exact plan,
reusing only successful, identity-checked compile/link receipts.  No NVCC,
SDK rebuild, old whole-product freeze validation, or inference/test execution.
"""
from pathlib import Path
import argparse
import datetime as dt
import hashlib
import importlib.util
import json
import os
import subprocess
import sys
import time
import uuid

sys.dont_write_bytecode = True
STAGE = Path(__file__).resolve().parent
ARCH = STAGE.parent
ROOT = ARCH.parents[1]
# Existing numerical/timing runners load this module's conventional helpers.
_spec = importlib.util.spec_from_file_location("lease_filter_retained_host_helpers",
                                             ARCH / "qwen-current-retest/build.py")
_helpers = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(_helpers)
b, c = _helpers.b, _helpers.c
BASES = {
    "cpu": ARCH / "view-projection-reuse/checks/20261019T191627/cpu-link-plan.json",
    "qwen": ARCH / "qwen-current-retest/checks/main1/qwen-link-plan.json",
}
PROBE_FREEZE = ARCH / "qwen-current-retest/lease-probe/source-freeze.json"
PRODUCT_FREEZE = STAGE / "source-freeze.json"
TEST_FREEZE = STAGE / "tests-source-freeze.json"
GRAPH_RECIPE = ARCH / "fp8-shared-prologue/checks/host1/graph--executable-identity.json"
CPU_GRAPH_RECIPE = ARCH / "view-projection-reuse/checks/20261019T191627/graph-identity.json"
TEST_RECIPE = ARCH / "prepare-replay-cold-index/checks/20261019T173829/08-graph-region_provider_test-identity.json"
OUTPUT_FLAGS = ("/OUT:", "/MAP:", "/IMPLIB:", "/PDB:")


def read(path):
    return json.loads(Path(path).read_text(encoding="utf-8-sig"))


def save(path, value):
    Path(path).write_text(json.dumps(value, indent=2) + "\n", encoding="utf-8")


def key(path):
    return str(Path(path).resolve()).casefold()


def identity(path):
    path = Path(path).resolve()
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(4 * 1024 * 1024), b""):
            digest.update(block)
    return dict(path=str(path), bytes=path.stat().st_size, sha256=digest.hexdigest())


def check_identity(row):
    if identity(row["path"]) != row:
        raise ValueError("Identity changed: " + row["path"])


def host_command(recipe, source, tag, out):
    command, skip = [], False
    for arg in recipe:
        if skip:
            skip = False
        elif arg.casefold() == "/sourcedependencies":
            skip = True
        elif not (arg.casefold().startswith(("/fo", "/fd")) or
                  arg.casefold().endswith((".cc", ".cpp"))):
            command.append(arg)
    command += ["/sourceDependencies", str(out / (tag + "-deps.json")),
                str(source), "/Fo" + str(out / (tag + ".obj")),
                "/Fd" + str(out / (tag + ".pdb"))]
    if Path(command[0]).name.casefold() != "cl.exe" or not {"/W4", "/WX"} <= set(command):
        raise ValueError("Expected the retained strict cl.exe host recipe")
    return command


def make_plan():
    out = STAGE / "checks" / (dt.datetime.now(dt.timezone.utc).strftime("%Y%m%dT%H%M%S")
                             + "-" + uuid.uuid4().hex[:8])
    out.mkdir(parents=True, exist_ok=False)
    (out / "tmp").mkdir()
    probe = read(PROBE_FREEZE)
    resource_recipe = Path(probe["old_resources_recipe"]["path"])
    check_identity(probe["old_resources_recipe"])
    specs = [
        ("resources", ROOT / "src/graph/resources.cc", resource_recipe),
        ("executable", ROOT / "src/graph/executable.cc", GRAPH_RECIPE),
        ("region-test", ROOT / "tests/graph/region_provider_test.cc", TEST_RECIPE),
    ]
    bases = {arm: read(path) for arm, path in BASES.items()}
    recipes = {tag: read(path) for tag, _, path in specs}
    cpu_graph = read(CPU_GRAPH_RECIPE)
    replacements = {
        "cpu": {key(recipes["resources"]["object"]["path"]): str(out / "resources.obj"),
                key(cpu_graph["object"]["path"]): str(out / "executable.obj"),
                key(recipes["region-test"]["object"]["path"]): str(out / "region-test.obj")},
        "qwen": {key(recipes["resources"]["object"]["path"]): str(out / "resources.obj"),
                 key(recipes["executable"]["object"]["path"]): str(out / "executable.obj")},
    }
    frozen = {}
    for path in [Path(__file__), Path(_helpers.__file__), Path(b.__file__), Path(c.__file__),
                 PROBE_FREEZE, PRODUCT_FREEZE, TEST_FREEZE, CPU_GRAPH_RECIPE, *BASES.values(),
                 *(path for _, _, path in specs)]:
        frozen[key(path)] = identity(path)
    for seal in (PRODUCT_FREEZE, TEST_FREEZE):
        for row in read(seal)["files"]:
            check_identity(row["after"])
            check_identity(row["snapshot"])
            frozen[key(row["after"]["path"])] = row["after"]
    rows = []
    for tag, source, recipe_path in specs:
        recipe = recipes[tag]
        if key(recipe["source"]["path"]) != key(source):
            raise ValueError("Recipe/source mismatch: " + tag)
        command = host_command(recipe["command"], source, tag, out)
        if not Path(command[0]).is_file():
            raise ValueError("Missing compiler: " + command[0])
        rows.append(dict(tag=tag, source=identity(source), recipe=identity(recipe_path),
                         command=command, object=str(out / (tag + ".obj"))))
        # Freeze current dependencies of these selected TUs only.  Historical
        # source hashes are recipe provenance, not a whole-product freshness gate.
        for path in [source, *(Path(row["path"]) for row in recipe.get("dependencies", []))]:
            resolved = Path(path).resolve()
            if any(resolved.is_relative_to(ROOT / part) for part in ("src", "include", "tests")):
                frozen[key(resolved)] = identity(resolved)
        snapshot = out / "compiled-source" / source.relative_to(ROOT)
        snapshot.parent.mkdir(parents=True, exist_ok=True)
        snapshot.write_bytes(source.read_bytes())
    cached, links = {}, {}
    for arm, base in bases.items():
        if len(base["inputs"]) != (115 if arm == "cpu" else 135):
            raise ValueError("Unexpected baseline closure size: " + arm)
        original = {key(row["path"]): row for row in base["inputs"]}
        if len(original) != len(base["inputs"]):
            raise ValueError("Duplicated baseline input: " + arm)
        for old in replacements[arm]:
            if old not in original or sum(key(arg) == old for arg in base["command"]) != 1:
                raise ValueError("Replacement is not one exact input: " + old)
        command = [replacements[arm].get(key(arg), arg) for arg in base["command"]
                   if not arg.upper().startswith(OUTPUT_FLAGS)]
        image = out / (arm + ".exe")
        command += ["/OUT:" + str(image), "/MAP:" + str(image.with_suffix(".map")),
                    "/IMPLIB:" + str(image.with_suffix(".lib"))]
        inputs = [arg for arg in command if not arg.startswith("/") and
                  Path(arg).is_absolute() and Path(arg).suffix.casefold() in (".obj", ".lib")]
        if len(inputs) != len(base["inputs"]) or len(set(map(key, inputs))) != len(inputs):
            raise ValueError("Replacement changed the ordered link closure: " + arm)
        for old_key, row in original.items():
            if old_key in replacements[arm]:
                continue
            path = Path(row["path"])
            if not path.is_file() or path.stat().st_size != row["bytes"]:
                raise ValueError("Missing or resized cached input: " + str(path))
            if old_key in cached and cached[old_key] != row:
                raise ValueError("Inconsistent shared cached input: " + row["path"])
            cached[old_key] = row
        links[arm] = dict(command=command, inputs=inputs, image=str(image),
                          replacements=replacements[arm])
    plan = dict(schema="hyle.lease_read_filter.host_increment.v1", root=str(ROOT),
                compile=rows, links=links, cached_inputs=list(cached.values()),
                frozen=list(frozen.values()), base_link_plans={k: identity(v) for k, v in BASES.items()},
                host_TUs=3, native_TUs=0, product_host_TUs=2, test_host_TUs=1,
                main_object_reused=True, SDK_rebuild=False, executes_images=False,
                freshness_scope="Current selected-TU product/test dependencies only; no historical whole-product freeze gate.")
    save(out / "plan.json", plan)
    save(STAGE / "latest-plan.json", dict(plan=str(out / "plan.json")))
    return out / "plan.json"


def execute(tag, command, env, out):
    attempt = 1
    stem = tag
    while (out / (stem + ".command.json")).exists():
        attempt += 1
        stem = tag + "-attempt" + str(attempt)
    row = dict(tag=tag, command=command, cwd=str(ROOT), started=time.time(), exit=None,
               attempt=attempt, terminal=False)
    save(out / (stem + ".command.json"), row)
    with (out / (stem + ".stdout.log")).open("wb") as stdout, \
         (out / (stem + ".stderr.log")).open("wb") as stderr:
        process = subprocess.Popen(command, cwd=ROOT, env=env, stdout=stdout, stderr=stderr,
                                   creationflags=subprocess.CREATE_NO_WINDOW)
        row["pid"] = process.pid
        save(out / "live.json", row)
        print("START", tag, "PID", process.pid, flush=True)
        row["exit"] = process.wait()
    row.update(finished=time.time(), terminal=True)
    save(out / (stem + ".result.json"), row)
    save(out / "live.json", row)
    print("END", tag, "exit", row["exit"], flush=True)
    if row["exit"]:
        raise RuntimeError("Host command failed: " + stem)
    return str(out / (stem + ".result.json"))


def reusable(receipt_path, command, output_key):
    if not receipt_path.is_file():
        return False
    receipt = read(receipt_path)
    result = read(receipt["result"])
    if result.get("exit") != 0 or not result.get("terminal") or result["command"] != command:
        raise ValueError("Invalid successful receipt: " + str(receipt_path))
    check_identity(receipt[output_key])
    for row in receipt.get("dependencies", []):
        check_identity(row)
    return True


def build(plan_path):
    plan_path = Path(plan_path).resolve()
    if not plan_path.is_relative_to(STAGE / "checks") or plan_path.name != "plan.json":
        raise ValueError("Resume accepts only this stage's exact checks/.../plan.json")
    plan = read(plan_path)
    if plan.get("schema") != "hyle.lease_read_filter.host_increment.v1" or plan.get("root") != str(ROOT):
        raise ValueError("Unexpected plan schema/root")
    out = plan_path.parent
    def check_frozen():
        for row in plan["frozen"]:
            check_identity(row)
    check_frozen()
    for row in plan["cached_inputs"]:
        check_identity(row)
    # Compiler setup is delayed until --build.  This imports no model or CUDA.
    env, runtime = b.environment(plan["links"]["qwen"]["command"],
                                 [row["path"] for row in plan["cached_inputs"]
                                  if row["path"] in plan["links"]["qwen"]["inputs"]], out)
    save(out / "runtime-environment.json", dict(runtime=runtime, unrelated_CPU_closure_union=False))
    for row in plan["compile"]:
        receipt_path = out / (row["tag"] + "-identity.json")
        if reusable(receipt_path, row["command"], "object"):
            print("REUSE", row["tag"], flush=True)
            continue
        result = execute(row["tag"] + "-compile", row["command"], env, out)
        check_frozen()
        data = read(out / (row["tag"] + "-deps.json"))["Data"]
        dependencies = [identity(path) for path in dict.fromkeys([data["Source"], *data["Includes"]])]
        save(receipt_path, dict(command=row["command"], source=row["source"],
                               object=identity(row["object"]), dependencies=dependencies, result=result))
    available = {key(row["path"]): row for row in plan["cached_inputs"]}
    for row in plan["compile"]:
        receipt = read(out / (row["tag"] + "-identity.json"))
        available[key(receipt["object"]["path"])] = receipt["object"]
    for arm, link in plan["links"].items():
        check_frozen()
        receipt_path = out / (arm + "-link-identity.json")
        if reusable(receipt_path, link["command"], "image"):
            print("REUSE", arm + "-link", flush=True)
            continue
        result = execute(arm + "-link", link["command"], env, out)
        check_frozen()
        inputs = [available[key(path)] for path in link["inputs"]]
        save(out / (arm + "-link-plan.json"), dict(command=link["command"], inputs=inputs))
        save(receipt_path, dict(command=link["command"], image=identity(link["image"]), result=result,
                               dependencies=[available[key(row["object"])] for row in plan["compile"]
                                             if row["object"] in link["inputs"]]))
        save(out / (arm + "-image.json"), identity(link["image"]))
    save(out / "summary.json", dict(passed=True, host_TUs=3, native_TUs=0,
                                    SDK_rebuild=False, images_executed=False))
    print("BUILT", out, flush=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--build", action="store_true")
    parser.add_argument("--resume", type=Path, help="Exact previously prepared plan.json")
    args = parser.parse_args()
    plan_path = args.resume.resolve() if args.resume else make_plan()
    print("PLAN", plan_path, flush=True)
    if args.build:
        build(plan_path)


if __name__ == "__main__":
    try:
        main()
    except (ValueError, RuntimeError, OSError, KeyError) as error:
        print("ERROR:", error, file=sys.stderr, flush=True)
        raise SystemExit(1)
