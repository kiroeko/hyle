"""Run only native-read ownership, rebind/failure and original projected/writer neighbours."""
import importlib.util
from pathlib import Path
import sys
import xml.etree.ElementTree as ET
sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("lease_filter_test_helpers", S / "build.py")
h = importlib.util.module_from_spec(spec)
spec.loader.exec_module(h)
b, c = h.b, h.c
plan_path = Path(c.read(S / "latest-plan.json")["plan"])
plan = c.read(plan_path)
assert c.read(plan_path.parent / "summary.json")["passed"]
image = c.read(plan_path.parent / "cpu-image.json")
assert b.same(image)
names = c.read(S / "tests-source-freeze.json")["recommended_filters"]
assert len(names) == 7 and len(set(names)) == 7
out = S / "tests"
out.mkdir(exist_ok=False)
(out / "tmp").mkdir()
link = c.read(plan_path.parent / "cpu-link-plan.json")
env, runtime = b.environment(link["command"], [row["path"] for row in link["inputs"]], out)
c.save(out / "inputs.json", dict(image=image, filters=names, plan=b.identity(plan_path),
    runtime=runtime, CPU_only=True, GPU_execution=False))
try:
    c.execute("tests", [image["path"], "--gtest_filter=" + ":".join(names),
        "--gtest_output=xml:" + str(out / "results.xml")], env, out)
finally:
    cases = ET.parse(out / "results.xml").findall(".//testcase") if (out / "results.xml").is_file() else []
    actual = [row.attrib["classname"] + "." + row.attrib["name"] for row in cases]
    passed = set(actual) == set(names) and len(cases) == len(names) and all(
        row.find(tag) is None for row in cases for tag in ("failure", "error", "skipped"))
    c.save(out / "summary.json", dict(passed=passed, cases=len(cases), expected=names, actual=actual,
        skipped=sum(row.find("skipped") is not None for row in cases), image=image,
        failures=[dict(name=row.attrib["name"], details=[child.text for child in row.findall("failure")])
                  for row in cases if row.find("failure") is not None]))
assert passed
print("LEASE_FILTER_CPU_TESTS", len(cases), "passed", flush=True)
