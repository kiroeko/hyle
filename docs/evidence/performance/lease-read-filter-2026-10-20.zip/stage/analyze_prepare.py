"""Extract the consumer's unchanged whole preparation boundary, not per-function time."""
import json
from pathlib import Path
import re
import statistics
S = Path(__file__).resolve().parent
rotation = S / "performance-rotation"
pattern = re.compile(r"prepared T=1 visible=(\d+) replay=\S+ cold_batch_seconds=([\d.eE+-]+)")
rows = []
for file in sorted(rotation.glob("*.stderr.log")):
    if not any(arm in file.name for arm in ("baseline", "current")):
        continue
    values = [(int(visible), float(seconds) * 1e6) for visible, seconds in pattern.findall(file.read_text())
              if 135 <= int(visible) <= 159]
    assert [visible for visible, _ in values] == list(range(135, 160)), file
    samples = [value for _, value in values]
    rows.append(dict(arm="baseline" if "baseline" in file.name else "current",
        log=str(file), samples_us=samples, median_us=statistics.median(samples), mean_us=statistics.mean(samples)))
assert len(rows) == 6
medians = {arm: statistics.median(row["median_us"] for row in rows if row["arm"] == arm)
           for arm in ("baseline", "current")}
report = dict(passed=True, processes=rows, process_median_us=medians,
    new_over_old=medians["current"] / medians["baseline"],
    boundary="Existing uninstrumented main's cold_batch_seconds: attention layout version, batch prepare/reset,101 ordinary binds and prepare_replay; after token/position writes, before submit.",
    source="tools/qwen35_text/main.cc:498-532; fixed decode7-31, visible135..159; one median of25 steps per process, then median of3 processes per arm.",
    limits=["This is a whole preparation boundary, not input_lease timing or GPU kernel time.",
        "Existing coarse consumer clocks only, no counter/profiler image or extra run.",
        "Preparation and full-step median differences must not be added or causally equated."])
(S / "prepare-results.json").write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
print(json.dumps(dict(process_medians=[(row["arm"], row["median_us"]) for row in rows],
                     median_us=medians, ratio=report["new_over_old"])))
