"""Root-only one-object counter diagnostic; no command executes without --build/--run."""
from pathlib import Path
import argparse
import hashlib
import importlib.util
import re
import sys

sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('filter_probe_host_helpers', S.parent / 'build.py')
h = importlib.util.module_from_spec(spec)
spec.loader.exec_module(h)
b, c = h.b, h.c
OUT = S / 'build'
REFERENCE = S.parent.parent / 'qwen-current-retest/correctness'


def check_sources():
    freeze = c.read(S / 'source-freeze.json')
    for item in (freeze['product_source'], freeze['after'], freeze['product_freeze']):
        assert b.same(item), item['path']
    for row in c.read(freeze['product_freeze']['path'])['files']:
        assert b.same(row['after']), row['source']
    return freeze


def build(base_path):
    freeze = check_sources()
    base = c.read(base_path)
    wanted = {c.key(x['path']): x for x in base['inputs']}
    matches = []
    for path in base_path.parent.glob('*identity*.json'):
        row = c.read(path)
        obj = row.get('object', {})
        if not isinstance(obj, dict) or c.key(obj.get('path', '')) not in wanted:
            continue
        if c.key(row.get('source', {}).get('path', '')) == c.key(freeze['product_source']['path']):
            assert obj == wanted[c.key(obj['path'])] and row['source'] == freeze['product_source']
            matches.append((path, row))
    assert len(matches) == 1, 'Need one actual linked resources identity beside base link plan'
    recipe_path, recipe = matches[0]
    assert b.same(recipe['object'])
    main = [x for x in base['inputs'] if Path(x['path']).name == 'qwen-main.obj']
    assert len(main) == 1 and b.same(main[0]), 'Retain the exact accepted same main object'
    OUT.mkdir(exist_ok=False)
    (OUT / 'tmp').mkdir()
    compile_command = b.host_command(recipe['command'], Path(freeze['after']['path']), 'resources', OUT)
    old = c.key(recipe['object']['path'])
    command = [str(OUT / 'resources.obj') if c.key(x) == old else x for x in base['command']
               if not x.lower().startswith(('/out:', '/map:', '/implib:', '/pdb:'))]
    image = OUT / 'qwen.exe'
    command += ['/OUT:' + str(image), '/MAP:' + str(image.with_suffix('.map')),
                '/IMPLIB:' + str(image.with_suffix('.lib'))]
    inputs = [x for x in command if Path(x).is_absolute() and Path(x).suffix.lower() in ('.obj', '.lib')]
    assert len(inputs) == len(base['inputs']) and command.count(str(OUT / 'resources.obj')) == 1
    assert all(Path(x['path']).is_file() for x in base['inputs'])
    plan = {'base_link_plan': b.identity(base_path), 'source_freeze': b.identity(S / 'source-freeze.json'),
        'compile': compile_command, 'link': command, 'recipe': b.identity(recipe_path),
        'replaced': recipe['object'], 'same_main': main[0], 'retained_inputs_rehashed': False}
    c.save(OUT / 'plan.json', plan)
    env, runtime = b.environment(command, inputs, OUT)
    c.save(OUT / 'runtime-environment.json', {'runtime': runtime})
    c.execute('resources-compile', compile_command, env, OUT)
    dep = c.read(OUT / 'resources-deps.json')['Data']
    obj = b.identity(OUT / 'resources.obj')
    c.save(OUT / 'resources-identity.json', {'command': compile_command,
        'source': freeze['after'], 'object': obj,
        'dependencies': [b.identity(p) for p in dict.fromkeys([dep['Source'], *dep['Includes']])]})
    check_sources()
    assert b.same(main[0]) and b.same(plan['base_link_plan'])
    c.execute('qwen-link', command, env, OUT)
    identities = {c.key(x['path']): x for x in base['inputs']}
    identities[c.key(obj['path'])] = obj
    c.save(OUT / 'qwen-link-plan.json', {'command': command, 'inputs': [identities[c.key(p)] for p in inputs]})
    c.save(OUT / 'image.json', b.identity(image))
    c.save(OUT / 'summary.json', {'passed': True, 'host_TUs': 1, 'native_TUs': 0,
        'main_or_executable_recompiled': False, 'SDK_rebuild': False, 'counter_only': True})


def run(base_path):
    check_sources()
    built = c.read(OUT / 'plan.json')
    assert b.identity(base_path) == built['base_link_plan']
    assert b.same(built['source_freeze']) and c.read(OUT / 'summary.json')['passed']
    image = c.read(OUT / 'image.json')
    assert b.same(image) and b.same(built['same_main'])
    out = S / 'run'
    out.mkdir(exist_ok=False)
    (out / 'tmp').mkdir()
    command = c.read(REFERENCE / 'qwen.command.json')['command'].copy()
    command[0] = image['path']
    command[command.index('--trace') + 1] = str(out / 'trace')
    accepted = c.read(REFERENCE / 'inputs.json')
    assert all(b.same(accepted[name]) for name in ('manifest', 'prompt', 'decode'))
    link = c.read(OUT / 'qwen-link-plan.json')
    env, runtime = b.environment(link['command'], [x['path'] for x in link['inputs']], out)
    c.save(out / 'inputs.json', {'image': image, 'base_link_plan': built['base_link_plan'],
        'same_main': built['same_main'], 'reference': str(REFERENCE), 'command': command,
        'original_model_payload_receipt': accepted['model'], 'model_payload_rehashed': False,
        'only_command_changes': ['executable', '--trace destination'], 'runtime': runtime})
    c.execute('qwen', command, env, out)
    groups, overflow = [], None
    for line in (out / 'qwen.stderr.log').read_text(errors='replace').splitlines():
        pairs = dict(re.findall(r'(\w+)=([^\s]+)', line))
        if line.startswith('lease_filter_probe invocation='):
            key = pairs.pop('invocation')
            groups.append({'invocation': key, **{k: int(v) for k, v in pairs.items()}})
        elif line.startswith('lease_filter_probe_overflow '):
            overflow = int(pairs['calls'])
    expected = {p.relative_to(REFERENCE / 'trace'): p for p in (REFERENCE / 'trace').rglob('*')
                if p.suffix in ('.bf16', '.f32')}
    actual = {p.relative_to(out / 'trace'): p for p in (out / 'trace').rglob('*') if p.suffix in ('.bf16', '.f32')}
    equal = sum(rel in actual and hashlib.sha256(p.read_bytes()).digest() ==
                hashlib.sha256(actual[rel].read_bytes()).digest() for rel, p in expected.items())
    passed = bool(groups) and overflow == 0 and len(expected) == len(actual) == equal == 64
    c.save(out / 'summary.json', {'passed': passed, 'groups': groups, 'overflow_calls': overflow,
        'equal_vectors': equal, 'reference_vectors': len(expected), 'observed_vectors': len(actual),
        'throughput_claim': False, 'timing_attribution': False,
        'limits': 'Counter work perturbs execution. All phases aggregate by Invocation address, not serial lifetime. No per-call clocks/printing, no permission or lookup algorithm changes.'})
    assert passed, 'Preserve raw results: missing counters/overflow or64-vector mismatch'
    print('COUNTER_RESULT', out / 'summary.json', flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--base-link-plan', type=Path, required=True)
    parser.add_argument('--build', action='store_true')
    parser.add_argument('--run', action='store_true')
    args = parser.parse_args()
    if args.build:
        build(args.base_link_plan.resolve())
    if args.run:
        run(args.base_link_plan.resolve())
    if not args.build and not args.run:
        print('PREPARED_NO_BUILD_GPU', S / 'source-freeze.json')
