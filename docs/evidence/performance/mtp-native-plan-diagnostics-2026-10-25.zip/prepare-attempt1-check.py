from pathlib import Path
import difflib,hashlib,importlib.util,json,os,re,sys
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent;R=S.parents[1]
B=R/'.scratch/mtp-performance-convergence-20261025/baseline'
OLD=R/'.scratch/glm-quark-selected-20261024/Q30/graph-integration-preparation'
spec=importlib.util.spec_from_file_location('retained',R/'.scratch/mtp-extraction-regression-20261024/check.py')
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
JOB=next(x for x in b.read(OLD/'host-commands.json')['jobs']if x['name']=='compute_provider_flashinfer--flashinfer_provider')
def args(path):
 x=b.read(path);return x['command']if isinstance(x,dict)else x
def prepare():
 source=R/'src/compute_provider_flashinfer/flashinfer_provider.cc';raw=source.read_bytes();text=raw.decode('utf-8')
 assert b.pin(source)==JOB['source']
 old_obj=OLD/'host1/compute_provider_flashinfer--flashinfer_provider.obj'
 assert b.pin(old_obj)['sha256']=='4d69d0689714294b5c21dee97d1e9ca91ba6455bf0782b1ba26341a264d1660a'
 out=text
 def add(anchor,payload,before=False,count=1):
  nonlocal out
  assert out.count(anchor)==count,(anchor,out.count(anchor))
  marked='// NATIVE_PLAN_DIAG_BEGIN\n'+payload+'\n// NATIVE_PLAN_DIAG_END\n'
  out=out.replace(anchor,marked+anchor if before else anchor+marked,count)
 add('namespace hyle::compute::flashinfer {\n','#include <atomic>\n#include <cstdio>\n#include <cstdlib>\n#include <type_traits>',before=True)
 add('Status qualify_batch(void*opaque,BatchCapacity capacity,const BatchProgramOptions&options)noexcept {\n',
     '#include "'+str(S/'native_plan_probe.h').replace('\\','/')+'"',before=True)
 assert out.count('bool can_reuse_batch_plan(')==1
 out=out.replace('bool can_reuse_batch_plan(','bool can_reuse_batch_plan_original(',1)
 add('Status query_batch_layout(BatchSlot&slot,Queue&queue,const BatchLayoutVersion&layout,\n',
     'bool can_reuse_batch_plan(const BatchSlot&slot,const BatchLayoutVersion&layout)noexcept{\n'
     '  const bool original_result=can_reuse_batch_plan_original(slot,layout);\n'
     '  native_plan_probe::decision(slot,layout,original_result);\n'
     '  return original_result;\n}\n',before=True)
 add('                         bool allow_update,native::BatchFacts&facts) {\n',
     '  native_plan_probe::QueryScope diagnostic_query{slot,layout,allow_update};')
 add('    facts={};facts.float_bytes=slot.report.float_workspace_bytes;facts.int_bytes=slot.report.int_workspace_bytes;\n',
     '    native_plan_probe::facts(slot,layout,native_plan_probe::QueryReuse,facts);')
 add('  slot.workspace_query={layout,std::move(queue_owner),slot.primary,spec,facts};\n',
     '  native_plan_probe::facts(slot,layout,native_plan_probe::NativeQuery,facts);')
 add('                                    detail::BatchWorkspaceViews workspace,BatchPlanReport*report)noexcept {\n  auto&slot=*static_cast<BatchSlot*>(opaque);\n',
     '  native_plan_probe::facts(slot,layout,native_plan_probe::PlanBegin,native::BatchFacts{},workspace.float_workspace.size(),workspace.int_workspace.size(),workspace.host_workspace.size());')
 add('      if(status.ok()){slot.kv_chunk_rows=facts.kv_chunk_rows;slot.spec=spec;slot.generation=layout.generation();slot.layout=layout;*report={.layout_generation=layout.generation(),.float_workspace_bytes=facts.float_bytes,.int_workspace_bytes=facts.int_bytes,.cta_tile_q=facts.cta_tile_q,.padded_batch_size=facts.padded_batch_size,.split_kv=facts.split_kv,.bf16_partials=facts.bf16_partials};slot.report=*report;}\n',
     '      if(status.ok())native_plan_probe::facts(slot,layout,native_plan_probe::PlanCommit,facts,workspace.float_workspace.size(),workspace.int_workspace.size(),workspace.host_workspace.size());')
 add('  slot.report=*report;return true;\n',
     '  native_plan_probe::facts(slot,layout,native_plan_probe::UpdateCommit,native::BatchFacts{\n'
     '      .float_bytes=report->float_workspace_bytes,.int_bytes=report->int_workspace_bytes,\n'
     '      .cta_tile_q=report->cta_tile_q,.padded_batch_size=report->padded_batch_size,\n'
     '      .kv_chunk_rows=slot.kv_chunk_rows,.split_kv=report->split_kv,.bf16_partials=report->bf16_partials});',before=True)
 restored=re.sub(r'// NATIVE_PLAN_DIAG_BEGIN\n.*?// NATIVE_PLAN_DIAG_END\n','',out,flags=re.S)
 restored=restored.replace('bool can_reuse_batch_plan_original(','bool can_reuse_batch_plan(',1)
 assert restored.encode('utf-8')==raw
 (S/'overlay').mkdir(exist_ok=False);(S/'overlay/flashinfer_provider.cc').write_text(out,encoding='utf-8',newline='\n')
 (S/'before-flashinfer_provider.cc').write_bytes(raw)
 (S/'source.patch').write_text(''.join(difflib.unified_diff(text.splitlines(True),out.splitlines(True),fromfile='canonical/flashinfer_provider.cc',tofile='private/overlay/flashinfer_provider.cc')),encoding='utf-8')
 # Pin the actual cached object/source contract. Do not rebuild SDKs.
 deps=b.read(OLD/'host1/compute_provider_flashinfer--flashinfer_provider-deps.json')['Data']['Includes']
 manifest=b.read(OLD/'compiled-source-snapshot/manifest.json');old_pins={x['original_path']:x for x in manifest['copies']}
 checked=[];missing=[]
 for path in map(Path,deps):
  path=path.resolve()
  if not path.is_relative_to(R):continue
  rel=path.relative_to(R).as_posix();p=b.pin(path)
  if rel in old_pins:
   assert p['sha256']==old_pins[rel]['compiled_sha256'],('stale dependency',rel)
   checked.append(p)
  else:missing.append(p)
 b.save(S/'equivalence.json',dict(original=b.pin(source),overlay=b.pin(S/'overlay/flashinfer_provider.cc'),helper=b.pin(S/'native_plan_probe.h'),
    restored_body_sha256=hashlib.sha256(restored.encode()).hexdigest(),byte_equal_to_original=True,
    original_predicate_body_unchanged=True,wrapper_returns_original_result=True,
    cached_object=b.pin(old_obj),cached_successful_job=JOB,checked_repository_dependencies=checked,
    dependencies_without_snapshot_pin=missing,capacities=dict(slots=64,events=4096,requests_per_layout=8,detail_queries_per_slot=20),
    no_new_native_calls=True,no_math_route_or_budget_change=True))
 print('SOURCE_EQUIVALENCE_PASS',len(checked),'repo dependencies checked;',len(missing),'without snapshot pin',flush=True)
def build():
 original=JOB['command'];flags=[];skip=False
 for value in original[1:]:
  if skip:skip=False;continue
  if value=='/sourceDependencies':skip=True;continue
  if value.lower().startswith(('/fo','/fd'))or value.lower().endswith(('.cc','.cpp')):continue
  flags.append(value)
 folder=S/'compile';source=S/'overlay/flashinfer_provider.cc'
 command=[original[0],*flags,str(source),'/sourceDependencies',str(folder/'dependencies.json'),'/Fo'+str(folder/'provider.obj')]
 assert sum(x.lower().endswith(('.cc','.cpp'))for x in command)==1
 env=b.environment(command[0]);b.execute(command,folder,env,240)
 dependencies=[Path(x).resolve()for x in b.read(folder/'dependencies.json')['Data']['Includes']]
 b.save(folder/'source-pins.json',dict(source=b.pin(source),dependencies=[b.pin(p)for p in dependencies if p.is_relative_to(R)],equivalence=b.pin(S/'equivalence.json')))
 link=args(B/'link/command.json');old=str(OLD/'host1/compute_provider_flashinfer--flashinfer_provider.obj');assert link.count(old)==1
 link=[str(folder/'provider.obj')if x==old else x for x in link if not x.upper().startswith(('/OUT:','/MAP:','/PDB:','/IMPLIB:'))]
 link+=['/OUT:'+str(S/'link/hyle.exe')]
 b.execute(link,S/'link',env,120)
 dll=B/'link/hyle_ggml_cpu_gdn_scale_v3.dll';os.link(dll,S/'link'/dll.name)
 b.save(S/'ready.json',dict(image=b.pin(S/'link/hyle.exe'),baseline=b.read(B/'ready.json')['image'],overlay=b.pin(source),helper=b.pin(S/'native_plan_probe.h'),
    replaced_object=b.pin(OLD/'host1/compute_provider_flashinfer--flashinfer_provider.obj'),new_object=b.pin(folder/'provider.obj'),link=b.pin(S/'link/command.json'),
    canonical_main=b.pin(R/'engine/models/qwen35/main.cc'),Graph_TUs_rebuilt=0,SDK_builds=0,HTTP=0))
def run():
 command=b.read(B/'two-turn-timing/02-hyle_mtp/command.json')['command'][:]
 assert b.pin(Path(command[0]))['sha256']=='c343db76232c4b5bd34878820433057b8c23789cd1b170b6a3b86cd91bf82fa1'
 command[0]=str(S/'link/hyle.exe');env=dict(os.environ,PATH=str(S/'link')+';'+b.read(B/'runtime.json')['PATH'],HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1')
 b.execute(command,S/'run',env,120)
if __name__=='__main__':{'prepare':prepare,'build':build,'run':run}[sys.argv[1]]()
