from pathlib import Path
import collections, hashlib, json, zipfile

S = Path(__file__).resolve().parent
R = S.parents[1]
B = R / '.scratch/mtp-performance-convergence-20261025/baseline'

def load(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))

def save(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')

def pin(path):
    return dict(path=str(path), bytes=path.stat().st_size,
                sha256=hashlib.sha256(path.read_bytes()).hexdigest())

def report(path):
    return json.loads(next(line for line in path.read_text().splitlines() if line.startswith('{')))

excluded = []
def clean(value, path=''):
    if isinstance(value, dict):
        out = {}
        for key, child in value.items():
            here = path + '/' + key
            if key == 'seconds' or key.endswith('_seconds') or 'tokens_per_second' in key:
                excluded.append(here)
            else:
                out[key] = clean(child, here)
        return out
    if isinstance(value, list):
        return [clean(x, path + '/' + str(i)) for i, x in enumerate(value)]
    return value

def differences(a, b, path=''):
    if type(a) != type(b): return [dict(path=path, baseline=a, actual=b)]
    if isinstance(a, dict):
        out = []
        for key in sorted(a.keys() | b.keys()):
            if key not in a or key not in b: out.append(dict(path=path+'/'+key, baseline=a.get(key), actual=b.get(key)))
            else: out.extend(differences(a[key], b[key], path+'/'+key))
        return out
    if isinstance(a, list):
        if len(a) != len(b): return [dict(path=path, baseline_length=len(a), actual_length=len(b))]
        return [d for i, (x, y) in enumerate(zip(a,b)) for d in differences(x,y,path+'/'+str(i))]
    return [] if a == b else [dict(path=path, baseline=a, actual=b)]

raw = (S/'run/stderr.log').read_text()
rows = [json.loads(line[6:]) for line in raw.splitlines() if line.startswith('NPLAN ')]
meta = next(x for x in rows if x['type'] == 'meta')
slots = [x for x in rows if x['type'] == 'slot']
events = [x for x in rows if x['type'] == 'event']
assert len(slots) == meta['slots'] and len(events) == meta['events']
assert all(meta[k] == 0 for k in ('slot_overflow','event_overflow','array_truncations','inconsistent_reasons','concurrent_skips'))
baseline_report = report(B/'two-turn-timing/02-hyle_mtp/stdout.log')
actual_report = report(S/'run/stdout.log')
base_clean = clean(baseline_report)
actual_clean = clean(actual_report)
diff = differences(base_clean, actual_clean)
save(S/'non-time-comparison.json', dict(equal=not diff, differences=diff,
    excluded_keys=sorted(set(excluded)), criterion="key == 'seconds' or key.endswith('_seconds') or 'tokens_per_second' in key",
    baseline=pin(B/'two-turn-timing/02-hyle_mtp/stdout.log'), actual=pin(S/'run/stdout.log')))
assert not diff, diff[:10]

role_calls = collections.defaultdict(list)
for batch in actual_report['batches']:
    role_calls[batch['role']].append(batch['index'] + 1)

by_slot = []
all_kinds = collections.Counter()
query_reasons = collections.Counter()
update_reasons = collections.Counter()
groups = collections.defaultdict(list)
for slot in slots:
    own = [x for x in events if x['slot'] == slot['slot']]
    queries = [x for x in own if x['kind'] == 'query']
    first = queries[0]
    signature = (slot['queries'], first['new']['query_rows'])
    groups[signature].append(slot['slot'])
    all_kinds.update(slot['kinds'])
    query_reasons.update(slot['query_reasons'])
    update_reasons.update(slot['update_reasons'])
    sequence = []
    for query in queries:
        q = query['query']
        detail = [x for x in own if x['query'] == q]
        predicate = next((x for x in detail if x['kind'] == 'predicate' and x['in_query']), None)
        native = next((x for x in detail if x['kind'] == 'native_query'), None)
        commit = next((x for x in detail if x['kind'] == 'plan_commit'), None)
        kind = 'forced_fresh' if not query['allow_update'] else predicate['reason'] if predicate else 'unknown'
        item = dict(query=q, reason=kind, allow_update=bool(query['allow_update']),
                    slot_generation=query['slot_generation'], old=query['old'], new=query['new'],
                    prior_chunk_rows=query['old_chunk'], prior_cta=query['old_cta'], prior_padded=query['old_padded'],
                    prior_split=bool(query['old_split']), prior_workspace=dict(float=query['old_float_bytes'], integer=query['old_int_bytes']),
                    native_query_executed=native is not None, new_plan_committed=commit is not None)
        if commit: item['committed_facts'] = commit['facts']; item['allocated'] = commit['allocated']
        # Matching occurrence counts establish role correlation, not cross-process timestamps.
        if slot['queries'] in (8,58):
            role = 3 if slot['queries'] == 8 else 4
            item['correlated_role'] = role
            item['correlated_global_call'] = role_calls[role][q-1]
        sequence.append(item)
    outside_detailed_predicates = {k: slot['query_reasons'][k] - sum(x['reason'] == k for x in sequence if x['allow_update'])
                                  for k in slot['query_reasons']}
    by_slot.append(dict(slot=slot['slot'], address=slot['address'], native_plan=slot['native_plan'],
        queries=slot['queries'], kinds=slot['kinds'], query_reasons=slot['query_reasons'], update_reasons=slot['update_reasons'],
        detailed_queries=sequence, query_predicate_counts_beyond_detail=outside_detailed_predicates))
save(S/'native-slot-sequences.json', by_slot)

specific = [x for x in by_slot if x['queries'] == 8]
seventh = [next(x for x in slot['detailed_queries'] if x['query'] == 7) for slot in specific]
assert len(seventh) == 7 and all(x['reason'] == 'chunk_count' and x['correlated_global_call'] == 37 for x in seventh)
assert all(x['old']['kv']['values'] == [0,13] and x['new']['kv']['values'] == [0,24] and
           x['old']['query']['values'] == x['new']['query']['values'] and
           x['prior_chunk_rows'] == 128 and x['prior_padded'] == 2 and x['committed_facts']['padded_batch_size'] == 3
           for x in seventh)

binary_paths = sorted(p for p in S.rglob('*') if p.is_file() and p.suffix.lower() in {'.obj','.exe','.exp','.lib','.dll','.pdb','.map'})
cleanup = [dict(relative_repository_path=p.relative_to(R).as_posix(), **pin(p)) for p in binary_paths]
save(S/'cleanup-candidates.json', dict(performed=False, count=len(cleanup), logical_bytes=sum(x['bytes'] for x in cleanup), files=cleanup,
    hardlink_note='link/hyle_ggml_cpu_gdn_scale_v3.dll is a hardlink to preserved baseline DLL; logical bytes are not distinct physical blocks.'))

summary = dict(status='one_actual_process_completed_no_product_changes',
    scope='Single original clean-c343 two-turn CUDA MTP journey; private FlashInfer provider host TU observer only. Not TPS, quality or candidate optimization evidence.',
    attempts=dict(prepare_first='pin_rejected_before_compile_or_model; preserved prepare-dependency-firstfailure.json',
                  correction='Complete original cached versions of three headers via private include overlay; 52 repository dependency pins match.',
                  provider_compiles=1, links=1, model_processes=1),
    process=load(S/'run/process.json'), compile=load(S/'compile/process.json'), link=load(S/'link/process.json'),
    instrumentation=meta, aggregate=dict(queries=sum(x['queries'] for x in slots), kinds=dict(all_kinds),
        query_predicate_reasons=dict(query_reasons), update_predicate_reasons=dict(update_reasons),
        forced_fresh_queries=sum(x['kind']=='query' and not x['allow_update'] for x in events)),
    slot_groups=[dict(queries=k[0], native_query_rows=k[1], slots=v) for k,v in sorted(groups.items())],
    non_time_report_equal=True, comparison=pin(S/'non-time-comparison.json'),
    actual_work={k: actual_report[k] for k in ('generated_tokens','prefill_target_rows','prefill_draft_rows','verified_target_rows',
        'actual_target_rows','actual_draft_rows','draft_rounds','consumed_drafts','actual_graph_calls')},
    definite_findings=[
        'Each of seven 8-query native slots rejected reuse at query7/global call37 (turn2 first decode) because chunk_count changed, not query shape, schema or lost generation.',
        'KV page indptr [0,13] -> [0,24]; chunk128 rows / page16 rows = 8 pages; ceil(13/8)=2 -> ceil(24/8)=3. Native plan commit padded2 ->3, float263168 ->394752B, int82 ->83B; CTA16/chunk128/split=true unchanged.',
        'Each of seven 58-query slots had exactly two chunk_count query rejections, both after its first20 detailed queries; exact query ordinals/layouts of these14 late rejections were not captured.',
        'All 427 reuse query decisions and corresponding427 update decisions succeeded; every observed non-initial query predicate rejection in whole-run counts was chunk_count (21 total).'],
    ignored_fields=[
        'Default reason/result/allow_update values outside their relevant event kinds are ignored, not classified as successful reuse.',
        'QueryReuse facts only supply existing workspace byte counts; their zero CTA/chunk fields are ignored.',
        'PlanCommit old/old_* fields are post-commit current slot state; Query/PlanBegin supply genuine pre-plan facts.',
        'Raw numeric addresses/native_plan IDs are per-process identity only; no across-process address or clock subtraction.'],
    limitations=[
        'First20 detailed queries per slot only; full query/update/plan/reason counters continue through all58. No exact late rejection ordinals or layouts inferred.',
        'Native slots are correlated with roles3/4 by exact8/58 occurrence counts. Slot6 row1 is the role3 draft, followed by six target row2 slots7..12. Role4 slot13 row2 precedes six target row2 slots14..19, consistent with Recipe emission order; exact target layer IDs are not directly instrumented.',
        'No direct Graph invalidation stack/step IDs recorded in this process. The call37 association joins identical non-time reports with previous separate-process capture evidence; it does not prove the exact higher-level caller address.',
        'Generation/indptr/tails and existing native-plan facts are observed; page-ID contents, native kernel topology and GraphExecUpdate outcomes are unknown.',
        'No native timers/profile or causal latency measurement; replan semantics do not establish recoverable speedup or justify bypassing split/chunk guards.'],
    source_equivalence=pin(S/'equivalence.json'), header_overlay=pin(S/'header-overlay.json'), ready=load(S/'ready.json'),
    clean_baseline_unchanged=pin(B/'link/hyle.exe'), source_sequence=pin(S/'native-slot-sequences.json'),
    cleanup=load(S/'cleanup-candidates.json'), HTTP=0, SDK_builds=0, Graph_TUs_rebuilt=0, canonical_product_edits=0)
assert summary['clean_baseline_unchanged']['sha256'] == 'c343db76232c4b5bd34878820433057b8c23789cd1b170b6a3b86cd91bf82fa1'
assert all_kinds['native_query'] == all_kinds['plan_commit'] == 47 and all_kinds['query_reuse'] == all_kinds['update_commit'] == 427
save(S/'summary.json', summary)
print(json.dumps(dict(report_equal=not diff, meta=meta, kinds=dict(all_kinds), query_reasons=dict(query_reasons),
    cleanup_count=len(cleanup), cleanup_logical_bytes=sum(x['bytes'] for x in cleanup))))
