from pathlib import Path
import hashlib, json, zipfile

S=Path(__file__).resolve().parent
R=S.parents[1]
B=R/'.scratch/mtp-performance-convergence-20261025/baseline'

def pin(p):
    return dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def save(p,x):
    p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')

refs=S/'references';refs.mkdir(exist_ok=True)
baseline_report=B/'two-turn-timing/02-hyle_mtp/stdout.log'
(refs/'baseline-stdout.log').write_bytes(baseline_report.read_bytes())
frozen_main=B/'recorded-source/engine/models/qwen35/main.cc'
canonical_main=R/'engine/models/qwen35/main.cc'
assert pin(frozen_main)['sha256']==pin(canonical_main)['sha256']=='9b73fe9afe325d139072a94632e26d739e2b3cb48b411320c0c5bed320e9b9e9'
save(refs/'contracts.json',dict(
    included_baseline_report=pin(refs/'baseline-stdout.log'),original_report=pin(baseline_report),
    frozen_main=pin(frozen_main),current_main=pin(canonical_main),
    original_argv=pin(B/'two-turn-timing/02-hyle_mtp/command.json'),
    runtime=pin(B/'runtime.json'),baseline_ready=pin(B/'ready.json'),
    baseline_image=pin(B/'link/hyle.exe'),
    source_and_artifact_scope='Only private provider overlay/helper, original provider and three exact old headers are bundled. Remaining cached source/object/compiler/SDK paths in recipes and dependency pins are explicit external prerequisites; not archive payloads. The clean baseline application/source/runtime are pinned unchanged, with raw stdout included for full non-time recomparison.',
    prior_call37_capture_join=pin(R/'.scratch/mtp-performance-convergence-20261025/early-record-join/result.json')))
skip_names={'proof.zip','proof-pins.json','proof-package.json'}
binary_suffixes={'.obj','.exe','.exp','.lib','.dll','.pdb','.map','.pyc'}
files=sorted(p for p in S.rglob('*') if p.is_file() and p.name not in skip_names and
             p.suffix.lower() not in binary_suffixes and p.name!='live.json')
assert all(p.suffix.lower() not in binary_suffixes for p in files)
pins=[dict(archive_path=p.relative_to(S).as_posix(),**pin(p))for p in files]
save(S/'proof-pins.json',dict(files=pins,entries=len(pins),payload_bytes=sum(x['bytes']for x in pins),
    exclusions='No rebuildable binaries, SDK or model weights; external recipe/dependency artifacts are pins, not falsely included payloads.'))
files.append(S/'proof-pins.json')
archive=S/'proof.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9)as z:
    for p in files:z.write(p,p.relative_to(S).as_posix())
with zipfile.ZipFile(archive)as z:
    assert z.testzip()is None
    for item in pins:
        assert hashlib.sha256(z.read(item['archive_path'])).hexdigest()==item['sha256']
save(S/'proof-package.json',dict(archive=pin(archive),pins=pin(S/'proof-pins.json'),summary=pin(S/'summary.json'),
    archive_entries=len(files),cleanup=pin(S/'cleanup-candidates.json'),
    GPU='released after single terminal process',product_edits=0,HTTP=0))
print(json.dumps(dict(archive=pin(archive),summary=pin(S/'summary.json'),entries=len(files))))
