// Private observer; included after BatchSlot in the original anonymous namespace.
namespace native_plan_probe {
enum Reason : unsigned { Reuse, ForcedFresh, NoGeneration, ForeignSchema, QueryShape, MlaKvTail,
                         ChunkInvalid, ChunkCount, Unknown, ReasonCount };
enum Kind : unsigned { Query, Predicate, QueryReuse, NativeQuery, PlanBegin, PlanCommit, UpdateCommit, KindCount };
struct Array { unsigned count, copied; std::int32_t values[9]; };
struct Layout {
  std::uint64_t generation;
  std::uint32_t requests, query_rows, kv_rows, page_refs;
  Array query, kv, tail;
};
struct Event {
  unsigned sequence, slot, query, kind, reason, in_query, allow_update, result;
  std::uint32_t old_query_rows, old_chunk, old_cta, old_padded;
  bool old_split, old_bf16, mla, paged;
  std::uint64_t generation;
  std::size_t old_float_bytes, old_int_bytes;
  Layout old_layout, new_layout;
  native::BatchFacts facts;
  std::size_t allocated_float, allocated_int, allocated_host;
};
struct Slot {
  std::uintptr_t address, native_plan;
  unsigned queries; bool in_query;
  unsigned long long kinds[KindCount], reasons[2][ReasonCount];
};
struct Store {
  Slot slots[64]; Event events[4096]; unsigned slots_used, events_used;
  unsigned long long slot_overflow, event_overflow, array_truncations, inconsistent_reasons;
};
static_assert(std::is_trivially_copyable_v<Store>);
inline Store store{};
inline std::atomic_flag writer = ATOMIC_FLAG_INIT;
inline std::atomic<unsigned long long> contention{0};
struct Guard {
  bool valid = !writer.test_and_set(std::memory_order_acquire);
  Guard() noexcept { if (!valid) contention.fetch_add(1, std::memory_order_relaxed); }
  ~Guard() { if (valid) writer.clear(std::memory_order_release); }
};
inline unsigned find(const BatchSlot &value) noexcept {
  const auto address = reinterpret_cast<std::uintptr_t>(&value);
  for (unsigned i = 0; i < store.slots_used; ++i) if (store.slots[i].address == address) return i;
  if (store.slots_used == 64) { ++store.slot_overflow; return 64; }
  const unsigned i = store.slots_used++; store.slots[i].address = address;
  store.slots[i].native_plan = reinterpret_cast<std::uintptr_t>(value.plan); return i;
}
inline Array copy(std::span<const std::int32_t> values) noexcept {
  Array out{}; out.count = static_cast<unsigned>(values.size());
  out.copied = static_cast<unsigned>(std::min<std::size_t>(9, values.size()));
  if (values.size() > 9) ++store.array_truncations;
  for (unsigned i = 0; i < out.copied; ++i) out.values[i] = values[i];
  return out;
}
inline Layout layout(const BatchLayoutVersion &value) noexcept {
  Layout out{}; if (!value.valid()) return out;
  const auto facts = value.facts(); const auto host = value.host();
  out.generation = value.generation(); out.requests = facts.requests; out.query_rows = facts.query_rows;
  out.kv_rows = facts.kv_rows; out.page_refs = facts.page_refs;
  out.query = copy(host.query_indptr); out.kv = copy(host.kv_indptr); out.tail = copy(host.last_page_lengths); return out;
}
inline Event *append(unsigned index, Kind kind, const BatchSlot &value, const BatchLayoutVersion &next) noexcept {
  if (index == 64) return nullptr;
  auto &slot = store.slots[index]; ++slot.kinds[kind];
  if (slot.queries > 20) return nullptr;
  if (store.events_used == 4096) { ++store.event_overflow; return nullptr; }
  auto &event = store.events[store.events_used++]; event.sequence = store.events_used;
  event.slot = index; event.query = slot.queries; event.kind = kind; event.in_query = slot.in_query;
  event.old_query_rows = value.spec.query_rows; event.old_chunk = value.kv_chunk_rows;
  event.old_cta = value.report.cta_tile_q; event.old_padded = value.report.padded_batch_size;
  event.old_split = value.report.split_kv; event.old_bf16 = value.report.bf16_partials;
  event.old_float_bytes = value.report.float_workspace_bytes; event.old_int_bytes = value.report.int_workspace_bytes;
  event.mla = value.mla; event.paged = value.spec.paged;
  event.generation = value.generation;
  event.old_layout = layout(value.layout); event.new_layout = layout(next); return &event;
}
inline Reason reason(const BatchSlot &value, const BatchLayoutVersion &next) noexcept {
  if (!value.generation) return NoGeneration;
  if (!value.layout.schema().owns(next)) return ForeignSchema;
  const auto old = value.layout.host(), current = next.host();
  const auto equal = [](auto a, auto b) { return a.size() == b.size() && std::equal(a.begin(), a.end(), b.begin()); };
  if (!equal(old.query_indptr, current.query_indptr)) return QueryShape;
  if (value.mla && (!equal(old.kv_indptr, current.kv_indptr) || !equal(old.last_page_lengths, current.last_page_lengths))) return MlaKvTail;
  if (value.spec.query_rows && !equal(old.kv_indptr, current.kv_indptr)) {
    const std::uint64_t units = value.spec.paged ? value.spec.page_size : 1U;
    if (!value.kv_chunk_rows || value.kv_chunk_rows % units || !value.report.cta_tile_q) return ChunkInvalid;
    const auto chunk = value.kv_chunk_rows / units;
    const auto chunks = [&](HostBatchLayout metadata, std::size_t request) {
      auto length = std::uint64_t(metadata.kv_indptr[request + 1] - metadata.kv_indptr[request]);
      if (value.spec.window_left >= 0) {
        const auto window = std::uint64_t(value.spec.window_left) + value.report.cta_tile_q;
        length = std::min(length, (window + units - 1U) / units);
      }
      return (std::max(length, std::uint64_t{1}) + chunk - 1U) / chunk;
    };
    for (std::size_t request = 0; request + 1 < current.query_indptr.size(); ++request) {
      if (current.query_indptr[request] == current.query_indptr[request + 1]) continue;
      if (chunks(old, request) != chunks(current, request)) return ChunkCount;
    }
  }
  return Reuse;
}
inline void decision(const BatchSlot &value, const BatchLayoutVersion &next, bool result) noexcept {
  Guard guard; if (!guard.valid) return; const unsigned index = find(value); if (index == 64) return;
  const auto cause = reason(value, next);
  if ((cause == Reuse) != result) ++store.inconsistent_reasons;
  ++store.slots[index].reasons[store.slots[index].in_query ? 0 : 1][cause];
  if (auto *event = append(index, Predicate, value, next)) { event->reason = cause; event->result = result; }
}
struct QueryScope final {
  const BatchSlot &value;
  QueryScope(const BatchSlot &v, const BatchLayoutVersion &next, bool allow_update) noexcept : value(v) {
    Guard guard; if (!guard.valid) return; const unsigned index = find(value); if (index == 64) return;
    auto &slot = store.slots[index]; ++slot.queries; slot.in_query = true;
    if (auto *event = append(index, Query, value, next)) { event->allow_update = allow_update; event->reason = allow_update ? Unknown : ForcedFresh; }
  }
  ~QueryScope() { Guard guard; if (!guard.valid) return; const unsigned index = find(value); if (index != 64) store.slots[index].in_query = false; }
};
inline void facts(const BatchSlot &value, const BatchLayoutVersion &next, Kind kind, const native::BatchFacts &observed,
                  std::size_t floating = 0, std::size_t integer = 0, std::size_t host = 0) noexcept {
  Guard guard; if (!guard.valid) return;
  if (auto *event = append(find(value), kind, value, next)) { event->facts = observed; event->allocated_float = floating; event->allocated_int = integer; event->allocated_host = host; }
}
inline void print_array(const Array &value) noexcept {
  std::fprintf(stderr, "{\"count\":%u,\"values\":[", value.count);
  for (unsigned i = 0; i < value.copied; ++i) std::fprintf(stderr, "%s%d", i ? "," : "", value.values[i]);
  std::fprintf(stderr, "]}");
}
inline void print_layout(const Layout &value) noexcept {
  std::fprintf(stderr, "{\"generation\":%llu,\"requests\":%u,\"query_rows\":%u,\"kv_rows\":%u,\"page_refs\":%u,\"query\":",
      static_cast<unsigned long long>(value.generation), value.requests, value.query_rows, value.kv_rows, value.page_refs);
  print_array(value.query); std::fprintf(stderr, ",\"kv\":"); print_array(value.kv); std::fprintf(stderr, ",\"tail\":"); print_array(value.tail); std::fprintf(stderr, "}");
}
inline void dump() noexcept {
  static constexpr const char *reasons[ReasonCount] = {"reuse", "forced_fresh", "no_generation", "foreign_schema", "query_shape", "MLA_KV_tail", "chunk_invalid", "chunk_count", "unknown"};
  static constexpr const char *kinds[KindCount] = {"query", "predicate", "query_reuse", "native_query", "plan_begin", "plan_commit", "update_commit"};
  std::fprintf(stderr, "NPLAN {\"type\":\"meta\",\"slots\":%u,\"events\":%u,\"slot_overflow\":%llu,\"event_overflow\":%llu,\"array_truncations\":%llu,\"inconsistent_reasons\":%llu,\"concurrent_skips\":%llu}\n",
      store.slots_used, store.events_used, store.slot_overflow, store.event_overflow, store.array_truncations, store.inconsistent_reasons, contention.load());
  for (unsigned i = 0; i < store.slots_used; ++i) {
    const auto &slot = store.slots[i];
    std::fprintf(stderr, "NPLAN {\"type\":\"slot\",\"slot\":%u,\"address\":%llu,\"native_plan\":%llu,\"queries\":%u,\"kinds\":{", i,
        static_cast<unsigned long long>(slot.address), static_cast<unsigned long long>(slot.native_plan), slot.queries);
    for (unsigned k = 0; k < KindCount; ++k) std::fprintf(stderr, "%s\"%s\":%llu", k ? "," : "", kinds[k], slot.kinds[k]);
    std::fprintf(stderr, "},\"query_reasons\":{");
    for (unsigned r = 0; r < ReasonCount; ++r) std::fprintf(stderr, "%s\"%s\":%llu", r ? "," : "", reasons[r], slot.reasons[0][r]);
    std::fprintf(stderr, "},\"update_reasons\":{");
    for (unsigned r = 0; r < ReasonCount; ++r) std::fprintf(stderr, "%s\"%s\":%llu", r ? "," : "", reasons[r], slot.reasons[1][r]);
    std::fprintf(stderr, "}}\n");
  }
  for (unsigned i = 0; i < store.events_used; ++i) {
    const auto &event = store.events[i];
    std::fprintf(stderr, "NPLAN {\"type\":\"event\",\"sequence\":%u,\"slot\":%u,\"query\":%u,\"kind\":\"%s\",\"reason\":\"%s\",\"in_query\":%u,\"allow_update\":%u,\"result\":%u,\"slot_generation\":%llu,\"old_query_rows\":%u,\"old_chunk\":%u,\"old_cta\":%u,\"old_padded\":%u,\"old_split\":%u,\"old_bf16\":%u,\"mla\":%u,\"paged\":%u,\"old_float_bytes\":%zu,\"old_int_bytes\":%zu,\"old\":",
        event.sequence, event.slot, event.query, kinds[event.kind], reasons[event.reason], event.in_query, event.allow_update, event.result, static_cast<unsigned long long>(event.generation),
        event.old_query_rows, event.old_chunk, event.old_cta, event.old_padded, unsigned(event.old_split), unsigned(event.old_bf16), unsigned(event.mla), unsigned(event.paged), event.old_float_bytes, event.old_int_bytes);
    print_layout(event.old_layout); std::fprintf(stderr, ",\"new\":"); print_layout(event.new_layout);
    std::fprintf(stderr, ",\"facts\":{\"float_bytes\":%zu,\"int_bytes\":%zu,\"cta_tile_q\":%u,\"padded_batch_size\":%u,\"kv_chunk_rows\":%u,\"split_kv\":%u,\"bf16_partials\":%u},\"allocated\":{\"float\":%zu,\"int\":%zu,\"host\":%zu}}\n",
        event.facts.float_bytes, event.facts.int_bytes, event.facts.cta_tile_q, event.facts.padded_batch_size, event.facts.kv_chunk_rows, unsigned(event.facts.split_kv), unsigned(event.facts.bf16_partials), event.allocated_float, event.allocated_int, event.allocated_host);
  }
}
[[maybe_unused]] inline const int registered = std::atexit(dump);
} // namespace native_plan_probe
