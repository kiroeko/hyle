"""Join only existing logical preparation and capture diagnostics; no execution."""
from pathlib import Path
from collections import defaultdict, Counter
import hashlib
import json
import re

D=Path(__file__).resolve().parent;R=D.parents[2]
C=D.parent/'current-cuda';N=R/'.scratch/mtp-capture-miss-20261025'
def pin(p):return dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def raw(p):return json.loads(next(x for x in reversed(p.read_text().splitlines())if x.startswith('{')))
def no_time(x):
    if isinstance(x,dict):return{k:no_time(v)for k,v in x.items()if k!='seconds'and not k.endswith('_seconds')and 'tokens_per_second'not in k}
    return[no_time(v)for v in x]if isinstance(x,list)else x

roles={0:'Text',2:'MtpPrefill',3:'MtpRound',4:'MtpCatchupRound',7:'MtpCatchupPrefill'}
arms={};mtp_rows=[]
for arm in('mtp-two-turn','plain-two-turn'):
    p=C/arm;report=raw(p/'stdout.log');detail=report['sessions'][0]['result']
    lines=(p/'stderr.log').read_text().splitlines();rows=[];groups=defaultdict(list)
    role_prepares=Counter();round_index=0;context=0
    preparation=[(line_number,line)for line_number,line in enumerate(lines,1)if line.startswith('private_preparation')]
    assert len(preparation)==len(report['dispatch'])==len(report['batches'])
    for index,((line_number,line),dispatch,batch)in enumerate(zip(preparation,report['dispatch'],report['batches']),1):
        kv=dict(re.findall(r'(\w+)=([^ ]+)',line));numbers={k:int(kv[k])for k in('role','generation','requests','input_rows','slot','prior_uses','recorded','reused')}
        role=numbers['role'];prepare_key=(role,numbers['generation'],batch['tokens']);role_prepares[prepare_key]+=1
        assert role==batch['role']and bool(numbers['generation'])==batch['generation']
        assert numbers['prior_uses']==role_prepares[prepare_key]-1 if numbers['generation'] else True
        before=context
        if numbers['generation']:
            actual_round=detail['rounds'][round_index];context+=actual_round['committed_target_rows'];round_index+=1
        else: context+=batch['tokens']
        row=dict(call=index,turn=dispatch['turn'],role_name=roles[role],role_prepare=role_prepares[prepare_key],
            **numbers,target_query_rows=batch['tokens'],context_before=before,context_after=context,
            stderr_line=line_number,replay_prepare_seconds=float(kv['replay_seconds']))
        rows.append(row);groups[(dispatch['turn'],role,numbers['generation'],numbers['input_rows'],batch['tokens'])].append(row)
    assert context==435 and round_index==len(detail['rounds'])
    summaries=[]
    for key,group in groups.items():
        turn,role,generation,logical,query=key
        summaries.append(dict(turn=turn,role=role,role_name=roles[role],generation=bool(generation),calls=len(group),
            requests=sorted({r['requests']for r in group}),logical_input_rows=logical,target_query_rows=query,
            phase_slots=sorted({r['slot']for r in group}),prior_uses=[min(r['prior_uses']for r in group),max(r['prior_uses']for r in group)],
            recorded_ranges=sum(r['recorded']for r in group),reused_ranges=sum(r['reused']for r in group),
            recording_calls=[r['call']for r in group if r['recorded']]))
    arms[arm]=dict(stdout=pin(p/'stdout.log'),stderr=pin(p/'stderr.log'),process=read(p/'process.json'),
        call_count=len(rows),turns=[{k:t[k]for k in('turn','new_user_tokens','pending_flushed','context_before','context_after','output_begin','output_end')}for t in detail['turns']],
        turn_role_groups=summaries,total_recorded_ranges=sum(r['recorded']for r in rows),
        nonfirst_phase_use_recorded_ranges=sum(r['recorded']for r in rows if r['prior_uses']>0),
        recording_calls=[r for r in rows if r['recorded']],
        native_plan_field_present=any('native_plan'in line for _,line in preparation))
    if arm=='mtp-two-turn':mtp_rows=rows;timer_report=report

capture=read(N/'summary2.json');capture_report=raw(N/'run2/stdout.log')
assert no_time(timer_report)==no_time(capture_report)
events=[json.loads(line[8:])for line in(N/'run2/stderr.log').read_text().splitlines()if line.startswith('CAPDIAG ')]
hard=[e for e in events if e.get('kind')=='invalidated'and e['b']==0]
slot_role={0:2,1:3,2:4,3:7}
capture_records=[]
for series in capture['range_series']:
    seen=set()
    for snap in series['snapshots']:
        fp=snap['current_fingerprint'];same_hash_seen=fp in seen;seen.add(fp)
        record=next((d for d in snap['decisions']if d['kind']=='record_begin'),None)
        if record is None:continue
        matching=[r for r in mtp_rows if r['role']==slot_role[series['slot']]and r['role_prepare']==snap['prepare']]
        assert len(matching)==1
        row=matching[0]
        capture_records.append(dict(invocation_slot=series['slot'],native_role=series['role'],range_begin=series['begin'],
            own_prepare=snap['prepare'],logical_call=row['call'],turn=row['turn'],role=row['role'],
            role_name=row['role_name'],phase_prior_uses=row['prior_uses'],seed_valid=record['seed_valid'],
            fingerprint_seen_before_in_same_range=same_hash_seen,current_fingerprint=fp,
            plan_skeleton_fingerprint=snap['plan_skeleton_fingerprint']))
reset_next=[r for r in capture_records if r['invocation_slot']==1 and r['own_prepare']==7]
assert len(reset_next)==2
detail_record_count=len(capture_records);whole=sum(s['totals']['recorded']for s in capture['slot_aggregates'])
unknown=whole-detail_record_count
assert whole==32 and unknown==10
result=dict(status='existing_data_join_complete',scope='No new model,compilation,trace,HTTP orcandidate. Existing timer andcapture are separateprocesses, joined only by proven identical non-time journey androle occurrence.',
    sources=dict(timer_source=pin(C/'main2.cc'),capture_summary=pin(N/'summary2.json'),capture_stderr=pin(N/'run2/stderr.log'),capture_source_patch=pin(N/'source2.patch'),
        published_capture=pin(R/'docs/evidence/performance/mtp-capture-binding-diagnostics-2026-10-25.json')),
    arms=arms,cross_process_non_time_all_fields_equal=True,
    meanings=dict(generation='Boolean prompt/prefill vs generation; not native plan generation/version.',
        timer_slot='Phase carrier slot0. Distinct from CAPDIAG Invocation registration slot0..3.',
        input_rows='Generation request contains only pending1; actual classic verifier query_rows2 is separately recorded from original batch.',
        nonfirst='prior_uses>0 proves phase already used; it does not prove current bindingvariant or native executable was seen before.'),
    capture=dict(role_mapping=slot_role,whole_range_decisions=132,whole_recorded_ranges=32,whole_hits=100,
        detailed_recorded_ranges=detail_record_count,detailed_nonfirst_recorded_ranges=sum(r['phase_prior_uses']>0 for r in capture_records),
        detailed_records=capture_records,records_without_key_detail=unknown,
        detail_limit='Only first20prepares perInvocation. All8role3prepares covered,role4prepare21..58 notkey-detailed. Its later10recordings are not assigned a nativecause.',
        explicit_hard_resets=hard,reset_linked_next_records=reset_next,
        reset_bracket='Invocation1(role3) ownprepare6 completed with retainedhits; outsideprepare steps39/255 invalidate with recycle=false anddiscardkeys. Next ownprepare7=logicalcall37/turn2 firstdecode/prioruses6 records bothranges. Logicalcall36 is the intervening155-row catchup-prefill; exact adapter caller and reset placement withinthat call are notcaptured.',
        exact_adapter_caller=None,actual_native_plan_change=None,actual_native_update_result=None),
    lower_bound=dict(nonfirst_phase_use_recorded_ranges=arms['mtp-two-turn']['nonfirst_phase_use_recorded_ranges'],
        explicit_reset_linked_next_records=2,unexplained_due_late_detail_limit=10,
        description='Extra record is not merely first phase use. Two nextrecords directly follow known hard reset; other recorded binding tuples/firstvariant fills remain distinct. No assertion that all repeated hashes are exact equal or reset redundant.'),
    missing=['Timer row has no native_plan identity/version or perrange graph/executablehandle. Cannot distinguish a nativeplan replacement from key invalidation solely using phase_prior_uses.',
        'No ordinarynative detailedcaptureprocess exists in this batch; its5 nonfirstrecordings cannot be assigned the same MTPresetcause.',
        'Capture first20coverage omits role4 turn2 detailedreasons; native Update result is not inthese timer/capture logs.',
        'These are separateinstrumentedprocesses; timestamps,pointers andnativeplan identities cannot be crossjoined. Native API profile results belong to another process.'],
    conclusion='Existing data already proves nonfirst recordings and one known turn-boundary hard-reset bracket. Finer attribution of remaining Instantiate origins requires facts notrecorded here (actual native_plan/version andinvalidateadapter boundary); no new experiment is performed or performance saving claimed.')
(D/'result.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(status=result['status'],groups={k:v['turn_role_groups']for k,v in arms.items()},
    recorded={k:(v['total_recorded_ranges'],v['nonfirst_phase_use_recorded_ranges'])for k,v in arms.items()},
    known_reset_records=len(reset_next),late_unknown=unknown),indent=2))
