# 原生计划拒绝诊断（执行前冻结）

只在私有 overlay 编译 `flashinfer_provider.cc` 一个host TU，替换 clean c343 链接闭包中的对应一个OBJ。原成功host recipe及source SHA与当前canonical完全一致；不引入provider版本变化。

- 原 `can_reuse_batch_plan` 函数仅私有改名，函数体保留逐字原文；原名wrapper先调用原函数并保留原返回值，然后只读归因。去插入、逆改名必须恢复完整原源码。
- 固定64个slot、4096个POD events；每slot前20次query详细记录，全部后续reason／plan／update计数继续。每个layout最多8请求的query/KV indptr及tail，超出显式标记截断。
- query入口记录allow_update、旧／新layout generation与实际host数组、旧query rows/chunk/CTA/split/workspace；wrapper区分query内部和update调用，首拒绝原因按原顺序列no_generation、foreign_schema、query_shape、MLA_KV_tail、chunk_invalid、chunk_count、unknown。allow_update=false单列forced_fresh，不冒充predicate拒绝。
- 原native query／plan成功后直接读取现成facts（chunk、CTA、split、workspace），不新增native调用；只在atexit输出，不热打印、不持layout／lease／owner、不GPU readback、不修改控制分支。
- 至多一次原MTP两轮进程，原argv/runtime/weights/schedule；和clean基线原raw报告比较所有非时间字段。无profile、SDK、下载或其它候选。
- 本批时长不是TPS证据。未触发路径、metadata截断、记录溢出、原生失败均显式记录，不从源码可能性推断真实原因。

canonical provider SHA：`7f7d4d036c187fd206955a61f9e9f7a7873d2ab56f4eb8ee6e5476f44f9674e7`；原OBJ SHA：`4d69d0689714294b5c21dee97d1e9ca91ba6455bf0782b1ba26341a264d1660a`。
原成功recipe：`.scratch/glm-quark-selected-20261024/Q30/graph-integration-preparation/host-commands.json` 中 `compute_provider_flashinfer--flashinfer_provider`。
原clean image SHA：`c343db76232c4b5bd34878820433057b8c23789cd1b170b6a3b86cd91bf82fa1`。

## 实际执行结果

首次准备在编译前因 cached TU 的依赖 pin 不同而停止，原失败保留于 `prepare-dependency-firstfailure.json`。逐个核52个项目依赖后，使用原 compiled-source-snapshot 的3个完整旧头做私有include覆盖；原canonical和SDK未修改，未反复试编。

一次 provider TU 严格编译 exit0（2.172s），一次原闭包链接 exit0（1.688s）；唯一原MTP两轮进程 exit0（3.843s），无超时、无重跑，GPU已释放。全部非时间raw报告字段与clean基线相同。实际详细1014events，slot/event溢出、metadata截断、并发跳过及原因不一致均0。

结果和边界见 `analysis.md` / `summary.json`；原始逐slot前20query与全程计数见 `native-slot-sequences.json` / `run/stderr.log`。不依据本次插桩时长作TPS或可回收收益结论。清理仅列候选，未执行。
