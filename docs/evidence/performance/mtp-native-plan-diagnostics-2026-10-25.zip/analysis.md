# 原生计划复用拒绝：一次真实两轮诊断

唯一进程成功；raw非时间报告全同clean c343基线。26个native slots、474次query；427次reuse/update成功、47次fresh plan成功。47次包含26次首次`allow_update=false`，另21次全部被原predicate以`chunk_count`拒绝。

| 实际slots | 次数/slot | native query indptr | 归属边界 |
| --- | ---: | --- | --- |
| 0–5 | 1 | [0,154] | 首轮prefill |
| 6 | 8 | [0,1] | MtpRound draft |
| 7–12 | 8 | [0,2] | MtpRound六target attention |
| 13 | 58 | [0,2] | MtpCatchupRound draft |
| 14–19 | 58 | [0,2] | MtpCatchupRound六target attention |
| 20–25 | 1 | [0,155] | 次轮catchup-prefill |

role由原报告8/58次及同顺序对应；target/draft与原冷图发射顺序和实际1/2行、KV长度相符，未直接插入模型layer ID。

明确的第二轮首decode（全局call37）：8-query组第7次均拒绝。draft KV202→373、target KV203→374；query indptr各自不变，KV page indptr均[0,13]→[0,24]。原chunk128行、page16行，故ceil(13/8)=2→ceil(24/8)=3。成功新plan的padded2→3、float workspace263168→394752B、int82→83B；CTA16、chunk128、split=true保持。此次是实际分块/工作区计划变化，不能当作无理由的地址失效。

58-query组每slot另外各2次chunk_count拒绝，但在首20次详细记录之外；全程14次计数可靠，具体query序号、布局及新plan facts没有记录，保持未知。没有补跑。

全程未发生foreign_schema、query_shape、no_generation、chunk_invalid或MLA_KV_tail predicate拒绝；初次forced-fresh不是predicate失败。详细记录无溢出/截断/并发跳过，原predicate返回值与只读归因逐次一致。

call37的Graph旧key清除来自上一独立进程的capture证据；本次有同一非时间旅程和role occurrence可逻辑对应，但没有Graph失效调用栈或step ID，不能证明具体上层调用地址。未观测page-ID内容/native kernel拓扑/GraphExecUpdate结果，未计native时间，不能把重新计划次数直接换算成可回收时长，也不支持跳过chunk正确性保护。

源码仅私有一TU插桩；去插入并逆向私有函数改名恢复canonical逐字原文。首次依赖pin失败及3头完整旧快照修正保留。clean c343映像未变，无产品修改、SDK构建、HTTP或GPU profile。
