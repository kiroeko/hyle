from pathlib import Path
import hashlib,json,zipfile
S=Path(__file__).resolve().parent; R=S.parents[1]
J=R/'.scratch/mtp-performance-convergence-20261025/early-record-join'
P=R/'docs/evidence/performance/mtp-native-plan-diagnostics-2026-10-25.json'; Z=P.with_suffix('.zip')
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def pin(p):return dict(path=p.relative_to(R).as_posix(),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
assert not P.exists()and not Z.exists()
data=read(S/'summary.json'); cleanup=read(S/'cleanup-candidates.json')
assert data['non_time_report_equal']and data['aggregate']['queries']==474
assert data['aggregate']['query_predicate_reasons']['chunk_count']==21
with zipfile.ZipFile(Z,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9)as out:
    with zipfile.ZipFile(S/'proof.zip')as source:
        assert source.testzip()is None
        for member in source.namelist():out.writestr(member,source.read(member))
    for p in (J/'analyze.py',J/'result.json'):out.write(p,'early-record-join/'+p.name)
    out.write(Path(__file__),'publish.py')
data.update(archive=pin(Z),original_private_archive=pin(S/'proof.zip'),
    related=dict(original_baseline='docs/evidence/performance/mtp-current-single-and-multiturn-2026-10-25.json',
                 prior_capture='docs/evidence/performance/mtp-capture-binding-diagnostics-2026-10-25.json',
                 earlier_api_and_body='docs/evidence/performance/mtp-body-route-attribution-2026-10-25.json',
                 offline_logical_join=pin(J/'result.json')),
    cleanup=dict(performed=False,files=[dict(path=x['relative_repository_path'],bytes=x['bytes'],sha256=x['sha256'])for x in cleanup['files']],logical_bytes=cleanup['logical_bytes'],note=cleanup['hardlink_note']),
    decision='Retain original chunk-count and resource invalidation gates. This evidence supports checking existing fixed-split scheduling as a separate private candidate; no throughput gain or product change is claimed.')
P.write_text(json.dumps(data,indent=2,ensure_ascii=False)+'\n',encoding='utf8')
print(json.dumps(dict(public=pin(P),archive=pin(Z))))
