"""Root-only two host-TU diagnostic rebuild; no SDK/NVCC/shaders."""
from pathlib import Path
import argparse,importlib.util,os,sys
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent;R=S.parents[1];AS=R/'.scratch/qwen-capture-reuse-20261022'
sp=importlib.util.spec_from_file_location('at_cached',AS/'build.py')
m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m);b,c,h=m.b,m.c,m.h;h.S=S
tags={'graph-cost':(m.recipe('executable'),S/'diagnostic/executable.cc'),
      'main-tuple':(R/'.scratch/qwen-mtp-quality-20261022/compile1/hyle/identity.json',AS/'probe/tools/qwen35_text/main.cc')}
p=argparse.ArgumentParser();p.add_argument('--attempt',type=int,default=1);attempt=p.parse_args().attempt
(S/'recipes').mkdir(exist_ok=True)
for tag,(recipe,source)in tags.items():
    if attempt!=1 and tag=='main-tuple':continue
    value=c.read(recipe);value['command']+=['/I'+str(R/'tools/qwen35_text')]
    path=S/'recipes'/f'{tag}.json';c.save(path,value)
    h.RECIPES[tag]=path;h.SOURCES[tag]=source;h.compile_one(tag,attempt)
base_dir=AS/'hyle-link2';base=c.read(base_dir/'link-plan.json')
replacement={c.key(c.read(AS/'compile1/executable/identity.json')['object']['path']):c.read(S/f'compile{attempt}/graph-cost/identity.json')['object'],
 c.key(c.read(R/'.scratch/qwen-mtp-quality-20261022/compile1/hyle/identity.json')['object']['path']):c.read(S/'compile1/main-tuple/identity.json')['object']}
inputs=[replacement.get(c.key(x['path']),x)for x in base['inputs']]
assert all(b.identity(x['path'])==x for x in inputs)
command=[replacement.get(c.key(x),{}).get('path',x)for x in base['command']if not x.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:'))]
out=S/f'diagnostic-link{attempt}';out.mkdir();(out/'tmp').mkdir();image=out/'qwen.exe'
command+=['/OUT:'+str(image),'/MAP:'+str(image.with_suffix('.map')),'/IMPLIB:'+str(image.with_suffix('.lib'))]
c.save(out/'link-plan.json',dict(command=command,inputs=inputs,diagnostic_only=True,SDK_builds=0,NVCC=0,shaders=0))
env,_=b.environment(command,[x['path']for x in inputs],out);c.execute('link',command,env,out)
runtime=c.read(base_dir/'runtime-environment.json')
for x in runtime['staged_dlls']:os.link(x['path'],out/Path(x['path']).name)
c.save(out/'runtime-environment.json',runtime);c.save(out/'ready.json',dict(image=b.identity(image)))
print('LINKED diagnostic',flush=True)
