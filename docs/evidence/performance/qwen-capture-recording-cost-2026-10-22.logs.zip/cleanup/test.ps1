$ErrorActionPreference = 'Stop'
$taskPrefix = 'C:\public\project-hyle\hyle\.scratch\qwen-capture-cost-20261022\'
$taskFiles = @(
  @{ Path = 'C:\public\project-hyle\hyle\.scratch\qwen-capture-cost-20261022\diagnostic-link1\qwen.exe'; Bytes = 140402176; Sha256 = '320bcfc719c8c14e3cfed53380b46156a4d7b5a3694ac97ac1de43aa8f2b4a26' }
  @{ Path = 'C:\public\project-hyle\hyle\.scratch\qwen-capture-cost-20261022\diagnostic-link2\qwen.exe'; Bytes = 140403712; Sha256 = '5895edab718cc0c3c440e004da807ca2505cc95a1e5f00af9eb7f9d2b45111cb' }
  @{ Path = 'C:\public\project-hyle\hyle\.scratch\qwen-capture-cost-20261022\diagnostic-link3\qwen.exe'; Bytes = 140403712; Sha256 = '17c34a0590a96338ae64b8694d4c6233e2864a68f2545c5e22c7c64ec4c32f2a' }
)
foreach ($taskFile in $taskFiles) {
  $taskResolved = (Resolve-Path -LiteralPath $taskFile.Path).Path
  if (-not $taskResolved.StartsWith($taskPrefix, [StringComparison]::OrdinalIgnoreCase)) { throw 'Cleanup outside exact AT workspace' }
  $taskInfo = Get-Item -LiteralPath $taskResolved
  if ($taskInfo.PSIsContainer -or $taskInfo.Length -ne $taskFile.Bytes) { throw 'Cleanup target changed' }
  if ((Get-FileHash -LiteralPath $taskResolved -Algorithm SHA256).Hash -ne $taskFile.Sha256) { throw 'Cleanup hash changed' }
}
$taskRemoved = @()
foreach ($taskFile in $taskFiles) {
  Remove-Item -LiteralPath $taskFile.Path -Force
  $taskRemoved += $taskFile
}
[PSCustomObject]@{ Removed = $taskRemoved; Bytes = ($taskRemoved | Measure-Object -Property Bytes -Sum).Sum } | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath 'C:\public\project-hyle\hyle\.scratch\qwen-capture-cost-20261022\cleanup-result.json' -Encoding utf8
