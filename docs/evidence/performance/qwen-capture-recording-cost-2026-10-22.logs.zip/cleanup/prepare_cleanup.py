"""Write the exact three disposable diagnostic images to root test.ps1."""
from pathlib import Path
import hashlib,json
S=Path(__file__).resolve().parent;R=S.parents[1]
rows=[]
for i in [1,2,3]:
    p=(S/f'diagnostic-link{i}/qwen.exe').resolve();assert p.is_relative_to(S)
    rows.append(dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()))
lines=["$ErrorActionPreference = 'Stop'",f"$taskPrefix = '{S}\\'",'$taskFiles = @(']
for x in rows:lines.append("  @{ Path = '"+x['path']+"'; Bytes = "+str(x['bytes'])+"; Sha256 = '"+x['sha256']+"' }")
lines += [')','foreach ($taskFile in $taskFiles) {',
 '  $taskResolved = (Resolve-Path -LiteralPath $taskFile.Path).Path',
 "  if (-not $taskResolved.StartsWith($taskPrefix, [StringComparison]::OrdinalIgnoreCase)) { throw 'Cleanup outside exact AT workspace' }",
 '  $taskInfo = Get-Item -LiteralPath $taskResolved',
 "  if ($taskInfo.PSIsContainer -or $taskInfo.Length -ne $taskFile.Bytes) { throw 'Cleanup target changed' }",
 "  if ((Get-FileHash -LiteralPath $taskResolved -Algorithm SHA256).Hash -ne $taskFile.Sha256) { throw 'Cleanup hash changed' }",'}',
 '$taskRemoved = @()','foreach ($taskFile in $taskFiles) {','  Remove-Item -LiteralPath $taskFile.Path -Force',
 '  $taskRemoved += $taskFile','}',
 "[PSCustomObject]@{ Removed = $taskRemoved; Bytes = ($taskRemoved | Measure-Object -Property Bytes -Sum).Sum } | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath '"+str(S/'cleanup-result.json')+"' -Encoding utf8"]
(R/'test.ps1').write_text('\n'.join(lines)+'\n',encoding='utf-8')
(S/'cleanup-plan.json').write_text(json.dumps(dict(files=rows,script_sha256=hashlib.sha256((R/'test.ps1').read_bytes()).hexdigest(),
    retained=['AS/hyle-link2/qwen.exe current uninstrumented product image','Diagnostic source, objects, commands and compact evidence']),indent=2)+'\n',encoding='utf-8')
print('PREPARED',sum(x['bytes']for x in rows),'bytes from3 exact files')
