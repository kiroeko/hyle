"""Append exact cleanup and audit frozen evidence; no new runtime experiment."""
from pathlib import Path
import hashlib,json,zipfile
S=Path(__file__).resolve().parent;R=S.parents[1]
out=R/'docs/evidence/performance/qwen-capture-recording-cost-2026-10-22.json';archive=out.with_suffix('.logs.zip')
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def ident(p):return dict(path=str(p.relative_to(R)),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
cleanup=read(S/'cleanup-result.json');assert cleanup['Bytes']==421209600
assert all(not Path(x['Path']).exists()for x in cleanup['Removed'])
previous=read(R/'docs/evidence/performance/qwen-capture-rebuild-2026-10-22.json')
assert all(ident(R/x['path'])==x for x in previous['product_changes'])
with zipfile.ZipFile(archive,'a',compression=zipfile.ZIP_DEFLATED,compresslevel=9)as z:
    for p in [R/'test.ps1',S/'cleanup-plan.json',S/'cleanup-result.json',S/'prepare_cleanup.py',Path(__file__)]:z.write(p,'cleanup/'+p.name)
with zipfile.ZipFile(archive)as z:assert z.testzip()is None
record=read(out);record['cleanup']=dict(bytes_removed=cleanup['Bytes'],disposable_images=cleanup['Removed'])
record['archived_logs']=ident(archive);out.write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
receipt=dict(evidence=ident(out),logs=ident(archive),product_sources_unchanged=True,goal_complete=False,
    current_image=ident(R/'.scratch/qwen-capture-reuse-20261022/hyle-link2/qwen.exe'))
(S/'final-receipt.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print('FINAL AUDIT',receipt['evidence'],receipt['logs'])
