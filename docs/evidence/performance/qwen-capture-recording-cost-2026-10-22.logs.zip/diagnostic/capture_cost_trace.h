#pragma once
#include <chrono>
#include <cstdint>
#include <cstdio>
namespace capture_cost_diag {
using Clock=std::chrono::steady_clock;
struct Trace final {
  const void* invocation;
  int mode;
  Clock::time_point begin=Clock::now();
  std::uint64_t phase[6]{};
  template<class F> auto measure(unsigned index,F&& fn) noexcept {
    const auto start=Clock::now();
    auto result=fn();
    phase[index]+=static_cast<std::uint64_t>(std::chrono::duration_cast<std::chrono::nanoseconds>(Clock::now()-start).count());
    return result;
  }
  ~Trace(){
    const auto total=static_cast<unsigned long long>(std::chrono::duration_cast<std::chrono::nanoseconds>(Clock::now()-begin).count());
    std::fprintf(stderr,"hyle.capture_cost invocation=%p mode=%d total=%llu bindings=%llu sources=%llu begin=%llu record=%llu end=%llu finish=%llu\n",invocation,mode,total,
      static_cast<unsigned long long>(phase[0]),static_cast<unsigned long long>(phase[1]),
      static_cast<unsigned long long>(phase[2]),static_cast<unsigned long long>(phase[3]),
      static_cast<unsigned long long>(phase[4]),static_cast<unsigned long long>(phase[5]));
  }
};
}
