"""Publish finite phase diagnosis and resource-stability audit; no native run."""
from pathlib import Path
import hashlib,json,re,collections,zipfile
S=Path(__file__).resolve().parent;R=S.parents[1]
OUT=R/'docs/evidence/performance/qwen-capture-recording-cost-2026-10-22.json';ZIP=OUT.with_suffix('.logs.zip')
def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def ident(p):
    p=Path(p).resolve();raw=p.read_bytes()
    return dict(path=str(p.relative_to(R)),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
assert not OUT.exists()and not ZIP.exists()
previous=read(R/'docs/evidence/performance/qwen-capture-rebuild-2026-10-22.json')
assert all(ident(R/x['path'])==x for x in previous['product_changes'])
observations=[read(S/f'phase-probe{i}/summary.json')for i in [1,2,3]]
assert sum(len(x['records'])for x in observations)==4
for experiment in observations:
    for x in experiment['records']:
        assert x['IDs_equal_current']and x['phases']['decode']['calls']==63
        assert x['caller_tuples']['distinct_logged_state_tuples']==2
        assert set(x['caller_tuples']['port_counts'])=={72}
        assert x['caller_tuples']['sequence']==[i%2 for i in range(63)]
first=observations[0]['records'][0]['phases']['decode']['intervals_ns']
assert first['record']['total']/first['total']['total']>.75
log=(S/'phase-probe3/auto/stderr.log').read_text()
providers={}
for ptr,region,name in re.findall(r'hyle.capture_provider invocation=(\w+) step=\d+ region=(\d) provider=([^\r\n]*)',log):
    key=ptr;providers.setdefault(key,collections.Counter())[(region,name or '<unnamed-native>')]+=1
provider_rows=[dict(invocation=k,commands=[dict(region=region=='1',provider=name,count=n)for(region,name),n in v.items()])for k,v in providers.items()]
compiled=[]
for i in [1,2,3]:
    record=read(S/f'compile{i}/graph-cost/identity.json')
    snapshot=S/f'compile{i}/graph-cost/source'/Path(record['source']['path']).relative_to(R)
    assert ident(snapshot)['sha256']==record['source']['sha256']
    compiled.append(dict(record=ident(S/f'compile{i}/graph-cost/identity.json'),actual_frozen_source=ident(snapshot),
        image=read(S/f'diagnostic-link{i}/ready.json')['image']))
reviews=[p for p in (S/'review').glob('*.json')]
required={'operation-private-stability.json','region-private-stability.json'}
assert required.issubset({p.name for p in reviews}), 'Wait for finite implementation resource audits'
selected=[]
for folder in ['diagnostic','review','phase-probe1','phase-probe2','phase-probe3','recipes']:
    selected += [p for p in (S/folder).rglob('*')if p.is_file()and p.suffix in ['.json','.py','.cc','.h','.diff','.log']]
for folder in [*S.glob('compile*'),*S.glob('diagnostic-link*')]:
    if not folder.is_dir():continue
    selected += [p for p in folder.rglob('*')if p.is_file()and p.suffix in ['.json','.cc','.h','.log']and 'tmp'not in p.parts]
selected += list(S.glob('*.py'))+[S/'variant-design.json']
with zipfile.ZipFile(ZIP,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9)as z:
    for p in sorted(set(selected)):z.write(p,p.relative_to(S).as_posix())
    retained=R/'.scratch/qwen-capture-reuse-20261022'
    for p in [retained/'probe/caller_tuple_probe.h',retained/'main-probe.diff',retained/'main-probe.json',retained/'prepare_probe_source.py']:
        z.write(p,'retained-tuple-probe/'+p.name)
record=dict(status='RECORDING_COST_IDENTIFIED_NO_NEW_PRODUCT_PERFORMANCE_RESULT',date='2026-10-22',
    conclusion='The remaining repeated-capture cost is dominated by encoding a fresh recording, not re-instantiating the native graph or rebuilding the GGML graph. Logged state ports alternate between two tuples; a bounded exact full-binding capture variant mechanism needs explicit private-resource stability facts.',
    measurements=observations,capture_provider_commands=provider_rows,compiled_diagnostics=compiled,
    recorded_fraction_of_prepare_wall=first['record']['total']/first['total']['total'],
    product_sources_unchanged=True,product_source_identity_reference=ident(R/'docs/evidence/performance/qwen-capture-rebuild-2026-10-22.json'),
    full_performance_result_unchanged=dict(hyle_plain_decode=80.26226139813292,hyle_MTP_decode=103.84204010379588),
    source_reviews=[dict(source=ident(p),review=read(p))for p in reviews],proposed_design=read(S/'variant-design.json'),
    scope=dict(diagnostic_model_processes=4,host_translation_unit_compiles=4,SDK_builds=0,NVCC_builds=0,shader_builds=0,new_full_TPS_windows=0,new_memory_windows=0),
    limits=['Diagnostic intervals are host wall brackets that can include SDK waits. They are not CPU self-time and do not establish exclusive causal accounting of all decode time.',
        'Three auto diagnostic processes have different added metadata logging and background conditions. Their durations are not a new formal performance window or a basis for extrapolated tokens/s.',
        '72 logged state port identities include dimensions/strides/dtype/resource/handle/offset/span; they do not cover all private capture arguments or prove future MTP shapes have exactly two variants.',
        'The source audits describe exact currently reviewed implementations. A provider family name, capture-compatible flag or no-prepare callback alone does not prove cross-record private stability.',
        'Capture variants and their capability contracts are proposed and not implemented in this batch; current default execution, precision and resource lifetime are unchanged.'],
    archived_logs=ident(ZIP))
OUT.write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
doc=R/'docs/developer/current-work.md';text=doc.read_text(encoding='utf-8')
old='下一步继续量化每步捕获、Provider绑定准备和状态地址轮换的成本；本批不恢复Model双Invocation、不放宽身份或退休门、不改变默认replay与精度。普通路径与MTP增量分开判断，不能把共用回退都算作MTP问题。'
new='''**[后续诊断已定位剩余捕获成本](../evidence/performance/qwen-capture-recording-cost-2026-10-22.json)。** 普通63步的prepare wall总113.41ms，中位1.7801ms；其中新record总86.17ms（75.98%）、中位1.3629ms，bindings中位0.1677ms，end/update中位0.2202ms，finish中位0.0138ms。另一次相同阶段诊断接近，增加Provider清单日志的第三次更快；它们均为带日志诊断，不是新TPS或CPU self-time。72份caller状态端口的完整物理tuple实际只有两组交替；这不是全capture key或私有资源稳定证明。当前T1捕获含GGML／cuBLASLt／CCCL／original artifacts／FlashInfer／分页写入，资格需按实际prepared实现核，不能按provider名或无prepare hook推断。

下一步实现同一Invocation内有界的完整参数捕获变体，保留全部当前绑定、权限、alias与seal检查，只在实际后端身份和每个实现的私有资源稳定资格成立时复用；配置／native／Queue／Commands变化先清覆盖变体。更改尚未实施，当前正式TPS仍为80.26／103.84；实现后再跑普通基线与MTP增量四臂及独立内存对照。'''
assert text.count(old)==1;text=text.replace(old,new);doc.write_text(text,encoding='utf-8',newline='\n')
doc=R/'docs/developer/performance/decode.md';text=doc.read_text(encoding='utf-8')
old='下一步先量化每步新capture、Provider绑定准备与状态地址轮换的实际成本，按普通基线和MTP增量分别归因；之后再回到普通小行数投影的冷算法选择。'
new='''[每步诊断已完成](../../evidence/performance/qwen-capture-recording-cost-2026-10-22.json)：63步prepare总113.41ms，其中新record86.17ms，占75.98%；中位prepare／record／bindings／end分别1.7801／1.3629／0.1677／0.2202ms。GGML未每步重建原生图或重分workspace，重复record是本批优先项。72份caller状态端口仅两组物理tuple交替，但全参数和私有资源另核；不能据此宣称完整capture可直接复用。带日志的4进程只作归因，正式TPS表保持不变。

下一步实现Invocation局部有界capture变体：沿实际prepared能力检查私有资源稳定，保完整物理参数、实际Queue／配置失效与真实退休；仍走现绑定／权限／seal，只省重复record。未具资格者保原update／fresh capture，Commands及native重配先清全部覆盖变体。实现后核普通与MTP完整四项，不从诊断区间推算TPS；之后再回到普通小行数投影的冷算法选择。'''
assert text.count(old)==1;text=text.replace(old,new);doc.write_text(text,encoding='utf-8',newline='\n')
(S/'publication-receipt.json').write_text(json.dumps(dict(evidence=ident(OUT),logs=ident(ZIP),goal_complete=False),indent=2)+'\n',encoding='utf-8')
print('PUBLISHED',ident(OUT),ident(ZIP))
