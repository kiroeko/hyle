"""Generate a coarse, logging-only prepare_replay phase diagnostic TU."""
from pathlib import Path
import hashlib,json,difflib
S=Path(__file__).resolve().parent;R=S.parents[1];D=S/'diagnostic';D.mkdir(exist_ok=True)
source=R/'src/graph/executable.cc';before=source.read_text(encoding='utf-8')
header='''#pragma once
#include <chrono>
#include <cstdint>
#include <cstdio>
namespace capture_cost_diag {
using Clock=std::chrono::steady_clock;
struct Trace final {
  const void* invocation;
  int mode;
  Clock::time_point begin=Clock::now();
  std::uint64_t phase[6]{};
  template<class F> auto measure(unsigned index,F&& fn) noexcept {
    const auto start=Clock::now();
    auto result=fn();
    phase[index]+=static_cast<std::uint64_t>(std::chrono::duration_cast<std::chrono::nanoseconds>(Clock::now()-start).count());
    return result;
  }
  ~Trace(){
    const auto total=static_cast<unsigned long long>(std::chrono::duration_cast<std::chrono::nanoseconds>(Clock::now()-begin).count());
    std::fprintf(stderr,"hyle.capture_cost invocation=%p mode=%d total=%llu bindings=%llu sources=%llu begin=%llu record=%llu end=%llu finish=%llu\\n",invocation,mode,total,
      static_cast<unsigned long long>(phase[0]),static_cast<unsigned long long>(phase[1]),
      static_cast<unsigned long long>(phase[2]),static_cast<unsigned long long>(phase[3]),
      static_cast<unsigned long long>(phase[4]),static_cast<unsigned long long>(phase[5]));
  }
};
}
'''
(D/'capture_cost_trace.h').write_text(header,encoding='utf-8')
start=before.index('Status Invocation::prepare_replay(');end=before.index('\nReplayRoute Invocation::replay_route()',start)
fn=before[start:end]
changes={
  '                                  ReplayOptions options) noexcept {':
  '''                                  ReplayOptions options) noexcept {
  capture_cost_diag::Trace diagnostic{state_,static_cast<int>(options.mode)};
  if (state_ && state_->capture_rebuilds.empty()) {
    std::size_t regions=0,borrowed=0,operations=0,other=0;
    for (const auto &range:state_->plan->capture_ranges)
      for (std::size_t i=range.step_begin;i<std::size_t{range.step_begin}+range.step_count;++i) {
        const auto &step=state_->plan->steps[i];
        if (!step.emits_command())continue;
        const auto identity=step.provider();
        std::fprintf(stderr,"hyle.capture_provider invocation=%p step=%zu region=%u provider=%.*s\\n",static_cast<void*>(state_),i,step.region.valid()?1u:0u,static_cast<int>(identity.name.size()),identity.name.data());
        if(step.region.valid()) { ++regions;borrowed+=detail::RegionAccess::borrows_tensor_views_only(step.region); }
        else if(step.kind==detail::PlanStepKind::kOperation)++operations;
        else ++other;
      }
    std::fprintf(stderr,"hyle.capture_kinds invocation=%p regions=%zu borrowed=%zu operations=%zu other=%zu\\n",static_cast<void*>(state_),regions,borrowed,operations,other);
  }''',
  'Status bindings = prepare_invocation_bindings(*state_);':
  'Status bindings = diagnostic.measure(0,[&]() noexcept { return prepare_invocation_bindings(*state_); });',
  'detail::prepare_input_sources(*state_, queues, options.host_wait)':
  'diagnostic.measure(1,[&]() noexcept { return detail::prepare_input_sources(*state_, queues, options.host_wait); })',
  'Status begun = compute::detail::CommandCaptureAccess::begin(*extension, *sequence);':
  'Status begun = diagnostic.measure(2,[&]() noexcept { return compute::detail::CommandCaptureAccess::begin(*extension, *sequence); });',
  'Status recorded = enqueue_segment_steps(*state_, range, *sequence);':
  'Status recorded = diagnostic.measure(3,[&]() noexcept { return enqueue_segment_steps(*state_, range, *sequence); });',
  'auto captured = compute::detail::CommandCaptureAccess::end(\n        *extension, *sequence, state_->allocator, std::move(rebuild));':
  'auto captured = diagnostic.measure(4,[&]() noexcept { return compute::detail::CommandCaptureAccess::end(\n        *extension, *sequence, state_->allocator, std::move(rebuild)); });',
  'Status finished = finish_preparation(*sequence);':
  'Status finished = diagnostic.measure(5,[&]() noexcept { return finish_preparation(*sequence); });',
}
for a,b in changes.items():
    expected=2 if a=='Status finished = finish_preparation(*sequence);' else 1
    assert fn.count(a)==expected,(a,fn.count(a));fn=fn.replace(a,b)
after='#include "capture_cost_trace.h"\n'+before[:start]+fn+before[end:]
(D/'executable.cc').write_text(after,encoding='utf-8')
(D/'implementation.diff').write_text(''.join(difflib.unified_diff(before.splitlines(keepends=True),after.splitlines(keepends=True),fromfile='product',tofile='diagnostic')),encoding='utf-8')
def ident(p):return dict(path=str(p.relative_to(R)),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
(D/'source-freeze.json').write_text(json.dumps(dict(base=ident(source),generated=[ident(D/x)for x in ['executable.cc','capture_cost_trace.h','implementation.diff']],
    scope='Logging-only phase wall intervals; not CPU self-time, not throughput/memory evidence; no new native calls or mathematical changes.'),indent=2)+'\n',encoding='utf-8')
print('PREPARED diagnostic')
