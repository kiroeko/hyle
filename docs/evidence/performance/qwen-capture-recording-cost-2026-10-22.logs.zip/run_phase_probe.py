"""Root-only one plain auto/commands diagnostic each; no TPS acceptance."""
from pathlib import Path
import argparse,importlib.util,os,json,re,statistics,hashlib,sys
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent;R=S.parents[1];AS=R/'.scratch/qwen-capture-reuse-20261022'
sp=importlib.util.spec_from_file_location('at_phase_run',R/'.scratch/qwen-mtp-quality-20261022/run_quality.py')
h=importlib.util.module_from_spec(sp);sp.loader.exec_module(h)
p=argparse.ArgumentParser();p.add_argument('--attempt',type=int,default=1);p.add_argument('--only-auto',action='store_true');args=p.parse_args()
image=h.read(S/f'diagnostic-link{args.attempt}/ready.json')['image'];assert h.ident(image['path'])==image
env=os.environ.copy();env['PATH']=h.read(S/f'diagnostic-link{args.attempt}/runtime-environment.json')['PATH']
reference=next(x for x in h.read(AS/'current-window/timing/runs.json')if x['arm']=='hyle_plain')['observation']['raw']
records=[]
for replay in (['auto']if args.only_auto else['auto','commands']):
    out=S/f'phase-probe{args.attempt}'/replay
    command=[image['path'],'--inputs',str(h.V/'inputs/text'),'--steps','64','--capacity','1024',
        '--max-sessions','1','--active-sequences','1','--prefix-cache','off','--progress','direct','--replay',replay,'--mtp','off']
    process=h.execute(command,env,out,timeout=120);assert process['exit']==0 and not process['timed_out'],process
    raw=json.loads((out/'stdout.log').read_text().strip().splitlines()[-1]);h.save(out/'parsed.json',raw)
    assert raw['generated_ids']==reference['generated_ids']
    log=(out/'stderr.log').read_text();phase='outside';phases=[];tuples={};context={}
    for line in log.splitlines():
        if 'memory_phase=generation_prefill_begin'in line:phase='prefill'
        elif 'memory_phase=generation_decode_begin'in line:phase='decode'
        elif 'memory_phase=generation_decode_end'in line:phase='outside'
        if line.startswith('hyle.capture_cost '):
            row=dict(re.findall(r'(\w+)=([^ ]+)',line));row={k:int(v)if k not in ['invocation']else v for k,v in row.items()};row['phase']=phase;phases.append(row)
        elif line.startswith('caller_tuple_begin '):
            row=dict(re.findall(r'(\w+)=([^ ]+)',line));context[int(row['call'])]=row
        elif line.startswith('caller_tuple '):
            row=dict(re.findall(r'(\w+)=([^ ]+)',line));call=int(row.pop('call'));row.pop('prior');row.pop('run');tuples.setdefault(call,[]).append(row)
    summary={}
    for p in ['prefill','decode']:
        rows=[x for x in phases if x['phase']==p]
        summary[p]=dict(calls=len(rows),intervals_ns={k:dict(total=sum(x[k]for x in rows),median=statistics.median(x[k]for x in rows),
            min=min(x[k]for x in rows),max=max(x[k]for x in rows))for k in ['total','bindings','sources','begin','record','end','finish']})
    signatures=[]
    for call in sorted(context):
        if context[call]['T']!='1':continue
        key=json.dumps(tuples[call],sort_keys=True,separators=(',',':'))
        signatures.append(dict(call=call,sha256=hashlib.sha256(key.encode()).hexdigest(),ports=len(tuples[call])))
    distinct=list(dict.fromkeys(x['sha256']for x in signatures))
    observed=dict(calls=len(signatures),distinct_logged_state_tuples=len(distinct),sequence=[distinct.index(x['sha256'])for x in signatures],
        port_counts=[x['ports']for x in signatures],scope='Caller state input/output descriptions/resource/handle/offset/span only; not full capture signature or proof private resources stay valid.')
    result=dict(replay=replay,image=image,process=process,IDs_equal_current=True,phases=summary,caller_tuples=observed,
        throughput_evidence=False,memory_evidence=False,limits=['Logging-only one process; wall intervals may contain native waits and are not CPU self-time.',
        'Intervals are disjoint coarse prepare_replay subphases. Unmeasured remainder includes dependency validation, metadata and scope cleanup.',
        'Caller tuple logging occurs before core phase clocks; it still perturbs the process. No throughput conclusion from this run.'])
    records.append(result);h.save(out/'summary.json',result)
    print('PHASE',replay,json.dumps(dict(phases=summary,tuple_counts={k:observed[k]for k in ['calls','distinct_logged_state_tuples']})),flush=True)
h.save(S/f'phase-probe{args.attempt}/summary.json',dict(records=records,product_changes=False))
