#pragma once
#include <cstdio>
#include <cstddef>

// Scratch-only scalar address evidence. No tensor/resource/lease owner escapes.
// These stderr logs make the run diagnostic, not a throughput measurement.
namespace hyle_caller_tuple_probe {
struct Context final {
  std::size_t call = 0, width = 0, tokens = 0, prior = 0;
  unsigned role = 0;
  const void *run = nullptr;
};
inline thread_local Context current;
inline void begin(unsigned role, std::size_t width, std::size_t tokens,
                  std::size_t prior, const void *run) noexcept {
  ++current.call; current.role = role; current.width = width;
  current.tokens = tokens; current.prior = prior; current.run = run;
  std::fprintf(stderr, "caller_tuple_begin call=%zu role=%u R=%zu T=%zu prior=%zu run=%p diagnostic_not_TPS=1\n",
      current.call, role, width, tokens, prior, const_cast<void *>(run));
}
template<class Tensor>
void record(const char *name, std::size_t member, std::size_t layer,
            unsigned port, const Tensor &tensor) noexcept {
  const auto storage = tensor.storage();
  const auto &description = tensor.description();
  const auto resource = storage.resource();
  std::fprintf(stderr, "caller_tuple call=%zu role=%u R=%zu T=%zu prior=%zu run=%p semantic=%s member=%zu layer=%zu port=%u resource=%p handle=%p offset=%zu bytes=%zu dtype=%u rank=%zu dims=",
      current.call, current.role, current.width, current.tokens, current.prior,
      const_cast<void *>(current.run), name, member, layer, port,
      resource.valid() ? static_cast<void *>(&resource.resource()) : nullptr,
      storage.native_handle(), storage.offset(), storage.size(),
      static_cast<unsigned>(description.data_type()), description.rank());
  for (std::size_t i = 0; i < description.rank(); ++i)
    std::fprintf(stderr, "%s%lld", i ? "," : "", static_cast<long long>(description.dimensions()[i]));
  std::fprintf(stderr, " strides=");
  for (std::size_t i = 0; i < description.rank(); ++i)
    std::fprintf(stderr, "%s%lld", i ? "," : "", static_cast<long long>(description.byte_strides()[i]));
  std::fprintf(stderr, "\n");
}
} // namespace hyle_caller_tuple_probe
