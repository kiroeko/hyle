"""Generate one scratch main TU with caller tuple logs; no build/native work."""
from pathlib import Path
import hashlib
import json
import difflib

STAGE = Path(__file__).resolve().parent
ROOT = STAGE.parents[1]


def identity(path):
    raw = path.read_bytes()
    return dict(path=str(path),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())


def main():
    source = ROOT/'tools/qwen35_text/main.cc'
    original = source.read_text()
    text = original
    def replace(before, after):
        nonlocal text
        assert text.count(before) == 1, before
        text = text.replace(before, after)
    replace('#include "backend.h"', '#include "backend.h"\n#include "../../caller_tuple_probe.h"')
    replace('      initialize_slot(phase, slot);\n      std::vector<std::int32_t> packed_ids, positions;',
            '      initialize_slot(phase, slot);\n'
            '      hyle_caller_tuple_probe::begin(static_cast<unsigned>(role), width, tokens, phase.preparation_uses[slot], &run);\n'
            '      std::vector<std::int32_t> packed_ids, positions;')
    for name, index in [('carry',0),('prior',1)]:
        anchor=f'      check(run.bind(ports[{index}], dense(Type::kBFloat16, {{1, hidden}}), member.base->{name}_hidden));'
        if index == 1:
            anchor = '  '+anchor
        indent = '        ' if index == 1 else '      '
        replace(anchor,
            indent+f'hyle_caller_tuple_probe::record("{name}-input", j, 24, ports[{index}].ordinal(), take(member.base->{name}_hidden.tensor(dense(Type::kBFloat16, {{1, hidden}}))));\n'+anchor)
    for name, description in [('history','history'),('recurrent','recurrent')]:
        anchor=f'          check(run.bind(ports.{name}, descriptions.{description}, step.members[j].base->state[i].{name}));'
        replace(anchor,
            f'          hyle_caller_tuple_probe::record("{name}-input", j, i, ports.{name}.ordinal(), take(step.members[j].base->state[i].{name}.tensor(descriptions.{description})));\n'+anchor)
    replace('''          const auto bind_state = [&](V port, const c::TensorDesc &description, c::LeasePool &pool) {
            if (phase.child->caller_output(port))
              check(run.bind(port, description, take(pool.allocate(take(description.required_bytes())))));
          };''', '''          const auto bind_state = [&](V port, const c::TensorDesc &description, c::LeasePool &pool, const char *label) {
            if (phase.child->caller_output(port)) {
              auto writer = take(pool.allocate(take(description.required_bytes())));
              hyle_caller_tuple_probe::record(label, j, i, port.ordinal(), take(c::TensorView::create(description, take(writer.view()))));
              check(run.bind(port, description, std::move(writer)));
            }
          };''')
    for name,pool in [('next_history','history'),('next_recurrent','recurrent'),('first_history','history'),('first_recurrent','recurrent')]:
        anchor=f'bind_state(ports.{name}, descriptions.{pool}, state_pools[i].{pool});'
        replace(anchor,f'bind_state(ports.{name}, descriptions.{pool}, state_pools[i].{pool}, "{name}-output");')
    replace('''          if (phase.child->caller_output(ports[i]))
            check(run.bind(ports[i], dense(Type::kBFloat16, {1, hidden}), take(hidden_pool.allocate(4096))));''',
        '''          if (phase.child->caller_output(ports[i])) {
            auto writer = take(hidden_pool.allocate(4096));
            const auto description = dense(Type::kBFloat16, {1, hidden});
            hyle_caller_tuple_probe::record(i ? "carry-row1-output" : "carry-row0-output", static_cast<std::size_t>(&ports - phase.carry_ports.data()), 24, ports[i].ordinal(), take(c::TensorView::create(description, take(writer.view()))));
            check(run.bind(ports[i], description, std::move(writer)));
          }''')
    target = STAGE/'probe/tools/qwen35_text/main.cc'
    assert not target.exists(), 'do not replace an existing frozen probe'
    target.parent.mkdir(parents=True,exist_ok=True)
    target.write_text(text,encoding='utf-8',newline='\n')
    (STAGE/'main-probe.diff').write_text(''.join(difflib.unified_diff(original.splitlines(True),text.splitlines(True),fromfile=str(source),tofile=str(target))),encoding='utf-8')
    record=dict(status='SOURCE_ONLY_NOT_COMPILED_OR_RUN',base=identity(source),generated=identity(target),
                helper=identity(STAGE/'probe/caller_tuple_probe.h'),
                scope='Caller-side logging before original binds; exact original source and allocation sequence. Local WriteLease and TensorViews do not escape. No core/provider TU rebuilt.',
                limitations=['Does not observe first retained-range erase; correlate scalar tuple changes with existing capture counts and original route metadata.',
                             'All timing from this diagnostic is invalid for TPS comparisons.'],
                build_suggestion='Root may substitute this sole consumer TU in current195 closure, adding /I tools/qwen35_text. Keep all native objects unchanged. No run is performed by generator.')
    (STAGE/'main-probe.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(record))


if __name__ == '__main__':
    main()
