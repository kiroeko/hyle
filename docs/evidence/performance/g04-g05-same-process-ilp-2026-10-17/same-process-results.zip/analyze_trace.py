import sqlite3,pathlib,bisect,collections,statistics,json,hashlib
P=pathlib.Path('/root/hyle-scratch/compute-unified/g04-same-process-ilp/run-trace-1')
c=sqlite3.connect(P/'profile.sqlite');c.row_factory=sqlite3.Row
strings=dict(c.execute('select id,value from StringIds'))
nv=[dict(r) for r in c.execute('select * from NVTX_EVENTS where end is not null order by start')]
shapes=[r for r in nv if r['text'] in ['window','prefill','holdout']]
assert [r['text'] for r in shapes]==['window','prefill','holdout']*4
episodes=[r for r in nv if r['text'] in ['control.episode','treatment.episode']]
assert len(episodes)==12288
starts=[r['start'] for r in episodes]
shape_starts=[r['start'] for r in shapes]
for i,e in enumerate(episodes):
    j=bisect.bisect_right(shape_starts,e['start'])-1;s=shapes[j];assert e['end']<=s['end']
    e.update(shape=s['text'],alloc=j//6,order=j//3%2,side=e['text'].split('.')[0])
    e['stages']={};e['api']=collections.defaultdict(list);e['kernels']=[]
for r in nv:
    if r['text'] not in ['update','admit_submit','checked_wait','output_acquire']:continue
    i=bisect.bisect_right(starts,r['start'])-1
    if i>=0 and r['end']<=episodes[i]['end']:episodes[i]['stages'][r['text']]=(r['end']-r['start'])/1000
runtime={}
for r in c.execute('select * from CUPTI_ACTIVITY_KIND_RUNTIME order by start'):
    i=bisect.bisect_right(starts,r['start'])-1
    if i>=0 and r['end']<=episodes[i]['end'] and r['globalTid']==episodes[i]['globalTid']:
        runtime[r['correlationId']]=i
        episodes[i]['api'][strings[r['nameId']]].append((r['end']-r['start'])/1000)
resources=collections.defaultdict(set);outside=0
for r in c.execute('select * from CUPTI_ACTIVITY_KIND_KERNEL order by start'):
    if r['correlationId'] not in runtime:outside+=1;continue
    e=episodes[runtime[r['correlationId']]];name=strings[r['demangledName']];kind='merge' if 'MergeStatesKernel' in name else 'attention'
    e['kernels'].append({'kind':kind,'us':(r['end']-r['start'])/1000,'registers':r['registersPerThread'],'correlation':r['correlationId']})
    resources[e['shape'],e['side'],kind].add((r['registersPerThread'],r['dynamicSharedMemory'],r['localMemoryPerThread'],r['blockX'],r['blockY'],r['blockZ'],strings[r['mangledName']]))
assert sum(len(e['kernels']) for e in episodes)==16384
for e in episodes:
    assert len(e['kernels'])==(2 if e['shape']=='prefill' else 1)
    assert set(e['stages'])=={'update','admit_submit','checked_wait','output_acquire'}
    if e['shape']=='prefill':assert [k['registers'] for k in e['kernels'] if k['kind']=='attention']==[248 if e['side']=='control' else 250]
groups=collections.defaultdict(list)
for e in episodes:groups[e['alloc'],e['order'],e['shape'],e['side']].append(e)
rows=[]
for alloc in range(2):
 for order in range(2):
  for shape in ['window','prefill','holdout']:
   row={'alloc':alloc,'order':order,'shape':shape,'arm':{}}
   for side in ['control','treatment']:
    ee=groups[alloc,order,shape,side];assert len(ee)==512
    kernel={k:statistics.mean(sum(x['us'] for x in e['kernels'] if x['kind']==k) for e in ee) for k in ['attention','merge'] if any(x['kind']==k for x in ee[0]['kernels'])}
    stages={k:statistics.mean(e['stages'][k] for e in ee) for k in ee[0]['stages']}
    api={k:statistics.mean(sum(e['api'].get(k,[])) for e in ee) for k in sorted(set.union(*(set(e['api']) for e in ee)))}
    row['arm'][side]={'kernel_mean_us':kernel,'host_stage_mean_us_trace_only':stages,'cuda_api_mean_us_trace_only':api}
   row['gpu_delta_pct']={k:(row['arm']['treatment']['kernel_mean_us'][k]/v-1)*100 for k,v in row['arm']['control']['kernel_mean_us'].items()}
   rows.append(row)
result={'state':'ONE_PROFILER_RUN_EXPLANATION_ONLY_NOT_ORDINARY_PRIMARY','episodes':len(episodes),'timed_kernels':16384,'outside_timed_kernels':outside,'resources':[{'shape':k[0],'side':k[1],'kind':k[2],'variants':[{'registers':r[0],'dynamic_shared':r[1],'local_bytes':r[2],'block':r[3:6],'mangled':r[6]} for r in sorted(v)]} for k,v in resources.items()],'strata':rows,'sqlite_sha256':hashlib.sha256((P/'profile.sqlite').read_bytes()).hexdigest()}
(P/'analysis.json').write_text(json.dumps(result,indent=2)+'\n')
with (P/'episode-kernels.jsonl').open('w') as f:
 for i,e in enumerate(episodes):
  r={k:e[k] for k in ['shape','alloc','order','side','kernels','stages']};r['index']=i;r['api']=dict(e['api']);f.write(json.dumps(r)+'\n')
for row in rows:print(row['alloc'],row['order'],row['shape'],row['gpu_delta_pct'],row['arm']['control']['kernel_mean_us'],row['arm']['treatment']['kernel_mean_us'])
