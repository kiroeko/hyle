import pathlib, subprocess, re, hashlib, json, shlex, time

ROOT=pathlib.Path('/root/hyle-scratch/compute-unified/g04-same-process-ilp')
OLD=pathlib.Path('/root/hyle-scratch/compute-unified/g04-load-ilp-2026-10-17/consumer')
SDK=pathlib.Path('/root/hyle-scratch/compute-unified/g06-final-sdk/cuda-static-1/relocated')
OUT=pathlib.Path('/mnt/c/public/project-hyle/hyle/.scratch/g04-same-process-ilp')
ROOT.mkdir(exist_ok=False)
(ROOT/'original').mkdir()
def run(args): return subprocess.check_output([str(a) for a in args],text=True)
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def nm(p,external=False):
    a=['nm','--defined-only','--format=posix']
    if external:a+=['--extern-only']
    return run(a+[p])
def names(s):return {l.split()[0] for l in s.splitlines()}
archive=SDK/'lib/libhyle_compute_provider_flashinfer.a'
for member in ['flashinfer_provider.cc.o','native_batch.cu.o']:
    (ROOT/'original'/member).write_bytes(subprocess.check_output(['ar','p',str(archive),member]))
factory='_ZN4hyle7compute10flashinfer8providerEv'
report={'archive':{'path':str(archive),'sha256':sha(archive)},'arms':{},'source':str(OLD/'bench/inference_resident_sdpa/cuda_encoded_page_bench.cc')}
targets={}
for arm in ['control','treatment']:
    files=[ROOT/'original/flashinfer_provider.cc.o',ROOT/'original/native_batch.cu.o',OLD/f'native_cache_{arm}.o']
    folder=ROOT/arm;folder.mkdir()
    defined=set(); signatures=set()
    for i,p in enumerate(files):
        (folder/f'before-{i}.symbols.txt').write_text(run(['readelf','-Ws',p]))
        groups=run(['readelf','--section-groups',p]);(folder/f'before-{i}.groups.txt').write_text(groups)
        defined.update(names(nm(p,True)))
        signatures.update(re.findall(r"COMDAT group section.*?\[([^\]]+)\] contains",groups))
    candidates=[]
    for line in nm(files[2]).splitlines():
        n,t,*_=line.split()
        if t=='t' and n.startswith('_ZN10flashinferL34BatchPrefillWithPagedKVCacheKernel') and 'MaskModeE1ELj64ELj1ELj1ELj16ELj16ELj4ELj1E' in n and '13__nv_bfloat1613__nv_fp8_e4m3ffi' in n and 'MergeParams' in n and 'Lj256E' in n and not n.endswith('.cold'):candidates.append(n)
    assert len(candidates)==1,candidates
    target=candidates[0];targets[arm]='g04_'+arm+'_'+target
    mapping={n:'g04_'+arm+'_'+n for n in defined|signatures|{target}}
    mp=folder/'rename.syms';mp.write_text(''.join(f'{a} {b}\n' for a,b in sorted(mapping.items())))
    rows=[]
    for i,p in enumerate(files):
        dst=folder/['provider.o','batch.o','cache.o'][i]
        args=['objcopy','--redefine-syms='+str(mp)]
        if i==2:args+=['--globalize-symbol='+targets[arm]]
        args += [str(p),str(dst)];subprocess.run(args,check=True)
        after=run(['readelf','-Ws',dst]);(folder/f'after-{i}.symbols.txt').write_text(after)
        groups=run(['readelf','--section-groups',dst]);(folder/f'after-{i}.groups.txt').write_text(groups)
        assert names(nm(dst,True)) == {mapping[n] for n in names(nm(p,True))}|({targets[arm]} if i==2 else set())
        before_u=names(run(['nm','--undefined-only','--format=posix',p]))
        after_u=names(run(['nm','--undefined-only','--format=posix',dst]))
        assert after_u=={mapping.get(n,n) for n in before_u}
        for sig in re.findall(r"COMDAT group section.*?\[([^\]]+)\] contains",groups):assert sig.startswith('g04_'+arm+'_')
        row={'original':str(p),'original_sha256':sha(p),'cloned':str(dst),'cloned_sha256':sha(dst),'defined':len(names(nm(p,True))),'undefined_original':sorted(before_u),'undefined_after':sorted(after_u)}
        if i==2:
            for which,ob in [('original',p),('cloned',dst)]:
                raw=folder/(which+'.fatbin');subprocess.run(['objcopy','--dump-section','.nv_fatbin='+str(raw),str(ob)],check=True)
                row[which+'_fatbin_sha256']=sha(raw)
            assert row['original_fatbin_sha256']==row['cloned_fatbin_sha256']
        rows.append(row)
    report['arms'][arm]={'objects':rows,'map_sha256':sha(mp),'defined_count':len(defined),'comdat_count':len(signatures),'target':targets[arm],'factory':'g04_'+arm+'_'+factory}
assert not set.union(*(names(nm(ROOT/'control'/p,True)) for p in ['provider.o','batch.o','cache.o'])) & set.union(*(names(nm(ROOT/'treatment'/p,True)) for p in ['provider.o','batch.o','cache.o']))
src=(OLD/'bench/inference_resident_sdpa/cuda_encoded_page_bench.cc').read_text()
src=src.replace('#include "../common/perf_process.h"','').replace('#include <nanobench.h>','#include <cuda_runtime_api.h>\n#include <sched.h>')
src=src.replace('namespace c=hyle::compute;namespace nb=ankerl::nanobench;','namespace c=hyle::compute;')
start=src.index('template<class A,class B>') if 'template<class A,class B>' in src else -1
end=src.index('struct Harness {')
if start<0:
    # Keep only Data and its independent oracle before the old nanobench helper.
    start=src.index('nb::CompareResult')
src=src[:start]+src[end:]
decl='namespace hyle::compute::flashinfer {\n'
for arm in ['control','treatment']:decl+=f'Provider provider_{arm}() noexcept asm("g04_{arm}_{factory}");\n'
decl+='}\n'
for arm in ['control','treatment']:decl+=f'extern "C" void target_{arm}() asm("{targets[arm]}");\n'
src=src.replace('namespace {',decl+'namespace {',1)
src=src.replace('c::flashinfer::provider())','original?c::flashinfer::provider_control():c::flashinfer::provider_treatment())')
src=src[:src.index('void measure(int q1')]+r'''
using Clock=std::chrono::steady_clock;
double us(Clock::duration d){return std::chrono::duration<double,std::micro>(d).count();}
void attrs(){
  cudaFuncAttributes a{},b{};
  if(cudaFuncGetAttributes(&a,reinterpret_cast<const void*>(&target_control))!=cudaSuccess||
     cudaFuncGetAttributes(&b,reinterpret_cast<const void*>(&target_treatment))!=cudaSuccess)
    fail(hyle::Status::Internal("isolated kernel attribute query failed"));
  std::printf("ATTR control_regs=%d treatment_regs=%d control_local=%zu treatment_local=%zu control_shared=%zu treatment_shared=%zu control_binary=%d treatment_binary=%d control_stub=%p treatment_stub=%p\n",a.numRegs,b.numRegs,a.localSizeBytes,b.localSizeBytes,a.sharedSizeBytes,b.sharedSizeBytes,a.binaryVersion,b.binaryVersion,reinterpret_cast<void*>(&target_control),reinterpret_cast<void*>(&target_treatment));
  if(a.numRegs!=248||b.numRegs!=250||a.localSizeBytes||b.localSizeBytes||a.binaryVersion!=89||b.binaryVersion!=89)fail(hyle::Status::Internal("expected original248/new250 SM89 identity not established"));
}
void measure(unsigned alloc,unsigned order,int q1,int q2,int k1,int k2,int dk,int dv,bool causal,int window,bool verify_only=false){
  const char *shape=verify_only?"tail":(window>=0?"window":(dk==256?"prefill":"holdout"));
  Data data(q1,q2,k1,k2,dk,dv,causal,window);std::unique_ptr<Harness> h[2];
  for(unsigned i=0;i<2;++i){const unsigned side=alloc?1-i:i;const auto start=Clock::now();h[side]=std::make_unique<Harness>(data,side==0);std::printf("COLD alloc=%u order=%u shape=%s side=%u create_us=%.9f\n",alloc,order,shape,side,us(Clock::now()-start));}
  const auto expected=data.oracle();std::vector<std::uint16_t> values[2];
  for(unsigned replay=0;replay<4;++replay)for(unsigned side=0;side<2;++side)values[side]=h[side]->verify(data,expected);
  double diff=0;for(std::size_t i=0;i<expected.size();++i)diff=std::max(diff,std::abs(double(decode(values[0][i]))-decode(values[1][i])));
  if(diff>8e-3)fail(hyle::Status::Internal("control/treatment disagreement exceeded 8e-3"));
  std::printf("ORACLE alloc=%u order=%u shape=%s pair_difference=%.9g\n",alloc,order,shape,diff);
  if(!verify_only){
    for(unsigned i=0;i<64;++i)for(unsigned j=0;j<2;++j){auto output=h[order?1-j:j]->execute();output.reset();}
    diagnostic_trace=set("G04_TRACE");push(shape);
    std::array<std::array<double,2>,512> raw{};
    for(unsigned group=0;group<8;++group)for(unsigned step=0;step<64;++step)for(unsigned j=0;j<2;++j){
      const unsigned side=order?1-j:j;
      push(side?"treatment.episode":"control.episode");const auto start=Clock::now();
      {auto output=h[side]->execute();output.reset();}
      raw[group*64+step][side]=us(Clock::now()-start);pop();
    }
    pop();diagnostic_trace=false;
    for(unsigned group=0;group<8;++group){double sums[2]{};
      for(unsigned step=0;step<64;++step){const auto &x=raw[group*64+step];sums[0]+=x[0];sums[1]+=x[1];std::printf("PAIR alloc=%u order=%u shape=%s group=%u step=%u control_us=%.9f treatment_us=%.9f\n",alloc,order,shape,group,step,x[0],x[1]);}
      std::printf("BLOCK alloc=%u order=%u shape=%s group=%u count=64 control_us=%.9f treatment_us=%.9f\n",alloc,order,shape,group,sums[0]/64,sums[1]/64);
    }
    for(unsigned side=0;side<2;++side)h[side]->verify(data,expected);
  }
  for(unsigned i=0;i<2;++i){const unsigned side=alloc?1-i:i;const auto start=Clock::now();h[side].reset();std::printf("CLOSE alloc=%u order=%u shape=%s side=%u close_us=%.9f\n",alloc,order,shape,side,us(Clock::now()-start));}
}
}
int main(){
  cpu_set_t cpus;CPU_ZERO(&cpus);CPU_SET(2,&cpus);if(sched_setaffinity(0,sizeof(cpus),&cpus)!=0)fail(hyle::Status::Internal("caller CPU2 affinity failed"));
  attrs();
  std::printf("SCHEDULE warmups=64 groups=8 group_size=64 primary=complete_episode_arithmetic_block_mean slots=2 allocation_orders=2 execution_orders=2 trace=%d\n",set("G04_TRACE"));
  for(unsigned alloc=0;alloc<2;++alloc)for(unsigned order=0;order<2;++order){
    measure(alloc,order,1,17,1024,768,256,256,true,16);
    measure(alloc,order,64,128,1024,768,256,256,true,-1);
    measure(alloc,order,17,1,7,47,64,128,false,-1);
  }
  measure(0,0,64,128,1023,767,256,256,true,-1,true);
  std::printf("EXIT code=0\n");return 0;
}
'''
(ROOT/'bench').mkdir()
(ROOT/'bench/cuda_encoded_page_bench.cc').write_text(src)
(ROOT/'bench/cuda_encoded_page_reference.h').write_bytes((OLD/'bench/inference_resident_sdpa/cuda_encoded_page_reference.h').read_bytes())
report['consumer_sha256']=sha(ROOT/'bench/cuda_encoded_page_bench.cc')
(ROOT/'identity.json').write_text(json.dumps(report,indent=2)+'\n')
for p in ['identity.json','bench/cuda_encoded_page_bench.cc','bench/cuda_encoded_page_reference.h']:(OUT/pathlib.Path(p).name).write_bytes((ROOT/p).read_bytes())
cmds=run(['ninja','-C',OLD/'build','-t','commands','load_ilp_control']).splitlines()
compile_argv=shlex.split(cmds[0]);compile_argv=compile_argv[:compile_argv.index('-MD')]+['-o',str(ROOT/'consumer.o'),'-c',str(ROOT/'bench/cuda_encoded_page_bench.cc')]
link=shlex.split(cmds[1]);link=link[2:link.index('&&',2)]
oldobj=str(OLD/'native_cache_control.o');idx=link.index(oldobj)
link[idx:idx+2]=[str(ROOT/arm/p) for arm in ['control','treatment'] for p in ['provider.o','batch.o','cache.o']]+[str(ROOT/'consumer.o')]
link[link.index('-o')+1]=str(ROOT/'g04_same_process')
link=[('-Wl,-Map='+str(ROOT/'link.map')) if x.startswith('-Wl,-Map=') else x for x in link]
(ROOT/'commands.json').write_text(json.dumps({'compile':compile_argv,'link':link},indent=2)+'\n')
(OUT/'commands.json').write_bytes((ROOT/'commands.json').read_bytes())
print(json.dumps({'root':str(ROOT),'consumer_sha256':report['consumer_sha256'],'target':targets,'maps':[(k,v['defined_count'],v['comdat_count']) for k,v in report['arms'].items()]}))
