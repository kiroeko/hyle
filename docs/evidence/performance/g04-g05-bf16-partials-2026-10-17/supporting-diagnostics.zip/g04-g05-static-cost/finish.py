from pathlib import Path
import hashlib
import json
import re

out=Path(__file__).resolve().parent
pattern=re.compile(r'/\*([0-9a-f]+)\*/\s+((?:@!?P\d+\s+)?[A-Z][^;]*;)')
code=[(int(m[1],16),m[2].strip()) for line in (out/'overlap-sass.txt').read_text().splitlines() if (m:=pattern.search(line))]
print('V next-vector initialization and guard:')
for pc,ins in code:
    if 0x4260<=pc<=0x4350:
        print(f'{pc:04x}',ins)
paths=['static-cost-analysis.json','prepare_overlap.py','prefill-both.cuh','overlap-both.patch',
       'compile_overlap_wsl.py','overlap-compile.json','overlap-compile.log','overlap-resources.txt',
       'overlap-sass.txt','analyze.py','analyze_overlap_wsl.py','overlap-codegen-analysis.json',
       'overlap-four-kernel-sass.txt']
manifest={p:{'sha256':hashlib.sha256((out/p).read_bytes()).hexdigest(),'bytes':(out/p).stat().st_size} for p in paths}
(out/'files.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
print(json.dumps(manifest,indent=2))
