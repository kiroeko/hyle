from pathlib import Path
import collections
import hashlib
import json
import re
import sqlite3
import struct

root = Path(__file__).resolve().parents[2]
out = Path(__file__).resolve().parent
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
control = root / '.scratch/inference-performance-recovery-2026-10-17/g04-load-ilp-control-sass.txt'
peer = root / '.scratch/inference-gaps/g04-g05/causal-diagnostic-1/actual-attention-sass.txt'
decoder = root / '.scratch/g04-g05-dual-k-adoption/materialized-production/include/flashinfer/vec_dtypes.cuh'
pattern = re.compile(r'/\*([0-9a-f]+)\*/\s+((?:@!?P\d+\s+)?[A-Z][^;]*;)')
def parse(text):
    return [(int(m[1],16), m[2].strip()) for line in text.splitlines() if (m:=pattern.search(line))]
def functions(path):
    chunks = re.split(r'\s*Function : ', path.read_text(encoding='utf-8'))[1:]
    return [(chunk.splitlines()[0], parse(chunk)) for chunk in chunks]

control_name, control_code = functions(control)[0]
peer_functions = functions(peer)
bf_name, bf_code = next((name, code) for name,code in peer_functions if 'S4_ffi' in name)
def ops(code):
    return dict(collections.Counter(re.sub(r'^@!?P\d+\s+', '', ins).split()[0] for _,ins in code))
def selected(code, begin, end):
    return [{'pc':f'{pc:04x}', 'instruction':ins} for pc,ins in code if begin<=pc<=end]

dbpath = root / '.scratch/g04-g05-sameprocess-review/d1-current.sqlite'
db = sqlite3.connect(dbpath.as_uri()+'?mode=ro&immutable=1',uri=True)
gpu_columns = [r[1] for r in db.execute('pragma table_info(TARGET_INFO_GPU)')]
gpu_rows = [dict(zip(gpu_columns,row)) for row in db.execute('select * from TARGET_INFO_GPU')]
db.close()

# Source formula, not a new GPU observation. Every result is representable
# exactly as BF16; legacy 0x7f/0xff are finite because their temporary BF16
# exponent is finite, unlike CUDA's class scalar-conversion semantics.
def expected(code):
    exponent=(code&127)>>3
    mantissa=code&7
    x=((1+mantissa/8)*2.**(exponent-7)) if exponent else mantissa*2.**-9
    if code&128: x=-x
    return struct.unpack('<I',struct.pack('<f',x))[0]>>16
mapping=[expected(c) for c in range(256)]
normal_formula=lambda c: (((c&0x7f)<<4)+0x3c00)|((c&0x80)<<8)
assert all(mapping[c]==normal_formula(c) for c in range(256) if (c&0x78)!=0)

# The archived trace says grid(40,1,2); source planner with 46 SM gives 46
# available split tasks per KV head and selects 16 pages (256 tokens).
qrows=[64,128]; kvrows=[1024,768]; hq=8; hkv=2; group=4; qtile=64; ktile=16; depth=256
chunks=[4,3]
tasks=sum((q*group+qtile-1)//qtile*c for q,c in zip(qrows,chunks))
partial_rows=sum(q*c for q,c in zip(qrows,chunks))
actual_f32_values=partial_rows*hq*depth*4
actual_bf16_values=partial_rows*hq*depth*2
actual_scores=partial_rows*hq*4
allocation_values=hq*tasks*qtile*depth*4
allocation_scores=hq*tasks*qtile*4
assert tasks==40 and allocation_values+allocation_scores==21053440
request_tiles=[]
for q,k in zip(qrows,kvrows):
    needed=loaded=0
    for tile in range((q*group+qtile-1)//qtile):
        causal_end=min(k,k-q+((tile+1)*qtile+group-1)//group)
        for start in range(0,k,256):
            end=min(start+256,k)
            iterations=(max(0,min(end,causal_end)-start)+15)//16
            needed+=iterations
            # The prologue + unconditional next-tile producers make one
            # extra read if causal bound ends before this chunk's end.
            loaded+=min(iterations+1,(end-start+15)//16)
    request_tiles.append({'query_rows':q,'kv_rows':k,'consumed_tiles_per_kv_head':needed,
                          'valid_loaded_tiles_per_kv_head':loaded})
result={
 'state':'STATIC_COST_AND_DEPENDENCY_ANALYSIS_NOT_CYCLE_MEASUREMENT',
 'gpu_executed':False, 'canonical_product_changed':False,
 'inputs':{str(p.relative_to(root)):{'sha256':sha(p),'bytes':p.stat().st_size} for p in [control,peer,decoder,dbpath]},
 'actual_gpu_info_from_archived_trace':gpu_rows,
 'sass':{'current':{'name':control_name,'instructions':len(control_code),'ops':ops(control_code)},
         'bf16_f32_cropped_d3':{'name':bf_name,'instructions':len(bf_code),'ops':ops(bf_code)}},
 'first_k_dependency_chain':selected(control_code,0x1170,0x17e0),
 'pipeline_mechanism':[
   'BF16 producer issues cp.async and returns; next K can overlap current PV, next V can overlap next QK.',
   'Actual FP8 SASS, not source order: next K LDG 3bd0/3f40 follows softmax EX2 31e0..3610; decode/store finishes before BAR 4370 and PV HMMA 4620..4850.',
   'Actual FP8 SASS already hoists next V LDG 4540/4570 before current PV HMMA 4620..4850, then decodes after PV at 4860..4e70. Missing V load/PV overlap is NOT established.',
   'Earlier source-order-only V serialization inference is corrected here; a synchronous-looking source helper is not proof of final scheduling.',
   'Moving both K packed loads together did not recover cross-math prefetch overlap and had no stable full-flow benefit.',
   'Do not move V shared stores before current PV: they overwrite the current V tile.',
   'Moving whole K producer before softmax is shared-memory safe after QK, but still serializes load/decode/math; it is not proof of overlap.'
 ],
 'loop_sass_evidence':selected(control_code,0x31d0,0x4e70),
 'decoder':{'element_count_per_quad':4,'prmt_per_quad':1,'bf16_hfma2_per_quad':2,
            'scale_power':120,'all_256_source_formula_bf16_hex':[f'{x:04x}' for x in mapping],
            'zero_hex':{'00':f'{mapping[0]:04x}','80':f'{mapping[128]:04x}'},
            'legacy_special_hex':{'7f':f'{mapping[127]:04x}','ff':f'{mapping[255]:04x}'},
            'special_status':'source/SASS-derived finite +/-480; old all-code GPU probe preserved old bits but did not print special values',
            'normal_integer_formula':'((code & 0x7f) << 4) + 0x3c00, OR ((code & 0x80) << 8); exact only exponent != 0',
            'subnormal_positive_hex':[f'{mapping[x]:04x}' for x in range(8)],
            'c1_status':'old native FP8->half->float->BF16 path exact but measured slower; not retried'},
 'tile_bytes':{'kv_rows':16,'depth':256,'threads':128,'fp8_global_k':4096,'fp8_global_v':4096,
               'bf16_global_k':8192,'bf16_global_v':8192,'bf16_shared_k':8192,'bf16_shared_v':8192,
               'q_shared':32768,'dynamic_shared_total':49152,
               'fp8_ldg128_per_thread_per_tile_k_plus_v':4,'fp8_sts128_per_thread_per_tile_k_plus_v':8,
               'fp8_prmt_per_thread_per_tile_k_plus_v':16,'fp8_hfma2_per_thread_per_tile_k_plus_v':32},
 'prefill_source_derived_geometry':{'query_rows':qrows,'kv_rows':kvrows,'query_heads':hq,'kv_heads':hkv,
   'tasks_per_kv_head':tasks,'grid':[tasks,1,hkv],'kv_chunk_tokens':256,'chunks_per_request':chunks,
   'actual_partial_rows':partial_rows,'allocated_partial_rows_including_q_tile_padding':tasks*qtile,
   'f32_partial_values_write_bytes':actual_f32_values,'f32_partial_values_read_bytes':actual_f32_values,
   'bf16_partial_values_write_bytes':actual_bf16_values,'bf16_partial_values_read_bytes':actual_bf16_values,
   'f32_extra_value_roundtrip_bytes':2*(actual_f32_values-actual_bf16_values),
   'score_write_bytes':actual_scores,'score_read_bytes':actual_scores,
   'final_bf16_write_bytes':sum(qrows)*hq*depth*2,'allocation_values_bytes':allocation_values,
   'allocation_scores_bytes':allocation_scores,'allocation_bytes_are_not_traffic':True,
   'request_tile_counts':request_tiles,
   'fp8_kv_valid_load_bytes_including_last_unused_prefetch':sum(x['valid_loaded_tiles_per_kv_head'] for x in request_tiles)*hkv*8192,
   'bf16_kv_valid_load_bytes_same_geometry':sum(x['valid_loaded_tiles_per_kv_head'] for x in request_tiles)*hkv*16384,
   'traffic_status':'derived logical accesses from loop + exact divisible shape; not DRAM/L2 transaction counters'},
 'resources':{'current_registers':248,'bf16_f32_d3_registers':239,'dual_k_registers':250,
              'block_threads':128,'dynamic_shared_bytes':49152,'current_spill_bytes':0,
              'register_only_raw_block_upper_bound':2,'shared_only_block_upper_bound':2,
              'max_warps_per_sm':48,'two_block_active_warps':8,'two_block_occupancy_fraction':8/48,
              'bound_not_measured_active_occupancy':True,
              'source_lifetimes':[
                'D256 CTA64/4Qwarps gives NUM_MMA_Q1 and o_frag[1][16][8]: 128 F32 accumulator values persist across all KV iterations, in both BF16 and FP8 representations.',
                's_frag[1][1][8], m[1][2], d[1][2] span QK/softmax/PV; packed conversion temporaries add shorter producer-local lifetimes.',
                'Original SASS already keeps next V packed registers R68..R75 across PV (loads4540/4570, PRMT first uses4860 onward).',
                'K first vector R4..R7 at3bd0 is consumed by decode before second K vector at3f40, so original K has neither early softmax-crossing load nor two packed vector lifetimes together.',
                'These are source/dataflow lifetimes, not a complete per-PC register-allocation proof; final compiler allocation is the actual 248-register fact.'
              ],
              'occupancy_explanation':'Current, BF16/F32 D3, dualK all allow at most two blocks under 64K registers/100KB shared. No resource tier drop established.'},
 'merge':{'grid':[460,1,1],'block':[32,4,1],'shared_bytes':8704,
          'f32_stages':2,'f32_registers':48,'bf16_stages':4,'bf16_registers':40,
          'partial_sets_per_output_row':[4,3],'merge_loop_iterations_per_state':1,
          'f32_vec8_async128_instructions_per_active_thread':2,
          'bf16_vec8_async128_instructions_per_active_thread':1,
          'stage_note':'Only 3/4 input states with bdy4: neither 2 nor 4 stages gives a long multi-iteration pipeline on this shape; original 2x2 stage bundle remains a controlled factor.',
          'geometry_note':'460 persistent CTAs iterate 1536 output row/head states; grid is not partial-row count',
          'causal_limit':'D3 cropped source changed representation and stage bundle; old deltas cannot be called pure conversion/byte costs'},
 'primary_sources':[
   'https://docs.nvidia.com/cuda/ada-tuning-guide/',
   'https://docs.nvidia.com/cuda/parallel-thread-execution/'
 ],
 'limits':['No static instruction count is interpreted as elapsed cycles.','No clock/DRAM/L2/scoreboard counter was collected here.',
           'Existing D3 is cropped; new full-TU 2x2 experiment is needed before causal attribution.',
           'Current merge already fuses output scale/cast; no obsolete extra F32 final staging traffic is counted.']
}
(out/'static-cost-analysis.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'current_instruction_count':len(control_code),'bf16_d3_instruction_count':len(bf_code),
                  'gpu_info':gpu_rows,'partial':result['prefill_source_derived_geometry'],
                  'legacy_special':result['decoder']['legacy_special_hex']},indent=2))
