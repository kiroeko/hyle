from pathlib import Path
import collections
import hashlib
import json
import re
import subprocess
import time

root = Path('/mnt/c/public/project-hyle/hyle')
out = root / '.scratch/g04-g05-static-cost'
build = json.loads((out/'overlap-compile.json').read_text())
assert build['state']=='COMPILE_AND_CODEGEN_PASS_NO_GPU'
obj=Path(build['object'])
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert sha(obj)==build['object_sha256']
link=json.loads((root/'.scratch/inference-performance-recovery-2026-10-17/g04-load-ilp-link-receipt.json').read_text())
names={k:v['function'] for k,v in link['linked_kernel_review']['kernels']['control'].items()}
cmd=['/usr/local/cuda-13.3/bin/cuobjdump','--dump-sass','--function',','.join(names.values()),str(obj)]
t=time.monotonic()
with (out/'overlap-four-kernel-sass.txt').open('w') as f:
    p=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,timeout=60)
assert p.returncode==0
pattern=re.compile(r'/\*([0-9a-f]+)\*/\s+((?:@!?P\d+\s+)?[A-Z][^;]*;)')
def parse(path):
    result={}
    for chunk in re.split(r'\s*Function : ',Path(path).read_text())[1:]:
        name=chunk.splitlines()[0]
        code=[(int(m[1],16),m[2].strip()) for line in chunk.splitlines() if (m:=pattern.search(line))]
        result[name]=code
    return result
baseline=parse(root/'.scratch/inference-performance-recovery-2026-10-17/g04-load-ilp-linked-control-sass.txt')
candidate=parse(out/'overlap-four-kernel-sass.txt')
assert set(names.values()).issubset(baseline) and set(names.values()).issubset(candidate)
resources=(out/'overlap-resources.txt').read_text()
rows={}
for key,name in names.items():
    old=baseline[name]; new=candidate[name]
    norm=lambda code:'\n'.join(x[1] for x in code).encode()
    getops=lambda code:dict(collections.Counter(re.sub(r'^@!?P\d+\s+','',x[1]).split()[0] for x in code))
    match=re.search(r'Function\s+[^\n]*'+re.escape(name)+r'[^\n]*\n([^\n]+)',resources)
    assert match, name
    rows[key]={'name':name,'resource_line':match[1].strip(),
               'control_normalized_sha256':hashlib.sha256(norm(old)).hexdigest(),
               'candidate_normalized_sha256':hashlib.sha256(norm(new)).hexdigest(),
               'instructions_control':len(old),'instructions_candidate':len(new),
               'ops_control':getops(old),'ops_candidate':getops(new),
               'sass_unchanged':norm(old)==norm(new)}
    if key!='prefill':
        assert rows[key]['sass_unchanged'], key+' unexpected codegen change'
code=candidate[names['prefill']]
selected=[]
for pc,ins in code:
    if any(x in ins for x in ['LDG.E.128','MUFU.EX2','HMMA.16816','HFMA2','STS.128','BAR.SYNC']):
        selected.append({'pc':f'{pc:04x}','instruction':ins})
result={'state':'CODEGEN_CAPTURED_NOT_GPU_TESTED','gpu_executed':False,'canonical_product_changed':False,
        'object':str(obj),'object_sha256':sha(obj),'candidate_prefill_sha256':build['candidate_prefill_sha256'],
        'command':cmd,'seconds':time.monotonic()-t,'kernels':rows,
        'prefill_selected_instructions':selected,
        'needs_human_dataflow_check':['K first LDG before softmax EX2 and dependent decoder after math',
                                     'Both V LDG before PV as in control; reject V second-read regression',
                                     'No target stack/local spills; unchanged math and shared stores/barriers']}
result['actual_schedule_review']={
    'k_first_load_pc':'2910','k_first_load_registers':'R64..R67',
    'qk_last_hmma_pc':'2d20','softmax_ex2_pc_range':['3260','3640'],
    'k_first_packed_use_pc':'3c50','k_second_load_pc':'3c40',
    'v_first_load_pc':'4320','v_second_load_pc':'4580',
    'pv_hmma_pc_range':['4630','4a50'],'v_first_decoder_pc':'47c0',
    'k_load_crosses_softmax_and_qk_tail':True,'v_second_load_regressed_past_pv':False,
    'v_decoder_now_interleaves_pv_tail':True,
    'pure_k_single_factor':False,
    'qualification':'Actual generated schedule meets the intended K overlap without spill. V load overlap already existed in control and is preserved; new V decoder schedule also changes. No runtime benefit or math PASS has been measured for this object.'
}
(out/'overlap-codegen-analysis.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:{x:v[x] for x in ['resource_line','instructions_control','instructions_candidate','sass_unchanged']} for k,v in rows.items()},indent=2))
print('Key schedule:')
for x in selected:
    if any(y in x['instruction'] for y in ['LDG.E.128','MUFU.EX2','BAR.SYNC']):
        print(x['pc'],x['instruction'])
