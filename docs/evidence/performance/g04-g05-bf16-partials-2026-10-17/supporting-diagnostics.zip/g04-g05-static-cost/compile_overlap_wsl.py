from pathlib import Path
import hashlib
import json
import os
import shlex
import shutil
import subprocess
import time

root = Path('/mnt/c/public/project-hyle/hyle')
out = root / '.scratch/g04-g05-static-cost'
work = Path('/root/hyle-scratch/compute-unified/g04-overlap-both-20261017')
assert not work.exists(), 'Use an owned fresh diagnostic directory'
work.mkdir(parents=True)
allowed = sorted(os.sched_getaffinity(0))
os.sched_setaffinity(0, allowed[-4:])
os.nice(10)
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
receipt = json.loads((root / 'evidence/architecture/inference-g04-g05-c1-packed-conversion/receipt.json').read_text())
original = receipt['direct_product_stage']['build']['original_compile_record']
args = shlex.split(original['command'])
include_i = next(i for i, a in enumerate(args) if a.startswith('-I') and 'cache-source-' in a)
old_include = Path(args[include_i][2:])
assert sha(original['file']) == '62ace94e0809144aca540fa317f72e9a2bc2b1d29b5099ef15048d3da6b92858'
assert sha(root / 'src/compute_provider_flashinfer/native_cache.cu') == sha(original['file'])
assert sha(old_include / 'flashinfer/attention/prefill.cuh') == '8146bd05db566d6f3c999a3aa3b83d91f7a565a343d06780edf2abd5faa0840f'
assert sha(out / 'prefill-both.cuh') == '5f696914da31a9bf2f50706f2f830dcbcec4e85cff0ca5ec755aa5c0f8188708'
include = work / 'include'
shutil.copytree(old_include, include)
shutil.copy2(out / 'prefill-both.cuh', include / 'flashinfer/attention/prefill.cuh')
obj = work / 'native_cache_overlap.o'
args[include_i] = '-I' + str(include)
for flag, value in [('-MT', obj), ('-MF', work / 'native_cache_overlap.d'), ('-o', obj)]:
    args[args.index(flag) + 1] = str(value)
args += ['--ptxas-options=-v']
result = {'state': 'COMPILE_RUNNING', 'gpu_executed': False, 'canonical_product_changed': False,
          'work': str(work), 'command': args, 'original_compile_record': original,
          'source_sha256': sha(original['file']), 'candidate_prefill_sha256': sha(include / 'flashinfer/attention/prefill.cuh'),
          'affinity': sorted(os.sched_getaffinity(0)), 'nice': os.nice(0), 'commands': []}
save = lambda: (out / 'overlap-compile.json').write_text(json.dumps(result, indent=2) + '\n')
save()
start = time.monotonic()
with (out / 'overlap-compile.log').open('w') as log:
    child = subprocess.Popen(args, cwd=original['directory'], stdout=log, stderr=subprocess.STDOUT)
    result['pid'] = child.pid
    save()
    print('native_cache full-TU compile PID', child.pid, flush=True)
    try:
        code = child.wait(timeout=900)
    except subprocess.TimeoutExpired:
        child.kill()
        child.wait()
        result.update(state='COMPILE_TIMEOUT', seconds=time.monotonic() - start)
        save()
        raise
result.update(state='COMPILE_PASS' if code == 0 else 'COMPILE_FAIL', exit=code, seconds=time.monotonic()-start)
result.pop('pid', None)
save()
if code:
    raise SystemExit(code)
result['object_sha256'] = sha(obj)
result['object'] = str(obj)
target = ('_ZN10flashinfer34BatchPrefillWithPagedKVCacheKernelINS_12KernelTraitsILNS_8MaskModeE1ELj64ELj1ELj1ELj16ELj16ELj4ELj1ELNS_15PosEncodingModeE0E13__nv_bfloat1613__nv_fp8_e4m3ffiNS_16DefaultAttentionILb0ELb1ELb0ELb0EEEEEN4hyle7compute10flashinfer6native48_GLOBAL__N__ca0ae4f1_15_native_cache_cu_95f5a4b011MergeParamsINS_23BatchPrefillPagedParamsIS4_S5_fiEES4_Lj256EEEEEvT0_')
for name, options in [('overlap-resources.txt', ['--dump-resource-usage']),
                      ('overlap-sass.txt', ['--dump-sass', '--function', target])]:
    command = ['/usr/local/cuda-13.3/bin/cuobjdump', *options, str(obj)]
    t = time.monotonic()
    with (out / name).open('w') as stream:
        p = subprocess.run(command, stdout=stream, stderr=subprocess.STDOUT, timeout=60)
    result['commands'].append({'command': command, 'exit': p.returncode, 'seconds': time.monotonic()-t,
                               'output': name, 'output_sha256': sha(out / name)})
    save()
    if p.returncode:
        raise SystemExit(p.returncode)
result['state'] = 'COMPILE_AND_CODEGEN_PASS_NO_GPU'
save()
print(json.dumps({k: result[k] for k in ['state','seconds','object','object_sha256','candidate_prefill_sha256']}, indent=2), flush=True)
