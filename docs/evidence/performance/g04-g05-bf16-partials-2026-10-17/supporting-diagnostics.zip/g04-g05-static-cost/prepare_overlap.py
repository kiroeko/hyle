from pathlib import Path
import difflib
import hashlib
import json

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent
SOURCE = ROOT / '.scratch/g04-g05-dual-k-adoption/prefill-control.cuh'
sha = lambda b: hashlib.sha256(b).hexdigest()
raw = SOURCE.read_bytes()
assert sha(raw) == '8146bd05db566d6f3c999a3aa3b83d91f7a565a343d06780edf2abd5faa0840f'
original = raw.decode('utf-8')

# This helper changes no decoder bits or shared layout. It deliberately carries
# just four registers across math; the second original 16B read stays in place.
helpers = r'''
template <typename KTraits>
constexpr bool hyle_overlap_probe_scope =
    KTraits::HYLE_FP8_DIRECT_STAGE && KTraits::CTA_TILE_Q == 64 &&
    KTraits::HEAD_DIM_QK == 256 && KTraits::HEAD_DIM_VO == 256 &&
    KTraits::NUM_MMA_KV == 1 && KTraits::NUM_WARPS_Q == 4 &&
    KTraits::NUM_WARPS_KV == 1 &&
    std::is_same_v<typename KTraits::DTypeQ, nv_bfloat16>;

__device__ __forceinline__ b128_t hyle_overlap_probe_load(const void* source, bool valid) {
  b128_t packed{};
  if (valid) {
    // Volatile PTX fixes the intended source order; SASS must still verify that
    // this load precedes math and that first use follows it. No GPU barrier.
    asm volatile("ld.global.v4.u32 {%0,%1,%2,%3}, [%4];"
                 : "=r"(packed.x), "=r"(packed.y), "=r"(packed.z), "=r"(packed.w)
                 : "l"(source) : "memory");
  }
  return packed;
}

template <bool produce_v, typename KTraits, typename SmemStorage>
__device__ __forceinline__ void hyle_overlap_probe_publish(
    SmemStorage* storage, typename KTraits::DTypeKV* kv_ptr,
    const size_t* next_offset, uint32_t next_base, uint32_t chunk_size,
    uint32_t warp_idx, uint32_t lane_idx, b128_t packed) {
  static_assert(hyle_overlap_probe_scope<KTraits>);
  constexpr auto fill_mode = produce_v ? SharedMemFillMode::kFillZero
                                       : SharedMemFillMode::kNoFill;
  const uint32_t row = warp_idx * 4 + lane_idx / 8;
  const bool valid = next_base + row < chunk_size;
  if (!valid && !produce_v) return;
  smem_t<KTraits::SWIZZLE_MODE_KV> smem(produce_v ? storage->v_smem : storage->k_smem);
  alignas(16) typename KTraits::DTypeQ converted[16];
  vec_cast<typename KTraits::DTypeQ, typename KTraits::DTypeKV>::template cast<16>(
      converted, reinterpret_cast<typename KTraits::DTypeKV*>(&packed));
  constexpr uint32_t stride = 256 / upcast_size<typename KTraits::DTypeQ>();
  const uint32_t col = lane_idx % 8;
  smem.base[get_permuted_offset<KTraits::SWIZZLE_MODE_KV, stride>(row, 2 * col)] =
      *reinterpret_cast<b128_t*>(converted);
  smem.base[get_permuted_offset<KTraits::SWIZZLE_MODE_KV, stride>(row, 2 * col + 1)] =
      *reinterpret_cast<b128_t*>(converted + 8);
  // Preserve original kNoFill / V-zero-fill semantics and second vector read.
  hyle_load_fp8_native_stage<fill_mode, KTraits, 256>(
      smem, kv_ptr + next_offset[0] + 128, row, col + 8, valid);
}

'''
helper_anchor = 'template <bool produce_v, SharedMemFillMode fill_mode, typename KTraits, bool DirectStage = false>'
assert original.count(helper_anchor) == 1
base = original.replace(helper_anchor, helpers + helper_anchor)
start = base.index('__device__ __forceinline__ void BatchPrefillWithPagedKVCacheDevice(')
end = base.index('__global__ __launch_bounds__(KTraits::NUM_THREADS) void BatchPrefillWithPagedKVCacheKernel(', start)
prefix, region, suffix = base[:start], base[start:end], base[end:]

def change_once(text, old, new):
    assert text.count(old) == 1, (text.count(old), old[:120])
    return text.replace(old, new, 1)

def load_code(kind):
    return f'''        [[maybe_unused]] b128_t overlap_{kind}_first{{}};
        if constexpr (hyle_overlap_probe_scope<KTraits>) {{
          const uint32_t row = warp_idx * 4 + lane_idx / 8;
          overlap_{kind}_first = hyle_overlap_probe_load(
              paged_kv.{kind}_data + thr_local_kv_offset_{kind}[0],
              (iter + 1) * CTA_TILE_KV + row < chunk_size);
        }}
'''

old_k = '''          page_produce_kv<false, KTraits>(&smem_storage, &k_smem_offset_w, paged_kv.k_data,
                                          (iter + 1) * CTA_TILE_KV, thr_local_kv_offset_k,
                                          chunk_size, warp_idx, lane_idx);'''
old_v = '''          page_produce_kv<true, KTraits>(&smem_storage, &v_smem_offset_w, paged_kv.v_data,
                                         (iter + 1) * CTA_TILE_KV, thr_local_kv_offset_v,
                                         chunk_size, warp_idx, lane_idx);'''

manifest = {'state': 'SOURCE_ONLY_NOT_COMPILED_NOT_EXECUTED', 'gpu_executed': False,
            'canonical_product_changed': False, 'control_prefill_sha256': sha(raw),
            'scope': 'paged / BF16 Q / E4M3 KV / F32 partial / D256 / CTA64 / KV-MMA1 / 4x1 warps',
            'variants': {}}
for name, use_k, use_v in [('k-only', True, False), ('v-only', False, True), ('both', True, True)]:
    text = region
    if use_k:
        anchor = '        // compute m,d states in online softmax\n'
        text = change_once(text, anchor, load_code('k') + anchor)
        replacement = '''          if constexpr (hyle_overlap_probe_scope<KTraits>) {
            hyle_overlap_probe_publish<false, KTraits>(
                &smem_storage, paged_kv.k_data, thr_local_kv_offset_k,
                (iter + 1) * CTA_TILE_KV, chunk_size, warp_idx, lane_idx, overlap_k_first);
          } else {
''' + old_k + '\n          }'
        text = change_once(text, old_k, replacement)
    if use_v:
        anchor = '        // compute sfm*v\n'
        text = change_once(text, anchor, load_code('v') + anchor)
        replacement = '''          if constexpr (hyle_overlap_probe_scope<KTraits>) {
            hyle_overlap_probe_publish<true, KTraits>(
                &smem_storage, paged_kv.v_data, thr_local_kv_offset_v,
                (iter + 1) * CTA_TILE_KV, chunk_size, warp_idx, lane_idx, overlap_v_first);
          } else {
''' + old_v + '\n          }'
        text = change_once(text, old_v, replacement)
    candidate = prefix + text + suffix
    path = OUT / f'prefill-{name}.cuh'
    path.write_bytes(candidate.encode('utf-8'))
    diff = ''.join(difflib.unified_diff(original.splitlines(True), candidate.splitlines(True),
                                       fromfile='control/prefill.cuh', tofile=f'{name}/prefill.cuh'))
    patch = OUT / f'overlap-{name}.patch'
    patch.write_bytes(diff.encode('utf-8'))
    manifest['variants'][name] = {'source': str(path), 'source_sha256': sha(path.read_bytes()),
                                 'patch': str(patch), 'patch_sha256': sha(patch.read_bytes())}
(OUT / 'overlap-source.json').write_text(json.dumps(manifest, indent=2) + '\n', encoding='utf-8')
print(json.dumps(manifest, indent=2))
