from pathlib import Path
import hashlib
import json

root=Path(__file__).resolve().parents[2]
out=Path(__file__).resolve().parent
old=root/'.scratch/g04-factorial-fulltu'
text=(old/'consumer.cc').read_text(encoding='utf-8')
prefix=text[:text.index('using Clock=std::chrono::steady_clock;')]
prefix=prefix.replace('#include "bindings.h"','#include "bindings.h"\n#include "native_bindings.h"\n#include <sstream>\n#include <unordered_map>')
maps=json.loads((old/'object-identity.json').read_text(encoding='utf-8'))['arms']
signature='const void*,hyle::compute::flashinfer::native::BatchSpec,const void*,const void*,const void*,const void*,void*,void*,void*,cudaStream_t'
header='#pragma once\n#include "bindings.h"\n'
symbols={}
for arm in ['00','01','10','11','orig']:
    matched=[(k,v) for k,v in maps[arm]['mapping'].items() if '15run_cache_batchE' in k]
    assert len(matched)==1, (arm,matched)
    symbols[arm]=matched[0][1]
    header+=f'cudaError_t native_{arm}({signature}) asm("{matched[0][1]}");\n'
header+=f'using NativeRun=cudaError_t(*)({signature});\n'
header+='inline constexpr NativeRun native_runs[]{&native_00,&native_01,&native_10,&native_11,&native_orig};\n'
(out/'native_bindings.h').write_bytes(header.encode('utf-8'))
tail=(out/'driver_tail.cc').read_text(encoding='utf-8')
(out/'consumer.cc').write_bytes((prefix+tail).encode('utf-8'))
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
identity={'state':'HOST_ONLY_SOURCE_PREPARED_NO_GPU','gpu_executed':False,
          'base_consumer_sha256':sha(old/'consumer.cc'),'factor_record_sha256':sha(old/'factor_record.h'),
          'native_source_sha256':sha(old/'native_cache.cu'),'object_identity_sha256':sha(old/'object-identity.json'),
          'consumer_sha256':sha(out/'consumer.cc'),'native_bindings_sha256':sha(out/'native_bindings.h'),
          'run_cache_batch_symbols':symbols,'source_owner':'one 00 Harness and retained first output lease',
          'input_identity':'all arms receive one copied 00 FactorReplayRecord, including identical state/spec/Q/FP8KV/metadata/output/workspaces/stream; 10/11 share one cold unscaled BF16 KV snapshot',
          'diagnostic':'native attention+merge CUDAgraph GPU event cost; not public complete latency'}
(out/'source-identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8')
print(json.dumps(identity,indent=2))
