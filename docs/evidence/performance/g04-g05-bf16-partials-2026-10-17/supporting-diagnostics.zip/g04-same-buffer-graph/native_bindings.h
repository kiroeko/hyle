#pragma once
#include "bindings.h"
cudaError_t native_00(const void*,hyle::compute::flashinfer::native::BatchSpec,const void*,const void*,const void*,const void*,void*,void*,void*,cudaStream_t) asm("g04f_00__ZN4hyle7compute10flashinfer6native15run_cache_batchEPKvNS2_9BatchSpecES4_S4_S4_S4_PvS6_S6_P11CUstream_st");
cudaError_t native_01(const void*,hyle::compute::flashinfer::native::BatchSpec,const void*,const void*,const void*,const void*,void*,void*,void*,cudaStream_t) asm("g04f_01__ZN4hyle7compute10flashinfer6native15run_cache_batchEPKvNS2_9BatchSpecES4_S4_S4_S4_PvS6_S6_P11CUstream_st");
cudaError_t native_10(const void*,hyle::compute::flashinfer::native::BatchSpec,const void*,const void*,const void*,const void*,void*,void*,void*,cudaStream_t) asm("g04f_10__ZN4hyle7compute10flashinfer6native15run_cache_batchEPKvNS2_9BatchSpecES4_S4_S4_S4_PvS6_S6_P11CUstream_st");
cudaError_t native_11(const void*,hyle::compute::flashinfer::native::BatchSpec,const void*,const void*,const void*,const void*,void*,void*,void*,cudaStream_t) asm("g04f_11__ZN4hyle7compute10flashinfer6native15run_cache_batchEPKvNS2_9BatchSpecES4_S4_S4_S4_PvS6_S6_P11CUstream_st");
cudaError_t native_orig(const void*,hyle::compute::flashinfer::native::BatchSpec,const void*,const void*,const void*,const void*,void*,void*,void*,cudaStream_t) asm("g04f_orig__ZN4hyle7compute10flashinfer6native15run_cache_batchEPKvNS2_9BatchSpecES4_S4_S4_S4_PvS6_S6_P11CUstream_st");
using NativeRun=cudaError_t(*)(const void*,hyle::compute::flashinfer::native::BatchSpec,const void*,const void*,const void*,const void*,void*,void*,void*,cudaStream_t);
inline constexpr NativeRun native_runs[]{&native_00,&native_01,&native_10,&native_11,&native_orig};
