from pathlib import Path
import hashlib
import json
import shutil
import subprocess
import time

root=Path('/mnt/c/public/project-hyle/hyle')
out=root/'.scratch/g04-same-buffer-graph'
base=Path('/root/hyle-scratch/compute-unified/g04-factorial-fulltu')
work=Path('/root/hyle-scratch/compute-unified/g04-same-buffer-graph')
work.mkdir(exist_ok=True)
for name in ['consumer.cc','native_bindings.h']:
    shutil.copy2(out/name,work/name)
old=json.loads((base/'commands.json').read_text())
compile=[str(work/'consumer.cc') if x==str(base/'consumer.cc') else str(work/'consumer.o') if x==str(base/'consumer.o') else x for x in old['compile']]
compile.insert(1,'-I'+str(work))
link=[str(work/'consumer.o') if x==str(base/'consumer.o') else str(work/'same_buffer_graph') if x==str(base/'factorial') else '-Wl,-Map='+str(work/'link.map') if x=='-Wl,-Map='+str(base/'link.map') else x for x in old['link']]
commands={'compile':compile,'link':link}
(out/'commands.json').write_text(json.dumps(commands,indent=2)+'\n')
(work/'commands.json').write_text(json.dumps(commands,indent=2)+'\n')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
result={'state':'HOST_BUILD_RUNNING_NO_GPU','gpu_executed':False,'work':str(work),'stages':[],
        'inputs':{str(p):sha(p) for p in [out/'consumer.cc',out/'native_bindings.h',base/'factor_record.h',base/'object-identity.json']}}
for stage,args in commands.items():
    t=time.monotonic()
    with (out/f'{stage}.log').open('w') as f:
        p=subprocess.run(args,stdout=f,stderr=subprocess.STDOUT,timeout=120)
    result['stages'].append({'stage':stage,'exit':p.returncode,'seconds':time.monotonic()-t})
    print(stage,result['stages'][-1],flush=True)
    if p.returncode:
        result['state']='HOST_BUILD_FAIL_NO_GPU';(out/'build.json').write_text(json.dumps(result,indent=2)+'\n');print((out/f'{stage}.log').read_text()[-12000:]);raise SystemExit(p.returncode)
result.update(state='HOST_BUILD_PASS_NO_GPU',binary=str(work/'same_buffer_graph'),binary_sha256=sha(work/'same_buffer_graph'))
(out/'build.json').write_text(json.dumps(result,indent=2)+'\n')
shutil.copy2(work/'link.map',out/'link.map')
print(json.dumps(result,indent=2))
