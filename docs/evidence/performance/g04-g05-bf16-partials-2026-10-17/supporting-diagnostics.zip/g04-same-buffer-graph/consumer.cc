#if defined(_MSC_VER)
#define _CRT_SECURE_NO_WARNINGS
#endif
#include "cuda_encoded_page_reference.h"
#include "hyle/compute/backends/cuda.h"
#include "hyle/compute/providers/flashinfer.h"

#include "hyle/compute/batch_execution.h"
#include "hyle/simd/dtype.h"
#include <cstring>
#include <cuda_runtime_api.h>
#include <sched.h>
#include <array>
#include <algorithm>
#include <bit>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <chrono>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <memory>
#include <string>
#include <vector>
#include <nvtx3/nvToolsExt.h>

#include "bindings.h"
#include "native_bindings.h"
#include <sstream>
#include <unordered_map>
namespace {
#ifndef HYLE_RESIDENT_PLACEMENT
#define HYLE_RESIDENT_PLACEMENT 0
#endif
namespace c=hyle::compute;
bool diagnostic_trace=false;
void push(const char *s){if(diagnostic_trace)nvtxRangePushA(s);}
void pop(){if(diagnostic_trace)nvtxRangePop();}
[[noreturn]] void fail(hyle::Status status){std::fprintf(stderr,"CUDA encoded: %.*s\n",int(status.message().size()),status.message().data());std::exit(2);}
void check(hyle::Status status){if(!status.ok())fail(status);}
template<class T>T take(hyle::Result<T> value){if(!value)fail(value.error());return std::move(*value);}
bool set(const char *name){const auto *p=std::getenv(name);return p&&*p;}
float decode(std::uint16_t x){return std::bit_cast<float>(std::uint32_t(x)<<16);}
std::uint16_t encode(float x){return std::uint16_t(std::bit_cast<std::uint32_t>(x)>>16);}
double fp8(std::uint8_t code){const unsigned e=(code&127)>>3,m=code&7;
  const double value=e?std::ldexp(1.+double(m)/8.,int(e)-7):std::ldexp(double(m)/8.,-6);
  return code&128?-value:value;
}
struct Data {
  c::BatchCapacity capacity;
  std::array<std::int32_t,3> qp,kp;
  std::vector<std::int32_t> ids;std::array<std::int32_t,2> tails;
  std::vector<std::uint16_t> query;
  std::array<std::vector<std::byte>,2> packed;
  std::array<std::vector<float>,2> decoded;
  float scale;bool causal;std::int32_t window;
  Data(int q1,int q2,int k1,int k2,int dk,int dv,bool masked,int left):
    capacity{.storage=c::BatchStorage::kPaged,.query_type=c::DataType::kBFloat16,
      .output_type=c::DataType::kBFloat16,.key_storage=c::CacheStorage::float8(.5F).value(),
      .value_storage=c::CacheStorage::float8(2.F).value(),.max_requests=2,
      .max_query_rows=unsigned(q1+q2+3),.max_kv_rows=unsigned(k1+k2+13),
      .max_pages=unsigned((k1+15)/16+(k2+15)/16+2),.max_page_refs=unsigned((k1+15)/16+(k2+15)/16),
      .query_heads=8,.kv_heads=2,.qk_head_dim=unsigned(dk),.value_head_dim=unsigned(dv),.page_size=16},
    qp{0,q1,q1+q2},kp{0,(k1+15)/16,(k1+15)/16+(k2+15)/16},
    scale(1.F/std::sqrt(float(dk))),causal(masked),window(left){
    tails={(k1-1)%16+1,(k2-1)%16+1};
    for(unsigned i=0;i<capacity.max_page_refs;++i)ids.push_back(static_cast<std::int32_t>(capacity.max_pages-1-i));
    ids[static_cast<unsigned>(kp[1])]=ids[0];
    query.resize(std::size_t(capacity.max_query_rows)*8*dk);
    for(std::size_t i=0;i<query.size();++i)query[i]=encode(.125F+float((i/dk)%8%3)*.015625F);
    for(unsigned port=0;port<2;++port){
      const auto depth=port?dv:dk;
      auto &bytes=packed[port];auto &values=decoded[port];
      values.resize(std::size_t(capacity.max_pages)*16*2*depth);
      bytes.resize(values.size());
      // Independent finite FP8 fixture; the oracle decodes these actual bytes.
      for(std::size_t i=0;i<bytes.size();++i){
        const auto row=i/(2*depth),head=(i/depth)%2;
        constexpr std::uint8_t key_codes[]{0,56,64,68,72},value_codes[]{16,24,28,32,34};
        const auto code=(port?value_codes:key_codes)[(row+head)%5];
        bytes[i]=std::byte(code);values[i]=float(fp8(code)*(port?2.:.5));
      }
      for(unsigned page=0;page<capacity.max_pages;++page){
        unsigned valid=0;
        for(unsigned r=0;r<2;++r)for(auto ref=kp[r];ref<kp[r+1];++ref)
          if(ids[unsigned(ref)]==int(page))valid=std::max(valid,ref+1==kp[r+1]?unsigned(tails[r]):16u);
        for(auto i=std::size_t(page*16+valid)*2*depth;i<std::size_t((page+1)*16)*2*depth;++i){
          bytes[i]=std::byte(0x78);values[i]=float(fp8(0x78)*(port?2.:.5));
        }
      }
    }
  }
  std::size_t row_bytes(unsigned port)const{return std::size_t(2)*(port?capacity.value_head_dim:capacity.qk_head_dim);}
  std::vector<double> oracle()const{
    const auto dk=capacity.qk_head_dim,dv=capacity.value_head_dim;
    std::vector<double> output(std::size_t(qp[2])*8*dv),weights;double uniform_difference=0;
    for(unsigned r=0;r<2;++r){const int nq=qp[r+1]-qp[r],nk=(kp[r+1]-kp[r]-1)*16+tails[r];weights.resize(nk);
      for(int row=0;row<nq;++row)for(unsigned h=0;h<8;++h){double sum=0;
        const auto position=nk-nq+row;
        for(int j=0;j<nk;++j){
          if(causal&&(j>position||(window>=0&&j<std::max(0,position-window)))){weights[j]=0;continue;}
          double dot=0;for(unsigned d=0;d<dk;++d)dot+=double(decode(query[(std::size_t(qp[r]+row)*8+h)*dk+d]))*
              decoded[0][((std::size_t(ids[static_cast<unsigned>(kp[r]+j/16)])*16+j%16)*2+h/4)*dk+d];
          weights[j]=std::exp(dot*scale);sum+=weights[j];
        }
        for(unsigned d=0;d<dv;++d)for(int j=0;j<nk;++j)output[(std::size_t(qp[r]+row)*8+h)*dv+d]+=
            weights[j]/sum*decoded[1][((std::size_t(ids[static_cast<unsigned>(kp[r]+j/16)])*16+j%16)*2+h/4)*dv+d];
        double uniform=0;unsigned eligible=0;
        for(int j=0;j<nk;++j)if(weights[j]>0){++eligible;
          uniform+=decoded[1][((std::size_t(ids[unsigned(kp[r]+j/16)])*16+j%16)*2+h/4)*dv];}
        uniform_difference=std::max(uniform_difference,std::abs(
            output[(std::size_t(qp[r]+row)*8+h)*dv]-uniform/eligible));
      }
    }
    if(uniform_difference<=.01)fail(hyle::Status::Internal("FP8 oracle fixture cannot distinguish missing QK loads"));
    std::fprintf(stderr,"# CUDA_ENCODED_ORACLE uniform_difference=%.9g\n",uniform_difference);
    return output;
  }
};
struct Harness {
  unsigned arm_id=0;
  std::unique_ptr<hyle::bench::resident::CudaEncodedReferenceData> reference;
  std::array<hyle::mem::Buffer,2> expanded;
  std::array<std::vector<std::uint16_t>,2> expanded_expected;
  c::Context context;c::cuda::MemoryResource memory,host;c::Queue queue;c::BatchSchema schema;c::BatchLayoutVersion layout;
  c::BatchProgram program;std::array<c::BatchInvocation,2> slots;c::LeasePool pool;
  c::PagedArena keys,values;c::PagedArenaRead key_frame,value_frame;
  std::vector<c::ReadLease> key_pages,value_pages;std::vector<unsigned> physical_ids;c::ReadLease query;std::size_t next=0;
  Harness(const Data &data,unsigned arm):arm_id(arm){
    const bool original=arm==5;
    if(original)reference=std::make_unique<hyle::bench::resident::CudaEncodedReferenceData>();
    context=take(c::Context::create(take(c::cuda::device(0)),original?peer_provider(reference.get()):bindings[arm].provider()));
    const auto env=take(c::cuda::environment(context));
    if(env.sm_major!=8||env.sm_minor!=9)fail(hyle::Status::Unimplemented("finite actual SM89 profile"));
    std::fprintf(stderr,"# CUDA_ENCODED_ENV device=%s sm=%d%d driver=%s runtime=%d toolkit=%d original=%d\n",
        env.device_name.data(),env.sm_major,env.sm_minor,env.driver_release.data(),env.runtime_version,env.build_toolkit_version,original);
    memory=take(c::cuda::MemoryResource::create(context,c::cuda::MemoryKind::kDevice));
    host=take(c::cuda::MemoryResource::create(context,c::cuda::MemoryKind::kPinnedHost));
    queue=take(context.create_queue());
    schema=take(c::BatchSchema::create(data.capacity));layout=take(schema.version({data.qp,data.kp,data.ids,data.tails}));
    const auto key_bytes=16*data.row_bytes(0),value_bytes=16*data.row_bytes(1);
    keys=take(c::PagedArena::create(schema,c::BatchCacheRole::kKey,memory.ref(),{.max_backing_bytes=key_bytes*data.capacity.max_pages+1}));
    values=take(c::PagedArena::create(schema,c::BatchCacheRole::kValue,memory.ref(),{.max_backing_bytes=value_bytes*data.capacity.max_pages+1}));
    for(unsigned page=0;page<data.capacity.max_pages;++page)if(std::find(data.ids.begin(),data.ids.end(),static_cast<std::int32_t>(page))!=data.ids.end()){
      auto kw=take(keys.acquire(page)),vw=take(values.acquire(page));
      check(kw.lease().view()->write(std::span(data.packed[0]).subspan(page*key_bytes,key_bytes)));
      check(vw.lease().view()->write(std::span(data.packed[1]).subspan(page*value_bytes,value_bytes)));
      physical_ids.push_back(page);key_pages.push_back(take(kw.publish(16)));value_pages.push_back(take(vw.publish(16)));
    }
    key_frame=take(keys.read(layout,key_pages));value_frame=take(values.read(layout,value_pages));
    if(original)check(peer_prepare(*reference,queue,layout,key_frame,value_frame,memory.ref()));
    const bool primary=data.capacity.qk_head_dim==256 && data.capacity.value_head_dim==256 && data.causal && data.window==-1;
    if(primary && (arm==2 || arm==3))for(unsigned port=0;port<2;++port){
      auto &raw=expanded_expected[port];raw.resize(data.packed[port].size());
      for(std::size_t i=0;i<raw.size();++i){const float value=float(fp8(std::to_integer<std::uint8_t>(data.packed[port][i])));raw[i]=encode(value);if(decode(raw[i])!=value)fail(hyle::Status::Internal("cold raw FP8 expansion was not exact BF16"));}
      expanded[port]=take(hyle::mem::Buffer::create(memory.ref(),raw.size()*2,256));
      check(expanded[port].view().write(std::as_bytes(std::span(raw))));
    }

    program=take(c::BatchProgram::prepare(context,schema,{.resource=memory.ref(),.host_workspace=host.ref(),
        .max_float_workspace_bytes=32u<<20,.max_int_workspace_bytes=4096,.scale=data.scale,.causal=data.causal,.window_left=data.window}));
    for(auto &slot:slots){slot=take(c::BatchInvocation::create(program,queue));auto prepared=take(slot.prepare_batch(layout));}
    pool=take(c::LeasePool::create(memory.ref(),data.query.size()*2+2048));
    auto writer=take(pool.allocate(data.query.size()*2));check(writer.view()->write(std::as_bytes(std::span(data.query))));query=take(writer.publish());
    if(arm<4){const void *k=nullptr,*v=nullptr;if(!expanded_expected[0].empty()){k=take(c::cuda::pointer<std::uint16_t>(expanded[0].view()));v=take(c::cuda::pointer<std::uint16_t>(expanded[1].view()));}bindings[arm].configure(arm>=2,(arm&1)!=0,k,v);}
    std::fprintf(stderr,"# FACTOR_RESIDENCY arm=%s original_fp8_bytes=%zu extra_raw_bf16_bytes=%zu cold_exact_unscaled=1 snapshots_retained_through_drain=1\n",arm_names[arm],data.packed[0].size()+data.packed[1].size(),expanded[0].size()+expanded[1].size());
    std::fprintf(stderr,"# CUDA_ENCODED_COLD original=%d known_float_bytes=%zu known_int_bytes=%zu tile=%u split=%d private_pool_upper=UNKNOWN requests=2 immutable_history=1\n",original,slots[0].report().float_workspace_bytes,slots[0].report().int_workspace_bytes,slots[0].report().cta_tile_q,slots[0].report().split_kv);
  }
  ~Harness(){const auto start=std::chrono::steady_clock::now();
    for(auto &slot:slots){check(slot.close());slot={};}
    program={};query.reset();pool={};key_frame={};value_frame={};
    key_pages.clear();value_pages.clear();keys={};values={};
    check(queue.drain());expanded={};reference.reset();queue={};host.reset();memory.reset();check(context.close());
    std::fprintf(stderr,"# CUDA_ENCODED_TEARDOWN seconds=%.9f\n",
        std::chrono::duration<double>(std::chrono::steady_clock::now()-start).count());
  }
  c::ReadLease execute(){auto &slot=slots[next++%slots.size()];
    push("update");auto prepared=take(slot.update_batch(layout));pop();
    if(!slot.report().reused_native_plan)fail(hyle::Status::Internal("paged warm topology rebuilt"));
    push("admit_submit");auto completion=take(prepared.run(query,key_frame,value_frame));pop();
    push("checked_wait");check(completion.wait());pop();
    push("output_acquire");auto output=take(slot.output());pop();return output;}
  std::vector<std::uint16_t> verify(const Data &data,const std::vector<double> &expected){auto output=execute();std::vector<std::uint16_t> actual(std::size_t(data.capacity.max_query_rows)*8*data.capacity.value_head_dim);check(output.view()->read(std::as_writable_bytes(std::span(actual))));
    double worst=0;for(std::size_t i=0;i<expected.size();++i){if(!std::isfinite(decode(actual[i])))fail(hyle::Status::Internal("paged nonfinite output"));worst=std::max(worst,std::abs(double(decode(actual[i]))-expected[i]));}
    if(worst>8e-3)fail(hyle::Status::Internal("paged independent double oracle exceeded 8e-3"));
    for(unsigned port=1;port<3;++port)for(unsigned index=0;index<key_pages.size();++index){const auto &lease=port==1?key_pages[index]:value_pages[index];auto view=take(lease.view());
      std::vector<std::byte> after(view.size());check(view.read(after));
      const auto first=data.packed[port-1].begin()+std::size_t(physical_ids[index])*16*data.row_bytes(port-1);
      if(!std::equal(after.begin(),after.end(),first))fail(hyle::Status::Internal("paged readonly KV changed"));
    }
    for(unsigned port=0;port<2;++port)if(!expanded_expected[port].empty()){
      std::vector<std::uint16_t> after(expanded_expected[port].size());check(expanded[port].view().read(std::as_writable_bytes(std::span(after))));
      if(after!=expanded_expected[port])fail(hyle::Status::Internal("cold BF16 snapshot changed"));
    }
    std::fprintf(stderr,"# CUDA_ENCODED_CORRECTNESS max_abs_error=%.9g elements=%zu\n",worst,expected.size());return actual;
  }
};


void cuda_check(cudaError_t status,const char *where){
  if(status!=cudaSuccess){std::fprintf(stderr,"CUDA_FAIL where=%s error=%s code=%d\n",where,cudaGetErrorString(status),int(status));std::exit(3);}
}
void require(bool condition,const char *message){if(!condition){std::fprintf(stderr,"ASSERT_FAIL %s\n",message);std::exit(4);}}
std::string hex_bytes(const void *value,std::size_t bytes){
  static constexpr char digits[]="0123456789abcdef";
  std::string result;result.reserve(bytes*2);const auto *p=static_cast<const unsigned char*>(value);
  for(std::size_t i=0;i<bytes;++i){result+=digits[p[i]>>4];result+=digits[p[i]&15];}return result;
}
struct KernelSnapshot {
  unsigned grid[3]{},block[3]{},shared=0;
  std::vector<std::string> values;
  std::vector<std::size_t> offsets,sizes;
};
struct Graph {
  cudaGraph_t graph=nullptr;cudaGraphExec_t executable=nullptr;
  std::array<KernelSnapshot,2> first;
  void close(){
    if(executable){cuda_check(cudaGraphExecDestroy(executable),"graph exec destroy");}
    executable=nullptr;
    if(graph){cuda_check(cudaGraphDestroy(graph),"graph destroy");}
    graph=nullptr;
  }
};
bool semantic_equal(unsigned kind,const KernelSnapshot &a,const KernelSnapshot &b){
  require(a.offsets==b.offsets && a.sizes==b.sizes,"kernel argument ABI changed");
  if(kind==1){
    require(a.sizes==std::vector<std::size_t>{8,8,8,8,8,4,8,4,4},"merge argument widths changed");
    return a.values==b.values;
  }
  require(a.sizes==std::vector<std::size_t>{376},"attention struct layout differs from reviewed locked Linux64 ABI");
  // Locked PagedBase360 + final_output@360/final_scale@368; exclude only
  // reviewed padding. Preserve full raw bytes in GRAPH_PARAM for inspection.
  constexpr unsigned intervals[][2]{{0,244},{248,308},{312,325},{328,348},{352,372}};
  for(const auto &range:intervals)for(unsigned byte=range[0];byte<range[1];++byte){
    if(a.values[0].compare(byte*2,2,b.values[0],byte*2,2)!=0)return false;
  }
  return true;
}
void native_call(unsigned arm,const FactorRecord &record){
  cuda_check(native_runs[arm](record.state,record.spec,record.q,record.k,record.v,record.metadata,
      record.output,record.floating,record.integer,record.stream),"same-record run_cache_batch");
}
void inspect_graph(Graph &graph,unsigned arm,unsigned repeats){
  std::size_t count=0;cuda_check(cudaGraphGetNodes(graph.graph,nullptr,&count),"graph node count");
  require(count==2*repeats,"native graph must have exactly attention+merge per repeat");
  std::vector<cudaGraphNode_t> nodes(count);cuda_check(cudaGraphGetNodes(graph.graph,nodes.data(),&count),"graph nodes");
  std::unordered_map<cudaGraphNode_t,cudaGraphNode_t> successors;
  cudaGraphNode_t first=nullptr;
  for(auto node:nodes){cudaGraphNodeType type;cuda_check(cudaGraphNodeGetType(node,&type),"node type");
    require(type==cudaGraphNodeTypeKernel,"native capture contains non-kernel work");
    std::size_t dependencies=0;cuda_check(cudaGraphNodeGetDependencies(node,nullptr,nullptr,&dependencies),"dependencies count");
    if(dependencies==0){require(first==nullptr,"multiple graph roots");first=node;}
    else{require(dependencies==1,"native serial chain must have one dependency");cudaGraphNode_t parent=nullptr;
      cuda_check(cudaGraphNodeGetDependencies(node,&parent,nullptr,&dependencies),"graph dependency");
      require(successors.emplace(parent,node).second,"native graph branched");}
  }
  auto node=first;
  for(unsigned index=0;index<count;++index){require(node!=nullptr,"broken native chain");
    cudaKernelNodeParams params{};cuda_check(cudaGraphKernelNodeGetParams(node,&params),"kernel node params");
    const unsigned kind=index%2;KernelSnapshot snapshot;
    snapshot.grid[0]=params.gridDim.x;snapshot.grid[1]=params.gridDim.y;snapshot.grid[2]=params.gridDim.z;
    snapshot.block[0]=params.blockDim.x;snapshot.block[1]=params.blockDim.y;snapshot.block[2]=params.blockDim.z;
    snapshot.shared=params.sharedMemBytes;
    require(params.kernelParams!=nullptr && params.extra==nullptr,"expected typed native argument array");
    const unsigned arguments=kind==0?1:9;
    for(unsigned argument=0;argument<arguments;++argument){std::size_t offset=0,size=0;
      cuda_check(cudaFuncGetParamInfo(params.func,argument,&offset,&size),"native parameter layout");
      snapshot.offsets.push_back(offset);snapshot.sizes.push_back(size);
      snapshot.values.push_back(hex_bytes(params.kernelParams[argument],size));
    }
    if(index<2){graph.first[kind]=snapshot;
      std::printf("GRAPH_NODE arm=%s kind=%s repeats=%u grid=%u,%u,%u block=%u,%u,%u shared=%u func=%p args=%u\n",
          arm_names[arm],kind?"merge":"attention",repeats,snapshot.grid[0],snapshot.grid[1],snapshot.grid[2],
          snapshot.block[0],snapshot.block[1],snapshot.block[2],snapshot.shared,params.func,arguments);
      for(unsigned argument=0;argument<arguments;++argument)std::printf("GRAPH_PARAM arm=%s kind=%u argument=%u offset=%zu bytes=%zu value_hex=%s\n",
          arm_names[arm],kind,argument,snapshot.offsets[argument],snapshot.sizes[argument],snapshot.values[argument].c_str());
    }else{const auto &a=graph.first[kind];
      require(std::equal(std::begin(a.grid),std::end(a.grid),snapshot.grid) && std::equal(std::begin(a.block),std::end(a.block),snapshot.block) && a.shared==snapshot.shared,"repeat launch geometry changed");
      // Full raw bytes are reported below for 00/orig. Repeat padding can be
      // stack-dependent; it is not silently treated as a semantic parameter.
      if(a.values!=snapshot.values)std::printf("GRAPH_REPEAT_RAW_DIFF arm=%s node=%u note=raw_struct_padding_or_field_difference_requires_review\n",arm_names[arm],index);
      require(semantic_equal(kind,a,snapshot),"repeat semantic kernel params changed");
    }
    auto next=successors.find(node);node=next==successors.end()?nullptr:next->second;
  }
  require(node==nullptr,"graph chain had extra nodes");
  cuda_check(cudaGraphInstantiateWithFlags(&graph.executable,graph.graph,0),"graph instantiate");
}
void verify_output(const Data &data,const std::vector<double> &expected,const FactorRecord &record,unsigned arm,const char *stage){
  std::vector<std::uint16_t> values(expected.size());
  cuda_check(cudaMemcpyAsync(values.data(),record.output,values.size()*sizeof(std::uint16_t),cudaMemcpyDeviceToHost,record.stream),"native output read");
  cuda_check(cudaStreamSynchronize(record.stream),"native oracle sync");
  double error=0;for(std::size_t i=0;i<values.size();++i){require(std::isfinite(decode(values[i])),"native output nonfinite");error=std::max(error,std::abs(double(decode(values[i]))-expected[i]));}
  require(error<=8e-3,"native graph output exceeded independent double oracle");
  std::printf("NATIVE_ORACLE arm=%s stage=%s max_abs_error=%.9g elements=%zu query_rows=%d\n",arm_names[arm],stage,error,values.size(),data.qp[2]);
}
void verify_readonly(const Data &data,Harness &owner,const std::array<hyle::mem::Buffer,2> &expanded,
                     const std::array<std::vector<std::uint16_t>,2> &expected){
  for(unsigned port=0;port<2;++port)for(unsigned index=0;index<owner.key_pages.size();++index){
    const auto &lease=port==0?owner.key_pages[index]:owner.value_pages[index];auto view=take(lease.view());
    std::vector<std::byte> after(view.size());check(view.read(after));
    const auto first=data.packed[port].begin()+std::size_t(owner.physical_ids[index])*16*data.row_bytes(port);
    require(std::equal(after.begin(),after.end(),first),"shared FP8 KV changed");
  }
  auto query_view=take(owner.query.view());std::vector<std::uint16_t> query(data.query.size());
  check(query_view.read(std::as_writable_bytes(std::span(query))));require(query==data.query,"shared Q changed");
  for(unsigned port=0;port<2;++port){std::vector<std::uint16_t> after(expected[port].size());
    check(expanded[port].view().read(std::as_writable_bytes(std::span(after))));require(after==expected[port],"shared unscaled BF16 snapshot changed");}
  std::printf("READONLY_PASS Q=1 original_FP8_KV=1 shared_unscaled_BF16_KV=1\n");
}
void compare_bridge(const Graph &a,const Graph &b){
  for(unsigned kind=0;kind<2;++kind){const auto &x=a.first[kind];const auto &y=b.first[kind];
    require(std::equal(std::begin(x.grid),std::end(x.grid),y.grid) && std::equal(std::begin(x.block),std::end(x.block),y.block) && x.shared==y.shared,"00/orig launch geometry differs");
    require(x.offsets==y.offsets && x.sizes==y.sizes,"00/orig kernel argument ABI differs");
    require(semantic_equal(kind,x,y),"00/orig semantic kernel params differ");
    unsigned differing_bytes=0;
    for(unsigned arg=0;arg<x.values.size();++arg)for(unsigned i=0;i<x.values[arg].size();i+=2)if(x.values[arg].substr(i,2)!=y.values[arg].substr(i,2)){
      ++differing_bytes;std::printf("BRIDGE_RAW_BYTE_DIFF kind=%u argument=%u byte=%u a=%s b=%s\n",kind,arg,i/2,x.values[arg].substr(i,2).c_str(),y.values[arg].substr(i,2).c_str());}
    std::printf("BRIDGE_PARAM_COMPARE kind=%u semantic_equal=1 raw_equal=%d differing_bytes=%u same_native_inputs=1 raw_padding_not_assumed_semantic=1\n",kind,differing_bytes==0,differing_bytes);
  }
}
void measure_graph_pair(const std::array<Graph,5> &graphs,const FactorRecord &record,unsigned a,unsigned b,unsigned repeats){
  constexpr unsigned groups=8,steps=8,samples=groups*steps*2;
  const unsigned pair[2]{a,b};std::array<cudaEvent_t,samples> starts{},stops{};
  for(unsigned i=0;i<samples;++i){cuda_check(cudaEventCreate(&starts[i]),"start event create");cuda_check(cudaEventCreate(&stops[i]),"stop event create");}
  for(unsigned i=0;i<8;++i)for(unsigned pos=0;pos<2;++pos)cuda_check(cudaGraphLaunch(graphs[pair[(i+pos)&1]].executable,record.stream),"paired graph warm");
  cuda_check(cudaStreamSynchronize(record.stream),"paired warm sync");
  diagnostic_trace=set("G04_TRACE");const auto label=std::string("same-buffer-")+arm_names[a]+"-"+arm_names[b];push(label.c_str());
  // Enqueue a whole balanced pair series before the sole final event wait.
  // No Completion, CPU logging, memcpy, oracle or per-graph host wait here.
  for(unsigned group=0;group<groups;++group)for(unsigned step=0;step<steps;++step)for(unsigned pos=0;pos<2;++pos){
    const unsigned index=(group*steps+step)*2+pos,side=(pos+step+group)&1,arm=pair[side];
    cuda_check(cudaEventRecord(starts[index],record.stream),"timed start record");
    cuda_check(cudaGraphLaunch(graphs[arm].executable,record.stream),"timed graph launch");
    cuda_check(cudaEventRecord(stops[index],record.stream),"timed stop record");
  }
  cuda_check(cudaEventSynchronize(stops.back()),"pair final event sync");pop();diagnostic_trace=false;
  std::array<std::array<double,2>,groups> sums{};
  for(unsigned group=0;group<groups;++group)for(unsigned step=0;step<steps;++step)for(unsigned pos=0;pos<2;++pos){
    const unsigned index=(group*steps+step)*2+pos,side=(pos+step+group)&1,arm=pair[side];float ms=0;
    cuda_check(cudaEventElapsedTime(&ms,starts[index],stops[index]),"event elapsed");const double total_us=double(ms)*1000.;sums[group][side]+=total_us/repeats;
    std::printf("GRAPH_SAMPLE pair=%s-%s group=%u step=%u position=%u arm=%s repeats=%u graph_us=%.9f native_us=%.9f\n",arm_names[a],arm_names[b],group,step,pos,arm_names[arm],repeats,total_us,total_us/repeats);
  }
  for(unsigned group=0;group<groups;++group)for(unsigned side=0;side<2;++side)std::printf("GRAPH_BLOCK pair=%s-%s group=%u arm=%s samples=%u native_mean_us=%.9f\n",arm_names[a],arm_names[b],group,arm_names[pair[side]],steps,sums[group][side]/steps);
  for(unsigned i=0;i<samples;++i){cuda_check(cudaEventDestroy(starts[i]),"start event destroy");cuda_check(cudaEventDestroy(stops[i]),"stop event destroy");}
}
void same_buffer_shape(bool tail,bool timed,unsigned repeats){
  Data data(64,128,tail?1023:1024,tail?767:768,256,256,true,-1);
  std::printf("SHAPE name=%s timed=%d\n",tail?"tail":"prefill",timed);
  auto owner=std::make_unique<Harness>(data,0);
  std::array<hyle::mem::Buffer,2> expanded;std::array<std::vector<std::uint16_t>,2> snapshot;
  std::array<const void*,2> snapshot_pointer{};
  for(unsigned port=0;port<2;++port){snapshot[port].resize(data.packed[port].size());
    for(std::size_t i=0;i<snapshot[port].size();++i){const auto value=float(fp8(std::to_integer<std::uint8_t>(data.packed[port][i])));snapshot[port][i]=encode(value);require(decode(snapshot[port][i])==value,"cold unscaled BF16 snapshot was inexact");}
    expanded[port]=take(hyle::mem::Buffer::create(owner->memory.ref(),snapshot[port].size()*2,256));
    check(expanded[port].view().write(std::as_bytes(std::span(snapshot[port]))));snapshot_pointer[port]=take(c::cuda::pointer<std::uint16_t>(expanded[port].view()));
  }
  for(unsigned arm=0;arm<4;++arm)bindings[arm].configure(arm>=2,(arm&1)!=0,snapshot_pointer[0],snapshot_pointer[1]);
  auto retained_output=owner->execute(); // The only public inference; outside capture/timing.
  const auto record=*bindings[0].get();
  require(record.ready && record.state && record.q && record.k && record.v && record.metadata && record.output && record.floating && record.integer,"00 record incomplete");
  require(record.spec.query_heads==8 && record.spec.kv_heads==2 && record.spec.qk_head_dim==256 && record.spec.value_head_dim==256 && record.spec.query_rows==192 && record.spec.key_scale==.5F && record.spec.value_scale==2.F,"00 BYVALUE BatchSpec drift");
  std::printf("SHARED_RECORD state=%p q=%p fp8k=%p fp8v=%p metadata=%p output=%p floating=%p integer=%p stream=%p raw_bf16k=%p raw_bf16v=%p retained_output=1\n",record.state,record.q,record.k,record.v,record.metadata,record.output,record.floating,record.integer,static_cast<void*>(record.stream),snapshot_pointer[0],snapshot_pointer[1]);
  std::printf("SHARED_SPEC bytes=%zu hex=%s query_heads=%u kv_heads=%u depth=256 rows=192 requests=%u scale=%.9g key_scale=%.9g value_scale=%.9g offsets=%zu,%zu,%zu,%zu\n",sizeof(record.spec),hex_bytes(&record.spec,sizeof(record.spec)).c_str(),record.spec.query_heads,record.spec.kv_heads,record.spec.requests,record.spec.scale,record.spec.key_scale,record.spec.value_scale,record.spec.query_indptr_offset,record.spec.kv_indptr_offset,record.spec.page_indices_offset,record.spec.tail_offset);
  cuda_check(bindings[0].dump("same-buffer-00"),"plan dump");check(owner->queue.drain());
  const auto expected=data.oracle();verify_output(data,expected,record,0,"public-first");
  std::array<Graph,5> graphs;
  for(unsigned arm=0;arm<5;++arm){native_call(arm,record);cuda_check(cudaStreamSynchronize(record.stream),"cold native warm sync");verify_output(data,expected,record,arm,"native-single");
    cuda_check(cudaStreamBeginCapture(record.stream,cudaStreamCaptureModeThreadLocal),"native capture begin");
    for(unsigned i=0;i<repeats;++i)native_call(arm,record);
    cuda_check(cudaStreamEndCapture(record.stream,&graphs[arm].graph),"native capture end");inspect_graph(graphs[arm],arm,repeats);
    cuda_check(cudaGraphLaunch(graphs[arm].executable,record.stream),"first graph replay");cuda_check(cudaStreamSynchronize(record.stream),"first graph sync");verify_output(data,expected,record,arm,"graph-first");
  }
  compare_bridge(graphs[0],graphs[4]);
  if(timed){constexpr unsigned pairs[][2]{{0,4},{0,2},{1,3},{0,1},{2,3},{0,3}};
    for(const auto &pair:pairs)measure_graph_pair(graphs,record,pair[0],pair[1],repeats);}
  for(unsigned arm=0;arm<5;++arm){cuda_check(cudaGraphLaunch(graphs[arm].executable,record.stream),"final oracle graph");cuda_check(cudaStreamSynchronize(record.stream),"final graph sync");verify_output(data,expected,record,arm,"graph-final");}
  verify_readonly(data,*owner,expanded,snapshot);
  // Finish device work before destroying graph executables or any input owner.
  cudaEvent_t last=nullptr;cuda_check(cudaEventCreate(&last),"last event create");cuda_check(cudaEventRecord(last,record.stream),"last event record");cuda_check(cudaEventSynchronize(last),"last event sync");
  for(auto &graph:graphs){graph.close();}
  cuda_check(cudaEventDestroy(last),"last event destroy");
  check(owner->queue.drain());retained_output.reset();expanded={};owner.reset();
  std::printf("NATIVE_GRAPH_SHAPE_DONE name=%s owners_after_last_event_and_graph_destroy=1 queue_drained=1\n",tail?"tail":"prefill");
}
}
int main(){
  cpu_set_t cpus;CPU_ZERO(&cpus);CPU_SET(2,&cpus);require(sched_setaffinity(0,sizeof(cpus),&cpus)==0,"CPU affinity");
  cuda_check(cudaSetDevice(0),"device0");
  constexpr unsigned repeats=64;
  std::printf("DIAGNOSTIC same_buffer=1 same_state_spec_workspace_stream=1 arms=00,01,10,11,orig repeats=64 groups=8 steps=8 active_timed_arms=2 balanced_AB_BA=1 graph_event_gpu_cost=1 public_complete_latency=0 per_graph_CPU_wait=0 no_timed_logging=1 trace=%d\n",set("G04_TRACE"));
  same_buffer_shape(false,true,repeats);same_buffer_shape(true,false,1);
  std::printf("EXIT code=0\n");return 0;
}
