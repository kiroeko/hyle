from pathlib import Path
import json, subprocess, time, hashlib, re
repo=Path('/mnt/c/public/project-hyle/hyle')
out=repo/'.scratch/g04-overlap-ab'
old=Path('/root/hyle-scratch/compute-unified/g04-same-process-ilp')
work=Path('/root/hyle-scratch/compute-unified/g04-overlap-ab')
overlap=Path('/root/hyle-scratch/compute-unified/g04-overlap-both-20261017/native_cache_overlap.o')
script=(repo/'.scratch/g04-same-process-ilp/prepare.py').read_text()
script=script[:script.index("src=(OLD/'bench/inference_resident_sdpa/cuda_encoded_page_bench.cc').read_text()")]
script=script.replace("ROOT=pathlib.Path('/root/hyle-scratch/compute-unified/g04-same-process-ilp')", "ROOT=pathlib.Path('/root/hyle-scratch/compute-unified/g04-overlap-ab')")
script=script.replace("OUT=pathlib.Path('/mnt/c/public/project-hyle/hyle/.scratch/g04-same-process-ilp')", "OUT=pathlib.Path('/mnt/c/public/project-hyle/hyle/.scratch/g04-overlap-ab')")
script=script.replace("OLD/f'native_cache_{arm}.o'", "OLD/'native_cache_control.o' if arm=='control' else pathlib.Path('/root/hyle-scratch/compute-unified/g04-overlap-both-20261017/native_cache_overlap.o')")
scope={};exec(compile(script,'validated-object-isolation','exec'),scope)
report=scope['report'];targets=scope['targets'];sha=scope['sha']
(work/'bench').mkdir()
source=(repo/'.scratch/g04-same-process-ilp/cuda_encoded_page_bench.cc').read_text()
source=source.replace('b.numRegs!=250','b.numRegs!=248').replace('original248/new250','original248/new248-overlap')
for arm in ['control','treatment']:
    source=re.sub(r'extern "C" void target_'+arm+r'\(\) asm\("[^"]+"\);',f'extern "C" void target_{arm}() asm("{targets[arm]}");',source)
(work/'bench/cuda_encoded_page_bench.cc').write_text(source)
(work/'bench/cuda_encoded_page_reference.h').write_bytes((old/'bench/cuda_encoded_page_reference.h').read_bytes())
report['consumer_sha256']=sha(work/'bench/cuda_encoded_page_bench.cc')
report['treatment_kind']='full TU original FP8/F32; first K/V packed vector prefetched across existing math; current registers248/no local'
report['treatment_original_full_tu_sha256']='62ace94e0809144aca540fa317f72e9a2bc2b1d29b5099ef15048d3da6b92858'
report['scope_and_codegen']=json.loads((repo/'.scratch/g04-g05-static-cost/overlap-compile.json').read_text())
commands=json.loads((old/'commands.json').read_text())
for stage in commands:
    commands[stage]=[arg.replace(str(old),str(work)) for arg in commands[stage]]
(work/'commands.json').write_text(json.dumps(commands,indent=2)+'\n')
(work/'identity.json').write_text(json.dumps(report,indent=2)+'\n')
result={}
for stage in ['compile','link']:
    start=time.monotonic()
    with (work/(stage+'.log')).open('w') as f:p=subprocess.run(commands[stage],stdout=f,stderr=subprocess.STDOUT)
    result[stage]={'exit':p.returncode,'seconds':time.monotonic()-start}
    if p.returncode:print((work/(stage+'.log')).read_text()[-6000:]);break
if all(x['exit']==0 for x in result.values()) and len(result)==2:
    linkmap=(work/'link.map').read_text()
    assert not re.search(r'libhyle_compute_provider_flashinfer\.a\((?:flashinfer_provider\.cc|native_batch\.cu|native_cache\.cu)\.o\)',linkmap)
    result['binary']={'path':str(work/'g04_same_process'),'sha256':sha(work/'g04_same_process')}
    result['original_archive_three_members_not_extracted']=True
(work/'build-result.json').write_text(json.dumps(result,indent=2)+'\n')
for name in ['bench/cuda_encoded_page_bench.cc','bench/cuda_encoded_page_reference.h','identity.json','commands.json','build-result.json','compile.log','link.log','link.map']:
    if (work/name).exists():(out/Path(name).name).write_bytes((work/name).read_bytes())
print(json.dumps(result,indent=2))
