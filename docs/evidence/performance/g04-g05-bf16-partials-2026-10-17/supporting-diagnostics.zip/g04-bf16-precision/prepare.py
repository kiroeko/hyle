from pathlib import Path
import json,subprocess,time,hashlib
repo=Path('/mnt/c/public/project-hyle/hyle');out=repo/'.scratch/g04-bf16-precision'
factor=Path('/root/hyle-scratch/compute-unified/g04-factorial-fulltu')
work=Path('/root/hyle-scratch/compute-unified/g04-bf16-precision');work.mkdir(exist_ok=True)
if (work/'compile.log').exists() and not (work/'compile-first-failure.log').exists():
  (work/'compile-first-failure.log').write_bytes((work/'compile.log').read_bytes())
  (out/'compile-first-failure.log').write_bytes((work/'compile.log').read_bytes())
source=(factor/'consumer.cc').read_text();source=source[:source.index('using Clock=')]
source=source.replace('bool set(const char *name)','[[maybe_unused]] bool set(const char *name)')
source+=r'''
double rounded_bf16(double v){auto u=std::bit_cast<std::uint32_t>(float(v));u+=0x7fff+((u>>16)&1);return double(decode(std::uint16_t(u>>16)));}
void precision_case(const char*name,std::uint8_t positive,std::uint8_t perturbed){
  Data data(64,128,8192,8192,256,256,true,-1);
  std::fill(data.query.begin(),data.query.end(),std::uint16_t{0});
  for(unsigned r=0;r<2;++r)for(unsigned row=0;row<8192;++row){
    const unsigned physical=unsigned(data.ids[unsigned(data.kp[r])+row/16])*16+row%16;
    const auto code=std::uint8_t(row<4096?(row%64==0?perturbed:positive):(positive|128));
    for(unsigned head=0;head<2;++head)for(unsigned d=0;d<256;++d){const auto i=(std::size_t(physical)*2+head)*256+d;
      data.packed[0][i]=std::byte{0};data.decoded[0][i]=0;
      data.packed[1][i]=std::byte(code);data.decoded[1][i]=float(fp8(code)*2.);
    }
  }
  std::vector<double> expected(std::size_t(data.qp[2])*8*256);
  for(unsigned r=0;r<2;++r){const unsigned nq=unsigned(data.qp[r+1]-data.qp[r]);
    std::vector<double> prefix(8193);
    for(unsigned j=0;j<8192;++j){const unsigned physical=unsigned(data.ids[unsigned(data.kp[r])+j/16])*16+j%16;
      prefix[j+1]=prefix[j]+data.decoded[1][std::size_t(physical)*2*256];}
    for(unsigned q=0;q<nq;++q){const unsigned last=8192-nq+q+1;const double mean=prefix[last]/last;
      for(unsigned h=0;h<8;++h)for(unsigned d=0;d<256;++d)expected[(std::size_t(data.qp[r])+q)*8*256+h*256+d]=mean;
    }
  }
  constexpr unsigned arms[]{0,1,5};
  std::array<std::unique_ptr<Harness>,3> h;
  for(unsigned arm=0;arm<3;++arm)h[arm]=std::make_unique<Harness>(data,arms[arm]);
  std::array<std::vector<std::uint16_t>,3> all;
  for(unsigned arm=0;arm<3;++arm){auto output=h[arm]->execute();
    if(h[arm]->slots[0].report().cta_tile_q!=64||!h[arm]->slots[0].report().split_kv)fail(hyle::Status::Internal("precision fixture did not reach target CTA64 split path"));
    all[arm].resize(std::size_t(data.capacity.max_query_rows)*8*256);
    check(output.view()->read(std::as_writable_bytes(std::span(all[arm]))));
    double abs=0,rel=0,round_error=0,sum=0;std::size_t worst=0;
    for(std::size_t i=0;i<expected.size();++i){const double a=decode(all[arm][i]);if(!std::isfinite(a))fail(hyle::Status::Internal("nonfinite precision output"));
      const double e=std::abs(a-expected[i]);if(e>abs){abs=e;worst=i;}sum+=e;
      if(std::abs(expected[i])>1e-12)rel=std::max(rel,e/std::abs(expected[i]));
      round_error=std::max(round_error,std::abs(a-rounded_bf16(expected[i])));
    }
    const auto index=expected.size()-1;
    std::printf("PRECISION case=%s arm=%s cta=64 split=1 rows=8192 queries=64,128 value_scale=2 period=64 elements=%zu max_abs=%.12g mean_abs=%.12g max_relative=%.12g max_vs_rounded_bf16_reference=%.12g worst_index=%zu worst_expected=%.12g worst_actual=%.12g final_expected=%.12g final_actual=%.12g\n",name,arm_names[arms[arm]],expected.size(),abs,sum/expected.size(),rel,round_error,worst,expected[worst],double(decode(all[arm][worst])),expected[index],double(decode(all[arm][index])));
  }
  double difference=0;for(std::size_t i=0;i<expected.size();++i)difference=std::max(difference,std::abs(double(decode(all[0][i]))-double(decode(all[1][i]))));
  std::printf("PRECISION_PAIR case=%s max_abs_bf16_minus_f32=%.12g\n",name,difference);
  double peer_difference=0;std::size_t peer_different=0;
  for(std::size_t i=0;i<expected.size();++i){peer_difference=std::max(peer_difference,std::abs(double(decode(all[1][i]))-double(decode(all[2][i]))));peer_different+=all[1][i]!=all[2][i];}
  std::printf("PRECISION_PEER case=%s max_abs_bf16_minus_peer=%.12g different_words=%zu elements=%zu\n",name,peer_difference,peer_different,expected.size());
  for(unsigned arm=0;arm<3;++arm)for(unsigned port=0;port<2;++port)for(unsigned j=0;j<h[arm]->key_pages.size();++j){
    const auto &lease=port?h[arm]->value_pages[j]:h[arm]->key_pages[j];auto view=take(lease.view());std::vector<std::byte> after(view.size());check(view.read(after));
    const auto first=data.packed[port].begin()+std::size_t(h[arm]->physical_ids[j])*16*data.row_bytes(port);
    if(!std::equal(after.begin(),after.end(),first))fail(hyle::Status::Internal("precision readonly FP8 input changed"));
  }
  for(auto &p:h)p.reset();
}
}
int main(){precision_case("cancellation-large",0x70,0x71);precision_case("cancellation-unit",0x38,0x39);std::printf("PRECISION_DONE cases=2 readonly=PASS close_drain=PASS model_quality=NOT_MEASURED\n");}
'''
(work/'consumer.cc').write_text(source)
c=json.loads((factor/'commands.json').read_text())
for stage in c:
  c[stage]=[str(work/'consumer.cc') if x==str(factor/'consumer.cc') else str(work/'consumer.o') if x==str(factor/'consumer.o') else str(work/'precision') if x==str(factor/'factorial') else '-Wl,-Map='+str(work/'link.map') if x=='-Wl,-Map='+str(factor/'link.map') else x for x in c[stage]]
(work/'commands.json').write_text(json.dumps(c,indent=2)+'\n')
result={}
for stage in ['compile','link']:
  start=time.monotonic()
  with (work/(stage+'.log')).open('w') as f:p=subprocess.run(c[stage],stdout=f,stderr=subprocess.STDOUT)
  result[stage]={'exit':p.returncode,'seconds':time.monotonic()-start}
  if p.returncode:print((work/(stage+'.log')).read_text()[-6000:]);break
if len(result)==2 and all(x['exit']==0 for x in result.values()):result['binary']={'path':str(work/'precision'),'sha256':hashlib.sha256((work/'precision').read_bytes()).hexdigest()}
(work/'build-result.json').write_text(json.dumps(result,indent=2)+'\n')
for name in ['consumer.cc','commands.json','build-result.json','compile.log','link.log','link.map']:
  if (work/name).exists():(out/name).write_bytes((work/name).read_bytes())
print(json.dumps(result,indent=2))
