import pathlib,json,subprocess,time,shutil,hashlib
P=pathlib.Path('/root/hyle-scratch/compute-unified/g04-public-capture');P.mkdir(exist_ok=False)
BASE=pathlib.Path('/root/hyle-scratch/compute-unified/g04-factorial-fulltu')
OUT=pathlib.Path('/mnt/c/public/project-hyle/hyle/.scratch/g04-public-capture')
s=(BASE/'consumer.cc').read_text();s=s[:s.index('using Clock=')]
s=s.replace('c::ReadLease execute(){','''void capture(){
    for(unsigned index=0;index<slots.size();++index){auto &slot=slots[index];auto prepared=take(slot.update_batch(layout));
      check(prepared.prepare_replay(query,key_frame,value_frame));
      if(!slot.report().capture_compatible)fail(hyle::Status::Internal("public capture was not retained"));
      std::printf("CAPTURE arm=%s slot=%u capture_compatible=1 native_plan_reused=%d\\n",arm_names[arm_id],index,slot.report().reused_native_plan);
    }
  }
  c::ReadLease execute(){''')
s=s.replace('if(!slot.report().reused_native_plan)fail(hyle::Status::Internal("paged warm topology rebuilt"));','if(!slot.report().reused_native_plan || !slot.report().capture_compatible)fail(hyle::Status::Internal("public captured warm topology or capture changed"));')
s+=r'''
using Clock=std::chrono::steady_clock;
double us(Clock::duration d){return std::chrono::duration<double,std::micro>(d).count();}
void measure(unsigned alloc,unsigned order,int q1,int q2,int k1,int k2,int dk,int dv,bool causal,int window,bool verify_only=false){
  const char *shape=verify_only?"tail":(window>=0?"window":(dk==256?"prefill":"holdout"));
  Data data(q1,q2,k1,k2,dk,dv,causal,window);std::unique_ptr<Harness> h[2];
  for(unsigned pos=0;pos<2;++pos){const unsigned arm=alloc?1-pos:pos;auto start=Clock::now();h[arm]=std::make_unique<Harness>(data,arm);std::printf("COLD alloc=%u order=%u shape=%s side=%u create_us=%.9f\n",alloc,order,shape,arm,us(Clock::now()-start));start=Clock::now();h[arm]->capture();std::printf("CAPTURE_COST alloc=%u order=%u shape=%s side=%u capture_us=%.9f\n",alloc,order,shape,arm,us(Clock::now()-start));}
  const auto expected=data.oracle();std::vector<std::uint16_t> values[2];
  for(unsigned replay=0;replay<4;++replay)for(unsigned arm=0;arm<2;++arm)values[arm]=h[arm]->verify(data,expected);
  double diff=0;for(std::size_t i=0;i<expected.size();++i)diff=std::max(diff,std::abs(double(decode(values[0][i]))-decode(values[1][i])));if(diff>8e-3)fail(hyle::Status::Internal("public capture factor outputs disagree"));
  std::printf("ORACLE alloc=%u order=%u shape=%s pair_difference=%.9g\n",alloc,order,shape,diff);
  if(!verify_only){
    for(unsigned i=0;i<64;++i)for(unsigned pos=0;pos<2;++pos){const unsigned arm=order?1-pos:pos;auto output=h[arm]->execute();output.reset();}
    diagnostic_trace=set("G04_TRACE");push(shape);std::array<std::array<double,2>,512> raw{};
    for(unsigned group=0;group<8;++group)for(unsigned step=0;step<64;++step)for(unsigned pos=0;pos<2;++pos){
      const unsigned side=order?1-pos:pos;push(side?"treatment.episode":"control.episode");const auto start=Clock::now();{auto output=h[side]->execute();output.reset();}raw[group*64+step][side]=us(Clock::now()-start);pop();
    }
    pop();diagnostic_trace=false;
    for(unsigned group=0;group<8;++group){double sums[2]{};for(unsigned step=0;step<64;++step){const auto &x=raw[group*64+step];sums[0]+=x[0];sums[1]+=x[1];std::printf("PAIR alloc=%u order=%u shape=%s group=%u step=%u control_us=%.9f treatment_us=%.9f\n",alloc,order,shape,group,step,x[0],x[1]);}std::printf("BLOCK alloc=%u order=%u shape=%s group=%u count=64 control_us=%.9f treatment_us=%.9f\n",alloc,order,shape,group,sums[0]/64,sums[1]/64);}
    for(unsigned side=0;side<2;++side)h[side]->verify(data,expected);
  }
  for(unsigned pos=0;pos<2;++pos){const unsigned arm=alloc?1-pos:pos;const auto start=Clock::now();h[arm].reset();std::printf("CLOSE alloc=%u order=%u shape=%s side=%u close_us=%.9f\n",alloc,order,shape,arm,us(Clock::now()-start));}
}
}
int main(){
 cpu_set_t cpus;CPU_ZERO(&cpus);CPU_SET(2,&cpus);if(sched_setaffinity(0,sizeof(cpus),&cpus)!=0)std::abort();
 std::printf("SCHEDULE mode=public-PreparedBatch-prepare_replay control=FP8-F32 treatment=FP8-BF16partial warmups=64 groups=8 group_size=64 slots=2 primary=complete-episode-arithmetic-block-mean allocation_orders=2 execution_orders=2 trace=%d\n",set("G04_TRACE"));
 for(unsigned alloc=0;alloc<2;++alloc)for(unsigned order=0;order<2;++order){measure(alloc,order,1,17,1024,768,256,256,true,16);measure(alloc,order,64,128,1024,768,256,256,true,-1);measure(alloc,order,17,1,7,47,64,128,false,-1);}
 measure(0,0,64,128,1023,767,256,256,true,-1,true);std::printf("EXIT code=0\n");return 0;
}
'''
(P/'consumer.cc').write_text(s);(OUT/'consumer.cc').write_text(s)
c=json.loads((BASE/'commands.json').read_text())
c['compile']=[str(P/'consumer.cc') if x==str(BASE/'consumer.cc') else str(P/'consumer.o') if x==str(BASE/'consumer.o') else x for x in c['compile']]
c['link']=[str(P/'consumer.o') if x==str(BASE/'consumer.o') else str(P/'public_capture') if x==str(BASE/'factorial') else '-Wl,-Map='+str(P/'link.map') if x=='-Wl,-Map='+str(BASE/'link.map') else x for x in c['link']]
(P/'commands.json').write_text(json.dumps(c,indent=2)+'\n');(OUT/'commands.json').write_bytes((P/'commands.json').read_bytes())
result={}
for stage in ['compile','link']:
 start=time.monotonic()
 with (P/(stage+'.log')).open('w') as f:z=subprocess.run(c[stage],stdout=f,stderr=subprocess.STDOUT)
 result[stage]={'exit_code':z.returncode,'seconds':time.monotonic()-start};print(stage,result[stage],flush=True)
 if z.returncode:print((P/(stage+'.log')).read_text()[-5000:]);break
(P/'build-result.json').write_text(json.dumps(result,indent=2)+'\n')
for name in ['compile.log','link.log','link.map','build-result.json']:
 if (P/name).exists():(OUT/name).write_bytes((P/name).read_bytes())
if (P/'public_capture').exists():
 identity={'source_sha256':hashlib.sha256((P/'consumer.cc').read_bytes()).hexdigest(),'executable_sha256':hashlib.sha256((P/'public_capture').read_bytes()).hexdigest(),'reused_factor_object_sha256':hashlib.sha256((BASE/'native_cache_factor.o').read_bytes()).hexdigest(),'entry':str(P/'public_capture'),'not_yet_executed':True,'no_cuda_recompile':True};(OUT/'identity.json').write_text(json.dumps(identity,indent=2)+'\n');print(json.dumps(identity))
