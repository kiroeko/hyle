"""Read-only analysis of the retained single-factory product public journey."""
import argparse
import hashlib
import json
from pathlib import Path

from analyze import analyze, parse


def field_map(line):
    return dict(word.split('=',1) for word in line.split()[1:] if '=' in word)


def review(text):
    rows=parse(text)
    reports=[]
    for capture in (0,1):
        selected=[r for r in rows if int(r['capture'])==capture]
        result=analyze(selected,expected_groups=32,group_size=128)
        assert result['episode_pairs']==49152 and result['blocks']==384
        reports.append({'capture':capture,'comparison':'Product allow_bf16_partials=true / product default F32 within this mode',**result})
    memory={};pending=None
    for line in text.splitlines():
        if line.startswith('PRODUCT_MEMORY '):
            assert pending is None
            pending={k:int(v) for k,v in field_map(line).items()}
        elif line.startswith('COLD '):
            assert pending is not None
            f=field_map(line)
            key=(int(f['capture']),int(f['alloc']),int(f['order']),f['shape'],int(f['side']))
            assert key not in memory
            assert pending['f32']==(key[-1]==0) and pending['captured']==key[0] and pending['slots']==2
            expected_narrow=key[3] in ('prefill','tail') and key[-1]==1
            assert pending['bf16_partials']==expected_narrow
            assert pending['float_cap']==((11 if expected_narrow else 22)<<20)
            if key[3] in ('prefill','tail'):
                assert pending['required_workspace']==(10567680 if expected_narrow else 21053440)
            memory[key]=pending;pending=None
    assert pending is None and len(memory)==52
    memory_pairs=[]
    for key,left in memory.items():
        if key[-1]:continue
        right=memory[(*key[:-1],1)]
        memory_pairs.append({'capture':key[0],'alloc':key[1],'order':key[2],'shape':key[3],
                             'f32':left,'opt_in':right,
                             'resource_used_reduction_bytes':left['resource_used']-right['resource_used'],
                             'resource_reserved_reduction_bytes':left['resource_reserved']-right['resource_reserved']})
    return {'kind':'INDEPENDENT_SINGLE_FACTORY_PRODUCT_PUBLIC_BENCH_ANALYSIS',
            'episode_pairs':98304,'complete_episodes':196608,'blocks_verified':768,
            'all_samples_retained':True,'negative_control_subtraction':False,
            'limits':['Each capture mode/alloc/execution-order/shape stratum is compared separately. No cross-mode paired capture-speed claim.',
                      'One retained process, not independent-process confidence. Individual medians/p99 do not replace complete-episode arithmetic block means.',
                      'Resource used/reserved are actual requested allocations through this Hyle CUDA memory resource; driver/native private allocations remain excluded.'],
            'capture_modes':reports,'memory_pairs':memory_pairs}


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('log',type=Path);parser.add_argument('--output',type=Path)
    args=parser.parse_args();raw=args.log.read_bytes();result=review(raw.decode())
    result['source_log']=str(args.log.resolve());result['source_log_sha256']=hashlib.sha256(raw).hexdigest()
    if args.output:args.output.write_text(json.dumps(result,indent=2)+'\n')
    else:print(json.dumps(result,indent=2))
    for mode in result['capture_modes']:
        for row in mode['strata']:
            print('capture',mode['capture'],row['shape'],row['allocation_order'],row['execution_order'],
                  f"change={row['latency_change_percent']:+.5f}%",f"faster_blocks={row['block_treatment_faster']}/32")
    print('prefill resource reductions',sorted({r['resource_used_reduction_bytes'] for r in result['memory_pairs'] if r['shape']=='prefill'}))


if __name__=='__main__':main()
