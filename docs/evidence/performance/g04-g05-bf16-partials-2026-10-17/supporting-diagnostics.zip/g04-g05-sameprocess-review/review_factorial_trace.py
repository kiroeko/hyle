"""Read-only independent correlation of the retained full-TU factorial trace."""
import bisect
from collections import defaultdict
import hashlib
import json
from pathlib import Path
import sqlite3
import statistics

base = Path(__file__).resolve().parents[1] / 'g04-factorial-fulltu/run-trace-1'
database = base / 'profile.sqlite'
db = sqlite3.connect(database.as_uri() + '?mode=ro&immutable=1', uri=True)
shapes = db.execute("select start,end,text from NVTX_EVENTS where text in ('window','prefill','holdout') order by start").fetchall()
pairs = db.execute("select start,end,text from NVTX_EVENTS where text in ('00-orig','00-10','01-11','00-01','10-11','00-peer','orig-peer','11-peer') order by start").fetchall()
episodes = db.execute("select start,end,text from NVTX_EVENTS where text in ('00','01','10','11','orig','peer') order by start").fetchall()
assert len(shapes) == len(pairs) == 48 and len(episodes) == 49152
shape_starts, pair_starts, episode_starts = ([x[0] for x in rows] for rows in (shapes, pairs, episodes))
api = defaultdict(list)
for table in ('CUPTI_ACTIVITY_KIND_RUNTIME', 'CUPTI_ACTIVITY_KIND_DRIVER'):
    if db.execute('select count(*) from sqlite_master where name=?', (table,)).fetchone()[0]:
        for start, end, correlation in db.execute('select start,end,correlationId from ' + table):
            api[correlation].append((start, end))
kernels = db.execute('select k.start,k.end,k.correlationId,k.registersPerThread,k.dynamicSharedMemory,k.localMemoryPerThread,n.value,k.gridX,k.gridY,k.gridZ,k.blockX,k.blockY,k.blockZ from CUPTI_ACTIVITY_KIND_KERNEL k join StringIds n on n.id=k.demangledName order by k.start').fetchall()
mapped = defaultdict(list)
for start, end, correlation, registers, shared, local, name, *dimensions in kernels:
    if not api[correlation]:
        continue
    launch = min(api[correlation])[0]
    index = bisect.bisect_right(episode_starts, launch) - 1
    if index < 0 or launch > episodes[index][1]:
        continue
    kind = 'attention' if 'BatchPrefillWithPagedKVCacheKernel' in name else 'merge' if 'MergeStates' in name else None
    assert kind and local == 0
    mapped[index].append({'kind': kind, 'us': (end-start)/1000, 'registers': registers,
                          'shared': shared, 'grid': dimensions[:3], 'block': dimensions[3:],
                          'correlation': correlation, 'start': start, 'end': end})
assert len(mapped) == 49152 and sum(map(len,mapped.values())) == 65536
supplied = [json.loads(line) for line in (base/'episode-kernels.jsonl').read_text().splitlines()]
assert len(supplied) == len(episodes)
samples, resources = defaultdict(list), defaultdict(set)
expected_pairs = ['00-orig','00-10','01-11','00-01','10-11','00-peer','orig-peer','11-peer']
for index,(start,end,arm) in enumerate(episodes):
    si = bisect.bisect_right(shape_starts,start)-1
    pi = bisect.bisect_right(pair_starts,start)-1
    low,high,shape = shapes[si]
    plow,phigh,pair = pairs[pi]
    alloc, shapenum, pairnum = si//24, (si%24)//8, si%8
    assert low <= start <= end <= high and plow <= low <= high <= phigh
    assert shape == ('window','prefill','holdout')[shapenum]
    assert pair == expected_pairs[pairnum if alloc==0 else 7-pairnum] and arm in pair.split('-')
    row = supplied[index]
    assert (row['index'],row['alloc'],row['shape'],row['pair'],row['arm']) == (index,alloc,shape,pair,arm)
    assert len(mapped[index]) == (2 if shape=='prefill' else 1)
    for kernel in mapped[index]:
        original = next(k for k in row['kernels'] if k['kind']==kernel['kind'])
        for key in ('us','registers','correlation','start','end'):
            assert kernel[key] == original[key]
        if shape=='prefill':
            assert kernel['block'] == [32,4,1]
            if kernel['kind']=='attention':
                assert kernel['shared']==49152 and kernel['grid']==[40,1,2]
                assert kernel['registers']=={'00':248,'orig':248,'01':246,'10':237,'11':240,'peer':240}[arm]
            else:
                assert kernel['shared']==8704 and kernel['grid']==[460,1,1]
                assert kernel['registers']==(40 if arm=='peer' else 48)
        samples[alloc,shape,pair,arm,kernel['kind']].append(kernel['us'])
        resources[shape,arm,kernel['kind']].add((kernel['registers'],kernel['shared'],tuple(kernel['grid']),tuple(kernel['block'])))
results=[]
for alloc in (0,1):
    for shape in ('window','prefill','holdout'):
        for pair in expected_pairs:
            a,b=pair.split('-')
            stages={}
            for kind in (('attention','merge') if shape=='prefill' else ('attention',)):
                left,right=(samples[alloc,shape,pair,arm,kind] for arm in (a,b))
                assert len(left)==len(right)==512
                lm,rm=statistics.fmean(left),statistics.fmean(right)
                stages[kind]={'left_mean_us':lm,'right_mean_us':rm,'left_minus_right_us':lm-rm,'right_over_left_change_percent':100*(rm/lm-1)}
            left=sum(s['left_mean_us'] for s in stages.values())
            right=sum(s['right_mean_us'] for s in stages.values())
            results.append({'alloc':alloc,'shape':shape,'pair':pair,'stages':stages,
                            'gpu_sum':{'left_mean_us':left,'right_mean_us':right,'left_minus_right_us':left-right,'right_over_left_change_percent':100*(right/left-1)}})
report={'kind':'INDEPENDENT_EXISTING_FULL_TU_ACTIVE_PAIR_TRACE_REVIEW','episodes':len(episodes),
        'timed_kernels':sum(map(len,mapped.values())), 'outside_timed_kernels':len(kernels)-sum(map(len,mapped.values())),
        'supplied_mapping_matches_raw_sqlite':True,
        'boundaries':['GPU phases from one profiler run; no profiler host primary or ordinary tail trimming.',
                      'Each pair has its own working set/time; same-SASS fresh00/orig differences prevent small cross-pair deltas from proving pure carrier cost.',
                      'Partial factor includes 2/4-stage native merge, output rounding and attention codegen, not only representation width.'],
        'strata':results,
        'resources':[{'shape':k[0],'arm':k[1],'kind':k[2],'variants':sorted(v)} for k,v in resources.items()],
        'sha256':{str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in (database,base/'episode-kernels.jsonl',base/'identity.json')}}
target=Path(__file__).with_name('factorial-trace-review.json')
target.write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
for row in results:
    if row['shape']=='prefill':
        print(row['alloc'],row['pair'],json.dumps(row['stages']),json.dumps(row['gpu_sum']))
db.close()
