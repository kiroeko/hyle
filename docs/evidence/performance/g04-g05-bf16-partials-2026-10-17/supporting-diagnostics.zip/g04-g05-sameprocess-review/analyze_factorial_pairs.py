"""Analyze full-TU factorial active pairs; never pool an arm across peer scenes."""
import argparse
from collections import Counter
import hashlib
import json
import math
from pathlib import Path
import statistics

from analyze import distribution, percentile

PAIRS = ("00-orig", "00-10", "01-11", "00-01", "10-11", "00-peer", "orig-peer", "11-peer")
OPTIONAL_PAIRS = set()
SHAPES = ("window", "prefill", "holdout")


def fields(line):
    return dict(word.split("=", 1) for word in line.split()[1:] if "=" in word)


def effects(deltas):
    c32, c16, p8, p16 = (deltas[p] for p in ("00-10", "01-11", "00-01", "10-11"))
    answer = {
        "carrier_at_F32_us": c32, "carrier_at_BF16partial_us": c16,
        "partial_pipeline_at_FP8_us": p8, "partial_pipeline_at_BF16carrier_us": p16,
        "interaction_via_carrier_pairs_us": c32 - c16,
        "interaction_via_partial_pairs_us": p8 - p16,
        "factorial_path_closure_residual_us": c32 + p16 - p8 - c16,
        "fresh00_minus_original_us": deltas["00-orig"],
        "original_minus_peer_us": deltas["orig-peer"],
        "fresh00_minus_peer_us": deltas["00-peer"],
        "anchor_triangle_closure_residual_us": deltas["00-peer"] - deltas["00-orig"] - deltas["orig-peer"],
        "inferred_11_minus_peer_via_carrier_first_us": deltas["00-peer"] - c32 - p16,
        "inferred_11_minus_peer_via_partial_first_us": deltas["00-peer"] - p8 - c16,
    }
    if "11-peer" in deltas:
        answer["direct_11_minus_peer_us"] = deltas["11-peer"]
        answer["carrier_path_to_peer_closure_us"] = deltas["00-peer"] - c32 - p16 - deltas["11-peer"]
        answer["partial_path_to_peer_closure_us"] = deltas["00-peer"] - p8 - c16 - deltas["11-peer"]
    return answer


def analyze(text):
    episodes, blocks, cold, plan = {}, {}, [], []
    for number, line in enumerate(text.splitlines(), 1):
        if line.startswith(("FACTOR_PLAN ", "FACTOR_ARRAY ")):
            plan.append(line)
        if line.startswith(("COLD ", "CLOSE ")):
            cold.append({"kind": line.split()[0], "source_line": number, **fields(line)})
        if not line.startswith(("EP ", "BLOCK ")):
            continue
        r = fields(line)
        pair, alloc, shape, group, arm = r["pair"], int(r["alloc"]), r["shape"], int(r["group"]), r["arm"]
        assert pair in set(PAIRS) | OPTIONAL_PAIRS and alloc in (0, 1) and shape in SHAPES and arm in pair.split("-")
        key = pair, alloc, shape, group, arm
        if line.startswith("EP "):
            key += (int(r["step"]),)
            value, position = float(r["us"]), int(r["position"])
            assert math.isfinite(value) and value > 0 and position in (0, 1) and key not in episodes
            episodes[key] = {"us": value, "position": position, "source_line": number}
        else:
            assert int(r["count"]) == 64 and key not in blocks
            blocks[key] = float(r["mean_us"])
    present = {k[0] for k in episodes}
    assert set(PAIRS) <= present <= set(PAIRS) | OPTIONAL_PAIRS
    expected = {(p, a, s, g, arm, i) for p in present for a in (0, 1) for s in SHAPES
                for g in range(8) for arm in p.split("-") for i in range(64)}
    assert set(episodes) == expected and set(blocks) == {k[:-1] for k in expected}
    output, deltas_by_scene = [], {}
    for alloc in (0, 1):
        for shape in SHAPES:
            for pair in sorted(present):
                arms, block_rows, all_means = {}, [], {}
                left, right = pair.split("-")
                for g in range(8):
                    for step in range(64):
                        assert {episodes[pair, alloc, shape, g, arm, step]["position"] for arm in (left, right)} == {0, 1}
                for arm in (left, right):
                    samples = [episodes[pair, alloc, shape, g, arm, step] for g in range(8) for step in range(64)]
                    values = [r["us"] for r in samples]
                    threshold, positions = percentile(values, .99), Counter(r["position"] for r in samples)
                    arms[arm] = {**distribution(values), "position_counts": dict(positions),
                                 "tail_at_or_above_p99": [r for r in samples if r["us"] >= threshold]}
                    all_means[arm] = statistics.fmean(values)
                for g in range(8):
                    means = {arm: statistics.fmean(episodes[pair, alloc, shape, g, arm, i]["us"] for i in range(64)) for arm in (left, right)}
                    assert all(math.isclose(means[arm], blocks[pair, alloc, shape, g, arm], rel_tol=5e-9, abs_tol=1e-6) for arm in means)
                    block_rows.append({"group": g, "arithmetic_means_us": means,
                                       "left_minus_right_us": means[left] - means[right],
                                       "left_over_right": means[left] / means[right]})
                delta = all_means[left] - all_means[right]
                deltas_by_scene[pair, alloc, shape] = delta
                output.append({"pair": pair, "alloc": alloc, "shape": shape, "arms": arms,
                               "blocks": block_rows, "left_minus_right_us": delta,
                               "left_over_right": all_means[left] / all_means[right],
                               "left_over_right_latency_percent": 100 * (all_means[left] / all_means[right] - 1)})
    derived = [{"alloc": a, "shape": s, "contrasts_from_active_pair_arithmetic_means": effects({p: deltas_by_scene[p, a, s] for p in present})} for a in (0, 1) for s in SHAPES]
    pooled = [{"shape": s, "contrasts_from_equal_count_allocations": effects({p: statistics.fmean(deltas_by_scene[p, a, s] for a in (0, 1)) for p in present})} for s in SHAPES]
    return {"kind": "READ_ONLY_FULL_TU_ACTIVE_PAIR_FACTORIAL_ANALYSIS",
            "pairs": sorted(present), "episodes": len(episodes), "blocks_verified": len(blocks),
            "all_samples_retained": True, "negative_control_subtraction": False,
            "active_arms_per_pair": 2, "cold_resident_owners": 6,
            "limits": ["Each contrast uses its own two-active-arm scene; an arm is never pooled across different peers.",
                       "Interaction from carrier pairs and partial pairs are separate estimates. Their closure is not forced by algebra.",
                       "Pairs run sequentially; matching group indexes do not establish simultaneous paired confidence intervals.",
                       "Partial factor includes native epilogue/rounding and2/4stage merge, not pure bytes. Carrier includes load/conversion/resource effects.",
                       "Six owners physically resident is different from six active L2 working sets. Pair warmup removes touches to other four arms, but capacity belowL2 alone does not prove allhot.",
                       "Profiler hostwall must not replace ordinary complete-episode latency."],
            "strata": output, "derived_by_alloc_and_shape": derived,
            "derived_pooled_allocations": pooled, "cold_and_close_records": cold, "plan_dump_lines": plan}


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("log", type=Path)
    p.add_argument("--output", type=Path, required=True)
    args = p.parse_args()
    raw = args.log.read_bytes()
    result = analyze(raw.decode("utf-8"))
    result["source_log_sha256"] = hashlib.sha256(raw).hexdigest()
    args.output.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    for row in result["derived_by_alloc_and_shape"]:
        print(row["alloc"], row["shape"], row["contrasts_from_active_pair_arithmetic_means"])


if __name__ == "__main__":
    main()
