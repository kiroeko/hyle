"""Read all ordinary six-arm factorial episodes, without trimming or subtraction."""
import argparse
from collections import Counter
import hashlib
import json
import math
from pathlib import Path
import statistics

from analyze import distribution, percentile

ARMS = ("00", "01", "10", "11", "orig", "peer")
SHAPES = ("window", "prefill", "holdout")


def fields(line):
    return dict(word.split("=", 1) for word in line.split()[1:] if "=" in word)


def effects(means):
    a, b, c, d = (means[arm] for arm in ARMS[:4])
    return {
        "carrier_at_F32_us": a - c,
        "carrier_at_BF16partial_us": b - d,
        "partial_pipeline_at_FP8_us": a - b,
        "partial_pipeline_at_BF16carrier_us": c - d,
        "interaction_us": a - c - b + d,
        "fresh00_minus_original_us": a - means["orig"],
        "original_minus_peer_us": means["orig"] - means["peer"],
        "matched11_minus_peer_us": d - means["peer"],
        "original_minus_peer_latency_percent": 100 * (means["orig"] / means["peer"] - 1),
        "fresh00_over_original": a / means["orig"],
    }


def analyze(text):
    episodes, printed_blocks, cold, plan_lines = {}, {}, [], []
    for line_number, line in enumerate(text.splitlines(), 1):
        if line.startswith(("FACTOR_PLAN ", "FACTOR_ARRAY ")):
            plan_lines.append(line)
        if line.startswith(("COLD ", "CLOSE ")):
            cold.append({"kind": line.split()[0], "source_line": line_number, **fields(line)})
        if not line.startswith(("EP ", "BLOCK ")):
            continue
        row = fields(line)
        alloc, group = int(row["alloc"]), int(row["group"])
        shape, arm = row["shape"], row["arm"]
        assert alloc in (0, 1) and shape in SHAPES and arm in ARMS
        base = alloc, shape, group, arm
        if line.startswith("EP "):
            step, position, us = int(row["step"]), int(row["position"]), float(row["us"])
            assert 0 <= position < 6 and math.isfinite(us) and us > 0
            key = (*base, step)
            assert key not in episodes, ("duplicate episode", key)
            episodes[key] = {"us": us, "position": position, "source_line": line_number}
        else:
            assert int(row["count"]) == 64 and base not in printed_blocks
            printed_blocks[base] = float(row["mean_us"])
    expected = {(a, s, g, arm, i) for a in (0, 1) for s in SHAPES
                for g in range(8) for arm in ARMS for i in range(64)}
    assert set(episodes) == expected, ("incomplete/unexpected episode matrix", len(episodes))
    assert set(printed_blocks) == {key[:-1] for key in expected}
    for a in (0, 1):
        for s in SHAPES:
            for g in range(8):
                for i in range(64):
                    assert {episodes[a, s, g, arm, i]["position"] for arm in ARMS} == set(range(6))
    result = []
    for a in (0, 1):
        for shape in SHAPES:
            all_values, blocks, arms = {}, [], {}
            for arm in ARMS:
                samples = [episodes[a, shape, g, arm, i] for g in range(8) for i in range(64)]
                values = [r["us"] for r in samples]
                all_values[arm] = values
                positions = Counter(r["position"] for r in samples)
                p99 = percentile(values, .99)
                arms[arm] = {
                    **distribution(values),
                    "position_counts": {str(p): positions[p] for p in range(6)},
                    "position_count_range": max(positions.values()) - min(positions.values()),
                    "tail_at_or_above_p99": [r for r in samples if r["us"] >= p99],
                }
            for g in range(8):
                means = {}
                for arm in ARMS:
                    value = statistics.fmean(episodes[a, shape, g, arm, i]["us"] for i in range(64))
                    assert math.isclose(value, printed_blocks[a, shape, g, arm], rel_tol=5e-9, abs_tol=1e-6)
                    means[arm] = value
                blocks.append({"group": g, "arithmetic_means_us": means, "effects": effects(means)})
            means = {arm: statistics.fmean(values) for arm, values in all_values.items()}
            result.append({"alloc": a, "shape": shape, "arms": arms, "blocks": blocks,
                           "effects_from_all_arithmetic_means": effects(means)})
    pooled = []
    for shape in SHAPES:
        means = {arm: statistics.fmean(episodes[a, shape, g, arm, i]["us"]
                    for a in (0, 1) for g in range(8) for i in range(64)) for arm in ARMS}
        pooled.append({"shape": shape, "arithmetic_means_us": means, "effects": effects(means)})
    return {
        "kind": "READ_ONLY_ORDINARY_FULL_TU_FACTORIAL_ANALYSIS",
        "arm_definitions": {"00": "FP8carrier/F32partial+2stage", "01": "FP8carrier/BF16partial+4stage",
                            "10": "unscaledBF16carrier/F32partial+2stage", "11": "unscaledBF16carrier/BF16partial+4stage",
                            "orig": "original full native TU", "peer": "original scaled-BF16 peer"},
        "episodes": len(episodes), "printed_blocks_verified": len(printed_blocks),
        "all_samples_retained": True, "negative_control_subtraction": False,
        "effect_sign": "Positive microseconds means the first named path takes longer.",
        "limits": ["Partial is the whole representation/native merge pipeline factor, not pure byte width.",
                   "Carrier includes loading, conversion, and induced kernel resource effects, not decoder instructions alone.",
                   "Descriptive ordinary whole-episode data from one process; GPU phases require the independent same-binary trace.",
                   "Original-versus-peer is recomputed simultaneously; old P1 percentages are not combined with these absolute durations."],
        "strata": result, "pooled_equal_count_allocations": pooled,
        "cold_and_close_records": cold, "plan_dump_lines": plan_lines,
    }


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("log", type=Path)
    p.add_argument("--output", type=Path, required=True)
    args = p.parse_args()
    raw = args.log.read_bytes()
    result = analyze(raw.decode("utf-8"))
    result["source_log_sha256"] = hashlib.sha256(raw).hexdigest()
    args.output.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    for row in result["strata"]:
        print(row["alloc"], row["shape"], row["effects_from_all_arithmetic_means"])


if __name__ == "__main__":
    main()
