"""Read-only all-tail summaries. CI is descriptive for retained blocks only."""
import csv
import hashlib
import json
import math
from pathlib import Path
import statistics

from scipy.stats import t as student_t

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]


def paired_block_interval(strata):
    blocks=[b for row in strata for b in row['blocks']]
    c=[b['control_arithmetic_mean_us'] for b in blocks]
    d=[b['treatment_arithmetic_mean_us'] for b in blocks]
    n=len(blocks);mc=statistics.fmean(c);mt=statistics.fmean(d);ratio=mt/mc
    differences=[b-a for a,b in zip(c,d)]
    residual=[b-ratio*a for a,b in zip(c,d)]
    critical=float(student_t.ppf(.975,n-1))
    delta_radius=critical*statistics.stdev(differences)/math.sqrt(n)
    ratio_radius=critical*statistics.stdev(residual)/(math.sqrt(n)*mc)
    return {'paired_blocks':n,'complete_pairs':sum(b['count'] for b in blocks),
            'control_all_tail_mean_us':mc,'treatment_all_tail_mean_us':mt,
            'treatment_over_control':ratio,'latency_change_percent':100*(ratio-1),
            'treatment_minus_control_us':mt-mc,
            'paired_block_delta_us_95pct_t_interval':[mt-mc-delta_radius,mt-mc+delta_radius],
            'paired_block_ratio_delta_method_95pct_t_interval':[ratio-ratio_radius,ratio+ratio_radius],
            'latency_change_percent_interval':[100*(ratio-ratio_radius-1),100*(ratio+ratio_radius-1)],
            'treatment_faster_blocks':sum(b<a for a,b in zip(c,d)),
            'critical_t':critical,'degrees_of_freedom':n-1}


def main():
    reports=[];table=[]
    for name,comparison in [('product-f32-vs-optin-analysis','default F32 -> opt-in BF16 partial'),
                            ('product-peer-vs-optin-analysis','same-source plain BF16 peer -> FP8 opt-in')]:
        path=HERE/(name+'.json');data=json.loads(path.read_text())
        for mode in data['capture_modes']:
            for shape in sorted({r['shape'] for r in mode['strata']}):
                strata=[r for r in mode['strata'] if r['shape']==shape]
                summary=paired_block_interval(strata)
                # Equal 4096-pair strata make the pooled block mean exactly
                # the all-retained-episode arithmetic mean, up to print precision.
                pooled=next(r for r in mode['pooled_equal_count_matrix'] if r['shape']==shape)
                assert math.isclose(summary['treatment_over_control'],pooled['ratio_of_all_arithmetic_means'],rel_tol=1e-12)
                reports.append({'comparison':comparison,'capture':mode['capture'],'shape':shape,**summary})
                for r in strata:
                    table.append({'comparison':comparison,'capture':mode['capture'],'shape':shape,
                                  'allocation_order':r['allocation_order'],'execution_order':r['execution_order'],
                                  'control_mean_us':r['control']['arithmetic_mean_us'],
                                  'treatment_mean_us':r['treatment']['arithmetic_mean_us'],
                                  'latency_change_percent':r['latency_change_percent'],
                                  'control_p99_us':r['control']['p99_us'],'treatment_p99_us':r['treatment']['p99_us'],
                                  'control_max_us':r['control']['max_us'],'treatment_max_us':r['treatment']['max_us'],
                                  'treatment_faster_blocks':r['block_treatment_faster'],'blocks':32,
                                  'complete_pairs':r['control']['count']})
    bindings=[]
    for folder in ('g04-bf16-product-bench/run-1','g04-bf16-product-peer-bench/run-ordinary-1','g04-bf16-product-precision/run-ordinary-2'):
        run=ROOT/'.scratch'/folder;result=json.loads((run/'result.json').read_text())
        assert result['returncode']==0
        bindings.append({'run':folder,'identity':result,
                         'stdout_sha256':hashlib.sha256((run/'stdout.log').read_bytes()).hexdigest(),
                         'stderr_sha256':hashlib.sha256((run/'stderr.log').read_bytes()).hexdigest()})
    record={'kind':'INDEPENDENT_NEW_PRODUCT_RESULT_SUMMARY','pooled_all_tail_means':reports,
            'all_matrices':table,'bindings':bindings,
            'precision_review':'product-precision-review.json',
            'interval_method':'Paired arithmetic block means, all 128 blocks per fixed mode/shape. Student t interval for delta; first-order paired-residual delta method for ratio. Equal-size blocks preserve the all-tail episode mean.',
            'interval_limits':['These descriptive intervals condition on one retained process and treat adjacent blocks as independent; temporal autocorrelation, process-to-process and device/systematic uncertainty are not estimated.',
                               'Allocation/execution strata are all shown separately. Intervals are not a replacement for those effects and are not a fresh measurement or a selection gate.',
                               'No trimmed samples, negative-control subtraction, cross-mode normalization or cold-cost subtraction.'],
            'conclusion':{'default_comparison':'Opt-in improves all eight target prefill all-tail arithmetic means and halves actual requested float workspace backing in this finite domain.',
                          'peer_comparison':'FP8 opt-in remains slower than same-source BF16 KV peer in all eight measured target strata; the remaining gap is not closed.',
                          'precision':'Both cancellation amplitudes/modes/slots match the current same-source BF16 peer word for word; default F32 matches independent RNE oracle. This does not establish full model quality.'}}
    dest=HERE/'new-product-results-summary.json';dest.write_text(json.dumps(record,indent=2)+'\n')
    with (HERE/'new-product-all-matrices.csv').open('w',newline='') as stream:
        writer=csv.DictWriter(stream,fieldnames=list(table[0]));writer.writeheader();writer.writerows(table)
    for r in reports:
        print(r['comparison'],'capture',r['capture'],r['shape'],
              f"{r['control_all_tail_mean_us']:.6f}->{r['treatment_all_tail_mean_us']:.6f} us",
              f"change {r['latency_change_percent']:+.6f}%",
              'block ratio CI',','.join(f'{v:+.6f}%' for v in r['latency_change_percent_interval']))
    print('summary SHA256',hashlib.sha256(dest.read_bytes()).hexdigest())


if __name__=='__main__':main()
