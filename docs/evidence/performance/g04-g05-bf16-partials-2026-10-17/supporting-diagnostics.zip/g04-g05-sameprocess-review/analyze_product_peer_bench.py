"""Read-only product FP8 opt-in / same-source BF16 KV peer comparison."""
import argparse
import hashlib
import json
from pathlib import Path

import analyze as paired


def fields(line):
    return dict(item.split('=',1) for item in line.split()[1:] if '=' in item)


def review(text):
    # This experiment deliberately contains only the target prefill matrix.
    paired.SHAPES=('prefill',)
    records=paired.parse(text)
    modes=[]
    for capture in (0,1):
        result=paired.analyze([r for r in records if int(r['capture'])==capture],32,128)
        assert result['episode_pairs']==16384 and result['blocks']==128
        modes.append({'capture':capture,**result})
    memory={};pending=None;expansions=[];oracles=[]
    for line in text.splitlines():
        if line.startswith('PRODUCT_MEMORY '):
            assert pending is None
            pending={k:int(v) for k,v in fields(line).items()}
        elif line.startswith('COLD '):
            assert pending is not None
            f=fields(line)
            key=(int(f['capture']),int(f['alloc']),int(f['order']),f['shape'],int(f['side']))
            assert key not in memory
            assert pending['default_option']==(key[-1]==0)
            assert pending['captured']==key[0] and pending['slots']==2
            assert pending['bf16_partials']==(key[-1]==1)
            assert pending['float_cap']==((22 if key[-1]==0 else 11)<<20)
            if key[-1]==1:assert pending['required_workspace']==10567680
            memory[key]=pending;pending=None
        elif line.startswith('COLD_EXPANSION '):
            f=fields(line);assert f['outside_warm_timing']=='1'
            assert int(f['expanded_BF16_bytes'])==2*int(f['source_FP8_bytes'])
            expansions.append(f)
        elif line.startswith('ORACLE '):
            f=fields(line);assert float(f['pair_difference'])<=8e-3
            oracles.append(f)
    assert pending is None and len(memory)==20 and len(expansions)==10 and len(oracles)==10
    assert text.rstrip().endswith('EXIT code=0')
    reductions=[]
    for key,left in memory.items():
        if key[-1]:continue
        right=memory[(*key[:-1],1)]
        reductions.append({'capture':key[0],'alloc':key[1],'order':key[2],'shape':key[3],
                           'same_source_plain_bf16_peer':left,'product_fp8_optin':right,
                           'actual_resource_used_reduction_bytes':left['resource_used']-right['resource_used'],
                           'actual_resource_reserved_reduction_bytes':left['resource_reserved']-right['resource_reserved']})
    return {'kind':'INDEPENDENT_PRODUCT_SAME_SOURCE_BF16_PEER_PUBLIC_BENCH_ANALYSIS',
            'comparison':'new FP8 allow_bf16_partials=true / same-source FlashInfer plain BF16 native batch',
            'external_engine_comparison':False,'episode_pairs':32768,'complete_episodes':65536,
            'blocks_verified':256,'capture_modes':modes,'memory_pairs':reductions,
            'cold_expansion':expansions,'oracles':oracles,
            'all_samples_retained':True,'negative_control_subtraction':False,
            'limits':['Cold exact decode plus scale and all cold create costs are logged separately and never deducted from warm episode latency.',
                      'Compare within each capture/alloc/execution-order stratum. No cross-mode paired claim or independent-process confidence.',
                      'Resource differences include both KV representation and requested float workspace caps, not a pure partial-workspace ablation.',
                      'The peer is the same pinned FlashInfer implementation, not an external inference engine.']}


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('log',type=Path);parser.add_argument('--output',type=Path)
    args=parser.parse_args();raw=args.log.read_bytes();result=review(raw.decode())
    result['source_log']=str(args.log.resolve());result['source_log_sha256']=hashlib.sha256(raw).hexdigest()
    if args.output:args.output.write_text(json.dumps(result,indent=2)+'\n')
    else:print(json.dumps(result,indent=2))
    for mode in result['capture_modes']:
        for r in mode['strata']:
            print('capture',mode['capture'],r['allocation_order'],r['execution_order'],
                  f"change={r['latency_change_percent']:+.5f}%",f"faster_blocks={r['block_treatment_faster']}/32")


if __name__=='__main__':main()
