import sqlite3,json
from pathlib import Path
p=Path('/root/hyle-scratch/compute-unified/g04-bf16-product-peer-trace/run-trace-1/profile.sqlite')
db=sqlite3.connect(p.as_uri()+'?mode=ro&immutable=1',uri=True)
names=[x[0] for x in db.execute("select name from sqlite_master where type='table'")]
print(json.dumps(names))
for name in names:
    if name in ('NVTX_EVENTS','CUPTI_ACTIVITY_KIND_KERNEL','CUPTI_ACTIVITY_KIND_RUNTIME','CUPTI_ACTIVITY_KIND_DRIVER') or ('GRAPH' in name and 'ENUM' not in name):
        print(name,db.execute('pragma table_info('+name+')').fetchall())
        print('EXAMPLES',db.execute('select * from '+name+' limit 2').fetchall())
print('NVTX',db.execute("select start,end,text,textId,globalTid from NVTX_EVENTS where text like 'PRODUCT_PEER%' or text like '%.episode' order by start limit 8").fetchall())
print('APINAMES',db.execute('select s.value,count(*) from CUPTI_ACTIVITY_KIND_RUNTIME r join StringIds s on s.id=r.nameId group by s.value').fetchall())
capture=db.execute("select start,end from NVTX_EVENTS where text like 'PRODUCT_PEER capture=1%' order by start limit 1").fetchone()
print('CAPTURE',capture)
print('CAPTURE APIS',db.execute('select r.start,r.end,r.correlationId,s.value from CUPTI_ACTIVITY_KIND_RUNTIME r join StringIds s on s.id=r.nameId where r.start>=? and r.end<=? order by r.start limit 20',capture).fetchall())
print('CAPTURE KERNELS',db.execute('select k.start,k.end,k.correlationId,k.graphNodeId,k.graphId,s.value from CUPTI_ACTIVITY_KIND_KERNEL k join StringIds s on s.id=k.demangledName where k.start>=? and k.end<=? order by k.start limit 5',capture).fetchall())
