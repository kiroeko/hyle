"""Prepare two host consumers; never compile native CUDA or run GPU work."""
from pathlib import Path
import hashlib
import json

repo=Path(__file__).resolve().parents[2]
source=repo/'.scratch/g04-bf16-product-bench/consumer.cc'
original=source.read_text()
prefix=original[:original.index('using Clock=')]
assert 'readonly Q changed' in prefix or 'readonly query changed' in prefix or 'readonly query' in prefix or 'readonly Q' in prefix
prefix=prefix.replace('bool set(const char *name)', '[[maybe_unused]] bool set(const char *name)')
before='std::size_t row_bytes(unsigned port)const{return std::size_t(2)*(port?capacity.value_head_dim:capacity.qk_head_dim);}'
after='std::size_t row_bytes(unsigned port)const{const auto storage=port?capacity.value_storage:capacity.key_storage;return std::size_t(2)*(port?capacity.value_head_dim:capacity.qk_head_dim)*(storage.data_type()==c::DataType::kFloat8E4M3FN?1u:2u);}'
assert prefix.count(before)==1
prefix=prefix.replace(before,after)
prefix=prefix.replace('PRODUCT_MEMORY f32=%d','PRODUCT_MEMORY default_option=%d')

peer_helper=r'''
Data plain_bf16_peer(const Data &source){
  Data peer=source;
  for(unsigned port=0;port<2;++port){
    const auto scale=port?source.capacity.value_storage.scale():source.capacity.key_storage.scale();
    std::vector<std::byte> bytes(source.packed[port].size()*2);
    for(std::size_t i=0;i<source.packed[port].size();++i){
      const auto value=float(fp8(std::to_integer<std::uint8_t>(source.packed[port][i]))*scale);
      const auto word=encode(value);
      if(decode(word)!=value)fail(hyle::Status::Internal("plain BF16 peer cold expansion changed an input value"));
      std::memcpy(bytes.data()+i*2,&word,2);
    }
    peer.packed[port]=std::move(bytes);
  }
  peer.capacity.key_storage=take(c::CacheStorage::plain(c::DataType::kBFloat16));
  peer.capacity.value_storage=take(c::CacheStorage::plain(c::DataType::kBFloat16));
  return peer;
}
'''

precision=r'''
std::uint16_t round_word(double value){auto bits=std::bit_cast<std::uint32_t>(float(value));bits+=0x7fff+((bits>>16)&1);return std::uint16_t(bits>>16);}
void readonly_inputs(const Data &data,Harness &owner){
  auto qview=take(owner.query.view());std::vector<std::uint16_t> q(data.query.size());
  check(qview.read(std::as_writable_bytes(std::span(q))));
  if(q!=data.query)fail(hyle::Status::Internal("new product precision readonly Q changed"));
  for(unsigned port=0;port<2;++port)for(unsigned index=0;index<owner.key_pages.size();++index){
    auto view=take((port?owner.value_pages[index]:owner.key_pages[index]).view());std::vector<std::byte> bytes(view.size());check(view.read(bytes));
    const auto first=data.packed[port].begin()+std::size_t(owner.physical_ids[index])*16*data.row_bytes(port);
    if(!std::equal(bytes.begin(),bytes.end(),first))fail(hyle::Status::Internal("new product precision readonly KV changed"));
  }
}
void precision_case(const char *name,std::uint8_t positive,std::uint8_t perturbed,bool capture){
  Data data(64,128,8192,8192,256,256,true,-1);
  std::fill(data.query.begin(),data.query.end(),std::uint16_t{0});
  for(unsigned r=0;r<2;++r)for(unsigned row=0;row<8192;++row){
    const auto physical=unsigned(data.ids[unsigned(data.kp[r])+row/16])*16+row%16;
    const auto code=std::uint8_t(row<4096?(row%64==0?perturbed:positive):(positive|128));
    for(unsigned head=0;head<2;++head)for(unsigned d=0;d<256;++d){const auto at=(std::size_t(physical)*2+head)*256+d;
      data.packed[0][at]=std::byte{0};data.decoded[0][at]=0;
      data.packed[1][at]=std::byte{code};data.decoded[1][at]=float(fp8(code)*2.);
    }
  }
  auto peer=plain_bf16_peer(data);
  std::vector<double> expected(std::size_t(data.qp[2])*8*256);
  for(unsigned r=0;r<2;++r){const auto nq=unsigned(data.qp[r+1]-data.qp[r]);std::vector<double> prefix(8193);
    for(unsigned row=0;row<8192;++row){const auto physical=unsigned(data.ids[unsigned(data.kp[r])+row/16])*16+row%16;
      prefix[row+1]=prefix[row]+data.decoded[1][std::size_t(physical)*2*256];}
    for(unsigned q=0;q<nq;++q){const auto count=8192-nq+q+1;const auto mean=prefix[count]/count;
      for(unsigned head=0;head<8;++head)for(unsigned d=0;d<256;++d)expected[((std::size_t(data.qp[r])+q)*8+head)*256+d]=mean;
    }
  }
  const std::array<const char*,3> names{"fp8_f32","fp8_bf16partial","plain_bf16_same_source_peer"};
  std::array<std::unique_ptr<Harness>,3> owners;
  owners[0]=std::make_unique<Harness>(data,true,capture);
  owners[1]=std::make_unique<Harness>(data,false,capture);
  owners[2]=std::make_unique<Harness>(peer,true,capture);
  for(unsigned episode=0;episode<2;++episode){std::array<std::vector<std::uint16_t>,3> all;
    for(unsigned arm=0;arm<3;++arm){auto output=owners[arm]->execute();
      const auto report=owners[arm]->slots[episode].report();
      if(report.cta_tile_q!=64 || !report.split_kv || report.bf16_partials!=(arm==1))fail(hyle::Status::Internal("product precision did not select its declared pipeline"));
      // The lease covers capacity rows, including three inactive rows. The
      // memory API reads the whole view; only the logical prefix has outputs.
      all[arm].resize(std::size_t(data.capacity.max_query_rows)*8*256);
      check(output.view()->read(std::as_writable_bytes(std::span(all[arm]))));
      all[arm].resize(expected.size());
      double maximum=0,sum=0,relative=0,rounded_error=0;std::size_t differences=0;
      for(std::size_t i=0;i<expected.size();++i){const auto value=double(decode(all[arm][i]));
        if(!std::isfinite(value))fail(hyle::Status::Internal("product precision output was nonfinite"));
        const auto error=std::abs(value-expected[i]);maximum=std::max(maximum,error);sum+=error;
        if(std::abs(expected[i])>1e-12)relative=std::max(relative,error/std::abs(expected[i]));
        rounded_error=std::max(rounded_error,std::abs(value-double(decode(round_word(expected[i])))));differences+=all[arm][i]!=round_word(expected[i]);
      }
      if(arm==0 && differences)fail(hyle::Status::Internal("new product default F32 lost the retained RNE residual"));
      std::printf("NEW_PRECISION case=%s capture=%u slot=%u arm=%s elements=%zu max_abs=%.12g mean_abs=%.12g max_relative=%.12g max_vs_RNE=%.12g different_RNE_words=%zu final_expected=%.12g final_actual=%.12g workspace=%zu cap=%zu actual_optin=%d\n",name,unsigned(capture),episode,names[arm],expected.size(),maximum,sum/expected.size(),relative,rounded_error,differences,expected.back(),double(decode(all[arm].back())),report.float_workspace_bytes,owners[arm]->float_cap,report.bf16_partials);
    }
    std::size_t different=0;double maximum=0;
    for(std::size_t i=0;i<expected.size();++i){different+=all[1][i]!=all[2][i];maximum=std::max(maximum,std::abs(double(decode(all[1][i]))-decode(all[2][i])));}
    if(different)fail(hyle::Status::Internal("new product BF16 partial output differs from same-source BF16 KV peer"));
    const auto known=positive==0x70?.08251953125:.000644683837890625;
    if(double(decode(all[1].back()))!=known)fail(hyle::Status::Internal("new product did not reproduce retained peer final residual"));
    std::printf("NEW_PRECISION_PEER case=%s capture=%u slot=%u compared_words=%zu different_words=%zu max_abs_difference=%.12g known_retained_peer_final=%.12g\n",name,unsigned(capture),episode,expected.size(),different,maximum,known);
  }
  for(unsigned arm=0;arm<3;++arm)readonly_inputs(arm==2?peer:data,*owners[arm]);
  for(auto &owner:owners)owner.reset();
  std::printf("NEW_PRECISION_CASE_DONE case=%s capture=%u Q_KV_readonly=1 both_slots=1 checked_drain=1\n",name,unsigned(capture));
}
}
int main(){
  std::printf("SCOPE new_product_public_ABI=1 peer=same_source_FlashInfer_plain_BF16_native_batch not_external_engine=1 timing=0 model_quality=NOT_MEASURED\n");
  for(unsigned capture=0;capture<2;++capture){precision_case("cancellation-large",0x70,0x71,capture!=0);precision_case("cancellation-unit",0x38,0x39,capture!=0);}
  std::printf("NEW_PRECISION_DONE cases=2 capture_modes=2 slots=2 peer_all_words_equal=1 default_all_words_RNE=1 EXIT=0\n");return 0;
}
'''

tail=original[original.index('using Clock='):]
old='Data data(q1,q2,k1,k2,dk,dv,causal,window);std::unique_ptr<Harness> h[2];'
new='''Data data(q1,q2,k1,k2,dk,dv,causal,window);const auto expand_start=Clock::now();auto peer=plain_bf16_peer(data);
  std::printf("COLD_EXPANSION capture=%u alloc=%u order=%u shape=%s host_us=%.9f source_FP8_bytes=%zu expanded_BF16_bytes=%zu outside_warm_timing=1\\n",unsigned(captured),alloc,order,shape,us(Clock::now()-expand_start),data.packed[0].size()+data.packed[1].size(),peer.packed[0].size()+peer.packed[1].size());
  std::unique_ptr<Harness> h[2];'''
assert tail.count(old)==1;tail=tail.replace(old,new)
tail=tail.replace('std::make_unique<Harness>(data,side==0,captured)','std::make_unique<Harness>(side==0?peer:data,side==0,captured)')
tail=tail.replace('h[side]->verify(data,expected)','h[side]->verify(side==0?peer:data,expected)')
tail=tail.replace('product_single_factory=1 baseline_f32=1 treatment_bf16=1','product_single_factory=1 control=same_source_plainBF16_native_batch treatment=FP8_optinBF16partial not_external_engine=1')
tail=tail.replace('    measure(alloc,order,replay!=0,1,17,1024,768,256,256,true,16);\n','')
tail=tail.replace('    measure(alloc,order,replay!=0,17,1,7,47,64,128,false,-1);\n','')

build_template=r'''from pathlib import Path
import hashlib,json,subprocess,sys,time
repo=Path('/mnt/c/public/project-hyle/hyle');name='__NAME__'
out=repo/'.scratch'/name;work=Path('/root/hyle-scratch/compute-unified')/name;work.mkdir(exist_ok=True)
source=out/'consumer.cc';(work/'consumer.cc').write_bytes(source.read_bytes())
commands=json.loads((repo/'.scratch/g04-bf16-product-bench/commands.json').read_text())
old=Path('/root/hyle-scratch/compute-unified/g04-bf16-product-bench')
for stage,args in commands.items():
 commands[stage]=[str(work/'consumer.cc') if x==str(old/'consumer.cc') else str(work/'consumer.o') if x==str(old/'consumer.o') else str(work/'consumer') if x==str(old/'product_bench') else '-Wl,-Map='+str(work/'link.map') if x=='-Wl,-Map='+str(old/'link.map') else x for x in args]
(out/'commands.json').write_text(json.dumps(commands,indent=2)+'\n')
stage='compile' if '--compile-only' in sys.argv else 'link';start=time.monotonic()
with (out/(stage+'.log')).open('w') as f:r=subprocess.run(commands[stage],stdout=f,stderr=subprocess.STDOUT)
result={'stage':stage,'seconds':time.monotonic()-start,'exit_code':r.returncode,'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'gpu_executed':False}
if (work/'consumer').exists():result['binary_sha256']=hashlib.sha256((work/'consumer').read_bytes()).hexdigest()
(out/('build-'+stage+'.json')).write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result));raise SystemExit(r.returncode)
'''
for name,body in [('g04-bf16-product-precision',prefix+peer_helper+precision),
                  ('g04-bf16-product-peer-bench',prefix+peer_helper+tail)]:
 out=repo/'.scratch'/name;out.mkdir(exist_ok=True);(out/'consumer.cc').write_text(body)
 (out/'build.py').write_text(build_template.replace('__NAME__',name))
 identity={'source_sha256':hashlib.sha256((out/'consumer.cc').read_bytes()).hexdigest(),
           'base_product_bench_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),
           'peer':'same-source FlashInfer plain BF16 native batch, exact cold FP8 decode and .5/2 scale; not an external engine',
           'gpu_executed':False,'changes_to_frozen_tests_or_product':False}
 (out/'source-identity.json').write_text(json.dumps(identity,indent=2)+'\n');print(name,json.dumps(identity))
