"""Host syntax check only; no link, native CUDA compile, or GPU execution."""
import json
import subprocess
from pathlib import Path

root=Path('/mnt/c/public/project-hyle/hyle')
argv=['/usr/bin/g++-14','-std=c++23','-fsyntax-only','-Wall','-Wextra','-Werror',
      '-DHYLE_STATIC','-DHYLE_COMPUTE_FLASHINFER=1','-DHYLE_COMPUTE_CUDA=1',
      '-I'+str(root/'include'),'-I/usr/local/cuda-13.3/targets/x86_64-linux/include',
      str(root/'tests/compute_batch/g04_bf16_partials_consumer.cc')]
r=subprocess.run(argv,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
target=root/'.scratch/g04-g05-sameprocess-review/public-policy-syntax-result.json'
target.write_text(json.dumps({'argv':argv,'exit_code':r.returncode,'output':r.stdout},indent=2)+'\n')
print(r.stdout)
print('host syntax exit',r.returncode)
raise SystemExit(r.returncode)
