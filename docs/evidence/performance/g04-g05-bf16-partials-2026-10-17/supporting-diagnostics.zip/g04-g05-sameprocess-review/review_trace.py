"""Independently correlate existing Nsight rows; never launch GPU work."""
import bisect
from collections import defaultdict
import hashlib
import json
from pathlib import Path
import sqlite3
import statistics

base = Path(__file__).resolve().parents[1] / "g04-same-process-ilp/run-trace-1"
database = base / "profile.sqlite"
db = sqlite3.connect(database.as_uri() + "?mode=ro&immutable=1", uri=True)
shapes = db.execute("select start,end,text from NVTX_EVENTS where text in ('window','prefill','holdout') order by start").fetchall()
episodes = db.execute("select start,end,text from NVTX_EVENTS where text in ('control.episode','treatment.episode') order by start").fetchall()
assert len(shapes) == 12 and len(episodes) == 12288
shape_starts, episode_starts = [x[0] for x in shapes], [x[0] for x in episodes]
api = defaultdict(list)
for table in ("CUPTI_ACTIVITY_KIND_RUNTIME", "CUPTI_ACTIVITY_KIND_DRIVER"):
    if db.execute("select count(*) from sqlite_master where name=?", (table,)).fetchone()[0]:
        for start, end, correlation in db.execute("select start,end,correlationId from " + table):
            api[correlation].append((start, end))
kernels = db.execute("select k.start,k.end,k.correlationId,k.registersPerThread,k.dynamicSharedMemory,k.localMemoryPerThread,n.value,k.blockX,k.blockY,k.blockZ from CUPTI_ACTIVITY_KIND_KERNEL k join StringIds n on n.id=k.demangledName order by k.start").fetchall()
mapped = defaultdict(list)
for start, end, correlation, registers, shared, local, name, *block in kernels:
    launches = api[correlation]
    if not launches:
        continue
    launch = min(launches)[0]
    index = bisect.bisect_right(episode_starts, launch) - 1
    if index < 0 or launch > episodes[index][1]:
        continue
    kind = "attention" if "BatchPrefillWithPagedKVCacheKernel" in name else "merge" if "MergeStates" in name else None
    assert kind and local == 0
    mapped[index].append({"kind": kind, "us": (end - start) / 1000,
                          "registers": registers, "shared": shared,
                          "block": block, "correlation": correlation})
assert len(mapped) == 12288 and sum(map(len, mapped.values())) == 16384
supplied = [json.loads(line) for line in (base / "episode-kernels.jsonl").read_text().splitlines()]
assert len(supplied) == len(episodes)
samples = defaultdict(list)
for index, (start, end, label) in enumerate(episodes):
    shape_index = bisect.bisect_right(shape_starts, start) - 1
    low, high, shape = shapes[shape_index]
    assert low <= start <= end <= high
    alloc, order = shape_index // 6, (shape_index // 3) % 2
    assert shape == ("window", "prefill", "holdout")[shape_index % 3]
    side = label.split(".")[0]
    row = supplied[index]
    assert (row["index"], row["shape"], row["alloc"], row["order"], row["side"]) == (index, shape, alloc, order, side)
    assert len(mapped[index]) == (2 if shape == "prefill" else 1)
    for kernel in mapped[index]:
        original = next(k for k in row["kernels"] if k["kind"] == kernel["kind"])
        assert kernel["us"] == original["us"] and kernel["registers"] == original["registers"] and kernel["correlation"] == original["correlation"]
        if shape == "prefill" and kernel["kind"] == "attention":
            assert kernel["registers"] == (248 if side == "control" else 250)
            assert kernel["shared"] == 49152 and kernel["block"] == [32, 4, 1]
        if shape == "prefill" and kernel["kind"] == "merge":
            assert kernel["registers"] == 48 and kernel["shared"] == 8704
        samples[alloc, order, shape, side, kernel["kind"]].append(kernel["us"])
results = []
for alloc in (0, 1):
    for order in (0, 1):
        for shape in ("window", "prefill", "holdout"):
            stages = {}
            for kind in (("attention", "merge") if shape == "prefill" else ("attention",)):
                c, t = (samples[alloc, order, shape, s, kind] for s in ("control", "treatment"))
                assert len(c) == len(t) == 512
                cm, tm = statistics.fmean(c), statistics.fmean(t)
                stages[kind] = {"control_mean_us": cm, "treatment_mean_us": tm,
                                "latency_change_percent": 100 * (tm / cm - 1)}
            results.append({"alloc": alloc, "order": order, "shape": shape, "gpu_stages": stages})
report = {"kind": "INDEPENDENT_REVIEW_OF_ONE_EXISTING_TRACE",
          "episodes": len(episodes), "timed_kernels": sum(map(len, mapped.values())),
          "outside_timed_kernels": len(kernels) - sum(map(len, mapped.values())),
          "actual_target_routing": "Every control prefill attention has 248 registers; every treatment has 250; local=0, dynamicShared=49152, block32x4x1.",
          "supplied_episode_mapping_matches_raw_sqlite": True,
          "scope": "Trace explains GPU routing/stages only. Its host wall is never substituted for ordinary complete-episode primary.",
          "strata": results,
          "source_sha256": {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in (database, base / "episode-kernels.jsonl", base / "identity.json")}}
target = Path(__file__).with_name("trace-review.json")
target.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
for row in results:
    if row["shape"] == "prefill":
        print(row["alloc"], row["order"], row["gpu_stages"])
db.close()
