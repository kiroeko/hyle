from pathlib import Path

repo = Path(__file__).resolve().parents[2]
template = '''"""Run once only when invoked by the sole GPU runner."""
from pathlib import Path
import hashlib,json,os,subprocess,time

repo=Path('/mnt/c/public/project-hyle/hyle')
out=repo/'.scratch'/'TASK'
work=Path('/root/hyle-scratch/compute-unified/TASK')
binary=work/'consumer'
dest=out/'run-ordinary-1'
dest.mkdir(exist_ok=False)
source=out/'consumer.cc'
commands=json.loads((out/'commands.json').read_text())
inputs={}
for arg in commands['link']:
    path=Path(arg)
    if arg.endswith('.a') and path.is_file():
        inputs[arg]=hashlib.sha256(path.read_bytes()).hexdigest()
info={'argv':[str(binary)],'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),
      'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),
      'linked_static_inputs_sha256':inputs,'CUDA_VISIBLE_DEVICES':os.environ.get('CUDA_VISIBLE_DEVICES'),
      'G04_TRACE':os.environ.get('G04_TRACE'),'started_unix':time.time()}
assert not info['G04_TRACE'], 'This is the unprofiled ordinary measurement'
gpu=subprocess.run(['/usr/lib/wsl/lib/nvidia-smi','--query-gpu=name,uuid,driver_version,memory.used,temperature.gpu','--format=csv,noheader'],capture_output=True,text=True)
info['gpu_pre']={'returncode':gpu.returncode,'stdout':gpu.stdout,'stderr':gpu.stderr}
(dest/'identity.json').write_text(json.dumps(info,indent=2)+'\\n')
print(json.dumps({'argv':info['argv'],'dest':str(dest)}),flush=True)
start=time.monotonic()
with (dest/'stdout.log').open('w') as stdout,(dest/'stderr.log').open('w') as stderr:
    result=subprocess.run(info['argv'],stdout=stdout,stderr=stderr)
info.update({'returncode':result.returncode,'elapsed_s':time.monotonic()-start})
(dest/'result.json').write_text(json.dumps(info,indent=2)+'\\n')
print(json.dumps({'returncode':result.returncode,'elapsed_s':info['elapsed_s']}),flush=True)
raise SystemExit(result.returncode)
'''
for name in ('g04-bf16-product-precision','g04-bf16-product-peer-bench'):
    (repo/'.scratch'/name/'run.py').write_text(template.replace('TASK',name),encoding='utf-8')
