"""Independent retained-log and mathematical-oracle review; no GPU execution."""
import argparse
import hashlib
import json
import math
from pathlib import Path
import struct


def fields(line):
    return dict(item.split('=',1) for item in line.split()[1:] if '=' in item)


def bf16_rne(value):
    bits=struct.unpack('<I',struct.pack('<f',value))[0]
    word=((bits+0x7fff+((bits>>16)&1))>>16)&0xffff
    return struct.unpack('<f',struct.pack('<I',word<<16))[0]


def expected(case):
    positive,perturbed=(128.,144.) if case=='cancellation-large' else (1.,1.125)
    prefix=[0.]
    for row in range(8192):
        value=(perturbed if row%64==0 else positive) if row<4096 else -positive
        prefix.append(prefix[-1]+value*2.)
    rows=[]
    for nq in (64,128):
        for row in range(nq):
            count=8192-nq+row+1;rows.append(prefix[count]/count)
    rounded=[bf16_rne(v) for v in rows]
    return {'final':rows[-1],'elements':len(rows)*8*256,
            'maximum_RNE_error':max(abs(a-b) for a,b in zip(rows,rounded)),
            'mean_RNE_error':sum(abs(a-b) for a,b in zip(rows,rounded))/len(rows),
            'max_relative_RNE_error':max(abs(a-b)/abs(a) for a,b in zip(rows,rounded))}


def review(text):
    precision={};peer={};done=set()
    cases=('cancellation-large','cancellation-unit')
    arms=('fp8_f32','fp8_bf16partial','plain_bf16_same_source_peer')
    mathematical={case:expected(case) for case in cases}
    for line in text.splitlines():
        if line.startswith('NEW_PRECISION '):
            row=fields(line);key=(row['case'],int(row['capture']),int(row['slot']),row['arm'])
            assert key not in precision
            oracle=mathematical[key[0]]
            assert int(row['elements'])==oracle['elements']==393216
            assert math.isclose(float(row['final_expected']),oracle['final'],rel_tol=1e-11)
            assert int(row['actual_optin'])==(key[3]=='fp8_bf16partial')
            if key[3]=='fp8_f32':
                assert int(row['different_RNE_words'])==0 and float(row['max_vs_RNE'])==0
                for field,value in (('max_abs',oracle['maximum_RNE_error']),('mean_abs',oracle['mean_RNE_error']),('max_relative',oracle['max_relative_RNE_error'])):
                    assert math.isclose(float(row[field]),value,rel_tol=2e-10,abs_tol=2e-12),(field,row[field],value)
                assert float(row['final_actual'])==oracle['final']
            else:
                known=.08251953125 if key[0]=='cancellation-large' else .000644683837890625
                assert math.isclose(float(row['final_actual']),known,rel_tol=1e-11)
            precision[key]=row
        elif line.startswith('NEW_PRECISION_PEER '):
            row=fields(line);key=(row['case'],int(row['capture']),int(row['slot']))
            assert key not in peer and int(row['compared_words'])==393216
            assert int(row['different_words'])==0 and float(row['max_abs_difference'])==0
            peer[key]=row
        elif line.startswith('NEW_PRECISION_CASE_DONE '):
            row=fields(line);key=(row['case'],int(row['capture']))
            assert key not in done and row['Q_KV_readonly']=='1' and row['both_slots']=='1' and row['checked_drain']=='1'
            done.add(key)
    assert set(precision)=={(case,capture,slot,arm) for case in cases for capture in (0,1) for slot in (0,1) for arm in arms}
    assert set(peer)=={(case,capture,slot) for case in cases for capture in (0,1) for slot in (0,1)}
    assert done=={(case,capture) for case in cases for capture in (0,1)}
    assert text.rstrip().endswith('NEW_PRECISION_DONE cases=2 capture_modes=2 slots=2 peer_all_words_equal=1 default_all_words_RNE=1 EXIT=0')
    rows=[]
    for key,row in sorted(precision.items()):
        rows.append({'case':key[0],'capture':key[1],'slot':key[2],'arm':key[3],**row})
    return {'kind':'INDEPENDENT_NEW_PRODUCT_PRECISION_REVIEW',
            'mathematical_double_prefix_and_RNE_recomputed':mathematical,
            'rows':rows,'peer_all_words_checks':list(peer.values()),
            'comparisons_checked':24,'peer_word_comparisons_reported':393216*8,
            'new_product_default_all_outputs_RNE':True,'new_product_optin_same_source_peer_word_parity':True,
            'limits':['Two constructed cancellation amplitudes; V scale is 2 in both. Not a model quality evaluation.',
                      'Same-source FlashInfer plain BF16 KV math comparison, not an external engine claim.',
                      'Mathematical double prefix and default RNE summaries independently recomputed; all-word GPU parity relies on reviewed executable comparisons and retained logs, not a second GPU readback.',
                      'The opt-in intentionally loses a cancellation residual versus default F32 while matching this BF16 peer.']}


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('log',type=Path);parser.add_argument('--output',type=Path)
    args=parser.parse_args();raw=args.log.read_bytes();result=review(raw.decode())
    result['source_log']=str(args.log.resolve());result['source_log_sha256']=hashlib.sha256(raw).hexdigest()
    if args.output:args.output.write_text(json.dumps(result,indent=2)+'\n')
    else:print(json.dumps(result,indent=2))
    print('24 precision records, 8 all-word peer comparisons and independent default RNE oracle verified')


if __name__=='__main__':main()
