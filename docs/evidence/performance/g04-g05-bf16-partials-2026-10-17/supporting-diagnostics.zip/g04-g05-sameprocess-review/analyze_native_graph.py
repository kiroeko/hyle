"""Analyze retained same-buffer native CUDA-graph event samples, without GPU work."""
import argparse
from collections import defaultdict
import hashlib
import json
import math
from pathlib import Path
import statistics

PAIRS=('00-orig','00-10','01-11','00-01','10-11','00-11')

def fields(line):
    return dict(x.split('=',1) for x in line.split()[1:] if '=' in x)

def distribution(values):
    values=sorted(values)
    result={'count':len(values),'arithmetic_mean_us':statistics.fmean(values),'min_us':min(values),'max_us':max(values)}
    for label,fraction in [('p50',.5),('p90',.9),('p95',.95),('p99',.99)]:
        at=(len(values)-1)*fraction;lo=math.floor(at);hi=math.ceil(at)
        result[label+'_us']=values[lo]+(values[hi]-values[lo])*(at-lo)
    return result

def analyze(log):
    samples={};blocks={}
    for number,line in enumerate(log.splitlines(),1):
        if line.startswith('GRAPH_SAMPLE '):
            f=fields(line);key=(f['pair'],int(f['group']),int(f['step']),f['arm'])
            assert key not in samples
            value=float(f['native_us']);total=float(f['graph_us']);repeats=int(f['repeats']);position=int(f['position'])
            assert math.isfinite(value) and value>0 and repeats==64 and math.isfinite(total) and abs(total/repeats-value)<2e-8
            samples[key]={'native_us':value,'graph_us':total,'position':position,'source_line':number}
        elif line.startswith('GRAPH_BLOCK '):
            f=fields(line);key=(f['pair'],int(f['group']),f['arm'])
            assert key not in blocks and int(f['samples'])==8
            blocks[key]=float(f['native_mean_us'])
    expected={(pair,group,step,arm) for pair in PAIRS for group in range(8) for step in range(8) for arm in pair.split('-')}
    assert set(samples)==expected and len(samples)==768 and len(blocks)==96
    for pair in PAIRS:
        a,b=pair.split('-')
        for group in range(8):
            for step in range(8):
                assert {samples[pair,group,step,arm]['position'] for arm in (a,b)}=={0,1}
            for arm in (a,b):
                mean=statistics.fmean(samples[pair,group,step,arm]['native_us'] for step in range(8))
                assert abs(mean-blocks[pair,group,arm])<2e-8
    results=[];contrasts={}
    for pair in PAIRS:
        a,b=pair.split('-');arms={}
        for arm in (a,b):
            values=[samples[pair,g,s,arm]['native_us'] for g in range(8) for s in range(8)]
            positions=[samples[pair,g,s,arm]['position'] for g in range(8) for s in range(8)]
            assert positions.count(0)==positions.count(1)==32
            arms[arm]=distribution(values)
            arms[arm]['position_counts']={str(x):positions.count(x) for x in (0,1)}
        am,bm=(arms[arm]['arithmetic_mean_us'] for arm in (a,b))
        delta=am-bm;contrasts[pair]=delta
        results.append({'pair':pair,'arms':arms,'left_minus_right_us':delta,'right_over_left_change_percent':100*(bm/am-1),
                        'block_left_minus_right_us':[blocks[pair,g,a]-blocks[pair,g,b] for g in range(8)]})
    return {'kind':'INDEPENDENT_SAME_BUFFER_NATIVE_GRAPH_EVENT_ANALYSIS','graph_samples':768,'native_replays_per_graph':64,'timed_native_replays':49152,'printed_blocks_verified':96,
            'all_samples_retained':True,'negative_control_subtraction':False,
            'limits':['GPU-event bracket measures a serial native graph, not public Completion/ownership whole-episode latency.',
                      'The graph uses one shared buffer set and one native plan. The original public benchmark uses separately owned slots.',
                      'Contrasts use separate pair series. Interaction/path closure is reported, not forced, and no same-process result creates independent-process confidence.'],
            'strata':results,
            'contrasts_us':{'carrier_at_F32':contrasts['00-10'],'carrier_at_BF16':contrasts['01-11'],
                            'partial_at_FP8':contrasts['00-01'],'partial_at_BF16':contrasts['10-11'],
                            'interaction_via_carrier':contrasts['00-10']-contrasts['01-11'],
                            'interaction_via_partial':contrasts['00-01']-contrasts['10-11'],
                            'factorial_path_closure_residual':contrasts['00-10']-contrasts['01-11']-contrasts['00-01']+contrasts['10-11'],
                            'direct_00_minus_11':contrasts['00-11'],
                            'direct_vs_carrier_then_partial_residual':contrasts['00-11']-contrasts['00-10']-contrasts['10-11'],
                            'direct_vs_partial_then_carrier_residual':contrasts['00-11']-contrasts['00-01']-contrasts['01-11'],
                            'same_SASS_bridge_00_minus_orig':contrasts['00-orig']}}

def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('log',type=Path);parser.add_argument('--output',type=Path)
    args=parser.parse_args();raw=args.log.read_bytes();result=analyze(raw.decode())
    result['source_log']=str(args.log.resolve());result['source_log_sha256']=hashlib.sha256(raw).hexdigest()
    if args.output:args.output.write_text(json.dumps(result,indent=2)+'\n')
    else:print(json.dumps(result,indent=2))
    for row in result['strata']:print(row['pair'],row['left_minus_right_us'],row['right_over_left_change_percent'])

if __name__=='__main__':main()
