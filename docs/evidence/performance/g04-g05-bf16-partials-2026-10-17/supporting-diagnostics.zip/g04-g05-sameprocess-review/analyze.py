"""Read-only paired analysis of the ordinary same-process load-ILP log.

Ratio = treatment latency / control latency; below one favors treatment.
Every complete episode is retained. No trimming or negative-control subtraction.
"""

import argparse
from collections import defaultdict
import hashlib
import json
import math
from pathlib import Path
import statistics


SHAPES = ("window", "prefill", "holdout")


def percentile(values, fraction):
    ordered = sorted(values)
    index = (len(ordered) - 1) * fraction
    lo = math.floor(index)
    hi = math.ceil(index)
    return ordered[lo] + (ordered[hi] - ordered[lo]) * (index - lo)


def distribution(values):
    return {
        "count": len(values),
        "arithmetic_mean_us": statistics.fmean(values),
        "min_us": min(values),
        **{f"p{int(p * 100)}_us": percentile(values, p)
           for p in (.5, .9, .95, .99)},
        "max_us": max(values),
    }


def parse(text):
    records = []
    for line_number, line in enumerate(text.splitlines(), 1):
        words = line.split()
        if not words or words[0] not in {"PAIR", "BLOCK", "COLD", "CLOSE"}:
            continue
        record = {"kind": words[0], "source_line": line_number}
        for word in words[1:]:
            key, value = word.split("=", 1)
            if key in record:
                raise ValueError(f"duplicate field at line {line_number}: {key}")
            record[key] = value
        for key in ("alloc", "order"):
            record[key] = int(record[key])
            assert record[key] in (0, 1), record
        assert record["shape"] in (SHAPES + (("tail",) if record["kind"] in {"COLD", "CLOSE"} else ())), record
        for key in ("group", "step", "count", "side"):
            if key in record:
                record[key] = int(record[key])
        for key in ("control_us", "treatment_us", "create_us", "close_us"):
            if key in record:
                record[key] = float(record[key])
                assert math.isfinite(record[key]) and record[key] > 0, record
        records.append(record)
    return records


def analyze(records, expected_groups=8, group_size=64):
    pairs, blocks, cold, close = {}, {}, [], []
    for row in records:
        stratum = row["alloc"], row["order"], row["shape"]
        if row["kind"] == "PAIR":
            key = (*stratum, row["group"], row["step"])
            assert key not in pairs, ("duplicate episode", key)
            pairs[key] = row
        elif row["kind"] == "BLOCK":
            key = (*stratum, row["group"])
            assert key not in blocks, ("duplicate block", key)
            blocks[key] = row
        elif row["kind"] == "COLD":
            cold.append(row)
        else:
            close.append(row)
    expected_strata = {(a, o, s) for a in (0, 1) for o in (0, 1) for s in SHAPES}
    expected_pairs = {(*k, g, i) for k in expected_strata
                      for g in range(expected_groups) for i in range(group_size)}
    expected_blocks = {(*k, g) for k in expected_strata for g in range(expected_groups)}
    assert set(pairs) == expected_pairs, ("incomplete/unexpected paired matrix", len(pairs))
    assert set(blocks) == expected_blocks, ("incomplete/unexpected block matrix", len(blocks))
    for kind, rows, field in (("COLD", cold, "create_us"), ("CLOSE", close, "close_us")):
        identity = [(r["alloc"], r["order"], r["shape"], r["side"]) for r in rows]
        expected = {(*k, side) for k in expected_strata for side in (0, 1)}
        expected |= {(0, 0, "tail", side) for side in (0, 1)}
        assert len(identity) == len(set(identity)) and set(identity) == expected, (kind, identity)
        assert all(field in r for r in rows), kind

    strata, pooled = [], defaultdict(list)
    for alloc, order, shape in sorted(expected_strata):
        rows = [pairs[alloc, order, shape, g, i]
                for g in range(expected_groups) for i in range(group_size)]
        block_results = []
        for group in range(expected_groups):
            group_rows = [pairs[alloc, order, shape, group, i] for i in range(group_size)]
            block = blocks[alloc, order, shape, group]
            assert block["count"] == group_size, block
            control = statistics.fmean(r["control_us"] for r in group_rows)
            treatment = statistics.fmean(r["treatment_us"] for r in group_rows)
            for field, value in (("control_us", control), ("treatment_us", treatment)):
                assert math.isclose(block[field], value, rel_tol=5e-9, abs_tol=1e-6), (block, value)
            block_results.append({"group": group, "count": group_size,
                                  "control_arithmetic_mean_us": control,
                                  "treatment_arithmetic_mean_us": treatment,
                                  "treatment_over_control": treatment / control,
                                  "latency_change_percent": 100 * (treatment / control - 1),
                                  "delta_us": treatment - control})
        c = [r["control_us"] for r in rows]
        t = [r["treatment_us"] for r in rows]
        ratios = [r["treatment_us"] / r["control_us"] for r in rows]
        threshold_c, threshold_t = percentile(c, .99), percentile(t, .99)
        strata.append({
            "shape": shape, "allocation_order": "treatment-first" if alloc else "control-first",
            "execution_order": "treatment-first" if order else "control-first",
            "control": distribution(c), "treatment": distribution(t),
            "ratio_of_all_arithmetic_means": statistics.fmean(t) / statistics.fmean(c),
            "latency_change_percent": 100 * (statistics.fmean(t) / statistics.fmean(c) - 1),
            "paired_episode_median_ratio": statistics.median(ratios),
            "paired_episode_treatment_faster": sum(x < 1 for x in ratios),
            "paired_episode_equal": sum(x == 1 for x in ratios),
            "paired_episode_treatment_slower": sum(x > 1 for x in ratios),
            "block_treatment_faster": sum(b["delta_us"] < 0 for b in block_results),
            "blocks": block_results,
            "individual_tail_pairs_at_or_above_either_p99": [r for r in rows
                if r["control_us"] >= threshold_c or r["treatment_us"] >= threshold_t],
        })
        pooled[shape].extend(rows)
    pooled_results = []
    for shape in SHAPES:
        rows = pooled[shape]
        c, t = ([r[f"{side}_us"] for r in rows] for side in ("control", "treatment"))
        pooled_results.append({"shape": shape, "control": distribution(c),
                               "treatment": distribution(t),
                               "ratio_of_all_arithmetic_means": statistics.fmean(t) / statistics.fmean(c),
                               "latency_change_percent": 100 * (statistics.fmean(t) / statistics.fmean(c) - 1)})
    return {
        "kind": "READ_ONLY_SAME_PROCESS_PAIRED_EPISODE_ANALYSIS",
        "ratio_definition": "treatment complete-episode latency / control latency; below 1 favors treatment",
        "episode_pairs": len(pairs), "blocks": len(blocks),
        "expected_groups_per_stratum": expected_groups, "episodes_per_block": group_size,
        "all_samples_retained": True, "outlier_trimming": False,
        "negative_control_subtraction": False,
        "limits": ["Descriptive results from one ordinary same-process measurement; no independent-process confidence claim.",
                   "Host wall and GPU kernel time are different quantities; profiler host time is not an ordinary timing result.",
                   "Cold setup/teardown rows are kept separate and are never deducted from warm episodes."],
        "strata": strata, "pooled_equal_count_matrix": pooled_results,
        "cold_setup": cold, "close": close,
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("log", type=Path)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    raw = args.log.read_bytes()
    result = analyze(parse(raw.decode("utf-8")))
    result["source_log"] = str(args.log.resolve())
    result["source_log_sha256"] = hashlib.sha256(raw).hexdigest()
    if args.output:
        args.output.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    else:
        print(json.dumps(result, indent=2))
    for row in result["strata"]:
        print(row["shape"], row["allocation_order"], row["execution_order"],
              f"latency_change={row['latency_change_percent']:+.4f}%",
              f"faster_blocks={row['block_treatment_faster']}/8")


if __name__ == "__main__":
    main()
