from pathlib import Path
import hashlib
import json
import subprocess
import time

root=Path('/mnt/c/public/project-hyle/hyle')
out=root/'.scratch/g04-bf16-partials-vendor'
source=json.loads((out/'source-result.json').read_text())
include=out/'materialized-production-fixed-signatures/include'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
for name,expected in source['headers'].items():
    assert sha(out/'materialized-production-fixed-signatures'/name)==expected
work=Path('/root/hyle-scratch/compute-unified/g04-bf16-partials-planner-smoke')
work.mkdir(exist_ok=True)
command=['/usr/local/cuda-13.3/bin/nvcc','-ccbin','/usr/bin/g++-14','-std=c++17','-arch=sm_89','-O0',
         '-DFLASHINFER_ENABLE_BF16','-DFLASHINFER_ENABLE_F16','-I'+str(include),
         '-c',str(out/'planner_smoke.cu'),'-o',str(work/'planner_smoke.o')]
t=time.monotonic()
with (out/'planner-smoke.log').open('w') as f:
    p=subprocess.run(command,stdout=f,stderr=subprocess.STDOUT,timeout=120)
result={'state':'COMPILE_PASS_NO_GPU' if p.returncode==0 else 'COMPILE_FAIL_NO_GPU',
        'command':command,'exit':p.returncode,'seconds':time.monotonic()-t,'gpu_executed':False,
        'source_sha256':sha(out/'planner_smoke.cu'),'scheduler_sha256':source['headers']['include/flashinfer/attention/scheduler.cuh'],
        'tree_sha256':source['tree_sha256'],'source_result_sha256':sha(out/'source-result.json'),
        'compile_log_sha256':sha(out/'planner-smoke.log')}
if p.returncode==0:
    result.update(object=str(work/'planner_smoke.o'),object_sha256=sha(work/'planner_smoke.o'))
(out/'planner-smoke.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
if p.returncode:
    print((out/'planner-smoke.log').read_text());raise SystemExit(p.returncode)
