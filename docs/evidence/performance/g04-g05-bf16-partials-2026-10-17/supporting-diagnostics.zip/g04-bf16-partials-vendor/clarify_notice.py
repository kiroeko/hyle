from pathlib import Path
import hashlib
import json
import subprocess
import sys

ROOT=Path(__file__).resolve().parents[2]
OUT=Path(__file__).resolve().parent
sha=lambda b:hashlib.sha256(b).hexdigest()
normalize=lambda b:b.replace(b'\r\n',b'\n').replace(b'\r',b'\n')
folder=ROOT/'third_party/flashinfer_cache'
notice_path=folder/'NOTICE.md';lock_path=ROOT/'cmake/HyleDependencyLock.json'
before_notice=notice_path.read_bytes();before_lock=lock_path.read_bytes()
old=b'No public HYLE API is added.'
new=b'This merge epilogue itself adds no public HYLE API.'
assert before_notice.count(old)==1
notice=before_notice.replace(old,new,1)
lock=json.loads(before_lock);dep=next(x for x in lock['dependencies'] if x['name']=='flashinfer_cache_patches')
old_tree=dep['vendored']['tree_sha256']
notice_sha=sha(normalize(notice))
new_tree=sha(''.join(name+'|'+sha(normalize(data))+'\n' for name,data in sorted({
    'LICENSE':(folder/'LICENSE').read_bytes(),'NOTICE.md':notice,'patches.json':(folder/'patches.json').read_bytes()}.items())).encode())
for item in dep['license']['files']:
    if item['path']=='third_party/flashinfer_cache/NOTICE.md':item['sha256']=notice_sha
dep['vendored']['tree_sha256']=new_tree
lock_bytes=before_lock.replace(sha(normalize(before_notice)).encode(),notice_sha.encode(),1).replace(old_tree.encode(),new_tree.encode(),1)
assert json.loads(lock_bytes)==lock
assert notice_path.read_bytes()==before_notice and lock_path.read_bytes()==before_lock
notice_path.write_bytes(notice);lock_path.write_bytes(lock_bytes)
report_path=OUT/'source-result.json'
previous=report_path.read_bytes();(OUT/'source-result-before-notice-clarification.json').write_bytes(previous)
report=json.loads(previous)
command=[sys.executable,str(ROOT/'src/compute_ggml_runtime/prepare_source.py'),'--source',str(OUT/'upstream'),
         '--output',str(OUT/'materialized-production'),'--manifest',str(folder/'patches.json')]
p=subprocess.run(command,capture_output=True,text=True)
assert p.returncode==0,(p.stdout,p.stderr)
for name,expected in report['headers'].items():assert sha((OUT/'materialized-production'/name).read_bytes())==expected
report.update(tree_sha256=new_tree,notice_sha256=notice_sha,lock_sha256=sha(lock_bytes),
              materializer_command=command,materializer_stdout=p.stdout,
              notice_clarification={'old_tree_sha256':old_tree,'change':'Limit no-public-API claim to the original merge epilogue; BF16 options/report API is separate.',
                                    'manifest_and_derived_header_bytes_unchanged':True})
report_path.write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:report[k] for k in ['tree_sha256','notice_sha256','lock_sha256','manifest_sha256','headers','materializer_stdout']},indent=2))
