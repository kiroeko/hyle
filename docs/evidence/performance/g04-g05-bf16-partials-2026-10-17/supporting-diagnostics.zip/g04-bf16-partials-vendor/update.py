from pathlib import Path
import copy
import difflib
import hashlib
import json
import subprocess
import sys
import tarfile

ROOT=Path(__file__).resolve().parents[2]
OUT=Path(__file__).resolve().parent
ARCHIVE=ROOT/'.scratch/validation/m1-route-binding/m1-cuda-intake/flashinfer-69ff11fc4954396d98326656dc85debd2223f637.tar.gz'
normalize=lambda b:b.replace(b'\r\n',b'\n').replace(b'\r',b'\n')
sha=lambda b:hashlib.sha256(b).hexdigest()
def tree(files):return sha(''.join(name+'|'+sha(normalize(data))+'\n' for name,data in sorted(files.items())).encode())
manifest_path=ROOT/'third_party/flashinfer_cache/patches.json'
notice_path=ROOT/'third_party/flashinfer_cache/NOTICE.md'
lock_path=ROOT/'cmake/HyleDependencyLock.json'
old_manifest=manifest_path.read_bytes();old_notice=notice_path.read_bytes();old_lock=lock_path.read_bytes()
manifest=json.loads(old_manifest);lock=json.loads(old_lock)
dep=next(x for x in lock['dependencies'] if x['name']=='flashinfer_cache_patches')
assert dep['version']=='hyle-flashinfer-direct-fp8-stage-v10'
assert sha(old_manifest)=='1977b83b67495c4aedb391517c2f35c6034ea4b986716591732ddb2612cd1712'
assert sha(ARCHIVE.read_bytes())==dep['archive']['sha256']=='4fc85abaa6210d6a1773e6011ff572aa0c04b7030644b74f75a2db2dbda472a9'
assert tree({'LICENSE':(manifest_path.parent/'LICENSE').read_bytes(),'NOTICE.md':old_notice,'patches.json':old_manifest})==dep['vendored']['tree_sha256']
upstream={};derived={}
with tarfile.open(ARCHIVE) as tar:
    prefix=tar.getnames()[0].split('/')[0]+'/'
    for item in manifest['files']:
        data=normalize(tar.extractfile(prefix+item['path']).read())
        upstream[item['path']]=data;assert sha(data)==item['before_sha256']
        for edit in item['edits']:
            a,b=edit['before'].encode(),edit['after'].encode();assert data.count(a)==1
            data=data.replace(a,b,1)
        assert sha(data)==item['after_sha256'];derived[item['path']]=data
    scheduler_name='include/flashinfer/attention/scheduler.cuh'
    upstream[scheduler_name]=normalize(tar.extractfile(prefix+scheduler_name).read())

prefill=next(x for x in manifest['files'] if x['path']=='include/flashinfer/attention/prefill.cuh')
before=derived[prefill['path']].decode('utf-8')
prefill_edits=[{
  'before':'template <MaskMode MASK_MODE_, uint32_t CTA_TILE_Q_',
  'after':'''template <typename Variant, typename = void>
struct HyleBf16Partials : std::false_type {};
template <typename Variant>
struct HyleBf16Partials<Variant, std::void_t<decltype(Variant::hyle_bf16_partials)>>
    : std::bool_constant<Variant::hyle_bf16_partials> {};

template <MaskMode MASK_MODE_, uint32_t CTA_TILE_Q_'''
},{
  'before':'USE_KV_REPACK && std::is_same_v<DTypeO_, float> &&',
  'after':'''USE_KV_REPACK &&
       (std::is_same_v<DTypeO_, float> ||
        (HyleBf16Partials<AttentionVariant_>::value && std::is_same_v<DTypeO_, __nv_bfloat16> &&
         HEAD_DIM_QK == 256 && HEAD_DIM_VO == 256 && CTA_TILE_Q == 64)) &&'''
}]
after=before
for edit in prefill_edits:
    assert after.count(edit['before'])==1
    after=after.replace(edit['before'],edit['after'],1)
prefill['edits'].extend(prefill_edits);prefill['after_sha256']=sha(after.encode())
derived[prefill['path']]=after.encode()

scheduler_before=upstream[scheduler_name].decode('utf-8')
scheduler_edits=[
 {'before':'    int64_t uniform_q_len, cudaStream_t stream, uint32_t kv_dtype_bytes = 2) {',
  'after':'    int64_t uniform_q_len, cudaStream_t stream, uint32_t kv_dtype_bytes = 2,\n    bool hyle_bf16_partials = false) {'},
 {'before':'                               int64_t uniform_q_len, cudaStream_t stream,\n                               uint32_t kv_dtype_bytes = 2) {',
  'after':'                               int64_t uniform_q_len, cudaStream_t stream,\n                               uint32_t kv_dtype_bytes = 2, bool hyle_bf16_partials = false) {'},
 {'before':'    bool disable_split_kv, int64_t num_colocated_ctas, int64_t uniform_q_len, cudaStream_t stream,\n    uint32_t kv_dtype_bytes = 2) {',
  'after':'    bool disable_split_kv, int64_t num_colocated_ctas, int64_t uniform_q_len, cudaStream_t stream,\n    uint32_t kv_dtype_bytes = 2, bool hyle_bf16_partials = false) {'},
 {'before':'''    plan_info.v_offset = float_allocator.aligned_alloc_offset(
        num_qo_heads * padded_batch_size * cta_tile_q * head_dim_vo * sizeof(float), 16,
        "batch_prefill_tmp_v");''',
  'after':'''    // The caller admits the private BF16-partial domain. Select its width
    // only after this same query/materialize implementation chose the tile.
    const size_t partial_value_bytes =
        hyle_bf16_partials && plan_info.cta_tile_q == 64 && plan_info.split_kv
            ? sizeof(uint16_t)
            : sizeof(float);
    plan_info.v_offset = float_allocator.aligned_alloc_offset(
        num_qo_heads * padded_batch_size * cta_tile_q * head_dim_vo * partial_value_bytes, 16,
        "batch_prefill_tmp_v");'''},
 {'before':'                               uniform_q_len, stream, kv_dtype_bytes);',
  'after':'                               uniform_q_len, stream, kv_dtype_bytes, hyle_bf16_partials);'},
 {'before':'                                num_colocated_ctas, uniform_q_len, stream, kv_dtype_bytes);',
  'after':'                                num_colocated_ctas, uniform_q_len, stream, kv_dtype_bytes,\n                                hyle_bf16_partials);'}
]
scheduler_after=scheduler_before
for edit in scheduler_edits:
    assert scheduler_after.count(edit['before'])==1,(scheduler_after.count(edit['before']),edit['before'])
    scheduler_after=scheduler_after.replace(edit['before'],edit['after'],1)
manifest['files'].append({'path':scheduler_name,'before_sha256':sha(upstream[scheduler_name]),
                          'after_sha256':sha(scheduler_after.encode()),'edits':scheduler_edits})
derived[scheduler_name]=scheduler_after.encode()
manifest['scope']+='; explicit private D256 CTA64 BF16 partial marker and shared query/materialize workspace width selection, default FP32 retained'
new_manifest=(json.dumps(manifest,indent=2)+'\n').encode()
notice=normalize(old_notice).replace(b'FP32 partials and accumulation remain\nunchanged;',b'By default, FP32 partials and accumulation remain\nunchanged;',1)
assert notice!=normalize(old_notice)
notice+=b'''
An explicit private BF16-partial attention marker also admits the existing
direct FP8 tile producer for BF16 output at equal D256 and CTA64. All other
direct-stage gates, the packed decoder, shared layout and synchronization
remain unchanged; this does not include the unadopted K-load or overlap experiments.
The caller opts into intermediate BF16 partial values while attention and
merge accumulation remain FP32. Final scaling still precedes the final output
cast. Intermediate rounding can differ from the default FP32-partial path.

The private prefill planner accepts a default-false BF16-partial flag after
kv_dtype_bytes. Query and materialization share one implementation: only an
enabled flag with the actual split CTA64 plan uses two bytes per temporary
value; other plans retain four. Temporary scores remain FP32. The native
adapter must admit the finite domain before passing this flag and select
the same predicate for execution. This changes required workspace bytes;
actual reserved memory still follows the caller's workspace cap.
'''
version=dep['version'];old_tree=dep['vendored']['tree_sha256']
dep['version']='hyle-flashinfer-bf16-partials-v11'
notice_sha=sha(notice)
for item in dep['license']['files']:
    if item['path']=='third_party/flashinfer_cache/NOTICE.md':item['sha256']=notice_sha
new_tree=tree({'LICENSE':(manifest_path.parent/'LICENSE').read_bytes(),'NOTICE.md':notice,'patches.json':new_manifest})
dep['vendored']['tree_sha256']=new_tree
new_lock=old_lock.replace(version.encode(),dep['version'].encode(),1)
for old,new in [(sha(normalize(old_notice)),notice_sha),(old_tree,new_tree)]:
    assert new_lock.count(old.encode())==1
    new_lock=new_lock.replace(old.encode(),new.encode(),1)
assert json.loads(new_lock)==lock

# Authenticate and materialize the whole pinned source, not three detached headers.
upstream_dir=OUT/'upstream'
if not upstream_dir.exists():
    upstream_dir.mkdir()
    with tarfile.open(ARCHIVE) as tar:
        for entry in tar.getmembers():
            parts=Path(entry.name).parts[1:]
            if not parts:continue
            assert '..' not in parts and not entry.issym() and not entry.islnk()
            target=upstream_dir.joinpath(*parts)
            if entry.isdir():target.mkdir(parents=True,exist_ok=True)
            elif entry.isfile():target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(tar.extractfile(entry).read())
            else:raise ValueError(entry.name)
for name,data in upstream.items():assert normalize((upstream_dir/name).read_bytes())==data
for path,data,original in [(manifest_path,new_manifest,old_manifest),(notice_path,notice,old_notice),(lock_path,new_lock,old_lock)]:
    assert path.read_bytes()==original,'Concurrent edit: '+str(path)
    path.write_bytes(data)
command=[sys.executable,str(ROOT/'src/compute_ggml_runtime/prepare_source.py'),'--source',str(upstream_dir),
         '--output',str(OUT/'materialized-production'),'--manifest',str(manifest_path)]
p=subprocess.run(command,capture_output=True,text=True)
assert p.returncode==0,(p.stdout,p.stderr)
for item in manifest['files']:
    assert sha((OUT/'materialized-production'/item['path']).read_bytes())==item['after_sha256']
assert (OUT/'materialized-production/include/flashinfer/attention/cascade.cuh').read_bytes()==derived['include/flashinfer/attention/cascade.cuh']
assert b'Load both packed K vectors' not in derived[prefill['path']]
assert b'overlap_probe' not in derived[prefill['path']]
for name,a,b in [('prefill',before,after),('scheduler',scheduler_before,scheduler_after)]:
    (OUT/(name+'-before.cuh')).write_bytes(a.encode())
    (OUT/(name+'-after.cuh')).write_bytes(b.encode())
    (OUT/(name+'.diff')).write_bytes(''.join(difflib.unified_diff(a.splitlines(True),b.splitlines(True),fromfile='before/'+name,tofile='after/'+name)).encode())
report={'state':'CANONICAL_VENDOR_UPDATED_AND_MATERIALIZED_NO_COMPILE_NO_GPU','gpu_executed':False,
 'archive_sha256':sha(ARCHIVE.read_bytes()),'version':dep['version'],'old_tree_sha256':old_tree,'tree_sha256':new_tree,
 'manifest_sha256':sha(new_manifest),'notice_sha256':notice_sha,'lock_sha256':sha(new_lock),
 'headers':{item['path']:item['after_sha256'] for item in manifest['files']},
 'materialized_source':str(OUT/'materialized-production'),'materializer_command':command,'materializer_stdout':p.stdout,
 'whole_source_file_count':sum(1 for path in (OUT/'materialized-production').rglob('*') if path.is_file()),
 'scheduler_tail_parameter':'kv_dtype_bytes=2, bool hyle_bf16_partials=false',
 'marker':'AttentionVariant::hyle_bf16_partials',
 'source_checks':{'query_materialize_share_impl':True,'scores_remain_f32':True,'default_false_retains_f32':True,'no_dual_k_or_overlap':True},
 'fixture_workspace_arithmetic':{'tmp_values_f32':20971520,'tmp_values_bf16':10485760,'scores_f32':81920,
   'total_default':21053440,'total_bf16':10567680,'cap_11_mib':11534336,
   'status':'source arithmetic only; actual cap allocation test belongs to native consumer run'}}
(OUT/'source-result.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
print(json.dumps(report,indent=2))
