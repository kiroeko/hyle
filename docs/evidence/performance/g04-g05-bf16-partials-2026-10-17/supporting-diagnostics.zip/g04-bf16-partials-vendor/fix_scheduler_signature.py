from pathlib import Path
import difflib
import hashlib
import json
import subprocess
import sys

ROOT=Path(__file__).resolve().parents[2]
OUT=Path(__file__).resolve().parent
sha=lambda b:hashlib.sha256(b).hexdigest()
normalize=lambda b:b.replace(b'\r\n',b'\n').replace(b'\r',b'\n')
folder=ROOT/'third_party/flashinfer_cache'
path=folder/'patches.json';lock_path=ROOT/'cmake/HyleDependencyLock.json'
before_manifest=path.read_bytes();before_lock=lock_path.read_bytes()
manifest=json.loads(before_manifest);lock=json.loads(before_lock)
item=next(x for x in manifest['files'] if x['path']=='include/flashinfer/attention/scheduler.cuh')
assert item['edits'][1]['before']=='                                uint32_t kv_dtype_bytes = 2) {'
item['edits'][1]={
 'before':'                               int64_t uniform_q_len, cudaStream_t stream,\n                               uint32_t kv_dtype_bytes = 2) {',
 'after':'                               int64_t uniform_q_len, cudaStream_t stream,\n                               uint32_t kv_dtype_bytes = 2, bool hyle_bf16_partials = false) {'}
original=normalize((OUT/'upstream'/item['path']).read_bytes())
assert sha(original)==item['before_sha256']
changed=original
for edit in item['edits']:
    a,b=edit['before'].encode(),edit['after'].encode();assert changed.count(a)==1
    changed=changed.replace(a,b,1)
item['after_sha256']=sha(changed)
source=changed.decode()
for name in ['PrefillPlanImpl','PrefillPlan','PrefillPlanWorkspaceSize']:
    signature=source[source.index(name+'('):].split('{',1)[0]
    assert signature.count('bool hyle_bf16_partials = false')==1,name
signature=source[source.index('PrefillSplitQOKVIndptr('):].split('{',1)[0]
assert 'hyle_bf16_partials' not in signature
assert source.count('hyle_bf16_partials')==6
new_manifest=(json.dumps(manifest,indent=2)+'\n').encode()
dep=next(x for x in lock['dependencies'] if x['name']=='flashinfer_cache_patches')
old_tree=dep['vendored']['tree_sha256']
new_tree=sha(''.join(name+'|'+sha(normalize(data))+'\n' for name,data in sorted({
    'LICENSE':(folder/'LICENSE').read_bytes(),'NOTICE.md':(folder/'NOTICE.md').read_bytes(),'patches.json':new_manifest}.items())).encode())
dep['vendored']['tree_sha256']=new_tree
lock_bytes=before_lock.replace(old_tree.encode(),new_tree.encode(),1)
assert json.loads(lock_bytes)==lock
assert path.read_bytes()==before_manifest and lock_path.read_bytes()==before_lock
path.write_bytes(new_manifest);lock_path.write_bytes(lock_bytes)
report_path=OUT/'source-result.json'
previous=report_path.read_bytes();(OUT/'source-result-before-signature-fix.json').write_bytes(previous)
report=json.loads(previous)
output=OUT/'materialized-production-fixed-signatures'
command=[sys.executable,str(ROOT/'src/compute_ggml_runtime/prepare_source.py'),'--source',str(OUT/'upstream'),
         '--output',str(output),'--manifest',str(path)]
p=subprocess.run(command,capture_output=True,text=True)
assert p.returncode==0,(p.stdout,p.stderr)
for entry in manifest['files']:assert sha((output/entry['path']).read_bytes())==entry['after_sha256']
assert (output/item['path']).read_bytes()==changed
report.update(tree_sha256=new_tree,lock_sha256=sha(lock_bytes),manifest_sha256=sha(new_manifest),
              headers={entry['path']:entry['after_sha256'] for entry in manifest['files']},
              materialized_source=str(output),materializer_command=command,materializer_stdout=p.stdout,
              source_signature_checks={'PrefillPlanImpl':True,'PrefillPlan':True,'PrefillPlanWorkspaceSize':True,
                'PrefillSplitQOKVIndptr_unchanged':True,'only_three_default_false_declarations':True},
              correction={'reason':'A substring indentation anchor had incorrectly targeted PrefillSplitQOKVIndptr rather than PrefillPlan.',
                'fixed':'Exact full PrefillPlan signature anchor, verified three intended declarations and unchanged splitter signature.',
                'compile_status':'not compiled; materialization verifies bytes, signature checks are source-only; coordinator owns compilation'})
report_path.write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
(OUT/'scheduler-after.cuh').write_bytes(changed)
(OUT/'scheduler.diff').write_bytes(''.join(difflib.unified_diff(original.decode().splitlines(True),source.splitlines(True),fromfile='before/scheduler',tofile='after/scheduler')).encode())
print(json.dumps({k:report[k] for k in ['tree_sha256','lock_sha256','manifest_sha256','headers','materializer_stdout','source_signature_checks']},indent=2))
