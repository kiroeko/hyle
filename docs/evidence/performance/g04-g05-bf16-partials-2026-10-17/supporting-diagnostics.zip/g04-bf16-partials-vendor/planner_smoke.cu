#include <flashinfer/attention/scheduler.cuh>
#include <cstdint>

// Compile only: never call these functions or initialize a device here.
cudaError_t hyle_planner_explicit_tail_bool(
    void* floating, void* integer, void* mirror,
    std::int32_t* query_indptr, std::int32_t* kv_indptr, cudaStream_t stream,
    bool allow_bf16_partials) {
  std::size_t float_bytes = 0, int_bytes = 0;
  auto status = flashinfer::PrefillPlanWorkspaceSize<std::int32_t>(
      float_bytes, int_bytes, query_indptr, kv_indptr,
      192, 2, 8, 2, 256, 256, 16, false, 4, -1, -1, false,
      0, 0, stream, 1, allow_bf16_partials);
  if (status != cudaSuccess) return status;
  flashinfer::PrefillPlanInfo plan;
  return flashinfer::PrefillPlan<std::int32_t>(
      floating, float_bytes, integer, mirror, int_bytes, plan,
      query_indptr, kv_indptr, 192, 2, 8, 2, 256, 256, 16,
      false, 4, -1, -1, false, 0, 0, stream, 1, allow_bf16_partials);
}

cudaError_t hyle_planner_legacy_default_tail(
    void* floating, void* integer, void* mirror,
    std::int32_t* query_indptr, std::int32_t* kv_indptr, cudaStream_t stream) {
  std::size_t float_bytes = 0, int_bytes = 0;
  // Omit both private default arguments, retaining ordinary BF16 behavior.
  auto status = flashinfer::PrefillPlanWorkspaceSize<std::int32_t>(
      float_bytes, int_bytes, query_indptr, kv_indptr,
      192, 2, 8, 2, 256, 256, 16, false, 2, -1, -1, false,
      0, 0, stream);
  if (status != cudaSuccess) return status;
  flashinfer::PrefillPlanInfo plan;
  // Supply kv_dtype_bytes only: the appended bool still defaults to false.
  return flashinfer::PrefillPlan<std::int32_t>(
      floating, float_bytes, integer, mirror, int_bytes, plan,
      query_indptr, kv_indptr, 192, 2, 8, 2, 256, 256, 16,
      false, 2, -1, -1, false, 0, 0, stream, 2);
}
