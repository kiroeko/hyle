from pathlib import Path
import subprocess,json,os,time,hashlib,shutil
OUT=Path('/mnt/c/public/project-hyle/hyle/.scratch/g04-bf16-ncu-source')
WORK=Path('/root/hyle-scratch/compute-unified/g04-bf16-ncu-source');WORK.mkdir(exist_ok=False)
NCU='/usr/local/cuda-13.3/bin/ncu';binary=Path('/root/hyle-scratch/compute-unified/g04-bf16-c2/validation/peer-trace/consumer')
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
pre=json.loads((OUT.parent/'g04-bf16-ncu-enabled/preflight.json').read_text());assert pre['metrics_access_restored']
links=json.loads((OUT.parent/'g04-bf16-c2/consumer-links.json').read_text());built=json.loads((OUT.parent/'g04-bf16-c2/archive-result.json').read_text());assert sha(binary)==links['peer-trace']['binary_sha256']
source=OUT.parent/'g04-bf16-product-peer-trace/consumer.cc';assert sha(source)=='0c1cce0c24af14e167d304333d1ab898a831c29d214fe293187fb70180fb629a'
archive=Path(built['C2_archive']);assert sha(archive)==built['C2_archive_sha256']
sections=[]
metrics=['smsp__pcsamp_warps_issue_stalled_long_scoreboard_not_issued','smsp__pcsamp_warps_issue_stalled_math_pipe_throttle_not_issued','smsp__pcsamp_warps_issue_stalled_mio_throttle_not_issued','smsp__pcsamp_sample_count']
argv=[NCU,'--config-file','off','--replay-mode','application','--app-replay-mode','strict','--app-replay-match','all','--cache-control','none','--clock-control','none','--nvtx','--nvtx-include','PRODUCT_PEER capture=0 alloc=0 order=0 shape=prefill/','--kernel-name-base','demangled','--rename-kernels','off','--kernel-name','regex:BatchPrefillWithPagedKVCacheKernel','--filter-mode','global','--launch-skip','0','--launch-count','4']
argv+=['--metrics',','.join(metrics)]
argv+=['--export',str(WORK/'profile'),str(binary)]
identity={'started_unix':time.time(),'argv':argv,'nonsecret_env':{'G04_TRACE':'1'},'binary_sha256':sha(binary),'host_source_sha256':sha(source),'FI_archive':str(archive),'FI_archive_sha256':sha(archive),'C2_source_sha256':built['C2_source_sha256'],'preflight_sha256':sha(OUT.parent/'g04-bf16-ncu-enabled/preflight.json'),'sample_limit_logical_attention_launches':4,'expected_arm_sequence':['plainBF16-slot0','FP8optin-slot0','plainBF16-slot1','FP8optin-slot1'],'expected_geometry':{'grid':[40,1,2],'block':[32,4,1],'dynamic_shared':49152,'expected_registers':[238,246,238,246]},'cache_control':'none','clock_control':'none','replay_mode':'application','app_replay_mode':'strict','app_replay_match':'all','pipeline_boost_state':'ncu default stable','kill':False,'section_ids':sections,'explicit_SourceCounters_PC_metrics':metrics,'warp_sampling_interval':'auto/default; no fixed interval override','support_preflight':'../g04-bf16-ncu-enabled/{warp-query,source-support,groups-query}.stdout.log','notes':['NVTX range is an ancestor push/pop filter, not a top-of-stack requirement; warm64 occur before it.','Kernel-name filter excludes PersistentVariableLengthMergeStatesKernel.','Launch count is four matching logical attention launches; multi-pass application replay will execute full program repeatedly to collect counters.','Full ordinary primary is not remeasured; profiler measurements are causal diagnostics with collection interventions.','Clock-control none and cache-control none avoid explicit profiler clock locking/cache flush; instrumentation/pass re-execution can still perturb execution.']}
(OUT/'identity.json').write_text(json.dumps(identity,indent=2)+'\n');(OUT/'commands.json').write_text(json.dumps({'profile':argv},indent=2)+'\n');print(json.dumps({'argv':argv,'source_sha':identity['host_source_sha256'],'binary_sha':identity['binary_sha256']}),flush=True)
env=os.environ.copy();env['G04_TRACE']='1'
with (OUT/'profile.stdout.log').open('w') as so,(OUT/'profile.stderr.log').open('w') as se:
 try:r=subprocess.run(argv,env=env,cwd=WORK,stdout=so,stderr=se,timeout=480);rc=r.returncode
 except subprocess.TimeoutExpired:rc='TIMEOUT_480s'
identity.update(returncode=rc,elapsed_s=time.time()-identity['started_unix']);(OUT/'profile-result.json').write_text(json.dumps(identity,indent=2)+'\n');print(json.dumps({'returncode':rc,'elapsed_s':identity['elapsed_s']}),flush=True)
if rc!=0:raise SystemExit(1)
report=WORK/'profile.ncu-rep';assert report.is_file();shutil.copyfile(report,OUT/report.name);assert sha(report)==sha(OUT/report.name)
exports={}
for name,args in [('raw',['--page','raw','--csv','--print-units','base','--print-metric-instances','values']),('details',['--page','details']),('source',['--page','source','--print-source','sass','--print-metric-instances','values'])]:
 cmd=[NCU,'--config-file','off','--import',str(report)]+args
 with (OUT/(name+('.csv' if name=='raw' else '.txt'))).open('w') as so,(OUT/(name+'.stderr.log')).open('w') as se:r=subprocess.run(cmd,stdout=so,stderr=se)
 exports[name]={'argv':cmd,'returncode':r.returncode};assert r.returncode==0
identity['report']={'path':str(OUT/report.name),'bytes':report.stat().st_size,'sha256':sha(report)};identity['exports']=exports;(OUT/'profile-result.json').write_text(json.dumps(identity,indent=2)+'\n');print(json.dumps(identity['report']),flush=True)
