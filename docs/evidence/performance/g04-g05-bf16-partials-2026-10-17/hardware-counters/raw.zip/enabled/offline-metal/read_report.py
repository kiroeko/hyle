from pathlib import Path
import hashlib,json,sys,time

ROOT=Path('/mnt/c/public/project-hyle/hyle')
OUT=Path(sys.argv[2]) if len(sys.argv)>2 else ROOT/'.scratch/g04-bf16-ncu-enabled/offline-metal';OUT.mkdir(exist_ok=True)
SDK=Path('/opt/nvidia/nsight-compute/2026.2.1/extras/python')
sys.path.insert(0,str(SDK))
import ncu_report
path=Path(sys.argv[1]) if len(sys.argv)>1 else OUT.parent/'profile.ncu-rep'
t=time.monotonic();report=ncu_report.load_report(str(path))
result={'kind':'EXISTING_REPORT_PYTHON_API_OFFLINE_READ','gpu_executed':False,'compiled':False,'path':str(path),'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'api_module_sha256':hashlib.sha256((SDK/'ncu_report.py').read_bytes()).hexdigest(),'actions':[]}
for ir in range(report.num_ranges()):
    rng=report.range_by_idx(ir)
    for ia in range(rng.num_actions()):
        a=rng.action_by_idx(ia)
        names=list(a.metric_names())
        selected=[name for name in names if name in ['launch__function_pcs','sass__inst_executed_per_opcode','sass__thread_inst_executed_per_opcode_category','inst_executed','thread_inst_executed','thread_inst_executed_true'] or name.startswith(('smsp__pcsamp_','smsp__warpidsamp_'))]
        row={'range':ir,'action':ia,'name':a.name(),'mangled_name':a.name(ncu_report.IAction.NameBase_MANGLED),'all_metric_names':names,'selected_metrics':{}}
        for name in selected:
            m=a.metric_by_name(name)
            ids=m.correlation_ids() if m.has_correlation_ids() else None
            instances=[]
            for i in range(m.num_instances()):
                identifier=ids.value(i) if ids is not None else None
                entry={'id':identifier,'value':m.value(i)}
                if (name=='inst_executed' or name.startswith('smsp__pcsamp_warps_')) and isinstance(identifier,int):
                    entry['sass']=a.sass_by_pc(identifier)
                instances.append(entry)
            row['selected_metrics'][name]={'scalar':m.value(),'instances':instances,'has_correlation_ids':ids is not None}
        result['actions'].append(row)
result['read_seconds']=time.monotonic()-t
(OUT/'report-api.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps([{'action':a['action'],'name':a['name'],'metric_instance_counts':{n:len(m['instances']) for n,m in a['selected_metrics'].items()}} for a in result['actions']],indent=2))
