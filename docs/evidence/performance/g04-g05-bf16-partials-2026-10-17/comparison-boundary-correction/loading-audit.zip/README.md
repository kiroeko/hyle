The reference loads too. The retained C6 profile supports a comparison of the two loading mechanisms; it does not isolate their net loading cost or prove that software decoding plus initial loads explains the entire remaining timing difference.

| Stage | Resident plain BF16 reference | Resident FP8 C6 |
|---|---|---|
| Initial metadata | Reads K/V page indices (`04e0`, `0cf0`), forms independent K/V addresses, then loads both payloads. | Reads K/V page indices (`0be0`, `0ce0`), forms independent addresses, then loads both payloads. |
| Initial payload | K `0de0..0e40` and V `1500..1540` use async global-to-shared `LDGSTS`; no FP8 decode. | V raw `0e00/0f00` and K raw `1160/14a0` use register loads; software decoding and explicit shared stores follow. Compiler scheduling interleaves the two producers. |
| Completion / first consumer | `DEPBAR.LE SB0,1` at `1700`, then shared publication barrier and `LDSM`. The following `1710` has 158/159 long-scoreboard samples. Its visible SHF operand alone does not explain that wait. | Full async wait plus CTA publication, then BF16 shared fragments. Initial V/index and K consumers still have samples; these are not exclusive kinds of work. |
| Main-loop next tile | Separate K/V page-index reads. K async copies `24f0..25b0` overlap softmax; V async copies `33e0..3430` overlap tail PV and complete before the next use. | Shared K/V page-index read `2420`. Raw K `29b0/29c0` precedes softmax; decode/shared stores follow. Raw V `43e0/4410` precedes PV; decode/shared stores follow. |
| Valid payload per full 16-row, D256 tile/head | K 8192 B + V 8192 B. | K 4096 B + V 4096 B, then conversion to BF16 fragments. |

Logical bytes are not measured DRAM bytes. Cache hits, transactions, physical page aliases and tails matter. The reference's async wait and the FP8 register-load scoreboard wait occur at different instructions and cover different producer groups. Per-PC samples cannot be subtracted to obtain net loading microseconds.

The FP8 path has an additional 646144 dynamic decoder-fingerprint instructions. That is evidence of extra work, not its exclusive latency or the complete reason for a timing gap. Both execute the same measured HMMA, MUFU, FMUL and LDSM counts. Neither the sample totals nor those matching counts provide a complete causal cost decomposition.

The previous archived initial-load labels need correction: `1140` consumes initial **V** raw R4 from `0e00`/V base, not K. `14c0` consumes initial **K** second-vector R13 from `14a0`/K base. `0d70` waits on initial **V** page metadata. The old raw measurements remain unchanged; `comparison.json` records the corrected def-use chains.

The existing warm reference owns BF16 pages that were expanded and scaled before timing. It therefore measures a representation/residency tradeoff against FP8, not two implementations with the same FP8-resident start. The observed warm difference alone does not establish a performance defect in the FP8 implementation.

A same-format reference is source-feasible in the exact locked upstream FlashInfer `69ff11fc4954396d98326656dc85debd2223f637`: BF16 Q, resident E4M3 K/V, BF16 temporary partials and BF16 output. It loads packed FP8 asynchronously, repacks tiles to BF16 inside attention and does not require a full-history BF16 shadow. Its original dispatcher must choose a valid tile; the Hyle direct-stage KMMA1 exception cannot be imposed on it. Scale placement and public call/cache lifetime must also match. This source audit has not compiled or measured that reference. See `same-format-baseline-feasibility.json` for exact archive/header identities, source lines and adapter constraints.

`audit.py` reproduces both new reports using existing files only. It verifies all 1619 exported reference PCs and all 2012 exported C6 PCs against their exact retained typed kernels. No GPU run, CUDA compilation, product edit or archived-evidence rewrite was performed.
