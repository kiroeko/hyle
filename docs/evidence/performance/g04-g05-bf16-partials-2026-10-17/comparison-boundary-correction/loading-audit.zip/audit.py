from pathlib import Path
from collections import Counter
import hashlib
import json
import re
import tarfile

ROOT = Path(__file__).resolve().parents[4]
OUT = Path(__file__).resolve().parent
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
read = lambda p: json.loads(p.read_text(encoding='utf-8'))
R = ROOT / '.scratch'
report_path = R / 'g04-bf16-ncu-c6/offline-metal/report-api.json'
report = read(report_path)
plain_dir = R / 'g04-bf16-product-peer-codegen'
c6_dir = R / 'g04-bf16-c6-codegen'
plain_read = read(plain_dir / 'read.json')
c6_read = read(c6_dir / 'review.json')
plain_rows = read(plain_dir / 'plain-bf16-prefill-mma1-rows.json')
c6_rows = read(c6_dir / 'c6-rows.json')['bf16-prefill']
static = {'plain_BF16': {int(x['pc'], 16): x for x in plain_rows},
          'FP8_C6': {int(x['pc'], 16): x for x in c6_rows}}
symbols = {'plain_BF16': plain_read['kernels']['plain-bf16-prefill-mma1']['device_symbol'],
           'FP8_C6': c6_read['current']['symbols']['bf16-prefill']}
word_paths = {'plain_BF16': plain_dir / 'plain-bf16-prefill-mma1-codewords.txt',
              'FP8_C6': c6_dir / 'c6-bf16-prefill-codewords.txt'}

def normal(s, base=0):
    if re.search(r'\b(?:BRA|BSSY|CALL)\b', s):
        s = re.sub(r'0x[0-9a-fA-F]+', lambda m: hex(int(m[0], 16) - base) if int(m[0], 16) >= base else m[0], s)
    return ''.join(s.replace('.reuse', '').replace(',', '').rstrip(' ;').split())

def opcode(s):
    return re.sub(r'^@!?U?P(?:\d+|T)\s+', '', s.strip()).split()[0].split('.')[0]

words = {}
for arm, path in word_paths.items():
    lines = path.read_text().splitlines()
    assert len(lines) == len(static[arm])
    words[arm] = {}
    for row, line in zip(static[arm].values(), lines):
        lo, hi = [int(x, 16) for x in line.split(':')]
        cc = ((hi << 64 | lo) >> 105) & 0x1ffff
        words[arm][int(row['pc'], 16)] = {'low64': hex(lo), 'high64': hex(hi),
            'reverse_engineered_control': {'wait_counters': [i for i in range(6) if cc >> (11+i) & 1],
                                          'read_counter': cc >> 8 & 7, 'write_counter': cc >> 5 & 7}}

actions = []
for a in report['actions']:
    arm = 'FP8_C6' if a['action'] % 2 else 'plain_BF16'
    assert a['mangled_name'] == symbols[arm]
    m = a['selected_metrics']; base = m['launch__function_pcs']['instances'][0]['value']
    inst = m['inst_executed']['instances']
    assert sum(x['value'] for x in inst) == m['inst_executed']['scalar']
    by_pc = {}
    for x in inst:
        pc = x['id'] - base
        assert pc in static[arm] and normal(x['sass'], base) == normal(static[arm][pc]['sass']), (arm, hex(pc))
        by_pc[pc] = x['value']
    sampled = {}
    for k, v in m.items():
        if k.startswith('smsp__pcsamp_') and v['instances']:
            assert sum(x['value'] for x in v['instances']) == v['scalar']
            sampled[k] = {x['id'] - base: x['value'] for x in v['instances']}
    rows = {hex(pc): {'sass': row['sass'], 'dynamic_warp_instructions': by_pc.get(pc, 0),
                     **words[arm][pc], 'samples': {k: v.get(pc, 0) for k,v in sampled.items()}}
            for pc, row in static[arm].items()}
    op = Counter()
    for x in inst: op[opcode(x['sass'])] += x['value']
    long_key = 'smsp__pcsamp_warps_issue_stalled_long_scoreboard_not_issued'
    actions.append({'action': a['action'], 'arm': arm, 'function_base': base,
        'mangled_name': a['mangled_name'], 'all_runtime_SASS_PCs_verified': len(inst),
        'dynamic_instructions': m['inst_executed']['scalar'], 'dynamic_opcodes': dict(sorted(op.items())),
        'sample_totals': {k:m[k]['scalar'] for k in sampled},
        'top_long_scoreboard': [{'pc':hex(pc), 'count':count, 'sass':static[arm][pc]['sass']}
                              for pc,count in sorted(sampled[long_key].items(), key=lambda x:x[1], reverse=True)[:20]],
        'rows': rows})

def points(arm, pcs):
    return [{'pc':hex(pc), 'sass': static[arm][pc]['sass'], **words[arm][pc],
             'profile_actions': [{'action':a['action'], **a['rows'][hex(pc)]} for a in actions if a['arm']==arm]}
            for pc in pcs]

stages = [
 {'stage':'initial page index / independent K,V address computation',
  'common':'Both read paged.indices with signed bounds guards, then use independent K and V stride/base fields. Metadata is not exclusive FP8 work.',
  'plain':points('plain_BF16',[0x4e0,0xcc0,0xd70,0xcf0,0x1470,0x1480]),
  'FP8':points('FP8_C6',[0xbe0,0xd70,0xd80,0xce0]),
  'note':'Plain 4e0->R33->cc0/d70 is K; cf0->R19->1470/1480 is V. C6 be0->R11->d70/d80 uses v_stride_page c194 and v_data c1a8: it is initial V metadata, not K.'},
 {'stage':'initial K/V payload staging',
  'plain':points('plain_BF16',[0xde0,0xe00,0xe20,0xe40,0xe90,0x1500,0x1520,0x1530,0x1540,0x1560]),
  'FP8':points('FP8_C6',[0xe00,0xf00,0x1140,0x1160,0x1180,0x1190,0x14a0,0x14c0,0x1440,0x1460]),
  'note':'Plain K goes global->SMEM by four 16B LDGSTS/thread; V likewise. C6 initial V raw e00/f00 already starts while K addresses are computed. 1140 consumes e00 R4 (V), not K. K raw1160/14a0 adds k_data c1a0; first K consumer1180 consumes R17, second14c0 consumes R13.'},
 {'stage':'loop entry and first shared-memory consumers',
  'plain':points('plain_BF16',[0x1700,0x1710,0x17d0,0x17e0,0x1810]),
  'FP8':points('FP8_C6',[0x2360,0x2370,0x2390]),
  'note':'Plain also has an observed long-scoreboard hotspot at1710 immediately after DEPBAR.LE SB0,1 (158/159 samples). It has no encoded general scoreboard wait at1710 and its SHF operands alone do not identify a unique cause. Do not call reference loading free or mistake this for a slow SHF. Async-copy wait/group and following CTA barrier exist; these six metrics do not isolate their net latency.'},
 {'stage':'next-tile metadata in main loop',
  'plain':points('plain_BF16',[0x1a60,0x22e0,0x2320,0x28a0,0x31f0]),
  'FP8':points('FP8_C6',[0x2420,0x2910,0x2920,0x2a70]),
  'note':'Plain has separate index loads1a60 and28a0 for next K/V; c188 vs c194 consumers preserve each stride. C6 shares one typed guarded page-index load2420 for both, without assuming equal strides.'},
 {'stage':'next K payload / softmax / publication',
  'plain':points('plain_BF16',[0x2420,0x24f0,0x2530,0x2570,0x25b0,0x25f0,0x26d0,0x26e0,0x2770]),
  'FP8':points('FP8_C6',[0x29b0,0x29c0,0x3060,0x3230,0x35d0,0x3b00,0x3b90,0x40b0,0x40e0,0x40f0,0x4100]),
  'note':'Plain async K copies interleave softmax and publish through commit/wait/barrier; compressed C6 raw K is read before softmax, decoded after softmax and explicitly stored to SMEM. Different wait mechanisms/locations make per-PC stall subtraction invalid. C6 first shared W5 wait has0/2 long samples, which does not prove zero latency.'},
 {'stage':'next V payload / PV / publication and buffer reuse',
  'plain':points('plain_BF16',[0x28a0,0x31f0,0x33a0,0x33e0,0x3400,0x3410,0x3430,0x3450]),
  'FP8':points('FP8_C6',[0x43d0,0x43e0,0x4410,0x44c0,0x4770,0x4c80,0x4cb0,0x4ce0,0x4cf0,0x4d00,0x4d20]),
  'note':'Both reuse shared buffers only around synchronization boundaries. Plain V LDGSTS overlaps tail PV and is consumed next iteration after wait_group/barrier. C6 raw V loads precede PV, decode/store follows PV. Neither has free V loading. C6 loop2370 read-counter wait can cover loop-carried V STS register/address lifetime; it is not evidence of a new K or scalar arithmetic bottleneck.'}
]

archive = R/'validation/m1-route-binding/m1-cuda-intake/flashinfer-69ff11fc4954396d98326656dc85debd2223f637.tar.gz'
assert sha(archive)=='4fc85abaa6210d6a1773e6011ff572aa0c04b7030644b74f75a2db2dbda472a9'
upstream = R/'g04-bf16-partials-vendor/upstream'
files=['include/flashinfer/attention/prefill.cuh','include/flashinfer/attention/default_prefill_params.cuh',
       'include/flashinfer/attention/scheduler.cuh','include/flashinfer/attention/variants.cuh',
       'include/flashinfer/attention/variant_helper.cuh','include/flashinfer/page.cuh','include/flashinfer/vec_dtypes.cuh']
up_headers=[]
with tarfile.open(archive) as t:
    prefix=t.getnames()[0].split('/')[0]+'/'
    for f in files:
        b=t.extractfile(prefix+f).read(); assert b==(upstream/f).read_bytes()
        up_headers.append({'path':f,'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b),'exact_archive_bytes':True})

feasibility={
 'scope':'Read-only exact upstream69ff source feasibility, not a compiled or measured upstream FP8 baseline',
 'upstream_revision':'69ff11fc4954396d98326656dc85debd2223f637','archive':str(archive.relative_to(ROOT)),
 'archive_sha256':sha(archive),'headers':up_headers,
 'direct_FP8_resident_input_supported_at_template_source_level':True,
 'signature':'BatchPrefillPagedParams<__nv_bfloat16,__nv_fp8_e4m3,__nv_bfloat16,int32_t>; BatchPrefillWithPagedKVCacheDispatched<64,256,256,PosEncodingMode::kNone,false,MaskMode::kCausal,DefaultAttention<false,false,false,false>>',
 'output_and_partial':'prefill.cuh4335 takes Params::DTypeO* tmp_v;4497 writes that typed tmp;4507 calls upstream VariableLengthMergeStates(tmp_v,...,original o). BF16 O therefore means BF16 split partials and BF16 final output with F32 scores. F32 temporary followed by BF16 final is a different customization, not that exact default type tuple.',
 'loader':'Upstream528..576 uses cp.async packed FP8 global->SMEM; USE_KV_REPACK294..296 is true for D256/CTA64. Mainloop3923..3933 and4013..4023 repacks tile FP8->BF16 SMEM before BF16 QK/PV. It does not require an expanded persistent BF16 cache.',
 'different_legal_geometry':'Original IsInvalid316 requires NUM_MMA_KV*2 % NUM_WARPS_Q==0 for byte KV. CTA64 has4Q warps: minimum legal KMMA2/32KV rows. The production direct-stage KMMA1 exception is Hyle patch behavior and must not be forced into pristine upstream. Original dispatcher4412..4437 selects legal tile from actual device resource limits.',
 'workspace':'Original scheduler775 ignores sizeof_dtype_o and861 reserves tmp_v with sizeof(float). This can overreserve BF16 temporary storage; it does not change the typed BF16 partial writes/reads to F32. Do not impose product11MiB cap on this baseline or mislabel allocator reserve as partial dtype.',
 'scales':'K=.5 can be folded into params.sm_scale on both routes. Upstream DefaultAttention has no final Vscale field/epilogue. For Vscale=2, a reference must explicitly use a supported OutputTransform customization (variant_helper66..85) or a clearly charged output step, and prove its placement relative to BF16 partial rounding meets the compared finite contract. Unit scales are a simpler supported shape but not the identical original scaled fixture. Do not silently drop scale or pretend pre- and post-round scaling is universally equivalent.',
 'boundary_for_valid_comparison':['Both start with the same immutable FP8 device bytes/owners and page metadata, plus the same BF16 Q; both finish after BF16 output/merge completion.','Plan/capture may be cold for both but must be declared, retained and invalidated on identical cache/layout lifecycle events. No cold expanded BF16 shadow on only one side.','Same public normal/replay enqueue/wait boundary and slots/leases/teardown, or explicitly native-only diagnostics for both. Do not compare a public arm with a cropped direct kernel bridge.','Allow each original dispatcher to choose its valid geometry; record actual tile/split/partial precision/resources. Match numeric policy and oracle, not an illegal forced kernel.','This baseline is source-feasible, not yet compiled, run or numerically validated.'],
 'existing_comparators':[
  {'name':'C6 current plain BF16 peer','input':'cold CPU-expanded+scaled BF16 GPU resident pages','kind':'representation/residency tradeoff, not same-FP8 throughput baseline','evidence':'.scratch/g04-g05-sameprocess-review/product-c6-peer-comparability-audit.json'},
  {'name':'Full-TU four-corner00/orig','input':'actual original FP8 resident pages','kind':'Hyle patched loader / F32 partials; same-format historical Hyle version, not pristine upstream'},
  {'name':'Full-TU four-corner01','input':'actual original FP8 resident pages','kind':'Hyle patched loader and custom BF16-partial merge; same-format historical diagnostic, not pristine upstream'},
  {'name':'Full-TU four-corner10/11 and peer','input':'retained cold-expanded BF16 snapshot','kind':'not same-FP8 input'},
  {'name':'Old D3 fp8-bf16','input':'reference.cc114..115 selects actual FP8 input storage when uses_fp8; native.cu138 chooses BF16Q/FP8KV/BF16O','kind':'true FP8 input, but cropped CTA64/D256/paged-causal bridge and adapted output/scale behavior. Cannot call it a full public unmodified-upstream baseline or transfer its causal timing decomposition.'},
  {'name':'Old D3 bf16-f32','input':'cold-expanded BF16 snapshot','kind':'not same-FP8 input; uses custom F32 temporary merge'}],
 'primary_source_urls':['https://github.com/flashinfer-ai/flashinfer/blob/69ff11fc4954396d98326656dc85debd2223f637/include/flashinfer/attention/prefill.cuh','https://github.com/flashinfer-ai/flashinfer/blob/69ff11fc4954396d98326656dc85debd2223f637/include/flashinfer/attention/scheduler.cuh']}
(OUT/'same-format-baseline-feasibility.json').write_text(json.dumps(feasibility,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')

bindings=[report_path,plain_dir/'read.json',plain_dir/'plain-bf16-prefill-mma1-rows.json',*word_paths.values(),c6_dir/'review.json',c6_dir/'c6-rows.json',R/'g04-bf16-c6/archive-result.json',R/'g04-bf16-product-c6-earlier-k-prefetch/prefill.cuh',R/'g04-g05-sameprocess-review/product-c6-peer-comparability-audit.json']
result={'scope':'New independent two-sided loading-stage comparison from already captured C6 profile/static artifacts. No GPU, compilation, product edits, or archived-report edits.',
 'report_sha256':report['sha256'],'bindings':{str(p.relative_to(ROOT)):sha(p) for p in bindings},
 'conclusion':'The BF16 reference also loads metadata and K/V and waits for data. FP8 adds software decode/register/shared-store work while reducing KV payload width. Existing six metrics do not measure the net cost of loading, isolate the remaining normal/replay difference, or prove software decode plus initial loading is the complete remaining cause. The compared persistent KV representations and cold preparation differ, so warm BF16 peer timing is not an apples-to-apples same-FP8 inference baseline.',
 'mandatory_label_correction':'Previous archived reports named C6(and identical C2..C5 prologue)1140 initial_K and14c0 initial_V. Def-use/base fields show1140 consumes V rawR4 frome00/c1a8;14c0 consumes K second rawR13 from14a0/c1a0. d70 is initial V page metadata. Raw PC samples/counters remain unchanged; the producer labels are corrected here without rewriting old artifacts.',
 'actions':actions,'stage_comparison':stages,
 'payload_bytes_per_full_KV_tile_16rows_D256_per_head':{'plain_K':8192,'plain_V':8192,'FP8_K':4096,'FP8_V':4096,'meaning':'Logical valid payload bytes; not measured DRAM traffic. Partial tails/duplicate physical page aliases/cache reuse affect transactions.'},
 'common_work':['Q BF16 asynchronous staging; paged metadata and bounds/address computation; actual K and V global loads; shared-memory publication/reuse synchronization; BF16 fragments and identical HMMA/MUFU/F32 arithmetic counts'],
 'additional_or_changed_work':['FP8 tile decode646144 dynamic fingerprint instructions, raw payload register lifetimes, explicit shared stores, different scheduling/address instructions.','Plain carries twice-as-wide resident KV and uses direct async global-to-shared transfer rather than raw-register decoding.','Scale placement differs: peer absorbs .5/2 before warm; FP8 uses sm_scale and scaled merge. Same effective finite values do not erase lifecycle/rounding distinctions.'],
 'unsupported_claims':['All remaining performance difference is caused by software decode plus initial load.','The reference does not pay loading cost or has no load stalls.','Subtracting per-PC samples or total long-scoreboard samples yields net load microseconds.','Near-zero sampled main-K stalls prove zero load latency.','The warm plain-BF16 comparison alone establishes an FP8 implementation performance defect or general engine ranking.'],
 'limits':['Selected six metrics omit per-PC barrier-notissued and complete memory hierarchy/cache/transaction latency breakdown; instruction counts and samples are not additive time costs.','A stall sample attaches to observed instruction/wait location, not necessarily its visible operand or one unique producer. Async LDGSTS/group waits and synchronous raw-register loads are different mechanisms.','Control-field grouping uses retained CuAssembler reverse-engineered Ada decoding; it is not NVIDIA public ABI.','Profiler replay/cache conditions and kernel duration are not ordinary full-episode speedups.','No causal residual attribution without a matched FP8-resident-start reference or targeted matched experiment.'],
 'same_format_baseline_report':'same-format-baseline-feasibility.json'}
(OUT/'comparison.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'comparison':{'path':str((OUT/'comparison.json').relative_to(ROOT)),'sha256':sha(OUT/'comparison.json')},'same_format':{'path':str((OUT/'same-format-baseline-feasibility.json').relative_to(ROOT)),'sha256':sha(OUT/'same-format-baseline-feasibility.json')},'runtime_PCs_verified':[a['all_runtime_SASS_PCs_verified'] for a in actions]},indent=2))
