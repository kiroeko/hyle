#pragma once
#include "factor_record.h"
#include "cuda_encoded_page_reference.h"
using FactorRecord=hyle::compute::flashinfer::native::FactorReplayRecord;
struct Binding {hyle::compute::Provider(*provider)() noexcept;void(*configure)(bool,bool,const void*,const void*)noexcept;const FactorRecord*(*get)()noexcept;cudaError_t(*replay)(cudaStream_t);cudaError_t(*dump)(const char*);};
hyle::compute::Provider provider_00() noexcept asm("g04f_00__ZN4hyle7compute10flashinfer8providerEv");
void config_00(bool,bool,const void*,const void*) noexcept asm("g04f_00__ZN4hyle7compute10flashinfer6native16configure_factorEbbPKvS4_");
const FactorRecord* get_00() noexcept asm("g04f_00__ZN4hyle7compute10flashinfer6native17get_factor_recordEv");
cudaError_t replay_00(cudaStream_t) asm("g04f_00__ZN4hyle7compute10flashinfer6native13replay_factorEP11CUstream_st");
cudaError_t dump_00(const char*) asm("g04f_00__ZN4hyle7compute10flashinfer6native16dump_factor_planEPKc");
hyle::compute::Provider provider_01() noexcept asm("g04f_01__ZN4hyle7compute10flashinfer8providerEv");
void config_01(bool,bool,const void*,const void*) noexcept asm("g04f_01__ZN4hyle7compute10flashinfer6native16configure_factorEbbPKvS4_");
const FactorRecord* get_01() noexcept asm("g04f_01__ZN4hyle7compute10flashinfer6native17get_factor_recordEv");
cudaError_t replay_01(cudaStream_t) asm("g04f_01__ZN4hyle7compute10flashinfer6native13replay_factorEP11CUstream_st");
cudaError_t dump_01(const char*) asm("g04f_01__ZN4hyle7compute10flashinfer6native16dump_factor_planEPKc");
hyle::compute::Provider provider_10() noexcept asm("g04f_10__ZN4hyle7compute10flashinfer8providerEv");
void config_10(bool,bool,const void*,const void*) noexcept asm("g04f_10__ZN4hyle7compute10flashinfer6native16configure_factorEbbPKvS4_");
const FactorRecord* get_10() noexcept asm("g04f_10__ZN4hyle7compute10flashinfer6native17get_factor_recordEv");
cudaError_t replay_10(cudaStream_t) asm("g04f_10__ZN4hyle7compute10flashinfer6native13replay_factorEP11CUstream_st");
cudaError_t dump_10(const char*) asm("g04f_10__ZN4hyle7compute10flashinfer6native16dump_factor_planEPKc");
hyle::compute::Provider provider_11() noexcept asm("g04f_11__ZN4hyle7compute10flashinfer8providerEv");
void config_11(bool,bool,const void*,const void*) noexcept asm("g04f_11__ZN4hyle7compute10flashinfer6native16configure_factorEbbPKvS4_");
const FactorRecord* get_11() noexcept asm("g04f_11__ZN4hyle7compute10flashinfer6native17get_factor_recordEv");
cudaError_t replay_11(cudaStream_t) asm("g04f_11__ZN4hyle7compute10flashinfer6native13replay_factorEP11CUstream_st");
cudaError_t dump_11(const char*) asm("g04f_11__ZN4hyle7compute10flashinfer6native16dump_factor_planEPKc");
hyle::compute::Provider provider_orig() noexcept asm("g04f_orig__ZN4hyle7compute10flashinfer8providerEv");
hyle::compute::Provider peer_provider(const hyle::bench::resident::CudaEncodedReferenceData*) noexcept asm("g04f_peer__ZN4hyle5bench8resident31cuda_encoded_reference_providerEPKNS1_24CudaEncodedReferenceDataE");
hyle::Status peer_prepare(hyle::bench::resident::CudaEncodedReferenceData&,hyle::compute::Queue&,hyle::compute::BatchLayoutVersion,hyle::compute::PagedArenaRead,hyle::compute::PagedArenaRead,hyle::mem::MemoryResourceRef) noexcept asm("g04f_peer__ZN4hyle5bench8resident30prepare_cuda_encoded_referenceERNS1_24CudaEncodedReferenceDataERNS_7compute5QueueENS4_18BatchLayoutVersionENS4_14PagedArenaReadES8_NS_3mem17MemoryResourceRefE");
inline constexpr const char* arm_names[]{"00","01","10","11","orig","peer"};
inline const Binding bindings[]{
{&provider_00,&config_00,&get_00,&replay_00,&dump_00},
{&provider_01,&config_01,&get_01,&replay_01,&dump_01},
{&provider_10,&config_10,&get_10,&replay_10,&dump_10},
{&provider_11,&config_11,&get_11,&replay_11,&dump_11},
{&provider_orig,nullptr,nullptr,nullptr,nullptr},
};
