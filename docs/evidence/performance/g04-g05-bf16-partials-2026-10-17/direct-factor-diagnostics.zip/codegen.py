import pathlib,subprocess,re,json,hashlib
P=pathlib.Path('/root/hyle-scratch/compute-unified/g04-factorial-fulltu')
OUT=pathlib.Path('/mnt/c/public/project-hyle/hyle/.scratch/g04-factorial-fulltu/codegen');OUT.mkdir(exist_ok=False)
old=pathlib.Path('/root/hyle-scratch/compute-unified/g04-load-ilp-2026-10-17/consumer/native_cache_control.o');new=P/'native_cache_factor.o'
result={}
for side,p in [('original',old),('fresh00',new)]:
 syms=subprocess.check_output(['nm','--defined-only','--format=posix',str(p)],text=True)
 candidates=[]
 for line in syms.splitlines():
  n,t,*_=line.split()
  if t=='t' and n.startswith('_ZN10flashinferL34BatchPrefillWithPagedKVCacheKernel') and 'MaskModeE1ELj64ELj1ELj1ELj16ELj16ELj4ELj1E' in n and '13__nv_bfloat1613__nv_fp8_e4m3ffi' in n and '11MergeParams' in n and 'Lj256E' in n and not n.endswith('.cold'):candidates.append(n)
 assert len(candidates)==1,candidates
 host=candidates[0];device=host.replace('_ZN10flashinferL34','_ZN10flashinfer34',1)
 args=['/usr/local/cuda-13.3/bin/cuobjdump','--dump-sass','--function',device,str(p)]
 z=subprocess.run(args,capture_output=True,text=True);(OUT/(side+'-sass.txt')).write_text(z.stdout);(OUT/(side+'-stderr.txt')).write_text(z.stderr)
 instructions=[]
 for line in z.stdout.splitlines():
  m=re.search(r'/\*[0-9a-fA-F]+\*/\s+(.+?;)',line)
  if m:instructions.append(m.group(1).strip())
 assert len(instructions)>1000,(side,len(instructions))
 (OUT/(side+'-instructions.txt')).write_text('\n'.join(instructions)+'\n')
 resource=subprocess.run(['/usr/local/cuda-13.3/bin/cuobjdump','--dump-resource-usage','--function',device,str(p)],capture_output=True,text=True);(OUT/(side+'-resources.txt')).write_text(resource.stdout);(OUT/(side+'-resources-stderr.txt')).write_text(resource.stderr)
 result[side]={'object':str(p),'object_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'host_symbol':host,'device_symbol':device,'sass_argv':args,'instruction_count':len(instructions),'normalized_sha256':hashlib.sha256(('\n'.join(instructions)+'\n').encode()).hexdigest(),'resource_dump':resource.stdout}
result['baseline_target_instruction_identical']=result['original']['normalized_sha256']==result['fresh00']['normalized_sha256']
(OUT/'comparison.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:{f:v for f,v in r.items() if f in ['instruction_count','normalized_sha256']} if isinstance(r,dict) else r for k,r in result.items()},indent=2))
