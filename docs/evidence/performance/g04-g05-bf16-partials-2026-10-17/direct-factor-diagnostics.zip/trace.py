import pathlib,sqlite3,json,bisect,collections,statistics,hashlib
P=pathlib.Path('/root/hyle-scratch/compute-unified/g04-factorial-fulltu/run-trace-1')
OUT=pathlib.Path('/mnt/c/public/project-hyle/hyle/.scratch/g04-factorial-fulltu/run-trace-1')
c=sqlite3.connect(P/'profile.sqlite');c.row_factory=sqlite3.Row;strings=dict(c.execute('select id,value from StringIds'))
nv=[dict(x) for x in c.execute('select * from NVTX_EVENTS where end is not null order by start')]
arm_names=['00','01','10','11','orig','peer'];pair_names=['00-orig','00-10','01-11','00-01','10-11','00-peer','orig-peer','11-peer']
ep=[r for r in nv if r['text'] in arm_names];sh=[r for r in nv if r['text'] in ['window','prefill','holdout']];pr=[r for r in nv if r['text'] in pair_names]
assert len(ep)==49152 and len(sh)==48 and len(pr)==48
es=[e['start'] for e in ep];ss=[s['start'] for s in sh];ps=[p['start'] for p in pr]
for e in ep:
 i=bisect.bisect_right(ss,e['start'])-1;j=bisect.bisect_right(ps,e['start'])-1
 assert sh[i]['end']>=e['end'] and pr[j]['end']>=e['end']
 e.update(alloc=i//24,shape=sh[i]['text'],pair=pr[j]['text'],arm=e['text'],kernels=[],stages={})
for r in nv:
 if r['text'] not in ['update','admit_submit','checked_wait','output_acquire']:continue
 i=bisect.bisect_right(es,r['start'])-1
 if i>=0 and r['end']<=ep[i]['end']:ep[i]['stages'][r['text']]=(r['end']-r['start'])/1000
runtime={}
for r in c.execute('select * from CUPTI_ACTIVITY_KIND_RUNTIME order by start'):
 i=bisect.bisect_right(es,r['start'])-1
 if i>=0 and r['end']<=ep[i]['end'] and r['globalTid']==ep[i]['globalTid']:runtime[r['correlationId']]=i
resources=collections.defaultdict(set);outside=0
for r in c.execute('select * from CUPTI_ACTIVITY_KIND_KERNEL order by start'):
 if r['correlationId'] not in runtime:outside+=1;continue
 e=ep[runtime[r['correlationId']]];name=strings[r['demangledName']];kind='merge' if 'MergeStatesKernel' in name else 'attention';assert kind=='merge' or 'PrefillWithPagedKVCacheKernel' in name
 row={'kind':kind,'us':(r['end']-r['start'])/1000,'registers':r['registersPerThread'],'start':r['start'],'end':r['end'],'correlation':r['correlationId']};e['kernels'].append(row)
 resources[e['shape'],e['arm'],kind].add((r['registersPerThread'],r['dynamicSharedMemory'],r['localMemoryPerThread'],r['gridX'],r['gridY'],r['gridZ'],r['blockX'],r['blockY'],r['blockZ'],strings[r['mangledName']]))
assert sum(len(e['kernels']) for e in ep)==65536
for e in ep:
 assert len(e['kernels'])==(2 if e['shape']=='prefill' else 1)
 if e['shape']=='prefill' and e['arm'] in ['00','orig']:assert next(k['registers'] for k in e['kernels'] if k['kind']=='attention')==248
g=collections.defaultdict(list)
for e in ep:g[e['alloc'],e['shape'],e['pair'],e['arm']].append(e)
rows=[]
for alloc in range(2):
 for shape in ['window','prefill','holdout']:
  for pair in pair_names:
   a,b=pair.split('-');row={'alloc':alloc,'shape':shape,'pair':pair,'arms':{}}
   for arm in [a,b]:
    ee=g[alloc,shape,pair,arm];assert len(ee)==512
    gpu={kind:statistics.mean(sum(k['us'] for k in e['kernels'] if k['kind']==kind) for e in ee) for kind in ['attention','merge'] if any(k['kind']==kind for k in ee[0]['kernels'])}
    row['arms'][arm]={'kernel_mean_us':gpu,'kernel_sum_mean_us':sum(gpu.values()),'host_stages_trace_only':{stage:statistics.mean(e['stages'][stage] for e in ee) for stage in ee[0]['stages']}}
   row['b_over_a_gpu_delta_pct']={kind:(row['arms'][b]['kernel_mean_us'][kind]/v-1)*100 for kind,v in row['arms'][a]['kernel_mean_us'].items()};row['b_over_a_gpu_sum_delta_pct']=(row['arms'][b]['kernel_sum_mean_us']/row['arms'][a]['kernel_sum_mean_us']-1)*100
   rows.append(row)
result={'scope':'One retained profiler run, GPU-stage attribution only, never replaces ordinary whole-episode primary. Each timed region touches only its warmed active pair.','episodes':len(ep),'timed_kernels':65536,'outside_timed_kernels':outside,'sqlite_sha256':hashlib.sha256((P/'profile.sqlite').read_bytes()).hexdigest(),'resources':[{'shape':k[0],'arm':k[1],'kind':k[2],'variants':[dict(registers=r[0],dynamic_shared=r[1],local_bytes=r[2],grid=r[3:6],block=r[6:9],mangled=r[9]) for r in sorted(v)]} for k,v in resources.items()],'strata':rows}
(OUT/'analysis.json').write_text(json.dumps(result,indent=2)+'\n')
with (OUT/'episode-kernels.jsonl').open('w') as f:
 for i,e in enumerate(ep):
  row={k:e[k] for k in ['alloc','shape','pair','arm','kernels','stages']};row['index']=i;f.write(json.dumps(row)+'\n')
for row in rows:
 if row['shape']=='prefill':print(row['alloc'],row['pair'],row['b_over_a_gpu_delta_pct'],row['b_over_a_gpu_sum_delta_pct'])
for r in result['resources']:
 if r['shape']=='prefill':print('RESOURCE',r['arm'],r['kind'],[{k:v for k,v in x.items() if k!='mangled'} for x in r['variants']])
