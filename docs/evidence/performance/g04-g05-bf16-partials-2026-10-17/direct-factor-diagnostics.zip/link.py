import pathlib,subprocess,re,json,hashlib,shutil,time
P=pathlib.Path('/root/hyle-scratch/compute-unified/g04-factorial-fulltu')
OLD=pathlib.Path('/root/hyle-scratch/compute-unified/g04-same-process-ilp')
OUT=pathlib.Path('/mnt/c/public/project-hyle/hyle/.scratch/g04-factorial-fulltu')
def run(a):return subprocess.check_output([str(x) for x in a],text=True)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def nm(p,external=False,undefined=False):return run(['nm','--format=posix','--undefined-only' if undefined else '--defined-only']+(['--extern-only'] if external else [])+[p])
def names(s):return {x.split()[0] for x in s.splitlines()}
factor=P/'native_cache_factor.o';assert factor.exists()
factory='_ZN4hyle7compute10flashinfer8providerEv'
arms=['00','01','10','11','orig']
objects={};report={'arms':{}}
for arm in arms:
 files=[OLD/'original/flashinfer_provider.cc.o',OLD/'original/native_batch.cu.o',factor if arm!='orig' else pathlib.Path('/root/hyle-scratch/compute-unified/g04-load-ilp-2026-10-17/consumer/native_cache_control.o')]
 folder=P/arm;folder.mkdir(exist_ok=False);defs=set();sigs=set()
 for i,p in enumerate(files):
  defs.update(names(nm(p,True)));groups=run(['readelf','--section-groups',p]);sigs.update(re.findall(r'COMDAT group section.*?\[([^\]]+)\] contains',groups));(folder/f'before-{i}.groups.txt').write_text(groups);(folder/f'before-{i}.symbols.txt').write_text(run(['readelf','-Ws',p]))
 mapping={n:'g04f_'+arm+'_'+n for n in defs|sigs}
 mp=folder/'rename.syms';mp.write_text(''.join(f'{a} {b}\n' for a,b in sorted(mapping.items())))
 rows=[];objects[arm]=[]
 for i,p in enumerate(files):
  dst=folder/['provider.o','batch.o','cache.o'][i];subprocess.run(['objcopy','--redefine-syms='+str(mp),str(p),str(dst)],check=True);objects[arm].append(dst)
  assert names(nm(dst,True))=={mapping[n] for n in names(nm(p,True))}
  assert names(nm(dst,undefined=True))=={mapping.get(n,n) for n in names(nm(p,undefined=True))}
  (folder/f'after-{i}.symbols.txt').write_text(run(['readelf','-Ws',dst]));(folder/f'after-{i}.groups.txt').write_text(run(['readelf','--section-groups',dst]))
  rows.append({'source':str(p),'source_sha256':sha(p),'clone':str(dst),'clone_sha256':sha(dst)})
 report['arms'][arm]={'objects':rows,'mapping':mapping}
# True original cold-expanded BF16 peer, not the cropped D3 bridge.
peerarchive=pathlib.Path('/root/hyle-scratch/compute-unified/g04-ce28-producer-stage-build-1/original-peer/libg04_cuda_encoded_original.a')
folder=P/'peer';folder.mkdir();(folder/'native-original.o').write_bytes(subprocess.check_output(['ar','p',str(peerarchive),'cuda_encoded_page_native.cu.o']))
files=[pathlib.Path('/root/hyle-scratch/compute-unified/g04-causal-diagnostic-1/build/CMakeFiles/diag.dir/bench/inference_resident_sdpa/cuda_encoded_page_reference.cc.o'),folder/'native-original.o']
defs=set();sigs=set()
for i,p in enumerate(files):
 defs.update(names(nm(p,True)));groups=run(['readelf','--section-groups',p]);sigs.update(re.findall(r'COMDAT group section.*?\[([^\]]+)\] contains',groups));(folder/f'before-{i}.groups.txt').write_text(groups);(folder/f'before-{i}.symbols.txt').write_text(run(['readelf','-Ws',p]))
mapping={n:'g04f_peer_'+n for n in defs|sigs};mapping[factory]='g04f_orig_'+factory
mp=folder/'rename.syms';mp.write_text(''.join(f'{a} {b}\n' for a,b in sorted(mapping.items())))
rows=[];objects['peer']=[]
for i,p in enumerate(files):
 dst=folder/['reference.o','native.o'][i];subprocess.run(['objcopy','--redefine-syms='+str(mp),str(p),str(dst)],check=True);objects['peer'].append(dst)
 assert names(nm(dst,True))=={mapping[n] for n in names(nm(p,True))}
 assert names(nm(dst,undefined=True))=={mapping.get(n,n) for n in names(nm(p,undefined=True))}
 (folder/f'after-{i}.symbols.txt').write_text(run(['readelf','-Ws',dst]));(folder/f'after-{i}.groups.txt').write_text(run(['readelf','--section-groups',dst]))
 rows.append({'source':str(p),'source_sha256':sha(p),'clone':str(dst),'clone_sha256':sha(dst)})
report['arms']['peer']={'objects':rows,'mapping':mapping,'native_archive':str(peerarchive),'native_archive_sha256':sha(peerarchive)}
seen=set()
for arm,ff in objects.items():
 dd=set.union(*(names(nm(f,True)) for f in ff));assert not seen&dd;seen|=dd
header='#pragma once\n#include "factor_record.h"\n#include "cuda_encoded_page_reference.h"\n'
header+='using FactorRecord=hyle::compute::flashinfer::native::FactorReplayRecord;\n'
header+='struct Binding {hyle::compute::Provider(*provider)() noexcept;void(*configure)(bool,bool,const void*,const void*)noexcept;const FactorRecord*(*get)()noexcept;cudaError_t(*replay)(cudaStream_t);cudaError_t(*dump)(const char*);};\n'
for arm in arms:
 m=report['arms'][arm]['mapping']
 header+=f'hyle::compute::Provider provider_{arm}() noexcept asm("{m[factory]}");\n'
 if arm!='orig':
  for token,signature in [('configure_factor',f'void config_{arm}(bool,bool,const void*,const void*) noexcept'),('get_factor_record',f'const FactorRecord* get_{arm}() noexcept'),('replay_factor',f'cudaError_t replay_{arm}(cudaStream_t)'),('dump_factor_plan',f'cudaError_t dump_{arm}(const char*)')]:
   key=next(n for n in m if token in n);header+=signature+' asm("'+m[key]+'");\n'
m=report['arms']['peer']['mapping']
for token,signature in [('cuda_encoded_reference_provider','hyle::compute::Provider peer_provider(const hyle::bench::resident::CudaEncodedReferenceData*) noexcept'),('prepare_cuda_encoded_reference','hyle::Status peer_prepare(hyle::bench::resident::CudaEncodedReferenceData&,hyle::compute::Queue&,hyle::compute::BatchLayoutVersion,hyle::compute::PagedArenaRead,hyle::compute::PagedArenaRead,hyle::mem::MemoryResourceRef) noexcept')]:
 key=next(n for n in m if token in n);header+=signature+' asm("'+m[key]+'");\n'
header+='inline constexpr const char* arm_names[]{"00","01","10","11","orig","peer"};\ninline const Binding bindings[]{\n'
for arm in arms:header+='{&provider_'+arm+(','+','.join('&'+x+'_'+arm for x in ['config','get','replay','dump']) if arm!='orig' else ',nullptr,nullptr,nullptr,nullptr')+'},\n'
header+='};\n';(P/'bindings.h').write_text(header);(OUT/'bindings.h').write_text(header)
c=json.loads((OLD/'commands.json').read_text());c['compile']=[str(P/'consumer.cc') if x==str(OLD/'bench/cuda_encoded_page_bench.cc') else str(P/'consumer.o') if x==str(OLD/'consumer.o') else x for x in c['compile']];c['compile'][1:1]=['-I'+str(P),'-I/root/hyle-scratch/compute-unified/source-7a7b4c3b/src/compute_provider_flashinfer']
old_objects=[str(OLD/arm/p) for arm in ['control','treatment'] for p in ['provider.o','batch.o','cache.o']]
link=[]
for x in c['link']:
 if x==old_objects[0]:link.extend(str(f) for ff in objects.values() for f in ff)
 elif x in old_objects:continue
 elif x==str(OLD/'consumer.o'):link.append(str(P/'consumer.o'))
 elif x==str(OLD/'g04_same_process'):link.append(str(P/'factorial'))
 elif x=='-Wl,-Map='+str(OLD/'link.map'):link.append('-Wl,-Map='+str(P/'link.map'))
 else:link.append(x)
c['link']=link;(P/'commands.json').write_text(json.dumps(c,indent=2)+'\n');(OUT/'commands.json').write_bytes((P/'commands.json').read_bytes());(P/'object-identity.json').write_text(json.dumps(report,indent=2)+'\n');(OUT/'object-identity.json').write_bytes((P/'object-identity.json').read_bytes())
build={}
for stage in ['compile','link']:
 start=time.monotonic()
 with (P/('host-'+stage+'.log')).open('w') as f:z=subprocess.run(c[stage],stdout=f,stderr=subprocess.STDOUT)
 build[stage]={'exit_code':z.returncode,'seconds':time.monotonic()-start};print(stage,build[stage],flush=True)
 if z.returncode:print((P/('host-'+stage+'.log')).read_text()[-7000:]);break
(P/'host-build-result.json').write_text(json.dumps(build,indent=2)+'\n')
for name in ['host-compile.log','host-link.log','host-build-result.json','link.map']:
 if (P/name).exists():(OUT/name).write_bytes((P/name).read_bytes())
print('linked', (P/'factorial').exists(),flush=True)
