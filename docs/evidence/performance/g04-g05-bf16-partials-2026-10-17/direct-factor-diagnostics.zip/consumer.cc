#if defined(_MSC_VER)
#define _CRT_SECURE_NO_WARNINGS
#endif
#include "cuda_encoded_page_reference.h"
#include "hyle/compute/backends/cuda.h"
#include "hyle/compute/providers/flashinfer.h"

#include "hyle/compute/batch_execution.h"
#include "hyle/simd/dtype.h"
#include <cstring>
#include <cuda_runtime_api.h>
#include <sched.h>
#include <array>
#include <algorithm>
#include <bit>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <chrono>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <memory>
#include <string>
#include <vector>
#include <nvtx3/nvToolsExt.h>

#include "bindings.h"
namespace {
#ifndef HYLE_RESIDENT_PLACEMENT
#define HYLE_RESIDENT_PLACEMENT 0
#endif
namespace c=hyle::compute;
bool diagnostic_trace=false;
void push(const char *s){if(diagnostic_trace)nvtxRangePushA(s);}
void pop(){if(diagnostic_trace)nvtxRangePop();}
[[noreturn]] void fail(hyle::Status status){std::fprintf(stderr,"CUDA encoded: %.*s\n",int(status.message().size()),status.message().data());std::exit(2);}
void check(hyle::Status status){if(!status.ok())fail(status);}
template<class T>T take(hyle::Result<T> value){if(!value)fail(value.error());return std::move(*value);}
bool set(const char *name){const auto *p=std::getenv(name);return p&&*p;}
float decode(std::uint16_t x){return std::bit_cast<float>(std::uint32_t(x)<<16);}
std::uint16_t encode(float x){return std::uint16_t(std::bit_cast<std::uint32_t>(x)>>16);}
double fp8(std::uint8_t code){const unsigned e=(code&127)>>3,m=code&7;
  const double value=e?std::ldexp(1.+double(m)/8.,int(e)-7):std::ldexp(double(m)/8.,-6);
  return code&128?-value:value;
}
struct Data {
  c::BatchCapacity capacity;
  std::array<std::int32_t,3> qp,kp;
  std::vector<std::int32_t> ids;std::array<std::int32_t,2> tails;
  std::vector<std::uint16_t> query;
  std::array<std::vector<std::byte>,2> packed;
  std::array<std::vector<float>,2> decoded;
  float scale;bool causal;std::int32_t window;
  Data(int q1,int q2,int k1,int k2,int dk,int dv,bool masked,int left):
    capacity{.storage=c::BatchStorage::kPaged,.query_type=c::DataType::kBFloat16,
      .output_type=c::DataType::kBFloat16,.key_storage=c::CacheStorage::float8(.5F).value(),
      .value_storage=c::CacheStorage::float8(2.F).value(),.max_requests=2,
      .max_query_rows=unsigned(q1+q2+3),.max_kv_rows=unsigned(k1+k2+13),
      .max_pages=unsigned((k1+15)/16+(k2+15)/16+2),.max_page_refs=unsigned((k1+15)/16+(k2+15)/16),
      .query_heads=8,.kv_heads=2,.qk_head_dim=unsigned(dk),.value_head_dim=unsigned(dv),.page_size=16},
    qp{0,q1,q1+q2},kp{0,(k1+15)/16,(k1+15)/16+(k2+15)/16},
    scale(1.F/std::sqrt(float(dk))),causal(masked),window(left){
    tails={(k1-1)%16+1,(k2-1)%16+1};
    for(unsigned i=0;i<capacity.max_page_refs;++i)ids.push_back(static_cast<std::int32_t>(capacity.max_pages-1-i));
    ids[static_cast<unsigned>(kp[1])]=ids[0];
    query.resize(std::size_t(capacity.max_query_rows)*8*dk);
    for(std::size_t i=0;i<query.size();++i)query[i]=encode(.125F+float((i/dk)%8%3)*.015625F);
    for(unsigned port=0;port<2;++port){
      const auto depth=port?dv:dk;
      auto &bytes=packed[port];auto &values=decoded[port];
      values.resize(std::size_t(capacity.max_pages)*16*2*depth);
      bytes.resize(values.size());
      // Independent finite FP8 fixture; the oracle decodes these actual bytes.
      for(std::size_t i=0;i<bytes.size();++i){
        const auto row=i/(2*depth),head=(i/depth)%2;
        constexpr std::uint8_t key_codes[]{0,56,64,68,72},value_codes[]{16,24,28,32,34};
        const auto code=(port?value_codes:key_codes)[(row+head)%5];
        bytes[i]=std::byte(code);values[i]=float(fp8(code)*(port?2.:.5));
      }
      for(unsigned page=0;page<capacity.max_pages;++page){
        unsigned valid=0;
        for(unsigned r=0;r<2;++r)for(auto ref=kp[r];ref<kp[r+1];++ref)
          if(ids[unsigned(ref)]==int(page))valid=std::max(valid,ref+1==kp[r+1]?unsigned(tails[r]):16u);
        for(auto i=std::size_t(page*16+valid)*2*depth;i<std::size_t((page+1)*16)*2*depth;++i){
          bytes[i]=std::byte(0x78);values[i]=float(fp8(0x78)*(port?2.:.5));
        }
      }
    }
  }
  std::size_t row_bytes(unsigned port)const{return std::size_t(2)*(port?capacity.value_head_dim:capacity.qk_head_dim);}
  std::vector<double> oracle()const{
    const auto dk=capacity.qk_head_dim,dv=capacity.value_head_dim;
    std::vector<double> output(std::size_t(qp[2])*8*dv),weights;double uniform_difference=0;
    for(unsigned r=0;r<2;++r){const int nq=qp[r+1]-qp[r],nk=(kp[r+1]-kp[r]-1)*16+tails[r];weights.resize(nk);
      for(int row=0;row<nq;++row)for(unsigned h=0;h<8;++h){double sum=0;
        const auto position=nk-nq+row;
        for(int j=0;j<nk;++j){
          if(causal&&(j>position||(window>=0&&j<std::max(0,position-window)))){weights[j]=0;continue;}
          double dot=0;for(unsigned d=0;d<dk;++d)dot+=double(decode(query[(std::size_t(qp[r]+row)*8+h)*dk+d]))*
              decoded[0][((std::size_t(ids[static_cast<unsigned>(kp[r]+j/16)])*16+j%16)*2+h/4)*dk+d];
          weights[j]=std::exp(dot*scale);sum+=weights[j];
        }
        for(unsigned d=0;d<dv;++d)for(int j=0;j<nk;++j)output[(std::size_t(qp[r]+row)*8+h)*dv+d]+=
            weights[j]/sum*decoded[1][((std::size_t(ids[static_cast<unsigned>(kp[r]+j/16)])*16+j%16)*2+h/4)*dv+d];
        double uniform=0;unsigned eligible=0;
        for(int j=0;j<nk;++j)if(weights[j]>0){++eligible;
          uniform+=decoded[1][((std::size_t(ids[unsigned(kp[r]+j/16)])*16+j%16)*2+h/4)*dv];}
        uniform_difference=std::max(uniform_difference,std::abs(
            output[(std::size_t(qp[r]+row)*8+h)*dv]-uniform/eligible));
      }
    }
    if(uniform_difference<=.01)fail(hyle::Status::Internal("FP8 oracle fixture cannot distinguish missing QK loads"));
    std::fprintf(stderr,"# CUDA_ENCODED_ORACLE uniform_difference=%.9g\n",uniform_difference);
    return output;
  }
};
struct Harness {
  unsigned arm_id=0;
  std::unique_ptr<hyle::bench::resident::CudaEncodedReferenceData> reference;
  std::array<hyle::mem::Buffer,2> expanded;
  std::array<std::vector<std::uint16_t>,2> expanded_expected;
  c::Context context;c::cuda::MemoryResource memory,host;c::Queue queue;c::BatchSchema schema;c::BatchLayoutVersion layout;
  c::BatchProgram program;std::array<c::BatchInvocation,2> slots;c::LeasePool pool;
  c::PagedArena keys,values;c::PagedArenaRead key_frame,value_frame;
  std::vector<c::ReadLease> key_pages,value_pages;std::vector<unsigned> physical_ids;c::ReadLease query;std::size_t next=0;
  Harness(const Data &data,unsigned arm):arm_id(arm){
    const bool original=arm==5;
    if(original)reference=std::make_unique<hyle::bench::resident::CudaEncodedReferenceData>();
    context=take(c::Context::create(take(c::cuda::device(0)),original?peer_provider(reference.get()):bindings[arm].provider()));
    const auto env=take(c::cuda::environment(context));
    if(env.sm_major!=8||env.sm_minor!=9)fail(hyle::Status::Unimplemented("finite actual SM89 profile"));
    std::fprintf(stderr,"# CUDA_ENCODED_ENV device=%s sm=%d%d driver=%s runtime=%d toolkit=%d original=%d\n",
        env.device_name.data(),env.sm_major,env.sm_minor,env.driver_release.data(),env.runtime_version,env.build_toolkit_version,original);
    memory=take(c::cuda::MemoryResource::create(context,c::cuda::MemoryKind::kDevice));
    host=take(c::cuda::MemoryResource::create(context,c::cuda::MemoryKind::kPinnedHost));
    queue=take(context.create_queue());
    schema=take(c::BatchSchema::create(data.capacity));layout=take(schema.version({data.qp,data.kp,data.ids,data.tails}));
    const auto key_bytes=16*data.row_bytes(0),value_bytes=16*data.row_bytes(1);
    keys=take(c::PagedArena::create(schema,c::BatchCacheRole::kKey,memory.ref(),{.max_backing_bytes=key_bytes*data.capacity.max_pages+1}));
    values=take(c::PagedArena::create(schema,c::BatchCacheRole::kValue,memory.ref(),{.max_backing_bytes=value_bytes*data.capacity.max_pages+1}));
    for(unsigned page=0;page<data.capacity.max_pages;++page)if(std::find(data.ids.begin(),data.ids.end(),static_cast<std::int32_t>(page))!=data.ids.end()){
      auto kw=take(keys.acquire(page)),vw=take(values.acquire(page));
      check(kw.lease().view()->write(std::span(data.packed[0]).subspan(page*key_bytes,key_bytes)));
      check(vw.lease().view()->write(std::span(data.packed[1]).subspan(page*value_bytes,value_bytes)));
      physical_ids.push_back(page);key_pages.push_back(take(kw.publish(16)));value_pages.push_back(take(vw.publish(16)));
    }
    key_frame=take(keys.read(layout,key_pages));value_frame=take(values.read(layout,value_pages));
    if(original)check(peer_prepare(*reference,queue,layout,key_frame,value_frame,memory.ref()));
    const bool primary=data.capacity.qk_head_dim==256 && data.capacity.value_head_dim==256 && data.causal && data.window==-1;
    if(primary && (arm==2 || arm==3))for(unsigned port=0;port<2;++port){
      auto &raw=expanded_expected[port];raw.resize(data.packed[port].size());
      for(std::size_t i=0;i<raw.size();++i){const float value=float(fp8(std::to_integer<std::uint8_t>(data.packed[port][i])));raw[i]=encode(value);if(decode(raw[i])!=value)fail(hyle::Status::Internal("cold raw FP8 expansion was not exact BF16"));}
      expanded[port]=take(hyle::mem::Buffer::create(memory.ref(),raw.size()*2,256));
      check(expanded[port].view().write(std::as_bytes(std::span(raw))));
    }

    program=take(c::BatchProgram::prepare(context,schema,{.resource=memory.ref(),.host_workspace=host.ref(),
        .max_float_workspace_bytes=32u<<20,.max_int_workspace_bytes=4096,.scale=data.scale,.causal=data.causal,.window_left=data.window}));
    for(auto &slot:slots){slot=take(c::BatchInvocation::create(program,queue));auto prepared=take(slot.prepare_batch(layout));}
    pool=take(c::LeasePool::create(memory.ref(),data.query.size()*2+2048));
    auto writer=take(pool.allocate(data.query.size()*2));check(writer.view()->write(std::as_bytes(std::span(data.query))));query=take(writer.publish());
    if(arm<4){const void *k=nullptr,*v=nullptr;if(!expanded_expected[0].empty()){k=take(c::cuda::pointer<std::uint16_t>(expanded[0].view()));v=take(c::cuda::pointer<std::uint16_t>(expanded[1].view()));}bindings[arm].configure(arm>=2,(arm&1)!=0,k,v);}
    std::fprintf(stderr,"# FACTOR_RESIDENCY arm=%s original_fp8_bytes=%zu extra_raw_bf16_bytes=%zu cold_exact_unscaled=1 snapshots_retained_through_drain=1\n",arm_names[arm],data.packed[0].size()+data.packed[1].size(),expanded[0].size()+expanded[1].size());
    std::fprintf(stderr,"# CUDA_ENCODED_COLD original=%d known_float_bytes=%zu known_int_bytes=%zu tile=%u split=%d private_pool_upper=UNKNOWN requests=2 immutable_history=1\n",original,slots[0].report().float_workspace_bytes,slots[0].report().int_workspace_bytes,slots[0].report().cta_tile_q,slots[0].report().split_kv);
  }
  ~Harness(){const auto start=std::chrono::steady_clock::now();
    for(auto &slot:slots){check(slot.close());slot={};}
    program={};query.reset();pool={};key_frame={};value_frame={};
    key_pages.clear();value_pages.clear();keys={};values={};
    check(queue.drain());expanded={};reference.reset();queue={};host.reset();memory.reset();check(context.close());
    std::fprintf(stderr,"# CUDA_ENCODED_TEARDOWN seconds=%.9f\n",
        std::chrono::duration<double>(std::chrono::steady_clock::now()-start).count());
  }
  c::ReadLease execute(){auto &slot=slots[next++%slots.size()];
    push("update");auto prepared=take(slot.update_batch(layout));pop();
    if(!slot.report().reused_native_plan)fail(hyle::Status::Internal("paged warm topology rebuilt"));
    push("admit_submit");auto completion=take(prepared.run(query,key_frame,value_frame));pop();
    push("checked_wait");check(completion.wait());pop();
    push("output_acquire");auto output=take(slot.output());pop();return output;}
  std::vector<std::uint16_t> verify(const Data &data,const std::vector<double> &expected){auto output=execute();std::vector<std::uint16_t> actual(std::size_t(data.capacity.max_query_rows)*8*data.capacity.value_head_dim);check(output.view()->read(std::as_writable_bytes(std::span(actual))));
    double worst=0;for(std::size_t i=0;i<expected.size();++i){if(!std::isfinite(decode(actual[i])))fail(hyle::Status::Internal("paged nonfinite output"));worst=std::max(worst,std::abs(double(decode(actual[i]))-expected[i]));}
    if(worst>8e-3)fail(hyle::Status::Internal("paged independent double oracle exceeded 8e-3"));
    for(unsigned port=1;port<3;++port)for(unsigned index=0;index<key_pages.size();++index){const auto &lease=port==1?key_pages[index]:value_pages[index];auto view=take(lease.view());
      std::vector<std::byte> after(view.size());check(view.read(after));
      const auto first=data.packed[port-1].begin()+std::size_t(physical_ids[index])*16*data.row_bytes(port-1);
      if(!std::equal(after.begin(),after.end(),first))fail(hyle::Status::Internal("paged readonly KV changed"));
    }
    for(unsigned port=0;port<2;++port)if(!expanded_expected[port].empty()){
      std::vector<std::uint16_t> after(expanded_expected[port].size());check(expanded[port].view().read(std::as_writable_bytes(std::span(after))));
      if(after!=expanded_expected[port])fail(hyle::Status::Internal("cold BF16 snapshot changed"));
    }
    std::fprintf(stderr,"# CUDA_ENCODED_CORRECTNESS max_abs_error=%.9g elements=%zu\n",worst,expected.size());return actual;
  }
};


using Clock=std::chrono::steady_clock;
double us(Clock::duration d){return std::chrono::duration<double,std::micro>(d).count();}
void measure(unsigned alloc,int q1,int q2,int k1,int k2,int dk,int dv,bool causal,int window,bool verify_only=false){
  const char *shape=verify_only?"tail":(window>=0?"window":(dk==256?"prefill":"holdout"));
  Data data(q1,q2,k1,k2,dk,dv,causal,window);std::array<std::unique_ptr<Harness>,6> h;
  for(unsigned pos=0;pos<6;++pos){const unsigned arm=alloc?5-pos:pos;const auto start=Clock::now();h[arm]=std::make_unique<Harness>(data,arm);std::printf("COLD alloc=%u shape=%s arm=%s create_us=%.9f\n",alloc,shape,arm_names[arm],us(Clock::now()-start));}
  const auto expected=data.oracle();std::array<std::vector<std::uint16_t>,6> values;
  for(unsigned replay=0;replay<4;++replay)for(unsigned arm=0;arm<6;++arm)values[arm]=h[arm]->verify(data,expected);
  for(unsigned arm=0;arm<6;++arm){double diff=0;for(std::size_t i=0;i<expected.size();++i)diff=std::max(diff,std::abs(double(decode(values[0][i]))-decode(values[arm][i])));if(diff>8e-3)fail(hyle::Status::Internal("factorial arms disagree"));std::printf("ORACLE alloc=%u shape=%s arm=%s diff_from_00=%.9g\n",alloc,shape,arm_names[arm],diff);}
  if(!verify_only){
    if(dk==256 && window==-1)for(unsigned arm=0;arm<4;++arm){const auto status=bindings[arm].dump(arm_names[arm]);if(status!=cudaSuccess)fail(hyle::Status::Internal("cold factor plan dump failed"));}
    constexpr unsigned pairs[8][2]{{0,4},{0,2},{1,3},{0,1},{2,3},{0,5},{4,5},{3,5}};
    for(unsigned pair_index=0;pair_index<8;++pair_index){
      const auto &pair=pairs[alloc?7-pair_index:pair_index];
      const std::string pair_name=std::string(arm_names[pair[0]])+"-"+arm_names[pair[1]];
      // Only this pair touches device cache after its own warmup. Other owners stay cold/live.
      for(unsigned i=0;i<64;++i)for(unsigned pos=0;pos<2;++pos){const unsigned arm=pair[(i+pos)&1];auto output=h[arm]->execute();output.reset();}
      diagnostic_trace=set("G04_TRACE");push(pair_name.c_str());push(shape);
      std::array<std::array<double,2>,512> raw{};std::array<std::array<unsigned,2>,512> positions{};
      for(unsigned group=0;group<8;++group)for(unsigned step=0;step<64;++step)for(unsigned pos=0;pos<2;++pos){
        const unsigned side=(pos+step+group)&1,arm=pair[side];positions[group*64+step][side]=pos;
        push(arm_names[arm]);const auto start=Clock::now();{auto output=h[arm]->execute();output.reset();}
        raw[group*64+step][side]=us(Clock::now()-start);pop();
      }
      pop();pop();diagnostic_trace=false;
      for(unsigned group=0;group<8;++group){std::array<double,2>sums{};
        for(unsigned step=0;step<64;++step)for(unsigned side=0;side<2;++side){const auto i=group*64+step;sums[side]+=raw[i][side];std::printf("EP pair=%s alloc=%u shape=%s group=%u step=%u arm=%s us=%.9f position=%u\n",pair_name.c_str(),alloc,shape,group,step,arm_names[pair[side]],raw[i][side],positions[i][side]);}
        for(unsigned side=0;side<2;++side)std::printf("BLOCK pair=%s alloc=%u shape=%s group=%u arm=%s count=64 mean_us=%.9f\n",pair_name.c_str(),alloc,shape,group,arm_names[pair[side]],sums[side]/64);
      }
    }
    for(unsigned arm=0;arm<6;++arm)h[arm]->verify(data,expected);
  }
  for(unsigned pos=0;pos<6;++pos){const unsigned arm=alloc?5-pos:pos;const auto start=Clock::now();h[arm].reset();std::printf("CLOSE alloc=%u shape=%s arm=%s close_us=%.9f\n",alloc,shape,arm_names[arm],us(Clock::now()-start));}
}
}
int main(){
  cpu_set_t cpus;CPU_ZERO(&cpus);CPU_SET(2,&cpus);if(sched_setaffinity(0,sizeof(cpus),&cpus)!=0)std::abort();
  std::printf("SCHEDULE arms=00,01,10,11,orig,peer allocation_orders=2 groups=8 steps=64 warmups=64 active_arms=2 pairs=00-orig,00-10,01-11,00-01,10-11,00-peer,orig-peer,11-peer execution=pair-only-interleaved-balanced-AB-BA primary=complete-episode-arithmetic-mean no_trimming=1 trace=%d\n",set("G04_TRACE"));
  for(unsigned alloc=0;alloc<2;++alloc){measure(alloc,1,17,1024,768,256,256,true,16);measure(alloc,64,128,1024,768,256,256,true,-1);measure(alloc,17,1,7,47,64,128,false,-1);}
  measure(0,64,128,1023,767,256,256,true,-1,true);
  std::printf("EXIT code=0\n");return 0;
}
