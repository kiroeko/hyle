#pragma once
#include "native_batch.h"
namespace hyle::compute::flashinfer::native {
struct FactorReplayRecord {
  const void *state=nullptr;BatchSpec spec{};
  const void *q=nullptr,*k=nullptr,*v=nullptr,*metadata=nullptr;
  void *output=nullptr,*floating=nullptr,*integer=nullptr;
  cudaStream_t stream=nullptr;bool ready=false;
};
const FactorReplayRecord *get_factor_record() noexcept;
cudaError_t replay_factor(cudaStream_t);
cudaError_t dump_factor_plan(const char*);
void configure_factor(bool,bool,const void*,const void*) noexcept;
}
