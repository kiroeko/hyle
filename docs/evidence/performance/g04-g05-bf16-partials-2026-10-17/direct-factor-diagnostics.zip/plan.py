import pathlib,sys,json,collections,hashlib
source=pathlib.Path(sys.argv[1]);out=pathlib.Path(sys.argv[2]);plans=[]
seen=collections.Counter()
for line in source.read_text().splitlines():
 if line.startswith('FACTOR_PLAN '):
  d=dict(x.split('=',1) for x in line.split()[1:]);tag=d.pop('tag');index=seen[tag];seen[tag]+=1
  p={'arm':tag,'allocation_index':index,'facts':{k:int(v) for k,v in d.items()},'arrays':{}};plans.append(p)
 elif line.startswith('FACTOR_ARRAY '):
  d=dict(x.split('=',1) for x in line.split()[1:]);assert plans and plans[-1]['arm']==d['tag']
  values=[int(x) for x in d['values'].split(',')];assert len(values)==int(d['count']);plans[-1]['arrays'][d['name']]=values
assert len(plans)==8
for p in plans:
 m=p['arrays']['merge_indptr'];assert len(m)==193 and all(a<=b for a,b in zip(m,m[1:]));lengths=[b-a for a,b in zip(m,m[1:])];states=m[-1]-m[0]
 p['derived']={'logical_merge_rows':192,'partial_states_read_by_merge':states,'merge_lengths_histogram':dict(collections.Counter(lengths)),'merge_rows_zero_states':lengths.count(0),'merge_rows_one_state':lengths.count(1),'merge_rows_multiple_states':sum(x>1 for x in lengths),'partial_dtype':'BF16' if p['arm'].endswith('1') else 'F32','partial_payload_bytes':states*8*256*(2 if p['arm'].endswith('1') else 4),'score_payload_bytes':states*8*4,'payload_scope':'Logical partial/score elements named by merge_indptr, not the allocated workspace capacity, memory-transaction bytes, or measured DRAM traffic.','attention_grid':[p['facts']['padded_batch_size'],1,2]}
for alloc in range(2):
 pp=[p for p in plans if p['allocation_index']==alloc];assert len(pp)==4
 for p in pp[1:]:assert p['facts']==pp[0]['facts'] and p['arrays']==pp[0]['arrays'],'Original FP8 planner facts/arrays differ among controlled corners'
result={'source':str(source),'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'controlled_corners_original_planner_identical':True,'plans':plans}
out.write_text(json.dumps(result,indent=2)+'\n')
for p in plans:print(p['allocation_index'],p['arm'],p['facts'],p['derived'])
