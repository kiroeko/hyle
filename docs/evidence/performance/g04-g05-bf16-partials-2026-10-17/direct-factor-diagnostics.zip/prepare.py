import pathlib,shutil,hashlib,json,zipfile,subprocess,time,datetime,difflib
P=pathlib.Path('/root/hyle-scratch/compute-unified/g04-factorial-fulltu')
OUT=pathlib.Path('/mnt/c/public/project-hyle/hyle/.scratch/g04-factorial-fulltu')
P.mkdir(exist_ok=True)
Z=zipfile.ZipFile('/mnt/c/public/project-hyle/hyle/evidence/architecture/inference-performance-recovery-2026-10-17/source-and-raw.zip')
old=json.loads(Z.read('diagnostic/g04-load-ilp-compile-receipt.json'))
original=pathlib.Path(old['original_compile_record']['file'])
header=pathlib.Path('/root/hyle-scratch/compute-unified/l-cpu-cuda/selected-graph/static-sdk-build/src/compute_provider_flashinfer/cache-source-92767c3031b8a0a753f0cd36ce14ea792ac4595d7e1939c81d8deadf49ba7c4b/include')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(original)==old['source_sha256'];assert sha(header/'flashinfer/attention/prefill.cuh')==old['original_prefill_sha256']
shutil.copytree(header,P/'include',dirs_exist_ok=True)
s=original.read_text();initial=s
def edit(a,b):
 global s
 assert s.count(a)==1,(a[:100],s.count(a));s=s.replace(a,b)
edit('#include "native_batch.h"','#include "native_batch.h"\n#include "factor_record.h"\n#include <cstdio>\n#include <vector>')
edit('namespace {\ntemplate<class Q,unsigned Depth>cudaError_t merge_f32(float *values', '''namespace {
bool factor_bf16_kv=false,factor_bf16_partial=false;
const void *factor_key=nullptr,*factor_value=nullptr;
FactorReplayRecord factor_record{};
template<class Q,unsigned Depth>cudaError_t merge_f32(float *values''')
helper=initial[initial.index('template<class Q,unsigned Depth>cudaError_t merge_f32'):initial.index('\n}\n}\n#include <flashinfer/attention/prefill.cuh>')]
narrow_helper=helper.replace('merge_f32(float *values','merge_partial16(Q *values').replace('constexpr unsigned stages=2,shared=stages*y*Depth*sizeof(float)+128*sizeof(float);','constexpr unsigned stages=4,shared=stages*y*Depth*sizeof(Q)+128*sizeof(float);').replace('stages,float,Q,std::int32_t,true>','stages,Q,Q,std::int32_t,true>')
edit('\n}\n}\n#include <flashinfer/attention/prefill.cuh>', '\n'+narrow_helper+'\n}\n}\n#include <flashinfer/attention/prefill.cuh>')
edit('namespace {\ntemplate<class Base>struct OutputParams', '''namespace {
struct NarrowAttention:fi::DefaultAttention<false,true,false,false> {
  using Base=fi::DefaultAttention<false,true,false,false>;
  using Base::Base;
  static constexpr bool hyle_factor_narrow_partial=true;
};
template<class Base>struct OutputParams''')
edit('template<class Params>void bind_plan', '''template<class Base,class Q,unsigned Depth>struct Partial16MergeParams:Base {
  Q *final_output=nullptr;
  float final_scale=1.F;
  cudaError_t merge_states(Q *values,float *scores,float *final_lse,cudaStream_t stream) const {
    return merge_partial16<Q,Depth>(values,scores,this->merge_indptr,final_output,final_lse,
        this->max_total_num_rows,this->total_num_rows,this->num_qo_heads,final_scale,stream);
  }
};
template<class Params>void bind_plan''')
edit('using Variant=fi::DefaultAttention<false,true,false,false>;', 'using Variant=std::conditional_t<fi::HyleHasMergeStates<Params>::value && std::is_same_v<typename Params::DTypeO,__nv_bfloat16>,NarrowAttention,fi::DefaultAttention<false,true,false,false>>;')
edit('template<class Q,class KV,unsigned QK,unsigned VO,bool Split>','template<class Q,class KV,unsigned QK,unsigned VO,bool Split,bool Narrow=false>')
edit('using O=std::conditional_t<Split,float,Q>;','using O=std::conditional_t<Split && !Narrow,float,Q>;')
# BF16 raw expansion is swapped only for the split primary; non-split paths stay original.
edit('std::conditional_t<Split,MergeParams<Base,Q,VO>,OutputParams<Base>> params;', 'std::conditional_t<Split,std::conditional_t<Narrow,Partial16MergeParams<Base,Q,VO>,MergeParams<Base,Q,VO>>,OutputParams<Base>> params;') if s.count('std::conditional_t<Split,MergeParams<Base,Q,VO>,OutputParams<Base>> params;')==1 else None
s=s.replace('std::conditional_t<Split,MergeParams<Base,Q,VO>,OutputParams<Base>> params;','std::conditional_t<Split,std::conditional_t<Narrow,Partial16MergeParams<Base,Q,VO>,MergeParams<Base,Q,VO>>,OutputParams<Base>> params;')
edit('if constexpr(sizeof(KV)==1){','if constexpr(sizeof(KV)==1 || (QK==256 && VO==256)){')
needle='}\ncudaError_t run_cache_batch'
addition='''
template<class Q>cudaError_t factor_dispatch(const fi::PrefillPlanInfo &plan,BatchSpec spec,
    const void *q,const void *k,const void *v,const void *metadata,void *output,void *floating,void *integer,cudaStream_t stream){
  const bool primary=spec.bfloat16 && spec.paged && spec.causal && spec.window_left==-1 &&
      spec.qk_head_dim==256 && spec.value_head_dim==256 && plan.cta_tile_q==64 && plan.split_kv;
  if(primary && factor_bf16_kv){
    if(!factor_key || !factor_value)return cudaErrorInvalidValue;
    spec.fp8=false;k=factor_key;v=factor_value;
  }
  if(primary && factor_bf16_partial){
    return spec.fp8?run_output<Q,__nv_fp8_e4m3,256,256,true,true>(plan,spec,q,k,v,metadata,output,floating,integer,stream):
                    run_output<Q,Q,256,256,true,true>(plan,spec,q,k,v,metadata,output,floating,integer,stream);
  }
  return dispatch_kv<Q>(plan,spec,q,k,v,metadata,output,floating,integer,stream);
}
}
void configure_factor(bool bf16_kv,bool bf16_partial,const void *key,const void *value) noexcept {
  factor_bf16_kv=bf16_kv;factor_bf16_partial=bf16_partial;factor_key=key;factor_value=value;
  factor_record={};
}
const FactorReplayRecord *get_factor_record() noexcept{return &factor_record;}
cudaError_t replay_factor(cudaStream_t stream){
  if(!factor_record.ready)return cudaErrorInvalidValue;
  const auto r=factor_record;
  return run_cache_batch(r.state,r.spec,r.q,r.k,r.v,r.metadata,r.output,r.floating,r.integer,stream);
}
cudaError_t dump_factor_plan(const char *tag){
  if(!factor_record.ready)return cudaErrorInvalidValue;
  const auto &r=factor_record;const auto &p=*static_cast<const fi::PrefillPlanInfo*>(r.state);
  const auto read=[&](std::int64_t offset,std::size_t count,std::vector<std::int32_t>&values){values.resize(count);return cudaMemcpy(values.data(),static_cast<const char*>(r.integer)+offset,count*sizeof(std::int32_t),cudaMemcpyDeviceToHost);};
  std::vector<std::int32_t>request,qo,kv,merge,chunk;
  auto status=read(p.request_indices_offset,p.padded_batch_size,request);if(status!=cudaSuccess)return status;
  status=read(p.qo_tile_indices_offset,p.padded_batch_size,qo);if(status!=cudaSuccess)return status;
  status=read(p.kv_tile_indices_offset,p.padded_batch_size,kv);if(status!=cudaSuccess)return status;
  status=read(p.merge_indptr_offset,r.spec.query_rows+1,merge);if(status!=cudaSuccess)return status;
  status=read(p.kv_chunk_size_ptr_offset,1,chunk);if(status!=cudaSuccess)return status;
  std::printf("FACTOR_PLAN tag=%s query_rows=%u padded_batch_size=%lld cta_tile_q=%lld kv_chunk_rows=%d v_offset=%lld s_offset=%lld total_num_rows=%lld merge_indptr_offset=%lld request_indices_offset=%lld qo_tile_indices_offset=%lld kv_tile_indices_offset=%lld\\n",tag,r.spec.query_rows,(long long)p.padded_batch_size,(long long)p.cta_tile_q,chunk[0],(long long)p.v_offset,(long long)p.s_offset,(long long)p.total_num_rows,(long long)p.merge_indptr_offset,(long long)p.request_indices_offset,(long long)p.qo_tile_indices_offset,(long long)p.kv_tile_indices_offset);
  const auto print=[&](const char*name,const std::vector<std::int32_t>&a){std::printf("FACTOR_ARRAY tag=%s name=%s count=%zu values=",tag,name,a.size());for(std::size_t i=0;i<a.size();++i)std::printf("%s%d",i?",":"",a[i]);std::printf("\\n");};
  print("request",request);print("qo_tile",qo);print("kv_tile",kv);print("merge_indptr",merge);return cudaSuccess;
}
cudaError_t run_cache_batch'''
edit(needle,addition)
edit('if(!spec.query_rows)return cudaSuccess;','''if(!spec.query_rows)return cudaSuccess;
  if(!factor_record.ready && spec.bfloat16 && spec.paged && spec.causal && spec.window_left==-1 && spec.qk_head_dim==256 && spec.value_head_dim==256){
    factor_record={state,spec,q,k,v,metadata,output,floating,integer,stream,true};
  }''')
edit('return spec.bfloat16?dispatch_kv<__nv_bfloat16>(plan,spec,q,k,v,metadata,output,floating,integer,stream):\n                      dispatch_kv<half>(plan,spec,q,k,v,metadata,output,floating,integer,stream);','return spec.bfloat16?factor_dispatch<__nv_bfloat16>(plan,spec,q,k,v,metadata,output,floating,integer,stream):\n                      factor_dispatch<half>(plan,spec,q,k,v,metadata,output,floating,integer,stream);')
(P/'native_cache.cu').write_text(s)
record_header='''#pragma once
#include "native_batch.h"
namespace hyle::compute::flashinfer::native {
struct FactorReplayRecord {
  const void *state=nullptr;BatchSpec spec{};
  const void *q=nullptr,*k=nullptr,*v=nullptr,*metadata=nullptr;
  void *output=nullptr,*floating=nullptr,*integer=nullptr;
  cudaStream_t stream=nullptr;bool ready=false;
};
const FactorReplayRecord *get_factor_record() noexcept;
cudaError_t replay_factor(cudaStream_t);
cudaError_t dump_factor_plan(const char*);
void configure_factor(bool,bool,const void*,const void*) noexcept;
}
'''
(P/'factor_record.h').write_text(record_header);(OUT/'factor_record.h').write_text(record_header)
h=P/'include/flashinfer/attention/prefill.cuh';t=h.read_text();initial_h=t
needle='template <MaskMode MASK_MODE_, uint32_t CTA_TILE_Q_'
assert t.count(needle)==1
t=t.replace(needle,'''template <typename Variant,typename=void> struct HyleFactorNarrowPartial:std::false_type {};
template <typename Variant> struct HyleFactorNarrowPartial<Variant,std::void_t<decltype(Variant::hyle_factor_narrow_partial)>>:std::bool_constant<Variant::hyle_factor_narrow_partial> {};

'''+needle)
needle='USE_KV_REPACK && std::is_same_v<DTypeO_, float> &&';assert t.count(needle)==1
t=t.replace(needle,'USE_KV_REPACK && (std::is_same_v<DTypeO_, float> || (HyleFactorNarrowPartial<AttentionVariant_>::value && std::is_same_v<DTypeO_,__nv_bfloat16> && HEAD_DIM_QK==256 && HEAD_DIM_VO==256 && CTA_TILE_Q==64)) &&')
h.write_text(t)
(OUT/'native_cache.cu').write_bytes((P/'native_cache.cu').read_bytes());(OUT/'prefill.cuh').write_bytes(h.read_bytes())
(OUT/'source.diff').write_text(''.join(difflib.unified_diff(initial.splitlines(True),s.splitlines(True),fromfile='original/native_cache.cu',tofile='factor/native_cache.cu'))+''.join(difflib.unified_diff(initial_h.splitlines(True),t.splitlines(True),fromfile='original/prefill.cuh',tofile='factor/prefill.cuh')))
args=old['command'];args=[('-I'+str(P/'include')) if x=='-I'+old['work']+'/include' else str(P/'native_cache.cu') if x==str(original) else str(P/'native_cache_factor.o') if x==old['work']+'/native_cache_load_ilp.o' else str(P/'native_cache_factor.d') if x==old['work']+'/native_cache_load_ilp.d' else x for x in args]
meta={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'original_source':str(original),'original_source_sha256':sha(original),'original_header':str(header/'flashinfer/attention/prefill.cuh'),'original_header_sha256':sha(header/'flashinfer/attention/prefill.cuh'),'source_sha256':sha(P/'native_cache.cu'),'header_sha256':sha(h),'nvcc_argv':args,'full_tu_not_cropped':True,'provider_and_native_batch_reused_unchanged':True,'primary_scope':'BF16Q+D256/paged/causal/window-1/CTA64/split','scale_timing':'KV expansion raw unscaled; original BatchSpec.key_scale0.5 / value_scale2 preserved; all partial merge SCALE_OUTPUTtrue','partial_factor':'F32partial+2stage merge vs BF16partial+4stage merge; both shared8704. This is the native partial pipeline bundle, not pure store bandwidth.'}
(P/'identity.json').write_text(json.dumps(meta,indent=2)+'\n');(OUT/'identity.json').write_bytes((P/'identity.json').read_bytes())
print(json.dumps(meta),flush=True)
start=time.monotonic()
with (P/'compile.log').open('w') as f:z=subprocess.run(args,stdout=f,stderr=subprocess.STDOUT)
meta.update(compile_exit=z.returncode,compile_seconds=time.monotonic()-start)
if z.returncode==0:meta['object_sha256']=sha(P/'native_cache_factor.o')
(P/'compile-result.json').write_text(json.dumps(meta,indent=2)+'\n')
for name in ['compile.log','compile-result.json']:(OUT/name).write_bytes((P/name).read_bytes())
print(json.dumps({k:v for k,v in meta.items() if k in ['compile_exit','compile_seconds','object_sha256']}),flush=True)
