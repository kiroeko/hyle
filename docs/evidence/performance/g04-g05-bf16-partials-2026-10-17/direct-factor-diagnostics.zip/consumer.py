import pathlib,shutil
P=pathlib.Path('/root/hyle-scratch/compute-unified/g04-factorial-fulltu')
OUT=pathlib.Path('/mnt/c/public/project-hyle/hyle/.scratch/g04-factorial-fulltu')
OLD=pathlib.Path('/root/hyle-scratch/compute-unified/g04-same-process-ilp/bench')
base=(OLD/'cuda_encoded_page_bench.cc').read_text()
start=base.index('namespace hyle::compute::flashinfer {');end=base.index('namespace {',start)
base=base[:start]+'#include "bindings.h"\n'+base[end:]
base=base[:base.index('using Clock=')]
base=base.replace('struct Harness {','''struct Harness {
  unsigned arm_id=0;
  std::unique_ptr<hyle::bench::resident::CudaEncodedReferenceData> reference;
  std::array<hyle::mem::Buffer,2> expanded;
  std::array<std::vector<std::uint16_t>,2> expanded_expected;''')
base=base.replace('Harness(const Data &data,bool original){\n    context=take(c::Context::create(take(c::cuda::device(0)),original?c::flashinfer::provider_control():c::flashinfer::provider_treatment()));', '''Harness(const Data &data,unsigned arm):arm_id(arm){
    const bool original=arm==5;
    if(original)reference=std::make_unique<hyle::bench::resident::CudaEncodedReferenceData>();
    context=take(c::Context::create(take(c::cuda::device(0)),original?peer_provider(reference.get()):bindings[arm].provider()));''')
needle='key_frame=take(keys.read(layout,key_pages));value_frame=take(values.read(layout,value_pages));'
replacement=needle+'''
    if(original)check(peer_prepare(*reference,queue,layout,key_frame,value_frame,memory.ref()));
    const bool primary=data.capacity.qk_head_dim==256 && data.capacity.value_head_dim==256 && data.causal && data.window==-1;
    if(primary && (arm==2 || arm==3))for(unsigned port=0;port<2;++port){
      auto &raw=expanded_expected[port];raw.resize(data.packed[port].size());
      for(std::size_t i=0;i<raw.size();++i){const float value=float(fp8(std::to_integer<std::uint8_t>(data.packed[port][i])));raw[i]=encode(value);if(decode(raw[i])!=value)fail(hyle::Status::Internal("cold raw FP8 expansion was not exact BF16"));}
      expanded[port]=take(hyle::mem::Buffer::create(memory.ref(),raw.size()*2,256));
      check(expanded[port].view().write(std::as_bytes(std::span(raw))));
    }
'''
assert base.count(needle)==1;base=base.replace(needle,replacement)
needle='std::fprintf(stderr,"# CUDA_ENCODED_COLD original=%d'
idx=base.index(needle)
base=base[:idx]+'''if(arm<4){const void *k=nullptr,*v=nullptr;if(!expanded_expected[0].empty()){k=take(c::cuda::pointer<std::uint16_t>(expanded[0].view()));v=take(c::cuda::pointer<std::uint16_t>(expanded[1].view()));}bindings[arm].configure(arm>=2,(arm&1)!=0,k,v);}
    std::fprintf(stderr,"# FACTOR_RESIDENCY arm=%s original_fp8_bytes=%zu extra_raw_bf16_bytes=%zu cold_exact_unscaled=1 snapshots_retained_through_drain=1\\n",arm_names[arm],data.packed[0].size()+data.packed[1].size(),expanded[0].size()+expanded[1].size());
    '''+base[idx:]
base=base.replace('check(queue.drain());queue={};host.reset();memory.reset();check(context.close());','check(queue.drain());expanded={};reference.reset();queue={};host.reset();memory.reset();check(context.close());')
needle='std::fprintf(stderr,"# CUDA_ENCODED_CORRECTNESS max_abs_error='
idx=base.index(needle)
base=base[:idx]+'''for(unsigned port=0;port<2;++port)if(!expanded_expected[port].empty()){
      std::vector<std::uint16_t> after(expanded_expected[port].size());check(expanded[port].view().read(std::as_writable_bytes(std::span(after))));
      if(after!=expanded_expected[port])fail(hyle::Status::Internal("cold BF16 snapshot changed"));
    }
    '''+base[idx:]
base+=r'''
using Clock=std::chrono::steady_clock;
double us(Clock::duration d){return std::chrono::duration<double,std::micro>(d).count();}
void measure(unsigned alloc,int q1,int q2,int k1,int k2,int dk,int dv,bool causal,int window,bool verify_only=false){
  const char *shape=verify_only?"tail":(window>=0?"window":(dk==256?"prefill":"holdout"));
  Data data(q1,q2,k1,k2,dk,dv,causal,window);std::array<std::unique_ptr<Harness>,6> h;
  for(unsigned pos=0;pos<6;++pos){const unsigned arm=alloc?5-pos:pos;const auto start=Clock::now();h[arm]=std::make_unique<Harness>(data,arm);std::printf("COLD alloc=%u shape=%s arm=%s create_us=%.9f\n",alloc,shape,arm_names[arm],us(Clock::now()-start));}
  const auto expected=data.oracle();std::array<std::vector<std::uint16_t>,6> values;
  for(unsigned replay=0;replay<4;++replay)for(unsigned arm=0;arm<6;++arm)values[arm]=h[arm]->verify(data,expected);
  for(unsigned arm=0;arm<6;++arm){double diff=0;for(std::size_t i=0;i<expected.size();++i)diff=std::max(diff,std::abs(double(decode(values[0][i]))-decode(values[arm][i])));if(diff>8e-3)fail(hyle::Status::Internal("factorial arms disagree"));std::printf("ORACLE alloc=%u shape=%s arm=%s diff_from_00=%.9g\n",alloc,shape,arm_names[arm],diff);}
  if(!verify_only){
    if(dk==256 && window==-1)for(unsigned arm=0;arm<4;++arm){const auto status=bindings[arm].dump(arm_names[arm]);if(status!=cudaSuccess)fail(hyle::Status::Internal("cold factor plan dump failed"));}
    constexpr unsigned pairs[8][2]{{0,4},{0,2},{1,3},{0,1},{2,3},{0,5},{4,5},{3,5}};
    for(unsigned pair_index=0;pair_index<8;++pair_index){
      const auto &pair=pairs[alloc?7-pair_index:pair_index];
      const std::string pair_name=std::string(arm_names[pair[0]])+"-"+arm_names[pair[1]];
      // Only this pair touches device cache after its own warmup. Other owners stay cold/live.
      for(unsigned i=0;i<64;++i)for(unsigned pos=0;pos<2;++pos){const unsigned arm=pair[(i+pos)&1];auto output=h[arm]->execute();output.reset();}
      diagnostic_trace=set("G04_TRACE");push(pair_name.c_str());push(shape);
      std::array<std::array<double,2>,512> raw{};std::array<std::array<unsigned,2>,512> positions{};
      for(unsigned group=0;group<8;++group)for(unsigned step=0;step<64;++step)for(unsigned pos=0;pos<2;++pos){
        const unsigned side=(pos+step+group)&1,arm=pair[side];positions[group*64+step][side]=pos;
        push(arm_names[arm]);const auto start=Clock::now();{auto output=h[arm]->execute();output.reset();}
        raw[group*64+step][side]=us(Clock::now()-start);pop();
      }
      pop();pop();diagnostic_trace=false;
      for(unsigned group=0;group<8;++group){std::array<double,2>sums{};
        for(unsigned step=0;step<64;++step)for(unsigned side=0;side<2;++side){const auto i=group*64+step;sums[side]+=raw[i][side];std::printf("EP pair=%s alloc=%u shape=%s group=%u step=%u arm=%s us=%.9f position=%u\n",pair_name.c_str(),alloc,shape,group,step,arm_names[pair[side]],raw[i][side],positions[i][side]);}
        for(unsigned side=0;side<2;++side)std::printf("BLOCK pair=%s alloc=%u shape=%s group=%u arm=%s count=64 mean_us=%.9f\n",pair_name.c_str(),alloc,shape,group,arm_names[pair[side]],sums[side]/64);
      }
    }
    for(unsigned arm=0;arm<6;++arm)h[arm]->verify(data,expected);
  }
  for(unsigned pos=0;pos<6;++pos){const unsigned arm=alloc?5-pos:pos;const auto start=Clock::now();h[arm].reset();std::printf("CLOSE alloc=%u shape=%s arm=%s close_us=%.9f\n",alloc,shape,arm_names[arm],us(Clock::now()-start));}
}
}
int main(){
  cpu_set_t cpus;CPU_ZERO(&cpus);CPU_SET(2,&cpus);if(sched_setaffinity(0,sizeof(cpus),&cpus)!=0)std::abort();
  std::printf("SCHEDULE arms=00,01,10,11,orig,peer allocation_orders=2 groups=8 steps=64 warmups=64 active_arms=2 pairs=00-orig,00-10,01-11,00-01,10-11,00-peer,orig-peer,11-peer execution=pair-only-interleaved-balanced-AB-BA primary=complete-episode-arithmetic-mean no_trimming=1 trace=%d\n",set("G04_TRACE"));
  for(unsigned alloc=0;alloc<2;++alloc){measure(alloc,1,17,1024,768,256,256,true,16);measure(alloc,64,128,1024,768,256,256,true,-1);measure(alloc,17,1,7,47,64,128,false,-1);}
  measure(0,64,128,1023,767,256,256,true,-1,true);
  std::printf("EXIT code=0\n");return 0;
}
'''
(P/'consumer.cc').write_text(base);(OUT/'consumer.cc').write_text(base)
shutil.copyfile(OLD/'cuda_encoded_page_reference.h',P/'cuda_encoded_page_reference.h')
print('consumer source generated',len(base))
