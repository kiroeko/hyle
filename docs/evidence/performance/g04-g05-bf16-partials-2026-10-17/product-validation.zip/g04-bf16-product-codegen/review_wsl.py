from pathlib import Path
import collections
import difflib
import hashlib
import json
import re
import subprocess
import time

ROOT=Path('/mnt/c/public/project-hyle/hyle')
OUT=ROOT/'.scratch/g04-bf16-product-codegen'
BUILD=Path('/root/hyle-scratch/compute-unified/l-cpu-cuda/selected-graph/static-sdk-build')
new=BUILD/'src/compute_provider_flashinfer/CMakeFiles/hyle_compute_provider_flashinfer.dir/native_cache.cu.o'
archive=BUILD/'bin/libhyle_compute_provider_flashinfer.a'
factor=Path('/root/hyle-scratch/compute-unified/g04-factorial-fulltu/native_cache_factor.o')
original=Path('/root/hyle-scratch/compute-unified/g04-load-ilp-2026-10-17/consumer/native_cache_control.o')
sha=lambda data:hashlib.sha256(data).hexdigest()
build=json.loads((ROOT/'.scratch/g04-bf16-product/build-commands.json').read_text())
assert any(x['stage']=='build' and x['returncode']==0 for x in build),'Product build not finished'
identities=json.loads((ROOT/'.scratch/g04-bf16-product/built-identity.json').read_text())
assert sha(archive.read_bytes())==identities[str(archive)]
assert sha(subprocess.check_output(['ar','p',str(archive),'native_cache.cu.o']))==sha(new.read_bytes())
baseline_identity=ROOT/'.scratch/g04-factorial-fulltu/codegen/comparison.json'
old_comparison=json.loads(baseline_identity.read_text())
assert old_comparison['original']['object']==str(original)
assert sha(original.read_bytes())==old_comparison['original']['object_sha256']=='30cef3debb1241ebb9526361f2d66f89d30c5b0dc9c6ac241001d0ad7caee476'
assert sha(factor.read_bytes())=='db05922b54cad32c2760ba4703cbe6b439f2f6eaf2ed70a7915c38af19e19c3d'
trait='MaskModeE1ELj64ELj1ELj1ELj16ELj16ELj4ELj1E'
def symbols(path,include_bf16):
    text=subprocess.check_output(['nm','--defined-only','--format=posix',str(path)],text=True)
    candidates=[line.split()[0] for line in text.splitlines() if len(line.split())>=2 and line.split()[1]=='t']
    def exactly(predicate):
        matched=[name for name in candidates if not name.endswith('.cold') and predicate(name)]
        assert len(matched)==1,(str(path),matched)
        return matched[0]
    result={
      'f32-prefill':exactly(lambda x:x.startswith('_ZN10flashinferL34BatchPrefillWithPagedKVCacheKernel') and trait in x and '13__nv_bfloat1613__nv_fp8_e4m3ffi' in x and 'MergeParams' in x and 'Lj256E' in x),
      'f32-merge':exactly(lambda x:x.startswith('_ZN10flashinferL41PersistentVariableLengthMergeStatesKernel') and 'ILj8ELj32ELj4ELj2Ef13__nv_bfloat16iLb1E' in x)}
    if include_bf16:
        result['bf16-prefill']=exactly(lambda x:x.startswith('_ZN10flashinferL34BatchPrefillWithPagedKVCacheKernel') and trait in x and '13__nv_bfloat1613__nv_fp8_e4m3S4_fi' in x and 'MergeParams' in x and 'Lj256E' in x)
        result['bf16-merge']=exactly(lambda x:x.startswith('_ZN10flashinferL41PersistentVariableLengthMergeStatesKernel') and 'ILj8ELj32ELj4ELj4E13__nv_bfloat16' in x and 'iLb1E' in x)
    return {key:re.sub(r'^_ZN10flashinferL(\d+)',r'_ZN10flashinfer\1',value) for key,value in result.items()}

def dump(label,path,include_bf16):
    names=symbols(path,include_bf16)
    result={'object':str(path),'object_sha256':sha(path.read_bytes()),'symbols':names,'commands':[],'kernels':{}}
    for option,name in [('--dump-sass','sass'),('--dump-resource-usage','resources')]:
        command=['/usr/local/cuda-13.3/bin/cuobjdump','--gpu-architecture','sm_89',option,'--function',','.join(names.values()),str(path)]
        t=time.monotonic();p=subprocess.run(command,capture_output=True,text=True,timeout=120)
        (OUT/f'{label}-{name}.txt').write_text(p.stdout);(OUT/f'{label}-{name}-stderr.txt').write_text(p.stderr)
        assert p.returncode==0,(command,p.stderr)
        result['commands'].append({'argv':command,'exit':p.returncode,'seconds':time.monotonic()-t,'stdout_sha256':sha(p.stdout.encode()),'stderr':p.stderr})
    sass=(OUT/f'{label}-sass.txt').read_text();resources=(OUT/f'{label}-resources.txt').read_text()
    assert 'arch = sm_89' in sass and 'arch = sm_80' not in sass
    chunks={piece.splitlines()[0]:piece for piece in re.split(r'\s*Function : ',sass)[1:]}
    assert set(names.values())==set(chunks)
    for key,symbol in names.items():
        lines=chunks[symbol].splitlines();instructions=[];codewords=[]
        for index,line in enumerate(lines):
            m=re.search(r'/\*[0-9a-fA-F]+\*/\s+(.+?;)',line)
            if not m:continue
            instructions.append(m[1].strip())
            low=re.search(r'/\* (0x[0-9a-fA-F]{16}) \*/',line)
            high=re.search(r'/\* (0x[0-9a-fA-F]{16}) \*/',lines[index+1])
            assert low and high,(line,lines[index+1])
            codewords.append(low[1]+':'+high[1])
        assert len(instructions)>500,(label,key,len(instructions))
        text='\n'.join(instructions)+'\n';bits='\n'.join(codewords)+'\n'
        (OUT/f'{label}-{key}-instructions.txt').write_text(text)
        (OUT/f'{label}-{key}-codewords.txt').write_text(bits)
        match=re.search(r'Function\s+'+re.escape(symbol)+r':\s*\n([^\n]+)',resources)
        assert match,symbol
        result['kernels'][key]={'device_symbol':symbol,'instruction_count':len(instructions),'normalized_sha256':sha(text.encode()),
             'codewords_sha256':sha(bits.encode()),'resource':match[1].strip(),
             'ops':dict(collections.Counter(re.sub(r'^@!?P\d+\s+','',line).split()[0] for line in instructions))}
    return result

record={'state':'READ_ONLY_SM89_CODEGEN_REVIEW','gpu_executed':False,'recompiled':False,
        'product_archive':str(archive),'product_archive_sha256':sha(archive.read_bytes()),
        'archive_native_cache_member_equals_object':True,'artifacts':{},'comparisons':[],
        'baseline_identity_file':str(baseline_identity),'baseline_identity_sha256':sha(baseline_identity.read_bytes()),
        'instruction_count_note':'This parser includes always-false @!PT/@!UPT padding instructions. Earlier static-cost parser excluded seven such rows, so 1809 there vs 1816 here is a parsing definition correction, not a new performance delta.'}
for label,path,has_bf16 in [('original',original,False),('fulltu-factor',factor,True),('product',new,True)]:
    record['artifacts'][label]=dump(label,path,has_bf16)
for kind,baseline in [('f32-prefill','original'),('f32-merge','original'),('f32-prefill','fulltu-factor'),('f32-merge','fulltu-factor'),('bf16-prefill','fulltu-factor'),('bf16-merge','fulltu-factor')]:
    a=record['artifacts'][baseline]['kernels'][kind];b=record['artifacts']['product']['kernels'][kind]
    row={'kind':kind,'baseline':baseline,'instructions_equal':a['normalized_sha256']==b['normalized_sha256'],
         'encoded_schedule_words_equal':a['codewords_sha256']==b['codewords_sha256'],
         'resource_equal':a['resource']==b['resource'],'baseline':baseline,'baseline_resource':a['resource'],'product_resource':b['resource']}
    before=(OUT/f'{baseline}-{kind}-instructions.txt').read_text().splitlines(True)
    after=(OUT/f'product-{kind}-instructions.txt').read_text().splitlines(True)
    (OUT/f'{baseline}-vs-product-{kind}.diff').write_text(''.join(difflib.unified_diff(before,after,fromfile=baseline,tofile='product')))
    before_bits=(OUT/f'{baseline}-{kind}-codewords.txt').read_text().splitlines(True)
    after_bits=(OUT/f'product-{kind}-codewords.txt').read_text().splitlines(True)
    (OUT/f'{baseline}-vs-product-{kind}-controlwords.diff').write_text(''.join(difflib.unified_diff(before_bits,after_bits,fromfile=baseline,tofile='product')))
    row['different_codeword_rows']=sum(a!=b for a,b in zip(before_bits,after_bits))+abs(len(before_bits)-len(after_bits))
    record['comparisons'].append(row)
record['limits']=['Read-only generated code comparison only. No new runtime/math/memory-sanitizer verdict.',
                  'Normalized instruction and encoded control-word identity are separate; any difference is retained, not explained away.',
                  'Final actual plan/workspace offsets and BF16 precision behavior are verified by product consumers, not this disassembly.']
(OUT/'review.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record['comparisons'],indent=2))
