from pathlib import Path
import hashlib,json
repo=Path('/mnt/c/public/project-hyle/hyle')
out=repo/'.scratch/g04-bf16-product-precision'
run=out/'run-ordinary-1';identity=json.loads((run/'identity.json').read_text())
new=(out/'consumer.cc').read_bytes()
replacement=b'''      // The lease covers capacity rows, including three inactive rows. The\r
      // memory API reads the whole view; only the logical prefix has outputs.\r
      all[arm].resize(std::size_t(data.capacity.max_query_rows)*8*256);\r
      check(output.view()->read(std::as_writable_bytes(std::span(all[arm]))));\r
      all[arm].resize(expected.size());'''
previous=b'      all[arm].resize(expected.size());check(output.view()->read(std::as_writable_bytes(std::span(all[arm]))));'
assert new.count(replacement)==1
old=new.replace(replacement,previous)
assert hashlib.sha256(old).hexdigest()==identity['source_sha256']
(run/'consumer.cc').write_bytes(old)
binary=Path(identity['argv'][0]).read_bytes()
assert hashlib.sha256(binary).hexdigest()==identity['binary_sha256']
(run/'consumer').write_bytes(binary)
metadata=json.loads((out/'source-identity.json').read_text())
metadata['supersedes_read_size_error_source_sha256']=metadata['source_sha256']
metadata['source_sha256']=hashlib.sha256(new).hexdigest()
metadata['read_size_fix']='Read full max_query_rows view, then resize to logical expected rows before final/back/all-word analysis.'
(out/'source-identity.json').write_text(json.dumps(metadata,indent=2)+'\n')
print(json.dumps({'run1_original_source_and_binary_preserved':True,'new_source_sha256':metadata['source_sha256']}))
