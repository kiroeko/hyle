#if defined(_MSC_VER)
#define _CRT_SECURE_NO_WARNINGS
#endif
#include "hyle/compute/paged_arena.h"
#include "hyle/compute/backends/cuda.h"
#include "hyle/compute/providers/flashinfer.h"

#include "hyle/compute/batch_execution.h"
#include "hyle/simd/dtype.h"
#include <cstring>
#include <cuda_runtime_api.h>
#include <sched.h>
#include <array>
#include <algorithm>
#include <bit>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <chrono>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <memory>
#include <string>
#include <vector>
#include <nvtx3/nvToolsExt.h>

namespace {
#ifndef HYLE_RESIDENT_PLACEMENT
#define HYLE_RESIDENT_PLACEMENT 0
#endif
namespace c=hyle::compute;
bool diagnostic_trace=false;
void push(const char *s){if(diagnostic_trace)nvtxRangePushA(s);}
void pop(){if(diagnostic_trace)nvtxRangePop();}
[[noreturn]] void fail(hyle::Status status){std::fprintf(stderr,"CUDA encoded: %.*s\n",int(status.message().size()),status.message().data());std::exit(2);}
void check(hyle::Status status){if(!status.ok())fail(status);}
template<class T>T take(hyle::Result<T> value){if(!value)fail(value.error());return std::move(*value);}
[[maybe_unused]] bool set(const char *name){const auto *p=std::getenv(name);return p&&*p;}
float decode(std::uint16_t x){return std::bit_cast<float>(std::uint32_t(x)<<16);}
std::uint16_t encode(float x){return std::uint16_t(std::bit_cast<std::uint32_t>(x)>>16);}
double fp8(std::uint8_t code){const unsigned e=(code&127)>>3,m=code&7;
  const double value=e?std::ldexp(1.+double(m)/8.,int(e)-7):std::ldexp(double(m)/8.,-6);
  return code&128?-value:value;
}
struct Data {
  c::BatchCapacity capacity;
  std::array<std::int32_t,3> qp,kp;
  std::vector<std::int32_t> ids;std::array<std::int32_t,2> tails;
  std::vector<std::uint16_t> query;
  std::array<std::vector<std::byte>,2> packed;
  std::array<std::vector<float>,2> decoded;
  float scale;bool causal;std::int32_t window;
  Data(int q1,int q2,int k1,int k2,int dk,int dv,bool masked,int left):
    capacity{.storage=c::BatchStorage::kPaged,.query_type=c::DataType::kBFloat16,
      .output_type=c::DataType::kBFloat16,.key_storage=c::CacheStorage::float8(.5F).value(),
      .value_storage=c::CacheStorage::float8(2.F).value(),.max_requests=2,
      .max_query_rows=unsigned(q1+q2+3),.max_kv_rows=unsigned(k1+k2+13),
      .max_pages=unsigned((k1+15)/16+(k2+15)/16+2),.max_page_refs=unsigned((k1+15)/16+(k2+15)/16),
      .query_heads=8,.kv_heads=2,.qk_head_dim=unsigned(dk),.value_head_dim=unsigned(dv),.page_size=16},
    qp{0,q1,q1+q2},kp{0,(k1+15)/16,(k1+15)/16+(k2+15)/16},
    scale(1.F/std::sqrt(float(dk))),causal(masked),window(left){
    tails={(k1-1)%16+1,(k2-1)%16+1};
    for(unsigned i=0;i<capacity.max_page_refs;++i)ids.push_back(static_cast<std::int32_t>(capacity.max_pages-1-i));
    ids[static_cast<unsigned>(kp[1])]=ids[0];
    query.resize(std::size_t(capacity.max_query_rows)*8*dk);
    for(std::size_t i=0;i<query.size();++i)query[i]=encode(.125F+float((i/dk)%8%3)*.015625F);
    for(unsigned port=0;port<2;++port){
      const auto depth=port?dv:dk;
      auto &bytes=packed[port];auto &values=decoded[port];
      values.resize(std::size_t(capacity.max_pages)*16*2*depth);
      bytes.resize(values.size());
      // Independent finite FP8 fixture; the oracle decodes these actual bytes.
      for(std::size_t i=0;i<bytes.size();++i){
        const auto row=i/(2*depth),head=(i/depth)%2;
        constexpr std::uint8_t key_codes[]{0,56,64,68,72},value_codes[]{16,24,28,32,34};
        const auto code=(port?value_codes:key_codes)[(row+head)%5];
        bytes[i]=std::byte(code);values[i]=float(fp8(code)*(port?2.:.5));
      }
      for(unsigned page=0;page<capacity.max_pages;++page){
        unsigned valid=0;
        for(unsigned r=0;r<2;++r)for(auto ref=kp[r];ref<kp[r+1];++ref)
          if(ids[unsigned(ref)]==int(page))valid=std::max(valid,ref+1==kp[r+1]?unsigned(tails[r]):16u);
        for(auto i=std::size_t(page*16+valid)*2*depth;i<std::size_t((page+1)*16)*2*depth;++i){
          bytes[i]=std::byte(0x78);values[i]=float(fp8(0x78)*(port?2.:.5));
        }
      }
    }
  }
  std::size_t row_bytes(unsigned port)const{const auto storage=port?capacity.value_storage:capacity.key_storage;return std::size_t(2)*(port?capacity.value_head_dim:capacity.qk_head_dim)*(storage.data_type()==c::DataType::kFloat8E4M3FN?1u:2u);}
  std::vector<double> oracle()const{
    const auto dk=capacity.qk_head_dim,dv=capacity.value_head_dim;
    std::vector<double> output(std::size_t(qp[2])*8*dv),weights;double uniform_difference=0;
    for(unsigned r=0;r<2;++r){const int nq=qp[r+1]-qp[r],nk=(kp[r+1]-kp[r]-1)*16+tails[r];weights.resize(nk);
      for(int row=0;row<nq;++row)for(unsigned h=0;h<8;++h){double sum=0;
        const auto position=nk-nq+row;
        for(int j=0;j<nk;++j){
          if(causal&&(j>position||(window>=0&&j<std::max(0,position-window)))){weights[j]=0;continue;}
          double dot=0;for(unsigned d=0;d<dk;++d)dot+=double(decode(query[(std::size_t(qp[r]+row)*8+h)*dk+d]))*
              decoded[0][((std::size_t(ids[static_cast<unsigned>(kp[r]+j/16)])*16+j%16)*2+h/4)*dk+d];
          weights[j]=std::exp(dot*scale);sum+=weights[j];
        }
        for(unsigned d=0;d<dv;++d)for(int j=0;j<nk;++j)output[(std::size_t(qp[r]+row)*8+h)*dv+d]+=
            weights[j]/sum*decoded[1][((std::size_t(ids[static_cast<unsigned>(kp[r]+j/16)])*16+j%16)*2+h/4)*dv+d];
        double uniform=0;unsigned eligible=0;
        for(int j=0;j<nk;++j)if(weights[j]>0){++eligible;
          uniform+=decoded[1][((std::size_t(ids[unsigned(kp[r]+j/16)])*16+j%16)*2+h/4)*dv];}
        uniform_difference=std::max(uniform_difference,std::abs(
            output[(std::size_t(qp[r]+row)*8+h)*dv]-uniform/eligible));
      }
    }
    if(uniform_difference<=.01)fail(hyle::Status::Internal("FP8 oracle fixture cannot distinguish missing QK loads"));
    std::fprintf(stderr,"# CUDA_ENCODED_ORACLE uniform_difference=%.9g\n",uniform_difference);
    return output;
  }
};
struct Harness {
  bool captured=false;std::size_t float_cap=0;
  c::Context context;c::cuda::MemoryResource memory,host;c::Queue queue;c::BatchSchema schema;c::BatchLayoutVersion layout;
  c::BatchProgram program;std::array<c::BatchInvocation,2> slots;c::LeasePool pool;
  c::PagedArena keys,values;c::PagedArenaRead key_frame,value_frame;
  std::vector<c::ReadLease> key_pages,value_pages;std::vector<unsigned> physical_ids;c::ReadLease query;std::size_t next=0;
  Harness(const Data &data,bool original,bool replay):captured(replay){
    const bool prefill=data.capacity.qk_head_dim==256 && data.window==-1 && data.causal;
    float_cap=std::size_t((original || !prefill)?22u:11u)<<20;
    context=take(c::Context::create(take(c::cuda::device(0)),c::flashinfer::provider()));
    const auto env=take(c::cuda::environment(context));
    if(env.sm_major!=8||env.sm_minor!=9)fail(hyle::Status::Unimplemented("finite actual SM89 profile"));
    std::fprintf(stderr,"# CUDA_ENCODED_ENV device=%s sm=%d%d driver=%s runtime=%d toolkit=%d original=%d\n",
        env.device_name.data(),env.sm_major,env.sm_minor,env.driver_release.data(),env.runtime_version,env.build_toolkit_version,original);
    memory=take(c::cuda::MemoryResource::create(context,c::cuda::MemoryKind::kDevice));
    host=take(c::cuda::MemoryResource::create(context,c::cuda::MemoryKind::kPinnedHost));
    queue=take(context.create_queue());
    schema=take(c::BatchSchema::create(data.capacity));layout=take(schema.version({data.qp,data.kp,data.ids,data.tails}));
    const auto key_bytes=16*data.row_bytes(0),value_bytes=16*data.row_bytes(1);
    keys=take(c::PagedArena::create(schema,c::BatchCacheRole::kKey,memory.ref(),{.max_backing_bytes=key_bytes*data.capacity.max_pages+1}));
    values=take(c::PagedArena::create(schema,c::BatchCacheRole::kValue,memory.ref(),{.max_backing_bytes=value_bytes*data.capacity.max_pages+1}));
    for(unsigned page=0;page<data.capacity.max_pages;++page)if(std::find(data.ids.begin(),data.ids.end(),static_cast<std::int32_t>(page))!=data.ids.end()){
      auto kw=take(keys.acquire(page)),vw=take(values.acquire(page));
      check(kw.lease().view()->write(std::span(data.packed[0]).subspan(page*key_bytes,key_bytes)));
      check(vw.lease().view()->write(std::span(data.packed[1]).subspan(page*value_bytes,value_bytes)));
      physical_ids.push_back(page);key_pages.push_back(take(kw.publish(16)));value_pages.push_back(take(vw.publish(16)));
    }
    key_frame=take(keys.read(layout,key_pages));value_frame=take(values.read(layout,value_pages));
    program=take(c::BatchProgram::prepare(context,schema,{.resource=memory.ref(),.host_workspace=host.ref(),
        .max_float_workspace_bytes=float_cap,.max_int_workspace_bytes=4096,.scale=data.scale,.causal=data.causal,.window_left=data.window,.allow_bf16_partials=!original}));
    for(auto &slot:slots){slot=take(c::BatchInvocation::create(program,queue));auto prepared=take(slot.prepare_batch(layout));}
    pool=take(c::LeasePool::create(memory.ref(),data.query.size()*2+2048));
    auto writer=take(pool.allocate(data.query.size()*2));check(writer.view()->write(std::as_bytes(std::span(data.query))));query=take(writer.publish());
    if(captured)for(auto &slot:slots){auto prepared=take(slot.update_batch(layout));check(prepared.prepare_replay(query,key_frame,value_frame));if(!slot.report().capture_compatible)fail(hyle::Status::Internal("cold public replay did not record"));}
    const auto stats=take(memory.ref().resource().stats());
    std::printf("PRODUCT_MEMORY default_option=%d captured=%d float_cap=%zu required_workspace=%zu bf16_partials=%d resource_used=%zu resource_reserved=%zu slots=2\n",original,captured,float_cap,slots[0].report().float_workspace_bytes,slots[0].report().bf16_partials,stats.used_bytes,stats.reserved_bytes);

    if(slots[0].report().bf16_partials!=(!original && prefill))fail(hyle::Status::Internal("actual product partial policy mismatch"));
    std::fprintf(stderr,"# CUDA_ENCODED_COLD original=%d known_float_bytes=%zu known_int_bytes=%zu tile=%u split=%d private_pool_upper=UNKNOWN requests=2 immutable_history=1\n",original,slots[0].report().float_workspace_bytes,slots[0].report().int_workspace_bytes,slots[0].report().cta_tile_q,slots[0].report().split_kv);
  }
  ~Harness(){const auto start=std::chrono::steady_clock::now();
    for(auto &slot:slots){check(slot.close());slot={};}
    program={};query.reset();pool={};key_frame={};value_frame={};
    key_pages.clear();value_pages.clear();keys={};values={};
    check(queue.drain());queue={};host.reset();memory.reset();check(context.close());
    std::fprintf(stderr,"# CUDA_ENCODED_TEARDOWN seconds=%.9f\n",
        std::chrono::duration<double>(std::chrono::steady_clock::now()-start).count());
  }
  c::ReadLease execute(){auto &slot=slots[next++%slots.size()];
    push("update");auto prepared=take(slot.update_batch(layout));pop();
    if(captured && !slot.report().capture_compatible)fail(hyle::Status::Internal("warm capture was lost"));
    if(!slot.report().reused_native_plan)fail(hyle::Status::Internal("paged warm topology rebuilt"));
    push("admit_submit");auto completion=take(prepared.run(query,key_frame,value_frame));pop();
    push("checked_wait");check(completion.wait());pop();
    push("output_acquire");auto output=take(slot.output());pop();return output;}
  std::vector<std::uint16_t> verify(const Data &data,const std::vector<double> &expected){auto output=execute();std::vector<std::uint16_t> actual(std::size_t(data.capacity.max_query_rows)*8*data.capacity.value_head_dim);check(output.view()->read(std::as_writable_bytes(std::span(actual))));
    double worst=0;for(std::size_t i=0;i<expected.size();++i){if(!std::isfinite(decode(actual[i])))fail(hyle::Status::Internal("paged nonfinite output"));worst=std::max(worst,std::abs(double(decode(actual[i]))-expected[i]));}
    if(worst>8e-3)fail(hyle::Status::Internal("paged independent double oracle exceeded 8e-3"));
    std::vector<std::uint16_t> query_after(data.query.size());
    check(query.view()->read(std::as_writable_bytes(std::span(query_after))));
    if(query_after!=data.query)fail(hyle::Status::Internal("paged readonly Q changed"));
    for(unsigned port=1;port<3;++port)for(unsigned index=0;index<key_pages.size();++index){const auto &lease=port==1?key_pages[index]:value_pages[index];auto view=take(lease.view());
      std::vector<std::byte> after(view.size());check(view.read(after));
      const auto first=data.packed[port-1].begin()+std::size_t(physical_ids[index])*16*data.row_bytes(port-1);
      if(!std::equal(after.begin(),after.end(),first))fail(hyle::Status::Internal("paged readonly KV changed"));
    }
    std::fprintf(stderr,"# CUDA_ENCODED_CORRECTNESS max_abs_error=%.9g elements=%zu\n",worst,expected.size());return actual;
  }
};


Data plain_bf16_peer(const Data &source){
  Data peer=source;
  for(unsigned port=0;port<2;++port){
    const auto scale=port?source.capacity.value_storage.scale():source.capacity.key_storage.scale();
    std::vector<std::byte> bytes(source.packed[port].size()*2);
    for(std::size_t i=0;i<source.packed[port].size();++i){
      const auto value=float(fp8(std::to_integer<std::uint8_t>(source.packed[port][i]))*scale);
      const auto word=encode(value);
      if(decode(word)!=value)fail(hyle::Status::Internal("plain BF16 peer cold expansion changed an input value"));
      std::memcpy(bytes.data()+i*2,&word,2);
    }
    peer.packed[port]=std::move(bytes);
  }
  peer.capacity.key_storage=take(c::CacheStorage::plain(c::DataType::kBFloat16));
  peer.capacity.value_storage=take(c::CacheStorage::plain(c::DataType::kBFloat16));
  return peer;
}

std::uint16_t round_word(double value){auto bits=std::bit_cast<std::uint32_t>(float(value));bits+=0x7fff+((bits>>16)&1);return std::uint16_t(bits>>16);}
void readonly_inputs(const Data &data,Harness &owner){
  auto qview=take(owner.query.view());std::vector<std::uint16_t> q(data.query.size());
  check(qview.read(std::as_writable_bytes(std::span(q))));
  if(q!=data.query)fail(hyle::Status::Internal("new product precision readonly Q changed"));
  for(unsigned port=0;port<2;++port)for(unsigned index=0;index<owner.key_pages.size();++index){
    auto view=take((port?owner.value_pages[index]:owner.key_pages[index]).view());std::vector<std::byte> bytes(view.size());check(view.read(bytes));
    const auto first=data.packed[port].begin()+std::size_t(owner.physical_ids[index])*16*data.row_bytes(port);
    if(!std::equal(bytes.begin(),bytes.end(),first))fail(hyle::Status::Internal("new product precision readonly KV changed"));
  }
}
void precision_case(const char *name,std::uint8_t positive,std::uint8_t perturbed,bool capture){
  Data data(64,128,8192,8192,256,256,true,-1);
  std::fill(data.query.begin(),data.query.end(),std::uint16_t{0});
  for(unsigned r=0;r<2;++r)for(unsigned row=0;row<8192;++row){
    const auto physical=unsigned(data.ids[unsigned(data.kp[r])+row/16])*16+row%16;
    const auto code=std::uint8_t(row<4096?(row%64==0?perturbed:positive):(positive|128));
    for(unsigned head=0;head<2;++head)for(unsigned d=0;d<256;++d){const auto at=(std::size_t(physical)*2+head)*256+d;
      data.packed[0][at]=std::byte{0};data.decoded[0][at]=0;
      data.packed[1][at]=std::byte{code};data.decoded[1][at]=float(fp8(code)*2.);
    }
  }
  auto peer=plain_bf16_peer(data);
  std::vector<double> expected(std::size_t(data.qp[2])*8*256);
  for(unsigned r=0;r<2;++r){const auto nq=unsigned(data.qp[r+1]-data.qp[r]);std::vector<double> prefix(8193);
    for(unsigned row=0;row<8192;++row){const auto physical=unsigned(data.ids[unsigned(data.kp[r])+row/16])*16+row%16;
      prefix[row+1]=prefix[row]+data.decoded[1][std::size_t(physical)*2*256];}
    for(unsigned q=0;q<nq;++q){const auto count=8192-nq+q+1;const auto mean=prefix[count]/count;
      for(unsigned head=0;head<8;++head)for(unsigned d=0;d<256;++d)expected[((std::size_t(data.qp[r])+q)*8+head)*256+d]=mean;
    }
  }
  const std::array<const char*,3> names{"fp8_f32","fp8_bf16partial","plain_bf16_same_source_peer"};
  std::array<std::unique_ptr<Harness>,3> owners;
  owners[0]=std::make_unique<Harness>(data,true,capture);
  owners[1]=std::make_unique<Harness>(data,false,capture);
  owners[2]=std::make_unique<Harness>(peer,true,capture);
  for(unsigned episode=0;episode<2;++episode){std::array<std::vector<std::uint16_t>,3> all;
    for(unsigned arm=0;arm<3;++arm){auto output=owners[arm]->execute();
      const auto report=owners[arm]->slots[episode].report();
      if(report.cta_tile_q!=64 || !report.split_kv || report.bf16_partials!=(arm==1))fail(hyle::Status::Internal("product precision did not select its declared pipeline"));
      // The lease covers capacity rows, including three inactive rows. The
      // memory API reads the whole view; only the logical prefix has outputs.
      all[arm].resize(std::size_t(data.capacity.max_query_rows)*8*256);
      check(output.view()->read(std::as_writable_bytes(std::span(all[arm]))));
      all[arm].resize(expected.size());
      double maximum=0,sum=0,relative=0,rounded_error=0;std::size_t differences=0;
      for(std::size_t i=0;i<expected.size();++i){const auto value=double(decode(all[arm][i]));
        if(!std::isfinite(value))fail(hyle::Status::Internal("product precision output was nonfinite"));
        const auto error=std::abs(value-expected[i]);maximum=std::max(maximum,error);sum+=error;
        if(std::abs(expected[i])>1e-12)relative=std::max(relative,error/std::abs(expected[i]));
        rounded_error=std::max(rounded_error,std::abs(value-double(decode(round_word(expected[i])))));differences+=all[arm][i]!=round_word(expected[i]);
      }
      if(arm==0 && differences)fail(hyle::Status::Internal("new product default F32 lost the retained RNE residual"));
      std::printf("NEW_PRECISION case=%s capture=%u slot=%u arm=%s elements=%zu max_abs=%.12g mean_abs=%.12g max_relative=%.12g max_vs_RNE=%.12g different_RNE_words=%zu final_expected=%.12g final_actual=%.12g workspace=%zu cap=%zu actual_optin=%d\n",name,unsigned(capture),episode,names[arm],expected.size(),maximum,sum/expected.size(),relative,rounded_error,differences,expected.back(),double(decode(all[arm].back())),report.float_workspace_bytes,owners[arm]->float_cap,report.bf16_partials);
    }
    std::size_t different=0;double maximum=0;
    for(std::size_t i=0;i<expected.size();++i){different+=all[1][i]!=all[2][i];maximum=std::max(maximum,std::abs(double(decode(all[1][i]))-decode(all[2][i])));}
    if(different)fail(hyle::Status::Internal("new product BF16 partial output differs from same-source BF16 KV peer"));
    const auto known=positive==0x70?.08251953125:.000644683837890625;
    if(double(decode(all[1].back()))!=known)fail(hyle::Status::Internal("new product did not reproduce retained peer final residual"));
    std::printf("NEW_PRECISION_PEER case=%s capture=%u slot=%u compared_words=%zu different_words=%zu max_abs_difference=%.12g known_retained_peer_final=%.12g\n",name,unsigned(capture),episode,expected.size(),different,maximum,known);
  }
  for(unsigned arm=0;arm<3;++arm)readonly_inputs(arm==2?peer:data,*owners[arm]);
  for(auto &owner:owners)owner.reset();
  std::printf("NEW_PRECISION_CASE_DONE case=%s capture=%u Q_KV_readonly=1 both_slots=1 checked_drain=1\n",name,unsigned(capture));
}
}
int main(){
  std::printf("SCOPE new_product_public_ABI=1 peer=same_source_FlashInfer_plain_BF16_native_batch not_external_engine=1 timing=0 model_quality=NOT_MEASURED\n");
  for(unsigned capture=0;capture<2;++capture){precision_case("cancellation-large",0x70,0x71,capture!=0);precision_case("cancellation-unit",0x38,0x39,capture!=0);}
  std::printf("NEW_PRECISION_DONE cases=2 capture_modes=2 slots=2 peer_all_words_equal=1 default_all_words_RNE=1 EXIT=0\n");return 0;
}
