from pathlib import Path
import hashlib
import json
import os
import subprocess
import time

OUT = Path('/mnt/c/public/project-hyle/hyle/.scratch/g04-bf16-product-peer-trace')
WORK = Path('/root/hyle-scratch/compute-unified/g04-bf16-product-peer-trace')

def main():
    dest = OUT / 'run-trace-1'
    dest.mkdir(exist_ok=False)
    native_dest = WORK / 'run-trace-1'
    native_dest.mkdir(exist_ok=False)
    binary = WORK / 'consumer'
    argv = ['nsys', 'profile', '--trace=cuda,nvtx', '--sample=none', '--cpuctxsw=none',
            '--cuda-graph-trace=node', '--cuda-trace-all-apis=true', '--force-overwrite=false',
            '-o', str(native_dest / 'profile'), str(binary)]
    env = os.environ.copy()
    env['G04_TRACE'] = '1'
    identity = {'argv': argv, 'G04_TRACE': '1', 'source_sha256': hashlib.sha256((OUT / 'consumer.cc').read_bytes()).hexdigest(),
                'binary_sha256': hashlib.sha256(binary.read_bytes()).hexdigest(),
                'scope': 'small diagnostic trace; host wall times are instrumented, not ordinary primary results',
                'started_unix': time.time()}
    (dest / 'identity.json').write_text(json.dumps(identity, indent=2) + '\n')
    print(json.dumps(identity), flush=True)
    with (dest / 'stdout.log').open('w') as stdout, (dest / 'stderr.log').open('w') as stderr:
        result = subprocess.run(argv, env=env, stdout=stdout, stderr=stderr)
    identity.update({'returncode': result.returncode, 'elapsed_s': time.time() - identity['started_unix']})
    (dest / 'result.json').write_text(json.dumps(identity, indent=2) + '\n')
    print(json.dumps({'profile_returncode': result.returncode, 'elapsed_s': identity['elapsed_s']}), flush=True)
    if result.returncode:
        raise SystemExit(result.returncode)
    export = ['nsys', 'export', '--type=sqlite', '--force-overwrite=false', '--output', str(native_dest / 'profile.sqlite'), str(native_dest / 'profile.nsys-rep')]
    start = time.time()
    with (dest / 'export.log').open('w') as log:
        r = subprocess.run(export, stdout=log, stderr=subprocess.STDOUT)
    (dest / 'export.json').write_text(json.dumps({'argv': export, 'returncode': r.returncode, 'elapsed_s': time.time() - start}, indent=2) + '\n')
    print(json.dumps({'export_returncode': r.returncode, 'elapsed_s': time.time() - start}), flush=True)
    raise SystemExit(r.returncode)

if __name__ == '__main__':
    main()
