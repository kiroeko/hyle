from pathlib import Path
import json,subprocess,time,hashlib,sys
repo=Path('/mnt/c/public/project-hyle/hyle');out=repo/'.scratch/g04-bf16-product-bench'
work=Path('/root/hyle-scratch/compute-unified/g04-bf16-product-bench')
product=Path('/root/hyle-scratch/compute-unified/g04-bf16-product')
commands=json.loads((repo/'.scratch/g04-bf16-product/consumer-commands.json').read_text())
for stage in commands:
  commands[stage]=[str(work/'consumer.cc') if arg.endswith('/tests/compute_batch/g04_bf16_partials_consumer.cc') else str(work/'consumer.o') if arg==str(product/'consumer.o') else str(work/'product_bench') if arg==str(product/'public_consumer') else '-Wl,-Map='+str(work/'link.map') if arg=='-Wl,-Map='+str(product/'link.map') else arg for arg in commands[stage]]
(work/'commands.json').write_text(json.dumps(commands,indent=2)+'\n');(out/'commands.json').write_bytes((work/'commands.json').read_bytes())
result={}
for stage in (['compile'] if '--compile-only' in sys.argv else ['link']):
  start=time.monotonic()
  with (work/(stage+'.log')).open('w') as f:p=subprocess.run(commands[stage],stdout=f,stderr=subprocess.STDOUT)
  result[stage]={'exit':p.returncode,'seconds':time.monotonic()-start}
  if p.returncode:print((work/(stage+'.log')).read_text()[-6000:])
if (work/'product_bench').exists():result['binary']={'path':str(work/'product_bench'),'sha256':hashlib.sha256((work/'product_bench').read_bytes()).hexdigest()}
(work/('build-compile.json' if '--compile-only' in sys.argv else 'build-link.json')).write_text(json.dumps(result,indent=2)+'\n')
for name in ['compile.log','link.log','build-compile.json','build-link.json','link.map']:
  if (work/name).exists():(out/name).write_bytes((work/name).read_bytes())
print(json.dumps(result,indent=2))
