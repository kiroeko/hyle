from pathlib import Path
import json,hashlib
repo=Path('/mnt/c/public/project-hyle/hyle');out=repo/'.scratch/g04-bf16-product-bench'
work=Path('/root/hyle-scratch/compute-unified/g04-bf16-product-bench');work.mkdir(exist_ok=True)
source=(repo/'.scratch/g04-same-process-ilp/cuda_encoded_page_bench.cc').read_text()
source=source.replace('#include "cuda_encoded_page_reference.h"','#include "hyle/compute/paged_arena.h"')
start=source.index('namespace hyle::compute::flashinfer {');stop=source.index('namespace {',start)
source=source[:start]+source[stop:]
source=source.replace('struct Harness {','struct Harness {\n  bool captured=false;std::size_t float_cap=0;')
source=source.replace('Harness(const Data &data,bool original){','Harness(const Data &data,bool original,bool replay):captured(replay){\n    const bool prefill=data.capacity.qk_head_dim==256 && data.window==-1 && data.causal;\n    float_cap=std::size_t((original || !prefill)?22u:11u)<<20;')
source=source.replace('original?c::flashinfer::provider_control():c::flashinfer::provider_treatment()','c::flashinfer::provider()')
source=source.replace('.max_float_workspace_bytes=32u<<20','.max_float_workspace_bytes=float_cap')
source=source.replace('.causal=data.causal,.window_left=data.window}', '.causal=data.causal,.window_left=data.window,.allow_bf16_partials=!original}')
source=source.replace('std::fprintf(stderr,"# CUDA_ENCODED_COLD original=%d', 'if(slots[0].report().bf16_partials!=(!original && prefill))fail(hyle::Status::Internal("actual product partial policy mismatch"));\n    std::fprintf(stderr,"# CUDA_ENCODED_COLD original=%d')
needle='query=take(writer.publish());'
assert source.count(needle)==1
source=source.replace(needle,needle+'''
    if(captured)for(auto &slot:slots){auto prepared=take(slot.update_batch(layout));check(prepared.prepare_replay(query,key_frame,value_frame));if(!slot.report().capture_compatible)fail(hyle::Status::Internal("cold public replay did not record"));}
    const auto stats=take(memory.ref().resource().stats());
    std::printf("PRODUCT_MEMORY f32=%d captured=%d float_cap=%zu required_workspace=%zu bf16_partials=%d resource_used=%zu resource_reserved=%zu slots=2\\n",original,captured,float_cap,slots[0].report().float_workspace_bytes,slots[0].report().bf16_partials,stats.used_bytes,stats.reserved_bytes);
''')
source=source.replace('if(!slot.report().reused_native_plan)fail', 'if(captured && !slot.report().capture_compatible)fail(hyle::Status::Internal("warm capture was lost"));\n    if(!slot.report().reused_native_plan)fail')
start=source.index('void attrs(){');stop=source.index('void measure(',start)
source=source[:start]+source[stop:]
source=source.replace('void measure(unsigned alloc,unsigned order,','void measure(unsigned alloc,unsigned order,bool captured,')
source=source.replace('std::make_unique<Harness>(data,side==0)','std::make_unique<Harness>(data,side==0,captured)')
source=source.replace('alloc=%u order=%u shape=', 'alloc=%u order=%u capture=%u shape=')
source=source.replace('alloc,order,shape,','alloc,order,unsigned(captured),shape,')
source=source.replace('  attrs();\n','')
source=source.replace('    for(unsigned port=1;port<3;++port)', '''    std::vector<std::uint16_t> query_after(data.query.size());
    check(query.view()->read(std::as_writable_bytes(std::span(query_after))));
    if(query_after!=data.query)fail(hyle::Status::Internal("paged readonly Q changed"));
    for(unsigned port=1;port<3;++port)''')
source=source.replace('for(unsigned side=0;side<2;++side)h[side]->verify(data,expected);',
                      'for(unsigned pass=0;pass<2;++pass)for(unsigned side=0;side<2;++side)h[side]->verify(data,expected);')
source=source.replace('allocation_orders=2 execution_orders=2 trace=', 'allocation_orders=2 execution_orders=2 capture_modes=2 product_single_factory=1 baseline_f32=1 treatment_bf16=1 trace=')
source=source.replace('for(unsigned alloc=0;alloc<2;++alloc)for(unsigned order=0;order<2;++order){','for(unsigned replay=0;replay<2;++replay)for(unsigned alloc=0;alloc<2;++alloc)for(unsigned order=0;order<2;++order){')
source=source.replace('measure(alloc,order,','measure(alloc,order,replay!=0,')
source=source.replace('measure(0,0,64,128,1023,767,256,256,true,-1,true);','measure(0,0,false,64,128,1023,767,256,256,true,-1,true);\n  measure(0,0,true,64,128,1023,767,256,256,true,-1,true);')
# Resolve the observed heavy-tail uncertainty with larger, fixed blocks before
# the first product measurement. No trimming or primary-metric change.
source=source.replace('>,512> raw{}','>,4096> raw{}')
source=source.replace('group<8','group<32').replace('step<64','step<128')
source=source.replace('group*64+step','group*128+step')
source=source.replace('count=64','count=128').replace('sums[0]/64,sums[1]/64','sums[0]/128,sums[1]/128')
source=source.replace('groups=8 group_size=64','groups=32 group_size=128')
assert 'provider_control' not in source and 'target_control' not in source
assert 'allow_bf16_partials=!original' in source and 'capture=%u' in source
(work/'consumer.cc').write_text(source);(out/'consumer.cc').write_text(source)
identity={'source_sha256':hashlib.sha256(source.encode()).hexdigest(),'path':str(work/'consumer.cc'),'only_one_product_factory':True,'normal_and_public_prepare_replay':True,'prefill_caps_bytes':{'f32':22<<20,'bf16':11<<20},'control_caps_bytes':22<<20,'link_intent':'fresh ABI-owning compute_batch/graph_batch/FlashInfer/GGML libraries; unchanged lower dependencies reused; actual final map/hash recorded after link','diagnostic_primary':'all-tail complete episode arithmetic block mean; paired 2allocation x2execution x2capture modes'}
(work/'source-identity.json').write_text(json.dumps(identity,indent=2)+'\n');(out/'source-identity.json').write_bytes((work/'source-identity.json').read_bytes())
print(json.dumps(identity,indent=2))
