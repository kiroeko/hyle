from pathlib import Path
import hashlib, json, subprocess, time

repo = Path('/mnt/c/public/project-hyle/hyle')
out = repo / '.scratch/g04-bf16-product-bench'
work = Path('/root/hyle-scratch/compute-unified/g04-bf16-product-bench')
dest = out / 'run-1'
dest.mkdir(exist_ok=False)
binary = work / 'product_bench'
info = {
    'argv': [str(binary)],
    'binary_sha256': hashlib.sha256(binary.read_bytes()).hexdigest(),
    'source_sha256': hashlib.sha256((work / 'consumer.cc').read_bytes()).hexdigest(),
    'predeclared_schedule': '32 blocks x 128 pairs; 2 allocation x 2 execution x 2 capture modes x 3 shapes; retain all tails',
    'primary': 'complete public episode arithmetic mean; no control normalization or trimming',
}
gpu = subprocess.run(['/usr/lib/wsl/lib/nvidia-smi', '--query-gpu=name,uuid,driver_version,memory.used,temperature.gpu', '--format=csv,noheader'], capture_output=True, text=True)
info['gpu_pre'] = {'returncode': gpu.returncode, 'stdout': gpu.stdout, 'stderr': gpu.stderr}
info['started_unix'] = time.time()
(dest / 'identity.json').write_text(json.dumps(info, indent=2) + '\n')
print(json.dumps(info), flush=True)
with (dest / 'stdout.log').open('w') as stdout, (dest / 'stderr.log').open('w') as stderr:
    result = subprocess.run(info['argv'], stdout=stdout, stderr=stderr)
info.update(returncode=result.returncode, elapsed_s=time.time() - info['started_unix'])
(dest / 'result.json').write_text(json.dumps(info, indent=2) + '\n')
print(json.dumps(info), flush=True)
raise SystemExit(result.returncode)
