from pathlib import Path
import hashlib,json,subprocess,sys,time
repo=Path('/mnt/c/public/project-hyle/hyle');name='g04-bf16-product-peer-bench'
out=repo/'.scratch'/name;work=Path('/root/hyle-scratch/compute-unified')/name;work.mkdir(exist_ok=True)
source=out/'consumer.cc';(work/'consumer.cc').write_bytes(source.read_bytes())
commands=json.loads((repo/'.scratch/g04-bf16-product-bench/commands.json').read_text())
old=Path('/root/hyle-scratch/compute-unified/g04-bf16-product-bench')
for stage,args in commands.items():
 commands[stage]=[str(work/'consumer.cc') if x==str(old/'consumer.cc') else str(work/'consumer.o') if x==str(old/'consumer.o') else str(work/'consumer') if x==str(old/'product_bench') else '-Wl,-Map='+str(work/'link.map') if x=='-Wl,-Map='+str(old/'link.map') else x for x in args]
(out/'commands.json').write_text(json.dumps(commands,indent=2)+'\n')
stage='compile' if '--compile-only' in sys.argv else 'link';start=time.monotonic()
with (out/(stage+'.log')).open('w') as f:r=subprocess.run(commands[stage],stdout=f,stderr=subprocess.STDOUT)
result={'stage':stage,'seconds':time.monotonic()-start,'exit_code':r.returncode,'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'gpu_executed':False}
if (work/'consumer').exists():result['binary_sha256']=hashlib.sha256((work/'consumer').read_bytes()).hexdigest()
(out/('build-'+stage+'.json')).write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result));raise SystemExit(r.returncode)
