import hashlib
import json
import pathlib
import shlex
import subprocess
import sys
import time

from build_consumer import BUILD, OUT, SOURCE, WORK, commands

OLD = pathlib.Path('/root/hyle-scratch/compute-unified/g06-final-sdk/cuda-static-1/build')

def main():
    WORK.mkdir(parents=True, exist_ok=True)
    cc = json.loads((OLD / 'compile_commands.json').read_text())
    entry = next(c for c in cc if c['file'].endswith('/native_cache_test.cc'))
    compile_argv = shlex.split(entry['command'])
    compile_argv[1:1] = ['-I' + str(SOURCE / 'include')]
    compile_argv[compile_argv.index('-o') + 1] = str(WORK / 'native_cache_test.o')
    compile_argv[-1] = str(SOURCE / 'tests/compute_provider_flashinfer/native_cache_test.cc')
    link_argv = commands()['link']
    link_argv = [a.replace(str(WORK / 'consumer.o'), str(WORK / 'native_cache_test.o'))
                 .replace(str(WORK / 'public_consumer'), str(WORK / 'native_cache_test'))
                 .replace(str(WORK / 'link.map'), str(WORK / 'native-test-link.map')) for a in link_argv]
    link_argv += [str(OLD / 'lib/libgtest_main.a'), str(OLD / 'lib/libgtest.a')]
    plan = {'compile': compile_argv, 'link': link_argv}
    (OUT / 'native-test-commands.json').write_text(json.dumps(plan, indent=2) + '\n')
    for stage in sys.argv[1:] or ['compile', 'link']:
        start = time.time()
        with (OUT / ('native-test-' + stage + '.log')).open('w') as log:
            result = subprocess.run(plan[stage], stdout=log, stderr=subprocess.STDOUT)
        record = {'argv': plan[stage], 'started_unix': start,
                  'elapsed_s': time.time() - start, 'returncode': result.returncode}
        (OUT / ('native-test-' + stage + '.json')).write_text(json.dumps(record, indent=2) + '\n')
        print(json.dumps(record), flush=True)
        if result.returncode:
            raise SystemExit(result.returncode)
    if 'link' in sys.argv[1:] or len(sys.argv) == 1:
        path = WORK / 'native_cache_test'
        (OUT / 'native-test-binary.json').write_text(json.dumps({
            'path': str(path), 'sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
            'source_sha256': hashlib.sha256(pathlib.Path(compile_argv[-1]).read_bytes()).hexdigest()
        }, indent=2) + '\n')

if __name__ == '__main__':
    main()
