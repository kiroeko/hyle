import hashlib
import json
import os
import pathlib
import shutil
import subprocess
import time

from build_consumer import BUILD, OUT

def sha(data):
    return hashlib.sha256(data).hexdigest()

def main():
    obj = BUILD / 'src/compute_provider_ggml/CMakeFiles/hyle_compute_provider_ggml.dir/native_batch.cc.o'
    argv = ['ninja', '-C', str(BUILD), '-j2', str(obj.relative_to(BUILD))]
    start = time.time()
    with (OUT / 'ggml-host-object.log').open('w') as log:
        result = subprocess.run(argv, stdout=log, stderr=subprocess.STDOUT)
    record = {'argv': argv, 'started_unix': start, 'elapsed_s': time.time() - start, 'returncode': result.returncode}
    (OUT / 'ggml-host-object.json').write_text(json.dumps(record, indent=2) + '\n')
    print(json.dumps(record), flush=True)
    if result.returncode:
        raise SystemExit(result.returncode)
    archive = BUILD / 'bin/libhyle_compute_provider_ggml.a'
    members = subprocess.check_output(['ar', 't', str(archive)], text=True).splitlines()
    assert members == ['ggml_cpu_provider.cc.o', 'standard_index.cc.o', 'native_batch.cc.o'], members
    before = {name: sha(subprocess.check_output(['ar', 'p', str(archive), name])) for name in members}
    scratch = archive.with_suffix('.abi-update.a')
    assert not scratch.exists()
    shutil.copyfile(archive, scratch)
    subprocess.run(['ar', 'r', str(scratch), str(obj)], check=True)
    subprocess.run(['ranlib', str(scratch)], check=True)
    after = {name: sha(subprocess.check_output(['ar', 'p', str(scratch), name])) for name in members}
    assert after[obj.name] == sha(obj.read_bytes())
    assert all(before[name] == after[name] for name in members if name != obj.name)
    os.replace(scratch, archive)
    report = {'archive': str(archive), 'archive_sha256': sha(archive.read_bytes()),
              'object': str(obj), 'object_sha256': sha(obj.read_bytes()),
              'members_before': before, 'members_after': after,
              'method': 'Ninja rebuilt ABI-affected host TU; atomic archive replacement retains other members unchanged; unchanged runtime libraries reused.'}
    (OUT / 'ggml-host-archive.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps(report), flush=True)

if __name__ == '__main__':
    main()
