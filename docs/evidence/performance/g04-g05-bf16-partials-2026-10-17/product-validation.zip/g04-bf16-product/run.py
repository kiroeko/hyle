import hashlib
import json
import pathlib
import subprocess
import sys
import time

REPO = pathlib.Path('/mnt/c/public/project-hyle/hyle')
OUT = REPO / '.scratch/g04-bf16-product'
WORK = pathlib.Path('/root/hyle-scratch/compute-unified/g04-bf16-product')
SANITIZER = '/usr/local/cuda-13.3/bin/compute-sanitizer'

def main():
    mode = sys.argv[1]
    argv = {
        'ordinary': [str(WORK / 'public_consumer')],
        'memcheck': [SANITIZER, '--tool', 'memcheck', '--error-exitcode', '86', str(WORK / 'public_consumer')],
        'synccheck': [SANITIZER, '--tool', 'synccheck', '--error-exitcode', '87', str(WORK / 'public_consumer')],
        'native-test': [str(WORK / 'native_cache_test'), '--gtest_filter=FlashinferCache.*:FlashinferCacheEncode.*:FlashinferBatchReplay.*'],
        'feature-memcheck': [SANITIZER, '--tool', 'memcheck', '--error-exitcode', '88', str(WORK / 'native_cache_test'), '--gtest_filter=FlashinferCache.OptInBfloat16PartialsAgainstFeatureOracle'],
    }[mode]
    dest = OUT / ('run-' + mode + '-1')
    dest.mkdir(exist_ok=False)
    binary = WORK / ('native_cache_test' if mode in ('native-test', 'feature-memcheck') else 'public_consumer')
    info = {'argv': argv, 'binary': str(binary), 'binary_sha256': hashlib.sha256(binary.read_bytes()).hexdigest()}
    gpu = subprocess.run(['/usr/lib/wsl/lib/nvidia-smi', '--query-gpu=name,uuid,driver_version,memory.used,temperature.gpu', '--format=csv,noheader'], capture_output=True, text=True)
    info['gpu_pre'] = {'returncode': gpu.returncode, 'stdout': gpu.stdout, 'stderr': gpu.stderr}
    info['started_unix'] = time.time()
    (dest / 'identity.json').write_text(json.dumps(info, indent=2) + '\n')
    print(json.dumps({'mode': mode, 'argv': argv, 'dest': str(dest)}), flush=True)
    with (dest / 'stdout.log').open('w') as stdout, (dest / 'stderr.log').open('w') as stderr:
        run = subprocess.run(argv, stdout=stdout, stderr=stderr)
    info.update({'elapsed_s': time.time() - info['started_unix'], 'returncode': run.returncode})
    (dest / 'result.json').write_text(json.dumps(info, indent=2) + '\n')
    print(json.dumps({'mode': mode, 'elapsed_s': info['elapsed_s'], 'returncode': run.returncode}), flush=True)
    raise SystemExit(run.returncode)

if __name__ == '__main__':
    main()
