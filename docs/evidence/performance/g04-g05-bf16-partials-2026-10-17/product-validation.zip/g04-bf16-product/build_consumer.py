import hashlib
import json
import pathlib
import subprocess
import sys
import time

REPO = pathlib.Path('/mnt/c/public/project-hyle/hyle')
OUT = REPO / '.scratch/g04-bf16-product'
WORK = pathlib.Path('/root/hyle-scratch/compute-unified/g04-bf16-product')
SOURCE = pathlib.Path('/root/hyle-scratch/compute-unified/source-7a7b4c3b')
BUILD = pathlib.Path('/root/hyle-scratch/compute-unified/l-cpu-cuda/selected-graph/static-sdk-build')
SDK = pathlib.Path('/root/hyle-scratch/compute-unified/g06-final-sdk/cuda-static-1/relocated')

def commands():
    WORK.mkdir(parents=True, exist_ok=True)
    previous = json.loads((REPO / '.scratch/g04-public-capture/commands.json').read_text())
    compile_argv = previous['compile'][:]
    compile_argv = [arg for arg in compile_argv if not arg.startswith('-I/root/hyle-scratch/compute-unified/g04-factorial-fulltu')]
    compile_argv[1:1] = ['-I' + str(SOURCE / 'include')]
    compile_argv[compile_argv.index('-o') + 1] = str(WORK / 'consumer.o')
    compile_argv[-1] = str(SOURCE / 'tests/compute_batch/g04_bf16_partials_consumer.cc')
    link_argv = []
    for arg in previous['link']:
        if arg.endswith('.o') and '/g04-factorial-fulltu/' in arg:
            continue
        if arg.endswith('/g04-public-capture/consumer.o'):
            arg = str(WORK / 'consumer.o')
        elif arg.endswith('/g04-public-capture/public_capture'):
            arg = str(WORK / 'public_consumer')
        elif arg.startswith('-Wl,-Map='):
            arg = '-Wl,-Map=' + str(WORK / 'link.map')
        elif arg.startswith(str(SDK / 'lib/libhyle_')) and arg.endswith('.a'):
            candidate = BUILD / 'bin' / pathlib.Path(arg).name
            if candidate.is_file():
                arg = str(candidate)
        link_argv.append(arg)
    # Link archive groups preserve the genuine public Graph dependency closure,
    # without compiling or installing unrelated providers.
    first_archive = next(i for i, a in enumerate(link_argv) if a.endswith('.a'))
    link_argv[first_archive:first_archive] = ['-Wl,--start-group']
    link_argv += [str(BUILD / 'bin/libhyle_graph_batch.a')]
    link_argv += [str(p) for p in sorted((SDK / 'lib').glob('libhyle_graph*.a')) if p.name != 'libhyle_graph_batch.a']
    link_argv += ['-Wl,--end-group']
    return {'compile': compile_argv, 'link': link_argv}

def main():
    plan = commands()
    (OUT / 'consumer-commands.json').write_text(json.dumps(plan, indent=2) + '\n')
    for stage in sys.argv[1:] or ['compile', 'link']:
        start = time.time()
        with (OUT / ('consumer-' + stage + '.log')).open('w') as log:
            result = subprocess.run(plan[stage], stdout=log, stderr=subprocess.STDOUT)
        record = {'argv': plan[stage], 'started_unix': start,
                  'elapsed_s': time.time() - start, 'returncode': result.returncode}
        (OUT / ('consumer-' + stage + '.json')).write_text(json.dumps(record, indent=2) + '\n')
        print(json.dumps(record), flush=True)
        if result.returncode:
            raise SystemExit(result.returncode)
    if 'link' in sys.argv[1:] or len(sys.argv) == 1:
        binary = WORK / 'public_consumer'
        (OUT / 'consumer-binary.json').write_text(json.dumps({
            'path': str(binary), 'sha256': hashlib.sha256(binary.read_bytes()).hexdigest(),
            'source_sha256': hashlib.sha256(pathlib.Path(plan['compile'][-1]).read_bytes()).hexdigest()
        }, indent=2) + '\n')

if __name__ == '__main__':
    main()
