from pathlib import Path
import hashlib
import json
import shlex
import subprocess
import time

REPO = Path('/mnt/c/public/project-hyle/hyle')
OUT = REPO / '.scratch/g04-bf16-product-peer-trace'
WORK = Path('/root/hyle-scratch/compute-unified/g04-bf16-product-peer-trace')
SOURCE_SHA = 'f27e606b2b73e7b811168833222da64e9ad1de10ca152a566f71623715240846'

def main():
    OUT.mkdir(exist_ok=True)
    WORK.mkdir(exist_ok=True)
    assert not (OUT / 'consumer.cc').exists() and not (WORK / 'consumer.cc').exists()
    source_bytes = (REPO / '.scratch/g04-bf16-product-peer-bench/consumer.cc').read_bytes()
    assert hashlib.sha256(source_bytes).hexdigest() == SOURCE_SHA
    source = source_bytes.decode()
    changes = [
        ('std::array<std::array<double,2>,4096> raw{};', 'std::array<std::array<double,2>,32> raw{};', 1),
        ('group<32', 'group<2', 2), ('step<128', 'step<16', 2),
        ('group*128+step', 'group*16+step', 2),
        ('count=128 control_us=', 'count=16 control_us=', 1),
        ('sums[0]/128,sums[1]/128', 'sums[0]/16,sums[1]/16', 1),
        ('groups=32 group_size=128', 'groups=2 group_size=16', 1),
        ('diagnostic_trace=set("G04_TRACE");push(shape);',
         'diagnostic_trace=set("G04_TRACE");char trace_label[160]{};std::snprintf(trace_label,sizeof(trace_label),"PRODUCT_PEER capture=%u alloc=%u order=%u shape=%s",unsigned(captured),alloc,order,shape);push(trace_label);', 1),
        ('    if(slots[0].report().bf16_partials!=(!original && prefill))',
         '    std::printf("TRACE_PLAN original=%d captured=%d cta=%u padded=%u split=%d workspace=%zu\\n",original,captured,slots[0].report().cta_tile_q,slots[0].report().padded_batch_size,slots[0].report().split_kv,slots[0].report().float_workspace_bytes);\n    if(slots[0].report().bf16_partials!=(!original && prefill))', 1),
    ]
    for old, new, count in changes:
        assert source.count(old) == count, (old, source.count(old), count)
        source = source.replace(old, new)
    (OUT / 'consumer.cc').write_text(source)
    (WORK / 'consumer.cc').write_text(source)
    commands = json.loads((REPO / '.scratch/g04-bf16-product-peer-bench/commands.json').read_text())
    old_work = Path('/root/hyle-scratch/compute-unified/g04-bf16-product-peer-bench')
    for stage, argv in commands.items():
        commands[stage] = [arg.replace(str(old_work), str(WORK)) for arg in argv]
    (OUT / 'commands.json').write_text(json.dumps(commands, indent=2) + '\n')
    result = {'base_source_sha256': SOURCE_SHA, 'source_sha256': hashlib.sha256(source.encode()).hexdigest(),
              'scope': 'diagnostic trace only, 2x16 pairs in each 8 matrices; original ordinary source/binary/results unchanged',
              'changes': [{'old': old, 'new': new, 'count': count} for old, new, count in changes], 'stages': []}
    for stage in ['compile', 'link']:
        start = time.monotonic()
        with (OUT / (stage + '.log')).open('w') as log:
            r = subprocess.run(commands[stage], stdout=log, stderr=subprocess.STDOUT)
        result['stages'].append({'stage': stage, 'elapsed_s': time.monotonic() - start, 'returncode': r.returncode})
        (OUT / 'build.json').write_text(json.dumps(result, indent=2) + '\n')
        if r.returncode:
            raise SystemExit(r.returncode)
    result['binary_sha256'] = hashlib.sha256((WORK / 'consumer').read_bytes()).hexdigest()
    (OUT / 'build.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({k: v for k, v in result.items() if k != 'changes'}, indent=2))

if __name__ == '__main__':
    main()
