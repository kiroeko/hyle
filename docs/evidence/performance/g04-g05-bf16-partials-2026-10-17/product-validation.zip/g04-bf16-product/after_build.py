import hashlib
import json
import pathlib
import subprocess
import sys
import time

from build_consumer import BUILD, OUT, SOURCE

def main():
    history = json.loads((OUT / 'build-commands.json').read_text())
    assert history[-1]['stage'] == 'build' and history[-1]['returncode'] == 0
    argv = ['cmake', '--build', str(BUILD), '--target', 'hyle_compute_provider_ggml', '--parallel', '2']
    start = time.time()
    with (OUT / 'ggml-build.stdout.log').open('w') as stdout, (OUT / 'ggml-build.stderr.log').open('w') as stderr:
        result = subprocess.run(argv, stdout=stdout, stderr=stderr)
    record = {'argv': argv, 'started_unix': start, 'elapsed_s': time.time() - start, 'returncode': result.returncode}
    (OUT / 'ggml-build.json').write_text(json.dumps(record, indent=2) + '\n')
    print(json.dumps(record), flush=True)
    if result.returncode:
        raise SystemExit(result.returncode)
    libraries = [BUILD / 'bin' / ('libhyle_' + name + '.a') for name in
                 ['compute_batch', 'graph_batch', 'compute_provider_flashinfer', 'compute_provider_ggml']]
    for script in ['build_consumer.py', 'build_native_test.py']:
        result = subprocess.run([sys.executable, str(OUT / script), 'link'])
        if result.returncode:
            raise SystemExit(result.returncode)
    sources = [SOURCE / x for x in ['include/hyle/compute/batch_execution.h',
                                   'include/hyle/compute/batch_ops.h',
                                   'src/compute_provider_ggml/native_batch.cc']]
    identity = {str(p): {'sha256': hashlib.sha256(p.read_bytes()).hexdigest(), 'bytes': p.stat().st_size,
                         'mtime_ns': p.stat().st_mtime_ns} for p in libraries + sources}
    (OUT / 'abi-complete-identity.json').write_text(json.dumps(identity, indent=2) + '\n')
    print(json.dumps({'stage': 'ABI_ARCHIVES_AND_TESTS_READY', 'archives': identity}), flush=True)

if __name__ == '__main__':
    main()
