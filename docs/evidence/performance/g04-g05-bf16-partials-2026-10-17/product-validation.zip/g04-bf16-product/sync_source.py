import hashlib
import json
import pathlib
import tarfile
import time

REPO = pathlib.Path('/mnt/c/public/project-hyle/hyle')
OUT = REPO / '.scratch/g04-bf16-product'
SOURCE = pathlib.Path('/root/hyle-scratch/compute-unified/source-7a7b4c3b')
OVERLAYS = [
    'cmake/HyleDependencyLock.json',
    'docs/user/batch-attention.md',
    'include/hyle/compute/batch_execution.h',
    'include/hyle/compute/batch_ops.h',
    'src/compute_provider_flashinfer/flashinfer_provider.cc',
    'src/compute_provider_flashinfer/native_batch.cu',
    'src/compute_provider_flashinfer/native_batch.h',
    'src/compute_provider_flashinfer/native_cache.cu',
    'src/graph_batch/batch.cc',
    'third_party/flashinfer_cache/NOTICE.md',
    'third_party/flashinfer_cache/patches.json',
    'tests/compute_batch/g04_bf16_partials_consumer.cc',
]

def digest(data):
    return hashlib.sha256(data).hexdigest()

def main():
    start = time.monotonic()
    report = {'head': '0103f2d5893db8e295985eac79abf316c68c9e4e',
              'source': str(SOURCE), 'archive_changed': [], 'archive_same': 0,
              'overlays': []}
    archive = OUT / 'head.tar'
    sha = hashlib.sha256()
    with archive.open('rb') as stream:
        for chunk in iter(lambda: stream.read(8 << 20), b''):
            sha.update(chunk)
    report['archive_sha256'] = sha.hexdigest()
    with tarfile.open(archive, 'r') as tar:
        for member in tar:
            name = pathlib.PurePosixPath(member.name)
            assert not name.is_absolute() and '..' not in name.parts, member.name
            dest = SOURCE / name
            if member.isdir():
                dest.mkdir(parents=True, exist_ok=True)
                continue
            assert member.isfile(), (member.name, member.type)
            data = tar.extractfile(member).read()
            if dest.is_file() and dest.read_bytes() == data:
                report['archive_same'] += 1
                continue
            dest.parent.mkdir(parents=True, exist_ok=True)
            dest.write_bytes(data)
            dest.chmod(member.mode)
            report['archive_changed'].append({'path': member.name, 'sha256': digest(data)})
    for name in OVERLAYS:
        data = (REPO / name).read_bytes()
        dest = SOURCE / name
        same = dest.is_file() and dest.read_bytes() == data
        if not same:
            dest.parent.mkdir(parents=True, exist_ok=True)
            dest.write_bytes(data)
        report['overlays'].append({'path': name, 'sha256': digest(data), 'written': not same})
    report['elapsed_s'] = time.monotonic() - start
    (OUT / 'source-sync.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps({'archive_same': report['archive_same'],
                      'archive_changed': len(report['archive_changed']),
                      'overlays': report['overlays'], 'elapsed_s': report['elapsed_s']}, indent=2))

if __name__ == '__main__':
    main()
