import hashlib
import json
import pathlib
import subprocess
import time

REPO = pathlib.Path('/mnt/c/public/project-hyle/hyle')
OUT = REPO / '.scratch/g04-bf16-product'
SOURCE = pathlib.Path('/root/hyle-scratch/compute-unified/source-7a7b4c3b')
BUILD = pathlib.Path('/root/hyle-scratch/compute-unified/l-cpu-cuda/selected-graph/static-sdk-build')

def main():
    name = 'tests/compute_batch/g04_bf16_partials_consumer.cc'
    data = (REPO / name).read_bytes()
    assert hashlib.sha256(data).hexdigest() == '3d455dab91c6546ada121417630c9c84e6b4b17564aa889269425e8d78c087e4'
    dest = SOURCE / name
    if not dest.is_file() or dest.read_bytes() != data:
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_bytes(data)
    commands = [
        ('configure', ['cmake', '-S', str(SOURCE), '-B', str(BUILD), '-DHYLE_COMPUTE_ROUTES=cpu;cuda']),
        ('build', ['cmake', '--build', str(BUILD), '--target', 'hyle_compute_batch', 'hyle_graph_batch',
                   'hyle_compute_provider_flashinfer', '--parallel', '2']),
    ]
    records = []
    for stage, argv in commands:
        print(json.dumps({'stage': stage, 'argv': argv}), flush=True)
        started = time.time()
        with (OUT / (stage + '.stdout.log')).open('w') as stdout, (OUT / (stage + '.stderr.log')).open('w') as stderr:
            result = subprocess.run(argv, stdout=stdout, stderr=stderr)
        record = {'stage': stage, 'argv': argv, 'started_unix': started,
                  'elapsed_s': time.time() - started, 'returncode': result.returncode}
        records.append(record)
        (OUT / 'build-commands.json').write_text(json.dumps(records, indent=2) + '\n')
        print(json.dumps(record), flush=True)
        if result.returncode:
            raise SystemExit(result.returncode)
    identities = {}
    for path in [*SOURCE.glob('src/compute_provider_flashinfer/*'),
                 BUILD / 'bin/libhyle_compute_batch.a', BUILD / 'bin/libhyle_graph_batch.a',
                 BUILD / 'bin/libhyle_compute_provider_flashinfer.a']:
        if path.is_file():
            identities[str(path)] = hashlib.sha256(path.read_bytes()).hexdigest()
    (OUT / 'built-identity.json').write_text(json.dumps(identities, indent=2) + '\n')

if __name__ == '__main__':
    main()
