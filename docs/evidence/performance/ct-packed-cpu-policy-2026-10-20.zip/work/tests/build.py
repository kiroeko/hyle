from pathlib import Path
import importlib.util,sys,concurrent.futures
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent;A=S.parents[2];R=A.parents[1];O=S/'checks';O.mkdir(exist_ok=True);(O/'tmp').mkdir(exist_ok=True)
sp=importlib.util.spec_from_file_location('ct_ranking_test_build',A/'grouped-shared-activation/build_host.py');h=importlib.util.module_from_spec(sp);sp.loader.exec_module(h);b,c=h.b,h.c
freeze=c.read(S/'source-freeze.json')
for row in freeze['sources']:assert h.same_identity(row)
rows=[]
for arm in ['cpu','cuda']:
 p=A/'ct-packed-linear-cpu/tests/checks'/arm/'test-identity.json';recipe=c.read(p);source=R/f'tests/graph_route_{arm}/ct_packed_linear_test.cc';out=O/arm;out.mkdir(exist_ok=True);(out/'tmp').mkdir(exist_ok=True);rows.append(dict(arm=arm,source=b.identity(source),command=b.host_command(recipe['command'],source,'test',out),original_recipe=b.identity(p),prior_object=recipe['object'],out=str(out)))
c.save(O/'plan.json',dict(compile=rows,source_freeze=b.identity(S/'source-freeze.json'),CXX=2,links=0,NVCC=0,GPU=0))
def run(row):
 out=Path(row['out']);env,runtime=b.environment(row['command'],[],out);c.save(out/'environment.json',dict(PATH=env['PATH'],runtime=runtime));c.execute('test-compile',row['command'],env,out);dep=out/'test-deps.json';d=c.read(dep)['Data'];record=dict(row,object=b.identity(out/'test.obj'),source_dependencies=b.identity(dep),dependencies=[b.identity(p)for p in dict.fromkeys([d['Source'],*d['Includes']])]);c.save(out/'test-identity.json',record);return record
with concurrent.futures.ThreadPoolExecutor(max_workers=2)as pool:records=list(pool.map(run,rows))
for row in freeze['sources']:assert h.same_identity(row)
for row in rows:assert h.same_identity(row['prior_object'])
c.save(O/'summary.json',dict(passed=True,owners=records,CXX=2,links=0,NVCC=0,GPU=0,prior_objects_preserved=True))
print('CT_RANKING_CPU_CUDA_TEST_TWO_CXX_GREEN')
