from pathlib import Path
import importlib.util,json,sys
sys.dont_write_bytecode=True
R=Path.cwd();A=R/'.scratch/architecture-refactor-2026-10-18';S=Path(__file__).resolve().parent;out=S/'ranking/checks';(out/'tmp').mkdir(exist_ok=True)
spec=importlib.util.spec_from_file_location('ct_bench_helpers',A/'grouped-shared-activation/build_host.py');h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h);b,c=h.b,h.c
basepath=A/'ct-packed-cross-platform/ranking/cpu/link-plan.json';original=c.read(basepath);obj=c.read(out/'identity.json')['object'];assert h.same_identity(obj)
inputs=[b.identity(Path(arg))for arg in original['command']if Path(arg).is_absolute()and Path(arg).suffix.lower()in{'.obj','.lib'}]
for row in original['inputs']:assert h.same_identity(row),row['path']
current=inputs+[obj];env,runtime=b.environment(original['command'],[row['path']for row in current],out);env['DNNL_VERBOSE']='0';env['MKL_VERBOSE']='0';c.save(out/'environment.json',dict(PATH=env['PATH'],runtime=runtime,DNNL_VERBOSE='0',MKL_VERBOSE='0'))
command=[arg for arg in original['command']if not arg.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:'))]+[obj['path']];image=out/'cpu-bench.exe';command+=['/OUT:'+str(image),'/MAP:'+str(image.with_suffix('.map')),'/IMPLIB:'+str(image.with_suffix('.lib'))]
c.save(out/'link-plan.json',dict(command=command,inputs=current,base=b.identity(basepath),new=obj));c.execute('link',command,env,out);c.save(out/'image.json',b.identity(image))
