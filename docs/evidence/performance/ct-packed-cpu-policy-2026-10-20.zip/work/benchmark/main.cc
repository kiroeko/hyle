#include "tests/compute_models/ct_packed_graph_fixture.h"
#include "src/compute_route_cpu/default_policy.h"
#include "src/compute_provider_native/default_rules.h"
#include "src/graph_route_cpu/ggml_region.h"
#include "hyle/graph/cpu.h"
#include "hyle/graph/providers/onednn.h"
#include <chrono>
#include <iomanip>
#include <iostream>
#include <string>
#include <vector>

namespace f = ct_packed_graph_test;
namespace c = hyle::compute;
namespace g = hyle::graph;
namespace m = hyle::mem;
using Clock = std::chrono::steady_clock;
struct SystemResource final { m::MemoryResourceRef ref() noexcept { return m::system_resource(); } };

// Exact current Graph CPU facade assembly, with only ct_packed_regions absent.
// Both actual factories retain the original ggml and independent oneDNN region
// plus the same DefaultScope, default native provider, executor and thread hint.
c::Context without_ct_regions(c::cpu::DefaultContextOptions options) {
  auto ggml = g::cpu::internal::ggml_regions({.executor = options.executor,
                                            .native_threads = options.native_threads});
  c::ProviderBinding region{g::onednn::provider({.executor = options.executor}), 150};
  return f::take(c::cpu::internal::create_context(options,
      c::cpu::internal::DefaultScope::kGraph, std::move(ggml), std::move(region),
      c::native::internal::default_provider({.executor = options.executor},
          c::native::internal::DefaultRuleScope::kGraph, options.native_threads == 1)),
      "CPU Context without CT region decoration");
}

double micros(Clock::time_point begin, Clock::time_point end) {
  return std::chrono::duration<double, std::micro>(end - begin).count();
}
void optional(std::optional<std::size_t> value) {
  if (value) std::cout << *value; else std::cout << "null";
}
void numbers(const std::vector<double> &values) {
  std::cout << '[';
  for (std::size_t i = 0; i < values.size(); ++i) {
    if (i) std::cout << ',';
    std::cout << values[i];
  }
  std::cout << ']';
}
struct Arm final {
  std::string name;
  c::Context context;
  g::CompiledGraph program;
  g::Invocation slot;
  c::Queue queue;
  double cold_us = 0;
  std::vector<double> warm_us;
};
void compile(Arm &arm, const f::Logical &logical,
             std::span<const g::ConstantBinding> constants) {
  const auto begin = Clock::now();
  arm.program = f::take(g::cpu::compile(logical.graph, arm.context,
                                      {.constants = constants}), "same Graph compile");
  arm.cold_us = micros(begin, Clock::now());
  arm.slot = f::invocation(arm.program.executable);
  arm.queue = f::take(arm.context.create_queue(), "CPU Queue");
  std::size_t packed = 0;
  for (std::size_t i = 0; i < arm.program.report.step_count(); ++i)
    packed += arm.program.report.step(i).value().policy == f::kPackedPolicy;
  if (packed != (arm.name == "packed" ? 1U : 0U))
    throw std::runtime_error("actual CT contraction differs from requested arm");
}
double turn(Arm &arm, const f::Logical &logical, f::Bindings &inputs,
             const c::StorageOwner &owner) {
  // Caller reset/bind/output pool/replay-token preparation are outside both
  // arms' measured boundary. Cold compile and source upload are also separate.
  f::check(arm.slot.reset(), "warm slot reset");
  f::bind(logical, inputs, arm.slot, owner);
  const std::array queues{g::QueueBinding{g::ExecutionLaneId{0}, &arm.queue}};
  f::check(arm.slot.prepare_replay(queues,
      {.mode = g::ReplayMode::kCommands, .host_wait = g::HostWaitPolicy::kAllow}),
      "warm replay token");
  const auto begin = Clock::now();
  auto work = f::take(arm.slot.submit(arm.queue), "warm submit");
  f::check(work.wait(), "warm Completion::wait");
  const auto end = Clock::now();
  return micros(begin, end);
}
void report(const Arm &arm) {
  const auto storage = arm.program.report.compiled_storage();
  std::cout << "{\"name\":" << std::quoted(arm.name)
      << ",\"cold_compile_us\":" << arm.cold_us << ",\"warm_submit_to_completion_us\":";
  numbers(arm.warm_us);
  std::cout << ",\"storage\":{\"compiled_known_bytes\":" << storage.known_bytes()
      << ",\"compiled_total_bytes\":";
  optional(storage.total_bytes());
  std::cout << ",\"materialized_constant_bytes\":" << storage.materialized_constant_bytes
      << ",\"provider_persistent_known_bytes\":" << storage.provider_persistent_bytes
      << ",\"packed_constant_bytes\":" << storage.packed_constant_bytes
      << ",\"unknown_provider_count\":" << storage.unknown_provider_count
      << ",\"invocation_workspace_bytes\":" << arm.program.report.workspace_bytes()
      << "},\"steps\":[";
  for (std::size_t i = 0; i < arm.program.report.step_count(); ++i) {
    const auto step = arm.program.report.step(i).value();
    if (i) std::cout << ',';
    std::cout << "{\"provider\":" << std::quoted(std::string(step.provider.name))
        << ",\"kind\":" << int(step.kind) << ",\"nodes\":" << step.node_count
        << ",\"ct_packed_policy\":" << (step.policy == f::kPackedPolicy ? "true" : "false")
        << ",\"persistent_bytes\":";
    optional(step.persistent_bytes);
    std::cout << ",\"workspace_bytes\":" << step.workspace.size << '}';
  }
  std::cout << "]}";
}
int main(int argc, char **argv) {
  ::testing::InitGoogleTest(&argc, argv);
  try {
    f::check(c::cpu::configure_runtime_threads(1), "startup configure_runtime_threads(1)");
    const auto threads = f::take(c::cpu::runtime_thread_info(), "runtime thread info");
    double minimum_delta = std::numeric_limits<double>::infinity();
    for (std::size_t i = 0; i < 10000; ++i) {
      const auto begin = Clock::now(), end = Clock::now();
      const auto delta = micros(begin, end);
      if (delta > 0) minimum_delta = (std::min)(minimum_delta, delta);
    }
    std::cout << std::setprecision(12) << "{\"native_threads\":1,\"runtime_intra_op_limit\":";
    if (threads.intra_op_limit) std::cout << *threads.intra_op_limit; else std::cout << "null";
    std::cout << ",\"runtime_inter_op_limit\":";
    if (threads.inter_op_limit) std::cout << *threads.inter_op_limit; else std::cout << "null";
    std::cout << ",\"timer_min_observed_delta_us\":" << minimum_delta
        << ",\"warmup_per_arm\":2,\"interleaved_pairs\":4,\"cases\":[";
    bool first_case = true;
    for (const auto rows : {1, 128}) {
      if (!first_case) std::cout << ',';
      first_case = false;
      // These original bindings are shared by both Contexts; no escaped or
      // additionally published decoded W is used to force decomposition.
      const auto logical = f::build({true, f::Type::kBFloat16, f::Type::kBFloat16,
          f::Type::kBFloat16, rows}, 512, 1024, f::Escape::kNone, true);
      c::cpu::DefaultContextOptions options{.native_threads = 1};
      Arm packed, original;
      packed.name = "packed";
      packed.context = f::take(g::cpu::create_context(options), "ordinary CPU Context");
      original.name = "undecorated";
      original.context = without_ct_regions(options);
      auto owner = f::take(c::StorageOwner::adopt(packed.context, SystemResource{}), "CPU owner");
      f::Bindings inputs(logical, owner, 1);
      std::vector<g::ConstantBinding> constants;
      for (std::size_t i = 1; i < logical.ports.size(); ++i)
        constants.push_back({logical.ports[i], f::take(inputs.inputs[i].tensor(logical.descriptions[i]),
            "original packed constant"), g::ConstantPolicy::kBorrow, owner, inputs.inputs[i]});
      compile(packed, logical, constants);
      compile(original, logical, constants);
      for (std::size_t warmup = 0; warmup < 2; ++warmup) {
        (void)turn(packed, logical, inputs, owner);
        (void)turn(original, logical, inputs, owner);
      }
      for (std::size_t pair = 0; pair < 4; ++pair) {
        if (pair % 2) {
          original.warm_us.push_back(turn(original, logical, inputs, owner));
          packed.warm_us.push_back(turn(packed, logical, inputs, owner));
        } else {
          packed.warm_us.push_back(turn(packed, logical, inputs, owner));
          original.warm_us.push_back(turn(original, logical, inputs, owner));
        }
      }
      // Existing independent F64 staged oracle, outside all timed episodes.
      f::expect_dot(logical, inputs, f::read(f::output(packed.slot, logical.output)));
      f::expect_dot(logical, inputs, f::read(f::output(original.slot, logical.output)));
      if (::testing::UnitTest::GetInstance()->ad_hoc_test_result().Failed())
        throw std::runtime_error("independent oracle assertion failed");
      std::cout << "{\"M\":" << rows << ",\"N\":512,\"K\":1024,\"group\":32,"
          "\"scale_decode_operand\":\"BF16\",\"asymmetric\":true,\"published_values\":1,"
          "\"same_graph_and_original_borrowed_constants\":true,\"oracle_passed\":true,\"arms\":[";
      report(packed); std::cout << ','; report(original); std::cout << "]}";
      // The output pools borrow owner, which outlives both original slots.
      packed.slot = {}; original.slot = {};
    }
    std::cout << "]}\n";
    return 0;
  } catch (const std::exception &error) {
    std::cerr << error.what() << '\n';
    return 1;
  }
}
