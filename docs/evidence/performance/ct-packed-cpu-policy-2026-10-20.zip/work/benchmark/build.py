from pathlib import Path
import importlib.util,sys,json,hashlib,subprocess,os,time
sys.dont_write_bytecode=True
R=Path.cwd();A=R/'.scratch/architecture-refactor-2026-10-18';S=Path(__file__).resolve().parent;out=S/'checks';out.mkdir(exist_ok=True);(out/'tmp').mkdir(exist_ok=True)
def ident(path):
 p=Path(path);b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def save(path,x):path.write_text(json.dumps(x,indent=2)+'\n',encoding='utf-8')
env=os.environ.copy();r=subprocess.run(['cmd','/d','/c',str(A/'bf16-nan-cast-contract/compiler-env.bat')],text=True,capture_output=True,check=True)
for line in r.stdout.splitlines():
 if '='in line and not line.startswith('='):
  k,v=line.split('=',1);env[k.upper()]=v
recipe=A/'ct-packed-linear-cpu/tests/checks/cpu/test-identity.json';old=json.loads(recipe.read_bytes())['command'];base=[];skip=False
for arg in old:
 if skip:skip=False;continue
 if arg=='/sourceDependencies':skip=True;continue
 if arg.startswith(('/Fo','/Fd'))or arg.lower().endswith(('.cc','.cpp')):continue
 base.append(arg)
base+=['/DHYLE_COMPUTE_ONEDNN=1','/DHYLE_GRAPH_ONEDNN=1']
source=S/'main.cc';obj=out/'main.obj';dep=out/'main-deps.json';command=base+['/sourceDependencies',str(dep),str(source),'/Fo'+str(obj),'/Fd'+str(out/'main.pdb')]
save(out/'main-command.json',dict(command=command,source=ident(source),recipe=ident(recipe),factory_recipe=ident(A/'ct-packed-cross-platform/checks/src--graph_route_cpu--cpu_context-identity.json')))
start=time.time();r=subprocess.run(command,cwd=R,env=env,capture_output=True,text=True,encoding='utf-8',errors='replace');(out/'main.stdout.log').write_text(r.stdout,encoding='utf-8');(out/'main.stderr.log').write_text(r.stderr,encoding='utf-8');save(out/'main-result.json',dict(exit_code=r.returncode,seconds=time.time()-start));print('CXX',r.returncode,flush=True)
if r.returncode:print(r.stdout+r.stderr);raise SystemExit(r.returncode)
d=json.loads(dep.read_bytes())['Data'];save(out/'main-identity.json',dict(command=command,source=ident(source),object=ident(obj),recipe=ident(recipe),source_dependencies=ident(dep),dependencies=[ident(p)for p in dict.fromkeys([d['Source'],*d['Includes']])]))
spec=importlib.util.spec_from_file_location('ct_bench_helpers',A/'grouped-shared-activation/build_host.py');h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h);b,c=h.b,h.c
basepath=A/'ct-packed-cross-platform/cpu-green/link-plan.json';original=c.read(basepath);inputs=[b.identity(Path(arg))for arg in original['command']if Path(arg).is_absolute()and Path(arg).suffix.lower()in{'.obj','.lib'}];current=inputs+[b.identity(obj)]
for row in original['inputs']:
 if not h.same_identity(row):raise RuntimeError('base input drift: '+row['path'])
env,runtime=b.environment(original['command'],[row['path']for row in current],out);env['DNNL_VERBOSE']='0';env['MKL_VERBOSE']='0';save(out/'environment.json',dict(PATH=env['PATH'],runtime=runtime,DNNL_VERBOSE='0',MKL_VERBOSE='0'))
command=[arg for arg in original['command']if not arg.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:'))]+[str(obj)];image=out/'cpu-bench.exe';command+=['/OUT:'+str(image),'/MAP:'+str(image.with_suffix('.map')),'/IMPLIB:'+str(image.with_suffix('.lib'))]
c.save(out/'link-plan.json',dict(command=command,inputs=current,base=b.identity(basepath),new=b.identity(obj)));c.execute('link',command,env,out);c.save(out/'image.json',b.identity(image));print('prepared only; no benchmark execution',flush=True)
