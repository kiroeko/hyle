from pathlib import Path
import json,hashlib,subprocess,os,time
R=Path.cwd();A=R/'.scratch/architecture-refactor-2026-10-18';S=Path(__file__).resolve().parent
recipe=A/'ct-packed-cpu-native/checks/attempt1/native-provider-identity.json'
def ident(path):
 p=Path(path);b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def save(path,x):path.write_text(json.dumps(x,indent=2)+'\n',encoding='utf-8')
env=os.environ.copy();r=subprocess.run(['cmd','/d','/c',str(A/'bf16-nan-cast-contract/compiler-env.bat')],text=True,capture_output=True,check=True)
for line in r.stdout.splitlines():
 if '='in line and not line.startswith('='):
  k,v=line.split('=',1);env[k.upper()]=v
old=json.loads(recipe.read_bytes())['command'];base=[];skip=False
for arg in old:
 if skip:skip=False;continue
 if arg=='/sourceDependencies':skip=True;continue
 if arg.startswith(('/Fo','/Fd'))or arg.lower().endswith(('.cc','.cpp')):continue
 base.append(arg)
source=R/'src/compute_provider_native/native_provider.cc';obj=S/'native-provider.obj';dep=S/'native-provider-deps.json';command=base+['/sourceDependencies',str(dep),str(source),'/Fo'+str(obj),'/Fd'+str(S/'native-provider.pdb')]
save(S/'command.json',dict(command=command,source=ident(source),recipe=ident(recipe)));start=time.time();r=subprocess.run(command,cwd=R,env=env,capture_output=True,text=True,encoding='utf-8',errors='replace');(S/'stdout.log').write_text(r.stdout,encoding='utf-8');(S/'stderr.log').write_text(r.stderr,encoding='utf-8');save(S/'result.json',dict(exit_code=r.returncode,seconds=time.time()-start));print(r.stdout+r.stderr);print('CXX',r.returncode,flush=True)
if r.returncode:raise SystemExit(r.returncode)
d=json.loads(dep.read_bytes())['Data'];save(S/'identity.json',dict(command=command,source=ident(source),object=ident(obj),recipe=ident(recipe),source_dependencies=ident(dep),dependencies=[ident(p)for p in dict.fromkeys([d['Source'],*d['Includes']])]))
