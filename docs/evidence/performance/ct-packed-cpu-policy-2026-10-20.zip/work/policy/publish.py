from pathlib import Path
import hashlib,json,zipfile,xml.etree.ElementTree as E
S=Path(__file__).resolve().parent;A=S.parents[1];R=A.parents[1];B=A/'ct-packed-cpu-benchmark'
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def ident(p):
 p=p.resolve();data=p.read_bytes();return dict(path=str(p),bytes=len(data),sha256=hashlib.sha256(data).hexdigest())
validation={}
for arm,wanted in [('cpu',10),('cuda',8)]:
 p=S/arm/'tests.xml';root=E.parse(p).getroot();assert int(root.get('tests'))==wanted and int(root.get('failures'))==0 and int(root.get('errors'))==0
 cases=[(s.get('name'),t.get('name'))for s in root.findall('testsuite')for t in s.findall('testcase')];assert len(cases)==len(set(cases));assert not any(int(s.get('skipped','0'))for s in root.findall('testsuite'))
 for row in read(S/arm/'link-plan.json')['inputs']:
  now=ident(Path(row['path']));assert (now['bytes'],now['sha256'])==(row['bytes'],row['sha256'])
 validation[arm]=dict(tests=wanted,failures=0,skip=0,xml=ident(p),cases=cases)
sources=['src/compute_provider_native/native_provider.cc','src/graph/ct_packed_region.h','src/compute_provider_native/ct_packed.cc',
 'src/compute_packed_shared/ct_packed_linear.h','src/graph_route_cpu/ct_packed_linear_region.cc','src/graph_route_cuda/ct_packed_linear_region.cc',
 'tests/compute_models/ct_packed_graph_fixture.h','tests/graph_route_cpu/ct_packed_linear_test.cc','tests/graph_route_cuda/ct_packed_linear_test.cc',
 'docs/user/compute.md','docs/developer/current-work.md','docs/implementation/model-quantizations.json']
report=dict(date='2026-10-20',status='default_multirow_regression_fixed_with_packed_capability_retained',
 scope='CPU CT packed vs original decomposition on one unchanged public Graph and original packed constants. Correctness/performance follow-up to ct-packed-cpu; not a Qwen model throughput comparison.',
 cause='The bounded scalar row implementation decodes W independently for every activation row. Its memory savings did not justify unconditionally preferring it for matrix prefill.',
 decision='Cold native proposal leaves single-row rank unchanged and assigns multi-row CT rank1001, after ordinary facade native binding1000. The common region forwards an explicit backend rank, retaining its old200 default for the sentinel. Other operations and CUDA policy remain unchanged. Multirow packed capability stays available under hard admission constraints; RequirePrepared selection is actually tested.',
 architecture='Use existing backend policy preference, not fake dispatch/byte cost or new Graph scoring/configuration. No model/quantized-artifact whitelist, public API fields, hot routing, new executor or numerical changes.',
 windows=dict(before=read(B/'final-validation.json'),after=read(B/'ranking/final-validation.json')),
 observation=dict(before='M1 packed1364.4us vs original3100.3us (0.440x); M128 packed174009.1us vs original40982.8us (4.246x), all pairs4.207..4.287x. Original includes hot ArtifactDecode/View/ggml MatMul.',
  after='M1 actual CT count1:1421.2us vs original3233.15us. M128 actual CT count0:41381.25us vs original41457.5us, identical decomposition,0.998x is noise rather than a speedup.',
  memory='M1 packed known compiled storage376B/workspace0. Multirow default/original each1MiB workspace plus unknown ggml private storage; no claim that current multirow execution removes dense W.',
  boundary='N512/K1024/group32/asymmetric BF16 scales/decode/operand. Same input Graph publishes onlyY, original constants/A, original Context/provider assembly except CT decoration, two warmups and four AB/BA pairs. Intra-op/native limits1; observed inter-op24 in same shared runtime, not a claim that the whole process has only one thread. Cold compile is a separate single observation per arm.'),
 validation=validation,
 builds=dict(policy_native_CXX=1,common_region_CXX=2,test_CXX=2,benchmark_CXX=2,total_CXX=7,NVCC=0,SDK=0,links=4,correctness_processes=2,benchmark_processes=2,all_terminal_zero=True,whole_suite=False),
 source_freeze=[ident(R/p)for p in sources],
 limits=['Two synthetic geometries and one CPU/runtime configuration do not establish a universal crossover, fastest policy on every machine or full-model quality/speed.',
  'All current numerical and resource capability remains; this ranks existing candidates during cold discovery only.',
  'Prepared admission fallback is executed; generic memory-budget search must not be described as complete RSS/opaque-provider control.',
  'No new Linux/macOS run, whole-artifact payload, model peak-memory measurement or CUDA Qwen benchmark.'])
(S/'final-validation.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8',newline='\n')
payload={}
for p in sources:payload['source/'+p]=(R/p).read_bytes()
for label,folder in [('policy',S),('benchmark',B),('tests',A/'ct-packed-linear-cpu/ranking/test')]:
 for p in folder.rglob('*'):
  if p.is_file()and p.suffix.lower()in {'.json','.xml','.log','.cc','.h','.py','.diff'}and p.stat().st_size<3_000_000 and not any(x in p.relative_to(folder).parts for x in ('tmp','cleanup')):
   payload['work/'+label+'/'+p.relative_to(folder).as_posix()]=p.read_bytes()
manifest=[dict(member=k,bytes=len(v),sha256=hashlib.sha256(v).hexdigest())for k,v in sorted(payload.items())]
payload['payload-manifest.json']=(json.dumps(manifest,indent=2)+'\n').encode();dest=R/'docs/evidence/performance';arc=dest/'ct-packed-cpu-policy-2026-10-20.zip';assert not arc.exists()
with zipfile.ZipFile(arc,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9)as z:
 for k,v in sorted(payload.items()):z.writestr(k,v)
with zipfile.ZipFile(arc)as z:
 assert z.testzip()is None
 for row in manifest:
  data=z.read(row['member']);assert len(data)==row['bytes']and hashlib.sha256(data).hexdigest()==row['sha256']
report['archive']=dict(**ident(arc),payloads=len(manifest),CRC_checked=True,all_payload_SHA256_checked=True)
out=dest/'ct-packed-cpu-policy-2026-10-20.json';out.write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(dict(report=ident(out),archive=ident(arc)),indent=2))
