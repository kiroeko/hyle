from pathlib import Path
import importlib.util,sys,concurrent.futures
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent;A=S.parents[1];R=A.parents[1];O=S/'regions';O.mkdir(exist_ok=True);(O/'tmp').mkdir(exist_ok=True)
spec=importlib.util.spec_from_file_location('ct_rank_region_helpers',A/'grouped-shared-activation/build_host.py');h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h);b,c=h.b,h.c
def compile(arm):
 old=c.read(S.parent/f'checks/src--graph_route_{arm}--ct_packed_linear_region-identity.json')
 base=c.read(S.parent/('cpu-green'if arm=='cpu'else'cuda-final')/'link-plan.json')
 tag=arm+'-region';cmd=b.host_command(old['command'],Path(old['source']['path']),tag,O)
 env,runtime=b.environment(base['command'],[x['path']for x in base['inputs']],O)
 c.execute(tag,cmd,env,O);dep=Path(cmd[cmd.index('/sourceDependencies')+1]);data=c.read(dep)['Data']
 c.save(O/(tag+'-identity.json'),dict(command=cmd,source=b.identity(Path(old['source']['path'])),object=b.identity(O/(tag+'.obj')),source_dependencies=b.identity(dep),dependencies=[b.identity(Path(p))for p in dict.fromkeys([data['Source'],*data['Includes']])]))
with concurrent.futures.ThreadPoolExecutor(max_workers=2)as pool:list(pool.map(compile,['cpu','cuda']))
print('TWO_COLD_REGION_OWNERS_REFRESHED')
