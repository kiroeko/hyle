from pathlib import Path
import importlib.util,sys
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent;A=S.parents[1];R=A.parents[1]
spec=importlib.util.spec_from_file_location('ct_rank_link_helpers',A/'grouped-shared-activation/build_host.py');h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h);b,c=h.b,h.c
arm=sys.argv[1];testpath=Path(sys.argv[2]).resolve()
basepath=S.parent/('cpu-green'if arm=='cpu'else'cuda-final')/'link-plan.json';base=c.read(basepath);meta=h.metadata({arm:base})
rows=[c.read(S/'regions'/(arm+'-region-identity.json')),c.read(testpath)]
if arm=='cpu':rows.append(c.read(S/'native/identity.json'))
repl={}
for row in rows:
 old=[x for x in base['inputs']if c.key(x['path'])in meta and c.key(meta[c.key(x['path'])]['source_path'])==c.key(row['source']['path'])]
 assert len(old)==1,(row['source']['path'],len(old))
 repl[c.key(old[0]['path'])]=row['object']
inputs=[repl.get(c.key(x['path']),x)for x in base['inputs']]
for row in inputs:assert h.same_identity(row),row['path']
out=S/arm;out.mkdir(exist_ok=True);(out/'tmp').mkdir(exist_ok=True);image=out/(arm+'.exe')
cmd=[repl.get(c.key(arg),{}).get('path',arg)for arg in base['command']if not arg.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:'))]
cmd+=['/OUT:'+str(image),'/MAP:'+str(image.with_suffix('.map')),'/IMPLIB:'+str(image.with_suffix('.lib'))]
env,runtime=b.environment(base['command'],[x['path']for x in inputs],out)
c.save(out/'link-plan.json',dict(command=cmd,inputs=inputs,replacements=repl,base=b.identity(basepath)))
c.execute('link',cmd,env,out);c.save(out/'image.json',b.identity(image))
filt='CpuCtPackedLinear.*:NativeCtPackedLinear.*:CpuNvfp4ReferenceGraph.*'if arm=='cpu'else'CudaCtPackedLinear.*:CudaNvfp4ReferenceGraph.*:CudaMlxSharedActivation.*:CudaMlxMoeGraph.*'
c.execute('run',[str(image),'--gtest_filter='+filt,'--gtest_output=xml:'+str(out/'tests.xml')],env,out)
