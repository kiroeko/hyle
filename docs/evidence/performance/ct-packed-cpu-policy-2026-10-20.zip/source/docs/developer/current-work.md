# 当前工作主线

2026-10-17，用户明确以下八项工作；后续按用户选择推进。
本页记录任务与范围，不引入状态机、审批、预算或新的开发门禁。

1. 已删除旧治理工具、状态源、审批与资格流程，精简相关说明；保留实际构建、数值、资源寿命和并发回归。
2. 删除、合并、简化文档，减少重复和失效规则，保留有用的设计依据与历史源码、日志、数据。
   已按“首次构建→接入 C++→按任务查模块”重排入口，保留四层分工；共用合同集中说明，
   复杂边界保留示例与反例，过程卡与过时规则已清理。入口见[文档导航](../README.md)。
3. 提供统一初始化入口，在受支持系统上用简单参数配置编译环境，复用工具链与依赖缓存。
   2026-10-18 已统一为 `scripts/init.py`、`build.py`、`test.py`：自动发现工具链，按后端与产品
   准备依赖，支持配置切换、增量构建和安装；基础系统工具仍按平台正常安装。用法见[初始化指南](setup/README.md)。
4. 检查 Compute/Graph 的公共 C++ 接口是否符合推理引擎调用需要，包括易用性、一致性、布局
   转换及暴露给用户的内部 CMake 变量和宏。不按旧六问重新审核全项目。
   构建系统已完成路线、依赖、target 宏与资源装配的统一，见[构建设计](../architecture/build-system.md)。
   2026-10-18 已静态核对四条后端路线及三种 CPU＋GPU 桥接的公开头、所属 target、能力宏和安装闭包，
   普通消费者仍只链接产品 target；本轮未重跑跨平台交付构建。已移除 direct submit 的双输出位置歧义，
   多输出改用既有 span 入口；禁止租约绑定借用临时 writer，并明确各 owner 的 drain 是否永久关闭接纳。
   同步修正独立 runtime 的公开 prepare 入口及初始化后端选择说明。
5. 狩猎剩余性能输项；只要确认超出仪器分辨率与测量噪声，即使差距小也继续调查。
   2026-10-18 全模块首轮调研及当前优化见[性能清单](../evidence/performance/library-review-2026-10-18/README.md)。
   先排除不同工作与过期实现，再处理真实复杂度问题；历史小输与当前待测项分开记录。
6. 完成独立Qwen3.5-2B纯文本、无MTP/多模态的CUDA测试消费者，以真实调用校正底座接口、布局和性能。
   已跑通完整推理，并与llama.cpp进行同窗对照；当前数值、吞吐及剩余边界见下面的重构主线和
   [实测记录](../evidence/performance/qwen35-full-cuda-2026-10-19/README.md)。

7. 补全 MTP 所需的底座能力与真实消费者验证。
   2026-10-18 本轮补全 GDN 接受前缀快照、融合 recurrent 多 token 输入、页失败后的安全重试，
   并扩展公共状态消费者；用法与引擎边界见[状态版本](../user/state-versions.md#mtp-接受前缀并继续计算)。
8. 补全多模态所需的底座能力与真实消费者验证，优先图像 encoder/projector（mmproj）链路。

## 当前重构主线

当前目标是完成 Compute/Graph 推理执行体系的重构及余项，范围为 Windows/Linux/macOS 的单机
CPU、单 GPU、CPU＋一张 GPU，覆盖选定正式文本模型及主流量化。**主干已落地，整体尚未完成。**
设计与完成条件集中在[Compute 设计](../architecture/compute-design.md#推理执行体系的重构形状)，
模型、制品、角色、算子与融合以[现行总表](../implementation/model-operators.md)为准。
此前“约75%”只是旧功能审查的粗估，不作为当前完成比例。

当前调用链保持模型语义图→冷编译→不可变计划→独立 Invocation→prepare/bind/layout→严格 submit
→Completion／结果／状态发布。普通引擎中间层不判断平台、Provider 或原生算子。
Direct/Graph 共用实际实现事实；共同核心处理依赖、权限、alias、预算与寿命，各后端处理自己的数学、布局及原生资源。
CPU＋CUDA、CPU＋Apple/Vulkan 的旧专属运行时、Plan、Invocation 和 driver 已删除，不保兼容入口；
CUDA 仅保留冷环境 helper。普通图不强制 CPU 数学 Context、IO 或调度服务，后两项分别显式选用
`compute_stream`、`graph_progress`。可选进度驱动仍推进同一 SubmissionCursor，不另造执行器。

接下来交叉推进前四项，不能用单个模型成功或局部回归替代底座完成：

1. 查清当前 Qwen 的实际投影、准备／绑定／提交开销，继续公平比较加载、prefill、decode、显存和内存。
2. 按总表补非多模态功能、各种量化和融合接线；区分角色 header、算子运行与整制品执行。
3. 收敛三平台 CPU/GPU/混合调用链，补变长、有限 shape、KV/recurrent/conv 状态、分页、并发槽、
   旧结果与取消／失败／重试／关闭／退休的实际遗漏。
4. 清除重复路径，统一接口、构建和文档；新增普通算子或融合应集中于实际实现，不牵动共同调度和资源核心。
5. 完成 MTP 真实消费者闭环，复用已有状态、分支与接受前缀底座。
6. 补图像 encoder/projector（mmproj）和图像输入到文本推理的链路。

前四项是当前重构收工范围，后两项随后分别推进。测试引擎不扩张为正式产品；模型格式、tokenizer、
生成／接受策略与请求政策仍归引擎，可复用计算、存储、执行、搬运与状态能力归底座。

普通Paged/Ragged图已区分schema上限C、具体Q/output行数R和布局活跃行A，冷准备要求A<=R<=C，
owned分页仍精确R=A，显式MLA的独立合同未放开。CPU74项、CUDA2项、Apple3项及Vulkan3项实际回归通过；
CPU/CUDA验证同图有限128/1入口与CUDA capture，Apple/Vulkan验证C128下真实R1端口，
各自覆盖共享metadata、独立槽、旧输出和越界布局；不据此宣称全部MLA或模型组合已完成。
Qwen消费者现已迁到一份symbolic Graph/schema/finite family，启动预列实际chunk，每child保留原两个Invocation；
六个reader每步共享同一layout，Q/output为实际T行，无热建图或padding。公共child report提供实际资源描述，
family compiled storage按去重汇总并保留unknown计数；没有全局缓存或新executor。
原128+31的64份hidden/logits逐byte同；23/4/1的scheduler＋capture旅程与fresh前版6份向量逐byte同。
首次普通23/4续算正确在EOS停止，随后固定消费同一EOS ID才覆盖T1，原观察与检查脚本修正均保留。
产品main与被测候选逐byte同，另1个产品CXX增量构建和完整128+31 smoke通过。
两组独立窗口中shape准备0.335→0.269s（-19.60%）、0.348→0.262s（-24.53%），
TTFT分别-4.37%／-6.12%。首窗完整decode+0.23%／warm-1.72%，反向C/B/B/C复核+0.88%／+2.49%，
小差异反向，未证明稳定decode收益。13进程均exit0且预测一致，不合并两窗；
[源码、红绿与实测](../evidence/performance/qwen-finite-family-2026-10-20.json)未新测整模型峰值、物理kernel或独立质量。
封包核验后按根test.ps1回收86个过期镜像／重复向量文件，共约394MiB，当前镜像、对象与独特观测保留；
[清理记录](../evidence/performance/qwen-finite-family-2026-10-20.cleanup.json)。
此前[有限图设计审查](../evidence/correctness/batch-query-extent-2026-10-20.json)保留当时边界。随后独立修复CPU/CUDA的R>A输出尾部：原192个F16残留元素的复现对象不改即转绿，
只修改两个provider和一个私有几何helper，未改公共ABI或原生数学。CPU4项、CUDA4项实际通过且0skip，包含原有限图／capture邻居；
新增F16 ragged与BF16 paged/GQA2/Q64-V128，验证A1/R4、A1/R1/C128、A0/R4的两次污染后执行与前后护栏，
CUDA每次要求capture。A=R不加清零命令；原TensorView已精确裁切，因此撤回冗余共同裁切。
[本批红绿、源码与测试修正](../evidence/correctness/batch-output-tail-2026-10-20.json)不代表MLA、Direct或整模型已重新运行，未重测吞吐。

随后将`batch::prepare`的全量reset收敛为原Invocation内的配置撤销：保留稳定调用者输入／输出、lease与不可变InputSource owner，
清旧metadata、投影页权限及来源派生准备，显式`Invocation::reset`仍全清。原双资源布局更新用例不改测试对象即由红转绿；
CPU11项、CUDA4项实际通过且0skip，覆盖bind-once、变化载荷／布局、来源重新准备、旧结果门控、准确页权限失效和capture复用。
只改4个产品CXX；额外刷新1个旧Provider16工厂对象以匹配现Context17，未改版本检查、SDK或数学。
[本批源码、失败与回归](../evidence/correctness/layout-binding-lifetime-2026-10-20.json)仅证明Windows CPU/CUDA该旅程，未重跑其他平台、整模型或吞吐。
随后同一bind-once布局旅程在MacBook Air和Vulkan各3项回归通过；[跨后端续验](../evidence/correctness/mlx-moe-typed-inputs-2026-10-20.json)
复用实际原生执行与旧结果保护，Mac仅刷新4个共同产品对象和1个测试对象，未重编SDK或shader。
Linux随后以当前头与ABI增量续验同一路径：bind-once布局、配置/full reset和输入来源共9项通过、0skip。
复用原对象与依赖，只重编38个必要产品owner和3个既有测试owner；GCC首次严格警告发现的空Queue初始化
已显式补全。[源码、首错与实际回归](../evidence/correctness/linux-layout-current-2026-10-20.json)
只证明Linux CPU这9项，未重跑Linux CUDA、整模型或吞吐。
两批封包后按根`test.ps1`回收28个过期镜像／映射与导入库，共约643MiB；保留对象、SDK、当前及对照镜像和独特向量，[清理实录](../evidence/correctness/layout-binding-lifetime-2026-10-20.cleanup.json)。

当前真实 CUDA 消费者已执行完整24层、23-token prefill→4-token cached continuation→decode，
也有128-token prefill及31步固定输入decode的持续回归。Direct与可选进度驱动的相关旅程已有逐字节对照；
固定32阶段的64份hidden/logits用于后续回归，并不构成独立质量验收。
与早期Torch参考仍有BF16舍入、归约与attention实现差异；固定序列的top1曾相同31/32，
唯一差异步最高两token并列，logits相对L2均值1.166%、KL均值6.462e-4。
源序列来自既有参考，不能由此签收模型准确率。数学诊断、失败和边界见
[底座审查证据](../evidence/correctness/inference-foundation-review-2026-10-18/README.md)。

当前Qwen已将常量表达式、卷积权重转换及静态索引移入冷准备，接通typed RMS、36组GDN L2、
24组保BF16舍入的decode FFN、显式频率RoPE、typed Conv及Cast/稳定SiLU融合；普通投影保留cuBLAS叶偏好。
这些改动不复制gate/up整份权重，不改变公开舍入边界。最新实际trace为每步596个kernel、1次GraphLaunch，
其中591个图内核、5个辅助核，独立BF16/F32转换55个、Repeat为0；typed门控与同A双投影各18处。
按最近保留的参考trace，同口径每步总数为Hyle596、llama.cpp558；此前395是参考的非投影kernel数，并非总数。
原163项投影角色中，Hyle将36个小投影合为18次双投影，当前物理投影kernel为145（103 cuBLAS、24完整FFN、18双投影），
非投影451；参考物理投影163、非投影395。Hyle激活/输出主要为BF16、参考decode为F32，不能据kernel数推导同数学工作或提速。
最新两份保留trace的离线分摊中，双方投影约占各自kernel累计耗时的92%，每步逻辑矩阵权重约3.763GB；
本轮未发现新的大份额实现缺陷。此前确认GDN每步有18MiB状态stage-out，旧trace拷贝累计中位约30微秒；
现已通过直接写入真实状态输出消除，仍不能将其累计耗时当作可回收wall或主要差距。
两份软件插桩trace不同时，GraphLaunch区间也不能直接当可回收wall；详见[热点重审](../evidence/performance/decode-major-hotspots-2026-10-20.json)。

本批将独立CUDA消费者的权重加载接入现有FileResourcePipeline：保留320个原device分配与原BF16/F32字节，
借原Queue和pinned resource，以两个8MiB staging slot读取实际文件；目标LeasePool保留到Graph停止使用。
文件关闭、管线／native退休与临时Scheduler／IoContext销毁均计入完整启动和首token。
11:17:36–11:18:03的9新进程窗口中，原版→新加载的TTFT中位2.139→1.446s（-32.39%），
ready为2.069→1.376s；首批完整decode／warm分别-2.02%／-1.58%。另一次11:19:25–11:19:36的C/B/B/C四进程复核，
TTFT为2.106→1.429s（-32.15%），完整decode为+0.71%、warm为-0.44%，prefill两窗约-0.6%／-0.4%。
两窗各自保留，不合池、不用后窗替换前窗；小decode负差未同向复现，尚不能证明稳态收益或无回归。
全部13进程exit0、预测一致，完整64份hidden/logits逐byte相同。约32%指TTFT；新进程未清OS页缓存，不能称冷盘加载。
原load子计时不含稍后的mmap释放，新load含管线清理且lease域创建前移，净收益按完整启动／TTFT判断。
详见[有界pinned加载实测](../evidence/performance/qwen-pinned-weight-load-2026-10-20.json)。
证据封包核验后，已通过根`test.ps1`回收本批约500MiB过期镜像及重复向量；保留最新CPU／CUDA测试、
产品Qwen、直接前版与参考引擎、对象依赖及原始64份观测，[清理记录](../evidence/performance/qwen-pinned-weight-load-2026-10-20.cleanup.json)。

最新三方同窗为2026-10-20北京时间16:27:21–16:27:43：前版／当前／llama各3个新进程按Latin顺序交错，
固定128+31、context256。当前仅替换未插桩的退休查询provider，其余link输入与前版相同；
9进程exit0且预测一致，计时外另1进程的64份hidden/logits逐byte同参考，未跑profiler或旁采。

| 指标 | 前版Hyle | 当前Hyle | llama.cpp |
| --- | --- | --- | --- |
| 完整31步decode tokens/s中位 | 91.01 | 94.13 | 94.98 |
| warm第7–31步 tokens/s中位 | 94.33 | 96.74 | 96.79 |
| 首次prefill tokens/s中位 | 2019.42 | 2009.19 | 1244.87 |
| 首token秒中位 | 1.340 | 1.346 | 1.949 |

本窗当前相对参考完整／warm为-0.90%／-0.06%，相对前版中位+3.43%／+2.55%；
当前有一个完整85.85／warm86.17的慢进程，全部保留，区间重叠且每臂仅3份，不能签稳定追平或将warm变化归因冷退休优化。
同权重但BF16/F32中间计算与参考额外logits读回边界仍不同；
[原始分步、独立重算及限制](../evidence/performance/qwen-decode-rebenchmark-2026-10-20.json)只描述本窗。

此前两方同窗为2026-10-20北京时间15:02:47–15:03:02：Hyle／llama各3个新进程按H/P/P/H/H/P交错，
固定128+31、context256；6进程exit0且预测相同，无profiler／内存旁采，计时外编译链接。以下只描述该窗：

| 指标 | 当前Hyle | 同窗llama.cpp | 边界 |
| --- | --- | --- | --- |
| 完整31步decode tokens/s | 92.44 | 96.79 | 本窗中位低4.49% |
| warm第7–31步 tokens/s | 96.04 | 97.78 | 本窗中位低1.77%，样本范围重叠，不签稳定差距 |
| 首次prefill tokens/s | 2030.62 | 1261.59 | 含各自首次step工作 |
| 首token秒 | 1.349 | 1.942 | 各自引擎计时起点至首个host token，含加载／准备 |

本批将每步101个稳定端口绑定移到各child建槽，两臂同149个共同对象／库，64份hidden/logits与旧参考及彼此逐byte相同。
独立before/current/current/before四进程窗未证明提速：warm106.84→105.66（-1.11%）、full -0.70%，
cold_batch也未下降；仅保留接口简化，不把不同窗的绝对值或新peer窗归因为绑定收益。
新peer窗中Hyle最前两步cold_batch合计9.47／13.78／10.42ms，对应两parity首次record；该桶还含layout/metadata/prepare，
只是冷准备线索，不能签纯capture因果，更不能将工作挪出decode计时称作提速。
BF16/F32中间计算与readback边界仍不同，固定输入不构成独立质量验收，本窗未新测物理kernel或内存。
[源码、两独立窗与分步实录](../evidence/performance/qwen-stable-bind-2026-10-20.json)保所有负样本。
随后两次128+2短程诊断（capture/commands）各6份向量逐byte等旧prefix，未改产品或新跑吞吐窗。
首两步replay准备合计7.94／1.08ms，batch为1.56／1.59ms；额外工作定位在首次capture生命周期。
commands将编码转到submit，6.86ms差分不能直接认领为可回收收益；
[首次准备诊断](../evidence/performance/qwen-first-prepare-2026-10-20.json)保留原完整step边界。
随后在同一Completion原始链内复用已结束capture的正向证明，逐节点guard释放、辅助退休与错误处理保留；
实际每次decode首次准备的capture查询369→1，6项相关回归通过。每臂1个128+2诊断进程中，
首两步冷准备合计约少0.55ms；尚无新完整吞吐窗，不签稳态收益，见[退休查询复用](../evidence/performance/qwen-retirement-query-reuse-2026-10-20.json)。
已有两份596核trace的独立离线union分析表明，图内无activity合计中位约42–48微秒；
软件GraphLaunch重叠区间和7个原因未明的孤立长gap不能当可回收预算，见[时间分解](../evidence/performance/decode-busy-union-2026-10-20.json)。
此前12:16三方窗的Hyle／llama完整91.11／95.35、warm93.92／97.00及反向复核另见
[有限图族旧窗](../evidence/performance/qwen-finite-family-2026-10-20.json)，不与新窗合池或归因。

此前有限图族批次另独立运行前版／当时Hyle／参考各一个新进程，固定128+31、context256，PSAPI／PDH请求10ms采样。
专用GPU内存观测峰值分别3897.074／3895.074／4041.090MiB；当前与前版接近，不将2MiB差解释为稳定节省。
当前／参考的进程驻留集观测峰值为1076.668／4166.586MiB，private commit为5608.906／5000.098MiB，后者当前更高。
驻留集含映射／共享页，commit不等于驻留RAM，几种口径不能相加。参考保留mmap而Hyle沿FileIO读取，
文件缓存可落在系统缓存，不能将进程驻留集差当作全机RAM节省。实际最大采样间隔约16.7ms，
prefill仅6–9个样本，GPU峰值只代表采样下界；三进程exit0且32预测一致，不把这些旁采时长并入吞吐。
[原始内存序列、边界与限制](../evidence/performance/qwen-memory-current-2026-10-20.json)。

此前10:36:07–10:36:35窗口的Hyle／llama warm为94.25／93.71，完整91.23／91.76 tokens/s，
不足1%的差异未证明稳定反超；该窗load子段1.218／1.774s、准备0.341／0.007s做的工作不同。
[旧窗原始对照](../evidence/performance/gdn-direct-state-comparison-2026-10-20.json)保留，不与新窗合池。

此前09:29:46–09:30:16窗口的warm为Hyle91.59／llama92.96，完整87.74／91.10，
各臂后段均有明显慢样本；另一次粗粒度GPU时钟旁采的B/C/C/B为warm84.48→84.70、完整81.98→81.95。
这些历史样本与本窗分开保留，不合池或择好数；不能把全GPU时钟／利用率采样归于某个decode阶段。
同A、两个真实BF16输出的小行投影已作为通用冷候选接入，完整FFN优先；5项新CUDA回归、7项原生邻居及8项CPU回归通过，
最终64向量逐byte相同。实际每步614→596核，T1每槽显式workspace1811712→1807616B；没有重测整模型峰值。
共同收缩查询的位图改按候选拓扑跨度分配／清理，保原data/control合法性；另补完整FFN冷输入root的最终Mul延寿。
[本批源码与实测](../evidence/performance/paired-small-projections-2026-10-20.json)区分功能、物理命中和吞吐结论。

严格分页／row输入绑定已将整Plan alias与consumer扫描移入最终选定Plan的冷索引；只保存逻辑输入、物理副本与消费端口，
实际页、epoch、读者、artifact及权限仍逐次检查。当前三验证镜像涉及的10个私有PlanState头owner已刷新，
20项CPU、5项CUDA邻居与完整64向量逐byte对照通过；本轮未重测吞吐或Linux/macOS运行。
证据见[分页绑定冷索引](../evidence/performance/projected-bind-cold-index-2026-10-20.json)。已按根test.ps1执行回收约384MiB过期镜像及重复向量，
保留对象、依赖、当前镜像、直接前版Qwen、参考引擎及原始64份观测。

状态发布补上mutable lease的schema extent校验：同一block/generation经合法subview取回的短writer也不能当完整成员发布。
新回归对新鲜编译的旧实现实证产生8／0字节坏版本，修复后32项StateVersions／StateClone通过，保原pending与native失败处理。
详见[状态范围修复](../evidence/correctness/state-writer-slice-2026-10-20.json)；本项未重测GPU或推理吞吐。
另修原生clone句柄在显式host observer期间被取消／close并行访问的问题：只记录逻辑取消、封住准入，
close保持非阻塞；collect／rearm等先检查observer再触碰原句柄。真实CPU复制加确定性观察边界实证旧头红，
修复后33项StateVersions／StateClone通过、0skip；[源码与红绿记录](../evidence/correctness/state-clone-observer-close-2026-10-20.json)
保留初次测试源码编译错误；该项未运行其它后端。
随后已实证旧失败ticket／draft能误操作复用slot，改为取消／致命失败先撤销原copy所有权，
wait／poll也先核owner；Unavailable保留原copy与重试关系。最终旧实现4项新增回归中3项失败，
修复后37项StateVersions／StateClone通过、0skip；[源码、首轮复现与最终红绿](../evidence/correctness/state-clone-slot-ownership-2026-10-20.json)
保留原错、观察边界与真实reader独占回归。本批仅Windows CPU，未重测其它后端、模型或吞吐，未宣称状态寿命全部完成。

GDN单快照的闭合输出段现复用原数学kernel，直接写入独立状态CONT，保留原score拷贝；
冷准备确认私有中间值的读者及延寿，热执行仍核当前地址、owner和不重叠条件，其它情形保原执行。
13项CUDA回归与完整64份hidden/logits逐byte对照通过；新trace的25个warm步均为596核、1次GraphLaunch，
D2D由73次／19763200B降至55次／888832B，18次各1MiB的状态拷贝全消失。
本项保留原packed分配；吞吐见上面的独立同窗对照，尚无整模型峰值新测。[源码与结构实测](../evidence/performance/gdn-direct-state-output-2026-10-20.json)
同时保留最初漏链接4项L2邻居导致测试数量断言失败及补齐后的实际结果。
本轮StateWriter／GDN合计按根test.ps1回收约444MiB过期镜像与重复向量，保留对象、当前及直接前版镜像、参考引擎和原始64份观测；
[清理实录](../evidence/performance/gdn-direct-state-output-2026-10-20.cleanup.json)单独记录，未改已封存的源码／结构证据包。

前一批冷常量准备已按实际Context端点复用原Queue；两形状合计execution stream／pinned控制块创建182→2、
event创建2912→32，194核／170小上传的各形状冷数学序列与原等待次数不变。双形状准备中位437.308→332.805ms，
四进程复测436.864→335.914ms；完整首token仍计入映射释放。16项相关CPU回归及最终完整64向量通过。
详见[冷准备实测](../evidence/performance/cold-preparation-queues-2026-10-20.json)。
typed z门控复用原SiLU×Mul载体的输入与存储类型，完整保F32中间舍入；
13项相关CUDA回归与64份模型向量通过，实际warm每步650→614核、转换91→55。
[租约查找修复](../evidence/performance/lease-read-filter-2026-10-20.json)已在本次准备中按原顺序过滤读绑定，保live view与范围检查；
固定Qwen旅程的记录访问从2217072降到25000，decode每步69360→782。7项相关CPU回归与正式／计数镜像各64向量通过；
候选元数据冷预留，不缓存权限或命中。该复杂度改善不等于整模型提速，后续继续查实际投影与准备热点。
当前保留原BF16合同，未启用scratch里的F32消费者草稿。最新完整模型64份hidden/logits逐byte相同，
此前九进程及四进程复测均exit0、预测一致；尚无新的独立质量或总显存／内存峰值验收。
另以各1个独立进程采样Windows内存归因：GPU dedicated最大观察值为Hyle3.806／llama3.946GiB，
CPU private commit为5.477／4.884GiB；后者不是物理驻留量，GPU计数也不是瞬时真实峰值，均不混入吞吐统计。
逐批源码、时钟、物理trace和负结果见[实测记录](../evidence/performance/qwen35-full-cuda-2026-10-19/README.md)
及[门控批次](../evidence/performance/typed-gating-suffix-2026-10-20.json)。

最近功能批次已沿原执行路径补CT非对称INT4冷decode、GGUF NVFP4独立block64/36身份，
并修正CUDA MMQ重复expert slot映射。它们各有实际算子与寿命回归，未执行所选27B整制品。
Apple随后已补原编码NVFP4 MV/MM、expert及所选行路径，保F32激活与原共享输入，
相关Direct／Graph数值与寿命验证见[Apple批次](../evidence/correctness/apple-gguf-nvfp4-2026-10-20.json)。
CUDA随后已接CT symmetric/asymmetric INT4的普通同图Decode→精确Transpose View→MatMul冷融合，
允许权重链一处Cast，保源scale乘法、decode和operand舍入，直接读packed输入，不留整份dense W。
[4项Graph测试及5项MLX回归](../evidence/correctness/ct-packed-linear-2026-10-20.json)通过，含正向RequireCapture、
动态双槽、borrowed常量和逃逸后备。未运行所选27B payload或整模型，也未重测吞吐或峰值内存；
CPU随后沿同一recipe直接读原CT packed bank，CUDA/CPU共用冷识别与原PreparedOperation适配，未增加executor或普通叶偏好。
CPU保scale dtype乘法、decode、operand三处舍入，64元素栈内tile、0workspace；双槽更新A/codes/Z/scales与旧结果均覆盖。
CPU9项、CUDA8项实际通过且0skip；同一常量用例在旧CPU产品上因无packed region及opaque存储报告而红，
接通后N257/K1024的已知编译自有存储376B、workspace0，借用原压缩bank另计，不把它签成整机内存峰值。
保留新Graph／Direct的精度与逃逸回退以及原CUDA捕获，[CPU续接及共同识别](../evidence/correctness/ct-packed-cpu-2026-10-20.json)未重测Qwen吞吐、整制品或Linux/macOS。
封包后按根`test.ps1`回收24个被替代镜像／链接产物约564MiB，当前测试、模型对照、对象与依赖保留；
[清理实录](../evidence/correctness/ct-packed-cpu-2026-10-20.cleanup.json)。CPU packed的大M性能与默认选择仍须单独量化。
Apple/Vulkan的CT packed、成熟tensorcore/FFN/专家、其他packing及HF W4A4仍分别处理。
随后同图、同常量、相同线程边界的CPU对照确认：M1 packed中位约1.36ms／原路线3.10ms；
M128因每行重复解码约174.01ms／40.98ms，4.25倍退化，原路线包含热decode与ggml MatMul。
现默认单向量保持packed、多行先试原路线，仍保留packed候选；共同region转发后端既有rank，不把结构cost伪造成时间。
新窗M1约1.42／3.23ms；M128实际不再选CT，两臂约41.38／41.46ms，差异按噪声处理；不合池或推导通用crossover。
CPU10项、CUDA8项通过且0skip，新增同图默认多行／RequirePrepared两路线均执行独立oracle；
[排序修复与两独立窗口](../evidence/performance/ct-packed-cpu-policy-2026-10-20.json)保全部原始数据。
此时多行默认工作区仍为原1MiB并有未知provider私有量，不能称整模型已无dense W或总内存已受完整预算约束。
见[CT INT4](../evidence/correctness/ct-asymmetric-int4-2026-10-20.json)、
[GGUF NVFP4](../evidence/correctness/gguf-nvfp4-2026-10-20.json)及现行总表。

随后GroupedMatMul已补共享激活A=1及实际零slot步幅View，保原F32激活与累加、真实span和行距；
修复CPU BF16权重提前窄化激活、常量冷准备漏接，以及CUDA/Metal/Vulkan重复expert slot承载。
Apple同时修正原生输出实际分配量；Vulkan边界保原共享backing，原生矩阵按全部occurrence覆盖执行块。
本批Windows18项、Air16个公共数值域及8个native域通过，完整Qwen64份向量保持。
[原批证据](../evidence/correctness/grouped-shared-activation-2026-10-20.json)保留跨后端数值与寿命边界。

MLX packed grouped现也接通A=1与真实零slot步幅／token行距View，输出按IDs保独立槽，避免完整激活展开；
原codec、scale/bias、F32累加和已有舍入边界保持，[四后端记录](../evidence/correctness/mlx-grouped-shared-activation-2026-10-20.json)保留实际范围。
随后Vulkan mixed affine直接消费原typed输入，固定选择的专家下，额外F32 scale/bias bank从E3的96B／E17的544B降为0；
12个新增linear/grouped入口均完成Direct/Graph执行，原21函数与35份SPIR-V逐byte不变。
CPU/CUDA/Vulkan完整普通MoE各验证E3/E17、双槽、两轮内容更新与最终结果寿命；输出按公共ownership处理，无Provider分支。
[源码、失败与原生实测](../evidence/correctness/mlx-moe-typed-inputs-2026-10-20.json)不代表整制品、质量、吞吐或峰值内存验收。
随后Vulkan MLX为合资格不可变bank复用既有HAL借用：两槽共享原native存储，取消各槽整bank分配／首轮复制；
[同测试对象红绿与11项邻居](../evidence/correctness/vulkan-mlx-constant-bank-reuse-2026-10-20.json)验证7种kind／format及View／外部导入回退，数学与结果寿命保持。
每K组工作区仍在，Apple任意nested lazy View尚未核实；未重测整模型吞吐或峰值。
封包核验后按根`test.ps1`回收21个旧诊断／红例镜像及可重建链接产物，约265MiB；保留对象、SDK、当前及模型对照镜像，[清理实录](../evidence/correctness/mlx-moe-typed-inputs-2026-10-20.cleanup.json)。
Vulkan原生View另修正4处父指针：控制块继续持有lease／页帧／权重选择，指针指向实际Buffer父节点，避免资源报告按错误类型追根。
[原结构红例与5项寿命回归](../evidence/correctness/vulkan-view-root-owner-2026-10-20.json)通过，仅修改2个实现文件，无对象布局或公开接口变更。
两批封包后按根`test.ps1`再回收19个过期镜像／链接产物，约420MiB；保留当前与直接对照镜像、对象和SDK，[清理实录](../evidence/correctness/vulkan-mlx-constant-bank-reuse-2026-10-20.cleanup.json)。

CUDA plain随后已为合资格NVIDIA小T域接原MMVF，直接读GPU IDs，保A=1/独立slot、重复ID和原checked/guarded流程；
修复后备专家矩阵调用丢失F32 accumulator/source精度标记。[6项CUDA回归](../evidence/performance/plain-grouped-cuda-2026-10-20.json)通过，
含正常／非正规数精度见证和捕获；新F32-ID专域的实际SM89 SASS核对不带FTZ。
随后CUDA BF16专家bank已保留原存储，小T直接位扩宽后F32计算，奇K／大T保F32激活并仅临时转换单专家N×K；
删除整bank Cast、冷widen工厂及其专用singleton。相关[16项CUDA回归](../evidence/performance/bf16-grouped-bank-2026-10-20.json)通过，
含Direct64次动态重绑、borrowed常量及两个非正规数见证；实际32个严格F32/BF16-ID SM89 kernel无FTZ。
E8/N512/K2048常量对照消除32MiB F32副本，充分冷准备后的提交中位54.9→55.6μs，未证明提速；
raw常量缺owner而无法冷准备的旧路径另记。大T排序、IDs读回／同步及原生池空间仍在，严格mixed GLU融合尚未接。
本轮不代表新Qwen吞吐、整模型质量或峰值内存验收，也未重测Linux。

CUDA Graph随后已接同一激活及精确相同量化规则的两条FP8线性共享前置处理，保原两个GEMM、输出舍入和独立结果；
[16项相关回归及实际4→3核trace](../evidence/performance/fp8-shared-prologue-2026-10-20.json)通过。
固定样本提交至完成中位661.6→655.0μs，整个图的工作区均33792B；不推广为BF16 Qwen收益或峰值减半。
同时删除已失效的旧CUDA性能资格包装，并修正普通叶算子的执行次数报告；没有替代资格表或兼容入口。

Grouped FP8随后修复两份有限scale预乘溢出的问题：零权重codes、As=2、Bs=`2^127`时，
旧SM89实测F32／BF16各128个NaN；现在代码点积先乘As、再乘Bs，两次F32 RNE后沿原顺序累加。
原始SGLang源码、量化器、dot、ABI／geometry和checked align保留；两份AOT的实际PTX／SASS核对乘法边界。
[5项CUDA回归及同见证红绿对照](../evidence/correctness/grouped-fp8-scale-order-2026-10-20.json)通过，输出均为零。
这不证明普通F32点积等价、所选FP8整制品、质量、吞吐或其他平台完成。
这两项正确性修复封存后，已按根test.ps1回收约421MiB旧镜像／映射及导入库；
[清理实录](../evidence/correctness/state-clone-observer-close-2026-10-20.cleanup.json)保留精确目标，当前镜像、对象、依赖及推理对照基线仍保留。

CUDA浮点Cast现统一到既有原生PreparedOperation/shared queue，支持F32/F16/BF16/E4M3FN/E5M2，
删除旧managed转换分支。连续存储省坐标除模，byte-stride/广播保原布局；无Provider workspace或私有结果，
64位Cast/Copy不缩小原大descriptor域，普通算术仍保原32位域。CPU ATen的BF16 NaN payload丢失也已按SIMD规则修正。
CPU14项、CUDA14项通过、0skip：含全FP8位型、全F16/BF16入FP8、RNE边界、特殊值、护栏、旧输出及双槽，
以及共用tensor私有程序的两个row-cache邻居；
固定CT rank3 BF16 QDQ两端各四次提交逐bit等于独立oracle，CUDA完整链已RequireCapture。
约16Mi元素实际覆盖有界grid的跨轮尾部与护栏；8B元素仅做descriptor冷准备，未分配或运行巨型payload；未据此声明整FP8制品、原生FP8点积、质量或吞吐。
[原生转换与数值/capture回归](../evidence/correctness/cuda-native-storage-cast-2026-10-20.json)保原拒绝和测试修正；
不同部署端的量化/点积规则见[固定来源研究](../evidence/research/fp8-channel-token-contract-2026-10-20.json)。
本轮封包后按根`test.ps1`回收38个被替代镜像／链接产物，共1,074,220,879B（约1GiB）；
保留当前CPU/CUDA、Qwen直接前后与llama对照镜像、对象和依赖，[清理实录](../evidence/correctness/cuda-native-storage-cast-2026-10-20.cleanup.json)。
ModelOpt group16随后接通五输入`Nvfp4Linear`软件参考：A当前块QDQ、W非fast的scale先乘和BF16操作数边界明确；
CPU/CUDA复用原PreparedOperation/Invocation/Queue，A只量化一次，工作区2×M×K字节，W只展开当前组／row tile。
CPU5项、CUDA26项通过、0skip，包含原MLX/CT共享行骨架邻居；每端8次寿命提交、24次成功域提交、18次失败Completion，
恢复按原Graph合同重建Invocation；另实测拒绝CPU caller workspace覆盖A/W且输入未改。
[原生参考与数值／寿命证据](../evidence/correctness/nvfp4-reference-linear-2026-10-20.json)保留缺入口红例及测试生命周期假设修正。
[186角色header/生产者研究](../evidence/research/nvfp4-channel-global-contract-2026-10-20.json)仍未读取权重payload；
随后Apple/Vulkan typed参考也已接通：Apple6项、Vulkan17项邻居通过，CPU/CUDA新增非零subnormal见证后3／2项通过，均0skip。
每后端覆盖8次寿命提交、25次成功域及18次预期失败；Apple/Vulkan共用私有整数IEEE标量算术，
避免设备原生FTZ／近似除法改变合法域。实际发现并修复Vulkan六字节scale的冷常量D2D接入，复用原TransferSlot，暖推理无新增等待。
[四后端续验](../evidence/correctness/nvfp4-cross-backend-reference-2026-10-20.json)保留首错与边界；
硬件native FP4、整制品质量／吞吐及Linux该入口仍未验收，不能把软件参考签成这些域完成。
封包后按根`test.ps1`回收26个被替代镜像／链接产物，约659MiB；当前／直接前版、对象与依赖保留，
[清理记录](../evidence/correctness/nvfp4-reference-linear-2026-10-20.cleanup.json)保存精确目标。
四后端与新decode窗口封包后，另按根`test.ps1`回收Windows约925MiB、Mac约30MiB被替代镜像／链接产物；
当前／直接前版Qwen、参考、最新测试镜像、对象和依赖保留，[本批清理实录](../evidence/correctness/nvfp4-cross-backend-reference-2026-10-20.cleanup.json)。

跨平台已验证过有限形状、变长／分页attention、ready/pending来源、双槽、旧结果和取消／退休的多条实际旅程，
但不能推广为全部模型、dtype、布局和平台组合均完成。Vulkan固定backing的旧结果阻止复用，
Apple独立生成Array可保活至后续准备；close停止接纳，drain等待该实例实际退休，Scheduler空闲不代表GPU退休。
队列、共享KV/state和同Model推进仍受实际顺序与所有权约束。
Scheduler task/stack、原生metadata上传、Apple变KV的eager数组图等费用尚在，不能宣传零热分配。
Linux已有当前CPU＋CUDA finite-family增量运行证据，其余Linux旅程未代签。
当前paged scorer→TopK→压缩行decoder→Sink已接普通Graph及真实页权限，完整scores仍为O(T×C)。
各域正确性、失败恢复与资源限制集中在底座审查证据和对应用户指南，本页不重复实验流水账。

## 已确认范围

- 用户决定 G04/G05 先视为解决；公平实测与边界见
  [同 FP8 输入报告](../evidence/performance/g04-g05-bf16-partials-2026-10-17/same-fp8/README.md)。
- 用户澄清“多机器”指多系统上的**单机器推理**，不是多台机器协同推理。
- 底座应在受支持系统上覆盖 CPU、CPU＋一张 GPU、单 GPU 三种模式；硬件后端按实际系统支持。
- 除 MTP、多模态外，底座的稳定性和功能完整性仍是核心要求。不能仅用 Qwen3.5-2B
  单请求成功或若干算子片段推导三种模式均完整。
- Windows/Linux/macOS 平台能力、构建后端集合、CPU/GPU/混合执行模式和静态/动态交付应分开表达，
  合法组合由依赖图组装；混合执行所需桥接模块复用相应 CPU/GPU 后端。
- 普通用户无需决定算子分配到哪个 Provider 或启用哪些第三方库。后端选择带出完整实现依赖，
  运行时按请求与设备能力绑定实现；精度、设备放置和资源预算仍由引擎控制。
- 独立 Qwen3.5-2B CUDA 架构测试消费者已执行完整 prefill→续算→decode，并完成上述短程性能对照；
  数值接受、长期稳态性能与其余模型/系统的旅程仍未完成。该消费者不作为基础库交付的正式推理引擎。
- 模型格式、tokenizer、生成/接受策略与请求政策留在独立引擎；可复用计算、存储、
  状态、执行、搬运和图能力在 Compute/Graph 及相应基础模块解决。
- 2026-10-19 用户移除旧 DeepSeek-V4-Pro/Flash preview 及其 GGUF 衍生制品的支持要求，
  同时加入 V4 系列正式版 Pro-0813、Flash-0731，现行范围为 8 个文本模型，已锁定24个官方/GGUF基线配置；
  两个正式版各选官方、同版本 UD-Q4_K_XL 与 UD-Q8_K_XL，身份已锁定，GGUF 的逐角色 codec 与 DSpark 覆盖仍待核，
  见[模型—制品—算子总表](../implementation/model-operators.md)。不能把 API 别名或旧 preview 的制品身份当成正式版。
  用户随后明确还须覆盖这些模型的 Unsloth 与 Hugging Face 主流量化制品；24不是范围上限，
  按实际模型版本、角色和精确 codec/packing/数值合同扩充，不凭位宽或量化名称代替接线覆盖。
  先补正反向关系，再删除已证明仅服务旧 preview、正式版与其他现行模型均不需要的非通用实现，
  随后检查各量化精度的融合接线。正式版仍有 FP4 expert、hash routing、压缩与 mHC，不能整组删除。
  共享算子、独立公共能力及历史源码/日志/数据不因模型名删除；旧八模型审查仅提供历史事实。
- 后续融合和量化接线以该现行范围为准，
  使用实际 dtype、格式、形状与数值合同核对普通 Provider 路由；历史覆盖表仅提供模型事实，
  其中的旧通过、拒绝与流程状态不直接代表当前支持。
  2026-10-18 的接线补全、实际检查及剩余边界见[本轮报告](../evidence/correctness/model-route-completion-2026-10-18/README.md)。
  继续按 prefill、缓存接续、decode、多请求和接受前缀核对完整调用链；已扩充 CUDA/Vulkan
  量化 embedding，修复 Graph 非对称 attention 输出绑定，并补接四后端的部分高维原生批次。
  可组合的数学、原生分页承载和整模型执行分别记录，不能用当前白名单缩小功能需求。
  用户随后启动[非多模态底座全量审查](../evidence/correctness/inference-foundation-review-2026-10-18/README.md)：
  在以上模型范围内持续review融合、量化接线及Compute/Graph完整推理行为，包括资源调度、
  重复分配/转换/搬运、状态与失败寿命；先查证再修复，不将局部修复视为全量完成。

## 首个 Qwen3.5-2B 消费者的复用材料

模型输入身份见[本地输入清单](../implementation/tasks/compute/qwen35-2b-local-input.json)，
独立公式与中间结果生成见[文本参考](../../tests/compute_models/qwen35_reference.py)，
原运行条件见[参考预检数据](../evidence/correctness/qwen35-cli-preflight/README.md)。
这批早期参考材料覆盖公式与片段；完整 CUDA 消费者及实测结果见第六项。
加载、tokenizer、chat template、生成循环属于独立引擎。

接线时保留模型特有的数值边界，而不是仅匹配算子名字：

- 普通 RMS 的 scale 为模型规定的 `1+weight`；GDN gated RMS 是另一公式。
- linear Q/K 的 L2 使用 `sum(x*x)+eps`，不是 mean RMS；不要重复施加 GDN 已包含的 `1/sqrt(Dk)`。
- full-attention 的 Q/gate 按 head 拆分；partial RoPE 旋转 64 维并使用实际绝对位置。
- conv history 和 F32 recurrent state 逐层、逐步真实反馈；KV active 长度与 capacity 分开，新请求重置状态。
- 首次 prefill、多 token cached continuation 和单 token decode 分别核对。旧参考依赖的 cached 分支
  曾重置初始 state，不能把该行为复制为数学标准，也不能每轮把候选 state 换成 oracle state 来掩盖累计误差。

完整 CUDA 首版已按第六项约定关闭 MTP/视觉；与 llama.cpp 对照的权重、精度和计时边界见该项实测记录。
