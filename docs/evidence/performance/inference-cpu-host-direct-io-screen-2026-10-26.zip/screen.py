"""Fresh direct-IO 6 timing + 2 independent memory; retained observer only."""
from pathlib import Path
import importlib.util, json, os, re, sys
sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
B = W.parent
spec = importlib.util.spec_from_file_location('retained_CPU_counter_hooks', B / 'poll-screen.py')
p = importlib.util.module_from_spec(spec); spec.loader.exec_module(p)
m = p.m
reference = m.read(B / 'inline-executor1/behavior1/stdout.log')
detail = reference['sessions'][0]['result']
m.references = dict(hyle=reference, peer=dict(generated_ids=detail['generated_ids'], prompt_ids=detail['turns'][0]['input_ids']))
OUT = W / 'screen'
ARMS = dict(H=(B / 'inline-executor1/ready.json', B / 'inline-executor1/runtime.json'),
            C=(W / 'attempt3/ready.json', W / 'attempt3/model-link-runtime.json'))
METRICS = ('weights_load_seconds', 'startup_to_ready_seconds', 'prefill_tokens_per_second',
           'decode_output_tokens_per_second', 'output_tokens_per_second')

def loader(folder, arm):
    text = (folder / 'stderr.log').read_text(encoding='utf8', errors='replace')
    lines = [x for x in text.splitlines() if x.startswith('weight_loader ')]
    assert len(lines) == 1
    facts = dict(x.split('=', 1) for x in lines[0].split()[1:])
    expected = dict(backend='cpu', staging_bytes='16777216', io_calls='627', native_calls='627' if arm == 'H' else '0',
        native_waits='0', host_waits='0', phase_completions='627' if arm == 'H' else '0',
        copied_physical_bytes='3763655360' if arm == 'H' else '0', peak_backing_bytes='3780432576')
    assert facts == expected, (arm, facts)
    matches = re.findall(r'^weights_load_seconds=([0-9.eE+-]+)$', text, re.M)
    assert len(matches) == 1
    return facts, float(matches[0])

def summarize(rows):
    timing = {a: [x for x in rows if x['mode'] == 'timing' and x['arm'] == a] for a in ARMS}
    stats = {a: {k: m.stats([x['metrics'][k] for x in xs]) for k in METRICS} for a, xs in timing.items()}
    comparison = {k: dict(C_over_H_percent=(stats['C'][k]['median'] / stats['H'][k]['median'] - 1) * 100,
        better_direction='lower' if k.endswith('_seconds') else 'higher',
        ranges_overlap=max(stats['C'][k]['min'], stats['H'][k]['min']) <= min(stats['C'][k]['max'], stats['H'][k]['max'])) for k in METRICS}
    return dict(status='COMPLETE' if len(rows) == 8 else 'PARTIAL', processes=rows,
        timing=stats, comparison=comparison,
        timing_process_CPU={a: {k: m.stats([x['process_cpu'][k] for x in xs if x['process_cpu']['available']])
            for k in ('user_seconds','kernel_seconds','total_seconds')} for a,xs in timing.items()},
        memory={x['arm']: dict(summary=m.read(Path(x['folder'])/'memory-summary.json'),
            threads=m.read(Path(x['folder'])/'threads.json')) for x in rows if x['mode']=='memory'},
        full_stdout_nontime_all_pass=True, loader_fields_all_match_exact_arm_contract=True,
        H='caller217e original staged CPU load', C='c229 direct host IO with original late gate',
        order='H,C,C,H,H,C timing; H,C independent memory', old_samples_pooled=False,
        model_processes=8, peer_processes=0, warmups=0, retries=0, timeout_seconds=180,
        limits=['Three timing samples per arm, one Windows CPU N1/R1 greedy workload; no energy or general throughput claim.',
            'Loading/startup seconds are original producer endpoints. Prefill154/decode15/combined16 endpoints unchanged.',
            'GetProcessTimes occurs only after terminal wait; all process threads/startup/generation/teardown, not decode CPU cost.',
            'Independent PSAPI/PDH/thread samples do not enter timing stats. Missing GPU instances remain null; OS thread counts are not busy threads.',
            'Fixed staging allocation/budget stays unchanged; fewer native copies alone is not proof of a beneficial optimization.'])

def main():
    assert sys.argv[1:] == ['run']
    assert not OUT.exists(), 'Refuse overwrite/repeat'
    plan = {}
    for arm, (ready_path, runtime_path) in ARMS.items():
        ready = m.read(ready_path); assert m.pin(ready['image']['path']) == ready['image']
        command = list(m.read(B/'inline-executor1/behavior1/command.json')['command']); command[0] = ready['image']['path']
        plan[arm] = dict(ready=m.pin(ready_path), runtime=m.pin(runtime_path), image=ready['image'], command=command)
    OUT.mkdir(); m.save(OUT/'plan.json', dict(arms=plan, source=m.pin(__file__),
        protocol='Fresh H,C,C,H,H,C timing plus H,C memory; no retries,warmups,peer or old pooled samples.'))
    rows = []
    try:
        for i, (mode, arm) in enumerate([('timing',a) for a in 'HCCHHC']+[('memory','H'),('memory','C')], 1):
            folder = OUT / f'{i:02d}-{mode}-{arm}'; rt = m.read(plan[arm]['runtime']['path'])
            env = os.environ.copy(); env['PATH'] = rt['PATH']; env.update(rt.get('configured_flags', {}))
            env.update(HF_HUB_OFFLINE='1', TRANSFORMERS_OFFLINE='1'); m.current_folder = folder
            process = m.runner.execute(folder, 'hyle', plan[arm]['command'], env, mode == 'memory')
            raw = m.read(folder/'stdout.log'); work = m.check(raw, 'hyle'); facts, seconds = loader(folder, arm)
            metrics = {k: raw[k] for k in ('startup_to_ready_seconds','prefill_tokens_per_second',
                'decode_output_tokens_per_second','output_tokens_per_second','prefill_seconds','decode_seconds','session_seconds')}
            metrics['weights_load_seconds'] = seconds
            m.save(folder/'checks.json', dict(stdout=work, loader=facts))
            rows.append(dict(index=i,mode=mode,arm=arm,folder=str(folder),process=process,work=work,
                loader=facts,metrics=metrics,process_cpu=m.read(folder/'process-cpu.json')))
            m.save(OUT/'runs.json',rows)
            if len(rows) >= 2: m.save(OUT/'summary.json',summarize(rows))
            print('DIRECT_IO_TERMINAL',process['pid'],process['exit'],mode,arm,'WORK_PASS',flush=True)
    except Exception as exc:
        m.save(OUT/'failure.json', dict(error=repr(exc),completed=len(rows),stopped_before_next_process=True)); raise
    m.save(OUT/'summary.json',summarize(rows)); print('DIRECT_IO_WINDOW_COMPLETE_CPU_RELEASED',flush=True)

if __name__ == '__main__': main()
