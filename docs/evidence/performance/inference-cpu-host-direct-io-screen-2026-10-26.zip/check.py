"""Bounded private FileStream suite and one authorized normal CPU behavior."""
from pathlib import Path
import importlib.util, json, os, sys, xml.etree.ElementTree as ET
sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
B = W.parent
R = B.parents[1]
spec = importlib.util.spec_from_file_location('direct_io_host_tools', B / 'check_build.py')
b = importlib.util.module_from_spec(spec); spec.loader.exec_module(b)
read, pin, save, key = b.read, b.pin, b.save, b.key
CONTROL = B / 'inline-executor1'
ATTEMPT = W / (sys.argv[2] if len(sys.argv) > 2 else 'attempt1')

def compile_one(name, recipe, source):
    old = read(recipe)['command']
    command = [old[0], '/I' + str(W / 'source/include'), '/I' + str(W / 'source'),
               '/I' + str(R / source.relative_to(W / 'source').parent)]
    skip = False
    for a in old[1:]:
        if skip: skip = False; continue
        if a.lower() == '/sourcedependencies': skip = True; continue
        if a.lower().startswith(('/fo', '/fd')) or a.lower().endswith(('.cc', '.cpp')): continue
        command.append(a)
    out = ATTEMPT / 'compile' / name
    command += [str(source), '/sourceDependencies', str(out / 'dependencies.json'),
                '/Fo' + str(out / 'unit.obj'), '/Fd' + str(out / 'unit.pdb')]
    result = b.h.execute(command, b.env(command), out, timeout=120)
    deps = read(out / 'dependencies.json')['Data']
    actual = [pin(p) for p in dict.fromkeys([deps['Source'], *deps['Includes']])]
    for p in actual:
        rel = None
        try: rel = Path(p['path']).relative_to(R).as_posix()
        except ValueError: pass
        if rel and rel in {x['path'] for x in read(W / 'source-pins.json')['files']}:
            raise AssertionError('canonical changed header leaked into private compile: ' + rel)
    save(out / 'actual-dependencies.json', actual)
    return dict(process=result, object=pin(out / 'unit.obj'), actual_dependencies=pin(out / 'actual-dependencies.json'))

def hardlink_runtime(out):
    rt = read(CONTROL / 'runtime.json')
    target = out / Path(rt['native_hardlink']['path']).name
    os.link(rt['native']['path'], target)
    rt['native_hardlink'] = pin(target)
    save(out.parent / (out.name + '-runtime.json'), rt)
    return rt

def link(command, inputs, replacements, *, test=False):
    engine = set(key(x['path']) for x in inputs[-4:])
    assert all(x['path'].lower().endswith('unit.obj') for x in inputs[-4:])
    out = ATTEMPT / ('suite-link' if test else 'model-link')
    image = out / ('file-stream-tests.exe' if test else 'hyle.exe')
    cmd, seen = [], set()
    for a in command:
        if a.upper().startswith(('/OUT:', '/MAP:', '/IMPLIB:', '/PDB:')): continue
        if test and key(a) in engine: continue
        if key(a) in replacements:
            seen.add(key(a)); a = replacements[key(a)]['path']
        cmd.append(a)
    assert seen == set(replacements)
    if test: cmd.append(str(ATTEMPT / 'compile/suite/unit.obj'))
    actual_inputs = [replacements.get(key(x['path']), x) for x in inputs if not test or key(x['path']) not in engine]
    if test: actual_inputs.append(pin(ATTEMPT / 'compile/suite/unit.obj'))
    save(ATTEMPT / (out.name + '-inputs.json'), actual_inputs)
    cmd += ['/OUT:' + str(image), '/MAP:' + str(image.with_suffix('.map')), '/IMPLIB:' + str(image.with_suffix('.lib'))]
    result = b.h.execute(cmd, b.env(cmd), out, timeout=120)
    rt = hardlink_runtime(out)
    return dict(process=result, image=pin(image), runtime=rt)

def main():
    assert sys.argv[1] in {'prepare', 'build-suite', 'behavior'}
    rows = read(W / 'source-pins.json')['files'] + read(W / 'test-pins.json')['files']
    for x in rows:
        assert {k:v for k,v in pin(W / 'source' / x['path']).items() if k != 'path'} == x['after']
        assert {k:v for k,v in pin(R / x['path']).items() if k != 'path'} == x['before']
    inputs = read(CONTROL / 'link-inputs.json')
    jobs = []
    for rel, needle in [
        ('src/compute/batch_transfer.cc', 'compute--batch_transfer_cc'),
        ('src/compute_stream/file_stream.cc', 'compute_stream--file_stream_cc'),
        ('src/compute_stream/stream_sources.cc', 'compute_stream--stream_sources_cc'),
        ('src/compute_stream_cpu/file_stream.cc', 'compute_stream_cpu--file_stream_cc'),
        ('src/compute_stream_cuda/file_stream.cc', 'compute_stream_cuda--file_stream_cc')]:
        matches = [x for x in inputs if needle in x['path']]
        assert len(matches) == 1
        old = matches[0]
        recipe = Path(old['path']).parent / 'command.json'
        source = W / 'source' / rel
        # Unmodified source TUs must nevertheless see the new endpoint layout.
        if not source.exists(): source.parent.mkdir(parents=True, exist_ok=True); source.write_bytes((R / rel).read_bytes())
        jobs.append(dict(name=needle, source=pin(source), original_object=old, recipe=pin(recipe)))
    plan = dict(status='PREPARED_ONLY', control=pin(CONTROL / 'ready.json'), control_image=read(CONTROL / 'ready.json')['image'],
        product_pins=pin(W / 'source-pins.json'), test_pins=pin(W / 'test-pins.json'), five_host_TUs=jobs,
        suite=dict(target='existing compute_stream', filter='FileStream.*', expected_windows_tests=17,
            command='file-stream-tests.exe --gtest_filter=FileStream.* --gtest_output=xml:<suite-run>/results.xml'),
        behavior=dict(command=read(CONTROL / 'behavior1/command.json')['command'], timeout_seconds=180,
            reference=pin(CONTROL / 'behavior1/stdout.log'), maximum_model_processes=1),
        scope='No SDK/device TU/Model/weights/provider build. Remove four engine objects only for the existing gtest suite image; model image preserves every other exact caller217e link input.')
    save(W / 'check-plan.json', plan)
    if sys.argv[1] == 'prepare': print('PREPARED_NO_BUILD_OR_MODEL', flush=True); return
    if sys.argv[1] == 'build-suite':
        assert not ATTEMPT.exists(), 'Refuse overwrite completed/failed attempt'
        for x in inputs: assert pin(x['path']) == x
        compiled, replacements = {}, {}
        for job in jobs:
            if ATTEMPT.name == 'attempt3' or (ATTEMPT.name == 'attempt2' and job['name'] == 'compute--batch_transfer_cc'):
                previous = 'attempt2' if ATTEMPT.name == 'attempt3' else 'attempt1'
                result = read(W / previous / 'compile-summary.json')[job['name']]
                assert pin(result['object']['path']) == result['object']
                assert read(Path(result['actual_dependencies']['path']))[0] == pin(job['source']['path'])
                result = dict(result, reused_from=previous + ' same-source strict PASS')
            else:
                result = compile_one(job['name'], Path(job['recipe']['path']), Path(job['source']['path']))
            compiled[job['name']] = result; replacements[key(job['original_object']['path'])] = result['object']
            save(ATTEMPT / 'compile-summary.json', compiled)
        test_recipe = R / '.scratch/architecture-refactor-2026-10-18/optional-file-stream/windows/cpu_tests-identity.json'
        compiled['suite'] = compile_one('suite', test_recipe, W / 'source/tests/compute_stream/file_stream_test.cc')
        save(ATTEMPT / 'compile-summary.json', compiled)
        original_command = read(CONTROL / 'link/command.json')['command']
        suite = link(original_command, inputs, replacements, test=True)
        rt = suite['runtime']; env = b.env(original_command); env['PATH'] = str(Path(suite['image']['path']).parent) + os.pathsep + rt['PATH']
        run = ATTEMPT / 'suite-run'; b.h.ROOT = run
        result = b.h.execute([suite['image']['path'], '--gtest_filter=FileStream.*', '--gtest_output=xml:' + str(run / 'results.xml')], env, run, timeout=120)
        b.h.ROOT = R
        xml = ET.parse(run / 'results.xml').getroot()
        assert int(xml.attrib['tests']) == 17 and int(xml.attrib['failures']) == 0
        assert not any(t.find('skipped') is not None for t in xml.iter('testcase'))
        model = link(original_command, inputs, replacements)
        save(ATTEMPT / 'ready.json', dict(status='SUITE17_PASS_MODEL_NOT_RUN', compile=compiled, suite=suite,
            suite_run=result, tests=17, failures=0, skipped=0, image=model['image'], runtime=pin(ATTEMPT / 'model-link-runtime.json'),
            link=model['process'], control=pin(CONTROL / 'ready.json'), product_pins=pin(W / 'source-pins.json'), test_pins=pin(W / 'test-pins.json')))
        print('SUITE17_PASS_MODEL_READY', json.dumps(model['image']), flush=True)
    else:
        ready = read(ATTEMPT / 'ready.json'); assert ready['status'] == 'SUITE17_PASS_MODEL_NOT_RUN'
        assert pin(ready['image']['path']) == ready['image']
        rt = read(ready['runtime']['path']); env = b.env(read(CONTROL / 'link/command.json')['command'])
        env['PATH'] = rt['PATH']; env.update(rt.get('configured_flags', {})); env.update(HF_HUB_OFFLINE='1', TRANSFORMERS_OFFLINE='1')
        command = read(CONTROL / 'behavior1/command.json')['command']; command[0] = ready['image']['path']
        result = b.h.execute(command, env, ATTEMPT / 'behavior1', timeout=180)
        save(ATTEMPT / 'behavior-process.json', result)
        print('ONE_BEHAVIOR_TERMINAL_CPU_RELEASED', json.dumps(result), flush=True)

if __name__ == '__main__': main()
