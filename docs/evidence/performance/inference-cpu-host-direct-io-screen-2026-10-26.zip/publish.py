"""Publish retained direct-host-IO checks and screen; no build/model action."""
from pathlib import Path
import datetime, hashlib, json, zipfile
W = Path(__file__).resolve().parent
B = W.parent
R = B.parents[1]
PUBLIC = R / 'docs/evidence/performance/inference-cpu-host-direct-io-screen-2026-10-26.json'
ZIP = PUBLIC.with_suffix('.zip')

def read(p): return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def pin(p):
    p = Path(p).resolve(); data = p.read_bytes()
    return dict(path=str(p), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())
def save(p, x):
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_bytes((json.dumps(x, indent=2, ensure_ascii=False, allow_nan=False) + '\n').encode())

def main():
    final = read(W / 'final-summary.json')
    assert read(W / 'attempt3/behavior1/nontime-diff.json') == []
    screen = read(W / 'screen/summary.json')
    assert screen['status'] == 'COMPLETE' and len(screen['processes']) == 8
    assert all(x['process']['exit'] == 0 and x['work']['all_within_arm_non_time_fields_equal_initial_AVX2_pair']
               for x in screen['processes'])
    assert not (W / 'screen/failure.json').exists()
    for file in ('source-pins.json', 'test-pins.json'):
        for x in read(W / file)['files']:
            for phase in ('before', 'after'):
                path = W / ('before' if phase == 'before' else 'source') / x['path']
                assert {k:v for k,v in pin(path).items() if k != 'path'} == x[phase]
    final['status'] = 'CLOSE_NOT_MERGED'
    final['decision'] = dict(status='CLOSE_NOT_MERGED', canonical_product_changed=False,
        reason='Correctness checks passed, but the candidate loading and startup-to-ready times are slower with disjoint sample ranges. Prefill/decode/combined ranges overlap. No stable net throughput benefit; fewer copy calls alone is insufficient to merge.',
        next_action='Stop this candidate, no extra samples/tuning. Do not speculate about the cause of slower IO.')
    save(W / 'final-summary.json', final)
    files = {}
    def add(name, path):
        path = Path(path); assert path.is_file(), path
        assert path.suffix.lower() in {'.json','.py','.patch','.log','.xml','.txt'}, path
        assert name not in files
        files[name] = path
    for name in ['source.patch','source-pins.json','test.patch','test-pins.json','support-pins.json',
                 'design.json','independent-review.json','check.py','check-plan.json','screen.py','final-summary.json','publish.py']:
        add(name, W / name)
    for name in ['source.patch','source-pins.json','independent-review.json']:
        add('first-source-review/' + name, W / 'r1' / name)
    for attempt in ['attempt1', 'attempt2', 'attempt3']:
        root = W / attempt
        for name in ['first-failure.json','compile-summary.json','ready.json','behavior-process.json',
                     'suite-link-inputs.json','model-link-inputs.json','suite-link-runtime.json','model-link-runtime.json']:
            if (root / name).is_file(): add(attempt + '/' + name, root / name)
        for path in sorted(root.rglob('*')):
            if not path.is_file(): continue
            rel = path.relative_to(root)
            if path.name in {'command.json','process.json','actual-dependencies.json','stdout.log','stderr.log',
                             'results.xml','nontime-diff.json'}:
                add(attempt + '/' + rel.as_posix(), path)
        for name in (['source.patch','source-pins.json'] if attempt == 'attempt1' else
                     ['test.patch','test-pins.json'] if attempt == 'attempt2' else []):
            add(attempt + '/first-failed-source/' + name, root / 'frozen' / name)
    for name in ['plan.json','runs.json','summary.json']:
        add('screen/' + name, W / 'screen' / name)
    for row in screen['processes']:
        folder = Path(row['folder'])
        for path in sorted(folder.iterdir()):
            if path.is_file(): add('screen/' + folder.name + '/' + path.name, path)
    for name, path in {
        'control/ready.json': B / 'inline-executor1/ready.json',
        'control/runtime.json': B / 'inline-executor1/runtime.json',
        'control/link-inputs.json': B / 'inline-executor1/link-inputs.json',
        'control/behavior-stdout.log': B / 'inline-executor1/behavior1/stdout.log',
        'control/behavior-stderr.log': B / 'inline-executor1/behavior1/stderr.log',
        'retained-observer/poll-screen.py': B / 'poll-screen.py',
        'retained-observer/CPU-screen.py': R / '.scratch/inference-cpu-representative-20261026/peer-avx2/screen.py',
        'retained-observer/baseline-window.py': R / '.scratch/mtp-performance-convergence-20261025/baseline/window.py',
        'retained-observer/window.py': R / '.scratch/qwen-mtp-window-20261022/window.py',
        'retained-observer/runner.py': R / '.scratch/architecture-refactor-2026-10-18/d4-windows-preparation-2026-10-21/first-decode-startup-2026-10-21/multiturn/multiturn_run.py',
        'retained-observer/observer.py': R / '.scratch/shared-execution-20261021/observer.py',
        'retained-observer/sampler.py': R / '.scratch/architecture-refactor-2026-10-18/qwen-gpu-comparison/memory-probe/memory_probe.py',
    }.items(): add(name, path)
    report = dict(schema='hyle.cpu-host-direct-io-screen.v1', status='CLOSE_NOT_MERGED',
        generated_UTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        scope='Private buffered CPU FileStream direct-destination IO candidate. Existing typed endpoint, WriteLease, exact IO and late Context/Queue gate. No canonical product edit, public API, new runtime, executor, registry or option.',
        results=final,
        mechanism='CPU-only optional private mapping/finish callbacks qualify original catalog/physical host identity and unique writer. Flush capability is checked before IO for every mapped carrier. Unsupported capability returns to the original staged route. Actual IO retirement, explicit flush/close, second cancellation/deadline checkpoint and original late QueueSequence gate precede unchanged group publication.',
        source_review=dict(receipt=pin(W / 'independent-review.json'),
            history='Initial coherent-flush capability omission was fixed before compilation. The independent resolved review covers that change and three regression source cases. Its test pins precede a later two-name qualification fix for an ambiguous detail namespace; final test pins and successful strict compile/runtime receipts are separate authoritative records.',
            later_compile_corrections=['Explicit local Status replaces auto ResultError before Update.','Two test-only detail:: references become hyle::compute::detail::. No mathematical/control/lifetime change.']),
        correctness_scope='The original FileStream.* target passed17 Windows tests, including3 added tests. A separate sole normal P154/16/C256/N1/R1 CPU4 greedy behavior had complete stdout non-time0diff versus caller217e and identical16IDs/169target/15decode. These are correctness observations, not performance samples.',
        closure_scope='Five host product TUs refreshed together: batch_transfer, common file_stream, stream_sources, CPU factory and CUDA factory. Passed core object reused from attempt1, four remaining passed products from attempt2; final test object compiled in attempt3. No old/new StreamCopyEndpoint layout mixing in either final image. All other caller217e absolute link inputs preserved; Model/weights/provider/SDK/device TUs not rebuilt. GPU factory is linked but no GPU work was run.',
        precision='Existing frozen caller217e CPU BF16 weights, original activation/store points and F32 operation boundaries; native4/ATen4 with caller executor unchanged. No per-run kernel/ISA sampling, cross-dtype bit/quality, multi-request or mixed-device claim.',
        counter_scope='copied_bytes remains logical completed source-to-destination progress, verified by suite. Real loading stderr keeps627 IO calls,16MiB stage and backing budget; actual native calls/phases627->0 and physical-copy bytes3,763,655,360->0. These changes are expected work counters, not evidence of speed or freed staging.',
        measurement_limits=['Fresh6 timing+2 separate memory processes only; no old correctness/behavior/window samples pooled, warmup, retry, peer process or profiler.',
            'Original producer weights_load_seconds/startup_to_ready and154/15/16 prefill/decode/combined denominators retained; do not attribute changes between historical windows.',
            'Post-exit GetProcessTimes measures all process threads, startup/loading/generation/teardown. It is not decode CPU cost or energy.',
            'PSAPI/PDH and OS-thread sampling occurs only in independent memory processes. Peaks are lower bounds; OS thread count is not active-thread count. Missing GPU instances remain null.',
            'Windows CPU evidence only. Direct-IO files, mapping sources/writeback and GPU factories retain staged routes. No Mac/Linux/native-GPU runtime claim.',
            'No explanation of slower IO is established by these measurements. No extra samples or implementation tuning follow this closed candidate.'],
        cleanup_proposal=pin(W / 'cleanup-candidates.json'),
        publication='Offline source/raw-results archive only; no model/build/network during publication.')
    save(W / 'public-summary.json', report); add('summary.json', W / 'public-summary.json')
    manifest = [dict(name=n, bytes=p.stat().st_size, sha256=pin(p)['sha256']) for n,p in sorted(files.items())]
    save(W / 'archive-manifest.json', manifest); add('archive-manifest.json', W / 'archive-manifest.json')
    ZIP.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(ZIP, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for name, path in sorted(files.items()): z.writestr(name, path.read_bytes())
    with zipfile.ZipFile(ZIP) as z:
        assert z.testzip() is None and len(z.namelist()) == len(files)
        for item in manifest:
            data = z.read(item['name'])
            assert len(data) == item['bytes'] and hashlib.sha256(data).hexdigest() == item['sha256']
    report['archive'] = dict(**pin(ZIP), members=len(files), CRC_PASS=True, member_SHA256_PASS=True,
        exclusions='NoEXE/OBJ/LIB/EXP/DLL/map/SDK/model or whole frozen source tree; no old timing or memory samples.')
    report['archive']['path'] = ZIP.relative_to(R).as_posix(); save(PUBLIC, report)
    print(json.dumps(dict(report=pin(PUBLIC), archive=report['archive'], cleanup=read(W / 'cleanup-candidates.json')), indent=2))

if __name__ == '__main__': main()
