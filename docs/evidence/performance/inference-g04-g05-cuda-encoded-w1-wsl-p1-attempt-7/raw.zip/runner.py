from pathlib import Path
import hashlib,json,os,shutil,subprocess,sys,time
BASE=Path('/mnt/c/public/project-hyle/hyle/.scratch/inference-gaps/g04-g05')
attempt=sys.argv[1];run=BASE/'cuda-encoded-p1'/attempt;snapshot=json.loads((run/'snapshot.json').read_text())
ext=Path('/root/hyle-scratch/compute-unified');source=ext/('g04-cuda-encoded-p1-source-'+attempt)
build=ext/('g04-cuda-encoded-p1-fresh-'+attempt);out=ext/('g04-cuda-encoded-p1-output-'+attempt)
assert not source.exists() and not build.exists() and not out.exists()
start=time.monotonic();child=None
record={'state':'SETUP','snapshot':snapshot,'source':str(source),'build':str(build),'output':str(out),'observer_pid':os.getpid()}
def save():(run/'job.json').write_text(json.dumps(record,indent=2)+'\n')
save();(run/'runner.py').write_bytes(Path(__file__).read_bytes())
def failed(kind,error,traceback):
 record.update(state='OBSERVER_ERROR_CHILD_MAY_RUN' if child and child.poll() is None else 'TERMINAL_SETUP_FAIL',
  error=repr(error),elapsed_seconds=time.monotonic()-start);save();sys.__excepthook__(kind,error,traceback)
sys.excepthook=failed
identity={k:subprocess.check_output(cmd,text=True).strip() for k,cmd in (
 ('host',['uname','-a']),('compiler',['g++-14','--version']),('cuda',['/usr/local/cuda-13.3/bin/nvcc','--version']),
 ('gpu',['nvidia-smi','--query-gpu=name,driver_version,uuid,compute_cap','--format=csv,noheader']))}
assert 'RTX 4070' in identity['gpu'] and '8.9' in identity['gpu']
subprocess.run(['git','clone','--shared','--no-checkout','/mnt/c/public/project-hyle/hyle',str(source)],check=True)
subprocess.run(['git','-C',str(source),'checkout','--detach',snapshot['source_commit']],check=True)
assert not subprocess.check_output(['git','-C',str(source),'status','--porcelain'],text=True).strip()
numeric=source/'evidence/correctness/inference-g04-g05-cuda-ce20-sync-fixed-numeric-rebind/receipt.json'
assert hashlib.sha256(numeric.read_bytes()).hexdigest()==snapshot['numeric_receipt_sha256']
assert json.loads(numeric.read_text())['state']=='TERMINAL_PASS'
contract=source/'bench/inference_resident_sdpa/cuda_encoded_p1'
assert hashlib.sha256((contract/'contract.json').read_bytes()).hexdigest()==snapshot['contract_file_sha256']
env=os.environ.copy();env['PATH']='/usr/local/cuda-13.3/bin:'+env['PATH'];env['CMAKE_BUILD_PARALLEL_LEVEL']='2'
command=['python3',str(source/'scripts/hyle-perf.py'),'qualify-platform','--contract',str(contract/'contract.json'),
 '--source',str(contract),'--machine','W1-WSL','--peer',
 'original-flashinfer=/root/hyle-scratch/compute-unified/peers/flashinfer-69ff-git-1',
 '--build',str(build),'--output',str(out)]
with (run/'qualification.log').open('w') as stream:
 child=subprocess.Popen(command,env=env,stdout=stream,stderr=subprocess.STDOUT)
 record.update(state='RUNNING',pid=child.pid,identity=identity,command=command);save();print(json.dumps(record),flush=True);code=child.wait()
record['qualification_exit_code']=code
if (out/'manifest.json').is_file():
 t=time.monotonic()
 with (run/'verify.log').open('w') as stream:
  checked=subprocess.run(['python3',str(source/'scripts/hyle-perf.py'),'verify','--contract',str(contract/'contract.json'),
   '--manifest',str(out/'manifest.json')],env=env,stdout=stream,stderr=subprocess.STDOUT)
 record.update(verify_exit=checked.returncode,verify_elapsed_seconds=time.monotonic()-t)
else:record.update(verify_exit=None,verify_limit='No manifest; verify not run')
if out.exists():shutil.copytree(out,run/'output')
record.update(state='TERMINAL',exit_code=code,elapsed_seconds=time.monotonic()-start);save();print(json.dumps(record),flush=True)
raise SystemExit(code)
