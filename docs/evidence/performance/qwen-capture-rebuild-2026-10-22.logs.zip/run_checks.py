"""One focused root-run capture lifetime/error regression selection."""
from pathlib import Path
import importlib.util, os, sys, xml.etree.ElementTree as ET
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent;R=S.parents[1]
sp=importlib.util.spec_from_file_location('as_check_helpers',R/'.scratch/qwen-mtp-quality-20261022/run_quality.py')
h=importlib.util.module_from_spec(sp);sp.loader.exec_module(h)
image=h.read(S/'tests-link2/ready.json')['image'];assert h.ident(image['path'])==image
env=os.environ.copy();env['PATH']=h.read(S/'tests-link2/runtime-environment.json')['PATH']
out=S/'checks1';xml=out/'results.xml'
command=[image['path'],'--gtest_filter=GraphRegions.*Captur*:CudaDeviceStatus.*',
         '--gtest_output=xml:'+str(xml)]
process=h.execute(command,env,out,timeout=120)
assert process['exit']==0 and not process['timed_out'],process
root=ET.parse(xml).getroot()
assert int(root.attrib['tests'])>3 and int(root.attrib['failures'])==0
h.save(out/'summary.json',dict(status='PASS',process=process,image=image,
    tests=int(root.attrib['tests']),failures=int(root.attrib['failures']),
    disabled=int(root.attrib['disabled']),errors=int(root.attrib['errors']),
    skipped=sum(1 for x in root.iter('testcase') if x.find('skipped') is not None),
    cases=[x.attrib for x in root.iter('testcase')],native_cuda=True,
    scope='Focused capture binding/rebuild/failure/retirement; not full repository or model quality.'))
print('CHECKS',root.attrib,flush=True)
