"""Publish one completed finite rebuild batch; does not run tests/models."""
from pathlib import Path
import hashlib,json,re,zipfile
S=Path(__file__).resolve().parent;R=S.parents[1];W=S/'current-window'
AR=R/'.scratch/qwen-mtp-quality-20261022/current-window'
OUT=R/'docs/evidence/performance/qwen-capture-rebuild-2026-10-22.json';ZIP=OUT.with_suffix('.logs.zip')
def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def save(p,x):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def ident(p):
    p=p.resolve();raw=p.read_bytes()
    return dict(path=str(p.relative_to(R)),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
assert not OUT.exists()and not ZIP.exists()
t,m=read(W/'timing/summary.json'),read(W/'memory/summary.json');old=read(AR/'timing/summary.json')
checks=read(S/'checks1/summary.json');probe=read(S/'native-update-probe1/summary.json')
assert t['processes']==12 and m['processes']==4 and checks['tests']==21 and checks['skipped']==0
assert t['within_arm_fixed_work_valid']and m['within_arm_fixed_work_valid']
assert probe['counts']=={'updated':62}
names={'hyle_plain':'Hyle普通','hyle_mtp':'Hyle MTP K1','peer_plain':'llama.cpp普通','peer_mtp':'llama.cpp MTP K1'}
capture={}
for arm in ['hyle_plain','hyle_mtp']:
    rows=[]
    for x in read(W/'timing/runs.json'):
        if x['arm']!=arm:continue
        path=Path(x['folder'])/'stderr.log';log=path.read_text()
        rows.append(dict(source=ident(path),recorded=sum(map(int,re.findall(r'capture_recorded=(\d+)',log))),
            reused=sum(map(int,re.findall(r'capture_reused=(\d+)',log)))))
    capture[arm]=rows
save(S/'capture-observations.json',capture)
files=['include/hyle/compute/detail/command_capture.h','src/compute/command_capture.cc',
       'src/graph/plan_state.h','src/graph/executable.cc','src/compute_backend_cuda/cuda_backend.cc',
       'src/compute_backend_cuda/cuda_internal.h','tests/graph/region_provider_test.cc',
       'tests/compute_backend_cuda/device_status_test.cc']
for name in files:
    target=S/'final-source'/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes((R/name).read_bytes())
save(S/'final-source/identity.json',[ident(R/x)for x in files])
comparison={}
for arm in ['hyle_plain','hyle_mtp']:
    peer='peer_'+arm.split('_')[1]
    comparison[arm]=dict(
        versus_previous_AR_decode_percent=100*(t['groups'][arm]['full_decode_tokens_per_second']['median']/old['groups'][arm]['full_decode_tokens_per_second']['median']-1),
        versus_current_peer_percent={key:100*(t['groups'][arm][key]['median']/t['groups'][peer][key]['median']-1)
            for key in ['prefill_tokens_per_second','full_decode_tokens_per_second','session_output_tokens_per_second']})
selected=[]
for folder in ['current-window','checks1','screen1','screen2','native-update-probe1','cuda','review','trace-source','final-source','recipes']:
    selected += [p for p in (S/folder).rglob('*')if p.is_file()and p.suffix in ['.json','.py','.log','.xml','.diff','.cc','.h']]
selected += [p for p in S.glob('*.py')]+[S/'capture-observations.json']
for folder in [S/'compile1',S/'hyle-link2',S/'tests-link2',S/'trace-link1']:
    selected += [p for p in folder.rglob('*.json')if 'tmp'not in p.parts]
    selected += [p for p in folder.glob('*.log')]
with zipfile.ZipFile(ZIP,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9)as z:
    for p in sorted(set(selected)):
        z.write(p,p.relative_to(S).as_posix())
save(OUT,dict(status='FINITE_CAPTURE_REBUILD_FIX_VERIFIED_REGRESSION_PARTLY_RECOVERED',date='2026-10-22',
    conclusion='Single serial carrier exposes changing input/output state addresses. Preserve full binding identity checks and native retirement; recycle only a nonlaunchable idle executable and update it from a fresh capture. New state/status word, native/config/Queue invalidation and structural fallback remain strict.',
    regression=dict(before_single_carrier_plain_decode=90.95,before_single_carrier_MTP_decode=112.27,
        after_single_carrier_plain_decode=72.56649970996438,after_single_carrier_MTP_decode=96.89794,
        fully_recovered=False,all_cost_attributed=False),
    product_changes=read(S/'final-source/identity.json'),checks=checks,native_update_probe=probe,
    current_timing=t,current_independent_memory=m,comparison=comparison,capture=capture,
    initial_replay_screen=read(S/'screen1/summary.json'),
    previous_complete_window=ident(R/'docs/evidence/performance/qwen-mtp-current-carrier-2026-10-22.json'),
    archived_logs=ident(ZIP),
    build_scope=dict(host_TUs=19,SDK_builds=0,NVCC_builds=0,shader_builds=0,
        failed_initial_link='Cached batch_execution referenced old end signature; rebuilt it and replaced all five CUDA host objects. No compatibility symbol or ignored duplicate definitions.'),
    remaining=['Fresh per-step capture and provider binding preparation still remain; determine their actual costs before choosing another mechanism.',
        'Ordinary decode still below old90.95 and current peer95.84; MTP incremental acceleration does not close this shared-path regression.',
        'Other applicable model/quant MTP artifacts and overall architecture/function work remain active.'],
    limits=['Three timing processes per arm; descriptive medians/ranges, not a statistical significance or universal speed claim.',
        'Both Hyle arms preserve all64IDs, exported work and non-time decisions from the previous window. Cross-engine natural continuations differ.',
        'The logging-only native-update probe is excluded from timing/memory. It observed62 successful native updates for ordinary decode; do not extrapolate a measured update count to MTP.',
        'ReplayReport recorded means new capture, not new native executable instantiation. Counts63/0 and60/8 therefore remain unchanged.',
        'Sampled Windows PSAPI/PDH peaks are not exact physical allocation peaks; dedicated/shared separate peaks cannot be added.']))

def val(a,k):return t['groups'][a][k]['median']
def span(a,k):
    v=t['groups'][a][k];return f"{v['min']:.2f}～{v['max']:.2f}"
speed='\n'.join(f"| {n} | {val(a,'prefill_tokens_per_second'):.2f} | {val(a,'full_decode_tokens_per_second'):.2f} | {val(a,'session_output_tokens_per_second'):.2f} |"for a,n in names.items())
startup='\n'.join(f"| {n} | {span(a,'prefill_tokens_per_second')} | {span(a,'full_decode_tokens_per_second')} | {val(a,'weights_load_seconds'):.3f} | {val(a,'startup_to_ready_seconds'):.3f} | {val(a,'startup_to_endpoint_seconds'):.3f} |"for a,n in names.items())
mem=[]
for a,n in names.items():
    v=m['groups'][a]['sampled_peaks']
    mem.append(f"| {n} | {v['sampled_peak_gpu_dedicated_bytes']/2**30:.3f} | {v['sampled_peak_gpu_shared_bytes']/2**20:.2f} | {v['sampled_peak_gpu_total_bytes']/2**30:.3f} | {v['sampled_max_working_set_bytes']/2**30:.3f} | {v['sampled_max_private_commit_bytes']/2**30:.3f} |")
section=f'''## 最新完整性能对比

**2026-10-22，单槽CUDA捕获更新修复后的完整四臂窗口。** Qwen3.5-2B、RTX 4070、全CUDA、BF16权重；相同P154提示词，自然greedy输出64枚、C1024／N1／R1、前缀关闭、replay auto。每臂3个新进程交错测速，另各1个独立进程旁采内存。Hyle为本批增量构建，peer沿用上批固定镜像；历史窗口不合并。

| 当前模式 | prefill tok/s | 完整decode tok/s | 综合输出 tok/s |
| --- | ---: | ---: | ---: |
{speed}

普通版Hyle相对参考prefill +54.54%，decode -16.26%，综合 -11.11%；MTP分别 +54.93%／-18.50%／-10.61%。综合为64输出／（完整prefill＋decode），不含加载；本窗单轮，不冒充多轮或多人吞吐。

| 当前模式 | prefill范围 tok/s | decode范围 tok/s | 加载s | 入口至ready s | 入口至末输出s |
| --- | ---: | ---: | ---: | ---: | ---: |
{startup}

速度为3个独立进程比率的中位数并保留范围。decode计prefill后63枚新输出的完整host端点，包含准备／捕获／等待。加载边界依消费者实现；入口不含OS装载DLL，末输出不含销毁，不将其称为同一加载算法的胜负。

| 当前模式 | GPU dedicated峰 GiB | GPU shared峰 MiB | 同采样GPU总峰 GiB | CPU WS峰 GiB | CPU private commit峰 GiB |
| --- | ---: | ---: | ---: | ---: | ---: |
{chr(10).join(mem)}

内存是独立Windows PSAPI／PDH旁采观测峰，非精确物理分配。dedicated与shared分列峰不可直接相加，总峰只在同一有效采样点相加；WS／commit／GPU shared也非互斥量。请求间隔10ms，实际间隔、阶段样本、基线及空值完整保留；本批Hyle GPU采样峰与上批相同。

**可比边界：** 各臂3次输出ID、实际工作及非计时轮次决策均稳定，也与上批对应臂相同。跨引擎两对续文仍从第19枚起不同；Hyle中间BF16、末分数F32，peer原生算术／状态／draft prefill及接受工作量不同，报告自然性能，不称同token数学完全一致。

**回退尚未完全修复。** 单槽前普通／MTP decode为90.95／112.27，上批降至72.57／96.90；本批为80.26／103.84，相对上批 +10.61%／+7.17%，仍低于单槽前。普通record／reuse仍为63／0，MTP仍60／8：本批复用的是原生可执行分配，仍生成新capture，不能把record计数当instantiate次数。另一个仅诊断普通版进程实际观察到62次cudaGraphExecUpdate成功，64ID一致；带日志，不入TPS。21项Graph／CUDA检查全过，含新参数、旧失败Completion及结构回退。

下一步继续量化每步捕获、Provider绑定准备和状态地址轮换的成本；本批不恢复Model双Invocation、不放宽身份或退休门、不改变默认replay与精度。普通路径与MTP增量分开判断，不能把共用回退都算作MTP问题。

[本轮12次计时、4次内存旁采、21项检查、原生更新诊断及源码／命令](../evidence/performance/qwen-capture-rebuild-2026-10-22.json)。[修复前单槽窗口](../evidence/performance/qwen-mtp-current-carrier-2026-10-22.json)、[单槽前窗口](../evidence/performance/qwen-mtp-steady-profile-2026-10-22.json)保留各自口径，不混算。
'''
doc=R/'docs/developer/current-work.md';text=doc.read_text(encoding='utf-8')
previous=text[text.index('## 最新完整性能对比'):];(S/'current-work-performance.before.md').write_text(previous,encoding='utf-8')
text=text[:text.index('## 最新完整性能对比')]+section
changes={
    '**下一步先修当前单槽路径频繁Graph重录及decode回退，再继续适用制品接线。**':'**单槽捕获更新已修一部分，普通／MTP decode回到80.26／103.84，仍未恢复90.95／112.27；继续处理共用捕获／绑定成本，再继续适用制品接线。**',
    '**最近完整四臂对照见[页末](#最新完整性能对比)**：当前普通版Hyle／llama.cpp prefill为2239.10／1505.62tok/s，decode72.57／95.71；MTP为2320.19／1427.88、96.90／126.59。各3次中位数，独立内存旁采另列。prefill仍领先，当前decode回退且Graph重录明显增多，下一步先修该热点；两对续文从第19枚起不同，不称同token严格差距。':
    '**最近完整四臂对照见[页末](#最新完整性能对比)**：普通版Hyle／llama.cpp prefill为2411.98／1560.74tok/s，decode80.26／95.84；MTP为2228.18／1438.17、103.84／127.41。各3次中位数，独立内存旁采另列。捕获更新已恢复部分损失，仍须继续修普通共用路径；两对续文从第19枚起不同，不称同token严格差距。',
    '频繁重录及decode回退是下一待修问题，修后再复测。':'捕获更新已恢复部分速度，完整新窗见页末；每步捕获／绑定准备及剩余回退继续处理。',
    '当前四臂已重测，下一步修频繁重录；':'当前四臂已重测，捕获更新修复部分回退，每步捕获／绑定成本继续处理；'}
for a,b_ in changes.items():
    assert text.count(a)==1,(a,text.count(a));text=text.replace(a,b_)
doc.write_text(text,encoding='utf-8',newline='\n')
doc=R/'docs/developer/performance/decode.md';text=doc.read_text(encoding='utf-8')
start=text.index('**当前优先项（2026-10-22）');end=text.index('\n\n',start)
text=text[:start]+'''**当前优先项（2026-10-22）：继续修串行单槽后的共用decode回退。** 普通版原90.95tok/s在单槽后降至72.57，MTP112.27→96.90；状态输入／输出地址轮换使普通capture record／reuse从2／61变为63／0。单槽解决Vulkan资源占用，保留这一执行形状与完整身份／退休门。

本批[可执行捕获更新](../../evidence/performance/qwen-capture-rebuild-2026-10-22.json)已实现并经21项Graph／CUDA检查：真实退休后仅保留不可launch的原生分配，从新capture更新；新state／checked状态字独立，配置／native／Queue变化强制销毁，结构不兼容可重新实例化。独立普通版诊断观察62次原生update成功。新完整四臂中普通80.26对95.84，MTP103.84对127.41；相对修复前回升10.61%／7.17%，**尚未恢复原速度**，GPU采样峰与上批相同。record63／0与60／8仍计新capture，不代表新instantiate次数。

下一步先量化每步新capture、Provider绑定准备与状态地址轮换的实际成本，按普通基线和MTP增量分别归因；之后再回到普通小行数投影的冷算法选择。原稳态矩阵投影占累计kernel时长92.466%，两个单行批次替代两行矩阵的候选已拒绝，不能用这个旧GPU占比解释新增host开销。最新prefill、decode、启动、空间和完整边界统一见[当前工作末表](../current-work.md#最新完整性能对比)。'''+text[end:]
doc.write_text(text,encoding='utf-8',newline='\n')
save(S/'publication-receipt.json',dict(evidence=ident(OUT),logs=ident(ZIP),updated=[ident(doc),ident(R/'docs/developer/current-work.md')]))
print('PUBLISHED',ident(OUT),ident(ZIP))
