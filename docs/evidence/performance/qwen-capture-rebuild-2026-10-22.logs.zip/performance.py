"""Root-only fixed four-arm timing and independent memory window after rebuild."""
from pathlib import Path
import argparse,importlib.util,sys
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent;R=S.parents[1];AR=R/'.scratch/qwen-mtp-quality-20261022';W=S/'current-window'
sp=importlib.util.spec_from_file_location('as_current_window',AR/'current-window/performance.py')
h=importlib.util.module_from_spec(sp);sp.loader.exec_module(h)
h.S=W
base=h.base

def setup():
    W.mkdir(exist_ok=True)
    config=base.read(AR/'current-window/arms.json')
    for kind,folder in [('hyle',S/'hyle-link2'),('peer',AR/'peer-link1')]:
        wrapper=base.read(AR/'current-window'/f'{kind}-ready.json')
        wrapper.update(image=base.read(folder/'ready.json')['image'],
            runtime_environment=base.identity(folder/'runtime-environment.json'),
            original_ready=base.identity(folder/'ready.json'),
            link_plan=base.identity(folder/'link-plan.json'))
        wrapper['note']='AS current product capture-rebuild image' if kind=='hyle' else 'Unchanged AR peer host/core'
        base.save(W/f'{kind}-ready.json',wrapper)
        for arm in base.ARMS:
            if arm.startswith(kind):config['arms'][arm]['ready']=str(W/f'{kind}-ready.json')
    config['note']='Fixed original P154/64, C1024 N1R1, replay auto; AS Hyle rebuild, unchanged AR peer. No pooling.'
    base.save(W/'arms.json',config)

def plan(config,mode,output):
    h.owned_output(output)
    result=h.original_plan(config,mode,output)
    for row in result['commands']:
        folder=S/'hyle-link2'if row['arm'].startswith('hyle')else AR/'peer-link1'
        assert row['image']==base.read(folder/'ready.json')['image']
    result.update(script=base.identity(Path(__file__)),
        retained_AR_window=base.identity(AR/'current-window/performance.py'),
        current_Hyle_score_policy='bf16_inputs_f32_output',
        former_windows_pooled=False,same_token_cross_arm_speed_claim=False)
    return result

def analyze(output):
    result=h.analyze(output)
    result['limits']=[x.replace('current AR image/F32-score policy','current AS image/F32-score policy')
        .replace('Current Hyle plain/MTP is a new four-arm window.','AS Hyle plain/MTP is a new four-arm window.') for x in result['limits']]
    reference=base.read(AR/'current-window/timing/runs.json');runs=base.read(Path(output)/'runs.json')
    same={}
    for arm in base.ARMS:
        old=next(x for x in reference if x['arm']==arm)['observation']
        rows=[x['observation']for x in runs if x['arm']==arm]
        same[arm]=dict(IDs=all(x['generated_ids']==old['generated_ids']for x in rows),
            work=all(x['work']==old['work']for x in rows),
            non_time_decisions=all(h.decision_work(x['raw'].get('rounds'))==h.decision_work(old['raw'].get('rounds'))for x in rows))
    result['previous_AR_work_preserved_by_arm']=same
    base.save(Path(output)/'summary.json',result)
    assert all(all(x.values())for x in same.values()),same
    return result

base.plan=plan;base.analyze=analyze
if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('action',choices=['setup','run']);a=p.parse_args()
    if a.action=='setup':setup()
    else:
        for mode in ['timing','memory']:
            result=base.run(W/'arms.json',mode,W/mode)
            print('COMPLETE',mode,result['processes'],result['within_arm_fixed_work_valid'],flush=True)
