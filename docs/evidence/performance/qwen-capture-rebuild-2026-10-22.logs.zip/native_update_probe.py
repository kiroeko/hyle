"""Root-only diagnostic build and one model run; never a TPS sample."""
from pathlib import Path
import importlib.util,os,json,re,sys
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent;R=S.parents[1]
sp=importlib.util.spec_from_file_location('as_probe_build',S/'build.py')
m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m);b,c,h=m.b,m.c,m.h
h.RECIPES['backend-trace']=m.recipe('backend')
h.SOURCES['backend-trace']=S/'trace-source/src/compute_backend_cuda/cuda_backend.cc'
h.compile_one('backend-trace',1)
rec=c.read(S/'compile1/backend-trace/identity.json');old=c.read(S/'compile1/backend/identity.json')['object']
base_dir=S/'hyle-link2';base=c.read(base_dir/'link-plan.json')
inputs=[rec['object']if c.key(x['path'])==c.key(old['path'])else x for x in base['inputs']]
assert all(b.identity(x['path'])==x for x in inputs)
out=S/'trace-link1';out.mkdir();(out/'tmp').mkdir();image=out/'qwen.exe'
command=[rec['object']['path']if c.key(x)==c.key(old['path'])else x for x in base['command']
    if not x.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:'))]
command+=['/OUT:'+str(image),'/MAP:'+str(image.with_suffix('.map')),'/IMPLIB:'+str(image.with_suffix('.lib'))]
c.save(out/'link-plan.json',dict(command=command,inputs=inputs,diagnostic_only=True))
env,_=b.environment(command,[x['path']for x in inputs],out);c.execute('link',command,env,out)
runtime=c.read(base_dir/'runtime-environment.json')
for x in runtime['staged_dlls']:os.link(x['path'],out/Path(x['path']).name)
c.save(out/'runtime-environment.json',runtime)
sp=importlib.util.spec_from_file_location('as_probe_run',R/'.scratch/qwen-mtp-quality-20261022/run_quality.py')
q=importlib.util.module_from_spec(sp);sp.loader.exec_module(q)
env=os.environ.copy();env['PATH']=runtime['PATH']
command=[str(image),'--inputs',str(q.V/'inputs/text'),'--steps','64','--capacity','1024',
    '--max-sessions','1','--active-sequences','1','--prefix-cache','off','--progress','direct','--replay','auto','--mtp','off']
folder=S/'native-update-probe1';process=q.execute(command,env,folder,timeout=120)
assert process['exit']==0 and not process['timed_out'],process
raw=json.loads((folder/'stdout.log').read_text().strip().splitlines()[-1]);q.save(folder/'parsed.json',raw)
old=next(x for x in q.read(S/'current-window/timing/runs.json')if x['arm']=='hyle_plain')['observation']['raw']
assert raw['generated_ids']==old['generated_ids']
log=(folder/'stderr.log').read_text();events=re.findall(r'hyle.cuda.capture_update seed=eligible native=(-?\d+) result=(-?\d+) outcome=(\w+)',log)
assert events, 'No native seed update observed'
q.save(folder/'summary.json',dict(status='COMPLETE',process=process,image=q.ident(image),
    events=[dict(native=int(a),result=int(b_),outcome=o)for a,b_,o in events],
    counts={o:sum(x[2]==o for x in events)for o in sorted({x[2]for x in events})},
    generated_IDs_equal_current=True,throughput_evidence=False,memory_evidence=False,
    limit='Logging changes host timing; this run only observes actual update calls and success/fallback.'))
print('NATIVE UPDATE EVENTS',len(events),{o:sum(x[2]==o for x in events)for o in sorted({x[2]for x in events})},flush=True)
