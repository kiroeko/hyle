"""Root-only fixed four-process replay screen; no performance acceptance claim."""
from pathlib import Path
import importlib.util,json,os,re,sys
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent;R=S.parents[1]
AR=R/'.scratch/qwen-mtp-quality-20261022'
spec=importlib.util.spec_from_file_location('capture_screen_helpers',AR/'run_quality.py')
h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
image=h.read(AR/'hyle-link1/ready.json')['image'];assert h.ident(image['path'])==image
env=os.environ.copy();env['PATH']=h.read(AR/'hyle-link1/runtime-environment.json')['PATH']
reference=h.read(AR/'current-window/timing/runs.json')
records=[]
for index,(mtp,replay)in enumerate([(False,'auto'),(False,'commands'),(True,'commands'),(True,'auto')],1):
    name=('mtp'if mtp else'plain')+'-'+replay;folder=S/'screen1'/f'{index:02d}-{name}'
    inputs=h.V/'inputs'/('mtp'if mtp else'text')
    command=[image['path'],'--inputs',str(inputs),'--steps','64','--capacity','1024',
        '--max-sessions','1','--active-sequences','1','--prefix-cache','off','--progress','direct',
        '--replay',replay,'--mtp','on'if mtp else'off']
    print('START',name,flush=True)
    process=h.execute(command,env,folder,timeout=120)
    assert process['exit']==0 and not process['timed_out'],process
    raw=json.loads((folder/'stdout.log').read_text().strip().splitlines()[-1]);h.save(folder/'parsed.json',raw)
    old=next(x for x in reference if x['arm']==('hyle_mtp'if mtp else'hyle_plain'))['observation']['raw']
    assert raw['generated_ids']==old['generated_ids']
    log=(folder/'stderr.log').read_text()
    row=dict(name=name,process=process,image=image,generated_IDs_equal_current_four_arm=True,
        generated_ids=raw['generated_ids'],prefill_seconds=raw['prefill_seconds'],decode_seconds=raw['decode_seconds'],
        full_decode_tokens_per_second=63/raw['decode_seconds'],
        session_output_tokens_per_second=64/raw['session_seconds'],
        capture_recorded=sum(map(int,re.findall(r'capture_recorded=(\d+)',log))),
        capture_reused=sum(map(int,re.findall(r'capture_reused=(\d+)',log))))
    records.append(row);h.save(folder/'observation.json',row)
    print('DONE',name,row['full_decode_tokens_per_second'],row['capture_recorded'],row['capture_reused'],flush=True)
h.save(S/'screen1/summary.json',dict(status='FOUR_PROCESS_CURRENT_IMAGE_REPLAY_SCREEN_COMPLETE',
    records=records,processes=4,builds=0,precision_changes=False,mathematical_changes=False,
    limits=['One sample per mode is a bounded mechanism screen, not a final timing/memory window.',
      'Direct commands and captured execution can overlap host/device differently; the difference is not pure instantiate self-time.',
      'No default replay policy changed and no native graph update implementation is selected by this screen alone.']))
