"""Root-only incremental host rebuild. Reuses the current AR link closure."""
from pathlib import Path
import argparse, importlib.util, os, sys
sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
R = S.parents[1]
AR = R/'.scratch/qwen-mtp-quality-20261022'
spec = importlib.util.spec_from_file_location('as_cached', AR/'build.py')
m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
b, c, h = m.b, m.c, m.h
h.S = S
BASE = AR/'hyle-link1'
GRAPH = ['input_sources', 'resource_report', 'constant_artifact', 'resources',
         'region_access', 'submission', 'lease_submission', 'executable']
SOURCES = {x: R/f'src/graph/{x}.cc' for x in GRAPH}
SOURCES.update({'progress': R/'src/graph_progress/progress.cc',
                'capture': R/'src/compute/command_capture.cc',
                'batch-execution': R/'src/compute_batch/batch_execution.cc',
                'device': R/'src/compute/device.cc'})
SOURCES.update({x: R/f'src/compute_backend_cuda/cuda_{x}.cc'
                for x in ['backend', 'device_status', 'memory', 'batch_transfer', 'paged_append']})
SOURCES.update({'graph-test': R/'tests/graph/region_provider_test.cc',
                'cuda-test': R/'tests/compute_backend_cuda/device_status_test.cc'})
INDEX = {'input_sources':72, 'resource_report':73, 'progress':74,
         'resources':76, 'executable':80, 'constant_artifact':81,
         'submission':82, 'region_access':83, 'lease_submission':94,
         'capture':97, 'device':90, 'backend':149, 'device_status':150,
         'memory':70, 'batch_transfer':71, 'paged_append':193, 'batch-execution':86}

def recipe(tag):
    path = S/'recipes'/f'{tag}.json'
    if path.exists(): return path
    template = (R/'.scratch/qwen-native-protocol-20261022/compile1/region-test/plan.json'
                if tag == 'graph-test' else
                R/'.scratch/paged-capture-20261021/cuda/checks1/backend/identity.json'
                if tag in ['backend','device_status','memory','batch_transfer','paged_append']
                else AR/'compile1/hyle/identity.json')
    record = c.read(template)
    record['command'] += ['/I'+str(R/'src/graph'), '/I'+str(R/'src/compute_backend_cuda')]
    c.save(path, record)
    return path

def compile_one(tag, attempt):
    h.RECIPES[tag] = recipe(tag); h.SOURCES[tag] = SOURCES[tag]
    h.compile_one(tag, attempt)

def link(attempt, link_attempt):
    base = c.read(BASE/'link-plan.json')
    replacements = {}; records = []
    # Five CUDA host TUs include cuda_internal.h. Only backend/status were
    # explicit objects in the prior closure; the other three override archive
    # members without recompiling any CUDA kernels.
    additions = []
    for tag in SOURCES:
        if tag.endswith('-test'): continue
        p = S/f'compile{attempt}'/tag/'identity.json'; rec = c.read(p)
        assert all(b.identity(x['path']) == x for x in [rec['source'],rec['object'],*rec['dependencies']])
        records.append(b.identity(p))
        if tag in INDEX:
            replacements[c.key(base['inputs'][INDEX[tag]]['path'])] = rec['object']
        else:
            additions.append(rec['object'])
    inputs = additions + [replacements.get(c.key(x['path']),x) for x in base['inputs']]
    assert all(b.identity(x['path']) == x for x in inputs)
    command = [replacements.get(c.key(x),{}).get('path',x) for x in base['command']
               if not x.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:'))]
    command[1:1] = [x['path'] for x in additions]
    out = S/f'hyle-link{link_attempt}'; out.mkdir(); (out/'tmp').mkdir()
    image = out/'qwen.exe'
    command += ['/OUT:'+str(image), '/MAP:'+str(image.with_suffix('.map')), '/IMPLIB:'+str(image.with_suffix('.lib'))]
    c.save(out/'link-plan.json',dict(command=command,inputs=inputs,compiled_records=records,
        base=b.identity(BASE/'link-plan.json'),SDK_builds=0,NVCC=0,shaders=0))
    env,_ = b.environment(command,[x['path'] for x in inputs],out)
    c.execute('link',command,env,out)
    runtime = c.read(BASE/'runtime-environment.json')
    for x in runtime.get('staged_dlls',[]):
        assert b.identity(x['path']) == x
        os.link(x['path'],out/Path(x['path']).name)
    runtime['staged_dlls'] = [b.identity(x) for x in out.glob('*.dll')]
    c.save(out/'runtime-environment.json',runtime)
    c.save(out/'ready.json',dict(image=b.identity(image),link_plan=b.identity(out/'link-plan.json')))
    print('LINKED',image,flush=True)

def link_tests(attempt, link_attempt):
    base_dir=S/f'hyle-link{link_attempt}'; base=c.read(base_dir/'link-plan.json')
    records=[c.read(S/f'compile{attempt}'/tag/'identity.json') for tag in ['graph-test','cuda-test']]
    for rec in records:
        assert all(b.identity(x['path'])==x for x in [rec['source'],rec['object'],*rec['dependencies']])
    retained=R/'.scratch/build-compute-v2-dev'
    kernel=R/'.scratch/architecture-refactor-2026-10-18/d4-windows-preparation-2026-10-21/first-decode-startup-2026-10-21/native-fix/tests/attempt1/kernel/cuda-test-kernel.obj'
    extra=[x['object'] for x in records]+[b.identity(kernel)]+[b.identity(retained/x) for x in [
        'lib/gtest_main.lib','lib/gtest.lib']]
    removed=c.key(c.read(AR/'compile1/hyle/identity.json')['object']['path'])
    inputs=extra+[x for x in base['inputs'] if c.key(x['path'])!=removed]
    assert all(b.identity(x['path'])==x for x in inputs)
    command=[x for x in base['command'] if c.key(x)!=removed
             and not x.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:'))]
    command[1:1]=[x['path'] for x in extra]
    out=S/f'tests-link{link_attempt}';out.mkdir();(out/'tmp').mkdir();image=out/'capture-tests.exe'
    command+=['/OUT:'+str(image),'/MAP:'+str(image.with_suffix('.map')),'/IMPLIB:'+str(image.with_suffix('.lib'))]
    c.save(out/'link-plan.json',dict(command=command,inputs=inputs,
        current_base=b.identity(base_dir/'link-plan.json'),SDK_builds=0,NVCC=0,shaders=0))
    env,_=b.environment(command,[x['path'] for x in inputs],out);c.execute('link',command,env,out)
    runtime=c.read(base_dir/'runtime-environment.json')
    for x in runtime['staged_dlls']:os.link(x['path'],out/Path(x['path']).name)
    c.save(out/'runtime-environment.json',runtime)
    c.save(out/'ready.json',dict(image=b.identity(image)))
    print('LINKED tests',flush=True)

if __name__ == '__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('tags',nargs='+',choices=[*SOURCES,'link','link-tests','core'])
    p.add_argument('--attempt',type=int,default=1)
    p.add_argument('--link-attempt',type=int,default=1)
    a=p.parse_args(); (S/'recipes').mkdir(exist_ok=True)
    for tag in a.tags:
        if tag=='link': link(a.attempt,a.link_attempt)
        elif tag=='link-tests': link_tests(a.attempt,a.link_attempt)
        elif tag=='core':
            for x in SOURCES:
                if not x.endswith('-test'): compile_one(x,a.attempt)
        else: compile_one(tag,a.attempt)
