"""Audit finite evidence and append the already-executed cleanup receipt."""
from pathlib import Path
import hashlib,json,zipfile
S=Path(__file__).resolve().parent;R=S.parents[1]
out=R/'docs/evidence/performance/qwen-capture-rebuild-2026-10-22.json';archive=out.with_suffix('.logs.zip')
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def ident(p):return dict(path=str(p.relative_to(R)),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
record=read(out);cleanup=read(S/'cleanup-result.json')
assert cleanup['Bytes']==282518016
assert all(not Path(x['Path']).exists()for x in cleanup['Removed'])
assert (S/'hyle-link2/qwen.exe').is_file()
for x in record['product_changes']:
    assert ident(R/x['path'])==x
for mode in ['timing','memory']:
    v=read(S/'current-window'/mode/'summary.json')
    assert v['within_arm_fixed_work_valid']and all(all(x.values())for x in v['previous_AR_work_preserved_by_arm'].values())
with zipfile.ZipFile(archive,'a',compression=zipfile.ZIP_DEFLATED,compresslevel=9)as z:
    for p in [R/'test.ps1',S/'cleanup-plan.json',S/'cleanup-result.json',S/'prepare_cleanup.py',Path(__file__)]:
        z.write(p,'cleanup/'+p.name)
with zipfile.ZipFile(archive)as z:assert z.testzip()is None
record['cleanup']=dict(bytes_removed=cleanup['Bytes'],disposable_images=cleanup['Removed'],current_product_image_retained=True)
record['build_scope']['diagnostic_host_TUs']=1
record['archived_logs']=ident(archive)
out.write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
receipt=dict(evidence=ident(out),logs=ident(archive),checks='JSON, source identities, preserved arm work, ZIP CRC, exact cleanup, git diff --check',
    current_image=ident(S/'hyle-link2/qwen.exe'),goal_complete=False)
(S/'final-receipt.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print('AUDIT COMPLETE',receipt['evidence'],receipt['logs'])
