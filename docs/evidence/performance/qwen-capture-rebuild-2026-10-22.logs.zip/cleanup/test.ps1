$ErrorActionPreference = 'Stop'
$taskPrefix = 'C:\public\project-hyle\hyle\.scratch\qwen-capture-reuse-20261022\'
$taskFiles = @(
  @{ Path = 'C:\public\project-hyle\hyle\.scratch\qwen-capture-reuse-20261022\tests-link2\capture-tests.exe'; Bytes = 142118400; Sha256 = '2326ef465cb2379e9953e6dd4bf0f9bb466de7238e90df8de5ed8134c6af8917' }
  @{ Path = 'C:\public\project-hyle\hyle\.scratch\qwen-capture-reuse-20261022\trace-link1\qwen.exe'; Bytes = 140399616; Sha256 = '9f3f41c6c8b55d1ba8c7c826589c9bf273f2d975b57aaca2cb5508afdde459a5' }
)
foreach ($taskFile in $taskFiles) {
  $taskResolved = (Resolve-Path -LiteralPath $taskFile.Path).Path
  if (-not $taskResolved.StartsWith($taskPrefix, [StringComparison]::OrdinalIgnoreCase)) { throw 'Cleanup outside exact AS workspace' }
  $taskInfo = Get-Item -LiteralPath $taskResolved
  if ($taskInfo.PSIsContainer -or $taskInfo.Length -ne $taskFile.Bytes) { throw 'Cleanup target changed' }
  if ((Get-FileHash -LiteralPath $taskResolved -Algorithm SHA256).Hash -ne $taskFile.Sha256) { throw 'Cleanup hash changed' }
}
$taskRemoved = @()
foreach ($taskFile in $taskFiles) {
  Remove-Item -LiteralPath $taskFile.Path -Force
  $taskRemoved += $taskFile
}
[PSCustomObject]@{ Removed = $taskRemoved; Bytes = ($taskRemoved | Measure-Object -Property Bytes -Sum).Sum } | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath 'C:\public\project-hyle\hyle\.scratch\qwen-capture-reuse-20261022\cleanup-result.json' -Encoding utf8
