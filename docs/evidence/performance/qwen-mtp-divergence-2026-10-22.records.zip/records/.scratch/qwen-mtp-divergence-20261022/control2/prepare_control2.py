"""Prepare two bounded follow-ups in a new TU; never build/run native code."""
from pathlib import Path
import difflib
import hashlib
import json

HERE = Path(__file__).resolve().parent
W = HERE.parent
BASE = W / 'control/control_peer.cc'
EXPECTED = '8349fc089d1012d3d4cfe18f33d7ad3b17f048e311ec84c81d5054c86d20a555'


def once(source, old, new):
    assert source.count(old) == 1, old
    return source.replace(old, new)


def main():
    raw = BASE.read_bytes()
    assert hashlib.sha256(raw).hexdigest() == EXPECTED
    before = HERE / 'before/control_peer.cc'
    before.parent.mkdir(parents=True, exist_ok=True)
    assert not before.exists() and not (HERE / 'control_peer.cc').exists()
    before.write_bytes(raw)
    source = raw.decode()
    anchor = '    auto b_165 = save_partial(context, diagnostic, "B165_after_trim", base + 1);'
    source = once(source, anchor, anchor + r'''
    // Exporting NONE observes the same logical B165 as PARTIAL_ONLY and does
    // not materialize pending rs_idx. The original live branch remains below.
    const auto b165_full = state_bytes(context, LLAMA_STATE_SEQ_FLAGS_NONE);
    Diagnostic::binary(diagnostic.directory / "B165.full-state.bin", b165_full.data(), b165_full.size());''')
    anchor = '    auto b_166 = save_partial(context, diagnostic, "B166", base + 2);'
    extension = r'''

    // Narrow control1: start from the exact serialized logical B165. Only this
    // separate continuation is canonicalized; the original B above was live.
    require(llama_state_seq_set_data_ext(context, b165_full.data(), b165_full.size(), 0,
                LLAMA_STATE_SEQ_FLAGS_NONE) == b165_full.size(),
            "B165 canonical restore consumed wrong byte count");
    position(context, base + 1);
    auto b_canonical_next = control_decode(context, sampler, batch, diagnostic, "B_canonical_T1_51338", Tokens{51338},
                                          continued_prefix, base + 1, width, vocabulary);
    auto b_canonical_166 = save_partial(context, diagnostic, "B166_canonical", base + 2);

    // Narrow control2: replay the actual original target partitions to C171.
    // This is fixed-token state diagnosis, not new speculative generation.
    restore();
    Tokens replay_prefix = prefix;
    Json replay = Json::array();
    const auto replay_step = [&](const std::string & name, const Tokens & inputs,
                                 const Tokens & expected_ids, std::size_t committed) {
        const auto first = replay_prefix.size();
        auto output = control_decode(context, sampler, batch, diagnostic, name, inputs, replay_prefix,
                                     first, width, vocabulary);
        require(committed > 0 && committed <= inputs.size(), "invalid fixed replay commit");
        trim(context, first + committed);
        replay_prefix.insert(replay_prefix.end(), inputs.begin(), inputs.begin() + static_cast<std::ptrdiff_t>(committed));
        output.observation["selected_rows"] = committed;
        output.observation["after_trim"] = replay_prefix.size();
        output.observation["expected_original_ids"] = expected_ids;
        output.observation["ids_match_original"] = output.ids == expected_ids;
        output.observation["committed_prefix_ids"] = replay_prefix;
        replay.push_back(std::move(output.observation));
    };
    replay_step("R5_T2_11_36760", Tokens{11,36760}, Tokens{51338,11}, 1);
    replay_step("R6_T2_51338_11", Tokens{51338,11}, Tokens{11,36760}, 2);
    replay_step("R7_T2_36760_11", Tokens{36760,11}, Tokens{11,1697}, 2);
    replay_step("R8_T2_1697_11", Tokens{1697,11}, Tokens{11,11906}, 2);
    require(replay_prefix.size() == 171, "C171 replay committed length mismatch");
    position(context, replay_prefix.size());
    const auto c171_full = state_bytes(context, LLAMA_STATE_SEQ_FLAGS_NONE);
    Diagnostic::binary(diagnostic.directory / "C171.full-state.bin", c171_full.data(), c171_full.size());
    const auto restore171 = [&]() {
        require(llama_state_seq_set_data_ext(context, c171_full.data(), c171_full.size(), 0,
                    LLAMA_STATE_SEQ_FLAGS_NONE) == c171_full.size(),
                "C171 restore consumed wrong byte count");
        position(context, replay_prefix.size());
    };
    restore171();
    auto c171_t1 = control_decode(context, sampler, batch, diagnostic, "C171_T1_11906", Tokens{11906},
                                 replay_prefix, 171, width, vocabulary);
    restore171();
    auto c171_t2 = control_decode(context, sampler, batch, diagnostic, "C171_T2_11906_271", Tokens{11906,271},
                                 replay_prefix, 171, width, vocabulary);
'''
    source = once(source, anchor, anchor + extension)
    anchor = '        {"diagnostic", diagnostic.summary()}, {"native_target_contexts", 1}, {"shared_model_objects", 1},'
    new = r'''        {"B_same_logical165_canonical", {
            {"checkpoint", {{"file", "B165.full-state.bin"}, {"bytes", b165_full.size()},
                {"flags", LLAMA_STATE_SEQ_FLAGS_NONE}, {"logical_length", base + 1}}},
            {"restore_boundary165", true}, {"next", b_canonical_next.observation}, {"logical166", b_canonical_166},
            {"comparison_contract", "Compare against original B.next/B.logical166; same logical B165 source, T1 input and RS1 context. Only this branch restores before continuation."}}},
        {"C171_shape_control", {{"replay", replay}, {"checkpoint_prefix_ids", replay_prefix},
            {"checkpoint", {{"file", "C171.full-state.bin"}, {"bytes", c171_full.size()},
                {"flags", LLAMA_STATE_SEQ_FLAGS_NONE}, {"logical_length", 171}}},
            {"T1", c171_t1.observation}, {"T2", c171_t2.observation},
            {"comparison_contract", "Both restore exactly the same C171; compare T1 row0 vs T2 row0 on prefix+11906. T2 row1 appends271. Raw T2 rows must be checked against original round9, not presumed faithful from IDs."}}},
        {"diagnostic", diagnostic.summary()}, {"native_target_contexts", 1}, {"shared_model_objects", 1},'''
    source = once(source, anchor, new)
    source = once(source, 'Two full-C restores normalize both initial branches; B pending restore path remains uninterrupted after trim.',
                  'Initial A/B restores normalize both C164 branches; original B pending path remains uninterrupted after trim. The extra canonical B165 continuation and C171 T-shape controls are separate finite diagnostics, not acceptance/performance evidence.')
    (HERE / 'control_peer.cc').write_text(source, encoding='utf-8', newline='\n')
    (HERE / 'control.diff').write_text(''.join(difflib.unified_diff(raw.decode().splitlines(True), source.splitlines(True), fromfile='W/control/control_peer.cc', tofile='W/control2/control_peer.cc')), encoding='utf-8')
    print(json.dumps(dict(source=str(HERE / 'control_peer.cc'), bytes=len(source.encode()), sha256=hashlib.sha256(source.encode()).hexdigest())))


if __name__ == '__main__':
    main()
