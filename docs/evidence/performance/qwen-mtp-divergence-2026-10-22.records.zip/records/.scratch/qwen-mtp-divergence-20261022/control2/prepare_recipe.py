"""Emit the original one-TU native recipe for the finite second control."""
from pathlib import Path
import ast
import hashlib
import json

HERE = Path(__file__).resolve().parent
W = HERE.parent
ROOT = W.parents[1]
OLD = W / 'control'
CACHE = ROOT / '.scratch/architecture-refactor-2026-10-18/llama-matched-consumer'


def identity(path):
    raw = path.read_bytes()
    return dict(path=str(path), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


def save(path, data):
    assert not path.exists(), path
    path.write_text(json.dumps(data, indent=2) + '\n', encoding='utf-8')


def main():
    original = json.loads((OLD / 'build-plan.json').read_text())
    plan = dict(original)
    plan['status'] = 'Frozen finite controls2 source only; no CXX/native/GPU by author.'
    plan['source'] = identity(HERE / 'control_peer.cc')
    plan['output_directory'] = str(HERE / 'checks/attempt1')
    for key in ['compile', 'link']:
        plan[key] = [item.replace(str(OLD), str(HERE)) for item in original[key]]
    plan['baseline_plan'] = identity(OLD / 'build-plan.json')
    plan['baseline_source'] = identity(HERE / 'before/control_peer.cc')
    save(HERE / 'build-plan.json', plan)
    text = (W / 'build_control.py').read_text()
    assert text.count("U/'control/build-plan.json'") == 1
    text = text.replace("U/'control/build-plan.json'", "U/'control2/build-plan.json'")
    text = text.replace("U/f'control-ready-{out.name}.json'", "U/f'control2-ready-{out.name}.json'")
    text = text.replace('READY one-context RS1 control peer', 'READY finite one-context RS1 control2 peer')
    builder = W / 'build_control2.py'
    assert not builder.exists()
    builder.write_text(text, encoding='utf-8')
    for path in [HERE / 'prepare_control2.py', HERE / 'prepare_recipe.py', builder]:
        ast.parse(path.read_text())
    output = W / 'control2-run1'
    save(HERE / 'run-plan.json', dict(unrun=True, diagnostic_not_performance=True,
        command=[str(HERE / 'checks/attempt1/peer.exe'), '--model', str(CACHE / 'Qwen3.5-2B-text-MTP-BF16.gguf'),
            '--inputs', str(ROOT / '.scratch/qwen-mtp-window-20261022/inputs'), '--steps', '64', '--capacity', '1024',
            '--max-rounds', '10', '--mtp', 'on', '--memory-snapshots', 'off',
            '--diagnostic-dir', str(output / 'diagnostic'), '--output', str(output / 'consumer-result.json')],
        preserved='Original control1 A/B raw names and operations unchanged; only read-only full B165 export added before original live B continuation.',
        narrow_extensions=[
            'After original B166, restore exact B165 full state and execute same T1[51338]; save B166_canonical PARTIAL_ONLY, logits and hidden.',
            'Restore original C164; original fixed target partitions R5T2 trim165, R6T2 trim167, R7T2 trim169, R8T2 trim171. Save C171 full, then restore twice for T1[11906] / T2[11906,271]. No extra recurrent171 exports.'],
        mandatory_faithfulness_checks=['Original control1 A/B payloads unchanged',
            'Replayed R5 T2 rows match original peer-on round5 raw',
            'C171 T2 rows match original peer-on round9 raw; matching IDs alone is insufficient'],
        no_new_context_model_or_native_library=True))
    source = (HERE / 'control_peer.cc').read_text()
    before = (HERE / 'before/control_peer.cc').read_text()
    a_start = '    restore();\n    auto a_first ='
    a_end = '    auto b_165 = save_partial(context, diagnostic, "B165_after_trim", base + 1);'
    assert source[source.index(a_start):source.index(a_end) + len(a_end)] == before[before.index(a_start):before.index(a_end) + len(a_end)]
    b_start = '    // Critical witness: no set_data/clear/context rebuild occurs between the'
    b_end = '    auto b_166 = save_partial(context, diagnostic, "B166", base + 2);'
    assert source[source.index(b_start):source.index(b_end) + len(b_end)] == before[before.index(b_start):before.index(b_end) + len(b_end)]
    live_start = source.index('    trim(context, base + 1);')
    live_end = source.index(b_end, live_start)
    assert 'set_data_ext(' not in source[live_start:live_end] and 'restore();' not in source[live_start:live_end]
    assert source.count('restore();') == 3 and source.count('restore171();') == 2
    assert source.count('llama_state_seq_set_data_ext(') == 3
    for key in ['compile', 'link']:
        assert plan[key] == [item.replace(str(OLD), str(HERE)) for item in original[key]]
    save(HERE / 'source-freeze.json', dict(status='Frozen; pure-host AST/invariants/recipe checked. Uncompiled/unrun by author.',
        source=identity(HERE / 'control_peer.cc'), baseline_source=identity(HERE / 'before/control_peer.cc'),
        files=[identity(path) for path in [HERE / 'control.diff', HERE / 'prepare_control2.py', HERE / 'prepare_recipe.py',
                                         HERE / 'build-plan.json', HERE / 'run-plan.json', builder]],
        fixed_source_headers=original['header_identities'],
        original_runtime_reference=identity(W / 'control-run1/consumer-result.json'),
        original_diagnostic_reference=identity(W / 'peer-on-run1/consumer-result.json'),
        invariants=['Original A/B operations and names retained verbatim; extra B165 full get never sets/normalizes before live continuation.',
                    'One model and one original RS1 target context; no dtype, context, sampler, native capture or mathematical kernel changes.',
                    'B165 canonical continuation and C171 shape comparison are separate finite controls, not a new acceptance/performance experiment.',
                    'C171 replay follows original target input chunks and checked trim boundaries; exact raw faithfulness remains runtime evidence to verify.'],
        runtime_unverified=['Original control1 payload equality', 'Full B165 same-logical-state live/canonical equality',
                            'C171 T1/T2 scores and original round9 exact raw match']))
    print(json.dumps(dict(source=plan['source'], build_script=str(builder), build_plan=str(HERE / 'build-plan.json'), run_plan=str(HERE / 'run-plan.json'))))


if __name__ == '__main__':
    main()
