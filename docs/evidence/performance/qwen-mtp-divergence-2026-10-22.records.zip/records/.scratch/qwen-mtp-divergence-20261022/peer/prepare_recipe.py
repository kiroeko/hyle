"""Prepare a fixed-native one-host-TU diagnostic recipe. Do not compile/run."""
from pathlib import Path
import hashlib
import json

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
BASE = ROOT / '.scratch/qwen-mtp-window-20261022/peer'
CACHE = ROOT / '.scratch/architecture-refactor-2026-10-18/llama-matched-consumer'


def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def identity(path):
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())


def save(path, data):
    assert not path.exists(), path
    path.write_text(json.dumps(data, indent=2) + '\n', encoding='utf-8')


def main():
    original = read(BASE / 'build-plan.json')
    plan = dict(original)
    plan['status'] = 'Prepared diagnostic only; uncompiled/unrun. Root owns all native execution.'
    plan['source'] = identity(HERE / 'peer_mtp.cc')
    plan['output_directory'] = str(HERE / 'checks/attempt1')
    for key in ['compile', 'link']:
        plan[key] = [item.replace(str(BASE), str(HERE)) for item in original[key]]
    plan['baseline_plan'] = identity(BASE / 'build-plan.json')
    plan['baseline_source'] = identity(HERE / 'before/peer_mtp.cc')
    plan['diagnostic_only'] = True
    save(HERE / 'build-plan.json', plan)
    inputs = ROOT / '.scratch/qwen-mtp-window-20261022/inputs'
    cases = []
    for mode, rounds in [('on', 10), ('off', 19)]:
        name = 'mtp-logits1' if mode == 'on' else 'plain-logits1'
        model = CACHE / ('Qwen3.5-2B-text-MTP-BF16.gguf' if mode == 'on' else 'Qwen3.5-2B-text-BF16.gguf')
        cases.append(dict(name=name, unrun=True, diagnostic_not_throughput=True,
            command=[str(HERE / 'checks/attempt1/peer.exe'), '--model', str(model),
                     '--inputs', str(inputs), '--steps', '64', '--capacity', '1024',
                     '--max-rounds', str(rounds), '--mtp', mode, '--memory-snapshots', 'off',
                     '--diagnostic-dir', str(HERE / name / 'diagnostic'),
                     '--output', str(HERE / name / 'result.json')]))
    save(HERE / 'run-plan.json', dict(cases=cases,
         preserve_quota='steps64 remains unchanged; max-rounds only stops after original decisions. No steps21 last-role substitution.',
         selection='MTP zero-based rounds5/6/9 both rows; plain generated offsets11/12/13/18/19; prefill both modes.',
         prefix_matching='Compare actual evaluated_prefix_ids, not only absolute length: rejected speculative row1 may differ from plain prefix.',
         no_new_native_libraries=True, no_CPU_sampling_fallback=True))
    source_references = [
        ('include/llama.h', '1083-1092: public sampled logits/candidate getters'),
        ('src/llama-context.cpp', '1030-1099: nullable logits; candidate fallback/full-vocabulary list; row resolution and counts; 3947-3968: public synchronize wrappers'),
        ('src/llama-sampler.cpp', '1062-1089: original GPU greedy argmax writes sampled token; does not truncate logits'),
        ('src/llama-graph.cpp', '3775-3846: original per-sequence/per-row sampling registers sampled logits')]
    save(HERE / 'source-freeze.json', dict(
        status='Source and recipes frozen. No CXX/link/native/GPU run by this agent.',
        source=identity(HERE / 'peer_mtp.cc'), baseline_source=identity(HERE / 'before/peer_mtp.cc'),
        baseline_expected_sha256='f35535b5210bc89e71923e6e2442905e05f4d1467f27974bf4bd857f84d1c2b3',
        files=[identity(HERE / file) for file in ['diagnostic.diff', 'prepare_diagnostic.py', 'prepare_recipe.py', 'build-plan.json', 'run-plan.json']],
        source_commit='d9e03f1074dbd2979126d91dce1b5d304ec8394e',
        API_source_facts=[dict(**identity(CACHE / 'source' / file), anchors=anchor) for file, anchor in source_references],
        unchanged_contract=['GPU greedy remains original sampler; CPU argmax is observation only',
            'same target/draft context params, RS1/RS0, output capacities2/1, hidden carry, trim, acceptance/EOS/quota/round decisions',
            'no warmup, new kernel, sampling fallback, SDK/library rebuild or product changes'],
        limits=['Diagnostic extra synchronize getters, CPU scan, raw writes and JSON lie within old endpoints: never use these rates for TPS.',
            'Raw F32 counts and full candidate permutation are required for full-vocabulary argmax; otherwise observation is unavailable.',
            'CPU strict-greater oracle retains first sampled index on ties, whose mapped token is recorded; it never replaces native ID.',
            'Fullvocab logits are expected from current greedy chain but remain an unrun runtime condition.',
            'Fixed Windows x64 ABI uses F32_LE/I32_LE; source and payload hashes can be recorded after actual run.']))
    print(json.dumps(dict(source=plan['source'], build_plan=str(HERE / 'build-plan.json'), run_plan=str(HERE / 'run-plan.json'), freeze=str(HERE / 'source-freeze.json'))))


if __name__ == '__main__':
    main()
