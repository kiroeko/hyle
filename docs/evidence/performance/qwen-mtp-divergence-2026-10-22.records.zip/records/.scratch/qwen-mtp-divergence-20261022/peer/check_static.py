"""Pure-host recipe/source invariants, not a C++ or runtime acceptance."""
from pathlib import Path
import ast
import hashlib
import json

P = Path(__file__).resolve().parent
V = P.parents[1] / 'qwen-mtp-window-20261022/peer'
for file in ['prepare_diagnostic.py', 'prepare_recipe.py', 'check_static.py']:
    ast.parse((P / file).read_text())
plan = json.loads((P / 'build-plan.json').read_text())
old = json.loads((V / 'build-plan.json').read_text())
freeze = json.loads((P / 'source-freeze.json').read_text())
source = (P / 'peer_mtp.cc').read_bytes()
assert hashlib.sha256(source).hexdigest() == freeze['source']['sha256']
for key in ['compile', 'link']:
    assert plan[key] == [item.replace(str(V), str(P)) for item in old[key]]
assert plan['retained_native_input_records_not_rehashed'] == old['retained_native_input_records_not_rehashed']
assert plan['header_identities'] == old['header_identities']
assert hashlib.sha256((P / 'before/peer_mtp.cc').read_bytes()).hexdigest() == old['source']['sha256']
text = source.decode()
removed = [line[1:] for line in (P / 'diagnostic.diff').read_text().splitlines()
           if line.startswith('-') and not line.startswith('---')]
changed_original = [line for line in removed if line not in text.splitlines()]
assert changed_original == ['    std::filesystem::path model, inputs, output;'], changed_original
assert text.count('llama_sampler_sample(') == 1 and text.count('llama_decode(') == 1
prompt = (P.parents[1] / 'qwen-mtp-window-20261022/inputs/prompt.ids').read_text().split()
assert len(prompt) == 154
for values in [[1., 2., 2.], [-2., -1., -3.], [0., 0., 0.]]:
    best = second = -1
    for index, value in enumerate(values):
        if best < 0 or value > values[best]:
            second, best = best, index
        elif second < 0 or value > values[second]:
            second = index
    assert [best, second] == sorted(range(len(values)), key=lambda index: (-values[index], index))[:2]
result = dict(status='Pure-host static checks passed. No CXX/link/native/GPU.',
              source_sha256=freeze['source']['sha256'], python_AST='3 scripts parsed',
              changed_original_lines=changed_original,
              original_computation_lines_retained=True,
              recipe='Exact V compile/link path substitution; same retained native-input records and header identities.',
              prompt_tokens=len(prompt), CPU_top2_check='3 finite toy cases including stable ties; observation only.',
              checker_incident='First inline check incorrectly treated unified-diff replaced context anchors as removed computation. Corrected by checking retained exact original lines; no source or math change.',
              runtime_unverified=['full sampled-logits count/mapping', 'native-vs-CPU argmax', 'all native execution and raw payloads'])
(P / 'static-check.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result))
