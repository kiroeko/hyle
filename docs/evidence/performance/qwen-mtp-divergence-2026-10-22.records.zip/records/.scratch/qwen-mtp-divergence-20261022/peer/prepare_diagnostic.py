"""Prepare the bounded diagnostic TU; never compile or execute a native consumer."""
from pathlib import Path
import difflib
import hashlib
import json

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
BASE = ROOT / '.scratch/qwen-mtp-window-20261022/peer/peer_mtp.cc'
EXPECTED = 'f35535b5210bc89e71923e6e2442905e05f4d1467f27974bf4bd857f84d1c2b3'


def replace_once(source, old, new):
    assert source.count(old) == 1, old
    return source.replace(old, new)


def main():
    raw = BASE.read_bytes()
    assert hashlib.sha256(raw).hexdigest() == EXPECTED
    before = HERE / 'before/peer_mtp.cc'
    before.parent.mkdir(parents=True, exist_ok=True)
    assert not before.exists() and not (HERE / 'peer_mtp.cc').exists()
    before.write_bytes(raw)
    source = raw.decode('utf-8')
    helper = r'''
// Opt-in observation only: never feeds a CPU result back to sampling or state.
// Fixed witnesses belong to this scratch consumer, not a model/provider API.
struct Diagnostic final {
    std::filesystem::path directory;
    Json records = Json::array();
    explicit Diagnostic(std::filesystem::path path) : directory(std::move(path)) {
        if (!directory.empty()) {
            require(!std::filesystem::exists(directory), "diagnostic directory already exists");
            std::filesystem::create_directories(directory);
        }
    }
    bool enabled() const { return !directory.empty(); }
    static bool mtp_round(std::size_t index) { return index == 5 || index == 6 || index == 9; }
    static bool plain_offset(std::size_t offset) {
        return offset == 11 || offset == 12 || offset == 13 || offset == 18 || offset == 19;
    }
    static void binary(const std::filesystem::path & path, const void * data, std::size_t bytes) {
        std::ofstream out(path, std::ios::binary);
        out.write(static_cast<const char *>(data), static_cast<std::streamsize>(bytes));
        require(static_cast<bool>(out), "cannot write diagnostic raw data");
    }
    void capture(llama_context * context, const std::string & name, int32_t row,
                 int32_t vocabulary, llama_token native, const Tokens & prefix,
                 Json round, Json decode_row, std::size_t generated_offset) {
        if (!enabled()) return;
        const auto count = llama_get_sampled_logits_count_ith(context, row);
        const auto candidate_count = llama_get_sampled_candidates_count_ith(context, row);
        const auto * logits = llama_get_sampled_logits_ith(context, row);
        const auto * candidates = llama_get_sampled_candidates_ith(context, row);
        Json record{{"name", name}, {"round_index", round}, {"decode_row", decode_row},
            {"original_batch_row", row}, {"generated_offset_before", generated_offset},
            {"evaluated_prefix_ids", prefix}, {"evaluated_prefix_rows", prefix.size()},
            {"native_sampled_id", native}, {"vocabulary", vocabulary},
            {"sampled_logits_count", count}, {"sampled_candidates_count", candidate_count},
            {"logits_pointer_present", logits != nullptr}, {"candidates_pointer_present", candidates != nullptr},
            {"status", "unavailable"}, {"full_vocabulary", false}};
        // Counts alone are insufficient: the original getter can report the
        // vocab size while returning no backend sampled-logits allocation.
        if (logits && count > 0 && count <= static_cast<uint32_t>(vocabulary)) {
            const auto file = name + ".logits.f32";
            binary(directory / file, logits, static_cast<std::size_t>(count) * sizeof(float));
            record["raw_logits"] = {{"file", file}, {"dtype", "F32_LE"}, {"shape", {count}},
                                    {"bytes", static_cast<std::size_t>(count) * sizeof(float)}};
        }
        bool mapping_valid = candidates && count == static_cast<uint32_t>(vocabulary) &&
            (candidate_count == 0 || candidate_count == count);
        if (mapping_valid) {
            std::vector<uint8_t> seen(static_cast<std::size_t>(vocabulary), 0);
            for (uint32_t i = 0; i < count; ++i) {
                const auto id = candidates[i];
                if (id < 0 || id >= vocabulary || seen[static_cast<std::size_t>(id)]) {
                    mapping_valid = false; break;
                }
                seen[static_cast<std::size_t>(id)] = 1;
            }
        }
        if (logits && mapping_valid) {
            const auto file = name + ".candidates.i32";
            binary(directory / file, candidates, static_cast<std::size_t>(count) * sizeof(llama_token));
            record["raw_candidates"] = {{"file", file}, {"dtype", "I32_LE"}, {"shape", {count}},
                                        {"bytes", static_cast<std::size_t>(count) * sizeof(llama_token)}};
            bool identity = true; std::size_t finite = 0;
            Json scores = Json::object();
            int32_t best = -1, second = -1;
            for (uint32_t i = 0; i < count; ++i) {
                const auto id = candidates[i]; const auto value = logits[i];
                identity = identity && id == static_cast<llama_token>(i);
                finite += std::isfinite(value);
                if (id == 11 || id == 271 || id == native) {
                    uint32_t bits = 0; std::memcpy(&bits, &value, sizeof(bits));
                    scores[std::to_string(id)] = {{"sample_index", i}, {"value", std::isfinite(value) ? Json(value) : Json(nullptr)},
                                                {"f32_bits", bits}};
                }
                // Stable strict-greater scan: ties retain the earlier sampled
                // index; no result is supplied to the native greedy sampler.
                if (!std::isfinite(value)) continue;
                if (best < 0 || value > logits[best]) { second = best; best = static_cast<int32_t>(i); }
                else if (second < 0 || value > logits[second]) second = static_cast<int32_t>(i);
            }
            record["full_vocabulary"] = true;
            record["candidate_mapping"] = candidate_count == 0 ? "original getter full-vocab fallback; permutation verified" : "explicit full permutation verified";
            record["identity_mapping"] = identity; record["finite_count"] = finite;
            record["nonfinite_count"] = count - finite; record["watched_logits"] = scores;
            record["status"] = finite == count ? "full_finite" : "full_nonfinite_no_argmax_assertion";
            if (finite == count && best >= 0 && second >= 0) {
                record["cpu_argmax"] = {{"token", candidates[best]}, {"sample_index", best}, {"logit", logits[best]}};
                record["cpu_second"] = {{"token", candidates[second]}, {"sample_index", second}, {"logit", logits[second]}};
                record["top2_margin"] = static_cast<double>(logits[best]) - logits[second];
                record["native_matches_cpu_argmax"] = native == candidates[best];
            }
        } else {
            record["unavailable_reason"] = "need nonnull logits, exactly vocabulary logits and verified full candidate permutation";
        }
        std::ofstream out(directory / (name + ".json"), std::ios::binary); out << record.dump(2) << '\n';
        require(static_cast<bool>(out), "cannot write diagnostic record");
        records.push_back(std::move(record));
    }
    Json summary() const {
        return {{"enabled", enabled()}, {"directory", directory.string()}, {"not_throughput_evidence", enabled()},
                {"selection", "prefill; MTP zero-based rounds5/6/9 rows0/1; plain output offsets11/12/13/18/19"},
                {"records", records}};
    }
};
'''
    source = replace_once(source, 'struct Options final {', helper + '\nstruct Options final {')
    source = replace_once(source, 'std::filesystem::path model, inputs, output;', 'std::filesystem::path model, inputs, output, diagnostic_dir;')
    source = replace_once(source, 'else if (k == "--output") o.output = v;', 'else if (k == "--output") o.output = v;\n        else if (k == "--diagnostic-dir") o.diagnostic_dir = v;')
    source = replace_once(source, 'const auto startup = Clock::now();', 'const auto startup = Clock::now();\n    Diagnostic diagnostic(o.diagnostic_dir);')
    prefill = 'const auto first = sampled(target.get(), target_sampler.get(), prompt.size() - 1, 1, vocabulary).front();'
    source = replace_once(source, prefill, prefill + '''
    if (diagnostic.enabled()) diagnostic.capture(target.get(), "prefill", static_cast<int32_t>(prompt.size() - 1),
        vocabulary, first, prompt, nullptr, nullptr, 0);''')
    anchor = 'if (o.mtp) actual_hidden = hidden(target.get(), verify.size(), width);'
    source = replace_once(source, anchor, anchor + '''
        if (diagnostic.enabled() && (o.mtp ? Diagnostic::mtp_round(rounds.size()) : Diagnostic::plain_offset(generated.size()))) {
            Tokens prefix = prompt;
            prefix.insert(prefix.end(), generated.begin(), generated.end() - 1);
            require(prefix.size() == base, "diagnostic prefix does not match committed target history");
            for (std::size_t row = 0; row < verify.size(); ++row) {
                prefix.push_back(verify[row]);
                diagnostic.capture(target.get(), "round_" + std::to_string(rounds.size()) + "_row_" + std::to_string(row),
                    static_cast<int32_t>(row), vocabulary, ids[row], prefix, rounds.size(), row, generated.size());
            }
        }''')
    source = replace_once(source, '{"mtp", o.mtp}, {"memory_snapshots_enabled", o.memory_snapshots},', '{"mtp", o.mtp}, {"memory_snapshots_enabled", o.memory_snapshots},\n        {"diagnostic", diagnostic.summary()},')
    (HERE / 'peer_mtp.cc').write_text(source, encoding='utf-8', newline='\n')
    (HERE / 'diagnostic.diff').write_text(''.join(difflib.unified_diff(raw.decode().splitlines(True), source.splitlines(True), fromfile='V/peer_mtp.cc', tofile='W/peer_mtp.cc')), encoding='utf-8')
    print(json.dumps({'source': str(HERE / 'peer_mtp.cc'), 'bytes': len(source.encode()), 'sha256': hashlib.sha256(source.encode()).hexdigest(), 'new_native_calls': 'opt-in public logits/candidate getters only', 'build_or_GPU': False}))


if __name__ == '__main__':
    main()
