from pathlib import Path
import importlib.util,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;R=W.parents[1]
sp=importlib.util.spec_from_file_location('retained',R/'.scratch/qwen-mtp-window-20261022/build.py');h=importlib.util.module_from_spec(sp);sp.loader.exec_module(h);b,c=h.b,h.c
def same(x):return b.identity(x['path'])==x
