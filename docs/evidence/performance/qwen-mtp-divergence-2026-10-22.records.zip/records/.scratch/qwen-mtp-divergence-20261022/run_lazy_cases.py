"""Finite lazy-carrier regression: real P1/one-output and lag1 quota-one continuation."""
from pathlib import Path
import importlib.util,os,sys,hashlib,json,struct
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;R=W.parents[1];V=W.parent/'qwen-mtp-window-20261022';M=W.parent/'qwen-mtp-weights-20261022'
s=importlib.util.spec_from_file_location('helpers',W/'build.py');h=importlib.util.module_from_spec(s);s.loader.exec_module(h);b,c=h.b,h.c
out=W/'lazy-cases1';out.mkdir(exist_ok=False)
original=[int(x)for x in(M/'prepared/prompt.ids').read_text().split()]
plans=[]
for name,length,steps in(('p1',1,1),('p15',15,4)):
 inputs=W/'lazy-inputs'/name;inputs.mkdir(parents=True,exist_ok=False)
 os.link(V/'inputs/mtp/weights.tsv',inputs/'weights.tsv');(inputs/'prompt.ids').write_text(' '.join(map(str,original[:length]))+'\n')
 for arm,root in(('before',V),('current',W)):
  folder=out/f'{name}-{arm}';folder.mkdir()
  ready=c.read(root/'qwen-ready-attempt1.json');assert h.same(ready['image'])
  if arm=='current':assert h.same(ready['source'])
  else:assert hashlib.sha256((W/'before/tools/qwen35_text/main.cc').read_bytes()).hexdigest()==ready['source']['sha256']
  env=os.environ.copy();env['PATH']=c.read(ready['runtime_environment']['path'])['PATH']
  command=[ready['image']['path'],'--inputs',str(inputs),'--steps',str(steps),'--capacity','64','--max-sessions','1','--active-sequences','1','--prefix-cache','off','--progress','direct','--replay','auto','--mtp','on','--trace',str(folder/'trace'),'--trace-level','decisions']
  record=dict(case=name,arm=arm,image=ready,command=command,diagnostic=True,throughput_evidence=False);c.save(folder/'plan.json',record);plans.append(record)
  c.execute('run',command,env,folder)
checks=[]
for name,_,steps in(('p1',1,1),('p15',15,4)):
 old=out/f'{name}-before';now=out/f'{name}-current'
 a=json.loads((old/'run.stdout.log').read_text().splitlines()[-1]);d=json.loads((now/'run.stdout.log').read_text().splitlines()[-1])
 for key in('generated_ids','rounds','visible_tokens','draft_frontier','draft_lag','actual_graph_calls','actual_target_rows','actual_draft_rows','committed_target_rows'):
  assert a[key]==d[key],(name,key)
 if name=='p15':assert d['generated_ids']==[198,248045,74455,271]and d['rounds'][-1]['committed_target_rows']==1 and d['rounds'][-1]['draft_rows']==2
 vectors=[]
 for p in sorted((old/'trace').rglob('*')):
  if p.suffix not in('.f32','.bf16'):continue
  q=now/'trace'/p.relative_to(old/'trace');raw=p.read_bytes();assert q.read_bytes()==raw
  if p.suffix=='.f32':assert all(abs(x[0])<float('inf')for x in struct.iter_unpack('<f',raw))
  else:assert all((x[0]&0x7f80)!=0x7f80 for x in struct.iter_unpack('<H',raw))
  vectors.append(dict(relative=p.relative_to(old/'trace').as_posix(),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest(),byte_equal=True,finite=True))
 checks.append(dict(case=name,generated_ids=d['generated_ids'],actual_graph_calls=d['actual_graph_calls'],rounds=d['rounds'],vectors=vectors))
c.save(W/'review/lazy-cases-review.json',dict(status='Finite real CUDA original/current IDs/roles/work and all exported vectors identical',plans=plans,cases=checks,diagnostic=True,throughput_evidence=False,broader_goal_complete=False))
print(json.dumps(dict(cases=len(checks),vectors=sum(len(x['vectors'])for x in checks),status='PASS'),indent=2))
