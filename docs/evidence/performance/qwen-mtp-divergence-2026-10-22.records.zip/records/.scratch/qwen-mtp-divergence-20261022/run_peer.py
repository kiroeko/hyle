from pathlib import Path
import argparse,importlib.util,os,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;R=W.parents[1];V=R/'.scratch/qwen-mtp-window-20261022';CACHE=R/'.scratch/architecture-refactor-2026-10-18/llama-matched-consumer'
s=importlib.util.spec_from_file_location('helpers',W/'build.py');h=importlib.util.module_from_spec(s);s.loader.exec_module(h);b,c=h.b,h.c
p=argparse.ArgumentParser();p.add_argument('--mtp',choices=('on','off'),default='on');p.add_argument('--attempt',type=int,default=1);p.add_argument('--image-attempt',type=int,default=1);a=p.parse_args()
out=W/f'peer-{a.mtp}-run{a.attempt}';out.mkdir(exist_ok=False)
ready=c.read(W/f'peer-ready-attempt{a.image_attempt}.json');assert h.same(ready['image'])and h.same(ready['source'])
model=CACHE/('Qwen3.5-2B-text-MTP-BF16.gguf'if a.mtp=='on'else'Qwen3.5-2B-text-BF16.gguf')
env=os.environ.copy();env['PATH']=c.read(ready['runtime_environment']['path'])['PATH']
command=[ready['image']['path'],'--model',str(model),'--inputs',str(V/'inputs'),'--steps','64','--capacity','1024','--mtp',a.mtp,'--memory-snapshots','off','--max-rounds','10'if a.mtp=='on'else'19','--diagnostic-dir',str(out/'diagnostic'),'--output',str(out/'consumer-result.json')]
c.save(out/'identity.json',ready);c.save(out/'plan.json',dict(command=command,diagnostic=True,throughput_evidence=False,graph_math='Original fixed native GPU greedy; no output flags/math/RS/precision change, read already returned rows after synchronize',limit='Requested output quota64 retained; maxrounds bounds diagnostic length, not a performance process'))
c.execute('run',command,env,out)
