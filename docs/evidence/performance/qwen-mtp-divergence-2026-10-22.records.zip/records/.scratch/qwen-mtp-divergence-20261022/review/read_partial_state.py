"""Fixed-source Qwen3.5-2B PARTIAL_ONLY parser and offline RS1 control review.

This is deliberately not a general llama state-file parser. It accepts only the
retained single-sequence, F32, non-transposed, 24-layer/no-PLE profile. Headers
are validated as integers; only the 18 R and 18 S payloads become float views.
No model code, Torch, CUDA calls, or state restore is executed here.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import struct
import sys

import numpy as np

W = Path(__file__).resolve().parents[1]
LAYERS = tuple(i for i in range(24) if i % 4 != 3)
VOCAB = 248320
MAGIC = 0xAF143CD8


def unique(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError('duplicate JSON key: ' + key)
        result[key] = value
    return result


def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'), object_pairs_hook=unique)


def identity(path):
    data = path.read_bytes()
    return dict(path=str(path.resolve()), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())


def parse_partial(path):
    data = path.read_bytes()
    offset = 0

    def unpack(fmt):
        nonlocal offset
        size = struct.calcsize('<' + fmt)
        if size > len(data) - offset:
            raise ValueError(f'{path}: truncated header at {offset}')
        fields = struct.unpack_from('<' + fmt, data, offset)
        offset += size
        return fields[0] if len(fields) == 1 else fields

    magic, seq_id = unpack('Ii')
    if magic != MAGIC or seq_id != 0:
        raise ValueError(f'{path}: expected sequence magic and seq_id0')
    cells = unpack('I')
    if cells != 1:
        raise ValueError(f'{path}: this fixed-profile parser requires exactly one logical cell')
    position, seq_count = unpack('iI')
    if position < 0 or seq_count != 0:
        raise ValueError(f'{path}: unexpected sequence-specific cell metadata')
    transposed, layer_count = unpack('II')
    if transposed != 0 or layer_count != 24:
        raise ValueError(f'{path}: expected untransposed 24-layer profile')
    arrays = {}
    metadata = []
    for kind, rowbytes, shape in [('R', 73728, [3, 6144]), ('S', 1048576, [128, 128, 16])]:
        for layer in LAYERS:
            dtype, size = unpack('iQ')
            if dtype != 0 or size != rowbytes:
                raise ValueError(f'{path}: {kind} layer{layer} expected F32 row bytes {rowbytes}; got {dtype}/{size}')
            if size > len(data) - offset:
                raise ValueError(f'{path}: truncated {kind} layer{layer} payload')
            name = f'{kind}{layer}'
            # np.frombuffer retains the immutable bytes owner. No payload copy,
            # and no header/padding/unused snapshot plane is read as a number.
            arrays[name] = np.frombuffer(data, dtype='<f4', count=size // 4, offset=offset)
            metadata.append(dict(name=name, layer=layer, kind=kind, dtype='F32_LE', offset=offset,
                                 bytes=size, elements=size // 4, ggml_ne0_fast_shape=shape,
                                 finite=bool(np.isfinite(arrays[name]).all())))
            offset += size
    if offset != len(data):
        raise ValueError(f'{path}: trailing bytes ({len(data) - offset}); unsupported profile or malformed blob')
    return dict(source=identity(path), magic=hex(magic), seq_id=seq_id, cell_count=cells,
                cell_position=position, logical_length=position + 1, s_trans=transposed,
                layer_count=layer_count, recurrent_layers=list(LAYERS),
                payload_order='all 18 R blocks, then all 18 S blocks',
                payload_bytes=sum(m['bytes'] for m in metadata),
                header_bytes=len(data) - sum(m['bytes'] for m in metadata),
                all_payload_finite=all(m['finite'] for m in metadata), blocks=metadata), arrays


def metrics(a, b):
    if a.shape != b.shape:
        raise ValueError(f'extent mismatch: {a.shape} vs {b.shape}')
    finite_a, finite_b = bool(np.isfinite(a).all()), bool(np.isfinite(b).all())
    result = dict(elements=int(a.size), finite_left=finite_a, finite_right=finite_b,
                  byte_equal=a.tobytes() == b.tobytes(),
                  unequal_elements=int(np.count_nonzero(a != b)))
    if finite_a and finite_b:
        x, y = a.astype(np.float64), b.astype(np.float64)
        d = x - y
        nx, ny = np.linalg.norm(x), np.linalg.norm(y)
        result.update(maxabs=float(np.max(np.abs(d), initial=0)),
                      relative_L2_to_right=float(np.linalg.norm(d) / ny) if ny else None,
                      cosine=float(x @ y / (nx * ny)) if nx and ny else None)
    return result


def state_comparison(left, right):
    lm, la = parse_partial(left)
    rm, ra = parse_partial(right)
    if lm['logical_length'] != rm['logical_length']:
        raise ValueError('attempted comparison at different logical lengths')
    blocks = [dict(name=n, **metrics(la[n], ra[n])) for n in la]
    totals = {}
    for kind in ('R', 'S'):
        names = [n for n in la if n[0] == kind]
        # No persistent tensor/model allocation: one small native state vector
        # is concatenated per kind solely for offline descriptive aggregation.
        totals[kind] = metrics(np.concatenate([la[n] for n in names]), np.concatenate([ra[n] for n in names]))
    return dict(left=lm, right=rm, logical_length=lm['logical_length'],
                header_comparison='Integer fields establish profile/position only; not numerical state evidence.',
                by_kind=totals, by_layer=blocks)


def logits(directory, name):
    metadata_path = directory / (name + '.json')
    record = read(metadata_path)
    raw_path = directory / record['raw_logits']['file']
    candidate_path = directory / record['raw_candidates']['file']
    scores = np.frombuffer(raw_path.read_bytes(), dtype='<f4')
    candidates = np.frombuffer(candidate_path.read_bytes(), dtype='<i4')
    if scores.size != VOCAB or candidates.size != VOCAB or not np.isfinite(scores).all():
        raise ValueError('expected finite full vocabulary')
    if not np.array_equal(np.sort(candidates), np.arange(VOCAB)):
        raise ValueError('candidate map is not a complete vocabulary permutation')
    ordered = np.empty(VOCAB, dtype='<f4')
    ordered[candidates] = scores
    gpu_id = record['native_sampled_id']
    independent_id = int(candidates[int(scores.argmax())])
    assert independent_id == gpu_id == record['cpu_argmax']['token']
    prefix = record['evaluated_prefix_ids']
    assert len(prefix) == record['evaluated_prefix_rows']
    return ordered, prefix, dict(metadata=identity(metadata_path), logits=identity(raw_path),
        candidates=identity(candidate_path), native_id=gpu_id, independent_argmax=independent_id,
        full_vocabulary_permutation=True, identity_mapping=bool(np.array_equal(candidates, np.arange(VOCAB))),
        prefix_rows=len(prefix), prefix_SHA256_I32_LE=hashlib.sha256(np.asarray(prefix, '<i4').tobytes()).hexdigest(),
        top2_margin=record['top2_margin'])


def control(run, output):
    terminal = read(run / 'run.result.json')
    assert terminal['terminal'] and terminal['exit'] == 0
    raw = read(run / 'consumer-result.json')
    directory = run / 'diagnostic'
    assert raw['native_target_contexts'] == raw['shared_model_objects'] == 1
    assert raw['checkpoint_length'] == 164 and raw['checkpoint']['flags'] == 0
    assert raw['B']['trim_to'] == 165 and raw['B']['restore_between_trim_and_next'] is False
    assert raw['A']['first']['inputs'] == [11] and raw['B']['first']['inputs'] == [11, 36760]
    assert raw['A']['next']['inputs'] == raw['B']['next']['inputs'] == [51338]
    assert raw['A']['next']['evaluated_prefix_ids'] == raw['B']['next']['evaluated_prefix_ids']
    expected = raw['checkpoint_prefix_ids']
    assert len(expected) == 164
    comparisons = []
    for left, right in [('A_T1_11_row_0', 'B_T2_11_36760_row_0'),
                        ('A_T1_51338_row_0', 'B_T1_51338_after_trim_row_0')]:
        a, ap, am = logits(directory, left)
        b, bp, bm = logits(directory, right)
        assert ap == bp == expected + ([11] if len(ap) == 165 else [11, 51338])
        comparisons.append(dict(left=am, right=bm, equal_evaluated_prefix=True,
                                native_ids_equal=am['native_id'] == bm['native_id'], **metrics(a, b)))
    _, badprefix, rejected_metadata = logits(directory, 'B_T2_11_36760_row_1')
    assert badprefix == expected + [11, 36760]
    hidden = []
    for left, right, rows in [('A_T1_11', 'B_T2_11_36760', 2),
                              ('A_T1_51338', 'B_T1_51338_after_trim', 1)]:
        lp, rp = directory / (left + '.hidden.f32'), directory / (right + '.hidden.f32')
        a = np.frombuffer(lp.read_bytes(), '<f4').reshape(1, 2048)[0]
        b = np.frombuffer(rp.read_bytes(), '<f4').reshape(rows, 2048)[0]
        hidden.append(dict(left=identity(lp), right=identity(rp), right_slice_row=0, **metrics(a, b)))
    states = []
    for length, a, b in [(165, 'A165', 'B165_after_trim'), (166, 'A166', 'B166')]:
        result = state_comparison(directory / (a + '.partial-state.bin'), directory / (b + '.partial-state.bin'))
        assert result['logical_length'] == length
        for side in ('left', 'right'):
            metadata = raw['A' if side == 'left' else 'B']['logical' + str(length)]
            assert metadata['flags'] == 1 and metadata['bytes'] == result[side]['source']['bytes']
            assert metadata['logical_length'] == length and metadata['native_pos_max'] == length - 1
        states.append(result)
    source = W / 'control/control_peer.cc'
    frozen = read(W / 'control/source-freeze.json')
    assert identity(source)['sha256'] == frozen['source']['sha256']
    report = dict(scope='One actual RS1 target, same full checkpoint, T1 vs T2 plus trim. Descriptive offline state/logit analysis; no threshold or quality PASS.',
        checker=identity(Path(__file__)), terminal=identity(run / 'run.result.json'),
        result=identity(run / 'consumer-result.json'), source=identity(source), source_freeze=identity(W / 'control/source-freeze.json'),
        checkpoint=dict(**identity(directory / 'C.full-state.bin'), flags=0, logical_length=164,
                        restore_count=2, provenance='Both restore calls read the exact same immutable local checkpoint vector; source-bound fact.'),
        trajectory=dict(natural_first5_completed=len(raw['natural_rounds_completed']),
                        B_rejection_reproduced=raw['B']['original_rejection_reproduced'],
                        B_row0_matches_original_51338=raw['B']['row0_matches_original_51338'],
                        A_first_id=raw['A']['first']['native_ids'], B_first_ids=raw['B']['first']['native_ids'],
                        A_next_id=raw['A']['next']['native_ids'], B_next_id=raw['B']['next']['native_ids']),
        comparisons=dict(logits=comparisons, hidden=hidden, logical_recurrent_states=states),
        excluded=dict(row1=rejected_metadata,
                      reason='B row1 consumes rejected token36760, unlike the common next input51338; no numeric comparison to A next.'),
        limits=[
            'State get synchronizes and reads logical pending rollback-plane state, but does not set/normalize it. B continues without a restore after trim.',
            'Integer headers and sequence positions are checked; only typed F32 R/S payloads are compared. KV payload is not parsed here.',
            'T1 and T2 can differ through shape-dependent arithmetic before rejection; unequal state alone does not identify a rollback bug.',
            'Serial full-state restore resets both branch starts. Host carry/prior, draft context, logits and sampler outputs are not serialized or resumed by this control.',
            'The fixed51338 follow-up is an explicit diagnostic input, not a natural acceptance-rate/quality claim.',
            'No equality threshold, model quality PASS, throughput conclusion, or algorithm modification is inferred.'
        ])
    output.write_text(json.dumps(report, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')
    print(json.dumps(dict(output=str(output), source=frozen['source']['sha256'],
        ids=report['trajectory'], logits=[{k:v for k,v in r.items() if k not in ('left','right')} for r in comparisons],
        states=[dict(length=r['logical_length'], **r['by_kind']) for r in states]), indent=2))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--run', type=Path)
    parser.add_argument('--left', type=Path)
    parser.add_argument('--right', type=Path)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    if args.run:
        if args.left or args.right:
            parser.error('--run cannot be combined with --left/--right')
        control(args.run, args.output)
    elif args.left:
        result = state_comparison(args.left, args.right) if args.right else parse_partial(args.left)[0]
        args.output.write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
    else:
        parser.error('provide --run or --left')
    assert 'torch' not in sys.modules, 'offline reader must not import Torch'


if __name__ == '__main__':
    main()
