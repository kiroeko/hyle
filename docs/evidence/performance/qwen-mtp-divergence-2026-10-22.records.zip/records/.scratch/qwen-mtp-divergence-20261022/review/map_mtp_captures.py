"""Host-only reconciliation of the frozen V capture reports; no inference."""
from __future__ import annotations

import hashlib
import json
import re
import statistics
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
V = ROOT / ".scratch/qwen-mtp-window-20261022"
OUT = Path(__file__).with_name("capture-source-review.json")
PREPARED = re.compile(
    r"prepared T=(\d+) visible=(\d+) replay=(\S+) "
    r"cold_batch_seconds=([\d.eE+-]+) capture_recorded=(\d+) capture_reused=(\d+)"
)


def identity(path: Path) -> dict:
    data = path.read_bytes()
    return {"path": path.relative_to(ROOT).as_posix(), "bytes": len(data),
            "sha256": hashlib.sha256(data).hexdigest()}


def prepared(text: str) -> list[dict]:
    return [{"T": int(m[1]), "reported_visible_after_commit": int(m[2]), "route": m[3],
             "cold_seconds": float(m[4]), "recorded_ranges": int(m[5]),
             "reused_ranges": int(m[6])} for m in PREPARED.finditer(text)]


def extent(values: list[float | int]) -> dict:
    return {"median": statistics.median(values), "min": min(values), "max": max(values)}


def mtp_process(folder: Path) -> dict:
    data = json.loads((folder / "stdout.log").read_text(encoding="utf-8"))
    text = (folder / "stderr.log").read_text(encoding="utf-8")
    records = prepared(text)
    assert len(records) == 1 + len(data["rounds"]) == 35
    assert records[0]["T"] == records[0]["reported_visible_after_commit"] == 154
    length = 154
    lag = 0
    seen: dict[tuple[str, int], int] = {}
    events = []
    for ordinal, (round_, raw) in enumerate(zip(data["rounds"], records[1:]), 1):
        # Successful prefill uses slot0; each successful original episode flips
        # Model.execution_parity exactly once, including a partial acceptance.
        slot = ordinal % 2
        role = "kMtpCatchupRound" if lag else "kMtpRound"
        key = (role, slot)
        prior = seen.get(key, 0)
        seen[key] = prior + 1
        assert raw["T"] == 2
        # The deferred 'prepared' line is printed from StepObservation only
        # after finish and carries the selected committed extent, not T2's
        # temporary verified frontier when only row0 is accepted.
        assert raw["reported_visible_after_commit"] == length + round_["committed_target_rows"]
        assert raw["recorded_ranges"] + raw["reused_ranges"] == 2
        assert round_["draft_rows"] == lag + 1
        if not prior:
            assert raw["recorded_ranges"] == 2
        events.append({"stderr_call": f"mtp{ordinal}", "round_zero_based": ordinal - 1,
                       "derived_role": role, "derived_slot": slot,
                       "derived_prior_role_slot_calls": prior,
                       "target_length_before": length, "draft_frontier_before": length - lag,
                       "lag_before": lag,
                       "target_page_refs_after_verify": (length + 2 + 15) // 16,
                       "draft_page_refs_after_work": (length + 1 + 15) // 16,
                       "previous_round_partial_accept": ordinal > 1 and lag == 0,
                       "accepted_draft": round_["accepted_draft"],
                       "committed_target_rows": round_["committed_target_rows"], **raw,
                       "attribution": "first actual role-slot: two initial ranges" if not prior
                       else ("retained ranges reused" if not raw["recorded_ranges"] else
                             "subsequent recording: exact invalidation reason not logged")})
        length += round_["committed_target_rows"]
        lag = int(round_["accepted_draft"])
    assert length == data["visible_tokens"] == 217
    assert lag == data["draft_lag"] == 1
    first = [r for r in events if r["derived_prior_role_slot_calls"] == 0]
    subsequent = [r for r in events if r["derived_prior_role_slot_calls"] != 0]
    phases = re.findall(r"compiled T=(\d+) steps=(\d+) workspace/slot=(\d+) .*?child_prepare_seconds=([\d.eE+-]+)", text)
    assert [int(x[0]) for x in phases] == [154, 2, 2, 1, 1]
    roles = ["kMtpPrefill", "kMtpRound", "kMtpCatchupRound", "kMtpSingle", "kMtpCatchupSingle"]
    phase_records = []
    for role, record in zip(roles, phases):
        phase_records.append({"role_in_source_initialization_order": role, "T": int(record[0]),
                              "steps": int(record[1]), "declared_workspace_bytes_per_slot": int(record[2]),
                              "logged_child_prepare_seconds_excludes_initialize_slot": float(record[3]),
                              "eagerly_initialized_slots_from_source": 2,
                              "actual_used_slots": [0] if role == "kMtpPrefill" else
                              sorted(k[1] for k in seen if k[0] == role)})
    known_all = sum(2 * x["declared_workspace_bytes_per_slot"] for x in phase_records)
    known_used = sum(len(x["actual_used_slots"]) * x["declared_workspace_bytes_per_slot"] for x in phase_records)
    families = re.findall(r"compiled text finite family .*?cold_seconds=([\d.eE+-]+)", text)
    assert len(families) == 5
    return {"folder": folder.relative_to(ROOT).as_posix(),
            "raw": [identity(folder / p) for p in ["stdout.log", "stderr.log", "result.json"]],
            "prefill": records[0], "rounds": events,
            "summary": {"actual_decode_calls": len(events),
                        "recorded_ranges": sum(r["recorded_ranges"] for r in events),
                        "reused_ranges": sum(r["reused_ranges"] for r in events),
                        "first_role_slot_recorded_ranges": sum(r["recorded_ranges"] for r in first),
                        "subsequent_recorded_ranges": sum(r["recorded_ranges"] for r in subsequent),
                        "first_role_slot_calls": [r["stderr_call"] for r in first],
                        "subsequent_recording_calls": [r["stderr_call"] for r in subsequent if r["recorded_ranges"]],
                        "cold_decode_seconds": sum(r["cold_seconds"] for r in events),
                        "first_role_slot_cold_seconds": sum(r["cold_seconds"] for r in first),
                        "subsequent_recording_cold_seconds": sum(r["cold_seconds"] for r in subsequent if r["recorded_ranges"]),
                        "zero_record_decode_cold_seconds": sum(r["cold_seconds"] for r in events if not r["recorded_ranges"]),
                        "declared_eager_workspace_bytes": known_all,
                        "declared_workspace_bytes_in_never_executed_slots": known_all - known_used,
                        "two_unexecuted_T1_family_compile_seconds": sum(map(float, families[3:]))},
            "phase_carriers": phase_records}


def main() -> None:
    source = ROOT / "tools/qwen35_text/main.cc"
    assert identity(source)["sha256"] == "8c71a5fda9b9ed29d3fe9210fad80f164a83f000511a1477a1544dbf8aecf7b6"
    plan = json.loads((V / "performance/timing/runs.json").read_text(encoding="utf-8"))
    mtp = [mtp_process(Path(p["folder"])) for p in plan if p["arm"] == "hyle_mtp"]
    plain = []
    for process in plan:
        if process["arm"] != "hyle_plain":
            continue
        folder = Path(process["folder"])
        events = prepared((folder / "stderr.log").read_text(encoding="utf-8"))
        assert len(events) == 64
        plain.append({"folder": folder.relative_to(ROOT).as_posix(),
                      "raw": [identity(folder / p) for p in ["stdout.log", "stderr.log", "result.json"]],
                      "decode_recorded_ranges": sum(r["recorded_ranges"] for r in events[1:]),
                      "decode_reused_ranges": sum(r["reused_ranges"] for r in events[1:]),
                      "cold_decode_seconds": sum(r["cold_seconds"] for r in events[1:])})
    assert len(mtp) == len(plain) == 3
    patterns = [[(r["derived_role"], r["derived_slot"], r["recorded_ranges"], r["reused_ranges"])
                 for r in p["rounds"]] for p in mtp]
    assert patterns[0] == patterns[1] == patterns[2]
    result = {
        "status": "focused read-only source and frozen actual-log review; no inferred capture bug",
        "checker": identity(Path(__file__)),
        "source_and_frozen_execution": {"current_main": identity(source),
            "ready": identity(V / "qwen-ready-attempt1.json"),
            "independent_window_analysis": identity(V / "review/window-analysis.json"),
            "sources": [identity(ROOT / p) for p in ["src/graph/executable.cc", "src/graph/resources.cc",
                "src/graph_batch/batch.cc", "src/graph_batch/paged_append.cc",
                "src/compute_provider_flashinfer/flashinfer_provider.cc"]]},
        "mapping_contract": [
            "The JSON round array is zero-based; stderr mtp1..mtp34 is one-based. Do not conflate the names.",
            "Role and slot are derived from exact successful source control flow and the actual round ledger; they were not printed directly in V.",
            "Global initial parity0; prefill commits slot0; each successful finish flips once even when only target row0 commits.",
            "The deferred prepared line's visible value is post-selection committed extent; do not mistake it for the temporary T2 verified frontier.",
            "Lag after an accepted proposal is1, otherwise0. All actual decode calls here are T2; neither T1 fallback role ran."
        ],
        "actual_MTP_processes": mtp, "actual_plain_processes": plain,
        "aggregate": {"MTP_record_reuse_pattern_equal_all_three": True,
            "MTP_decode_cold_seconds": extent([x["summary"]["cold_decode_seconds"] for x in mtp]),
            "plain_decode_cold_seconds": extent([x["cold_decode_seconds"] for x in plain]),
            "first_role_slot_ranges_each_process": 8, "additional_recorded_ranges_each_process": 10,
            "MTP_declared_unused_slot_workspace_bytes_each_process": 41799936},
        "source_mechanisms": [
            {"anchors": ["tools/qwen35_text/main.cc:413", "tools/qwen35_text/main.cc:1411", "tools/qwen35_text/main.cc:1666", "tools/qwen35_text/main.cc:1997"],
             "fact": "Roles have separate Family/Phase and two independent Invocation slots. Four actual role-slot pairs first appear at mtp1,2,3,12, each recording both ranges: exactly8 of18."},
            {"anchors": ["tools/qwen35_text/main.cc:1773", "tools/qwen35_text/main.cc:1780", "tools/qwen35_text/main.cc:1615", "tools/qwen35_text/main.cc:1975", "src/graph/executable.cc:1244", "src/graph/executable.cc:1283"],
             "fact": "Each verify allocates two distinct conv/GDN output boundaries plus two carry outputs. Partial acceptance selects different material and drops the verified mutable tail; the next call may COW. Real buffer tuple changes legitimately invalidate covering ranges. V does not log those tuples, so rejection correlation is not proof for a particular record."},
            {"anchors": ["src/graph/resources.cc:310", "src/graph/resources.cc:841", "src/graph/resources.cc:885", "src/graph/executable.cc:1069"],
             "fact": "Qualified pointer-backed borrowed carriers and written projections can retain dormant recordings across unbind/take while permissions and replay are revoked. A new lease/generation alone is not proof of a recording change; do not reintroduce the old blanket-invalidation diagnosis."},
            {"anchors": ["src/compute_provider_flashinfer/flashinfer_provider.cc:257", "src/graph_batch/batch.cc:355", "src/graph_batch/batch.cc:501", "src/graph_batch/paged_append.cc:467", "src/graph_batch/paged_append.cc:494"],
             "fact": "Attention schedule reuse checks exact query counts and original chunk topology; native before-change callbacks invalidate owners and metadata dependents. Append descriptors may update stable contents, but a replaced/split mirror or actual bank pointer invalidates before replacement. KV growth does not by itself require recording every page boundary."},
            {"anchors": ["src/graph/executable.cc:7888", "src/graph/executable.cc:9444"],
             "fact": "Capture counts are ranges, not Graph calls or kernels. Invalidation destroys only covering retained artifacts; preparation records missing ranges and counts existing ranges as reuse."}
        ],
        "unresolved_ten_ranges": {
            "one_based_calls": [4, 7, 8, 10, 13, 14, 15],
            "counts_in_that_order": [1, 1, 1, 1, 2, 2, 2],
            "conclusion": "No actual slot/range/port identities or invalidation reasons were logged. These10 cannot be assigned uniquely to target/draft native topology, state/carry backing changes, or descriptor carrier changes from V. No redundant capture bug or removable55ms is established.",
            "counterexample_to_blanket_topology_explanation": "All mtp16..34 reuse both ranges despite several later target/draft page-count increments; growth alone is insufficient attribution."
        },
        "one_minimal_optimization_candidate": {
            "name": "Keep fallback families/plans cold, but instantiate execution carriers only when their exact role/slot actually needs explicit preparation",
            "anchors": ["tools/qwen35_text/main.cc:2182", "tools/qwen35_text/main.cc:2189", "tools/qwen35_text/main.cc:1522", "tools/qwen35_text/main.cc:1382", "src/graph/executable.cc:8674"],
            "actual_evidence": "run_mtp eagerly prepare_execution(either_slot=true) for prefill plus all4 decode roles. This creates10 Invocation slots. Actual P154/64 uses only prefill slot0 and the4 T2 role-slots; both T1 roles and prefill slot1 never execute.",
            "bounded_cost": "Five never-executed slots declare41,799,936 workspace bytes in total (39.8635MiB), excluding private provider allocations, metadata/alignment and the two unused T1 Phase IO sets. create_invocation actually instantiates each workspace; this is not a claim of equal OS/physical GPU peak savings.",
            "minimal_cut": "Retain all existing finite family compilations and pre-registered role/slot use bounds. Explicitly prepare the known prefill slot and recurring T2 roles; let the existing prepare_evaluations -> prepare_child/initialize_slot path create a fallback T1 carrier on its first real need. No Graph/Provider/API change, model-role whitelist, new executor or skipped prepare is needed.",
            "fairness": "Any actual fallback initialization remains inside its explicit prepare and full decode/session/startup endpoint. Report that cold tail if it occurs; do not silently move real work out of elapsed or claim a measured speedup. Success/EOS/quota/abort behavior must remain unchanged.",
            "not_claimed": "This carrier-only cut does not remove the upfront T1 family compilations (their two cold_seconds are retained per process), nor explain or eliminate the10 subsequent records. No per-slot initialization time was logged, so no ms/TPS saving is estimated."
        },
        "smallest_diagnostic_if_exact_capture_attribution_is_required": {
            "consumer_cold_records": "Reuse the existing preallocated PreparationObservation, adding role and actual phase-slot prior-use count to each MTP round; keep all records until after final host endpoint. Split existing layout/batch/replay buckets, without changing total measurement endpoints.",
            "attention_facts": "Snapshot existing public BatchPlanReport for the six target attention nodes AND the draft node (current reports[6] omits it). Need reused_native_plan, topology/workspace sizes, metadata upload facts; no new device query.",
            "remaining_gap": "Those reports can distinguish schedule replan but not state-pointer vs recording-range invalidation. If still necessary, a single temporary bounded cold breadcrumb at current invalidation call sites must identify selected step/range and reason (tuple/native before-change/descriptor replacement/unproven release), with changed port ordinal. Do not infer reason from recorded count alone or create a permanent tuning framework.",
            "not_run": True
        },
        "limits": ["Only the exact V P154/C1024/N1R1/64-output stream and current source8c71 are bound here.",
            "cold_batch_seconds starts after token/position uploads and phase initialization; it contains layout/state/append work, batch prepare, replay capture and host waits, not one function self-time.",
            "No new native trace, model/GPU run, build, product/doc edit, public API or default route change.",
            "Peer output divergence investigation is separate; this report makes no new quality claim."]
    }
    # The same capture/role/slot pattern was asserted for all three runs. Keep
    # one bounded pattern with all three actual clock samples rather than
    # duplicating the same 34 structural records three times.
    pattern = []
    for index, event in enumerate(mtp[0]["rounds"]):
        entry = {k: v for k, v in event.items() if k != "cold_seconds"}
        entry["cold_seconds_by_process_in_order"] = [p["rounds"][index]["cold_seconds"] for p in mtp]
        pattern.append(entry)
    result["round_pattern_equal_all_three"] = pattern
    result["phase_carriers_in_initialization_order"] = [
        {k: v for k, v in phase.items() if k != "logged_child_prepare_seconds_excludes_initialize_slot"}
        for phase in mtp[0]["phase_carriers"]]
    for process in mtp:
        process["logged_phase_child_prepare_seconds_in_order"] = [
            p["logged_child_prepare_seconds_excludes_initialize_slot"] for p in process.pop("phase_carriers")]
        del process["rounds"]
    OUT.parent.mkdir(parents=True, exist_ok=True)
    OUT.write_text(json.dumps(result, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print(json.dumps({"report": identity(OUT), "aggregate": result["aggregate"]}, indent=2))


if __name__ == "__main__":
    main()
