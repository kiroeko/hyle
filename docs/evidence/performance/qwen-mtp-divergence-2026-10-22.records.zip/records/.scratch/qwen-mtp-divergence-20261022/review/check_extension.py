"""Offline extension: pending rollback vs restore, then exact-C171 T1/T2.

Consumes only completed native diagnostic files. Does not run a model, restore
native state, change frozen control1 reports, or establish a quality threshold.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path
import sys

import numpy as np

from read_partial_state import identity, logits, metrics, parse_partial, read
from check_logits import rne_bf16

W = Path(__file__).resolve().parents[1]


def summary(scores):
    order = np.lexsort((np.arange(scores.size), -scores))[:3]
    bf16 = rne_bf16(scores)
    return dict(native_F32_first_argmax=int(order[0]),
                top3=[dict(id=int(i), value=float(scores[i])) for i in order],
                score11=float(scores[11]), score271=float(scores[271]),
                margin11_minus271=float(np.float64(scores[11]) - np.float64(scores[271])),
                offline_BF16_RNE=dict(score11=float(bf16[11]), score271=float(bf16[271]),
                                      first_argmax=int(bf16.argmax()),
                                      meaning='Description only; never fed back or used to change native sampling.'))


def compare_logits(leftdir, left, rightdir, right):
    a, ap, am = logits(leftdir, left)
    b, bp, bm = logits(rightdir, right)
    if ap != bp:
        raise ValueError(f'different evaluated input prefixes: {left} vs {right}')
    return dict(left=am, right=bm, equal_evaluated_prefix=True,
                native_ids_equal=am['native_id'] == bm['native_id'],
                left_summary=summary(a), right_summary=summary(b), **metrics(a, b))


def compare_hidden(directory, left, right, leftrows=1, rightrows=1, leftrow=0, rightrow=0):
    lp, rp = directory / (left + '.hidden.f32'), directory / (right + '.hidden.f32')
    a = np.frombuffer(lp.read_bytes(), '<f4').reshape(leftrows, 2048)[leftrow]
    b = np.frombuffer(rp.read_bytes(), '<f4').reshape(rightrows, 2048)[rightrow]
    return dict(left=identity(lp), right=identity(rp), left_row=leftrow, right_row=rightrow, **metrics(a, b))


def compare_state(directory, left, right):
    lm, a = parse_partial(directory / (left + '.partial-state.bin'))
    rm, b = parse_partial(directory / (right + '.partial-state.bin'))
    if lm['logical_length'] != rm['logical_length']:
        raise ValueError('different logical state lengths')
    result = dict(left=lm['source'], right=rm['source'], logical_length=lm['logical_length'],
                  profile='Single seq0, cell1, 24layers/noPLE, 18R then18S; F32 checked extents/EOF.',
                  headers_used_only_for_validation=True,
                  whole_blob_byte_equal=lm['source']['sha256'] == rm['source']['sha256'],
                  by_kind={}, by_layer=[])
    for kind in ('R', 'S'):
        names = [n for n in a if n.startswith(kind)]
        result['by_kind'][kind] = metrics(np.concatenate([a[n] for n in names]), np.concatenate([b[n] for n in names]))
        result['by_layer'].extend(dict(name=n, **metrics(a[n], b[n])) for n in names)
    return result


def completed(path):
    terminal = read(path / 'run.result.json')
    if not terminal.get('terminal') or terminal['exit'] != 0:
        raise ValueError(f'run is not terminal success: {path}')
    return dict(terminal=identity(path / 'run.result.json'),
                result=identity(path / 'consumer-result.json'),
                runtime_identity=identity(path / 'identity.json'))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--run', type=Path, default=W / 'control2-run1')
    parser.add_argument('--output', type=Path, default=W / 'review/extension-comparison.json')
    args = parser.parse_args()
    proof = completed(args.run)
    directory = args.run / 'diagnostic'
    raw = read(args.run / 'consumer-result.json')
    original = W / 'peer-on-run1/diagnostic'
    old_control = W / 'control-run1/diagnostic'
    oldproof = completed(W / 'control-run1')
    originalproof = completed(W / 'peer-on-run1')
    assert raw['native_target_contexts'] == raw['shared_model_objects'] == 1
    assert raw['target_n_rs_seq'] == 1 and raw['target_effective_context'] == 1024
    canonical = raw['B_same_logical165_canonical']
    shape = raw['C171_shape_control']
    assert canonical['restore_boundary165'] is True
    assert canonical['checkpoint']['flags'] == 0 and canonical['checkpoint']['logical_length'] == 165
    assert shape['checkpoint']['flags'] == 0 and shape['checkpoint']['logical_length'] == 171
    assert raw['B']['restore_between_trim_and_next'] is False
    assert canonical['next']['inputs'] == raw['B']['next']['inputs'] == [51338]
    assert canonical['next']['first_position'] == raw['B']['next']['first_position'] == 165
    assert shape['T1']['inputs'] == [11906] and shape['T2']['inputs'] == [11906, 271]
    assert shape['T1']['first_position'] == shape['T2']['first_position'] == 171

    # Reproduce each originally observed row before attributing a new control
    # to that trajectory. Mismatch is reported rather than silently accepted.
    anchors = []
    for name, reference in [('B_T2_11_36760', 'round_5'),
                             ('C171_T2_11906_271', 'round_9')]:
        for row in (0, 1):
            anchors.append(dict(control=name, row=row,
                **compare_logits(directory, f'{name}_row_{row}', original, f'{reference}_row_{row}')))
    original_control_recheck = [compare_logits(old_control, f'B_T2_11_36760_row_{row}',
                                               original, f'round_5_row_{row}') for row in (0, 1)]
    control1_to_control2 = [compare_logits(directory, f'B_T2_11_36760_row_{row}',
                                         old_control, f'B_T2_11_36760_row_{row}') for row in (0, 1)]
    live = compare_logits(directory, 'B_T1_51338_after_trim_row_0',
                          directory, 'B_canonical_T1_51338_row_0')
    hidden = compare_hidden(directory, 'B_T1_51338_after_trim', 'B_canonical_T1_51338')
    state = compare_state(directory, 'B166', 'B166_canonical')
    at171 = compare_logits(directory, 'C171_T1_11906_row_0',
                           directory, 'C171_T2_11906_271_row_0')
    hidden171 = compare_hidden(directory, 'C171_T1_11906', 'C171_T2_11906_271', rightrows=2)
    # The rejected/next row of T2 consumes token271 and has no counterpart in
    # the T1 row. It is used only for exact original-T2 reproduction above.
    _, row1prefix, row1proof = logits(directory, 'C171_T2_11906_271_row_1')
    _, row0prefix, _ = logits(directory, 'C171_T1_11906_row_0')
    assert row1prefix == row0prefix + [271]

    replay = shape['replay']
    assert len(replay) == 4
    original_result = read(W / 'peer-on-run1/consumer-result.json')
    expected_prefix = list(raw['checkpoint_prefix_ids'])
    replay_proof = []
    for index, record in enumerate(replay, 5):
        original_round = original_result['rounds'][index]
        expected_input = [original_round['pending'], original_round['draft']]
        assert record['inputs'] == expected_input
        assert record['first_position'] == len(expected_prefix) == original_round['target_before']
        expected_prefix.extend(expected_input[:original_round['committed_target_rows']])
        assert record['selected_rows'] == original_round['committed_target_rows']
        assert record['after_trim'] == len(expected_prefix) == original_round['target_after']
        # A T2 observation records both evaluated rows even when only row0 is
        # committed. The separate prefix records post-trim logical history.
        assert record['committed_prefix_ids'] == expected_prefix
        assert record['expected_original_ids'] == original_round['target_ids']
        assert record['ids_match_original'] == (record['native_ids'] == original_round['target_ids'])
        replay_proof.append(dict(original_round=index, inputs=expected_input,
            selected_rows=record['selected_rows'], context_before=record['first_position'],
            context_after=record['after_trim'], native_ids=record['native_ids'],
            original_native_ids=original_round['target_ids'],
            native_ids_match=record['native_ids'] == original_round['target_ids']))
    assert len(expected_prefix) == 171
    assert shape['checkpoint_prefix_ids'] == expected_prefix
    assert row0prefix == expected_prefix + [11906]

    run_identity = read(args.run / 'identity.json')
    source_path = Path(run_identity['source']['path'])
    actual_source = identity(source_path)
    assert actual_source['sha256'] == run_identity['source']['sha256']
    source_freeze_path = W / 'control2/source-freeze.json'
    source_freeze = read(source_freeze_path)
    assert actual_source['sha256'] == source_freeze['source']['sha256']
    checkpoint_files = [directory / 'C.full-state.bin', directory / 'B165.full-state.bin',
                         directory / 'C171.full-state.bin']
    original_rows_match = all(r['byte_equal'] for r in anchors)
    same_shape_equal = live['byte_equal'] and hidden['byte_equal'] and all(
        s['byte_equal'] for s in state['by_kind'].values())
    report = dict(
        scope='One-model/one-target-RS1 extension, raw offline analysis only. No numerical quality threshold or inference execution.',
        checker=identity(Path(__file__)), typed_reader=identity(Path(__file__).with_name('read_partial_state.py')),
        run=proof, source=actual_source, source_freeze=identity(source_freeze_path),
        old_control_run=oldproof, original_peer_on_run=originalproof,
        checkpoints=[identity(p) for p in checkpoint_files],
        original_trajectory_anchors=dict(
            exact_original_row_matches=original_rows_match, row_comparisons=anchors,
            original_control1_vs_round5=original_control_recheck,
            current_control2_vs_control1_round5=control1_to_control2,
            C171_replay=replay_proof,
            criterion='Each row must have the same actual evaluated token prefix and complete candidate permutation. Exact raw logits, not just ID, establish this finite trajectory anchor.'),
        rollback_live_vs_canonical=dict(
            setup='B165 full NONE is exported after trim without resetting the live path. Live B continues T1[51338]. A later restore of that same fullB165 supplies the identical T1 input.',
            logits=live, hidden=hidden, recurrent_state=state,
            all_published_boundaries_byte_equal=same_shape_equal,
            finite_equal_R_blocks=sum(r['name'].startswith('R') and r['byte_equal'] and r['finite_left'] and r['finite_right'] for r in state['by_layer']),
            finite_equal_S_blocks=sum(r['name'].startswith('S') and r['byte_equal'] and r['finite_left'] and r['finite_right'] for r in state['by_layer']),
            meaning=('No observable live-pending-vs-restored difference at this tested165→166 boundary; this finite result does not prove every rollback or hidden internal field correct.' if same_shape_equal else
                     'An observable difference remains between same-shape live-pending and full-restored paths. This control alone does not locate the cause or establish a quality failure.')),
        C171_same_checkpoint_shape=dict(
            setup='Same immutable C171 full NONE checkpoint restored separately before T1[11906] and T2[11906,271]. Compare only row0 with identical actual token prefix.',
            logits=at171, hidden=hidden171,
            original_T2_both_rows_exact=all(r['byte_equal'] for r in anchors if r['control'].startswith('C171')),
            argmax_changes=not at171['native_ids_equal'],
            original_anchored_shape_sufficient_to_change_choice=original_rows_match and not at171['native_ids_equal'],
            meaning=('With both original T2 row logits reproduced exactly, changing T1/T2 geometry alone from this same serialized RS1 checkpoint changes the selected row0 ID.' if original_rows_match and not at171['native_ids_equal'] else
                     'This result does not establish that T1/T2 geometry alone explains the originally observed choice; inspect exact reproduction and row0 IDs above.'),
            excluded_row1=dict(proof=row1proof, reason='Different evaluated token prefix: includes271. Not compared to T1 row0.')),
        limits=[
            'State serialization get may synchronize, but no set occurs between the live B trim and its next T1. Canonical restoration is a separately labelled later branch.',
            'The full checkpoints are provenance-bound opaque data. Only validated typed PARTIAL_ONLY R/S segments are interpreted numerically.',
            'Same-context T1/T2 includes normal shape-dependent kernel/capture selection; no native algorithm, rounding, precision, or sampler policy is changed.',
            'A finite matched result narrows this tested explanation; it is not a universal recurrent-state proof, quality acceptance, or permission to alter logits after the fact.',
            'No rejected/counterfactual row is compared against a different actual input prefix. No Torch, model calculation, native build, GPU operation, or old frozen report modification is performed.'
        ])
    args.output.write_text(json.dumps(report, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')
    print(json.dumps(dict(output=str(args.output), original_row_logits_exact=original_rows_match,
        rollback_boundaries_byte_equal=same_shape_equal,
        live_vs_restored_logits={k:v for k,v in live.items() if k not in ('left','right','left_summary','right_summary')},
        C171=dict(T1=at171['left_summary'], T2=at171['right_summary'],
            original_anchored_shape_changes_choice=report['C171_same_checkpoint_shape']['original_anchored_shape_sufficient_to_change_choice'])), indent=2))


if __name__ == '__main__':
    main()
    assert 'torch' not in sys.modules
