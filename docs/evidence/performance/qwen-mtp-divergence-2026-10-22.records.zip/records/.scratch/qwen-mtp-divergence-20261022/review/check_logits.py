"""Offline full-vocabulary comparison at actual evaluated prefixes; no inference."""
from __future__ import annotations
import hashlib
import json
from pathlib import Path
import sys
import numpy as np

W=Path(__file__).resolve().parents[1]
V=W.parent/'qwen-mtp-window-20261022'
N=248320

def unique(pairs):
    result={}
    for key,value in pairs:
        if key in result:raise ValueError('duplicate JSON key: '+key)
        result[key]=value
    return result

def read(path):return json.loads(path.read_text(encoding='utf-8-sig'),object_pairs_hook=unique)
def identity(path):
    raw=path.read_bytes();return dict(path=str(path.resolve()),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def prefix_id(ids):return dict(rows=len(ids),sha256_I32_LE=hashlib.sha256(np.asarray(ids,dtype='<i4').tobytes()).hexdigest(),last12=ids[-12:])

def rne_bf16(x):
    x=np.ascontiguousarray(x,dtype='<f4');bits=x.view('<u4')
    if not np.isfinite(x).all():raise ValueError('this finite RNE comparison does not accept NaN/Inf')
    words=((bits+np.uint32(0x7fff)+((bits>>16)&1))>>16).astype('<u2')
    return (words.astype('<u4')<<16).view('<f4')

def summary(x):
    assert x.shape==(N,) and np.isfinite(x).all()
    top=np.lexsort((np.arange(N),-x))[:5]
    rounded=rne_bf16(x)
    return dict(elements=N,finite=True,first_argmax=int(top[0]),top5=[dict(id=int(i),score=float(x[i]))for i in top],
                top2_margin=float(np.float64(x[top[0]])-np.float64(x[top[1]])),
                logit11=float(x[11]),logit271=float(x[271]),margin11_minus271=float(np.float64(x[11])-np.float64(x[271])),
                BF16_RNE=dict(logit11=float(rounded[11]),logit271=float(rounded[271]),same_11_271=bool(rounded[11]==rounded[271]),
                              full_vocab_first_argmax=int(rounded.argmax()),
                              scope='Offline descriptive postprocessing only; not the native algorithm or a proposed alteration.'))

def metrics(a,b):
    a,b=a.astype(np.float64),b.astype(np.float64);delta=a-b;an=np.linalg.norm(a);bn=np.linalg.norm(b)
    return dict(elements=N,all_finite=True,byte_equal=a.astype('<f4').tobytes()==b.astype('<f4').tobytes(),
                mismatched_elements=int(np.count_nonzero(a!=b)),maxabs=float(np.abs(delta).max()),
                relative_L2=float(np.linalg.norm(delta)/bn)if bn else None,cosine=float(a@b/(an*bn))if an and bn else None)

def peer(mode):
    folder=W/f'peer-{mode}-run1';terminal=read(folder/'run.result.json');assert terminal['terminal']and terminal['exit']==0
    raw=read(folder/'consumer-result.json');rows=[]
    original=(V/'performance/timing'/('04-peer_mtp'if mode=='on'else'03-peer_plain')/'consumer-result.json')
    old=read(original)
    assert raw['generated_ids']==old['generated_ids'][:len(raw['generated_ids'])]
    # Original diagnostic adds records but must retain protocol/token fields.
    for a,b in zip(raw['rounds'],old['rounds']):
        for key in ('pending','draft','target_ids','accepted_draft','emitted','target_before','target_after','draft_before','draft_after','lag_after'):
            assert a[key]==b[key]
    for path in sorted((folder/'diagnostic').glob('*.json')):
        record=read(path);assert record['full_vocabulary']and record['status']=='full_finite'
        p=folder/'diagnostic'/record['raw_logits']['file'];cp=folder/'diagnostic'/record['raw_candidates']['file']
        x=np.frombuffer(p.read_bytes(),'<f4');ids=np.frombuffer(cp.read_bytes(),'<i4')
        assert len(x)==len(ids)==N and np.isfinite(x).all() and np.array_equal(np.sort(ids),np.arange(N))
        mapped=np.empty(N,dtype='<f4');mapped[ids]=x
        arg=int(ids[int(x.argmax())]);stable_arg=int(mapped.argmax())
        assert arg==stable_arg==record['native_sampled_id']==record['cpu_argmax']['token']
        actual=record['evaluated_prefix_ids'];assert len(actual)==record['evaluated_prefix_rows']
        if record['name']=='prefill':
            assert actual==raw['prompt_ids'] and record['native_sampled_id']==raw['prefill_first_id']
        else:
            r=raw['rounds'][record['round_index']]
            committed=list(raw['prompt_ids'])
            for prev in raw['rounds'][:record['round_index']]:
                inputs=[prev['pending']]+([]if prev['single']else[prev['draft']])
                committed.extend(inputs[:prev['committed_target_rows']])
            evaluated=committed+[r['pending']]
            if record['original_batch_row']==1:evaluated.append(r['draft'])
            assert evaluated==actual
            assert record['native_sampled_id']==r['target_ids'][record['original_batch_row']]
            at=1+sum(prev['committed_target_rows']for prev in raw['rounds'][:record['round_index']])
            assert record['generated_offset_before']==at
            if record['original_batch_row']<r['committed_target_rows']:
                assert raw['generated_ids'][at+record['original_batch_row']]==record['native_sampled_id']
        for token in (11,271):assert float(mapped[token])==record['watched_logits'][str(token)]['value']
        rows.append(dict(label='peer_'+mode+':'+record['name'],source=identity(p),candidates=identity(cp),metadata=identity(path),
                         prefix=actual,array=mapped,original_batch_row=record['original_batch_row'],
                         rejected_row1=(record['name']!='prefill'and record['original_batch_row']==1 and not raw['rounds'][record['round_index']]['accepted_draft']),
                         candidate_mapping_identity=bool(np.array_equal(ids,np.arange(N))),native_argmax=arg,**summary(mapped)))
    return rows,dict(terminal=identity(folder/'run.result.json'),result=identity(folder/'consumer-result.json'),original_window=identity(original),
                     generated_ID_prefix_matches_original=True,protocol_fields_match_original=True)

def hyle():
    folder=W/'hyle-trace1';raw=read(folder/'run.stdout.log');terminal=read(folder/'run.result.json')
    assert terminal['terminal']and terminal['exit']==0
    original=json.loads((V/'performance/timing/02-hyle_mtp/stdout.log').read_text(encoding='utf-8'),object_pairs_hook=unique)
    assert raw['generated_ids']==original['generated_ids'][:20]and raw['rounds'][:10]==original['rounds'][:10]
    prompt=read(V/'inputs/input.json')['prompt_ids'];rows=[]
    for name,index in [('prefill',None),('mtp6',5),('mtp7',6),('mtp10',9)]:
        path=folder/'trace'/name/'logits.f32';x=np.frombuffer(path.read_bytes(),'<f4').reshape(-1,N)
        if index is None:prefixes=[prompt];expected=[raw['generated_ids'][0]];rejected=[False]
        else:
            committed=list(prompt)
            for r in raw['rounds'][:index]:committed.extend([r['pending'],r['draft']][:r['committed_target_rows']])
            r=raw['rounds'][index];prefixes=[committed+[r['pending']],committed+[r['pending'],r['draft']]]
            expected=[r['target_first'],r['target_second']];rejected=[False,not r['accepted_draft']]
        assert len(x)==len(prefixes)
        for i,(array,prefix)in enumerate(zip(x,prefixes)):
            assert int(array.argmax())==expected[i]
            rows.append(dict(label=f'hyle:{name}:row{i}',source=identity(path),slice_row=i,prefix=prefix,array=array,
                             original_batch_row=i,rejected_row1=rejected[i],native_argmax=expected[i],**summary(array)))
    return rows,dict(terminal=identity(folder/'run.result.json'),stdout=identity(folder/'run.stdout.log'),prior_review=identity(W/'review/hyle-trace-review.json'),
                     generated_ID_prefix20_and_first10_rounds_match=True)

def main():
    on,onproof=peer('on');off,offproof=peer('off');hy,hyproof=hyle();allrows=on+off+hy
    pairs=[];excluded=[]
    for left,right in [(a,b)for a in on for b in off]+[(a,b)for a in hy for b in on]+[(a,b)for a in hy for b in off]:
        if left['prefix']!=right['prefix']:
            if len(left['prefix'])==len(right['prefix'])and(left['rejected_row1']or right['rejected_row1']):
                excluded.append(dict(left=left['label'],right=right['label'],reason='different actual evaluated prefix; no numeric comparison',
                                     left_prefix=prefix_id(left['prefix']),right_prefix=prefix_id(right['prefix'])))
            continue
        pairs.append(dict(left=left['label'],right=right['label'],actual_prefix=prefix_id(left['prefix']),
                          native_IDs_equal=left['native_argmax']==right['native_argmax'],**metrics(left['array'],right['array'])))
    key={r['label']:r for r in allrows}
    watch=[key[name]for name in ('hyle:mtp10:row0','peer_on:round_9_row_0','peer_off:round_17_row_0')]
    assert watch[0]['prefix']==watch[1]['prefix']==watch[2]['prefix']
    assert all(r['BF16_RNE']['logit11']==r['BF16_RNE']['logit271']==23.75 for r in watch)
    for row in allrows:
        row['actual_evaluated_prefix']=prefix_id(row.pop('prefix'));row.pop('array')
    result=dict(status='independent diagnostic raw logits/prefix/mapping comparison; no inference or quality threshold',
                checker=identity(Path(__file__)),runs=dict(Hyle=hyproof,peer_on=onproof,peer_off=offproof),
                rows=allrows,same_actual_prefix_comparisons=pairs,excluded_different_prefix_pairs=excluded,
                first_divergence=dict(zero_based_output_index=18,one_based_output_index=19,pending=11906,target_position=171,
                                      watched_rows=[{k:r[k]for k in ('label','native_argmax','logit11','logit271','margin11_minus271','top2_margin','BF16_RNE')}for r in watch]),
                findings=['All archived diagnostic F32 rows are finite; full candidate permutations and raw->token mapping independently checked. Original native ID equals independent CPU argmax for every captured row.',
                          'Actual evaluated prefixes are reconstructed from committed input tokens plus the current evaluated row, not from returned IDs alone. Rejected row1 is never compared to plain at its different committed prefix.',
                          'At the first divergent position, native MTP raw F32 score271 exceeds11; plain native has11 above271. Hyle original BF16-head scores tie at23.75 and select lower ID11. This is a true recorded target-score/ranking difference, not a simple returned-array off-by-one.',
                          'Offline round-to-nearest-even converts both watched native scores to23.75 for both on and off. That descriptive fact does not reproduce the earlier BF16 model computation or prove that all hidden/state values were correct.',
                          'A posthoc BF16-rounded argmax is explicitly not the native algorithm, not a proposed accuracy fix, and is not fed back into acceptance/state. Same checkpoint RS1 controls are still needed if root wants to separate arithmetic/geometry from restoration effects.'],
                limitations=['Only the captured finite rows and identical evaluated input prefixes are compared. Same token prefix does not prove equal underlying recurrent payload.',
                             'Target T1/RS0/plain output mode differs from native MTP T2/RS1/hidden export. Near-tie observations alone do not rule out state drift.',
                             'No timing, broad model quality or corrected algorithm claim. No new GPU, model execution, Torch or build.'],
                activity=dict(new_GPU_runs=0,model_computation=0,Torch_imports=0,builds=0,product_edits=0,raw_data_edits=0))
    assert 'torch'not in sys.modules
    output=W/'review/logit-comparison.json';output.write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
    print(json.dumps(dict(output=str(output),rows=len(allrows),matched_prefix_pairs=len(pairs),first_divergence=result['first_divergence']),indent=2))

if __name__=='__main__':main()
