"""Independent offline raw-result/sample reconciliation for W's carrier window.

Reuse V's separately authored audit arithmetic, not performance.py or its parser.
No model/tokenizer/Torch, native program, build, GPU query or old-file writes.
"""
from __future__ import annotations

from collections import Counter
import importlib.util
import json
from pathlib import Path
import sys

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parents[1]
ROOT = W.parents[1]
V = ROOT / ".scratch/qwen-mtp-window-20261022"
AUDIT_PATH = V / "review/analyze_window.py"
spec = importlib.util.spec_from_file_location("frozen_independent_V_arithmetic", AUDIT_PATH)
a = importlib.util.module_from_spec(spec)
spec.loader.exec_module(a)
ARMS = ("before_MTP", "after_MTP", "peer_MTP")


def main() -> None:
    input_record = a.read(V / "inputs/input.json")
    assert input_record["prompt_tokens"] == 154 and input_record["capacity"] == 1024
    timing_plan = a.read(W / "performance/timing/inputs.json")
    memory_plan = a.read(W / "performance/memory/inputs.json")
    records, raw_by_arm, first_ids = [], {arm: [] for arm in ARMS}, {}
    positions_by_arm = {arm: [] for arm in ARMS}
    for command in timing_plan["commands"]:
        folder = Path(command["folder"])
        receipt = a.read(folder / "result.json")
        assert receipt["command"] == command["command"] and receipt["image"] == command["image"]
        assert not receipt["memory_only"] and receipt["throughput_evidence"]
        raw, _ = a.raw_result(folder)
        row, positions = a.timing_row(folder, "peer_mtp" if command["arm"] == "peer_MTP" else "hyle_mtp", 154)
        row["arm"] = command["arm"]
        raw_by_arm[row["arm"]].append(raw)
        positions_by_arm[row["arm"]].append(positions)
        records.append(row)
    assert len(records) == 9
    groups = {}
    for arm in ARMS:
        own = [r for r in records if r["arm"] == arm]
        assert len(own) == 3 and all(x["ids"] == own[0]["ids"] and x["work"] == own[0]["work"] for x in own)
        first_ids[arm] = own[0]["ids"]
        assert all(positions == positions_by_arm[arm][0] for positions in positions_by_arm[arm])
        if arm != "peer_MTP":  # Peer rounds additionally include native call clocks.
            assert all(raw["rounds"] == raw_by_arm[arm][0]["rounds"] for raw in raw_by_arm[arm])
        groups[arm] = dict(metrics={key: a.stats([r["metrics"][key] for r in own])
                                   for key in own[0]["metrics"]}, work=own[0]["work"],
                           within_arm_all64_IDs_and_rounds_equal=True)
    assert first_ids["before_MTP"] == first_ids["after_MTP"]
    assert raw_by_arm["before_MTP"][0]["rounds"] == raw_by_arm["after_MTP"][0]["rounds"]
    assert groups["before_MTP"]["work"] == groups["after_MTP"]["work"]
    memories = {}
    for command in memory_plan["commands"]:
        arm, folder = command["arm"], Path(command["folder"])
        receipt = a.read(folder / "result.json")
        assert receipt["command"] == command["command"] and receipt["image"] == command["image"]
        raw, _ = a.raw_result(folder)
        work, positions = a.ledger(raw, 154, "peer_mtp" if arm == "peer_MTP" else "hyle_mtp")
        assert raw["generated_ids"] == first_ids[arm] and work == groups[arm]["work"]
        assert positions == positions_by_arm[arm][0]
        if arm != "peer_MTP":
            assert raw["rounds"] == raw_by_arm[arm][0]["rounds"]
        memories[arm] = a.memory_row(folder)
    assert len(memories) == 3
    # Summary matching is a check after raw-derived arithmetic, not its input.
    summary = a.read(W / "performance/timing/summary.json")
    metric_names = dict(prefill_tps="prefill_tokens_per_second", full_decode_tps="full_decode_tokens_per_second",
        session_output_tps="session_output_tokens_per_second", session_processed_target_tps="session_processed_tokens_per_second",
        load_seconds="weights_load_seconds", ready_seconds="startup_to_ready_seconds",
        startup_TTFT_seconds="first_token_elapsed_seconds", startup_endpoint_seconds="startup_to_endpoint_seconds",
        cold_output_tps="cold_output_tokens_per_second")
    for arm in ARMS:
        for key, ours in groups[arm]["metrics"].items():
            original = summary["groups"][arm][metric_names.get(key, key)]
            assert all(a.close(ours[k], original[k]) for k in ("median", "min", "max"))
    changes = {key: 100 * (groups["after_MTP"]["metrics"][key]["median"] /
                           groups["before_MTP"]["metrics"][key]["median"] - 1)
               for key in groups["after_MTP"]["metrics"]}
    memory_delta = {key: memories["after_MTP"]["sampled_peak_bytes"][key] -
                         memories["before_MTP"]["sampled_peak_bytes"][key] for key in a.KEYS}
    captures = {arm: {key: a.stats([r["prepare_capture"]["totals"][key] for r in records if r["arm"] == arm])
                      for key in ("recorded", "reused", "cold_batch_seconds")}
                for arm in ARMS[:2]}
    for arm in captures:
        captures[arm]["decode_cold_batch_seconds"] = a.stats([
            r["prepare_capture"]["decode_cold_batch_seconds_sum"] for r in records if r["arm"] == arm])
    mismatch = next(i for i, (x, y) in enumerate(zip(first_ids["after_MTP"], first_ids["peer_MTP"])) if x != y)
    assert mismatch == 18 and first_ids["after_MTP"][mismatch] == 11 and first_ids["peer_MTP"][mismatch] == 271
    before_ready = a.read(V / "qwen-ready-attempt1.json")
    after_ready = a.read(W / "qwen-ready-attempt1.json")
    before_link = a.read(before_ready["link_plan"]["path"])
    after_link = a.read(after_ready["link_plan"]["path"])
    assert len(before_link["inputs"]) == len(after_link["inputs"]) == 195
    encode = lambda x: (x["path"], x["bytes"], x["sha256"])
    before_set = Counter(map(encode, before_link["inputs"]))
    after_set = Counter(map(encode, after_link["inputs"]))
    removed, added = list((before_set - after_set).elements()), list((after_set - before_set).elements())
    assert len(removed) == len(added) == 1 and removed[0][0].endswith("qwen.obj") and added[0][0].endswith("qwen.obj")
    report = dict(status="independent offline raw nine-timing/three-memory carrier-window review; all assertions pass",
        checker=a.identity(Path(__file__)), reused_independent_arithmetic=a.identity(AUDIT_PATH),
        workload=dict(P=154, outputs=64, C=1024, N=1, R=1, MTP=True, prefix=False, trace=False,
                      fresh_timing_processes_per_arm=3, independent_memory_processes_per_arm=1),
        timing_plan=a.identity(W / "performance/timing/inputs.json"),
        memory_plan=a.identity(W / "performance/memory/inputs.json"), per_process=records,
        groups=groups, before_to_after_median_percent=changes, independent_memory=memories,
        before_to_after_memory_peak_delta_bytes=memory_delta,
        capture_and_cold_across_three=captures,
        numerical_regression=dict(before_after_all64_IDs_equal=True, raw_round_ledgers_equal=True,
            actual_work_frontier_lag_counts_equal=True, independent_memory_processes_match_own_timing_arm=True,
            total_completed_processes=12, not_a_hidden_or_full_quality_claim=True),
        peer_different_output=dict(first_zero_based=mismatch, first_one_based=mismatch + 1,
            Hyle_ID=11, peer_ID=271, scope="Original V peer image. This timing comparison does not include W's logits/control diagnostics and makes no new cause claim."),
        implementation_binding=dict(before_ready=a.identity(V / "qwen-ready-attempt1.json"),
            after_ready=a.identity(W / "qwen-ready-attempt1.json"),
            original_peer_ready=a.identity(V / "peer-ready-attempt1.json"),
            before_image=before_ready["image"], after_image=after_ready["image"],
            before_main=before_ready["source"], after_main=after_ready["source"],
            link_inputs_each=195, unchanged_inputs=194, removed_main_object=removed, added_main_object=added,
            only_source_change=a.identity(W / "carrier-implementation.diff"),
            lazy_real_case_review=a.identity(W / "review/lazy-cases-review.json"),
            large_images_SDKs_models_not_rehashed=True),
        conclusions=["Full decode medians/ranges overlap; this window does not establish a speed improvement.",
            "Measured startup/ready medians are lower and sampled GPU/CPU peaks are lower in this finite window. Keep samples/ranges and the required cold work; do not equate sampled peak deltas to exact allocator savings.",
            "Both Hyle arms still report18 recorded/50 reused ranges. Lazy unused carriers do not establish reduced runtime capture count or native topology changes.",
            "All64 Hyle before/after IDs and all actual rounds/work match. Peer MTP differs after18 shared IDs; its speed is descriptive for a different generated continuation."],
        limits=["Per-process ratios then median/min/max, never pooled or mixed with V's historical window.",
            "Independent memory timing never contributes to throughput. Ready sampled baseline may be unknown; null is not zero.",
            "Same-sample GPU total recomputed for each sample, not sum of dedicated/shared separate peaks. Peaks are sampled attributed WDDM/PSAPI values, not direct physical allocation limits.",
            "Phase receipt markers are approximate external sampling boundaries; negative bracket deltas may include teardown.",
            "No hardware isolation/fixed clocks/statistical significance/full quality or multi-session MTP claim."],
        activity=dict(GPU_runs=0, model_runs=0, builds=0, product_edits=0, old_raw_or_V_edits=0))
    out = W / "review/carrier-window-analysis.json"
    out.write_text(json.dumps(report, ensure_ascii=False, indent=2, allow_nan=False) + "\n", encoding="utf-8")
    print(json.dumps(dict(report=a.identity(out), metrics={arm: {k: v["median"] for k, v in g["metrics"].items()}
                          for arm, g in groups.items()}, percent=changes, memory_delta=memory_delta), indent=2))


if __name__ == "__main__":
    main()
