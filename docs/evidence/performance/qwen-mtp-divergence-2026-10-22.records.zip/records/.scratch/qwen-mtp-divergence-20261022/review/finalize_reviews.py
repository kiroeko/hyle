"""Freeze only this offline/source-review deliverable; does not edit raw runs."""
from pathlib import Path
import ast
import hashlib
import json

W = Path(__file__).resolve().parents[1]
R = W / 'review'
N = W.parent / 'architecture-refactor-2026-10-18/llama-matched-consumer/source'


def read(p):
    return json.loads(p.read_text(encoding='utf-8-sig'))


def identity(p):
    data = p.read_bytes()
    return dict(path=str(p.resolve()), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())


def write(p, data):
    p.write_text(json.dumps(data, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')


source = W / 'control/control_peer.cc'
frozen = read(W / 'control/source-freeze.json')
assert identity(source)['sha256'] == frozen['source']['sha256']
text = source.read_text(encoding='utf-8')
assert text.count('    restore();') == 2
assert text.count('llama_state_seq_set_data_ext(') == 1
between = text.split('    trim(context, base + 1);', 1)[1].split('    auto b_next = control_decode', 1)[0]
assert 'save_partial(' in between and 'llama_state_seq_set_data_ext(' not in between
runtime_identity = read(W / 'control-run1/identity.json')
assert runtime_identity['source']['sha256'] == frozen['source']['sha256']
terminal = read(W / 'control-run1/run.result.json')
assert terminal['terminal'] and terminal['exit'] == 0

report = dict(
    status='No blocking source finding in this narrow control; actual execution is bound separately. No model-quality/state-correctness acceptance.',
    source=identity(source), source_freeze=identity(W / 'control/source-freeze.json'),
    diff=identity(W / 'control/control.diff'), runtime_identity=identity(W / 'control-run1/identity.json'),
    observed_image=runtime_identity['image'], terminal=identity(W / 'control-run1/run.result.json'),
    reviewed=[
        dict(anchor='control_peer.cc:264-288', finding='state_bytes synchronizes and checks exact native get size. Partial export is get-only; source never restores a partial blob.'),
        dict(anchor='control_peer.cc:291-313', finding='Each decode uses original native Batch/GPU greedy, captures every returned row, and appends only actual input tokens to the evaluated-prefix record.'),
        dict(anchor='control_peer.cc:315-347', finding='Exact 154-token prompt/natural first5/prefix164/draftfrontier165 witness is checked. One immutable full-NONE checkpoint vector supplies exactly two restores into the same target context.'),
        dict(anchor='control_peer.cc:347-357', finding='B evaluates [11,36760], trims to165, exports PARTIAL_ONLY, then evaluates fixed51338 without state_set/clear/context rebuild in between. A uses T1[11] then the same fixed51338.'),
        dict(anchor='control_peer.cc:538-551', finding='One hook occurs after natural first5 and current draft calculation, before original target round5 decode. The program returns after the target-only control; stale host carry/prior/draft context is not resumed as a natural MTP round.'),
        dict(anchor='llama-context.cpp:4199-4212; llama-memory-recurrent.cpp:766-875', finding='Size query does not itself synchronize. Data get does synchronize, selects logical rs_idx source planes and is const; only state read resets rollback index. The control explicitly synchronizes before size and uses no set after B trim.'),
        dict(anchor='llama-memory-recurrent.cpp:897-989; llama-memory-hybrid.cpp:190-202', finding='PARTIAL_ONLY omits attention memory and serializes all R blocks then all S blocks. Fixed reader validates seq0/cell1/24layers/F32 extents/transposition/EOF and never compares opaque headers as numerical state.')
    ],
    exclusions=[
        'T1 vs T2 changes native computation geometry, so this control does not distinguish all shape-dependent numerical error from state rollback error.',
        'Observed IDs agree and payloads are finite, but R/S/hidden/logits are unequal; this is descriptive evidence, not a claim that state rollback is correct.',
        'The raw rejected B row1 has a different token prefix from the shared next-T1 input and is excluded from that numerical comparison.',
        'Full memory serialization does not include host carry/prior, pending sampler output, output hidden/logits or independent draft memory. This diagnostic deliberately does not resume those objects.',
        'No GPU, native compilation, model calculation or source modification was performed by this reviewer.'
    ],
    inspected_native_sources=[identity(N / 'src' / name) for name in
        ('llama-context.cpp', 'llama-memory-recurrent.cpp', 'llama-memory-hybrid.cpp')],
    prior_source_contract=identity(R / 'rs1-control-design.json'),
    actual_typed_comparison=identity(R / 'rs1-control-comparison.json'))
write(R / 'control-source-review.json', report)

for name in ('check_logits.py', 'read_partial_state.py', 'finalize_reviews.py'):
    ast.parse((R / name).read_text(encoding='utf-8'), filename=name)
files = [identity(R / name) for name in ('check_logits.py', 'logit-comparison.json',
    'read_partial_state.py', 'rs1-control-comparison.json', 'control-source-review.json', 'finalize_reviews.py')]
freeze = dict(status='Frozen offline NumPy/raw-source review; raw data unchanged; 0 build / 0 GPU / 0 Torch model computation.',
    files=files,
    rerun=[
        'python .scratch/qwen-mtp-divergence-20261022/review/check_logits.py',
        'python .scratch/qwen-mtp-divergence-20261022/review/read_partial_state.py --run .scratch/qwen-mtp-divergence-20261022/control-run1 --output .scratch/qwen-mtp-divergence-20261022/review/rs1-control-comparison.json',
        'python .scratch/qwen-mtp-divergence-20261022/review/finalize_reviews.py'],
    limits='No posthoc numerical threshold, quality PASS, rollback-correctness claim, native algorithm change, or performance conclusion.')
write(R / 'independent-review-freeze.json', freeze)
print(json.dumps(dict(freeze=identity(R / 'independent-review-freeze.json'), files=files), indent=2))
