"""Check the real trace prefix and full-vocabulary original Hyle output rows."""
from pathlib import Path
import array,hashlib,json,math
W=Path(__file__).resolve().parents[1];V=W.parent/'qwen-mtp-window-20261022';N=248320
def read(p):return json.loads(p.read_text(encoding='utf-8-sig').splitlines()[-1])
def identity(p):
 raw=p.read_bytes();return dict(path=str(p.resolve()),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
a=read(W/'hyle-trace1/run.stdout.log');b=read(V/'performance/timing/02-hyle_mtp/stdout.log')
assert a['generated_ids']==b['generated_ids'][:20]
assert a['rounds'][:10]==b['rounds'][:10]
rows=[]
for name in ('prefill','mtp6','mtp7','mtp10'):
 p=W/'hyle-trace1/trace'/name/'logits.f32';v=array.array('f');v.frombytes(p.read_bytes());assert len(v)%N==0
 for row in range(len(v)//N):
  values=v[row*N:(row+1)*N];assert all(map(math.isfinite,values))
  top=sorted(range(len(values)),key=lambda x:(-values[x],x))[:5]
  rows.append(dict(name=name,row=row,n=N,source=identity(p),top5=[dict(id=x,score=values[x])for x in top],logit11=values[11],logit271=values[271],margin11_minus271=values[11]-values[271]))
report=dict(checker=identity(Path(__file__)),diagnostic=True,throughput_evidence=False,
 compiled_source_record=json.loads((V/'qwen-ready-attempt1.json').read_text())['source'],
 source_snapshot=identity(W/'before/tools/qwen35_text/main.cc'),
 original_window=identity(V/'performance/timing/02-hyle_mtp/stdout.log'),new_run=identity(W/'hyle-trace1/run.stdout.log'),
 original64_ID_prefix_20_equal=True,first10_rounds_equal=True,
 limit='Trace20 vs timing64 only compares the first10 rounds before quota changes selection. Auto replay is prefer-capture for the same roles; all original prefix results are actually checked. Not a timing sample or general numerical quality test.',
 math_graph_outputs='Model always publishes logits/hidden; trace only exports original outputs after finish. No layer0 probe used.',rows=rows)
(W/'review/hyle-trace-review.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(dict(rows=len(rows),round9=next(x for x in rows if x['name']=='mtp10'and x['row']==0)),indent=2))
