"""Freeze the additional finite control without editing earlier review files."""
from pathlib import Path
import ast
import json

from read_partial_state import identity, read

R = Path(__file__).resolve().parent
W = R.parent
report = read(R / 'extension-comparison.json')
same = report['rollback_live_vs_canonical']
shape = report['C171_same_checkpoint_shape']
assert report['original_trajectory_anchors']['exact_original_row_matches']
assert all(r['byte_equal'] for r in report['original_trajectory_anchors']['original_control1_vs_round5'])
assert all(r['byte_equal'] for r in report['original_trajectory_anchors']['current_control2_vs_control1_round5'])
assert all(r['native_ids_match'] for r in report['original_trajectory_anchors']['C171_replay'])
assert same['all_published_boundaries_byte_equal']
assert same['recurrent_state']['whole_blob_byte_equal']
assert same['finite_equal_R_blocks'] == same['finite_equal_S_blocks'] == 18
assert shape['original_T2_both_rows_exact']
assert shape['original_anchored_shape_sufficient_to_change_choice']
for name in ('check_extension.py', 'freeze_extension.py'):
    ast.parse((R / name).read_text(encoding='utf-8'), filename=name)
previous = read(R / 'independent-review-freeze.json')
assert all(identity(Path(entry['path']))['sha256'] == entry['sha256'] for entry in previous['files'])

freeze = dict(
    status='Frozen independent extension. All conclusions are specific to this actual control2 run; no product or old review modification.',
    files=[identity(R / name) for name in ('check_extension.py', 'extension-comparison.json', 'freeze_extension.py')],
    source=report['source'], source_freeze=report['source_freeze'],
    actual_run=report['run'], previous_frozen_review=identity(R / 'independent-review-freeze.json'),
    confirmed_finite_findings=[
        'C164 control T2 rows0/1 exactly reproduce original peer-on round5 logits; C171 control T2 rows0/1 exactly reproduce original round9 logits, with identical actual evaluated prefixes and complete candidate maps.',
        'After the first rejection, live pending rollback and restore-of-fullB165 followed by identical T1[51338] give byte-identical hidden, all248320 logits, all18 R and18 S payloads, and the complete PARTIAL_ONLY blob. This finite case exposes no additional pending-recovery error at165→166.',
        'The exact same C171 serialized RS1 checkpoint yields T1 row0 ID11 with F32 logits11=logits271=23.793373107910156. T2 row0 yields ID271 with logits11=23.788818359375 and271=23.805431365966797. The T1/T2 shape is sufficient to flip this near-top2 selection in this observed state.'
    ],
    scope_limits=[
        'No general rollback-correctness, full-model-quality, acceptance-rate, or performance claim.',
        'No native algorithm, precision/dtype, graph, or sampling policy was changed. Offline BF16 rounding is descriptive only.',
        'No GPU, build, Torch/model computation, or modification to original raw or previous frozen reports.'
    ],
    rerun=[
        'python .scratch/qwen-mtp-divergence-20261022/review/check_extension.py --run .scratch/qwen-mtp-divergence-20261022/control2-run1 --output .scratch/qwen-mtp-divergence-20261022/review/extension-comparison.json',
        'python .scratch/qwen-mtp-divergence-20261022/review/freeze_extension.py'])
out = R / 'extension-review-freeze.json'
out.write_text(json.dumps(freeze, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')
print(json.dumps(dict(freeze=identity(out), report=identity(R / 'extension-comparison.json')), indent=2))
