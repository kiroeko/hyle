"""Execute the frozen one-TU peer plan against the retained fixed native cache."""
from pathlib import Path
import importlib.util,os,sys
sys.dont_write_bytecode=True
U=Path(__file__).resolve().parent;R=U.parents[1]
sp=importlib.util.spec_from_file_location('build',U/'build.py');h=importlib.util.module_from_spec(sp);sp.loader.exec_module(h);b,c=h.b,h.c
plan_path=U/'control/build-plan.json';plan=c.read(plan_path);plan['retained_native_inputs']=plan['retained_native_input_records_not_rehashed'];out=Path(plan['output_directory'])
assert h.same(plan['source'])and all(h.same(x)for x in plan['retained_native_inputs'])and all(h.same(x)for x in plan['header_identities'])
out.mkdir(parents=True,exist_ok=False);(out/'tmp').mkdir()
command=plan['compile'];env,_=b.environment(command,[],out)
c.save(out/'actual-plan.json',dict(plan=b.identity(plan_path),source=plan['source'],compile_command=command,SDK_builds=0,native_rebuilds=0))
c.execute('compile',command,env,out)
data=c.read(out/'peer-deps.json')['Data'];deps=list(dict.fromkeys([data['Source'],*data['Includes']]))
assert h.same(plan['source'])
record=dict(source=plan['source'],object=b.identity(out/'peer.obj'),command=command,dependencies=[b.identity(x)for x in deps]);c.save(out/'identity.json',record)
command=plan['link'];env,_=b.environment(command,[x['path']for x in plan['retained_native_inputs']],out)
c.save(out/'link-plan.json',dict(command=command,inputs=[record['object'],*plan['retained_native_inputs']],frozen_plan=b.identity(plan_path),SDK_builds=0,native_rebuilds=0))
c.execute('link',command,env,out)
runtime=c.read(R/'.scratch/qwen-cli-batch-20261022/peer/checks/attempt1/runtime-environment.json')
c.save(out/'runtime-environment.json',runtime)
c.save(U/f'control-ready-{out.name}.json',dict(image=b.identity(out/'peer.exe'),source=plan['source'],compiled_identity=b.identity(out/'identity.json'),link_plan=b.identity(out/'link-plan.json'),runtime_environment=b.identity(out/'runtime-environment.json'),SDK_builds=0,native_rebuilds=0))
print('READY one-context RS1 control peer',flush=True)
