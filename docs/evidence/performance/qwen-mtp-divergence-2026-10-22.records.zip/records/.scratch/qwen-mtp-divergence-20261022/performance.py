"""Root-run carrier-only MTP window. Only `run` starts model processes.

The frozen V input/runner/parser/observer are reused read-only. All plans, logs,
observations and summaries are written under W; no V artifact is replaced.
"""
from __future__ import annotations

import argparse
import importlib.util
import json
import os
from pathlib import Path
import re
import sys

sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
ROOT = S.parents[1]
V = ROOT / ".scratch/qwen-mtp-window-20261022"
INPUTS = V / "inputs"
ARMS = ("before_MTP", "after_MTP", "peer_MTP")
EXPECTED_READY = {"before_MTP": V / "qwen-ready-attempt1.json",
                  "after_MTP": S / "qwen-ready-attempt1.json",
                  "peer_MTP": V / "peer-ready-attempt1.json"}
spec = importlib.util.spec_from_file_location("carrier_frozen_V_window", V / "window.py")
base = importlib.util.module_from_spec(spec)
spec.loader.exec_module(base)
base.ARMS = ARMS  # Its generic result parser/summary accepts these exact labels.


def owned_output(path: Path) -> Path:
    path = path.resolve()
    if not path.is_relative_to(S) or path == S:
        raise ValueError("all output must remain in the W stage: " + str(path))
    return path


def plan(config_path: Path, mode: str, output: Path) -> dict:
    output = owned_output(output)
    config = base.read(config_path)
    if set(config["arms"]) != set(ARMS):
        raise ValueError("exactly before_MTP/after_MTP/peer_MTP are required")
    inputs = base.read(INPUTS / "input.json")
    if inputs["prompt_tokens"] != 154 or inputs["requested_output_tokens"] != 64:
        raise ValueError("this is the original V P154/64 window only")
    if base.identity(INPUTS / "prompt.ids") != inputs["inputs"]["prompt"]:
        raise ValueError("frozen V prompt changed")
    manifest = INPUTS / "mtp/weights.tsv"
    if base.identity(manifest) != inputs["inputs"]["manifests"]["mtp"]["weights"]["destination"]:
        raise ValueError("canonical V335 manifest changed")
    original_peer = base.read(V / "arms.json")["arms"]["peer_mtp"]
    order = list(ARMS) if mode == "memory" else [ARMS[(i + round_) % len(ARMS)]
                                                               for round_ in range(3) for i in range(len(ARMS))]
    commands = []
    for ordinal, arm in enumerate(order, 1):
        entry = config["arms"][arm]
        if Path(entry["ready"]).resolve() != EXPECTED_READY[arm].resolve():
            raise ValueError("arm must use its prescribed V/W ready receipt: " + arm)
        ready = base.read(entry["ready"])
        if base.identity(ready["image"]["path"]) != ready["image"]:
            raise ValueError("ready image identity mismatch: " + arm)
        if arm == "peer_MTP" and entry["model"] != original_peer["model"]:
            raise ValueError("peer must use the original V335 model and V image, not W diagnostic peer")
        folder = output / f"{ordinal:02}-{arm}"
        variables = dict(image=ready["image"]["path"], inputs_mtp=str(INPUTS / "mtp"),
                         inputs=str(INPUTS), result=str(folder / "consumer-result.json"),
                         steps="64", capacity="1024", peer_model=entry.get("model", ""))
        command = [p.format_map(variables) for p in entry["command"]]
        if command[0] != ready["image"]["path"]:
            raise ValueError("command must start the exact ready image")
        for flag, value in (("--steps", "64"), ("--capacity", "1024"), ("--mtp", "on")):
            if command.count(flag) != 1 or command[command.index(flag) + 1] != value:
                raise ValueError("actual CLI differs from fixed natural MTP window: " + flag)
        expected_input = variables["inputs"] if arm == "peer_MTP" else variables["inputs_mtp"]
        if command.count("--inputs") != 1 or command[command.index("--inputs") + 1] != expected_input:
            raise ValueError("consumer must read the canonical V input")
        if arm != "peer_MTP":
            for flag, value in (("--max-sessions", "1"), ("--active-sequences", "1"),
                                ("--prefix-cache", "off"), ("--progress", "direct"), ("--replay", "auto")):
                if command.count(flag) != 1 or command[command.index(flag) + 1] != value:
                    raise ValueError("Hyle execution policy differs: " + flag)
        elif "--memory-snapshots" not in command or command[command.index("--memory-snapshots") + 1] != "off":
            raise ValueError("retain original peer memory snapshot policy")
        if any(x in command for x in ("--trace", "--schedule", "--session-schedules", "--decode-ids",
                                       "--ignore-eos", "--layer0-probe")):
            raise ValueError("no diagnostics, forced IDs or synthetic acceptance in timing")
        commands.append(dict(ordinal=ordinal, arm=arm, folder=str(folder), command=command,
                             ready=base.identity(entry["ready"]), image=ready["image"],
                             environment=ready["runtime_environment"]))
    return dict(mode=mode, commands=commands, arm_order=order, configuration=base.identity(config_path),
                input=base.identity(INPUTS / "input.json"), prompt=inputs["inputs"]["prompt"],
                prompt_tokens=154, requested_output_tokens=64, capacity=1024, N=1, R=1,
                timing_processes=9 if mode == "timing" else 0, memory_processes=3 if mode == "memory" else 0,
                independent_memory_processes=True, memory_interval_seconds=0.01, timer=base.timer_info(),
                profiler=False, GPU_concurrency=False, warmup=False, forced_acceptance=False,
                generated_IDs_assumed_equal=False, script=base.identity(Path(__file__)),
                reused_V_script=base.identity(V / "window.py"),
                helpers=[base.identity(base.RUNNER), base.identity(base.OBSERVER)],
                contract="Original P154/64 natural greedy, C1024/N1R1, prefixoff/replayauto. Before/after IDs and round/work ledgers must match. Original V peer_MTP is descriptive if its continuation differs; no quality or same-token cross-engine winner claim.")


def capture_ledger(folder: Path) -> dict:
    matches = re.findall(r"prepared T=(\d+) visible=(\d+) replay=(\S+) cold_batch_seconds=([\d.eE+-]+) "
                         r"capture_recorded=(\d+) capture_reused=(\d+)",
                         (folder / "stderr.log").read_text(encoding="utf-8"))
    rows = [dict(call_index=i, T=int(x[0]), reported_committed_visible=int(x[1]), replay=x[2],
                 cold_batch_seconds=float(x[3]), recorded_ranges=int(x[4]), reused_ranges=int(x[5]))
            for i, x in enumerate(matches)]
    return dict(calls=rows, decode_recorded_ranges=sum(x["recorded_ranges"] for x in rows[1:]),
                decode_reused_ranges=sum(x["reused_ranges"] for x in rows[1:]),
                cold_batch_decode_seconds=sum(x["cold_batch_seconds"] for x in rows[1:]),
                scope="Actual Hyle reported ranges and inclusive cold bucket; peer has no matching counter and remains null.")


def compare_before_after(runs: list[dict]) -> dict:
    hyle = {arm: [r for r in runs if r["arm"] == arm] for arm in ARMS[:2]}
    if not all(hyle.values()):
        return dict(pending=True)
    first = hyle["before_MTP"][0]["observation"]
    for arm, selected in hyle.items():
        for run in selected:
            obs = run["observation"]
            if obs["generated_ids"] != first["generated_ids"] or len(obs["generated_ids"]) != 64:
                raise ValueError("carrier before/after must preserve all64 actual IDs: " + run["folder"])
            if obs["raw"].get("rounds") != first["raw"].get("rounds"):
                raise ValueError("carrier before/after MTP round policy/decisions differ: " + run["folder"])
            if obs["work"] != first["work"]:
                raise ValueError("carrier before/after actual work counters differ: " + run["folder"])
    return dict(pending=False, all64_IDs_equal=True, actual_round_ledgers_equal=True,
                actual_work_counters_equal=True, compared_Hyle_processes=sum(map(len, hyle.values())),
                note="Does not assert hidden/state bit identity or full model quality.")


def analyze(output: Path) -> dict:
    output = owned_output(output)
    # Original V parser retains full endpoints, counters, EOS and all raw fields.
    result = base.analyze(output)
    runs = base.read(output / "runs.json")
    comparison = compare_before_after(runs)
    for run in runs:
        if run["arm"] != "peer_MTP":
            run["observation"]["capture_ledger"] = capture_ledger(Path(run["folder"]))
            base.save(Path(run["folder"]) / "observation.json", run["observation"])
        else:
            run["observation"]["capture_ledger"] = None
    result["carrier_before_after_regression"] = comparison
    result["Hyle_capture_cold_ledgers"] = {arm: [r["observation"]["capture_ledger"] for r in runs if r["arm"] == arm]
                                           for arm in ARMS[:2]}
    result["limits"] = [x.replace("four separate monitored processes", "three separate monitored processes")
                        for x in result["limits"]]
    result["limits"].append("Original V peer MTP already differs from the Hyle stream. Its output/work ledger is reported, never assumed equal or used as a same-token quality/speed claim.")
    base.save(output / "runs.json", runs)
    base.save(output / "summary.json", result)
    return result


def run(config_path: Path, mode: str, output: Path) -> dict:
    output = owned_output(output)
    if output.exists():
        raise ValueError("run output must be new; preserve prior attempts")
    configuration = plan(config_path, mode, output)
    output.mkdir(parents=True)
    base.save(output / "inputs.json", configuration)
    helpers = base.load_helpers()
    helpers.gpu_snapshot(output, "window-before")
    observed = []
    try:
        for entry in configuration["commands"]:
            env = os.environ.copy()
            if base.identity(entry["environment"]["path"]) != entry["environment"]:
                raise ValueError("runtime environment receipt changed")
            env["PATH"] = base.read(entry["environment"]["path"])["PATH"]
            print("WINDOW_BEGIN", mode, entry["ordinal"], entry["arm"], flush=True)
            helpers.execute(Path(entry["folder"]), entry["arm"], entry["command"], env, mode == "memory")
            obs = base.parse_result(Path(entry["folder"]), entry["arm"], configuration)
            observed.append(dict(arm=entry["arm"], folder=entry["folder"], observation=obs))
            compare_before_after(observed)  # Preserve and stop at a true regression.
            print("WINDOW_END", mode, entry["ordinal"], entry["arm"], flush=True)
    finally:
        helpers.gpu_snapshot(output, "window-after")
    return analyze(output)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("action", choices=("plan", "run", "analyze", "self-check"))
    parser.add_argument("--config", type=Path, default=S / "arms.json")
    parser.add_argument("--mode", choices=("timing", "memory"), default="timing")
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    if args.action == "self-check":
        result = base.self_check()
        assert owned_output(S / "performance/timing").is_relative_to(S)
        try:
            owned_output(V / "performance/forbidden")
        except ValueError:
            pass
        else:
            raise AssertionError("V output must be rejected")
        result.update(three_arm_order=list(ARMS), output_guard_rejects_V=True,
                      no_input_generation=True, new_model_runs=0)
        base.save(S / "performance-preparation-checks.json", result)
        print(json.dumps(result))
        return
    output = owned_output(args.output or S / "performance" / args.mode)
    if args.action == "plan":
        result = plan(args.config, args.mode, output)
        base.save(S / (args.mode + "-plan.json"), result)
        print(json.dumps(dict(processes=len(result["commands"]), plan=str(S / (args.mode + "-plan.json")), model_runs=0)))
    else:
        result = run(args.config, args.mode, output) if args.action == "run" else analyze(output)
        print(json.dumps(dict(summary=str(output / "summary.json"), processes=result["processes"], mode=result["mode"])))


if __name__ == "__main__":
    main()
