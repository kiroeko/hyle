from pathlib import Path
import importlib.util,os,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent
s=importlib.util.spec_from_file_location('helper',W/'build.py');h=importlib.util.module_from_spec(s);s.loader.exec_module(h);b,c=h.b,h.c
ready=c.read(W/'control-ready-attempt1.json');assert h.same(ready['image'])and h.same(ready['source'])
plan=c.read(W/'control/run-plan.json');command=plan['command'];assert command[0]==ready['image']['path']
out=W/'control-run1';out.mkdir(exist_ok=False)
env=os.environ.copy();env['PATH']=c.read(ready['runtime_environment']['path'])['PATH']
c.save(out/'identity.json',ready);c.save(out/'plan.json',dict(**plan,ready=ready,unrun=False))
c.execute('run',command,env,out)
