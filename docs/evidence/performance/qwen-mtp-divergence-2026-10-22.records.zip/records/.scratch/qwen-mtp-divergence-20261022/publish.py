"""Publish finite MTP divergence controls and the actual carrier-only comparison."""
from pathlib import Path
import difflib,hashlib,json,subprocess,zipfile
W=Path(__file__).resolve().parent;R=W.parents[1];V=W.parent/'qwen-mtp-window-20261022';O=R/'docs/evidence/performance';NAME='qwen-mtp-divergence-2026-10-22'
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def save(p,d):p.write_text(json.dumps(d,indent=2,ensure_ascii=False,allow_nan=False)+'\n',encoding='utf-8')
def identity(p):
 p=Path(p);h=hashlib.sha256()
 with p.open('rb')as f:
  for data in iter(lambda:f.read(8<<20),b''):h.update(data)
 return dict(path=str(p.resolve()),bytes=p.stat().st_size,sha256=h.hexdigest())
changed=['tools/qwen35_text/main.cc','tools/qwen35_text/README.md','docs/developer/current-work.md','docs/developer/performance/decode.md']
frozen=[]
for name in changed:
 p=R/name;snap=W/'current'/name;snap.parent.mkdir(parents=True,exist_ok=True);snap.write_bytes(p.read_bytes())
 record=dict(source=identity(p),snapshot=identity(snap));before=W/'before'/name
 assert before.is_file()
 diff=W/'product-diffs'/(name.replace('/','--')+'.diff');diff.parent.mkdir(exist_ok=True)
 diff.write_text(''.join(difflib.unified_diff(before.read_text(encoding='utf-8-sig').splitlines(True),p.read_text(encoding='utf-8-sig').splitlines(True),fromfile='before/'+name,tofile=name)),encoding='utf-8')
 result=subprocess.run(['git','diff','--no-index','--check',str(before),str(p)],capture_output=True,text=True,encoding='utf-8',errors='replace')
 assert result.returncode in(0,1)and not result.stdout.strip()and not result.stderr.strip(),(name,result.stdout,result.stderr)
 record.update(before=identity(before),diff=identity(diff),whitespace_diagnostics=[]);frozen.append(record)
save(W/'product-freeze.json',dict(files=frozen))
ready={}
for tag in('qwen','peer','control','control2'):
 p=W/f'{tag}-ready-attempt1.json';r=read(p)
 assert identity(r['image']['path'])==r['image']and identity(r['source']['path'])==r['source']
 ready[tag]=r
runs={}
for name in ['hyle-trace1','peer-on-run1','peer-off-run1','control-run1','control2-run1',*[f'lazy-cases1/{case}-{arm}'for case in('p1','p15')for arm in('before','current')]]:
 folder=W/name;t=read(folder/'run.result.json');assert t['exit']==0 and t['terminal']is True
 runs[name]=dict(terminal=identity(folder/'run.result.json'),stdout=identity(folder/'run.stdout.log'),stderr=identity(folder/'run.stderr.log'),command=t['command'],throughput_evidence=False)
timing=read(W/'performance/timing/summary.json');memory=read(W/'performance/memory/summary.json')
assert timing['processes']==9 and memory['processes']==3
for mode,count in(('timing',9),('memory',3)):
 observed=read(W/f'performance/{mode}/runs.json');assert len(observed)==count
 assert all(x['process']['exit']==0 and x['observation']['actual_generated_tokens']==64 for x in observed)
reports={p.name:read(p)for p in sorted((W/'review').glob('*.json'))}
assert read(W/'review/lazy-cases-review.json')['status'].startswith('Finite real CUDA')
summary=dict(status='Finite same-checkpoint MTP divergence localized and carrier-only resource change implemented/measured; broader goal active',date='2026-10-22',
 product_freeze=identity(W/'product-freeze.json'),source_change=read(W/'carrier-source-freeze.json'),ready=ready,
 diagnostic_runs=runs,actual_native_diagnostic_processes=9,actual_unmonitored_timing_processes=9,actual_independent_memory_processes=3,
 timing=timing,memory=memory,reports=reports,
 build_scope=dict(new_Hyle_library_TUs=0,Hyle_consumer_TUs=1,diagnostic_peer_TUs=3,SDK_builds=0,NVCC_builds=0,full_configures=0,unchanged_Hyle_link_inputs=194),
 findings=['All original sampled full-vocabulary rows are finite and GPU-greedy IDs match independent argmax. The first divergence is a target-score difference, not row/candidate mapping.',
 'The exact original native round5/round9 target logits are reproduced byte-for-byte by controlled replay. From the same complete C171 RS1 checkpoint, T1 chooses11 at a true F32 tie while T2 chooses271 with a0.016613 score margin. Shape arithmetic is sufficient to flip this particular near-tied decision.',
 'At the first rejected boundary165, uninterrupted native pending restore and full-state canonical reload followed by the same T1 have byte-identical hidden/logits/all36 typed R/S payloads and the complete partial-state blob. No additional pending-restore discrepancy was found in that tested continuation.',
 'Hyle at the original divergence has BF16-derived scores11=271=23.75 and stable lower-ID selection. No dtype, rounding, tolerances or generation policy was altered to match reference IDs.',
 'Product change is only three run_mtp preparation lines: instantiate the actual prefill slot; cold-compile all finite families but instantiate T1 carriers only when selected. Existing prepare/exception/retirement machinery retained.',
 'Real CUDA P1/one-output and P15/four-output before/current tests return identical IDs/roles/work and eight finite byte-identical vectors; the latter first uses lazy lag1 quota-one targetT1/draft2.',
 'New P154/64 N1R1 before/current/unchanged native peer window: nine fresh timing plus three separate memory processes. Hyle64 IDs/rounds/work remain identical and capture18/50 unchanged. Formal wall clocks are not changed by this analysis.'],
 limitations=['One pinned native version, one prompt, one card and finite checkpoint cases do not establish general model quality or correctness of every rollback path.',
 'T1/T2 arithmetic and intermediate precision differ. Different natural native-MTP continuation remains unsuitable for a same-token cross-engine implementation-speed claim.',
 'Carrier change did not demonstrate decode speed improvement: actual medians/ranges and the small negative decode/session change are retained. Lower sampled peaks are not an exact physical-allocation proof.',
 'Requested10ms memory sampling has actual gaps and missing ready baselines retained. Dedicated/shared maxima are not summed; CPU WS/private/GPU shared overlap.',
 'No new ordinary ninety-vector regression or other-OS GPU run was performed because shared library/Model/Graph/math were unchanged. Existing evidence remains separate.',
 'One Python run-control helper failed before any native command due duplicate keyword; corrected merge and the original failed helper are retained under revisions. No failed model run is relabeled pass.'],
 previous_evidence=['docs/evidence/performance/qwen-mtp-window-2026-10-22.json','docs/evidence/correctness/qwen-mtp-retirement-2026-10-22.json'],
 remaining=['Connect actual MTP multi-session consumers, starting with shared-model interleavedR1 and complete independent state comparisons, then applicable equal-shape batch.',
 'Explain remaining ten non-first-use MTP capture recordings using actual invalidation/resource facts; do not assume all recorded time is removable.',
 'Other systems/native backends, selected models/quantization, images and full architecture scope remain active.'])
save(W/'actual-summary.json',summary)
excluded={'.exe','.dll','.obj','.map','.lib','.exp','.pdb','.pyc'}
files=sorted(p for p in W.rglob('*')if p.is_file()and p.suffix.lower()not in excluded and not any(x in('tmp','__pycache__')for x in p.relative_to(W).parts)and p.name not in('published.json','cleanup-plan.json','cleanup-result.json','cleanup_script.ps1'))
archive=O/(NAME+'.data.zip');assert not archive.exists();entries=[];unique={}
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=6)as z:
 for p in files:
  e=identity(p);key=(e['bytes'],e['sha256']);canonical=unique.get(key)
  if canonical is None:
   canonical=p.relative_to(R).as_posix();unique[key]=canonical;z.write(p,canonical)
  else:e['identical_content_alias']=True
  e['entry']=canonical;entries.append(e)
with zipfile.ZipFile(archive)as z:
 assert z.testzip()is None and len(z.namelist())==len(unique)
 for (size,sha),entry in unique.items():
  raw=z.read(entry);assert len(raw)==size and hashlib.sha256(raw).hexdigest()==sha
manifest=O/(NAME+'.json');assert not manifest.exists()
save(manifest,dict(**summary,archives=[identity(archive)],archive_files=entries,archive_verified=dict(CRC=True,all_unique_entry_SHA256=True,source_files=len(entries),unique_entries=len(unique),original_bytes=sum(x['bytes']for x in entries),unique_bytes=sum(x[0]for x in unique),content_deduplication='Every source path retains its own SHA/size and canonical ZIP entry. Byte-identical raw states/vectors are stored once.')))
published=dict(manifest=identity(manifest),archives=[identity(archive)]);save(W/'published.json',published)
print(json.dumps(dict(**published,source_files=len(entries),unique_entries=len(unique),original_bytes=sum(x['bytes']for x in entries),unique_bytes=sum(x[0]for x in unique)),indent=2))
