"""Emit the one-host-TU same-native control recipe. Never compile or run."""
from pathlib import Path
import ast
import hashlib
import json

HERE = Path(__file__).resolve().parent
W = HERE.parent
ROOT = W.parents[1]
CACHE = ROOT / '.scratch/architecture-refactor-2026-10-18/llama-matched-consumer'


def identity(path):
    raw = path.read_bytes()
    return dict(path=str(path), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


def save(path, data):
    assert not path.exists(), path
    path.write_text(json.dumps(data, indent=2) + '\n', encoding='utf-8')


def main():
    original = json.loads((W / 'peer/build-plan.json').read_text())
    plan = dict(original)
    plan['status'] = 'Frozen one-context RS1 control source only; root owns build/GPU.'
    plan['source'] = identity(HERE / 'control_peer.cc')
    plan['output_directory'] = str(HERE / 'checks/attempt1')
    for key in ['compile', 'link']:
        plan[key] = [item.replace(str(W / 'peer'), str(HERE)).replace(str(HERE / 'peer_mtp.cc'), str(HERE / 'control_peer.cc')) for item in original[key]]
    plan['baseline_plan'] = identity(W / 'peer/build-plan.json')
    plan['baseline_source'] = identity(HERE / 'before/peer_mtp.cc')
    plan['diagnostic_only'] = True
    save(HERE / 'build-plan.json', plan)
    build_script = (W / 'build_peer.py').read_text()
    assert build_script.count("U/'peer/build-plan.json'") == 1
    build_script = build_script.replace("U/'peer/build-plan.json'", "U/'control/build-plan.json'")
    build_script = build_script.replace("U/f'peer-ready-{out.name}.json'", "U/f'control-ready-{out.name}.json'")
    build_script = build_script.replace('READY fixed native MTP peer', 'READY one-context RS1 control peer')
    target_script = W / 'build_control.py'
    assert not target_script.exists()
    target_script.write_text(build_script, encoding='utf-8')
    for path in [HERE / 'prepare_control.py', HERE / 'prepare_recipe.py', target_script]:
        ast.parse(path.read_text())
    output = W / 'control-run1'
    command = [str(HERE / 'checks/attempt1/peer.exe'), '--model', str(CACHE / 'Qwen3.5-2B-text-MTP-BF16.gguf'),
               '--inputs', str(ROOT / '.scratch/qwen-mtp-window-20261022/inputs'),
               '--steps', '64', '--capacity', '1024', '--max-rounds', '10', '--mtp', 'on',
               '--memory-snapshots', 'off', '--diagnostic-dir', str(output / 'diagnostic'),
               '--output', str(output / 'consumer-result.json')]
    save(HERE / 'run-plan.json', dict(command=command, unrun=True, diagnostic_not_performance=True,
        input_contract='Same V154prompt, steps64/quota and original first5 natural MTP rounds. Native draft round5 executes before checkpoint; no natural target round5 occurs before C.',
        branches='Single RS1 target context; full NONE C restore twice. A:T1[11], get partial165, T1[51338], get partial166. B:T2[11,36760], trim165, get partial165 without set, T1[51338], get partial166.',
        raw_outputs='One complete C blob; four original partial logical-R/S blobs with flags/bytes/position; full sampled logits+candidate maps, per-call F32 hidden; no duplicate weights or state payload pretending to be floats.',
        checkpoint_limits='Only target native memory is restored. Host carry/prior/pending/draft context/sampler outputs are not serialized and MTP generation is not resumed after control.'))
    natural = json.loads((W / 'peer-on-run1/consumer-result.json').read_text())
    generated = [natural['prefill_first_id']]
    for row in natural['rounds'][:5]:
        generated.extend(row['emitted'])
    assert generated == [71093,12305,198,464,19298,198,1445,18904,1120,5586,11]
    assert natural['rounds'][5]['target_before'] == 164
    assert natural['rounds'][5]['draft'] == 36760 and natural['rounds'][5]['pending'] == 11
    source = (HERE / 'control_peer.cc').read_text()
    assert source.count('llama_state_seq_set_data_ext(') == 1  # called exactly twice by restore closure
    start = source.index('trim(context, base + 1);')
    end = source.index('auto b_166 =', start)
    assert 'restore()' not in source[start:end] and 'set_data_ext(' not in source[start:end]
    assert source.count('restore();') == 2
    save(HERE / 'source-freeze.json', dict(status='Frozen; pure-host AST/recipe/witness/source invariants checked. No CXX/link/GPU.',
        source=identity(HERE / 'control_peer.cc'), baseline_source=identity(HERE / 'before/peer_mtp.cc'),
        files=[identity(path) for path in [HERE / 'control.diff', HERE / 'prepare_control.py', HERE / 'prepare_recipe.py',
            HERE / 'build-plan.json', HERE / 'run-plan.json', target_script]],
        natural_witness_reference=identity(W / 'peer-on-run1/consumer-result.json'),
        source_design_reference=identity(W / 'review/rs1-control-design.json'),
        source_API_headers=original['header_identities'],
        native_inputs='Retained records copied from actual W/V original closure; not rehashed or rebuilt.',
        live_contract=['Original native GPU greedy and same RS1 target/output capacity2/nextn exports remain unchanged.',
            'Exactly one complete NONE checkpoint and two restores into the same target; B has no restore between trim and nextdecode.',
            'PARTIAL_ONLY get synchronizes and observes logical rollback-plane state without setting/materializing a new base state.',
            'Raw state headers are never cast to floats; typed offline parser must validate segments.',
            'Diagnostic fixed51338 continuation does not claim natural generation/acceptance or numerical equality.'],
        runtime_unverified=['Checkpoint bytes/restore consumption and logical state outputs', 'All A/B numerical comparisons and native control execution']))
    print(json.dumps(dict(source=plan['source'], build_script=str(target_script), build_plan=str(HERE / 'build-plan.json'), run_plan=str(HERE / 'run-plan.json'))))


if __name__ == '__main__':
    main()
