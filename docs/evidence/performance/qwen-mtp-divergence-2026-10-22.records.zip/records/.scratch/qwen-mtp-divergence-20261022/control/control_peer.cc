// Bounded measurement consumer. Fixed d9e03 llama/ggml math and native archives.
// No warmup, synthetic acceptance, separate weight copy or model-specific kernel.
#include "llama.h"
#include "llama-ext.h"
#include "llama-memory.h"
#include "ggml-backend.h"
#include "nlohmann/json.hpp"

#include <algorithm>
#include <chrono>
#include <cmath>
#include <cstdint>
#include <cstring>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <limits>
#include <memory>
#include <stdexcept>
#include <string>
#include <vector>

#if defined(_WIN32)
#define NOMINMAX
#define WIN32_LEAN_AND_MEAN
#define PSAPI_VERSION 2
#include <windows.h>
#include <psapi.h>
#endif

namespace peer_mtp {
using Json = nlohmann::ordered_json;
using Clock = std::chrono::steady_clock;
using Point = Clock::time_point;
using Tokens = std::vector<llama_token>;
using Model = std::unique_ptr<llama_model, decltype(&llama_model_free)>;
using Context = std::unique_ptr<llama_context, decltype(&llama_free)>;
using Sampler = std::unique_ptr<llama_sampler, decltype(&llama_sampler_free)>;

double seconds(Point end, Point begin) { return std::chrono::duration<double>(end - begin).count(); }
void require(bool value, const char * message) { if (!value) throw std::runtime_error(message); }
bool eos(llama_token id) { return id == 248044 || id == 248046; }

struct Backend final {
    Backend() { llama_backend_init(); }
    ~Backend() { llama_backend_free(); }
};

struct Batch final {
    // Draft uses the original API's explicit token+hidden-state representation.
    // llama_batch_free owns embd; token is this vector, never freed by that API.
    llama_batch value;
    Tokens draft_tokens;
    std::size_t capacity, embedding;
    Batch(std::size_t count, std::size_t width = 0)
        : value(llama_batch_init(static_cast<int32_t>(count), static_cast<int32_t>(width), 1)),
          draft_tokens(width ? count : 0), capacity(count), embedding(width) {
        if (embedding) value.token = draft_tokens.data();
    }
    ~Batch() { if (embedding) value.token = nullptr; llama_batch_free(value); }
    Batch(const Batch &) = delete;
    Batch & operator=(const Batch &) = delete;
    void fill(const Tokens & ids, std::size_t first, const std::vector<float> * hidden,
              bool all_outputs, bool last_output) {
        require(!ids.empty() && ids.size() <= capacity, "batch capacity exceeded");
        require((embedding != 0) == (hidden != nullptr), "draft hidden carrier mismatch");
        if (hidden) require(hidden->size() == ids.size() * embedding, "draft hidden row count mismatch");
        value.n_tokens = static_cast<int32_t>(ids.size());
        for (std::size_t row = 0; row < ids.size(); ++row) {
            value.token[row] = ids[row]; value.pos[row] = static_cast<llama_pos>(first + row);
            value.n_seq_id[row] = 1; value.seq_id[row][0] = 0;
            value.logits[row] = static_cast<int8_t>(all_outputs || (last_output && row + 1 == ids.size()));
        }
        if (hidden) std::memcpy(value.embd, hidden->data(), hidden->size() * sizeof(float));
    }
};

struct Drain final {
    llama_context * target, * draft;
    ~Drain() { if (target) llama_synchronize(target); if (draft) llama_synchronize(draft); }
};

Json memory(const char * name, Point start, ggml_backend_dev_t device) {
    const auto begin = Clock::now(); Json v{{"name", name}, {"elapsed_seconds", seconds(begin, start)}};
    v["unix_ms"] = std::chrono::duration_cast<std::chrono::milliseconds>(
        std::chrono::system_clock::now().time_since_epoch()).count();
#if defined(_WIN32)
    PROCESS_MEMORY_COUNTERS_EX p{}; p.cb = sizeof(p);
    if (GetProcessMemoryInfo(GetCurrentProcess(), reinterpret_cast<PROCESS_MEMORY_COUNTERS *>(&p), sizeof(p))) {
        v["working_set"] = p.WorkingSetSize; v["peak_working_set"] = p.PeakWorkingSetSize;
        v["private_commit"] = p.PrivateUsage; v["peak_commit"] = p.PeakPagefileUsage;
    }
#endif
    if (device) {
        std::size_t free_bytes = 0, total = 0; ggml_backend_dev_memory(device, &free_bytes, &total);
        v["device_free"] = free_bytes; v["device_total"] = total;
    }
    std::cerr << "measure_memory name=" << name << " elapsed_seconds=" << v["elapsed_seconds"]
              << " unix_ms=" << v["unix_ms"] << '\n';
    v["snapshot_seconds"] = seconds(Clock::now(), begin); return v;
}

std::size_t backing(llama_context * context) {
    std::size_t bytes = 0;
    for (const auto & allocation : llama_get_memory(context)->memory_breakdown()) {
        require(allocation.second <= (std::numeric_limits<std::size_t>::max)() - bytes, "cache byte overflow");
        bytes += allocation.second;
    }
    return bytes;
}

Json decode(llama_context * context, Batch & batch) {
    const auto begin = Clock::now(); const auto code = llama_decode(context, batch.value);
    const auto returned = Clock::now();
    require(code == 0, "original llama_decode failed");
    llama_synchronize(context); const auto retired = Clock::now();
    return {{"rows", batch.value.n_tokens}, {"decode_return_seconds", seconds(returned, begin)},
            {"synchronize_seconds", seconds(retired, returned)}, {"seconds", seconds(retired, begin)}};
}

Tokens sampled(llama_context * context, llama_sampler * sampler, std::size_t first, std::size_t rows,
               int32_t vocabulary) {
    Tokens ids; ids.reserve(rows);
    for (std::size_t i = first; i < first + rows; ++i) {
        const auto native = llama_get_sampled_token_ith(context, static_cast<int32_t>(i));
        require(native >= 0 && native < vocabulary, "GPU greedy output missing; CPU fallback is prohibited");
        require(native == llama_sampler_sample(sampler, context, static_cast<int32_t>(i)),
                "public/native greedy output mismatch");
        ids.push_back(native);
    }
    return ids;
}

std::vector<float> hidden(llama_context * context, std::size_t rows, std::size_t width) {
    std::vector<float> result(rows * width);
    for (std::size_t row = 0; row < rows; ++row) {
        const auto * h = llama_get_embeddings_nextn_ith(context, static_cast<int32_t>(row));
        require(h != nullptr, "target did not export every actual normalized hidden row");
        std::copy(h, h + width, result.begin() + static_cast<std::ptrdiff_t>(row * width));
    }
    require(std::all_of(result.begin(), result.end(), [](float f) { return std::isfinite(f); }),
            "nonfinite target hidden state");
    return result;
}

void position(llama_context * context, std::size_t length) {
    require(llama_memory_seq_pos_max(llama_get_memory(context), 0) == static_cast<llama_pos>(length) - 1,
            "native committed position differs from accepted boundary");
}
void trim(llama_context * context, std::size_t length) {
    require(llama_memory_seq_rm(llama_get_memory(context), 0, static_cast<llama_pos>(length), -1),
            "original context cannot remove unaccepted state");
    position(context, length);
}


// Opt-in observation only: never feeds a CPU result back to sampling or state.
// Fixed witnesses belong to this scratch consumer, not a model/provider API.
struct Diagnostic final {
    std::filesystem::path directory;
    Json records = Json::array();
    explicit Diagnostic(std::filesystem::path path) : directory(std::move(path)) {
        if (!directory.empty()) {
            require(!std::filesystem::exists(directory), "diagnostic directory already exists");
            std::filesystem::create_directories(directory);
        }
    }
    bool enabled() const { return !directory.empty(); }
    static bool mtp_round(std::size_t index) { return index == 5 || index == 6 || index == 9; }
    static bool plain_offset(std::size_t offset) {
        return offset == 11 || offset == 12 || offset == 13 || offset == 18 || offset == 19;
    }
    static void binary(const std::filesystem::path & path, const void * data, std::size_t bytes) {
        std::ofstream out(path, std::ios::binary);
        out.write(static_cast<const char *>(data), static_cast<std::streamsize>(bytes));
        require(static_cast<bool>(out), "cannot write diagnostic raw data");
    }
    void capture(llama_context * context, const std::string & name, int32_t row,
                 int32_t vocabulary, llama_token native, const Tokens & prefix,
                 Json round, Json decode_row, std::size_t generated_offset) {
        if (!enabled()) return;
        const auto count = llama_get_sampled_logits_count_ith(context, row);
        const auto candidate_count = llama_get_sampled_candidates_count_ith(context, row);
        const auto * logits = llama_get_sampled_logits_ith(context, row);
        const auto * candidates = llama_get_sampled_candidates_ith(context, row);
        Json record{{"name", name}, {"round_index", round}, {"decode_row", decode_row},
            {"original_batch_row", row}, {"generated_offset_before", generated_offset},
            {"evaluated_prefix_ids", prefix}, {"evaluated_prefix_rows", prefix.size()},
            {"native_sampled_id", native}, {"vocabulary", vocabulary},
            {"sampled_logits_count", count}, {"sampled_candidates_count", candidate_count},
            {"logits_pointer_present", logits != nullptr}, {"candidates_pointer_present", candidates != nullptr},
            {"status", "unavailable"}, {"full_vocabulary", false}};
        // Counts alone are insufficient: the original getter can report the
        // vocab size while returning no backend sampled-logits allocation.
        if (logits && count > 0 && count <= static_cast<uint32_t>(vocabulary)) {
            const auto file = name + ".logits.f32";
            binary(directory / file, logits, static_cast<std::size_t>(count) * sizeof(float));
            record["raw_logits"] = {{"file", file}, {"dtype", "F32_LE"}, {"shape", {count}},
                                    {"bytes", static_cast<std::size_t>(count) * sizeof(float)}};
        }
        bool mapping_valid = candidates && count == static_cast<uint32_t>(vocabulary) &&
            (candidate_count == 0 || candidate_count == count);
        if (mapping_valid) {
            std::vector<uint8_t> seen(static_cast<std::size_t>(vocabulary), 0);
            for (uint32_t i = 0; i < count; ++i) {
                const auto id = candidates[i];
                if (id < 0 || id >= vocabulary || seen[static_cast<std::size_t>(id)]) {
                    mapping_valid = false; break;
                }
                seen[static_cast<std::size_t>(id)] = 1;
            }
        }
        if (logits && mapping_valid) {
            const auto file = name + ".candidates.i32";
            binary(directory / file, candidates, static_cast<std::size_t>(count) * sizeof(llama_token));
            record["raw_candidates"] = {{"file", file}, {"dtype", "I32_LE"}, {"shape", {count}},
                                        {"bytes", static_cast<std::size_t>(count) * sizeof(llama_token)}};
            bool identity = true; std::size_t finite = 0;
            Json scores = Json::object();
            int32_t best = -1, second = -1;
            for (uint32_t i = 0; i < count; ++i) {
                const auto id = candidates[i]; const auto value = logits[i];
                identity = identity && id == static_cast<llama_token>(i);
                finite += std::isfinite(value);
                if (id == 11 || id == 271 || id == native) {
                    uint32_t bits = 0; std::memcpy(&bits, &value, sizeof(bits));
                    scores[std::to_string(id)] = {{"sample_index", i}, {"value", std::isfinite(value) ? Json(value) : Json(nullptr)},
                                                {"f32_bits", bits}};
                }
                // Stable strict-greater scan: ties retain the earlier sampled
                // index; no result is supplied to the native greedy sampler.
                if (!std::isfinite(value)) continue;
                if (best < 0 || value > logits[best]) { second = best; best = static_cast<int32_t>(i); }
                else if (second < 0 || value > logits[second]) second = static_cast<int32_t>(i);
            }
            record["full_vocabulary"] = true;
            record["candidate_mapping"] = candidate_count == 0 ? "original getter full-vocab fallback; permutation verified" : "explicit full permutation verified";
            record["identity_mapping"] = identity; record["finite_count"] = finite;
            record["nonfinite_count"] = count - finite; record["watched_logits"] = scores;
            record["status"] = finite == count ? "full_finite" : "full_nonfinite_no_argmax_assertion";
            if (finite == count && best >= 0 && second >= 0) {
                record["cpu_argmax"] = {{"token", candidates[best]}, {"sample_index", best}, {"logit", logits[best]}};
                record["cpu_second"] = {{"token", candidates[second]}, {"sample_index", second}, {"logit", logits[second]}};
                record["top2_margin"] = static_cast<double>(logits[best]) - logits[second];
                record["native_matches_cpu_argmax"] = native == candidates[best];
            }
        } else {
            record["unavailable_reason"] = "need nonnull logits, exactly vocabulary logits and verified full candidate permutation";
        }
        std::ofstream out(directory / (name + ".json"), std::ios::binary); out << record.dump(2) << '\n';
        require(static_cast<bool>(out), "cannot write diagnostic record");
        records.push_back(std::move(record));
    }
    Json summary() const {
        return {{"enabled", enabled()}, {"directory", directory.string()}, {"not_throughput_evidence", enabled()},
                {"selection", "prefill; MTP zero-based rounds5/6/9 rows0/1; plain output offsets11/12/13/18/19"},
                {"records", records}};
    }
};


// The sequence API serializes target memory only. Host carry/prior, sampler
// outputs and draft context are not saved/restored and are not resumed here.
std::vector<uint8_t> state_bytes(llama_context * context, llama_state_seq_flags flags) {
    llama_synchronize(context);
    const auto bytes = llama_state_seq_get_size_ext(context, 0, flags);
    require(bytes > 0, "native sequence checkpoint size is zero");
    std::vector<uint8_t> result(bytes);
    require(llama_state_seq_get_data_ext(context, result.data(), result.size(), 0, flags) == bytes,
            "native sequence checkpoint export consumed wrong byte count");
    return result;
}

Json save_partial(llama_context * context, Diagnostic & diagnostic,
                  const std::string & name, std::size_t length) {
    position(context, length);
    const auto data = state_bytes(context, LLAMA_STATE_SEQ_FLAGS_PARTIAL_ONLY);
    const auto file = name + ".partial-state.bin";
    Diagnostic::binary(diagnostic.directory / file, data.data(), data.size());
    // Opaque bytes are not numerical data. An offline fixed-source parser must
    // validate headers/types/extents and select only each logical R/S payload.
    return {{"file", file}, {"bytes", data.size()}, {"seq_id", 0},
            {"flags", LLAMA_STATE_SEQ_FLAGS_PARTIAL_ONLY}, {"logical_length", length},
            {"native_pos_max", llama_memory_seq_pos_max(llama_get_memory(context), 0)},
            {"operation", "get-only; no set_data or rollback normalization"},
            {"payload_note", "Original PARTIAL_ONLY blob. Headers/placement are not floats; logical R/S require typed offline parsing."}};
}

struct ControlOutput final { Json observation; Tokens ids; };

ControlOutput control_decode(llama_context * context, llama_sampler * sampler, Batch & batch,
                             Diagnostic & diagnostic, const std::string & name,
                             const Tokens & inputs, Tokens prefix, std::size_t first,
                             std::size_t width, int32_t vocabulary) {
    require(prefix.size() == first, "control input prefix length mismatch");
    batch.fill(inputs, first, nullptr, true, false);
    auto compute = decode(context, batch);
    auto ids = sampled(context, sampler, 0, inputs.size(), vocabulary);
    const auto values = hidden(context, inputs.size(), width);
    for (std::size_t row = 0; row < inputs.size(); ++row) {
        prefix.push_back(inputs[row]);
        diagnostic.capture(context, name + "_row_" + std::to_string(row), static_cast<int32_t>(row),
                           vocabulary, ids[row], prefix, nullptr, row, first);
    }
    const auto file = name + ".hidden.f32";
    Diagnostic::binary(diagnostic.directory / file, values.data(), values.size() * sizeof(float));
    Json observation{{"name", name}, {"inputs", inputs}, {"first_position", first},
        {"native_ids", ids}, {"compute", compute}, {"evaluated_prefix_ids", prefix},
        {"native_pos_max_after_decode", llama_memory_seq_pos_max(llama_get_memory(context), 0)},
        {"hidden", {{"file", file}, {"dtype", "F32_LE"}, {"shape", {inputs.size(), width}},
                    {"bytes", values.size() * sizeof(float)}}}};
    return {std::move(observation), std::move(ids)};
}

Json rejection_control(llama_context * context, llama_sampler * sampler, Batch & batch,
                       Diagnostic & diagnostic, const Tokens & prompt, const Tokens & generated,
                       const Tokens & natural_verify, const Json & natural_rounds,
                       const Json & original_draft_compute, std::size_t base,
                       std::size_t draft_frontier, std::size_t old_lag,
                       std::size_t width, int32_t vocabulary) {
    const Tokens expected_generated{71093,12305,198,464,19298,198,1445,18904,1120,5586,11};
    require(prompt.size() == 154 && base == 164 && generated == expected_generated &&
            natural_rounds.size() == 5 && natural_verify == Tokens({11,36760}) &&
            draft_frontier == 165 && old_lag == 1,
            "natural pre-control trajectory differs from the recorded first rejection witness");
    Tokens prefix = prompt;
    prefix.insert(prefix.end(), generated.begin(), generated.end() - 1);
    require(prefix.size() == base, "checkpoint target history length mismatch");
    position(context, base);
    const auto checkpoint = state_bytes(context, LLAMA_STATE_SEQ_FLAGS_NONE);
    Diagnostic::binary(diagnostic.directory / "C.full-state.bin", checkpoint.data(), checkpoint.size());
    const auto restore = [&]() {
        require(llama_state_seq_set_data_ext(context, checkpoint.data(), checkpoint.size(), 0,
                    LLAMA_STATE_SEQ_FLAGS_NONE) == checkpoint.size(),
                "complete checkpoint restore consumed wrong byte count");
        position(context, base);
    };

    restore();
    auto a_first = control_decode(context, sampler, batch, diagnostic, "A_T1_11", Tokens{11}, prefix, base, width, vocabulary);
    auto a_165 = save_partial(context, diagnostic, "A165", base + 1);
    auto continued_prefix = prefix; continued_prefix.push_back(11);
    auto a_next = control_decode(context, sampler, batch, diagnostic, "A_T1_51338", Tokens{51338}, continued_prefix,
                                 base + 1, width, vocabulary);
    auto a_166 = save_partial(context, diagnostic, "A166", base + 2);

    restore();
    auto b_first = control_decode(context, sampler, batch, diagnostic, "B_T2_11_36760", Tokens{11,36760}, prefix,
                                  base, width, vocabulary);
    const bool rejection_reproduced = b_first.ids[0] != 36760;
    trim(context, base + 1);
    auto b_165 = save_partial(context, diagnostic, "B165_after_trim", base + 1);
    // Critical witness: no set_data/clear/context rebuild occurs between the
    // native trim and this decode. PARTIAL_ONLY get preserves pending rs_idx.
    auto b_next = control_decode(context, sampler, batch, diagnostic, "B_T1_51338_after_trim", Tokens{51338}, continued_prefix,
                                 base + 1, width, vocabulary);
    auto b_166 = save_partial(context, diagnostic, "B166", base + 2);
    return {{"scope", "One-model one-RS1-target diagnostic. Natural first5 MTP rounds, then serial same-checkpoint controls; not throughput or numerical-quality acceptance."},
        {"sampling", "Original native GPU greedy capacity2, CPU diagnostic argmax never fed back"},
        {"natural_rounds_completed", natural_rounds}, {"natural_generated_before_control", generated},
        {"prompt_ids", prompt}, {"checkpoint_prefix_ids", prefix}, {"checkpoint_length", base},
        {"natural_round5_draft_compute", original_draft_compute}, {"natural_round5_verify", natural_verify},
        {"draft_frontier_after_original_round5_draft", draft_frontier},
        {"checkpoint", {{"file", "C.full-state.bin"}, {"bytes", checkpoint.size()}, {"flags", LLAMA_STATE_SEQ_FLAGS_NONE},
            {"seq_id", 0}, {"complete_target_hybrid_memory", true},
            {"excludes", "Host carry/prior/pending, sampler/output logits/hidden, and independent draft context are not serialized."}}},
        {"A", {{"first", a_first.observation}, {"logical165", a_165}, {"next", a_next.observation}, {"logical166", a_166}}},
        {"B", {{"first", b_first.observation}, {"original_rejection_reproduced", rejection_reproduced},
            {"row0_matches_original_51338", b_first.ids[0] == 51338},
            {"selected_rows", 1}, {"trim_to", base + 1}, {"logical165", b_165},
            {"restore_between_trim_and_next", false}, {"next", b_next.observation}, {"logical166", b_166}}},
        {"diagnostic", diagnostic.summary()}, {"native_target_contexts", 1}, {"shared_model_objects", 1},
        {"control_followup_inputs", "Fixed original next token51338 in both branches, independent of current diagnostic argmax; not natural generation/acceptance evidence."},
        {"limits", "Same RS1 T1/T2 geometry may differ mathematically; no byte/tolerance agreement presumed. Two full-C restores normalize both initial branches; B pending restore path remains uninterrupted after trim."}};
}

struct Options final {
    std::filesystem::path model, inputs, output, diagnostic_dir;
    std::size_t prompt_rows = 0, steps = 16, capacity = 64, max_rounds = 0;
    bool mtp = false, memory_snapshots = false;
};
std::size_t integer(const char * value) {
    std::size_t consumed = 0; const std::string s(value); const auto n = std::stoull(s, &consumed);
    require(consumed == s.size(), "invalid integer option"); return static_cast<std::size_t>(n);
}
Options options(int argc, char ** argv) {
    Options o;
    for (int i = 1; i < argc; ++i) {
        const std::string k = argv[i]; require(i + 1 < argc, "option requires a value"); const auto * v = argv[++i];
        if (k == "--model") o.model = v;
        else if (k == "--inputs") o.inputs = v;
        else if (k == "--output") o.output = v;
        else if (k == "--diagnostic-dir") o.diagnostic_dir = v;
        else if (k == "--prompt-rows") o.prompt_rows = integer(v);
        else if (k == "--steps") o.steps = integer(v);
        else if (k == "--capacity") o.capacity = integer(v);
        else if (k == "--max-rounds") o.max_rounds = integer(v);
        else if (k == "--mtp" || k == "--memory-snapshots") {
            const std::string selected(v); require(selected == "on" || selected == "off", "expected on or off");
            (k == "--mtp" ? o.mtp : o.memory_snapshots) = selected == "on";
        }
        else throw std::runtime_error("unknown option: " + k);
    }
    require(!o.model.empty() && !o.inputs.empty(), "--model GGUF and --inputs DIR are required");
    require(o.capacity && o.capacity <= 4096 && o.steps && o.steps <= 1024,
            "bounded positive context<=4096 and output budget<=1024 required");
    require(o.output.empty() || !std::filesystem::exists(o.output), "output already exists");
    return o;
}

Json run(const Options & o) {
    const auto startup = Clock::now();
    require(o.mtp && !o.diagnostic_dir.empty(), "control requires --mtp on and --diagnostic-dir DIR");
    require(o.steps == 64 && o.capacity == 1024 && (!o.max_rounds || o.max_rounds >= 6),
            "control keeps original steps64/C1024 and must reach zero-based round5");
    Diagnostic diagnostic(o.diagnostic_dir);
    std::ifstream input(o.inputs / "prompt.ids"); require(static_cast<bool>(input), "cannot open prompt.ids");
    Tokens prompt; int64_t token = 0;
    while (input >> token) {
        require(token >= 0 && token < (std::numeric_limits<llama_token>::max)(), "invalid prompt ID");
        prompt.push_back(static_cast<llama_token>(token));
    }
    require(input.eof() && !prompt.empty(), "invalid or empty prompt.ids");
    if (o.prompt_rows) { require(o.prompt_rows <= prompt.size(), "prompt rows exceed source IDs"); prompt.resize(o.prompt_rows); }
    require(prompt.size() + o.steps - 1 <= o.capacity, "prompt plus requested output inputs exceed context");
    Backend backend;
    auto * device = ggml_backend_dev_by_name("CUDA0");
    require(device && ggml_backend_dev_type(device) == GGML_BACKEND_DEVICE_TYPE_GPU, "CUDA0 GPU required");
    Json snapshots = Json::array(), phase_points = Json::array();
    const auto marker = [&](const char * name, Point point) {
        const auto unix_ms = std::chrono::duration_cast<std::chrono::milliseconds>(
            std::chrono::system_clock::now().time_since_epoch()).count();
        phase_points.push_back({{"name", name}, {"elapsed_seconds", seconds(point, startup)}, {"unix_ms", unix_ms}});
        if (std::string(name) == "ready_before_first") std::cerr << "measure_memory name=" << name;
        else std::cerr << "memory_phase=" << name;
        std::cerr << " elapsed_seconds=" << seconds(point, startup)
                  << " unix_ms=" << unix_ms << '\n';
    };
    if (o.memory_snapshots) snapshots.push_back(memory("before_model", startup, device));
    ggml_backend_dev_t devices[]{device, nullptr};
    auto mp = llama_model_default_params(); mp.devices = devices; mp.n_gpu_layers = 999; mp.load_mtp = o.mtp;
    const llama_model_tensor_buft_override overrides[]{
        {"^token_embd\\.weight$", ggml_backend_dev_buffer_type(device)}, {nullptr, nullptr}};
    mp.tensor_buft_overrides = overrides;
    const auto model_begin = Clock::now(); Model model(llama_model_load_from_file(o.model.string().c_str(), mp), &llama_model_free);
    const auto model_end = Clock::now(); require(static_cast<bool>(model), "cannot load combined target+MTP model");
    require(llama_model_n_layer(model.get()) == 24 && llama_model_n_layer_nextn(model.get()) == (o.mtp ? 1 : 0),
            "model metadata must match target-only or complete target+MTP mode");
    const auto width = static_cast<std::size_t>(llama_model_n_embd_out(model.get()));
    const auto vocabulary = llama_vocab_n_tokens(llama_model_get_vocab(model.get()));
    require(width && vocabulary > 0 && std::all_of(prompt.begin(), prompt.end(),
            [&](llama_token id) { return id < vocabulary; }), "prompt/model shape mismatch");
    Sampler target_sampler(llama_sampler_chain_init(llama_sampler_chain_default_params()), &llama_sampler_free);
    Sampler draft_sampler(nullptr, &llama_sampler_free);
    if (o.mtp) draft_sampler.reset(llama_sampler_chain_init(llama_sampler_chain_default_params()));
    require(target_sampler && (!o.mtp || draft_sampler), "cannot create original samplers");
    llama_sampler_chain_add(target_sampler.get(), llama_sampler_init_greedy());
    if (o.mtp) llama_sampler_chain_add(draft_sampler.get(), llama_sampler_init_greedy());
    llama_sampler_seq_config target_config{0, target_sampler.get()}, draft_config{0, draft_sampler.get()};
    auto cp = llama_context_default_params(); cp.n_ctx = static_cast<uint32_t>(o.capacity); cp.n_seq_max = 1;
    cp.n_outputs_max = o.mtp ? 2u : 1u; cp.n_outputs_max_per_seq = cp.n_outputs_max;
    cp.n_rs_seq = o.mtp ? 1u : 0u;
    cp.n_batch = static_cast<uint32_t>((std::max)(prompt.size(), o.mtp ? std::size_t{2} : std::size_t{1})); cp.n_ubatch = cp.n_batch;
    cp.n_threads = 24; cp.n_threads_batch = 24; cp.kv_unified = true;
    cp.type_k = GGML_TYPE_BF16; cp.type_v = GGML_TYPE_BF16; cp.flash_attn_type = LLAMA_FLASH_ATTN_TYPE_ENABLED;
    cp.samplers = &target_config; cp.n_samplers = 1;
    const auto contexts_begin = Clock::now(); Context target(llama_init_from_model(model.get(), cp), &llama_free);
    require(static_cast<bool>(target), "cannot create target context");
    Context draft(nullptr, &llama_free);
    if (o.mtp) {
        auto dp = cp; dp.ctx_type = LLAMA_CONTEXT_TYPE_MTP; dp.ctx_other = target.get(); dp.n_rs_seq = 0;
        dp.n_outputs_max = 1; dp.n_outputs_max_per_seq = 1; dp.samplers = &draft_config;
        draft.reset(llama_init_from_model(model.get(), dp));
        require(static_cast<bool>(draft), "cannot create draft context");
    }
    Drain drain{target.get(), draft.get()};
    const auto contexts_end = Clock::now();
    require(llama_n_ctx_seq(target.get()) >= o.capacity && llama_n_rs_seq(target.get()) == (o.mtp ? 1u : 0u),
            "effective target cache/rollback contract mismatch");
    if (o.mtp) require(llama_n_ctx_seq(draft.get()) >= o.capacity && llama_n_rs_seq(draft.get()) == 0,
                       "effective draft cache contract mismatch");
    if (o.mtp) llama_set_embeddings_nextn(target.get(), true, false);
    // K1 never feeds a speculative MTP hidden to another head. Only actual
    // normalized target hidden is exported; draft greedy stays on the device.
    if (o.mtp) llama_set_embeddings_nextn(draft.get(), false, true);
    Batch target_batch(cp.n_batch); std::unique_ptr<Batch> draft_batch;
    if (o.mtp) draft_batch = std::make_unique<Batch>(cp.n_batch, width);
    const auto target_backing = backing(target.get()), draft_backing = o.mtp ? backing(draft.get()) : 0;
    const auto ready = Clock::now(); marker("ready_before_first", ready);
    if (o.memory_snapshots) snapshots.push_back(memory("ready_before_first", startup, device));

    marker("generation_prefill_begin", Clock::now());
    const auto prefill_begin = Clock::now();
    target_batch.fill(prompt, 0, nullptr, false, true);
    auto target_prefill = decode(target.get(), target_batch);
    std::vector<float> target_hidden;
    if (o.mtp) target_hidden = hidden(target.get(), prompt.size(), width);
    const auto first = sampled(target.get(), target_sampler.get(), prompt.size() - 1, 1, vocabulary).front();
    if (diagnostic.enabled()) diagnostic.capture(target.get(), "prefill", static_cast<int32_t>(prompt.size() - 1),
        vocabulary, first, prompt, nullptr, nullptr, 0);
    Json draft_prefill = nullptr; std::vector<float> carry, prior;
    if (o.mtp) {
        std::vector<float> shifted(prompt.size() * width, 0.0f);
        if (prompt.size() > 1) std::copy(target_hidden.begin(), target_hidden.end() - static_cast<std::ptrdiff_t>(width),
                                      shifted.begin() + static_cast<std::ptrdiff_t>(width));
        draft_batch->fill(prompt, 0, &shifted, false, false);
        draft_prefill = decode(draft.get(), *draft_batch);
        trim(draft.get(), prompt.size());
        carry.assign(target_hidden.end() - static_cast<std::ptrdiff_t>(width), target_hidden.end());
    }
    position(target.get(), prompt.size());
    std::size_t length = prompt.size(), frontier = o.mtp ? length : 0, lag = 0;
    llama_token catchup = LLAMA_TOKEN_NULL, pending = first;
    const auto prefill_end = Clock::now();
    Json rounds = Json::array(); Tokens generated{first};
    std::size_t target_rows = 0, draft_rows = 0, target_calls = 0, draft_calls = 0;
    std::size_t proposals = 0, agreements = 0, accepts = 0;
    const auto decode_begin = prefill_end;
    marker("generation_prefill_end", prefill_end); marker("generation_decode_begin", decode_begin);
    while (generated.size() < o.steps && !eos(pending) && (!o.max_rounds || rounds.size() < o.max_rounds)) {
        const auto begin = Clock::now(); const auto base = length, old_frontier = frontier, old_lag = lag;
        if (o.mtp) require(frontier + lag == length && lag <= 1 && (lag == 0 || prior.size() == width), "inconsistent MTP entry frontier");
        const auto quota = o.steps - generated.size();
        const bool single = !o.mtp || quota == 1 || o.capacity - length == 1;
        Tokens draft_ids;
        std::vector<float> draft_hidden;
        Json dft = nullptr;
        if (o.mtp) {
            if (lag) { draft_ids.push_back(catchup); draft_hidden.insert(draft_hidden.end(), prior.begin(), prior.end()); }
            draft_ids.push_back(pending); draft_hidden.insert(draft_hidden.end(), carry.begin(), carry.end());
            draft_batch->fill(draft_ids, frontier, &draft_hidden, false, !single);
            dft = decode(draft.get(), *draft_batch); ++draft_calls; draft_rows += draft_ids.size();
            frontier += draft_ids.size(); require(frontier == length + 1, "draft frontier did not reach current input");
        }
        const auto proposed = single ? LLAMA_TOKEN_NULL : sampled(draft.get(), draft_sampler.get(), draft_ids.size() - 1, 1, vocabulary).front();
        Tokens verify{pending}; if (!single) verify.push_back(proposed);
        target_batch.fill(verify, length, nullptr, true, false);
        if (rounds.size() == 5) {
            auto result = rejection_control(target.get(), target_sampler.get(), target_batch, diagnostic,
                prompt, generated, verify, rounds, dft, base, frontier, old_lag, width, vocabulary);
            result["model"] = o.model.string(); result["inputs"] = o.inputs.string();
            result["target_n_rs_seq"] = llama_n_rs_seq(target.get());
            result["target_effective_context"] = llama_n_ctx_seq(target.get());
            result["draft_contexts_retained_but_not_run_during_control"] = 1;
            return result;
        }
        auto tgt = decode(target.get(), target_batch); ++target_calls; target_rows += verify.size();
        const auto ids = sampled(target.get(), target_sampler.get(), 0, verify.size(), vocabulary);
        std::vector<float> actual_hidden;
        if (o.mtp) actual_hidden = hidden(target.get(), verify.size(), width);
        if (diagnostic.enabled() && (o.mtp ? Diagnostic::mtp_round(rounds.size()) : Diagnostic::plain_offset(generated.size()))) {
            Tokens prefix = prompt;
            prefix.insert(prefix.end(), generated.begin(), generated.end() - 1);
            require(prefix.size() == base, "diagnostic prefix does not match committed target history");
            for (std::size_t row = 0; row < verify.size(); ++row) {
                prefix.push_back(verify[row]);
                diagnostic.capture(target.get(), "round_" + std::to_string(rounds.size()) + "_row_" + std::to_string(row),
                    static_cast<int32_t>(row), vocabulary, ids[row], prefix, rounds.size(), row, generated.size());
            }
        }
        const bool agreed = !single && proposed == ids[0];
        const bool accepted = agreed && quota >= 2 && !eos(ids[0]);
        const auto commit = accepted ? std::size_t{2} : std::size_t{1};
        // Select effective accepted state BEFORE any output counters or bonus.
        // Original n_rs_seq=1 restores all target conv/GDN members on rejection.
        length += commit;
        if (o.mtp) trim(target.get(), length); else position(target.get(), length);
        if (o.mtp) {
            trim(draft.get(), frontier);
            carry.assign(actual_hidden.begin() + static_cast<std::ptrdiff_t>((commit - 1) * width),
                         actual_hidden.begin() + static_cast<std::ptrdiff_t>(commit * width));
            if (accepted) { prior.assign(actual_hidden.begin(), actual_hidden.begin() + static_cast<std::ptrdiff_t>(width)); catchup = proposed; }
            else { prior.clear(); catchup = LLAMA_TOKEN_NULL; }
            lag = length - frontier; require(lag == (accepted ? 1u : 0u), "published draft lag mismatch");
        }
        Tokens emitted{ids[0]}; if (accepted) emitted.push_back(ids[1]);
        pending = emitted.back(); generated.insert(generated.end(), emitted.begin(), emitted.end());
        proposals += !single; agreements += agreed; accepts += accepted;
        const auto end = Clock::now();
        rounds.push_back({{"index", rounds.size()}, {"target_before", base}, {"draft_before", o.mtp ? Json(old_frontier) : Json(nullptr)}, {"lag_before", o.mtp ? Json(old_lag) : Json(nullptr)},
            {"pending", verify[0]}, {"draft", proposed}, {"target_ids", ids}, {"agreed", agreed}, {"accepted_draft", accepted},
            {"emitted", emitted}, {"quota_before", quota}, {"single", single}, {"verified_target_rows", verify.size()},
            {"committed_target_rows", commit}, {"draft_rows", draft_ids.size()}, {"target_after", length},
            {"draft_after", o.mtp ? Json(frontier) : Json(nullptr)}, {"lag_after", o.mtp ? Json(lag) : Json(nullptr)}, {"catchup_token", catchup},
            {"native_target_pos_max", llama_memory_seq_pos_max(llama_get_memory(target.get()), 0)},
            {"native_draft_pos_max", o.mtp ? Json(llama_memory_seq_pos_max(llama_get_memory(draft.get()), 0)) : Json(nullptr)},
            {"draft_compute", dft}, {"target_compute", tgt}, {"seconds", seconds(end, begin)}});
    }
    throw std::runtime_error("natural stream stopped before the requested rejection checkpoint");
}
} // namespace peer_mtp

int main(int argc, char ** argv) {
    try {
        const auto options = peer_mtp::options(argc, argv); const auto result = peer_mtp::run(options);
        const auto text = result.dump(2) + '\n';
        if (!options.output.empty()) {
            if (options.output.has_parent_path()) std::filesystem::create_directories(options.output.parent_path());
            std::ofstream out(options.output, std::ios::binary); out << text;
            if (!out) throw std::runtime_error("cannot write result JSON");
        }
        std::cout << text; return 0;
    } catch (const std::exception & error) { std::cerr << "peer MTP error: " << error.what() << '\n'; return 1; }
}
