"""Prepare the one-context RS1 rejection control; never compile/run native code."""
from pathlib import Path
import difflib
import hashlib
import json

HERE = Path(__file__).resolve().parent
W = HERE.parent
ROOT = W.parents[1]
BASE = W / 'peer/peer_mtp.cc'
EXPECTED = '62ccafc9d1bdf6a2062992feede0d51ae7c8657c74e1774fc095aaf27e09f1dc'


def once(source, old, new):
    assert source.count(old) == 1, old
    return source.replace(old, new)


def main():
    raw = BASE.read_bytes()
    assert hashlib.sha256(raw).hexdigest() == EXPECTED
    before = HERE / 'before/peer_mtp.cc'
    before.parent.mkdir(parents=True, exist_ok=True)
    assert not before.exists() and not (HERE / 'control_peer.cc').exists()
    before.write_bytes(raw)
    source = raw.decode().replace('\r\n', '\n')
    helpers = r'''
// The sequence API serializes target memory only. Host carry/prior, sampler
// outputs and draft context are not saved/restored and are not resumed here.
std::vector<uint8_t> state_bytes(llama_context * context, llama_state_seq_flags flags) {
    llama_synchronize(context);
    const auto bytes = llama_state_seq_get_size_ext(context, 0, flags);
    require(bytes > 0, "native sequence checkpoint size is zero");
    std::vector<uint8_t> result(bytes);
    require(llama_state_seq_get_data_ext(context, result.data(), result.size(), 0, flags) == bytes,
            "native sequence checkpoint export consumed wrong byte count");
    return result;
}

Json save_partial(llama_context * context, Diagnostic & diagnostic,
                  const std::string & name, std::size_t length) {
    position(context, length);
    const auto data = state_bytes(context, LLAMA_STATE_SEQ_FLAGS_PARTIAL_ONLY);
    const auto file = name + ".partial-state.bin";
    Diagnostic::binary(diagnostic.directory / file, data.data(), data.size());
    // Opaque bytes are not numerical data. An offline fixed-source parser must
    // validate headers/types/extents and select only each logical R/S payload.
    return {{"file", file}, {"bytes", data.size()}, {"seq_id", 0},
            {"flags", LLAMA_STATE_SEQ_FLAGS_PARTIAL_ONLY}, {"logical_length", length},
            {"native_pos_max", llama_memory_seq_pos_max(llama_get_memory(context), 0)},
            {"operation", "get-only; no set_data or rollback normalization"},
            {"payload_note", "Original PARTIAL_ONLY blob. Headers/placement are not floats; logical R/S require typed offline parsing."}};
}

struct ControlOutput final { Json observation; Tokens ids; };

ControlOutput control_decode(llama_context * context, llama_sampler * sampler, Batch & batch,
                             Diagnostic & diagnostic, const std::string & name,
                             const Tokens & inputs, Tokens prefix, std::size_t first,
                             std::size_t width, int32_t vocabulary) {
    require(prefix.size() == first, "control input prefix length mismatch");
    batch.fill(inputs, first, nullptr, true, false);
    auto compute = decode(context, batch);
    auto ids = sampled(context, sampler, 0, inputs.size(), vocabulary);
    const auto values = hidden(context, inputs.size(), width);
    for (std::size_t row = 0; row < inputs.size(); ++row) {
        prefix.push_back(inputs[row]);
        diagnostic.capture(context, name + "_row_" + std::to_string(row), static_cast<int32_t>(row),
                           vocabulary, ids[row], prefix, nullptr, row, first);
    }
    const auto file = name + ".hidden.f32";
    Diagnostic::binary(diagnostic.directory / file, values.data(), values.size() * sizeof(float));
    Json observation{{"name", name}, {"inputs", inputs}, {"first_position", first},
        {"native_ids", ids}, {"compute", compute}, {"evaluated_prefix_ids", prefix},
        {"native_pos_max_after_decode", llama_memory_seq_pos_max(llama_get_memory(context), 0)},
        {"hidden", {{"file", file}, {"dtype", "F32_LE"}, {"shape", {inputs.size(), width}},
                    {"bytes", values.size() * sizeof(float)}}}};
    return {std::move(observation), std::move(ids)};
}

Json rejection_control(llama_context * context, llama_sampler * sampler, Batch & batch,
                       Diagnostic & diagnostic, const Tokens & prompt, const Tokens & generated,
                       const Tokens & natural_verify, const Json & natural_rounds,
                       const Json & original_draft_compute, std::size_t base,
                       std::size_t draft_frontier, std::size_t old_lag,
                       std::size_t width, int32_t vocabulary) {
    const Tokens expected_generated{71093,12305,198,464,19298,198,1445,18904,1120,5586,11};
    require(prompt.size() == 154 && base == 164 && generated == expected_generated &&
            natural_rounds.size() == 5 && natural_verify == Tokens({11,36760}) &&
            draft_frontier == 165 && old_lag == 1,
            "natural pre-control trajectory differs from the recorded first rejection witness");
    Tokens prefix = prompt;
    prefix.insert(prefix.end(), generated.begin(), generated.end() - 1);
    require(prefix.size() == base, "checkpoint target history length mismatch");
    position(context, base);
    const auto checkpoint = state_bytes(context, LLAMA_STATE_SEQ_FLAGS_NONE);
    Diagnostic::binary(diagnostic.directory / "C.full-state.bin", checkpoint.data(), checkpoint.size());
    const auto restore = [&]() {
        require(llama_state_seq_set_data_ext(context, checkpoint.data(), checkpoint.size(), 0,
                    LLAMA_STATE_SEQ_FLAGS_NONE) == checkpoint.size(),
                "complete checkpoint restore consumed wrong byte count");
        position(context, base);
    };

    restore();
    auto a_first = control_decode(context, sampler, batch, diagnostic, "A_T1_11", Tokens{11}, prefix, base, width, vocabulary);
    auto a_165 = save_partial(context, diagnostic, "A165", base + 1);
    auto continued_prefix = prefix; continued_prefix.push_back(11);
    auto a_next = control_decode(context, sampler, batch, diagnostic, "A_T1_51338", Tokens{51338}, continued_prefix,
                                 base + 1, width, vocabulary);
    auto a_166 = save_partial(context, diagnostic, "A166", base + 2);

    restore();
    auto b_first = control_decode(context, sampler, batch, diagnostic, "B_T2_11_36760", Tokens{11,36760}, prefix,
                                  base, width, vocabulary);
    const bool rejection_reproduced = b_first.ids[0] != 36760;
    trim(context, base + 1);
    auto b_165 = save_partial(context, diagnostic, "B165_after_trim", base + 1);
    // Critical witness: no set_data/clear/context rebuild occurs between the
    // native trim and this decode. PARTIAL_ONLY get preserves pending rs_idx.
    auto b_next = control_decode(context, sampler, batch, diagnostic, "B_T1_51338_after_trim", Tokens{51338}, continued_prefix,
                                 base + 1, width, vocabulary);
    auto b_166 = save_partial(context, diagnostic, "B166", base + 2);
    return {{"scope", "One-model one-RS1-target diagnostic. Natural first5 MTP rounds, then serial same-checkpoint controls; not throughput or numerical-quality acceptance."},
        {"sampling", "Original native GPU greedy capacity2, CPU diagnostic argmax never fed back"},
        {"natural_rounds_completed", natural_rounds}, {"natural_generated_before_control", generated},
        {"prompt_ids", prompt}, {"checkpoint_prefix_ids", prefix}, {"checkpoint_length", base},
        {"natural_round5_draft_compute", original_draft_compute}, {"natural_round5_verify", natural_verify},
        {"draft_frontier_after_original_round5_draft", draft_frontier},
        {"checkpoint", {{"file", "C.full-state.bin"}, {"bytes", checkpoint.size()}, {"flags", LLAMA_STATE_SEQ_FLAGS_NONE},
            {"seq_id", 0}, {"complete_target_hybrid_memory", true},
            {"excludes", "Host carry/prior/pending, sampler/output logits/hidden, and independent draft context are not serialized."}}},
        {"A", {{"first", a_first.observation}, {"logical165", a_165}, {"next", a_next.observation}, {"logical166", a_166}}},
        {"B", {{"first", b_first.observation}, {"original_rejection_reproduced", rejection_reproduced},
            {"row0_matches_original_51338", b_first.ids[0] == 51338},
            {"selected_rows", 1}, {"trim_to", base + 1}, {"logical165", b_165},
            {"restore_between_trim_and_next", false}, {"next", b_next.observation}, {"logical166", b_166}}},
        {"diagnostic", diagnostic.summary()}, {"native_target_contexts", 1}, {"shared_model_objects", 1},
        {"control_followup_inputs", "Fixed original next token51338 in both branches, independent of current diagnostic argmax; not natural generation/acceptance evidence."},
        {"limits", "Same RS1 T1/T2 geometry may differ mathematically; no byte/tolerance agreement presumed. Two full-C restores normalize both initial branches; B pending restore path remains uninterrupted after trim."}};
}
'''
    source = once(source, 'struct Options final {', helpers + '\nstruct Options final {')
    source = once(source, 'Diagnostic diagnostic(o.diagnostic_dir);', '''require(o.mtp && !o.diagnostic_dir.empty(), "control requires --mtp on and --diagnostic-dir DIR");
    require(o.steps == 64 && o.capacity == 1024 && (!o.max_rounds || o.max_rounds >= 6),
            "control keeps original steps64/C1024 and must reach zero-based round5");
    Diagnostic diagnostic(o.diagnostic_dir);''')
    anchor = '        target_batch.fill(verify, length, nullptr, true, false);'
    source = once(source, anchor, anchor + '''
        if (rounds.size() == 5) {
            auto result = rejection_control(target.get(), target_sampler.get(), target_batch, diagnostic,
                prompt, generated, verify, rounds, dft, base, frontier, old_lag, width, vocabulary);
            result["model"] = o.model.string(); result["inputs"] = o.inputs.string();
            result["target_n_rs_seq"] = llama_n_rs_seq(target.get());
            result["target_effective_context"] = llama_n_ctx_seq(target.get());
            result["draft_contexts_retained_but_not_run_during_control"] = 1;
            return result;
        }''')
    end = source.index('    const auto endpoint = Clock::now(); marker("generation_decode_end", endpoint);')
    namespace_end = source.index('} // namespace peer_mtp', end)
    source = source[:end] + '    throw std::runtime_error("natural stream stopped before the requested rejection checkpoint");\n}\n' + source[namespace_end:]
    (HERE / 'control_peer.cc').write_text(source, encoding='utf-8', newline='\n')
    (HERE / 'control.diff').write_text(''.join(difflib.unified_diff(raw.decode().replace('\r\n', '\n').splitlines(True), source.splitlines(True), fromfile='W/peer/peer_mtp.cc', tofile='W/control/control_peer.cc')), encoding='utf-8')
    print(json.dumps(dict(source=str(HERE / 'control_peer.cc'), bytes=len(source.encode()), sha256=hashlib.sha256(source.encode()).hexdigest())))


if __name__ == '__main__':
    main()
