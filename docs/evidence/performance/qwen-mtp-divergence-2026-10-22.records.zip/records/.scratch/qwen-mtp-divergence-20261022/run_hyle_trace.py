from pathlib import Path
import importlib.util,os,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;R=W.parents[1];V=R/'.scratch/qwen-mtp-window-20261022'
s=importlib.util.spec_from_file_location('helper',W/'build.py');h=importlib.util.module_from_spec(s);s.loader.exec_module(h);b,c=h.b,h.c
out=W/'hyle-trace1';out.mkdir(exist_ok=False)
ready=c.read(V/'qwen-ready-attempt1.json');assert h.same(ready['image']) and h.same(ready['source'])
env=os.environ.copy();env['PATH']=c.read(ready['runtime_environment']['path'])['PATH']
command=[ready['image']['path'],'--inputs',str(V/'inputs/mtp'),'--steps','20','--capacity','1024','--max-sessions','1','--active-sequences','1','--prefix-cache','off','--progress','direct','--replay','auto','--mtp','on','--trace',str(out/'trace'),'--trace-level','decisions']
c.save(out/'identity.json',ready);c.save(out/'plan.json',dict(command=command,diagnostic=True,throughput_evidence=False,source_graph_outputs_always_published=True,limit='requested20 vs prior64: compare prefix through round9 only after actual ID/role verification; no speed claim'))
c.execute('run',command,env,out)
