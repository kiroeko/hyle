"""Read-only pure-host recomputation of this stage's completed 9+3 processes."""
from pathlib import Path
import collections
import importlib.util
import json
import re
import statistics
import sys

sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent.parent
R = S.parents[1]
P = S / "performance"
previous = R / ".scratch/qwen-batch-profile-20261022"
D = R / ".scratch/qwen-cli-batch-20261022"
spec = importlib.util.spec_from_file_location(
    "memory_checker", D / "review/recompute_performance.py")
h = importlib.util.module_from_spec(spec)
spec.loader.exec_module(h)
read, identity, stats = h.read, h.identity, h.stats
ready = {"before": read(previous / "qwen-ready-attempt2.json"),
         "batch": read(S / "qwen-ready-attempt1.json"),
         "peer": read(D / "peer-ready.json")}


def change(a, b):
    return (a / b - 1) * 100


def main():
    rows, memory, raw_identities, per_arm_ids = [], {}, [], {}
    expected_order = ["before", "batch", "peer", "peer", "batch", "before",
                      "batch", "before", "peer"]
    physical_reference = None
    for mode in ("timing", "memory"):
        directory = P / mode
        inputs, terminal = read(directory / "inputs.json"), read(directory / "summary.json")
        entries = inputs["commands"]
        assert terminal["processes"] == len(entries) == (9 if mode == "timing" else 3)
        assert [x["variant"] for x in entries] == (
            expected_order if mode == "timing" else ["before", "batch", "peer"])
        assert inputs["profiler"] is False and inputs["diagnostic"] is False
        assert inputs["mode"] == mode
        for entry in entries:
            arm, folder = entry["variant"], Path(entry["folder"])
            result = read(folder / "result.json")
            assert result["exit"] == 0 and result["reader_errors"] == []
            assert result["image"] == ready[arm]["image"]
            assert result["command"] == entry["command"]
            assert result["profiler"] is False
            assert result["memory_only"] == (mode == "memory")
            assert "--trace" not in entry["command"]
            path = folder / ("peer-result.json" if arm == "peer" else "stdout.log")
            raw = read(path)
            assert raw["processed_tokens"] == raw["actual_graph_tokens"] == 1728
            assert raw["generated_tokens"] == 198 and raw["actual_graph_calls"] == 99
            assert raw["prefix_cache"] == "off" and raw["reused_tokens"] == 0
            waves = raw["waves"]
            units = raw["episodes"] if arm == "peer" else raw["batches"]
            assert len(waves) == len(units) == 99
            phase = dict(prefill=0.0, decode=0.0)
            rounds = [dict(prefill_seconds=0.0, decode_seconds=0.0) for _ in range(3)]
            physical = []
            for i, (wave, unit) in enumerate(zip(waves, units)):
                kind = "prefill" if i % 33 == 0 else "decode"
                t = 256 if kind == "prefill" else 1
                actual_t = unit["T"] if arm == "peer" else unit["query_rows"]
                names = tuple(m["session"] for m in unit["members"]) if arm == "peer" else tuple(unit["session_ids"])
                assert names == ("alice", "bob")
                assert actual_t == t and unit["kind"] == wave["kind"] == kind
                assert unit["requests"] == wave["outputs"] == 2
                assert wave["logical_tokens"] == wave["actual_tokens"] == 2 * t
                assert wave["graph_calls"] == 1 and wave["seconds"] > 0
                phase[kind] += wave["seconds"]
                rounds[i // 33][kind + "_seconds"] += wave["seconds"]
                physical.append((kind, t, names))
            assert sum(w["actual_tokens"] for w in waves) == 1728
            assert sum(w["outputs"] for w in waves) == 198
            if physical_reference is None:
                physical_reference = physical
            assert physical_reference == physical
            ids = {}
            for session in raw["sessions"]:
                name = session["id" if arm == "peer" else "session_id"]
                ids[name] = session["generated_ids"]
                assert len(ids[name]) == 99 and session["visible_tokens"] == 864
                assert len(session["phases"]) == 6
                for item, before in zip(session["phases"], (0, 256, 288, 544, 576, 832)):
                    assert item["context_before"] == before
                    assert item["context_after"] == before + (256 if item["kind"] == "prefill" else 32)
                if arm != "peer":
                    assert session["restored_calls"] == session["restored_tokens"] == 0
                    assert session["recomputed_decision_changes"] == []
            if arm in per_arm_ids:
                assert per_arm_ids[arm] == ids
            per_arm_ids[arm] = ids
            wall = raw["session_seconds" if arm == "peer" else "interleaved_seconds"]
            assert 0 <= wall - sum(phase.values()) < 0.001
            stderr = (folder / "stderr.log").read_text(encoding="utf-8-sig")
            if arm == "peer":
                loading = dict(load_seconds=raw["model_load_seconds"], ready_seconds=raw["ready_seconds"])
                assert raw["native_sequence_quota"] == 4 and raw["native_n_ctx"] == 2048
                assert raw["cache_backing_bytes"] == 105971712
                assert raw["seq_copy_api_calls"] == raw["directory_evictions"] == 0
            else:
                loading = dict(
                    load_seconds=float(re.search(r"^weights_load_seconds=(\S+)", stderr, re.M)[1]),
                    ready_seconds=float(re.search(r"startup_to_ready_seconds=(\S+)", stderr)[1]))
                assert raw["cache_shared_backing_bytes"] == 103710768
                assert raw["max_batch_requests"] == 2
            metrics = dict(
                prefill_tps=1536 / phase["prefill"], decode_tps=192 / phase["decode"],
                total_output_tps=198 / wall,
                startup_inclusive_output_tps=198 / raw["startup_total_seconds"],
                prefill_seconds=phase["prefill"], decode_seconds=phase["decode"],
                request_wall_seconds=wall, startup_total_seconds=raw["startup_total_seconds"],
                outside_waves_seconds=wall - sum(phase.values()), **loading)
            row = dict(arm=arm, folder=str(folder.relative_to(R)), metrics=metrics,
                       rounds=rounds, raw=identity(path), result=identity(folder / "result.json"))
            raw_identities.append(dict(arm=arm, mode=mode, raw=row["raw"], result=row["result"]))
            if mode == "timing":
                rows.append(row)
            else:
                memory[arm] = h.check_memory(folder)
    assert len(rows) == 9 and len(memory) == 3
    assert per_arm_ids["before"] == per_arm_ids["batch"] == per_arm_ids["peer"]
    groups = {arm: [x for x in rows if x["arm"] == arm] for arm in ready}
    table = {arm: {key: stats([r["metrics"][key] for r in samples])
                   for key in samples[0]["metrics"]} for arm, samples in groups.items()}
    changes = {arm: {key: change(table["batch"][key]["median"], table[arm][key]["median"])
                     for key in ("prefill_tps", "decode_tps", "total_output_tps", "startup_inclusive_output_tps")}
               for arm in ("before", "peer")}
    round_rates = {arm: [dict(prefill_tps=stats([512 / r["rounds"][i]["prefill_seconds"] for r in samples]),
                                    decode_tps=stats([64 / r["rounds"][i]["decode_seconds"] for r in samples]))
                         for i in range(3)] for arm, samples in groups.items()}

    old_plan = read(Path(ready["before"]["link_plan"]["path"]))
    new_plan = read(Path(ready["batch"]["link_plan"]["path"]))
    old_inputs, new_inputs = old_plan["inputs"], new_plan["inputs"]
    assert len(old_inputs) == len(new_inputs) == 195
    unchanged = []
    replaced = []
    for old, new in zip(old_inputs, new_inputs):
        if old == new:
            unchanged.append(old)
        else:
            replaced.append(dict(before=old, current=new))
    assert len(replaced) == 1
    assert "provider" in replaced[0]["current"]["path"]
    assert any("native" in x["path"] and "qwen-batch-profile-20261022" in x["path"] for x in unchanged)
    assert old_inputs[0] == new_inputs[0]  # Same actual consumer object.
    tests = read(S / "tests-run1/run.result.json")
    assert tests["exit"] == 0
    import xml.etree.ElementTree as ET
    xml = ET.parse(S / "tests-run1/gtest.xml").getroot()
    assert int(xml.attrib["tests"]) == 14 and int(xml.attrib["failures"]) == 0
    regression = read(S / "review/topone-model-regression.json")
    assert regression["status"].startswith("PASS")
    environment = {}
    for mode in ("timing", "memory"):
        environment[mode] = {label: (P / mode / (label + "-gpu.stdout.log")).read_text(encoding="utf-8-sig").strip()
                             for label in ("window-before", "window-after")}
    report = dict(
        status="PASS independent raw workload/metric/memory recomputation; this capability-only change shows near-equal sampled throughput, not a claimed speedup",
        scope="This completed stage only: 9 unprofiled timing processes, 3 independent memory processes; no previous-window pooling, no GPU/build/product edits by reviewer.",
        driver=identity(S / "performance.py"), checker=identity(Path(__file__)),
        actual_work=dict(processes=12, prefill_tokens=1536, decode_tokens=192,
                         total_input_tokens=1728, returned_decisions=198,
                         physical_B2_episodes=99, prefill_episodes=3, decode_episodes=96,
                         sessions=2, final_tokens_per_session=864, prefix_cache="off",
                         workload_and_198_ids_equal_across_all_arms=True,
                         interleaved_timing_order=expected_order),
        timing_processes=rows, process_statistics=table,
        current_vs_other_median_rate_change_percent=changes, round_rates=round_rates,
        memory=memory,
        source_and_build=dict(ready_receipts=ready, link_input_count=195,
                              unchanged_stored_input_identities=len(unchanged), replaced=replaced,
                              checks="Compared fixed link receipts; did not rehash inherited objects/SDKs/models.",
                              common_native_topone_and_consumer_object_unchanged=True),
        related_correctness=dict(tests=identity(S / "tests-run1/gtest.xml"), tests_passed=14,
                                 model_regression=identity(S / "review/topone-model-regression.json"),
                                 model_regression_scope="Parent/independent byte checker records R1/B2 90 finite vectors exactly matching their own previous same-B baselines; this performance review does not re-read vector payloads."),
        window_gpu_snapshots=environment,
        limits=[
            "Headline rates are process medians of per-process token-count/summed wall time; no averaging instantaneous or per-token TPS. Total is198/requestwall, startup-inclusive is a separate198/startupwall metric.",
            "Current vs before decode and total min/max ranges overlap. Three fresh processes per arm, no exclusive GPU/fixed clocks/page-cache reset or statistical significance; the small difference is not evidence of a stable speedup.",
            "Both arms still have1234 logical steps and the same native TopK1 kernels; prepared/capture eligibility can combine command recording differently. No new native profile was run here, so do not infer physical GraphLaunch counts or a specific component's time saving from capability flags.",
            "Same fixed token inputs, same198 IDs and finite vectors do not establish cross-engine BF16 quality acceptance; this synthetic synchronized two-session teacher-forced workload does not establish free-running serving latency or four-user scaling.",
            "Both preserve full KV+conv/GDN state, but Hyle immutable N+R version backing and peer in-place/native context contracts are not identical. Hyle state backing103710768 bytes vs peer105971712; memory sampler separately observes IO/weights/workspace/runtime.",
            "Sampled per-PID PDH GPU and CPU working-set peaks are lower bounds, not exact allocation maxima; CPU private commit is not private resident memory. Simultaneous GPU-total peak is not the sum of dedicated/shared independent maxima.",
            "Memory was sampled in separate processes at requested10ms; actual gap statistics are reported. Marker timestamps are reader receipts with brackets, not exact device boundaries; two sessions' overlapping phase windows must not be added. Missing ready-to-firstP samples mean ready-to-inference allocation delta is unknown.",
            "After-window nvidia-smi utilization is a rolling snapshot immediately after inference and may include the just-finished consumer. It cannot alone identify external background GPU activity.",
        ])
    out = S / "review/final-review.json"
    out.write_text(json.dumps(report, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print(json.dumps(dict(report=identity(out), medians={a: {k: table[a][k]["median"]
          for k in ("prefill_tps", "decode_tps", "total_output_tps", "startup_inclusive_output_tps")}
          for a in ready}, changes=changes,
          memory={a: dict(peaks=x["peaks_bytes"], gap_ms=x["running_sample_gap_ms"],
                          ready_baseline=x["ready_baseline_available"]) for a, x in memory.items()}), indent=2))


if __name__ == "__main__":
    main()
