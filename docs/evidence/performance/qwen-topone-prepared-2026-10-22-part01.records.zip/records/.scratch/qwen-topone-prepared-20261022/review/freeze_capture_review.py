"""Freeze the bounded source-only capture review; does not build or run CUDA."""
from pathlib import Path
import difflib
import hashlib
import json
import shutil

repo = Path(__file__).resolve().parents[3]
stage = repo / ".scratch/qwen-topone-prepared-20261022"
review = stage / "review"
relative = Path("tests/graph_route_cuda/topk_test.cc")
before = stage / "before" / relative
current = stage / "current" / relative
current.parent.mkdir(parents=True, exist_ok=True)
shutil.copyfile(repo / relative, current)


def identity(path):
    data = path.read_bytes()
    return {"path": str(path.relative_to(repo)), "bytes": len(data),
            "sha256": hashlib.sha256(data).hexdigest()}


diff = review / "topk-test.diff"
diff.write_text("".join(difflib.unified_diff(
    before.read_text(encoding="utf-8").splitlines(keepends=True),
    current.read_text(encoding="utf-8").splitlines(keepends=True),
    fromfile="before/" + relative.as_posix(),
    tofile=relative.as_posix())), encoding="utf-8")

sources = [
    "src/compute_provider_cuda/collectives_provider.cc",
    "src/compute_provider_cuda/collectives.h",
    "src/compute_provider_cuda/collectives.cu",
    "include/hyle/compute/provider.h",
    "include/hyle/compute/detail/queue_sequence.h",
    "src/compute/operation.cc",
    "src/compute_backend_cuda/cuda_backend.cc",
    "src/graph/executable.cc",
    str(relative),
]
report = {
    "scope": "Bounded source review plus edits only to existing CUDA TopK Graph tests; no build, GPU, native process or product implementation edits by reviewer.",
    "source_identities": [identity(repo / path) for path in sources],
    "test_before": identity(before),
    "test_current": identity(current),
    "test_diff": identity(diff),
    "original_gap": {
        "source": identity(stage / "before/src/compute_provider_cuda/collectives_provider.cc"),
        "anchors": ["collectives_provider.cc:27-45 runtime", "collectives_provider.cc:291-314 capture rejection/error synchronization"],
        "fact": "Nonempty TopK was uniformly Managed and capture incompatible, including the new fixed two-kernel arg_tiles program. Thus ordinary RequirePrepared filtering and RequireCapture were both blocked.",
    },
    "current_root_fix_review": {
        "anchors": ["collectives_provider.cc:27-49", "collectives_provider.cc:295-325", "collectives.cu:460-485", "collectives.cu:549-572"],
        "conclusion": "No source-level blocker found for the narrow arg_tiles capability change. Root owns implementation and actual validation.",
        "facts": [
            "Program is zero-initialized by describe; configure_typed is the sole writer of nonzero arg_tiles, only for TopK K=1, more than one row and width>2048. No model, vocabulary or batch-size whitelist is needed.",
            "Cold configure resolves both kernel attributes and reserves the complete caller-owned aligned partial workspace. The successful arg_tiles submit branch only launches fixed geometry kernels and reports launch status; it does not call CUB host dispatch, shape search, heap allocation, packing, device-to-host validation or stream synchronization.",
            "runtime(program) is shared by proposal and selected prepared artifact. Root now marks Gather or nonzero arg_tiles Prepared/capture-compatible, with caller workspace and concurrent Invocations; empty programs retain the existing no-op Prepared contract.",
            "The same runtime fact now gates external-capture rejection and the old error-path host synchronization. Single-row TopK1, short multirow TopK1, K>1 and Scan remain Managed and uncapturable.",
            "Each Invocation stores its own caller workspace pointer; Graph allocations and captured command arguments are per Invocation. Concurrent direct callers must still supply distinct writable workspace, as required by the existing borrowed-workspace contract.",
        ],
    },
    "accepted_prefix_boundary": {
        "anchors": ["collectives.cu:555-562", "collectives_provider.cc:313-325", "queue_sequence.h:29-50,94-104", "operation.cc:1872-1890", "cuda_backend.cc:1332-1349"],
        "facts": [
            "The first tile kernel may be accepted before the second finish launch fails. The current CUDA helper returns only cudaError_t and cannot prove that an error means zero native work was accepted.",
            "Provider retains accepted_command(status), conservatively retaining the original ordered prefix and Completion machinery. Do not turn a failed tiled submission into rejected solely from the helper return status.",
            "Prepared arg_tiles no longer runs cudaStreamSynchronize on an error. Capture failure must terminate/abort the original recording, not synchronize a capturing stream; original CUDA abort_capture ends and destroys the recording.",
            "This is a source-level error ownership review, not an injected first-success/second-failure runtime proof. No new failure hook was added.",
        ],
    },
    "tests_added": [
        {
            "name": "CudaDefaultGraph.WideTopOnePreparedCaptureKeepsInvocationWorkspaceIsolated",
            "coverage": "Float32 3x8193 K1: direct provider/runtime/capture facts; ordinary Graph RequirePrepared selects CCCL; two Invocations with separate queues, IO and Graph workspace; RequireCapture+HostWaitReject; both submit before either wait; three replay rounds; same-address changed contents; subsequent cold preparations assert zero recordings and actual capture reuse; cross-tile equal maxima use independent std::max_element first-index oracle; final round only changes second Invocation and checks first result retained.",
        },
        {
            "name": "CudaDefaultGraph.OtherTopKProgramsKeepManagedReplayContract",
            "coverage": "Three bounded exclusions: 1x8193 K1, 3x17 K1 and 3x8193 K2. Direct stays CCCL Managed/capture=false and ordinary RequirePrepared Graph compile rejects.",
        },
    ],
    "existing_reusable_entries": {
        "retained_test": "CudaDefaultGraph.SoftmaxTopKAndRenormalizationCaptureBothOutputs remains unchanged; its existing explicit Commands/AllowAny contract must not silently become strict prepared.",
        "direct_numerical_tests": [
            "CudaCccl.WideMultiRowTopOneFourTypesAndStridedAxesKeepOracle",
            "CudaCccl.MultiRowTopOneOriginalBitsAndCrossTileIndices",
        ],
        "ownership_pattern": "CudaCccl.PendingCompletionRetainsPreparedOwnersWithCallerWorkspace (existing native gate and borrowed payload/workspace lifetime; no new gate test required for the classification-only change).",
        "generic_policy_pattern": "GraphRegions.PreparedOnlyRejectsUnknownAndManagedBeforeRegionPreparation covers discovery filtering generically, but is not a real CCCL/capture test.",
        "cmake_target": "hyle_graph_route_cuda_test (existing topk_test.cc source); no CMake edits required.",
        "incremental_compile_recipe": ".scratch/qwen-batch-profile-20261022/compile1/graph-test/plan.json",
        "retained_test_link_plan": ".scratch/qwen-batch-profile-20261022/tests-link3/link-plan.json",
        "suggested_gtest_filter": "CudaDefaultGraph.*Top*:CudaCccl.WideMultiRowTopOneFourTypesAndStridedAxesKeepOracle:CudaCccl.MultiRowTopOneOriginalBitsAndCrossTileIndices",
    },
    "validation": {
        "git_diff_check_owned_test": "passed",
        "source_static_review": "completed",
        "compile": "not run by reviewer; root owns",
        "cuda_tests": "not run by reviewer; root owns",
        "mtp": "No MTP model inference or quality/performance claim made by this review/test edit.",
    },
}
out = review / "capture-review.json"
out.write_text(json.dumps(report, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
freeze = {"source": identity(repo / relative), "before": identity(before),
          "current": identity(current), "diff": identity(diff),
          "review": identity(out), "stop_writing": True,
          "build_or_gpu_run": False}
(review / "source-freeze.json").write_text(
    json.dumps(freeze, indent=2) + "\n", encoding="utf-8")
print(json.dumps(freeze, indent=2))
