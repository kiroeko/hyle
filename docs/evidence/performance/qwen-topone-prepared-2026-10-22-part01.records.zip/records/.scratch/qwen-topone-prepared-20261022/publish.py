"""Publish separate capability/performance and real-weight loading evidence."""
from pathlib import Path
import hashlib,json,zipfile
S=Path(__file__).resolve().parent;R=S.parents[1];M=R/'.scratch/qwen-mtp-weights-20261022'
read=lambda p:json.loads(Path(p).read_text(encoding='utf-8-sig'))
def ident(p):
 p=Path(p).resolve();h=hashlib.sha256()
 with p.open('rb')as f:
  for b in iter(lambda:f.read(8<<20),b''):h.update(b)
 return dict(path=str(p),bytes=p.stat().st_size,sha256=h.hexdigest())
def save(p,d):p.write_text(json.dumps(d,indent=2,ensure_ascii=False,allow_nan=False)+'\n',encoding='utf-8')
def pack(stage,directory,stem,extra):
 paths=list(extra)
 for p in stage.rglob('*'):
  if not p.is_file()or any(x in('tmp','__pycache__')for x in p.relative_to(stage).parts):continue
  if p.suffix.lower()in('.obj','.exe','.dll','.lib','.exp','.pdb','.map'):continue
  if p.name=='published.json':continue
  paths.append(p)
 paths=sorted(set(p.resolve()for p in paths),key=lambda p:p.relative_to(R).as_posix())
 files=[dict(**ident(p),entry=p.relative_to(R).as_posix())for p in paths];archives=[];z=None;current=None
 try:
  for p,row in zip(paths,files):
   if z is None or z.fp.tell()>80_000_000:
    if z is not None:z.close();archives.append(ident(current))
    current=directory/f'{stem}.data.part{len(archives)+1:02}.zip';assert not current.exists()
    z=zipfile.ZipFile(current,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6)
   z.write(p,row['entry'])
  if z is not None:z.close();z=None;archives.append(ident(current))
 finally:
  if z is not None:z.close()
 entries={}
 for a in archives:
  assert a['bytes']<100*2**20
  with zipfile.ZipFile(a['path'])as z:
   assert z.testzip()is None
   for entry in z.infolist():
    assert entry.filename not in entries;data=z.read(entry.filename);entries[entry.filename]=(len(data),hashlib.sha256(data).hexdigest())
 assert len(entries)==len(files)and all(entries[x['entry']]==(x['bytes'],x['sha256'])for x in files)
 return dict(archives=archives,archive_files=files,archive_layout='Ordinary ZIP volumes below100MiB, repository-relative entries; CRC and every entry SHA verified. No models, SDKs, objects or executables duplicated.'),dict(archive_verified_entries=len(entries),archived_bytes=sum(x['bytes']for x in files))

provider=read(S/'compile1/provider/identity.json');graph=read(S/'compile1/graph-test/identity.json')
assert ident(R/'src/compute_provider_cuda/collectives_provider.cc')==provider['source']
assert ident(R/'tests/graph_route_cuda/topk_test.cc')==graph['source']
assert read(S/'tests-run1/run.result.json')['exit']==0 and '14 tests.'in(S/'tests-run1/run.stdout.log').read_text()
assert all(read(M/f'{name}-run1/run.result.json')['exit']==0 for name in('prepare','probe','r1','batch'))
probe=read(M/'probe-run1/run.stdout.log');assert probe['mtp_tensors']==15 and probe['all_mtp_device_bytes_equal_original']and not probe['MTP_inference_executed']
for mode in('probe','qwen'):
 rec=read(M/f'compile1/{mode}/identity.json');assert ident(R/'tools/qwen35_text/main.cc')==rec['main']
 ready=read(M/f'{mode}-ready-attempt1.json');assert ident(ready['image']['path'])==ready['image']

sources=[R/'src/compute_provider_cuda/collectives_provider.cc',R/'tests/graph_route_cuda/topk_test.cc',R/'docs/user/graph.md']
extra=sources+[R/'docs/developer/current-work.md',R/'docs/developer/performance/decode.md',M/'before/tools/qwen35_text/main.cc']
directory=R/'docs/evidence/performance';stem='qwen-topone-prepared-2026-10-22';packed,stats=pack(S,directory,stem,extra)
manifest=dict(schema='hyle.qwen-topone-prepared.v1',date='2026-10-22',status='Prepared capability/capture implemented and finite checks completed; broad goal incomplete',sources=[ident(x)for x in sources],measured_image=read(S/'qwen-ready-attempt1.json'),compiled_consumer_source_archive=ident(M/'before/tools/qwen35_text/main.cc'),**packed,
 change=['Use immutable configured Program.arg_tiles for prepared/capture capability in the same runtime function used by proposal, prepared operation and submit. Single-row/narrow/K>1 CUB paths and Scan remain managed.',
 'The two native kernels and perInvocation workspace are unchanged from prior native optimization. Only one host Provider object differs across195 measured link inputs;194 others including native/consumer unchanged.',
 'Prepared kernel launch attempts conservatively retain accepted-prefix on failure, without stream synchronization inside capture. Original Queue Completion retirement and Graph capture-abort retain owners. Managed CUB error synchronization remains.'],
 correctness=dict(unit_tests=14,unit_result=ident(S/'tests-run1/run.result.json'),unit_xml=ident(S/'tests-run1/gtest.xml'),math=read(S/'review/topone-model-regression.json'),capture_review=read(S/'review/capture-review.json'),failure_source_review=read(S/'review/provider-failure-review.json'),native_failure_injection=False),
 performance=dict(timing=read(S/'performance/timing/summary.json'),memory=read(S/'performance/memory/summary.json'),independent_review=read(S/'review/final-review.json'),interpretation='Near equal: decode168.0966 ->168.1499 (+0.0317%), total147.1753 ->147.3229 (+0.1003%). Overlapping ranges, no claimed speedup. Versus fixed peer186.5019/156.3233, still -9.8401%/-5.7576%. Prior native optimization window not pooled.',limits='Retained synthetic teacherforced2sessions,3rounds256+32; C1024/N2/R2,1536P+192D,198IDs,99actualB2.3fresh timing and1independent memory process perarm. No natural serving/quality/general support claim; existing BF16/F32 smallweight,conv history,physical-pool/failure-contract differences remain. Ready memory baseline unknown, actual samples ~15.2ms, peaks lower bounds. No new native trace/kernel-count claim.'),
 next=['Real MTP weights now separately loaded and byte-checked; see docs/evidence/correctness/qwen-mtp-weights-2026-10-22.json. MTP target outputs, graph and accepted-state transaction remain.', 'Full three-OS/backend/model/quant architecture scope and image projection incomplete.'],
 provenance='Measured consumer is frozen pre-MTP main0ff952f8; actual default main after loader extension was separately rebuilt and math-regressed, not substituted into this performance window.',previous='docs/evidence/performance/qwen-batch-topone-2026-10-22.json')
save(directory/f'{stem}.json',manifest);save(S/'published.json',dict(manifest=ident(directory/f'{stem}.json'),archives=packed['archives'],**stats))
print('PUBLISHED',stem,stats['archive_verified_entries'],'entries',sum(x['bytes']for x in packed['archives']),'ZIP bytes')

sources=[R/'tools/qwen35_text/main.cc',R/'tools/qwen35_text/prepare.py',R/'tools/qwen35_text/README.md']
directory=R/'docs/evidence/correctness';stem='qwen-mtp-weights-2026-10-22';packed,stats=pack(M,directory,stem,sources)
manifest=dict(schema='hyle.qwen-mtp-weights.v1',date='2026-10-22',status='Real MTP input/weight loading slice completed; MTP inference remains unimplemented',sources=[ident(x)for x in sources],**packed,
 implementation=['prepare.py --mtp explicitly selects335 original text+MTP tensors with distinct signature; default320 manifest preserved.',
 'The same FileResourcePipeline uploads335 groups into335 original device allocations with two8MiB staging slots. Only15 tensors/121656320B added; original tied embedding/head shared. No second loader or inference executor.',
 'Recipe absolute-name lookup and target relative wrapper share one constant cache. Default Model/CLI still text-only, explicitly rejects MTP manifest before upload. No fake MTP inference option.'],
 actual_prepare=dict(result=ident(M/'prepare-run1/run.result.json'),receipt=read(M/'prepared/input.json'),metadata_check=read(M/'metadata-check.json')),
 actual_loader=dict(result=ident(M/'probe-run1/run.result.json'),probe=probe,scope='Actual335 tensor upload and15 complete MTP device byte comparisons against original local shard. Probe load_seconds is one diagnostic observation, not MTP inference/performance benchmark.'),
 ordinary_text_regression=dict(image=read(M/'qwen-ready-attempt1.json'),vectors=read(M/'review/topone-model-regression.json'),scope='Updated default320 consumer rebuilt, R1 and B2 actual runs compare90 raw files byteexact to their same-B baselines; no extra full timing window claimed.'),
 review=read(M/'review/loader-review.json'),
 not_completed=['Real MTP block mathematics/independent numeric reference, shifted prefill catchup and draft KV/frontier.', 'Target all-row hidden/IDs, T2 accepted conv/GDN boundary material outputs, independent carry ownership and full budget.', 'Single original Graph draft-ID device edge to target verification, accepted/rejected state selection and atomic composite publication via original Invocation/Completion.', 'Natural acceptance/rejection, emitted stream/quality, failure/cancellation retirement, matched real MTP peer speed and memory.'],
 research='docs/evidence/research/qwen35-mtp-next-2026-10-22.json',incidents=['Initial preparation of the capture regression checker wrote run_checks.py then stopped because its review directory did not yet exist. Created exact stage directory, generated checker; actual runs and checks all separately completed exit0. No native process restarted or result hidden.'])
save(directory/f'{stem}.json',manifest);save(M/'published.json',dict(manifest=ident(directory/f'{stem}.json'),archives=packed['archives'],**stats))
print('PUBLISHED',stem,stats['archive_verified_entries'],'entries',sum(x['bytes']for x in packed['archives']),'ZIP bytes')
