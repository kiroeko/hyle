"""Incremental host capability/test rebuild; reuse final native TopK1 and SDK closure."""
from pathlib import Path
import argparse,importlib.util,os,sys
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent;R=S.parents[1];D=R/'.scratch/qwen-batch-profile-20261022'
spec=importlib.util.spec_from_file_location('prior',D/'build.py');h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
h.S=S;b,c=h.b,h.c

def same(record):return b.identity(record['path'])==record

def link(mode,attempt):
    base_path=D/('qwen-link2/link-plan.json'if mode=='qwen'else'tests-link3/link-plan.json')
    base=c.read(base_path);inputs=base['inputs']
    tags=['provider']+(['graph-test']if mode=='tests'else[])
    replacements={};records=[]
    old={'provider':D/'compile1/provider/identity.json','graph-test':D/'compile1/graph-test/identity.json'}
    for tag in tags:
        p=S/f'compile{attempt}'/tag/'identity.json';record=c.read(p);records.append(b.identity(p))
        assert all(same(x)for x in(record['source'],record['object'],*record['dependencies']))
        replacements[c.key(c.read(old[tag])['object']['path'])]=record['object']
    assert all(sum(c.key(x['path'])==k for x in inputs)==1 for k in replacements)
    assert all(same(x)for x in inputs)
    inputs=[replacements.get(c.key(x['path']),x)for x in inputs]
    command=[replacements.get(c.key(x),{}).get('path',x)for x in base['command']if not x.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:'))]
    out=S/f'{mode}-link{attempt}';out.mkdir(exist_ok=False);(out/'tmp').mkdir();image=out/f'{mode}.exe'
    command+=['/OUT:'+str(image),'/MAP:'+str(image.with_suffix('.map')),'/IMPLIB:'+str(image.with_suffix('.lib'))]
    c.save(out/'link-plan.json',dict(command=command,inputs=inputs,base=b.identity(base_path),compiled_records=records,SDK_builds=0,native_rebuilds=0))
    env,_=b.environment(command,[x['path']for x in inputs],out);c.execute('link',command,env,out)
    for dll in(D/'qwen-link2').glob('*.dll'):os.link(dll,out/dll.name)
    runtime=c.read(D/'qwen-link2/runtime-environment.json');runtime['PATH']=env['PATH'];runtime['staged_dlls']=[b.identity(x)for x in out.glob('*.dll')];c.save(out/'runtime-environment.json',runtime)
    c.save(S/f'{mode}-ready-attempt{attempt}.json',dict(image=b.identity(image),source=b.identity(R/'tools/qwen35_text/main.cc'),changed_sources=[c.read(S/f'compile{attempt}'/t/'identity.json')['source']for t in tags],link_plan=b.identity(out/'link-plan.json'),runtime_environment=b.identity(out/'runtime-environment.json'),SDK_builds=0,native_rebuilds=0))
    print('READY',mode,flush=True)
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('mode',choices=('provider','graph-test','qwen','tests'));p.add_argument('--attempt',type=int,default=1);p.add_argument('--link',action='store_true');a=p.parse_args()
    if a.link:link(a.mode,a.attempt)
    else:h.compile_owner(a.mode,a.attempt)
