from pathlib import Path
import json,hashlib
R=Path.cwd();D=Path(__file__).resolve().parent
read=lambda p:json.loads(Path(p).read_text(encoding='utf-8-sig'))
def pin(p):return dict(path=str(p.resolve()),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
summary=dict(status='complete_current_2026_10_25_single_and_real_two_turn_baselines',date='2026-10-25',image=read(D/'ready.json'),binding=pin(D/'binding.json'),windows={},total_timing_processes=24,total_independent_memory_processes=8,SDK_builds=0,HTTP=0,GPU_profiles=0,architecture_causal_benefit_claim=False,achieved_optimization_claim=False,historical_samples_pooled=False,failures=[],limits=['3 interleaved new timing processes per arm per workload; descriptive median/min/max, no significance or fixed clock claim.','Each workload has its own4 memory processes; their durations are not throughput. PSAPI/PDH peaks are sampled lower bounds; requested10ms does not imply exact cadence. Ready baseline nulls remain null.','Natural greedy/EOS output and accepted work can differ across engines or modes; no forced identical-token/quality claim.','Default cerr/unitbuf IO remains; continuous session timing includes the preceding step post-endpoint reporting. This is clean canonical CLI with no new clocks/profiler.','Scoped current BF16 application/Graph closure uses retained compatible native math; not blanket full SDK or other quant-mode certification.'])
rows=[];GIB=2**30
for workload in ['single','two-turn']:
 t=read(D/(workload+'-timing')/'summary.json');m=read(D/(workload+'-memory')/'summary.json');runs=read(D/(workload+'-timing')/'runs.json')
 assert t['within_arm_fixed_work_valid']and m['within_arm_fixed_work_valid']and t['processes']==12 and m['processes']==4
 window=dict(timing_summary=pin(D/(workload+'-timing')/'summary.json'),memory_summary=pin(D/(workload+'-memory')/'summary.json'),arms={},comparisons={},within_arm_work=t['within_arm_work'])
 for arm in ['hyle_plain','hyle_mtp','peer_plain','peer_mtp']:
  selected=next(r['observation']for r in runs if r['arm']==arm);mem=m['groups'][arm];metrics=t['groups'][arm];peaks=mem['sampled_peaks'];assert mem['setup_error']is None and mem['thread_error']is None
  observation=dict(actual_generated_tokens=selected['actual_generated_tokens'],generated_ids=selected['generated_ids'],work=selected['work'],metrics=metrics,memory=dict(sampled_peaks=peaks,sample_count=mem['sample_count'],ready_baseline=mem['ready_baseline'],actual_sample_gaps_ms={k:v for k,v in mem['actual_sample_gaps_ms'].items()if k!='samples'},sample_cost_ms={k:v for k,v in mem['sample_cost_ms'].items()if k!='samples'},null_sample_counts=mem['null_sample_counts'],unavailable_reasons=mem['unavailable_reasons']))
  window['arms'][arm]=observation
  rows.append(dict(workload=workload,arm=arm,prefill=metrics['prefill_tokens_per_second']['median'],decode=metrics['full_decode_tokens_per_second']['median'],combined=metrics['session_output_tokens_per_second']['median'],gpu_dedicated_GiB=peaks['sampled_peak_gpu_dedicated_bytes']/GIB,gpu_shared_GiB=peaks['sampled_peak_gpu_shared_bytes']/GIB,working_set_GiB=peaks['sampled_max_working_set_bytes']/GIB,private_commit_GiB=peaks['sampled_max_private_commit_bytes']/GIB))
 for mode in ['plain','mtp']:
  h=t['groups']['hyle_'+mode];p=t['groups']['peer_'+mode]
  window['comparisons'][mode]={k:dict(hyle=h[k]['median'],peer=p[k]['median'],hyle_relative_percent=(h[k]['median']/p[k]['median']-1)*100)for k in ['prefill_tokens_per_second','full_decode_tokens_per_second','session_output_tokens_per_second']}
 window['within_engine_MTP']={engine:{k:(t['groups'][engine+'_mtp'][k]['median']/t['groups'][engine+'_plain'][k]['median']-1)*100 for k in ['full_decode_tokens_per_second','session_output_tokens_per_second']}for engine in ['hyle','peer']}
 summary['windows'][workload]=window
(D/'summary.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(rows=rows,comparisons={k:v['comparisons']for k,v in summary['windows'].items()},actual_work={w:{a:d['work']for a,d in v['arms'].items()}for w,v in summary['windows'].items()},within_engine_MTP={w:v['within_engine_MTP']for w,v in summary['windows'].items()}),indent=2))
