from pathlib import Path
import importlib.util,json,sys,os
sys.dont_write_bytecode=True
D=Path(__file__).resolve().parent;R=D.parents[2];C=D.parent/'current-cuda'
spec=importlib.util.spec_from_file_location('retained',R/'.scratch/mtp-extraction-regression-20261024/check.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
def args(p):
 x=b.read(p);return x.get('command',x)if isinstance(x,dict)else x
source=R/'engine/models/qwen35/main.cc';assert b.pin(source)['sha256']=='9b73fe9afe325d139072a94632e26d739e2b3cb48b411320c0c5bed320e9b9e9'
probe=D/'probe.cc';probe.write_text('#include "engine/models/qwen35/main.cc"\nint main(int argc,char**argv){return qwen35::run(argc,argv);}\n',encoding='utf-8')
original=args(C/'app2/command.json');flags=[];skip=False
for w in original[1:]:
 if skip:skip=False;continue
 if w=='/sourceDependencies':skip=True;continue
 if w.lower().startswith(('/fo','/fd'))or w.lower().endswith(('.cc','.cpp')):continue
 flags.append(w)
cmd=[original[0],*flags,str(probe),'/sourceDependencies',str(D/'compile/dependencies.json'),'/Fo'+str(D/'compile/unit.obj')]
assert not any('main2.cc'in w or'probe2.cc'in w for w in cmd)
b.execute(cmd,D/'compile',b.environment(cmd[0]),180)
deps=[Path(p).resolve()for p in b.read(D/'compile/dependencies.json')['Data']['Includes']]
assert source in deps and not any(p.is_relative_to(C)for p in deps)
b.save(D/'compile/source-pins.json',dict(source=b.pin(probe),canonical_main=b.pin(source),actual_dependencies=[b.pin(p)for p in deps if p.is_relative_to(R)],instrumentation='No private timer/observer source, no extra clock/report/capture hooks; exact canonical main include and direct qwen35::run.'))
reportpin=b.read(C/'report/source-pins.json')['source'];assert b.pin(R/'engine/reporting/execution_report.cc')==reportpin
old=str(C/'app2/unit.obj');link=args(C/'link/command.json');assert link.count(old)==1
link=[str(D/'compile/unit.obj')if w==old else w for w in link if not w.upper().startswith(('/OUT:','/PDB:','/MAP:','/IMPLIB:'))];link+=['/OUT:'+str(D/'link/hyle.exe')]
b.execute(link,D/'link',b.environment(link[0]),120)
native=C/'link/hyle_ggml_cpu_gdn_scale_v3.dll';os.link(native,D/'link'/native.name)
runtime=dict(PATH=str(D/'link')+';'+b.read(R/'.scratch/qwen35-unsloth-mtp-20261024/engine-check/ready-cuda.json')['PATH'],native=b.pin(D/'link'/native.name))
b.save(D/'runtime.json',runtime)
b.save(D/'ready.json',dict(image=b.pin(D/'link/hyle.exe'),source=b.pin(probe),compiled_identity=b.pin(D/'compile/source-pins.json'),runtime_environment=b.pin(D/'runtime.json'),canonical_main=b.pin(source),reused_reporting_object=b.pin(C/'report/unit.obj'),reused_current_BF16_Graph=b.read(C/'ready.json')['replacements'],instrumented=False,SDK_builds=0,HTTP=0,qualification='Current canonical BF16 engine main/report + refreshed4 actual Graph/batch/CUDA-region TUs; unchanged compatible native BF16 math/templates retained, not blanket SDK/new-quant-mode current certification.'))
print(json.dumps(b.read(D/'ready.json')['image']),flush=True)
