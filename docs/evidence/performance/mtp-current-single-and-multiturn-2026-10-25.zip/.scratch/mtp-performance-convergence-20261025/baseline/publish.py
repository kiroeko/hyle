from pathlib import Path
import hashlib,json,zipfile,shutil
R=Path.cwd();D=Path(__file__).resolve().parent;C=D.parent/'current-cuda';P=R/'docs/evidence/performance';name='mtp-current-single-and-multiturn-2026-10-25'
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def pin(p):return dict(path=p.relative_to(R).as_posix(),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
j=read(D/'summary.json');assert j['total_timing_processes']==24 and j['total_independent_memory_processes']==8
executions=[];memory_limit=dict(max_sample_gap_ms=0,max_sample_cost_ms=0,ready_unknown=0)
for work in ['single','two-turn']:
 for mode in ['timing','memory']:
  out=D/(work+'-'+mode);summary=read(out/'summary.json');assert summary['within_arm_fixed_work_valid'];plan=read(out/'inputs.json')
  for entry in plan['commands']:
   folder=Path(entry['folder']);terminal=read(folder/'result.json');assert terminal['exit']==0 and not terminal.get('timed_out',False)
   executions.append(dict(workload=work,mode=mode,arm=entry['arm'],ordinal=entry['ordinal'],process=pin(folder/'result.json'),observation=pin(folder/'observation.json'),stdout=pin(folder/'stdout.log'),stderr=pin(folder/'stderr.log'),raw_terminal=terminal))
  if mode=='memory':
   for arm,m in summary['groups'].items():
    assert m['setup_error']is None and m['thread_error']is None
    memory_limit['max_sample_gap_ms']=max(memory_limit['max_sample_gap_ms'],m['actual_sample_gaps_ms']['max']);memory_limit['max_sample_cost_ms']=max(memory_limit['max_sample_cost_ms'],m['sample_cost_ms']['max']);memory_limit['ready_unknown']+=int(m['ready_baseline']['unknown'])
assert len(executions)==32
sources=[]
for rel in ['engine/models/qwen35/main.cc',*(str(p.relative_to(R)).replace('\\','/')for p in(R/'engine/models/qwen35').glob('*.h')),*(str(p.relative_to(R)).replace('\\','/')for p in(R/'engine/inference').glob('*.h')),'engine/reporting/execution_report.cc','engine/reporting/execution_report.h','src/graph/executable.cc','src/graph_batch/batch.cc','src/graph_batch/paged_append.cc','src/graph_provider_ggml_cuda/ggml_cuda_region.cc']:
 p=R/rel;target=D/'recorded-source'/rel;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,target);sources.append(dict(canonical=pin(p),recorded=pin(target)))
for path in [D/'compile/source-pins.json',*(C/f'product-{i}/source-pins.json'for i in range(4))]:
 record=read(path)
 for row in record.get('actual_dependencies',[]):
  p=Path(row['path']);assert p.stat().st_size==row['bytes']and hashlib.sha256(p.read_bytes()).hexdigest()==row['sha256']
public=dict(schema='hyle.performance.current_single_and_multiturn_baseline.v1',**j,executions=executions,memory_observer_limits=memory_limit,source_pins=sources,preparation_failures=read(C/'summary.json')['first_failures'],scope='New contemporaneous pre-optimization baseline only. No claim of architecture causal benefit or achieved performance optimization. Published Oct24 samples remain independent.',input_receipts=dict(V2_manifest=pin(R/'.scratch/qwen35-unsloth-mtp-20261024/geometry-v2-check/original/weights.tsv'),prompt=pin(R/'.scratch/qwen35-unsloth-mtp-20261024/geometry-v2-check/original/prompt.ids'),schedule=pin(R/'.scratch/qwen-mtp-final-window-20261024/natural-inputs/performance64.txt'),exact_original_role_mapping=pin(C/'input-adaptation.json')))
output=P/(name+'.json');archive=P/(name+'.zip');assert not output.exists()and not archive.exists()
output.write_text(json.dumps(public,indent=2)+'\n',encoding='utf-8')
files=[p for p in D.rglob('*')if p.is_file()and p.suffix.lower()in{'.json','.log','.py','.cc','.h','.txt'}]
for i in range(4):files.extend(p for p in(C/f'product-{i}').iterdir()if p.is_file()and p.suffix.lower()in{'.json','.log'})
files.extend(C/p for p in['audit.py','closure-audit.json','source2-pins.json','source2.patch','input-adaptation.json','app/command.json','app/process.json','app/stdout.log','app/stderr.log','plain-entry/command.json','plain-entry/process.json','plain-entry/stderr.log'])
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9)as z:
 for p in sorted(set(files)):z.write(p,p.relative_to(R).as_posix())
with zipfile.ZipFile(archive)as z:assert all(Path(n).suffix.lower()not in{'.obj','.exe','.lib','.dll','.bin','.gguf','.safetensors','.pdb'}for n in z.namelist())
pins=dict(evidence=pin(output),archive=pin(archive),files=len(set(files)),runs=32,models_rerun=0,SDK_builds=0,HTTP=0)
(D/'publication.json').write_text(json.dumps(pins,indent=2)+'\n',encoding='utf-8');print(json.dumps(pins))
