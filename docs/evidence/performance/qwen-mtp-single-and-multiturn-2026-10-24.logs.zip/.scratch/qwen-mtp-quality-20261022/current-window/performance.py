"""Current AR Hyle off/on and current AR peer off/on; only `run` starts models.

Reuse V's exact workload/endpoints, result parser and PSAPI/PDH sampler. All new
outputs belong to this directory. No old Hyle image or cross-arm ID assumption.
"""
from pathlib import Path
import argparse
import importlib.util
import sys

sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
ROOT = S.parents[2]
V = ROOT / '.scratch/qwen-mtp-window-20261022'
AR = S.parent
spec = importlib.util.spec_from_file_location('ar_current_retained_V_window', V / 'window.py')
base = importlib.util.module_from_spec(spec)
spec.loader.exec_module(base)
ARMS = base.ARMS
EXPECTED_READY = {arm: S / ('hyle-ready.json' if arm.startswith('hyle')
                           else 'peer-ready.json') for arm in ARMS}
original_plan, original_parse, original_analyze = base.plan, base.parse_result, base.analyze


def owned_output(path):
    output = Path(path).resolve()
    if output == S or not output.is_relative_to(S):
        raise ValueError('new output must be a child of AR/current-window')
    return output


def decision_work(value):
    if isinstance(value, dict):
        return {key: decision_work(item) for key, item in value.items()
                if key != 'seconds' and not key.endswith('_seconds')}
    if isinstance(value, list):
        return [decision_work(item) for item in value]
    return value


def plan(config_path, mode, output):
    output = owned_output(output)
    config = base.read(config_path)
    if set(config['arms']) != set(ARMS):
        raise ValueError('exactly four retained off/on arms are required')
    for arm in ARMS:
        entry = config['arms'][arm]
        if Path(entry['ready']).resolve() != EXPECTED_READY[arm].resolve():
            raise ValueError('current window forbids a different/old ready image: ' + arm)
        ready = base.read(entry['ready'])
        original_ready = AR / ('hyle-link1' if arm.startswith('hyle') else 'peer-link1') / 'ready.json'
        if ready['image'] != base.read(original_ready)['image']:
            raise ValueError('wrapper differs from current AR ready image: ' + arm)
        expected_image = original_ready.parent / ('qwen.exe' if arm.startswith('hyle') else 'peer.exe')
        if Path(ready['image']['path']).resolve() != expected_image.resolve():
            raise ValueError('current window requires the AR link image: ' + arm)
        for key in ('source', 'runtime_environment'):
            if base.identity(ready[key]['path']) != ready[key]:
                raise ValueError('current AR wrapper identity changed: ' + key)
        if arm.startswith('hyle'):
            command = entry['command']
            for flag, expected in (('--max-sessions','1'),('--active-sequences','1'),
                                   ('--prefix-cache','off'),('--progress','direct'),('--replay','auto')):
                if command.count(flag) != 1 or command[command.index(flag)+1] != expected:
                    raise ValueError('Hyle window option differs: ' + flag)
        elif entry['model'] != base.read(V/'arms.json')['arms'][arm]['model']:
            raise ValueError('peer original GGUF320/335 mapping changed')
    result = original_plan(config_path, mode, output)
    result.update(script=base.identity(Path(__file__)), retained_V_script=base.identity(V/'window.py'),
        ready_mapping={arm:str(path) for arm,path in EXPECTED_READY.items()},
        current_Hyle_score_policy='bf16_inputs_f32_output',
        native_peer_policy='Current AR host consumer with cached native libraries and original GGUF320/335. Other BF16 small-weight/state arithmetic and reduction differences remain.',
        actual_IDs_or_work_equal_between_modes_assumed=False,
        actual_IDs_or_work_equal_between_engines_assumed=False,
        validation='Require IDs, exported work and non-time round decisions stable within each arm. Across arms report actual differences descriptively; no quality threshold.',
        former_windows_pooled=False)
    return result


def parse_result(folder, arm, input_plan):
    result = original_parse(folder, arm, input_plan)
    if arm.startswith('hyle'):
        raw = result['raw']
        if raw.get('score_dtype') != 'F32' or raw.get('score_policy') != 'bf16_inputs_f32_output':
            raise ValueError('current Hyle F32-score policy not actually exported')
    return result


def within_arm_work(runs):
    result = {}
    for arm in ARMS:
        rows = [r['observation'] for r in runs if r['arm']==arm]
        if not rows:
            result[arm] = dict(processes=0, stable=False)
            continue
        same_IDs = all(row['generated_ids']==rows[0]['generated_ids'] for row in rows)
        same_work = all(row['work']==rows[0]['work'] for row in rows)
        reference = decision_work(rows[0]['raw'].get('rounds'))
        same_decisions = all(decision_work(row['raw'].get('rounds'))==reference for row in rows)
        result[arm] = dict(processes=len(rows), identical_IDs=same_IDs,
            identical_exported_work=same_work, identical_non_time_round_decisions=same_decisions,
            actual_output_lengths=[len(row['generated_ids']) for row in rows],
            stopped_on_EOS=[row['stopped_on_EOS'] for row in rows],
            stable=same_IDs and same_work and same_decisions)
    return result


def analyze(output):
    output = owned_output(output)
    result = original_analyze(output)
    runs = base.read(output/'runs.json')
    expected = 3 if result['mode']=='timing' else 1
    consistency = within_arm_work(runs)
    stable = len(runs)==4*expected and all(x['processes']==expected and x['stable'] for x in consistency.values())
    result.update(status='complete_stable_within_arm_work' if stable else 'complete_with_within_arm_variability',
        within_arm_work=consistency, within_arm_fixed_work_valid=stable,
        current_Hyle_score_policy='bf16_inputs_f32_output',
        same_token_cross_arm_speed_claim=False, all_math_equal_assumed=False,
        quality_pass=False, quality_threshold=None, former_windows_pooled=False)
    result['limits'] += [
        'Both Hyle modes use the current AR image/F32-score policy; both peer modes use the current AR host image with cached native libraries and GGUF320/335. BF16 weights/activation/state and arithmetic contracts still differ.',
        'Only within-arm output/work/decisions are required to repeat. Natural output differences across modes/engines are reported, not converted into same-token speed or quality claims.',
        'Current Hyle plain/MTP is a new four-arm window. Never reuse a deleted old Hyle-off image, pool historical V/W/AC/AD/AF timing, or treat independent memory-process timing as throughput.'
    ]
    base.save(output/'summary.json',result)
    return result


base.plan, base.parse_result, base.analyze = plan, parse_result, analyze


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action',choices=('plan','run','analyze'))
    parser.add_argument('--config',type=Path,default=S/'arms.json')
    parser.add_argument('--mode',choices=('all','timing','memory'),default='all')
    parser.add_argument('--output',type=Path)
    args=parser.parse_args()
    if args.mode=='all' and args.output is not None:
        raise ValueError('--mode all uses the fixed timing and memory children')
    modes=('timing','memory') if args.mode=='all' else (args.mode,)
    for mode in modes:
        output=owned_output(args.output or S/mode)
        if args.action=='plan':
            result=plan(args.config,mode,output)
            base.save(S/(mode+'-plan.json'),result)
            print('PLAN',mode,len(result['commands']),output,flush=True)
        else:
            result=base.run(args.config,mode,output) if args.action=='run' else analyze(output)
            print('COMPLETE',mode,result['processes'],output/'summary.json',flush=True)


if __name__=='__main__':
    main()
