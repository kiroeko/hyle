"""Root-run four-arm natural-generation window; tokenizer/analysis are CPU-host only.

prepare-inputs/plan/analyze/self-check never start a model. Only run does so.
Timing processes are unmonitored; independent memory processes reuse the retained
PSAPI/PDH MemoryProbe. No CUDA, NVML, model library or Torch import is performed.
"""
from __future__ import annotations

import argparse
import ctypes
import hashlib
import importlib.metadata
import importlib.util
import json
import math
import os
from pathlib import Path
import re
import statistics
import sys
import time

sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
ROOT = S.parents[1]
D4 = ROOT / ".scratch/architecture-refactor-2026-10-18/d4-windows-preparation-2026-10-21/first-decode-startup-2026-10-21"
RUNNER = D4 / "multiturn/multiturn_run.py"
OBSERVER = ROOT / ".scratch/shared-execution-20261021/observer.py"
ARMS = ("hyle_plain", "hyle_mtp", "peer_plain", "peer_mtp")
EOS = (248044, 248046)
PROMPT = '''Write a complete Python module implementing stable_merge_sort(items, *, key=None, reverse=False).
Use a bottom-up iterative merge sort, return a new list, never mutate the input, and preserve the original order of equal-key items even with reverse=True.
Support an arbitrary iterable and an optional key function. Evaluate each key exactly once per element. Do not use sorted(), list.sort(), recursion, or external packages.
Include a clear docstring, a small private merge helper, and a unittest.TestCase covering empty input, singleton input, repeated keys, reverse stability, and a generator input.
Return only Python code with no Markdown fences or explanation. Write the complete implementation and tests, not pseudocode.'''


def unique(pairs):
    value = {}
    for key, item in pairs:
        if key in value:
            raise ValueError("duplicate JSON key: " + key)
        value[key] = item
    return value


def read(path):
    return json.loads(Path(path).read_text(encoding="utf-8-sig"), object_pairs_hook=unique)


def save(path, value):
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    Path(path).write_text(json.dumps(value, indent=2, ensure_ascii=False, allow_nan=False) + "\n", encoding="utf-8")


def identity(path):
    path = Path(path).resolve()
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        while raw := stream.read(8 << 20):
            digest.update(raw)
    return dict(path=str(path), bytes=path.stat().st_size, sha256=digest.hexdigest())


def write_once(path, raw):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        if path.read_bytes() != raw:
            raise ValueError("refuse to replace different existing input: " + str(path))
    else:
        path.write_bytes(raw)


def hardlink(source, destination):
    source, destination = Path(source).resolve(), Path(destination).resolve()
    destination.parent.mkdir(parents=True, exist_ok=True)
    if destination.exists():
        if not os.path.samefile(source, destination):
            raise ValueError("existing input is not this exact hardlink: " + str(destination))
    else:
        os.link(source, destination)
    return dict(source=identity(source), destination=identity(destination), same_file=os.path.samefile(source, destination))


def prepare_inputs(model, text_manifest, mtp_manifest):
    # Only tokenizer metadata and the small existing manifests are read/hashed.
    # The multi-GiB original weight file is neither copied nor rehashed.
    model = model.resolve()
    os.environ.update(HF_HUB_OFFLINE="1", TRANSFORMERS_OFFLINE="1", HF_HUB_DISABLE_TELEMETRY="1",
                      TOKENIZERS_PARALLELISM="false", USE_TORCH="0", USE_TF="0", USE_FLAX="0")
    from transformers import AutoTokenizer
    tokenizer = AutoTokenizer.from_pretrained(model, local_files_only=True, trust_remote_code=False)
    messages = [dict(role="user", content=PROMPT)]
    kwargs = dict(add_generation_prompt=True, enable_thinking=False)
    rendered = tokenizer.apply_chat_template(messages, tokenize=False, **kwargs)
    encoded = tokenizer.apply_chat_template(messages, tokenize=True, return_dict=True, **kwargs)
    ids = encoded["input_ids"]
    if not ids or not all(isinstance(x, int) and 0 <= x < 248320 for x in ids):
        raise ValueError("unexpected local tokenizer output")
    if len(ids) + 63 > 1024:
        raise ValueError("prompt plus64 output-input budget does not fit C1024")
    inputs = S / "inputs"
    write_once(inputs / "prompt.txt", (PROMPT + "\n").encode("utf-8"))
    write_once(inputs / "rendered-chat.txt", rendered.encode("utf-8"))
    write_once(inputs / "prompt.ids", (" ".join(map(str, ids)) + "\n").encode("ascii"))
    manifests = {}
    for kind, path, signature, count in (("text", text_manifest, "HYLE_QWEN35_TEXT_V1", 320),
                                         ("mtp", mtp_manifest, "HYLE_QWEN35_TEXT_MTP_V1", 335)):
        lines = path.read_text(encoding="utf-8-sig").splitlines()
        if lines[0] != signature or len(lines) != count + 3:
            raise ValueError("original manifest signature/count differs: " + str(path))
        if lines[2] != "4068044d8571635d8a86f1e96a43dad104efc7089169065f735601e350008155":
            raise ValueError("original model source ID differs")
        manifests[kind] = dict(weights=hardlink(path, inputs / kind / "weights.tsv"),
                               prompt=hardlink(inputs / "prompt.ids", inputs / kind / "prompt.ids"),
                               tensor_count=count, source_id=lines[2], checkpoint=lines[1])
    metadata = [identity(model / name) for name in ("config.json", "tokenizer.json", "tokenizer_config.json",
                                                    "chat_template.jinja", "vocab.json", "merges.txt")]
    template = tokenizer.get_chat_template()
    report = dict(kind="offline_tokenizer_only_natural_coding_generation_input", source_id=manifests["text"]["source_id"],
                  original_model=str(model), prompt=PROMPT, prompt_ids=ids, prompt_tokens=len(ids),
                  requested_output_tokens=64, output_budget_includes_prefill_first_id=True,
                  capacity=1024, resident_sessions=1, active_sequences=1, prefix_cache="off",
                  EOS=list(EOS), ignore_EOS=False, forced_decode_tape=False, trace=False, probe=False,
                  intended_task="Complete stable merge sort module and unit tests; expected longer than64 tokens, not guaranteed. EOS is honored.",
                  tokenizer=dict(class_name=type(tokenizer).__name__, local_files_only=True, trust_remote_code=False,
                                 chat_template_kwargs=kwargs, template_sha256=hashlib.sha256(template.encode("utf-8")).hexdigest(),
                                 versions={name: importlib.metadata.version(name) for name in ("transformers", "tokenizers")},
                                 metadata=metadata),
                  inputs=dict(prompt=identity(inputs / "prompt.ids"), text=identity(inputs / "prompt.txt"),
                              rendered_chat=identity(inputs / "rendered-chat.txt"), manifests=manifests),
                  model_computation=False, GPU=False, full_checkpoint_copied=False, full_checkpoint_rehashed=False)
    path = inputs / "input.json"
    raw = (json.dumps(report, indent=2, ensure_ascii=False) + "\n").encode("utf-8")
    write_once(path, raw)
    return report


def load_helpers():
    def module(name, path):
        spec = importlib.util.spec_from_file_location(name, path)
        result = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(result)
        return result
    runner = module("window_retained_runner", RUNNER)
    observer = module("window_retained_observer", OBSERVER)
    observer.install(runner)
    old_marker = runner.marker

    def marker(line):
        match = re.search(r"\bmemory_phase=([A-Za-z0-9_-]+)\b", line)
        if match:
            name = match[1]
            # The generation producer's real ready checkpoint is explicit.
            if name in ("ready", "ready_begin", "ready_before_prefill"):
                return "ready_before_prefill"
            if name in ("prefill_begin", "prefill_end", "decode_begin", "decode_end"):
                return "window_" + name
        return old_marker(line)

    old_summary = runner.memory_summary

    def memory_summary(samples, record):
        # Consumers may use one shared first-output endpoint instead of issuing
        # a duplicate decode_begin marker. Preserve originals and mark derivation.
        names = [row["name"] for row in record["markers"]]
        adjusted = dict(record, markers=list(record["markers"]))
        derived = "window_decode_begin" not in names and names.count("window_prefill_end") == 1
        if derived:
            first = next(row for row in record["markers"] if row["name"] == "window_prefill_end")
            adjusted["markers"].append(dict(first, name="window_decode_begin", derived_from="window_prefill_end"))
        result = old_summary(samples, adjusted)
        result.update(requested_interval_seconds=0.01, decode_begin_derived_from_prefill_end=derived,
                      counter_source="Windows PSAPI and PDH GPU Process Memory (WDDM); not direct DXGI allocator enumeration",
                      timer=timer_info())
        return result

    runner.marker, runner.memory_summary = marker, memory_summary
    return runner


def timer_info():
    clock = time.get_clock_info("perf_counter")
    frequency = None
    if os.name == "nt":
        counter = ctypes.c_longlong()
        if ctypes.windll.kernel32.QueryPerformanceFrequency(ctypes.byref(counter)):
            frequency = counter.value
    return dict(parent_clock="time.perf_counter_ns", implementation=clock.implementation,
                advertised_resolution_seconds=clock.resolution, monotonic=clock.monotonic,
                QueryPerformanceFrequency_Hz=frequency,
                endpoint_scope="Consumer high-resolution host endpoints determine TPS; parent QPC brackets process/received stderr only.")


def stats(values):
    return dict(count=len(values), median=statistics.median(values) if values else None,
                min=min(values) if values else None, max=max(values) if values else None, samples=values)


def plan(config_path, mode, output):
    config = read(config_path)
    if set(config["arms"]) != set(ARMS):
        raise ValueError("config needs exactly hyle_plain/hyle_mtp/peer_plain/peer_mtp")
    inputs = read(S / "inputs/input.json")
    if identity(S / "inputs/prompt.ids") != inputs["inputs"]["prompt"]:
        raise ValueError("frozen prompt changed")
    order = list(ARMS) if mode == "memory" else [ARMS[(i + round_) % 4] for round_ in range(3) for i in range(4)]
    commands = []
    for ordinal, arm in enumerate(order, 1):
        entry = config["arms"][arm]
        ready = read(entry["ready"])
        if identity(ready["image"]["path"]) != ready["image"]:
            raise ValueError("exact ready image differs: " + arm)
        folder = output / f"{ordinal:02}-{arm}"
        variables = dict(image=ready["image"]["path"], inputs_text=str(S / "inputs/text"),
                         inputs_mtp=str(S / "inputs/mtp"), inputs=str(S / "inputs"),
                         prompt_ids=str(S / "inputs/prompt.ids"), peer_model=entry.get("model", config.get("peer_model", "")),
                         result=str(folder / "consumer-result.json"), steps="64", capacity="1024")
        command = [piece.format_map(variables) for piece in entry["command"]]
        if command[0] != ready["image"]["path"]:
            raise ValueError("command must use exact ready image")
        for flag, expected in (("--capacity", "1024"), ("--steps", "64"),
                               ("--mtp", "on" if arm.endswith("_mtp") else "off")):
            if command.count(flag) != 1 or command[command.index(flag) + 1] != expected:
                raise ValueError("command does not lock shared window option: " + flag)
        if arm.startswith("hyle"):
            expected_inputs = variables["inputs_mtp" if arm.endswith("_mtp") else "inputs_text"]
            if command.count("--inputs") != 1 or command[command.index("--inputs") + 1] != expected_inputs:
                raise ValueError("Hyle input manifest does not match text320/MTP335 selection")
        forbidden = ("--trace", "--schedule", "--session-schedules", "--decode-ids", "--ignore-eos", "--layer0-probe")
        if any(flag in command for flag in forbidden):
            raise ValueError("this window requires natural generation without trace/forced IDs")
        commands.append(dict(ordinal=ordinal, arm=arm, folder=str(folder), command=command,
                             ready=identity(entry["ready"]), image=ready["image"],
                             environment=ready["runtime_environment"]))
    return dict(mode=mode, commands=commands, arm_order=order, configuration=identity(config_path),
                input=identity(S / "inputs/input.json"), prompt=inputs["inputs"]["prompt"],
                prompt_tokens=inputs["prompt_tokens"], requested_output_tokens=64, capacity=1024, N=1, R=1,
                timing_processes=12 if mode == "timing" else 0, memory_processes=4 if mode == "memory" else 0,
                independent_memory_processes=True, memory_interval_seconds=0.01, timer=timer_info(),
                profiler=False, GPU_concurrency=False, warmup=False, forced_acceptance=False,
                generated_IDs_assumed_equal=False, script=identity(Path(__file__)),
                helpers=[identity(RUNNER), identity(OBSERVER)],
                contract="Same original BF16 model family and tokenizer prompt, natural greedy at most64 returned IDs, respect EOS, C1024/N1/R1, prefixoff. Root validates actual flags in each command against the frozen consumer CLI.")


def required(raw, key, aliases=()):
    for name in (key, *aliases):
        if name in raw:
            value = raw[name]
            if not isinstance(value, (int, float)) or not math.isfinite(value) or value < 0:
                raise ValueError("invalid complete endpoint: " + name)
            return float(value)
    raise ValueError("missing complete native host endpoint: " + key)


def parse_result(folder, arm, input_plan):
    result_file = folder / "consumer-result.json"
    if result_file.exists():
        raw = read(result_file)
    else:
        lines = (folder / "stdout.log").read_text(encoding="utf-8").splitlines()
        raw = json.loads(next(line for line in reversed(lines) if line.startswith("{")), object_pairs_hook=unique)
    ids = raw.get("generated_ids", raw.get("predicted_ids"))
    if not ids or not all(isinstance(x, int) and 0 <= x < 248320 for x in ids) or len(ids) > 64:
        raise ValueError("invalid actual natural output IDs")
    if len(ids) < 64 and ids[-1] not in EOS:
        raise ValueError("short output did not stop at actual EOS; do not silently compare truncated work")
    if any(x in EOS for x in ids[:-1]):
        raise ValueError("consumer continued after EOS")
    p = input_plan["prompt_tokens"]
    timing = dict(raw)
    endpoint_sources = {}
    if "weights_load_seconds" not in timing and "model_load_seconds" not in timing:
        stderr = (folder / "stderr.log").read_text(encoding="utf-8", errors="replace")
        weights = re.search(r"^weights_load_seconds=([^\s]+)", stderr, re.MULTILINE)
        if weights:
            timing["weights_load_seconds"] = float(weights[1])
            endpoint_sources["weights_load_seconds"] = "original weights_load_seconds stderr field"
    if "first_token_elapsed_seconds" not in timing and "startup_to_first_token_seconds" not in timing:
        # Peer defines decode_begin=prefill_end and shares endpoint/startup.
        # Subtract exact elapsed scalars, never parent marker arrival timestamps.
        timing["first_token_elapsed_seconds"] = required(raw, "startup_to_endpoint_seconds") - required(raw, "decode_seconds")
        endpoint_sources["first_token_elapsed_seconds"] = "peer exact shared endpoints: startup_to_endpoint_seconds minus decode_seconds"
        points = [row for row in raw.get("phase_points", []) if row.get("name") == "generation_prefill_end"]
        if len(points) == 1 and not math.isclose(points[0]["elapsed_seconds"], timing["first_token_elapsed_seconds"], abs_tol=2e-9):
            raise ValueError("peer explicit prefill-end timestamp differs from shared-endpoint TTFT")
    pref = required(raw, "prefill_seconds")
    dec = required(raw, "decode_seconds")
    session = required(raw, "session_seconds")
    startup = required(raw, "startup_to_endpoint_seconds", ("startup_total_seconds",))
    ready = required(raw, "startup_to_ready_seconds", ("ready_seconds",))
    load = required(timing, "weights_load_seconds", ("model_load_seconds",))
    ttft = required(timing, "first_token_elapsed_seconds", ("startup_to_first_token_seconds",))
    if min(pref, session, startup) <= 0 or (len(ids) > 1 and dec <= 0):
        raise ValueError("nonpositive complete segment duration")
    if not math.isclose(pref + dec, session, rel_tol=1e-5, abs_tol=2e-6):
        raise ValueError("prefill+decode must partition the same complete session endpoints")
    if not (load <= ready <= ttft <= startup + 2e-6):
        raise ValueError("cold load/ready/TTFT/startup endpoints out of order")
    for key in ("requested_context", "capacity", "context_capacity"):
        if key in raw and raw[key] != 1024:
            raise ValueError("actual requested context differs")
    if "prompt_ids" in raw and raw["prompt_ids"] != read(S / "inputs/input.json")["prompt_ids"]:
        raise ValueError("actual consumer prompt differs")
    if "generated_decode_tokens" in raw and raw["generated_decode_tokens"] != len(ids) - 1:
        raise ValueError("generated decode ledger differs")
    if "generated_tokens" in raw and raw["generated_tokens"] != len(ids):
        raise ValueError("total generated output ledger differs")
    if "requested_steps" in raw and raw["requested_steps"] != 64:
        raise ValueError("actual output quota differs")
    if "processed_tokens" in raw and raw["processed_tokens"] != p + len(ids) - 1:
        raise ValueError("committed target-input count differs from actual outputs")
    if "committed_target_rows" in raw and raw["committed_target_rows"] != p + len(ids) - 1:
        raise ValueError("committed target rows differ")
    metrics = dict(prefill_tokens_per_second=p / pref,
                   full_decode_tokens_per_second=(len(ids) - 1) / dec if dec else None,
                   session_output_tokens_per_second=len(ids) / session,
                   session_processed_tokens_per_second=(p + len(ids) - 1) / session,
                   prefill_seconds=pref, decode_seconds=dec, session_seconds=session,
                   weights_load_seconds=load, startup_to_ready_seconds=ready,
                   first_token_elapsed_seconds=ttft, startup_to_endpoint_seconds=startup,
                   cold_output_tokens_per_second=len(ids) / startup)
    work_keys = ("actual_graph_calls", "actual_graph_tokens", "actual_target_rows", "actual_draft_rows",
                 "target_compute_calls", "draft_compute_calls", "committed_target_rows", "verified_target_rows", "committed_target_decode_rows",
                 "target_decode_calls", "draft_decode_calls", "draft_rows", "draft_decode_rows", "draft_rounds", "agreements",
                 "accepted_drafts", "proposals", "generated_decode_tokens", "prefill_target_rows", "prefill_draft_rows",
                 "visible_tokens", "draft_frontier", "draft_lag", "target_cache_backing_bytes", "draft_cache_backing_bytes",
                 "cache_live_requested_bytes", "cache_peak_requested_bytes", "shared_model_objects", "native_contexts")
    return dict(raw=raw, metrics=metrics, endpoint_sources=endpoint_sources,
                generated_ids=ids, actual_generated_tokens=len(ids),
                prompt_tokens=p, stopped_on_EOS=ids[-1] in EOS,
                work={key:raw.get(key) for key in work_keys},
                work_scope="Actual exported work; absent counters remain null. MTP discarded verify/draft work is not counted as emitted outputs.")


def differences(left, right):
    common = min(len(left), len(right))
    mismatch = [i for i in range(common) if left[i] != right[i]]
    return dict(left_tokens=len(left), right_tokens=len(right), equal=left == right,
                first_divergence=mismatch[0] if mismatch else (common if len(left) != len(right) else None),
                overlapping_mismatches=[dict(index=i,left=left[i],right=right[i]) for i in mismatch],
                left_extra=left[common:],right_extra=right[common:])


def analyze(output):
    config = read(output / "inputs.json")
    runs = []
    for entry in config["commands"]:
        folder = Path(entry["folder"])
        terminal = read(folder / "result.json")
        if terminal["exit"] or not (folder / "stdout.log").exists():
            raise ValueError("nonzero/incomplete raw process: " + str(folder))
        observation = parse_result(folder, entry["arm"], config)
        save(folder / "observation.json", observation)
        runs.append(dict(arm=entry["arm"], folder=str(folder), process=terminal, observation=observation))
    groups = {}
    within = {}
    for arm in ARMS:
        selected = [r for r in runs if r["arm"] == arm]
        values = [r["observation"]["generated_ids"] for r in selected]
        within[arm] = dict(identical=all(x == values[0] for x in values), actual_lengths=[len(x) for x in values])
        if config["mode"] == "timing":
            keys = selected[0]["observation"]["metrics"]
            groups[arm] = {key:stats([r["observation"]["metrics"][key] for r in selected
                                     if r["observation"]["metrics"][key] is not None]) for key in keys}
        else:
            groups[arm] = read(Path(selected[0]["folder"]) / "memory-summary.json")
    first = {arm:next(r["observation"]["generated_ids"] for r in runs if r["arm"] == arm) for arm in ARMS}
    between = {a + "__" + b:differences(first[a], first[b]) for i,a in enumerate(ARMS) for b in ARMS[i + 1:]}
    result = dict(mode=config["mode"], processes=len(runs), groups=groups,
                  within_arm_outputs=within, between_arm_first_process_outputs=between,
                  timer=config["timer"], input=config["input"],
                  throughput_evidence=config["mode"] == "timing", quality_threshold=None,
                  limits=["Three fresh timing processes per arm; descriptive median/min/max only, no significance claim.",
                          "TPS is computed per process from actual counts and full endpoints, then summarized. Never pool windows or average phase TPS.",
                          "Different natural IDs/EOS lengths mean different follow-up token work. Same prompt/quota is not a promise of identical output or quality.",
                          "Memory uses four separate monitored processes,10ms requested cadence with actual gaps/cost/nulls. Never use their timing as throughput.",
                          "Dedicated/shared peaks are separate; simultaneous total uses same-sample addition only. CPU commit/WS/GPU shared overlap, not physical allocation sums.",
                          "No exclusive GPU control, fixed clocks, killed desktop apps, page-cache clearing, warmup, profiler or synthetic acceptance."])
    save(output / "runs.json", runs)
    save(output / "summary.json", result)
    return result


def run(config_path, mode, output):
    if output.exists():
        raise ValueError("run output must be new")
    configuration = plan(config_path, mode, output)
    output.mkdir(parents=True)
    save(output / "inputs.json", configuration)
    helpers = load_helpers()
    helpers.gpu_snapshot(output, "window-before")
    try:
        for entry in configuration["commands"]:
            env = os.environ.copy()
            environment_path = entry["environment"]["path"]
            if identity(environment_path) != entry["environment"]:
                raise ValueError("runtime environment receipt changed")
            # Receipt also contains non-environment metadata (runtime arrays,
            # staged DLL identities). Only its actual PATH is an env override.
            env["PATH"] = read(environment_path)["PATH"]
            print("WINDOW_BEGIN", mode, entry["ordinal"], entry["arm"], flush=True)
            helpers.execute(Path(entry["folder"]), entry["arm"], entry["command"], env, mode == "memory")
            # Parse immediately; preserve the first actual schema/ledger failure.
            parse_result(Path(entry["folder"]), entry["arm"], configuration)
            print("WINDOW_END", mode, entry["ordinal"], entry["arm"], flush=True)
    finally:
        helpers.gpu_snapshot(output, "window-after")
    return analyze(output)


def self_check():
    helper = load_helpers()
    assert helper.marker("memory_phase=prefill_begin") == "window_prefill_begin"
    assert helper.marker("memory_phase=ready_begin") == "ready_before_prefill"
    assert helper.marker("memory_phase=decode_end") == "window_decode_end"
    assert helper.marker("memory_phase=generation_prefill_begin") == "generation_prefill_begin"
    assert helper.marker("memory_phase=generation_decode_end") == "generation_decode_end"
    assert helper.marker("measure_memory name=ready_before_first") == "ready_before_first"
    sampled = dict(samples=[dict(timestamp_ns=105, process_running=True, sample_duration_ns=2,
                    working_set_bytes=1, private_commit_bytes=2, gpu_dedicated_bytes=None,
                    gpu_shared_bytes=None, gpu_total_bytes=None)], peaks={}, gpu_setup_error=None, thread_error=None)
    record = dict(markers=[dict(name="ready_before_prefill", timestamp_ns=90),
                          dict(name="window_prefill_begin", timestamp_ns=100),
                          dict(name="window_prefill_end", timestamp_ns=110),
                          dict(name="window_decode_end", timestamp_ns=120)])
    result = helper.memory_summary(sampled, record)
    assert result["ready_baseline"]["unknown"]
    assert result["decode_begin_derived_from_prefill_end"]
    assert result["phase_windows"]["window_prefill"]["sample_count"] == 1
    assert result["phase_windows"]["window_decode"]["sample_count"] == 0
    assert result["phase_windows"]["window_prefill"]["values"]["gpu_total_bytes"]["max"] is None
    assert differences([1,2], [1,3,4])["first_divergence"] == 1
    return dict(status="pure_host_parser_checks_pass", GPU_runs=0, native_runs=0, model_computation=False,
                timer=timer_info(), checks="phase marker adaptation, shared boundary, null and empty sample preservation, unknown ready baseline, ID divergence")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("action", choices=("prepare-inputs", "plan", "run", "analyze", "self-check"))
    parser.add_argument("--model", type=Path, default=Path("C:/Users/kiro/Downloads/Qwen3.5-2B"))
    parser.add_argument("--text-manifest", type=Path, default=ROOT / ".scratch/architecture-refactor-2026-10-18/qwen-gpu-comparison/128-prefill/inputs/weights.tsv")
    parser.add_argument("--mtp-manifest", type=Path, default=ROOT / ".scratch/qwen-mtp-weights-20261022/prepared/weights.tsv")
    parser.add_argument("--config", type=Path, default=S / "arms.json")
    parser.add_argument("--mode", choices=("timing", "memory"), default="timing")
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    if args.action == "prepare-inputs":
        result = prepare_inputs(args.model, args.text_manifest, args.mtp_manifest)
        print(json.dumps(dict(input=str(S / "inputs/input.json"), prompt_tokens=result["prompt_tokens"],
                              capacity=1024, requested_outputs=64, model_computation=False)))
    elif args.action == "self-check":
        result = self_check()
        save(S / "preparation-checks.json", result)
        print(json.dumps(result))
    else:
        output = (args.output or S / "performance" / args.mode).resolve()
        if args.action == "plan":
            result = plan(args.config, args.mode, output)
            save(S / (args.mode + "-plan.json"), result)
            print(json.dumps(dict(processes=len(result["commands"]), plan=str(S / (args.mode + "-plan.json")), native_runs=0)))
        else:
            result = run(args.config, args.mode, output) if args.action == "run" else analyze(output)
            print(json.dumps(dict(summary=str(output / "summary.json"), processes=result["processes"], mode=result["mode"])))


if __name__ == "__main__":
    main()
