"""Two-turn binding over the retained four-arm window, clocks and PSAPI/PDH sampler."""
from pathlib import Path
import argparse
import importlib.util
import math
import re
import sys

sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent


def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    value = importlib.util.module_from_spec(spec); spec.loader.exec_module(value)
    return value


c = module('_natural_turns_current_images', S / 'current.py')
smoke = module('_natural_turns_existing_functional_checks', S / 'smoke.py')
base, h = c.base, c.h
original_load_helpers = base.load_helpers


def load_helpers():
    runner = original_load_helpers(); old_marker = runner.marker; turn = 0
    def marker(line):
        nonlocal turn
        if line.startswith('measure_memory ') and 'name=ready_before_first' in line:
            turn = 0
        found = re.search(r'\bmemory_phase=generation_default_(prefill|decode)_(begin|end)\b', line)
        if found:
            if found.groups() == ('prefill', 'begin'): turn += 1
            return f'round{turn}_{found[1]}_{found[2]}'
        return old_marker(line)
    # Labels alone adapt the existing single resident MTP request to the
    # sampler's original roundN phases. Sampling cadence/counters/clocks stay.
    runner.marker = marker
    return runner


def plan(config, mode, output):
    # First retain the current AV image/weights/flags/prompt guards. The only
    # workload change is replacing single --steps64 with the explicit two-turn
    # prompt/generate schedule, shared verbatim across all four arms.
    result = c.plan(config, mode, output)
    prepared = smoke.plan(output, quota=64)
    schedule = prepared['schedule']; c.require(schedule)
    for row in result['commands']:
        command = row['command']; index = command.index('--steps')
        if command[index + 1] != '64': raise ValueError('Retained output quota differs')
        del command[index:index + 2]
        command += ['--schedule', schedule['path']]
    result.update(script=base.identity(Path(__file__)), input=prepared['input'], source_AV_input=result['input'],
        schedule=schedule, user_ids=prepared['user_ids'], quota=64, turn_count=2,
        prompt_tokens=308, new_user_tokens=308, prefill_target_input_rows=309, pending_flushed_tokens=1,
        requested_output_tokens=128, maximum_decode_generated_tokens=126,
        genuine_multiturn=True, throughput_evidence=mode == 'timing',
        contract='One load and one resident session per process; two explicit originalP154 raw input segments, each greedy/EOS<=64;C1024/N1/R1. Previous pending is consumed once. No old-history prefill, forced generation, or cross-engine output equality assumption.',
        numerator_scope='Prefill309 actual target input rows also reports308 new-user rows; decode counts actual returned outputs minus2 prefill outputs. Extra MTP catchup/draft/verify rows remain actual cost, never user-output credit.')
    return result


def parse_result(folder, arm, configuration):
    raw = smoke.parse(folder)
    checked = smoke.check(raw, arm, configuration)
    detail = raw['sessions'][0]['result'] if arm == 'hyle_mtp' else raw
    ids = checked['generated_ids']; p, d, total = (float(raw[k]) for k in ('prefill_seconds', 'decode_seconds', 'session_seconds'))
    if not all(math.isfinite(x) and x >= 0 for x in (p, d, total)) or p <= 0 or total <= 0 or not math.isclose(p + d, total, rel_tol=1e-5, abs_tol=2e-6):
        raise ValueError('Top-level P+D must cover the same complete continuous session')
    prefill = raw['prefill_target_rows']; user = sum(len(configuration['user_ids']) for _ in checked['turns_observed'])
    if (prefill, user) != (309, 308): raise ValueError('Two-turn user/pending input accounting differs')
    startup = float(raw['startup_to_endpoint_seconds']); ready = float(raw['startup_to_ready_seconds'])
    first = float(raw['first_token_elapsed_seconds'])
    if 'weights_load_seconds' in raw: load = float(raw['weights_load_seconds'])
    else:
        stderr = (folder / 'stderr.log').read_text(encoding='utf-8', errors='replace')
        found = re.search(r'^weights_load_seconds=([^\s]+)', stderr, re.MULTILINE)
        if not found: raise ValueError('Original weights-load endpoint missing')
        load = float(found[1])
    if not all(math.isfinite(x) for x in (load, ready, first, startup)) or not 0 <= load <= ready <= first <= startup + 2e-6:
        raise ValueError('Actual load/ready/first/last endpoints differ')
    decode_outputs = len(ids) - 2
    if decode_outputs and d <= 0: raise ValueError('Generated decode outputs require positive complete decode time')
    metrics = dict(prefill_tokens_per_second=prefill / p, new_user_prefill_tokens_per_second=user / p,
        full_decode_tokens_per_second=decode_outputs / d if d else None,
        session_output_tokens_per_second=len(ids) / total,
        session_processed_tokens_per_second=checked['context'] / total,
        prefill_seconds=p, decode_seconds=d, session_seconds=total,
        weights_load_seconds=load, startup_to_ready_seconds=ready, first_token_elapsed_seconds=first,
        startup_to_endpoint_seconds=startup, cold_output_tokens_per_second=len(ids) / startup)
    keys = ('actual_graph_calls', 'actual_target_rows', 'actual_draft_rows', 'target_compute_calls', 'draft_compute_calls',
        'committed_target_rows', 'verified_target_rows', 'committed_target_decode_rows', 'target_decode_calls', 'draft_decode_calls',
        'draft_rows', 'draft_decode_rows', 'draft_rounds', 'agreements', 'accepted_drafts', 'proposals', 'generated_decode_tokens',
        'prefill_target_rows', 'prefill_draft_rows', 'visible_tokens', 'draft_frontier', 'draft_lag',
        'target_cache_backing_bytes', 'draft_cache_backing_bytes', 'cache_live_requested_bytes', 'cache_peak_requested_bytes',
        'shared_model_objects', 'native_contexts', 'pending_flushed_tokens', 'turn_count', 'restore_count')
    return dict(raw=detail, top_level_raw=raw, metrics=metrics, generated_ids=ids,
        actual_generated_tokens=len(ids), actual_generated_decode_tokens=decode_outputs,
        prompt_tokens=user, actual_prefill_target_rows=prefill, stopped_on_EOS=ids[-1] in smoke.EOS,
        turns=checked['turns_observed'], actual_context=checked['context'],
        work={key: raw.get(key) for key in keys},
        endpoint_sources=dict(prefill_decode_session='Original producer top-level complete continuous intervals; nested turn spans are explanatory only.',
            first_token='Actual first-turn prefill end, not a difference of aggregate multi-turn durations.'),
        work_scope='Actual natural outputs and native/Graph work; speculative/catchup rows are costs, not emitted tokens.')


def analyze(output):
    result = h.analyze(output)
    result.update(genuine_multiturn=True, actual_current_build=base.identity(c.BUILD),
        prefill_target_input_rows=309, new_user_tokens=308, maximum_outputs=128,
        same_token_cross_arm_speed_claim=False, historical_window_samples_pooled=False)
    result['limits'] = [x for x in result['limits'] if 'current AR image' not in x and 'current AR host' not in x]
    result['limits'] += [
        'Two explicit originalP154 raw input segments share one loaded model/session; output per turn is natural greedy/EOS<=64. Actual continuation IDs and acceptance/work may differ across arms.',
        'Prefill TPS uses309 actual target input rows including the previous pending flush;308 new-user rows is also reported. Decode uses actual outputs minus2 prefill outputs; total uses all actual outputs/continuous session seconds.',
        'Producer top-level P+D=session includes turn transitions and warm append. Nested per-turn timing is explanatory and must not replace the complete endpoints.',
        'MTP warm lag1 catchup remains charged in actual draft rows; its extra row is not a new user token. Memory is a separate12+4 protocol observation, not throughput evidence.'
    ]
    base.save(Path(output) / 'summary.json', result)
    return result


base.plan, base.parse_result, base.analyze, base.load_helpers = plan, parse_result, analyze, load_helpers


if __name__ == '__main__':
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument('action', choices=('plan', 'run', 'analyze'))
    cli.add_argument('--mode', choices=('all', 'timing', 'memory'), default='all')
    cli.add_argument('--output', type=Path)
    args = cli.parse_args()
    if args.mode == 'all' and args.output is not None: raise ValueError('Choose one mode for explicit output')
    modes = ('timing', 'memory') if args.mode == 'all' else (args.mode,)
    for mode in modes:
        output = h.owned_output(args.output or c.W / ('natural-' + mode + '1'))
        if args.action == 'plan':
            result = plan(c.W / 'arms.json', mode, output)
            base.save(c.W / ('natural-' + mode + '-plan1.json'), result)
            print('PLAN_ONLY', mode, len(result['commands']), output, flush=True)
        else:
            result = base.run(c.W / 'arms.json', mode, output) if args.action == 'run' else analyze(output)
            print('COMPLETE', mode, result['processes'], result['within_arm_fixed_work_valid'], output / 'summary.json', flush=True)
