"""Publish the two completed current four-arm windows; never run or fetch."""
from pathlib import Path
import importlib.util
import json
import sys
import zipfile

sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
R = S.parents[1]
W = S / 'current-window2'
NAME = 'qwen-mtp-single-and-multiturn-2026-10-24'


def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    value = importlib.util.module_from_spec(spec); spec.loader.exec_module(value)
    return value


a = module('_current_performance_archive', R / '.scratch/glm-quark-selected-20261024/Q30/publish.py')
a.SMALL_SUFFIXES.update({'.ids', '.diff', '.md'})
read, identity, require, resolve = a.read, a.identity, a.require, a.resolve
ARMS = ('hyle_plain', 'hyle_mtp', 'peer_plain', 'peer_mtp')
METRICS = ('prefill_tokens_per_second', 'full_decode_tokens_per_second', 'session_output_tokens_per_second')


def delta(left, right):
    return {key: 100 * (left[key]['median'] / right[key]['median'] - 1) for key in METRICS}


def compact_memory(group):
    result = {key: group[key] for key in ('sample_count', 'running_sample_count', 'sampled_peaks',
        'null_sample_counts', 'ready_baseline', 'unavailable_reasons', 'setup_error', 'thread_error',
        'throughput_evidence', 'limits', 'requested_interval_seconds', 'counter_source', 'timer')}
    for key in ('actual_sample_gaps_ms', 'sample_cost_ms'):
        result[key] = {name: value for name, value in group[key].items() if name != 'samples'}
    result['phase_windows'] = {}
    for name, phase in group['phase_windows'].items():
        result['phase_windows'][name] = {key: value for key, value in phase.items() if key != 'values'}
        result['phase_windows'][name]['values'] = {
            key: {k: v for k, v in value.items() if k != 'samples'}
            for key, value in phase['values'].items()}
    return result


def window(kind, timing_folder, memory_folder, archive):
    timing, memory = (read(folder / 'summary.json') for folder in (timing_folder, memory_folder))
    if (timing['processes'], memory['processes']) != (12, 4):
        raise ValueError('Require the actual 12 unmonitored +4 separate monitored processes')
    for summary in (timing, memory):
        if summary['status'] != 'complete_stable_within_arm_work' or not summary['within_arm_fixed_work_valid']:
            raise ValueError('Actual completed within-arm work must be stable')
        if set(summary['groups']) != set(ARMS): raise ValueError('Actual arms differ')
    executed, observations, phase = [], {}, {}
    for mode, folder in (('timing', timing_folder), ('memory', memory_folder)):
        plan, runs = read(folder / 'inputs.json'), read(folder / 'runs.json')
        if len(runs) != len(plan['commands']): raise ValueError('Actual process count differs')
        for item in (plan['script'], plan['configuration'], plan['input'], plan['prompt'], *plan['helpers']):
            require(item); archive.add(item['path'])
        for row, planned in zip(runs, plan['commands']):
            process = row['process']; run_folder = resolve(row['folder'])
            actual = read(run_folder / 'result.json')
            if actual != process or row['arm'] != planned['arm'] or process['command'] != planned['command']:
                raise ValueError('Actual command/result differs')
            if process['exit'] != 0 or process['reader_errors'] or process['profiler']:
                raise ValueError('A selected process did not complete cleanly')
            if process['memory_only'] != (mode == 'memory') or process['throughput_evidence'] != (mode == 'timing'):
                raise ValueError('Timing and memory observations must remain separate')
            if process['image'] != planned['image'] or resolve(process['image']['path']).stat().st_size != process['image']['bytes']:
                raise ValueError('Actual executed image identity differs')
            observed = read(run_folder / 'observation.json')
            expected = 128 if kind == 'two_turns' else 64
            if observed['actual_generated_tokens'] != expected: raise ValueError('Keep actual emitted output quota')
            if mode == 'timing': observations.setdefault(row['arm'], observed)
            executed.append(dict(arm=row['arm'], mode=mode, process=identity(run_folder / 'result.json'),
                observation=identity(run_folder / 'observation.json'), image=process['image'],
                start_unix_ns=process['started_unix_ns'], finish_unix_ns=process['finished_unix_ns']))
        archive.metadata_tree(folder)
        phase[mode] = dict(start_unix_ns=runs[0]['process']['started_unix_ns'],
            finish_unix_ns=runs[-1]['process']['finished_unix_ns'])
    work = {}
    for arm, observed in observations.items():
        raw, value = observed['raw'], observed['work']
        work[arm] = dict(actual_output_tokens=observed['actual_generated_tokens'], exported_work=value,
            stable_across_three_processes=timing['within_arm_work'][arm])
        if arm.endswith('mtp'):
            rounds = raw['rounds']; proposals = sum(row['draft'] >= 0 for row in rounds)
            accepted = sum(bool(row['accepted_draft']) for row in rounds)
            if accepted != value['accepted_drafts']: raise ValueError('Actual acceptance count differs')
            work[arm]['acceptance'] = dict(accepted=accepted, actual_proposals=proposals,
                actual_decode_rounds=len(rounds), final_single_without_proposal=sum(row['draft'] < 0 for row in rounds),
                accepted_fraction_of_proposals=accepted / proposals)
    between = {key: dict(equal=row['equal'], first_divergence_zero_based=row['first_divergence'],
        left_tokens=row['left_tokens'], right_tokens=row['right_tokens'])
        for key, row in timing['between_arm_first_process_outputs'].items()}
    result = dict(scope=kind, timing=dict(processes=12, groups=timing['groups'], timer=timing['timer'],
        within_arm_work=timing['within_arm_work'], between_arm_first_process_outputs=between),
        independent_memory=dict(processes=4, throughput_evidence=False,
            groups={arm: compact_memory(memory['groups'][arm]) for arm in ARMS}),
        comparisons={mode: delta(timing['groups']['hyle_' + mode], timing['groups']['peer_' + mode]) for mode in ('plain', 'mtp')},
        within_engine_MTP={engine: delta(timing['groups'][engine + '_mtp'], timing['groups'][engine + '_plain']) for engine in ('hyle', 'peer')},
        actual_work=work, executions=executed, phase=phase,
        raw_timing_summary=identity(timing_folder / 'summary.json'), raw_memory_summary=identity(memory_folder / 'summary.json'))
    result['numerators'] = dict(new_user_tokens=308 if kind == 'two_turns' else 154,
        target_prefill_input_rows=309 if kind == 'two_turns' else 154,
        actual_outputs=128 if kind == 'two_turns' else 64,
        decode_generated_outputs=126 if kind == 'two_turns' else 63,
        target_committed_rows=435 if kind == 'two_turns' else 217,
        pending_flushed_before_later_turn=1 if kind == 'two_turns' else 0)
    return result


def main():
    proof = R / 'docs/evidence/performance' / (NAME + '.json')
    target = proof.with_suffix('.logs.zip')
    if proof.exists() or target.exists(): raise ValueError('Never overwrite a published window')
    archive = a.Archive([])
    archive.add(Path(__file__))
    for name in ('current.py', 'turns.py', 'smoke.py', 'update_performance_docs.py',
                 'current-build-result.json', 'window-ready.json',
                 'natural-inputs/prepared.json', 'natural-inputs/performance64.txt'):
        archive.add(S / name)
    for path in (R / '.scratch/qwen-mtp-quality-20261022/current-window/performance.py',
                 R / '.scratch/qwen-mtp-window-20261022/window.py',
                 R / '.scratch/architecture-refactor-2026-10-18/qwen-gpu-comparison/memory-probe/memory_probe.py'):
        archive.add(path)
    build = read(S / 'current-build-result.json')
    for key in ('selected_hyle_ready', 'selected_peer_ready'):
        require(build[key]); archive.add(build[key]['path'])
    for path in (W / 'arms.json', W / 'hyle-ready.json', W / 'peer-ready.json'):
        archive.add(path)
    windows = dict(single_turn=window('single_turn', W / 'timing1', W / 'memory1', archive),
        two_turns=window('two_turns', W / 'natural-timing1', W / 'natural-memory1', archive))
    correctness = R / 'docs/evidence/correctness/mtp-qwen-natural-multiturn-2026-10-24.json'
    archive.add(correctness)
    for path in (S / 'publication-before').glob('*.md'): archive.add(path)
    for path in (R / 'docs/developer/current-work.md', R / 'docs/developer/mtp-progress.md',
                 R / 'docs/developer/performance/decode.md'): archive.add(path)
    result = dict(status='COMPLETE_CURRENT_SINGLE_AND_GENUINE_TWO_TURN_FOUR_ARM_WINDOWS',
        date='2026-10-24', goal_complete=False, windows=windows,
        current_build=identity(S / 'current-build-result.json'), current_images={
            engine: read(build['selected_' + engine + '_ready']['path'])['image'] for engine in ('hyle', 'peer')},
        consumer_source_build_and_finite_continuation=identity(correctness),
        fixed_workload=dict(model='Qwen3.5-2B BF16 text, matched original weights', system='Windows, RTX4070, all CUDA',
            capacity=1024, retained_sessions=1, active_sequences=1, prefix_cache='off', replay='auto',
            natural_greedy=True, EOS_respected=True, K=1, warmup=False, profiler=False,
            raw_token_append=True, chat_template_quality_claim=False),
        quiet_window=dict(performance_processes=32, download_and_other_native_work_paused=True,
            source='Root scheduling; measured process/clock/GPU-boundary records archived. B04 Range batch was explicitly paused before the first window and resumed only after both terminal0.'),
        memory_scope=dict(protocol='Original Windows PSAPI/PDH process observer in separate memory-only processes.',
            GPU_dedicated='WDDM per-process dedicated usage, not exact CUDA allocation accounting.',
            GPU_shared='Reported system-memory usage; may overlap CPU categories.',
            GPU_total='Dedicated+shared from the same valid sample; never sum independent category peaks.',
            CPU_working_set='Resident working set includes mapped/shared pages.',
            CPU_private_commit='Committed private address space, not resident physical RAM or pagefile disk usage.',
            no_physical_sum=True, ready_baseline_missing_is_null=True,
            phase_bracket_deltas='Neighbor-sample differences with actual ages; not exact phase-boundary allocation deltas.',
            sampled_peaks_are_lower_bounds=True),
        limits=[
            'Each arm has three independent timing processes; report every sample/range, no significance or universal speed claim.',
            'Natural generated tokens and MTP accept/verify work differ across arms. No equal-token or fully equal-arithmetic speed claim.',
            'Two turns keep one resident session/context. Target prefill309 includes one pending flush; new-user308 is separate;126 decode outputs exclude two first-prefill outputs.',
            'Top-level continuous P+D=session covers turn transitions. Nested turn intervals do not replace those endpoints.',
            'MTP extra draft/catchup/verification rows are charged as work, never credited as output/user tokens.',
            'Load endpoint is implementation-defined and excludes OS DLL load before main; last-output endpoint excludes destruction.',
            'Timing is unmonitored;8 independent memory processes do not provide TPS evidence.10ms requested sampling cadence is not exact.',
            'Current source snapshot is not an isolated MMQ or single-change speedup experiment. No historical samples are pooled or used to claim causal gain.',
            'Complete task-quality checks remain separately reported; readable outputs or this finite workload do not establish model quality.',
        ], archive_files=[])
    with zipfile.ZipFile(target, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as output:
        for entry, path in sorted(archive.files.items()): output.write(path, entry)
    result['archive_files'] = [dict(**identity(path), entry=entry) for entry, path in sorted(archive.files.items())]
    result['archive'] = identity(target)
    proof.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    receipt = dict(proof=identity(proof), archive=identity(target), entries=len(archive.files),
        native_runs=0, HTTP=0, full_body_or_image_rehashes=0)
    (S / 'performance-published.json').write_text(json.dumps(receipt, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(receipt))


if __name__ == '__main__': main()
