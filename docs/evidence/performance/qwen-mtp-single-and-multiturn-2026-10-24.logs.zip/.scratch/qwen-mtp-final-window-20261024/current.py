"""Current-image binding for the existing AV four-arm timing/memory protocol.

setup/plan/analyze never start models. Only run does, after root schedules a
quiet window. Inputs, clocks, observer, parsers and workloads remain retained.
"""
from pathlib import Path
import argparse
import importlib.util
import sys

sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
R = S.parents[1]
W = S / 'current-window2'
AR = R / '.scratch/qwen-mtp-quality-20261022'
AV = R / '.scratch/qwen-mtp-next-20261022/current-window'
CURRENT = AR / 'current-refresh-20261024'
BUILD = S / 'current-build-result.json'
BUILD_SHA = 'bf09d70048e65bb4a4569dda5ee542c74d02576847bce7d182f4522ac2540916'
PEER = S / 'peer-link1'
HELPER = AR / 'current-window/performance.py'
HELPER_SHA = 'c18106e6dc3b590be000194c3c26220e6579ee955949c5b054d09150d4d42f58'
spec = importlib.util.spec_from_file_location('_current_qwen_retained_AR_window', HELPER)
h = importlib.util.module_from_spec(spec); spec.loader.exec_module(h)
h.S = W
base = h.base


def require(info):
    if base.identity(info['path']) != info: raise ValueError('Actual identity changed: ' + info['path'])


def proof():
    if base.identity(HELPER)['sha256'] != HELPER_SHA or base.identity(BUILD)['sha256'] != BUILD_SHA:
        raise ValueError('Actual current build or retained measurement helper changed')
    value = base.read(BUILD)
    require(value['hyle_build']); built = base.read(value['hyle_build']['path'])
    if (built['current_product_hosts'], built['current_native_objects'], built['removed_focused_test_TUs'],
            built['removed_gtest_libraries'], value['SDK_builds'], value['NVCC_builds'], value['native_runs'], value['HTTP']) != (131, 4, 3, 2, 0, 0, 0, 0):
        raise ValueError('Actual current product composition differs')
    for key in ('selected_hyle_ready', 'selected_peer_ready', 'hyle_compile', 'hyle_link', 'peer_compile', 'peer_link'): require(value[key])
    ready = base.read(value['selected_hyle_ready']['path'])
    for key in ('source', 'compiled_record', 'link_plan', 'runtime_environment'): require(ready[key])
    for key in ('hyle_compile', 'hyle_link', 'peer_compile', 'peer_link'):
        if base.read(value[key]['path'])['exit'] != 0: raise ValueError('Actual compile/link did not pass')
    if ready['image'] != built['image'] or ready['image']['sha256'] != 'bdbd2c8149871e76d680b410ef77fc6f87d5524479dcae3a38b9f2d25face105':
        raise ValueError('Only the newly linked current Qwen image is allowed')
    link = base.read(ready['link_plan']['path'])
    if any('gtest' in arg.lower() for arg in link['command']): raise ValueError('Product image includes Gtest')
    runtime = base.read(ready['runtime_environment']['path'])
    if len(runtime['staged_dlls']) != 1 or runtime['staged_dlls'][0]['sha256'] != 'fcb2b57d8aad1453c8dde3468986d4f0120edcd71ef3e6edfd86870c6c1914fa':
        raise ValueError('Current corrected CPU runtime identity differs')
    for row in runtime['staged_dlls']: require(row)
    peer = base.read(value['selected_peer_ready']['path'])
    for key in ('source', 'compiled_identity', 'runtime_environment', 'link_plan'): require(peer[key])
    if peer['image']['sha256'] != '433e7051f4c36d0d9b2297dc378631546b7e3c44630cda0653cba2d1ec6bbe8e':
        raise ValueError('Actual new same-core peer consumer differs')
    return ready, peer, value


def setup():
    ready, peer, build = proof()
    wrapper = dict(image=ready['image'], source=ready['source'], runtime_environment=ready['runtime_environment'],
        original_ready=base.identity(CURRENT / 'hyle-link2/ready.json'), compiled_identity=ready['compiled_record'],
        link_plan=ready['link_plan'], actual_build_result=base.identity(BUILD),
        note='Actual current main1-TU/current131-host+4-native product image, no Gtest; original AV weights and input protocol.')
    require(peer['image'])
    W.mkdir(exist_ok=True)
    for kind, value in (('hyle', wrapper), ('peer', peer)): base.save(W / f'{kind}-ready.json', value)
    config = base.read(AV / 'arms.json')
    for arm, entry in config['arms'].items():
        entry['ready'] = str(W / ('hyle-ready.json' if arm.startswith('hyle') else 'peer-ready.json'))
    config['note'] = 'New current four-arm window; unchanged AV inputs/models/flags/endpoints, new turn-capable peer on the same fixed native core. No historical sample pooling.'
    base.save(W / 'arms.json', config)
    print('PREPARED_ONLY', W, flush=True)


def plan(config_path, mode, output):
    h.owned_output(output)
    current, current_peer, build = proof()
    inputs = base.read(base.S / 'inputs/input.json')
    if base.identity(base.S / 'inputs/input.json')['sha256'] != 'e768036a9ea28c234b49fc3510da144d11d099109e753d2a989e49fc87990ea2':
        raise ValueError('Original AV input metadata differs')
    for row in (inputs['inputs']['prompt'], inputs['inputs']['text'], inputs['inputs']['rendered_chat']): require(row)
    for kind in ('text', 'mtp'):
        for key in ('weights', 'prompt'):
            require(inputs['inputs']['manifests'][kind][key]['source'])
            require(inputs['inputs']['manifests'][kind][key]['destination'])
    config = base.read(config_path); original = base.read(AV / 'arms.json')
    if set(config['arms']) != set(base.ARMS): raise ValueError('Exactly four original arms required')
    for arm in base.ARMS:
        entry = config['arms'][arm]; old = original['arms'][arm]
        if {k: v for k, v in entry.items() if k != 'ready'} != {k: v for k, v in old.items() if k != 'ready'}:
            raise ValueError('Retained AV model/command protocol changed: ' + arm)
        expected = W / ('hyle-ready.json' if arm.startswith('hyle') else 'peer-ready.json')
        if Path(entry['ready']).resolve() != expected.resolve(): raise ValueError('Ready binding differs')
        ready = base.read(expected)
        if arm.startswith('hyle'):
            if ready['image'] != current['image'] or ready['compiled_identity'] != current['compiled_record']:
                raise ValueError('Current wrapper is not the actual current consumer')
        elif ready != current_peer: raise ValueError('New same-core peer wrapper differs')
        for key in ('source', 'runtime_environment'): require(ready[key])
    result = h.original_plan(config_path, mode, output)
    result.update(script=base.identity(Path(__file__)), retained_AV_config=base.identity(AV / 'arms.json'),
        retained_AR_window=base.identity(HELPER), actual_current_build=base.identity(BUILD),
        ready_mapping={arm: config['arms'][arm]['ready'] for arm in base.ARMS},
        current_Hyle_score_policy='bf16_inputs_f32_output', former_windows_pooled=False,
        same_token_cross_arm_speed_claim=False, genuine_multiturn=False,
        scope='Original AV single-turn P154/D64/C1024/N1/R1, natural greedy/EOS, replay auto;12 unmonitored timing processes and4 separate PSAPI/PDH memory processes.')
    return result


def analyze(output):
    result = h.analyze(output)
    result.update(actual_current_build=base.identity(BUILD), genuine_multiturn=False,
        runtime_scope='New current Hyle131-host/4-native closure and new turn-capable peer on the same fixed matched native core. Actual output/acceptance/work differences remain recorded.',
        historical_window_samples_pooled=False)
    result['limits'] = [x.replace('current AR image/F32-score policy', 'new current product image/F32-score policy')
        .replace('current AR host image', 'unchanged matched peer host image') for x in result['limits']]
    result['limits'].append('This retained AV workload is single-turn; its combined speed is64 outputs/(prefill+complete decode), not multi-turn KV-reuse or serving throughput.')
    base.save(Path(output) / 'summary.json', result)
    return result


base.plan, base.analyze = plan, analyze


if __name__ == '__main__':
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument('action', choices=('setup', 'plan', 'run', 'analyze'))
    cli.add_argument('--mode', choices=('all', 'timing', 'memory'), default='all')
    cli.add_argument('--output', type=Path)
    args = cli.parse_args()
    if args.action == 'setup': setup()
    else:
        if args.mode == 'all' and args.output is not None: raise ValueError('Choose one mode for explicit output')
        modes = ('timing', 'memory') if args.mode == 'all' else (args.mode,)
        for mode in modes:
            output = h.owned_output(args.output or W / (mode + '1'))
            if args.action == 'plan':
                value = plan(W / 'arms.json', mode, output)
                base.save(W / (mode + '-plan1.json'), value)
                print('PLAN_ONLY', mode, len(value['commands']), output, flush=True)
            else:
                value = base.run(W / 'arms.json', mode, output) if args.action == 'run' else analyze(output)
                print('COMPLETE', mode, value['processes'], output / 'summary.json', flush=True)
