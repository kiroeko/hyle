"""Four existing consumers, two natural turns: plan/check or root-scheduled run."""
from pathlib import Path
import argparse
import importlib.util
import json
import os
import sys

sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
R = S.parents[1]
Q = R / '.scratch/qwen-mtp-quality-20261022'
V = R / '.scratch/qwen-mtp-window-20261022'
HYLE = Q / 'current-refresh-20261024/hyle-link2'
PEER = S / 'peer-link1'
ARMS = ('hyle_plain', 'hyle_mtp', 'peer_plain', 'peer_mtp')
EOS = (248044, 248046)
spec = importlib.util.spec_from_file_location('_turns_existing_process_helper', Q / 'run_quality.py')
q = importlib.util.module_from_spec(spec); spec.loader.exec_module(q)
read, save, identity = q.read, q.save, q.ident


def require(info):
    if identity(info['path']) != info: raise ValueError('Actual current input changed: ' + info['path'])


def plan(output, quota=4):
    source = read(S / 'natural-inputs/prepared.json')
    definition = next(x for x in source['plans'] if x['output_quotas'] == [quota, quota])
    require(source['prompt']); require(definition['schedule'])
    commands = []
    models = read(R / '.scratch/qwen-mtp-next-20261022/current-window/arms.json')['arms']
    for arm in ARMS:
        peer = arm.startswith('peer'); mtp = arm.endswith('_mtp')
        folder = output / arm; root = PEER if peer else HYLE
        ready = read(root / 'ready.json'); require(ready['image']); require(ready['runtime_environment'])
        inputs = V / 'inputs' if peer else V / 'inputs' / ('mtp' if mtp else 'text')
        command = [ready['image']['path'], '--inputs', str(inputs), '--schedule', definition['schedule']['path'],
                   '--capacity', '1024', '--mtp', 'on' if mtp else 'off']
        if peer: command += ['--model', models[arm]['model'], '--memory-snapshots', 'off', '--output', str(folder / 'consumer-result.json')]
        else: command += ['--max-sessions', '1', '--active-sequences', '1', '--prefix-cache', 'off', '--progress', 'direct', '--replay', 'auto']
        commands.append(dict(arm=arm, folder=str(folder), command=command, image=ready['image'],
                             ready=identity(root / 'ready.json'), environment=ready['runtime_environment']))
    return dict(prepared_only=True, commands=commands, input=identity(S / 'natural-inputs/prepared.json'),
        schedule=definition['schedule'], user_ids=[int(x) for x in Path(source['prompt']['path']).read_text().split()],
        quota=quota, capacity=1024, model_loads_per_arm=1, same_context_across_turns=True,
        natural=True, greedy=True, EOS=list(EOS), teacher_forced_generation=False,
        throughput_evidence=False, memory_evidence=False, driver=identity(Path(__file__)))


def parse(folder):
    path = folder / 'consumer-result.json'
    if path.is_file(): return read(path)
    lines = (folder / 'stdout.log').read_text(encoding='utf-8').splitlines()
    return json.loads(next(line for line in reversed(lines) if line.startswith('{')))


def check(raw, arm, expected):
    mtp = arm.endswith('_mtp'); peer = arm.startswith('peer')
    detail = raw['sessions'][0]['result'] if not peer and mtp else raw
    ids = detail['generated_ids']; turns = detail['turns']
    if len(turns) != 2 or raw['mtp'] != mtp: raise ValueError('Actual mode/turn count differs')
    if not peer and detail.get('score_policy') != 'bf16_inputs_f32_output': raise ValueError('Actual Hyle precision policy differs')
    context = 0; offset = 0; prefill = 0
    for i, turn in enumerate(turns):
        begin, end = turn['output_begin'], turn['output_end']
        if turn['turn'] != i + 1 or begin != offset or not 1 <= end - begin <= expected['quota'] or turn['requested_steps'] != expected['quota']:
            raise ValueError('Actual per-turn output offsets/quota differ')
        output = ids[begin:end]
        if any(type(x) is not int or not 0 <= x < 248320 for x in output) or any(x in EOS for x in output[:-1]):
            raise ValueError('Generated IDs or per-turn EOS handling differ')
        if len(output) < expected['quota'] and output[-1] not in EOS: raise ValueError('Short natural turn has no EOS')
        inputs = ([ids[begin - 1]] if i else []) + expected['user_ids']
        if turn['input_ids'] != inputs or int(turn['pending_flushed']) != i:
            raise ValueError('Next turn must consume only previous pending plus the explicit new user IDs')
        after = context + len(inputs) + len(output) - 1
        if turn['context_before'] != context or turn['context_after'] != after or after > expected['capacity']:
            raise ValueError('Actual committed context length differs')
        if peer:
            if turn['native_target_pos_max'] != after - 1: raise ValueError('Native target position differs')
            if mtp and (turn['draft_after'] + turn['lag_after'] != after or not 0 <= turn['lag_after'] <= 1 or turn['native_draft_pos_max'] != turn['draft_after'] - 1):
                raise ValueError('Native draft frontier/lag differs')
        context = after; offset = end; prefill += len(inputs)
    if offset != len(ids) or raw['committed_target_rows'] != context or raw['prefill_target_rows'] != prefill or raw['generated_decode_tokens'] != len(ids) - 2:
        raise ValueError('Whole-session actual row/output ledger differs')
    if not peer and mtp:
        if raw['restore_count'] != 0 or raw['idle_evictions'] != 0 or raw['live_committed_versions'] != 0 or len(raw['sessions']) != 1:
            raise ValueError('The one resident session must retire without eviction/restoration')
        ledger = raw['sessions'][0]['ledger']; prior = 0
        for row in ledger:
            if row['before_length'] != prior or row['after_length'] != prior + row['accepted'] or row['imported']:
                raise ValueError('MTP accepted boundary ledger is not continuous')
            for at in ('before', 'after'):
                if row[at + '_frontier'] + row[at + '_lag'] != row[at + '_length'] or not 0 <= row[at + '_lag'] <= 1:
                    raise ValueError('MTP complete target/draft boundary differs')
            if not row['generation']:
                inputs = turns[row['turn'] - 1]['input_ids']; digest = 1469598103934665603
                for token in inputs: digest = ((digest ^ token) * 1099511628211) & ((1 << 64) - 1)
                if row['input_rows'] != len(inputs) or row['first_input'] != inputs[0] or row['input_hash'] != digest or row['after_lag'] != 0:
                    raise ValueError('Warm MTP append is not the exact pending/new-user chunk')
            prior = row['after_length']
        if prior != context: raise ValueError('MTP final accepted boundary differs from the session')
    return dict(arm=arm, passed=True, turns=2, generated_ids=ids, generated_tokens=len(ids),
        context=context, prefill_target_rows=prefill, generated_decode_tokens=len(ids) - 2,
        actual_target_rows=raw['actual_target_rows'], actual_draft_rows=raw['actual_draft_rows'],
        accepted_drafts=raw.get('accepted_drafts', 0), rounds=detail.get('rounds', []),
        turns_observed=turns, same_token_cross_arm_claim=False, throughput_evidence=False)


def run(output):
    if output.exists(): raise ValueError('Use a fresh actual smoke output')
    configuration = plan(output); output.mkdir(parents=True)
    save(output / 'plan.json', configuration); results = []
    for entry in configuration['commands']:
        folder = Path(entry['folder']); environment = os.environ.copy()
        require(entry['environment']); environment['PATH'] = read(entry['environment']['path'])['PATH']
        print('TURN_SMOKE_BEGIN', entry['arm'], flush=True)
        process = q.execute(entry['command'], environment, folder, timeout=600)
        if process['exit'] != 0 or process['timed_out']: raise ValueError('Actual two-turn consumer failed: ' + entry['arm'])
        observation = check(parse(folder), entry['arm'], configuration)
        save(folder / 'observation.json', observation); results.append(observation)
        save(output / 'summary.json', dict(status='All selected arms passed' if len(results) == 4 else 'Incomplete actual run',
            cases=len(results), failures=0, selected_arms=results, throughput_evidence=False, memory_evidence=False,
            scope='Same explicit two raw user-token segments; actual natural greedy/EOS/pending/context continuity, not full task quality or performance.'))
        print('TURN_SMOKE_PASS', entry['arm'], observation['context'], flush=True)


if __name__ == '__main__':
    cli = argparse.ArgumentParser(description=__doc__); cli.add_argument('action', choices=('plan', 'run'))
    cli.add_argument('--output', type=Path, default=S / 'smoke1'); args = cli.parse_args()
    if args.action == 'plan':
        value = plan(args.output); save(S / 'smoke-plan1.json', value)
        print('PLAN_ONLY', len(value['commands']), args.output, flush=True)
    else: run(args.output)
