"""Synchronize only the latest measured snapshot and its progress nodes."""
from pathlib import Path
from datetime import datetime
import json

S = Path(__file__).resolve().parent
R = S.parents[1]
W = S / 'current-window2'
before = S / 'publication-before'
before.mkdir(exist_ok=True)
names = ('current-work.md', 'mtp-progress.md', 'performance/decode.md')
docs = {}
for name in names:
    path = R / 'docs/developer' / name
    target = before / Path(name).name
    if target.exists(): raise ValueError('Before snapshot already exists; do not overwrite it')
    target.write_bytes(path.read_bytes()); docs[name] = path.read_text(encoding='utf-8')


def once(text, old, new):
    if text.count(old) != 1: raise ValueError('Expected one exact current passage: ' + old[:90])
    return text.replace(old, new, 1)


T = {k: json.loads((W / p / 'summary.json').read_text()) for k, p in
     [('单轮', 'timing1'), ('两轮', 'natural-timing1')]}
M = {k: json.loads((W / p / 'summary.json').read_text()) for k, p in
     [('单轮', 'memory1'), ('两轮', 'natural-memory1')]}
arms = [('hyle_plain', 'Hyle普通'), ('hyle_mtp', 'Hyle MTP K1'),
        ('peer_plain', 'llama.cpp普通'), ('peer_mtp', 'llama.cpp MTP K1')]
metrics = ('prefill_tokens_per_second', 'full_decode_tokens_per_second', 'session_output_tokens_per_second')
speed = ['| 负载／模式 | prefill tok/s | 完整decode tok/s | 综合输出 tok/s |', '| --- | ---: | ---: | ---: |']
ranges = ['| 负载／模式 | prefill范围 | decode范围 | 综合范围 | 加载s | 入口至ready s | 入口至末输出s |',
          '| --- | ---: | ---: | ---: | ---: | ---: | ---: |']
memory = ['| 负载／模式 | GPU dedicated峰 GiB | GPU shared峰 MiB | 同点GPU总峰 GiB | CPU WS峰 GiB | CPU private commit峰 GiB |',
          '| --- | ---: | ---: | ---: | ---: | ---: | ---: |']
for load in ('单轮', '两轮'):
    for arm, label in arms:
        g = T[load]['groups'][arm]
        speed.append('| ' + load + ' ' + label + ' | ' + ' | '.join(f'{g[k]["median"]:.3f}' for k in metrics) + ' |')
        row = [f'{g[k]["min"]:.2f}～{g[k]["max"]:.2f}' for k in metrics]
        row += [f'{g[k]["median"]:.3f}' for k in ('weights_load_seconds', 'startup_to_ready_seconds', 'startup_to_endpoint_seconds')]
        ranges.append('| ' + load + ' ' + label + ' | ' + ' | '.join(row) + ' |')
        p = M[load]['groups'][arm]['sampled_peaks']
        values = [p['sampled_peak_gpu_dedicated_bytes'] / 2**30, p['sampled_peak_gpu_shared_bytes'] / 2**20,
                  p['sampled_peak_gpu_total_bytes'] / 2**30, p['sampled_max_working_set_bytes'] / 2**30,
                  p['sampled_max_private_commit_bytes'] / 2**30]
        memory.append('| ' + load + ' ' + label + ' | ' + ' | '.join(f'{v:.3f}' for v in values) + ' |')
footer = '''## 最新完整性能对比

**2026-10-24，当前源码的单轮与真实两轮四臂窗口。** 北京时间06:33:07～06:34:54；Qwen3.5-2B、RTX 4070、全CUDA、匹配原BF16权重，C1024／N1／R1、前缀关闭、replay auto、自然greedy并尊重EOS。两种负载各有12个交错测速新进程（每臂3个），另各4个独立进程旁采内存，合计32进程；窗口期间暂停下载和其它原生运行。两窗分别统计，历史样本不合池。

单轮沿原P154输入、64枚输出；两轮在同一已加载模型和会话上各追加相同154枚原输入、各生成64枚，第二轮只消费上一pending与新增输入，不重prefill历史。两轮是明确的原token追加负载，不外推聊天模板或任务质量。

SPEED

单轮普通Hyle相对参考P／D／综合为+46.16%／−3.83%／+1.16%，MTP为+42.84%／−11.23%／−4.54%；两轮普通为+36.99%／−3.45%／−0.61%，MTP为+24.38%／−10.07%／−6.95%。两轮Hyle自身启用MTP使decode／综合+27.92%／+23.49%，参考自身为+37.34%／+31.91%。普通公共余差与MTP增量分开调查，这些差值不证明由某个控制函数或MMQ造成。

RANGES

表中速度及加载／ready／末输出是各臂3个独立进程的中位数，保留全部最小～最大范围，不作显著性结论。单轮decode分子为63；两轮prefill分子为**309行实际target输入（308枚新增用户输入＋1枚pending）**，decode为126枚新输出，综合为128输出／完整连续会话时间。顶层P＋D覆盖完整会话及轮间接纳；分轮span仅作说明。加载边界依消费者实现，入口不含OS装载DLL，末输出不含销毁，含启动总时长在原证据分列。

MEMORY

内存是独立Windows PSAPI／PDH进程旁采，采样峰是下界，不是精确物理分配。dedicated／shared独立峰不相加，总峰来自同一有效采样点；WS包含映射／共享驻留页，private commit是承诺地址空间，均不能与GPU shared简单相加为物理RAM。请求间隔10ms，实际中位15.01～15.31ms；单轮最大24.72ms、两轮最大19.56ms。八臂ready基线均无样本，保留null；两轮prefill每段仅3～9个样本，阶段邻样差仍带边界年龄。单轮到两轮Hyle普通／MTP dedicated采样峰分别多138／146MiB，参考峰近同值；这是不同完整进程的观测差，不是精确单轮分配增量或已定位泄漏。

**实际工作：** 每臂3次ID、工作量和非计时决策稳定，全部达到64／128输出，未触发EOS。单轮Hyle MTP接受29／34个proposal、验证68行、draft decode62行；参考接受30／33、验证66行、draft decode62行。两轮Hyle接受60／66（90.91%），target验证132行、draft decode124行；参考接受61／64（95.31%），另有1次无proposal的单行尾步，共65次decode调用、target验证129行、draft decode125行。两者prefill target309／draft310行，额外catchup仍计成本，不计用户token。两轮target总计算Hyle441／参考438行，draft总计算434／435行，最终均提交435行。不能按每轮均摊把完整decode余差归于接受率。

**可比边界与后续：** 跨臂自然续文和实际工作不同，单轮从第19枚起分歧；Hyle中间BF16、末分数F32，参考保持原生计算／状态／host carry。报告真实自然生成吞吐，不称同token或数学完全一致，也不以可读性代签质量。本次更新当前源码闭包并接通真实两轮，未作隔离MMQ收益实验；与旧AV的跨窗变化不能归因某次优化。下一步仍是剩余制品接线与普通／MTP实际余差，保留既定质量失败与未知项。

[两窗24次计时、8次独立内存旁采、完整samples／命令／结果](../evidence/performance/qwen-mtp-single-and-multiturn-2026-10-24.json)；[自然两轮有限状态与构建证明](../evidence/correctness/mtp-qwen-natural-multiturn-2026-10-24.json)。此前[AV](../evidence/performance/qwen-mtp-assembly-2026-10-22.json)、[AU](../evidence/performance/qwen-capture-variants-2026-10-22.json)及其回链保留历史口径，不混算。
'''.replace('SPEED', '\n'.join(speed)).replace('RANGES', '\n'.join(ranges)).replace('MEMORY', '\n'.join(memory))
current = docs['current-work.md']
current = once(current,
    '**最新完整性能仍是[页末AV四臂窗口](#最新完整性能对比)**：普通Hyle／llama.cpp prefill为2349.076／1553.955tok/s，decode99.764／105.224；MTP为2137.322／1499.623、123.162／139.532。普通共用成本和MTP增量分别调查，不能用总TPS判定MTP逻辑错误；本次原角色接线没有新TPS或显存数据。',
    '**最新完整性能见[页末2026-10-24单轮／真实两轮四臂窗口](#最新完整性能对比)**：单轮普通Hyle／llama.cpp decode98.093／101.998tok/s，MTP120.508／135.747；两轮普通98.082／101.590、MTP125.465／139.519，两轮综合分别92.967／93.534和114.806／123.383。普通公共余差和MTP增量分别调查；本窗不是隔离某次优化的收益实验。')
current = once(current,
    '当前单轮／两轮速度及独立内存窗口准备中，尚无新性能数据。',
    '当前单轮／真实两轮四臂速度及独立内存窗口均已实测完成，各12＋4进程，结果见页末；两轮功能检查另保有限状态证据。')
current = once(current, '真实两轮四臂功能已过，单轮／两轮测速准备中。',
    '真实两轮四臂功能及各12＋4进程的单轮／两轮性能窗口已完成，普通／MTP余差仍待实际热点定位。')
current = once(current, '页末AV仍是最新完整性能窗口。', '最新完整性能已更新为页末2026-10-24两窗，未完成制品不由Qwen窗口代签。')
current = once(current, '最终普通／MTP性能复测与热点；不将有限数值检查外推为所有形状或任务质量',
    '单轮／真实两轮当前性能复测已完成；继续普通／MTP热点，不将有限数值检查外推为所有形状或任务质量')
current = current[:current.index('## 最新完整性能对比')] + footer

decode = docs['performance/decode.md']
start = decode.index('**当前优先项（2026-10-22）')
end = decode.index('变体实现前的[每步诊断]')
new = '''**当前优先项（2026-10-24）：用已完成的单轮／真实两轮窗口定位普通公共成本及MTP增量。** 当前源码、匹配原权重与原P154输入；单轮64输出，两轮在同一会话各追加P154并各生成64，保自然greedy／EOS。每种负载各12个交错新进程测速，另4个进程独立旁采内存，两窗和历史样本不合池。

| 当前负载／模式 | Hyle prefill | Hyle decode | Hyle综合 | peer prefill | peer decode | peer综合 |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| 单轮普通 | 2285.823 | 98.093 | 90.373 | 1563.944 | 101.998 | 89.335 |
| 单轮MTP | 2087.841 | 120.508 | 107.284 | 1461.629 | 135.747 | 112.387 |
| 真实两轮普通 | 3301.684 | 98.082 | 92.967 | 2410.144 | 101.590 | 93.534 |
| 真实两轮MTP | 2792.392 | 125.465 | 114.806 | 2245.021 | 139.519 | 123.383 |

单位tok/s，中位数；全部samples、范围、加载和端点见[最新两窗证据](../../evidence/performance/qwen-mtp-single-and-multiturn-2026-10-24.json)及[当前工作末表](../current-work.md#最新完整性能对比)。单轮普通／MTP decode落后3.83%／11.23%，两轮落后3.45%／10.07%；两轮综合落后0.61%／6.95%。两轮Hyle自身MTP decode提升27.92%，参考自身提升37.34%；总余差不能都算作MTP逻辑或纯GPU问题。

两轮prefill以309行实际target输入计速，另列308枚新增用户token；decode以126枚输出计速，综合128枚输出／连续会话时间，加载分列。只补前一pending及新输入，未重算历史；额外draft catchup不记用户token。Hyle MTP接受60／66，验证132行；peer接受61／64，另有一次无proposal尾步，共65次decode调用、验证129行。两边自然续文不同，不按每轮均摊把全部墙差归于接受率，也不要求强制同token。

单轮Hyle普通／MTP dedicated采样峰3.888／4.048GiB，两轮4.023／4.191GiB；peer两窗均3.728／3.896GiB。它们来自独立PSAPI／PDH旁采，是采样下界；ready基线均null，WS／commit／shared不相加为物理RAM。实际采样最大间隔24.72ms，不能按请求10ms解释为精确分配计费。

本窗完成当前产品闭包与真实两轮驱动对照，不是隔离MMQ、capture或某个算子改动的收益实验；与AV的跨窗变化不作因果归因。[两轮有限功能与构建](../../evidence/correctness/mtp-qwen-natural-multiturn-2026-10-24.json)已保留实际pending／cursor／续算。后续优先依据少量当前热点决定改动，普通与MTP分开计账；不重开已拒绝的行拆、Top1或旧capture候选。

历史[AV组装窗口](../../evidence/performance/qwen-mtp-assembly-2026-10-22.json)及[29项相关检查](../../evidence/correctness/mtp-consumer-wiring-2026-10-22.json)保留输入ReadLease候选表懒建、F32 Add对齐与冷alias准入的原结论；[AU有界capture](../../evidence/performance/qwen-capture-variants-2026-10-22.json)保留两份变体及真实失效／权限／退休门。这些历史实现与结果不充当本窗热点比例或新增收益证明。

'''
decode = decode[:start] + new + decode[end:]
decode = once(decode,
    '下一步沿当前实际热点定位普通与MTP余差，并推进其它已有真实MTP制品的适用接线；本批有限反馈／原权重角色检查不代签其它格式或完整接受状态，也不表示GPU余差已定位，不扩大重复验证范围。',
    '下一步沿当前实际热点定位普通与MTP余差，并推进余B04／B07／Q32适用接线；有限制品检查不代签完整模型，当前窗口也不表示GPU余差已定位，不扩大重复验证范围。')

progress = docs['mtp-progress.md']
progress = once(progress, '更新：2026-10-24 06:31（北京时间）。',
    '更新：2026-10-24 ' + datetime.now().strftime('%H:%M') + '（北京时间）。')
progress = once(progress, '**MTP整体 — 约80%**', '**MTP整体 — 约85%**')
progress = once(progress, '**性能收尾 — 约35%**', '**性能收尾 — 约65%**')
progress = once(progress, '最新四臂速度、内存与多轮综合复测 — 0%', '最新四臂速度、内存与多轮综合复测 — 100%（单轮／真实两轮各12＋4进程）')
row = '| 真实多轮四臂驱动 | 普通／MTP都复用同一会话上下文 | 性能收尾 → 最新四臂速度、内存与多轮综合复测 | 真实两轮四臂功能已过：每臂8枚输出、309行prefill、缓存长度315；单轮／两轮测速准备中 |\n'
progress = once(progress, row, '')
for name, value in [('current-work.md', current), ('performance/decode.md', decode), ('mtp-progress.md', progress)]:
    (R / 'docs/developer' / name).write_text(value, encoding='utf-8')
print('Updated latest measured snapshot in three existing documents; historical evidence unchanged.')
