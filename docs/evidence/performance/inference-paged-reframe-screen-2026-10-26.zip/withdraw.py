"""Restore only this closed candidate's two exact, preserved source changes."""
from pathlib import Path
import hashlib
import json

W = Path(__file__).resolve().parent
R = W.parents[1]
I = R / '.scratch/inference-b2-reframe-single-source-20261026'

def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))

def pin(path):
    path = Path(path)
    raw = path.read_bytes()
    return dict(path=str(path), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())

summary = read(W / 'summary.json')
assert summary['status'] == 'COMPLETE_8_FULL_NON_TIME_AND_198IDS_EQUAL'
handoff = read(I / 'handoff.json')
corrected = read(I / 'test-correction2/receipt.json')
rows = []
for row in handoff['sources']:
    target = R / row['product_path']
    current = row['current'] if row['product_path'].startswith('src/') else corrected['corrected_current_test']
    assert pin(target) == current, 'Preserve any unrelated later edits'
    assert pin(row['before']['path']) == row['before']
    frozen = row['frozen'] if row['product_path'].startswith('src/') else corrected['corrected_frozen_test']
    assert pin(frozen['path']) == frozen, 'Keep the tested candidate source'
    rows.append(dict(target=target, current=current, before=row['before'], frozen=frozen))
assert not (W / 'withdrawal.json').exists()
for row in rows:
    row['target'].write_bytes(Path(row['before']['path']).read_bytes())
    assert pin(row['target'])['sha256'] == row['before']['sha256']
receipt = dict(status='CLOSED_NOT_MERGED_CANONICAL_SOURCES_RESTORED',
    reason='No net full-consumer speed benefit; candidate decode and combined medians fell and ranges overlap. Do not refill samples or retain the extra fast path.',
    summary=pin(W / 'summary.json'),
    restored=[dict(path=str(row['target']), candidate=row['current'], restored=pin(row['target']), candidate_frozen=row['frozen']) for row in rows],
    unrelated_files_changed=False, extra_builds_or_model_runs=0)
(W / 'withdrawal.json').write_text(json.dumps(receipt, indent=2) + '\n', encoding='utf8')
print(json.dumps(receipt, indent=2))
