"""Explicit, post-decision publication only. Preparing/importing starts nothing."""
from pathlib import Path
import argparse
import hashlib
import json
import subprocess
import zipfile

W = Path(__file__).resolve().parent
R = W.parents[1]
I = R / '.scratch/inference-b2-reframe-single-source-20261026'
DEST = R / 'docs/evidence/performance'
NAME = 'inference-paged-reframe-screen-2026-10-26'


def read(p):
    return json.loads(Path(p).read_text(encoding='utf-8-sig'))


def sha(p):
    with Path(p).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def publish(decision, reason):
    result = read(W / 'summary.json')
    tests = read(W / 'cpu-contract3/summary.json')
    review = read(W / 'independent-result-review.json')
    assert result['status'] == 'COMPLETE_8_FULL_NON_TIME_AND_198IDS_EQUAL'
    assert tests['status'] == 'PASS_8_CPU_REFRAME_TESTS'
    assert tests['counts'] == dict(tests=8, failures=0, errors=0, skipped=0)
    assert review['status'] == 'INDEPENDENT_OFFLINE_RECALCULATION_PASS'
    assert review['decision'] == decision
    assert result['process_count'] == 8 and result['complete_nontime_differences'] == result['ID_differences'] == 0
    assert all(x['process']['exit'] == 0 and not x['process'].get('timeout') for x in result['runs'])
    assert [x['mode'] for x in result['runs']] == ['timing']*6 + ['memory']*2
    assert [x['arm'] for x in result['runs']] == ['control','candidate','candidate','control','control','candidate','control','candidate']
    correction = I / 'test-correction/receipt.json'
    correction2 = I / 'test-correction2/receipt.json'
    assert correction.is_file() and (I / 'test-correction/test-only-correction.patch').is_file()
    assert correction2.is_file() and (I / 'test-correction2/test-only-correction.patch').is_file()
    assert (W / 'cpu-contract1/compile/process.json').is_file(), 'Preserve the first failed test attempt'
    assert read(W / 'cpu-contract1/compile/process.json')['exit'] != 0
    assert read(W / 'cpu-contract2/run/process.json')['exit'] != 0
    # Canonical source/test may be withdrawn. Certify the retained compiled
    # snapshots, never require a mutable current pathname to keep its old hash.
    candidate = read(W / 'candidate/ready.json')
    assert sha(candidate['source']['path']) == candidate['source']['sha256']
    frozen_test = read(correction2)['corrected_frozen_test']
    assert sha(frozen_test['path']) == frozen_test['sha256']
    test_ready = read(W / 'cpu-contract3/ready.json')
    assert (test_ready['source']['bytes'],test_ready['source']['sha256']) == (frozen_test['bytes'],frozen_test['sha256'])
    test_deps = read(test_ready['actual_dependencies']['path'])
    source_key = test_ready['source']['path'].replace('/','\\').casefold()
    compiled_source = [x for x in test_deps if x['path'].replace('/','\\').casefold()==source_key]
    assert len(compiled_source)==1 and compiled_source[0]['sha256']==frozen_test['sha256']
    archive_path, report_path = DEST / (NAME+'.zip'), DEST / (NAME+'.json')
    assert not archive_path.exists() and not report_path.exists(), 'Do not overwrite a published result'
    suffixes = {'.json','.log','.py','.cc','.h','.patch','.xml','.txt','.ps1'}
    selected = []
    for prefix, root in [('',W),('implementation/',I)]:
        for path in root.rglob('*'):
            if not path.is_file() or path.suffix.lower() not in suffixes:
                continue
            if '__pycache__' in path.parts or path.name in {'archive-receipt.json','archive-manifest.json'}:
                continue
            selected.append((prefix+path.relative_to(root).as_posix(),path))
    names = {name for name,_ in selected}
    assert len(names)==len(selected)
    assert any(name.startswith('cpu-contract1/') for name in names)
    assert any(name.startswith('cpu-contract2/') for name in names)
    assert any(name.startswith('cpu-contract3/') for name in names)
    assert 'implementation/test-correction/test-only-correction.patch' in names
    assert 'implementation/test-correction2/test-only-correction.patch' in names
    assert all(not name.lower().endswith(x) for name in names for x in ('.exe','.obj','.dll','.lib','.exp','.pdb','.map','.nsys-rep','.sqlite','.safetensors','.gguf'))
    manifest = [dict(member=name,bytes=path.stat().st_size,sha256=sha(path)) for name,path in sorted(selected)]
    with zipfile.ZipFile(archive_path,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as archive:
        for name,path in sorted(selected):
            archive.write(path,name)
        archive.writestr('archive-manifest.json',json.dumps(manifest,indent=2)+'\n')
    with zipfile.ZipFile(archive_path) as archive:
        assert archive.testzip() is None and len(archive.namelist())==len(manifest)+1
        for row in manifest:
            data=archive.read(row['member'])
            assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256']
    memory = {}
    for arm,facts in result['memory'].items():
        memory[arm]={k:facts[k] for k in ('sample_count','running_sample_count','sampled_peaks','null_sample_counts','ready_baseline','setup_error','thread_error')}
        memory[arm]['actual_sample_gaps_ms']={k:v for k,v in facts['actual_sample_gaps_ms'].items() if k!='samples'}
    report = dict(schema='hyle.performance.evidence.v1',date='2026-10-26',status=decision,decision=reason,
        source_git_before_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),
        change='A validated single-source specialization in the existing PagedArena::reframe. Exact source and eight contract cases are retained; no new cache, decoder, owner or executor.',
        decision_boundary='Decision is supplied explicitly after the completed screen. A positive overlapping median is not a stable throughput result, and deterministic redundant work alone does not require adopting this fast path.',
        build=dict(new_product_TUs=1,source=read(W/'candidate/ready.json')['source'],
            candidate_image=read(W/'candidate/ready.json')['image'],
            control_image=read(R/'.scratch/inference-result-publication-screen-20261026/candidate/ready.json')['image'],
            link_delta=read(W/'plan.json')['actual_link_delta'],SDK_or_device_builds=0,
            scope='Control f36 retains the previous ResourceEpisode publication change. Only its original cpu-arena.obj is replaced; all other221 link inputs, including the resources object, are identical.'),
        validation=dict(cpu_contract3=tests,
            first_cpu_contract_compile=read(W/'cpu-contract1/compile/process.json'),
            second_cpu_contract_run=read(W/'cpu-contract2/run/process.json'),
            separate_test_correction=read(correction),
            separate_test_correction2=read(correction2),
            frozen_corrected_test=frozen_test,
            source_validation='Frozen candidate snapshot and corrected private test match actual compiled source hashes. Mutable canonical originals may be restored without changing this evidence.',
            source_review='implementation/independent-review-architecture.json',
            full_non_time_differences=0,output_ID_differences=0,
            processes=8,unmonitored_timing=6,independent_memory=2,
            workload='Ordinary greedy CUDA B2 teacher-forced C1024/N2/R2, prefix off and MTP off; three P256+32 turns per request,99 physical episodes,1728 input rows,198 decisions.',
            extra_behavior_or_warmup_processes=0,old_samples_pooled=False),
        metrics=result['metrics'],comparisons=result['comparisons'],memory=memory,
        independent_result_review=review,
        prior_phase_scope=read(W/'offline-preflight-review.json')['bound'],
        limits=['Three fresh timing samples per arm and one independent memory process each; no sample refill or peer run.',
            'Memory peaks are sampled lower bounds. Ready/phase gaps or unavailable counters remain unknown, and separate peaks are not additive.',
            'The older21.130ms page/frame-export interval is a profiled wall envelope, not the cost of this fast path or its recoverable benefit. Do not subtract it from these unprofiled endpoints.',
            'The host-phase diagnostic had truncated captured stdout; its full report/198IDs gate did not complete. This screen requires complete uninstrumented reports independently.',
            'Observed lower medians in this finite screen do not identify a cause. No new profiling, replacement samples or sweep was used.',
            'This does not refresh the reference table, certify other backends/models, or prove that the major B2 gap has been fixed.'],
        archive=dict(path=archive_path.name,bytes=archive_path.stat().st_size,sha256=sha(archive_path),
            members=len(manifest)+1,verification='ZIP CRC and every member length/SHA256 verified once'))
    report_path.write_bytes((json.dumps(report,ensure_ascii=False,indent=2)+'\n').encode())
    (W/'archive-receipt.json').write_bytes((json.dumps(report['archive'],indent=2)+'\n').encode())
    print(json.dumps(dict(report=str(report_path),archive=report['archive']),indent=2))


if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('action',choices=['publish'])
    parser.add_argument('--decision',required=True,choices=['ADOPTED','CLOSED_NOT_MERGED'])
    parser.add_argument('--reason',required=True)
    args=parser.parse_args()
    publish(args.decision,args.reason)
