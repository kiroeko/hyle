"""Explicit root-only B2 screen: original adapter/observer, two Hyle images, 8 runs."""
from pathlib import Path
import hashlib
import inspect
import json
import math
import os
import re
import sys
import traceback

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = W.parents[1]
B = R / '.scratch/inference-b2-current-window-20261026'
REFERENCE = R / '.scratch/inference-result-publication-screen-20261026/runs/timing-02-candidate'
import importlib.util
spec = importlib.util.spec_from_file_location('retained_b2', B / 'run.py')
b = importlib.util.module_from_spec(spec)
spec.loader.exec_module(b)

read, pin, exact, save = b.read, b.identity, b.verify, lambda p,x: Path(p).write_bytes((json.dumps(x,indent=2,ensure_ascii=False)+'\n').encode('utf8'))


def prepare():
    assert not (W/'plan.json').exists() and not (W/'runs').exists(), 'Do not overwrite a prepared or used screen'
    old_plan, old_pins = read(B/'plan.json'), read(B/'pins.json')
    ready_paths = dict(control=R/'.scratch/inference-result-publication-screen-20261026/candidate/ready.json', candidate=W/'candidate/ready.json')
    ready = {a:read(p) for a,p in ready_paths.items()}
    for item in ready.values():
        for key in ('image','runtime','link_inputs'):
            exact(item[key])
    inputs = {a:read(item['link_inputs']['path']) for a,item in ready.items()}
    assert len(inputs['control']) == len(inputs['candidate'])
    changes = [(i,a,c) for i,(a,c) in enumerate(zip(inputs['control'],inputs['candidate'])) if a != c]
    assert len(changes) == 1, changes
    expected_old = R/'.scratch/inference-f32-append-20261025/cpu1/compile/cpu-arena/unit.obj'
    assert str(changes[0][1]['path']).replace('/', '\\').casefold() == str(expected_old).replace('/', '\\').casefold(), changes
    assert changes[0][2] == ready['candidate']['app']
    commands = []
    for i,arm in enumerate(['control','candidate','candidate','control','control','candidate','control','candidate']):
        memory = i >= 6
        folder = W/'runs'/f'{"memory" if memory else "timing"}-{i-5 if memory else i+1:02d}-{arm}'
        argv = [ready[arm]['image']['path'], *old_plan['commands'][0]['command'][1:]]
        commands.append(dict(arm=arm, mode='memory' if memory else 'timing', index=i+1,
            folder=str(folder), command=argv, runtime=ready[arm]['runtime'], memory_only=memory))
    frozen = [pin(__file__), pin(B/'run.py'), pin(B/'plan.json'), pin(B/'pins.json'),
        pin(B/'expected-work.json'),pin(B/'runner-ready.json'),pin(REFERENCE/'complete-nontime-report.json'),
        pin(REFERENCE/'stdout.log')]
    frozen += list(old_pins['harness'].values())
    for arm,item in ready.items():
        frozen += [pin(ready_paths[arm]), item['image'], item['runtime'],item['link_inputs']]
        runtime=read(item['runtime']['path'])
        if 'native_hardlink' in runtime:
            exact(runtime['native_hardlink'])
            frozen.append(runtime['native_hardlink'])
    expected = read(B/'expected-work.json')
    frozen += [expected['manifest'],expected['schedule'],*[x['file'] for x in expected['tapes']]]
    for p in frozen:
        exact(p)
    save(W/'plan.json',dict(status='FROZEN_READY_NOT_RUN', process_count=8, timing_count=6, independent_memory_count=2,
        commands=commands, files=frozen, harness=old_pins['harness'],
        actual_link_delta=dict(index=changes[0][0],before=changes[0][1],after=changes[0][2],
            unchanged_inputs=len(inputs['control'])-1),
        work='Same existing P3x256/3x32 teacher-forced tapes, C1024/N2/R2, ordinary greedy CUDA, prefix off, MTP off: 99 physical episodes, 1728 rows and 198 decisions.',
        full_work_gate='Each report must pass original B2 check_work and equal the original f36 complete non-time report and all198IDs. No extra metadata exclusions. Every difference is saved before stopping.',
        normalization='Reuse exact original B2 normalize: original seconds/rates/timestamps and only memory[].device_global_free_bytes telemetry removed with audited paths; all raw values retained.',
        timeout_seconds=180, extra_behavior_or_warmup_processes=0, old_samples_pooled=False,
        scopes=['Only the actual paged_arena.obj input differs from f36; the prior resources-publication object and all other221 inputs remain identical. No claim that later canonical CPU/SDK code was built.',
            'Six unmonitored timing processes; two independent monitored memory processes, excluded from rates.',
            'Use original Hyle waves/interleaved_seconds endpoints; no profiler or new markers.',
            'Sampled WS/commit/VRAM are lower bounds, null stays null; separate peaks are not additive.',
            'First error or work difference stops with no retry/refill. This script never builds.']))
    print('PAGED_REFRAME_SCREEN_PREPARED', str(W/'plan.json'), flush=True)


def run():
    plan=read(W/'plan.json')
    assert plan['status']=='FROZEN_READY_NOT_RUN' and len(plan['commands'])==8
    assert not (W/'runs').exists() and not (W/'run-state.json').exists(), 'No overwrite or sample refill'
    for row in plan['files']:
        exact(row)
    expected=read(B/'expected-work.json')
    historical=json.loads((REFERENCE/'stdout.log').read_text(encoding='utf8'))
    reference=read(REFERENCE/'complete-nontime-report.json')
    reference_ids=b.ids_for(historical,'hyle')
    h=b.module('paged_reframe_retained_runner',plan['harness']['runner']['path'])
    b.module('paged_reframe_retained_observer',plan['harness']['observer']['path']).install(h)
    original=inspect.getsource(h.execute)
    assert original.count('timeout=900')==1 and original.count("record['pid'] = process.pid")==1
    adapted=original.replace('timeout=900','timeout=180').replace("record['pid'] = process.pid", "record['pid'] = process.pid\n        print('PAGED_REFRAME_MODEL_PID', process.pid, flush=True)")
    exec(compile(adapted,str(plan['harness']['runner']['path'])+':timeout180_and_PID_only','exec'),h.__dict__)
    code,binding=b.legacy_phase_parser(plan['harness']['old_performance_parser']['path'])
    assert binding['extracted_code_sha256']==read(B/'runner-ready.json')['legacy_phase_code_sha256']
    save(W/'execution-binding.json',dict(plan=pin(W/'plan.json'),runner=pin(__file__),
        retained_execute_before_sha256=hashlib.sha256(original.encode()).hexdigest(),
        retained_execute_after_sha256=hashlib.sha256(adapted.encode()).hexdigest(),
        adaptation='Only 900s -> 180s watchdog and immediate parent console PID; model argv/observer/endpoints unchanged.',
        parser=binding,baseline=pin(REFERENCE/'complete-nontime-report.json')))
    runs,memory=[],{}
    entry=None
    save(W/'run-state.json',dict(status='RUNNING',completed=0,planned=8))
    h.gpu_snapshot(W,'window-before')
    try:
        for entry in plan['commands']:
            arm,folder=entry['arm'],Path(entry['folder'])
            print('PAGED_REFRAME_BEGIN',entry['mode'],entry['index'],arm,flush=True)
            env=os.environ.copy()
            env['PATH']=read(entry['runtime']['path'])['PATH']
            env.update(HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1')
            process=h.execute(folder,'hyle',entry['command'],env,entry['memory_only'])
            raw=json.loads((folder/'stdout.log').read_text(encoding='utf8'))
            audit=[]
            normalized=b.normalize(raw,audit)
            delta=b.differences(reference,normalized)
            save(folder/'normalization-audit.json',audit)
            save(folder/'complete-nontime-report.json',normalized)
            save(folder/'baseline-nontime-differences.json',delta)
            ids=b.check_work(raw,'hyle',expected,historical)
            id_delta=b.differences(reference_ids,ids)
            save(folder/'baseline-ID-differences.json',id_delta)
            assert not delta and not id_delta, 'Full original f36 B2 work changed; no replacement samples'
            namespace=dict(folder=folder,raw=raw,waves=raw['waves'],variant='hyle',ids=ids,re=re)
            exec(code,namespace)
            observation=namespace['observation']
            assert all(math.isfinite(v) and v>0 for v in observation['metrics'].values())
            save(folder/'observation.json',observation)
            if entry['memory_only']:
                mem=read(folder/'memory-summary.json')
                assert mem['setup_error'] is None and mem['thread_error'] is None
                memory[arm]=mem
            runs.append(dict(arm=arm,mode=entry['mode'],index=entry['index'],folder=str(folder),
                process=process,metrics=observation['metrics'],complete_nontime_differences=0,ID_differences=0))
            save(W/'runs.json',runs)
            save(W/'run-state.json',dict(status='RUNNING',completed=len(runs),planned=8))
            print('PAGED_REFRAME_END',entry['mode'],entry['index'],arm,observation['metrics'],flush=True)
        metrics={a:{k:h.stats([x['metrics'][k] for x in runs if x['arm']==a and x['mode']=='timing']) for k in runs[0]['metrics']} for a in ('control','candidate')}
        comparisons={k:dict(candidate_relative_to_control_percent=(metrics['candidate'][k]['median']/metrics['control'][k]['median']-1)*100,
            ranges_overlap=not(metrics['candidate'][k]['min']>metrics['control'][k]['max'] or metrics['control'][k]['min']>metrics['candidate'][k]['max'])) for k in runs[0]['metrics']}
        assert len(runs)==8 and set(memory)=={'control','candidate'}
        summary=dict(status='COMPLETE_8_FULL_NON_TIME_AND_198IDS_EQUAL',runs=runs,metrics=metrics,
            comparisons=comparisons,memory=memory,process_count=8,unmonitored_timing=6,independent_memory=2,
            complete_nontime_differences=0,ID_differences=0,old_samples_pooled=False,
            extra_behavior_or_warmup_processes=0,limits=plan['scopes'])
        save(W/'summary.json',summary)
        save(W/'run-state.json',dict(status=summary['status'],completed=8,planned=8))
    except BaseException as error:
        save(W/'run-state.json',dict(status='STOPPED_FAILED_NO_REFILL',completed=len(runs),planned=8,
            failed_entry=entry,error=repr(error),traceback=traceback.format_exc(),remaining_not_run=plan['commands'][len(runs)+1:]))
        raise
    finally:
        h.gpu_snapshot(W,'window-after')
    print('PAGED_REFRAME_TERMINAL COMPLETE_8 GPU_RELEASED',flush=True)


if __name__=='__main__':
    if sys.argv[1:]==['prepare']:
        prepare()
    elif sys.argv[1:]==['run']:
        run()
    else:
        raise SystemExit('Usage: python -B '+str(__file__)+' prepare | run')
