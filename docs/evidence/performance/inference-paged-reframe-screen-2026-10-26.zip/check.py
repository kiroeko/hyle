"""Explicit finite CPU contract check: one test TU, cached Arena OBJ, eight tests."""
from pathlib import Path
import importlib.util
import json
import os
import sys
import xml.etree.ElementTree as ET

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = W.parents[1]
C = R / '.scratch/inference-result-publication-screen-20261026/cpu-contract1'
F = W / 'cpu-contract3'
SOURCE = R / 'tests/compute_batch/paged_arena_test.cc'
RESOURCE = W / 'candidate/compile/unit.obj'
OLD_RESOURCE = R / '.scratch/inference-f32-append-20261025/cpu1/compile/cpu-arena/unit.obj'
OLD_TEST = C / 'compile/unit.obj'
EXPECTED = {
    'PagedArena.ReframeComposesHistoriesAndRetainsOnlyItsExactPagePermissions',
    'PagedArena.ReframeCannotExpandASourcesLogicalPrefixThroughItsWholePageGuard',
    'PagedArena.ReframeSingleSourceProjectsARequestWithIndependentCanonicalGuards',
    'PagedArena.ReframeSingleSourceCombinesLogicalAuthorityAcrossRequestsWhenNeeded',
    'PagedArena.ReframeKeepsOldAppendablePrefixBoundedAfterTheFrontierAdvances',
    'PagedArena.ReframeRejectsInvalidForeignAndMissingSourcesWithoutChangingSnapshots',
    'PagedArena.ReframeEmptyTargetPinsNoPageAndStillValidatesEverySuppliedSource',
    'PagedArena.ReframeMetadataFailureLeavesSourcesReadyForRetry',
}

spec = importlib.util.spec_from_file_location('paged_reframe_host_tools',
    R / '.scratch/inference-synchronous-step-report-20261025/check_host.py')
h = importlib.util.module_from_spec(spec)
spec.loader.exec_module(h)


def read(p):
    return json.loads(Path(p).read_text(encoding='utf-8-sig'))


def pin(p):
    return h.pin(Path(p))


def key(p):
    return os.path.normcase(os.path.normpath(str(p)))


def exact(row):
    assert pin(row['path']) == row, row['path']


def environment(compiler):
    return h.discover_environment(compiler='msvc', cache={
        'CMAKE_C_COMPILER': compiler, 'CMAKE_CXX_COMPILER': compiler,
        'CMAKE_GENERATOR': 'Ninja'}, backends=()).env


def build():
    assert not F.exists(), 'Preserve prior attempts; do not overwrite a failure'
    correction = read(R / '.scratch/inference-b2-reframe-single-source-20261026/test-correction2/receipt.json')
    exact(correction['prior_correction'])
    exact(correction['original_handoff'])
    handoff = read(correction['original_handoff']['path'])
    for row in handoff['sources']:
        if row['product_path'] == 'src/compute_batch/paged_arena.cc':
            exact(row['current'])
        else:
            exact(row['frozen'])
    exact(correction['corrected_current_test'])
    exact(correction['corrected_frozen_test'])
    exact(correction['runner'])
    assert read(W / 'candidate/compile/process.json')['exit'] == 0
    source_pin, resource_pin = pin(SOURCE), pin(RESOURCE)
    assert source_pin == correction['corrected_current_test']
    old = read(C / 'compile/command.json')['command']
    old_source = str(R / 'tests/graph/invocation_unbind_test.cc')
    command = []
    for arg in old:
        if key(arg) == key(old_source):
            arg = str(SOURCE)
        elif key(arg) == key(C / 'compile/dependencies.json'):
            arg = str(F / 'compile/dependencies.json')
        elif arg.startswith('/Fo'):
            arg = '/Fo' + str(F / 'compile/unit.obj')
        elif arg.startswith('/Fd'):
            arg = '/Fd' + str(F / 'compile/unit.pdb')
        command.append(arg)
    command.insert(1, '/I' + str(R / 'tests/compute_batch'))
    assert '/W4' in command and '/WX' in command
    assert sum(key(a) == key(SOURCE) for a in command) == 1
    cached = read(C / 'link-inputs.json')
    replacements = {key(OLD_RESOURCE): resource_pin['path'],
                    key(OLD_TEST): str(F / 'compile/unit.obj')}
    for row in cached:
        # Replaced inputs may have been cleaned; verify only retained objects.
        if key(row['path']) not in replacements:
            exact(row)
    for path in replacements:
        assert sum(key(row['path']) == path for row in cached) == 1, path
    h.save(F / 'plan.json', dict(status='PREPARED_NOT_RUN', source=source_pin,
        resource_object=resource_pin, cached_inputs=cached,
        test_correction=pin(R / '.scratch/inference-b2-reframe-single-source-20261026/test-correction2/receipt.json'),
        original_handoff=correction['original_handoff'],
        recipes=[pin(C / 'compile/command.json'), pin(C / 'link/command.json')],
        scope='1 test TU + 1 link + 8 CPU tests; reuse new Arena OBJ and retained cached resources flag; no model/SDK/device build'))
    env = environment(command[0])
    compiled = h.execute(command, env, F / 'compile', timeout=120)
    deps = read(F / 'compile/dependencies.json')['Data']
    h.save(F / 'compile/actual-dependencies.json',
        [pin(p) for p in dict.fromkeys([deps['Source'], *deps['Includes']])])
    exact(source_pin)
    exact(resource_pin)
    link, seen = [], []
    for arg in read(C / 'link/command.json')['command']:
        if arg.upper().startswith(('/OUT:', '/MAP:', '/PDB:', '/IMPLIB:')):
            continue
        if key(arg) in replacements:
            seen.append(key(arg))
            arg = replacements[key(arg)]
        link.append(arg)
    assert len(seen) == 2 and set(seen) == set(replacements)
    image = F / 'link/contracts.exe'
    link += ['/OUT:' + str(image), '/MAP:' + str(image.with_suffix('.map')),
             '/IMPLIB:' + str(image.with_suffix('.lib'))]
    linked = h.execute(link, env, F / 'link', timeout=120)
    h.save(F / 'link-inputs.json', [pin(a) for a in link[1:]
        if Path(a).is_absolute() and Path(a).suffix.lower() in {'.obj', '.lib'}])
    runtime = read(C / 'runtime.json')
    exact(runtime['native'])
    alias = image.parent / Path(runtime['native_hardlink']['path']).name
    os.link(runtime['native']['path'], alias)
    runtime['native_hardlink'] = pin(alias)
    h.save(F / 'runtime.json', runtime)
    h.save(F / 'ready.json', dict(status='BUILT_NOT_RUN', image=pin(image),
        source=source_pin, resource_object=resource_pin, compile=compiled, link=linked,
        test_correction=pin(R / '.scratch/inference-b2-reframe-single-source-20261026/test-correction2/receipt.json'),
        original_handoff=correction['original_handoff'],
        link_inputs=pin(F / 'link-inputs.json'), runtime=pin(F / 'runtime.json'),
        actual_dependencies=pin(F / 'compile/actual-dependencies.json'),
        expected_tests=sorted(EXPECTED), model_runs=0, SDK_builds=0))


def run():
    ready = read(F / 'ready.json')
    for field in ('image', 'resource_object', 'source', 'runtime', 'link_inputs',
                  'test_correction', 'original_handoff'):
        exact(ready[field])
    assert not (F / 'run').exists(), 'No automatic retry'
    runtime = read(F / 'runtime.json')
    exact(runtime['native_hardlink'])
    env = environment(read(F / 'compile/command.json')['command'][0])
    env['PATH'] = str(Path(ready['image']['path']).parent) + os.pathsep + runtime['PATH']
    env.update(HF_HUB_OFFLINE='1', TRANSFORMERS_OFFLINE='1')
    out = F / 'run'
    process = h.execute([ready['image']['path'],
        '--gtest_filter=PagedArena.Reframe*',
        '--gtest_output=xml:' + str(out / 'results.xml')], env, out, timeout=120)
    xml = ET.parse(out / 'results.xml').getroot()
    cases = list(xml.iter('testcase'))
    names = {case.attrib['classname'] + '.' + case.attrib['name'] for case in cases}
    counts = {k: int(xml.attrib.get(k, 0)) for k in ('tests', 'failures', 'errors')}
    counts['skipped'] = sum(case.find('skipped') is not None for case in cases)
    h.save(F / 'summary.json', dict(status='RECORDED_REQUIRES_COUNTS', process=process,
        counts=counts, names=sorted(names), ready=pin(F / 'ready.json'),
        model_runs=0, GPU_runs=0, full_graph_suite_run=False))
    assert names == EXPECTED, names
    assert counts == dict(tests=8, failures=0, errors=0, skipped=0), counts
    summary = read(F / 'summary.json')
    summary['status'] = 'PASS_8_CPU_REFRAME_TESTS'
    h.save(F / 'summary.json', summary)
    print(json.dumps(summary, indent=2))


if __name__ == '__main__':
    if sys.argv[1:] not in (['build'], ['run'], ['all']):
        raise SystemExit('Usage: python -B check.py build|run|all')
    if sys.argv[1] in ('build', 'all'):
        build()
    if sys.argv[1] in ('run', 'all'):
        run()
