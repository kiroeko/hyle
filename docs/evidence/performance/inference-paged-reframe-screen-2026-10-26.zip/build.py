"""Explicit build: one current PagedArena TU into the retained f36 consumer."""
from pathlib import Path
import importlib.util
import os
import shutil
import sys

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = W.parents[1]
B = R / '.scratch/inference-result-publication-screen-20261026/candidate'
O = R / '.scratch/inference-f32-append-20261025/cpu1'
C = O / 'compile/cpu-arena'
F = W / 'candidate'
SOURCE = R / 'src/compute_batch/paged_arena.cc'
spec = importlib.util.spec_from_file_location('host_tools', R / '.scratch/inference-synchronous-step-report-20261025/check_host.py')
h = importlib.util.module_from_spec(spec)
spec.loader.exec_module(h)


def read(path):
    import json
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def key(path):
    return os.path.normcase(os.path.normpath(str(path)))


def pin(path):
    return h.pin(Path(path))


if sys.argv[1:] != ['build']:
    raise SystemExit('Usage: python -B build.py build')
assert not F.exists(), 'Do not overwrite prior builds'
before_deps = read(C / 'actual-dependencies.json')
for row in before_deps:
    path = Path(row['path'])
    mapped = R / path.relative_to(O / 'source') if path.is_relative_to(O / 'source') else path
    if key(mapped) == key(SOURCE):
        continue
    actual = pin(mapped)
    assert (actual['bytes'], actual['sha256']) == (row['bytes'], row['sha256']), str(mapped)
baseline = read(B / 'ready.json')
inputs = read(baseline['link_inputs']['path'])
old_object = C / 'unit.obj'
assert sum(key(row['path']) == key(old_object) for row in inputs) == 1
for row in inputs:
    assert pin(row['path']) == row
(F / 'source').mkdir(parents=True)
snapshot = F / 'source/paged_arena.cc'
shutil.copyfile(SOURCE, snapshot)
h.save(F / 'source-pins.json', dict(original=before_deps[0], candidate=pin(snapshot), canonical=pin(SOURCE)))
command = []
for arg in read(C / 'command.json')['command']:
    if key(arg) == key(O / 'source/src/compute_batch/paged_arena.cc'):
        arg = str(snapshot)
    elif key(arg) == key(C / 'dependencies.json'):
        arg = str(F / 'compile/dependencies.json')
    elif arg.startswith('/Fo'):
        arg = '/Fo' + str(F / 'compile/unit.obj')
    elif arg.startswith('/Fd'):
        arg = '/Fd' + str(F / 'compile/unit.pdb')
    else:
        arg = arg.replace(str(O / 'source'), str(R))
    command.append(arg)
assert command.count(str(snapshot)) == 1
compiler = command[0]
env = h.discover_environment(compiler='msvc', cache={
    'CMAKE_C_COMPILER': compiler, 'CMAKE_CXX_COMPILER': compiler, 'CMAKE_GENERATOR': 'Ninja'}, backends=()).env
compiled = h.execute(command, env, F / 'compile', timeout=120)
deps = read(F / 'compile/dependencies.json')['Data']
actual = [pin(path) for path in dict.fromkeys([deps['Source'], *deps['Includes']])]
h.save(F / 'compile/actual-dependencies.json', actual)
original = {}
for row in before_deps:
    path = Path(row['path'])
    mapped = R / path.relative_to(O / 'source') if path.is_relative_to(O / 'source') else path
    original[key(mapped)] = row
new = {key(SOURCE) if key(row['path']) == key(snapshot) else key(row['path']): row for row in actual}
assert set(original) == set(new)
changed = [path for path in original if (original[path]['bytes'], original[path]['sha256']) != (new[path]['bytes'], new[path]['sha256'])]
assert changed == [key(SOURCE)], changed
obj = pin(F / 'compile/unit.obj')
new_inputs = [obj if key(row['path']) == key(old_object) else row for row in inputs]
link = []
for arg in read(B / 'link/command.json')['command']:
    if key(arg) == key(old_object):
        arg = obj['path']
    elif arg.upper().startswith('/OUT:'):
        arg = '/OUT:' + str(F / 'link/hyle.exe')
    elif arg.upper().startswith('/PDB:'):
        arg = '/PDB:' + str(F / 'link/hyle.pdb')
    elif arg.upper().startswith('/IMPLIB:'):
        arg = '/IMPLIB:' + str(F / 'link/hyle.lib')
    link.append(arg)
linked = h.execute(link, env, F / 'link', timeout=120)
h.save(F / 'link-inputs.json', new_inputs)
runtime = read(baseline['runtime']['path'])
assert pin(runtime['native']['path']) == runtime['native']
alias = F / 'link' / Path(runtime['native']['path']).name
os.link(runtime['native']['path'], alias)
runtime['native_hardlink'] = pin(alias)
h.save(F / 'runtime.json', runtime)
h.save(F / 'ready.json', dict(status='PAGED_REFRAME_BUILT_NOT_RUN', image=pin(F / 'link/hyle.exe'), app=obj,
    source=pin(snapshot), source_pins=pin(F / 'source-pins.json'),
    actual_dependencies=pin(F / 'compile/actual-dependencies.json'), runtime=pin(F / 'runtime.json'),
    link_inputs=pin(F / 'link-inputs.json'), compile=compiled, link=linked,
    baseline_ready=pin(B / 'ready.json'), changed_source_only=changed, unchanged_absolute_inputs=len(inputs)-1,
    new_host_TUs=1, SDK_or_device_builds=0, model_runs=0))
print('PAGED_REFRAME_READY', pin(F / 'ready.json'), flush=True)
