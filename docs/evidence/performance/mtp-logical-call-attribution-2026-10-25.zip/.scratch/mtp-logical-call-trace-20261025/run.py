from pathlib import Path
import importlib.util,sys,os,json,datetime
R=Path.cwd();W=Path(__file__).resolve().parent;arm=sys.argv[1];assert arm in ['hyle','peer']
spec=importlib.util.spec_from_file_location('retained',R/'.scratch/mtp-extraction-regression-20261024/check.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
plan=b.read(W/'plan.json');record=next(x for x in plan['commands']if x['arm']==arm);ready=b.read(W/arm/'ready.json')
assert b.pin(Path(ready['image']['path']))==ready['image']
for pin in ready['source_pins']:assert b.pin(Path(pin['path']))==pin
runtime=Path(record['runtime']['path']);assert b.pin(runtime)['sha256']==record['runtime']['sha256']
env=os.environ.copy();env['PATH']=str(W/arm/'link')+';'+b.read(runtime)['PATH'];env['HF_HUB_OFFLINE']='1';env['TRANSFORMERS_OFFLINE']='1'
b.save(W/arm/'run-start.json',dict(start_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),image=ready['image'],plan=b.pin(W/'plan.json'),scope='Single profile-only process, notTPS'))
b.execute(record['command'],Path(record['run_dir']),env,record['timeout_seconds'])
