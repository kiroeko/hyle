from pathlib import Path
import hashlib,json,shutil,subprocess,difflib
R=Path.cwd();W=Path(__file__).resolve().parent
F=W/'hyle';F.mkdir(exist_ok=False);shutil.copytree(R/'.scratch/inference-prepare-scratch-20261025/candidate/source',F/'source')
def pin(p):return dict(path=str(p.relative_to(R)),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def patch(s,a,b):
 assert s.count(a)==1,(a,s.count(a));return s.replace(a,b)
header=r'''#pragma once
#include <nvtx3/nvToolsExt.h>
#include <cstddef>
#include <cstdio>
#include <cstdint>
namespace logical_trace {
inline nvtxDomainHandle_t domain=nullptr;
inline unsigned long long sequence=0,finished_ranges=0,overlapping_episodes=0;
inline void initialize() noexcept { domain=nvtxDomainCreateA("HyleLogicalCalls"); }
class Range final {
 nvtxRangeId_t id_=0; bool active_=false;
 public:
 Range() noexcept=default;
 explicit Range(const char *text,unsigned long long payload=0) noexcept {start(text,payload);}
 Range(const Range &)=delete;Range &operator=(const Range &)=delete;
 ~Range(){finish();}
 void start(const char *text,unsigned long long payload=0) noexcept {
  if(active_){++overlapping_episodes;finish();}
  nvtxEventAttributes_t event{};event.version=NVTX_VERSION;event.size=NVTX_EVENT_ATTRIB_STRUCT_SIZE;
  event.messageType=NVTX_MESSAGE_TYPE_ASCII;event.message.ascii=text;
  event.payloadType=NVTX_PAYLOAD_TYPE_UNSIGNED_INT64;event.payload.ullValue=payload;
  id_=nvtxDomainRangeStartEx(domain,&event);active_=true;
 }
 void finish() noexcept {if(active_){nvtxDomainRangeEnd(domain,id_);active_=false;++finished_ranges;}}
};
inline Range episode;
inline char episode_text[256]{};
inline void hyle_begin(unsigned role,std::size_t target_rows,std::size_t draft_rows,std::size_t width,std::size_t context,std::size_t frontier,std::size_t lag) noexcept {
 ++sequence;std::snprintf(episode_text,sizeof(episode_text),"hyle/episode seq=%llu role=%u target_T=%zu draft_T=%zu R=%zu context=%zu frontier=%zu lag=%zu",sequence,role,target_rows,draft_rows,width,context,frontier,lag);episode.start(episode_text,sequence);
}
inline void dump() noexcept { std::fprintf(stderr,"LOGICAL_NVTX sequence=%llu completed_ranges=%llu overlapping_episodes=%llu\n",sequence,finished_ranges,overlapping_episodes); }
}
'''
(W/'logical_trace.h').write_text(header,encoding='utf8')
p=F/'source/engine/models/qwen35/main.cc';before=p.read_text();s=before
s=patch(s,'    const auto step_start = Clock::now();',
'''    const auto &trace_head = *requests.front().session->head;
    logical_trace::hyle_begin(static_cast<unsigned>(role), tokens,
        has_mtp(role) ? (is_mtp_prefill(role) ? tokens + draft_lag(role) : draft_lag(role) + 1) : 0,
        requests.size(), trace_head.length, trace_head.draft ? trace_head.draft->frontier : 0,
        trace_head.draft ? trace_head.draft->lag : 0);
    logical_trace::Range trace_prepare("hyle/prepare", logical_trace::sequence);
    const auto step_start = Clock::now();''')
s=patch(s,'      check(run.prepare_replay(queues, {.mode = phase.replay_modes[slot], .host_wait = g::HostWaitPolicy::kAllow}));',
'''      {
        logical_trace::Range trace_replay("hyle/prepare_replay", logical_trace::sequence);
        check(run.prepare_replay(queues, {.mode = phase.replay_modes[slot], .host_wait = g::HostWaitPolicy::kAllow}));
      }''')
s=patch(s,'  void submit_evaluations() {','''  void submit_evaluations() {
    logical_trace::Range trace_submit("hyle/submit", logical_trace::sequence);''')
s=patch(s,'    const auto step_start = step.step_start, start = step.start;',
'''    logical_trace::Range trace_wait("hyle/wait_publish", logical_trace::sequence);
    const auto step_start = step.step_start, start = step.start;''')
s=patch(s,'    const auto finished = Clock::now();','''    const auto finished = Clock::now();
    trace_wait.finish(); logical_trace::episode.finish();''')
p.write_text(s,encoding='utf8');(F/'source.patch').write_text(''.join(difflib.unified_diff(before.splitlines(True),s.splitlines(True),fromfile='625f1a/main.cc',tofile='nvtx/main.cc')),encoding='utf8')
(F/'consumer.cc').write_text('#include "../logical_trace.h"\n#include "source/engine/models/qwen35/main.cc"\nint main(int argc,char **argv){logical_trace::initialize();const int code=qwen35::run(argc,argv);logical_trace::episode.finish();logical_trace::dump();return code;}\n',encoding='utf8')
P=W/'source';P.mkdir(exist_ok=False)
deps=json.loads((R/'.scratch/qwen-mtp-final-window-20261024/compile1/peer/identity.json').read_text())['dependencies']
for name in ['mtp_schedule.h','session_schedule.h','schedule.h']:
 blob=subprocess.run(['git','show','908ad39d0:tools/qwen35_text/'+name],check=True,capture_output=True).stdout
 expected=next(x for x in deps if x['path'].endswith('\\'+name));assert hashlib.sha256(blob).hexdigest()==expected['sha256'];(P/name).write_bytes(blob)
peer=R/'.scratch/qwen-mtp-final-window-20261024/source/peer_multiturn.cc';before=peer.read_text();s=before
s=patch(s,'#include "../../../tools/qwen35_text/mtp_schedule.h"','#include "mtp_schedule.h"')
s=patch(s,'namespace peer_mtp {','#include "../logical_trace.h"\n\nnamespace peer_mtp {')
s=patch(s,'Json decode(llama_context * context, Batch & batch) {',
'''Json decode(llama_context * context, Batch & batch, const char *role, std::size_t target_context, std::size_t draft_frontier, std::size_t turn) {
    const auto trace_sequence = ++logical_trace::sequence;
    char trace_text[256]{};
    std::snprintf(trace_text, sizeof(trace_text), "peer/%s seq=%llu T=%d context=%zu frontier=%zu turn=%zu", role, trace_sequence, batch.value.n_tokens, target_context, draft_frontier, turn);
    logical_trace::Range trace_call(trace_text, trace_sequence);''')
s=patch(s,'    llama_synchronize(context); const auto retired = Clock::now();','''    llama_synchronize(context); const auto retired = Clock::now();
    trace_call.finish();''')
s=patch(s,'auto turn_target_prefill = decode(target.get(), target_batch);','auto turn_target_prefill = decode(target.get(), target_batch, "target_prefill", length, frontier, turn_index + 1);')
s=patch(s,'turn_draft_prefill = decode(draft.get(), *draft_batch);','turn_draft_prefill = decode(draft.get(), *draft_batch, "draft_prefill", length, frontier, turn_index + 1);')
s=patch(s,'dft = decode(draft.get(), *draft_batch);','dft = decode(draft.get(), *draft_batch, "draft_decode", length, frontier, turn_index + 1);')
s=patch(s,'auto tgt = decode(target.get(), target_batch);','auto tgt = decode(target.get(), target_batch, "target_decode", length, frontier, turn_index + 1);')
s=patch(s,'int main(int argc, char ** argv) {','int main(int argc, char ** argv) {\n    logical_trace::initialize();')
s=patch(s,'        std::cout << text; return 0;','        std::cout << text; logical_trace::dump(); return 0;')
(P/'peer_multiturn.cc').write_text(s,encoding='utf8');(W/'peer.patch').write_text(''.join(difflib.unified_diff(before.splitlines(True),s.splitlines(True),fromfile='fixed-peer/peer_multiturn.cc',tofile='nvtx/peer_multiturn.cc')),encoding='utf8')
pins=[pin(x)for x in W.rglob('*')if x.is_file()and x.suffix in ['.cc','.h','.patch']]
(W/'source-pins.json').write_text(json.dumps(pins,indent=2)+'\n');print('prepared',len(pins),'small source/pins')
