from pathlib import Path
import json,hashlib,zipfile,sqlite3,datetime
R=Path.cwd();W=Path(__file__).resolve().parent;P=R/'docs/evidence/performance/mtp-logical-call-attribution-2026-10-25'
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def pin(p):return dict(path=p.relative_to(R).as_posix(),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
analysis=read(W/'analysis.json');actions=read(W/'capture-action-summary.json')
assert all(v['source_work_equal']for v in analysis['arms'].values());assert all(v['NVTX']['missing_ends']==0 for v in analysis['arms'].values())
warnings={}
for arm in ['hyle','peer']:
 c=sqlite3.connect('file:'+(W/arm/'trace1/trace.sqlite').as_posix()+'?mode=ro',uri=True)
 warnings[arm]=[dict(severity=v[0],text=v[1],count=v[2])for v in c.execute('SELECT severity,text,COUNT(*) FROM DIAGNOSTIC_EVENT GROUP BY severity,text ORDER BY severity DESC,text')];c.close()
 (W/arm/'diagnostics.json').write_text(json.dumps(warnings[arm],indent=2)+'\n')
cleanup=[pin(p)for arm in ['hyle','peer']for d in ['compile','link']for p in (W/arm/d).glob('*')if p.is_file()and p.suffix.lower()in['.obj','.exe','.exp','.lib','.dll','.pdb','.map']]
(W/'cleanup-candidates.json').write_text(json.dumps(dict(files=cleanup,count=len(cleanup),logical_bytes=sum(x['bytes']for x in cleanup),scope='Onlythisbatchrebuildableprivatebinaries,nosource/model/SDK/dependencies;NODELETION'),indent=2)+'\n')
before_failures=dict(scope='Offlinehelper failuresonly,norecaptureorrebuild',issues=['InitialanalysisreadpeerNVTXcapturedstdout,whichNsighttruncated;correctedtoalreadywrittencompletepeerconsumer-result.json.','Initialworkcomparisonleftoriginalphase_points.unix_ms;onlythesetimekeys differed. Excludedthatknownwallclockfield,allnon-timefieldsthenexact.','Aone-lineshellSQLiteinspectionhadPowerShellquotingerror;replacedwithprivateinspect.py.'],actual_compile_or_model_failures=0,actual_model_processes=2)
(W/'analysis-setup-notes.json').write_text(json.dumps(before_failures,indent=2)+'\n')
summary=dict(status='LOGICAL_CALL_DIAGNOSTIC_COMPLETE_WORK_PRESERVED',created_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),scope='HyleandpeerK1real2turnMTPonly,oneNVTX+CUDAprofilerprocessperarm;notTPS,numericalqualityormemorycertification.',throughput_evidence=False,quality_evidence=False,product_edits=0,SDK_builds=0,HTTP=0,actual_processes=2,GPU_released=True,source_pins=read(W/'source-pins.json'),plan=pin(W/'plan.json'),builds={a:dict(compile=read(W/a/'compile/process.json'),link=read(W/a/'link/process.json'),ready=read(W/a/'ready.json'))for a in ['hyle','peer']},analysis=analysis,capture_actions=actions,diagnostic_warnings=warnings,key_finding=dict(hyle_decode_prepare_replay_total_ms=107.036554,hyle_decode_replay_GPU_activity_union_ms=0,instantiate_episodes=dict(count=13,replay_cpu_ms=78.248896),record_without_instantiate_episodes=dict(count=8,replay_cpu_ms=16.324447),no_record_episodes=dict(count=45,replay_cpu_ms=12.463211),meaning='Sameprofilephaseactualcost,notrecoverablewallpromise. Replayischildofprepare;APIisnestedandmayoverlap. Donotaddparent/child/APIorcompareprofilesecondsasformalTPS.'),next_evidence_boundary='13actualHyleupdatesreturnedcudaSuccesswithnosamecapturefallback. 19instantiationshadnoUpdateattempt. Firstreviewseedqualification/firstartifactandfixedslot0rangeidentity;donotassumeUpdatefailure,increasethevariantcache,orblameoldclosedfingerprint/reverse-hiddenclues.',cleanup=read(W/'cleanup-candidates.json'),first_failures=before_failures)
(W/'proof-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
files=[p for p in W.rglob('*')if p.is_file()and p.suffix.lower()in['.py','.cc','.h','.patch','.json','.log','.sqlite','.nsys-rep']and'__pycache__'not in p.parts and p.name!='publication.json']
archive=P.with_suffix('.zip')
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=6)as z:
 for f in files:z.write(f,f.relative_to(R).as_posix())
with zipfile.ZipFile(archive)as z:assert z.testzip()is None
summary['archive']={**pin(archive), 'entries':len(files),'CRC_pass':True,'binaries_included':False,'weights_or_SDK_included':False}
P.with_suffix('.json').write_text(json.dumps(summary,indent=2)+'\n')
publication=dict(public=pin(P.with_suffix('.json')),archive=pin(archive),entries=len(files),cleanup_count=len(cleanup),cleanup_logical_bytes=sum(x['bytes']for x in cleanup))
(W/'publication.json').write_text(json.dumps(publication,indent=2)+'\n');print(json.dumps(publication))
