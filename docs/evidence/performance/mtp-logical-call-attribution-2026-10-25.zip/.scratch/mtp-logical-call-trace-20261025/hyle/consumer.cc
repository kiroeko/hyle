#include "../logical_trace.h"
#include "source/engine/models/qwen35/main.cc"
int main(int argc,char **argv){logical_trace::initialize();const int code=qwen35::run(argc,argv);logical_trace::episode.finish();logical_trace::dump();return code;}
