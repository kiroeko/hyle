from pathlib import Path
import sqlite3,json
W=Path(__file__).resolve().parent
for arm in ['hyle','peer']:
 p=W/arm/'trace1/trace.sqlite';c=sqlite3.connect('file:'+p.as_posix()+'?mode=ro',uri=True);c.row_factory=sqlite3.Row
 tables=[x[0]for x in c.execute("SELECT name FROM sqlite_master WHERE type='table'")]
 print(arm,'tables',[t for t in tables if any(k in t for k in ['NVTX','RUNTIME','DRIVER'])])
 for table in ['NVTX_EVENTS','CUPTI_ACTIVITY_KIND_RUNTIME','CUPTI_ACTIVITY_KIND_KERNEL']:
  print(table,'schema',[tuple(x)for x in c.execute('PRAGMA table_info('+table+')')]);print('rows',c.execute('SELECT COUNT(*) FROM '+table).fetchone()[0])
  if table=='NVTX_EVENTS':print('sample',[dict(x)for x in c.execute('SELECT * FROM NVTX_EVENTS LIMIT10'.replace('LIMIT10','LIMIT 10'))])
 c.close()
