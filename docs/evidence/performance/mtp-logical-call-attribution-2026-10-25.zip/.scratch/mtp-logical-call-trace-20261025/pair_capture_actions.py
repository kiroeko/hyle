from pathlib import Path
from collections import Counter
import sqlite3,json
W=Path(__file__).resolve().parent;out=dict(scope='Only same NVTXlogicalcall, same globalTid and ordered actual runtime APIs. Each StreamEndCapture is followed until next StreamBeginCapture or endoflogicalcall. No capturegraph pointer/originallineage or devicefunction identity inferred.',arms={})
for arm in ['hyle','peer']:
 records=json.loads((W/arm/'logical-records.json').read_text());c=sqlite3.connect('file:'+(W/arm/'trace1/trace.sqlite').as_posix()+'?mode=ro',uri=True);c.row_factory=sqlite3.Row
 apis=[dict(r)for r in c.execute('SELECT r.start,r.end,r.globalTid,r.correlationId,r.returnValue,s.value AS api FROM CUPTI_ACTIVITY_KIND_RUNTIME r JOIN StringIds s ON s.id=r.nameId WHERE s.value LIKE \'%Capture%\' OR s.value LIKE \'%GraphExecUpdate%\' OR s.value LIKE \'%GraphInstantiate%\' ORDER BY r.start')]
 actions=[]
 for root in records:
  rows=[v for v in apis if v['globalTid']==root['globalTid']and root['start_ns']<=v['start']and v['end']<=root['end_ns']]
  current=None
  for row in rows:
   if 'StreamBeginCapture'in row['api']:
    if current:actions.append(current)
    current=dict(logical_label=root['label'],meta=root['meta'],begin=row,events=[])
   elif current:
    if 'StreamEndCapture'in row['api']:current['end_capture']=row
    elif any(t in row['api']for t in ['GraphExecUpdate','GraphInstantiate']):current['events'].append(row)
  if current:actions.append(current)
 for action in actions:
  updates=[v for v in action['events']if'GraphExecUpdate'in v['api']];inst=[v for v in action['events']if'GraphInstantiate'in v['api']]
  action['classification']='update_and_instantiate'if updates and inst else'update_only'if updates else'instantiate_no_update_attempt'if inst else'unknown_no_action'
  action['ordered_actions']=['update'if'GraphExecUpdate'in v['api']else'instantiate'for v in action['events']]
 result=dict(capture_records=len(actions),classes=dict(Counter(x['classification']for x in actions)),ordered_action_counts=dict(Counter('->'.join(x['ordered_actions'])for x in actions)),update_returns=dict(Counter(str(v['returnValue'])for x in actions for v in x['events']if'GraphExecUpdate'in v['api'])),actions=actions,unobserved_output_fields=['cudaGraphExecUpdateResultInfo.result','errorNode','errorFromNode','capture graph handle','graph node kind/function address'])
 (W/arm/'capture-actions.json').write_text(json.dumps(result,indent=2)+'\n');out['arms'][arm]={k:v for k,v in result.items()if k!='actions'};c.close()
out['interpretation']='All observed Update returns0 mean cudaSuccess per installed CUDA13.3cuda_runtime_api.h:12891. All13Hyle updates have noInstantiatefallback before nextcapture/endlogicalcall. Thus19Hyleinstantiate calls were19capture records with NO Update attempt, not19 observed structural Update failures. Native result/errornodes not directly captured; exact seedeligibility/firstartifact identity remains for source/probe review.'
(W/'capture-action-summary.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
