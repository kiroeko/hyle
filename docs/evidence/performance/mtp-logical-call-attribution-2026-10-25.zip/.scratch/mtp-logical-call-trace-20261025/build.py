from pathlib import Path
import importlib.util,json,os,sys,hashlib,subprocess
R=Path.cwd();W=Path(__file__).resolve().parent;arm=sys.argv[1];assert arm in ['hyle','peer']
spec=importlib.util.spec_from_file_location('retained',R/'.scratch/mtp-extraction-regression-20261024/check.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
F=W/arm;F.mkdir(exist_ok=True)
if arm=='hyle':
 old=R/'.scratch/inference-prepare-scratch-20261025/candidate';compile_path=old/'compile/command.json';link_path=old/'link/command.json';old_obj=str(old/'compile/unit.obj');source=W/'hyle/consumer.cc';extra=['/I'+str(W/'hyle/source'),'/I'+str(W/'hyle/source/engine/models/qwen35')]
else:
 old=R/'.scratch/qwen-mtp-final-window-20261024';compile_path=old/'compile1/peer/identity.json';link_path=old/'peer-link1/link-plan.json';old_obj=str(old/'compile1/peer/peer.obj');source=W/'source/peer_multiturn.cc';extra=[]
original=b.args(compile_path);flags=[];skip=False
for a in original[1:]:
 if skip:skip=False;continue
 if a=='/sourceDependencies':skip=True;continue
 if a.lower().startswith(('/fo','/fd'))or a.lower().endswith(('.cc','.cpp')):continue
 if arm=='hyle'and a.lower().startswith('/i')and 'inference-prepare-scratch-20261025' in a.lower():continue
 flags.append(a)
flags=[*extra,'/external:IC:\\Program Files\\NVIDIA GPU Computing Toolkit\\CUDA\\v13.3\\include',*flags]
env=b.environment(original[0]);cmd=[original[0],*flags,str(source),'/sourceDependencies',str(F/'compile/dependencies.json'),'/Fo'+str(F/'compile/unit.obj'),'/Fd'+str(F/'compile/unit.pdb')]
b.save(F/'before-source-pins.json',[b.pin(Path(x['path']))for x in b.read(W/'source-pins.json')])
b.execute(cmd,F/'compile',env,90)
deps=b.read(F/'compile/dependencies.json')['Data'];pins=[]
for n in [deps['Source'],*deps['Includes']]:
 p=Path(n).resolve()
 if p.is_relative_to(R/'engine')or p.is_relative_to(R/'tests')or p.is_relative_to(R/'tools'):raise RuntimeError('Canonical private source leaked '+str(p))
 if p.is_relative_to(R)or'nvtx3'in str(p):pins.append(b.pin(p))
b.save(F/'compile/source-pins.json',pins)
link=b.args(link_path);args=[];replaced=0
for a in link[1:]:
 if a.lower()==old_obj.lower():args.append(str(F/'compile/unit.obj'));replaced+=1
 elif not a.lower().startswith(('/out:','/pdb:','/map:','/implib:')):args.append(a)
assert replaced==1
b.execute([link[0],*args,'/OUT:'+str(F/'link/consumer.exe'),'/IMPLIB:'+str(F/'link/consumer.lib')],F/'link',env,90)
if arm=='hyle':os.link(old/'link/hyle_ggml_cpu_gdn_scale_v3.dll',F/'link/hyle_ggml_cpu_gdn_scale_v3.dll')
for p in pins:assert b.pin(Path(p['path']))==p
b.save(F/'ready.json',dict(image=b.pin(F/'link/consumer.exe'),source=b.pin(source),source_pins=pins,original_compile=b.pin(compile_path),original_link=b.pin(link_path),new_TUs=1,SDK_builds=0,GPU_runs=0,HTTP=0))
print(arm,'BUILT',flush=True)
