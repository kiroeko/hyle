"""Prepare a scratch consumer diagnostic copy; product is never edited."""
from pathlib import Path
import difflib
import hashlib
import json

C = Path(__file__).resolve().parent
R = C.parents[1]
source = R / 'tools/qwen35_text/main.cc'
original = source.read_bytes()
assert hashlib.sha256(original).hexdigest() == 'f2e1c6002042d8ccf08eaed3d2204fe7c459a2e9a37ae74d13c2ff93e3714131'
before_text = original.decode('utf-8-sig').replace('\r\n', '\n')
text = before_text
for old, new in [
    ('#include <algorithm>', '#include "../../capture_probe.h"\n#include <algorithm>'),
    ('int main(int argc, char **argv) {',
     'int main(int argc, char **argv) {\n  struct ProbeFlush { ~ProbeFlush() { hyle_capture_probe::flush(); } } probe_flush;'),
    ('      initialize_slot(phase, slot);\n      std::vector<std::int32_t> packed_ids, positions;',
     '      initialize_slot(phase, slot);\n      hyle_capture_probe::set_context(static_cast<unsigned>(role), width, tokens, slot, phase.preparation_uses[slot], &run);\n      std::vector<std::int32_t> packed_ids, positions;'),
    ('      if (output.trace && !output.trace->empty()) {',
     '      // Scratch diagnostic keeps route metadata only, without tensor payload copies.\n      if (output.trace && !output.trace->empty() && trace_routes.empty()) {'),
]:
    assert text.count(old) == 1, old
    text = text.replace(old, new)
p = C / 'probe/tools/qwen35_text/main.cc'
p.parent.mkdir(parents=True, exist_ok=True)
if p.exists():
    assert hashlib.sha256(p.read_bytes()).hexdigest() == '3a3011b05f800d042c5f053740854a5accc13d47afd7d25a1ca8cf447ffefa4a'
p.write_text(text, encoding='utf-8', newline='')
(C / 'main-probe.diff').write_text(''.join(difflib.unified_diff(before_text.splitlines(True), text.splitlines(True), fromfile='product/tools/qwen35_text/main.cc', tofile=str(p.relative_to(R)))), encoding='utf-8')
record = dict(product_source=str(source), product_bytes=len(original),
              product_sha256=hashlib.sha256(original).hexdigest(),
              scratch_source=str(p), scratch_sha256=hashlib.sha256(p.read_bytes()).hexdigest(),
              changes='Diagnostic header, main-exit flush, context label after original slot initialization, route-only trace without tensor copies; no flags or mathematical/execution policy change.')
(C / 'main-probe.json').write_text(json.dumps(record, indent=2) + '\n', encoding='utf-8')
print(json.dumps(record, indent=2))
