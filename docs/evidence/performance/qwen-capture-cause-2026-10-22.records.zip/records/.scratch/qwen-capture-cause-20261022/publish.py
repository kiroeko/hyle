"""Publish one finite capture-cause diagnostic; no performance window implied."""
from pathlib import Path
from collections import Counter
import hashlib
import json
import zipfile

C = Path(__file__).resolve().parent
R = C.parents[1]
O = R / 'docs/evidence/performance'
NAME = 'qwen-capture-cause-2026-10-22'

def read(p):
    return json.loads(Path(p).read_text(encoding='utf-8-sig'))

def save(p, d):
    Path(p).write_text(json.dumps(d, indent=2, ensure_ascii=False, allow_nan=False) + '\n', encoding='utf-8')

def identity(p):
    p = Path(p)
    h = hashlib.sha256()
    with p.open('rb') as f:
        for data in iter(lambda: f.read(8 << 20), b''):
            h.update(data)
    return dict(path=str(p.resolve()), bytes=p.stat().st_size, sha256=h.hexdigest())

assert not (O / (NAME + '.json')).exists()
assert not (O / (NAME + '.data.zip')).exists()
freeze = read(C / 'probe/core-source-freeze.json')
for before in freeze['before']:
    relative = Path(before['path']).relative_to(Path('.scratch/qwen-capture-cause-20261022/before'))
    current = identity(R / relative)
    assert (current['bytes'], current['sha256']) == (before['bytes'], before['sha256'])
main = read(C / 'main-probe.json')
assert identity(main['product_source'])['sha256'] == main['product_sha256']
ready = read(C / 'qwen-ready-attempt1.json')
assert identity(ready['image']['path']) == ready['image']
assert identity(ready['source']['path']) == ready['source']
link = read(ready['link_plan']['path'])
assert len(link['inputs']) == 195 and link['reused_link_inputs'] == 191
receipts = []
for tag in ['main', 'executable', 'resources', 'region_access']:
    d = C / 'compile1' / tag
    receipt = read(d / 'compile.result.json')
    assert receipt['terminal'] and receipt['exit'] == 0
    compiled = read(d / 'identity.json')
    assert identity(compiled['source']['path']) == compiled['source']
    assert identity(compiled['object']['path']) == compiled['object']
    receipts.append(identity(d / 'compile.result.json'))
assert read(C / 'qwen-link1/link.result.json')['exit'] == 0
actual = read(C / 'diagnostic1/run.result.json')
assert actual['terminal'] and actual['exit'] == 0
control = read(C / 'diagnostic1/finite-control.json')
assert not control['selected_changes'] and control['no_tensor_payloads'] and control['actual_outputs'] == 64
reports = {p.name: read(p) for p in sorted((C / 'review').glob('*.json'))}
assert all(name in reports for name in ['actual-run-review.json', 'actual-cause-review.json', 'next-optimization-design.json'])
lines = (C / 'diagnostic1/run.stderr.log').read_text(encoding='utf-8-sig').splitlines()
losses = [dict(part.split('=', 1) for part in line.split()[1:]) for line in lines if line.startswith('capture_loss ')]
assert len(losses) == 10 and all(x['why'] == 'prepare-binding' for x in losses)
assert all(x['stable'] == '1' and x['native_inputs'] == '0' and x['unproved'] == '0' and x['revision_changed'] == '0' for x in losses)
summary_line = next(line for line in lines if line.startswith('capture_probe_summary '))
assert 'overflow=0' in summary_line and 'pending=0' in summary_line

docs = []
for name in ['docs/developer/current-work.md', 'docs/developer/performance/decode.md']:
    p = R / name
    out = C / 'current' / name
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_bytes(p.read_bytes())
    docs.append(dict(source=identity(p), snapshot=identity(out)))
save(C / 'docs-freeze.json', dict(files=docs))
summary = dict(
    status='Actual first invalidation causes identified; no product execution fix or new speed claim in this diagnostic batch; broad goal remains active',
    date='2026-10-22', ready=ready, docs_freeze=identity(C / 'docs-freeze.json'),
    build_scope=dict(successful_host_compiles=4, host_compile_attempts=4, successful_links=1,
                     input_count=195, reused_inputs=191, SDK_builds=0, NVCC_builds=0, full_configures=0,
                     compile_receipts=receipts),
    actual_model_processes=1, diagnostic_processes=1, performance_processes=0,
    actual_run=identity(C / 'diagnostic1/run.result.json'), finite_control=control,
    losses=losses, diagnostic_summary=summary_line, reports=reports,
    product_code_changed=False,
    findings=[
        'The original P154/64 natural MTP workload completed once with64 actual IDs and selected work fields equal to the frozen AD run. Scratch logging records only metadata and emits after the original workload; tensor payload copies are suppressed.',
        'Ten actual retained capture ranges were erased. All first observed causes were qualified ordinary tensor binding tuple changes with same resource/native allocation but different byte offset, not native-plan callback, unproven identity, Queue replacement or permission-release loss.',
        'Nine first changed ports are MTP prior/carry hidden pool views; one is the layer0 conv history input. Read aliases and candidate output aliases vary with accepted-prefix state selection and ordinary pooled range reuse.',
        'Physical argument changes require invalidation under the original captured-command contract. The same backing allocation is not proof that a different subrange may replay through old pointer arguments.',
        'Each event captures only the first changed port which causes a whole retained range to be erased. It is not an exhaustive diff of every later port or proof all history/state movement was observed.',
        'Existing Graph invalidation and state lifetime contracts remain unchanged. No public diagnostic API, new executor, shadow state copy, unsafe preservation or performance improvement is introduced.',
        'All observed losses occur in decode rounds4..15, followed by complete recorded-range reuse. The7 affected calls have18.1936ms inclusive cold buckets in this instrumented process, not a measurement of invalidation self-time or recoverable performance. The next finite investigation is actual no-recapture MTP steady-state hotspots.',
        'This batch closes the actual first-cause attribution gap for the current AD-shaped workload. Historical W data retains its original scope; matching total counts alone do not retroactively prove those old causes.'],
    limitations=[
        'Only one finite diagnostic process; it supplies causal metadata, not uninstrumented TPS, statistical performance or new full quality evidence.',
        'Existing preparation-diagnostics still rejects MTP; no claim is made that six target BatchPlanReports cover the seventh draft attention. This probe uses first-loss metadata and actual route TSV instead.',
        'Only first losses through the original central per-step invalidator are recorded. Explicit whole-cache teardown/reset paths and fresh slots without retained ranges are outside this event log.',
        'No native allocation delta, removable time or universal pointer-stability optimization is established. State readers/versions and actual native retirement remain mandatory.',
        'Other backend/model/quantization/image and architecture requirements remain unfinished.'],
    previous_evidence=['docs/evidence/performance/qwen-cublas-scores-2026-10-22.json',
                       'docs/evidence/performance/qwen-mtp-divergence-2026-10-22.json'])
save(C / 'actual-summary.json', summary)
excluded = {'.exe', '.dll', '.obj', '.map', '.lib', '.exp', '.pdb', '.pyc', '.tmp'}
names = {'published.json', 'cleanup-plan.json', 'cleanup-result.json', 'cleanup_script.ps1', 'postconditions.json'}
files = sorted(p for p in C.rglob('*') if p.is_file() and p.suffix.lower() not in excluded
               and p.name not in names and not any(x in ('tmp', '__pycache__') for x in p.relative_to(C).parts))
archive = O / (NAME + '.data.zip')
entries, unique = [], {}
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED, compresslevel=6) as z:
    for p in files:
        item = identity(p)
        key = item['bytes'], item['sha256']
        entry = unique.get(key)
        if entry is None:
            entry = p.relative_to(R).as_posix()
            unique[key] = entry
            z.write(p, entry)
        else:
            item['identical_content_alias'] = True
        item['entry'] = entry
        entries.append(item)
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for (size, sha), entry in unique.items():
        data = z.read(entry)
        assert len(data) == size and hashlib.sha256(data).hexdigest() == sha
manifest = O / (NAME + '.json')
save(manifest, dict(**summary, archives=[identity(archive)], archive_files=entries,
                    archive_verified=dict(CRC=True, all_unique_entry_SHA256=True,
                                          source_files=len(entries), unique_entries=len(unique))))
published = dict(manifest=identity(manifest), archives=[identity(archive)])
save(C / 'published.json', published)
print(json.dumps(published, indent=2))
