"""One serial metadata-only capture diagnostic; never a throughput sample."""
from pathlib import Path
import importlib.util
import json
import os
import sys

sys.dont_write_bytecode = True
C = Path(__file__).resolve().parent
R = C.parents[1]
AD = R / '.scratch/qwen-cublas-scores-20261022'
spec = importlib.util.spec_from_file_location('ae_explicit_build', C / 'build.py')
bld = importlib.util.module_from_spec(spec)
spec.loader.exec_module(bld)

def run():
    ready_path = C / 'qwen-ready-attempt1.json'
    ready = bld.c.read(ready_path)
    assert bld.b.identity(ready['image']['path']) == ready['image']
    assert bld.b.identity(ready['runtime_environment']['path']) == ready['runtime_environment']
    prior_result = AD / 'performance/timing/02-after_MTP/result.json'
    prior = bld.c.read(prior_result)
    out = C / 'diagnostic1'
    out.mkdir(parents=True, exist_ok=False)
    command = [ready['image']['path'], *prior['command'][1:],
               '--trace', str(out / 'route-only'), '--trace-level', 'decisions']
    env = os.environ.copy()
    env['PATH'] = bld.c.read(ready['runtime_environment']['path'])['PATH']
    bld.c.save(out / 'plan.json', dict(
        command=command, ready_record=bld.b.identity(ready_path),
        reused_AD_command=bld.b.identity(prior_result),
        diagnostic=True, performance_evidence=False,
        purpose='One original P154/64 natural MTP window, trace routes only, fixed scratch event budget; no tensor payload export or changed execution policy.'))
    bld.c.execute('run', command, env, out)
    parsed = json.loads((out / 'run.stdout.log').read_text(encoding='utf-8-sig').splitlines()[-1])
    bld.c.save(out / 'parsed.json', parsed)
    old = bld.c.read(AD / 'performance/timing/02-after_MTP/observation.json')['raw']
    changed = {k: {'AD': old.get(k), 'probe': parsed.get(k)} for k in (
        'score_dtype', 'score_policy', 'generated_ids', 'visible_tokens',
        'draft_frontier', 'draft_lag', 'actual_graph_calls', 'actual_target_rows',
        'actual_draft_rows', 'draft_rounds', 'accepted_drafts') if old.get(k) != parsed.get(k)}
    raw_files = [str(p) for p in out.rglob('*') if p.suffix in ('.bf16', '.f32', '.bin', '.i32')]
    bld.c.save(out / 'finite-control.json', dict(
        status='same_selected_output_work_fields' if not changed else 'differences_retained',
        selected_changes=changed, no_tensor_payloads=not raw_files,
        unexpected_payload_paths=raw_files,
        actual_outputs=len(parsed.get('generated_ids', [])),
        performance_evidence=False))
    print(json.dumps(dict(exit=0, generated=len(parsed.get('generated_ids', [])),
                         changed_selected_fields=list(changed), payload_files=len(raw_files))))

if __name__ == '__main__':
    run()
