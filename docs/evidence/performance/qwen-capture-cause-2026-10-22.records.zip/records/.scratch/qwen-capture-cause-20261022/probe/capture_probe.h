#pragma once

#include <algorithm>
#include <array>
#include <atomic>
#include <cstdarg>
#include <cstddef>
#include <cstdint>
#include <cstdio>
#include <type_traits>

namespace hyle_capture_probe {

struct TensorTuple final {
  bool valid = false;
  unsigned dtype = 0;
  std::size_t rank = 0;
  const void *resource = nullptr;
  const void *handle = nullptr;
  std::size_t offset = 0, bytes = 0;
  std::array<std::int64_t, 8> dimensions{}, strides{};
};

template<class Tensor>
TensorTuple tensor_tuple(const Tensor &tensor) noexcept {
  TensorTuple result;
  result.valid = tensor.valid();
  if (!result.valid) return result;
  const auto &description = tensor.description();
  const auto storage = tensor.storage();
  result.dtype = static_cast<unsigned>(description.data_type());
  result.rank = description.rank();
  result.resource = storage.resource().valid()
      ? static_cast<const void *>(&storage.resource().resource()) : nullptr;
  result.handle = storage.native_handle();
  result.offset = storage.offset(); result.bytes = storage.size();
  for (std::size_t i = 0; i < std::min(result.rank, result.dimensions.size()); ++i) {
    result.dimensions[i] = description.dimensions()[i];
    result.strides[i] = description.byte_strides()[i];
  }
  return result;
}

struct Cause final {
  const char *why = "native-region-invalidate";
  const void *caller = nullptr;
  bool output = false, unproved = false, revision_changed = false;
  bool native_current = false;
  int port = -1;
  std::uint32_t instance = UINT32_MAX;
  TensorTuple before{}, after{};
};

struct Context final {
  bool active = false;
  std::uint64_t serial = 0;
  unsigned role = 0;
  std::size_t width = 0, tokens = 0, slot = 0, prior = 0;
  const void *run = nullptr;
};

static_assert(std::is_trivially_copyable_v<TensorTuple>);
static_assert(std::is_trivially_copyable_v<Cause>);
static_assert(std::is_trivially_copyable_v<Context>);
inline thread_local Context context{};
inline thread_local Cause cause{};

inline void set_context(unsigned role, std::size_t width, std::size_t tokens,
                        std::size_t slot, std::size_t prior,
                        const void *run) noexcept {
  ++context.serial;
  context.active = true; context.role = role; context.width = width;
  context.tokens = tokens; context.slot = slot; context.prior = prior;
  context.run = run; cause = {};
}

class Scope final {
public:
  explicit Scope(const Cause &value) noexcept : previous_(cause) { cause = value; }
  explicit Scope(const char *why, const void *caller = nullptr) noexcept
      : previous_(cause) { cause = {}; cause.why = why; cause.caller = caller; }
  ~Scope() { cause = previous_; }
  Scope(const Scope &) = delete;
  Scope &operator=(const Scope &) = delete;
private:
  Cause previous_;
};

constexpr std::size_t capacity = 256, event_bytes = 2048;
struct Event final {
  std::array<char, event_bytes> text{};
  std::atomic<bool> ready{false};
};
inline std::array<Event, capacity> events{};
inline std::atomic<std::size_t> used{0}, overflow{0};
inline std::atomic<bool> flushed{false};

struct Line final {
  char *data;
  std::size_t remaining;
  bool truncated = false;
  void append(const char *format, ...) noexcept {
    if (remaining <= 1) { truncated = true; return; }
    std::va_list args;
    va_start(args, format);
    const int result = std::vsnprintf(data, remaining, format, args);
    va_end(args);
    if (result < 0) { truncated = true; return; }
    const auto written = static_cast<std::size_t>(result);
    if (written >= remaining) {
      data += remaining - 1; remaining = 1; truncated = true;
    } else { data += written; remaining -= written; }
  }
  void tuple(const char *label, const TensorTuple &value) noexcept {
    append(" %s_valid=%u %s_dtype=%u %s_rank=%zu %s_resource=%p %s_handle=%p %s_offset=%zu %s_bytes=%zu %s_dims=",
        label, unsigned(value.valid), label, value.dtype, label, value.rank,
        label, const_cast<void *>(value.resource), label, const_cast<void *>(value.handle),
        label, value.offset, label, value.bytes, label);
    for (std::size_t i = 0; i < std::min(value.rank, value.dimensions.size()); ++i)
      append("%s%lld", i ? "," : "", static_cast<long long>(value.dimensions[i]));
    append(" %s_strides=", label);
    for (std::size_t i = 0; i < std::min(value.rank, value.strides.size()); ++i)
      append("%s%lld", i ? "," : "", static_cast<long long>(value.strides[i]));
  }
};

// Called only at an actual retained covering-range erase, before destruction.
// All stored material is text/scalar metadata; no tensor or resource owner is kept.
inline void record_loss(const void *invocation, const void *plan,
                        std::uint64_t generation, std::uint32_t step,
                        std::uint32_t range_begin, std::uint32_t range_count,
                        std::uint64_t revision, std::uint64_t prepared_revision,
                        bool stable, bool native_inputs) noexcept {
  if (!context.active) return;
  const auto index = used.fetch_add(1, std::memory_order_relaxed);
  if (index >= capacity) { overflow.fetch_add(1, std::memory_order_relaxed); return; }
  auto &event = events[index];
  Line line{event.text.data(), event.text.size()};
  line.append("capture_loss event=%zu serial=%llu role=%u R=%zu T=%zu slot=%zu prior=%zu run=%p inv=%p plan=%p generation=%llu step=%u range_begin=%u range_count=%u revision=%llu prepared_revision=%llu stable=%u native_inputs=%u why=%s caller=%p unproved=%u revision_changed=%u native_current=%u port_kind=%s port=%d instance=%u",
      index, static_cast<unsigned long long>(context.serial), context.role,
      context.width, context.tokens, context.slot, context.prior,
      const_cast<void *>(context.run), const_cast<void *>(invocation), const_cast<void *>(plan),
      static_cast<unsigned long long>(generation), step, range_begin, range_count,
      static_cast<unsigned long long>(revision), static_cast<unsigned long long>(prepared_revision),
      unsigned(stable), unsigned(native_inputs), cause.why,
      const_cast<void *>(cause.caller), unsigned(cause.unproved), unsigned(cause.revision_changed),
      unsigned(cause.native_current), cause.port < 0 ? "none" : cause.output ? "output" : "input",
      cause.port, cause.instance);
  if (cause.port >= 0) { line.tuple("old", cause.before); line.tuple("new", cause.after); }
  if (line.truncated) {
    constexpr char marker[] = " truncated=1";
    std::snprintf(event.text.data() + event.text.size() - sizeof(marker), sizeof(marker), "%s", marker);
  }
  event.ready.store(true, std::memory_order_release);
}

// The scratch consumer calls this once after its original work has finished.
inline void flush() noexcept {
  if (flushed.exchange(true, std::memory_order_acq_rel)) return;
  const auto total = used.load(std::memory_order_acquire);
  std::size_t pending = 0;
  for (std::size_t i = 0; i < std::min(total, capacity); ++i) {
    if (events[i].ready.load(std::memory_order_acquire))
      std::fprintf(stderr, "%s\n", events[i].text.data());
    else ++pending;
  }
  std::fprintf(stderr, "capture_probe_summary retained_loss_events=%zu capacity=%zu overflow=%zu pending=%zu context_anchor=%p\n",
      total, capacity, overflow.load(std::memory_order_acquire), pending,
      reinterpret_cast<void *>(&set_context));
}

} // namespace hyle_capture_probe
