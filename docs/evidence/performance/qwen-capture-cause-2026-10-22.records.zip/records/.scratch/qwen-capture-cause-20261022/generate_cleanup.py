"""Adapt the prior exact-leaf cleanup generator; this writes no root script yet."""
from pathlib import Path
C = Path(__file__).resolve().parent
R = C.parents[1]
s = (R / '.scratch/qwen-cublas-scores-20261022/prepare_cleanup.py').read_text()
s = s.replace('qwen-cublas-scores-20261022', 'qwen-capture-cause-20261022')
s = s.replace('qwen-cublas-scores-2026-10-22.cleanup.json', 'qwen-capture-cause-2026-10-22.cleanup.json')
s = s.replace("keep=[X/'qwen-link1/qwen.exe',", "keep=[R/'.scratch/qwen-cublas-scores-20261022/qwen-link1/qwen.exe',")
start = s.index('old_ready=')
end = s.index('plan=dict', start)
s = s[:start] + s[end:]
s = s.replace('historical_image_allowlist=[str(old.resolve())]', 'historical_image_allowlist=[]')
(C / 'prepare_cleanup.py').write_text(s, encoding='utf-8')
print('Prepared diagnostic cleanup generator; no deletion.')
