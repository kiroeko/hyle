"""Explicit scratch-only host diagnostic compilation/link; import performs no work.

Four source copies use retained recipes and replace four AD objects. No SDK,
NVCC, configure, inference or GPU action is provided by this script.
"""
from pathlib import Path
from functools import cache
import argparse
import importlib.util
import os
import sys

S = Path(__file__).resolve().parent
R = S.parents[1]
AD = R / '.scratch/qwen-cublas-scores-20261022'
BASE = AD / 'qwen-link1/link-plan.json'
RECIPES = {
    'main': R / '.scratch/qwen-f32-scores-20261022/compile1/qwen/identity.json',
    'executable': R / '.scratch/qwen-prefix-20261021/core-checks/diagnostic2/identity.json',
    'resources': R / '.scratch/qwen-mtp-round-20261022/compile1/resources/identity.json',
    'region_access': R / '.scratch/qwen-prefix-20261021/core-checks/attempt1/graph--region_access/identity.json',
}
ORIGINAL_SOURCES = {
    'main': 'tools/qwen35_text/main.cc',
    'executable': 'src/graph/executable.cc',
    'resources': 'src/graph/resources.cc',
    'region_access': 'src/graph/region_access.cc',
}
SOURCES = {tag: S / 'probe' / relative for tag, relative in ORIGINAL_SOURCES.items()}
INDICES = {'main': 0, 'executable': 80, 'resources': 76, 'region_access': 83}


@cache
def helpers():
    # Original helpers are loaded only when an explicit plan/build function is
    # called, never as an import-time action of this module.
    sys.dont_write_bytecode = True
    spec = importlib.util.spec_from_file_location('ae_retained_ad_helpers', AD / 'build.py')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module.b, module.c


def __getattr__(name):
    # The existing root run helper consumes b/c. Resolve only on that explicit
    # attribute request, preserving an otherwise side-effect-free import.
    if name in ('b', 'c'):
        return helpers()[0 if name == 'b' else 1]
    raise AttributeError(name)


def compile_command(tag, attempt):
    b, c = helpers()
    out = S / f'compile{attempt}' / tag
    original = c.read(RECIPES[tag])['command']
    command = b.host_command(original, SOURCES[tag], tag, out)
    directory = R / ('tools/qwen35_text' if tag == 'main' else 'src/graph')
    include = '/I' + str(directory)
    if not any(x.casefold() == include.casefold() for x in command):
        command.insert(1, include)
    assert all(flag in command for flag in ('/W4', '/WX', '/O2', '/MD', '/std:c++latest'))
    return command


def compile_owner(tag, attempt):
    b, c = helpers()
    recipe, base = c.read(RECIPES[tag]), c.read(BASE)
    assert len(base['inputs']) == 195
    assert recipe['object'] == base['inputs'][INDICES[tag]]
    assert b.identity(recipe['object']['path']) == recipe['object']
    source = SOURCES[tag]
    frozen = b.identity(source)
    command = compile_command(tag, attempt)
    out = S / f'compile{attempt}' / tag
    out.mkdir(parents=True, exist_ok=False)
    (out / 'tmp').mkdir()
    snapshot = out / 'source' / source.name
    snapshot.parent.mkdir()
    snapshot.write_bytes(source.read_bytes())
    c.save(out / 'plan.json', dict(command=command, source=frozen,
        source_snapshot=b.identity(snapshot), original_source=recipe['source'],
        recipe=b.identity(RECIPES[tag]), replaced_object=recipe['object'],
        diagnostic_only=True, SDK_builds=0, NVCC_builds=0))
    env, _ = b.environment(command, [], out)
    c.execute('compile', command, env, out)
    data = c.read(out / f'{tag}-deps.json')['Data']
    dependencies = list(dict.fromkeys([data['Source'], *data['Includes']]))
    assert b.identity(source) == frozen, 'scratch source changed during compilation'
    record = dict(source=frozen, source_snapshot=b.identity(snapshot),
        original_source=recipe['source'], object=b.identity(out / f'{tag}.obj'),
        command=command, recipe=b.identity(RECIPES[tag]), replaced_object=recipe['object'],
        dependencies=[b.identity(p) for p in dependencies],
        diagnostic_only=True, SDK_builds=0, NVCC_builds=0)
    if tag == 'main':
        record['main'] = frozen
    c.save(out / 'identity.json', record)
    print('COMPILED', tag, flush=True)


def link(attempt, link_attempt, owner_attempts=None):
    b, c = helpers()
    base = c.read(BASE)
    assert len(base['inputs']) == 195
    # Inherited large libraries/SDK objects are not rehashed: the original AD
    # identity list is retained and their current paths/sizes are checked.
    for item in base['inputs']:
        p = Path(item['path'])
        assert p.is_file() and p.stat().st_size == item['bytes'], item['path']
    records, record_ids, replacements = {}, [], {}
    checked = {}
    for tag in SOURCES:
        selected = (owner_attempts or {}).get(tag, attempt)
        path = S / f'compile{selected}' / tag / 'identity.json'
        record, recipe = c.read(path), c.read(RECIPES[tag])
        old = base['inputs'][INDICES[tag]]
        assert recipe['object'] == old
        assert b.identity(old['path']) == old
        for item in (record['source'], record['object'], *record['dependencies']):
            k = c.key(item['path'])
            if k in checked:
                assert checked[k] == item
            else:
                assert b.identity(item['path']) == item
                checked[k] = item
        records[tag] = record
        record_ids.append(b.identity(path))
        replacements[c.key(old['path'])] = record['object']
    assert len(replacements) == 4
    assert all(sum(c.key(i['path']) == old for i in base['inputs']) == 1 for old in replacements)
    inputs = [replacements.get(c.key(item['path']), item) for item in base['inputs']]
    assert len(inputs) == 195 and len({c.key(i['path']) for i in inputs}) == 195
    assert sum(a == z for a, z in zip(base['inputs'], inputs)) == 191
    command = [replacements.get(c.key(arg), {}).get('path', arg) for arg in base['command']
        if not arg.upper().startswith(('/OUT:', '/MAP:', '/IMPLIB:', '/PDB:'))]
    out = S / f'qwen-link{link_attempt}'
    out.mkdir(parents=True, exist_ok=False)
    (out / 'tmp').mkdir()
    image = out / 'qwen.exe'
    command += ['/OUT:' + str(image), '/MAP:' + str(image.with_suffix('.map')),
                '/IMPLIB:' + str(image.with_suffix('.lib'))]
    main_record = S / f"compile{(owner_attempts or {}).get('main', attempt)}/main/identity.json"
    c.save(out / 'link-plan.json', dict(command=command, inputs=inputs,
        base=b.identity(BASE), compiled_records=record_ids,
        consumer_compiled_record=b.identity(main_record), consumer_recompiled=True,
        replaced_product_inputs=4, reused_link_inputs=191,
        validation=dict(replaced_object_SHA_verified=True, fresh_dependency_SHA_verified=True,
            inherited_input_paths_and_sizes_verified=True, inherited_input_SHA_rehashed=False),
        diagnostic_only=True, SDK_builds=0, NVCC_builds=0))
    env, _ = b.environment(command, [i['path'] for i in inputs], out)
    c.execute('link', command, env, out)
    runtime_path = AD / 'qwen-link1/runtime-environment.json'
    runtime = c.read(runtime_path)
    for item in runtime['staged_dlls']:
        assert b.identity(item['path']) == item
        source = Path(item['path'])
        os.link(source, out / source.name)
    runtime['previous_environment'] = b.identity(runtime_path)
    runtime['PATH'] = env['PATH']
    runtime['staged_dlls'] = [b.identity(p) for p in out.glob('*.dll')]
    if 'CPU_DLL' in runtime:
        name = Path(runtime['CPU_DLL']['source']['path']).name
        runtime['CPU_DLL']['destination'] = b.identity(out / name)
    c.save(out / 'runtime-environment.json', runtime)
    ready = dict(image=b.identity(image), source=records['main']['source'],
        main=records['main']['source'], compiled_records=record_ids,
        consumer_compiled_record=b.identity(main_record), consumer_recompiled=True,
        changed_sources=[record['source'] for record in records.values()],
        link_plan=b.identity(out / 'link-plan.json'),
        runtime_environment=b.identity(out / 'runtime-environment.json'),
        diagnostic_only=True, SDK_builds=0, NVCC_builds=0)
    c.save(S / f'qwen-ready-attempt{link_attempt}.json', ready)
    print('READY qwen', flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('tag', choices=(*SOURCES, 'qwen'))
    parser.add_argument('--attempt', type=int, default=1)
    parser.add_argument('--link', action='store_true')
    parser.add_argument('--link-attempt', type=int)
    for owner in SOURCES:
        parser.add_argument('--' + owner.replace('_', '-') + '-attempt', type=int)
    args = parser.parse_args()
    owners = {tag: getattr(args, tag + '_attempt') for tag in SOURCES
              if getattr(args, tag + '_attempt') is not None}
    if any(n <= 0 for n in [args.attempt, *(owners.values()),
                           *([args.link_attempt] if args.link_attempt is not None else [])]):
        parser.error('attempt numbers must be positive')
    if args.link:
        if args.tag != 'qwen':
            parser.error('--link requires qwen')
        link(args.attempt, args.link_attempt or args.attempt, owners)
    elif args.tag in SOURCES:
        compile_owner(args.tag, args.attempt)
    else:
        parser.error('qwen requires --link')
