"""Read-only postcleanup checks for the one actual capture diagnostic."""
from pathlib import Path
import hashlib
import json

C = Path(__file__).resolve().parent
R = C.parents[1]

def read(p):
    return json.loads(Path(p).read_text(encoding='utf-8-sig'))

def identity(p):
    p = Path(p)
    h = hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda: f.read(8 << 20), b''):
            h.update(b)
    return dict(path=str(p.resolve()), bytes=p.stat().st_size, sha256=h.hexdigest())

pub = read(C / 'published.json')
assert identity(pub['manifest']['path']) == pub['manifest']
assert all(identity(e['path']) == e for e in pub['archives'])
plan = read(C / 'cleanup-plan.json')
result = read(C / 'cleanup-result.json')
assert len(plan['targets']) == result['removed_files']
assert plan['logical_bytes'] == result['removed_logical_bytes']
assert all(not Path(e['path']).exists() for e in plan['targets'])
assert not plan['historical_image_allowlist']
assert all(identity(e['path']) == e for e in plan['keep_images'])
assert (R / 'test.ps1').read_bytes() == (C / 'cleanup_script.ps1').read_bytes()
assert identity(plan['script']['path']) == plan['script']
assert identity(plan['script_copy']['path']) == plan['script_copy']
assert (C / 'cleanup-result.json').read_bytes() == (R / 'docs/evidence/performance/qwen-capture-cause-2026-10-22.cleanup.json').read_bytes()
freeze = read(C / 'probe/core-source-freeze.json')
for e in freeze['before']:
    rel = Path(e['path']).relative_to(Path('.scratch/qwen-capture-cause-20261022/before'))
    live = identity(R / rel)
    assert (live['bytes'], live['sha256']) == (e['bytes'], e['sha256'])
assert identity(R / 'tools/qwen35_text/main.cc')['sha256'] == read(C / 'main-probe.json')['product_sha256']
for e in read(C / 'docs-freeze.json')['files']:
    assert identity(e['source']['path']) == e['source']
    assert identity(e['snapshot']['path']) == e['snapshot']
ready = read(C / 'qwen-ready-attempt1.json')
link = read(ready['link_plan']['path'])
assert len(link['inputs']) == 195 and link['reused_link_inputs'] == 191
assert all(Path(e['path']).is_file() and Path(e['path']).stat().st_size == e['bytes'] for e in link['inputs'])
for e in ready['compiled_records']:
    assert identity(e['path']) == e
    compiled = read(e['path'])
    assert identity(compiled['object']['path']) == compiled['object']
assert not Path(ready['image']['path']).exists()
control = read(C / 'diagnostic1/finite-control.json')
assert control['actual_outputs'] == 64 and not control['selected_changes'] and control['no_tensor_payloads']
report = dict(status='PASS', published=pub, product_core_and_main_unchanged=True,
              latest_docs_SHA_verified=True, root_script_completed_do_not_rerun=True,
              removed_files=len(plan['targets']), removed_logical_bytes=plan['logical_bytes'],
              current_AD_and_native_images=plan['keep_images'],
              all195_link_inputs_preserved_by_path_and_size=True, reused_inputs=191,
              all4_scratch_TU_objects_SHA_verified=True, diagnostic_image_removed=True,
              actual_model_processes=1, performance_evidence=False)
(C / 'postconditions.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
print(json.dumps(dict(status='PASS', removed_files=len(plan['targets']),
                     removed_logical_MiB=plan['logical_bytes'] / 2**20,
                     link_inputs_preserved=195, actual_diagnostic_processes=1), indent=2))
