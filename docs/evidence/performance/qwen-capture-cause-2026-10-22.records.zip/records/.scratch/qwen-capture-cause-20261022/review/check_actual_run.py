"""Pure-host accounting of the one retained AE capture diagnostic."""
from collections import Counter, defaultdict
from pathlib import Path
import hashlib
import json
import re

S = Path(__file__).resolve().parents[1]
R = S.parents[1]
RUN = S / 'diagnostic1'
AD = R / '.scratch/qwen-cublas-scores-20261022'


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))


def identity(path):
    path = Path(path).resolve()
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())


def pairs(line):
    return dict(part.split('=', 1) for part in line.split()[1:])


def main():
    result = read(RUN / 'run.result.json')
    assert result['exit'] == 0 and result['terminal']
    actual = read(RUN / 'parsed.json')
    assert actual == read(RUN / 'run.stdout.log')
    ad_runs = read(AD / 'performance/timing/runs.json')
    baseline = next(x for x in ad_runs if x['arm'] == 'after_MTP')['observation']
    assert actual['generated_ids'] == baseline['generated_ids'] and len(actual['generated_ids']) == 64
    assert actual['rounds'] == baseline['raw']['rounds'] and len(actual['rounds']) == 34
    compared_work = {key: value for key, value in baseline['work'].items() if value is not None}
    assert all(actual.get(key) == value for key, value in compared_work.items())
    assert actual['diagnostic'] and not baseline['raw']['diagnostic']
    lines = (RUN / 'run.stderr.log').read_text(encoding='utf-8').splitlines()
    events = [pairs(line) for line in lines if line.startswith('capture_loss ')]
    summaries = [pairs(line) for line in lines if line.startswith('capture_probe_summary ')]
    assert len(summaries) == 1
    summary = {key: int(value) for key, value in summaries[0].items() if key != 'context_anchor'}
    assert summary == dict(retained_loss_events=10, capacity=256, overflow=0, pending=0)
    assert len(events) == 10 and [int(x['event']) for x in events] == list(range(10))
    assert all('truncated' not in x for x in events)
    prepared = []
    cold_seconds = []
    expression = re.compile(r'^prepared T=(\d+) visible=(\d+) replay=(\S+) cold_batch_seconds=([\d.eE+-]+) capture_recorded=(\d+) capture_reused=(\d+)$')
    for line in lines:
        match = expression.match(line)
        if match:
            t, visible, replay, cold, recorded, reused = match.groups()
            prepared.append(dict(T=int(t), visible=int(visible), replay=replay,
                                 recorded=int(recorded), reused=int(reused)))
            cold_seconds.append(float(cold))
    assert len(prepared) == actual['actual_graph_calls'] == 35
    assert prepared[0] == dict(T=154, visible=154, replay='commands', recorded=0, reused=0)
    event_counts = Counter(int(x['serial']) for x in events)
    contexts, uses, first_uses = {}, Counter(), []
    length, draft = 154, 154
    for index, round_ in enumerate(actual['rounds']):
        serial = index + 2
        lag = length - draft
        assert lag in (0, 1)
        role = 3 if lag == 0 else 4
        slot = (serial - 1) % 2
        key = (role, slot)
        prior = uses[key]
        context = dict(serial=serial, round_index_zero_based=index, role=role, slot=slot, prior=prior)
        contexts[serial] = context
        length += round_['committed_target_rows']
        draft += round_['draft_rows']
        call = prepared[serial - 1]
        assert call['T'] == 2 and call['visible'] == length
        assert call['recorded'] + call['reused'] == 2
        if prior == 0:
            assert call['recorded'] == 2 and event_counts[serial] == 0
            first_uses.append(dict(**context, recorded_ranges=2))
        else:
            assert call['recorded'] == event_counts[serial]
        uses[key] += 1
    assert (length, draft) == (actual['visible_tokens'], actual['draft_frontier']) == (217, 216)
    assert len(first_uses) == 4 and sum(x['recorded_ranges'] for x in first_uses) == 8
    assert sum(x['recorded'] for x in prepared) == 18
    assert sum(x['reused'] for x in prepared) == 50
    first_serials = {x['serial'] for x in first_uses}
    loss_serials = set(event_counts)
    other_serials = set(contexts) - first_serials - loss_serials
    assert not first_serials.intersection(loss_serials)
    def bucket(serials):
        return dict(calls=len(serials), inclusive_cold_batch_seconds=sum(cold_seconds[x - 1] for x in serials),
                    by_call=[dict(**contexts[x], cold_batch_seconds=cold_seconds[x - 1]) for x in sorted(serials)])
    cold_buckets = dict(prefill_inclusive_cold_batch_seconds=cold_seconds[0],
                        all34_decode_calls_inclusive_seconds=sum(cold_seconds[1:]),
                        first8_ranges_in4_calls=bucket(first_serials),
                        actual10_loss_ranges_in7_calls=bucket(loss_serials),
                        remaining23_calls=bucket(other_serials))
    assert len(first_serials) == 4 and len(loss_serials) == 7 and len(other_serials) == 23
    assert abs(sum(cold_buckets[key]['inclusive_cold_batch_seconds'] for key in
                   ('first8_ranges_in4_calls', 'actual10_loss_ranges_in7_calls', 'remaining23_calls'))
               - cold_buckets['all34_decode_calls_inclusive_seconds']) < 1e-12
    compact_events, actual_ranges = [], set()
    pointer_ids = defaultdict(set)
    for event in events:
        serial = int(event['serial'])
        context = contexts[serial]
        assert all(int(event[key]) == context[key] for key in ('role', 'slot', 'prior'))
        assert event['R'] == '1' and event['T'] == '2'
        assert event['why'] == 'prepare-binding' and event['stable'] == '1' and event['native_inputs'] == '0'
        assert event['unproved'] == event['revision_changed'] == event['native_current'] == '0'
        assert event['revision'] == event['prepared_revision']
        assert event['port_kind'] in ('input', 'output') and int(event['port']) >= 0
        fields = ('valid', 'dtype', 'rank', 'resource', 'handle', 'offset', 'bytes', 'dims', 'strides')
        changed = [key for key in fields if event['old_' + key] != event['new_' + key]]
        assert changed == ['offset'] and event['old_valid'] == event['new_valid'] == '1'
        unique = (serial, event['inv'], event['range_begin'], event['range_count'])
        assert unique not in actual_ranges
        actual_ranges.add(unique)
        pointer_ids[(event['role'], event['slot'])].add((event['run'], event['inv'], event['plan'], event['generation']))
        compact_events.append(dict(event=int(event['event']), **context,
            step=int(event['step']), range_begin=int(event['range_begin']), range_count=int(event['range_count']),
            revision=int(event['revision']), port_kind=event['port_kind'], port=int(event['port']), instance=int(event['instance']),
            first_observed_changed_field='offset', old_offset_bytes=int(event['old_offset']), new_offset_bytes=int(event['new_offset']),
            unchanged_extent_bytes=int(event['old_bytes']), unchanged_dims=event['old_dims'], unchanged_strides=event['old_strides']))
    assert all(len(values) == 1 for values in pointer_ids.values())
    metadata = sorted((RUN / 'route-only').rglob('*'))
    metadata = [path for path in metadata if path.is_file()]
    assert len(metadata) == 6 and all(path.suffix == '.tsv' for path in metadata)
    finite = read(RUN / 'finite-control.json')
    assert finite['status'] == 'same_selected_output_work_fields' and finite['no_tensor_payloads'] and not finite['unexpected_payload_paths']
    ready = read(S / 'qwen-ready-attempt1.json')
    source_paths = [RUN / name for name in ('plan.json', 'run.command.json', 'run.result.json', 'run.stdout.log', 'run.stderr.log', 'parsed.json', 'finite-control.json')]
    source_paths += [S / 'qwen-ready-attempt1.json', S / 'probe/core-source-freeze.json', S / 'main-probe.json', S / 'probe/capture_probe.h',
                     AD / 'performance/timing/runs.json', Path(__file__)]
    report = dict(status='FROZEN_PURE_HOST_ACTUAL_RUN_REVIEW', sources=[identity(path) for path in source_paths],
        image=ready['image'], verification=dict(exit_zero_terminal=True, parsed_equals_stdout=True, AD64_IDs_equal=True,
            AD34_rounds_equal=True, AD_exported_work_equal=True, prepared_calls=35,
            capture_loss_events=10, event_indices_contiguous=True, first_change_offset_only=True,
            all_events_prepare_binding_stable1_native_inputs0=True, native_owner_loss_events=0,
            event_buffer_overflow=0, event_buffer_pending=0, truncated_events=0,
            role_slot_generation_identity_stable_across_observed_events=True, route_metadata_files=6, tensor_payload_files=0),
        work=compared_work, capture=dict(recorded_ranges=18, reused_ranges=50, initial_role_slot_ranges=8,
            actual_lost_and_rerecorded_ranges=10, equation='18 = 4 first role/slot uses *2 ranges +10 actual retained-range losses;18+50=34 decode calls *2 child ranges.',
            first_uses=first_uses, losses_by_call=[dict(**contexts[serial], actual_loss_ranges=count) for serial, count in sorted(event_counts.items())]),
        events=compact_events, metadata=[identity(path) for path in metadata],
        inclusive_diagnostic_cold_buckets=cold_buckets,
        erased_range_step_counts=dict(sorted(Counter(int(x['range_count']) for x in events).items())),
        interpretation='All10 actual retained covering-range erases first observed an ordinary prepared input/output byte-offset change within the same logged resource/native_handle. Tensor valid/dtype/rank/extent/dimensions/strides and prior prepared revision were unchanged. No native-region-invalidate/native owner-loss event was recorded in this window.',
        attribution_limits=['Only the first changed tensor port at each actual range erase is snapshotted; later differences are not enumerated and cannot be declared absent.',
            'Unchanged tensor descriptions do not mean the owned paged BatchLayoutVersion/content never changes; this probe did not record every layout identity.',
            'Role/slot/prior are checked against natural accept/reject lag transitions, source global parity starting0 and source per-role-slot preparation use counts. Initial first-use ranges do not have old covering artifacts to lose.',
            'No payload read was added by the diagnostic: six route/boundary TSV files and scalar tuple metadata only. This is not new hidden/state numerical-quality or timing evidence.',
            'The result establishes these10 actual first-port losses in this single run, not a cache bug or a safe optimization to ignore offsets. Semantic pool/port mapping is outside this review.',
            'cold_batch_seconds is an inclusive diagnostic preparation bucket, not capture self-time or recoverable savings. The7 loss-bearing calls include all other preparation work and can record two different-sized ranges in one call; their bucket is only a descriptive upper envelope, not10 times a per-range cost or a share of an unprofiled decode gap.',
            'The fixed buffer reported no overflow/pending/truncation. Explicit global capture-cache resets and teardown are outside this per-step erase hook; no such event is inferred from absent logs.'],
        new_native_runs=0, builds=0, GPU_runs=0)
    output = S / 'review/actual-run-review.json'
    output.write_text(json.dumps(report, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')
    print(json.dumps(dict(report=identity(output), recorded=18, first=8, losses=10, reused=50,
                          loss_serials=dict(event_counts), same_AD64_and_work=True, GPU_runs=0)))


if __name__ == '__main__':
    main()
