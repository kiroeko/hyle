"""Bounded source feasibility record. No build, native execution or network."""
from pathlib import Path
import hashlib
import json

W = Path(__file__).resolve().parent
R = W.parents[1]
NATIVE = R / '.scratch/legacy-root/hyle-scratch/ggml-native-static/src/compute_ggml_runtime/source-4e1a7b2f39afe15d/src/ggml-cuda'

def pin(path):
    raw = path.read_bytes()
    return {'path': str(path.relative_to(R)), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}

proof = json.loads((R / 'docs/evidence/performance/mtp-body-route-attribution-2026-10-25.json').read_text())
arms = proof['body']['arms']
h = arms['hyle_mtp']['ms']['N6144_K2048']['mean']
p = arms['peer_mtp']['ms']['N6144_K2048']['mean']
memo = {
    'status': 'SOURCE_FEASIBLE_NEW_TC_ALGORITHM_NOT_COVERED_BY_CLOSED_SIMT_LEAVES',
    'date': '2026-10-26',
    'execution': {'compile': 0, 'GPU': 0, 'HTTP': 0, 'canonical_product_changes': 0},
    'old_candidates_actual_algorithm': [
        {'source': pin(R / '.scratch/qwen-mtp-final-window-20261024/typed-mmvf-m2-proposal/typed_mmvf_m2.cu'),
         'fact': 'Direct mul_mat_vec_f<nv_bfloat16,float,2,256,...,nv_bfloat16,nv_bfloat16> instantiation; SIMT products and warp/shared F32 reduction. Closed down-N2048/K6144 consumer.'},
        {'source': pin(R / '.scratch/mtp-performance-convergence-20261025/m2-wide-leaf/typed_mmvf_m2_wide.cu'),
         'fact': 'Same mul_mat_vec_f SIMT body, whole M2, target-N6144/K2048 leaf. Closed overlapping0.95% result.'},
        {'source': pin(R / '.scratch/mtp-m2-pair-20261025/m2_pair.cu'),
         'fact': 'Same mul_mat_vec_f SIMT body with two-original-W paired outputs. Closed slower median.'},
        {'source': pin(R / '.scratch/mtp-m2-wide-lt-20261026/wide_leaf.cc'),
         'fact': 'Ordinary Lt request1 at separate N6144 versus concatenated N12288; no native MMF used. Closed overlapping/slower wide median.'},
    ],
    'actual_peer_algorithm': {
        'evidence': pin(R / 'docs/evidence/performance/mtp-body-route-attribution-2026-10-25.json'),
        'kernel': 'mul_mat_f<__nv_bfloat162,32,2,8,false>(BF16pair W,F32 A,F32 Y)',
        'counts': '66 N6144/K2048 projections per selected target:24gate+24up+18GDNQKV; grid192/block256.',
        'native_body': {**pin(NATIVE / 'mmf.cuh'), 'anchors': ['48-55 signature', '202-226 activation pair conversion and mma', '232-282 float combine/final stores', '638-685 fixed launch geometry']},
        'MMA': {**pin(NATIVE / 'mma.cuh'), 'anchor': '1181-1193: mma.sync.aligned.m16n8k16.row.col.f32.bf16.bf16.f32 under AMPERE_MMA_AVAILABLE'},
        'dispatch': {**pin(NATIVE / 'mmf.cu'), 'anchors': ['13-34 F32 activation/output assertions', '120-128 original BF16 W branch', '133-187 original geometry/SM80+ predicate']},
        'version_limit': 'This retained native source is an algorithm reference, not a declaration that its whole runtime ABI equals current Hyle. A future compile must use the current canonical-manifest native include/source closure; never inject an old48/56-byte ABI object merely because mmf.cuh matches.'},
    'typed_boundary_minimum': {
        'domain': 'Initial finite candidate only original BF16 W[N6144,K2048], A[M2,K2048], independent BF16 Y[M2,N6144], F32 accumulation, no IDs/batches/fusions, exact dense row strides. No model-name branch and no change to F32-activation mixed contract.',
        'keep': 'Original tile geometry, BF16 W loads, ldmatrix, BF16 MMA with F32 tile_C, cross-warp shared F32 sums and output ordering. Keep each projection final BF16 value, then unchanged SiLU/BF16/Mul boundaries downstream.',
        'change_A_only': 'mmf.cuh:208 currently reads float2 then rounds it into nv_bfloat162 for tile_B. For original BF16 A, read the corresponding nv_bfloat162 bits directly into that same tile. Preserve the same padded lanes and element-stride units; no FP16, TF32, FP8 or weight shadow. An F32 widening of an already BF16 finite-normal operand followed by BF16 RN would recover its original bits; actual peer F32 A is not thereby claimed numerically identical.',
        'change_Y_only': 'After the unchanged float sum at :275, write __float2bfloat16_rn(sum) once at the original output boundary instead of float destination at :282. No intermediate BF16 accumulation or epilogue activation fusion.',
        'shared_body_design': 'Add private typed activation/output template parameters defaulting to existing float contracts, or an equally small typed epilogue/input adapter on the same shared MMF body. Confine typed support initially to has_ids=false; do not duplicate the complete algorithm or propagate new type cases through every MoE/AMD/column count.',
        'required_checks_if_later_implemented': 'Original full independent F64/gamma/BF16 gate before timing in direct and first captured execution. Retain NaN/Inf/subnormal contract/fallback honestly; no claim of arbitrary IEEE bit identity or task quality from a normal-domain original-data leaf.'},
    'minimum_changed_sources_not_implemented': {
        'private_leaf': 'One overlaid mmf.cuh shared-body type-boundary change plus one new small CUDA TU directly instantiating the exact <BF16pair,32,2,8,false,BF16A,BF16Y> case, and one reused original Lt/oracle host leaf. No old MMVF/pair/Lt parameter grid reopened.',
        'native_product_if_proven': [
            'mmf.cuh: private typed input/store support; retain existing float-default instantiations/host signatures.',
            'One dedicated typed-M2 CUDA instance/entry TU (or a correspondingly narrow existing MMF entry TU). No need to rebuild all original16 column-instance TUs merely to add one typed case.',
            'ggml-cuda.cu: exact cold supports/record qualification and BF16-result dispatch must admit the new matrix domain before its current M1-only bfloat_matvec assert; existing F32/mixed paths stay unchanged.',
            'Canonical dependency manifest/source list records the narrow patch/new TU; current native library link receives the new/replacement objects, not another SDK/runtime copy.'
        ],
        'host_product_if_proven': [
            'tensor_program.cc:1116-1131 must construct a BF16-native MUL_MAT result for the newly qualified matrix domain; current bfloat_vector is M1-only. Merely preferring GGML leaves M2 at F32 internal result plus as_output BF16 Cast and does not select this typed path.',
            'CUDA default policy currently prefers admitted direct Lt for ordinary rank2 MatMul. A measured candidate would require an explicit cold native capability/preference for its actual dtype/shape/device; no per-token model-string route or unconditional GGML preference.'
        ],
        'ABI': 'No change required to public Compute Operation, Graph IR, TensorDesc, ggml_tensor layout or existing exported F32/MMF host signatures. A private internal symbol or additive private capability hook can carry the typed case. Adding template instantiations changes internal kernel symbols, not public structure layout; current runtime/interface contract still must be checked when linking.',
        'not_done': 'No source patch, new SDK build, new API, registry, owner, model loader or product route has been implemented in this source review.'},
    'geometry_and_space': {
        'SM89_supported': 'BF16 MMA here requires Ampere SM80+, not Hopper TMA/WGMMA/TMEM. Ada SM89 qualifies for the original BF16 tile primitive.',
        'exact_fixed_geometry': {'grid': [192, 1, 1], 'block': [32, 8, 1],
                                 'nwarps': 8, 'rows_per_block': 32, 'cols_per_block': 2,
                                 'dynamic_shared_bytes': 18432, 'shared_combine_bytes': 8320},
        'derivation': 'Kpair1024, warp32, original heuristic chooses8 warps; max(8*16*(32+4)*4, PAD(2,8)*(8*32+4)*4)=18432B.',
        'global_extra_scratch_bytes': 0, 'original_weight_bytes_per_projection': 25165824,
        'weight_conversion_or_duplicate_bytes': 0,
        'important_baseline_limit': 'Current selected Hyle Lt already consumes BF16 A/W and outputs BF16. Typed MMF avoids casts needed by a naive GGML-F32-carrier integration; it does not remove such casts from the current direct-Lt baseline. Lt itself can use TensorCores: the proposed difference is MMF tile/scheduling versus Lt GEMM, not TensorCores versus no TensorCores.',
        'budget': 'Original input/output leases, shared workspace/capture ownership remain original. Per-CTA dynamic shared usage is native execution cost, not a new resident W/host-state pool. Provider workspace/opaque cost reporting must reflect any actual added metadata, not claim globally zero-cost execution.'},
    'old_hotspot_exposure_not_speedup': {
        'old_last_target_difference_ms_approximately': 0.340,
        'superseding_consistent_window': 'Each arm own last24 captured T2 targets; do not mix this mean with the previous last-single-target figure.',
        'hyle_group_activity_mean_ms': h, 'peer_group_activity_mean_ms': p,
        'group_mean_difference_ms': h-p, 'mean_difference_microseconds_per_projection': (h-p)*1000/66,
        'group_count_per_target': 66,
        'limits': 'This candidate can affect the66 group if later admitted; it is not limited to gate/up pair fusion and need not touch the18QKV role naming. The roughly0.209ms group activity delta is descriptive, not recoverable complete-wall time or an upper bound on a new algorithm. Different continuations and F32 versus BF16 carriers remain. No full decode/MTP/quality/TPS benefit is promised.'},
    'recommendation': 'A real new source-feasible TC-MMF mechanism remains after the closed SIMT/MMVF/pair/Lt candidates. If ROOT chooses implementation, start only with the one exact typed-MMF leaf and original numeric gate, without new tuning axes or product-wide route changes. This review itself authorises no compile/GPU.'
}
path = W / 'source-feasibility.json'
path.write_text(json.dumps(memo, indent=2) + '\n', encoding='utf-8')
print(json.dumps(pin(path)))
