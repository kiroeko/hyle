"""One fixed typed-MMF leaf: two small TUs, then one separately authorized run."""
from concurrent.futures import ThreadPoolExecutor
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import sys

W = Path(__file__).resolve().parent
R = W.parents[1]
spec = importlib.util.spec_from_file_location('prior_leaf_check', R / '.scratch/mtp-m2-wide-lt-20261026/check.py')
prior = importlib.util.module_from_spec(spec)
spec.loader.exec_module(prior)
read, save, pin, check, execute = prior.read, prior.save, prior.pin, prior.check, prior.execute

def reviewed():
    plan, pins = read(W / 'plan.json'), read(W / 'source-pins.json')
    for item in [*pins['private_source'], pins['reference_header'], pins['retained_harness'],
                 *pins['installed_or_retained_link_inputs'], plan['runtime'], plan['source_pins']]:
        check(item)
    return plan

def environment(plan):
    return prior.environment({'commands_not_executed': plan['commands']})

def build():
    plan = reviewed()
    env = environment(plan)
    with ThreadPoolExecutor(max_workers=2) as workers:
        futures = {name: workers.submit(execute, plan['commands'][name], env, W / name, 120)
                   for name in ('host', 'native')}
        results = {}
        errors = []
        for name, future in futures.items():
            try:
                results[name] = future.result()
            except Exception as error:
                errors.append((name, str(error)))
        if errors:
            raise RuntimeError(str(errors))
    host = read(W / 'host/dependencies.json')['Data']
    dependencies = {'host': [pin(Path(p)) for p in dict.fromkeys([host['Source'], *host['Includes']])]}
    deptext = (W / 'native/dependencies.d').read_text(encoding='utf-8-sig').replace('\\\n', ' ')
    rhs = deptext.split(' : ', 1)[1]
    paths = [Path(token.replace('\\ ', ' ')) for token in re.findall(r'(?:\\.|[^\s])+', rhs)]
    dependencies['native'] = [pin(path) for path in dict.fromkeys(paths)]
    save(W / 'actual-dependencies.json', dependencies)
    results['link'] = execute(plan['commands']['link'], env, W / 'link', 120)
    save(W / 'ready.json', {'status': 'BUILT_NOT_RUN', 'processes': results,
         'sources': [pin(W / name) for name in ('typed_leaf.cc', 'typed_mmf.cu', 'source/mmf.cuh')],
         'objects': [pin(W / name) for name in ('host/probe.obj', 'native/pair.obj')],
         'image': pin(W / 'link/typed-mmf-leaf.exe'), 'plan': pin(W / 'plan.json'),
         'source_pins': pin(W / 'source-pins.json'), 'actual_dependencies': pin(W / 'actual-dependencies.json'),
         'GPU_runs': 0, 'CUDA_TUs': 1, 'host_TUs': 1, 'SDK_builds': 0})
    print('READY BUILT_NOT_RUN', json.dumps(pin(W / 'ready.json')), flush=True)

def run():
    plan, ready = reviewed(), read(W / 'ready.json')
    for item in [*ready['sources'], *ready['objects'], ready['image'], ready['plan'],
                 ready['source_pins'], ready['actual_dependencies']]:
        check(item)
    inputs = []
    for role in plan['inputs']['original_roles']:
        item = role['range']
        with Path(item['path']).open('rb') as stream:
            stream.seek(item['offset'])
            payload = stream.read(item['bytes'])
        if len(payload) != item['bytes'] or hashlib.sha256(payload).hexdigest() != item['sha256']:
            raise RuntimeError('Original weight range changed: ' + role['name'])
        inputs.append({'role': role['name'], **item})
    activation = plan['inputs']['activation']
    check(activation['full_trace'])
    payload = Path(activation['full_trace']['path']).read_bytes()[:8192]
    if hashlib.sha256(payload).hexdigest() != activation['selected_sha256']:
        raise RuntimeError('Original activation prefix changed')
    save(W / 'run-inputs.json', {'roles': inputs, 'activation_bytes': len(payload),
                               'activation_sha256': activation['selected_sha256']})
    env = environment(plan)
    env.update({k: v for k, v in read(Path(plan['runtime']['path'])).items() if isinstance(v, str)})
    env.update(HF_HUB_OFFLINE='1', TRANSFORMERS_OFFLINE='1')
    process = execute(plan['commands']['run'], env, W / 'run', 120)
    actual = read(W / 'run/stdout.log')
    if not actual.get('passed'):
        raise RuntimeError('Leaf omitted successful numerical completion')
    save(W / 'summary.json', {'status': 'ACTUAL_FIXED_TYPED_MMF_LEAF_PASS', 'process': process,
         'ready': ready, 'actual': actual, 'input_checks': pin(W / 'run-inputs.json'),
         'limits': plan['limits'], 'GPU_released': True, 'Model_runs': 0,
         'additional_algorithm_searches': 0, 'additional_trials': 0, 'product_edits': 0})
    print('GPU RELEASED', json.dumps(pin(W / 'summary.json')), flush=True)

if __name__ == '__main__':
    {'build': build, 'run': run}[sys.argv[1]]()
