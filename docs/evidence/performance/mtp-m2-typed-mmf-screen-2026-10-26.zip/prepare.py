"""Prepare exactly one typed TC-MMF kernel and retained bounded Lt host leaf."""
from pathlib import Path
import difflib
import hashlib
import json

W=Path(__file__).resolve().parent
R=W.parents[1]
OLD=R/'.scratch/mtp-m2-pair-20261025'
REF=R/'.scratch/legacy-root/hyle-scratch/ggml-native-static/src/compute_ggml_runtime/source-4e1a7b2f39afe15d/src/ggml-cuda/mmf.cuh'
COHERENT=R/'.scratch/architecture-refactor-2026-10-18/paired-projection-route/native-source'

def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def save(p,v):p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8')
def pin(p):
 d=p.read_bytes();return {'path':str(p),'bytes':len(d),'sha256':hashlib.sha256(d).hexdigest()}
def once(text,old,new):
 assert text.count(old)==1,(old,text.count(old))
 return text.replace(old,new,1)

original=REF.read_text(encoding='utf-8')
assert (COHERENT/'src/ggml-cuda/mmf.cuh').read_bytes()==REF.read_bytes()
end=original.index('template <typename T, int rows_per_block, int cols_per_block, int nwarps>',original.index('static __global__ void mul_mat_f('))
kernel,tail=original[:end],original[end:]
kernel=once(kernel,'template <typename T, int rows_per_block, int cols_per_block, int nwarps, bool has_ids>',
 '''template <typename T, int rows_per_block, int cols_per_block, int nwarps, bool has_ids,
          typename TY = float, typename TD = float>''')
kernel=once(kernel,'const T * __restrict__ x, const float * __restrict__ y, const int32_t * __restrict__ ids, float * __restrict__ dst,',
                    'const T * __restrict__ x, const TY * __restrict__ y, const int32_t * __restrict__ ids, TD * __restrict__ dst,')
kernel=once(kernel,'// TODO: handle this in a consistent and simpler way after AMD MFMA support has been added',
 '''    static_assert((std::is_same_v<TY, float> && std::is_same_v<TD, float>) ||
        (std::is_same_v<T, nv_bfloat162> && std::is_same_v<TY, nv_bfloat16> &&
         std::is_same_v<TD, nv_bfloat16> && !has_ids), "private typed BF16 MMF is non-indexed only");
// TODO: handle this in a consistent and simpler way after AMD MFMA support has been added''')
old='''                        const float2 tmp = j < cols_per_block ? y2[j*stride_col_y + col] : make_float2(0.0f, 0.0f);
                        tile_xy[j0*tile_k_padded + threadIdx.x] = ggml_cuda_cast<T>(tmp);'''
new='''                        if constexpr (std::is_same_v<TY, nv_bfloat16>) {
                            const auto * typed_y2 = reinterpret_cast<const nv_bfloat162 *>(y);
                            tile_xy[j0*tile_k_padded + threadIdx.x] = j < cols_per_block
                                ? typed_y2[j*stride_col_y + col] : ggml_cuda_cast<T>(make_float2(0.0f, 0.0f));
                        } else {
                            const float2 tmp = j < cols_per_block ? y2[j*stride_col_y + col] : make_float2(0.0f, 0.0f);
                            tile_xy[j0*tile_k_padded + threadIdx.x] = ggml_cuda_cast<T>(tmp);
                        }'''
kernel=once(kernel,old,new)
kernel=once(kernel,'                dst[j*stride_col_dst + row0 + i0*warp_size + threadIdx.x] = sum[i0];',
 '''                if constexpr (std::is_same_v<TD, nv_bfloat16>) {
                    dst[j*stride_col_dst + row0 + i0*warp_size + threadIdx.x] = __float2bfloat16_rn(sum[i0]);
                } else {
                    dst[j*stride_col_dst + row0 + i0*warp_size + threadIdx.x] = sum[i0];
                }''')
after=kernel+tail
(W/'source').mkdir(exist_ok=True)
(W/'source/mmf.cuh').write_text(after,encoding='utf-8')
(W/'native-header.patch').write_text(''.join(difflib.unified_diff(original.splitlines(True),after.splitlines(True),fromfile='before/mmf.cuh',tofile='source/mmf.cuh')),encoding='utf-8')
host=(OLD/'m2_pair_leaf.cc').read_text(encoding='utf-8')
host=host.replace('extern "C" int hyle_m2_pair_configure() noexcept;', 'extern "C" int hyle_mmf_m2_configure() noexcept;')
host=host.replace('extern "C" int hyle_m2_pair_launch(const void *w0, const void *w1, const void *activation, void *y0, void *y1, void *stream) noexcept;',
                  'extern "C" int hyle_mmf_m2_launch(const void *weight, const void *activation, void *output, void *stream) noexcept;')
host=host.replace('paired','typed').replace('hyle_m2_pair_configure','hyle_mmf_m2_configure')
host=host.replace('typed_two_original_W_M2','two_typed_TC_MMF_original_W_M2')
host=once(host,'''      require(hyle_m2_pair_launch(reinterpret_cast<void*>(d.banks[bank][0]),reinterpret_cast<void*>(d.banks[bank][1]),
        reinterpret_cast<void*>(d.a),reinterpret_cast<void*>(d.y[0]),reinterpret_cast<void*>(d.y[1]),reinterpret_cast<void*>(d.stream))==0,"typed M2 launch failed");''',
 '''      for(std::size_t role=0;role<2;++role)
        require(hyle_mmf_m2_launch(reinterpret_cast<void*>(d.banks[bank][role]),reinterpret_cast<void*>(d.a),
          reinterpret_cast<void*>(d.y[role]),reinterpret_cast<void*>(d.stream))==0,"typed TC MMF M2 launch failed");''')
host=host.replace('choice.graph_nodes==std::size_t(Replays),"typed path is not one fixed kernel per pair"',
                  'choice.graph_nodes==2*std::size_t(Replays),"typed path is not exactly two original projections per pair"')
host=host.replace('Private two-original-W M2 pair leaf','Private typed TensorCore MMF versus two Lt projections')
host=host.replace('cold typed-kernel capability/materialization failed','cold typed TC-MMF capability/materialization failed')
host=once(host,'  int l2_bytes=0,warp_size=0;', '  int l2_bytes=0,warp_size=0,major=0,minor=0;')
host=once(host,'  require(warp_size==32,"fixed native pair requires NVIDIA warp32");',
 '''  cu(cuDeviceGetAttribute(&major,CU_DEVICE_ATTRIBUTE_COMPUTE_CAPABILITY_MAJOR,d.device),"actual major");
  cu(cuDeviceGetAttribute(&minor,CU_DEVICE_ATTRIBUTE_COMPUTE_CAPABILITY_MINOR,d.device),"actual minor");
  require(major==8&&minor==9&&warp_size==32,"fixed typed MMF leaf requires original Ada SM89/warp32");''')
host=once(host,'    launch(choice,0);cu(cuStreamSynchronize(d.stream),"direct numeric retirement");verify(choice,true);',
 '''    for(auto y:d.y)cu(cuMemsetD16(y,0x7fc1u,M*N),"complete independent output poison");
    launch(choice,0);cu(cuStreamSynchronize(d.stream),"direct numeric retirement");verify(choice,true);''')
host=once(host,'    cu(cuGraphLaunch(choice.executable,d.stream),"pre-timing captured numeric replay");',
 '''    for(auto y:d.y)cu(cuMemsetD16(y,0x7fc1u,M*N),"captured independent output poison");
    cu(cuGraphLaunch(choice.executable,d.stream),"pre-timing captured numeric replay");''')
(W/'typed_leaf.cc').write_text(host,encoding='utf-8')
old=read(OLD/'plan.json')
commands={name:[x.replace(str(OLD),str(W)).replace('m2_pair_leaf.cc','typed_leaf.cc').replace('m2_pair.cu','typed_mmf.cu').replace('paired-leaf.exe','typed-mmf-leaf.exe') for x in old['commands'][name]] for name in ('host','native','link','run')}
commands['native']=[x.replace('source\\mmvf.cuh','source\\mmf.cuh') for x in commands['native']]
oracle=lambda text:text[text.index('double gamma('):text.index('std::array<std::uint32_t,9> config(')]
assert oracle(host)==oracle((OLD/'m2_pair_leaf.cc').read_text(encoding='utf-8'))
save(W/'source-pins.json',{'private_source':[pin(W/p) for p in ('source/mmf.cuh','typed_mmf.cu','typed_leaf.cc','native-header.patch','prepare.py')],
 'reference_header':pin(REF),'coherent_native_root':str(COHERENT),
 'retained_harness':pin(OLD/'m2_pair_leaf.cc'),'oracle_sha256':hashlib.sha256(oracle(host).encode()).hexdigest(),
 'installed_or_retained_link_inputs':[pin(Path(x)) for x in commands['link'] if x.lower().endswith('.lib')]})
save(W/'plan.json',{'status':'SOURCE_READY_NOT_COMPILED_NOT_RUN','mechanism':'BF16 typed load/final RN on original TensorCore mul_mat_f; not SIMT mul_mat_vec_f or pair fusion.',
 'shape':{'M':2,'N':6144,'K':2048,'projections_per_pair':2},'math':'BF16 A/W/Y, original BF16 MMA with F32 tile accumulation and cross-warp F32 sum, final BF16 RN; no SiLU fusion or intermediate rounding change.',
 'native_geometry':{'grid':[192,1,1],'block':[32,8,1],'dynamic_shared_bytes':18432,'global_candidate_scratch':0,'ABI':'Only scalar/pointer leaf hook, no ggml context/tensor crosses runtime ABI; original header defaults unchanged.'},
 'inputs':{'original_roles':old['original_roles'],'activation':old['activation']},
 'banks':{'count':4,'weight_bytes_total':201326592,'same_physical_bytes_and_addresses':True,'candidate_extra_weights':0,'candidate_extra_outputs':0,'shared_workspace_cap':33554432},
 'protocol':{'jobs_per_graph':64,'trials_per_arm':5,'order':'alternating by trial','numeric':'Full independent original F64/gamma/BF16 gate for both roles in direct and first captured execution before timing; NaN output poison. No tolerance adaptation.','candidate_kernels_per_graph':128,'no_algorithm_grid':True},
 'commands':commands,'runtime':old['runtime'],'source_pins':pin(W/'source-pins.json'),
 'limits':['Retained real T23 prefill first2 A rows, not fresh current verifier A.','Private fixed SM89/non-indexed/dense geometry, no Model/provider route or task quality/TPS claim.','Existing F32 MMF and F32-A mixed precision not changed.','Coherent reference native headers expose compile-time math only; no old GGML runtime object/context/tensor is imported.','GPU execution requires ROOT release/authorization; compilation itself launches no model/GPU work.'],
 'actual_so_far':{'compiles':0,'links':0,'GPU':0,'HTTP':0,'product_edits':0}})
print(json.dumps({'host':pin(W/'typed_leaf.cc'),'CUDA':pin(W/'typed_mmf.cu'),'header':pin(W/'source/mmf.cuh'),'plan':pin(W/'plan.json')}))
