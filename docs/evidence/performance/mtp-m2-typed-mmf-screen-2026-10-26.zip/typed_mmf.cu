// Fixed TensorCore MMF leaf. Same MMA/reduction, typed BF16 A and terminal Y.
#include "mmf.cuh"
#include <cstdint>
#include <limits>

namespace {
constexpr int K=2048,N=6144,M=2,Warps=8,Shared=18432;
constexpr std::size_t WBytes=std::size_t(N)*K*2,ABytes=std::size_t(M)*K*2,YBytes=std::size_t(M)*N*2;
bool span(const void *p,std::size_t bytes)noexcept{
  const auto begin=reinterpret_cast<std::uintptr_t>(p);
  return p&&(begin&15)==0&&begin<=std::numeric_limits<std::uintptr_t>::max()-bytes;
}
bool overlaps(const void *a,std::size_t na,const void *b,std::size_t nb)noexcept{
  const auto x=reinterpret_cast<std::uintptr_t>(a),y=reinterpret_cast<std::uintptr_t>(b);
  return x<y+nb&&y<x+na;
}
}
extern "C" int hyle_mmf_m2_configure()noexcept{
  cudaFuncAttributes attributes{};
  const auto status=cudaFuncGetAttributes(&attributes,
    mul_mat_f<nv_bfloat162,32,M,Warps,false,nv_bfloat16,nv_bfloat16>);
  if(status!=cudaSuccess)return int(status);
  return attributes.maxThreadsPerBlock>=32*Warps&&attributes.maxDynamicSharedSizeBytes>=Shared
    ?int(cudaSuccess):int(cudaErrorInvalidConfiguration);
}
extern "C" int hyle_mmf_m2_launch(const void *w,const void *a,void *y,void *stream)noexcept{
  if(!stream||!span(w,WBytes)||!span(a,ABytes)||!span(y,YBytes)||
     overlaps(y,YBytes,w,WBytes)||overlaps(y,YBytes,a,ABytes))return int(cudaErrorInvalidValue);
  mul_mat_f<nv_bfloat162,32,M,Warps,false,nv_bfloat16,nv_bfloat16>
    <<<dim3(N/32,1,1),dim3(32,Warps,1),Shared,reinterpret_cast<cudaStream_t>(stream)>>>(
      static_cast<const nv_bfloat162*>(w),static_cast<const nv_bfloat16*>(a),nullptr,
      static_cast<nv_bfloat16*>(y),K/2,M,1,K/2,K/2,N,0,0,
      1,N*K/2,M*K,M*N,1,N*K/2,M*K,M*N);
  return int(cudaGetLastError());
}
