"""Small offline proposal. This script neither edits product nor builds/runs it."""
from pathlib import Path
import hashlib
import json
W = Path(__file__).resolve().parent
R = W.parents[1]
def read(p): return json.loads(Path(p).read_bytes())
def pin(p):
    p = Path(p).resolve(); body = p.read_bytes()
    return dict(path=str(p), bytes=len(body), sha256=hashlib.sha256(body).hexdigest())
model = R / 'engine/models/qwen35/main.cc'
assert pin(model)['sha256'] == '441ff48649cef90205d97f4fbbf71cdd73a4f06b1fdd9d85cbd4fd3ff64fffd3'
base = R / '.scratch/inference-stable-attention-20261027'
ready = read(base / 'ready-cli.json')
two = R / '.scratch/inference-stable-attention-window-20261027/attempt1/two-turn-timing/02-hyle_auto'
eos = R / '.scratch/inference-long-input-20261027/attempt1/p1024-timing/01-hyle_auto'
future = str(W / 'bin/hyle-cross-turn-warm-hints.exe')
cases = []
for name, source in [('natural-two-turn',two), ('natural-model-eos',eos)]:
    original = read(source / 'command.json')['command']
    cases.append(dict(name=name, source_command=pin(source/'command.json'),
        source_report=pin(source/'consumer-result.json'),
        future_command=[future,*original[1:]],
        expected_outputs=128 if name=='natural-two-turn' else 46,
        oracle_scope='Complete non-time semantic facts only; historical EOS image differs in attention closure, not a fresh timing control',
        budget='One candidate process only, no automatic rerun; root schedules actual GPU',
        performance_claim=False))
resets = [
    dict(lines=[5948,5959], context='reset/select on a changed key/turn cohort',
        proposal='Separate release_cohort from reset. Same carrier shape retains hints; actual ready/key/turn bindings are always rebuilt.'),
    dict(lines=[5970,5976], context='admission/release; called before next-turn prefill and completed-turn publication',
        proposal='admission clears ready/cohort without retaining a source; publish_turn uses an explicit completed-turn release retaining only warm hints. stop/evict/failure keeps the strong reset.'),
    dict(lines=[6250,6260], context='non-generation/prefill and other ordinary-continuation eligibility fallback',
        proposal='Ordinary same-owner prefill/full-hit clears cohort without erasing matching carrier hints. Disabled/permanent unavailable or incompatible execution mode remains a strong reset.'),
    dict(lines=[6268], context='ready no longer matches the complete original head/key/epoch',
        proposal='Keep strong reset; never reuse Source or skip matches.'),
    dict(lines=[6288,6371], context='abort/error or missing source sets permanent unavailable',
        proposal='Keep strong reset and original native abort/retirement.'),
    dict(lines=[6451], context='optional B tuple refusal',
        proposal='Keep strong reset; prime fresh real tuple through the original ready path.'),
    dict(lines=[6506,6508], context='turn-done/stop/failure terminal versus credit/yield drain',
        proposal='Only a normal fully retired published turn may retain hints; stop/failed/nonpublished/unavailable remains strong reset. Credit/yield release_ready already releases source without erasing hints.'),
    dict(lines=[6806,6819], context='common wave drain and retired recovery',
        proposal='Normal empty drain may clear cohort only; abort/failure/observe_only recovery keeps strong reset. Never clear pending_calls except after original real retirement.'),
    dict(lines=[7374], context='zero output credit',
        proposal='Existing release_ready is correct: source and slot released, hint is not delivery authority.')]
value = dict(status='DESIGN_ONLY_NOT_IMPLEMENTED_NOT_BUILT_NOT_RUN',
    source=pin(model), base_ready=pin(base/'ready-cli.json'),
    base_image_identity_from_retained_receipt=ready['image'],
    frozen_comparison_model='441ff48649cef90205d97f4fbbf71cdd73a4f06b1fdd9d85cbd4fd3ff64fffd3',
    scope='Preserve predictor metadata across ordinary turns, never ready state, slots, resources, credits or execution authority',
    patch=[
        'Add release_cohort(): release_ready(); members.clear(); no change to pending_calls, request grants or native owners.',
        'Keep reset() as strong invalidation: release_cohort(); direction_warm.fill(false); ready_steps=0; clear warm carrier scope.',
        'Retain one bounded warm carrier key: R and sampling_index of ordinary imported Text/T1/EmitNext in this same Model lifetime. This is a hint, not a new cache or ModelOps table. A scope change strongly clears hints before selecting members.',
        'For normal completed turn, ordinary prefill, and next-turn admission use cohort release, then rebuild the complete ordered member/turn identity. Do not change exact Source/head/epoch matching.',
        'Keep strong reset for failures/cancellation/eviction, permanent unavailability, explicit capture refusal, unexpected ready mismatch, changed carrier scope and teardown. Do not suppress a future Graph refusal based on warm hints.',
        'Saturate ready_steps at existing eligibility threshold6 instead of unbounded ++. No new per-turn statistics or control fields are required.'],
    authority_unchanged=[
        'imported still requires fresh continuation.matches or original resumed Step',
        'credits, remaining quota/context, cancellation, stop and cold report capacities remain checked',
        'B still uses prepare_relay_evaluations and full native tuple/private/Queue/Source permission checks',
        'original Step/Source keeps sole Completion; late EOS/cancel discards accepted B and waits real retirement',
        'no retained source/session/lease survives turn release solely for a hint'],
    reset_inventory=resets,
    finite_build=dict(CXX=1, links=1, NVCC=0, SDK_rebuilds=0,
        model_compile_recipe=pin(R/'.scratch/inference-wave-recovery-final-20261027/logs/model/command.json'),
        model_dependency_manifest=pin(R/'.scratch/inference-wave-recovery-final-20261027/compile/model/actual-dependencies.json'),
        link_inputs=pin(base/'cli-link-inputs.json'),
        replacement_object=read(R/'.scratch/inference-wave-recovery-final-20261027/ready-model.json')['compiled']['object'],
        link_scope='Replace only W17 Model object in current stable-attention224 closure; retain stable attention/CUDA/Graph/native closure exactly.',
        freeze='Before compiling, snapshot candidate main and each actual project include with one overlay root; pin toolchain/runtime. No current canonical header fallback and no mutation after actions start.'),
    future_functional_cases=cases,
    checks=[
        'Use the original sole-session normalization and exact retained full non_time predicate; preserve raw first comparison and all differences.',
        'Two-turn:128 IDs, turns, target rows/actual graph work, ledger/RNG/resource fields unchanged; no refusal. Changed successor submissions/publications are expected but not a speed measurement.',
        'EOS:46 exact output IDs and real EOS retained; accepted successor, if any, must be accounted as discarded after real retirement. Preserve actual changed work/counters instead of deleting fields.',
        'All real live versions/resources return to0. Warm hint cannot revive stopped requests or retain a Source after finish.',
        'Existing16-arm frozen probe is prior evidence only: a new Model CXX does not rebuild its include-main TU. Do not claim new complete-state/multi-request controls from running the old probe.'],
    unresolved=[
        'The current W18 complete40 window is not rerun. This design initially proposes2 finite candidate behavior processes only.',
        'The EOS oracle is earlier W17 attention closure, hence semantic comparison only; if unrelated physical reports differ, retain them and use one existing current-image EOS control only if root chooses.',
        'A one-Model-TU budget cannot add new include-main state-probe tests. Failure/cancel reset branches need source review; a fresh bytewise state probe would require an explicit additional TU, not a hidden run.',
        'Warm carrier hints may survive benign phase capture replacement; original Graph qualification remains the only authority. Conservative strong invalidation on refusal/error avoids repeated blind retries.',
        'Timing effect is unproven. Do not convert additional successors into a throughput claim.'])
W.mkdir(parents=True, exist_ok=True)
with (W/'plan.json').open('x',encoding='utf-8') as f: f.write(json.dumps(value,indent=2)+'\n')
print(json.dumps(dict(status=value['status'],plan=str(W/'plan.json'),model_sha=value['source']['sha256'],future_processes=len(cases))))
