"""One Model TU, one224-input link, two finite behavior checks; explicit actions.

Reuse corrected CLI helper/toolchain/runtime and exact existing header snapshots.
No action repeats the prior40 window, rebuilds a probe/native SDK, or retries.
"""
from pathlib import Path
import difflib
import importlib.util
import json
import sys
import time
import traceback
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent
ROOT=W.parents[1]
BASE=ROOT/'.scratch/inference-stable-attention-20261027/followup-user-cli'
spec=importlib.util.spec_from_file_location('corrected_user_cli_reuse',BASE/'build.py')
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
read,save,pin,exact,key=b.read,b.save,b.pin,b.exact,b.key

def environment():
    value=b.environment(); value['PATH']=str(W/'bin')+';'+value['PATH']; return value

def prepare():
    assert not (W/'model-plan.json').exists(),'Preserve first preparation'
    ready=read(BASE/'ready-cli.json'); current=ROOT/'engine/models/qwen35/main.cc'
    assert ready['compiled']['source']['sha256']=='4b6c914b08775667bb91ba01a1caf5c365a23eb9140d1ed378b537add8e4e854'
    old_source=ready['compiled']['snapshot'];exact(old_source)
    old=Path(old_source['path']).read_text(encoding='utf-8-sig'); new=current.read_text(encoding='utf-8-sig')
    assert old!=new and '--decode-overlap auto|off' not in new
    snapshot=W/'source/engine/models/qwen35/main.cc';snapshot.parent.mkdir(parents=True,exist_ok=True)
    with snapshot.open('xb') as f:f.write(current.read_bytes())
    actual=read(ready['compiled']['actual_dependencies']['path'])
    expected=[]
    for row in actual:
        if key(row['path'])==key(old_source['path']): continue
        exact(row);expected.append(row)
    # Original relative include roots remain immutable. Check their canonical
    # product counterparts before borrowing any old header byte.
    headers=[]
    for row in read(BASE/'source-freeze.json'):
        if key(row['original']['path'])==key(current): continue
        exact(row['original']);exact(row['snapshot']);headers.append(row)
    save(W/'reused-headers.json',headers)
    expected.append(pin(snapshot));save(W/'expected-model-dependencies.json',expected)
    out=W/'compile/model';template=read(BASE/'logs/model/command.json')['command'];command=[]
    for index,arg in enumerate(template):
        if index and template[index-1].lower()=='/sourcedependencies':arg=str(out/'dependencies.json')
        elif arg.lower().startswith('/fo'):arg='/Fo'+str(out/'unit.obj')
        elif arg.lower().startswith('/fd'):arg='/Fd'+str(out/'unit.pdb')
        elif arg.lower().endswith(('.cc','.cpp','.cxx')):arg=str(snapshot)
        command.append(arg)
    (W/'candidate.diff').write_text(''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='Model4b6c914',tofile='cross-turn-hints')),encoding='utf-8')
    save(W/'model-plan.json',dict(status='PREPARED_NOT_BUILT',source=pin(current),snapshot=pin(snapshot),
        base_ready=pin(BASE/'ready-cli.json'),base_model=ready['compiled'],base_inputs=ready['inputs'],base_recipe=ready['recipe'],
        reused_headers=pin(W/'reused-headers.json'),expected_dependencies=pin(W/'expected-model-dependencies.json'),
        recipe_source=pin(BASE/'logs/model/command.json'),command=command,script=pin(__file__),
        counts=dict(CXX=1,links=1,model_functional_checks=2,NVCC=0,probe_builds=0,SDK_builds=0),
        scope='Scheduling hints only. All old Source/key/head/epoch bindings are released at turn boundaries; no capture permission is inferred. No new TPS conclusion.'))
    print('PREPARED one Model snapshot and reused exact header closure; no CXX/link/model')

def validate():
    plan=read(W/'model-plan.json')
    for name in ('source','snapshot','base_ready','reused_headers','expected_dependencies','script','recipe_source'):exact(plan[name])
    for row in read(plan['reused_headers']['path']):exact(row['original']);exact(row['snapshot'])
    return plan

def compile_model():
    plan=validate();out=W/'compile/model';out.mkdir(parents=True,exist_ok=False)
    process=b.b.b.h.execute(plan['command'],environment(),W/'logs/model',timeout=240)
    data=read(out/'dependencies.json')['Data'];assert key(data['Source'])==key(plan['snapshot']['path'])
    expected={key(row['path']):row for row in read(plan['expected_dependencies']['path'])};actual=[]
    for path in dict.fromkeys([data['Source'],*data['Includes']]):
        row=pin(path);assert row==expected[key(path)],('Unexpected or changed dependency',path);actual.append(row)
    validate();save(out/'actual-dependencies.json',actual)
    save(out/'compiled.json',dict(source=plan['source'],snapshot=plan['snapshot'],object=pin(out/'unit.obj'),
        process=process,command=pin(W/'logs/model/command.json'),dependencies=pin(out/'dependencies.json'),actual_dependencies=pin(out/'actual-dependencies.json')))
    print('PASS one Model CXX')

def link_model():
    plan=validate(); compiled=read(W/'compile/model/compiled.json');exact(compiled['object'])
    exact(plan['base_inputs']);exact(plan['base_recipe']);original=read(plan['base_inputs']['path'])
    assert len(original)==224 and sum(row==plan['base_model']['object'] for row in original)==1
    inputs=[compiled['object'] if row==plan['base_model']['object'] else row for row in original]
    for row in inputs:exact(row)
    image=W/'bin/hyle-cross-turn-warm.exe';image.parent.mkdir(parents=True,exist_ok=True)
    assert not image.exists() and not (W/'link-model').exists(),'Preserve first link'
    command=[];replaced=0
    for arg in read(plan['base_recipe']['path'])['command']:
        if key(arg)==key(plan['base_model']['object']['path']):arg=compiled['object']['path'];replaced+=1
        for option,suffix in (('/OUT:','.exe'),('/PDB:','.pdb'),('/IMPLIB:','.lib'),('/MAP:','.map')):
            if arg.upper().startswith(option):arg=option+str(image.with_suffix(suffix));break
        command.append(arg)
    assert replaced==1;save(W/'link-inputs.json',inputs)
    process=b.b.b.h.execute(command,environment(),W/'link-model',timeout=180)
    save(W/'ready-model.json',dict(status='LINKED_NOT_RUN',image=pin(image),compiled=compiled,inputs=pin(W/'link-inputs.json'),
        recipe=pin(W/'link-model/command.json'),base_ready=plan['base_ready'],runtime=read(BASE/'ready-cli.json')['runtime'],
        process=process,plan=pin(W/'model-plan.json'),performance_claim=False))
    print('PASS one224-input Model-only link')

def run(name):
    assert name in ('two-turn','model-eos');plan=validate();ready=read(W/'ready-model.json');exact(ready['image'])
    previous=BASE/'model-two-turn' if name=='two-turn' else ROOT/'.scratch/inference-long-input-20261027/attempt1/p1024-timing/01-hyle_auto'
    command=[ready['image']['path'],*read(previous/'command.json')['command'][1:]]
    out=W/'runs'/name;assert not out.exists(),'Preserve every actual model process'
    process=b.b.b.h.execute(command,environment(),out,timeout=180)
    facts_spec=importlib.util.spec_from_file_location('retained_cross_turn_semantics',ROOT/'.scratch/inference-wave-recovery-final-20261027/run.py')
    facts=importlib.util.module_from_spec(facts_spec);facts_spec.loader.exec_module(facts)
    actual=read(out/'stdout.log');expected=read(previous/'stdout.log')
    changes=facts.changed(facts.facts.non_time(expected),facts.facts.non_time(actual))
    save(out/'consumer-result.json',actual);save(out/'complete-non-time-differences.json',changes)
    allowed={'/overlap_successor_submissions','/overlap_successor_publications'} if name=='two-turn' else set()
    assert all(row['path'] in allowed for row in changes),changes[:8]
    assert actual['live_committed_versions']==0 and actual['overlap_successor_refusals']==0
    if name=='two-turn':
        assert actual['overlap_successor_publications']>expected['overlap_successor_publications']
        assert actual['overlap_successor_publications']==actual['overlap_successor_submissions']
    save(out/'summary.json',dict(status='FINITE_NON_TIME_FACTS_PASS',process=process,image=ready['image'],
        oracle=pin(previous/'stdout.log'),complete_non_time_differences=changes,
        continuation={key:value for key,value in actual.items() if key.startswith('overlap_')},performance_claim=False,
        scope='Current final-user-CLI natural two-turn semantic control' if name=='two-turn' else 'Historical W17 natural46-output real EOS semantic oracle only; no current performance control'))
    print('PASS finite '+name+' facts; not a performance sample')

if __name__=='__main__':
    try:
        action=sys.argv[1]
        if action=='prepare':prepare()
        elif action=='compile':compile_model()
        elif action=='link':link_model()
        elif action=='run':run(sys.argv[2])
        else:raise ValueError(action)
    except BaseException:
        W.mkdir(parents=True,exist_ok=True)
        (W/('failure-'+ '-'.join(sys.argv[1:3])+'-'+str(time.time_ns())+'.log')).write_text(traceback.format_exc(),encoding='utf-8');raise
