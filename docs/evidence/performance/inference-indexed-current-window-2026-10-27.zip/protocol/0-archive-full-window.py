"""Offline extraction only: completed32, exact retained normalization, compact archive."""
from pathlib import Path
import ast
from datetime import datetime, timezone, timedelta
import hashlib
import json
import math
import zipfile

R = Path(__file__).resolve().parents[2]
W = Path(__file__).resolve().parent
D = W / 'full-window'
OLD = R / '.scratch/inference-current-closure-20261026/full-window'
BEHAVIOR = OLD.parent / 'behavior.py'
STEM = 'inference-indexed-current-window-2026-10-27'
ARMS = ('hyle_plain', 'hyle_mtp', 'peer_plain', 'peer_mtp')
LABELS = tuple(w + '-' + m for w in ('single', 'two-turn') for m in ('timing', 'memory'))
METRICS = ('prefill_tokens_per_second', 'full_decode_tokens_per_second',
           'session_output_tokens_per_second', 'weights_load_seconds',
           'startup_to_ready_seconds', 'first_token_elapsed_seconds', 'startup_to_endpoint_seconds')


def read(p):
    return json.loads(Path(p).read_text(encoding='utf-8-sig'))


def digest(raw):
    return dict(bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


def pin(p):
    p = Path(p)
    return dict(path=str(p.resolve()), **digest(p.read_bytes()))


def save(p, value):
    p.parent.mkdir(parents=True, exist_ok=True)
    if p.exists():
        assert read(p) == value, 'Preserve different prior offline extraction: ' + str(p)
        return
    p.write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + '\n', encoding='utf-8')


def stats(s):
    return {key: s[key] for key in ('count', 'median', 'min', 'max')}


def main():
    destination = R / 'docs/evidence/performance'
    out, archive = (destination / (STEM + suffix) for suffix in ('.json', '.zip'))
    assert not out.exists() and not archive.exists(), 'Preserve previous publication'
    ready, binding = read(D / 'ready.json'), read(D / 'binding.json')
    assert not ready['instrumented']
    assert ready['image']['sha256'] == 'd1cbcff43e554b8fd69d4e55566ae43dbbb22f62331d3595909f2635480620d7'
    assert binding['peer']['image']['sha256'] == '433e7051f4c36d0d9b2297dc378631546b7e3c44630cda0653cba2d1ec6bbe8e'
    # Never import behavior.py: its top level launches consumers.
    source = BEHAVIOR.read_text(encoding='utf-8')
    functions = [node for node in ast.parse(source).body
                 if isinstance(node, ast.FunctionDef) and node.name in ('normalize', 'differences')]
    assert {node.name for node in functions} == {'normalize', 'differences'}
    pure_source = '\n\n'.join(ast.get_source_segment(source, node) for node in functions) + '\n'
    namespace = {}
    exec(compile(ast.Module(body=functions, type_ignores=[]), str(BEHAVIOR) + ':pure-functions-only', 'exec'), namespace)
    compare_dir = W / 'offline-comparison'
    compare_dir.mkdir(exist_ok=True)
    pure_path = compare_dir / 'pure-functions.py'
    if pure_path.exists():
        assert pure_path.read_text(encoding='utf-8') == pure_source
    else:
        pure_path.write_text(pure_source, encoding='utf-8')
    summaries, runs, processes, comparisons, old_controls = {}, {}, [], [], {}
    for workload in ('single', 'two-turn'):
        old_rows = read(OLD / (workload + '-timing') / 'runs.json')
        for arm in ('hyle_plain', 'hyle_mtp'):
            old_controls[workload, arm] = next(row for row in old_rows if row['arm'] == arm)
    for label in LABELS:
        workload, mode = label.rsplit('-', 1)
        summaries[label], runs[label] = s, rows = read(D / label / 'summary.json'), read(D / label / 'runs.json')
        assert s['status'] == 'complete_stable_within_arm_work' and s['within_arm_fixed_work_valid']
        assert s['processes'] == len(rows) == (12 if mode == 'timing' else 4)
        assert s['baseline_date'] == '2026-10-25' and not s['historical_samples_pooled'] and not s['image_instrumented']
        for row in rows:
            p, observation, folder = row['process'], row['observation'], Path(row['folder'])
            assert folder.parent == D / label
            assert p['exit'] == 0 and not p['reader_errors'] and not p['profiler']
            assert p['memory_only'] == (mode == 'memory') and p['throughput_evidence'] == (mode == 'timing')
            assert p['image'] == (ready['image'] if row['arm'].startswith('hyle') else binding['peer']['image'])
            assert read(folder / 'observation.json') == observation
            assert all(math.isfinite(observation['metrics'][k]) and observation['metrics'][k] > 0 for k in METRICS)
            processes.append(dict(window=label, arm=row['arm'], pid=p['pid'], exit=p['exit'],
                started_unix_ns=p['started_unix_ns'], finished_unix_ns=p['finished_unix_ns'],
                memory_only=p['memory_only']))
            if row['arm'].startswith('hyle'):
                prior = old_controls[workload, row['arm']]
                delta = namespace['differences'](namespace['normalize'](prior['observation']['raw']),
                                                 namespace['normalize'](observation['raw']))
                path = compare_dir / label / (folder.name + '.json')
                save(path, delta)
                comparisons.append(dict(window=label, arm=row['arm'], process=folder.name,
                    previous_first_timing_observation=pin(Path(prior['folder']) / 'observation.json'),
                    current_observation=pin(folder / 'observation.json'), differences=pin(path),
                    difference_count=len(delta), changed_paths=[x['path'] for x in delta],
                    IDs_equal=prior['observation']['generated_ids'] == observation['generated_ids'],
                    work_counters_equal=prior['observation']['work'] == observation['work']))
    assert len(processes) == 32 and len(comparisons) == 16
    comparison = dict(source=pin(BEHAVIOR), extracted_pure_functions=pin(compare_dir / 'pure-functions.py'),
        method='AST loads only the exact normalize/differences definitions; no old module import or top-level execution.',
        reference='First retained timing observation for the same workload and Hyle arm, including comparison of each new independent memory observation.',
        results=comparisons, differences_total=sum(x['difference_count'] for x in comparisons),
        all_IDs_equal=all(x['IDs_equal'] for x in comparisons),
        all_work_counters_equal=all(x['work_counters_equal'] for x in comparisons))
    save(compare_dir / 'summary.json', comparison)
    table, fairness, memory_quality = [], {}, {}
    for workload in ('single', 'two-turn'):
        timing, memory = summaries[workload + '-timing'], summaries[workload + '-memory']
        fairness[workload] = dict(within_arm_timing=True, within_arm_memory=True,
            between_arm_first_outputs={k: {name: v[name] for name in ('left_tokens', 'right_tokens', 'equal', 'first_divergence')}
                                      | {'overlapping_mismatches': len(v['overlapping_mismatches'])}
                                      for k, v in timing['between_arm_first_process_outputs'].items()},
            memory_matches_timing_first={})
        for policy in ('plain', 'mtp'):
            line = dict(workload=workload, policy=policy)
            for side, arm in [('hyle', 'hyle_' + policy), ('llama_cpp', 'peer_' + policy)]:
                group, mem = timing['groups'][arm], memory['groups'][arm]
                first = next(row['observation'] for row in runs[workload + '-timing'] if row['arm'] == arm)
                independent = next(row['observation'] for row in runs[workload + '-memory'] if row['arm'] == arm)
                assert all(group[key]['count'] == 3 for key in METRICS)
                fairness[workload]['memory_matches_timing_first'][arm] = dict(
                    IDs=first['generated_ids'] == independent['generated_ids'], work=first['work'] == independent['work'])
                line[side] = dict(timing={key: stats(group[key]) for key in METRICS},
                    independent_memory_bytes=mem['sampled_peaks'], generated_tokens=first['actual_generated_tokens'],
                    stopped_on_EOS=first['stopped_on_EOS'], work={k: v for k, v in first['work'].items() if v is not None},
                    unreported_work_counters=[k for k, v in first['work'].items() if v is None])
                memory_quality[workload + '/' + arm] = dict(
                    requested_interval_seconds=mem['requested_interval_seconds'], sample_count=mem['sample_count'],
                    running_sample_count=mem['running_sample_count'], actual_sample_gaps_ms=stats(mem['actual_sample_gaps_ms']),
                    sample_cost_ms=stats(mem['sample_cost_ms']), null_sample_counts=mem['null_sample_counts'],
                    unavailable_reasons=mem['unavailable_reasons'], setup_error=mem['setup_error'],
                    thread_error=mem['thread_error'], counter_source=mem['counter_source'])
            line['hyle_relative_to_llama_percent'] = {key: (line['hyle']['timing'][key]['median'] /
                line['llama_cpp']['timing'][key]['median'] - 1) * 100 for key in METRICS[:3]}
            table.append(line)
    low, high = min(x['started_unix_ns'] for x in processes), max(x['finished_unix_ns'] for x in processes)
    stamp = lambda n, zone: datetime.fromtimestamp(n / 1e9, zone).isoformat()
    report = dict(status='COMPLETE32_STABLE_WITHIN_ARM', date='2026-10-27', process_count=32,
        timing_processes=24, independent_memory_processes=8,
        actual_window=dict(started_unix_ns=low, finished_unix_ns=high,
            started_UTC=stamp(low, timezone.utc), finished_UTC=stamp(high, timezone.utc),
            started_Asia_Shanghai=stamp(low, timezone(timedelta(hours=8))),
            finished_Asia_Shanghai=stamp(high, timezone(timedelta(hours=8)))),
        retained_protocol_baseline_date='2026-10-25',
        date_note='The old protocol baseline_date is an unchanged label, not this window date. Original clock fields/files are preserved.',
        hyle=ready, retained_peer=binding['peer'], binding=pin(D / 'binding.json'),
        protocol='Same retained four-arm single/two-turn plan, parser, original producer endpoints and independent observer; three unmonitored timing samples and one memory process per arm/workload. No old samples pooled.',
        timer=summaries['single-timing']['timer'], table=table, fairness_and_work=fairness,
        old_window_nonclock_comparison=dict(report=pin(compare_dir / 'summary.json'), comparisons=16,
            differences_total=comparison['differences_total'], IDs_equal=comparison['all_IDs_equal'],
            work_counters_equal=comparison['all_work_counters_equal'], reference_window=str(OLD),
            normalization='Exact old behavior.normalize/differences; no additional telemetry/plan/work exclusions.'),
        memory_measurement_quality=memory_quality, processes=processes,
        hardware_after_window=pin(W / 'hardware-after-window.txt'),
        hardware_observation='Post-window hardware identity only; no exclusive GPU, fixed frequency or thermal-control claim.',
        original_summary_pins={label: pin(D / label / 'summary.json') for label in LABELS},
        limits=['Named retained peer433e version; no latest-upstream assertion.',
            'Natural generated IDs, accepted drafts, target/draft rows and later histories differ across arms. These are complete natural consumer observations, not equal-mathematical-work speed or task-quality rankings.',
            'Rates are per-arm medians of3. All original samples/ranges and clocks are archived; no statistical-significance claim.',
            'Memory uses1 independent process per arm/workload, excluded from throughput medians. PDH/PSAPI sampled peaks are observations/lower bounds; dedicated/shared maxima and RAM/commit must not be summed as physical memory.',
            'Loading/ready retain original producer boundaries and existing OS file caches. Default report/IO cost remains inside its natural boundaries.',
            'Old-window nonclock equality does not make cross-day TPS deltas causal. No isolated optimization attribution, B2/multi-user throughput, other-model/backend/quantization or quality claim.'])
    members, origins = {}, {}
    def add(name, path):
        path = Path(path)
        assert name not in members and path.is_file() and path.suffix.lower() in {'.json', '.log', '.py', '.txt', '.ids', '.tsv'}
        members[name], origins[name] = path.read_bytes(), str(path.resolve())
    for name in ('ready.json', 'peer-ready.json', 'binding.json', 'arms.json'):
        add('binding/' + name, D / name)
    add('binding/hardware-after-window.txt', W / 'hardware-after-window.txt')
    add('binding/offline-export-attempt1.json', W / 'archive-attempt1.json')
    for name in ('adapter', 'protocol', 'original_arms', 'input_manifest', 'prompt', 'two_turn_schedule'):
        add('binding/actual-' + name + Path(binding[name]['path']).suffix, binding[name]['path'])
    for name in ('build', 'runtime_environment', 'link_inputs'):
        add('hyle/' + name + '.json', ready[name]['path'])
    for name in ('runtime_environment', 'link_plan'):
        add('peer/' + name + '.json', binding['peer'][name]['path'])
    protocol_files = [Path(__file__), BEHAVIOR, R / '.scratch/qwen-mtp-window-20261022/window.py',
        R / '.scratch/qwen-mtp-quality-20261022/current-window/performance.py',
        R / '.scratch/qwen-mtp-final-window-20261024/turns.py',
        R / '.scratch/shared-execution-20261021/observer.py',
        R / '.scratch/architecture-refactor-2026-10-18/d4-windows-preparation-2026-10-21/first-decode-startup-2026-10-21/multiturn/multiturn_run.py',
        R / '.scratch/architecture-refactor-2026-10-18/qwen-gpu-comparison/memory-probe/memory_probe.py',
        R / '.scratch/qwen-mtp-window-20261022/inputs/prompt.ids']
    for i, path in enumerate(protocol_files):
        add(f'protocol/{i}-{path.name}', path)
    for label in LABELS:
        for path in sorted((D / label).iterdir()):
            if path.is_file() and path.suffix in ('.json', '.log'):
                add('actual/' + label + '/' + path.name, path)
        for row in runs[label]:
            folder = Path(row['folder'])
            for path in sorted(folder.iterdir()):
                if path.is_file() and path.suffix in ('.json', '.log') and path.name != 'observation.json':
                    # Exact observations are already embedded in original runs.json.
                    add('actual/' + label + '/' + folder.name + '/' + path.name, path)
        add('binding/' + label + '-plan.json', D / (label + '-plan.json'))
    add('comparison/summary.json', compare_dir / 'summary.json')
    add('comparison/pure-functions.py', compare_dir / 'pure-functions.py')
    for row in comparisons:
        add('comparison/' + row['window'] + '/' + row['process'] + '.json', row['differences']['path'])
    for (workload, arm), row in old_controls.items():
        add('comparison/old-first-timing/' + workload + '-' + arm + '.json', Path(row['folder']) / 'observation.json')
    index = dict(members=[dict(member=name, original_path=origins[name], **digest(raw)) for name, raw in sorted(members.items())],
        exclusions='No binaries/objects/libraries/PDB, model payloads, full traces, SDK or dependency/source tree. Exact original observations embedded in runs.json; old first controls preserved for pure offline comparison.')
    index_bytes = (json.dumps(index, ensure_ascii=False, indent=2) + '\n').encode()
    destination.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for name, raw in sorted(members.items()):
            z.writestr(name, raw)
        z.writestr('member-sha256.json', index_bytes)
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None and len(z.namelist()) == len(members) + 1
        assert z.read('member-sha256.json') == index_bytes
        for name, raw in members.items():
            assert digest(z.read(name)) == digest(raw)
    report['archive'] = dict(**pin(archive), members=len(members) + 1, CRC_and_member_SHA256_verified=True)
    save(out, report)
    print(json.dumps(dict(report=pin(out), archive=report['archive'], nonclock_difference_count=comparison['differences_total'],
        table=[dict(workload=x['workload'], policy=x['policy'],
            hyle=[round(x['hyle']['timing'][k]['median'], 3) for k in METRICS[:3]],
            peer=[round(x['llama_cpp']['timing'][k]['median'], 3) for k in METRICS[:3]]) for x in table]), indent=2))


if __name__ == '__main__':
    main()
