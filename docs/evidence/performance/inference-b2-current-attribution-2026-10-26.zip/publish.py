"""Publish the completed finite paired diagnostic; never builds or runs a model."""
from pathlib import Path
import hashlib
import json
import subprocess
import zipfile

W = Path(__file__).resolve().parent
R = W.parents[1]
DEST = R / 'docs/evidence/performance'
NAME = 'inference-b2-current-attribution-2026-10-26'


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def digest(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


summary = read(W / 'summary.json')
review = read(W / 'independent-interval-review.json')
independent = read(W / 'independent-root-recalculation.json')
assert summary['status'] == 'FROZEN_OFFLINE_SUMMARY'
assert summary['input_quality']['status'] == 'PASS'
assert not review['blocking_findings']
assert (W / 'hyle/trace1/process.json').exists()
for arm in ('hyle', 'peer2'):
    process = read(W / arm / 'trace1/process.json')
    quality = read(W / arm / 'trace1/quality.json')
    assert process['exit'] == 0 and not process['timeout']
    assert quality['status'] == 'PASS' and quality['full_non_time_equal']
    assert quality['physical_roots'] == 99 and quality['decode'] == 96
for source_arm, independent_arm in (('hyle', 'hyle'), ('peer', 'peer2')):
    core = summary['engines'][source_arm]['root_groups']['all']
    checked = review['same_trace_clock_96decode'][independent_arm]
    for source_key, target_key in (('wall_ms', 'wall_ns'), ('GPU_union_ms', 'GPU_union_ns'),
                                   ('wall_without_observed_GPU_ms', 'uncovered_wall_ns')):
        assert abs(core[source_key] * 1000000 - checked[target_key]) < 0.1

target_zip = DEST / (NAME + '.zip')
target_json = DEST / (NAME + '.json')
assert not target_zip.exists() and not target_json.exists()
# Preserve exact source deltas, commands, failures, raw SQLite and original reports.
# Rebuildable binaries, duplicate native trace format and bytecode are omitted.
extensions = {'.json', '.log', '.cc', '.h', '.patch', '.py', '.sqlite'}
paths = sorted(p for p in W.rglob('*') if p.is_file() and p.suffix in extensions
               and p.name not in {'archive-receipt.json', 'archive-manifest.json'})
manifest = [dict(member=p.relative_to(W).as_posix(), bytes=p.stat().st_size,
                 sha256=digest(p)) for p in paths]
with zipfile.ZipFile(target_zip, 'w', zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
    for path, row in zip(paths, manifest):
        archive.write(path, row['member'])
    archive.writestr('archive-manifest.json', json.dumps(manifest, indent=2) + '\n')
with zipfile.ZipFile(target_zip) as archive:
    assert archive.testzip() is None
    assert set(archive.namelist()) == {row['member'] for row in manifest} | {'archive-manifest.json'}
    for row in manifest:
        data = archive.read(row['member'])
        assert len(data) == row['bytes'] and hashlib.sha256(data).hexdigest() == row['sha256']

engines = {}
for arm, value in summary['engines'].items():
    engines[arm] = dict(
        decode=value['root_groups']['all'],
        phases=value['inclusive_phases_do_not_add'],
        root_exclusive=value['root_exclusive_outside_top_level_phases'],
        graph_launch={group: {k: v for k, v in facts.items() if k != 'seqs'}
                      for group, facts in value['cudaGraphLaunch'].items()})
    engines[arm]['decode'].pop('seqs', None)
result = dict(
    schema='hyle.performance.evidence.v1', date='2026-10-26',
    status='PAIRED_DIAGNOSTIC_COMPLETED_NO_NEW_SPEED_PATCH',
    scope=summary['scope'],
    source_git_before_documentation=subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=R, text=True).strip(),
    protocol=dict(profiles=2, extra_model_runs=0, new_host_consumer_TUs=2,
                  new_Graph_or_device_or_SDK_builds=0, downloads=0,
                  workload='ordinary B2 teacher-forced: C1024 N2/R2 prefix off; three P256+32 turns/request; no MTP',
                  work='99 physical episodes, 1728 input rows, 198 equal IDs; full non-time reports equal to own unprofiled references'),
    baseline='Current-source Model dfaa530b / sampling085be10d, retained image41 CUDA closure; peer632 B2 consumer with same eight native libraries as peer433, not latest upstream.',
    engines=engines,
    interpretation=dict(
        root_wall_difference_ms=135.317190, GPU_union_difference_ms=12.311127,
        wall_without_observed_GPU_difference_ms=123.006063,
        priority='Identify redundant preparation, submission and post-completion result/state publication work before another GPU leaf replacement.',
        source_candidate='Each B2 ordinary episode has 72 GDN state retain calls; each calls Invocation::result and repeats the fixed-writer publication scan. A local optimization is being evaluated separately; no measured gain here.',
        head='Preliminary vocabulary-tail kernel signatures are similar in total time. Unique physical-node identification remains incomplete; no optimization or gain is selected from this observation.'),
    limits=[
        'One profiled process per engine. This is attribution, not a new throughput or memory comparison.',
        'GPU complement includes waiting, untraced work and profiler effects; it is not pure CPU self-time or recoverable time.',
        'Inclusive parents/children must not be added. cudaGraphLaunch time includes driver and instrumentation effects.',
        'Hyle root ends at original internal finished endpoint; peer ends after original outer sampling/publication. Native publication contracts and BF16/F32 intermediates differ.',
        'Recording/hot groups differ across engines; do not use their means as a paired throughput comparison.',
        'A failed peer host compile from an invalid external-include option is retained; the explicit corrected peer2 build and both actual profiles succeeded.',
        'Initial preliminary-costs.json *_ns totals were mislabeled milliseconds; superseded by final explicitly named ms and integer-ns facts.',
        'Existing formal ordinary/MTP and B2 unprofiled performance tables are unchanged.'
    ],
    independent_review=review['status'],
    archive=dict(path=target_zip.name, bytes=target_zip.stat().st_size,
                 sha256=digest(target_zip), members=len(manifest)+1,
                 verification='ZIP CRC and every member byte length/SHA256 checked at publication'))
target_json.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
(W / 'archive-receipt.json').write_text(json.dumps(result['archive'], indent=2) + '\n', encoding='utf-8')
print(json.dumps(dict(report=str(target_json), archive=result['archive']), indent=2))
