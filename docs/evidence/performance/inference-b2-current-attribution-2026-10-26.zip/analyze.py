"""Offline B2 interval analysis only. Never starts a model, build or profiler."""
from pathlib import Path
from collections import Counter, defaultdict
import hashlib
import json
import sqlite3

W = Path(__file__).resolve().parent


def read(p):
    return json.loads(p.read_text(encoding='utf-8-sig'))


def save(p, value):
    p.write_bytes((json.dumps(value, indent=2, ensure_ascii=False) + '\n').encode('utf8'))


def merged(xs):
    out = []
    for a, b in sorted(xs):
        if b <= a:
            continue
        if out and a <= out[-1][1]:
            out[-1][1] = max(b, out[-1][1])
        else:
            out.append([a, b])
    return out


def measure(xs):
    return sum(b - a for a, b in merged(xs))


def intersection(xs, ys):
    xs, ys = merged(xs), merged(ys)
    out, i, j = [], 0, 0
    while i < len(xs) and j < len(ys):
        a, b = xs[i]
        c, d = ys[j]
        if min(b, d) > max(a, c):
            out.append([max(a, c), min(b, d)])
        if b < d:
            i += 1
        else:
            j += 1
    return out


def subtract(xs, ys):
    out = []
    ys = merged(ys)
    for a, b in merged(xs):
        pos = a
        for c, d in ys:
            if d <= pos:
                continue
            if c >= b:
                break
            if c > pos:
                out.append([pos, min(c, b)])
            pos = max(pos, d)
        if pos < b:
            out.append([pos, b])
    return out


def intervals(rows):
    return [(x['start'], x['end']) for x in rows]


def overlaps(rows, a, b):
    return [x for x in rows if x['start'] < b and a < x['end']]


def metric(bounds, gpu, api):
    wall = measure(bounds)
    gu = measure(intersection(bounds, intervals(gpu)))
    au = measure(intersection(bounds, intervals(api)))
    return dict(wall_ns=wall, GPU_union_ns=gu,
                wall_without_observed_GPU_ns=wall-gu,
                API_library_union_ns=au, wall_outside_API_library_ns=wall-au)


def add_metrics(rows):
    keys = ('wall_ns', 'GPU_union_ns', 'wall_without_observed_GPU_ns',
            'API_library_union_ns', 'wall_outside_API_library_ns')
    return {k: sum(x[k] for x in rows) for k in keys}


def one(arm):
    F = W / arm / 'trace1'
    assert read(F / 'quality.json')['status'] == 'PASS'
    roots = read(F / 'physical-roots.json')
    assert len(roots) == 99
    con = sqlite3.connect('file:' + (F / 'trace.sqlite').as_posix() + '?mode=ro', uri=True)
    con.row_factory = sqlite3.Row
    nvtx = [dict(x) for x in con.execute('SELECT n.*,COALESCE(n.text,s.value) label FROM NVTX_EVENTS n LEFT JOIN StringIds s ON s.id=n.textId ORDER BY n.start')]
    nvtx = [x for x in nvtx if x['end'] is not None and x['label']]
    tables = {x[0] for x in con.execute("SELECT name FROM sqlite_master WHERE type='table'")}
    apis = []
    for table in ('RUNTIME', 'DRIVER'):
        if 'CUPTI_ACTIVITY_KIND_' + table in tables:
            apis += [dict(x) for x in con.execute('SELECT a.*,s.value api FROM CUPTI_ACTIVITY_KIND_' + table + ' a JOIN StringIds s ON s.id=a.nameId ORDER BY a.start')]
    gpu = []
    for table in ('KERNEL', 'MEMCPY', 'MEMSET'):
        gpu += [dict(x, kind=table) for x in con.execute('SELECT * FROM CUPTI_ACTIVITY_KIND_' + table + ' ORDER BY start')]
    con.close()
    prefix = 'hyle/' if arm == 'hyle' else 'peer/'
    phase_labels = ([prefix+x for x in ('prepare', 'prepare_replay', 'submit', 'wait_publish', 'completion_wait', 'postwait_publish')]
                    if arm == 'hyle' else [prefix+x for x in ('prepare', 'llama_decode', 'synchronize', 'sample_publish')])
    top_labels = [prefix+x for x in ('prepare', 'submit', 'wait_publish')] if arm == 'hyle' else phase_labels
    label_index = {x['label']: x for x in nvtx}
    results, launch_rows, stages = [], [], defaultdict(list)
    for root in roots:
        a, b, tid = root['start_ns'], root['end_ns'], root['globalTid']
        exact = label_index[root['label']]
        assert (a, b, tid) == (exact['start'], exact['end'], exact['globalTid'])
        process = tid & ~((1 << 24)-1)
        rg = [x for x in overlaps(gpu, a, b) if x['globalPid'] == process]
        assert all(a <= x['start'] and x['end'] <= b for x in rg)
        ra = [x for x in overlaps(apis, a, b) if x['globalTid'] == tid]
        library = [x for x in nvtx if x['globalTid'] == tid and x['label'].lower().startswith('cublas') and x['start'] < b and a < x['end']]
        all_api = ra + library
        phases = [x for x in nvtx if x['globalTid'] == tid and x['label'] in phase_labels and a <= x['start'] and x['end'] <= b]
        assert len(phases) == len(phase_labels)
        counts = Counter(x['api'] for x in ra)
        recorded = any('StreamBeginCapture' in k for k in counts)
        top = [x for x in phases if x['label'] in top_labels]
        assert measure(intervals(top)) == sum(x['end']-x['start'] for x in top)
        exclusive = subtract([(a, b)], intervals(top))
        row = dict(meta=root['meta'], start_ns=a, end_ns=b,
                   record=recorded, root=metric([(a, b)], rg, all_api),
                   root_exclusive_outside_top_level_phases=metric(exclusive, rg, all_api),
                   phases={}, capture_API_counts={k:v for k,v in counts.items() if any(s in k for s in ('StreamBeginCapture', 'StreamEndCapture', 'GraphInstantiate', 'GraphExecUpdate', 'GraphLaunch'))})
        for p in phases:
            x = metric([(p['start'], p['end'])], rg, all_api)
            row['phases'][p['label']] = x
            if root['meta']['kind'] == 'decode':
                stages[p['label']].append(x)
        for call in (x for x in ra if 'cudaGraphLaunch' in x['api']):
            bounds = [(call['start'], call['end'])]
            correlated = [x for x in rg if x['correlationId'] == call['correlationId']]
            ag = measure(intersection(bounds, intervals(rg)))
            cg = measure(intersection(bounds, intervals(correlated)))
            launch_rows.append(dict(seq=root['meta']['seq'], kind=root['meta']['kind'], record=recorded,
                correlationId=call['correlationId'], returnValue=call.get('returnValue'),
                API_start_from_root_ns=call['start']-a, API_end_from_root_ns=call['end']-a,
                API_wall_ns=call['end']-call['start'], root_GPU_overlap_union_ns=ag,
                API_without_observed_GPU_ns=call['end']-call['start']-ag,
                correlated_GPU_activities=len(correlated), correlated_GPU_overlap_union_ns=cg,
                first_correlated_GPU_start_from_API_return_ns=min((x['start'] for x in correlated), default=call['end'])-call['end'] if correlated else None))
        results.append(row)
    decode = [x for x in results if x['meta']['kind'] == 'decode']
    assert len(decode) == 96
    launch = [x for x in launch_rows if x['kind'] == 'decode']
    launch_groups = {}
    for group, selected in [('all', launch), ('record', [x for x in launch if x['record']]), ('hot', [x for x in launch if not x['record']])]:
        launch_groups[group] = dict(count=len(selected), seqs=[x['seq'] for x in selected],
            **{k:sum(x[k] for x in selected) for k in ('API_wall_ns', 'root_GPU_overlap_union_ns', 'API_without_observed_GPU_ns', 'correlated_GPU_overlap_union_ns')},
            zero_correlated_GPU_launches=sum(not x['correlated_GPU_activities'] for x in selected),
            first_correlated_GPU_started_before_API_return=sum(x['first_correlated_GPU_start_from_API_return_ns'] is not None and x['first_correlated_GPU_start_from_API_return_ns'] < 0 for x in selected))
    group_roots = {}
    for label, selected in [('all', decode), ('record', [x for x in decode if x['record']]), ('hot', [x for x in decode if not x['record']])]:
        group_roots[label] = dict(count=len(selected), seqs=[x['meta']['seq'] for x in selected], **add_metrics([x['root'] for x in selected]))
    return dict(API_tables_present=sorted(x for x in tables if x in ('CUPTI_ACTIVITY_KIND_RUNTIME','CUPTI_ACTIVITY_KIND_DRIVER')), root_groups=group_roots, decode_inclusive_phases_do_not_add={k:add_metrics(v) for k,v in stages.items()},
        decode_root_exclusive_outside_top_level_phases=add_metrics([x['root_exclusive_outside_top_level_phases'] for x in decode]),
        cudaGraphLaunch_groups=launch_groups, decode_rows=decode, cudaGraphLaunch_timeline=launch_rows)


def main():
    facts = dict(status='FROZEN_OFFLINE_B2_TRACE_FACTS', units='All *_ns fields are integer nanoseconds.',
                 sources={'hyle':'hyle/trace1/trace.sqlite', 'peer':'peer2/trace1/trace.sqlite'},
                 hyle=one('hyle'), peer=one('peer2'))
    independent = read(W / 'independent-root-recalculation.json')['results']
    for out, key in [('hyle','hyle'), ('peer','peer2')]:
        actual = facts[out]['root_groups']['all']
        expected = independent[key]['decode']
        for a,b in [('wall_ns','wall_ns'), ('GPU_union_ns','GPU_union_ns'), ('wall_without_observed_GPU_ns','uncovered_wall_ns')]:
            assert actual[a] == expected[b], (out,a,actual[a],expected[b])
        for label, p in facts[out]['decode_inclusive_phases_do_not_add'].items():
            for k in ('wall_ns','GPU_union_ns'):
                assert p[k] == expected['inclusive_phase_totals_do_not_add'][label][k]
    save(W / 'facts.json', facts)
    summary = dict(status='FROZEN_OFFLINE_SUMMARY', units='milliseconds explicitly named *_ms; original integer ns in facts.json',
        scope='One instrumented process per engine; identical teacher-forced 99 physical R2 episodes, 3 prefill and 96 decode, 1728 input rows, 198 equal decisions. Not TPS or natural MTP acceptance.',
        phase_safety='Inclusive prepare_replay is inside prepare; completion_wait and postwait_publish are inside wait_publish. Only disjoint top-level phases may be added.',
        preliminary_correction='preliminary-costs.json is superseded: its *_ns totals were actually milliseconds. It is retained unchanged as the initial draft.',
        input_quality=read(W / 'pair-quality.json'), engines={})
    for arm in ('hyle','peer'):
        f = facts[arm]
        ms = lambda x: {k[:-3]+'_ms':v/1e6 for k,v in x.items() if k.endswith('_ns') and isinstance(v,int)}
        summary['engines'][arm] = dict(root_groups={k:dict(count=v['count'],seqs=v['seqs'],**ms(v)) for k,v in f['root_groups'].items()},
            API_tables_present=f['API_tables_present'],
            inclusive_phases_do_not_add={k:ms(v) for k,v in f['decode_inclusive_phases_do_not_add'].items()},
            root_exclusive_outside_top_level_phases=ms(f['decode_root_exclusive_outside_top_level_phases']),
            cudaGraphLaunch={k:dict(count=v['count'], seqs=v['seqs'], **ms(v),
                zero_correlated_GPU_launches=v['zero_correlated_GPU_launches'],
                first_correlated_GPU_started_before_API_return=v['first_correlated_GPU_started_before_API_return']) for k,v in f['cudaGraphLaunch_groups'].items()})
    summary['decision'] = dict(head='DOWNGRADED: preliminary vocab-tail signatures have near-equal total kernel durations (H 221.304 ms, peer 223.378 ms). Unique node proof incomplete; not used to choose an optimization.',
        next_source_seam='Hyle Model::finish completion_wait -> postwait_publish -> retain_output -> Invocation::result. The latter scans the fixed caller bindings and publishes every still-valid writer for each requested output (resources.cc:1718-1728). Check whether successful publication can be remembered by the existing ResourceEpisode with correct mutation invalidation; no new owner/cache. Phase 32.908 ms wall, almost no observed GPU, 29.785 ms outside visible API/library. This is a bounded candidate envelope, not measured scan cost or proved removable CPU cost.',
        no_claims=['Root GPU complement is not pure CPU self-time.', 'cudaGraphLaunch duration includes instrumentation/driver behavior; do not subtract engine totals to claim removable host cost.', 'Different recording/hot bags and engine endpoints prevent paired-speed claims from bag means.', 'No new profile, benchmark, build or product change was performed by this analyzer.'])
    save(W / 'summary.json', summary)
    memo = dict(status='FROZEN_BOUNDED_B2_ATTRIBUTION',
        work='New pair only: 99 physical R2 roots per engine, 3 prefill + 96 decode, 1728 input rows and 198 equal decisions; teacher-forced inputs, not natural MTP acceptance.',
        main_fact_ms=dict(Hyle_wall=1279.679368,peer_wall=1144.362178,
            Hyle_GPU_union=1037.306757,peer_GPU_union=1024.995630,
            Hyle_wall_without_observed_GPU=242.372611,peer_wall_without_observed_GPU=119.366548,
            wall_difference=135.317190,GPU_union_difference=12.311127,
            complement_difference=123.006063),
        phase_comparison='Phase roots differ in completion definition: Hyle common Model finish includes checked selected-state publication; peer llama_decode/synchronize/sample_publish is its original boundary. Parent/child phases are inclusive; do not add prepare_replay to prepare or completion/postwait to wait_publish.',
        launch='Hyle 96 launches 79.449412 ms, observed root GPU overlap 0.026880 ms; peer 93 launches 53.463922 ms, overlap 0. Both have 90 hot launches at exactly the same physical seqs: H 74.042203 ms and peer 51.659555 ms. All correlated graph activities start after the API return. The API interval includes driver/profiler behavior and is not proved CPU self-time or removable cost.',
        recording='Actual BeginCapture grouping: H 6 record roots at seq 2,3,35,36,68,69 and 90 non-record; peer 3 at seq 3,36,69 and 93 non-record. Peer non-record also includes 3 eager/no-GraphLaunch roots at seq 2,35,68; do not call all 93 hot replay.',
        root_exclusive='Outside the disjoint top-level stage union: Hyle 0.312665 ms, peer 0.440929 ms. This does not support a large outer Graph/request-loop overhead claim.',
        priority=summary['decision']['next_source_seam'],
        head=summary['decision']['head'],
        source_anchors=[dict(path='engine/models/qwen35/main.cc',line=3953,why='Original completion wait and following selected-state/result publication.'),
            dict(path='src/graph/resources.cc',line=1695,why='Invocation::result output checks and repeated fixed binding publication scan.'),
            dict(path='src/graph/resources.cc',line=1718,why='Existing ResourceEpisode is the scope in which a publication fact could naturally live.')],
        evidence_limits=['No new GPU/model/build/trace was run for this analysis.',
            'Hyle and peer BF16/F32 intermediate policies differ; equal IDs are not bitwise math or quality equivalence.',
            'Activity union is clipped to each observed interval; overlapping kernels/API/library intervals are never added.',
            'No old N1 clock or unprofiled TPS is subtracted from this trace.',
            'No head/whole-kernel inventory expansion; no native route/kernel/Graph capture eligibility change proposed.',
            'Initial preliminary-costs.json uses misleading *_ns names for ms and is superseded by integer-ns facts.json.',
            'Driver table absence is reported per engine. Visible API/library complement is unobserved wall, not proven host work.'],
        references=['facts.json','summary.json','independent-root-recalculation.json','independent-interval-review.json','offline-analysis-first-failure.json'])
    save(W / 'memo.json', memo)
    def pin(path):
        data=path.read_bytes()
        return dict(path=str(path.relative_to(W)) if path.is_relative_to(W) else str(path),bytes=len(data),sha256=hashlib.sha256(data).hexdigest())
    save(W / 'analysis-pins.json', dict(status='FINAL_FROZEN_ANALYSIS_HANDOFF', files=[pin(W/x) for x in (
        'analyze.py','facts.json','summary.json','memo.json','offline-analysis-first-failure.json',
        'independent-root-recalculation.json','independent-interval-review.json')]))
    print(json.dumps({'status':'FROZEN_OFFLINE_ONLY','files':[pin(W/x) for x in ('analyze.py','facts.json','summary.json','memo.json','analysis-pins.json')]},indent=2))


if __name__ == '__main__':
    main()
