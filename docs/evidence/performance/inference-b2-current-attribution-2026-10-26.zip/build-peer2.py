"""Root-only corrected peer include qualification. Never rebuilds Hyle."""
from pathlib import Path
import importlib.util
import sys

sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('original_B2_build',W/'build.py')
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
m=b.m;h=b.h

def build():
    F=W/'peer2';plan=m.read(W/'plan.json');correction=m.read(F/'correction.json')
    for row in correction['frozen_inputs']:m.exact(row)
    m.exact(correction['build_plan'])
    if (F/'compile').exists() or (F/'link').exists():raise FileExistsError('Retain failure; no automatic retry')
    recipe=m.read(F/'build-plan.json');source=m.read(W/'source-pins.json')
    for row in source['files']:
        for field in ('before','after','patch'):m.exact(row[field])
    m.exact(source['helper'])
    for row in source['peer_exact_support']:
        m.exact(row['compile_input']);m.exact(row['cached_source'])
        assert (row['compile_input']['bytes'],row['compile_input']['sha256'])==(row['original']['bytes'],row['original']['sha256'])
    original=m.read(W/'baseline-dependencies.json')['peer']
    for row in original:m.exact(row['compile_input'])
    inputs=m.read(W/'baseline-link-inputs.json')['peer']
    for row in inputs:m.exact(row)
    compiler=recipe['compile'][0]
    env=h.discover_environment(compiler='msvc',cache={'CMAKE_C_COMPILER':compiler,
        'CMAKE_CXX_COMPILER':compiler,'CMAKE_GENERATOR':'Ninja'},backends=()).env
    compiled=h.execute(recipe['compile'],env,F/'compile',timeout=120)
    dep=m.read(F/'compile/dependencies.json')['Data']
    actual=[m.pin(p) for p in dict.fromkeys([dep['Source'],*dep['Includes']])]
    peer_source=m.read(m.P/'identity.json')['source']['path']
    def canonical(p):
        p=Path(p)
        if p.is_relative_to(W/'peer/source'):
            rel=p.relative_to(W/'peer/source')
            return m.key(peer_source if rel.as_posix()=='peer-batch.cc' else m.R/rel)
        return m.key(p)
    baseline={canonical(x['original']['path']):x['original'] for x in original}
    current={canonical(x['path']):x for x in actual}
    assert set(baseline)<=set(current),set(baseline)-set(current)
    changes={k for k in baseline if baseline[k]['sha256']!=current[k]['sha256']}
    assert changes=={m.key(peer_source)},changes
    assert m.key(W/'logical_trace.h') in current
    for row in source['peer_exact_support']:
        assert m.key(row['compile_input']['path']) in {m.key(x['path']) for x in actual}
        assert current[m.key(row['original']['path'])]['sha256']==row['original']['sha256']
    m.save(F/'compile/actual-dependencies.json',actual)
    m.save(F/'compile/dependency-contract.json',dict(original=len(baseline),actual=len(current),
        original_dependency_set_preserved=True,changed_only_source=sorted(changes),
        added=[x for k,x in current.items() if k not in baseline],exact_old_headers=source['peer_exact_support']))
    obj=m.pin(F/'compile/unit.obj')
    new_inputs=[obj if m.key(x['path'])==m.key(recipe['baseline_object']['path']) else x for x in inputs]
    m.save(F/'link-inputs.json',new_inputs)
    m.save(F/'link-contract.json',dict(original_recipe=recipe['original_link_recipe'],replaced=recipe['baseline_object'],
        unchanged_absolute_inputs=recipe['retained_inputs'],retained_count=8,consumer_TUs=1,SDK_Graph_native_builds=0))
    linked=h.execute(recipe['link'],env,F/'link',timeout=120)
    for row in recipe['retained_inputs']:m.exact(row)
    runtime=m.read(plan['runtime']['peer']['path']);m.save(F/'runtime.json',runtime)
    m.save(F/'ready.json',dict(status='B2_NVTX_PEER2_BUILT_NOT_PROFILED',image=m.pin(F/'link/consumer.exe'),app=obj,
        source=recipe['source'],source_pins=plan['source_pins'],actual_dependencies=m.pin(F/'compile/actual-dependencies.json'),
        link_inputs=m.pin(F/'link-inputs.json'),runtime=m.pin(F/'runtime.json'),compile=compiled,link=linked,
        baseline_ready=plan['baseline_ready']['peer'],include_correction=m.pin(F/'correction.json'),
        new_host_TUs=1,SDK_Graph_native_builds=0,model_runs=0,scope='Identical peer632NVTXsource/helper; only newly-added CUDA include qualification corrected; Hyle not rebuilt'))
    print('peer2 READY',m.pin(F/'ready.json'),flush=True)

if __name__=='__main__':build()
