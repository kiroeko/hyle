"""Explicit Root-only action: one consumer hostTU+retained link per arm."""
from pathlib import Path
import importlib.util
import os
import sys

sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent
R=W.parents[1]

def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path)
    mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod);return mod

m=load('b2_frozen_preparation',W/'prepare.py')
h=load('retained_consumer_execution',R/'.scratch/inference-synchronous-step-report-20261025/check_host.py')

def build(arm):
    assert arm in ('hyle','peer')
    plan=m.read(W/'plan.json');F=W/arm
    for field in ('source_pins','baseline_dependencies','baseline_link_inputs','expected_work','work_gate_source'):
        m.exact(plan[field])
    m.exact(plan['build_plans'][arm]);m.exact(plan['baseline_ready'][arm]);m.exact(plan['runtime'][arm])
    if (F/'compile').exists() or (F/'link').exists():
        raise FileExistsError('One build per arm; preserve failures, no automatic retry')
    source=m.read(W/'source-pins.json')
    for row in source['files']:
        for key in ('before','after','patch'):m.exact(row[key])
    m.exact(source['helper'])
    for row in source['peer_exact_support']:
        m.exact(row['cached_source']);m.exact(row['compile_input'])
        assert (row['compile_input']['bytes'],row['compile_input']['sha256'])==(row['original']['bytes'],row['original']['sha256'])
    original=m.read(W/'baseline-dependencies.json')[arm]
    for row in original:m.exact(row['compile_input'])
    inputs=m.read(W/'baseline-link-inputs.json')[arm]
    for row in inputs:m.exact(row)
    recipe=m.read(plan['build_plans'][arm]['path'])
    compiler=recipe['compile'][0]
    env=h.discover_environment(compiler='msvc',cache={'CMAKE_C_COMPILER':compiler,
        'CMAKE_CXX_COMPILER':compiler,'CMAKE_GENERATOR':'Ninja'},backends=()).env
    compiled=h.execute(recipe['compile'],env,F/'compile',timeout=120)
    dep=m.read(F/'compile/dependencies.json')['Data']
    actual=[m.pin(p) for p in dict.fromkeys([dep['Source'],*dep['Includes']])]
    peer_source=m.read(m.P/'identity.json')['source']['path']
    def canonical(p):
        p=Path(p)
        if arm=='hyle':
            for root in (F/'source',m.H/'source'):
                if p.is_relative_to(root):return m.key(R/p.relative_to(root))
        elif p.is_relative_to(F/'source'):
            rel=p.relative_to(F/'source')
            return m.key(peer_source if rel.as_posix()=='peer-batch.cc' else R/rel)
        return m.key(p)
    baseline={canonical(x['original']['path']):x['original'] for x in original}
    current={canonical(x['path']):x for x in actual}
    assert set(baseline)<=set(current),('Missing original dependency',set(baseline)-set(current))
    changes={k for k in baseline if baseline[k]['sha256']!=current[k]['sha256']}
    expected=m.key(R/'engine/models/qwen35/main.cc') if arm=='hyle' else m.key(peer_source)
    assert changes=={expected},changes
    assert m.key(W/'logical_trace.h') in current
    if arm=='peer':
        for row in source['peer_exact_support']:
            assert m.key(row['compile_input']['path']) in {m.key(x['path']) for x in actual}
            assert current[m.key(row['original']['path'])]['sha256']==row['original']['sha256']
    m.save(F/'compile/actual-dependencies.json',actual)
    m.save(F/'compile/dependency-contract.json',dict(original=len(baseline),actual=len(current),
        original_dependency_set_preserved=True,changed_only_source=sorted(changes),
        added=[x for k,x in current.items() if k not in baseline],peer_original_headers_restored=source['peer_exact_support'] if arm=='peer' else [],
        no_SDK_or_other_TU_build=True))
    object_pin=m.pin(F/'compile/unit.obj')
    new_inputs=[object_pin if m.key(x['path'])==m.key(recipe['baseline_object']['path']) else x for x in inputs]
    assert sum(m.key(x['path'])==m.key(object_pin['path']) for x in new_inputs)==1
    for row in new_inputs:m.exact(row)
    m.save(F/'link-inputs.json',new_inputs)
    m.save(F/'link-contract.json',dict(original_recipe=recipe['original_link_recipe'],replaced=recipe['baseline_object'],
        unchanged_absolute_inputs=recipe['retained_inputs'],retained_count=len(recipe['retained_inputs']),consumer_TUs=1,
        original_formal_entry_retained=arm=='hyle',SDK_Graph_native_builds=0))
    linked=h.execute(recipe['link'],env,F/'link',timeout=120)
    for row in recipe['retained_inputs']:m.exact(row)
    runtime=m.read(plan['runtime'][arm]['path'])
    if arm=='hyle':
        m.exact(runtime['native'])
        alias=F/'link'/Path(runtime['native_hardlink']['path']).name
        os.link(runtime['native']['path'],alias);runtime['native_hardlink']=m.pin(alias)
    m.save(F/'runtime.json',runtime)
    m.save(F/'ready.json',dict(status='B2_NVTX_CONSUMER_BUILT_NOT_PROFILED',image=m.pin(F/'link/consumer.exe'),
        app=object_pin,source=recipe['source'],source_pins=plan['source_pins'],actual_dependencies=m.pin(F/'compile/actual-dependencies.json'),
        link_inputs=m.pin(F/'link-inputs.json'),runtime=m.pin(F/'runtime.json'),compile=compiled,link=linked,
        baseline_ready=plan['baseline_ready'][arm],new_host_TUs=1,SDK_Graph_native_builds=0,model_runs=0,
        scope='Only private consumer NVTX delta; Hyle formal Modeldfaa/sampling085 plus retained entry/weights/report/core; peer632exact source/support/native closure; not N1 reference consumer433'))
    print(arm,'READY',m.pin(F/'ready.json'),flush=True)

if __name__=='__main__':build(sys.argv[1])
