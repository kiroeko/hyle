"""Prepare exactly two consumer NVTX overlays/recipes. Never builds or runs."""
from pathlib import Path
import difflib
import hashlib
import json
import os
import sys

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = W.parents[1]
B = R / '.scratch/inference-b2-current-window-20261026'
H = R / '.scratch/inference-sampling-three-arm-20261026/batch'
P = R / '.scratch/qwen-cli-batch-20261022/peer/checks/attempt1'
NSYS = Path('C:/Program Files/NVIDIA Corporation/Nsight Systems 2026.1.3/target-windows-x64/nsys.exe')

def read(p):
    return json.loads(Path(p).read_bytes())

def save(p, value):
    p=Path(p);p.parent.mkdir(parents=True,exist_ok=True)
    p.write_bytes((json.dumps(value,indent=2)+'\n').encode())

def pin(p):
    p=Path(p).resolve();data=p.read_bytes()
    return dict(path=str(p),bytes=len(data),sha256=hashlib.sha256(data).hexdigest())

def key(p):
    return os.path.normcase(str(Path(p).resolve()))

def exact(row):
    assert pin(row['path'])==row, row['path']

def replace(s,old,new):
    assert s.count(old)==1,(old[:100],s.count(old))
    return s.replace(old,new)

def source(arm,relative,raw,after):
    before=W/arm/'before'/relative;before.parent.mkdir(parents=True,exist_ok=True);before.write_bytes(raw)
    path=W/arm/'source'/relative;path.parent.mkdir(parents=True,exist_ok=True)
    newline='\r\n' if b'\r\n' in raw else '\n'
    path.write_bytes(after.replace('\n',newline).encode())
    patch=''.join(difflib.unified_diff(raw.decode().splitlines(True),path.read_bytes().decode().splitlines(True),
        fromfile='a/'+relative,tofile='b/'+relative))
    (W/arm/'source.patch').write_bytes(patch.encode())
    return dict(arm=arm,path=relative,before=pin(before),after=pin(path),patch=pin(W/arm/'source.patch'))

def prepare():
    if (W/'plan.json').exists():raise FileExistsError('Frozen B2 plan exists; no implicit regeneration')
    hready=read(H/'ready.json');pready=read(R/'.scratch/qwen-cli-batch-20261022/peer-ready.json')
    assert hready['image']['sha256'].startswith('41ce916d') and pready['image']['sha256'].startswith('632cc09c')
    for row in (hready['image'],hready['app'],hready['actual_dependencies'],hready['link_inputs'],hready['runtime'],pready['image'],pready['source'],pready['compile_identity'],pready['link_plan'],pready['runtime_environment']):exact(row)
    main=H/'source/engine/models/qwen35/main.cc';raw=main.read_bytes()
    assert pin(main)['sha256']==pin(R/'engine/models/qwen35/main.cc')['sha256']=='dfaa530b2148a31d3834f0b62c4f123d5fc6983be9f37652395269db2b69dfc6'
    s=raw.decode().replace('\r\n','\n')
    s=replace(s,'#include <algorithm>','#include "logical_trace.h"\n#include <algorithm>')
    s=replace(s,'int qwen35::run(int argc, char **argv) {',
        'int qwen35::run(int argc, char **argv) {\n  [[maybe_unused]] logical_trace::RunScope trace_process;')
    s=replace(s,'    const auto step_start = Clock::now();',
        '    const auto step_start = Clock::now();\n    logical_trace::Range trace_prepare("hyle/prepare", logical_trace::sequence);')
    s=replace(s,'      check(run.prepare_replay(queues, {.mode = phase.replay_modes[slot], .host_wait = g::HostWaitPolicy::kAllow}));',
        '      {\n        logical_trace::Range trace_replay("hyle/prepare_replay", logical_trace::sequence);\n        check(run.prepare_replay(queues, {.mode = phase.replay_modes[slot], .host_wait = g::HostWaitPolicy::kAllow}));\n      }')
    s=replace(s,'  void submit_evaluations() {','  void submit_evaluations() {\n    logical_trace::Range trace_submit("hyle/submit", logical_trace::sequence);')
    s=replace(s,'    const auto step_start = step.step_start, start = step.start;',
        '    logical_trace::Range trace_finish("hyle/wait_publish", logical_trace::sequence);\n    logical_trace::Range trace_postwait;\n    const auto step_start = step.step_start, start = step.start;')
    s=replace(s,'      check(step.completion.wait()); step.completion = {};',
        '      {\n        logical_trace::Range trace_wait("hyle/completion_wait", logical_trace::sequence);\n        check(step.completion.wait()); step.completion = {};\n      }\n      trace_postwait.start("hyle/postwait_publish", logical_trace::sequence);')
    s=replace(s,'    const auto finished = Clock::now();\n    for (const auto &output : outputs) if (output.generation_ledger)',
        '    const auto finished = Clock::now();\n    trace_postwait.finish(); trace_finish.finish(); logical_trace::episode.finish();\n    for (const auto &output : outputs) if (output.generation_ledger)')
    s=replace(s,'          const auto batch_start = qwen35::Clock::now();\n          make_batch_room(owners);',
        '''          const auto batch_start = qwen35::Clock::now();
          const auto trace_b2_j0 = selected.front();
          const auto trace_b2_j1 = selected.size() > 1 ? selected[1] : selected.front();
          const auto &trace_b2_call0 = wave.calls[trace_b2_j0];
          const auto &trace_b2_call1 = wave.calls[trace_b2_j1];
          logical_trace::b2_begin("hyle", kind == qwen35::benchmark::PhaseKind::kPrompt ? "prefill" : "decode",
              executed_graph_calls, query_rows, selected.size(), trace_b2_call0.session, trace_b2_call1.session,
              runs[trace_b2_call0.session].calls[trace_b2_call0.call].phase,
              runs[trace_b2_call1.session].calls[trace_b2_call1.call].phase,
              owners[0] && owners[0]->head ? owners[0]->head->length : 0,
              owners.size() > 1 && owners[1] && owners[1]->head ? owners[1]->head->length : 0);
          make_batch_room(owners);''')
    files=[source('hyle','engine/models/qwen35/main.cc',raw,s)]

    original_peer=Path(pready['source']['path']);raw=original_peer.read_bytes();s=raw.decode().replace('\r\n','\n')
    s='#include "logical_trace.h"\n'+s
    s=replace(s,'    const auto startup = Clock::now();','    [[maybe_unused]] logical_trace::RunScope trace_process;\n    const auto startup = Clock::now();')
    s=replace(s,'                const auto begin = Clock::now();\n                // A distinct old version',
        '''                const auto begin = Clock::now();
                const auto &trace_b2_call0 = pending[members.front()].call;
                const auto &trace_b2_call1 = pending[members.size() > 1 ? members[1] : members.front()].call;
                const auto trace_b2_context0 = pending[members.front()].target;
                const auto trace_b2_context1 = pending[members.size() > 1 ? members[1] : members.front()].target;
                logical_trace::b2_begin("peer", prompt ? "prefill" : "decode", graph_calls, t, members.size(),
                    trace_b2_call0.session, trace_b2_call1.session, trace_b2_call0.phase, trace_b2_call1.phase,
                    trace_b2_context0 >= t ? trace_b2_context0 - t : 0,
                    trace_b2_context1 >= t ? trace_b2_context1 - t : 0);
                logical_trace::Range trace_prepare("peer/prepare", logical_trace::sequence);
                // A distinct old version''')
    s=replace(s,'                            llama_memory_seq_cp(llama_get_memory(context.get()), run.head->id, p.candidate->id, -1, -1);',
        '                            {\n                                logical_trace::Range trace_copy("peer/seq_copy", logical_trace::sequence);\n                                llama_memory_seq_cp(llama_get_memory(context.get()), run.head->id, p.candidate->id, -1, -1);\n                            }')
    s=replace(s,'                const auto prepared = Clock::now(); pool.native_inflight = true;',
        '                const auto prepared = Clock::now(); pool.native_inflight = true;\n                trace_prepare.finish();\n                logical_trace::Range trace_decode("peer/llama_decode", logical_trace::sequence);')
    s=replace(s,'                const auto status = llama_decode(context.get(), batch.value); const auto decoded = Clock::now();',
        '                const auto status = llama_decode(context.get(), batch.value); const auto decoded = Clock::now();\n                trace_decode.finish();')
    s=replace(s,'                llama_synchronize(context.get()); pool.native_inflight = false; const auto synchronized = Clock::now();',
        '                logical_trace::Range trace_synchronize("peer/synchronize", logical_trace::sequence);\n                llama_synchronize(context.get()); pool.native_inflight = false; const auto synchronized = Clock::now();\n                trace_synchronize.finish();\n                logical_trace::Range trace_publish("peer/sample_publish", logical_trace::sequence);')
    s=replace(s,'                const auto end = Clock::now(); const auto elapsed = seconds(end, begin);',
        '                const auto end = Clock::now(); const auto elapsed = seconds(end, begin);\n                trace_publish.finish(); logical_trace::episode.finish();')
    files.append(source('peer','peer-batch.cc',raw,s))
    ident=read(P/'identity.json');support=[]
    for relative,available in (
        ('tools/qwen35_text/schedule.h',R/'.scratch/qwen-prefix-20261021/implementation/source/tools/qwen35_text/schedule.h'),
        ('tools/qwen35_text/session_schedule.h',R/'.scratch/qwen-cli-batch-20261022/before/tools/qwen35_text/session_schedule.h')):
        old=next(x for x in ident['dependencies'] if key(x['path'])==key(R/relative));new=W/'peer/source'/relative
        new.parent.mkdir(parents=True,exist_ok=True);new.write_bytes(available.read_bytes())
        assert pin(new)['sha256']==old['sha256'] and pin(new)['bytes']==old['bytes']
        support.append(dict(path=relative,original=old,cached_source=pin(available),compile_input=pin(new)))
    save(W/'source-pins.json',dict(files=files,helper=pin(W/'logical_trace.h'),peer_exact_support=support))
    dependencies={}
    for arm,old in (('hyle',read(H/'compile/actual-dependencies.json')),('peer',ident['dependencies'])):
        out=[]
        for row in old:
            restored=next((x for x in support if key(x['original']['path'])==key(row['path'])),None) if arm=='peer' else None
            actual=restored['compile_input'] if restored else pin(row['path'])
            assert (actual['bytes'],actual['sha256'])==(row['bytes'],row['sha256']),row['path']
            out.append(dict(original=row,compile_input=actual))
        dependencies[arm]=out
    save(W/'baseline-dependencies.json',dependencies)
    absolute={'hyle':read(H/'link-inputs.json'),'peer':read(P/'link-plan.json')['inputs']}
    for rows in absolute.values():
        for row in rows:exact(row)
    save(W/'baseline-link-inputs.json',absolute)
    build_plans={}
    for arm in ('hyle','peer'):
        F=W/arm
        old=read(H/'compile/command.json')['command'] if arm=='hyle' else ident['command']
        oldsource=main if arm=='hyle' else original_peer
        flags=[];skip=False
        for a in old[1:]:
            if skip:skip=False;continue
            if a=='/sourceDependencies':skip=True;continue
            if a.lower().startswith(('/fo','/fd')) or key(a)==key(oldsource):continue
            if arm=='hyle' and a.lower().startswith('/i') and str(H/'source').lower() in a.lower():continue
            flags.append(a)
        includes=['/I'+str(W)]
        if arm=='peer':includes += ['/I'+str(F/'source'),'/I'+str(original_peer.parent)]
        cmd=[old[0],*includes,'/external:IC:\\Program Files\\NVIDIA GPU Computing Toolkit\\CUDA\\v13.3\\include',*flags,
            files[0 if arm=='hyle' else 1]['after']['path'],'/sourceDependencies',str(F/'compile/dependencies.json'),
            '/Fo'+str(F/'compile/unit.obj'),'/Fd'+str(F/'compile/unit.pdb')]
        assert all(x in cmd for x in ('/O2','/Ob2','/MD','/DGGML_USE_CUDA'))
        if arm=='hyle':assert all(x in cmd for x in ('/W4','/WX'))
        original_link=H/'link/process/command.json' if arm=='hyle' else P/'link-plan.json'
        link=[];count=0;original_obj=hready['app']['path'] if arm=='hyle' else ident['object']['path']
        for a in read(original_link)['command']:
            if key(a)==key(original_obj):link.append(str(F/'compile/unit.obj'));count+=1
            elif not a.lower().startswith(('/out:','/pdb:','/map:','/implib:')):link.append(a)
        assert count==1
        link += ['/OUT:'+str(F/'link/consumer.exe'),'/PDB:'+str(F/'link/consumer.pdb'),'/IMPLIB:'+str(F/'link/consumer.lib')]
        plan=dict(compile=cmd,link=link,source=files[0 if arm=='hyle' else 1]['after'],
            baseline_object=hready['app'] if arm=='hyle' else ident['object'],
            original_link_recipe=pin(original_link),retained_inputs=[x for x in absolute[arm] if key(x['path'])!=key(original_obj)],
            original_flags_preserved=True,only_consumer_host_TU=True,SDK_or_Graph_or_native_builds=0)
        save(F/'build-plan.json',plan);build_plans[arm]=pin(F/'build-plan.json')
    baseline_plan=read(B/'plan.json');commands=[]
    for arm in ('hyle','peer'):
        row=next(x for x in baseline_plan['commands'] if x['arm']==arm)
        argv=row['command'] if 'command' in row else row['argv']
        # No process launches: preserve exact B2 argv except executable/result.
        argv=[str(W/arm/'link/consumer.exe'),*argv[1:]]
        if arm=='peer':argv[argv.index('--result')+1]=str(W/arm/'trace1/consumer-result.json')
        commands.append(dict(arm=arm,consumer=argv,profile=[str(NSYS),'profile','--trace=cuda,cublas,nvtx',
            '--cuda-graph-trace=node','--sample=none','--cpuctxsw=none','--discard-environment=true',
            '--nvtx-domain-include=HyleLogicalCalls','--duration=60','--kill=true','--wait=all','--stats=false',
            '--export=sqlite','--output='+str(W/arm/'trace1/trace'),*argv],
            reference=pin(B/('hyle-nontime-baseline.json' if arm=='hyle' else 'peer-nontime-baseline.json'))))
    save(W/'plan.json',dict(status='SOURCE_AND_COMMANDS_PREPARED_NOT_BUILT_NOT_RUN',design=pin(W/'design.json'),
        source_pins=pin(W/'source-pins.json'),baseline_dependencies=pin(W/'baseline-dependencies.json'),
        baseline_link_inputs=pin(W/'baseline-link-inputs.json'),build_plans=build_plans,
        baseline_ready={'hyle':pin(H/'ready.json'),'peer':pin(R/'.scratch/qwen-cli-batch-20261022/peer-ready.json')},
        runtime={'hyle':hready['runtime'],'peer':pready['runtime_environment']},
        tool=pin(NSYS),tool_version='NVIDIA Nsight Systems2026.1.3.425-261338342291v0 (previous actual tool receipt; not rerun)',
        commands=commands,expected_work=pin(B/'expected-work.json'),work_gate_source=pin(B/'run.py'),
        root_contract=dict(per_arm=99,prefill=3,decode=96,R=2,prefill_T=256,decode_T=1,
            rows=1728,decisions=198,payload='sequence1..99; text index0..98, kind/T/R/m0/m1/p0/p1/c0/c1 from actual consumer bucket',
            hyle_phase_labels=['hyle/prepare','hyle/prepare_replay','hyle/submit','hyle/wait_publish','hyle/completion_wait','hyle/postwait_publish'],
            peer_phase_labels=['peer/prepare','peer/llama_decode','peer/synchronize','peer/sample_publish'],peer_copy_expected=0),
        limits=['Exactly one consumerTU and one link per engine. No product, SDK, device, Graph or native changes.',
            'Original Clock/endpoint/math/report/order/retirement statements remain unchanged; marker timestamps are only adjacent boundaries.',
            'N1 gates68/134/target/draft/schedule are not used. B2 own full raw report gate, physical order and198IDs are mandatory.',
            'Only source/metadata prepared. Root alone may explicitly build then profile one process per engine; watchdog120, no retry or unprofiled baseline.']))
    print(json.dumps(dict(source_pins=pin(W/'source-pins.json'),plan=pin(W/'plan.json'),helper=pin(W/'logical_trace.h'))))

if __name__=='__main__':prepare()
