#pragma once
// Private NVTX instrumentation. Preserve the caller's Windows COM macro state.
#pragma push_macro("interface")
#include <nvtx3/nvToolsExt.h>
#pragma pop_macro("interface")
#include <cstddef>
#include <cstdio>
#include <cstdint>
namespace logical_trace {
inline nvtxDomainHandle_t domain = nullptr;
inline unsigned long long sequence = 0, finished_ranges = 0, overlapping_episodes = 0;
inline void initialize() noexcept { domain = nvtxDomainCreateA("HyleLogicalCalls"); }
class Range final {
  nvtxRangeId_t id_ = 0;
  bool active_ = false;
public:
  Range() noexcept = default;
  explicit Range(const char *text, unsigned long long payload = 0) noexcept { start(text, payload); }
  Range(const Range &) = delete;
  Range &operator=(const Range &) = delete;
  ~Range() { finish(); }
  void start(const char *text, unsigned long long payload = 0) noexcept {
    if (active_) { ++overlapping_episodes; finish(); }
    nvtxEventAttributes_t event{};
    event.version = NVTX_VERSION;
    event.size = NVTX_EVENT_ATTRIB_STRUCT_SIZE;
    event.messageType = NVTX_MESSAGE_TYPE_ASCII;
    event.message.ascii = text;
    event.payloadType = NVTX_PAYLOAD_TYPE_UNSIGNED_INT64;
    event.payload.ullValue = payload;
    id_ = nvtxDomainRangeStartEx(domain, &event);
    active_ = true;
  }
  void finish() noexcept {
    if (active_) { nvtxDomainRangeEnd(domain, id_); active_ = false; ++finished_ranges; }
  }
};
inline Range episode;
inline char episode_text[512]{};
inline void b2_begin(const char *engine, const char *kind, std::size_t index,
                     std::size_t rows, std::size_t width,
                     std::size_t member0, std::size_t member1,
                     std::size_t phase0, std::size_t phase1,
                     std::size_t context0, std::size_t context1) noexcept {
  ++sequence;
  std::snprintf(episode_text, sizeof(episode_text),
      "%s/b2_episode seq=%llu index=%zu kind=%s T=%zu R=%zu m0=%zu m1=%zu p0=%zu p1=%zu c0=%zu c1=%zu",
      engine, sequence, index, kind, rows, width, member0, member1,
      phase0, phase1, context0, context1);
  episode.start(episode_text, sequence);
}
inline void dump() noexcept {
  std::fprintf(stderr, "LOGICAL_NVTX sequence=%llu completed_ranges=%llu overlapping_episodes=%llu\n",
      sequence, finished_ranges, overlapping_episodes);
}
struct RunScope final {
  RunScope() noexcept { initialize(); }
  ~RunScope() { episode.finish(); dump(); }
};
} // namespace logical_trace
