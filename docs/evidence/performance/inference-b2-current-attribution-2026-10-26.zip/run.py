"""Explicit Root-only serial pair; one profile/engine, no retry or warmup."""
from pathlib import Path
from collections import Counter
import importlib.util
import json
import os
import re
import sqlite3
import subprocess
import sys
import time

sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent
R=W.parents[1]

def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path)
    mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod);return mod

m=load('b2_profile_plan',W/'prepare.py')
gate=load('completed_B2_work_gate',m.B/'run.py')

def run(arm):
    assert arm in ('hyle','peer')
    plan=m.read(W/'plan.json')
    navigation=m.read(W/'run-contract.json')
    m.exact(navigation['source_plan']);m.exact(navigation['peer_correction'])
    for field in ('tool','source_pins','expected_work','work_gate_source'):m.exact(plan[field])
    record=next(x for x in plan['commands'] if x['arm']==arm)
    ready=m.read(navigation['ready_paths'][arm])
    for field in ('image','app','source','source_pins','runtime','actual_dependencies','link_inputs'):m.exact(ready[field])
    for row in m.read(ready['link_inputs']['path']):m.exact(row)
    m.exact(record['reference'])
    F=Path(navigation['run_paths'][arm]);F.mkdir(exist_ok=False)
    runtime=m.read(ready['runtime']['path']);env=os.environ.copy()
    env['PATH']=str(Path(ready['image']['path']).parent)+';'+runtime['PATH']
    env['HF_HUB_OFFLINE']='1';env['TRANSFORMERS_OFFLINE']='1'
    env.update(runtime.get('configured_flags',{}))
    cmd=[ready['image']['path'] if x==record['consumer'][0]
         else '--output='+str(F/'trace') if x.startswith('--output=') else x for x in record['profile']]
    if arm=='peer':cmd[cmd.index('--result')+1]=str(F/'consumer-result.json')
    assert cmd.count(ready['image']['path'])==1
    assert '--duration=60' in cmd and '--cuda-graph-trace=node' in cmd
    assert cmd[cmd.index('--session-schedules')+1]==m.read(plan['expected_work']['path'])['manifest']['path']
    if arm=='peer':assert cmd[cmd.index('--result')+1]==str(F/'consumer-result.json')
    m.save(F/'command.json',dict(command=cmd,cwd=str(R),timeout_seconds=120,image=ready['image'],runtime=ready['runtime'],
        profiler=True,throughput_evidence=False,no_retry=True,navigation=m.pin(W/'run-contract.json')))
    started=time.perf_counter()
    with (F/'stdout.log').open('wb') as out,(F/'stderr.log').open('wb') as err:
        p=subprocess.Popen(cmd,cwd=R,env=env,stdout=out,stderr=err,creationflags=subprocess.CREATE_NO_WINDOW)
        m.save(F/'live.json',dict(nsys_pid=p.pid,started_unix_ns=time.time_ns()))
        print('B2_PROFILE_STARTED',arm,p.pid,flush=True)
        timed_out=False
        try:code=p.wait(timeout=120)
        except subprocess.TimeoutExpired:
            timed_out=True
            killed=subprocess.run(['C:/Windows/System32/taskkill.exe','/PID',str(p.pid),'/T','/F'],capture_output=True)
            (F/'timeout-taskkill.stdout.log').write_bytes(killed.stdout);(F/'timeout-taskkill.stderr.log').write_bytes(killed.stderr)
            p.wait(timeout=20);code=p.returncode
    m.save(F/'process.json',dict(exit=code,nsys_pid=p.pid,seconds=time.perf_counter()-started,timeout=timed_out))
    print('B2_PROFILE_ENDED',arm,code,'timeout',timed_out,flush=True)
    assert code==0 and not timed_out,'Original failure retained; do not launch another arm or retry'
    c=sqlite3.connect('file:'+(F/'trace.sqlite').as_posix()+'?mode=ro',uri=True);c.row_factory=sqlite3.Row
    tables={x[0] for x in c.execute("SELECT name FROM sqlite_master WHERE type='table'")}
    assert {'NVTX_EVENTS','CUPTI_ACTIVITY_KIND_KERNEL','CUPTI_ACTIVITY_KIND_RUNTIME','ProcessStreams'}<=tables
    present=[]
    for name,text in c.execute('SELECT f.value,c.value FROM ProcessStreams p JOIN StringIds f ON f.id=p.filenameId JOIN StringIds c ON c.id=p.contentId'):
        if 'stdout_' in name or 'stderr_' in name:
            target='native-stdout.log' if 'stdout_' in name else 'native-stderr.log'
            (F/target).write_bytes(text.encode());present.append(target)
    # Hyle emits one complete JSON line. Peer632 writes its authoritative
    # complete report directly to --result; its stdout is normally empty.
    raw=json.loads((F/'native-stdout.log').read_bytes()) if arm=='hyle' else m.read(F/'consumer-result.json')
    reference=m.read(record['reference']['path']);expected=m.read(plan['expected_work']['path'])
    ids=gate.check_work(raw,arm,expected,reference)
    audit=[];normalized=gate.normalize(raw,audit)
    differences=gate.differences(reference,normalized)
    m.save(F/'non-time-comparison.json',dict(differences=differences,reference=record['reference'],normalization_audit=audit,
        gate=plan['work_gate_source'],scope='Same complete per-arm8window report; no new metadata exclusion'))
    m.save(F/'ids.json',ids)
    events=[dict(x) for x in c.execute('SELECT n.*,COALESCE(n.text,s.value) label FROM NVTX_EVENTS n LEFT JOIN StringIds s ON s.id=n.textId ORDER BY n.start') if x['label']]
    roots=[x for x in events if x['label'].startswith(arm+'/b2_episode ')]
    phase_labels=plan['root_contract']['hyle_phase_labels' if arm=='hyle' else 'peer_phase_labels']
    phases=[x for x in events if x['label'] in phase_labels]
    missing=[dict(label=x['label'],start=x['start']) for x in roots+phases if x['end'] is None]
    assert not missing and len(roots)==99
    expected_meta=[];context=0
    for phase,tape in enumerate(expected['tapes']):
        for rows in ([tape['rows']] if tape['kind']=='prompt' else [1]*tape['rows']):
            expected_meta.append(dict(kind='prefill' if tape['kind']=='prompt' else 'decode',T=rows,p0=phase,p1=phase,c0=context,c1=context))
            context+=rows
    metadata=[]
    for index,(root,e) in enumerate(zip(roots,expected_meta)):
        meta={k:int(v) for k,v in re.findall(r'(\w+)=(\d+)',root['label'])}
        meta['kind']=re.search(r'kind=(\w+)',root['label'])[1]
        required=dict(seq=index+1,index=index,R=2,m0=0,m1=1,**e)
        assert meta==required,(meta,required)
        assert root['uint64Value']==index+1
        inner=[x for x in phases if x['uint64Value']==index+1]
        assert Counter(x['label'] for x in inner)==Counter(phase_labels)
        assert all(x['globalTid']==root['globalTid'] and root['start']<=x['start']<=x['end']<=root['end'] for x in inner)
        if index:assert roots[index-1]['end']<=root['start']
        metadata.append(dict(label=root['label'],meta=meta,start_ns=root['start'],end_ns=root['end'],globalTid=root['globalTid']))
    copies=[x for x in events if x['label']=='peer/seq_copy']
    assert not copies,'Original B2copy0 contract changed'
    native_err=(F/'native-stderr.log').read_text(encoding='utf8')
    marker=re.findall(r'LOGICAL_NVTX sequence=(\d+) completed_ranges=(\d+) overlapping_episodes=(\d+)',native_err)
    assert marker and tuple(map(int,marker[-1]))==(99,693 if arm=='hyle' else 495,0),marker
    activity={name:c.execute('SELECT COUNT(*) FROM '+name).fetchone()[0] for name in ('CUPTI_ACTIVITY_KIND_KERNEL','CUPTI_ACTIVITY_KIND_RUNTIME')}
    assert all(activity.values());c.close()
    m.save(F/'physical-roots.json',metadata)
    m.save(F/'quality.json',dict(status='PASS' if not differences else 'FAIL',full_non_time_equal=not differences,
        physical_roots=99,prefill=3,decode=96,R=2,rows=1728,decisions=198,
        complete_marker=marker,phase_counts=dict(Counter(x['label'] for x in phases)),missing_ends=missing,
        activity_rows=activity,native_streams_present=present,report_authority='ProcessStreams native stdout' if arm=='hyle' else 'complete consumer-result.json, not stdout',
        source_report_gate=plan['work_gate_source'],original_expected_work=plan['expected_work'],
        artifacts=[m.pin(F/x) for x in ('trace.sqlite','trace.nsys-rep','native-stderr.log')],
        limits='One profiled job/arm, no throughput claim. NVTX/API/parent phases inclusive; roots have distinct native publication/report boundaries. GPU correlation/union pending offline analysis.'))
    assert not differences,'Changed full report retained; stop without another arm or retry'
    print('B2_QUALITY_PASS',arm,flush=True)

if __name__=='__main__':
    action=sys.argv[1]
    assert action in ('hyle','peer','pair')
    if action=='pair':
        run('hyle');run('peer')
        navigation=m.read(W/'run-contract.json')
        a=m.read(Path(navigation['run_paths']['hyle'])/'ids.json');b=m.read(Path(navigation['run_paths']['peer'])/'ids.json')
        assert a==b,'Cross-engine198IDs changed; original raw kept'
        m.save(W/'pair-quality.json',dict(status='PASS',cross_engine_198IDs_equal=True,profiles=2,no_extra_runs=True))
    else:run(action)
