"""Two ordinary arms, two frozen prompt lengths. Only run/resume start models."""
from pathlib import Path
import argparse
import importlib.util
import json
import math
import os
import re
import statistics
import sys

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
V = W.parent
R = V.parents[1]
ARMS = ('hyle_auto', 'peer_plain')
EOS = (248044, 248046)


def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    value = importlib.util.module_from_spec(spec); spec.loader.exec_module(value)
    return value


# Reuse process execution, original clocks, OS counters and memory reducer only.
# Their old P154/C1024 and two-turn P309 parsers are deliberately not called.
base = module('long_input_retained_clocks_memory', R/'.scratch/qwen-mtp-window-20261022/window.py')
facts = module('long_input_original_non_time', R/'.scratch/inference-current-review-profile-20261027/analyze.py')


def read(path): return json.loads(Path(path).read_text(encoding='utf-8-sig'))
def save(path, value): base.save(path, value)


def exact(row):
    assert base.identity(row['path']) == row, row['path']


def receipt_stat(row):
    # Image/weight hashes are retained as-run identities, not another large read.
    p = Path(row['path']); assert p.is_file() and p.stat().st_size == row['bytes'], row['path']


def helpers():
    runner = base.load_helpers(); old_marker = runner.marker
    def marker(line):
        found = re.search(r'\bmemory_phase=generation_default_(prefill|decode)_(begin|end)\b', line)
        if found: return 'window_'+found[1]+'_'+found[2]
        name = old_marker(line)
        if name and name.startswith('round1_'): return 'window_'+name[len('round1_'):]
        return name
    runner.marker = marker
    return runner


def prepare():
    assert not (W/'plan.json').exists(), 'Preserve prepared attempt'
    original = read(V/'plan.json')
    assert original['proposed_minimum_execution']['processes'] == 16
    assert original['images']['hyle']['image']['sha256'] == 'aa8647242ee68049e4bab0c4409638f11949c5f48de1c7b95b2ba1bd50f08983'
    assert original['images']['peer']['image']['sha256'] == '433e7051f4c36d0d9b2297dc378631546b7e3c44630cda0653cba2d1ec6bbe8e'
    for image in original['images'].values():
        exact(image['ready']); exact(image['runtime_environment']); exact(image['source']); receipt_stat(image['image'])
    exact(original['weights']['hyle_manifest'])
    receipt_stat(original['weights']['historical_peer_full_file_identity'])
    cases = {}
    for case in original['cases']:
        exact(case['prompt']); exact(case['schedule'])
        ids = [int(x) for x in Path(case['prompt']['path']).read_text().split()]
        assert len(ids) == case['prompt_rows'] and case['maximum_committed_rows'] < case['capacity']
        groups = {}
        for mode in ('timing', 'memory'):
            order = original['proposed_minimum_execution'][mode+'_order']
            output = W/(case['name']+'-'+mode)
            entries = []
            for ordinal, arm in enumerate(order, 1):
                image = original['images']['hyle' if arm == 'hyle_auto' else 'peer']
                folder = output/f'{ordinal:02}-{arm}'
                command = list(case['hyle_command'] if arm == 'hyle_auto' else case['peer_command_template'])
                if arm == 'peer_plain': command[command.index('--output')+1] = str(folder/'consumer-result.json')
                assert command[0] == image['image']['path'] and '--steps' not in command
                assert command[command.index('--schedule')+1] == case['schedule']['path']
                entries.append(dict(ordinal=ordinal, arm=arm, folder=str(folder), command=command,
                    image=image['image'], ready=image['ready'], environment=image['runtime_environment']))
            groups[mode] = dict(case=case, mode=mode, output=str(output), commands=entries,
                original_plan=base.identity(V/'plan.json'), runner=base.identity(Path(__file__)))
            save(W/(case['name']+'-'+mode+'-plan.json'), groups[mode])
        cases[case['name']] = groups
    save(W/'plan.json', dict(status='PREPARED_NOT_RUN', original_plan=base.identity(V/'plan.json'),
        cases=cases, actual_processes_planned=16, images=original['images'], weights=original['weights'],
        parser='Case-parameterized one-turn ordinary parser; original P/D endpoints and process/memory helpers unchanged.',
        peer_single_turn_schedule_support='Actual peer_multiturn.cc reads arbitrary turn_definitions and loops each; one turn needs no binary or parameter change.',
        payloads_copied=0, large_payloads_rehashed=0, CXX=0, SDK=0, downloads=0))
    print('PREPARED 16 processes; zero model/driver/build execution', flush=True)


def normalize(folder, arm):
    if arm == 'peer_plain': return read(folder/'consumer-result.json')
    lines = (folder/'stdout.log').read_text(encoding='utf-8-sig').splitlines()
    raw = json.loads(next(x for x in reversed(lines) if x.startswith('{')))
    assert len(raw['sessions']) == 1
    detail = raw['sessions'][0]['result']; value = dict(raw)
    # Only absent non-time facts are adapted; original top-level timing wins.
    for key, item in detail.items():
        if key not in value:
            if any(x in key for x in ('seconds', 'per_second', 'clock_unix', 'unix_ns', 'unix_ms')): continue
            value[key] = item
    save(folder/'consumer-result.json', value)
    save(folder/'result-schema-adapter.json', dict(source_stdout=base.identity(folder/'stdout.log'),
        operation='Copy missing non-time fields from sole original session result; no producer timing changed.', timing_values_changed=False))
    return value


def parse(folder, arm, config):
    raw = normalize(folder, arm); case = config['case']
    ids = raw['generated_ids']; count = len(ids); decode_outputs = max(count-1, 0)
    assert 1 <= count <= case['max_outputs'] and all(isinstance(x, int) and x >= 0 for x in ids)
    stopped = ids[-1] in EOS
    assert count == case['max_outputs'] or stopped, 'Short natural output must be genuine EOS'
    if 'stopped_on_EOS' in raw: assert raw['stopped_on_EOS'] == stopped
    assert raw['turn_count'] == 1 and raw['session_count'] == 1 and not raw['mtp']
    assert raw['prefill_target_rows'] == case['prompt_rows']
    p, d, total = (float(raw[k]) for k in ('prefill_seconds', 'decode_seconds', 'session_seconds'))
    assert all(math.isfinite(x) for x in (p, d, total)) and p > 0 and total > 0 and d >= 0
    decode_calls = raw['decode_graph_calls'] if arm == 'hyle_auto' else raw['target_decode_calls']
    assert (decode_calls > 0 and d > 0) if decode_outputs else (decode_calls == 0 and d == 0)
    assert math.isclose(p+d, total, rel_tol=1e-5, abs_tol=2e-6), 'P+D must cover original whole session'
    if arm == 'hyle_auto':
        assert raw['decode_overlap'] and raw['live_committed_versions'] == 0
        assert raw['max_sessions'] == raw['active_sequences'] == 1
        assert raw['prefill_graph_calls'] == 1 and raw['generated_tokens'] == count
        assert raw['generated_decode_tokens'] == decode_outputs
        assert raw['original_device_weight_bytes'] == 3763655360 and raw['original_host_weight_bytes'] == 0
        # Final availability/refusal/partial fallback are facts, not pass gates.
    else:
        assert raw['requested_context'] == case['capacity'] and raw['target_effective_context'] == case['capacity']
        assert raw['prefill_draft_rows'] == raw['actual_draft_rows'] == raw['draft_decode_calls'] == 0
    startup = float(raw['startup_to_endpoint_seconds']); ready = float(raw['startup_to_ready_seconds'])
    first = float(raw.get('first_token_elapsed_seconds', startup-d))
    load = raw.get('weights_load_seconds')
    if load is None:
        match = re.search(r'^weights_load_seconds=([^\s]+)', (folder/'stderr.log').read_text(), re.M)
        assert match; load = float(match[1])
    assert all(math.isfinite(x) for x in (startup, ready, first, float(load)))
    assert 0 <= float(load) <= ready <= first <= startup+2e-6 and startup > 0
    metrics = dict(prefill_tokens_per_second=case['prompt_rows']/p,
        full_decode_tokens_per_second=decode_outputs/d if decode_outputs else None,
        session_output_tokens_per_second=count/total,
        session_processed_tokens_per_second=(case['prompt_rows']+decode_outputs)/total,
        prefill_seconds=p, decode_seconds=d, session_seconds=total,
        weights_load_seconds=float(load), startup_to_ready_seconds=ready,
        first_token_elapsed_seconds=first, startup_to_endpoint_seconds=startup, cold_output_tokens_per_second=count/startup)
    observation = dict(metrics=metrics, generated_ids=ids, actual_generated_tokens=count,
        actual_generated_decode_tokens=decode_outputs, stopped_on_EOS=stopped,
        actual_prefill_target_rows=raw['prefill_target_rows'], original_producer_timing_unchanged=True,
        work={k: raw[k] for k in raw if any(s in k for s in ('rows', 'calls', 'tokens', 'successor', 'overlap', 'backing_bytes', 'requested_bytes')) and not any(s in k for s in ('seconds', 'per_second'))})
    save(folder/'observation.json', observation)
    save(folder/'timing-partition-gate.json', dict(status='PASS', prefill_seconds=p, decode_seconds=d,
        session_seconds=total, actual_decode_calls=decode_calls, actual_decode_outputs=decode_outputs,
        EOS_first_output_allows_zero_decode=True))
    return observation


def analyze(config):
    output = Path(config['output']); rows = []
    for entry in config['commands']:
        folder = Path(entry['folder'])
        if not folder.exists(): break
        process = read(folder/'result.json')
        assert process['exit'] == 0 and not process.get('reader_errors') and not process.get('timeout')
        observation = parse(folder, entry['arm'], config)
        rows.append(dict(arm=entry['arm'], folder=str(folder), process=process, observation=observation))
    groups, stability = {}, {}
    for arm in ARMS:
        selected = [r for r in rows if r['arm'] == arm]
        if not selected: continue
        normalized = [facts.non_time(read(Path(r['folder'])/'consumer-result.json')) for r in selected]
        stable = all(x == normalized[0] for x in normalized)
        stability[arm] = dict(processes=len(selected), complete_non_time_reports_identical=stable,
            all_IDs_identical=all(r['observation']['generated_ids'] == selected[0]['observation']['generated_ids'] for r in selected))
        save(output/'within-arm-stability.json', stability)
        assert stable, 'Preserved within-arm variability; do not discard or replace a sample'
        if config['mode'] == 'timing':
            groups[arm] = {k: base.stats([r['observation']['metrics'][k] for r in selected if r['observation']['metrics'][k] is not None])
                           for k in selected[0]['observation']['metrics']}
        else: groups[arm] = read(Path(selected[0]['folder'])/'memory-summary.json')
    ids = [next((r['observation']['generated_ids'] for r in rows if r['arm'] == arm), None) for arm in ARMS]
    comparison = None
    if all(x is not None for x in ids):
        first = next((j for j, (x, y) in enumerate(zip(*ids)) if x != y), None)
        if first is None and len(ids[0]) != len(ids[1]): first = min(map(len, ids))
        comparison = dict(equal=ids[0] == ids[1], lengths=list(map(len, ids)), first_divergence_zero_based=first)
    result = dict(status='COMPLETE_STABLE' if len(rows) == len(config['commands']) else 'PARTIAL_STABLE',
        case=config['case']['name'], mode=config['mode'], actual_processes=len(rows), planned_processes=len(config['commands']),
        groups=groups, within_arm=stability, natural_ID_comparison=comparison,
        throughput_evidence=config['mode'] == 'timing', requested_memory_interval_seconds=0.01,
        limits=['Three timing samples or one separate memory process per arm; no significance claim.',
                'EOS shortening is actual work, no quota64 substitution. Cross-engine IDs/work may differ.',
                'Original OS memory counters/phase sampling preserve null, ready unknown and actual cadence; peaks are sampled lower bounds.',
                'No sample replacement, historical pooling, fixed decode tape, off/MTP arm or new model/SDK build.'])
    save(output/'runs.json', rows); save(output/'summary.json', result)
    return result


def run(case, mode, resume=False, limit=None):
    config = read(W/(case+'-'+mode+'-plan.json')); output = Path(config['output'])
    exact(config['original_plan'])
    assert config['case']['name'] == case
    for row in (config['case']['prompt'], config['case']['schedule']): exact(row)
    if resume:
        assert read(output/'inputs.json') == config
        existing = [e for e in config['commands'] if Path(e['folder']).exists()]
        assert existing == config['commands'][:len(existing)]
        analyze(config)  # Offline recheck; never execute a pre-existing folder.
    else:
        assert not output.exists(), 'Preserve actual attempts; use explicit resume for remaining commands'
        output.mkdir(parents=True); save(output/'inputs.json', config); existing = []
    runner = helpers(); runner.gpu_snapshot(output, 'resume-before' if resume else 'window-before')
    remaining = config['commands'][len(existing):]
    if limit is not None: remaining = remaining[:limit]
    try:
        for entry in remaining:
            folder = Path(entry['folder']); assert not folder.exists()
            exact(entry['ready']); exact(entry['environment']); receipt_stat(entry['image'])
            env = dict(os.environ, PATH=read(entry['environment']['path'])['PATH'],
                HF_HUB_OFFLINE='1', TRANSFORMERS_OFFLINE='1', HF_HUB_DISABLE_TELEMETRY='1')
            print('BEGIN', case, mode, entry['ordinal'], entry['arm'], flush=True)
            process = runner.execute(folder, entry['arm'], entry['command'], env, mode == 'memory')
            assert read(folder/'result.json')['exit'] == 0
            parse(folder, entry['arm'], config)
            analyze(config)  # Stop before any next process if facts vary.
            print('END', case, mode, entry['ordinal'], entry['arm'], flush=True)
    finally:
        runner.gpu_snapshot(output, 'resume-after' if resume else 'window-after')
    result = analyze(config); print(result['status'], result['actual_processes'], flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('action', choices=('prepare', 'run-one', 'resume-one', 'analyze-one'))
    parser.add_argument('case', nargs='?', choices=('p1024', 'p4032'))
    parser.add_argument('mode', nargs='?', choices=('timing', 'memory'))
    parser.add_argument('--limit', type=int)
    args = parser.parse_args()
    if args.action == 'prepare': prepare()
    elif args.action == 'analyze-one': print(analyze(read(W/(args.case+'-'+args.mode+'-plan.json')))['status'])
    else: run(args.case, args.mode, args.action == 'resume-one', args.limit)
