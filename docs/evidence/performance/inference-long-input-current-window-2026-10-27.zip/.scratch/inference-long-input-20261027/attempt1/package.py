"""Offline 16-process long-input receipt. Never runs a model or a compiler."""
from pathlib import Path
import hashlib
import json
import math
import statistics
import sys
import zipfile

W = Path(__file__).resolve().parent
V = W.parent
R = V.parents[1]
D = R/'docs/evidence/performance'
STEM = 'inference-long-input-current-window-2026-10-27'
ARMS = ('hyle_auto', 'peer_plain')
FORBIDDEN = {'.exe', '.obj', '.pdb', '.dll', '.lib', '.exp', '.bin', '.gguf', '.safetensors', '.pt', '.spv', '.db', '.sqlite', '.pyc', '.zip'}


def read(path): return json.loads(Path(path).read_text(encoding='utf-8-sig'))
def sha(data): return hashlib.sha256(data).hexdigest()


def pin(path):
    p = Path(path).resolve(); data = p.read_bytes()
    return dict(path=str(p), bytes=len(data), sha256=sha(data))


def exact(row):
    actual = pin(row['path'])
    assert (actual['bytes'], actual['sha256']) == (row['bytes'], row['sha256']), row['path']


def save(path, value): Path(path).write_text(json.dumps(value, indent=2, ensure_ascii=False)+'\n', encoding='utf-8')


def compact(path, value):
    lines = ['{']
    for at, (k, v) in enumerate(value.items()):
        prefix = '  '+json.dumps(k)+': '; end = ',' if at+1 < len(value) else ''
        if isinstance(v, list):
            lines.append(prefix+'[')
            for j, row in enumerate(v): lines.append('    '+json.dumps(row, ensure_ascii=False, allow_nan=False, separators=(',', ': '))+(',' if j+1 < len(v) else ''))
            lines.append('  ]'+end)
        else: lines.append(prefix+json.dumps(v, ensure_ascii=False, allow_nan=False, separators=(',', ': '))+end)
    lines.append('}'); Path(path).write_text('\n'.join(lines)+'\n', encoding='utf-8')


def non_time(x):
    if isinstance(x, list): return [non_time(v) for v in x]
    if isinstance(x, dict): return {k: non_time(v) for k, v in x.items() if not any(s in k for s in ('seconds', 'per_second', 'clock_unix', 'unix_ns', 'unix_ms'))}
    return x


def triple(row): return [None if row[k] is None else round(row[k], 6) for k in ('median', 'min', 'max')]
def mib(x): return None if x is None else round(x/1048576, 3)


def collect():
    plan = read(V/'plan.json'); prepared = read(W/'plan.json')
    exact(prepared['original_plan'])
    table, cold, memory, work, pauses, processes = [], [], [], [], [], []
    for case in plan['cases']:
        name = case['name']; exact(case['prompt']); exact(case['schedule'])
        groups = {mode: read(W/(name+'-'+mode)/'summary.json') for mode in ('timing', 'memory')}
        assert all(g['status'] == 'COMPLETE_STABLE' for g in groups.values())
        assert groups['timing']['actual_processes'] == 6 and groups['memory']['actual_processes'] == 2
        assert groups['timing']['natural_ID_comparison']['equal'] and groups['memory']['natural_ID_comparison']['equal']
        actual = {}
        for mode in ('timing', 'memory'):
            configuration = read(W/(name+'-'+mode+'-plan.json'))
            exact(configuration['runner']); exact(configuration['original_plan'])
            for entry in configuration['commands']:
                folder = Path(entry['folder']); process = read(folder/'result.json')
                assert process['exit'] == 0 and not process.get('timeout') and not process.get('reader_errors')
                assert process['command'] == entry['command'] and process['image'] == entry['image'] and process['arm'] == entry['arm']
                assert process['memory_only'] == (mode == 'memory')
                raw = read(folder/'consumer-result.json'); observation = read(folder/'observation.json')
                gate = read(folder/'timing-partition-gate.json'); assert gate['status'] == 'PASS'
                assert raw['prefill_target_rows'] == case['prompt_rows'] and raw['turn_count'] == 1 and not raw['mtp']
                assert math.isclose(raw['prefill_seconds']+raw['decode_seconds'], raw['session_seconds'], rel_tol=1e-5, abs_tol=2e-6)
                assert observation['actual_generated_tokens'] == (46 if name == 'p1024' else 64)
                assert observation['generated_ids'][-1] == (248046 if name == 'p1024' else 4479)
                assert observation['stopped_on_EOS'] == (name == 'p1024')
                if entry['arm'] == 'hyle_auto':
                    assert raw['live_committed_versions'] == 0 and raw['decode_overlap']
                    assert (raw['overlap_successor_submissions'], raw['overlap_successor_publications'], raw['overlap_successor_discards'], raw['overlap_successor_refusals']) == ((38,37,1,0) if name == 'p1024' else (55,55,0,0))
                actual.setdefault((mode, entry['arm']), []).append((raw, observation, process))
                processes.append(dict(case=name, mode=mode, arm=entry['arm'], folder=str(folder),
                    pid=process['pid'], exit=0, image=process['image'],
                    started_unix_ns=process['started_unix_ns'], finished_unix_ns=process['finished_unix_ns'],
                    raw_files=[pin(folder/n) for n in ('command.json','result.json','stdout.log','stderr.log')]))
        timing_order = read(W/(name+'-timing/runs.json'))
        last_first_pair = timing_order[1]['process']; first_resume = timing_order[2]['process']
        pauses.append(dict(case=name, first_pair_pids=[x['process']['pid'] for x in timing_order[:2]],
            remaining_pids=[x['process']['pid'] for x in timing_order[2:]],
            between_pair_and_resume_seconds=round((first_resume['started_unix_ns']-last_first_pair['finished_unix_ns'])/1e9, 6),
            first_pair_retained_as_samples=True, rerun=False))
        for arm in ARMS:
            t = groups['timing']['groups'][arm]; m = groups['memory']['groups'][arm]
            rows = actual[('timing',arm)]; raw, observation, _ = rows[0]
            assert len(rows) == 3 and all(non_time(row[0]) == non_time(raw) for row in rows)
            for k, reduction in t.items():
                values = [row[1]['metrics'][k] for row in rows if row[1]['metrics'][k] is not None]
                assert reduction['count'] == len(values)
                if values:
                    assert all(math.isclose(reduction[key], result, rel_tol=1e-12) for key,result in
                               (('median',statistics.median(values)),('min',min(values)),('max',max(values))))
            peaks = m['sampled_peaks']
            table.append(dict(case=name, arm=arm, prefill_tps=triple(t['prefill_tokens_per_second']),
                full_decode_tps=triple(t['full_decode_tokens_per_second']), overall_output_tps=triple(t['session_output_tokens_per_second']),
                separate_sampled_peak_dedicated_MiB=mib(peaks['sampled_peak_gpu_dedicated_bytes'])))
            cold.append(dict(case=name, arm=arm, weights_load_s=triple(t['weights_load_seconds']),
                ready_s=triple(t['startup_to_ready_seconds']), first_token_s=triple(t['first_token_elapsed_seconds']),
                startup_final_s=triple(t['startup_to_endpoint_seconds']), cold_output_tps=triple(t['cold_output_tokens_per_second'])))
            memory.append(dict(case=name, arm=arm, sampled_peak_dedicated_MiB=mib(peaks['sampled_peak_gpu_dedicated_bytes']),
                sampled_peak_shared_MiB=mib(peaks['sampled_peak_gpu_shared_bytes']), same_sample_peak_total_GPU_MiB=mib(peaks['sampled_peak_gpu_total_bytes']),
                sampled_peak_working_set_MiB=mib(peaks['sampled_max_working_set_bytes']), sampled_peak_private_commit_MiB=mib(peaks['sampled_max_private_commit_bytes']),
                ready_unknown=m['ready_baseline']['unknown'], null_counts=m['null_sample_counts'],
                running_samples=m['running_sample_count'], actual_gap_ms=[round(m['actual_sample_gaps_ms'][k],3) for k in ('median','min','max')]))
            work.append(dict(case=name, arm=arm, actual_outputs=observation['actual_generated_tokens'], actual_decode_outputs=observation['actual_generated_decode_tokens'],
                last_id=observation['generated_ids'][-1], stopped_on_EOS=observation['stopped_on_EOS'],
                actual_target_rows=raw['actual_target_rows'], committed_target_rows=raw['committed_target_rows'], verified_target_rows=raw['verified_target_rows'],
                target_calls=raw.get('actual_graph_calls',raw.get('target_compute_calls')),
                publications=raw.get('overlap_successor_publications'), submissions=raw.get('overlap_successor_submissions'),
                discards=raw.get('overlap_successor_discards'), refusals=raw.get('overlap_successor_refusals'),
                within_timing_complete_non_time_identical=True,
                memory_complete_non_time_matches_timing=non_time(actual[('memory',arm)][0][0]) == non_time(raw),
                memory_IDs_match_timing=actual[('memory',arm)][0][1]['generated_ids'] == observation['generated_ids']))
    assert len(processes) == len({x['pid'] for x in processes}) == 16
    return plan, table, cold, memory, work, pauses, processes


def main():
    plan, table, cold, memory, work, pauses, processes = collect()
    old_correctness = R/'docs/evidence/correctness/inference-wave-recovery-2026-10-27'
    old_performance = R/'docs/evidence/performance/inference-continuous-wave-current-window-2026-10-27'
    result = dict(schema='hyle.performance.long-input.v1', date='2026-10-27', status='COMPLETE16_FOUR_GROUPS_STABLE',
        scope='Finite uninstrumented ordinary CUDA natural generation, default-auto Hyle versus frozen local native peer; whole-prefill long-input comparison.',
        counts=dict(actual_model_processes=16, unmonitored_timing_processes=12, separate_memory_processes=4,
            samples_per_timing_arm_and_case=3, separate_memory_samples_per_arm_and_case=1,
            failed=0, rerun=0, CXX=0, links=0, SDK=0, NVCC=0, downloads=0),
        images=[dict(role=k, **v['image']) for k,v in plan['images'].items()],
        hardware='Windows WDDM, NVIDIA GeForce RTX4070, driver617.14; original outside-process GPU snapshots retained. No fixed clocks, profiler, warmup or OS cache reset.',
        workloads=[dict(case=c['name'], prompt_rows=c['prompt_rows'], capacity=c['capacity'], maximum_outputs=64,
            actual_outputs=46 if c['name']=='p1024' else 64, full_decode_outputs=45 if c['name']=='p1024' else 63,
            matched_IDs=True, EOS_last_id=248046 if c['name']=='p1024' else None,
            prompt=c['prompt'], schedule=c['schedule']) for c in plan['cases']],
        configuration='N1/R1, target-only BF16 roles/GGUF, greedy, prefix off, replay auto; Hyle default-auto has no decode-overlap flag. Each peer scheduled workload contains exactly one turn; no --steps or forced IDs/EOS.',
        batching='Both actual producers run one full P-row prefill: Hyle unbounded prefill and one Graph prefill call, peer n_batch=n_ubatch=P with only final logits. Cases are P1024/C2048 and P4032/C4096; the latter is not P4096.',
        table_order='Timing arrays are [median,min,max], TPS=emitted or actual prefill tokens/second; GPU MiB is one independent sampled memory maximum, not three-sample timing data.',
        four_metrics_table=table, load_ready_and_cold_table=cold, RAM_and_GPU_table=memory,
        formulas=[
            'Prefill TPS = actual P / original complete prefill seconds, including first selected output. Full decode TPS = (actual emitted IDs-1) / original complete decode interval.',
            'Overall output TPS = actual emitted IDs / original (prefill+decode) session interval. Cold output TPS charges original startup-to-final endpoint. Original load/ready/first-output boundaries remain unchanged.',
            'Every result passes original P+D=session tolerance; actual decode calls require positive decode time. A legal first-output EOS would retain zero decode and null decode TPS; this window actually emitted46/64 IDs.',
            'Memory uses retained PSAPI working set/private commit and PDH WDDM dedicated/shared GPU counters at requested10ms; actual gaps, costs, phase windows, ready unknown and nulls are preserved.'
        ], actual_work=work,
        EOS_observation='All P1024 processes naturally emitted the same46 IDs ending248046. Hyle actually accepted38 successors, published37 and retired/discarded1 after the stop; final live committed owners0. This is a finite real model EOS/retirement check, not a complete hidden-state oracle.',
        quota_observation='All P4032 processes emitted the same64 requested IDs (last4479), no EOS; Hyle55 successor publications, zero refusal/discard. IDs match between engines and across each arm’s timing repetitions.',
        first_pair_and_resume=pauses,
        sample_policy='Both first pairs remain samples1/2. Root inspected their real IDs/EOS/work, paused, then explicitly resumed only ordinals3..6. Independent memory pairs followed completed timing; no successful process was replayed, replaced or discarded.',
        source_and_reuse=dict(original_plan=pin(V/'plan.json'), actual_runner=pin(W/'window.py'),
            Hyle_build_and_source_archive=pin(old_correctness.with_suffix('.zip')),
            original_clocks_sampler_peer_archive=pin(old_performance.with_suffix('.zip')),
            source_main_sha256=plan['images']['hyle']['source']['sha256'],
            source_peer_sha256=plan['images']['peer']['source']['sha256'],
            identity_policy='Reuse retained full image/weight identities with current existence/size checks; only small receipts/input files are hashed. No model/SDK payload copy or new large-file hash.'),
        limits=[
            'Three timing samples per arm give descriptive median/range only: no statistical significance, generalized speedup or architecture-causal attribution. No latest-upstream comparison.',
            'Prompts repeat the frozen original154-token prompt to1024/4032. They are finite synthetic length extensions, not semantic long-context or model-quality evaluations.',
            'Matched emitted IDs improve workload comparability, but Hyle P1024 executes one extra discarded target call/row; original producer host endpoint scopes also differ and are not subtracted away.',
            'Dedicated/shared maxima can occur at different samples; only same-sample total sums concurrent GPU values. CPU working set/private commit and GPU shared memory must not be summed as physical RAM.',
            'Sampled peaks are lower bounds, ready snapshots absent remain unknown/null, and unsupported/exited-process counter values are retained. No direct DXGI allocator, exact physical peak or hardware-fault proof.',
            'Only CUDA ordinary N1/R1, these two capacities/prompts, max64, current frozen images. No MTP/off arm, random sampling, arbitrary-length claim, complete hidden-state comparison or other-platform check.'
        ], archive=dict(status='PENDING_OFFLINE_ZIP', filename=STEM+'.zip'))
    D.mkdir(parents=True, exist_ok=True); output=D/(STEM+'.json'); compact(output,result)
    if len(sys.argv)>1 and sys.argv[1]=='receipt':
        print(json.dumps(dict(status='RECEIPT_READY_ZIP_PENDING',json=pin(output)))); return
    save(W/'process-index.json',dict(actual_processes=16,processes=processes))
    files=set()
    def add(path):
        p=Path(path).resolve(); assert p.is_relative_to(R) and p.is_file() and p.suffix.lower() not in FORBIDDEN,str(p)
        files.add(p)
    for p in V.iterdir():
        if p.is_file() and p.suffix.lower() in ('.json','.ids','.txt'):add(p)
    for p in W.rglob('*'):
        if p.is_file() and p.suffix.lower() not in FORBIDDEN and p.name not in ('runs.json','observation.json','package-result.json'):
            add(p)
    # Reuse full prior frozen-source archives; archive current receipts and
    # exact helper code only, not SDK trees, binary closures or model payloads.
    for image in plan['images'].values():
        for field in ('ready','runtime_environment','source','link_inputs','compiled_identity','link_plan'):
            if field not in image:continue
            row=image[field];exact(row)
            if field!='source':add(row['path'])
    ready=read(plan['images']['hyle']['ready']['path'])
    for row in (ready['compiled']['command'],ready['compiled']['compiler_dependencies'],ready['compiled']['actual_dependencies'],ready['recipe'],ready['plan']):exact(row);add(row['path'])
    for p in (old_correctness.with_suffix('.json'),old_performance.with_suffix('.json'),
        R/'.scratch/qwen-mtp-window-20261022/window.py',R/'.scratch/inference-current-review-profile-20261027/analyze.py',
        R/'.scratch/architecture-refactor-2026-10-18/d4-windows-preparation-2026-10-21/first-decode-startup-2026-10-21/multiturn/multiturn_run.py',
        R/'.scratch/architecture-refactor-2026-10-18/qwen-gpu-comparison/memory-probe/memory_probe.py',
        R/'.scratch/shared-execution-20261021/observer.py',Path(plan['weights']['hyle_manifest']['path'])):add(p)
    source_reuse=[]
    for role,archive in (('hyle',old_correctness.with_suffix('.zip')),('peer',old_performance.with_suffix('.zip'))):
        expected=plan['images'][role]['source']['sha256']
        with zipfile.ZipFile(archive) as z:
            manifest=read_manifest=json.loads(z.read('manifest.json'))
            record=next(row for row in manifest['members'] if row['sha256']==expected)
            assert sha(z.read(record['member']))==expected
            source_reuse.append(dict(role=role,archive=pin(archive),member=record))
    save(W/'reuse-receipts.json',dict(source_reuse=source_reuse,large_payloads_rehashed=False,
        omitted_redundant_files=['*/runs.json','*/observation.json'],
        reconstruction='Original raw process/result/normalized producer reports and fixed inputs retained; runner regenerates redundant observations/reductions.'))
    add(W/'reuse-receipts.json')
    members=[]
    for p in sorted(files):
        item=pin(p);members.append(dict(member=p.relative_to(R).as_posix(),bytes=item['bytes'],sha256=item['sha256']))
    manifest=(json.dumps(dict(schema='hyle.archive.manifest.v1',members=members,source_reuse=source_reuse,binary_model_or_SDK_payload=False),indent=2)+'\n').encode()
    destination=D/(STEM+'.zip')
    with zipfile.ZipFile(destination,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for row in members:
            data=(R/row['member']).read_bytes();assert len(data)==row['bytes'] and sha(data)==row['sha256'];z.writestr(row['member'],data)
        z.writestr('manifest.json',manifest)
    with zipfile.ZipFile(destination) as z:
        assert z.testzip() is None and len(z.namelist())==len(members)+1
        for row in members:
            data=z.read(row['member']);assert len(data)==row['bytes'] and sha(data)==row['sha256']
        assert z.read('manifest.json')==manifest
    result['archive']=dict(**pin(destination),members=len(members)+1,all_member_bytes_and_sha256_read_back=True)
    compact(output,result)
    final=dict(status='PACKAGED_VERIFIED',json=pin(output),zip=pin(destination),members=len(members)+1,actual_processes=16)
    save(W/'package-result.json',final);print(json.dumps(final))


if __name__=='__main__':main()
