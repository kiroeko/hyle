$ErrorActionPreference = 'Stop'
$repoRoot = 'C:\public\project-hyle\hyle'
$buildRoot = [IO.Path]::GetFullPath('C:\hyle-scratch\active-cpu\p1')
$parentRoot = [IO.Path]::GetFullPath('C:\hyle-scratch\active-cpu')
if ($buildRoot -ne 'C:\hyle-scratch\active-cpu\p1' -or
    -not $buildRoot.StartsWith($parentRoot + '\', [StringComparison]::OrdinalIgnoreCase)) {
  throw 'Invalid P1 rotation target'
}
$result = Get-Content -LiteralPath (Join-Path $repoRoot '.scratch\validation\onednn-aa\f1-delivery-result.json') -Raw | ConvertFrom-Json
if ($result.exit_code -ne 0) { throw 'Delivery must finish before the next heavy job' }
$items = @((Get-Item -LiteralPath $buildRoot)) + @(Get-ChildItem -LiteralPath $buildRoot -Recurse -Force)
if (@($items | Where-Object { $_.Attributes -band [IO.FileAttributes]::ReparsePoint }).Count) {
  throw 'Refuse rotation through a reparse point'
}
$logicalBytes = ($items | Where-Object { -not $_.PSIsContainer } | Measure-Object Length -Sum).Sum
$env:PYTHONUTF8 = '1'
@'
import hashlib, json, pathlib, zipfile
root = pathlib.Path('C:/public/project-hyle/hyle')
build = pathlib.Path('C:/hyle-scratch/active-cpu/p1')
evidence = root/'evidence/performance/onednn-normalization-p1-e33b6fea-w1-win'
logs = root/'.scratch/validation/onednn-aa'
manifest = json.loads((evidence/'manifest.json').read_text(encoding='utf-8'))
assert manifest['source']['revision'] == 'e33b6fea4b80d4b82adb6a267dc52ba2ad7a73f9'
def sha(p):
    with p.open('rb') as stream:
        return hashlib.file_digest(stream,'sha256').hexdigest()
with zipfile.ZipFile(evidence/'raw-bundle.zip') as bundle:
    assert bundle.testzip() is None
entries = {}
for artifact in manifest['artifacts']:
    p = pathlib.Path(artifact['file']['path'])
    if p.is_relative_to(build):
        assert sha(p) == artifact['file']['sha256'], str(p)
        entries[p.relative_to(build).as_posix()] = p
for p in (build/'bin').glob('*.dll'):
    entries[p.relative_to(build).as_posix()] = p
archive = logs/'original-p1-artifacts.zip'
assert not archive.exists()
identities = {name: {'bytes':p.stat().st_size,'sha256':sha(p)} for name,p in entries.items()}
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as bundle:
    for name,p in entries.items():
        bundle.write(p,name)
    bundle.writestr('sha256.json',json.dumps(identities,indent=2)+'\n')
with zipfile.ZipFile(archive) as bundle:
    assert bundle.testzip() is None
    for name,identity in identities.items():
        assert hashlib.sha256(bundle.read(name)).hexdigest() == identity['sha256']
(logs/'original-p1-artifacts.json').write_text(json.dumps({
    'source':manifest['source'], 'archive':str(archive), 'archive_sha256':sha(archive),
    'archive_bytes':archive.stat().st_size,'entries':identities,
    'note':'Original qualification verified before product correction. Exact build artifacts retained here; original absolute build paths are rotated for the next fresh candidate. Raw evidence is unchanged.'
},indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps({'archive':str(archive),'bytes':archive.stat().st_size,'files':len(entries)}))
'@ | python -
if ($LASTEXITCODE -ne 0) { throw 'Original artifact preservation failed; nothing deleted' }
Remove-Item -LiteralPath $buildRoot -Recurse -Force
@{removed=$buildRoot; logical_bytes=$logicalBytes; archive='original-p1-artifacts.zip'; reason='Rotate the single fixed P1 build after preserving original immutable artifacts and evidence'} |
  ConvertTo-Json | Set-Content -LiteralPath (Join-Path $repoRoot '.scratch\validation\onednn-aa\f1-p1-cleanup.json') -Encoding utf8
