import hashlib
import json
from pathlib import Path
import shutil
import statistics
import subprocess
import zipfile

root=Path('C:/public/project-hyle/hyle')
scratch=root/'.scratch/validation/onednn-aa'
run=root/'.scratch/perf-runs/onednn-normalization-f1-p1'
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
assert head.startswith('64e1e169')
assert not subprocess.check_output(['git','status','--porcelain'],cwd=root)
def read(path): return json.loads(path.read_text(encoding='utf-8-sig'))
def sha(path):
    with path.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
m=read(run/'manifest.json'); s=read(run/'summary.json')
v=read(scratch/'f1-diagnostic-verify.json')
assert m['source']['revision']==head
assert m['qualification']==s['qualification']==v['qualification']=='DIAGNOSTIC'
assert v['paths_verified'] and v['provenance_compatibility']=='EXACT'
assert m['artifacts_stable'] and m['inputs_stable'] and m['host_stable']
assert all(row['gate']=='PASS' for row in m['controls'])
runs=[]
for line in (run/'validators/normalization-workload-aa.log').read_text(encoding='utf-8').splitlines():
    try:r=json.loads(line)
    except json.JSONDecodeError:continue
    if 'ratios' in r:runs.append(r)
assert len(runs)==16
outliers=[]; factor_failures=[]
for r in runs:
    for name,ratio in r['ratios'].items():
        if not 1/1.10<=ratio<=1.10:
            outliers.append({key:r[key] for key in ('route','variant','order','allocation')}|
                            {'workload':name,'ratio':ratio})
for route in ('selected','peer'):
    group=[r for r in runs if r['route']==route]
    for name in group[0]['ratios']:
        medians={'all':statistics.median(r['ratios'][name] for r in group)}
        for factor in ('variant','order','allocation'):
            for level in {r[factor] for r in group}:
                medians[factor+'='+level]=statistics.median(r['ratios'][name] for r in group if r[factor]==level)
        if any(not 1/1.05<=x<=1.05 for x in medians.values()):
            factor_failures.append({'route':route,'workload':name,'medians':medians})
assert len(outliers)==1 and not factor_failures
diagnostic=read(scratch/'f1-aa-diagnostic/receipt.json')
assert diagnostic['binary_unchanged'] and diagnostic['candidate']==head
rows=[]
for row in s['workloads']:
    strata=row['strata']
    rows.append({'id':row['id'],'qualification':'DIAGNOSTIC','direction':'UNSIGNED',
                 'observed_stratum_median_ratio_range':[
                    min(x['estimate']['median_advantage_ratio'] for x in strata),
                    max(x['estimate']['median_advantage_ratio'] for x in strata)],
                 'descriptive_median_microseconds':{
                    side:statistics.median(1e6/x['absolute'][side+'_median'] for x in strata)
                    for side in ('candidate','peer')}})
out=root/'evidence/performance/onednn-normalization-f1-64e1e169-w1-win'
out.mkdir(exist_ok=False)
for name in ('manifest.json','summary.json','controls.json','contract-lock.json'):
    shutil.copyfile(run/name,out/name)
shutil.copyfile(scratch/'f1-diagnostic-verify.json',out/'verify.json')
shutil.copyfile(scratch/'f1-p1-loc.json',out/'loc.json')
(out/'diagnostic-observations.json').write_text(json.dumps(rows,indent=2)+'\n',encoding='utf-8',newline='\n')
entries=[(p,'attempt/'+p.relative_to(run).as_posix()) for p in run.rglob('*') if p.is_file()]
for name in ('f1-p1.ps1','f1-p1-launch.log','f1-p1-launch-result.json','f1-p1-environment.log',
             'f1-diagnostic-verify.json','f1-p1-loc.json','f1-preflight-source-audit.md',
             'f1-compile-cost-audit.json','f1-rotate-p1.ps1','f1-p1-cleanup.json',
             'original-p1-artifacts.json','f1-aa-diagnostic.py','collect-f1-diagnostic.py'):
    entries.append((scratch/name,'receipts/'+name))
entries.extend((p,'bounded-diagnostic/'+p.name) for p in (scratch/'f1-aa-diagnostic').iterdir() if p.is_file())
with zipfile.ZipFile(out/'raw-bundle.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for p,name in entries:z.write(p,name)
    z.writestr('file-sha256.json',json.dumps([
        {'path':name,'bytes':p.stat().st_size,'sha256':sha(p)} for p,name in entries],indent=2)+'\n')
with zipfile.ZipFile(out/'raw-bundle.zip') as z:assert z.testzip() is None
result={'candidate':head,'product_fix':'ae270af9ceb948b09601b26f32454eb28d32dff3',
        'qualification_gate':'FAIL','engineering_performance':'INCONCLUSIVE',
        'pre_sampling_workload_aa':'PASS as recorded in manifest; final validator log replaces the initial command log',
        'post_sampling_workload_aa':'FAIL','aa_observations':256,'gross_outliers':outliers,
        'fixed_factor_median_failures':factor_failures,
        'common_controls':{row['id']:row['gate'] for row in m['controls']},
        'product_children':120,'control_children':30,'samples_per_stratum':15,
        'bounded_diagnostic':diagnostic,
        'diagnostic_interpretation':'The four fixed same-artifact oneDNN/oneDNN cells do not reproduce the 21% deviation. This neither identifies an OS/JIT/allocation cause nor replaces the failed qualification.',
        'unchanged_full_retries_available':0,
        'default_rules':'UNSIGNED','native_removal':'NONE',
        'remaining':'Bounded separate workload-AA qualification task, then remaining AA04 default rules; no additional unchanged full run',
        'limitations':'No performance winner or SIMD/Sched defect is inferred from this unqualified sample. Correctness and three deliveries are separately PASS.',
        'old_build_cleanup':read(scratch/'f1-p1-cleanup.json')}
(out/'result.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8',newline='\n')
(out/'README.md').write_text('''# C1-AA04-F1: qualification failure retained

Frozen source `'''+head+'''`; product correction `ae270af9`.
Correctness and Graph source/static/shared delivery passed separately. Performance
qualification FAIL; engineering performance INCONCLUSIVE. No speed winner is signed.

The workload A/A passed before sampling. All 120 product children (n=15 in eight
strata) and 30 common controls completed. All five common controls pass; source,
artifacts and host identity remain stable. The final workload A/A contains one
gross outlier among 256 ratios: oneDNN versus itself, primary placement,
peer-first execution and allocation, Direct LayerNorm 1x2048, ratio 1.21435.
Every aggregate/factor A/A median remains inside its existing 5% band. The outlier's
own paired-round interval excludes equality, so it is not dismissed as a timer tick.

One bounded four-child same-artifact diagnostic crossed both orders and allocations.
Its affected-row ratios were 1.00731, 0.99646, 0.95003 and 1.01484. The original
deviation did not recur, but its OS, code/data-placement or runtime cause is unknown.
This diagnostic is not a retry, qualification or permission to discard the failure.
No complete run was repeated, no threshold changed and no outlier removed.

The corrected Graph actually uses an optimized norm/vector-Mul region and a Native
residual node for multiple rows. All unqualified observations are retained for
source/cost investigation only; they cannot sign routing, deletion or a SIMD defect.
The earlier qualified 4 wins/12 losses remain a distinct historical result.

Both actual normalization builds use Release /O2. Upstream /Od applies only to
unrelated generated GEMM files. Compiler rules and the complete source/cost bill
are in raw-bundle.zip, together with all logs, scripts and failed qualification.
Deep verify reports DIAGNOSTIC / EXACT / paths_verified at verification time.
Rotating the build later does not preserve its absolute artifact paths.

A separate bounded qualification task must establish an auditable recovery before
another candidate performance run. Default rules and Native removal remain unsigned.
The global C1–C7 goal is not complete. Unified Compute+Graph LOC: 46,955 / 193 files,
excluding tests, benchmarks and vendor code; self-check PASS.
''',encoding='utf-8',newline='\n')
(out/'sha256.json').write_text(json.dumps({p.name:{'bytes':p.stat().st_size,'sha256':sha(p)}
                                         for p in sorted(out.iterdir()) if p.is_file()},indent=2)+'\n',
                                encoding='utf-8',newline='\n')
print(json.dumps({'output':str(out),'raw_files':len(entries),'raw_bytes':(out/'raw-bundle.zip').stat().st_size}))
