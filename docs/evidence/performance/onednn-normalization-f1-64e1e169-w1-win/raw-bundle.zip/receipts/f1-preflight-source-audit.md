# F1 normalization comparison: source and cost preflight

Frozen running revision: `64e1e169`; product fix: `ae270af9`.
Contract SHA256: `1e6cebeb86a2a599ae5b5fd3b833a089126927d1a5dcd0c6a427204fc6aa0729`.

- Both Direct arms use retained Context/Queue, `OperationInvocation::submit`
  and `Completion::wait`; both Graph arms use `Invocation::submit` and the same
  terminal wait. The complete public boundary, checks, mapping close and
  completion destruction remain inside each timed callback.
- Both arms consume the same initialized F32 data and parameters, independent
  outputs, epsilon and final mathematical result. `Problem::verify` checks the
  independent FP64 oracle before timing. Cold creation, JIT, binding, workspace
  allocation, Graph planning and warmup are outside both timed callbacks.
- The corrected multirow Graph arm contains an actual oneDNN norm/vector-Mul
  region plus a Native full-shape Add. The peer has the same norm/Mul/Add as
  three Native nodes. Single-row oneDNN retains all three fused nodes. Provider
  ID, region count, step count, prefix node count and mixed-provider status are
  checked, so an all-Native candidate cannot fake the mature implementation.
- Extra Graph state/edges and materialized output between the optimized prefix
  and residual are charged. Graph backing is retained and reused on both sides.
  Vendor replay metadata allocation is charged; the oneDNN runtime stays
  Managed. No allocation, copy or synchronization was hidden for F1.
- Both providers receive the empty serial executor. The canonical launcher
  fixes the same logical P core; no worker-pool competition is in this contract.
  Execution order, creation/allocation order and code placement remain crossed.
- The F1 product change adds only cold validation and exact-preparation checks.
  It changes no SIMD loop, oneDNN algorithm, public API, hot fields, benchmark
  epochs, statistical threshold or common performance instrument.
- Actual generated compile rules were inspected for HYLE's norm TU and both
  oneDNN normalization TUs: all use Release `/O2`. Upstream `/Od` is scoped to
  generated GEMM source and excludes these TUs. Exact rules are saved separately.

This experiment qualifies explicit implementation compositions. Ordinary CPU
default preference still needs the AA04 decision. A Direct win cannot sign a
Graph win, and a full-operator result cannot establish isolated SIMD causality.
The original qualified losses remain intact. New A/A or product timing has not
yet been used by this preflight note to select a rule or change source.
