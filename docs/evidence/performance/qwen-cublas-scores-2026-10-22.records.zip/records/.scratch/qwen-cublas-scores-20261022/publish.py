"""Publish AD cuBLAS F32 scores evidence. Explicit execution by root only."""
from pathlib import Path
from collections import Counter
import difflib, hashlib, json, re, subprocess, zipfile

C = Path(__file__).resolve().parent
R = C.parents[1]
A = R / '.scratch/qwen-f32-scores-20261022'
O = R / 'docs/evidence/performance'
NAME = 'qwen-cublas-scores-2026-10-22'
SOURCES = [
    'src/compute_provider_cublas/cublas_provider.cc',
    'src/compute_route_cuda/default_policy.cc',
    'include/hyle/compute/providers/cublas.h',
    'tests/compute_provider_cublas/cublas_provider_test.cc',
    'tests/compute_route_cuda/linear_test.cc',
    'tests/compute_route_cuda/CMakeLists.txt',
    'tools/qwen35_text/README.md',
    'docs/developer/current-work.md',
]
NEW_SOURCE = 'tests/compute_route_cuda/linear_test.cc'
EXCLUDED = {'.exe', '.dll', '.obj', '.map', '.lib', '.exp', '.pdb', '.pyc', '.tmp'}
EXCLUDED_NAMES = {'published.json', 'cleanup-plan.json', 'cleanup-result.json',
                  'cleanup_script.ps1', 'postconditions.json'}

def read(p):
    return json.loads(Path(p).read_text(encoding='utf-8-sig'))

def save(p, value):
    Path(p).write_text(json.dumps(value, indent=2, ensure_ascii=False,
                                allow_nan=False) + '\n', encoding='utf-8')

def identity(p):
    p = Path(p)
    h = hashlib.sha256()
    with p.open('rb') as f:
        for block in iter(lambda: f.read(8 << 20), b''):
            h.update(block)
    return dict(path=str(p.resolve()), bytes=p.stat().st_size, sha256=h.hexdigest())

def same(record):
    return identity(record['path']) == record

def key(record):
    return record['path'], record['bytes'], record['sha256']

def main():
    archive, manifest = O / (NAME + '.data.zip'), O / (NAME + '.json')
    assert not archive.exists() and not manifest.exists(), 'Publication already exists'
    O.mkdir(parents=True, exist_ok=True)
    # Existing-source before files are original AD backups. The one new test
    # has no prior source; never manufacture a pre-existing empty test file.
    frozen = []
    for name in SOURCES:
        p, before = R / name, C / 'before' / name
        assert p.is_file(), name
        assert before.is_file() if name != NEW_SOURCE else not before.exists(), name
        snapshot = C / 'current' / name
        snapshot.parent.mkdir(parents=True, exist_ok=True)
        snapshot.write_bytes(p.read_bytes())
        diff = C / 'product-diffs' / (name.replace('/', '--') + '.diff')
        diff.parent.mkdir(exist_ok=True)
        previous = before.read_text(encoding='utf-8-sig').splitlines(True) if before.exists() else []
        diff.write_text(''.join(difflib.unified_diff(previous,
            p.read_text(encoding='utf-8-sig').splitlines(True),
            fromfile='before/' + name if before.exists() else '/dev/null', tofile=name)), encoding='utf-8')
        check_before = before
        if not before.exists():
            check_before = C / 'product-diffs/empty-new-file-before.txt'
            check_before.write_bytes(b'')
        check = subprocess.run(['git', 'diff', '--no-index', '--check', str(check_before), str(p)],
                               capture_output=True, text=True, encoding='utf-8', errors='replace')
        assert check.returncode in (0, 1) and not (check.stdout.strip() or check.stderr.strip()), (name, check.stdout, check.stderr)
        frozen.append(dict(source=identity(p), snapshot=identity(snapshot),
            before=identity(before) if before.exists() else None,
            new_file=not before.exists(), diff=identity(diff)))
    save(C / 'product-freeze.json', dict(files=frozen,
        unchanged_provider_test_CMake=identity(R / 'tests/compute_provider_cublas/CMakeLists.txt')))

    ready, test_ready = read(C / 'qwen-ready-attempt1.json'), read(C / 'tests-ready-attempt1.json')
    old = read(A / 'qwen-ready-attempt1.json')
    for record in (ready, test_ready, old):
        assert all(same(record[k]) for k in ('source', 'main', 'image', 'runtime_environment'))
    assert ready['source'] == old['source'] and not ready['consumer_recompiled']
    assert same(ready['consumer_compiled_record']) and same(test_ready['consumer_compiled_record'])
    consumer = read(ready['consumer_compiled_record']['path'])
    compiled = {}
    compile_receipts = []
    for folder in ('compile1/cublas', 'compile2/cublas', 'compile1/policy', 'compile1/test', 'compile1/route_test'):
        d = C / folder
        result = read(d / 'compile.result.json')
        expected = 2 if folder == 'compile1/cublas' else 0
        assert result['terminal'] and result['exit'] == expected, folder
        entry = dict(stage=folder, exit=result['exit'], terminal=identity(d / 'compile.result.json'),
                     command=identity(d / 'compile.command.json'), stdout=identity(d / 'compile.stdout.log'),
                     stderr=identity(d / 'compile.stderr.log'))
        if expected == 0:
            item = read(d / 'identity.json')
            assert same(item['source']) and same(item['object'])
            compiled[folder] = item
            entry.update(source=item['source'], object=item['object'], identity=identity(d / 'identity.json'))
        else:
            assert 'C2678' in (d / 'compile.stdout.log').read_text(encoding='utf-8-sig')
        compile_receipts.append(entry)
    assert len(ready['compiled_records']) == 2 and len(test_ready['compiled_records']) == 4
    assert all(same(i) for i in ready['compiled_records'] + test_ready['compiled_records'])
    links = []
    for folder, record, count in (('qwen-link1', ready, 195), ('tests-link1', test_ready, 198)):
        result = read(C / folder / 'link.result.json')
        plan = read(record['link_plan']['path'])
        assert same(record['link_plan']) and result['terminal'] and result['exit'] == 0
        assert result['command'] == plan['command'] and len(plan['inputs']) == count
        assert plan['replaced_product_inputs'] == 2 and not plan['consumer_recompiled']
        for name in ('compile2/cublas', 'compile1/policy'):
            assert compiled[name]['object'] in plan['inputs']
        if folder == 'tests-link1':
            assert consumer['object'] not in plan['inputs']
            assert all(compiled[n]['object'] in plan['inputs'] for n in ('compile1/test', 'compile1/route_test'))
        else:
            assert consumer['object'] in plan['inputs']
        base = read(plan['base']['path'])
        reused = sum((Counter(map(key, plan['inputs'])) & Counter(map(key, base['inputs']))).values())
        if folder == 'qwen-link1':
            assert reused == 193
        links.append(dict(stage=folder, result=identity(C / folder / 'link.result.json'),
            plan=record['link_plan'], inputs=count, unchanged_original_inputs=reused))

    reports = {p.name: read(p) for p in sorted((C / 'review').glob('*.json'))}
    score = reports['actual-score-analysis.json']
    assert score['checks_passed'] and score['check_count'] == 1037
    assert score['status'] == 'offline_actual_raw_review_complete'
    assert all(x['hidden_byte_equal'] and x['logits_byte_equal'] for x in score['ordinary_control'])
    final_source = reports['final-source-review.json']
    assert final_source['findings'] == [] and final_source['required_source_corrections'] == []
    for item in final_source['sources']:
        actual = identity(R / item['path'])
        assert (actual['bytes'], actual['sha256']) == (item['bytes'], item['sha256'])
    correction = reports['round-ledger-time-filter-review.json']
    assert correction['status'] == 'FROZEN_HOST_ONLY_TIMING_METADATA_CORRECTION'
    assert correction['timing_runs_bytes_unchanged'] and correction['all_other_summary_fields_unchanged']
    assert same(correction['performance_script']) and same(correction['timing_summary']) and same(correction['timing_runs'])
    window = reports['actual-window-review.json']
    assert window['status'] == 'FROZEN_HOST_ONLY_REVIEW'
    verification = window['verification']
    assert verification['timing_processes'] == 9 and verification['independent_memory_processes'] == 3
    for field in ('all_exit_zero', 'all_stdout_matches_retained_raw', 'all_timing_P_plus_D_equals_session',
                  'per_process_ratios_and_summary_statistics_match', 'each_arm_timing3_and_memory1_IDs_work_decisions_equal',
                  'Hyle_F32_contract_and64IDs_work_decisions_equal', 'memory_peaks_gaps_cost_phases_deltas_recomputed',
                  'ready_sample_missing_in_all3_memory_runs'):
        assert verification[field] is True, field
    assert all(same(item) for item in window['sources'])
    timing, memory = read(C / 'performance/timing/summary.json'), read(C / 'performance/memory/summary.json')
    assert timing['processes'] == 9 and memory['processes'] == 3
    assert timing['fixed_work_window_valid'] and memory['fixed_work_window_valid']
    assert timing['between_arm_first_process_outputs']['before_MTP__after_MTP']['equal']
    assert timing['between_arm_first_process_outputs']['after_MTP__peer_MTP']['first_divergence'] == 18
    delta = (memory['groups']['after_MTP']['sampled_peaks']['sampled_peak_gpu_dedicated_bytes'] -
             memory['groups']['before_MTP']['sampled_peaks']['sampled_peak_gpu_dedicated_bytes'])
    assert delta == -113246208

    runs = []
    test_result = read(C / 'tests-run1/run.result.json')
    test_log = (C / 'tests-run1/run.stdout.log').read_text(encoding='utf-8-sig')
    assert test_result['terminal'] and test_result['exit'] == 0
    assert test_result['command'][0] == test_ready['image']['path']
    assert len(re.findall(r'^\[       OK \] [A-Za-z0-9_.]+', test_log, re.M)) == 11
    assert '[  PASSED  ] 11 tests.' in test_log
    runs.append(dict(category='unit_tests', command=test_result['command'],
        terminal=identity(C / 'tests-run1/run.result.json'), performance_evidence=False, model_process=False))
    diagnostics = sorted((C / 'cases1').glob('*/run.result.json'))
    assert len(diagnostics) == 5
    for p in diagnostics:
        result = read(p)
        assert result['terminal'] and result['exit'] == 0
        runs.append(dict(category='diagnostic', command=result['command'], terminal=identity(p),
                         performance_evidence=False, model_process=True))
    for mode, count in (('timing', 9), ('memory', 3)):
        paths = sorted((C / 'performance' / mode).glob('*/result.json'))
        assert len(paths) == count
        for p in paths:
            result = read(p)
            assert result['exit'] == 0 and not result['reader_errors']
            runs.append(dict(category=mode, command=result['command'], terminal=identity(p),
                performance_evidence=mode == 'timing', model_process=True))
    assert len(runs) == 18 and sum(r['model_process'] for r in runs) == 17
    summary = dict(status='Existing mixed-output score contract implemented in cuBLAS and naturally selected; finite and limited-window evidence retained; broader goal active',
        date='2026-10-22', product_freeze=identity(C / 'product-freeze.json'), ready=ready,
        tests_ready=test_ready, before_ready=old,
        build_scope=dict(host_compile_attempts=5, successful_host_compiles=4, failed_host_compiles=1,
            successful_links=2, provider_TUs=1, policy_TUs=1, test_TUs=2, consumer_TUs=0,
            SDK_builds=0, NVCC_builds=0, full_configures=0, qwen_link_inputs=195,
            qwen_reused_link_inputs=193, tests_link_inputs=198, compile_receipts=compile_receipts, links=links),
        actual_total_processes=18, actual_model_processes=17, unit_test_processes=1, GTests=11,
        diagnostic_processes=5, timing_processes=9, independent_memory_processes=3, actual_runs=runs,
        reports=reports, performance=dict(timing=timing, memory=memory),
        findings=[
            'Existing BFloatLinearF32 now admits native cuBLAS BF16[T,K] and stored BF16[E,K] to F32[T,E]. Original weight pointer is described as COL[K,E]; no transpose/copy/repack/kernel or consumer change was added. Ordinary MatMul retains its same-dtype contract.',
            'Private geometry uses each port dtype and2/2/4-byte storage units. Compute policy follows BF16 input, not F32 output;32MiB workspace preference, original queue/Invocation/capture and accepted-prefix lifetime remain unchanged.',
            'After original capability/resource admission, default policyv2 ranks admitted plain rank2 cuBLAS candidates99 (Graph299). Other/rank>2 and specific Graph fusion ordering remain. Public Direct route and actual Graph score routes select cuBLAS without a consumer override.',
            'Provider compile1 failed because custom_as returns optional; original source/logs remain. Root changed presence check to.has_value(); provider compile2 and policy/provider-test/route-test compile1 succeeded. Two actual links use these exact objects; no consumer/native/SDK rebuild occurred.',
            'Eleven GTests passed, including non-square stored weights, sub-BF16 F32 witness, dtype negatives, old broadcasts/lanes/native-use lifetime and separate default-route integration. Five diagnostics retain98raw files/64finite target score rows with own argmax matching all IDs.',
            'Both ordinary arms use BF16-input/F32-output scores: four upstream hidden and993280scores are byteequal. Selected original-weight FP64 dots satisfy the condition-checked conventional F32 forward-error comparison; this does not independently validate a full model or an unexported draft hidden.',
            'Real R2 warm uses5Graph/9participations; N1 pressure uses29=19new+10recompute Graph,64target/64draft restore rows, normalized lag1, and no live versions at exit. Draft coverage is declared shared operation, actual routes and natural execution, not an independent draft oracle.',
            'Same-window Hyle prefill median2027.6204->2341.5821tok/s; complete decode121.7842->122.1884 has overlapping ranges;64/session107.8786->109.8450 has nonoverlapping three-sample ranges. Startup-to-end medians2.1922366->2.1920751seconds have overlapping ranges; no general significance or cold-start win is claimed.',
            'One separate memory process per arm reports dedicated peak4478550016->4365303808B, delta-113246208B(-108MiB). This is an observed sampled peak change, not an exact physical allocation saving or proof of one buffer attribution. Actual gaps, cost, phase/null/ready limits and CPU/private/shared/same-sample total remain in reports.',
            'Before/current Hyle64IDs/work/decisions match. Peer diverges at zero-index18 and has different natural work/arithmetic; its rates are descriptive, not a same-token speed or quality comparison.',
            'Round-ledger comparison originally included volatile timing fields and falsely marked instability. The host-only correction drops only seconds/*_seconds keys; original false summaries/script backups and raw runs are retained, with zero model reruns.',
            'preparation-freeze.json describes earlier build/performance scripts. It is preserved as historical preparation and is not asserted to match current build.py/performance.py; actual command/identity/terminal records are authoritative.'],
        limitations=['Three timing samples and one memory process per arm do not establish universal performance, exact allocation delta or model quality.',
            'F32-score contract remains the same, but vendor reduction bit identity is not a general guarantee. Ordinary byteidentity is this finite control only.',
            'No new full MTP state/retirement probe was built or run by this batch. Earlier probe results retain their original source/score policy scope.',
            'Mixed-output cuBLAS availability does not guarantee every backend or shape support; actual native qualification remains authoritative.',
            'Capture invalidation, other models/backends/quantization/image and complete architecture remain open.'],
        previous_evidence=['docs/evidence/performance/qwen-f32-scores-2026-10-22.json',
            'docs/evidence/correctness/qwen-mtp-batch-numerics-2026-10-22.json',
            'docs/evidence/performance/qwen-mtp-divergence-2026-10-22.json'],
        next_actions=['Use a minimal cold diagnostic to identify the remaining actual capture invalidation mechanism before another optimization; do not infer causation from a prepare bucket.',
                      'Continue explicitly scoped architecture/model/backend work without declaring whole quality or goal completion.'])
    save(C / 'actual-summary.json', summary)
    # All AD source/receipts/failed attempts/old false analysis/raw are retained.
    # Prior AC consumer/input/SDK closures are referenced, not copied wholesale.
    files = sorted(p for p in C.rglob('*') if p.is_file() and p.suffix.lower() not in EXCLUDED
        and not any(part in ('tmp', '__pycache__') for part in p.relative_to(C).parts)
        and p.name not in EXCLUDED_NAMES)
    entries, unique = [], {}
    with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED, compresslevel=6) as z:
        for p in files:
            item = identity(p)
            content = item['bytes'], item['sha256']
            entry = unique.get(content)
            if entry is None:
                entry = p.relative_to(R).as_posix()
                unique[content] = entry
                z.write(p, entry)
            else:
                item['identical_content_alias'] = True
            item['entry'] = entry
            entries.append(item)
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None and len(z.namelist()) == len(unique)
        for (size, sha), entry in unique.items():
            data = z.read(entry)
            assert len(data) == size and hashlib.sha256(data).hexdigest() == sha
    save(manifest, dict(**summary, archives=[identity(archive)], archive_files=entries,
        archive_verified=dict(CRC=True, all_unique_entry_SHA256=True, source_files=len(entries),
            unique_entries=len(unique), original_bytes=sum(i['bytes'] for i in entries),
            unique_bytes=sum(k[0] for k in unique), content_deduplication='All original paths retain SHA/size and canonical ZIP mapping; identical content stored once.')))
    published = dict(manifest=identity(manifest), archives=[identity(archive)])
    save(C / 'published.json', published)
    print(json.dumps(dict(**published, source_files=len(entries), unique_entries=len(unique)), indent=2))

if __name__ == '__main__':
    main()
