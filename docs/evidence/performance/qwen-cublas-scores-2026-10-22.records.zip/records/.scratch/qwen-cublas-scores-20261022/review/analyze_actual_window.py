"""Read existing AD logs/samples only; write the finite independent review."""
from pathlib import Path
import hashlib
import json
import math
import re
import statistics

S = Path(__file__).resolve().parents[1]
ARMS = ('before_MTP', 'after_MTP', 'peer_MTP')
FIELDS = ('working_set_bytes', 'private_commit_bytes', 'gpu_dedicated_bytes',
          'gpu_shared_bytes', 'gpu_total_bytes')


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))


def identity(path):
    path = Path(path).resolve()
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())


def stats(values):
    return dict(count=len(values), median=statistics.median(values), min=min(values), max=max(values)) if values else None


def near(a, b):
    return math.isclose(a, b, rel_tol=1e-11, abs_tol=1e-11)


def decisions(value):
    if isinstance(value, dict):
        return {k: decisions(v) for k, v in value.items() if k != 'seconds' and not k.endswith('_seconds')}
    return [decisions(x) for x in value] if isinstance(value, list) else value


def first_difference(left, right):
    return next((dict(index=i, left=a, right=b) for i, (a, b) in enumerate(zip(left, right)) if a != b), None)


def main():
    source_ids = [identity(Path(__file__))]
    summaries = {mode: read(S / 'performance' / mode / 'summary.json') for mode in ('timing', 'memory')}
    runs = {mode: read(S / 'performance' / mode / 'runs.json') for mode in ('timing', 'memory')}
    for mode in runs:
        source_ids += [identity(S / 'performance' / mode / name) for name in ('summary.json', 'runs.json', 'inputs.json')]
        assert summaries[mode]['status'] == 'complete_stable_within_arm_work'
        assert summaries[mode]['fixed_work_window_valid']
        assert len(runs[mode]) == (9 if mode == 'timing' else 3)
    timing, raw_by_arm, per_process, captures = {}, {}, [], {}
    for arm in ARMS:
        selected = [row for row in runs['timing'] if row['arm'] == arm]
        assert len(selected) == 3
        numbers, raw_by_arm[arm], capture_rows = {}, [], []
        for row in selected:
            folder = Path(row['folder'])
            raw = read(folder / 'stdout.log')
            assert raw == row['observation']['raw']
            assert row['process']['exit'] == 0 and not row['process']['memory_only']
            assert row['process']['throughput_evidence']
            command = row['process']['command']
            assert command[command.index('--capacity') + 1] == '1024'
            ids = raw['generated_ids']
            assert len(ids) == raw['generated_tokens'] == 64
            p, d, session = (raw[key] for key in ('prefill_seconds', 'decode_seconds', 'session_seconds'))
            assert near(p + d, session)
            startup = raw['startup_to_endpoint_seconds']
            if arm == 'peer_MTP':
                assert len(raw['prompt_ids']) == 154
                load = raw['weights_load_seconds']
                ttft = startup - d
                assert raw['requested_context'] == 1024
            else:
                assert raw['score_dtype'] == 'F32' and raw['score_policy'] == 'bf16_inputs_f32_output'
                assert command[command.index('--max-sessions') + 1] == '1'
                assert command[command.index('--active-sequences') + 1] == '1'
                match = re.findall(r'^weights_load_seconds=([0-9.eE+-]+)$', (folder / 'stderr.log').read_text(encoding='utf-8'), re.M)
                assert len(match) == 1
                load, ttft = float(match[0]), raw['first_token_elapsed_seconds']
            values = dict(prefill_tokens_per_second=154 / p, full_decode_tokens_per_second=63 / d,
                          session_output_tokens_per_second=64 / session, cold_output_tokens_per_second=64 / startup,
                          prefill_seconds=p, decode_seconds=d, session_seconds=session,
                          weights_load_seconds=load, startup_to_ready_seconds=raw['startup_to_ready_seconds'],
                          first_token_elapsed_seconds=ttft, startup_to_endpoint_seconds=startup)
            for key, value in values.items():
                assert near(value, row['observation']['metrics'][key]), key
                numbers.setdefault(key, []).append(value)
            raw_by_arm[arm].append(raw)
            if arm != 'peer_MTP':
                matches = re.findall(r'prepared T=(\d+) visible=(\d+) replay=(\S+) cold_batch_seconds=([\d.eE+-]+) capture_recorded=(\d+) capture_reused=(\d+)',
                                     (folder / 'stderr.log').read_text(encoding='utf-8'))
                assert len(matches) == raw['actual_graph_calls'] == 35
                capture = dict(decode_recorded_ranges=sum(int(x[4]) for x in matches[1:]),
                               decode_reused_ranges=sum(int(x[5]) for x in matches[1:]),
                               cold_batch_decode_seconds=sum(float(x[3]) for x in matches[1:]))
                old = row['observation']['capture_ledger']
                assert all(near(value, old[key]) for key, value in capture.items())
                capture_rows.append(capture)
            per_process.append(dict(arm=arm, folder=str(folder), **values))
        timing[arm] = {key: stats(values) for key, values in numbers.items()}
        for key, value in timing[arm].items():
            assert all(near(value[name], summaries['timing']['groups'][arm][key][name]) for name in ('median', 'min', 'max'))
        captures[arm] = capture_rows or None
    work = {}
    for arm in ARMS:
        selected = [row for mode in runs.values() for row in mode if row['arm'] == arm]
        first = selected[0]['observation']
        assert len(selected) == 4
        assert all(row['observation']['generated_ids'] == first['generated_ids'] for row in selected)
        assert all(read(Path(row['folder']) / 'stdout.log') == row['observation']['raw'] for row in selected)
        assert all(row['observation']['work'] == first['work'] for row in selected)
        assert all(decisions(row['observation']['raw']['rounds']) == decisions(first['raw']['rounds']) for row in selected)
        assert all(row['process']['exit'] == 0 for row in selected)
        rounds = first['raw']['rounds']
        accepted = sum(bool(x['accepted_draft']) for x in rounds)
        assert accepted == first['raw']['accepted_drafts']
        work[arm] = dict(exported={key: value for key, value in first['work'].items() if value is not None},
                         round_count=len(rounds), accepted_drafts=accepted, accepted_drafts_per_round=accepted / len(rounds),
                         within_arm_timing3_and_memory1_IDs_work_decisions_equal=True,
                         IDs_sha256=hashlib.sha256(json.dumps(first['generated_ids'], separators=(',', ':')).encode()).hexdigest())
    a, b = raw_by_arm['before_MTP'][0], raw_by_arm['after_MTP'][0]
    assert a['generated_ids'] == b['generated_ids'] and a['rounds'] == b['rounds']
    before_obs = next(x['observation'] for x in runs['timing'] if x['arm'] == 'before_MTP')
    after_obs = next(x['observation'] for x in runs['timing'] if x['arm'] == 'after_MTP')
    assert before_obs['work'] == after_obs['work']
    difference = first_difference(b['generated_ids'], raw_by_arm['peer_MTP'][0]['generated_ids'])
    assert difference == dict(index=18, left=11, right=271)
    changes = {}
    for metric in timing['before_MTP']:
        old, new = timing['before_MTP'][metric], timing['after_MTP'][metric]
        changes[metric] = dict(current_vs_baseline_median_percent=100 * (new['median'] / old['median'] - 1),
                               observed_ranges_overlap=max(old['min'], new['min']) <= min(old['max'], new['max']))
    memory = {}
    for row in runs['memory']:
        arm, folder = row['arm'], Path(row['folder'])
        assert row['process']['memory_only'] and not row['process']['throughput_evidence']
        data = read(folder / 'memory.json')
        samples = [x for x in data['samples'] if x['process_running']]
        summary = summaries['memory']['groups'][arm]
        assert len(samples) == summary['running_sample_count']
        assert data['gpu_setup_error'] is None and data['thread_error'] is None
        peaks = {key: max(x[key] for x in samples if x.get(key) is not None) for key in FIELDS}
        peak_names = dict(working_set_bytes='sampled_max_working_set_bytes', private_commit_bytes='sampled_max_private_commit_bytes',
                          gpu_dedicated_bytes='sampled_peak_gpu_dedicated_bytes', gpu_shared_bytes='sampled_peak_gpu_shared_bytes',
                          gpu_total_bytes='sampled_peak_gpu_total_bytes')
        assert all(value == summary['sampled_peaks'][peak_names[key]] for key, value in peaks.items())
        assert all(x['gpu_total_bytes'] == x['gpu_dedicated_bytes'] + x['gpu_shared_bytes'] for x in samples if x.get('gpu_total_bytes') is not None)
        gaps = stats([(y['timestamp_ns'] - x['timestamp_ns']) / 1e6 for x, y in zip(samples, samples[1:])])
        cost = stats([x['sample_duration_ns'] / 1e6 for x in samples])
        assert gaps == {k: v for k, v in summary['actual_sample_gaps_ms'].items() if k != 'samples'}
        assert cost == {k: v for k, v in summary['sample_cost_ms'].items() if k != 'samples'}
        phases = {}
        markers = {x['name']: x['timestamp_ns'] for x in row['process']['markers']}
        for phase in ('generation_prefill', 'generation_decode'):
            begin, end = markers[phase + '_begin'], markers[phase + '_end']
            selected = [x for x in samples if begin <= x['timestamp_ns'] <= end]
            before = next((x for x in reversed(samples) if x['timestamp_ns'] <= begin), None)
            after = next((x for x in samples if x['timestamp_ns'] >= end), None)
            delta = {key: after[key] - before[key] if before and after and before.get(key) is not None and after.get(key) is not None else None for key in FIELDS}
            original = summary['phase_windows'][phase]
            assert len(selected) == original['sample_count'] and delta == original['bracket_delta_bytes']
            nulls = {key: sum(x.get(key) is None for x in selected) for key in FIELDS}
            assert nulls == original['null_sample_counts']
            phases[phase] = dict(sample_count=len(selected), null_sample_counts=nulls,
                                 sampled_peaks_bytes={key: max((x[key] for x in selected if x.get(key) is not None), default=None) for key in FIELDS},
                                 neighboring_sample_delta_bytes=delta, bracket_ages_ns=original['bracket_ages_ns'],
                                 exact_boundary_values=False)
        ready = markers['ready_before_first']
        before_prefill = markers['generation_prefill_begin']
        assert not any(ready <= x['timestamp_ns'] <= before_prefill for x in samples)
        assert summary['ready_baseline']['unknown'] and summary['ready_baseline']['sample'] is None
        memory[arm] = dict(source=identity(folder / 'memory.json'), requested_interval_seconds=data['requested_interval_s'],
                            all_samples=len(data['samples']), running_samples=len(samples), sampled_peaks_bytes=peaks,
                            actual_running_sample_gaps_ms=gaps, sample_cost_ms=cost,
                            running_null_sample_counts={key: sum(x.get(key) is None for x in samples) for key in FIELDS},
                            ready_baseline=None, phases=phases)
    peak_delta = {key: memory['after_MTP']['sampled_peaks_bytes'][key] - memory['before_MTP']['sampled_peaks_bytes'][key] for key in FIELDS}
    report = dict(status='FROZEN_HOST_ONLY_REVIEW', scope='Existing3 arms x3 unmonitored timing plus1 independently sampled-memory process each; no model/build/GPU execution.',
                  verification=dict(timing_processes=9, independent_memory_processes=3, all_exit_zero=True,
                     all_stdout_matches_retained_raw=True, all_timing_P_plus_D_equals_session=True,
                     per_process_ratios_and_summary_statistics_match=True,
                     each_arm_timing3_and_memory1_IDs_work_decisions_equal=True,
                     Hyle_F32_contract_and64IDs_work_decisions_equal=True,
                     memory_peaks_gaps_cost_phases_deltas_recomputed=True,
                     ready_sample_missing_in_all3_memory_runs=True),
                  sources=source_ids, methods=dict(prefill_TPS='154 / per-process full prefill_seconds', decode_TPS='63 / per-process full decode_seconds',
                     output_TPS='64 / per-process session_seconds', cold_output_TPS='64 / per-process startup_to_endpoint_seconds',
                     endpoints='All9 P+D=session verified. Consumer full host endpoints, not submit-only timers or received stderr; median/min/max after per-process ratios.',
                     loading='Hyle exact weights_load_seconds stderr; native original stdout weights_load_seconds.',
                     round_comparison='Recursive removal only of seconds and *_seconds; every other nested decision/work field retained.'),
                  timing=timing, baseline_to_current=changes, work=work,
                  comparison=dict(Hyle_F32_score_public_contract_equal=True, Hyle64IDs_equal=True, Hyle_work_equal=True, Hyle_round_decisions_equal=True,
                     native_first_ID_difference=difference, native_same_token_or_all_math_comparison=False),
                  capture_cold=captures, independent_memory=memory, sampled_current_minus_baseline_peaks_bytes=peak_delta,
                  selected_per_process_values=per_process,
                  conclusion='Current Hyle observed higher prefill and session-output medians with nonoverlapping3-sample ranges. Decode median is slightly higher but ranges overlap; cold startup ranges also overlap. This is a limited window, not significance or a universal gain.',
                  limits=['Hyle before/current have identical64 IDs, exported work and decisions in this window; this is not full hidden/state quality equivalence or a general guarantee.',
                          'Native differs from index18 and verifies66 rows vs Hyle68; its different arithmetic and actual workload prevent a same-token cross-engine speed/quality verdict.',
                          'Only3 timing processes per arm, normal nonexclusive desktop background, no fixed clocks; do not pool prior windows or claim statistical significance.',
                          'Capture record/reuse are range counts; inclusive cold_batch is not function/capture self-time. No new profiler/causal attribution.',
                          'Memory is1 separate observed process per arm. Sampled peaks are lower bounds, not physical allocation totals or exact provider workspace attribution; CPU commit/WS/GPU shared cannot be summed.',
                          '10ms requested cadence differs from actual gaps. Ready baseline has no sample in all3 arms and remains null. Phase boundaries are parent receipt times; bracketing deltas can include later work/teardown, particularly native decode-end large negative delta.',
                          'Global dedicated/shared peaks are independent; simultaneous total is recomputed from each available same-time pair. Preserve unavailable early GPU counters as null.'],
                  reruns=0, builds=0, GPU_runs=0)
    output = S / 'review/actual-window-review.json'
    output.write_text(json.dumps(report, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')
    print(json.dumps(dict(report=identity(output), table={arm: {key: values[key] for key in ('prefill_tokens_per_second', 'full_decode_tokens_per_second', 'session_output_tokens_per_second', 'cold_output_tokens_per_second')} for arm, values in timing.items()},
                          current_vs_baseline_percent={key: changes[key] for key in ('prefill_tokens_per_second', 'full_decode_tokens_per_second', 'session_output_tokens_per_second')},
                          sampled_memory_peak_delta_bytes=peak_delta)))


if __name__ == '__main__':
    main()
