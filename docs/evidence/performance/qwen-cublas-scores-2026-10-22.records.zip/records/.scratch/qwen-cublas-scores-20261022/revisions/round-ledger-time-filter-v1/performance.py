"""AD F32-score provider window. Only the explicit run action starts models.

Reuse the frozen AC/W/V endpoints, capture ledger and external memory sampler.
All new output stays in AD. Natural outputs/work may differ between providers;
each arm's three fixed64 timing repeats must agree with itself.
"""
from pathlib import Path
import argparse
import importlib.util
import json
import sys

sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
ROOT = S.parents[1]
AC = ROOT / '.scratch/qwen-f32-scores-20261022'
V = ROOT / '.scratch/qwen-mtp-window-20261022'
spec = importlib.util.spec_from_file_location('ad_retained_AC_performance', AC / 'performance.py')
ac = importlib.util.module_from_spec(spec)
spec.loader.exec_module(ac)
retained, base, ARMS = ac.retained, ac.base, ac.ARMS
ac.S = retained.S = S
retained.EXPECTED_READY = {
    'before_MTP': AC / 'qwen-ready-attempt1.json',
    'after_MTP': S / 'qwen-ready-attempt1.json',
    'peer_MTP': V / 'peer-ready-attempt1.json',
}
POLICIES = {
    'before_MTP': 'AC Hyle BF16 inputs/weights, F32 scores via its retained GGML route',
    'after_MTP': 'AD Hyle same F32-score public contract; new cuBLAS implementation and default route policy v2',
    'peer_MTP': 'Retained V native F32 scores; other native arithmetic/state differences remain',
}


def compare_work(runs):
    result = ac.compare_work(runs)
    for arm, observation in result['within_arm'].items():
        selected = [r['observation'] for r in runs if r['arm'] == arm]
        if not selected:
            continue
        rounds = selected[0]['raw'].get('rounds')
        stable = all(x['raw'].get('rounds') == rounds for x in selected)
        observation['identical_round_ledgers'] = stable
        observation['valid_fixed_work_repeats'] &= stable
    stable = all(x.get('valid_fixed_work_repeats', False) for x in result['within_arm'].values())
    result['status'] = 'stable_observed_within_arm_work' if stable else 'pending_or_within_arm_variability'
    result['note'] = ('Both Hyle arms expose BF16-input/F32-output scores. Different reductions/providers may change '
                      'natural IDs, acceptance and actual work. Cross-arm equality and quality are not assumed; '
                      'require actual64 IDs, work and round ledgers to agree within each timing arm.')
    return result


def plan(config_path, mode, output):
    result = ac.original_plan(config_path, mode, output)
    result.update(
        score_policies=POLICIES,
        Hyle_score_dtype_contract_equal=True,
        same_all_math_or_actual_IDs_assumed=False,
        expected_within_arm_processes=3 if mode == 'timing' else 1,
        within_arm_fixed_work_policy='Require actual64 IDs, work and round ledgers stable within each arm; preserve and flag any variability/EOS-short run.',
        route_selection='Candidate admission/default policy is changed; use actual selected CompileReport/provider evidence before attributing a measurement specifically to cuBLAS.',
        contract='Original V P154/64 natural MTP, C1024/N1R1, prefixoff/replayauto/direct. Both Hyle arms have F32 score outputs. Report actual IDs, EOS, proposal/accept/verify work descriptively across arms; do not infer same-token speed or quality from public dtype equality.',
        script=base.identity(Path(__file__)),
        reused_AC_script=base.identity(AC / 'performance.py'),
        reused_W_script=base.identity(ac.W / 'performance.py'),
    )
    return result


def analyze(output):
    # Call the retained W collector directly: it supplies full endpoint and
    # record/reuse/cold ledgers without AC's superseded BF16-score wording.
    result = ac.original_analyze(output)
    result.pop('carrier_before_after_regression', None)
    runs = base.read(output / 'runs.json')
    consistency = compare_work(runs)
    expected = 3 if result['mode'] == 'timing' else 1
    result['score_provider_observation'] = consistency
    result['score_policies'] = POLICIES
    result['Hyle_score_dtype_contract_equal'] = True
    result['same_all_math_or_actual_IDs_assumed'] = False
    result['fixed_work_window_valid'] = (
        len(runs) == len(ARMS) * expected
        and all(x.get('valid_fixed_work_repeats', False) and x['processes'] == expected
                for x in consistency['within_arm'].values()))
    result['status'] = ('complete_stable_within_arm_work' if result['fixed_work_window_valid']
                        else 'complete_with_work_or_output_variability_not_validated')
    result['same_token_cross_arm_speed_claim'] = False
    result['quality_threshold'] = None
    result['limits'] = [x for x in result['limits'] if not x.startswith('Original V peer MTP already differs')]
    result['limits'] += [
        'Both Hyle arms retain the same F32-score public contract; different provider reductions and native arithmetic may change near-tie IDs, acceptance and workload. Cross-arm comparisons are descriptive unless actual IDs/work are separately shown equal.',
        'Default selection must be confirmed from the actual image; availability of the cuBLAS candidate alone does not establish it was selected.',
        'Three timing processes per arm and one separate sampled-memory process do not establish significance, repeatable memory peaks or physical allocation attribution. Preserve actual sample gaps, phase sample counts and null ready baselines.',
        'This is a new window: do not pool AC/W/V timing or infer throughput gains from capture range counts or inclusive cold_batch buckets.',
    ]
    base.save(output / 'summary.json', result)
    return result


retained.plan = plan
retained.compare_before_after = compare_work
retained.analyze = analyze


def self_check():
    def row(arm, token=0, calls=35, rounds=None):
        return {'arm': arm, 'observation': {'generated_ids': [token] + list(range(1, 64)),
                'work': {'actual_graph_calls': calls}, 'raw': {'rounds': rounds or []}}}
    rows = [row(arm, index, 35 + index) for index, arm in enumerate(ARMS)]
    assert all(x['valid_fixed_work_repeats'] for x in compare_work(rows)['within_arm'].values())
    for changed in (row(ARMS[0], 99), row(ARMS[0], calls=99), row(ARMS[0], rounds=[{'accepted': 2}])):
        assert not compare_work(rows + [changed])['within_arm'][ARMS[0]]['valid_fixed_work_repeats']
    assert retained.owned_output(S / 'performance/timing').is_relative_to(S)
    try:
        retained.owned_output(AC / 'performance/forbidden')
    except ValueError:
        pass
    else:
        raise AssertionError('frozen AC output accepted')
    return dict(status='pure_host_checks_pass', checks=6, builds=0, GPU_runs=0,
                model_runs=0, script=base.identity(Path(__file__)))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action', choices=('plan', 'run', 'analyze', 'self-check'))
    parser.add_argument('--config', type=Path, default=S / 'arms.json')
    parser.add_argument('--mode', choices=('timing', 'memory'), default='timing')
    parser.add_argument('--output', type=Path)
    args = parser.parse_args()
    if args.action == 'self-check':
        result = self_check()
        base.save(S / 'review/performance-host-check.json', result)
        print(json.dumps(result))
        return
    output = retained.owned_output(args.output or S / 'performance' / args.mode)
    if args.action == 'plan':
        result = plan(args.config, args.mode, output)
        target = S / (args.mode + '-plan.json')
        base.save(target, result)
        print(json.dumps(dict(processes=len(result['commands']), plan=str(target), model_runs=0)))
    else:
        result = retained.run(args.config, args.mode, output) if args.action == 'run' else analyze(output)
        print(json.dumps(dict(summary=str(output / 'summary.json'), processes=result['processes'],
                              mode=result['mode'], status=result['status'],
                              fixed_work_window_valid=result['fixed_work_window_valid'])))


if __name__ == '__main__':
    main()
