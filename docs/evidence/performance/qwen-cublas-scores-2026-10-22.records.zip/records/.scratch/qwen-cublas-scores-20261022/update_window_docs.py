"""Append the observed AD window once; no model, build or inference execution."""
from pathlib import Path
import json

C = Path(__file__).resolve().parent
R = C.parents[1]
read = lambda p: json.loads(p.read_text(encoding='utf-8-sig'))
t = read(C / 'performance/timing/summary.json')
m = read(C / 'performance/memory/summary.json')
assert t['fixed_work_window_valid'] and m['fixed_work_window_valid']
assert t['between_arm_first_process_outputs']['before_MTP__after_MTP']['equal']
arms = ['before_MTP', 'after_MTP', 'peer_MTP']
groups = [t['groups'][a] for a in arms]
mem = [m['groups'][a] for a in arms]

def med(key, digits=2):
    return [f"{g[key]['median']:.{digits}f}" for g in groups]

def peak(key):
    return [f"{g['sampled_peaks'][key] / 2**30:.3f}" for g in mem]

rows = [
    ('Prefill，tok/s', med('prefill_tokens_per_second')),
    ('完整decode，tok/s', med('full_decode_tokens_per_second')),
    ('decode范围，tok/s', [f"{g['full_decode_tokens_per_second']['min']:.2f}～{g['full_decode_tokens_per_second']['max']:.2f}" for g in groups]),
    ('综合64输出／session wall，tok/s', med('session_output_tokens_per_second')),
    ('权重加载中位，s（非冷盘）', med('weights_load_seconds', 3)),
    ('启动至ready中位，s', med('startup_to_ready_seconds', 3)),
    ('含启动至最后token中位，s', med('startup_to_endpoint_seconds', 3)),
    ('GPU dedicated观测峰，GiB', peak('sampled_peak_gpu_dedicated_bytes')),
    ('GPU shared独立观测峰，GiB', peak('sampled_peak_gpu_shared_bytes')),
    ('GPU同一采样点总量峰，GiB', peak('sampled_peak_gpu_total_bytes')),
    ('CPU working set观测峰，GiB', peak('sampled_max_working_set_bytes')),
    ('CPU private commit观测峰，GiB', peak('sampled_max_private_commit_bytes')),
]
table = '\n'.join('| ' + ' | '.join([label] + values) + ' |' for label, values in rows)
phase = []
for g in mem:
    windows = g['phase_windows']
    phase.append('→'.join(f"{windows[k]['values']['gpu_dedicated_bytes']['max'] / 2**30:.3f}" for k in ('generation_prefill', 'generation_decode')))
gaps = '／'.join(f"{g['actual_sample_gaps_ms']['median']:.2f}" for g in mem)
text = '''

### 最新完整窗口：F32末分数的cuBLASLt承载，2026-10-22

Windows／RTX4070；原335张量BF16权重、P154／64自然输出、C1024／N1／R1、prefixoff／replayauto。两版Hyle均为BF16输入／权重、F32末分数，中间计算政策相同；前镜像为AC的GGML CUDA承载，当前为AD的cuBLASLt默认候选。消费者main／MTP helper源码与对象沿用，未新增引擎Provider分支、精度开关或公共API。

每臂3个新进程交错测速，另各1个新进程独立旁采内存；未预热、trace、padding、强制token或接受。P以154／完整prefill wall、D以63／首token之后的完整decode wall、综合以64／session wall逐进程计算后取中位。不是多轮／多人吞吐窗口。

| 指标 | 修改前Hyle MTP（GGML） | 当前Hyle MTP（cuBLASLt） | 原llama.cpp MTP |
| --- | ---: | ---: | ---: |
''' + table + '''

本窗Hyle前后64ID、34轮草拟／29次接受、35次Graph、222target／216draft实际行和18record／50reuse相同。prefill中位＋15.48%、综合＋1.82%，各自样本范围不重叠；decode仅＋0.33%、范围重叠，仍按近持平处理，不宣称解决decode差距或普遍收益。启动至末token中位近持平，ready也无稳定收益。当前dedicated及同点GPU总量峰少113,246,208B（108MiB）；每臂只有一次独立旁采，不将其认定为精确分配节省或归因某个buffer。

参考自身3进程输出／工作量稳定，相对两版Hyle仍从零基index18分歧；其220target／216draft行、33次生成proposal／30次接受与双Context边界也不同。原BF16小张量提升、conv／GDN状态等数学差别保留。参考速度仅描述实际自然续文，不签同token跨引擎胜负或完整质量。

按表顺序，实际采样gap中位为''' + gaps + '''ms（请求10ms），全部ready基线未知；prefill→decode阶段dedicated观测峰为''' + '／'.join(phase) + '''GiB。阶段样本、边界邻样和CPU变化保留在证据中。峰是采样下界；邻样delta可能含后续／退出，不当精确释放。GPU总量使用同一采样点，CPU驻留、commit及GPU shared分别报告，不相加冒充物理RAM。

11项相关测试通过，含非方阵权重方向、F32低于BF16舍入间距的分数、旧MatMul／广播与真实退休重放、默认Context自然选择。5个CLI诊断覆盖普通固定输入、单MTP、双会话lag1和N1三次重建。普通4份hidden及993280个F32分数前后逐字节相同；98份raw的64行有限且各自argmax匹配，选定原权重FP64点积符合条件F32归约界。draft hidden未导出，未签独立完整draft oracle、跨批宽或全模型质量。

只增量编译4个host翻译单元，195个Qwen链接输入重用193个；SDK／NVCC／全量配置均0次。Provider首编把optional误当指针而失败，修正后第二次成功；其余3个TU首编成功，两次链接成功。分析脚本曾把参考逐轮耗时当决策比较，已仅剔除时间字段、保留所有行数／ID／接受／位置并从原9份测速重算；原失败／false记录保留，无模型重跑。合计17个模型进程及1个相关测试进程。

下一步核MTP实际capture首次失效step／port及准备成本，再决定是否优化；不根据额外range数直接改缓存。其它系统／量化、完整质量、图片和架构目标仍未完成。[完整源码、命令、数值检查与本窗原始结果](../evidence/performance/qwen-cublas-scores-2026-10-22.json)。
'''
p = R / 'docs/developer/current-work.md'
assert '### 最新完整窗口：F32末分数的cuBLASLt承载' not in p.read_text(encoding='utf-8-sig')
with p.open('a', encoding='utf-8', newline='') as f:
    f.write(text)
print('Appended observed AD table and limits.')
