"""Finite score-policy checks; all commands are diagnostic, GPU is serial."""
from pathlib import Path
import argparse,importlib.util,json,os,sys
sys.dont_write_bytecode=True
C=Path(__file__).resolve().parent;R=C.parents[1];A=R/'.scratch/qwen-f32-scores-20261022';F=R/'.scratch/qwen-mtp-batch-20261022/fixtures'
s=importlib.util.spec_from_file_location('score_build',C/'build.py');h=importlib.util.module_from_spec(s);s.loader.exec_module(h)
b,c=h.b,h.c

def run(name,args,before=False):
 ready_path=(A if before else C)/'qwen-ready-attempt1.json';ready=c.read(ready_path)
 assert h.same(ready['image'])and h.same(ready['runtime_environment'])
 if before:
  snapshot=b.identity(A/'current/tools/qwen35_text/main.cc')
  assert(snapshot['bytes'],snapshot['sha256'])==(ready['source']['bytes'],ready['source']['sha256'])
 else:assert h.same(ready['source'])and h.same(ready['main'])
 out=C/'cases1'/name;out.mkdir(parents=True,exist_ok=False)
 command=[ready['image']['path'],*args,'--trace',str(out/'trace'),'--trace-level','decisions']
 env=os.environ.copy();env['PATH']=c.read(ready['runtime_environment']['path'])['PATH']
 c.save(out/'plan.json',dict(command=command,ready=ready,ready_record=b.identity(ready_path),diagnostic=True,performance_evidence=False,
  score_policy='bf16_inputs_f32_output',score_route='previous_ggml_native_program'if before else'new_cublas_default_candidate'))
 c.execute('run',command,env,out)
 c.save(out/'parsed.json',json.loads((out/'run.stdout.log').read_text().splitlines()[-1]))
 print('CASE_OK',name,flush=True)

def ordinary():
 args=['--inputs',str(A/'inputs/text'),'--capacity','64','--steps','4','--decode-ids',str(A/'inputs/fixed-decode.ids')]
 run('ordinary-before',args,True);run('ordinary-after',args)

def mtp():
 base=['--inputs',str(A/'inputs/mtp'),'--capacity','64','--mtp','on']
 run('mtp-single',base+['--steps','4'])
 run('mtp-warm-r2',base+['--session-schedules',str(F/'warm-sessions.txt'),'--max-sessions','2','--active-sequences','2','--prefix-cache','off'])
 run('mtp-pressure-r1',base+['--session-schedules',str(F/'sessions.txt'),'--max-sessions','1','--active-sequences','1','--prefix-cache','off'])

if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('mode',choices=['ordinary','mtp']);mode=p.parse_args().mode
 ordinary()if mode=='ordinary'else mtp()
