"""Explicit host-only incremental builds; importing this module runs no build.

Compile cublas/policy/test/route_test once, then link qwen/tests. The retained
AC consumer object and all other current products stay in the original cache.
Only the root runner executes these build actions or the resulting images.
"""
from pathlib import Path
import argparse
import importlib.util
import os
import sys

sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
R = S.parents[1]
AC = R / '.scratch/qwen-f32-scores-20261022'
OLD = R / '.scratch/architecture-refactor-2026-10-18'
spec = importlib.util.spec_from_file_location('ad_cached_build_helpers', R / '.scratch/qwen-mtp-round-20261022/build.py')
h = importlib.util.module_from_spec(spec)
spec.loader.exec_module(h)
b, c = h.b, h.c
CUBLAS_RECIPE = OLD / 'ct-bf16-block128-reference/cuda-batched-matmul/checks/attempt1/cublas-identity.json'
TEST_RECIPE = OLD / 'ct-bf16-block128-reference/cuda-batched-matmul/checks/general-broadcast/test-identity.json'
POLICY_RECIPE = OLD / 'mlx-weight-orientation-2026-10-21/cpu-cuda/checks/attempt1/default-policy/identity.json'
RECIPES = {'cublas': CUBLAS_RECIPE, 'policy': POLICY_RECIPE,
           'test': TEST_RECIPE, 'route_test': TEST_RECIPE}
SOURCES = {'cublas': R / 'src/compute_provider_cublas/cublas_provider.cc',
           'policy': R / 'src/compute_route_cuda/default_policy.cc',
           'test': R / 'tests/compute_provider_cublas/cublas_provider_test.cc',
           'route_test': R / 'tests/compute_route_cuda/linear_test.cc'}
GTEST = [R / '.scratch/build-compute-v2-dev/lib/gtest_main.lib',
         R / '.scratch/build-compute-v2-dev/lib/gtest.lib']


def same(record):
    return b.identity(record['path']) == record


def compile_command(tag, attempt):
    out = S / f'compile{attempt}' / tag
    command = b.host_command(c.read(RECIPES[tag])['command'], SOURCES[tag], tag, out)
    assert all(x in command for x in ('/W4', '/WX', '/O2', '/MD'))
    return command


def compile_owner(tag, attempt):
    source = SOURCES[tag]
    command = compile_command(tag, attempt)
    frozen = b.identity(source)
    out = S / f'compile{attempt}' / tag
    out.mkdir(parents=True, exist_ok=False)
    (out / 'tmp').mkdir()
    snapshot = out / 'source' / source.relative_to(R)
    snapshot.parent.mkdir(parents=True)
    snapshot.write_bytes(source.read_bytes())
    c.save(out / 'plan.json', dict(command=command, source=frozen,
           recipe=b.identity(RECIPES[tag]), SDK_builds=0, NVCC_builds=0))
    env, _ = b.environment(command, [], out)
    c.execute('compile', command, env, out)
    data = c.read(out / f'{tag}-deps.json')['Data']
    dependencies = list(dict.fromkeys([data['Source'], *data['Includes']]))
    assert same(frozen), 'source changed during compile'
    c.save(out / 'identity.json', dict(source=frozen,
           object=b.identity(out / f'{tag}.obj'), command=command,
           recipe=b.identity(RECIPES[tag]),
           dependencies=[b.identity(x) for x in dependencies],
           SDK_builds=0, NVCC_builds=0))
    print('COMPILED', tag, flush=True)


def link(mode, attempt, link_attempt, cublas_attempt=None):
    base_path = AC / 'qwen-link1/link-plan.json'
    base = c.read(base_path)
    main_record_path = Path(base['compiled_record']['path'])
    main_record = c.read(main_record_path)
    assert same(base['compiled_record'])
    # Source/dependencies of the retained consumer must still be its real ones.
    assert all(same(x) for x in (main_record['source'], main_record['object'],
                                *main_record['dependencies']))
    assert len(base['inputs']) == 195
    assert all(same(x) for x in base['inputs'])
    tags = ('cublas', 'policy') + (('test', 'route_test') if mode == 'tests' else ())
    records = {}
    record_ids = []
    for tag in tags:
        owner_attempt = cublas_attempt if tag == 'cublas' and cublas_attempt is not None else attempt
        path = S / f'compile{owner_attempt}' / tag / 'identity.json'
        record = c.read(path)
        assert all(same(x) for x in (record['source'], record['object'], *record['dependencies']))
        records[tag] = record
        record_ids.append(b.identity(path))
    replacements = {c.key(c.read(RECIPES[tag])['object']['path']): records[tag]['object']
                    for tag in ('cublas', 'policy')}
    for old in replacements:
        assert sum(c.key(x['path']) == old for x in base['inputs']) == 1
    main_key = c.key(main_record['object']['path'])
    assert sum(c.key(x['path']) == main_key for x in base['inputs']) == 1
    additions = ([records[tag]['object'] for tag in ('test', 'route_test')]
                 + [b.identity(x) for x in GTEST]) if mode == 'tests' else []
    inputs = [replacements.get(c.key(x['path']), x) for x in base['inputs']
              if mode != 'tests' or c.key(x['path']) != main_key] + additions
    command = [replacements.get(c.key(x), {}).get('path', x)
               for x in base['command']
               if not x.upper().startswith(('/OUT:', '/MAP:', '/IMPLIB:', '/PDB:'))
               and (mode != 'tests' or c.key(x) != main_key)]
    command += [x['path'] for x in additions]
    assert len(inputs) == (198 if mode == 'tests' else 195)
    assert len({c.key(x['path']) for x in inputs}) == len(inputs)
    out = S / f'{mode}-link{link_attempt}'
    out.mkdir(exist_ok=False)
    (out / 'tmp').mkdir()
    image = out / f'{mode}.exe'
    command += ['/OUT:' + str(image), '/MAP:' + str(image.with_suffix('.map')),
                '/IMPLIB:' + str(image.with_suffix('.lib'))]
    c.save(out / 'link-plan.json', dict(command=command, inputs=inputs,
           base=b.identity(base_path), compiled_records=record_ids,
           consumer_compiled_record=b.identity(main_record_path),
           consumer_recompiled=False, replaced_product_inputs=2,
           SDK_builds=0, NVCC_builds=0))
    env, _ = b.environment(command, [x['path'] for x in inputs], out)
    c.execute('link', command, env, out)
    runtime_path = AC / 'qwen-link1/runtime-environment.json'
    runtime = c.read(runtime_path)
    # Stage only the already selected private DLL by hardlink; preserve cache.
    for item in runtime['staged_dlls']:
        assert same(item)
        source = Path(item['path'])
        os.link(source, out / source.name)
    runtime['previous_environment'] = b.identity(runtime_path)
    runtime['PATH'] = env['PATH']
    runtime['staged_dlls'] = [b.identity(x) for x in out.glob('*.dll')]
    if 'CPU_DLL' in runtime:
        name = Path(runtime['CPU_DLL']['source']['path']).name
        runtime['CPU_DLL']['destination'] = b.identity(out / name)
    c.save(out / 'runtime-environment.json', runtime)
    ready = dict(image=b.identity(image), source=main_record['source'],
                 main=main_record['source'], consumer_compiled_record=b.identity(main_record_path),
                 changed_sources=[records[tag]['source'] for tag in tags],
                 compiled_records=record_ids, consumer_recompiled=False,
                 link_plan=b.identity(out / 'link-plan.json'),
                 runtime_environment=b.identity(out / 'runtime-environment.json'),
                 SDK_builds=0, NVCC_builds=0)
    c.save(S / f'{mode}-ready-attempt{link_attempt}.json', ready)
    print('READY', mode, flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('tag', choices=(*SOURCES, 'qwen', 'tests'))
    parser.add_argument('--attempt', type=int, default=1)
    parser.add_argument('--link', action='store_true')
    parser.add_argument('--link-attempt', type=int)
    parser.add_argument('--cublas-attempt', type=int)
    args = parser.parse_args()
    if args.attempt <= 0 or (args.link_attempt is not None and args.link_attempt <= 0):
        parser.error('attempt numbers must be positive')
    if args.link:
        if args.tag not in ('qwen', 'tests'):
            parser.error('--link requires qwen or tests')
        link(args.tag, args.attempt, args.link_attempt or args.attempt, args.cublas_attempt)
    elif args.tag in SOURCES:
        compile_owner(args.tag, args.attempt)
    else:
        parser.error('qwen/tests require --link')
