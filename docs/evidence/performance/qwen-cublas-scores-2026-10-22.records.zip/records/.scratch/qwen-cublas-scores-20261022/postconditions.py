"""Read-only AD publication/cleanup checks; no build, test or inference run."""
from pathlib import Path
import hashlib
import json

C = Path(__file__).resolve().parent
R = C.parents[1]

def read(p):
    return json.loads(Path(p).read_text(encoding='utf-8-sig'))

def identity(p):
    p = Path(p)
    h = hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda: f.read(8 << 20), b''):
            h.update(b)
    return dict(path=str(p.resolve()), bytes=p.stat().st_size, sha256=h.hexdigest())

pub = read(C / 'published.json')
plan = read(C / 'cleanup-plan.json')
result = read(C / 'cleanup-result.json')
assert identity(pub['manifest']['path']) == pub['manifest']
assert all(identity(e['path']) == e for e in pub['archives'])
freeze = read(C / 'product-freeze.json')
assert all(identity(e['source']['path']) == e['source'] and
           identity(e['snapshot']['path']) == e['snapshot'] for e in freeze['files'])
assert len(plan['targets']) == result['removed_files']
assert plan['logical_bytes'] == result['removed_logical_bytes']
assert all(not Path(e['path']).exists() for e in plan['targets'])
assert all(identity(e['path']) == e for e in plan['keep_images'])
assert identity(plan['script']['path']) == plan['script']
assert identity(plan['script_copy']['path']) == plan['script_copy']
assert (R / 'test.ps1').read_bytes() == (C / 'cleanup_script.ps1').read_bytes()
assert (C / 'cleanup-result.json').read_bytes() == (R / 'docs/evidence/performance/qwen-cublas-scores-2026-10-22.cleanup.json').read_bytes()

links = {}
for name, expected in [('qwen', 195), ('tests', 198)]:
    ready = read(C / (name + '-ready-attempt1.json'))
    link = read(ready['link_plan']['path'])
    assert len(link['inputs']) == expected
    assert all(Path(e['path']).is_file() and Path(e['path']).stat().st_size == e['bytes'] for e in link['inputs'])
    for e in ready['compiled_records']:
        assert identity(e['path']) == e
        compiled = read(e['path'])
        assert identity(compiled['object']['path']) == compiled['object']
    links[name] = expected
ready = read(C / 'qwen-ready-attempt1.json')
assert identity(ready['image']['path']) == ready['image']
assert identity(ready['consumer_compiled_record']['path']) == ready['consumer_compiled_record']
assert not (R / '.scratch/qwen-f32-scores-20261022/qwen-link1/qwen.exe').exists()
assert not (C / 'tests-link1/tests.exe').exists()
for mode in ['timing', 'memory']:
    assert read(C / 'performance' / mode / 'summary.json')['fixed_work_window_valid']

report = dict(
    status='PASS', published=pub, product_freeze_unchanged=True,
    product_files=len(freeze['files']), removed_files=len(plan['targets']),
    removed_logical_bytes=plan['logical_bytes'], current_and_peer_images=plan['keep_images'],
    all_link_inputs_preserved_by_path_and_size=links, reused_Qwen_inputs=193,
    changed_TU_objects_SHA256_verified=True, consumer_compiled_record_preserved=True,
    source_docs_script_archive_current_peer_SHA256_verified=True,
    root_script_completed_do_not_rerun=True,
    actual_model_processes=17, related_unit_processes=1,
    scope='Postcleanup read-only verification. Reuses actual compile/link/native results; no extra test/model run.')
(C / 'postconditions.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
print(json.dumps(dict(status='PASS', product_files=len(freeze['files']),
                     removed_files=len(plan['targets']), removed_logical_GiB=plan['logical_bytes'] / 2**30,
                     link_inputs_preserved=links, current_image=ready['image']['sha256']), indent=2))
