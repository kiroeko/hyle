"""Incremental scratch consumer and its previously unused IO service closure."""
import concurrent.futures
import importlib.util
from pathlib import Path
import sys
sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
ROOT = S.parents[2]
spec = importlib.util.spec_from_file_location('pinned_loader_build_helpers', S.parent/'projected-bind-cold-index/build.py')
h = importlib.util.module_from_spec(spec)
spec.loader.exec_module(h)
b, c = h.b, h.c
out = S/'checks'
out.mkdir(exist_ok=True)
(out/'tmp').mkdir(exist_ok=True)
base_path = S.parent/'gdn-direct-state-output/checks/native1/qwen-link-plan.json'
base = c.read(base_path)
main_recipe = c.read(S.parent/'qwen-current-retest/checks/main1/qwen-main-identity.json')
sources = [('qwen-main', S/'candidate/main.cc', [])]
sources += [('stream-'+name, ROOT/'src/compute_stream'/(name+'.cc'), ['/DHYLE_COMPUTE_STREAM_BUILD'])
    for name in ('file_stream', 'stream_sources')]
sources += [('cuda-stream', ROOT/'src/compute_stream_cuda/file_stream.cc', ['/DHYLE_COMPUTE_STREAM_CUDA_BUILD'])]
# No certified old source/dependency closure exists for the IO archive. Refresh
# these twelve small ordinary CXX owners, never the cached SDK/backend archive.
sources += [('io-'+name, ROOT/'src/io_core'/(name+'.cc'), ['/DHYLE_IO_CORE_BUILD'])
    for name in ('proactor', 'endpoint', 'operation', 'io_uring', 'io_context',
                 'tcp', 'udp', 'file', 'file_region', 'local', 'signal', 'dns')]
frozen = [b.identity(p) for p in (S/'source-freeze.json', S/'independent-review.json',
    S/'candidate/main.cc', ROOT/'tools/qwen35_text/main.cc')]
rows = []
for tag, source, definitions in sources:
    command = b.host_command(main_recipe['command'], source, tag, out)
    if tag.startswith('io-'):
        command = [arg for arg in command if arg.upper()!='/DNOMINMAX']
    command[1:1] = ['/DHYLE_IO_HAS_COROUTINE_TRANSPORT=1', *definitions]
    rows.append(dict(tag=tag, source=b.identity(source), command=command, object=str(out/(tag+'.obj'))))
frozen += [row['source'] for row in rows]
plan = dict(base_path=str(base_path), compile=rows, frozen=frozen, host_TUs=len(rows),
    native_TUs=0, SDK_rebuild=False, product_consumer_changed=False,
    candidate_only=True, unchanged_device_allocations=320, staging_bytes=16777216,
    io_archive_reused=False)
c.save(out/'plan.json', plan)
for row in base['inputs']:
    assert b.same(row), row['path']
env, runtime = b.environment(base['command'], [row['path'] for row in base['inputs']], out)
c.save(out/'runtime-environment.json', dict(runtime=runtime, PATH=env['PATH']))

def check():
    for row in frozen:
        assert b.same(row), row['path']

def compile_one(row):
    check()
    receipt_path = out/(row['tag']+'-identity.json')
    if receipt_path.exists():
        old = c.read(receipt_path)
        if old['command']==row['command'] and b.same(old['object']) and all(b.same(d) for d in old['dependencies']):
            print('REUSE', row['tag'], flush=True)
            return row['tag'], old
    result_path = out/(row['tag']+'-compile.result.json')
    if result_path.exists():
        import shutil
        saved = out/'first-attempt'
        saved.mkdir(exist_ok=True)
        for path in out.glob(row['tag']+'-compile.*'):
            target = saved/path.name
            if not target.exists():
                shutil.copy2(path, target)
    c.execute(row['tag']+'-compile', row['command'], env, out)
    check()
    data = c.read(out/(row['tag']+'-deps.json'))['Data']
    result = dict(command=row['command'], source=row['source'], object=b.identity(row['object']),
        dependencies=[b.identity(p) for p in dict.fromkeys([data['Source'], *data['Includes']])])
    c.save(receipt_path, result)
    return row['tag'], result

finished, errors = {}, []
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
    for future in concurrent.futures.as_completed([pool.submit(compile_one, row) for row in rows]):
        try:
            tag, result = future.result()
            finished[tag] = result
        except Exception as error:
            errors.append(repr(error))
c.save(out/'compile-summary.json', dict(passed=not errors, errors=errors))
assert not errors, errors
old_main = c.key(main_recipe['object']['path'])
assert sum(c.key(row['path'])==old_main for row in base['inputs'])==1
main_object = finished['qwen-main']['object']
lookup = {c.key(row['path']): row for row in base['inputs']}
lookup[c.key(main_object['path'])] = main_object
command = [main_object['path'] if c.key(arg)==old_main else arg for arg in base['command']
    if not arg.upper().startswith(('/OUT:', '/MAP:', '/IMPLIB:', '/PDB:'))]
for tag in finished:
    if tag != 'qwen-main':
        obj = finished[tag]['object']
        command.append(obj['path'])
        lookup[c.key(obj['path'])] = obj
command.append('mswsock.lib')
image = out/'qwen.exe'
command += ['/OUT:'+str(image), '/MAP:'+str(image.with_suffix('.map')), '/IMPLIB:'+str(image.with_suffix('.lib'))]
inputs = [lookup[c.key(arg)] for arg in command if Path(arg).is_absolute() and Path(arg).suffix.lower() in ('.obj','.lib')]
for row in inputs:
    assert b.same(row), row['path']
check()
link = dict(command=command, inputs=inputs)
c.save(out/'qwen-link-plan.json', link)
c.execute('qwen-link', command, env, out)
c.save(out/'qwen-image.json', b.identity(image))
plan['links'] = dict(qwen=dict(**link, image=str(image)))
c.save(out/'plan.json', plan)
c.save(out/'summary.json', dict(passed=True, host_TUs=len(rows), native_TUs=0, SDK_rebuild=False,
    candidate_only=True, product_consumer_changed=False, GPU_run=False))
print('PINNED_LOADER_BUILT', len(rows), flush=True)
