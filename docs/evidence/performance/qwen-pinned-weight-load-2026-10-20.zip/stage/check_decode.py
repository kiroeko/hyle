"""One bounded C/B/B/C follow-up for the observed small decode difference."""
import importlib.util
from pathlib import Path
import statistics
import sys
sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('pinned_decode_check_helpers', S.parent/'qwen-current-retest/compare.py')
h = importlib.util.module_from_spec(spec)
spec.loader.exec_module(h)
b, c, r = h.b, h.c, h.r
plan = c.read(S/'performance-prepared/plan.json')
for row in plan['frozen'] + plan['peer_inputs'] + list(plan['images'].values()):
    r.require_same(row)
out = S/'decode-followup'
out.mkdir(exist_ok=False)
(out/'tmp').mkdir()
build, peer = c.read(plan['build_plan']['path']), c.read(r.PEER_PLAN)
env, runtime = r.runtime_environment(build, peer, out)
c.save(out/'inputs.json', dict(plan=b.identity(S/'performance-prepared/plan.json'),
    reason='Nine-process window showed candidate full31 -2.02% and warm -1.58%; check reversed balanced order before adoption.',
    images=plan['images'], order=['current','baseline','baseline','current'], runtime=runtime,
    profiler=False, external_memory_monitor=False, compiles=0, links=0))
runs = []
for index, arm in enumerate(('current','baseline','baseline','current'), 10):
    original = next(row for row in plan['requests'] if row['arm']==arm)
    request = dict(arm=arm, tag=f'{index:02d}-{arm}', command=original['command'])
    process = r.execute(request['tag'], request['command'], env, out)
    observed = r.hyle_result(out, request, plan)
    runs.append(dict(arm=arm, tag=request['tag'], pid=process['pid'], exit=process['exit'], **observed))
    c.save(out/'runs.json', runs)
groups = {arm: {key: dict(samples=[row['metrics'][key] for row in runs if row['arm']==arm],
    median=statistics.median(row['metrics'][key] for row in runs if row['arm']==arm))
    for key in r.COMMON_METRICS} for arm in ('baseline','current')}
c.save(out/'summary.json', dict(executed=True, terminal_zero=len(runs), groups=groups,
    current_over_baseline={key:groups['current'][key]['median']/groups['baseline'][key]['median'] for key in r.COMMON_METRICS},
    same_predictions=all(row['same_baseline_predictions'] for row in runs),
    statistical_significance=False, scope='Separate four-process reversed-order follow-up; preserve original nine-process window, do not replace unfavorable samples.'))
print('PINNED_DECODE_CHECK_COMPLETE', flush=True)
