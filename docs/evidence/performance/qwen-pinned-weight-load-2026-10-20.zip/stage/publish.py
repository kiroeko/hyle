"""Seal the scratch pinned-weight-loader experiment after root's actual runs.

Offline only: never imports build.py or runs a compiler, model, profiler or cleanup.
"""
from datetime import datetime, timedelta, timezone
import hashlib
import json
from pathlib import Path
import statistics
import zipfile

S = Path(__file__).resolve().parent
ROOT = S.parents[2]
PERF = S / 'performance-rotation'


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))


def identity(path):
    path = Path(path).resolve()
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())


def same(row):
    return identity(row['path']) == {key: row[key] for key in ('path', 'bytes', 'sha256')}


def save(path, value):
    Path(path).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


def require(condition, description):
    if not condition:
        raise AssertionError(description)


required = [S/'checks/summary.json', S/'correctness/summary.json',
            PERF/'summary.json', PERF/'runs.json', S/'decode-followup/summary.json',
            S/'decode-followup/runs.json', S/'adoption.json']
require(all(path.is_file() for path in required),
        'Root actual build,64-vector correctness, both completed timing windows and adoption receipt are required.')
freeze = read(S/'source-freeze.json')
review = read(S/'independent-review.json')
plan = read(S/'checks/plan.json')
build = read(S/'checks/summary.json')
model = read(S/'correctness/summary.json')
perf = read(PERF/'summary.json')
runs = read(PERF/'runs.json')
adoption = read(S/'adoption.json')
require(build['passed'] and build['host_TUs'] == 16 and build['native_TUs'] == 0
        and not build['SDK_rebuild'], 'Actual16 CXX/no SDK build must have passed.')
require(model['passed'] and model['observation']['equal_vectors'] == 64
        and model['observation']['all_outputs_finite']
        and model['observation']['same_greedy_ids_as_reference']
        and model['observation']['same_fixed_decode_inputs']
        and model['single_outer_range_32_phases'], 'Complete64-vector exact model evidence is required.')
for key in ('before', 'candidate', 'diff'):
    require(same(freeze[key]), 'Frozen experiment input changed: ' + key)
require(same(review['candidate']), 'Independently reviewed candidate changed.')
product = ROOT/'tools/qwen35_text/main.cc'
product_identity = identity(product)
require(adoption['adopted'] and adoption['compiled_product'], 'Root must have adopted and compiled the actual product consumer.')
for key in ('candidate', 'product', 'product_snapshot', 'before_cmake', 'cmake', 'cmake_snapshot', 'product_check', 'product_image'):
    require(same(adoption[key]), 'Adopted product/source receipt changed: ' + key)
require(product_identity == adoption['product'], 'Current product consumer differs from observed adoption.')
candidate_text = Path(freeze['candidate']['path']).read_text(encoding='utf-8')
expected_product_text = candidate_text.replace(
    '// Scratch loading candidate only. The original tensor math/phase lifecycle below\n// is unchanged. Each original device allocation becomes one retained lease pool;\n',
    '// Each original device allocation becomes one retained lease pool;\n')
require(product.read_text(encoding='utf-8') == expected_product_text,
        'Product executable source differs from measured candidate beyond the exact removed scratch comment.')
product_check = read(S/'product-checks/summary.json')
require(product_check['passed'] and product_check['host_TUs'] == 1 and product_check['native_TUs'] == 0
        and not product_check['SDK_rebuild'] and product_check['fixed128_plus31']
        and product_check['unchanged_predictions'] and product_check['executable_CXX_text_equal_to_measured_candidate'],
        'The freshly compiled actual product consumer smoke must pass.')
for name in ('main-compile', 'qwen-link', 'qwen'):
    result = read(S/'product-checks'/(name+'.result.json'))
    require(result['terminal'] and result['exit'] == 0, 'Adopted product command did not succeed: ' + name)
product_receipt = read(S/'product-checks/main-identity.json')
for row in [product_receipt['source'], product_receipt['object'], *product_receipt['dependencies']]:
    require(same(row), 'Actual product CXX source/dependency changed: ' + row['path'])
for row in plan['frozen']:
    # Root may explicitly adopt the candidate after measuring it; preserve both
    # historical originals and this observed promotion instead of rewriting them.
    if Path(row['path']).resolve() != product:
        require(same(row), 'Build-frozen source changed: ' + row['path'])
image = read(S/'checks/qwen-image.json')
require(same(image) and image == model['observation']['image'], 'Correctness image differs from actual linked candidate.')
actual_compile_results = []
first_compile_results = []
for row in plan['compile']:
    receipt_path = S/'checks'/(row['tag']+'-identity.json')
    receipt = read(receipt_path)
    require(same(receipt['source']) and same(receipt['object']), 'Fresh CXX source/object changed: ' + row['tag'])
    for dependency in receipt['dependencies']:
        require(same(dependency), 'Fresh dependency changed: ' + dependency['path'])
    result = read(S/'checks'/(row['tag']+'-compile.result.json'))
    require(result['terminal'] and result['exit'] == 0, 'Final CXX did not succeed: ' + row['tag'])
    actual_compile_results.append(result)
for path in sorted((S/'checks/first-attempt').glob('*-compile.result.json')):
    result = read(path)
    require(result['terminal'], 'First attempt is not terminal: ' + str(path))
    first_compile_results.append(result)
require(len(actual_compile_results) == 16 and len(first_compile_results) == 12
        and sum(row['exit'] != 0 for row in first_compile_results) == 9,
        'Keep the actual first12 IO attempts, including9 C4005 failures, separate from16 final owners.')
link_result = read(S/'checks/qwen-link.result.json')
require(link_result['terminal'] and link_result['exit'] == 0, 'Candidate link failed.')
for row in model['observation']['vectors']:
    require(row['byte_equal'] and row['actual']['sha256'] == row['reference']['sha256'],
            'A hidden/logits vector differs.')
    require(same(row['actual']) and same(row['reference']), 'Original or candidate vector identity changed.')
require(runs and perf['terminal_zero'] == len(runs), 'Every timing process must have terminal exit0.')
require([row['arm'] for row in runs] == perf['order'], 'Rotation order differs.')
require(not perf.get('statistical_significance', False), 'No statistical significance study was performed.')
prediction_flags = [value for key, value in perf.items()
                    if key.startswith('same_') and 'prediction' in key]
require(prediction_flags and all(prediction_flags), 'Rotation predictions must agree.')
processes = []
for row in runs:
    process = read(PERF/(row['tag']+'.result.json'))
    require(row['exit'] == process['exit'] == 0 and process['terminal'], 'Timing process did not succeed.')
    require(process['pid'] == row['pid'] and process['command'] == row['command'], 'Timing process metadata differs.')
    require(len(row['phase_step_seconds']) == 32, 'Each timing process needs128 prefill+31 decode steps.')
    require(abs(sum(row['phase_step_seconds'][1:]) - row['metrics']['full31_seconds']) < 1.e-12,
            'Full decode metric is not the original31 complete step durations.')
    require(abs(sum(row['phase_step_seconds'][7:]) - row['metrics']['warm7_31_seconds']) < 1.e-12,
            'Warm metric is not original steps7to31.')
    processes.append(process)
for arm, group in perf['groups'].items():
    actual = [row for row in runs if row['arm'] == arm]
    require(actual, 'Empty timing arm: ' + arm)
    for key, stats in group.items():
        samples = [row['metrics'][key] for row in actual]
        require(stats['samples'] == samples and stats['median'] == statistics.median(samples),
                'Timing sample/median parser differs: ' + arm + '/' + key)
perf_images = perf.get('images', {})
require(any(row == image for row in perf_images.values()), 'The actual candidate image was not timed.')
for row in perf_images.values():
    require(same(row), 'Timed image identity changed.')
prepared_plan_path = S/'performance-prepared/plan.json'
if prepared_plan_path.is_file():
    prepared_plan = read(prepared_plan_path)
    require(not prepared_plan.get('profiler', False) and not prepared_plan.get('external_memory_monitor', False),
            'A profiler or external memory monitor was used in the timing window.')
    require(prepared_plan.get('source_or_SDK_compilations_during_rotation', 0) == 0
            and prepared_plan.get('links_during_rotation', 0) == 0, 'Timing rotation contained build/link work.')

started = min(row['started'] for row in processes)
finished = max(row['finished'] for row in processes)
beijing = timezone(timedelta(hours=8))
window = dict(started_epoch=started, finished_epoch=finished,
    started_Beijing=datetime.fromtimestamp(started, beijing).isoformat(),
    finished_Beijing=datetime.fromtimestamp(finished, beijing).isoformat(),
    source='Actual completed process metadata, UTC+08:00; no prior timings are pooled.')

# The follow-up is a distinct reversed-order window. Validate and preserve it;
# never replace the original slightly unfavorable decode samples or pool them.
FOLLOW = S/'decode-followup'
follow_inputs = read(FOLLOW/'inputs.json')
follow_summary = read(FOLLOW/'summary.json')
follow_runs = read(FOLLOW/'runs.json')
require(follow_summary['executed'] and follow_summary['terminal_zero'] == len(follow_runs) == 4
        and follow_summary['same_predictions'] and not follow_summary['statistical_significance'],
        'Reversed-order follow-up did not complete as four successful matching processes.')
require([row['arm'] for row in follow_runs] == follow_inputs['order'] == ['current','baseline','baseline','current'],
        'Follow-up must keep its actual C/B/B/C order.')
require(not follow_inputs['profiler'] and not follow_inputs['external_memory_monitor']
        and follow_inputs['compiles'] == follow_inputs['links'] == 0, 'Follow-up used instrumentation or build work.')
follow_processes = []
for row in follow_runs:
    process = read(FOLLOW/(row['tag']+'.result.json'))
    require(row['exit'] == process['exit'] == 0 and process['terminal']
            and row['same_baseline_predictions'], 'Follow-up process failed or its predictions differ.')
    expected_command = next(request['command'] for request in read(prepared_plan_path)['requests'] if request['arm'] == row['arm'])
    require(process['pid'] == row['pid'] and process['command'] == expected_command, 'Follow-up process metadata differs.')
    require(len(row['phase_step_seconds']) == 32, 'Incomplete follow-up model journey.')
    require(abs(sum(row['phase_step_seconds'][1:]) - row['metrics']['full31_seconds']) < 1.e-12
            and abs(sum(row['phase_step_seconds'][7:]) - row['metrics']['warm7_31_seconds']) < 1.e-12,
            'Follow-up complete-step timing boundaries differ.')
    follow_processes.append(process)
for arm, group in follow_summary['groups'].items():
    actual = [row for row in follow_runs if row['arm'] == arm]
    require(len(actual) == 2, 'Follow-up needs two actual processes per arm.')
    for key, stats in group.items():
        samples = [row['metrics'][key] for row in actual]
        require(stats['samples'] == samples and stats['median'] == statistics.median(samples),
                'Follow-up sample/median differs: ' + arm + '/' + key)
follow_started = min(row['started'] for row in follow_processes)
follow_finished = max(row['finished'] for row in follow_processes)
follow_window = dict(started_epoch=follow_started, finished_epoch=follow_finished,
    started_Beijing=datetime.fromtimestamp(follow_started, beijing).isoformat(),
    finished_Beijing=datetime.fromtimestamp(follow_finished, beijing).isoformat(),
    source='Actual four process result metadata; separate from the first nine-process window.')
for summary in (perf, follow_summary):
    for key, ratio in summary['current_over_baseline'].items():
        expected = summary['groups']['current'][key]['median'] / summary['groups']['baseline'][key]['median']
        require(ratio == expected, 'A reported within-window ratio differs: ' + key)

files = {}
allowed = {'.py', '.cc', '.c', '.cu', '.h', '.cuh', '.json', '.log', '.xml',
           '.diff', '.md', '.txt', '.tsv', '.csv', '.ps1', '.ids', '.d'}
excluded_names = {'publication.json', 'archive-manifest.json', 'cleanup-plan.json', 'cleanup-receipt.json'}
for path in sorted(S.rglob('*')):
    if not path.is_file():
        continue
    relative = path.relative_to(S)
    if any(part in ('tmp', '__pycache__', 'trace') for part in relative.parts):
        continue
    if path.name in excluded_names or path.name.startswith('cleanup') or path.suffix.lower() not in allowed:
        continue
    files['stage/' + relative.as_posix()] = path
# The exact compiled Hyle sources/headers are small, local and reproducible.
# Keep SDK/vendor/system dependency identities in the original CXX receipts,
# never duplicate those payloads into this experiment archive.
for row in plan['compile']:
    receipt = read(S/'checks'/(row['tag']+'-identity.json'))
    for dependency in [receipt['source'], *receipt['dependencies']]:
        path = Path(dependency['path']).resolve()
        try:
            relative = path.relative_to(ROOT)
        except ValueError:
            continue
        if relative.parts[0] in ('include', 'src') and path.suffix.lower() in allowed:
            require(same(dependency), 'Local source/header changed while archiving.')
            files['compiled-source/' + relative.as_posix()] = path
inputs = read(S/'correctness/inputs.json')
for field in ('manifest', 'prompt', 'decode'):
    row = inputs[field]
    require(same(row), 'Fixed input changed: ' + field)
    path = Path(row['path'])
    files['fixed-inputs/' + path.name] = path
for relative in ('docs/developer/current-work.md', 'tools/qwen35_text/README.md', 'docs/evidence/performance/qwen35-full-cuda-2026-10-19/README.md'):
    files['documentation/' + relative] = ROOT/relative
# Capture the independent review of the candidate's parent loader choice too.
for name in ('review.json', 'finite-query-capacity-review.json'):
    path = S.parent/'cold-startup-next-hotspot'/name
    if path.is_file():
        files['prior-review/' + name] = path

public = ROOT/'docs/evidence/performance'
public.mkdir(parents=True, exist_ok=True)
archive_path = public/'qwen-pinned-weight-load-2026-10-20.zip'
temporary = archive_path.with_suffix('.zip.tmp')
payloads = []
with zipfile.ZipFile(temporary, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
    for member, path in sorted(files.items()):
        data = path.read_bytes()
        row = dict(member=member, **identity(path))
        payloads.append(row)
        archive.writestr(member, data)
    archive.writestr('payload-sha256.json', json.dumps(payloads, ensure_ascii=False, indent=2) + '\n')
with zipfile.ZipFile(temporary) as archive:
    require(archive.testzip() is None, 'Archive CRC check failed.')
    require(len(archive.namelist()) == len(payloads) + 1, 'Archive payload count differs.')
    for row in payloads:
        data = archive.read(row['member'])
        require(len(data) == row['bytes'] and hashlib.sha256(data).hexdigest() == row['sha256'],
                'Archive payload hash failed: ' + row['member'])
temporary.replace(archive_path)

body = dict(date='2026-10-20',
    scope='Windows CUDA Qwen3.5-2B BF16 independent text consumer loader; scratch candidate measured first, followed by separately receipted adoption. Existing FileResourcePipeline with bounded pinned staging replaces synchronous whole-mapped-file uploads.',
    source_freeze=freeze, independent_review=review,
    current_product_source=product_identity,
    current_product_matches='separately_compiled_adopted_candidate_with_only_scratch_comment_removed',
    product_adoption=adoption, actual_product_check=product_check,
    actual_build=dict(summary=build, final_CXX_owners=16, native_TUs=0, SDK_rebuild=False,
        initial_IO_attempts=12, initial_IO_failed_CXX=9,
        first_failure='Root reused the consumer /DNOMINMAX definition in IO-core CXX recipes, conflicting with their existing local NOMINMAX define under /W4 /WX C4005. The IO recipes remove only that consumer macro; all12 IO owners then compile successfully. All first-attempt commands/results/logs are retained, including3 original successes. No warning suppression or product-source change is represented as a fix.'),
    correctness=dict(passed=True, equal_vectors=64, image=image,
        same_greedy_ids_as_reference=True, same_fixed_decode_inputs=True,
        all_outputs_finite=True, single_outer_range_32_phases=True,
        summary=identity(S/'correctness/summary.json'), quality_acceptance=False),
    actual_window=window, actual_processes=len(runs),
    processes_per_arm={arm:sum(row['arm'] == arm for row in runs) for arm in perf['groups']},
    actual_summary=perf, runs=runs,
    separate_decode_followup=dict(actual_window=follow_window, actual_summary=follow_summary,
        actual_processes=4, processes_per_arm=2, runs=follow_runs,
        interpretation='This reversed-order C/B/B/C window is retained separately. No samples are pooled with, or substituted for, the original nine-process window.'),
    implementation=dict(original_device_allocations=320, original_weight_bytes=3763655360,
        pinned_staging_slots=2, pinned_bytes_per_slot=8388608, pinned_staging_bytes=16777216,
        public_service='Existing FileResourcePipeline/StreamFile/CopyBatch with original Model.queue and planning_memory; no new executor, native math, global cache, SDK or full pinned weight bank.',
        lifetime='Each original Buffer becomes an individually adopted LeasePool kept open in Model until Graph uses retire. Tensor.ready retains the returned immutable lease. The source uses the actual IO File and exact ranges. Pipeline/drain/native-slot destruction, actual file close and temporary Scheduler/IoContext destruction are included before startup/TTFT completes.',
        numerical_shape='Phase::prepare and the complete execution suffix are byte-identical to the original source; original sourceidentity/dtypes/manifest count/weight payloads and mathematical routes are retained.'),
    timing_contract=dict(primary='Complete model_seconds, startup_to_ready and main-entry first_token_elapsed_seconds preserve the complete service/file/runtime cleanup. Full decode includes original31 complete step durations; warm includes steps7to31.',
        sub_timer_warning=freeze['timing_comparison_limit'],
        profiler=False, external_memory_monitor=False, compilations_during_rotation=0, links_during_rotation=0),
    interpretation='First nine-process window: TTFT2.13868to1.4459s (-32.39%); ready2.06923to1.37616s (-33.49%); full decode-2.02%,warm-1.58%,prefill-0.58%. Separate four-process C/B/B/C follow-up: TTFT2.10647to1.42928s (-32.15%); full decode+0.71%,warm-0.435%,prefill-0.40%. The small full-decode loss did not reproduce with the same direction. Neither window establishes a steady-state gain, statistical significance or proof of no regression. About32% describes startup-to-first-token, never decode. Fresh processes do not establish a cold OS page cache or cold-disk bandwidth.',
    limits=[
        'The new public loader service is exercised on one fixed model/file and128+31 input journey.64 equal hidden/logits records and matching predictions do not constitute independent model-quality acceptance.',
        'Two pinned staging slots bound the added payload to16MiB, but native/IO-private metadata and OS file cache are not claimed zero. The active-backing report includes retained destination bytes and is not a process physical-residency peak.',
        'Original ready-weight lease adoption moves from shape preparation into loading. Individual load sub-timer medians perform different subsets of cleanup; complete startup/TTFT is the causal end-to-end boundary.',
        'The pipeline retains its existing per-chunk IO/completion/native observations; physical native calls may increase. This archive does not infer time savings from API counts or software-profiler idle intervals.',
        'No OS cache eviction, cross-platform run, independent quality study, total memory-peak run or statistically powered significance test was added here.',
        'Archive retains all experiment sources, project source/header closure, initial compilation failures, commands/logs/results and binary/vector identities; SDKs, model payloads, executables, objects, libraries, maps and duplicate64 vector payloads are excluded.'],
    archive=identity(archive_path), payloads=payloads,
    archive_verified=dict(CRC=True, all_payload_SHA256=True))
save(archive_path.with_suffix('.json'), body)
save(S/'publication.json', dict(published=True, archive=identity(archive_path),
    evidence=identity(archive_path.with_suffix('.json')), payloads=len(payloads), archive_verified=body['archive_verified']))
print(json.dumps(dict(published=True, actual_window=window, actual_processes=len(runs),
    payloads=len(payloads), archive=identity(archive_path)), ensure_ascii=False, indent=2), flush=True)
