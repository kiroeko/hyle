"""Exact file-only cleanup after both new evidence bundles are verified."""
import ast
import hashlib
import json
from pathlib import Path
import shutil
import zipfile
S = Path(__file__).resolve().parent
A = S.parent
ROOT = S.parents[2]
def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))
def save(path, value):
    Path(path).write_text(json.dumps(value, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
def identity(path):
    path = Path(path).resolve()
    assert path.is_file() and path.is_relative_to(ROOT)
    return dict(path=str(path), bytes=path.stat().st_size, sha256=hashlib.sha256(path.read_bytes()).hexdigest())
reports = [ROOT/'docs/evidence'/path for path in (
    'correctness/state-clone-slot-ownership-2026-10-20.json',
    'performance/qwen-pinned-weight-load-2026-10-20.json')]
for path in reports:
    report = read(path)
    assert report['archive_verified']['CRC'] and report['archive_verified']['all_payload_SHA256']
    assert identity(report['archive']['path']) == report['archive']
    with zipfile.ZipFile(report['archive']['path']) as archive:
        assert archive.testzip() is None
        for row in read(path)['payloads']:
            data = archive.read(row['member'])
            assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256']
assert read(S/'product-checks/summary.json')['passed']
assert read(A/'state-clone-slot-ownership/tests/summary.json')['passed']
targets = read(A/'state-clone-slot-ownership/cleanup-candidates.json')['files']
for row in targets:
    assert identity(row['path'])==row
for directory, name in [('qwen-pinned-weight-load/checks', 'qwen'),
                        ('projected-bind-cold-index/checks/host1', 'qwen')]:
    for suffix in ('.exe','.map','.lib','.exp'):
        path = A/directory/(name+suffix)
        if path.is_file():
            targets.append(identity(path))
reference = A/'batch-graph-capture/correctness-final/trace'
vectors = []
for path in sorted((S/'correctness/trace').rglob('*')):
    if path.is_file() and path.suffix in ('.bf16','.f32'):
        original = reference/path.relative_to(S/'correctness/trace')
        row, old = identity(path), identity(original)
        assert (row['bytes'],row['sha256'])==(old['bytes'],old['sha256'])
        targets.append(row)
        vectors.append(dict(duplicate=row, original=old))
assert len(vectors)==64 and len(targets)==84
protected = [identity(A/path) for path in (
    'state-clone-slot-ownership/checks/after.exe',
    'grouped-fp8-scale-order/checks/tests.exe',
    'qwen-pinned-weight-load/product-checks/qwen.exe',
    'gdn-direct-state-output/checks/native1/qwen.exe',
    'cuda-explicit-rope/performance-prepared/peer.exe')]
protected += [row['original'] for row in vectors]
protected += [identity(A/'grouped-fp8-scale-order/aot'/(label+'.cubin')) for label in ('grouped_fp32','grouped_bf16')]
keys = {row['path'].casefold() for row in targets}
assert len(keys)==len(targets) and not any(row['path'].casefold() in keys for row in protected)
module = ast.parse((A/'gdn-direct-state-output/prepare_cleanup.py').read_text(encoding='utf-8'))
assignment = next(node for node in module.body if isinstance(node,ast.Assign)
    and any(isinstance(t,ast.Name) and t.id=='text' for t in node.targets))
script_text = ast.literal_eval(assignment.value).replace('gdn-direct-state-output', 'qwen-pinned-weight-load').replace('GDN_BATCH_CLEANED','PINNED_AND_STATE_BATCH_CLEANED')
script = ROOT/'test.ps1'
backup = S/'test-before-reclaim.ps1'
assert not backup.exists()
shutil.copyfile(script, backup)
script.write_text(script_text, encoding='utf-8')
save(S/'cleanup-plan.json', dict(root=str(ROOT), script=identity(script), targets=targets,
    protected=protected, vectors=vectors, reports=[identity(path) for path in reports],
    removed_bytes=sum(row['bytes'] for row in targets),
    description='Obsolete State CPU images, measured scratch candidate and older v32 Qwen images, and64 SHA-equal duplicate observations. Retain latest actual product Qwen, immediate v33 baseline, peer, latest CPU/CUDA tests, all objects/dependency libraries and original64 observations.'))
print('PINNED_STATE_CLEANUP_PREPARED', len(targets), sum(row['bytes'] for row in targets), flush=True)
