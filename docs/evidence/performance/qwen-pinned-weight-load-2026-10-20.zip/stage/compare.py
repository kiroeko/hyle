"""Same retained nine-process rotation; only320 weight loading changes."""
import argparse
import importlib.util
from pathlib import Path
import sys
sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
A = S.parent
spec = importlib.util.spec_from_file_location('pinned_loader_rotation', A/'qwen-current-retest/compare.py')
h = importlib.util.module_from_spec(spec)
spec.loader.exec_module(h)
b, c, r = h.b, h.c, h.r
h.rotation.STAGE = S
r.PREPARED = S/'performance-prepared'
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--run', action='store_true')
args = parser.parse_args()
if args.run:
    h.rotation.run(r.PREPARED/'plan.json', S/'performance-rotation')
else:
    assert c.read(S/'checks/summary.json')['passed']
    assert c.read(S/'correctness/summary.json')['passed']
    retained = c.read(A/'gdn-direct-state-output/performance-prepared/plan.json')
    images = dict(baseline=retained['images']['current'], current=c.read(S/'checks/qwen-image.json'),
        llama=retained['images']['llama'])
    for row in images.values():
        r.require_same(row)
    requests = []
    for old in retained['requests']:
        command = old['command'].copy()
        command[0] = images[old['arm']]['path']
        assert '--trace' not in command
        requests.append(dict(**{k:v for k,v in old.items() if k!='command'}, command=command))
    hc = next(row['command'] for row in requests if row['arm']=='current')
    lc = next(row['command'] for row in requests if row['arm']=='llama')
    inputs = Path(hc[hc.index('--inputs')+1])
    manifest = inputs/'weights.tsv'
    wanted = {c.key(path) for path in (manifest, inputs/'prompt.ids',
        Path(hc[hc.index('--decode-ids')+1]), Path(lc[2]),
        Path(manifest.read_text(encoding='utf-8').splitlines()[1]), Path(lc[1]))}
    frozen = [row for row in retained['frozen'] if c.key(row['path']) in wanted]
    assert {c.key(row['path']) for row in frozen}==wanted
    build_path = S/'checks/plan.json'
    frozen += [b.identity(p) for p in (Path(__file__), build_path, S/'checks/qwen-link-plan.json',
        S/'correctness/summary.json', S/'candidate/main.cc', S/'source-freeze.json', r.PEER_PLAN)]
    plan = {key: retained[key] for key in ('schema_version','status','fixed','source_id',
        'expected_baseline_ids','order','metric_contract')}
    plan.update(build_plan=b.identity(build_path), images=images, peer_inputs=retained['peer_inputs'],
        frozen=frozen, requests=requests, profiler=False, external_memory_monitor=False,
        source_or_SDK_compilations_during_rotation=0, links_during_rotation=0,
        baseline='Immediate GDNv33 original pageable/mapped320-weight loader; same model math and full timing boundary.',
        precision_limit=retained['precision_limit'],
        loading_subtimer_limit='Baseline weight sub-timer excludes later mmap destruction; candidate includes loader cleanup and moves320 lease-domain adoptions earlier. Only full model/startup/TTFT measure net loading benefit.')
    r.PREPARED.mkdir(exist_ok=False)
    c.save(r.PREPARED/'plan.json', plan)
    print('PINNED_ROTATION_PREPARED_NO_GPU', flush=True)
