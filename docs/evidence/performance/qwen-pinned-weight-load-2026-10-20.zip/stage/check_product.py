"""Compile the adopted real consumer once; preserve every measured other object."""
import importlib.util
from pathlib import Path
import sys
sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
ROOT = S.parents[2]
spec = importlib.util.spec_from_file_location('pinned_product_helpers', S.parent/'projected-bind-cold-index/build.py')
h = importlib.util.module_from_spec(spec)
spec.loader.exec_module(h)
b, c = h.b, h.c
adoption = c.read(S/'adoption.json')
assert b.same(adoption['product']) and b.same(adoption['cmake'])
source = ROOT/'tools/qwen35_text/main.cc'
candidate = (S/'candidate/main.cc').read_text(encoding='utf-8')
assert source.read_text(encoding='utf-8') == candidate.replace(
    '// Scratch loading candidate only. The original tensor math/phase lifecycle below\n// is unchanged. Each original device allocation becomes one retained lease pool;\n',
    '// Each original device allocation becomes one retained lease pool;\n')
out = S/'product-checks'
out.mkdir(exist_ok=False)
(out/'tmp').mkdir()
recipe = c.read(S/'checks/qwen-main-identity.json')
base = c.read(S/'checks/qwen-link-plan.json')
for row in base['inputs']:
    assert b.same(row), row['path']
env, runtime = b.environment(base['command'], [row['path'] for row in base['inputs']], out)
command = b.host_command(recipe['command'], source, 'main', out)
c.execute('main-compile', command, env, out)
data = c.read(out/'main-deps.json')['Data']
obj = b.identity(out/'main.obj')
c.save(out/'main-identity.json', dict(command=command, source=b.identity(source), object=obj,
    dependencies=[b.identity(p) for p in dict.fromkeys([data['Source'], *data['Includes']])]))
old = c.key(recipe['object']['path'])
lookup = {c.key(row['path']): row for row in base['inputs']}
lookup[c.key(obj['path'])] = obj
link = [obj['path'] if c.key(arg)==old else arg for arg in base['command']
    if not arg.upper().startswith(('/OUT:', '/MAP:', '/IMPLIB:', '/PDB:'))]
image = out/'qwen.exe'
link += ['/OUT:'+str(image), '/MAP:'+str(image.with_suffix('.map')), '/IMPLIB:'+str(image.with_suffix('.lib'))]
inputs = [lookup[c.key(arg)] for arg in link if Path(arg).is_absolute() and Path(arg).suffix.lower() in ('.obj','.lib')]
c.save(out/'qwen-link-plan.json', dict(command=link, inputs=inputs))
c.execute('qwen-link', link, env, out)
c.save(out/'qwen-image.json', b.identity(image))
prepared = c.read(S/'performance-prepared/plan.json')
run = next(row['command'] for row in prepared['requests'] if row['arm']=='current').copy()
run[0] = str(image)
c.execute('qwen', run, env, out)
import json
observed = json.loads((out/'qwen.stdout.log').read_text(encoding='utf-8').splitlines()[-1])
assert observed['generated_ids']==prepared['expected_baseline_ids']
assert observed['decode_input_ids']==prepared['fixed']['decode_input_ids']
assert observed['source_id']==prepared['source_id']
assert b.same(adoption['product']) and b.same(adoption['cmake'])
summary = dict(passed=True, host_TUs=1, native_TUs=0, SDK_rebuild=False,
    executed_product_source=b.identity(source), image=b.identity(image), fixed128_plus31=True,
    unchanged_predictions=True, executable_CXX_text_equal_to_measured_candidate=True,
    source_difference='Comments and translation-unit file path only.',
    limits='One real adopted-source smoke run;64-vector numerical comparison and13-process timing windows were performed on the executable-text-identical scratch candidate. This extra smoke run is not pooled into performance medians.')
c.save(out/'summary.json', summary)
adoption['compiled_product'] = True
adoption['product_check'] = b.identity(out/'summary.json')
adoption['product_image'] = b.identity(image)
c.save(S/'adoption.json', adoption)
print('PINNED_PRODUCT_CHECKED', flush=True)
