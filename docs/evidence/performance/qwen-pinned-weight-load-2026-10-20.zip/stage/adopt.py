"""Adopt only the measured public loader into the independent CUDA consumer."""
import importlib.util
from pathlib import Path
import sys
sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
ROOT = S.parents[2]
spec = importlib.util.spec_from_file_location('pinned_adoption_helpers', S.parent/'projected-bind-cold-index/build.py')
h = importlib.util.module_from_spec(spec)
spec.loader.exec_module(h)
b, c = h.b, h.c
source = ROOT/'tools/qwen35_text/main.cc'
cmake = source.with_name('CMakeLists.txt')
old_source = b.identity(source)
assert old_source['sha256']=='38ee18ff552ee4db15663469457d293219d4f6e4bbbef3ae4037af8c16350869'
assert b.identity(S/'candidate/main.cc')['sha256']=='a786d41688ab0b07031dd6c6b0b870a6aea358fc0508662e2b9a4dae4601bab8'
assert c.read(S/'correctness/summary.json')['passed']
assert c.read(S/'performance-rotation/summary.json')['terminal_zero']==9
assert c.read(S/'decode-followup/summary.json')['terminal_zero']==4
before = S/'before/CMakeLists.txt'
before.write_bytes(cmake.read_bytes())
text = (S/'candidate/main.cc').read_text(encoding='utf-8')
text = text.replace('// Scratch loading candidate only. The original tensor math/phase lifecycle below\n// is unchanged. Each original device allocation becomes one retained lease pool;\n',
    '// Each original device allocation becomes one retained lease pool;\n')
assert text != (S/'candidate/main.cc').read_text(encoding='utf-8')
cmake_text = cmake.read_text(encoding='utf-8')
find = 'COMPONENTS compute graph graph_progress mem)'
link = 'hyle::graph hyle::compute hyle::graph_progress hyle::mem)'
assert cmake_text.count(find)==1 and cmake_text.count(link)==1
cmake_text = cmake_text.replace(find, 'COMPONENTS compute graph graph_progress compute_stream mem)')
cmake_text = cmake_text.replace(link, 'hyle::graph hyle::compute hyle::graph_progress hyle::compute_stream hyle::mem)')
source.write_text(text, encoding='utf-8')
cmake.write_text(cmake_text, encoding='utf-8')
after = S/'product'
after.mkdir(exist_ok=False)
(after/'main.cc').write_bytes(source.read_bytes())
(after/'CMakeLists.txt').write_bytes(cmake.read_bytes())
c.save(S/'adoption.json', dict(adopted=True, before=old_source, candidate=b.identity(S/'candidate/main.cc'),
    product=b.identity(source), product_snapshot=b.identity(after/'main.cc'),
    before_cmake=b.identity(before), cmake=b.identity(cmake), cmake_snapshot=b.identity(after/'CMakeLists.txt'),
    code_difference='Only remove the scratch-only two-line comment from the frozen measured candidate; all executable C++ text unchanged.',
    package_dependency='Normal public compute_stream component and hyle::compute_stream target; no user provider or internal library flags.',
    measured_scope='TTFT -32% in two small windows, not prefill/decode throughput gain; retain both original and reversed-order windows.',
    compiled_product=False))
print('PINNED_LOADER_ADOPTED', flush=True)
