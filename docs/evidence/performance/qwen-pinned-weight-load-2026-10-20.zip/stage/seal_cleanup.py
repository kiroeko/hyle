"""Receipt the executed cleanup without rewriting immutable source archives."""
import hashlib
import json
from pathlib import Path
S = Path(__file__).resolve().parent
ROOT = S.parents[2]
def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))
def save(path, value):
    Path(path).write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def identity(path):
    path = Path(path).resolve()
    return dict(path=str(path),bytes=path.stat().st_size,sha256=hashlib.sha256(path.read_bytes()).hexdigest())
plan, receipt = read(S/'cleanup-plan.json'), read(S/'cleanup-executed.json')
assert receipt['removed']==plan['targets'] and len(receipt['removed'])==84
assert receipt['removed_bytes']==plan['removed_bytes'] and receipt['script_sha256']==plan['script']['sha256']
assert not any(Path(row['path']).exists() for row in plan['targets'])
assert all(identity(row['path'])==row for row in plan['protected'])
archives = []
for row in plan['reports']:
    report = read(row['path'])
    assert identity(report['archive']['path'])==report['archive']
    archives.append(report['archive'])
destination = ROOT/'docs/evidence/performance/qwen-pinned-weight-load-2026-10-20.cleanup.json'
save(destination,dict(executed=True,receipt=receipt,plan=plan,all_targets_absent=True,
    all_protected_SHA256_equal=True,archives_unchanged=archives))
for row in plan['reports']:
    report = read(row['path'])
    report['cleanup'] = dict(executed=True,actual=identity(destination),removed_bytes=receipt['removed_bytes'],
        scope='Shared State ownership and pinned loader cleanup; count these bytes once.')
    save(row['path'],report)
print('PINNED_STATE_CLEANUP_VERIFIED',receipt['removed_bytes'],flush=True)
