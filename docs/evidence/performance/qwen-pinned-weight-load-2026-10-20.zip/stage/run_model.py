"""One fresh full CUDA model and the retained64 exact hidden/logit observations."""
import importlib.util
from pathlib import Path
import sys
sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
A = S.parent
def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module
h = load('pinned_model_helpers', A/'projected-bind-cold-index/build.py')
b, c = h.b, h.c
n = load('pinned_model_numerics', A/'cuda-bf16-dual-projection/compare_numerics.py')
out = S/'correctness'
out.mkdir(exist_ok=False)
(out/'tmp').mkdir()
plan_path = S/'checks/plan.json'
plan = c.read(plan_path)
assert c.read(S/'checks/summary.json')['passed']
for row in plan['frozen']:
    assert b.same(row), row['path']
for path in (S/'checks').glob('*-identity.json'):
    receipt = c.read(path)
    assert b.same(receipt['object'])
    for row in receipt['dependencies']:
        assert b.same(row), row['path']
reference = A/'batch-graph-capture/correctness-final'
vectors = {path.relative_to(reference/'trace'): n.identity(path)
    for path in sorted((reference/'trace').rglob('*')) if path.suffix in ('.bf16','.f32')}
assert len(vectors)==64
command = c.read(reference/'qwen.command.json')['command'].copy()
command[0] = plan['links']['qwen']['image']
command[command.index('--trace')+1] = str(out/'trace')
inputs = Path(command[command.index('--inputs')+1])
manifest = inputs/'weights.tsv'
model = Path(manifest.read_text(encoding='utf-8').splitlines()[1])
image = b.identity(command[0])
assert image == c.read(S/'checks/qwen-image.json')
c.save(out/'inputs.json', dict(plan=b.identity(plan_path), image=image, command=command,
    manifest=b.identity(manifest), model=b.identity(model), prompt=b.identity(inputs/'prompt.ids'),
    decode=b.identity(command[command.index('--decode-ids')+1]), reference_vectors=list(vectors.values()),
    quality_acceptance=False, throughput_claim=False, fresh_model_processes=1))
link = plan['links']['qwen']
env, runtime = b.environment(link['command'], [row['path'] for row in link['inputs']], out)
c.save(out/'runtime-environment.json', dict(runtime=runtime, PATH=env['PATH']))
c.execute('qwen', command, env, out)
observed = n.analyze_arm('current', image, out, vectors, n.final_json(reference/'qwen.stdout.log'))
single_range = len(observed['capture_counts'])==32 and all(
    row['recorded']+row['reused']==1 and row['replay']=='hybrid' for row in observed['capture_counts'])
passed = observed['equal_vectors']==64 and observed['all_outputs_finite'] and single_range and \
    observed['same_greedy_ids_as_reference'] and observed['same_fixed_decode_inputs']
c.save(out/'summary.json', dict(passed=passed, observation=observed, route='hybrid',
    single_outer_range_32_phases=single_range, quality_acceptance=False, throughput_claim=False,
    fresh_model_processes=1, limits='One fixed128+31 CUDA test consumer;64 exact original BF16 hidden/logit observations. No independent model quality or throughput claim.'))
assert passed, observed
print('PINNED_MODEL_CHECK', observed['equal_vectors'], flush=True)
