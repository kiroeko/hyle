#include "hyle/io/io_context.h"

#include <new>

#include "hyle/io/detail/net.h"
#include "hyle/io/detail/net_timeout.h"
#if HYLE_OS_LINUX
#  include "hyle/io/detail/net_multishot.h"
#endif
#include "hyle/core/compiler.h"
#include "hyle/obs/trace.h"
#include "hyle/sched/detail/integration.h"
#include "hyle/sched/waker.h"  // current_worker_index()

// io-04 integration (plan A). One proactor per worker; the poll hook reaps the
// caller worker's ring and routes each completion to its awaiting fiber via
// net::complete(). See io_context.h for the per-core-ring rationale.

namespace hyle::io {

using detail::Completion;
using detail::Proactor;
using detail::complete;
using detail::complete_timed;
using detail::is_timed_token;
#if HYLE_OS_LINUX
using detail::complete_multishot;
using detail::is_multishot_token;
#endif

IoContext::IoContext(sched::Scheduler& sched,
                     IoContextOptions options) noexcept
    : sched_(sched),
      allocator_(options.allocator),
      blocking_(allocator_, options.max_blocking_threads,
                options.blocking_keep_alive, &status_) {
  if (!sched.valid()) {
    status_ = Status::FailedPrecondition(
        "IO context requires a valid scheduler");
    return;
  }
  if (options.queue_depth == 0) {
    status_ = Status::InvalidArgument(
        "IO context queue depth must be at least one");
    return;
  }
  if (!status_.ok()) return;

  const unsigned num_workers = sched.num_workers();
  rings_ = allocator_.allocate_n<Proactor>(num_workers);
  if (rings_ == nullptr) {
    status_ = Status::ResourceExhausted(
        "IO context ring table allocation failed");
    return;
  }
  for (unsigned i = 0; i < num_workers; ++i) {
    ::new (static_cast<void*>(&rings_[i])) Proactor();
    ++ring_count_;
  }
  for (unsigned i = 0; i < num_workers; ++i) {
    // COOP_TASKRUN is the portable context policy. The incompatible
    // DEFER_TASKRUN/R_DISABLED experiment remains an internal Proactor mechanism;
    // it cannot be a normal IoContext switch while provided-buffer registration
    // requires a different lifecycle.
    if (!rings_[i].init(options.queue_depth,
                        /*defer_worker_thread=*/false)) {
      destroy_rings();
      status_ = Status::Unavailable("IO backend initialization failed");
      return;
    }
  }
  if (!sched::detail::SchedulerIntegration::attach_io(
          sched_, &IoContext::poll_trampoline, &IoContext::wake_trampoline,
          this)) {
    destroy_rings();
    status_ = Status::AlreadyExists(
        "scheduler already has an attached IO context");
    return;
  }
  valid_ = true;
}

IoContext::~IoContext() {
  // Unregister before we (and our rings) are destroyed so no worker calls a
  // dangling hook during teardown. The scheduler is expected already stopped
  // (its shutdown() drained fibers) by the time IoContext is destroyed.
  if (valid_) {
    sched::detail::SchedulerIntegration::detach_io(sched_, this);
  }

  // io-06 orphan drain: a timed op whose TIMER won submitted a cancel and resumed
  // its fiber, but the cancelled kernel op still owes a late completion (io_uring
  // -ECANCELED / IOCP ABORTED / epoll's synthesized one) that drops the op's heap
  // slot's kernel-ref. If the scheduler shut down before that landed, the workers
  // are gone and no one will reap it -> the TimedSlot leaks. So here, with workers
  // stopped (single-threaded, safe to touch each ring), drain every ring until it
  // owes nothing: each late TIMED completion routes through complete_timed, which
  // (seeing timer_fired) releases the kernel-ref and frees the heap slot. Bounded so
  // a wedged ring can't hang teardown. (tokio-uring's Driver::drop does the same.)
  //
  // BASE (untimed) op late completions are DROPPED here, NOT routed to complete()
  // (red-team L5): a base op's IoOperation slot lives on its awaiting fiber's STACK,
  // and by teardown that fiber is gone (scheduler stopped; a caller that reached
  // ~IoContext after drain_for() TIMED OUT may have abandoned a fiber still blocked
  // on a base op whose peer never sent). complete() would deref that freed stack
  // slot + wake a dead fiber -> UAF. There is nothing to free for a base op (no heap
  // slot, no kernel-ref to balance -- the stack slot died with the fiber), so the
  // only correct action is to reap-and-discard: pull the CQE off the ring so the
  // kernel is squared, and drop it. (Normal drain-to-completion never reaches here
  // with a base op in flight; this is purely the abandoned-op teardown backstop.)
  for (unsigned ring_index = 0; ring_index < ring_count_; ++ring_index) {
    Proactor& ring = rings_[ring_index];
    Completion batch[64];
    for (int guard = 0; guard < 1024 && ring.in_flight(); ++guard) {
      std::size_t n = ring.reap(batch, 64, 1'000'000ull);  // up to 1ms per wait
      for (std::size_t i = 0; i < n; ++i) {
        if (batch[i].user_data == Proactor::kWakeToken) continue;
        if (
#if HYLE_OS_LINUX
            is_multishot_token(batch[i].user_data)
#else
            false
#endif
        ) {
#if HYLE_OS_LINUX
          complete_multishot(batch[i]);
#endif
        } else if (is_timed_token(batch[i].user_data)) {
          complete_timed(batch[i]);
        }
        // else: base op late completion -> DROP (its stack slot/fiber are gone; see
        // the L5 note above). Reaped off the ring already, so nothing more to do.
      }
      // A cancel completion is asynchronous. A single 1 ms timeout is not proof
      // that the ring is permanently wedged (and was observed to leak TimedSlot
      // on Linux under ordinary scheduler teardown). Keep polling while the
      // backend still reports in-flight work; the guard remains the hard bound.
    }
  }
  destroy_rings();
}

void IoContext::destroy_rings() noexcept {
  if (rings_ == nullptr) return;
  for (unsigned i = ring_count_; i > 0; --i) rings_[i - 1].~Proactor();
  allocator_.deallocate_n(rings_, ring_count_);
  rings_ = nullptr;
  ring_count_ = 0;
}

bool IoContext::bind_handle(unsigned worker_idx,
                            std::intptr_t handle) noexcept {
  // Associate the fd with this worker's ring. On IOCP this is the (once-only)
  // CreateIoCompletionPort association; on io_uring/epoll register_handle is a
  // no-op returning true. After this, the fd's ops must run on worker_idx (pin
  // the connection fiber there with Scheduler::spawn_on).
  if (worker_idx >= ring_count_ || handle < 0) return false;
  return rings_[worker_idx].register_handle(handle);
}

IoCapabilities IoContext::capabilities(unsigned worker) const noexcept {
  if (!valid_ || worker >= ring_count_) return {};
  return rings_[worker].capabilities();
}

#if HYLE_OS_LINUX
IoUringExtension IoContext::io_uring(unsigned worker) noexcept {
  if (!valid_ || worker >= ring_count_ ||
      rings_[worker].backend_kind() != IoBackend::kIoUring) {
    return {};
  }
  return IoUringExtension(this, worker);
}
#endif

bool IoContext::poll_trampoline(void* ctx, unsigned worker_idx,
                                unsigned long long timeout_ns) noexcept {
  return static_cast<IoContext*>(ctx)->poll(worker_idx, timeout_ns);
}

void IoContext::wake_trampoline(void* ctx, unsigned worker_idx) noexcept {
  // Break worker_idx's blocking reap by waking ITS ring (park merge). Writes the
  // ring's wake eventfd (io_uring) / posts its port (IOCP) -- thread-safe, no SQ
  // race. The woken reap returns and the worker re-checks its run queue.
  auto* self = static_cast<IoContext*>(ctx);
  HYLE_FATAL_ASSERT(worker_idx < self->ring_count_);
  self->rings_[worker_idx].wake();
}

bool IoContext::poll(unsigned worker_idx,
                     unsigned long long timeout_ns) noexcept {
  HYLE_FATAL_ASSERT(worker_idx < ring_count_);
  HYLE_TRACE_ZONE_NAMED("hyle.io.reap");
  // Reap THIS worker's own ring only (per-core: submit + reap share this thread,
  // no lock). A batch amortizes the reap syscall. Every completion here is an io
  // op whose user_data is an IoOperation*, so net::complete() casts it back,
  // stores the result, and wakes the fiber.
  //
  // Return whether ops were in flight BEFORE we reaped: the scheduler uses this
  // at the park boundary to decide whether to loop (io outstanding -> we may have
  // blocked in the ring harvesting, so re-check the run queue) or park on its
  // futex (nothing outstanding -> a non-blocking poll only, so a cross-thread
  // wake should interrupt an ordinary park, which a reap block cannot). The
  // blocking GETEVENTS reap when timeout_ns > 0 is what actually surfaces
  // io_uring completions that a non-blocking reap(0) never would (the hang fix).
  Proactor& p = rings_[worker_idx];
  bool had_io = p.in_flight();
  Completion batch[64];
  std::size_t n = p.reap(batch, 64, had_io ? timeout_ns : 0);
#if defined(HYLE_TRACE) && defined(HYLE_TRACE_TRACY)
  static thread_local unsigned long long trace_completions = 0;
  trace_completions += n;
  HYLE_TRACE_COUNTER("hyle.io.completions", trace_completions);
#endif
  for (std::size_t i = 0; i < n; ++i) {
    // Skip the cross-thread wake token: it carries no IoOperation* (it only broke
    // the block). io_uring/epoll drop it inside reap, but IOCP's wake posts it as a
    // completion, so filter here to defend all backends uniformly.
    if (batch[i].user_data == Proactor::kWakeToken) continue;
    // io-06: a TIMED op's token has bit 0 set (a tagged &TimedSlot); route it to
    // the timed arbiter (handles the normal, late-cancel, and cancel-op-own CQEs).
    // io-07b: a MULTISHOT stream's token has bits 0b11 (bit0 set too, so it lands in
    // this branch); is_multishot_token catches it first and routes to its own arbiter
    // (one token, many completions, kernel ref spent on the kMore-clear terminal one).
    // An ordinary op's token is a clean &IoOperation -> the plain router.
    if (
#if HYLE_OS_LINUX
        is_multishot_token(batch[i].user_data)
#else
        false
#endif
    ) {
#if HYLE_OS_LINUX
      complete_multishot(batch[i]);
#endif
    } else if (is_timed_token(batch[i].user_data)) {
      complete_timed(batch[i]);
    } else {
      complete(batch[i]);
    }
  }
  return had_io;
}

}  // namespace hyle::io
