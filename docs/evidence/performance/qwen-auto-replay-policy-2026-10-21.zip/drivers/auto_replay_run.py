"""One bounded verification of the consumer's declared-use replay policy."""
from pathlib import Path
import importlib.util
import statistics
import sys

sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('d4_auto_original_runner', S / 'root_run.py')
r = importlib.util.module_from_spec(spec)
spec.loader.exec_module(r)
P = S / 'auto-replay-policy'
READY = r.read(P / 'ready-for-root.json')
IMAGE = READY['image']
assert r.identity(IMAGE['path']) == IMAGE


def smoke():
    out = P / 'correctness'
    out.mkdir(exist_ok=False)
    old = S / 'current-correctness'
    command = r.read(old / 'qwen.command.json')['command'].copy()
    command[0] = IMAGE['path']
    index = command.index('--replay')
    del command[index:index + 2]  # Also exercise the new default, without an explicit override.
    command[command.index('--trace') + 1] = str(out / 'trace')
    process = r.execute(out, 'qwen', command)
    obs = r.hyle_observation(out, 'qwen')
    old_obs = r.read(old / 'summary.json')['observation']
    refs = {p.relative_to(old / 'trace'): r.identity(p) for p in sorted((old / 'trace').rglob('*'))
            if p.suffix in ('.f32', '.bf16')}
    actual = {p.relative_to(out / 'trace'): r.identity(p) for p in sorted((out / 'trace').rglob('*'))
              if p.suffix in ('.f32', '.bf16')}
    assert len(refs) == len(actual) == 64 and refs.keys() == actual.keys()
    vectors = [dict(name=k.as_posix(), actual=v, reference=refs[k],
                    byte_equal=(v['bytes'], v['sha256']) == (refs[k]['bytes'], refs[k]['sha256']))
               for k, v in actual.items()]
    checks = dict(all64_vectors_equal=all(x['byte_equal'] for x in vectors),
                  fixed_inputs_equal=obs['raw']['decode_input_ids'] == old_obs['raw']['decode_input_ids'],
                  predictions_equal=obs['raw']['generated_ids'] == old_obs['raw']['generated_ids'],
                  one_shot_commands_then_decode_capture=obs['capture_counts'] == [[0, 0], [1, 0], [1, 0]] + [[0, 1]] * 29)
    r.save(out / 'summary.json', dict(passed=all(checks.values()), checks=checks, vectors=vectors,
                                     process=process, observation=obs, independent_model_quality_acceptance=False))
    assert all(checks.values()), checks
    print('AUTO64_EQUAL_DEFAULT_POLICY_VERIFIED', flush=True)


def timing(workload):
    assert r.read(P / 'correctness/summary.json')['passed']
    out = P / (workload + '-timing')
    out.mkdir(exist_ok=False)
    cached = workload == 'cached16'
    if cached:
        old = S / 'cached16-timing/attempt1'
        hc = r.read(old / '01-current.command.json')['command'].copy()
        pc = r.read(old / '02-llama.command.json')['command'].copy()
    else:
        hc, pc = r.commands(workload == 'long')
    images = dict(capture=r.CURRENT, auto=IMAGE, llama=r.identity(pc[0]))
    order = ['capture', 'auto', 'llama', 'llama', 'capture', 'auto', 'auto', 'llama', 'capture']
    r.save(out / 'inputs.json', dict(workload=workload, images=images, order=order,
                                   source=r.identity(S / 'auto_replay_run.py'), profiler=False,
                                   memory_observer=False, builds_during_window=False,
                                   unchanged_full_host_token_timer=True, context_capacity=256,
                                   page_cache='Uncontrolled; not cold disk',
                                   precision='Same BF16 weights; Hyle/peer intermediate precision and engine sampled-logit readback still differ.'))
    runs = []
    for i, arm in enumerate(order, 1):
        tag = f'{i:02}-{arm}'
        command = (pc if arm == 'llama' else hc).copy()
        command[0] = images[arm]['path']
        if arm == 'llama':
            command[-1] = str(out / (tag + '-peer-result.json'))
        elif arm == 'auto':
            command[command.index('--replay') + 1] = 'auto'
        process = r.execute(out, tag, command)
        if arm == 'llama':
            raw = r.read(command[-1])
            obs = dict(raw=raw, phases=raw['phases'], loading=raw['loading'])
        else:
            obs = r.hyle_observation(out, tag)
        rows = obs['phases']
        if cached:
            assert [x['input_tokens'] for x in rows] == [128, 16] + [1] * 15
            assert [x['visible_tokens'] for x in rows] == [128] + list(range(144, 160))
            decode_start = 2
        else:
            n = 127 if workload == 'long' else 31
            assert [x['input_tokens'] for x in rows] == [128] + [1] * n
            assert [x['visible_tokens'] for x in rows] == list(range(128, 129 + n))
            decode_start = 1
        seconds = [x['step_seconds'] for x in rows]
        decode = seconds[decode_start:]
        metrics = dict(prefill_tokens_per_second=128 / seconds[0],
                       full_decode_tokens_per_second=len(decode) / sum(decode),
                       stable_decode_tokens_per_second=(len(decode) - 6) / sum(decode[6:]))
        if cached:
            metrics['cached_continuation_tokens_per_second'] = 16 / seconds[1]
        print('  auto comparison', {k: round(v, 2) for k, v in metrics.items()}, flush=True)
        runs.append(dict(tag=tag, arm=arm, process=process, observation=obs, metrics=metrics,
                         predictions=[x['predicted_id'] for x in rows]))
        r.save(out / 'runs.json', runs)
    expected = next(x['predictions'] for x in runs if x['arm'] == 'capture')
    same = all(x['predictions'] == expected for x in runs if x['arm'] != 'llama')
    groups = {arm: {key: dict(samples=[x['metrics'][key] for x in runs if x['arm'] == arm],
                             median=statistics.median(x['metrics'][key] for x in runs if x['arm'] == arm))
                    for key in runs[0]['metrics']} for arm in images}
    r.save(out / 'summary.json', dict(passed=same, groups=groups, Hyle_predictions_equal=same,
                                     processes=9, independent_model_quality_acceptance=False,
                                     auto_over_capture={k: groups['auto'][k]['median'] / groups['capture'][k]['median'] for k in groups['auto']},
                                     auto_over_llama={k: groups['auto'][k]['median'] / groups['llama'][k]['median'] for k in groups['auto']},
                                     statistical_significance=False))
    assert same


def memory():
    spec = importlib.util.spec_from_file_location('d4_auto_existing_memory_driver', S / 'memory_run.py')
    m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m)
    sampler_path = r.A / 'qwen-gpu-comparison/memory-probe/memory_probe.py'
    Probe = m.load('d4_auto_existing_sampler', sampler_path).MemoryProbe
    out = P / 'memory-observations'
    out.mkdir(exist_ok=False)
    hc, pc = r.commands(False)
    hc[0] = IMAGE['path']
    hc[hc.index('--replay') + 1] = 'auto'
    r.save(out / 'inputs.json', dict(current_image=IMAGE, peer_image=r.identity(pc[0]),
                                   driver=r.identity(S / 'memory_run.py'), sampler=r.identity(sampler_path),
                                   source=r.identity(__file__), interval_seconds=0.05,
                                   throughput_evidence=False, scope='One short128+31 fresh process per arm; original sampler, null/phase limits unchanged.'))
    results = {}
    for arm, command in [('current', hc), ('reference', pc)]:
        results[arm] = m.run_one(r, Probe, out, arm, command)
        r.save(out / 'summary.json', dict(arms=results, throughput_evidence=False))
        assert results[arm]['exit'] == 0 and not results[arm]['timeout']
        print('AUTO_MEMORY', arm, results[arm]['peaks'], flush=True)


if __name__ == '__main__':
    action = sys.argv[1]
    if action == 'smoke':
        smoke()
    elif action == 'memory':
        memory()
    else:
        timing(action)
