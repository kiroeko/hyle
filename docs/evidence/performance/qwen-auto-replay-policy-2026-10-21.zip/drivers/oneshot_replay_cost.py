"""Finite capture-vs-Commands cost check. Same existing consumer, no builds."""
from pathlib import Path
import importlib.util
import statistics
import sys

sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('d4_oneshot_original', S / 'root_run.py')
r = importlib.util.module_from_spec(spec)
spec.loader.exec_module(r)


def main():
    out = S / 'oneshot-replay-cost'
    out.mkdir(exist_ok=False)
    old = S / 'cached16-timing/attempt1'
    original = r.read(old / '01-current.command.json')['command']
    expected = r.read(old / 'runs.json')[0]['predictions']
    order = ['capture', 'commands', 'commands', 'capture', 'capture', 'commands']
    r.save(out / 'inputs.json', dict(image=r.CURRENT, order=order, profiler=False, memory_observer=False,
                                   source_command=r.identity(old / '01-current.command.json'),
                                   scope='Only existing global --replay choice differs. Both prefill128 and cached16 affected. No policy edits.',
                                   input_and_full_host_token_boundary_unchanged=True))
    runs = []
    for i, arm in enumerate(order, 1):
        tag = f'{i:02}-{arm}'
        command = original.copy()
        command[command.index('--replay') + 1] = 'prefer-capture' if arm == 'capture' else 'commands'
        process = r.execute(out, tag, command)
        obs = r.hyle_observation(out, tag)
        assert [x['predicted_id'] for x in obs['phases']] == expected
        metrics = dict(prefill_tokens_per_second=128 / obs['phases'][0]['step_seconds'],
                       continuation_tokens_per_second=16 / obs['phases'][1]['step_seconds'],
                       decode_tokens_per_second=15 / sum(x['step_seconds'] for x in obs['phases'][2:]))
        print('  mode', arm, {k: round(v, 2) for k, v in metrics.items()}, flush=True)
        runs.append(dict(tag=tag, arm=arm, process=process, metrics=metrics, observation=obs))
        r.save(out / 'runs.json', runs)
    groups = {arm: {key: dict(samples=[x['metrics'][key] for x in runs if x['arm'] == arm],
                             median=statistics.median(x['metrics'][key] for x in runs if x['arm'] == arm))
                    for key in runs[0]['metrics']} for arm in ('capture', 'commands')}
    r.save(out / 'summary.json', dict(groups=groups, all_fixed_predictions_identical=True,
                                     independent_model_quality_acceptance=False,
                                     limitation='Global replay switch also changes prefill/cuda graph history. Not an isolated T16-only causal decomposition.'))


if __name__ == '__main__':
    main()
