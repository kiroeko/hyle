"""Two serial cached16 diagnostic traces, separate from throughput evidence."""
from pathlib import Path
import importlib.util
import sys

sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('d4_trace_original_runner', S / 'root_run.py')
r = importlib.util.module_from_spec(spec)
spec.loader.exec_module(r)
NSYS = Path('C:/Program Files/NVIDIA Corporation/Nsight Systems 2026.1.3/target-windows-x64/nsys.exe')


def main():
    out = S / 'cached16-trace'
    out.mkdir(exist_ok=False)
    source = S / 'cached16-timing/attempt1'
    commands = [('current', r.read(source / '01-current.command.json')['command']),
                ('llama', r.read(source / '02-llama.command.json')['command'])]
    r.save(out / 'plan.json', dict(tool=r.identity(NSYS), script=r.identity(__file__),
                                 scope='Two unchanged actual cached16 consumers; CUDA API instrumentation only. Not throughput.',
                                 threads_sampled=False, context_switch_sampling=False,
                                 builds=0, memory_observer=False, environment=r.identity(S / 'checks/link1/runtime-environment.json')))
    for arm, command in commands:
        folder = out / arm
        folder.mkdir()
        if arm == 'llama':
            command[-1] = str(folder / 'peer-result.json')
        profile = [str(NSYS), 'profile', '--trace=cuda', '--sample=none', '--cpuctxsw=none',
                   '--cuda-trace-all-apis=true', '--discard-environment=true', '--force-overwrite=false',
                   '--output=' + str(folder / 'capture'), *command]
        r.save(folder / 'model-command.json', dict(command=command, image=r.identity(command[0]),
                                                  instrumented=True, throughput_evidence=False))
        r.execute(folder, 'profile', profile)
        r.execute(folder, 'export', [str(NSYS), 'export', '--type=sqlite', '--force-overwrite=false',
                                    '--output=' + str(folder / 'capture.sqlite'), str(folder / 'capture.nsys-rep')])
        r.save(folder / 'receipt.json', dict(report=r.identity(folder / 'capture.nsys-rep'),
                                             sqlite=r.identity(folder / 'capture.sqlite'),
                                             model_image=r.identity(command[0]), instrumented=True,
                                             throughput_evidence=False))


if __name__ == '__main__':
    main()
