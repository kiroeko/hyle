"""Read-only cached16 NSYS SQLite attribution. Never builds or runs a model."""
from pathlib import Path
import collections,hashlib,json,re,sqlite3
P=Path(__file__).resolve().parent;D=P.parent;A=D.parent
ms=lambda ns:ns/1e6
def ident(f):
 f=Path(f);return dict(path=str(f.resolve()),bytes=f.stat().st_size,sha256=hashlib.sha256(f.read_bytes()).hexdigest())
def merged(intervals):
 out=[]
 for s,e in sorted(intervals):
  if e<=s:continue
  if out and s<=out[-1][1]:out[-1][1]=max(e,out[-1][1])
  else:out.append([s,e])
 return out
def duration(a):return sum(e-s for s,e in merged(a))
def intervals(rows,s,e):return [(max(s,x['start']),min(e,x['end']))for x in rows]
def clipped(x,s,e):return max(0,min(e,x['end'])-max(s,x['start']))
def grouped(rows,s,e,name='name',limit=None):
 g=collections.defaultdict(lambda:dict(count=0,inclusive_clipped_ns=0,intervals=[]))
 for x in rows:
  a=g[str(x[name])];a['count']+=1;a['inclusive_clipped_ns']+=clipped(x,s,e);a['intervals'].append((max(s,x['start']),min(e,x['end'])))
 out=[dict(name=n,count=x['count'],inclusive_clipped_ms=ms(x['inclusive_clipped_ns']),union_clipped_ms=ms(duration(x['intervals'])))for n,x in g.items()]
 return sorted(out,key=lambda x:-x['inclusive_clipped_ms'])[:limit]
def run(arm):
 root=P/arm;db=root/'capture.sqlite';c=sqlite3.connect(db.resolve().as_uri()+'?mode=ro',uri=True);c.row_factory=sqlite3.Row
 strings={x['id']:x['value']for x in c.execute('select *from StringIds')};streams={}
 for x in c.execute('select *from ANALYSIS_FILE where id in(0,1)'):
  kind='stdout'if'stdout_'in x['filename']else'stderr';streams[kind]=strings[x['contentId']];(root/('model.'+kind+'.extracted.log')).write_text(streams[kind],encoding='utf-8')
 if arm=='current':
  phases=[];prepares=[]
  for line in streams['stderr'].splitlines():
   if re.match(r'^(prefill|continuation|decode\d+) tokens=',line):
    words=line.split();v=dict(x.split('=',1)for x in words[1:]);phases.append(dict(name=words[0],input_tokens=int(v['tokens']),visible_tokens=int(v['visible']),predicted_id=int(v['next']),step_ms=float(v['step_seconds'])*1000,submit_to_token_ms=float(v['seconds'])*1000,submit_return_ms=float(v['submit_seconds'])*1000))
   if line.startswith('prepared T='):
    v=dict(x.split('=',1)for x in line.split()[1:]);prepares.append(dict(T=int(v['T']),visible=int(v['visible']),replay=v['replay'],cold_batch_ms=float(v['cold_batch_seconds'])*1000,capture_recorded=int(v['capture_recorded']),capture_reused=int(v['capture_reused'])))
  assert len(prepares)==len(phases);[x.update(prepares[i])for i,x in enumerate(phases)]
 else:
  peer=json.loads((root/'peer-result.json').read_text());phases=[dict(**x,step_ms=x['step_seconds']*1000)for x in peer['phases']]
 assert len(phases)==17 and [x['name']for x in phases]==['prefill','continuation',*[f'decode{i}'for i in range(1,16)]]
 assert [x['input_tokens']for x in phases]==[128,16]+[1]*15
 assert [x['visible_tokens']for x in phases]==[128,144]+list(range(145,160))
 api=[dict(x,name=strings[x['nameId']])for x in c.execute('select *from CUPTI_ACTIVITY_KIND_RUNTIME order by start')];bycorr=collections.defaultdict(list)
 for x in api:bycorr[x['correlationId']].append(x)
 copies=[dict(x)for x in c.execute('select *from CUPTI_ACTIVITY_KIND_MEMCPY order by start')];dtoh=[x for x in copies if x['copyKind']==2]
 if arm=='current':assert len(dtoh)==17 and all(x['bytes']==4 for x in dtoh);pairs=[[x]for x in dtoh]
 else:
  assert len(dtoh)==34;pairs=[dtoh[i:i+2]for i in range(0,34,2)];assert all([x['bytes']for x in pair]==[4,993280]for pair in pairs)
  assert all(x['sampled_logits_elements']==248320 for x in phases)
 anchors=[]
 for i,pair in enumerate(pairs):
  last=pair[-1];ops=bycorr[last['correlationId']];assert len(ops)==1;op=ops[0]
  if arm=='current':assert 'MemcpyDtoH'in op['name']and op['end']>=last['end'];completion=op
  else:
   matches=[x for x in api if 'StreamSynchronize'in x['name']and x['globalTid']==op['globalTid']and x['start']>=op['end']and x['start']<=last['end']<=x['end']];assert matches
   completion=min(matches,key=lambda x:x['end'])
  anchors.append(dict(phase=i,name=phases[i]['name'],input_tokens=phases[i]['input_tokens'],visible_tokens=phases[i]['visible_tokens'],copies=[dict(start_ns=x['start'],end_ns=x['end'],bytes=x['bytes'],correlationId=x['correlationId'],streamId=x['streamId'])for x in pair],host_completion_api=dict(name=completion['name'],start_ns=completion['start'],end_ns=completion['end'],correlationId=completion['correlationId'])))
 s=anchors[0]['host_completion_api']['end_ns'];e=anchors[1]['host_completion_api']['end_ns'];a=[x for x in api if x['start']<e and x['end']>s]
 ks=[dict(x,name=strings[x['demangledName']])for x in c.execute('select *from CUPTI_ACTIVITY_KIND_KERNEL where start<?and end>?order by start',(e,s))]
 graphs=[dict(x)for x in c.execute('select *from CUPTI_ACTIVITY_KIND_GRAPH_TRACE where start<?and end>?order by start',(e,s))]
 cs=[x for x in copies if x['start']<e and x['end']>s];sets=[dict(x)for x in c.execute('select *from CUPTI_ACTIVITY_KIND_MEMSET where start<?and end>?',(e,s))]
 direct=intervals(ks+cs+sets,s,e);coverage=merged(direct+intervals(graphs,s,e));gaps=[];at=s
 for b,d in coverage:
  if b>at:gaps.append((at,b))
  at=max(at,d)
 if at<e:gaps.append((at,e))
 gap_info=[]
 for b,d in sorted(gaps,key=lambda x:x[1]-x[0],reverse=True)[:8]:
  overlaps=[x for x in a if x['start']<d and x['end']>b]
  gap_info.append(dict(start_from_phase_envelope_ms=ms(b-s),duration_ms=ms(d-b),overlapping_API_top=grouped(overlaps,b,d,limit=5)))
 critical=[dict(name=x['name'],start_from_envelope_ms=ms(x['start']-s),end_from_envelope_ms=ms(x['end']-s),full_duration_ms=ms(x['end']-x['start']),clipped_duration_ms=ms(clipped(x,s,e)),correlationId=x['correlationId'])for x in a if any(k in x['name']for k in ['StreamBeginCapture','StreamEndCapture','GraphInstantiate','GraphLaunch','GraphDestroy'])or x['end']-x['start']>=500000]
 begin=[x for x in a if 'StreamBeginCapture'in x['name']];end=[x for x in a if 'StreamEndCapture'in x['name']];capture_span=ms(end[-1]['end']-begin[0]['start'])if begin and end else None
 api_groups=grouped(a,s,e);sync=[x for x in a if 'Synchronize'in x['name']];copygroups=collections.defaultdict(lambda:dict(count=0,bytes=0,intervals=[]))
 for x in cs:
  k=(x['copyKind'],x['bytes']);v=copygroups[k];v['count']+=1;v['bytes']+=x['bytes'];v['intervals'].append((max(s,x['start']),min(e,x['end'])))
 report=dict(sqlite=ident(db),receipt=ident(root/'receipt.json'),model_command=ident(root/'model-command.json'),extracted_stderr=ident(root/'model.stderr.extracted.log'),phase_count=17,phases=phases,host_token_mapping=anchors,t16=dict(phase_ordinal=1,logged_phase=phases[1],envelope_start_ns=s,envelope_end_ns=e,envelope_ms=ms(e-s),envelope_minus_logged_step_ms=ms(e-s)-phases[1]['step_ms'],envelope_definition='From previous prefill host-token completion API return to continuation host-token completion API return. Identified by exact ordered DtoH copies and runtime correlations; includes inter-phase logging/snapshot and excludes short host bookkeeping after token availability. Not claimed to equal the source CPU timer boundaries.',API_record_count=len(a),API_inclusive_sum_ms=sum(clipped(x,s,e)for x in a)/1e6,API_union_ms=ms(duration(intervals(a,s,e))),API_top=api_groups[:20],sync_API=grouped(sync,s,e),critical_API_timeline=critical,capture_recording_envelope_ms=capture_span,graph_launch_API_count=sum('GraphLaunch'in x['name']for x in a),graph_instantiate_API_count=sum('GraphInstantiate'in x['name']for x in a),graph_add_child_node_API_count=sum('GraphAddChildGraphNode'in x['name']for x in a),GPU_graphs=[dict(start_from_envelope_ms=ms(x['start']-s),end_from_envelope_ms=ms(x['end']-s),duration_ms=ms(x['end']-x['start']),graphId=x['graphId'],graphExecId=x['graphExecId'],correlationId=x['correlationId'])for x in graphs],visible_kernel_count=len(ks),visible_kernel_duration_sum_ms=sum(clipped(x,s,e)for x in ks)/1e6,visible_kernel_union_ms=ms(duration(intervals(ks,s,e))),visible_kernel_first_ms=ms(min(x['start']for x in ks)-s)if ks else None,visible_kernel_span_ms=ms(max(x['end']for x in ks)-min(x['start']for x in ks))if ks else None,visible_kernel_top=grouped(ks,s,e,limit=12),recorded_non_graph_GPU_activity_union_ms=ms(duration(direct)),graph_envelope_plus_visible_GPU_coverage_ms=ms(duration(coverage)),outside_recorded_activity_or_graph_envelope_ms=ms(e-s-duration(coverage)),uncovered_gap_top=gap_info,memcpy_groups=[dict(copyKind=k[0],single_copy_bytes=k[1],count=v['count'],total_bytes=v['bytes'],GPU_union_ms=ms(duration(v['intervals'])))for k,v in sorted(copygroups.items())],network_kernel_duration_sum_ms=None if graphs else sum(clipped(x,s,e)for x in ks)/1e6,recorded_GPU_activity_busy_union_ms=None if graphs else ms(duration(direct)),graph_detail_limit='NSYS graph-level capture hides internal graph kernels and intra-graph holes. Graph span/coverage is not kernel/memcopy busy union; direct kernel sums are incomplete.'if graphs else'No graph execution in this phase; recorded direct kernel union is measurable.'))
 c.close();return report
out={a:run(a)for a in ['current','llama']};assert [x['predicted_id']for x in out['current']['phases']]==[x['predicted_id']for x in out['llama']['phases']]
notes=dict(scope='Two existing all-CUDA-API instrumented traces only; no model execution/build or new profiling by this analyzer.',phase_identification='Exactly 17 current 4-byte synchronous host-token copies and17 peer token+full-logits pairs map in order to extracted original phase records; T16 is phase ordinal1, with visible144 and the same actual predicted token4649.',asymmetry='Current first T16 records/captures/instantiates a full replay graph; peer T16 launches direct kernels. Current network kernels are opaque in this graph-level trace, so current vs peer cumulative kernel/busy-union comparison is unavailable.',interpretation='Capture/instantiate/enqueue and synchronization API durations can overlap one another and GPU execution. Inclusive API sums are not additive CPU cost or removable overhead. Instrumented wall times, graph spans and uncovered intervals are not no-profiler speedup estimates.',mapping_limit='The host-token API envelope is a reliable phase bracket rather than exact source CPU timer; original logged step times are reported separately. Current startup child_prepare for T16 is outside this phase, distinct from logged cold_batch_seconds inside it.',comparison=dict(logged_current_step_ms=out['current']['t16']['logged_phase']['step_ms'],logged_peer_step_ms=out['llama']['t16']['logged_phase']['step_ms'],current_graph_span_ms=sum(x['duration_ms']for x in out['current']['t16']['GPU_graphs']),peer_direct_kernel_sum_ms=out['llama']['t16']['network_kernel_duration_sum_ms']))
notes['activity_scope']='All unions concern recorded activities of the profiled process/device, not PMU-measured global GPU utilization or other processes. Captured graph interiors can hide kernels, copies and intra-graph gaps.'
notes['key_findings']=[
 dict(topic='First-use recording before execution',fact='Current logged cold_batch8.9623ms; capture recording envelope4.097153ms, one instantiate2.118740ms and graph destroy0.158456ms occur before one graph launch0.289497ms. The GPU graph starts9.489837ms after the preceding host-token API completion. The two-phase bracket differs from the exact current step timer by0.059887ms.'),
 dict(topic='Opaque graph versus direct launches',fact='Current GPU graph duration12.015401ms hides internal kernels/gaps; only4 CUB/Top1 kernels totaling0.011456ms are individually visible outside it. Peer T16 has no graph launch/capture and708 visible kernels totaling/union10.848340ms, span16.759739ms. Those unlike measures must not be treated as a kernel-speed comparison.'),
 dict(topic='Peer major direct kernels',fact='Peer150 mul_mat_f BF16-input matrix kernels total6.809757ms; one BF16-input mul_mat_vec_f kernel2.113227ms;36 CUTLASS BF16 kernels0.444061ms;18 GDN kernels0.325500ms. Current corresponding network kernel costs are unavailable in this capture.'),
 dict(topic='Uncovered intervals',fact='Current longest interval without visible work or a graph envelope is7.629909ms, overlapping capture/instantiate before graph execution. Peer longest3.455358ms overlaps a1.969886ms cuLibraryLoadData and a1.270675ms cudaLaunchKernel call. These are instrumented observations, not proven no-profiler idle or recoverable savings.'),
 dict(topic='Host-token transfer and synchronization',fact='Current one4B copy GPU duration0.001824ms. Peer one4B plus993280B sampled-logits copy durations0.001696+0.039488ms; its final stream synchronize4.562642ms includes pending network execution, so it cannot be charged entirely to logits transfer. Current final graph event wait12.135689ms similarly overlaps graph execution.'),
 dict(topic='Cold-start separation',fact='Current stderr separately records T16 child_prepare22.0638ms before ready, outside this phase. Do not combine that startup preparation with cold_batch8.9623ms as if both were inside the T16 measured step.')]
result=dict(schema='hyle.cached16.nsys-attribution.v1',notes=notes,analyzer=ident(Path(__file__)),arms=out,source_timer_snapshots=dict(current=ident(D/'checks/attempt1/main/source/tools/qwen35_text/main.cc'),peer=ident(D/'peer-continuation/peer_benchmark.cpp')),actions=dict(GPU_runs=0,compiles=0,product_edits=0,SQLite_mode='read-only'))
(P/'analysis.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(dict(output=ident(P/'analysis.json'),notes=notes),indent=2))
