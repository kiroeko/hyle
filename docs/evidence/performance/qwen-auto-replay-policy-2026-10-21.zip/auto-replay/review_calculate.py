"""Read-only host recomputation of already completed observations; no imports of runners."""
from pathlib import Path
import collections
import hashlib
import json
import math
import re
import statistics

P = Path(__file__).resolve().parent
S = P.parent
sources = {}


def data(path):
    path = Path(path)
    raw = path.read_bytes()
    sources[str(path)] = dict(path=str(path), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())
    return raw


def read(path):
    return json.loads(data(path).decode('utf-8-sig'))


def text(path):
    return data(path).decode('utf-8')


def stats(values, retain=False):
    values = list(values)
    result = dict(count=len(values), median=statistics.median(values) if values else None,
                  min=min(values) if values else None, max=max(values) if values else None)
    if retain:
        result['samples'] = values
    return result


def close(a, b):
    return math.isclose(a, b, rel_tol=1e-12, abs_tol=1e-12)


def fields(line):
    return dict(t.split('=', 1) for t in line.split()[1:] if '=' in t)


def hyle(path):
    loading, phases, prepared, plans, byte_lines = {}, [], [], [], []
    for line in text(path).splitlines():
        if line.startswith('weights_load_seconds='):
            loading['model_load_seconds'] = float(line.split('=', 1)[1])
        elif line.startswith('first_token_elapsed_seconds='):
            loading['first_token_elapsed_seconds'] = float(line.split('=', 1)[1])
        elif line.startswith('initialized '):
            loading.update({k: float(v) for k, v in fields(line).items()})
        elif line.startswith('planned_replay '):
            f = fields(line)
            plans.append(dict(tokens=int(f['T']), slot_uses=[int(f['slot0_uses']), int(f['slot1_uses'])],
                              slot_modes=[f['slot0'], f['slot1']]))
        elif line.startswith('prepared '):
            prepared.append(fields(line))
        elif re.match(r'^(prefill|continuation|decode\d+) tokens=', line):
            f, q = fields(line), prepared[len(phases)]
            step, cold, token = float(f['step_seconds']), float(q['cold_batch_seconds']), float(f['seconds'])
            phases.append(dict(name=line.split()[0], input_tokens=int(f['tokens']),
                               visible_tokens=int(f['visible']), predicted_id=int(f['next']),
                               step_seconds=step, cold_batch_seconds=cold,
                               submit_to_token_seconds=token, submit_seconds=float(f['submit_seconds']),
                               remainder_seconds=step-cold-token, replay=q['replay'],
                               capture_recorded=int(q['capture_recorded']), capture_reused=int(q['capture_reused'])))
        if line.startswith(('resident text weights:', 'pinned_weight_loader ', 'compiled text finite family ', 'compiled T=')):
            byte_lines.append(line)
    assert len(phases) == len(prepared)
    return dict(loading=loading, phases=phases, plans=plans, byte_lines=byte_lines)


def policy(run):
    rows = run['obs']['phases']
    counts, used, totals = {}, set(), collections.Counter()
    command = run['process']['command']
    mode = command[command.index('--replay')+1]
    for i, row in enumerate(rows):
        counts.setdefault(row['input_tokens'], [0, 0])[i % 2] += 1
    plans = run['obs']['plans']
    if run['arm'] == 'auto':
        assert mode == 'auto' and len(plans) == len(counts)
        for plan in plans:
            assert plan['slot_uses'] == counts[plan['tokens']]
            assert plan['slot_modes'] == ['commands' if n <= 1 else 'prefer-capture' for n in plan['slot_uses']]
    else:
        assert mode == ('commands' if run['arm'] == 'commands' else 'prefer-capture') and not plans
    for i, row in enumerate(rows):
        key = row['input_tokens'], i % 2
        commands = mode == 'commands' or (mode == 'auto' and counts[key[0]][key[1]] <= 1)
        expected = (0, 0) if commands else ((0, 1) if key in used else (1, 0))
        assert (row['capture_recorded'], row['capture_reused']) == expected
        assert row['replay'] == ('commands' if commands else 'hybrid')
        totals.update(capture_recorded=row['capture_recorded'], capture_reused=row['capture_reused'],
                      commands_calls=int(commands), hybrid_calls=int(not commands))
        used.add(key)
    return dict(tag=run['tag'], ordered_global_parity_uses=counts, planned_replay=plans,
                actual=dict(totals), all_calls_match=True)


def parts(run, rows):
    keys = ['step_seconds']
    keys += (['input_prepare_seconds', 'decode_return_seconds', 'synchronize_seconds',
              'token_access_seconds', 'sample_fastpath_seconds'] if run['arm'] == 'llama'
             else ['cold_batch_seconds', 'submit_to_token_seconds', 'submit_seconds', 'remainder_seconds'])
    return {key: sum(row[key] for row in rows) for key in keys}


def window(folder, kind):
    original = read(folder/'runs.json')
    summary = read(folder/'summary.json')
    read(folder/'inputs.json')
    cached, oneshot = kind in ('cached16', 'oneshot'), kind == 'oneshot'
    count = 15 if cached else 127 if kind == 'long' else 31
    runs = []
    for path in sorted(folder.glob('??-*.result.json')):
        tag = path.name[:-12]
        arm = tag.split('-', 1)[1]
        process = read(path)
        command = read(folder/(tag+'.command.json'))
        assert process['exit'] == 0 and not process.get('timeout', False)
        assert process['command'] == command['command']
        if arm == 'llama':
            raw = read(folder/(tag+'-peer-result.json'))
            obs = dict(loading=raw['loading'], phases=raw['phases'])
        else:
            obs = hyle(folder/(tag+'.stderr.log'))
        rows = obs['phases']
        assert [r['input_tokens'] for r in rows] == [128]+([16] if cached else [])+[1]*count
        expected_visible = [128, 144]+list(range(145, 160)) if cached else list(range(128, 129+count))
        assert [r['visible_tokens'] for r in rows] == expected_visible
        decode = rows[2 if cached else 1:]
        metrics = dict(prefill_tokens_per_second=128/rows[0]['step_seconds'],
                       full_decode_tokens_per_second=count/sum(r['step_seconds'] for r in decode),
                       stable_decode_tokens_per_second=(count-6)/sum(r['step_seconds'] for r in decode[6:]))
        if cached:
            metrics['cached_continuation_tokens_per_second'] = 16/rows[1]['step_seconds']
        run = dict(tag=tag, arm=arm, process=process, obs=obs, metrics=metrics)
        run['stages'] = dict(prefill=parts(run, rows[:1]), full_decode_total=parts(run, decode),
                             first_two_decode_total=parts(run, decode[:2]), stable_decode_total=parts(run, decode[6:]))
        if cached:
            run['stages']['continuation'] = parts(run, rows[1:2])
        old = next(r for r in original if r['tag'] == tag)
        assert [r['predicted_id'] for r in rows] == [r['predicted_id'] for r in old['observation']['phases']]
        for key, value in metrics.items():
            k = {'full_decode_tokens_per_second': 'decode_tokens_per_second',
                 'cached_continuation_tokens_per_second': 'continuation_tokens_per_second'}.get(key, key) if oneshot else key
            if k in old['metrics']:
                assert close(value, old['metrics'][k])
        runs.append(run)
    groups, checks = {}, []
    for arm in sorted({r['arm'] for r in runs}):
        arm_runs = [r for r in runs if r['arm'] == arm]
        assert len(arm_runs) == 3
        keys = ['model_load_seconds', 'startup_to_ready_seconds', 'first_token_elapsed_seconds']
        keys += ['backend_setup_seconds', 'context_prepare_seconds'] if arm == 'llama' else ['model_seconds', 'shape_prepare_seconds']
        groups[arm] = dict(run_tags=[r['tag'] for r in arm_runs],
                           TPS={k: stats([r['metrics'][k] for r in arm_runs], True) for k in arm_runs[0]['metrics']},
                           loading_seconds={k: stats(r['obs']['loading'][k] for r in arm_runs) for k in keys},
                           stage_seconds={s: {k: stats(r['stages'][s][k] for r in arm_runs)
                                              for k in arm_runs[0]['stages'][s]} for s in arm_runs[0]['stages']})
        for key, value in groups[arm]['TPS'].items():
            k = {'full_decode_tokens_per_second': 'decode_tokens_per_second',
                 'cached_continuation_tokens_per_second': 'continuation_tokens_per_second'}.get(key, key) if oneshot else key
            if k in summary['groups'][arm]:
                assert close(value['median'], summary['groups'][arm][k]['median'])
        if arm != 'llama':
            checks.extend(policy(r) for r in arm_runs)
    chosen = 'commands' if oneshot else 'auto'
    comparisons = {}
    for other in (['capture'] if oneshot else ['capture', 'llama']):
        comparisons[chosen+'_vs_'+other] = dict(
            TPS_percent={k: (v['median']/groups[other]['TPS'][k]['median']-1)*100 for k, v in groups[chosen]['TPS'].items()},
            loading_seconds_delta={k: groups[chosen]['loading_seconds'][k]['median']-groups[other]['loading_seconds'][k]['median']
                                   for k in ['model_load_seconds', 'startup_to_ready_seconds', 'first_token_elapsed_seconds']},
            complete_stage_seconds_delta={s: groups[chosen]['stage_seconds'][s]['step_seconds']['median']-groups[other]['stage_seconds'][s]['step_seconds']['median']
                                          for s in groups[chosen]['stage_seconds']})
    reference = [r['predicted_id'] for r in next(r for r in runs if r['arm'] == 'capture')['obs']['phases']]
    assert all([r['predicted_id'] for r in run['obs']['phases']] == reference for run in runs if run['arm'] != 'llama')
    return dict(processes=len(runs), all_exit_zero=True, fresh_processes_per_arm=3, decode_count=count,
                stable_count=count-6, groups=groups, comparisons=comparisons, policy_checks=checks,
                recomputed_metrics_match_stored=True, Hyle_same_window_predictions_equal=True), runs


def memory():
    summary = read(P/'memory-observations/summary.json')
    assert set(summary['arms']) == {'current', 'reference'} and all(v['exit'] == 0 for v in summary['arms'].values())
    metric_keys = ['working_set_bytes', 'os_peak_working_set_bytes', 'private_commit_bytes', 'os_peak_commit_bytes',
                   'gpu_dedicated_bytes', 'gpu_shared_bytes', 'gpu_total_bytes']
    peak_keys = ['sampled_max_working_set_bytes', 'observed_os_peak_working_set_bytes', 'sampled_max_private_commit_bytes',
                 'observed_os_peak_commit_bytes', 'sampled_peak_gpu_dedicated_bytes', 'sampled_peak_gpu_shared_bytes', 'sampled_peak_gpu_total_bytes']
    result = {}
    for arm in ('current', 'reference'):
        folder = P/'memory-observations'/arm
        raw, record, stored = read(folder/'memory.json'), read(folder/'result.json'), read(folder/'summary.json')
        assert record['exit'] == 0 and not record.get('timeout', False)
        rows = raw['samples']
        running = [r for r in rows if r.get('process_running')]
        high = {}
        for row in rows:
            for kind in ('dedicated', 'shared'):
                value, available = row['gpu_'+kind+'_bytes'], row['gpu_'+kind+'_available']
                assert (value is not None) == available
                if available:
                    instances = [v[kind] for v in row['gpu_instances'].values() if kind in v]
                    assert instances and all(v['status'] in (0, 1) and v['bytes'] >= 0 for v in instances)
                    assert sum(v['bytes'] for v in instances) == value
            total = row['gpu_dedicated_bytes']+row['gpu_shared_bytes'] if row['gpu_dedicated_available'] and row['gpu_shared_available'] else None
            assert row['gpu_total_bytes'] == total
            for key in metric_keys:
                if row.get(key) is not None:
                    high[key] = max(high.get(key, 0), row[key])
            assert high == row['observed_monotonic_peaks_bytes']
        peaks = {name: max((r[key] for r in rows if r.get(key) is not None), default=None) for name, key in zip(peak_keys, metric_keys)}
        assert peaks == raw['peaks'] == stored['peaks']
        bounds = {r['name']: r['timestamp_ns'] for r in record['markers']}
        windows = {}
        for name, begin, end in [('loading', record['popen_perf_ns'], bounds['model_loaded']),
                                 ('post_load_preparation', bounds['model_loaded'], bounds['ready_before_prefill']),
                                 ('prefill', bounds['ready_before_prefill'], bounds['prefill_complete']),
                                 ('decode31', bounds['prefill_complete'], bounds['inference_complete'])]:
            rr = [r for r in running if begin <= r['timestamp_ns'] <= end]
            byte_stats = {key: stats(r[key] for r in rr if r.get(key) is not None)
                          for key in ['working_set_bytes', 'private_commit_bytes', 'gpu_dedicated_bytes', 'gpu_shared_bytes', 'gpu_total_bytes']}
            assert len(rr) == stored['windows'][name]['sample_count']
            for key in ['working_set_bytes', 'private_commit_bytes', 'gpu_dedicated_bytes', 'gpu_shared_bytes']:
                assert all(byte_stats[key][v] == stored['windows'][name][key][v] for v in ['min', 'median', 'max'])
            windows[name] = dict(duration_ns=end-begin, running_samples=len(rr),
                                 GPU_null_running_samples=sum(r['gpu_total_bytes'] is None for r in rr), bytes=byte_stats)
        valid = [i for i, r in enumerate(rows) if r['gpu_total_bytes'] is not None]
        first, last = min(valid), max(valid)
        gaps = [(b['timestamp_ns']-a['timestamp_ns'])/1e6 for a, b in zip(running, running[1:])]
        assert close(max(gaps), stored['actual_sample_gaps_ms']['max'])
        peak = max((r for r in rows if r['gpu_total_bytes'] is not None), key=lambda r: r['gpu_total_bytes'])
        result[arm] = dict(exit=0, samples=len(rows), running_samples=len(running), GPU_valid_samples=len(valid),
                           GPU_null_samples=len(rows)-len(valid),
                           null_classification=dict(initial=sum(r['gpu_total_bytes'] is None for r in rows[:first]),
                                                    interior=sum(r['gpu_total_bytes'] is None for r in rows[first:last+1]),
                                                    trailing=sum(r['gpu_total_bytes'] is None for r in rows[last+1:])),
                           unavailable_reasons=dict(collections.Counter(r.get('gpu_'+k+'_unavailable_reason') for r in rows for k in ['dedicated', 'shared'] if not r['gpu_'+k+'_available'])),
                           PSAPI_unavailable_samples=sum(not r.get('psapi_available') for r in rows),
                           requested_interval_s=raw['requested_interval_s'], actual_sample_gaps_ms=stats(gaps),
                           collection_cost_ms=stats(r['sample_duration_ns']/1e6 for r in running),
                           gpu_setup_error=raw['gpu_setup_error'], thread_error=raw['thread_error'], reader_errors=record['reader_errors'],
                           peaks_exact_bytes=peaks, phase_windows=windows,
                           simultaneous_GPU_total_peak={k: peak[k] for k in ['timestamp_ns', 'gpu_dedicated_bytes', 'gpu_shared_bytes', 'gpu_total_bytes']})
        if arm == 'current':
            result[arm]['consumer_reported_byte_lines'] = hyle(folder/'stderr.log')['byte_lines']
    read(P/'memory-observations/inputs.json')
    return dict(scope='Two separate short128+31 memory-only processes, not cached16 or a throughput window.', arms=result,
                raw_sums_highwaters_peaks_and_summaries_match=True,
                current_minus_reference_peak_accounting_bytes={k: result['current']['peaks_exact_bytes'][k]-result['reference']['peaks_exact_bytes'][k] for k in peak_keys},
                limits=['Sampled maxima are lower bounds; exact byte counters are OS/WDDM accounting, not a physical-allocation attribution.',
                        'WorkingSet includes shared/mapped pages; PrivateUsage is commit. GPU shared can overlap CPU accounting. Do not add these categories.',
                        'Dedicated/shared maxima may be non-coincident. Only gpu_total_bytes is a simultaneous sum; PID accounting may include cross-process shared resources.',
                        'Observed OS high-water fields are process-lifetime, not phase peaks. Parent stderr receipt windows are approximate; zero-sample phases remain unknown.',
                        'Logical weights/copy bytes, loader backing/staging, known compiled storage with unknown providers, and per-slot workspace do not enumerate every allocation.'])


def main():
    report = dict(schema='hyle.d4.auto-policy.independent-measurement-review.v1', date='2026-10-21',
                  status='finite_recomputation_complete_no_goal_completion_claim', this_review=dict(builds=0, GPU_runs=0, product_or_raw_edits=0),
                  method='Independently parse original stderr/peer JSON and terminal receipts, recompute each process TPS from complete printed step seconds, compare stored results, then report per-window medians/min/max. No cross-window pooling.')
    runs = {}
    for kind in ['cached16', 'short', 'long']:
        report[kind], runs[kind] = window(P/(kind+'-timing'), kind)
    report['original_oneshot'], _ = window(S/'oneshot-replay-cost', 'oneshot')
    seq, fixed = read(S/'short-timing/runs.json'), read(S/'inputs/cached16-fixed-inputs.json')
    boundaries = []
    for run in runs['cached16']:
        arm = 'llama' if run['arm'] == 'llama' else 'current'
        old = next(r for r in seq if r['arm'] == arm)
        rows = old['observation']['phases']
        expected = [rows[0]['predicted_id']]+[rows[i]['predicted_id'] for i in range(16, 32)]
        assert [r['predicted_id'] for r in run['obs']['phases']] == expected
        assert old['observation']['raw']['decode_input_ids'] == fixed['continuation_ids']+fixed['decode_input_ids']
        boundaries.append(dict(run=run['tag'], same_arm_reference=old['tag'], matching_boundaries=17, differences=0))
    report['cached16']['same_arm_sequential_boundary_checks'] = boundaries
    old, new = read(S/'checks/link1/link-plan.json'), read(P/'checks/attempt1/link-plan.json')
    key = lambda r: (r['path'].lower(), r['bytes'], r['sha256'])
    a, b = collections.Counter(key(r) for r in old['inputs']), collections.Counter(key(r) for r in new['inputs'])
    assert len(old['inputs']) == len(new['inputs']) == 190 and sum((a & b).values()) == 189
    assert sum((a-b).values()) == sum((b-a).values()) == 1
    freeze = read(P/'source-freeze.json')
    assert hashlib.sha256(data(P/'before/main.cc')).hexdigest() == freeze['before']['sha256']
    assert hashlib.sha256(data(Path('tools/qwen35_text/main.cc'))).hexdigest() == freeze['source']['sha256']
    report['source_scope'] = dict(changed_source='tools/qwen35_text/main.cc', before_SHA256=freeze['before']['sha256'],
                                  current_SHA256=freeze['source']['sha256'], recorded_link_inputs=190,
                                  reused_identical_recorded_inputs=189, only_replaced_input='consumer main.obj',
                                  shared_Graph_Provider_API_changes=0, ready_build=dict(CXX=1, links=1, NVCC=0, SDK_builds=0),
                                  limitation='Recorded link-input identities checked; not a new SDK rebuild or binary rehash of every retained input.')
    read(P/'ready-for-root.json')
    for path in [P/'main.diff', S/'auto_replay_run.py', S/'oneshot_replay_cost.py', S/'memory_run.py', Path(__file__)]:
        data(path)
    corr = read(P/'correctness/summary.json')
    assert corr['passed'] and len(corr['vectors']) == 64
    assert all(r['byte_equal'] and r['actual']['bytes'] == r['reference']['bytes'] and r['actual']['sha256'] == r['reference']['sha256'] for r in corr['vectors'])
    assert corr['observation']['capture_counts'] == [[0, 0], [1, 0], [1, 0]]+[[0, 1]]*29
    report['recorded_default_correctness'] = dict(exit=corr['process']['exit'], recorded_equal_vector_identity_pairs_checked=64,
                                                 default_capture_counter_pattern_checked=True, no_new_GPU_or_large_vector_read=True)
    report['memory'] = memory()
    report['counts'] = dict(new_unmonitored_timing_processes=27, original_oneshot_processes=6, new_memory_only_processes=2,
                            all_terminal_exit_zero=True, fresh_processes_per_arm_per_window=3)
    report['interpretation'] = [
        'All comparisons use the same-window auto/capture/reference groups. Loading, ready, TTFT and TPS are never pooled with earlier windows or original oneshot.',
        'Cached16 auto improves versus same-window capture and exceeds reference median here. Full15 cold decode still trails reference while its nine-step stable suffix is higher. Short full31 decode is slightly lower; long decode is close. This is not universal superiority.',
        'Auto counts ordered child/global-parity uses: <=1 Commands, >1 PreferCapture. Planned and actual public Graph counters match every call. Early stop can execute fewer calls than the requested upper-bound plan.',
        'Counters cover public Graph capture ranges/hybrid replay, not every vendor internal CUDA graph. Commands can move work from prepare to submit; compare full step_seconds, not one internal bucket.',
        'Original oneshot global Commands changes both prefill and continuation and disables repeated decode capture. Its gains and losses are measured observations, not an isolated T16-only causal decomposition.',
        'Hyle cold_batch includes layout/version/batch/replay prepare/report. submit-to-token includes submit/wait/4B selected-ID read. submit_seconds is a subset. Peer decode-return has different internal boundaries.',
        'Componentwise medians need not add to median full-step latency. Printed decimal timer precision also affects small remainders. Loading sub-boundaries differ between engines.',
        'Three-process min/max ranges are observations, not confidence intervals. No statistical significance, independent quality acceptance, automatic D4 or Goal completion is declared.']
    report['source_identities'] = list(sources.values())
    path = P/'independent-measurement-review.json'
    path.write_text(json.dumps(report, ensure_ascii=False, indent=2, allow_nan=False)+'\n', encoding='utf-8')
    print(json.dumps(dict(path=str(path), bytes=path.stat().st_size, sha256=hashlib.sha256(path.read_bytes()).hexdigest(),
                          sources=len(sources), comparisons={k: report[k]['comparisons'] for k in ['cached16', 'short', 'long']},
                          memory={k: dict(samples=v['samples'], nulls=v['GPU_null_samples'], peaks=v['peaks_exact_bytes'],
                                          phases={w: t['running_samples'] for w, t in v['phase_windows'].items()})
                                  for k, v in report['memory']['arms'].items()}), indent=2))


if __name__ == '__main__':
    main()
