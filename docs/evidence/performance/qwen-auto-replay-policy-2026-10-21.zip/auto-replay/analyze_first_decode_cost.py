"""Finite read-only attribution from retained timings and two existing traces."""
from pathlib import Path
import collections,hashlib,json,re,sqlite3,statistics
P=Path(__file__).resolve().parent;D=P.parent;T=D/'cached16-trace'
def read(f):return json.loads(f.read_text(encoding='utf-8-sig'))
def ident(f):return dict(path=str(f.resolve()),bytes=f.stat().st_size,sha256=hashlib.sha256(f.read_bytes()).hexdigest())
def merged(xs):
 out=[]
 for s,e in sorted(xs):
  if out and s<=out[-1][1]:out[-1][1]=max(out[-1][1],e)
  else:out.append([s,e])
 return out
def union(xs):return sum(e-s for s,e in merged(xs))
def intervals(rows,s,e):return [(max(s,x['start']),min(e,x['end']))for x in rows]
def group(rows,s,e):
 g=collections.defaultdict(lambda:[0,0])
 for x in rows:g[x['name']][0]+=1;g[x['name']][1]+=max(0,min(e,x['end'])-max(s,x['start']))
 return sorted([dict(name=k,count=v[0],inclusive_ms=v[1]/1e6)for k,v in g.items()],key=lambda x:-x['inclusive_ms'])
workloads={}
for workload,expected in [('short',31),('long',127),('cached16',15)]:
 folder=P/(workload+'-timing');runs=read(folder/'runs.json');assert len(runs)==9
 groups=collections.defaultdict(list);records=[]
 for r in runs:
  assert r['process']['exit']==0;rows=r['observation']['phases'];indexes=[];decoded=[]
  for i,x in enumerate(rows):
   name=x.get('name','');m=re.fullmatch(r'decode(\d+)',name)
   if m:indexes.append(int(m.group(1)));decoded.append((i,x))
  if not decoded:
   assert workload!='cached16'and rows[0]['input_tokens']==128 and all(x['input_tokens']==1 for x in rows[1:])
   assert [x['phase']for x in rows]==list(range(len(rows)));indexes=list(range(1,len(rows)));decoded=list(enumerate(rows[1:],1));index_source='peer original phase ordinal with proven no-continuation shape'
  else:index_source='explicit decodeN names, independent of continuation phase offset'
  assert indexes==list(range(1,expected+1))and len(decoded)==expected
  times=[x['step_seconds']*1000 for _,x in decoded];parts=dict(first_two_ms=sum(times[:2]),decode3_to6_ms=sum(times[2:6]),decode7_to_end_ms=sum(times[6:]));total=sum(times)
  assert abs(sum(parts.values())-total)<1e-8
  captures=None
  if r['arm']!='llama':
   cc=r['observation']['capture_counts'];assert len(cc)==len(rows);captures=[dict(decode_index=j+1,phase_array_index=i,recorded=cc[i][0],reused=cc[i][1])for j,(i,_)in enumerate(decoded)]
   assert [x['recorded']for x in captures]==[1,1]+[0]*(expected-2)
   assert [x['reused']for x in captures]==[0,0]+[1]*(expected-2)
  row=dict(tag=r['tag'],arm=r['arm'],decode_count=expected,index_source=index_source,segments=parts,total_decode_ms=total,first_two_decode_ms=times[:2],capture_counts=(dict(first_two=captures[:2],tail_phase_count=expected-2,tail_recorded=sum(x['recorded']for x in captures[2:]),tail_reused=sum(x['reused']for x in captures[2:]),all_tail_records_zero_and_reuse_one=all(x['recorded']==0 and x['reused']==1 for x in captures[2:]))if captures is not None else None),process_command=str(folder/(r['tag']+'.command.json')))
  groups[r['arm']].append(row);records.append(row)
 assert set(groups)=={'capture','auto','llama'}and all(len(x)==3 for x in groups.values())
 summaries={}
 for arm,rs in groups.items():
  med=sorted(rs,key=lambda x:x['total_decode_ms'])[1];summaries[arm]=dict(processes=3,mean_segments_ms={k:statistics.mean(x['segments'][k]for x in rs)for k in parts},mean_total_ms=statistics.mean(x['total_decode_ms']for x in rs),median_total_ms=med['total_decode_ms'],whole_window_median_run=med['tag'],whole_window_median_run_segments_ms=med['segments'],independent_segment_medians_ms={k:statistics.median(x['segments'][k]for x in rs)for k in parts})
 aa=summaries['auto'];rr=summaries['llama'];delta={k:aa['mean_segments_ms'][k]-rr['mean_segments_ms'][k]for k in parts};full=aa['mean_total_ms']-rr['mean_total_ms'];assert abs(sum(delta.values())-full)<1e-8
 meddelta={k:aa['whole_window_median_run_segments_ms'][k]-rr['whole_window_median_run_segments_ms'][k]for k in parts};assert abs(sum(meddelta.values())-(aa['median_total_ms']-rr['median_total_ms']))<1e-8
 workloads[workload]=dict(raw_runs=ident(folder/'runs.json'),inputs=ident(folder/'inputs.json'),processes=9,decode_count=expected,excluded='Prefill and optional16-token continuation; this is the requested31/127/15 singleton-decode window.',processes_detail=records,arm_summaries=summaries,auto_minus_peer=dict(mean_segment_delta_ms=delta,mean_full_window_delta_ms=full,positive_front_delta_share_of_positive_full_excess=delta['first_two_ms']/full if full>0 else None,median_full_window_delta_ms=aa['median_total_ms']-rr['median_total_ms'],whole_window_median_runs_segment_delta_ms=meddelta,scope='Means provide an exact additive decomposition across the three unpaired fresh processes per arm. Whole-window median-run decomposition is separately exact; independent segment medians are not added. Positive delta means Auto took longer.'))
trace=read(T/'analysis.json');trace_review={}
for arm in ['current','llama']:
 db=T/arm/'capture.sqlite';c=sqlite3.connect(db.resolve().as_uri()+'?mode=ro',uri=True);c.row_factory=sqlite3.Row;strings={x['id']:x['value']for x in c.execute('select *from StringIds')};phases=trace['arms'][arm]['phases'];anchors=trace['arms'][arm]['host_token_mapping'];out=[]
 for name in ['decode1','decode2']:
  i=next(i for i,x in enumerate(phases)if x['name']==name);assert i>=1 and anchors[i]['name']==name and phases[i]['input_tokens']==1
  s=anchors[i-1]['host_completion_api']['end_ns'];e=anchors[i]['host_completion_api']['end_ns'];api=[dict(x,name=strings[x['nameId']])for x in c.execute('select *from CUPTI_ACTIVITY_KIND_RUNTIME where start<?and end>?order by start',(e,s))]
  ks=[dict(x)for x in c.execute('select *from CUPTI_ACTIVITY_KIND_KERNEL where start<?and end>?',(e,s))];gs=[dict(x)for x in c.execute('select *from CUPTI_ACTIVITY_KIND_GRAPH_TRACE where start<?and end>?',(e,s))]
  begin=[x for x in api if 'StreamBeginCapture'in x['name']];end=[x for x in api if 'StreamEndCapture'in x['name']];critical=[x for x in api if any(k in x['name']for k in ['BeginCapture','EndCapture','GraphInstantiate','GraphLaunch','GraphDestroy'])];sums=group(api,s,e)
  out.append(dict(name=name,phase_array_index=i,token_anchors=[anchors[i-1],anchors[i]],logged_phase=phases[i],host_token_API_envelope_ms=(e-s)/1e6,capture_recording_span_ms=(end[-1]['end']-begin[0]['start'])/1e6 if begin and end else None,critical_APIs=[dict(name=x['name'],start_from_envelope_ms=(x['start']-s)/1e6,full_duration_ms=(x['end']-x['start'])/1e6)for x in critical],capture_begin_count=len(begin),instantiate_count=sum('GraphInstantiate'in x['name']for x in api),instantiate_inclusive_ms=sum(x['end']-x['start']for x in api if 'GraphInstantiate'in x['name'])/1e6,graph_launch_count=sum('GraphLaunch'in x['name']for x in api),graph_envelopes_ms=[(x['end']-x['start'])/1e6 for x in gs],visible_kernel_count=len(ks),visible_kernel_sum_ms=sum(min(e,x['end'])-max(s,x['start'])for x in ks)/1e6,recorded_kernel_union_ms=None if gs else union(intervals(ks,s,e))/1e6,API_top=sums[:8]))
 trace_review[arm]=dict(sqlite=ident(db),model_command=trace['arms'][arm]['model_command'],scope='Existing cached16 explicit prefer-capture image2382, not the later Auto image0442. It illustrates the preserved first-use M1 paths; these instrumented durations do not quantify the unprofiled Auto gap.',first_two_M1=out,total_instantiations=sum(x['instantiate_count']for x in out),instantiate_inclusive_ms=sum(x['instantiate_inclusive_ms']for x in out))
 c.close()
result=dict(schema='hyle.auto-replay.first-decode-cost-review.v1',status='OBSERVED_FRONT_TWO_DECODE_DIFFERENCE_CONCENTRATION_NOT_A_CAPTURE_SAVINGS_PROOF',scope='Read-only decomposition of the existing27 unprofiled processes and existing two graph-level cached16 traces. No GPU/model/build/profile activity.',script=ident(Path(__file__)),workloads=workloads,existing_trace=trace_review,conclusions=[
 'Auto unprofiled logs show one recorded range on decode1 and decode2, then reuse on every decode3..end for all three workloads. The peer has no analogous unprofiled capture counter; its existing trace supplies the separate API evidence.',
 'Mean Auto-minus-peer decode31 wall excess is3.882266667ms: first two+5.840000ms, decode3..6+0.065500ms, decode7..31-2.023233333ms. The full-window loss is concentrated in the first two calls and partially offset later.',
 'Mean cached continuation-afterward decode15 excess is4.206800ms: first two+4.678400ms, decode3..6-0.467800ms, decode7..15-0.003800ms. That final group is effectively tied in the mean at this sample scale; independent medians differ and are retained.',
 'Mean decode127 total is8.720200ms faster for Auto despite first two+4.107833333ms: decode3..6-1.344366667ms and decode7..127-11.483666667ms offset the front cost.',
 'The existing explicit-capture trace records/instantiates both first M1 parity slots (two instantiations totaling3.565908ms). Peer decode1 is direct with no capture/instantiate, decode2 records one graph with1.550523ms instantiate. That establishes different first-use work, not that the2.015385ms API difference or whole cold preparation is removable.',
 'The remaining observed31/15 loss lies in actual first-two-M1 preparation/replay execution rather than a persistent decode7+ regression. Isolating its cold preparation, capture/instantiate, provider first-use and execution components is still unresolved; no alias or single-slot design conclusion follows from these data.'],limits=[
 'Three unpaired fresh processes per arm/workload, cyclic order; no statistical significance or independent model-quality claim.',
 'Positive window concentration is not causal proof that the entire capture API duration is a recoverable no-profile gain. Synchronization overlaps GPU execution, and graph-level traces hide graph-internal kernels and holes.',
 'Current trace uses the prior explicit PreferCapture image, not Auto; previous T128/T16 behavior and profiler overhead can affect first-M1 initialization. Only structural first-use counts are compared to the unprofiled Auto counters.',
 'No product/source-review edits, new sampling, native executor, alias or single-slot recommendation.'],actions=dict(GPU_runs=0,compiles=0,links=0,product_edits=0))
(P/'first-decode-capture-cost-review.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(dict(output=ident(P/'first-decode-capture-cost-review.json'),deltas={w:x['auto_minus_peer']for w,x in workloads.items()},trace={a:dict(total_instantiations=x['total_instantiations'],instantiate_inclusive_ms=x['instantiate_inclusive_ms'])for a,x in trace_review.items()}),indent=2))
