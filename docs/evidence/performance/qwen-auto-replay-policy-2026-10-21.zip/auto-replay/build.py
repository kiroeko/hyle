"""Refresh only the Qwen consumer TU against the retained190input closure; no run."""
from pathlib import Path
import importlib.util
import json
import sys

sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
D = S.parent
A = D.parent
R = A.parents[1]
spec = importlib.util.spec_from_file_location('d4_auto_existing_helpers', D / 'build.py')
h = importlib.util.module_from_spec(spec)
spec.loader.exec_module(h)
b, c = h.b, h.c


def same(row):
    return all(b.identity(row['path'])[k] == row[k] for k in ['bytes', 'sha256'])


def main():
    base_path = D / 'checks/link1/link-plan.json'
    base = c.read(base_path)
    recipe_path = D / 'checks/attempt1/main/identity.json'
    recipe = c.read(recipe_path)
    old = recipe['object']
    source = R / 'tools/qwen35_text/main.cc'
    before = S / 'before/main.cc'
    assert b.identity(before)['sha256'] == recipe['source']['sha256']
    assert len(base['inputs']) == 190 and sum(c.key(x['path']) == c.key(old['path']) for x in base['inputs']) == 1
    assert all(same(row) for row in base['inputs'])
    out = S / 'checks/attempt1'
    out.mkdir(parents=True, exist_ok=True)
    (out / 'tmp').mkdir(exist_ok=True)
    assert not (out / 'compile.result.json').exists(), 'Preserve actual attempts.'
    command = b.host_command(recipe['command'], source, 'main', out)
    assert '/WX' in command and '/W4' in command and '/MD' in command and '/O2' in command
    env, runtime = b.environment(command, [x['path'] for x in base['inputs']], out)
    c.save(out / 'compile-plan.json', dict(command=command, source=b.identity(source),
        original_recipe=b.identity(recipe_path), previous_source=b.identity(before),
        SDK_builds=0, GPU_runs=0))
    c.execute('compile', command, env, out)
    data = c.read(out / 'main-deps.json')['Data']
    dependencies = [b.identity(p) for p in dict.fromkeys([data['Source'], *data['Includes']])]
    assert all(same(row) for row in dependencies)
    snapshot = out / 'source/tools/qwen35_text/main.cc'
    snapshot.parent.mkdir(parents=True, exist_ok=True)
    snapshot.write_bytes(source.read_bytes())
    obj = b.identity(out / 'main.obj')
    c.save(out / 'identity.json', dict(command=command, source=b.identity(source), object=obj,
        dependencies=dependencies, source_dependencies=b.identity(out / 'main-deps.json'),
        source_snapshot=b.identity(snapshot), original_recipe=b.identity(recipe_path),
        replaced_object=old, SDK_builds=0, GPU_runs=0))
    image = out / 'qwen.exe'
    link = [obj['path'] if c.key(x) == c.key(old['path']) else x for x in base['command']
            if not x.upper().startswith(('/OUT:', '/MAP:', '/IMPLIB:', '/PDB:'))]
    link += ['/OUT:' + str(image), '/MAP:' + str(image.with_suffix('.map')),
             '/IMPLIB:' + str(image.with_suffix('.lib'))]
    inputs = [obj if c.key(x['path']) == c.key(old['path']) else x for x in base['inputs']]
    assert len(inputs) == 190
    c.save(out / 'link-plan.json', dict(command=link, inputs=inputs,
        base=b.identity(base_path), replaced_object=old, fresh_main=obj,
        source=b.identity(source), CXX=1, links=1, NVCC=0, SDK_builds=0, GPU_runs=0))
    env, runtime = b.environment(link, [x['path'] for x in inputs], out)
    c.execute('link', link, env, out)
    # Preserve the original dynamically loaded CPU-module staging requirement.
    import os
    modules = []
    for row in c.read(D / 'checks/link1/PE-imports-and-runtime.json')['possible_dynamic_CPU_modules']:
        original = Path(row['destination']['path'])
        target = out / original.name
        assert same(row['destination'])
        if not target.exists():
            os.link(original, target)
        assert os.path.samefile(original, target)
        modules.append(dict(source=b.identity(original), destination=b.identity(target), hardlink=True))
    c.save(out / 'runtime-environment.json', dict(PATH=env['PATH'], runtime=runtime,
        staged_CPU_modules=modules))
    c.save(S / 'source-freeze.json', dict(source=b.identity(source), before=b.identity(before),
        source_diff=b.identity(S / 'main.diff'), compile_identity=b.identity(out / 'identity.json'),
        host_plan_checks=b.identity(S / 'plan-static-checks.json'),
        changed_product_sources=['tools/qwen35_text/main.cc'],
        shared_Graph_Provider_API_changes=0))
    c.save(S / 'ready-for-root.json', dict(status='auto_consumer_compiled_and_linked_not_run',
        image=b.identity(image), link_plan=b.identity(out / 'link-plan.json'),
        runtime_environment=b.identity(out / 'runtime-environment.json'),
        source=b.identity(source), source_freeze=b.identity(S / 'source-freeze.json'),
        compile_identity=b.identity(out / 'identity.json'), previous_image=c.read(D / 'ready-for-root.json')['image'],
        CXX=1, links=1, NVCC=0, SDK_builds=0, GPU_runs=0,
        policy='Ordered requested calls cold-count each exact child/global-parity slot. Expecteduses<=1 Commands; expecteduses>1 PreferCapture. Explicit old modes override both slots.',
        limits='Generation early stop can use fewer calls than the requested upper-bound plan; no fake warmup or first execution outside original timer. Numerics/capture/performance await root execution.'))
    print('READY', image, flush=True)


if __name__ == '__main__':
    main()
