"""Publish the finite auto-replay follow-up, without rebuilding or running anything."""
from pathlib import Path
import hashlib
import json
import statistics
import zipfile
import zlib

P = Path(__file__).resolve().parent
D = P.parent
A = D.parent
R = A.parents[1]
PUBLIC = R / 'docs/evidence/performance/qwen-auto-replay-policy-2026-10-21.json'
ZIP = PUBLIC.with_suffix('.zip')
OMIT = {'.exe', '.obj', '.lib', '.exp', '.pdb', '.dll', '.map', '.bf16', '.f32', '.pyc', '.nsys-rep'}


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def identity(path):
    p = Path(path)
    h = hashlib.sha256()
    with p.open('rb') as f:
        for chunk in iter(lambda: f.read(8 << 20), b''):
            h.update(chunk)
    return dict(path=str(p), bytes=p.stat().st_size, sha256=h.hexdigest())


def encode(value):
    return (json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + '\n').encode('utf-8')


def main():
    assert not PUBLIC.exists() and not ZIP.exists(), 'Preserve prior public evidence.'
    review = P / 'independent-measurement-review.json'
    cost = P / 'first-decode-capture-cost-review.json'
    assert review.is_file() and cost.is_file(), 'Wait for both independent final reports.'
    ready = read(P / 'ready-for-root.json')
    source = R / 'tools/qwen35_text/main.cc'
    assert identity(source)['sha256'] == ready['source']['sha256'] == '667c5fc8748dbed8994e8725c4708aff8deb146ea8092328c3593ea666cb9c84'
    summaries = {}
    for name in ['short', 'long', 'cached16']:
        base = P / (name + '-timing')
        j = read(base / 'summary.json')
        rows = read(base / 'runs.json')
        assert j['passed'] and j['processes'] == 9 and len(rows) == 9
        assert all(x['process']['exit'] == 0 and not x['process']['profiler']
                   and not x['process']['memory_monitor'] for x in rows)
        summaries[name] = j
    correctness = read(P / 'correctness/summary.json')
    assert correctness['passed'] and correctness['checks']['all64_vectors_equal']
    assert len(correctness['vectors']) == 64
    memory = read(P / 'memory-observations/summary.json')
    assert all(x['exit'] == 0 and not x['timeout'] for x in memory['arms'].values())
    oneshot = read(D / 'oneshot-replay-cost/summary.json')
    oneshot_rows = read(D / 'oneshot-replay-cost/runs.json')
    assert len(oneshot_rows) == 6 and all(x['process']['exit'] == 0 for x in oneshot_rows)
    for arm in ['current', 'llama']:
        assert read(D / 'cached16-trace' / arm / 'profile.result.json')['exit'] == 0
        assert read(D / 'cached16-trace' / arm / 'export.result.json')['exit'] == 0
    trace = read(D / 'cached16-trace/analysis.json')

    payloads = {}

    def add(path, name):
        path = Path(path)
        assert path.is_file() and path.suffix.lower() not in OMIT, path
        data = path.read_bytes()
        if name in payloads:
            assert payloads[name] == data
        else:
            payloads[name] = data

    # Only explicit, completed directories; no unrelated/new diagnostics are discovered.
    for name in ['build.py', 'main.diff', 'plan-static-checks.json', 'source-freeze.json',
                 'ready-for-root.json', 'independent-review.json',
                 'independent-measurement-review.json', 'first-decode-capture-cost-review.json',
                 'review_calculate.py', 'analyze_first_decode_cost.py', 'package.py']:
        add(P / name, 'auto-replay/' + name)
    for name in ['before', 'checks/attempt1', 'revisions/plan-metadata-before',
                 'short-timing', 'long-timing', 'cached16-timing', 'memory-observations']:
        base = P / name
        assert base.is_dir(), base
        for p in sorted(base.rglob('*')):
            if p.is_file() and p.suffix.lower() not in OMIT:
                add(p, 'auto-replay/' + p.relative_to(P).as_posix())
    for name in ['qwen.command.json', 'qwen.result.json', 'qwen.stderr.log', 'qwen.stdout.log', 'summary.json']:
        add(P / 'correctness' / name, 'auto-replay/correctness/' + name)
    for p in sorted((P / 'correctness/trace/routes').glob('*.tsv')):
        add(p, 'auto-replay/' + p.relative_to(P).as_posix())
    add(D / 'hardware-observation.json', 'hardware-observation.json')
    for name in ['auto_replay_run.py', 'root_run.py', 'memory_run.py', 'trace_cached.py', 'oneshot_replay_cost.py']:
        add(D / name, 'drivers/' + name)
    for p in sorted((D / 'oneshot-replay-cost').iterdir()):
        if p.is_file() and p.suffix.lower() not in OMIT:
            add(p, 'attribution/oneshot-replay-cost/' + p.name)
    trace_root = D / 'cached16-trace'
    for name in ['plan.json', 'analysis.json', 'analyze.py']:
        add(trace_root / name, 'diagnostic/cached16-trace/' + name)
    trace_identities = []
    for arm in ['current', 'llama']:
        for p in sorted((trace_root / arm).iterdir()):
            if p.is_file() and p.suffix.lower() not in OMIT:
                add(p, 'diagnostic/cached16-trace/' + arm + '/' + p.name)
        rep = trace_root / arm / 'capture.nsys-rep'
        trace_identities.append(dict(arm=arm, omitted_nsys_rep=identity(rep),
                                     sqlite=identity(trace_root / arm / 'capture.sqlite'),
                                     nsys_rep_archived=False, sqlite_archived=True))
    payloads['diagnostic/nsys-rep-identities.json'] = encode(trace_identities)
    # Small inputs/metadata remain exact; all library source closure is referenced from the prior package.
    for name in ['cached16-fixed-inputs.json', 'continuation16.ids', 'decode-after-continuation15.ids']:
        add(D / 'inputs' / name, 'inputs/' + name)
    for name in ['qwen-gpu-comparison/128-prefill/inputs/prompt.ids',
                 'qwen-gpu-comparison/128-prefill/inputs/weights.tsv',
                 'qwen-gpu-comparison/128-prefill/decode.ids',
                 'qwen-gpu-comparison/128-prefill/fixed-inputs.json',
                 'decode-prepare-cost/long-peer/decode.ids',
                 'decode-prepare-cost/long-peer/fixed-inputs.json']:
        add(A / name, 'inputs/reference/' + name)
    payloads['vector-hashes.json'] = encode(dict(vectors=correctness['vectors'],
        payload_archived=False, count=64,
        reproduction='Original correctness command and source/input identity in auto-replay/correctness; prior qwen-current-delivery archive retains reference provenance.'))
    add(source, 'current_sources/tools/qwen35_text/main.cc')

    cached_groups = summaries['cached16']['groups']
    c = cached_groups['auto']['cached_continuation_tokens_per_second']['median']
    o = cached_groups['capture']['cached_continuation_tokens_per_second']['median']
    q = cached_groups['llama']['cached_continuation_tokens_per_second']['median']
    prior = R / 'docs/evidence/performance/qwen-current-delivery-2026-10-21.json'
    prior_zip = prior.with_suffix('.zip')
    related = [
        'qwen-current-delivery-2026-10-21.json',
        '../correctness/linux-current-package-install-2026-10-21.json',
        '../correctness/apple-current-sdk-reference-2026-10-21.json']
    assert all((PUBLIC.parent / link).resolve().is_file() for link in related)
    report = dict(
        date='2026-10-21', status='finite_auto_policy_verified_D4_remaining_short_decode_gap',
        scope='Windows RTX4070 real Qwen3.5-2B text consumer only; replay policy uses declared ordered calls and original library ReplayMode.',
        delivery4_complete=False, goal_complete=False,
        hardware=read(D/'hardware-observation.json'),
        change=dict(source=identity(source), before=identity(P/'before/main.cc'), diff=identity(P/'main.diff'),
            default='--replay auto', controls=['--replay commands', '--replay prefer-capture'],
            policy='Cold-count exact child/global-parity slot uses from prompt, optional continuation, then requested singleton calls. At most1 expected use ->Commands; more than1 ->PreferCapture.',
            cold='Family deduplicates exact shapes after counting every ordered call. Phase stores both counts and resolved per-slot modes.',
            hot='Read Phase.replay_modes[parity]; no extra map lookup/provider search, no fake warmup or moved first execution.',
            shape_or_model_special_cases=False, Graph_Provider_public_API_changes=0,
            early_stop='Requested unforced generation is an upper-bound plan; EOS may run only a prefix, so reuse can be overestimated. No hidden adaptivity is claimed.'),
        actual=dict(new_CXX=1, links=1, NVCC=0, SDK_builds=0,
            numerical_processes=1, vectors_byte_equal=64,
            unmonitored_timing_processes=dict(short=9, long=9, cached16=9, total=27),
            independent_memory_processes=2, earlier_oneshot_attribution_processes=6,
            earlier_profiled_diagnostic_processes=2, all_actual_process_exits_zero=True,
            counts_are_process_executions_not_distinct_models=True),
        result=dict(cached16=dict(auto=c, previous_capture=o, reference=q,
            auto_over_previous=c/o, throughput_gain_percent=(c/o-1)*100,
            auto_over_reference=c/q, samples='3fresh processes per arm in this same unprofiled9process window'),
            short_complete_decode=dict(auto=summaries['short']['groups']['auto']['full_decode_tokens_per_second']['median'],
                reference=summaries['short']['groups']['llama']['full_decode_tokens_per_second']['median']),
            cached_after_continuation_complete15_decode=dict(auto=cached_groups['auto']['full_decode_tokens_per_second']['median'],
                reference=cached_groups['llama']['full_decode_tokens_per_second']['median'])),
        interpretation=[
            f'T16 cached continuation improved{(c/o-1)*100:.2f}% in the same window: auto{c:.2f} vs old capture{o:.2f} vs reference{q:.2f}token/s. Default auto smoke kept all64 full hidden/logits vectors byte-equal; same-arm predicted sequences match.',
            'Short complete31-step decode still loses:103.63 vs105.22token/s. After continuation, complete15-step decode still loses:100.34 vs102.74. Do not replace these with the faster steady or longer-window metric.',
            'Long complete127-step median107.12 vs106.47 is a small finite-window advantage; it does not establish overall performance dominance or complete D4. The3auto/reference T16 sample ranges overlap; no significance is claimed.',
            'Original oneshot replay control on old2382... image supports choosing by declared reuse: global Commands improved T16 but hurt repeated decode. It changed prefill and graph history too, so it is not an isolated T16-only causal decomposition.',
            'Two pre-policy capture/reference API traces locate recording/instantiate before the one-off current T16 execution. Captured current network interiors are opaque; unlike direct peer kernel sums are not an apples-to-apples kernel-speed comparison. Inclusive API/wait sums overlap and are not removable CPU cost.',
            'Memory observations are separate1process-per-arm side samples; never mix their timings with the27unprofiled processes.'],
        measurements=summaries,
        correctness=dict(checks=correctness['checks'], summary=identity(P/'correctness/summary.json'),
            finite_numeric_regression=True, independent_model_quality_acceptance=False),
        attribution=dict(original_global_replay_control=oneshot,
            trace_summary=trace['notes'], traces=trace_identities,
            profiled_throughput_claim=False),
        remaining=dict(action='Investigate the actual complete short-decode first-call costs using the retained unprofiled samples before further policy/library changes.',
            first_decode_cost_review=identity(cost),
            first_decode_observations=read(cost)['conclusions'],
            first_decode_attribution='Still unresolved. Observed front-two concentration is not proof that all capture/instantiate duration is removable; prior trace used the older explicit-capture image.',
            independent_measurement_review=identity(review),
            not_assumed=['A single-slot problem', 'An alias failure', 'A missing public API', 'A globally optimal replay rule']),
        memory=dict(throughput_evidence=False,
            current=memory['arms']['current']['peaks'], reference=memory['arms']['reference']['peaks'],
            sample_counts={k:v['samples'] for k,v in memory['arms'].items()},
            limitations='Working set, private commit and WDDM samples are separate metrics; unavailable intervals stay null. No proven physical allocation bound, cached16-specific memory attribution or pool-completion claim.'),
        measurement_contract=dict(metric='Complete source step_seconds with unchanged token endpoint',
            Hyle='Input writes, batch/replay preparation, submit, wait,4B token read; startup/exact-family preparation separate.',
            reference='Original public backend greedy/token fastpath includes engine sampled-logit readback; no consumer CPUargmax. Intermediate F32/BF16 boundaries differ.',
            page_cache='uncontrolled', no_hidden_warmup=True, no_profiler_in_timing=True,
            statistical_significance=False, independent_quality_acceptance=False),
        metadata_correction=dict(fix='Cached ordered_chunks example now[128,16,15singleton] rather than omitting16.',
            actual_counts_or_source_or_object_changed=False,
            original_metadata_archived='auto-replay/revisions/plan-metadata-before/',
            source_review='Apple review retains its original metadata note; reviewed source667c5fc8 and executable044288dd are unchanged.'),
        build=ready, source_review=identity(P/'independent-review.json'),
        source_closure=dict(current_source_count=1, prior183source_bundle_copied=False,
            prior_report=identity(prior), prior_archive=identity(prior_zip),
            dependency_proof='Current main actual dependency identities and190input replacement plan are in this archive; all189 non-main inputs retain prior identities.'),
        related_evidence=related,
        limits=['This finite policy/workload evidence does not sign full checkpoint quality, all models/context shapes/platforms or overall D4/goal completion.',
                'No Graph/Provider/public API or tensor arithmetic changed. No new SDK, native kernel or global route priority.',
                'Binary/runtime/model identities are retained; executables/objects/SDK/weights/duplicate64vectors are not redistributed.',
                'Original nsys-rep remains at its hashed scratch path; SQLite, commands, analysis and extracted stdout/stderr are archived.'],
        cleanup='No deletion performed by this package task.')
    payloads['report.json'] = encode(report)
    manifest = [dict(member=n, bytes=len(d), sha256=hashlib.sha256(d).hexdigest(),
                     CRC32=f'{zlib.crc32(d)&0xffffffff:08x}') for n,d in sorted(payloads.items())]
    payloads['manifest.json'] = encode(dict(payloads=manifest,
        omitted='Executables/objects/libs/DLL/maps/SDK/model weights/64duplicate vectors/duplicate nsys-rep'))
    PUBLIC.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(ZIP, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for n,d in sorted(payloads.items()):
            z.writestr(n,d)
    with zipfile.ZipFile(ZIP) as z:
        assert z.testzip() is None
        for row in manifest:
            data=z.read(row['member'])
            assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256']
            assert f'{z.getinfo(row["member"]).CRC:08x}'==row['CRC32']
    report['archive']=dict(**identity(ZIP), members=len(payloads), manifest='manifest.json',
        CRC_checked=True, all_payload_SHA256_checked=True)
    PUBLIC.write_bytes(encode(report))
    print(json.dumps(dict(report=identity(PUBLIC),archive=report['archive']),ensure_ascii=False))


if __name__=='__main__':
    main()
