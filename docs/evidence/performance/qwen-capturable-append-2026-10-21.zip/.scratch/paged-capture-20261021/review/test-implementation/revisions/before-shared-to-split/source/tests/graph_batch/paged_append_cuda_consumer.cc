#include <hyle/compute/backends/cuda.h>
#include <hyle/compute/storage_owner.h>
#include <hyle/graph/batch.h>
#include <hyle/graph/cuda.h>
#include <hyle/simd/dtype.h>

#include <algorithm>
#include <array>
#include <cstdint>
#include <cstdio>
#include <span>
#include <utility>

#if !defined(HYLE_APPEND_STANDALONE)
#include <gtest/gtest.h>
#endif

namespace {
namespace c = hyle::compute;
namespace g = hyle::graph;
namespace gb = g::batch;
namespace m = hyle::mem;
using hyle::Result;
using hyle::Status;

Status require(bool value, const char *message) {
  return value ? Status::Ok() : Status::Internal(message);
}
std::uint16_t bf16(float value) { return hyle::simd::f32_to_bf16(value).bits; }

Result<c::ReadLease> upload(c::LeasePool &pool,
                          std::span<const std::uint16_t> words) {
  HYLE_ASSIGN_OR_RETURN(auto writer, pool.allocate(words.size_bytes(), 256));
  HYLE_ASSIGN_OR_RETURN(auto storage, writer.view());
  HYLE_RETURN_IF_ERROR(storage.write(std::as_bytes(words)));
  return writer.publish();
}

Status journey(const c::Context &context, const c::StorageOwner &memory,
               m::MemoryResourceRef host_workspace, c::Queue &queue,
               bool missing_dependency) {
  HYLE_ASSIGN_OR_RETURN(auto plain, c::CacheStorage::plain(c::DataType::kBFloat16));
  const c::BatchCapacity capacity{
      .query_type = c::DataType::kBFloat16,
      .output_type = c::DataType::kBFloat16,
      .key_storage = plain, .value_storage = plain,
      .max_requests = 1, .max_query_rows = 2, .max_kv_rows = 8,
      .max_pages = 6, .max_page_refs = 4,
      .query_heads = 2, .kv_heads = 1,
      .qk_head_dim = 64, .value_head_dim = 64, .page_size = 2};
  HYLE_ASSIGN_OR_RETURN(auto schema, c::BatchSchema::create(capacity));
  const std::array<std::int32_t, 2> old_query{0, 1}, next_query{0, 2};
  const std::array<std::int32_t, 2> old_indptr{0, 2}, next_indptr{0, 3};
  const std::array<std::int32_t, 2> old_ids{0, 1};
  const std::array<std::int32_t, 3> next_ids{0, 2, 3};
  const std::array<std::int32_t, 1> tail{1};
  HYLE_ASSIGN_OR_RETURN(auto old_layout,
      schema.version({old_query, old_indptr, old_ids, tail}));
  HYLE_ASSIGN_OR_RETURN(auto next_layout,
      schema.version({next_query, next_indptr, next_ids, tail}));
  HYLE_ASSIGN_OR_RETURN(auto keys, c::PagedArena::create(schema,
      c::BatchCacheRole::kKey, memory.ref(), {.max_backing_bytes = 4096}));
  HYLE_ASSIGN_OR_RETURN(auto values, c::PagedArena::create(schema,
      c::BatchCacheRole::kValue, memory.ref(), {.max_backing_bytes = 4096}));

  // Old page 1 has only its first row initialized. The unused NaN tail must
  // remain private to this old page and cannot participate in attention.
  std::array<std::uint16_t, 128> zeros{}, first_page{}, partial_page{};
  std::fill_n(first_page.begin(), 64, bf16(.125f));
  std::fill(first_page.begin() + 64, first_page.end(), bf16(.25f));
  std::fill_n(partial_page.begin(), 64, bf16(.375f));
  std::fill(partial_page.begin() + 64, partial_page.end(), std::uint16_t{0x7fc1});
  std::array<c::ReadLease, 2> old_keys, old_values;
  for (std::size_t page = 0; page < 2; ++page) {
    HYLE_ASSIGN_OR_RETURN(auto key, keys.acquire(static_cast<std::uint32_t>(page)));
    HYLE_ASSIGN_OR_RETURN(auto value, values.acquire(static_cast<std::uint32_t>(page)));
    HYLE_ASSIGN_OR_RETURN(auto key_storage, key.lease().view());
    HYLE_ASSIGN_OR_RETURN(auto value_storage, value.lease().view());
    HYLE_RETURN_IF_ERROR(key_storage.write(std::as_bytes(std::span(zeros))));
    HYLE_RETURN_IF_ERROR(value_storage.write(std::as_bytes(std::span(
        page == 0 ? first_page : partial_page))));
    HYLE_ASSIGN_OR_RETURN(old_keys[page], key.publish(page == 0 ? 2 : 1));
    HYLE_ASSIGN_OR_RETURN(old_values[page], value.publish(page == 0 ? 2 : 1));
  }
  HYLE_ASSIGN_OR_RETURN(auto previous_keys, keys.read(old_layout, old_keys));
  HYLE_ASSIGN_OR_RETURN(auto previous_values, values.read(old_layout, old_values));
  std::array<c::PagedPageWriter, 2> dirty_keys, dirty_values;
  for (std::uint32_t page = 0; page < 2; ++page) {
    HYLE_ASSIGN_OR_RETURN(dirty_keys[page], keys.acquire(page + 2));
    HYLE_ASSIGN_OR_RETURN(dirty_values[page], values.acquire(page + 2));
  }
  HYLE_ASSIGN_OR_RETURN(auto append_keys,
      gb::PagedAppendPages::create(keys, next_layout, previous_keys, dirty_keys));
  HYLE_ASSIGN_OR_RETURN(auto append_values,
      gb::PagedAppendPages::create(values, next_layout, previous_values, dirty_values));

  HYLE_ASSIGN_OR_RETURN(auto rows, c::TensorDesc::dense(c::DataType::kBFloat16,
      std::array<std::int64_t, 3>{2, 1, 64}));
  HYLE_ASSIGN_OR_RETURN(auto query_description, c::batch_query_description(capacity, 2));
  HYLE_ASSIGN_OR_RETURN(auto key_description,
      c::batch_cache_description(schema, c::BatchCacheRole::kKey));
  HYLE_ASSIGN_OR_RETURN(auto value_description,
      c::batch_cache_description(schema, c::BatchCacheRole::kValue));
  HYLE_ASSIGN_OR_RETURN(auto builder, g::GraphBuilder::create());
  HYLE_ASSIGN_OR_RETURN(auto query, builder.input(query_description));
  HYLE_ASSIGN_OR_RETURN(auto incoming_keys, builder.input(rows));
  HYLE_ASSIGN_OR_RETURN(auto incoming_values, builder.input(rows));
  HYLE_ASSIGN_OR_RETURN(auto key_bank, builder.input(key_description));
  HYLE_ASSIGN_OR_RETURN(auto value_bank, builder.input(value_description));
  // Discovery sees the original mixed DAG before logical views specialize.
  HYLE_ASSIGN_OR_RETURN(auto row_view, g::ViewSpec::reshape(std::array{
      g::Dimension::fixed(2), g::Dimension::fixed(1), g::Dimension::fixed(64)}));
  HYLE_ASSIGN_OR_RETURN(auto viewed_keys, builder.add(row_view, incoming_keys));
  HYLE_ASSIGN_OR_RETURN(auto produced_keys, builder.add(c::Copy{}, viewed_keys));
  HYLE_ASSIGN_OR_RETURN(auto produced_values, builder.add(c::Copy{}, incoming_values));
  HYLE_ASSIGN_OR_RETURN(auto key_append, gb::paged_append(schema, c::BatchCacheRole::kKey));
  HYLE_ASSIGN_OR_RETURN(auto value_append, gb::paged_append(schema, c::BatchCacheRole::kValue));
  HYLE_ASSIGN_OR_RETURN(auto key_writer,
      builder.add_node(c::Operation::custom(key_append), std::array{produced_keys}));
  HYLE_ASSIGN_OR_RETURN(auto value_writer,
      builder.add_node(c::Operation::custom(value_append), std::array{produced_values}));
  HYLE_RETURN_IF_ERROR(builder.depends_on(value_writer, key_writer));
  HYLE_ASSIGN_OR_RETURN(auto attention,
      gb::paged_attention(next_layout, {.scale = .125f, .causal = true}));
  HYLE_ASSIGN_OR_RETURN(auto reader, builder.add_node(c::Operation::custom(attention),
      std::array{query, key_bank, value_bank}));
  if (!missing_dependency) {
    HYLE_RETURN_IF_ERROR(builder.depends_on(reader, key_writer));
    HYLE_RETURN_IF_ERROR(builder.depends_on(reader, value_writer));
  }
  HYLE_ASSIGN_OR_RETURN(auto output, builder.result(reader));
  HYLE_RETURN_IF_ERROR(builder.publish(output));
  HYLE_ASSIGN_OR_RETURN(auto graph, std::move(builder).finish());
  const std::array domains{g::StorageDomain{memory.ref()}};
  HYLE_ASSIGN_OR_RETURN(auto source, g::ExecutionSource::acquire(context));
  const std::array targets{g::ExecutionTarget{source, g::StorageDomainId{0}}};
  HYLE_ASSIGN_OR_RETURN(auto compiled, gb::compile(graph,
      {.storage_domains = domains, .targets = targets}));
  HYLE_ASSIGN_OR_RETURN(auto invocation, compiled.executable.create_invocation(
      {.resources = g::ResourceOptions{}}));
  const std::array queues{g::QueueBinding{g::ExecutionLaneId{0}, &queue}};
  HYLE_RETURN_IF_ERROR(gb::prepare(invocation, queues,
      std::array{gb::NodeLayout{reader, next_layout}},
      {.host_workspace = host_workspace}));
  const auto bound = gb::bind_append(invocation, graph, key_writer, key_bank,
                                   std::move(append_keys));
  if (missing_dependency) {
    HYLE_RETURN_IF_ERROR(require(!bound.ok() && append_keys.valid(),
        "missing DAG edge accepted append or consumed its original pages"));
    HYLE_ASSIGN_OR_RETURN(auto &first, append_keys.page(0));
    HYLE_RETURN_IF_ERROR(require(first.lease().valid(),
        "missing DAG edge withdrew the caller's original writer"));
    std::puts("CUDA paged append missing dependency rejected before ownership transfer PASS");
    return Status::Ok();
  }
  HYLE_RETURN_IF_ERROR(bound);
  HYLE_RETURN_IF_ERROR(gb::bind_append(invocation, graph, value_writer, value_bank,
                                     std::move(append_values)));
  HYLE_RETURN_IF_ERROR(require(!append_keys.valid() && !append_values.valid(),
      "append bind did not transfer its page owners"));

  HYLE_ASSIGN_OR_RETURN(auto pool, c::LeasePool::create(memory.ref(), 8192,
      {.max_blocks = 8, .backing_alignment = 256}));
  std::array<std::uint16_t, 256> query_zeros{};
  std::array<std::uint16_t, 128> appended_values{};
  std::fill_n(appended_values.begin(), 64, bf16(.5f));
  std::fill(appended_values.begin() + 64, appended_values.end(), bf16(.75f));
  HYLE_ASSIGN_OR_RETURN(auto query_input, upload(pool, query_zeros));
  HYLE_ASSIGN_OR_RETURN(auto key_input, upload(pool, zeros));
  HYLE_ASSIGN_OR_RETURN(auto value_input, upload(pool, appended_values));
  HYLE_RETURN_IF_ERROR(invocation.bind(query, query_description, query_input));
  HYLE_RETURN_IF_ERROR(invocation.bind(incoming_keys, rows, key_input));
  HYLE_RETURN_IF_ERROR(invocation.bind(incoming_values, rows, value_input));
  HYLE_ASSIGN_OR_RETURN(auto output_description, c::batch_output_description(capacity, 2));
  HYLE_ASSIGN_OR_RETURN(auto destination, pool.allocate(512, 256));
  HYLE_RETURN_IF_ERROR(invocation.bind(output, output_description, std::move(destination)));
  HYLE_RETURN_IF_ERROR(invocation.prepare_replay(queues));
  HYLE_ASSIGN_OR_RETURN(auto completion, invocation.submit(queues));
  HYLE_RETURN_IF_ERROR(completion.wait());
  completion = {};
  {
    HYLE_ASSIGN_OR_RETURN(auto result, invocation.result(output));
    HYLE_ASSIGN_OR_RETURN(auto output_lease, result.storage_lease());
    HYLE_ASSIGN_OR_RETURN(auto output_storage, output_lease.view());
    std::array<std::uint16_t, 256> actual{};
    HYLE_RETURN_IF_ERROR(output_storage.read(std::as_writable_bytes(std::span(actual))));
    for (std::size_t i = 0; i < actual.size(); ++i) {
      const auto expected = bf16(i < 128 ? .3125f : .4f);
      if (actual[i] != expected) {
        std::fprintf(stderr, "CUDA append oracle index=%zu actual=%04x expected=%04x\n",
            i, unsigned(actual[i]), unsigned(expected));
        return Status::Internal("causal CUDA append attention mean differs");
      }
    }
  } // Release GraphOutput/observer before taking the retired page transactions.
  HYLE_ASSIGN_OR_RETURN(auto returned_keys, gb::take_append(invocation, key_writer));
  HYLE_ASSIGN_OR_RETURN(auto returned_values, gb::take_append(invocation, value_writer));
  {
    // A dormant recording is not page permission or a prepared transaction.
    // Taking both original writers must revoke submit until a fresh bind/prepare.
    auto stale_submit = invocation.submit(queues);
    if (stale_submit) {
      stale_submit->wait().IgnoreError(); // Retire any erroneously accepted work.
      return Status::Internal("taken append transactions still permitted submit");
    }
    HYLE_RETURN_IF_ERROR(require(stale_submit.error().IsFailedPrecondition(),
        "submit without rebound append pages did not reject its missing preparation"));
  }
  HYLE_ASSIGN_OR_RETURN(auto next_keys, returned_keys.ready());
  HYLE_ASSIGN_OR_RETURN(auto next_values, returned_values.ready());
  HYLE_RETURN_IF_ERROR(require(next_keys.layout() == next_layout &&
      next_values.layout() == next_layout && next_keys.page_count() == 3 &&
      next_values.page_count() == 3, "new ready frames do not match the exact appended layout"));
  HYLE_RETURN_IF_ERROR(require(previous_keys.layout() == old_layout &&
      previous_values.layout() == old_layout && previous_values.page_count() == 2,
      "append mutated the original snapshot layout"));
  HYLE_RETURN_IF_ERROR(require(!keys.acquire(1) && !values.acquire(1) &&
      !keys.acquire(2) && !values.acquire(2), "old or new ready pages lost their exact permissions"));
  for (std::size_t page = 0; page < 2; ++page) {
    HYLE_ASSIGN_OR_RETURN(auto old_storage, old_values[page].view());
    std::array<std::uint16_t, 128> actual{};
    HYLE_RETURN_IF_ERROR(old_storage.read(std::as_writable_bytes(std::span(actual))));
    HYLE_RETURN_IF_ERROR(require(actual == (page == 0 ? first_page : partial_page),
        "COW append changed an old snapshot byte or its unused tail"));
  }
  std::puts("CUDA ordinary Copy -> exact append/COW -> causal paged attention -> ready frames PASS");
  return Status::Ok();
}

// The metadata cases share one ordinary compiled Graph and its original
// page/lease path. Only page mappings change between these cold episodes.
struct MetadataGraph final {
  c::BatchCapacity capacity;
  c::BatchSchema schema;
  c::TensorDesc rows, query_description, output_description;
  g::Graph graph;
  g::CompiledGraph compiled;
  g::ValueId query, incoming_keys, incoming_values, key_bank, value_bank, output;
  g::NodeId key_writer, value_writer, reader;
};

Result<c::BatchLayoutVersion> metadata_layout(const c::BatchSchema &schema,
    bool next, std::uint32_t tail_page, std::uint32_t last_page = 0) {
  const std::array<std::int32_t, 2> queries{0, next ? 2 : 1};
  const std::array<std::int32_t, 2> indptr{0, next ? 3 : 2};
  const std::array<std::int32_t, 3> ids{0,
      static_cast<std::int32_t>(tail_page), static_cast<std::int32_t>(last_page)};
  const std::array<std::int32_t, 1> tail{1};
  return schema.version({queries, indptr,
      std::span(ids).first(next ? 3 : 2), tail});
}

Result<MetadataGraph> metadata_graph(const c::Context &context,
                                     const c::StorageOwner &memory) {
  MetadataGraph result;
  HYLE_ASSIGN_OR_RETURN(auto plain, c::CacheStorage::plain(c::DataType::kBFloat16));
  result.capacity = {.query_type = c::DataType::kBFloat16,
      .output_type = c::DataType::kBFloat16, .key_storage = plain, .value_storage = plain,
      .max_requests = 1, .max_query_rows = 2, .max_kv_rows = 8,
      .max_pages = 6, .max_page_refs = 4, .query_heads = 2, .kv_heads = 1,
      .qk_head_dim = 64, .value_head_dim = 64, .page_size = 2};
  HYLE_ASSIGN_OR_RETURN(result.schema, c::BatchSchema::create(result.capacity));
  HYLE_ASSIGN_OR_RETURN(auto initial, metadata_layout(result.schema, true, 2, 3));
  HYLE_ASSIGN_OR_RETURN(result.rows, c::TensorDesc::dense(c::DataType::kBFloat16,
      std::array<std::int64_t, 3>{2, 1, 64}));
  HYLE_ASSIGN_OR_RETURN(result.query_description,
      c::batch_query_description(result.capacity, 2));
  HYLE_ASSIGN_OR_RETURN(result.output_description,
      c::batch_output_description(result.capacity, 2));
  HYLE_ASSIGN_OR_RETURN(auto key_description,
      c::batch_cache_description(result.schema, c::BatchCacheRole::kKey));
  HYLE_ASSIGN_OR_RETURN(auto value_description,
      c::batch_cache_description(result.schema, c::BatchCacheRole::kValue));
  HYLE_ASSIGN_OR_RETURN(auto builder, g::GraphBuilder::create());
  HYLE_ASSIGN_OR_RETURN(result.query, builder.input(result.query_description));
  HYLE_ASSIGN_OR_RETURN(result.incoming_keys, builder.input(result.rows));
  HYLE_ASSIGN_OR_RETURN(result.incoming_values, builder.input(result.rows));
  HYLE_ASSIGN_OR_RETURN(result.key_bank, builder.input(key_description));
  HYLE_ASSIGN_OR_RETURN(result.value_bank, builder.input(value_description));
  HYLE_ASSIGN_OR_RETURN(auto produced_keys, builder.add(c::Copy{}, result.incoming_keys));
  HYLE_ASSIGN_OR_RETURN(auto produced_values, builder.add(c::Copy{}, result.incoming_values));
  HYLE_ASSIGN_OR_RETURN(auto key_append, gb::paged_append(result.schema, c::BatchCacheRole::kKey));
  HYLE_ASSIGN_OR_RETURN(auto value_append, gb::paged_append(result.schema, c::BatchCacheRole::kValue));
  HYLE_ASSIGN_OR_RETURN(result.key_writer,
      builder.add_node(c::Operation::custom(key_append), std::array{produced_keys}));
  HYLE_ASSIGN_OR_RETURN(result.value_writer,
      builder.add_node(c::Operation::custom(value_append), std::array{produced_values}));
  HYLE_RETURN_IF_ERROR(builder.depends_on(result.value_writer, result.key_writer));
  HYLE_ASSIGN_OR_RETURN(auto attention,
      gb::paged_attention(initial, {.scale = .125f, .causal = true}));
  HYLE_ASSIGN_OR_RETURN(result.reader, builder.add_node(c::Operation::custom(attention),
      std::array{result.query, result.key_bank, result.value_bank}));
  HYLE_RETURN_IF_ERROR(builder.depends_on(result.reader, result.key_writer));
  HYLE_RETURN_IF_ERROR(builder.depends_on(result.reader, result.value_writer));
  HYLE_ASSIGN_OR_RETURN(result.output, builder.result(result.reader));
  HYLE_RETURN_IF_ERROR(builder.publish(result.output));
  HYLE_ASSIGN_OR_RETURN(result.graph, std::move(builder).finish());
  const std::array domains{g::StorageDomain{memory.ref()}};
  HYLE_ASSIGN_OR_RETURN(auto source, g::ExecutionSource::acquire(context));
  const std::array targets{g::ExecutionTarget{source, g::StorageDomainId{0}}};
  HYLE_ASSIGN_OR_RETURN(result.compiled, gb::compile(result.graph,
      {.storage_domains = domains, .targets = targets}));
  return result;
}

struct MetadataPages final {
  c::PagedArena keys, values;
  std::array<c::ReadLease, 2> old_keys, old_values;
  c::ReadLease decoy;
  c::PagedArenaRead previous_keys, previous_values;
  float scale = 1;
};

Result<MetadataPages> metadata_pages(const MetadataGraph &graph,
    const c::StorageOwner &memory, float scale, bool different_old_tail = false) {
  MetadataPages result;
  result.scale = scale;
  HYLE_ASSIGN_OR_RETURN(result.keys, c::PagedArena::create(graph.schema,
      c::BatchCacheRole::kKey, memory.ref(), {.max_backing_bytes = 4096}));
  HYLE_ASSIGN_OR_RETURN(result.values, c::PagedArena::create(graph.schema,
      c::BatchCacheRole::kValue, memory.ref(), {.max_backing_bytes = 4096}));
  std::array<std::uint16_t, 128> zeros{}, words{};
  for (std::uint32_t ordinal = 0; ordinal < 2; ++ordinal) {
    HYLE_ASSIGN_OR_RETURN(auto key, result.keys.acquire(ordinal));
    const auto value_id = ordinal == 1 && different_old_tail ? 4u : ordinal;
    HYLE_ASSIGN_OR_RETURN(auto value, result.values.acquire(value_id));
    HYLE_ASSIGN_OR_RETURN(auto key_storage, key.lease().view());
    HYLE_ASSIGN_OR_RETURN(auto value_storage, value.lease().view());
    HYLE_RETURN_IF_ERROR(key_storage.write(std::as_bytes(std::span(zeros))));
    std::fill_n(words.begin(), 64, bf16((ordinal == 0 ? .125f : .375f) * scale));
    std::fill(words.begin() + 64, words.end(),
        ordinal == 0 ? bf16(.25f * scale) : std::uint16_t{0x7fc1});
    HYLE_RETURN_IF_ERROR(value_storage.write(std::as_bytes(std::span(words))));
    HYLE_ASSIGN_OR_RETURN(result.old_keys[ordinal], key.publish(ordinal == 0 ? 2 : 1));
    HYLE_ASSIGN_OR_RETURN(result.old_values[ordinal], value.publish(ordinal == 0 ? 2 : 1));
  }
  if (different_old_tail) {
    // Wrongly sharing K's source-page1 instructions with V must read a
    // deterministic wrong value rather than relying on uninitialized memory.
    HYLE_ASSIGN_OR_RETURN(auto decoy, result.values.acquire(1));
    HYLE_ASSIGN_OR_RETURN(auto storage, decoy.lease().view());
    words.fill(bf16(1.375f * scale));
    HYLE_RETURN_IF_ERROR(storage.write(std::as_bytes(std::span(words))));
    HYLE_ASSIGN_OR_RETURN(result.decoy, decoy.publish(2));
  }
  HYLE_ASSIGN_OR_RETURN(auto key_layout, metadata_layout(graph.schema, false, 1));
  HYLE_ASSIGN_OR_RETURN(auto value_layout,
      metadata_layout(graph.schema, false, different_old_tail ? 4u : 1u));
  HYLE_ASSIGN_OR_RETURN(result.previous_keys, result.keys.read(key_layout, result.old_keys));
  HYLE_ASSIGN_OR_RETURN(result.previous_values, result.values.read(value_layout, result.old_values));
  return result;
}

struct MetadataRun final {
  c::LeasePool pool;
  g::Invocation invocation;
  c::ReadLease query, keys, values;
};

Result<MetadataRun> metadata_run(const MetadataGraph &graph,
    const c::StorageOwner &memory, float scale) {
  MetadataRun result;
  HYLE_ASSIGN_OR_RETURN(result.invocation, graph.compiled.executable.create_invocation(
      {.resources = g::ResourceOptions{}}));
  HYLE_ASSIGN_OR_RETURN(result.pool, c::LeasePool::create(memory.ref(), 8192,
      {.max_blocks = 8, .backing_alignment = 256}));
  std::array<std::uint16_t, 256> query{};
  std::array<std::uint16_t, 128> keys{}, values{};
  std::fill_n(values.begin(), 64, bf16(.5f * scale));
  std::fill(values.begin() + 64, values.end(), bf16(.75f * scale));
  HYLE_ASSIGN_OR_RETURN(result.query, upload(result.pool, query));
  HYLE_ASSIGN_OR_RETURN(result.keys, upload(result.pool, keys));
  HYLE_ASSIGN_OR_RETURN(result.values, upload(result.pool, values));
  HYLE_RETURN_IF_ERROR(result.invocation.bind(graph.query, graph.query_description, result.query));
  HYLE_RETURN_IF_ERROR(result.invocation.bind(graph.incoming_keys, graph.rows, result.keys));
  HYLE_RETURN_IF_ERROR(result.invocation.bind(graph.incoming_values, graph.rows, result.values));
  HYLE_ASSIGN_OR_RETURN(auto destination, result.pool.allocate(512, 256));
  HYLE_RETURN_IF_ERROR(result.invocation.bind(graph.output, graph.output_description,
                                           std::move(destination)));
  return result;
}

Status prepare_metadata_episode(const MetadataGraph &graph, MetadataRun &run,
    MetadataPages &pages, m::MemoryResourceRef host_workspace,
    std::span<const g::QueueBinding> queues, c::BatchLayoutVersion layout,
    std::uint32_t first_page, bool expect_reuse) {
  std::array<c::PagedPageWriter, 2> dirty_keys, dirty_values;
  std::array<std::uint16_t, 128> poison;
  poison.fill(0x7fc1);
  for (std::uint32_t i = 0; i < 2; ++i) {
    HYLE_ASSIGN_OR_RETURN(dirty_keys[i], pages.keys.acquire(first_page + i));
    HYLE_ASSIGN_OR_RETURN(dirty_values[i], pages.values.acquire(first_page + i));
    HYLE_ASSIGN_OR_RETURN(auto key, dirty_keys[i].lease().view());
    HYLE_ASSIGN_OR_RETURN(auto value, dirty_values[i].lease().view());
    HYLE_RETURN_IF_ERROR(key.write(std::as_bytes(std::span(poison))));
    HYLE_RETURN_IF_ERROR(value.write(std::as_bytes(std::span(poison))));
  }
  HYLE_ASSIGN_OR_RETURN(auto append_keys, gb::PagedAppendPages::create(
      pages.keys, layout, pages.previous_keys, dirty_keys));
  HYLE_ASSIGN_OR_RETURN(auto append_values, gb::PagedAppendPages::create(
      pages.values, layout, pages.previous_values, dirty_values));
  HYLE_RETURN_IF_ERROR(gb::prepare(run.invocation, queues,
      std::array{gb::NodeLayout{graph.reader, layout}}, {.host_workspace = host_workspace}));
  HYLE_RETURN_IF_ERROR(gb::bind_append(run.invocation, graph.graph, graph.key_writer,
      graph.key_bank, std::move(append_keys)));
  HYLE_RETURN_IF_ERROR(gb::bind_append(run.invocation, graph.graph, graph.value_writer,
      graph.value_bank, std::move(append_values)));
  HYLE_RETURN_IF_ERROR(run.invocation.prepare_replay(queues,
      {.mode = g::ReplayMode::kRequireCapture}));
  HYLE_ASSIGN_OR_RETURN(auto report, run.invocation.replay_report());
  HYLE_RETURN_IF_ERROR(require(report.route == g::ReplayRoute::kCaptured,
      "metadata append did not use the original captured Graph"));
  HYLE_RETURN_IF_ERROR(require(expect_reuse
      ? report.recorded_capture_range_count == 0 && report.reused_capture_range_count > 0
      : report.recorded_capture_range_count > 0 && report.reused_capture_range_count == 0,
      "metadata append capture recording/reuse did not match this episode"));
  return Status::Ok();
}

Result<std::array<c::PagedArenaRead, 2>> finish_metadata_episode(
    const MetadataGraph &graph, MetadataRun &run, MetadataPages &pages,
    std::span<const g::QueueBinding> queues, c::BatchLayoutVersion layout) {
  HYLE_ASSIGN_OR_RETURN(auto done, run.invocation.submit(queues));
  HYLE_RETURN_IF_ERROR(done.wait()); done = {};
  {
    HYLE_ASSIGN_OR_RETURN(auto result, run.invocation.result(graph.output));
    HYLE_ASSIGN_OR_RETURN(auto lease, result.storage_lease());
    HYLE_ASSIGN_OR_RETURN(auto storage, lease.view());
    std::array<std::uint16_t, 256> actual{};
    HYLE_RETURN_IF_ERROR(storage.read(std::as_writable_bytes(std::span(actual))));
    for (std::size_t i = 0; i < actual.size(); ++i)
      HYLE_RETURN_IF_ERROR(require(actual[i] == bf16((i < 128 ? .3125f : .4f) * pages.scale),
          "dynamic append metadata read the wrong source/target page"));
  }
  HYLE_ASSIGN_OR_RETURN(auto keys, gb::take_append(run.invocation, graph.key_writer));
  HYLE_ASSIGN_OR_RETURN(auto values, gb::take_append(run.invocation, graph.value_writer));
  auto stale = run.invocation.submit(queues);
  if (stale) {
    stale->wait().IgnoreError();
    return std::unexpected(Status::Internal("taken metadata append still allowed submit"));
  }
  HYLE_RETURN_IF_ERROR(require(stale.error().IsFailedPrecondition(),
      "taken metadata append did not revoke preparation"));
  std::array<c::PagedArenaRead, 2> ready;
  HYLE_ASSIGN_OR_RETURN(ready[0], keys.ready());
  HYLE_ASSIGN_OR_RETURN(ready[1], values.ready());
  HYLE_RETURN_IF_ERROR(require(ready[0].layout() == layout && ready[1].layout() == layout,
      "metadata append published a stale layout"));
  HYLE_ASSIGN_OR_RETURN(auto old_storage, pages.old_values[1].view());
  std::array<std::uint16_t, 128> old{};
  HYLE_RETURN_IF_ERROR(old_storage.read(std::as_writable_bytes(std::span(old))));
  for (std::size_t i = 0; i < old.size(); ++i)
    HYLE_RETURN_IF_ERROR(require(old[i] == (i < 64 ? bf16(.375f * pages.scale) : 0x7fc1),
        "metadata append changed the retained old partial page"));
  return ready;
}

Status metadata_mapping_journey(const c::Context &context,
    const c::StorageOwner &memory, m::MemoryResourceRef host_workspace, c::Queue &queue) {
  HYLE_ASSIGN_OR_RETURN(auto graph, metadata_graph(context, memory));
  const std::array queues{g::QueueBinding{g::ExecutionLaneId{0}, &queue}};
  HYLE_ASSIGN_OR_RETURN(auto pages, metadata_pages(graph, memory, 1));
  HYLE_ASSIGN_OR_RETURN(auto run, metadata_run(graph, memory, 1));
  HYLE_ASSIGN_OR_RETURN(auto first, metadata_layout(graph.schema, true, 2, 3));
  HYLE_RETURN_IF_ERROR(prepare_metadata_episode(graph, run, pages, host_workspace,
      queues, first, 2, false));
  HYLE_ASSIGN_OR_RETURN(auto retained_first,
      finish_metadata_episode(graph, run, pages, queues, first));
  HYLE_ASSIGN_OR_RETURN(auto second, metadata_layout(graph.schema, true, 4, 5));
  HYLE_RETURN_IF_ERROR(prepare_metadata_episode(graph, run, pages, host_workspace,
      queues, second, 4, true));
  HYLE_ASSIGN_OR_RETURN(auto retained_second,
      finish_metadata_episode(graph, run, pages, queues, second));
  HYLE_RETURN_IF_ERROR(require(retained_first[0].layout() == first &&
      retained_first[1].layout() == first && retained_second[0].layout() == second,
      "metadata replay replaced the retained prior ready frame"));
  HYLE_RETURN_IF_ERROR(require(!pages.keys.acquire(2) && !pages.values.acquire(2),
      "metadata replay released the retained first ready page"));
  std::puts("CUDA append dynamic target IDs keep capture and both old/new ready frames PASS");
  {
    HYLE_ASSIGN_OR_RETURN(auto different_pages, metadata_pages(graph, memory, 1, true));
    HYLE_ASSIGN_OR_RETURN(auto different_run, metadata_run(graph, memory, 1));
    HYLE_RETURN_IF_ERROR(prepare_metadata_episode(graph, different_run, different_pages,
        host_workspace, queues, first, 2, false));
    HYLE_ASSIGN_OR_RETURN(auto ready,
        finish_metadata_episode(graph, different_run, different_pages, queues, first));
    HYLE_RETURN_IF_ERROR(require(ready[0].valid() && ready[1].valid(),
        "different old-tail mappings did not publish their actual frames"));
  }
  std::puts("CUDA append same target layout distinguishes K/V old-tail source mappings PASS");
  return Status::Ok();
}

Status metadata_slot_journey(const c::Context &context,
    const c::StorageOwner &memory, m::MemoryResourceRef host_workspace, c::Queue &queue) {
  HYLE_ASSIGN_OR_RETURN(auto graph, metadata_graph(context, memory));
  const std::array queues{g::QueueBinding{g::ExecutionLaneId{0}, &queue}};
  HYLE_ASSIGN_OR_RETURN(auto pages_a, metadata_pages(graph, memory, 1));
  HYLE_ASSIGN_OR_RETURN(auto pages_b, metadata_pages(graph, memory, 2));
  HYLE_ASSIGN_OR_RETURN(auto run_a, metadata_run(graph, memory, 1));
  HYLE_ASSIGN_OR_RETURN(auto run_b, metadata_run(graph, memory, 2));
  HYLE_ASSIGN_OR_RETURN(auto layout_a, metadata_layout(graph.schema, true, 2, 3));
  HYLE_ASSIGN_OR_RETURN(auto layout_b, metadata_layout(graph.schema, true, 4, 5));
  HYLE_RETURN_IF_ERROR(prepare_metadata_episode(graph, run_a, pages_a, host_workspace,
      queues, layout_a, 2, false));
  HYLE_RETURN_IF_ERROR(prepare_metadata_episode(graph, run_b, pages_b, host_workspace,
      queues, layout_b, 4, false));
  // Both metadata uploads/captures precede either real submit. A global or
  // Executable-shared descriptor mirror would now make at least A incorrect.
  HYLE_ASSIGN_OR_RETURN(auto ready_a,
      finish_metadata_episode(graph, run_a, pages_a, queues, layout_a));
  HYLE_ASSIGN_OR_RETURN(auto ready_b,
      finish_metadata_episode(graph, run_b, pages_b, queues, layout_b));
  HYLE_RETURN_IF_ERROR(require(ready_a[0].layout() == layout_a &&
      ready_b[0].layout() == layout_b, "append metadata leaked between Invocations"));
  std::puts("CUDA append two prepared Invocations retain independent device metadata PASS");
  return Status::Ok();
}

Status all(int profile = 0) {
  HYLE_ASSIGN_OR_RETURN(auto context, g::cuda::create_context());
  HYLE_ASSIGN_OR_RETURN(auto device,
      c::cuda::MemoryResource::create(context, c::cuda::MemoryKind::kDevice));
  HYLE_ASSIGN_OR_RETURN(auto memory, c::StorageOwner::adopt(context, std::move(device)));
  HYLE_ASSIGN_OR_RETURN(auto staging,
      c::cuda::MemoryResource::create(context, c::cuda::MemoryKind::kPinnedHost));
  HYLE_ASSIGN_OR_RETURN(auto queue, context.create_queue());
  struct Drain {
    c::Context &context;
    ~Drain() { context.drain().IgnoreError(); }
  } drain{context};
  if (profile == 0) {
    HYLE_RETURN_IF_ERROR(journey(context, memory, staging.ref(), queue, true));
    return journey(context, memory, staging.ref(), queue, false);
  }
  if (profile == 1)
    return metadata_mapping_journey(context, memory, staging.ref(), queue);
  return metadata_slot_journey(context, memory, staging.ref(), queue);
}
} // namespace

#if defined(HYLE_APPEND_STANDALONE)
int main() {
  std::setvbuf(stdout, nullptr, _IONBF, 0);
  for (int profile = 0; profile < 3; ++profile) {
    const auto result = all(profile);
    if (!result.ok()) {
      char text[1024]{};
      result.ToString(text, sizeof(text));
      std::fprintf(stderr, "%s\n", text);
      return 1;
    }
  }
  return 0;
}
#else
TEST(CudaPagedAppend, OriginalDevicePagesAndSameGraphProof) {
  const auto result = all();
  EXPECT_TRUE(result.ok()) << result.message();
}
TEST(CudaPagedAppend, CapturedMetadataChangesPageMappings) {
  const auto result = all(1);
  EXPECT_TRUE(result.ok()) << result.message();
}
TEST(CudaPagedAppend, InvocationMetadataStaysIndependent) {
  const auto result = all(2);
  EXPECT_TRUE(result.ok()) << result.message();
}
#endif
