"""Host-only comparison of completed consumers. Never invokes builds or inference."""
from pathlib import Path
from array import array
from collections import Counter
import hashlib,json,os,sys
R=Path.cwd(); C=R/'.scratch/paged-capture-20261021'; N=R/'.scratch/paged-native-cost-20261021'; O=C/'review'
def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def identity(p):
 p=Path(p);b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def norm(p):return os.path.normcase(os.path.normpath(str(p)))
def verify(x):
 a=identity(x['path']);assert a['bytes']==x['bytes'] and a['sha256']==x['sha256'],(a,x);return a

def stable(x):
 if isinstance(x,dict):return{k:stable(v)for k,v in x.items()if k!='seconds'and not k.endswith('_seconds')}
 if isinstance(x,list):return[stable(v)for v in x]
 return x

def normalized_argv(c):
 c=list(c);c[0]='EXE';c[c.index('--trace')+1]='TRACE';return c
ready=read(C/'qwen-ready-attempt3.json'); old_ready=read(N/'qwen-ready-attempt1.json')
verify(ready['image']);verify(old_ready['image']);verify(ready['source']);assert ready['source']['sha256']=='440220ee2b4c38575765d3617127f275ca932e2a8e25d37d7e5baf4e463bbdd9'
assert ready['source']==old_ready['source']
for row in ready['fresh_sources']:verify(row)
freeze_path=C/'implementation/source-freeze.json';freeze=read(freeze_path)
assert identity(freeze_path)['sha256']=='1854e7f797907818e24a287cef82d8c84807529aa56e5e8a156ed465aafb1f76'
for row in freeze['files']:verify(row)
verify(ready['link_plan']);verify(old_ready['link_plan'])
new_plan=read(ready['link_plan']['path']);old_plan=read(old_ready['link_plan']['path'])
def ikey(x):return(norm(x['path']),x['bytes'],x['sha256'])
a={ikey(x):x for x in new_plan['inputs']};b={ikey(x):x for x in old_plan['inputs']}
assert len(a)==len(new_plan['inputs'])==195 and len(b)==len(old_plan['inputs'])==192
same=a.keys()&b.keys();removed=b.keys()-a.keys();added=a.keys()-b.keys()
assert len(same)==188 and len(removed)==4 and len(added)==7
replacements=new_plan['replaced_inputs'];new_objects=new_plan['added_inputs']
assert len(replacements)==4 and len(new_objects)==3
assert{ikey(x['before'])for x in replacements}==removed
assert{ikey(x['after'])for x in replacements}|{ikey(x)for x in new_objects}==added
assert[ikey(x)for x in new_plan['inputs']if ikey(x)in same]==[ikey(x)for x in old_plan['inputs']if ikey(x)in same]
compiled=[]
for row in [*[x['after']for x in replacements],*new_objects]:
 verify(row);ip=Path(row['path']).parent/'identity.json';record=read(ip);assert ikey(record['object'])==ikey(row);verify(record['source'])
 compiled.append(dict(identity=identity(ip),source=record['source'],object=record['object']))
assert{(norm(x['source']['path']),x['source']['sha256'])for x in compiled}=={(norm(x['path']),x['sha256'])for x in ready['fresh_sources']}
assert len(ready['fresh_sources'])==7
assert sys.byteorder=='little'
finite={'bf16_elements':0,'f32_elements':0,'nonfinite_elements':0}
def compare_tensor(actual,baseline):
 aa,bb=Path(actual).read_bytes(),Path(baseline).read_bytes();assert aa==bb,(actual,baseline)
 typ='H'if str(actual).endswith('.bf16')else'I';mask=0x7f80 if typ=='H'else 0x7f800000
 values=array(typ);values.frombytes(aa);nonfinite=sum((v&mask)==mask for v in values);assert nonfinite==0
 finite['bf16_elements'if typ=='H'else'f32_elements']+=len(values);finite['nonfinite_elements']+=nonfinite
 return dict(actual=identity(actual),baseline=identity(baseline),byte_equal=True,elements=len(values),nonfinite=nonfinite)
cases={};total=0
for name,expected in [('main-run1',22),('pressure-run1',30)]:
 cur,old=C/name,N/name;new_receipt,old_receipt=read(cur/'result.json'),read(old/'result.json')
 assert new_receipt['exit']==old_receipt['exit']==0
 assert new_receipt['image']==ready['image']and old_receipt['image']==old_ready['image']
 assert normalized_argv(new_receipt['command'])==normalized_argv(old_receipt['command'])
 x,y=read(cur/'observation.json'),read(old/'observation.json');assert stable(x)==stable(y)
 actual={p.relative_to(cur/'trace').as_posix():p for p in(cur/'trace').rglob('*')if p.name in('hidden.bf16','logits.f32')}
 baseline={p.relative_to(old/'trace').as_posix():p for p in(old/'trace').rglob('*')if p.name in('hidden.bf16','logits.f32')}
 assert actual.keys()==baseline.keys()and len(actual)==expected
 pairs=[{'relative':rel,**compare_tensor(actual[rel],baseline[rel])}for rel in sorted(actual)]
 hits=[]
 for p in(cur/'trace').rglob('cache-hit.json'):
  rel=p.relative_to(cur/'trace');ref=old/'trace'/rel;v=read(p);assert v==read(ref)
  assert v['graph_calls']==0 and v['tensor_payload_available']is False
  assert not(p.parent/'hidden.bf16').exists()and not(p.parent/'logits.f32').exists()
  hits.append(dict(actual=identity(p),baseline=identity(ref),contents=v))
 cases[name]=dict(new_result=identity(cur/'result.json'),old_result=identity(old/'result.json'),new_observation=identity(cur/'observation.json'),old_observation=identity(old/'observation.json'),same_command_except_image_trace_path=True,all_non_timing_observation_fields_equal=True,decision_vectors=len(pairs),pairs=pairs,cache_hit_metadata=hits,
 statistics={k:x[k]for k in['session_count','processed_tokens','generated_tokens','actual_graph_calls','actual_graph_tokens','prefix_hits','prefix_misses','prefix_full_hits','reused_tokens','cache_shared_backing_bytes','cache_live_snapshot_versions','cache_peak_committed_versions','cache_committed_version_limit','prefix_entries','prefix_evictions','dispatch_session_ids','evicted_session_ids']},
 sessions=[{k:v[k]for k in['session_id','visible_tokens','generated_ids','actual_graph_calls','actual_graph_tokens','restored_calls','restored_tokens','prefix_hits','prefix_misses','prefix_full_hits','reused_tokens']}|{'phase_contexts':[{k:p[k]for k in['turn','kind','name','input_tokens','calls','context_before','context_after']}for p in v['phases']]}for v in x['sessions']])
 total+=len(pairs)
assert total==52
canonical={}
for name,expected in[('single-run1',18),('multi-run1',72)]:
 cur=C/name;summary=read(cur/'summary.json');receipt=read(cur/'result.json');obs=read(cur/'observation.json')
 assert receipt['exit']==0 and receipt['image']==ready['image'] and summary['passed']is True and summary['vector_count']==expected
 if 'pairs'in summary:groups={'alice':summary['pairs']}
 else:groups=summary['sessions']
 verified=[];sessions=[]
 for sid,pairs in groups.items():
  baseline_dir=R/'.scratch/multi-session-20261021/attempt2/baseline'/sid
  base_observation=read(baseline_dir/'observation.json');assert read(baseline_dir/'result.json')['exit']==0
  session_obs=obs if name=='single-run1'else next(x for x in obs['sessions']if x['session_id']==sid)
  base_stable=stable(base_observation);assert{k:stable(session_obs[k])for k in base_stable}==base_stable
  for pair in pairs:
   assert pair['byte_equal']is True;verify(pair['actual']);verify(pair['baseline'])
   actual=Path(pair['actual']['path']);baseline=Path(pair['baseline']['path'])
   assert actual.is_relative_to(cur/'trace')and baseline.is_relative_to(baseline_dir/'trace')
   verified.append({'session':sid,'vector':pair['vector'],**compare_tensor(actual,baseline)})
  sessions.append(dict(session_id=sid,baseline_observation=identity(baseline_dir/'observation.json'),original_non_timing_fields_equal=True,visible_tokens=session_obs['visible_tokens'],generated_ids=session_obs['generated_ids'],phase_contexts=[{k:p[k]for k in['turn','kind','name','input_tokens','calls','context_before','context_after']}for p in session_obs['phases']]))
 assert len(verified)==expected
 digest=hashlib.sha256(json.dumps(verified,sort_keys=True).encode()).hexdigest()
 canonical[name]=dict(receipt=identity(cur/'result.json'),summary=identity(cur/'summary.json'),observation=identity(cur/'observation.json'),passed=True,decision_vectors=len(verified),raw_pairs_independently_reread=True,verified_pair_identities_digest_sha256=digest,sessions=sessions,
   statistics={k:obs[k]for k in ['processed_tokens','generated_tokens','actual_graph_calls','actual_graph_tokens','cache_shared_backing_bytes','cache_live_snapshot_versions','cache_peak_committed_versions','cache_committed_version_limit']})
 total+=len(verified)
assert total==142
assert finite=={'bf16_elements':145408,'f32_elements':17630720,'nonfinite_elements':0}
report=dict(status='Host-only comparison PASS:52newprefix/pressure vectors match N, plus90canonical vectors match their original independent-process same-partition baselines. All142actual vector files are byte-identical and finite.',ready=identity(C/'qwen-ready-attempt3.json'),image=ready['image'],source=ready['source'],source_freeze=identity(freeze_path),source_review=identity(O/'common-review.json'),old_ready=identity(N/'qwen-ready-attempt1.json'),old_image=old_ready['image'],script=identity(__file__),
 closure=dict(new_input_count=195,baseline_input_count=192,unchanged_input_count=188,changed_existing_objects=4,new_objects=3,replacements=replacements,added_inputs=new_objects,fresh_product_sources=ready['fresh_sources'],actual_object_source_bindings=compiled,actual_input_order_of_unchanged_188_preserved=True,new_link_plan=ready['link_plan'],old_link_plan=old_ready['link_plan'],limits='Stored188unchanged input identities independently matched between actual plans; changed/new7objects and their7source identities were hashed from disk. This is not an all195dependency or installed-package revalidation.'),cases=cases,canonical=canonical,total_decision_vectors=total,prefix_and_pressure_vectors=52,canonical_vectors=90,finite_counts=finite,all_byte_equal=True,
 limits=['No new model process, GPU query, build, link or source modification. Original N reports/scripts/vectors and canonical baselines were read only.','142 counts actual vector artifacts across four processes; they are not142distinct mathematical inputs or models. Alice canonical inputs repeat in single and multi contexts.','Only actual hidden.bf16/logits.f32 decision tensors count. Route TSV and cache-hit metadata are not vectors. Full-hit publishes no fake tensor payload and has0Graph calls.','All non-time observations are equal for the two new-vs-Ncases, including IDs,dispatch,phase contexts,prefix hits/misses/full-hit,actualGraphwork,restore,evictions and committed/globalbacking counters.','Canonical summaries were bound to ready3 and independently checked by reading their actual+originalbaseline bytes and original common non-time observation fields, without demanding equality of later cache-policy counters absent in the oldbaseline.','This signs finite same-partition regression, not independent modelquality, all-layerstatebitidentity, asynchronous preemption, concurrency throughput, performance improvement or physicalGPU memory peak.','The earlier cuda-run1 failure and corrected view-before-F1 sequence remain explicitly preserved in common-review.json and original raw receipts; these numerical successes do not erase that first-red history.'])
p=O/'runtime-comparison.json';p.write_text(json.dumps(report,indent=2,allow_nan=False)+'\n',encoding='utf-8')
print(json.dumps(dict(report=identity(p),total_vectors=total,finite=finite,closure={k:report['closure'][k]for k in['new_input_count','baseline_input_count','unchanged_input_count','changed_existing_objects','new_objects']},case_statistics={k:v['statistics']for k,v in cases.items()},canonical_counts={k:v['decision_vectors']for k,v in canonical.items()}),indent=2))
