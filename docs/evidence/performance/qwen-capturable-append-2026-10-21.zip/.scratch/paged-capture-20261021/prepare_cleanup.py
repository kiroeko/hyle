"""Write exact obsolete trial-image/link-output deletion plan and root test.ps1; do not execute."""
from pathlib import Path
import json,hashlib
S=Path(__file__).resolve().parent;R=S.parents[1]
def identity(p):
 p=p.resolve();return dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
obsolete={'cpu':(1,2),'qwen':(1,2),'probe':(1,2),'cuda':(1,2,3,4)}
targets=[S/f'{mode}-link{attempt}'/f'{mode}.exe'for mode,attempts in obsolete.items()for attempt in attempts]
for mode,last in [('cpu',3),('qwen',3),('probe',3),('cuda',5)]:
 for attempt in range(1,last+1):
  for suffix in ('.map','.lib','.exp'):
   p=S/f'{mode}-link{attempt}'/(mode+suffix)
   if p.is_file():targets.append(p)
assert len(set(targets))==len(targets)and all(p.is_file()and p.resolve().is_relative_to(S)for p in targets)
plan=dict(targets=[identity(p)for p in targets],total_bytes=sum(p.stat().st_size for p in targets),
 receipt=str(R/'docs/evidence/performance/qwen-capturable-append-2026-10-21.cleanup.json'),
 reason='Only superseded trial images and reconstructible linker maps/import stubs from this stage. All exact commands, failures, source snapshots, final images and numerical/native evidence remain.',
 kept=['Current7b854 Qwen image, final CPU3/CUDA5/probe3 images, prior3859/dense/llama comparison images, all objects/toolchains/dependencies/weights, raw NSYS+SQLite, vectors+oracles, source changes/commands/results/reviews.'])
(S/'cleanup-plan.json').write_text(json.dumps(plan,indent=2)+'\n',encoding='utf-8')
script=(R/'.scratch/paged-native-cost-20261021/cleanup-script.ps1').read_text(encoding='utf-8')
script=script.replace('paged-native-cost-20261021','paged-capture-20261021')
script=script.replace('qwen-paged-native-cost-2026-10-21','qwen-capturable-append-2026-10-21')
script=script.replace("Join-Path $repoRoot '.scratch'","Join-Path $repoRoot '.scratch\\paged-capture-20261021'")
(R/'test.ps1').write_text(script,encoding='utf-8')
(S/'cleanup-script.ps1').write_text(script,encoding='utf-8')
print(json.dumps(dict(files=len(targets),bytes=plan['total_bytes'],script=identity(R/'test.ps1'),
 targets=[str(p.relative_to(R))for p in targets]),indent=2))
