"""Keep the active performance plan compact; older measured windows remain in linked evidence."""
from pathlib import Path
S=Path(__file__).resolve().parent;R=S.parents[1]
p=R/'docs/developer/performance/decode.md';text=p.read_text(encoding='utf-8')
start=text.index('**当前优先项（2026-10-21）')
end=text.index('当前选用的 D1 基线',start)
replacement='''**当前优先项（2026-10-21）：多会话分页路径的单会话成本。** 完整KV＋conv/GDN状态、前缀／分支、有界恢复和实际CUDA退休已验证。分页版仍有性能差距，不能因功能跑通宣布完成。

[本批可录制写页](../../evidence/performance/qwen-capturable-append-2026-10-21.json)已实现，原Queue、Graph effect、逐页权限和whole-state提交不变。真实99个完成ID／96次decode核对：每步**1次Graph launch、596个kernel、0次录制外eager D2D**，90次不重录；[前一原生调查](../../evidence/performance/qwen-paged-native-cost-2026-10-21.json)分页路径为7／584及2232次eager D2D总量。descriptor动态内容可变化，实际载体变化仍先销毁旧录制；不能只翻capture标志。

本窗各3新进程交错、显存另各1进程：current／before／dense／llama的完整decode为**94.89／94.59／97.82／97.59tok/s**，综合**85.74／84.62／87.86／85.54tok/s**。相对before仅高0.32%／1.32%，样本重叠；对参考decode仍慢2.76%，综合基本持平。prefill、加载、显存／内存及完整范围见[当前四项表](../current-work.md#最新完整性能对比)。软件插桩只核实际物理工作，不进入速率分母或预测收益；旧窗口不与本窗合池。

| 剩余项 | 已知事实与下一步 |
| --- | --- |
| 独占尾页 | 当前fresh／COW仍复制尾页有效前缀。实现有界已提交读＋唯一尾权，分支保COW；失败不得扩大已提交前缀的故障范围，实际退休后才能回收 |
| 主机页组织 | 当前仍有随历史页数增长的验证、权限及发布工作。已有canonical footprint／排序索引／定点接线／固定输出前缀复用，继续消除重复工作；不能据无API空档认定某个C++函数占比 |
| descriptor上传 | 新路径每次真正上传并等待退休后发布，冷准备有额外成本。沿原依赖／F1机制减少不必要等待，不伪造ready或保旧权限来换速度；完整准备桶不是单函数计时 |
| Radix索引 | 测试引擎目前线性查找有界完整快照。下一批在独占续写后替换为树索引，命中须有完整KV／conv／GDN状态边界；主要减少共享输入prefill，不能冒充无命中decode收益 |

顺序：**本批写页已实现并完整对照 → 独占续写 → Radix索引／有效状态边界 → 完整多会话对照**。相关数值／资源检查随实现做，阶段完成后对照性能，不重复扩展全量验证。单会话延迟、缓存命中收益和多人吞吐分别报告；不恢复旧dense兼容执行器。

此前窗口和归因留在[上一轮提交／发布证据](../../evidence/performance/qwen-retirement-publication-2026-10-21.json)及其回链；下面D1/D2是此前dense路线的已结调查，不充当当前分页性能。

'''
p.write_text(text[:start]+replacement+text[end:],encoding='utf-8')
print('Active performance plan now shows current facts, four remaining mechanisms and implementation order.')
