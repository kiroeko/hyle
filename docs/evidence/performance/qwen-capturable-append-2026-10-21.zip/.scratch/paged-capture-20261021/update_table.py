"""Render latest independent same-window numbers; no new execution or measurement."""
from pathlib import Path
import json,re,statistics
S=Path(__file__).resolve().parent;R=S.parents[1]
read=lambda p:json.loads(Path(p).read_text(encoding='utf-8-sig'))
table=read(S/'performance/public-table.json');timing=read(S/'performance/timing/summary.json')
memory=read(S/'performance/memory/summary.json')['groups'];arms=('current','before','dense','peer')
rates=table['timing'];images=table['images'];comp=table['comparison']
f=lambda arm,key:rates[arm]['rates'][key]['median']
lines=['## 最新完整性能对比','',
 '**2026-10-21，CUDA可录制分页写入后的四臂测试。** RTX 4070 12GB／Windows，Qwen3.5-2B BF16、F32 GDN，无MTP／图片；三轮`256新增输入＋32 decode`，容量1024、最终上下文864。各3新进程交错测速，显存另各1进程旁采。同权重、固定teacher-forced输入和续算历史；关闭trace／诊断及单会话前缀目录。不是多人吞吐或自由生成质量测试。','',
 '当前`7b854a2b…`，本批前paged `38596ad8…`，原dense `ff748694…`，llama.cpp `9b259137…`／`d9e03f1074db…`。当前相对before替换resources／batch／append／CUDA backend四个对象，新增helper及CUDA host／kernel三个对象；188个原输入不变，192→195。消费者main、模型数学及Provider DLL相同。','',
 '| 指标 | 当前分页Hyle | 本批前paged | 原dense Hyle | llama.cpp |',
 '| --- | ---: | ---: | ---: | ---: |']
def add(label,fn,digits=2):lines.append('| '+label+' | '+' | '.join(f'{fn(a):.{digits}f}'for a in arms)+' |')
for i in range(1,4):add(f'第{i}轮prefill tok/s',lambda a,i=i:timing['groups'][a]['phases'][f'round{i}_prefill']['median'])
for i in range(1,4):add(f'第{i}轮完整decode tok/s',lambda a,i=i:timing['groups'][a]['phases'][f'round{i}_decode']['median'])
for label,key in [('合计prefill tok/s（768／三段prefill总wall）','prefill_tps'),('完整decode tok/s（96／三段decode总wall）','full_decode_tps'),('综合输出 tok/s（99／会话wall）','session_output_tps')]:add(label,lambda a,k=key:f(a,k))
add('会话wall s',lambda a:rates[a]['session_seconds']['median'],5)
add('入口至末输出 s（含加载／冷准备）',lambda a:timing['groups'][a]['metrics']['startup_total_seconds']['median'],5)
for label,key in [('启动至ready s','startup_to_ready_seconds'),('模型权重加载 s（非冷盘带宽）','model_load_seconds')]:add(label,lambda a,k=key:rates[a]['loading'][k]['median'],5)
for label,key in [('GPU dedicated全程观测峰 GiB','gpu_dedicated_bytes'),('GPU shared全程观测峰 GiB','gpu_shared_bytes'),('GPU同一采样点总量观测峰 GiB','gpu_total_bytes'),('进程working set观测峰 GiB','working_set_bytes'),('进程private commit观测峰 GiB','private_commit_bytes')]:
 add(label,lambda a,k=key:table['independent_memory'][a]['sampled_peak_bytes'][k]/(1<<30),3)
lines+=['',
 f"每进程分别求比值后取3进程中位。相对before，decode **＋{comp['before']['full_decode_tps']['current_vs_other_median_percent']:.2f}%**、综合**＋{comp['before']['session_output_tps']['current_vs_other_median_percent']:.2f}%**，范围重叠，未证明稳定收益。相对llama，decode仍慢**{-comp['peer']['full_decode_tps']['current_vs_other_median_percent']:.2f}%**，综合高{comp['peer']['session_output_tps']['current_vs_other_median_percent']:.2f}%且范围重叠；合计prefill高{comp['peer']['prefill_tps']['current_vs_other_median_percent']:.2f}%。本窗当前3个decode样本均低于参考3样本。相对原dense，decode慢{-comp['dense']['full_decode_tps']['current_vs_other_median_percent']:.2f}%、综合慢{-comp['dense']['session_output_tps']['current_vs_other_median_percent']:.2f}%。没有用前一窗口91.34等绝对值计算本批收益。",'']
for label,key in [('decode','full_decode_tps'),('综合','session_output_tps')]:
 ranges='／'.join(f"{rates[a]['rates'][key]['min']:.2f}–{rates[a]['rates'][key]['max']:.2f}"for a in arms)
 lines.append(f'current／before／dense／参考的{label}三进程范围：**{ranges} tok/s**。')
# Original entire cold preparation bucket, including new descriptor upload/wait.
buckets={a:{str(i):[]for i in range(1,4)}for a in ('current','before')}
for run in read(S/'performance/timing/runs.json'):
 if run['variant']not in buckets:continue
 pending=None
 for line in(Path(run['folder'])/'stderr.log').read_text().splitlines():
  if line.startswith('prepared T='):pending=dict(re.findall(r'(\w+)=([^\s]+)',line))
  match=re.match(r'round(\d+)_decode\d+ tokens=',line)
  if match:
   assert pending is not None
   if int(pending['capture_recorded'])==0:buckets[run['variant']][match[1]].append(float(pending['cold_batch_seconds'])*1000)
   pending=None
bucket_stats={a:{turn:dict(count=len(v),median_ms=statistics.median(v),min_ms=min(v),max_ms=max(v))for turn,v in turns.items()}for a,turns in buckets.items()}
assert all(x['count']==90 for turns in bucket_stats.values()for x in turns.values())
(S/'performance/preparation-buckets.json').write_text(json.dumps(dict(groups=bucket_stats,scope='Complete cold_batch_seconds bucket,90zero-record calls per turn across3 processes. Not a source-function attribution. Includes native descriptor preparation/upload/wait.'),indent=2)+'\n',encoding='utf-8')
lines+=['',
 '本批实际原生trace确认96次decode均为**1次Graph launch、596个kernel、0次录制外eager D2D**，其中90次不重录；之前分页trace为7／584／2232次eager D2D总量。两次trace属于不同软件插桩窗口，只比较物理机制，不把插桩时长算作吞吐收益。新增12个写页kernel取代原range复制，数量增加不代表模型计算增加。',
 '零重录调用的完整冷准备桶按轮取中位，current约'+ '／'.join(f"{bucket_stats['current'][str(i)]['median_ms']:.3f}"for i in range(1,4))+'ms，before约'+'／'.join(f"{bucket_stats['before'][str(i)]['median_ms']:.3f}"for i in range(1,4))+'ms。每轮各90次；这是整桶，包含descriptor上传和等待，不能当作单函数耗时或保证可消除的时间。','',
 '下面是P1→D1→P2→D2→P3→D3阶段内dedicated观测峰GiB，缺样保持未知：']
for a in arms:
 values=[]
 for i in range(1,4):
  for kind in ('prefill','decode'):
   phase=memory[a]['phase_windows'].get(f'round{i}_{kind}')
   value=phase['values']['gpu_dedicated_bytes']['max']if phase else None
   values.append(f'{value/(1<<30):.3f}'if value is not None else '未知')
 lines.append(a+'：**'+'→'.join(values)+'**。')
intervals='／'.join(f"{memory[a]['actual_sample_gaps_ms']['median']:.2f}"for a in arms)
lines+=['',f'旁采请求10ms，实际间隔中位current／before／dense／参考约{intervals}ms；4个ready占用均未知，峰是采样下界。dedicated与shared各自峰不能相加；表中总量使用同一采样点的和再取峰。阶段边界括号可跨入退出，末阶段负delta不能当作推理中显存节省。',
 '12个测速与4个显存进程的99个预测ID均一致；单独142份向量回归覆盖状态续算。未固定时钟或独占GPU，小样本不作长期胜负或模型质量结论。',
 '[完整源码、命令、失败、独立数值／性能复算与SQLite](../evidence/performance/qwen-capturable-append-2026-10-21.json)。下一步补独占尾权，减少COW及主机准备工作；随后替换测试引擎的线性前缀目录为Radix索引，命中仍须有完整模型状态的有效快照边界，再做完整多会话对照。','']
path=R/'docs/developer/current-work.md';text=path.read_text(encoding='utf-8')
assert text.count('## 最新完整性能对比')==1
path.write_text(text.split('## 最新完整性能对比')[0]+'\n'.join(lines),encoding='utf-8')
print('Updated latest four-arm table from independently recomputed finite window; no new measurement.')
