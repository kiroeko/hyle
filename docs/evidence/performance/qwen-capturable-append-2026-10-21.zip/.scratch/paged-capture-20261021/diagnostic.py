"""Scratch-only readonly original Invocation state trace; no product instrumentation."""
from pathlib import Path
import importlib.util
import sys
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent;R=S.parents[1]
spec=importlib.util.spec_from_file_location('localbuild',S/'build.py')
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
source=(R/'tests/graph_batch/paged_append_cuda_consumer.cc').read_text(encoding='utf-8')
source='#include "'+(R/'src/graph/plan_state.h').as_posix()+'"\n'+source
insert=r'''
void dump_capture(g::Invocation& invocation,const char*label) {
  const auto*s=g::detail::InvocationAccess::state(invocation);
  std::fprintf(stderr,"CAP_STATE %s ranges=%zu bindings=%d\n",label,s->captured_ranges.size(),int(s->bindings_prepared));
  for(std::size_t i=0;i<s->step_bindings.size();++i){
    const auto&v=s->step_bindings[i];const auto&step=s->plan->steps[i];
    std::fprintf(stderr,"  step=%zu rev=%llu prepared=%llu stable=%d native=%d kind=%d\n",i,
      static_cast<unsigned long long>(v.revision),static_cast<unsigned long long>(v.prepared_revision),
      int(v.stable_binding_identity),int(v.native_inputs),int(step.kind));
  }
}
'''
source=source.replace('using hyle::Status;','using hyle::Status;\n'+insert)
pairs=[
 ('  HYLE_RETURN_IF_ERROR(gb::prepare(run.invocation, queues,','  dump_capture(run.invocation,"before-batch-prepare");\n  HYLE_RETURN_IF_ERROR(gb::prepare(run.invocation, queues,'),
 ('  HYLE_RETURN_IF_ERROR(gb::bind_append(run.invocation, graph.graph, graph.key_writer,','  dump_capture(run.invocation,"after-batch-prepare");\n  HYLE_RETURN_IF_ERROR(gb::bind_append(run.invocation, graph.graph, graph.key_writer,'),
 ('  HYLE_RETURN_IF_ERROR(gb::bind_append(run.invocation, graph.graph, graph.value_writer,','  dump_capture(run.invocation,"after-key-bind");\n  HYLE_RETURN_IF_ERROR(gb::bind_append(run.invocation, graph.graph, graph.value_writer,'),
 ('  HYLE_RETURN_IF_ERROR(run.invocation.prepare_replay(queues,','  dump_capture(run.invocation,"after-value-bind");\n  HYLE_RETURN_IF_ERROR(run.invocation.prepare_replay(queues,'),
 ('  HYLE_ASSIGN_OR_RETURN(auto report, run.invocation.replay_report());','  dump_capture(run.invocation,"after-prepare-replay");\n  HYLE_ASSIGN_OR_RETURN(auto report, run.invocation.replay_report());'),
 ('  HYLE_ASSIGN_OR_RETURN(auto keys, gb::take_append(run.invocation, graph.key_writer));','  dump_capture(run.invocation,"before-key-take");\n  HYLE_ASSIGN_OR_RETURN(auto keys, gb::take_append(run.invocation, graph.key_writer));\n  dump_capture(run.invocation,"after-key-take");'),
 ('  HYLE_ASSIGN_OR_RETURN(auto values, gb::take_append(run.invocation, graph.value_writer));','  HYLE_ASSIGN_OR_RETURN(auto values, gb::take_append(run.invocation, graph.value_writer));\n  dump_capture(run.invocation,"after-value-take");')]
for old,new in pairs:
 assert source.count(old)==1,(old,source.count(old))
 source=source.replace(old,new)
out=S/'diagnostic/source/tests/graph_batch/paged_append_cuda_consumer.cc'
out.parent.mkdir(parents=True,exist_ok=True);out.write_text(source,encoding='utf-8')
b.RECIPES['fixture']=(out.relative_to(R).as_posix(),b.RECIPES['fixture'][1])
b.compile_owner('fixture',3)
b.link('cuda',4,1,3,3,2)
