#pragma once

#include <cstddef>
#include <cstdint>
#include "hyle/compute/detail/backend_extension.h"
#include "hyle/mem/buffer.h"

namespace hyle::compute::detail {
inline constexpr BackendExtensionId kPagedAppendExtensionId{
    0x48594c4550414745ULL, 0x415050454e443031ULL, 1};

// Device wire format. Coordinates are rows, so independently permissioned
// banks with identical page mappings can share this immutable episode data.
// source_kind 0 reads packed new rows at source_row; 1 reads source_page in
// this same arena. Every instruction is validated by the typed page owner.
struct PagedAppendInstruction final {
  std::uint32_t source_kind=0,source_page=0,source_row=0,destination_page=0;
  std::uint32_t destination_row=0,rows=0,reserved0=0,reserved1=0;
  friend constexpr bool operator==(PagedAppendInstruction,PagedAppendInstruction) noexcept = default;
};
struct PagedAppendMetadata final {
  std::uint32_t active_count=0,reserved0=0,reserved1=0,reserved2=0;
  // Followed by instruction_capacity PagedAppendInstruction records.
};
static_assert(sizeof(PagedAppendInstruction)==32 && sizeof(PagedAppendMetadata)==16);

struct PagedAppendNativeSpec final {
  std::uint32_t page_rows=0,physical_pages=0,input_rows=0,instruction_capacity=0;
  std::size_t row_bytes=0;
};
struct PagedAppendNativeBindings final {
  // Addressable capacity, NOT whole-bank mutable permission. The original
  // Graph admits precisely the typed instruction destinations and old reads.
  mem::ConstBufferView arena,rows,metadata;
};
// Optional byte-copy primitive of the exact backend Context. This records a
// single fixed-topology kernel into the original admitted Queue sequence.
// prepare/destroy are cold; no private Queue, Completion, page owner or plan.
// Captured arguments depend only on spec and all three complete carrier
// identities. Instruction contents/count may change only after retirement.
struct PagedAppendBackendVTable final {
  Status (*prepare)(void *context,PagedAppendNativeSpec,mem::AllocatorRef,
                    void **program) noexcept=nullptr;
  void (*destroy)(void *program,mem::AllocatorRef) noexcept=nullptr;
  EnqueueResult (*enqueue)(void *context,void *queue,void *program,
                          PagedAppendNativeBindings) noexcept=nullptr;
  bool supports_command_capture=false;
};
} // namespace hyle::compute::detail
