#include "paged_append.h"
#include "hyle/compute/detail/batch_provider.h"
#include "hyle/compute/detail/paged_arena_access.h"
#include "hyle/compute/transfer.h"
#include "hyle/mem/std_allocator.h"
#include <algorithm>
#include <array>
#include <functional>
#include <utility>
#include <vector>

namespace hyle::graph::batch {
namespace c=compute;namespace cd=c::detail;namespace gd=graph::detail;
namespace {
Result<c::TensorDesc> row_description(const PagedAppend&op,std::int64_t rows)noexcept{
  if(!op.schema.valid() || op.schema.capacity().storage!=c::BatchStorage::kPaged ||
      (op.role!=c::BatchCacheRole::kKey && op.role!=c::BatchCacheRole::kValue && op.role!=c::BatchCacheRole::kMla) ||
      rows<=0 || rows>op.schema.capacity().max_query_rows ||
      ((op.schema.mla_layout()!=c::MlaCacheLayout::kNone)!=(op.role==c::BatchCacheRole::kMla)))
    return std::unexpected(Status::InvalidArgument("paged append needs its paged schema/role/active rows"));
  const auto cap=op.schema.capacity();const auto storage=op.role==c::BatchCacheRole::kValue?cap.value_storage:cap.key_storage;
  if(storage.data_type()!=c::DataType::kFloat16 && storage.data_type()!=c::DataType::kBFloat16)
    return std::unexpected(Status::Unimplemented("paged append currently copies plain F16/BF16 rows"));
  return c::TensorDesc::dense(storage.data_type(),std::array<std::int64_t,3>{rows,cap.kv_heads,
      op.role==c::BatchCacheRole::kValue?cap.value_head_dim:cap.qk_head_dim});
}
std::uint32_t history(c::HostBatchLayout h,std::uint32_t request,std::uint32_t page_size)noexcept{
  const auto pages=std::uint32_t(h.kv_indptr[request+1]-h.kv_indptr[request]);
  return pages?(pages-1)*page_size+std::uint32_t(h.last_page_lengths[request]):0;
}
}
Status PagedAppend::infer_output_descriptions(std::span<const c::TensorDesc>inputs,std::span<c::TensorDesc>outputs)const noexcept{
  if(inputs.size()!=1 || !inputs[0].valid() || inputs[0].rank()!=3 || !outputs.empty())
    return Status::InvalidArgument("paged append needs packed new rows and no tensor output");
  HYLE_ASSIGN_OR_RETURN(auto expected,row_description(*this,inputs[0].dimensions()[0]));
  if(inputs[0]!=expected)return Status::InvalidArgument("paged append needs exact packed new rows");
  return Status::Ok();
}
Result<PagedAppend> paged_append(c::BatchSchema schema,c::BatchCacheRole role)noexcept{
  PagedAppend result{std::move(schema),role};HYLE_ASSIGN_OR_RETURN(auto expected,row_description(result,1));(void)expected;return result;
}
namespace detail {
struct PagedAppendData final {
  struct Range final {std::size_t writer=0,destination=0,source=0,bytes=0;bool prefix=false;};
  explicit PagedAppendData(mem::AllocatorRef a):allocator(a),writers(mem::StdAllocator<c::PagedPageWriter>(a)),
      ranges(mem::StdAllocator<Range>(a)),ready_pages(mem::StdAllocator<c::ReadLease>(a)),
      required(mem::StdAllocator<std::uint32_t>(a)),
      writer_ptrs(mem::StdAllocator<const c::WriteLease*>(a)),targets(mem::StdAllocator<mem::BufferView>(a)){}
  void destroy()noexcept{const auto a=allocator;a.destroy(this);}
  mem::AllocatorRef allocator;c::PagedArena arena;c::BatchLayoutVersion layout;c::PagedArenaRead previous,result;
  PagedAppend descriptor;c::TensorDesc rows;std::size_t row_bytes=0;
  std::vector<c::PagedPageWriter,mem::StdAllocator<c::PagedPageWriter>>writers;
  std::vector<Range,mem::StdAllocator<Range>>ranges;
  std::vector<c::ReadLease,mem::StdAllocator<c::ReadLease>>ready_pages;
  std::vector<std::uint32_t,mem::StdAllocator<std::uint32_t>>required;
  std::vector<const c::WriteLease*,mem::StdAllocator<const c::WriteLease*>>writer_ptrs;
  std::vector<mem::BufferView,mem::StdAllocator<mem::BufferView>>targets;
  bool successful=false;
};
}
PagedAppendPages::PagedAppendPages(PagedAppendPages&&other)noexcept:data_(std::exchange(other.data_,nullptr)){}
PagedAppendPages&PagedAppendPages::operator=(PagedAppendPages&&other)noexcept{if(this!=&other){PagedAppendPages next(std::move(other));std::swap(data_,next.data_);}return *this;}
PagedAppendPages::~PagedAppendPages(){if(data_)data_->destroy();}
c::BatchLayoutVersion PagedAppendPages::layout()const noexcept{return data_?data_->layout:c::BatchLayoutVersion{};}
std::size_t PagedAppendPages::page_count()const noexcept{return data_?data_->writers.size():0;}
Result<c::PagedPageWriter&> PagedAppendPages::page(std::size_t index)noexcept{
  if(!data_ || index>=data_->writers.size())return std::unexpected(Status::OutOfRange("paged append dirty page index"));return data_->writers[index];
}
Result<PagedAppendPages> PagedAppendPages::create(c::PagedArena arena,c::BatchLayoutVersion next,
    c::PagedArenaRead previous,std::span<c::PagedPageWriter>dirty,PagedAppendOptions options)noexcept{
  if(!arena.valid() || !next.valid() || !previous.valid() || !cd::PagedArenaAccess::owns(arena,previous) ||
      !cd::PagedArenaAccess::schema(arena).owns(next) || dirty.empty() || !options.allocator.valid())
    return std::unexpected(Status::InvalidArgument("paged append requires original arena, old frame, next layout and dirty pages"));
  auto allocator=options.allocator;if(options.resource_budget.valid()){HYLE_ASSIGN_OR_RETURN(allocator,options.resource_budget.metadata_allocator());}
  auto*p=allocator.construct<detail::PagedAppendData>(allocator);if(!p)return std::unexpected(Status::ResourceExhausted("paged append owner metadata"));
  PagedAppendPages result(p);p->arena=std::move(arena);p->layout=std::move(next);p->previous=std::move(previous);
  HYLE_ASSIGN_OR_RETURN(p->descriptor,paged_append(p->layout.schema(),cd::PagedArenaAccess::role(p->arena)));
  HYLE_ASSIGN_OR_RETURN(p->rows,row_description(p->descriptor,p->layout.facts().query_rows));HYLE_ASSIGN_OR_RETURN(auto row_bytes,p->rows.required_bytes());p->row_bytes=row_bytes/p->layout.facts().query_rows;
  const auto cap=p->layout.schema().capacity();const auto old=p->previous.layout();
  if(!p->layout.schema().owns(old) || old.facts().requests!=p->layout.facts().requests)
    return std::unexpected(Status::InvalidArgument("paged append old/new request domains differ"));
  try{
    p->writers.reserve(dirty.size());p->writer_ptrs.reserve(dirty.size());p->required.resize(dirty.size());p->targets.reserve(dirty.size());
    p->ranges.reserve(std::size_t(p->layout.facts().query_rows)+dirty.size());
    p->ready_pages.reserve(p->layout.facts().page_refs);
    std::vector<cd::ArenaPageWrite,mem::StdAllocator<cd::ArenaPageWrite>>facts{mem::StdAllocator<cd::ArenaPageWrite>(allocator)};facts.reserve(dirty.size());
    // Keep facts/writers in caller order: ranges and page() use that original
    // ordinal. Only this call-scoped lookup index is sorted.
    std::vector<std::size_t,mem::StdAllocator<std::size_t>>writer_order{mem::StdAllocator<std::size_t>(allocator)};writer_order.reserve(dirty.size());
    for(std::size_t i=0;i<dirty.size();++i){HYLE_ASSIGN_OR_RETURN(auto fact,cd::PagedArenaAccess::writer(p->arena,dirty[i]));
      facts.push_back(fact);writer_order.push_back(i);}
    std::sort(writer_order.begin(),writer_order.end(),[&](auto a,auto b){return std::less<const void*>{}(facts[a].root,facts[b].root);});
    for(std::size_t i=1;i<writer_order.size();++i)if(facts[writer_order[i-1]].root==facts[writer_order[i]].root)
      return std::unexpected(Status::InvalidArgument("paged append repeats a dirty original page"));
    std::sort(writer_order.begin(),writer_order.end(),[&](auto a,auto b){return facts[a].page<facts[b].page;});
    for(std::size_t i=1;i<writer_order.size();++i)if(facts[writer_order[i-1]].page==facts[writer_order[i]].page)
      return std::unexpected(Status::InvalidArgument("paged append repeats a dirty original page"));
    const auto old_pages=cd::PagedArenaAccess::pages(p->previous);const auto before=old.host(),after=p->layout.host();
    // read_impl validated and canonicalized these immutable guards against
    // this exact layout. Holding the frame prevents their pages from being
    // reclaimed, so its cached footprint preserves the same guard ordinals.
    HYLE_ASSIGN_OR_RETURN(auto old_ids,cd::BatchLayoutAccess::page_footprint(old));
    if(old_ids.size()!=old_pages.size())
      return std::unexpected(Status::Internal("paged append old frame footprint differs from its guards"));
    const auto writer_index=[&](std::uint32_t page)->std::size_t{
      const auto found=std::lower_bound(writer_order.begin(),writer_order.end(),page,[&](auto i,auto target){return facts[i].page<target;});
      return found!=writer_order.end() && facts[*found].page==page?*found:facts.size();};
    const auto old_page_index=[&](std::uint32_t page)->Result<std::size_t>{
      const auto found=std::lower_bound(old_ids.begin(),old_ids.end(),page,
        [](std::int32_t id,std::uint32_t target){return std::uint32_t(id)<target;});
      if(found==old_ids.end() || std::uint32_t(*found)!=page)return std::unexpected(Status::InvalidArgument("paged append prefix page is absent"));
      return std::size_t(found-old_ids.begin());};
    for(std::uint32_t request=0;request<p->layout.facts().requests;++request){
      const auto previous_rows=history(before,request,cap.page_size),next_rows=history(after,request,cap.page_size);
      const auto rows=std::uint32_t(after.query_indptr[request+1]-after.query_indptr[request]);
      if(std::uint64_t(previous_rows)+rows!=next_rows)return std::unexpected(Status::InvalidArgument("paged append must extend each request by its packed query rows"));
      const auto pages=std::uint32_t(after.kv_indptr[request+1]-after.kv_indptr[request]);
      for(std::uint32_t logical=0;logical<pages;++logical){
        const auto physical=std::uint32_t(after.page_indices[std::size_t(after.kv_indptr[request])+logical]);
        const auto begin=logical*cap.page_size,end=std::min(next_rows,begin+cap.page_size);
        const auto inherited=previous_rows>begin?std::min(previous_rows-begin,cap.page_size):0;
        const auto index=writer_index(physical);
        if(end>previous_rows && end>begin && rows){
          if(index==facts.size())return std::unexpected(Status::InvalidArgument("paged append has no writer for new rows"));
          if(p->required[index])return std::unexpected(Status::InvalidArgument("paged append dirty page is shared across requests"));
          p->required[index]=end-begin;
          if(inherited){
            const auto source_page=std::uint32_t(before.page_indices[std::size_t(before.kv_indptr[request])+logical]);
            if(source_page==physical)return std::unexpected(Status::InvalidArgument("retained prefix must use a distinct dirty COW page"));
            HYLE_ASSIGN_OR_RETURN(auto ordinal,old_page_index(source_page));
            p->ranges.push_back({index,0,ordinal,std::size_t(inherited)*p->row_bytes,true});
          }
          const auto new_begin=std::max(begin,previous_rows);
          p->ranges.push_back({index,std::size_t(new_begin-begin)*p->row_bytes,
            std::size_t(std::uint32_t(after.query_indptr[request])+new_begin-previous_rows)*p->row_bytes,
            std::size_t(end-new_begin)*p->row_bytes,false});
        }else{
          if(index!=facts.size())return std::unexpected(Status::InvalidArgument("paged append dirty page has no appended rows"));
          const auto source_page=std::uint32_t(before.page_indices[std::size_t(before.kv_indptr[request])+logical]);
          if(source_page!=physical)return std::unexpected(Status::InvalidArgument("paged append changed an untouched prefix page"));
          HYLE_ASSIGN_OR_RETURN(auto ordinal,old_page_index(source_page));(void)ordinal;
        }
      }
    }
    for(std::size_t i=0;i<dirty.size();++i){if(!p->required[i])return std::unexpected(Status::InvalidArgument("paged append contains an unused writer"));
      if(facts[i].initialized_rows)return std::unexpected(Status::InvalidArgument("paged append dirty targets must be fresh uninitialized original pages"));}
    // This immutable layout already owns the canonical ID set, shared by all
    // its banks. The footprint carries no permission; old guards and every
    // dirty writer were independently checked above.
    HYLE_ASSIGN_OR_RETURN(auto final_pages,cd::BatchLayoutAccess::page_footprint(p->layout));
    // Retain exactly the untouched ready prefix now, using the two canonical
    // ID sets. These are old readonly guards, not publication of dirty pages;
    // ready() still requires whole-Graph success and publishes each writer.
    for(std::size_t old_index=0,final_index=0;old_index<old_ids.size() && final_index<final_pages.size();){
      const auto final_id=std::uint32_t(final_pages[final_index]);
      const auto old_id=std::uint32_t(old_ids[old_index]);
      if(old_id<final_id)++old_index;
      else if(final_id<old_id)++final_index;
      else{p->ready_pages.push_back(old_pages[old_index]);++old_index;++final_index;}
    }
    // Last fallible validation/allocation precedes consuming caller writers.
    for(const auto&fact:facts)p->targets.push_back(fact.storage);
    for(auto&writer:dirty)p->writers.push_back(std::move(writer));
    for(auto&writer:p->writers)p->writer_ptrs.push_back(&writer.lease());
  }catch(...){return std::unexpected(Status::ResourceExhausted("paged append fixed metadata"));}
  return result;
}
Result<c::PagedArenaRead> PagedAppendPages::ready()noexcept{
  if(!data_ || !data_->successful)return std::unexpected(Status::FailedPrecondition("paged append requires a successful retired whole Graph"));
  auto&p=*data_;if(p.result.valid())return p.result;
  for(std::size_t i=0;i<p.writers.size();++i){if(!p.writers[i].lease().valid())continue;
    HYLE_ASSIGN_OR_RETURN(auto ready,p.writers[i].publish(p.required[i]));p.ready_pages.push_back(std::move(ready));}
  HYLE_ASSIGN_OR_RETURN(p.result,p.arena.read(p.layout,p.ready_pages));return p.result;
}
namespace detail {
namespace {
constexpr c::ProviderRuntimeProperties queue_runtime{.mode=c::ProviderRuntimeMode::kSharedQueue,
  .workspace_owner=c::ProviderWorkspaceOwner::kCaller,.replay_class=c::ProviderReplayClass::kPrepared,
  .blocks_host=false,.uses_private_threads=false,.supports_concurrent_invocations=true,.capture_compatible=false};
c::ProviderRuntimeProperties runtime(const AppendAdapter&adapter)noexcept{
  auto result=queue_runtime;
  // The CPU Queue performs its copies synchronously on the submitting thread.
  // Device-Queue copies enqueue into that same original ordered sequence.
  result.blocks_host=adapter.device_class==c::DeviceClass::kCpu;
  return result;
}
struct Prepared final {PagedAppend descriptor;c::TensorDesc rows;mem::MemoryResourceRef resource;NodeId node;};
struct Slot final {PagedAppendPages pages;ValueId cache;};
const ProviderRegionPreparedVTable table{
 .destroy_prepared=[](void*p,mem::AllocatorRef a)noexcept{a.destroy(static_cast<Prepared*>(p));},
 .alias_support=[](void*,std::size_t,std::size_t)noexcept{return c::AliasSupport{};},
 .create_invocation=[](void*,mem::AllocatorRef a,mem::BufferView,void**out)noexcept->Status{*out=a.construct<Slot>();return *out?Status::Ok():Status::ResourceExhausted("paged append slot");},
 .destroy_invocation=[](void*p,mem::AllocatorRef a)noexcept{a.destroy(static_cast<Slot*>(p));},
 .shared_submit=[](void*,void*opaque,cd::QueueSequence&sequence,std::span<const c::ConstTensorView>inputs,std::span<const c::TensorView>outputs)noexcept->cd::EnqueueResult{
   auto&slot=*static_cast<Slot*>(opaque);auto*p=PagedAppendAccess::data(slot.pages);
   if(!p || inputs.size()!=1 || !outputs.empty() || inputs[0].description()!=p->rows)
     return cd::EnqueueResult::rejected(Status::FailedPrecondition("paged append original transaction is not bound"));
   bool accepted=false;const auto old=cd::PagedArenaAccess::pages(p->previous);
   for(const auto&range:p->ranges){auto target=p->targets[range.writer].subview(range.destination,range.bytes);if(!target)return {accepted,target.error()};
     Result<mem::ConstBufferView> source=range.prefix?old[range.source].view():inputs[0].storage().subview(range.source,range.bytes);
     if(!source)return {accepted,source.error()};if(range.prefix)source=source->subview(0,range.bytes);if(!source)return {accepted,source.error()};
     auto command=cd::TransferAccess::enqueue_copy(sequence,*target,*source);accepted|=command.accepted;
     if(!command.status.ok())return {accepted,std::move(command.status)};
   }return {accepted,Status::Ok()};
 },
 .seal_bindings=[](void*,void*opaque)noexcept->Status{return static_cast<Slot*>(opaque)->pages.valid()?Status::Ok():Status::FailedPrecondition("paged append has no owned original pages");}};
Status propose(void*,const RegionDiscoveryRequest&r,mem::AllocatorRef,RegionProposalWriter&w)noexcept{
  for(std::size_t i=0;i<r.graph.node_count();++i){if(!r.allowed_nodes.empty() && !r.allowed_nodes[i])continue;
    HYLE_ASSIGN_OR_RETURN(auto node,r.graph.node_id(i));
    HYLE_ASSIGN_OR_RETURN(auto kind,r.graph.operation_kind(node));
    if(kind!=c::OperationKind::kCustom)continue;
    HYLE_ASSIGN_OR_RETURN(auto operation,r.graph.operation(node));
    if(!operation.custom_as<PagedAppend>())continue;const std::array nodes{node};
    HYLE_ASSIGN_OR_RETURN(auto added,w.try_add({.nodes=nodes,.route=1,.replay_class=c::ProviderReplayClass::kPrepared,
        .implementation=c::ProviderImplementationId{0x5041474544415050ULL}}));if(!added)break;
  }return Status::Ok();
}
Status resources(void*opaque,const RegionCompileRequest&r,mem::AllocatorRef,std::span<RegionInputRequirement>inputs,
    std::span<RegionOutputRequirement>outputs,RegionResourceProposal*out)noexcept{
  if(!r.graph || r.nodes.size()!=1 || r.inputs.size()!=1 || inputs.size()!=1 || !outputs.empty() || !r.has_unknown_effects)
    return Status::Unimplemented("paged append needs its original external-write singleton");
  HYLE_ASSIGN_OR_RETURN(auto op,r.graph->operation(r.nodes[0]));const auto append=op.custom_as<PagedAppend>();
  if(!append)return Status::Unimplemented("not paged append");HYLE_ASSIGN_OR_RETURN(auto rows,r.graph->value_description(r.inputs[0]));
  HYLE_RETURN_IF_ERROR(append->infer_output_descriptions(std::span(&rows,1),{}));
  const auto&a=*static_cast<AppendAdapter*>(opaque);
  inputs[0].resource.required_properties=a.device_class==c::DeviceClass::kCpu?mem::MemoryProperty::kHostAccessible:mem::MemoryProperty::kDeviceAccessible;
  inputs[0].resource.minimum_alignment=1;
  *out={.runtime=runtime(a),.preserves_effects=true};return Status::Ok();
}
c::ProviderPrepareOutcome compile(void*opaque,const RegionCompileRequest&r,mem::AllocatorRef a,ProviderRegionPrepared*out)noexcept{
  *out={};if(!r.graph || r.nodes.size()!=1 || r.inputs.size()!=1 || r.input_resources.size()!=1 || !r.outputs.empty() || !r.has_unknown_effects)
    return c::ProviderPrepareOutcome::unsupported(Status::Unimplemented("paged append boundary differs"));
  auto operation=r.graph->operation(r.nodes[0]);if(!operation)return c::ProviderPrepareOutcome::error(operation.error());
  const auto append=operation->custom_as<PagedAppend>();if(!append)return c::ProviderPrepareOutcome::unsupported(Status::Unimplemented("not paged append"));
  auto rows=r.graph->value_description(r.inputs[0]);if(!rows)return c::ProviderPrepareOutcome::error(rows.error());
  const auto validation=append->infer_output_descriptions(std::span(&*rows,1),{});if(!validation.ok())return c::ProviderPrepareOutcome::error(validation);
  const auto&adapter=*static_cast<AppendAdapter*>(opaque);
  if(r.input_resources[0]!=adapter.resource)return c::ProviderPrepareOutcome::unsupported(Status::Unimplemented("paged append needs rows in its original Queue resource"));
  auto*p=a.construct<Prepared>();if(!p)return c::ProviderPrepareOutcome::error(Status::ResourceExhausted("paged append prepared metadata"));
  p->descriptor=*append;p->rows=*rows;p->resource=adapter.resource;p->node=r.nodes[0];
  *out={.vtable=&table,.state=p,.properties={.workspace={0,1},.persistent_bytes=sizeof(Prepared),.dispatch_count=1,
      .runtime=runtime(adapter),.preserves_effects=true,.invocation_private_bytes=std::nullopt}};
  return c::ProviderPrepareOutcome::prepared();
}
const RegionProviderVTable provider_table{&propose,&resources,&compile};
struct Find final {NodeId node;Slot*slot=nullptr;Prepared*prepared=nullptr;gd::ProjectedWriter proof;};
Status find(void*opaque,const gd::RegionAccessView&view)noexcept{
  auto&f=*static_cast<Find*>(opaque);if(view.prepared_vtable!=&table || view.node_ordinals.size()!=1 || static_cast<const Prepared*>(view.prepared)->node!=f.node)return Status::Ok();
  if(f.slot)return Status::InvalidArgument("duplicate selected paged append");
  f.slot=static_cast<Slot*>(view.invocation);f.prepared=static_cast<Prepared*>(view.prepared);f.proof={f.node,view.step,&table,view.prepared};return Status::Ok();
}
}
const RegionProviderVTable*PagedAppendAccess::provider()noexcept{return &provider_table;}
Result<AppendFacts>PagedAppendAccess::facts(const PagedAppendPages&pages)noexcept{
  if(!pages.data_)return std::unexpected(Status::InvalidArgument("paged append pages are empty"));
  HYLE_ASSIGN_OR_RETURN(auto capacity,cd::PagedArenaAccess::tensor(pages.data_->arena));
  return AppendFacts{pages.data_->layout,pages.data_->descriptor.role,capacity};
}
Status PagedAppendAccess::bind(Invocation&invocation,const Graph&graph,NodeId node,ValueId cache,PagedAppendPages&&pages,
    std::span<const gd::ProjectedReader>readers,ResourceOptions options)noexcept{
  Find f{node};HYLE_RETURN_IF_ERROR(gd::RegionAccess::visit(invocation,node,&find,&f));
  if(!f.slot || !pages.data_ || f.slot->pages.valid())return Status::FailedPrecondition("paged append needs its selected idle slot and untaken transaction");
  auto&p=*pages.data_;const auto&op=f.prepared->descriptor;
  if(!op.schema.owns(p.layout) || op.role!=p.descriptor.role || p.rows!=f.prepared->rows ||
      p.layout.facts().query_rows!=f.prepared->rows.dimensions()[0] || p.successful)
    return Status::InvalidArgument("paged append transaction differs from its selected operation");
  HYLE_ASSIGN_OR_RETURN(auto capacity,cd::PagedArenaAccess::tensor(p.arena));
  if(capacity.storage().resource()!=f.prepared->resource)return Status::InvalidArgument("paged append arena belongs to another selected Queue resource");
  for(const auto&writer:p.writers){HYLE_ASSIGN_OR_RETURN(auto fact,cd::PagedArenaAccess::writer(p.arena,writer));(void)fact;}
  HYLE_RETURN_IF_ERROR(gd::RegionAccess::bind_written_projection(invocation,graph,cache,capacity,
      cd::PagedArenaAccess::pages(p.previous),p.writer_ptrs,f.proof,readers,options));
  f.slot->cache=cache;f.slot->pages=std::move(pages);return Status::Ok();
}
Result<PagedAppendPages>PagedAppendAccess::take(Invocation&invocation,NodeId node)noexcept{
  Find f{node};HYLE_RETURN_IF_ERROR(gd::RegionAccess::visit_retired(invocation,node,&find,&f));
  if(!f.slot || !f.slot->pages.valid())return std::unexpected(Status::InvalidArgument("paged append has no retained transaction"));
  const bool successful=gd::RegionAccess::successful_outcome(invocation);
  // Taking one resource revokes replay/output readiness for the whole Graph.
  // Latch the same actual successful terminal for all its original append
  // transactions before the first release; this does not publish any page.
  if(successful)HYLE_RETURN_IF_ERROR(gd::RegionAccess::visit_retired(invocation,
      [](void*,const gd::RegionAccessView&view)noexcept->Status{
        if(view.prepared_vtable==&table){auto&pages=static_cast<Slot*>(view.invocation)->pages;
          if(auto*p=PagedAppendAccess::data(pages))p->successful=true;}return Status::Ok();
      },nullptr));
  HYLE_RETURN_IF_ERROR(gd::RegionAccess::release_written_projection(invocation,f.slot->cache));
  auto result=std::move(f.slot->pages);f.slot->cache={};return result;
}
Status PagedAppendAccess::reset(Invocation&invocation)noexcept{
  return gd::RegionAccess::visit(invocation,[](void*,const gd::RegionAccessView&view)noexcept->Status{
    if(view.prepared_vtable==&table && static_cast<Slot*>(view.invocation)->pages.valid())
      return Status::FailedPrecondition("take original paged append pages before resetting the Graph");return Status::Ok();
  },nullptr);
}
} // namespace detail
} // namespace hyle::graph::batch
