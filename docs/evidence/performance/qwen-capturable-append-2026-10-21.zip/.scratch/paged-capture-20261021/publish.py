"""Publish one bounded source/command/numeric/native/performance evidence bundle."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,zipfile
S=Path(__file__).resolve().parent;R=S.parents[1]
def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def identity(p):
 p=Path(p).resolve();return dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def save(p,v):Path(p).write_text(json.dumps(v,indent=2,allow_nan=False)+'\n',encoding='utf-8')
report_path=R/'docs/evidence/performance/qwen-capturable-append-2026-10-21.json'
archive=report_path.with_suffix('.zip')
assert not report_path.exists()and not archive.exists()
research=R/'docs/evidence/research/radix-hybrid-prefix-cache-2026-10-21.json'
research_bytes=(S/'research/radix-next.json').read_bytes()
assert not research.exists()or research.read_bytes()==research_bytes
research.write_bytes(research_bytes)
numeric=read(S/'review/runtime-comparison.json')
assert numeric['total_decision_vectors']==142 and numeric['all_byte_equal']
assert numeric['image']==read(S/'qwen-ready-attempt3.json')['image']
assert read(S/'single-run1/summary.json')['passed']and read(S/'multi-run1/summary.json')['passed']
for folder in ['cpu-run2','cuda-run5','main-run1','pressure-run1','probe-run3']:
 assert read(S/folder/'result.json')['exit']==0
assert read(S/'probe-run3/observation.json')['status']=='PASS'
native=read(S/'native-analysis.json');assert native['physical_counts']['current']==dict(
 calls=96,GraphLaunch_counts={'1':96},kernel_counts={'596':96},total_eager_D2D=0,zero_record_calls=90)
for mode,count in [('timing',12),('memory',4)]:
 runs=read(S/f'performance/{mode}/runs.json')
 assert len(runs)==count and all(x['process']['exit']==0 for x in runs)
all_runs=read(S/'performance/timing/runs.json')+read(S/'performance/memory/runs.json')
assert all(x['observation']['predicted_ids']==all_runs[0]['observation']['predicted_ids']for x in all_runs)
table=read(S/'performance/public-table.json')
performance_review=identity(S/'review/performance-review.json')
sources=[
 'include/hyle/compute/detail/paged_append_backend.h','include/hyle/compute/detail/paged_append_wire.h',
 'include/hyle/compute/detail/paged_append_program.h','include/hyle/graph/detail/region_access.h',
 'src/compute_batch/paged_append_program.cc','src/compute_batch/CMakeLists.txt',
 'src/compute_backend_cuda/cuda_paged_append.cc','src/compute_backend_cuda/cuda_paged_append.cu',
 'src/compute_backend_cuda/cuda_paged_append.h','src/compute_backend_cuda/cuda_backend.cc',
 'src/compute_backend_cuda/cuda_internal.h','src/compute_backend_cuda/CMakeLists.txt',
 'src/graph/resources.cc','src/graph_batch/paged_append.h','src/graph_batch/paged_append.cc',
 'src/graph_batch/batch.cc','tests/graph_batch/paged_append_cuda_consumer.cc',
 'docs/architecture/compute-design.md','docs/architecture/graph-design.md',
 'docs/developer/current-work.md','docs/developer/performance/decode.md',
 'docs/evidence/research/radix-hybrid-prefix-cache-2026-10-21.json']
allowed={'.json','.py','.ps1','.log','.diff','.patch','.txt','.md','.cc','.h','.cu','.tsv','.sqlite','.original-bytes'}
paths={}
for p in S.rglob('*'):
 if p.is_file()and p.suffix in allowed and 'tmp'not in p.relative_to(S).parts and '__pycache__'not in p.parts and p.name!='published.json':
  paths[p.relative_to(R).as_posix()]=p
for name in sources:paths[name]=R/name
for name in ['.scratch/paged-native-cost-20261021/analyze_native.py',
 '.scratch/paged-prepare-20261021/performance.py',
 '.scratch/architecture-refactor-2026-10-18/d4-windows-preparation-2026-10-21/first-decode-startup-2026-10-21/multiturn/multiturn_run.py']:
 paths[name]=R/name
inventory=[dict(archive_path=n,**identity(p))for n,p in sorted(paths.items())]
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6)as z:
 for n,p in sorted(paths.items()):z.write(p,n)
 z.writestr('manifest.json',json.dumps(dict(files=inventory,
  scope='Actual current SQLite native trace, all bounded raw correctness/performance process commands/results/logs, exact source/before/diffs/revisions, incremental build identities, host-only numerical/performance analyses and exact cleanup script/plan.',
  excluded='No model/SDK/exe/object/map payloads or duplicate raw decision vectors. Final images and original vector oracles remain in retained scratch, raw NSYS retained and hashed separately. Historical traces referenced from prior published evidence; not rerun or copied.'),indent=2))
with zipfile.ZipFile(archive)as z:assert z.testzip()is None
records=list((S/'core').rglob('identity.json'))+list((S/'cuda/checks1').rglob('identity.json'))+list((S/'host').rglob('identity.json'))
links=list(S.glob('*-link*/link-plan.json'))
save(report_path,dict(date='2026-10-21',created_utc=datetime.now(timezone.utc).isoformat(),
 status='CUDA metadata-driven append implemented in original Graph and actual Qwen validated; bounded performance comparison complete. Exclusive suffix/MTP/images and other-native full consumers remain unfinished.',
 archive=identity(archive),archive_file_count=len(inventory),source_identities=[identity(R/n)for n in sources],
 current_image=read(S/'qwen-ready-attempt3.json')['image'],current_ready=identity(S/'qwen-ready-attempt3.json'),
 implementation=[
  'Compute batch owns typed finite row-instruction program/mirror; actual backend extension opts into native command capture. CUDA leaf executes bit-exact F16/BF16 row copies on original admitted QueueSequence, no provider/model whitelist or alternate executor.',
  'Only one original Invocation can share a descriptor group, keyed by exact layout/Queue/resource/host/capacity/full resolved instructions including actual old-tail IDs. Different Invocation or differing mappings own separate mirrors; previously shared mappings can split without overwriting a live sibling.',
  'Descriptor upload has actual F1 host read/device write, accepted Completion retention and actual terminal before publish; each model Graph admits actual ready descriptor reads. Device/host IO is charged to explicit batch preparation budget, independently of state-only cache budget.',
  'Taking pages withdraws original permissions and execution readiness. Original selected writer plus actual capture backend stable-identity proof may keep dormant commands; fresh permissions and seal required. Bank backing remains owned without retaining old-page permission. Carrier changes invalidate before replacement; actual packed input/write overlap rejected cold.',
  'Fallback retains original TransferAccess loop. Existing page/COW/wholeGraph publication/error/native-retirement contracts unchanged. No public consumer main or model mathematics changes.'],
 build=dict(CXX_compiles=sum(not str(read(p)['source']['path']).endswith('.cu')for p in records),
  NVCC_compiles=sum(str(read(p)['source']['path']).endswith('.cu')for p in records),links=len(links),SDK_builds=0,
  closure='Four existing host objects replaced and three native/helper objects added to prior192 inputs;188 original inputs identical, current195. Cached native libraries/SDKs reused.',
  local_device_architecture='NVCC cached local89 PTX+sm89, WindowsRTX4070; not normal-default80/89 cross-platform certification.'),
 correctness=dict(vector_count=142,all_byte_equal=True,finite=True,independent_review=identity(S/'review/runtime-comparison.json'),
  canonical=[identity(S/x/'summary.json')for x in ['single-run1','multi-run1']],
  final_fixtures={x:identity(S/x/'result.json')for x in ['cpu-run2','cuda-run5']},
  actual_native_retirement=dict(result=identity(S/'probe-run3/result.json'),observation=read(S/'probe-run3/observation.json')),
  limits='Actual WindowsCPU fallback/CUDA Qwen consumers, fixed tested journeys/shapes. Not independent model quality, every intermediate state bit, simultaneous GPU request throughput or Apple/Vulkan/encoded append acceptance.'),
 native=dict(actual_counts=native['physical_counts'],review=identity(S/'native-analysis.json'),
  raw_nsys=identity(S/'current/capture.nsys-rep'),sqlite=identity(S/'current/capture.sqlite'),
  meaning='Actual99 host decisions/96 decode device envelopes. Current1 graph launch and596 kernels each,0eagerD2D; prior historical paged7/584/2232 versus dense1/596/0. Ninety current decode calls have0 recordings. Counts compare mechanism, profiler timing does not certify speedup.',
  limitations=native['limits']),
 full_unprofiled_performance=dict(table=table,independent_review=performance_review,
  timing=identity(S/'performance/timing/summary.json'),memory=identity(S/'performance/memory/summary.json'),
  scope='Same3turn256newprompt+32decode/capacity1024,864inputs/96decode/99predicted IDs. Current7b854, prior3859, originaldenseff748 and llama9b259 with same provider DLLs;3fresh interleaved timing perarm plus1separate memory process perarm. No profiler/diagnostic/prefix directory, no actual eviction/cancellation in timed window.',
  limitation='Small overlapping desktop samples, clocks not fixed, no GPU isolation; not a lasting win or regression test. Per-process ratio then median, never pooled or phase-median denominator. Memory peaks are sampled lower bounds; ready occupancy unknown.'),
 failures_and_corrections=[
  'Actual CUDA attempt1 failed because writer.view was requested after F1 admission. Fixed by obtaining views first, preserving admission/Completion/retirement gates. Source reviewers recorded this missed ordering issue.',
  'Actual CUDA attempts2/3 failed strict same-Graph reuse assertion; scratch-only attempt4 proved page take, layout preparation and K/V bind retained capture. Only upstream opaque native Copy output-owner cold rebind invalidated the range at prepare_replay.',
  'Metadata-specific fixture now feeds stable original input TensorViews, retaining strict0record/reuse>0 assertion; original ordinaryCopy->Append->Attention test remains unchanged. Final attempt5 passes. Distinct test workloads are documented, not treated as one performance comparison.'],
 reviews=[identity(S/'review/common-review.json'),identity(S/'review/independent-source-review.json')],
 next_radix_research=identity(research),
 cleanup_plan=identity(S/'cleanup-plan.json'),cleanup_script=identity(S/'cleanup-script.ps1'),
 previous_evidence=['docs/evidence/performance/qwen-paged-native-cost-2026-10-21.json',
  'docs/evidence/performance/qwen-retirement-publication-2026-10-21.json',
  'docs/evidence/correctness/qwen-native-retirement-2026-10-21.json'],
 next='Safe exclusive committed-prefix read/unique tail append authority with failure isolation and actual native retirement; reduce remaining host preparation/published-page permission work and metadata cold waits without weakening exact-state/cache semantics. Continue MTP/images/architecture afterward; goal remains active.'))
save(S/'published.json',dict(files=[identity(report_path),identity(archive)],archive_files=len(inventory),
 uncompressed_bytes=sum(x['bytes']for x in inventory)))
print(json.dumps(read(S/'published.json'),indent=2))
