"""Reuse the bounded99-token analyzer for one actual current timeline; historical counts only."""
from pathlib import Path
import json
S=Path(__file__).resolve().parent;R=S.parents[1]
N=R/'.scratch/paged-native-cost-20261021'
source=(N/'analyze_native.py').read_text(encoding='utf-8')
source=source.split("arms={arm:analyze(arm)for arm in ['current','dense']}")[0]
pairs=[
 ("expected = read(R/'.scratch/paged-retirement-20261021/performance/timing/inputs.json')",
  "expected = read(S/'performance/timing/inputs.json')"),
 ("baseline_file = R/'.scratch/paged-retirement-20261021/performance/timing'/('01-current' if arm=='current' else '03-dense')/'stdout.log'",
  "baseline_file = S/'performance/timing/01-current/stdout.log'")]
for old,new in pairs:
 assert source.count(old)==1
 source=source.replace(old,new)
exec(compile(source,str(Path(__file__).resolve()),'exec'),globals())
current=analyze('current')
historical=read(N/'native-analysis.json')
assert current['verified99IDs_sha256']==historical['arms']['current']['verified99IDs_sha256']
def shape(arm):
 from collections import Counter
 return dict(calls=len(arm['decode_steps']),
   GraphLaunch_counts=dict(Counter(str(x['totals']['GraphLaunch_count'])for x in arm['decode_steps'])),
   kernel_counts=dict(Counter(str(x['totals']['kernel_count'])for x in arm['decode_steps'])),
   total_eager_D2D=arm['groups']['all96decode']['totals']['eager_D2D_count'],
   zero_record_calls=arm['groups']['pure90decode']['calls'])
report=dict(status='Actual current profile/export exit0,99 IDs and96 decode device anchors verified',
 script=identity(__file__),reused_analyzer=identity(N/'analyze_native.py'),current=current,
 physical_counts=dict(current=shape(current),prior_paged=shape(historical['arms']['current']),
   original_dense=shape(historical['arms']['dense'])),
 historical_evidence=identity(N/'native-analysis.json'),
 limits=historical['limits']+[
   'Exactly one NEW instrumented current process. Prior paged and dense profiles are retained historical separate windows and images; only physical command/count mechanisms compared here, never speedup estimates.',
   'The unprofiled12 timing plus4 memory processes are separate and define the new public performance table.',
   'No native field access or capture-count assertion was weakened. Diagnostic Copy-owner rebind is separate from this actual Qwen trace.'])
p=S/'native-analysis.json';p.write_text(json.dumps(report,indent=2,allow_nan=False)+'\n',encoding='utf-8')
print(json.dumps(dict(report=identity(p),physical_counts=report['physical_counts']),indent=2))
