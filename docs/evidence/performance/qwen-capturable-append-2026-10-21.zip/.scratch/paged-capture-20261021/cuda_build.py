"""Two CUDA backend host owners and one cached-toolchain device TU, no SDK rebuild."""
from pathlib import Path
import concurrent.futures
import importlib.util
import sys
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent
R=S.parents[1]
A=R/'.scratch/architecture-refactor-2026-10-18'
sp=importlib.util.spec_from_file_location('retained',R/'.scratch/paged-retirement-20261021/build.py')
h=importlib.util.module_from_spec(sp);sp.loader.exec_module(h)
b,c=h.b,h.c
recipe=A/'d4-windows-preparation-2026-10-21/first-decode-startup-2026-10-21/native-fix/checks/attempt1/backend/identity.json'
prior=c.read(recipe)

def host(job):
    tag,relative=job;source=R/relative
    out=S/'cuda/checks1'/tag;out.mkdir(parents=True,exist_ok=False);(out/'tmp').mkdir()
    flags=prior['command'].copy()
    if '/WX' not in flags:flags.append('/WX')
    command=b.host_command(flags,source,tag,out)
    frozen=b.identity(source)
    c.save(out/'compile-plan.json',dict(command=command,source=frozen,recipe=b.identity(recipe),CXX=1,NVCC=0,SDK_builds=0))
    env,_=b.environment(command,[],out);c.execute('compile',command,env,out)
    deps=c.read(out/(tag+'-deps.json'))['Data']
    record=dict(source=frozen,object=b.identity(out/(tag+'.obj')),command=command,
        dependencies=[b.identity(p)for p in dict.fromkeys([deps['Source'],*deps['Includes']])])
    if tag=='backend':record['replaced_object']=prior['object']
    assert h.h.same(frozen)and all(h.h.same(x)for x in record['dependencies'])
    c.save(out/'identity.json',record);return record

def device():
    source=R/'src/compute_backend_cuda/cuda_paged_append.cu'
    out=S/'cuda/checks1/kernel';out.mkdir(parents=True,exist_ok=False);(out/'tmp').mkdir()
    cuda=Path('C:/Program Files/NVIDIA GPU Computing Toolkit/CUDA/v13.3')
    image=out/'kernel.obj'
    command=[str(cuda/'bin/nvcc.exe'),'-forward-unknown-to-host-compiler',
        '-ccbin',str(Path(prior['command'][0]).parent),
        '-DHYLE_COMPUTE_BACKEND_CUDA_BUILD','-DHYLE_COMPUTE_CUDA=1','-DHYLE_STATIC',
        '-I'+str(R/'include'),'-I'+str(R/'src/compute_backend_cuda'),'-I'+str(R/'src/compute'),
        '-isystem',str(cuda/'include'),'-isystem',str(cuda/'include/cccl'),
        '-D_WINDOWS','-Xcompiler=/EHsc','-Xcompiler=/O2,/Ob2','-DNDEBUG','-std=c++20',
        '--generate-code=arch=compute_89,code=[compute_89,sm_89]',
        '-Xcompiler=/MD,/utf-8,/wd4211','-MD','-MT',str(image),'-MF',str(out/'kernel.obj.d'),
        '-x','cu','-c',str(source),'-o',str(image),'-Xcompiler=/Fd'+str(out/'kernel.pdb')+',/FS']
    frozen=[b.identity(p)for p in (source,R/'src/compute_backend_cuda/cuda_paged_append.h',R/'include/hyle/compute/detail/paged_append_wire.h')]
    env,_=b.environment(prior['command'],[],out)
    c.save(out/'compile-plan.json',dict(command=command,source=frozen[0],sources=frozen,
        cached_ninja_recipe='device_status_kernel.cu: build-compute-v2-dev/build.ninja1824/rules.ninja624',
        architecture='Cached local89 PTX+sm89, not a normal-default cross-device certification',CXX=0,NVCC=1,SDK_builds=0))
    c.execute('compile',command,env,out)
    assert all(h.h.same(x)for x in frozen)
    record=dict(source=frozen[0],object=b.identity(image),command=command,dependencies=frozen,
        depfile=b.identity(out/'kernel.obj.d'),NVCC=1,SDK_builds=0)
    c.save(out/'identity.json',record);return record

with concurrent.futures.ThreadPoolExecutor(max_workers=2)as pool:
    records=list(pool.map(host,[('backend','src/compute_backend_cuda/cuda_backend.cc'),
        ('append-host','src/compute_backend_cuda/cuda_paged_append.cc')]))
records.append(device())
c.save(S/'cuda/compiled1.json',dict(records=records,CXX=2,NVCC=1,SDK_builds=0,GPU_runs=0))
print('CUDA_LEAF_READY',flush=True)
