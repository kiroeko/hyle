"""Current common resource owner only; other implementation owners compile after freeze."""
from pathlib import Path
import importlib.util
import sys
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent
R=S.parents[1]
T=R/'.scratch/paged-retirement-20261021'
sp=importlib.util.spec_from_file_location('retained',T/'build.py')
h=importlib.util.module_from_spec(sp);sp.loader.exec_module(h)
b,c=h.b,h.c
source=R/'src/graph/resources.cc'
recipe=T/'resources-compile1/identity.json'
out=S/'core/compile1';out.mkdir(parents=True,exist_ok=False);(out/'tmp').mkdir()
frozen=b.identity(source)
command=b.host_command(c.read(recipe)['command'],source,'resources',out)
c.save(out/'compile-plan.json',dict(command=command,source=frozen,recipe=b.identity(recipe),CXX=1,NVCC=0,SDK_builds=0))
env,_=b.environment(command,[],out);c.execute('compile',command,env,out)
deps=c.read(out/'resources-deps.json')['Data']
rows=[b.identity(p)for p in dict.fromkeys([deps['Source'],*deps['Includes']])]
assert all(h.h.same(x)for x in rows)and h.h.same(frozen)
c.save(out/'identity.json',dict(source=frozen,object=b.identity(out/'resources.obj'),command=command,
    replaced_object=c.read(recipe)['object'],dependencies=rows,CXX=1,NVCC=0,SDK_builds=0))
print('CORE_HOST_READY',flush=True)
