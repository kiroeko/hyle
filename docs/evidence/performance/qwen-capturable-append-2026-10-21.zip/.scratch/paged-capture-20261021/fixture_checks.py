"""Root serial CPU fallback then CUDA capture and numeric checks; no performance claim."""
from pathlib import Path
import argparse
S=Path(__file__).resolve().parent
R=S.parents[1]
parser=argparse.ArgumentParser()
parser.add_argument('mode',choices=('both','cpu','cuda'),default='both',nargs='?')
parser.add_argument('--attempt',type=int,default=1)
parser.add_argument('--ready-attempt',type=int)
args=parser.parse_args()
modes=('cpu','cuda')if args.mode=='both'else(args.mode,)
source=(R/'.scratch/qwen-prefix-20261021/run_fixtures.py').read_text(encoding='utf-8')
old="ready_path = S / f'{mode}-ready-attempt1.json'"
assert source.count(old)==1
source=source.replace(old,"ready_path = S / f'{mode}-ready-attempt{args.ready_attempt if args.ready_attempt else (2 if mode == \"cpu\" else 1)}.json'")
source=source.replace("for mode in ('cpu', 'cuda'):","for mode in modes:")
source=source.replace("folder = S / f'{mode}-run1'","folder = S / f'{mode}-run{args.attempt}'")
exec(compile(source,str(Path(__file__).resolve()),'exec'),globals())
