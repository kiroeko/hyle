"""Single bounded unprofiled comparison using the established four-arm workload and runner."""
from pathlib import Path
S=Path(__file__).resolve().parent
R=S.parents[1]
source=(R/'.scratch/paged-prepare-20261021/performance.py').read_text(encoding='utf-8')
pairs=[
 ("current=S / 'qwen-ready.json'","current=S / 'qwen-ready-attempt3.json'"),
 ("before=R / '.scratch/paged-recording-20261021/qwen-ready.json'","before=R / '.scratch/paged-native-cost-20261021/qwen-ready-attempt1.json'"),
 ('Compare current generic lookup/page-set changes to exact previous paged ff42 closure, dense Hyle and matched llama.cpp;',
  'Compare current metadata-driven native captured append to exact prior3859 paged, original dense Hyle and matched llama.cpp; prefix directory off;')]
for old,new in pairs:
 assert source.count(old)==1
 source=source.replace(old,new)
exec(compile(source,str(Path(__file__).resolve()),'exec'),globals())
