"""One current native timeline to verify physical capture shape; never tokens/s evidence."""
from pathlib import Path
S=Path(__file__).resolve().parent
R=S.parents[1]
source=(R/'.scratch/paged-native-cost-20261021/profile.py').read_text(encoding='utf-8')
pairs=[
 ("prior = c.read(R/'.scratch/paged-retirement-20261021/performance/timing/inputs.json')",
  "prior = c.read(S/'performance/timing/inputs.json')"),
 ("receipts = dict(current=R/'.scratch/paged-retirement-20261021/qwen-ready-attempt1.json', dense=W/'ready-for-root.json')",
  "receipts = dict(current=S/'qwen-ready-attempt3.json')"),
 ("b.identity(R/'.scratch/paged-retirement-20261021/performance/timing/inputs.json')",
  "b.identity(S/'performance/timing/inputs.json')")]
for old,new in pairs:
 assert source.count(old)==1
 source=source.replace(old,new)
exec(compile(source,str(Path(__file__).resolve()),'exec'),globals())
