"""Original real-CUDA native-retirement probe; current binary, retained command template."""
from pathlib import Path
S=Path(__file__).resolve().parent
R=S.parents[1]
source=(R/'.scratch/paged-retirement-20261021/run_probe.py').read_text(encoding='utf-8')
old="read(S / 'probe/report.json')"
assert source.count(old)==1
source=source.replace(old,"read(R / '.scratch/paged-retirement-20261021/probe/report.json')")
exec(compile(source,str(Path(__file__).resolve()),'exec'),globals())
