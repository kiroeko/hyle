"""Read-only offline attribution of root's two native timelines; no target launch."""
from pathlib import Path
from collections import Counter, defaultdict
import bisect
import hashlib
import json
import re
import sqlite3
import statistics
import sys
sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
R = S.parents[1]


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def identity(path):
    p = Path(path).resolve()
    return dict(path=str(p), bytes=p.stat().st_size,
                sha256=hashlib.sha256(p.read_bytes()).hexdigest())


def merged(intervals):
    out = []
    for lo, hi in sorted(intervals):
        if hi <= lo:
            continue
        if out and lo <= out[-1][1]:
            out[-1][1] = max(out[-1][1], hi)
        else:
            out.append([lo, hi])
    return out


def union(intervals):
    return sum(hi-lo for lo, hi in merged(intervals))


def clips(rows, lo, hi):
    return [(max(lo, r['start']), min(hi, r['end'])) for r in rows]


def gaps(intervals, lo, hi):
    out, at = [], lo
    for a, b in merged(intervals):
        if a > at:
            out.append((at, a))
        at = max(at, b)
    if at < hi:
        out.append((at, hi))
    return out


def intersections(a, b):
    a, b = merged(a), merged(b)
    out, i, j = [], 0, 0
    while i < len(a) and j < len(b):
        lo, hi = max(a[i][0], b[j][0]), min(a[i][1], b[j][1])
        if hi > lo:
            out.append((lo, hi))
        if a[i][1] <= b[j][1]:
            i += 1
        else:
            j += 1
    return out


def stats(values):
    values = list(values)
    return dict(count=len(values), min=min(values), median=statistics.median(values),
                max=max(values), mean=statistics.mean(values)) if values else None


def log_steps(stderr):
    out, prepared = [], None
    fields = lambda line: dict(re.findall(r'(\w+)=([^\s]+)', line))
    for line in stderr.splitlines():
        if line.startswith('prepared T='):
            prepared = fields(line)
        match = re.match(r'^(round(\d+)_(prefill|decode(\d+))) tokens=', line)
        if not match:
            continue
        f = fields(line)
        assert prepared and int(prepared['visible']) == int(f['visible'])
        out.append(dict(ordinal=len(out), name=match[1], turn=int(match[2]),
            kind='prefill' if match[3] == 'prefill' else 'decode',
            local=int(match[4]) if match[4] else None, tokens=int(f['tokens']),
            visible=int(f['visible']), next=int(f['next']),
            recorded=int(prepared['capture_recorded']), reused=int(prepared['capture_reused']),
            cold_batch_ns=round(float(prepared['cold_batch_seconds'])*1e9),
            step_ns=round(float(f['step_seconds'])*1e9)))
        prepared = None
    assert len(out) == 99 and prepared is None
    return out


def kernel_family(name):
    if 'gemvx::kernel' in name or 'mul_mat_vec_f<' in name:
        return 'matvec_projection'
    if 'gated_delta_net' in name:
        return 'GDN_core'
    if 'ssm_conv' in name:
        return 'causal_convolution'
    if 'flashinfer::' in name or 'flash_attn_ext' in name:
        return 'attention_and_merge'
    if 'set_rows' in name or 'single_update' in name:
        return 'dense_KV_scatter'
    if 'ArgPair<' in name or 'ArgValue<' in name or 'ArgIndex<' in name or 'argmax' in name:
        return 'argmax'
    return 'other'


def grouped(rows, field='name', limit=None):
    groups = defaultdict(lambda: [0, 0])
    for r in rows:
        groups[str(r[field])][0] += 1
        groups[str(r[field])][1] += r['end']-r['start']
    values = [dict(name=k, count=v[0], inclusive_ns=v[1]) for k, v in groups.items()]
    return sorted(values, key=lambda r: -r['inclusive_ns'])[:limit]


def analyze(arm):
    out = S/arm
    plan = read(out/'plan.json')
    for tag in ['profile', 'export']:
        result = read(out/(tag+'.result.json'))
        assert result['exit'] == 0 and result['terminal']
        assert result['command'] == plan['commands'][tag]
    expected = read(R/'.scratch/paged-retirement-20261021/performance/timing/inputs.json')
    assert identity(plan['image']['path']) == plan['image'] == expected['images'][arm]
    assert '--trace' not in plan['commands']['profile'][11:]
    c = sqlite3.connect((out/'capture.sqlite').resolve().as_uri()+'?mode=ro', uri=True)
    c.execute('pragma query_only=ON')
    c.row_factory = sqlite3.Row
    tables = {r[0] for r in c.execute("select name from sqlite_master where type='table'")}
    strings = dict(c.execute('select id,value from StringIds'))
    logs = {}
    for row in c.execute('select * from ProcessStreams'):
        filename = strings[row['filenameId']]
        for kind in ['stdout', 'stderr']:
            if '/'+kind+'_' in filename.replace('\\', '/'):
                assert kind not in logs
                logs[kind] = dict(metadata=dict(row), filename=filename, text=strings[row['contentId']])
                (out/('model.'+kind+'.extracted.log')).write_text(logs[kind]['text'])
    assert set(logs) == {'stdout', 'stderr'}
    pid = logs['stdout']['metadata']['globalPid']
    assert logs['stderr']['metadata']['globalPid'] == pid
    raw = json.loads(next(line for line in reversed(logs['stdout']['text'].splitlines()) if line.startswith('{')))
    steps = log_steps(logs['stderr']['text'])
    assert [raw[k] for k in ['processed_tokens', 'generated_tokens', 'phase_count', 'turn_count']] == [864,99,6,3]
    baseline_file = R/'.scratch/paged-retirement-20261021/performance/timing'/('01-current' if arm=='current' else '03-dense')/'stdout.log'
    baseline = json.loads(next(line for line in reversed(baseline_file.read_text().splitlines()) if line.startswith('{')))
    assert raw['generated_ids'] == baseline['generated_ids'] == [x['next'] for x in steps]
    assert raw.get('prefix_cache','off') == 'off' and not raw['diagnostic']
    assert [i for i,x in enumerate(steps) if x['kind']=='prefill'] == [0,33,66]
    assert sum(x['kind']=='decode' for x in steps) == 96
    assert [x['visible'] for x in steps] == [x['visible'] for x in log_steps((baseline_file.parent/'stderr.log').read_text())]

    def rows(table):
        if table not in tables:
            return []
        data = [dict(r) for r in c.execute('select * from '+table+' order by start')]
        assert len({tuple(r.values()) for r in data}) == len(data), 'unexpected duplicate actual activities'
        return data

    api = rows('CUPTI_ACTIVITY_KIND_RUNTIME')
    for r in api:
        r['name'] = strings[r['nameId']]
    kernels = rows('CUPTI_ACTIVITY_KIND_KERNEL')
    for r in kernels:
        r['name'] = strings[r['demangledName']]
        r['family'] = kernel_family(r['name'])
    copies, sets = rows('CUPTI_ACTIVITY_KIND_MEMCPY'), rows('CUPTI_ACTIVITY_KIND_MEMSET')
    assert all(r['globalPid']==pid for r in kernels+copies+sets)
    assert {r['deviceId'] for r in kernels+copies+sets} == {0}
    kinds = {r[0]:r[2] for r in c.execute('select * from ENUM_CUDA_MEMCPY_OPER')}
    diagnostics = [dict(r) for r in c.execute('select *from DIAGNOSTIC_EVENT')]
    c.close()
    corr = defaultdict(list)
    for r in api:
        corr[r['correlationId']].append(r)
    dtoh = [r for r in copies if r['copyKind']==2]
    assert len(dtoh)==99 and all(r['bytes']==4 for r in dtoh)
    anchors = []
    for step, copy in zip(steps,dtoh,strict=True):
        a = corr[copy['correlationId']]
        assert len(a)==1 and 'MemcpyDtoH' in a[0]['name'] and a[0]['end']>=copy['end']
        anchors.append(dict(**step, host_API_end=a[0]['end'], host_API_start=a[0]['start'],
            host_API_name=a[0]['name'], correlationId=copy['correlationId'], globalTid=a[0]['globalTid'],
            copy_start=copy['start'],copy_end=copy['end']))
    assert all(b['host_API_end']>a['host_API_end'] for a,b in zip(anchors,anchors[1:]))
    starts = {id(data):[r['start']for r in data] for data in [api,kernels,copies,sets]}

    def select(data,lo,hi):
        # Include an API spanning an anchor, then clip all durations to the window.
        return [r for r in data[:bisect.bisect_left(starts[id(data)],hi)] if r['end']>lo]

    reports, selected_rows = [], {}
    for index, anchor in enumerate(anchors):
        if anchor['kind']!='decode':
            continue
        lo,hi = anchors[index-1]['host_API_end'],anchor['host_API_end']
        aa,kk,cc,zz = [select(data,lo,hi)for data in [api,kernels,copies,sets]]
        for r in aa+kk+cc+zz:
            assert r['start']>=lo and r['end']<=hi, ('activity crosses token envelope',arm,index)
        busy = merged(clips(kk+cc+zz,lo,hi))
        gg = gaps(busy,lo,hi)
        main_api = [r for r in aa if r['globalTid']==anchor['globalTid']]
        api_gap = intersections(gg,clips(aa,lo,hi))
        main_api_gap = intersections(gg,clips(main_api,lo,hi))
        launch = [r for r in aa if 'GraphLaunch' in r['name']]
        event_create = [r for r in aa if 'EventCreate' in r['name']]
        copy_api = [r for r in aa if 'Memcpy' in r['name'] and r['correlationId']!=anchor['correlationId']]
        eager_d2d = [r for r in cc if r['copyKind']==8 and not r.get('graphNodeId')]
        first_kernel = min(r['start']for r in kk)
        last_kernel = max(r['end']for r in kk)
        graph_ranges = {}
        for r in kk:
            if r.get('graphId'):
                g = graph_ranges.setdefault(r['graphId'],[r['start'],r['end']])
                g[0] = min(g[0],r['start']);g[1] = max(g[1],r['end'])
        graph_ranges = sorted(graph_ranges.values())
        transitions = [(a[1],b[0])for a,b in zip(graph_ranges,graph_ranges[1:])]
        assert all(a<=b for a,b in transitions)
        totals = dict(envelope_ns=hi-lo,kernel_count=len(kk),graph_node_kernels=sum(bool(r.get('graphNodeId'))for r in kk),
            kernel_sum_ns=sum(r['end']-r['start']for r in kk),kernel_union_ns=union(clips(kk,lo,hi)),
            copy_count=len(cc),copy_bytes=sum(r['bytes']for r in cc),copy_sum_ns=sum(r['end']-r['start']for r in cc),
            copy_union_ns=union(clips(cc,lo,hi)),eager_D2D_count=len(eager_d2d),eager_D2D_bytes=sum(r['bytes']for r in eager_d2d),
            eager_D2D_union_ns=union(clips(eager_d2d,lo,hi)),memset_count=len(zz),
            device_busy_union_ns=union(busy),no_traced_device_ns=union(gg),
            no_device_with_any_API_ns=union(api_gap),no_device_with_main_API_ns=union(main_api_gap),
            no_device_no_recorded_API_ns=union(gg)-union(api_gap),API_count=len(aa),
            no_device_before_first_kernel_ns=union(intersections(gg,[(lo,first_kernel)])),
            no_device_inside_kernel_span_ns=union(intersections(gg,[(first_kernel,last_kernel)])),
            no_device_after_last_kernel_ns=union(intersections(gg,[(last_kernel,hi)])),
            GraphLaunch_count=len(launch),GraphLaunch_API_ns=union(clips(launch,lo,hi)),
            GraphLaunch_during_no_device_ns=union(intersections(gg,clips(launch,lo,hi))),
            non_token_Memcpy_API_count=len(copy_api),non_token_Memcpy_API_ns=union(clips(copy_api,lo,hi)),
            non_token_Memcpy_during_no_device_ns=union(intersections(gg,clips(copy_api,lo,hi))),
            GraphLaunch_or_Memcpy_during_no_device_ns=union(intersections(gg,clips(launch+copy_api,lo,hi))),
            graph_kernel_ranges=len(graph_ranges),inter_graph_kernel_ranges=len(transitions),
            inter_graph_kernel_range_ns=union(transitions),
            inter_graph_kernel_range_device_busy_ns=union(intersections(transitions,busy)),
            inter_graph_kernel_range_no_device_ns=union(intersections(transitions,gg)),
            EventCreate_count=len(event_create),EventRecord_count=sum('EventRecord' in r['name']for r in aa),
            EventSync_count=sum('EventSynchronize' in r['name']for r in aa),
            EventQuery_count=sum('EventQuery' in r['name']for r in aa),
            StreamSync_count=sum('StreamSynchronize' in r['name']for r in aa))
        assert totals['device_busy_union_ns']+totals['no_traced_device_ns']==hi-lo
        reports.append(dict(**{k:anchor[k]for k in ['ordinal','name','turn','local','visible','recorded','reused','cold_batch_ns','step_ns']},
            envelope_start_ns=lo,envelope_end_ns=hi,totals=totals))
        selected_rows[index] = (aa,kk,cc,zz,gg)

    def aggregate(selected):
        ids = {r['ordinal']for r in selected}
        aa,kk,cc,zz,gg = [sum((selected_rows[i][j]for i in ids),[])for j in range(5)]
        values={key:sum(r['totals'][key]for r in selected)for key in selected[0]['totals']}
        sizes=defaultdict(lambda:dict(count=0,bytes=0,inclusive_ns=0,eager_count=0))
        for r in cc:
            g=sizes[(r['copyKind'],r['bytes'])];g['count']+=1;g['bytes']+=r['bytes'];g['inclusive_ns']+=r['end']-r['start'];g['eager_count']+=not bool(r.get('graphNodeId'))
        return dict(calls=len(selected),totals=values,per_call={k:stats(r['totals'][k]for r in selected)for k in values},
            APIs=grouped(aa),kernel_families=grouped(kk,'family'),kernels_top=grouped(kk,limit=12),
            copies_by_kind_size=[dict(kind=k[0],kind_name=kinds[k[0]],bytes_each=k[1],**v)for k,v in sorted(sizes.items())],
            top_no_device_gaps=[dict(start_ns=lo,end_ns=hi,duration_ns=hi-lo,
                overlapping_APIs=grouped([dict(r,start=max(lo,r['start']),end=min(hi,r['end']))for r in aa if r['start']<hi and r['end']>lo],limit=6))for lo,hi in sorted(gg,key=lambda x:x[1]-x[0],reverse=True)[:8]])

    groups={'all96decode':aggregate(reports),'pure90decode':aggregate([r for r in reports if r['recorded']==0])}
    assert groups['pure90decode']['calls']==90
    for turn in range(1,4):
        group=[r for r in reports if r['turn']==turn]
        assert len(group)==32 and [r['local']for r in group if r['recorded']>0]==[1,2]
        groups[f'turn{turn}_all32']=aggregate(group)
        groups[f'turn{turn}_pure30']=aggregate([r for r in group if r['recorded']==0])
    return dict(arm=arm,image=plan['image'],plan=identity(out/'plan.json'),sqlite=identity(out/'capture.sqlite'),
        profile=identity(out/'profile.result.json'),export=identity(out/'export.result.json'),
        ProcessStreams={kind:dict(metadata=v['metadata'],filename=v['filename'],extracted=identity(out/('model.'+kind+'.extracted.log')))for kind,v in logs.items()},
        unprofiled_log=identity(baseline_file),verified99IDs_sha256=hashlib.sha256(json.dumps(raw['generated_ids']).encode()).hexdigest(),
        diagnostics=diagnostics,actual_token_anchors=anchors,decode_steps=reports,groups=groups,
        full_run_counts=dict(kernels=len(kernels),copies=len(copies),APIs=len(api),memsets=len(sets)),
        tables_present=sorted(tables))


arms={arm:analyze(arm)for arm in ['current','dense']}
assert arms['current']['verified99IDs_sha256']==arms['dense']['verified99IDs_sha256']
deltas={}
for group in arms['current']['groups']:
    a,b=[arms[arm]['groups'][group]for arm in ['current','dense']]
    assert a['calls']==b['calls']
    difference={key:a['totals'][key]-b['totals'][key]for key in a['totals']}
    deltas[group]=dict(calls=a['calls'],current_minus_dense_totals=difference,
        current_minus_dense_mean_per_call={k:v/a['calls']for k,v in difference.items()})

result=dict(status='offline completed; two actual root profile/export exit0,99ID and96decode mappings verified',
    script=identity(__file__),discovery=identity(S/'profiler-discovery.json'),arms=arms,current_minus_dense=deltas,
    limits=['Exactly one instrumented native process per arm; no tokens/s result or unprofiled speedup attribution.',
        'Both traces warn driver13.4 is not directly supported by this NSYS build and use13.3 collector/legacy software instrumentation; all warnings retained. No hardware tracing/counters were collected.',
        'Device busy is interval union of actual kernels/copies/memsets across streams. API inclusive time, kernel sum and wall are not additive. EventSynchronize often overlaps actual GPU execution and is not removable overhead.',
        'All96decode is primary;90pure reuse excludes only actual first2recording calls in each turn and is supplementary. Actual capture metadata from ProcessStreams decides this selection.',
        'Each token envelope runs from previous4B DtoH hostAPI end to current4B DtoH hostAPI end. Snapshot publication is after token read and can be shifted into the next envelope; final publication is outside the last endpoint. These envelopes are not exact source phase/step clocks.',
        'No traced device activity is a measurable union complement. An interval with no recorded API is not a CPU-function measurement, proof of CPU idleness or proof it is removable; CPU sampling is disabled.',
        'Copy payload GPU durations/bytes are reported separately from memcpy submission API durations and GraphLaunch costs; overlapping time cannot be summed into a claimed total saving.',
        'One run cannot isolate changed pointers/layout, clock/load variation and nonlinear software tracing overhead; any dominant-cost claim must remain bounded by these actual observed buckets.',
        'No product/source build or GPU query/launch by this analyzer. SQLite opened mode=ro and query_only; only scratch reports/extracted logs are written.'])
target=S/'native-analysis.json';target.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(dict(report=identity(target),groups={arm:{g:dict(calls=r['calls'],totals=r['totals'])for g,r in data['groups'].items()if g in ['all96decode','pure90decode']}for arm,data in arms.items()},delta=deltas['all96decode']),indent=2))
