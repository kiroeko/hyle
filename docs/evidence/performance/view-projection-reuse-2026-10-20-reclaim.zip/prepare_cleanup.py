"""Prepare exact deletion of archived experiments, superseded images and duplicate vectors."""
from pathlib import Path
import hashlib
import json
S = Path(__file__).resolve().parent
A = S.parent
ROOT = A.parents[1]
def read(p):
    return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def identity(p):
    p = Path(p).resolve()
    data = p.read_bytes()
    return dict(path=str(p), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())
def check(row):
    actual = identity(row['path'])
    assert all(actual[k] == row[k] for k in ('bytes', 'sha256'))
    return actual
receipt_names = ['docs/evidence/performance/view-projection-reuse-2026-10-20-archive.json',
    'docs/evidence/performance/dual-matvec-row-tiles-2026-10-20-archive.json',
    'docs/evidence/correctness/ga-dense-indexer-cuda-2026-10-20-archive.json',
    'docs/evidence/performance/qwen35-full-cuda-2026-10-19/cast-stable-silu-archive.json',
    'docs/evidence/performance/qwen35-full-cuda-2026-10-19/binding-port-reuse-archive.json']
evidence = []
for name in receipt_names:
    path = ROOT / name
    receipt = read(path)
    assert receipt['crc_verified'] and receipt['payload_sha256_verified']
    evidence += [check(receipt), identity(path)]
plan_path = Path(read(S / 'latest-check.json')['plan'])
out = plan_path.parent
retained = [check(read(out / (arm + '-image.json'))) for arm in ('qwen', 'cpu')]
retained += [check(read(A / 'cccl-single-row-topk/checks/20261019T185912-host/qwen-image.json')),
             check(read(A / 'cuda-explicit-rope/performance-prepared/peer-image.json'))]
targets, references = {}, {}
def target(p):
    p = Path(p).resolve()
    assert p.is_file() and p.is_relative_to(ROOT / '.scratch')
    targets[str(p).casefold()] = identity(p)
experimental = Path(read(A / 'projection-hotspot-review/experiment-check.json')['plan']).parent / 'dual-rows-bench.exe'
images = [experimental, A / 'projection-hotspot-review/hot-prepare-diagnostic/qwen-diagnostic.exe',
    S / 'prepare-comparison/qwen-diagnostic.exe',
    Path(check(read(A / 'ga-dense-indexer/checks/20261019T184046-metadata-boundaries/qwen-image.json'))['path']),
    Path(check(read(A / 'cast-stable-silu/checks/20261019T180121/qwen-image.json'))['path']),
    Path(check(read(A / 'binding-port-reuse/checks/20261019T174851/cpu-image.json'))['path'])]
assert len(images) == 6
for image in [*images, *(Path(r['path']) for r in retained[:2])]:
    suffixes = ('.exe', '.map', '.lib', '.exp', '.pdb') if image in images else ('.map', '.lib', '.exp', '.pdb')
    for suffix in suffixes:
        p = image.with_suffix(suffix)
        if p.exists():
            target(p)
observation = read(S / 'correctness/summary.json')['observation']
assert observation['equal_vectors'] == len(observation['vectors']) == 64
for row in observation['vectors']:
    actual, reference = check(row['actual']), check(row['reference'])
    assert row['byte_equal'] and actual['sha256'] == reference['sha256']
    references[str(Path(reference['path'])).casefold()] = reference
    target(actual['path'])
assert len(references) == 64
build = read(plan_path)
inputs = {str(Path(p).resolve()).casefold() for link in build['links'].values() for p in link['inputs']}
assert not set(targets).intersection(inputs)
assert not set(targets).intersection(str(Path(r['path']).resolve()).casefold()
    for r in [*retained, *references.values(), *evidence])
cleanup = dict(evidence=evidence, retained_images=retained, retained_vectors=list(references.values()),
    current_build_plan=identity(plan_path), targets=list(targets.values()), count=len(targets),
    total_bytes=sum(r['bytes'] for r in targets.values()), recursive=False,
    scope='Six archived experiment/superseded images, link side products including current map/import outputs, and64 duplicate model vectors. Keep current CPU/Qwen, immediate Qwen baseline/peer, every actual link object/library/source/SDK and64original vectors.')
path = S / 'cleanup-plan.json'
assert not path.exists()
path.write_text(json.dumps(cleanup, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
previous = ROOT / 'test.ps1'
old = previous.read_bytes()
(S / 'test-before-reclaim.ps1').write_bytes(old)
script = old.decode('utf-8-sig')
prior_hash = identity(A / 'cccl-single-row-topk/cleanup-plan.json')['sha256']
assert prior_hash in script
script = script.replace('cccl-single-row-topk\\cleanup-plan.json', 'view-projection-reuse\\cleanup-plan.json')
script = script.replace('cccl-single-row-topk\\cleanup-result.json', 'view-projection-reuse\\cleanup-result.json')
script = script.replace(prior_hash, identity(path)['sha256'])
assert 'cccl-single-row-topk\\cleanup-' not in script
for p in (previous, S / 'executed-reclaim.ps1'):
    with p.open('w', encoding='utf-8', newline='\n') as f:
        f.write(script)
print(json.dumps(dict(files=cleanup['count'], bytes=cleanup['total_bytes'],
    MiB=cleanup['total_bytes'] / 1024**2, plan=identity(path), deletion_executed=False), indent=2))
