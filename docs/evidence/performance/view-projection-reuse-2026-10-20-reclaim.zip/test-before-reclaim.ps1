$ErrorActionPreference = 'Stop'
$workspace = (Resolve-Path -LiteralPath 'C:\public\project-hyle\hyle\.scratch').Path
$planPath = 'C:\public\project-hyle\hyle\.scratch\architecture-refactor-2026-10-18\cccl-single-row-topk\cleanup-plan.json'
if ((Get-FileHash -LiteralPath $planPath -Algorithm SHA256).Hash.ToLowerInvariant() -ne '7050c5b1879dd1725f7a00d8e9130216d7c369d29ac041adebe8c767b34b8886') { throw 'Cleanup plan differs' }
$plan = Get-Content -LiteralPath $planPath -Raw | ConvertFrom-Json
function Assert-Identity($row) {
    $item = Get-Item -LiteralPath $row.path -Force
    if ($item.PSIsContainer -or $item.Length -ne $row.bytes -or (Get-FileHash -LiteralPath $item.FullName -Algorithm SHA256).Hash.ToLowerInvariant() -ne $row.sha256) { throw "File differs: $($row.path)" }
}
foreach ($row in @($plan.evidence) + @($plan.retained_images) + @($plan.retained_vectors) + @($plan.current_build_plan)) { Assert-Identity $row }
$build = Get-Content -LiteralPath $plan.current_build_plan.path -Raw | ConvertFrom-Json
$inputs = @()
foreach ($entry in $build.links.PSObject.Properties) { $inputs += @($entry.Value.inputs) }
foreach ($row in $plan.targets) {
    $item = Get-Item -LiteralPath $row.path -Force
    if (-not $item.FullName.StartsWith($workspace + '\', [System.StringComparison]::OrdinalIgnoreCase) -or $item.PSIsContainer -or ($item.Attributes -band [System.IO.FileAttributes]::ReparsePoint)) { throw 'Unexpected target path' }
    $parent = $item.Directory
    while ($parent.FullName.StartsWith($workspace, [System.StringComparison]::OrdinalIgnoreCase)) {
        if ($parent.Attributes -band [System.IO.FileAttributes]::ReparsePoint) { throw 'Reparse point in target ancestry' }
        if ($parent.FullName -eq $workspace) { break }
        $parent = $parent.Parent
    }
    if ($inputs -contains $item.FullName) { throw 'Target is an actual retained link input' }
    Assert-Identity $row
}
foreach ($row in $plan.targets) { Remove-Item -LiteralPath $row.path -Force }
foreach ($row in $plan.targets) { if (Test-Path -LiteralPath $row.path) { throw 'Target remains' } }
foreach ($row in $plan.retained_images) { Assert-Identity $row }
foreach ($row in $plan.retained_vectors) { Assert-Identity $row }
@{ deleted_files = $plan.count; deleted_bytes = $plan.total_bytes; targets = $plan.targets; retained_images = $plan.retained_images; retained_reference_vectors = @($plan.retained_vectors).Count; evidence = $plan.evidence; recursive = $false; all_link_inputs_retained = $true } | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath 'C:\public\project-hyle\hyle\.scratch\architecture-refactor-2026-10-18\cccl-single-row-topk\cleanup-result.json' -Encoding utf8
