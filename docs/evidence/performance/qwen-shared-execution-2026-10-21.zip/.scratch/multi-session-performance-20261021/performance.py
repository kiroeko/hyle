"""One finite true-prefix three-arm timing/memory window, serial GPU only."""
from pathlib import Path
import argparse,importlib.util,json,os,sys
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent;R=S.parents[1]
F=R/'.scratch/architecture-refactor-2026-10-18/d4-windows-preparation-2026-10-21/first-decode-startup-2026-10-21'
sp=importlib.util.spec_from_file_location('retained_runner',F/'multiturn/multiturn_run.py');m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m)
p=argparse.ArgumentParser();p.add_argument('mode',choices=('timing','memory'));a=p.parse_args()
receipts=dict(current=R/'.scratch/paged-host-prepare-20261021/qwen-ready-attempt3.json',before=R/'.scratch/paged-exclusive-20261021/qwen-ready-attempt1.json',peer=S/'peer-ready-attempt1.json')
images={k:m.ready_image(v)for k,v in receipts.items()};plan=m.read(S/'inputs/plan.json');manifest=plan['manifest']['path']
hc,pc=m.original_commands();original_inputs=hc[hc.index('--inputs')+1];model=pc[1]
order=['current','before','peer','peer','before','current','before','current','peer']if a.mode=='timing'else['before','current','peer']
out=S/'performance'/a.mode;out.mkdir(parents=True,exist_ok=False)
commands=[]
for i,variant in enumerate(order,1):
 folder=out/f'{i:02}-{variant}'
 command=[images[variant]['path'],model,'--session-schedules',manifest,'--capacity','256','--cache-slots','4','--pool-tokens','1024','--result',str(folder/'peer-result.json')]if variant=='peer'else[images[variant]['path'],'--inputs',original_inputs,'--session-schedules',manifest,'--capacity','256','--max-sessions','4','--active-sequences','1','--prefix-cache','auto','--progress','direct','--replay','auto']
 commands.append(dict(variant=variant,folder=str(folder),command=command))
m.save(out/'inputs.json',dict(plan=plan,receipts={k:m.identity(v)for k,v in receipts.items()},images=images,order=order,commands=commands,mode=a.mode,
 profiler=False,diagnostic=False,concurrent_GPU=False,memory_interval_seconds=.01 if a.mode=='memory'else None,
 scope='Four named sessions, serial turn cohorts, exact complete-state checkpoint129 and two real suffix branches1/16, fullhit0Graph, source resume. Same645logical/102outputs, actual161P+97D,3prefixhits/1fullhit/387reused. No session eviction/restore or simultaneous GPU batch claim.'))
runs=[];reference=None;m.gpu_snapshot(out,'window-before')
try:
 for i,entry in enumerate(commands,1):
  variant=entry['variant'];folder=Path(entry['folder']);print('PREFIX_BEGIN',a.mode,i,variant,flush=True)
  env=os.environ.copy();env['PATH']=m.read(m.read(receipts[variant])['runtime_environment']['path'])['PATH']
  process=m.execute(folder,'peer'if variant=='peer'else'hyle',entry['command'],env,a.mode=='memory')
  data=m.read(folder/'peer-result.json')if variant=='peer'else json.loads((folder/'stdout.log').read_text(encoding='utf-8').splitlines()[-1])
  expected=dict(processed_tokens=645,generated_tokens=102,actual_graph_calls=101,actual_graph_tokens=258,prefix_hits=3,prefix_misses=2,prefix_full_hits=1,reused_tokens=387)
  assert all(data[k]==v for k,v in expected.items()),{k:(data[k],v)for k,v in expected.items()}
  phases=[v for session in data['sessions']for v in session['phases']]
  ids={session['id'if variant=='peer'else'session_id']:session['generated_ids']for session in data['sessions']}
  if reference is None:reference=ids
  assert ids==reference
  seconds={kind:sum(v['seconds']for v in phases if v['kind']==kind)for kind in ('prefill','decode')}
  wall=data['session_seconds'if variant=='peer'else'interleaved_seconds']
  metrics=dict(logical_prefill_tps=548/seconds['prefill'],actual_prefill_tps=161/seconds['prefill'],full_decode_tps=97/seconds['decode'],session_output_tps=102/wall,logical_session_tps=645/wall,actual_session_tps=258/wall,session_seconds=wall,startup_total_seconds=data['startup_total_seconds'])
  observation=dict(raw=data,metrics=metrics,ids=ids,phase_seconds=seconds)
  m.save(folder/'observation.json',observation);runs.append(dict(variant=variant,folder=str(folder),process=process,observation=observation));m.save(out/'runs.json',runs)
  print('PREFIX_END',a.mode,i,variant,process['exit'],flush=True)
finally:m.gpu_snapshot(out,'window-after')
groups={v:{key:m.stats([r['observation']['metrics'][key]for r in runs if r['variant']==v])for key in runs[0]['observation']['metrics']}for v in receipts}if a.mode=='timing'else{v:m.read(Path(next(r for r in runs if r['variant']==v)['folder'])/'memory-summary.json')for v in receipts}
m.save(out/'summary.json',dict(groups=groups,processes=len(runs),all_work_and_ids_equal=True,throughput_evidence=a.mode=='timing',quality_acceptance=False,concurrent_gpu_throughput=False))
print('PREFIX_COMPLETE',a.mode,len(runs),flush=True)
