// Consumer-only finite multi-session/prefix comparison. Retained SDK/math unchanged.
#define main retained_peer_single_session_main
#include "../../architecture-refactor-2026-10-18/d4-windows-preparation-2026-10-21/peer-continuation/peer_benchmark.cpp"
#undef main

#include <exception>
#include "tools/qwen35_text/session_schedule.h"
#include "../../architecture-refactor-2026-10-18/llama-matched-consumer/source/src/llama-memory.h"

namespace peer_prefix {
namespace schedule = qwen35::benchmark;
using Tokens = std::vector<llama_token>;

struct Pool;
struct Version {
    Pool * pool = nullptr;
    llama_seq_id id = -1;
    const Tokens * tokens = nullptr;
    std::size_t length = 0;
    llama_token next = LLAMA_TOKEN_NULL;
    ~Version();
};
struct Pool {
    llama_context * context;
    std::vector<bool> used;
    std::size_t live = 0, peak = 0;
    bool native_inflight = false;
    explicit Pool(llama_context * c, std::size_t count) : context(c), used(count, false) {}
    std::shared_ptr<Version> create() {
        const auto found = std::find(used.begin(), used.end(), false);
        if (found == used.end()) throw std::runtime_error("native sequence/version quota exhausted");
        const auto slot = static_cast<std::size_t>(found - used.begin());
        auto value = std::make_shared<Version>();
        value->pool = this; value->id = static_cast<llama_seq_id>(slot);
        used[slot] = true; ++live; peak = std::max(peak, live);
        return value;
    }
};
Version::~Version() {
    if (!pool) return;
    // Every call is synchronized before publication. Never recycle a native
    // seq id while an original decode or sampled-token access is in flight.
    if (pool->native_inflight) {
        llama_synchronize(pool->context);
        pool->native_inflight = false;
    }
    if (!llama_memory_seq_rm(llama_get_memory(pool->context), id, -1, -1)) std::terminate();
    pool->used[static_cast<std::size_t>(id)] = false;
    --pool->live;
}

struct Directory {
    struct Entry { std::shared_ptr<Version> version; std::uint64_t stamp; };
    std::vector<Entry> entries;
    std::size_t capacity, evictions = 0;
    std::uint64_t clock = 0;
    explicit Directory(std::size_t count) : capacity(count) { entries.reserve(count); }
    bool evict() {
        if (entries.empty()) return false;
        const auto oldest = std::min_element(entries.begin(), entries.end(),
            [](const Entry & a, const Entry & b) { return a.stamp < b.stamp; });
        entries.erase(oldest); ++evictions; return true;
    }
    std::shared_ptr<Version> lookup(const Tokens & target, std::size_t end, std::size_t minimum) {
        Entry * selected = nullptr;
        for (auto & entry : entries) {
            const auto & v = *entry.version;
            if (v.length < minimum || v.length > end || (selected && v.length <= selected->version->length)) continue;
            if (std::equal(v.tokens->begin(), v.tokens->begin() + static_cast<std::ptrdiff_t>(v.length), target.begin()))
                selected = &entry;
        }
        if (!selected) return {};
        selected->stamp = ++clock;
        return selected->version;
    }
    void publish(const std::shared_ptr<Version> & version) {
        for (auto & entry : entries) {
            const auto & old = *entry.version;
            if (old.length == version->length && std::equal(old.tokens->begin(),
                    old.tokens->begin() + static_cast<std::ptrdiff_t>(old.length), version->tokens->begin())) {
                entry.version = version; entry.stamp = ++clock; return;
            }
        }
        if (entries.size() == capacity) evict();
        entries.push_back({version, ++clock});
    }
};

struct Observation {
    std::string session, name;
    std::size_t turn = 0, logical_tokens = 0, graph_tokens = 0, visible = 0, reused = 0;
    llama_token next = LLAMA_TOKEN_NULL;
    bool prompt = false, hit = false, full_hit = false;
    double total = 0, lookup = 0, copy_api = 0, prepare = 0, decode = 0, synchronize = 0, sample = 0;
    std::uint32_t sampled_logits = 0;
    llama_seq_id source_seq = -1, target_seq = -1;
};
struct Phase {
    std::string name, begin_marker, end_marker;
    Point start{};
    double seconds = 0, step_sum = 0;
    std::size_t before = 0, after = 0;
};
struct Run {
    Tokens tokens;
    std::vector<Phase> phases;
    std::vector<llama_token> predictions;
    std::shared_ptr<Version> head;
    std::size_t visible = 0;
    Point start{}, endpoint{};
};
struct Call { std::size_t session, phase, local, first, count; };

std::size_t cache_bytes(llama_context * context) {
    // Exact retained private ABI, cold-only: these are actual KV + R/S buffer
    // sizes, excluding model and execution workspace. Not process VRAM usage.
    std::size_t total = 0;
    for (const auto & entry : llama_get_memory(context)->memory_breakdown()) {
        if (entry.second > (std::numeric_limits<std::size_t>::max)() - total)
            throw std::runtime_error("native cache backing byte sum overflow");
        total += entry.second;
    }
    return total;
}

static int run(const char * model_path, const char * manifest, std::size_t logical_capacity,
        std::size_t committed_limit, std::size_t pool_tokens, std::size_t byte_limit, const char * output_path) {
    const auto startup = Clock::now();
    constexpr std::int64_t vocabulary = 248320;
    if (logical_capacity == 0 || logical_capacity > static_cast<std::size_t>((std::numeric_limits<int32_t>::max)()) ||
        committed_limit == 0 || committed_limit >= LLAMA_MAX_SEQ ||
        pool_tokens < logical_capacity || pool_tokens > (std::numeric_limits<uint32_t>::max)())
        throw std::runtime_error("invalid capacity/committed-version/native-token-pool bounds");
    const auto schedules = schedule::read_session_schedules(manifest, vocabulary, logical_capacity, committed_limit, true);
    std::vector<Run> runs(schedules.size());
    std::vector<std::vector<Call>> session_calls(schedules.size());
    std::size_t total_calls = 0, logical_tokens = 0, batch_capacity = 1;
    for (std::size_t s = 0; s < schedules.size(); ++s) {
        auto & run = runs[s]; const auto & phases = schedules[s].phases;
        run.tokens.reserve(logical_capacity); run.phases.resize(phases.size());
        for (std::size_t p = 0; p < phases.size(); ++p) {
            const auto & phase = phases[p]; const bool prompt = phase.kind == schedule::PhaseKind::kPrompt;
            const auto first = run.tokens.size();
            run.tokens.insert(run.tokens.end(), phase.ids.begin(), phase.ids.end());
            logical_tokens += phase.ids.size();
            if (prompt) batch_capacity = std::max(batch_capacity, phase.ids.size());
            auto & summary = run.phases[p];
            summary.name = "round" + std::to_string(phase.turn) + (prompt ? "_prefill" : "_decode");
            summary.begin_marker = schedules[s].id + "_" + summary.name + "_begin";
            summary.end_marker = schedules[s].id + "_" + summary.name + "_end";
            const auto count = prompt ? std::size_t{1} : phase.ids.size();
            for (std::size_t local = 0; local < count; ++local)
                session_calls[s].push_back({s, p, local, first + (prompt ? 0 : local), prompt ? phase.ids.size() : 1});
        }
        run.predictions.reserve(session_calls[s].size()); total_calls += session_calls[s].size();
    }
    std::vector<Call> dispatch; dispatch.reserve(total_calls);
    // Same active=1 turn/cohort order as the ordinary Hyle manifest driver.
    for (std::size_t turn = 1;; ++turn) {
        bool found = false;
        for (std::size_t s = 0; s < schedules.size(); ++s) {
            for (const auto & call : session_calls[s]) if (schedules[s].phases[call.phase].turn == turn) {
                dispatch.push_back(call); found = true;
            }
        }
        if (!found) break;
    }
    std::vector<Observation> observations(dispatch.size());
    for (std::size_t i = 0; i < dispatch.size(); ++i) {
        const auto & call = dispatch[i]; const auto & phase = schedules[call.session].phases[call.phase];
        auto & o = observations[i]; o.session = schedules[call.session].id;
        o.name = schedule::phase_name(phase, call.local); o.turn = phase.turn;
        o.prompt = phase.kind == schedule::PhaseKind::kPrompt;
    }

    Backend backend;
    auto * device = ggml_backend_dev_by_name("CUDA0");
    if (!device || ggml_backend_dev_type(device) != GGML_BACKEND_DEVICE_TYPE_GPU)
        throw std::runtime_error("CUDA0 GPU required");
    ggml_backend_dev_t devices[] = {device, nullptr};
    auto model_params = llama_model_default_params(); model_params.devices = devices; model_params.n_gpu_layers = 999;
    const llama_model_tensor_buft_override overrides[] = {
        {"^token_embd\\.weight$", ggml_backend_dev_buffer_type(device)}, {nullptr, nullptr}};
    model_params.tensor_buft_overrides = overrides;
    using Model = std::unique_ptr<llama_model, decltype(&llama_model_free)>;
    const auto model_start = Clock::now();
    Model model(llama_model_load_from_file(model_path, model_params), &llama_model_free);
    const auto model_end = Clock::now();
    if (!model || llama_model_n_layer(model.get()) != 24 || llama_vocab_n_tokens(llama_model_get_vocab(model.get())) != vocabulary)
        throw std::runtime_error("expected original full Qwen3.5-2B model/vocabulary");
    const auto native_sequences = committed_limit + 1;
    using Sampler = std::unique_ptr<llama_sampler, decltype(&llama_sampler_free)>;
    std::vector<Sampler> samplers; samplers.reserve(native_sequences);
    std::vector<llama_sampler_seq_config> sampler_configs; sampler_configs.reserve(native_sequences);
    for (std::size_t i = 0; i < native_sequences; ++i) {
        Sampler sampler(llama_sampler_chain_init(llama_sampler_chain_default_params()), &llama_sampler_free);
        if (!sampler) throw std::runtime_error("cannot create native sampler");
        llama_sampler_chain_add(sampler.get(), llama_sampler_init_greedy());
        sampler_configs.push_back({static_cast<llama_seq_id>(i), sampler.get()});
        samplers.push_back(std::move(sampler));
    }
    auto params = llama_context_default_params();
    params.n_ctx = static_cast<uint32_t>(pool_tokens); params.n_seq_max = static_cast<uint32_t>(native_sequences);
    params.kv_unified = true; // n_ctx_seq=n_ctx; this is one physical token pool, not n_ctx/n_seq_max.
    params.n_batch = static_cast<uint32_t>(batch_capacity); params.n_ubatch = static_cast<uint32_t>(batch_capacity);
    params.n_threads = 24; params.n_threads_batch = 24;
    params.type_k = GGML_TYPE_BF16; params.type_v = GGML_TYPE_BF16;
    params.flash_attn_type = LLAMA_FLASH_ATTN_TYPE_ENABLED;
    params.samplers = sampler_configs.data(); params.n_samplers = sampler_configs.size();
    using Context = std::unique_ptr<llama_context, decltype(&llama_free)>;
    const auto context_start = Clock::now();
    Context context(llama_init_from_model(model.get(), params), &llama_free);
    const auto context_end = Clock::now();
    if (!context || llama_n_ctx_seq(context.get()) < logical_capacity || llama_n_seq_max(context.get()) != native_sequences)
        throw std::runtime_error("native unified context did not preserve per-sequence logical capacity/quota");
    const auto native_cache_bytes = cache_bytes(context.get());
    if (byte_limit && native_cache_bytes > byte_limit) throw std::runtime_error("native KV plus recurrent backing exceeds cache-byte budget");
    Batch batch(static_cast<int32_t>(batch_capacity));
    Pool pool(context.get(), native_sequences);
    Directory directory(committed_limit);
    // Runs were cold-created before Model, but native Version owners are only
    // acquired below. Explicit clearing before return keeps Pool/context alive.
    const auto ready = Clock::now();
    const auto memory_ready = memory("ready_before_first", startup, device);
    std::size_t graph_calls = 0, graph_tokens = 0, hits = 0, misses = 0, full_hits = 0, reused_tokens = 0, copies = 0;
    double prefill_service = 0, decode_service = 0;
    Point journey_start{}, journey_end{};
    const auto make_room = [&](const std::shared_ptr<Version> & base) {
        // Alias entries do not count as distinct snapshots. Drop LRU entries
        // until the real native Version population has room or base is sole.
        while (pool.live >= committed_limit && (!base || base.use_count() != 1))
            if (!directory.evict()) throw std::runtime_error("all committed native versions are retained by session heads");
    };
    try {
        for (std::size_t index = 0; index < dispatch.size(); ++index) {
            const auto & call = dispatch[index]; auto & run = runs[call.session];
            auto & summary = run.phases[call.phase]; const auto & phase = schedules[call.session].phases[call.phase];
            auto & observation = observations[index];
            if (call.local == 0) {
                std::cerr << "memory_phase=" << summary.begin_marker << '\n';
                summary.before = run.visible; summary.start = Clock::now();
                if (run.predictions.empty()) run.start = summary.start;
                if (index == 0) journey_start = summary.start;
            }
            const auto start = Clock::now();
            const auto target = run.visible + call.count;
            observation.logical_tokens = call.count;
            std::size_t reused = 0;
            if (observation.prompt) {
                const auto lookup_start = Clock::now();
                auto hit = directory.lookup(run.tokens, target, run.visible + (run.head ? 1 : 0));
                if (hit) {
                    reused = hit->length - run.visible;
                    run.head = std::move(hit); observation.hit = true; ++hits; reused_tokens += reused;
                } else ++misses;
                observation.lookup = seconds(Clock::now(), lookup_start);
            }
            const auto count = call.count - reused;
            observation.reused = reused; observation.graph_tokens = count;
            if (!count) {
                if (!run.head || run.head->length != target || run.head->next == LLAMA_TOKEN_NULL)
                    throw std::runtime_error("full prefix hit has no exact complete boundary/next id");
                observation.full_hit = true; ++full_hits;
                observation.next = run.head->next; observation.target_seq = run.head->id;
            } else {
                make_room(run.head);
                auto candidate = run.head;
                // candidate adds one local reference; every other reference is
                // an actual directory/session owner whose old state must stay.
                if (!candidate || candidate.use_count() != 2) {
                    candidate = pool.create();
                    if (run.head) {
                        observation.source_seq = run.head->id;
                        const auto copy_start = Clock::now();
                        llama_memory_seq_cp(llama_get_memory(context.get()), run.head->id, candidate->id, -1, -1);
                        observation.copy_api = seconds(Clock::now(), copy_start); ++copies;
                        if (llama_memory_seq_pos_max(llama_get_memory(context.get()), candidate->id) != static_cast<llama_pos>(run.head->length) - 1)
                            throw std::runtime_error("complete hybrid sequence copy did not preserve boundary");
                    }
                }
                observation.target_seq = candidate->id;
                const auto native_start = Clock::now();
                batch.value.n_tokens = static_cast<int32_t>(count);
                for (std::size_t i = 0; i < count; ++i) {
                    batch.value.token[i] = run.tokens[call.first + reused + i];
                    batch.value.pos[i] = static_cast<llama_pos>(run.visible + reused + i);
                    batch.value.n_seq_id[i] = 1; batch.value.seq_id[i][0] = candidate->id;
                    batch.value.logits[i] = i + 1 == count;
                }
                const auto prepared = Clock::now();
                pool.native_inflight = true;
                const auto status = llama_decode(context.get(), batch.value);
                const auto decoded = Clock::now();
                if (status != 0) throw std::runtime_error("llama_decode failed: " + std::to_string(status));
                llama_synchronize(context.get()); pool.native_inflight = false;
                const auto synchronized = Clock::now();
                const auto backend_next = llama_get_sampled_token_ith(context.get(), -1);
                if (backend_next == LLAMA_TOKEN_NULL) throw std::runtime_error("native greedy missing; CPU fallback rejected");
                const auto next = llama_sampler_sample(samplers[static_cast<std::size_t>(candidate->id)].get(), context.get(), -1);
                if (next != backend_next || next < 0 || next >= vocabulary)
                    throw std::runtime_error("public/native greedy token differs or is outside vocabulary");
                const auto sampled = Clock::now();
                observation.prepare = seconds(prepared, native_start); observation.decode = seconds(decoded, prepared);
                observation.synchronize = seconds(synchronized, decoded); observation.sample = seconds(sampled, synchronized);
                observation.sampled_logits = llama_get_sampled_logits_count_ith(context.get(), -1);
                candidate->tokens = &run.tokens; candidate->length = target; candidate->next = next;
                run.head = std::move(candidate); observation.next = next;
                ++graph_calls; graph_tokens += count;
            }
            // Publication and host-visible next id are part of this endpoint.
            run.visible = target; observation.visible = target;
            run.endpoint = journey_end = Clock::now(); observation.total = seconds(run.endpoint, start);
            run.predictions.push_back(observation.next); summary.step_sum += observation.total;
            (observation.prompt ? prefill_service : decode_service) += observation.total;
            if (pool.live > committed_limit) throw std::runtime_error("committed native versions exceed N");
            const bool phase_end = observation.prompt || call.local + 1 == phase.ids.size();
            if (phase_end) {
                summary.after = target; summary.seconds = seconds(run.endpoint, summary.start);
                std::cerr << "memory_phase=" << summary.end_marker << '\n';
                directory.publish(run.head);
            }
        }
        for (const auto & o : observations)
            std::cerr << "session=" << o.session << ' ' << o.name << " tokens=" << o.logical_tokens
                      << " visible=" << o.visible << " next=" << o.next << " step_seconds=" << o.total
                      << " graph_tokens=" << o.graph_tokens << " reused=" << o.reused
                      << " lookup_seconds=" << o.lookup << " copy_api_seconds=" << o.copy_api << '\n';
        const auto memory_final = memory("all_sessions_complete", startup, device);
        json result;
        result["llama_commit"] = "d9e03f1074dbd2979126d91dce1b5d304ec8394e";
        result["model"] = model_path; result["session_manifest"] = manifest;
        result["active_sequences"] = 1; result["logical_capacity"] = logical_capacity;
        result["committed_versions_limit"] = committed_limit; result["native_sequence_quota"] = native_sequences;
        result["native_n_ctx"] = llama_n_ctx(context.get()); result["native_n_ctx_seq"] = llama_n_ctx_seq(context.get());
        result["kv_unified"] = true; result["cache_backing_bytes"] = native_cache_bytes; result["cache_byte_limit"] = byte_limit;
        result["native_rnn_dtype"] = "F32 conv R and GDN S; original model implementation";
        result["processed_tokens"] = logical_tokens; result["generated_tokens"] = observations.size();
        result["actual_graph_calls"] = graph_calls; result["actual_graph_tokens"] = graph_tokens;
        result["prefix_hits"] = hits; result["prefix_misses"] = misses; result["prefix_full_hits"] = full_hits;
        result["reused_tokens"] = reused_tokens; result["seq_copy_api_calls"] = copies;
        result["restored_calls"] = 0; result["restored_tokens"] = 0; result["restore_seconds"] = 0;
        result["directory_evictions"] = directory.evictions; result["peak_native_versions"] = pool.peak;
        result["session_seconds"] = seconds(journey_end, journey_start);
        result["startup_total_seconds"] = seconds(journey_end, startup);
        result["ready_seconds"] = seconds(ready, startup);
        result["model_load_seconds"] = seconds(model_end, model_start);
        result["context_seconds"] = seconds(context_end, context_start);
        result["prefill_service_seconds"] = prefill_service; result["decode_service_seconds"] = decode_service;
        result["sessions"] = json::array();
        for (std::size_t s = 0; s < runs.size(); ++s) {
            const auto & run = runs[s]; json item;
            item["id"] = schedules[s].id; item["generated_ids"] = run.predictions;
            item["visible_tokens"] = run.visible; item["session_wall_seconds"] = seconds(run.endpoint, run.start);
            item["phases"] = json::array();
            for (std::size_t p = 0; p < run.phases.size(); ++p) {
                const auto & summary = run.phases[p]; const auto & phase = schedules[s].phases[p];
                item["phases"].push_back({{"name", summary.name}, {"turn", phase.turn},
                    {"kind", phase.kind == schedule::PhaseKind::kPrompt ? "prefill" : "decode"},
                    {"input_tokens", phase.ids.size()}, {"context_before", summary.before}, {"context_after", summary.after},
                    {"seconds", summary.seconds}, {"step_sum_seconds", summary.step_sum}});
            }
            result["sessions"].push_back(std::move(item));
        }
        result["steps"] = json::array();
        for (const auto & o : observations) result["steps"].push_back({{"session", o.session}, {"name", o.name},
            {"kind", o.prompt ? "prefill" : "decode"}, {"turn", o.turn}, {"input_tokens", o.logical_tokens},
            {"visible_tokens", o.visible}, {"predicted_id", o.next}, {"step_seconds", o.total},
            {"graph_tokens", o.graph_tokens}, {"prefix_hit", o.hit}, {"full_hit", o.full_hit}, {"reused_tokens", o.reused},
            {"lookup_seconds", o.lookup}, {"seq_copy_api_seconds", o.copy_api}, {"input_prepare_seconds", o.prepare},
            {"decode_return_seconds", o.decode}, {"synchronize_seconds", o.synchronize}, {"sampling_seconds", o.sample},
            {"sampled_logits_elements", o.sampled_logits}, {"source_seq", o.source_seq}, {"target_seq", o.target_seq}});
        result["memory"] = {{{"name", memory_ready.name}, {"device_global_free_bytes", memory_ready.device_free},
                              {"device_global_total_bytes", memory_ready.device_total}},
                             {{"name", memory_final.name}, {"device_global_free_bytes", memory_final.device_free},
                              {"device_global_total_bytes", memory_final.device_total}}};
        result["scope"] = "One model/context; serial active1, bounded N immutable checkpoint/session versions plus one spare native ID. Native unified KV tag sharing and recurrent COW; no session eviction/serialized restore implementation in this first fixture. Full hit returns stored exact-boundary next id with zero decode and no tensor payload. No server/concurrent throughput claim.";
        result["timing_boundary"] = "Before real prefix lookup/admission/copy/input preparation through synchronized native greedy host token plus successful head publication. No actual work moved out of timer. Per-call logs deferred; realtime phase markers/control and checkpoint publication between calls remain in global session wall. Prefix copy API time excludes deferred native recurrent copy, which is inside next llama_decode.";
        result["budget_boundary"] = "N counts distinct native Version objects, not directory aliases. Actual allocated KV+RS backing includes fixed candidate quota; excludes weights/workspace and is not process VRAM. Default unified physical token pool1024 versus Hyle1040 is not equal-byte provisioning; logical per-request capacity is independently checked. Optional byte limit uses actual cold KV+RS buffer sizes after context creation; not an early preallocation rejection contract.";
        result["failure_boundary"] = "Any native decode/copy-boundary failure aborts this measurement. This fixture does not certify transactional rollback/cancellation equivalent to Hyle; no error is converted to success.";
        std::ofstream output(output_path); output << result.dump(2) << '\n';
        if (!output) throw std::runtime_error("cannot write comparison result");
    } catch (...) {
        llama_synchronize(context.get());
        for (auto & run : runs) run.head.reset();
        directory.entries.clear();
        throw;
    }
    for (auto & run : runs) run.head.reset();
    directory.entries.clear();
    return 0;
}
} // namespace peer_prefix

int main(int argc, char ** argv) {
    try {
        if (argc < 2) throw std::runtime_error("MODEL.gguf --session-schedules FILE --result FILE [--capacity256 --cache-slots4 --pool-tokens1024 --cache-bytesB]");
        const char * manifest = nullptr; const char * output = nullptr;
        std::size_t capacity = 256, slots = 4, pool_tokens = 1024, byte_limit = 0;
        const auto integer = [](const char * text) {
            const std::string value(text); std::size_t end = 0;
            if (value.empty() || value.find_first_not_of("0123456789") != std::string::npos)
                throw std::runtime_error("capacity values must be unsigned decimal integers");
            const auto number = std::stoull(value, &end);
            if (end != value.size() || number > (std::numeric_limits<std::size_t>::max)())
                throw std::runtime_error("capacity value exceeds size_t");
            return static_cast<std::size_t>(number);
        };
        for (int i = 2; i < argc; ++i) {
            if (i + 1 >= argc) throw std::runtime_error("missing CLI value");
            const std::string key = argv[i]; const char * value = argv[++i];
            if (key == "--session-schedules") manifest = value;
            else if (key == "--result") output = value;
            else if (key == "--capacity") capacity = integer(value);
            else if (key == "--cache-slots") slots = integer(value);
            else if (key == "--pool-tokens") pool_tokens = integer(value);
            else if (key == "--cache-bytes") byte_limit = integer(value);
            else throw std::runtime_error("unknown option: " + key);
        }
        if (!manifest || !output) throw std::runtime_error("session manifest and result path required");
        return peer_prefix::run(argv[1], manifest, capacity, slots, pool_tokens, byte_limit, output);
    } catch (const std::exception & error) { std::cerr << "error: " << error.what() << '\n'; return 1; }
}
