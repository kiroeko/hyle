"""Root's one finite full comparison; timing and memory runs are separate."""
from pathlib import Path
import argparse
import importlib.util
import os
import sys
sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
R = S.parents[1]
D = R / '.scratch/architecture-refactor-2026-10-18/d4-windows-preparation-2026-10-21'
F = D / 'first-decode-startup-2026-10-21'
W = F / 'layout-workspace-facts-reuse-2026-10-21'
spec = importlib.util.spec_from_file_location('original_multiturn', F / 'multiturn/multiturn_run.py')
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)
parser = argparse.ArgumentParser()
parser.add_argument('mode', choices=('timing', 'memory'))
args = parser.parse_args()
receipts = dict(current=S / 'qwen-ready.json', before=R / '.scratch/paged-recording-20261021/qwen-ready.json', dense=W / 'ready-for-root.json',
                peer=D / 'peer-continuation/multiround/ready-for-root.json')
images = {key:m.ready_image(path) for key,path in receipts.items()}
plan = m.read(W / 'performance/timing/attempt1/inputs.json')['plan']
assert plan['processed_tokens'] == 864 and plan['generated_tokens'] == 99
order = ['current', 'before', 'dense', 'peer', 'peer', 'dense', 'before', 'current', 'before', 'current', 'peer', 'dense'] if args.mode == 'timing' else ['before', 'current', 'dense', 'peer']
out = S / 'performance' / args.mode
out.mkdir(parents=True, exist_ok=False)
assert not os.environ.get('GGML_CUDA_DISABLE_GRAPHS')
environment_paths = {key:Path(m.read(path)['runtime_environment']['path']) for key,path in receipts.items()}
commands = []
for i, variant in enumerate(order, 1):
    arm = 'peer' if variant == 'peer' else 'hyle'
    commands.append(dict(variant=variant, arm=arm,
        command=m.command_for(arm, images[variant], plan, out / f'{i:02}-{variant}')))
m.save(out / 'inputs.json', dict(plan=plan, images=images, order=order, commands=commands,
    driver=m.identity(__file__), original_driver=m.identity(F / 'multiturn/multiturn_run.py'),
    ready_receipts={k:m.identity(p) for k,p in receipts.items()},
    environments={k:m.identity(p) for k,p in environment_paths.items()},
    throughput_evidence=args.mode == 'timing', memory_monitor=args.mode == 'memory',
    profiler=False, diagnostic=False, concurrent_GPU=False,
    purpose='Compare current generic lookup/page-set changes to exact previous paged ff42 closure, dense Hyle and matched llama.cpp; all four reuse full continuation state. No hidden warmups or diagnostic trace.',
    requested_memory_interval_seconds=.01 if args.mode == 'memory' else None))
runs = []
m.gpu_snapshot(out, 'window-before')
try:
    for i, entry in enumerate(commands, 1):
        variant, arm = entry['variant'], entry['arm']
        folder = out / f'{i:02}-{variant}'
        print('FULL_BEGIN', args.mode, i, variant, flush=True)
        environment = os.environ.copy()
        environment['PATH'] = m.read(environment_paths[variant])['PATH']
        process = m.execute(folder, arm, entry['command'], environment, args.mode == 'memory')
        observation = m.parse_observation(folder, arm, plan)
        if arm == 'hyle':
            assert not observation['raw']['diagnostic']
        runs.append(dict(variant=variant, arm=arm, folder=str(folder), process=process, observation=observation))
        m.save(out / 'runs.json', runs)
        print('FULL_END', args.mode, i, variant, process['exit'], flush=True)
finally:
    m.gpu_snapshot(out, 'window-after')
groups = {}
for variant in receipts:
    selected = [x for x in runs if x['variant'] == variant]
    if args.mode == 'timing':
        groups[variant] = dict(metrics={key:m.stats([x['observation']['metrics'][key] for x in selected])
            for key in selected[0]['observation']['metrics']},
            loading={key:m.stats([x['observation']['loading'][key] for x in selected])
                for key,value in selected[0]['observation']['loading'].items() if isinstance(value,(float,int))},
            phases={p['name']:m.stats([x['observation']['raw']['phases'][j]['input_tokens'] /
                x['observation']['raw']['phases'][j]['seconds'] for x in selected])
                for j,p in enumerate(selected[0]['observation']['raw']['phases'])},
            predictions_equal=all(x['observation']['predicted_ids'] == selected[0]['observation']['predicted_ids'] for x in selected))
    else:
        groups[variant] = m.read(Path(selected[0]['folder']) / 'memory-summary.json')
hyle_ids = [x['observation']['predicted_ids'] for x in runs if x['arm'] == 'hyle']
assert all(ids == hyle_ids[0] for ids in hyle_ids)
m.save(out / 'summary.json', dict(mode=args.mode, groups=groups, processes=len(runs),
    same_Hyle_predictions=True, throughput_evidence=args.mode == 'timing',
    statistical_significance=False, independent_quality_acceptance=False))
print('FULL_COMPLETE', args.mode, len(runs), flush=True)
