"""Changed host owners only; retained C CUDA closure, no NVCC/SDK build or device run."""
from pathlib import Path
import argparse, concurrent.futures, importlib.util, os, sys
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent; R=S.parents[1]
C=R/'.scratch/paged-capture-20261021'; P=R/'.scratch/qwen-prefix-20261021'
A=R/'.scratch/architecture-refactor-2026-10-18'; T=R/'.scratch/paged-retirement-20261021'
spec=importlib.util.spec_from_file_location('capture_helpers',C/'build.py')
h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
b,c=h.b,h.c
RECIPES={
 'leases':('src/compute/resource_leases.cc',R/'.scratch/paged-append-20261021/checks/attempt2/compute--resource_leases/identity.json'),
 'arena':('src/compute_batch/paged_arena.cc',R/'.scratch/paged-append-20261021/checks/attempt2/compute_batch--paged_arena/identity.json'),
 'submission':('src/graph/lease_submission.cc',C/'core/compile1/identity.json'),
 'resources':('src/graph/resources.cc',C/'core/compile1/identity.json'),
 'append':('src/graph_batch/paged_append.cc',C/'host/checks3/append/identity.json'),
 'main':('tools/qwen35_text/main.cc',P/'checks/attempt3/identity.json'),
 'probe':('tools/qwen35_text/retirement_probe.cc',T/'probe-compile2/identity.json'),
 'cpu-test':('tests/graph_batch/paged_append_graph_test.cc',R/'.scratch/paged-prepare-20261021/checks/attempt1/graph_batch--paged_append_graph_test/identity.json'),
 'cuda-test':('tests/graph_batch/paged_append_cuda_consumer.cc',C/'host/checks4/fixture/identity.json'),
 'radix-test':('tests/tools/qwen_prefix_cache_test.cc',P/'checks/attempt3/identity.json'),
 'lease-test':('tests/compute/resource_leases_test.cc',R/'.scratch/paged-prepare-20261021/checks/attempt1/graph_batch--paged_append_graph_test/identity.json'),
}
COMMON=('leases','arena','submission','resources','append')
def same(row): return b.identity(row['path'])==row
def compile_owner(tag,attempt):
 relative,recipe=RECIPES[tag];source=R/relative
 out=S/f'compile{attempt}'/tag;out.mkdir(parents=True,exist_ok=False);(out/'tmp').mkdir()
 flags=c.read(recipe)['command'].copy()
 if '/WX'not in flags:flags.append('/WX')
 if tag=='radix-test':flags.append('/DHYLE_PREFIX_CACHE_STANDALONE=1')
 if tag=='lease-test':
  flags=[x for x in flags if 'HYLE_APPEND_STANDALONE'not in x]
 command=b.host_command(flags,source,tag,out);assert all(x in command for x in ('/W4','/WX','/O2','/MD'))
 frozen=b.identity(source)
 snap=out/'source'/relative;snap.parent.mkdir(parents=True,exist_ok=True);snap.write_bytes(source.read_bytes())
 c.save(out/'compile-plan.json',dict(command=command,source=frozen,recipe=b.identity(recipe),CXX=1,NVCC=0,SDK_builds=0))
 env,_=b.environment(command,[],out);c.execute('compile',command,env,out)
 deps=c.read(out/(tag+'-deps.json'))['Data']
 record=dict(source=frozen,object=b.identity(out/(tag+'.obj')),command=command,
  dependencies=[b.identity(p)for p in dict.fromkeys([deps['Source'],*deps['Includes']])])
 assert same(frozen)and all(same(x)for x in record['dependencies'])
 c.save(out/'identity.json',record);print('COMPILED',tag,flush=True)
 return record
def record_path(tag,attempt):return S/f'compile{2 if tag=="submission"and attempt==1 else attempt}'/tag/'identity.json'
def record(tag,attempt):return c.read(record_path(tag,attempt))
def link(mode,attempt,common_attempt,owner_attempt):
 base_mode=mode if mode in ('qwen','cpu','cuda','probe')else 'qwen'
 prior_path=C/f'{base_mode}-ready-attempt{5 if base_mode=="cuda"else 3}.json'
 prior=c.read(prior_path);base=c.read(prior['link_plan']['path'])
 owner={'qwen':'main','cpu':'cpu-test','cuda':'cuda-test','probe':'probe','radix':'radix-test','lease':'lease-test'}[mode]
 records=[record(t,common_attempt)for t in COMMON]+[record(owner,owner_attempt)]
 assert all(same(x)for x in base['inputs'])
 assert all(same(x['source'])and same(x['object'])and all(same(d)for d in x['dependencies'])for x in records)
 replacements={}
 original_names={
  'leases':'resource_leases.obj','arena':'paged_arena.obj','submission':'lease_submission.obj',
  'resources':'resources.obj','append':'append.obj'}
 for tag,rec in zip(COMMON,records):
  candidates=[x for x in base['inputs']if Path(x['path']).name.lower().endswith(original_names[tag])]
  assert len(candidates)==1,(tag,candidates)
  replacements[c.key(candidates[0]['path'])]=rec['object']
 source_object={
  'qwen':T/'qwen-compile1/qwen.obj',
  'cpu':R/'.scratch/paged-prepare-20261021/checks/attempt1/graph_batch--paged_append_graph_test/graph_batch--paged_append_graph_test.obj',
  'cuda':C/'host/checks4/fixture/fixture.obj',
  'probe':T/'probe-compile2/probe.obj',
  'radix':T/'qwen-compile1/qwen.obj',
  'lease':T/'qwen-compile1/qwen.obj'}[mode]
 replacements[c.key(source_object)]=records[-1]['object']
 assert len(replacements)==6
 assert all(sum(c.key(x['path'])==key for x in base['inputs'])==1 for key in replacements)
 extra=[]
 if mode=='lease':extra=[b.identity(R/'.scratch/build-compute-v2-dev/lib'/name)for name in ('gtest_main.lib','gtest.lib')]
 inputs=[replacements.get(c.key(x['path']),x)for x in base['inputs']]+extra
 out=S/f'{mode}-link{attempt}';out.mkdir(exist_ok=False);(out/'tmp').mkdir();image=out/(mode+'.exe')
 command=[replacements.get(c.key(x),{}).get('path',x)for x in base['command']if not x.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:'))]
 command += [x['path']for x in extra]+['/OUT:'+str(image),'/MAP:'+str(image.with_suffix('.map')),'/IMPLIB:'+str(image.with_suffix('.lib'))]
 c.save(out/'link-plan.json',dict(command=command,inputs=inputs,base=b.identity(prior['link_plan']['path']),
  replaced_inputs=[dict(before=x,after=replacements[c.key(x['path'])])for x in base['inputs']if c.key(x['path'])in replacements],
  added_inputs=extra,compiled_records=[b.identity(record_path(t,common_attempt))for t in COMMON]+[b.identity(record_path(owner,owner_attempt))],links=1,NVCC=0,SDK_builds=0))
 env,_=b.environment(command,[x['path']for x in inputs],out);c.execute('link',command,env,out)
 for dll in Path(prior['image']['path']).parent.glob('*.dll'):os.link(dll,out/dll.name)
 runtime=c.read(prior['runtime_environment']['path']);runtime['PATH']=env['PATH'];runtime['staged_dlls']=[b.identity(x)for x in out.glob('*.dll')]
 if mode=='cpu'and 'CPU_native_overlay'in runtime:runtime['CPU_native_overlay']['destination']=b.identity(out/'hyle_ggml_cpu_append_hyca.dll')
 c.save(out/'runtime-environment.json',runtime)
 c.save(S/f'{mode}-ready-attempt{attempt}.json',dict(image=b.identity(image),source=records[-1]['source'],fresh_sources=[x['source']for x in records],
  link_plan=b.identity(out/'link-plan.json'),runtime_environment=b.identity(out/'runtime-environment.json'),CXX=0,links=1,NVCC=0,SDK_builds=0,GPU_runs=0))
 print('READY',mode,flush=True)
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('mode',choices=(*RECIPES,'common','qwen','cpu','cuda','radix','lease'))
 p.add_argument('--attempt',type=int,default=1);p.add_argument('--common-attempt',type=int,default=1);p.add_argument('--owner-attempt',type=int,default=1);p.add_argument('--link',action='store_true');a=p.parse_args()
 if a.link:link(a.mode,a.attempt,a.common_attempt,a.owner_attempt)
 elif a.mode=='common':
  with concurrent.futures.ThreadPoolExecutor(max_workers=3)as pool:list(pool.map(lambda t:compile_owner(t,a.attempt),COMMON))
 else:compile_owner(a.mode,a.attempt)
