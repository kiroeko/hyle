"""Root serial real-CUDA retirement check, with reaped timeout and raw receipt."""
from pathlib import Path
import hashlib
import argparse
import json
import os
import subprocess
import time
S = Path(__file__).resolve().parent
R = S.parents[1]
def read(p): return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def save(p, d): p.write_text(json.dumps(d, indent=2) + '\n', encoding='utf-8')
parser = argparse.ArgumentParser()
parser.add_argument('--attempt', type=int, default=1)
args = parser.parse_args()
ready_path = S / f'probe-ready-attempt{args.attempt}.json'
ready = read(ready_path)
image = ready['image']
assert hashlib.sha256(Path(image['path']).read_bytes()).hexdigest() == image['sha256']
command = read(S / 'probe/report.json')['command_template']
command[0] = image['path']
env = os.environ.copy()
env['PATH'] = read(ready['runtime_environment']['path'])['PATH']
out = S / f'probe-run{args.attempt}'
out.mkdir(exist_ok=False)
record = dict(command=command, image=image, ready=str(ready_path), cwd=str(R),
    throughput_evidence=False, concurrent_benchmark=False, started_unix_ns=time.time_ns())
save(out / 'command.json', record)
process = None
with (out / 'stdout.log').open('wb') as so, (out / 'stderr.log').open('wb') as se:
    try:
        process = subprocess.Popen(command, cwd=R, env=env, stdout=so, stderr=se,
            creationflags=subprocess.CREATE_NO_WINDOW)
        record['pid'] = process.pid
        try: record['exit'] = process.wait(timeout=180)
        except subprocess.TimeoutExpired:
            record['timeout'] = True
            process.kill()
            record['exit'] = process.wait()
    finally:
        if process is not None and process.poll() is None:
            process.kill()
            process.wait()
        record['finished_unix_ns'] = time.time_ns()
        save(out / 'result.json', record)
assert record['exit'] == 0 and not record.get('timeout'), out
data = json.loads((out / 'stdout.log').read_text().splitlines()[-1])
assert data['status'] == 'PASS' and data['dropped_live_public_completion']
assert data['managed_bytes_while_native_pending'] == data['managed_backing_bytes']
save(out / 'observation.json', data)
print(json.dumps(data, indent=2))
