"""Small changed-owner rebuild against the retained native closure; GPU runs are separate."""
from pathlib import Path
import argparse
import concurrent.futures
import importlib.util
import os
import sys
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent
R=S.parents[1]
N=R/'.scratch/paged-native-cost-20261021'
T=R/'.scratch/paged-retirement-20261021'
P=R/'.scratch/qwen-prefix-20261021'
sp=importlib.util.spec_from_file_location('retained',T/'build.py')
h=importlib.util.module_from_spec(sp);sp.loader.exec_module(h)
b,c=h.b,h.c

RECIPES={
 'append':('src/graph_batch/paged_append.cc',N/'host-check1/identity.json'),
 'batch':('src/graph_batch/batch.cc',P/'core-checks/attempt1/graph_batch--batch/identity.json'),
 'helper':('src/compute_batch/paged_append_program.cc',R/'.scratch/paged-append-20261021/checks/attempt2/compute_batch--paged_arena/identity.json'),
 'fixture':('tests/graph_batch/paged_append_cuda_consumer.cc',R/'.scratch/paged-recording-20261021/checks/attempt1/graph_batch--paged_append_cuda_consumer/identity.json'),
}

def compile_owner(tag,attempt):
    relative,recipe=RECIPES[tag];source=R/relative;prior=c.read(recipe)
    out=S/f'host/checks{attempt}'/tag;out.mkdir(parents=True,exist_ok=False);(out/'tmp').mkdir()
    frozen=b.identity(source);flags=prior['command'].copy()
    if '/WX' not in flags:flags.append('/WX')
    command=b.host_command(flags,source,tag,out)
    assert all(x in command for x in ('/W4','/WX','/O2','/MD'))
    c.save(out/'compile-plan.json',dict(command=command,source=frozen,recipe=b.identity(recipe),CXX=1,NVCC=0,SDK_builds=0))
    env,_=b.environment(command,[],out);c.execute('compile',command,env,out)
    deps=c.read(out/(tag+'-deps.json'))['Data']
    record=dict(source=frozen,object=b.identity(out/(tag+'.obj')),command=command,
        dependencies=[b.identity(p) for p in dict.fromkeys([deps['Source'],*deps['Includes']])])
    if tag!='helper':record['replaced_object']=prior['object']
    assert h.h.same(frozen) and all(h.h.same(x) for x in record['dependencies'])
    c.save(out/'identity.json',record)
    print('COMPILED',tag,flush=True)
    return record

def link(mode,attempt,host_attempt,fixture_attempt,append_attempt,helper_attempt):
    prior_path=(T/'probe-ready-attempt2.json') if mode=='probe' else N/f'{mode}-ready-attempt1.json'
    prior=c.read(prior_path);base=c.read(prior['link_plan']['path'])
    records=[c.read(S/'core/compile1/identity.json'),
             c.read(S/'cuda/checks1/backend/identity.json')]
    owner_attempts=dict(append=append_attempt,batch=host_attempt,helper=helper_attempt)
    records += [c.read(S/f'host/checks{owner_attempts[tag]}'/tag/'identity.json')for tag in ('append','batch','helper')]
    records += [c.read(S/'cuda/checks1'/tag/'identity.json')for tag in ('append-host','kernel')]
    if mode=='cuda':records.append(c.read(S/f'host/checks{fixture_attempt}/fixture/identity.json'))
    assert all(h.h.same(x)for x in base['inputs'])
    for record in records:
        assert h.h.same(record['source']) and h.h.same(record['object'])
        assert all(h.h.same(x)for x in record['dependencies'])
    replacements={c.key(x['replaced_object']['path']):x['object'] for x in records if 'replaced_object'in x}
    if mode=='probe':
        append=c.read(S/f'host/checks{append_attempt}/append/identity.json')
        del replacements[c.key(append['replaced_object']['path'])]
        replacements[c.key(c.read(P/'core-checks/attempt1/graph_batch--paged_append/identity.json')['object']['path'])]=append['object']
    assert all(sum(c.key(x['path'])==key for x in base['inputs'])==1 for key in replacements)
    added=[x['object']for x in records if 'replaced_object'not in x]
    inputs=[replacements.get(c.key(x['path']),x)for x in base['inputs']]+added
    assert len({c.key(x['path'])for x in inputs})==len(inputs)
    out=S/f'{mode}-link{attempt}';out.mkdir(exist_ok=False);(out/'tmp').mkdir()
    image=out/(mode+'.exe')
    command=[replacements.get(c.key(x),{}).get('path',x) for x in base['command']
        if not x.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:'))]
    command += [x['path']for x in added]
    command += ['/OUT:'+str(image),'/MAP:'+str(image.with_suffix('.map')),'/IMPLIB:'+str(image.with_suffix('.lib'))]
    c.save(out/'link-plan.json',dict(command=command,inputs=inputs,base=b.identity(prior['link_plan']['path']),
        replaced_inputs=[dict(before=x,after=replacements[c.key(x['path'])])for x in base['inputs']if c.key(x['path'])in replacements],
        added_inputs=added,compiled_records=[b.identity(S/'core/compile1/identity.json')],links=1,NVCC=0,SDK_builds=0))
    env,_=b.environment(command,[x['path']for x in inputs],out);c.execute('link',command,env,out)
    for dll in Path(prior['image']['path']).parent.glob('*.dll'):os.link(dll,out/dll.name)
    runtime=c.read(prior['runtime_environment']['path']);runtime['PATH']=env['PATH']
    runtime['staged_dlls']=[b.identity(x)for x in out.glob('*.dll')]
    if mode=='cpu'and 'CPU_native_overlay'in runtime:
        runtime['CPU_native_overlay']['destination']=b.identity(out/'hyle_ggml_cpu_append_hyca.dll')
    c.save(out/'runtime-environment.json',runtime)
    owner=next((x for x in records if x['source']['path'].endswith('paged_append_cuda_consumer.cc')),None)
    c.save(S/f'{mode}-ready-attempt{attempt}.json',dict(image=b.identity(image),source=owner['source']if owner else prior['source'],
        fresh_sources=[x['source']for x in records],link_plan=b.identity(out/'link-plan.json'),
        runtime_environment=b.identity(out/'runtime-environment.json'),CXX=0,links=1,NVCC=0,SDK_builds=0,GPU_runs=0))
    print('READY',mode,flush=True)

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('mode',choices=(*RECIPES,'common','qwen','cpu','cuda','probe'))
    parser.add_argument('--attempt',type=int,default=1);parser.add_argument('--host-attempt',type=int,default=1)
    parser.add_argument('--fixture-attempt',type=int,default=1)
    parser.add_argument('--append-attempt',type=int,default=1)
    parser.add_argument('--helper-attempt',type=int,default=1);args=parser.parse_args()
    if args.mode=='common':
        with concurrent.futures.ThreadPoolExecutor(max_workers=3)as pool:
            list(pool.map(lambda tag:compile_owner(tag,args.attempt),('append','batch','helper')))
    elif args.mode in RECIPES:compile_owner(args.mode,args.attempt)
    else:link(args.mode,args.attempt,args.host_attempt,args.fixture_attempt,args.append_attempt,args.helper_attempt)
