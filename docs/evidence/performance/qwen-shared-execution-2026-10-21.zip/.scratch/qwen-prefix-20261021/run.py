"""Root-only serial actual-model checks, independently partitioned oracles."""
from pathlib import Path
import argparse
import importlib.util
import sys
sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
R = S.parents[1]
F = R / '.scratch/architecture-refactor-2026-10-18/d4-windows-preparation-2026-10-21/first-decode-startup-2026-10-21'
spec = importlib.util.spec_from_file_location('original_checker', F / 'multi-session-isolation-2026-10-21/run.py')
h = importlib.util.module_from_spec(spec)
spec.loader.exec_module(h)
m = h.m
parser = argparse.ArgumentParser()
parser.add_argument('mode', choices=('baselines', 'pressure-baselines', 'terminal-baselines', 'main', 'pressure', 'canonical'))
parser.add_argument('--attempt', type=int, default=1)
parser.add_argument('--ready', type=Path)
args = parser.parse_args()
plan = m.read(S / 'inputs/plan.json')
ready = args.ready.resolve() if args.ready else S / f'ready-attempt{args.attempt}.json'
if args.mode in ('baselines', 'pressure-baselines'):
    before = R / '.scratch/paged-prepare-20261021/qwen-ready.json'
    results = {}
    keys = ('baseline_a', 'baseline_b', 'baseline_seed') if args.mode == 'baselines' else ('baseline_a_pressure', 'baseline_b_monolithic')
    for key in keys:
        # The old image does not support terminal-prompt schedules. The
        # changed-key full-miss oracle is generated with the fresh off image.
        out = S / 'baselines' / key
        observed = h.run(out, before, ['--schedule', plan['cases'][key]['schedule']])
        results[key] = dict(folder=str(out), generated_ids=observed['generated_ids'],
                            visible_tokens=observed['visible_tokens'])
        print('Actual independent original-partition baseline:', key, flush=True)
    m.save(S / ('baselines/summary.json' if args.mode == 'baselines' else 'baselines/pressure-summary.json'), dict(results=results, ready=m.identity(before),
        throughput_evidence=False, weights_copied=0, SDK_builds=0))
elif args.mode == 'terminal-baselines':
    results = {}
    for key in ('changed', 'full_hit'):
        out = S / 'baselines' / ('off_' + key)
        observed = h.run(out, ready, ['--schedule', plan['cases'][key]['schedule'], '--prefix-cache', 'off'])
        results[key] = dict(folder=str(out), generated_ids=observed['generated_ids'],
                            visible_tokens=observed['visible_tokens'])
        print('Actual independent uncached terminal oracle:', key, flush=True)
    m.save(S / 'baselines/terminal-summary.json', dict(results=results, ready=m.identity(ready), throughput_evidence=False))
elif args.mode in ('main', 'pressure'):
    pressure = args.mode == 'pressure'
    out = S / f'{args.mode}-run{args.attempt}'
    observed = h.run(out, ready, ['--session-schedules', plan['pressure_manifest'] if pressure else plan['manifest'],
        '--max-sessions', '2' if pressure else '4', '--active-sequences', '1', '--prefix-cache', 'auto'])
    print('Actual scheduled prefix process exit0:', out, flush=True)
else:
    original = m.read(F / 'multi-session-isolation-2026-10-21/inputs/plan.json')
    single = S / f'single-run{args.attempt}'
    observed = h.run(single, ready, ['--schedule', original['cases']['alice']['schedule']['path']])
    baseline = R / '.scratch/multi-session-20261021/attempt2/baseline/alice'
    pairs = h.check_vectors(baseline / 'trace', single / 'trace', original['cases']['alice']['calls'])
    assert len(pairs) == 18 and all(x['byte_equal'] for x in pairs)
    assert observed['generated_ids'] == m.read(baseline / 'observation.json')['generated_ids']
    m.save(single / 'summary.json', dict(passed=True, vector_count=18, pairs=pairs, throughput_evidence=False))
    multi = S / f'multi-run{args.attempt}'
    observed = h.run(multi, ready, ['--session-schedules', original['manifests']['4']['manifest']['path'],
        '--max-sessions', '2', '--active-sequences', '2', '--cache-bytes', '168886272'])
    assert observed['processed_tokens'] == 239 and observed['generated_tokens'] == 36
    assert observed['evicted_session_ids'] == ['bob', 'alice', 'carol', 'dave', 'alice', 'bob']
    assert sum(s['restored_calls'] for s in observed['sessions']) == 18
    assert sum(s['restored_tokens'] for s in observed['sessions']) == 185
    proofs = {}
    for session in observed['sessions']:
        sid = session['session_id']
        case = original['cases'][sid]
        h.check_session(session, case)
        baseline = R / '.scratch/multi-session-20261021/attempt2/baseline' / sid
        assert session['generated_ids'] == m.read(baseline / 'observation.json')['generated_ids']
        pairs = h.check_vectors(baseline / 'trace', multi / 'trace' / session['trace_subdirectory'], case['calls'])
        assert len(pairs) == 18 and all(x['byte_equal'] for x in pairs)
        proofs[sid] = pairs
    m.save(multi / 'summary.json', dict(passed=True, vector_count=72, sessions=proofs, throughput_evidence=False))
    print('Original 18/72 canonical vectors still byte-identical.', flush=True)
