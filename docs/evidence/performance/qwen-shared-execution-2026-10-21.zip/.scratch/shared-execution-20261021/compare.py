"""Host-only F/run3 numerical comparison; preserve deliberate metadata differences."""
from pathlib import Path
from array import array
import argparse,hashlib,json,sys
S=Path(__file__).resolve().parent;F=S.parent/'paged-host-prepare-20261021'
p=argparse.ArgumentParser();p.add_argument('attempt',nargs='?',type=int,default=1);p.add_argument('--ready',type=Path);a=p.parse_args()
read=lambda p:json.loads(Path(p).read_text(encoding='utf-8-sig'))
def identity(p):
    p=Path(p);b=p.read_bytes();return dict(path=str(p.resolve()),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def stable(v):
    if isinstance(v,dict):return {k:stable(x) for k,x in v.items() if k!='seconds' and not k.endswith('_seconds')}
    if isinstance(v,list):return [stable(x) for x in v]
    return v
def diff(x,y,path=''):
    if isinstance(x,dict) and isinstance(y,dict):
        return [r for k in sorted(x.keys()|y.keys()) for r in
            ([dict(field=path+'/'+k,current=x.get(k),before=y.get(k))] if k not in x or k not in y else diff(x[k],y[k],path+'/'+k))]
    if isinstance(x,list) and isinstance(y,list) and len(x)==len(y):return [r for i,(v,w) in enumerate(zip(x,y)) for r in diff(v,w,path+'/'+str(i))]
    return [] if x==y else [dict(field=path,current=x,before=y)]
assert sys.byteorder=='little'
ready_path=(a.ready or S/f'qwen-ready-attempt{a.attempt}.json').resolve();ready=read(ready_path)
old_ready_path=F/'qwen-ready-attempt3.json';old_ready=read(old_ready_path)
keys=('processed_tokens','generated_tokens','actual_graph_calls','actual_graph_tokens','prefix_hits','prefix_misses','prefix_full_hits','reused_tokens')
cases={};total=bf16=f32=0
for name,count in [('single',18),('multi',72),('main',22),('pressure',30)]:
    current=S/f'{name}-run{a.attempt}';before=F/f'{name}-run3'
    nr,br=read(current/'result.json'),read(before/'result.json')
    assert nr['exit']==br['exit']==0 and nr['image']==ready['image'] and br['image']==old_ready['image']
    assert nr['ready']==identity(ready_path) and br['ready']==identity(old_ready_path)
    x,y=read(current/'observation.json'),read(before/'observation.json')
    for directory,d in [(current,x),(before,y)]:
        assert json.loads((directory/'stdout.log').read_text(encoding='utf-8-sig').splitlines()[-1])==d
    assert all(x[k]==y[k] for k in keys)
    xs,ys=x.get('sessions',[x]),y.get('sessions',[y]);assert len(xs)==len(ys)
    for n,b in zip(xs,ys):
        assert n.get('session_id')==b.get('session_id') and n['generated_ids']==b['generated_ids'] and n['visible_tokens']==b['visible_tokens']
        assert [{k:v[k] for k in ('turn','kind','name','input_tokens','context_before','context_after')} for v in n['phases']]==[
            {k:v[k] for k in ('turn','kind','name','input_tokens','context_before','context_after')} for v in b['phases']]
    av={v.relative_to(current/'trace').as_posix():v for v in (current/'trace').rglob('*') if v.name in ('hidden.bf16','logits.f32')}
    bv={v.relative_to(before/'trace').as_posix():v for v in (before/'trace').rglob('*') if v.name in ('hidden.bf16','logits.f32')}
    assert av.keys()==bv.keys() and len(av)==count
    tensors=[]
    for rel,file in sorted(av.items()):
        data=file.read_bytes();assert data==bv[rel].read_bytes()
        kind='H' if file.suffix=='.bf16' else 'I';mask=0x7f80 if kind=='H' else 0x7f800000
        words=array(kind);words.frombytes(data);assert all((x&mask)!=mask for x in words)
        if kind=='H':bf16+=len(words)
        else:f32+=len(words)
        tensors.append(dict(relative=rel,bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
    total+=count
    changes=diff(stable(x),stable(y))
    cases[name]=dict(current_receipt=identity(current/'result.json'),baseline_receipt=identity(before/'result.json'),
        vector_count=count,all_byte_equal=True,all_finite=True,semantic_work_ids_and_context_equal=True,
        non_timing_observation_differences=changes,tensors=tensors)
assert (total,bf16,f32)==(142,145408,17630720)
out=dict(status='PASS',current_ready=identity(ready_path),baseline_ready=identity(old_ready_path),checker=identity(__file__),
    vector_count=total,bf16_elements=bf16,f32_elements=f32,nonfinite=0,cases=cases,
    scope='Actual decision outputs and semantic work/IDs/contexts, not independent quality. Changed execution/cache preparation metadata is reported, not silently required equal or hidden.',
    builds=0,GPU_runs=0)
target=S/f'runtime-comparison{a.attempt}.json';target.write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(report=identity(target),vectors=total,finite=True,all_byte_equal=True)))
