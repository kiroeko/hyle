"""Freeze the actual two consumer sources; no build or GPU work."""
from pathlib import Path
import difflib, hashlib, json
S=Path(__file__).resolve().parent; R=S.parents[1]
def identity(p):
    p=Path(p).resolve(); data=p.read_bytes()
    return dict(path=str(p),bytes=len(data),sha256=hashlib.sha256(data).hexdigest())
rows=[]
for name,before in [('main.cc',S/'implementation/main.before.cc'),
                    ('retirement_probe.cc',S/'review/before/tools/qwen35_text/retirement_probe.cc')]:
    current=R/'tools/qwen35_text'/name
    frozen=S/'implementation/source/tools/qwen35_text'/name
    frozen.parent.mkdir(parents=True,exist_ok=True); frozen.write_bytes(current.read_bytes())
    patch=S/'implementation'/(name+'.diff')
    patch.write_text(''.join(difflib.unified_diff(before.read_text(encoding='utf-8').splitlines(True),
        current.read_text(encoding='utf-8').splitlines(True),fromfile=str(before),tofile=str(current))),encoding='utf-8')
    rows.append(dict(current=identity(current),frozen=identity(frozen),before=identity(before),diff=identity(patch)))
value=dict(files=rows,first_main=identity(S/'implementation/main.attempt1.cc'),
    final_qwen_ready=identity(S/'qwen-ready-attempt2.json'),final_probe_ready=identity(S/'probe-ready-attempt2.json'),
    scope='Consumer state/execution ownership and safe resource reuse only; no public Compute/Graph API, provider, native kernel, weights or mathematical changes.',
    builds=dict(CXX=4,links=4,NVCC=0,SDK_builds=0),
    initial_window='performance/* retained completely. First draft moved off-mode cold preparation into first requests; final explicitly prepares the known ordered off plan in its original cold boundary. Prefix-mode first actual preparation stays in request wall. No favorable-only selection.')
(S/'implementation/source-freeze.json').write_text(json.dumps(value,indent=2)+'\n',encoding='utf-8')
print(json.dumps(identity(S/'implementation/source-freeze.json')))
