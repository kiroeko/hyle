"""Root-only publish of final shared-execution evidence; no build/run/cleanup."""
from pathlib import Path
from datetime import datetime,timezone
import difflib,hashlib,json,zipfile
S=Path(__file__).resolve().parent;R=S.parents[1]
STEM='qwen-shared-execution-2026-10-21'
FINAL_MAIN='08a3a5c8289af2f4cf3c204c609128c8d671d58c01ddc099a8e1bb7d37ddaf3f'
ALLOWED={'.json','.py','.ps1','.log','.diff','.patch','.txt','.md','.cc','.cpp','.h','.tsv','.xml','.ids'}

def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def identity(p):
    p=Path(p).resolve();data=p.read_bytes();return dict(path=str(p),bytes=len(data),sha256=hashlib.sha256(data).hexdigest())
def verify(row):
    assert identity(row['path'])==row, 'Identity drift: '+str(row['path'])
    return row
def save(p,v):p.write_text(json.dumps(v,indent=2,allow_nan=False)+'\n',encoding='utf-8')
def terminal(path):
    value=read(path);assert value['exit']==0 and not value.get('timeout'),path
    return value

def main():
    report_path=R/'docs/evidence/performance'/(STEM+'.json');archive=report_path.with_suffix('.zip')
    assert not report_path.exists() and not archive.exists(), 'Published evidence must not be overwritten'
    ready_path=S/'qwen-ready-attempt2.json';probe_path=S/'probe-ready-attempt2.json'
    ready,probe=read(ready_path),read(probe_path)
    assert ready['source']['sha256']==FINAL_MAIN
    for value in (ready,probe):
        verify(value['image']);verify(value['source']);verify(value['link_plan']);verify(value['runtime_environment'])
    source_path=S/'implementation/source-freeze.json';freeze=read(source_path)
    assert len(freeze['files'])==2 and freeze['final_qwen_ready']==identity(ready_path) and freeze['final_probe_ready']==identity(probe_path)
    for row in freeze['files']:
        for name in ('current','frozen','before','diff'):verify(row[name])
        assert row['current']['sha256']==row['frozen']['sha256']
    verify(freeze['first_main'])
    assert freeze['first_main']['sha256']==read(S/'qwen-ready-attempt1.json')['source']['sha256']
    main_row=next(row for row in freeze['files'] if Path(row['current']['path']).name=='main.cc')
    texts={name:Path(record['path']).read_text(encoding='utf-8') for name,record in
        [('before',main_row['before']),('attempt1',freeze['first_main']),('final',main_row['frozen'])]}
    trial_diffs=[]
    for before,after in [('before','attempt1'),('attempt1','final')]:
        target=S/'implementation'/f'main.{before}-to-{after}.diff'
        text=''.join(difflib.unified_diff(texts[before].splitlines(True),texts[after].splitlines(True),
            fromfile='main.'+before+'.cc',tofile='main.'+after+'.cc'))
        if target.exists():assert target.read_text(encoding='utf-8')==text
        else:target.write_text(text,encoding='utf-8')
        trial_diffs.append(identity(target))
    builds=[]
    for attempt in (1,2):
        for mode,tag in [('qwen','main'),('probe','probe')]:
            value=read(S/f'{mode}-ready-attempt{attempt}.json');plan=read(value['link_plan']['path'])
            assert len(plan['inputs'])==195 and len(plan['replaced_inputs'])==1 and not plan['added_inputs'] and plan['unchanged_inputs']==194
            record_path=S/f'compile{attempt}'/tag/'identity.json';record=read(record_path)
            verify(record['object']);assert record['source']==value['source']
            snapshot=record_path.parent/'source'/Path(record['source']['path']).relative_to(R)
            assert identity(snapshot)['sha256']==record['source']['sha256']
            assert all(x in record['command'] for x in ('/W4','/WX','/O2','/MD'))
            compile_receipt=S/f'compile{attempt}'/tag/'compile.result.json';link_receipt=S/f'{mode}-link{attempt}/link.result.json'
            terminal(compile_receipt);terminal(link_receipt)
            builds.append(dict(mode=mode,attempt=attempt,compile=identity(compile_receipt),link=identity(link_receipt),
                actual_source=record['source'],object=record['object'],snapshot=identity(snapshot),ready=identity(S/f'{mode}-ready-attempt{attempt}.json')))
    for name in ('single','multi','main','pressure','probe'):
        receipt=terminal(S/f'{name}-run2/result.json')
        assert receipt['image']==(probe if name=='probe' else ready)['image']
    numeric_path=S/'review/runtime-comparison2.json';numeric=read(numeric_path)
    assert numeric['current_ready']==identity(ready_path) and numeric['total_decision_vectors']==142
    assert numeric['canonical_vectors']==90 and numeric['prefix_and_pressure_vectors']==52 and numeric['all_byte_equal']
    assert numeric['finite_counts']['nonfinite_elements']==0 and numeric['closure']['unchanged_inputs']==194
    probe_observation=read(S/'probe-run2/observation.json')
    assert probe_observation['status']=='PASS' and probe_observation['busy_prepare_rejections']==3
    assert probe_observation['old_kv_guards_and_bytes_unchanged'] and probe_observation['old_recurrent_resources_byte_unchanged']==36
    assert probe_observation['idle_stop_preserved_other_execution_loan'] and probe_observation['retired_aborted_slot_rebuilt_in_same_model_bundle']
    assert probe_observation['post_commit_trace_error_preserved_head_and_returned_loan'] and probe_observation['different_session_continued_after_report_error']
    assert probe_observation['native_error_injected'] is False and probe_observation['cancel_means_native_preemption'] is False
    windows={}
    for workload,counts in [('single',dict(timing=12,memory=4)),('multi',dict(timing=9,memory=3))]:
        folder=S/'performance2'/workload;table=read(folder/'public-table.json');review=read(folder/'performance-review.json')
        assert table['images']['current']==ready['image'] and review['public_table']==identity(folder/'public-table.json')
        actual={}
        for mode,count in counts.items():
            inputs=read(folder/mode/'inputs.json');runs=read(folder/mode/'runs.json')
            assert len(runs)==count and inputs['images']['current']==ready['image']
            for row in runs:
                proc=terminal(Path(row['folder'])/'result.json');assert proc==row['process']
                assert proc['image']==inputs['images'][row['variant']] and proc['memory_only']==(mode=='memory')
                assert not proc['profiler']
            actual[mode]=dict(process_count=count,inputs=identity(folder/mode/'inputs.json'),runs=identity(folder/mode/'runs.json'),summary=identity(folder/mode/'summary.json'))
        windows[workload]=dict(table=identity(folder/'public-table.json'),independent_review=identity(folder/'performance-review.json'),
            final_window=True,rates={a:{k:v['median'] for k,v in group['rates'].items()} for a,group in table['timing'].items()},
            comparisons=table['comparison'],processes=actual,limits=table['limits'])
    cleanup_plan=identity(S/'cleanup-plan.json');cleanup_script=identity(S/'cleanup-script.ps1')
    assert identity(R/'test.ps1')['sha256']==cleanup_script['sha256']
    docs=[R/x for x in ['docs/developer/current-work.md','docs/developer/performance/README.md',
        'docs/developer/performance/decode.md','docs/architecture/compute-design.md','docs/architecture/graph-design.md']]
    paths={}
    def add(p):
        p=Path(p).resolve();assert p.is_file() and p.is_relative_to(R)
        assert p.suffix.lower() in ALLOWED
        paths[p.relative_to(R).as_posix()]=p
    for p in S.rglob('*'):
        rel=p.relative_to(S)
        if p.is_file() and p.suffix.lower() in ALLOWED and not any(x in rel.parts for x in ('tmp','__pycache__')) and p.name!='published.json':add(p)
    for p in docs:add(p)
    for row in freeze['files']:add(row['current']['path'])
    # Only tiny fixed-input/parser/helper sources; no tensor, model or SDK trees.
    tiny_trees=[R/'.scratch/qwen-prefix-20261021/inputs',R/'.scratch/multi-session-performance-20261021/inputs',
        R/'.scratch/architecture-refactor-2026-10-18/d4-windows-preparation-2026-10-21/first-decode-startup-2026-10-21/multiturn/inputs',
        R/'.scratch/architecture-refactor-2026-10-18/d4-windows-preparation-2026-10-21/first-decode-startup-2026-10-21/multi-session-isolation-2026-10-21/inputs']
    for folder in tiny_trees:
        assert folder.is_dir(), folder
        for p in folder.rglob('*'):
            if p.is_file() and p.suffix.lower() in ('.json','.txt','.ids'):add(p)
    for rel in ['tools/qwen35_text/session_state.h','tools/qwen35_text/schedule.h','tools/qwen35_text/session_schedule.h','tools/qwen35_text/prefix_cache.h',
        '.scratch/paged-host-prepare-20261021/qwen-ready-attempt3.json','.scratch/paged-host-prepare-20261021/probe-ready-attempt3.json',
        '.scratch/multi-session-performance-20261021/peer-ready-attempt1.json','.scratch/multi-session-performance-20261021/peer/peer_prefix_benchmark.cpp',
        '.scratch/paged-prepare-20261021/performance.py','.scratch/multi-session-performance-20261021/performance.py',
        '.scratch/paged-exclusive-20261021/build.py','.scratch/paged-capture-20261021/build.py',
        '.scratch/qwen-prefix-20261021/run.py','.scratch/paged-retirement-20261021/run_probe.py',
        '.scratch/architecture-refactor-2026-10-18/d4-windows-preparation-2026-10-21/first-decode-startup-2026-10-21/multiturn/multiturn_run.py',
        '.scratch/architecture-refactor-2026-10-18/qwen-gpu-comparison/memory-probe/memory_probe.py']:
        add(R/rel)
    inventory=[dict(archive_path=n,**identity(p)) for n,p in sorted(paths.items())]
    with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for n,p in sorted(paths.items()):z.write(p,n)
        z.writestr('manifest.json',json.dumps(dict(files=inventory,
            scope='Selected before/first/final source+diffs; actual compile/link/run commands and all raw process JSON/logs; both performance rounds, independent reviews, current docs and exact cleanup plan.',
            exclusions='No exe,obj,dll,map,lib,exp,SDK/model bytes or duplicate hidden/logits payloads. Final run2 vectors/current qwen2/allobjects remain in scratch.',
            final_measurement='Only performance2 and qwen/probe-ready-attempt2 support final claims. performance is a retained non-final draft and must not be pooled with final numbers.'),indent=2))
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None
        for row in inventory:assert hashlib.sha256(z.read(row['archive_path'])).hexdigest()==row['sha256']
    report=dict(date='2026-10-21',created_utc=datetime.now(timezone.utc).isoformat(),
        status='Shared Model execution carriers implemented and checked in this Windows CUDA consumer; finite single/multi timing+memory windows complete. Overall goal remains active.',
        goal_status='active',archive=identity(archive),archive_file_count=len(inventory),
        current_ready=identity(ready_path),current_image=ready['image'],current_source=ready['source'],
        source_freeze=identity(source_path),sources=freeze['files'],first_source=freeze['first_main'],docs=[identity(p) for p in docs],
        build=dict(CXX=4,links=4,NVCC=0,SDK_builds=0,actual_commands=builds,
            closure='For each image one consumer object replaced and194/195 original F input records retained, including append15c8 and all current native/weight/core owners.'),
        correctness=dict(independent_review=identity(numeric_path),vector_files=142,canonical=90,prefix_and_pressure=52,all_byte_equal=True,
            finite_counts=numeric['finite_counts'],probe_ready=identity(probe_path),probe_result=identity(S/'probe-run2/result.json'),probe=probe_observation),
        final_performance=windows,
        nonfinal_history=dict(root=str(S/'performance'),source_diffs=trial_diffs,scope='Preserved first-draft raw windows and reviews, not final evidence and not pooled.',
            reason='First draft lazily moved known off-plan first-use preparation from ready into firstP. Final restores ordered off calls at the original explicit cold boundary and only actual execution slot; prefix-mode preparation remains in request timing.'),
        observer=dict(source=identity(S/'observer.py'),host_checks=identity(S/'observer-checks.json'),
            scope='Session-prefixed phase markers received dynamically. Null/zero-interior-sample phases, ready baselines, exactbytes, bracket ages/deltas, actual sample gaps and sample cost are retained. Historical oldM timestamps are not reconstructed.'),
        cleanup_plan=cleanup_plan,cleanup_script=cleanup_script,
        limits=['This is a private consumer ownership/resource preparation change; public mathematical/provider/kernel contracts and weights were not changed.',
            'Finite teacher-forced WindowsCUDA journeys, one serialized execution loan and bounded complete state. Not multi-batch/concurrent GPU throughput or a general serving scheduler.',
            'Other native backends, MTP/images/all-model integration and the broader goal remain incomplete. Successful cancellation/abandonment/post-commit-reporting checks are not a native error-injection or GPU-preemption proof.',
            'All rates are per-process ratios then3-process median/ranges, using after-ready full session wall separately from startup/load. Multi logical and actual prefill stay distinct. No profiled or sampled-memory time in TPS.',
            'Small desktop window with uncontrolled clocks; no universal ranking/quality/statistical-significance claim. One independent memory process per image/workload; sampled peaks/neighbor deltas do not attribute physical allocations.',
            'Same logical contexts/complete prefix semantics do not imply byte-identical native provisioning or identical intermediate arithmetic/host logits transfer across engines.',
            'Archive excludes binary tensors; their exact hashes/comparisons remain in reviews and final run2 payloads stay retained. First attempt raw history is preserved before exact duplicates are removed.'])
    save(report_path,report)
    save(S/'published.json',dict(files=[identity(report_path),identity(archive)],archive_files=len(inventory),cleanup_plan=cleanup_plan,cleanup_script=cleanup_script))
    print(json.dumps(read(S/'published.json'),indent=2))

if __name__=='__main__':main()
