"""Root-only serial timing/memory, preserving original F/M command workloads."""
from pathlib import Path
import argparse,sys
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent;R=S.parents[1]
p=argparse.ArgumentParser();p.add_argument('workload',choices=('single','multi'));p.add_argument('mode',choices=('timing','memory'))
p.add_argument('--ready',type=Path,default=S/'qwen-ready-attempt1.json');p.add_argument('--output',type=Path);p.add_argument('--check-only',action='store_true')
_arguments=p.parse_args();_arguments.ready=_arguments.ready.resolve()
_output=(_arguments.output or S/'performance'/_arguments.workload/_arguments.mode).resolve()
if not _output.is_relative_to(S):raise RuntimeError('New outputs must remain under the new stage')
M=R/'.scratch/multi-session-performance-20261021'
if _arguments.workload=='single':
    _origin=R/'.scratch/paged-prepare-20261021/performance.py'
    source=_origin.read_text(encoding='utf-8')
    edits=[
        ("parser = argparse.ArgumentParser()\nparser.add_argument('mode', choices=('timing', 'memory'))\nargs = parser.parse_args()",'args = _arguments'),
        ("current=S / 'qwen-ready.json'","current=_arguments.ready"),
        ("before=R / '.scratch/paged-recording-20261021/qwen-ready.json'","before=R / '.scratch/paged-host-prepare-20261021/qwen-ready-attempt3.json'"),
        ("out = S / 'performance' / args.mode","out = _output"),
        ("spec.loader.exec_module(m)","spec.loader.exec_module(m)\nfrom observer import install\ninstall(m)"),
        ('Compare current generic lookup/page-set changes to exact previous paged ff42 closure, dense Hyle and matched llama.cpp;',
         'Compare shared-execution consumer to exact previous F source2/append-index image, dense Hyle and matched llama.cpp;')]
else:
    _origin=M/'performance.py';source=_origin.read_text(encoding='utf-8')
    edits=[
        ("p=argparse.ArgumentParser();p.add_argument('mode',choices=('timing','memory'));a=p.parse_args()",'a=_arguments'),
        ("current=R/'.scratch/paged-host-prepare-20261021/qwen-ready-attempt3.json'",'current=_arguments.ready'),
        ("before=R/'.scratch/paged-exclusive-20261021/qwen-ready-attempt1.json'","before=R/'.scratch/paged-host-prepare-20261021/qwen-ready-attempt3.json'"),
        ("peer=S/'peer-ready-attempt1.json'","peer=R/'.scratch/multi-session-performance-20261021/peer-ready-attempt1.json'"),
        ("plan=m.read(S/'inputs/plan.json')","plan=m.read(R/'.scratch/multi-session-performance-20261021/inputs/plan.json')"),
        ("out=S/'performance'/a.mode","out=_output"),
        ("sp.loader.exec_module(m)","sp.loader.exec_module(m)\nfrom observer import install\ninstall(m)"),
        ("m.save(out/'inputs.json',dict(plan=plan,", "m.save(out/'inputs.json',dict(driver=m.identity(__file__),original_driver=m.identity(_origin),observer=m.identity(S/'observer.py'),plan=plan,")]
for old,new in edits:
    if source.count(old)!=1:raise RuntimeError('Retained helper changed: '+old)
    source=source.replace(old,new)
if _arguments.check_only:
    import ast,json,hashlib
    ast.parse(source)
    print(json.dumps(dict(status='PASS',workload=_arguments.workload,mode=_arguments.mode,
        expanded_helper_sha256=hashlib.sha256(source.encode('utf-8')).hexdigest(),
        current_ready=str(_arguments.ready),before_ready=str(R/'.scratch/paged-host-prepare-20261021/qwen-ready-attempt3.json'),
        observer=str(S/'observer.py'),output=str(_output),builds=0,GPU_runs=0)))
else:exec(compile(source,str(Path(__file__).resolve()),'exec'),globals())
