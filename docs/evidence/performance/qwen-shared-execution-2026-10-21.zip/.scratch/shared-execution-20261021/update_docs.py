"""Update the single current progress entry from final per-process results."""
from pathlib import Path
import json,statistics
S=Path(__file__).resolve().parent;R=S.parents[1]
read=lambda p:json.loads(Path(p).read_text(encoding='utf-8-sig'))
single=read(S/'performance2/single/public-table.json');multi=read(S/'performance2/multi/public-table.json')
evidence='../evidence/performance/qwen-shared-execution-2026-10-21.json'
def rate(t,arm,key):return t['timing'][arm]['rates'][key]['median']
def change(t,other,key):return 100*(rate(t,'current',key)/rate(t,other,key)-1)
def value(t,arm,key):
    g=t['timing'][arm]
    if key in ('session_seconds','startup_total_seconds'):return g[key]['median']
    return g['loading'][key]['median']
def row(label,items,places=2):return '| '+label+' | '+' | '.join(f'{v:.{places}f}' for v in items)+' |\n'
def memory(t,arm,key):return t['independent_memory'][arm]['observed_sampled_peaks_bytes'][key]/2**30
def table(t,arms,metrics):
    text=''
    for label,key in metrics:text+=row(label,[rate(t,a,key)for a in arms])
    for label,key in [('推理全程wall s','session_seconds'),('入口至末输出 s（含加载／冷准备）','startup_total_seconds'),('启动至ready s','startup_to_ready_seconds'),('权重加载 s（非冷盘带宽）','model_load_seconds')]:
        text+=row(label,[value(t,a,key)for a in arms],5)
    for label,key in [('GPU dedicated观测峰 GiB','gpu_dedicated_bytes'),('GPU shared观测峰 GiB','gpu_shared_bytes'),('GPU同点总量观测峰 GiB','gpu_total_bytes'),('CPU working set观测峰 GiB','working_set_bytes'),('进程private commit观测峰 GiB','private_commit_bytes')]:
        text+=row(label,[memory(t,a,key)for a in arms],3)
    return text
def ranges(t,key):
    return '／'.join(f"{t['timing'][a]['rates'][key]['min']:.2f}–{t['timing'][a]['rates'][key]['max']:.2f}"for a in t['timing'])
def phases(t,arm,names):
    out=[]
    for name in names:
        v=t['independent_memory'][arm]['phase_windows'][name]['sampled_peaks_bytes']['gpu_dedicated_bytes']
        out.append('未知'if v is None else f'{v/2**30:.3f}')
    return '→'.join(out)
tail='''## 最新完整性能对比

**2026-10-21，Model执行资源复用后的最终窗口。** Windows／RTX 4070 12GB，Qwen3.5-2B BF16、F32 GDN，无MTP／图片。当前`e0a71239…`，本批前`e7a7597d…`，原dense `ff748694…`；参考沿原`d9e03f1074db…`库与同BF16权重。每个消费者镜像只替换一个host对象，194／195输入保持；未改公共Compute／Graph API、数学、原生kernel或Provider DLL。

单会话仍是`(256新增输入＋32 decode)×3`、容量1024、最终上下文864；各3新进程交错测速，显存另各1进程旁采。固定teacher-forced历史、99个host预测一致；关闭trace、诊断和前缀目录。无前缀模式在原ready前显式准备已知有序计划实际用到的shape／slot，未将首用构造藏到计时外。

| 指标 | 当前Hyle | 本批前Hyle | 原dense Hyle | llama.cpp |
| --- | ---: | ---: | ---: | ---: |
'''
arms=list(single['timing'])
tail+=table(single,arms,[('合计prefill tok/s（768／P总wall）','prefill_tps'),('完整decode tok/s（96／D总wall）','full_decode_tps'),('综合输出 tok/s（99／全程wall）','session_output_tps')])
tail+=f'''
各进程先求比值，再取3进程中位。相对本批前，prefill {change(single,'before','prefill_tps'):+.2f}%、decode {change(single,'before','full_decode_tps'):+.2f}%、综合 {change(single,'before','session_output_tps'):+.2f}%；decode／综合范围重叠，**本批未证明单会话吞吐改善**。相对参考decode {change(single,'peer','full_decode_tps'):+.2f}%、综合 {change(single,'peer','session_output_tps'):+.2f}%，剩余差距继续保留。
current／before／dense／参考的decode范围：**{ranges(single,'full_decode_tps')} tok/s**；综合范围：**{ranges(single,'session_output_tps')} tok/s**。

阶段dedicated观测峰按P1→D1→P2→D2→P3→D3列出，GiB：
'''
names=[f'round{i}_{kind}'for i in range(1,4)for kind in ('prefill','decode')]
for arm in arms:tail+=f"{arm}：**{phases(single,arm,names)}**。\n\n"
tail+='''### 多会话共享前缀：资源复用后的对照

4个命名会话、active1，按turn串行；不是一次多序列GPU batch。原P128＋D1完整检查点129，A／B分别补T1／T16后D32，完整命中0Graph，seed再P16＋D32。双方645逻辑输入、102输出，实际161个prefill＋97个decode token、101次模型调用，3次命中／1次全命中、复用387token，无淘汰恢复。本窗各3新进程测速、另各1进程显存旁采，12进程全部ID及工作量一致。

| 指标 | 当前Hyle | 本批前Hyle | llama.cpp多会话消费者 |
| --- | ---: | ---: | ---: |
'''
tail+=table(multi,list(multi['timing']),[('逻辑prefill tok/s（548／P总wall）','logical_prefill_tps'),('实际prefill tok/s（161／同一P总wall）','actual_prefill_tps'),('完整decode tok/s（97／D总wall）','full_decode_tps'),('综合输出 tok/s（102／全程wall）','session_output_tps')])
tail+=f'''
相对本批前，实际prefill {change(multi,'before','actual_prefill_tps'):+.2f}%、decode {change(multi,'before','full_decode_tps'):+.2f}%、综合 {change(multi,'before','session_output_tps'):+.2f}%；相对参考分别 {change(multi,'peer','actual_prefill_tps'):+.2f}%、{change(multi,'peer','full_decode_tps'):+.2f}%、{change(multi,'peer','session_output_tps'):+.2f}%。**重复构造已消除，多会话中位综合改善；尚未追平参考，单会话也没有因此变快。**
current／before／参考的decode范围：**{ranges(multi,'full_decode_tps')} tok/s**；综合范围：**{ranges(multi,'session_output_tps')} tok/s**。当前保留了一个明显偏慢进程，范围重叠，不签稳定普遍收益，也不删慢样本重测寻找正号。

前缀模式的首次实际T1槽仍在首次decode的显式prepare中构造；旧版在每会话prompt接纳时先建所有槽。因此P／D子桶所含冷准备有所迁移，**不能把prefill改善或decode下降全归因于数学kernel**。完整请求及全程wall保留这些必要工作。原ready前可提前准备的off模式边界在最终版保持；首稿的全部计时／内存与负结果另保留在证据中，不替代最终表。

本窗当前／before的dedicated观测峰相差88MiB，working set／private commit观测峰也降低；这是各1进程的采样结果，不当作精确分配节省。双方Hyle状态backing仍为110,469,168字节；变化在执行载体及其附属资源，不减少保留会话／完整状态额度。参考状态backing为113,590,272字节、统一1024物理KV行／5个native seq ID，Hyle池1040行／4份committed＋1份candidate，仍不是逐字节相同配额。

新采样器已实际收到各会话9个phase的18个边界，保留阶段观测峰及邻样变化；完整命中等短阶段可能无样本。按seed P→D1→A P→D32→B P→D32→fullhit→seed P2→D32列dedicated观测峰，GiB：
'''
names=['seed_round1_prefill','seed_round1_decode','branch_a_round1_prefill','branch_a_round1_decode','branch_b_round1_prefill','branch_b_round1_decode','full_hit_round1_prefill','seed_round2_prefill','seed_round2_decode']
for arm in multi['timing']:tail+=f"{arm}：**{phases(multi,arm,names)}**。\n\n"
tail+=f'''两组内存旁采请求10ms，实际中位约15ms；ready基线均未知，阶段值是采样下界，邻样delta含边界间隙及可能的后续工作／退出，不冒充精确分配或释放。GPU总量峰取同一采样点之和，不能加dedicated／shared独立峰；CPU驻留与commit分列。

本批142份真实hidden／logits向量逐字节相同且全部有限；阻塞CUDA队列时，取消／丢弃Completion仍保42,418,224字节backing，旧KV及36份conv／GDN不变；空闲Session停止不关闭他人借用，三个prepare被拒，退休后同槽重建。发布后写trace失败仍保留已提交状态并归还借用，另一会话继续成功。不是全模型质量、其它系统原生消费者或GPU同时多人吞吐验收。

[{evidence.split('/')[-1]}]({evidence})保留两轮全部原始样本、源码、增量命令、实际状态／寿命检查和独立复算。未重采物理kernel trace，不沿用旧计数宣称本批结构收益。下一步接真实多序列batch；MTP、图片及其它原生后端仍未完成。
'''
p=R/'docs/developer/current-work.md';text=p.read_text(encoding='utf-8')
text=text[:text.index('## 最新完整性能对比')]+tail
lines=text.splitlines()
for i,line in enumerate(lines):
    if line.startswith('**当前正在做：'):
        lines[i]='**当前正在做：执行资源已改为Model按实际并发复用，相关状态／寿命回归和两组完整性能对照已完成；下一步接真实多序列batch。** Session保完整KV／conv／GDN、位置与历史，不再各留一套Invocation／IO／workspace。前缀、分支、有界淘汰恢复、CUDA在途回收、可录制写页、独占尾权与有界Radix索引已接通并完成对应检查；Radix索引完成不等于多序列同时批处理或全部后端原生路径完成。'
    elif line.startswith('[此前重复准备及输出发布扫描修复]'):
        lines[i]=f'[此前重复准备及输出发布扫描修复](../evidence/performance/qwen-retirement-publication-2026-10-21.json)保留。[最新执行资源复用窗口]({evidence})单会话decode为101.25对参考105.38，仍差约3.92%；多会话共享前缀综合91.99对95.12，慢约3.29，相对本批前中位改善6.80%。当前有慢进程、范围重叠，不作稳定普遍收益承诺；完整四项及口径变化见页末。'
    elif line.startswith('| 2 | 多会话缓存复用'):
        lines[i]='| 2 | 多会话缓存复用 | **真实Qwen前缀、分支、完全命中、有界恢复及CUDA异步回收已验证**。同645逻辑输入／102输出、258实际计算token完成资源复用后对照；当前仍串行交错，未接GPU同时批处理。其它系统原生写页与完整消费者仍有实现／验证工作 |'
    elif line.startswith('| 2c |'):
        lines[i]=f'| 2c | 执行资源复用 | **[已实现并完成本批检查]({evidence})**。Phase／Invocation／IO／workspace归Model，按原串行实际并发整体借用；只准备实际shape／slot，Session停止不关闭共享池。142份向量一致；取消／丢弃Completion保留借用至真实退休，失败槽重建、提交后trace错误及另一会话继续均实测通过 |'
    elif line.startswith('| 2d |'):
        lines[i]='| 2d | 多序列批处理与其它后端 | **下一步实现**。Conv／GDN已有独立B维；先补opaque ready页帧的typed合并／投影，再接真实B2／T1 batch与各序列状态／结果分流、取消退休及N＋R候选额度。不是多个串行evaluate包装成batch。Apple／Vulkan原生新写页及完整消费者另有缺口 |'
    elif line.startswith('| 并行 | 已知性能慢项'):
        lines[i]='| 并行 | 已知性能慢项 | 可录制paged写入、尾权小分配、selected-slot扫描及执行资源重复创建已修。单会话分页decode仍慢，descriptor上传依赖、随历史增长的页组织、cached-prefill首用／合法拓扑变化仍查；性能与内存最新窗口见页末 |'
    elif line.startswith('近期顺序：'):
        lines[i]='近期顺序：**执行资源复用及本批相关回归／两组对照已完成 → typed页帧组合与真实多序列batch → MTP真实消费者 → 图片链路**。其它后端必要实现与原生验证继续保留；单会话延迟、多人总吞吐与缓存命中收益分别报告。每批只做相关增量检查和阶段对照，不以反复全量验证拖延功能。'
    elif line.startswith('本轮资源复用的收尾是：'):
        lines[i]='本轮资源复用已收尾，实际结果见页末。当前Radix复用已有完整KV／conv／GDN检查点；任意token处分叉不能只切KV便宣称得到可续算状态。多序列batch与其它后端仍须实现，不是只剩验证，也不以一个CUDA消费者通过代替全部模型／系统完成。'
p.write_text('\n'.join(lines)+'\n',encoding='utf-8')
print('Updated current-work with final single/multi tables; no model/build/GPU work.')
