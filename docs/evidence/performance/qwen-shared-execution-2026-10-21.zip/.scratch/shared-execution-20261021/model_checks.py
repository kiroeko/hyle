"""Root-only original canonical18/72 and prefix52 process entry points."""
from pathlib import Path
S=Path(__file__).resolve().parent;R=S.parents[1]
source=(R/'.scratch/qwen-prefix-20261021/run.py').read_text(encoding='utf-8')
for old,new in [
    ("plan = m.read(S / 'inputs/plan.json')","plan = m.read(R / '.scratch/qwen-prefix-20261021/inputs/plan.json')"),
    ("S / f'ready-attempt{args.attempt}.json'","S / f'qwen-ready-attempt{args.attempt}.json'")]:
    assert source.count(old)==1;source=source.replace(old,new)
exec(compile(source,str(Path(__file__).resolve()),'exec'),globals())
