"""Read-only independent calculation from completed raw multi-session processes."""
from pathlib import Path
import argparse, collections, hashlib, json, re, statistics

S=Path(__file__).resolve().parents[1];R=S.parents[1]
p=argparse.ArgumentParser();p.add_argument('--window',type=Path,default=S/'performance2/multi')
p.add_argument('--tag',default='multi-performance');args=p.parse_args();W=args.window.resolve()
assert W.is_relative_to(S/'performance2')
def read(p):return json.loads(Path(p).read_text(encoding='utf-8'))
def identity(p):
    p=Path(p);b=p.read_bytes();return dict(path=str(p.relative_to(R)),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def stats(xs):return dict(count=len(xs),min=min(xs) if xs else None,median=statistics.median(xs) if xs else None,max=max(xs) if xs else None,samples=xs)
def save(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def hyle_steps(text):
    session=None;prepared=None;steps=[];children=collections.defaultdict(list);active=None
    for line in text.splitlines():
        m=re.fullmatch(r'memory_phase=(.+)_begin',line)
        if m:active=m[1]
        if re.fullmatch(r'memory_phase=(.+)_end',line):active=None
        m=re.search(r'^compiled T=(\d+).*child_prepare_seconds=([\deE.+-]+)$',line)
        if m:children[active].append(dict(T=int(m[1]),seconds=float(m[2])))
        m=re.fullmatch(r'session_steps id=(\S+)',line)
        if m:session=m[1]
        m=re.fullmatch(r'prepared T=(\d+) visible=(\d+) replay=(\S+) cold_batch_seconds=([\deE.+-]+) capture_recorded=(\d+) capture_reused=(\d+)',line)
        if m:prepared=dict(T=int(m[1]),cold=float(m[4]),recorded=int(m[5]),reused=int(m[6]),route=m[3])
        m=re.fullmatch(r'(round\d+_(?:prefill|decode\d+)) tokens=(\d+) visible=(\d+) seconds=([\deE.+-]+) submit_seconds=([\deE.+-]+) step_seconds=([\deE.+-]+) progress=(\S+) next=(\d+)',line)
        if m:
            assert session is not None
            steps.append(dict(session=session,name=m[1],logical=int(m[2]),visible=int(m[3]),next=int(m[8]),graph_tokens=prepared['T'] if prepared else 0,
                              step_seconds=float(m[6]),submitted_execution_publish_seconds=float(m[4]),prepared=prepared));prepared=None
    return steps,dict(children)

expected=dict(processed_tokens=645,generated_tokens=102,actual_graph_calls=101,actual_graph_tokens=258,prefix_hits=3,prefix_misses=2,prefix_full_hits=1,reused_tokens=387)
phase_contexts={'seed_round1_prefill':(0,128),'seed_round1_decode':(128,129),'seed_round2_prefill':(129,145),'seed_round2_decode':(145,177),
                'branch_a_round1_prefill':(0,130),'branch_a_round1_decode':(130,162),'branch_b_round1_prefill':(0,145),'branch_b_round1_decode':(145,177),'full_hit_round1_prefill':(0,129)}
rows=[];reference=None;memory={}
for mode,order in [('timing',['current','before','peer','peer','before','current','before','current','peer']),('memory',['before','current','peer'])]:
    inputs=read(W/mode/'inputs.json');folders=sorted(v for v in (W/mode).iterdir() if v.is_dir())
    assert [v.name.split('-',1)[1] for v in folders]==order
    last_end=0
    for folder in folders:
        arm=folder.name.split('-',1)[1];proc=read(folder/'result.json');assert proc['exit']==0 and not proc['reader_errors']
        assert proc['image']==inputs['images'][arm] and proc['memory_only']==(mode=='memory') and not proc['profiler']
        if arm=='current': assert proc['image']['sha256']==read(S/'qwen-ready-attempt2.json')['image']['sha256']
        assert proc['started_unix_ns']>=last_end;last_end=proc['finished_unix_ns']
        path=folder/('peer-result.json' if arm=='peer' else 'stdout.log')
        raw=read(path) if arm=='peer' else json.loads(path.read_text().splitlines()[-1])
        assert all(raw[k]==v for k,v in expected.items())
        ids={v.get('session_id',v.get('id')):v['generated_ids'] for v in raw['sessions']}
        if reference is None:reference=ids
        assert ids==reference and sum(map(len,ids.values()))==102
        phases={v.get('session_id',v.get('id'))+'_'+q['name']:q for v in raw['sessions'] for q in v['phases']}
        assert {k:(v['context_before'],v['context_after']) for k,v in phases.items()}==phase_contexts
        assert sum(v['input_tokens'] for v in phases.values() if v['kind']=='prefill')==548
        assert sum(v['input_tokens'] for v in phases.values() if v['kind']=='decode')==97
        prefill=sum(v['seconds'] for v in phases.values() if v['kind']=='prefill');decode=sum(v['seconds'] for v in phases.values() if v['kind']=='decode')
        wall=raw['session_seconds' if arm=='peer' else 'interleaved_seconds'];text=(folder/'stderr.log').read_text()
        if arm=='peer':
            steps=raw['steps'];children={};assert sum(v['graph_tokens']>0 for v in steps)==101
            full=[v for v in steps if v['full_hit']];assert len(full)==1 and full[0]['graph_tokens']==0 and full[0]['predicted_id']==ids['seed'][1]
            assert raw['native_sequence_quota']==5 and raw['native_n_ctx_seq']==1024 and raw['cache_backing_bytes']==113590272
            assert raw['restored_calls']==0
            native=dict(seq_copy_api_calls=raw['seq_copy_api_calls'],peak_native_versions=raw['peak_native_versions'],prefix_entry_evictions=raw['directory_evictions'])
            startup=dict(model_load_seconds=raw['model_load_seconds'],context_seconds=raw['context_seconds'],ready_seconds=raw['ready_seconds'])
        else:
            steps,children=hyle_steps(text);assert len(steps)==102 and sum(bool(v['prepared']) for v in steps)==101
            full=[v for v in steps if not v['prepared']];assert len(full)==1 and full[0]['session']=='full_hit' and full[0]['next']==ids['seed'][1]
            assert {s:[v['next'] for v in steps if v['session']==s] for s in ids}==ids
            assert not raw['evicted_session_ids'] and all(v['restored_calls']==0 for v in raw['sessions'])
            assert raw['cache_peak_committed_versions']<=4 and raw['cache_live_requested_bytes']==raw['cache_shared_backing_bytes']==110469168
            native=dict(recorded=sum(v['prepared']['recorded'] for v in steps if v['prepared']),reused=sum(v['prepared']['reused'] for v in steps if v['prepared']),
                        pure_decode_reuse_cold=stats([v['prepared']['cold'] for v in steps if 'decode' in v['name'] and v['prepared'] and not v['prepared']['recorded'] and v['prepared']['reused']]))
            m=re.search(r'initialized model_seconds=([\deE.+-]+) shape_prepare_seconds=([\deE.+-]+) startup_to_ready_seconds=([\deE.+-]+)',text)
            startup=dict(model_seconds=float(m[1]),shape_prepare_seconds=float(m[2]),ready_seconds=float(m[3]),weight_load_seconds=float(re.search(r'weights_load_seconds=([\deE.+-]+)',text)[1]))
        assert len(steps)==102 and sum(v['graph_tokens'] for v in steps)==258
        assert {s:sum(v['graph_tokens'] for v in steps if v['session']==s) for s in ids}==dict(seed=177,branch_a=33,branch_b=48,full_hit=0)
        metrics=dict(logical_prefill_tps=548/prefill,actual_prefill_tps=161/prefill,decode_tps=97/decode,output_tps=102/wall,
                     logical_session_tps=645/wall,actual_session_tps=258/wall,prefill_seconds=prefill,decode_seconds=decode,wall_seconds=wall,
                     between_phase_seconds=wall-prefill-decode,startup_total_seconds=raw['startup_total_seconds'],**startup)
        rows.append(dict(mode=mode,arm=arm,folder=str(folder.relative_to(R)),result=identity(folder/'result.json'),raw=identity(path),image=proc['image'],
                         metrics=metrics,phase_seconds={k:v['seconds'] for k,v in phases.items()},children=children,native=native))
        if mode=='memory':
            mem=read(folder/'memory.json');running=[v for v in mem['samples'] if v['process_running']]
            keys=('working_set_bytes','private_commit_bytes','gpu_dedicated_bytes','gpu_shared_bytes','gpu_total_bytes')
            peaks={k:max((v[k] for v in running if v.get(k) is not None),default=None) for k in keys}
            phases_mem={}
            for name in phase_contexts:
                begin=[v['timestamp_ns'] for v in proc['markers'] if v['name']==name+'_begin'];end=[v['timestamp_ns'] for v in proc['markers'] if v['name']==name+'_end']
                assert len(begin)==len(end)==1 and begin[0]<=end[0]
                assert 'memory_phase='+name+'_begin' in text and 'memory_phase='+name+'_end' in text
                samples=[v for v in running if begin[0]<=v['timestamp_ns']<=end[0]]
                before=max((v for v in running if v['timestamp_ns']<=begin[0]),key=lambda v:v['timestamp_ns'],default=None)
                after=min((v for v in running if v['timestamp_ns']>=end[0]),key=lambda v:v['timestamp_ns'],default=None)
                reported=read(folder/'memory-summary.json')['phase_windows'][name]
                assert reported['sample_count']==len(samples) and reported['begin_ns']==begin[0] and reported['end_ns']==end[0]
                phases_mem[name]=dict(sample_count=len(samples),peak_bytes={k:max((v[k] for v in samples if v.get(k) is not None),default=None) for k in keys},
                    bracket_delta_bytes={k:after[k]-before[k] if before and after and before.get(k) is not None and after.get(k) is not None else None for k in keys},
                    before_age_ms=(begin[0]-before['timestamp_ns'])/1e6 if before else None,after_age_ms=(after['timestamp_ns']-end[0])/1e6 if after else None,
                    exact_boundary_values=False)
                assert all(phases_mem[name]['peak_bytes'][k]==reported['values'][k]['max'] for k in keys)
            memory[arm]=dict(raw=identity(folder/'memory.json'),process=identity(folder/'result.json'),phase_marker_pairs=9,phase_windows=phases_mem,
                peaks_bytes=peaks,requested_interval_seconds=mem['requested_interval_s'],actual_gaps_ms=stats([(b['timestamp_ns']-a['timestamp_ns'])/1e6 for a,b in zip(running,running[1:])]),
                ready_baseline=read(folder/'memory-summary.json')['ready_baseline'],limits='Live parent-receipt timestamps, not exact device/allocator boundaries; zero-sample phases stay null. Bracket deltas can include adjacent work/cleanup, never exact allocation attribution.')

timing=[v for v in rows if v['mode']=='timing'];arms={}
for arm in ('current','before','peer'):
    rs=[v for v in timing if v['arm']==arm]
    arms[arm]=dict(metrics={k:stats([v['metrics'][k] for v in rs]) for k in rs[0]['metrics']},phase_seconds={k:stats([v['phase_seconds'][k] for v in rs]) for k in phase_contexts},
                   pooled_rates=dict(actual_prefill_tps=483/sum(v['metrics']['prefill_seconds'] for v in rs),decode_tps=291/sum(v['metrics']['decode_seconds'] for v in rs),output_tps=306/sum(v['metrics']['wall_seconds'] for v in rs)))
changes={other:{k:100*(arms['current']['metrics'][k]['median']/arms[other]['metrics'][k]['median']-1) for k in ('logical_prefill_tps','actual_prefill_tps','decode_tps','output_tps')} for other in ('before','peer')}
means={a:{k:statistics.mean(v['metrics'][k] for v in timing if v['arm']==a) for k in ('prefill_seconds','decode_seconds','wall_seconds','between_phase_seconds')} for a in arms}
report=dict(status='Independent pure-host calculation from9timing+3memory completed processes; all work and102IDs matched.',window=str(W.relative_to(R)),checker=identity(Path(__file__)),
            ready=identity(S/'qwen-ready-attempt2.json'),image=read(S/'qwen-ready-attempt2.json')['image'],architecture_review=identity(S/'review/architecture-review2.json'),
            work=expected,logical_P=548,actual_P=161,D=97,outputs_per_global_wall=102,arms=arms,memory=memory,current_vs_other_median_rate_change_percent=changes,
            mean_current_minus_other_seconds={a:{k:means['current'][k]-means[a][k] for k in means[a]} for a in ('before','peer')},samples=rows,
            limitations=[
                'Active1, four named resident Sessions with complete state and exact129 checkpoint, not concurrent GPU batch throughput or free generation.',
                'No resident eviction/restore/cancellation inside this timing window; separate actual correctness/probe evidence applies only to its tested boundaries.',
                'Peer backing113590272B/1024 unified KV rows vsHyle110469168B/1040 page rows; logical capacity256/N4 match, physical byte provisioning differs.',
                'Only3independent timing processes/arm and1memory process/arm, clocks/system activity uncontrolled; do not combine with older windows or infer universal gains.',
                'Per-session walls overlap; aggregate output rate is102/global wall, never102/sum(per-session walls). P logical rate includes387reused tokens; actual P uses161.',
                'Current child_prepare log no longer includes initialize_slot; old child_prepare did. Raw request/phase/whole walls include actual preparation, but child_prepare bucket scopes must not be treated as identical.',
                'In prefix mode the first actual T1 slot constructions are charged to decode when first selected; the old F carrier construction happened inside prompt admission. P/D bucket contents therefore changed, while complete request/global/startup walls retain the work. Do not label the whole decode-rate difference a kernel regression.',
                'Prefix-enabled scheduled mode materializes an execution carrier on its first actual request, inside that request wall. Final off/legacy mode explicitly prepares only its actual ordered shape/slot calls before ready; prefix suffix candidates remain lazy. Old performance/* data belongs to the superseded first draft and is not this final performance2 window.',
                'The final current image destroys the retired StepState before the original host-token endpoint and keeps only the serial admission guard through all report/trace/probe reads. Optional diagnostics remain outside the endpoint and are disabled in these timing processes.',
                'Live dynamic phase markers were independently checked, but received boundary timestamps and15ms-class samples do not create exact phase peaks or deltas. Missing values stay null; distinct dedicated/shared peaks never sum.',
                'No model/GPU/build/device query started by this checker. Original data files are not modified.'])
out=S/'review'/(args.tag+'-review.json');save(out,report)
print(json.dumps(dict(report=identity(out),medians={a:{k:v['median'] for k,v in row['metrics'].items() if k in ('actual_prefill_tps','decode_tps','output_tps','startup_total_seconds')} for a,row in arms.items()},changes=changes,mean_gaps=report['mean_current_minus_other_seconds']),ensure_ascii=False))
