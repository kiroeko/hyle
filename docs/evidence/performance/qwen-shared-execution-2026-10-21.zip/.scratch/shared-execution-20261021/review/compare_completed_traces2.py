"""Host-only reread of completed shared-execution evidence. Runs no consumer."""
from array import array
from pathlib import Path
import hashlib
import json
import sys

ROOT = Path(__file__).resolve().parents[3]
STAGE = ROOT / '.scratch/shared-execution-20261021'
BEFORE = ROOT / '.scratch/paged-host-prepare-20261021'
OUT = STAGE / 'review'


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def identity(path):
    path = Path(path)
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())


def verify(record):
    actual = identity(record['path'])
    assert actual == record, (actual, record)
    return actual


def stable(value):
    if isinstance(value, dict):
        return {key: stable(item) for key, item in value.items()
                if key != 'seconds' and not key.endswith('_seconds')}
    if isinstance(value, list):
        return [stable(item) for item in value]
    return value


def normalized_command(command):
    result = list(command)
    result[0] = 'EXE'
    if '--trace' in result:
        result[result.index('--trace') + 1] = 'TRACE'
    return result


assert sys.byteorder == 'little'
ready = read(STAGE / 'qwen-ready-attempt2.json')
old_ready = read(BEFORE / 'qwen-ready-attempt3.json')
verify(ready['image'])
verify(ready['source'])
verify(ready['link_plan'])
verify(old_ready['link_plan'])
verify(ready['runtime_environment'])
new_plan = read(ready['link_plan']['path'])
old_plan = read(old_ready['link_plan']['path'])
assert len(new_plan['inputs']) == len(old_plan['inputs']) == 195
changed = [dict(index=index, before=old, after=new)
           for index, (new, old) in enumerate(zip(new_plan['inputs'], old_plan['inputs']))
           if new != old]
assert len(changed) == 1
assert Path(changed[0]['after']['path']).name == 'main.obj'
for item in new_plan['inputs']:
    verify(item)
verify(changed[0]['before'])
assert ready['source'] == read(STAGE / 'compile2/main/identity.json')['source']

cases = {}
counts = dict(vectors=0, bf16_elements=0, f32_elements=0, nonfinite_elements=0)
for name, prior, expected in [('single-run2', 'single-run3', 18),
                              ('multi-run2', 'multi-run3', 72),
                              ('main-run2', 'main-run3', 22),
                              ('pressure-run2', 'pressure-run3', 30)]:
    current = STAGE / name
    baseline = BEFORE / prior
    result = read(current / 'result.json')
    old_result = read(baseline / 'result.json')
    assert result['exit'] == old_result['exit'] == 0
    assert result['image'] == ready['image']
    assert old_result['image'] == old_ready['image']
    assert normalized_command(result['command']) == normalized_command(old_result['command'])
    observation = read(current / 'stdout.log')
    old_observation = read(baseline / 'stdout.log')
    assert observation == read(current / 'observation.json')
    if (baseline / 'observation.json').is_file():
        assert old_observation == read(baseline / 'observation.json')
    assert stable(observation) == stable(old_observation)
    actual = {path.relative_to(current / 'trace').as_posix(): path
              for path in (current / 'trace').rglob('*')
              if path.name in ('hidden.bf16', 'logits.f32')}
    original = {path.relative_to(baseline / 'trace').as_posix(): path
                for path in (baseline / 'trace').rglob('*')
                if path.name in ('hidden.bf16', 'logits.f32')}
    assert actual.keys() == original.keys() and len(actual) == expected
    pairs = []
    for relative in sorted(actual):
        data, old_data = actual[relative].read_bytes(), original[relative].read_bytes()
        assert data == old_data
        is_bf16 = relative.endswith('.bf16')
        values = array('H' if is_bf16 else 'I')
        values.frombytes(data)
        mask = 0x7f80 if is_bf16 else 0x7f800000
        nonfinite = sum((value & mask) == mask for value in values)
        assert nonfinite == 0
        counts['bf16_elements' if is_bf16 else 'f32_elements'] += len(values)
        counts['nonfinite_elements'] += nonfinite
        counts['vectors'] += 1
        pairs.append(dict(relative=relative, current=identity(actual[relative]),
                          before=identity(original[relative]), byte_equal=True,
                          elements=len(values), nonfinite=nonfinite))
    hit_metadata = []
    for path in (current / 'trace').rglob('cache-hit.json'):
        reference = baseline / 'trace' / path.relative_to(current / 'trace')
        metadata = read(path)
        assert metadata == read(reference)
        assert metadata['graph_calls'] == 0 and metadata['tensor_payload_available'] is False
        assert not (path.parent / 'hidden.bf16').exists()
        assert not (path.parent / 'logits.f32').exists()
        hit_metadata.append(dict(current=identity(path), before=identity(reference), contents=metadata))
    statistics = {key: value for key, value in stable(observation).items()
                  if key != 'sessions'}
    sessions = observation.get('sessions', [observation])
    cases[name] = dict(
        previous=prior, current_result=identity(current / 'result.json'),
        before_result=identity(baseline / 'result.json'),
        current_stdout=identity(current / 'stdout.log'),
        before_stdout=identity(baseline / 'stdout.log'),
        current_stderr=identity(current / 'stderr.log'),
        before_stderr=identity(baseline / 'stderr.log'),
        same_command_except_image_and_trace=True,
        all_non_timing_observation_fields_equal=True,
        observation_fields_excluded=['seconds', '*_seconds'],
        decision_vectors=expected, pairs=pairs, full_hit_metadata=hit_metadata,
        statistics=statistics,
        sessions=[stable(item) for item in sessions])

assert counts['vectors'] == 142
assert sum(cases[name]['decision_vectors'] for name in ('main-run2', 'pressure-run2')) == 52
probe = read(STAGE / 'probe-run2/stdout.log')
assert probe == read(STAGE / 'probe-run2/observation.json')
probe_result = read(STAGE / 'probe-run2/result.json')
probe_ready = read(STAGE / 'probe-ready-attempt2.json')
assert probe_result['exit'] == 0 and probe_result['image'] == probe_ready['image']
verify(probe_ready['image'])
probe_identity = read(STAGE / 'compile2/probe/identity.json')
assert probe_identity['source'] == probe_ready['source']
assert probe_identity['source']['sha256'] == '1a2f463b7a28a50e3135b403ca3ed2d48bf3a4ae0aeb4a0fc5377237824b8b7e'
for key in ['post_commit_trace_error_preserved_head_and_returned_loan',
            'different_session_continued_after_report_error',
            'old_kv_guards_and_bytes_unchanged', 'idle_stop_preserved_other_execution_loan',
            'dropped_live_public_completion', 'retired_aborted_slot_rebuilt_in_same_model_bundle']:
    assert probe[key] is True
assert probe['busy_prepare_rejections'] == 3
assert probe['old_recurrent_resources_byte_unchanged'] == 36
assert probe['head_alias_sessions_added_distinct_versions'] == 0
assert probe['native_error_injected'] is False
assert probe['final_tokens'] == 131
assert any(item == ready['source'] for item in probe_identity['dependencies'])
stderr = (STAGE / 'probe-run2/stderr.log').read_text()
assert stderr.count('shared_execution_post_commit_trace_rejected reason=') == 1
assert 'weights.tsv' in stderr
assert 'retirement_after_report_error tokens=1 visible=131 ' in stderr
for stage in ['native_pending', 'stopped_native_pending', 'dropped_completion_native_pending']:
    assert stderr.count('shared_execution_prepare_rejected stage=' + stage + ' ') == 1

report = dict(
    attempt=2,
    status='PASS; independent host-only reread of completed processes and raw decision bytes',
    previous_round_review=identity(OUT / 'runtime-comparison.json'),
    script=identity(__file__), current_ready=identity(STAGE / 'qwen-ready-attempt2.json'),
    before_ready=identity(BEFORE / 'qwen-ready-attempt3.json'),
    current_image=ready['image'], before_image=old_ready['image'],
    current_source=ready['source'], before_source=old_ready['source'],
    closure=dict(input_count=195, unchanged_inputs=194, changed=changed,
                 all_current_input_payload_identities_verified=True,
                 no_new_provider_or_native_module_object=True),
    total_decision_vectors=142, prefix_and_pressure_vectors=52, canonical_vectors=90,
    all_byte_equal=True, finite_counts=counts, cases=cases,
    probe=dict(result=identity(STAGE / 'probe-run2/result.json'),
               stdout=identity(STAGE / 'probe-run2/stdout.log'),
               stderr=identity(STAGE / 'probe-run2/stderr.log'),
               ready=identity(STAGE / 'probe-ready-attempt2.json'),
               compiled_probe_source=probe_ready['source'], observation=probe,
               actual_native_gate_rejections_verified_in_raw_stderr=True),
    limits=[
        'No inference, GPU query, build, link or source change performed by this checker.',
        'The comparison is source-bound same-partition numerical regression, not independent model quality or all-layer state-bit proof.',
        'Every non-timing stdout field matches; preparation/capture log strategy is allowed to change and is not used as a mathematical oracle.',
        'Raw timings are diagnostic and are not a throughput result. This report makes no speed claim.',
        'Only hidden.bf16/logits.f32 are decision vectors; route TSV and full-hit metadata are excluded. Full hits have no fabricated tensor payload.',
        'Probe-run1 covers cancelled/aborted execution loan recovery; it injects no separate checked native error.',
        'Probe-run2 additionally checks real filesystem_error after head130 commit, loan return on unwinding, and a different Session continuing through the same carrier to131.'
    ])
destination = OUT / 'runtime-comparison2.json'
destination.write_text(json.dumps(report, indent=2, allow_nan=False) + '\n')
print(json.dumps(dict(report=identity(destination), counts=counts,
                      prefix_and_pressure_vectors=52,
                      cases={name: item['statistics'] for name, item in cases.items()
                             if name in ('main-run2', 'pressure-run2')}), indent=2))
