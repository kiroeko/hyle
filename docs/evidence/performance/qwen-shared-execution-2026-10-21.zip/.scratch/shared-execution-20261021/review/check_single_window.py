"""Independent read-only calculation from final 12 timing / 4 memory processes."""
from pathlib import Path
import hashlib, json, re, statistics

S=Path(__file__).resolve().parents[1]; R=S.parents[1]; W=S/'performance2/single'
def read(p): return json.loads(Path(p).read_text(encoding='utf-8'))
def identity(p):
    p=Path(p); b=p.read_bytes(); return dict(path=p.relative_to(R).as_posix(),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def stats(xs): return dict(count=len(xs),min=min(xs) if xs else None,median=statistics.median(xs) if xs else None,max=max(xs) if xs else None,samples=xs)
def save(p,v): p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
contexts={'round1_prefill':(256,0,256),'round1_decode':(32,256,288),'round2_prefill':(256,288,544),
          'round2_decode':(32,544,576),'round3_prefill':(256,576,832),'round3_decode':(32,832,864)}
rows=[]; memories={}; reference=None; ready=read(S/'qwen-ready-attempt2.json')
for mode,order in [('timing',['current','before','dense','peer','peer','dense','before','current','before','current','peer','dense']),('memory',['before','current','dense','peer'])]:
    inputs=read(W/mode/'inputs.json'); folders=sorted(v for v in (W/mode).iterdir() if v.is_dir()); assert [v.name.split('-',1)[1] for v in folders]==order
    last_end=0
    for folder in folders:
        arm=folder.name.split('-',1)[1]; proc=read(folder/'result.json')
        assert proc['exit']==0 and not proc['reader_errors'] and not proc['profiler'] and proc['memory_only']==(mode=='memory')
        assert proc['image']==inputs['images'][arm] and proc['started_unix_ns']>=last_end; last_end=proc['finished_unix_ns']
        if arm=='current': assert proc['image']['sha256']==ready['image']['sha256']
        text=(folder/'stderr.log').read_text(encoding='utf-8'); path=folder/('peer-result.json' if arm=='peer' else 'stdout.log')
        raw=read(path) if arm=='peer' else json.loads(path.read_text().splitlines()[-1])
        ids=raw['predicted_ids'] if arm=='peer' else raw['generated_ids']
        assert len(ids)==99
        if reference is None: reference=ids
        else: assert ids==reference
        assert raw['processed_tokens']==864 and raw['generated_tokens']==99 and raw['phase_count']==6 and raw['turn_count']==3
        if arm=='peer': assert raw['context_capacity']==1024 and raw['configured_batch_capacity']==256
        else:
            assert raw['visible_tokens']==864
            if arm!='dense':
                assert raw['actual_graph_calls']==99 and raw['actual_graph_tokens']==864
                assert raw['prefix_cache']=='off' and raw['reused_tokens']==0 and raw['restored_calls']==0
        phases={v['name']:v for v in raw['phases']}; assert set(phases)==set(contexts)
        for name,(tokens,before,after) in contexts.items():
            x=phases[name]; assert (x['input_tokens'],x['context_before'],x['context_after'])==(tokens,before,after)
        P=sum(v['seconds'] for v in phases.values() if v['kind']=='prefill'); D=sum(v['seconds'] for v in phases.values() if v['kind']=='decode'); wall=raw['session_seconds']
        native={}
        if arm=='peer':
            startup=dict(ready_seconds=raw['loading']['startup_to_ready_seconds'],model_load_seconds=raw['loading']['model_load_seconds'],context_seconds=raw['loading']['context_prepare_seconds'])
        else:
            steps=[]; prepared=None
            for line in text.splitlines():
                m=re.fullmatch(r'prepared T=(\d+) visible=(\d+) replay=(\S+) cold_batch_seconds=([\deE.+-]+) capture_recorded=(\d+) capture_reused=(\d+)',line)
                if m: prepared=dict(T=int(m[1]),visible=int(m[2]),route=m[3],cold=float(m[4]),recorded=int(m[5]),reused=int(m[6]))
                m=re.fullmatch(r'(round\d+_(?:prefill|decode\d+)) tokens=(\d+) visible=(\d+) seconds=([\deE.+-]+) submit_seconds=([\deE.+-]+) step_seconds=([\deE.+-]+) progress=(\S+) next=(\d+)',line)
                if m:
                    assert prepared is not None
                    steps.append(dict(name=m[1],tokens=int(m[2]),visible=int(m[3]),next=int(m[8]),prepared=prepared)); prepared=None
            assert len(steps)==99 and [v['next'] for v in steps]==ids and sum(v['tokens'] for v in steps)==864
            native=dict(recorded=sum(v['prepared']['recorded'] for v in steps),reused=sum(v['prepared']['reused'] for v in steps),
                        pure_reuse_decode_cold_by_turn={str(t):stats([v['prepared']['cold'] for v in steps if v['name'].startswith('round'+str(t)+'_decode') and not v['prepared']['recorded'] and v['prepared']['reused']]) for t in (1,2,3)})
            m=re.search(r'initialized model_seconds=([\deE.+-]+) shape_prepare_seconds=([\deE.+-]+) startup_to_ready_seconds=([\deE.+-]+)',text); assert m
            startup=dict(model_seconds=float(m[1]),shape_prepare_seconds=float(m[2]),ready_seconds=float(m[3]),weight_load_seconds=float(re.search(r'weights_load_seconds=([\deE.+-]+)',text)[1]))
        metrics=dict(prefill_tps=768/P,decode_tps=96/D,output_tps=99/wall,prefill_seconds=P,decode_seconds=D,wall_seconds=wall,
                     between_phase_seconds=wall-P-D,startup_total_seconds=raw['startup_total_seconds'],**startup)
        rows.append(dict(mode=mode,arm=arm,folder=folder.relative_to(R).as_posix(),result=identity(folder/'result.json'),raw=identity(path),image=proc['image'],metrics=metrics,
                         phase_seconds={k:v['seconds'] for k,v in phases.items()},native=native))
        if mode=='memory':
            mem=read(folder/'memory.json'); running=[v for v in mem['samples'] if v['process_running']]; keys=('working_set_bytes','private_commit_bytes','gpu_dedicated_bytes','gpu_shared_bytes','gpu_total_bytes')
            peaks={k:max((v[k] for v in running if v.get(k) is not None),default=None) for k in keys}; windows={}
            for name in contexts:
                begin=[v['timestamp_ns'] for v in proc['markers'] if v['name']==name+'_begin']; end=[v['timestamp_ns'] for v in proc['markers'] if v['name']==name+'_end']; assert len(begin)==len(end)==1 and begin[0]<=end[0]
                assert 'memory_phase='+name+'_begin' in text and 'memory_phase='+name+'_end' in text
                inside=[v for v in running if begin[0]<=v['timestamp_ns']<=end[0]]
                before=max((v for v in running if v['timestamp_ns']<=begin[0]),key=lambda v:v['timestamp_ns'],default=None)
                after=min((v for v in running if v['timestamp_ns']>=end[0]),key=lambda v:v['timestamp_ns'],default=None)
                reported=read(folder/'memory-summary.json')['phase_windows'][name]
                window=dict(sample_count=len(inside),peak_bytes={k:max((v[k] for v in inside if v.get(k) is not None),default=None) for k in keys},
                            bracket_delta_bytes={k:after[k]-before[k] if before and after and before.get(k) is not None and after.get(k) is not None else None for k in keys},
                            before_age_ms=(begin[0]-before['timestamp_ns'])/1e6 if before else None,after_age_ms=(after['timestamp_ns']-end[0])/1e6 if after else None,exact_boundary_values=False)
                assert reported['sample_count']==len(inside) and reported['begin_ns']==begin[0] and reported['end_ns']==end[0]
                assert all(window['peak_bytes'][k]==reported['values'][k]['max'] for k in keys); windows[name]=window
            memories[arm]=dict(raw=identity(folder/'memory.json'),result=identity(folder/'result.json'),phase_marker_pairs=6,phase_windows=windows,peaks_bytes=peaks,
                               actual_gaps_ms=stats([(b['timestamp_ns']-a['timestamp_ns'])/1e6 for a,b in zip(running,running[1:])]),requested_interval_seconds=mem['requested_interval_s'],
                               ready_baseline=read(folder/'memory-summary.json')['ready_baseline'])
timing=[v for v in rows if v['mode']=='timing']; arms={}
for arm in ('current','before','dense','peer'):
    rs=[v for v in timing if v['arm']==arm]
    arms[arm]=dict(metrics={k:stats([v['metrics'][k] for v in rs]) for k in rs[0]['metrics']},phase_seconds={k:stats([v['phase_seconds'][k] for v in rs]) for k in contexts},
                   pooled_rates=dict(prefill_tps=2304/sum(v['metrics']['prefill_seconds'] for v in rs),decode_tps=288/sum(v['metrics']['decode_seconds'] for v in rs),output_tps=297/sum(v['metrics']['wall_seconds'] for v in rs)))
changes={a:{k:100*(arms['current']['metrics'][k]['median']/arms[a]['metrics'][k]['median']-1) for k in ('prefill_tps','decode_tps','output_tps')} for a in ('before','dense','peer')}
means={a:{k:statistics.mean(v['metrics'][k] for v in timing if v['arm']==a) for k in ('prefill_seconds','decode_seconds','wall_seconds','between_phase_seconds')} for a in arms}
report=dict(status='PASS independent pure-host raw check:12timing+4memory processes exit0;99IDs,6phases,864inputs matched.',checker=identity(Path(__file__)),ready=identity(S/'qwen-ready-attempt2.json'),image=ready['image'],
            window=W.relative_to(R).as_posix(),work=dict(P=768,D=96,outputs=99,context_final=864,context_capacity=1024,phases=6),arms=arms,memory=memories,
            current_vs_other_median_rate_change_percent=changes,mean_current_minus_other_seconds={a:{k:means['current'][k]-means[a][k] for k in means[a]} for a in ('before','dense','peer')},samples=rows,
            limitations=['This final off-mode prepares actual ordered carriers before ready. Superseded first-draft negative performance/* results remain separate, not discarded or mixed.',
                         'Only3timing processes/arm and1memory process/arm, uncontrolled clocks/system activity. Tiny differences with overlapping ranges are not stable wins or regressions.',
                         'All arms consume fixed teacher-forced input IDs;99equal predictedIDs do not establish equality of every hidden tensor or free-generation quality.',
                         'Phase markers are live parent receipt times, not exact GPU/allocator boundaries.10msrequested sampling is15ms-class in this window; zero-sample windows remain null, adjacent bracket deltas can include neighboring work. GPU total is sampled simultaneously; independent dedicated/shared peaks are not summed.',
                         'Original actual capture/permission/retirement contracts remain in effect. Reviewer started no model/GPU/build/device query and modified no raw data.'])
out=S/'review/single-performance2-review.json'; save(out,report)
print(json.dumps(dict(report=identity(out),medians={a:{k:v['median'] for k,v in row['metrics'].items() if k in ('prefill_tps','decode_tps','output_tps','startup_total_seconds')} for a,row in arms.items()},changes=changes,mean_gaps=report['mean_current_minus_other_seconds'])))
