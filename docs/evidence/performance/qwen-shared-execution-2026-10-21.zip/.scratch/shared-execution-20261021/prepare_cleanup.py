"""Prepare exact stage-only cleanup plan + root test.ps1; never execute deletion."""
from pathlib import Path
import hashlib,json
S=Path(__file__).resolve().parent;R=S.parents[1]
STEM='qwen-shared-execution-2026-10-21'

def identity(p):
    p=Path(p).resolve();raw=p.read_bytes();return dict(path=str(p),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def save(p,v):p.write_text(json.dumps(v,indent=2,allow_nan=False)+'\n',encoding='utf-8')
def safe(p):
    p=Path(p);resolved=p.resolve(strict=True)
    assert resolved.is_relative_to(S) and not resolved.is_dir()
    for parent in [p,*p.parents]:
        assert not (getattr(parent.stat(),'st_file_attributes',0)&0x400), 'Reparse point: '+str(parent)
        if parent==S:break
    return resolved

def main():
    rows=[]
    for relative in ['qwen-link1/qwen.exe','probe-link1/probe.exe','probe-link2/probe.exe']:
        p=safe(S/relative);rows.append(dict(**identity(p),kind='superseded-image'))
    for folder in ('qwen-link1','qwen-link2','probe-link1','probe-link2'):
        for p in sorted((S/folder).iterdir()):
            if p.is_file() and p.suffix.lower() in ('.map','.lib','.exp'):
                rows.append(dict(**identity(safe(p)),kind='link-sidecar'))
    for name,count in [('single',18),('multi',72),('main',22),('pressure',30)]:
        old=S/f'{name}-run1/trace';new=S/f'{name}-run2/trace'
        files=sorted(p for p in old.rglob('*') if p.is_file() and p.name in ('hidden.bf16','logits.f32'))
        assert len(files)==count
        for p in files:
            destination=safe(new/p.relative_to(old));a,b=identity(safe(p)),identity(destination)
            assert (a['bytes'],a['sha256'])==(b['bytes'],b['sha256']), 'Not duplicate: '+str(p)
            rows.append(dict(**a,kind='superseded-run1-vector',kept_duplicate=b))
    assert len(rows)==len({x['path'].lower() for x in rows})
    current=identity(safe(S/'qwen-link2/qwen.exe'));assert current['path'].lower() not in {x['path'].lower() for x in rows}
    plan=dict(targets=rows,total_files=len(rows),total_bytes=sum(x['bytes'] for x in rows),
        receipt=str(R/'docs/evidence/performance'/(STEM+'.cleanup.json')),
        reason='Only superseded qwen1/probe1/probe2 images, four link directories map/import sidecars, and142 run1 decision files proven identical to retained run2 files.',
        kept=['Current qwen-link2 image; all .obj files and compile/link recipes; all142 run2 final decision payloads and all raw logs/metadata/reviews.',
              'All DLL hardlinks/cache originals, SDK/dependencies/models, every other stage; no directories or recursive delete.'],
        kept_current_image=current,recursive_delete=False,reparse_targets=False,
        publication_required=str(S/'published.json'))
    save(S/'cleanup-plan.json',plan)
    script=SCRIPT.replace('@REPO@',str(R)).replace('@STAGE@',str(S)).replace('@STEM@',STEM)
    root=R/'test.ps1';before=S/'cleanup-before-test.ps1'
    if root.exists() and not before.exists():before.write_bytes(root.read_bytes())
    (S/'cleanup-script.ps1').write_text(script,encoding='utf-8');root.write_text(script,encoding='utf-8')
    print(json.dumps(dict(plan=identity(S/'cleanup-plan.json'),script=identity(root),files=len(rows),bytes=plan['total_bytes'],executed=False)))

SCRIPT=r"""$ErrorActionPreference = 'Stop'
$repoRoot = '@REPO@'
$stageRoot = [IO.Path]::GetFullPath('@STAGE@')
$stagePrefix = $stageRoot + '\'
$planPath = Join-Path $stageRoot 'cleanup-plan.json'
$publishedPath = Join-Path $stageRoot 'published.json'
$plan = Get-Content -LiteralPath $planPath -Raw -Encoding utf8 | ConvertFrom-Json
$published = Get-Content -LiteralPath $publishedPath -Raw -Encoding utf8 | ConvertFrom-Json
function Assert-Identity($row) {
    $item = Get-Item -LiteralPath $row.path
    if ($item.PSIsContainer -or $item.Length -ne $row.bytes) { throw "Size/type mismatch: $($row.path)" }
    if ((Get-FileHash -LiteralPath $row.path -Algorithm SHA256).Hash.ToLowerInvariant() -ne $row.sha256) { throw "Hash mismatch: $($row.path)" }
}
Assert-Identity $published.cleanup_plan
Assert-Identity $published.cleanup_script
if ([IO.Path]::GetFullPath($published.cleanup_plan.path) -ne $planPath) { throw 'Unexpected plan.' }
if ((Get-FileHash -LiteralPath $PSCommandPath -Algorithm SHA256).Hash.ToLowerInvariant() -ne $published.cleanup_script.sha256) { throw 'Root test.ps1 differs from archived cleanup script.' }
foreach ($row in $published.files) { Assert-Identity $row }
$expectedReceipt = Join-Path $repoRoot 'docs\evidence\performance\@STEM@.cleanup.json'
$receiptPath = [IO.Path]::GetFullPath($plan.receipt)
if ($receiptPath -ne $expectedReceipt -or (Test-Path -LiteralPath $receiptPath)) { throw 'Unexpected/existing cleanup receipt.' }
$running = @(Get-CimInstance Win32_Process | Where-Object { $_.ExecutablePath -and $_.ExecutablePath.StartsWith($stagePrefix, [StringComparison]::OrdinalIgnoreCase) })
if ($running.Count -ne 0) { throw 'A process from this stage is still running.' }
$seen = [Collections.Generic.HashSet[string]]::new([StringComparer]::OrdinalIgnoreCase)
foreach ($row in $plan.targets) {
    $resolved = [IO.Path]::GetFullPath($row.path)
    if (-not $resolved.StartsWith($stagePrefix, [StringComparison]::OrdinalIgnoreCase) -or -not $seen.Add($resolved)) { throw "Outside/duplicate target: $resolved" }
    if ($resolved -eq (Join-Path $stageRoot 'qwen-link2\qwen.exe')) { throw 'Final image may not be removed.' }
    $at = Get-Item -LiteralPath $resolved
    while ($null -ne $at) {
        if (($at.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) { throw "Reparse target: $resolved" }
        if ($at.FullName -eq $stageRoot) { break }
        $at = if ($at.PSIsContainer) { $at.Parent } else { $at.Directory }
    }
    Assert-Identity $row
    if ($row.kind -eq 'superseded-run1-vector') { Assert-Identity $row.kept_duplicate }
}
Assert-Identity $plan.kept_current_image
$removed = @()
foreach ($row in $plan.targets) {
    Remove-Item -LiteralPath $row.path -Force
    if (Test-Path -LiteralPath $row.path) { throw "Target remains: $($row.path)" }
    $removed += $row
}
$result = [ordered]@{status='completed';time_utc=[DateTime]::UtcNow.ToString('o');deleted_files=$removed.Count;deleted_bytes=($removed | Measure-Object -Property bytes -Sum).Sum;targets=$removed;reason=$plan.reason;kept=$plan.kept;recursive_delete=$false;plan_sha256=(Get-FileHash -LiteralPath $planPath -Algorithm SHA256).Hash.ToLowerInvariant();script_sha256=(Get-FileHash -LiteralPath $PSCommandPath -Algorithm SHA256).Hash.ToLowerInvariant()}
$result | ConvertTo-Json -Depth 10 | Set-Content -LiteralPath $receiptPath -Encoding utf8
Write-Output "Removed $($result.deleted_files) exact files, $($result.deleted_bytes) bytes; receipt $receiptPath"
"""
if __name__=='__main__':main()
