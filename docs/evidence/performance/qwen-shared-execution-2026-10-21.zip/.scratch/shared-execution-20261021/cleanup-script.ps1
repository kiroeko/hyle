$ErrorActionPreference = 'Stop'
$repoRoot = 'C:\public\project-hyle\hyle'
$stageRoot = [IO.Path]::GetFullPath('C:\public\project-hyle\hyle\.scratch\shared-execution-20261021')
$stagePrefix = $stageRoot + '\'
$planPath = Join-Path $stageRoot 'cleanup-plan.json'
$publishedPath = Join-Path $stageRoot 'published.json'
$plan = Get-Content -LiteralPath $planPath -Raw -Encoding utf8 | ConvertFrom-Json
$published = Get-Content -LiteralPath $publishedPath -Raw -Encoding utf8 | ConvertFrom-Json
function Assert-Identity($row) {
    $item = Get-Item -LiteralPath $row.path
    if ($item.PSIsContainer -or $item.Length -ne $row.bytes) { throw "Size/type mismatch: $($row.path)" }
    if ((Get-FileHash -LiteralPath $row.path -Algorithm SHA256).Hash.ToLowerInvariant() -ne $row.sha256) { throw "Hash mismatch: $($row.path)" }
}
Assert-Identity $published.cleanup_plan
Assert-Identity $published.cleanup_script
if ([IO.Path]::GetFullPath($published.cleanup_plan.path) -ne $planPath) { throw 'Unexpected plan.' }
if ((Get-FileHash -LiteralPath $PSCommandPath -Algorithm SHA256).Hash.ToLowerInvariant() -ne $published.cleanup_script.sha256) { throw 'Root test.ps1 differs from archived cleanup script.' }
foreach ($row in $published.files) { Assert-Identity $row }
$expectedReceipt = Join-Path $repoRoot 'docs\evidence\performance\qwen-shared-execution-2026-10-21.cleanup.json'
$receiptPath = [IO.Path]::GetFullPath($plan.receipt)
if ($receiptPath -ne $expectedReceipt -or (Test-Path -LiteralPath $receiptPath)) { throw 'Unexpected/existing cleanup receipt.' }
$running = @(Get-CimInstance Win32_Process | Where-Object { $_.ExecutablePath -and $_.ExecutablePath.StartsWith($stagePrefix, [StringComparison]::OrdinalIgnoreCase) })
if ($running.Count -ne 0) { throw 'A process from this stage is still running.' }
$seen = [Collections.Generic.HashSet[string]]::new([StringComparer]::OrdinalIgnoreCase)
foreach ($row in $plan.targets) {
    $resolved = [IO.Path]::GetFullPath($row.path)
    if (-not $resolved.StartsWith($stagePrefix, [StringComparison]::OrdinalIgnoreCase) -or -not $seen.Add($resolved)) { throw "Outside/duplicate target: $resolved" }
    if ($resolved -eq (Join-Path $stageRoot 'qwen-link2\qwen.exe')) { throw 'Final image may not be removed.' }
    $at = Get-Item -LiteralPath $resolved
    while ($null -ne $at) {
        if (($at.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) { throw "Reparse target: $resolved" }
        if ($at.FullName -eq $stageRoot) { break }
        $at = if ($at.PSIsContainer) { $at.Parent } else { $at.Directory }
    }
    Assert-Identity $row
    if ($row.kind -eq 'superseded-run1-vector') { Assert-Identity $row.kept_duplicate }
}
Assert-Identity $plan.kept_current_image
$removed = @()
foreach ($row in $plan.targets) {
    Remove-Item -LiteralPath $row.path -Force
    if (Test-Path -LiteralPath $row.path) { throw "Target remains: $($row.path)" }
    $removed += $row
}
$result = [ordered]@{status='completed';time_utc=[DateTime]::UtcNow.ToString('o');deleted_files=$removed.Count;deleted_bytes=($removed | Measure-Object -Property bytes -Sum).Sum;targets=$removed;reason=$plan.reason;kept=$plan.kept;recursive_delete=$false;plan_sha256=(Get-FileHash -LiteralPath $planPath -Algorithm SHA256).Hash.ToLowerInvariant();script_sha256=(Get-FileHash -LiteralPath $PSCommandPath -Algorithm SHA256).Hash.ToLowerInvariant()}
$result | ConvertTo-Json -Depth 10 | Set-Content -LiteralPath $receiptPath -Encoding utf8
Write-Output "Removed $($result.deleted_files) exact files, $($result.deleted_bytes) bytes; receipt $receiptPath"
