"""Focused host-only checks; no consumer/MemoryProbe/driver initialization."""
from pathlib import Path
import hashlib,json
from observer import marker,memory_summary,KEYS
S=Path(__file__).resolve().parent;R=S.parents[1];M=R/'.scratch/multi-session-performance-20261021'
def identity(p):
    data=p.read_bytes();return dict(path=str(p),bytes=len(data),sha256=hashlib.sha256(data).hexdigest())
old=[]
for folder in [M/'performance/memory/02-current',M/'performance/memory/03-peer']:
    lines=(folder/'stderr.log').read_text(encoding='utf-8-sig').splitlines()
    names=[marker(line) for line in lines if line.startswith('memory_phase=')]
    assert len(names)==18 and all(names) and len(set(n.rsplit('_',1)[0] for n in names))==9
    previous=json.loads((folder/'result.json').read_text(encoding='utf-8-sig'))
    assert not any(n['name'].endswith(('_begin','_end')) for n in previous['markers'])
    old.append(dict(raw_stderr=identity(folder/'stderr.log'),old_receipt=identity(folder/'result.json'),
        parsed_boundaries=18,parsed_phase_names=list(dict.fromkeys(n.rsplit('_',1)[0] for n in names)),
        timestamped_old_phase_reconstruction=False))
assert marker('memory_phase=round3_decode_end')=='round3_decode_end'
assert marker('memory_phase=user_2-x_round10_prefill_begin')=='user_2-x_round10_prefill_begin'
assert marker('measure_memory name=ready_before_first elapsed_seconds=1.0')=='ready_before_first'
assert marker('unrelated memory_phase=not_an_allowed_phase') is None
samples=[]
for t,d in [(15,100),(25,None),(35,110),(45,120),(60,130),(95,140),(105,140)]:
    v=dict(timestamp_ns=t,process_running=True,sample_duration_ns=1,working_set_bytes=20,private_commit_bytes=30,
        gpu_dedicated_bytes=d,gpu_shared_bytes=10,gpu_total_bytes=None if d is None else d+10)
    samples.append(v)
raw=dict(samples=samples,peaks={},gpu_setup_error=None,thread_error=None)
records=[('ready_before_first',10),('seed_round1_prefill_begin',20),('seed_round1_prefill_end',40),
    ('seed_round1_decode_begin',50),('seed_round1_decode_end',90),('full_hit_round1_prefill_begin',100),('full_hit_round1_prefill_end',100),
    ('missing_round1_decode_begin',110),('duplicate_round2_prefill_begin',120),('duplicate_round2_prefill_begin',121),('duplicate_round2_prefill_end',130)]
result=memory_summary(raw,dict(markers=[dict(name=n,timestamp_ns=t) for n,t in records]))
p=result['phase_windows']['seed_round1_prefill'];assert p['sample_count']==2 and p['bracket_delta_bytes']['gpu_dedicated_bytes']==20
assert p['null_sample_counts']['gpu_dedicated_bytes']==1 and p['values']['gpu_dedicated_bytes']['count']==1
assert result['ready_baseline']['sample']['timestamp_ns']==15
f=result['phase_windows']['full_hit_round1_prefill'];assert f['sample_count']==0 and f['values']['gpu_dedicated_bytes']['max'] is None
for name in ['missing_round1_decode','duplicate_round2_prefill']:
    p=result['phase_windows'][name];assert p['sample_count']==0 and all(v is None for v in p['bracket_delta_bytes'].values())
assert result['phase_windows']['duplicate_round2_prefill']['ambiguous_boundary']
report=dict(status='PASS',checks=['Actual oldM Hyle/peer18markers→9phase names', 'Single/session-prefixed marker compatibility',
    'Dynamic phase discovery including zero-interior-sample fullhit','Ready-before-first alias', 'Null sample preservation',
    'Neighbor bracket deltas','Missing/duplicate boundary rejection'],historical_parser_checks=old,
    historical_scope='Only old log strings were reparsed. The old result lost phase receive times; no old memory phase statistics are reconstructed or rewritten.',
    observer=identity(S/'observer.py'),builds=0,GPU_runs=0,MemoryProbe_initializations=0)
target=S/'observer-checks.json';target.write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(status='PASS',report=identity(target),checks=len(report['checks']))))
