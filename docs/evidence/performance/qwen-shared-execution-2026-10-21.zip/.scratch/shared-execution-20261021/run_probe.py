"""Root-only original real retirement probe with retained command provenance."""
from pathlib import Path
S=Path(__file__).resolve().parent;R=S.parents[1]
source=(R/'.scratch/paged-retirement-20261021/run_probe.py').read_text(encoding='utf-8')
old="read(S / 'probe/report.json')";assert source.count(old)==1
source=source.replace(old,"read(R / '.scratch/paged-retirement-20261021/probe/report.json')")
# Explicit UTF8 applies to the completed stdout read as well as new JSON writes.
source=source.replace("(out / 'stdout.log').read_text()","(out / 'stdout.log').read_text(encoding='utf-8-sig')")
exec(compile(source,str(Path(__file__).resolve()),'exec'),globals())
