# Qwen3.5-2B 推理架构实验消费者

这是检验 Compute/Graph 架构的独立测试产物，不是已交付的推理引擎。使用本地官方权重运行完整24层CUDA纯文本计算，关闭MTP和视觉。
消费者只调用公共接口，模型格式、tokenizer和生成策略仍由消费者负责。

`prepare.py` 校验原输入清单的13个文件，输出权重偏移和token IDs；Python只做输入准备与独立参考。
`main.cc` 用一份模型语义图表达prefill、带状态的多token continuation和decode，在启动时预列本次调用序列，
以有限shape图族一次冷编译。Model共享权重、图族、不可变child及按实际执行并发使用的Phase／IO／workspace；每个驻留Session保存完整KV／conv／GDN与位置，不各自复制执行载体。每个实际准备的child最多两个Invocation槽，共用IO所以整体独占借用；空闲会话不占槽。
无前缀模式沿已知有序调用计划显式提前准备实际用到的shape／slot；前缀模式首次选中实际suffix后才在请求内准备，未命中的候选不建。只实例化已有编译child，不临时建图、搜索Provider、编译或padding；首次准备仍计入对应冷准备或请求及含启动总时间。
conv/GDN状态真实反馈，KV使用有界共享页池，只写新增行及COW尾页。不可变Snapshot同时保留12份KV帧、36份conv/GDN读租约与位置；收齐成功结果、取回append事务并撤回已退休状态绑定后，一次替换会话head。失败保留旧head并按真实退休回收候选，不发布部分状态。

六个BF16 GQA attention共用一份BatchSchema，每次执行共享同一owned layout与metadata输入。
schema容量为最大预列chunk，具体Q/output行数等于当前chunk，KV可见长度由layout和positions表达。
例如23-token prefill→4-token continuation→单token decode使用同图族的23/4/1三个child；head深度等模型常数保持固定。
每槽冷准备IO与状态端口；每步更新token、position与layout，绑定精确页写事务和状态租约，沿原Invocation执行`graph::batch::prepare`→`prepare_replay`→submit→Completion，再取回结果与状态。
两个槽不授权并发覆盖tokens、KV或状态；当前共享一个Queue，控制须外部串行化。借用在写输入前取得，实际退休、状态提交及最后report／trace读取后才归还；失败只在真实退休后销毁本次Invocation，下次显式prepare重建。`evaluate`组合原有prepare／submit／finish；拆开调用可在真实工作在途时停止会话。`stop`只撤回本会话提交／发布资格并关闭自己的pending槽，不关闭Model共享池；`try_retire`只在原Completion及页权限退休门通过后清理本会话状态。目录retiring项不可查询或重新接纳，实际收集前继续计费。取消不表示GPU抢占，丢弃Completion也不表示页已可写。显式shutdown仍drain，所有Session须先于Model销毁；没有新增多候选并发调度。

构建消费者的已安装SDK须包含CUDA `compute;graph;graph_progress;compute_stream;mem` 产品。
CMake只查包和链接，不构建原生依赖。`--inputs DIR` 指向准备后的输入；可用选项：

- `--continuation IDS`：prefill后追加多token输入；`--steps N`指定生成阶段数。
- `--schedule FILE`：执行固定输入的多轮prompt／decode；与`--continuation`、`--decode-ids`及显式`--steps`互斥。所有ID和完整会话容量在创建Model前校验。
- `--session-schedules FILE`：执行多会话manifest，与`--schedule`及上述生成参数互斥。每行`SESSION_ID SCHEDULE_FILE`，路径相对manifest，支持双引号和整行`#`注释；ID为ASCII字母／数字开头，后续可含`_`／`-`且不能重复。`--capacity`是每会话上下文上限，所有会话和ID均先校验再加载模型。
- `--max-sessions auto|N`：保留的设备缓存会话上限；默认auto取本次输入会话数。manifest可以包含更多会话，空闲缓存按LRU淘汰，正在处理的请求不能淘汰。此值不提前分配对应份数，也不改选数学kernel。
- `--active-sequences auto|N`：同时保留为活跃请求的序列上限，不等于同时执行的GPU kernel数。默认auto取输入会话数、缓存数量与状态字节额度能容纳数量的最小值；显式超数量／字节容量会报错。
- `--cache-bytes auto|N`：共享KV页池、conv／GDN状态池的请求字节额度；默认auto按本次缓存数量及一个串行候选版本解析。显式额度不足时先缩小可驻留会话数或在加载前报错。实际共享backing只计一次，淘汰会话归还页／版本，不销毁Model的池。权重、IO／workspace、Provider私有存储和驱动额外占用另计，这不是全进程或物理显存上限。
- `--prefix-cache off|auto`：多会话manifest默认auto，单会话schedule及普通生成默认off；显式auto须使用schedule。仅在prompt请求边界查找同Model／数学图族的最长精确token前缀，借用已完成的完整Snapshot，只执行剩余输入。完整命中直接返回该快照保存的next ID，执行0次Graph；decode直达Session，不查询目录。目录最多N项，旧检查点与会话head共同受N份完整版本额度约束，额外一份只供串行候选，不能无界保留历史。
- `--progress direct|scheduler`：默认direct；scheduler在原槽上准备进度驱动，复用同一提交机制。
- `--replay auto|commands|prefer-capture`：默认auto，在Model范围按各会话的有序调用计划冷聚合每个child／槽的使用上界，只用一次走commands，预计复用才prefer-capture；前缀命中会跳调用或重置会话parity，因此对各可能slot及真实检查点suffix保守计数。也可显式固定其中一种模式。生成可能提前结束，不保证每份capture都会复用；换会话仍由实际资源／布局身份决定是否重录。`planned_replay`记录冷选择，逐步日志记录实际录制与复用；不做虚假预热或把首次执行移出计时。
- `--decode-ids FILE`：固定单token输入带，允许跨过预测EOS；若同时给steps，须等于输入数加一。正常生成遇到endoftext或im_end停止。
- `--trace DIR --trace-level decisions`：仅导出logits与最后hidden；默认full还导出conv/GDN状态与`kv-layout.json`。分页帧不公开原始bank载荷，后者记录实际页布局，不再导出dense KV文件。路由写入DIR/routes，不增加图输出。
- `--layer0-probe DIR`：诊断时另行发布layer0边界并比较实际路由；诊断图会影响合法融合，因此与普通图分别冷准备，均计入启动时间。多会话的边界输出按`session<序号>_<ID>`子目录隔离，不覆盖其他会话；共享图的路由说明仍在DIR。
- `--preparation-diagnostics 1`：仅schedule模式；分开记录layout、batch和replay准备时间，注明实际槽及其首用，并读取六份公开BatchPlanReport。记录冷预分配，报告在原host输出端点后读取、最终端点后打印；标记为diagnostic，不用于吞吐对比。默认关闭，不增加这些报告查询。

多轮manifest每行是`prompt IDSFILE`或`decode IDSFILE`，须从prompt开始并交替；Qwen消费者允许最后一轮仅有prompt，表示只取首token。共享parser的默认完整prompt／decode合同不变。
ID文件路径相对manifest所在目录；含空格的路径用双引号，ID文件使用空白分隔的整数。例如：

```text
prompt prompt1.ids
decode decode1.ids
prompt prompt2.ids
decode decode2.ids
```

```text
hyle_qwen35_text --inputs DIR --schedule session/manifest.txt --capacity 1024
```

每个prompt块执行一次，每个decode ID执行一次单token调用，固定输入允许跨过预测EOS。
后续prompt沿同一个Session及原KV、conv/GDN状态追加，不重新加载或重置缓存。
图族按所有会话的shape并集冷编译，Model按有序调用冷统计两个物理槽的使用上界。会话parity按自己的实际Graph调用前进，完整命中不翻转，采用前缀新会话从0开始；轮次切换不重置parity，也不执行预热。准备诊断的prior-use计数属于共享物理槽，跨会话不清零，失败后重建该槽才清零。
日志标签为`round1_prefill`、`round1_decode1`等；每个阶段另有
`memory_phase=roundX_prefill_begin/end`或`roundX_decode_begin/end`标记，供独立显存旁采定位，不代表消费者已测得显存数值。

仅schedule模式的stdout追加`phase_count`、`turn_count`、`processed_tokens`、`generated_tokens`和`phases`摘要。
`processed_tokens`是逻辑输入总数；`generated_tokens`是每个prompt末尾返回的一枚首token，加上每次decode返回的一枚token，包括完整缓存命中的返回。`actual_graph_calls`／`actual_graph_tokens`单列真实Graph工作，包含淘汰后的恢复；`reused_tokens`只计覆盖的新增逻辑prompt输入，恢复原边界的等长命中为0。`prefix_hits`／`prefix_misses`／`prefix_full_hits`和目录淘汰数另列。
每phase记录上下文范围、完整阶段`seconds`及原逐调用`step_sum_seconds`。
逐调用记录和标签在冷端预分配，执行时只填原计时、capture和token字段；最后一个host端点之后，才按原两行格式顺序打印日志。
`session_seconds`从首阶段输入准备前至最后token在host可见，保留实时阶段标记和控制间隙；
`startup_total_seconds`还包括输入解析、权重加载和冷图准备。最后调用端点之后的日志不计入这两个时间。
首用layout准备、capture和实例化均留在原完整调用计时内，不能只报重放段或平均各阶段TPS；
综合有效输出率使用`generated_tokens / session_seconds`；另列`processed_tokens / session_seconds`为总输入处理率，decode率按其实际调用数除以对应完整时间另报。
trace或layer0 probe会标记`diagnostic=true`，其中间导出可能拖长会话时间，不作为速度窗口。
未给schedule时保留原CLI结果和日志格式。

多会话manifest例如：

```text
alice alice/manifest.txt
bob bob/manifest.txt
```

```text
hyle_qwen35_text --inputs DIR --session-schedules sessions.txt --capacity 1024
```

一个prompt／decode完整turn是一份活跃请求；按活跃上限分组，组内逐完整调用轮转，turn完成后会话变空闲。
stdout的`execution`为`turn_round_robin_serial`；不是GPU并发或连续batch服务。
`sessions`各自记录状态和阶段，`dispatch_session_ids`记录实际顺序。`trace`按`session0_alice`等子目录隔离；路由仍共享写入`DIR/routes`。
各会话／phase的wall包含轮转期间其他会话的工作，`step_sum_seconds`才是本会话调用累计；总输出率应使用全部输出数除以`interleaved_seconds`，不能相加各会话TPS。
off模式首组状态与实际槽的显式准备计入`shape_prepare_seconds`，后续接纳／恢复计入对应请求的phase／session wall，并另列`cache_prepare_seconds`；已有Model载体不重复创建，模型加载桶不包含状态分配。auto模式在请求边界查前缀，再准备实际所需的槽，其lookup／接纳／首次准备／恢复均包含在该请求的`step_sum_seconds`与wall；`cache_prepare_seconds`此时只计目录准入，不能当成全部准备。跨模式比较须保冷准备边界一致，或使用含全部启动工作的端到端时间。
消费者保留输入历史；缓存被淘汰后，按原chunk顺序重建完整状态，不用参考状态或改为另一种prefill。`restored_calls`／`restored_tokens`单列重建工作，不混入逻辑新输出数；off的`step_sum_seconds`保持只累计新调用，auto计完整请求工作。
启用前缀时，重建记录保留实际计算过的token范围、分块和next ID，也包括借来快照的原计算记录；不会把`128＋1＋suffix`擅自改成一次大prefill。分块记录用于准确重建，不成为通用前缀key。不同合法分块得到的完整状态均可复用，逐字节回归须使用该状态实际来源的分块参考。
前缀匹配和接纳／恢复／suffix槽准备计入请求wall。完整命中的trace仅写`cache-hit.json`并标记`tensor_payload_available=false`，不导出未经执行的hidden／logits；诊断应使用新目录，不把旧文件当成本次输出。所需suffix形状从本次有限输入中的真实checkpoint匹配推导，在加载后的冷图族中一次准备。图族的算子候选和制品准备预算按请求变体数有界计算，日志列实际额度和使用数；不需要用户填写内部搜索上限。
`cache_hits`／`cache_misses`、`evicted_session_ids`和live／peak请求字节描述实际缓存行为。目录仅在请求边界使用，decode直达已pin的Session。
共享Model与2／4会话隔离的[原回归](../../docs/evidence/correctness/qwen-multi-session-isolation-2026-10-21.json)和dense状态容量限制的[三组检查](../../docs/evidence/correctness/qwen-session-capacity-2026-10-21.json)已通过。完整分页快照后的[单会话与四会话淘汰重建](../../docs/evidence/correctness/qwen-paged-snapshot-2026-10-21.json)保留18／72份决策向量对照。[实际前缀／分支与有界淘汰恢复](../../docs/evidence/correctness/qwen-prefix-reuse-2026-10-21.json)另核完整命中0Graph、T1／T16两条分支和之后的原会话续写。[CUDA在途回收](../../docs/evidence/correctness/qwen-native-retirement-2026-10-21.json)使用真实队列阻塞，核取消／丢弃Completion不提前返还资源，实际退休后才能重新接纳。独占尾页与Radix的本批结果见下；其它原生后端的完整消费者及并发吞吐仍待补。

当前前缀目录使用有界压缩Radix树，按实际token与模型／数学身份查询完整快照，结构分叉不自动生成检查点。
lookup只发生在请求边界；完整命中仍为0Graph，普通decode不逐token查树。目录及LRU在初始化时预留容量，活跃命中可同时只读持有。
Session独占自己的尾权，同页续写只写未提交后缀；前缀命中不会复制尾权，分支沿原COW路径，旧快照范围始终不变。
[本批实现、回归与性能](../../docs/evidence/performance/qwen-exclusive-radix-2026-10-21.json)不代表其它原生后端或GPU并发吞吐已交付。

退休检查独立于默认构建，可显式构建`hyle_qwen35_retirement_probe`，运行时传`--inputs DIR --decode-ids IDSFILE`；使用原P128输入及至少两个decode ID，不复制权重。它检验原执行链的寿命，不用于测速。
探针当前覆盖同页独占后缀取消：实际退休前保留资源，退休后旧快照仍持页，所有旧读者释放后才可重新取得整页。

当前页大小16。设容量为C、实际可保留会话／完整快照数为N，12份KV arena各容纳`N*ceil(C/16)+1`页，每页16×1024字节；36份conv/GDN池各有N＋1个块，单版本有效载荷合计19,537,920字节。各backing另有自己的1字节尾部，实际预留总额为`12*((N*ceil(C/16)+1)*16*1024+1)+19,537,920*(N+1)+36`。C256、N1／N2分别为42,418,224／65,101,872字节。额外候选只服务同一队列的串行执行，不能据此接纳并行写入。显式保留的旧Snapshot仍占版本及页容量；同一Snapshot的别名引用不重复计版本。

加载沿现有FileResourcePipeline，用两个8MiB pinned暂存读取原权重范围并上传，保留320个device分配和持久目标租约。
完整Model／ready／首token计时包含文件关闭、管线退休和临时运行时销毁。新进程未清OS页缓存，不能称冷盘加载。
`step_seconds`包含输入上传、layout准备、绑定、replay准备、提交、等待及token读回；首次shape编译在启动时完成，trace导出不在step内。
`seconds`和`submit_seconds`是更窄子段，不可直接与另一引擎的完整decode相比；完整启动至首token看`first_token_elapsed_seconds`。

本次有限图族已完成原128+31旅程的64份hidden/logits逐byte对照，以及23/4/1 scheduler＋capture旅程的6份对照。
两组独立性能窗口确认准备开销减少；decode小差异反向，未证明稳定提速。详见[有限图族实测](../../docs/evidence/performance/qwen-finite-family-2026-10-20.json)，
最新同窗指标见[当前工作](../../docs/developer/current-work.md)。报告中的compiled storage保留unknown计数，不等于完整显存峰值。
默认auto及其一次性chunk／重复槽选择见[最新实测与完整证据](../../docs/evidence/performance/qwen-auto-replay-policy-2026-10-21.json)；该策略修复了首次缓存续算损项，完整短decode的首次准备成本仍在排查。
另有独立的[进程内存／显存采样](../../docs/evidence/performance/qwen-memory-current-2026-10-20.json)：GPU峰值为采样下界，
驻留集、private commit和GPU共享内存分别记录；mmap与文件缓存会影响归属，不能将进程差直接当作全机RAM节省。

`reference.py`是独立Torch参考，候选不会读取参考状态或结果。固定输入与向量相同属于回归检查，独立质量验收仍未完成；
BF16舍入、归约和RoPE诊断见[底座审查证据](../../docs/evidence/correctness/inference-foundation-review-2026-10-18/README.md)。
原输入位于仓库`.scratch/inference-execution-refactor-2026-10-18/qwen35-text/`，不复制权重或SDK。
