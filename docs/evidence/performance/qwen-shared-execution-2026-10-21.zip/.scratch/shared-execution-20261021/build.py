"""Root-only consumer compile/link entry; retain the exact F195-input closure."""
from pathlib import Path
import argparse, importlib.util, os, sys
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent; R=S.parents[1]; F=R/'.scratch/paged-host-prepare-20261021'
spec=importlib.util.spec_from_file_location('retained_consumer_build',R/'.scratch/paged-exclusive-20261021/build.py')
h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
b,c=h.b,h.c

def base(mode):
    ready_path=F/f'{mode}-ready-attempt3.json';ready=c.read(ready_path)
    plan=c.read(ready['link_plan']['path'])
    source=R/('tools/qwen35_text/main.cc' if mode=='qwen' else 'tools/qwen35_text/retirement_probe.cc')
    records=[(row,c.read(row['path'])) for row in plan['compiled_records']]
    matched=[(row,value) for row,value in records if c.key(value['source']['path'])==c.key(source)]
    assert len(matched)==1 and len(plan['inputs'])==195
    recipe,record=matched[0]
    assert h.same(recipe) and sum(x==record['object'] for x in plan['inputs'])==1
    return ready_path,ready,plan,source,recipe,record

def compile_owner(mode,attempt):
    _,_,_,source,recipe,_=base(mode);tag='main' if mode=='qwen' else 'probe'
    h.S=S;h.RECIPES[tag]=(source.relative_to(R).as_posix(),Path(recipe['path']))
    return h.compile_owner(tag,attempt)

def link(mode,attempt,owner_attempt):
    prior_path,prior,original,source,_,old=base(mode);tag='main' if mode=='qwen' else 'probe'
    rp=S/f'compile{owner_attempt}'/tag/'identity.json';record=c.read(rp)
    assert c.key(record['source']['path'])==c.key(source)
    assert all(h.same(x) for x in [record['source'],record['object'],*record['dependencies']])
    assert all(h.same(x) for x in original['inputs'])
    key=c.key(old['object']['path']);replacement=record['object']
    inputs=[replacement if c.key(x['path'])==key else x for x in original['inputs']]
    assert sum(a==z for a,z in zip(inputs,original['inputs']))==194
    out=S/f'{mode}-link{attempt}';out.mkdir(exist_ok=False);(out/'tmp').mkdir();image=out/(mode+'.exe')
    command=[replacement['path'] if c.key(x)==key else x for x in original['command'] if not x.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:'))]
    command+=['/OUT:'+str(image),'/MAP:'+str(image.with_suffix('.map')),'/IMPLIB:'+str(image.with_suffix('.lib'))]
    c.save(out/'link-plan.json',dict(command=command,inputs=inputs,base=b.identity(prior['link_plan']['path']),
        replaced_inputs=[dict(before=old['object'],after=replacement)],added_inputs=[],compiled_records=[b.identity(rp)],
        unchanged_inputs=194,CXX=0,links=1,NVCC=0,SDK_builds=0))
    env,_=b.environment(command,[x['path'] for x in inputs],out);c.execute('link',command,env,out)
    staged=[]
    for dll in Path(prior['image']['path']).parent.glob('*.dll'):
        target=out/dll.name;os.link(dll,target);staged.append(dict(source=b.identity(dll),destination=b.identity(target),hardlink=True))
    runtime=c.read(prior['runtime_environment']['path']);runtime['PATH']=env['PATH'];runtime['staged_dlls']=[x['destination'] for x in staged]
    runtime['consumer_runtime_reuse']=dict(base_ready=b.identity(prior_path),hardlinks=staged)
    c.save(out/'runtime-environment.json',runtime)
    c.save(S/f'{mode}-ready-attempt{attempt}.json',dict(image=b.identity(image),source=record['source'],fresh_sources=[record['source']],
        link_plan=b.identity(out/'link-plan.json'),runtime_environment=b.identity(out/'runtime-environment.json'),
        input_count=195,unchanged_inputs=194,CXX=0,links=1,NVCC=0,SDK_builds=0,GPU_runs=0))
    print('READY',mode,flush=True)

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('mode',choices=('qwen','probe'));p.add_argument('--attempt',type=int,default=1)
    p.add_argument('--owner-attempt',type=int,default=1);p.add_argument('--link',action='store_true');a=p.parse_args()
    if a.link:link(a.mode,a.attempt,a.owner_attempt)
    else:compile_owner(a.mode,a.attempt)
