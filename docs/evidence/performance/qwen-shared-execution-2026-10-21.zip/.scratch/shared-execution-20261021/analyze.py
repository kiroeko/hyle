"""Host-only raw timing/memory recomputation for a completed new-stage window."""
from pathlib import Path
import argparse,hashlib,json,math,re,sys
sys.dont_write_bytecode=True
from observer import KEYS,memory_summary,stats
S=Path(__file__).resolve().parent
p=argparse.ArgumentParser();p.add_argument('workload',choices=('single','multi'));p.add_argument('--folder',type=Path)
a=p.parse_args();P=(a.folder or S/'performance'/a.workload).resolve()
assert P.is_relative_to(S)
read=lambda p:json.loads(Path(p).read_text(encoding='utf-8-sig'))
def identity(p):
    p=Path(p);data=p.read_bytes();return dict(path=str(p),bytes=len(data),sha256=hashlib.sha256(data).hexdigest())
def save(p,v):p.write_text(json.dumps(v,indent=2,allow_nan=False)+'\n',encoding='utf-8')
def raw(folder,arm):
    return read(folder/'peer-result.json') if arm=='peer' else json.loads((folder/'stdout.log').read_text(encoding='utf-8-sig').splitlines()[-1])
def command_key(command):
    command=command.copy()
    if '--result' in command:command[command.index('--result')+1]='RESULT'
    return command
inputs=read(P/'timing/inputs.json');images=inputs['images'];rows=[];mem={};reference=None;phase_reference=None;commands={}
expect=dict(processed_tokens=864,generated_tokens=99) if a.workload=='single' else dict(processed_tokens=645,generated_tokens=102,
    actual_graph_calls=101,actual_graph_tokens=258,prefix_hits=3,prefix_misses=2,prefix_full_hits=1,reused_tokens=387)
for mode in ('timing','memory'):
    previous_end=0
    for entry in read(P/mode/'runs.json'):
        folder=Path(entry['folder']);proc=read(folder/'result.json');arm=entry['variant'];d=raw(folder,arm)
        assert proc==entry['process'] and proc['exit']==0 and not proc.get('timeout') and not proc.get('reader_errors')
        assert proc['memory_only']==(mode=='memory') and not proc['profiler'] and proc['image']==images[arm]
        assert proc['started_unix_ns']>=previous_end;previous_end=proc['finished_unix_ns']
        if arm in commands:assert commands[arm]==command_key(proc['command'])
        else:commands[arm]=command_key(proc['command'])
        assert all(d[k]==v for k,v in expect.items())
        if a.workload=='single':
            phases={v['name']:v for v in d['phases']};ids=d.get('generated_ids',d.get('predicted_ids'));wall=d['session_seconds']
            assert proc['command'][proc['command'].index('--capacity')+1]=='1024'
            assert sum(v['input_tokens'] for v in phases.values() if v['kind']=='prefill')==768
            assert sum(v['input_tokens'] for v in phases.values() if v['kind']=='decode')==96
        else:
            phases={v.get('session_id',v.get('id'))+'_'+q['name']:q for v in d['sessions'] for q in v['phases']}
            ids={v.get('session_id',v.get('id')):v['generated_ids'] for v in d['sessions']}
            wall=d['session_seconds' if arm=='peer' else 'interleaved_seconds']
            assert proc['command'][proc['command'].index('--capacity')+1]=='256'
            assert len(phases)==9 and sum(len(v) for v in ids.values())==102
            assert sum(v['input_tokens'] for v in phases.values() if v['kind']=='prefill')==548
            assert sum(v['input_tokens'] for v in phases.values() if v['kind']=='decode')==97
        contexts={k:(v['kind'],v['input_tokens'],v['context_before'],v['context_after']) for k,v in phases.items()}
        if reference is None:reference=ids;phase_reference=contexts
        assert ids==reference and contexts==phase_reference
        pref=sum(v['seconds'] for v in phases.values() if v['kind']=='prefill');dec=sum(v['seconds'] for v in phases.values() if v['kind']=='decode')
        assert min(pref,dec,wall)>0
        metrics=dict(prefill_tps=768/pref,full_decode_tps=96/dec,session_output_tps=99/wall,session_processed_tps=864/wall) if a.workload=='single' else dict(
            logical_prefill_tps=548/pref,actual_prefill_tps=161/pref,full_decode_tps=97/dec,session_output_tps=102/wall,logical_session_tps=645/wall,actual_session_tps=258/wall)
        text=(folder/'stderr.log').read_text(encoding='utf-8-sig');loading={}
        if arm=='peer':
            values=d.get('loading',d)
            for src,dst in [('model_load_seconds','model_load_seconds'),('startup_to_ready_seconds','startup_to_ready_seconds'),
                ('ready_seconds','startup_to_ready_seconds'),('first_token_elapsed_seconds','first_token_elapsed_seconds')]:
                if src in values:loading[dst]=values[src]
        else:
            for src,dst in [('weights_load_seconds','model_load_seconds'),('startup_to_ready_seconds','startup_to_ready_seconds'),
                ('first_token_elapsed_seconds','first_token_elapsed_seconds')]:
                matches=re.findall(r'\b'+src+r'=([\deE.+-]+)',text)
                if matches:loading[dst]=float(matches[0])
        for k in ('model_load_seconds','startup_to_ready_seconds','first_token_elapsed_seconds'):loading.setdefault(k,None)
        details=dict(arm=arm,folder=str(folder),receipt=identity(folder/'result.json'),raw=identity(folder/('peer-result.json' if arm=='peer' else 'stdout.log')),
            metrics=metrics,prefill_wall_seconds=pref,decode_wall_seconds=dec,session_seconds=wall,
            startup_total_seconds=d['startup_total_seconds'],loading=loading,phases_seconds={k:v['seconds'] for k,v in phases.items()})
        if mode=='timing':rows.append(details)
        else:
            sampled=read(folder/'memory.json');summary=memory_summary(sampled,proc)
            assert summary==read(folder/'memory-summary.json')
            assert set(summary['phase_windows'])==set(phases)
            assert all(not v['missing_boundary'] and not v['ambiguous_boundary'] and not v['invalid_boundary_order'] for v in summary['phase_windows'].values())
            for v in sampled['samples']:
                ded,shared=v['gpu_dedicated_bytes'],v['gpu_shared_bytes']
                assert v['gpu_total_bytes']==(ded+shared if ded is not None and shared is not None else None)
            peaks={k:max((v[k] for v in sampled['samples'] if v.get(k) is not None),default=None) for k in KEYS}
            compact_phases={k:dict(sample_count=v['sample_count'],sampled_peaks_bytes={f:v['values'][f]['max'] for f in KEYS},
                null_sample_counts=v['null_sample_counts'],bracket_delta_bytes=v['bracket_delta_bytes'],bracket_ages_ns=v['bracket_ages_ns']) for k,v in summary['phase_windows'].items()}
            mem[arm]=dict(receipt=details['receipt'],sampler=identity(folder/'memory.json'),summary=identity(folder/'memory-summary.json'),
                requested_interval_seconds=sampled['requested_interval_s'],sample_count=summary['sample_count'],running_samples=summary['running_sample_count'],
                observed_sampled_peaks_bytes=peaks,null_sample_counts=summary['null_sample_counts'],actual_sample_gaps_ms=summary['actual_sample_gaps_ms'],
                sample_cost_ms=summary['sample_cost_ms'],ready_baseline=summary['ready_baseline'],phase_windows=compact_phases,
                gpu_setup_error=summary['setup_error'],thread_error=summary['thread_error'])
groups={}
for arm in images:
    selected=[v for v in rows if v['arm']==arm];assert len(selected)==3 and arm in mem
    groups[arm]=dict(rates={k:stats([r['metrics'][k] for r in selected]) for k in selected[0]['metrics']},
        session_seconds=stats([r['session_seconds'] for r in selected]),startup_total_seconds=stats([r['startup_total_seconds'] for r in selected]),
        loading={k:stats([r['loading'][k] for r in selected if r['loading'][k] is not None]) for k in selected[0]['loading']},
        phase_seconds={k:stats([r['phases_seconds'][k] for r in selected]) for k in selected[0]['phases_seconds']})
comparison={other:{k:dict(current_vs_other_median_percent=100*(groups['current']['rates'][k]['median']/groups[other]['rates'][k]['median']-1),
    observed_ranges_overlap=max(groups['current']['rates'][k]['min'],groups[other]['rates'][k]['min'])<=min(groups['current']['rates'][k]['max'],groups[other]['rates'][k]['max'])) for k in groups['current']['rates']} for other in images if other!='current'}
limits=['Rates are computed per process first and then median/min/max over3 processes. No phase TPS averaging, pooled process denominator or phase-median denominator.',
    'After-ready session wall is separate from loading/startup_total. Session residence walls overlap in multi-session runs and must not be summed.',
    'Multi prefix hits reuse387 tokens; logical prefill548 and actual prefill161 are separately labelled. Active1 is serial GPU work, not simultaneous-user throughput.',
    'Memory is one separate process per arm. Exact reported bytes/nulls and sample gaps are retained. Sampled peaks are lower bounds, not physical allocations; no sum of independent dedicated/shared peaks.',
    'All phase deltas use parent-time neighbor brackets. Short/full-hit phases may have0 interior samples; teardown may contaminate final brackets. No allocation attribution or fake missing baseline.',
    'Normal desktop/unfixed clocks and3-process finite window; no universal gain/statistical significance/quality claim. No profiler duration enters rates.',
    'No historical memory samples are reused for new images. All phase windows are independently recomputed from the live timestamped marker records saved by the new observer.']
table=dict(status='Host-only independent raw recomputation PASS',workload=a.workload,images=images,
    input_record=identity(P/'timing/inputs.json'),timing=groups,independent_memory=mem,comparison=comparison,
    work=expect,all_timing_and_memory_ids_contexts_equal=True,timing_processes=len(rows),memory_processes=len(mem),limits=limits)
save(P/'public-table.json',table)
review=dict(status='PASS',script=identity(__file__),observer=identity(S/'observer.py'),public_table=identity(P/'public-table.json'),
    per_process=rows,inputs=[identity(P/mode/name) for mode in ('timing','memory') for name in ('inputs.json','runs.json','summary.json')],
    window_snapshots=[identity(x) for mode in ('timing','memory') for x in sorted((P/mode).glob('window-*.json'))],
    scope=limits,activity=dict(builds=0,GPU_runs=0,product_edits=0))
save(P/'performance-review.json',review)
print(json.dumps(dict(table=identity(P/'public-table.json'),review=identity(P/'performance-review.json'),
    median={arm:{k:v['median'] for k,v in group['rates'].items()} for arm,group in groups.items()})))
