"""Offline exact-source review receipt only."""
from pathlib import Path
import hashlib,json
W=Path(__file__).resolve().parent
R=W.parents[2]
def pin(p):
 b=p.read_bytes();return dict(path=p.relative_to(R).as_posix(),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
pins=json.loads((W/'source-pins.json').read_text())
before=R/pins['files'][0]['before']['path'];after=R/pins['files'][0]['after']['path']
assert pin(before)['sha256']==pins['files'][0]['before']['sha256']
assert pin(after)['sha256']==pins['files'][0]['after']['sha256']
old=iter(before.read_text().splitlines())
# Every original source line remains in original order: only diagnostic
# declarations/calls were added; no original operation or branch was deleted.
lines=iter(after.read_text().splitlines())
for line in old:
 assert any(candidate==line for candidate in lines),line
review=dict(status='NO_SOURCE_BLOCKER_PRIVATE_DIAGNOSTIC_ONLY',source=pin(after),patch=pin(W/'source.patch'),
 plan=pin(W/'plan.json'),checks=[
 'All original source lines remain ordered. Stream validation, recording_guard, bindings, primary-context admission, checked IDs, packed scope, native bridge, catch/status and deferred native retirement are unchanged.',
 'Scope records only integer tags/scalars, never keeps or dereferences a resource/owner. Constructor/mark/destructor are noexcept; no new permission or error policy.',
 'Static32768 Event store has source-derived x64 size96/3MiB payload; only recording=true reads clocks/updates entries. No instrumentation heap allocation or per-submit IO.',
 'seen flags preserve early-return/exception paths; missing ticks are not zero-duration stages. Overflow increments are visible in process-exit trailer.',
 'Four deltas are disjoint only within a complete seen31 event. Do not add them again to enclosing Graph capture/native API spans or GPU time. t4 includes later original local/context destruction.',
 'Same-TU Store is alive during Dumper; no CUDA/resource access at dump. Accept only normal fully retired/joined case with complete trailer, attempted=stored=finished and overflow0. Crashes/timeouts/concurrent exit are not certified.',
 'Original provider dependency overlay, original56afda object replacement and233 unchanged inputs are a source plan; actual compile deps/link map and runtime results are not yet reviewed.'
 ],notes=['The measured provider span has no added allocation; process-exit stdio may use normal CRT buffering outside it.',
 'The four newly explicit standard includes may enlarge actual dependency count. Preserve the original209 dependency identities (except instrumented source); allow only attributable extra standard-library instrumentation headers.',
 'Exact private diagnostic is not canonical product or TPS evidence. No compiler, model, GPU, network or numerical execution performed by reviewer.'])
p=W/'independent-review-architecture.json';p.write_text(json.dumps(review,indent=2)+'\n',encoding='utf-8');print(pin(p))
