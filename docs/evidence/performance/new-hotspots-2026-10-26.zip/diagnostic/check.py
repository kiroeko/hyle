"""Bounded provider-only diagnostic. Explicit build/run subcommands; no SDK build."""
from pathlib import Path
import ast
import hashlib
import importlib.util
import json
import os
import re
import statistics
import sys

sys.dont_write_bytecode = True
WORK = Path(__file__).resolve().parent
ROOT = WORK.parents[2]
BASE = ROOT / '.scratch/inference-synchronous-step-report-20261025/cuda'
OLD = ROOT / '.scratch/mtp-packed-head-20261024/orin-proposal/mmq-query-proposal/compile2/provider'
spec = importlib.util.spec_from_file_location('retained_local_recipe',
    ROOT / '.scratch/inference-synchronous-step-report-20261025/check_host.py')
helper = importlib.util.module_from_spec(spec)
spec.loader.exec_module(helper)
pin, save, execute = helper.pin, helper.save, helper.execute


def read(path):
    return json.loads(path.read_bytes())


def exact(row):
    path = Path(row['path'])
    if not path.is_absolute():
        path = ROOT / path
    actual = pin(path)
    assert actual['bytes'] == row['bytes'] and actual['sha256'] == row['sha256'], path


def prerequisites():
    ready = read(BASE / 'ready.json')
    assert ready['image']['sha256'] == '7030426b20990d8d5dcfcbce35f75ded435696efd16de49fd30aafefebef4b40'
    for key in ['image', 'app', 'weights', 'report', 'native', 'runtime', 'link_inputs']:
        exact(ready[key])
    for row in read(BASE / 'link-inputs.json'):
        exact(row)
    source_pins = read(WORK / 'source-pins.json')
    for row in source_pins['files']:
        exact(row['before'])
        exact(row['after'])
    deps_plan = read(WORK / 'dependency-plan.json')
    for row in deps_plan['selected']:
        exact(row['selected'])
    return ready, source_pins, deps_plan


def build(resume=False):
    out = WORK / 'attempt1'
    assert out.exists() if resume else not out.exists(), 'Retain existing attempts; do not overwrite/recompile'
    ready, source_pins, dep_plan = prerequisites()
    source = WORK / 'source/src/compute_provider_ggml_cuda/ggml_cuda_provider.cc'
    identity = read(OLD / 'identity.json')
    command = list(read(OLD / 'compile.command.json')['command'])
    compiler = command[0]
    env = helper.discover_environment(compiler='msvc', cache={
        'CMAKE_C_COMPILER': compiler, 'CMAKE_CXX_COMPILER': compiler,
        'CMAKE_GENERATOR': 'Ninja'}, backends=()).env
    out.mkdir(exist_ok=resume)
    folder = out / 'provider'
    obj = folder / 'unit.obj'
    command.insert(1, '/I' + str(WORK / 'include-freeze'))
    command[command.index(identity['source']['path'])] = str(source)
    command[command.index('/sourceDependencies') + 1] = str(folder / 'dependencies.json')
    command = [('/Fo' + str(obj)) if arg.startswith('/Fo') else
               ('/Fd' + str(folder / 'unit.pdb')) if arg.startswith('/Fd') else arg
               for arg in command]
    build_plan = {'baseline_ready': pin(BASE / 'ready.json'),
        'source_pins': pin(WORK / 'source-pins.json'), 'diagnostic_plan': pin(WORK / 'plan.json'),
        'dependency_plan': pin(WORK / 'dependency-plan.json'),
        'original_compile': pin(OLD / 'compile.command.json'),
        'scope': 'one original provider host TU, original209-header contract,233 other original703 inputs; no current-canonical whole-image certification'}
    if resume:
        assert read(out / 'plan.json') == build_plan
        assert read(folder / 'command.json')['command'] == command
        compiled = read(folder / 'process.json')
        assert compiled['exit'] == 0
    else:
        save(out / 'plan.json', build_plan)
        compiled = execute(command, env, folder, timeout=120)
    data = read(folder / 'dependencies.json')['Data']
    assert Path(data['Source']).resolve() == source.resolve()
    actual = list(dict.fromkeys([data['Source'], *data['Includes']]))
    actual_rows = [pin(Path(path)) for path in actual]
    actual_map = {Path(row['path']).resolve(): row for row in actual_rows}
    source_path = (ROOT / identity['source']['path']).resolve()
    expected_actual = set()
    for row in dep_plan['selected']:
        old_path = Path(row['expected']['path']).resolve()
        selected_path = Path(row['selected']['path'])
        if not selected_path.is_absolute():
            selected_path = ROOT / selected_path
        if old_path == source_path:
            selected_path = source
            wanted = source_pins['files'][0]['after']['sha256']
        else:
            wanted = row['expected']['sha256']
        selected_path = selected_path.resolve()
        assert selected_path in actual_map, selected_path
        assert actual_map[selected_path]['sha256'] == wanted, selected_path
        expected_actual.add(selected_path)
    extra = [row for row in actual_rows if Path(row['path']).resolve() not in expected_actual]
    # chrono/atomic/type_traits can expose more standard-library headers. No
    # unreviewed project/header version may silently enter through this branch.
    compiler_include = Path(compiler).parents[3] / 'include'
    ucrt_dirs = {Path(row['expected']['path']).parent.resolve()
                 for row in dep_plan['selected']
                 if Path(row['expected']['path']).name.lower() == 'stdio.h'}
    standard_roots = [compiler_include.resolve(), *ucrt_dirs]
    for row in extra:
        assert any(Path(row['path']).resolve().is_relative_to(base) for base in standard_roots), row
    save(folder / 'actual-dependencies.json', actual_rows)
    save(folder / 'dependency-check.json', {'old_dependencies': len(dep_plan['selected']),
        'all_original_selected_hashes_exact': True, 'instrumented_source': pin(source),
        'additional_MSVC_or_original_UCRT_standard_headers': extra,
        'standard_roots': [str(path) for path in standard_roots], 'actual_count': len(actual_rows)})
    old_obj = identity['object']['path']
    original = read(BASE / 'link/command.json')['command']
    assert original.count(old_obj) == 1
    args = [str(obj) if arg == old_obj else arg for arg in original
            if not arg.lower().startswith(('/out:', '/pdb:', '/implib:', '/map:'))]
    inputs = [Path(arg) for arg in args[1:] if Path(arg).is_absolute() and Path(arg).suffix.lower() in ['.obj', '.lib']]
    before = read(BASE / 'link-inputs.json')
    after = [pin(path) for path in inputs]
    assert len(before) == len(after) == 221
    assert sum(a != b for a, b in zip(before, after)) == 1
    assert [row for row in before if row['path'] != old_obj] == [row for row in after if row['path'] != str(obj)]
    save(out / 'link-inputs.json', after)
    image = out / 'link/hyle.exe'
    linked = execute([*args, '/OUT:' + str(image), '/IMPLIB:' + str(image.with_suffix('.lib')),
                      '/PDB:' + str(image.with_suffix('.pdb'))], env, image.parent, timeout=120)
    native = Path(ready['native']['path'])
    os.link(native, image.parent / native.name)
    runtime = read(BASE / 'runtime.json')
    runtime['PATH'] = str(image.parent) + os.pathsep + runtime['PATH']
    runtime['original_runtime_record'] = pin(BASE / 'runtime.json')
    runtime['native_hardlink'] = pin(image.parent / native.name)
    save(out / 'runtime.json', runtime)
    prerequisites()
    result = {'status': 'READY_CAPTURE_ONLY_PROVIDER_TIMING_NO_GPU_RUN',
        'image': pin(image), 'app': ready['app'], 'weights': ready['weights'], 'report': ready['report'],
        'provider': pin(obj), 'source': pin(source), 'source_pins': pin(WORK / 'source-pins.json'),
        'runtime': pin(out / 'runtime.json'), 'native': ready['native'],
        'baseline_ready': pin(BASE / 'ready.json'), 'baseline_image': ready['image'],
        'link_inputs': pin(out / 'link-inputs.json'), 'total_inputs': 234, 'unchanged_inputs': 233,
        'commands': {'provider': pin(folder / 'command.json'), 'link': pin(image.parent / 'command.json')},
        'actual_dependencies': pin(folder / 'actual-dependencies.json'),
        'dependency_check': pin(folder / 'dependency-check.json'),
        'processes': {'provider': compiled, 'link': linked}, 'new_TUs': 1,
        'app_core_SDK_native_CUDA_rebuilds': 0, 'GPU_runs': 0,
        'limits': 'Frozen703 historical-source incremental closure; not an all-current-canonical image or throughput result. Five exact original provider headers restored, no newer API certification.'}
    save(out / 'ready.json', result)
    print(json.dumps({key: result[key] for key in ['status', 'image', 'processes']}, indent=2))


def retained_normalization():
    # Reuse literal original screen functions without importing its top-level
    # benchmark execution or manufacturing a new normalization whitelist.
    path = ROOT / '.scratch/mtp-fixed-hidden-output-20261025/screen.py'
    tree = ast.parse(path.read_text())
    namespace = {}
    code = ast.Module(body=[node for node in tree.body if isinstance(node, ast.FunctionDef)
                           and node.name in ['normalize', 'differences']], type_ignores=[])
    exec(compile(code, str(path), 'exec'), namespace)
    return namespace['normalize'], namespace['differences']


def report(path):
    return json.loads(next(line for line in reversed(path.read_text().splitlines()) if line.startswith('{')))


def run():
    out = WORK / 'attempt1'
    ready = read(out / 'ready.json')
    prerequisites()
    for key in ['image', 'provider', 'runtime', 'source']:
        exact(ready[key])
    baseline_folder = ROOT / '.scratch/inference-synchronous-step-report-20261025/screen/timing-02-candidate'
    original = read(baseline_folder / 'command.json')['command']
    assert original[0] == read(BASE / 'ready.json')['image']['path']
    command = [ready['image']['path'], *original[1:]]
    input_dir = Path(command[command.index('--inputs') + 1])
    schedule = Path(command[command.index('--schedule') + 1])
    inputs = [pin(input_dir / name) for name in ['weights.tsv', 'prompt.ids', 'input.json']] + [pin(schedule)]
    runtime = read(out / 'runtime.json')
    env = dict(os.environ)
    env['PATH'] = runtime['PATH']
    env.update(runtime.get('configured_flags', {}))
    save(out / 'run-plan.json', {'baseline_command': pin(baseline_folder / 'command.json'),
        'baseline_stdout': pin(baseline_folder / 'stdout.log'), 'baseline_stderr': pin(baseline_folder / 'stderr.log'),
        'image': ready['image'], 'runtime': ready['runtime'], 'inputs': inputs,
        'GPU_processes': 1, 'timeout': 120, 'not_TPS': True})
    executed = execute(command, env, out / 'run', timeout=120)
    stdout, stderr = out / 'run/stdout.log', out / 'run/stderr.log'
    parsed = report(stdout)
    normalize, differences = retained_normalization()
    delta = differences(normalize(report(baseline_folder / 'stdout.log')), normalize(parsed))
    save(out / 'run/nontime-differences.json', delta)
    text = stderr.read_text()
    marker_lines = [line for line in text.splitlines() if line.startswith('CUDA_PROVIDER_CAPTURE')]
    def fields(line):
        return {k: int(v) for k, v in re.findall(r'(\w+)=(\d+)', line)}
    assert len([line for line in marker_lines if line.startswith('CUDA_PROVIDER_CAPTURE_BEGIN ')]) == 1
    assert len([line for line in marker_lines if line.startswith('CUDA_PROVIDER_CAPTURE_END ')]) == 1
    end = fields(next(line for line in marker_lines if line.startswith('CUDA_PROVIDER_CAPTURE_END ')))
    rows = [fields(line) for line in marker_lines if line.startswith('CUDA_PROVIDER_CAPTURE ordinal=')]
    assert end['attempted'] == end['stored'] == end['finished'] == len(rows)
    assert end['overflow'] == 0 and end['process_exit_dump'] == 1
    assert all(row['seen'] == 31 and row['terminal_ok'] == 1 for row in rows)
    assert [row['ordinal'] for row in rows] == list(range(len(rows)))
    ordinary_lines = [line for line in text.splitlines(keepends=True) if not line.startswith('CUDA_PROVIDER_CAPTURE')]
    def no_clocks(value):
        return re.sub(r'\b(\w*seconds)=\S+', r'\1=<TIME>', value)
    stderr_equal = no_clocks(''.join(ordinary_lines)) == no_clocks((baseline_folder / 'stderr.log').read_text())
    assert not delta and stderr_equal
    buckets = {}
    for index, name in enumerate(['bindings', 'admission_and_guards', 'bridge', 'publication_and_cleanup']):
        values = [row['t' + str(index + 1)] - row['t' + str(index)] for row in rows]
        assert all(value >= 0 for value in values)
        buckets[name] = {'total_ms': sum(values) / 1e6, 'median_us': statistics.median(values) / 1e3,
                         'min_us': min(values) / 1e3, 'max_us': max(values) / 1e3}
    save(out / 'run/events.json', rows)
    summary = {'status': 'FINITE_FROZEN_PROVIDER_CAPTURE_TIMING_PASS_NOT_TPS',
        'process': executed, 'ready': pin(out / 'ready.json'), 'complete': end,
        'non_time_differences': len(delta), 'original_stderr_equal_after_clock_values_only': stderr_equal,
        'buckets': buckets, 'events': pin(out / 'run/events.json'),
        'original_report': parsed, 'raw': [pin(stdout), pin(stderr)],
        'limits': 'CPU elapsed diagnostic in frozen703 historical object closure, not current canonical whole-image certification. No profiler/no peer/no measured speed claim. Provider buckets omit graph dispatch between invocations and may contain original GPU API host work.'}
    save(out / 'summary.json', summary)
    print(json.dumps({key: summary[key] for key in ['status', 'process', 'complete', 'non_time_differences', 'buckets']}, indent=2))


if __name__ == '__main__':
    assert sys.argv[1:] in [['build'], ['resume-after-compile'], ['run']]
    if sys.argv[1] == 'run':
        run()
    else:
        build(resume=sys.argv[1] == 'resume-after-compile')
