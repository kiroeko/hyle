"""Offline reduction of the one direct diagnostic's original stderr/stdout."""
from pathlib import Path
from collections import defaultdict
import hashlib
import json
import re
import statistics

ROOT = Path.cwd()
WORK = Path(__file__).resolve().parent
ATTEMPT = WORK / 'diagnostic/attempt1'


def pin(path):
    raw = path.read_bytes()
    return {'path': path.relative_to(ROOT).as_posix(), 'bytes': len(raw),
            'sha256': hashlib.sha256(raw).hexdigest()}


def stats(values, unit=1):
    return {'n': len(values), 'total': sum(values) / unit,
            'median': statistics.median(values) / unit,
            'min': min(values) / unit, 'max': max(values) / unit}


text = (ATTEMPT / 'run/stderr.log').read_text()
events = [{k: int(v) for k, v in re.findall(r'(\w+)=(\d+)', line)}
          for line in text.splitlines()
          if line.startswith('CUDA_PROVIDER_CAPTURE ordinal=')]
assert len(events) == 4446
assert all(row['seen'] == 31 and row['terminal_ok'] == 1 for row in events)
assert all(a['t4'] <= b['t0'] for a, b in zip(events, events[1:])), 'Do not sum overlapping provider events'
prepared = []
for line in text.splitlines():
    if line.startswith('prepared T='):
        fields = dict(re.findall(r'(\w+)=(\S+)', line))
        prepared.append({'prepared_ordinal': len(prepared) + 1,
            'T': int(fields['T']), 'visible': int(fields['visible']),
            'replay': fields['replay'], 'cold_batch_seconds': float(fields['cold_batch_seconds']),
            'capture_recorded': int(fields.get('capture_recorded', 0)),
            'capture_reused': int(fields.get('capture_reused', 0))})
groups = {
    'all_prepared': prepared,
    'prefill_T_gt2': [row for row in prepared if row['T'] > 2],
    'decode_T_le2': [row for row in prepared if row['T'] <= 2],
    'decode_with_record': [row for row in prepared if row['T'] <= 2 and row['capture_recorded']],
    'decode_no_record': [row for row in prepared if row['T'] <= 2 and not row['capture_recorded']],
}
prepared_groups = {name: {
    'cold_batch_ms': stats([row['cold_batch_seconds'] * 1000 for row in rows]),
    'capture_recorded': sum(row['capture_recorded'] for row in rows),
    'capture_reused': sum(row['capture_reused'] for row in rows)}
    for name, rows in groups.items()}
by_nodes = defaultdict(list)
for row in events:
    by_nodes[row['nodes']].append(row)
node_groups = [{
    'recipe_nodes': nodes, 'events': len(rows),
    'bridge_ms': stats([row['t3'] - row['t2'] for row in rows], 1e6),
    'provider_ms': stats([row['t4'] - row['t0'] for row in rows], 1e6),
    'note': 'Recipe-node count, not kernel count or an operation label.'}
    for nodes, rows in sorted(by_nodes.items())]
first, later = {}, []
for row in events:
    if row['program'] not in first:
        first[row['program']] = row
    else:
        later.append(row)
program_groups = {name: {'events': len(rows),
    'bridge_ms': stats([row['t3'] - row['t2'] for row in rows], 1e6),
    'provider_ms': stats([row['t4'] - row['t0'] for row in rows], 1e6)}
    for name, rows in [('first_per_program', list(first.values())), ('later_per_program', later)]}
provider_ms = sum(row['t4'] - row['t0'] for row in events) / 1e6
cold_ms = prepared_groups['decode_with_record']['cold_batch_ms']['total']
summary = json.loads((ATTEMPT / 'summary.json').read_bytes())
report = {'status': 'FINITE_SAME_RUN_CAPTURE_ONLY_PROVIDER_SCOPE_CLOSED_NO_TPS',
    'original_summary': pin(ATTEMPT / 'summary.json'),
    'raw_stdout': pin(ATTEMPT / 'run/stdout.log'), 'raw_stderr': pin(ATTEMPT / 'run/stderr.log'),
    'process': summary['process'], 'complete': summary['complete'],
    'non_time_differences': summary['non_time_differences'],
    'original_stderr_equal_after_clock_values_only': summary['original_stderr_equal_after_clock_values_only'],
    'four_provider_buckets': summary['buckets'],
    'all_events_nonoverlapping': True, 'all_events_seen31_terminal_ok1': True,
    'provider_total_ms': provider_ms, 'prepared_groups': prepared_groups,
    'same_run_nested_scope': {'recording_prepares_ms': cold_ms,
        'capture_only_provider_event_union_ms': provider_ms,
        'outside_provider_in_recording_prepares_ms': cold_ms - provider_ms,
        'basis': 'Original cold_batch timer encloses batch/layout/replay prepare. Capture-only provider submits run inside original replay preparation; event intervals do not overlap. This is aggregate nesting, not a recorded per-event-to-episode clock join.',
        'unknown_outside': 'Includes original layout/native-plan preparation, other providers/copies, Graph host dispatch, capture-end/Instantiate/Update and possible native waits. No new API trace or breakdown exists; it is not pure Graph CPU or a recoverable amount.'},
    'programs': len(first), 'invocations': len({row['invocation'] for row in events}),
    'node_groups': node_groups, 'program_first_vs_later': program_groups,
    'top10_bridge_events': sorted(events, key=lambda row: row['t3'] - row['t2'], reverse=True)[:10],
    'prepared_rows': prepared,
    'decision': 'Do not pursue removal/merging of provider safety scopes on this evidence: the three non-bridge buckets total2.1209ms over the whole diagnostic. Establish a dependency-consistent current host closure first. If further cold-cost localization is needed, target the original replay/native capture-end preparation outside provider, not a repeat provider sample.',
    'limits': ['No profiler in this new single process; old paired15body/Nsight capture totals cannot be subtracted from this27capture direct process.',
               'Bridge13.1698ms includes cuBLAS scope/metadata/encode and native host API work; no unique internal attribution.',
               'The largest bridge event2.0222ms is tagged nodes3/inputs6/outputs2 only; exact operation and cause were not captured.',
               'No complete graph/capture wall timestamp was added; outside-provider aggregate cannot be assigned per body/front range.',
               'Frozen703 historical-object closure with five exact old provider headers; no current-canonical whole-image or newer API certification.',
               'No optimization or throughput gain is demonstrated.']}
path = WORK / 'current-diagnostic-memo.json'
path.write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'memo': pin(path), 'prepared_groups': prepared_groups,
                  'same_run_nested_scope': report['same_run_nested_scope']}, indent=2))
