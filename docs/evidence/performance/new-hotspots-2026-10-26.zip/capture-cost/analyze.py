"""Offline read of the paired logical traces, no device/compiler invocation."""
from pathlib import Path
from collections import Counter, defaultdict
import hashlib
import json
import sqlite3
import statistics

ROOT = Path.cwd()
WORK = Path(__file__).resolve().parent
SOURCE = ROOT / '.scratch/mtp-logical-call-trace-20261025'
SQL = 'SELECT r.*,s.value AS api FROM CUPTI_ACTIVITY_KIND_RUNTIME r JOIN StringIds s ON s.id=r.nameId ORDER BY start'


def read(path):
    return json.loads(path.read_bytes())


def pin(path):
    raw = path.read_bytes()
    return {'path': path.relative_to(ROOT).as_posix(), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def union(rows):
    merged = []
    for a, b in sorted(rows):
        if merged and a <= merged[-1][1]:
            merged[-1][1] = max(merged[-1][1], b)
        else:
            merged.append([a, b])
    return sum(b - a for a, b in merged)


def stats(values):
    return {'n': len(values), 'total_ms': sum(values) / 1e6,
            'mean_ms': statistics.mean(values) / 1e6, 'median_ms': statistics.median(values) / 1e6,
            'min_ms': min(values) / 1e6, 'max_ms': max(values) / 1e6}


def api_stats(rows):
    result = {}
    for name in sorted({row['api'] for row in rows}):
        selected = [row for row in rows if row['api'] == name]
        result[name] = {'calls': len(selected),
            'sum_ms_not_additive_across_APIs': sum(row['end'] - row['start'] for row in selected) / 1e6,
            'union_ms': union((row['start'], row['end']) for row in selected) / 1e6,
            'return_codes': dict(Counter(str(row['returnValue']) for row in selected))}
    return result


def api_group_union(rows):
    groups = {
        'kernel_launch': lambda name: name.startswith(('cudaLaunchKernel_', 'cudaLaunchKernelExC_', 'cuLaunchKernel')),
        'capture_control': lambda name: name.startswith(('cudaStreamIsCapturing_', 'cudaThreadExchangeStreamCaptureMode_')),
        'copy': lambda name: 'Memcpy' in name,
        'allocation_event_or_sync': lambda name: any(part in name for part in ['Malloc', 'Free', 'EventCreate', 'EventRecord', 'Synchronize']),
    }
    return {name: {'API_calls': len(selected),
                   'union_ns': union((row['start'], row['end']) for row in selected)}
            for name, predicate in groups.items()
            for selected in [[row for row in rows if predicate(row['api'])]]}


out = {'status': 'OFFLINE_OLD_PAIRED_CAPTURE_COST_ONLY', 'SQL': SQL, 'arms': {}}
for arm in ['hyle', 'peer']:
    folder = SOURCE / arm / 'trace1'
    db = sqlite3.connect('file:' + (folder / 'trace.sqlite').resolve().as_posix() + '?mode=ro', uri=True)
    db.row_factory = sqlite3.Row
    db.execute('PRAGMA query_only=ON')
    apis = [dict(row) for row in db.execute(SQL)]
    gpu = []
    for table in ['CUPTI_ACTIVITY_KIND_KERNEL', 'CUPTI_ACTIVITY_KIND_MEMCPY', 'CUPTI_ACTIVITY_KIND_MEMSET']:
        gpu.extend(dict(row) for row in db.execute('SELECT start,end FROM ' + table))
    captures, groups = [], defaultdict(list)
    for action in read(SOURCE / arm / 'capture-actions.json')['actions']:
        a, b, tid = action['begin']['start'], action['end_capture']['end'], action['begin']['globalTid']
        rows = [row for row in apis if row['globalTid'] == tid and a < row['end'] and row['start'] < b]
        crossing = [row for row in rows if row['start'] < a or row['end'] > b]
        assert not crossing
        kernels = [row for row in rows if row['api'].startswith(('cudaLaunchKernel_', 'cudaLaunchKernelExC_', 'cuLaunchKernel'))]
        group = ('body_target_signature738' if len(kernels) == 738 else 'front_draft_signature37or41') if arm == 'hyle' else ('target' if action['logical_label'].startswith('peer/target') else 'draft')
        assert len(kernels) in ([738, 37, 41] if arm == 'hyle' else [727, 34])
        special = action['events']
        end = max(row['end'] for row in special)
        post = [row for row in apis if row['globalTid'] == tid and b <= row['start'] and row['end'] <= end]
        covered = union((row['start'], row['end']) for row in rows)
        observed_gpu = union((max(a, row['start']), min(b, row['end'])) for row in gpu if a < row['end'] and row['start'] < b)
        record = {'group': group, 'meta': action['meta'], 'start_ns': a, 'end_ns': b,
            'capture_wall_ns': b - a, 'visible_API_union_ns': covered,
            'API_uncovered_wall_ns': b - a - covered, 'visible_GPU_union_ns': observed_gpu,
            'kernel_launch_API_calls': len(kernels), 'capture_API': api_stats(rows),
            'capture_API_group_union': api_group_union(rows),
            'post_capture_native_API': api_stats(post),
            'capture_through_native_action_end_wall_ns': end - a,
            'native_actions': action['ordered_actions']}
        captures.append(record)
        groups[group].append((record, rows, post))
    summarized = {}
    for name, items in groups.items():
        summary = {key: stats([row[key] for row, _, _ in items]) for key in
            ['capture_wall_ns', 'visible_API_union_ns', 'API_uncovered_wall_ns',
             'visible_GPU_union_ns', 'capture_through_native_action_end_wall_ns']}
        summary['capture_API'] = api_stats([item for _, rows, _ in items for item in rows])
        summary['capture_API_group_union'] = api_group_union([item for _, rows, _ in items for item in rows])
        summary['post_capture_native_API'] = api_stats([item for _, _, rows in items for item in rows])
        summary['kernel_launch_API_counts_per_record'] = sorted({row['kernel_launch_API_calls'] for row, _, _ in items})
        summary['seq'] = [row['meta']['seq'] for row, _, _ in items]
        summarized[name] = summary
    if arm == 'hyle':
        first, *rest = [row for row in captures if row['group'] == 'body_target_signature738']
        summarized['body_first_vs_remaining'] = {'first_seq': first['meta']['seq'],
            'first_capture_ms': first['capture_wall_ns'] / 1e6,
            'remaining14_capture': stats([row['capture_wall_ns'] for row in rest]),
            'remaining14_API_union': stats([row['visible_API_union_ns'] for row in rest]),
            'remaining14_API_uncovered': stats([row['API_uncovered_wall_ns'] for row in rest])}
    records = read(SOURCE / arm / 'logical-records.json')
    eager = [row for row in records if ('_decode' in row['label'] if arm == 'peer' else row['meta']['role'] in [3, 4, 5, 6]) and not row['captured_launches']]
    tables = [row[0] for row in db.execute("SELECT name FROM sqlite_master WHERE type='table'")]
    out['arms'][arm] = {'inputs': [pin(folder / 'trace.sqlite'), pin(SOURCE / arm / 'capture-actions.json'), pin(SOURCE / arm / 'logical-records.json')],
        'record_count': len(captures), 'groups': summarized, 'captures': captures,
        'eager_decode_roots': [{'label': row['label'], 'meta': row['meta'], 'kernels': row['kernels'],
            'native_range_wall_ns': row['cpu_range_ns'], 'GPU_union_ns': row['gpu_contained_union_ns']} for row in eager],
        'explicit_CUBLAS_or_driver_tables': [table for table in tables if 'CUBLAS' in table or table == 'CUPTI_ACTIVITY_KIND_DRIVER']}
    db.close()
out['script'] = pin(Path(__file__))
(WORK / 'facts.json').write_text(json.dumps(out, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'status': out['status'], 'groups': {arm: {group: {key: value for key, value in row.items() if key not in ['capture_API', 'post_capture_native_API']} for group, row in data['groups'].items()} for arm, data in out['arms'].items()}}, indent=2))
