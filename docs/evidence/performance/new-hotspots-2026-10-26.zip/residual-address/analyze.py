"""Bounded offline use of retained full bindings and current formatter logs."""
from pathlib import Path
import hashlib
import json
import re

ROOT=Path(__file__).resolve().parents[2]
WORK=Path(__file__).resolve().parent
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def pin(p):
    b=p.read_bytes();return dict(path=p.relative_to(ROOT).as_posix(),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def save(name,d):
    (WORK/name).write_text(json.dumps(d,indent=2)+'\n',encoding='utf-8')

old=ROOT/'.scratch/mtp-body-recapture-cause-20261025/cause-facts.json'
cause=read(old)
hidden=read(ROOT/'.scratch/mtp-fixed-hidden-output-20261025/capture-counts.json')
window_path=ROOT/'docs/evidence/performance/inference-current-window-2026-10-25.json'
window=read(window_path)
pattern=re.compile(r'^prepared T=(\d+) visible=(\d+) replay=(\w+) cold_batch_seconds=(\S+) capture_recorded=(\d+) capture_reused=(\d+)$')
current=[]
for item in window['processes']:
    if item['arm']!='hyle_mtp' or not item['window'].startswith('two-'):continue
    observation=Path(item['observation']['path'])
    stderr=observation.parent/'stderr.log'
    rows=[]
    for line in stderr.read_text().splitlines():
        if not line.startswith('prepared '):continue
        m=pattern.fullmatch(line);assert m,line
        t,visible,replay,_,record,reuse=m.groups()
        rows.append(dict(seq=len(rows)+1,T=int(t),visible=int(visible),replay=replay,recorded=int(record),reused=int(reuse)))
    assert rows==hidden['complete_sequences']['candidate'],stderr
    current.append(dict(window=item['window'],stderr=pin(stderr),rows=len(rows),recorded=sum(x['recorded'] for x in rows),reused=sum(x['reused'] for x in rows)))
assert len(current)==4

# Evaluate two one-sided state ideas against the same fully reconstructed
# original stream. Stop before the original script's save/print tail.
sim=ROOT/'.scratch/inference-mtp-state-io-offline-20261025/simulate.py'
ns={'__file__':str(sim),'__name__':'offline_reconstruction'}
exec(compile(sim.read_text().split('base = simulate({})')[0],str(sim),'exec'),ns)
simulate=ns['simulate'];manifest=ns['manifest'];groups=ns['groups']
def ports(roles):
    return {saved:{x['flat'] for x in manifest if x['saved']==saved and x['role'] in roles} for saved in groups}
carry={'carry_prefix_output'}
inputs={'history_snapshot_input','recurrent_snapshot_input'}
outputs={'history_prefix_output','recurrent_prefix_output'}
projected={}
for name,roles in [('original',set()),('hidden_output',carry),('hidden_plus_gdn_output',carry|outputs),
                   ('hidden_plus_gdn_input',carry|inputs),('hidden_plus_gdn_io',carry|inputs|outputs)]:
    result=simulate(ports(roles))
    assert result['status']=='EXACT_LOGGED_TUPLE_EQUALITY_SIMULATION'
    projected[name]=dict(records=result['records'],hits=result['hits'],
        record_set=[[x['seq'],x['range_begin']] for x in result['rows'] if not x['hit']],
        hard_clear_boundaries=sorted(set((x['seq'],x['range_begin']) for x in result['hard_clears'])))
assert projected['original']['records']==15 and projected['hidden_output']['records']==10
body=[]
remaining=set(tuple(x) for x in projected['hidden_output']['record_set'])
for x in cause['body_records']:
    a=x['closest_valid_variant']
    body.append(dict(seq=x['seq'],role=x['role'],old_context=x['context'],range_begin=x['range_begin'],
        old_reason=x['reason'],old_nearest_changed_classes=None if a is None else a['port_classes'],
        old_observed_window_ms=x['capture_through_native_API_end_ms'],
        inferred_survives_hidden_output=(x['seq'],x['range_begin']) in remaining))
save('facts.json',dict(status='OFFLINE_ONLY_NO_NEW_NATIVE_EXECUTION',inputs=[pin(old),pin(sim),pin(window_path),
    pin(ROOT/'.scratch/mtp-fixed-hidden-output-20261025/capture-counts.json')],current_two_turn_formatter=current,
    old_body_records=body,projected_old_stream=projected,
    old_observed_window_sums_ms={name:round(sum(x['capture_through_native_API_end_ms'] for x in cause['body_records']
        if (x['seq'],x['range_begin']) in set(tuple(p) for p in d['record_set'])),6) for name,d in projected.items()},
    qualification='Full bindings are historical. Current stdout/stderr corroborate only aggregate/per-call counters, not current body ranges or native plan reasons. Projected windows are old observed envelopes, not current avoidable wall time.'))
print(json.dumps(dict(current=current,projected=projected),indent=2))
