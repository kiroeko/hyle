"""Write the bounded source-only decision from the retained offline facts."""
from pathlib import Path
import hashlib
import json
ROOT=Path(__file__).resolve().parents[2]
WORK=Path(__file__).resolve().parent
def read(p):return json.loads(p.read_text())
def pin(p):
    b=p.read_bytes();return dict(path=p.relative_to(ROOT).as_posix(),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
facts=read(WORK/'facts.json')
source_names=['engine/models/qwen35/main.cc','engine/models/qwen35/session_state.h',
    'include/hyle/compute/resource_leases.h','include/hyle/compute/batch_transfer.h',
    'src/compute_provider_flashinfer/flashinfer_provider.cc','src/graph_batch/batch.cc']
source=[pin(ROOT/p) for p in source_names]
def line(path,needle):
    lines=(ROOT/path).read_text().splitlines()
    at=[i+1 for i,s in enumerate(lines) if needle in s]
    assert len(at)==1,(path,needle,at)
    return f'{path}:{at[0]}'
rows=[]
removed={13,14,15,16,41}
for r in facts['old_body_records']:
    seq=r['seq']
    why=('first role/bank variant' if seq in {2,3} else
         'native plan hardclear' if seq in {37,38,43} else
         'hidden output only' if seq in {13,14,15,41} else
         'indirect eviction caused by seq15 hidden key' if seq==16 else
         'second GDN input/output address combination in current native-plan epoch')
    rows.append(dict(seq=seq,role=r['role'],old_window_ms=r['old_observed_window_ms'],
        old_cause=why,after_hidden='removed/corroborated by formatter' if seq in removed else 'inferred remaining; no new full-key trace'))
S=18*(36864+1048576)
memo=dict(status='BOUNDED_OFFLINE_REVIEW_COMPLETE_NO_NEW_LOW_COST_STATE_ADDRESS_CANDIDATE',date='2026-10-26',
    strongest_fact='After already-fixed hidden OUTPUT, fixing only GDN OUTPUT or only GDN INPUT leaves the exact historical body record set unchanged at10. Both sides must be stable to reach5. Do not extend the small hidden-output copy to GDN outputs and claim another5 fewer records.',
    current=dict(observed='All four final-canonical two-turn MTP stderr streams exactly match the screened candidate per-call sequence:68 prepared calls,132 range decisions,27record/105reuse.',
        limitation='These formatter counters do not name subranges or native invalidation reasons. 10 body+17 front records is the corroborated old-key interpretation, not a fresh current BIND measurement.',
        inputs=facts['current_two_turn_formatter']),
    old_fifteen=rows,
    residual_epochs=[dict(role=3,range_begin=57,records_before_clear=[2,8],records_after_clear=[37,39]),
        dict(role=4,range_begin=55,records_before_clear=[3,4],records_after_first_clear=[38,40],records_after_second_clear=[43,44])],
    interpretation='Each residual epoch needs its first variant and a second physically different GDN input/output tuple. Once hidden output is removed there is no third-tuple eviction in this historical stream. A larger variant cache cannot eliminate a first-seen second tuple, and invalidated native plans cannot remain launchable.',
    old_observed_windows_ms=dict(all15=78.431404,hidden_removed5=19.474001,residual10=58.957403,
        first2=18.186282,native_hardclear3=11.597198,second_address_fills5=29.173923,
        meaning='Historical capture-begin through native Instantiate/ExecUpdate-end envelopes aligned by original record order/range. They include recording/API and intervening work, are not pure CPU self time, and are neither current costs nor current recoverable ceilings.'),
    native_plan=dict(direct='Original seq37/38/43 each logged NativeArguments invalidation at six target attention steps. Both lookup keys were correctly discarded while retaining a nonlaunchable native seed.',
        predicate='Separate same-work provider diagnostic directly correlates seq37 chunks2->3 (128-row chunks, CTA16, pages13->24). seq38 chunks2->3 and seq43 chunks3->4 are source/layout inference; their specific return predicates were not logged in the full-key trace.',
        required='can_reuse_batch_plan checks per-request chunks at the original CTA/chunk. More float/int workspace alone cannot preserve changed tile/merge offsets or launch structure. Do not delete the gate, keep stale keys, or reopen fixed512. No new erroneous invalidation was established.'),
    minimum_legal_but_already_known_two_way_staging=dict(scope='Natural K1, actual caller-owned history/recurrent ports, selected prefix known before complete Snapshot publication; no new public API/executor/manager.',
        mechanism='Cold-prepare distinct full-block input and each chronological output scratch at the actual dtype/resource per slot. Copy old Snapshot state to fixed ingress and wait its actual Completion; publish/bind readonly scratch lease. Graph writes original leased outputs and actually retires. After selection copy the chosen complete boundary into pre-admitted original canonical state-pool writers, wait real copy retirement, then publish original head/ledger. Unbind all original Graph/copy aliases before unique writer recovery. No escaping Snapshot may retain scratch.',
        failure='Both copy Completions must retain the original ColdResources/Backend via existing retirement_sources+RetainedResources, independently of Graph retirement. Pending/unknown copy blocks reuse; no head/RNG/ledger publication. Native-generated output or arbitrary escaping precommit prefix readers must retain the original path.',
        added_GDN_copy_bytes_per_body=2*S,added_GDN_copy_MiB_per_body=2*S/2**20,
        ingress_bytes=S,selected_egress_bytes=S,logical_ranges=72,
        added_payload_for66_body_decisions=66*2*S,
        fixed_GDN_payload_two_roles_two_prefixes=6*S,fixed_GDN_payload_MiB=6*S/2**20,
        logged_changed_port_lower_bound_two_roles=5*S,
        independent_both_prefix_egress_if_required=2*S,
        independent_both_prefix_total_copy=3*S,
        accounting='Costs above are GDN-only increments; current hidden4/8KiB copy is already paid and is not counted again. Full two-prefix scratch for both logged roles is111.796875MiB, not the93.1640625MiB changing-port lower bound. Actual compiled output ownership may reduce it. Pool alignment, control/metadata and native costs are extra. Keep original cache N+2R slots/local caps; new scratch and Copy control must pass existing execution/shared scope admission. No capacity increase or forced offset is proposed.'),
    decision='Close one-sided GDN output/input candidates: zero extra record reduction in the exact old stream. The only currently expressible address stabilization is the already-known, much larger two-way materialization with two real copy retirement boundaries; this review supplies no new cheap mechanism or demonstrated gain to justify implementing it. Retain correct native invalidations. No new experiment is requested.',
    anchors=[line(source_names[0],'const auto bind_state ='),line(source_names[0],'void copy_selected_hidden_outputs('),
        line(source_names[0],'step.members[j].next->state[i].history = retain_state_storage'),
        line(source_names[0],'HYLE_FATAL_ASSERT(copy.retirement.attach(*original[0]).ok())'),
        line(source_names[1],'const auto states = add(residents, multiply(candidate_boundaries, active_sequences))'),
        line(source_names[4],'bool can_reuse_batch_plan('),line(source_names[2],'Result<WriteLease> allocate(')],
    source_pins=source,offline_facts=pin(WORK/'facts.json'),new_build_model_GPU_HTTP=0)
# The exact stderr pins and verbose per-record facts remain in facts.json;
# keep the decision memo small and directly scannable.
memo['current'].pop('inputs')
labels={'first role/bank variant':'first','native plan hardclear':'native',
    'hidden output only':'hidden','indirect eviction caused by seq15 hidden key':'indirect-hidden',
    'second GDN input/output address combination in current native-plan epoch':'GDN-second'}
memo['old_fifteen']={'columns':['seq','role','cause','old_window_ms','removed_by_hidden'],
    'rows':[[r['seq'],r['role'],labels[r['old_cause']],r['old_window_ms'],r['seq'] in removed] for r in rows]}
(WORK/'memo.json').write_text(json.dumps(memo,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(memo=pin(WORK/'memo.json'),facts=pin(WORK/'facts.json')),indent=2))
