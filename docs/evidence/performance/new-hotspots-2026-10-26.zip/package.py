"""Publish one compact offline/new-diagnostic evidence bundle, no binaries."""
from pathlib import Path
import hashlib
import json
import zipfile

ROOT = Path.cwd()
WORK = Path(__file__).resolve().parent
D = WORK / 'diagnostic'
A = D / 'attempt1'
PUBLIC = ROOT / 'docs/evidence/performance'
NAME = 'new-hotspots-2026-10-26'
REPORT, ZIP = PUBLIC / (NAME + '.json'), PUBLIC / (NAME + '.zip')
assert not REPORT.exists() and not ZIP.exists(), 'Do not overwrite published proof'


def read(path):
    return json.loads(path.read_bytes())


def pin(path):
    data = path.read_bytes()
    return {'path': path.relative_to(ROOT).as_posix(), 'bytes': len(data),
            'sha256': hashlib.sha256(data).hexdigest()}


files = []


def include(path, member):
    path = ROOT / path if not Path(path).is_absolute() else Path(path)
    assert path.suffix.lower() not in ['.exe', '.obj', '.dll', '.lib', '.pdb', '.exp', '.sqlite', '.nsys-rep']
    assert not any(item['member'] == member for item in files)
    files.append({'source': pin(path), 'member': member})


for name in ['analyze.py', 'facts.json', 'memo.json', 'summarize_diagnostic.py',
             'current-diagnostic-memo.json']:
    include(WORK / name, 'capture-cost/' + name)
for name in ['source.patch', 'source-pins.json', 'plan.json', 'dependency-plan.json',
             'check.py', 'independent-review-architecture.json', 'review-architecture.py']:
    include(D / name, 'diagnostic/' + name)
for path in sorted((D / 'include-freeze').rglob('*.h')):
    include(path, 'diagnostic/include-freeze/' + path.relative_to(D / 'include-freeze').as_posix())
for path in sorted(D.glob('old-to-current-*.patch')):
    include(path, 'diagnostic/' + path.name)
for name in ['plan.json', 'first-postcompile-check-failure.json', 'ready.json',
             'link-inputs.json', 'runtime.json', 'run-plan.json']:
    include(A / name, 'diagnostic/attempt1/' + name)
for part in ['provider', 'link', 'run']:
    for name in ['command.json', 'process.json', 'stdout.log', 'stderr.log']:
        include(A / part / name, 'diagnostic/attempt1/' + part + '/' + name)
for name in ['actual-dependencies.json', 'dependency-check.json']:
    include(A / 'provider' / name, 'diagnostic/attempt1/provider/' + name)
include(A / 'run/nontime-differences.json', 'diagnostic/attempt1/run/nontime-differences.json')
old = ROOT / '.scratch/mtp-packed-head-20261024/orin-proposal/mmq-query-proposal/compile2/provider'
for name in ['identity.json', 'compile.command.json', 'provider-deps.json']:
    include(old / name, 'baseline-provider/' + name)
base = ROOT / '.scratch/inference-synchronous-step-report-20261025/cuda'
for name in ['ready.json', 'link-inputs.json', 'link/command.json']:
    include(base / name, 'baseline703/' + name)
residual = ROOT / '.scratch/mtp-residual-body-review-20261026'
for name in ['memo.json', 'facts.json', 'analyze.py', 'write_memo.py']:
    include(residual / name, 'residual-address/' + name)
include(ROOT / '.scratch/inference-foundation-inventory-20261025/trtllm-decode-inspiration.json',
        'reference/trtllm-decode-inspiration.json')
include(Path(__file__).resolve(), 'package.py')

old_memo = read(WORK / 'memo.json')
current = read(WORK / 'current-diagnostic-memo.json')
ready = read(A / 'ready.json')
baseline_folder = ROOT / '.scratch/inference-synchronous-step-report-20261025/screen/timing-02-candidate'
baseline_archive = ROOT / 'docs/evidence/performance/inference-synchronous-step-report-2026-10-26.zip'
baseline_members = []
with zipfile.ZipFile(baseline_archive) as z:
    for name in ['stdout.log', 'stderr.log', 'command.json']:
        member = 'screen/timing-02-candidate/' + name
        actual = z.read(member)
        assert actual == (baseline_folder / name).read_bytes()
        baseline_members.append({'member': member, 'bytes': len(actual),
            'sha256': hashlib.sha256(actual).hexdigest()})
linked_data = read(A / 'link-inputs.json')
assert len(linked_data) == 221 and ready['total_inputs'] == 234 and ready['unchanged_inputs'] == 233
assert read(A / 'run/nontime-differences.json') == []
assert current['complete'] == {'attempted': 4446, 'stored': 4446,
    'finished': 4446, 'overflow': 0, 'process_exit_dump': 1}
assert current['process']['exit'] == 0

report = {'schema': 'hyle-performance-evidence-v1',
    'status': 'BOUNDED_ATTRIBUTION_COMPLETE_NO_OPTIMIZATION_OR_TPS_CLAIM',
    'date': '2026-10-26',
    'scope': 'Old paired logical CUDA traces plus one new capture-only provider CPU-timing diagnostic in a pinned incremental703 closure; residual-address source review and previously pinned TRT inspiration. No new profiler, peer run, full throughput window or product change.',
    'next_action': 'Deprioritize surgery on provider binding/query/safety scopes: their three non-bridge buckets total2.1209ms in this complete run. First make the current host-source closure dependency-consistent. If cold preparation then still needs localization, examine the existing replay/native capture-end preparation outside provider; do not infer Graph CPU or implement broader region fusion from an API-uncovered interval.',
    'old_paired_profile': {
        'provenance': 'Original32Hyle/7peer capture trace, before seed/hidden-output/report changes; no use as current27-capture timing.',
        'capture_definition': old_memo['definitions'], 'counts': old_memo['record_counts'],
        'per_capture_mean_ms': {
            'Hyle_body15': {'wall': 3.6925999333333333, 'visible_API_union': 1.2339578, 'API_uncovered': 2.4586421333333335},
            'Hyle_body_without_first14': {'wall': 3.4890735714285714, 'visible_API_union': 1.1646022857142857, 'API_uncovered': 2.324471285714286},
            'peer_target2': {'wall': 2.250114, 'visible_API_union': 1.1895575, 'API_uncovered': 1.0605565}},
        'visible_native_surface': old_memo['secondary_observation'],
        'interpretation': 'Recording frequency and per-record wall both differed, but most per-record difference was outside visible CUDA APIs. No explicit cuBLAS/driver table was present.406 native provider invocations are not406 kernels; no capture-local allocation/event/synchronization storm was observed.',
        'no_current_recoverable_ms': True},
    'one_direct_diagnostic': {
        'image': ready['image'], 'source': ready['source'], 'source_pins': ready['source_pins'],
        'actual_compile': ready['processes']['provider'], 'actual_link': ready['processes']['link'],
        'actual_run': current['process'], 'complete': current['complete'],
        'actual_Event_bytes': 96, 'capacity': 32768, 'fixed_event_array_bytes': 3145728,
        'event_recording': 'Capture-only steady_clock, no hot allocation/IO. Five ticks form four disjoint per-invocation intervals; normal-exit fixed scalar dump. All4446 seen31/terminal_ok1, monotonic nonoverlapping events.',
        'four_buckets': current['four_provider_buckets'],
        'provider_total_ms': current['provider_total_ms'],
        'prepared_groups': current['prepared_groups'],
        'same_run_nested_scope': current['same_run_nested_scope'],
        'node_count_distribution': [{'recipe_nodes': row['recipe_nodes'], 'events': row['events'], 'bridge_total_ms': row['bridge_ms']['total']} for row in current['node_groups']],
        'largest_bridge_event': {'ordinal': 38, 'bridge_ms': 2.0222, 'recipe_nodes': 3,
            'inputs': 6, 'outputs': 2, 'operation_or_cause': None},
        'work_gate': {'full_recursive_non_time_JSON_differences': 0,
            'stderr_equal_after_only_clock_values_and_appended_diagnostic_removed': True,
            'prepared': 68, 'decode_episodes': 66, 'capture_recorded': 27, 'capture_reused': 105,
            'stdout_full_report_retained': True, 'raw_stderr_not_truncated': True,
            'baseline_archive': pin(baseline_archive), 'baseline_members': baseline_members},
        'first_failure': {'kind': 'postcompile harness validation, not product/compiler/model failure',
            'compiler_had_exit0': True,
            'reason': 'Additional chrono/UCRT ctype.h was rejected by an over-narrow MSVC-only standard-header check.',
            'correction': 'Allow only the already-pinned original UCRT directory plus same MSVC includes for extra standard headers; preserve exact original209 dependency subset. Reused same successful OBJ, no repeated compile.'},
        'dependency_contract': {'original_dependencies': 209, 'exact_current_original': 204,
            'exact_restored_original_project_headers': 5, 'additional_same_toolchain_standard_headers': 45,
            'actual_dependencies': 254, 'total_link_inputs': 234, 'changed_inputs': 1,
            'unchanged_inputs': 233, 'app_core_native_CUDA_SDK_rebuilds': 0,
            'not_current_whole_image_certification': True,
            'note': 'The five headers have real later semantic/declaration differences; the instrumented provider deliberately uses its original dependency versions. be3/703 incremental cached objects must not be described as every TU compiled against current canonical.'}},
    'residual_state_address_review': {
        'classification': 'Offline historical full-key reconstruction, not fresh current BIND measurement',
        'after_already_merged_hidden_output': 'Old body15->10 interpretation:2first+3native hardclear+5second-address fills. Larger cache adds no hits. Fixing GDN INPUT alone or OUTPUT alone still leaves10; both sides stable yields5 in that old stream.',
        'cost_of_known_two_way_staging': {'extra_GDN_copy_bytes_per_body': 39075840,
            'extra_MiB_per_body': 37.265625, 'two_roles_two_prefix_fixed_scratch_MiB': 111.796875,
            'actual_copy_retirement_boundaries': 2},
        'decision': 'No newly justified cheap address-stabilization candidate. Preserve native invalidation and immutable old-reader/accept-prefix/real-retirement contracts; do not extend the small hidden-output copy one-sidedly.'},
    'TRT_reference': {'HEAD': '46d9966b54d9d11998b712e732fb20f64d4d35c0',
        'scope': 'Previously fixed local source review, no new TRT execution or speed comparison',
        'conditional_questions': ['device token dependency versus delayed host observation, retaining original unpublished/commit boundaries',
                                  'upload fence tied to actual immutable source reuse, without weakening mutable-take/ready/native-plan retirement'],
        'limits': 'Non-owning reused outputs are not Hyle immutable Snapshots. Inspected deferred decode-output implementation was CSA2-only, not general dense Qwen/K1. No new executor, megakernel or scope removal follows.'},
    'limits': current['limits'] + [
        'Old paired15body with Nsight and this new27capture direct process differ in recording count, code closure, profiling overhead and timing clock; do not subtract their totals or multiply old per-record wall by current counts.',
        'The49.0787ms same-run outside-provider remainder is only a nested aggregate, not pure Graph CPU, Inst/Update attribution, an optimization budget or predicted gain.',
        'Source/route evidence alone does not authorize merging preferred leaves, skipping permission checks or deleting native retirement/query gates.'
    ],
    'existing_evidence': [pin(ROOT / 'docs/evidence/performance' / name) for name in [
        'mtp-logical-call-attribution-2026-10-25.json',
        'mtp-body-recapture-cause-2026-10-25.json',
        'inference-synchronous-step-report-2026-10-26.json']],
    'archive': None}
manifest = {'schema': 'hyle-evidence-members-v1', 'files': files,
            'excluded': 'OBJ/EXE/DLL/LIB/PDB, SDK/model payload, full frozen source/dependency trees, large SQLite/nsys copies, duplicate baseline raw already in cited report ZIP'}
with zipfile.ZipFile(ZIP, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for item in files:
        z.write(ROOT / item['source']['path'], item['member'])
    z.writestr('manifest.json', json.dumps(manifest, indent=2) + '\n')
with zipfile.ZipFile(ZIP) as z:
    assert z.testzip() is None
    assert len(z.namelist()) == len(files) + 1
    for item in files:
        data = z.read(item['member'])
        assert len(data) == item['source']['bytes']
        assert hashlib.sha256(data).hexdigest() == item['source']['sha256']
report['archive'] = {**pin(ZIP), 'members': len(files) + 1,
                     'CRC': 'PASS', 'all_content_member_SHA256': 'PASS'}
REPORT.write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
receipt = {'report': pin(REPORT), 'archive': pin(ZIP), 'members': len(files) + 1,
           'CRC': 'PASS', 'all_member_hashes': 'PASS', 'forbidden_binary_or_payload_members': 0}
(WORK / 'package-check.json').write_text(json.dumps(receipt, indent=2) + '\n', encoding='utf-8')
print(json.dumps(receipt, indent=2))
