"""Prepare or run the two finite driver checks. Only root executes `run`.

plan/analyze are host-only. Single-round requires original64 byte identity;
short-prefix records actual chunk-vs-sequential numerical differences.
"""
from pathlib import Path
import argparse
import array
import math
import os
import re
import struct
import sys
sys.dont_write_bytecode = True
import multiturn_run as m

S = Path(__file__).resolve().parent
F = S.parent
BASE = F / 'native-fix/validation/correctness'


def inputs():
    plan = m.prepare_inputs()['plans']['short']
    folder = S / 'inputs/single'
    folder.mkdir(parents=True, exist_ok=True)
    m.write_once(folder / 'prompt128.ids', ' '.join(map(str, plan['phases'][0]['ids'])) + '\n')
    hc, _ = m.original_commands()
    tape = list(map(int, Path(hc[hc.index('--decode-ids') + 1]).read_text().split()))
    m.write_once(folder / 'decode31.ids', ' '.join(map(str, tape)) + '\n')
    m.write_once(folder / 'schedule.txt', 'prompt prompt128.ids\ndecode decode31.ids\n')
    flat39 = [value for phase in plan['phases'][1:] for value in phase['ids']]
    assert len(flat39) == 39
    flat_path = S / 'inputs/short/flattened39.ids'
    m.write_once(flat_path, ' '.join(map(str, flat39)) + '\n')
    return dict(single_schedule=m.identity(folder / 'schedule.txt'),
                short_schedule=plan['manifest'], flat39=m.identity(flat_path))


def make_plan(ready, check, out):
    prepared = inputs()
    image = m.ready_image(ready)
    hc, _ = m.original_commands()
    common = ['--inputs', hc[hc.index('--inputs') + 1], '--capacity', '256', '--progress', 'direct']
    first = out / 'schedule'
    schedule = prepared['single_schedule' if check == 'single' else 'short_schedule']['path']
    commands = [dict(arm='schedule', folder=str(first), command=[image['path'], *common,
        '--schedule', schedule, '--replay', 'auto', '--trace', str(first / 'trace'), '--trace-level', 'decisions'])]
    if check == 'short-prefix':
        old = m.read(BASE / 'qwen.command.json')['image']
        assert m.identity(old['path']) == old, 'Original f85 baseline must retain exact image bytes'
        second = out / 'legacy'
        commands.append(dict(arm='legacy', folder=str(second), command=[old['path'], *common,
            '--decode-ids', prepared['flat39']['path'], '--steps', '40', '--replay', 'auto',
            '--trace', str(second / 'trace'), '--trace-level', 'decisions']))
    return dict(check=check, commands=commands, ready_receipt=m.identity(ready), inputs=prepared,
        original64_summary=m.identity(BASE / 'summary.json'), builds=0, profiler=False,
        memory_monitor=False, throughput_evidence=False,
        required_visible_prefixes=[128, *range(129, 137), 152, *range(153, 168)] if check == 'short-prefix' else list(range(128, 160)))


def vectors(folder):
    return {p.relative_to(folder).as_posix(): p for p in folder.rglob('*') if p.suffix in ('.f32', '.bf16')}


def decode(data, suffix):
    if suffix == '.f32':
        result = array.array('f')
        result.frombytes(data)
        return result
    return [struct.unpack('<f', struct.pack('<I', code << 16))[0] for (code,) in struct.iter_unpack('<H', data)]


def difference(actual, reference):
    ai, ri = m.identity(actual), m.identity(reference)
    assert ai['bytes'] == ri['bytes']
    equal = ai['sha256'] == ri['sha256']
    result = dict(actual=ai, reference=ri, byte_equal=equal)
    if equal:
        result['different_elements'] = 0
        return result
    a, b = decode(actual.read_bytes(), actual.suffix), decode(reference.read_bytes(), reference.suffix)
    finite, class_mismatch, first = [], 0, []
    count = 0
    for i, (x, y) in enumerate(zip(a, b)):
        if x != y or (x == 0 and math.copysign(1, x) != math.copysign(1, y)):
            count += 1
            if len(first) < 8:
                first.append(dict(index=i, actual=x if math.isfinite(x) else str(x),
                                  reference=y if math.isfinite(y) else str(y)))
        if math.isfinite(x) and math.isfinite(y):
            finite.append((x, y))
        elif (math.isnan(x), math.isinf(x), math.copysign(1, x)) != (math.isnan(y), math.isinf(y), math.copysign(1, y)):
            class_mismatch += 1
    squared = math.fsum((x - y) ** 2 for x, y in finite)
    ref_squared = math.fsum(y ** 2 for _, y in finite)
    result.update(different_elements=count, nonfinite_class_or_sign_mismatch=class_mismatch,
        finite_max_abs=max((abs(x - y) for x, y in finite), default=None),
        finite_relative_l2=math.sqrt(squared / ref_squared) if ref_squared else (0.0 if squared == 0 else None),
        finite_l2=math.sqrt(squared), first_differences=first)
    return result


def analyze(out, check):
    actual = vectors(out / 'schedule/trace')
    if check == 'single':
        original = m.read(BASE / 'summary.json')
        expected = {x['name']: x['actual'] for x in original['vectors']}
        comparisons = []
        for name, path in sorted(actual.items()):
            mapped = re.sub(r'^round1_', '', name)
            entry = expected[mapped]
            ident = m.identity(path)
            comparisons.append(dict(name=name, original_name=mapped, actual=ident, reference=entry,
                byte_equal=(ident['bytes'], ident['sha256']) == (entry['bytes'], entry['sha256'])))
        stdout = (out / 'schedule/stdout.log').read_text(encoding='utf-8').splitlines()
        raw = m.json.loads(next(line for line in reversed(stdout) if line.startswith('{')))
        same_predictions = raw['generated_ids'] == original['observation']['raw']['generated_ids']
        passed = len(comparisons) == len(expected) == 64 and all(x['byte_equal'] for x in comparisons) and same_predictions
        result = dict(check=check, passed=passed, vector_count=len(comparisons), vectors=comparisons,
            same_predictions=same_predictions,
            throughput_evidence=False, original_summary=m.identity(BASE / 'summary.json'))
    else:
        legacy = vectors(out / 'legacy/trace')
        comparisons = []
        for name, path in sorted(actual.items()):
            phase, filename = name.split('/', 1)
            if phase == 'round1_prefill':
                old_phase, visible = 'prefill', 128
            elif phase.startswith('round1_decode'):
                idx = int(phase[len('round1_decode'):])
                old_phase, visible = 'decode' + str(idx), 128 + idx
            elif phase == 'round2_prefill':
                old_phase, visible = 'decode24', 152
            else:
                idx = int(phase[len('round2_decode'):])
                old_phase, visible = 'decode' + str(24 + idx), 152 + idx
            comparisons.append(dict(name=name, visible_tokens=visible,
                original_name=old_phase + '/' + filename,
                **difference(path, legacy[old_phase + '/' + filename])))
        assert len(comparisons) == 50, len(comparisons)
        new_steps = m.parse_steps((out / 'schedule/stderr.log').read_text(encoding='utf-8'))
        old_steps = []
        for line in (out / 'legacy/stderr.log').read_text(encoding='utf-8').splitlines():
            if re.match(r'^(prefill|decode\d+) tokens=', line):
                fields = dict(re.findall(r'(\w+)=([^\s]+)', line))
                old_steps.append(dict(visible_tokens=int(fields['visible']), predicted_id=int(fields['next'])))
        by_visible = {x['visible_tokens']: x['predicted_id'] for x in old_steps}
        endpoints = [dict(visible_tokens=x['visible_tokens'], schedule_id=x['predicted_id'],
            legacy_id=by_visible[x['visible_tokens']], equal=x['predicted_id'] == by_visible[x['visible_tokens']]) for x in new_steps]
        assert len(endpoints) == 25
        result = dict(check=check, completed=True, endpoints=endpoints,
            all_predictions_equal=all(x['equal'] for x in endpoints),
            all_vectors_byte_equal=all(x['byte_equal'] for x in comparisons), vectors=comparisons,
            byte_different_vectors=sum(not x['byte_equal'] for x in comparisons),
            policy='Record exact differences; chunk-vs-sequential arithmetic is not assumed bit identical.',
            numerical_tolerance_acceptance=None, throughput_evidence=False)
    m.save(out / 'summary.json', result)
    if check == 'single' and not result['passed']:
        raise RuntimeError('Single-round schedule failed original64 byte identity; source logs retained')
    return result


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('action', choices=['plan', 'run', 'analyze'])
    ap.add_argument('--check', choices=['single', 'short-prefix'], default='single')
    ap.add_argument('--hyle-ready', type=Path, default=S / 'hyle/ready-for-root.json')
    ap.add_argument('--output', type=Path)
    args = ap.parse_args()
    out = (args.output or S / 'validation' / args.check / 'attempt1').resolve()
    if args.action == 'analyze':
        result = analyze(out, args.check)
        print(m.json.dumps({key: value for key, value in result.items() if key not in ('vectors', 'endpoints')}, indent=2))
        return
    plan = make_plan(args.hyle_ready, args.check, out)
    if args.action == 'plan':
        print(m.json.dumps(plan, indent=2))
        return
    out.mkdir(parents=True, exist_ok=False)
    m.save(out / 'inputs.json', plan)
    runtime = m.read(args.hyle_ready).get('runtime_environment', m.ENVIRONMENT)
    runtime = Path(runtime['path'] if isinstance(runtime, dict) else runtime)
    env = os.environ.copy()
    env['PATH'] = m.read(runtime)['PATH']
    for item in plan['commands']:
        m.execute(Path(item['folder']), item['arm'], item['command'], env, False)
    result = analyze(out, args.check)
    print(m.json.dumps({key: value for key, value in result.items() if key not in ('vectors', 'endpoints')}, indent=2))


if __name__ == '__main__':
    main()
