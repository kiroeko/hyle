"""One current FI host TU and the existing diagnostic190-input link."""
from pathlib import Path
import importlib.util
import os
import sys

sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
F = S.parent
D = F.parent
R = next(p for p in S.parents if (p / 'AGENTS.md').is_file() and (p / 'src').is_dir())
spec = importlib.util.spec_from_file_location('facts_original_build_helpers', D / 'build.py')
h = importlib.util.module_from_spec(spec)
spec.loader.exec_module(h)
b, c = h.b, h.c

def same(row):
    return all(b.identity(row['path'])[k] == row[k] for k in ('bytes', 'sha256'))

def main():
    out = S / 'checks/attempt1'
    out.mkdir(parents=True, exist_ok=False)
    (out / 'tmp').mkdir()
    recipe_path = R / '.scratch/architecture-refactor-2026-10-18/compact-mla-e4-reference/cuda/checks/attempt1/host-provider/identity.json'
    recipe = c.read(recipe_path)
    provider = R / 'src/compute_provider_flashinfer/flashinfer_provider.cc'
    frozen = b.identity(provider)
    diagnostic_ready_path = F / 'layout-preparation-diagnostic-2026-10-21/ready-for-root.json'
    diagnostic_ready = c.read(diagnostic_ready_path)
    source, header = diagnostic_ready['source'], diagnostic_ready['header']
    assert same(source) and same(header)
    command = b.host_command(recipe['command'], provider, 'provider', out)
    assert all(flag in command for flag in ('/WX', '/W4', '/MD', '/O2'))
    c.save(out / 'compile-plan.json', dict(command=command, provider_source=frozen,
        recipe=b.identity(recipe_path), CXX=1, SDK_builds=0, GPU_runs=0))
    env, _ = b.environment(command, [], out)
    c.execute('compile', command, env, out)
    deps = c.read(out / 'provider-deps.json')['Data']
    dependencies = [b.identity(p) for p in dict.fromkeys([deps['Source'], *deps['Includes']])]
    assert same(frozen) and all(same(row) for row in dependencies)
    obj = b.identity(out / 'provider.obj')
    c.save(out / 'identity.json', dict(command=command, provider_source=frozen, object=obj,
        dependencies=dependencies, replaced_object=recipe['object'], CXX=1,
        SDK_builds=0, GPU_runs=0))
    snap = out / 'source/src/compute_provider_flashinfer/flashinfer_provider.cc'
    snap.parent.mkdir(parents=True, exist_ok=True)
    snap.write_bytes(provider.read_bytes())
    base_path = Path(diagnostic_ready['link_plan']['path'])
    base = c.read(base_path)
    assert len(base['inputs']) == 190 and all(same(row) for row in base['inputs'])
    old = c.key(recipe['object']['path'])
    assert sum(c.key(row['path']) == old for row in base['inputs']) == 1
    inputs = [obj if c.key(row['path']) == old else row for row in base['inputs']]
    image = out / 'qwen.exe'
    link = [obj['path'] if c.key(arg) == old else arg for arg in base['command']
        if not arg.upper().startswith(('/OUT:', '/MAP:', '/IMPLIB:', '/PDB:'))]
    link += ['/OUT:' + str(image), '/MAP:' + str(image.with_suffix('.map')),
             '/IMPLIB:' + str(image.with_suffix('.lib'))]
    c.save(out / 'link-plan.json', dict(command=link, inputs=inputs, base=b.identity(base_path),
        source=source, provider_source=frozen, header=header,
        CXX=1, links=1, NVCC=0, SDK_builds=0, GPU_runs=0))
    env, runtime = b.environment(link, [row['path'] for row in inputs], out)
    c.execute('link', link, env, out)
    original = next(Path(diagnostic_ready['image']['path']).parent.glob('hyle_ggml_cpu_avx2_*.dll'))
    target = out / original.name
    os.link(original, target)
    assert os.path.samefile(original, target)
    c.save(out / 'runtime-environment.json', dict(PATH=env['PATH'], runtime=runtime,
        staged_CPU_modules=[dict(source=b.identity(original), destination=b.identity(target), hardlink=True)]))
    assert same(source) and same(header) and same(frozen) and all(same(row) for row in inputs)
    c.save(S / 'ready-for-root.json', dict(image=b.identity(image), source=source,
        provider_source=frozen, header=header, link_plan=b.identity(out / 'link-plan.json'),
        runtime_environment=b.identity(out / 'runtime-environment.json'),
        baseline_diagnostic=b.identity(diagnostic_ready_path),
        CXX=1, links=1, NVCC=0, SDK_builds=0, GPU_runs=0))
    print('FACTS_CANDIDATE_READY', str(image), flush=True)

if __name__ == '__main__':
    main()
