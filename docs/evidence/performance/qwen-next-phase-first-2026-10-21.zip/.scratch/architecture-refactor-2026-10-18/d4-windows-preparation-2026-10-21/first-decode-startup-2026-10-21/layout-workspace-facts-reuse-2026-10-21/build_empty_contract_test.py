"""One corrected original empty-case TU; same current193-input link, no GPU execution."""
from pathlib import Path
import importlib.util, os, sys
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location("empty_current_build_helpers",S/"build.py")
h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
b,c,R,F,D=h.b,h.c,h.R,h.F,h.D

def main():
    source=R/"tests/compute_provider_flashinfer/native_cache_test.cc"
    frozen=b.identity(source)
    assert frozen["sha256"]=="93b028d78b8b0a86cc7eb4183b565966e1894f7d8d2d2f6c5b517221dba0bc78"
    recipe_path=S/"tests/attempt2/native-cache-test/identity.json";recipe=c.read(recipe_path)
    out=S/"tests/attempt3/native-cache-test";out.mkdir(parents=True,exist_ok=False);(out/"tmp").mkdir()
    command=b.host_command(recipe["command"],source,"native-cache-test",out)
    assert all(x in command for x in ("/W4","/WX","/MD","/O2","/DHYLE_STATIC","/DHYLE_COMPUTE_FLASHINFER=1"))
    c.save(out/"compile-plan.json",dict(command=command,source=frozen,recipe=b.identity(recipe_path),changes="Only source/out and deps paths; same strict native-cache target recipe and real FI PUBLIC definition.",CXX=1,NVCC=0,SDK_builds=0,GPU_runs=0))
    env,_=b.environment(command,[],out);c.execute("compile",command,env,out)
    deps_path=out/"native-cache-test-deps.json";deps=c.read(deps_path)["Data"]
    dependencies=[b.identity(p) for p in dict.fromkeys([deps["Source"],*deps["Includes"]])]
    assert h.same(frozen) and all(h.same(x) for x in dependencies)
    obj=b.identity(out/"native-cache-test.obj")
    identity=dict(source=frozen,object=obj,command=command,dependencies=dependencies,source_dependencies=b.identity(deps_path),recipe=b.identity(recipe_path),replaced_object=recipe["object"],CXX=1,GPU_runs=0)
    c.save(out/"identity.json",identity)
    snap=out/"source/tests/compute_provider_flashinfer/native_cache_test.cc";snap.parent.mkdir(parents=True);snap.write_bytes(source.read_bytes())
    base_path=S/"tests/attempt2/link/link-plan.json";base=c.read(base_path)
    assert len(base["inputs"])==193 and all(h.same(x) for x in base["inputs"])
    old=c.key(recipe["object"]["path"]);assert sum(c.key(x["path"])==old for x in base["inputs"])==1
    inputs=[obj if c.key(x["path"])==old else x for x in base["inputs"]]
    ragged_path=S/"tests/attempt2/ragged-mla-test/identity.json";ragged=c.read(ragged_path)
    assert sum(c.key(x["path"])==c.key(ragged["object"]["path"]) for x in inputs)==1 and h.same(ragged["object"])
    linkout=S/"tests/attempt3/link";linkout.mkdir(parents=True,exist_ok=False);(linkout/"tmp").mkdir()
    image=linkout/"flashinfer-native-cache-tests.exe"
    link=[obj["path"] if c.key(x)==old else x for x in base["command"] if not x.upper().startswith(("/OUT:","/MAP:","/IMPLIB:","/PDB:"))]
    link += ["/OUT:"+str(image),"/MAP:"+str(image.with_suffix(".map")),"/IMPLIB:"+str(image.with_suffix(".lib"))]
    c.save(linkout/"link-plan.json",dict(command=link,inputs=inputs,base=b.identity(base_path),fresh_test_identity=b.identity(out/"identity.json"),reused_ragged_identity=b.identity(ragged_path),CXX=1,links=1,NVCC=0,SDK_builds=0,GPU_runs=0))
    env,runtime=b.environment(link,[x["path"] for x in inputs],linkout);c.execute("link",link,env,linkout)
    staged=[]
    for row in c.read(S/"tests/attempt2/link/runtime-environment.json")["staged_CPU_modules"]:
        original=Path(row["destination"]["path"]);assert h.same(row["destination"])
        target=linkout/original.name;os.link(original,target);assert os.path.samefile(original,target)
        staged.append(dict(source=b.identity(original),destination=b.identity(target),hardlink=True))
    c.save(linkout/"runtime-environment.json",dict(PATH=env["PATH"],runtime=runtime,staged_CPU_modules=staged))
    provider_source=c.read(S/"ready-for-root.json")["provider_source"]
    assert h.same(provider_source) and all(h.same(x) for x in inputs) and all(h.same(x) for x in dependencies)
    test="FlashinferCache.EmptyRequestsAndAllZeroQueriesUseCheckedNoOp"
    c.save(S/"empty-contract-tests-ready-for-root.json",dict(status="corrected_original_empty_case_built_not_run",image=b.identity(image),source=frozen,provider_source=provider_source,identity=b.identity(out/"identity.json"),link_plan=b.identity(linkout/"link-plan.json"),runtime_environment=b.identity(linkout/"runtime-environment.json"),suggested_command=[str(image),"--gtest_filter="+test,"--gtest_output=xml:tests.xml"],expected_cases=1,filter=test,CXX=1,links=1,NVCC=0,SDK_builds=0,GPU_runs=0,preserved_failure_windows=["validation/focused-tests/attempt1","validation/baseline-empty/attempt1"],scope="Test-only current empty exact-frame contract. Zero/2request zero-query runs via owning ragged QKV and paged address-only K/V frames; nonempty missing-page-guard rejection and original1024-byte zero output per run. Three already-passing cases are not requested for rerun. No product/math/threshold change."))
    print("EMPTY_CONTRACT_TEST_READY",image,flush=True)
if __name__=="__main__":main()
