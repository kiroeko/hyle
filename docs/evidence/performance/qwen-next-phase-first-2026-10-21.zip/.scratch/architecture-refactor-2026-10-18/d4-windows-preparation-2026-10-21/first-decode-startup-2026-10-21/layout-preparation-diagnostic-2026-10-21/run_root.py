"""One explicit preparation diagnostic; no throughput conclusion or rebuild."""
from pathlib import Path
import argparse
import importlib.util
import json
import os
import subprocess
import sys
import time

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
S = HERE.parent / 'multiturn'
spec = importlib.util.spec_from_file_location('multiturn_observation_helpers', S / 'multiturn_run.py')
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--ready', type=Path, default=HERE / 'ready-for-root.json')
    parser.add_argument('--attempt', default='attempt1')
    args = parser.parse_args()
    ready = m.read(args.ready)
    for key in ('image', 'source', 'header', 'link_plan', 'runtime_environment'):
        row = ready[key]
        assert m.identity(row['path']) == row, (key, 'changed since compilation')
    expected = m.read(S / 'inputs/plan.json')['plans']['long']
    assert m.identity(expected['manifest']['path']) == expected['manifest']
    env = os.environ.copy()
    env['PATH'] = m.read(ready['runtime_environment']['path'])['PATH']
    out = HERE / 'execution' / args.attempt
    out.mkdir(parents=True, exist_ok=False)
    command = m.command_for('hyle', ready['image'], expected, out) + ['--preparation-diagnostics', '1']
    record = dict(command=command, cwd=str(m.ROOT), image=ready['image'],
        source=ready['source'], header=ready['header'], ready=m.identity(args.ready),
        schedule=expected['manifest'], preparation_diagnostic=True,
        throughput_evidence=False, profiler=False, memory_sampler=False,
        GPU_runs=1, builds=0, started_unix_ns=time.time_ns())
    m.save(out / 'command.json', record)
    m.gpu_snapshot(out, 'before')
    with (out / 'stdout.log').open('wb') as stdout, (out / 'stderr.log').open('wb') as stderr:
        started = time.perf_counter()
        process = subprocess.Popen(command, cwd=m.ROOT, env=env, stdout=stdout, stderr=stderr,
            creationflags=subprocess.CREATE_NO_WINDOW)
        record['pid'] = process.pid
        try:
            record['exit'] = process.wait(timeout=900)
        except subprocess.TimeoutExpired:
            record['timeout'] = True
            process.kill()
            record['exit'] = process.wait()
        record['process_wall_seconds'] = time.perf_counter() - started
    record['finished_unix_ns'] = time.time_ns()
    m.save(out / 'result.json', record)
    m.gpu_snapshot(out, 'after')
    if record['exit'] or record.get('timeout'):
        raise SystemExit('Diagnostic failed; inspect preserved execution logs: ' + str(out))
    observation = m.parse_observation(out, 'hyle', expected)
    baseline = m.read(S / 'long-timing/attempt1/runs.json')
    assert isinstance(baseline, list)
    baseline_ids = [row['observation']['predicted_ids'] for row in baseline]
    equal = all(observation['predicted_ids'] == ids for ids in baseline_ids)
    assert len(observation['predicted_ids']) == 99 and equal
    m.save(out / 'observation.json', dict(observation=observation,
        predicted_ids_match_all_six_prior_timing_processes=equal,
        baseline=m.identity(S / 'long-timing/attempt1/runs.json'),
        throughput_evidence=False, note='Single explicit host diagnostic, not a timing comparison or model-quality acceptance.'))
    print(json.dumps(dict(exit=record['exit'], outputs=len(observation['predicted_ids']),
        predictions_match_prior_timing=equal, folder=str(out), throughput_evidence=False), indent=2))


if __name__ == '__main__':
    main()
