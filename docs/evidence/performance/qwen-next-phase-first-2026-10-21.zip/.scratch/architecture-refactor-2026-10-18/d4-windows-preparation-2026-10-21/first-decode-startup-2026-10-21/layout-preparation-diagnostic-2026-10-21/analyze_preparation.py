from pathlib import Path
import collections, hashlib, json, math, re, statistics
S = Path(__file__).resolve().parent
F = S.parent
ROOT = F.parents[3]
E = S / "execution/attempt1"
def identity(path):
    path = Path(path)
    return dict(path=str(path.relative_to(ROOT)).replace("\\", "/"), bytes=path.stat().st_size, sha256=hashlib.sha256(path.read_bytes()).hexdigest())
def fields(line):
    result = {}
    for token in line.split()[1:]:
        key, value = token.split("=", 1)
        if re.fullmatch(r"-?[0-9]+", value): result[key] = int(value)
        elif re.fullmatch(r"-?[0-9.]+(?:e[+-]?[0-9]+)?", value, re.I): result[key] = float(value)
        else: result[key] = value
    return result
lines = (E / "stderr.log").read_text().splitlines()
preparation, plans, steps, pending = [], collections.defaultdict(list), [], None
for line in lines:
    if line.startswith("prepared T="): pending = fields(line)
    elif re.match(r"round[0-9]+_(?:prefill|decode[0-9]+) tokens=", line):
        assert pending is not None
        step = fields(line); step["name"] = line.split()[0]; step["prepared"] = pending
        steps.append(step); pending = None
    elif line.startswith("preparation "): preparation.append(fields(line))
    elif line.startswith("batch_plan "):
        row = fields(line); plans[row["name"]].append(row)
assert len(preparation) == len(steps) == len(plans) == 99
assert sum(len(x) for x in plans.values()) == 594
assert [x["name"] for x in preparation] == [x["name"] for x in steps]
stdout = json.loads((E / "stdout.log").read_text())
execution = json.loads((E / "result.json").read_text())
assert execution["exit"] == 0 and stdout["diagnostic"] is True
assert stdout["generated_tokens"] == 99 and stdout["processed_tokens"] == 864
prior, slot = {}, 0
all_rows, raw_reports = [], []
geometry_fields = ["float_workspace_bytes", "int_workspace_bytes", "cta_tile_q", "padded_batch_size", "split_kv", "bf16_partials", "capture_compatible", "native_metadata_unknown"]
first_nodes = None
for index, (obs, step) in enumerate(zip(preparation, steps)):
    name = obs["name"]; records = plans[name]
    assert len(records) == 6 and [x["attention_index"] for x in records] == list(range(6))
    nodes = [x["node"] for x in records]
    if first_nodes is None: first_nodes = nodes
    assert nodes == first_nodes
    assert all(x["slot"] == slot == obs["slot"] for x in records)
    assert obs["tokens"] == step["tokens"] == step["prepared"]["T"]
    assert obs["visible"] == step["visible"] == step["prepared"]["visible"]
    uses = prior.setdefault(obs["tokens"], [0, 0])
    assert obs["phase_slot_prior_uses"] == uses[slot]
    assert obs["native_plan_first_use"] == int(uses[slot] == 0)
    uses[slot] += 1; slot = 1 - slot
    assert all(x["layout_generation"] == index + 1 for x in records)
    assert all(obs[k] >= 0 and math.isfinite(obs[k]) for k in ["layout_seconds", "batch_prepare_seconds", "replay_prepare_seconds", "report_snapshot_seconds"])
    assert obs["snapshot_after_host_endpoint"] == 1
    assert all(all(x[k] == records[0][k] for x in records) for k in geometry_fields)
    assert all(x["host_waits"] == x["upload_host_waits"] + (0 if x["reused_native_plan"] else 1) for x in records)
    # Shared metadata transfer is reported only by the first selected region.
    assert all(x[k] == 0 for x in records[1:] for k in ["metadata_staging_bytes", "upload_logical_bytes", "upload_physical_bytes", "upload_native_calls", "upload_host_waits"])
    row = dict(obs, capture_recorded=step["prepared"]["capture_recorded"], capture_reused=step["prepared"]["capture_reused"], replay_route=step["prepared"]["replay"], cold_combined_seconds=step["prepared"]["cold_batch_seconds"], step_seconds=step["step_seconds"], submit_seconds=step["submit_seconds"], submit_to_host_token_seconds=step["seconds"], geometry={k: records[0][k] for k in geometry_fields}, reused_native_plans=sum(x["reused_native_plan"] for x in records), plan_count=6, report_host_waits=[x["host_waits"] for x in records], planning_retirement_waits=sum(x["host_waits"]-x["upload_host_waits"] for x in records), metadata_declared_logical_bytes=sum(x["upload_logical_bytes"] for x in records), metadata_declared_physical_bytes=sum(x["upload_physical_bytes"] for x in records), metadata_upload_native_calls=sum(x["upload_native_calls"] for x in records), metadata_upload_host_waits=sum(x["upload_host_waits"] for x in records), metadata_report=records[0])
    all_rows.append(row); raw_reports.extend(records)
old_runs = F / "multiturn/long-timing/attempt1/runs.json"
prediction_checks = []
for run in json.loads(old_runs.read_text()):
    raw = run["observation"]["raw"]
    ids = raw.get("generated_ids", raw.get("predicted_ids"))
    assert ids == stdout["generated_ids"]
    prediction_checks.append(dict(arm=run["arm"], folder=run["folder"], count=len(ids), equal=True))
def timing(rows, field):
    data = [x[field] for x in rows]
    return dict(calls=len(data), sum_ms=sum(data)*1000, median_us=statistics.median(data)*1e6, min_us=min(data)*1e6, max_us=max(data)*1e6)
def window(rows):
    return dict(calls=len(rows), timing={k: timing(rows,k) for k in ["layout_seconds", "batch_prepare_seconds", "replay_prepare_seconds", "report_snapshot_seconds", "cold_combined_seconds", "step_seconds"]}, capture_recorded=sum(x["capture_recorded"] for x in rows), capture_reused=sum(x["capture_reused"] for x in rows), fresh_native_plans=sum(6-x["reused_native_plans"] for x in rows), reused_native_plans=sum(x["reused_native_plans"] for x in rows), planning_retirement_waits=sum(x["planning_retirement_waits"] for x in rows), metadata_upload_host_waits=sum(x["metadata_upload_host_waits"] for x in rows), metadata_declared_logical_bytes=sum(x["metadata_declared_logical_bytes"] for x in rows), metadata_upload_native_calls=sum(x["metadata_upload_native_calls"] for x in rows), geometric_summaries=[dict(geometry=json.loads(key),calls=count) for key,count in collections.Counter(json.dumps(x["geometry"],sort_keys=True) for x in rows).items()])
prefills = [x for x in all_rows if x["tokens"] == 256]
decode_windows = {}
for turn in range(1,4):
    decode = [x for x in all_rows if x["name"].startswith(f"round{turn}_decode")]
    assert len(decode) == 32
    assert all(x["reused_native_plans"] == 0 for x in decode[:2])
    assert all(x["reused_native_plans"] == 6 for x in decode[2:])
    decode_windows[f"round{turn}"] = dict(first_two=[x for x in decode[:2]], first_two_summary=window(decode[:2]), later_3_to_32=window(decode[2:]))
steady = [x for x in all_rows if "decode" in x["name"] and int(x["name"].split("decode")[1]) >= 3]
slowest = max(steady,key=lambda x: x["batch_prepare_seconds"])
report_snapshot_in_session = sum(x["report_snapshot_seconds"] for x in all_rows[:-1])
session_gap = stdout["session_seconds"] - stdout["step_sum_seconds"]
original_remaining = [x["cold_combined_seconds"] - x["layout_seconds"] - x["batch_prepare_seconds"] - x["replay_prepare_seconds"] for x in all_rows]
assert all(x >= -1e-8 for x in original_remaining)  # stderr's original six-digit display rounds this residual.
summary = dict(schema="hyle.layout-preparation-diagnostic-independent-analysis.v1",status="actual_single_process_diagnostic_complete_not_throughput",sources=[identity(E/p) for p in ["command.json","result.json","stderr.log","stdout.log","before.json","after.json"]]+[identity(old_runs),identity(S/"static-checks.json"),identity(ROOT/"tools/qwen35_text/main.cc"),identity(ROOT/"src/compute_batch/batch_execution.cc"),identity(ROOT/"src/compute_provider_flashinfer/flashinfer_provider.cc"),identity(Path(__file__))],validation=dict(exit=0,preparation_records=99,batch_plan_records=594,selected_attention_nodes=first_nodes,all_records_unique_and_complete=True,global_parity_and_actual_prior_uses_checked=True,all_layout_generations_in_order=True,all_timing_fields_finite_nonnegative=True,all_99_IDs_match_each_of_six_previous_long_processes=prediction_checks),prefills=prefills,decode_windows=decode_windows,whole_window=window(all_rows),first_use_vs_replan=dict(first_child_slot_calls=sum(x["native_plan_first_use"] for x in all_rows),nonfirst_calls_with_nonreused_native_plans=[x["name"] for x in all_rows if not x["native_plan_first_use"] and x["reused_native_plans"] != 6],first_two_decode_slots_each_later_round_are_real_repreparation=True),host_diagnostic_overhead=dict(report_snapshot_all_calls_ms=sum(x["report_snapshot_seconds"] for x in all_rows)*1000,report_snapshot_within_session_ms=report_snapshot_in_session*1000,final_call_snapshot_outside_session_ms=all_rows[-1]["report_snapshot_seconds"]*1000,session_minus_sum_of_original_steps_ms=session_gap*1000,other_unbucketed_between_call_host_time_ms=(session_gap-report_snapshot_in_session)*1000,original_cold_residual_ms=sum(original_remaining)*1000,method="Report snapshots occur after each original host-token endpoint. The first98 can fall between session endpoints; the last cannot. Deferred original/diagnostic log printing is after the final endpoint. Extra diagnostic clocks still perturb their measured branch; do not compare this session as throughput."),steady_outlier=slowest,findings=["P1 T256 slot0 is first use: batch4.2983ms/replay46.9415ms, one outer capture; this large first capture is startup, not steady performance.","P2 T256 slot1 is first use: batch3.9260ms/replay0.5585ms, Commands, no outer capture. Its six nonreused plans are initial construction and must not be labeled a redundant replan defect.","P3 T256 slot0 has prior-use1: batch0.5418ms/replay3.6231ms, six nonreused plans plus a newly recorded outer range. Public float/int workspace, CTA64/padded32/splitKV are identical to P1, but those fields are not a complete topology or physical-identity proof.","Each round's first two T1 calls have six nonreused plans and one new outer capture each. Rounds2/3 have already-used slots; reported padded batches/workspace rise3/394752B to5/657920B to7/921088B per native attention plan. This is actual reprepare on history growth; exact private chunk rows/signatures were not recorded.","Each round's calls3..32 reuse all six plans and the outer range. Batch medians46.55/54.2/55.75us; replay medians8.75/9.3/11.2us. A retained round3_decode24 outlier batch1.1888ms has all six plans reused, one metadata wait and no capture, so it is not evidence of a native replan.","Metadata transfer is reported once per call by attention_index0, not repeated sixfold: first4 child/slot calls36B, remaining95 calls24B, total2424 declared logical/physical bytes,99 copy entry calls and99 explicit metadata-upload waits.54 nonreused attention plans add54 planning-retirement waits. Copy metadata_bytes4526 is report/program metadata capacity, not extra transfer bytes or measured fresh allocation.","All594 reports retain native_metadata_unknown=true; workspace bytes are per-plan reported requirements. No allocation/free API trace, peak VRAM or complete provider-private memory accounting is available in this diagnostic."],source_interpretation=dict(host_waits_anchor="src/compute_batch/batch_execution.cc:521-535",host_waits_rule="report.host_waits = metadata upload waits + (nonreused plan ?1:0); nonreuse waits on the actual planning Completion before returning.",reuse_anchor="src/compute_provider_flashinfer/flashinfer_provider.cc:234-262,382-397",reuse_rule="Unchanged public workspace sizes are insufficient. Reuse requires original query layout and active-request KV chunk-count/CTA compatibility; new planning/workspace carriers invalidate affected recorded commands. The report cannot distinguish every rejection cause."),limits=["Exactly one process with extra Clock/read-only host report queries, no new observer/profiler. No statistical throughput or latency comparison with prior timing windows.","No first-layer or whole-vector numerical capture in this run.99 predictions match prior Hyle/peer long runs, but this is not independent quality acceptance.","Do not count all reported waits as repeated costs that can be removed: some are required metadata readiness/planning retirement; source proof and a later specific change need separate regression.","No product or consumer edits, build or GPU/model execution by this reviewer."],next_source_question="Now distinguish the provider's repeated workspace-size query in one original prepare transaction from mandatory first-use planning, real topology replan and immutable-capture invalidation. Preserve the existing update/fresh and lifetime proofs; these timings do not justify bypassing any guard.")
details=dict(per_call=all_rows,per_report=raw_reports)
(E/"independent-analysis-details.json").write_text(json.dumps(details,indent=2)+"\n")
baseline_recipe_path = ROOT / ".scratch/architecture-refactor-2026-10-18/compact-mla-e4-reference/cuda/checks/attempt1/host-provider/identity.json"
baseline_recipe = json.loads(baseline_recipe_path.read_text())
summary["provider_source_provenance"] = dict(measured_baseline_source=baseline_recipe["source"],measured_baseline_object=baseline_recipe["object"],identity=identity(baseline_recipe_path),source_review_inventory="sources contains the current provider7f7d... after the separate facts-reuse edit; it is a read-only source anchor, not the provider executed in this old diagnostic. This count/timing analysis is for baselineac20... only. The later candidate requires its separate execution evidence.",current_candidate_diff=identity(F/"layout-workspace-facts-reuse-2026-10-21/diff/flashinfer_provider.cc.diff"))
summary["details"] = identity(E/"independent-analysis-details.json")
(E/"independent-analysis.json").write_text(json.dumps(summary,indent=2)+"\n")
print(json.dumps(dict(report=identity(E/"independent-analysis.json"),host_diagnostic_overhead=summary["host_diagnostic_overhead"],totals=summary["whole_window"]),indent=2))
