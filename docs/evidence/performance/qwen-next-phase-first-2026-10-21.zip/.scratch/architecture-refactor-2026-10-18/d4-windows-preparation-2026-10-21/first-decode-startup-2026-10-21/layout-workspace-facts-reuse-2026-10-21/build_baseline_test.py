"""One link with the old FI provider only; no CXX or test execution."""
from pathlib import Path
import importlib.util,os,sys
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location("fi_baseline_test_build",S/"build.py")
h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
b,c,R,F=h.b,h.c,h.R,h.F
base_path=S/"tests/attempt2/link/link-plan.json";base=c.read(base_path)
new=c.read(S/"checks/attempt1/identity.json")["object"]
old_recipe_path=R/".scratch/architecture-refactor-2026-10-18/compact-mla-e4-reference/cuda/checks/attempt1/host-provider/identity.json"
old_recipe=c.read(old_recipe_path);old=old_recipe["object"]
assert old["sha256"]=="606ca158b885b31c7b015b86dfb0749219115784b74f015e48d9c3bdacd6922f"
assert len(base["inputs"])==193 and all(h.same(x) for x in base["inputs"]) and h.same(old)
key=c.key(new["path"]);assert sum(c.key(x["path"])==key for x in base["inputs"])==1
inputs=[old if c.key(x["path"])==key else x for x in base["inputs"]]
out=S/"tests/baseline-provider/link";out.mkdir(parents=True,exist_ok=False);(out/"tmp").mkdir()
image=out/"flashinfer-native-cache-baseline.exe"
link=[old["path"] if c.key(x)==key else x for x in base["command"] if not x.upper().startswith(("/OUT:","/MAP:","/IMPLIB:","/PDB:"))]
link += ["/OUT:"+str(image),"/MAP:"+str(image.with_suffix(".map")),"/IMPLIB:"+str(image.with_suffix(".lib"))]
c.save(out/"link-plan.json",dict(command=link,inputs=inputs,base=b.identity(base_path),removed_provider=new,restored_provider=old,restored_recipe=b.identity(old_recipe_path),CXX=0,links=1,NVCC=0,GPU_runs=0))
env,runtime=b.environment(link,[x["path"] for x in inputs],out);c.execute("link",link,env,out)
staged=[]
for row in c.read(S/"tests/attempt2/link/runtime-environment.json")["staged_CPU_modules"]:
 original=Path(row["destination"]["path"]);assert h.same(row["destination"])
 target=out/original.name;os.link(original,target);assert os.path.samefile(original,target)
 staged.append(dict(source=b.identity(original),destination=b.identity(target),hardlink=True))
c.save(out/"runtime-environment.json",dict(PATH=env["PATH"],runtime=runtime,staged_CPU_modules=staged))
c.save(S/"tests-baseline-ready-for-root.json",dict(status="old_provider_only_baseline_built_not_run",image=b.identity(image),link_plan=b.identity(out/"link-plan.json"),runtime_environment=b.identity(out/"runtime-environment.json"),baseline_provider_source=old_recipe["source"],baseline_provider_object=old,unchanged_test_objects=[dict(source=x["source"],object=x["object"]) for x in base["fresh_tests"]],suggested_command=[str(image),"--gtest_filter=FlashinferCache.EmptyRequestsAndAllZeroQueriesUseCheckedNoOp","--gtest_output=xml:tests.xml"],expected_cases=1,CXX=0,links=1,NVCC=0,SDK_builds=0,GPU_runs=0))
print("BASELINE_EMPTY_TEST_READY",image,flush=True)
