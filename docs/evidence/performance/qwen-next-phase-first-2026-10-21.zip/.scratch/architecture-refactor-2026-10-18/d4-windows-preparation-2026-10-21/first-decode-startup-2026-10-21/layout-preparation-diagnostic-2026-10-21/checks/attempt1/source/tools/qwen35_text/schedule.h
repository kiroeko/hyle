// Fixed-input benchmark schedule shared by the two test consumers.
// This is consumer input handling, not a Compute/Graph execution interface.
#pragma once

#include <charconv>
#include <cstddef>
#include <cstdint>
#include <filesystem>
#include <fstream>
#include <iomanip>
#include <limits>
#include <sstream>
#include <stdexcept>
#include <string>
#include <system_error>
#include <utility>
#include <vector>

namespace qwen35::benchmark {

enum class PhaseKind { kPrompt, kDecode };

struct Phase {
  PhaseKind kind;
  std::vector<std::int32_t> ids;
  std::size_t turn;
};

inline std::vector<Phase> read_schedule(const std::filesystem::path &path,
    std::int64_t vocabulary, std::size_t capacity) {
  if (vocabulary <= 0 || vocabulary > (std::numeric_limits<std::int32_t>::max)() ||
      capacity == 0 || capacity > static_cast<std::size_t>((std::numeric_limits<std::int32_t>::max)()))
    throw std::runtime_error("schedule requires positive vocabulary and context capacity within I32 positions");
  std::ifstream manifest(path);
  if (!manifest) throw std::runtime_error("cannot open schedule: " + path.string());
  std::vector<Phase> phases;
  std::size_t total = 0, line_number = 0, turn = 0;
  std::string line;
  while (std::getline(manifest, line)) {
    ++line_number;
    const auto first = line.find_first_not_of(" \t\r");
    if (first == std::string::npos || line[first] == '#') continue;
    const auto error = [&](const std::string &message) {
      return std::runtime_error(path.string() + ":" + std::to_string(line_number) + ": " + message);
    };
    std::istringstream fields(line);
    std::string kind, filename, extra;
    if (!(fields >> kind >> std::quoted(filename)) || filename.empty() || (fields >> extra))
      throw error("expected prompt IDSFILE or decode IDSFILE (quote paths containing spaces)");
    const auto expected = phases.size() % 2 == 0 ? "prompt" : "decode";
    if (kind != expected)
      throw error(std::string("expected ") + expected + "; each turn is prompt followed by decode");
    const auto input_path = path.parent_path() / std::filesystem::path(filename);
    std::ifstream input(input_path);
    if (!input) throw error("cannot open token IDs: " + input_path.string());
    Phase phase{kind == "prompt" ? PhaseKind::kPrompt : PhaseKind::kDecode, {}, turn};
    if (phase.kind == PhaseKind::kPrompt) phase.turn = ++turn;
    else phase.turn = turn;
    std::string token;
    while (input >> token) {
      std::int64_t id = 0;
      const auto converted = std::from_chars(token.data(), token.data() + token.size(), id);
      if (converted.ec != std::errc{} || converted.ptr != token.data() + token.size() || id < 0 || id >= vocabulary)
        throw error("token ID outside vocabulary or malformed: " + input_path.string());
      if (phase.ids.size() >= capacity - total)
        throw error("schedule exceeds context capacity");
      phase.ids.push_back(static_cast<std::int32_t>(id));
    }
    if (!input.eof()) throw error("failed reading token IDs: " + input_path.string());
    if (phase.ids.empty()) throw error("phase requires nonempty token IDs: " + input_path.string());
    total += phase.ids.size();
    phases.push_back(std::move(phase));
  }
  if (!manifest.eof()) throw std::runtime_error("failed reading schedule: " + path.string());
  if (phases.empty() || phases.back().kind != PhaseKind::kDecode)
    throw std::runtime_error("schedule requires complete prompt/decode turns");
  return phases;
}

// local_index is zero based, including single-token decode inputs.
inline std::string phase_name(const Phase &phase, std::size_t local_index) {
  const auto prefix = "round" + std::to_string(phase.turn);
  return phase.kind == PhaseKind::kPrompt ? prefix + "_prefill"
      : prefix + "_decode" + std::to_string(local_index + 1);
}

} // namespace qwen35::benchmark
