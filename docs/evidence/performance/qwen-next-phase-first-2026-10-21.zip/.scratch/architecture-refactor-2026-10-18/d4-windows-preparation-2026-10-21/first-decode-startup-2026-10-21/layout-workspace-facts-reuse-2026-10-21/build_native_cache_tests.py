"""Fresh two original FI test TUs and one current193-input link; no test execution."""
from pathlib import Path
import importlib.util, os, sys
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location("native_cache_current_build",S/"build.py")
h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
b,c,R,F,D=h.b,h.c,h.R,h.F,h.D

def compile_test(tag,relative):
    recipe_path=F/"native-fix/tests/attempt1/device-status-test/identity.json"
    recipe=c.read(recipe_path)
    usage_path=R/".scratch/architecture-refactor-2026-10-18/compact-mla-e4-reference/cuda/checks/attempt1/host-provider/identity.json"
    usage=c.read(usage_path)
    flag="/DHYLE_COMPUTE_FLASHINFER=1"
    assert flag in usage["command"] and flag not in recipe["command"]
    source=R/relative;frozen=b.identity(source)
    out=S/"tests/attempt2"/tag;out.mkdir(parents=True,exist_ok=False);(out/"tmp").mkdir()
    command=b.host_command([*recipe["command"],flag],source,tag,out)
    assert all(x in command for x in ("/W4","/WX","/MD","/O2","/DHYLE_STATIC"))
    c.save(out/"compile-plan.json",dict(command=command,source=frozen,actual_same_environment_test_recipe=b.identity(recipe_path),target_usage_definition_provenance=b.identity(usage_path),added_PUBLIC_definition=flag,recipe_scope="Actual Windows CUDA/gtest recipe; source/out changed and the real FI target PUBLIC usage definition restored. No warning flags relaxed; no native/Linux/Vulkan recipe substitution.",CXX=1,NVCC=0,SDK_builds=0,GPU_runs=0))
    env,_=b.environment(command,[],out);c.execute("compile",command,env,out)
    deps_path=out/(tag+"-deps.json");deps=c.read(deps_path)["Data"]
    dependencies=[b.identity(p) for p in dict.fromkeys([deps["Source"],*deps["Includes"]])]
    assert h.same(frozen) and all(h.same(x) for x in dependencies)
    obj=b.identity(out/(tag+".obj"))
    row=dict(source=frozen,object=obj,command=command,dependencies=dependencies,source_dependencies=b.identity(deps_path),recipe=b.identity(recipe_path),PUBLIC_usage=flag,CXX=1,GPU_runs=0)
    c.save(out/"identity.json",row)
    snapshot=out/"source"/relative;snapshot.parent.mkdir(parents=True);snapshot.write_bytes(source.read_bytes())
    return row

def main():
    rows=[compile_test("native-cache-test","tests/compute_provider_flashinfer/native_cache_test.cc"),compile_test("ragged-mla-test","tests/compute_provider_flashinfer/ragged_mla_test.cc")]
    base_path=S/"checks/attempt1/link-plan.json";base=c.read(base_path)
    assert len(base["inputs"])==190 and all(h.same(x) for x in base["inputs"])
    old_main=c.read(F/"layout-preparation-diagnostic-2026-10-21/checks/attempt1/identity.json")["object"];old=c.key(old_main["path"])
    assert sum(c.key(x["path"])==old for x in base["inputs"])==1
    gtests=[x for x in c.read(D/"preparation-plan.json")["remove_test_inputs"] if x["path"].endswith(("gtest.lib","gtest_main.lib"))]
    assert len(gtests)==2 and all(h.same(x) for x in gtests)
    fresh=[row["object"] for row in rows]+gtests
    inputs=[x for x in base["inputs"] if c.key(x["path"])!=old]+fresh;assert len(inputs)==193
    out=S/"tests/attempt2/link";out.mkdir(parents=True,exist_ok=False);(out/"tmp").mkdir()
    image=out/"flashinfer-native-cache-tests.exe"
    link=[x for x in base["command"] if c.key(x)!=old and not x.upper().startswith(("/OUT:","/MAP:","/IMPLIB:","/PDB:"))]
    link += [x["path"] for x in fresh]
    link += ["/OUT:"+str(image),"/MAP:"+str(image.with_suffix(".map")),"/IMPLIB:"+str(image.with_suffix(".lib"))]
    c.save(out/"link-plan.json",dict(command=link,inputs=inputs,base=b.identity(base_path),removed_main=old_main,fresh_tests=rows,gtest_libraries=gtests,CXX=2,links=1,NVCC=0,SDK_builds=0,GPU_runs=0))
    env,runtime=b.environment(link,[x["path"] for x in inputs],out);c.execute("link",link,env,out)
    staged=[]
    for row in c.read(S/"checks/attempt1/runtime-environment.json")["staged_CPU_modules"]:
        original=Path(row["destination"]["path"]);assert h.same(row["destination"])
        target=out/original.name;os.link(original,target);assert os.path.samefile(original,target)
        staged.append(dict(source=b.identity(original),destination=b.identity(target),hardlink=True))
    c.save(out/"runtime-environment.json",dict(PATH=env["PATH"],runtime=runtime,staged_CPU_modules=staged))
    filters=["FlashinferCache.RuntimeScheduleReusesActualTilesAcrossKvExtents","FlashinferBatchReplay.ColdRecordAndRuntimeSchedule","FlashinferCache.EmptyRequestsAndAllZeroQueriesUseCheckedNoOp","FlashInferRaggedMla.Compact512And576KeepGlobalRowsDirectGraphAndOwners"]
    provider_source=c.read(S/"ready-for-root.json")["provider_source"]
    assert h.same(provider_source) and all(h.same(x) for x in inputs)
    c.save(S/"tests-ready-for-root.json",dict(status="original_native_cache_and_MLA_tests_built_not_run",image=b.identity(image),sources=[row["source"] for row in rows],provider_source=provider_source,identities=[b.identity(S/"tests/attempt2"/tag/"identity.json") for tag in ("native-cache-test","ragged-mla-test")],link_plan=b.identity(out/"link-plan.json"),runtime_environment=b.identity(out/"runtime-environment.json"),suggested_command=[str(image),"--gtest_filter="+":".join(filters),"--gtest_output=xml:tests.xml"],expected_cases=4,filters=filters,CXX=2,links=1,NVCC=0,SDK_builds=0,GPU_runs=0,first_red="tests/attempt1 missing FI target PUBLIC define in backend-only recipe; preserved raw command/source/log. Not a product or math failure.",scope="Original64-step fresh/update/boundary/explicit-fresh/old-output direct and captured journeys, empty/no-op, original compact512/576 MLA direct/Graph owner lifecycle. No source edits or new test matrix."))
    print("NATIVE_CACHE_AND_MLA_TESTS_READY",image,flush=True)
if __name__=="__main__":main()
