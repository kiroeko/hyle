"""Publish bounded source/results, then refresh the current performance table."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
import statistics
import zipfile


W = Path(__file__).resolve().parent
F = W.parent
DIAG = F / 'layout-preparation-diagnostic-2026-10-21'
R = next(p for p in W.parents if (p / 'AGENTS.md').is_file())
REPORT = R / 'docs/evidence/performance/qwen-next-phase-first-2026-10-21.json'
ARCHIVE = REPORT.with_suffix('.zip')


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def identity(path):
    path = Path(path)
    data = path.read_bytes()
    return dict(path=path.relative_to(R).as_posix(), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())


def save(path, value):
    Path(path).write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + '\n', encoding='utf-8')


def main():
    assert not REPORT.exists() and not ARCHIVE.exists(), 'Preserve prior published data'
    timing = read(W / 'performance/timing/attempt1/summary.json')
    memory = read(W / 'performance/memory/attempt1/summary.json')
    independent = read(W / 'performance/independent-review.json')
    vectors = read(W / 'validation/single/attempt1/summary.json')
    first_tests = read(W / 'validation/focused-tests/attempt1/result.json')
    baseline_empty = read(W / 'validation/baseline-empty/attempt1/result.json')
    fixed_empty = read(W / 'validation/fixed-empty/attempt1/result.json')
    assert vectors['passed'] and vectors['vector_count'] == 64
    assert first_tests['exit'] == baseline_empty['exit'] == 1 and fixed_empty['exit'] == 0
    assert independent['all8_process_predictions_equal'] and independent['predictions_per_process'] == 99
    ready = read(W / 'ready-for-root.json')
    for key in ('source', 'provider_source', 'header', 'image'):
        row = ready[key]
        data = Path(row['path']).read_bytes()
        assert len(data) == row['bytes'] and hashlib.sha256(data).hexdigest() == row['sha256']

    members = {}
    allowed = {'.json', '.log', '.py', '.cc', '.h', '.diff', '.txt', '.tsv', '.xml'}
    for folder in (DIAG, W):
        for path in folder.rglob('*'):
            relative = path.relative_to(folder)
            if path.is_file() and path.suffix in allowed and 'tmp' not in relative.parts:
                members[path.relative_to(R).as_posix()] = path
    # Existing one-session runner and exact ID inputs are reused, without SDKs,
    # model weights, large images/maps, or duplicate tensor payload.
    S = F / 'multiturn'
    for path in [S / 'multiturn_run.py', S / 'correctness.py',
                 *[p for p in (S / 'inputs').rglob('*') if p.is_file()]]:
        members[path.relative_to(R).as_posix()] = path
    design = F / 'multi-session-implementation/design.json'
    members[design.relative_to(R).as_posix()] = design
    with zipfile.ZipFile(ARCHIVE, 'w', zipfile.ZIP_DEFLATED) as archive:
        for name, path in sorted(members.items()):
            archive.writestr(name, path.read_bytes())
    with zipfile.ZipFile(ARCHIVE) as archive:
        assert archive.testzip() is None
        for name, path in members.items():
            assert archive.read(name) == path.read_bytes()

    report = dict(
        date='2026-10-21', status='first_complete_new_phase_single_session_window',
        hardware='Windows, RTX 4070 12GB, driver 617.14; ordinary desktop, no exclusive GPU or fixed clocks.',
        implementation={
            'consumer': 'Explicit schedule-only preparation diagnostics, cold preallocated six reports and separate layout/batch/replay timing; disabled in throughput window.',
            'provider': 'One original BatchSlot passes a successful fresh workspace sizing result once into the exact matching plan attempt; preserves original native materialization, capacity, queue/primary admission and failure retirement.',
            'known_scope': 'No new quantized math, fusion, multi-session, MTP or image execution in this batch.',
            'current_images': ready,
        },
        workload=dict(model='Qwen3.5-2B official BF16 text, no MTP/vision', active_sequences=1,
            phases='(256 fixed input tokens + 32 one-token fixed decode inputs) x 3',
            capacity=1024, final_context=864, generated_endpoints=99, decode_endpoints=96,
            synthetic_teacher_forced=True, timing_processes_per_arm=3, independent_memory_processes_per_arm=1,
            peer_library_commit='d9e03f1074dbd2979126d91dce1b5d304ec8394e'),
        primary_metrics=independent['publication_table'],
        timing_groups=timing['groups'], rounds=timing['rounds'], loading=timing['loading'],
        memory={arm: dict(sampled_peaks=row['sampled_peaks'],
            actual_sample_gap_ms={k: v for k, v in row['actual_sample_gaps_ms'].items() if k != 'samples'},
            ready_baseline_unknown=row['ready_baseline']['unknown'],
            strict_phase_boundary_delta=None,
            phase_peaks={name: {key: value['max'] for key, value in phase['values'].items()}
                for name, phase in row['phase_windows'].items()}) for arm, row in memory['arms'].items()},
        validation=dict(original64_byte_equal=True, all8_timing_and_memory_predictions_equal=True,
            focused_tests_initial='3 passed, stale empty-arena contract fixture failed',
            original_provider_control='Same fixture failed with the old provider and identical common/test objects',
            corrected_empty_fixture='Passed after actual empty-frame execution/zero-output and nonempty missing-page-permission checks; no product contract or numerical threshold relaxed',
            tests_repeated='Only corrected failed case repeated; prior three passing cases not rerun',
            independent_model_quality_acceptance=False),
        diagnosis=dict(
            timing_is_old_provider_host_diagnostic=True,
            second_prefill='T256 slot1 first native plan; batch 3.926 ms, replay 0.5585 ms in the one diagnostic process',
            third_prefill='T256 slot0 previously used at KV256, now KV832; batch 0.5418 ms, replay 3.6231 ms',
            topology='Fixed original FlashInfer scheduler proves chunk-count change at P3. Equal public workspace/tile dimensions do not prove reusable native plan.',
            decode='Every round first two calls have six nonreuse plans, followed by thirty calls with all six native plans reused.',
            no_claim='One diagnostic process does not measure optimization gain or establish all remaining causes.'),
        next_action=[
            'Separate shared model weights/schema/family from session state and independent Invocation/IO. Validate two-session isolation, then at least four active users.',
            'Close generic Graph paged-write/effect integration without making the consumer manually splice a producer/copy/consumer executor per layer.',
            'Investigate capture lifetime/amortization across actual topology changes; avoid recording one-use replacements without weakening plan/permission invalidation.',
        ],
        limits=[
            'Both arms are slower than the preceding window. Do not attribute cross-window differences to this narrow query change.',
            'This is a current Hyle-vs-peer window, not a matched old-provider-vs-new-provider throughput experiment. No measured speedup for the query reuse is claimed.',
            'GPU utilization snapshots were 16% before and 21% after; desktop background load and clocks vary.',
            'Per-process rates use actual counts and wall times before taking medians; three phase TPS values are never averaged.',
            'Memory sampled peaks are lower bounds; ready baselines and exact boundary deltas remain unknown; dedicated/shared independent peaks and CPU/GPU counters are not summed.',
            'Consumer-entry startup excludes OS/DLL loading. Model loading uses warm uncontrolled OS page cache.',
            'No DGX Spark or four-user benchmark was performed. Capacity/throughput on that deployment is unverified.',
            'No model-quality acceptance or full original artifact coverage is implied by byte regression or equal predicted IDs.',
        ],
        evidence=dict(diagnostic_source_review=identity(DIAG / 'source-review.json'),
            diagnostic_analysis=identity(DIAG / 'execution/attempt1/independent-analysis.json'),
            provider_review=identity(W / 'independent-review.json'),
            independent_performance_review=identity(W / 'performance/independent-review.json'),
            model_session_design=identity(design)),
        archive={**identity(ARCHIVE), 'members': len(members)}, goal_complete=False)
    save(REPORT, report)

    # Keep just the newest complete window in the entry page; prior raw
    # evidence stays linked rather than growing a second experiment journal.
    page = R / 'docs/developer/current-work.md'
    text = page.read_text(encoding='utf-8-sig')
    start = text.index('## 最新完整性能对比')
    lines = [
        '## 最新完整性能对比', '',
        '**每次完整测试后更新本节**，保留prefill、decode、显存变化、多轮综合速度及加载／冷准备口径，并链接当次数据。局部诊断不覆盖完整对比；未复测改动不沿用旧数据声称收益。', '',
        '**2026-10-21，新阶段首轮完整测试。** RTX 4070 12GB／Windows，Qwen3.5-2B BF16、无MTP／图片；单会话三轮`256输入＋32 decode`，同固定ID带、容量1024、最终上下文864。',
        'Hyle镜像`ff748694…`，参考`9b259137…`／llama.cpp `d9e03f1074db…`；各3进程交错测速，显存另各1进程旁采，诊断关闭。**尚未测试Spark／四人并发。**', '',
        '| 指标 | Hyle | llama.cpp |', '| --- | ---: | ---: |',
    ]
    def add(label, a, b, digits=2):
        lines.append(f'| {label} | {a:.{digits}f} | {b:.{digits}f} |')
    for turn in ('1', '2', '3'):
        add(f'第{turn}轮prefill tok/s', timing['rounds']['hyle'][turn]['prefill']['tokens_per_second']['median'],
            timing['rounds']['peer'][turn]['prefill']['tokens_per_second']['median'])
    for turn in ('1', '2', '3'):
        add(f'第{turn}轮完整decode tok/s', timing['rounds']['hyle'][turn]['decode']['tokens_per_second']['median'],
            timing['rounds']['peer'][turn]['decode']['tokens_per_second']['median'])
    decode_row = independent['publication_table'][1]
    add('完整decode合计 tok/s（96／三段decode总wall）', decode_row['hyle'], decode_row['peer'])
    add('综合输出 tok/s（99／会话wall）', timing['groups']['hyle']['output_tokens_per_second']['median'], timing['groups']['peer']['output_tokens_per_second']['median'])
    for label, field in [('会话wall s', 'session_seconds'), ('消费者入口至末输出 s（含加载／冷准备）', 'startup_total_seconds')]:
        add(label, timing['groups']['hyle'][field]['median'], timing['groups']['peer'][field]['median'], 5)
    add('启动至ready s', timing['loading']['hyle']['startup_to_ready_seconds']['median'], timing['loading']['peer']['startup_to_ready_seconds']['median'], 5)
    for label, key in [('GPU dedicated全程观测峰 GiB','sampled_peak_gpu_dedicated_bytes'),
                       ('GPU shared全程观测峰 GiB','sampled_peak_gpu_shared_bytes'),
                       ('进程working set观测峰 GiB','sampled_max_working_set_bytes'),
                       ('进程private commit观测峰 GiB','sampled_max_private_commit_bytes')]:
        add(label, memory['arms']['hyle']['sampled_peaks'][key] / 2**30, memory['arms']['peer']['sampled_peaks'][key] / 2**30, 3)
    lines += ['',
        '专用显存阶段峰按P1→D1→P2→D2→P3→D3：Hyle **3.956→3.972→4.077→4.081→4.081→4.085 GiB**；参考 **4.191→4.194→4.194→4.194→4.194→4.194 GiB**。',
        '严格阶段边界占用／增量仍未知；实际旁采间隔中位约15.23／15.25ms，GPU峰为采样下界。CPU与GPU不相加，消费者入口计时不含OS装载DLL。',
        '综合本窗约快3.43%，第二轮prefill仍慢24.07%，第三轮差−0.14%且样本范围重叠。两端相对前窗都变慢；背景GPU负载与时钟变化，不将跨窗差异归因本批query修复，也不宣称稳定胜出。',
        '[完整数据、源码、回归和测量限制](../evidence/performance/qwen-next-phase-first-2026-10-21.json)；[前一完整窗口](../evidence/performance/qwen-multiturn-current-2026-10-21.json)。', '']
    page.write_text(text[:start] + '\n'.join(lines), encoding='utf-8')
    print(json.dumps(dict(report=identity(REPORT), archive=identity(ARCHIVE), members=len(members)), ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
