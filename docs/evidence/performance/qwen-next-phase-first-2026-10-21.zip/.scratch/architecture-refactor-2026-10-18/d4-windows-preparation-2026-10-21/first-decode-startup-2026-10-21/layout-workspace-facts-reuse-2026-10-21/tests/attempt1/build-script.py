"""Fresh one original FI test TU; overlay the already-built192-input test closure. No execution."""
from pathlib import Path
import importlib.util, os, sys
sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("native_cache_current_build", S / "build.py")
h = importlib.util.module_from_spec(spec); spec.loader.exec_module(h)
b,c,R,F,D = h.b,h.c,h.R,h.F,h.D

def main():
    out = S / "tests/attempt1"
    out.mkdir(parents=True, exist_ok=False); (out / "tmp").mkdir()
    recipe_path = F / "native-fix/tests/attempt1/device-status-test/identity.json"
    recipe = c.read(recipe_path)
    source = R / "tests/compute_provider_flashinfer/native_cache_test.cc"
    frozen = b.identity(source)
    command = b.host_command(recipe["command"], source, "native-cache-test", out)
    assert all(x in command for x in ("/W4", "/WX", "/MD", "/O2", "/DHYLE_STATIC"))
    c.save(out / "compile-plan.json", dict(command=command, source=frozen,
        actual_same_environment_test_recipe=b.identity(recipe_path),
        recipe_scope="Actual retained Windows CUDA/gtest test recipe; source/out changed. No retained exact FI native_cache_test Windows TU was found; no Linux recipe or Vulkan same-basename recipe substituted.",
        CXX=1,NVCC=0,SDK_builds=0,GPU_runs=0))
    env,_ = b.environment(command, [], out)
    c.execute("compile",command,env,out)
    deps_path=out/"native-cache-test-deps.json"
    deps=c.read(deps_path)["Data"]
    dependencies=[b.identity(p) for p in dict.fromkeys([deps["Source"],*deps["Includes"]])]
    assert h.same(frozen) and all(h.same(x) for x in dependencies)
    obj=b.identity(out/"native-cache-test.obj")
    c.save(out/"identity.json",dict(source=frozen,object=obj,command=command,dependencies=dependencies,source_dependencies=b.identity(deps_path),recipe=b.identity(recipe_path),CXX=1,GPU_runs=0))
    snapshot=out/"source/tests/compute_provider_flashinfer/native_cache_test.cc"
    snapshot.parent.mkdir(parents=True); snapshot.write_bytes(source.read_bytes())
    base_path=S/"checks/attempt1/link-plan.json"
    base=c.read(base_path)
    assert len(base["inputs"])==190 and all(h.same(x) for x in base["inputs"])
    main_identity=c.read(F/"layout-preparation-diagnostic-2026-10-21/checks/attempt1/identity.json")
    old_main=main_identity["object"]; old=c.key(old_main["path"])
    assert sum(c.key(x["path"])==old for x in base["inputs"])==1
    gtests=[x for x in c.read(D/"preparation-plan.json")["remove_test_inputs"] if x["path"].endswith(("gtest.lib","gtest_main.lib"))]
    assert len(gtests)==2 and all(h.same(x) for x in gtests)
    inputs=[x for x in base["inputs"] if c.key(x["path"])!=old]+[obj,*gtests]
    assert len(inputs)==192
    image=out/"flashinfer-native-cache-tests.exe"
    link=[x for x in base["command"] if c.key(x)!=old and not x.upper().startswith(("/OUT:","/MAP:","/IMPLIB:","/PDB:"))]
    link += [x["path"] for x in [obj,*gtests]]
    link += ["/OUT:"+str(image),"/MAP:"+str(image.with_suffix(".map")),"/IMPLIB:"+str(image.with_suffix(".lib"))]
    c.save(out/"link-plan.json",dict(command=link,inputs=inputs,base=b.identity(base_path),removed_main=old_main,fresh_test=obj,gtest_libraries=gtests,CXX=1,links=1,NVCC=0,SDK_builds=0,GPU_runs=0))
    env,runtime=b.environment(link,[x["path"] for x in inputs],out)
    c.execute("link",link,env,out)
    staged=[]
    for row in c.read(S/"checks/attempt1/runtime-environment.json")["staged_CPU_modules"]:
        original=Path(row["destination"]["path"]);assert h.same(row["destination"])
        target=out/original.name;os.link(original,target);assert os.path.samefile(original,target)
        staged.append(dict(source=b.identity(original),destination=b.identity(target),hardlink=True))
    c.save(out/"runtime-environment.json",dict(PATH=env["PATH"],runtime=runtime,staged_CPU_modules=staged))
    filters=["FlashinferCache.RuntimeScheduleReusesActualTilesAcrossKvExtents","FlashinferBatchReplay.ColdRecordAndRuntimeSchedule","FlashinferCache.EmptyRequestsAndAllZeroQueriesUseCheckedNoOp"]
    provider_source=c.read(S/"ready-for-root.json")["provider_source"]
    assert h.same(frozen) and h.same(provider_source) and all(h.same(x) for x in inputs)
    c.save(S/"tests-ready-for-root.json",dict(status="original_native_cache_tests_built_not_run",image=b.identity(image),source=frozen,provider_source=provider_source,identity=b.identity(out/"identity.json"),link_plan=b.identity(out/"link-plan.json"),runtime_environment=b.identity(out/"runtime-environment.json"),suggested_command=[str(image),"--gtest_filter="+":".join(filters),"--gtest_output=xml:tests.xml"],expected_cases=3,filters=filters,CXX=1,links=1,NVCC=0,SDK_builds=0,GPU_runs=0,scope="Original64-step fresh/update/boundary/explicit-fresh/old-output direct and captured journeys, plus empty/no-op. No source edits or new test matrix."))
    print("NATIVE_CACHE_TESTS_READY", image,flush=True)
if __name__ == "__main__": main()
