"""Recompute from consumer JSON/logs and raw PDH samples, without runner summaries."""
from pathlib import Path
from statistics import median
import hashlib
import json
import re

P = Path(__file__).resolve().parent
R = next(p for p in P.parents if (p / 'AGENTS.md').is_file())
raw_files = []

def read(p):
    raw_files.append(p)
    return json.loads(p.read_text(encoding='utf-8-sig'))

def text(p):
    raw_files.append(p)
    return p.read_text(encoding='utf-8')

def stats(v):
    return dict(samples=v, count=len(v), min=min(v), median=median(v), max=max(v))

def maximum(samples, key):
    values = [s[key] for s in samples if s.get(key) is not None]
    return max(values) if values else None

def identity(p):
    data = p.read_bytes()
    return dict(path=str(p.relative_to(R)), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())

rows = []
all_predictions = []
for mode, expected in (('timing', 6), ('memory', 2)):
    folders = sorted(p for p in (P / mode / 'attempt1').iterdir() if p.is_dir())
    assert len(folders) == expected
    for folder in folders:
        process = read(folder / 'result.json')
        arm = process['arm']
        assert process['exit'] == 0 and not process['reader_errors']
        assert process['memory_only'] == (mode == 'memory') and not process['profiler']
        source = read(folder / ('stdout.log' if arm == 'hyle' else 'peer-result.json'))
        stderr = text(folder / 'stderr.log')
        phases = source['phases']
        assert len(phases) == 6 and source['processed_tokens'] == 864 and source['generated_tokens'] == 99
        assert [p['context_after'] for p in phases] == [256, 288, 544, 576, 832, 864]
        predicted = source['generated_ids' if arm == 'hyle' else 'predicted_ids']
        assert len(predicted) == 99
        all_predictions.append(predicted)
        step_re = re.compile(r'^(round\d+_(?:prefill|decode\d+)) tokens=(\d+) visible=(\d+) .*?step_seconds=([\deE+.-]+).*?next=(\d+)$')
        if arm == 'hyle':
            steps = [dict(name=m[1], input_tokens=int(m[2]), visible_tokens=int(m[3]),
                          step_seconds=float(m[4]), predicted_id=int(m[5]))
                     for line in stderr.splitlines() if (m := step_re.match(line))]
            assert len(steps) == 99 and [s['predicted_id'] for s in steps] == predicted
        else:
            steps = source['steps']
            assert len(steps) == 99 and [s['predicted_id'] for s in steps] == predicted
        decode = [p for p in phases if p['kind'] == 'decode']
        prefills = [p for p in phases if p['kind'] == 'prefill']
        stable = [s for s in steps if (m := re.match(r'round\d+_decode(\d+)$', s['name'])) and int(m[1]) >= 7]
        assert len(stable) == 78
        row = dict(mode=mode, process=folder.name, arm=arm,
                   session_seconds=source['session_seconds'],
                   output_tps=99 / source['session_seconds'],
                   processed_tps=864 / source['session_seconds'],
                   full_decode_tps=96 / sum(p['seconds'] for p in decode),
                   stable_decode_7_to32_tps=78 / sum(s['step_seconds'] for s in stable),
                   total_prefill_tps=768 / sum(p['seconds'] for p in prefills),
                   startup_to_last_seconds=source['startup_total_seconds'],
                   outer_process_wall_seconds=process['process_wall_seconds'],
                   phases=[dict(name=p['name'], tokens=p['input_tokens'], seconds=p['seconds'],
                                tps=p['input_tokens'] / p['seconds']) for p in phases])
        if arm == 'hyle':
            prepared = re.findall(r'^prepared T=(\d+) visible=(\d+) replay=(\S+) cold_batch_seconds=([\deE+.-]+) capture_recorded=(\d+) capture_reused=(\d+)', stderr, re.M)
            assert len(prepared) == 99
            row['prefill_combined_cold_seconds'] = [float(p[3]) for p in prepared if int(p[0]) == 256]
            row['prefill_capture_recorded_reused'] = [[int(p[4]), int(p[5])] for p in prepared if int(p[0]) == 256]
            loaded = re.search(r'^weights_load_seconds=([\deE+.-]+)', stderr, re.M)
            ready = re.search(r'^initialized model_seconds=([\deE+.-]+) shape_prepare_seconds=([\deE+.-]+) startup_to_ready_seconds=([\deE+.-]+)', stderr, re.M)
            row['loading'] = dict(model_load_seconds=float(loaded[1]), startup_to_ready_seconds=float(ready[3]))
        else:
            row['loading'] = source['loading']
        if mode == 'memory':
            raw = read(folder / 'memory.json')
            assert raw['pid'] == process['pid'] and not raw['thread_error'] and not raw['gpu_setup_error']
            samples = [s for s in raw['samples'] if s['process_running']]
            keys = ['working_set_bytes', 'os_peak_working_set_bytes', 'private_commit_bytes',
                    'os_peak_commit_bytes', 'gpu_dedicated_bytes', 'gpu_shared_bytes', 'gpu_total_bytes']
            peaks = {k: maximum(samples, k) for k in keys}
            for s in samples:
                if s.get('gpu_dedicated_bytes') is not None and s.get('gpu_shared_bytes') is not None:
                    assert s['gpu_total_bytes'] == s['gpu_dedicated_bytes'] + s['gpu_shared_bytes']
            markers = {m['name']: m['timestamp_ns'] for m in process['markers']}
            windows = []
            for phase in phases:
                name = phase['name']
                begin, end = markers[name + '_begin'], markers[name + '_end']
                interior = [s for s in samples if begin <= s['timestamp_ns'] <= end]
                windows.append(dict(name=name, samples=len(interior),
                    missing_dedicated=sum(s.get('gpu_dedicated_bytes') is None for s in interior),
                    missing_shared=sum(s.get('gpu_shared_bytes') is None for s in interior),
                    sampled_peaks={k: maximum(interior, k) for k in keys},
                    exact_boundary_delta_bytes=None))
            ready = markers['ready_before_prefill']
            first = markers['round1_prefill_begin']
            ready_samples = [s for s in samples if ready <= s['timestamp_ns'] < first]
            row['memory'] = dict(requested_interval_s=raw['requested_interval_s'],
                running_samples=len(samples), all_samples=len(raw['samples']),
                sample_gap_seconds=stats([(b['timestamp_ns']-a['timestamp_ns'])/1e9 for a,b in zip(samples,samples[1:])]),
                sampled_peaks=peaks, windows=windows, ready_to_first_marker_seconds=(first-ready)/1e9,
                ready_baseline_samples=len(ready_samples), exact_ready_baseline_known=False,
                missing_dedicated_samples=sum(s.get('gpu_dedicated_bytes') is None for s in samples),
                missing_shared_samples=sum(s.get('gpu_shared_bytes') is None for s in samples))
        rows.append(row)

assert all(p == all_predictions[0] for p in all_predictions)
groups = {}
for arm in ('hyle', 'peer'):
    selected = [r for r in rows if r['mode'] == 'timing' and r['arm'] == arm]
    groups[arm] = {key: stats([r[key] for r in selected]) for key in
        ['session_seconds', 'output_tps', 'processed_tps', 'full_decode_tps',
         'stable_decode_7_to32_tps', 'total_prefill_tps', 'startup_to_last_seconds', 'outer_process_wall_seconds']}
    groups[arm]['phases'] = [dict(name=selected[0]['phases'][i]['name'],
        seconds=stats([r['phases'][i]['seconds'] for r in selected]),
        tps=stats([r['phases'][i]['tps'] for r in selected])) for i in range(6)]
    groups[arm]['model_load_seconds'] = stats([r['loading']['model_load_seconds'] for r in selected])
    groups[arm]['startup_to_ready_seconds'] = stats([r['loading']['startup_to_ready_seconds'] for r in selected])

memory = {r['arm']: r['memory'] for r in rows if r['mode'] == 'memory'}
table = []
for key, label in [('output_tps', '99 actual returned endpoints / complete session wall'),
                   ('full_decode_tps', '96 decode outputs / sum of three complete D32 phase walls'),
                   ('stable_decode_7_to32_tps', 'Auxiliary78 / sum of each round steps7..32'),
                   ('total_prefill_tps', '768 input tokens / sum of three prefill phase walls')]:
    x, y = [groups[a][key]['median'] for a in ('hyle', 'peer')]
    table.append(dict(metric=label, hyle=x, peer=y, difference_percent=(x/y-1)*100))
for i in range(6):
    x,y=[groups[a]['phases'][i]['tps']['median'] for a in ('hyle','peer')]
    table.append(dict(metric=groups['hyle']['phases'][i]['name']+' tok/s',hyle=x,peer=y,difference_percent=(x/y-1)*100))

windows = {}
for mode in ('timing','memory'):
    windows[mode] = {side:text(P/mode/'attempt1'/('window-'+side+'-gpu.stdout.log')).strip() for side in ('before','after')}

report = dict(schema='hyle.workspace-query.independent-measurement-review.v1',
    scope='Recompute6 timing and2 separate memory processes from original consumer outputs/logs and raw samples. No build, GPU or imported runner summary.',
    groups=groups, processes=rows, memory=memory, publication_table=table,
    all8_process_predictions_equal=True, predictions_per_process=99,
    effective_output_count=99, decode_output_count=96, input_processed_count=864,
    gpu_window_snapshots=windows,
    limitations=[
        'Three timing processes per arm, alternating H/P/P/H/H/P; one separate monitored memory process per arm. No statistical stable-win claim.',
        'Main performance field is99/session wall, not input throughput or averaged phase TPS. Full decode is96/sum(D32 walls), median across processes; stable decode is auxiliary.',
        'Fixed teacher-forced token journey864/context1024 is not a natural conversation, quality benchmark, multi-session or MTP result.',
        'Both arms are slower than the earlier window. Do not attribute that change or this finite Hyle/peer difference to the small query change: the old unmodified Hyle image is not a same-window third arm.',
        'Timing-window outside GPU snapshots report16% then21% utilization and SM2475 then2820MHz. Clocks/background activity were not fixed or continuously profiled.',
        'Source-entry startup_to_last excludes OS process creation/DLL initialization. Outer process wall also includes logs and teardown, and is separate.',
        'Sampled GPU peaks are lower bounds. Dedicated/shared maxima must not be added; total is maximum of simultaneous per-sample sums.',
        'No sample resolves exact ready or phase boundaries. Phase deltas remain unknown; last-phase after-brackets can cross teardown. Missing counter values remain null.',
        'Working set is residency; private commit is commit charge. They overlap and cannot be added as physical RAM. Shared GPU counters can overlap process RAM.',
        '99 predicted IDs match across8 processes, and root separately verified64 vectors. This is not an independent whole-model quality threshold or all-backend claim.'
    ], inputs=[identity(p) for p in dict.fromkeys(raw_files)])
out=P/'independent-review.json'
assert not out.exists()
out.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(report=identity(out),publication_table=table,
    memory_peaks={a:m['sampled_peaks'] for a,m in memory.items()}),ensure_ascii=False))
