from pathlib import Path
import importlib.util, json, os, re, sys, traceback
import xml.etree.ElementTree as ET
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent; R=W.parents[1]
spec=importlib.util.spec_from_file_location('identical_previous', R/'.scratch/inference-alias-role-filter-20261027/build.py')
old=importlib.util.module_from_spec(spec);spec.loader.exec_module(old)
m,h,exact=old.m,old.h,old.exact
m.W=W
CLI=R/'.scratch/inference-generation-batch-continuation-20261027'
TEST=R/'.scratch/inference-alias-role-filter-20261027'
CASES=['GraphRegions.StablePrivateCaptureVariantsReuseBothBoundPortsAfterPreparation',
'GraphRegions.CaptureReuseKeepsFullViewAliasAndPrivateBindingRequirements',
'GraphRegions.CaptureVariantsUseBoundedLruAndClearBeforeForcedChanges',
'GraphRegions.CaptureVariantEndAndSealFailuresCannotPublishAnOldRoute',
'GraphRegions.CapturesCompatibleRangesAroundAnUncapturableCommandInOneSequence']

def environment():
    env=dict(os.environ);env.update(m.read(CLI/'environment.json'))
    parts=[str(W/'bin'),*m.read(CLI/'runtime.json')['PATH'].split(';'),*m.read(TEST/'runtime.json')['PATH'].split(';')]
    seen=set();env['PATH']=';'.join(x for x in parts if x and not (x.casefold() in seen or seen.add(x.casefold())))
    for k in ['HF_HUB_OFFLINE','HF_DATASETS_OFFLINE','TRANSFORMERS_OFFLINE']:env[k]='1'
    return env

def command(template,source,original,out):
    argv=[]
    for i,arg in enumerate(template):
        if i and template[i-1].lower()=='/sourcedependencies':arg=str(out/'dependencies.json')
        elif arg.lower().startswith('/fo'):arg='/Fo'+str(out/'unit.obj')
        elif arg.lower().startswith('/fd'):arg='/Fd'+str(out/'unit.pdb')
        elif arg.lower().endswith(('.cc','.cpp','.cxx')):arg=str(source)
        argv.append(arg)
    argv.insert(1,'/I'+str(original.parent))
    assert m.build_contract(argv)==m.build_contract(template)
    for prefix in ['/Fo','/Fd']:
        values=[x[len(prefix):] for x in argv if x.lower().startswith(prefix.lower())]
        assert len(values)==1 and Path(values[0]).is_relative_to(W)
    return argv

def freeze():
    assert not (W/'build-plan.json').exists()
    cli=m.read(CLI/'cli-link-inputs.json');test=m.read(TEST/'test-link-inputs.json')
    assert len(cli)==224 and len(test)==241
    for row in {m.key(x['path']):x for x in cli+test}.values():exact(row)
    ci,ti=m.index(cli),m.index(test)
    graph=ci[m.key(R/'src/graph/executable.cc')];region=ti[m.key(R/'tests/graph/region_provider_test.cc')]
    assert graph['object']==ti[m.key(R/'src/graph/executable.cc')]['object']
    specs=[('executable','src/graph/executable.cc',TEST/'logs/executable/command.json',graph),
           ('region-test','tests/graph/region_provider_test.cc',Path(region['object']['path']).parent/'command.json',region)]
    pre={};units=[]
    for name,relative,recipe,record in specs:
        source=R/relative;pin=m.pin(source)
        snapshot=W/'source'/relative;snapshot.parent.mkdir(parents=True,exist_ok=True);snapshot.write_bytes(source.read_bytes())
        for path in [*record['data']['Includes'],str(source),str(snapshot),str(R/'include/hyle/graph/detail/replay_access.h')]:
            pre[m.key(path)]=m.pin(path)
        units.append(dict(name=name,original_source=pin,source=m.pin(snapshot),snapshot=m.pin(snapshot),recipe=m.pin(recipe),
             baseline=record,command=command(m.read(recipe)['command'],snapshot,source,W/'compile'/name),object=str(W/'compile'/name/'unit.obj')))
    tests=Path(units[1]['original_source']['path']).read_text(encoding='utf-8')
    names=[a+'.'+b for a,b in re.findall(r'\bTEST(?:_F)?\s*\(\s*(\w+)\s*,\s*(\w+)\s*\)',tests)]
    assert len(names)==len(set(names)) and set(CASES)<=set(names)
    env=environment();(W/'bin').mkdir(exist_ok=True)
    m.save(W/'environment.json',{k:env.get(k,'') for k in ('PATH','INCLUDE','LIB','LIBPATH')})
    m.save(W/'runtime.json',dict(cli=m.pin(CLI/'runtime.json'),component=m.pin(TEST/'runtime.json'),
        cli_runtime=m.read(CLI/'runtime.json'),component_runtime=m.read(TEST/'runtime.json'),PATH=env['PATH']))
    m.save(W/'precompile-dependencies.json',list(pre.values()))
    replacements={'cli':[dict(original=graph['object'],unit='executable')],
                  'test':[dict(original=graph['object'],unit='executable'),dict(original=region['object'],unit='region-test')]}
    m.save(W/'build-plan.json',dict(status='FROZEN_NOT_BUILT',units=units,original_executable=graph,
       cli_baseline=m.pin(CLI/'cli-link-inputs.json'),cli_ready=m.pin(CLI/'ready-cli1.json'),
       test_baseline=m.pin(TEST/'test-link-inputs.json'),test_ready=m.pin(TEST/'ready-test.json'),
       link_replacements=replacements,link_additions={'cli':[],'test':[]},
       dependencies=m.pin(W/'precompile-dependencies.json'),runtime=m.pin(W/'runtime.json'),tests=CASES,
       counts=dict(CXX=2,links=2,cli_inputs=224,test_inputs=241,selected_cases=len(CASES),SDK=0,NVCC=0,downloads=0),
       boundary='Only Graph executable behavior and existing region-test TU change. The latter replaces its original object; no new test TU or registration collision. Existing full capture/private/permission gates remain. Snapshot sources compile with original source include directories.'))
    print('FROZEN 2 CXX / 2 links / 5 host cases',flush=True)
    for u in units:print(u['name']+' '+u['original_source']['sha256'],flush=True)

def compile_unit(name):
    plan=m.read(W/'build-plan.json');unit=next(x for x in plan['units'] if x['name']==name)
    for field in ['source','original_source','recipe']:exact(unit[field])
    out=Path(unit['object']).parent;out.mkdir(parents=True,exist_ok=False)
    pre={m.key(x['path']):x for x in m.read(plan['dependencies']['path'])}
    for row in pre.values():exact(row)
    process=h.execute(unit['command'],environment(),W/'logs'/name,timeout=240)
    data=m.read(out/'dependencies.json')['Data'];assert m.key(data['Source'])==m.key(unit['source']['path'])
    deps=[m.pin(x) for x in dict.fromkeys([data['Source'],*data['Includes']])]
    for row in deps:
        before=pre.get(m.key(row['path']))
        if before:assert row==before,('dependency changed during CXX',row['path'])
        else:assert not Path(row['path']).resolve().is_relative_to(R),('unfrozen local include',row['path'])
    exact(unit['source']);exact(unit['original_source']);m.save(out/'actual-dependencies.json',deps)
    result=dict(name=name,source=unit['source'],original_source=unit['original_source'],snapshot=unit['snapshot'],object=m.pin(unit['object']),
       command=m.pin(W/'logs'/name/'command.json'),compiler_dependencies=m.pin(out/'dependencies.json'),
       actual_dependencies=m.pin(out/'actual-dependencies.json'),process=process)
    m.save(out/'compiled.json',result);print('COMPILED '+name,flush=True)

def link(kind):
    plan=m.read(W/'build-plan.json');rows=m.read(plan[kind+'_baseline']['path'])
    compiled={x['name']:m.read(W/'compile'/x['name']/'compiled.json') for x in plan['units'] if kind=='test' or x['name']=='executable'}
    substitutions={m.key(x['original']['path']):compiled[x['unit']]['object']['path'] for x in plan['link_replacements'][kind]}
    inputs=[compiled[next(x['unit'] for x in plan['link_replacements'][kind] if m.key(x['original']['path'])==m.key(row['path']))]['object']
            if m.key(row['path']) in substitutions else row for row in rows]
    assert len(inputs)==(224 if kind=='cli' else 241)
    for row in inputs:exact(row)
    for unit in compiled.values():
        exact(unit['source']);exact(unit['original_source']);exact(unit['object'])
        for row in m.read(unit['actual_dependencies']['path']):exact(row)
    recipe=CLI/'link-cli1/command.json' if kind=='cli' else TEST/'link-test/command.json'
    image=W/'bin'/('hyle.exe' if kind=='cli' else 'identical-capture-component-test.exe')
    argv=m.link_command(m.read(recipe)['command'],substitutions,[],image)
    m.save(W/(kind+'-link-inputs.json'),inputs)
    process=h.execute(argv,environment(),W/('link-'+kind),timeout=180)
    for row in inputs:exact(row)
    result=dict(image=m.pin(image),link=process,inputs=m.pin(W/(kind+'-link-inputs.json')),
        recipe=m.pin(W/('link-'+kind)/'command.json'),runtime=m.pin(W/'runtime.json'),plan=m.pin(W/'build-plan.json'))
    m.save(W/('ready-'+kind+'.json'),result);print(kind.upper()+'_READY '+result['image']['path']+' '+result['image']['sha256'],flush=True)

def run():
    ready=m.read(W/'ready-test.json');exact(ready['image'])
    for row in m.read(ready['inputs']['path']):exact(row)
    argv=[ready['image']['path'],'--gtest_color=no','--gtest_filter='+':'.join(CASES),'--gtest_output=xml:'+str(W/'run/results.xml')]
    process=h.execute(argv,environment(),W/'run',timeout=180)
    xml=W/'run/results.xml';tree=ET.parse(xml).getroot();cases=tree.findall('./testsuite/testcase')
    actual=[x.attrib['classname']+'.'+x.attrib['name'] for x in cases]
    assert sorted(actual)==sorted(CASES) and len(cases)==len(CASES)
    assert all(x.find('failure') is None and x.find('error') is None and x.find('skipped') is None for x in cases)
    m.save(W/'summary.json',dict(status='PASS',process=process,tests=actual,xml=m.pin(xml),
       CLI=m.pin(W/'ready-cli.json'),component=m.pin(W/'ready-test.json'),plan=m.pin(W/'build-plan.json'),
       counts=dict(CXX=2,links=2,test_processes=1,passed=len(cases),skip=0,SDK=0,NVCC=0,model_processes=0),
       boundary='Five directed host controlled-capture Graph cases only; no CUDA model/GPU inference or performance run.'))
    print('PASS '+str(len(cases))+'/'+str(len(cases))+', 0 skip',flush=True)

if __name__=='__main__':
    try:
        action=sys.argv[1]
        if action=='freeze':freeze()
        elif action=='compile':compile_unit(sys.argv[2])
        elif action=='link':link(sys.argv[2])
        elif action=='run':run()
        else:raise ValueError(action)
    except BaseException:
        (W/('failure-'+ '-'.join(sys.argv[1:])+'.log')).write_text(traceback.format_exc());raise
