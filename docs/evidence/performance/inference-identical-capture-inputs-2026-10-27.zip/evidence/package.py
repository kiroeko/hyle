"""Offline candidate evidence; invoke only after root finishes tests and all12 screens."""
from pathlib import Path
from collections import Counter
import hashlib
import json
import statistics
import xml.etree.ElementTree as ET
import zipfile

W = Path(__file__).resolve().parent
R = W.parents[1]
F = R / '.scratch/inference-generation-batch-continuation-20261027'
DEST = R / 'docs/evidence/performance/inference-identical-capture-inputs-2026-10-27.json'
CACHE = {}


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def pin(path):
    path = Path(path).resolve()
    key = str(path).casefold()
    if key not in CACHE:
        raw = path.read_bytes()
        CACHE[key] = dict(path=str(path), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())
    return dict(CACHE[key])


def exact(row):
    actual = pin(row['path'])
    assert (actual['bytes'], actual['sha256']) == (row['bytes'], row['sha256']), (row, actual)
    return actual


def save(path, value):
    Path(path).write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + '\n', encoding='utf-8')


def facts(value):
    # Exactly screen.py's preregistered predicate, without new exclusions.
    if isinstance(value, list):
        return [facts(item) for item in value]
    if isinstance(value, dict):
        return {key: facts(item) for key, item in value.items()
                if not any(token in key for token in ['seconds', 'per_second', 'capture', 'replay', 'trace_name'])}
    return value


def row_key(row):
    return (str(Path(row['path']).resolve()).casefold(), row['bytes'], row['sha256'])


def verify_unit(unit, dependencies='actual_dependencies'):
    assert unit['process']['exit'] == 0
    original = unit.get('original_source', unit.get('source'))
    snapshot = unit.get('snapshot', unit.get('source'))
    assert original['sha256'] == snapshot['sha256']
    for field in ('object', 'command', 'compiler_dependencies', dependencies):
        exact(unit[field])
    exact(snapshot)
    rows = read(unit[dependencies]['path'])
    for row in rows:
        if row['path'].casefold() == original['path'].casefold():
            assert (row['bytes'], row['sha256']) == (snapshot['bytes'], snapshot['sha256'])
        else:
            exact(row)
    return len(rows)


def main():
    # No runner imports, waits or inferred partial success. Read terminal files
    # before hashing/creating the archive; root explicitly schedules invocation.
    plan, tests, screen = (read(W / name) for name in ('build-plan.json', 'summary.json', 'screen-summary.json'))
    assert tests['status'] == 'PASS_ACROSS_RECORDED_IMAGES' and screen['status'] == 'PASS'
    assert not DEST.exists() and not DEST.with_suffix('.zip').exists()
    exact(tests['plan'])
    setup_failure = read(W / 'screen-attempt1.json')
    assert setup_failure['status'] == 'SETUP_FAILED_BEFORE_MODEL_START'
    assert setup_failure['model_processes'] == 0 and setup_failure['exit'] == 1
    baseline = read(F / 'ready-cli1.json')
    exact(baseline['image']); exact(baseline['inputs']); exact(baseline['runtime'])
    model = baseline['compiled']
    model_dependencies = verify_unit(model)
    assert baseline['image'] == screen['images']['baseline']
    compiled = [read(W / 'compile' / unit['name'] / 'compiled.json') for unit in plan['units']]
    assert len(compiled) == 2
    exact(tests['source_fix'])
    second_freeze = read(tests['source_fix']['path'])
    assert len(second_freeze['units']) == 1 and second_freeze['units'][0]['name'] == 'region-test2'
    compiled.append(read(W / 'compile/region-test2/compiled.json'))
    for unit in compiled:
        unit['verified_dependency_count'] = verify_unit(unit)
    graph = next(unit for unit in compiled if Path(unit.get('original_source', unit['source'])['path']).name == 'executable.cc')
    region = next(unit for unit in compiled if unit['name'] == 'region-test')
    corrected_region = next(unit for unit in compiled if unit['name'] == 'region-test2')
    ready = {kind: read(W / ('ready-' + kind + '.json')) for kind in ('cli', 'test')}
    closure_deltas = {}
    for kind in ('cli', 'test'):
        record = ready[kind]
        for field in ('image', 'inputs', 'recipe', 'runtime'):
            exact(record[field])
        assert record['link']['exit'] == 0
        before = read(plan['cli_baseline' if kind == 'cli' else 'test_baseline']['path'])
        after = read(record['inputs']['path'])
        for row in after:
            exact(row)
        old_graph = plan['original_executable']['object']
        assert before.count(old_graph) == 1
        if kind == 'cli':
            assert len(before) == len(after) == 224
            assert after == [graph['object'] if row == old_graph else row for row in before]
        else:
            # Use actual old/new identities from the build plan. Never infer
            # an original test object from an ambiguous unit.obj filename.
            replacements = plan['link_replacements'][kind]
            replacement_by_key = {row_key(entry['original']): next(unit['object'] for unit in compiled if unit['name'] == entry['unit']) for entry in replacements}
            expected = [replacement_by_key.get(row_key(row), row) for row in before]
            for name in plan.get('link_additions', {}).get(kind, []):
                expected.append(next(unit['object'] for unit in compiled if unit['name'] == name))
            assert after == expected
            assert graph['object'] in after and region['object'] in after
        original_keys, candidate_keys = Counter(map(row_key, before)), Counter(map(row_key, after))
        closure_deltas[kind] = dict(before=len(before), after=len(after),
            removed=[dict(path=key[0], bytes=key[1], sha256=key[2], count=count) for key, count in (original_keys - candidate_keys).items()],
            added=[dict(path=key[0], bytes=key[1], sha256=key[2], count=count) for key, count in (candidate_keys - original_keys).items()])
    ready_test2 = read(W / 'ready-test2.json')
    for field in ('image', 'inputs', 'recipe', 'runtime', 'freeze'):
        exact(ready_test2[field])
    assert ready_test2['link']['exit'] == 0
    before2, after2 = read(ready['test']['inputs']['path']), read(ready_test2['inputs']['path'])
    assert before2.count(region['object']) == 1
    assert after2 == [corrected_region['object'] if row == region['object'] else row for row in before2]
    assert graph['object'] in after2
    closure_deltas['test2'] = dict(before=len(before2), after=len(after2),
        sole_test_replacement=dict(original=region['object'], replacement=corrected_region['object']))
    assert screen['images']['candidate'] == ready['cli']['image']
    runtime = read(W / 'runtime.json')
    for key in ('original', 'original_native_cpu', 'alias'):
        if key in runtime:
            exact(runtime[key])
    for image in screen['images'].values():
        exact(image)
    assert tests['counts'] == dict(CXX_attempts=3, distinct_TUs=2, links=3, test_processes=2,
        unique_cases=5, unique_final_pass=5, test_executions=6, initial_failed_assertions=1,
        skip=0, SDK=0, NVCC=0, model_processes=0)
    final_results, test_review, first_failed = {}, [], []
    for index, episode in enumerate(tests['test_processes']):
        assert index < 2
        exact(episode['xml']); exact(episode['ready'])
        image_ready = read(episode['ready']['path'])
        exact(image_ready['image'])
        assert image_ready == (ready['test'] if index == 0 else ready_test2)
        cases = ET.parse(episode['xml']['path']).getroot().findall('./testsuite/testcase')
        case_results = []
        for case in cases:
            name = case.attrib['classname'] + '.' + case.attrib['name']
            assert case.find('skipped') is None
            failed = any(case.find(key) is not None for key in ('failure', 'error'))
            final_results[name] = not failed
            if index == 0 and failed:
                first_failed.append(name)
            case_results.append(dict(name=name, passed=not failed))
        assert sum(row['passed'] for row in case_results) == episode['passed']
        assert sum(not row['passed'] for row in case_results) == episode['failed']
        assert episode['process']['exit'] == (1 if index == 0 else 0)
        run_dir = W / ('run' if index == 0 else 'run2')
        assert read(run_dir / 'process.json') == episode['process']
        if index == 0:
            assert len(cases) == 5 and len(first_failed) == 1
            assert sorted(row['name'] for row in case_results) == sorted(plan['tests'])
        else:
            assert len(cases) == 1 and [row['name'] for row in case_results] == first_failed
        test_review.append(dict(**episode, image=image_ready['image'], results=case_results))
    assert len(tests['test_processes']) == 2 and all(final_results.values())
    assert sorted(final_results) == sorted(tests['tests']) == sorted(plan['tests'])
    names = sorted(final_results)
    order = [('baseline', 'off'), ('candidate', 'off'), ('candidate', 'auto'), ('baseline', 'auto'),
             ('baseline', 'auto'), ('candidate', 'auto'), ('candidate', 'off'), ('baseline', 'off'),
             ('baseline', 'off'), ('candidate', 'off'), ('candidate', 'auto'), ('baseline', 'auto')]
    assert len(screen['runs']) == 12
    oracles, process_review = {}, []
    for row, expected in zip(screen['runs'], order):
        assert (row['arm'], row['mode']) == expected and row['process']['exit'] == 0
        folder = W / 'screen' / row['name']
        exact(row['report'])
        report = read(folder / 'report.json')
        assert report == read(folder / 'stdout.log')
        assert read(folder / 'process.json') == row['process']
        command = read(folder / 'command.json')['command']
        assert command[0] == screen['images'][row['arm']]['path']
        assert command[command.index('--decode-overlap') + 1] == row['mode']
        assert report['generated_tokens'] == 97 and report['generated_decode_tokens'] == 96
        assert report['live_committed_versions'] == 0
        assert report['overlap_successor_publications'] == (44 if row['mode'] == 'auto' else 0)
        assert report['overlap_successor_refusals'] == report['overlap_successor_discards'] == 0
        selected = facts(report)
        if row['mode'] not in oracles:
            oracles[row['mode']] = selected
        assert selected == oracles[row['mode']]
        process_review.append(dict(name=row['name'], arm=row['arm'], mode=row['mode'], process=row['process'], report=row['report']))
    overlap = {}
    for arm in ('baseline', 'candidate'):
        for mode in ('off', 'auto'):
            rows = [row for row in screen['runs'] if (row['arm'], row['mode']) == (arm, mode)]
            assert len(rows) == 3
            for metric in ('prefill', 'decode', 'total', 'ready_seconds', 'shared_backing_bytes'):
                assert statistics.median(row[metric] for row in rows) == screen['medians'][arm][mode][metric]
            for metric in ('prefill', 'decode', 'total'):
                assert [min(row[metric] for row in rows), max(row[metric] for row in rows)] == screen['ranges'][arm][mode][metric]
                gain = 100 * (screen['medians']['candidate'][mode][metric] / screen['medians']['baseline'][mode][metric] - 1)
                assert gain == screen['candidate_gain_percent'][mode][metric]
    for mode in ('off', 'auto'):
        overlap[mode] = {metric: max(screen['ranges']['baseline'][mode][metric][0], screen['ranges']['candidate'][mode][metric][0]) <= min(screen['ranges']['baseline'][mode][metric][1], screen['ranges']['candidate'][mode][metric][1]) for metric in ('prefill', 'decode', 'total')}
    assert screen['complete_non_time_reports_equal_per_mode']
    assert not screen['memory_peak_sampled'] and not screen['peer_run'] and not screen['mtp_run']
    files = []
    for path in W.rglob('*'):
        if not path.is_file():
            continue
        rel = path.relative_to(W)
        if path.name in ('archive-manifest.json', 'package-result.json') or '__pycache__' in rel.parts:
            continue
        if path.suffix.lower() not in ('.py', '.json', '.diff', '.cc', '.h', '.log', '.txt', '.xml'):
            continue
        if rel.parts[0] not in ('source', 'source2', 'compile', 'logs', 'link-cli', 'link-test', 'link-test2', 'run', 'run2', 'screen') and len(rel.parts) != 1:
            continue
        files.append(path)
    manifest = [dict(archive_path='evidence/' + path.relative_to(W).as_posix(), **pin(path)) for path in sorted(files)]
    save(W / 'archive-manifest.json', manifest)
    files.append(W / 'archive-manifest.json')
    fact_pins = {mode: hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':')).encode()).hexdigest() for mode, value in oracles.items()}
    receipt = dict(schema_version=1, date='2026-10-27', status='PASS', scope='Finite identical-capture-input candidate A/B',
        change='Avoid the replacement-by-port P*M scan when replacement tensors exactly match the already bound tensors. Retain the original full tuple, alias, source/private proof and actual replay/submit validation.',
        complexity='Only the source-level redundant P*M replacement lookup is removed for the fully identical binding case. No instruction-count, universal complexity or measured root-cause claim.',
        counts=dict(CXX=3, distinct_TU=2, links=3, component_processes=2, tests=5,
                    test_executions=6, initial_failed_assertions=1, skipped=0,
                    screen_processes=12, new_peer_processes=0, new_MTP_processes=0, SDK=0, NVCC=0, downloads=0),
        baseline=dict(ready=pin(F / 'ready-cli1.json'), image=baseline['image'], closure=baseline['inputs'], inputs=224,
                      model_source=model['original_source'], model_snapshot=model['source'], model_object=model['object'], model_actual_dependencies=model['actual_dependencies'], verified_dependency_count=model_dependencies,
                      model_public_evidence='docs/evidence/correctness/inference-generation-batch-continuation-2026-10-27.json'),
        candidate=dict(source=graph.get('original_source', graph['source']), snapshot=graph.get('snapshot', graph['source']), image=ready['cli']['image'], graph_object=graph['object'],
                       sole_CLI_replacement=dict(original=plan['original_executable']['object'], replacement=graph['object'])),
        build=dict(plan=pin(W / 'build-plan.json'), units=compiled, CLI=ready['cli'], component_first=ready['test'], component_corrected_fixture=ready_test2, closure_deltas=closure_deltas),
        correctness=dict(status='Five unique cases pass across the two explicitly recorded component images, not one final all-case rerun.',
            cases=names, processes=test_review, source_fix=tests['source_fix'],
            failure_scope='First component image: four pass and one retained old LRU fixture-count failure. Only that corrected fixture case ran on image2. Product Graph object and performance CLI image did not change.'),
        performance=dict(plan=pin(W / 'screen-plan.json'), summary=pin(W / 'screen-summary.json'), runs=process_review,
            medians=screen['medians'], ranges=screen['ranges'], candidate_gain_percent=screen['candidate_gain_percent'], observed_ranges_overlap=overlap,
            complete_non_time_report_equality_per_mode=True, original_fact_predicate='Exactly screen.py facts; clock/rate/capture/replay/trace_name keys only, no added exclusions.', complete_fact_sha256_per_mode=fact_pins,
            setup_failure=dict(receipt=pin(W / 'screen-attempt1.json'), script=pin(W / 'screen-attempt1.py'), facts=setup_failure,
                outcome='Helper lookup AttributeError occurred before any model started. Corrected m.exact lookup; subsequent12 are the only model screen processes, without inference reruns.'),
            conclusion='No net speedup demonstrated. Off decode %.4f%%, auto decode %+.4f%%, auto prefill %.4f%%; retain all overlapping ranges and the negative prefill observation. This is not a new peer/MTP/full-window result.' %
                (screen['candidate_gain_percent']['off']['decode'], screen['candidate_gain_percent']['auto']['decode'], screen['candidate_gain_percent']['auto']['prefill'])),
        limits=['Ordinary CUDA R1 P154 +96 decode only, three observations per image/mode. No significance or general hardware claim.',
                'Shared backing is cache backing, not a sampled full VRAM/RAM peak; no memory observer ran.',
                'No peer/MTP/multi-user or new32-process full comparison was run for this candidate. Earlier full tables remain separately identified.'],
        archive_manifest=pin(W / 'archive-manifest.json'), archive=dict(path=str(DEST.with_suffix('.zip')), files=len(files) + 1, binaries_SDK_models=False))
    DEST.parent.mkdir(parents=True, exist_ok=True)
    save(DEST, receipt)
    with zipfile.ZipFile(DEST.with_suffix('.zip'), 'w', zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
        archive.write(DEST, 'receipt.json')
        for path in sorted(files):
            archive.write(path, 'evidence/' + path.relative_to(W).as_posix())
    with zipfile.ZipFile(DEST.with_suffix('.zip')) as archive:
        assert archive.testzip() is None and len(archive.namelist()) == receipt['archive']['files']
        assert json.loads(archive.read('receipt.json')) == receipt
        for row in manifest:
            data = archive.read(row['archive_path'])
            assert len(data) == row['bytes'] and hashlib.sha256(data).hexdigest() == row['sha256']
        assert all(Path(name).suffix.lower() not in ('.obj', '.exe', '.dll', '.pdb', '.lib', '.gguf', '.metallib') for name in archive.namelist())
    result = dict(status='ARCHIVED_AND_READ_BACK', receipt=pin(DEST), archive=pin(DEST.with_suffix('.zip')), files=receipt['archive']['files'], new_model_or_test_processes=0)
    save(W / 'package-result.json', result)
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
