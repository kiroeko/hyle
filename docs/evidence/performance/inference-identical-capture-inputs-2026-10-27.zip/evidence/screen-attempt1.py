from pathlib import Path
import importlib.util, json, statistics, sys
sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = W.parents[1]
F = R / '.scratch/inference-generation-batch-continuation-20261027'
spec = importlib.util.spec_from_file_location('identical_capture_screen_base', F / 'build.py')
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)
b, h = m.m, m.h

def facts(value):
    if isinstance(value, list):
        return [facts(x) for x in value]
    if isinstance(value, dict):
        return {k: facts(v) for k, v in value.items()
                if not any(x in k for x in ['seconds', 'per_second', 'capture', 'replay', 'trace_name'])}
    return value

def main():
    candidate = b.pin(Path(sys.argv[1]).resolve())
    baseline = b.read(F / 'ready-cli1.json')['image']
    assert not (W / 'screen').exists(), 'No automatic retry or replacement samples'
    images = dict(baseline=baseline, candidate=candidate)
    for image in images.values():
        b.exact(image)
    b.save(W / 'screen-plan.json', dict(images=images, scope='Candidate A/B only; no new reference/MTP/full memory peak window'))
    order = [('baseline', 'off'), ('candidate', 'off'), ('candidate', 'auto'), ('baseline', 'auto'),
             ('baseline', 'auto'), ('candidate', 'auto'), ('candidate', 'off'), ('baseline', 'off'),
             ('baseline', 'off'), ('candidate', 'off'), ('candidate', 'auto'), ('baseline', 'auto')]
    oracle, rows = {}, []
    for index, (arm, mode) in enumerate(order, 1):
        image = images[arm]
        b.exact(image)
        name = f'{index:02d}-{arm}-{mode}'
        out = W / 'screen' / name
        command = [image['path'], '--inputs', str(R / '.scratch/qwen35-unsloth-mtp-20261024/geometry-v2-check/original'),
                   '--backend', 'cuda', '--mtp', 'off', '--capacity', '256', '--steps', '97',
                   '--max-sessions', '1', '--active-sequences', '1', '--decode-overlap', mode]
        process = h.execute(command, m.environment(), out, timeout=180)
        report = json.loads((out / 'stdout.log').read_text(encoding='utf-8-sig'))
        b.save(out / 'report.json', report)
        selected = facts(report)
        if mode not in oracle:
            oracle[mode] = selected
        assert selected == oracle[mode], (name, 'complete non-time report changed')
        assert report['generated_tokens'] == 97 and report['generated_decode_tokens'] == 96
        assert report['live_committed_versions'] == 0
        assert report['overlap_successor_publications'] == (44 if mode == 'auto' else 0)
        assert report['overlap_successor_refusals'] == report['overlap_successor_discards'] == 0
        row = dict(name=name, arm=arm, mode=mode, image=image, process=process,
                   prefill=report['prefill_tokens_per_second'], decode=report['decode_output_tokens_per_second'],
                   total=report['output_tokens_per_second'], ready_seconds=report['startup_to_ready_seconds'],
                   shared_backing_bytes=report['cache_shared_backing_bytes'], report=b.pin(out / 'report.json'))
        rows.append(row)
        b.save(W / 'screen-partial.json', rows)
        print('PASS ' + name + ' ' + json.dumps({k: row[k] for k in ['prefill', 'decode', 'total']}), flush=True)
    medians = {arm: {mode: {metric: statistics.median(x[metric] for x in rows if x['arm'] == arm and x['mode'] == mode)
                           for metric in ['prefill', 'decode', 'total', 'ready_seconds', 'shared_backing_bytes']}
                     for mode in ['off', 'auto']} for arm in images}
    ranges = {arm: {mode: {metric: [min(x[metric] for x in rows if x['arm'] == arm and x['mode'] == mode),
                                          max(x[metric] for x in rows if x['arm'] == arm and x['mode'] == mode)]
                           for metric in ['prefill', 'decode', 'total']}
                     for mode in ['off', 'auto']} for arm in images}
    gains = {mode: {metric: 100 * (medians['candidate'][mode][metric] / medians['baseline'][mode][metric] - 1)
                    for metric in ['prefill', 'decode', 'total']} for mode in ['off', 'auto']}
    b.save(W / 'screen-summary.json', dict(status='PASS', images=images, runs=rows, medians=medians,
          ranges=ranges, candidate_gain_percent=gains, complete_non_time_reports_equal_per_mode=True,
          memory_peak_sampled=False, peer_run=False, mtp_run=False,
          scope='12 interleaved candidate A/B processes: ordinary CUDA R1 P154 +96 decode, three each image/mode. Cache backing is not total VRAM peak.'))
    print('MEDIANS ' + json.dumps(medians), flush=True)
    print('GAINS ' + json.dumps(gains), flush=True)

if __name__ == '__main__':
    main()
