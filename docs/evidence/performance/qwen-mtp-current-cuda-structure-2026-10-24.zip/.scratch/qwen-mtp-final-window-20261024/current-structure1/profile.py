"""Two current MTP images, one CUDA-node trace each; diagnostic only."""
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

S = Path(__file__).resolve().parent
W = S.parent / 'current-window2'
R = S.parents[2]
NSYS = Path('C:/Program Files/NVIDIA Corporation/Nsight Systems 2026.1.3/target-windows-x64/nsys.exe')


def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def save(path, value):
    with path.open('x', encoding='utf-8') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')


def main():
    for arm, previous in (('hyle_mtp', '02-hyle_mtp'), ('peer_mtp', '04-peer_mtp')):
        out = S / arm
        out.mkdir(exist_ok=False)
        original = read(W / 'natural-timing1' / previous / 'command.json')
        native = original['command'][:]
        image = Path(native[0])
        actual = dict(bytes=image.stat().st_size, sha256=hashlib.sha256(image.read_bytes()).hexdigest())
        if any(actual[k] != original['image'][k] for k in actual):
            raise ValueError('Trace image differs from the actual current measured image')
        if '--output' in native:
            native[native.index('--output') + 1] = str(out / 'consumer-result.json')
        ready = read(W / ('hyle-ready.json' if arm == 'hyle_mtp' else 'peer-ready.json'))
        runtime = read(Path(ready['runtime_environment']['path']))
        env = dict(os.environ, PATH=runtime['PATH'])
        command = [str(NSYS), 'profile', '--trace=cuda,cublas', '--cuda-graph-trace=node',
            '--sample=none', '--cpuctxsw=none', '--discard-environment=true',
            '--duration=20', '--stats=false', '--export=sqlite', '--output=' + str(out / 'trace'), *native]
        plan = dict(command=command, cwd=str(R), source_command=str(W / 'natural-timing1' / previous / 'command.json'),
            image=original['image'], runtime=ready['runtime_environment'],
            profiler=True, throughput_evidence=False, memory_evidence=False,
            background_static_HTTP_active=True, purpose='Current MTP work/kernel/API structure; no unprofiled speed or host-gap magnitude claim.')
        save(out / 'command.json', plan)
        start = time.time()
        timed_out = False
        with (out / 'stdout.log').open('wb') as stdout, (out / 'stderr.log').open('wb') as stderr:
            process = subprocess.Popen(command, cwd=R, env=env, stdout=stdout, stderr=stderr)
            save(out / 'live.json', dict(pid=process.pid, started=start, **plan))
            try:
                status = process.wait(timeout=120)
            except subprocess.TimeoutExpired:
                timed_out = True
                subprocess.run(['taskkill', '/PID', str(process.pid), '/T', '/F'], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                status = process.wait(timeout=15)
        result = dict(exit=status, timed_out=timed_out, started=start, elapsed=time.time()-start,
            finished_at=datetime.now(timezone.utc).isoformat(), **plan)
        save(out / 'process.json', result)
        print(arm, 'exit', status, 'timed_out', timed_out, flush=True)
        if status or timed_out:
            raise SystemExit(status or 1)


if __name__ == '__main__':
    main()
