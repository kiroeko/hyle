"""Read the two current traces; keep structural facts separate from TPS."""
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import sqlite3
import statistics
import zipfile

S = Path(__file__).resolve().parent
R = S.parents[2]
D = R / 'docs/evidence/performance'
NAME = 'qwen-mtp-current-cuda-structure-2026-10-24'


def identity(path):
    raw = path.read_bytes()
    return dict(path=path.relative_to(R).as_posix(), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def one(arm):
    folder = S / arm
    process = read(folder / 'process.json')
    if process['exit'] != 0 or process['timed_out']:
        raise ValueError('Profiler process did not complete')
    db = sqlite3.connect('file:' + (folder / 'trace.sqlite').as_posix() + '?mode=ro', uri=True)
    streams = db.execute('SELECT f.value,c.value FROM ProcessStreams p JOIN StringIds f ON f.id=p.filenameId JOIN StringIds c ON c.id=p.contentId').fetchall()
    for name, content in streams:
        if 'stdout_' not in name and 'stderr_' not in name:
            continue
        path = folder / ('native-stdout.log' if 'stdout_' in name else 'native-stderr.log')
        if path.is_file():
            if path.read_text(encoding='utf-8') != content:
                raise ValueError('Extracted native stream differs')
        else:
            path.write_text(content, encoding='utf-8')
    if arm == 'hyle_mtp':
        raw = json.loads(next(line for line in (folder / 'native-stdout.log').read_text(encoding='utf-8').splitlines() if line.startswith('{')))
    else:
        raw = read(folder / 'consumer-result.json')
    calls = db.execute('SELECT s.value,r.start,r.end,r.correlationId,r.returnValue FROM CUPTI_ACTIVITY_KIND_RUNTIME r JOIN StringIds s ON r.nameId=s.id ORDER BY r.start').fetchall()
    launches = [row for row in calls if row[0].startswith('cudaGraphLaunch')]
    groups = {}
    launch_rows = []
    for name, start, end, cid, returned in launches:
        count, first, last, total = db.execute('SELECT count(*),min(start),max(end),sum(end-start) FROM CUPTI_ACTIVITY_KIND_KERNEL WHERE correlationId=?', (cid,)).fetchone()
        copies = [dict(kind=kind, count=n, bytes=size, activity_ns=duration) for kind,n,size,duration in
            db.execute('SELECT copyKind,count(*),sum(bytes),sum(end-start) FROM CUPTI_ACTIVITY_KIND_MEMCPY WHERE correlationId=? GROUP BY copyKind', (cid,))]
        item = dict(correlation_id=cid, api_start_ns=start, api_end_ns=end, return_value=returned,
            kernel_count=count, first_kernel_ns=first, last_kernel_ns=last,
            kernel_activity_ns=total, copies=copies)
        launch_rows.append(item)
        groups.setdefault(count, []).append(item)
    buckets = []
    for count, rows in groups.items():
        buckets.append(dict(kernels=count, launches=len(rows),
            median_kernel_activity_ns=statistics.median(row['kernel_activity_ns'] for row in rows),
            median_first_to_last_kernel_span_ns=statistics.median(row['last_kernel_ns']-row['first_kernel_ns'] for row in rows),
            median_copy_bytes=statistics.median(sum(copy['bytes'] for copy in row['copies']) for row in rows),
            median_copy_activity_ns=statistics.median(sum(copy['activity_ns'] for copy in row['copies']) for row in rows)))
    allocation_events = [dict(api=name, start_ns=start, end_ns=end,
        launches_already_started=sum(row[1] < start for row in launches))
        for name,start,end,cid,ret in calls if name.startswith(('cuMemAlloc_v2', 'cudaMalloc_v'))]
    instantiation_events = [dict(api=name, start_ns=start, end_ns=end,
        launches_already_started=sum(row[1] < start for row in launches))
        for name,start,end,cid,ret in calls if name.startswith('cudaGraphInstantiate')]
    top = [dict(kernel=name, grid=[x,y,z], count=count, activity_ns=duration) for name,x,y,z,count,duration in db.execute(
        'SELECT s.value,k.gridX,k.gridY,k.gridZ,count(*),sum(k.end-k.start) FROM CUPTI_ACTIVITY_KIND_KERNEL k JOIN StringIds s ON s.id=k.demangledName WHERE k.graphId!=0 GROUP BY s.value,k.gridX,k.gridY,k.gridZ ORDER BY sum(k.end-k.start) DESC LIMIT 12')]
    keys = ('generated_tokens','turn_count','prefill_target_rows','prefill_draft_rows','verified_target_rows',
        'actual_target_rows','actual_draft_rows','accepted_drafts','draft_rounds','proposals','target_decode_calls','draft_decode_calls')
    return dict(process=identity(folder/'process.json'), image=process['image'],
        actual_work={key: raw.get(key) for key in keys}, graph_launches=len(launches),
        captured_kernel_buckets=buckets, captured_launch_details=launch_rows,
        allocation_events=allocation_events, instantiation_events=instantiation_events,
        allocation_api_counts=dict(Counter(row['api'] for row in allocation_events)),
        allocation_counts_by_api_and_prior_launches={name: dict(Counter(row['launches_already_started']
            for row in allocation_events if row['api']==name)) for name in sorted({row['api'] for row in allocation_events})},
        allocation_counts_by_prior_launches=dict(Counter(row['launches_already_started'] for row in allocation_events)),
        instantiation_counts_by_prior_launches=dict(Counter(row['launches_already_started'] for row in instantiation_events)),
        captured_top_kernels=top,
        diagnostic_events=[dict(timestamp=t,severity=severity,text=text) for t,severity,text in db.execute('SELECT timestamp,severity,text FROM DIAGNOSTIC_EVENT')])


def main():
    output, archive_path = D/(NAME+'.json'), D/(NAME+'.zip')
    if output.exists() or archive_path.exists():
        raise ValueError('Do not replace published evidence')
    arms = {arm: one(arm) for arm in ('hyle_mtp','peer_mtp')}
    files = [Path(__file__), S/'profile.py']
    for arm in arms:
        files += [path for path in (S/arm).iterdir() if path.is_file() and path.name not in ('trace.nsys-rep','live.json')]
    with zipfile.ZipFile(archive_path,'x',zipfile.ZIP_DEFLATED,compresslevel=6) as target:
        for path in sorted(files): target.write(path,path.relative_to(R).as_posix())
    record = dict(created_at=datetime.now(timezone.utc).isoformat(), status='diagnostic_completed',
        baseline=identity(D/'qwen-mtp-single-and-multiturn-2026-10-24.json'),
        throughput_evidence=False, memory_evidence=False, product_changes=0,
        scope='One node-level Nsight Systems trace per current MTP image, same real two-turn workload and immutable images as the formal window.',
        arms=arms,
        findings=[
            'Hyle132 captured launches equal its66 K1 decode calls times draft/target. Peer116 captures cover only part of its65 native decode calls; other calls execute eagerly. Graph launch counts are not logical-call counts.',
            'Hyle2357 of2458 cuMemAlloc calls precede the first captured decode launch. Remaining101 calls cluster at first shape/slot and the second-turn boundary. The last48 launches have no new allocation or graph instantiation; the trace does not show an allocator call on every token.',
            'Hyle target captured graphs have738 kernels, peer727; draft graphs have37/41 versus34. These are actual graph structures, not complete process/kernel count equality.',
            'Each of66 Hyle target captures contains135 D2D copies: payload median39,731,200B, range39,702,528..42,856,448B. Their measured copy activity is small relative to complete decode; removing all of it cannot be claimed to recover the full speed gap.',
            'Both current target/draft vocabulary contractions remain large bandwidth workloads. Hyle small-row projections use cuBLAS WMMA kernels; peer uses its mul_mat_f implementation. This trace identifies work and candidates, not a proof that swapping algorithms improves end-to-end throughput.',
            'No new redundant hot allocation was established. Cold variants remain necessary until a source/owner/shape-equivalent replacement is demonstrated; the closed M2 down, row-split and Top1 experiments remain closed.'
        ],
        limits=['One instrumented process per arm; node tracing and cuBLAS tracing add overhead. Background static HTTP continued. No unprofiled TPS, host scheduling time or causal100ms decomposition is inferred.',
            'Natural continuations/acceptance and total verified rows differ across engines. Captured-only kernel buckets omit eager work and do not represent equal complete workloads.',
            'Sum of GPU activities is not host wall time; first-to-last-kernel span also includes copies, dependencies and profiler effects. Copy counts are observed work, not automatically redundant or legally removable.',
            'Allocation and graph-instantiation positions are recorded relative to observed launch starts; later first-use and the warm second prefill are included. No per-allocation source or lifetime is inferred solely from timing.',
            'Allocation events include both runtime cudaMalloc and driver cuMemAlloc APIs, which can be nested. API counts are reported separately and must not be summed as independent physical allocations. The2458/2357/101 finding refers only to cuMemAlloc_v2.'],
        files=[identity(path) for path in sorted(files)], archive=identity(archive_path))
    with output.open('x',encoding='utf-8') as stream:
        json.dump(record,stream,ensure_ascii=False,indent=2,allow_nan=False)
        stream.write('\n')
    print(json.dumps(dict(evidence=identity(output),archive=record['archive'])))


if __name__=='__main__':
    main()
