from pathlib import Path
import re,json,hashlib,collections,difflib
W=Path('.scratch/inference-sampling-three-arm-20261026').resolve();D=W/'behavior2'
def pin(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def clock(s):return re.sub(r'\b(\w*seconds)=\S+',r'\1=<TIME>',s)
def category(l):
 if l.startswith('ggml_backend_cuda_graph_compute:'):return 'original_native_GGML_graph_warmup'
 if l.startswith(('planned_replay ','prepared T=')):return 'explicit_replay_capture_diagnostics'
 if l.startswith(('compile full text finite family ','compiled text finite family ','compiled T=')):return 'cold_graph_topology_and_footprint'
 return 'other'
result={'scope':'Offline classification of original behavior2 stderr, no log edits or new run. Clocks removed only for comparison; all unclassified residual differences preserved.','arms':{}};logs={}
for arm in ('control','batch','hybrid'):
 p=D/arm/'stderr.log';lines=p.read_text(encoding='utf-8-sig').splitlines();logs[arm]=lines
 counts=collections.Counter(category(l) for l in lines);warm=collections.Counter(l for l in lines if category(l)=='original_native_GGML_graph_warmup');routes=collections.Counter(re.search(r'\breplay=(\S+)',l)[1] for l in lines if l.startswith('prepared T='));reused=sum(bool(re.search(r'capture_reused=([1-9]\d*)',l)) for l in lines if l.startswith('prepared T='))
 result['arms'][arm]={'raw':pin(p),'line_categories':dict(counts),'native_warmup_messages':dict(warm),'replay_member_observations':dict(routes),'member_observations_with_reuse':reused}
base=[clock(l) for l in logs['control'] if category(l)=='other'];comparisons={}
for arm in ('batch','hybrid'):
 other=[clock(l) for l in logs[arm] if category(l)=='other'];residual=list(difflib.unified_diff(base,other,fromfile='control',tofile=arm,lineterm=''))
 detailed={}
 for cat in ('cold_graph_topology_and_footprint','explicit_replay_capture_diagnostics'):
  a=collections.Counter(clock(l) for l in logs['control'] if category(l)==cat);b=collections.Counter(clock(l) for l in logs[arm] if category(l)==cat)
  detailed[cat]={'control_only':dict(a-b),'candidate_only':dict(b-a)}
 comparisons[arm]={'unclassified_ordered_non_clock_difference_lines':residual,'classified_differences':detailed}
result['comparisons']=comparisons;result['unclassified_difference_line_count']=sum(len(x['unclassified_ordered_non_clock_difference_lines']) for x in comparisons.values());result['status']='NO_UNEXPECTED_WORK_DIFFERENCE' if not result['unclassified_difference_line_count'] else 'UNCLASSIFIED_DIFFERENCES_RETAINED';result['boundaries']=['Cold graph node/step/provider/workspace differences are expected consequences of the batched sampling graph or captured replay, not additional model target rows. Full stdout IDs/ledger/RNG/work equality is separately recorded by the actual behavior and screen.','Prepared and capture counts may repeat per member; do not equate512 observations with512 independent captures.','Original native GGML warmup output differences remain counted; not silently normalized out.']
p=W/'behavior2/stderr-classification.json';p.write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8');print(json.dumps({'classification':pin(p),'status':result['status'],'unclassified_lines':result['unclassified_difference_line_count'],'arms':result['arms'],'unclassified_first':{a:v['unclassified_ordered_non_clock_difference_lines'][:14] for a,v in comparisons.items()}},indent=2))
