from pathlib import Path
import hashlib, importlib.util, inspect, json, math, os, re, statistics, sys
sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = W.parents[1]
ARMS = ['control', 'batch', 'hybrid']
def read(p): return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def save(p, d):
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(d, indent=2) + '\n', encoding='utf-8')
def module(name, p):
    spec = importlib.util.spec_from_file_location(name, p)
    m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m); return m
def normalize(x):
    if isinstance(x, list): return [normalize(v) for v in x]
    if isinstance(x, dict):
        return {k: normalize(v) for k, v in x.items() if not any(t in k for t in
            ['seconds', 'tokens_per_second', 'clock_unix', 'unix_ns', 'unix_ms'])}
    return x
def differences(a, b, path='$'):
    if type(a) is not type(b): return [dict(path=path, control=a, candidate=b)]
    if isinstance(a, dict):
        out = []
        for k in sorted(set(a) | set(b)):
            if k not in a or k not in b: out.append(dict(path=path+'.'+k, control=a.get(k), candidate=b.get(k)))
            else: out.extend(differences(a[k], b[k], path+'.'+k))
        return out
    if isinstance(a, list):
        if len(a) != len(b): return [dict(path=path, control_length=len(a), candidate_length=len(b))]
        return [d for i, (x, y) in enumerate(zip(a, b)) for d in differences(x, y, f'{path}[{i}]')]
    return [] if a == b else [dict(path=path, control=a, candidate=b)]
def report(folder):
    return json.loads(next(x for x in reversed((folder/'stdout.log').read_text(encoding='utf-8').splitlines()) if x.startswith('{')))
def stderr_facts(folder):
    rows = [dict(re.findall(r'(\w+)=([^ ]+)', x)) for x in (folder/'stderr.log').read_text(encoding='utf-8').splitlines() if x.startswith('prepared ')]
    return dict(member_observations=len(rows), modes={mode:sum(x.get('replay')==mode for x in rows) for mode in ['commands','hybrid','capture']},
                observations_with_reuse=sum(int(x.get('capture_reused',0))>0 for x in rows),
                limits='Per-member prepared reports can repeat a single shared invocation; these are not independent capture counts.')
def env_for(d):
    env = os.environ.copy(); env.update(d['environment_overrides']); return env
def stat(v): return dict(samples=v, median=statistics.median(v), min=min(v), max=max(v))

action = sys.argv[1]
assert action in ('behavior2', 'screen')
commands = {a:read(W/'commands'/f'{a}.json') for a in ARMS}
for d in commands.values():
    assert hashlib.sha256(Path(d['image']['path']).read_bytes()).hexdigest()==d['image']['sha256']
    assert d['command'][1:]==commands['control']['command'][1:]
out = W/action
assert not out.exists(), 'Never overwrite or pool previous runs'
out.mkdir()
if action == 'behavior2':
    h = module('sampling_behavior', R/'.scratch/inference-synchronous-step-report-20261025/check_host.py')
    baseline = None; runs = []
    for arm in ARMS:
        folder = out/arm; d = commands[arm]
        process = h.execute(d['command'], env_for(d), folder, timeout=120)
        raw = report(folder); actual = normalize(raw)
        if baseline is None: baseline = actual; save(out/'control-nontime.json', baseline)
        delta = differences(baseline, actual); save(folder/'nontime-differences.json', delta)
        facts = stderr_facts(folder); save(folder/'prepared-facts.json', facts)
        runs.append(dict(arm=arm, process=process, differences=len(delta), prepared=facts))
        save(out/'runs.json', runs)
        assert not delta, 'Unexpected non-time difference; stop and retain raw'
        assert not raw['mtp'] and raw['session_count']==4 and raw['turn_count']==8 and raw['active_sequences']==4
        if arm=='hybrid': assert facts['modes']['hybrid']>0 and facts['observations_with_reuse']>0
    save(out/'summary.json', dict(status='PASS_FULL_NONTIME_EQUAL', runs=runs, throughput_claim=False))
else:
    assert read(W/'behavior2/summary.json')['status']=='PASS_FULL_NONTIME_EQUAL'
    baseline = read(W/'behavior2/control-nontime.json')
    m = module('sampling_screen', R/'.scratch/mtp-performance-convergence-20261025/baseline/window.py')
    m.WORKLOAD = 'two-turn'; h = m.helpers()
    src = inspect.getsource(h.execute)
    assert src.count('process.wait(timeout=900)')==1
    ns = dict(h.execute.__globals__)
    exec(compile(src.replace('process.wait(timeout=900)','process.wait(timeout=120)'), inspect.getsourcefile(h.execute), 'exec'), ns)
    execute = ns['execute']
    plan = read(W/'command-arguments.json'); runs=[]; memory={}
    save(out/'plan.json', {k:plan[k] for k in ['planned_timing_order','planned_memory_order','timing_processes','independent_memory_processes']})
    h.gpu_snapshot(out, 'before')
    try:
        for mode, order in [('timing',plan['planned_timing_order']), ('memory',plan['planned_memory_order'])]:
            for index, arm in enumerate(order, 1):
                folder=out/f'{mode}-{index:02}-{arm}'; d=commands[arm]
                print('BEGIN',mode,index,arm,flush=True)
                process=execute(folder,arm,d['command'],env_for(d),mode=='memory')
                raw=report(folder); delta=differences(baseline,normalize(raw))
                save(folder/'nontime-differences.json',delta); assert not delta, 'Non-time work changed; stop'
                facts=stderr_facts(folder); save(folder/'prepared-facts.json',facts)
                assert facts==read(W/'behavior2'/arm/'prepared-facts.json'), 'Prepared behavior changed; stop'
                assert math.isclose(raw['prefill_seconds']+raw['decode_seconds'],raw['session_seconds'],rel_tol=1e-5,abs_tol=2e-6)
                metrics={k:raw[k] for k in ['prefill_tokens_per_second','decode_output_tokens_per_second','output_tokens_per_second','prefill_seconds','decode_seconds','session_seconds']}
                runs.append(dict(arm=arm,mode=mode,index=index,pid=process['pid'],exit=process['exit'],metrics=metrics))
                save(out/'runs.json',runs)
                if mode=='memory':
                    mem=read(folder/'memory-summary.json')
                    assert mem['setup_error'] is None and mem['thread_error'] is None
                    memory[arm]=mem
                print('END',mode,index,arm,flush=True)
    finally: h.gpu_snapshot(out,'after')
    metrics={a:{k:stat([r['metrics'][k] for r in runs if r['arm']==a and r['mode']=='timing']) for k in runs[0]['metrics']} for a in ARMS}
    comparisons={a:{k:dict(relative_percent=(metrics[a][k]['median']/metrics['control'][k]['median']-1)*100,
        ranges_overlap=not(metrics[a][k]['min']>metrics['control'][k]['max'] or metrics['control'][k]['min']>metrics[a][k]['max'])) for k in metrics[a]} for a in ['batch','hybrid']}
    work={k:raw[k] for k in ['generated_tokens','generated_decode_tokens','prefill_target_rows','logical_prompt_tokens','actual_graph_calls','decode_graph_calls','prefill_graph_calls']}
    save(out/'summary.json',dict(status='FINITE_SCREEN_COMPLETE_ALL_WORK_EQUAL',runs=runs,metrics=metrics,comparisons=comparisons,memory=memory,work=work,
        limits='Three timing processes and one independent sampled-memory process per arm. Hyle-only random R4 ordinary screen; no greedy/MTP/peer improvement claim, no statistical-significance certificate.'))
print('TERMINAL',action,'GPU_RELEASED',flush=True)
