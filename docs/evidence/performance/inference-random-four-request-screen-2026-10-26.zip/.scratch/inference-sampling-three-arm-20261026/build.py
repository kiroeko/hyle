"""Compile only two formal Model TUs; retained formal entry and native closure."""
import hashlib,importlib.util,json,os,shutil,sys
from pathlib import Path
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;R=W.parents[1];B=R/'.scratch/inference-current-control-b346-20261026'
spec=importlib.util.spec_from_file_location('retained_only_host_build',R/'.scratch/inference-synchronous-step-report-20261025/check_host.py');h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
def read(p):return json.loads(Path(p).read_bytes())
def pin(p):
 p=Path(p).resolve();b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def save(p,x):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,indent=2)+'\n',encoding='utf-8')
def key(p):return os.path.normcase(str(Path(p).resolve()))
choices={'batch':{'main':R/'.scratch/inference-batched-text-sampling-20261026/source/engine/models/qwen35/main.cc','header':R/'.scratch/inference-batched-text-sampling-20261026/source/engine/inference/sampling_graph.h','main_sha':'dfaa530b2148a31d3834f0b62c4f123d5fc6983be9f37652395269db2b69dfc6','header_sha':'085be10d28ae789a7fb576d372c23b8cdefede0bbc6ac4c8e4c66328d75a17d5'},'hybrid':{'main':R/'.scratch/inference-sampling-hybrid-replay-20261026/source/engine/models/qwen35/main.cc','header':R/'engine/inference/sampling_graph.h','main_sha':'7a2f85c1dd8e7f9866bd29c943676d672ddb93aaeb81b822d3726fd10b667952','header_sha':'d066651db9acba82ca5b96d8f35ccceefd60e96c2c61e6e5040389f8f71485bb'}}
def build(arm):
 target=W/arm;target.mkdir(exist_ok=True);assert not (target/'ready.json').exists();selected=choices[arm]
 baseline=read(B/'ready.json');assert pin(baseline['image']['path'])==baseline['image'];assert baseline['image']['sha256']=='ddb447ac4dea2d6cf031a510303fe99343727f16d4b770eefc05131f55ef16c4'
 assert pin(R/'engine/models/qwen35/main.cc')['sha256']=='b346d408cdf8226b2df464f757483cc3aecd5b7c2f2d7f290751c7115d3cc44c'
 frozen=[]
 for kind,rel in [('main','engine/models/qwen35/main.cc'),('header','engine/inference/sampling_graph.h')]:
  assert pin(selected[kind])['sha256']==selected[kind+'_sha'];dest=target/'source'/rel;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(selected[kind],dest);frozen.append({'path':rel,'original':pin(selected[kind]),'frozen':pin(dest)})
 save(target/'source-pins.json',{'files':frozen,'canonical_baseline':baseline['canonical_main'],'formal_model_not_test_main':True})
 main=target/'source/engine/models/qwen35/main.cc';stage=target/'compile';obj=stage/'unit.obj';old=read(B/'compile/command.json')['command'];compiler=old[0]
 cmd=[str(main) if key(x)==key(R/'engine/models/qwen35/main.cc') else x for x in old]
 cmd[cmd.index('/sourceDependencies')+1]=str(stage/'dependencies.json');cmd=[('/Fo'+str(obj)) if x.startswith('/Fo') else ('/Fd'+str(stage/'unit.pdb')) if x.startswith('/Fd') else x for x in cmd]
 cmd[1:1]=['/I'+str(main.parent)]
 assert all(x in cmd for x in ('/W4','/WX','/DHYLE_COMPUTE_CUDA=1','/DGGML_USE_CUDA','/MD','/O2'))
 env=h.discover_environment(compiler='msvc',cache={'CMAKE_C_COMPILER':compiler,'CMAKE_CXX_COMPILER':compiler,'CMAKE_GENERATOR':'Ninja'},backends=()).env
 compiled=read(stage/'process.json') if (stage/'process.json').exists() else h.execute(cmd,env,stage,timeout=120);assert compiled['exit']==0;dep=read(stage/'dependencies.json')['Data'];actual=[pin(p) for p in dict.fromkeys([dep['Source'],*dep['Includes']])];save(stage/'actual-dependencies.json',actual)
 before={key(x['path']):x for x in read(B/'compile/actual-dependencies.json')};mapped={}
 for item in actual:
  p=Path(item['path']);canonical=R/p.relative_to(target/'source') if p.is_relative_to(target/'source') else p;mapped[key(canonical)]=item
 assert set(mapped)==set(before),'Unexpected new header domain'
 changed=[k for k in mapped if mapped[k]['sha256']!=before[k]['sha256']];expected=[key(R/'engine/models/qwen35/main.cc')]
 if arm=='batch':expected.append(key(R/'engine/inference/sampling_graph.h'))
 assert set(changed)==set(expected),(changed,expected)
 assert len([x for x in actual if key(x['path']).endswith('sampling_graph.h')])==1
 save(target/'dependency-differences.json',{'changed':[{'canonical':k,'baseline':before[k],'candidate':mapped[k]} for k in changed],'unchanged':len(actual)-len(changed),'no_new_headers':True})
 linkdir=target/'link';oldargs=read(B/'link/process/command.json')['command'];oldobj=baseline['app'];assert sum(key(x)==key(oldobj['path']) for x in oldargs)==1
 link=[str(obj) if key(x)==key(oldobj['path']) else x for x in oldargs if not x.lower().startswith(('/out:','/pdb:','/implib:','/map:'))]
 link.extend(['/OUT:'+str(linkdir/'hyle.exe'),'/PDB:'+str(linkdir/'hyle.pdb'),'/IMPLIB:'+str(linkdir/'hyle.lib')])
 oldinputs=read(B/'link-inputs.json');newinputs=[pin(Path(x)) for x in link if Path(x).is_absolute() and Path(x).suffix.lower() in ('.obj','.lib')]
 unchanged=[x for x in newinputs if key(x['path'])!=key(obj)];expected_inputs=[x for x in oldinputs if key(x['path'])!=key(oldobj['path'])];assert unchanged==expected_inputs
 systems=[x for x in link if not Path(x).is_absolute() and not x.startswith('/') and x.lower().endswith('.lib')];assert len(unchanged)==221 and len(systems)==13,(len(unchanged),len(systems))
 assert any('engine' in x['path'] and 'entry' in x['path'] for x in unchanged)
 save(target/'link-inputs.json',newinputs);save(target/'link-contract.json',{'unchanged_absolute':221,'system_libraries':systems,'baseline_model':oldobj,'replacement_model':pin(obj),'retains_original_formal_entry':True})
 linked=h.execute(link,env,linkdir/'process',timeout=120)
 runtime=read(B/'runtime.json');native=Path(runtime['native']['path']);alias=linkdir/Path(runtime['native_hardlink']['path']).name;os.link(native,alias);assert os.path.samefile(native,alias);runtime['native_hardlink']=pin(alias);save(target/'runtime.json',runtime)
 save(target/'ready.json',{'status':'FORMAL_MODEL_BUILT_NOT_RUN','arm':arm,'image':pin(linkdir/'hyle.exe'),'app':pin(obj),'source_pins':pin(target/'source-pins.json'),'runtime':pin(target/'runtime.json'),'compile':compiled,'link':linked,'link_inputs':pin(target/'link-inputs.json'),'link_contract':pin(target/'link-contract.json'),'actual_dependencies':pin(stage/'actual-dependencies.json'),'GPU_runs':0,'other_TU_or_SDK_builds':0})
 print(json.dumps(read(target/'ready.json'),indent=2),flush=True)
if __name__=='__main__':build(sys.argv[1])
