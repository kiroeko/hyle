"""Root-only explicit single Hyle profile; reuse original work gate/watchdog."""
from pathlib import Path
import importlib.util
import sys

sys.dont_write_bytecode = True
D = Path(__file__).resolve().parent
W = D.parents[1]
spec = importlib.util.spec_from_file_location('original_pair_run', W / 'run.py')
original = importlib.util.module_from_spec(spec); spec.loader.exec_module(original)
original.W = D

if __name__ == '__main__':
    assert len(sys.argv) == 1, 'One Hyle profile only, no peer/retry action'
    original.run('hyle')
