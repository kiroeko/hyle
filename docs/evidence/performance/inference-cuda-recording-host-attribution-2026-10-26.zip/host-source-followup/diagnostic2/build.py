"""Explicit Root action: two Graph host compilations, one retained link."""
from pathlib import Path
import importlib.util
import os
import sys

sys.dont_write_bytecode = True
D = Path(__file__).resolve().parent
W = D.parents[1]
R = W.parents[1]

def load(name, p):
    spec = importlib.util.spec_from_file_location(name, p)
    mod = importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
    return mod

m = load('graph_trace_plan', D / 'prepare.py')
h = load('retained_graph_executor', R / '.scratch/inference-synchronous-step-report-20261025/check_host.py')

def build():
    plan = m.read(D / 'plan.json')
    for field in ('source_pins', 'baseline_dependencies', 'build_plan', 'baseline_ready', 'baseline_link_inputs', 'baseline_runtime'):
        m.exact(plan[field])
    if (D / 'compile').exists() or (D / 'hyle/link').exists():
        raise FileExistsError('One build only; preserve failure; no automatic retry')
    sources = m.read(plan['source_pins']['path'])
    for row in sources['files']:
        for field in ('before','baseline_source','after'): m.exact(row[field])
    for field in ('helper','inherited_helper','patch'): m.exact(sources[field])
    baseline = m.read(plan['baseline_dependencies']['path'])
    recipe = m.read(plan['build_plan']['path'])
    for row in recipe['retained_inputs']: m.exact(row)
    old_ready = m.read(plan['baseline_ready']['path'])
    for field in ('image','app','source','source_pins','actual_dependencies','link_inputs','runtime'):
        m.exact(old_ready[field])
    compiler = recipe['compile']['executable'][0]
    env = h.discover_environment(compiler='msvc', cache={'CMAKE_C_COMPILER':compiler,
        'CMAKE_CXX_COMPILER':compiler,'CMAKE_GENERATOR':'Ninja'}, backends=()).env
    compiled = {}; actual_all = {}; contracts = {}
    for name in ('executable','submission'):
        old = baseline[name]
        for row in old['all_dependencies_at_preparation']: m.exact(row)
        m.exact(old['identity']); m.exact(old['object']); m.exact(old['command'])
        F = D / 'compile' / name
        compiled[name] = h.execute(recipe['compile'][name], env, F, timeout=120)
        dep = m.read(F / 'dependencies.json')['Data']
        actual = [m.pin(p) for p in dict.fromkeys([dep['Source'], *dep['Includes']])]
        def original_key(p):
            p = Path(p)
            return m.key(R / p.relative_to(D / 'source')) if p.is_relative_to(D / 'source') else m.key(p)
        mapped = {original_key(x['path']):x for x in actual}
        prior = {m.key(x['path']):x for x in old['all_dependencies_at_preparation']}
        assert set(prior) <= set(mapped), ('Missing original dependency', set(prior)-set(mapped))
        changes = [k for k in prior if prior[k]['sha256'] != mapped[k]['sha256']]
        assert changes == [m.key(old['source']['path'])], changes
        for helper in (D / 'graph_capture_trace.h', W / 'logical_trace.h'):
            assert m.key(helper) in mapped
        actual_all[name] = actual
        contracts[name] = dict(original_dependencies=len(prior), actual_dependencies=len(actual),
            project_original_count=old['project_dependency_count'], original_project_headers_changed=0,
            source_changed_only=changes, added=[x for k,x in mapped.items() if k not in prior])
        m.save(F / 'actual-dependencies.json', actual)
        m.save(F / 'dependency-contract.json', contracts[name])
    m.save(D / 'actual-dependencies.json', actual_all)
    replacements = {m.key(old['object']['path']):m.pin(D / 'compile' / name / 'unit.obj') for name,old in baseline.items()}
    original_inputs = m.read(plan['baseline_link_inputs']['path'])
    new_inputs = [replacements.get(m.key(x['path']),x) for x in original_inputs]
    assert len(replacements) == 2 and len(new_inputs) == len(original_inputs)
    for row in new_inputs: m.exact(row)
    m.save(D / 'hyle/link-inputs.json', new_inputs)
    m.save(D / 'hyle/link-contract.json', dict(original_recipe=m.pin(W / 'hyle/link/command.json'),
        replaces=recipe['replaces'], retained=len(recipe['retained_inputs']),
        retained_app=old_ready['app'], unchanged_absolute_inputs=recipe['retained_inputs'],
        no_app_weights_report_SDK_or_device_build=True))
    linked = h.execute(recipe['link'], env, D / 'hyle/link', timeout=120)
    for row in recipe['retained_inputs']: m.exact(row)
    runtime = m.read(plan['baseline_runtime']['path'])
    alias = D / 'hyle/link' / Path(runtime['native_hardlink']['path']).name
    m.exact(runtime['native']); os.link(runtime['native']['path'], alias)
    runtime['native_hardlink'] = m.pin(alias)
    m.save(D / 'hyle/runtime.json', runtime)
    source = next(x['after'] for x in sources['files'] if x['path'].endswith('executable.cc'))
    m.save(D / 'hyle/ready.json', dict(status='PRIVATE_TWO_GRAPH_NVTX_TUS_BUILT_NOT_PROFILED',
        image=m.pin(D / 'hyle/link/consumer.exe'), app=old_ready['app'], source=source,
        source_pins=plan['source_pins'], actual_dependencies=m.pin(D / 'actual-dependencies.json'),
        link_inputs=m.pin(D / 'hyle/link-inputs.json'), runtime=m.pin(D / 'hyle/runtime.json'),
        Graph_objects={n:m.pin(D / 'compile' / n / 'unit.obj') for n in baseline},
        compile=compiled, link=linked, baseline_ready=plan['baseline_ready'],
        new_host_TUs=2, SDK_builds=0, model_runs=0,
        scope='Frozen previous Hyle NVTX consumer; only Graph executable/submission objects replaced; neither current CPU nor SDK rebuild claim'))
    print('READY', m.pin(D / 'hyle/ready.json'), flush=True)

if __name__ == '__main__':
    build()
