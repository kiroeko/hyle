"""Publish the finite completed diagnostic; no build or inference."""
from pathlib import Path
import hashlib
import io
import json
import subprocess
import zipfile

D = Path(__file__).resolve().parent
W = D.parents[1]
R = W.parents[1]
DEST = R / 'docs/evidence/performance'
NAME = 'inference-cuda-recording-host-attribution-2026-10-26'

def read(p):
    return json.loads(Path(p).read_bytes())

def pin(p):
    p = Path(p)
    raw = p.read_bytes()
    return dict(path=str(p.resolve()), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())

def encode(value):
    return (json.dumps(value, ensure_ascii=False, indent=2) + '\n').encode('utf-8')

assert not (DEST / (NAME + '.json')).exists()
assert not (DEST / (NAME + '.zip')).exists()
memo = read(D / 'memo.json')
quality = read(D / 'hyle/trace1/quality.json')
check = read(D / 'root-range-check.json')
assert quality['status'] == 'PASS' and quality['full_non_time_equal']
assert memo['actual_run']['exit'] == 0 and not memo['actual_run']['timeout']
assert memo['counts']['emitted_capture_steps'] == 6909
assert check['status'] == 'PASS_FINITE_INDEPENDENT_RANGE_COUNT_AND_NESTING_CHECK'
assert check['totals']['graph/capture_dispatch']['wall_ns'] == 43908905
assert check['totals']['graph/capture_step/operation']['wall_ns'] + check['totals']['graph/capture_step/region']['wall_ns'] == 42803505
allow = read(D / 'allowlist.json')
files = {}
for row in allow['files'] + [x for x in allow['large_references'] if Path(x['path']).suffix == '.sqlite']:
    p = Path(row['path'])
    assert p.resolve().is_relative_to(W.resolve())
    assert pin(p) == row, 'Frozen file changed: ' + str(p)
    files[p.relative_to(W).as_posix()] = p.read_bytes()
for p in (D / 'allowlist.json', D / 'root-range-check.py', D / 'root-range-check.json', Path(__file__)):
    files[p.relative_to(W).as_posix()] = p.read_bytes()
manifest = [dict(path=name, bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest()) for name,raw in sorted(files.items())]
files['manifest.json'] = encode(dict(files=manifest, includes_sqlite=True,
    excludes='Objects/executables/DLLs/SDKs/weights and duplicate nsys-rep. Original source comes from the pinned Git tree plus archived patch/preparer.'))
data = io.BytesIO()
with zipfile.ZipFile(data, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as z:
    for name, raw in sorted(files.items()):
        z.writestr(name, raw)
blob = data.getvalue()
with zipfile.ZipFile(io.BytesIO(blob)) as z:
    assert z.testzip() is None
    for row in manifest:
        raw = z.read(row['path'])
        assert len(raw) == row['bytes'] and hashlib.sha256(raw).hexdigest() == row['sha256']
out = DEST / (NAME + '.zip')
out.write_bytes(blob)
report = dict(schema='hyle.performance.evidence.v1', date='2026-10-26',
    status='CLOSED_ONE_HYLE_RECORDING_DIAGNOSTIC_NO_PRODUCT_OR_THROUGHPUT_CHANGE',
    source_git=subprocess.check_output(['git','rev-parse','HEAD'], cwd=R, text=True).strip(),
    scope='Qwen3.5-2B BF16 pure CUDA; retained current-Model consumer; two natural P154+64 turns; greedy K1 MTP. Two private Graph host objects replaced, all native/vendor/math/kernel/report inputs retained.',
    findings=memo, independent_interval_check=check,
    source_review=read(D.parent / 'diagnostic/independent-review-architecture.json'),
    correction_review=read(D / 'independent-correction-review-architecture.json'),
    quality=quality,
    references=dict(paired_diagnostic='inference-cuda-mtp-current-attribution-2026-10-26.json',
                    formal_window='inference-current-window-2026-10-26.json'),
    limits=[
        'Diagnostic timings include NVTX/Nsight perturbation; they are not uninstrumented throughput, provider self-cost or recoverable savings. Formal four-item tables are unchanged.',
        'Step ranges are nested in dispatch; the three range stages are siblings. Counts and parent/child walls are never added as independent costs.',
        'Provider signatures use same-trace API/kernel evidence plus the known source chain. Generic operation/region labels alone do not identify a provider; unknown groups remain explicit.',
        'The first private instrumentation compilation failed due to the Windows interface macro. Its logs and exact correction are retained. The corrected two compilations/link and the only model profile completed.',
        'Ready status and model_runs=0 are historical build checkpoints. Final process/quality evidence records the completed profile.',
        'No new correctness/platform/general quality claim, no current CPU runtime certification, no peer rerun and no source/dependency/model download.'
    ],
    archive=dict(path=out.name, bytes=len(blob), sha256=hashlib.sha256(blob).hexdigest(),
                 members=len(files), verification='ZIP CRC and every manifest length/SHA256 passed'))
(DEST / (NAME + '.json')).write_bytes(encode(report))
print(json.dumps(dict(report=NAME + '.json', archive=report['archive']), indent=2))
