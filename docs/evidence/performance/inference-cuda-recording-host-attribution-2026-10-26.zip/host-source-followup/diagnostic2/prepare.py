"""Prepare only: exact baseline dependency check, two source copies/recipes."""
from pathlib import Path
import difflib
import hashlib
import json
import os
import sys

sys.dont_write_bytecode = True
D = Path(__file__).resolve().parent
W = D.parents[1]
R = W.parents[1]
SPECS = {
    'executable': R / '.scratch/inference-current-closure-20261026/drift8/graph--executable_cc',
    'submission': R / '.scratch/inference-current-closure-20261026/headers79/graph--submission_cc',
}

def read(p):
    return json.loads(Path(p).read_bytes())

def save(p, value):
    p = Path(p); p.parent.mkdir(parents=True, exist_ok=True)
    p.write_bytes((json.dumps(value, indent=2) + '\n').encode())

def pin(p):
    p = Path(p).resolve(); b = p.read_bytes()
    return dict(path=str(p), bytes=len(b), sha256=hashlib.sha256(b).hexdigest())

def key(p):
    return os.path.normcase(str(Path(p).resolve()))

def exact(p):
    assert pin(p['path']) == p, p['path']

def replace(s, a, b):
    assert s.count(a) == 1, (a[:100], s.count(a))
    return s.replace(a, b)

def prepare():
    if (D / 'plan.json').exists():
        raise FileExistsError('Frozen diagnostic; no implicit regeneration')
    identities = {}
    for name, folder in SPECS.items():
        ident = read(folder / 'identity-current.json')
        rows = ident['current_project_dependencies']
        differences = [dict(expected=x, actual=pin(x['path'])) for x in rows if pin(x['path']) != x]
        assert not differences, differences
        exact(ident['source']); exact(ident['object']); exact(ident['command'])
        deps = read(folder / 'dependencies.json')['Data']
        full = [pin(p) for p in dict.fromkeys([deps['Source'], *deps['Includes']])]
        identities[name] = dict(identity=pin(folder / 'identity-current.json'), source=ident['source'],
            object=ident['object'], command=ident['command'], source_dependencies=pin(folder / 'dependencies.json'),
            project_dependency_count=len(rows), project_differences=differences,
            project_dependencies=rows, all_dependencies_at_preparation=full,
            SDK_identity_scope='Original recipe/version and current file pins retained; no SDK rebuild or new claim about historical unpinned SDK bytes')
    save(D / 'baseline-dependencies.json', identities)
    files = []
    patches = []
    for name, info in identities.items():
        rel = 'src/graph/' + name + '.cc'
        raw = Path(info['source']['path']).read_bytes()
        s = raw.decode().replace('\r\n', '\n')
        s = '#include "graph_capture_trace.h"\n' + s
        if name == 'executable':
            s = replace(s, '    range.step_count = candidate.step_count;',
                '    range.step_count = candidate.step_count;\n    graph_capture_trace::Candidate trace_candidate(range.step_begin, range.step_count);')
            s = replace(s, '      ++reused_range_count;\n      captured_command_count += candidate.command_count;\n      continue;',
                '      ++reused_range_count;\n      captured_command_count += candidate.command_count;\n      trace_candidate.reuse_retained();\n      continue;')
            s = replace(s, '        ++reused_range_count;\n        captured_command_count += candidate.command_count;\n        continue;',
                '        ++reused_range_count;\n        captured_command_count += candidate.command_count;\n        trace_candidate.reuse_variant();\n        continue;')
            # Three fallback exits only inside this original capture loop.
            s = replace(s, '      if (options.mode == ReplayMode::kPreferCapture && unavailable.IsUnimplemented()) {',
                '      if (options.mode == ReplayMode::kPreferCapture && unavailable.IsUnimplemented()) {\n        trace_candidate.fallback();')
            s = replace(s, '      if (options.mode == ReplayMode::kPreferCapture && begun.IsUnimplemented()) {',
                '      if (options.mode == ReplayMode::kPreferCapture && begun.IsUnimplemented()) {\n        trace_candidate.fallback();')
            s = replace(s, '          capture_error.IsUnimplemented() && finished.ok()) {',
                '          capture_error.IsUnimplemented() && finished.ok()) {\n        trace_candidate.fallback();')
            s = replace(s, '    Status recorded = enqueue_segment_steps(*state_, range, *sequence);',
                '    trace_candidate.dispatch();\n    Status recorded = enqueue_segment_steps(*state_, range, *sequence);\n    trace_candidate.end_dispatch();')
            s = replace(s, '    compute::detail::CaptureRebuildStorage rebuild;\n    if (saved != nullptr)',
                '    trace_candidate.finalize();\n    compute::detail::CaptureRebuildStorage rebuild;\n    if (saved != nullptr)')
            s = replace(s, '    ++recorded_range_count;\n    captured_command_count += candidate.command_count;',
                '    ++recorded_range_count;\n    captured_command_count += candidate.command_count;\n    trace_candidate.recorded();')
        else:
            a = '    if (!step.emits_command())\n      continue;\n    const auto step_inputs ='
            b = '    if (!step.emits_command())\n      continue;\n    graph_capture_trace::Step trace_step(sequence.recording(), step_index,\n        static_cast<unsigned>(step.kind), step.region.valid());\n    const auto step_inputs ='
            s = replace(s, a, b)
        newline = '\r\n' if b'\r\n' in raw else '\n'
        after = D / 'source' / rel; after.parent.mkdir(parents=True, exist_ok=True)
        after.write_bytes(s.replace('\n', newline).encode())
        before = D / 'before' / rel; before.parent.mkdir(parents=True, exist_ok=True); before.write_bytes(raw)
        # Body newline stays exact to the original source.
        patch = ''.join(difflib.unified_diff(raw.decode().splitlines(True), after.read_bytes().decode().splitlines(True),
            fromfile='a/' + rel, tofile='b/' + rel))
        patches.append(patch)
        files.append(dict(path=rel, before=pin(before), baseline_source=info['source'], after=pin(after)))
    (D / 'source.patch').write_bytes(''.join(patches).encode())
    save(D / 'source-pins.json', dict(files=files, helper=pin(D / 'graph_capture_trace.h'),
        inherited_helper=pin(W / 'logical_trace.h'), patch=pin(D / 'source.patch')))
    ready = read(W / 'hyle/ready.json')
    exact(ready['image']); exact(ready['app']); exact(ready['link_inputs']); exact(ready['runtime'])
    inputs = read(ready['link_inputs']['path'])
    for x in inputs: exact(x)
    old = read(W / 'hyle/link/command.json')['command']
    replacement = {key(v['object']['path']): str(D / 'compile' / n / 'unit.obj') for n, v in identities.items()}
    assert all(sum(key(x['path']) == k for x in inputs) == 1 for k in replacement)
    compile_commands = {}
    for name, info in identities.items():
        flags = []; skip = False
        for a in read(info['command']['path'])['command'][1:]:
            if skip: skip = False; continue
            if a == '/sourceDependencies': skip = True; continue
            if a.lower().startswith(('/fo', '/fd')) or key(a) == key(info['source']['path']): continue
            flags.append(a)
        compiler = read(info['command']['path'])['command'][0]
        F = D / 'compile' / name
        cmd = [compiler, '/I' + str(D), '/I' + str(W), *flags,
            str(D / 'source/src/graph' / (name + '.cc')), '/sourceDependencies', str(F / 'dependencies.json'),
            '/Fo' + str(F / 'unit.obj'), '/Fd' + str(F / 'unit.pdb')]
        assert all(x in cmd for x in ('/W4', '/WX', '/O2', '/MD', '/DGGML_USE_CUDA'))
        compile_commands[name] = cmd
    link = []; count = 0
    for a in old:
        if key(a) in replacement: link.append(replacement[key(a)]); count += 1
        elif not a.lower().startswith(('/out:', '/pdb:', '/map:', '/implib:')): link.append(a)
    assert count == 2
    link += ['/OUT:' + str(D / 'hyle/link/consumer.exe'), '/PDB:' + str(D / 'hyle/link/consumer.pdb'),
        '/IMPLIB:' + str(D / 'hyle/link/consumer.lib')]
    save(D / 'build-plan.json', dict(compile=compile_commands, link=link, replaces=[v['object'] for v in identities.values()],
        retained_inputs=[x for x in inputs if key(x['path']) not in replacement], new_host_TUs=2,
        app_retained=ready['app'], no_SDK_or_device_kernel_build=True))
    original_plan = read(W / 'plan.json')
    command = next(x for x in original_plan['commands'] if x['arm'] == 'hyle').copy()
    command['command'] = [str(D / 'hyle/link/consumer.exe') if key(x) == key(ready['image']['path'])
        else '--output=' + str(D / 'hyle/trace1/trace') if x.startswith('--output=') else x for x in command['command']]
    command['run_dir'] = str(D / 'hyle/trace1')
    save(D / 'plan.json', dict(status='PREPARED_NOT_BUILT_NOT_RUN', tool=original_plan['tool'], tool_version=original_plan['tool_version'],
        source_pins=pin(D / 'source-pins.json'), baseline_dependencies=pin(D / 'baseline-dependencies.json'),
        build_plan=pin(D / 'build-plan.json'), baseline_ready=pin(W / 'hyle/ready.json'),
        baseline_link_inputs=ready['link_inputs'], baseline_runtime=ready['runtime'], commands=[command],
        compile_TUs=2, link_count=1, planned_Hyle_profiles=1, peer_profiles=0,
        instrumentation=dict(siblings=['graph/capture_lookup','graph/capture_dispatch','graph/capture_finalize'],
            outcome_marks=['graph/capture_record','graph/capture_reuse_retained','graph/capture_reuse_variant','graph/capture_fallback','graph/capture_error'],
            range_payload='uint64(step_begin)<<32 | uint32(step_count)',
            step_labels=['graph/capture_step/region','graph/capture_step/operation','graph/capture_step/copy','graph/capture_step/invalid'],
            step_payload='complete uint64 PlanStep index; same-thread parent determines range/episode',
            provider_identity='Not emitted. Attribute only when same-trace native API/kernel correlation uniquely qualifies; otherwise unknown',
            overhead='NVTX itself perturbs host timing; not an uninstrumented self-cost or recoverable gain',
            lifecycle='No domain initialization, sequence reset, formatting, product fields, allocation, readback, guards/status/order/permission/retirement changes'),
        arithmetic='Sibling ranges disjoint; steps nested in dispatch. Never add step/dispatch or parent/children. All APIs interval-unioned, original parent remainder explicit.',
        limits='No compile/model started by preparation. Root alone runs build then single Hyle profile; duration60/watchdog120; no retry. Full non-time report gate inherited.'))
    print(json.dumps(dict(plan=pin(D / 'plan.json'), source_pins=pin(D / 'source-pins.json'),
        source_patch=pin(D / 'source.patch'), dependencies=pin(D / 'baseline-dependencies.json'))))

if __name__ == '__main__':
    prepare()
