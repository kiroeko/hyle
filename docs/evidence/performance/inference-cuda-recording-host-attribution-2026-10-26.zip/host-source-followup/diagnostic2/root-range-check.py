"""Independent finite interval/count check; no model or compiler invocation."""
from collections import defaultdict
from pathlib import Path
import hashlib
import json
import re
import sqlite3

D = Path(__file__).resolve().parent
db = D / 'hyle/trace1/trace.sqlite'
conn = sqlite3.connect('file:' + db.as_posix() + '?mode=ro', uri=True)
conn.row_factory = sqlite3.Row
rows = [dict(x) for x in conn.execute('''
 SELECT n.start,n.end,n.globalTid,COALESCE(n.text,s.value) label
 FROM NVTX_EVENTS n LEFT JOIN StringIds s ON s.id=n.textId
 ORDER BY n.start''')]
conn.close()
roots = [x for x in rows if x['label'] and x['label'].startswith('hyle/episode')]
assert len(roots) == 68
decode = [x for x in roots if int(re.search(r'target_T=(\d+)', x['label'])[1]) <= 2]
assert len(decode) == 66
stages = ('graph/capture_lookup', 'graph/capture_dispatch', 'graph/capture_finalize')
selected = [x for x in rows if x['label'] in stages or
            (x['label'] and x['label'].startswith('graph/capture_step/'))]
assert all(x['end'] is not None and x['end'] >= x['start'] for x in selected)
total = defaultdict(lambda: dict(count=0, wall_ns=0))
for root in decode:
    children = [x for x in selected if x['globalTid'] == root['globalTid'] and
                root['start'] <= x['start'] <= x['end'] <= root['end']]
    siblings = [x for x in children if x['label'] in stages]
    assert all(a['end'] <= b['start'] for a,b in zip(siblings, siblings[1:]))
    dispatch = [x for x in siblings if x['label'] == stages[1]]
    for child in children:
        label = child['label']
        if label.startswith('graph/capture_step/'):
            assert sum(a['start'] <= child['start'] <= child['end'] <= a['end']
                       for a in dispatch) == 1
        total[label]['count'] += 1
        total[label]['wall_ns'] += child['end'] - child['start']
out = dict(status='PASS_FINITE_INDEPENDENT_RANGE_COUNT_AND_NESTING_CHECK',
           sqlite_sha256=hashlib.sha256(db.read_bytes()).hexdigest(),
           roots=len(roots), decode_roots=len(decode), totals=dict(total),
           limits='Fixed P154 two-turn K1 experiment; target_T<=2 identifies decode here. Steps are nested in dispatch and never additive with it. This does not attribute provider self-cost or prove removable work.')
(D / 'root-range-check.json').write_text(json.dumps(out, indent=2) + '\n', encoding='utf8')
print(json.dumps(out, indent=2))
