"""Finite offline complement: disjoint native-call signatures, not kernel cost."""
from pathlib import Path
from collections import Counter, defaultdict
import importlib.util
import json
import sqlite3
import statistics
import sys

sys.dont_write_bytecode = True
D = Path(__file__).resolve().parent
W = D.parents[1]
spec=importlib.util.spec_from_file_location('same_graph_unions',W/'analyze.py')
a=importlib.util.module_from_spec(spec);spec.loader.exec_module(a)
m=a.m

def classify(x):
    cu=any('cublas' in k for k in x['library_counts'])
    ex=any('ThreadExchangeStreamCaptureMode' in k for k in x['api_counts'])
    assert not(cu and ex), 'Do not make overlapping provider buckets'
    if cu:
        return 'cuBLAS_library_observed'
    if ex:
        assert sum(v for k,v in x['api_counts'].items() if 'ThreadExchangeStreamCaptureMode' in k)==2
        assert sum(v for k,v in x['api_counts'].items() if 'StreamIsCapturing' in k)==1
        return 'GGML_recording_bridge_signature_source_supported'
    return 'other_or_unqualified_provider'

def facts(xs):
    return dict(steps=len(xs),wall_ns=sum(x['wall_ns'] for x in xs),
        api_library_union_ns=sum(x['visible_api_library_union_ns'] for x in xs),
        uncovered_ns=sum(x['uncovered_ns'] for x in xs),
        median_step_ns=statistics.median(x['wall_ns'] for x in xs) if xs else None,
        api_counts=dict(sum((Counter(x['api_counts']) for x in xs),Counter())),
        library_counts=dict(sum((Counter(x['library_counts']) for x in xs),Counter())))

def main():
    summary=m.read(D/'summary.json');ranges=m.read(D/'range-rows.json')
    parents=m.read(D/'parent-rows.json');steps=m.read(D/'step-rows.json')
    recordseq={x['meta']['seq'] for x in parents if not x['prefill'] and x['classification']=='record'}
    rows=[x for x in ranges if x['meta']['seq'] in recordseq]
    # Parent subtraction uses ALL42 sibling lookup scopes, including15reuse.
    lookup={label:dict(count=len(xs),wall_ns=sum(x['stages']['graph/capture_lookup']['wall_ns'] for x in xs))
        for label in ('all_in_record_parents','record_candidates','reuse_in_record_parents')
        for xs in [[x for x in rows if label=='all_in_record_parents' or
            (x['outcome']=='graph/capture_record')==(label=='record_candidates')]]}
    groups=defaultdict(list)
    for x in steps:groups[classify(x)].append(x)
    by_signature={k:facts(xs) for k,xs in groups.items()}
    by_kind={k:facts([x for x in steps if x['kind']==k]) for k in sorted({x['kind'] for x in steps})}
    by_geometry={label:{k:facts([x for x in xs if bool(x['range_begin'])==body]) for k,xs in groups.items()}
        for label,body in (('front_capture_subset',False),('body_capture_subset',True))}
    c=sqlite3.connect('file:'+(D/'hyle/trace1/trace.sqlite').as_posix()+'?mode=ro',uri=True);c.row_factory=sqlite3.Row
    tables={x[0] for x in c.execute("SELECT name FROM sqlite_master WHERE type='table'")}
    apis=[dict(x) for x in c.execute(a.SQL['runtime'])]
    if 'CUPTI_ACTIVITY_KIND_DRIVER' in tables:apis += [dict(x) for x in c.execute(a.SQL['driver'])]
    c.close()
    stage_api={}
    for name in ('graph/capture_lookup','graph/capture_dispatch','graph/capture_finalize'):
        selected=[]
        for r in ranges:
            if name not in r['stages']:continue
            p=next(x for x in parents if x['meta']['seq']==r['meta']['seq'])
            phase=r['stages'][name]
            # All phase parents share the one model/control thread, verified
            # in the primary analyzer. Clip native intervals to that stage.
            rootrow=next(x for x in m.read(D/'hyle/episode-rows.json') if x['meta']['seq']==p['meta']['seq'])
            tid=rootrow['globalTid'];lo,hi=phase['start_ns'],phase['end_ns']
            selected += [dict(x,start=max(lo,x['start']),end=min(hi,x['end'])) for x in apis
                if x['globalTid']==tid and x['start']<hi and lo<x['end']]
        stage_api[name]={k:dict(count=len(xs),union_ns=a.event_union(xs),
            return_values=dict(Counter(str(x.get('returnValue')) for x in xs)))
            for k in sorted({x['api'] for x in selected}) for xs in [[x for x in selected if x['api']==k]]}
    source_paths=('src/compute_provider_ggml_cuda/ggml_cuda_provider.cc',
        'src/compute_provider_ggml_cuda/native_bridge_impl.h','src/compute_provider_cublas/cublas_provider.cc')
    R=W.parents[1]
    m.save(D/'step-signature-summary.json',dict(analyzer=m.pin(Path(__file__)),
        lookup_in_record_parents=lookup,by_signature=by_signature,by_kind=by_kind,by_geometry=by_geometry,
        stage_API_counts_and_unions=stage_api,largest_steps=sorted(steps,key=lambda x:x['wall_ns'],reverse=True)[:12],
        source_pins=[m.pin(R/p) for p in source_paths],
        source_anchors={'ggml_cuda_provider.cc':[1172,1212], 'native_bridge_impl.h':[203,206,211,257,265,266], 'cublas_provider.cc':[596]},
        limits=['Native cuBLAS is directly observed by library NVTX. GGML bridge grouping uses the same-trace exact two ThreadExchange plus one StreamIsCapturing signature and the pinned source path; no ProviderInstanceId was emitted.',
            'Other448steps remain unqualified. Step kind is not provider identity or a kernel count.',
            'Native API names can be nested; individual API unions must not be added. Stage/step sums are valid only for the already-validated disjoint sibling or step intervals.',
            'No old provider timing subtraction, current-seed cause proof, pure-CPU attribution, or recoverable benefit is claimed.']))
    print(json.dumps(m.pin(D/'step-signature-summary.json')))

if __name__=='__main__':main()
