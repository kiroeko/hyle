"""Offline only, one new Hyle SQLite; no cross-process clock subtraction."""
from pathlib import Path
from collections import Counter, defaultdict
import importlib.util
import json
import re
import sqlite3
import sys

sys.dont_write_bytecode = True
D = Path(__file__).resolve().parent
W = D.parents[1]

def load(name, p):
    spec = importlib.util.spec_from_file_location(name, p)
    mod = importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
    return mod

m = load('graph_trace_offline_plan', D / 'prepare.py')
a = load('original_interval_analysis', W / 'analyze.py')
STAGES = ('graph/capture_lookup', 'graph/capture_dispatch', 'graph/capture_finalize')
OUTCOMES = ('graph/capture_record', 'graph/capture_reuse_retained',
            'graph/capture_reuse_variant', 'graph/capture_fallback', 'graph/capture_error')

def contains(parent, child):
    return parent['globalTid'] == child['globalTid'] and parent['start'] <= child['start'] and child['end'] <= parent['end']

def analyze():
    F = D / 'hyle/trace1'
    assert m.read(F / 'quality.json')['status'] == 'PASS'
    # Reuse precisely the original per-root work/correlation/role checks, but
    # write only into this new diagnostic tree. No peer or old timestamps.
    a.W = D
    root_summary = a.analyze('hyle')
    c = sqlite3.connect('file:' + (F / 'trace.sqlite').as_posix() + '?mode=ro', uri=True)
    c.row_factory = sqlite3.Row
    tables = {x[0] for x in c.execute("SELECT name FROM sqlite_master WHERE type='table'")}
    nvtx = [dict(x) for x in c.execute(a.SQL['nvtx']) if x['label']]
    closed = [x for x in nvtx if x['end'] is not None]
    missing = [dict(label=x['label'], start=x['start']) for x in nvtx
               if x['label'] in STAGES or x['label'].startswith('graph/capture_step/')
               if x['end'] is None]
    assert not missing, ('Incomplete Graph ranges', missing)
    api = [dict(x) for x in c.execute(a.SQL['runtime'])]
    if 'CUPTI_ACTIVITY_KIND_DRIVER' in tables:
        api += [dict(x) for x in c.execute(a.SQL['driver'])]
    library = [x for x in closed if x['label'].startswith('cublas')]
    c.close()
    roots = [x for x in closed if x['label'].startswith('hyle/episode ')]
    replays = [x for x in closed if x['label'] == 'hyle/prepare_replay']
    marks = [x for x in nvtx if x['label'] in OUTCOMES]
    assert len(roots) == len(replays) == 68
    stage_used = set(); step_used = set(); mark_used = set()
    ranges = []; step_rows = []; parents = []

    def metrics(scope):
        lo, hi = scope['start'], scope['end']; tid = scope['globalTid']
        calls = [x for x in api if x['globalTid'] == tid and x['start'] < hi and lo < x['end']]
        libs = [x for x in library if x['globalTid'] == tid and x['start'] < hi and lo < x['end']]
        visible = a.event_union(calls + libs, (lo, hi))
        return dict(start_ns=lo, end_ns=hi, wall_ns=hi-lo,
            visible_api_library_union_ns=visible, uncovered_ns=hi-lo-visible,
            api_counts=dict(Counter(x['api'] for x in calls)),
            library_counts=dict(Counter(x['label'] for x in libs)))

    for root in roots:
        meta = {k:int(v) for k,v in re.findall(r'(\w+)=(\d+)',root['label'])}
        parent = [x for x in replays if contains(root,x)]
        assert len(parent) == 1
        parent = parent[0]
        children = [x for x in closed if x['label'] in STAGES and contains(parent,x)]
        outcomes = [x for x in marks if x['globalTid'] == parent['globalTid'] and parent['start'] <= x['start'] <= parent['end']]
        payloads = [x['uint64Value'] for x in outcomes]
        assert len(payloads) == len(set(payloads)), ('Repeated candidate tuple in one parent',meta,payloads)
        assert sum(x['end']-x['start'] for x in children) == a.event_union(children), 'Sibling overlap'
        pm = metrics(parent)
        child_intervals = [(x['start'],x['end']) for x in children]
        remainder = a.subtract([(parent['start'],parent['end'])], child_intervals)
        pm.update(meta=meta,prefill=meta['role'] in (2,7), sibling_union_ns=a.measure(child_intervals),
            outside_siblings_ns=a.measure(remainder), outcomes=dict(Counter(x['label'] for x in outcomes)))
        pm['classification'] = 'record' if pm['outcomes'].get('graph/capture_record') else 'no_record'
        pm['outside_siblings_visible_union_ns'] = sum(metrics(dict(start=lo,end=hi,globalTid=parent['globalTid']))['visible_api_library_union_ns'] for lo,hi in remainder)
        pm['outside_siblings_uncovered_ns'] = pm['outside_siblings_ns']-pm['outside_siblings_visible_union_ns']
        parents.append(pm)
        for outcome in outcomes:
            mark_used.add(id(outcome))
            payload = outcome['uint64Value']
            begin, count = payload >> 32, payload & 0xffffffff
            selected = [x for x in children if x['uint64Value'] == payload]
            labels = Counter(x['label'] for x in selected)
            assert labels['graph/capture_lookup'] == 1 and all(v == 1 for v in labels.values())
            if outcome['label'] == 'graph/capture_record':
                assert labels == Counter(STAGES), (meta,begin,count,labels)
            elif outcome['label'].startswith('graph/capture_reuse_'):
                assert labels == Counter((STAGES[0],)), (meta,begin,count,labels)
            assert all(x['end'] <= outcome['start'] for x in selected)
            stage_used.update(id(x) for x in selected)
            stages = {x['label']:metrics(x) for x in selected}
            row = dict(meta=meta, step_begin=begin,step_count=count,outcome=outcome['label'],stages=stages)
            dispatch = next((x for x in selected if x['label'] == STAGES[1]),None)
            steps = [x for x in closed if x['label'].startswith('graph/capture_step/') and dispatch and contains(dispatch,x)]
            assert all(begin <= x['uint64Value'] < begin+count for x in steps)
            assert len(steps) == len({x['uint64Value'] for x in steps})
            assert sum(x['end']-x['start'] for x in steps) == a.event_union(steps), 'Step overlap'
            step_used.update(id(x) for x in steps)
            row['emitted_steps'] = len(steps)
            row['step_union_ns'] = a.event_union(steps)
            row['dispatch_outside_steps_ns'] = dispatch['end']-dispatch['start']-row['step_union_ns'] if dispatch else 0
            ranges.append(row)
            for step in steps:
                step_rows.append(dict(meta=meta,range_begin=begin,range_count=count,index=step['uint64Value'],
                    kind=step['label'].rsplit('/',1)[-1],**metrics(step)))
    all_stages = [x for x in closed if x['label'] in STAGES]
    all_steps = [x for x in closed if x['label'].startswith('graph/capture_step/')]
    assert len(stage_used) == len(all_stages) and len(step_used) == len(all_steps) and len(mark_used) == len(marks)
    totals = Counter(x['outcome'] for x in ranges)
    stderr = (F / 'native-stderr.log').read_text(encoding='utf8')
    reports = [(int(x),int(y)) for x,y in re.findall(r'capture_recorded=(\d+)\s+capture_reused=(\d+)',stderr)]
    assert len(reports) == 68
    assert sum(x for x,y in reports) == totals['graph/capture_record']
    assert sum(y for x,y in reports) == totals['graph/capture_reuse_retained']+totals['graph/capture_reuse_variant']
    groups = defaultdict(list)
    for x in step_rows:
        q=x['meta']
        # Never join indices from different Family signatures as one program.
        k=(q['role'],q['target_T'],q['draft_T'],q['R'],x['range_begin'],x['range_count'],x['index'],x['kind'])
        groups[k].append(x)
    ranking = []
    for k,xs in groups.items():
        ranking.append(dict(family_and_range_step=k,occurrences=len(xs),sequences=[x['meta']['seq'] for x in xs],
            wall_ns=sum(x['wall_ns'] for x in xs),visible_union_ns=sum(x['visible_api_library_union_ns'] for x in xs),
            uncovered_ns=sum(x['uncovered_ns'] for x in xs),api_counts=dict(sum((Counter(x['api_counts']) for x in xs),Counter())),
            library_counts=dict(sum((Counter(x['library_counts']) for x in xs),Counter()))))
    ranking.sort(key=lambda x:x['wall_ns'],reverse=True)
    fields=('wall_ns','visible_api_library_union_ns','uncovered_ns','outside_siblings_ns','outside_siblings_visible_union_ns','outside_siblings_uncovered_ns')
    summary = dict(status='OFFLINE_SINGLE_NEW_TRACE_NO_TPS',analyzer=m.pin(Path(__file__)),database=m.pin(F/'trace.sqlite'),
        quality=m.pin(F/'quality.json'),root_analysis=m.pin(D/'hyle/analysis.json'),
        counts=dict(roots=len(roots),parents=len(parents),prefill=sum(x['prefill'] for x in parents),
            decode_record=sum(not x['prefill'] and x['classification']=='record' for x in parents),
            decode_no_record=sum(not x['prefill'] and x['classification']=='no_record' for x in parents),
            outcomes=dict(totals),stages=len(all_stages),emitted_capture_steps=len(all_steps)),
        parents_by_class={key:{f:a.stats(x[f] for x in xs) for f in fields}
            for key in ('prefill','record','no_record')
            for xs in [[x for x in parents if x['prefill'] if key=='prefill'] if key=='prefill' else [x for x in parents if not x['prefill'] and x['classification']==key]]},
        sibling_stages={label:{f:a.stats(r['stages'][label][f] for r in ranges if label in r['stages']) for f in ('wall_ns','visible_api_library_union_ns','uncovered_ns')} for label in STAGES},
        top_steps=ranking[:30], unexpected_outcomes={k:v for k,v in totals.items() if k in ('graph/capture_error','graph/capture_fallback')},
        limits=['Only this trace clock; old71.48/30.85ms or provider15.29ms cannot be subtracted from these measurements.',
            'Sibling stages are disjoint; step ranges are nested inside dispatch. Parent, stage, step and API metrics must never be summed together.',
            'Step label is kind/region+index, not provider identity or kernel count. Same-trace APIs may help infer provider, but ambiguous identity remains unknown.',
            'Failure abort/finish cleanup after failed dispatch is outside the three stages. Error outcome is explicit; these stages do not cover a whole error path.',
            'Visible runtime/driver/cuBLAS intervals are unioned; uncovered includes profiler bookkeeping, scheduler and unobserved native calls, not proved pure Graph CPU or recoverable gain.',
            'New per-step NVTX can perturb the very host cost measured. No unprofiled TPS, paired speed, or return-on-investment claim.',
            'Original normal-end/full non-time work gate and 68 root phase validation required before analysis. No new model launch or retry.'])
    m.save(D/'range-rows.json',ranges);m.save(D/'step-rows.json',step_rows);m.save(D/'parent-rows.json',parents)
    m.save(D/'step-ranking.json',ranking);m.save(D/'summary.json',summary)
    print(json.dumps(dict(summary=m.pin(D/'summary.json'),counts=summary['counts'])))

if __name__ == '__main__':
    analyze()
