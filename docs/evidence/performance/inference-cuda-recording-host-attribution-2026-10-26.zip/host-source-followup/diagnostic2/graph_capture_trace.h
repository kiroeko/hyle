#pragma once

// Private instrumentation only. Model RunScope owns initialization and the
// shared episode sequence; Graph must not initialize/reset either one.
#pragma push_macro("interface")
#include "logical_trace.h"
#pragma pop_macro("interface")

namespace graph_capture_trace {
class Range final {
  nvtxRangeId_t id_ = 0;
  bool active_ = false;
public:
  Range() noexcept = default;
  Range(const Range &) = delete;
  Range &operator=(const Range &) = delete;
  ~Range() { finish(); }
  void start(const char *label, unsigned long long payload) noexcept {
    if (logical_trace::domain == nullptr)
      return;
    nvtxEventAttributes_t event{};
    event.version = NVTX_VERSION;
    event.size = NVTX_EVENT_ATTRIB_STRUCT_SIZE;
    event.messageType = NVTX_MESSAGE_TYPE_ASCII;
    event.message.ascii = label;
    event.payloadType = NVTX_PAYLOAD_TYPE_UNSIGNED_INT64;
    event.payload.ullValue = payload;
    id_ = nvtxDomainRangeStartEx(logical_trace::domain, &event);
    active_ = true;
  }
  void finish() noexcept {
    if (active_) {
      nvtxDomainRangeEnd(logical_trace::domain, id_);
      active_ = false;
    }
  }
};

inline void mark(const char *label, unsigned long long payload) noexcept {
  if (logical_trace::domain == nullptr)
    return;
  nvtxEventAttributes_t event{};
  event.version = NVTX_VERSION;
  event.size = NVTX_EVENT_ATTRIB_STRUCT_SIZE;
  event.messageType = NVTX_MESSAGE_TYPE_ASCII;
  event.message.ascii = label;
  event.payloadType = NVTX_PAYLOAD_TYPE_UNSIGNED_INT64;
  event.payload.ullValue = payload;
  nvtxDomainMarkEx(logical_trace::domain, &event);
}

// Three sequential sibling ranges, plus one instant outcome marker. The
// payload is the existing uint32 step_begin/count, not another episode owner.
class Candidate final {
  unsigned long long payload_;
  const char *outcome_ = "graph/capture_error";
  Range stage_;
public:
  Candidate(std::uint32_t begin, std::uint32_t count) noexcept
      : payload_((static_cast<unsigned long long>(begin) << 32) | count) {
    stage_.start("graph/capture_lookup", payload_);
  }
  Candidate(const Candidate &) = delete;
  Candidate &operator=(const Candidate &) = delete;
  ~Candidate() {
    stage_.finish();
    mark(outcome_, payload_);
  }
  void dispatch() noexcept {
    stage_.finish();
    stage_.start("graph/capture_dispatch", payload_);
  }
  void end_dispatch() noexcept { stage_.finish(); }
  void finalize() noexcept {
    stage_.start("graph/capture_finalize", payload_);
  }
  void reuse_retained() noexcept { outcome_ = "graph/capture_reuse_retained"; }
  void reuse_variant() noexcept { outcome_ = "graph/capture_reuse_variant"; }
  void fallback() noexcept { outcome_ = "graph/capture_fallback"; }
  void recorded() noexcept { outcome_ = "graph/capture_record"; }
};

// Capture only. Fixed labels and complete step index: no formatting, provider
// registry, counter, allocation, I/O, domain initialization, or state owner.
class Step final {
  Range range_;
public:
  Step(bool recording, std::size_t index, unsigned kind, bool region) noexcept {
    if (!recording)
      return;
    const char *label = region ? "graph/capture_step/region"
        : kind == 0 ? "graph/capture_step/operation"
        : kind == 2 ? "graph/capture_step/copy"
                    : "graph/capture_step/invalid";
    range_.start(label, static_cast<unsigned long long>(index));
  }
};
} // namespace graph_capture_trace
