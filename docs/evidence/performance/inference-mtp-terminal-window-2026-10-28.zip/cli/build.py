"""One current Model CXX and CLI link. No action runs a consumer."""
from pathlib import Path
import importlib.util
import re
import sys

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = Path(r'C:\public\project-hyle\hyle')
BASE = R / '.scratch/inference-small-projection-20261028/model-candidate/attempt2'
ENTRY = R / '.scratch/inference-current-closure-20261026/engine/entry'
SOURCE = R / 'engine/models/qwen35/main.cc'
spec = importlib.util.spec_from_file_location('bounded_incremental_tools', R / '.scratch/inference-indexed-store-20261028/build.py')
t = importlib.util.module_from_spec(spec); spec.loader.exec_module(t); t.W = W


def prepare():
    ready = t.read(BASE / 'ready-control.json'); t.exact(ready['inputs'])
    rows = t.read(ready['inputs']['path']); assert len(rows) == 229
    original = ready['compiled']['object']
    assert original in rows and sum(t.key(row['path']) == t.key(original['path']) for row in rows) == 1
    entry = t.pin(ENTRY / 'unit.obj')
    assert entry['sha256'] == 'c44d44f90c729b329aeac89e3384e4ce6b1bde5bd4f6c2acb7e59f0c17cc052f'
    entry_dep = t.read(ENTRY / 'dependencies.json')['Data']
    assert t.key(entry_dep['Source']) == t.key(R / 'engine/main.cc')
    assert t.pin(R / 'engine/main.cc')['sha256'] == '1d6bb08fe752d10c69ae9e65e16843470757482117072dba61db92132075f40c'
    assert 'int run(int argc, char **argv);' in (R / 'engine/models/qwen35/driver.h').read_text(encoding='utf-8-sig')
    assert entry in rows
    source_snapshot = W / 'source/engine/models/qwen35/main.cc'
    before = t.command(ready['compiled']['command']['path']); args = []
    old_source = t.read(ready['compiled']['dependencies']['path'])['Data']['Source']
    for at, arg in enumerate(before):
        if t.key(arg) == t.key(old_source): arg = str(source_snapshot)
        elif at and before[at - 1].lower() == '/sourcedependencies': arg = str(W / 'compile/model/dependencies.json')
        elif arg.lower().startswith('/fo'): arg = '/Fo' + str(W / 'compile/model/unit.obj')
        elif arg.lower().startswith('/fd'): arg = '/Fd' + str(W / 'compile/model/unit.pdb')
        args.append(arg)
    # Only the TU is copied. All quote headers resolve to canonical current
    # files, avoiding the two-physical-path pragma-once failure of a test overlay.
    args.insert(1, '/I' + str(SOURCE.parent))
    assert sum(t.key(arg) == t.key(source_snapshot) for arg in args) == 1
    assert all('/source/engine' not in arg.replace('\\', '/').lower() for arg in args if arg.lower().startswith('/i') and 'program-io-window' not in arg)
    t.save(W / 'recipe-model.json', dict(command=args, timeout_seconds=300))
    link = []
    for arg in t.command(ready['recipe']['path']):
        if t.key(arg) == t.key(original['path']): arg = str(W / 'compile/model/unit.obj')
        for prefix, suffix in (('/OUT:', '.exe'), ('/PDB:', '.pdb'), ('/MAP:', '.map'), ('/IMPLIB:', '.lib')):
            if arg.upper().startswith(prefix): arg = prefix + str((W / 'bin/hyle-current').with_suffix(suffix)); break
        link.append(arg)
    assert sum(t.key(arg) == t.key(W / 'compile/model/unit.obj') for arg in link) == 1
    assert not any(t.key(arg) == t.key(original['path']) for arg in link)
    t.save(W / 'link-model.json', dict(command=link, timeout_seconds=240))
    stats = []
    for row in rows:
        if t.key(row['path']) == t.key(original['path']): continue
        st = Path(row['path']).stat(); assert st.st_size == row['bytes']
        stats.append(dict(path=row['path'], bytes=st.st_size, mtime_ns=st.st_mtime_ns))
    t.save(W / 'retained-input-stats.json', stats)
    env = t.read(BASE / 'environment.json'); env['PATH'] = str(W / 'bin') + ';' + env['PATH']
    t.save(W / 'environment.json', env)
    native = t.read(BASE / 'runtime.json')['native']; t.exact(native)
    t.save(W / 'runtime.json', dict(PATH=env['PATH'], native=native,
        ownership='Current runtime directories and original native DLL in place; no SDK/model payload copy.'))
    t.save(W / 'build-plan.json', dict(baseline=t.pin(BASE / 'ready-control.json'), inputs=ready['inputs'],
        original_object=original, recipe=t.pin(W / 'recipe-model.json'), link=t.pin(W / 'link-model.json'),
        old_dependencies=ready['compiled']['dependencies'], entry=dict(object=entry, source=t.pin(R / 'engine/main.cc'),
            driver=t.pin(R / 'engine/models/qwen35/driver.h'), dependencies=t.pin(ENTRY / 'dependencies.json'),
            contract='Original opaque int qwen35::run(int,char**) forwarding entry; no Model layout or backend types.'),
        retained_stats=t.pin(W / 'retained-input-stats.json'), environment=t.pin(W / 'environment.json'), runtime=t.pin(W / 'runtime.json'),
        counts=dict(CXX=1, links=1, SDK_CXX=0, NVCC=0, downloads=0, original_inputs=229, retained_SDK_weights=227, retained_entry=1, CLI_inputs=229),
        scope='Current Model after terminal/ledger fix; same ON227 SDK/weights plus original entry as control0c622. Also includes two intervening cold abstractions; not a terminal-only causal isolation.'))
    print('PREPARED: retained ON229 CLI -> replace only Model OBJ; no compiler/model run; current source not yet frozen')


def prepared():
    plan = t.read(W / 'build-plan.json')
    for field in ('baseline', 'inputs', 'recipe', 'link', 'old_dependencies', 'retained_stats', 'environment', 'runtime'): t.exact(plan[field])
    for field in ('object', 'source', 'driver', 'dependencies'): t.exact(plan['entry'][field])
    return plan


def freeze():
    plan = prepared(); command = t.command(plan['recipe']['path'])
    roots = [R / 'include', R, *[Path(arg[2:]) for arg in command if arg.lower().startswith('/i')]]
    # Read only the TU's reachable include closure, never a whole SDK/source tree.
    pending = [SOURCE]; paths = {}
    while pending:
        path = pending.pop().resolve()
        if t.key(path) in paths: continue
        paths[t.key(path)] = path
        for kind, include in re.findall(r'^\s*#\s*include\s*([<"])([^>"\r\n]+)[>"]', path.read_text(encoding='utf-8-sig'), re.M):
            search = ([path.parent] if kind == '"' else []) + roots
            found = next((p.resolve() for root in search if (p := root / include).is_file()), None)
            if found is not None and t.project(found): pending.append(found)
    t.save(W / 'reachable-project-dependencies.json', [t.pin(p) for p in paths.values()])
    target = W / 'source/engine/models/qwen35/main.cc'; target.parent.mkdir(parents=True, exist_ok=True)
    with target.open('xb') as stream: stream.write(SOURCE.read_bytes())
    t.save(W / 'source-freeze.json', dict(source=t.pin(SOURCE), snapshot=t.pin(target),
        helper=t.pin(__file__), project_dependencies=t.pin(W / 'reachable-project-dependencies.json'),
        headers='Canonical current reachable headers, no SDK copy, no test-header overlay; unrelated SDK objects are stat-retained from the successful 228 closure.'))
    print('SOURCE FROZEN', t.pin(SOURCE), 'reachable project files:', len(paths))


def validate():
    plan = prepared(); frozen = t.read(W / 'source-freeze.json')
    for field in ('source', 'snapshot', 'helper', 'project_dependencies'): t.exact(frozen[field])
    for row in t.read(frozen['project_dependencies']['path']): t.exact(row)
    return plan, frozen


def parse_compile():
    plan, frozen = validate(); out = W / 'compile/model'; process = t.read(W / 'logs/model/process.json')
    assert process['exit'] == 0 and not process['timed_out']
    allowed = {t.key(row['path']): row for row in t.read(frozen['project_dependencies']['path'])}
    allowed[t.key(frozen['snapshot']['path'])] = frozen['snapshot']
    actual = []
    for path in dict.fromkeys(t.dep_paths(out / 'dependencies.json')):
        if t.project(path) or t.key(path) == t.key(frozen['snapshot']['path']):
            assert t.key(path) in allowed, ('unfrozen actual project include; metadata error after successful CXX, do not recompile', str(path))
            t.exact(allowed[t.key(path)])
        actual.append(t.pin(path))
    t.save(out / 'actual-dependencies.json', actual)
    t.save(out / 'compiled.json', dict(source=frozen['source'], snapshot=frozen['snapshot'], object=t.pin(out / 'unit.obj'),
        command=t.pin(W / 'logs/model/command.json'), dependencies=t.pin(out / 'dependencies.json'),
        actual_dependencies=t.pin(out / 'actual-dependencies.json'), process=process))
    print('MODEL CXX actual dependencies recorded')


def compile_model():
    plan, _ = validate(); (W / 'compile/model').mkdir(parents=True, exist_ok=False)
    t.execute(t.command(plan['recipe']['path']), W / 'logs/model', 300)
    parse_compile()


def link_model():
    plan, frozen = validate(); compiled = t.read(W / 'compile/model/compiled.json'); t.exact(compiled['object'])
    for row in t.read(plan['retained_stats']['path']):
        st = Path(row['path']).stat(); assert (st.st_size, st.st_mtime_ns) == (row['bytes'], row['mtime_ns']), row['path']
    rows = [compiled['object'] if t.key(row['path']) == t.key(plan['original_object']['path']) else row for row in t.read(plan['inputs']['path'])]
    assert len(rows) == len({t.key(row['path']) for row in rows}) == 229
    (W / 'bin').mkdir(exist_ok=True); t.save(W / 'inputs-model.json', rows)
    native = t.read(plan['runtime']['path'])['native']; destination = W / 'bin' / Path(native['path']).name
    destination.hardlink_to(native['path']); assert destination.samefile(native['path'])
    process = t.execute(t.command(plan['link']['path']), W / 'link/model', 240)
    t.save(W / 'ready-model.json', dict(image=t.pin(W / 'bin/hyle-current.exe'), inputs=t.pin(W / 'inputs-model.json'),
        compiled=compiled, runtime=plan['runtime'], recipe=t.pin(W / 'link/model/command.json'), process=process,
        plan=t.pin(W / 'build-plan.json'), source_freeze=t.pin(W / 'source-freeze.json'), closure_inputs=229))
    print('CLI LINK PASS: current Model plus retained ON227 SDK/weights and original CLI entry')


if __name__ == '__main__':
    {'prepare': prepare, 'freeze': freeze, 'preflight': validate, 'compile': compile_model,
     'parse-compile': parse_compile, 'link': link_model}[sys.argv[1]]()
