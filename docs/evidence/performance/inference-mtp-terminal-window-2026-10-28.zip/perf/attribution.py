"""Offline decomposition of the six preserved timing processes. Never launches a process."""
from pathlib import Path
import hashlib
import json
import re
import statistics as st

W = Path(__file__).resolve().parent
R = W.parents[2]

def pin(p):
    p = Path(p)
    b = p.read_bytes()
    return dict(path=str(p), bytes=len(b), sha256=hashlib.sha256(b).hexdigest())

def fields(line):
    result = {}
    for k, v in re.findall(r'([\w/]+)=([^ ]+)', line):
        try: result[k] = float(v)
        except ValueError: result[k] = v
    return result

def stats(values):
    return dict(median=st.median(values), mean=st.mean(values), min=min(values), max=max(values), samples=values)

def read_case(d):
    text = (d/'stderr.log').read_text(encoding='utf-8')
    current = None
    steps = []
    for line in text.splitlines():
        if line.startswith('prepared T='): current = fields(line)
        if re.match(r'^mtp\d+ ', line):
            assert current is not None
            x = dict(current, **fields(line))
            x['episode'] = int(re.match(r'^mtp(\d+) ', line)[1])
            x['prepare_total'] = x['step_seconds'] - x['seconds']
            x['post_submit_total'] = x['seconds'] - x['submit_seconds']
            x['prepare_outside_cold_batch'] = x['prepare_total'] - x['cold_batch_seconds']
            steps.append(x)
            current = None
    result = json.loads((d/'consumer-result.json').read_text())
    assert len(steps) == result['decode_graph_calls'] == 27
    sums = {k:sum(x[k] for x in steps) for k in (
        'step_seconds','seconds','prepare_total','cold_batch_seconds',
        'prepare_outside_cold_batch','submit_seconds','post_submit_total')}
    sums['proposal_seconds_inferred'] = result['decode_step_sum_seconds'] - sums['step_seconds']
    sums['decode_outside_recorded_steps'] = result['decode_seconds'] - result['decode_step_sum_seconds']
    # These four exclusive bins partition each target episode; proposals are outside it.
    assert abs(sums['prepare_total']+sums['submit_seconds']+sums['post_submit_total']-sums['step_seconds']) < 1e-8
    compiled = [fields(x) for x in text.splitlines() if x.startswith('compiled T=')]
    steady = steps[2:25]  # Same 23 width3 episodes, excludes first2 warm and finalwidth2/Single.
    return dict(name=d.name, variant=d.name.split('-',1)[1], stderr=pin(d/'stderr.log'),
        consumer=pin(d/'consumer-result.json'),
        work={k:result[k] for k in ('actual_graph_calls','prefill_graph_calls','decode_graph_calls','draft_rounds','draft_rows','consumed_drafts')},
        compiled=compiled, sums_seconds=sums, episodes=steps,
        steady_episodes_3_to_25={k:sum(x[k] for x in steady) for k in sums if k in steps[0]},
        cold_compile_seconds=sum(float(fields(x)['cold_seconds']) for x in text.splitlines() if x.startswith('compiled text finite family ')),
        startup={k:result[k] for k in ('startup_to_ready_seconds','prefill_seconds','decode_seconds','decode_step_sum_seconds')},
        ggml_graph_messages=dict(warmup_complete=text.count('CUDA graph warmup complete'),warmup_reset=text.count('CUDA graph warmup reset')))

def main():
    cases = [read_case(d) for d in sorted((W/'timing').iterdir()) if d.is_dir()]
    assert len(cases)==6
    groups={}
    for variant in ('control','current'):
        cs=[x for x in cases if x['variant']==variant]
        groups[variant] = dict(
            sums_seconds={k:stats([x['sums_seconds'][k] for x in cs]) for k in cs[0]['sums_seconds']},
            steady_episodes_3_to_25={k:stats([x['steady_episodes_3_to_25'][k] for x in cs]) for k in cs[0]['steady_episodes_3_to_25']},
            compiled=cs[0]['compiled'],
            ggml_graph_messages=[x['ggml_graph_messages'] for x in cs],
            cold_compile_seconds=stats([x['cold_compile_seconds'] for x in cs]))
    episode_groups=[]
    for episode in range(1,28):
        row=dict(episode=episode)
        for variant in ('control','current'):
            xs=[x['episodes'][episode-1] for x in cases if x['variant']==variant]
            row[variant]={k:stats([x[k] for x in xs]) for k in (
                'step_seconds','prepare_total','cold_batch_seconds','prepare_outside_cold_batch',
                'submit_seconds','post_submit_total')}
        episode_groups.append(row)
    payload=dict(schema='hyle.mtp-terminal.offline-stage-attribution.v1', cases=cases,groups=groups,by_episode=episode_groups,
        actual_source_provenance={
            'control':pin(R/'.scratch/inference-store-cohort-20261028/cli/source/engine/models/qwen35/main.cc'),
            'current':pin(W.parent/'cli/source/engine/models/qwen35/main.cc'),
            'scope':json.loads((W/'binding.json').read_text())['scope'],
        },
        source_boundaries={
            'current_prepare':'main.cc:4334 step_start; 4379 prepare_child; 4385 initialize_slot; 4407 q binding; 4445 identity upload; 4463 cold_start; 4623 prepare_replay; 4634 cold_batch end',
            'current_submit':'main.cc:4701 step.start; 4702 execution.submit; 4721 submit_seconds',
            'current_finish':'main.cc:4798 wait_success; 4811 valid read; 4831 accepted read; 4839 IDs read; 5248 select; 5299 repair; 5102 finished timestamp',
            'control_private_terminal':'main.cc:3299 sample_recursive_prefix: bind/q/identity, prepare_replay Commands, submit/wait, per-row6 readbacks at m2, release inputs; called after target wait in finish_recursive_mtp:5396',
        },
        structural_findings={
            'both_target_routes':'Commands, recorded/reused capture zero in all27 stderr target episodes; shape_admission_seconds zero',
            'target_T3':dict(control_steps=1086,current_steps=1358,control_workspace_bytes=615424,current_workspace_bytes=19987204),
            'target_T2':dict(control_steps=1086,current_steps=1237,control_workspace_bytes=410624,current_workspace_bytes=14565896),
            'target_prefill_and_final_single':'Identical printed steps, workspace, compiled known bytes and unknown provider counts',
            'old_terminal_readback':'m2 old private program reads valid/accepted/finalID per row (6 read calls); current target batches the same predicate/ID facts into3 groups',
            'interpretation':'26 removed whole-Graph helper episodes do not remove their math. Fused target has a larger native/Commands plan; observed submit grows while post-submit shrinks. The total steady path is near flat and lazy carrier setup is larger. API/GPU attribution and a sole causal explanation need the two optional unmodified-image diagnostics.',
        },
        definitions={
            'prepare_total':'stderr step_seconds - seconds: prepare_evaluations entry through submit_evaluations entry; excludes recursive proposals',
            'cold_batch_seconds':'subset of prepare_total: dynamic IO/layout/batch/Store/Append prepare plus prepare_replay',
            'submit_seconds':'original submit entry through ExecutionEpisode.submit return; includes Commands host orchestration and any synchronous native waits, not CPU-only time',
            'post_submit_total':'stderr seconds-submit_seconds: target wait/readback/selection/repair/publication; control includes old PrefixSamplingProgram here',
            'proposal_seconds_inferred':'report decode_step_sum_seconds minus sum(stderr target step_seconds); original per-call recursive proposal timings, stderr rounding uncertainty',
            'steady_episodes_3_to_25':'same23 T3 episodes; excludes first2 episodes and final T2/Single',
        },limitations=[
            'No separate wait/readback/repair timing in these stderr logs; post_submit_total is inclusive of those stages.',
            'No CUDA API/kernel trace collected for this experiment; no GPU/CPU attribution or host-busy claim.',
            'Medians of separate partitions need not add to the median total; use each sample for conservation.',
            'Only six existing timing processes, no reruns. A structured cost change is not proof of sole slowdown cause.'
        ])
    (W/'attribution.json').write_text(json.dumps(payload,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    for variant,g in groups.items():
        print(variant, 'total ms', {k:round(v['median']*1000,3) for k,v in g['sums_seconds'].items()})
    for x in episode_groups:
        if x['episode'] in (1,2,26,27):
            print('episode',x['episode'],{variant:{k:round(v['median']*1000,3) for k,v in x[variant].items()} for variant in ('control','current')})

if __name__=='__main__':main()
