"""Offline ProcessStreams recovery and whole-consumer CUDA structure; no native launch."""
from pathlib import Path
from collections import defaultdict
import hashlib
import importlib.util
import json
import sqlite3
import statistics
import sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent

def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def pin(p):
 p=Path(p);b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def save(p,v):
 p=Path(p)
 with p.open('x',encoding='utf-8') as f:f.write(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
def module(name,p):
 s=importlib.util.spec_from_file_location(name,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
def union(rows):
 out=0;left=right=None
 for a,z in sorted(rows):
  if right is None:left,right=a,z
  elif a>right:out+=right-left;left,right=a,z
  else:right=max(right,z)
 return (out+(right-left if right is not None else 0))/1e6
def groups(rows,key):
 g=defaultdict(list)
 for x in rows:g[key(x)].append(x)
 return [dict(key=k,count=len(xs),sum_ms=sum(x['end']-x['start'] for x in xs)/1e6,
  median_us=statistics.median(x['end']-x['start'] for x in xs)/1e3,
  bytes=sum(x.get('bytes',0) for x in xs)) for k,xs in sorted(g.items(),key=lambda kv:-sum(x['end']-x['start'] for x in kv[1]))]

def parse(name,window):
 folder=W/'runs'/name;path=folder/'trace.sqlite'
 c=sqlite3.connect(path.resolve().as_uri()+'?mode=ro&immutable=1',uri=True);c.row_factory=sqlite3.Row
 tables={x[0] for x in c.execute("select name from sqlite_master where type='table'")}
 strings={x['id']:x['value'] for x in c.execute('select * from StringIds')}
 devices={int(x[0]) for x in c.execute('select distinct pid from TARGET_INFO_CUDA_DEVICE')}
 contexts={int(x[0]) for x in c.execute('select distinct processId from TARGET_INFO_CUDA_CONTEXT_INFO')}
 assert len(devices&contexts)==1
 pid=next(iter(devices&contexts));streams={}
 for row in c.execute('select * from ProcessStreams'):
  if ((row['globalPid']>>24)&0xffffff)!=pid:continue
  filename=strings[row['filenameId']];kind='stdout' if 'stdout_' in filename else 'stderr' if 'stderr_' in filename else None
  if kind:
   assert kind not in streams;streams[kind]=strings[row['contentId']]
 assert set(streams)=={'stdout','stderr'}
 for k,v in streams.items():
  p=folder/f'native-{k}.log'
  if p.exists():assert p.read_text(encoding='utf-8')==v
  else:p.write_text(v,encoding='utf-8')
 report=json.loads(streams['stdout']);normalized=dict(report)
 assert len(report['sessions'])==1
 for key,value in report['sessions'][0]['result'].items():normalized.setdefault(key,value)
 plan=read(W/'plan.json');entry=next(x for x in plan['commands'] if x['name']==name)
 delta=window.differences(window.task(read(entry['reference']['path'])),window.task(normalized));assert not delta,delta[:3]
 save(folder/'report-processstreams.json',report)
 gpu=[]
 for kind in ('KERNEL','MEMCPY','MEMSET'):
  for rr in c.execute('select * from CUPTI_ACTIVITY_KIND_'+kind):
   x=dict(rr)
   if ((x['globalPid']>>24)&0xffffff)!=pid:continue
   x['kind']=kind
   if kind=='KERNEL':x['name']=strings[x['demangledName']]
   gpu.append(x)
 api=[]
 for table in ('CUPTI_ACTIVITY_KIND_RUNTIME','CUPTI_ACTIVITY_KIND_DRIVER'):
  if table not in tables:continue
  for rr in c.execute('select * from '+table):
   x=dict(rr)
   if ((x['globalTid']>>24)&0xffffff)!=pid:continue
   x['table']=table;x['name']=strings[x['nameId']];api.append(x)
 kinds={x['id']:x['label'] for x in c.execute('select * from ENUM_CUDA_MEMCPY_OPER')}
 kernels=[x for x in gpu if x['kind']=='KERNEL'];copies=[x for x in gpu if x['kind']=='MEMCPY']
 apigroups=groups(api,lambda x:x['name'])
 selected_api=[x for x in apigroups if any(k in x['key'] for k in ('Graph','LaunchKernel','Malloc','Free','Memcpy','Memset','Synchronize','Event'))]
 result=dict(name=name,sqlite=pin(path),nsys_controller=read(folder/'process.json'),actual_consumer_pid=pid,
  consumer_identity='CUDA_DEVICE.pid intersect CUDA_CONTEXT_INFO.processId, all ProcessStreams/CUPTI rows filtered by encoded actualPID',
  quality=dict(status='PASS_SAME_OUTPUT_AND_MATH_TASK',differences=delta,reference=entry['reference']),
  report_work={k:report[k] for k in ('actual_graph_calls','decode_graph_calls','draft_rounds','consumed_drafts','actual_target_rows','actual_draft_rows','generated_tokens')},
  gpu=dict(kernel_count=len(kernels),kernel_sum_ms=sum(x['end']-x['start'] for x in kernels)/1e6,
   all_activity_union_ms=union([(x['start'],x['end']) for x in gpu]),
   activity_envelope_ms=(max(x['end'] for x in gpu)-min(x['start'] for x in gpu))/1e6,
   by_kind=groups(gpu,lambda x:x['kind']),memcpy_by_kind=groups(copies,lambda x:kinds[x['copyKind']]),
   kernel_groups=groups(kernels,lambda x:(x['name'],tuple(x[k] for k in ('gridX','gridY','gridZ')),tuple(x[k] for k in ('blockX','blockY','blockZ'))))),
  api=dict(count=len(api),duration_sum_ms=sum(x['end']-x['start'] for x in api)/1e6,
   interval_union_ms=union([(x['start'],x['end']) for x in api]),selected=selected_api,all=apigroups),
  application_NVTX_labels=False,scope='Whole actual consumer including loading/cold preparation/prefill/decode/teardown. No asserted per-step or decode partition; API sums are not host busy wall time.')
 c.close();save(folder/'analysis-processstreams.json',result)
 return result

def main():
 window=module('actual_k2_completed_window',W.parent/'window.py')
 rows={name:parse(name,window) for name in ('control','current')}
 save(W/'summary-processstreams.json',dict(status='TWO_ACTUAL_PROFILES_OFFLINE_RECOVERED',arms=rows,
  native_reruns=0,parser_amendment=pin(__file__),original_frozen_helper_unchanged=pin(W/'profile.py'),
  limitations=['Original stdout parser failures retained. Reports recovered solely from SQLite ProcessStreams.',
   'One profile per arm is diagnostic, not a throughput sample or significance test.',
   'No HyleLogicalCalls ranges. CUDA API/kernel/copy totals are whole-process, not decode-only.']))
 for name,x in rows.items():
  print(name,'PID',x['actual_consumer_pid'],'kernels',x['gpu']['kernel_count'],'kernel_ms',round(x['gpu']['kernel_sum_ms'],3),'gpu_union_ms',round(x['gpu']['all_activity_union_ms'],3),'api_ms',round(x['api']['duration_sum_ms'],3))
  print('APIs',[(a['key'],a['count'],round(a['sum_ms'],3)) for a in x['api']['selected']])
  print('copies',x['gpu']['memcpy_by_kind'])

if __name__=='__main__':main()
