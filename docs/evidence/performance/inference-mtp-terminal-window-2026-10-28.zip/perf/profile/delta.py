"""Small offline delta, using only the already-extracted profile summary."""
from collections import defaultdict
from pathlib import Path
import json
W=Path(__file__).resolve().parent
x=json.loads((W/'summary-processstreams.json').read_text())['arms']
kernels={}
for name in ('control','current'):
 g=defaultdict(lambda:dict(count=0,sum_ms=0))
 for row in x[name]['gpu']['kernel_groups']:
  item=g[row['key'][0]];item['count']+=row['count'];item['sum_ms']+=row['sum_ms']
 kernels[name]=g
changed=[]
for name in sorted(set(kernels['control'])|set(kernels['current'])):
 a=kernels['control'][name];z=kernels['current'][name]
 if a['count']!=z['count']:changed.append(dict(kernel=name,control=a,current=z,delta_count=z['count']-a['count']))
api={name:{row['key']:row for row in x[name]['api']['all']} for name in x}
result=dict(status='TWO_WHOLE_PROCESS_STRUCTURE_DELTAS',candidate_decision='NOT_ADOPTED',kernel_count_changes=changed,
 api_count_changes=[dict(api=key,control=api['control'].get(key,{}).get('count',0),current=api['current'].get(key,{}).get('count',0))
  for key in sorted(set(api['control'])|set(api['current']))
  if api['control'].get(key,{}).get('count',0)!=api['current'].get(key,{}).get('count',0)],
 conclusions=[
  '26 fewer engine auxiliary Graph episodes remove26 original completion event synchronizations, but are not26 fewer CUDA GraphLaunch calls.',
  'Old Verify raw TopK contributes26 arg_tiles and26 arg_finish kernels, absent in current. Added predicate/concat kernels total101; net kernel count +49.',
  'D2D count and bytes are identical. DtoH count/bytes decrease, consistent with grouped predicate/ID reads plus fewer episode status transfers; readback API calls and DMA counts are distinct.',
  'No observed whole-process bulk-copy increase or major extra GPU compute explains the eight-process slowdown. Current whole-process GPU/API duration is lower in this one instrumented sample, which cannot establish a decode speedup.',
  'The preserved stderr attribution shows larger target Commands plan and lazy carrier setup. Do not hide that cost by changing default warmup or claim that structural fusion itself guarantees speed.',
  'No further profile/leaf matrix is justified by these two diagnostics alone; retain the measured no-net-speedup result when deciding whether the fused candidate stays.'
 ],decision_basis='Root restored product main to pre-candidate HEAD plus the independent12-line retired-ledger fix. Candidate27cd source, patch, eight-process observations and two actual profiles remain preserved; no performance improvement was established.',
 next_bounded_candidate=dict(implemented=False,
  proposal='Independently remove the old stochastic Verify raw TopK only if its real ID-output/observer contracts can be preserved.',
  evidence='The fused diagnostic eliminated26 arg_tiles plus26 arg_finish kernels. Their52-kernel removal is an observed structural fact, not an isolated speed measurement or proof those outputs are unused by every consumer.',
  scope='Not implemented or tested in this batch; no more compiler/model/profile processes requested.'),
 parser_amendment=dict(original_profile_helper_unchanged=True,
  original_failure='Root reported both original parse actions failed because nsys redirected app output to SQLite ProcessStreams; no raw parse-failure files were supplied. Frozen original code and successful native/process/SQLite remain intact.',
  actual_recovery='Read ProcessStreams StringIds contents filtered by CUDA-device/context-proven consumer PID; preserve exact aggregate report, merge only missing sole-session result fields for the existing window.task comparator.',
  offline_only=True,native_reruns=0),scope='Whole process only; loading/cold preparation/prefill/decode/teardown are not separately labeled. No formal TPS update or sole-cause claim.')
with (W/'delta.json').open('x',encoding='utf-8') as f:f.write(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print('OFFLINE_DELTA_SAVED',len(changed),'changed kernel families')
