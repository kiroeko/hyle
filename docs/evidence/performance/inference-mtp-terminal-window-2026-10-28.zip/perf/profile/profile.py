"""Two explicit unmodified-image diagnostic profiles. prepare/parse are offline; only run launches."""
from pathlib import Path
import hashlib
import importlib.util
import json
import os
import sys
sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
PERF = W.parent
R = W.parents[3]
OLD = R/'.scratch/inference-current-host-profile-20261028'
DRIVER = R/'.scratch/inference-current-review-profile-20261027/build.py'
NSYS = Path('C:/Program Files/NVIDIA Corporation/Nsight Systems 2026.1.3/target-windows-x64/nsys.exe')
NAMES = ('control','current')

def read(p): return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def pin(p):
    p=Path(p); data=p.read_bytes()
    return dict(path=str(p),bytes=len(data),sha256=hashlib.sha256(data).hexdigest())
def exact(row): assert pin(row['path'])==row,row['path']
def save(p,value):
    p=Path(p);p.parent.mkdir(parents=True,exist_ok=True)
    with p.open('x',encoding='utf-8') as out: out.write(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
def module(name,p):
    s=importlib.util.spec_from_file_location(name,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m

def prepare():
    binding=read(PERF/'binding.json'); commands=[]
    profiler=read(OLD/'plan.json')['profiler'];exact(profiler)
    assert Path(profiler['path'])==NSYS
    for name,first in (('control','01-control'),('current','02-current')):
        version=binding['versions'][name]
        argv=read(PERF/f'timing/{first}/command.json')['command']
        assert argv[0]==version['image']['path']
        assert argv[argv.index('--mtp-max-drafts')+1]=='2' and argv[argv.index('--sampling')+1]=='random'
        assert argv[argv.index('--steps')+1]=='64' and '--trace' not in argv
        for k in ('image','runtime'): exact(version[k])
        exact(version['compiled']['snapshot'])
        command=[str(NSYS),'profile','--trace=cuda,cublas,nvtx','--cuda-graph-trace=node',
            '--sample=none','--cpuctxsw=none','--discard-environment=true',
            '--duration=60','--kill=true','--wait=all','--stats=false','--export=sqlite',
            '--output='+str(W/f'runs/{name}/trace'),*argv]
        commands.append(dict(name=name,consumer=argv,command=command,image=version['image'],
            runtime=version['runtime'],source=version['compiled']['snapshot'],
            reference=pin(PERF/f'timing/{first}/consumer-result.json'),timeout_seconds=120))
    save(W/'plan.json',dict(script=pin(__file__),profiler=profiler,driver=pin(DRIVER),
        binding=pin(PERF/'binding.json'),commands=commands,native_processes=2,retries=0,
        scope='Same two actual K2 random R1 CLI images and exact argv as completed eight-process window. One diagnostic profile per image, no new build or instrumentation.',
        limitations=[
            'Neither CLI has HyleLogicalCalls NVTX. Do not reuse the old logical-root parser or assert exact decode/prepare/wait windows.',
            'Whole-process CUDA API/kernel/copy/GraphLaunch structure can be compared; startup/loading/prefill are included until an independently evidenced boundary is available.',
            'No --nvtx-domain-include filter: unmodified images have no application domain; preserve any existing native-library annotations.',
            'Controller Popen PID is nsys, not the consumer PID. Resolve the latter from SQLite device/context tables.',
            'No TPS or quality inference from a single instrumented sample; original eight timing/memory processes are not rerun.',
            binding['scope']]))
    print('TWO_UNMODIFIED_PROFILE_COMMANDS_READY; no profiler/model started')

def run(name):
    assert name in NAMES
    plan=read(W/'plan.json')
    for k in ('script','profiler','driver','binding'):exact(plan[k])
    row=next(x for x in plan['commands'] if x['name']==name)
    for k in ('image','runtime','source','reference'):exact(row[k])
    folder=W/'runs'/name;assert not folder.exists(),'Preserve original attempt; no rerun'
    runtime=read(row['runtime']['path']);env=os.environ.copy()
    env['PATH']=str(Path(row['image']['path']).parent)+';'+runtime['PATH']
    env.update(runtime.get('configured_flags',{}));env['HF_HUB_OFFLINE']='1';env['TRANSFORMERS_OFFLINE']='1'
    driver=module('prior_actual_nsys_driver',DRIVER)
    driver.execute(row['command'],folder,env,row['timeout_seconds'])
    print('PROFILE_FINISHED; parse existing output offline, never rerun for a parser error')

def parse(name):
    assert name in NAMES
    row=next(x for x in read(W/'plan.json')['commands'] if x['name']==name)
    folder=W/'runs'/name;process=read(folder/'process.json');assert process['exit']==0
    decoder=json.JSONDecoder();text=(folder/'stdout.log').read_text(encoding='utf-8',errors='replace');reports=[]
    for i,c in enumerate(text):
        if c!='{':continue
        try:v,_=decoder.raw_decode(text[i:])
        except json.JSONDecodeError:continue
        if isinstance(v,dict) and 'sessions' in v and 'generated_ids' in v:reports.append(v)
    assert len(reports)==1, 'Keep raw stdout; resolve report extraction offline without a new native process'
    report=reports[0];window=module('original_completed_k2_window',PERF/'window.py')
    delta=window.differences(window.task(read(row['reference']['path'])),window.task(report))
    save(folder/'quality.json',dict(status='PASS_SAME_OUTPUT_AND_MATH_TASK' if not delta else 'FACT_DIFFERENCES',differences=delta,
        nsys_controller_process=process,consumer_pid='resolve_from_SQLite',reference=row['reference']))
    save(folder/'report.json',report);assert not delta
    print('OFFLINE_REPORT_MATCH; SQLite has no application phase labels')

if __name__=='__main__':
    action=sys.argv[1]
    if action=='prepare':prepare()
    elif action=='run':run(sys.argv[2])
    elif action=='parse':parse(sys.argv[2])
    else:raise SystemExit('prepare | run control|current | parse control|current')
