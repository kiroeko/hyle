"""Offline archive of the completed eight-process candidate window and two profiles."""
from pathlib import Path
import hashlib
import json
import math
import zipfile

W = Path(__file__).resolve().parent
PARENT = W.parent
R = Path('C:/public/project-hyle/hyle')
DEST = R / 'docs/evidence/performance/inference-mtp-terminal-window-2026-10-28'
METRICS = ('prefill_tokens_per_second', 'full_decode_tokens_per_second',
           'session_output_tokens_per_second', 'session_processed_tokens_per_second')
CANDIDATE_MAIN = '27cd19c1e87b457007cc7ae4bbd4a90fae1a4e7df570f93c733b6c0cbcbf1080'
CONTROL_MAIN = '41199a68784ea521affc47542b62f01ba430faeaebc1d56e34ff6e403bc86a15'


def read(path): return json.loads(Path(path).read_text(encoding='utf-8-sig'))
def encoded(value): return (json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + '\n').encode()
def sha(raw): return hashlib.sha256(raw).hexdigest()
def pin(path):
    path = Path(path); raw = path.read_bytes()
    return dict(path=str(path.resolve()), bytes=len(raw), sha256=sha(raw))
def exact(row):
    actual = pin(row['path'])
    assert (actual['bytes'], actual['sha256']) == (row['bytes'], row['sha256']), row['path']
def success(process):
    assert process['exit'] == 0 and not process.get('timed_out') and not process.get('timeout'), process
def compact_stats(value): return {k: v for k, v in value.items() if k != 'samples'}


def main():
    outjson, outzip = DEST.with_suffix('.json'), DEST.with_suffix('.zip')
    assert not outjson.exists() and not outzip.exists(), 'Preserve completed evidence'
    summary = read(W / 'summary.json'); binding = read(W / 'binding.json')
    assert summary['status'] == 'COMPLETE8_STABLE' and summary['processes'] == 8
    assert summary['timing_processes'] == 6 and summary['independent_memory_processes'] == 2
    assert summary['policy'] == dict(sampling='random', temperature=1, top_k=0, top_p=1, seed=17, max_drafts=2)
    for mode, count in (('timing', 6), ('memory', 2)):
        section = summary[mode]
        assert section['status'] == 'COMPLETE_STABLE' and section['processes'] == count
        assert section['identical_output_and_math_task'] is True and section['semantic_task_differences'] == []
        assert all(row['stable'] for row in section['within_arm_complete_non_time'].values())
        assert section['historical_samples_pooled'] is False
    timing, memory = read(W / 'timing/runs.json'), read(W / 'memory/runs.json')
    rows = timing + memory
    assert len(rows) == 8 and len({row['process']['pid'] for row in rows}) == 8
    for row in rows:
        success(row['process'])
        assert row['process']['image'] == binding['versions'][row['variant']]['image']
        assert row['observation']['prompt_tokens'] == 154
        assert row['observation']['actual_generated_tokens'] == 64
        assert len(row['observation']['generated_ids']) == 64
    assert len([r for r in timing if r['variant'] == 'control']) == 3
    assert len([r for r in timing if r['variant'] == 'current']) == 3
    assert {r['variant'] for r in memory} == {'control', 'current'}
    assert all(r['process']['throughput_evidence'] and not r['process']['memory_only'] for r in timing)
    assert all(not r['process']['throughput_evidence'] and r['process']['memory_only'] for r in memory)
    table = []
    for key in METRICS:
        control, candidate = (summary['timing']['groups'][v][key] for v in ('control', 'current'))
        assert control['count'] == candidate['count'] == 3
        percent = 100 * (candidate['median'] / control['median'] - 1)
        assert math.isclose(percent, summary['median_delta_percent'][key], rel_tol=1e-12, abs_tol=1e-12)
        table.append(dict(metric=key, control=control, candidate=candidate, candidate_delta_percent=percent))
    assert summary['median_delta_percent']['full_decode_tokens_per_second'] < 0
    profiles = read(W / 'profile/summary-processstreams.json')
    assert profiles['status'] == 'TWO_ACTUAL_PROFILES_OFFLINE_RECOVERED' and profiles['native_reruns'] == 0
    assert set(profiles['arms']) == {'control', 'current'}
    profile_rows = []
    for name, row in profiles['arms'].items():
        success(row['nsys_controller'])
        assert row['quality']['status'] == 'PASS_SAME_OUTPUT_AND_MATH_TASK' and row['quality']['differences'] == []
        exact(row['quality']['reference'])
        assert row == read(W / 'profile/runs' / name / 'analysis-processstreams.json')
        work = row['report_work']
        assert work['generated_tokens'] == 64 and work['actual_target_rows'] == 232 and work['actual_draft_rows'] == 289
        profile_rows.append(dict(variant=name, consumer_pid=row['actual_consumer_pid'],
            controller=row['nsys_controller'], quality=row['quality'], work=work,
            gpu={key: value for key, value in row['gpu'].items() if key != 'kernel_groups'},
            api_count=row['api']['count'], api_duration_sum_ms=row['api']['duration_sum_ms'],
            scope=row['scope'], SQLite_identity_only=row['sqlite']))
    assert len({r['consumer_pid'] for r in profile_rows}) == 2
    assert not {r['consumer_pid'] for r in profile_rows} & {r['process']['pid'] for r in rows}
    delta = read(W / 'profile/delta.json'); assert delta['candidate_decision'] == 'NOT_ADOPTED'
    attribution = read(W / 'attribution.json'); assert len(attribution['cases']) == 6
    archive = {}
    def add(path, name=None):
        path = Path(path); name = name or path.relative_to(PARENT).as_posix()
        assert name not in archive and path.is_file(), (name, str(path))
        assert path.suffix.lower() in ('.json', '.jsonl', '.log', '.py', '.cc', '.h', '.patch', '.txt', '.csv', '.ids')
        archive[name] = path.read_bytes()
    def metadata_tree(directory):
        directory = Path(directory)
        for path in sorted(directory.rglob('*')):
            if path.is_file() and path.suffix.lower() in ('.json', '.jsonl', '.log', '.py', '.txt', '.csv'):
                if path.name not in ('running.json', 'live.json', 'package-readback.json'):
                    add(path)
    # All current window raw facts, independent memory samples and grouped profile rows.
    # SQLite/nsys archives, binaries and tensor/model payloads are excluded by extension.
    metadata_tree(W)
    metadata_tree(PARENT / 'cli')
    for version, expected in (('control', CONTROL_MAIN), ('current', CANDIDATE_MAIN)):
        item = binding['versions'][version]
        for key in ('ready', 'inputs', 'runtime'): exact(item[key])
        compiled = item['compiled']; success(compiled['process'])
        assert compiled['source']['sha256'] == compiled['snapshot']['sha256'] == expected
        exact(compiled['snapshot'])
        add(compiled['snapshot']['path'], 'source/' + version + '/main.cc')
        assert len(read(item['inputs']['path'])) == 229
        if version == 'control':
            for key in ('ready', 'inputs', 'runtime'):
                add(item[key]['path'], 'control-provenance/' + key + '.json')
            for key in ('command', 'dependencies', 'actual_dependencies'):
                exact(compiled[key]); add(compiled[key]['path'], 'control-provenance/' + key + '.json')
    source_freeze = read(PARENT / 'cli/source-freeze.json')
    exact(source_freeze['snapshot']); exact(source_freeze['helper']); exact(source_freeze['project_dependencies'])
    current = read(PARENT / 'cli/ready-model.json'); success(current['process'])
    assert current['compiled'] == binding['versions']['current']['compiled'] and current['closure_inputs'] == 229
    for key in ('original_protocol', 'original_runner', 'observer'):
        exact(binding[key]); add(binding[key]['path'], 'helpers/' + key + '.py')
    for key in ('prompt', 'input'):
        exact(binding[key]); add(binding[key]['path'], 'inputs/' + Path(binding[key]['path']).name)
    # Manifest identity only: weights and calibration payloads remain cached, never copied.
    exact(binding['input_manifest'])
    add(PARENT / 'changes.patch', 'candidate-changes.patch')
    metrics_memory = {}
    for version in ('control', 'current'):
        m = summary['memory']['groups'][version]
        assert m['ready_baseline']['unknown'] and m['ready_baseline']['sample'] is None
        metrics_memory[version] = dict(sampled_peaks=m['sampled_peaks'], ready_baseline=m['ready_baseline'],
            actual_sample_gaps_ms=compact_stats(m['actual_sample_gaps_ms']), sample_cost_ms=compact_stats(m['sample_cost_ms']),
            sample_count=m['sample_count'], running_sample_count=m['running_sample_count'],
            requested_interval_seconds=m['requested_interval_seconds'], null_sample_counts=m['null_sample_counts'],
            setup_error=m['setup_error'], thread_error=m['thread_error'],
            phase_windows={name: dict(begin_ns=value['begin_ns'], end_ns=value['end_ns'], sample_count=value['sample_count'],
                exact_phase_boundary_values=value['exact_phase_boundary_values'], bracket_ages_ns=value['bracket_ages_ns'],
                values={k:compact_stats(v) for k,v in value['values'].items()}) for name,value in m['phase_windows'].items()})
    manifest = encoded(dict(members=[dict(name=name, bytes=len(raw), sha256=sha(raw)) for name, raw in sorted(archive.items())]))
    archive['MANIFEST.json'] = manifest
    with zipfile.ZipFile(outzip, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as z:
        for name, raw in sorted(archive.items()): z.writestr(name, raw)
    with zipfile.ZipFile(outzip) as z:
        assert z.testzip() is None and set(z.namelist()) == set(archive)
        for name, raw in archive.items(): assert sha(z.read(name)) == sha(raw), name
    result = dict(schema='hyle.performance.mtp-terminal-candidate.v1', date='2026-10-28',
        status='COMPLETE8_STABLE_CANDIDATE_NOT_ADOPTED', candidate_decision='NOT_ADOPTED',
        decision='No net end-to-end speedup; larger cold preparation and target plan workspace. Keep only the independent failure fix.',
        source=dict(control_main_sha256=CONTROL_MAIN, candidate_main_sha256=CANDIDATE_MAIN,
            control_image=binding['versions']['control']['image'], candidate_image=binding['versions']['current']['image'],
            closure_inputs_per_image=229, changed_link_inputs=binding['replacements'], scope=binding['scope']),
        counts=dict(CXX=1, links=1, timing_native_processes=6, independent_memory_native_processes=2,
            diagnostic_profile_consumer_processes=2, diagnostic_profiler_controller_processes=2,
            total_model_processes=10, native_failures=0, successful_native_reruns=0, SDK_CXX=0, NVCC=0, downloads=0),
        policy=summary['policy'], workload=dict(prompt_tokens=154, requested_outputs=64, sequences=1, sessions=1,
            turns=1, capacity=1024, backend='cuda', draft_K=2, decode_overlap='off', peer_comparison=False),
        four_metrics=table,
        end_to_end={version: {key: value for key,value in summary['timing']['groups'][version].items() if key not in METRICS}
            for version in ('control','current')},
        same_task=dict(identical_generated_IDs_acceptance_RNG_and_actual_row_work=True,
            full_semantic_differences=summary['timing']['semantic_task_differences'],
            graph_episodes=dict(control=131,candidate=105), complete_non_time_differences=summary['timing']['complete_cross_arm_differences'],
            actual_processes=summary['actual_processes']),
        independent_memory=metrics_memory,
        compiled_plan_facts=attribution['structural_findings'],
        stage_attribution=dict(groups=attribution['groups'], definitions=attribution['definitions'], limitations=attribution['limitations']),
        whole_process_profiles=profile_rows, profile_deltas=delta,
        parser_amendment=delta['parser_amendment'],
        limitations=['Three timing samples per image are descriptive; no significance, sole-cause or stable-speedup claim.',
            'Do not pool with earlier default K1 or peer windows. This is P154/K2/random/seed17, not the default K1 board.',
            'Control differs by the candidate plus two intervening cold abstractions and retired-ledger fix; this does not isolate terminal fusion alone.',
            'Memory is independent PSAPI/PDH sampling. Ready baselines are null/unknown, actual gaps are retained, and sampled peaks are lower bounds.',
            'Two profiles cover whole consumer processes including loading, cold prepare, prefill, decode and teardown. GPU/API sums are not decode wall time.',
            'Profile raw output was recovered offline from ProcessStreams; two original parser failures did not cause a native rerun. See amendment for unavailable raw parser-failure files.',
            'No trained-quality, tensor-bit-equality, new-native capability or overlapping-episode claim is established by this performance window.',
            'Candidate was withdrawn. These measurements do not describe the separately retained failure-fix product image.'],
        archive=dict(**pin(outzip), members=len(archive), manifest_sha256=sha(manifest), CRC='PASS', all_member_SHA256='PASS'))
    with outjson.open('xb') as f: f.write(encoded(result))
    receipt = dict(JSON=pin(outjson), ZIP=pin(outzip), members=len(archive), CRC='PASS', all_member_SHA256='PASS')
    with (W / 'package-readback.json').open('xb') as f: f.write(encoded(receipt))
    print(json.dumps(receipt, ensure_ascii=False))


if __name__ == '__main__': main()
