"""Eight fresh K2-random observations; only run/resume start model processes."""
from pathlib import Path
import copy
import importlib.util
import json
import math
import os
import sys
import time
import traceback

sys.dont_write_bytecode = True
R = Path(r'C:\public\project-hyle\hyle')
W = Path(__file__).resolve().parent
OLD = R / '.scratch/inference-small-projection-20261028/model-candidate/attempt2'
CLI = W.parent / 'cli'
spec = importlib.util.spec_from_file_location('terminal_original_protocol', R / '.scratch/mtp-performance-convergence-20261025/baseline/window.py')
p = importlib.util.module_from_spec(spec); spec.loader.exec_module(p)
b = p.base
spec = importlib.util.spec_from_file_location('terminal_non_time', R / '.scratch/inference-current-review-profile-20261027/analyze.py')
facts = importlib.util.module_from_spec(spec); spec.loader.exec_module(facts)
read, pin = b.read, b.identity
POLICY = dict(sampling='random', temperature=1, top_k=0, top_p=1, seed=17, max_drafts=2)
METRICS = ('prefill_tokens_per_second', 'full_decode_tokens_per_second',
           'session_output_tokens_per_second', 'session_processed_tokens_per_second')


def save(path, value):
    path = Path(path); path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('x', encoding='utf-8') as stream:
        stream.write(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + '\n')


def exact(row):
    assert pin(row['path']) == row, row['path']


def differences(a, z, at='$'):
    if type(a) is not type(z): return [dict(path=at, control=a, current=z)]
    if isinstance(a, dict):
        out = []
        for key in sorted(set(a) | set(z)):
            out += differences(a[key], z[key], at + '.' + key) if key in a and key in z else [dict(path=at + '.' + key, control=a.get(key), current=z.get(key))]
        return out
    if isinstance(a, list):
        if len(a) != len(z): return [dict(path=at, control=a, current=z)]
        return [d for i, (x, y) in enumerate(zip(a, z)) for d in differences(x, y, at + '[' + str(i) + ']')]
    return [] if a == z else [dict(path=at, control=a, current=z)]


def prepare():
    assert not (W / 'binding.json').exists(), 'Preserve original preparation'
    versions = {'control': OLD / 'ready-control.json', 'current': CLI / 'ready-model.json'}
    ready = {name: read(path) for name, path in versions.items()}
    assert ready['control']['image']['sha256'] == '0c6227e048997fbf9f830153664371558b40bf2fc011ff587772a525cf4b76d9'
    for value in ready.values():
        assert value['process']['exit'] == value['compiled']['process']['exit'] == 0
        for field in ('image', 'inputs', 'recipe', 'runtime', 'source_freeze'): exact(value[field])
        exact(value['compiled']['snapshot'])
        native = read(value['runtime']['path'])['native']; exact(native)
        assert (Path(value['image']['path']).parent / Path(native['path']).name).samefile(native['path'])
    old_rows, new_rows = (read(ready[k]['inputs']['path']) for k in ('control', 'current'))
    assert len(old_rows) == len(new_rows) == 229
    changes = [dict(control=a, current=z) for a, z in zip(old_rows, new_rows) if a != z]
    assert changes == [dict(control=ready['control']['compiled']['object'], current=ready['current']['compiled']['object'])]
    template = read(OLD / 'window/single-mtp-timing-plan.json')
    for field in ('input', 'prompt'): exact(template[field])
    manifest = R / '.scratch/qwen35-unsloth-mtp-20261024/geometry-v2-check/original/weights.tsv'
    prompt_ids = Path(template['prompt']['path']).read_text().split()
    assert len(prompt_ids) == 154 and (manifest.parent / 'prompt.ids').read_text().split() == prompt_ids
    snapshot = Path(ready['control']['compiled']['snapshot']['path']).read_text(encoding='utf-8-sig')
    required = ('--sampling', '--temperature', '--top-k', '--top-p', '--seed', '--mtp-max-drafts')
    assert all(('option == "' + flag + '"') in snapshot for flag in required)
    binding = dict(versions={name: dict(ready=pin(path), **{k: ready[name][k] for k in ('image', 'inputs', 'runtime', 'compiled')}) for name, path in versions.items()},
        replacements=changes, prompt=template['prompt'], input=template['input'], input_manifest=pin(manifest),
        policy=POLICY, original_protocol=pin(p.__file__), original_runner=pin(b.RUNNER), observer=pin(b.OBSERVER),
        scope='Same ON227 SDK/weights plus original entry; current Model also includes two intervening cold abstractions and retired-ledger fix. Not terminal-only causal isolation.',
        historical_samples_pooled=False, expected_model_processes=8)
    save(W / 'binding.json', binding)
    for mode, order in [('timing', ('control', 'current', 'current', 'control', 'control', 'current')), ('memory', ('control', 'current'))]:
        cfg = copy.deepcopy(template)
        for key in ('binding', 'commands', 'canonical_main', 'configuration', 'retained_plan'): cfg.pop(key, None)
        commands = []
        for ordinal, version in enumerate(order, 1):
            value = binding['versions'][version]
            command = [value['image']['path'], *template['commands'][0]['command'][1:]]
            for flag, val in [('--sampling', 'random'), ('--mtp-max-drafts', '2')]: command[command.index(flag) + 1] = val
            command += ['--temperature', '1', '--top-k', '0', '--top-p', '1', '--seed', '17']
            assert all(flag not in command for flag in ('--trace', '--schedule', '--session-schedules', '--ignore-eos'))
            commands.append(dict(ordinal=ordinal, variant=version, arm='hyle_mtp', scenario='single',
                command=command, folder=str(W / mode / (f'{ordinal:02d}-' + version)), ready=value['ready'], image=value['image'], environment=value['runtime']))
        cfg.update(mode=mode, commands=commands, script=pin(__file__), binding=pin(W / 'binding.json'), policy=POLICY,
            processes=len(commands), timing_processes=len(commands) if mode == 'timing' else 0,
            memory_processes=len(commands) if mode == 'memory' else 0, arm_order=list(order),
            contract='P154/C1024/N1R1 CUDA/K2 fixed random policy, natural maximum64 outputs respecting EOS. No warmup/trace/forced acceptance. Fresh samples only.',
            plan_only=True, automatic_retries=0)
        save(W / (mode + '-plan.json'), cfg)
    print('PREPARED8_NOT_RUN: six interleaved timing, two independent memory; no old timing samples pooled')


def config(mode):
    assert mode in ('timing', 'memory')
    cfg = read(W / (mode + '-plan.json')); exact(cfg['script']); exact(cfg['binding'])
    for field in ('prompt', 'input', 'input_manifest'): exact(read(cfg['binding']['path'])[field])
    p.WORKLOAD = 'single'
    return cfg


def parse_one(entry, cfg):
    folder = Path(entry['folder']); process = read(folder / 'result.json')
    assert process['exit'] == 0 and not process.get('timeout') and not process.get('reader_errors')
    assert process['command'] == entry['command'] and process['image'] == entry['image']
    p.WORKLOAD = 'single'
    observation = p.parse(folder, 'hyle_mtp', cfg)
    raw = observation['raw']
    assert raw['mtp'] is True and raw['sampling'] == 'random' and raw['sampling_seed'] == POLICY['seed']
    assert raw['mtp_max_drafts'] == 2 and raw['mtp_min_draft_probability'] == 0 and raw['decode_overlap'] is False
    assert raw['sampling_top_k'] == 0 and math.isclose(raw['sampling_top_p'], 1) and math.isclose(raw['sampling_temperature'], 1)
    assert raw['backend'] == 'cuda' and raw['session_count'] == raw['turn_count'] == raw['active_sequences'] == 1
    assert raw['logical_prompt_tokens'] == raw['prefill_target_rows'] == 154 and raw['live_committed_versions'] == 0
    assert len(raw['sessions']) == 1
    for record in raw['sessions'][0]['ledger']:
        rows = record['verified_rows']
        draws = 2 * (rows - 1) + 1 if record['role'] == 1 else 3 if record['role'] in (3, 4) else 1
        assert record['sampling_draw_after'] - record['sampling_draw_before'] == draws
    b.save(folder / 'observation.json', observation)
    return dict(variant=entry['variant'], folder=str(folder), process=process, observation=observation)


def task(raw):
    # Explicit semantic comparison. Auxiliary Graph counts are real changing
    # work and stay intact in full reports/differences, not mathematical IDs.
    keys = ('source_id', 'sampling', 'sampling_temperature', 'sampling_top_k', 'sampling_top_p', 'sampling_seed',
        'generated_ids', 'generated_tokens', 'generated_decode_tokens', 'actual_target_rows', 'actual_draft_rows',
        'prefill_target_rows', 'committed_target_rows', 'consumed_drafts', 'draft_rounds', 'sampling_draw_cursor', 'visible_tokens', 'draft_frontier', 'draft_lag')
    value = {k: raw[k] for k in keys}
    def ledger(v):
        if isinstance(v, dict): return {k: ledger(z) for k, z in v.items() if k != 'auxiliary_graph_calls'}
        if isinstance(v, list): return [ledger(z) for z in v]
        return v
    value['ledger'] = ledger(facts.non_time(raw['sessions'][0]['ledger']))
    value['rounds'] = ledger(facts.non_time(raw['rounds']))
    return value


def analyze(mode):
    cfg = config(mode); out = W / mode
    rows = [parse_one(entry, cfg) for entry in cfg['commands']]
    groups = {}; complete = {}; first = {}
    for version in ('control', 'current'):
        selected = [r for r in rows if r['variant'] == version]
        first[version] = selected[0]['observation']['raw']
        first_facts = facts.non_time(first[version])
        delta = [dict(folder=row['folder'], differences=differences(first_facts, facts.non_time(row['observation']['raw']))) for row in selected[1:]]
        complete[version] = dict(processes=len(selected), stable=all(not x['differences'] for x in delta), differences=delta)
        groups[version] = ({key: b.stats([r['observation']['metrics'][key] for r in selected if r['observation']['metrics'][key] is not None]) for key in selected[0]['observation']['metrics']}
            if mode == 'timing' else read(Path(selected[0]['folder']) / 'memory-summary.json'))
    cross = differences(facts.non_time(first['control']), facts.non_time(first['current']))
    semantic = differences(task(first['control']), task(first['current']))
    b.save(out / 'runs.json', rows)
    b.save(out / 'summary.json', dict(status='COMPLETE_STABLE' if all(v['stable'] for v in complete.values()) else 'WITHIN_ARM_VARIABILITY',
        mode=mode, processes=len(rows), groups=groups, within_arm_complete_non_time=complete,
        complete_cross_arm_differences=cross, semantic_task_differences=semantic, identical_output_and_math_task=not semantic,
        historical_samples_pooled=False, no_significance_claim=True))
    assert all(v['stable'] for v in complete.values()), 'Preserve all variability; no successful native reruns'
    return rows


def execute(mode, resume=False):
    cfg = config(mode); out = W / mode
    if mode == 'memory': assert read(W / 'timing/summary.json')['status'] == 'COMPLETE_STABLE'
    if not resume:
        out.mkdir(exist_ok=False); save(out / 'inputs.json', cfg)
    else: assert read(out / 'inputs.json') == cfg
    entries = cfg['commands']; existing = [e for e in entries if Path(e['folder']).exists()]
    assert existing == entries[:len(existing)]
    for entry in existing: parse_one(entry, cfg)  # Parse successful old results; never relaunch.
    runner = p.helpers(); runner.gpu_snapshot(out, 'resume-before' if resume else 'window-before')
    try:
        for entry in entries[len(existing):]:
            exact(entry['ready']); exact(entry['image']); exact(entry['environment'])
            env = os.environ.copy(); env['PATH'] = read(entry['environment']['path'])['PATH']
            env.update(HF_HUB_OFFLINE='1', TRANSFORMERS_OFFLINE='1', HF_HUB_DISABLE_TELEMETRY='1')
            print('BEGIN', mode, entry['ordinal'], entry['variant'], flush=True)
            runner.execute(Path(entry['folder']), entry['arm'], entry['command'], env, mode == 'memory')
            parse_one(entry, cfg)
    finally: runner.gpu_snapshot(out, 'resume-after' if resume else 'window-after')
    analyze(mode)


def summary():
    timing, memory = (read(W / mode / 'summary.json') for mode in ('timing', 'memory'))
    assert timing['status'] == memory['status'] == 'COMPLETE_STABLE'
    rows = read(W / 'timing/runs.json') + read(W / 'memory/runs.json')
    assert len(rows) == 8 and len({r['process']['pid'] for r in rows}) == 8
    for version in ('control', 'current'):
        selected = [r for r in rows if r['variant'] == version]
        assert all(facts.non_time(r['observation']['raw']) == facts.non_time(selected[0]['observation']['raw']) for r in selected)
    delta = {key: 100 * (timing['groups']['current'][key]['median'] / timing['groups']['control'][key]['median'] - 1)
        if timing['groups']['current'][key]['median'] is not None and timing['groups']['control'][key]['median'] not in (None, 0) else None for key in METRICS}
    b.save(W / 'summary.json', dict(status='COMPLETE8_STABLE', processes=8, timing_processes=6, independent_memory_processes=2,
        policy=POLICY, timing=timing, memory=memory, median_delta_percent=delta,
        actual_processes=[dict(variant=r['variant'], pid=r['process']['pid'], exit=r['process']['exit'], started_unix_ns=r['process']['started_unix_ns'], finished_unix_ns=r['process']['finished_unix_ns'],
            generated_ids=r['observation']['generated_ids'], actual_work=r['observation']['work']) for r in rows],
        limits=['Only this eight-process window; control0c622 source differs by terminal, two cold abstractions and failure fix.',
            'Three timing samples and one independent memory per version, ranges retained; no statistical significance or causal isolation.',
            'Complete cross-arm non-time differences/actual work retained; output/acceptance/RNG differences prohibit an identical-task speed claim.',
            'Original PSAPI/PDH10ms requested interval and actual gaps/ready nulls retained; sampled maxima are lower bounds, not exact ready deltas.']))
    print('COMPLETE8_STABLE', delta)


if __name__ == '__main__':
    try:
        action = sys.argv[1]
        if action == 'prepare': prepare()
        elif action == 'run': execute(sys.argv[2])
        elif action == 'resume': execute(sys.argv[2], True)
        elif action == 'analyze': analyze(sys.argv[2])
        elif action == 'parse':
            cfg = config(sys.argv[2]); parse_one(cfg['commands'][int(sys.argv[3]) - 1], cfg)
        elif action == 'summary': summary()
        else: raise ValueError(action)
    except BaseException:
        (W / ('failure-' + '-'.join(sys.argv[1:4]) + '-' + str(time.time_ns()) + '.log')).write_text(traceback.format_exc(), encoding='utf-8')
        raise
