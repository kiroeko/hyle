"""Select the already-tested D1 baseline without losing the D2 experiment."""
from pathlib import Path
import hashlib
import json

B = Path(__file__).resolve().parent
ROOT = B.parents[2]
def read(p):
    return json.loads(Path(p).read_text(encoding='utf-8'))
def identity(p):
    data = Path(p).read_bytes()
    return dict(path=str(p), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())
def save(p, value):
    Path(p).write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')

assert not (B / 'decision.json').exists(), 'Preserve the disposition'
freeze = read(B / 'consumer/source-freeze.json')
source = ROOT / 'tools/qwen35_text/main.cc'
old = B / 'consumer/before/tools/qwen35_text/main.cc'
candidate = B / 'consumer/after/tools/qwen35_text/main.cc'
assert identity(source)['sha256'] == identity(candidate)['sha256'] == freeze['after']['sha256']
assert identity(old)['sha256'] == freeze['before']['sha256']
local = read(B / 'isolation/observation/summary.json')
obs = local['observation']
assert obs['completed'] and obs['both_values_and_tokens_verified']
assert obs['direct_wall_us_median'] == 39.95 and obs['cast_wall_us_median'] == 44.05
for name in ('timing', 'long-timing'):
    assert read(B / name / 'summary.json')['status'] == 'nine_fresh_processes_exit_zero'
before = identity(source)
source.write_bytes(old.read_bytes())
assert identity(source)['sha256'] == freeze['before']['sha256']
test = read(B / 'tests/source-freeze.json')['source']
assert identity(ROOT / 'tests/compute_provider_cuda/collectives_test.cc')['sha256'] == test['sha256']
decision = dict(
    decision='Do not promote this D2 consumer experiment to the selected full-model baseline. Restore exact D1 main; preserve candidate source, the useful new CUDA test and all positive/negative observations.',
    consumer_sha256=freeze['before']['sha256'], previous_consumer=before,
    selected_consumer=identity(source), candidate_snapshot=identity(candidate),
    selected_image=read(B.parent / 'decode-prepare-cost/candidate/image.json'),
    reason='The local direct-BF16 path is cheaper in this observation, but neither complete-model window establishes a throughput benefit. This is a baseline-selection decision, not proof that BF16 Top1 is slower, mathematically wrong, or useless on other hardware.',
    local_observation=dict(direct_wall_us_median=obs['direct_wall_us_median'],
        cast_wall_us_median=obs['cast_wall_us_median'],
        paired_cast_minus_direct_us_median=obs['paired_cast_minus_direct_us_median'],
        expected_token=obs['expected_token'], samples_per_arm=obs['primary_samples_per_arm'],
        independent_processes=1, correlated_samples=True,
        limitation='Both Commands routes on one hot actual logits row. Model Cast belongs to a larger captured segment. Auxiliary stream events include host-admission gaps. Do not convert these samples into model throughput or an identified whole-model regression cause.'),
    preserved_test=test,
    no_new_regression_cause_identified=True,
    mathematical_correctness_and_performance_are_separate=True,
    memory_bandwidth_hypothesis='Dominant weight streaming can dilute small suffix/host improvements; no new full-step DRAM saturation measurement was performed. Lower physical traffic/cache reuse improvements remain relevant. Do not blame this candidate on a hardware bottleneck without counters.',
    next='End this bounded D2 investigation absent a new measured premise; proceed with remaining format/function packages. Retain D1 as the throughput reference and test the current closure at final delivery.')
save(B / 'decision.json', decision)
print(json.dumps(dict(decision=decision['decision'], consumer_sha256=decision['consumer_sha256'])))
