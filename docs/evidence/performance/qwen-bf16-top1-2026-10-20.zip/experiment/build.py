"""Build only the frozen Qwen consumer and one existing CUDA Top1 test TU."""
from pathlib import Path
import argparse
import importlib.util
import sys

sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
A = S.parent
ROOT = A.parents[1]
OUT = S / "checks"
spec = importlib.util.spec_from_file_location(
    "bf16_top1_retained_helpers", A / "grouped-shared-activation/build_host.py")
h = importlib.util.module_from_spec(spec)
spec.loader.exec_module(h)
b, c = h.b, h.c
BASE = A / "decode-prepare-cost/candidate/link-plan.json"
MAIN_RECIPE = A / "decode-stable-bind/checks/main-identity.json"
TOPK = A / "cccl-single-row-topk/checks/20261019T185912-host"
TEST_RECIPE = TOPK / "direct-test-identity.json"
SOURCES = [("main", ROOT / "tools/qwen35_text/main.cc", MAIN_RECIPE),
           ("direct-test", ROOT / "tests/compute_provider_cuda/collectives_test.cc", TEST_RECIPE)]
FILTER = ":".join([
    "CudaCccl.VocabularyBfloatTopOneMatchesCastFloatAcrossBlocks",
    "CudaCccl.SingleRowTopOneDenseAndGenericLayoutsKeepStableOriginalBits",
    "CudaCccl.TopKFourTypesStableTiesNaNsAndOriginalBits",
])


def require_same(row):
    assert h.same_identity(row), row["path"]


def proposal():
    base = c.read(BASE)
    old_main = c.read(MAIN_RECIPE)["object"]
    assert sum(c.key(x["path"]) == c.key(old_main["path"])
               for x in base["inputs"]) == 1
    topk = c.read(TOPK / "topk-link-plan.json")
    gtest = [r for r in topk["inputs"]
             if Path(r["path"]).name.lower() in ("gtest_main.lib", "gtest.lib")]
    assert len(gtest) == 2
    rows = []
    for tag, source, recipe in SOURCES:
        original = c.read(recipe)
        rows.append(dict(tag=tag, source_path=str(source), recipe=b.identity(recipe),
                         command=b.host_command(original["command"], source, tag, OUT),
                         object_path=str(OUT / (tag + ".obj"))))
    return dict(base=b.identity(BASE), old_main=old_main, compile=rows,
                gtest=gtest, product_CXX=0, consumer_CXX=1, test_CXX=1,
                links=2, GPU=0, SDK=0, NVCC=0,
                qwen_inputs=len(base["inputs"]), test_inputs=len(base["inputs"]) + 2,
                test_filter_for_root=FILTER,
                scope="Only consumer/test objects change. All D1 product inputs, including both Graph core owners and native TopK, are retained unchanged.")


def build(consumer_ready, test_ready):
    assert consumer_ready and consumer_ready.is_file(), "Wait for consumer freeze"
    assert test_ready and test_ready.is_file(), "Wait for test freeze"
    assert not (OUT / "plan.json").exists(), "Preserve this attempt before retrying"
    plan = proposal()
    base = c.read(BASE)
    frozen = [b.identity(p) for _, p, _ in SOURCES]
    frozen.extend([b.identity(consumer_ready), b.identity(test_ready)])
    plan.update(frozen=frozen, consumer_ready=b.identity(consumer_ready),
                test_ready=b.identity(test_ready))
    c.save(OUT / "plan.json", plan)
    for row in [*base["inputs"], *plan["gtest"]]:
        require_same(row)
    c.save(OUT / "retained-input-recheck.json", dict(passed=True,
           base_inputs=base["inputs"], additional_test_libraries=plan["gtest"]))
    env, runtime = b.environment(plan["compile"][0]["command"], [], OUT)
    c.save(OUT / "compile-environment.json", dict(PATH=env["PATH"], runtime=runtime))
    records = {}
    for row in plan["compile"]:
        for item in frozen:
            require_same(item)
        source = b.identity(row["source_path"])
        c.execute(row["tag"] + "-compile", row["command"], env, OUT)
        depfile = OUT / (row["tag"] + "-deps.json")
        data = c.read(depfile)["Data"]
        dependencies = [b.identity(Path(p).resolve())
                        for p in dict.fromkeys([data["Source"], *data["Includes"]])]
        record = dict(source=source, object=b.identity(row["object_path"]),
                      command=row["command"], source_dependencies=b.identity(depfile),
                      dependencies=dependencies, recipe=row["recipe"],
                      consumer_ready=plan["consumer_ready"], test_ready=plan["test_ready"])
        c.save(OUT / (row["tag"] + "-identity.json"), record)
        records[row["tag"]] = record
    c.save(OUT / "compile-summary.json", dict(passed=True, product_CXX=0,
           consumer_CXX=1, test_CXX=1, SDK=0, NVCC=0, GPU=0))
    links = {}
    for arm, tag in [("qwen", "main"), ("topk", "direct-test")]:
        obj = records[tag]["object"]
        command = [obj["path"] if c.key(arg) == c.key(plan["old_main"]["path"]) else arg
                   for arg in base["command"]
                   if not arg.upper().startswith(("/OUT:", "/MAP:", "/IMPLIB:", "/PDB:"))]
        inputs = [obj if c.key(row["path"]) == c.key(plan["old_main"]["path"]) else row
                  for row in base["inputs"]]
        if arm == "topk":
            command[1:1] = [x["path"] for x in plan["gtest"]]
            inputs = [*plan["gtest"], *inputs]
        image = OUT / (arm + ".exe")
        command += ["/OUT:" + str(image), "/MAP:" + str(image.with_suffix(".map")),
                    "/IMPLIB:" + str(image.with_suffix(".lib"))]
        assert len(inputs) == (plan["qwen_inputs"] if arm == "qwen" else plan["test_inputs"])
        assert len({c.key(x["path"]) for x in inputs}) == len(inputs)
        for row in inputs:
            require_same(row)
        link = dict(command=command, inputs=inputs, base=b.identity(BASE),
                    replacement=dict(before=plan["old_main"], after=obj),
                    added_libraries=plan["gtest"] if arm == "topk" else [],
                    consumer_ready=plan["consumer_ready"], test_ready=plan["test_ready"],
                    product_objects_unchanged=True, GPU_run=False)
        c.save(OUT / (arm + "-link-plan.json"), link)
        env, runtime = b.environment(command, [x["path"] for x in inputs], OUT)
        c.save(OUT / (arm + "-runtime-environment.json"), dict(PATH=env["PATH"], runtime=runtime))
        c.execute(arm + "-link", command, env, OUT)
        links[arm] = dict(image=b.identity(image),
                          link_plan=b.identity(OUT / (arm + "-link-plan.json")))
        c.save(OUT / (arm + "-image.json"), links[arm]["image"])
    for item in frozen:
        require_same(item)
    c.save(OUT / "summary.json", dict(passed=True, consumer_CXX=1, test_CXX=1,
           product_CXX=0, links=2, GPU=0, SDK=0, NVCC=0, images=links,
           test_filter_for_root=FILTER, consumer_ready=plan["consumer_ready"],
           test_ready=plan["test_ready"], correctness_not_run=True,
           performance_not_run=True))
    print("BF16_TOP1_2CXX_2LINK_COMPLETE_NO_GPU", flush=True)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mode", choices=["plan", "build"])
    parser.add_argument("--consumer-ready", type=Path)
    parser.add_argument("--test-ready", type=Path)
    args = parser.parse_args()
    OUT.mkdir(parents=True, exist_ok=True)
    (OUT / "tmp").mkdir(exist_ok=True)
    if args.mode == "plan":
        c.save(OUT / "proposed-plan.json", proposal())
        print("BF16_TOP1_PLAN_1MAIN_1TEST_2LINK_NO_GPU", flush=True)
    else:
        build(args.consumer_ready.resolve() if args.consumer_ready else None,
              args.test_ready.resolve() if args.test_ready else None)
