"""Publish this bounded D2 experiment after root writes decision.json.

Before final disposition: python publish.py --check
After local isolation/final decision: python publish.py --local <directory-in-this-stage>
No product/doc writes occur in --check. Environment inventories, binaries,
SDK/cache content, raw profiler databases and repeated model tensors are excluded.
"""
from pathlib import Path, PurePosixPath
import argparse
import hashlib
import json
import zipfile

B = Path(__file__).resolve().parent
ROOT = B.parents[2]
DEST = ROOT / 'docs/evidence/performance'
NAME = 'qwen-bf16-top1-2026-10-20'
TEXT = {'.json', '.log', '.xml', '.py', '.cc', '.cpp', '.cu', '.cuh', '.h', '.inc', '.csv', '.diff', '.ids', '.tsv'}
FOLDERS = ('consumer', 'tests', 'checks', 'regression', 'correctness', 'timing', 'long-timing', 'profile')
ROOT_FILES = ('publish.py', 'build.py', 'run.py', 'finalize.py', 'window-analysis.json',
              'independent-timing-review.json', 'bandwidth-review.json',
              'hardware-before.csv', 'hardware-after.csv')

def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))

def identity(path):
    path = Path(path)
    data = path.read_bytes()
    return {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}

def safe_member(name):
    p = PurePosixPath(name)
    assert not p.is_absolute() and '..' not in p.parts and ':' not in name and chr(92) not in name
    assert p.as_posix() == name
    return name

def eligible(path):
    # Never read environment captures, opaque tensor payload, rebuilt programs,
    # SDK/archive payload or cleanup scripts simply because they are nearby.
    lower = path.name.lower()
    return (path.is_file() and path.suffix.lower() in TEXT
            and 'environment' not in lower and 'payload' not in lower
            and not lower.startswith('cleanup'))

def local_root(value):
    path = Path(value)
    if not path.is_absolute():
        path = B / path
    path = path.resolve()
    assert path.is_relative_to(B) and path != B
    assert path.is_dir(), 'Local isolation directory not ready'
    return path

def collect(local=None):
    files = {}
    for folder in FOLDERS:
        base = B / folder
        assert base.is_dir()
        for p in sorted(base.rglob('*')):
            if eligible(p):
                # Model trace payloads are deliberately represented by the
                # correctness summary and hashes; only four cold-route TSVs.
                relative = p.relative_to(B)
                if folder == 'correctness' and 'trace' in relative.parts and p.suffix.lower() != '.tsv':
                    continue
                name = safe_member('experiment/' + relative.as_posix())
                assert name not in files
                files[name] = p
    for filename in ROOT_FILES:
        p = B / filename
        assert eligible(p), filename
        files[safe_member('experiment/' + filename)] = p
    if (B / 'decision.json').exists():
        files['experiment/decision.json'] = B / 'decision.json'
    if local is not None:
        for p in sorted(local.rglob('*')):
            if eligible(p):
                name = safe_member('local-isolation/' + p.relative_to(local).as_posix())
                assert name not in files
                files[name] = p
    return files

def validate_inputs(final):
    freeze = read(B / 'consumer/source-freeze.json')
    for version in ('before', 'after'):
        p = B / 'consumer' / version / 'tools/qwen35_text/main.cc'
        assert identity(p)['sha256'] == freeze[version]['sha256']
    test = read(B / 'tests/source-freeze.json')
    p = B / 'tests/after/tests/compute_provider_cuda/collectives_test.cc'
    assert identity(p)['sha256'] == test['source']['sha256']
    regression = read(B / 'regression/summary.json')
    numeric = read(B / 'correctness/summary.json')
    assert regression['passed'] and regression['cases'] == 3 and regression['failed'] == 0 and regression['skipped'] == 0
    assert numeric['passed'] and numeric['equal_vectors'] == 64
    windows = {name: read(B / name / 'summary.json') for name in ('timing', 'long-timing')}
    assert all(w['status'] == 'nine_fresh_processes_exit_zero' and w['current_matches_baseline_ids'] for w in windows.values())
    for w in windows.values():
        assert all(len(w['groups'][arm]['full_decode_tokens_per_second']['samples']) == 3 for arm in ('baseline', 'current', 'llama'))
    if final:
        decision = read(B / 'decision.json')
        assert isinstance(decision.get('decision'), str) and decision['decision'], 'Root final decision missing'
    else:
        decision = None
    return freeze, test, regression, numeric, windows, decision

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--check', action='store_true')
    parser.add_argument('--local', help='Final local-isolation directory, relative to this stage')
    args = parser.parse_args()
    local = local_root(args.local) if args.local else None
    freeze, test, regression, numeric, windows, decision = validate_inputs(not args.check)
    files = collect(local)
    if args.check:
        print(json.dumps({'ready_for_final_disposition': True, 'writes': False,
                          'existing_selected_files': len(files),
                          'existing_selected_bytes': sum(p.stat().st_size for p in files.values()),
                          'decision_present': (B / 'decision.json').exists(),
                          'local_present': local is not None,
                          'pending': 'Root decision.json and final local-isolation path; --check does not publish.'}))
        return
    assert local is not None, 'Await actual local-isolation source/commands/results'
    target = DEST / (NAME + '.json')
    archive = DEST / (NAME + '.zip')
    assert not target.exists() and not archive.exists(), 'Do not overwrite published evidence'
    current = identity(ROOT / 'tools/qwen35_text/main.cc')
    assert current['sha256'] in (freeze['before']['sha256'], freeze['after']['sha256'])
    current['matches'] = 'before' if current['sha256'] == freeze['before']['sha256'] else 'candidate'
    if 'consumer_sha256' in decision:
        assert current['sha256'] == decision['consumer_sha256']
    members = []
    with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for name, path in files.items():
            data = path.read_bytes()
            z.writestr(name, data)
            members.append({'member': name, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
        z.writestr('manifest.json', json.dumps(members, indent=2) + '\n')
    with zipfile.ZipFile(archive) as z:
        names = z.namelist()
        assert len(names) == len(set(names)) == len(members) + 1
        assert all(safe_member(name) for name in names)
        assert z.testzip() is None
        assert json.loads(z.read('manifest.json')) == members
        for row in members:
            data = z.read(row['member'])
            assert len(data) == row['bytes'] and hashlib.sha256(data).hexdigest() == row['sha256']
    value = {
        'date': '2026-10-20',
        'scope': 'Bounded Windows RTX4070 BF16 Qwen3.5-2B text consumer experiment; same retained D1 product closure, only consumer main replaced. No provider/native/SDK rebuild in the whole-consumer candidate.',
        'decision': decision,
        'current_consumer': current,
        'candidate': 'One graph retains BF16 head logits and direct BF16 Top1; trace-only U16bits<<16 widening preserves original logits.f32 file format after inference timing endpoint.',
        'source_freeze': freeze,
        'validation': {
            'CUDA_tests': {'cases': 3, 'failed': 0, 'skipped': 0, 'names': regression['names']},
            'original_hidden_logits_vectors': {'byte_equal': 64, 'stored_as': 'Hashes and metrics in correctness summary; repeated tensor payloads excluded'},
            'cold_plan_and_source_review': read(B / 'consumer/source-review.json'),
            'structural_profile': read(B / 'profile/summary.json'),
            'consumer_build': read(B / 'checks/summary.json'),
            'local_isolation': {'directory': local.relative_to(B).as_posix(), 'evidence_prefix': 'local-isolation/', 'conclusion': 'Use root decision and actual retained local outputs; this publication does not infer a result from fewer casts.'}
        },
        'windows': {name: {'groups': w['groups'], 'current_over_baseline': w['current_over_baseline'],
                           'current_over_llama': w['current_over_llama'], 'processes_per_arm': 3,
                           'current_matches_baseline_ids': w['current_matches_baseline_ids']} for name, w in windows.items()},
        'window_analysis': read(B / 'window-analysis.json'),
        'independent_timing_review': read(B / 'independent-timing-review.json'),
        'local_observation': read(local / 'observation/summary.json'),
        'bandwidth_review': read(B / 'bandwidth-review.json'),
        'limits': [
            'Short128+31 and long128+127 windows each have three fresh processes per arm; no statistical significance or precise regression mechanism is established. Do not pool the windows.',
            'Candidate full-decode medians were approximately0.945percent and0.815percent below baseline in the two windows; warm deltas approximately0.704percent and0.826percent. Preserve all raw samples and observed drift.',
            '596to595 physical kernels and one fewer Cast are structural observations, not speed evidence. Software-traced profiler durations are not uninstrumented wall-time budgets.',
            'Both real host-token endpoints are retained. Hyle BF16 intermediates and peer F32 intermediates differ; peer also returns sampled full logits. Same weights do not mean identical mathematical work.',
            'Three CUDA tests and64 identical vectors do not independently accept model quality or complete model/quantization/platform support.',
            'Environment captures, exe/obj/lib/map, SDK caches, raw nsys/sqlite and repeated hidden/logit tensor payloads are excluded. Their available identities and structural/validation summaries are retained.',
            'No new memory peak, power/energy, Linux or Apple execution is claimed.'
        ],
        'archive': {'path': archive.name, **identity(archive), 'members': len(members) + 1},
        'payloads': members,
        'archive_verified': {'CRC': True, 'all_payload_SHA256': True, 'member_paths_and_duplicates': True}
    }
    target.write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')
    result = read(target)
    assert result['payloads'] == members and result['archive']['sha256'] == identity(archive)['sha256']
    print(json.dumps({'evidence': {'path': str(target), **identity(target)},
                      'archive': {'path': str(archive), **identity(archive)},
                      'members': len(members) + 1}, ensure_ascii=False))

if __name__ == '__main__':
    main()
