"""Bounded BF16-logits consumer verification with retained runtime/benchmarks."""
from pathlib import Path
import importlib.util
import json
import re
import statistics
import sys
import time
import xml.etree.ElementTree as ET
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent
A=S.parent
def load(name,p):
    spec=importlib.util.spec_from_file_location(name,p);v=importlib.util.module_from_spec(spec);spec.loader.exec_module(v);return v
d=load('bf16_top1_old_experiment',A/'decode-prepare-cost/experiment.py')
b,c,h=d.b,d.c,d.h
LINK=c.read(S/'checks/qwen-link-plan.json')
IMAGE=c.read(S/'checks/qwen-image.json')
BASELINE=c.read(A/'decode-prepare-cost/candidate/image.json')

def tests():
    out=S/'regression';out.mkdir(exist_ok=False)
    image=c.read(S/'checks/topk-image.json');plan=c.read(S/'checks/topk-link-plan.json')
    env,runtime=b.environment(plan['command'],[x['path'] for x in plan['inputs']],out)
    names=['CudaCccl.VocabularyBfloatTopOneMatchesCastFloatAcrossBlocks',
        'CudaCccl.SingleRowTopOneDenseAndGenericLayoutsKeepStableOriginalBits',
        'CudaCccl.TopKFourTypesStableTiesNaNsAndOriginalBits']
    c.execute('tests',[image['path'],'--gtest_filter='+':'.join(names),'--gtest_output=xml:'+str(out/'results.xml')],env,out)
    cases=ET.parse(out/'results.xml').findall('.//testcase')
    actual=[x.get('classname')+'.'+x.get('name') for x in cases]
    assert len(cases)==3 and set(actual)==set(names)
    assert all(x.find('failure') is None and x.find('skipped') is None for x in cases)
    c.save(out/'summary.json',dict(passed=True,cases=3,failed=0,skipped=0,names=actual,image=image,runtime=runtime))

def correctness():
    out=S/'correctness';out.mkdir(exist_ok=False)
    env,runtime=h.environment(out,LINK)
    n=h.load('bf16_top1_vectors',A/'cuda-bf16-dual-projection/compare_numerics.py')
    ref=A/'batch-graph-capture/correctness-final'
    vectors={p.relative_to(ref/'trace'):n.identity(p) for p in sorted((ref/'trace').rglob('*')) if p.suffix in ('.bf16','.f32')}
    assert len(vectors)==64
    command=c.read(ref/'qwen.command.json')['command'].copy();command[0]=IMAGE['path']
    command[command.index('--trace')+1]=str(out/'trace')
    c.execute('qwen',command,env,out)
    obs=n.analyze_arm('current',IMAGE,out,vectors,n.final_json(ref/'qwen.stdout.log'))
    assert obs['equal_vectors']==64 and obs['all_outputs_finite'] and obs['same_greedy_ids_as_reference'] and obs['same_fixed_decode_inputs']
    assert [[x['recorded'],x['reused']] for x in obs['capture_counts']]==[[1,0]]*3+[[0,1]]*29
    c.save(out/'summary.json',dict(passed=True,equal_vectors=64,observation=obs,image=IMAGE,independent_quality_acceptance=False,runtime=runtime))
    print('BF16_TOP1_64_VECTORS_EQUAL',flush=True)

def timing(long=False):
    assert c.read(S/'regression/summary.json')['passed'] and c.read(S/'correctness/summary.json')['passed']
    out=S/('long-timing' if long else 'timing');out.mkdir(exist_ok=False)
    env,runtime=h.environment(out,LINK)
    hc,pc=d.commands(long)
    images=dict(baseline=BASELINE,current=IMAGE,llama=c.read(A/'decode-prepare-cost/long-peer/image.json') if long else h.PEER['images']['llama'])
    assert all(h.h.same_identity(x) for x in images.values())
    order=['baseline','current','llama','llama','baseline','current','current','llama','baseline']
    c.save(out/'inputs.json',dict(images=images,order=order,process_count=9,fresh_processes_per_arm=3,prompt_tokens=128,
        decode_tokens=127 if long else 31,context_capacity=256,repeated_original31_tape_for_long=long,
        runtime=runtime,added_D1_instrumentation=False,profiler=False,external_sampling=False,
        retained_peer_normal_snapshots=True,compile_during_window=False,
        metric='Complete host-token step including input preparation, capture when first needed, submit/wait/read',
        precision_limit='Same BF16 weights; Hyle mainly BF16 activation/output vs many peer F32 intermediates and automatic sampled-logits readback. Not identical-math or quality acceptance.',
        scope='Retained D1 BF16 closure, only main object replaced. Not all later format-capability owners rebuilt.'))
    runs=[];start=time.time()
    for i,arm in enumerate(order,1):
        tag=f'{i:02}-{arm}';command=(pc if arm=='llama' else hc).copy();command[0]=images[arm]['path']
        if arm=='llama':command[-1]=str(out/(tag+'-peer-result.json'))
        process=c.execute(tag,command,env,out)
        obs=d.observation(out,tag,arm,long)
        runs.append(dict(tag=tag,arm=arm,process=process,**obs));c.save(out/'runs.json',runs)
    groups={arm:{k:dict(samples=[x['metrics'][k] for x in runs if x['arm']==arm],median=statistics.median(x['metrics'][k] for x in runs if x['arm']==arm))
                 for k in runs[0]['metrics']} for arm in images}
    ids=next(x['generated_ids'] for x in runs if x['arm']=='baseline')
    assert all(x['generated_ids']==ids for x in runs if x['arm']!='llama')
    c.save(out/'summary.json',dict(status='nine_fresh_processes_exit_zero',started=start,finished=time.time(),groups=groups,
        current_over_baseline={k:groups['current'][k]['median']/groups['baseline'][k]['median'] for k in groups['current']},
        current_over_llama={k:groups['current'][k]['median']/groups['llama'][k]['median'] for k in groups['current']},
        peer_prediction_differences={x['tag']:[i for i,(a,e) in enumerate(zip(x['generated_ids'],ids)) if a!=e] for x in runs if x['arm']=='llama'},
        current_matches_baseline_ids=True,images=images,long=long,statistical_significance=False,independent_quality_acceptance=False))
    print('BF16_TOP1_WINDOW_COMPLETE',out.name,groups,flush=True)

def profile():
    assert c.read(S/'correctness/summary.json')['passed']
    p=load('bf16_top1_profile_helpers',A/'cold-prepare-review/profile.py')
    out=S/'profile';out.mkdir(exist_ok=False);(out/'tmp').mkdir()
    tape=list(map(int,Path(d.commands()[0][d.commands()[0].index('--decode-ids')+1]).read_text().split()))[:7]
    (out/'decode.ids').write_text('\n'.join(map(str,tape))+'\n')
    command=d.commands()[0].copy();command[0]=IMAGE['path'];command[command.index('--decode-ids')+1]=str(out/'decode.ids');command[command.index('--steps')+1]='8'
    old=c.read(A/'cold-prepare-review/profile/plan.json');nsys=old['commands']['profile'][0];stem=out/'capture'
    commands=dict(profile=[nsys,'profile','--trace=cuda','--sample=none','--cpuctxsw=none','--cuda-trace-all-apis=true',
        '--cuda-graph-trace=node:host-only','--discard-environment=true','--output='+str(stem),*command],
        export=[nsys,'export','--type=sqlite','--output='+str(stem)+'.sqlite',str(stem)+'.nsys-rep'])
    env,runtime=h.environment(out,LINK)
    c.save(out/'plan.json',dict(commands=commands,image=IMAGE,consumer_command=command,runtime=runtime,throughput_claim=False))
    for tag,argv in commands.items():c.execute(tag,argv,env,out)
    data=p.trace(stem.with_suffix('.sqlite'))
    tokens=sorted((x for x in data['copies'] if x['copyKind']==2 and x['bytes']==4),key=lambda x:x['end']);assert len(tokens)==8
    phases=[]
    for i in range(1,8):
        lo,hi=tokens[i-1]['end'],tokens[i]['end']
        kernels=[x for x in data['kernels'] if lo<x['start'] and x['end']<=hi]
        runtime_rows=[x for x in data['runtime'] if lo<x['start'] and x['end']<=hi]
        phases.append(dict(index=i,**p.summarize_kernels(kernels),graph_launches=sum(p.api_name(x['name'])=='cudaGraphLaunch' for x in runtime_rows),graph_kernel_nodes=sum(bool(x.get('graphNodeId')) for x in kernels)))
    for kind,value in data['streams'].items():(out/('target.'+kind+'.log')).write_text(value,encoding='utf-8')
    c.save(out/'summary.json',dict(status='structural_profile_only',phases=phases,diagnostics=data['diagnostics'],throughput_claim=False))
    print('BF16_TOP1_STRUCTURE',phases[-1],flush=True)

if __name__=='__main__':
    {'tests':tests,'correctness':correctness,'timing':timing,'long-timing':lambda:timing(True),'profile':profile}[sys.argv[1]]()
