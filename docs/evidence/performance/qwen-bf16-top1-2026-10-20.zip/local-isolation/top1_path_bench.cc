// One payload, one process, two public Commands Graphs; no provider changes.
#include "hyle/compute/backends/cuda.h"
#include "hyle/compute/providers/cuda.h"
#include "hyle/graph/cuda.h"

#include <algorithm>
#include <array>
#include <bit>
#include <chrono>
#include <cmath>
#include <cstdint>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <span>
#include <stdexcept>
#include <string>
#include <utility>
#include <vector>

namespace c = hyle::compute;
namespace g = hyle::graph;
namespace m = hyle::mem;
using Clock = std::chrono::steady_clock;
constexpr std::int64_t width = 248320;

template<class T> T take(hyle::Result<T> value) {
  if (!value) throw std::runtime_error(std::string(value.error().message()));
  return std::move(*value);
}
void check(hyle::Status status) {
  if (!status.ok()) throw std::runtime_error(std::string(status.message()));
}
void cuda_check(cudaError_t status) {
  if (status != cudaSuccess) throw std::runtime_error(cudaGetErrorString(status));
}
struct Drain final {
  c::Queue &queue;
  ~Drain() { (void)queue.drain(); }
};
struct Events final {
  cudaEvent_t first = nullptr, last = nullptr;
  ~Events() {
    if (last) (void)cudaEventDestroy(last);
    if (first) (void)cudaEventDestroy(first);
  }
};
struct Arm final {
  g::Graph logical;
  g::CompiledGraph compiled;
  m::Buffer values, indices;
  g::Invocation slot;
  bool widened = false;
};

c::TensorDesc description(c::DataType type, std::int64_t columns) {
  return take(c::TensorDesc::dense(type, std::array<std::int64_t, 2>{1, columns}));
}
Arm prepare(bool widened, const c::Context &context, m::MemoryResourceRef memory,
            c::Queue &queue, const m::Buffer &input) {
  Arm arm;
  arm.widened = widened;
  const auto input_desc = description(c::DataType::kBFloat16, width);
  const auto values_desc = description(
      widened ? c::DataType::kFloat32 : c::DataType::kBFloat16, 1);
  const auto index_desc = description(c::DataType::kInt32, 1);
  auto builder = take(g::GraphBuilder::create());
  const auto x = take(builder.input(input_desc));
  auto scores = x;
  if (widened)
    scores = take(builder.add(c::Cast{c::DataType::kFloat32}, x));
  const auto top = take(builder.add_node(c::Operation(c::TopK{.count = 1}),
                                          std::array{scores}));
  const auto value = take(builder.result(top, 0));
  const auto index = take(builder.result(top, 1));
  check(builder.publish(value));
  check(builder.publish(index));
  arm.logical = take(std::move(builder).finish());
  arm.compiled = take(g::cuda::compile(arm.logical, context, memory,
      {.provider_replay = g::ProviderReplayPolicy::kAllowAny}));
  std::size_t cccl = 0;
  for (std::size_t step = 0; step < arm.compiled.report.step_count(); ++step)
    cccl += take(arm.compiled.report.step(step)).provider.id ==
             c::cuda_native::kCcclProviderId ? 1u : 0u;
  if (cccl != 1) throw std::runtime_error("Expected one original CCCL Top1");
  arm.values = take(m::Buffer::create(memory, take(values_desc.required_bytes()), 256));
  arm.indices = take(m::Buffer::create(memory, take(index_desc.required_bytes()), 256));
  arm.slot = take(arm.compiled.executable.create_invocation());
  check(arm.slot.bind(x, take(c::ConstTensorView::create(input_desc, input.view()))));
  check(arm.slot.bind(value, take(c::TensorView::create(values_desc, arm.values.view()))));
  check(arm.slot.bind(index, take(c::TensorView::create(index_desc, arm.indices.view()))));
  check(g::cuda::prepare_replay(arm.slot, queue,
      {.mode = g::ReplayMode::kCommands, .host_wait = g::HostWaitPolicy::kAllow}));
  if (arm.slot.replay_route() != g::ReplayRoute::kCommands)
    throw std::runtime_error("Both arms must use original Commands route");
  return arm;
}

std::int32_t host_token(const Arm &arm) {
  std::int32_t token = -1;
  check(arm.indices.view().read(std::as_writable_bytes(std::span(&token, 1))));
  return token;
}
void submit_wait(Arm &arm, c::Queue &queue) {
  auto done = take(arm.slot.submit(queue));
  check(done.wait());
  // Completion destruction is inside the original host-token timing boundary.
}
void verify_value(const Arm &arm, std::int32_t expected, std::uint32_t bits) {
  if (host_token(arm) != expected) throw std::runtime_error("Token differs");
  std::uint32_t actual = 0;
  if (arm.widened) {
    check(arm.values.view().read(std::as_writable_bytes(std::span(&actual, 1))));
  } else {
    std::uint16_t narrow = 0;
    check(arm.values.view().read(std::as_writable_bytes(std::span(&narrow, 1))));
    actual = static_cast<std::uint32_t>(narrow) << 16;
  }
  if (actual != bits) throw std::runtime_error("Selected value bits differ");
}
double median(std::vector<double> values) {
  std::sort(values.begin(), values.end());
  return (values[(values.size() - 1) / 2] + values[values.size() / 2]) / 2.0;
}
void print_values(const std::vector<double> &values) {
  std::cout << '[';
  for (std::size_t i = 0; i < values.size(); ++i) {
    if (i) std::cout << ',';
    std::cout << values[i];
  }
  std::cout << ']';
}

int main(int argc, char **argv) try {
  static_assert(std::endian::native == std::endian::little);
  if (argc != 2) throw std::runtime_error("Requires the retained decode7 logits.f32 path");
  std::ifstream file(argv[1], std::ios::binary | std::ios::ate);
  if (!file || file.tellg() != static_cast<std::streamoff>(width * 4))
    throw std::runtime_error("Requires exactly 248320 original F32 elements");
  file.seekg(0);
  std::vector<std::uint32_t> original(static_cast<std::size_t>(width));
  file.read(reinterpret_cast<char *>(original.data()), width * 4);
  if (!file) throw std::runtime_error("Could not read original logits");
  std::vector<std::uint16_t> narrow(original.size());
  std::uint64_t input_fnv = 14695981039346656037ULL;
  std::int32_t expected = 0;
  for (std::size_t i = 0; i < original.size(); ++i) {
    const auto bits = original[i];
    if ((bits & 0xffffu) != 0 || !std::isfinite(std::bit_cast<float>(bits)))
      throw std::runtime_error("Original finite logits must be exact BF16 widening");
    narrow[i] = static_cast<std::uint16_t>(bits >> 16);
    for (unsigned byte = 0; byte < 4; ++byte) {
      input_fnv ^= (bits >> (byte * 8)) & 255u;
      input_fnv *= 1099511628211ULL;
    }
    if (std::bit_cast<float>(bits) > std::bit_cast<float>(original[expected]))
      expected = static_cast<std::int32_t>(i);
  }
  auto context = take(g::cuda::create_context());
  auto memory = take(c::cuda::MemoryResource::create(context, c::cuda::MemoryKind::kDevice));
  auto queue = take(context.create_queue());
  check(queue.reserve_completions(2));
  auto input = take(m::Buffer::create(memory.ref(), narrow.size() * sizeof(narrow[0]), 256));
  check(input.view().write(std::as_bytes(std::span(narrow))));
  std::array arms{prepare(false, context, memory.ref(), queue, input),
                  prepare(true, context, memory.ref(), queue, input)};
  Drain drain{queue};
  constexpr std::size_t warmup_per_arm = 32, cycles = 64;
  for (std::size_t i = 0; i < warmup_per_arm; ++i)
    for (unsigned offset = 0; offset < 2; ++offset) {
      auto &arm = arms[(i + offset) % 2];
      submit_wait(arm, queue);
      if (host_token(arm) != expected) throw std::runtime_error("Warm token differs");
    }
  for (const auto &arm : arms) verify_value(arm, expected, original[expected]);

  std::array<std::vector<double>, 2> wall;
  std::vector<double> paired_cast_minus_direct;
  paired_cast_minus_direct.reserve(cycles);
  for (std::size_t cycle = 0; cycle < cycles; ++cycle) {
    const std::array<unsigned, 4> order = cycle % 2 == 0
        ? std::array<unsigned, 4>{0, 1, 1, 0} : std::array<unsigned, 4>{1, 0, 0, 1};
    std::array<double, 2> sums{};
    for (const auto index : order) {
      auto &arm = arms[index];
      const auto before = Clock::now();
      submit_wait(arm, queue);
      const auto token = host_token(arm);
      const auto after = Clock::now();
      if (token != expected) throw std::runtime_error("Measured token differs");
      const auto us = std::chrono::duration<double, std::micro>(after - before).count();
      wall[index].push_back(us);
      sums[index] += us;
    }
    paired_cast_minus_direct.push_back((sums[1] - sums[0]) / 2.0);
  }

  // Separate bounded event observation; never pooled into primary wall samples.
  Events events;
  cuda_check(cudaEventCreate(&events.first));
  cuda_check(cudaEventCreate(&events.last));
  const auto stream = take(c::cuda::stream(queue));
  std::array<std::vector<double>, 2> event_us;
  constexpr std::size_t event_cycles = 8;
  for (std::size_t cycle = 0; cycle < event_cycles; ++cycle) {
    const auto order = cycle % 2 == 0
        ? std::array<unsigned, 4>{0, 1, 1, 0} : std::array<unsigned, 4>{1, 0, 0, 1};
    for (const auto index : order) {
      auto &arm = arms[index];
      cuda_check(cudaEventRecord(events.first, stream));
      {
        auto done = take(arm.slot.submit(queue));
        cuda_check(cudaEventRecord(events.last, stream));
        check(done.wait());
      }
      cuda_check(cudaEventSynchronize(events.last));
      if (host_token(arm) != expected) throw std::runtime_error("Auxiliary token differs");
      float milliseconds = 0;
      cuda_check(cudaEventElapsedTime(&milliseconds, events.first, events.last));
      event_us[index].push_back(static_cast<double>(milliseconds) * 1000.0);
    }
  }
  for (const auto &arm : arms) verify_value(arm, expected, original[expected]);
  std::cout << std::setprecision(12)
      << "{\"completed\":true,\"route\":\"commands\",\"input_dtype\":\"BF16\","
      << "\"width\":" << width << ",\"input_fnv1a64\":" << input_fnv
      << ",\"expected_token\":" << expected
      << ",\"expected_value_f32_bits\":" << original[expected]
      << ",\"cold_prepares\":2,\"warmup_per_arm\":" << warmup_per_arm
      << ",\"primary_cycles\":" << cycles
      << ",\"primary_samples_per_arm\":" << wall[0].size()
      << ",\"direct_wall_us_median\":" << median(wall[0])
      << ",\"cast_wall_us_median\":" << median(wall[1])
      << ",\"paired_cast_minus_direct_us_median\":" << median(paired_cast_minus_direct)
      << ",\"direct_wall_us\":";
  print_values(wall[0]); std::cout << ",\"cast_wall_us\":"; print_values(wall[1]);
  std::cout << ",\"paired_cast_minus_direct_us\":"; print_values(paired_cast_minus_direct);
  std::cout << ",\"aux_event_cycles\":" << event_cycles
      << ",\"direct_stream_us_median\":" << median(event_us[0])
      << ",\"cast_stream_us_median\":" << median(event_us[1])
      << ",\"direct_stream_us\":";
  print_values(event_us[0]); std::cout << ",\"cast_stream_us\":"; print_values(event_us[1]);
  std::cout << ",\"both_values_and_tokens_verified\":true,\"profiler\":false,"
      << "\"wall_boundary\":\"public-submit+original-completion-wait-and-destruction+4B-host-token-read\","
      << "\"limit\":\"One hot logits row, same Commands route, correlated within-process ABBA/BAAB samples; stream event intervals include host admission gaps and are not kernel-only or full-model throughput\"}\n";
  return 0;
} catch (const std::exception &error) {
  std::cerr << error.what() << '\n';
  return 1;
}
