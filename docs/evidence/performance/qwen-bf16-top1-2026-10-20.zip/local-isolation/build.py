"""One host bench TU plus one link; GPU execution belongs to root."""
from pathlib import Path
import hashlib
import importlib.util
import math
import struct
import sys
sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
A = S.parents[1]
ROOT = A.parents[1]
spec = importlib.util.spec_from_file_location(
    "top1_isolation_helpers", A / "grouped-shared-activation/build_host.py")
h = importlib.util.module_from_spec(spec)
spec.loader.exec_module(h)
b, c = h.b, h.c
BASE = S.parent / "checks/qwen-link-plan.json"
RECIPE = S.parent / "checks/main-identity.json"
SOURCE = S / "top1_path_bench.cc"
OUT = S / "checks"
INPUT = A / "batch-graph-capture/correctness-final/trace/decode7/logits.f32"
D1_PROOF = A / "decode-prepare-cost/correctness/summary.json"
EXPECTED_SHA = "8c90db2481c2110453c52633a8b3153fe37391085de09fb4e5a0943adfe396c1"


def find_vector(value):
    if isinstance(value, dict):
        if value.get("path") == "decode7/logits.f32":
            return value
        for child in value.values():
            if (found := find_vector(child)) is not None:
                return found
    elif isinstance(value, list):
        for child in value:
            if (found := find_vector(child)) is not None:
                return found
    return None


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    (OUT / "tmp").mkdir(exist_ok=True)
    assert not (OUT / "plan.json").exists(), "Preserve this attempt"
    base, recipe = c.read(BASE), c.read(RECIPE)
    for row in base["inputs"]:
        assert h.same_identity(row), row["path"]
    vector = find_vector(c.read(D1_PROOF))
    assert vector["byte_equal"] and vector["actual"]["sha256"] == vector["reference"]["sha256"] == EXPECTED_SHA
    raw = INPUT.read_bytes()
    assert len(raw) == 248320 * 4 and hashlib.sha256(raw).hexdigest() == EXPECTED_SHA
    bits = struct.unpack("<248320I", raw)
    assert all(x & 65535 == 0 for x in bits)
    assert all(math.isfinite(struct.unpack("<f", struct.pack("<I", x))[0]) for x in bits)
    source = b.identity(SOURCE)
    command = b.host_command(recipe["command"], SOURCE, "bench", OUT)
    plan = dict(command=command, source=source, recipe=b.identity(RECIPE),
                base=b.identity(BASE), input=b.identity(INPUT),
                d1_byte_equal_proof=b.identity(D1_PROOF), d1_vector=vector,
                low16_all_zero=True, all_finite=True,
                consumer_CXX=1, product_CXX=0, SDK=0, NVCC=0, links=1, GPU=0,
                design=dict(shape=[1,248320], input="One shared original BF16 row",
                    cold_prepare="Exactly one per arm, both original public Commands route",
                    primary="32 warmups per arm,64 alternating ABBA/BAAB cycles,128 samples per arm; original Completion wait/destruction and4B host-token read inside wall",
                    auxiliary="Separate8 ABBA/BAAB event cycles,16 samples per arm; not pooled with primary wall",
                    limit="Hot fixed row/same-process correlated samples; Commands route excludes model capture composition. No full-model throughput/quality claim. No cache/shape matrix or rerun window"))
    c.save(OUT / "plan.json", plan)
    env, runtime = b.environment(command, [], OUT)
    c.execute("compile", command, env, OUT)
    depfile = OUT / "bench-deps.json"
    dep = c.read(depfile)["Data"]
    receipt = dict(source=source, object=b.identity(OUT / "bench.obj"), command=command,
                   source_dependencies=b.identity(depfile),
                   dependencies=[b.identity(Path(p).resolve())
                                 for p in dict.fromkeys([dep["Source"], *dep["Includes"]])])
    c.save(OUT / "bench-identity.json", receipt)
    assert h.same_identity(source)
    old_main = recipe["object"]
    assert sum(c.key(x["path"]) == c.key(old_main["path"]) for x in base["inputs"]) == 1
    link_command = [receipt["object"]["path"] if c.key(arg) == c.key(old_main["path"]) else arg
                    for arg in base["command"]
                    if not arg.upper().startswith(("/OUT:", "/MAP:", "/IMPLIB:", "/PDB:"))]
    image = OUT / "bench.exe"
    link_command += ["/OUT:" + str(image), "/MAP:" + str(image.with_suffix(".map")),
                     "/IMPLIB:" + str(image.with_suffix(".lib"))]
    inputs = [receipt["object"] if c.key(row["path"]) == c.key(old_main["path"]) else row
              for row in base["inputs"]]
    for row in inputs:
        assert h.same_identity(row), row["path"]
    c.save(OUT / "link-plan.json", dict(command=link_command, inputs=inputs,
           base=b.identity(BASE), replacement=dict(before=old_main, after=receipt["object"]),
           product_objects_unchanged=True))
    env, runtime = b.environment(link_command, [x["path"] for x in inputs], OUT)
    c.save(OUT / "runtime-environment.json", dict(PATH=env["PATH"], runtime=runtime))
    c.execute("link", link_command, env, OUT)
    c.save(OUT / "image.json", b.identity(image))
    c.save(OUT / "run-plan.json", dict(image=b.identity(image),
           command=[str(image), str(INPUT)], input=b.identity(INPUT),
           link_plan=b.identity(OUT / "link-plan.json"),
           observation_directory=str(S / "observation"), GPU_run=False,
           process_limit=1, timing_window_limit=1, plan=b.identity(OUT / "plan.json")))
    assert h.same_identity(source)
    c.save(OUT / "summary.json", dict(built=True, bench_CXX=1, links=1,
           product_CXX=0, SDK=0, NVCC=0, GPU=0, image=b.identity(image),
           correctness_not_run=True, performance_not_run=True))
    print("TOP1_ISOLATION_BUILT_1CXX_1LINK_NO_GPU", flush=True)


if __name__ == "__main__":
    main()
