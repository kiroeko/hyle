"""Exactly one fixed local observation; no model window or parameter search."""
from pathlib import Path
import importlib.util
import json
import statistics
import sys

sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('top1_local_build', S / 'build.py')
h = importlib.util.module_from_spec(spec)
spec.loader.exec_module(h)
b, c = h.b, h.c
plan = c.read(S / 'checks/run-plan.json')
out = Path(plan['observation_directory'])
out.mkdir(exist_ok=False)
for row in [plan['image'], plan['input'], plan['link_plan'], plan['plan']]:
    assert h.h.same_identity(row), row['path']
link = c.read(S / 'checks/link-plan.json')
env, runtime = b.environment(link['command'], [x['path'] for x in link['inputs']], out)
c.save(out / 'inputs.json', dict(run_plan=plan, runtime=runtime,
    processes=1, windows=1, no_parameter_search=True, full_model_claim=False))
process = c.execute('bench', plan['command'], env, out)
result = json.loads((out / 'bench.stdout.log').read_text().strip().splitlines()[-1])
assert result['completed'] and result['both_values_and_tokens_verified']
assert result['width'] == 248320 and result['route'] == 'commands'
assert result['cold_prepares'] == 2 and result['primary_samples_per_arm'] == 128
assert all(x > 0 for x in result['direct_wall_us'] + result['cast_wall_us'])
assert statistics.median(result['direct_wall_us']) == result['direct_wall_us_median']
assert statistics.median(result['cast_wall_us']) == result['cast_wall_us_median']
c.save(out / 'summary.json', dict(process=process, observation=result,
    independent_processes=1, correlated_samples=True, full_model_throughput_claim=False,
    captured_model_suffix_equivalence=False,
    limitation='Both Commands routes; the original Cast belongs to a larger captured model segment. Hot row observation cannot assign full-model delta.'))
print(json.dumps({key: result[key] for key in (
    'direct_wall_us_median', 'cast_wall_us_median',
    'paired_cast_minus_direct_us_median', 'direct_stream_us_median',
    'cast_stream_us_median', 'both_values_and_tokens_verified')}), flush=True)
