"""Private Model hook using existing PreparationObservation; never runs a model."""
from pathlib import Path
import difflib, hashlib, json
W=Path(__file__).resolve().parent; R=W.parents[1]
def pin(p):
 b=p.read_bytes(); return dict(path=str(p.resolve()),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def save(p,d):
 p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(d,indent=2)+'\n',encoding='utf8')
p=R/'engine/models/qwen35/main.cc'; raw=p.read_bytes()
assert hashlib.sha256(raw).hexdigest()=='b346d408cdf8226b2df464f757483cc3aecd5b7c2f2d7f290751c7115d3cc44c'
before=W/'before/engine/models/qwen35/main.cc';before.parent.mkdir(parents=True,exist_ok=True);before.write_bytes(raw)
s=raw.decode(); nl='\r\n' if b'\r\n' in raw else '\n'; s=s.replace('\r\n','\n')
anchor='  std::size_t draft_program_graph_calls = 0, prefix_decision_graph_calls = 0;\n'
extra=r'''  // Private bounded observation only: original stage clocks and report path.
  struct BatchClockEntry {
    inference::PreparationObservation preparation;
    std::size_t rows = 0, requests = 0, visible_before = 0;
    int role = 0;
    bool generation = false, finished = false;
  };
  std::array<BatchClockEntry, 68> batch_clock{};
  std::size_t batch_clock_seen = 0, batch_clock_finished = 0, batch_clock_overflow = 0;
  BatchClockEntry *begin_batch_clock(std::size_t rows, std::size_t requests, std::size_t visible,
      GraphRole role, bool generation) noexcept {
    const auto index = batch_clock_seen++;
    if (index >= batch_clock.size()) { ++batch_clock_overflow; return nullptr; }
    auto &entry = batch_clock[index];
    entry.rows = rows; entry.requests = requests; entry.visible_before = visible;
    entry.role = static_cast<int>(role); entry.generation = generation;
    return &entry;
  }
  void dump_batch_clock() const {
    // One final serialization, after the natural journey endpoints. Existing
    // report vectors resize after each host_endpoint; neither cost is TPS evidence.
    std::ostringstream out; out << std::setprecision(17);
    out << "MODEL_BATCH_CLOCK {\"seen\":" << batch_clock_seen
        << ",\"finished\":" << batch_clock_finished << ",\"capacity\":" << batch_clock.size()
        << ",\"overflow\":" << batch_clock_overflow << ",\"expected_reports_per_call\":6,\"entries\":[";
    const auto count = (std::min)(batch_clock_seen, batch_clock.size());
    for (std::size_t index = 0; index < count; ++index) {
      const auto &entry = batch_clock[index]; const auto &p = entry.preparation;
      out << (index ? "," : "") << "{\"index\":" << index << ",\"rows\":" << entry.rows
          << ",\"requests\":" << entry.requests << ",\"visible_before\":" << entry.visible_before
          << ",\"role\":" << entry.role << ",\"generation\":" << entry.generation
          << ",\"finished\":" << entry.finished << ",\"slot\":" << p.slot
          << ",\"prior_uses\":" << p.phase_slot_prior_uses
          << ",\"layout_seconds\":" << p.layout_seconds
          << ",\"batch_prepare_seconds\":" << p.batch_prepare_seconds
          << ",\"replay_prepare_seconds\":" << p.replay_prepare_seconds
          << ",\"report_snapshot_seconds\":" << p.report_snapshot_seconds
          << ",\"nodes\":" << p.nodes.size() << ",\"reports\":[";
      for (std::size_t node = 0; node < p.reports.size(); ++node) {
        const auto &r = p.reports[node]; const auto &u = r.metadata_upload;
        out << (node ? "," : "") << "{\"node\":" << p.nodes.at(node).ordinal()
            << ",\"layout_generation\":" << r.layout_generation
            << ",\"reused_native_plan\":" << r.reused_native_plan
            << ",\"float_bytes\":" << r.float_workspace_bytes << ",\"int_bytes\":" << r.int_workspace_bytes
            << ",\"cta_tile_q\":" << r.cta_tile_q << ",\"padded_batch_size\":" << r.padded_batch_size
            << ",\"split_kv\":" << r.split_kv << ",\"bf16_partials\":" << r.bf16_partials
            << ",\"capture_compatible\":" << r.capture_compatible
            << ",\"native_metadata_unknown\":" << r.native_metadata_unknown
            << ",\"host_waits\":" << r.host_waits << ",\"metadata_staging_bytes\":" << r.metadata_staging_bytes
            << ",\"upload\":{\"resources\":" << u.resources << ",\"copies\":" << u.copies
            << ",\"active_copies\":" << u.active_copies << ",\"phases\":" << u.phases
            << ",\"no_op_copies\":" << u.no_op_copies << ",\"logical_bytes\":" << u.logical_bytes
            << ",\"physical_bytes\":" << u.physical_bytes << ",\"staging_bytes\":" << u.staging_bytes
            << ",\"metadata_bytes\":" << u.metadata_bytes << ",\"native_calls\":" << u.native_calls
            << ",\"native_waits\":" << u.native_waits << ",\"phase_completions\":" << u.phase_completions
            << ",\"host_waits\":" << u.host_waits << ",\"native_metadata_unknown\":" << u.native_metadata_unknown << "}}";
      }
      out << "]}";
    }
    out << "]}"; std::cerr << out.str() << '\n';
  }
'''
assert s.count(anchor)==1;s=s.replace(anchor,anchor+extra)
anchor='  const auto role = calls[0].role; const auto generation = calls[0].generation;\n'
extra='''  auto *batch_clock = model.begin_batch_clock(drafts_token(role) ? 2 : calls[0].ids().size(),
      calls.size(), calls[0].request->session->length(), role, generation);
  auto *preparation = batch_clock ? &batch_clock->preparation : nullptr;
'''
assert s.count(anchor)==1;s=s.replace(anchor,anchor+extra)
anchor='        nullptr, nullptr, request.ledger.get()));\n'
assert s.count(anchor)==1;s=s.replace(anchor,'        nullptr, outputs.empty() ? preparation : nullptr, request.ledger.get()));\n')
anchor='  model.prepare_evaluations(std::span(inputs.data(), inputs.size()), nullptr, role, calls[0].completion); model.submit_evaluations();\n'
assert s.count(anchor)==1;s=s.replace(anchor,anchor.replace('), nullptr, role', '), preparation, role'))
anchor='''      finish_generation_call(model, calls[j]);
    }
  } catch (...) {
'''
assert s.count(anchor)==1;s=s.replace(anchor,anchor.replace('  } catch (...) {','    if (batch_clock) { batch_clock->finished = true; ++model.batch_clock_finished; }\n  } catch (...) {'))
anchor='  logical_prompt = cache::add(user_prompt, total_turns - requests.size());\n'
assert s.count(anchor)==1;s=s.replace(anchor,anchor+'  model.dump_batch_clock();\n')
after=W/'source/engine/models/qwen35/main.cc';after.parent.mkdir(parents=True,exist_ok=True);after.write_bytes(s.replace('\n',nl).encode())
patch=''.join(difflib.unified_diff(raw.decode().replace('\r\n','\n').splitlines(True),s.splitlines(True),fromfile='a/engine/models/qwen35/main.cc',tofile='b/engine/models/qwen35/main.cc'))
(W/'source.patch').write_text(patch,encoding='utf8')
save(W/'source-pins.json',dict(before=pin(before),canonical=pin(p),after=pin(after),patch=pin(W/'source.patch')))
save(W/'plan.json',dict(scope='Private current-b346 Model TU only; no Graph/core/provider/SDK changes, no GPU authorization yet.',capacity=68,expected_reports=6,existing_path='PreparationObservation clocks in prepare_evaluations and original finish post-host_endpoint report snapshot.',allocations='Fixed68 observation controls, with existing vectors initially empty. Original reports/nodes resize after host_endpoint, separately timed by report_snapshot_seconds. Final ostringstream allocates only after natural journey endpoints. Not TPS evidence.',frozen_control='2a94 image and221 other absolute link inputs, plus13 system libraries; current b346 has CPU-forward/shared-selection source changes outside default K1 GPU semantics.',limits='Only new private Model hook. Existing cold_start excludes earlier token/position/identity writes. Failures retain original exceptions and unfinished entries; overflow suppresses only additional diagnostics. No new clock or Graph implementation.'))
print(json.dumps(pin(after)))
