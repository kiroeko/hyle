"""Build only the frozen Model TU and relink the retained2a94 closure."""
from pathlib import Path
import hashlib,importlib.util,json,os,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;R=W.parents[1];B=R/'.scratch/inference-current-closure-20261026'
spec=importlib.util.spec_from_file_location('model_batch_clock_build',R/'.scratch/inference-synchronous-step-report-20261025/check_host.py')
h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def pin(p):
 p=Path(p).resolve();b=p.read_bytes()
 return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def save(p,d):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(d,indent=2)+'\n',encoding='utf-8')
def key(p):return os.path.normcase(str(Path(p).resolve()))
canonical_pin=pin(R/'engine/models/qwen35/main.cc')
assert canonical_pin['sha256']=='b346d408cdf8226b2df464f757483cc3aecd5b7c2f2d7f290751c7115d3cc44c'
before=read(B/'ready-current.json');assert pin(before['image']['path'])==before['image']
assert before['image']['sha256']=='2a94f0b297d00825c6470138c6daf472868161ff76a0dea15477f0c57b58b7a6'
pins=read(W/'source-pins.json');assert pin(pins['after']['path'])==pins['after']
old=read(B/'engine/model/command.json')['command'];source=Path(pins['after']['path']);out=W/'compile'
command=[];skip=False
for i,arg in enumerate(old):
 if skip:skip=False;continue
 if arg.lower()=='/sourcedependencies':skip=True;continue
 if arg.lower().startswith(('/fo','/fd')) or key(arg)==key(pins['canonical']['path']):continue
 command.append(arg)
command.extend(['/I'+str(R/'engine/models/qwen35'),str(source),'/sourceDependencies',str(out/'dependencies.json'),'/Fo'+str(out/'unit.obj'),'/Fd'+str(out/'unit.pdb')])
assert all(x in command for x in ['/W4','/WX','/DHYLE_COMPUTE_CUDA=1','/DGGML_USE_CUDA','/MD','/O2'])
env=h.discover_environment(compiler='msvc',cache={'CMAKE_C_COMPILER':command[0],'CMAKE_CXX_COMPILER':command[0],'CMAKE_GENERATOR':'Ninja'},backends=()).env
save(W/'build-plan.json',dict(source_pins=pin(W/'source-pins.json'),compile_recipe=pin(B/'engine/model/command.json'),link_recipe=pin(B/'link-current/process/command.json'),baseline=pin(B/'ready-current.json'),only_replacement='engine/model/unit.obj',other_TUs=0,SDK_builds=0))
compiled=h.execute(command,env,out,timeout=120)
deps=read(out/'dependencies.json')['Data'];prior=read(B/'engine/model/dependencies.json')['Data']
assert {key(p) for p in deps['Includes']}=={key(p) for p in prior['Includes']},'Header closure changed unexpectedly'
actual=[pin(p) for p in dict.fromkeys([deps['Source'],*deps['Includes']])]
save(out/'actual-dependencies.json',actual)
old_model=next(x for x in read(B/'engine/summary.json')['results'] if x['key']=='model')['object']
assert pin(old_model['path'])==old_model
new_model=pin(out/'unit.obj');inputs=read(B/'link-inputs-current.json')
assert sum(key(x['path'])==key(old_model['path']) for x in inputs)==1
linkdir=W/'link';linkargs=read(B/'link-current/process/command.json')['command'];link=[];replaced=0
for arg in linkargs:
 if key(arg)==key(old_model['path']):link.append(new_model['path']);replaced+=1
 elif arg.upper().startswith('/OUT:'):link.append('/OUT:'+str(linkdir/'hyle.exe'))
 elif arg.upper().startswith('/MAP:'):link.append('/MAP:'+str(linkdir/'hyle.map'))
 else:link.append(arg)
assert replaced==1
linked=h.execute(link,env,linkdir/'process',timeout=120)
runtime=read(B/'runtime-current.json');native=Path(runtime['native']['path']);target=linkdir/Path(runtime['native_hardlink']['path']).name
os.link(native,target);assert pin(native)['sha256']==pin(target)['sha256']
runtime['native_hardlink']=pin(target);save(W/'runtime.json',runtime)
mapped=[new_model if key(x['path'])==key(old_model['path']) else x for x in inputs]
save(W/'link-inputs.json',mapped);save(W/'object-map.json',dict(before=old_model,after=new_model,unchanged_absolute_inputs=len(inputs)-1))
ready=dict(status='BUILT_NOT_RUN',image=pin(linkdir/'hyle.exe'),app=new_model,source_pins=pin(W/'source-pins.json'),runtime=pin(W/'runtime.json'),
 commands=[pin(out/'command.json'),pin(linkdir/'process/command.json')],compile=compiled,link=linked,actual_dependencies=pin(out/'actual-dependencies.json'),
 link_inputs=pin(W/'link-inputs.json'),object_map=pin(W/'object-map.json'),limits='Frozen2a94 rest-of-closure with current-b346 Model+private existing-observation hook. No GPU result/TPS. Current CPU-forward/shared-selector patches have unchanged default K1 GPU semantics; not a claim this image is byte-identical to2a94.')
assert pin(R/'engine/models/qwen35/main.cc')==canonical_pin
ready['canonical_main']=canonical_pin
ready['GPU_runs']=0
save(W/'ready.json',ready);print(json.dumps(ready,indent=2))
