"""Offline compact evidence publication; never builds or runs an image."""
from pathlib import Path
import hashlib,json,zipfile
W=Path(__file__).resolve().parent;R=W.parents[1]
P=R/'docs/evidence/performance/inference-model-prepare-attribution-2026-10-26.json'
Z=P.with_suffix('.zip')
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def pin(p):return dict(path=p.relative_to(R).as_posix(),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def save(p,d):p.write_text(json.dumps(d,indent=2)+'\n',encoding='utf8')
s=read(W/'summary.json'); ready=read(W/'ready.json')
assert s['stdout_full_non_time_differences']==0 and s['completeness']['overflow']==0
g=s['groups']; elapsed=read(W/'run/report.json')['decode_seconds']
batch=g['decode']['stages']['batch_prepare_seconds']['total_ms']/1000
interpretation=dict(
 strongest_fact='The same-run Graph-external parent is33.4354ms: layout8.7681ms + batch24.6504ms + tail/printed rounding0.0169ms. On66decode calls layout8.4414ms, batch16.3278ms and replay60.3606ms are separate siblings, never additive to the parent again.',
 reuse='396target decode reports:366reused/30fresh.61episodes reuse all6target plans;5episodes contain fresh target plans.45episodes with no Graph record reuse all270target plans. Per-episode metadata upload remains:66native calls,66host waits,1952physical bytes total; shared followers do not repeat it.',
 source_exclusion='FlashInfer successful workspace/update reuse skips its scheduler/device queries. The45Graph-no-record episodes show7.457ms whole batch preparation despite270/270target-plan reuse; a static SM/CC/occupancy cache cannot explain or remove this whole cost.',
 next_mechanism=dict(priority='Conditional source-feasibility candidate, not an implementation or demonstrated gain: eliminate the repeated host-side metadata readiness round trip only if the existing copy/queue/Graph dependency can carry it safely.',
  trigger='Actual target metadata is about30bytes per decode on average, but has one real host wait per episode. It is already shared across6target layers. Investigate queue-ordered metadata production rather than another metadata cache or6layer upload dedup.',
  required_contract='Current mirror is published as ReadLease only after CopyBatch actual retirement. Moving uploaded.wait alone is invalid. A candidate must keep the original mutable/native-use owner through copy completion, provide a legal current metadata dependency/seal before attention, preserve fresh-plan sizing and before-command-change invalidation, and retain all owners on failure/unknown retirement. No second manager or fake ready publication.',
  qualification='The reports cover6target nodes; separate draft attention planning/upload is inside the batch parent but not separately reported. No per-upload/query/wait elapsed clock exists here. Do not claim metadata wait accounts for16.3278ms.',
  same_run_whole_batch_elapsed_share_percent=batch/elapsed*100,
  hypothetical_speed_percent_if_entire_batch_were_deleted=(elapsed/(elapsed-batch)-1)*100,
  bound_warning='The16.3278ms whole decode batch bucket is a deliberately generous algebraic envelope, not recoverable time. It includes validation, native fresh planning, real copies/retirement and append binding. Moving work to submit/wait may merely move cost; no gain or ceiling for a concrete mechanism is measured.'),
 broader_priority='Replay preparation60.3606ms remains the larger sibling. This diagnostic does not justify a new cache, a broad batch API redesign, or reopening closed state/copy/chunk candidates.',
 graph_prior_comparison='The prior Graph-only diagnostic supports consistent interpretation of capture27/reuse105 and the stage boundary. Its98.0957/34.477ms are not subtracted from this run; no cross-run residual is a result.',
 observations_cost='Original nodes/reports vectors resize and query after host_endpoint. Their separately measured snapshot total0.9606ms can affect the next natural endpoint/process; final serialization is also outside the journey endpoints. This image is diagnostic, not TPS evidence.')
save(W/'interpretation.json',interpretation)
files={}
def add(p,name):
 assert p.is_file() and name not in files
 assert p.suffix.lower() not in {'.obj','.exe','.dll','.lib','.exp','.bin'}
 files[name]=p
for name in ['prepare.py','build.py','run.py','analyze.py','publish.py','plan.json','source.patch','source-pins.json','build-plan.json','ready.json','runtime.json','object-map.json','link-inputs.json','run-plan.json','summary.json','interpretation.json']:
 add(W/name,'diagnostic/'+name)
for directory in ['compile','link/process','run']:
 for f in sorted((W/directory).rglob('*')):
  if f.is_file()and f.suffix in {'.json','.log'}:add(f,'diagnostic/'+f.relative_to(W).as_posix())
B=R/'.scratch/inference-current-closure-20261026'
for name in ['ready-current.json','runtime-current.json','link-inputs-current.json']:
 add(B/name,'control/'+name)
for name in ['command.json','result.json','stdout.log','stderr.log']:
 add(B/'full-window/two-turn-timing/02-hyle_mtp'/name,'control/baseline/'+name)
add(R/'.scratch/inference-batch-prepare-reuse-20261026/memo.json','reference/batch-prepare-source-review.json')
add(R/'.scratch/inference-graph-cold-clock-20261026/attempt1/summary.json','reference/prior-graph-diagnostic.json')
manifest=[dict(member=n,**pin(p))for n,p in sorted(files.items())]
with zipfile.ZipFile(Z,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6)as z:
 for n,p in sorted(files.items()):z.write(p,n)
 z.writestr('archive/manifest.json',json.dumps(manifest,indent=2)+'\n')
with zipfile.ZipFile(Z)as z:
 assert z.testzip()is None
 info=z.infolist()
archive=dict(**pin(Z),members=len(info),logical_bytes=sum(f.file_size for f in info),CRC='PASS')
report=dict(status=s['status'],date='2026-10-26',scope='Exactly one current-b346 private Model observation TU using existing PreparationObservation/g::batch::report. Original K1 natural two-turn fixture, no Graph/core/provider changes or profiler.',
 source=read(W/'source-pins.json'),control_image=read(B/'ready-current.json')['image'],diagnostic_image=ready['image'],
 frozen_boundary='Control2a94 is historical frozen current-source image. Diagnostic Model starts at canonical b346 including CPU forwarding/shared selection, with default K1 GPU semantics unchanged; all other221absolute+13system inputs use the same2a94 closure. No claim the source/image is byte-identical to2a94.',
 build=dict(Model_TUs=1,other_TUs=0,compile=ready['compile'],link=ready['link'],actual_dependencies=ready['actual_dependencies'],object_map=ready['object_map']),
 process=s['process'],GPU='RELEASED',model_processes=1,stdout_full_non_time_differences=0,
 stdout_gate='Original recursive named timing/clock/throughput fields only; no work/cache/ledger/RNG/ID/state or replay metadata excluded. Original stdout retained.',
 stderr_unexpected_difference_count=s['stderr_unexpected_difference_count'],
 stderr_gate='Exactly one final MODEL_BATCH_CLOCK line is new. Other lines compared after named clock/time normalization; differences are retained, not silently filtered.',
 completeness=s['completeness'],original_graph_capture=s['original_graph_capture'],groups=g,interpretation=interpretation,
 limits=s['limits']+['ready.json remains the pre-run BUILT_NOT_RUN checkpoint. The later run/process and summary are authoritative.','No independently readback comparison of unreported device tensors, no failure/unknown-retirement injection, no peer or throughput screen.'],
 product_edits=0,SDK_builds=0,HTTP=0,archive=archive)
save(P,report);save(W/'publication.json',dict(report=pin(P),archive=archive))
print(json.dumps(dict(report=pin(P),archive=archive)))
