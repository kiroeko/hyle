"""Exactly one Root-authorized K1 diagnostic process; no retry or screen."""
from pathlib import Path
import hashlib, importlib.util, json, os, sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;R=W.parents[1]
B=R/'.scratch/inference-current-closure-20261026/full-window/two-turn-timing/02-hyle_mtp'
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def pin(p):
 p=Path(p);return dict(path=str(p.resolve()),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def save(p,d):p.write_text(json.dumps(d,indent=2)+'\n',encoding='utf-8')
ready=read(W/'ready.json');runtime=read(W/'runtime.json')
assert pin(ready['image']['path'])==ready['image']
baseline=read(B/'result.json')
assert baseline['image']['sha256']=='2a94f0b297d00825c6470138c6daf472868161ff76a0dea15477f0c57b58b7a6'
command=baseline['command'].copy();command[0]=ready['image']['path']
assert command[command.index('--mtp-max-drafts')+1]=='1'
out=W/'run';assert not out.exists(),'No repeat/overwrite of authorized process'
save(W/'run-plan.json',dict(ready=pin(W/'ready.json'),runtime=pin(W/'runtime.json'),
 baseline_process=pin(B/'result.json'),baseline_stdout=pin(B/'stdout.log'),
 command=command,timeout_seconds=120,processes=1,profiler=False,TPS=False,
 scope='Current-b346 Model diagnostic with fixed existing Observation hook; frozen2a94 rest of closure. Only one K1 natural two-turn process.'))
spec=importlib.util.spec_from_file_location('batch_clock_execute',R/'.scratch/inference-synchronous-step-report-20261025/check_host.py')
h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
env=os.environ.copy();env.update(HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1')
env['PATH']=str(Path(command[0]).parent)+';'+runtime['PATH']
result=h.execute(command,env,out,timeout=120)
print('MODEL_DIAGNOSTIC_TERMINAL_GPU_RELEASED',json.dumps(result),flush=True)
