"""Offline same-run decomposition; does not execute a model."""
from pathlib import Path
import hashlib,json,re,statistics
W=Path(__file__).resolve().parent;R=W.parents[1]
B=R/'.scratch/inference-current-closure-20261026/full-window/two-turn-timing/02-hyle_mtp'
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def save(p,d):p.write_text(json.dumps(d,indent=2)+'\n',encoding='utf8')
def pin(p):return dict(path=str(p.resolve()),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def report(p):return json.loads(next(s for s in reversed(p.read_text(encoding='utf8').splitlines())if s.startswith('{')))
def normalize(v):
 if isinstance(v,list):return [normalize(x)for x in v]
 if isinstance(v,dict):return {k:normalize(x)for k,x in v.items()if not any(t in k for t in ['seconds','tokens_per_second','clock_unix','unix_ns','unix_ms'])}
 return v
def differences(a,b,path='$'):
 if type(a)is not type(b):return [dict(path=path,baseline=a,actual=b)]
 if isinstance(a,dict):
  rows=[]
  for k in sorted(set(a)|set(b)):
   rows+=differences(a[k],b[k],path+'.'+k)if k in a and k in b else [dict(path=path+'.'+k,baseline=a.get(k),actual=b.get(k))]
  return rows
 if isinstance(a,list):
  if len(a)!=len(b):return [dict(path=path,baseline_length=len(a),actual_length=len(b))]
  return [r for i,(x,y)in enumerate(zip(a,b))for r in differences(x,y,f'{path}[{i}]')]
 return []if a==b else[dict(path=path,baseline=a,actual=b)]
def stats(xs):return dict(count=len(xs),total_ms=sum(xs)*1000,mean_us=statistics.mean(xs)*1e6,median_us=statistics.median(xs)*1e6,min_us=min(xs)*1e6,max_us=max(xs)*1e6)

actual=report(W/'run/stdout.log');baseline=report(B/'stdout.log')
save(W/'run/report.json',actual)
delta=differences(normalize(baseline),normalize(actual));save(W/'run/non-time-differences.json',delta)
assert not delta,'Full non-time gate failed; differences retained'
stderr=(W/'run/stderr.log').read_text(encoding='utf8').splitlines()
lines=[s for s in stderr if s.startswith('MODEL_BATCH_CLOCK ')]
assert len(lines)==1
def stderr_normalized(lines):
 return [re.sub(r'([A-Za-z0-9_]*(?:seconds|tokens_per_second|clock_unix[A-Za-z0-9_]*|unix_ns|unix_ms)\s*[=:]\s*)[-+0-9.eE]+',r'\1<TIME>',s)for s in lines if not s.startswith('MODEL_BATCH_CLOCK ')]
stderr_delta=differences(stderr_normalized((B/'stderr.log').read_text(encoding='utf8').splitlines()),stderr_normalized(stderr),'stderr')
save(W/'run/stderr-unexpected-differences.json',stderr_delta)
clock=json.loads(lines[0].split(' ',1)[1]);save(W/'run/observations.json',clock)
assert clock['seen']==clock['finished']==clock['capacity']==68 and clock['overflow']==0
assert len(clock['entries'])==68 and all(e['finished']and e['nodes']==len(e['reports'])==6 for e in clock['entries'])
prepared=[]
for line in stderr:
 if not line.startswith('prepared '):continue
 v=dict(re.findall(r'(\w+)=([^ ]+)',line))
 prepared.append(dict(rows=int(v['T']),visible=int(v['visible']),cold_seconds=float(v['cold_batch_seconds']),recorded=int(v['capture_recorded']),reused=int(v['capture_reused'])))
assert len(prepared)==68
joined=[]
for e,p in zip(clock['entries'],prepared):
 assert e['index']==len(joined)and e['rows']==p['rows']and e['requests']==1
 t=e['layout_seconds']+e['batch_prepare_seconds']+e['replay_prepare_seconds']
 joined.append(dict(**e,prepared=p,outside_prepare_replay_seconds=p['cold_seconds']-e['replay_prepare_seconds'],parent_tail_and_print_rounding_seconds=p['cold_seconds']-t))
save(W/'run/paired-observations.json',joined)
groups={}
for name,items in [('all',joined),('prefill',[x for x in joined if not x['generation']]),('decode',[x for x in joined if x['generation']]),('decode_no_graph_record',[x for x in joined if x['generation']and not x['prepared']['recorded']]),('decode_has_graph_record',[x for x in joined if x['generation']and x['prepared']['recorded']]),('decode_target_all_reused',[x for x in joined if x['generation']and all(r['reused_native_plan']for r in x['reports'])]),('decode_any_target_fresh',[x for x in joined if x['generation']and any(not r['reused_native_plan']for r in x['reports'])])]:
 if not items:continue
 rs=[r for x in items for r in x['reports']]
 groups[name]=dict(calls=len(items),stages={k:stats([x['prepared']['cold_seconds']if k=='cold_parent_seconds'else x[k]for x in items])for k in ['cold_parent_seconds','layout_seconds','batch_prepare_seconds','replay_prepare_seconds','outside_prepare_replay_seconds','parent_tail_and_print_rounding_seconds','report_snapshot_seconds']},
  target_node_reports=dict(count=len(rs),reused=sum(r['reused_native_plan']for r in rs),fresh=sum(not r['reused_native_plan']for r in rs),host_waits=sum(r['host_waits']for r in rs),metadata_staging_bytes=sum(r['metadata_staging_bytes']for r in rs),upload={k:sum(r['upload'][k]for r in rs)for k in ['active_copies','logical_bytes','physical_bytes','staging_bytes','native_calls','native_waits','phase_completions','host_waits']}))
summary=dict(status='PASS_ONE_K1_MODEL_OBSERVATION_DIAGNOSTIC_NOT_TPS',GPU='RELEASED',process=read(W/'run/process.json'),ready=pin(W/'ready.json'),baseline_result=pin(B/'result.json'),stdout_full_non_time_differences=0,stderr_unexpected_difference_count=len(stderr_delta),completeness={k:clock[k]for k in ['seen','finished','capacity','overflow','expected_reports_per_call']},
 original_graph_capture=dict(recorded=sum(p['recorded']for p in prepared),reused=sum(p['reused']for p in prepared)),groups=groups,
 limits=['Only same-run clocks are subtracted. Historical98.0957/34.477ms is not an operand in this decomposition.','layout includes actual layout/page/state/output preparation after cold_start; earlier token/position/identity writes and initialize_slot are outside this parent.','batch_prepare includes g::batch::prepare and bind_append. The6target reports are counts/bytes/waits, not per-node timing, and omit the separate draft attention node.','Fresh/reused native-plan facts differ from Graph capture facts. Shared metadata followers report no upload; summing the6target nodes avoids pretending6independent uploads.','Existing vectors resize in original finish report branch after host_endpoint; report_snapshot_seconds is separate, not part of cold_parent. It may still affect subsequent natural work/process timing. Fixed controls and final serialization also alter diagnostic footprint. Not TPS or a wholly uninstrumented binary.','No independent device-state byte readback or failure injection. No claimed time per driver query/upload/wait and no recoverable ceiling.'],raw=dict(stdout=pin(W/'run/stdout.log'),stderr=pin(W/'run/stderr.log'),observations=pin(W/'run/observations.json'),paired=pin(W/'run/paired-observations.json')))
save(W/'summary.json',summary)
print(json.dumps(dict(status=summary['status'],process=summary['process'],completeness=summary['completeness'],capture=summary['original_graph_capture'],groups=groups),indent=2))
