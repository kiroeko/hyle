#include "../compute_models/glm_flash_mixed_mlx_fixture.h"
#include "hyle/compute/apple_memory.h"
#include "hyle/graph/apple.h"
#include "../../src/compute_route_apple/apple_weights_internal.h"
#include <cstdio>
#include <cstdlib>
#include <string>

namespace {
namespace f = expert_working_set_test;
namespace a = hyle::compute::apple;
struct Backend final {
  using Slots = a::WeightSlots;
  using Batch = a::WeightBatch;
  a::Context &context;
  a::MemoryResource &memory;
  f::m::MemoryResourceRef resource;
  std::span<const f::g::QueueBinding> queues{};
  f::g::ExecutionSource source;
  struct Generation { const void *owner = nullptr; unsigned accepted = 0; };
  std::array<Generation,2> generations{};
  unsigned binding_sequence = 0;
  hyle::Result<Slots> create_slots(std::span<const f::BankSpec> banks,
                                    std::size_t capacity) {
    std::vector<a::WeightSpec> catalog;
    catalog.reserve(banks.size());
    for (const auto &bank : banks) catalog.push_back({bank.id, bank.description});
    return Slots::create(context, memory, catalog, capacity, {.max_fragments = 128});
  }
  hyle::Result<Batch> upload(Slots &slots, std::size_t slot,
                             std::span<const f::c::WeightSlice> slices) {
    auto result = slots.upload_slices(slot, slices);
    if (result) {
      auto binding = f::take(a::detail::WeightAccess::binding(*result,slices.front().id),"diagnostic owner identity");
      generations[slot].owner = binding.owner.get();
      ++generations[slot].accepted;
      std::fprintf(stderr,"HYLE_MLX_EVENT {\"event\":\"accepted_upload\",\"slot\":%zu,\"accepted_generation_ordinal\":%u}\n",slot,generations[slot].accepted);
    }
    return result;
  }
  hyle::Status bind(f::g::Invocation &invocation,
      std::span<const f::g::WeightBinding> bindings, const Batch &batch) {
    auto binding = f::take(a::detail::WeightAccess::binding(batch,bindings.front().id),"diagnostic bound generation");
    unsigned selected = 2;
    for (unsigned i=0;i<2;++i) if (generations[i].owner==binding.owner.get()) selected=i;
    if (selected==2) return hyle::Status::Internal("diagnostic lost original upload generation");
    const auto label=std::string("dynamic.slot")+std::to_string(selected)+".generation"+
        std::to_string(generations[selected].accepted)+".bind"+std::to_string(++binding_sequence);
    ::setenv("HYLE_APPLE_DIAG_LABEL",label.c_str(),1);
    std::fprintf(stderr,"HYLE_MLX_EVENT {\"event\":\"bind_label\",\"label\":\"%s\"}\n",label.c_str());
    return f::g::apple::bind(invocation, bindings, batch);
  }
  hyle::Result<f::g::CompiledGraph> compile(const f::g::Graph &graph) {
    const std::array domains{f::g::StorageDomain{resource}};
    const std::array targets{f::g::ExecutionTarget{source, f::g::StorageDomainId{0}}};
    ::setenv("HYLE_APPLE_DIAG_LABEL","dynamic.cold.compile",1);
    return f::g::compile(graph, {domains, targets});
  }
  hyle::Status prepare(f::g::Invocation &invocation) {
    return invocation.prepare_replay(queues);
  }
  hyle::Status write(f::m::BufferView destination, std::span<const std::byte> bytes) {
    return destination.write(bytes);
  }
  hyle::Status read(f::m::ConstBufferView source_view, std::span<std::byte> bytes) {
    return source_view.read(bytes);
  }
};
template<class Run> void run_apple(Run run) {
  auto context = f::take(a::Context::create(), "Apple context");
  ::testing::Test::RecordProperty("device", context.environment()->device_name);
  auto memory = f::take(a::MemoryResource::create(context), "Apple shared memory");
  Backend api{context, memory, memory.ref(), {},
      f::take(f::g::apple::execution_source(context), "original Apple execution source")};
  run(api);
}
} // namespace

TEST(AppleGlmFlashMixedMlx, OriginalRolesKeepTypedPromotionAndWeightGeneration) {
  run_apple([](auto &api) { glm_flash_mixed_mlx_test::run_gpu(api); });
}


// VALIDATION-ONLY tiny Graph constants comparison; no product/operator changes.
TEST(AppleImmutableMetadataDiagnostic, GraphConstantsKeepMetadataReadyAcrossThreeSubmissions) {
  run_apple([](auto &api) {
    namespace x=glm_flash_mixed_mlx_test;
    constexpr std::int64_t n=8,k=64;
    auto builder=f::take(f::g::GraphBuilder::create(),"diagnostic constant graph");
    const auto ad=f::dense(f::Type::kBFloat16,{1,k});
    const auto wd=f::dense(f::Type::kUInt32,{n,k/8});
    const auto sd=f::dense(f::Type::kFloat16,{n,1});
    const auto input=f::take(builder.input(ad),"BF16 activation");
    const std::array ids{f::take(builder.constant(wd),"constant packed W"),
        f::take(builder.constant(sd),"constant original F16 SF"),
        f::take(builder.constant(sd),"constant original F16 bias")};
    std::vector<std::uint32_t> codes(std::size_t(n*k),1U);
    for(std::int64_t row=0;row<n;++row)codes[std::size_t(row*k)]=unsigned(2+row%3);
    auto packed=mlx_affine_test::pack(codes,std::size_t(n),std::size_t(k),4);
    std::vector<std::uint16_t> scales(std::size_t(n),std::uint16_t{0}),biases(scales.size());
    for(std::int64_t row=0;row<n;++row){scales[std::size_t(row)]=x::scale_bits(0,11,row,0,0);biases[std::size_t(row)]=scales[std::size_t(row)]^0x8000U;}
    const auto output=f::take(builder.add(f::c::model_ops::mlx_quantized_matmul(
        f::c::model_ops::MlxWeightFormat::kAffine,4,64),input,ids[0],ids[1],ids[2]),"original affine op");
    f::check(builder.publish(output),"publish constant control");
    const auto graph=f::take(std::move(builder).finish(),"constant control finish");
    const std::array desc{wd,sd,sd};
    const std::array payload{f::raw(packed),f::raw(scales),f::raw(biases)};
    std::array<f::m::Buffer,3> buffers;
    std::array<f::g::ConstantBinding,3> constants;
    for(std::size_t i=0;i<3;++i){
      buffers[i]=f::take(f::m::Buffer::create(api.resource,payload[i].size(),256),"constant bytes");
      f::check(api.write(buffers[i].view(),payload[i]),"write constant original bytes");
      constants[i]={ids[i],f::take(f::c::ConstTensorView::create(desc[i],buffers[i].view()),"constant typed bytes"),f::g::ConstantPolicy::kMaterialize};
    }
    const std::array domains{f::g::StorageDomain{api.resource}};
    const std::array targets{f::g::ExecutionTarget{api.source,f::g::StorageDomainId{0}}};
    ::setenv("HYLE_APPLE_DIAG_LABEL","constants.cold.compile",1);
    auto compiled=f::take(f::g::compile(graph,{domains,targets},{.constants=constants}),"constant control compile");
    auto invocation=f::take(compiled.executable.create_invocation({.resources=f::g::ResourceOptions{}}),"constant control invocation");
    auto activation=f::take(f::m::Buffer::create(api.resource,ad.required_bytes().value(),256),"dynamic BF16 control A");
    f::check(invocation.bind(input,f::take(f::c::ConstTensorView::create(ad,activation.view()),"control A")),"bind control A");
    f::c::LeasePool pool;
    if(f::take(compiled.executable.output_ownership(),"control ownership")==f::g::OutputOwnership::kCaller){
      const auto od=f::take(graph.value_description(output),"control output description");
      pool=f::take(f::c::LeasePool::create(api.resource,256,{.max_blocks=1}),"control output pool");
      f::check(invocation.bind(output,od,f::take(pool.allocate(od.required_bytes().value()),"control writer")),"bind control writer");
    }
    f::check(api.prepare(invocation),"prepare control");
    for(unsigned phase=0;phase<3;++phase){
      const auto label=std::string("constants.phase")+std::to_string(phase);
      ::setenv("HYLE_APPLE_DIAG_LABEL",label.c_str(),1);
      std::vector<std::uint16_t> values(std::size_t(k),0U);
      const float a_value=phase==0?.5F:phase==1?1.F:2.F;
      values[0]=x::nv::bf16(a_value);
      f::check(api.write(activation.view(),std::as_bytes(std::span(values))),"update control A");
      auto done=f::take(invocation.submit(api.queues),"control submit");f::check(done.wait(),"control completed");
      auto result=f::take(invocation.result(output),"control result");
      const auto actual=ga_indexer_state_test::read_result<float>(result,[&](f::m::ConstBufferView from,std::span<std::byte> to){return api.read(from,to);});
      ASSERT_EQ(actual.size(),std::size_t(n));
      for(std::int64_t row=0;row<n;++row)EXPECT_EQ(actual[std::size_t(row)],
          (float(codes[std::size_t(row*k)])-1.F)*x::half(scales[std::size_t(row)])*a_value);
    }
    ::testing::Test::RecordProperty("successful_submissions",3);
    ::testing::Test::RecordProperty("scope","tiny Graph compile constants;BF16 A/F16 SF+bias;original GLM SF bit pattern;3 actual dynamic A submits");
  });
}
