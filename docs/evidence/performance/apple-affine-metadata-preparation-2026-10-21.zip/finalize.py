from pathlib import Path
import collections,hashlib,json,math,runpy,xml.etree.ElementTree as E
R=Path.cwd();A=R/'.scratch/architecture-refactor-2026-10-18';P=A/'apple-immutable-materialization-2026-10-21';O=P/'apple/mac/final';Q=O/'results'
def read(p):return json.loads(p.read_text())
def save(p,v):p.write_text(json.dumps(v,indent=2)+'\n')
def ident(p):
 b=p.read_bytes();return dict(path=p.relative_to(R).as_posix(),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
plan=read(O/'plan.json');compiles=read(Q/'compile-summary.json')['compiles'];audit=read(P/'apple/actual-dependencies-audit.json');assert audit['accidental_drift']==0 and all(c['exit']==0 for c in compiles)
log=(Q/'run.stderr.log').read_text().splitlines();frames=[json.loads(x[len('HYLE_MLX_GRAPH '):])for x in log if x.startswith('HYLE_MLX_GRAPH ')];events=[json.loads(x[len('HYLE_MLX_EVENT '):])for x in log if x.startswith('HYLE_MLX_EVENT ')];assert not any(x.startswith('HYLE_MLX_GRAPH_ERROR')for x in log)
assert len(frames)==10 and not any(f['truncated']for f in frames)
save(P/'apple/native-graph-frames.json',dict(diagnostic_nonproduct=True,frames=frames,events=events))
def summary(f):
 out=dict(sequence=f['sequence'],phase=f['phase'],label=f['label'],reachable_arrays=f['reachable_arrays'],program_observer_address=f['program'],f16_metadata_casts=[],bf16_activation_casts=[])
 for c in f['casts']:
  item=dict(shape=c['output']['shape'],input_id=c['input']['id'],input_status=c['input']['status'],input_available=c['input']['available'],output_id=c['output']['id'],output_status=c['output']['status'],output_available=c['output']['available'])
  out['f16_metadata_casts'if c['input']['dtype']=='float16'else'bf16_activation_casts'].append(item)
 out['logical_f32_metadata_bytes']=sum(math.prod(c['shape'])*4 for c in out['f16_metadata_casts']);out['pending_f16_metadata_casts']=sum(c['output_status']==0 for c in out['f16_metadata_casts'])
 return out
by=[summary(f)for f in frames];dynamic=[x for x in by if x['phase']=='actual_before_eval'and x['label'].startswith('dynamic.')];constant=[x for x in by if x['phase']=='actual_before_eval'and x['label'].startswith('constants.')]
assert len(dynamic)==5 and len(constant)==3
assert all(x['pending_f16_metadata_casts']==12 and x['logical_f32_metadata_bytes']==31457280 for x in dynamic)
assert all(x['pending_f16_metadata_casts']==2 for x in constant)
assert len({tuple(c['input_id']for c in x['f16_metadata_casts'])for x in constant})==1
assert all(c['input_available']and not c['output_available']for x in dynamic+constant for c in x['f16_metadata_casts'])
cases=[]
for c in E.parse(Q/'tests.xml').findall('.//testcase'):
 assert not c.findall('failure')and not c.findall('skipped');cases.append(dict(name=c.get('classname')+'.'+c.get('name'),properties={p.get('name'):p.get('value')for p in c.findall('./properties/property')}))
assert len(cases)==2 and sum(int(c['properties']['successful_submissions'])for c in cases)==7
ssh=runpy.run_path(str(A/'batch-query-extent/delegated/apple/validate.py'))['ssh']
remote=ssh(r'''from pathlib import Path
import sys,json,hashlib,subprocess
r=Path(json.load(sys.stdin)['remote']);im=r/'immutable-materialization-diagnostic';m=Path(str(im)+'.map')
def ident(p):
 b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest(),symlink=p.is_symlink(),resolved=str(p.resolve()))
files=[im,m];objects=sorted((r/'objects').glob('*.o'));lines=m.read_text().splitlines();owners=[x for x in lines if x.startswith('[')]
matches=[x for x in owners if any(w in x for w in ['apple_context','apple_mature_float','glm_flash_mixed_mlx'])];oldcontext=[x for x in owners if 'apple_context' in x and '.a('in x];assert not oldcontext
status=Path('/Users/kiro/hyle-scratch/g09-air-direct-20261017/final-1dbfce9a0/apple-sdk/include/mlx/array.h');s=status.read_text().splitlines();lsof=subprocess.run(['/usr/sbin/lsof','-t',*map(str,files)],capture_output=True,text=True)
print(json.dumps(dict(remote_root=str(r),remote_root_is_symlink=r.is_symlink(),deletable_files=[ident(x)for x in files],retained_objects=[ident(x)for x in objects],active_lsof=lsof.stdout.strip().splitlines(),lsof_exit=lsof.returncode,map_owner_check=dict(map=ident(m),matching_object_rows=matches,old_context_archive_members=oldcontext,observer_symbol_rows=[x for x in lines if 'diagnostic_graph'in x][:2]),sdk_status=dict(identity=ident(status),excerpts=[dict(line=i+1,text=s[i])for i in range(386,405)]))))
''',dict(remote=plan['remote']))
assert not remote['remote_root_is_symlink']and not remote['active_lsof'];save(P/'apple/cleanup-inventory.json',remote);save(P/'apple/map-owner-check.json',remote['map_owner_check']);save(P/'apple/status-definition.json',remote['sdk_status'])
original=read(P/'diagnostic-source-freeze.json');freeze=[]
for x in original['overrides']:
 baseline=ident(R/x['canonical']['path']);assert baseline==x['canonical'];diag=ident(P/'diagnostic'/x['canonical']['path']);assert diag['sha256']==x['diagnostic']['sha256'];freeze.append(dict(canonical=baseline,diagnostic=diag))
save(P/'apple/source-freeze.json',dict(diagnostic_nonproduct=True,canonical_unchanged=True,overrides=freeze,actual_dependency_audit=ident(P/'apple/actual-dependencies-audit.json'),linked_inputs=ident(Q/'link-inputs.json'),baseline_resolved_link='AA/apple/mac/final/results/link.command.json;all old test objects excluded;current AA mature and Z CPU retained',SDK_rebuilt=False,normal_compile_flags_preserved=True))
report=dict(status='actual_finite_diagnostic_passed',scope='Two validation-only overrides. No canonical source, public ABI, compile mode, executor, cache or native SDK change.',observed=dict(native_graph_not_opaque=True,frames=len(frames),cold_frames=2,dynamic_actual_calls=5,constants_actual_calls=3,dynamic_successes=4,dynamic_expected_failure=1,accepted_weight_generations=3,weight_slots=2,constants_successes=3,rows=by),conclusion=['Every actual X compiled call retained twelve reachable F16-to-F32 metadata AsType results in unscheduled state, while their original F16 inputs were available. This includes a second successful call of slot0 generation2 after the expected failed-ID call.','The twelve F32 result shapes total 31,457,280 logical bytes per actual dynamic graph. This is not a measurement of live/resident memory or allocations.','The tiny captured Graph constants control retained two unscheduled F16-to-F32 metadata casts on each of its three submissions. Original F16 constant array ids remained identical across those calls; this native compiled path did not expose folded ready-F32 metadata.','Two BF16-to-F32 activation casts in the full X graph and one in the tiny control are dynamic arithmetic inputs; they are reported separately from immutable metadata.'],limitations=['Observation is after compiled(inputs), before async_eval. It proves reachable pending conversion nodes, not physical GPU dispatches, actual allocation counts, bytes moved or latency.','Original X helper creates a fresh Invocation for each execute call while reusing the compiled program and bound WeightBatch generations; this proves repeated compiled-call graphs, not same-Invocation replay.','Array ids and program addresses are transient diagnostic identities, may be recycled and are not payload generation keys. Generation ordinals are observer tags for successful slot uploads, not ReadLease generation().','Compiled fused primitive interiors were not traversed. F16 metadata casts were explicit reachable AsType primitives outside those fused interiors.','No cache implementation or expanded product design is proposed or signed by this experiment.'],cases=cases,evidence=dict(frames=ident(P/'apple/native-graph-frames.json'),raw_stderr=ident(Q/'run.stderr.log'),xml=ident(Q/'tests.xml'),compile_summary=ident(Q/'compile-summary.json'),link_command=ident(Q/'link.command.json'),run_command=ident(Q/'run.command.json'),source_freeze=ident(P/'apple/source-freeze.json'),map_owner_check=ident(P/'apple/map-owner-check.json'),status_definition=ident(P/'apple/status-definition.json'),hardware=ident(O/'hardware.json'),cleanup=ident(P/'apple/cleanup-inventory.json')))
save(P/'apple/final-validation.json',report);print(json.dumps(dict(report=ident(P/'apple/final-validation.json'),source_freeze=ident(P/'apple/source-freeze.json'),cleanup=ident(P/'apple/cleanup-inventory.json'),deletable_bytes=sum(x['bytes']for x in remote['deletable_files']),retained_objects=len(remote['retained_objects']),actual_cases=len(cases),successes=7,expected_failure=1),indent=2))
