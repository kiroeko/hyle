from pathlib import Path
import difflib,hashlib,json
P=Path(__file__).resolve().parent
def identity(p):
    b=p.read_bytes();return dict(path=p.as_posix(),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def store(rel,b):
    p=P/'diagnostic'/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b);return p
rel='src/compute_route_apple/apple_context.cc';original=Path(rel).read_bytes();text=original.decode()
text=text.replace('#include <exception>','#include <exception>\n#include <cstdio>\n#include <cstdlib>\n#include <map>\n#include <sstream>\n#include <unordered_set>')
hook=r'''
// VALIDATION-ONLY DIAGNOSTIC. Does not evaluate, copy, modify or retain data.
// This file is a validation overlay, never the canonical product source.
std::string diagnostic_quote(const char *text) {
  std::string out = "\"";
  for (const char *p = text; p && *p; ++p) {
    if (*p == '\\' || *p == '"') out += '\\';
    if (*p == '\n') { out += "\\n"; continue; }
    out += *p;
  }
  return out + "\"";
}
const char *diagnostic_dtype(const mx::array &value) {
  return value.dtype() == mx::float16 ? "float16"
      : value.dtype() == mx::bfloat16 ? "bfloat16"
      : value.dtype() == mx::float32 ? "float32" : "other";
}
void diagnostic_array(std::ostream &out, const mx::array &value) {
  out << "{\"id\":" << value.id() << ",\"dtype\":"
      << diagnostic_quote(diagnostic_dtype(value)) << ",\"shape\":[";
  bool comma = false;
  for (auto dim : value.shape()) { if (comma) out << ','; out << dim; comma = true; }
  out << "],\"status\":" << int(value.status())
      << ",\"available\":" << (value.status() == mx::array::available ? "true" : "false")
      << ",\"has_primitive\":" << (value.has_primitive() ? "true" : "false");
  if (value.has_primitive()) out << ",\"primitive\":" << diagnostic_quote(value.primitive().name());
  out << '}';
}
void diagnostic_graph(const void *program, const char *phase,
                      const std::vector<mx::array> &inputs,
                      const std::vector<mx::array> &outputs) noexcept {
  try {
    std::vector<mx::array> todo(outputs), casts;
    std::unordered_set<std::uintptr_t> visited;
    std::map<std::string, std::size_t> histogram;
    constexpr std::size_t limit = 10000;
    while (!todo.empty() && visited.size() < limit) {
      auto value = std::move(todo.back()); todo.pop_back();
      if (!visited.insert(value.id()).second) continue;
      if (value.has_primitive()) {
        const std::string name(value.primitive().name());
        ++histogram[name];
        if (dynamic_cast<const mx::AsType *>(&value.primitive()) &&
            value.dtype() == mx::float32 && value.inputs().size() == 1 &&
            (value.inputs()[0].dtype() == mx::float16 || value.inputs()[0].dtype() == mx::bfloat16))
          casts.push_back(value);
      }
      for (const auto &parent : value.inputs()) todo.push_back(parent);
    }
    static std::atomic<std::uint64_t> sequence{0};
    const char *label = std::getenv("HYLE_APPLE_DIAG_LABEL");
    std::ostringstream out;
    out << "{\"diagnostic_nonproduct\":true,\"sequence\":" << sequence.fetch_add(1)
        << ",\"program\":" << reinterpret_cast<std::uintptr_t>(program)
        << ",\"phase\":" << diagnostic_quote(phase)
        << ",\"label\":" << diagnostic_quote(label ? label : "unset")
        << ",\"reachable_arrays\":" << visited.size()
        << ",\"truncated\":" << (!todo.empty() ? "true" : "false") << ",\"inputs\":[";
    for (std::size_t i = 0; i < inputs.size(); ++i) { if (i) out << ','; diagnostic_array(out, inputs[i]); }
    out << "],\"casts\":[";
    for (std::size_t i = 0; i < casts.size(); ++i) {
      if (i) out << ',';
      out << "{\"output\":"; diagnostic_array(out, casts[i]);
      out << ",\"input\":"; diagnostic_array(out, casts[i].inputs()[0]); out << '}';
    }
    out << "],\"primitive_histogram\":{";
    bool comma = false;
    for (const auto &[name,count] : histogram) {
      if (comma) out << ',';
      out << diagnostic_quote(name.c_str()) << ':' << count; comma = true;
    }
    out << "}}";
    std::fprintf(stderr, "HYLE_MLX_GRAPH %s\n", out.str().c_str());
  } catch (...) { std::fprintf(stderr, "HYLE_MLX_GRAPH_ERROR observer_exception\n"); }
}
'''
anchor='// Compile each maximal MLX region once.'
assert text.count(anchor)==1;text=text.replace(anchor,hook+'\n'+anchor)
anchor='  auto outputs = program.compiled(isolated);\n'
assert text.count(anchor)==1;text=text.replace(anchor,anchor+'  diagnostic_graph(&program, "cold_isolated", isolated, outputs);\n')
anchor='  outputs = program.compiled(inputs);\n'
assert text.count(anchor)==1;text=text.replace(anchor,anchor+'  diagnostic_graph(&program, "actual_before_eval", inputs, outputs);\n')
context=store(rel,text.encode());baseline=P/'baseline'/rel;baseline.parent.mkdir(parents=True,exist_ok=True);baseline.write_bytes(original)
(P/'diagnostic-context.diff').write_text(''.join(difflib.unified_diff(original.decode().splitlines(True),text.splitlines(True),fromfile=rel,tofile='diagnostic/'+rel)))

rel='tests/graph_route_apple/glm_flash_mixed_mlx_test.cc';original=Path(rel).read_bytes();text=original.decode()
text=text.replace('#include "hyle/graph/apple.h"','#include "hyle/graph/apple.h"\n#include "../../src/compute_route_apple/apple_weights_internal.h"\n#include <cstdio>\n#include <cstdlib>\n#include <string>')
text=text.replace('  f::g::ExecutionSource source;',r'''  f::g::ExecutionSource source;
  struct Generation { const void *owner = nullptr; unsigned accepted = 0; };
  std::array<Generation,2> generations{};
  unsigned binding_sequence = 0;''')
old='    return slots.upload_slices(slot, slices);'
new=r'''    auto result = slots.upload_slices(slot, slices);
    if (result) {
      auto binding = f::take(a::detail::WeightAccess::binding(*result,slices.front().id),"diagnostic owner identity");
      generations[slot].owner = binding.owner.get();
      ++generations[slot].accepted;
      std::fprintf(stderr,"HYLE_MLX_EVENT {\"event\":\"accepted_upload\",\"slot\":%zu,\"accepted_generation_ordinal\":%u}\n",slot,generations[slot].accepted);
    }
    return result;'''
assert text.count(old)==1;text=text.replace(old,new)
old='    return f::g::apple::bind(invocation, bindings, batch);'
new=r'''    auto binding = f::take(a::detail::WeightAccess::binding(batch,bindings.front().id),"diagnostic bound generation");
    unsigned selected = 2;
    for (unsigned i=0;i<2;++i) if (generations[i].owner==binding.owner.get()) selected=i;
    if (selected==2) return hyle::Status::Internal("diagnostic lost original upload generation");
    const auto label=std::string("dynamic.slot")+std::to_string(selected)+".generation"+
        std::to_string(generations[selected].accepted)+".bind"+std::to_string(++binding_sequence);
    ::setenv("HYLE_APPLE_DIAG_LABEL",label.c_str(),1);
    std::fprintf(stderr,"HYLE_MLX_EVENT {\"event\":\"bind_label\",\"label\":\"%s\"}\n",label.c_str());
    return f::g::apple::bind(invocation, bindings, batch);'''
assert text.count(old)==1;text=text.replace(old,new)
anchor='    return f::g::compile(graph, {domains, targets});'
assert text.count(anchor)==1;text=text.replace(anchor,'    ::setenv("HYLE_APPLE_DIAG_LABEL","dynamic.cold.compile",1);\n'+anchor)
text+=r'''

// VALIDATION-ONLY tiny Graph constants comparison; no product/operator changes.
TEST(AppleImmutableMetadataDiagnostic, GraphConstantsKeepMetadataReadyAcrossThreeSubmissions) {
  run_apple([](auto &api) {
    namespace x=glm_flash_mixed_mlx_test;
    constexpr std::int64_t n=8,k=64;
    auto builder=f::take(f::g::GraphBuilder::create(),"diagnostic constant graph");
    const auto ad=f::dense(f::Type::kBFloat16,{1,k});
    const auto wd=f::dense(f::Type::kUInt32,{n,k/8});
    const auto sd=f::dense(f::Type::kFloat16,{n,1});
    const auto input=f::take(builder.input(ad),"BF16 activation");
    const std::array ids{f::take(builder.constant(wd),"constant packed W"),
        f::take(builder.constant(sd),"constant original F16 SF"),
        f::take(builder.constant(sd),"constant original F16 bias")};
    std::vector<std::uint32_t> codes(std::size_t(n*k),1U);
    for(std::int64_t row=0;row<n;++row)codes[std::size_t(row*k)]=unsigned(2+row%3);
    auto packed=mlx_affine_test::pack(codes,std::size_t(n),std::size_t(k),4);
    std::vector<std::uint16_t> scales(std::size_t(n),std::uint16_t{0}),biases(scales.size());
    for(std::int64_t row=0;row<n;++row){scales[std::size_t(row)]=x::scale_bits(0,11,row,0,0);biases[std::size_t(row)]=scales[std::size_t(row)]^0x8000U;}
    const auto output=f::take(builder.add(f::c::model_ops::mlx_quantized_matmul(
        f::c::model_ops::MlxWeightFormat::kAffine,4,64),input,ids[0],ids[1],ids[2]),"original affine op");
    f::check(builder.publish(output),"publish constant control");
    const auto graph=f::take(std::move(builder).finish(),"constant control finish");
    const std::array desc{wd,sd,sd};
    const std::array payload{f::raw(packed),f::raw(scales),f::raw(biases)};
    std::array<f::m::Buffer,3> buffers;
    std::array<f::g::ConstantBinding,3> constants;
    for(std::size_t i=0;i<3;++i){
      buffers[i]=f::take(f::m::Buffer::create(api.resource,payload[i].size(),256),"constant bytes");
      f::check(api.write(buffers[i].view(),payload[i]),"write constant original bytes");
      constants[i]={ids[i],f::take(f::c::ConstTensorView::create(desc[i],buffers[i].view()),"constant typed bytes"),f::g::ConstantPolicy::kMaterialize};
    }
    const std::array domains{f::g::StorageDomain{api.resource}};
    const std::array targets{f::g::ExecutionTarget{api.source,f::g::StorageDomainId{0}}};
    ::setenv("HYLE_APPLE_DIAG_LABEL","constants.cold.compile",1);
    auto compiled=f::take(f::g::compile(graph,{domains,targets},{.constants=constants}),"constant control compile");
    auto invocation=f::take(compiled.executable.create_invocation({.resources=f::g::ResourceOptions{}}),"constant control invocation");
    auto activation=f::take(f::m::Buffer::create(api.resource,ad.required_bytes().value(),256),"dynamic BF16 control A");
    f::check(invocation.bind(input,f::take(f::c::ConstTensorView::create(ad,activation.view()),"control A")),"bind control A");
    f::c::LeasePool pool;
    if(f::take(compiled.executable.output_ownership(),"control ownership")==f::g::OutputOwnership::kCaller){
      const auto od=f::take(graph.value_description(output),"control output description");
      pool=f::take(f::c::LeasePool::create(api.resource,256,{.max_blocks=1}),"control output pool");
      f::check(invocation.bind(output,od,f::take(pool.allocate(od.required_bytes().value()),"control writer")),"bind control writer");
    }
    f::check(api.prepare(invocation),"prepare control");
    for(unsigned phase=0;phase<3;++phase){
      const auto label=std::string("constants.phase")+std::to_string(phase);
      ::setenv("HYLE_APPLE_DIAG_LABEL",label.c_str(),1);
      std::vector<std::uint16_t> values(std::size_t(k),0U);
      const float a_value=phase==0?.5F:phase==1?1.F:2.F;
      values[0]=x::nv::bf16(a_value);
      f::check(api.write(activation.view(),std::as_bytes(std::span(values))),"update control A");
      auto done=f::take(invocation.submit(api.queues),"control submit");f::check(done.wait(),"control completed");
      auto result=f::take(invocation.result(output),"control result");
      const auto actual=ga_indexer_state_test::read_result<float>(result,[&](f::m::ConstBufferView from,std::span<std::byte> to){return api.read(from,to);});
      ASSERT_EQ(actual.size(),std::size_t(n));
      for(std::int64_t row=0;row<n;++row)EXPECT_EQ(actual[std::size_t(row)],
          (float(codes[std::size_t(row*k)])-1.F)*x::half(scales[std::size_t(row)])*a_value);
    }
    ::testing::Test::RecordProperty("successful_submissions",3);
    ::testing::Test::RecordProperty("scope","tiny Graph compile constants;BF16 A/F16 SF+bias;original GLM SF bit pattern;3 actual dynamic A submits");
  });
}
'''
wrapper=store(rel,text.encode());baseline=P/'baseline'/rel;baseline.parent.mkdir(parents=True,exist_ok=True);baseline.write_bytes(original)
(P/'diagnostic-wrapper.diff').write_text(''.join(difflib.unified_diff(original.decode().splitlines(True),text.splitlines(True),fromfile=rel,tofile='diagnostic/'+rel)))
manifest=dict(status='validation_only_nonproduct_sources_no_build_yet',overrides=[dict(canonical=identity(Path(rel)),diagnostic=identity(wrapper)),
    dict(canonical=identity(Path('src/compute_route_apple/apple_context.cc')),diagnostic=identity(context))],
    scope='Observe reachable native graph after compiled(inputs), before evaluation; no compile-mode change, payload read, native dispatch interceptor or retained array cache.')
(P/'diagnostic-source-freeze.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps(manifest,indent=2))
