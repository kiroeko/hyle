from pathlib import Path
import importlib.util
import shutil
import subprocess
import sys
import zipfile

sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent
R=W.parents[1]
spec=importlib.util.spec_from_file_location('build',W/'build.py')
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
read,save,pin,exact,key=b.read,b.save,b.pin,b.exact,b.key

def prepare():
    p,a=read(W/'plan.json'),read(W/'analysis.json')
    failed=read(W/'runs/warm-cohort/unguarded/report.json')
    passed=read(W/'runs/warm-cohort/restored/report.json')
    assert failed['status']=='EXPECTED_UNSAFE_HINT_REGRESSION'
    assert passed['status']=='PASS' and passed['complete_state_epoch_rng_ledger_equal']
    assert passed['actual_r2_imported_slots']==3 and passed['fresh_r1_imported_prior_uses']==[0,0,0]
    assert passed['first_survivor_slot_uses']==1 and passed['first_survivor_capture_recorded']>0
    assert passed['all_source_session_owners_retired'] and passed['final_live_versions']==0
    assert not subprocess.check_output(['git','diff','--','engine/models/qwen35/main.cc'],cwd=R)
    assert (W/'baseline-main.cc').read_bytes()==(R/'engine/models/qwen35/main.cc').read_bytes()
    receipt_path=W/'compile/warm-cohort/receipt.json'
    receipt=read(receipt_path)
    for item in [receipt['object'],*receipt['source_identities'],*p['retained']]:exact(item)
    base=read(p['base']['path'])
    base.update(schema='hyle.warm-boundary.current-link-base.v1',base=p['base'],
        current_consumers={**base['current_consumers'],'warm-cohort':dict(receipt=pin(receipt_path),object=receipt['object'])},
        note='Product warm-reset strategy unchanged; only restored-strategy warm-cohort probe is a new current consumer. Rejected candidate object is not a product input.')
    save(W/'model-link-base.json',base)
    processes=[dict(folder=path.parent.relative_to(W).as_posix(),**read(path))
        for path in sorted((W/'runs').rglob('process.json'))]
    assert len(processes)==24 and all(x['state']=='TERMINAL' and not x['timed_out'] for x in processes)
    assert [x['folder'] for x in processes if x['exit']!=0]==['runs/warm-cohort/unguarded']
    a.update(regression=dict(unsafe_candidate=pin(W/'runs/warm-cohort/unguarded/report.json'),
        restored_strategy=pin(W/'runs/warm-cohort/restored/report.json'),
        original_product_strategy_restored_exactly=True),processes=processes,
        native_processes=24,expected_failed_candidate_processes=1,
        consumer_CXX_invocations=3,retained_SDK_engine_objects=227)
    save(W/'analysis.json',a)
    targets=[pin(path) for path in sorted((W/'bin').iterdir())]
    assert len(targets)==10 and all(Path(x['path']).suffix.lower() in ('.exe','.dll','.lib','.exp') for x in targets)
    save(W/'cleanup-targets.json',dict(boundary=str(W/'bin'),targets=targets))
    (W/'product.diff').write_bytes(subprocess.check_output(['git','diff','--','tests/tools/qwen_generation_batch_relay_probe.cc'],cwd=R))
    print('Recorded rejected candidate, native cold-slot regression and16-process spelling A/A; product unchanged.')

def finish():
    p,a=read(W/'plan.json'),read(W/'analysis.json')
    cleanup=read(W/'cleanup-report.json')
    assert cleanup['status']=='REMOVED_EXACT_FLAT_BATCH_IMAGES'
    shutil.copyfile(R/'test.ps1',W/'cleanup.ps1')
    out=R/'docs/evidence/performance/inference-warm-boundary-aa-2026-10-30.json'
    save(out,dict(schema='hyle.performance.warm-boundary-aa.v1',date='2026-10-30',base_commit=p['base_commit'],
        status='CANDIDATE_REJECTED_NATIVE_REGRESSION_RETAINED_AND_FINITE_AA_COMPLETED',
        decision='Keep original product reset strategy; no demonstrated gain and a reproduced fresh-slot Queue failure.',
        checks=a,contract=dict(warm='Direction/count hints do not grant authority, but their reset currently prevents premature pending-source binding on fresh Graph Queue state.',
            regression='One actual warmed R2 cohort, serial cancellation oracle, then same-continuation cancellation into fresh R1; all original Sources/leases/retirement remain real.',
            future='Any reduced warm-up must prove concrete selected-slot preparation and retain original full tuple/capture/Queue checks; do not swallow InvalidArgument.',
            conditional='Native If probe is not MTP support. Executed/Skipped outcome must be checked before observer/publication; skipped Store writer recovery is not permission to publish; undecided conditional Source cannot feed C.'),
        source_files=[pin(R/'tests/tools/qwen_generation_batch_relay_probe.cc'),pin(R/'engine/models/qwen35/main.cc')],
        cleanup=cleanup,retained_build_plan=pin(W/'model-link-base.json'),archive='inference-warm-boundary-aa-2026-10-30.zip'))
    files=[W/x for x in ('build.py','analyze.py','finish.py','analysis.json','product.diff','unguarded-main.cc',
        'baseline-main.cc','unguarded-screen.json','unguarded-non-timing-differences.json','single-turn.txt',
        'cleanup.ps1','cleanup-targets.json','cleanup-report.json')]
    for prefix in ('runs','compile','link'):
        files.extend(x for x in (W/prefix).rglob('*') if x.is_file() and x.suffix.lower() in ('.json','.log'))
    with zipfile.ZipFile(out.with_suffix('.zip'),'w',zipfile.ZIP_DEFLATED) as archive:
        for path in sorted(set(files)):archive.write(path,path.relative_to(W).as_posix())
    print('Saved rejected candidate and A/A evidence; latest complete peer table unchanged.')

if __name__=='__main__':{'prepare':prepare,'finish':finish}[sys.argv[1]]()
