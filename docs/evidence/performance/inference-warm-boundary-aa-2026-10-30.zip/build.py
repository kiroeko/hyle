"""One current consumer, retained same-ABI SDK, finite continuation experiment."""
from pathlib import Path
import importlib.util
import os
import shutil
import sys

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = W.parents[1]
spec = importlib.util.spec_from_file_location('source_build', R / '.scratch/inference-source-binding-20261030/build.py')
s = importlib.util.module_from_spec(spec)
spec.loader.exec_module(s)
s.W = s.b.W = W
read, save, pin, exact, key = s.read, s.save, s.pin, s.exact, s.key
BASE = R / '.scratch/inference-effect-domains-20261030/model-link-base.json'

def prepare():
    assert not (W / 'plan.json').exists()
    base = read(BASE)
    for item in [*base['retained'], base['runtime']]: exact(item)
    prior = read(base['current_consumers']['cli']['receipt']['path'])
    for item in [prior['object'], *prior['source_identities']]: exact(item)
    source = W / 'cli.cc'
    source.write_text('#include "../../engine/models/qwen35/main.cc"\nint main(int argc,char **argv){return qwen35::run(argc,argv);}\n')
    history = read(R / '.scratch/inference-continuation-warmth-20261030/plan.json')
    (W / 'bin').mkdir(exist_ok=True)
    shutil.copyfile(base['runtime']['path'], W / 'bin' / Path(base['runtime']['path']).name)
    shutil.copyfile(R / 'engine/models/qwen35/main.cc', W / 'baseline-main.cc')
    save(W / 'plan.json', dict(base=pin(BASE), base_commit='04cf45eb7', retained=base['retained'],
        runtime=base['runtime'], sdk=base['sdk_engine_dependencies'], baseline=prior['object'],
        original_link=base['link'], original_consumer=prior['object']['path'],
        units={}, consumers={'candidate':dict(source=str(source),compile=s.relocated(base['compile'],'candidate',source))},
        args=history['args'], two_turn_args=history['two_turn_args'],
        SDK_CXX=0,NVCC=0,downloads=0,full_performance_window=False))
    print('Prepared current baseline and one candidate CXX;227 SDK inputs retained.')

def link(name,attempt):
    p = read(W / 'plan.json')
    obj = p['baseline'] if name == 'control' else read(W / 'compile' / ('warm-cohort' if name=='probe' else 'candidate') / 'receipt.json')['object']
    for item in [obj, *p['retained']]: exact(item)
    args=[]
    for arg in p['original_link']:
        if key(arg)==key(p['original_consumer']): arg=obj['path']
        for prefix,suffix in [('/OUT:','.exe'),('/PDB:','.pdb'),('/IMPLIB:','.lib'),('/MAP:','.map')]:
            if arg.upper().startswith(prefix): arg=prefix+str((W / 'bin' / name).with_suffix(suffix));break
        args.append(arg)
    s.b.execute(args,W / 'link' / name / attempt,240)
    save(W / ('ready-'+name+'.json'),pin(W / 'bin' / (name+'.exe')))

def run(name,attempt,scenario):
    p=read(W / 'plan.json');image=read(W / ('ready-'+name+'.json'));exact(image)
    args=list(p['two_turn_args'] if 'two' in scenario else p['args'])
    if 'single-schedule' in scenario:
        schedule=W / 'single-turn.txt'
        if not schedule.exists():
            prompt=Path(args[args.index('--inputs')+1]) / 'prompt.ids'
            schedule.write_text('prompt "'+prompt.as_posix()+'"\ngenerate 64\n')
        at=args.index('--steps');args[at:at+2]=['--schedule',str(schedule)]
    if 'ordinary' in scenario:
        args[args.index('--mtp')+1]='off';at=args.index('--mtp-max-drafts');del args[at:at+2]
    os.environ.update(HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',HF_DATASETS_OFFLINE='1')
    folder=W / 'runs' / scenario / name / attempt
    save(folder / 'image.json',image)
    s.b.execute([image['path'],*args],folder,300)
    result=read(folder / 'stdout.log')
    assert result['generated_tokens']==(128 if 'two' in scenario else 64)
    assert result['live_committed_versions']==0
    save(folder / 'report.json',result)
    print('PASS',name,scenario,'generated',result['generated_tokens'])

def add_probe():
    p=read(W / 'plan.json');base=read(p['base']['path'])
    source=R / 'tests/tools/qwen_generation_batch_relay_probe.cc'
    p['consumers']['warm-cohort']=dict(source=str(source),compile=s.relocated(base['compile'],'warm-cohort',source))
    save(W / 'plan.json',p)

def probe(attempt,expected_failure):
    image=read(W / 'ready-probe.json');exact(image)
    folder=W / 'runs/warm-cohort' / attempt
    args=[image['path'],'--warm-cohort',str(R / '.scratch/inference-continuous-wave-20261027/inputs/context32')]
    save(folder / 'image.json',image)
    try:s.b.execute(args,folder,300)
    except SystemExit as error:
        if not expected_failure or error.code!=1:raise
    else:assert not expected_failure,'Unsafe warm-hint candidate unexpectedly passed the specific regression.'
    if expected_failure:
        message=(folder / 'stderr.log').read_text()
        assert "pending captured outputs require the producer's actual Queue" in message,message[-1500:]
        save(folder / 'report.json',dict(status='EXPECTED_UNSAFE_HINT_REGRESSION',exit=1,
            reason="pending captured outputs require the producer's actual Queue"))
    else:
        result=read(folder / 'stdout.log');assert result['status']=='PASS'
        save(folder / 'report.json',result)
    print('Observed expected regression' if expected_failure else 'PASS warm-cohort boundary')

if __name__=='__main__':
    action=sys.argv[1]
    if action=='prepare':prepare()
    elif action=='compile':s.compile_one('candidate',sys.argv[2])
    elif action=='add-probe':add_probe()
    elif action=='compile-probe':s.compile_one('warm-cohort',sys.argv[2])
    elif action=='probe':probe(sys.argv[2],sys.argv[3]=='failure')
    elif action=='link':link(sys.argv[2],sys.argv[3])
    elif action=='run':run(sys.argv[2],sys.argv[3],sys.argv[4])
    elif action=='screen':
        for index,name in enumerate(('control','candidate','candidate','control'),1):
            run(name,'abba-'+str(index),sys.argv[2])
    elif action=='aa':
        mode=sys.argv[2]
        for index,kind in enumerate(('steps','schedule','schedule','steps','schedule','steps','steps','schedule'),1):
            scenario=('ordinary-' if mode=='ordinary' else '')+('single-schedule' if kind=='schedule' else 'single')
            run('control','aa-'+mode+'-'+str(index),scenario)
    else:raise ValueError(action)
