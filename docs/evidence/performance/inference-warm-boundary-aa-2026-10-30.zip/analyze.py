from pathlib import Path
import importlib.util
import statistics
import sys

sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('build',W/'build.py')
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
read,save,pin=b.read,b.save,b.pin

def stable(value):
    if isinstance(value,dict):
        return {k:stable(v) for k,v in value.items() if not k.endswith('_seconds') and not k.endswith('_per_second')}
    if isinstance(value,list):return [stable(x) for x in value]
    return value

def differences(a,b,path='$'):
    if type(a)!=type(b):return [dict(path=path,type_changed=True)]
    if isinstance(a,dict):
        rows=[]
        for key in sorted(a.keys()|b.keys()):
            if key not in a or key not in b:rows.append(dict(path=path+'.'+key,key_presence_changed=True))
            else:rows.extend(differences(a[key],b[key],path+'.'+key))
        return rows
    if isinstance(a,list):
        if len(a)!=len(b):return [dict(path=path,lengths=[len(a),len(b)])]
        return [row for index,(x,y) in enumerate(zip(a,b)) for row in differences(x,y,path+'['+str(index)+']')]
    return [] if a==b else [dict(path=path,before=a,after=b)]

def aa(mode):
    samples=[]
    for index,kind in enumerate(('steps','schedule','schedule','steps','schedule','steps','steps','schedule'),1):
        scenario=('ordinary-' if mode=='ordinary' else '')+('single-schedule' if kind=='schedule' else 'single')
        folder=W/'runs'/scenario/'control'/('aa-'+mode+'-'+str(index))
        report=read(folder/'report.json')
        samples.append(dict(index=index,kind=kind,report=pin(folder/'report.json'),
            process=read(folder/'process.json'),data=report))
    reference=stable(samples[0]['data'])
    deviations=[dict(sample=x['index'],differences=differences(reference,stable(x['data'])))
        for x in samples if stable(x['data'])!=reference]
    assert not deviations,deviations[:1]
    summary={}
    for kind in ('steps','schedule'):
        rows=[x['data'] for x in samples if x['kind']==kind]
        summary[kind]={field:dict(median=statistics.median(row[field] for row in rows),
            minimum=min(row[field] for row in rows),maximum=max(row[field] for row in rows))
            for field in ('prefill_tokens_per_second','decode_output_tokens_per_second','output_tokens_per_second','decode_seconds')}
    ratios=[]
    for index in range(0,8,2):
        pair={x['kind']:x['data'] for x in samples[index:index+2]}
        ratios.append(pair['schedule']['decode_output_tokens_per_second']/pair['steps']['decode_output_tokens_per_second'])
    return dict(mode=mode,samples_per_arm=4,all_non_timing_fields_identical=True,
        order=[x['kind'] for x in samples],summary=summary,adjacent_decode_schedule_over_steps=ratios,
        samples=[{k:v for k,v in x.items() if k!='data'} for x in samples],
        limits=['One frozen current Hyle CLI and one-turn P154+64; no llama.cpp, GPU trace or physical memory sample.',
            'Four processes per spelling diagnose this current workload; no statistical equivalence or sub-percent speed claim.',
            'Does not reproduce the additional shape/workspace of the two-turn process; cannot exclude that separate memory-placement hypothesis.'])

def main():
    reports={mode:aa(mode) for mode in ('ordinary','mtp')}
    control=read(W/'runs/two-turn/control/baseline/report.json')
    candidate=read(W/'runs/two-turn/candidate/first/report.json')
    diff=differences(stable(control),stable(candidate))
    save(W/'unguarded-non-timing-differences.json',diff)
    samples=read(W/'unguarded-screen.json')
    medians={name:statistics.median(x['decode_tps'] for x in samples if x['arm']==name) for name in ('control','candidate')}
    save(W/'analysis.json',dict(status='REJECT_UNGUARDED_WARM_HINT_CANDIDATE_AND_COMPLETE_FINITE_AA',
        aa=reports,unguarded_candidate=dict(order=[x['arm'] for x in samples],samples=samples,
            median_decode_tps=medians,relative_change=medians['candidate']/medians['control']-1,
            decision='Not retained: no demonstrated speed gain, one additional discarded successor and two additional target/draft rows; fresh-slot Queue correctness hazard.',
            original_non_timing_differences=pin(W/'unguarded-non-timing-differences.json')),
        latest_complete_peer_window_unchanged=True,performance_improvement_claim=False,downloads=0,SDK_CXX=0,NVCC=0))
    for mode,result in reports.items():
        print(mode,'all non-time fields identical; decode medians',
            {kind:round(values['decode_output_tokens_per_second']['median'],4) for kind,values in result['summary'].items()},
            'adjacent ratios',[round(x,5) for x in result['adjacent_decode_schedule_over_steps']])
    print('Candidate non-time differences:',len(diff),'paths; ABBA change',medians['candidate']/medians['control']-1)

if __name__=='__main__':main()
