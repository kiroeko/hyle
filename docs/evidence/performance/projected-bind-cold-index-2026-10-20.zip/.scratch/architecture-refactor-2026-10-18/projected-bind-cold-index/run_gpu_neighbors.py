"""One unchanged GPU route family through the freshly linked common Plan."""
import importlib.util
from pathlib import Path
import sys
import xml.etree.ElementTree as ET
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('index_gpu_helpers',S/'build.py')
h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
b,c=h.b,h.c
out=S/'gpu-neighbors';out.mkdir(exist_ok=False);(out/'tmp').mkdir()
base=S/'checks/host1';image=c.read(base/'tests-image.json');assert b.same(image)
link=c.read(base/'tests-link-plan.json');env,runtime=b.environment(link['command'],[r['path'] for r in link['inputs']],out)
filters=['GgmlCudaPairedProjection.*'];c.save(out/'inputs.json',dict(image=image,filters=filters,expected_cases=5,runtime=runtime))
try:c.execute('tests',[image['path'],'--gtest_filter='+':'.join(filters),'--gtest_output=xml:'+str(out/'results.xml')],env,out)
finally:
    cases=ET.parse(out/'results.xml').findall('.//testcase') if (out/'results.xml').exists() else []
    failures=[dict(name=r.attrib['classname']+'.'+r.attrib['name'],details=[f.text for f in r.findall('failure')]) for r in cases if r.find('failure') is not None]
    skipped=sum(r.find('skipped') is not None for r in cases)
    passed=len(cases)==5 and not failures and not skipped
    c.save(out/'summary.json',dict(passed=passed,cases=len(cases),skipped=skipped,failures=failures,image=image,
        actual=[r.attrib['classname']+'.'+r.attrib['name'] for r in cases]))
assert passed
print('PROJECTED_INDEX_GPU_NEIGHBORS',len(cases),'passed',flush=True)
