"""Seal current product delta and actual relevant regressions before cleanup."""
import hashlib
import json
from pathlib import Path
import zipfile
S=Path(__file__).resolve().parent;A=S.parent;ROOT=S.parents[2];review=A/'cross-platform-followup'
def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def identity(p):
    p=Path(p).resolve();return dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def save(p,v):Path(p).write_text(json.dumps(v,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
freeze=read(review/'product-source-freeze.json')
for row in freeze['files']:
    assert identity(ROOT/row['path'])['sha256']==row['after_sha256']
    assert identity(ROOT/row['snapshot'])['sha256']==row['after_sha256']
tests=read(S/'tests-final/summary.json');gpu=read(S/'gpu-neighbors/summary.json');model=read(S/'correctness/summary.json')
assert tests['passed'] and tests['cases']==20 and gpu['passed'] and gpu['cases']==5 and model['passed']
assert (review/'independent-review.json').is_file()
files=[p for stage in (S,review) for p in stage.rglob('*') if p.is_file() and
       p.suffix.lower() in ('.py','.cc','.h','.json','.log','.xml','.diff','.ps1') and 'tmp' not in p.parts]
files += [ROOT/'test.ps1'];rows=[]
destination=ROOT/'docs/evidence/performance/projected-bind-cold-index-2026-10-20.zip'
with zipfile.ZipFile(destination,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as archive:
    for p in files:
        row=identity(p);row['member']=str(p.relative_to(ROOT)).replace('\\','/');rows.append(row)
        archive.writestr(row['member'],p.read_bytes())
    archive.writestr('payload-sha256.json',json.dumps(rows,indent=2))
with zipfile.ZipFile(destination) as archive:
    assert archive.testzip() is None
    for row in rows:
        payload=archive.read(row['member']);assert len(payload)==row['bytes'] and hashlib.sha256(payload).hexdigest()==row['sha256']
body=dict(date='2026-10-20',scope='Common Graph strict projected/row-input topology admission; actual Windows CPU and CUDA regressions, no new throughput test.',
    change=read(review/'review.json'),source_freeze=freeze,independent_review=read(review/'independent-review.json'),
    build=read(S/'checks/host1/summary.json'),actual_images={arm:read(S/'checks/host1'/(arm+'-image.json')) for arm in ('cpu','tests','qwen')},
    CPU_tests=tests,CUDA_neighbors=gpu,model=dict(passed=model['passed'],equal_vectors=model['observation']['equal_vectors'],
        single_outer_range_32_phases=model['single_outer_range_32_phases'],quality_acceptance=False,throughput_claim=False),
    archive=identity(destination),payloads=rows,archive_verified=dict(CRC=True,all_payload_SHA256=True),
    cleanup=dict(prepared=read(S/'cleanup-plan.json'),executed=False),
    limits=['Static topology scan complexity was removed; whole-bind/page/lease checks retain their live costs.',
        'No new throughput, model-quality, Linux/macOS runtime or overall architecture-completion claim.',
        'Private PlanState ABI owners were refreshed only for the actual three linked images; all SDK/native kernels and consumer main were reused.'])
save(destination.with_suffix('.json'),body)
print('PROJECTED_INDEX_PUBLISHED',len(rows),destination.stat().st_size,flush=True)
