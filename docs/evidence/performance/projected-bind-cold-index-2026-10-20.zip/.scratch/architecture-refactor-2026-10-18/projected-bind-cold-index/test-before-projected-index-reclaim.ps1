# Exact rebuildable targets for the completed paired projection / common contraction batch.
# This script is single-use. Read cleanup-plan.json for every target and retained owner.
$ErrorActionPreference = 'Stop'
$taskRoot = (Resolve-Path -LiteralPath $PSScriptRoot).Path
$taskPlan = Get-Content -LiteralPath 'C:\public\project-hyle\hyle\.scratch\architecture-refactor-2026-10-18\paired-projection-route\cleanup-plan.json' -Encoding utf8 -Raw | ConvertFrom-Json
foreach ($taskTarget in $taskPlan.targets) {
  $taskResolved = (Resolve-Path -LiteralPath $taskTarget.path).Path
  if (-not $taskResolved.StartsWith($taskRoot + [IO.Path]::DirectorySeparatorChar, [StringComparison]::OrdinalIgnoreCase)) { throw 'Target escapes repository' }
  $taskFile = Get-Item -LiteralPath $taskResolved
  if ($taskFile.PSIsContainer -or $taskFile.Length -ne $taskTarget.bytes) { throw ('Target identity differs: ' + $taskResolved) }
  if ((Get-FileHash -LiteralPath $taskResolved -Algorithm SHA256).Hash.ToLowerInvariant() -ne $taskTarget.sha256) { throw ('Target hash differs: ' + $taskResolved) }
}
foreach ($taskProtected in $taskPlan.protected) {
  $taskKeep = Get-Item -LiteralPath $taskProtected.path
  if ($taskKeep.Length -ne $taskProtected.bytes -or (Get-FileHash -LiteralPath $taskProtected.path -Algorithm SHA256).Hash.ToLowerInvariant() -ne $taskProtected.sha256) { throw ('Retained input differs: ' + $taskProtected.path) }
}
foreach ($taskTarget in $taskPlan.targets) { Remove-Item -LiteralPath $taskTarget.path -Force }
[pscustomobject]@{executed=$true; files=$taskPlan.files; bytes=$taskPlan.bytes; finished_utc=[DateTime]::UtcNow.ToString('O'); targets=$taskPlan.targets} |
  ConvertTo-Json -Depth 8 | Set-Content -LiteralPath 'C:\public\project-hyle\hyle\.scratch\architecture-refactor-2026-10-18\paired-projection-route\cleanup-receipt.json' -Encoding utf8
Write-Output ('RECLAIMED ' + $taskPlan.files + ' files, ' + $taskPlan.bytes + ' bytes')
