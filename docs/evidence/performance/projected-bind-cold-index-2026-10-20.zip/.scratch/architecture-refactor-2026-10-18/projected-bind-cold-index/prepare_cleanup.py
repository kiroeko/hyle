"""Write exact guarded deletions to repository test.ps1; do not delete here."""
import hashlib
import json
from pathlib import Path
import shutil
S=Path(__file__).resolve().parent;A=S.parent;ROOT=S.parents[2]
def read(p):return json.loads(Path(p).read_text(encoding='utf-8'))
def identity(p):
    p=Path(p).resolve();return dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def save(p,v):Path(p).write_text(json.dumps(v,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
for p in [S/'tests-final/summary.json',S/'gpu-neighbors/summary.json',S/'correctness/summary.json']:
    assert read(p)['passed']
targets=[]
for stage,names in [('quant-route-followup/checks/host1',['qwen']),('paired-projection-route/checks/native1',['cpu','tests'])]:
    for name in names:
        for suffix in ('.exe','.map','.lib','.exp'):
            p=A/stage/(name+suffix)
            if p.is_file():targets.append(identity(p))
original=A/'batch-graph-capture/correctness-final/trace';duplicate=S/'correctness/trace';vectors=[]
for p in sorted(duplicate.rglob('*')):
    if p.suffix not in ('.bf16','.f32'):continue
    reference=original/p.relative_to(duplicate);actual=identity(p);accepted=identity(reference)
    assert actual['bytes']==accepted['bytes'] and actual['sha256']==accepted['sha256']
    targets.append(actual);vectors.append(dict(duplicate=actual,accepted=accepted))
assert len(vectors)==64
protected=[identity(S/'checks/host1'/(arm+'.exe')) for arm in ('cpu','tests','qwen')]
protected += [identity(A/'paired-projection-route/checks/native1/qwen.exe'),
              identity(A/'cuda-explicit-rope/performance-prepared/peer.exe')]
protected += [row['accepted'] for row in vectors]
target_paths={row['path'].casefold() for row in targets}
assert not any(row['path'].casefold() in target_paths for row in protected)
script=ROOT/'test.ps1';backup=S/'test-before-projected-index-reclaim.ps1'
if not backup.exists():shutil.copy2(script,backup)
text=r'''$ErrorActionPreference = 'Stop'
$taskRoot = (Resolve-Path -LiteralPath $PSScriptRoot).Path
$taskStage = Join-Path $taskRoot '.scratch\architecture-refactor-2026-10-18\projected-bind-cold-index'
$taskPlan = Get-Content -LiteralPath (Join-Path $taskStage 'cleanup-plan.json') -Raw | ConvertFrom-Json
if ($taskRoot -ne $taskPlan.root) { throw 'Unexpected repository root' }
if ((Get-FileHash -LiteralPath $PSCommandPath -Algorithm SHA256).Hash -ne $taskPlan.script.sha256) { throw 'Cleanup script changed' }
foreach ($taskFile in @($taskPlan.targets) + @($taskPlan.protected)) {
    $taskPath = [IO.Path]::GetFullPath($taskFile.path)
    if (-not $taskPath.StartsWith($taskRoot + '\', [StringComparison]::OrdinalIgnoreCase)) { throw 'Cleanup path outside repository' }
    $taskItem = Get-Item -LiteralPath $taskPath
    if ($taskItem.PSIsContainer -or $taskItem.Length -ne $taskFile.bytes) { throw 'Cleanup target size/type changed' }
    if ((Get-FileHash -LiteralPath $taskPath -Algorithm SHA256).Hash -ne $taskFile.sha256) { throw 'Cleanup target content changed' }
}
$taskReportPath = Join-Path $taskRoot 'docs\evidence\performance\projected-bind-cold-index-2026-10-20.json'
$taskReport = Get-Content -LiteralPath $taskReportPath -Raw | ConvertFrom-Json
if (-not $taskReport.archive_verified.CRC -or -not $taskReport.archive_verified.all_payload_SHA256) { throw 'Evidence archive not verified' }
if ((Get-FileHash -LiteralPath $taskReport.archive.path -Algorithm SHA256).Hash -ne $taskReport.archive.sha256) { throw 'Evidence archive changed' }
$taskRemoved = @()
foreach ($taskFile in $taskPlan.targets) {
    Remove-Item -LiteralPath $taskFile.path -Force
    $taskRemoved += [PSCustomObject]@{path=$taskFile.path;bytes=$taskFile.bytes;sha256=$taskFile.sha256}
}
$taskReceipt = [PSCustomObject]@{executed_utc=[DateTime]::UtcNow.ToString('o');removed=$taskRemoved;removed_bytes=$taskPlan.removed_bytes;script_sha256=$taskPlan.script.sha256}
$taskReceipt | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath (Join-Path $taskStage 'cleanup-executed.json') -Encoding utf8
Write-Output ('PROJECTED_INDEX_CLEANED files=' + $taskRemoved.Count + ' bytes=' + $taskPlan.removed_bytes)
'''
script.write_text(text,encoding='utf-8')
save(S/'cleanup-plan.json',dict(root=str(ROOT),script=identity(script),targets=targets,protected=protected,vectors=vectors,
    removed_bytes=sum(row['bytes'] for row in targets),description='Superseded images and duplicate verified vectors only. Keep all objects/libraries, current three images, immediate paired baseline, peer and original64.'))
print('PROJECTED_INDEX_CLEANUP_PREPARED',len(targets),sum(row['bytes'] for row in targets),flush=True)
