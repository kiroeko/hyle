"""Refresh every actual owner of the changed private PlanState header only."""
import argparse
import concurrent.futures
import importlib.util
from pathlib import Path
import sys
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent; A=S.parent; ROOT=S.parents[2]
spec=importlib.util.spec_from_file_location('projection_index_helpers',A/'paired-projection-route/build.py')
h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
b,c=h.b,h.c

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--build',action='store_true');parser.add_argument('--resume',action='store_true')
    args=parser.parse_args();out=S/'checks/host1';out.mkdir(parents=True,exist_ok=True);(out/'tmp').mkdir(exist_ok=True)
    paths={arm:A/'paired-projection-route/checks/native1'/(arm+'-link-plan.json') for arm in ('cpu','tests','qwen')}
    bases={arm:c.read(path) for arm,path in paths.items()};meta=h.h.h.metadata(bases)
    header=ROOT/'src/graph/plan_state.h';target=c.key(header);owners={}
    for arm,base in bases.items():
        for obj in base['inputs']:
            owner=meta.get(c.key(obj['path']))
            if owner and any(c.key(dep['path'])==target for dep in owner.get('dependencies',[])):
                row=owners.setdefault(c.key(obj['path']),dict(owner=owner,old_object=obj,arms=[]))
                row['arms'].append(arm)
    expected={'input_sources.cc','resource_report.cc','progress.cc','resources.cc','executable.cc',
              'constant_artifact.cc','region_access.cc','submission.cc','constant_artifact_cache_test.cc','region_provider_test.cc'}
    assert {Path(row['owner']['source_path']).name for row in owners.values()}==expected
    rows=[]
    for i,row in enumerate(owners.values()):
        source=Path(row['owner']['source_path']);tag=f'{i:02d}-{source.parent.name}-{source.stem}'
        rows.append(dict(tag=tag,source=b.identity(source),old_object=row['old_object'],arms=row['arms'],
            object=str(out/(tag+'.obj')),command=b.host_command(row['owner']['command'],source,tag,out)))
    frozen=[b.identity(header),*[row['source'] for row in rows]]
    c.save(out/'plan.json',dict(compile=rows,base_paths={k:str(v) for k,v in paths.items()},frozen=frozen,
        host_TUs=len(rows),native_TUs=0,SDK_rebuild=False,main_reused=True,
        dependency_closure='Every actual baseline object whose compiler receipt names src/graph/plan_state.h'))
    print('PROJECTED_INDEX_PLAN',len(rows),flush=True)
    if not args.build:return
    def check():
        for row in frozen:assert b.same(row),row['path']
    for base in bases.values():
        for row in base['inputs']:assert b.same(row),row['path']
    env,runtime=b.environment(bases['qwen']['command'],[r['path'] for r in bases['qwen']['inputs']],out)
    c.save(out/'runtime-environment.json',dict(runtime=runtime,PATH=env['PATH']))
    def compile_one(row):
        check();receipt=out/(row['tag']+'-identity.json')
        if args.resume and receipt.exists():
            prior=c.read(receipt)
            if prior['command']==row['command'] and b.same(prior['object']) and all(b.same(x) for x in prior['dependencies']):
                print('REUSE',row['tag'],flush=True);return row['tag'],prior
        c.execute(row['tag']+'-compile',row['command'],env,out);check()
        dependencies=c.read(out/(row['tag']+'-deps.json'))['Data']
        identities=[b.identity(p) for p in dict.fromkeys([dependencies['Source'],*dependencies['Includes']])]
        result=dict(command=row['command'],source=row['source'],object=b.identity(row['object']),dependencies=identities)
        c.save(receipt,result);return row['tag'],result
    finished={};errors=[]
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
        for future in concurrent.futures.as_completed([pool.submit(compile_one,row) for row in rows]):
            try:
                tag,result=future.result();finished[tag]=result
            except Exception as error:errors.append(repr(error))
    c.save(out/'compile-summary.json',dict(passed=not errors,errors=errors))
    if errors:raise RuntimeError(errors)
    links={}
    for arm,base in bases.items():
        replacements={c.key(row['old_object']['path']):finished[row['tag']]['object'] for row in rows if arm in row['arms']}
        lookup={c.key(row['path']):row for row in base['inputs']};lookup.update({c.key(row['path']):row for row in replacements.values()})
        command=[replacements.get(c.key(arg),{}).get('path',arg) for arg in base['command']
                 if not arg.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:'))]
        image=out/(arm+'.exe');command+=['/OUT:'+str(image),'/MAP:'+str(image.with_suffix('.map')),'/IMPLIB:'+str(image.with_suffix('.lib'))]
        inputs=[lookup[c.key(arg)] for arg in command if Path(arg).is_absolute() and Path(arg).suffix.lower() in ('.obj','.lib')]
        assert len(inputs)==len({c.key(row['path']) for row in inputs})
        for row in inputs:assert b.same(row),row['path']
        check();plan=dict(command=command,inputs=inputs);old=out/(arm+'-link-plan.json');identity=out/(arm+'-image.json')
        reuse=args.resume and old.exists() and identity.exists() and c.read(old)==plan and b.same(c.read(identity))
        if reuse:print('REUSE_LINK',arm,flush=True)
        else:c.execute(arm+'-link',command,env,out)
        check();c.save(old,plan);c.save(identity,b.identity(image));links[arm]=dict(**plan,image=str(image))
    plan=c.read(out/'plan.json');plan['links']=links;c.save(out/'plan.json',plan)
    c.save(S/'latest-plan.json',dict(plan=str(out/'plan.json')))
    c.save(out/'summary.json',dict(passed=True,host_TUs=len(rows),native_TUs=0,SDK_rebuild=False,main_reused=True))
    print('PROJECTED_INDEX_BUILT',len(rows),flush=True)

if __name__=='__main__':main()
