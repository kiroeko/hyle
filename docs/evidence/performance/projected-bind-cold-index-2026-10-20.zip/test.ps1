$ErrorActionPreference = 'Stop'
$taskRoot = (Resolve-Path -LiteralPath $PSScriptRoot).Path
$taskStage = Join-Path $taskRoot '.scratch\architecture-refactor-2026-10-18\projected-bind-cold-index'
$taskPlan = Get-Content -LiteralPath (Join-Path $taskStage 'cleanup-plan.json') -Raw | ConvertFrom-Json
if ($taskRoot -ne $taskPlan.root) { throw 'Unexpected repository root' }
if ((Get-FileHash -LiteralPath $PSCommandPath -Algorithm SHA256).Hash -ne $taskPlan.script.sha256) { throw 'Cleanup script changed' }
foreach ($taskFile in @($taskPlan.targets) + @($taskPlan.protected)) {
    $taskPath = [IO.Path]::GetFullPath($taskFile.path)
    if (-not $taskPath.StartsWith($taskRoot + '\', [StringComparison]::OrdinalIgnoreCase)) { throw 'Cleanup path outside repository' }
    $taskItem = Get-Item -LiteralPath $taskPath
    if ($taskItem.PSIsContainer -or $taskItem.Length -ne $taskFile.bytes) { throw 'Cleanup target size/type changed' }
    if ((Get-FileHash -LiteralPath $taskPath -Algorithm SHA256).Hash -ne $taskFile.sha256) { throw 'Cleanup target content changed' }
}
$taskReportPath = Join-Path $taskRoot 'docs\evidence\performance\projected-bind-cold-index-2026-10-20.json'
$taskReport = Get-Content -LiteralPath $taskReportPath -Raw | ConvertFrom-Json
if (-not $taskReport.archive_verified.CRC -or -not $taskReport.archive_verified.all_payload_SHA256) { throw 'Evidence archive not verified' }
if ((Get-FileHash -LiteralPath $taskReport.archive.path -Algorithm SHA256).Hash -ne $taskReport.archive.sha256) { throw 'Evidence archive changed' }
$taskRemoved = @()
foreach ($taskFile in $taskPlan.targets) {
    Remove-Item -LiteralPath $taskFile.path -Force
    $taskRemoved += [PSCustomObject]@{path=$taskFile.path;bytes=$taskFile.bytes;sha256=$taskFile.sha256}
}
$taskReceipt = [PSCustomObject]@{executed_utc=[DateTime]::UtcNow.ToString('o');removed=$taskRemoved;removed_bytes=$taskPlan.removed_bytes;script_sha256=$taskPlan.script.sha256}
$taskReceipt | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath (Join-Path $taskStage 'cleanup-executed.json') -Encoding utf8
Write-Output ('PROJECTED_INDEX_CLEANED files=' + $taskRemoved.Count + ' bytes=' + $taskPlan.removed_bytes)
