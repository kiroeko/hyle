"""Archive the completed unprofiled nine-process rotation without running models."""
from datetime import datetime, timedelta, timezone
import hashlib
import json
from pathlib import Path
import statistics
import zipfile

S = Path(__file__).resolve().parent
A = S.parent
ROOT = S.parents[2]
OUT = S / 'performance-rotation'


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))


def identity(path):
    path = Path(path).resolve()
    return dict(path=str(path), bytes=path.stat().st_size,
                sha256=hashlib.sha256(path.read_bytes()).hexdigest())


def save(path, value):
    Path(path).write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')


plan = read(S / 'performance-prepared/plan.json')
summary = read(OUT / 'summary.json')
runs = read(OUT / 'runs.json')
assert summary['terminal_zero'] == len(runs) == 9
assert [row['arm'] for row in runs] == plan['order'] == summary['order']
assert not plan['profiler'] and not plan['external_memory_monitor']
assert plan['source_or_SDK_compilations_during_rotation'] == plan['links_during_rotation'] == 0
assert summary['same_baseline_predictions_all9'] and not summary['statistical_significance']
processes = []
for row in runs:
    process = read(OUT / (row['tag'] + '.result.json'))
    assert row['exit'] == process['exit'] == 0 and process['terminal']
    assert process['pid'] == row['pid'] and process['command'] == row['command']
    assert len(row['phase_step_seconds']) == 32
    assert abs(sum(row['phase_step_seconds'][1:]) - row['metrics']['full31_seconds']) < 1e-12
    assert abs(sum(row['phase_step_seconds'][7:]) - row['metrics']['warm7_31_seconds']) < 1e-12
    processes.append(process)
for arm, group in summary['groups'].items():
    actual = [row for row in runs if row['arm'] == arm]
    assert len(actual) == 3
    for key, stats in group.items():
        samples = [row['metrics'][key] for row in actual]
        assert stats['samples'] == samples and stats['median'] == statistics.median(samples)
for row in summary['images'].values():
    assert identity(row['path']) == row
start = min(row['started'] for row in processes)
finish = max(row['finished'] for row in processes)
beijing = timezone(timedelta(hours=8))
window = dict(started_epoch=start, finished_epoch=finish,
              started_Beijing=datetime.fromtimestamp(start, beijing).isoformat(),
              finished_Beijing=datetime.fromtimestamp(finish, beijing).isoformat(),
              source='Actual nine process result metadata; Asia/Shanghai UTC+08:00.')
prior_path = ROOT / 'docs/evidence/performance/gdn-direct-state-output-2026-10-20.zip'
prior_identity = identity(prior_path)
assert prior_identity['sha256'] == '1c6340962958c9711118b7cc372275ecf42d54f62e78063b7a4b17238b795e09'

payloads = []
for directory in (OUT, S / 'performance-prepared'):
    for path in directory.rglob('*'):
        if path.is_file() and 'tmp' not in path.relative_to(S).parts and not path.name.startswith('cleanup'):
            assert path.suffix.lower() in ('.json', '.log')
            payloads.append((path, path.relative_to(S).as_posix()))
for name in ('compare.py', 'retest-plan.json', 'publish_comparison.py'):
    payloads.append((S / name, name))
for name in ('qwen-current-retest/compare.py', 'batch-layout-query-reuse/compare_three.py',
             'cuda-bf16-dual-projection/compare_three_dual.py'):
    payloads.append((A / name, 'supporting-source/' + name))
for row in plan['frozen']:
    path = Path(row['path'])
    if path.name in ('weights.tsv', 'prompt.ids', 'decode.ids', 'fixed-inputs.json'):
        assert identity(path) == row
        payloads.append((path, 'fixed-inputs/' + path.name))
rows = []
archive_path = ROOT / 'docs/evidence/performance/gdn-direct-state-comparison-2026-10-20.zip'
with zipfile.ZipFile(archive_path, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
    for path, member in sorted(payloads, key=lambda value: value[1]):
        row = identity(path)
        row['member'] = member
        rows.append(row)
        archive.writestr(member, path.read_bytes())
    archive.writestr('payload-sha256.json', json.dumps(rows, indent=2))
with zipfile.ZipFile(archive_path) as archive:
    assert archive.testzip() is None
    for row in rows:
        data = archive.read(row['member'])
        assert len(data) == row['bytes'] and hashlib.sha256(data).hexdigest() == row['sha256']

body = dict(date='2026-10-20',
    scope='One fresh unprofiled Windows CUDA Qwen3.5-2B BF16 text comparison after GDN direct state output and StateWriter extent fix; immediate preceding Hyle image and retained llama.cpp consumer.',
    actual_window=window, actual_processes=9, processes_per_arm=3,
    actual_summary=summary, runs=runs,
    source_and_structural_evidence=prior_identity,
    comparison_script=identity(S / 'compare.py'),
    metric_contract=summary['metric_contract'],
    compilations_during_rotation=0, links_during_rotation=0,
    profiler=False, external_memory_monitor=False,
    current_over_peer_median_percent={key:(ratio - 1) * 100 for key, ratio in summary['current_over_llama'].items()},
    current_over_immediate_before_median_percent={key:(ratio - 1) * 100 for key, ratio in summary['current_over_baseline'].items()},
    interpretation='This window places warm decode median0.570% above the peer and complete31-step median0.586% below it. Current versus immediate preceding Hyle is+1.577% warm and+1.409% complete. Three samples per arm do not establish stable speedup, stable overtake or causal attribution.',
    limits=[
        'All9 processes ended successfully and predictions agree on the same fixed128-token prompt plus31 supplied decode inputs. This is not independent model quality acceptance.',
        'No historical samples or software-profiler durations enter these medians. Earlier windows remain separate.',
        'Both Hyle versions use the same BF16 consumer contract. The peer intermediate arithmetic differs; matrix precision, load and preparation sub-boundaries remain explicitly documented rather than assumed identical.',
        'Hyle prepares both shapes before prefill; the peer retains graph maintenance inside step. Startup-to-first-token is needed alongside individual load/prepare numbers.',
        'Current and preceding Hyle prefill sample ranges overlap; a difference between their three-sample medians does not establish a prefill regression.',
        'No model memory-peak measurement, OS cache eviction or independent statistical-significance result was added in this rotation.',
        'Source/math/lifetime regressions and structural copy removal remain in the separately sealed source archive. This archive holds the actual9 timing samples, raw logs, metric parser source, fixed input metadata and exact image identities; executable/model/SDK payloads are excluded.'],
    archive=identity(archive_path), payloads=rows,
    archive_verified=dict(CRC=True, all_payload_SHA256=True))
save(archive_path.with_suffix('.json'), body)
assert identity(prior_path) == prior_identity
print(json.dumps(dict(published=True, window=window, payloads=len(rows), archive=identity(archive_path)), indent=2), flush=True)
