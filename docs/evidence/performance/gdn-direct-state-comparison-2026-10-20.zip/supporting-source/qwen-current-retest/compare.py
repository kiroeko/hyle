"""Prepare after64-vector success; --run uses three interleaved old/current/llama processes each."""
from pathlib import Path
import argparse
import importlib.util
import sys
sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
A = S.parent
spec = importlib.util.spec_from_file_location('qwen_retest_rotation', A / 'batch-layout-query-reuse/compare_three.py')
rotation = importlib.util.module_from_spec(spec)
spec.loader.exec_module(rotation)
r, b, c = rotation.r, rotation.b, rotation.c
rotation.STAGE = S
r.PREPARED = S / 'performance-prepared'
r.FORBIDDEN_ENV = (*r.FORBIDDEN_ENV, 'GGML_CUDA_CUBLAS_COMPUTE_TYPE')


def runtime_environment(build, peer, out):
    paths = [item['path'] if isinstance(item, dict) else item for item in build['links']['qwen']['inputs']]
    paths += [item['path'] for item in peer['inputs']]
    env, runtime = b.environment(build['links']['qwen']['command'], paths, out)
    for key in r.FORBIDDEN_ENV:
        if key in env:
            raise ValueError('Unexpected experiment environment: ' + key)
    return env, runtime


r.runtime_environment = runtime_environment


def prepare(build_path):
    build_path = build_path.resolve()
    assert c.read(build_path.parent / 'summary.json')['passed']
    numerical = c.read(S / 'correctness/summary.json')
    assert numerical['passed'] and numerical['observation']['equal_vectors'] == 64
    inventory = c.read(S / 'retest-plan.json')
    retained = c.read(A / 'view-projection-reuse/performance-prepared/plan.json')
    images = {'baseline': inventory['retained_old_image'],
        'current': c.read(build_path.parent / 'qwen-image.json'),
        'llama': inventory['retained_llama_image']}
    for item in images.values():
        r.require_same(item)
    peer = c.read(r.PEER_PLAN)
    requests = []
    for old in retained['requests']:
        command = old['command'].copy()
        command[0] = images[old['arm']]['path']
        assert '--trace' not in command
        requests.append({**old, 'command': command})
    assert [row['arm'] for row in requests] == r.ORDER
    # Select actual fixture/model paths, including the source shard's real name.
    hyle = next(row['command'] for row in requests if row['arm'] == 'current')
    llama = next(row['command'] for row in requests if row['arm'] == 'llama')
    inputs = Path(hyle[hyle.index('--inputs') + 1])
    manifest = inputs / 'weights.tsv'
    wanted = {c.key(path) for path in (manifest, inputs / 'prompt.ids',
        Path(hyle[hyle.index('--decode-ids') + 1]), Path(llama[2]),
        Path(manifest.read_text(encoding='utf-8').splitlines()[1]), Path(llama[1]))}
    frozen = [item for item in retained['frozen'] if c.key(item['path']) in wanted]
    assert {c.key(item['path']) for item in frozen} == wanted
    frozen += [b.identity(path) for path in (Path(__file__), S / 'retest-plan.json', build_path,
        build_path.parent / 'qwen-link-plan.json', S / 'correctness/summary.json', r.PEER_PLAN)]
    plan = {key: retained[key] for key in ('schema_version', 'status', 'fixed', 'source_id',
        'expected_baseline_ids', 'order', 'metric_contract')}
    plan.update(build_plan=b.identity(build_path), images=images, peer_inputs=peer['inputs'],
        frozen=frozen, requests=requests, profiler=False, external_memory_monitor=False,
        source_or_SDK_compilations_during_rotation=0, links_during_rotation=0,
        baseline='Last accepted view-projection-reuse fc3638f3 image; retained original main source.',
        precision_limit='Original BF16 Hyle path unchanged; peer intermediate math and load/prepare boundaries remain different.')
    r.PREPARED.mkdir(exist_ok=False)
    c.save(r.PREPARED / 'plan.json', plan)
    print('QWEN_ROTATION_PREPARED_NO_GPU', r.PREPARED / 'plan.json', flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--build-plan', type=Path)
    parser.add_argument('--run', action='store_true')
    args = parser.parse_args()
    if args.run:
        assert args.build_plan is None
        rotation.run(r.PREPARED / 'plan.json', S / 'performance-rotation')
    else:
        assert args.build_plan is not None
        prepare(args.build_plan)
