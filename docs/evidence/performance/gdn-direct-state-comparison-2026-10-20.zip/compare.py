"""Reuse the fixed unprofiled three-arm rotation with the immediate v32 image."""
import argparse
import importlib.util
from pathlib import Path
import sys

sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
A = S.parent
spec = importlib.util.spec_from_file_location('gdn_direct_state_rotation', A / 'qwen-current-retest/compare.py')
h = importlib.util.module_from_spec(spec)
spec.loader.exec_module(h)
h.S = h.rotation.STAGE = S
h.r.PREPARED = S / 'performance-prepared'

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--run', action='store_true')
    args = parser.parse_args()
    if args.run:
        h.rotation.run(h.r.PREPARED / 'plan.json', S / 'performance-rotation')
    else:
        assert h.c.read(S / 'tests-final/summary.json')['passed']
        assert h.c.read(S / 'profile/summary.json')['passed']
        baseline = h.c.read(A / 'projected-bind-cold-index/checks/host1/qwen-image.json')
        peer = h.c.read(A / 'paired-projection-route/performance-prepared/plan.json')['images']['llama']
        for row in (baseline, peer):
            h.r.require_same(row)
        h.c.save(S / 'retest-plan.json', dict(retained_old_image=baseline, retained_llama_image=peer))
        h.prepare(S / 'checks/native1/plan.json')
        plan_path = h.r.PREPARED / 'plan.json'
        plan = h.c.read(plan_path)
        plan['baseline'] = ('Immediately preceding projected-bind-cold-index v32 image; current v33 removes the closed K1 GDN state stage-out and includes the separately tested StateWriter extent fix. Same original BF16 model main, weights, input tape and public precision.')
        plan['frozen'].append(h.b.identity(Path(__file__)))
        plan['correctness'] = dict(cuda_cases=13, hidden_logits_byte_equal=64, state_CPU_cases=32,
            state_tests=h.b.identity(A / 'state-writer-slice-fix/tests/summary.json'),
            native_tests=h.b.identity(S / 'tests-final/summary.json'))
        h.c.save(plan_path, plan)
