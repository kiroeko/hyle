"""Offline-only evidence helper. Root invokes after reviewing the current32 window."""
from pathlib import Path
import hashlib
import json
import math
import zipfile

R=Path('C:/public/project-hyle/hyle');A=Path(__file__).resolve().parent;W=A/'window';T=A/'trace-numerics'
DEST=R/'docs/evidence/performance/inference-small-projection-model-window-2026-10-28'
STAGES=(('single','ordinary'),('single','mtp'),('two-turn','ordinary'),('two-turn','mtp'))
METRICS=('prefill_tokens_per_second','full_decode_tokens_per_second','session_output_tokens_per_second','session_processed_tokens_per_second')


def read(path):return json.loads(Path(path).read_text(encoding='utf-8-sig'))
def encoded(value):return(json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False)+'\n').encode('utf-8')
def sha(raw):return hashlib.sha256(raw).hexdigest()
def pin(path):
    path=Path(path);raw=path.read_bytes();return dict(path=str(path.resolve()),bytes=len(raw),sha256=sha(raw))
def exact(row):
    actual=pin(row['path']);assert(actual['bytes'],actual['sha256'])==(row['bytes'],row['sha256']),row['path']
def non_time(value):
    if isinstance(value,list):return[non_time(v) for v in value]
    if isinstance(value,dict):return{k:non_time(v) for k,v in value.items() if not any(s in k for s in ('seconds','per_second','clock_unix','unix_ns','unix_ms'))}
    return value
def terminal(row):assert row['exit']==0 and not row.get('timeout') and not row.get('timed_out') and not row.get('reader_errors'),row


def main():
    summary=read(W/'summary.json');plan=read(W/'plan.json');binding=read(W/'binding.json')
    assert summary['status']=='COMPLETE32_CURRENT_CONTROL_N32_STABLE' and summary['processes']==32
    exact(plan['script']);exact(plan['binding']);assert(plan['timing_processes'],plan['independent_memory_processes'])==(24,8)
    for row in binding['protocols'].values():exact(row)
    for row in binding['work'].values():exact(row)
    ready={name:read(A/f'ready-{name}.json') for name in ('control','candidate')}
    for name,row in ready.items():
        exact(binding['versions'][name]['ready']);exact(row['inputs']);exact(row['recipe']);exact(row['runtime']);exact(row['source_freeze'])
        for key in ('snapshot','command','dependencies','actual_dependencies'):exact(row['compiled'][key])
    inputs={name:read(row['inputs']['path']) for name,row in ready.items()}
    assert len(inputs['control'])==len(inputs['candidate'])==229
    changed=[dict(control=a,candidate=b) for a,b in zip(inputs['control'],inputs['candidate']) if a!=b]
    assert changed==[dict(control=ready['control']['compiled']['object'],candidate=ready['candidate']['compiled']['object'])]
    assert ready['control']['image']['sha256'].startswith('0c6227') and ready['candidate']['image']['sha256'].startswith('e3a9fd')
    records=[];work=[];metrics_table=[];memory_table=[]
    for scenario,role in STAGES:
        facts=[];sample_rows=[];stage_work=None
        for mode,count in (('timing',6),('memory',2)):
            folder=W/(scenario+'-'+role+'-'+mode);group=read(folder/'summary.json')
            assert group['status']=='COMPLETE_STABLE' and group['processes']==count and group['unexpected_differences']==[]
            assert all(row['stable'] and not row['changes'] for row in group['within_variant_complete_non_time'].values())
            entries=read(folder/'runs.json');assert len(entries)==count
            for entry in entries:
                child=Path(entry['folder']);process=read(child/'result.json');terminal(process)
                command=read(child/'command.json');assert process['command']==command['command']
                assert process['image']==ready[entry['variant']]['image']
                assert '--trace' not in process['command'] and '--probe' not in process['command']
                raw=read(child/'consumer-result.json');original=next(json.loads(line) for line in reversed((child/'stdout.log').read_text(encoding='utf-8').splitlines()) if line.startswith('{'))
                assert all(raw[k]==original[k] for k in ('prefill_seconds','decode_seconds','session_seconds'))
                p,d,total=(raw[k] for k in ('prefill_seconds','decode_seconds','session_seconds'))
                assert all(math.isfinite(v) and v>0 for v in (p,d,total)) and math.isclose(p+d,total,rel_tol=1e-5,abs_tol=2e-6)
                expected=64 if scenario=='single' else 128
                assert len(raw['generated_ids'])==raw['generated_tokens']==expected
                assert raw['generated_decode_tokens']==(63 if scenario=='single' else 126)
                assert raw['prefill_target_rows']==(154 if scenario=='single' else 309)
                assert raw['live_committed_versions']==0
                if role=='mtp':
                    assert raw['mtp'] and raw['accepted_drafts']==raw['consumed_drafts']
                    assert len(raw['rounds'])==raw['draft_rounds']
                    assert sum(row['accepted_draft'] for row in raw['rounds'])==raw['accepted_drafts']
                else:assert not raw['mtp'] and 'accepted_drafts' not in raw
                facts.append(non_time(raw));sample_rows.append(entry)
                if stage_work is None:
                    stage_work={key:raw[key] for key in ('generated_tokens','generated_decode_tokens','actual_graph_calls','prefill_target_rows','actual_target_rows','actual_draft_rows','committed_target_rows','verified_target_rows','pending_flushed_tokens')}
                    stage_work.update(generated_ID_count=len(raw['generated_ids']),generated_IDs_sha256=sha(encoded(raw['generated_ids'])),
                        accepted_drafts=raw.get('accepted_drafts'),acceptance_present='accepted_drafts' in raw,
                        draft_rounds=raw.get('draft_rounds'),complete_non_time_sha256=sha(encoded(facts[-1])))
                records.append(dict(scenario=scenario,role=role,mode=mode,variant=entry['variant'],window_ordinal=entry['window_ordinal'],
                    folder=str(child),pid=process['pid'],exit=process['exit'],started_unix_ns=process['started_unix_ns'],finished_unix_ns=process['finished_unix_ns'],
                    result=pin(child/'result.json'),producer_report=pin(child/'consumer-result.json')))
            if mode=='timing':
                for variant in ('control','candidate'):
                    stats=group['groups'][variant]
                    metrics_table.append(dict(scenario=scenario,role=role,variant=variant,
                        four_metrics={key:stats[key] for key in METRICS},
                        complete_wall_seconds={key:stats[key] for key in ('prefill_seconds','decode_seconds','session_seconds')},
                        load_ready_cold={key:stats[key] for key in ('weights_load_seconds','startup_to_ready_seconds','first_token_elapsed_seconds','startup_to_endpoint_seconds','cold_output_tokens_per_second')}))
            else:
                for variant in ('control','candidate'):
                    value=group['groups'][variant]
                    memory_table.append(dict(scenario=scenario,role=role,variant=variant,sampled_peaks=value['sampled_peaks'],
                        ready_baseline=value['ready_baseline'],running_sample_count=value['running_sample_count'],
                        actual_sample_gaps_ms={key:value['actual_sample_gaps_ms'].get(key) for key in ('min','median','max')},null_sample_counts=value['null_sample_counts']))
        assert all(value==facts[0] for value in facts[1:]),(scenario,role,'Complete reports differ across version/timing/memory')
        work.append(dict(scenario=scenario,role=role,processes=len(sample_rows),all_8_complete_non_time_equal=True,actual=stage_work))
    # Windows may recycle a PID after termination. Identify each actual
    # attempt by PID plus its recorded start, and its unique planned ordinal.
    assert len(records)==len({(row['pid'],row['started_unix_ns']) for row in records})==len({row['window_ordinal'] for row in records})==32
    trace=read(T/'analysis.json');assert trace['status']=='PASS_FOUR_FINITE_EXPORTED_TENSOR_BIT_CHECKS'
    assert(trace['native_processes'],trace['compared_tensors'],trace['byte_equal_tensors'],trace['complete_compared_bytes'])==(4,266,266,144744448)
    assert trace['automatic_reruns']==0 and trace['numerical_tolerance'] is None
    assert all(v['byte_equal'] and v['differing_bytes']==0 and v['control_sha256']==v['candidate_sha256'] for v in trace['tensors'])
    for entry in trace['actual_original_processes'].values():
        for key in ('receipt','stdout','command'):exact(entry[key])
        terminal(read(entry['receipt']['path']))
    route=read(A/'route-attribution.json');assert route['status']=='OFFLINE_SIX_ACTUAL_FAMILY_ROUTE_ATTRIBUTION'
    assert len(route['families'])==6 and all(row['actual_groups_matched']==18 for row in route['families'])
    exact(route['source_basis']);exact(route['numeric_report_reference'])
    assert all(row['compiled_known_bytes_delta']==2365632 for row in route['families'])
    compile_process=read(A/'logs/model/process.json');terminal(compile_process)
    links={name:read(A/f'link/{name}/process.json') for name in ready}
    for row in links.values():terminal(row)
    archive={}
    def add(path,name=None):
        path=Path(path);assert path.is_file(),path
        assert path.suffix.lower() not in ('.exe','.obj','.lib','.exp','.pdb','.dll','.bf16','.f16','.f32','.f64','.bin','.gguf','.safetensors')
        name=name or path.relative_to(A).as_posix();raw=path.read_bytes();assert name not in archive or archive[name]==raw,name;archive[name]=raw
    def tree(path):
        for path in sorted(Path(path).rglob('*')):
            if path.is_file() and path.suffix.lower() in ('.json','.log','.py','.xml','.patch','.diff','.cc','.h','.txt') and path.name!='environment.json' and '__pycache__' not in path.parts:add(path)
    for name in ('build.py','build-plan.json','source-freeze.json','preparation.json','candidate.patch','project-dependencies.json',
                 'retained-input-stats.json','recipe-model-draft.json','link-model-draft.json','link-control.json','runtime.json',
                 'inputs-control.json','inputs-candidate.json','ready-control.json','ready-candidate.json','trace-numerics.py',
                 'trace-numerics-parse-v2.py','route-attribution.py','route-attribution.json','package-window.py'):add(A/name)
    for family in route['families']:
        for key in ('control_route','candidate_route','control_boundaries','candidate_boundaries'):
            exact(family[key]);add(family[key]['path'])
    for directory in ('source','logs','compile','link'):tree(A/directory)
    tree(W)  # only32 window raw metadata/logs and original memory.json samples
    for name in ('plan.json','analysis.json'):add(T/name)
    for name in trace['actual_original_processes']:
        child=T/name
        for path in sorted(child.iterdir()):
            if path.is_file() and path.suffix.lower() in ('.json','.log'):add(path)
        for path in sorted((child/'trace').rglob('kv-layout.json')):add(path)
    add(ready['control']['compiled']['snapshot']['path'],'source-control/engine/models/qwen35/main.cc')
    for name in ('prepare.py','failure-prepare1.log'):
        if(A.parent/name).is_file():add(A.parent/name,'previous-metadata/'+name)
    archive['build-environment-relevant.json']=encoded(dict(identity=pin(A/'environment.json'),
        preserved={key:read(A/'environment.json')[key] for key in ('PATH','INCLUDE','LIB','LIBPATH') if key in read(A/'environment.json')}))
    references=[]
    for relative in ('docs/evidence/correctness/inference-optional-aten-2026-10-28.json',
                     'docs/evidence/correctness/inference-optional-aten-2026-10-28.zip'):
        if(R/relative).is_file():references.append(pin(R/relative))
    manifest=encoded(dict(members=[dict(name=name,bytes=len(raw),sha256=sha(raw)) for name,raw in sorted(archive.items())],self_hash='In external JSON archive.manifest_sha256'))
    archive['MANIFEST.json']=manifest
    outzip=DEST.with_suffix('.zip');outjson=DEST.with_suffix('.json');assert not outzip.exists() and not outjson.exists(),'Never overwrite evidence'
    DEST.parent.mkdir(parents=True,exist_ok=True)
    with zipfile.ZipFile(outzip,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for name,raw in sorted(archive.items()):z.writestr(name,raw)
    with zipfile.ZipFile(outzip) as z:
        assert z.testzip() is None and set(z.namelist())==set(archive)
        for name,raw in archive.items():assert sha(z.read(name))==sha(raw),name
    result=dict(status='COMPLETE32_SCRATCH_CANDIDATE_WINDOW_AND4_TRACE_CHECKS',source_base_commit='4ca9',candidate_in_product=False,
        source_base_scope='Root-declared source base; immutable exact control/candidate Model source SHA and input rosters below are authoritative.',
        images={name:dict(image=row['image'],source=row['compiled']['snapshot'],inputs=row['inputs']) for name,row in ready.items()},
        input_count_each=229,only_replaced_input=changed,CXX=dict(actual=1,process=compile_process),links=links,
        performance=dict(processes=32,timing=24,independent_memory=8,all_terminal_success=True,automatic_retries=0,
            metrics=metrics_table,comparison=summary['within_window_comparison'],actual_work=work,processes_index=records),
        memory=dict(processes=memory_table,ready_unknown_count=sum(row['ready_baseline']['unknown'] for row in memory_table),
            requested_interval_seconds=0.01,definition='Independent PSAPI/PDH/WDDM samples; actual gaps and null counters retained. WS/private commit/dedicated/shared are separate. Sampled peaks are lower bounds; ready absence is unknown, never zero.'),
        trace_numerics=dict(processes=4,analysis=pin(T/'analysis.json'),compared_tensors=266,byte_equal_tensors=266,
            compared_bytes=144744448,per_tensor_hashes_in_archive=True,raw_tensor_payload_in_archive=False,
            parser_amendment=trace['parser_amendment'],native_failures=0,native_reruns=0,
            scope=trace['scope'],actual_branch_scope=trace['actual_branch_scope'],limits=trace['limits']),
        preparation_failure=dict(receipt=pin(A.parent/'failure-prepare1.log'),CXX=0,native=0,
            scope='Metadata Path/string conversion error before compile recipe/native launch; source/diff preserved.'),
        reference_archives=references,
        route_attribution=dict(analysis=pin(A/'route-attribution.json'),families=[{key:value for key,value in row.items()
            if key in ('mode','family','actual_groups_matched','control_counts','candidate_counts','compiled_known_bytes_delta','workspace_bytes_per_slot_delta')} for row in route['families']],
            cold_concat=route['cold_concat'],materialization=route['materialization'],plan_vs_native=route['plan_vs_native'],
            limit='Route/source facts do not establish the measured timing cause. Zero Graph kCopy is not zero private D2D; actual native copy counts/bytes/time were not measured.'),
        candidate_decision='Scratch candidate not adopted as a default: this finite window shows no significant end-to-end benefit. No next M2 paired implementation is part of this batch.',
        limits=['Three timing samples per version/scenario/role. Medians/ranges are descriptive; MTP two-turn+1.39% decode is not a stable-gain or statistical-significance claim.',
            'Currentcontrol0c622/candidatee3a9 both newly linked against the same ON229 inputs. No dfa9 historical timing samples or peer samples pooled.',
            'Frozen peer433e remains historical context, not latest upstream and not measured in this32-process A/B.',
            'Ordinary overlap-auto and MTP K1 overlap-off; single vs two-turn are one resident R1 session, not a two-user batch.',
            'Natural64/128 IDs and complete non-time reports match both variants; actual target/draft/accepted work is retained. This does not prove full unexported KV/carry byte identity.',
            'Trace4 native processes are independent numerical checks with overlap disabled and4 outputs, never performance samples. Only the exported tensor set is bit-checked.',
            'Compiled known-byte deltas are reported plan accounting, not physical peak memory; 18*128KiB bank plus6336 metadata is source-derived.',
            'No exact timing root-cause, trained quality, new-native-platform, production adoption, all-shape/provider or cross-window causal benefit claim.'],
        archive=dict(**pin(outzip),members=len(archive),manifest_sha256=sha(manifest),CRC='PASS',all_member_SHA256='PASS'))
    with outjson.open('xb') as stream:stream.write(encoded(result))
    with(A/'window-package-readback.json').open('xb') as stream:stream.write(encoded(dict(JSON=pin(outjson),ZIP=pin(outzip),members=len(archive),CRC='PASS',all_member_SHA256='PASS')))
    print(json.dumps(dict(JSON=pin(outjson),ZIP=pin(outzip),members=len(archive)),ensure_ascii=False))


if __name__=='__main__':main()
