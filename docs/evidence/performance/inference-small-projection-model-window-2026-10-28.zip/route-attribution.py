"""Offline actual route/boundary metadata only; no tensor payload, image or SDK scan."""
from pathlib import Path
from collections import Counter
import csv
import hashlib
import json
import re

W = Path(__file__).resolve().parent
T = W / 'trace-numerics'

def pin(path):
    raw = path.read_bytes()
    return {'path': str(path), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}

def table(path):
    with path.open(encoding='utf-8', newline='') as stream:
        return list(csv.DictReader(stream, delimiter='\t'))

def route(path):
    steps = table(path)
    nodes = {}
    for step in steps:
        for text in step['nodes'].split(','):
            ordinal, name = text.split(':', 1)
            assert int(ordinal) not in nodes
            nodes[int(ordinal)] = (name, step)
    return steps, nodes

def storage(path, tokens, steps):
    found = []
    for line in path.read_text(encoding='utf-8').splitlines():
        if not line.startswith('compiled T='):
            continue
        fields = {name: int(value) for name, value in re.findall(r'([\w/-]+)=(\d+)', line)}
        if fields['T'] == tokens and fields['steps'] == steps:
            found.append(fields)
    assert len(found) == 1, (path, tokens, steps)
    return found[0]

families = []
for mode in ('ordinary', 'mtp'):
    for candidate in sorted((T / (mode + '-candidate') / 'trace/routes').glob('*.route.tsv')):
        control = T / (mode + '-control') / 'trace/routes' / candidate.name
        a, an = route(control)
        b, bn = route(candidate)
        # Exact emitted Recipe order: cold Concat, permute, wide MatMul, two
        # Views. Each prior replacement adds exactly one graph node. Match the
        # corresponding two recorded original MatMul nodes, never a kernel name.
        groups = sorted(n for n, (kind, _) in bn.items() if kind == 'concat' and
                        all(n + i in bn and bn[n + i][0] == name for i, name in
                            ((1, 'view'), (2, 'matmul'), (3, 'view'), (4, 'view'))))
        assert len(groups) == 18
        replacements = []
        for index, node in enumerate(groups):
            old_a, old_b = node - index + 1, node - index + 5
            assert an[old_a][0] == an[old_b][0] == 'matmul'
            desc = lambda step: {'step': int(step['step']), 'kind': int(step['kind']),
                                 'provider': step['provider'], 'implementation': step['implementation']}
            replacements.append({'gdn_ordinal': index, 'control_matmul_nodes': [old_a, old_b],
                                  'candidate_concat_node': node, 'candidate_matmul_node': node + 2,
                                  'candidate_view_nodes': [node + 3, node + 4],
                                  'control_a': desc(an[old_a][1]), 'control_b': desc(an[old_b][1]),
                                  'candidate': desc(bn[node + 2][1])})
        boundary_name = candidate.name.replace('.route.tsv', '.boundaries.tsv')
        cb, nb = control.with_name(boundary_name), candidate.with_name(boundary_name)
        aa, bb = table(cb), table(nb)
        assert [(x['point'], x['shape']) for x in aa] == [(x['point'], x['shape']) for x in bb]
        tokens = int(re.search(r'-T(\d+)\.', candidate.name)[1])
        ac = storage(T / (mode + '-control') / 'stderr.log', tokens, len(a))
        bc = storage(T / (mode + '-candidate') / 'stderr.log', tokens, len(b))
        known_delta = bc['compiled_known_bytes'] - ac['compiled_known_bytes']
        assert known_delta == 18 * 131072 + 6336
        count = lambda xs: {'all_plan_steps': len(xs),
                            'metadata_views': sum(x['kind'] == '3' for x in xs),
                            'nonview_plan_steps': sum(x['kind'] != '3' for x in xs),
                            'graph_copy_steps': sum(x['kind'] == '2' for x in xs),
                            'provider_steps': dict(Counter(x['provider'] for x in xs))}
        families.append({'mode': mode, 'family': candidate.name.removesuffix('.route.tsv'),
                         'control_route': pin(control), 'candidate_route': pin(candidate),
                         'control_boundaries': pin(cb), 'candidate_boundaries': pin(nb),
                         'matching_named_boundary_shapes': len(aa),
                         'actual_groups_matched': len(replacements), 'replacements': replacements,
                         'control_counts': count(a), 'candidate_counts': count(b),
                         'control_compiled': ac, 'candidate_compiled': bc,
                         'compiled_known_bytes_delta': known_delta,
                         'workspace_bytes_per_slot_delta': bc['workspace/slot'] - ac['workspace/slot']})

assert len(families) == 6
report = {
    'status': 'OFFLINE_SIX_ACTUAL_FAMILY_ROUTE_ATTRIBUTION',
    'read_scope': 'Twelve small route TSVs, twelve boundary TSVs, four stderr logs. No tensor/binary/SDK payload read and no native execution.',
    'source_basis': json.loads((W / 'source-freeze.json').read_text(encoding='utf-8'))['candidate'],
    'numeric_report_reference': pin(T / 'analysis.json'),
    'families': families,
    'cold_concat': {
        'observed_added_concat_nodes_per_family': 18,
        'reported_compiled_known_bytes_delta_each_child': 2365632,
        'inferred_current_target_bank_payload_per_family': 2359296,
        'explanation': 'Frozen candidate geometry emits 18 immutable BF16[32,2048] concats. Source constant_expressions::prepare folds these into existing ConstantArtifact storage and removes folded recipe nodes before native prepare; the public route report still lists original Graph nodes. Known-byte delta equals 18*131072 plus6336 metadata.',
        'limit': 'This process did not separately export packed_constant_count/materialized_constant_bytes or read back the ConstantArtifact payload. The exact bank split is source-derived and consistent with observed known bytes, not an independent VRAM peak measurement.'},
    'materialization': {
        'actual_graph_copy_steps_control_candidate': [0, 0],
        'actual_added_metadata_views_per_family': 18,
        'actual_sigmoid_provider_change_per_family': '18 ggml-cuda unary leaves become18 hyle-cuda unary leaves in aggregate provider counts.',
        'source_proof': 'For M>1, a-half BF16[rows,16] has row stride64B rather than32B. Its selected Cast remains in ggml. tensor_program.cc::matrix()->matrix_form()->Cast inserts ggml_cont for noncontiguous inputs. M1 has no effective multirow gap.',
        'source_inferred_materialized_a_payload_per_episode': {'T2': 18 * 64, 'T154': 18 * 4928},
        'native_D2D_count_bytes_time_measured_in_this_batch': None,
        'limit': 'No Nsight/private-operation dump was collected for these4 new Model traces. Do not treat zero Graph copy steps as zero private copies or transfer the old leaf timing to this Model.'},
    'plan_vs_native': 'Graph steps include metadata Views and provider episodes, not native kernel counts. M1 nonview count is unchanged; M2/T154 nonview count decreases18 while added18Views hold total plan steps flat.',
    'no_TPS_or_causal_speed_claim': True,
}
output = W / 'route-attribution.json'
assert not output.exists(), 'Preserve prior analysis'
output.write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'output': pin(output), 'families': len(families),
                  'groups_each': 18, 'boundary_shapes_checked': sum(x['matching_named_boundary_shapes'] for x in families)}, indent=2))
