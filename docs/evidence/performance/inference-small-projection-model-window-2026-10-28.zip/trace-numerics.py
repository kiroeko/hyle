"""Four finite full-trace observations; only explicit run starts a model.

This is a byte comparison of exported tensors, not a throughput/quality gate
or a claim about target/draft KV and carry/prior storage not exported by CLI.
"""
from pathlib import Path
import hashlib
import importlib.util
import json
import sys

sys.dont_write_bytecode = True
M = Path(__file__).resolve().parent
W = M / 'trace-numerics'
R = M.parents[3]
OLD = R / '.scratch/inference-program-io-window-20261028'
CASES = ('ordinary-control', 'ordinary-candidate', 'mtp-control', 'mtp-candidate')
EXPECTED = {'logits.f32', 'hidden.bf16'} | {
    f'layer{i}.{kind}' for i in range(24) if i % 4 != 3
    for kind in ('conv.bf16', 'gdn.f32')}


def read(path):
    return json.loads(Path(path).read_bytes())


def save(path, value):
    path = Path(path); path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('x', encoding='utf-8') as stream:
        stream.write(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + '\n')


def pin(path):
    path = Path(path).resolve(); h = hashlib.sha256()
    with path.open('rb') as stream:
        while block := stream.read(1 << 20): h.update(block)
    return dict(path=str(path), bytes=path.stat().st_size, sha256=h.hexdigest())


def exact(row):
    assert pin(row['path']) == row, row['path']


def prepare():
    assert not (W / 'plan.json').exists(), 'Preserve the original plan and attempts'
    templates = read(OLD / 'single-timing-plan.json')
    ready = {v: read(M / f'ready-{v}.json') for v in ('control', 'candidate')}
    assert ready['control']['closure_inputs'] == ready['candidate']['closure_inputs'] == 229
    rows = {v: read(ready[v]['inputs']['path']) for v in ready}
    changes = [(a, b) for a, b in zip(rows['control'], rows['candidate']) if a != b]
    assert changes == [(ready['control']['compiled']['object'], ready['candidate']['compiled']['object'])]
    assert ready['control']['runtime'] == ready['candidate']['runtime']
    entries = []
    for name in CASES:
        role, variant = name.split('-'); r = ready[variant]
        assert r['process']['exit'] == r['compiled']['process']['exit'] == 0
        for field in ('image', 'runtime', 'inputs', 'source_freeze'): exact(r[field])
        mapped = 'hyle_auto' if role == 'ordinary' else 'hyle_mtp'
        source = next(e for e in templates['commands'] if e['arm'] == mapped)
        command = [r['image']['path'], *source['command'][1:]]
        assert '--trace' not in command and '--schedule' not in command
        command[command.index('--steps') + 1] = '4'
        command[command.index('--decode-overlap') + 1] = 'off'
        assert command[command.index('--sampling') + 1] == 'greedy'
        assert command[command.index('--mtp') + 1] == ('on' if role == 'mtp' else 'off')
        trace = W / name / 'trace'
        command += ['--trace', str(trace), '--trace-level', 'full']
        inputs = Path(command[command.index('--inputs') + 1])
        assert len((inputs / 'prompt.ids').read_text().split()) == 154
        entries.append(dict(name=name, role=role, variant=variant, folder=str(W / name),
            trace=str(trace), command=command, ready=pin(M / f'ready-{variant}.json'),
            image=r['image'], runtime=r['runtime'], prompt=pin(inputs / 'prompt.ids'),
            input_manifest=pin(inputs / 'weights.tsv')))
    save(W / 'plan.json', dict(status='PREPARED_FOUR_FINITE_NUMERICAL_PROCESSES_NOT_RUN',
        helper=pin(__file__), entries=entries, native_processes=4, max_output_tokens_each=4,
        policy='Every exported logits/hidden/conv/GDN payload must match complete bits; no new tolerance.',
        numerical_tolerance=None, performance_claim=False, downloads=0,
        limits=['Full trace explicitly disables ordinary overlap; times are not performance samples.',
                'Natural greedy inputs are common only while actual decisions agree; compare each mode with its own control.',
                'CLI exports 38 tensors per completed call and KV layout metadata, not target/draft KV or carry/prior payloads.',
                'Four-output MTP may not exercise both accept/reject branches; report actual rounds without adding cases.',
                'Raw trace tensors stay in scratch, not git evidence.']))
    print('READY: run ordinary-control | ordinary-candidate | mtp-control | mtp-candidate; then analyze')


def entry(name):
    plan = read(W / 'plan.json'); exact(plan['helper'])
    return next(e for e in plan['entries'] if e['name'] == name)


def run(name):
    assert name in CASES
    e = entry(name)
    for key in ('ready', 'image', 'runtime', 'prompt', 'input_manifest'): exact(e[key])
    spec = importlib.util.spec_from_file_location('existing_ab_build_driver', M / 'build.py')
    b = importlib.util.module_from_spec(spec); spec.loader.exec_module(b)
    # Existing process receipts, timeout and offline environment; no new runner.
    b.t.execute(e['command'], Path(e['folder']), 900)


def report(e):
    folder = Path(e['folder']); p = read(folder / 'process.json')
    assert p['state'] == 'TERMINAL' and p['exit'] == 0 and not p['timed_out'], p
    assert read(folder / 'command.json')['command'] == e['command']
    value = read(folder / 'stdout.log')
    assert not value['decode_overlap'] and value['live_committed_versions'] == 0
    assert 0 < value['generated_tokens'] <= 4
    return value


def tensor_manifest(trace):
    trace = Path(trace)
    files = {str(p.relative_to(trace)).replace('\\', '/'): p
             for p in trace.rglob('*') if p.is_file() and p.suffix in ('.f32', '.bf16')}
    assert files, 'No actual tensor payloads exported'
    groups = {}
    for name in files: groups.setdefault(name.rsplit('/', 1)[0], set()).add(Path(name).name)
    assert all(names == EXPECTED for names in groups.values()), groups
    return files


def equal_payload(a, b):
    left, right = hashlib.sha256(), hashlib.sha256()
    mismatches = 0; first = None; offset = 0
    assert a.stat().st_size == b.stat().st_size, (str(a), str(b))
    with a.open('rb') as x, b.open('rb') as y:
        while block := x.read(1 << 20):
            other = y.read(len(block)); assert len(other) == len(block)
            left.update(block); right.update(other)
            if block != other:
                for i, (u, v) in enumerate(zip(block, other)):
                    if u != v:
                        mismatches += 1
                        if first is None: first = offset + i
            offset += len(block)
        assert not y.read(1)
    width = 2 if a.suffix == '.bf16' else 4
    assert offset % width == 0
    return dict(bytes=offset, elements=offset // width, dtype='BF16' if width == 2 else 'F32',
        control_sha256=left.hexdigest(), candidate_sha256=right.hexdigest(),
        byte_equal=mismatches == 0, differing_bytes=mismatches, first_differing_byte=first)


def analyze():
    plan = read(W / 'plan.json'); exact(plan['helper'])
    entries = {e['name']: e for e in plan['entries']}
    reports = {name: report(e) for name, e in entries.items()}
    comparisons = []; semantic = []; layouts = []
    all_equal = True
    for role in ('ordinary', 'mtp'):
        control, candidate = (entries[role + '-' + v] for v in ('control', 'candidate'))
        a, b = (reports[role + '-' + v] for v in ('control', 'candidate'))
        decisions_equal = a['generated_ids'] == b['generated_ids']
        semantic.append(dict(role=role, generated_ids_equal=decisions_equal,
            control_generated_ids=a['generated_ids'], candidate_generated_ids=b['generated_ids'],
            actual_mtp_rounds_control=a.get('rounds'), actual_mtp_rounds_candidate=b.get('rounds')))
        all_equal = all_equal and decisions_equal
        left, right = tensor_manifest(control['trace']), tensor_manifest(candidate['trace'])
        assert left.keys() == right.keys(), 'Actual completed call/tensor sets differ; investigate before widening scope'
        for name in sorted(left):
            result = equal_payload(left[name], right[name]); all_equal = all_equal and result['byte_equal']
            comparisons.append(dict(role=role, relative_path=name, **result))
        for name in sorted(set(str(p.parent.relative_to(Path(control['trace']))) for p in left.values())):
            x, y = (read(Path(e['trace']) / name / 'kv-layout.json') for e in (control, candidate))
            logical_equal = all(x[k] == y[k] for k in ('visible_tokens', 'page_rows'))
            all_equal = all_equal and logical_equal
            layouts.append(dict(role=role, completed_call=name, logical_frontier_equal=logical_equal,
                control=x, candidate=y, physical_page_IDs_are_not_payload=True))
    outcome = dict(status='PASS_FOUR_FINITE_EXPORTED_TENSOR_BIT_CHECKS' if all_equal else 'STOP_EXPORTED_TENSOR_OR_DECISION_DIFFERENCE',
        plan=pin(W / 'plan.json'), native_processes=4, semantic=semantic, layouts=layouts,
        compared_tensors=len(comparisons), complete_compared_bytes=sum(v['bytes'] for v in comparisons),
        byte_equal_tensors=sum(v['byte_equal'] for v in comparisons), tensors=comparisons,
        numerical_tolerance=None, automatic_reruns=0, performance_claim=False,
        limits=plan['limits'], full_unexported_state_checked=False,
        scope='Current control versus N32 candidate separately within ordinary/MTP, same P154 prompt and up-to-four greedy output IDs. Complete exported tensor bytes, not continuation readability.')
    save(W / 'analysis.json', outcome)
    print(json.dumps({k: outcome[k] for k in ('status', 'native_processes', 'compared_tensors', 'complete_compared_bytes', 'byte_equal_tensors')}))
    assert all_equal, 'Preserved numerical difference: stop and investigate original mathematics; never widen tolerance or rerun successes'


if __name__ == '__main__':
    action = sys.argv[1]
    if action == 'prepare': prepare()
    elif action == 'run': run(sys.argv[2])
    elif action == 'analyze': analyze()
    else: raise SystemExit('prepare | run CASE | analyze')
