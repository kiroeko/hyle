"""Scratch Model candidate/recipe only. Does not compile, link or run anything."""
from pathlib import Path
import difflib
import hashlib
import json

R = Path(__file__).resolve().parents[3]
W = Path(__file__).resolve().parent / 'attempt2'
SOURCE = R / 'engine/models/qwen35/main.cc'
SEED = R / '.scratch/inference-store-cohort-20261028/cli'
ON = R / '.scratch/inference-optional-aten-20261028/validation'

def pin(path):
    raw = path.read_bytes()
    return {'path': str(path), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}

def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))

def save(path, data):
    assert not path.exists(), path
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')

raw = SOURCE.read_bytes()
assert b'\r' not in raw, 'Preserve the canonical Model LF contract'
original = raw.decode('utf-8')
anchor = '  V emit_projection(V x, const ProjectionBinding &binding, bool scores) {'
assert original.count(anchor) == 1
helper = '''  // Scratch candidate: mathematical sibling grouping, independent of M/N/K,
  // model role spelling, provider and execution mode. No product default change.
  std::optional<std::array<V, 2>> linear_pair(V x, const std::string &first,
                                             const std::string &second) {
    const auto &left = projection("model.language_model." + first);
    const auto &right = projection("model.language_model." + second);
    const auto *a = std::get_if<StoredProjection>(&left);
    const auto *b = std::get_if<StoredProjection>(&right);
    // All other original equations (including quantized/storage codecs and
    // F16/F32 dense readers) retain their existing arithmetic and operands.
    if (activation_type() != Type::kBFloat16 || spec(x).rank() != 2 ||
        spec(x).data_type() != Type::kBFloat16 || !a || !b ||
        !a->weight || !b->weight) return std::nullopt;
    const auto &wa = a->weight->description;
    const auto &wb = b->weight->description;
    if (!wa.is_plain() || !wa.is_dense() || !wb.is_plain() || !wb.is_dense() ||
        wa.data_type() != Type::kBFloat16 || wb.data_type() != Type::kBFloat16 ||
        wa.rank() != 2 || wb.rank() != 2 ||
        wa.dimensions()[1] != wb.dimensions()[1] ||
        spec(x).dimensions()[1] != f(wa.dimensions()[1])) return std::nullopt;
    const auto na = wa.dimensions()[0], nb = wb.dimensions()[0];
    const auto depth = wa.dimensions()[1];
    if (na <= 0 || nb <= 0 || depth <= 0 ||
        na > (std::numeric_limits<std::int64_t>::max)() - nb)
      throw std::runtime_error("cold projection group extent overflows");
    const auto total = na + nb;
    // Validate the complete physical extent before adding candidate nodes.
    (void)take(dense(Type::kBFloat16, {total, depth}).required_bytes());
    const std::array weights{operand(*a->weight), operand(*b->weight)};
    const auto joined = concat(weights, 0,
        dense_spec(Type::kBFloat16, {f(total), f(depth)}));
    constexpr std::array<std::int32_t, 2> axes{1, 0};
    const auto rhs = one(take(c::View::permute(axes)), {joined});
    const auto wide = one(c::MatMul{.accumulation_type = Type::kFloat32},
        {x, rhs}, dense_spec(Type::kBFloat16, {spec(x).dimensions()[0], f(total)}));
    // Both BF16 store boundaries survive. These are internal readonly Views;
    // do not publish the extra wide fixture output used by the old leaf test.
    return std::array{slice(wide, 1, f(0), f(na)), slice(wide, 1, f(na), f(nb))};
  }
'''
candidate = original.replace(anchor, helper + anchor)
replacements = [
('''          const auto a = r.reshape(r.cast(r.linear(normalized, prefix + "linear_attn.in_proj_a.weight"), Type::kFloat32),
              {packed, f(geometry.gdn_value_heads), f(1)});
          const auto b = r.reshape(r.linear(normalized, prefix + "linear_attn.in_proj_b.weight"),
              {packed, f(geometry.gdn_value_heads), f(1)});''',
'''          const auto ab = r.linear_pair(normalized, prefix + "linear_attn.in_proj_a.weight",
              prefix + "linear_attn.in_proj_b.weight");
          const auto a = r.reshape(r.cast(ab ? (*ab)[0] : r.linear(normalized, prefix + "linear_attn.in_proj_a.weight"), Type::kFloat32),
              {packed, f(geometry.gdn_value_heads), f(1)});
          const auto b = r.reshape(ab ? (*ab)[1] : r.linear(normalized, prefix + "linear_attn.in_proj_b.weight"),
              {packed, f(geometry.gdn_value_heads), f(1)});'''),
('''          auto a = r.reshape(r.cast(r.linear(normalized, prefix + "linear_attn.in_proj_a.weight"), Type::kFloat32), {batch, t, f(geometry.gdn_value_heads), f(1)});
          auto b = r.reshape(r.linear(normalized, prefix + "linear_attn.in_proj_b.weight"), {batch, t, f(geometry.gdn_value_heads), f(1)});''',
'''          const auto ab = r.linear_pair(normalized, prefix + "linear_attn.in_proj_a.weight",
              prefix + "linear_attn.in_proj_b.weight");
          auto a = r.reshape(r.cast(ab ? (*ab)[0] : r.linear(normalized, prefix + "linear_attn.in_proj_a.weight"), Type::kFloat32), {batch, t, f(geometry.gdn_value_heads), f(1)});
          auto b = r.reshape(ab ? (*ab)[1] : r.linear(normalized, prefix + "linear_attn.in_proj_b.weight"), {batch, t, f(geometry.gdn_value_heads), f(1)});''')]
for before, after in replacements:
    assert candidate.count(before) == 1, 'Canonical callsite drift: do not loosely rewrite'
    candidate = candidate.replace(before, after)
assert candidate.count('r.linear_pair(normalized,') == 2
assert candidate.count('linear_attn.in_proj_z.weight') == original.count('linear_attn.in_proj_z.weight')
assert 'M>=2' not in helper and 'rows == 1' not in helper
snapshot = W / 'source/engine/models/qwen35/main.cc'
snapshot.parent.mkdir(parents=True, exist_ok=True)
if snapshot.exists():
    assert snapshot.read_bytes() == candidate.encode('utf-8'), 'Do not overwrite an earlier source'
else:
    snapshot.write_bytes(candidate.encode('utf-8'))
patch = W / 'candidate.patch'
patch_text = ''.join(difflib.unified_diff(original.splitlines(True), candidate.splitlines(True),
                 fromfile='engine/models/qwen35/main.cc',
                 tofile='scratch-candidate/engine/models/qwen35/main.cc'))
if patch.exists():
    assert patch.read_bytes() == patch_text.encode('utf-8')
else:
    patch.write_text(patch_text, encoding='utf-8', newline='\n')

# Reuse the successful real CLI Model recipe; no copied headers/SDK. Relative
# quote includes fall through to the original canonical Model include directory.
seed = read(SEED / 'ready-model.json')
args = read(seed['compiled']['command']['path'])['command']
old_source = read(seed['compiled']['dependencies']['path'])['Data']['Source']
command = []
for index, value in enumerate(args):
    if value.lower().replace('\\', '/') == old_source.lower().replace('\\', '/'):
        value = str(snapshot)
    elif index and args[index - 1].lower() == '/sourcedependencies':
        value = str(W / 'compile/model/dependencies.json')
    elif value.lower().startswith('/fo'):
        value = '/Fo' + str(W / 'compile/model/unit.obj')
    elif value.lower().startswith('/fd'):
        value = '/Fd' + str(W / 'compile/model/unit.pdb')
    command.append(value)
assert command.count(str(snapshot)) == 1
save(W / 'recipe-model-draft.json', {'command': command, 'timeout_seconds': 300,
    'status': 'DRAFT_NOT_AUTHORIZED_TO_EXECUTE_OR_FROZEN',
    'required_before_execution': 'Root binds current ON closure and freezes actual canonical engine/project dependencies; source snapshot and old CLI recipe alone are not an ABI closure.'})

on_plan = read(ON / 'plan.json')
sdk_delta = []
for name in ('native-artifact', 'cuda-provider', 'cuda-policy', 'graph-packed',
             'graph-dense', 'graph-context', 'torch-artifact', 'native-kernel'):
    unit = on_plan['units'][name]
    compiled = ON / 'compile' / name / 'compiled.json'
    receipt = read(compiled) if compiled.exists() else None
    sdk_delta.append({'unit': name, 'source': unit['source'],
                      'old_object': unit['old_object'],
                      'new_compiled_receipt': pin(compiled) if receipt else None,
                      'new_object': receipt.get('object') if receipt else None,
                      'action': 'retain already successful current ON object; never rebuild for this candidate'})
save(W / 'preparation.json', {
    'status': 'SCRATCH_CANDIDATE_AND_DRAFT_RECIPE_READY_NOT_FROZEN_NOT_BUILT',
    'canonical_source': pin(SOURCE), 'candidate_source': pin(snapshot), 'diff': pin(patch),
    'helper': pin(Path(__file__).resolve()), 'seed_ready': pin(SEED / 'ready-model.json'),
    'compile_recipe_draft': pin(W / 'recipe-model-draft.json'),
    'changed': 'One cold mathematical helper and exactly two GDN target a/b callsites. No native/provider/weights/default source edits. Refinement2 returns no group before emitting any nodes on ineligibility, preserving original encoded-branch node emission order at the original callsites.',
    'eligibility': 'Same real BF16 rank2 A, two immutable plain dense StoredProjection BF16[N,K], same K, BF16 output, F32 accumulation; other original branches call original emit_projection unchanged.',
    'shape_policy': 'No M1/M2/shape whitelist or user switch; existing M1 paired route is knowingly displaced in candidate and remains the unmodified control.',
    'math_boundaries': 'Separate original BF16 result boundaries, a F32 cast and all original reshape/Softplus/Sigmoid/decay math remain. No new quality/bitwise claim.',
    'cold_resources': 'Original constant bindings and Graph ConstantArtifact ownership; no extra Model output or host packed bank. Expected 128KiB per layer/family for current a/b; 18layers=2.25MiB logical payload, cross-family dedup and actual peak unknown.',
    'on_sdk_delta_from_old_cli': sdk_delta,
    'other_cpu_delta': 'The old CLI seed predates current CPU facade deletion: final binding must also remove legacy default_rules OBJ and use the successful current five CPU SDK objects from current ON base_sdk. Prefer ON current SDK inventory rather than hand-subtracting the seed.',
    'link_recipe_status': 'PENDING_CURRENT_ON_CLI_BINDING: use actual current ON SDK inventory, retain real CLI entry and compatible weights, replace only Model for candidate; candidate link alone is one link, no leaf/gtests or old ATen native packed OBJ.',
    'work_plan': {'modes': ['ordinary-auto', 'MTP'], 'scenarios': ['single', 'two-turn'],
                  'consistency': 'Full non-time reports and complete state/RNG/epoch/old-checkpoint oracles first; retain actual differences, do not broaden ignore lists.',
                  'performance': 'If root schedules after actual numerical/resource review, same-window control/candidate four metrics with existing timing+independent-memory runner; no peer full window or new leaf matrix.'},
    'known_risks': ['M1 leaf +20% device interval; default paired route must remain control.',
                    'M2/T154 strided a Cast privately materialized 64/4928B D2D in old leaf; Graph copy_bytes0 does not prove zero payload copies.',
                    'T154 retained 562.176us long sample and worse mean.',
                    'Actual hidden input can change BF16 rounding/IDs/acceptance; no whole-model speed, quality or VRAM conclusion yet.'],
    'counts_executed_here': {'CXX': 0, 'links': 0, 'native': 0, 'GPU': 0, 'downloads': 0},
})
print(json.dumps({'candidate': pin(snapshot), 'patch': pin(patch),
                  'preparation': pin(W / 'preparation.json'), 'frozen': False}, indent=2))
