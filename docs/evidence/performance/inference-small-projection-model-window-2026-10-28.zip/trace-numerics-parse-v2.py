"""Offline schema correction only: read the four already-successful processes.

The immutable original helper/plan and all original native receipts stay intact.
This module has no model/compiler execution entry point.
"""
from pathlib import Path
import importlib.util
import json
import sys

sys.dont_write_bytecode = True
M = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('original_full_trace_byte_comparator', M / 'trace-numerics.py')
h = importlib.util.module_from_spec(spec); spec.loader.exec_module(h)
W = h.W


def report(e):
    folder = Path(e['folder']); process = h.read(folder / 'process.json')
    assert process['state'] == 'TERMINAL' and process['exit'] == 0 and process['timed_out'] is False, process
    assert h.read(folder / 'command.json')['command'] == e['command']
    raw = h.read(folder / 'stdout.log')
    assert raw['decode_overlap'] is False and raw['live_committed_versions'] == 0
    assert raw['session_count'] == len(raw['sessions']) == 1 and raw['turn_count'] == 1
    session = raw['sessions'][0]; value = session['result']
    assert isinstance(value['generated_ids'], list) and value['generated_tokens'] == len(value['generated_ids']) == 4
    assert raw['generated_tokens'] == value['generated_tokens'] and value['requested_steps'] == 4
    assert len(value['turns']) == 1 and value['turns'][0]['input_ids'] == list(map(int, Path(e['prompt']['path']).read_text().split()))
    assert len(value['turns'][0]['input_ids']) == value['turns'][0]['new_user_tokens'] == 154
    assert value['sampling'] == 'greedy' and value['sampling_seed'] == value['sampling_draw_cursor'] == 0
    assert value['mtp'] is (e['role'] == 'mtp')
    assert isinstance(session['ledger'], list) and len(session['ledger']) == value['graph_participations']
    assert len(session['ledger']) == len(value['rounds']) + 1
    return dict(raw=raw, session=session, result=value,
                receipt=h.pin(folder / 'process.json'), stdout=h.pin(folder / 'stdout.log'),
                command=h.pin(folder / 'command.json'))


def main():
    plan = h.read(W / 'plan.json'); h.exact(plan['helper'])
    entries = {e['name']: e for e in plan['entries']}
    assert set(entries) == set(h.CASES)
    reports = {name: report(e) for name, e in entries.items()}
    comparisons = []; semantic = []; layouts = []; all_equal = True
    for role in ('ordinary', 'mtp'):
        control, candidate = (entries[role + '-' + v] for v in ('control', 'candidate'))
        a, b = (reports[role + '-' + v] for v in ('control', 'candidate'))
        x, y = a['result'], b['result']
        ids_equal = x['generated_ids'] == y['generated_ids']
        ledger_equal = a['session']['ledger'] == b['session']['ledger']
        rounds_equal = x['rounds'] == y['rounds']
        frontier_fields = ('visible_tokens', 'emitted_pending', 'fresh_next_id', 'sampling_stream',
                           'sampling_draw_cursor', 'actual_target_rows', 'committed_target_rows',
                           'committed_target_decode_rows', 'verified_target_rows')
        if role == 'mtp':
            frontier_fields += ('draft_frontier', 'draft_lag', 'draft_rows', 'consumed_drafts',
                                'actual_draft_rows', 'agreements', 'draft_rounds')
        frontiers_equal = all(x[k] == y[k] for k in frontier_fields)
        turns = [{k: t[k] for k in t if k not in ('prefill_seconds', 'decode_seconds')} for t in x['turns']]
        other_turns = [{k: t[k] for k in t if k not in ('prefill_seconds', 'decode_seconds')} for t in y['turns']]
        turns_equal = turns == other_turns
        semantic.append(dict(role=role, generated_ids_equal=ids_equal,
            control_generated_ids=x['generated_ids'], candidate_generated_ids=y['generated_ids'],
            complete_ledger_equal=ledger_equal, control_ledger=a['session']['ledger'],
            candidate_ledger=b['session']['ledger'], complete_rounds_equal=rounds_equal,
            actual_rounds_control=x['rounds'], actual_rounds_candidate=y['rounds'],
            logical_frontiers_equal=frontiers_equal,
            control_frontiers={k: x[k] for k in frontier_fields}, candidate_frontiers={k: y[k] for k in frontier_fields},
            non_timing_turns_equal=turns_equal, control_turns=turns, candidate_turns=other_turns))
        all_equal = all_equal and ids_equal and ledger_equal and rounds_equal and frontiers_equal and turns_equal
        left, right = h.tensor_manifest(control['trace']), h.tensor_manifest(candidate['trace'])
        assert left.keys() == right.keys(), 'Completed call/tensor sets differ: do not rerun or relax the comparison'
        call_dirs = sorted({str(p.parent.relative_to(Path(control['trace']))) for p in left.values()})
        assert len(call_dirs) == x['graph_participations'] == y['graph_participations']
        for name in sorted(left):
            result = h.equal_payload(left[name], right[name]); all_equal = all_equal and result['byte_equal']
            comparisons.append(dict(role=role, relative_path=name, **result))
        for name in call_dirs:
            x_layout, y_layout = (h.read(Path(e['trace']) / name / 'kv-layout.json') for e in (control, candidate))
            logical_equal = all(x_layout[k] == y_layout[k] for k in ('visible_tokens', 'page_rows'))
            all_equal = all_equal and logical_equal
            layouts.append(dict(role=role, completed_call=name, logical_frontier_equal=logical_equal,
                control=x_layout, candidate=y_layout, physical_page_IDs_are_not_payload=True))
    outcome = dict(status='PASS_FOUR_FINITE_EXPORTED_TENSOR_BIT_CHECKS' if all_equal else 'STOP_EXPORTED_TENSOR_OR_DECISION_DIFFERENCE',
        original_plan=h.pin(W / 'plan.json'), original_helper=plan['helper'], offline_parser=h.pin(__file__),
        parser_amendment=dict(original_offline_exception="KeyError: 'generated_ids'",
            cause='Actual CLI emits aggregate report; generated_ids/rounds/turns are in sessions[0].result and committed ledger in sessions[0].ledger.',
            original_helper_and_plan_unchanged=True, native_failures=0, native_retries=0,
            correction='Only output-schema access; complete original tensor-set/extent/bit checks preserved; no numerical tolerance or result substituted.'),
        native_processes=4, actual_original_processes={name: {k: r[k] for k in ('receipt', 'stdout', 'command')} for name, r in reports.items()},
        semantic=semantic, layouts=layouts, compared_tensors=len(comparisons),
        complete_compared_bytes=sum(v['bytes'] for v in comparisons),
        byte_equal_tensors=sum(v['byte_equal'] for v in comparisons), tensors=comparisons,
        numerical_tolerance=None, automatic_reruns=0, performance_claim=False,
        full_unexported_state_checked=False, nonfinite_check_claim=False,
        actual_branch_scope='One MTP proposal accepted, followed by quota-one single catch-up. No rejected-proposal branch claimed.',
        limits=plan['limits'],
        scope='Current control versus N32 candidate separately in ordinary/MTP, same P154 and four greedy outputs. Every exported complete logits/hidden/conv/GDN payload is compared; no natural-text readability gate.')
    h.save(W / 'analysis.json', outcome)
    print(json.dumps({k: outcome[k] for k in ('status', 'native_processes', 'compared_tensors', 'complete_compared_bytes', 'byte_equal_tensors')}))
    assert all_equal, 'Numerical difference preserved: investigate original arithmetic, never relax tolerance or rerun successful native processes'


if __name__ == '__main__': main()
