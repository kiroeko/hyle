"""One explicit candidate CXX; two explicit links on the same successful ON inputs."""
from pathlib import Path
import importlib.util
import sys

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = W.parents[3]
ON = R / '.scratch/inference-optional-aten-20261028/validation'
OLD = R / '.scratch/inference-store-cohort-20261028/cli'
SOURCE = R / 'engine/models/qwen35/main.cc'
spec = importlib.util.spec_from_file_location('ab_original_windows_driver', R / '.scratch/inference-indexed-store-20261028/build.py')
t = importlib.util.module_from_spec(spec); spec.loader.exec_module(t); t.W = W


def freeze():
    draft = t.read(W / 'preparation.json')
    for name in ('canonical_source', 'candidate_source', 'diff'): t.exact(draft[name])
    old = t.read(OLD / 'ready-model.json')
    old_compiled = old['compiled']
    for name in ('object', 'command', 'dependencies', 'actual_dependencies'): t.exact(old_compiled[name])
    assert old_compiled['source']['sha256'] == t.pin(SOURCE)['sha256']
    original_dependencies = t.read(old_compiled['actual_dependencies']['path'])
    project = []
    for row in original_dependencies:
        if t.project(row['path']):
            t.exact(row)  # Byte proof for retaining the original control Model OBJ.
            project.append(t.pin(row['path']))
    assert project and len(project) == len({t.key(p['path']) for p in project})
    t.save(W / 'project-dependencies.json', project)
    on = t.read(ON / 'ready-resident-graph.json')
    for name in ('inputs', 'recipe', 'runtime', 'source_freeze'): t.exact(on[name])
    units = {}
    for name in ('native-artifact', 'cuda-provider', 'cuda-policy', 'graph-packed',
                 'graph-dense', 'graph-context', 'torch-artifact', 'native-kernel'):
        receipt = ON / 'compile' / name / 'compiled.json'
        compiled = t.read(receipt)
        assert compiled['process']['exit'] == 0 and not compiled['process']['timed_out']
        for field in ('source', 'object', 'command', 'actual_dependencies'): t.exact(compiled[field])
        checked = []
        for row in t.read(compiled['actual_dependencies']['path']):
            canonical = t.canonical(row['path'])
            if t.project(canonical):
                actual = t.pin(canonical)
                assert (actual['bytes'], actual['sha256']) == (row['bytes'], row['sha256']), canonical
                checked.append(actual)
        units[name] = dict(receipt=t.pin(receipt), object=compiled['object'], source=compiled['source'],
                           actual_dependencies=compiled['actual_dependencies'], current_project_checks=checked)
    inputs = t.read(on['inputs']['path']); assert len(inputs) == 228
    consumer = on['compiled']['resident-graph']['object']
    old_inputs = t.read(old['inputs']['path'])
    entry = next(p for p in old_inputs if t.key(p['path']).endswith('\\engine\\entry\\unit.obj'))
    assert consumer in inputs and entry not in inputs
    retained = [row for row in inputs if row != consumer] + [entry, old_compiled['object']]
    stats = []
    for row in retained:
        st = Path(row['path']).stat(); assert st.st_size == row['bytes'], row['path']
        stats.append(dict(path=row['path'], bytes=st.st_size, mtime_ns=st.st_mtime_ns,
                          retained_sha256=row['sha256']))
    t.save(W / 'retained-input-stats.json', stats)
    env = t.read(ON / 'environment.json'); env['PATH'] = str(W / 'bin') + ';' + env['PATH']
    t.save(W / 'environment.json', env)
    native = t.read(on['runtime']['path'])['native']; t.exact(native)
    t.save(W / 'runtime.json', dict(PATH=env['PATH'], native=native))
    candidate_link = t.command(W / 'link-model-draft.json')
    control_link = []
    for arg in candidate_link:
        if t.key(arg) == t.key(W / 'compile/model/unit.obj'): arg = old_compiled['object']['path']
        for prefix, suffix in (('/OUT:', '.exe'), ('/PDB:', '.pdb'), ('/IMPLIB:', '.lib'), ('/MAP:', '.map')):
            if arg.upper().startswith(prefix):
                arg = prefix + str((W / 'bin/hyle-ab-group-control').with_suffix(suffix)); break
        control_link.append(arg)
    t.save(W / 'link-control.json', dict(command=control_link, timeout_seconds=240))
    frozen = dict(canonical_model=t.pin(SOURCE), candidate=draft['candidate_source'],
                  project_dependencies=t.pin(W / 'project-dependencies.json'),
                  original_model_actual_dependencies=old_compiled['actual_dependencies'],
                  control_model=old_compiled, on_units=units, helper=t.pin(__file__),
                  driver=t.pin(R / '.scratch/inference-indexed-store-20261028/build.py'),
                  scope='Current canonical project includes only; no copied headers/SDK. All original control Model project includes byte-identical. Test EXE/importlib never read.')
    t.save(W / 'source-freeze.json', frozen)
    t.save(W / 'build-plan.json', dict(status='FROZEN_ROOT_EXECUTES_ONLY',
        frozen=t.pin(W / 'source-freeze.json'), on_ready=t.pin(ON / 'ready-resident-graph.json'),
        on_inputs=on['inputs'], consumer=consumer, entry=entry, retained_stats=t.pin(W / 'retained-input-stats.json'),
        compile_recipe=t.pin(W / 'recipe-model-draft.json'), candidate_link=t.pin(W / 'link-model-draft.json'),
        control_link=t.pin(W / 'link-control.json'), environment=t.pin(W / 'environment.json'),
        runtime=t.pin(W / 'runtime.json'), counts=dict(CXX=1, links=2, inputs_per_image=229, SDK=0, NVCC=0),
        control_scope='Retain dfa9 original Model OBJ, byte-identical current Model/source project includes, same current ON SDK/weights/entry as candidate. dfa9 executable itself is not used.'))
    print('READY: compile; link control; link candidate. 1CXX +2links, common ON229, no test EXE dependency.')


def validate():
    plan = t.read(W / 'build-plan.json')
    for name in ('frozen', 'on_ready', 'on_inputs', 'retained_stats', 'compile_recipe',
                 'candidate_link', 'control_link', 'environment', 'runtime'): t.exact(plan[name])
    frozen = t.read(plan['frozen']['path'])
    for name in ('canonical_model', 'candidate', 'project_dependencies',
                 'original_model_actual_dependencies', 'helper', 'driver'): t.exact(frozen[name])
    for row in t.read(frozen['project_dependencies']['path']): t.exact(row)
    for unit in frozen['on_units'].values():
        for name in ('receipt', 'object', 'source', 'actual_dependencies'): t.exact(unit[name])
        for row in unit['current_project_checks']: t.exact(row)
    return plan, frozen


def parse_compile():
    plan, frozen = validate()
    out = W / 'compile/model'; process = t.read(W / 'logs/model/process.json')
    assert process['exit'] == 0 and not process['timed_out']
    allowed = {t.key(p['path']): p for p in t.read(frozen['project_dependencies']['path'])}
    allowed[t.key(frozen['candidate']['path'])] = frozen['candidate']
    actual = []
    for path in dict.fromkeys(t.dep_paths(out / 'dependencies.json')):
        if t.project(path) or t.key(path) == t.key(frozen['candidate']['path']):
            assert t.key(path) in allowed, ('Metadata error after successful CXX; repair offline only, do not recompile', str(path))
            t.exact(allowed[t.key(path)])
        actual.append(t.pin(path))
    t.save(out / 'actual-dependencies.json', actual)
    t.save(out / 'compiled.json', dict(source=frozen['canonical_model'], snapshot=frozen['candidate'],
        object=t.pin(out / 'unit.obj'), command=t.pin(W / 'logs/model/command.json'),
        dependencies=t.pin(out / 'dependencies.json'), actual_dependencies=t.pin(out / 'actual-dependencies.json'), process=process))
    print('Candidate actual CXX metadata recorded; never rerun a successful CXX for parser errors.')


def compile_model():
    plan, _ = validate(); (W / 'compile/model').mkdir(parents=True, exist_ok=False)
    t.execute(t.command(plan['compile_recipe']['path']), W / 'logs/model', 300)
    parse_compile()


def link_model(arm):
    assert arm in ('control', 'candidate')
    plan, frozen = validate()
    for row in t.read(plan['retained_stats']['path']):
        st = Path(row['path']).stat()
        assert (st.st_size, st.st_mtime_ns) == (row['bytes'], row['mtime_ns']), row['path']
    compiled = frozen['control_model'] if arm == 'control' else t.read(W / 'compile/model/compiled.json')
    t.exact(compiled['object'])
    rows = [compiled['object'] if row == plan['consumer'] else row for row in t.read(plan['on_inputs']['path'])]
    rows.append(plan['entry'])
    assert len(rows) == len({t.key(row['path']) for row in rows}) == 229
    t.save(W / f'inputs-{arm}.json', rows); (W / 'bin').mkdir(exist_ok=True)
    native = t.read(plan['runtime']['path'])['native']; alias = W / 'bin' / Path(native['path']).name
    if not alias.exists(): alias.hardlink_to(native['path'])
    assert alias.samefile(native['path'])
    recipe = plan['control_link' if arm == 'control' else 'candidate_link']
    process = t.execute(t.command(recipe['path']), W / 'link' / arm, 240)
    t.save(W / f'ready-{arm}.json', dict(image=t.pin(W / f'bin/hyle-ab-group-{arm}.exe'),
        inputs=t.pin(W / f'inputs-{arm}.json'), compiled=compiled, process=process,
        recipe=t.pin(W / 'link' / arm / 'command.json'), runtime=plan['runtime'],
        source_freeze=plan['frozen'], plan=t.pin(W / 'build-plan.json'), closure_inputs=229,
        role=arm, source_math='Original two projections' if arm == 'control' else 'Scratch a+b ConstantConcat/MatMul/two Views'))
    print(arm, 'LINK READY: same ON SDK, weights, entry; exactly Model OBJ differs')


if __name__ == '__main__':
    action = sys.argv[1]
    if action in ('prepare', 'freeze'): freeze()
    elif action == 'preflight': validate(); print('PREFLIGHT PASS')
    elif action == 'compile': compile_model()
    elif action == 'parse-compile': parse_compile()
    elif action == 'link': link_model(sys.argv[2])
    else: raise SystemExit('freeze | preflight | compile | parse-compile | link control|candidate')
