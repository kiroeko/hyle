from pathlib import Path
import hashlib,json,subprocess,zipfile
ROOT=Path.cwd();BASE=ROOT/'.scratch/inference-gaps/g04-g05'
OUT=BASE/'cpu-encoded-p1-qualification-3';SOURCE=Path('C:/h7/g04-cpu-encoded-p1-source-3')
job=json.loads((BASE/'cpu-encoded-p1-job-3.json').read_text(encoding='utf-8'))
assert job['state']=='TERMINAL'
assert not subprocess.check_output(['git','-C',str(SOURCE),'status','--porcelain'],text=True).strip()
assert subprocess.check_output(['git','-C',str(SOURCE),'rev-parse','HEAD'],text=True).strip()==job['source_commit']
contract=SOURCE/'bench/inference_resident_sdpa/cpu_encoded_p1/contract.json'
args=['python',str(SOURCE/'scripts/hyle-perf.py'),'verify','--contract',str(contract),'--manifest',str(OUT/'manifest.json')]
verified=subprocess.run(args,capture_output=True,text=True,encoding='utf-8')
summary=json.loads((OUT/'summary.json').read_text(encoding='utf-8'))
manifest=json.loads((OUT/'manifest.json').read_text(encoding='utf-8'))
declared=json.loads(contract.read_text(encoding='utf-8'))
stages=manifest['extensions']['sample_stages']
assert stages and stages==declared['experiment']['sample_schedule'][:len(stages)]
assert declared['experiment']['sample_schedule']==[15,31]
raw_index=json.loads((OUT/'raw-log-index.json').read_text(encoding='utf-8'))
assert raw_index['sample_stages']==stages
rows=[]
for w in summary['workloads']:
 ratios=[s['estimate']['median_advantage_ratio'] for s in w['strata']]
 cis=[s['estimate']['confidence_interval'] for s in w['strata']]
 rows.append({'id':w['id'],'ratio_range':[min(ratios),max(ratios)],
     'noninferiority':w['combined_noninferiority_gate'],'exact':w['combined_exact_verdict'],
     'direction':'WIN' if all(c[0]>1 for c in cis) else 'LOSS' if all(c[1]<1 for c in cis) else 'INCONCLUSIVE'})
assert len(rows)==3
aa=json.loads((OUT/'cpu-encoded-aa.json').read_text(encoding='utf-8'))
logs=list((OUT/'raw').rglob('*.log'))
products=sum(p.name.startswith('product-') for p in logs)
controls=sum(p.name.startswith('control-') for p in logs)
assert len(aa['runs'])==16 and aa['gate']=='PASS'
assert products==len(declared['strata'])*sum(stages) and controls==2*sum(stages),(products,controls,stages)
assert products==sum(r['kind']=='product' for r in raw_index['entries'])
assert controls==sum(r['kind']=='control' for r in raw_index['entries'])
previous_path=ROOT/'evidence/performance/inference-g04-g05-cpu-encoded-w1-p1/receipt.json'
previous=json.loads(previous_path.read_text(encoding='utf-8'))
assert previous['qualification']=='QUALIFIED' and previous['performance']=='FAIL'
rebind_path=ROOT/'evidence/correctness/inference-g04-g05-ce12-cpu-validation/p1-rebind.json'
rebind=json.loads(rebind_path.read_text(encoding='utf-8'))
dest=ROOT/'evidence/performance/inference-g04-g05-ce12-cpu-encoded-w1-p1'
dest.mkdir(exist_ok=False)
for name in ('summary.json','manifest.json','observations.jsonl','raw-log-index.json'):(dest/name).write_bytes((OUT/name).read_bytes())
(dest/'verify-receipt.json').write_text(json.dumps({'command':args,'exit_code':verified.returncode,'stdout':verified.stdout,'stderr':verified.stderr},indent=2)+'\n',encoding='utf-8')
with zipfile.ZipFile(dest/'raw.zip','w',zipfile.ZIP_DEFLATED) as z:
 for attempt in (3,):
  folder=BASE/f'cpu-encoded-p1-qualification-{attempt}'
  for p in sorted(folder.rglob('*')):
   if p.is_file():z.write(p,f'qualification-{attempt}/'+str(p.relative_to(folder)))
  for name in (f'cpu-encoded-p1-job-{attempt}.json',f'cpu-encoded-p1-qualification-{attempt}.log'):
   z.write(BASE/name,name)
 for name in ('ce12_cpu_p1.py','rebind_ce12_cpu_p1.py','seal_ce12_cpu_p1.py'):
  z.write(BASE/name,'runners/'+name)
 for file in sorted((BASE/'ce12').glob('before-rebind-*')):z.write(file,'artifact-rebind/'+file.name)
 z.write(BASE/'ce12/p1-rebind.json','artifact-rebind/p1-rebind.json')
passed=summary['qualification']=='QUALIFIED' and verified.returncode==0 and job['exit_code']==0 and all(r['noninferiority']=='PASS' for r in rows)
receipt={'kind':'G04_G05_CE12_CPU_Q8_RESIDENT_WARM_FINITE_P1','product_candidate':job['product_candidate'],
 'performance_source':job['source_commit'],'contract_sha256':summary['contract_sha256'],
 'qualification':summary['qualification'],'performance':'PASS' if passed else ('FAIL' if summary['qualification']=='QUALIFIED' else 'UNPROVEN'),
 'verify_exit':verified.returncode,'job_exit':job['exit_code'],'runs':previous['runs']+[job],
 'original_qualified_failure':{'path':str(previous_path.relative_to(ROOT)),'sha256':hashlib.sha256(previous_path.read_bytes()).hexdigest(),'verdict':previous['performance']},
 'semantic_artifact_rebind':rebind,
 'cumulative_seconds':previous['cumulative_seconds']+job['elapsed_seconds'],
 'current_attempt_seconds':job['elapsed_seconds'],
 'aa_processes':len(aa['runs']),'aa_verdict':aa['gate'],'product_processes':products,'control_processes':controls,
 'sample_stages':stages,'final_stage_product_processes':len(declared['strata'])*stages[-1],
 'sampling_scope':'Original automatic n15->n31 rule only; earlier raw stage retained, final observations use final stage without pooling',
 'rows':rows,'peer_cold_extra_cache_bytes':{'D256':1949696,'D64_Dv128':22032},
 'scope':'Q8_0/BF16, ready immutable physical-page warm attention; window16 D256, unbounded prefill D256, full noncausal Q>KV D64/Dv128; actual original pristine ffa CPU DLL',
 'limits':['No dirty producer/growth/G06/GPU/whole G04-G05/token-s qualification','Native private pool upper remains UNKNOWN; peer cold cache/mask costs explicit'],
 'raw_zip_sha256':hashlib.sha256((dest/'raw.zip').read_bytes()).hexdigest()}
(dest/'receipt.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(receipt,ensure_ascii=False),flush=True)
