from pathlib import Path
import copy,hashlib,json
ROOT=Path.cwd();BASE=ROOT/'.scratch/inference-gaps/g04-g05';FOLDER=ROOT/'bench/inference_resident_sdpa/cpu_encoded_p1'
sdk=json.loads((BASE/'cpu-sdk/result-cpu-static-ce12-1.json').read_text());assert sdk['state']=='TERMINAL_PASS'
assert json.loads((BASE/'ce12/post-source-1/result.json').read_text())['state']=='TERMINAL_PASS'
for row in json.loads((BASE/'cpu-sdk/artifacts-cpu-static-ce12-1.json').read_text()):assert hashlib.sha256(Path(row['path']).read_bytes()).hexdigest()==row['sha256']
path=FOLDER/'contract.json';before=json.loads(path.read_text());after=copy.deepcopy(before)
cache=after['extensions']['runner']['cmake']['cache'];assert cache['CMAKE_PREFIX_PATH']=='C:/h7/g04-sdk-cpu-static-1/relocated'
assert sdk['prefix'].replace('\\','/')=='C:/h7/g04-sdk-cpu-static-ce12-1/relocated'
record=BASE/'ce12/p1-rebind.json';assert not record.exists()
for name in ('contract.json','consumer-provenance.json','consumer-provenance.md'):(BASE/'ce12'/('before-rebind-'+name)).write_bytes((FOLDER/name).read_bytes())
doc=FOLDER/'consumer-provenance.md';body=doc.read_text()
old='Installed static SDK is the independently tested f772 product, with every linked\nlibrary/program SHA authenticated.'
new='The original qualified run used the f772 static SDK and retained its material\nperformance FAIL. CE12 uses the independently tested 5f9b261bf static SDK at\nC:/h7/g04-sdk-cpu-static-ce12-1/relocated; every linked library/program SHA is\nauthenticated against the new SDK receipt. The semantic workload/lifecycle,\nfixtures, instrumentation, schedule and5% margin are unchanged.'
assert old in body;body=body.replace(old,new).replace('No P1 started at provenance creation.','Original qualification/FAIL remains immutable; the CE12 repeat has not started at this update.')
doc.write_text(body,encoding='utf-8',newline='\n')
provenance_path=FOLDER/'consumer-provenance.json';provenance=json.loads(provenance_path.read_text());provenance['sha256']=hashlib.sha256(doc.read_bytes()).hexdigest()
provenance_path.write_text(json.dumps(provenance,indent=2)+'\n',encoding='utf-8',newline='\n')
sha=hashlib.sha256(provenance_path.read_bytes()).hexdigest();cache['CMAKE_PREFIX_PATH']='C:/h7/g04-sdk-cpu-static-ce12-1/relocated'
for workload in after['workloads']:workload['provenance']['sha256']=sha
normalized=copy.deepcopy(after);normalized['extensions']['runner']['cmake']['cache']['CMAKE_PREFIX_PATH']=before['extensions']['runner']['cmake']['cache']['CMAKE_PREFIX_PATH']
for old_workload,new_workload in zip(before['workloads'],normalized['workloads']):new_workload['provenance']=old_workload['provenance']
assert normalized==before,'only SDK artifact prefix and supporting provenance hashes may change'
path.write_text(json.dumps(after,indent=2)+'\n',encoding='utf-8',newline='\n')
record.write_text(json.dumps({'kind':'CE12_CPU_P1_ARTIFACT_REBIND','original_qualified_contract_sha256':json.loads((ROOT/'evidence/performance/inference-g04-g05-cpu-encoded-w1-p1/receipt.json').read_text())['contract_sha256'],'new_contract_file_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'semantic_diff':'NONE; only new SDK prefix and supporting provenance hash binding','prefix':cache['CMAKE_PREFIX_PATH'],'prior_performance':'FAIL preserved; no samples/margins/fixtures changed'},indent=2)+'\n')
print(record.read_text())
