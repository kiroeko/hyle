from pathlib import Path
import hashlib,json,os,subprocess,time
ROOT=Path.cwd();BASE=ROOT/'.scratch/inference-gaps/g04-g05';OUT=BASE/'cpu-encoded-p1-qualification-3'
SOURCE=Path('C:/h7/g04-cpu-encoded-p1-source-3');BUILD=Path('C:/h7/g04-cpu-encoded-p1-build-3')
assert not OUT.exists() and not SOURCE.exists() and not BUILD.exists()
assert not subprocess.check_output(['git','status','--porcelain'],text=True).strip()
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
registry=json.loads((ROOT/'docs/implementation/module-status.json').read_text(encoding='utf-8'))
owner=next(m for m in registry['modules'] if m['module']=='compute_provider_ggml')
assert owner['state']=='CANDIDATE'
candidate=owner['candidate']
assert subprocess.check_output(['git','diff','--name-only','982676cb05a6e6244e66e0a596347aa96043617b',head,'--','src','include','cmake','third_party'],text=True).splitlines()==['cmake/HyleComponents.cmake','src/compute_provider_ggml/ggml_cpu_provider.cc']
assert not subprocess.check_output(['git','diff','--name-only',candidate,head,'--','src','include','cmake','third_party'],text=True).strip()
registry=json.loads((ROOT/'docs/implementation/module-status.json').read_text(encoding='utf-8'))
assert sum(m.get('candidate')=='982676cb05a6e6244e66e0a596347aa96043617b' and m['state']=='CANDIDATE' and m.get('record','').endswith('inference-g04-g05-cache-attention-domain.md') for m in registry['modules'])==10
for row in json.loads((BASE/'cpu-sdk/artifacts-cpu-static-ce12-1.json').read_text(encoding='utf-8')):assert hashlib.sha256(Path(row['path']).read_bytes()).hexdigest()==row['sha256']
identity=json.loads((ROOT/'.scratch/inference-gaps/g01/cpu-paged-original-identity.json').read_text(encoding='utf-8'))
for name,sha in identity['original_dlls'].items():assert hashlib.sha256(Path(name).read_bytes()).hexdigest()==sha
peer=ROOT/'.scratch/inference-gaps/g01/original-ggml-cpu-peer'
assert subprocess.check_output(['git','-C',str(peer),'rev-parse','HEAD'],text=True).strip()=='ffa4e8b80930029a35991f94e7c8a93cd67730ab'
assert not subprocess.check_output(['git','-C',str(peer),'status','--porcelain'],text=True).strip()
# Independent disposable validation copy. Never changes canonical source or older evidence trees.
subprocess.run(['git','clone','--shared','--no-checkout',str(ROOT),str(SOURCE)],check=True,stdout=subprocess.DEVNULL)
subprocess.run(['git','-C',str(SOURCE),'checkout','--detach',head],check=True,stdout=subprocess.DEVNULL)
assert not subprocess.check_output(['git','-C',str(SOURCE),'status','--porcelain'],text=True).strip()
setup=subprocess.check_output(['cmd','/d','/c',str(ROOT/'.scratch/inference-gaps/g01/cpu-ragged-env.cmd')],text=True)
env={k.upper():v for k,v in os.environ.items()}
env.update((k.upper(),v) for k,v in (line.split('=',1) for line in setup.splitlines() if '=' in line and not line.startswith('=')))
env['CMAKE_BUILD_PARALLEL_LEVEL']='4'
contract=SOURCE/'bench/inference_resident_sdpa/cpu_encoded_p1/contract.json'
assert json.loads(contract.read_text())['extensions']['runner']['cmake']['cache']['CMAKE_PREFIX_PATH']=='C:/h7/g04-sdk-cpu-static-ce12-1/relocated','must measure the new CE12 SDK, not the retained original failing artifact'
args=['python',str(SOURCE/'scripts/hyle-perf.py'),'qualify-platform','--contract',str(contract),'--source',str(contract.parent),'--machine','W1-WIN','--peer','original-ggml-cpu-flash='+str(peer),'--build',str(BUILD),'--output',str(OUT)]
log=BASE/'cpu-encoded-p1-qualification-3.log';start=time.monotonic()
with log.open('wb') as stream:
 process=subprocess.Popen(args,env=env,stdout=stream,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NO_WINDOW)
 job={'state':'RUNNING','pid':process.pid,'source_commit':head,'product_candidate':candidate,'contract_sha256':hashlib.sha256(contract.read_bytes()).hexdigest(),'source':str(SOURCE),'build':str(BUILD),'output':str(OUT),'log':str(log),'command':args,'heavy_serial':True,'max_compile_jobs':4}
 (BASE/'cpu-encoded-p1-job-3.json').write_text(json.dumps(job,indent=2)+'\n',encoding='utf-8');print(json.dumps(job),flush=True)
 code=process.wait()
job.update(state='TERMINAL',exit_code=code,elapsed_seconds=time.monotonic()-start)
(BASE/'cpu-encoded-p1-job-3.json').write_text(json.dumps(job,indent=2)+'\n',encoding='utf-8');print(json.dumps(job),flush=True)
print(log.read_text(encoding='utf-8',errors='replace')[-4500:],flush=True)
raise SystemExit(code)
