"""One scratch consumer with stage clocks; never changes product math or runtime owners."""
from pathlib import Path
import datetime as dt
import importlib.util
import json
import re
import statistics
import subprocess
import sys
sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('prepare_diagnostic_helpers', S / 'build_experiment.py')
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)
b, c = m.b, m.c
ROOT = S.parent.parents[1]
recipe_path = S.parent / 'decode-next-cold/checks/20261019T155819/29-qwen35_text-main-identity.json'
recipe = c.read(recipe_path)
source = ROOT / 'tools/qwen35_text/main.cc'
assert b.identity(source) == recipe['source']
base = c.read(S.parent / 'cccl-single-row-topk/checks/20261019T185912-host/qwen-link-plan.json')
assert recipe['object'] in base['inputs']
out = S / 'hot-prepare-diagnostic'
out.mkdir(exist_ok=False)
(out / 'tmp').mkdir()
text = source.read_text(encoding='utf-8')
edits = [
    ('    const auto cold_start = Clock::now();',
     '    const auto cold_start = Clock::now();\n    Clock::time_point layout_done, batch_done, binds_done, replay_done;'),
    ('      check(g::batch::prepare(run, queues, layouts, {.host_workspace = planning_memory.ref()}));',
     '      layout_done = Clock::now();\n      check(g::batch::prepare(run, queues, layouts, {.host_workspace = planning_memory.ref()}));\n      batch_done = Clock::now();'),
    ('      check(run.prepare_replay(queues, {.mode = replay_mode, .host_wait = g::HostWaitPolicy::kAllow}));',
     '      binds_done = Clock::now();\n      check(run.prepare_replay(queues, {.mode = replay_mode, .host_wait = g::HostWaitPolicy::kAllow}));\n      replay_done = Clock::now();'),
    ('              << " cold_batch_seconds=" << cold_batch_seconds',
     '              << " cold_batch_seconds=" << cold_batch_seconds\n'
     '              << " layout_us=" << std::chrono::duration<double, std::micro>(layout_done - cold_start).count()\n'
     '              << " batch_us=" << std::chrono::duration<double, std::micro>(batch_done - layout_done).count()\n'
     '              << " binds_us=" << std::chrono::duration<double, std::micro>(binds_done - batch_done).count()\n'
     '              << " replay_us=" << std::chrono::duration<double, std::micro>(replay_done - binds_done).count()')]
for before, after in edits:
    assert text.count(before) == 1
    text = text.replace(before, after)
diagnostic = out / 'main.cc'
diagnostic.write_text(text, encoding='utf-8')
diff = subprocess.run(['git', 'diff', '--no-index', '--', str(source), str(diagnostic)],
                      cwd=ROOT, capture_output=True)
assert diff.returncode == 1
(out / 'instrumentation.diff').write_bytes(diff.stdout)
command = b.host_command(recipe['command'], diagnostic, 'main', out)
link = [str(out / 'main.obj') if c.key(x) == c.key(recipe['object']['path']) else x
        for x in base['command'] if not x.upper().startswith(('/OUT:', '/MAP:', '/IMPLIB:', '/PDB:'))]
image = out / 'qwen-diagnostic.exe'
link += ['/OUT:' + str(image), '/MAP:' + str(image.with_suffix('.map')),
         '/IMPLIB:' + str(image.with_suffix('.lib'))]
frozen = [b.identity(p) for p in (Path(__file__), source, diagnostic, recipe_path)]
c.save(out / 'plan.json', dict(compile=command, link=link, frozen=frozen,
    clock_reads_added_per_step=4, product_patch=False, instrumented=True, throughput_claim=False))
env, runtime = b.environment(base['command'], [r['path'] for r in base['inputs']], out)
c.execute('compile', command, env, out)
deps = c.read(out / 'main-deps.json')['Data']
c.save(out / 'main-identity.json', dict(command=command, source=b.identity(diagnostic),
    object=b.identity(out / 'main.obj'), dependencies=[b.identity(p) for p in [deps['Source'], *deps['Includes']]]))
c.execute('link', link, env, out)
prepared = c.read(S.parent / 'cccl-single-row-topk/performance-prepared/plan.json')
target = next(r['command'] for r in prepared['requests'] if r['arm'] == 'current').copy()
target[0] = str(image)
assert '--trace' not in target
c.save(out / 'inputs.json', dict(image=b.identity(image), command=target,
    runtime_library_directories=runtime, fixed_inputs=prepared['fixed'], profiler=False,
    clocks_in_consumer=True, product_math_or_runtime_owners_changed=False))
c.execute('diagnostic', target, env, out)
actual = json.loads((out / 'diagnostic.stdout.log').read_text().splitlines()[-1])
reference = json.loads((S.parent / 'cccl-single-row-topk/correctness/qwen.stdout.log').read_text().splitlines()[-1])
assert actual['generated_ids'] == reference['generated_ids']
assert actual['decode_input_ids'] == reference['decode_input_ids']
phases = []
for line in (out / 'diagnostic.stderr.log').read_text().splitlines():
    if not line.startswith('prepared T='):
        continue
    fields = dict(re.findall(r'(\w+)=([^ ]+)', line))
    phases.append(dict(phase='prefill' if not phases else 'decode' + str(len(phases)),
        **{key: float(fields[key]) for key in ('layout_us', 'batch_us', 'binds_us', 'replay_us')},
        total_us=float(fields['cold_batch_seconds']) * 1e6,
        capture_recorded=int(fields['capture_recorded']), capture_reused=int(fields['capture_reused'])))
assert len(phases) == 32
warm = phases[7:]
keys = ['layout_us', 'batch_us', 'binds_us', 'replay_us', 'total_us']
c.save(out / 'summary.json', dict(passed=True, phases=phases,
    warm_medians={key: statistics.median(r[key] for r in warm) for key in keys},
    instrumented=True, product_patch=False, throughput_claim=False,
    predictions_and_fixed_inputs_same=True,
    limit='One consumer-stage-clock diagnostic run; added4 clock reads per step. No native/core subfunction attribution, independent numerical/quality or matched speed claim.'))
print('PREPARE_DIAGNOSTIC', {key: statistics.median(r[key] for r in warm) for key in keys}, flush=True)
