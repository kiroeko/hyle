"""Same diagnostic main; original versus refreshed common Graph object."""
from pathlib import Path
import importlib.util
import json
import re
import statistics
import sys
sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
ARCH = S.parent
spec = importlib.util.spec_from_file_location('view_prepare_compare_helpers', S / 'build.py')
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)
b, c = m.b, m.c
path = Path(c.read(S / 'latest-check.json')['plan'])
plan = c.read(path)
assert c.read(S / 'tests/summary.json')['passed'] and c.read(S / 'correctness/summary.json')['passed']
out = S / 'prepare-comparison'
out.mkdir(exist_ok=False)
(out / 'tmp').mkdir()
diagnostic = ARCH / 'projection-hotspot-review/hot-prepare-diagnostic'
main = c.read(diagnostic / 'main-identity.json')
assert b.same(main['object']) and b.same(main['source'])
base = c.read(path.parent / 'qwen-link-plan.json')
old_main = next(r['path'] for r in base['inputs'] if Path(r['path']).name == '29-qwen35_text-main.obj')
command = [main['object']['path'] if c.key(x) == c.key(old_main) else x for x in base['command']
           if not x.upper().startswith(('/OUT:', '/MAP:', '/IMPLIB:', '/PDB:'))]
after = out / 'qwen-diagnostic.exe'
command += ['/OUT:' + str(after), '/MAP:' + str(after.with_suffix('.map')),
            '/IMPLIB:' + str(after.with_suffix('.lib'))]
env, runtime = b.environment(base['command'], [r['path'] for r in base['inputs']], out)
c.execute('link', command, env, out)
images = dict(before=b.identity(diagnostic / 'qwen-diagnostic.exe'), after=b.identity(after))
target = c.read(diagnostic / 'inputs.json')['command']
order = ['before', 'after', 'after', 'before', 'before', 'after']
reference = json.loads((S / 'correctness/qwen.stdout.log').read_text().splitlines()[-1])
c.save(out / 'inputs.json', dict(build_plan=b.identity(path), images=images, command_template=target,
    order=order, runtime_library_directories=runtime, diagnostic_main_object=main['object'],
    only_common_graph_object_differs=True, instrumented=True, profiler=False, throughput_claim=False))
keys = ['layout_us', 'batch_us', 'binds_us', 'replay_us', 'total_us']
runs = []
for index, arm in enumerate(order):
    argv = [images[arm]['path'], *target[1:]]
    tag = str(index + 1) + '-' + arm
    c.execute(tag, argv, env, out)
    actual = json.loads((out / (tag + '.stdout.log')).read_text().splitlines()[-1])
    assert actual['generated_ids'] == reference['generated_ids']
    assert actual['decode_input_ids'] == reference['decode_input_ids']
    phases = []
    for line in (out / (tag + '.stderr.log')).read_text().splitlines():
        if not line.startswith('prepared T='):
            continue
        fields = dict(re.findall(r'(\w+)=([^ ]+)', line))
        phases.append(dict(index=len(phases), **{key: float(fields[key]) for key in keys[:-1]},
            total_us=float(fields['cold_batch_seconds']) * 1e6,
            capture_recorded=int(fields['capture_recorded']), capture_reused=int(fields['capture_reused'])))
    assert len(phases) == 32 and all(r['capture_recorded'] == 0 and r['capture_reused'] == 1 for r in phases[7:])
    medians = {key: statistics.median(r[key] for r in phases[7:]) for key in keys}
    runs.append(dict(arm=arm, tag=tag, phases=phases, warm_medians=medians))
    c.save(out / 'runs.json', runs)
medians = {arm: {key: statistics.median(r['warm_medians'][key] for r in runs if r['arm'] == arm)
                for key in keys} for arm in images}
c.save(out / 'summary.json', dict(passed=True, terminal_zero=6, runs=runs, process_medians=medians,
    instrumented=True, throughput_claim=False, predictions_and_fixed_inputs_same=True,
    limit='Three process pairs in one window;25 correlated warm samples per process. Same4 clock reads/step in same main object. Stage clocks do not resolve core subfunctions and are not uninstrumented throughput.'))
print('PREPARE_COMPARISON', medians, flush=True)
