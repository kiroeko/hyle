"""View projection metadata reuse regression: one fresh fixed-128+31 full-model; --prepare-only starts no model."""
from pathlib import Path
import argparse
import importlib.util
import sys

sys.dont_write_bytecode = True
STAGE = Path(__file__).resolve().parent
ARCH = STAGE.parent
ROOT = ARCH.parents[1]


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('plan', type=Path)
    parser.add_argument('--prepare-only', action='store_true')
    parser.add_argument('--analyze-only', action='store_true')
    parser.add_argument('--destination', default='correctness')
    args = parser.parse_args()
    if args.prepare_only and args.analyze_only:
        raise ValueError('Choose preparation or analysis')
    build = load('dynamic_alias_model_build', STAGE / 'build.py')
    n = load('dynamic_alias_model_numeric', ARCH / 'cuda-bf16-dual-projection/compare_numerics.py')
    b, c = build.b, build.c
    plan_path = args.plan.resolve()
    plan = c.read(plan_path)
    # Check this batch's actual inputs only. No historical build.check(plan) or
    # historical source-freeze admission is called by this runner.
    for row in plan['frozen']:
        if not b.same(row):
            raise ValueError('Current build input changed: ' + row['path'])
    if not c.read(plan_path.parent / 'summary.json')['passed']:
        raise ValueError('Successful current incremental build required')
    reference = ARCH / 'batch-graph-capture/correctness-final'
    vectors = {x.relative_to(reference / 'trace'): n.identity(x)
        for x in sorted((reference / 'trace').rglob('*')) if x.suffix in ('.bf16', '.f32')}
    expected = {Path(phase) / name for phase in n.PHASES for name in ('hidden.bf16', 'logits.f32')}
    if set(vectors) != expected:
        raise ValueError('Expected64 retained model observations')
    if Path(args.destination).name != args.destination or not args.destination.startswith('correctness'):
        raise ValueError('Expected a local correctness directory name')
    out = STAGE / args.destination
    out.mkdir(exist_ok=args.analyze_only or (out / 'inputs.json').exists())
    (out / 'tmp').mkdir(exist_ok=True)
    command = c.read(reference / 'qwen.command.json')['command'].copy()
    command[0] = plan['links']['qwen']['image']
    command[command.index('--trace') + 1] = str(out / 'trace')
    inputs = Path(command[command.index('--inputs') + 1])
    manifest = inputs / 'weights.tsv'
    lines = manifest.read_text(encoding='utf-8').splitlines()
    inventory = c.read(ROOT / 'docs/implementation/tasks/compute/qwen35-2b-local-input.json')
    model = Path(lines[1])
    record = next(x for x in inventory['files'] if x['path'] == model.name)
    model_expected = {'path': str(model), 'bytes': record['size_bytes'], 'sha256': record['sha256']}
    if lines[0] != 'HYLE_QWEN35_TEXT_V1' or lines[2] != inventory['artifact_identity_sha256'] or len(lines[3:]) != 320:
        raise ValueError('Inventory differs')
    prompt = list(map(int, (inputs / 'prompt.ids').read_text().split()))
    decode = list(map(int, Path(command[command.index('--decode-ids') + 1]).read_text().split()))
    if len(prompt) != 128 or len(decode) != 31:
        raise ValueError('Expected128 prompt IDs and31 fixed decode IDs')
    image = b.identity(command[0])
    if image != c.read(plan_path.parent / 'qwen-image.json'):
        raise ValueError('Current image differs')
    receipt = {'plan': b.identity(plan_path), 'runner': b.identity(Path(__file__)), 'image': image,
        'model': model_expected, 'manifest': b.identity(manifest),
        'prompt': b.identity(inputs / 'prompt.ids'), 'decode': b.identity(command[command.index('--decode-ids') + 1]),
        'reference_vectors': list(vectors.values()), 'reference_result': b.identity(reference / 'qwen.stdout.log'),
        'command': command, 'quality_acceptance': False, 'throughput_claim': False,
        'fresh_model_processes_when_run': 1, 'historical_source_freeze_check': False}
    if (out / 'inputs.json').exists():
        if c.read(out / 'inputs.json') != receipt:
            raise ValueError('Prepared model input identity differs')
    else:
        c.save(out / 'inputs.json', receipt)
    if args.prepare_only:
        print('PREPARED_NO_GPU', out / 'inputs.json', flush=True)
        return
    if b.identity(model) != model_expected:
        raise ValueError('Actual model differs')
    link = plan['links']['qwen']
    paths = [r['path'] if isinstance(r, dict) else r for r in link['inputs']]
    env, directories = b.environment(link['command'], paths, out)
    c.save(out / 'runtime-environment.json', {'runtime_link_input_paths': paths,
        'runtime_library_directories': directories, 'CPU_CUDA_cached_input_union_used': False})
    if not args.analyze_only:
        if (out / 'qwen.result.json').exists() or (out / 'trace').exists():
            raise ValueError('No implicit model retry or trace overwrite')
        c.execute('qwen', command, env, out)
    else:
        assert c.read(out / 'qwen.result.json')['exit'] == 0
    observed = n.analyze_arm('current', image, out, vectors, n.final_json(reference / 'qwen.stdout.log'))
    single_range = (len(observed['capture_counts']) == 32 and
        all(row['recorded'] + row['reused'] == 1 and row['replay'] == 'hybrid'
            for row in observed['capture_counts']))
    passed = (observed['equal_vectors'] == 64 and observed['all_outputs_finite'] and
        single_range and observed['same_greedy_ids_as_reference'] and observed['same_fixed_decode_inputs'])
    c.save(out / 'summary.json', {'passed': passed, 'observation': observed,
        'route': 'hybrid', 'sampling_provider_remains_uncaptured': True,
        'single_outer_range_32_phases': single_range, 'quality_acceptance': False,
        'throughput_claim': False, 'fresh_model_processes': 1,
        'limits': 'One fixed-input BF16 Qwen regression versus retained64vectors; no independent model quality, cross-platform or throughput claim. Historical seven-range analyzer field is retained only as its raw observation.'})
    if not passed:
        raise ValueError('Expected64 equal finite observations and unchanged capture journey')
    print('MODEL_CHECK', {'equal_vectors': observed['equal_vectors'], 'passed': passed}, flush=True)


if __name__ == '__main__':
    main()
