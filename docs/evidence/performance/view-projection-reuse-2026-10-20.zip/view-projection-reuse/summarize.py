"""Record exact metadata-reuse results and their limits."""
from pathlib import Path
import datetime as dt
import importlib.util
import sys
sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('view_reuse_summary_helpers', S / 'build.py')
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)
b, c = m.b, m.c
path = Path(c.read(S / 'latest-check.json')['plan'])
tests = c.read(S / 'tests/summary.json')
model = c.read(S / 'correctness/summary.json')
diagnostic = c.read(S / 'prepare-comparison/summary.json')
speed = c.read(S / 'performance-rotation/summary.json')
assert tests['passed'] and tests['cases'] == 14 and tests['skipped'] == 0
assert model['passed'] and model['observation']['equal_vectors'] == 64 and model['observation']['all_outputs_finite']
assert diagnostic['passed'] and diagnostic['terminal_zero'] == 6
assert speed['terminal_zero'] == 9 and speed['same_baseline_predictions_all9']
old = c.read(S.parent / 'cccl-single-row-topk/checks/20261019T185912-host/qwen-link-plan.json')
new = c.read(path.parent / 'qwen-link-plan.json')
old_set = {(c.key(r['path']), r['sha256']) for r in old['inputs']}
new_set = {(c.key(r['path']), r['sha256']) for r in new['inputs']}
assert len(old_set - new_set) == len(new_set - old_set) == 1
first = c.read(S / 'performance-rotation/01-baseline.result.json')
last = c.read(S / 'performance-rotation/09-baseline.result.json')
zone = dt.timezone(dt.timedelta(hours=8))
window = [dt.datetime.fromtimestamp(t, zone).isoformat() for t in (first['started'], last['finished'])]
summary = dict(passed=True, build_plan=b.identity(path),
    images={arm:c.read(path.parent / (arm + '-image.json')) for arm in ('qwen', 'cpu')},
    product_files=['src/graph/executable.cc', 'tests/graph/executable_test.cc'],
    unchanged_private_state=c.read(S / 'source-freeze.json')['PlanState_unchanged'],
    host_TUs=2, native_TUs=0, SDK_rebuild=False, Qwen_link_owner_changes=1,
    tests_passed=14, tests_skipped=0, model_equal_finite_vectors=64,
    stage_diagnostic_processes=6, stage_process_medians=diagnostic['process_medians'],
    speed_window_beijing=window, rotation_processes=9, groups=speed['groups'],
    current_over_baseline=speed['current_over_baseline'], current_over_llama=speed['current_over_llama'],
    contract='Reuse only exact canonical TensorView extent/projection metadata. Recompute current parent subview/offset/bounds/overflow and retain alignment/alias/published-range/native hooks/seal/lease checks. No PlanState/InvocationState field or public/private ABI addition.',
    limits=['Graph/port traversal remains; descriptor comparison is not claimed O(1).',
        'Instrumented stage replay median decreased134.4->125.1us, total preparation197.2->200.0us: no total-preparation gain established.',
        'One rotated throughput window, samples overlap; no stable throughput significance established.',
        'Prefill median regressed2.475%; sample ranges overlap and cause remains unassigned.',
        'Same-source weights but Hyle BF16 vs peer F32 intermediates still differ.',
        'No new native profile, total-memory-peak, cross-platform runtime or independent quality acceptance.'],
    goal_complete=False)
c.save(S / 'summary.json', summary)
print('VIEW_SUMMARY', window, flush=True)
