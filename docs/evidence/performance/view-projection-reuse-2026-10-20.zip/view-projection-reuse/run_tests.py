"""Focused View, rebinding, specialization and failure regressions on the CPU closure."""
from pathlib import Path
import argparse
import importlib.util
import sys
import xml.etree.ElementTree as ET
sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('view_projection_test_helpers', S / 'build.py')
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)
b, c = m.b, m.c
p = argparse.ArgumentParser(description=__doc__)
p.add_argument('--new-test', required=True)
a = p.parse_args()
path = Path(c.read(S / 'latest-check.json')['plan'])
plan = c.read(path)
assert c.read(path.parent / 'summary.json')['passed']
for row in plan['frozen']:
    assert b.same(row), row['path']
out = S / 'tests'
out.mkdir(exist_ok=False)
(out / 'tmp').mkdir()
names = ['GraphViews.MetadataOnlyChainNeedsNoProviderOrPreparationBudget',
    'GraphViews.EveryExactCompileAllocationFailureCleansUpAndRetries',
    'Invocation.PublishedViewReusesItsSourceBinding',
    'Invocation.ImmutableAllocationGroupsKeepViewOffsetsAcrossReset',
    'Invocation.ResolvesAnInternalSliceViewWithoutMaterializingIt',
    'Invocation.OwnsAPublishedViewRootedInPrivateWorkspace',
    'GraphConstants.BorrowedReplicasKeepViewOffsetsAndNeverCopyAtReplay',
    'GraphRegions.OrdinaryColdBindingsRetryWithoutExecutingAndTrackRebinds',
    'GraphRegions.UnknownCaptureIdentityRepreparesAfterSameTupleBindingEpisode',
    'GraphDomain.DistinctShapesSharePlanButNotMutableRunState',
    'GraphDomain.CrossStorageCopyUsesConcreteByteCountNotEnvelope',
    'Invocation.RejectsForeignInternalConstOutputAndWrongShapeBindings',
    'GraphViews.MetadataControlDependencyOrdersCommandsAcrossTargets', a.new_test]
assert len(set(names)) == len(names)
link = c.read(path.parent / 'cpu-link-plan.json')
image = c.read(path.parent / 'cpu-image.json')
assert b.same(image)
env, runtime = b.environment(link['command'], [r['path'] for r in link['inputs']], out)
c.save(out / 'runtime.json', dict(link_plan=b.identity(path.parent / 'cpu-link-plan.json'),
    runtime_library_directories=runtime, CUDA_runtime_union_used=False))
try:
    c.execute('tests', [image['path'], '--gtest_filter=' + ':'.join(names),
                       '--gtest_output=xml:' + str(out / 'results.xml')], env, out)
finally:
    cases = ET.parse(out / 'results.xml').findall('.//testcase') if (out / 'results.xml').exists() else []
    actual = [r.attrib['classname'] + '.' + r.attrib['name'] for r in cases]
    passed = (len(actual) == len(names) and set(actual) == set(names) and
              all(r.find(t) is None for r in cases for t in ('failure', 'error', 'skipped')))
    c.save(out / 'summary.json', dict(passed=passed, cases=len(cases), names=actual, expected=names,
        skipped=sum(r.find('skipped') is not None for r in cases), image=image,
        build_plan=b.identity(path), CPU_only=True, GPU_run=False))
assert passed
print('VIEW_TESTS', len(names), 'passed', flush=True)
