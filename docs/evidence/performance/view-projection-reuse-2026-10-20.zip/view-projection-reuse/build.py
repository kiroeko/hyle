"""Refresh the two changed host owners; share the original graph object across CPU/CUDA."""
from pathlib import Path
import datetime as dt
import importlib.util
import sys
sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
ARCH = S.parent
ROOT = ARCH.parents[1]
spec = importlib.util.spec_from_file_location('view_projection_build_helpers', ARCH / 'cccl-single-row-topk/build_host.py')
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)
b, c = m.b, m.c

def main():
    out = S / 'checks' / dt.datetime.now(dt.timezone.utc).strftime('%Y%m%dT%H%M%S')
    out.mkdir(parents=True, exist_ok=False)
    (out / 'tmp').mkdir()
    bases = {'cpu': c.read(ARCH / 'binding-port-reuse/checks/20261019T174851/cpu-link-plan.json'),
             'qwen': c.read(ARCH / 'cccl-single-row-topk/checks/20261019T185912-host/qwen-link-plan.json')}
    recipes = [('graph', ARCH / 'binding-port-reuse/checks/20261019T174851/00-graph-executable-identity.json',
                ROOT / 'src/graph/executable.cc'),
               ('test', ARCH / 'decode-next-cold/checks/20261019T155819/42-graph-executable_test-identity.json',
                ROOT / 'tests/graph/executable_test.cc')]
    seal = c.read(S / 'source-freeze.json')
    frozen = [b.identity(p) for p in [Path(__file__), S / 'source-freeze.json']]
    for row in seal['files']:
        assert b.same(row['after']), row['after']['path']
        frozen.append(row['after'])
    rows, cached = [], {c.key(r['path']):r for base in bases.values() for r in base['inputs']}
    for tag, recipe_path, source in recipes:
        recipe = c.read(recipe_path)
        assert cached[c.key(recipe['object']['path'])] == recipe['object']
        command = b.host_command(recipe['command'], source, tag, out)
        row = dict(tag=tag, source=b.identity(source), command=command,
                   object=str(out / (tag + '.obj')), old_object=recipe['object'])
        rows.append(row)
        frozen += [b.identity(recipe_path), row['source']]
        snapshot = out / 'compiled-source' / source.relative_to(ROOT)
        snapshot.parent.mkdir(parents=True, exist_ok=True)
        snapshot.write_bytes(source.read_bytes())
    links = {}
    for arm, base in bases.items():
        replacements = {c.key(row['old_object']['path']): row['object'] for row in rows
                        if row['old_object'] in base['inputs']}
        command = [replacements.get(c.key(x), x) for x in base['command']
                   if not x.upper().startswith(('/OUT:', '/MAP:', '/IMPLIB:', '/PDB:'))]
        image = out / (arm + '.exe')
        command += ['/OUT:' + str(image), '/MAP:' + str(image.with_suffix('.map')),
                    '/IMPLIB:' + str(image.with_suffix('.lib'))]
        inputs = [x for x in command if Path(x).is_absolute() and x.lower().endswith(('.obj', '.lib'))
                  and not x.upper().startswith(('/OUT:', '/MAP:', '/IMPLIB:', '/PDB:'))]
        assert len(inputs) == len(set(map(c.key, inputs))) == (115 if arm == 'cpu' else 130)
        links[arm] = dict(command=command, inputs=inputs, image=str(image))
    plan = dict(compile=rows, links=links, cached_inputs=list(cached.values()), frozen=frozen,
                host_TUs=2, native_TUs=0, SDK_rebuild=False, public_ABI_changed=False)
    c.save(out / 'plan.json', plan)
    print('PLAN', out / 'plan.json', flush=True)
    def check():
        for row in frozen:
            assert b.same(row), row['path']
    check()
    for row in cached.values():
        assert b.same(row), row['path']
    # CPU and CUDA images each receive only their own linked runtime closure.
    env, _ = b.environment(links['qwen']['command'], [r['path'] for r in bases['qwen']['inputs']], out)
    for row in rows:
        c.execute(row['tag'] + '-compile', row['command'], env, out)
        check()
        deps = c.read(out / (row['tag'] + '-deps.json'))['Data']
        record = dict(command=row['command'], source=row['source'], object=b.identity(row['object']),
            dependencies=[b.identity(p) for p in [deps['Source'], *deps['Includes']]])
        c.save(out / (row['tag'] + '-identity.json'), record)
        cached[c.key(row['object'])] = record['object']
    for arm, link in links.items():
        c.execute(arm + '-link', link['command'], env, out)
        check()
        c.save(out / (arm + '-link-plan.json'), dict(command=link['command'],
               inputs=[cached[c.key(p)] for p in link['inputs']]))
        c.save(out / (arm + '-image.json'), b.identity(link['image']))
    c.save(out / 'summary.json', dict(passed=True, host_TUs=2, native_TUs=0, SDK_rebuild=False))
    c.save(S / 'latest-check.json', dict(plan=str(out / 'plan.json'), summary=str(out / 'summary.json')))
    print('VIEW_PROJECTION_BUILT', out, flush=True)

if __name__ == '__main__':
    main()
