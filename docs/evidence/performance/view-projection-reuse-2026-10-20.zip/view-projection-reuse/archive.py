"""Archive the finished View metadata batch once; never builds, runs or deletes."""
from pathlib import Path
import argparse
import hashlib
import json
import xml.etree.ElementTree as ET
import zipfile
import zlib

STAGE = Path(__file__).resolve().parent
ARCH = STAGE.parent
ROOT = STAGE.parents[2]
HOT = ARCH / 'projection-hotspot-review'
DEST = ROOT / 'docs/evidence/performance/view-projection-reuse-2026-10-20.zip'
DOCS = ('docs/developer/current-work.md',
        'docs/evidence/performance/qwen35-full-cuda-2026-10-19/README.md')
OMIT = {'.exe','.obj','.o','.lib','.a','.map','.exp','.pdb','.dll','.pyc','.tmp',
        '.ilk','.res','.ptx','.cubin','.fatbin','.zip','.bin','.bf16','.f32','.f16',
        '.raw','.pt','.npy','.safetensors','.gguf','.nsys-rep','.sqlite'}
OWN = {'archive-receipt.json','archive-scope.json','archive-inventory.json'}


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))


def sha(data):
    return hashlib.sha256(data).hexdigest()


def identity(path):
    path = Path(path).resolve()
    data = path.read_bytes()
    return dict(path=str(path),bytes=len(data),sha256=sha(data))


def verify(record):
    actual = identity(record['path'])
    assert actual == record, (record,actual)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--build-plan',type=Path)
    parser.add_argument('--summary',type=Path,default=STAGE/'summary.json')
    args = parser.parse_args()
    final_summary = read(args.summary)
    assert final_summary['passed']
    plan_path = (args.build_plan or Path(read(STAGE/'latest-check.json')['plan'])).resolve()
    assert plan_path.is_relative_to(STAGE/'checks')
    plan_id = identity(plan_path)
    assert final_summary['build_plan']==plan_id
    assert read(STAGE/'latest-check.json')['plan'] == str(plan_path)
    plan,build = read(plan_path),read(plan_path.parent/'summary.json')
    assert build['passed'] and build['host_TUs']==2 and build['native_TUs']==0 and not build['SDK_rebuild']
    assert len(plan['compile'])==2
    tests = read(STAGE/'tests/summary.json')
    cases = ET.parse(STAGE/'tests/results.xml').findall('.//testcase')
    names = [row.attrib['classname']+'.'+row.attrib['name'] for row in cases]
    assert tests['passed'] and tests['cases']==len(cases)==14 and tests['skipped']==0
    assert len(set(names))==14 and set(names)==set(tests['expected'])==set(tests['names'])
    assert not any(row.find(tag) is not None for row in cases for tag in ('failure','error','skipped'))
    assert tests['build_plan']==plan_id
    test_result = read(STAGE/'tests/tests.result.json')
    assert test_result['exit']==0 and test_result['terminal']
    model = read(STAGE/'correctness/summary.json')
    obs = model['observation']
    assert model['passed'] and obs['equal_vectors']==len(obs['vectors'])==64
    assert obs['all_outputs_finite'] and obs['same_greedy_ids_as_reference'] and obs['same_fixed_decode_inputs']
    assert len(obs['generated_ids'])==32 and len(obs['decode_input_ids'])==31
    assert obs['process']['exit']==0 and obs['process']['terminal']
    assert obs['image']==read(plan_path.parent/'qwen-image.json')
    assert final_summary['images']['qwen']==obs['image']
    assert final_summary['images']['cpu']==tests['image']
    assert read(STAGE/'correctness/inputs.json')['plan']==plan_id
    assert all(row['byte_equal'] and row['actual']['bytes']==row['reference']['bytes'] and
               row['actual']['sha256']==row['reference']['sha256'] for row in obs['vectors'])
    prepare = read(STAGE/'prepare-comparison/summary.json')
    assert prepare['passed'] and prepare['terminal_zero']==len(prepare['runs'])==6
    assert prepare['instrumented'] and not prepare['throughput_claim'] and prepare['predictions_and_fixed_inputs_same']
    for row in prepare['runs']:
        result = read(STAGE/'prepare-comparison'/(row['tag']+'.result.json'))
        assert result['terminal'] and result['exit']==0 and len(row['phases'])==32
    perf = read(STAGE/'performance-rotation/summary.json')
    assert perf['status']=='nine_fresh_unprofiled_processes_terminal_zero' and perf['terminal_zero']==9
    assert not perf['profiler'] and perf['same_baseline_predictions_all9']
    assert perf['images']['current']==obs['image']
    for group in ('baseline','current','llama'):
        assert len(perf['groups'][group]['warm7_31_tokens_per_second']['samples'])==3
    frozen = read(STAGE/'source-freeze.json')
    for row in frozen['files']:
        for side in ('before','after','retained_after'): verify(row[side])
    verify(frozen['diff'])
    payload,origins,omitted = {},{},[]

    def add(path,name):
        path=Path(path)
        data=path.read_bytes()
        if name in payload:
            assert payload[name]==data,name
            return
        payload[name]=data
        origins[name]=dict(source_path=str(path.resolve()),bytes=len(data),sha256=sha(data))

    def collect(base,prefix):
        for path in sorted(base.rglob('*')):
            if not path.is_file(): continue
            rel=path.relative_to(base)
            if path.suffix.lower() in OMIT or path.name in OWN or {
                    part.lower() for part in rel.parts} & {'tmp','__pycache__','sdk','cache','models','weights'}:
                omitted.append(dict(path=prefix+rel.as_posix(),bytes=path.stat().st_size,
                    reason='rebuildable binary/debug/SDK/tmp/rawvector or generatedreceipt'))
                continue
            add(path,prefix+rel.as_posix())

    collect(STAGE,'view-projection-reuse/')
    collect(HOT/'hot-prepare-diagnostic','hot-prepare-diagnostic/')
    for name in ('diagnose_prepare.py','hot-prepare-review.json'):
        add(HOT/name,'hot-prepare-origin/'+name)
    hot = read(HOT/'hot-prepare-diagnostic/summary.json')
    assert hot['passed'] and hot['instrumented'] and not hot['product_patch'] and hot['predictions_and_fixed_inputs_same']
    hot_result=read(HOT/'hot-prepare-diagnostic/diagnostic.result.json')
    assert hot_result['terminal'] and hot_result['exit']==0
    # This consumer source is the real initial diagnostic owner, reused by
    # the paired stage-clock comparison, not a newly modified model consumer.
    diagnostic_owner=read(HOT/'hot-prepare-diagnostic/main-identity.json')
    verify(diagnostic_owner['source'])

    # Local headers actually compiled by these two owners, not a copied SDK.
    headers={}
    owners=[]
    for tag in ('graph','test'):
        owner=read(plan_path.parent/(tag+'-identity.json'))
        verify(owner['source'])
        owners.append(dict(tag=tag,identity=identity(plan_path.parent/(tag+'-identity.json')),
            source=owner['source'],object=owner['object']))
        result=read(plan_path.parent/(tag+'-compile.result.json'))
        assert result['terminal'] and result['exit']==0
        for dependency in owner['dependencies']:
            path=Path(dependency['path']).resolve()
            if path.is_relative_to(ROOT) and path.suffix.lower() in ('.h','.hpp','.cuh'):
                verify(dependency)
                archive_path='compiled-headers/'+path.relative_to(ROOT).as_posix()
                add(path,archive_path)
                headers[archive_path]=dependency
    # Preserve the factory/privateconstructor bodies used in the independent
    # canonicalspan argument, including the unchanged compiledsupport sources.
    for key,record in read(STAGE/'independent-review.json')['supporting_sources'].items():
        verify(record)
        add(record['path'],'review-support/'+Path(record['path']).relative_to(ROOT).as_posix())
    catalog_path=HOT/'remaining-feature-source-freeze.json'
    catalog=read(catalog_path)
    add(catalog_path,'catalog-correction/source-freeze.json')
    for name in ('remaining-feature-catalog.diff','remaining-feature-triage.json'):
        add(HOT/name,'catalog-correction/'+name)
    for row in catalog['files']:
        for side in ('before','snapshot'):
            verify(row[side])
            add(row[side]['path'],'catalog-correction/'+side+'/'+row['path'])
        assert row['snapshot']['sha256']==row['after']['sha256']
        before,after=read(row['before']['path']),read(row['snapshot']['path'])
        def remove_provider_coverage(value):
            if isinstance(value,dict):return {k:remove_provider_coverage(v) for k,v in value.items() if k!='provider_coverage'}
            if isinstance(value,list):return [remove_provider_coverage(v) for v in value]
            return value
        assert remove_provider_coverage(before)==remove_provider_coverage(after)
        assert all(a['provider_coverage']['artifact_execution_verified'] is False for a in after['artifacts'])
    verify(catalog['diff'])
    docs=[]
    for name in DOCS:
        path=ROOT/name
        add(path,'context/'+name)
        docs.append(identity(path))
    # Raw64 tensors already have exact current/reference identities and their
    # retained baselinepayload provenance. Do not duplicate their bodies.
    provenance=ROOT/'docs/evidence/performance/qwen35-full-cuda-2026-10-19/batch-graph-capture-archive.json'
    add(provenance,'baseline-provenance/batch-graph-capture-archive.json')
    scope=dict(
        result='CanonicalView projection metadata reuse with unchanged dynamic guards; completed localvalidation recorded separately from timing interpretations.',
        source_freeze=identity(STAGE/'source-freeze.json'),build_plan=plan_id,owners=owners,
        compiled_local_header_count=len(headers),compiled_local_headers=headers,
        CPU_cases=14,CPU_zero_skips=True,equal_finite_vectors=64,
        instrumentation=dict(before=prepare['process_medians']['before'],after=prepare['process_medians']['after'],
            limit='The same diagnostic main adds4clockreads perstep. Replayprepare stage134.4→125.1us improved in this onepairedwindow, but total197.2→200.0us did not. Do not claim totalpreparation or tokens/sec gains from these stage clocks.'),
        complexity='The graph still traverses every requiredstep/port, including518Views in the recorded1101step route. This skips repeated exactextent/factory work for matchingmetadata, not the graph traversal, currentparentrange checks, permissions, aliases or backendseal.',
        model_timing=dict(status=perf['status'],groups=perf['groups'],
            current_over_baseline=perf['current_over_baseline'],current_over_llama=perf['current_over_llama'],
            metric_contract=perf['metric_contract'],limits=perf['limits'],
            limit='Final ninefresh unprofiled rotation is the model timing evidence. Threeprocesses/arm in onewindow do not establish statistical significance or allplatform/model performance. Prefill regressions and overlap remain visible in rawdata.'),
        native_scope='No nativeCUDA math or sharedABI change and no new physicalmodelprofile. Do not label the previousnativekernel count as a newtrace result.',
        raw_vector_scope='All64 actual/reference SHA/bytes/bitcomparisons plus command/sourceimage receipts retained, raw BF16/F32 payloads omitted. Prior batchgraphcapture archive identifies baselinepayload provenance; no fullmodel-quality claim.',
        catalog_scope='Only the frozen catalogcorrection before/after/diff/triage; publishermetadata deep-compared excluding provider_coverage and every artifact_execution_verified remainsfalse. This is documentationcorrection, not artifactruntime coverage.',
        included_context_docs=docs,omitted=omitted,
        boundaries=['Cached ConstTensorView is nonowning metadata, not readiness/permission/lifetime authority.',
            'Unknown opaqueidentity recordings, currentowner/seal and actualexternalbinding checks remain.',
            'The hotprepare diagnostic and its source are intentionally included here; the separately archived rejected2row matvec experiment is not duplicated.',
            'No SDK/library/object/image/rawweight/rawvector body is copied; binary identities and actualcommands remain.'])
    payload['archive-scope.json']=(json.dumps(scope,ensure_ascii=False,indent=2)+'\n').encode()
    payload['payload-sha256.json']=(json.dumps({name:dict(bytes=len(data),sha256=sha(data))
        for name,data in sorted(payload.items())},indent=2)+'\n').encode()
    expected={name:dict(bytes=len(data),sha256=sha(data),crc32=zlib.crc32(data)&0xffffffff)
        for name,data in payload.items()}
    assert not DEST.exists(),'Do not overwrite a completed evidencearchive'
    DEST.parent.mkdir(parents=True,exist_ok=True)
    with zipfile.ZipFile(DEST,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
        for name,data in sorted(payload.items()):archive.writestr(name,data)
    with zipfile.ZipFile(DEST) as archive:
        assert set(archive.namelist())==set(expected)
        for item in archive.infolist():
            data=archive.read(item.filename)
            observed=dict(bytes=len(data),sha256=sha(data),crc32=zlib.crc32(data)&0xffffffff)
            assert observed==expected[item.filename] and item.CRC==observed['crc32']
    receipt=dict(**identity(DEST),entries=len(payload),payload_bytes=sum(map(len,payload.values())),
        CRC_and_every_payload_SHA_verified=True,crc_verified=True,payload_sha256_verified=True,
        verification_passes=1,build_plan=plan_id,host_TUs=2,native_TUs=0,CPU_cases=14,
        equal_finite_vectors=64,diagnostic_processes=6,model_rotation_processes=9,
        native_profile_run=False,total_prepare_speedup_claim=False,
        cleanup_executed=False,archive_scope='archive-scope.json',payload_manifest='payload-sha256.json')
    for path in (STAGE/'archive-receipt.json',DEST.with_name(DEST.stem+'-archive.json')):
        path.write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(receipt,indent=2))


if __name__=='__main__':
    main()
