"""Finite CPU B,C,C,B,B,C timing + independent B/C memory; no builds."""
from pathlib import Path
import hashlib, importlib.util, json, os, statistics, sys, time, types
sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = W.parents[2]
OUT = W / 'screen'

def read(p): return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def save(p, value):
    p = Path(p); p.parent.mkdir(parents=True, exist_ok=True)
    p.write_bytes((json.dumps(value, indent=2, allow_nan=False) + '\n').encode())
def pin(p):
    p = Path(p).resolve(); b = p.read_bytes()
    return dict(path=str(p), bytes=len(b), sha256=hashlib.sha256(b).hexdigest())
def stats(xs):
    return dict(count=len(xs), median=statistics.median(xs) if xs else None,
                min=min(xs) if xs else None, max=max(xs) if xs else None, samples=xs)
def load(name, path):
    s = importlib.util.spec_from_file_location(name, path)
    m = importlib.util.module_from_spec(s); s.loader.exec_module(m); return m

protocol = load('cpu_retained_window', R / '.scratch/mtp-performance-convergence-20261025/baseline/window.py')
runner = protocol.helpers()
original_popen = runner.subprocess.Popen
current_folder = None

class BoundedProcess:
    def __init__(self, *args, **kwargs):
        self.p = original_popen(*args, **kwargs)
        save(current_folder / 'live.json', dict(pid=self.p.pid, command=args[0]))
        print('CPU_PROCESS', self.p.pid, current_folder.name, flush=True)
    def __getattr__(self, name): return getattr(self.p, name)
    def wait(self, timeout=None): return self.p.wait(timeout=min(timeout or 180, 180))

runner.subprocess = types.SimpleNamespace(Popen=BoundedProcess,
    CREATE_NO_WINDOW=runner.subprocess.CREATE_NO_WINDOW,
    TimeoutExpired=runner.subprocess.TimeoutExpired)
OriginalProbe = runner.load_probe()

class ThreadProbe(OriginalProbe):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        import psutil
        self.psutil = psutil; self.thread_rows = []; self.next_thread_ns = 0
    def sample(self):
        row = super().sample()
        if row.get('process_running') and row['timestamp_ns'] >= self.next_thread_ns:
            start = time.perf_counter_ns()
            item = dict(timestamp_ns=start, pid=self.pid)
            try: item['threads'] = self.psutil.Process(self.pid).num_threads()
            except self.psutil.NoSuchProcess: item['unavailable'] = 'process_exited_during_sample'
            except Exception as exc: item['unavailable'] = repr(exc)
            item['sample_duration_ns'] = time.perf_counter_ns() - start
            self.thread_rows.append(item); self.next_thread_ns = start + 100_000_000
        return row
    def result(self):
        result = super().result()
        counts = [x['threads'] for x in self.thread_rows if 'threads' in x]
        save(current_folder / 'threads.json', dict(requested_interval_seconds=.1,
            sampler='psutil.Process.num_threads', psutil_version=self.psutil.__version__,
            samples=self.thread_rows, count=len(counts), peak=max(counts) if counts else None,
            values=stats(counts), limits='OS process thread count, not busy threads or CPU utilization. Sampled peak is a lower bound.'))
        return result

runner.load_probe = lambda: ThreadProbe
TIME_KEYS = {'seconds', 'unix_ms', 'unix_ns', 'clock_unix'}
def normalize(x):
    if isinstance(x, dict):
        return {k: normalize(v) for k, v in x.items()
                if k not in TIME_KEYS and not k.endswith('_seconds') and not k.endswith('tokens_per_second')}
    return [normalize(v) for v in x] if isinstance(x, list) else x

def raw(folder, arm):
    return read(folder / ('stdout.log' if arm == 'hyle' else 'consumer-result.json'))

def check(j, arm):
    assert j['backend'] == 'cpu' and not j['mtp']
    assert j['prefill_target_rows'] == 154 and j['actual_target_rows'] == 169
    assert j['generated_tokens'] == 16 and j['generated_decode_tokens'] == 15
    ids = j['sessions'][0]['result']['generated_ids'] if arm == 'hyle' else j['generated_ids']
    assert ids == references['peer']['generated_ids'] and len(ids) == 16
    if arm == 'hyle':
        assert j['actual_graph_calls'] == 16 and j['decode_graph_calls'] == 15
        assert j['original_device_weight_bytes'] == 0 and j['live_committed_versions'] == 0
        assert j['sessions'][0]['result']['turns'][0]['input_ids'] == references['peer']['prompt_ids']
    else:
        assert j['target_compute_calls'] == 16 and j['target_decode_calls'] == 15
        assert j['target_actual_threads'] == j['target_actual_batch_threads'] == 4
        assert j['selected_device_type_cpu'] and j['requested_gpu_layers'] == 0
        assert not j['offload_kqv'] and not j['op_offload'] and not j['stopped_on_EOS']
    assert normalize(j) == normalize(references[arm]), 'Complete within-arm non-time report changed'
    for key, n in [('prefill', 154), ('decode_output', 15), ('output', 16)]:
        seconds = j[{'prefill':'prefill_seconds', 'decode_output':'decode_seconds', 'output':'session_seconds'}[key]]
        assert abs(n / seconds - j[key + '_tokens_per_second']) < 1e-8
    assert abs(j['prefill_seconds'] + j['decode_seconds'] - j['session_seconds']) < 1e-8
    return dict(all_within_arm_non_time_fields_equal_initial_AVX2_pair=True,
                common_prompt_ids_equal=True, all16_generated_ids_equal=True,
                prompt_rows=154, target_rows=169, decode_calls=15, target_calls=16,
                generated_ids=ids)

references = dict(hyle=read(W / 'run/hyle/stdout.log'), peer=read(W / 'future-run/peer-result.json'))
METRICS = ('prefill_tokens_per_second', 'decode_output_tokens_per_second', 'output_tokens_per_second')

def summarize(rows):
    timing = [x for x in rows if x['mode'] == 'timing']
    grouped = {a: [x for x in timing if x['arm'] == a] for a in ('hyle','peer')}
    pairs = []
    for i in range(0, len(timing), 2):
        pair = {x['arm']: x for x in timing[i:i+2]}
        if len(pair) == 2:
            pairs.append(dict(pair=len(pairs)+1, order=[x['arm'] for x in timing[i:i+2]],
                peer_vs_hyle_tps_percent={k:(pair['peer']['metrics'][k]/pair['hyle']['metrics'][k]-1)*100 for k in METRICS}))
    return dict(status='COMPLETE' if len(rows)==8 else 'PARTIAL', processes=rows,
        timing={a:{k:stats([x['metrics'][k] for x in group]) for k in METRICS} for a,group in grouped.items()},
        paired_timing=pairs, memory={x['arm']:dict(memory=read(Path(x['folder'])/'memory-summary.json'),
            threads=read(Path(x['folder'])/'threads.json')) for x in rows if x['mode']=='memory'},
        order='B,C,C,B,B,C; then independent B,C memory', B='Hyle fa7b', C='peer AVX2 27a49a73',
        work_all_passed=all(x['work']['all_within_arm_non_time_fields_equal_initial_AVX2_pair'] for x in rows),
        warmups=0, retries=0, timing_memory_sampling=False, timeout_seconds=180,
        limits=['Only3 short timing samples/arm and1 separate memory sample/arm; no stable scaling/quality claim.',
            'Same16 observed greedy IDs, not intermediate-bit equality or identical precision/algorithm.',
            'Original endpoint metrics; Hyle outer ATen/Scheduler setup excluded by startup clock, so startup is not ranked.',
            'T4 configuration is not a process-wide thread cap. Thread peaks are OS counts, not busy threads.',
            'PSAPI/PDH sampled peaks are lower bounds; absent GPU instances remain null, not zero.',
            'Peer links a CUDA registry and may initialize it despite actual CPU model placement/nooffload.'])

def main():
    global current_folder
    assert not OUT.exists(), 'Refuse rerun or overwrite'
    plan = read(W/'commands.json'); OUT.mkdir()
    for arm in ('hyle','peer'):
        ready = read(plan[arm]['ready']['path'])
        assert pin(ready['image']['path']) == ready['image']
        assert pin(plan[arm]['ready']['path']) == plan[arm]['ready']
        assert pin(plan[arm]['runtime']['path']) == plan[arm]['runtime']
    save(OUT/'plan.json', dict(commands=plan, script=pin(__file__),
        runner=pin(protocol.base.RUNNER), observer=pin(protocol.base.OBSERVER), sampler=pin(runner.SAMPLER),
        changes='Original execute/observer. Popen wrapper caps wait180s and announces PID; MemoryProbe subclass adds psutil thread count every100ms in memory processes only.',
        references={a:pin(W/('run/hyle/stdout.log' if a=='hyle' else 'future-run/peer-result.json')) for a in references}))
    rows=[]
    try:
        order=[('timing',a) for a in ('hyle','peer','peer','hyle','hyle','peer')]+[('memory',a) for a in ('hyle','peer')]
        for index,(mode,arm) in enumerate(order,1):
            current_folder=OUT/f'{index:02d}-{mode}-{arm}'
            command=list(plan[arm]['command'])
            if arm=='peer': command[command.index('--output')+1]=str(current_folder/'consumer-result.json')
            rt=read(plan[arm]['runtime']['path']); env=os.environ.copy()
            env['PATH']=rt['PATH']; env.update(rt.get('configured_flags',{}))
            env.update(HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1')
            process=runner.execute(current_folder,arm,command,env,mode=='memory')
            j=raw(current_folder,arm); work=check(j,arm)
            row=dict(index=index,mode=mode,arm=arm,folder=str(current_folder),process=process,work=work,
                metrics={k:j[k] for k in (*METRICS,'prefill_seconds','decode_seconds','session_seconds',
                    'startup_to_ready_seconds','startup_to_endpoint_seconds')})
            rows.append(row); save(current_folder/'checks.json',work)
            save(OUT/'runs.json',rows); save(OUT/'summary.json',summarize(rows))
            print('CPU_TERMINAL',process['pid'],process['exit'],mode,arm,'WORK_PASS',flush=True)
    except Exception as exc:
        save(OUT/'failure.json',dict(error=repr(exc),stopped_before_next_process=True,completed=len(rows)))
        raise
    print('CPU_WINDOW_COMPLETE_RELEASED',flush=True)

if __name__=='__main__': main()
