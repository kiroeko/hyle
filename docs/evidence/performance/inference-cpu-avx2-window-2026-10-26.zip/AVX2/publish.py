"""Publish retained CPU evidence only; no inference, build, download or cleanup."""
from pathlib import Path
import datetime, hashlib, json, zipfile
W=Path(__file__).resolve().parent; P=W.parent; R=W.parents[2]
PUBLIC=R/'docs/evidence/performance/inference-cpu-avx2-window-2026-10-26.json'
ZIP=PUBLIC.with_suffix('.zip')
def read(p): return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def pin(p):
    p=Path(p).resolve();b=p.read_bytes()
    return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def save(p,x):
    p.parent.mkdir(parents=True,exist_ok=True)
    p.write_bytes((json.dumps(x,indent=2,ensure_ascii=False,allow_nan=False)+'\n').encode())
screen=read(W/'screen/final-summary.json'); runs=read(W/'screen/runs.json')
assert screen['status']=='FINITE_CPU_SCREEN_6_TIMING_2_INDEPENDENT_MEMORY_PASS'
assert len(runs)==8 and all(x['process']['exit']==0 for x in runs)
assert screen['work']['all8_complete_within_arm_non_time_reports_equal_first_AVX2_pair']
assert screen['memory']['hyle']['os_threads']['peak']==3428
assert screen['memory']['peer']['os_threads']['peak']==15
compile_rows=read(W/'compile-summary.json'); assert len(compile_rows)==15
assert all(x['result']['exit']==0 for x in compile_rows)
avx2=read(W/'ready.json');old=read(P/'analysis/summary.json')
assert avx2['cpu_library']['sha256']=='73a642b2b29427a44ef5cd25e5fdda61a37c4d48a6e6ed02afd87347ab89b226'
assert avx2['image']['sha256']=='27a49a73fdafccde9528bda413aee69f2e2d755b7705fa60bbd60fc8a8ca5404'
metric_keys=('prefill_seconds','decode_seconds','session_seconds','prefill_tokens_per_second',
    'decode_output_tokens_per_second','output_tokens_per_second','startup_to_ready_seconds','startup_to_endpoint_seconds')
def pair(base,hyle,peer):
    h=read(hyle);p=read(peer)
    assert h['sessions'][0]['result']['generated_ids']==p['generated_ids']==screen['work']['generated_ids']
    return dict(processes=read(base)['results'],hyle={k:h[k] for k in metric_keys},
        peer={k:p[k] for k in metric_keys},same16_IDs=True,pooled_in_screen=False)
pairs=dict(generic_initial=pair(P/'run/summary.json',P/'run/hyle/stdout.log',P/'future-run/peer-result.json'),
    AVX2_initial=pair(W/'run/summary.json',W/'run/hyle/stdout.log',W/'future-run/peer-result.json'))
files={}
def add(name,path):
    path=Path(path);assert path.is_file(),path
    assert path.suffix.lower() in {'.json','.py','.log','.patch','.cc','.h','.txt'},path
    assert name not in files;files[name]=path
for name in ['screen.py','analyze_screen.py','publish.py','build.py','run.py','commands.json',
    'plan.json','compile-summary.json','link-inputs.json','object-map.json','map-checks.json','ready.json','runtime.json']:
    add('AVX2/'+name,W/name)
for folder in ['archive','link']:
    for name in ['command.json','process.json','stdout.log','stderr.log']:
        add('AVX2/'+folder+'/'+name,W/folder/name)
for item in compile_rows:
    folder=Path(item['command']['path']).parent
    for name in ['command.json','process.json','stdout.log','stderr.log','actual-dependencies.json']:
        add('AVX2/compile/'+folder.name+'/'+name,folder/name)
for name in ['screen/final-summary.json','screen/summary.json','screen/runs.json','screen/plan.json',
    'screen/memory-continuation.json','screen/failure.json',
    'screen/first-orchestrator-failure/screen.py','screen/first-orchestrator-failure/failure.json']:
    add('AVX2/'+name,W/name)
for row in runs:
    folder=Path(row['folder'])
    for name in ['command.json','stdout.log','stderr.log','result.json','live.json','checks.json']:
        add('window/'+folder.name+'/'+name,folder/name)
    if row['arm']=='peer':add('window/'+folder.name+'/consumer-result.json',folder/'consumer-result.json')
    if row['mode']=='memory':
        for name in ['memory.json','memory-summary.json','threads.json']:
            add('window/'+folder.name+'/'+name,folder/name)
for name in ['command.json','stdout.log','stderr.log']:
    add('observer-first-failure/'+name,W/'screen/07-memory-hyle'/name)
for label,root in [('generic-initial',P),('AVX2-initial',W)]:
    for arm in ['hyle','peer']:
        for name in ['command.json','process.json','stdout.log','stderr.log']:
            add(label+'/'+arm+'/'+name,root/'run'/arm/name)
    add(label+'/summary.json',root/'run/summary.json')
    add(label+'/consumer-result.json',root/'future-run/peer-result.json')
for name in ['source.patch','source-pins.json','cpu_entry.cc','commands.json','build.py','run.py','source/mtp_schedule.h']:
    add('shared-consumer/'+name,P/name)
add('shared-consumer/peer_multiturn.cc',P/'source/peer_multiturn.cc')
for arm in ['hyle','peer3']:
    for name in ['ready.json','runtime.json','link-inputs.json','link/command.json','link/process.json']:
        add('shared-consumer/'+arm+'/'+name,P/arm/name)
protocol=read(W/'screen/plan.json')
for field in ['runner','observer','sampler']:
    add('retained-observer/'+field+'.py',protocol[field]['path'])
for rel in ['.scratch/mtp-performance-convergence-20261025/baseline/window.py',
            '.scratch/qwen-mtp-window-20261022/window.py']:
    add('retained-observer/'+Path(rel).parent.name+'-'+Path(rel).name,R/rel)
facts=dict(schema='hyle.inference-cpu-avx2-window.v1',
    status='FINITE_3PAIRED_CPU_TIMING_AND2_INDEPENDENT_MEMORY_COMPLETE',
    generated_UTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    scope='Local i9-13900K,ordinary P154/requested16/C256/N1/R1,greedy/naturalEOS. Hyle fa7b versus same-source AVX2 peer27a49a. No GPU model workload,new SDK,model download or product/default change.',
    screen=screen,
    initial_pairs=pairs,
    initial_pair_limits='Both initial pairs are separate historical n1 observations and excluded from the3paired timing stats. Generic peer lacked AVX2/FMA/F16C CPU compile flags and is not a fair ISA baseline. AVX2 initial pair preserves that correction and motivated the finite screen.',
    original_initial_pair_evidence=dict(json=pin(R/'docs/evidence/performance/inference-cpu-initial-pair-2026-10-26.json'),
        archive=pin(R/'docs/evidence/performance/inference-cpu-initial-pair-2026-10-26.zip')),
    same_source_ISA_correction=dict(peer_source='source-4e1a7b2f39afe15d',compiler='MSVC14.50.35717 /O2 /MD',
        CPU_TUs=15,compile_exit_zero=15,compile_seconds_sum=sum(x['result']['seconds'] for x in compile_rows),
        added_flags=['/arch:AVX2','/DGGML_AVX2','/DGGML_FMA','/DGGML_F16C'],
        excluded=['native-CPU tune','AVX512','AMX','OpenMP','BLAS','Hyle newer mixed-iq1 objects'],
        old_cpu_library=read(W/'object-map.json')['before'],new_cpu_library=avx2['cpu_library'],
        one_archive_replaced_other_peer_inputs_unchanged=True,source_and_actual_dependencies_in_archive=True,
        historical_prefix='C-root cache paths appear only in retained original command provenance; actual compilation remapped to repository .scratch/legacy-root. No new C-root path was created.',
        immutable_build_receipt_status='ready.json/commands.json preserve their original build-only not-run text. Actual later pair/window process records establish runtime, not rewritten build receipts.'),
    resource_observation=dict(actual_OS_thread_peak_hyle=3428,actual_OS_thread_peak_peer=15,
        actual_hyle_prefill_threads='3407..3410 in33 phase samples',actual_hyle_decode_threads='3428 in14 phase samples',
        native4_not_process_cap=True,
        interpretation='Thousands of live OS threads and7.03GB working set are an observed resource issue. This sample does not identify busy threads or prove the cause/speed impact of a particular pool. A shared-context/provider-pool candidate is a separate subsequent task, absent from these images/results.',
        memory_definitions='Working set includes resident mapped pages. Private commit excludes shared/file-backed mappings; distinct loading/mapping strategies affect this comparison. Neither is a total allocator-accounted physical footprint.'),
    precision_and_route=dict(matched=['same154prompt IDs','same16generated IDs','same169target rows/15decode calls','explicitCPU T4','AVX2/FMA/F16C peer CPU build'],
        hyle='Source BF16 activations/storepoints with F32 operations and bf16_inputs_f32_output head. native4+borrowed Scheduler4+ATen intraop4; no per-op census here.',
        peer='187BF16+133F32 source tensors;F32 recurrent state,K/VBF16;actualCPU/nooffload and decode/batch4 getters. Native AVX2 BF16 dot may use different accumulation/math from Hyle.',
        limits='Matching greedy IDs are observed,not intermediate-bit or precision/quality equivalence. This is an improved ISA-matched representative comparison,not proof of identical algorithms or complete CPU tuning.'),
    reproducibility=dict(work='.scratch/inference-cpu-representative-20261026/peer-avx2',
        original_commands=pin(W/'commands.json'),script=pin(W/'screen.py'),offline_parser=pin(W/'analyze_screen.py'),
        phases='Run screen.py once for6timing then2memory. Historical first execution stopped before first memory Popen on missingPIPE; corrected remaining-memory command ran only the2unstarted memory processes. Do not rerun into existing folders.',
        source_cache_required='Exact retained local sources,SDK/native libraries,original2B HF/GGUF weights and runtime identities. No automatic acquisition. Public ZIP intentionally excludes them.'),
    no_new_runtime_during_publication=True)
save(W/'screen/public-summary.json',facts)
add('summary.json',W/'screen/public-summary.json')
manifest=[dict(name=n,bytes=p.stat().st_size,sha256=pin(p)['sha256']) for n,p in sorted(files.items())]
save(W/'screen/archive-manifest.json',manifest);add('archive-manifest.json',W/'screen/archive-manifest.json')
ZIP.parent.mkdir(parents=True,exist_ok=True)
with zipfile.ZipFile(ZIP,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,path in sorted(files.items()):z.writestr(name,path.read_bytes())
with zipfile.ZipFile(ZIP) as z:
    assert z.testzip() is None and len(z.namelist())==len(files)
    for item in manifest:
        b=z.read(item['name']);assert len(b)==item['bytes'] and hashlib.sha256(b).hexdigest()==item['sha256']
facts['archive']=dict(**pin(ZIP),members=len(files),CRC_PASS=True,member_SHA256_PASS=True,
    exclusions='No executable,object,library,DLL,SDK,model payload,complete vendor/source tree or previous giant archive.')
facts['archive']['path']=ZIP.relative_to(R).as_posix()
save(PUBLIC,facts)
print(json.dumps(dict(report=pin(PUBLIC),archive=facts['archive']),indent=2))
