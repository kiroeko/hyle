"""Build only peer's same-version15 CPU TUs, archive, and single-input relink."""
from pathlib import Path
import hashlib, importlib.util, json, os, shlex, sys

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = W.parents[2]
PAIR = W.parent
CACHE = R / '.scratch/legacy-root/hyle-scratch/ggml-native-static'
SOURCE = CACHE / 'src/compute_ggml_runtime/source-4e1a7b2f39afe15d'
OLD_PREFIX = r'C:\hyle-scratch\ggml-native-static'
spec = importlib.util.spec_from_file_location('peer_avx2_execute',
    R / '.scratch/inference-synchronous-step-report-20261025/check_host.py')
h = importlib.util.module_from_spec(spec); spec.loader.exec_module(h)
def read(p): return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def pin(p):
    p=Path(p).resolve(); b=p.read_bytes()
    return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def save(p,x):
    p.parent.mkdir(parents=True,exist_ok=True)
    p.write_bytes((json.dumps(x,indent=2)+'\n').encode())
def key(p): return os.path.normcase(str(Path(p).resolve()))
def inside(p,root):
    try: Path(p).resolve().relative_to(Path(root).resolve()); return True
    except ValueError: return False
def remap(arg):
    return arg.replace(OLD_PREFIX,str(CACHE)).replace(OLD_PREFIX.replace('\\','/'),str(CACHE))

def main():
    old_ready=read(PAIR/'peer3/ready.json')
    inputs=read(PAIR/'peer3/link-inputs.json')
    old_cpu=next(x for x in inputs if key(x['path'])==key(CACHE/'bin/ggml-cpu.lib'))
    assert old_cpu['sha256']=='528f3921dc2983a2edec6af2b400af92e92cf857a4a97f3fd194e1b9d5905b8e'
    assert pin(old_cpu['path'])==old_cpu
    entries=[x for x in read(CACHE/'compile_commands.json') if 'ggml-cpu.dir' in x['command']]
    assert len(entries)==15
    selected=[]; rows=[]; compiler=None; env=None
    for index,entry in enumerate(entries):
        args=[x[1:-1] if x.startswith('"') and x.endswith('"') else x for x in shlex.split(entry['command'],posix=False)]
        assert all(not any(t in arg.lower() for t in ['arch:avx','ggml_avx2','ggml_fma','ggml_f16c','openmp','llamafile']) for arg in args)
        source=Path(remap(entry['file'])).resolve()
        assert inside(source,SOURCE) and source.is_file()
        command=[]
        for arg in args:
            if arg.lower().startswith(('/fo','/fd')): continue
            arg=remap(arg)
            assert 'c:\\hyle-scratch' not in arg.lower() and 'c:/hyle-scratch' not in arg.lower()
            if arg.lower().startswith(('-i','/i')):
                assert inside(Path(arg[2:]),CACHE) and Path(arg[2:]).is_dir(),arg
            command.append(arg)
        compiler=command[0]
        assert '14.50.35717' in compiler and '/O2' in command and '-MD' in command
        if env is None:
            env=h.discover_environment(compiler='msvc',cache={'CMAKE_C_COMPILER':compiler,'CMAKE_CXX_COMPILER':compiler,'CMAKE_GENERATOR':'Ninja'},backends=()).env
        label=f'{index:02d}-'+source.name.replace('.','-')
        out=W/'compile'/label; obj=out/(label+'.obj')
        assert inside(obj,W)
        command += ['/arch:AVX2','/DGGML_AVX2','/DGGML_FMA','/DGGML_F16C',
                    '/sourceDependencies',str(out/'dependencies.json'),'/Fo'+str(obj),'/Fd'+str(out/'unit.pdb')]
        selected.append(dict(index=index,original=entry,source=pin(source),command=command))
        save(W/'plan.json',dict(status='BUILD_ONLY',source_root=str(SOURCE),original_commands=pin(CACHE/'compile_commands.json'),
            old_cpu_library=old_cpu,original_cmake_AVX2_policy=pin(SOURCE/'src/ggml-cpu/CMakeLists.txt'),
            prefix_mapping={OLD_PREFIX:str(CACHE)},selected=selected,
            limits='Only CPU target15; original same-version source/headers/CRT. No native/AVX512/AMX/OMP/BLAS flags; no Hyle mixed-iq1 objects; no model run.'))
        result=h.execute(command,env,out,timeout=180)
        deps=read(out/'dependencies.json')['Data']
        assert key(deps['Source'])==key(source)
        actual=[pin(p) for p in dict.fromkeys([deps['Source'],*deps['Includes']])]
        allowed=[R,Path(compiler).parents[3],Path('C:/Program Files (x86)/Windows Kits/10/Include')]
        assert all(any(inside(x['path'],root) for root in allowed) for x in actual),[x['path'] for x in actual if not any(inside(x['path'],root) for root in allowed)]
        assert all('c:\\hyle-scratch' not in x['path'].lower() for x in actual)
        assert all('mixed-iq1' not in x['path'].lower() for x in actual)
        save(out/'actual-dependencies.json',actual)
        rows.append(dict(index=index,source=pin(source),object=pin(obj),result=result,
                         command=pin(out/'command.json'),actual_dependencies=pin(out/'actual-dependencies.json')))
        save(W/'compile-summary.json',rows)
    archive=W/'archive/ggml-cpu-avx2.lib'
    lib_command=[str(Path(compiler).with_name('lib.exe')),'/NOLOGO','/MACHINE:X64','/OUT:'+str(archive),*[x['object']['path'] for x in rows]]
    archived=h.execute(lib_command,env,W/'archive',timeout=180)
    new_cpu=pin(archive); mapped=[new_cpu if key(x['path'])==key(old_cpu['path']) else x for x in inputs]
    assert sum(key(x['path'])==key(new_cpu['path']) for x in mapped)==1
    for x in mapped: assert pin(x['path'])==x
    command=[]; count=0; image=W/'link/peer-avx2.exe'
    for arg in read(PAIR/'peer3/link/command.json')['command']:
        if arg.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:')):continue
        if key(arg)==key(old_cpu['path']):arg=new_cpu['path'];count+=1
        command.append(arg)
    assert count==1
    command += ['/OUT:'+str(image),'/MAP:'+str(image.with_suffix('.map')),'/IMPLIB:'+str(image.with_suffix('.lib'))]
    save(W/'link-inputs.json',mapped)
    linked=h.execute(command,env,W/'link',timeout=180)
    runtime=read(PAIR/'peer3/runtime.json');save(W/'runtime.json',runtime)
    save(W/'object-map.json',dict(before=old_cpu,after=new_cpu,unchanged_absolute_inputs=len(inputs)-1,consumer_object=old_ready['compile']['peer']['object']))
    ready=dict(status='PEER_AVX2_BUILD_ONLY_NOT_RUN',image=pin(image),cpu_library=new_cpu,compile_count=15,
        compile_summary=pin(W/'compile-summary.json'),archive=archived,link=linked,link_inputs=pin(W/'link-inputs.json'),
        object_map=pin(W/'object-map.json'),runtime=pin(W/'runtime.json'),source_plan=pin(W/'plan.json'),
        original_peer=pin(PAIR/'peer3/ready.json'),consumer=old_ready['compile']['peer'],threads=4,
        model_runs=0,GPU_runs=0,other_target_compiles=0,
        limits='Same peer4e1a CPU source only,15 TUs+archive+single CPU-library relink. No Hyle/native mixed-version objects. CPU inference, ISA availability, output IDs and speed remain untested; original generic CPU pair preserved.')
    save(W/'ready.json',ready)
    future=W/'future-run';future.mkdir(exist_ok=True)
    commands=read(PAIR/'commands.json')
    commands['status']='NEW_AVX2_PAIR_PLANNED_NOT_RUN'
    commands['peer']['command'][0]=str(image)
    i=commands['peer']['command'].index('--output');commands['peer']['command'][i+1]=str(future/'peer-result.json')
    commands['peer']['ready']=pin(W/'ready.json');commands['peer']['runtime']=pin(W/'runtime.json')
    commands['limits']+=' New peer AVX2 CPU library has not been run; generic result is historical and must not be mixed with a future pair.'
    save(W/'commands.json',commands)
    print(json.dumps(ready,indent=2),flush=True)

if __name__=='__main__': main()
