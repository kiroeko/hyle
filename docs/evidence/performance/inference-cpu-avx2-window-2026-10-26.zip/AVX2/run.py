"""Run the two frozen local CPU consumers once, serially; no warmup/sidecar."""
from pathlib import Path
import importlib.util, json, os, sys

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = W.parents[2]
spec = importlib.util.spec_from_file_location('cpu_pair_execute',
    R / '.scratch/inference-synchronous-step-report-20261025/check_host.py')
h = importlib.util.module_from_spec(spec)
spec.loader.exec_module(h)

def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))

def main():
    plan = read(W / 'commands.json')
    results = []
    for name in ('hyle', 'peer'):
        arm = plan[name]
        runtime = read(arm['runtime']['path'])
        env = os.environ.copy()
        env['PATH'] = runtime['PATH']
        env.update(runtime.get('configured_flags', {}))
        env.update(HF_HUB_OFFLINE='1', TRANSFORMERS_OFFLINE='1')
        directory = W / 'run' / name
        try:
            result = h.execute(arm['command'], env, directory, timeout=180)
        except Exception:
            h.save(W / 'run' / 'summary.json', {
                'status': 'STOPPED_AFTER_ARM_FAILURE', 'failed_arm': name,
                'completed': results, 'next_arm_not_started': name == 'hyle',
                'model_retries': 0, 'warmups': 0, 'sidecars': 0})
            raise
        results.append({'arm': name, 'process': result,
                        'ready': arm['ready'], 'runtime': arm['runtime']})
    h.save(W / 'run' / 'summary.json', {
        'status': 'BOTH_CPU_PROCESSES_EXITED_ZERO_NOT_YET_ANALYZED',
        'results': results, 'model_retries': 0, 'warmups': 0, 'sidecars': 0,
        'scope': 'Existing local inputs only. Original prefill/decode/session '
                 'endpoints; startup listed only, not a fair cross-engine metric.'})

if __name__ == '__main__':
    main()
