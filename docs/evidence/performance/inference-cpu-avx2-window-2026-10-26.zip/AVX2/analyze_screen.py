"""Offline summary only. Does not launch a process or modify original reports."""
from pathlib import Path
import hashlib, json, statistics
W = Path(__file__).resolve().parent
S = W / 'screen'
def read(p): return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def pin(p):
    p=Path(p).resolve(); b=p.read_bytes()
    return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def stats(values):
    return dict(count=len(values),min=min(values) if values else None,
        median=statistics.median(values) if values else None,max=max(values) if values else None)
s=read(S/'summary.json'); rows=read(S/'runs.json')
assert s['status']=='COMPLETE' and len(rows)==8 and s['work_all_passed']
assert [x['arm'] for x in rows]==['hyle','peer','peer','hyle','hyle','peer','hyle','peer']
assert all(x['process']['exit']==0 for x in rows)
assert all(x['mode']=='timing' for x in rows[:6]) and all(x['mode']=='memory' for x in rows[6:])
memory={}
for row in rows[6:]:
    f=Path(row['folder']); m=read(f/'memory-summary.json'); t=read(f/'threads.json')
    assert m['setup_error'] is None and m['thread_error'] is None and t['count']>0
    phases={}
    for name,phase in m['phase_windows'].items():
        assert not phase['missing_boundary'] and not phase['ambiguous_boundary'] and not phase['invalid_boundary_order']
        ts=[x['threads'] for x in t['samples'] if 'threads' in x and phase['begin_ns']<=x['timestamp_ns']<=phase['end_ns']]
        phases[name]=dict(memory_samples=phase['sample_count'],os_threads=stats(ts),
            memory_peaks={k:v['max'] for k,v in phase['values'].items()})
    gaps=[(b['timestamp_ns']-a['timestamp_ns'])/1e6 for a,b in zip(t['samples'],t['samples'][1:])]
    memory[row['arm']]=dict(pid=row['process']['pid'],sampled_peaks=m['sampled_peaks'],
        memory_sample_count=m['sample_count'],running_memory_samples=m['running_sample_count'],
        actual_memory_sample_gaps_ms={k:v for k,v in m['actual_sample_gaps_ms'].items() if k!='samples'},
        os_threads=dict(count=t['count'],peak=t['peak'],range={k:v for k,v in t['values'].items() if k!='samples'},
            requested_interval_seconds=.1,actual_sample_gaps_ms=stats(gaps),
            unavailable_samples=[x for x in t['samples'] if 'unavailable' in x]),
        phases=phases,ready_baseline_unknown=m['ready_baseline']['unknown'],
        unavailable_reasons=m['unavailable_reasons'],setup_error=m['setup_error'],thread_error=m['thread_error'],
        raw=dict(memory=pin(f/'memory.json'),threads=pin(f/'threads.json')))
comparison={}
for key in s['timing']['hyle']:
    h=s['timing']['hyle'][key];p=s['timing']['peer'][key]
    comparison[key]=dict(peer_over_hyle_median_percent=(p['median']/h['median']-1)*100,
        ranges_overlap=max(h['min'],p['min'])<=min(h['max'],p['max']))
out=dict(status='FINITE_CPU_SCREEN_6_TIMING_2_INDEPENDENT_MEMORY_PASS',
    timing=s['timing'],paired_timing=s['paired_timing'],median_comparison=comparison,memory=memory,
    processes=[dict(index=x['index'],arm=x['arm'],mode=x['mode'],pid=x['process']['pid'],
        exit=x['process']['exit'],process_wall_seconds=x['process']['process_wall_seconds'],
        folder=x['folder']) for x in rows],
    work=dict(all8_complete_within_arm_non_time_reports_equal_first_AVX2_pair=True,
        same154_prompt_ids=True,same16_generated_ids=True,generated_ids=rows[0]['work']['generated_ids'],
        actual_target_rows_each=169,target_calls_each=16,decode_calls_each=15,draft_rows_each=0,
        greedy=True,EOS_honored=True,early_EOS=False,capacity=256,sessions=1,active_sequences=1,
        prefix_cache=False,restore_count=0,each_hyle_ledger16_records=True,each_hyle_final_live_committed_versions=0),
    timing_protocol=dict(order='B,C,C,B,B,C',B='Hyle fa7b901e',C='same-version peer AVX2 27a49a73',
        timing_samples_per_arm=3,independent_memory_samples_per_arm=1,warmups=0,model_retries=0,
        first_AVX2_pair_pooled=False,generic_peer_samples_pooled=False,
        prefill='154/prefill_seconds',decode='15/decode_seconds; excludes prefill-produced first output',
        combined='16/session_seconds',memory_sampler='Original PSAPI/PDH10ms request; psutil total OS threads100ms request only in memory processes',
        timeout_seconds=180),
    identities=dict(hyle=read(W.parent/'hyle/ready.json')['image'],peer=read(W/'ready.json')['image'],
        commands=pin(W/'commands.json'),initial_plan=pin(S/'plan.json'),memory_continuation=pin(S/'memory-continuation.json'),
        script=pin(W/'screen.py'),analyzer=pin(__file__)),
    initial_observer_failure=dict(phase='Before first memory Popen; no model PID started',
        actual_error=read(S/'first-orchestrator-failure/failure.json'),
        frozen_script=pin(S/'first-orchestrator-failure/screen.py'),
        fix='Forward existing subprocess.PIPE constant through thin Popen wrapper. Continued only the2 originally planned memory processes in fresh folders;6 timing processes not repeated.',
        failed_command_directory=str(S/'07-memory-hyle')),
    limits=[
        'Finite P154/16output/T4 short window,3 timing samples each; not broad CPU scaling or stable deployment throughput.',
        'OS3428/15 thread peaks are actual sampled process counts, not busy threads. No source attribution or performance causation is established by thread count.',
        'T4 requests native4/borrowed Scheduler4/ATen intraop4 for Hyle and actual decode/batch4 for peer, not a process-wide cap.',
        'Same observed greedy16IDs does not prove intermediate-bit, sourceprecision, algorithm or quality equality.',
        'Hyle uses source BF16 activation/store points plus F32 operations/head; peer source contains187BF16+133F32tensors,recurrentF32,K/VBF16.',
        'Peer CPU library now uses AVX2/FMA/F16C same-source build; no kernel sampling proves equal routes/ISA usage across engines.',
        'Hyle outer ATen configuration/Scheduler construction precede its original startup clock; startup/process wall are not fair cold-start comparisons.',
        'Memory processes are separate and not TPS samples. Sampled RAM/PDH maxima are lower bounds; ready-to-prefill gaps had no sample.',
        'Hyle GPU counters have no PID instance and remain null. Peer24576B dedicated/shared0 is observed despite no model offload; linked CUDA registry can initialize.',
        'No product/default/thread-owner change, extra model run, CPU MTP or hybrid test follows from this screen.'])
(S/'final-summary.json').write_bytes((json.dumps(out,indent=2,allow_nan=False)+'\n').encode())
print(json.dumps(dict(summary=pin(S/'final-summary.json'),comparison=comparison,
    memory={a:dict(peaks=v['sampled_peaks'],threads=v['os_threads'],phases=v['phases']) for a,v in memory.items()}),indent=2))
