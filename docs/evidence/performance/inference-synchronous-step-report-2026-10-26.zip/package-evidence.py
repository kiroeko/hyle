"""Publish only existing host/build/screen facts; no compiler/model invocation."""
from pathlib import Path
from datetime import datetime, timezone
import ast
import hashlib
import json
import re
import statistics
import zipfile

ROOT = Path.cwd()
WORK = Path(__file__).resolve().parent
PUBLIC = ROOT / 'docs/evidence/performance'
STEM = 'inference-synchronous-step-report-2026-10-26'
PRIVATE = WORK / 'archive-draft'
PRIVATE.mkdir(exist_ok=True)


def read(path):
    return json.loads(path.read_bytes())


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def pin(path):
    raw = path.read_bytes()
    return {'path': path.relative_to(ROOT).as_posix(), 'bytes': len(raw), 'sha256': sha(raw)}


files = {}


def add(path, member=None):
    assert path.is_file(), path
    member = member or path.relative_to(WORK).as_posix()
    assert member not in files, member
    assert path.suffix.lower() not in ['.obj', '.exe', '.exp', '.lib', '.dll', '.pdb']
    files[member] = path


for name in ['product.patch', 'product-pins.json', 'source-checks.json', 'independent-review.json',
             'source/engine/reporting/execution_report.cc', 'before/engine/reporting/execution_report.cc',
             'source/engine/reporting/execution_report.h', 'source/engine/inference/execution_observation.h',
             'probe.cc', 'prepare.py', 'check_host.py', 'build-cuda.py',
             'screen.py', 'ordinary_screen.py', 'recover-ordinary-summary.py',
             'screen-driver.stdout.log', 'screen-driver.stderr.log',
             'ordinary-screen-driver.stdout.log', 'ordinary-screen-driver.stderr.log',
             'r1-history/product.patch', 'r1-history/product-pins.json',
             'r1-history/probe.cc', 'r1-history/check_host.py',
             'r1-history/source/engine/reporting/execution_report.cc',
             'host1/compile/command.json', 'host1/compile/process.json',
             'host1/compile/stdout.log', 'host1/compile/stderr.log', 'host1/compile/dependencies.json',
             'cuda/ready.json', 'cuda/plan.json', 'cuda/object-map.json',
             'cuda/link-inputs.json', 'cuda/runtime.json', 'cuda/dependency-check-first-failure.json',
             'cuda/report/actual-dependencies.json', 'cuda/report/dependencies.json']:
    add(WORK / name)
for name in ['report', 'link']:
    for leaf in ['command.json', 'process.json', 'stdout.log', 'stderr.log']:
        add(WORK / 'cuda' / name / leaf)
for attempt, stages in [('host2', ['compile-baseline', 'compile-candidate', 'compile-probe', 'link', 'run']),
                        ('host3', ['compile-candidate', 'compile-probe', 'link', 'run'])]:
    for leaf in ['summary.json', 'actual-dependencies.json']:
        add(WORK / attempt / leaf)
    for stage in stages:
        for leaf in ['command.json', 'process.json', 'stdout.log', 'stderr.log']:
            add(WORK / attempt / stage / leaf)
        dep = WORK / attempt / stage / 'dependencies.json'
        if dep.is_file():
            add(dep)

baseline = ROOT / '.scratch/mtp-fixed-hidden-output-20261025/integrated'
for leaf in ['ready.json', 'link-inputs.json', 'runtime.json']:
    add(baseline / leaf, 'control/' + leaf)
add(ROOT / '.scratch/mtp-performance-convergence-20261025/current-cuda/report/command.json',
    'control/original-report-command.json')


def compact_memory(memory):
    result = {key: memory[key] for key in ['sampled_peaks', 'sample_count',
              'ready_baseline', 'null_sample_counts', 'unavailable_reasons']}
    for key in ['actual_sample_gaps_ms', 'sample_cost_ms']:
        result[key] = {name: value for name, value in memory[key].items() if name != 'samples'}
    result['phase_windows'] = {name: {key: phase[key] for key in ['begin_ns', 'end_ns',
        'sample_count', 'missing_boundary', 'ambiguous_boundary', 'invalid_boundary_order',
        'exact_phase_boundary_values', 'bracket_ages_ns']} for name, phase in memory['phase_windows'].items()}
    return result


summaries, validation = {}, []
for folder_name, mtp, calls, counts in [('screen', True, 68, [27, 105]),
                                       ('ordinary-screen', False, 128, [6, 120])]:
    folder = WORK / folder_name
    for leaf in ['summary.json', 'runs.json', 'plan.json']:
        add(folder / leaf)
    if not mtp:
        for leaf in ['first-summary-failure.json', 'offline-validation-pins.json']:
            add(folder / leaf)
    runs = read(folder / 'runs.json')
    assert len(runs) == 8 and all(run['exit'] == 0 for run in runs)
    runner = WORK / ('screen.py' if mtp else 'ordinary_screen.py')
    namespace = dict(json=json, Path=Path, hashlib=hashlib, statistics=statistics)
    tree = ast.parse(runner.read_text())
    functions = [node for node in tree.body if isinstance(node, ast.FunctionDef)
                 and node.name in ['normalize', 'differences', 'report', 'stats']]
    exec(compile(ast.Module(body=functions, type_ignores=[]), str(runner), 'exec'), namespace)
    baseline_report, capture_sequence = None, None
    for run in runs:
        p = ROOT / run['folder']
        raw = namespace['report'](p / 'stdout.log')
        assert raw['mtp'] is mtp
        normalized = namespace['normalize'](raw)
        if baseline_report is None:
            baseline_report = normalized
        assert not namespace['differences'](baseline_report, normalized)
        assert read(p / 'nontime-differences.json') == []
        result = read(p / 'result.json')
        assert result['exit'] == 0 and not result['reader_errors']
        prepared = [re.search(r'prepared T=(\d+) visible=(\d+) replay=(\w+).*'
                              r'capture_recorded=(\d+) capture_reused=(\d+)', line)
                    for line in (p / 'stderr.log').read_text().splitlines()]
        prepared = [tuple(match.groups()) for match in prepared if match]
        assert len(prepared) == calls
        if capture_sequence is None:
            capture_sequence = prepared
        assert prepared == capture_sequence
        actual = [sum(int(row[i]) for row in prepared) for i in [3, 4]]
        assert actual == counts
        validation.append(dict(workload='MTP' if mtp else 'ordinary', mode=run['mode'],
            arm=run['arm'], index=run['index'], all_nontime_equal=True,
            capture_recorded_reused=actual, prepared_observations=calls,
            started_unix_ns=result['started_unix_ns'], finished_unix_ns=result['finished_unix_ns']))
        for leaf in ['command.json', 'result.json', 'stdout.log', 'stderr.log', 'nontime-differences.json']:
            add(p / leaf)
        if run['mode'] == 'memory':
            for leaf in ['memory.json', 'memory-summary.json']:
                add(p / leaf)
    source = read(folder / 'summary.json')
    assert source['all_exit0'] and source['source_work_equal']
    stats = namespace['stats']
    rederived = {arm: {key: stats([row['metrics'][key] for row in runs
                       if row['arm'] == arm and row['mode'] == 'timing'])
                      for key in runs[0]['metrics']} for arm in ['control', 'candidate']}
    assert rederived == source['metrics']
    summaries['MTP' if mtp else 'ordinary'] = {
        'timing_processes': 6, 'independent_memory_processes': 2,
        'metrics': source['metrics'], 'comparisons': source['comparisons'],
        'pair_comparisons': source.get('pair_comparisons'), 'work': source['work'],
        'memory': {arm: compact_memory(memory) for arm, memory in source['memory'].items()},
        'capture_recorded_reused_each_process': counts,
        'raw_summary': pin(folder / 'summary.json')}

host2, host3 = read(WORK / 'host2/summary.json'), read(WORK / 'host3/summary.json')
assert len(host2['contract_cases']) == 24 and len(host3['contract_cases']) == 25
assert all(case['equal'] for case in host3['contract_cases'])
assert not host3['timing_samples']
timing = {arm: [row['seconds'] / row['calls'] * 1e6 for row in host2['timing_samples']
               if row['timing'] == arm] for arm in ['baseline', 'candidate']}
ready = read(WORK / 'cuda/ready.json')
assert ready['total_inputs'] == 234 and ready['unchanged_inputs'] == 233
source_manifest = read(WORK / 'product-pins.json')
assert source_manifest['files'][0]['after']['sha256'] == '878e18b97a493521769fd40c491ddfe75789911f9daa7c6e01e53253d1bc286f'
assert sha((WORK / 'source/engine/reporting/execution_report.cc').read_bytes()) == source_manifest['files'][0]['after']['sha256']
archive = PRIVATE / (STEM + '.zip')
add(Path(__file__).resolve())
manifest = {'members': [{'name': name, 'bytes': path.stat().st_size,
                         'sha256': sha(path.read_bytes())} for name, path in sorted(files.items())]}
(PRIVATE / 'member-sha256.json').write_text(json.dumps(manifest, indent=2) + '\n', encoding='utf-8')
with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for name, path in sorted(files.items()):
        z.write(path, name)
    z.write(PRIVATE / 'member-sha256.json', 'member-sha256.json')
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None and len(z.namelist()) == len(set(z.namelist()))
    for row in manifest['members']:
        raw = z.read(row['name'])
        assert len(raw) == row['bytes'] and sha(raw) == row['sha256']
report = {
    'status': 'SYNCHRONOUS_REPORT_IMPLEMENTATION_MERGE_DECISION_FINITE_SCREENS_COMPLETE',
    'generated_UTC': datetime.now(timezone.utc).isoformat(),
    'scope': 'One report-only candidate,25 host contracts,2 separate frozen-be3 real-two-turn screens: '
             'ordinary and K1 MTP each6 timing+2 independent memory processes. Existing bytes/order '
             'and synchronous delivery retained; no async logger, silent mode, endpoint movement or new peer run.',
    'source': source_manifest, 'build': ready,
    'host': {'final_contract_cases': 25, 'all_pass': True,
        'r1_microcheck_cases': 24, 'microsecond_samples_per_call': timing,
        'microsecond_median_per_call': {arm: statistics.median(values) for arm, values in timing.items()},
        'default_bytes_equal': 224, 'counted_sink_writes_before_after': [66, 1],
        'unitbuf_and_tie_syncs_before_after': [29, 1],
        'new_local_allocations_per_call': 4, 'new_local_allocated_bytes_per_call': 480,
        'micro_scope': 'Author host2 actual synchronous forwarding to stderr pipe; finalr2 changes only the pre-bad width path. host3 reran25 contracts without timing loops. These are not OS syscall counts or Model TPS.'},
    'screens': summaries, 'all16_actual_processes': validation,
    'retained_failures_and_corrections': [
        {'stage': 'host1 compile', 'fact': 'Original probe double-included copied observation structs and omitted existing wd4324; compile failed, no link/run. Original command/deps/stdout/stderr retained; exact pre-fix probe snapshot was not separately preserved.'},
        {'stage': 'source independent review', 'fact': 'Pre-bad stream with nonzero width was not consumed inr1 early return; r2 resetswidth only after nonthrowing emptywrite. Originalr1 source/pins and new25th actual case retained.'},
        {'stage': 'CUDA build runner dependency check', 'fact': 'Report compile passed; string assertion compared c: vsC:. Fixed to WindowsPath equality; same compiled OBJ was reused for one actual link, no TU rerun.', 'evidence': pin(WORK / 'cuda/dependency-check-first-failure.json')},
        {'stage': 'ordinary final summary', 'fact': 'All8 processes already finished exit0 before KeyError actual_draft_rows. Offline recovery reuses original stats and saved original memory parser output. Only derived summary marks missing actual_draft_rows/consumed_drafts=0 after8 independent mtp=false/no draft program confirmations. No raw/runs overwrite or model rerun.', 'evidence': pin(WORK / 'ordinary-screen/first-summary-failure.json')}
    ],
    'independent_merge_recommendation': 'Merge as a bounded synchronous-report implementation improvement: '
        'ordinary decode+0.823%/combined+0.637% with3 positive pairs and disjoint observed ranges; '
        'ordinary prefill-.528% overlaps. MTP decode+.964%/combined+.889% overlaps, so stable MTP throughput benefit is unproven. '
        'Single-file local state has acceptable maintenance cost and preserves normal bytes/order/errors. No further MTP samples or formal peer-window refresh is justified by this package.',
    'limits': ['Three timing samples per arm are descriptive, not significance or broad hardware evidence.',
        'Each workload has one independent memory process per arm. Same sampled dedicated/shared peaks, ready baselines null, original null samples/gaps retained; small single-run RAM differences are not savings claims.',
        'Unitbuf/tie/sentry invocation counts intentionally decrease. Failedsync may expose a different partial prefix; no every-field fault/interleaving or arbitrary custom-facet/tie-callback equivalence is claimed.',
        'Frozenbe3 app/weights/core/Graph/native closure; only report object replaced. Current new coldCPU backend API is not certified by this image. New public peer32 performance table is unchanged.',
        'No binaries, SDK, weight tensors or whole model source tree are packed. Existing prerequisite cache paths and exact pins are retained.'],
    'archive': pin(archive),
    'archive_verification': {'members': len(files) + 1, 'CRC': 'PASS', 'all_content_member_SHA256': 'PASS', 'binary_SDK_model_payload': False}}
(PRIVATE / (STEM + '.json')).write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
for suffix in ['.json', '.zip']:
    assert not (PUBLIC / (STEM + suffix)).exists(), 'Do not overwrite prior public evidence'
(PUBLIC / (STEM + '.zip')).write_bytes(archive.read_bytes())
report['archive']['path'] = (PUBLIC / (STEM + '.zip')).relative_to(ROOT).as_posix()
(PUBLIC / (STEM + '.json')).write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'report': pin(PUBLIC / (STEM + '.json')),
                  'archive': pin(PUBLIC / (STEM + '.zip')), 'members': len(files) + 1}, indent=2))
