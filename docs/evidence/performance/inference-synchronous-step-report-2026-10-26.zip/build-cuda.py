"""One private report TU + exact be3 link closure. Does not execute the image."""
from pathlib import Path
import importlib.util
import json
import os
import sys

sys.dont_write_bytecode = True
WORK = Path(__file__).resolve().parent
ROOT = WORK.parents[1]
OUT = WORK / 'cuda'
BASE = ROOT / '.scratch/mtp-fixed-hidden-output-20261025/integrated'
OLD_REPORT = ROOT / '.scratch/mtp-performance-convergence-20261025/current-cuda/report'
spec = importlib.util.spec_from_file_location('host_recipe', WORK / 'check_host.py')
helper = importlib.util.module_from_spec(spec)
spec.loader.exec_module(helper)
pin, save, execute = helper.pin, helper.save, helper.execute


def read(path):
    return json.loads(path.read_bytes())


def exact(row):
    assert pin(Path(row['path'])) == row, row['path']


resume = sys.argv[1:] == ['--resume-after-compile']
assert not sys.argv[1:] or resume
assert OUT.exists() if resume else not OUT.exists(), 'Do not overwrite a prior attempt'
ready = read(BASE / 'ready.json')
assert ready['image']['sha256'] == 'be3c210ea954e97f7109783baf4b22345c4b4140c7d0d0d12af606807241c22a'
for key in ['image', 'app', 'weights', 'native']:
    exact(ready[key])
manifest = read(WORK / 'product-pins.json')
assert len(manifest['files']) == 1
source = WORK / 'source/engine/reporting/execution_report.cc'
assert pin(source)['sha256'] == '878e18b97a493521769fd40c491ddfe75789911f9daa7c6e01e53253d1bc286f'
assert pin(source) == manifest['files'][0]['after']
support = []
for rel in ['engine/reporting/execution_report.h', 'engine/inference/execution_observation.h']:
    private, canonical = WORK / 'source' / rel, ROOT / rel
    assert private.read_bytes() == canonical.read_bytes()
    support.append({'private': pin(private), 'canonical': pin(canonical)})
original = read(OLD_REPORT / 'command.json')['command']
original_source = str(ROOT / 'engine/reporting/execution_report.cc')
index = original.index(original_source)
compiler = original[0]
flags = original[1:index]
# Preserve the historical malformed command/raw. Its known string-extend /I
# fragments are not valid compiler options and are not replicated in this TU.
junk_start = flags.index('/')
removed = flags[junk_start:]
assert ''.join(removed) == '/I' + str(ROOT)
flags = flags[:junk_start]
assert all(flag in flags for flag in ['/c', '/W4', '/WX', '/O2', '/MD',
                                      '/DHYLE_COMPUTE_CUDA=1', '/DHYLE_COMPUTE_CPU=1'])
assert not any(arg.lower().endswith(('.cc', '.cpp')) for arg in flags)
before_inputs = read(BASE / 'link-inputs.json')
assert len(before_inputs) == 221
for row in before_inputs:
    exact(row)
old_report_obj = str(OLD_REPORT / 'unit.obj')
old_link = read(BASE / 'link/command.json')['command']
assert old_link.count(old_report_obj) == 1
assert old_link.count(ready['app']['path']) == 1
assert old_link.count(ready['weights']['path']) == 1
env = helper.discover_environment(compiler='msvc', cache={
    'CMAKE_C_COMPILER': compiler, 'CMAKE_CXX_COMPILER': compiler,
    'CMAKE_GENERATOR': 'Ninja'}, backends=()).env
OUT.mkdir(exist_ok=resume)
plan = {
    'baseline_ready': pin(BASE / 'ready.json'), 'source': pin(source),
    'source_manifest': pin(WORK / 'product-pins.json'),
    'report_command_original': pin(OLD_REPORT / 'command.json'),
    'removed_historical_invalid_string_extend_arguments': removed,
    'support_headers_byte_equal': support,
    'scope': 'Only the private report TU; frozen be3 app/weights and233 other link inputs unchanged. No GPU run, core/provider/SDK/device rebuild or current backend.h CPU-cold API certification.'}
if not resume:
    save(OUT / 'plan.json', plan)
else:
    assert read(OUT / 'plan.json') == plan
folder = OUT / 'report'
obj = folder / 'unit.obj'
command = [compiler, *flags, str(source), '/sourceDependencies', str(folder / 'dependencies.json'),
           '/Fo' + str(obj), '/Fd' + str(folder / 'unit.pdb')]
if resume:
    compiled = read(folder / 'process.json')
    assert compiled['exit'] == 0
    assert read(folder / 'command.json')['command'] == command
else:
    compiled = execute(command, env, folder, timeout=120)
deps = read(folder / 'dependencies.json')['Data']
assert Path(deps['Source']).resolve() == source.resolve()
actual = list(dict.fromkeys([deps['Source'], *deps['Includes']]))
actual_paths = {Path(path).resolve() for path in actual}
assert str(ROOT / 'engine/reporting/execution_report.cc') not in actual
for row in support:
    assert Path(row['private']['path']).resolve() in actual_paths
    assert Path(row['private']['path']).read_bytes() == Path(row['canonical']['path']).read_bytes()
save(folder / 'actual-dependencies.json', [pin(Path(path)) for path in actual])
args = [str(obj) if arg == old_report_obj else arg for arg in old_link
        if not arg.lower().startswith(('/out:', '/pdb:', '/implib:', '/map:'))]
inputs = [Path(arg) for arg in args[1:] if Path(arg).is_absolute() and Path(arg).suffix.lower() in ('.obj', '.lib')]
assert len(inputs) == 221
after_inputs = [pin(path) for path in inputs]
assert sum(a != b for a, b in zip(before_inputs, after_inputs)) == 1
assert [row for row in before_inputs if row['path'] != old_report_obj] == [row for row in after_inputs if row['path'] != str(obj)]
save(OUT / 'link-inputs.json', after_inputs)
object_map = [{'before': pin(Path(old_report_obj)), 'after': pin(obj)}]
save(OUT / 'object-map.json', object_map)
image = OUT / 'link/hyle.exe'
linked = execute([*args, '/OUT:' + str(image), '/IMPLIB:' + str(image.with_suffix('.lib')),
                  '/PDB:' + str(image.with_suffix('.pdb'))], env, image.parent, timeout=120)
native = Path(ready['native']['path'])
exact(ready['native'])
os.link(native, image.parent / native.name)
runtime = read(BASE / 'runtime.json')
runtime['PATH'] = str(image.parent) + os.pathsep + runtime['PATH']
runtime['original_runtime_record'] = pin(BASE / 'runtime.json')
runtime['native_hardlink'] = pin(image.parent / native.name)
save(OUT / 'runtime.json', runtime)
for row in before_inputs:
    exact(row)
assert pin(source) == manifest['files'][0]['after']
result = {
    'status': 'READY_PRIVATE_SYNCHRONOUS_REPORT_CUDA_LINK_NO_GPU_RUN',
    'baseline_ready': pin(BASE / 'ready.json'), 'baseline_image': ready['image'],
    'image': pin(image), 'app': ready['app'], 'weights': ready['weights'], 'report': pin(obj),
    'source': pin(source), 'source_pins': pin(WORK / 'product-pins.json'),
    'host_contracts': pin(WORK / 'host3/summary.json'),
    'actual_dependencies': pin(folder / 'actual-dependencies.json'),
    'object_map': object_map, 'link_inputs': pin(OUT / 'link-inputs.json'),
    'linked_absolute_inputs': 221, 'inherited_system_libraries': 13,
    'total_inputs': 234, 'unchanged_inputs': 233,
    'native': ready['native'], 'runtime': pin(OUT / 'runtime.json'),
    'processes': {'report': compiled, 'link': linked},
    'commands': {'report': pin(folder / 'command.json'), 'link': pin(image.parent / 'command.json')},
    'new_TUs': 1, 'main_weights_core_provider_SDK_device_rebuilds': 0, 'GPU_runs': 0,
    'limits': 'Compile/link only; no Model behavior/TPS/memory claim. App and weights are frozen be3 objects, unrelated current unused coldCPU backend API changes are not compiled by this image.'}
save(OUT / 'ready.json', result)
print(json.dumps({key: result[key] for key in ['status', 'image', 'processes', 'total_inputs', 'unchanged_inputs']}, indent=2))
