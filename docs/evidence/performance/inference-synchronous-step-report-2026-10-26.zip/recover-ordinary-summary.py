"""Recover only the completed ordinary screen summary. Never import its runner."""
from pathlib import Path
import ast
import hashlib
import json
import math
import re
import statistics

ROOT = Path.cwd()
WORK = Path(__file__).resolve().parent
OUT = WORK / 'ordinary-screen'
original = WORK / 'ordinary_screen.py'
namespace = dict(Path=Path, json=json, hashlib=hashlib, statistics=statistics)
tree = ast.parse(original.read_text(encoding='utf-8'))
selected = [node for node in tree.body if isinstance(node, ast.FunctionDef)
            and node.name in ['read', 'pin', 'normalize', 'differences', 'report', 'stats']]
assert len(selected) == 6
exec(compile(ast.Module(body=selected, type_ignores=[]), str(original), 'exec'), namespace)
read, pin, normalize, differences, report, stats = (namespace[name] for name in
    ['read', 'pin', 'normalize', 'differences', 'report', 'stats'])


def save(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8')


assert not (OUT / 'summary.json').exists(), 'Do not overwrite a recovered summary'
stderr = WORK / 'ordinary-screen-driver.stderr.log'
assert "KeyError: 'actual_draft_rows'" in stderr.read_text()
runs = read(OUT / 'runs.json')
assert len(runs) == 8
expected = [('timing', 'control'), ('timing', 'candidate'), ('timing', 'candidate'),
            ('timing', 'control'), ('timing', 'control'), ('timing', 'candidate'),
            ('memory', 'control'), ('memory', 'candidate')]
assert [(row['mode'], row['arm']) for row in runs] == expected
save(OUT / 'first-summary-failure.json', {
    'status': 'ALL8_PROCESSES_FINISHED_SUMMARY_CONSTRUCTION_FAILED',
    'reason': "Original final work-field projection indexed missing ordinary actual_draft_rows.",
    'runner': pin(original), 'driver_stderr': pin(stderr),
    'driver_stdout': pin(WORK / 'ordinary-screen-driver.stdout.log'),
    'completed_runs': pin(OUT / 'runs.json'),
    'raw_logs_overwritten': False, 'new_processes_for_recovery': 0})
baseline = None
memories, validated, capture_sequence, baseline_stderr = {}, [], None, None
all_source_pins = []
work = None
for run in runs:
    folder = ROOT / run['folder']
    raw = report(folder / 'stdout.log')
    process = read(folder / 'result.json')
    assert process['exit'] == 0 and not process['reader_errors']
    assert process['command'][process['command'].index('--mtp') + 1] == 'off'
    assert raw['mtp'] is False and raw['mtp_tensors'] == 0
    assert raw['draft_program_graph_calls'] == 0 and raw['mtp_max_drafts'] == 0
    assert raw['mtp_acceptance_policy'] == 'disabled'
    assert raw['generated_tokens'] == 128 and raw['generated_decode_tokens'] == 126
    assert raw['prefill_target_rows'] == 309
    current = normalize(raw)
    if baseline is None:
        baseline = current
        assert baseline == read(OUT / 'current-control-nontime.json')
    diff = differences(baseline, current)
    assert not diff
    assert read(folder / 'nontime-differences.json') == []
    p, d, s = raw['prefill_seconds'], raw['decode_seconds'], raw['session_seconds']
    assert math.isclose(p + d, s, rel_tol=1e-5, abs_tol=2e-6)
    recomputed = dict(prefill_seconds=p, decode_seconds=d, session_seconds=s,
                      prefill_tokens_per_second=309 / p,
                      decode_output_tokens_per_second=126 / d,
                      combined_output_tokens_per_second=128 / s)
    assert recomputed == run['metrics']
    actual_work = {key: raw[key] for key in ['mtp', 'mtp_tensors', 'mtp_acceptance_policy',
        'mtp_max_drafts', 'draft_program_graph_calls', 'generated_tokens', 'generated_decode_tokens',
        'actual_graph_calls', 'prefill_graph_calls', 'decode_graph_calls', 'prefill_target_rows',
        'verified_target_rows', 'actual_target_rows', 'committed_target_rows', 'committed_target_decode_rows']}
    absent = []
    for key in ['actual_draft_rows', 'consumed_drafts']:
        if key not in raw:
            absent.append(key)
        else:
            assert raw[key] == 0
        actual_work[key] = raw.get(key, 0)
    if work is None:
        work = actual_work
    assert work == actual_work
    prepared = [re.search(r'prepared T=(\d+) visible=(\d+) replay=(\w+).*'
                         r'capture_recorded=(\d+) capture_reused=(\d+)', line)
                for line in (folder / 'stderr.log').read_text().splitlines()]
    prepared = [tuple(match.groups()) for match in prepared if match]
    assert len(prepared) == 128
    if capture_sequence is None:
        capture_sequence = prepared
    assert prepared == capture_sequence
    # Same emitted field/text order; only the original clock field values vary.
    normalized_stderr = re.sub(r'\b(\w*seconds)=\S+', r'\1=<TIME>',
                              (folder / 'stderr.log').read_text())
    if baseline_stderr is None:
        baseline_stderr = normalized_stderr
    assert normalized_stderr == baseline_stderr
    validated.append(dict(arm=run['arm'], mode=run['mode'], index=run['index'],
        exit=process['exit'], raw_json_complete_nontime_equal=True,
        original_nontime_difference_file_empty=True, original_run_metrics_equal=True,
        ordinary_disabled_draft_facts_verified=True, missing_raw_fields=absent,
        prepared_observations=len(prepared), capture_recorded=sum(int(x[3]) for x in prepared),
        capture_reused=sum(int(x[4]) for x in prepared),
        stderr_equal_after_only_clock_field_values_removed=True,
        started_unix_ns=process['started_unix_ns'], finished_unix_ns=process['finished_unix_ns']))
    all_source_pins.extend(pin(folder / name) for name in ['command.json', 'result.json',
        'stdout.log', 'stderr.log', 'nontime-differences.json'])
    if run['mode'] == 'memory':
        memory = read(folder / 'memory-summary.json')
        samples = read(folder / 'memory.json')['samples']
        assert memory['setup_error'] is None and memory['thread_error'] is None
        assert memory['sample_count'] == len(samples)
        assert memory['phase_window_count'] == 4
        memories[run['arm']] = dict(
            path=pin(folder / 'memory-summary.json'), sampled_peaks=memory['sampled_peaks'],
            sample_count=memory['sample_count'], ready_baseline=memory['ready_baseline'],
            null_sample_counts={key: sum(row.get(key) is None for row in samples) for key in
                ['working_set_bytes', 'private_commit_bytes', 'gpu_dedicated_bytes',
                 'gpu_shared_bytes', 'gpu_total_bytes']},
            unavailable_reasons=memory['unavailable_reasons'],
            actual_sample_gaps_ms=memory['actual_sample_gaps_ms'], sample_cost_ms=memory['sample_cost_ms'],
            phase_windows=memory['phase_windows'])
        all_source_pins.extend(pin(folder / name) for name in ['memory.json', 'memory-summary.json'])
metrics = {arm: {key: stats([row['metrics'][key] for row in runs
                           if row['arm'] == arm and row['mode'] == 'timing'])
                 for key in runs[0]['metrics']} for arm in ['control', 'candidate']}
comparison = {key: dict(candidate_relative_percent=(metrics['candidate'][key]['median'] /
                           metrics['control'][key]['median'] - 1) * 100,
                       ranges_overlap=not (metrics['candidate'][key]['min'] > metrics['control'][key]['max'] or
                                           metrics['control'][key]['min'] > metrics['candidate'][key]['max']))
              for key in metrics['control']}
pairs = []
for index in range(3):
    a, b = runs[2 * index:2 * index + 2]
    control, candidate = (a, b) if a['arm'] == 'control' else (b, a)
    pairs.append(dict(pair=index + 1, actual_order=[a['arm'], b['arm']],
        control_index=control['index'], candidate_index=candidate['index'],
        candidate_relative_percent={key: (candidate['metrics'][key] / control['metrics'][key] - 1) * 100
            for key in ['prefill_tokens_per_second', 'decode_output_tokens_per_second',
                        'combined_output_tokens_per_second']}))
summary = dict(status='BOUNDED_SCREEN_COMPLETE_ALL_WORK_EQUAL_OFFLINE_SUMMARY_RECOVERED',
    timing_processes=6, independent_memory_processes=2, all_exit0=True,
    source_work_equal=True, metrics=metrics, comparisons=comparison,
    pair_comparisons=pairs, memory=memories, work=work,
    validation=validated, historical_samples_pooled=False, latest_llama_comparison=False, profiler=False,
    original_stats_function_reused_by_AST=True,
    original_memory_parser_output_reused_unmodified=True,
    schema_adaptation=dict(source='Derived summary only; all original stdout/result/runs files unchanged.',
        missing_fields=['actual_draft_rows', 'consumed_drafts'], derived_values=[0, 0],
        qualification='All8 original report mtp=false, mtp_tensors=0, draft_program_graph_calls=0, '
                      'mtp_max_drafts=0, mtp_acceptance_policy=disabled and actual argv --mtp off.'),
    retained_first_failure=pin(OUT / 'first-summary-failure.json'),
    recovery_script=pin(Path(__file__)),
    limits=['3 timing samples per arm: descriptive medians/ranges only; no significance claim or fixed clocks.',
            'No new process, compiler, GPU, profiler, SDK, HTTP, payload or canonical edit in recovery.',
            'Original P+D=session endpoints; prefill309 rows, decode126 outputs, combined128.',
            'Independent1 memory process per arm; PSAPI/PDH peaks are sampled lower bounds. Ready null and missing counters remain unknown.',
            'Private report-only replacement with frozenbe3 app/weights; not a current source or new peer full window.'])
save(OUT / 'offline-validation-pins.json', all_source_pins)
save(OUT / 'summary.json', summary)
print(json.dumps(dict(status=summary['status'], work=work, comparisons=comparison,
    memory={arm: value['sampled_peaks'] for arm, value in memories.items()},
    summary=pin(OUT / 'summary.json')), indent=2))
