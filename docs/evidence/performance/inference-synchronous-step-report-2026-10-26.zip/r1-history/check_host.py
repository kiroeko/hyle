from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
import time

WORK = Path(__file__).resolve().parent
ROOT = WORK.parents[1]
sys.path.insert(0, str(ROOT / 'scripts'))
from hyle_environment import discover_environment

def pin(path):
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}

def save(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8')

def execute(command, env, directory, timeout=60):
    directory.mkdir(parents=True, exist_ok=False)
    save(directory / 'command.json', {'command': command, 'cwd': str(ROOT), 'timeout_seconds': timeout})
    start = time.perf_counter()
    with (directory / 'stdout.log').open('wb') as out, (directory / 'stderr.log').open('wb') as err:
        process = subprocess.Popen(command, cwd=ROOT, env=env, stdout=out, stderr=err,
                                   creationflags=subprocess.CREATE_NO_WINDOW)
        save(directory / 'running.json', {'pid': process.pid})
        print('START', directory.name, process.pid, flush=True)
        try:
            code = process.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            process.kill()
            process.wait()
            code = -999
    result = {'exit': code, 'pid': process.pid, 'seconds': time.perf_counter() - start}
    save(directory / 'process.json', result)
    print('END', directory.name, result, flush=True)
    if code:
        print((directory / 'stdout.log').read_text(errors='replace')[-10000:], flush=True)
        print((directory / 'stderr.log').read_text(errors='replace')[-2000:], flush=True)
        raise RuntimeError('stage failed; original raw retained')
    return result

def main():
    out = WORK / (sys.argv[1] if len(sys.argv) > 1 else 'host1')
    if out.exists():
        raise FileExistsError(out)
    old = json.loads((ROOT / '.scratch/inference-cold-weights-split-20261025/cpu1/compile-weights/command.json').read_text())
    compiler = old['command'][0]
    env = discover_environment(compiler='msvc', cache={
        'CMAKE_C_COMPILER': compiler, 'CMAKE_CXX_COMPILER': compiler, 'CMAKE_GENERATOR': 'Ninja'}, backends=()).env
    image = out / 'link/probe.exe'
    flags = [compiler, '/nologo', '/std:c++latest', '/EHsc', '/Zc:__cplusplus', '/Zc:preprocessor',
        '/utf-8', '/O2', '/MD', '/permissive-', '/W4', '/WX', '/DHYLE_STATIC', '/DNOMINMAX',
        '/wd4324', '/I' + str(ROOT / 'include'), '/I' + str(ROOT), '/c']
    compiled, deps, objects = {}, [], []
    for name, source, extra in [('baseline', WORK / 'before/engine/reporting/execution_report.cc', ['/Dreporting=baseline_reporting']),
                                ('candidate', WORK / 'source/engine/reporting/execution_report.cc', []),
                                ('probe', WORK / 'probe.cc', [])]:
        stage = out / ('compile-' + name)
        obj = stage / 'unit.obj'
        compile_command = [*flags, *extra, str(source), '/sourceDependencies', str(stage / 'dependencies.json'),
                           '/Fo' + str(obj), '/Fd' + str(stage / 'unit.pdb')]
        compiled[name] = execute(compile_command, env, stage)
        objects.append(str(obj))
        dep = json.loads((stage / 'dependencies.json').read_text(encoding='utf-8-sig'))['Data']
        deps.extend([dep['Source'], *dep['Includes']])
    deps = list(dict.fromkeys(deps))
    save(out / 'actual-dependencies.json', [pin(Path(p)) for p in deps])
    assert not any('ggml' in p.lower() or 'cuda' in p.lower() for p in deps)
    link = str(Path(compiler).with_name('link.exe'))
    linked = execute([link, '/NOLOGO', *objects, '/OUT:' + str(image), '/PDB:' + str(out / 'link/probe.pdb')], env, out / 'link')
    ran = execute([str(image)], env, out / 'run')
    rows = [json.loads(line) for line in (out / 'run/stdout.log').read_text().splitlines()]
    assert rows[-1]['status'] == 'PASS'
    cases = [r for r in rows if 'case' in r]
    timings = [r for r in rows if 'timing' in r]
    assert len(cases) == 24 and all(r['equal'] for r in cases) and len(timings) == 6
    save(out / 'summary.json', {
        'status': 'HOST_ONLY_SYNCHRONOUS_REPORT_PROBE_PASS', 'compile': compiled, 'link': linked, 'run': ran,
        'image': pin(image), 'source': pin(WORK / 'source/engine/reporting/execution_report.cc'),
        'before': pin(WORK / 'before/engine/reporting/execution_report.cc'), 'probe': pin(WORK / 'probe.cc'),
        'source_pins': pin(WORK / 'product-pins.json'), 'actual_dependency_count': len(deps),
        'contract_cases': cases, 'timing_samples': timings,
        'limits': [
            'Host-only three small TUs: actual baseline report, candidate report, and probe; no engine/core/SDK/provider build or GPU.',
            'Successful bytes/order/format/locale/tie/exceptions contract checked. Sink short-write and thrown error keep state/exception.',
            'A unitbuf sync failure can expose a different partial prefix after write coalescing; both streams become bad. No exact per-field side-effect equivalence on a failing device is claimed.',
            'New ostringstream allocations counted inside the writer and timed. Std-error is synchronously forwarded to the original process pipe; no silence/async/deferred write.',
            'Three alternating 128-call pairs are a descriptive host microcheck, not an end-to-end TPS or significance result.',
        ]})
    print(json.dumps({'summary': pin(out / 'summary.json'), 'contract_cases': len(cases), 'timing_samples': len(timings)}, indent=2))

if __name__ == '__main__':
    main()
