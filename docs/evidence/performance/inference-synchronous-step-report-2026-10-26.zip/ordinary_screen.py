from pathlib import Path
import datetime
import hashlib
import importlib.util
import json
import math
import os
import statistics
import sys

sys.dont_write_bytecode = True
R = Path.cwd()
W = Path(__file__).resolve().parent
B = R / '.scratch/mtp-performance-convergence-20261025/baseline'
C = R / '.scratch/mtp-fixed-hidden-output-20261025/integrated'
O = W / 'ordinary-screen'
spec = importlib.util.spec_from_file_location('retained_screen', B / 'window.py')
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)
m.WORKLOAD = 'two-turn'
helpers = m.helpers()


def read(p):
    return json.loads(p.read_text(encoding='utf-8-sig'))


def pin(p):
    p = Path(p)
    return dict(path=str(p.resolve()), bytes=p.stat().st_size,
                sha256=hashlib.sha256(p.read_bytes()).hexdigest())


def save(p, value):
    p.write_text(json.dumps(value, indent=2) + '\n', encoding='utf8')


def normalize(value):
    # Original retained screen's clock exclusions, unchanged. No cache,
    # capture, state, work or other metadata exclusions are introduced.
    if isinstance(value, list):
        return [normalize(x) for x in value]
    if isinstance(value, dict):
        return {k: normalize(x) for k, x in value.items()
                if not any(t in k for t in
                           ['seconds', 'tokens_per_second', 'clock_unix',
                            'unix_ns', 'unix_ms'])}
    return value


def differences(a, b, path='$'):
    if type(a) is not type(b):
        return [dict(path=path, control=a, candidate=b)]
    if isinstance(a, dict):
        result = []
        for key in sorted(set(a) | set(b)):
            if key not in a or key not in b:
                result.append(dict(path=path + '.' + key,
                                   control=a.get(key), candidate=b.get(key)))
            else:
                result.extend(differences(a[key], b[key], path + '.' + key))
        return result
    if isinstance(a, list):
        if len(a) != len(b):
            return [dict(path=path, control_length=len(a), candidate_length=len(b))]
        return [row for i, (x, y) in enumerate(zip(a, b))
                for row in differences(x, y, f'{path}[{i}]')]
    return [] if a == b else [dict(path=path, control=a, candidate=b)]


def report(p):
    return json.loads(next(x for x in reversed(p.read_text(encoding='utf8').splitlines())
                           if x.startswith('{')))


def stats(values):
    return dict(count=len(values), median=statistics.median(values),
                min=min(values), max=max(values), samples=values)


control, candidate = read(C / 'ready.json'), read(W / 'cuda/ready.json')
images = dict(control=control['image'], candidate=candidate['image'])
for image in images.values():
    assert pin(image['path'])['sha256'] == image['sha256']
original = read(B / 'two-turn-timing/01-hyle_plain/command.json')['command']
inputs = Path(original[original.index('--inputs') + 1])
schedule = Path(original[original.index('--schedule') + 1])
assert not O.exists(), 'Keep previous runs; never overwrite or pool a screen.'
O.mkdir()
order = ['control', 'candidate', 'candidate', 'control', 'control', 'candidate']
save(O / 'plan.json', dict(
    created_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    timing_order=order, memory_order=['control', 'candidate'], images=images,
    app=candidate['app'], report=candidate['report'], runtime=pin(C / 'runtime.json'),
    source_review=pin(W / 'product-pins.json'),
    independent_review=pin(W / 'independent-review.json'),
    original_command=pin(B / 'two-turn-timing/01-hyle_plain/command.json'),
    schedule=pin(schedule),
    inputs=[pin(inputs / n) for n in ['weights.tsv', 'prompt.ids', 'input.json']],
    retained_screen=pin(R / '.scratch/mtp-native-seed-candidate-20261025/screen.py'),
    retained_memory_and_marker_helper=pin(B / 'window.py'),
    memory_interval_seconds=0.01, profiler=False, warmup=False,
    SDK_builds=0, HTTP=0, reference='First actual current control, no old report.',
    scope='Bounded frozen-be3 Hyle ordinary two-turn report-only control/candidate screen; first pair '
          'is the behavior gate. 3 serial interleaved pairs and1 independent '
          'memory process per arm. Original protocol, no old samples pooled.'))
results, memories, baseline = [], {}, None
helpers.gpu_snapshot(O, 'before')
try:
    for mode, sequence in [('timing', order), ('memory', ['control', 'candidate'])]:
        for index, arm in enumerate(sequence, 1):
            folder = O / (mode + f'-{index:02}-' + arm)
            command = original.copy()
            command[0] = images[arm]['path']
            env = os.environ.copy()
            env.update(HF_HUB_OFFLINE='1', TRANSFORMERS_OFFLINE='1')
            env['PATH'] = str(Path(command[0]).parent) + ';' + read(C / 'runtime.json')['PATH']
            print('BEGIN', mode, index, arm,
                  datetime.datetime.now(datetime.timezone.utc).isoformat(), flush=True)
            record = helpers.execute(folder, arm, command, env, mode == 'memory')
            raw = report(folder / 'stdout.log')
            normalized = normalize(raw)
            if baseline is None:
                assert arm == 'control' and mode == 'timing'
                baseline = normalized
                save(O / 'current-control-nontime.json', baseline)
            delta = differences(baseline, normalized)
            save(folder / 'nontime-differences.json', delta)
            assert not delta, (arm, mode, 'Non-time work or metadata changed; retained exact differences.')
            p, d, s = raw['prefill_seconds'], raw['decode_seconds'], raw['session_seconds']
            assert math.isclose(p + d, s, rel_tol=1e-5, abs_tol=2e-6)
            assert raw['prefill_target_rows'] == 309 and raw['generated_tokens'] == 128
            metrics = dict(prefill_seconds=p, decode_seconds=d, session_seconds=s,
                           prefill_tokens_per_second=309 / p,
                           decode_output_tokens_per_second=126 / d,
                           combined_output_tokens_per_second=128 / s)
            results.append(dict(arm=arm, mode=mode, index=index, exit=record['exit'],
                                folder=folder.relative_to(R).as_posix(),
                                source_work_equal=True, metrics=metrics))
            save(O / 'runs.json', results)
            if mode == 'memory':
                memory = read(folder / 'memory-summary.json')
                assert memory['setup_error'] is None and memory['thread_error'] is None
                memories[arm] = dict(
                    path=pin(folder / 'memory-summary.json'),
                    sampled_peaks=memory['sampled_peaks'], sample_count=memory['sample_count'],
                    ready_baseline=memory['ready_baseline'],
                    null_sample_counts={key: sum(row.get(key) is None for row in
                        read(folder / 'memory.json')['samples']) for key in
                        ['working_set_bytes', 'private_commit_bytes', 'gpu_dedicated_bytes',
                         'gpu_shared_bytes', 'gpu_total_bytes']},
                    unavailable_reasons=memory['unavailable_reasons'],
                    actual_sample_gaps_ms=memory['actual_sample_gaps_ms'],
                    sample_cost_ms=memory['sample_cost_ms'], phase_windows=memory['phase_windows'])
            print('END', mode, index, arm, flush=True)
finally:
    helpers.gpu_snapshot(O, 'after')

metrics = {arm: {key: stats([x['metrics'][key] for x in results
                            if x['arm'] == arm and x['mode'] == 'timing'])
                  for key in results[0]['metrics']} for arm in images}
comparison = {key: dict(
    candidate_relative_percent=(metrics['candidate'][key]['median'] /
                                metrics['control'][key]['median'] - 1) * 100,
    ranges_overlap=not (metrics['candidate'][key]['min'] > metrics['control'][key]['max'] or
                       metrics['control'][key]['min'] > metrics['candidate'][key]['max']))
    for key in metrics['control']}
summary = dict(
    status='BOUNDED_SCREEN_COMPLETE_ALL_WORK_EQUAL', timing_processes=6,
    independent_memory_processes=2, all_exit0=all(x['exit'] == 0 for x in results),
    source_work_equal=True, metrics=metrics, comparisons=comparison, memory=memories,
    work={key: raw[key] for key in ['generated_tokens', 'actual_graph_calls',
        'prefill_target_rows', 'verified_target_rows', 'actual_target_rows',
        'actual_draft_rows', 'consumed_drafts']},
    historical_samples_pooled=False, latest_llama_comparison=False, profiler=False,
    limits=['3 observations per arm: descriptive medians/ranges only, no fixed clocks.',
            'Original P+D=session endpoints. Decode126 outputs; combined128; prefill309 rows.',
            'Independent1 memory process per arm; PSAPI/PDH maxima are sampled lower bounds.',
            'Private synchronous step-report TU candidate; no canonical merge or full peer window.',
            'No device fault injection or complete intermediate tensor readback in this screen.'])
save(O / 'summary.json', summary)
print(json.dumps(dict(metrics=metrics, comparisons=comparison,
                     memory={a: v['sampled_peaks'] for a, v in memories.items()}), indent=2), flush=True)
print('SCREEN_TERMINAL_GPU_RELEASED', flush=True)
