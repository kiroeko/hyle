#include <algorithm>
#include <chrono>
#include <cstdlib>
#include <iomanip>
#include <iostream>
#include <locale>
#include <new>
#include <sstream>
#include <stdexcept>
#include <string>
#include <vector>

namespace allocations {
thread_local bool enabled = false;
thread_local std::size_t calls = 0, bytes = 0;
}
void *operator new(std::size_t bytes) {
  if (void *p = std::malloc(bytes ? bytes : 1)) {
    if (allocations::enabled) { ++allocations::calls; allocations::bytes += bytes; }
    return p;
  }
  throw std::bad_alloc();
}
void *operator new[](std::size_t bytes) { return ::operator new(bytes); }
void operator delete(void *p) noexcept { std::free(p); }
void operator delete[](void *p) noexcept { std::free(p); }
void operator delete(void *p, std::size_t) noexcept { std::free(p); }
void operator delete[](void *p, std::size_t) noexcept { std::free(p); }

#include "source/engine/reporting/execution_report.h"
#include "source/engine/inference/execution_observation.h"
namespace hyle::engine::baseline_reporting {
void write_step_observation(std::ostream &, const hyle::inference::StepObservation &);
}

using Step = hyle::inference::StepObservation;
using Writer = void (*)(std::ostream &, const Step &);
constexpr Writer baseline = &hyle::engine::baseline_reporting::write_step_observation;
constexpr Writer candidate = &hyle::engine::reporting::write_step_observation;

struct Sink final : std::streambuf {
  std::string bytes;
  std::size_t writes = 0, syncs = 0;
  std::size_t limit = static_cast<std::size_t>(-1);
  bool throws = false, capture = true, fail_sync = false;
  std::streambuf *delegate = nullptr;
  Sink() { bytes.reserve(4096); }
  std::streamsize xsputn(const char *text, std::streamsize n) override {
    ++writes;
    if (throws) throw std::runtime_error("sink threw");
    const auto count = std::min(static_cast<std::size_t>(n), limit);
    if (capture) bytes.append(text, count);
    if (delegate) return delegate->sputn(text, static_cast<std::streamsize>(count));
    limit -= count;
    return static_cast<std::streamsize>(count);
  }
  int_type overflow(int_type c) override {
    if (traits_type::eq_int_type(c, traits_type::eof())) return traits_type::not_eof(c);
    const char value = traits_type::to_char_type(c);
    return xsputn(&value, 1) == 1 ? c : traits_type::eof();
  }
  int sync() override {
    ++syncs;
    if (fail_sync) return -1;
    return delegate ? delegate->pubsync() : 0;
  }
};

struct Punctuation final : std::numpunct<char> {
  char do_decimal_point() const override { return ','; }
  char do_thousands_sep() const override { return '\''; }
  std::string do_grouping() const override { return "\3"; }
};
struct ThrowNumber final : std::num_put<char> {
  iter_type do_put(iter_type, std::ios_base &, char_type, unsigned long long) const override {
    throw std::runtime_error("numeric facet failure");
  }
};

struct Result {
  std::string bytes, exception;
  std::ios_base::fmtflags flags{};
  std::ios_base::iostate state{}, exceptions{};
  std::streamsize precision = 0, width = 0;
  char fill = 0;
  std::size_t writes = 0, syncs = 0, tie_syncs = 0, allocation_calls = 0, allocation_bytes = 0;
  bool locale_preserved = false, tie_preserved = false;
};

Step step(unsigned kind) {
  Step value;
  value.name = kind == 3 ? "" : "decode";
  value.input_tokens = 1; value.graph_input_tokens = 1; value.visible = 512;
  value.next = -42; value.seconds = 0.001234567890123; value.submit_seconds = 0.000123;
  value.step_seconds = 0.001456789; value.cold_batch_seconds = 0.000019;
  value.replay_route = hyle::graph::ReplayRoute::kCaptured;
  value.capture_reused = 2; value.graph_executed = kind != 2;
  value.prefix_hit = kind == 1; value.reused_tokens = 256; value.scheduled_progress = kind == 1;
  return value;
}

Result invoke(Writer writer, const Step &value, unsigned mode, unsigned fault, bool exceptions) {
  Sink sink, tied;
  std::ostream tie(&tied), output(&sink);
  output.tie(&tie);
  output.setf(std::ios_base::unitbuf);
  if (mode == 1) output << std::hex << std::showbase << std::boolalpha << std::uppercase << std::scientific << std::setprecision(17);
  if (mode == 2) output << std::fixed << std::setprecision(4);
  if (mode == 3) output.imbue(std::locale(std::locale::classic(), new Punctuation));
  if (mode == 4) output.imbue(std::locale(std::locale::classic(), new ThrowNumber));
  output.fill('~'); output.width(mode ? 19 : 0);
  const auto locale = output.getloc();
  if (fault == 1) sink.limit = 9;
  if (fault == 2) sink.throws = true;
  if (fault == 3) output.setstate(std::ios_base::badbit);
  if (fault == 4) sink.fail_sync = true;
  if (exceptions) output.exceptions(std::ios_base::badbit | std::ios_base::failbit);
  sink.writes = sink.syncs = tied.syncs = 0;
  allocations::calls = allocations::bytes = 0;
  Result result;
  allocations::enabled = true;
  try { writer(output, value); }
  catch (const std::ios_base::failure &) { allocations::enabled = false; result.exception = "ios_failure"; }
  catch (const std::runtime_error &error) { allocations::enabled = false; result.exception = error.what(); }
  allocations::enabled = false;
  result.allocation_calls = allocations::calls; result.allocation_bytes = allocations::bytes;
  result.bytes = sink.bytes; result.flags = output.flags(); result.state = output.rdstate();
  result.precision = output.precision(); result.width = output.width(); result.fill = output.fill();
  result.exceptions = output.exceptions(); result.locale_preserved = output.getloc() == locale;
  result.tie_preserved = output.tie() == &tie;
  result.writes = sink.writes; result.syncs = sink.syncs; result.tie_syncs = tied.syncs;
  return result;
}

void require(bool condition, const char *message) { if (!condition) throw std::runtime_error(message); }

void compare(unsigned kind, unsigned mode, unsigned fault, bool exceptions) {
  const auto value = step(kind);
  const auto a = invoke(baseline, value, mode, fault, exceptions);
  const auto b = invoke(candidate, value, mode, fault, exceptions);
  const bool equal = (fault == 4 || a.bytes == b.bytes) && a.flags == b.flags && a.state == b.state &&
      a.precision == b.precision && a.width == b.width && a.fill == b.fill &&
      a.exceptions == b.exceptions && a.exception == b.exception &&
      a.locale_preserved && b.locale_preserved && a.tie_preserved && b.tie_preserved;
  std::cout << "{\"case\":[" << kind << ',' << mode << ',' << fault << ',' << exceptions
      << "],\"equal\":" << equal << ",\"bytes\":" << b.bytes.size()
      << ",\"before_bytes\":" << a.bytes.size() << ",\"after_bytes\":" << b.bytes.size()
      << ",\"before_state\":" << a.state << ",\"after_state\":" << b.state
      << ",\"before_syncs\":" << a.syncs << ",\"after_syncs\":" << b.syncs
      << ",\"before_tie_syncs\":" << a.tie_syncs << ",\"after_tie_syncs\":" << b.tie_syncs
      << ",\"before_writes\":" << a.writes << ",\"after_writes\":" << b.writes
      << ",\"before_allocations\":" << a.allocation_calls << ",\"after_allocations\":" << b.allocation_calls
      << ",\"before_allocated_bytes\":" << a.allocation_bytes << ",\"after_allocated_bytes\":" << b.allocation_bytes
      << ",\"before_exception\":\"" << a.exception << "\",\"after_exception\":\"" << b.exception << "\"}\n";
  require(equal, "bytes/format/error contract mismatch");
}

void timing(Writer writer, const char *arm, unsigned pair) {
  Sink sink, tied;
  sink.capture = tied.capture = false;
  sink.delegate = std::cerr.rdbuf(); tied.delegate = std::cout.rdbuf();
  std::ostream tie(&tied), output(&sink);
  output.tie(&tie); output.setf(std::ios_base::unitbuf);
  const auto value = step(0);
  allocations::calls = allocations::bytes = 0;
  allocations::enabled = true;
  const auto start = std::chrono::steady_clock::now();
  for (unsigned i = 0; i < 128; ++i) writer(output, value);
  const auto seconds = std::chrono::duration<double>(std::chrono::steady_clock::now() - start).count();
  allocations::enabled = false;
  const auto calls = allocations::calls, bytes = allocations::bytes;
  require(output.good(), "synchronous stderr failed");
  std::cout << std::setprecision(17) << "{\"timing\":\"" << arm << "\",\"pair\":" << pair
      << ",\"calls\":128,\"seconds\":" << seconds << ",\"writes\":" << sink.writes
      << ",\"syncs\":" << sink.syncs << ",\"tie_syncs\":" << tied.syncs
      << ",\"allocation_calls\":" << calls << ",\"allocated_bytes\":" << bytes << "}\n";
}

int main(int argc, char **) {
  try {
    for (unsigned kind = 0; kind < 4; ++kind)
      for (unsigned mode = 0; mode < 4; ++mode) compare(kind, mode, 0, false);
    for (unsigned fault = 1; fault <= 4; ++fault) compare(0, 0, fault, false);
    compare(0, 1, 3, false);
    for (unsigned fault = 1; fault <= 2; ++fault) compare(0, 0, fault, true);
    compare(0, 4, 0, false); compare(0, 4, 0, true);
    for (unsigned pair = 0; argc == 1 && pair < 3; ++pair) {
      if (pair == 1) { timing(candidate, "candidate", pair); timing(baseline, "baseline", pair); }
      else { timing(baseline, "baseline", pair); timing(candidate, "candidate", pair); }
    }
    std::cout << "{\"status\":\"PASS\",\"contract_cases\":25,\"timed_calls_per_arm\":" << (argc == 1 ? 384 : 0) << "}\n";
    return 0;
  } catch (const std::exception &error) { std::cout << "probe_failure=" << error.what() << '\n'; return 1; }
}
