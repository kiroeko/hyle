from pathlib import Path
import difflib
import hashlib
import json

WORK = Path(__file__).resolve().parent
ROOT = WORK.parents[1]
REL = 'engine/reporting/execution_report.cc'

def pin(path):
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}

raw = (ROOT / REL).read_bytes()
newline = '\r\n' if b'\r\n' in raw else '\n'
before = raw.decode('utf-8').replace('\r\n', '\n')
start = before.index('void write_step_observation(')
end = before.index('void write_preparation_observation(', start)
old = before[start:end]
signature = 'void write_step_observation(std::ostream &output, const inference::StepObservation &step) {\n'
assert old.startswith(signature) and old.endswith('}\n')
body = old[len(signature):-2].replace('output <<', 'record <<')
setup = '''  // Keep the original synchronous endpoint, but emit one formatted record.
  if (!output.good()) { output.write("", 0); output.width(0); return; }
  std::ostringstream record;
  record.imbue(output.getloc());
  record.flags(output.flags() & ~std::ios_base::unitbuf);
  record.precision(output.precision());
  record.width(output.width());
  record.fill(output.fill());
  record.exceptions(output.exceptions());
  const auto emit = [&] {
    output.width(record.width());
    const auto text = record.view();
    output.write(text.data(), static_cast<std::streamsize>(text.size()));
    output.setstate(record.rdstate());
  };
  try {
'''
finish = '''  } catch (...) {
    // Preserve a formatting exception after publishing its original prefix.
    try { emit(); } catch (...) {}
    throw;
  }
  emit();
}
'''
after = before[:start] + signature + setup + ''.join('  ' + line if line.strip() else line for line in body.splitlines(keepends=True)) + finish + before[end:]
after = after.replace('#include <ostream>\n', '#include <ostream>\n#include <sstream>\n', 1)
for side in ('before', 'source'):
    for rel in (REL, 'engine/reporting/execution_report.h', 'engine/inference/execution_observation.h'):
        dst = WORK / side / rel
        dst.parent.mkdir(parents=True, exist_ok=True)
        data = after.replace('\n', newline).encode('utf-8') if side == 'source' and rel == REL else (ROOT / rel).read_bytes()
        dst.write_bytes(data)
patch = ''.join(difflib.unified_diff(before.splitlines(keepends=True), after.splitlines(keepends=True), fromfile='a/' + REL, tofile='b/' + REL))
(WORK / 'product.patch').write_text(patch, encoding='utf-8', newline='')
pins = {'files': [{'path': REL, 'before': pin(WORK / 'before' / REL), 'after': pin(WORK / 'source' / REL)}]}
(WORK / 'product-pins.json').write_text(json.dumps(pins, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'pins': pin(WORK / 'product-pins.json'), 'patch': pin(WORK / 'product.patch')}, indent=2))
