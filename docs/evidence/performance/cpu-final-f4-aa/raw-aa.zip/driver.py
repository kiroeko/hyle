exec(open('.scratch/cpu-ggml-isa-product-validate.py',encoding='utf-8').read().split("run('configure'")[0])
env['OMP_NUM_THREADS']='1';env['MKL_NUM_THREADS']='1'
out=repo/'.scratch/validation/cpu-final-f4/aa-windows';out.mkdir(parents=True,exist_ok=True);records=[]
b=Path('C:/hv/cpu-final-f4-probe')
run('build-aa-batch',['cmake','--build',b,'--target','hyle_cpu_best_of_batch','--parallel','2'])
run('bounded-workload-aa',['python',repo/'bench/compute_provider_native/cpu_best_of_p1/validate_aa.py','--build',b,'--output',out/'raw'])
