. C:/hyle-scratch/r3-cpu-20260916/msvc-env.ps1
$env:HYLE_BENCH_VENDOR_DIR = 'C:/public/project-hyle'
python -X utf8 scripts/hyle-perf.py qualify-platform --contract bench/contracts/graph-cpu-route-p1-v3.json --machine W1-WIN --peer hyle-native-mlp=C:/hyle-scratch/r3-cpu-20260916/candidate-1a3a8d0e --peer onednn-direct-gated-mlp=C:/hyle-scratch/onednn-71094df45190 --source C:/hyle-scratch/r3-cpu-20260916/candidate-7fa6dc0a --build C:/hyle-scratch/r3-cpu-20260916/p1-graph-v3-build --output C:/hyle-scratch/r3-cpu-20260916/p1-graph-v3 *> C:/hyle-scratch/r3-cpu-20260916/p1-graph-v3-run.log
$grExit = $LASTEXITCODE
Get-Content C:/hyle-scratch/r3-cpu-20260916/p1-graph-v3-run.log -Tail 35
exit $grExit
