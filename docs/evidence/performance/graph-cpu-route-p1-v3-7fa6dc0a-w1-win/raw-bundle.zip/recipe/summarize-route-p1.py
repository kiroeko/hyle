"""Read retained P1 intervals; report direction separately from the NI gate."""
import json
import pathlib
import sys

source = pathlib.Path(sys.argv[1])
summary = json.loads(source.read_text(encoding='utf-8-sig'))
rows = []
for workload in summary['workloads']:
    strata = workload['strata']
    estimates = [s['estimate'] for s in strata]
    ratios = [e['median_advantage_ratio'] for e in estimates]
    intervals = [e['confidence_interval'] for e in estimates]
    direction = ('WIN' if all(lo > 1 for lo, hi in intervals) else
                 'LOSS' if all(hi < 1 for lo, hi in intervals) else
                 'INCONCLUSIVE')
    units = {s['absolute']['unit'] for s in strata}
    assert len(units) == 1
    candidate = [s['absolute']['candidate_median'] for s in strata]
    peer = [s['absolute']['peer_median'] for s in strata]
    row = dict(id=workload['id'], strict_direction=direction,
               noninferiority=workload['combined_noninferiority_gate'],
               ratio_range=[min(ratios), max(ratios)],
               interval_envelope=[min(e[0] for e in intervals), max(e[1] for e in intervals)],
               absolute_unit=next(iter(units)), candidate_range=[min(candidate), max(candidate)],
               peer_range=[min(peer), max(peer)],
               independent_runs=sorted({s['absolute']['independent_runs'] for s in strata}),
               unresolved=[dict(id=s['id'], gate=s['noninferiority_gate'], estimate=s['estimate'])
                           for s in strata if s['noninferiority_gate'] != 'PASS'])
    if units == {'op/s'}:
        row['candidate_microseconds_range'] = [1e6 / max(candidate), 1e6 / min(candidate)]
        row['peer_microseconds_range'] = [1e6 / max(peer), 1e6 / min(peer)]
    rows.append(row)
report = dict(source=str(source), qualification=summary['qualification'],
              contract_sha256=summary['contract_sha256'], workloads=rows)
print(json.dumps(report, ensure_ascii=False, indent=2))
