$ErrorActionPreference = 'Stop'
. C:/hyle-scratch/r3-cpu-20260916/msvc-env.ps1
$grRoot = 'C:/hyle-scratch/r3-cpu-20260916'
$grBin = "$grRoot/p1-graph-v3-build/bin"
if (-not (Test-Path -LiteralPath "$grRoot/p1-graph-v3-build/CMakeCache.txt")) { throw 'Fresh P1 configuration is not ready' }
New-Item -ItemType Directory -Path $grBin -Force | Out-Null
# Same CRT bytes the preceding static candidate resolved from System32.
# Stage before the fresh candidate finishes building or launches any validator.
$grDependencies = & dumpbin /nologo /dependents "$grRoot/p1-graph-v2-build/bin/hyle_graph_onednn_region_bench.exe"
if ($LASTEXITCODE -ne 0) { throw 'Runtime dependency inspection failed' }
$grCrtNames = @($grDependencies | ForEach-Object { if ($_ -match '^\s*((?:MSVCP|VCRUNTIME|VCOMP)[A-Za-z0-9_]+\.dll)\s*$') { $Matches[1] } } | Sort-Object -Unique)
$grCrtReceipt = foreach ($grDllName in $grCrtNames) {
  $grDllSource = Join-Path ([Environment]::GetFolderPath('System')) $grDllName
  if (-not (Test-Path -LiteralPath $grDllSource)) { throw "Required runtime DLL missing: $grDllName" }
  Copy-Item -LiteralPath $grDllSource -Destination $grBin
  [ordered]@{Source=$grDllSource; Destination=(Join-Path $grBin $grDllName); Sha256=(Get-FileHash -LiteralPath $grDllSource -Algorithm SHA256).Hash}
}
@($grCrtReceipt) | ConvertTo-Json -Depth 4 | Set-Content -LiteralPath "$grRoot/p1-graph-v3-runtime-staging.json" -Encoding utf8
