#include <cstdint>
namespace timer_probe { std::uint64_t visits = 0; }
#include "hyle/time/timer_queue.h"
#include <cstdio>
#include <cstdlib>
#include <vector>

using hyle::time::TimerEntry;
using hyle::time::TimerQueue;
void require(bool condition) { if (!condition) std::abort(); }
int main() {
  constexpr std::uint64_t base = std::uint64_t{1} << 40;
  for (const auto n : {64u, 1024u, 16384u}) {
    for (const bool cancel_minimum : {false, true}) {
      std::vector<TimerEntry> entries(n);
      TimerQueue queue(0);
      for (unsigned i = 0; i != n; ++i) queue.schedule(&entries[i], base + i);
      if (cancel_minimum) require(queue.cancel(&entries[0]));
      timer_probe::visits = 0;
      for (std::uint64_t now = 1; now <= 128; ++now) {
        TimerQueue::EntryList due;
        require(queue.advance(now, due) == 0 && due.empty());
        require(queue.now_ns() == now && queue.size() == n - cancel_minimum);
        require(queue.next_deadline_ns() == base + cancel_minimum);
      }
      const auto visits = timer_probe::visits;
      TimerQueue::EntryList due;
      const auto fired = queue.advance(base + n, due);
      require(fired == n - cancel_minimum && queue.empty());
      std::size_t delivered = 0;
      while (auto *entry = due.pop_front()) {
        require(!entry->scheduled() && entry->deadline_ns() <= base + n);
        ++delivered;
      }
      require(delivered == fired);
      std::printf("{\"timers\":%u,\"cancel_minimum\":%s,\"polls\":128,\"minimum_visits\":%llu,\"delivered\":%zu,\"queue_bytes\":%zu,\"entry_bytes\":%zu,\"oracle\":true}\n",
          n, cancel_minimum ? "true" : "false", static_cast<unsigned long long>(visits), delivered,
          sizeof(TimerQueue), sizeof(TimerEntry));
    }
  }
}
