from pathlib import Path
import hashlib, json, shutil, subprocess, zipfile
ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
results = {}
for variant in ['baseline', 'candidate']:
    rows = [json.loads(line) for line in (OUT / (variant + '-counts.stdout.txt')).read_text().splitlines() if line.strip()]
    assert len(rows) == 6
    for row in rows:
        live = row['timers'] - row['cancel_minimum']
        expected = live * row['polls'] if variant == 'baseline' else live if row['cancel_minimum'] else 0
        assert row['oracle'] and row['minimum_visits'] == expected and row['delivered'] == live
        assert row['queue_bytes'] == 1080 and row['entry_bytes'] == 48
    results[variant] = rows
assert '[  PASSED  ] 27 tests.' in (OUT / 'tests.stdout.txt').read_text()
assert sha(OUT / 'candidate/timer_queue.source.h') == sha(ROOT / 'include/hyle/time/timer_queue.h')
shutil.copyfile(ROOT / 'tests/timer_queue/timer_queue_test.cc', OUT / 'timer_queue_test.cc')
(OUT / 'product.diff').write_bytes(subprocess.run(['git', 'diff', '--', 'include/hyle/time/timer_queue.h', 'tests/timer_queue/timer_queue_test.cc'], cwd=ROOT, capture_output=True, check=True).stdout)
summary = {
    'scope': 'TimerQueue advance with pending far-future timers; source-defined repeated minimum scans. Not an external-peer ranking or timing claim.',
    'baseline_commit': '907247284',
    'mechanism': 'advance previously reset cached next and rescanned every entry in the nearest untouched bucket even when no timer was due. Scheduler fire_due_timers calls this on busy worker dispatches with pending timers.',
    'change': 'Reuse an unchanged still-future exact cached minimum; next_dirty remembers earliest cancellation so the next advance still refreshes it as documented. Existing origin/rebucket/delivery/cancel ownership rules remain.',
    'state': 'One private bool uses existing Windows x64 tail padding: measured sizeof TimerQueue1080 and TimerEntry48 unchanged. No new allocation or public option. Other-platform layout/ABI and runtime not measured.',
    'workload': '64/1024/16384 stable nodes at2^40+i,128 advances1..128, with and without cancelling the minimum before the first poll; verify exact next after every poll, now/count/no-early-fire and final full delivery.',
    'metric': 'Source-instrumented recompute_next callback entry visits, same single increment in both scratch headers. Counter probes are not latency measurements or CPU instruction counts; no production tracing added.',
    'results': results,
    'tests': '27 TimerQueue tests passed on actual uninstrumented candidate header, including million-node randomized arm/cancel delivery, radix boundaries, cancellation/rearm, UINT64_MAX, pre-existing delivery-list contents and death/lifetime checks.',
    'review': 'backend_assembly_design independently reviewed dirty/cancel/rearm/rebucket/MAX paths; no confirmed semantic issue. Preserve original next-advance cancellation refresh contract.',
    'closure': 'MSVC14.50.35717 optimized O2/MD/W4/WX fresh probe/test TUs only; existing same-toolchain foundation/gtest reused, no configure or SDK copy/build. Header-only clients do not imply a rebuilt Scheduler runtime.',
    'initial_failure': 'First standalone test link lacked SUBSYSTEM:CONSOLE, LNK1561. Kept failure logs; added console subsystem only and linked existing test object, then ran tests once. run.py now has the successful link flag; finish_tests.py records the actual recovery.',
    'products': {str(p.relative_to(ROOT)).replace(chr(92), '/'): sha(p) for p in [ROOT / 'include/hyle/time/timer_queue.h', ROOT / 'tests/timer_queue/timer_queue_test.cc']},
    'limits': 'No Scheduler/IO latency, external Seastar comparison, other OS/ISA, whole-suite or full SDK rebuild. Cancellation of a current minimum may still require one nearest-bucket scan on the next advance.'
}
(OUT / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
cleanup = []
for p in OUT.rglob('*'):
    if p.is_file() and p.suffix.lower() in {'.exe', '.obj'}:
        cleanup.append(dict(path=str(p), bytes=p.stat().st_size, sha256=sha(p)))
(OUT / 'cleanup-candidates.json').write_text(json.dumps({'files': cleanup, 'bytes': sum(x['bytes'] for x in cleanup)}, indent=2) + '\n')
files = sorted([p for p in OUT.rglob('*') if p.is_file() and p.suffix.lower() in {'.h', '.cc', '.py', '.json', '.txt', '.diff'}], key=lambda p: p.relative_to(OUT).as_posix())
with zipfile.ZipFile(OUT / 'source-results.zip', 'w', zipfile.ZIP_DEFLATED) as archive:
    for p in files: archive.write(p, p.relative_to(OUT))
record = {'path': str((OUT / 'source-results.zip').relative_to(ROOT)), 'bytes': (OUT / 'source-results.zip').stat().st_size, 'sha256': sha(OUT / 'source-results.zip'), 'members': len(files), 'no_binaries': True}
(OUT / 'archive-record.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record))
