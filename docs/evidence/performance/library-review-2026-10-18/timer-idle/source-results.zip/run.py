from pathlib import Path
import hashlib, json, os, shutil, subprocess, sys, time
sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'scripts'))
from hyle_environment import windows_compiler_environment
CL = Path('C:/Program Files/Microsoft Visual Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/bin/Hostx64/x64/cl.exe')
LINK = CL.with_name('link.exe')
BASE = ROOT / '.scratch/build-compute-v2-dev'
ENV = windows_compiler_environment({'CMAKE_CXX_COMPILER': str(CL), 'CMAKE_C_COMPILER': str(CL)})
ENV['VSLANG'] = '1033'
ENV['PATH'] = str(BASE / 'bin') + os.pathsep + ENV['PATH']
GTEST = Path(os.environ['LOCALAPPDATA']) / 'hyle/dependencies/v1/sources/googletest-063de7e9578f-162765170ae6/googletest/include'
records = []
def run(label, args):
    args = list(map(str, args))
    p = subprocess.run(args, cwd=OUT, env=ENV, capture_output=True, timeout=60)
    (OUT / (label + '.stdout.txt')).write_bytes(p.stdout)
    (OUT / (label + '.stderr.txt')).write_bytes(p.stderr)
    records.append(dict(label=label, argv=args, cwd=str(OUT), exit=p.returncode))
    (OUT / 'commands.json').write_text(json.dumps(records, indent=2) + '\n')
    print(label, p.returncode, (p.stdout + p.stderr).decode(errors='replace')[-1800:], flush=True)
    if p.returncode: raise SystemExit(p.returncode)
    return p.stdout
flags = ['/nologo', '/std:c++latest', '/EHsc', '/Zc:preprocessor', '/Zc:__cplusplus', '/utf-8', '/O2', '/MD', '/DNDEBUG', '/DHYLE_STATIC', '/DNOMINMAX', '/W4', '/WX', '/wd4324', '/wd4702', '/permissive-']
libs = [BASE / 'bin' / (x + '.lib') for x in ['hyle_time', 'hyle_error', 'hyle_platform', 'hyle_platform_thread']]
system = ['bcrypt.lib', 'PowrProf.lib', 'Synchronization.lib', 'advapi32.lib', 'user32.lib', 'shell32.lib', 'ole32.lib', 'ws2_32.lib']
old = subprocess.run(['git', 'show', 'HEAD:include/hyle/time/timer_queue.h'], cwd=ROOT, capture_output=True, check=True).stdout
new = (ROOT / 'include/hyle/time/timer_queue.h').read_bytes()
identities = []
anchor = 'buckets_[nearest].for_each([&](const TimerEntry* entry) noexcept {\n'
for name, data in [('baseline', old), ('candidate', new)]:
    folder = OUT / name
    folder.mkdir(exist_ok=True)
    (folder / 'timer_queue.source.h').write_bytes(data)
    text = data.decode().replace('\r\n', '\n')
    assert text.count(anchor) == 1
    count_header = folder / 'include/hyle/time/timer_queue.h'
    count_header.parent.mkdir(parents=True, exist_ok=True)
    count_header.write_text(text.replace(anchor, anchor + '      ++::timer_probe::visits;\n'), encoding='utf-8')
    run(name + '-compile', [CL, *flags, '/I' + str(folder / 'include'), '/I' + str(ROOT / 'include'), '/c', OUT / 'probe.cc', '/Fo' + str(folder / 'probe.obj')])
    run(name + '-link', [LINK, '/nologo', '/OUT:' + str(folder / 'probe.exe'), '/INCREMENTAL:NO', '/NODEFAULTLIB:LIBCMT', folder / 'probe.obj', *libs, *system])
    run(name + '-counts', [folder / 'probe.exe'])
    identities.append(dict(variant=name, source_header_sha256=hashlib.sha256(data).hexdigest(), instrumented_header_sha256=hashlib.sha256(count_header.read_bytes()).hexdigest()))
run('tests-compile', [CL, *flags, '/I' + str(ROOT / 'include'), '/external:I' + str(GTEST), '/external:W0', '/c', ROOT / 'tests/timer_queue/timer_queue_test.cc', '/Fo' + str(OUT / 'tests.obj')])
run('tests-link', [LINK, '/nologo', '/SUBSYSTEM:CONSOLE', '/OUT:' + str(OUT / 'tests.exe'), '/INCREMENTAL:NO', '/NODEFAULTLIB:LIBCMT', OUT / 'tests.obj', BASE / 'lib/gtest.lib', BASE / 'lib/gtest_main.lib', *libs, *system])
run('tests', [OUT / 'tests.exe', '--gtest_filter=TimerQueue.*'])
(OUT / 'source-identities.json').write_text(json.dumps(identities, indent=2) + '\n')
