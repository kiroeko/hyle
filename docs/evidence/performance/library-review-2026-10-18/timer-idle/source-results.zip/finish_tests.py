from pathlib import Path
import hashlib, json, os, subprocess, sys
sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'scripts'))
from hyle_environment import windows_compiler_environment
CL = Path('C:/Program Files/Microsoft Visual Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/bin/Hostx64/x64/cl.exe')
BASE = ROOT / '.scratch/build-compute-v2-dev'
env = windows_compiler_environment({'CMAKE_CXX_COMPILER': str(CL), 'CMAKE_C_COMPILER': str(CL)})
env['PATH'] = str(BASE / 'bin') + os.pathsep + env['PATH']
records = json.loads((OUT / 'commands.json').read_text())
def run(label, args):
    args = list(map(str, args))
    result = subprocess.run(args, cwd=OUT, env=env, capture_output=True, timeout=60)
    (OUT / (label + '.stdout.txt')).write_bytes(result.stdout)
    (OUT / (label + '.stderr.txt')).write_bytes(result.stderr)
    records.append(dict(label=label, argv=args, cwd=str(OUT), exit=result.returncode))
    (OUT / 'commands.json').write_text(json.dumps(records, indent=2) + '\n')
    print(label, result.returncode, (result.stdout + result.stderr).decode(errors='replace')[-2600:], flush=True)
    if result.returncode: raise SystemExit(result.returncode)
libs = [BASE / 'bin' / (x + '.lib') for x in ['hyle_time', 'hyle_error', 'hyle_platform', 'hyle_platform_thread']]
system = ['bcrypt.lib', 'PowrProf.lib', 'Synchronization.lib', 'advapi32.lib', 'user32.lib', 'shell32.lib', 'ole32.lib', 'ws2_32.lib']
run('tests-link-console', [CL.with_name('link.exe'), '/nologo', '/SUBSYSTEM:CONSOLE', '/OUT:' + str(OUT / 'tests.exe'), '/INCREMENTAL:NO', '/NODEFAULTLIB:LIBCMT', OUT / 'tests.obj', BASE / 'lib/gtest.lib', BASE / 'lib/gtest_main.lib', *libs, *system])
run('tests', [OUT / 'tests.exe', '--gtest_filter=TimerQueue.*'])
identities = []
for variant in ['baseline', 'candidate']:
    folder = OUT / variant
    identities.append(dict(variant=variant, source_header_sha256=hashlib.sha256((folder / 'timer_queue.source.h').read_bytes()).hexdigest(), instrumented_header_sha256=hashlib.sha256((folder / 'include/hyle/time/timer_queue.h').read_bytes()).hexdigest()))
identities.append(dict(test_source_sha256=hashlib.sha256((ROOT / 'tests/timer_queue/timer_queue_test.cc').read_bytes()).hexdigest()))
(OUT / 'source-identities.json').write_text(json.dumps(identities, indent=2) + '\n')
