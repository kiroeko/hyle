"""Package recorded probe and applied source; never compile/run a consumer."""
from pathlib import Path
import difflib,hashlib,json,re,subprocess,zipfile
OUT=Path(__file__).resolve().parent
ROOT=OUT.parents[2]
hashof=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
write=lambda n,x:(OUT/n).write_text(json.dumps(x,indent=2)+'\n',encoding='utf-8')
read=lambda p:p.read_text(encoding='utf-8')
def code(s):
    lines=[x for x in s.splitlines() if not x.strip().startswith('//') and
           x.strip()!='#include <cstdio>' and 'std::fprintf(stderr, "# HYLE_F32_STEEL' not in x]
    return re.sub(r'\s+','','\n'.join(lines))
assert code(read(OUT/'native.candidate.cpp'))==code(read(OUT/'native.applied.cpp'))
assert code(read(OUT/'apple_tensor.candidate.cc'))==code(read(ROOT/'src/compute_route_apple/apple_tensor.cc'))
assert code(read(OUT/'attention_test.cc'))==code(read(ROOT/'tests/compute_route_apple/attention_test.cc'))
paths=['src/compute_route_apple/apple_tensor.cc','tests/compute_route_apple/attention_test.cc',
       'third_party/mlx_cast/patches.json','third_party/mlx_cast/NOTICE.md','cmake/HyleDependencyLock.json']
frozen=[]
for rel in paths:
    p=ROOT/rel;copy=OUT/'applied'/rel;copy.parent.mkdir(parents=True,exist_ok=True);copy.write_bytes(p.read_bytes())
    frozen.append(dict(path=rel,bytes=p.stat().st_size,sha256=hashof(p)))
write('frozen-source-identities.json',frozen)
(OUT/'product.patch').write_bytes(subprocess.check_output(['git','diff','--',*paths],cwd=ROOT))
for name,a,b in [('native-probe-to-applied.diff',OUT/'native.candidate.cpp',OUT/'native.applied.cpp'),
                 ('apple-probe-to-applied.diff',OUT/'apple_tensor.candidate.cc',ROOT/paths[0]),
                 ('test-probe-to-applied.diff',OUT/'attention_test.cc',ROOT/paths[1])]:
    (OUT/name).write_text(''.join(difflib.unified_diff(read(a).splitlines(True),read(b).splitlines(True),fromfile=a.name,tofile=b.name)),encoding='utf-8')
base=json.loads(read(OUT/'baseline-space.stdout.txt'))
candidate=json.loads(read(OUT/'measured/candidate-space.stdout.txt'))
uniform=json.loads(read(OUT/'measured/candidate-uniform.stdout.txt'))
identities=json.loads(read(OUT/'measured/runtime-identities.json'))
remote='/Users/kiro/hyle-scratch/compute-unified/library-review-20261018-steel-f32/'
cleanup=[dict(path=p,**d) for p,d in identities.items() if p.startswith(remote)]
write('cleanup-candidates.json',dict(files=cleanup,count=len(cleanup),total_bytes=sum(x['bytes'] for x in cleanup),
    action='Candidates only; not deleted. Root writes exact operations to test.ps1.',
    keep='Original SDK/metallib/native cache, all sources, commands, logs, maps, identities and result archive.'))
maps={}
for kind in ['tests','space','uniform']:
    s=read(OUT/'measured'/f'{kind}.map')
    maps[kind]=dict(fresh_apple=(remote+'candidate.o') in s,fresh_native=(remote+'native.o') in s,
        archive_apple_tensor=any('libhyle_compute_route_apple.a' in x and 'apple_tensor' in x for x in s.splitlines()),
        archive_native_selector=any('libmlx.a' in x and 'scaled_dot_product_attention.cpp.o' in x for x in s.splitlines()))
assert all(m['fresh_apple'] and m['fresh_native'] and not m['archive_apple_tensor'] and not m['archive_native_selector'] for m in maps.values())
old=json.loads(read(OUT.parent/'apple-nax-capability/summary.json'))
write('old-uniform-record.json',dict(path='apple-nax-capability/summary.json',sha256=hashof(OUT.parent/'apple-nax-capability/summary.json'),space=old['space_point']))
summary=dict(
    status='scoped_native_f32_steel_feasible_and_applied; no throughput claim',
    machine=dict(host='kiro@172.22.10.198',model='Mac16,12',chip='Apple M4',architecture='applegpu_g16g',compiler='Apple clang21.0.0',free_space_before='41GiB'),
    scope=dict(
        hyle_force='GPU ordinary matching-depth F32 D256, no mask, causal8<Q<=KV, nonempty batch/KV, only known Apple architecture generations13-16. Unknown/new architectures preserve native selection.',
        native_tile='Only ordinary !page/!mask/!sinks F32 Dq=Dv256,8<Q<=KV,causal; original NAX early-return remains first. BQ16/BK8/WM2/WN1; QueryT=float and hyle_q8=false.',
        admission='Actual selected PSO staticThreadgroupMemoryLength checked against actual MTLDevice max before dispatch. Exceeding rejects; no trial of another tile.',
        precision='Existing native float scale, QK, probabilities, online softmax and PV; no half conversion/new shader formula/TF32 enablement.',
        native_resource='Only host scaled_dot_product_attention.cpp in existing exact manifest; existing JIT/template/shader source unchanged.',
        unchanged='Public C++ API/ABI, half/page branches, current array masks and causal Q>KV fallback. No native SDK/metallib rebuild, download or copy; no env or tracing eval/sync.'),
    actual_pipeline=dict(static_threadgroup_bytes=28928,device_limit_bytes=32768,
        key='steel_attention_float32_bq16_bk8_bd256_wm2_wn1_maskfloat32_bv256_...',
        evidence='candidate-{tests,space,uniform}.stderr.txt logs actual selected key/resources. NAX not taken on this M4; no implicit TF32 change.'),
    compilation=dict(fresh_host_TUs=5,links=3,scope='native selector, Hyle lowerer, focused tests, frozen short-Q space consumer and old uniform consumer. Original SDK/foundation/gtest reused.',
        first_two_failures='Vendor include headers/unchanged VJP unused parameters rejected by inherited project WX. Private vendor include changed to isystem; native-only Wno-unused-parameter. Failed exact commands/stderr retained. No runtime occurred before these corrections.',
        loader_identity='runtime-identities.json+link maps; original libmlx.a SHA0ec0cd1a0e00c3f75c1ecf9db549b023e6fdc64f3d2f1a63a9a8be809eea9af9.',maps=maps),
    correctness=dict(gtests_passed=3,
        coverage='Nonzero QK F32 D256/GQA, BHSD and BSHD, Q17/KV31 positive scale and Q33/KV65 negative scale with unaligned tails; F32 weak-probability/V60000 case at Q17/KV257; existing small fallback controls.',
        oracle='Existing independent FP64 sums with unchanged F32 rel6e-6+abs2e-6. No new tolerance or input chosen after observing failures.',
        execution='One focused-test process, one short-Q candidate space process, one old-uniform candidate process. No timing/AB/AA or further tile experiment.'),
    short_q_space=dict(
        shape='F32 B1/H4/Hkv2/D256 Q129/KV32768,causal,None',
        frozen_input='Exactly the prior negative-candidate episode: Q/K0,V alternates+1.25/-1.25 per KV row. Same FP64 prefix mean and rel6e-6+abs2e-6 for every132096 outputs.',
        baseline='Reused original raw result/command from apple-short-q/measured/baseline-space. Its Hyle lowerer equals current baseline; original native source SHA6bfa592cbef5131845b5d2b5e6afa62ae31daed64ea8da9220dc2c1020f44318 and same libmlx.a verified. No baseline rerun.',
        baseline_raw=base,candidate_raw=candidate,
        extra_peak_reduction_bytes=base['peak_minus_active_before']-candidate['peak_minus_active_before'],
        extra_peak_reduction_fraction=1-candidate['peak_minus_active_before']/base['peak_minus_active_before'],
        metric='MLX allocator peak minus active-before-submit includes output and native buffers, after public prepare/create_invocation/bind then clear_cache/reset_peak, submit/wait/synchronize. Not whole-device VRAM/RSS or strict private memory. Cold JIT/prepare excluded.',
        result='68846084B ->540672B extra peak, output528384B still fully present; both numerical checks pass. Candidate maxerror1.7882893923277729e-12. One space point only.'),
    old_uniform_candidate=dict(
        shape='Exactly old F32 B1/H4/Hkv2/D256 Q=KV2048,causal,None,QK0/V1.25 and its9.5e-6 budget.',
        raw=uniform,exit=0,
        interpretation='Candidate all2097152 outputs pass with maxerror0; extra8MiB equals logical output. The prior two math-route FAIL records remain unaltered evidence of old routes; only this scoped new path/shape is now passing, not all F32 precision.'),
    resource_validation=dict(
        materializer='Existing prepare_source.py projected single exact host entry + pristine pinned archive file: before/after verification passed, afterSHA3325bb041f6319ba2e82e0459683b8edeb1595dd1732f082563d747f770b205e.',
        cmake='cmake -P check-lock.cmake audits only mlx_cast_patches tree and licenses/NOTICE; PASS. Independent root-resource-check.cmake/result also PASS and included in the archive.',
        initial_snapshot_check='After materializer hashes passed, extra LF-vs-WindowsCRLF snapshot assert initially failed. Corrected only the comparison to existing normalization; retained error note. No consumer/SDK rerun.',
        lock=json.loads(read(OUT/'lock-update.json'))),
    tested_vs_applied='Applied host source removes diagnostic cstdio/fprintf and adds explanatory comments; Hyle only updates comments; tests only format whitespace. Executable code equivalence checked after those explicit exclusions. All measured sources retained separately. No claim full SDK was rebuilt from final manifest.',
    limits=[
        'No throughput measurement. The old F16 BK16 tile slowdown does not measure this F32 BK8 shape.',
        'No full Apple/Graph suite, shared SDK rebuild, other Apple GPU/OS, broad mask/dtype/head domain or unknown/new-NAX force validation.',
        'F32 D192, explicit masks, causalQ>KV, other depths and unrecognized architectures retain existing routes and may retain full scores.',
        'Short-Q Q16 math expansion was a negative result and reverted. Its raw archive remains separate; do not rewrite it as success.',
        'The local patch materializer validation is a one-file projection, not full native SDK compilation.'
    ],
    frozen_files='frozen-source-identities.json',cleanup='cleanup-candidates.json;8 new Air obj/exe only, no deletion performed.')
write('summary.json',summary)
archive=OUT/'source-results.zip'
files=sorted(p for p in OUT.rglob('*') if p.is_file() and p.name not in
    ['source-results.zip','archive-record.json','measured-raw.tar.gz'])
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
    for p in files:z.write(p,str(p.relative_to(OUT)))
write('archive-record.json',dict(path=str(archive.relative_to(ROOT)),bytes=archive.stat().st_size,sha256=hashof(archive),files=len(files),scope='Sources/commands/stdout/stderr/maps/identities only; no executables/objects/SDK/native libraries.'))
print((OUT/'archive-record.json').read_text())
print('cleanup',len(cleanup),sum(x['bytes'] for x in cleanup))
print(json.dumps(frozen,indent=2))
