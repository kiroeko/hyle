cmake_minimum_required(VERSION 3.25)
include("C:/public/project-hyle/hyle/cmake/HyleDependencyVersions.cmake")
hyle_audit_in_tree_dependencies(mlx_cast_patches)
message(STATUS "Apple F32 Steel: selected native resource and NOTICE match")
