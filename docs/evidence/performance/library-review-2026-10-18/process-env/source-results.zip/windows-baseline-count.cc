
#include <algorithm>
#include <climits>
#include <cstdio>
#include <cstring>
#include <cwchar>
#include <fstream>
#include <string>
#include <string_view>
#include <vector>
#include "hyle/process/process.h"
#include "hyle/io/io_context.h"
#include "hyle/container/small_vector.h"
#include "hyle/error/system_error.h"
#ifdef _WIN32
#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#include <windows.h>
#endif
namespace hyle::process::detail {
std::size_t comparisons=0, extractions=0;
bool counted_less(std::string_view a,std::string_view b) noexcept {++comparisons; return a<b;}
bool counted_equal(std::string_view a,std::string_view b) noexcept {++comparisons; return a==b;}
const char* counted_separator(const char* text) noexcept {++extractions;return std::strchr(text,'=');}
template<class T,std::size_t Inline>
using Scratch=container::SmallVector<T,Inline,mem::AllocatorRef>;
char** probe_environ=nullptr;
#ifdef _WIN32
wchar_t* probe_wide_environment=nullptr;
wchar_t* probe_get_environment() noexcept{return probe_wide_environment;}
BOOL probe_free_environment(wchar_t*) noexcept{return TRUE;}
#endif
bool contains_nul(std::string_view text) noexcept {
  return text.find('\0') != std::string_view::npos;
}

bool valid_stdio_kind(ProcessStdioKind kind) noexcept {
  switch (kind) {
    case ProcessStdioKind::kInherit:
    case ProcessStdioKind::kNull:
    case ProcessStdioKind::kFile:
    case ProcessStdioKind::kPipe:
    case ProcessStdioKind::kMergeStdout:
      return true;
  }
  return false;
}

Status validate_stdio(ProcessStdio value, bool stderr_slot) noexcept {
  if (!valid_stdio_kind(value.kind()))
    return Status::InvalidArgument("process stdio kind is invalid");
  if (value.kind() == ProcessStdioKind::kMergeStdout && !stderr_slot)
    return Status::InvalidArgument(
        "merge_stdout is valid only for child stderr");
  if (value.kind() == ProcessStdioKind::kFile &&
      value.file_handle() == platform::FileHandle::kInvalid) {
    return Status::InvalidArgument("process stdio file handle is not open");
  }
  return Status{};
}

Status validate_start_options(const ProcessStartOptions& options) noexcept {
  if (options.executable.empty() || contains_nul(options.executable))
    return Status::InvalidArgument(
        "process executable must be non-empty and contain no NUL");
  if (options.executable_search != ExecutableSearch::kExact &&
      options.executable_search != ExecutableSearch::kPath) {
    return Status::InvalidArgument("process executable search mode is invalid");
  }
  if (options.environment_mode != EnvironmentMode::kInherit &&
      options.environment_mode != EnvironmentMode::kReplace) {
    return Status::InvalidArgument("process environment mode is invalid");
  }
  if (options.working_directory.has_value() &&
      (options.working_directory->empty() ||
       contains_nul(*options.working_directory))) {
    return Status::InvalidArgument(
        "process working directory must be non-empty and contain no NUL");
  }
  for (std::string_view argument : options.arguments) {
    if (contains_nul(argument))
      return Status::InvalidArgument("process argument contains NUL");
  }
  for (std::size_t i = 0; i < options.environment_changes.size(); ++i) {
    const EnvironmentChange& change = options.environment_changes[i];
    if (change.name.empty() || contains_nul(change.name) ||
        change.name.find('=') != std::string_view::npos) {
      return Status::InvalidArgument(
          "environment variable name must be non-empty and contain no '=' or NUL");
    }
    if (change.value.has_value() && contains_nul(*change.value))
      return Status::InvalidArgument("environment variable value contains NUL");
    if (options.environment_mode == EnvironmentMode::kReplace &&
        !change.value.has_value()) {
      return Status::InvalidArgument(
          "replacement environment cannot contain unset entries");
    }
    for (std::size_t j = 0; j < i; ++j) {
      if (counted_equal(options.environment_changes[j].name, change.name))
        return Status::InvalidArgument(
            "process environment contains duplicate variable names");
    }
  }
  Status status = validate_stdio(options.stdin_stream, false);
  if (!status.ok()) return status;
  status = validate_stdio(options.stdout_stream, false);
  if (!status.ok()) return status;
  status = validate_stdio(options.stderr_stream, true);
  if (!status.ok()) return status;

  const bool has_pipe =
      options.stdin_stream.kind() == ProcessStdioKind::kPipe ||
      options.stdout_stream.kind() == ProcessStdioKind::kPipe ||
      options.stderr_stream.kind() == ProcessStdioKind::kPipe;
  if (has_pipe) {
    if (options.pipe_io == nullptr || !options.pipe_io->valid())
      return Status::FailedPrecondition(
          "process pipe stdio requires a valid IoContext");
    if (options.pipe_owner >= options.pipe_io->num_workers())
      return Status::OutOfRange(
          "process pipe owner is outside IoContext");
  }
  return Status{};
}

Status win32_status(DWORD error, const char* operation) noexcept {
  return status_from_win32(error, operation);
}

template <std::size_t Inline>
bool append_wide(Scratch<wchar_t, Inline>& output, const wchar_t* source,
                 std::size_t size, bool nul = false) noexcept {
  const std::size_t extra = size + (nul ? 1u : 0u);
  if (extra > SIZE_MAX - output.size() ||
      !output.try_reserve(output.size() + extra)) {
    return false;
  }
  for (std::size_t i = 0; i < size; ++i) output.push_back(source[i]);
  if (nul) output.push_back(L'\0');
  return true;
}

Status append_utf8(Scratch<wchar_t, 512>& output, std::string_view text,
                   bool nul = false) noexcept {
  if (text.size() > static_cast<std::size_t>(INT_MAX))
    return Status::OutOfRange("process UTF-8 value exceeds Win32 limit");
  int required = 0;
  if (!text.empty()) {
    required = ::MultiByteToWideChar(
        CP_UTF8, MB_ERR_INVALID_CHARS, text.data(),
        static_cast<int>(text.size()), nullptr, 0);
    if (required <= 0)
      return win32_status(::GetLastError(), "decode process UTF-8 value");
  }
  const std::size_t extra = static_cast<std::size_t>(required) +
                            (nul ? 1u : 0u);
  if (extra > SIZE_MAX - output.size() ||
      !output.try_resize(output.size() + extra)) {
    return Status::ResourceExhausted(
        "process UTF-16 scratch allocation failed");
  }
  const std::size_t offset = output.size() - extra;
  if (required != 0 &&
      ::MultiByteToWideChar(CP_UTF8, MB_ERR_INVALID_CHARS, text.data(),
                            static_cast<int>(text.size()),
                            output.data() + offset, required) != required) {
    return win32_status(::GetLastError(), "decode process UTF-8 value");
  }
  if (nul) output.back() = L'\0';
  return Status{};
}

bool equal_name(const wchar_t* left, std::size_t left_size,
                const wchar_t* right, std::size_t right_size) noexcept {
  ++comparisons;
  if (left_size != right_size) return false;
  return ::CompareStringOrdinal(left, static_cast<int>(left_size), right,
                                static_cast<int>(right_size), TRUE) ==
         CSTR_EQUAL;
}

std::size_t environment_name_size(const wchar_t* text,
                                  std::size_t size) noexcept {
  std::size_t cursor = text[0] == L'=' ? 1u : 0u;
  while (cursor < size && text[cursor] != L'=') ++cursor;
  return cursor;
}

struct WideChange {
  std::size_t offset = 0;
  std::size_t name_size = 0;
  std::size_t text_size = 0;
  bool unset = false;
};

struct EnvironmentItem {
  const wchar_t* inherited = nullptr;
  std::size_t change_offset = 0;
  std::size_t size = 0;
  bool changed = false;
};

class EnvironmentBlock {
 public:
  explicit EnvironmentBlock(mem::AllocatorRef allocator) noexcept
      : changes_(allocator), change_text_(allocator), items_(allocator),
        output_(allocator) {}
  ~EnvironmentBlock() {
    if (inherited_ != nullptr) probe_free_environment(inherited_);
  }
  EnvironmentBlock(const EnvironmentBlock&) = delete;
  EnvironmentBlock& operator=(const EnvironmentBlock&) = delete;

  Status build(const ProcessStartOptions& options) noexcept {
    for (const EnvironmentChange& change : options.environment_changes) {
      const std::size_t offset = change_text_.size();
      Status status = append_utf8(change_text_, change.name);
      if (!status.ok()) return status;
      const std::size_t name_size = change_text_.size() - offset;
      for (const WideChange& existing : changes_) {
        if (equal_name(change_text_.data() + existing.offset,
                       existing.name_size, change_text_.data() + offset,
                       name_size)) {
          return Status::InvalidArgument(
              "Windows process environment contains duplicate names");
        }
      }
      if (change.value.has_value()) {
        if (!change_text_.try_push_back(L'='))
          return Status::ResourceExhausted(
              "process environment allocation failed");
        status = append_utf8(change_text_, *change.value, true);
        if (!status.ok()) return status;
      }
      if (!changes_.try_push_back(WideChange{
              offset, name_size, change_text_.size() - offset,
              !change.value.has_value()})) {
        return Status::ResourceExhausted(
            "process environment index allocation failed");
      }
    }

    if (options.environment_mode == EnvironmentMode::kInherit) {
      inherited_ = probe_get_environment();
      if (inherited_ == nullptr)
        return win32_status(::GetLastError(), "read process environment");
      const wchar_t* current = inherited_;
      while (*current != L'\0') {
        const std::size_t size = std::wcslen(current);
        const std::size_t name_size = environment_name_size(current, size);
        bool replaced = false;
        for (const WideChange& change : changes_) {
          if (equal_name(current, name_size,
                         change_text_.data() + change.offset,
                         change.name_size)) {
            replaced = true;
            break;
          }
        }
        if (!replaced && !items_.try_push_back(
                             EnvironmentItem{current, 0, size, false})) {
          return Status::ResourceExhausted(
              "process environment index allocation failed");
        }
        current += size + 1;
      }
    }

    for (const WideChange& change : changes_) {
      if (!change.unset &&
          !items_.try_push_back(EnvironmentItem{
              nullptr, change.offset, change.text_size - 1, true})) {
        return Status::ResourceExhausted(
            "process environment index allocation failed");
      }
    }
    std::sort(items_.begin(), items_.end(), [&](const EnvironmentItem& left,
                                                const EnvironmentItem& right) {
      const wchar_t* a = left.changed
                             ? change_text_.data() + left.change_offset
                             : left.inherited;
      const wchar_t* b = right.changed
                             ? change_text_.data() + right.change_offset
                             : right.inherited;
      return ::CompareStringOrdinal(a, static_cast<int>(left.size), b,
                                    static_cast<int>(right.size), TRUE) ==
             CSTR_LESS_THAN;
    });
    for (const EnvironmentItem& item : items_) {
      const wchar_t* text = item.changed
                                ? change_text_.data() + item.change_offset
                                : item.inherited;
      if (!append_wide(output_, text, item.size, true))
        return Status::ResourceExhausted(
            "process environment block allocation failed");
    }
    if (output_.empty() && !output_.try_push_back(L'\0'))
      return Status::ResourceExhausted(
          "process environment block allocation failed");
    if (!output_.try_push_back(L'\0'))
      return Status::ResourceExhausted(
          "process environment block allocation failed");
    return Status{};
  }

  wchar_t* data() noexcept { return output_.data(); }

 private:
  Scratch<WideChange, 16> changes_;
  Scratch<wchar_t, 512> change_text_;
  Scratch<EnvironmentItem, 64> items_;
  Scratch<wchar_t, 1024> output_;
  LPWCH inherited_ = nullptr;
};


} // namespace hyle::process::detail
struct AllocationCount {
  std::size_t allocations=0;
  static void* allocate(void* raw,std::size_t size,std::size_t align) noexcept {
    ++static_cast<AllocationCount*>(raw)->allocations;
    return hyle::mem::system_allocator().allocate(size,align);
  }
  static void free(void*,void* p,std::size_t size,std::size_t align) noexcept {
    hyle::mem::system_allocator().deallocate(p,size,align);
  }
  static void* resize(void* raw,void* p,std::size_t before,std::size_t after,std::size_t align) noexcept {
    ++static_cast<AllocationCount*>(raw)->allocations;
    return hyle::mem::system_allocator().reallocate(p,before,after,align);
  }
  hyle::mem::AllocatorRef get() noexcept {return {allocate,free,resize,this};}
};
int main(int argc,char** argv) {
  if(argc!=2)return 2;
  using namespace hyle::process;
  using namespace hyle::process::detail;
  for(const std::size_t n:{16u,1024u}) {
    std::vector<std::string> names,entries;
    std::vector<EnvironmentChange> changes;
    names.reserve(n);entries.reserve(n+4);changes.reserve(n);
    for(std::size_t i=n;i>0;--i) {
      const std::size_t k=i-1;
      char key[64];
      std::snprintf(key,sizeof(key),"HYLE_ENV_%04zu",k<n/2?2*k:n+k);
      names.emplace_back(key);
      changes.push_back({names.back(),k%3==0?std::nullopt:std::optional<std::string_view>{"new"}});
    }
    for(std::size_t i=0;i<n;++i) {
      char entry[80];std::snprintf(entry,sizeof(entry),"HYLE_ENV_%04zu=old",i);
      entries.emplace_back(entry);
    }
    entries.emplace_back("A=old");entries.emplace_back("AA=old");
    std::vector<char*> envp;
    for(auto& entry:entries)envp.push_back(entry.data());
    envp.push_back(nullptr);probe_environ=envp.data();
#ifdef _WIN32
    std::vector<wchar_t> wide;
    for(const auto& entry:entries) {for(char c:entry)wide.push_back(static_cast<wchar_t>(c));wide.push_back(0);}
    const wchar_t special[]=L"=C:=C:\\kept";
    wide.insert(wide.end(),special,special+sizeof(special)/sizeof(*special));
    wide.push_back(0);probe_wide_environment=wide.data();
#endif
    ProcessStartOptions options;options.executable="probe";options.environment_changes=changes;
    AllocationCount allocator;
    comparisons=0;extractions=0;
    auto status=validate_start_options(options);
    if(!status.ok())return 3;
    const auto validation_comparisons=comparisons;
    const auto validation_allocations=allocator.allocations;
    comparisons=0;extractions=0;
    std::vector<char> serialized;
#ifdef _WIN32
    EnvironmentBlock block(hyle::mem::system_allocator());
    status=block.build(options);if(!status.ok())return 4;
    const wchar_t* data=block.data();std::size_t size=0;
    while(data[size]!=0||data[size+1]!=0)++size;
    size+=2;
    serialized.assign(reinterpret_cast<const char*>(data),reinterpret_cast<const char*>(data+size));
#else
    auto result=build_environment(hyle::mem::system_allocator(),options);if(!result.has_value())return 4;
    serialized.assign(result->bytes.begin(),result->bytes.end());
#endif
    const auto merge_comparisons=comparisons;
    const auto separators=extractions;
    const std::string path=std::string(argv[1])+"-"+std::to_string(n)+".env";
    std::ofstream file(path,std::ios::binary);file.write(serialized.data(),static_cast<std::streamsize>(serialized.size()));file.close();
    std::printf("{\"changes\":%zu,\"inherited_regular\":%zu,\"validation_name_comparisons\":%zu,\"validation_allocator_calls\":%zu,\"native_name_comparisons\":%zu,\"native_separator_scans\":%zu,\"serialized_bytes\":%zu}\n",n,entries.size(),validation_comparisons,validation_allocations,merge_comparisons,separators,serialized.size());
  }
}
