"""Extract actual old/new name-validation and environment-builder source only.

No spawn, timer, native runtime, scheduler or threads. Instrument comparisons at
the actual source sites; substitute only inherited-environment acquisition.
"""
from pathlib import Path
import hashlib, json

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]

PREFIX = r'''
#include <algorithm>
#include <climits>
#include <cstdio>
#include <cstring>
#include <cwchar>
#include <fstream>
#include <string>
#include <string_view>
#include <vector>
#include "hyle/process/process.h"
#include "hyle/io/io_context.h"
#include "hyle/container/small_vector.h"
#include "hyle/error/system_error.h"
#ifdef _WIN32
#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#include <windows.h>
#endif
namespace hyle::process::detail {
std::size_t comparisons=0, extractions=0;
bool counted_less(std::string_view a,std::string_view b) noexcept {++comparisons; return a<b;}
bool counted_equal(std::string_view a,std::string_view b) noexcept {++comparisons; return a==b;}
const char* counted_separator(const char* text) noexcept {++extractions;return std::strchr(text,'=');}
template<class T,std::size_t Inline>
using Scratch=container::SmallVector<T,Inline,mem::AllocatorRef>;
char** probe_environ=nullptr;
#ifdef _WIN32
wchar_t* probe_wide_environment=nullptr;
wchar_t* probe_get_environment() noexcept{return probe_wide_environment;}
BOOL probe_free_environment(wchar_t*) noexcept{return TRUE;}
#endif
'''

MAIN = r'''
} // namespace hyle::process::detail
struct AllocationCount {
  std::size_t allocations=0;
  static void* allocate(void* raw,std::size_t size,std::size_t align) noexcept {
    ++static_cast<AllocationCount*>(raw)->allocations;
    return hyle::mem::system_allocator().allocate(size,align);
  }
  static void free(void*,void* p,std::size_t size,std::size_t align) noexcept {
    hyle::mem::system_allocator().deallocate(p,size,align);
  }
  static void* resize(void* raw,void* p,std::size_t before,std::size_t after,std::size_t align) noexcept {
    ++static_cast<AllocationCount*>(raw)->allocations;
    return hyle::mem::system_allocator().reallocate(p,before,after,align);
  }
  hyle::mem::AllocatorRef get() noexcept {return {allocate,free,resize,this};}
};
int main(int argc,char** argv) {
  if(argc!=2)return 2;
  using namespace hyle::process;
  using namespace hyle::process::detail;
  for(const std::size_t n:{16u,1024u}) {
    std::vector<std::string> names,entries;
    std::vector<EnvironmentChange> changes;
    names.reserve(n);entries.reserve(n+4);changes.reserve(n);
    for(std::size_t i=n;i>0;--i) {
      const std::size_t k=i-1;
      char key[64];
      std::snprintf(key,sizeof(key),"HYLE_ENV_%04zu",k<n/2?2*k:n+k);
      names.emplace_back(key);
      changes.push_back({names.back(),k%3==0?std::nullopt:std::optional<std::string_view>{"new"}});
    }
    for(std::size_t i=0;i<n;++i) {
      char entry[80];std::snprintf(entry,sizeof(entry),"HYLE_ENV_%04zu=old",i);
      entries.emplace_back(entry);
    }
    entries.emplace_back("A=old");entries.emplace_back("AA=old");
    std::vector<char*> envp;
    for(auto& entry:entries)envp.push_back(entry.data());
    envp.push_back(nullptr);probe_environ=envp.data();
#ifdef _WIN32
    std::vector<wchar_t> wide;
    for(const auto& entry:entries) {for(char c:entry)wide.push_back(static_cast<wchar_t>(c));wide.push_back(0);}
    const wchar_t special[]=L"=C:=C:\\kept";
    wide.insert(wide.end(),special,special+sizeof(special)/sizeof(*special));
    wide.push_back(0);probe_wide_environment=wide.data();
#endif
    ProcessStartOptions options;options.executable="probe";options.environment_changes=changes;
    AllocationCount allocator;
    comparisons=0;extractions=0;
    auto status=VALIDATE_CALL;
    if(!status.ok())return 3;
    const auto validation_comparisons=comparisons;
    const auto validation_allocations=allocator.allocations;
    comparisons=0;extractions=0;
    std::vector<char> serialized;
#ifdef _WIN32
    EnvironmentBlock block(hyle::mem::system_allocator());
    status=block.build(options);if(!status.ok())return 4;
    const wchar_t* data=block.data();std::size_t size=0;
    while(data[size]!=0||data[size+1]!=0)++size;
    size+=2;
    serialized.assign(reinterpret_cast<const char*>(data),reinterpret_cast<const char*>(data+size));
#else
    auto result=build_environment(hyle::mem::system_allocator(),options);if(!result.has_value())return 4;
    serialized.assign(result->bytes.begin(),result->bytes.end());
#endif
    const auto merge_comparisons=comparisons;
    const auto separators=extractions;
    const std::string path=std::string(argv[1])+"-"+std::to_string(n)+".env";
    std::ofstream file(path,std::ios::binary);file.write(serialized.data(),static_cast<std::streamsize>(serialized.size()));file.close();
    std::printf("{\"changes\":%zu,\"inherited_regular\":%zu,\"validation_name_comparisons\":%zu,\"validation_allocator_calls\":%zu,\"native_name_comparisons\":%zu,\"native_separator_scans\":%zu,\"serialized_bytes\":%zu}\n",n,entries.size(),validation_comparisons,validation_allocations,merge_comparisons,separators,serialized.size());
  }
}
'''

identity={}
for platform in ('windows','posix'):
    for arm in ('baseline','candidate'):
        base=OUT/'baseline' if arm=='baseline' else ROOT
        common=(base/'src/process/process.cc').read_text()
        native=(base/('src/process/process_'+platform+'.cc')).read_text()
        identity[platform+'-'+arm]={'common_sha256':hashlib.sha256((base/'src/process/process.cc').read_bytes()).hexdigest(),'native_sha256':hashlib.sha256((base/('src/process/process_'+platform+'.cc')).read_bytes()).hexdigest()}
        common=common[common.index('bool contains_nul('):common.index('Status close_pipes_locked(')]
        if arm=='baseline':
            old='options.environment_changes[j].name == change.name'
            assert old in common
            common=common.replace(old,'counted_equal(options.environment_changes[j].name, change.name)')
        else:
            old='std::sort(names.begin(), names.end());';assert old in common
            common=common.replace(old,'std::sort(names.begin(), names.end(), counted_less);')
            old='std::adjacent_find(names.begin(), names.end())';assert old in common
            common=common.replace(old,'std::adjacent_find(names.begin(), names.end(), counted_equal)')
        if platform=='posix':
            native=native[native.index('bool append_bytes('):native.index('Result<PackedStrings> build_arguments(')]
            if arm=='baseline':
                old="std::strchr(entry, '=')";assert old in native
                native=native.replace(old,'counted_separator(entry)')
                old='const char* separator = counted_separator(entry);'
                native=native.replace(old,'++comparisons;\n  '+old)
            else:
                old="std::strchr(*current, '=')";assert old in native
                native=native.replace(old,'counted_separator(*current)')
                old='std::sort(changed_names.begin(), changed_names.end());';assert old in native
                native=native.replace(old,'std::sort(changed_names.begin(), changed_names.end(), counted_less);')
                old='static_cast<std::size_t>(separator - *current)));';assert old in native
                native=native.replace(old,'static_cast<std::size_t>(separator - *current)), counted_less);')
            native=native.replace('char** current = environ;','char** current = probe_environ;')
        else:
            first=native[native.index('Status win32_status('):native.index('Result<Scratch<wchar_t, 512>> wide_c_string(')]
            last=native[native.index('bool equal_name('):native.index('Result<HANDLE> duplicate_inheritable(')]
            last=last.replace('  if (left_size != right_size)', '  ++comparisons;\n  if (left_size != right_size)')
            last=last.replace('::GetEnvironmentStringsW()', 'probe_get_environment()').replace('::FreeEnvironmentStringsW(inherited_)','probe_free_environment(inherited_)')
            native=first+last
        call='validate_start_options(options)' if arm=='baseline' else 'validate_start_options(options,allocator.get())'
        (OUT/(platform+'-'+arm+'-count.cc')).write_text(PREFIX+common+native+MAIN.replace('VALIDATE_CALL',call))
(OUT/'count-source-identity.json').write_text(json.dumps(identity,indent=2))
