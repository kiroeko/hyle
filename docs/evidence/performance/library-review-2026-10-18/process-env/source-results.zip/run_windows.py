from pathlib import Path
import hashlib, json, subprocess, sys, time

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]
BUILD = ROOT / '.scratch/build-compute-v2-dev'
sys.path.insert(0, str(ROOT / 'scripts'))
from hyle_environment import windows_compiler_environment
from hyle_support import read_cache
cache = read_cache(BUILD)
env = windows_compiler_environment(cache)
env['VSLANG'] = '1033'
cl = cache['CMAKE_CXX_COMPILER']
link = str(Path(cl).with_name('link.exe'))
flags = ['/nologo', '/c', '/DWIN32', '/D_WINDOWS', '/EHsc', '/O2', '/Ob2', '/DNDEBUG',
         '/std:c++latest', '/MD', '/W4', '/permissive-', '/wd4324', '/WX', '/Zc:__cplusplus',
         '/utf-8', '/Zc:preprocessor', '/DHYLE_STATIC', '/I' + str(ROOT / 'include'),
         '/I' + str(ROOT / 'src/process')]
libs = [str(BUILD / 'bin' / (n + '.lib')) for n in [
    'hyle_io_core', 'hyle_sched', 'hyle_mem_vm', 'hyle_mem', 'hyle_platform_fs',
    'hyle_platform_thread', 'hyle_platform', 'hyle_error', 'hyle_time', 'hyle_container',
    'mimalloc_static']]
libs += ['Synchronization.lib', 'bcrypt.lib', 'PowrProf.lib', 'advapi32.lib', 'ws2_32.lib', 'userenv.lib', 'psapi.lib']
test_libs = [str(BUILD / 'lib/gtest_main.lib'), str(BUILD / 'lib/gtest.lib'), *libs]
gtest = Path(cache['gtest_SOURCE_DIR'])

def run(tag, command, timeout=120):
    (OUT / (tag + '-command.json')).write_text(json.dumps(command, indent=2))
    start = time.monotonic()
    p = subprocess.run(command, cwd=OUT, env=env, capture_output=True, timeout=timeout)
    (OUT / (tag + '.stdout.txt')).write_bytes(p.stdout)
    (OUT / (tag + '.stderr.txt')).write_bytes(p.stderr)
    (OUT / (tag + '-exit.json')).write_text(json.dumps({'exit': p.returncode, 'wall_seconds': time.monotonic()-start}))
    print(tag, p.returncode, flush=True)
    if p.returncode:
        print(p.stdout.decode(errors='replace')); print(p.stderr.decode(errors='replace'))
        raise SystemExit(p.returncode)
    return p.stdout.decode(errors='replace')

if '--build' in sys.argv:
    run('win-helper-compile', [cl, *flags, '/Fowin-helper.obj', str(ROOT/'tests/process/process_child_helper.cc')])
    run('win-helper-link', [link, '/nologo', '/machine:x64', '/INCREMENTAL:NO', '/subsystem:console', '/out:process_child_helper.exe', 'win-helper.obj'])
    for stem in ('process', 'process_windows'):
        run('win-'+stem+'-compile', [cl, *flags, '/DHYLE_PROCESS_BUILD', '/Fowin-'+stem+'.obj', str(ROOT/'src/process'/(stem+'.cc'))])
    run('win-test-compile', [cl, *flags, '/external:I'+str(gtest/'include'), '/external:I'+str(gtest), '/external:W0',
        '/DHYLE_PROCESS_TEST_HELPER_PATH="'+str(OUT/'process_child_helper.exe').replace('\\','/')+'"',
        '/Fowin-test.obj', str(ROOT/'tests/process/process_test.cc')])
    run('win-test-link', [link, '/nologo', '/machine:x64', '/INCREMENTAL:NO', '/subsystem:console',
        '/out:process_tests.exe', 'win-test.obj', 'win-process.obj', 'win-process_windows.obj', *test_libs])
    (OUT/'windows-identity.json').write_text(json.dumps({'fresh_sources':{str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [ROOT/'src/process/process.cc',ROOT/'src/process/process_windows.cc',ROOT/'tests/process/process_test.cc',ROOT/'tests/process/process_child_helper.cc']},
        'reused_libraries':{p:hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in test_libs if Path(p).is_absolute()},
        'scope':'Fresh Process common/Windows/helper/test only; cached static foundation; no CMake build/staging/download.'}, indent=2))
if '--tests' in sys.argv:
    print(run('win-tests', [str(OUT/'process_tests.exe'), '--gtest_filter=Process.*', '--gtest_output=json:'+str(OUT/'win-tests.json')], timeout=120))
if '--counts' in sys.argv:
    for arm in ('baseline','candidate'):
        stem='windows-'+arm+'-count'
        run(stem+'-compile',[cl,*flags,'/Fo'+stem+'.obj',str(OUT/(stem+'.cc'))])
        run(stem+'-link',[link,'/nologo','/machine:x64','/INCREMENTAL:NO','/subsystem:console','/out:'+stem+'.exe',stem+'.obj',*libs])
        print(run(stem,[str(OUT/(stem+'.exe')),str(OUT/('win-'+arm))]))
    checks={str(n):(OUT/('win-baseline-'+str(n)+'.env')).read_bytes()==(OUT/('win-candidate-'+str(n)+'.env')).read_bytes() for n in (16,1024)}
    (OUT/'win-count-output-equivalence.json').write_text(json.dumps(checks,indent=2))
    assert all(checks.values())
