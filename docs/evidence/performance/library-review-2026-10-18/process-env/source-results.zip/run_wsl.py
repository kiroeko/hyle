from pathlib import Path
import hashlib, json, subprocess, sys, time

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]
BIN = Path('/root/hyle-scratch/process-env-20261018')
BUILD = Path('/root/hyle-scratch/io-watch-v2-dev')
BIN.mkdir(parents=True, exist_ok=True)
gtest = Path('/root/.cache/hyle/dependencies/v1/sources/googletest-063de7e9578f-162765170ae6/googletest')
flags = ['-std=c++23','-O3','-DNDEBUG','-Wall','-Wextra','-Wpedantic','-Werror','-pthread',
    '-DHYLE_PROCESS_BUILD','-I'+str(ROOT/'include'),'-I'+str(ROOT/'src/process')]
libnames = ['hyle_io_core','hyle_sched','hyle_mem_vm','hyle_mem','hyle_platform_fs','hyle_platform_thread','hyle_platform','hyle_error','hyle_time','hyle_container']
libs = ['-L'+str(BUILD/'bin'),'-Wl,-rpath,'+str(BUILD/'bin'), *['-l'+n for n in libnames], '-ldl', '-pthread']

def run(tag, command, timeout=120):
    (OUT/(tag+'-command.json')).write_text(json.dumps(command, indent=2))
    start = time.monotonic()
    p = subprocess.run(command, cwd=BIN, capture_output=True, timeout=timeout)
    (OUT/(tag+'.stdout.txt')).write_bytes(p.stdout)
    (OUT/(tag+'.stderr.txt')).write_bytes(p.stderr)
    (OUT/(tag+'-exit.json')).write_text(json.dumps({'exit':p.returncode,'wall_seconds':time.monotonic()-start}))
    print(tag,p.returncode,flush=True)
    if p.returncode:
        print(p.stdout.decode(errors='replace')); print(p.stderr.decode(errors='replace'))
        raise SystemExit(p.returncode)
    return p.stdout.decode(errors='replace')

if '--build' in sys.argv:
    run('wsl-helper-compile',['g++-14',*flags,str(ROOT/'tests/process/process_child_helper.cc'),'-o','process_child_helper'])
    for stem in ('process','process_posix'):
        run('wsl-'+stem+'-compile',['g++-14',*flags,'-c',str(ROOT/'src/process'/(stem+'.cc')),'-o',stem+'.o'])
    run('wsl-test-compile',['g++-14',*flags,'-isystem',str(gtest/'include'),'-isystem',str(gtest),
        '-DHYLE_PROCESS_TEST_HELPER_PATH="'+str(BIN/'process_child_helper')+'"','-c',str(ROOT/'tests/process/process_test.cc'),'-o','test.o'])
    run('wsl-test-link',['g++-14','-o','process_tests','test.o','process.o','process_posix.o',
        str(BUILD/'lib/libgtest_main.a'),str(BUILD/'lib/libgtest.a'),*libs])
    loader = run('wsl-loader',['ldd',str(BIN/'process_tests')])
    paths = {str(BUILD/'bin'/('lib'+n+'.so')): hashlib.sha256((BUILD/'bin'/('lib'+n+'.so')).read_bytes()).hexdigest() for n in libnames}
    (OUT/'wsl-identity.json').write_text(json.dumps({'loader':loader,'reused_libraries':paths,
        'fresh_sources':{str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [ROOT/'src/process/process.cc',ROOT/'src/process/process_posix.cc',ROOT/'tests/process/process_test.cc',ROOT/'tests/process/process_child_helper.cc']},
        'scope':'Fresh Process common/POSIX/helper/test only; cached shared foundation; no CMake build/download.'},indent=2))
if '--tests' in sys.argv:
    print(run('wsl-tests',[str(BIN/'process_tests'),'--gtest_filter=Process.*','--gtest_output=json:'+str(OUT/'wsl-tests.json')],timeout=120))
if '--counts' in sys.argv:
    for arm in ('baseline','candidate'):
        stem='posix-'+arm+'-count'
        run(stem+'-compile',['g++-14',*flags,str(OUT/(stem+'.cc')),'-o',str(BIN/stem),*libs])
        print(run(stem,[str(BIN/stem),str(OUT/('wsl-'+arm))]))
    checks={str(n):(OUT/('wsl-baseline-'+str(n)+'.env')).read_bytes()==(OUT/('wsl-candidate-'+str(n)+'.env')).read_bytes() for n in (16,1024)}
    (OUT/'wsl-count-output-equivalence.json').write_text(json.dumps(checks,indent=2))
    assert all(checks.values())
