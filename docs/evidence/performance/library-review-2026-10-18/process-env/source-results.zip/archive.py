from pathlib import Path
import hashlib, json, shutil, subprocess, zipfile

OUT=Path(__file__).resolve().parent
ROOT=OUT.parents[2]
paths=['src/process/process.cc','src/process/process_posix.cc','src/process/process_windows.cc','tests/process/process_test.cc']
for name in paths:
    p=OUT/'candidate'/name
    p.parent.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(ROOT/name,p)
diff=subprocess.run(['git','diff','--',*paths],cwd=ROOT,capture_output=True,check=True).stdout
(OUT/'source.diff').write_bytes(diff)
counts={}
for platform in ('windows','posix'):
    counts[platform]={}
    for arm in ('baseline','candidate'):
        counts[platform][arm]=[json.loads(line) for line in (OUT/(platform+'-'+arm+'-count.stdout.txt')).read_text().splitlines() if line.startswith('{')]
windows_artifacts=[]
for p in OUT.iterdir():
    if p.suffix in ('.obj','.exe'):
        windows_artifacts.append({'path':str(p),'bytes':p.stat().st_size})
wsl_out=subprocess.run(['wsl.exe','--','python3','-c',
    'from pathlib import Path; import json; p=Path("/root/hyle-scratch/process-env-20261018"); print(json.dumps([{ "path":str(x),"bytes":x.stat().st_size } for x in sorted(p.iterdir()) if x.is_file()]))'],capture_output=True,check=True).stdout
cleanup={'windows_rebuildable':windows_artifacts,'wsl_rebuildable':json.loads(wsl_out),'delete_via':'Root test.ps1 only, exact files; no SDK/cache/dependency deletion','preserve':'All source snapshots, scripts, diffs, commands, raw results, serialized environment outputs, summary and archive.'}
(OUT/'cleanup.json').write_text(json.dumps(cleanup,indent=2))
summary={
    'change':'Process environment duplicate validation and inherited merge: sorted name index replaces repeated scans.',
    'baseline_git':(OUT/'baseline-commit.txt').read_text().strip(),
    'canonical_source_sha256':{p:hashlib.sha256((ROOT/p).read_bytes()).hexdigest() for p in paths},
    'algorithm':{
        'common':'Validate names and values, sort borrowed string_view names, adjacent duplicate check. Inline16 entries; fallible AllocatorRef reserve larger than16.',
        'posix':'Exact case names sorted in inline16 Scratch index; one strchr per inherited entry plus binary_search; original appended-change order remains.',
        'windows':'Sort existing UTF16 WideChange metadata using length then original CompareStringOrdinal(TRUE), reject adjacent equal names and lower_bound inherited names. Original special-name extraction and full-entry ordinal output sort remain; no additional native index allocation.',
        'complexity':'O(M log M + E log M) name work, plus Windows pre-existing final output sort; compared with common M(M-1)/2 and native E*M scans.'},
    'correctness':{
        'windows':{'tests':21,'passed':21,'raw':'win-tests.stdout.txt','compiler':'MSVC19.50.35728 x64 Release /O2 /MD /W4 /WX, static foundation'},
        'wsl':{'tests':23,'passed':23,'raw':'wsl-tests.stdout.txt','compiler':'GCC14 C++23 Release -O3 -Wall -Wextra -Wpedantic -Werror, shared foundation'},
        'added_or_expanded':'128-change replacement and inherited/unset, large duplicate then runtime retry, Windows Unicode ordinal case equivalence vs POSIX exact case distinction, common index allocation failure and successful retry with balanced allocator.',
        'instrumented_environment_bytes_identical':{'windows':json.loads((OUT/'win-count-output-equivalence.json').read_text()),'posix':json.loads((OUT/'wsl-count-output-equivalence.json').read_text())},
        'native_count_fixture':'M16 control and M1024 representative; E=M+2 regular inherited entries, half changed names match existing, every third change unset. Windows adds one inherited =C: special entry. Exact serialized old/new environment blocks compared. Unicode case equivalence/distinction is separately covered by the canonical Process test, not this count fixture.',
        'small_index_allocation':'Common validation allocator calls are0 on both sides at16 changes; candidate1024 calls1, baseline0.'},
    'isolated_operation_counts':counts,
    'counts_method':'make_count_probe.py extracts the exact actual source validation and environment-builder functions from frozen baseline/canonical candidate, instruments name-comparison/strchr sites, substitutes only inherited-environment acquisition with fixed arrays. Windows name count includes duplicate/equality/lookup comparisons, excludes unchanged final full-output ordering comparisons. POSIX count includes sort/lookup comparisons or old name-match attempts. These are operations, not elapsed time or public API count guarantees.',
    'limits':[
        'No spawn-time benchmark or external-peer ranking; this fixes a source-confirmed complexity issue without claiming a measured end-to-end speedup.',
        'macOS Process was not built or run; it shares changed process_posix.cc but its native runtime was not validated this round.',
        'Zero-change inherited default path already bypasses environment packing; this change does not claim that default spawn previously paid E*M.',
        'Additional common scratch allocation for more than16 changes may fail with ResourceExhausted before child admission; regression confirms typed failure and retry.',
        'Validation now checks all name/value fields before sorted duplicate detection; when multiple inputs are malformed, the InvalidArgument message precedence may differ.',
        'No full library build, CMake configure, dependency download or SDK copy. Current cached foundation library hashes/loader paths are in windows-identity.json and wsl-identity.json.'
    ],
    'cleanup':'cleanup.json',
    'source_diff':'source.diff'}
(OUT/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
archive=OUT/'source-results.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
    for p in sorted(OUT.rglob('*')):
        if p.is_file() and p != archive and p.suffix not in ('.obj','.exe','.zip'):
            z.write(p,p.relative_to(OUT))
print(json.dumps({'path':str(archive),'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'cleanup_windows_bytes':sum(x['bytes'] for x in cleanup['windows_rebuildable']),'cleanup_wsl_bytes':sum(x['bytes'] for x in cleanup['wsl_rebuildable'])},indent=2))
