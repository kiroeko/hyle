
#include <algorithm>
#include <climits>
#include <cstdio>
#include <cstring>
#include <cwchar>
#include <fstream>
#include <string>
#include <string_view>
#include <vector>
#include "hyle/process/process.h"
#include "hyle/io/io_context.h"
#include "hyle/container/small_vector.h"
#include "hyle/error/system_error.h"
#ifdef _WIN32
#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#include <windows.h>
#endif
namespace hyle::process::detail {
std::size_t comparisons=0, extractions=0;
bool counted_less(std::string_view a,std::string_view b) noexcept {++comparisons; return a<b;}
bool counted_equal(std::string_view a,std::string_view b) noexcept {++comparisons; return a==b;}
const char* counted_separator(const char* text) noexcept {++extractions;return std::strchr(text,'=');}
template<class T,std::size_t Inline>
using Scratch=container::SmallVector<T,Inline,mem::AllocatorRef>;
char** probe_environ=nullptr;
#ifdef _WIN32
wchar_t* probe_wide_environment=nullptr;
wchar_t* probe_get_environment() noexcept{return probe_wide_environment;}
BOOL probe_free_environment(wchar_t*) noexcept{return TRUE;}
#endif
bool contains_nul(std::string_view text) noexcept {
  return text.find('\0') != std::string_view::npos;
}

bool valid_stdio_kind(ProcessStdioKind kind) noexcept {
  switch (kind) {
    case ProcessStdioKind::kInherit:
    case ProcessStdioKind::kNull:
    case ProcessStdioKind::kFile:
    case ProcessStdioKind::kPipe:
    case ProcessStdioKind::kMergeStdout:
      return true;
  }
  return false;
}

Status validate_stdio(ProcessStdio value, bool stderr_slot) noexcept {
  if (!valid_stdio_kind(value.kind()))
    return Status::InvalidArgument("process stdio kind is invalid");
  if (value.kind() == ProcessStdioKind::kMergeStdout && !stderr_slot)
    return Status::InvalidArgument(
        "merge_stdout is valid only for child stderr");
  if (value.kind() == ProcessStdioKind::kFile &&
      value.file_handle() == platform::FileHandle::kInvalid) {
    return Status::InvalidArgument("process stdio file handle is not open");
  }
  return Status{};
}

Status validate_start_options(const ProcessStartOptions& options,
                              mem::AllocatorRef allocator) noexcept {
  if (options.executable.empty() || contains_nul(options.executable))
    return Status::InvalidArgument(
        "process executable must be non-empty and contain no NUL");
  if (options.executable_search != ExecutableSearch::kExact &&
      options.executable_search != ExecutableSearch::kPath) {
    return Status::InvalidArgument("process executable search mode is invalid");
  }
  if (options.environment_mode != EnvironmentMode::kInherit &&
      options.environment_mode != EnvironmentMode::kReplace) {
    return Status::InvalidArgument("process environment mode is invalid");
  }
  if (options.working_directory.has_value() &&
      (options.working_directory->empty() ||
       contains_nul(*options.working_directory))) {
    return Status::InvalidArgument(
        "process working directory must be non-empty and contain no NUL");
  }
  for (std::string_view argument : options.arguments) {
    if (contains_nul(argument))
      return Status::InvalidArgument("process argument contains NUL");
  }
  for (std::size_t i = 0; i < options.environment_changes.size(); ++i) {
    const EnvironmentChange& change = options.environment_changes[i];
    if (change.name.empty() || contains_nul(change.name) ||
        change.name.find('=') != std::string_view::npos) {
      return Status::InvalidArgument(
          "environment variable name must be non-empty and contain no '=' or NUL");
    }
    if (change.value.has_value() && contains_nul(*change.value))
      return Status::InvalidArgument("environment variable value contains NUL");
    if (options.environment_mode == EnvironmentMode::kReplace &&
        !change.value.has_value()) {
      return Status::InvalidArgument(
          "replacement environment cannot contain unset entries");
    }
  }
  if (options.environment_changes.size() > 1) {
    container::SmallVector<std::string_view, 16, mem::AllocatorRef> names(
        allocator);
    if (!names.try_reserve(options.environment_changes.size()))
      return Status::ResourceExhausted(
          "process environment index allocation failed");
    for (const EnvironmentChange& change : options.environment_changes)
      names.push_back(change.name);
    std::sort(names.begin(), names.end(), counted_less);
    if (std::adjacent_find(names.begin(), names.end(), counted_equal) != names.end())
      return Status::InvalidArgument(
          "process environment contains duplicate variable names");
  }
  Status status = validate_stdio(options.stdin_stream, false);
  if (!status.ok()) return status;
  status = validate_stdio(options.stdout_stream, false);
  if (!status.ok()) return status;
  status = validate_stdio(options.stderr_stream, true);
  if (!status.ok()) return status;

  const bool has_pipe =
      options.stdin_stream.kind() == ProcessStdioKind::kPipe ||
      options.stdout_stream.kind() == ProcessStdioKind::kPipe ||
      options.stderr_stream.kind() == ProcessStdioKind::kPipe;
  if (has_pipe) {
    if (options.pipe_io == nullptr || !options.pipe_io->valid())
      return Status::FailedPrecondition(
          "process pipe stdio requires a valid IoContext");
    if (options.pipe_owner >= options.pipe_io->num_workers())
      return Status::OutOfRange(
          "process pipe owner is outside IoContext");
  }
  return Status{};
}

bool append_bytes(Scratch<char, 512>& output, std::string_view text,
                  bool nul = false) noexcept {
  const std::size_t extra = text.size() + (nul ? 1u : 0u);
  if (extra > SIZE_MAX - output.size() ||
      !output.try_reserve(output.size() + extra)) {
    return false;
  }
  for (char byte : text) output.push_back(byte);
  if (nul) output.push_back('\0');
  return true;
}

struct PackedStrings {
  explicit PackedStrings(mem::AllocatorRef allocator) noexcept
      : bytes(allocator), offsets(allocator), values(allocator) {}

  bool add(std::string_view text) noexcept {
    if (!offsets.try_push_back(bytes.size())) return false;
    return append_bytes(bytes, text, true);
  }

  bool finish() noexcept {
    if (!values.try_reserve(offsets.size() + 1)) return false;
    for (std::size_t offset : offsets) values.push_back(bytes.data() + offset);
    values.push_back(nullptr);
    return true;
  }

  Scratch<char, 512> bytes;
  Scratch<std::size_t, 16> offsets;
  Scratch<char*, 17> values;
};

Result<PackedStrings> build_environment(
    mem::AllocatorRef allocator, const ProcessStartOptions& options) noexcept {
  PackedStrings result(allocator);
  if (options.environment_mode == EnvironmentMode::kInherit) {
    Scratch<std::string_view, 16> changed_names(allocator);
    if (!changed_names.try_reserve(options.environment_changes.size()))
      return make_unexpected(Status::ResourceExhausted(
          "process environment index allocation failed"));
    for (const EnvironmentChange& change : options.environment_changes)
      changed_names.push_back(change.name);
    std::sort(changed_names.begin(), changed_names.end(), counted_less);
    for (char** current = probe_environ; current != nullptr && *current != nullptr;
         ++current) {
      const char* separator = counted_separator(*current);
      const bool replaced = separator != nullptr &&
          std::binary_search(changed_names.begin(), changed_names.end(),
              std::string_view(*current,
                  static_cast<std::size_t>(separator - *current)), counted_less);
      if (!replaced && !result.add(*current)) {
        return make_unexpected(Status::ResourceExhausted(
            "process environment allocation failed"));
      }
    }
  }
  for (const EnvironmentChange& change : options.environment_changes) {
    if (!change.value.has_value()) continue;
    if (!result.offsets.try_push_back(result.bytes.size()) ||
        !append_bytes(result.bytes, change.name) ||
        !append_bytes(result.bytes, "=") ||
        !append_bytes(result.bytes, *change.value, true)) {
      return make_unexpected(Status::ResourceExhausted(
          "process environment allocation failed"));
    }
  }
  return result;
}


} // namespace hyle::process::detail
struct AllocationCount {
  std::size_t allocations=0;
  static void* allocate(void* raw,std::size_t size,std::size_t align) noexcept {
    ++static_cast<AllocationCount*>(raw)->allocations;
    return hyle::mem::system_allocator().allocate(size,align);
  }
  static void free(void*,void* p,std::size_t size,std::size_t align) noexcept {
    hyle::mem::system_allocator().deallocate(p,size,align);
  }
  static void* resize(void* raw,void* p,std::size_t before,std::size_t after,std::size_t align) noexcept {
    ++static_cast<AllocationCount*>(raw)->allocations;
    return hyle::mem::system_allocator().reallocate(p,before,after,align);
  }
  hyle::mem::AllocatorRef get() noexcept {return {allocate,free,resize,this};}
};
int main(int argc,char** argv) {
  if(argc!=2)return 2;
  using namespace hyle::process;
  using namespace hyle::process::detail;
  for(const std::size_t n:{16u,1024u}) {
    std::vector<std::string> names,entries;
    std::vector<EnvironmentChange> changes;
    names.reserve(n);entries.reserve(n+4);changes.reserve(n);
    for(std::size_t i=n;i>0;--i) {
      const std::size_t k=i-1;
      char key[64];
      std::snprintf(key,sizeof(key),"HYLE_ENV_%04zu",k<n/2?2*k:n+k);
      names.emplace_back(key);
      changes.push_back({names.back(),k%3==0?std::nullopt:std::optional<std::string_view>{"new"}});
    }
    for(std::size_t i=0;i<n;++i) {
      char entry[80];std::snprintf(entry,sizeof(entry),"HYLE_ENV_%04zu=old",i);
      entries.emplace_back(entry);
    }
    entries.emplace_back("A=old");entries.emplace_back("AA=old");
    std::vector<char*> envp;
    for(auto& entry:entries)envp.push_back(entry.data());
    envp.push_back(nullptr);probe_environ=envp.data();
#ifdef _WIN32
    std::vector<wchar_t> wide;
    for(const auto& entry:entries) {for(char c:entry)wide.push_back(static_cast<wchar_t>(c));wide.push_back(0);}
    const wchar_t special[]=L"=C:=C:\\kept";
    wide.insert(wide.end(),special,special+sizeof(special)/sizeof(*special));
    wide.push_back(0);probe_wide_environment=wide.data();
#endif
    ProcessStartOptions options;options.executable="probe";options.environment_changes=changes;
    AllocationCount allocator;
    comparisons=0;extractions=0;
    auto status=validate_start_options(options,allocator.get());
    if(!status.ok())return 3;
    const auto validation_comparisons=comparisons;
    const auto validation_allocations=allocator.allocations;
    comparisons=0;extractions=0;
    std::vector<char> serialized;
#ifdef _WIN32
    EnvironmentBlock block(hyle::mem::system_allocator());
    status=block.build(options);if(!status.ok())return 4;
    const wchar_t* data=block.data();std::size_t size=0;
    while(data[size]!=0||data[size+1]!=0)++size;
    size+=2;
    serialized.assign(reinterpret_cast<const char*>(data),reinterpret_cast<const char*>(data+size));
#else
    auto result=build_environment(hyle::mem::system_allocator(),options);if(!result.has_value())return 4;
    serialized.assign(result->bytes.begin(),result->bytes.end());
#endif
    const auto merge_comparisons=comparisons;
    const auto separators=extractions;
    const std::string path=std::string(argv[1])+"-"+std::to_string(n)+".env";
    std::ofstream file(path,std::ios::binary);file.write(serialized.data(),static_cast<std::streamsize>(serialized.size()));file.close();
    std::printf("{\"changes\":%zu,\"inherited_regular\":%zu,\"validation_name_comparisons\":%zu,\"validation_allocator_calls\":%zu,\"native_name_comparisons\":%zu,\"native_separator_scans\":%zu,\"serialized_bytes\":%zu}\n",n,entries.size(),validation_comparisons,validation_allocations,merge_comparisons,separators,serialized.size());
  }
}
