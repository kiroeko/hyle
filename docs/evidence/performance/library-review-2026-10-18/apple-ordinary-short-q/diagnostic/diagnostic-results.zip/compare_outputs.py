from array import array
import hashlib
import json
import math
from pathlib import Path
import sys
import zipfile

ROOT = Path(__file__).resolve().parent


def decode(raw, kind):
    values = array(kind)
    values.frombytes(raw)
    if sys.byteorder != 'little':
        values.byteswap()
    return values


def location(i, layout):
    row, d = divmod(i, 256)
    h, t = divmod(row, 513) if layout == 'bhsd' else (row % 8, row // 8)
    return h, t, d


def main():
    with zipfile.ZipFile(ROOT / 'full-output-raw.zip') as z:
        cpp = {arm: [json.loads(line) for line in z.read('raw-' + arm + '/arrays.jsonl').decode().splitlines()]
               for arm in ['baseline', 'candidate']}
        summaries = {arm: json.loads(z.read('raw-' + arm + '/summary.json'))
                     for arm in ['baseline', 'candidate']}
        oracle = {}
        oracle_identity = []
        for phase in [0, 1]:
            name = 'oracle-phase' + str(phase) + '-hqt17.f64'
            old = z.read('raw-baseline/' + name)
            new = z.read('raw-candidate/' + name)
            assert old == new, 'different independent oracle bytes: ' + name
            reference = decode(old, 'd')
            assert len(reference) == 8 * 513 * 17
            # Match frozen expect() and C++ probe's original_expect exactly.
            target = array('f', reference)
            allowed = [2e-6 + 6e-6 * abs(float(r)) for r in target]
            oracle[phase] = reference, target, allowed
            oracle_identity.append({'file': name, 'bytes': len(old),
                'sha256': hashlib.sha256(old).hexdigest(), 'old_new_byte_identical': True})

        rows = []
        for old_stats, new_stats in zip(cpp['baseline'], cpp['candidate']):
            name = old_stats['file']
            assert name == new_stats['file']
            layout, phase = old_stats['layout'], old_stats['phase']
            old_raw, new_raw = z.read('raw-baseline/' + name), z.read('raw-candidate/' + name)
            old, new = decode(old_raw, 'f'), decode(new_raw, 'f')
            old_bits, new_bits = decode(old_raw, 'I'), decode(new_raw, 'I')
            assert len(old) == len(new) == 8 * 513 * 256
            reference, target, allowed = oracle[phase]
            result = {'file': name, 'layout': layout, 'phase': phase, 'rebind': old_stats['rebind'],
                'elements': len(old), 'baseline_violations': 0, 'candidate_violations': 0,
                'baseline_nonfinite': 0, 'candidate_nonfinite': 0, 'old_pass_new_fail': 0,
                'old_fail_new_pass': 0, 'both_fail': 0, 'bit_differences': 0,
                'bit_difference_query_rows': {},
                'candidate_error_greater': 0, 'max_positive_error_growth': 0.0,
                'max_abs_old_new': 0.0, 'first_bit_difference': None,
                'first_old_pass_new_fail': None, 'worst_error_growth': None,
                'worst_old_new_difference': None, 'baseline_max_absolute': 0.0,
                'candidate_max_absolute': 0.0, 'baseline_max_normalized': 0.0,
                'candidate_max_normalized': 0.0}
            for i, (b, c) in enumerate(zip(old, new)):
                h, t, d = location(i, layout)
                rindex = (h * 513 + t) * 17 + d % 17
                r, limit = float(target[rindex]), allowed[rindex]
                bf, cf = math.isfinite(b), math.isfinite(c)
                eb = abs(b - r) if bf else math.inf
                ec = abs(c - r) if cf else math.inf
                bv, cv = not bf or eb > limit, not cf or ec > limit
                result['baseline_violations'] += bv
                result['candidate_violations'] += cv
                result['baseline_nonfinite'] += not bf
                result['candidate_nonfinite'] += not cf
                result['old_pass_new_fail'] += not bv and cv
                result['old_fail_new_pass'] += bv and not cv
                result['both_fail'] += bv and cv
                different = old_bits[i] != new_bits[i]
                result['bit_differences'] += different
                if different:
                    key = str(t)
                    result['bit_difference_query_rows'][key] = result['bit_difference_query_rows'].get(key, 0) + 1
                delta = abs(c - b) if bf and cf else 0.0 if not different else math.inf
                growth = ec - eb if not (math.isinf(ec) and math.isinf(eb)) else 0.0
                result['candidate_error_greater'] += growth > 0
                result['baseline_max_absolute'] = max(result['baseline_max_absolute'], eb)
                result['candidate_max_absolute'] = max(result['candidate_max_absolute'], ec)
                result['baseline_max_normalized'] = max(result['baseline_max_normalized'], eb / limit)
                result['candidate_max_normalized'] = max(result['candidate_max_normalized'], ec / limit)

                def point():
                    return {'flat': i, 'batch': 0, 'head': h, 'query': t, 'channel': d,
                        'baseline': b, 'candidate': c, 'expected_original_expect': r,
                        'expected_unrounded_fp64': reference[rindex], 'allowed': limit,
                        'baseline_error': eb, 'candidate_error': ec,
                        'positive_error_growth': max(0.0, growth), 'old_new_absolute_delta': delta}

                if different and result['first_bit_difference'] is None:
                    result['first_bit_difference'] = point()
                if not bv and cv and result['first_old_pass_new_fail'] is None:
                    result['first_old_pass_new_fail'] = point()
                if growth > result['max_positive_error_growth']:
                    result['max_positive_error_growth'] = growth
                    result['worst_error_growth'] = point()
                if delta > result['max_abs_old_new']:
                    result['max_abs_old_new'] = delta
                    result['worst_old_new_difference'] = point()
            # Reconcile all-output offline counts with the actual probe reports.
            for arm, source in [('baseline', old_stats), ('candidate', new_stats)]:
                assert result[arm + '_violations'] == source['original_expect']['violations'], name
                assert result[arm + '_nonfinite'] == source['original_expect']['nonfinite'], name
                assert result[arm + '_max_absolute'] == source['original_expect']['max_absolute'], name
                assert math.isclose(result[arm + '_max_normalized'],
                    source['original_expect']['max_normalized'], rel_tol=2e-15), name
            result['probe_stats_reconciled'] = True
            result['baseline_probe_stats'] = old_stats
            result['candidate_probe_stats'] = new_stats
            rows.append(result)

        totals = {key: sum(row[key] for row in rows) for key in ['elements',
            'baseline_violations', 'candidate_violations', 'old_pass_new_fail',
            'old_fail_new_pass', 'both_fail', 'bit_differences', 'candidate_error_greater',
            'baseline_nonfinite', 'candidate_nonfinite']}
        for key in ['max_positive_error_growth', 'max_abs_old_new', 'baseline_max_absolute',
                    'candidate_max_absolute', 'baseline_max_normalized', 'candidate_max_normalized']:
            totals[key] = max(row[key] for row in rows)
        repeat = []
        for arm in ['baseline', 'candidate']:
            assert summaries[arm]['diagnostic_complete'] and summaries[arm]['arrays'] == 6
            assert totals[arm + '_violations'] == summaries[arm]['original_expect_violations']
            for layout in ['bhsd', 'bshd']:
                before = z.read('raw-' + arm + '/' + layout + '-phase1.f32')
                rebound = z.read('raw-' + arm + '/' + layout + '-phase1-rebind.f32')
                repeat.append({'arm': arm, 'layout': layout,
                    'phase1_rebind_byte_identical': before == rebound})
        output = {'status': 'offline all-output diagnostic; neither arm golden-passes',
            'input_scope': 'same fixed four layout/phase outputs plus two existing rebind outputs',
            'original_budget': {'absolute': 2e-6, 'relative': 6e-6,
                'target': 'independent FP64 oracle rounded to F32 exactly as frozen expect()'},
            'oracle_identity': oracle_identity, 'totals_over_six_outputs': totals,
            'array_pairs': rows, 'rebind_output_identity': repeat, 'probe_summaries': summaries,
            'no_performance_claim': True, 'no_isolation_experiment_run': True}
        (ROOT / 'full-output-comparison.json').write_text(json.dumps(output, indent=2,
            allow_nan=False) + '\n', encoding='utf-8')
        print(json.dumps({'totals': totals, 'oracle_bytes_identical': True,
            'old_payload_bit_changes': {a: summaries[a]['retained_payload_bit_changes']
                for a in summaries}, 'rebind_outputs_bit_identical': all(
                r['phase1_rebind_byte_identical'] for r in repeat)}, indent=2))


if __name__ == '__main__':
    main()
