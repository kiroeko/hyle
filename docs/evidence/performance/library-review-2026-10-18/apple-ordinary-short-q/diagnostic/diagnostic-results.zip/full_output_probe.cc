#include "tests/compute_route_apple/tensor_test_support.h"

#include <bit>
#include <filesystem>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <optional>
#include <sstream>
#include <stdexcept>
#include <string>
#include <string_view>
#include <utility>

namespace {
using namespace apple_tensor_test;
namespace sq = apple_tensor_test::ordinary_short_query;
namespace fs = std::filesystem;
static_assert(sizeof(float) == 4 && sizeof(double) == 8);
static_assert(std::numeric_limits<float>::is_iec559 && std::numeric_limits<double>::is_iec559);
static_assert(std::endian::native == std::endian::little);

std::string json_string(std::string_view value) {
  std::ostringstream result;
  result << '"';
  for (unsigned char ch : value) {
    if (ch == '"' || ch == '\\') result << '\\' << char(ch);
    else if (ch < 32) result << "\\u00" << std::hex << std::setw(2)
                           << std::setfill('0') << unsigned(ch) << std::dec;
    else result << char(ch);
  }
  return result.str() + '"';
}

std::string number(double value) {
  if (std::isnan(value)) return "\"NaN\"";
  if (std::isinf(value)) return value < 0 ? "\"-Infinity\"" : "\"Infinity\"";
  std::ostringstream result;
  result << std::setprecision(17) << value;
  return result.str();
}

void check(hyle::Status status, const char *phase) {
  if (status.ok()) return;
  std::ostringstream message;
  message << phase << ": " << status.message();
  throw std::runtime_error(message.str());
}

template <class T> T take(hyle::Result<T> result, const char *phase) {
  if (!result) check(result.error(), phase);
  return std::move(*result);
}

template <class T> void write_array(const fs::path &path, const std::vector<T> &values) {
  std::ofstream file(path, std::ios::binary);
  file.write(reinterpret_cast<const char *>(values.data()),
             static_cast<std::streamsize>(values.size() * sizeof(T)));
  if (!file) throw std::runtime_error("write failed: " + path.string());
}

std::size_t index(c::AttentionLayout layout, int h, int t, int d) {
  return layout == c::AttentionLayout::kBatchHeadSequenceDepth
      ? (std::size_t(h) * sq::queries + t) * sq::depth + d
      : (std::size_t(t) * sq::heads + h) * sq::depth + d;
}

std::vector<float> flattened(const mx::array &output) {
  if (output.dtype() != mx::float32 || output.status() != mx::array::available)
    throw std::runtime_error("output is not ready F32");
  std::vector<float> result(output.size());
  const auto *data = output.data<float>();
  for (std::size_t i = 0; i < result.size(); ++i) {
    std::size_t rest = i, offset = 0;
    for (std::size_t axis = output.ndim(); axis-- > 0;) {
      offset += (rest % output.shape()[axis]) * output.strides()[axis];
      rest /= output.shape()[axis];
    }
    result[i] = data[offset];
  }
  return result;
}

struct Point {
  std::size_t flat = 0;
  double actual = 0, expected = 0, error = 0, allowed = 0, normalized = 0;
};

struct Statistics {
  std::size_t checked = 0, violations = 0, nonfinite = 0;
  double max_absolute = 0, max_normalized = 0;
  std::optional<Point> first;
  Point worst, worst_absolute;
  void add(std::size_t i, float actual, double expected) {
    const auto allowed = 2e-6 + 6e-6 * std::abs(expected);
    const bool finite = std::isfinite(actual);
    const double error = finite ? std::abs(double(actual) - expected)
                                : std::numeric_limits<double>::infinity();
    const double normalized = error / allowed;
    Point point{i, double(actual), expected, error, allowed, normalized};
    if (checked == 0 || normalized > max_normalized) worst = point;
    if (checked == 0 || error > max_absolute) worst_absolute = point;
    ++checked;
    if (!finite) ++nonfinite;
    if (!finite || error > allowed) {
      ++violations;
      if (!first) first = point;
    }
    max_absolute = std::max(max_absolute, error);
    max_normalized = std::max(max_normalized, normalized);
  }
};

void print_point(std::ostream &out, const Point &point, c::AttentionLayout layout) {
  const auto row = point.flat / sq::depth;
  const auto h = layout == c::AttentionLayout::kBatchHeadSequenceDepth
      ? row / sq::queries : row % sq::heads;
  const auto t = layout == c::AttentionLayout::kBatchHeadSequenceDepth
      ? row % sq::queries : row / sq::heads;
  out << "{\"flat\":" << point.flat << ",\"batch\":0,\"head\":" << h
      << ",\"query\":" << t << ",\"channel\":" << point.flat % sq::depth
      << ",\"actual\":" << number(point.actual)
      << ",\"expected\":" << number(point.expected)
      << ",\"absolute_error\":" << number(point.error)
      << ",\"allowed\":" << number(point.allowed)
      << ",\"normalized\":" << number(point.normalized) << '}';
}

void print_statistics(std::ostream &out, const Statistics &stats,
                      c::AttentionLayout layout) {
  out << "{\"checked\":" << stats.checked << ",\"violations\":" << stats.violations
      << ",\"nonfinite\":" << stats.nonfinite
      << ",\"max_absolute\":" << number(stats.max_absolute)
      << ",\"max_normalized\":" << number(stats.max_normalized) << ",\"first\":";
  if (stats.first) print_point(out, *stats.first, layout);
  else out << "null";
  out << ",\"worst_normalized\":";
  print_point(out, stats.worst, layout);
  out << ",\"worst_absolute\":";
  print_point(out, stats.worst_absolute, layout);
  out << '}';
}

struct Diagnostic {
  fs::path directory;
  std::ofstream log;
  std::string arm;
  std::size_t arrays = 0, golden_violations = 0, raw_fp64_violations = 0;
  std::size_t old_payload_bit_changes = 0;

  Diagnostic(fs::path path, std::string name)
      : directory(std::move(path)), arm(std::move(name)) {
    if (fs::exists(directory))
      throw std::runtime_error("refuse to overwrite diagnostic directory: " + directory.string());
    fs::create_directories(directory);
    log.open(directory / "arrays.jsonl");
    if (!log) throw std::runtime_error("cannot open diagnostic log");
  }

  std::vector<float> inspect(const mx::array &output,
      const std::vector<double> &reference, c::AttentionLayout layout,
      int phase, bool rebound) {
    auto actual = flattened(output);
    if (actual.size() != reference.size())
      throw std::runtime_error("output element count disagrees with fixed reference");
    const auto expected_shape = layout == c::AttentionLayout::kBatchHeadSequenceDepth
        ? mx::Shape{1, sq::heads, sq::queries, sq::depth}
        : mx::Shape{1, sq::queries, sq::heads, sq::depth};
    if (output.shape() != expected_shape)
      throw std::runtime_error("output shape disagrees with fixed layout");
    Statistics original_expect, raw_fp64;
    for (std::size_t i = 0; i < actual.size(); ++i) {
      // Preserve frozen expect(): the independently computed FP64 target is
      // rounded to output F32 before its original abs2e-6+rel6e-6 comparison.
      original_expect.add(i, actual[i], static_cast<float>(reference[i]));
      raw_fp64.add(i, actual[i], reference[i]);
    }
    const std::string layout_name = layout == c::AttentionLayout::kBatchHeadSequenceDepth
        ? "bhsd" : "bshd";
    const std::string filename = layout_name + "-phase" + std::to_string(phase)
        + (rebound ? "-rebind" : "") + ".f32";
    write_array(directory / filename, actual);
    log << "{\"arm\":" << json_string(arm) << ",\"layout\":" << json_string(layout_name)
        << ",\"phase\":" << phase << ",\"rebind\":" << (rebound ? "true" : "false")
        << ",\"file\":" << json_string(filename) << ",\"elements\":" << actual.size()
        << ",\"original_expect\":";
    print_statistics(log, original_expect, layout);
    log << ",\"unrounded_fp64_diagnostic\":";
    print_statistics(log, raw_fp64, layout);
    log << "}\n";
    log.flush();
    if (!log) throw std::runtime_error("diagnostic statistics write failed");
    ++arrays;
    golden_violations += original_expect.violations;
    raw_fp64_violations += raw_fp64.violations;
    return actual;
  }

  void save_compact_oracle(const std::vector<double> &reference,
                          c::AttentionLayout layout, int phase) {
    // V repeats every17 channels. This is the exact FP64 reference already
    // computed by the frozen helper, not a new/reconstructed normalization.
    std::vector<double> period;
    period.reserve(std::size_t(sq::heads) * sq::queries * 17);
    for (int h = 0; h < sq::heads; ++h)
      for (int t = 0; t < sq::queries; ++t)
        for (int d = 0; d < 17; ++d)
          period.push_back(reference[index(layout, h, t, d)]);
    write_array(directory / ("oracle-phase" + std::to_string(phase) + "-hqt17.f64"), period);
  }
};

void run_layout(Diagnostic &diag, c::AttentionLayout layout) {
  const auto reference_a = sq::reference(layout, 0);
  const auto reference_b = sq::reference(layout, 1);
  if (layout == c::AttentionLayout::kBatchHeadSequenceDepth) {
    diag.save_compact_oracle(reference_a, layout, 0);
    diag.save_compact_oracle(reference_b, layout, 1);
  }
  auto inputs_a = sq::ports(layout, 0), inputs_b = sq::ports(layout, 1);
  const c::Operation operation(c::ScaledDotProductAttention{
      .layout = layout, .mask = c::MaskKind::kBoolean, .scale = sq::scale});
  auto context = take(a::Context::create(), "context");
  auto program = take(context.prepare(operation, inputs_a), "prepare examples");
  std::array<a::InputSpec, 4> specs;
  for (std::size_t i = 0; i < specs.size(); ++i)
    specs[i] = {inputs_a[i].shape(), inputs_a[i].dtype()};
  auto from_specs = take(context.prepare(operation, specs), "prepare specs");
  auto first = take(program.create_invocation(), "invocation A");
  auto second = take(from_specs.create_invocation(), "invocation B");
  check(first.bind(inputs_a), "bind A");
  check(second.bind(inputs_b), "bind B");
  auto work_a = take(first.submit(), "submit A"), work_b = take(second.submit(), "submit B");
  auto result_a = take(work_a.wait(), "wait A"), result_b = take(work_b.wait(), "wait B");
  auto old_output = result_a.get()->arrays()[0];
  const auto old_payload = diag.inspect(old_output, reference_a, layout, 0, false);
  diag.inspect(result_b.get()->arrays()[0], reference_b, layout, 1, false);
  result_a = {};
  work_a = {};
  check(first.bind(inputs_b), "four-port rebind");
  auto rebound = take(first.submit(), "submit rebound");
  inputs_a = inputs_b;
  first = {};
  second = {};
  program = {};
  from_specs = {};
  context = {};
  auto final_result = take(rebound.wait(), "wait rebound");
  diag.inspect(final_result.get()->arrays()[0], reference_b, layout, 1, true);
  const auto after = flattened(old_output);
  if (after.size() != old_payload.size())
    throw std::runtime_error("retained output size changed");
  for (std::size_t i = 0; i < after.size(); ++i)
    diag.old_payload_bit_changes += std::bit_cast<std::uint32_t>(after[i]) !=
        std::bit_cast<std::uint32_t>(old_payload[i]);
}
} // namespace

int main(int argc, char **argv) {
  // Only labels/output paths are selectable. Shape, data, seed and precision
  // remain the frozen control; there is no timing or optional PV execution.
  if (argc != 5 || std::string_view(argv[1]) != "--arm" ||
      std::string_view(argv[3]) != "--output" ||
      (std::string_view(argv[2]) != "baseline" && std::string_view(argv[2]) != "candidate")) {
    std::cerr << "usage: probe --arm baseline|candidate --output directory\n";
    return 2;
  }
  try {
    Diagnostic diag(argv[4], argv[2]);
    run_layout(diag, c::AttentionLayout::kBatchHeadSequenceDepth);
    run_layout(diag, c::AttentionLayout::kBatchSequenceHeadDepth);
    const bool golden = diag.golden_violations == 0 && diag.old_payload_bit_changes == 0;
    std::ostringstream text;
    text << "{\"diagnostic_complete\":true,\"golden_pass\":" << (golden ? "true" : "false")
        << ",\"exit_zero_means\":\"collection completed, not golden passed\""
        << ",\"arm\":" << json_string(diag.arm) << ",\"arrays\":" << diag.arrays
        << ",\"original_expect_violations\":" << diag.golden_violations
        << ",\"unrounded_fp64_violations\":" << diag.raw_fp64_violations
        << ",\"retained_payload_bit_changes\":" << diag.old_payload_bit_changes << "}\n";
    std::ofstream summary(diag.directory / "summary.json");
    summary << text.str();
    if (!summary) throw std::runtime_error("summary write failed");
    std::cout << text.str();
    return 0;
  } catch (const std::exception &error) {
    std::cerr << "{\"diagnostic_complete\":false,\"error\":" << json_string(error.what()) << "}\n";
    return 3;
  }
}
