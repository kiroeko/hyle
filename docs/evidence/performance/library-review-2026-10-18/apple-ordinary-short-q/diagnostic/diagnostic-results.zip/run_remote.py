from pathlib import Path
import hashlib,json,subprocess
root=Path('/Users/kiro/hyle-scratch/compute-unified/library-review-20261018-apple-ordinary-short-q/diagnostic')
plan=json.loads((root/'probe-plan.json').read_text())
def identity(p):
 p=Path(p);return {'path':str(p),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
for expected in plan['baseline_objects']+plan['candidate_objects']:
 actual=identity(expected['path']);assert actual['bytes']==expected['bytes'] and actual['sha256']==expected['sha256'],actual
assert identity(root/'full_output_probe.cc')['sha256']==plan['source']['sha256']
resource=root/'mlx.metallib'
if not resource.exists():resource.symlink_to(root.parent/'mlx.metallib')
records=[]
for i,item in enumerate(plan['commands']):
 phase=item['phase'];cmd=item['argv'];tag=str(i)+'-'+phase
 assert not (root/(tag+'-command.json')).exists()
 try:
  p=subprocess.run(cmd,cwd=root,capture_output=True,timeout=180)
  code,out,err=p.returncode,p.stdout,p.stderr
 except subprocess.TimeoutExpired as e:
  code,out,err=-999,e.stdout or b'',e.stderr or b''
 (root/(tag+'-command.json')).write_text(json.dumps({'argv':cmd,'cwd':str(root),'exit':code},indent=2)+'\n')
 (root/(tag+'.stdout.txt')).write_bytes(out);(root/(tag+'.stderr.txt')).write_bytes(err)
 records.append({'phase':phase,'argv':cmd,'exit':code})
 print(tag,code,flush=True)
 if code:
  print(out.decode(errors='replace'),flush=True);print(err.decode(errors='replace'),flush=True)
  raise SystemExit(3)
 if phase=='one_run_only_after_root_review':
  print(out.decode(errors='replace'),flush=True)
  result=json.loads((Path(cmd[-1])/'summary.json').read_text())
  assert result['diagnostic_complete'] and result['arrays']==6,result
artifacts=[root/'full-output-probe.o',root/'probe-baseline',root/'probe-candidate']
(root/'runtime-identities.json').write_text(json.dumps({'new_products':[identity(p) for p in artifacts],'reused_baseline':plan['baseline_objects'],'reused_candidate':plan['candidate_objects'],'no_product_recompile':True,'no_SDK_change':True},indent=2)+'\n')
(root/'execution-gate.json').write_text(json.dumps({'diagnostic_complete':True,'golden_status':'read individual summaries; diagnostic exit0 is not goldenPASS','commands':records},indent=2)+'\n')
