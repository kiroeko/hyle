from pathlib import Path
import base64,hashlib,json,zipfile
root=Path('/Users/kiro/hyle-scratch/compute-unified/library-review-20261018-apple-ordinary-short-q/diagnostic')
archive=root/'full-output-raw.zip'
assert not archive.exists()
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for arm in ['baseline','candidate']:
  for p in sorted((root/('raw-'+arm)).iterdir()):
   assert p.is_file();z.write(p,p.relative_to(root).as_posix())
 for p in sorted(root.iterdir()):
  if p.is_file() and p.suffix in ['.cc','.json','.map'] or p.is_file() and p.name.endswith(('.stdout.txt','.stderr.txt')):
   z.write(p,p.name)
raw=archive.read_bytes()
print(json.dumps({'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'data':base64.b64encode(raw).decode('ascii')}))
