from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent
PLAN = json.loads((ROOT / "commands-plan.json").read_text())
DESIGN = json.loads((ROOT / "design.json").read_text())
LOG = ROOT / "space-results"
LOG.mkdir(exist_ok=True)


def identity(path):
    path = Path(path)
    return {"path": str(path), "bytes": path.stat().st_size,
            "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}


def command(tag, argv, timeout=180):
    # Never overwrite an earlier failure or repeat a space process silently.
    record = LOG / (tag + "-command.json")
    if record.exists():
        raise RuntimeError("Refusing to overwrite existing attempt: " + tag)
    started = time.time_ns()
    try:
        result = subprocess.run(argv, cwd=PLAN["cwd"], capture_output=True,
                                timeout=timeout)
        code, out, err = result.returncode, result.stdout, result.stderr
    except subprocess.TimeoutExpired as error:
        code, out, err = -999, error.stdout or b"", error.stderr or b""
    record.write_text(json.dumps({"argv": argv, "cwd": PLAN["cwd"],
        "started_unix_ns": started, "finished_unix_ns": time.time_ns(),
        "exit": code}, indent=2) + "\n")
    (LOG / (tag + ".stdout.txt")).write_bytes(out)
    (LOG / (tag + ".stderr.txt")).write_bytes(err)
    print(tag, code, flush=True)
    if out:
        print(out.decode(errors="replace"), flush=True)
    if err:
        print(err.decode(errors="replace"), file=sys.stderr, flush=True)
    return code


def main():
    if sys.argv[1:] != ["--build-space-once"]:
        raise SystemExit("Only the authorized build + old/new space-once flow exists.")
    model = subprocess.check_output(["/usr/sbin/sysctl", "-n", "hw.model"],
                                    text=True).strip()
    if model != "Mac16,12":
        raise RuntimeError("This plan is authorized only on Air Mac16,12")
    command("hardware-toolchain", ["/bin/sh", "-c",
        "uname -a; sysctl -n hw.model hw.memsize hw.ncpu; sw_vers; "
        "/usr/bin/clang++ --version; xcrun --show-sdk-version; "
        "system_profiler SPDisplaysDataType; "
        "pgrep -fl 'baseline|candidate|consumer|clang|tests' || true"])
    source = identity(ROOT / "consumer.cc")
    if source["sha256"] != DESIGN["source"]["sha256"]:
        raise RuntimeError("Consumer source identity changed")
    checked = {}
    for arm, group in PLAN["required_object_identities"].items():
        checked[arm] = []
        for expected in group:
            actual = identity(expected["path"])
            if actual != expected:
                raise RuntimeError("Cached object identity mismatch: " + str(actual))
            checked[arm].append(actual)
    expected_metallib = Path(PLAN["native_libraries"][-1]).parent / "mlx.metallib"
    metallib = Path(PLAN["cwd"]) / "mlx.metallib"
    if not metallib.is_symlink() or metallib.resolve() != expected_metallib.resolve():
        raise RuntimeError("Existing metallib symlink does not select the recorded SDK")
    if not expected_metallib.is_file():
        raise RuntimeError("Original SDK metallib is unavailable")
    for path in PLAN["native_libraries"]:
        if not Path(path).is_file():
            raise RuntimeError("Original library unavailable: " + path)
    (LOG / "preflight-identities.json").write_text(json.dumps({
        "model": model, "source": source, "cached_host_objects": checked,
        "metallib": {"path": str(metallib), "target": str(metallib.resolve())},
        "native_libraries_stat_only": [{"path": p, "bytes": Path(p).stat().st_size}
                                        for p in PLAN["native_libraries"]],
        "environment": {k: v for k, v in os.environ.items()
                        if k.startswith(("MLX_", "HYLE_", "MTL_", "METAL_"))},
        "sdk_rebuild_or_copy": False, "latency_authorized_or_run": False}, indent=2) + "\n")
    if command("consumer-compile", PLAN["consumer_compile"]):
        raise SystemExit(10)
    for arm in ("baseline", "candidate"):
        if command(arm + "-link", PLAN["links"][arm]):
            raise SystemExit(11)
    artifacts = [identity(ROOT / "consumer.o")]
    maps = {}
    for arm, group in checked.items():
        artifacts.append(identity(ROOT / arm))
        mapping = ROOT / (arm + ".map")
        text = mapping.read_text(errors="replace")
        own = all(x["path"] in text for x in group)
        foreign = any(x["path"] in text for other, values in checked.items()
                      if other != arm for x in values)
        original_mlx = PLAN["native_libraries"][-1] in text
        maps[arm] = {"identity": identity(mapping),
                     "complete_own_host_group": own,
                     "foreign_host_group_present": foreign,
                     "original_mlx_archive_selected": original_mlx}
        if not own or foreign or not original_mlx:
            raise RuntimeError("Link-map identity check failed for " + arm)
    (LOG / "built-identities.json").write_text(json.dumps({
        "artifacts": artifacts, "maps": maps}, indent=2) + "\n")
    results = {}
    for arm in ("baseline", "candidate"):
        argv = [str(ROOT / arm), "--space"]
        code = command(arm + "-space", argv, timeout=180)
        text = (LOG / (arm + "-space.stdout.txt")).read_text(errors="replace")
        rows = []
        for line in text.splitlines():
            if line.startswith("{"):
                try:
                    rows.append(json.loads(line))
                except json.JSONDecodeError:
                    pass
        results[arm] = {"exit": code, "json_rows": rows}
    (LOG / "space-once-summary.json").write_text(json.dumps({
        "mode": "space only", "process_order": ["baseline", "candidate"],
        "results": results, "no_retries": True,
        "latency_or_extra_shape_run": False}, indent=2) + "\n")
    (LOG / "cleanup-candidates.json").write_text(json.dumps({
        "host": "kiro@172.22.10.198", "root": str(ROOT),
        "files": artifacts, "count": len(artifacts),
        "logical_bytes": sum(x["bytes"] for x in artifacts),
        "preserve": "source, plans, commands, maps, raw results, summaries, all preexisting objects and SDK",
        "performed_cleanup": False}, indent=2) + "\n")


if __name__ == "__main__":
    main()
