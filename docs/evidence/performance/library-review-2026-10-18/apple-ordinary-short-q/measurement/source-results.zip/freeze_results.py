from pathlib import Path
import hashlib
import json
import statistics
import zipfile

ROOT = Path(__file__).resolve().parent
RAW = ROOT / "space-results"


def read(path):
    return json.loads(path.read_text())


def record(path):
    return {"path": str(path.relative_to(ROOT)).replace("\\", "/"),
            "bytes": path.stat().st_size,
            "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}


def main():
    initial = read(RAW / "space-once-summary.json")
    space = read(RAW / "loader-fixed-space-summary.json")
    latency = read(RAW / "latency-once-summary.json")
    assert [x["exit"] for x in initial["results"].values()] == [4, 4]
    assert space["valid_space_processes"] == 2
    assert len(latency["results"]) == 4
    processes = []
    for result in latency["results"]:
        assert result["passed"] and result["exit"] == 0
        row = result["json_rows"][0]
        samples = row["timed_submit_checkedwait_ns"]
        assert len(samples) == 9
        processes.append({"index": result["index"], "arm": result["arm"],
            "exit": result["exit"], "all_samples_ns_in_execution_order": samples,
            "median_ns": statistics.median(samples),
            "mean_ns": statistics.mean(samples), "minimum_ns": min(samples),
            "maximum_ns": max(samples),
            "before_full_oracle_max_abs_error": row["oracle_before_maxabs"],
            "after_full_oracle_max_abs_error": row["oracle_after_maxabs"],
            "checked_elements_each": row["oracle_elements_each"],
            "oracle_passed": row["oracle_passed"]})
    pairs = []
    for old, new in ((0, 1), (3, 2)):
        pairs.append({"old_process_index": old, "new_process_index": new,
            "median_candidate_relative_change":
                processes[new]["median_ns"] / processes[old]["median_ns"] - 1,
            "mean_candidate_relative_change":
                processes[new]["mean_ns"] / processes[old]["mean_ns"] - 1})
    old_space = space["results"]["baseline"]["json_rows"][0]
    new_space = space["results"]["candidate"]["json_rows"][0]
    preflight = read(RAW / "preflight-identities.json")
    built = read(RAW / "built-identities.json")
    summary = {
        "status": "Fixed space and sole ABBA latency complete; no further compilation or measurement",
        "scope": "Current ordinary typed Apple attention, same native MLX SDK, old vs frozen Q128 checked-owner candidate; one fixed input, not peer ranking or all-shape precision validation",
        "fixed_point": read(ROOT / "design.json")["fixed_parameters"],
        "actual_hardware_toolchain": "Mac16,12 Air; Apple M4 8-GPU-core,16GiB RAM; macOS27.0.1(26A434), arm64; Apple clang21.0.0(2100.3.34.2),SDK27.0; full raw hardware-toolchain.stdout.txt retained",
        "build": {"fresh_consumer_TUs": 1, "successful_links": 2,
            "product_or_native_TU_recompiled": False, "sdk_copied_or_rebuilt": False,
            "source": preflight["source"], "cached8_host_objects": preflight["cached_host_objects"],
            "built_artifacts_and_maps": built,
            "limit": "Native archives reused at recorded exact paths; their sizes were rechecked, not all SDK archive payloads rehashed. Eight small host objects and executable/object/maps have actual SHA identities."},
        "original_loader_failures": {
            "count": 2, "results": initial["results"],
            "stderr": "Failed to load the default metallib. library not found library not found library not found library not found",
            "not_measurements": "Both exit4 occurred before GPU computation, oracle or memory sampling; preserve stdout/stderr/commands. No numerical or space conclusion from them.",
            "correction": read(RAW / "loader-fix.json"),
            "no_binary_input_budget_change_or_recompile": True},
        "valid_space_processes": 2,
        "space_old": old_space, "space_candidate": new_space,
        "space_extra_peak_reduction_fraction": 1 -
            new_space["peak_minus_active_before"] / old_space["peak_minus_active_before"],
        "memory_interpretation": "Logical caller ports41,964,033B and output4,202,496B reported separately. MLX peak minus prepared/bound live baseline includes output/private/transient native allocations; not total VRAM, allocator reserve or proof of one-block hard cap. Metrics sampled with output lease alive; cache cleared and peak reset only once before the one cold submission, never between chunks.",
        "latency": {"order": ["old", "new", "new", "old"],
            "total_processes": 4, "total_timed_samples": 36,
            "per_process_submissions": "2warm +1untimed full oracle +9timed +1untimed full oracle =13",
            "interval": "submit through checked wait return; excludes result/lease destruction and complete oracle; setup/prepare/bind outside",
            "processes": processes, "adjacent_order_pairs": pairs,
            "no_AA_retry_filtering_pooling_or_extra_shape": True},
        "precision_boundary": "Both one-shot space outputs and all eight before/after latency full-output checks pass unchanged abs2e-6+rel6e-6 against the FP64 prefix-mean formula, each over1,050,624 elements. This QK0/no-channel-bias fixed space input differs from the preserved nonzero-QK/channel-bias stress failure; no stress input/tolerance was changed and that failure is not called passed.",
        "tradeoff": "Measured extra active peak drops72.8450%; candidate adjacent-pair means increase1.2323%/2.6266%, medians2.7703%/4.2107%. Keep all36 samples and overlap/drift; this is a space/time tradeoff at one fixed point, not free speedup, statistically universal regression or tokens/s evidence.",
        "failed_stress_reference": "../summary.json and ../diagnostic/ remain separate evidence; frozen candidate source in ../candidate and identities in ../frozen-source-sha256.json",
        "canonical_product_or_README_modified_by_this_measurement": False,
        "cleanup": "All three new executable/object files retained for now at root instruction; cleanup-candidates.json is identity only, not deletion authorization. No test.ps1 or cleanup executed."
    }
    (ROOT / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")
    cleanup = read(RAW / "cleanup-candidates.json")
    cleanup["disposition"] = "Retain these3 files for current consistent cache; future explicit root cleanup only"
    cleanup["loader_link_retained"] = read(ROOT / "auxiliary-identities.json")["loader_link"]
    cleanup["generated_python_bytecode"] = read(ROOT / "auxiliary-identities.json")["known_generated_python_cache"]
    (ROOT / "cleanup-candidates.json").write_text(json.dumps(cleanup, indent=2) + "\n")
    files = sorted((p for p in ROOT.rglob("*") if p.is_file()
                    and p.name not in {"source-results.zip", "archive-identity.json", "package-manifest.json"}
                    and "__pycache__" not in p.parts),
                   key=lambda p: p.relative_to(ROOT).as_posix())
    manifest = {"files": [record(p) for p in files],
                "no_executables_objects_libraries_or_SDK": True}
    (ROOT / "package-manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
    files.append(ROOT / "package-manifest.json")
    archive = ROOT / "source-results.zip"
    with zipfile.ZipFile(archive, "w", zipfile.ZIP_DEFLATED) as zipped:
        for p in files:
            zipped.write(p, p.relative_to(ROOT).as_posix())
    archive_identity = record(archive)
    archive_identity["file_count"] = len(files)
    (ROOT / "archive-identity.json").write_text(json.dumps(archive_identity, indent=2) + "\n")
    print(json.dumps({"archive": archive_identity, "summary": record(ROOT / "summary.json"),
                      "cleanup": cleanup}, indent=2))


if __name__ == "__main__":
    main()
