from pathlib import Path
import json
import os

from run_space_remote import LOG, PLAN, ROOT, command, identity

expected = json.loads((LOG / "built-identities.json").read_text())
for entry in expected["artifacts"]:
    if identity(entry["path"]) != entry:
        raise RuntimeError("Existing measured executable/object identity changed")

metallib = ROOT / "mlx.metallib"
if os.path.lexists(metallib):
    raise RuntimeError("Refusing to replace existing measurement/mlx.metallib")
sdk_metallib = Path(PLAN["native_libraries"][-1]).parent / "mlx.metallib"
if not sdk_metallib.is_file():
    raise RuntimeError("Original SDK metallib missing")
metallib.symlink_to(sdk_metallib)
if metallib.resolve(strict=True) != sdk_metallib.resolve(strict=True):
    raise RuntimeError("New symlink did not resolve to original SDK metallib")
(LOG / "loader-fix.json").write_text(json.dumps({
    "reason": "Both original processes failed before measurement while loading default metallib",
    "previous_loader_failures_preserved": 2,
    "link": str(metallib), "target": str(metallib.resolve(strict=True)),
    "no_library_copy_or_rebuild": True, "cwd_after_fix": str(ROOT),
    "no_input_budget_or_binary_change": True}, indent=2) + "\n")
PLAN["cwd"] = str(ROOT)
results = {}
for arm in ("baseline", "candidate"):
    tag = arm + "-space-loader-fixed"
    code = command(tag, [str(ROOT / arm), "--space"], timeout=180)
    lines = (LOG / (tag + ".stdout.txt")).read_text(errors="replace").splitlines()
    rows = [json.loads(line) for line in lines if line.startswith("{")]
    valid = code == 0 and len(rows) == 1 and rows[0].get("mode") == "space" and \
        rows[0].get("checked_elements") == 1050624 and \
        rows[0].get("oracle_passed") is True
    results[arm] = {"exit": code, "json_rows": rows, "valid_space_process": valid}
    if not valid:
        break
(LOG / "loader-fixed-space-summary.json").write_text(json.dumps({
    "process_order": list(results), "results": results,
    "valid_space_processes": sum(v["valid_space_process"] for v in results.values()),
    "original_loader_failures": 2, "compile_or_link_repeated": False,
    "latency_or_additional_shape_run": False}, indent=2) + "\n")
