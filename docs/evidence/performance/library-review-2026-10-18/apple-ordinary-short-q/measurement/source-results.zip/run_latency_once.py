import json
import sys

from run_space_remote import LOG, PLAN, ROOT, command, identity

if sys.argv[1:]:
    raise SystemExit("No options: only the approved fixed old,new,new,old run.")
expected = json.loads((LOG / "built-identities.json").read_text())
for entry in expected["artifacts"]:
    if identity(entry["path"]) != entry:
        raise RuntimeError("Original measured executable/object identity changed")
loader = json.loads((LOG / "loader-fix.json").read_text())
if str((ROOT / "mlx.metallib").resolve(strict=True)) != loader["target"]:
    raise RuntimeError("Metallib selection changed")
PLAN["cwd"] = str(ROOT)
results = []
for index, arm in enumerate(("baseline", "candidate", "candidate", "baseline")):
    tag = "latency-" + str(index) + "-" + arm
    code = command(tag, [str(ROOT / arm), "--latency"], timeout=180)
    lines = (LOG / (tag + ".stdout.txt")).read_text(errors="replace").splitlines()
    rows = [json.loads(line) for line in lines if line.startswith("{")]
    passed = code == 0 and len(rows) == 1 and rows[0].get("mode") == "latency" \
        and rows[0].get("oracle_passed") is True \
        and rows[0].get("oracle_elements_each") == 1050624 \
        and len(rows[0].get("timed_submit_checkedwait_ns", [])) == 9
    results.append({"index": index, "arm": arm, "exit": code,
                    "json_rows": rows, "passed": passed})
    if not passed:
        break
(LOG / "latency-once-summary.json").write_text(json.dumps({
    "planned_order": ["baseline", "candidate", "candidate", "baseline"],
    "results": results, "no_retries_or_AA": True,
    "all_samples_preserved": True, "recompile_or_relink": False}, indent=2) + "\n")
