from pathlib import Path
import hashlib
import json
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
SDK = Path('/Users/kiro/hyle-scratch/g09-air-direct-20261017/final-1dbfce9a0/apple-sdk')
CORE = Path('/Users/kiro/hyle-scratch/compute-unified/a-cpu-apple/selected-graph/source-build')
Q128 = ROOT.parent / 'library-review-20261018-apple-sink-q128'
FORCE = ROOT.parent / 'library-review-20261018-apple-force-scale'
GTEST = Path('/Users/kiro/Library/Caches/hyle/dependencies/v1/sources/googletest-063de7e9578f-162765170ae6/googletest/include')

FLAGS = ['-O3', '-DNDEBUG', '-std=c++23', '-arch', 'arm64', '-DHYLE_STATIC',
         '-DMLX_STATIC', '-DHYLE_COMPUTE_APPLE=1', '-DHYLE_COMPUTE_ROUTE_APPLE_API=',
         '-DHYLE_GRAPH_ROUTE_APPLE_API=', '-Wall', '-Wextra', '-Wpedantic', '-Werror']
INCLUDES = ['-I' + str(ROOT / 'candidate/include'), '-I' + str(ROOT / 'common/include'),
            '-I' + str(ROOT / 'common/src/compute_route_apple'),
            '-I' + str(ROOT / 'common/src/compute'),
            '-I' + str(ROOT / 'common/src/graph_route_apple'),
            '-I' + str(ROOT / 'common/tests/compute_route_apple'), '-I' + str(ROOT / 'common'),
            '-isystem', str(SDK / 'include'), '-isystem', str(SDK / 'include/metal_cpp'),
            '-isystem', str(GTEST)]
LIBS = [SDK / 'lib' / ('lib' + name + '.a') for name in [
    'hyle_graph', 'hyle_compute_route_apple', 'hyle_compute_stream',
    'hyle_compute_state', 'hyle_compute_batch', 'hyle_compute', 'hyle_compute_ops',
    'hyle_simd', 'hyle_sched', 'hyle_container', 'hyle_mem_vm', 'hyle_mem',
    'mimalloc_static', 'hyle_platform_thread', 'hyle_time', 'hyle_platform',
    'hyle_error', 'hyle_compute_provider_ggml_metal', 'hyle_compute_ggml_runtime',
    'ggml', 'ggml-metal', 'ggml-base', 'mlx']]
FRAMEWORKS = ['-framework', 'Foundation', '-framework', 'Metal',
              '-framework', 'MetalKit', '-framework', 'QuartzCore']
BASELINE = [Q128 / 'candidate-context.o', Q128 / 'candidate-operations.o',
            FORCE / 'apple_tensor.o', Q128 / 'candidate-graph.o']
PRODUCTS = [('context', 'src/compute_route_apple/apple_context.cc'),
            ('operations', 'src/compute_route_apple/apple_operations.cc'),
            ('tensor', 'src/compute_route_apple/apple_tensor.cc'),
            ('graph', 'src/graph_route_apple/apple_lowering.cc')]


def record(path):
    return {'path': str(path), 'bytes': path.stat().st_size,
            'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}


def run(tag, command, required=True):
    command = list(map(str, command))
    original = tag
    attempt = 1
    while (ROOT / (tag + '-command.json')).exists():
        attempt += 1
        tag = original + '-attempt' + str(attempt)
    try:
        result = subprocess.run(command, cwd=ROOT, capture_output=True, timeout=180)
        code, out, err = result.returncode, result.stdout, result.stderr
    except subprocess.TimeoutExpired as error:
        code, out, err = -999, error.stdout or b'', error.stderr or b''
    (ROOT / (tag + '-command.json')).write_text(json.dumps(
        {'argv': command, 'cwd': str(ROOT), 'exit': code}, indent=2) + '\n', encoding='utf-8')
    (ROOT / (tag + '.stdout.txt')).write_bytes(out)
    (ROOT / (tag + '.stderr.txt')).write_bytes(err)
    print(tag, code, flush=True)
    if code and required:
        print(out.decode(errors='replace'), flush=True)
        print(err.decode(errors='replace'), flush=True)
        raise SystemExit(code)
    return code


def main():
    if sys.argv[1:] != ['--functional']:
        raise SystemExit('Only --functional is implemented; no space/latency execution.')
    expected = json.loads((ROOT / 'expected-inputs.json').read_text(encoding='utf-8'))
    for entry in expected['retained_used']:
        actual = record(Path(entry['path']))
        assert actual['bytes'] == entry['bytes'] and actual['sha256'] == entry['sha256'], actual
    for entry in expected['staged_sources']:
        actual = record(ROOT / entry['path'])
        assert actual['sha256'] == entry['sha256'], actual
    for path in LIBS + [CORE / 'lib/libgtest.a', CORE / 'lib/libgtest_main.a']:
        assert path.is_file(), path
    if not (ROOT / 'mlx.metallib').exists():
        (ROOT / 'mlx.metallib').symlink_to(SDK / 'lib/mlx.metallib')
    for name, source in PRODUCTS:
        run('candidate-' + name + '-compile', ['/usr/bin/clang++', *FLAGS, *INCLUDES,
            '-c', ROOT / 'candidate' / source, '-o', ROOT / ('candidate-' + name + '.o')])
    for name, source in [('attention-tests', 'tests/compute_route_apple/attention_test.cc'),
                         ('graph-tests', 'tests/graph_route_apple/tensor_test.cc')]:
        run(name + '-compile', ['/usr/bin/clang++', *FLAGS, *INCLUDES,
            '-c', ROOT / 'candidate' / source, '-o', ROOT / (name + '.o')])
    for arm, host in [('baseline', BASELINE),
                     ('candidate', [ROOT / ('candidate-' + name + '.o') for name, _ in PRODUCTS])]:
        for kind, objects in [('direct-tests', [ROOT / 'attention-tests.o', Q128 / 'applied-direct.o']),
                              ('graph-tests', [ROOT / 'graph-tests.o'])]:
            run(arm + '-' + kind + '-link', ['/usr/bin/clang++', '-O3', '-std=c++23',
                '-o', ROOT / (arm + '-' + kind), *objects, *host, *LIBS,
                CORE / 'lib/libgtest_main.a', CORE / 'lib/libgtest.a', *FRAMEWORKS,
                '-Wl,-map,' + str(ROOT / (arm + '-' + kind + '.map'))])
    products = [ROOT / ('candidate-' + name + '.o') for name, _ in PRODUCTS]
    products += [ROOT / (name + '.o') for name in ['attention-tests', 'graph-tests']]
    products += [ROOT / (arm + '-' + kind) for arm in ['baseline', 'candidate']
                 for kind in ['direct-tests', 'graph-tests']]
    (ROOT / 'runtime-identities.json').write_text(json.dumps({
        'fresh_products': [record(p) for p in products],
        'reused_baseline': [record(p) for p in BASELINE],
        'reused_sink_direct_test': record(Q128 / 'applied-direct.o'),
        'SDK_rebuilt': False, 'native_overlay': False}, indent=2) + '\n', encoding='utf-8')
    filters = [
        ('direct-tests', 'AppleAttention.CheckedShortQueryMathKeepsMasksTailAndReboundOwners:'
         'AppleAttention.MathQueryBlocksRetainBroadcastMasksAndReboundOwners:'
         'AppleSinkAttention.QBlocksKeepMasksSinksRebindingAndOwners:'
         'AppleSinkAttention.ShortQueriesRetainExistingFallback', 4),
        ('graph-tests', 'AppleGraph.PublishedShortQueryMathAndNegativeCrossCheckedBoundary:'
         'AppleSinkGraph.PublishedCopySinkAndNegativeCrossPrivateBoundary', 2)]
    gate = {'status': 'functional_only_no_space_or_latency', 'runs': []}
    for arm in ['baseline', 'candidate']:
        for kind, pattern, count in filters:
            tag = arm + '-' + kind
            code = run(tag, [ROOT / tag, '--gtest_filter=' + pattern,
                '--gtest_throw_on_failure', '--gtest_fail_fast',
                '--gtest_output=json:' + str(ROOT / (tag + '.json'))], required=False)
            data = json.loads((ROOT / (tag + '.json')).read_text(encoding='utf-8')) if (
                ROOT / (tag + '.json')).exists() else {}
            passed = code == 0 and data.get('tests') == count and data.get('failures') == 0
            gate['runs'].append({'name': tag, 'exit': code, 'expected_tests': count,
                                 'actual_tests': data.get('tests'), 'failures': data.get('failures'),
                                 'passed': passed})
            gate['passed'] = all(r['passed'] for r in gate['runs'])
            (ROOT / 'functional-gate.json').write_text(json.dumps(gate, indent=2) + '\n', encoding='utf-8')
            if not passed:
                raise SystemExit(3)


if __name__ == '__main__':
    main()
