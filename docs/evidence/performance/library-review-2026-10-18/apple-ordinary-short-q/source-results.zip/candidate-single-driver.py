from pathlib import Path
import json,subprocess,sys
root=Path('/Users/kiro/hyle-scratch/compute-unified/library-review-20261018-apple-ordinary-short-q')
tag='candidate-single-direct'
cmd=[str(root/'candidate-direct-tests'),'--gtest_filter=AppleAttention.CheckedShortQueryMathKeepsMasksTailAndReboundOwners','--gtest_throw_on_failure','--gtest_fail_fast','--gtest_output=json:'+str(root/(tag+'.json'))]
assert not (root/(tag+'-command.json')).exists()
try:
 p=subprocess.run(cmd,cwd=root,capture_output=True,timeout=180)
 code,out,err=p.returncode,p.stdout,p.stderr
except subprocess.TimeoutExpired as e:
 code,out,err=-999,e.stdout or b'',e.stderr or b''
(root/(tag+'-command.json')).write_text(json.dumps({'argv':cmd,'cwd':str(root),'exit':code,'single_existing_test_only':True},indent=2)+'\n',encoding='utf-8')
(root/(tag+'.stdout.txt')).write_bytes(out);(root/(tag+'.stderr.txt')).write_bytes(err)
print('candidate-single-direct',code,flush=True)
print(out.decode(errors='replace'),flush=True);print(err.decode(errors='replace'),flush=True)
raise SystemExit(0 if code==0 else 3)
