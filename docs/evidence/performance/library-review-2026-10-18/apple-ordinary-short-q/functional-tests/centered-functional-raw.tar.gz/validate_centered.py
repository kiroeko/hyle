from pathlib import Path
import hashlib
import json
import subprocess

ROOT = Path(__file__).resolve().parent
STRESS = ROOT.parent
SDK = Path('/Users/kiro/hyle-scratch/g09-air-direct-20261017/final-1dbfce9a0/apple-sdk')
CORE = Path('/Users/kiro/hyle-scratch/compute-unified/a-cpu-apple/selected-graph/source-build')
GTEST = Path('/Users/kiro/Library/Caches/hyle/dependencies/v1/sources/googletest-063de7e9578f-162765170ae6/googletest/include')
FLAGS = ['-O3', '-DNDEBUG', '-std=c++23', '-arch', 'arm64', '-DHYLE_STATIC',
         '-DMLX_STATIC', '-DHYLE_COMPUTE_APPLE=1', '-DHYLE_COMPUTE_ROUTE_APPLE_API=',
         '-DHYLE_GRAPH_ROUTE_APPLE_API=', '-Wall', '-Wextra', '-Wpedantic', '-Werror']
INCLUDES = ['-I' + str(STRESS / 'candidate/include'), '-I' + str(STRESS / 'common/include'),
            '-I' + str(STRESS / 'common/src/compute_route_apple'),
            '-I' + str(STRESS / 'common/src/compute'),
            '-I' + str(STRESS / 'common/src/graph_route_apple'),
            '-I' + str(ROOT / 'tests/compute_route_apple'), '-I' + str(STRESS / 'common'),
            '-isystem', str(SDK / 'include'), '-isystem', str(SDK / 'include/metal_cpp'),
            '-isystem', str(GTEST)]
LIBS = [SDK / 'lib' / ('lib' + name + '.a') for name in [
    'hyle_graph', 'hyle_compute_route_apple', 'hyle_compute_stream',
    'hyle_compute_state', 'hyle_compute_batch', 'hyle_compute', 'hyle_compute_ops',
    'hyle_simd', 'hyle_sched', 'hyle_container', 'hyle_mem_vm', 'hyle_mem',
    'mimalloc_static', 'hyle_platform_thread', 'hyle_time', 'hyle_platform',
    'hyle_error', 'hyle_compute_provider_ggml_metal', 'hyle_compute_ggml_runtime',
    'ggml', 'ggml-metal', 'ggml-base', 'mlx']]
LIBS += [CORE / 'lib/libgtest_main.a', CORE / 'lib/libgtest.a']
FRAMEWORKS = ['-framework', 'Foundation', '-framework', 'Metal',
              '-framework', 'MetalKit', '-framework', 'QuartzCore']
PATTERN = ':'.join([
    'AppleAttention.CenteredShortQueryMathKeepsMasksTailAndReboundOwners',
    'AppleGraph.PublishedCenteredShortQueryMathAndNegativeCrossCheckedBoundary',
    'AppleSinkAttention.QBlocksKeepMasksSinksRebindingAndOwners',
    'AppleSinkAttention.ShortQueriesRetainExistingFallback',
    'AppleSinkGraph.PublishedCopySinkAndNegativeCrossPrivateBoundary',
    'AppleAttention.MathQueryBlocksRetainBroadcastMasksAndReboundOwners'])


def record(path):
    return dict(path=str(path), bytes=path.stat().st_size,
                sha256=hashlib.sha256(path.read_bytes()).hexdigest())


def save(name, value):
    (ROOT / name).write_text(json.dumps(value, indent=2) + '\n')


def run(tag, command):
    assert not (ROOT / (tag + '-command.json')).exists(), 'No overwritten attempts'
    command = list(map(str, command))
    result = subprocess.run(command, cwd=ROOT, capture_output=True, timeout=180)
    save(tag + '-command.json', dict(argv=command, cwd=str(ROOT), exit=result.returncode))
    (ROOT / (tag + '.stdout.txt')).write_bytes(result.stdout)
    (ROOT / (tag + '.stderr.txt')).write_bytes(result.stderr)
    print(tag, result.returncode, flush=True)
    if result.returncode:
        print(result.stdout.decode(errors='replace')[-5000:], flush=True)
        print(result.stderr.decode(errors='replace')[-5000:], flush=True)
        raise RuntimeError('Stopped at failed command: ' + tag)


expected = json.loads((ROOT / 'expected-inputs.json').read_text())
assert not (ROOT / 'runtime-identities.json').exists(), 'Validation already started/completed'
for entry in expected['retained_objects'] + expected['product_sources']:
    actual = record(Path(entry['path']))
    assert actual['bytes'] == entry['bytes'] and actual['sha256'] == entry['sha256'], actual
for entry in expected['staged_sources']:
    actual = record(ROOT / entry['path'])
    assert actual['bytes'] == entry['bytes'] and actual['sha256'] == entry['sha256'], actual

# Both new test TUs and the adjacent original Sink helper include this exact
# physical header. Reuse the existing half-test source through one directory link.
half = ROOT / 'tests/compute_provider_native'
half.symlink_to(STRESS / 'common/tests/compute_provider_native', target_is_directory=True)
assert (half / 'half_test_support.h').resolve().is_file()
metallib = ROOT / 'mlx.metallib'
metallib.symlink_to(SDK / 'lib/mlx.metallib')
assert metallib.resolve() == (SDK / 'lib/mlx.metallib').resolve()

run('compiler', ['/usr/bin/clang++', '--version'])
run('hardware', ['/usr/sbin/sysctl', 'hw.model', 'hw.memsize'])
objects = [ROOT / 'centered-attention.o', ROOT / 'centered-graph.o']
baseline = [Path(path) for path in expected['baseline_objects']]
candidate = [Path(path) for path in expected['candidate_objects']]
sink_direct = Path(expected['sink_direct_object'])
artifacts = objects + [ROOT / 'baseline-centered-tests', ROOT / 'candidate-centered-tests']
identity = dict(reused_objects=expected['retained_objects'],
                product_sources=expected['product_sources'],
                staged_sources=expected['staged_sources'],
                libraries=[record(path) for path in LIBS],
                half_helper=record(half / 'half_test_support.h'),
                metallib=dict(path=str(metallib), symlink_target=str(metallib.resolve())),
                fresh_product_TUs=0, fresh_test_TUs=2,
                original_stress='Not changed or rerun; centered input is an additional functional fixture, not a reclassification of the original failure.')
save('runtime-identities.json', identity)
gate = dict(status='functional_only_not_timing', filter=PATTERN, expected_tests_per_process=6, runs=[])
try:
    for name, source, obj in [
        ('compile-attention', 'tests/compute_route_apple/attention_test.cc', objects[0]),
        ('compile-graph', 'tests/graph_route_apple/tensor_test.cc', objects[1])]:
        run(name, ['/usr/bin/clang++', *FLAGS, *INCLUDES, '-c', ROOT / source, '-o', obj])
    for arm, host in [('baseline', baseline), ('candidate', candidate)]:
        run('link-' + arm, ['/usr/bin/clang++', '-O3', '-std=c++23', '-o',
            ROOT / (arm + '-centered-tests'), *objects, sink_direct, *host,
            *LIBS, *FRAMEWORKS, '-Wl,-map,' + str(ROOT / (arm + '-centered-tests.map'))])
        content = (ROOT / (arm + '-centered-tests.map')).read_text()
        assert all(str(path) in content for path in host + objects + [sink_direct])
        assert str(SDK / 'lib/libmlx.a') in content
    identity['fresh_artifacts'] = [record(path) for path in artifacts]
    save('runtime-identities.json', identity)
    for arm in ['baseline', 'candidate']:
        run('run-' + arm, [ROOT / (arm + '-centered-tests'), '--gtest_filter=' + PATTERN,
            '--gtest_throw_on_failure', '--gtest_fail_fast',
            '--gtest_output=json:' + str(ROOT / (arm + '-centered-tests.json'))])
        result = json.loads((ROOT / (arm + '-centered-tests.json')).read_text())
        assert result.get('tests') == 6 and result.get('failures') == 0 and result.get('errors') == 0, result
        gate['runs'].append(dict(arm=arm, tests=result['tests'], failures=0, time=result['time']))
        save('functional-gate.json', gate)
    gate['passed'] = True
    save('functional-gate.json', gate)
finally:
    present = [record(path) for path in artifacts if path.is_file()]
    save('cleanup-candidates.json', dict(host='kiro@172.22.10.198', files=present,
        total_bytes=sum(item['bytes'] for item in present),
        note='Only two fresh test objects and two fresh combined executables; not deleted. Maps/source/log/raw and all reused product/native/SDK/cache objects remain.'))
