from pathlib import Path
import hashlib,json,subprocess

OUT=Path(__file__).resolve().parent
Q128=OUT.parent/'library-review-20261018-apple-sink-q128'
BLOCKS=OUT.parent/'library-review-20261018-sdpa-blocks'
SDK=Path('/Users/kiro/hyle-scratch/g09-air-direct-20261017/final-1dbfce9a0/apple-sdk')
CORE=Path('/Users/kiro/hyle-scratch/compute-unified/a-cpu-apple/selected-graph/source-build')
GTEST=Path('/Users/kiro/Library/Caches/hyle/dependencies/v1/sources/googletest-063de7e9578f-162765170ae6/googletest/include')
flags=['-O3','-DNDEBUG','-std=c++23','-arch','arm64','-DHYLE_STATIC','-DMLX_STATIC','-DHYLE_COMPUTE_APPLE=1',
    '-DHYLE_COMPUTE_ROUTE_APPLE_API=','-DHYLE_GRAPH_ROUTE_APPLE_API=',
    '-Wall','-Wextra','-Wpedantic','-Werror',
    '-I'+str(Q128/'candidate/include'),'-I'+str(Q128/'support/include'),
    '-I'+str(Q128/'support/src/compute_route_apple'),'-I'+str(Q128/'support/src/compute'),
    '-I'+str(Q128/'support/src/graph_route_apple'),
    '-I'+str(BLOCKS/'tests/compute_route_apple'),'-I'+str(BLOCKS),
    '-isystem',str(SDK/'include'),'-isystem',str(SDK/'include/metal_cpp'),'-isystem',str(GTEST)]
libs=[SDK/'lib'/('lib'+x+'.a') for x in ['hyle_graph','hyle_compute_route_apple','hyle_compute_stream',
    'hyle_compute_state','hyle_compute_batch','hyle_compute','hyle_compute_ops','hyle_simd','hyle_sched',
    'hyle_container','hyle_mem_vm','hyle_mem','mimalloc_static','hyle_platform_thread','hyle_time',
    'hyle_platform','hyle_error','hyle_compute_provider_ggml_metal','hyle_compute_ggml_runtime','ggml',
    'ggml-metal','ggml-base','mlx']]
host=[Q128/('candidate-'+x+'.o') for x in ['context','operations','graph']]
frameworks=['-framework','Foundation','-framework','Metal','-framework','MetalKit','-framework','QuartzCore']
def record(p):return dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def run(tag,cmd):
    cmd=list(map(str,cmd))
    if (OUT/(tag+'-command.json')).exists():
        if json.loads((OUT/(tag+'-command.json')).read_text())['exit']==0:return
        attempt=2
        while (OUT/(tag+'-attempt'+str(attempt)+'-command.json')).exists():attempt+=1
        tag+='-attempt'+str(attempt)
    p=subprocess.run(cmd,cwd=OUT,capture_output=True,timeout=120)
    (OUT/(tag+'-command.json')).write_text(json.dumps(dict(argv=cmd,cwd=str(OUT),exit=p.returncode),indent=2)+'\n')
    (OUT/(tag+'.stdout.txt')).write_bytes(p.stdout);(OUT/(tag+'.stderr.txt')).write_bytes(p.stderr)
    print(tag,p.returncode,flush=True)
    if p.returncode:
        print(p.stdout.decode(errors='replace'));print(p.stderr.decode(errors='replace'));raise SystemExit(p.returncode)

expected=json.loads((OUT/'expected-inputs.json').read_text())
for p in [OUT/'apple_tensor.measured.cc',OUT/'attention_test.cc',*host,*libs]:assert p.is_file(),p
for relative,name in [('tests/compute_route_apple/tensor_test_support.h','tensor_support'),
                       ('tests/compute_provider_native/half_test_support.h','half_support')]:
    assert record(BLOCKS/relative)['sha256']==expected[name],relative
if not (OUT/'mlx.metallib').exists():(OUT/'mlx.metallib').symlink_to(SDK/'lib/mlx.metallib')
run('machine',['/usr/sbin/sysctl','-n','hw.model','hw.memsize','machdep.cpu.brand_string'])
run('compiler',['/usr/bin/clang++','--version'])
run('compile-apple',['/usr/bin/clang++',*flags,'-c',OUT/'apple_tensor.measured.cc','-o',OUT/'apple_tensor.o'])
run('compile-tests',['/usr/bin/clang++',*flags,'-c',OUT/'attention_test.cc','-o',OUT/'attention_test.o'])
run('link-tests',['/usr/bin/clang++','-O3','-std=c++23','-o',OUT/'tests',OUT/'attention_test.o',
    *host,OUT/'apple_tensor.o',*libs,CORE/'lib/libgtest_main.a',CORE/'lib/libgtest.a',
    *frameworks,'-Wl,-map,'+str(OUT/'tests.map')])
maptext=(OUT/'tests.map').read_text()
assert 'apple_tensor.o' in maptext and 'candidate-context.o' in maptext
run('new-regression',[OUT/'tests','--gtest_filter=AppleAttention.ExtremeFiniteFloat32ScaleRetainsZeroScoreReference',
    '--gtest_output=json:'+str(OUT/'new-regression.json')])
sources=[OUT/'apple_tensor.measured.cc',OUT/'attention_test.cc']
artifacts=[OUT/x for x in ['apple_tensor.o','attention_test.o','tests','tests.map']]
(OUT/'runtime-identities.json').write_text(json.dumps(dict(
    fresh_sources=[record(p) for p in sources],reused_current_q128_host=[record(p) for p in host],
    artifacts=[record(p) for p in artifacts],
    SDK_inputs=[record(p) for p in libs],
    support_headers=[record(BLOCKS/'tests/compute_route_apple/tensor_test_support.h'),
        record(BLOCKS/'tests/compute_provider_native/half_test_support.h'),
        *[record(OUT/('apple_mature_'+x+'.h')) for x in ['indexing','artifact','reduction']]],
    native_host_overlay=False,native_shader_rebuilt=False,SDK_copied=False),indent=2)+'\n')
(OUT/'cleanup-candidates.json').write_text(json.dumps(dict(host='MacBookAir',files=[record(p) for p in artifacts],
    total_bytes=sum(p.stat().st_size for p in artifacts),
    retention='apple_tensor.o may still be needed by Q128 final consumers; root decides cleanup after that use.',
    note='Only4 rebuildable artifacts from this batch. The mlx.metallib entry is a symlink to original SDK and is not included. No deletion performed.'),indent=2)+'\n')
