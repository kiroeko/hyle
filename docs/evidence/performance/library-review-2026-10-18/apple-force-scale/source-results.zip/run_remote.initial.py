from pathlib import Path
import hashlib,json,subprocess
ROOT=Path(__file__).resolve().parents[4]
HERE=Path(__file__).resolve().parent
HOST='kiro@172.22.10.198'
REMOTE='/Users/kiro/hyle-scratch/compute-unified/library-review-20261018-apple-force-scale'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
assert (ROOT/'src/compute_route_apple/apple_tensor.cc').read_text()==(HERE/'apple_tensor.candidate.cc').read_text()
(HERE/'apple_tensor.measured.cc').write_bytes((ROOT/'src/compute_route_apple/apple_tensor.cc').read_bytes())
(HERE/'attention_test.cc').write_bytes((ROOT/'tests/compute_route_apple/attention_test.cc').read_bytes())
(HERE/'expected-inputs.json').write_text(json.dumps(dict(
    tensor_support=sha(ROOT/'tests/compute_route_apple/tensor_test_support.h'),
    half_support=sha(ROOT/'tests/compute_provider_native/half_test_support.h')),indent=2)+'\n')
cmd=['ssh',HOST,'mkdir','-p',REMOTE]
subprocess.run(cmd,check=True)
for name in ['apple_tensor.measured.cc','attention_test.cc','expected-inputs.json','validate_remote.py']:
    subprocess.run(['scp',str(HERE/name),HOST+':'+REMOTE+'/'+name],check=True)
cmd=['ssh',HOST,'/usr/bin/python3',REMOTE+'/validate_remote.py']
p=subprocess.run(cmd,capture_output=True,timeout=240)
(HERE/'remote-run-command.json').write_text(json.dumps(dict(argv=cmd,exit=p.returncode),indent=2)+'\n')
(HERE/'remote-run.stdout.txt').write_bytes(p.stdout);(HERE/'remote-run.stderr.txt').write_bytes(p.stderr)
print(p.stdout.decode(errors='replace'));print(p.stderr.decode(errors='replace'))
raise SystemExit(p.returncode)
