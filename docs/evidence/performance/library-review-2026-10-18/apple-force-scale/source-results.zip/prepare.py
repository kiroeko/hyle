from pathlib import Path
import difflib,hashlib,json

ROOT=Path('/mnt/c/public/project-hyle/hyle')
HERE=ROOT/'.scratch/perf-review-2026-10-18/apple-force-scale'
source=ROOT/'src/compute_route_apple/apple_tensor.cc'
before=source.read_text()
needle='''       (query.dtype() == mx::float32 &&
        (query.shape(3) == 192 ||'''
replacement='''       (query.dtype() == mx::float32 &&
        // Keep the existing route if converting scale to log2 would overflow.
        std::abs(static_cast<double>(attention.scale)) *
                static_cast<double>(1.4426950408889634F) <=
            static_cast<double>(std::numeric_limits<float>::max()) &&
        (query.shape(3) == 192 ||'''
assert before.count(needle)==1
after=before.replace(needle,replacement)
(HERE/'apple_tensor.before.cc').write_bytes(source.read_bytes())
# Preserve the canonical source's line-ending style in the candidate.
newline=b'\r\n' if b'\r\n' in source.read_bytes() else b'\n'
(HERE/'apple_tensor.candidate.cc').write_bytes(after.replace('\n',newline.decode()).encode())
(HERE/'force-scale.diff').write_text(''.join(difflib.unified_diff(before.splitlines(keepends=True),after.splitlines(keepends=True),
    fromfile='a/src/compute_route_apple/apple_tensor.cc',tofile='b/src/compute_route_apple/apple_tensor.cc')))
def record(p):return dict(path=str(p.relative_to(ROOT)),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
review=dict(status='Scratchproposal only; no canonical edits, compilation, device execution or precision result.',
    change='One cold log2-scale representability condition inside the newly added F32 force clause. Half/BF16 OR branch untouched; schema and defaultnative admission unchanged.',
    guard='Promote the actualfloatlog2e constant and finitefloat scale to double before checking against FLT_MAX; host double product cannot overflow for float operands. Conservative guard does not promise every QK result remains representable.',
    fallback='For extreme scales, force_fused=false. Q9 leaves chunk_attention_math off and existing native heuristic selects the preexisting math fallback. LargerQ can still choose the preexisting bounded mathblocks path.',
    regression=dict(placement='Paste snippet within the existing attention_test.cc anonymous namespace; do not overwrite concurrent Q128 tests.',
        shapes=['F32 B1/H2/Hkv1/Q9/K17/D192 noncausal/no mask','F32 B1/H2/Hkv1/Q9/K17/D256 bottomrightcausal/no mask'],
        scales=['+FLT_MAX','-FLT_MAX'],
        oracle='Exact zero Q/K, exactF32 binaryfraction V varying by key/channel. Uniform visible-key/prefix means accumulated in FP64. Existing expect() rel6e-6+abs2e-6 unchanged, outputF32 asserted.',
        prior_behavior='Source-level risk only. No claim that the old shader necessarily emits NaN; compiler reassociation and actual Metal behavior have not been tested.'),
    resource='Can merge with the otheragent final Q128 testTU and existing Apple native hostprojection/SDK. No shader, manifest, API or dependency change required.',
    files=[record(p) for p in [HERE/'apple_tensor.before.cc',HERE/'apple_tensor.candidate.cc',HERE/'force-scale.diff',HERE/'attention_test.snippet.cc']],
    canonical_tests_read=record(ROOT/'tests/compute_route_apple/attention_test.cc'),
    cleanup='No compiled artifacts; nothing to clean from this preparation.')
(HERE/'review.json').write_text(json.dumps(review,indent=2)+'\n')
print(json.dumps(review,indent=2))
