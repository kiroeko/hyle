from pathlib import Path
import difflib,hashlib,json,subprocess,zipfile

ROOT=Path(__file__).resolve().parents[3]
HERE=Path(__file__).resolve().parent
def record(p):return dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def write(name,data):(HERE/name).write_text(json.dumps(data,indent=2)+'\n')
runtime=json.loads((HERE/'measured/runtime-identities.json').read_text())
for p in runtime['fresh_sources']:
    assert record(HERE/Path(p['path']).name)['sha256']==p['sha256']
test=json.loads((HERE/'measured/new-regression.json').read_text())
assert test['tests']==1 and test['failures']==0 and test['errors']==0
assert (ROOT/'src/compute_route_apple/apple_tensor.cc').read_bytes()==(HERE/'apple_tensor.measured.cc').read_bytes()
assert (ROOT/'tests/compute_route_apple/attention_test.cc').read_bytes()==(HERE/'attention_test.cc').read_bytes()
for source,dest in [('src/compute_route_apple/apple_tensor.cc','apple_tensor.applied.cc'),
                     ('tests/compute_route_apple/attention_test.cc','attention_test.applied.cc')]:
    (HERE/dest).write_bytes((ROOT/source).read_bytes())
diff=subprocess.check_output(['git','diff','--','src/compute_route_apple/apple_tensor.cc',
    'tests/compute_route_apple/attention_test.cc'],cwd=ROOT)
(HERE/'applied.diff').write_bytes(diff)
maplines=(HERE/'measured/tests.map').read_text().splitlines()
symbols=[x for x in maplines if 'apple_tensor.o' in x or
    ('[  5]' in x and ('12lower_tensor' in x or '15lower_attention' in x))]
assert any('[  5]' in x and '12lower_tensor' in x and not 'cold.' in x for x in symbols)
assert any('[  5]' in x and '15lower_attention' in x for x in symbols)
write('link-map-check.json',dict(lowerer_object_index=5,symbol_lines=symbols,
    note='Current lower_tensor/lower_attention symbols come from the fresh guard object, not the SDK archive lowerer.'))
cleanup=json.loads((HERE/'measured/cleanup-candidates.json').read_text())
write('cleanup-candidates.json',cleanup)
proposal=json.loads((HERE/'review.json').read_text())
proposal['status']='Original pre-implementation source proposal. Applied changes and actual test results are now in summary.json.'
write('review.json',proposal)
summary=dict(
    result='Applied a cold scale-range guard only to the newly forced ordinary F32 Steel domain. The one new regression passed all4 requested executions on the existing Apple SDK/current host closure.',
    head_at_packaging=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),
    source_risk=dict(schema='src/compute_ops/operation.cc:669 accepts anyfinite SDPA scale, including positive/negativeFLT_MAX.',
        kernel='Local compact steel_attention.sdk.h:175 computes float scale*M_LOG2E_F before its302-305 QK scaling. Extremefinite scale may overflow this factor at source IEEE evaluation order.',
        distinction='The compact candidate was rejected; ordinary F32 force shares the relevant scale calculation. No rawSink change was applied here. No baseline device execution or assertion that oldMetal necessarily producesNaN.'),
    fix=dict(file='src/compute_route_apple/apple_tensor.cc',
        guard='abs(double(scale))*double(actualfloatLOG2E)<=double(FLT_MAX)',
        scope='Only the F32 term of the force_fused condition. Extreme scales stop being forced; native selection/existingmathblocks remain available.',
        unchanged='Half/BF16 force term, schema, dtype, ordinary normal-scale selectors, masks, defaultnative domain, shaders/manifest/API/ABI and all other operation lowerings.',
        caveat='This guards log2-scale preconversion overflow only; it does not establish numerical equivalence for every extreme QK value or change precision budgets.'),
    regression=dict(name='AppleAttention.ExtremeFiniteFloat32ScaleRetainsZeroScoreReference',
        actual_gtest_tests=1,passed=1,operation_executions=4,
        cases=['F32 B1/H2/Hkv1/Q9/K17/D192 noncausal/none mask,+FLT_MAX',
            'sameD192 with-FLT_MAX','F32 B1/H2/Hkv1/Q9/K17/D256 bottomrightcausal/none mask,+FLT_MAX',
            'sameD256 with-FLT_MAX'],
        input='Q/K allzero. V varies bykey/channel usingexact F32 binaryfractions from-9/8 to9/8.',
        oracle='Independent FP64 mean of visiblekeys; D192all17, D256causalprefix9..17. Existingexpect() rounding/comparison unchanged, F32 output dtype asserted.',
        original_budget='F32 rel6e-6+abs2e-6',expected_elements_compared=16128,
        measured_result='measured/new-regression.json and stdout/stderr',
        no_baseline_or_other_test_suite_or_timing=True),
    machine=dict(host='kiro@172.22.10.198 usingdefaultWindowsOpenSSHidentity',
        measured_model='Mac16,12',measured_chip='AppleM4',measured_memory_bytes=17179869184,
        compiler='Appleclang21.0.0 arm64-apple-darwin27.0.0; actual compilerstdout retained'),
    validation_closure=dict(fresh_TUs=['apple_tensor.measured.cc','attention_test.cc'],
        reused='Stablecurrent Q128candidate context/operations/graph hostobjects and originalSDK/foundationarchives. SDK inputs SHA recorded in measured/runtime-identities.json.',
        lowerer_object=runtime['artifacts'][0],
        Q128_reuse='Objectpath/SHA sent toQ128agent for itsfinalcanonical Direct/Graph tests; thisbatch did not rerunSinktests.',
        link_ownership='link-map-check.json confirms lower_tensor andlower_attention from freshobject[5].',
        no_nativehost_or_shader_source_build_or_sdk_copy_download=True,
        native_fallback='Q9 turns off querymathblocking. Guardprevents新增F32force so existingnative/mathfallback executes; source selection is not an instrumented dispatch counter.'),
    sources=dict(measured=[record(HERE/x) for x in ['apple_tensor.measured.cc','attention_test.cc']],
        applied=[record(HERE/x) for x in ['apple_tensor.applied.cc','attention_test.applied.cc']],
        measured_applied_byte_identical=True,source_diff='applied.diff'),
    failures=[dict(stage='Initial local preparation',
            result='Incorrect parents[4] resolvedROOTonelevelhigh; failedbeforeSSH/build. Correctedto[3]. Originalrunner and error note retained.'),
        dict(stage='First remotecompile',
            result='Missingexisting projectprivate apple_mature_indexing.h; preserve measured/compile-apple-command.json and stderr. Syncedonly3tinyexistingmature declarationheaders, thensame2TUclosure compiled successfully.')],
    limitations=['Only the new regression was run, no wholeApple/Graph/testmatrix or baseline numeric result.',
        'No performance, allocation-space or before/after speedclaim.',
        'Actual reference numerical checks passed for this finitefallback domain; no generalproof over all scales/inputs.'],
    cleanup=dict(manifest='cleanup-candidates.json',files=len(cleanup['files']),bytes=cleanup['total_bytes'],deleted=False,
        temporary_retention='Keep apple_tensor.o until Q128 finalconsumers finish; root handles precise cleanup.'))
write('summary.json',summary)
members=[p for p in sorted(HERE.rglob('*')) if p.is_file() and p.suffix in ('.cc','.h','.py','.json','.txt','.diff','.map') and p.name!='archive-record.json']
archive=HERE/'source-results.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for p in members:z.write(p,p.relative_to(HERE).as_posix())
with zipfile.ZipFile(archive) as z:assert z.testzip() is None
write('archive-record.json',dict(archive=record(archive),summary=record(HERE/'summary.json'),members=len(members),no_exe_obj_archive_library_or_sdk=True))
print(json.dumps(dict(summary=record(HERE/'summary.json'),archive=record(archive),members=len(members),
    cleanup_bytes=cleanup['total_bytes'],lowerer=runtime['artifacts'][0]),indent=2))
