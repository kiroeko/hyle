from pathlib import Path
import subprocess
HERE=Path(__file__).resolve().parent
REMOTE='/Users/kiro/hyle-scratch/compute-unified/library-review-20261018-apple-force-scale'
DEST=HERE/'measured';DEST.mkdir(exist_ok=True)
for pattern in ['*.json','*.stdout.txt','*.stderr.txt','tests.map']:
    subprocess.run(['scp','kiro@172.22.10.198:'+REMOTE+'/'+pattern,str(DEST)],check=True)
