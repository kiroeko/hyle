#include "hyle/sched/blocking.h"
#include <chrono>
#include <condition_variable>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <mutex>
#include <vector>
#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#include <windows.h>

namespace {
using namespace hyle::sched;
using hyle::mem::system_allocator;
void require(bool okay) { if (!okay) std::abort(); }
void sample(unsigned workers) {
  constexpr unsigned jobs = 8192;
  BlockingPool pool(system_allocator(), workers, std::chrono::seconds(60));
  std::mutex mutex;
  std::condition_variable ready;
  unsigned entered = 0;
  bool release = false;
  std::vector<JoinHandle<unsigned>> blockers, pending;
  blockers.reserve(workers); pending.reserve(jobs);
  for (unsigned i = 0; i < workers; ++i) {
    blockers.push_back(spawn_blocking(pool, system_allocator(), [&, i] {
      std::unique_lock lock(mutex);
      ++entered;
      ready.notify_all();
      ready.wait(lock, [&] { return release; });
      return i;
    }));
  }
  {
    std::unique_lock lock(mutex);
    require(ready.wait_for(lock, std::chrono::seconds(5), [&] { return entered == workers; }));
  }
  require(pool.live_threads() == workers && pool.retained_thread_handles() == workers);
  const auto begin = std::chrono::steady_clock::now();
  for (unsigned i = 0; i < jobs; ++i)
    pending.push_back(spawn_blocking(pool, system_allocator(), [i] { return i; }));
  const auto ns = std::chrono::duration<double, std::nano>(
      std::chrono::steady_clock::now() - begin).count();
  require(pool.live_threads() == workers && pool.retained_thread_handles() == workers);
  {
    std::lock_guard lock(mutex);
    release = true;
  }
  ready.notify_all();
  for (unsigned i = 0; i < workers; ++i) {
    auto result = blockers[i].join();
    require(result && *result == i);
  }
  std::uint64_t checksum = 0;
  for (unsigned i = 0; i < jobs; ++i) {
    auto result = pending[i].join();
    require(result && *result == i);
    checksum += *result;
  }
  require(checksum == std::uint64_t(jobs) * (jobs - 1) / 2);
  pool.shutdown();
  require(pool.live_threads() == 0 && pool.retained_thread_handles() == 0);
  std::printf("{\"workers\":%u,\"jobs\":%u,\"aggregate_ns\":%.0f,\"ns_per_submit\":%.9f,\"checksum\":%llu}\n",
      workers, jobs, ns, ns / jobs, static_cast<unsigned long long>(checksum));
}
}
int main() {
  require(SetThreadAffinityMask(GetCurrentThread(), DWORD_PTR{1} << 4) != 0);
  LARGE_INTEGER clock;
  require(QueryPerformanceFrequency(&clock) != 0);
  std::printf("{\"qpc_frequency_hz\":%lld,\"caller_logical_cpu\":4,\"scope\":\"submission only; setup, gate release, joins, result checks and shutdown outside timer\"}\n", clock.QuadPart);
  sample(1);
  sample(32);
}
