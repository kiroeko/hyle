from pathlib import Path
import hashlib, json, re, shlex, subprocess, sys, time

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]
BUILD = ROOT / '.scratch/build-compute-v2-dev'
sys.path.insert(0, str(ROOT / 'scripts'))
from hyle_environment import windows_compiler_environment
from hyle_support import read_cache
cache = read_cache(BUILD)
env = windows_compiler_environment(cache)
env['VSLANG'] = '1033'
cl = cache['CMAKE_CXX_COMPILER']
link = str(Path(cl).with_name('link.exe'))
flags = ['/nologo', '/c', '/DWIN32', '/D_WINDOWS', '/EHsc', '/O2', '/Ob2', '/DNDEBUG',
         '/std:c++latest', '/MD', '/W4', '/permissive-', '/wd4324', '/WX', '/Zc:__cplusplus',
         '/utf-8', '/Zc:preprocessor', '/DHYLE_STATIC', '/I' + str(ROOT / 'include')]
ninja = (BUILD / 'build.ninja').read_text()
probe_libs = [str(BUILD / 'bin' / (n + '.lib')) for n in [
    'hyle_sched', 'hyle_mem_vm', 'hyle_mem', 'hyle_platform_thread', 'hyle_platform',
    'hyle_error', 'hyle_time', 'hyle_container', 'mimalloc_static']]
probe_libs += ['Synchronization.lib', 'bcrypt.lib', 'PowrProf.lib', 'advapi32.lib', 'ws2_32.lib', 'userenv.lib', 'psapi.lib']
test_libs = [str(BUILD/'lib/gtest_main.lib'), str(BUILD/'lib/gtest.lib'), *probe_libs]

def run(tag, command, timeout=120):
    (OUT / (tag + '-command.json')).write_text(json.dumps(command, indent=2))
    start = time.monotonic()
    p = subprocess.run(command, cwd=BUILD, env=env, capture_output=True, timeout=timeout)
    (OUT / (tag + '.stdout.txt')).write_bytes(p.stdout)
    (OUT / (tag + '.stderr.txt')).write_bytes(p.stderr)
    (OUT / (tag + '-exit.json')).write_text(json.dumps({'exit':p.returncode,'wall_seconds':time.monotonic()-start}))
    print(tag, p.returncode, flush=True)
    if p.returncode:
        print(p.stdout.decode(errors='replace')); print(p.stderr.decode(errors='replace'))
        raise SystemExit(p.returncode)
    return p.stdout.decode(errors='replace')

if '--build' in sys.argv:
    for arm in ('baseline', 'candidate'):
        run(arm+'-compile', [cl,*flags,'/DHYLE_SCHED_BUILD','/Fo'+str(OUT/(arm+'.obj')),str(OUT/('blocking.'+arm+'.cc'))])
    run('probe-compile',[cl,*flags,'/Fo'+str(OUT/'probe.obj'),str(OUT/'probe.cc')])
    for arm in ('baseline', 'candidate'):
        run(arm+'-link',[link,'/nologo','/machine:x64','/INCREMENTAL:NO','/subsystem:console',
            '/out:'+str(OUT/(arm+'.exe')),str(OUT/'probe.obj'),str(OUT/(arm+'.obj')),*probe_libs])
    block = ninja.split('build tests\\compute_state\\CMakeFiles\\hyle_compute_state_test.dir\\state_versions_test.cc.obj:',1)[1].split('\n\n',1)[0]
    includes = shlex.split(re.search(r'^  INCLUDES = (.*)$',block,re.M).group(1),posix=False)
    run('test-compile',[cl,*flags,*includes,'/Fo'+str(OUT/'test.obj'),str(ROOT/'tests/sched/blocking_test.cc')])
    run('test-link',[link,'/nologo','/machine:x64','/INCREMENTAL:NO','/subsystem:console',
        '/out:'+str(OUT/'blocking_tests.exe'),str(OUT/'test.obj'),str(OUT/'candidate.obj'),*test_libs])
    (OUT/'binary-identity.json').write_text(json.dumps({
        'binary_sha256':{n:hashlib.sha256((OUT/n).read_bytes()).hexdigest() for n in ('baseline.exe','candidate.exe','blocking_tests.exe')},
        'reused_libraries_sha256':{p:hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in probe_libs if Path(p).is_absolute()},
        'scope':'Only fresh BlockingPool TU, public probe TU and existing Blocking tests; same foundation static libraries. No CMake build/staging/download.'},indent=2))
if '--tests' in sys.argv:
    print(run('tests',[str(OUT/'blocking_tests.exe'),'--gtest_filter=Blocking.*']))
if '--perf' in sys.argv:
    raw=[]
    for tag,arm in [('pair1-ab-baseline','baseline'),('pair1-ab-candidate','candidate'),('pair2-ba-candidate','candidate'),('pair2-ba-baseline','baseline')]:
        output=run(tag,[str(OUT/(arm+'.exe'))])
        rows=[json.loads(s) for s in output.splitlines() if s.startswith('{')]
        raw.append({'tag':tag,'arm':arm,'rows':rows});print(output)
    (OUT/'raw.json').write_text(json.dumps(raw,indent=2)+'\n')
