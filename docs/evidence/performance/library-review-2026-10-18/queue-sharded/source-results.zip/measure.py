from pathlib import Path
import ctypes as C
from ctypes import wintypes as W
import datetime
import json
import os
import struct
import subprocess
import winreg

HERE = Path(__file__).resolve().parent
assert not (HERE / 'formal-ab.process.json').exists(), 'Fixed final AB/BA already attempted.'
k = C.WinDLL('kernel32', use_last_error=True)
k.GetCurrentProcess.restype = W.HANDLE
k.SetProcessAffinityMask.argtypes = [W.HANDLE, C.c_size_t]
k.GetProcessAffinityMask.argtypes = [W.HANDLE, C.POINTER(C.c_size_t), C.POINTER(C.c_size_t)]
k.GetPriorityClass.argtypes = [W.HANDLE]
length = W.ULONG()
k.GetSystemCpuSetInformation(None, 0, C.byref(length), None, 0)
buffer = C.create_string_buffer(length.value)
if not k.GetSystemCpuSetInformation(buffer, length, C.byref(length), None, 0):
    raise C.WinError(C.get_last_error())
cpus = []
position = 0
while position < length.value:
    size, kind = struct.unpack_from('II', buffer.raw, position)
    if not size:
        raise RuntimeError('Invalid CPU-set record')
    if kind == 0:
        ident, group, logical, core, llc, numa, efficiency, flags = struct.unpack_from('IHBBBBBB', buffer.raw, position + 8)
        cpus.append(dict(id=ident, group=group, logical=logical, core=core, llc=llc,
                         numa=numa, efficiency_class=efficiency, flags=flags))
    position += size
best = max(x['efficiency_class'] for x in cpus if x['group'] == 0)
candidates = []
for cpu in cpus:
    if cpu['group'] == 0 and cpu['efficiency_class'] == best and cpu['core'] not in {x['core'] for x in candidates}:
        candidates.append(cpu)
selected = candidates[:6]
assert len(selected) == 6
mask = sum(1 << cpu['logical'] for cpu in selected)
if not k.SetProcessAffinityMask(k.GetCurrentProcess(), mask):
    raise C.WinError(C.get_last_error())
frequency = C.c_longlong()
if not k.QueryPerformanceFrequency(C.byref(frequency)):
    raise C.WinError(C.get_last_error())
with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r'HARDWARE\DESCRIPTION\System\CentralProcessor\0') as key:
    cpu_name = winreg.QueryValueEx(key, 'ProcessorNameString')[0]
(HERE / 'host.json').write_text(json.dumps(dict(
    cpu_name=cpu_name, cpu_sets=cpus, selected_cpu=selected, affinity_mask=hex(mask),
    qpc_frequency_hz=frequency.value, qpc_tick_seconds=1 / frequency.value,
    resources='Cold episode caller plus four producers and one consumer. Caller and5workers singleton-pin to6distinct highest-efficiency physical cores, one logical per core; actual worker group/mask/processor/priority read in one untimed warmup episode for each arm while all workers held at common gate. All timed workers check affinity setter success. Extra process threads may exist and are not attributed. No during-epoch monitor. ABOVE_NORMAL process priority. Queue/tokens/threads/gate/transfer/join/checks/destruction all inside each timed cold callback.'), indent=2) + '\n')

for order in ('ab', 'ba'):
    name = 'formal-' + order
    env = {key: value for key, value in os.environ.items()
           if not key.startswith(('HYLE_BENCH_', 'HYLE_QUEUE_BENCH_', 'HYLE_PERF_'))}
    command = [str(HERE / 'consumer.exe'), order, str(HERE / (name + '.epochs.json')), ','.join(str(cpu['logical']) for cpu in selected)]
    begin = datetime.datetime.now(datetime.timezone.utc)
    process = subprocess.Popen(command, cwd=HERE, env=env, stdout=subprocess.PIPE,
                               stderr=subprocess.PIPE,
                               creationflags=subprocess.ABOVE_NORMAL_PRIORITY_CLASS)
    process_mask, system_mask = C.c_size_t(), C.c_size_t()
    if not k.GetProcessAffinityMask(int(process._handle), C.byref(process_mask), C.byref(system_mask)):
        raise C.WinError(C.get_last_error())
    priority = k.GetPriorityClass(int(process._handle))
    stdout, stderr = process.communicate(timeout=30)
    record = dict(command=command, order=order, pid=process.pid, exit=process.returncode,
                  begin_utc=begin.isoformat(),
                  end_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                  affinity_mask=hex(process_mask.value), system_mask=hex(system_mask.value),
                  priority_class=priority, no_during_epoch_monitor=True)
    (HERE / (name + '.process.json')).write_text(json.dumps(record, indent=2) + '\n')
    (HERE / (name + '.stdout.txt')).write_bytes(stdout)
    (HERE / (name + '.stderr.txt')).write_bytes(stderr)
    print(name, process.returncode, stdout.decode(errors='replace'), stderr.decode(errors='replace'), flush=True)
    assert process.returncode == 0 and process_mask.value == mask and priority == 0x8000
