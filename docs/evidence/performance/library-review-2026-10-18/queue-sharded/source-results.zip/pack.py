from pathlib import Path
import hashlib
import json
import statistics
import subprocess
import zipfile

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[3]
PEER = ROOT.parent / 'moodycamel-ConcurrentQueue'


def identity(path):
    return dict(path=str(path), bytes=path.stat().st_size,
                sha256=hashlib.sha256(path.read_bytes()).hexdigest())


def write(name, value):
    (HERE / name).write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')


source_review = dict(
    kind='Read-only source/API proof; no hot-allocation instrumentation installed.',
    peer=dict(git_head=subprocess.check_output(['git', '-C', str(PEER), 'rev-parse', 'HEAD'], text=True).strip(),
              git_dirty=subprocess.check_output(['git', '-C', str(PEER), 'status', '--short'], text=True).strip(),
              header=identity(PEER / 'concurrentqueue.h')),
    hyle_git_head=subprocess.check_output(['git', '-C', str(ROOT), 'rev-parse', 'HEAD'], text=True).strip(),
    trace=dict(producers=4, consumers=1, caller=1, payload='uint64_t; producer * 512 + sequence, sequence 1..512',
               items_per_producer=512, total_items=2048,
               checks=['Every scalar push succeeds; no enqueue retry or ignored result.',
                       'Every successful pop has the exact next sequence for its producer.',
                       'Consumer verifies 512 items from each producer, total count 2048, sum 2098176, XOR 2048.',
                       'After all producer completion publications, retry dequeue before accepting empty.',
                       'Join every worker and check one final empty dequeue.'],
               retries='On an empty pop before all producers finish, both arms call std::this_thread::yield().'),
    hyle=dict(configuration='ShardedQueue<uint64_t>(4,1024); four caller-assigned producer identities; local consumer cursor.',
              capacity=4096, maximum_unconsumed_per_shard=512,
              paths=['include/hyle/container/sharded_queue.h:66-74,104-123,126-142',
                     'include/hyle/container/bounded_queue.h:166-170,245-247'],
              policy='Four bounded rings; per-shard FIFO, round-robin drain advances after every successful item.'),
    moody=dict(configuration='ConcurrentQueue<uint64_t>(4096), four simultaneously live explicit ProducerTokens, one ConsumerToken.',
               block_size=32, initial_pool_blocks=128, maximum_blocks_needed_per_fresh_producer=16,
               maximum_total_blocks_needed=64, initial_index_entries_per_explicit_producer=128,
               source_proof=[
                   dict(path='concurrentqueue.h:275,286,719-728,2935-2949', meaning='32 items/block; ordinary capacity constructor allocates ceil(4096/32)=128 initial blocks.'),
                   dict(path='concurrentqueue.h:1687-1702,2266-2273', meaning='Explicit producer index starts from max(32/2,ceil_pow2(128)/2); new_block_index doubles it to 128 entries, above 16 needed.'),
                   dict(path='concurrentqueue.h:986-996,1802-1818,2987-3005', meaning='try_enqueue(token,...) uses CannotAlloc; index/block exhaustion returns false rather than allocating. Every call succeeds in these two processes.'),
                   dict(path='concurrentqueue.h:3562-3568,601-606', meaning='All four tokens are created before any worker and remain live through all joins, so inactive producer recycling cannot collapse the trace.'),
                   dict(path='concurrentqueue.h:1089-1118,301', meaning='ConsumerToken uses the native 256-item rotation quota; this differs from Hyle round-robin draining and is retained as peer policy.')],
               policy='Per-producer FIFO only; no global FIFO promised or checked. No growing enqueue API.'),
    timing=dict(callback='Construct queue, register tokens where applicable, create and pin 5 workers, common gate, transfer/oracle, join, final-empty check, destroy tokens/queue.',
                excluded='One diagnostic cold episode for each arm, resource queries at its gate, nanobench/JSON setup and rendering.',
                unit='ns per transferred item = callback seconds * 1e9 / 2048. Each item includes one enqueue and one dequeue; this is not ns per scalar queue operation.',
                common_start_gate='ready/go atomics and wait/notify; common done publication; no hot shared statistics or per-operation tracing.',
                pinning='One caller plus four producers and one consumer, each singleton-pinned to a distinct P core; actual worker placement queried in the untimed diagnostic episode only.'),
    limitations=[
        'The no-full trace does not compare bounded full/backpressure policies or general MPMC behavior.',
        'Hyle ring cells and Moody block pool plus four producer indexes have different storage costs. Equal nominal capacity is not equal allocated bytes; no allocation-byte census was made.',
        'Source/API proof establishes prepared queue storage and CannotAlloc success; no malloc/global-new monitor was installed. Thread/runtime allocation remains inside the common cold callback.',
        'Both processes contain additional auxiliary threads (8 or 9 live total at the diagnostic gate, versus 6 intended actors); their ownership/activity was not attributed.',
        'Hyle round-robin-per-item and native Moody ConsumerToken quota are intentionally different policy implementations under the shared per-producer FIFO contract.',
        'The fixed two-process result includes Windows thread creation, OS scheduling, gate, joins, payload checks and cleanup; it does not isolate hot queue throughput.'])
write('source-review.json', source_review)

runs = []
all_windows = []
for order in ('ab', 'ba'):
    process = json.loads((HERE / f'formal-{order}.process.json').read_text())
    data = json.loads((HERE / f'formal-{order}.epochs.json').read_text())
    diagnostics = [json.loads(line) for line in (HERE / f'formal-{order}.stdout.txt').read_text().splitlines() if line.startswith('{')]
    arms = []
    for result in data['results']:
        measurements = result['measurements']
        assert len(measurements) == 9
        windows = [m['iterations'] * m['elapsed'] for m in measurements]
        all_windows.extend(windows)
        arms.append(dict(name=result['name'],
                         median_seconds_per_episode=result['median(elapsed)'],
                         median_ns_per_transferred_item=result['median(elapsed)'] * 1e9 / 2048,
                         median_absolute_percent_error=100 * result['medianAbsolutePercentError(elapsed)'],
                         configured_epochs=result['epochs'], observed_epochs=len(measurements),
                         configured_min_epoch_seconds=result['minEpochTime'],
                         configured_min_epoch_iterations=result['minEpochIterations'],
                         observed_min_epoch_seconds=min(windows), observed_max_epoch_seconds=max(windows),
                         observed_min_iterations=min(m['iterations'] for m in measurements),
                         all_epoch_ns_per_transferred_item=[m['elapsed'] * 1e9 / 2048 for m in measurements],
                         all_epoch_windows_seconds=windows,
                         all_epoch_iterations=[m['iterations'] for m in measurements]))
    hyle = next(arm for arm in arms if arm['name'].startswith('Hyle'))
    moody = next(arm for arm in arms if arm['name'].startswith('Moody'))
    runs.append(dict(order=order, process=process, diagnostics=diagnostics, arms=arms,
                     hyle_time_divided_by_moody_time=hyle['median_seconds_per_episode'] / moody['median_seconds_per_episode'],
                     hyle_time_lower_percent=100 * (1 - hyle['median_seconds_per_episode'] / moody['median_seconds_per_episode'])))

summary = dict(
    scope='One fixed non-full cold 4P1C episode trace, actual local pinned Moody; no product or formal benchmark source change.',
    result='Both orders pass every payload/FIFO/count/sum/XOR/final-empty check. Hyle median is lower in both orders, but 7-12% arm MAPE and process drift limit a speed claim. No current Hyle loss established in this trace.',
    attempts='Exactly AB then BA, one process each; exit 0 each. No earlier failed attempt, AA, filtered epoch, rerun or additional shape.',
    total_measured_epochs=36, all_epochs_retained=True, configured_min_epoch_seconds=0.012,
    actual_shortest_epoch_seconds=min(all_windows), actual_longest_epoch_seconds=max(all_windows),
    epoch_window_caveat='nanobench adapts iteration counts; configured minEpochTime is 12ms, while some observed windows are below 10ms. Actual per-epoch durations are retained, not relabeled or rerun.',
    timer_resolution_seconds=1e-7,
    runs=runs, host=json.loads((HERE / 'host.json').read_text()),
    source_review='source-review.json', identity='identity.json',
    no_product_edit=True, no_product_library_build=True, sdk_copy_or_download=False,
    interpretation_limits=source_review['limitations'],
    cleanup='cleanup-manifest.json; parent writes exact deletion to repo-root test.ps1 and executes; this agent performed no deletion.')
write('summary.json', summary)

cleanup_files = [identity(HERE / name) for name in ('main.obj', 'consumer.exe')]
write('cleanup-manifest.json', dict(files=cleanup_files, bytes=sum(p['bytes'] for p in cleanup_files),
    retain='All source, commands, source snapshots, epochs, logs and identity metadata. Existing shared nanobench.obj, foundation libraries and vendor checkout remain cached.',
    action='Root test.ps1 exact cleanup only; no deletion performed.'))

sources = {
    'snapshots/sharded_queue.h': ROOT / 'include/hyle/container/sharded_queue.h',
    'snapshots/bounded_queue.h': ROOT / 'include/hyle/container/bounded_queue.h',
    'snapshots/concurrentqueue.h': PEER / 'concurrentqueue.h',
    'snapshots/nanobench.h': ROOT / 'third_party/nanobench/nanobench.h',
    'snapshots/nanobench_impl.cc': ROOT / 'bench/nanobench_impl.cc',
    'snapshots/hyle_environment.py': ROOT / 'scripts/hyle_environment.py',
}
small = [path for path in HERE.iterdir() if path.is_file() and path.suffix in ('.py', '.cc', '.json', '.txt') and path.name != 'archive-identity.json']
archive = HERE / 'source-results.zip'
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as output:
    for path in sorted(small, key=lambda p: p.name):
        output.write(path, path.name)
    for name, path in sorted(sources.items()):
        output.write(path, name)
with zipfile.ZipFile(archive) as source:
    assert source.testzip() is None
    members = source.namelist()
    assert not any(Path(name).suffix.lower() in ('.obj', '.exe', '.lib', '.dll') for name in members)
write('archive-identity.json', dict(**identity(archive), members=len(members), binary_payloads_included=False))
print(json.dumps(dict(archive=identity(archive), members=len(members), cleanup_bytes=sum(p['bytes'] for p in cleanup_files),
                     shortest_epoch_seconds=min(all_windows),
                     runs=[dict(order=r['order'], hyle_time_lower_percent=r['hyle_time_lower_percent'],
                                arms=[dict(name=a['name'], ns=a['median_ns_per_transferred_item'], mape=a['median_absolute_percent_error']) for a in r['arms']]) for r in runs]), indent=2))
