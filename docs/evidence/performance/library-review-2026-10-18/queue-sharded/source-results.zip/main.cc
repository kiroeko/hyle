#define NOMINMAX
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <tlhelp32.h>

#include <nanobench.h>
#include <concurrentqueue.h>

#include <array>
#include <atomic>
#include <chrono>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <fstream>
#include <string_view>
#include <thread>

#include "hyle/container/sharded_queue.h"

#define CHECK(condition)                                                       \
  do {                                                                       \
    if (!(condition)) {                                                       \
      std::fprintf(stderr, "check failed line %d: %s\n", __LINE__, #condition);  \
      std::abort();                                                           \
    }                                                                        \
  } while (false)

constexpr unsigned kProducers = 4;
constexpr std::uint64_t kPerProducer = 512;
constexpr std::uint64_t kTotal = kProducers * kPerProducer;
std::array<unsigned, 6> cpus{};  // caller, four producers, consumer

struct WorkerResource {
  DWORD tid = 0;
  WORD group = 0;
  KAFFINITY mask = 0;
  WORD observed_group = 0;
  BYTE observed_processor = 0;
  int priority = 0;
};

void pin_current(unsigned cpu, WorkerResource* resource = nullptr) {
  CHECK(cpu < sizeof(DWORD_PTR) * 8);
  const DWORD_PTR mask = DWORD_PTR{1} << cpu;
  CHECK(SetThreadAffinityMask(GetCurrentThread(), mask) != 0);
  if (resource != nullptr) {
    GROUP_AFFINITY actual{};
    CHECK(GetThreadGroupAffinity(GetCurrentThread(), &actual));
    PROCESSOR_NUMBER processor{};
    GetCurrentProcessorNumberEx(&processor);
    CHECK(actual.Group == 0 && actual.Mask == mask);
    CHECK(processor.Group == 0 && processor.Number == cpu);
    resource->tid = GetCurrentThreadId();
    resource->group = actual.Group;
    resource->mask = actual.Mask;
    resource->observed_group = processor.Group;
    resource->observed_processor = processor.Number;
    resource->priority = GetThreadPriority(GetCurrentThread());
  }
}

unsigned process_thread_count() {
  const HANDLE snapshot = CreateToolhelp32Snapshot(TH32CS_SNAPTHREAD, 0);
  CHECK(snapshot != INVALID_HANDLE_VALUE);
  THREADENTRY32 entry{};
  entry.dwSize = sizeof(entry);
  unsigned count = 0;
  for (BOOL found = Thread32First(snapshot, &entry); found;
       found = Thread32Next(snapshot, &entry)) {
    if (entry.th32OwnerProcessID == GetCurrentProcessId()) ++count;
  }
  CloseHandle(snapshot);
  return count;
}

struct Result {
  std::uint64_t count = 0;
  std::uint64_t sum = 0;
  std::uint64_t xor_sum = 0;
};

template <class Push, class Pop>
void transfer(const char* label, Push push, Pop pop, bool inspect) {
  std::atomic<unsigned> ready{0};
  std::atomic<bool> go{false};
  std::atomic<unsigned> done{0};
  Result result;
  std::array<WorkerResource, 5> resources{};
  std::array<std::thread, 5> threads;
  auto await_start = [&](unsigned actor) {
    pin_current(cpus[actor + 1], inspect ? &resources[actor] : nullptr);
    ready.fetch_add(1, std::memory_order_release);
    ready.notify_one();
    while (!go.load(std::memory_order_acquire))
      go.wait(false, std::memory_order_relaxed);
  };
  for (unsigned producer = 0; producer != kProducers; ++producer) {
    threads[producer] = std::thread([&, producer] {
      await_start(producer);
      for (std::uint64_t sequence = 1; sequence <= kPerProducer; ++sequence)
        CHECK(push(producer, producer * kPerProducer + sequence));
      done.fetch_add(1, std::memory_order_release);
    });
  }
  threads[kProducers] = std::thread([&] {
    await_start(kProducers);
    std::array<std::uint64_t, kProducers> next{1, 1, 1, 1};
    Result local;
    bool draining = false;
    for (;;) {
      std::uint64_t value = 0;
      if (pop(value)) {
        CHECK(value >= 1 && value <= kTotal);
        const auto producer = static_cast<unsigned>((value - 1) / kPerProducer);
        const auto sequence = (value - 1) % kPerProducer + 1;
        CHECK(sequence == next[producer]++);
        ++local.count;
        local.sum += value;
        local.xor_sum ^= value;
      } else if (draining) {
        break;
      } else if (done.load(std::memory_order_acquire) == kProducers) {
        // Acquire all publications, then retry pop before accepting empty.
        draining = true;
      } else {
        std::this_thread::yield();
      }
    }
    for (const auto sequence : next) CHECK(sequence == kPerProducer + 1);
    result = local;
  });
  for (auto observed = ready.load(std::memory_order_acquire); observed != 5;
       observed = ready.load(std::memory_order_acquire))
    ready.wait(observed, std::memory_order_relaxed);
  if (inspect) {
    std::printf("{\"route\":\"%s\",\"live_process_threads_at_gate\":%u,\"workers\":[",
                label, process_thread_count());
    for (unsigned actor = 0; actor != resources.size(); ++actor) {
      const auto& resource = resources[actor];
      std::printf("%s{\"actor\":%u,\"tid\":%lu,\"group\":%u,\"mask\":%llu,"
                  "\"observed_processor\":%u,\"priority\":%d}",
                  actor == 0 ? "" : ",", actor, resource.tid,
                  static_cast<unsigned>(resource.group),
                  static_cast<unsigned long long>(resource.mask),
                  static_cast<unsigned>(resource.observed_processor), resource.priority);
    }
    std::puts("]}");
  }
  go.store(true, std::memory_order_release);
  go.notify_all();
  for (auto& thread : threads) thread.join();
  CHECK(result.count == kTotal);
  CHECK(result.sum == kTotal * (kTotal + 1) / 2);
  CHECK(result.xor_sum == kTotal);
  std::uint64_t extra = 0;
  CHECK(!pop(extra));
  ankerl::nanobench::doNotOptimizeAway(result);
}

void hyle_episode(bool inspect = false) {
  hyle::container::ShardedQueue<std::uint64_t> queue(kProducers, 1024);
  CHECK(queue.valid());
  if (inspect) CHECK(queue.capacity() == 4096);
  std::size_t cursor = 0;
  transfer("Hyle", [&](unsigned producer, std::uint64_t value) {
             return queue.try_push(producer, value);
           }, [&](std::uint64_t& value) { return queue.try_pop(cursor, value); }, inspect);
}

void moody_episode(bool inspect = false) {
  // 4096/32=128 initial blocks. Four fresh producers enqueue at most16blocks
  // each; each token's index is prebuilt for128blocks by this pinned header.
  moodycamel::ConcurrentQueue<std::uint64_t> queue(4096);
  std::array<moodycamel::ProducerToken, 4> producers{
      moodycamel::ProducerToken(queue), moodycamel::ProducerToken(queue),
      moodycamel::ProducerToken(queue), moodycamel::ProducerToken(queue)};
  for (const auto& token : producers) CHECK(token.valid());
  moodycamel::ConsumerToken consumer(queue);
  transfer("Moody", [&](unsigned producer, std::uint64_t value) {
             // CannotAlloc: every successful operation uses prepared storage.
             return queue.try_enqueue(producers[producer], value);
           }, [&](std::uint64_t& value) { return queue.try_dequeue(consumer, value); }, inspect);
}

int main(int argc, char** argv) {
  CHECK(argc == 4);
  const std::string_view order(argv[1]);
  CHECK(order == "ab" || order == "ba" || order == "aa");
  const char* input = argv[3];
  for (unsigned index = 0; index != cpus.size(); ++index) {
    char* end = nullptr;
    cpus[index] = static_cast<unsigned>(std::strtoul(input, &end, 10));
    CHECK(end != input);
    CHECK(index == cpus.size() - 1 ? *end == '\0' : *end == ',');
    input = end + (index == cpus.size() - 1 ? 0 : 1);
  }
  WorkerResource caller;
  pin_current(cpus[0], &caller);
  std::printf("{\"caller_tid\":%lu,\"caller_group\":%u,\"caller_mask\":%llu,"
              "\"caller_processor\":%u,\"cold_episode_items\":2048}\n",
              caller.tid, static_cast<unsigned>(caller.group),
              static_cast<unsigned long long>(caller.mask),
              static_cast<unsigned>(caller.observed_processor));
  hyle_episode(true);
  moody_episode(true);
  ankerl::nanobench::Bench bench;
  bench.title("cold4P1C512each, exact producer FIFO, no full")
      .relative(true).batch(kTotal).epochs(9).warmup(0)
      .minEpochIterations(5).minEpochTime(std::chrono::milliseconds(12))
      .performanceCounters(false);
  if (order == "aa") {
    bench.run("Hyle A", [] { hyle_episode(); });
    bench.run("Hyle B", [] { hyle_episode(); });
  } else if (order == "ab") {
    bench.run("Hyle ShardedQueue", [] { hyle_episode(); });
    bench.run("Moody explicit4P", [] { moody_episode(); });
  } else {
    bench.run("Moody explicit4P", [] { moody_episode(); });
    bench.run("Hyle ShardedQueue", [] { hyle_episode(); });
  }
  std::ofstream output(argv[2]);
  CHECK(output.good());
  bench.render(ankerl::nanobench::templates::json(), output);
}
