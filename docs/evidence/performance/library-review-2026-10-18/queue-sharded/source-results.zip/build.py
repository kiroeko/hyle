from pathlib import Path
import hashlib
import json
import subprocess
import sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[3]
sys.path.insert(0, str(ROOT / 'scripts'))
from hyle_environment import windows_compiler_environment

CL = Path('C:/Program Files/Microsoft Visual Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/bin/Hostx64/x64/cl.exe')
env = windows_compiler_environment({'CMAKE_CXX_COMPILER': str(CL), 'CMAKE_C_COMPILER': str(CL)})
env['VSLANG'] = '1033'
records = []


def run(name, argv):
    argv = list(map(str, argv))
    result = subprocess.run(argv, cwd=HERE, env=env, capture_output=True, timeout=60)
    (HERE / (name + '.stdout.txt')).write_bytes(result.stdout)
    (HERE / (name + '.stderr.txt')).write_bytes(result.stderr)
    records.append(dict(name=name, argv=argv, cwd=str(HERE), exit=result.returncode))
    (HERE / 'build-commands.json').write_text(json.dumps(records, indent=2) + '\n')
    print(name, result.returncode, flush=True)
    if result.returncode:
        print(result.stdout.decode(errors='replace')[-4000:])
        print(result.stderr.decode(errors='replace')[-4000:])
        raise SystemExit(result.returncode)


def identity(path):
    return dict(path=str(path), bytes=path.stat().st_size,
                sha256=hashlib.sha256(path.read_bytes()).hexdigest())


obj = HERE / 'main.obj'
exe = HERE / 'consumer.exe'
nanobench = HERE.parent / 'nanobench.obj'
flags = ['/nologo', '/c', '/std:c++latest', '/EHsc', '/Zc:preprocessor',
         '/Zc:__cplusplus', '/utf-8', '/O2', '/Ob2', '/MD', '/DNDEBUG',
         '/DHYLE_STATIC', '/DHYLE_BENCH_MOODYCAMEL', '/I' + str(ROOT / 'include'),
         '/external:I' + str(ROOT / 'third_party/nanobench'),
         '/external:I' + str(ROOT.parent / 'moodycamel-ConcurrentQueue'), '/external:W0']
run('compile', [CL, *flags, HERE / 'main.cc', '/Fo' + str(obj)])
foundation = ROOT / '.scratch/build-compute-v2-dev/bin'
libraries = [foundation / (name + '.lib') for name in ['hyle_platform_thread',
             'hyle_platform', 'hyle_time', 'hyle_mem', 'mimalloc_static', 'hyle_error']]
run('link', [CL.with_name('link.exe'), '/nologo', '/INCREMENTAL:NO', '/OPT:REF',
             '/OUT:' + str(exe), obj, nanobench, *libraries, 'advapi32.lib',
             'bcrypt.lib', 'Synchronization.lib'])
inputs = [ROOT / 'include/hyle/container/bounded_queue.h',
          ROOT.parent / 'moodycamel-ConcurrentQueue/concurrentqueue.h',
          ROOT / 'third_party/nanobench/nanobench.h', ROOT / 'bench/nanobench_impl.cc',
          HERE / 'main.cc', ROOT / 'include/hyle/container/sharded_queue.h', CL, nanobench, *libraries]
(HERE / 'identity.json').write_text(json.dumps(dict(inputs=[identity(p) for p in inputs],
    outputs=[identity(obj), identity(exe)], no_product_library_build=True,
    sdk_copy_or_download=False), indent=2) + '\n')
