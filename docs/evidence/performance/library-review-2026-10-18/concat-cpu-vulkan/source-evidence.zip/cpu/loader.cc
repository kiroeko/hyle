#include <windows.h>
#include <cstdio>
#include <cwchar>
#include <cstdlib>
namespace {
const auto preload = [] {
  auto module = LoadLibraryExW(L"C:/public/project-hyle/hyle/.scratch/build-compute-v2-dev/bin/hyle_ggml_cpu_avx2_ffa4e8b8_e74fc9bb8964d04f.dll", nullptr,
      LOAD_LIBRARY_SEARCH_DLL_LOAD_DIR | LOAD_LIBRARY_SEARCH_DEFAULT_DIRS);
  if (!module) { std::fprintf(stderr, "CPU optimized DLL preload failed: %lu\n", GetLastError()); std::abort(); }
  wchar_t path[1024]; GetModuleFileNameW(module,path,1024);
  std::fwprintf(stderr,L"CPU optimized native program: %ls\n",path);
  return module;
}();
}
