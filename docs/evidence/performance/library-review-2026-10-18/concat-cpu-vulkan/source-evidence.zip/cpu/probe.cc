#include ARM_SOURCE
#include <chrono>
#include <cstdio>
#include <iostream>

namespace c = hyle::compute;
namespace n = c::ggml_cpu;

int main(int argc, char **argv) {
  const bool metadata = argc > 1 && std::string_view(argv[1]) == "metadata";
  const bool census = metadata || (argc > 1 && std::string_view(argv[1]) == "census");
  constexpr std::int64_t ports = 64, width = 65536 / sizeof(float);
  if (census) {
    const std::int64_t count = metadata ? 70 : ports;
    const auto input = metadata
        ? c::TensorDesc::strided_bytes(c::DataType::kFloat32,
            std::array<std::int64_t, 3>{2, 1, 7},
            std::array<std::int64_t, 3>{56, 56, 8}).value()
        : c::TensorDesc::dense(c::DataType::kFloat32,
            std::array<std::int64_t, 2>{1, width}).value();
    const auto output = metadata
        ? c::TensorDesc::dense(c::DataType::kFloat32,
            std::array<std::int64_t, 3>{2, count, 7}).value()
        : c::TensorDesc::dense(c::DataType::kFloat32,
            std::array<std::int64_t, 2>{1, count * width}).value();
    n::Program program;
    program.recipe = {.values = {input, output},
        .nodes = {{c::Operation(c::Concat{.axis = 1}),
                   std::vector<std::uint32_t>(count, 0), {1}}},
        .inputs = {0}, .outputs = {1}};
    if (metadata) {
      program.recipe.values.push_back(output);
      program.recipe.nodes.push_back({c::Operation(c::Unary{c::UnaryKind::kNeg}), {1}, {2}});
      program.recipe.outputs.push_back(2);
    }
    n::Invocation invocation;
    invocation.arena = c::ggml_runtime::MetadataArena::for_graph(1024, 1024,
        hyle::mem::system_allocator()).value();
    auto *ctx = invocation.arena.get();
    invocation.graph = ggml_new_graph_custom(ctx, 1024, false);
    invocation.values.resize(program.recipe.values.size());
    auto *source = n::create_tensor_input(ctx, input);
    invocation.values[0] = source;
    std::vector<ggml_tensor *> external{source};
    for (std::size_t i = 0; i < program.recipe.nodes.size(); ++i) {
      auto values = n::lower(program, invocation, program.recipe.nodes[i], i);
      if (values.size() != 1) return 2;
      invocation.values[program.recipe.nodes[i].outputs[0]] = values[0];
      ggml_build_forward_expand(invocation.graph, values[0]);
    }
    for (const auto id : program.recipe.outputs) {
      auto *root = invocation.values[id];
      while (root->view_src) root = root->view_src;
      external.push_back(root);
    }
    std::size_t tensors=0, owned=0, roots=0, copy=0;
    for (auto *t=ggml_get_first_tensor(ctx); t; t=ggml_get_next_tensor(ctx,t)) {
      ++tensors;
      if (t->view_src || t->data || std::ranges::find(external,t)!=external.end()) continue;
      owned += (GGML_MEM_ALIGN-owned%GGML_MEM_ALIGN)%GGML_MEM_ALIGN + ggml_nbytes(t);
      ++roots;
    }
    for (int i=0;i<ggml_graph_n_nodes(invocation.graph);++i) {
      auto *t=ggml_graph_node(invocation.graph,i);
      if (t->op==GGML_OP_CONCAT || t->op==GGML_OP_DUP || t->op==GGML_OP_CONT) copy += ggml_nbytes(t);
    }
    const auto old_capacity=program.recipe.nodes.size()*32+program.recipe.values.size()*4+8;
    const auto capacity=old_capacity+4*std::size_t(count);
    std::cout << "{\"backend\":\"cpu\",\"metadata_case\":" << (metadata?"true":"false")
        << ",\"ports\":" << count << ",\"caller_output_bytes\":" << output.required_bytes().value()
        << ",\"lowered_copy_output_bytes\":" << copy << ",\"owned_arena_payload_bytes\":" << owned
        << ",\"owned_roots\":" << roots << ",\"tensor_metadata_count\":" << tensors
        << ",\"graph_nodes\":" << ggml_graph_n_nodes(invocation.graph)
        << ",\"old_capacity\":" << old_capacity << ",\"candidate_capacity\":" << capacity
        << ",\"payload_allocated\":false}\n";
    return 0;
  }
  auto context = c::Context::create(c::cpu::device(),n::provider({.native_threads=1})).value();
  const auto input = c::TensorDesc::dense(c::DataType::kFloat32,
      std::array<std::int64_t,2>{1,width}).value();
  const auto output_desc = c::TensorDesc::dense(c::DataType::kFloat32,
      std::array<std::int64_t,2>{1,ports*width}).value();
  auto input_buffer = hyle::mem::Buffer::create(hyle::mem::system_resource(),width*sizeof(float),64).value();
  auto output_buffer = hyle::mem::Buffer::create(hyle::mem::system_resource(),ports*width*sizeof(float),64).value();
  std::vector<float> values(width);
  for (std::size_t i=0;i<values.size();++i) values[i]=float(int(i%97)-48)*0.03125f;
  if (!input_buffer.view().write(std::as_bytes(std::span(values))).ok()) return 3;
  const auto source=c::ConstTensorView::create(input,input_buffer.view()).value();
  const auto target=c::TensorView::create(output_desc,output_buffer.view()).value();
  const std::vector<c::TensorDesc> descriptions(ports,input);
  const std::vector<c::ConstTensorView> inputs(ports,source);
  auto prepared=c::prepare(context,c::Operation(c::Concat{.axis=1}),descriptions,
      std::span(&output_desc,1),hyle::mem::system_resource()).value();
  auto invocation=prepared.create_invocation().value();
  auto queue=context.create_queue().value();
  auto execute=[&] {
    auto done=invocation.submit(queue,inputs,std::span(&target,1));
    if (!done || !done->wait().ok()) std::abort();
  };
  auto check=[&] {
    std::vector<float> actual(ports*width);
    if (!output_buffer.view().read(std::as_writable_bytes(std::span(actual))).ok()) std::abort();
    for (std::size_t i=0;i<actual.size();++i) if (actual[i]!=values[i%width]) std::abort();
    return actual.size();
  };
  for(int i=0;i<4;++i) execute();
  check();
  const auto begin=std::chrono::steady_clock::now();
  for(int i=0;i<16;++i) execute();
  const auto elapsed=std::chrono::steady_clock::now()-begin;
  const auto checked=check();
  std::cout << "{\"backend\":\"cpu\",\"ports\":" << ports << ",\"one_port_bytes\":" << width*sizeof(float)
      << ",\"caller_output_bytes\":" << ports*width*sizeof(float)
      << ",\"iterations\":16,\"warmup\":4,\"ns_per_submit_wait\":"
      << std::chrono::duration<double,std::nano>(elapsed).count()/16
      << ",\"oracle_exact\":true,\"oracle_elements\":" << checked
      << ",\"oracle_boundary\":\"before and after aggregate timing, not each iteration\"}\n";
}
