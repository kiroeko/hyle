#include "region.h"
#include "ggml-backend.h"
#include <chrono>
#include <cstdio>
#include <cstring>
#include <iostream>
namespace c=hyle::compute;
namespace d=c::ggml_vulkan::detail;
int main() {
  constexpr std::int64_t count=64,width=65536/sizeof(float);
  auto device=d::NativeDevice::create().value();
  const auto input=c::TensorDesc::dense(c::DataType::kFloat32,std::array<std::int64_t,2>{1,width}).value();
  const auto output=c::TensorDesc::dense(c::DataType::kFloat32,std::array<std::int64_t,2>{1,count*width}).value();
  d::RegionRecipe recipe{.values={input,output},.nodes={{c::Operation(c::Concat{.axis=1}),std::vector<std::uint32_t>(count,0),{1}}},.inputs={0},.outputs={1}};
  auto region=d::Region::create(device,recipe).value();
  auto arena=d::MetadataArena::create(2*ggml_tensor_overhead(),hyle::mem::system_allocator()).value();
  std::vector<std::shared_ptr<ggml_backend_buffer>> owners;
  std::vector<ggml_tensor*> tensors;
  std::vector<d::RegionBinding> bindings;
  {
    auto active=device.activate();
    for (auto size : {width,count*width}) {
      auto *allocation=device.allocate_buffer(size*sizeof(float)).value();
      owners.emplace_back(allocation,[owner=device](auto*b){auto scope=owner.activate();ggml_backend_buffer_free(b);});
      auto *t=ggml_new_tensor_1d(arena.get(),GGML_TYPE_F32,size);
      if (ggml_backend_tensor_alloc(allocation,t,ggml_backend_buffer_get_base(allocation))!=GGML_STATUS_SUCCESS) return 2;
      tensors.push_back(t);bindings.push_back({device.buffer_handle(allocation),0,std::size_t(size)*sizeof(float),owners.back()});
    }
    std::vector<float> values(width);
    for(std::size_t i=0;i<values.size();++i) values[i]=float(int(i%97)-48)*0.03125f;
    ggml_backend_tensor_set(tensors[0],values.data(),0,values.size()*sizeof(float));
  }
  if(!region.bind(bindings).ok()) return 3;
  auto execute=[&]{if(!region.submit().status.ok() || !region.wait().status.ok()) std::abort();};
  auto check=[&]{
    auto active=device.activate();std::vector<float> actual(count*width);
    ggml_backend_tensor_get(tensors[1],actual.data(),0,actual.size()*sizeof(float));
    for(std::size_t i=0;i<actual.size();++i) if(actual[i]!=float(int((i%width)%97)-48)*0.03125f) std::abort();
    return actual.size();
  };
  for(int i=0;i<4;++i) execute();check();
  const auto begin=std::chrono::steady_clock::now();
  for(int i=0;i<32;++i) execute();
  const auto elapsed=std::chrono::steady_clock::now()-begin;
  const auto checked=check();
  std::cout<<"{\"backend\":\"vulkan-native-region\",\"ports\":"<<count<<",\"one_port_bytes\":"<<width*sizeof(float)
      <<",\"caller_output_bytes\":"<<count*width*sizeof(float)<<",\"native_gallocr_storage_bytes\":"<<region.storage_bytes()
      <<",\"iterations\":32,\"warmup\":4,\"ns_per_submit_wait\":"<<std::chrono::duration<double,std::nano>(elapsed).count()/32
      <<",\"oracle_exact\":true,\"oracle_elements\":"<<checked
      <<",\"oracle_boundary\":\"before and after aggregate timing, not each iteration\"}\n";
}
