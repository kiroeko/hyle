from pathlib import Path
import argparse, hashlib, json, os, re, shlex, subprocess, sys, time
ROOT=Path(__file__).resolve().parents[3]; OUT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'scripts'))
from hyle_environment import windows_compiler_environment
cl=Path('C:/Program Files/Microsoft Visual Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/bin/Hostx64/x64/cl.exe'); link=cl.with_name('link.exe')
foundation=ROOT/'.scratch/build-compute-v2-dev'
cpu_source=foundation/'src/compute_ggml_runtime/source-e74fc9bb8964d04f'
vulkan_cache=ROOT/'.scratch/bench-api-runtime/vulkan/build'
vulkan_source=Path('C:/public/tools/hyle-dependencies/v1/sources/ggml-456172ec733a-41b7e10fd424')
# Use the exact patched Vulkan source already compiled by G09, not the unpatched pin.
vulkan_source=vulkan_cache/'native/hyle/src/compute_ggml_runtime/source-0e6af9898804b4ab'
# Resolve the cache's native header owner from one original region command.
commands=json.loads((vulkan_cache/'compile_commands.json').read_text(encoding='utf8'))
region_command=next(x['command'] for x in commands if x['file'].replace('\\','/').endswith('/compute_provider_ggml_vulkan/region.cc'))
m=re.search(r'[-/]external:I([^ ]*source-[^ ]*/include)',region_command)
if not m:
 m=re.search(r'[-/]I([^ ]*source-[^ ]*/include)',region_command)
if m:vulkan_source=Path(m.group(1).strip('"')).parent
else:
 dirs=list((vulkan_cache/'native/hyle/src/compute_ggml_runtime').glob('source-*'))
 assert len(dirs)==1,dirs
 vulkan_source=dirs[0]
vk=Path('C:/public/tools/hyle-dependencies/v1/sources/vulkan_headers-e3b1eec08173-69d6adc9001f/include')
gtest=Path(os.environ['LOCALAPPDATA'])/'hyle/dependencies/v1/sources/googletest-063de7e9578f-162765170ae6/googletest/include'
env=windows_compiler_environment({'CMAKE_CXX_COMPILER':str(cl),'CMAKE_C_COMPILER':str(cl)})
env['VSLANG']='1033'; env['PATH']=str(foundation/'bin')+os.pathsep+env['PATH']
torch_runtime=Path(os.environ['LOCALAPPDATA'])/'hyle/dependencies/v1/sdks/torch-cpu/Windows-bf0079104e068dcbd60b2f8de589dc725282cbe865a85016cc5b8aa46cab519d/libtorch/lib'
env['PATH']=str(torch_runtime)+os.pathsep+env['PATH']
env['DISABLE_VULKAN_OBS_CAPTURE']='1';env['VK_LOADER_LAYERS_DISABLE']='~all~'
records=json.loads((OUT/'commands.json').read_text()) if (OUT/'commands.json').exists() else []
def run(label,command,timeout=120):
 command=list(map(str,command)); t=time.monotonic()
 p=subprocess.run(command,cwd=ROOT,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=timeout)
 (OUT/(label+'.log')).write_bytes(p.stdout)
 records.append({'label':label,'command':command,'cwd':str(ROOT),'exit_code':p.returncode,'elapsed_seconds':time.monotonic()-t})
 (OUT/'commands.json').write_text(json.dumps(records,indent=2)+'\n')
 print(label,p.returncode,round(time.monotonic()-t,3),p.stdout.decode(errors='replace')[-3500:],flush=True)
 if p.returncode:raise SystemExit(p.returncode)
def flags(kind):
 source=cpu_source if kind=='cpu' else vulkan_source
 return ['/nologo','/c','/std:c++latest','/EHsc','/Zc:preprocessor','/Zc:__cplusplus','/utf-8','/O2','/Ob2','/MD','/DNDEBUG','/permissive-','/bigobj','/DHYLE_STATIC','/DNOMINMAX','/DHYLE_COMPUTE_VULKAN=1','/DHYLE_COMPUTE_GGML_CPU=1','/DHYLE_TEST_GGML_CPU=1',
  '/DHYLE_GGML_CPU_F32_FLASH=1','/DHYLE_GGML_CPU_PROVIDER_VERSION="concat-probe-ffa4"',
  '/I'+str(ROOT/'include'),'/I'+str(ROOT/'src/compute'),'/I'+str(ROOT/'src/compute_provider_ggml'),
  '/I'+str(ROOT/'src/compute_provider_ggml_vulkan'),'/I'+str(ROOT/'src/compute_ggml_runtime'),
  '/external:I'+str(source/'include'),'/external:I'+str(source/'src'),'/external:I'+str(gtest),'/external:I'+str(vk),'/external:W0']
def compile(kind,source,obj,label):
 if obj.exists() and obj.stat().st_mtime>=source.stat().st_mtime:return
 run(label,[cl,*flags(kind),source,'/Fo'+str(obj)])
core=['hyle_graph','hyle_compute_backend_cpu','hyle_compute_batch','hyle_compute','hyle_compute_ops','hyle_container','hyle_mem','mimalloc_static','hyle_platform','hyle_error','hyle_platform_thread','hyle_time']
corelibs=[foundation/'bin'/(n+'.lib') for n in core]
testlibs=[foundation/'lib'/(n+'.lib') for n in ['gtest','gtest_main']]
system=['bcrypt.lib','PowrProf.lib','Synchronization.lib','advapi32.lib','user32.lib','shell32.lib','ole32.lib','ws2_32.lib']
line=next(l for l in (vulkan_cache/'build.ninja').read_text().splitlines() if l.startswith('  LINK_LIBRARIES = '))
vendorlibs=[]
for arg in shlex.split(line.split(' = ',1)[1],posix=False):
 arg=arg.strip('"');p=Path(arg)
 if p.stem in ['hyle_compute_provider_ggml_vulkan','hyle_compute_ggml_runtime','ggml','ggml-base','ggml-vulkan']:
  vendorlibs.append(p if p.is_absolute() else vulkan_cache/p)
parser=argparse.ArgumentParser();parser.add_argument('action',choices=['compile','test','probe-compile','census','measure']);parser.add_argument('--kind',choices=['cpu','vulkan','both'],default='both');args=parser.parse_args()
for kind in (['cpu','vulkan'] if args.kind=='both' else [args.kind]):
 directory=OUT/kind
 if args.action=='compile':
  test=ROOT/('tests/compute_provider_ggml/concat_test.cc' if kind=='cpu' else 'tests/compute_provider_ggml_vulkan/concat_test.cc')
  compile(kind,test,directory/'tests.obj',kind+'-tests-compile')
  common=[directory/'tests.obj']
  if kind=='cpu':
   compile(kind,ROOT/'tests/graph_route_cpu/concat_test.cc',directory/'graph-tests.obj','cpu-graph-tests-compile')
   compile(kind,ROOT/'src/graph_route_cpu/ggml_region.cc',directory/'ggml-region.obj','cpu-region-compile')
   compile(kind,ROOT/'src/graph_route_cpu/cpu_context.cc',directory/'graph-context.obj','cpu-graph-context-compile')
   compile(kind,directory/'loader.cc',directory/'loader.obj','cpu-loader-compile')
   common += [directory/'graph-tests.obj',directory/'ggml-region.obj',directory/'graph-context.obj',directory/'loader.obj']
   libraries=corelibs+[foundation/'bin'/(n+'.lib') for n in ['hyle_compute_route_cpu','hyle_compute_provider_native','hyle_simd','hyle_compute_provider_ggml','hyle_compute_ggml_runtime','ggml','ggml-base','ggml-cpu']]+testlibs
   torch=Path(os.environ['LOCALAPPDATA'])/'hyle/dependencies/v1/sdks/torch-cpu/Windows-bf0079104e068dcbd60b2f8de589dc725282cbe865a85016cc5b8aa46cab519d/libtorch/lib'
   libraries += [torch/n for n in ['torch.lib','torch_cpu.lib','c10.lib']]
  else:libraries=corelibs+vendorlibs+testlibs
  for arm in ['baseline','candidate']:
   compile(kind,directory/(arm+'.cc'),directory/(arm+'.obj'),kind+'-'+arm+'-compile')
   run(kind+'-'+arm+'-link',[link,'/nologo','/MACHINE:X64','/SUBSYSTEM:CONSOLE','/INCREMENTAL:NO','/NODEFAULTLIB:LIBCMT','/OUT:'+str(directory/(arm+'-tests.exe')),directory/(arm+'.obj'),*common,*libraries,*system])
 if args.action=='probe-compile':
  for arm in ['baseline','candidate']:
   common=[]
   if kind=='cpu':
    obj=directory/(arm+'-probe.obj')
    run(kind+'-'+arm+'-probe-compile',[cl,*flags(kind),'/DARM_SOURCE="'+str(directory/(arm+'.cc')).replace('\\','/')+'"',directory/'probe.cc','/Fo'+str(obj)])
    common=[directory/'loader.obj']
    libraries=corelibs+[foundation/'bin'/(n+'.lib') for n in ['hyle_compute_provider_ggml','hyle_compute_ggml_runtime','ggml','ggml-base','ggml-cpu']]
   else:
    obj=directory/'probe.obj';compile(kind,directory/'probe.cc',obj,'vulkan-probe-compile')
    compile(kind,directory/(arm+'.census.cc'),directory/(arm+'-census.obj'),'vulkan-'+arm+'-census-compile')
    common=[directory/(arm+'-census.obj')];libraries=corelibs+vendorlibs
   run(kind+'-'+arm+'-probe-link',[link,'/nologo','/MACHINE:X64','/SUBSYSTEM:CONSOLE','/INCREMENTAL:NO','/NODEFAULTLIB:LIBCMT','/OUT:'+str(directory/(arm+'-probe.exe')),obj,*common,*libraries,*system])
 if args.action=='census' and kind=='cpu':
  for arm in ['baseline','candidate']:
   for domain in ['census','metadata']:
    run(kind+'-'+arm+'-'+domain,[directory/(arm+'-probe.exe'),domain])
 if args.action=='measure':
  for index,arm in enumerate(['baseline','candidate','candidate','baseline']):
   run(kind+'-'+str(index)+'-'+arm+'-measure',[directory/(arm+'-probe.exe')])
 if args.action=='test':
  for arm in ['baseline','candidate']:
   filters='GgmlCpuConcat.*' if kind=='cpu' and arm=='baseline' else 'GgmlCpuConcat.*:CpuGgmlConcatGraph.*' if kind=='cpu' else 'GgmlVulkanConcat.*'
   run(kind+'-'+arm+'-tests',[directory/(arm+'-tests.exe'),'--gtest_filter='+filters],60)
(OUT/('environment-'+args.action+'-'+args.kind+'.json')).write_text(json.dumps({'cpu_source':str(cpu_source),'cpu_pin':'ffa4e8b80930029a35991f94e7c8a93cd67730ab','vulkan_source':str(vulkan_source),'vulkan_pin':'456172ec733a135778adcd32d00e576a58232e45','sdk_copy_or_download':False,'native_rebuilt':False,'records':records},indent=2)+'\n')
