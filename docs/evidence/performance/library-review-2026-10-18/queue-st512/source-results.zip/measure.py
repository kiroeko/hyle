from pathlib import Path
import ctypes as C
from ctypes import wintypes as W
import datetime
import json
import os
import struct
import subprocess
import winreg

HERE = Path(__file__).resolve().parent
assert not (HERE / 'final-ab.process.json').exists(), 'Fixed final AB/BA already attempted.'
k = C.WinDLL('kernel32', use_last_error=True)
k.GetCurrentProcess.restype = W.HANDLE
k.SetProcessAffinityMask.argtypes = [W.HANDLE, C.c_size_t]
k.GetProcessAffinityMask.argtypes = [W.HANDLE, C.POINTER(C.c_size_t), C.POINTER(C.c_size_t)]
k.GetPriorityClass.argtypes = [W.HANDLE]
length = W.ULONG()
k.GetSystemCpuSetInformation(None, 0, C.byref(length), None, 0)
buffer = C.create_string_buffer(length.value)
if not k.GetSystemCpuSetInformation(buffer, length, C.byref(length), None, 0):
    raise C.WinError(C.get_last_error())
cpus = []
position = 0
while position < length.value:
    size, kind = struct.unpack_from('II', buffer.raw, position)
    if not size:
        raise RuntimeError('Invalid CPU-set record')
    if kind == 0:
        ident, group, logical, core, llc, numa, efficiency, flags = struct.unpack_from('IHBBBBBB', buffer.raw, position + 8)
        cpus.append(dict(id=ident, group=group, logical=logical, core=core, llc=llc,
                         numa=numa, efficiency_class=efficiency, flags=flags))
    position += size
best = max(x['efficiency_class'] for x in cpus if x['group'] == 0)
candidates = []
for cpu in cpus:
    if cpu['group'] == 0 and cpu['efficiency_class'] == best and cpu['core'] not in {x['core'] for x in candidates}:
        candidates.append(cpu)
selected = candidates[1] if len(candidates) > 1 else candidates[0]
mask = 1 << selected['logical']
if not k.SetProcessAffinityMask(k.GetCurrentProcess(), mask):
    raise C.WinError(C.get_last_error())
frequency = C.c_longlong()
if not k.QueryPerformanceFrequency(C.byref(frequency)):
    raise C.WinError(C.get_last_error())
with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r'HARDWARE\DESCRIPTION\System\CentralProcessor\0') as key:
    cpu_name = winreg.QueryValueEx(key, 'ProcessorNameString')[0]
(HERE / 'host.json').write_text(json.dumps(dict(
    cpu_name=cpu_name, cpu_sets=cpus, selected_cpu=selected, affinity_mask=hex(mask),
    qpc_frequency_hz=frequency.value, qpc_tick_seconds=1 / frequency.value,
    resources='One queue-calling OS thread, no queue worker threads. Actual process thread counts/TIDs are recorded by cold self-snapshots; runtime auxiliary threads may exist and are not attributed. Both queues persist in the same process; no active external resource monitor during epochs. Construction, implicit producer first touch,32warmwaves each and final queue destruction outside timed intervals. ABOVE_NORMAL process priority.'), indent=2) + '\n')

for order in ('ab', 'ba'):
    name = 'final-' + order
    env = {key: value for key, value in os.environ.items()
           if not key.startswith(('HYLE_BENCH_', 'HYLE_QUEUE_BENCH_', 'HYLE_PERF_'))}
    command = [str(HERE / 'consumer.exe'), order, str(HERE / (name + '.epochs.json'))]
    begin = datetime.datetime.now(datetime.timezone.utc)
    process = subprocess.Popen(command, cwd=HERE, env=env, stdout=subprocess.PIPE,
                               stderr=subprocess.PIPE,
                               creationflags=subprocess.ABOVE_NORMAL_PRIORITY_CLASS)
    process_mask, system_mask = C.c_size_t(), C.c_size_t()
    if not k.GetProcessAffinityMask(int(process._handle), C.byref(process_mask), C.byref(system_mask)):
        raise C.WinError(C.get_last_error())
    priority = k.GetPriorityClass(int(process._handle))
    stdout, stderr = process.communicate(timeout=30)
    record = dict(command=command, order=order, pid=process.pid, exit=process.returncode,
                  begin_utc=begin.isoformat(),
                  end_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                  affinity_mask=hex(process_mask.value), system_mask=hex(system_mask.value),
                  priority_class=priority, no_during_epoch_monitor=True)
    (HERE / (name + '.process.json')).write_text(json.dumps(record, indent=2) + '\n')
    (HERE / (name + '.stdout.txt')).write_bytes(stdout)
    (HERE / (name + '.stderr.txt')).write_bytes(stderr)
    print(name, process.returncode, stdout.decode(errors='replace'), stderr.decode(errors='replace'), flush=True)
    assert process.returncode == 0 and process_mask.value == mask and priority == 0x8000
