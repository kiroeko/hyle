#define NOMINMAX
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <tlhelp32.h>

#define main original_queue_benchmark_main
#include "queue_sota.candidate.cc"
#undef main

#include <chrono>
#include <cstdio>
#include <fstream>
#include <string_view>

unsigned own_thread_count() {
  const HANDLE snapshot = CreateToolhelp32Snapshot(TH32CS_SNAPTHREAD, 0);
  if (snapshot == INVALID_HANDLE_VALUE) std::abort();
  THREADENTRY32 entry{};
  entry.dwSize = sizeof(entry);
  unsigned count = 0;
  for (BOOL found = Thread32First(snapshot, &entry); found;
       found = Thread32Next(snapshot, &entry)) {
    if (entry.th32OwnerProcessID == GetCurrentProcessId()) {
      ++count;
      std::printf("{\"cold_snapshot_tid\":%lu}\n", entry.th32ThreadID);
    }
  }
  CloseHandle(snapshot);
  return count;
}

int main(int argc, char** argv) {
  if (argc != 3) return 2;
  const std::string_view order(argv[1]);
  if (order != "ab" && order != "ba" && order != "aa" && order != "smoke") return 2;
  BoundedQueue<std::uint64_t> bounded(kCap);
  if (!bounded.valid()) std::abort();
  moodycamel::ConcurrentQueue<std::uint64_t> moody(kCap);
  auto hyle_wave = [&] {
    checked_single_thread_wave(
        [&](std::uint64_t value) { return bounded.try_push(value); },
        [&](std::uint64_t& value) { return bounded.try_pop(value); });
  };
  auto moody_wave = [&] {
    checked_single_thread_wave(
        [&](std::uint64_t value) { return moody.enqueue(value); },
        [&](std::uint64_t& value) { return moody.try_dequeue(value); });
  };
  for (unsigned wave = 0; wave != 32; ++wave) {
    if (order == "smoke") std::fprintf(stderr, "warmup %u Hyle\n", wave);
    hyle_wave();
    if (order == "smoke") std::fprintf(stderr, "warmup %u Moody\n", wave);
    moody_wave();
  }
  const auto threads_before = own_thread_count();
  if (order == "smoke") {
    std::fprintf(stderr, "warmups complete threads=%u\n", threads_before);
    return 0;
  }
  PROCESSOR_NUMBER processor{};
  GetCurrentProcessorNumberEx(&processor);
  std::printf("{\"threads_before\":%u,\"main_tid\":%lu,"
              "\"processor_group\":%u,\"logical_processor\":%u,"
              "\"explicit_untimed_warmup_waves_each\":32}\n",
              threads_before, GetCurrentThreadId(), processor.Group,
              processor.Number);
  if (threads_before == 0) std::abort();

  ankerl::nanobench::Bench bench;
  bench.title("warm ST512 checked fill/drain; no contention")
      .relative(true)
      .batch(1024)
      .epochs(9)
      .warmup(0)
      .minEpochIterations(200)
      .minEpochTime(std::chrono::milliseconds(10))
      .performanceCounters(false);
  if (order == "aa") {
    bench.run("Hyle A", hyle_wave);
    bench.run("Hyle B", hyle_wave);
  } else if (order == "ab") {
    bench.run("Hyle BoundedQueue", hyle_wave);
    bench.run("Moody ConcurrentQueue implicit", moody_wave);
  } else {
    bench.run("Moody ConcurrentQueue implicit", moody_wave);
    bench.run("Hyle BoundedQueue", hyle_wave);
  }
  const auto threads_after = own_thread_count();
  if (threads_after == 0) std::abort();
  std::ofstream epochs(argv[2]);
  if (!epochs) return 3;
  bench.render(ankerl::nanobench::templates::json(), epochs);
  std::printf("{\"threads_after\":%u,\"checked_all_push_pop_payloads\":true,"
              "\"peak_items\":512,\"one_empty_check_per_wave\":true,"
              "\"constructor_registration_warmup_destructor_timed\":false}\n",
              threads_after);
}
