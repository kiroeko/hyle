from pathlib import Path
import hashlib
import json
import subprocess
import zipfile

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[3]


def identity(path):
    return dict(path=str(path), bytes=path.stat().st_size,
                sha256=hashlib.sha256(path.read_bytes()).hexdigest())


rows = []
windows = []
resource_rows = []
for order in ('ab', 'ba'):
    data = json.loads((HERE / ('final-' + order + '.epochs.json')).read_text())['results']
    assert len(data) == 2 and all(len(x['measurements']) == 9 for x in data)
    hyle = next(x for x in data if x['name'].startswith('Hyle'))
    moody = next(x for x in data if x['name'].startswith('Moody'))
    arms = []
    for arm in data:
        values = [x['elapsed'] * 1e9 / 1024 for x in arm['measurements']]
        windows.extend(x['elapsed'] * x['iterations'] for x in arm['measurements'])
        arms.append(dict(name=arm['name'], ns_per_normalized_op=arm['median(elapsed)'] * 1e9 / 1024,
                         ns_per_checked_wave=arm['median(elapsed)'] * 1e9,
                         epoch_MAPE=arm['medianAbsolutePercentError(elapsed)'],
                         all_epoch_ns_per_op=values, min_ns_per_op=min(values), max_ns_per_op=max(values)))
    rows.append(dict(order=order, arms=arms,
                     hyle_time_over_moody=hyle['median(elapsed)'] / moody['median(elapsed)'],
                     hyle_lower_time_percent=100 * (1 - hyle['median(elapsed)'] / moody['median(elapsed)'])))
    observations = [json.loads(line) for line in (HERE / ('final-' + order + '.stdout.txt')).read_text().splitlines()
                    if line.startswith('{')]
    before = next(x for x in observations if 'threads_before' in x)
    after = next(x for x in observations if 'threads_after' in x)
    resource_rows.append(dict(order=order, cold_observations=observations,
                              process=json.loads((HERE / ('final-' + order + '.process.json')).read_text())))
    assert before['threads_before'] == 3 and after['threads_after'] == 3
source = ROOT / 'bench/container/queue_sota_bench.cc'
assert source.read_bytes() == (HERE / 'queue_sota.candidate.cc').read_bytes()
before = (HERE / 'queue_sota.before.cc').read_bytes()
after = source.read_bytes()
start, end = b'// ---- 1. single-thread', b'// ---- 2. MPMC throughput'
assert before[:before.index(start)] == after[:after.index(start)]
assert before[before.index(end):] == after[after.index(end):]
(HERE / 'benchmark.diff').write_bytes(subprocess.check_output(['git', 'diff', '--', str(source.relative_to(ROOT))], cwd=ROOT))
peer = ROOT.parent / 'moodycamel-ConcurrentQueue'
peer_identity = dict(commit=subprocess.check_output(['git', '-C', str(peer), 'rev-parse', 'HEAD'], text=True).strip(),
                     header_worktree_status=subprocess.check_output(['git', '-C', str(peer), 'status', '--porcelain', '--', 'concurrentqueue.h'], text=True),
                     header=identity(peer / 'concurrentqueue.h'))
cleanup = dict(files=[identity(HERE / name) for name in ('main.obj', 'consumer.exe')],
               retain='All source/commands/raw epochs/logs/identity metadata and existing shared nanobench/foundation caches.',
               action='Root test.ps1 exact cleanup only; no deletion performed.')
cleanup['bytes'] = sum(x['bytes'] for x in cleanup['files'])
(HERE / 'cleanup-manifest.json').write_text(json.dumps(cleanup, indent=2) + '\n')
host = json.loads((HERE / 'host.json').read_text())
summary = dict(
    conclusion='For this checked warm single-caller512-item scalar fill/drain trace, Hyle was faster in the two fixed AB/BA processes. No queue product change; not a general MPMC, contention, ordering-across-producers, full/backpressure, or bulk-API ranking.',
    trace=dict(payload='uint64_t0..511,512scalar enqueues then512scalar dequeues in exact FIFO order; every operation return and every payload checked, followed by one required-empty dequeue. Any mismatch aborts. Peak logical occupancy512.',
               peers='HyleBoundedQueue usable1024 with default SystemAllocator versus actual local moodycamel ConcurrentQueue defaulttraits, initial storage1024 and implicit producer. No explicit producer/consumer token, no bulk API, no full retry. Moody1024 is not called a hard capacity.',
               boundary='Both queues constructed before32explicit alternating warmwaves each; implicit producer registration and first touch occur there. Timed callback is only the entire checked wave. Both queue destructors run after all measurements and output. If any later queue allocation occurs it is included; no hot allocator monitor was used.',
               units='Raw elapsed is seconds per whole512-item wave. Console ns/op divides by1024 successful scalar push/pop operations; the extra empty check is charged once per wave but not counted in this denominator.',
               schedule='Fixed AB thenBA,9epochs per arm,minEpochTime10ms,minEpochIterations200, performanceCounters(false); all36epochs preserved. No trimming/AA/additional shape or timing matrix.'),
    results=rows,
    clock=dict(qpc_frequency_hz=host['qpc_frequency_hz'], qpc_tick_seconds=host['qpc_tick_seconds'],
               nanobench_resolution_seconds=1e-7, shortest_actual_epoch_window_seconds=min(windows),
               shortest_actual_window_ticks=min(windows) * host['qpc_frequency_hz'],
               note='Configured10ms is a calibration target; shortest actual window is slightly below10ms and retained. Epoch MAPE and cross-process variation are not clock resolution.'),
    resources=dict(cpu=host['cpu_name'], selected=host['selected_cpu'], mask=host['affinity_mask'],
                   actual=resource_rows,
                   interpretation='One thread calls either queue. Both final processes cold-snapshot3threads before and after; two auxiliary threads not attributed. Same inherited single-logical-CPU affinity0x4 andABOVE_NORMAL priority independently checked for each process. No during-epoch resource monitor.'),
    retained_failure=dict(first_attempt='formal-ab.process.json:0xC0000409 abort before any epochs file, BA not launched. Original main/candidate source snapshots retained; original executable was overwritten during diagnostic rebuild and its initial binary hash was not retained.',
                          diagnosis='One non-timed smoke passed all32warmwaves for both queues and then observed4process threads. The extra assertion that total process threads must equal1 was false; removed without changing push/pop/payload/empty oracle. Final actual counts3each are reported, not silently relabelled1.',
                          source_history='main.cc.first-attempt and main.cc.smoke-version plus diagnostic source/build identity retained. No failed measurement points filtered: initial abort generated no epochs.'),
    benchmark_fix='Only formal single-thread section changed: every return/payload+finalempty checked, cold construction/registration/warmup/destruction outside callback for each enabled peer. Existing MPMC/owner/vector/main sections byte-identical to frozen before. Actual measured closure enablesMoody only; optionalTBB/rigtorp branches were not compiled/run in this batch.',
    no_AA='Both order point gaps areabout19.6–19.9%; all Hyle epoch normalized times are below allMoody epoch times, MAPE<=2.3%. No additionalAA process needed; these two processes do not establish a long-run CI or all-hardware ranking.',
    source=identity(source), peer=peer_identity, build_identity=json.loads((HERE / 'identity.json').read_text()),
    scope='Windows x64 MSVC14.50/O2/MD; one fresh benchmark TU and cached nanobench/foundation link. No product queue edits, SDK download/copy, full build, more consumers/producers, or reopening prior bounded4P4C.',
    cleanup=cleanup)
(HERE / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
files = sorted([p for p in HERE.iterdir() if p.is_file() and p.name not in
                ('main.obj', 'consumer.exe', 'source-results.zip', 'archive-record.json')], key=lambda p: p.name)
with zipfile.ZipFile(HERE / 'source-results.zip', 'w', zipfile.ZIP_DEFLATED) as archive:
    for path in files:
        archive.write(path, path.name)
record = dict(archive=identity(HERE / 'source-results.zip'), members=len(files),
              binaries_included=False, cleanup_files=len(cleanup['files']), cleanup_bytes=cleanup['bytes'])
(HERE / 'archive-record.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record, indent=2))
