from pathlib import Path
import difflib,hashlib,json,subprocess,zipfile
ROOT=Path(__file__).resolve().parents[3];OUT=Path(__file__).resolve().parent
FILES=['src/compute_provider_ggml/ggml_cpu_provider.cc','src/compute_provider_ggml/native_batch.cc',
       'tests/compute_provider_ggml/native_paged_test.cc','tests/compute_provider_ggml/native_ragged_test.cc']
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def rec(p):return dict(path=str(p.resolve()),bytes=p.stat().st_size,sha256=sha(p))
def write(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
application=[]
for name in FILES:
    measured=(OUT/'candidate'/name).read_bytes();applied=(ROOT/name).read_bytes()
    if measured==applied:continue
    assert name=='tests/compute_provider_ggml/native_ragged_test.cc'
    double=b'#include "hyle/compute/backends/cpu.h"\n#include "hyle/compute/backends/cpu.h"\n'
    assert measured.replace(double,b'#include "hyle/compute/backends/cpu.h"\n',1)==applied
    dest=OUT/'applied'/name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(applied)
    application.append(dict(path=name,measured_sha256=hashlib.sha256(measured).hexdigest(),applied_sha256=hashlib.sha256(applied).hexdigest(),change='Root removed one duplicate guarded header include after validation; no semantic change, no recompile. Measured candidate snapshot remains unchanged.'))
    (OUT/'measured-to-applied.diff').write_bytes(b''.join(difflib.diff_bytes(difflib.unified_diff,measured.splitlines(keepends=True),applied.splitlines(keepends=True),fromfile=b'measured/'+name.encode(),tofile=b'applied/'+name.encode())))
retain=json.loads((OUT.parent/'cpu-native-causal/cleanup-and-retain.json').read_text())['retain_for_future_cpu_work']
for r in retain:assert rec(Path(r['path']))==r
libraries={}
commands=json.loads((OUT/'commands.json').read_text())
for r in commands:
    for arg in r['argv']:
        p=Path(arg)
        if p.is_absolute() and p.suffix=='.lib' and p.exists() and str(p) not in libraries:libraries[str(p)]=rec(p)
write(OUT/'source-identities.json',dict(baseline_commit='907247284',measured_product=[dict(path=name,**{k:v for k,v in rec(OUT/'candidate'/name).items() if k!='path'}) for name in FILES],applied_product=[dict(path=name,**{k:v for k,v in rec(ROOT/name).items() if k!='path'}) for name in FILES],measured_to_applied=application,retained_native_binaries=retain,linked_cached_libraries=list(libraries.values()),native_source_after_sha256={pin:sha(OUT.parent/'cpu-native-causal'/pin/'ops.cpp') for pin in ['ffa4','mixed']}))
(OUT/'applied-product.diff').write_bytes(subprocess.check_output(['git','diff','--',*FILES],cwd=ROOT))
# Preserve the sole failed source edit explicitly; original frozen path was
# overwritten after fixing that unused local, so label this reconstruction.
p=OUT/'candidate'/FILES[0]
failed=p.read_text().replace('std::size_t native_invocation_bytes(void *, void *slot) noexcept {',
    'std::size_t native_invocation_bytes(void *prepared, void *slot) noexcept {\n  const auto &program = *static_cast<Program *>(prepared);')
(OUT/'first-provider-unused-local-reconstructed.cc').write_text(failed,encoding='utf-8')
baseline=json.loads((OUT/'ffa4-space-baseline.log').read_text().strip())
candidate=json.loads((OUT/'ffa4-space-candidate.log').read_text().strip())
summary={
 'scope':'Remove the remaining private CPU paged/ragged non-boxed causal Q>1 ProgramHalf mask seed. Ordinary native causal already used HYCA. No public API, native resource, CMake, dependency or numerical contract change.',
 'implementation':{
  'native':'Reuse existing HYCA tag in non-boxed causal Q>1. Both vector and tile paths obtain logical rows via hyle_flash_rows; real page table still supplies row addresses. Boxed HYBX takes precedence for Q8/window/independent Dq-Dv; Q1 receives no tag and retains original split-KV eligibility.',
  'program':'Remove Program attention_masks, outer node vector, seed construction, explicit FLASH mask leaf and mask storage accounting.',
  'budget':'Remove only the obsolete Q×KV mask lower bound in native_batch; retain query lower bound, metadata checks and final actual native_invocation_bytes budget admission.',
  'layout':'Q>1 same active query/KV indptr, page IDs and tails can reuse the immutable compiled layout owner; changes replan. Q1 keeps existing runtime pointer/logicalRows refresh. No newly mutable compiled topology.',
 },
 'validation':{
  'toolchain':'Windows x64 MSVC14.50.35717 /O2 /MD /W4 /WX. Direct small TU compile/link, no full HEAD/SDK rebuild. No throughput or latency samples collected.',
  'native_identity':'Both same-pin retained HYCA ops baseline objects and AVX2 ABI2 DLLs reused unchanged; runtime logs confirm compute_owner points to the corresponding cpu-native-causal DLL. No old Hadamard-only module or new native compile.',
  'closure':'Fresh frozen provider, native_batch, native_paged/native_ragged tests, selector/main; same-pin native static libs and shared foundation .scratch/build-compute-v2-dev. Tests explicitly select ggml_cpu provider rather than default CPU route, preserving native thread counts and avoiding unrelated route dependency closure.',
  'measured_to_applied':application,
  'passed':12,
  'per_pin_tests':[
   'GgmlCpuPaged.ImplicitCausalPrefillUsesLogicalRowsAcrossLayoutChanges',
   'GgmlCpuPaged.ImplicitCausalPlanChargesActualWorkspaceWithoutMaskSeed',
   'GgmlCpuRagged.NativeFlashReadsTwoRequestsWithoutKvMaterialization',
   'GgmlCpuRagged.ColdBudgetAndPagedQualificationAreExplicit',
   'GgmlCpuBoxed.PlainWindowAndIndependentValueDepth',
   'GgmlCpuBoxed.QuantizedFullNoncausalAllowsMoreQueriesThanKeys',
  ],
  'new_paged_oracle':'Independent FP64 dot/softmax/PV using actual finite representable F16/BF16 inputs, GQA H4/KVhead2, D64. Nonlinear page IDs and tails: Q65/KV93 original and equal-content owner reuse, reordered pages/tail Q65/KV91 replan, Q63/KV91 query-change replan; Q1/KV513 replan then Q1/KV529 in-place logical-row/page-count reuse. F16 tiled Q65 and vector Q63, BF16 vector, original F16 decode split remain eligible under unchanged selection rules.',
  'max_abs_by_dtype':{'F16':3.22980653e-5,'BF16':6.09101415e-5},
  'unchanged_absolute_budgets':{'F16':.002,'BF16':.008},
  'known_budget_case':'F16 Q2048/logicalKV16384 with two physical pages referenced1024 times: both pins plan successfully at8MiB, report1,269,488B known native storage; budget1,269,487B fails specifically at the final known-native-workspace admission. Baseline907247284 new-budget regression deliberately fails at old mask/query lower bound; exit1 log retained.',
 },
 'cold_public_batch_plan_global_new':{
  'method':'One prewarmed public prepare_batch per arm, FFA pin, same128MiB configured float-workspace budget. F16 Q2048/logicalKV16384/H1/D64, page_size16, two physical pages and1024 repeating page refs. BatchProgram/BatchInvocation and generic pool created before counting; no attention execution or caller Q/K/V payloads.',
  'baseline':baseline,'candidate':candidate,
  'requested_bytes_removed':baseline['requested_bytes']-candidate['requested_bytes'],
  'reported_known_bytes_removed':baseline['reported_known_native_bytes']-candidate['reported_known_native_bytes'],
  'interpretation':'Remove64MiB seed, its39B MSVC release x64 vector manual-alignment overhead, and24B outer node-vector allocation: ordinary new calls27→25, requested67,111,611→2,684B. Actual known-native report68,378,352→1,269,488B differs by exactly the logical64MiB mask.',
  'limits':'Successful ordinary operator new/new[] requested bytes only. Excludes aligned new/C allocations and precreated generic pool. The generic batch float-workspace pool still reserves the same128MiB configured budget in this matched probe; this is not total/RSS/peak memory or throughput evidence.',
 },
 'failures_and_limits':[
  'Initial provider compile /WX failed on an unused Program local left after mask accounting removal. Removed local and unnamed the retained private argument; preserved compiler log and explicitly reconstructed failed source. All final compiled sources are frozen in candidate/.',
  'Baseline budget test exit1 is intentional and retained. All other final commands succeeded; no failed sample exclusion or performance samples.',
  'Only Windows, both locked native pins, the six listed tests and one FFA cold-plan allocation example. No full suite/SDK, Linux/macOS validation or broader nonfinite qualification. Existing native partial-tile NaN/Inf behavior is unchanged.',
 ],
 'artifacts':{'sources':'candidate/,baseline/,source-identities.json','commands':'commands.json','raw':'raw.zip','cleanup':'cleanup-and-retain.json'},
}
write(OUT/'summary.json',summary)
delete=[]
for p in OUT.rglob('*'):
    if p.is_file() and p.suffix.lower() in ['.obj','.exe','.dll','.lib','.exp','.map','.pdb','.pyc']:delete.append(rec(p))
for p in [OUT.parent/'cpu-native-causal/__pycache__/build.cpython-312.pyc',OUT.parent/'cpu-hadamard/__pycache__/run.cpython-312.pyc']:
    if p.exists():delete.append(rec(p))
write(OUT/'cleanup-and-retain.json',dict(rule='Exact candidates only; no deletion performed. Root checks hashes and writes test.ps1. Only this round rebuilt host binaries/maps and imported Python bytecode; keep all source/logs/evidence and the four existing native baseline objects/DLLs, shared foundation and native caches.',delete_candidates=delete,delete_total_bytes=sum(r['bytes'] for r in delete),retain_for_future_cpu_work=retain,retain_total_bytes=sum(r['bytes'] for r in retain)))
files={p.relative_to(OUT).as_posix():p for p in OUT.rglob('*') if p.is_file() and p.name not in ['raw.zip','archive-record.json'] and p.suffix.lower() not in ['.obj','.exe','.dll','.lib','.exp','.map','.pdb','.pyc']}
for relative in ['cpu-native-causal/build.py','cpu-hadamard/run.py','cpu-hadamard/test_main.cc']:
    files['reused/'+relative]=OUT.parent/relative
with zipfile.ZipFile(OUT/'raw.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,p in sorted(files.items()):z.write(p,name)
record=dict(path=(OUT/'raw.zip').relative_to(ROOT).as_posix(),bytes=(OUT/'raw.zip').stat().st_size,sha256=sha(OUT/'raw.zip'),members=len(files),note='Sources/commands/diff/logs/identities only; no obj/exe/DLL/lib/SDK.')
write(OUT/'archive-record.json',record)
print(json.dumps(dict(archive=record,delete_count=len(delete),delete_bytes=sum(r['bytes'] for r in delete)),indent=2))
