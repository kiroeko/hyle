#include "cpu_program.h"
#include "hyle/compute/backends/cpu.h"
#include "hyle/compute/batch_execution.h"
#include "hyle/compute/providers/ggml_cpu.h"
#include <windows.h>
#include <array>
#include <atomic>
#include <cstdlib>
#include <filesystem>
#include <iostream>
#include <new>
#include <vector>
namespace {
std::atomic<bool> enabled{false};
std::atomic<std::size_t> calls{0},bytes{0},maximum{0},large{0};
constexpr std::size_t old_seed=64u<<20;
}
void* operator new(std::size_t size){
  void*p=std::malloc(size?size:1);if(!p)throw std::bad_alloc();
  if(enabled.load(std::memory_order_relaxed)){
    calls.fetch_add(1,std::memory_order_relaxed);bytes.fetch_add(size,std::memory_order_relaxed);
    auto old=maximum.load(std::memory_order_relaxed);
    while(old<size&&!maximum.compare_exchange_weak(old,size,std::memory_order_relaxed)){}
    if(size>=old_seed)large.fetch_add(1,std::memory_order_relaxed);
  }
  return p;
}
void* operator new[](std::size_t n){return ::operator new(n);}
void operator delete(void*p)noexcept{std::free(p);}
void operator delete[](void*p)noexcept{std::free(p);}
void operator delete(void*p,std::size_t)noexcept{std::free(p);}
void operator delete[](void*p,std::size_t)noexcept{std::free(p);}
std::string owner(std::uintptr_t address){
  HMODULE module=nullptr;
  if(!GetModuleHandleExA(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS|GET_MODULE_HANDLE_EX_FLAG_UNCHANGED_REFCOUNT,reinterpret_cast<LPCSTR>(address),&module))throw std::bad_alloc();
  std::array<char,4096> name{};
  if(!GetModuleFileNameA(module,name.data(),DWORD(name.size())))throw std::bad_alloc();
  return std::filesystem::path(name.data()).generic_string();
}
int main(){
  using namespace hyle::compute;
  try{
    auto native=ggml_runtime::select_cpu_program().value();native->initialize();
    auto context=Context::create(cpu::device(),ggml_cpu::provider({.native_threads=2})).value();auto queue=context.create_queue().value();
    const auto make_schema=[](unsigned q,unsigned kv,unsigned refs){
      const auto storage=CacheStorage::plain(DataType::kFloat16).value();
      return BatchSchema::create({.storage=BatchStorage::kPaged,.query_type=DataType::kFloat16,.output_type=DataType::kFloat16,
        .key_storage=storage,.value_storage=storage,.max_requests=1,.max_query_rows=q,.max_kv_rows=kv,.max_pages=2,.max_page_refs=refs,
        .query_heads=1,.kv_heads=1,.qk_head_dim=64,.value_head_dim=64,.page_size=16}).value();
    };
    {auto schema=make_schema(2,4,1);const std::array<std::int32_t,2> q{0,2},k{0,1};const std::array<std::int32_t,1> ids{1},tail{4};
     auto layout=schema.version({q,k,ids,tail}).value();auto program=BatchProgram::prepare(context,schema,{.resource=hyle::mem::system_resource(),.max_float_workspace_bytes=2u<<20,.max_int_workspace_bytes=8192,.scale=.125F,.causal=true}).value();
     auto slot=BatchInvocation::create(program,queue).value();auto prepared=slot.prepare_batch(layout).value();prepared={};if(!slot.close().ok())return 5;}
    auto schema=make_schema(2048,16384,1024);const std::array<std::int32_t,2> q{0,2048},k{0,1024};const std::array<std::int32_t,1> tail{16};
    std::vector<std::int32_t> ids(1024);for(std::size_t i=0;i<ids.size();++i)ids[i]=std::int32_t(i%2);
    auto layout=schema.version({q,k,ids,tail}).value();auto program=BatchProgram::prepare(context,schema,{.resource=hyle::mem::system_resource(),.max_float_workspace_bytes=128u<<20,.max_int_workspace_bytes=8192,.scale=.125F,.causal=true}).value();
    auto slot=BatchInvocation::create(program,queue).value();
    enabled.store(true,std::memory_order_relaxed);auto prepared=slot.prepare_batch(layout);enabled.store(false,std::memory_order_relaxed);
    if(!prepared){std::cerr<<prepared.error().message()<<'\n';return 2;}
    const auto report=slot.report();
    std::cout<<"{\"dtype\":\"F16\",\"Q\":2048,\"logical_KV\":16384,\"physical_pages\":2,\"page_refs\":1024,\"old_seed_bytes\":"<<old_seed
      <<",\"successful_unaligned_new_calls\":"<<calls.load()<<",\"requested_bytes\":"<<bytes.load()<<",\"largest_request\":"<<maximum.load()<<",\"requests_at_least_seed_bytes\":"<<large.load()
      <<",\"reported_known_native_bytes\":"<<report.float_workspace_bytes<<",\"budget_bytes\":"<<(128u<<20)<<",\"executed\":false,\"compute_owner\":\""<<owner(reinterpret_cast<std::uintptr_t>(native->compute))<<"\"}\n";
    *prepared={};if(!slot.close().ok())return 3;if(!context.drain().ok())return 4;return 0;
  }catch(const std::exception&e){enabled.store(false);std::cerr<<e.what()<<'\n';return 6;}
}
