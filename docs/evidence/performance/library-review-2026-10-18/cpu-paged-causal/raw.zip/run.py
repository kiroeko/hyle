from pathlib import Path
import argparse,hashlib,importlib.util,json,subprocess
ROOT=Path(__file__).resolve().parents[3];OUT=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('causal',OUT.parent/'cpu-native-causal/build.py')
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
b.OUT=OUT;b.RECORDS=json.loads((OUT/'commands.json').read_text()) if (OUT/'commands.json').exists() else []
NATIVE=OUT.parent/'cpu-native-causal'
FILES=['src/compute_provider_ggml/ggml_cpu_provider.cc','src/compute_provider_ggml/native_batch.cc',
       'tests/compute_provider_ggml/native_paged_test.cc','tests/compute_provider_ggml/native_ragged_test.cc']

def freeze():
    for path in FILES:
        p=OUT/'candidate'/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((ROOT/path).read_bytes())
    for path in FILES[:2]:
        p=OUT/'baseline'/path;p.parent.mkdir(parents=True,exist_ok=True)
        p.write_bytes(subprocess.check_output(['git','show','907247284:'+path],cwd=ROOT))
    (OUT/'product.diff').write_bytes(subprocess.check_output(['git','diff','--',*FILES],cwd=ROOT))

def cfg(pin):
    c=dict(b.had.PINS[pin]);c['folder']=OUT/pin;c['folder'].mkdir(exist_ok=True)
    c['module']=NATIVE/pin/f'hyle_ggml_cpu_avx2_{pin}_causal_overlay.dll'
    c['native_baseline']=NATIVE/pin/'native-baseline.obj'
    return c

def link(c,name,objects,gtest=False):
    f=c['folder'];exe=f/(name+'.exe')
    b.run(f.name+'-'+name+'-link',[b.had.LINK,'/nologo','/MACHINE:X64','/SUBSYSTEM:CONSOLE','/INCREMENTAL:NO','/NODEFAULTLIB:LIBCMT','/OUT:'+str(exe),'/MAP:'+str(f/(name+'.map')),*[f/(x+'.obj') for x in objects],c['native_baseline'],*b.had.common_libs(c),*([b.had.BASE/'lib/gtest.lib'] if gtest else []),*b.had.SYSTEM])
    return exe

def tests(pin):
    c=cfg(pin);src=OUT/'candidate'
    b.cpp(c,src/FILES[0],'provider')
    b.cpp(c,src/FILES[1],'native-batch')
    for kind,path in zip(['paged','ragged'],FILES[2:]):
        b.cpp(c,src/path,kind,['/I'+str(ROOT/'tests/compute_provider_ggml')])
    b.cpp(c,b.HAD/'test_main.cc','main')
    b.cpp(c,ROOT/'src/compute_ggml_runtime/cpu_program.cc','selector',['/DHYLE_GGML_CPU_AVX2_PROGRAM=1','/DHYLE_GGML_CPU_PROGRAM_LIBRARY="'+str(c['module']).replace('\\','/')+'"'])
    exe=link(c,'tests',['provider','native-batch','paged','ragged','main','selector'],True)
    filter='GgmlCpuPaged.ImplicitCausal*:GgmlCpuRagged.NativeFlashReadsTwoRequestsWithoutKvMaterialization:GgmlCpuRagged.ColdBudgetAndPagedQualificationAreExplicit:GgmlCpuBoxed.PlainWindowAndIndependentValueDepth:GgmlCpuBoxed.QuantizedFullNoncausalAllowsMoreQueriesThanKeys'
    b.run(pin+'-tests',[exe,'--gtest_filter='+filter])

def space():
    c=cfg('ffa4');src=OUT/'baseline'
    b.cpp(c,src/FILES[0],'provider-baseline')
    b.cpp(c,src/FILES[1],'native-batch-baseline')
    b.cpp(c,OUT/'space_probe.cc','space')
    for arm,objects in [('baseline',['provider-baseline','native-batch-baseline']),('candidate',['provider','native-batch'])]:
        exe=link(c,'space-'+arm,[*objects,'space','selector'])
        b.run('ffa4-space-'+arm,[exe])
    exe=link(c,'baseline-budget',['provider-baseline','native-batch-baseline','paged','ragged','main','selector'],True)
    b.run('ffa4-baseline-budget',[exe,'--gtest_filter=GgmlCpuPaged.ImplicitCausalPlanChargesActualWorkspaceWithoutMaskSeed'],expected=1)

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('action',choices=['freeze','tests','space']);p.add_argument('--pin',choices=['ffa4','mixed'],default='ffa4');a=p.parse_args()
    if a.action=='freeze':freeze()
    elif a.action=='tests':tests(a.pin)
    else:space()
