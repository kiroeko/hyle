#include "tensor_program.h"
#include <ggml-cuda.h>
#include <ggml-backend.h>
#include <array>
#include <cstdint>
#include <iostream>
#include <vector>

int main() {
  namespace c = hyle::compute;
  namespace n = hyle::compute::ggml_cuda::internal;
  constexpr std::int64_t ports = 64;
  constexpr std::int64_t width = 1024 * 1024 / sizeof(float);
  const auto input = c::TensorDesc::dense(c::DataType::kFloat32,
      std::array<std::int64_t, 2>{1, width}).value();
  const auto output = c::TensorDesc::dense(c::DataType::kFloat32,
      std::array<std::int64_t, 2>{1, ports * width}).value();
  n::Recipe recipe{.values = {input, output},
      .nodes = {{.operation = c::Operation(c::Concat{.axis = 1}),
          .inputs = std::vector<std::uint32_t>(ports, 0), .outputs = {1}}},
      .inputs = {0}, .outputs = {1}};
  ggml_init_params params{.mem_size = 1024 * 1024, .mem_buffer = nullptr,
                          .no_alloc = true};
  auto *arena = ggml_init(params);
  if (!arena) return 2;
  auto *source = n::create_tensor_input(arena, input);
  std::array<ggml_tensor *, 2> values{source, nullptr};
  std::vector<n::ScalarConstant> scalar;
  std::vector<n::DenseConstant> dense;
  const auto lowered = n::lower_tensor_operation(arena, recipe, recipe.nodes[0],
      values, scalar, dense, {});
  if (lowered.size() != 1) return 3;
  auto *external_output = lowered[0];
  while (external_output->view_src) external_output = external_output->view_src;
  auto *graph = ggml_new_graph_custom(arena, 1024, false);
  ggml_build_forward_expand(graph, lowered[0]);
  auto *buft = ggml_backend_cuda_buffer_type(0);
  std::uint64_t payload = 0, allocation_requests = 0, largest = 0;
  std::size_t owned_roots = 0, metadata = 0;
  for (auto *tensor = ggml_get_first_tensor(arena); tensor;
       tensor = ggml_get_next_tensor(arena, tensor)) {
    ++metadata;
    if (tensor->view_src || tensor == source || tensor == external_output)
      continue;
    ++owned_roots;
    const auto bytes = ggml_nbytes(tensor);
    payload += bytes;
    allocation_requests += ggml_backend_buft_get_alloc_size(buft, tensor);
    if (bytes > largest) largest = bytes;
  }
  std::cout << "{\"ports\":" << ports << ",\"one_input_bytes\":" << width * sizeof(float)
      << ",\"caller_output_bytes\":" << ggml_nbytes(external_output)
      << ",\"owned_tensor_roots\":" << owned_roots << ",\"owned_payload_bytes\":" << payload
      << ",\"native_allocation_request_bytes\":" << allocation_requests
      << ",\"largest_owned_payload_bytes\":" << largest << ",\"tensor_metadata_count\":" << metadata
      << ",\"graph_nodes\":" << ggml_graph_n_nodes(graph)
      << ",\"cuda_malloc_performed\":false,\"measurement\":\"Exact lowered-arena tensor census using the provider allocation predicate and native buft allocation sizes; no owned workspace allocated\"}\n";
  ggml_free(arena);
  return 0;
}
