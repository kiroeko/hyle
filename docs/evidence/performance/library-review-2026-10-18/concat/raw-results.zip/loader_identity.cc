#include <windows.h>
#include <iostream>
namespace {
struct Identity final {
  Identity() {
    char path[32768]{};
    const auto module = GetModuleHandleA("hyle_compute_provider_ggml_cuda.dll");
    if (module && GetModuleFileNameA(module, path, sizeof(path)))
      std::cout << "provider_module=" << path << '\n';
  }
} identity;
}
