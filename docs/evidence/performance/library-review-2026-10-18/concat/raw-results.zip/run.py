from pathlib import Path
import argparse, hashlib, json, os, re, shlex, subprocess, sys

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
PREVIOUS = OUT.parent / 'ggml-attention-provider'
BUILD = ROOT / '.scratch/b-cuda-d5'
sys.path.insert(0, str(ROOT / 'scripts'))
from hyle_environment import windows_compiler_environment
from hyle_support import read_cache

parser = argparse.ArgumentParser()
parser.add_argument('action', choices=['compile', 'direct', 'identity', 'graph-static', 'census'])
args = parser.parse_args()
cache = read_cache(BUILD)
env = windows_compiler_environment(cache)
env['VSLANG'] = '1033'
toolkit = Path(cache.get('CUDAToolkit_ROOT') or Path(cache['CMAKE_CUDA_COMPILER']).parent.parent)
env['PATH'] = os.pathsep.join(map(str, [OUT / 'candidate', OUT / 'common', BUILD / 'bin',
    toolkit / 'bin/x64', toolkit / 'bin', env['PATH']]))

def invoke(command, tag, timeout=120):
    record = {'command': command, 'cwd': str(BUILD), 'timeout_seconds': timeout}
    result = subprocess.run(command, cwd=BUILD, env=env,
        stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=timeout)
    record['exit'] = result.returncode
    (OUT / (tag + '-command.json')).write_text(json.dumps(record, indent=2))
    (OUT / (tag + '.log')).write_bytes(result.stdout)
    text = result.stdout.decode('utf-8', errors='replace')
    print('\n'.join(line for line in text.splitlines() if not line.startswith('Note: including file:')), flush=True)
    if result.returncode:
        raise SystemExit(result.returncode)

def compile_source(source, obj, tag, definitions=()):
    command = json.loads((PREVIOUS / 'tensor-compile-command.json').read_text())
    command = command.replace(str(ROOT / 'src/compute_provider_ggml_cuda/tensor_program.cc'), str(source))
    command = re.sub(r'/Fo(?:"[^"]+"|\S+)', '/Fo"' + obj.as_posix() + '"', command)
    command = re.sub(r'/Fd(?:"[^"]+"|\S+)', '/Fd"' + (OUT / 'compile.pdb').as_posix() + '"', command)
    command = command.replace(str(PREVIOUS / 'provider-version.h'), str(OUT / 'provider-version.h'))
    if source.name == 'region-frozen.cc':
        command = command.replace('-DHYLE_COMPUTE_PROVIDER_GGML_CUDA_BUILD', '').replace('-Dhyle_compute_provider_ggml_cuda_EXPORTS', '')
    command += ' ' + ' '.join(definitions)
    invoke(command, tag)

def link_tests(source, target, tag):
    obj = OUT / (tag + '.obj')
    base = json.loads((OUT.parent / 'ggml-attention-tests/compile-command.json').read_text())['command']
    base = base.replace(str(ROOT / 'tests/compute_provider_ggml_cuda/attention_test.cc'), str(source))
    base = re.sub(r'/Fo(?:"[^"]+"|\S+)', '/Fo"' + obj.as_posix() + '"', base)
    base = re.sub(r'/Fd(?:"[^"]+"|\S+)', '/Fd"' + (OUT / 'tests.pdb').as_posix() + '"', base)
    invoke(base, tag + '-compile')
    ninja = (BUILD / 'build.ninja').read_text()
    block = ninja.split('build bin\\' + target + '.exe:', 1)[1].split('\n\n', 1)[0]
    line = re.search(r'^  LINK_LIBRARIES = (.*)$', block, re.M).group(1)
    libraries = [item.strip('"') for item in shlex.split(line, posix=False)]
    libraries = [str(OUT / 'candidate/hyle_compute_provider_ggml_cuda.lib') if item == 'bin\\hyle_compute_provider_ggml_cuda.lib'
        else str(OUT / 'common/hyle_graph_provider_ggml_cuda.lib') if item == 'bin\\hyle_graph_provider_ggml_cuda.lib' else item for item in libraries]
    invoke([str(Path(cache['CMAKE_CXX_COMPILER']).with_name('link.exe')), '/nologo',
        '/machine:x64', '/INCREMENTAL:NO', '/subsystem:console', '/out:' + str(OUT / (tag + '.exe')),
        str(obj), *libraries], tag + '-link')

if args.action == 'compile':
    compile_source(OUT / 'provider-frozen.cc', OUT / 'provider.obj', 'provider-compile')
    for tag in ['baseline', 'candidate']:
        obj = OUT / tag / 'tensor_program.obj'
        compile_source(OUT / ('tensor_program.' + tag + '.probe.cc'), obj, tag + '-compile')
        command = json.loads((PREVIOUS / 'candidate-strict-link-command.json').read_text())
        command = [str(OUT / 'provider.obj') if item == str(PREVIOUS / 'ggml_cuda_provider.obj')
            else str(obj) if item == str(PREVIOUS / 'tensor_program.obj')
            else '/out:' + str(OUT / tag / 'hyle_compute_provider_ggml_cuda.dll') if item.startswith('/out:')
            else '/implib:' + str(OUT / tag / 'hyle_compute_provider_ggml_cuda.lib') if item.startswith('/implib:') else item for item in command]
        invoke(command, tag + '-link')
    link_tests(ROOT / 'tests/compute_provider_ggml_cuda/tensor_test.cc', 'hyle_compute_provider_ggml_cuda_test', 'tensor-tests')
    # The old shared Graph core lacks current ResourceBudget members. Keep its
    # failed attempt in the raw logs; graph-static uses existing current libs.

if args.action == 'direct':
    filters = [('tensor-tests', 'GgmlCudaTensor.StridedCopyAndVariadicConcatPreserveBits:GgmlCudaTensor.IntegerConcatPreservesIndexBitsAcrossReplays:GgmlCudaTensor.BalancedConcatRetainsPortOrderAndStorageBits')]
    identities = {'exe': {}, 'provider': {}, 'runtime_search_prefix': env['PATH'].split(os.pathsep)[:5],
        'limitation': 'Full current tensor lowering except scratch-only explicit decline for three IQ1 mappings absent from legacy native. Concat only tests; no IQ1/default route/full GPU build validation.'}
    for tag in ['baseline', 'candidate']:
        env['PATH'] = str(OUT / tag) + os.pathsep + env['PATH']
        dll = OUT / tag / 'hyle_compute_provider_ggml_cuda.dll'
        identities['provider'][tag] = {'path': str(dll), 'sha256': hashlib.sha256(dll.read_bytes()).hexdigest()}
        for exe, filter in filters:
            identities['exe'][exe] = hashlib.sha256((OUT / (exe + '.exe')).read_bytes()).hexdigest()
            invoke([str(OUT / (exe + '.exe')), '--gtest_filter=' + filter], tag + '-' + exe)
    (OUT / 'tests-identity.json').write_text(json.dumps(identities, indent=2))

if args.action == 'identity':
    compile_source(OUT / 'loader_identity.cc', OUT / 'loader_identity.obj', 'loader-identity-compile')
    command = json.loads((OUT / 'tensor-tests-link-command.json').read_text())['command']
    command.append(str(OUT / 'loader_identity.obj'))
    invoke(command, 'tensor-tests-identity-link')

if args.action == 'graph-static':
    current = ROOT / '.scratch/build-compute-v2-dev'
    objects = []
    for source, name in [(OUT / 'provider-frozen.cc', 'static-provider'),
        (OUT / 'tensor_program.candidate.probe.cc', 'static-tensor'),
        (OUT / 'region-frozen.cc', 'static-region'),
        (ROOT / 'tests/graph_provider_ggml_cuda/region_test.cc', 'static-region-tests')]:
        obj = OUT / (name + '.obj')
        defines = ['-DHYLE_STATIC',
            '-external:I' + str(Path(os.environ['LOCALAPPDATA']) / 'hyle/dependencies/v1/sources/googletest-063de7e9578f-162765170ae6/googletest/include')]
        compile_source(source, obj, name + '-compile', defines)
        objects.append(str(obj))
    libraries = [current / 'bin' / name for name in ['hyle_graph.lib', 'hyle_compute_backend_cuda.lib',
        'hyle_compute_ggml_runtime.lib', 'hyle_compute.lib', 'hyle_compute_ops.lib',
        'hyle_container.lib', 'hyle_mem.lib', 'mimalloc_static.lib', 'hyle_platform.lib',
        'hyle_error.lib', 'hyle_platform_thread.lib', 'hyle_time.lib']]
    libraries += [current / 'lib' / name for name in ['gtest_main.lib', 'gtest.lib']]
    previous_link = json.loads((PREVIOUS / 'candidate-strict-link-command.json').read_text())
    native = [item for item in previous_link if item.endswith('.lib') and not item.startswith('bin\\')]
    exe = OUT / 'static-region-tests.exe'
    invoke([str(Path(cache['CMAKE_CXX_COMPILER']).with_name('link.exe')), '/nologo',
        '/machine:x64', '/INCREMENTAL:NO', '/subsystem:console', '/NODEFAULTLIB:LIBCMT',
        '/out:' + str(exe), *objects, *map(str, libraries),
        str(PREVIOUS / 'ggml-cuda.strict.obj'), *native, 'bcrypt.lib', 'PowrProf.lib', 'Synchronization.lib'], 'static-region-tests-link')
    invoke([str(exe), '--gtest_filter=GgmlCudaGraph.VariadicPortsReserveMetadataEvenWhenValuesRepeat'], 'static-region-tests')

if args.action == 'census':
    compile_source(OUT / 'census.cc', OUT / 'census.obj', 'census-compile')
    for tag in ['baseline', 'candidate']:
        command = json.loads((PREVIOUS / 'candidate-strict-link-command.json').read_text())
        command = [item for item in command if item not in ['/DLL'] and not item.startswith('/implib:') and item != str(PREVIOUS / 'ggml_cuda_provider.obj')]
        command = ['/out:' + str(OUT / (tag + '-census.exe')) if item.startswith('/out:')
            else str(OUT / tag / 'tensor_program.obj') if item == str(PREVIOUS / 'tensor_program.obj') else item for item in command]
        command.extend([str(OUT / 'census.obj')])
        invoke(command, tag + '-census-link')
        invoke([str(OUT / (tag + '-census.exe'))], tag + '-census')
