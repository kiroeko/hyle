from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import subprocess
import sys
import time

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
CACHE = ROOT / '.scratch/build-compute-v2-dev'
OUT = HERE / 'v2'
OUT.mkdir(exist_ok=True)
sys.path.insert(0, str(ROOT / 'scripts'))
from hyle_environment import windows_compiler_environment

cache = {}
for line in (CACHE / 'CMakeCache.txt').read_text(encoding='utf-8-sig').splitlines():
    if '=' in line and not line.startswith(('#', '//')):
        key, value = line.split('=', 1)
        cache[key.split(':', 1)[0]] = value
env = windows_compiler_environment(cache)
env['VSLANG'] = '1033'
before = json.loads((HERE / 'v1/commands.json').read_text())
records_file = OUT / 'commands.json'
records = json.loads(records_file.read_text()) if records_file.exists() else []


def run(name, argv):
    assert not (OUT / (name + '.stdout.txt')).exists()
    start = time.perf_counter()
    started = datetime.now(timezone.utc).isoformat()
    result = subprocess.run(list(map(str, argv)), cwd=HERE, env=env,
                            capture_output=True, timeout=60)
    (OUT / (name + '.stdout.txt')).write_bytes(result.stdout)
    (OUT / (name + '.stderr.txt')).write_bytes(result.stderr)
    records.append(dict(name=name, argv=list(map(str, argv)), cwd=str(HERE),
                        started_utc=started, exit=result.returncode,
                        wall_seconds=time.perf_counter()-start,
                        ended_utc=datetime.now(timezone.utc).isoformat()))
    records_file.write_text(json.dumps(records, indent=2)+'\n')
    print(name, result.returncode, flush=True)
    if result.returncode:
        print(result.stdout.decode(errors='replace')[-6000:])
        print(result.stderr.decode(errors='replace')[-6000:])
        raise SystemExit(result.returncode)


def command(name):
    return next(r['argv'] for r in before if r['name'] == name)


if sys.argv[1] == 'build':
    for name in ('state_versions_test.cc', 'state_clone_test.cc'):
        assert (ROOT / 'tests/compute_state' / name).read_bytes() == (HERE / 'v1' / name).read_bytes()
    assert (ROOT / 'src/compute_state/state_internal.h').read_bytes() == (HERE / 'v1/state_internal.h').read_bytes()
    (OUT / 'state_versions.candidate-v2.cc').write_bytes((ROOT / 'src/compute_state/state_versions.cc').read_bytes())
    (OUT / 'product.diff').write_bytes(subprocess.check_output(['git','diff','--',
        'src/compute_state/state_versions.cc','tests/compute_state/state_versions_test.cc'], cwd=ROOT))
    argv = [a.replace(str(HERE / 'state_versions.candidate.cc'), str(OUT / 'state_versions.candidate-v2.cc'))
             .replace(str(HERE / 'candidate.obj'), str(OUT / 'candidate-v2.obj'))
            for a in command('candidate-compile')]
    run('candidate-v2-compile', argv)
    for name, old_name in [('candidate-v2-tests','candidate-tests-link-retry1'),
                           ('candidate-v2','candidate-link')]:
        argv = [('/OUT:' + str(OUT / (name + '.exe'))) if a.startswith('/OUT:')
                else a.replace(str(HERE / 'candidate.obj'), str(OUT / 'candidate-v2.obj'))
                for a in command(old_name)]
        run(name + '-link', argv)
    run('candidate-v2-tests', [OUT / 'candidate-v2-tests.exe'])
    run('candidate-v2-smoke', [OUT / 'candidate-v2.exe', '--smoke'])
    print('READY v2; no formal timing run', flush=True)
elif sys.argv[1] == 'formal':
    for index, variant in enumerate(('baseline','candidate','candidate','baseline'),1):
        exe = HERE / 'baseline.exe' if variant == 'baseline' else OUT / 'candidate-v2.exe'
        run(f'formal-{index}-{variant}', [exe])
else:
    raise SystemExit('build or formal')
