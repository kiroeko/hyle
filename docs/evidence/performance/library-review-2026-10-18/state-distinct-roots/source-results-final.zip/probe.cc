#define NOMINMAX
#include <Windows.h>

#include "hyle/compute/state_versions.h"

#include <algorithm>
#include <array>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <vector>

namespace c = hyle::compute;
namespace m = hyle::mem;

namespace {
constexpr std::uint32_t kBlocks = 1024;
constexpr std::size_t kBytes = 64;
constexpr unsigned kEpochs = 9;
constexpr unsigned kCalls = 128;

void require(bool condition, const char *message) {
  if (!condition) {
    std::fprintf(stderr, "oracle failure: %s\n", message);
    std::exit(2);
  }
}

template <class T> T take(hyle::Result<T> result, const char *message) {
  require(result.has_value(), message);
  return std::move(*result);
}

std::uint64_t checksum(const c::StateStoreStats &s) {
  std::uint64_t hash = 1469598103934665603ULL;
  const auto mix = [&](std::uint64_t value) {
    hash ^= value;
    hash *= 1099511628211ULL;
  };
  mix(s.versions);
  mix(s.drafts);
  mix(s.retained_blocks);
  mix(s.backing_roots);
  mix(s.registered_clone_slots);
  mix(s.active_clones);
  mix(s.backing_bytes);
  mix(s.host_snapshot_bytes);
  mix(s.clone_capacity_bytes);
  mix(s.closed);
  return hash;
}

std::uint64_t checked_stats(const c::StateStore &store, unsigned roots) {
  const auto s = store.stats();
  require(s.versions == 1 && s.drafts == 0 && s.retained_blocks == kBlocks &&
              s.backing_roots == roots && s.registered_clone_slots == 0 &&
              s.active_clones == 0 && s.backing_bytes == kBlocks * kBytes &&
              s.host_snapshot_bytes == 0 && s.clone_capacity_bytes == 0 &&
              !s.closed,
          "complete public StateStoreStats fields");
  return checksum(s);
}

struct Fixture {
  c::StateSchema schema;
  std::vector<c::LeasePool> pools;
  c::StateStore store;
  c::StateVersion version;

  explicit Fixture(unsigned roots) {
    const auto desc = take(c::TensorDesc::dense(c::DataType::kFloat32,
                                std::array<std::int64_t, 1>{16}), "description");
    schema = take(c::StateSchema::create(
                      std::vector<c::StateEntrySpec>(kBlocks, {.description = desc})),
                  "schema");
    store = take(c::StateStore::create(schema,
                     {.max_versions = 1, .max_drafts = 1, .max_clone_slots = 1,
                      .max_retained_blocks = kBlocks,
                      .max_backing_bytes = kBlocks * kBytes}), "store");
    pools.reserve(roots);
    const auto per_pool = kBlocks / roots;
    for (unsigned i = 0; i < roots; ++i) {
      pools.push_back(take(c::LeasePool::create(m::system_resource(),
                         per_pool * kBytes,
                         {.max_blocks = per_pool, .backing_alignment = 64}), "pool"));
    }
    std::vector<c::StateMember> members;
    members.reserve(kBlocks);
    for (unsigned i = 0; i < kBlocks; ++i) {
      auto writer = take(pools[i / per_pool].allocate(kBytes, 64), "block");
      auto view = take(writer.view(), "write view");
      require(view.fill(std::byte(i & 255)).ok(), "fill");
      auto lease = take(writer.publish(), "publish");
      members.push_back({take(schema.entry(i), "entry"), std::move(lease)});
    }
    version = take(store.import(members), "import");
    members.clear();
    check_members();
    checked_stats(store, roots); // First sort is setup, outside timing.
  }

  void check_members() const {
    for (unsigned i = 0; i < kBlocks; ++i) {
      auto reader = take(version.member(take(schema.entry(i), "entry")), "member");
      std::array<std::byte, kBytes> bytes{};
      require(take(reader.view(), "read view").read(bytes).ok(), "read");
      for (auto value : bytes)
        require(value == std::byte(i & 255), "full member payload");
    }
  }
};

std::int64_t qpc() {
  LARGE_INTEGER value{};
  require(QueryPerformanceCounter(&value) != 0, "QueryPerformanceCounter");
  return value.QuadPart;
}
} // namespace

int main(int argc, char **argv) {
  const bool smoke = argc == 2 && std::strcmp(argv[1], "--smoke") == 0;
  require(argc == 1 || smoke, "arguments");
  DWORD_PTR process_mask = 0, system_mask = 0;
  require(GetProcessAffinityMask(GetCurrentProcess(), &process_mask, &system_mask) != 0,
          "GetProcessAffinityMask");
  constexpr DWORD_PTR requested = DWORD_PTR{1} << 4;
  require((process_mask & requested) != 0, "LP4 is available");
  require(SetProcessAffinityMask(GetCurrentProcess(), requested) != 0,
          "SetProcessAffinityMask LP4");
  DWORD_PTR actual_mask = 0;
  require(GetProcessAffinityMask(GetCurrentProcess(), &actual_mask, &system_mask) != 0 &&
              actual_mask == requested, "read back LP4 affinity");
  require(GetCurrentProcessorNumber() == 4, "executing on LP4");
  LARGE_INTEGER frequency{};
  require(QueryPerformanceFrequency(&frequency) != 0, "QueryPerformanceFrequency");
  std::int64_t minimum_delta = INT64_MAX;
  auto previous = qpc();
  for (unsigned i = 0; i < 10000; ++i) {
    const auto current = qpc();
    if (current > previous)
      minimum_delta = (std::min)(minimum_delta, current - previous);
    previous = current;
  }
  require(minimum_delta != INT64_MAX, "observed positive QPC step");
  std::printf("{\"event\":\"identity\",\"pid\":%lu,\"affinity_mask\":%llu,"
              "\"logical_processor\":%lu,\"process_priority\":%lu,\"thread_priority\":%d,"
              "\"qpc_frequency_hz\":%lld,\"qpc_nominal_tick_ns\":%.9f,"
              "\"qpc_observed_min_step_ticks\":%lld,\"qpc_observed_min_step_ns\":%.9f,"
              "\"smoke\":%s}\n",
              GetCurrentProcessId(), static_cast<unsigned long long>(actual_mask),
              GetCurrentProcessorNumber(), GetPriorityClass(GetCurrentProcess()),
              GetThreadPriority(GetCurrentThread()), frequency.QuadPart,
              1e9 / double(frequency.QuadPart), minimum_delta,
              double(minimum_delta) * 1e9 / double(frequency.QuadPart),
              smoke ? "true" : "false");
  unsigned sequence = 0;
  for (const auto roots : {1u, kBlocks}) {
    Fixture fixture(roots);
    std::uint64_t sum = 0;
    for (unsigned i = 0; i < 16; ++i)
      sum += checked_stats(fixture.store, roots);
    if (!smoke) {
      for (unsigned epoch = 0; epoch < kEpochs; ++epoch) {
        const auto start = qpc();
        for (unsigned i = 0; i < kCalls; ++i)
          sum += checked_stats(fixture.store, roots);
        const auto ticks = qpc() - start;
        require(ticks > 0, "positive measured duration");
        std::printf("{\"event\":\"epoch\",\"sequence\":%u,\"roots\":%u,"
                    "\"blocks\":%u,\"epoch\":%u,\"calls\":%u,\"ticks\":%lld,"
                    "\"actual_ns\":%.9f,\"ns_per_stats\":%.9f,\"checksum\":%llu}\n",
                    sequence++, roots, kBlocks, epoch, kCalls, ticks,
                    double(ticks) * 1e9 / double(frequency.QuadPart),
                    double(ticks) * 1e9 / double(frequency.QuadPart) / kCalls,
                    static_cast<unsigned long long>(sum));
      }
    }
    fixture.check_members();
    checked_stats(fixture.store, roots);
    std::printf("{\"event\":\"oracle\",\"roots\":%u,\"blocks\":%u,"
                "\"caller_pool_capacity_bytes\":%zu,\"all_fields_and_payload\":true,"
                "\"checksum\":%llu}\n", roots, kBlocks, kBlocks * kBytes,
                static_cast<unsigned long long>(sum));
  }
}
