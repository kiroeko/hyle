from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess

ROOT = Path(__file__).resolve().parent
OLD = ROOT.parent / 'library-review-20261018-apple-ordinary-short-q'
SDK = Path('/Users/kiro/hyle-scratch/g09-air-direct-20261017/final-1dbfce9a0/apple-sdk')
CORE = Path('/Users/kiro/hyle-scratch/compute-unified/a-cpu-apple/selected-graph/source-build')
GTEST = Path('/Users/kiro/Library/Caches/hyle/dependencies/v1/sources/googletest-063de7e9578f-162765170ae6/googletest/include')
FLAGS = ['-O3', '-DNDEBUG', '-std=c++23', '-arch', 'arm64', '-DHYLE_STATIC',
         '-DMLX_STATIC', '-DHYLE_COMPUTE_APPLE=1', '-DHYLE_COMPUTE_ROUTE_APPLE_API=',
         '-DHYLE_GRAPH_ROUTE_APPLE_API=', '-Wall', '-Wextra', '-Wpedantic', '-Werror']
INCLUDES = ['-I' + str(OLD / 'candidate/include'), '-I' + str(OLD / 'common/include'),
            '-I' + str(OLD / 'candidate/src/compute_route_apple'),
            '-I' + str(OLD / 'common/src/compute_route_apple'),
            '-I' + str(OLD / 'common/src/compute'),
            '-I' + str(OLD / 'common/src/graph_route_apple'), '-I' + str(ROOT),
            '-isystem', str(SDK / 'include'), '-isystem', str(SDK / 'include/metal_cpp'),
            '-isystem', str(GTEST)]
LIBS = [SDK / 'lib' / ('lib' + name + '.a') for name in [
    'hyle_graph', 'hyle_compute_route_apple', 'hyle_compute_stream',
    'hyle_compute_state', 'hyle_compute_batch', 'hyle_compute', 'hyle_compute_ops',
    'hyle_simd', 'hyle_sched', 'hyle_container', 'hyle_mem_vm', 'hyle_mem',
    'mimalloc_static', 'hyle_platform_thread', 'hyle_time', 'hyle_platform',
    'hyle_error', 'hyle_compute_provider_ggml_metal', 'hyle_compute_ggml_runtime',
    'ggml', 'ggml-metal', 'ggml-base', 'mlx']]
FRAMEWORKS = ['-framework', 'Foundation', '-framework', 'Metal',
              '-framework', 'MetalKit', '-framework', 'QuartzCore']
PATTERN = ('AppleSinkAttention.QBlocksKeepMasksSinksRebindingAndOwners:'
           'AppleSinkAttention.ShortQueriesRetainExistingFallback')


def record(path):
    path = Path(path)
    return dict(path=str(path), bytes=path.stat().st_size,
                sha256=hashlib.sha256(path.read_bytes()).hexdigest())


def save(name, value):
    (ROOT / name).write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8')


def run(tag, argv):
    path = ROOT / (tag + '-command.json')
    assert not path.exists(), 'Refusing to repeat/overwrite command: ' + tag
    command = list(map(str, argv))
    try:
        result = subprocess.run(command, cwd=ROOT, capture_output=True, timeout=240)
        code, out, err = result.returncode, result.stdout, result.stderr
    except subprocess.TimeoutExpired as error:
        code, out, err = -999, error.stdout or b'', error.stderr or b''
    save(tag + '-command.json', dict(argv=command, cwd=str(ROOT), exit=code))
    (ROOT / (tag + '.stdout.txt')).write_bytes(out)
    (ROOT / (tag + '.stderr.txt')).write_bytes(err)
    print(tag, code, flush=True)
    if out:
        print(out.decode(errors='replace')[-6000:], flush=True)
    if code:
        print(err.decode(errors='replace')[-6000:], flush=True)
        raise RuntimeError('Stopped: ' + tag)


def main():
    assert not (ROOT / 'runtime-identities.json').exists(), 'Already executed'
    expected = json.loads((ROOT / 'expected-inputs.json').read_text(encoding='utf-8'))
    for entry in expected['retained_objects'] + expected['retained_headers']:
        assert record(entry['path']) == entry, entry['path']
    for entry in expected['staged_sources']:
        actual = record(ROOT / entry['path'])
        assert actual['bytes'] == entry['bytes'] and actual['sha256'] == entry['sha256'], entry
    baseline = [Path(p) for p in expected['baseline_objects']]
    candidate = [ROOT / 'operations.o' if p.name == 'candidate-operations.o' else p
                 for p in baseline]
    centered = [Path(p) for p in expected['centered_objects']]
    for path in LIBS + [CORE / 'lib/libgtest.a', CORE / 'lib/libgtest_main.a']:
        assert path.is_file(), path
    model = subprocess.check_output(['/usr/sbin/sysctl', '-n', 'hw.model'], text=True).strip()
    assert model == 'Mac16,12', model
    run('hardware', ['/usr/sbin/sysctl', 'hw.model', 'hw.memsize', 'machdep.cpu.brand_string'])
    run('compiler', ['/usr/bin/clang++', '--version'])
    run('toolchain', ['/usr/bin/xcrun', '--show-sdk-path'])
    metal = ROOT / 'mlx.metallib'
    assert not os.path.lexists(metal)
    metal.symlink_to(OLD / 'mlx.metallib')
    assert metal.resolve(strict=True) == (SDK / 'lib/mlx.metallib').resolve(strict=True)
    half = ROOT / 'tests/compute_provider_native'
    half.symlink_to(OLD / 'centered-functional/tests/compute_provider_native', target_is_directory=True)
    assert (half / 'half_test_support.h').is_file()
    save('runtime-identities.json', dict(
        model=model, disk_free_bytes=shutil.disk_usage(ROOT).free,
        retained_objects=expected['retained_objects'], staged_sources=expected['staged_sources'],
        retained_headers=expected['retained_headers'], half_helper=record(half / 'half_test_support.h'),
        native_libraries=[dict(path=str(p), bytes=p.stat().st_size) for p in LIBS],
        libmlx=record(SDK / 'lib/libmlx.a'),
        metallib=dict(path=str(metal), target=str(metal.resolve(strict=True))),
        environment={k:v for k,v in os.environ.items() if k.startswith(('MLX_', 'MTL_', 'METAL_', 'HYLE_'))},
        fresh_product_TUs=1, fresh_test_TUs=1, fresh_space_TUs=1,
        native_SDK_rebuild_or_copy=False, latency_authorized_or_run=False))
    artifacts = []
    gate = dict(status='started', runs=[])
    try:
        for tag, source, obj in [
            ('compile-operations', 'src/compute_route_apple/apple_operations.cc', 'operations.o'),
            ('compile-tests', 'tests/compute_route_apple/tensor_test.cc', 'sink-tests.o'),
            ('compile-space', 'space.cc', 'space.o')]:
            run(tag, ['/usr/bin/clang++', *FLAGS, *INCLUDES, '-c', ROOT / source, '-o', ROOT / obj])
            artifacts.append(ROOT / obj)
        for arm, host in [('baseline', baseline), ('candidate', candidate)]:
            for kind, objs, gtest in [
                ('tests', [*centered, ROOT / 'sink-tests.o'], [CORE / 'lib/libgtest_main.a', CORE / 'lib/libgtest.a']),
                ('space', [ROOT / 'space.o'], [CORE / 'lib/libgtest.a'])]:
                exe = ROOT / (arm + '-' + kind)
                run('link-' + arm + '-' + kind, ['/usr/bin/clang++', '-O3', '-std=c++23', '-arch', 'arm64',
                    '-o', exe, *objs, *host, *LIBS, *gtest, *FRAMEWORKS, '-Wl,-map,' + str(exe) + '.map'])
                artifacts.append(exe)
                mapping = Path(str(exe) + '.map').read_text(encoding='utf-8')
                assert all(str(p) in mapping for p in host + objs)
                foreign = baseline[1] if arm == 'candidate' else ROOT / 'operations.o'
                assert str(foreign) not in mapping
                assert str(SDK / 'lib/libmlx.a') in mapping
        save('built-identities.json', dict(artifacts=[record(p) for p in artifacts],
             maps=[record(Path(str(p)+'.map')) for p in artifacts if not p.name.endswith('.o')]))
        for arm in ['baseline', 'candidate']:
            run('run-' + arm + '-tests', [ROOT / (arm + '-tests'), '--gtest_filter=' + PATTERN,
                '--gtest_throw_on_failure', '--gtest_fail_fast',
                '--gtest_output=json:' + str(ROOT / (arm + '-tests.json'))])
            result = json.loads((ROOT / (arm + '-tests.json')).read_text(encoding='utf-8'))
            assert result['tests'] == 2 and result['failures'] == 0 and result['errors'] == 0
            gate['runs'].append(dict(arm=arm, tests=2, queries=[513,1025,17], failures=0))
            save('functional-gate.json', gate)
        gate['status'] = 'both_two_test_filters_passed'
        save('functional-gate.json', gate)
        spaces = {}
        for arm in ['baseline', 'candidate']:
            run('run-' + arm + '-space', [ROOT / (arm + '-space')])
            rows = [json.loads(line) for line in (ROOT / ('run-' + arm + '-space.stdout.txt')).read_text(encoding='utf-8').splitlines() if line.startswith('{')]
            assert len(rows) == 1 and rows[0]['Q'] == 513 and rows[0]['oracle_passed'] is True
            spaces[arm] = rows[0]
            save('space-results.json', spaces)
    finally:
        present = [record(p) for p in artifacts if p.is_file()]
        # Include a failed compile's partially produced file, if any.
        known = {p['path'] for p in present}
        for name in ['operations.o', 'sink-tests.o', 'space.o', 'baseline-tests', 'candidate-tests', 'baseline-space', 'candidate-space']:
            p = ROOT / name
            if p.is_file() and str(p) not in known:
                present.append(record(p))
        save('cleanup-candidates.json', dict(host='kiro@172.22.10.198', files=present,
            total_bytes=sum(p['bytes'] for p in present), performed_cleanup=False,
            preserve='all preexisting objects/SDK/cache, sources, maps, commands, stdout/stderr, JSON, raw data and symlinks'))


if __name__ == '__main__':
    main()
