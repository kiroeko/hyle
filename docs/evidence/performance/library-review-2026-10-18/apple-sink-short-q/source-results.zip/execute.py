from pathlib import Path
import base64
import hashlib
import json
import subprocess
import tarfile

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
OLD = HERE.parent / 'apple-ordinary-short-q'
HOST = 'kiro@172.22.10.198'
REMOTE_OLD = '/Users/kiro/hyle-scratch/compute-unified/library-review-20261018-apple-ordinary-short-q'
REMOTE = '/Users/kiro/hyle-scratch/compute-unified/library-review-20261018-apple-sink-short-q'


def rec(path):
    return dict(path=str(path), bytes=path.stat().st_size,
                sha256=hashlib.sha256(path.read_bytes()).hexdigest())


def run(tag, argv, timeout=120):
    output = HERE / (tag + '-command.json')
    assert not output.exists(), 'Refusing to repeat: ' + tag
    result = subprocess.run(list(map(str, argv)), capture_output=True, timeout=timeout)
    output.write_text(json.dumps(dict(argv=list(map(str, argv)), exit=result.returncode), indent=2) + '\n', encoding='utf-8')
    (HERE / (tag + '.stdout.txt')).write_bytes(result.stdout)
    (HERE / (tag + '.stderr.txt')).write_bytes(result.stderr)
    print(tag, result.returncode, result.stdout.decode(errors='replace')[-7000:],
          result.stderr.decode(errors='replace')[-3000:], flush=True)
    if result.returncode:
        raise RuntimeError('Stopped: ' + tag)


def ssh(tag, code):
    payload = base64.b64encode(code.encode()).decode()
    run(tag, ['ssh', HOST, 'python3 -c \'import base64;exec(base64.b64decode("' + payload + '"))\''])


def main():
    assert (ROOT / 'AGENTS.md').is_file()
    source_identity = json.loads((HERE / 'source-identity.json').read_text(encoding='utf-8'))
    for item in source_identity['files']:
        assert rec(ROOT / item['path'])['sha256'] == item['candidate_sha256']
    # Freeze the precise current working sources; do not overwrite historical candidates.
    sources = ['src/compute_route_apple/apple_operations.cc',
               'tests/compute_route_apple/tensor_test.cc',
               'tests/compute_route_apple/tensor_test_support.h',
               'tests/compute_route_apple/sink_attention_test_support.h']
    staged = []
    for path in sources:
        dest = HERE / 'staged' / path
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_bytes((ROOT / path).read_bytes())
        entry = rec(dest)
        entry['path'] = path
        staged.append(entry)
    space_base = HERE.parent / 'apple-sink-q128/space.cc'
    space = space_base.read_text(encoding='utf-8')
    for old, new in [('queries = 1025', 'queries = 513'),
                     ('\\"Q\\":1025', '\\"Q\\":513'),
                     ('151142660', '79837444'), ('134348800', '67239936'),
                     ('537657600', '269091072')]:
        assert space.count(old) == 1, old
        space = space.replace(old, new, 1)
    (HERE / 'space.cc').write_text(space, encoding='utf-8', newline='\n')
    entry = rec(HERE / 'space.cc'); entry['path'] = 'space.cc'; staged.append(entry)
    previous = json.loads((OLD / 'functional-tests/expected-inputs.json').read_text(encoding='utf-8'))
    paths = previous['candidate_objects']
    records = {r['path']:r for r in previous['retained_objects']}
    retained = [records[p] for p in paths]
    centered_info = json.loads((OLD / 'functional-tests/runtime-identities.json').read_text(encoding='utf-8'))
    centered = [r for r in centered_info['fresh_artifacts'] if r['path'].endswith('.o')]
    assert len(centered) == 2
    retained += centered
    headers = []
    for path in ['include/hyle/compute/detail/apple_plan.h', 'src/compute_route_apple/apple_tensor.h']:
        local = ROOT / path
        assert local.read_bytes() == (OLD / 'candidate' / path).read_bytes()
        entry = rec(local); entry['path'] = REMOTE_OLD + '/candidate/' + path; headers.append(entry)
    for path in ['src/compute_route_apple/apple_context.cc', 'src/compute_route_apple/apple_tensor.cc',
                 'src/graph_route_apple/apple_lowering.cc']:
        assert (ROOT / path).read_bytes() == (OLD / 'candidate' / path).read_bytes(), path
    expected = dict(base_commit='8ff66c75f120c50b67bee50c2ba5a2ae868b79e1', baseline_objects=paths,
                    centered_objects=[r['path'] for r in centered], retained_objects=retained,
                    retained_headers=headers, staged_sources=staged)
    (HERE / 'expected-inputs.json').write_text(json.dumps(expected, indent=2) + '\n', encoding='utf-8')
    archive = HERE / 'sources.tar.gz'
    with tarfile.open(archive, 'w:gz') as tar:
        for path in sources:
            tar.add(HERE / 'staged' / path, arcname=path)
        for path in ['space.cc', 'run_remote.py', 'expected-inputs.json', 'plan.json', 'source-identity.json', 'candidate.diff']:
            tar.add(HERE / path, arcname=path)
    ssh('create-remote', 'from pathlib import Path; Path(' + repr(REMOTE) + ').mkdir(exist_ok=False)')
    run('stage-sources', ['scp', archive, HOST + ':' + REMOTE + '/sources.tar.gz'])
    ssh('extract-sources', '''from pathlib import Path
import tarfile
root=Path(''' + repr(REMOTE) + ''')
with tarfile.open(root/'sources.tar.gz','r:gz') as tar:
    members=tar.getmembers()
    assert len(members)==10
    for member in members:
        assert member.isfile() and not Path(member.name).is_absolute() and '..' not in Path(member.name).parts
    for member in members:
        path=root/member.name
        assert path.resolve().is_relative_to(root)
        assert not path.exists()
        path.parent.mkdir(parents=True,exist_ok=True)
        path.write_bytes(tar.extractfile(member).read())
print('Staged ten small source/plan files; no SDK/native tree copy')
''')
    run('execute-remote', ['ssh', HOST, 'python3 ' + REMOTE + '/run_remote.py'], timeout=600)


if __name__ == '__main__':
    main()
