from pathlib import Path
import hashlib, json, os, subprocess

ROOT=Path('/mnt/c/public/project-hyle/hyle')
HERE=ROOT/'.scratch/perf-review-2026-10-18/http2/fixed-send-frame'
OLD=HERE.parent
OUT=Path('/root/hyle-scratch/http2-current-20261018/fixed-send-frame')
OUT.mkdir(exist_ok=True)
CORE=Path('/root/hyle-scratch/http2-current-20261018/current-holdout')
CACHE=Path('/root/hyle-scratch/io-watch-v2-dev')
prior=json.loads((OLD/'build-candidate-commands.json').read_text())
records=[]
env=os.environ.copy(); env['LD_LIBRARY_PATH']=str(CORE)+':'+str(CACHE/'bin')

def run(name, argv, environment=env):
    argv=list(map(str,argv))
    p=subprocess.run(argv,cwd=OUT,env=environment,capture_output=True,text=True,timeout=60)
    (HERE/(name+'.stdout.txt')).write_text(p.stdout)
    (HERE/(name+'.stderr.txt')).write_text(p.stderr)
    records.append(dict(name=name,argv=argv,cwd=str(OUT),exit=p.returncode,
        environment={k:v for k,v in environment.items() if k.startswith(('LD_LIBRARY_PATH','HYLE_'))}))
    (HERE/'commands.json').write_text(json.dumps(records,indent=2)+'\n')
    print(name,p.returncode,p.stdout[-1800:],p.stderr[-800:],flush=True)
    if p.returncode: raise RuntimeError(name)
    return p.stdout

cmd=next(x['argv'] for x in prior if x['name']=='compile-candidate')
run('compile-http2',cmd[:-4]+['-c',HERE/'http2.candidate.cc','-o',OUT/'http2.o'])
cmd=next(x['argv'] for x in prior if x['name']=='compile-tests')
run('compile-tests',cmd[:-4]+['-c',HERE/'http2_test.cc','-o',OUT/'tests.o'])
link=next(x['argv'] for x in prior if x['name']=='link-tests')
link=[str(OUT/'tests') if x.endswith('/http2_tests') else
      str(OUT/'http2.o') if x.endswith('/http2-candidate.o') else
      str(OUT/'tests.o') if x.endswith('/http2_test.o') else x for x in link]
run('link-tests',link)
loader=run('loader',['ldd',OUT/'tests'])
assert str(CORE/'libhyle_io_core.so.0.1.0') in loader
run('protocol-tests',['timeout','--kill-after=2s','20s',OUT/'tests'])
epoll=env.copy(); epoll['HYLE_IO_FORCE_EPOLL']='1'
run('epoll-protocol-tests',['timeout','--kill-after=2s','20s',OUT/'tests'],epoll)
symbols=run('candidate-symbols',['nm','-C',OUT/'http2.o'])
private=[s for s in symbols.splitlines() if 'send_submitted_fixed' in s]
assert not any('[clone .actor]' in s or '[clone .destroy]' in s or '.Frame*' in s for s in private),private
(HERE/'private-frame-check.json').write_text(json.dumps(dict(
    source_has_co_await_in_helper=False,
    candidate_private_symbols=private,
    candidate_private_actor_or_destroy=False,
    before='before-factory.txt records actual256B frame allocation and before-callers.txt both parentactorcalls',
    method='Staticnm/objdump of existing/fresh host object only; not runtimeallocation or throughput probe.'),indent=2)+'\n')
disasm=run('candidate-disassembly',['objdump','-drwC',OUT/'http2.o'])
def record(p): return dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
inputs={Path(x) for x in link if x.endswith(('.o','.a'))}
for line in loader.splitlines():
    if 'libhyle_' in line and '=>' in line:
        inputs.add(Path(line.split('=>',1)[1].strip().split()[0]))
(HERE/'build-identity.json').write_text(json.dumps(dict(files=[record(p) for p in sorted(inputs)],
    artifacts=[record(p) for p in OUT.iterdir() if p.is_file()],
    fresh_source=record(HERE/'http2.candidate.cc'),fresh_tests=record(HERE/'http2_test.cc'),
    no_fresh_proactor_SDK_copy_or_download=True),indent=2)+'\n')
artifacts=[record(p) for p in OUT.iterdir() if p.is_file()]
(HERE/'cleanup-candidates.json').write_text(json.dumps(dict(host='WSL',directory=str(OUT),files=artifacts,
    total_bytes=sum(p['bytes'] for p in artifacts),
    note='Only thisbatch3host artifacts; sharedcurrentproactor and originalcache retained. No deletionperformed.'),indent=2)+'\n')
