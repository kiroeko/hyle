from pathlib import Path
import hashlib
import json
import os
import shlex
import subprocess

ROOT = Path('/mnt/c/public/project-hyle/hyle')
HERE = ROOT / '.scratch/perf-review-2026-10-18/tcp-owner-proactor'
CACHE = Path('/root/hyle-scratch/io-watch-v2-dev')
CORE = Path('/root/hyle-scratch/http2-current-20261018/current-holdout/libhyle_io_core.so.0.1.0')
OUT = Path('/root/hyle-scratch/http2-current-20261018/tcp-owner-proactor')
ENV = {k: v for k, v in os.environ.items()
       if not k.startswith(('HYLE_BENCH_', 'HYLE_PERF_', 'HYLE_IO_FORCE_'))}
ENV['LD_LIBRARY_PATH'] = str(CORE.parent) + ':' + str(CACHE / 'bin')
records = []


def rec(path):
    return dict(path=str(path), bytes=path.stat().st_size,
                sha256=hashlib.sha256(path.read_bytes()).hexdigest())


def write(name, value):
    (HERE / name).write_text(json.dumps(value, indent=2) + '\n')


def run(name, argv):
    argv = list(map(str, argv))
    result = subprocess.run(argv, cwd=OUT, env=ENV, capture_output=True,
                            text=True, timeout=60)
    (HERE / (name + '.stdout.txt')).write_text(result.stdout)
    (HERE / (name + '.stderr.txt')).write_text(result.stderr)
    records.append(dict(name=name, argv=argv, cwd=str(OUT), exit=result.returncode,
                        environment={'LD_LIBRARY_PATH': ENV['LD_LIBRARY_PATH']}))
    write('commands.json', records)
    print(name, result.returncode, result.stdout[-3500:], result.stderr[-1000:], flush=True)
    if result.returncode:
        raise RuntimeError('Stopped at failed command: ' + name)
    return result.stdout


assert not (HERE / 'commands.json').exists(), 'Do not repeat validation'
OUT.mkdir(exist_ok=False)
assert rec(CORE)['sha256'] == '9ead235b1bbd72f56d44eab9c8ac135b8c4b0ce0ec0a6fb72660aa917d3b4779'
source = ROOT / 'tests/io_core/tcp_test.cc'
header = ROOT / 'include/hyle/io/tcp.h'
for src, name in [(source, 'tcp_test.cc'), (header, 'tcp.h'),
                  (ROOT / 'include/hyle/io/detail/io_context_access.h', 'io_context_access.h')]:
    (HERE / name).write_bytes(src.read_bytes())
ninja = (CACHE / 'build.ninja').read_text().splitlines()
start = next(i for i, line in enumerate(ninja)
             if line.startswith('build tests/io_core/CMakeFiles/hyle_io_core_tcp_test.dir/tcp_test.cc.o:'))
compile_section = ninja[start:start + 9]
values = dict(line.strip().split(' = ', 1) for line in compile_section if ' = ' in line)
compile_cmd = ['g++-14'] + shlex.split(values['DEFINES'] + ' ' + values['FLAGS'] + ' ' + values['INCLUDES'])
start = next(i for i, line in enumerate(ninja) if line.startswith('build bin/hyle_io_core_tcp_test:'))
link_section = ninja[start:start + 10]
libraries = shlex.split(next(line.split(' = ', 1)[1] for line in link_section if line.strip().startswith('LINK_LIBRARIES =')))
link_inputs = []
link_args = []
for item in libraries:
    if item.startswith('-'):
        link_args.append(item)
    else:
        path = CORE if item == 'bin/libhyle_io_core.so.0.1.0' else CACHE / item
        link_args.append(str(path))
        link_inputs.append(rec(path))
write('identity.json', dict(test_source=rec(source), header=rec(header),
    access_header=rec(ROOT / 'include/hyle/io/detail/io_context_access.h'),
    reused_link_inputs=link_inputs, original_ninja_sections=compile_section + link_section,
    scope='Fresh tcp_test.cc consumer only. Accepted current core and retained scheduler/native/GTest/foundation reused; no configure/build/download.'))
run('compiler', ['g++-14', '--version'])
run('compile-tcp-test', compile_cmd + ['-c', HERE / 'tcp_test.cc', '-o', OUT / 'tcp_test.o'])
run('link-tests', ['g++-14', '-O3', '-DNDEBUG', '-o', OUT / 'tests', OUT / 'tcp_test.o'] + link_args)
loader = run('loader', ['ldd', OUT / 'tests'])
assert str(CORE) in loader
assert header.read_bytes() == (HERE / 'tcp.h').read_bytes()
assert source.read_bytes() == (HERE / 'tcp_test.cc').read_bytes()
run('targeted-tests', ['timeout', '--kill-after=2s', '20s', OUT / 'tests',
    '--gtest_filter=IoTcp.ListenerAcceptEchoRoundTrip:IoTcp.PeerCloseReturnsTypedErrorsWithoutSigpipe',
    '--gtest_output=json:' + str(HERE / 'targeted-tests.json')])
result = json.loads((HERE / 'targeted-tests.json').read_text())
assert result['tests'] == 2 and result['failures'] == result['errors'] == 0
artifacts = [rec(OUT / name) for name in ('tcp_test.o', 'tests')]
write('summary.json', dict(status='Two requested existing tests pass.',
    results=dict(tests=result['tests'], failures=result['failures'], errors=result['errors'], time=result['time']),
    fresh_consumer_TUs=1, core_or_sdk_rebuilds=0, configure_or_performance_run=False,
    artifacts=artifacts, header=rec(header),
    coverage_limit='PeerClose scalar write_some directly compiles/executes the changed ordinary-write inline path in fresh test TU. Echo calls read_exact/write_all in reused core: their internal budget inline code is cached, not rebuilt. All four changed inline definitions are type-checked by this fresh consumer. This is not new-machine-code execution coverage of all four overloads, nor an HTTP2 speed/residual claim.',
    deletion_or_commit_performed=False))
write('cleanup-candidates.json', dict(host='WSL Ubuntu-24.04 root', root=str(OUT), files=artifacts,
    count=len(artifacts), logical_bytes=sum(x['bytes'] for x in artifacts),
    disposition='Plan only; no cleanup executed. Source, commands, result logs and shared caches remain.'))
print('Only requested two tests completed; no further execution.', flush=True)
