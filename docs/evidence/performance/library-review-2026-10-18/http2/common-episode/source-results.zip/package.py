from pathlib import Path
import difflib,hashlib,json,statistics,subprocess,zipfile

ROOT=Path('/mnt/c/public/project-hyle/hyle')
HERE=ROOT/'.scratch/perf-review-2026-10-18/http2/common-episode'
OUT=Path('/root/hyle-scratch/http2-current-20261018/common-episode')

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def record(p):return dict(path=str(p),bytes=p.stat().st_size,sha256=sha(p))
def write(name,value):(HERE/name).write_text(json.dumps(value,indent=2)+'\n')

identity=json.loads((HERE/'build-identity.json').read_text())
for s in identity['sources']:
    assert sha(Path(s['path']))==s['sha256'],s
orders=[]
for name in ('ab','ba'):
    results=json.loads((HERE/(name+'.json')).read_text())['results']
    arms=[]
    for r in results:
        measurements=r['measurements']
        assert len(measurements)==9 and r['batch']==4
        med=statistics.median(m['elapsed'] for m in measurements)
        assert abs(med-r['median(elapsed)'])<1e-15
        arms.append(dict(name=r['name'],median_ns_per_episode=med*1e9,
            median_ns_per_stream=med*1e9/r['batch'],
            median_absolute_percent_error=r['medianAbsolutePercentError(elapsed)'],
            clock_resolution_seconds=r['clockResolution'],
            configured_min_epoch_seconds=r['minEpochTime'],
            epochs=[dict(iterations=m['iterations'],seconds_per_episode=m['elapsed'],
                actual_duration_seconds=m['elapsed']*m['iterations']) for m in measurements]))
    manual=next(a for a in arms if a['name']=='one Task manual loop')
    dual=next(a for a in arms if a['name']=='two endpoint Tasks')
    orders.append(dict(order=name,arms=arms,
        dual_slower_percent=(dual['median_ns_per_stream']/manual['median_ns_per_stream']-1)*100))

smokes=[json.loads(line) for line in (HERE/'smoke-startup-fixed.stdout.txt').read_text().splitlines() if line.startswith('{')]
assert len(smokes)==2
for s in smokes:
    assert s['completed']==4 and s['descriptors_closed']
    a,b=s['roles']
    assert a['send_bytes']+a['async_send_bytes']==b['recv_bytes']+b['async_recv_bytes']==1050124
    assert b['send_bytes']+b['async_send_bytes']==a['recv_bytes']+a['async_recv_bytes']
    assert b['send_bytes']+b['async_send_bytes']==(1050092 if s['mode']=='manual-1Task' else 1050027)
before=(HERE/'protocol.before-startup-fix.cc').read_text().splitlines(keepends=True)
after=(HERE/'protocol.cc').read_text().splitlines(keepends=True)
(HERE/'protocol-startup-fix.diff').write_text(''.join(difflib.unified_diff(before,after,fromfile='protocol.before-startup-fix.cc',tofile='protocol.cc')))
canonical=ROOT/'bench/io_http2/http2_p1_bench.cc'
(HERE/'canonical.applied.cc').write_bytes(canonical.read_bytes())
(HERE/'protocol-vs-canonical.diff').write_text(''.join(difflib.unified_diff(
    canonical.read_text().splitlines(keepends=True),after,
    fromfile='canonical.applied.cc',tofile='protocol.cc')))

cleanup=[record(p) for p in sorted(OUT.iterdir()) if p.is_file()]
assert {Path(x['path']).name for x in cleanup}=={'smoke','control','smoke.o','control.o'}
write('cleanup-candidates.json',dict(host='WSL',files=cleanup,total_bytes=sum(x['bytes'] for x in cleanup),
    note='Only these4 rebuildable artifacts from common-episode. No deletion performed. No cached dependency, current core override or helper object is part of this cleanup.'))
summary=dict(
    result='With common caller-owned Episode setup/teardown and the same raw protocol callbacks, two endpoint Tasks have higher point latency than one Task driving both endpoints in both fixed orders. This is a finite combined execution-policy control, not a replacement peer ranking or a pure context-switch measurement.',
    head_at_packaging=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),
    scope=dict(trace='Only4 streams x256KiB request and response, reverse completion in each pair, original connection-window holdout',
        processes=2,orders=['manual1Task then endpoints2Tasks','endpoints2Tasks then manual1Task'],
        epochs_per_arm=9,all36epochs_retained=True,extra_AA_shapes_or_formal_retries=False,
        product_or_canonical_modified_by_this_control=False,
        preformal=['Initial diagnostic smoke SIGSEGV preserved.',
            'One gdb reproduction reached the same uninitialized idle RawHarness state.',
            'After the exact startup-order fix, one complete diagnostic episode per driver passed.',
            'Formal counter-free executable also ran one complete warmup per arm per process.']),
    results=orders,
    common_responsibilities=[
        'Same caller-owned Episode contains two RawEndpoint, two RawWire and two adopted TcpStream owners; session initialization on caller in client/server order.',
        'Same socketpair options, nghttp2 callbacks/options/settings, headers, per-stream body buffers and complete byte oracle; reverse pair responses and separate stream/connection flow acknowledgments.',
        'Two RawWire each contain64KiB pending+64KiB input, zero-initialized by the same Episode construction in both arms; source total256KiB.',
        'Sessions and fd owners destroyed in the same common destructor after join; storage destructors and Task lifecycle included in timed episode.',
        'Workload strings and persistent one-worker Scheduler/IoContext plus idle RawHarness thread live outside both timed arms.'],
    deliberate_differences=[
        'One spawn_task+join with the original manual interleaving and poll fallback versus two endpoint spawn_task+join, endpoint-local progress cadence, adaptive yields, readiness-aware TcpStream async fallback and completion Event.',
        'Both arms now pay common TcpStream adoption and a caller-owned Episode; the original manual peer had no Task and used a separate worker. This control cannot replace that peer.',
        'The endpoint policy may issue different empty I/O operations and split wire chunks differently while preserving the same payload/protocol responsibility. These are part of the tested combined policy.',
        'Observed smoke server-to-client wire counts differ by65B. Neither actual control-frame composition nor terminal pending queue contents were recorded.'],
    diagnostic=dict(counters_compiletime_on_only_for_smoke=True,
        formal_nm_has_no_control_recv_send_or_active_counts=True,
        counters_owner_local_no_added_atomics_locks_QPC_or_worker=True,
        successful_smokes=smokes,
        wire_bytes_client_to_server=1050124,
        wire_bytes_server_to_client=dict(manual_1Task=1050092,endpoints_2Tasks=1050027),
        wire_difference='TwoTasks transferred65 fewer server-to-client wire bytes in the diagnostic episode. Payload, headers and consume/ack callback responsibilities are retained; actual control-frame composition was not decoded. Do not claim identical wire work or pureTask cost.',
        full_payload_bytes_each_direction=1048576,
        limits=['These counts are from one non-timed complete episode per driver, not the formal episodes.',
            'Direct recv/send wrappers count only the raw immediate seams; internal TcpStream/kernel async attempts are not counted. Async results record bytes and entry counts separately.',
            'Both final descriptor-closed checks happen after the common Episode destructor and only in diagnostic builds.',
            'Terminal RawWire begin/end, nghttp2_session_want_write and queued frame types were not recorded. No claim which frames account for65B.']),
    terminal_boundary=dict(
        manual='Loop exits when client.completed==4, then checks both endpoint.completed==4 and failure flags; no final want_write/drain check.',
        endpoints='Client exits at completed==4 and signals Event. Server waits for Event after all response pairs submitted, lastfirstresponse.output_done and its RawWire empty; both completed==4 checked after joins.',
        common='Both destroy sessions and transport owners after successful joins. Both source exit conditions permit nghttp2 control frames to remain queued; whether any actually remained was not recorded.',
        credit='Both arms execute the same raw_consume_readable callback loop: every consumed body chunk checks bytes and calls consume_stream and consume_connection. Emitting all terminal queued credit frames is not an additional completion requirement in either original boundary.'),
    source_and_cache=dict(fresh_TU='common-episode/main.cc includes frozen protocol.cc and split_advance.h; compiled twice with CONTROL_DIAGNOSTIC1/0',
        build_identity='build-identity.json',
        raw_nghttp2_not_Hyle_HTTP2=True,
        corrected_http2_object='Status-helper-fixed object is linked only to satisfy unused frozen original-benchmark symbols; the control does not call Hyle HTTP2 APIs.',
        current_core='ldd confirms current proactor override; other foundation shared libraries are retained cache, not wholeHEAD rebuild.',
        canonical_at_build=identity['canonical_peer'],
        canonical_applied=record(canonical),
        frozen_before_startup_fix=record(HERE/'protocol.before-startup-fix.cc'),
        frozen_after_startup_fix=record(HERE/'protocol.cc'),
        canonical_race_fix='Root applied the same worker_ declaration reorder independently; initialization-order comment differs. Other protocol-vs-canonical differences are the frozen stage8 diagnostic accessors and raw_write single_attempt seam.'),
    resources=dict(configured='caller + one Scheduler worker + same persistent idle RawHarness thread for both arms',
        cpu='WSL2 Intel i9-13900K, GCC14.2, taskset CPU2 inherited by created user threads',
        formal_command_affinity='taskset -c2 is recorded for both actual formal processes',
        limitations=['No in-interval actual TID/affinity or kernel-driver-thread snapshot was taken.',
            'metadata taskset pid0-31 belongs to the metadata parent, not formal; it is not backfilled as a formal snapshot.',
            'The IoContext backend was not printed in this control; no io_uring/epoll selection claim.']),
    failure=dict(cause='RawHarness starts worker_ before workload_/pending_/complete_/stopping_ are initialized; new idle worker entered run_raw with invalid workload. Episode had not started.',
        gdb='failed-smoke-gdb.stdout.txt',
        fix='Move only worker_ declaration after all state it reads. No driver, session, protocol or Episode semantics changed.',
        canonical_location='bench/io_http2/http2_p1_bench.cc classRawHarness formerly worker899 before fields900-904',
        failed_source='protocol.before-startup-fix.cc',failed_artifact_identity='failed-build-artifacts.json'),
    limitations=[
        'Only two fixed-order processes; no cross-process confidence interval, significance or general-equivalence claim.',
        'The observed delta includes Task count, join, progress/readiness cadence and yield strategy. It is not isolated fcontext cost or generic scheduler overhead.',
        'Do not subtract this delta from another round Hyle-versus-manual number to claim attribution of the previously observed16-17% residual.',
        'No Hyle HTTP2 public route runs here, so this does not remeasure the helper-fixed Hyle route.',
        'ClockResolution is nanobench sampled resolution metadata; actual epoch durations and cross-process variability are separate and all preserved.',
        'Hardware performance counters were disabled; JSON zero cycle/instruction fields are not measurements.'],
    cleanup=dict(manifest='cleanup-candidates.json',files=4,bytes=sum(x['bytes'] for x in cleanup),deleted=False))
write('summary.json',summary)
members=[p for p in sorted(HERE.iterdir()) if p.is_file() and p.suffix in ('.cc','.h','.py','.json','.txt','.diff') and p.name not in ('archive-record.json',)]
archive=HERE/'source-results.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for p in members:z.write(p,p.name)
with zipfile.ZipFile(archive) as z:assert z.testzip() is None
write('archive-record.json',dict(archive=record(archive),summary=record(HERE/'summary.json'),members=len(members),
    no_exe_obj_library_or_SDK=True))
print(json.dumps(dict(results=[dict(order=x['order'],dual_slower_percent=x['dual_slower_percent'],arms=[dict(name=a['name'],median_ns_per_stream=a['median_ns_per_stream']) for a in x['arms']]) for x in orders],archive=record(archive),members=len(members),cleanup_bytes=sum(x['bytes'] for x in cleanup)),indent=2))
