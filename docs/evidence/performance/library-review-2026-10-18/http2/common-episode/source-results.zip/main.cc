#include <sys/socket.h>
#include <unistd.h>
#include <cerrno>
#include <cstdint>
#include <cstdio>
#include <chrono>

#ifndef CONTROL_DIAGNOSTIC
#define CONTROL_DIAGNOSTIC 0
#endif
struct Counts {
  struct Role {
    std::uint64_t reads=0, read_ready=0, read_empty=0, read_bytes=0;
    std::uint64_t writes=0, write_ready=0, write_empty=0, write_bytes=0;
    std::uint64_t yields=0, async_reads=0, async_writes=0;
    std::uint64_t async_read_bytes=0, async_write_bytes=0;
  } role[2];
  int fd[2]{-1,-1};
  std::uint64_t polls=0;
};
#if CONTROL_DIAGNOSTIC
Counts* active_counts=nullptr;
Counts::Role* count_for(int fd) {
  if (!active_counts) return nullptr;
  for (unsigned r=0;r<2;++r) if (active_counts->fd[r]==fd) return &active_counts->role[r];
  return nullptr;
}
ssize_t control_recv(int fd,void* data,std::size_t n,int flags) {
  const ssize_t result=::recv(fd,data,n,flags);
  if (auto* c=count_for(fd)) {
    ++c->reads;
    if(result>0){++c->read_ready;c->read_bytes+=result;}
    else if(result<0 && (errno==EAGAIN || errno==EWOULDBLOCK))++c->read_empty;
  }
  return result;
}
ssize_t control_send(int fd,const void* data,std::size_t n,int flags) {
  const ssize_t result=::send(fd,data,n,flags);
  if(auto* c=count_for(fd)){
    ++c->writes;
    if(result>0){++c->write_ready;c->write_bytes+=result;}
    else if(result<0 && (errno==EAGAIN || errno==EWOULDBLOCK))++c->write_empty;
  }
  return result;
}
#define recv control_recv
#define send control_send
#endif
#define main original_benchmark_main
#include "protocol.cc"
#undef main
#if CONTROL_DIAGNOSTIC
#undef recv
#undef send
#endif
#include "split_advance.h"

namespace {
enum class Mode { Manual, Endpoints };
struct Episode {
  const Workload& workload;
  std::array<RawEndpoint,2> endpoint;
  std::array<RawWire,2> wire;
  std::array<TcpStream,2> socket;
  hyle::sched::Event client_consumed;
  bool failed=false;
  ~Episode(){
    for(unsigned r=0;r<2;++r){
      if(endpoint[r].session) nghttp2_session_del(endpoint[r].session);
      socket[r]=TcpStream{};
    }
  }
  int fail(){
    if(!failed){
      failed=true;
      for(auto& w:wire) if(w.descriptor>=0) (void)::shutdown(w.descriptor,SHUT_RDWR);
      client_consumed.signal();
    }
    return -1;
  }
};
bool server_flushed(const Episode& e){
  const auto& endpoint=e.endpoint[1]; const auto& wire=e.wire[1];
  const auto count=static_cast<std::size_t>(e.workload.streams);
  return endpoint.streams.size()==count && endpoint.next_response_pair==count &&
         endpoint.streams[count-2].output_done && wire.begin==wire.end;
}
Task<int> manual_driver(AllocatorRef,Episode* e) noexcept {
  auto& client=e->endpoint[0]; auto& server=e->endpoint[1];
  auto& cw=e->wire[0]; auto& sw=e->wire[1];
  // Original canonical manual ordering, now inside one Scheduler task.
  while(client.completed!=e->workload.streams && !client.failed && !server.failed){
    bool progress=false;
    if(!raw_advance(client,server,cw,sw) || !raw_fill_output(client,cw) ||
       !raw_fill_output(server,sw) || !raw_write(cw,progress) ||
       !raw_write(sw,progress) || !raw_read(client,cw,progress) ||
       !raw_read(server,sw,progress) || !raw_consume_readable(client,progress) ||
       !raw_consume_readable(server,progress)) co_return e->fail();
    if(progress) continue;
    pollfd descriptors[2]={{cw.descriptor,static_cast<short>(POLLIN|(cw.begin!=cw.end?POLLOUT:0)),0},
                          {sw.descriptor,static_cast<short>(POLLIN|(sw.begin!=sw.end?POLLOUT:0)),0}};
    int ready;
    do {
#if CONTROL_DIAGNOSTIC
      ++active_counts->polls;
#endif
      ready=::poll(descriptors,2,5000);
    }while(ready<0 && errno==EINTR);
    if(ready<=0) co_return e->fail();
  }
  if(client.failed || server.failed || client.completed!=e->workload.streams ||
     server.completed!=e->workload.streams) co_return e->fail();
  co_return e->workload.streams;
}
bool feed_async(RawEndpoint& endpoint,RawWire& wire,hyle::io::TransferResult result){
  if(!result.ok() || result.eof || !result.bytes || result.bytes>wire.input.size()) return false;
  if(nghttp2_session_mem_recv2(endpoint.session,wire.input.data(),result.bytes)!=
     static_cast<nghttp2_ssize>(result.bytes)) return false;
  bool progress=false;
  return raw_consume_readable(endpoint,progress);
}
Task<int> endpoint_driver(AllocatorRef,Episode* e,unsigned role) noexcept {
  auto& endpoint=e->endpoint[role]; auto& wire=e->wire[role]; auto& socket=e->socket[role];
  // Sessions and transports belong to the common caller, not this Task frame.
  for(;;){
    if(e->failed || endpoint.failed) co_return e->fail();
    if(role==0 && endpoint.completed==e->workload.streams){
      e->client_consumed.signal(); co_return e->workload.streams;
    }
    if(role==1 && server_flushed(*e)){
      if(!e->client_consumed.wait_for(std::chrono::seconds(5)) || e->failed ||
         endpoint.completed!=e->workload.streams) co_return e->fail();
      co_return e->workload.streams;
    }
    if(!(role==0?advance_client(endpoint,wire):advance_server(endpoint,wire)) ||
       !raw_fill_output(endpoint,wire)) co_return e->fail();
    bool written=false;
    if(!raw_write(wire,written)) co_return e->fail();
    if(role==1 && server_flushed(*e)) continue;
    if(written && wire.begin==wire.end) continue;
    bool progress=false;
    if(!raw_read(endpoint,wire,progress) || !raw_consume_readable(endpoint,progress)) co_return e->fail();
    if(progress) continue;
#if CONTROL_DIAGNOSTIC
    ++active_counts->role[role].yields;
#endif
    hyle::sched::Fiber::yield();
    if(e->failed) co_return e->fail();
    progress=false;
    if(!raw_read(endpoint,wire,progress) || !raw_consume_readable(endpoint,progress)) co_return e->fail();
    if(progress) continue;
    if(wire.begin!=wire.end){
      written=false;
      if(!raw_write(wire,written,true)) co_return e->fail();
      if(written) continue;
#if CONTROL_DIAGNOSTIC
      ++active_counts->role[role].async_writes;
#endif
      const auto result=co_await socket.write_some(std::span<const std::byte>(
          reinterpret_cast<const std::byte*>(wire.pending.data()+wire.begin),wire.end-wire.begin),
          hyle::io::OperationOptions{});
#if CONTROL_DIAGNOSTIC
      active_counts->role[role].async_write_bytes+=result.bytes;
#endif
      if(!result.ok() || !result.bytes || result.bytes>wire.end-wire.begin) co_return e->fail();
      wire.begin+=result.bytes;
      if(wire.begin==wire.end) wire.begin=wire.end=0;
    }else{
#if CONTROL_DIAGNOSTIC
      ++active_counts->role[role].async_reads;
#endif
      const auto result=co_await socket.read_some(std::span<std::byte>(
          reinterpret_cast<std::byte*>(wire.input.data()),wire.input.size()),hyle::io::OperationOptions{});
#if CONTROL_DIAGNOSTIC
      active_counts->role[role].async_read_bytes+=result.bytes;
#endif
      if(!feed_async(endpoint,wire,result)) co_return e->fail();
    }
  }
}
int run_common(HyleHarness& harness,const Workload& workload,Mode mode,
               bool check_descriptors=false,Counts* counts=nullptr){
  std::array<int,2> descriptors{-1,-1};
  int outcome=-1;
  {
    // Identical caller-owned allocations, initialization and lifetime in both modes.
    Episode e{workload};
    auto pair=make_socket_pair(); if(!pair.valid()) return -1;
    auto client=TcpStream::adopt(harness.diagnostic_io(),kOwner,pair.release_client());
    auto server=TcpStream::adopt(harness.diagnostic_io(),kOwner,pair.release_server());
    if(!client || !server) return -1;
    e.socket[0]=std::move(*client);e.socket[1]=std::move(*server);
    for(unsigned role=0;role<2;++role){
      e.endpoint[role].workload=&workload;e.endpoint[role].server=role==1;
      e.endpoint[role].streams.reserve(workload.streams);
      descriptors[role]=e.wire[role].descriptor=static_cast<int>(e.socket[role].native_handle());
      if(!raw_initialize(e.endpoint[role])) return -1;
    }
#if CONTROL_DIAGNOSTIC
    active_counts=counts;
    for(unsigned r=0;r<2;++r) counts->fd[r]=descriptors[r];
#else
    (void)counts;
#endif
    if(mode==Mode::Manual){
      auto joined=hyle::sched::spawn_task(harness.diagnostic_scheduler(),system_allocator(),
          manual_driver(system_allocator(),&e));
      auto result=joined.join();
      if(result && *result==workload.streams) outcome=*result;
    }else{
      auto server_join=hyle::sched::spawn_task(harness.diagnostic_scheduler(),system_allocator(),
          endpoint_driver(system_allocator(),&e,1));
      auto client_join=hyle::sched::spawn_task(harness.diagnostic_scheduler(),system_allocator(),
          endpoint_driver(system_allocator(),&e,0));
      auto client_result=client_join.join();auto server_result=server_join.join();
      if(client_result && server_result && *client_result==workload.streams &&
         *server_result==workload.streams) outcome=workload.streams;
    }
    if(e.failed || e.endpoint[0].completed!=workload.streams ||
       e.endpoint[1].completed!=workload.streams) outcome=-1;
  }
#if CONTROL_DIAGNOSTIC
  active_counts=nullptr;
#endif
  if(check_descriptors) for(int fd:descriptors){
    errno=0;if(::fcntl(fd,F_GETFD)!=-1 || errno!=EBADF) return -1;
  }
  return outcome;
}
#if CONTROL_DIAGNOSTIC
void print_counts(const char* mode,const Counts& c){
  std::printf("{\"mode\":\"%s\",\"completed\":4,\"descriptors_closed\":true,\"polls\":%llu,\"roles\":[",mode,
      static_cast<unsigned long long>(c.polls));
  for(unsigned r=0;r<2;++r){const auto& v=c.role[r];
    std::printf("%s{\"role\":%u,\"recv_calls\":%llu,\"recv_ready\":%llu,\"recv_empty\":%llu,\"recv_bytes\":%llu,"
      "\"send_calls\":%llu,\"send_ready\":%llu,\"send_empty\":%llu,\"send_bytes\":%llu,\"yields\":%llu,"
      "\"async_reads\":%llu,\"async_writes\":%llu,\"async_recv_bytes\":%llu,\"async_send_bytes\":%llu}",r?",":"",r,
      (unsigned long long)v.reads,(unsigned long long)v.read_ready,(unsigned long long)v.read_empty,(unsigned long long)v.read_bytes,
      (unsigned long long)v.writes,(unsigned long long)v.write_ready,(unsigned long long)v.write_empty,(unsigned long long)v.write_bytes,
      (unsigned long long)v.yields,(unsigned long long)v.async_reads,(unsigned long long)v.async_writes,
      (unsigned long long)v.async_read_bytes,(unsigned long long)v.async_write_bytes);
  }
  std::printf("]}\n");
}
#endif
} // namespace
int main(int argc,char**argv){
  std::signal(SIGPIPE,SIG_IGN);
  const auto workload=make_workload("HTTP2 common Episode 1Task vs2Tasks 4x256KiB",4,256*1024,256*1024,
                                    NGHTTP2_INITIAL_CONNECTION_WINDOW_SIZE);
  HyleHarness harness; RawHarness inactive_manual_thread;
#if CONTROL_DIAGNOSTIC
  if(argc!=2 || std::string_view(argv[1])!="smoke") return 2;
  for(auto mode:{Mode::Manual,Mode::Endpoints}){
    Counts counts;
    if(run_common(harness,workload,mode,true,&counts)!=4) return 3;
    print_counts(mode==Mode::Manual?"manual-1Task":"endpoint-2Tasks",counts);
  }
  return 0;
#else
  if(argc!=3 || (std::string_view(argv[1])!="ab" && std::string_view(argv[1])!="ba")) return 2;
  const bool endpoints_first=std::string_view(argv[1])=="ba";
  auto manual=[&]{if(run_common(harness,workload,Mode::Manual)!=4)std::abort();};
  auto dual=[&]{if(run_common(harness,workload,Mode::Endpoints)!=4)std::abort();};
  if(endpoints_first){dual();manual();}else{manual();dual();}
  ankerl::nanobench::Bench bench;
  bench.title(workload.title).relative(true).batch(4).unit("stream")
      .performanceCounters(false).minEpochTime(std::chrono::milliseconds(10)).minEpochIterations(5).epochs(9);
  if(endpoints_first){bench.run("two endpoint Tasks",dual);bench.run("one Task manual loop",manual);}
  else{bench.run("one Task manual loop",manual);bench.run("two endpoint Tasks",dual);}
  std::ofstream output(argv[2]);if(!output)return 4;
  bench.render(ankerl::nanobench::templates::json(),output);return output?0:4;
#endif
}
