from pathlib import Path
import json,os,subprocess
HERE=Path('/mnt/c/public/project-hyle/hyle/.scratch/perf-review-2026-10-18/http2/common-episode')
OUT=Path('/root/hyle-scratch/http2-current-20261018/common-episode')
env=os.environ.copy()
env['LD_LIBRARY_PATH']='/root/hyle-scratch/http2-current-20261018/current-holdout:/root/hyle-scratch/io-watch-v2-dev/bin'
argv=['taskset','-c','2','gdb','-q','-batch','-ex','run','-ex','thread apply all bt','-ex','x/12i $pc-20','--args',str(OUT/'smoke'),'smoke']
p=subprocess.run(argv,cwd=OUT,env=env,capture_output=True,text=True,timeout=30)
(HERE/'failed-smoke-gdb.stdout.txt').write_text(p.stdout)
(HERE/'failed-smoke-gdb.stderr.txt').write_text(p.stderr)
(HERE/'failed-smoke-gdb-command.json').write_text(json.dumps(dict(argv=argv,environment={'LD_LIBRARY_PATH':env['LD_LIBRARY_PATH']},exit=p.returncode),indent=2)+'\n')
print(p.stdout);print(p.stderr)
