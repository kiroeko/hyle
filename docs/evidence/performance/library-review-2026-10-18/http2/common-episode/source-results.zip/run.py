from pathlib import Path
import hashlib, json, os, subprocess, sys, time

ROOT=Path('/mnt/c/public/project-hyle/hyle')
HERE=ROOT/'.scratch/perf-review-2026-10-18/http2/common-episode'
BASE=Path('/root/hyle-scratch/http2-current-20261018')
OUT=BASE/'common-episode'
CORE=BASE/'current-holdout'
CACHE=Path('/root/hyle-scratch/io-watch-v2-dev')
ENV=os.environ.copy()
ENV['LD_LIBRARY_PATH']=str(CORE)+':'+str(CACHE/'bin')
COMMANDS=HERE/'commands.json'
records=json.loads(COMMANDS.read_text()) if COMMANDS.exists() else []

def record(p):
    return dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())

def run(name,argv,timeout=60):
    if any(x['name']==name for x in records):
        raise RuntimeError('Refusing to overwrite existing attempt: '+name)
    argv=list(map(str,argv))
    start=time.time()
    p=subprocess.run(argv,cwd=OUT,env=ENV,capture_output=True,text=True,timeout=timeout)
    (HERE/(name+'.stdout.txt')).write_text(p.stdout)
    (HERE/(name+'.stderr.txt')).write_text(p.stderr)
    records.append(dict(name=name,argv=argv,cwd=str(OUT),exit=p.returncode,
        started_unix=start,elapsed_seconds=time.time()-start,
        environment={k:v for k,v in ENV.items() if k.startswith(('LD_LIBRARY_PATH','HYLE_'))}))
    COMMANDS.write_text(json.dumps(records,indent=2)+'\n')
    print(name,p.returncode,p.stdout[-2500:],p.stderr[-1000:],flush=True)
    if p.returncode: raise RuntimeError(name)
    return p.stdout

phase=sys.argv[1]
if phase in ('build','build-fixed'):
    suffix='-startup-fixed' if phase=='build-fixed' else ''
    OUT.mkdir(exist_ok=True)
    prior=json.loads((HERE.parent/'current-build-commands.json').read_text())
    compile=next(x['argv'] for x in prior if x['name']=='bench_io_http2_http2_p1_bench.cc')
    link=next(x['argv'] for x in prior if x['name']=='link')
    for variant,macro in [('smoke',1),('control',0)]:
        obj=OUT/(variant+'.o')
        run('compile-'+variant+suffix,compile[:-4]+['-DCONTROL_DIAGNOSTIC='+str(macro),'-c',HERE/'main.cc','-o',obj])
        argv=[str(OUT/variant) if x==str(BASE/'http2_current') else
              str(BASE/'fixed-send-frame/http2.o') if x==str(BASE/'src_io_http2_http2.cc.o') else
              str(obj) if x==str(BASE/'bench_io_http2_http2_p1_bench.cc.o') else x for x in link]
        run('link-'+variant+suffix,argv)
    loader=run('loader'+suffix,['ldd',OUT/'control'])
    assert str(CORE/'libhyle_io_core.so.0.1.0') in loader
    run('smoke'+suffix,['taskset','-c','2','timeout','--kill-after=2s','20s',OUT/'smoke','smoke'])
    symbols=run('formal-symbols'+suffix,['nm','-C',OUT/'control.o'])
    assert not any(x in symbols for x in ('control_recv(', 'control_send(', 'active_counts'))
    inputs={Path(x) for x in argv if x.endswith(('.o','.a'))}
    inputs.add(BASE/'fixed-send-frame/http2.o')
    for line in loader.splitlines():
        if 'libhyle_' in line and '=>' in line:
            inputs.add(Path(line.split('=>',1)[1].strip().split()[0]))
    metadata=run('metadata',['bash','-c','uname -a; g++-14 --version; taskset -pc $$; lscpu'])
    (HERE/'build-identity.json').write_text(json.dumps(dict(
        sources=[record(HERE/x) for x in ('main.cc','protocol.cc','split_advance.h','run.py')],
        canonical_peer=record(ROOT/'bench/io_http2/http2_p1_bench.cc'),
        applied_http2=record(ROOT/'src/io_http2/http2.cc'),
        current_proactor=record(ROOT/'src/io_core/proactor.cc'),
        linked_inputs=[record(p) for p in sorted(inputs)],
        artifacts=[record(p) for p in sorted(OUT.iterdir()) if p.is_file()],
        notes=['Only common main TU freshly compiled with CONTROL_DIAGNOSTIC=1/0.',
               'Control exercises raw nghttp2, not Hyle HTTP2 public APIs; helper-fixed http2.o linked only for unused frozen original bench symbols.',
               'Current proactor override resolved by LD_LIBRARY_PATH. Other foundation libraries are retained cache, not whole-HEAD rebuild.',
               'Metadata process affinity is not formal snapshot. Each smoke/formal command explicitly taskset CPU2.']),indent=2)+'\n')
elif phase=='formal':
    if not any(x['name'].startswith('smoke') and x['exit']==0 for x in records):
        raise RuntimeError('Successful smoke required')
    if any(x['name'] in ('formal-ab','formal-ba') for x in records):
        raise RuntimeError('Formal attempts already exist; no retries')
    for order in ('ab','ba'):
        run('formal-'+order,['taskset','-c','2','timeout','--kill-after=2s','30s',OUT/'control',order,HERE/(order+'.json')])
else:
    raise RuntimeError('unknown phase')
