from pathlib import Path
import hashlib
import json
import zipfile

root=Path(__file__).resolve().parents[3]
out=Path(__file__).resolve().parent
dest=root/'docs/evidence/performance/library-review-2026-10-18/http2/phase-costs'
summary=json.loads((dest/'summary.json').read_text(encoding='utf-8'))
log=(out/'cleanup-executed.log').read_text(encoding='utf-8-sig')
completed=json.loads(log.splitlines()[-1])
assert completed==dict(status='completed',deleted_files=4,deleted_bytes=2207600,retained_files_verified=7,directories_removed=0)
summary['independent_recalculation']='Separate read-only agent recomputed all60 phase blocks and72 ablation blocks from raw cells: exact sums, arithmetic differences, medians, arm medians and paired log-ratio/GM/range/IQR/counters matched. No new measurements or code changes.'
with zipfile.ZipFile(dest/'cleanup.zip','x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
    archive.write(root/'test.ps1','test.ps1')
    for name in ('cleanup-executed.log','write_cleanup.py','finalize.py','artifact-plan.json'):
        archive.write(out/name,name)
summary['cleanup_execution']=completed
summary['cleanup_archive']={'bytes':(dest/'cleanup.zip').stat().st_size,'sha256':hashlib.sha256((dest/'cleanup.zip').read_bytes()).hexdigest()}
(dest/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
for path in dest.glob('*.zip'):
    with zipfile.ZipFile(path) as archive:
        assert archive.testzip() is None
print('Evidence finalized; four generated files removed, seven current caches verified. Product unchanged.')
