# One-time exact cleanup after HTTP2 phase-cost diagnosis. Already frozen sources/raw/maps remain.
$ErrorActionPreference = 'Stop'
$archive = Join-Path $PSScriptRoot 'docs/evidence/performance/library-review-2026-10-18/http2/phase-costs/source-results.zip'
if ((Get-FileHash -LiteralPath $archive -Algorithm SHA256).Hash.ToLowerInvariant() -ne '90bc965be470a838fd4cfe9168f70e8114414a765d540c26a2072c2b653c7c39') { throw 'Frozen evidence archive mismatch' }
$pythonSource = @'
import hashlib, json, os, stat
from pathlib import Path
root=Path('/root/hyle-scratch/http2-current-20261018')
targets = [
    (Path('/root/hyle-scratch/http2-current-20261018/phase-costs/consumer.o'), 168360, '70d86b7998b1ff82741443784e7a96501c4175d864c312f883665317363a8c8d'),
    (Path('/root/hyle-scratch/http2-current-20261018/phase-costs/probe'), 915904, '1322c68b21d6a69d9b4f623b57f99d5d39ff7abf2e6b568167ce1340b9400c7a'),
    (Path('/root/hyle-scratch/http2-current-20261018/phase-costs/owner-check-disabled.o'), 224824, 'ab2aea7c358c5ced3ac82ddb83166cd04278bf8788636449a0c0223c98f80338'),
    (Path('/root/hyle-scratch/http2-current-20261018/phase-costs/owner-check-disabled'), 898512, 'b10f4926157f3d50073cf28bf3b1504fcff6c4d8035962f6df71e14cf0f794dd'),
]
retained = [
    (Path('/root/hyle-scratch/http2-current-20261018/current-holdout/libhyle_io_core.so.0.1.0'), 387104, '9ead235b1bbd72f56d44eab9c8ac135b8c4b0ce0ec0a6fb72660aa917d3b4779'),
    (Path('/root/hyle-scratch/http2-current-20261018/owner-loop/http2.o'), 225824, '7c214427285e21da16dab647d0b5793b8b209554bf5f8d3ef20d4435653aa82e'),
    (Path('/root/hyle-scratch/http2-current-20261018/owner-loop/http2_test.o'), 739800, '7ffb3dac38465532c8980032a5f3dbee401ac7feec915f51c26eeb2ddd879f5c'),
    (Path('/root/hyle-scratch/http2-current-20261018/owner-loop/layout-new'), 898496, '3123e43a9c4e015241242673b9dc90d7c6d4ca26f72408ef53b5690cd29e4870'),
    (Path('/root/hyle-scratch/http2-current-20261018/owner-loop/tests-candidate'), 1618552, '97a8e618a6db7c621e770e37f349313f0ffeda99b7b66334016a96c3db52991a'),
    (Path('/root/hyle-scratch/http2-current-20261018/paired-comparison-v2/nanobench.o'), 283672, '43b16d764541dc1460c6aba273360f40403bcc35ee2feb37461f7f4d29984987'),
    (Path('/root/hyle-scratch/http2-current-20261018/root-cause-product/consumer.o'), 151104, '62a132158e443d6fae3df9c9ea8b4ccba19e71a21aeac9ffef6042d03df5b2b2'),
]

assert root.resolve(strict=True)==root
assert len({item[0] for item in targets+retained})==len(targets)+len(retained)
def inspect(item):
    path,size,digest=item
    assert path.is_absolute() and path.is_relative_to(root)
    part=Path(path.anchor)
    for name in path.parts[1:]:
        part/=name
        assert not stat.S_ISLNK(part.lstat().st_mode), str(part)
    assert path.resolve(strict=True)==path
    before=path.lstat()
    assert stat.S_ISREG(before.st_mode) and before.st_size==size
    with os.fdopen(os.open(path,os.O_RDONLY|os.O_NOFOLLOW),'rb') as source:
        opened=os.fstat(source.fileno())
        assert (opened.st_dev,opened.st_ino)==(before.st_dev,before.st_ino)
        actual=hashlib.sha256(source.read()).hexdigest()
        after=os.fstat(source.fileno())
    now=path.lstat()
    assert actual==digest and after.st_size==size
    assert (now.st_dev,now.st_ino,now.st_size)==(after.st_dev,after.st_ino,after.st_size)
    return now.st_dev,now.st_ino
identities={item[0]:inspect(item) for item in targets+retained}
for proc in Path('/proc').iterdir():
    if not proc.name.isdigit(): continue
    try: executable=os.readlink(proc/'exe')
    except (OSError,PermissionError): continue
    assert executable not in {str(item[0]) for item in targets}, 'Target still running: '+proc.name
print(json.dumps({'preflight_delete_files':len(targets),'delete_bytes':sum(item[1] for item in targets),'retain_files':len(retained)}),flush=True)
for item in targets:
    assert inspect(item)==identities[item[0]]
    item[0].unlink()
    print('Deleted exact generated file: '+str(item[0]),flush=True)
for item in retained:
    assert inspect(item)==identities[item[0]]
print(json.dumps({'status':'completed','deleted_files':len(targets),'deleted_bytes':sum(item[1] for item in targets),'retained_files_verified':len(retained),'directories_removed':0}),flush=True)
'@
$payload = [Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes($pythonSource))
$code = 'import base64;exec(base64.b64decode("' + $payload + '"))'
& wsl.exe -d Ubuntu-24.04 -u root --exec python3 -c $code
if ($LASTEXITCODE -ne 0) { throw "Exact WSL cleanup failed: $LASTEXITCODE" }
