"""Write a new exact, archive-guarded cleanup to the user-requested test.ps1."""
from pathlib import Path
import hashlib
import json

root=Path(__file__).resolve().parents[3]
out=Path(__file__).resolve().parent
plan=json.loads((out/'artifact-plan.json').read_text(encoding='utf-8'))
archive=root/'docs/evidence/performance/library-review-2026-10-18/http2/phase-costs/source-results.zip'
digest=hashlib.sha256(archive.read_bytes()).hexdigest()
payload='''import hashlib, json, os, stat
from pathlib import Path
root=Path('/root/hyle-scratch/http2-current-20261018')
'''
for key,values in [('targets',plan['delete']),('retained',plan['retain'])]:
    payload+=key+' = [\n'
    for item in values:
        assert item['path'].startswith('/root/hyle-scratch/http2-current-20261018/')
        payload+=f"    (Path({item['path']!r}), {item['bytes']}, {item['sha256']!r}),\n"
    payload+=']\n'
payload+='''
assert root.resolve(strict=True)==root
assert len({item[0] for item in targets+retained})==len(targets)+len(retained)
def inspect(item):
    path,size,digest=item
    assert path.is_absolute() and path.is_relative_to(root)
    part=Path(path.anchor)
    for name in path.parts[1:]:
        part/=name
        assert not stat.S_ISLNK(part.lstat().st_mode), str(part)
    assert path.resolve(strict=True)==path
    before=path.lstat()
    assert stat.S_ISREG(before.st_mode) and before.st_size==size
    with os.fdopen(os.open(path,os.O_RDONLY|os.O_NOFOLLOW),'rb') as source:
        opened=os.fstat(source.fileno())
        assert (opened.st_dev,opened.st_ino)==(before.st_dev,before.st_ino)
        actual=hashlib.sha256(source.read()).hexdigest()
        after=os.fstat(source.fileno())
    now=path.lstat()
    assert actual==digest and after.st_size==size
    assert (now.st_dev,now.st_ino,now.st_size)==(after.st_dev,after.st_ino,after.st_size)
    return now.st_dev,now.st_ino
identities={item[0]:inspect(item) for item in targets+retained}
for proc in Path('/proc').iterdir():
    if not proc.name.isdigit(): continue
    try: executable=os.readlink(proc/'exe')
    except (OSError,PermissionError): continue
    assert executable not in {str(item[0]) for item in targets}, 'Target still running: '+proc.name
print(json.dumps({'preflight_delete_files':len(targets),'delete_bytes':sum(item[1] for item in targets),'retain_files':len(retained)}),flush=True)
for item in targets:
    assert inspect(item)==identities[item[0]]
    item[0].unlink()
    print('Deleted exact generated file: '+str(item[0]),flush=True)
for item in retained:
    assert inspect(item)==identities[item[0]]
print(json.dumps({'status':'completed','deleted_files':len(targets),'deleted_bytes':sum(item[1] for item in targets),'retained_files_verified':len(retained),'directories_removed':0}),flush=True)
'''
script=f'''# One-time exact cleanup after HTTP2 phase-cost diagnosis. Already frozen sources/raw/maps remain.
$ErrorActionPreference = 'Stop'
$archive = Join-Path $PSScriptRoot 'docs/evidence/performance/library-review-2026-10-18/http2/phase-costs/source-results.zip'
if ((Get-FileHash -LiteralPath $archive -Algorithm SHA256).Hash.ToLowerInvariant() -ne '{digest}') {{ throw 'Frozen evidence archive mismatch' }}
$pythonSource = @'
{payload}'@
$payload = [Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes($pythonSource))
$code = 'import base64;exec(base64.b64decode("' + $payload + '"))'
& wsl.exe -d Ubuntu-24.04 -u root --exec python3 -c $code
if ($LASTEXITCODE -ne 0) {{ throw "Exact WSL cleanup failed: $LASTEXITCODE" }}
'''
(root/'test.ps1').write_text(script,encoding='utf-8',newline='\n')
print('Wrote new test.ps1; not executed.',len(plan['delete']),sum(item['bytes'] for item in plan['delete']))
