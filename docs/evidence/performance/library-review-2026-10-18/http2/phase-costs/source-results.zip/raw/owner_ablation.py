"""Falsify the dynamic-owner-check hypothesis. Intentionally invalid API mutant, never a product candidate."""
from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys

root = Path('/mnt/c/public/project-hyle/hyle')
out = Path(__file__).resolve().parent
remote = Path('/root/hyle-scratch/http2-current-20261018/phase-costs')
env = dict(os.environ, LD_LIBRARY_PATH='/root/hyle-scratch/http2-current-20261018/current-holdout:/root/hyle-scratch/io-watch-v2-dev/bin', LC_ALL='C')

def identity(path):
    path = Path(path)
    return {'path': str(path), 'bytes': path.stat().st_size, 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}

def execute(name, command):
    dest = out / (name + '.command.json')
    assert not dest.exists()
    record = {'argv': list(map(str,command)), 'cwd': str(remote), 'environment': {'LD_LIBRARY_PATH': env['LD_LIBRARY_PATH'], 'LC_ALL':'C'}}
    dest.write_text(json.dumps(record, indent=2)+'\n')
    with (out/(name+'.stdout.txt')).open('wb') as stdout, (out/(name+'.stderr.txt')).open('wb') as stderr:
        process = subprocess.run(record['argv'], cwd=remote, env=env, stdout=stdout, stderr=stderr, timeout=60)
    record['returncode'] = process.returncode
    dest.write_text(json.dumps(record, indent=2)+'\n')
    assert process.returncode == 0, name

def build():
    source = root/'src/io_http2/http2.cc'
    assert identity(source)['sha256'] == '30b57207730af05b29e3037d22427b67d35df6f5c4b69a1f99846c9630e6482f'
    text = source.read_text()
    removed = '''  if (sched::current_worker_index() !=
      static_cast<int>(state.transport_owner))
    return Status::FailedPrecondition(
        "HTTP/2 operation must run on transport owner worker");
'''
    assert text.count(removed) == 1
    mutant = out/'owner-check-disabled.cc'
    assert not mutant.exists()
    mutant.write_text(text.replace(removed, '  // DIAGNOSTIC ONLY: dynamic worker identity guard removed.\n'))
    previous = json.loads((out.parent/'http2-owner-loop/build.json').read_text())
    compile_command = previous['commands'][0]['argv'][:]
    compile_command[compile_command.index('-c')+1] = str(mutant)
    compile_command[compile_command.index('-o')+1] = str(remote/'owner-check-disabled.o')
    execute('ablation-compile', compile_command)
    prior = json.loads((out.parent/'http2-owner-loop/common-layout.json').read_text())
    link_command = prior['commands'][1]['argv'][:]
    original = '/root/hyle-scratch/http2-current-20261018/owner-loop/layout-new'
    link_command = [str(remote/'owner-check-disabled') if s==original else
                    '-Wl,-Map,'+str(remote/'owner-check-disabled.map') if s=='-Wl,-Map,'+original+'.map' else
                    str(remote/'owner-check-disabled.o') if s=='/root/hyle-scratch/http2-current-20261018/owner-loop/http2.o' else s for s in link_command]
    execute('ablation-link', link_command)
    baseline = Path(original)
    assert identity(baseline)['sha256'] == '3123e43a9c4e015241242673b9dc90d7c6d4ca26f72408ef53b5690cd29e4870'
    keys = ('nghttp2_session_mem_recv2', 'nghttp2_session_mem_send2', 'raw_task_endpoint', 'raw_data_chunk', 'hyle_server', 'hyle_client', 'HyleHarness::run')
    symbols = {}
    for label, binary in [('baseline',baseline), ('ablation',remote/'owner-check-disabled')]:
        lines = subprocess.check_output(['nm','-n','-C',str(binary)], text=True).splitlines()
        symbols[label] = {key:[s for s in lines if key in s] for key in keys}
    assert symbols['baseline'] == symbols['ablation']
    (out/'ablation-build.json').write_text(json.dumps({'warning':'Intentionally removes required runtime owner validation. Diagnostic only, not a correct product or optimization candidate.', 'removed':removed, 'inputs':[identity(source),identity(mutant),identity(baseline)], 'artifacts':[identity(remote/p) for p in ('owner-check-disabled.o','owner-check-disabled','owner-check-disabled.map')], 'common_symbols':symbols, 'same_common_addresses':True}, indent=2)+'\n')

def run():
    sys.path.insert(0,str(root/'bench/io_http2'))
    from run_paired import summarize,machine_metadata
    baseline=Path('/root/hyle-scratch/http2-current-20261018/owner-loop/layout-new')
    ablation=remote/'owner-check-disabled'
    schedule=[('self-before',baseline,'paired-self'), ('baseline-1',baseline,'paired'), ('disabled-1',ablation,'paired'), ('disabled-2',ablation,'paired'), ('baseline-2',baseline,'paired'), ('self-after',baseline,'paired-self')]
    record={'hypothesis':'If dynamic worker-identity validation explains most of the residual, removing just that guard should consistently collapse the Hyle/reference gap in this normal owner trace.',
            'limit':'Intentionally invalid owner semantics; full normal-trace oracle is necessary but does not validate the mutant as a product. Guard query/branch removal can alter product-internal layout. Shared benchmark/native hot symbol addresses matched. No elapsed subtraction across different rounds.',
            'machine':machine_metadata(2,os.sched_getaffinity(0)), 'schedule':[(n,str(p),m) for n,p,m in schedule], 'runs':[]}
    assert not (out/'ablation-plan.json').exists()
    (out/'ablation-plan.json').write_text(json.dumps(record,indent=2)+'\n')
    for name,binary,mode in schedule:
        execute('ablation-'+name,['taskset','-c','2',binary,'--'+mode])
        result=summarize((out/('ablation-'+name+'.stdout.txt')).read_text(),mode,2)
        record['runs'].append({'name':name,'result':result})
        (out/'ablation-summary.json').write_text(json.dumps(record,indent=2)+'\n')
        print(name,result['median_ratio_percent'],flush=True)
    record['status']='completed'
    (out/'ablation-summary.json').write_text(json.dumps(record,indent=2)+'\n')

{'build':build,'run':run}[sys.argv[1]]()
