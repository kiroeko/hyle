from pathlib import Path
import hashlib
import json
import math
import os
import statistics
import subprocess
import sys

root = Path('/mnt/c/public/project-hyle/hyle')
out = Path(__file__).resolve().parent
remote = Path('/root/hyle-scratch/http2-current-20261018/phase-costs')
base = json.loads((out.parent / 'http2-paired-run/attempt-2/build.json').read_text())
env = dict(os.environ, **base['environment'], LC_ALL='C')

def identity(path):
    path = Path(path)
    return dict(path=str(path), bytes=path.stat().st_size,
                sha256=hashlib.sha256(path.read_bytes()).hexdigest())

def execute(name, command, timeout=60):
    record = {'argv': list(map(str, command)), 'cwd': str(remote),
              'environment': {k: env[k] for k in ('LD_LIBRARY_PATH', 'LC_ALL')}}
    dest = out / (name + '.command.json')
    assert not dest.exists()
    dest.write_text(json.dumps(record, indent=2)+'\n')
    with (out / (name + '.stdout.txt')).open('wb') as stdout, (out / (name + '.stderr.txt')).open('wb') as stderr:
        p = subprocess.run(record['argv'], cwd=remote, env=env, stdout=stdout, stderr=stderr, timeout=timeout)
    record['returncode'] = p.returncode
    dest.write_text(json.dumps(record, indent=2)+'\n')
    assert p.returncode == 0, name

def build():
    remote.mkdir(exist_ok=False)
    compile_args = next(c['argv'] for c in base['commands'] if c['name'] == 'compile-consumer')
    compile_args[compile_args.index('-c')+1] = str(out / 'probe.cc')
    compile_args[compile_args.index('-o')+1] = str(remote / 'consumer.o')
    execute('compile', compile_args)
    common = [remote / 'consumer.o', '/root/hyle-scratch/http2-current-20261018/src_io_http_http.cc.o',
              '/root/hyle-scratch/http2-current-20261018/src_io_http2_feature.cc.o',
              '/root/hyle-scratch/http2-current-20261018/picohttpparser.o',
              '/root/hyle-scratch/http2-current-20261018/paired-comparison-v2/nanobench.o']
    product = Path('/root/hyle-scratch/http2-current-20261018/owner-loop/http2.o')
    assert identity(product)['sha256'] == '7c214427285e21da16dab647d0b5793b8b209554bf5f8d3ef20d4435653aa82e'
    native = '/root/hyle-scratch/http2-current-20261018/nghttp2-build/lib/libnghttp2.a'
    old_link = next(c['argv'] for c in base['commands'] if c['name'] == 'link')
    tail = old_link[old_link.index('-L/root/hyle-scratch/io-watch-v2-dev/bin'):]
    link = ['g++-14', '-pthread', '-o', remote / 'probe', '-Wl,-Map,'+str(remote / 'probe.map')] + common + ['-Wl,--whole-archive', native, '-Wl,--no-whole-archive', product] + tail
    execute('link', link)
    execute('ldd', ['ldd', remote / 'probe'])
    assert '/root/hyle-scratch/http2-current-20261018/current-holdout/libhyle_io_core.so.0.1.0' in (out / 'ldd.stdout.txt').read_text()
    (out / 'build.json').write_text(json.dumps({'inputs': [identity(p) for p in common[1:] + [native, product, out / 'probe.cc']], 'artifacts': [identity(remote / p) for p in ('consumer.o', 'probe', 'probe.map')]}, indent=2)+'\n')

def run():
    schedule = [('off-1', 'off'), ('phases-1', 'phases'), ('self', 'self'), ('phases-2', 'phases'), ('off-2', 'off')]
    plan = {'schedule': schedule, 'boundary': '64 complete fresh-session episodes/cell, 12 alternating ABBA/BAAB blocks/process. Same binary; phase clocks on/off switch. Full byte/header/order oracle.',
            'limit': 'Diagnostic CPU attribution, not production elapsed ranking. Worker remainder includes scheduling, native protocol, copies, validation, syscalls and timer overhead; it is not pure protocol time.', 'runs': []}
    assert not (out / 'plan.json').exists()
    (out / 'plan.json').write_text(json.dumps(plan, indent=2)+'\n')
    keys = ('wall_ns','caller_cpu_ns','worker_cpu_ns','initialize_ns','destroy_ns','worker_remainder_ns')
    for name, mode in schedule:
        execute(name, ['taskset', '-c', '2', remote / 'probe', mode])
        rows = [json.loads(s) for s in (out / (name + '.stdout.txt')).read_text().splitlines()]
        assert len(rows) == 49 and rows[0]['mode'] == mode
        cells = rows[1:]
        blocks=[]
        for b in range(12):
            selected = [r for r in cells if r['block'] == b]
            assert len(selected)==4
            arms={arm: [r for r in selected if r['arm']==arm] for arm in ('hyle','reference')}
            assert all(len(a)==2 for a in arms.values())
            means={arm: {k: statistics.mean(r[k] for r in a)/64 for k in keys} for arm,a in arms.items()}
            diff={k: means['hyle'][k]-means['reference'][k] for k in keys}
            assert abs(diff['worker_cpu_ns'] - diff['initialize_ns'] - diff['destroy_ns'] - diff['worker_remainder_ns']) < 0.01
            ratios={k: math.expm1(statistics.mean(math.log(r[k]) for r in arms['hyle']) - statistics.mean(math.log(r[k]) for r in arms['reference']))*100 for k in ('wall_ns','worker_cpu_ns')}
            blocks.append({'block':b, 'means_ns_per_episode':means, 'difference_ns_per_episode':diff, 'ratio_percent':ratios})
        result={'name':name,'mode':mode,'metadata':rows[0],'blocks':blocks,
                'median_difference_ns_per_episode':{k:statistics.median(b['difference_ns_per_episode'][k] for b in blocks) for k in keys},
                'mean_difference_ns_per_episode':{k:statistics.mean(b['difference_ns_per_episode'][k] for b in blocks) for k in keys},
                'median_arm_ns_per_episode':{arm:{k:statistics.median(b['means_ns_per_episode'][arm][k] for b in blocks) for k in keys} for arm in ('hyle','reference')},
                'median_ratio_percent':{k:statistics.median(b['ratio_percent'][k] for b in blocks) for k in ('wall_ns','worker_cpu_ns')}}
        plan['runs'].append(result)
        (out / 'summary.json').write_text(json.dumps(plan, indent=2)+'\n')
        print(name, result['median_difference_ns_per_episode'], result['median_ratio_percent'], flush=True)
    plan['status']='completed'
    (out / 'summary.json').write_text(json.dumps(plan, indent=2)+'\n')

{'build':build,'run':run}[sys.argv[1]]()
