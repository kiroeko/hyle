
Task<int> measure_worker_clock(AllocatorRef allocator, clockid_t *clock,
                              std::vector<std::uint64_t> *deltas) noexcept {
  (void)allocator;
  if (::pthread_getcpuclockid(::pthread_self(), clock) != 0) co_return -1;
  for (unsigned i = 0; i != 10000; ++i) {
    const auto before = clock_ns(CLOCK_THREAD_CPUTIME_ID);
    const auto after = clock_ns(CLOCK_THREAD_CPUTIME_ID);
    deltas->push_back(after - before);
  }
  co_return 0;
}

int main(int argc, char **argv) {
  if (argc != 2) return 2;
  const std::string_view mode(argv[1]);
  if (mode != "off" && mode != "phases" && mode != "self") return 2;
  const bool self = mode == "self";
  const bool enabled = mode != "off";
  std::signal(SIGPIPE, SIG_IGN);
  HyleHarness harness;
  clockid_t worker_clock{};
  std::vector<std::uint64_t> deltas;
  deltas.reserve(10000);
  auto clock_join = hyle::sched::spawn_task(
      harness.scheduler(), system_allocator(),
      measure_worker_clock(system_allocator(), &worker_clock, &deltas));
  auto clock_result = clock_join.join();
  if (!clock_result || *clock_result != 0) return 3;
  std::sort(deltas.begin(), deltas.end());
  timespec resolution{};
  if (::clock_getres(worker_clock, &resolution) != 0) return 3;
  std::printf("{\"type\":\"metadata\",\"mode\":\"%s\","
              "\"blocks\":12,\"episodes_per_cell\":64,"
              "\"thread_clock_back_to_back_ns\":{\"min\":%llu,\"median\":%llu,\"p99\":%llu},"
              "\"clock_reported_resolution_ns\":%llu}\n", argv[1],
              static_cast<unsigned long long>(deltas.front()),
              static_cast<unsigned long long>(deltas[deltas.size()/2]),
              static_cast<unsigned long long>(deltas[9900]),
              static_cast<unsigned long long>(resolution.tv_sec)*1000000000ULL+
                  static_cast<unsigned long long>(resolution.tv_nsec));
  const auto workload = make_workload("HTTP2 synchronous lifecycle attribution", 4,
      256 * 1024, 256 * 1024, NGHTTP2_INITIAL_CONNECTION_WINDOW_SIZE);
  auto run = [&](bool hyle_arm, bool descriptors = false) {
    return hyle_arm ? harness.run(workload)
                    : run_task_peer(harness, workload, descriptors);
  };
  for (unsigned i = 0; i != 16; ++i) {
    if (run(true) != workload.streams || run(self, i == 0) != workload.streams)
      return 4;
  }
  phases_enabled = enabled;
  for (unsigned block = 0; block != 12; ++block) {
    const std::array<bool, 4> abba{true, false, false, true};
    const std::array<bool, 4> baab{false, true, true, false};
    const auto &order = block % 2 == 0 ? abba : baab;
    for (unsigned cell = 0; cell != 4; ++cell) {
      phase_totals = {};
      const auto wall_before = clock_ns(CLOCK_MONOTONIC);
      const auto caller_before = clock_ns(CLOCK_THREAD_CPUTIME_ID);
      const auto worker_before = clock_ns(worker_clock);
      for (unsigned episode = 0; episode != 64; ++episode) {
        if (run(order[cell] || self) != workload.streams) return 5;
      }
      const auto worker_after = clock_ns(worker_clock);
      const auto caller_after = clock_ns(CLOCK_THREAD_CPUTIME_ID);
      const auto wall_after = clock_ns(CLOCK_MONOTONIC);
      if (enabled && phase_totals.completed != 128) return 6;
      const auto worker_ns = worker_after - worker_before;
      if (worker_ns < phase_totals.initialize_ns + phase_totals.destroy_ns) return 7;
      std::printf("{\"type\":\"cell\",\"block\":%u,\"cell\":%u,\"arm\":\"%s\","
                  "\"wall_ns\":%llu,\"caller_cpu_ns\":%llu,\"worker_cpu_ns\":%llu,"
                  "\"initialize_ns\":%llu,\"destroy_ns\":%llu,\"worker_remainder_ns\":%llu,"
                  "\"endpoints\":%u}\n", block, cell, order[cell] ? "hyle" : "reference",
                  static_cast<unsigned long long>(wall_after - wall_before),
                  static_cast<unsigned long long>(caller_after - caller_before),
                  static_cast<unsigned long long>(worker_ns),
                  static_cast<unsigned long long>(phase_totals.initialize_ns),
                  static_cast<unsigned long long>(phase_totals.destroy_ns),
                  static_cast<unsigned long long>(worker_ns - phase_totals.initialize_ns - phase_totals.destroy_ns),
                  phase_totals.completed);
    }
  }
  phases_enabled = false;
  return 0;
}
