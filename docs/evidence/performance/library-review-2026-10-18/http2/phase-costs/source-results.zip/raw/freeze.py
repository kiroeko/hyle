from pathlib import Path
import hashlib
import json
import stat
import zipfile

root=Path('/mnt/c/public/project-hyle/hyle')
out=Path(__file__).resolve().parent
remote=Path('/root/hyle-scratch/http2-current-20261018/phase-costs')
dest=root/'docs/evidence/performance/library-review-2026-10-18/http2/phase-costs'
dest.mkdir(exist_ok=False)

def identity(path):
    path=Path(path)
    assert path.resolve(strict=True)==path and stat.S_ISREG(path.lstat().st_mode)
    return {'path':str(path),'bytes':path.stat().st_size,'sha256':hashlib.sha256(path.read_bytes()).hexdigest()}

phase=json.loads((out/'summary.json').read_text())
ablation=json.loads((out/'ablation-summary.json').read_text())
assert phase['status']==ablation['status']=='completed'
assert identity(root/'src/io_http2/http2.cc')['sha256']=='30b57207730af05b29e3037d22427b67d35df6f5c4b69a1f99846c9630e6482f'
assert identity(root/'bench/io_http2/http2_p1_bench.cc')['sha256']=='96c1659810ca5d9e11610f937d619d122615f17cd4e3f3519ced9c0f255f6d63'
retained=json.loads((out.parent/'http2-owner-loop/artifact-plan.json').read_text())['retain']
for item in retained:
    assert identity(item['path'])==item
plan={'delete':[identity(remote/name) for name in ('consumer.o','probe','owner-check-disabled.o','owner-check-disabled')], 'retain':retained}
(out/'artifact-plan.json').write_text(json.dumps(plan,indent=2)+'\n')
summary={
  'conclusion':'No product change or resolution. In this diagnostic run the small worker-CPU gap mostly remains outside synchronous owner initialization and final cleanup. Removing just the dynamic worker-identity guard did not consistently collapse the gap; no single-function root cause established.',
  'phase_method':'One persistent Scheduler/IoContext, same complete4stream2MiB trace. Worker exposes pthread CPU clock ID through a joined Task; caller samples worker and caller CPU clocks once/cell. Two endpoint LifecycleProbes measure only synchronous initialization and final cleanup; no inclusive timing across yield/co_await/Event. Off/on toggles the eight internal clock reads per episode in one binary. Fixed off1/phases1/self/phases2/off2;12 alternating ABBA/BAAB blocks with64 episodes/cell; all full oracles passed.',
  'phase_mean_additive_differences_us_per_episode':[
    {key:run['mean_difference_ns_per_episode'][key]/1000 for key in ('worker_cpu_ns','initialize_ns','destroy_ns','worker_remainder_ns')}
    for run in phase['runs'] if run['mode']=='phases'],
  'phase_limitations':[
    'Components of each block and their arithmetic means add exactly; independent component medians need not add. No cross-process subtraction as timer correction or decomposition of earlier formal wall results.',
    'Remainder includes native protocol, copies, oracle, runtime owner/lifecycle validation, ACK/flowcontrol, I/O syscalls, scheduling, mid-episode stream/reader retirement and instrumentation. It is not pure codec, transport-wall or isolated wrapper cost.',
    'Final cleanup covers session/native/container/socket cleanup preceding endpoint completion. Runtime Task/frame/driver/stack retirement can occur after join publication and cross a cell edge; no new barrier/drain changes the trace.',
    'Back-to-back worker thread-clock medians120/121ns describe overhead scale, not accuracy. Reported1ns resolution is not an accuracy bound. Same-binary off/on controls only some perturbation/drift.',
    'Caller CPU is separate. No subtraction of two endpoint lifetimes; no summing overlapping wall intervals. No hardware PMU available. WSL guest CPU2 does not establish physical-core or host isolation.'
  ],
  'ablation':'Scratch-only mutant removes only sched::current_worker_index identity comparison inside validate_owner; alive/closed/native, cancellation, deadline, fatal checks retained. This deliberately breaks required owner semantics and is never a product candidate. Pure canonical paired consumer reused, selected consumer/native hot symbol addresses matched. Fixed self/baseline/disabled/disabled/baseline/self; full normal-trace oracles passed.',
  'ablation_result':'Baseline/disabled block medians +0.974518/+1.421958% and +1.748384/+1.058040%: one order worsens and one improves. AA+0.460092/+1.417915%. Does not establish that removing the query consistently collapses the gap. Does not establish zero query cost, TLS causality or fully exclude it. No new syscall/yield/wait counters were recorded; timing/layout effects cannot be isolated.',
  'scope':'Only diagnostic consumer TU and one deliberately invalid scratch product TU rebuilt with GCC14/O3/strict warnings; existing product, consumer, libraries, dependencies and final17test artifacts retained unchanged. No new product/benchmark/test source edits, no claim of new test passes, fullHEAD, Windows/macOS or TLS validation.',
  'phases':phase,
  'owner_ablation':ablation,
  'ablation_identity':json.loads((out/'ablation-build.json').read_text()),
  'source_identity':[identity(root/p) for p in ('src/io_http2/http2.cc','bench/io_http2/http2_p1_bench.cc')],
  'artifacts':plan,
}
(dest/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
with zipfile.ZipFile(dest/'source-results.zip','x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
    for path in sorted(out.rglob('*')):
        if path.is_file() and '__pycache__' not in path.parts:
            archive.write(path,'raw/'+path.relative_to(out).as_posix())
    for name in ('probe.map','owner-check-disabled.map'):
        archive.write(remote/name,'maps/'+name)
    archive.write(root/'src/io_http2/http2.cc','source/src/io_http2/http2.cc')
    archive.write(root/'bench/io_http2/http2_p1_bench.cc','source/bench/io_http2/http2_p1_bench.cc')
with zipfile.ZipFile(dest/'source-results.zip') as archive:
    assert archive.testzip() is None
print(json.dumps({'archive':identity(dest/'source-results.zip'),'delete':plan['delete']},indent=2))
