"""Generate a diagnostic-only fixture; canonical product and benchmark stay intact."""
from pathlib import Path
import hashlib
import json

root = Path('/mnt/c/public/project-hyle/hyle')
out = Path(__file__).resolve().parent
source = root / 'bench/io_http2/http2_p1_bench.cc'
text = source.read_text()
assert hashlib.sha256(source.read_bytes()).hexdigest() == '96c1659810ca5d9e11610f937d619d122615f17cd4e3f3519ced9c0f255f6d63'
support = r'''
// Diagnostic boundaries are synchronous; never time inclusive coroutine work.
std::uint64_t clock_ns(clockid_t clock) noexcept {
  timespec value{};
  if (::clock_gettime(clock, &value) != 0) std::abort();
  return static_cast<std::uint64_t>(value.tv_sec) * 1000000000ULL +
         static_cast<std::uint64_t>(value.tv_nsec);
}
struct PhaseTotals {
  std::uint64_t initialize_ns = 0;
  std::uint64_t destroy_ns = 0;
  unsigned completed = 0;
};
bool phases_enabled = false;
PhaseTotals phase_totals;
struct LifecycleProbe {
  bool active = phases_enabled;
  bool initialized_ok = false;
  bool finishing_ok = false;
  std::uint64_t mark = active ? clock_ns(CLOCK_THREAD_CPUTIME_ID) : 0;
  void initialized() noexcept {
    if (!active) return;
    phase_totals.initialize_ns += clock_ns(CLOCK_THREAD_CPUTIME_ID) - mark;
    initialized_ok = true;
  }
  void finishing() noexcept {
    if (!active) return;
    mark = clock_ns(CLOCK_THREAD_CPUTIME_ID);
    finishing_ok = true;
  }
  ~LifecycleProbe() {
    if (!active) return;
    if (!initialized_ok || !finishing_ok) std::abort();
    phase_totals.destroy_ns += clock_ns(CLOCK_THREAD_CPUTIME_ID) - mark;
    ++phase_totals.completed;
  }
};
'''
text = text.replace('#include <unistd.h>', '#include <unistd.h>\n#include <pthread.h>\n#include <time.h>')
anchor = 'Task<int> hyle_server('
assert text.count(anchor) == 1
text = text.replace(anchor, support + '\n' + anchor)
for name, end in [('hyle_server', 'Task<int> hyle_client('), ('hyle_client', 'class HyleHarness')]:
    start = text.index('Task<int> ' + name + '(')
    finish = text.index(end, start)
    part = text[start:finish]
    part = part.replace('  const Workload *workload = run->workload;',
                        '  LifecycleProbe lifecycle;\n  const Workload *workload = run->workload;')
    marker = '  for (int base = 0; base < workload->streams; base += 2) {'
    assert part.count(marker) == 1
    part = part.replace(marker, '  lifecycle.initialized();\n' + marker)
    assert part.count('  co_return workload->streams;') == 1
    part = part.replace('  co_return workload->streams;', '  lifecycle.finishing();\n  co_return workload->streams;')
    text = text[:start] + part + text[finish:]
start = text.index('Task<int> raw_task_endpoint(')
finish = text.index('// Sharing a Scheduler', start)
part = text[start:finish]
part = part.replace('  auto &endpoint = episode->endpoint[role];',
                    '  LifecycleProbe lifecycle;\n  auto &endpoint = episode->endpoint[role];')
part = part.replace('  for (;;) {', '  lifecycle.initialized();\n  for (;;) {', 1)
assert part.count('      co_return episode->workload.streams;') == 2
part = part.replace('      co_return episode->workload.streams;',
                    '      lifecycle.finishing();\n      co_return episode->workload.streams;')
text = text[:start] + part + text[finish:]
text = '#define main legacy_main\n' + text + '\n#undef main\n'
text += (out / 'probe_main.cc').read_text()
destination = out / 'probe.cc'
assert not destination.exists()
destination.write_text(text)
(out / 'source.json').write_text(json.dumps({'canonical': str(source), 'canonical_sha256': hashlib.sha256(source.read_bytes()).hexdigest(), 'probe_sha256': hashlib.sha256(destination.read_bytes()).hexdigest()}, indent=2) + '\n')
