from pathlib import Path
import hashlib
import json
import math
import statistics
import subprocess
import zipfile

ROOT = Path('/mnt/c/public/project-hyle/hyle')
HERE = ROOT / '.scratch/perf-review-2026-10-18/http2/owned-wire-no-copy'
PRIOR = HERE.parent / 'header-lifetime'


def rec(path):
    return dict(path=str(path), bytes=path.stat().st_size,
                sha256=hashlib.sha256(path.read_bytes()).hexdigest())


def write(name, value):
    (HERE / name).write_text(json.dumps(value, indent=2) + '\n')


assert (HERE / 'http2.candidate.cc').read_bytes() == (ROOT / 'src/io_http2/http2.cc').read_bytes()
assert (HERE / 'http2.before.cc').read_bytes() == (PRIOR / 'http2.applied.cc').read_bytes()
assert (HERE / 'http2_p1_bench.cc').read_bytes() == (ROOT / 'bench/io_http2/http2_p1_bench.cc').read_bytes()
(HERE / 'http2.applied.cc').write_bytes((ROOT / 'src/io_http2/http2.cc').read_bytes())
(HERE / 'http2_test.cc').write_bytes((PRIOR / 'http2_test.cc').read_bytes())
(HERE / 'feature_test.cc').write_bytes((PRIOR / 'feature_test.cc').read_bytes())
functional = json.loads((HERE / 'functional-identity.json').read_text())
holdout = json.loads((HERE / 'holdout-identity.json').read_text())
commands = json.loads((HERE / 'holdout-commands.json').read_text())
assert len([item for item in commands if item['name'].startswith('formal-')]) == 4
assert all(item['exit'] == 0 for item in commands)

processes = []
for index, variant in enumerate(['old', 'new', 'new', 'old']):
    raw_name = f'epochs-{index}-{variant}-4.json'
    raw = json.loads((HERE / raw_name).read_text())
    assert len(raw['results']) == 2
    arms = []
    for result in raw['results']:
        assert result['batch'] == 4 and result['epochs'] == len(result['measurements']) == 9
        assert result['minEpochTime'] == .001 and result['minEpochIterations'] == 5
        elapsed = [row['elapsed'] for row in result['measurements']]
        median = statistics.median(elapsed)
        assert math.isclose(median, result['median(elapsed)'], rel_tol=1e-12)
        epochs = [dict(iterations=row['iterations'], seconds_per_episode=row['elapsed'],
                       actual_duration_seconds=row['iterations'] * row['elapsed'],
                       microseconds_per_stream=row['elapsed'] * 1e6 / 4)
                  for row in result['measurements']]
        arms.append(dict(name=result['name'], median_microseconds_per_stream=median * 1e6 / 4,
                         epoch_microseconds_per_stream_range=[min(elapsed) * 1e6 / 4,
                                                              max(elapsed) * 1e6 / 4],
                         actual_epoch_duration_seconds_range=[min(row['actual_duration_seconds'] for row in epochs),
                                                              max(row['actual_duration_seconds'] for row in epochs)],
                         median_absolute_percent_error=result['medianAbsolutePercentError(elapsed)'],
                         measured_clock_resolution_seconds=result['clockResolution'], epochs=epochs))
    hyle = next(arm for arm in arms if arm['name'].startswith('HYLE'))
    peer = next(arm for arm in arms if arm['name'].startswith('nghttp2'))
    ratio = hyle['median_microseconds_per_stream'] / peer['median_microseconds_per_stream']
    processes.append(dict(index=index, variant=variant,
                          inner_order='Hyle then peer' if index < 2 else 'peer then Hyle',
                          raw=raw_name, arms=arms, hyle_over_peer_ratio=ratio,
                          hyle_slower_than_same_process_peer_percent=(ratio - 1) * 100))


def value(process, prefix):
    return next(arm['median_microseconds_per_stream'] for arm in process['arms']
                if arm['name'].startswith(prefix))


pairs = []
for old_index, new_index in [(0, 1), (3, 2)]:
    old, new = processes[old_index], processes[new_index]
    pairs.append(dict(old_process=old_index, new_process=new_index, inner_order=old['inner_order'],
                      new_over_old_hyle_percent=(value(new, 'HYLE') / value(old, 'HYLE') - 1) * 100,
                      new_over_old_peer_percent=(value(new, 'nghttp2') / value(old, 'nghttp2') - 1) * 100,
                      new_over_old_hyle_peer_ratio_percent=(new['hyle_over_peer_ratio'] /
                                                           old['hyle_over_peer_ratio'] - 1) * 100))

ranges = {}
for variant in ['old', 'new']:
    selected = [process for process in processes if process['variant'] == variant]
    ranges[variant] = dict(
        hyle_process_median_microseconds_per_stream_range=[min(value(p, 'HYLE') for p in selected),
                                                           max(value(p, 'HYLE') for p in selected)],
        peer_process_median_microseconds_per_stream_range=[min(value(p, 'nghttp2') for p in selected),
                                                           max(value(p, 'nghttp2') for p in selected)],
        hyle_slower_than_same_process_peer_percent_range=[min(p['hyle_slower_than_same_process_peer_percent'] for p in selected),
                                                         max(p['hyle_slower_than_same_process_peer_percent'] for p in selected)])

tests = []
for name in ['default-tests', 'epoll-tests']:
    result = json.loads((HERE / (name + '.json')).read_text())
    assert result['tests'] == 15 and result['failures'] == result['errors'] == result['disabled'] == 0
    tests.append(dict(backend=name, tests=15, failures=0, time=result['time'],
                      names=[suite['name'] + '.' + case['name']
                             for suite in result['testsuites'] for case in suite['testsuite']]))

artifacts = {item['path']: item for item in functional['artifacts'] + holdout['executables']}
for item in holdout['linked_inputs']:
    if item['path'].endswith('/owned-wire-no-copy/holdout.o'):
        artifacts[item['path']] = item
assert len(artifacts) == 5
for item in artifacts.values():
    assert rec(Path(item['path'])) == item
cleanup = [item for item in artifacts.values() if not item['path'].endswith('/http2.o')]
retain = [item for item in artifacts.values() if item['path'].endswith('/http2.o')]
retained_control = [item for item in functional['reused_inputs']
                    if item['path'].endswith(('/header-lifetime/http2.o', '/header-lifetime/http2_test.o',
                                             '/current-holdout/libhyle_io_core.so.0.1.0'))]
assert len(retained_control) == 3
write('cleanup-candidates.json', dict(
    host='WSL', root='/root/hyle-scratch/http2-current-20261018/owned-wire-no-copy',
    files=cleanup, total_bytes=sum(item['bytes'] for item in cleanup),
    retain_candidate_cache=retain, retain_current_baseline_test_core=retained_control,
    retained_bytes=sum(item['bytes'] for item in retain + retained_control),
    note='Do not execute until parent decides. Only four fresh executable/main-object paths are cleanup candidates. Keep old/new HTTP2 objects, current test object and core; all other shared foundation/native/cache files excluded. No deletion performed.'))

# Keep a small exact native-source excerpt to support the callback/PAUSE review,
# not another SDK/source-tree copy.
native_root = Path('/root/.cache/hyle/dependencies/v1/sources/nghttp2-85e300c79fb6-ca7aa79a25b3/lib')
native_excerpt = []
for source, spans in [('includes/nghttp2/nghttp2.h', [(985, 1049), (1538, 1583)]),
                      ('nghttp2_session.c', [(2794, 2823), (3043, 3099), (3129, 3154), (7512, 7585)])]:
    path = native_root / source
    lines = path.read_text().splitlines()
    native_excerpt.append(dict(source=rec(path), ranges=[dict(first=lo, last=hi,
        lines=[f'{index + 1}: {lines[index]}' for index in range(lo - 1, hi)]) for lo, hi in spans]))
write('native-contract-excerpts.json', native_excerpt)

summary = dict(
    result='The owned-wire DATA candidate passes existing functional coverage and has lower same-order normalized medians in both process pairs. Improvement magnitude is not stable across the two orders; the public route still loses to the manual peer in both candidate processes.',
    head_at_packaging=subprocess.check_output(['git', '-C', str(ROOT), 'rev-parse', 'HEAD'], text=True).strip(),
    product=dict(file='src/io_http2/http2.cc', changed='DATA read callback sets NO_COPY instead of copying into nghttp2 payload storage. The new synchronous send-data callback accepts the complete header/payload/padding into the existing owned wire and returns PAUSE.',
                 completion='mem_send2 returning zero with a queued wire is treated as one encoded frame; candidate_epoch and queued_for_flush are preserved, and flushed_epoch advances only after original transport completion.',
                 lifetime='Borrowed source, operation pins, EOF/trailer and stream-close lifetimes remain. Native callback performs no transport I/O/yield/reentrant native call. Partial-cancel tails remain owned by the original wire buffer.',
                 errors='If native reports callback failure, an existing fatal_status (including callback wire OOM) takes precedence over the generic native error mapping.',
                 unchanged='Control-frame route, public API/ABI/options, allocator, transport partial writes/read assistance/cancellation/deadline, dependency, peer, warmup and timing fixture are unchanged. Empty-notify micro-candidate was not included.',
                 copy_scope='This is not zero-copy: DATA still copies once from borrowed source to owned wire. One native-bounce payload copy is removed by source construction, not by a new runtime copy counter. No native-workspace or total allocation reduction is claimed.'),
    scope=dict(trace='Only original 4x256KiB request/response holdout with reverse pair responses and original flow-control window',
               full_smoke='Old and new each run once with all existing full payload/header/credit/completion/cleanup checks; both report Hyle=4, peer=4.',
               formal_outer_order=['old', 'new', 'new', 'old'],
               formal_inner_order=['Hyle then peer', 'Hyle then peer', 'peer then Hyle', 'peer then Hyle'],
               processes=4, epochs_per_arm=9, arms_per_process=2, all_72_epochs_retained=True,
               extra_AA_retry_shape_probe_or_warm_peer_change=False),
    tests=tests,
    coverage_limits='Existing tests cover empty fixed DATA, fragmented streaming finish/trailers, borrow stability, duplex/backpressure, peer close, cancel/reset/deadline/session reuse. Callback reserve-growth OOM, explicit padding production and TLS were not specifically exercised. No new implementation-mirroring test or separate test TU was added.',
    method=dict(toolchain=(HERE / 'compiler.stdout.txt').read_text().splitlines()[0],
                flags='Recorded in functional-commands.json and holdout-commands.json: GCC14.2, -O3 -DNDEBUG -std=c++23 -pthread -fPIC, hidden visibility, coroutine transport/HTTP2/static nghttp2 definitions.',
                fresh='Candidate HTTP2 TU plus original canonical one-holdout main TU; retained protocol/feature test objects, current core, foundation and locked nghttp2 static library were reused after exact SHA checks. No whole-HEAD or SDK build/copy.',
                baseline='The current-before header-lifetime object 9ec083... is reused, not the older pre-header-construction baseline. Its exact source equals this batch http2.before.cc.',
                core=holdout['core'], current_proactor_source=holdout['current_proactor_source'],
                peer='Exact current canonical peer/source and original one-holdout wrapper are byte-identical to the preceding holdout. All original headers/body/reverse completion, two credit layers, socket/session/handoff destruction and nanobench boundaries remain.',
                resources='All formal processes use taskset -c 2 with both persistent harnesses resident. No new live TID/affinity census or backend enum capture in this batch; configured caller + one Scheduler worker + one RawHarness worker, not a measured fresh thread census.',
                timer='Raw clock resolution and each actual epoch duration are retained separately from process variation. perf_event_open unavailability warning preserved; zero hardware-counter fields are not measured counters.',
                review='Root and backend_assembly_design independently reviewed the source before compilation.'),
    processes=processes, same_inner_order_pairs=pairs, process_median_ranges=ranges,
    interpretation=[
        'Both normalized median comparisons favor the candidate, but the first pair is small relative to observed within-run variation while the reverse-order pair is larger. These four processes do not establish a stable universal speedup, confidence interval or equivalence.',
        'Current candidate residuals are the two new-process points and range, not a cross-round subtraction from earlier 12-14% or 16-17% results. The manual peer still has lower medians in both candidate processes.',
        'The source copy change is an implementation improvement candidate, not proof that the historical/public API gap was caused by a unique extra receive/transmit copy or by Scheduler overhead.',
        'Every original epoch and actual duration is retained, including slower points; no AA, threshold filter, retry, extra shape or later timing was run.'
    ],
    source_identities=dict(before=rec(HERE / 'http2.before.cc'), candidate=rec(HERE / 'http2.candidate.cc'),
                           applied=rec(HERE / 'http2.applied.cc'), candidate_equals_applied=True,
                           peer=rec(HERE / 'http2_p1_bench.cc'), main=rec(HERE / 'holdout.cc')),
    identities=['preflight-identity.json', 'functional-identity.json', 'holdout-identity.json'],
    commands=['functional-commands.json', 'holdout-commands.json'],
    failures='No compile/link/test/smoke/formal failure in this batch; all attempts and stderr retained.',
    next='No further build, test or timing. Parent owns acceptance/commit/cleanup; precise cleanup and retained control cache are in cleanup-candidates.json.')
write('summary.json', summary)

archive = HERE / 'source-results.zip'
files = sorted(path for path in HERE.iterdir() if path.is_file() and
               path.name not in {'source-results.zip', 'archive-record.json'})
assert not any(path.suffix.lower() in {'.o', '.obj', '.a', '.lib', '.exe', '.so', '.dll'} for path in files)
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as zipped:
    for path in files:
        zipped.write(path, path.name)
    assert zipped.testzip() is None
write('archive-record.json', dict(
    archive=rec(archive), members=len(files), summary=rec(HERE / 'summary.json'),
    cleanup=rec(HERE / 'cleanup-candidates.json'),
    contents='Only source, small native contract excerpts, commands, exact identities, tests, all 72 raw epochs, analysis and logs; no executable/object/library/SDK/dependency tree.'))
print(json.dumps(dict(processes=[dict(index=p['index'], variant=p['variant'], hyle_us=value(p, 'HYLE'),
    peer_us=value(p, 'nghttp2'), ratio=p['hyle_over_peer_ratio'], residual_percent=p['hyle_slower_than_same_process_peer_percent'])
    for p in processes], pairs=pairs, ranges=ranges, archive=rec(archive), summary=rec(HERE / 'summary.json'),
    cleanup_bytes=sum(item['bytes'] for item in cleanup)), indent=2))
