from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys

ROOT = Path('/mnt/c/public/project-hyle/hyle')
HERE = ROOT / '.scratch/perf-review-2026-10-18/http2/owned-wire-no-copy'
PRIOR = HERE.parent / 'header-lifetime'
BASE = Path('/root/hyle-scratch/http2-current-20261018')
OUT = BASE / 'owned-wire-no-copy'
ENV = {key: value for key, value in os.environ.items()
       if not key.startswith(('HYLE_BENCH_', 'HYLE_PERF_', 'HYLE_IO_FORCE_'))}
ENV['LD_LIBRARY_PATH'] = str(BASE / 'current-holdout') + ':/root/hyle-scratch/io-watch-v2-dev/bin'


def rec(path):
    return dict(path=str(path), bytes=path.stat().st_size,
                sha256=hashlib.sha256(path.read_bytes()).hexdigest())


def write(name, value):
    (HERE / name).write_text(json.dumps(value, indent=2) + '\n')


def validate_inputs():
    identity = json.loads((PRIOR / 'build-identity.json').read_text())
    actual = []
    for expected in identity['inputs']:
        item = rec(Path(expected['path']))
        assert item == expected, 'Cached object/library changed: ' + item['path']
        actual.append(item)
    assert (HERE / 'http2.before.cc').read_bytes() == (PRIOR / 'http2.applied.cc').read_bytes()
    assert (HERE / 'http2.candidate.cc').read_bytes() == (ROOT / 'src/io_http2/http2.cc').read_bytes()
    assert (PRIOR / 'http2_test.cc').read_bytes() == (ROOT / 'tests/io_http2/http2_test.cc').read_bytes()
    assert (PRIOR / 'feature_test.cc').read_bytes() == (ROOT / 'tests/io_http2/feature_test.cc').read_bytes()
    assert rec(ROOT / 'src/io_core/proactor.cc')['sha256'] == identity['current_proactor']['sha256']
    return actual


if sys.argv[1] == 'preflight':
    actual = validate_inputs()
    write('preflight-identity.json', dict(
        reused_inputs=actual, retained_protocol_test_source=rec(PRIOR / 'http2_test.cc'),
        current_source=rec(ROOT / 'src/io_http2/http2.cc'),
        current_proactor_source=rec(ROOT / 'src/io_core/proactor.cc'),
        status='Exact cached file SHA/size and source checks only; no build or run.'))
    print('Exact preflight passed:', len(actual), 'cached inputs; current test/core sources match.')
elif sys.argv[1] == 'run':
    actual = validate_inputs()
    OUT.mkdir(exist_ok=True)
    assert not (HERE / 'functional-commands.json').exists(), 'No overwritten or retried attempts'
    records = []

    def run(name, argv, env=ENV):
        argv = list(map(str, argv))
        result = subprocess.run(argv, cwd=OUT, env=env, text=True,
                                capture_output=True, timeout=60)
        (HERE / (name + '.stdout.txt')).write_text(result.stdout)
        (HERE / (name + '.stderr.txt')).write_text(result.stderr)
        records.append(dict(name=name, argv=argv, cwd=str(OUT), exit=result.returncode,
                            environment={key: value for key, value in env.items()
                                         if key.startswith(('LD_LIBRARY_PATH', 'HYLE_'))}))
        write('functional-commands.json', records)
        print(name, result.returncode, result.stdout[-3500:], result.stderr[-1200:], flush=True)
        if result.returncode != 0:
            raise RuntimeError('Stopped at failed command: ' + name)
        return result.stdout

    commands = json.loads((PRIOR / 'commands.json').read_text())
    run('compiler', ['g++-14', '--version'])
    command = next(item['argv'] for item in commands if item['name'] == 'compile-http2')
    run('compile-http2', command[:-4] + ['-c', HERE / 'http2.candidate.cc', '-o', OUT / 'http2.o'])
    original = next(item['argv'] for item in commands if item['name'] == 'link-tests')
    link = [str(OUT / 'tests') if item == str(BASE / 'header-lifetime/tests') else
            str(OUT / 'http2.o') if item == str(BASE / 'header-lifetime/http2.o') else item
            for item in original]
    run('link-tests', link)
    loader = run('loader', ['ldd', OUT / 'tests'])
    assert str(BASE / 'current-holdout/libhyle_io_core.so.0.1.0') in loader
    run('default-tests', ['timeout', '--kill-after=2s', '20s', OUT / 'tests',
                          '--gtest_output=json:' + str(HERE / 'default-tests.json')])
    epoll = ENV.copy()
    epoll['HYLE_IO_FORCE_EPOLL'] = '1'
    run('epoll-tests', ['timeout', '--kill-after=2s', '20s', OUT / 'tests',
                        '--gtest_output=json:' + str(HERE / 'epoll-tests.json')], epoll)
    results = []
    for name in ['default-tests', 'epoll-tests']:
        result = json.loads((HERE / (name + '.json')).read_text())
        assert result['tests'] == 15 and result['failures'] == result['errors'] == 0
        results.append(dict(backend=name, tests=result['tests'], failures=result['failures'],
                            errors=result['errors'], time=result['time']))
    write('functional-identity.json', dict(
        fresh_source=rec(HERE / 'http2.candidate.cc'),
        reused_inputs=actual, artifacts=[rec(OUT / name) for name in ['http2.o', 'tests']],
        results=results, closure='Only candidate HTTP2 TU fresh. Existing protocol/feature test objects, current core, foundation/native cache reused with exact SHA checks.',
        not_run='No throughput, hardware/software sampling, new test TU, whole-library rebuild or SDK/dependency work. Callback OOM growth case not specifically exercised.'))
    write('cleanup-candidates.json', dict(host='WSL', root=str(OUT),
        files=[rec(OUT / name) for name in ['http2.o', 'tests']],
        total_bytes=sum((OUT / name).stat().st_size for name in ['http2.o', 'tests']),
        note='Exact fresh artifacts only; do not delete yet. No shared object/cache included.'))
else:
    raise RuntimeError('Unknown phase')
