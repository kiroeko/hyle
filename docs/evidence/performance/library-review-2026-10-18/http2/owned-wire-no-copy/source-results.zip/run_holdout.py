from pathlib import Path
import hashlib
import json
import os
import subprocess

ROOT = Path('/mnt/c/public/project-hyle/hyle')
HERE = ROOT / '.scratch/perf-review-2026-10-18/http2/owned-wire-no-copy'
PRIOR = HERE.parent / 'header-lifetime'
BASE = Path('/root/hyle-scratch/http2-current-20261018')
OUT = BASE / 'owned-wire-no-copy'
ENV = {key: value for key, value in os.environ.items()
       if not key.startswith(('HYLE_BENCH_', 'HYLE_PERF_', 'HYLE_IO_FORCE_'))}
ENV['LD_LIBRARY_PATH'] = str(BASE / 'current-holdout') + ':/root/hyle-scratch/io-watch-v2-dev/bin'
LOG = HERE / 'holdout-commands.json'
assert not LOG.exists(), 'No repeated build/smoke/formal attempt'
records = []


def rec(path):
    return dict(path=str(path), bytes=path.stat().st_size,
                sha256=hashlib.sha256(path.read_bytes()).hexdigest())


def write(name, value):
    (HERE / name).write_text(json.dumps(value, indent=2) + '\n')


def run(name, argv, env=ENV):
    argv = list(map(str, argv))
    result = subprocess.run(argv, cwd=OUT, env=env, text=True,
                            capture_output=True, timeout=60)
    (HERE / (name + '.stdout.txt')).write_text(result.stdout)
    (HERE / (name + '.stderr.txt')).write_text(result.stderr)
    records.append(dict(name=name, argv=argv, cwd=str(OUT), exit=result.returncode,
                        environment={key: value for key, value in env.items()
                                     if key.startswith(('LD_LIBRARY_PATH', 'HYLE_'))}))
    write('holdout-commands.json', records)
    print(name, result.returncode, result.stdout[-1500:], result.stderr[-800:], flush=True)
    if result.returncode != 0:
        raise RuntimeError('Stopped at failed command: ' + name)
    return result.stdout


functional = json.loads((HERE / 'functional-identity.json').read_text())
for expected in functional['reused_inputs'] + functional['artifacts']:
    assert rec(Path(expected['path'])) == expected, 'Changed input: ' + expected['path']
for name in ['default-tests', 'epoll-tests']:
    result = json.loads((HERE / (name + '.json')).read_text())
    assert result['tests'] == 15 and result['failures'] == result['errors'] == 0
assert (HERE / 'http2.candidate.cc').read_bytes() == (ROOT / 'src/io_http2/http2.cc').read_bytes()
assert (HERE / 'http2.before.cc').read_bytes() == (PRIOR / 'http2.applied.cc').read_bytes()
peer = ROOT / 'bench/io_http2/http2_p1_bench.cc'
assert peer.read_bytes() == (PRIOR / 'http2_p1_bench.cc').read_bytes()
(HERE / 'holdout.cc').write_bytes((PRIOR / 'holdout.cc').read_bytes())
(HERE / 'http2_p1_bench.cc').write_bytes(peer.read_bytes())

prior_commands = json.loads((PRIOR / 'holdout-commands.json').read_text())
compile_command = next(item['argv'] for item in prior_commands if item['name'] == 'compile-holdout')
run('compile-holdout', compile_command[:-4] + ['-c', HERE / 'holdout.cc', '-o', OUT / 'holdout.o'])
link_command = next(item['argv'] for item in prior_commands if item['name'] == 'link-holdout-new')
variants = {'old': BASE / 'header-lifetime/http2.o', 'new': OUT / 'http2.o'}
links = []
for variant, obj in variants.items():
    command = [str(OUT / ('holdout-' + variant)) if item == str(BASE / 'header-lifetime/holdout-new') else
               str(obj) if item == str(BASE / 'header-lifetime/http2.o') else
               str(OUT / 'holdout.o') if item == str(BASE / 'header-lifetime/holdout.o') else item
               for item in link_command]
    run('link-holdout-' + variant, command)
    loader = run('loader-holdout-' + variant, ['ldd', OUT / ('holdout-' + variant)])
    assert str(BASE / 'current-holdout/libhyle_io_core.so.0.1.0') in loader
    smoke = ENV.copy()
    smoke['HYLE_BENCH_SMOKE'] = '1'
    run('smoke-holdout-' + variant, ['taskset', '-c', '2', 'timeout', '--kill-after=2s',
                                    '20s', OUT / ('holdout-' + variant)], smoke)
    links.extend(Path(item) for item in command if item.endswith(('.o', '.a')))

write('holdout-identity.json', dict(
    sources=[rec(HERE / name) for name in ['holdout.cc', 'http2_p1_bench.cc', 'http2.before.cc', 'http2.candidate.cc']],
    linked_inputs=[rec(path) for path in sorted(set(links))],
    core=rec(BASE / 'current-holdout/libhyle_io_core.so.0.1.0'),
    current_proactor_source=rec(ROOT / 'src/io_core/proactor.cc'),
    executables=[rec(OUT / ('holdout-' + variant)) for variant in variants],
    plan='Only original 4x256KiB trace; outer old/new/new/old; first two Hyle then peer, last two peer then Hyle. Nine epochs/arm, 72 total. No AA, retry, extra shape, probe or warm/peer change.',
    closure='Fresh original canonical one-holdout wrapper TU plus old/new links; candidate HTTP2 TU from successful functional validation. Current core/foundation/native objects reused with exact hash checks. Not a whole-HEAD build.'))

assert (HERE / 'http2.candidate.cc').read_bytes() == (ROOT / 'src/io_http2/http2.cc').read_bytes()
assert peer.read_bytes() == (HERE / 'http2_p1_bench.cc').read_bytes()
for index, variant in enumerate(['old', 'new', 'new', 'old']):
    env = ENV.copy()
    env['HYLE_BENCH_JSON'] = str(HERE / ('epochs-' + str(index) + '-' + variant))
    if index >= 2:
        env['HYLE_BENCH_RIVAL_FIRST'] = '1'
    run('formal-' + str(index) + '-' + variant,
        ['taskset', '-c', '2', 'timeout', '--kill-after=2s', '30s', OUT / ('holdout-' + variant)], env)
print('Fixed four formal processes complete; no further build or execution.', flush=True)
