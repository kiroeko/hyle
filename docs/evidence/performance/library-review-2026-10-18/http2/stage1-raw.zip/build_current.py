#!/usr/bin/env python3
"""Small Linux HTTP/2 consumer build; no Hyle configure or vendor downloads."""
import hashlib
import json
from pathlib import Path
import subprocess
import time

SOURCE = Path('/mnt/c/public/project-hyle/hyle')
RECORD = SOURCE / '.scratch/perf-review-2026-10-18/http2'
BUILD = Path('/root/hyle-scratch/http2-current-20261018')
VENDOR = Path('/root/.cache/hyle/dependencies/v1/sources/nghttp2-85e300c79fb6-ca7aa79a25b3')
FOUNDATION = Path('/root/hyle-scratch/io-watch-v2-dev/bin')
BUILD.mkdir(parents=True, exist_ok=True)
RECORD.mkdir(parents=True, exist_ok=True)
commands = []

def run(args, name):
    args = [str(x) for x in args]
    start = time.time()
    completed = subprocess.run(args, cwd=BUILD, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    (RECORD / (name + '.log')).write_text(completed.stdout)
    commands.append({'name': name, 'argv': args, 'cwd': str(BUILD), 'returncode': completed.returncode, 'elapsed_seconds': time.time() - start})
    (RECORD / 'build-commands.json').write_text(json.dumps(commands, indent=2) + '\n')
    print(name, completed.returncode, flush=True)
    if completed.returncode:
        print(completed.stdout[-5000:])
        raise SystemExit(completed.returncode)

vendor_build = BUILD / 'nghttp2-build'
configure = ['cmake', '-S', VENDOR, '-B', vendor_build, '-G', 'Ninja',
             '-DCMAKE_BUILD_TYPE=Release', '-DCMAKE_C_COMPILER=gcc-14', '-DCMAKE_CXX_COMPILER=g++-14',
             '-DCMAKE_POSITION_INDEPENDENT_CODE=ON', '-DENABLE_LIB_ONLY=ON', '-DENABLE_APP=OFF',
             '-DENABLE_EXAMPLES=OFF', '-DENABLE_HPACK_TOOLS=OFF', '-DENABLE_DOC=OFF', '-DENABLE_HTTP3=OFF',
             '-DENABLE_FAILMALLOC=OFF', '-DENABLE_THREADS=OFF', '-DBUILD_TESTING=OFF',
             '-DBUILD_SHARED_LIBS=OFF', '-DBUILD_STATIC_LIBS=ON',
             '-DWITH_LIBXML2=OFF', '-DWITH_JEMALLOC=OFF', '-DWITH_LIBBPF=OFF', '-DWITH_WOLFSSL=OFF',
             '-DWITH_MRUBY=OFF', '-DWITH_NEVERBLEED=OFF']
for package in ['Python3', 'OpenSSL', 'Libngtcp2', 'Libnghttp3', 'Systemd', 'Jansson', 'Libevent', 'LibXml2', 'Jemalloc']:
    configure.append('-DCMAKE_DISABLE_FIND_PACKAGE_' + package + '=TRUE')
run(configure, 'nghttp2-configure')
run(['cmake', '--build', vendor_build, '--target', 'nghttp2_static', '-j2'], 'nghttp2-build')

common = ['g++-14', '-O3', '-DNDEBUG', '-std=c++23', '-pthread', '-fPIC', '-fvisibility=hidden',
          '-fvisibility-inlines-hidden', '-DHYLE_IO_HAS_COROUTINE_TRANSPORT=1', '-DHYLE_IO_HTTP2',
          '-DNGHTTP2_STATICLIB', '-I' + str(SOURCE / 'include'),
          '-I' + str(SOURCE / 'third_party/picohttpparser'),
          '-I' + str(SOURCE / 'third_party/nanobench'),
          '-I' + str(VENDOR / 'lib/includes'), '-I' + str(vendor_build / 'lib/includes')]
objects = []
inputs = []
for relative, owner in [('src/io_http/http.cc', 'HYLE_IO_HTTP_BUILD'),
                        ('src/io_http2/http2.cc', 'HYLE_IO_HTTP2_BUILD'),
                        ('src/io_http2/feature.cc', 'HYLE_IO_HTTP2_BUILD'),
                        ('bench/io_http2/http2_p1_bench.cc', None),
                        ('bench/nanobench_impl.cc', None)]:
    source = SOURCE / relative
    target = BUILD / (relative.replace('/', '_') + '.o')
    args = common + (['-D' + owner] if owner else []) + ['-c', source, '-o', target]
    run(args, target.stem)
    objects.append(target)
    inputs.append({'path': relative, 'sha256': hashlib.sha256(source.read_bytes()).hexdigest()})
pico = SOURCE / 'third_party/picohttpparser/picohttpparser.c'
pico_obj = BUILD / 'picohttpparser.o'
run(['gcc-14', '-O3', '-DNDEBUG', '-fPIC', '-c', pico, '-o', pico_obj], 'picohttpparser')
objects.append(pico_obj)
inputs.append({'path': str(pico.relative_to(SOURCE)), 'sha256': hashlib.sha256(pico.read_bytes()).hexdigest()})
libraries = ['hyle_io_core', 'hyle_container_text', 'hyle_container', 'hyle_sched', 'hyle_platform_thread',
             'hyle_mem_vm', 'hyle_mem', 'hyle_platform_fs', 'hyle_time', 'hyle_platform', 'hyle_error']
run(['g++-14', '-pthread', '-o', BUILD / 'http2_current', *objects, vendor_build / 'lib/libnghttp2.a',
     '-L' + str(FOUNDATION), '-Wl,-rpath,' + str(FOUNDATION), *['-l' + x for x in libraries]], 'link')
identity = {'sources': inputs, 'foundation': [], 'nghttp2_source': str(VENDOR), 'build_dir': str(BUILD)}
for name in libraries:
    path = (FOUNDATION / ('lib' + name + '.so')).resolve()
    identity['foundation'].append({'path': str(path), 'sha256': hashlib.sha256(path.read_bytes()).hexdigest(), 'bytes': path.stat().st_size})
identity['binary_sha256'] = hashlib.sha256((BUILD / 'http2_current').read_bytes()).hexdigest()
(RECORD / 'build-identity.json').write_text(json.dumps(identity, indent=2) + '\n')
