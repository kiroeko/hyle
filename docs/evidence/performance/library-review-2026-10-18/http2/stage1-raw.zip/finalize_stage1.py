import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import zipfile

ROOT = Path('/mnt/c/public/project-hyle/hyle')
HERE = ROOT / '.scratch/perf-review-2026-10-18/http2'
BUILD = Path('/root/hyle-scratch/http2-current-20261018')
source = HERE / 'source'
for relative in ['src/io_http/http.cc', 'src/io_http2/feature.cc', 'bench/nanobench_impl.cc',
                 'include/hyle/io/http2.h', 'include/hyle/io/http.h', 'include/hyle/io/tcp.h',
                 'include/hyle/io/io_context.h', 'tests/io_http2/http2_test.cc',
                 'tests/io_http2/feature_test.cc', 'cmake/HyleDependencyLock.json']:
    target = source / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(ROOT / relative, target)
config = BUILD / 'nghttp2-build'
for relative in ['CMakeCache.txt', 'config.h', 'lib/includes/nghttp2/nghttp2ver.h']:
    target = source / 'nghttp2-generated' / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(config / relative, target)

rows = []
for prefix in ['formal-', 'postfix-', 'aa-hyle-', 'aa-peer-']:
    for path in sorted(HERE.glob(prefix + '*.json')):
        if path.stem.rsplit('-', 1)[-1] not in ['4', '64']:
            continue
        data = json.loads(path.read_text())
        result = {'file': path.name, 'routes': []}
        for route in data['results']:
            result['routes'].append({'label': route['name'], 'ns_per_stream': route['median(elapsed)'] * 1e9 / route['batch'],
                                    'epoch_count': len(route['measurements']),
                                    'median_absolute_percent_error': route['medianAbsolutePercentError(elapsed)']})
        if len(result['routes']) == 2:
            hyle = next(x for x in result['routes'] if x['label'].startswith('HYLE'))
            peer = next(x for x in result['routes'] if x['label'].startswith('nghttp2'))
            result['hyle_over_peer'] = hyle['ns_per_stream'] / peer['ns_per_stream']
        rows.append(result)
metadata = {}
for name, argv in [('kernel', ['uname', '-a']), ('compiler', ['g++-14', '--version']),
                   ('affinity', ['taskset', '-pc', str(__import__('os').getpid())]),
                   ('loaded_libraries', ['ldd', str(BUILD / 'http2_baseline')])]:
    metadata[name] = subprocess.check_output(argv, text=True)
summary = {
    'scope': 'Current Linux/WSL public HTTP2 fixed-body connection episodes; not a current cross-platform ranking or an inference-engine test.',
    'method': {'cpu': 'All formal consumers and both persistent workers inherit Linux logical CPU2 affinity.',
               'configured_resources': 'One Hyle Scheduler worker plus one direct nghttp2 worker; both harnesses exist in every process, one route active at a time. Actual userspace thread snapshots were not collected.',
               'timed': 'Fresh nonblocking Unix socket pair, 4KiB socket buffers, both HTTP2 sessions, full header/body work and exact checks, reverse pair response completion, body acknowledgements at both flow-control levels, session/socket destruction and external completion handoff.',
               'not_charged': 'Persistent harness construction/destruction, fixed workload-body string generation, one untimed preflight per route, optional JSON serialization after each workload.',
               'normal': '64 streams, two active at a time, 1KiB request and response each, 1MiB connection receive window.',
               'holdout': '4 streams, two active at a time, 256KiB request and response each, 65535-byte connection window.',
               'stream_window': 65536, 'read_chunk': 16384, 'sampling': 'Four processes per formal phase, two execution orders. Nine nanobench epochs per route/workload, at least five complete episodes per epoch. No samples filtered; no cross-process CI or equivalence conclusion.'},
    'fairness_fix': 'Peer raw_advance formerly rescanned every completed pair on every protocol turn. A monotonic next_response_pair now skips pairs after both reverse-ordered responses have been submitted; all DATA/write/consume/validation/teardown work remains.',
    'current_result': 'With corrected peer wrapper, 64x1KiB is faster for Hyle in all four initial processes; 4x256KiB is slower by 5.59-8.27%. Do not inherit historical WIN/PARITY or the old 5% practical pass rule.',
    'aa_limit': 'One scratch-only process per same route, both labels run the same Hyle or peer call. Second-position holdout advantage approximately 5.04% Hyle / 2.66% peer. These are observed position/warm-state differences, not correction factors, CIs, hardware timer resolution, or proof that the formal residual is noise.',
    'candidate': {'description': 'Do not notify again when releasing the immediate read-direction claim; process_received already published input changes. Async read path unchanged.',
                  'tests': '13 current HTTP2/feature tests pass, plus separate forced-epoll duplex test. Both rebuilt baseline and candidate smoke return 64/64/4/4.',
                  'comparison': 'Both protocol TUs rebuilt against the same then-current headers because unrelated container headers changed during this task. Foundation shared cache and peer/consumer objects identical. Two baseline/candidate order pairs retained without filtering.',
                  'result': 'Not an established speedup: one holdout candidate point is slower, the other close in absolute Hyle time, while peer times drift. Reverted product source to original; frozen candidate and raw logs retained. Holdout residual remains unresolved.'},
    'identity_limits': 'Only nghttp2_static and current HTTP/HTTP2/consumer TUs built. Foundation libraries reused from io-watch-v2-dev and hashed; this is not a full HEAD rebuild. Initial formal and later candidate phase header environments differ and must not be directly attributed to the notify change.',
    'nghttp2': {'version': '1.70.0', 'source_commit': '85e300c79fb6dbcfa9c1013215c8710c1c2cd3d2', 'source_cache': '/root/.cache/hyle/dependencies/v1/sources/nghttp2-85e300c79fb6-ca7aa79a25b3',
                'static_sha256': hashlib.sha256((config / 'lib/libnghttp2.a').read_bytes()).hexdigest(),
                'build': 'Existing locked source, lib-only/static/Release/GCC14, no downloads, no SDK staging or Hyle CMake configure.'},
    'metadata': metadata, 'results': rows,
}
(HERE / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
(HERE / 'bench.diff').write_text(subprocess.check_output(['git', 'diff', '--', 'bench/io_http2/http2_p1_bench.cc'], cwd=ROOT, text=True))
members = [p for p in HERE.rglob('*') if p.is_file() and p.suffix in ['.json', '.log', '.cc', '.h', '.txt', '.py', '.diff'] and p.name not in ['archive-record.json', 'archive-members.json']]
archive = HERE / 'stage1-raw.zip'
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED) as output:
    for path in sorted(members):
        output.write(path, path.relative_to(HERE).as_posix())
record = {'file': archive.name, 'bytes': archive.stat().st_size, 'sha256': hashlib.sha256(archive.read_bytes()).hexdigest(), 'member_count': len(members), 'excluded': 'No executables, shared/static libraries, objects, vendor source tree or SDK copies.'}
(HERE / 'archive-record.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record))
