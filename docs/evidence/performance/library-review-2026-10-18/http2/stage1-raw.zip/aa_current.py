#!/usr/bin/env python3
"""Two scratch-only same-route controls; formal consumer is unchanged."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

SOURCE = Path('/mnt/c/public/project-hyle/hyle')
RECORD = SOURCE / '.scratch/perf-review-2026-10-18/http2'
BUILD = Path('/root/hyle-scratch/http2-current-20261018')
commands = json.loads((RECORD / 'current-build-commands.json').read_text())
compile_command, link_command = commands
original = (SOURCE / 'bench/io_http2/http2_p1_bench.cc').read_text()
records = []
for route, old, new in [('hyle', 'peer.run(workload)', 'hyle.run(workload)'),
                        ('peer', 'hyle.run(workload)', 'peer.run(workload)')]:
    assert original.count(old) == 1
    source = RECORD / ('aa-' + route + '.cc')
    source.write_text(original.replace(old, new))
    obj = BUILD / ('aa-' + route + '.o')
    binary = BUILD / ('aa-' + route)
    argv = [str(source) if x.endswith('/bench/io_http2/http2_p1_bench.cc') else str(obj) if x.endswith('/bench_io_http2_http2_p1_bench.cc.o') else x for x in compile_command['argv']]
    link = [str(binary) if x.endswith('/http2_current') else str(obj) if x.endswith('/bench_io_http2_http2_p1_bench.cc.o') else x for x in link_command['argv']]
    for name, command in [('aa-' + route + '-compile', argv), ('aa-' + route + '-link', link)]:
        completed = subprocess.run(command, cwd=BUILD, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
        (RECORD / (name + '.log')).write_text(completed.stdout)
        records.append({'name': name, 'argv': command, 'returncode': completed.returncode})
        (RECORD / 'aa-commands.json').write_text(json.dumps(records, indent=2) + '\n')
        if completed.returncode:
            print(completed.stdout[-5000:])
            raise SystemExit(completed.returncode)
    env = os.environ.copy()
    for key in ['HYLE_BENCH_SMOKE', 'HYLE_BENCH_RIVAL_FIRST', 'HYLE_BENCH_JSON']:
        env.pop(key, None)
    env['HYLE_PERF_RUN_NONCE'] = 'aa-' + route
    env['HYLE_BENCH_JSON'] = str(RECORD / ('aa-' + route))
    command = ['taskset', '-c', '2', str(binary)]
    start = time.time()
    completed = subprocess.run(command, env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, timeout=30)
    (RECORD / ('aa-' + route + '.log')).write_text(completed.stdout)
    records.append({'name': 'aa-' + route, 'argv': command, 'environment': {key: value for key, value in env.items() if key.startswith('HYLE_')}, 'returncode': completed.returncode, 'elapsed_seconds': time.time() - start, 'source_sha256': hashlib.sha256(source.read_bytes()).hexdigest(), 'binary_sha256': hashlib.sha256(binary.read_bytes()).hexdigest()})
    (RECORD / 'aa-commands.json').write_text(json.dumps(records, indent=2) + '\n')
    print('aa-' + route, completed.returncode, flush=True)
    if completed.returncode:
        print(completed.stdout[-5000:])
        raise SystemExit(completed.returncode)
