#!/usr/bin/env python3
"""Run the two existing HTTP/2 journeys with frozen commands and raw epochs."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

SOURCE = Path('/mnt/c/public/project-hyle/hyle')
RECORD = SOURCE / '.scratch/perf-review-2026-10-18/http2'
BUILD = Path('/root/hyle-scratch/http2-current-20261018')
commands = json.loads((RECORD / 'build-commands.json').read_text())

if sys.argv[1] == 'rebuild':
    records = []
    for old in commands:
        if old['name'] not in ['bench_io_http2_http2_p1_bench.cc', 'link']:
            continue
        completed = subprocess.run(old['argv'], cwd=BUILD, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
        (RECORD / ('current-' + old['name'] + '.log')).write_text(completed.stdout)
        records.append({**old, 'returncode': completed.returncode})
        (RECORD / 'current-build-commands.json').write_text(json.dumps(records, indent=2) + '\n')
        if completed.returncode:
            print(completed.stdout[-5000:])
            raise SystemExit(completed.returncode)
    identity = json.loads((RECORD / 'build-identity.json').read_text())
    for item in identity['sources']:
        item['sha256'] = hashlib.sha256((SOURCE / item['path']).read_bytes()).hexdigest()
    identity['binary_sha256'] = hashlib.sha256((BUILD / 'http2_current').read_bytes()).hexdigest()
    (RECORD / 'current-build-identity.json').write_text(json.dumps(identity, indent=2) + '\n')
    print('rebuild passed', flush=True)
    raise SystemExit(0)

names = ['smoke'] if sys.argv[1] == 'smoke' else ['formal-0-current-first', 'formal-1-peer-first', 'formal-2-peer-first', 'formal-3-current-first']
records = []
for name in names:
    env = os.environ.copy()
    for key in ['HYLE_BENCH_SMOKE', 'HYLE_BENCH_RIVAL_FIRST', 'HYLE_BENCH_JSON']:
        env.pop(key, None)
    if name == 'smoke':
        env['HYLE_BENCH_SMOKE'] = '1'
    elif 'peer-first' in name:
        env['HYLE_BENCH_RIVAL_FIRST'] = '1'
    env['HYLE_PERF_RUN_NONCE'] = name
    env['HYLE_BENCH_JSON'] = str(RECORD / name)
    argv = ['taskset', '-c', '2', str(BUILD / 'http2_current')]
    start = time.time()
    completed = subprocess.run(argv, env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, timeout=30)
    (RECORD / (name + '.log')).write_text(completed.stdout)
    records.append({'name': name, 'argv': argv, 'cwd': os.getcwd(), 'environment': {key: value for key, value in env.items() if key.startswith('HYLE_')}, 'returncode': completed.returncode, 'elapsed_seconds': time.time() - start})
    (RECORD / (sys.argv[1] + '-commands.json')).write_text(json.dumps(records, indent=2) + '\n')
    print(name, completed.returncode, flush=True)
    if completed.returncode:
        print(completed.stdout[-5000:])
        raise SystemExit(completed.returncode)
