from pathlib import Path
import argparse, hashlib, json, os, shlex, subprocess

ROOT = Path('/mnt/c/public/project-hyle/hyle')
HERE = ROOT / '.scratch/perf-review-2026-10-18/http2/current-holdout'
PRIOR = HERE.parent
CACHE = Path('/root/hyle-scratch/io-watch-v2-dev')
OLD = Path('/root/hyle-scratch/http2-current-20261018')
OUT = OLD / 'current-holdout'
OUT.mkdir(exist_ok=True)
records = json.loads((HERE/'commands.json').read_text()) if (HERE/'commands.json').exists() else []

def run(name, argv, env=None, timeout=60):
    argv = list(map(str,argv))
    result = subprocess.run(argv,cwd=OUT,env=env,capture_output=True,text=True,timeout=timeout)
    (HERE/(name+'.stdout.txt')).write_text(result.stdout)
    (HERE/(name+'.stderr.txt')).write_text(result.stderr)
    records.append(dict(name=name,argv=argv,cwd=str(OUT),exit=result.returncode,
        environment={k:v for k,v in (env or {}).items() if k.startswith(('HYLE_','LD_LIBRARY_PATH'))}))
    (HERE/'commands.json').write_text(json.dumps(records,indent=2)+'\n')
    print(name,result.returncode,result.stdout[-1700:],result.stderr[-1200:],flush=True)
    if result.returncode:
        raise RuntimeError(name)
    return result.stdout

def identity(p):
    return dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())

env = {k:v for k,v in os.environ.items() if not k.startswith(('HYLE_BENCH_','HYLE_PERF_'))}
env['LD_LIBRARY_PATH'] = str(OUT)+':'+str(CACHE/'bin')
parser=argparse.ArgumentParser(); parser.add_argument('action',choices=['build','finish-build','measure']); args=parser.parse_args()
if args.action != 'measure':
    for source,snapshot in [('src/io_http2/http2.cc','http2.current.cc'),('src/io_core/proactor.cc','proactor.current.cc'),('bench/io_http2/http2_p1_bench.cc','http2_p1_bench.cc')]:
        assert (ROOT/source).read_bytes()==(HERE/snapshot).read_bytes()
    h2cmd=json.loads((PRIOR/'build-candidate-commands.json').read_text())
    cmd=next(x['argv'] for x in h2cmd if x['name']=='compile-candidate')
    if args.action == 'build':
        run('compile-http2',cmd[:-4]+['-c',HERE/'http2.current.cc','-o',OUT/'http2.o'],env)
    old=json.loads((PRIOR/'current-build-commands.json').read_text())
    cmd=next(x['argv'] for x in old if x['name']=='bench_io_http2_http2_p1_bench.cc')
    if args.action == 'build':
        run('compile-main',cmd[:-4]+['-c',HERE/'main.cc','-o',OUT/'main.o'],env)
    direct=ROOT/'.scratch/perf-review-2026-10-18/io-direct-slots'
    compdb=json.loads((direct/'compdb.stdout.txt').read_text())
    cmd=shlex.split(next(x['command'] for x in compdb if x['file'].endswith('/src/io_core/proactor.cc')))
    cleaned=[]; i=0
    while i<len(cmd):
        if cmd[i] in ('-MT','-MF','-o','-c'): i+=2
        elif cmd[i]=='-MD': i+=1
        else: cleaned.append(cmd[i]); i+=1
    if args.action == 'build':
        run('compile-proactor',cleaned+['-c',HERE/'proactor.current.cc','-o',OUT/'proactor.o'],env)
    raw=(direct/'link-commands.stdout.txt').read_text()
    line=next(x for x in raw.splitlines() if ' -o bin/libhyle_io_core.so.0.1.0 ' in x)
    cmd=shlex.split(line[len(': && '):-len(' && :')])
    cmd[cmd.index('-o')+1]=str(OUT/'libhyle_io_core.so.0.1.0')
    cmd[cmd.index('src/io_core/CMakeFiles/hyle_io_core.dir/proactor.cc.o')]=str(OUT/'proactor.o')
    # The original link's remaining object arguments are relative to its cache.
    cmd=[str(CACHE/x) if (x.endswith('.o') or x.startswith('bin/')) and not Path(x).is_absolute() else x for x in cmd]
    run('link-current-core',cmd,env)
    link=next(x['argv'] for x in old if x['name']=='link')
    link=[str(OUT/'consumer') if x.endswith('/http2_current') else
          str(OUT/'http2.o') if x.endswith('/src_io_http2_http2.cc.o') else
          str(OUT/'main.o') if x.endswith('/bench_io_http2_http2_p1_bench.cc.o') else x for x in link]
    run('link-consumer',link,env)
    loader=run('loader',['ldd',OUT/'consumer'],env)
    assert str(OUT/'libhyle_io_core.so.0.1.0') in loader
    smoke=env.copy(); smoke['HYLE_BENCH_SMOKE']='1'
    run('smoke',['timeout','--kill-after=2s','20s','taskset','-c','2',OUT/'consumer'],smoke)
    files={Path(x).resolve() for x in link+cmd if x.endswith(('.o','.a'))}
    for line in loader.splitlines():
        if 'libhyle_' in line and '=>' in line:
            files.add(Path(line.split('=>',1)[1].strip().split()[0]).resolve())
    previous=json.loads((PRIOR/'build-identity.json').read_text())
    reused_source_match=[dict(path=x['path'],same_sha256=identity(ROOT/x['path'])['sha256']==x['sha256'])
        for x in previous['sources'] if x['path'] not in ('src/io_http2/http2.cc','bench/io_http2/http2_p1_bench.cc')]
    (HERE/'build-identity.json').write_text(json.dumps(dict(
        fresh_sources=[identity(HERE/n) for n in ['http2.current.cc','proactor.current.cc','http2_p1_bench.cc','main.cc']],
        files=[identity(p) for p in sorted(files)],consumer=identity(OUT/'consumer'),
        unchanged_reused_source=reused_source_match,
        method='Only currentHTTP2/proactor and oneholdout wrapper TU fresh. Existing other IO/foundation object cache reused; not wholeHEAD. Peer canonical bytes identical to corrected stage3.',
        no_configure_sdk_copy_download=True),indent=2)+'\n')
else:
    assert not any(x['name'].startswith('formal-') for x in records), 'Fixed formal schedule already attempted; do not rerun.'
    for order in ['ab','ba']:
        runenv=env.copy(); runenv['HYLE_BENCH_JSON']=str(HERE/('epochs-'+order))
        if order=='ba': runenv['HYLE_BENCH_RIVAL_FIRST']='1'
        run('formal-'+order,['timeout','--kill-after=2s','30s','taskset','-c','2',OUT/'consumer'],runenv,timeout=35)
