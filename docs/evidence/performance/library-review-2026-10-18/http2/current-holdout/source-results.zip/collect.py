from pathlib import Path
import hashlib, json, os, platform, subprocess

ROOT=Path('/mnt/c/public/project-hyle/hyle')
HERE=ROOT/'.scratch/perf-review-2026-10-18/http2/current-holdout'
OUT=Path('/root/hyle-scratch/http2-current-20261018/current-holdout')
def record(p):
    return dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
artifacts=[record(p) for p in OUT.iterdir() if p.is_file()]
(HERE/'cleanup-candidates.json').write_text(json.dumps(dict(host='WSL',directory=str(OUT),
    files=artifacts,total_bytes=sum(x['bytes'] for x in artifacts),
    note='Only currentrun artifacts. No deletion performed; root test.ps1 exact path/size/SHA cleanup. Existing sharedcache remains.'),indent=2)+'\n')
cpu=next(x.split(':',1)[1].strip() for x in Path('/proc/cpuinfo').read_text().splitlines() if x.startswith('model name'))
(HERE/'host-metadata.json').write_text(json.dumps(dict(uname=platform.uname()._asdict(),
    cpu_model=cpu,compiler=subprocess.check_output(['g++-14','--version'],text=True),
    nghttp2_lock_source='/root/.cache/hyle/dependencies/v1/sources/nghttp2-85e300c79fb6-ca7aa79a25b3',
    method='Post-run read-only metadata, no newconsumer execution. Formal commands explicitly tasksetCPU2; no actual during-formal perTID resource snapshot was collected.',
    thread_configuration='One persistent HyleScheduler worker and one persistent RawHarness worker are both present; one route active, external caller waits for completion. Does not assert observed exactOSthread count.',
    loader_environment_postrun={k:os.environ.get(k) for k in ['LD_PRELOAD','LD_AUDIT','HYLE_IO_FORCE_EPOLL']}),indent=2)+'\n')
print(len(artifacts),sum(x['bytes'] for x in artifacts))
