from pathlib import Path
import hashlib, json, statistics, subprocess, zipfile

ROOT=Path(__file__).resolve().parents[4]
HERE=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
rows=[]
for order in ['ab','ba']:
    data=json.loads((HERE/f'epochs-{order}-4.json').read_text())['results']
    arms=[]
    for r in data:
        assert len(r['measurements'])==9 and r['batch']==4
        per_stream=[m['elapsed']/4 for m in r['measurements']]
        median=statistics.median(per_stream)
        assert abs(median-r['median(elapsed)']/4)<1e-12
        arms.append(dict(name=r['name'],median_ns_per_stream=median*1e9,
            MAPE=r['medianAbsolutePercentError(elapsed)'],
            clock_resolution_seconds=r['clockResolution'],
            configured_min_epoch_seconds=r['minEpochTime'],
            all_epoch_seconds_per_stream=per_stream,
            all_epoch_iterations=[m['iterations'] for m in r['measurements']],
            all_actual_epoch_durations_seconds=[m['elapsed']*m['iterations'] for m in r['measurements']]))
    h=next(r for r in arms if r['name'].startswith('HYLE'))
    p=next(r for r in arms if not r['name'].startswith('HYLE'))
    rows.append(dict(order=order,arms=arms,
        hyle_slower_percent=100*(h['median_ns_per_stream']/p['median_ns_per_stream']-1)))
identity=json.loads((HERE/'build-identity.json').read_text())
for source,snapshot in [('src/io_http2/http2.cc','http2.current.cc'),('src/io_core/proactor.cc','proactor.current.cc'),('bench/io_http2/http2_p1_bench.cc','http2_p1_bench.cc')]:
    assert sha(ROOT/source)==sha(HERE/snapshot)
assert '# holdout smoke hyle=4 peer=4' in (HERE/'smoke.stderr.txt').read_text()
records=json.loads((HERE/'commands.json').read_text())
formal=[r for r in records if r['name'].startswith('formal-')]
assert len(formal)==2 and all(r['exit']==0 for r in formal)
assert all(x['same_sha256'] for x in identity['unchanged_reused_source'])
summary={
 'result':'Current corrected HTTP2 retains a larger point latency than the unchanged corrected manual-loop peer in both fixed orders. This is a finite current same-application-work observation, not universal performance or statistical-significance proof.',
 'head_at_packaging':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),
 'scope':{'trace':'Only original4streams x256KiB request andresponse, reverse pair completion, original connection-window holdout',
     'processes':2,'orders':['Hyle thenmanual','manual thenHyle'],'epochs_per_arm':9,
     'all_epochs_retained':True,'no_extra_AA_retry_or_shape':True,'product_modified':False},
 'results':rows,
 'correctness_and_timing':{
     'smoke':'One same-trace uninstrumented smoke, hyle=4/peer=4. Each formal arm also has the original one complete warmup outside its measured bench.',
     'retained_work':'Fresh socketpair/nonblocking setup, sessions/HPACK/headers, all request/response bytes and comparisons, reverse responses, stream+connection flow consumption, external completion handoff and session/socket cleanup remain in each run callback.',
     'hyle_driver':'Original public TcpStream::adopt, two spawn_task endpoint fibers and JoinHandle::join on one persistent Scheduler worker. Existing wrapper unchanged; no new explicit Scheduler::drain/offstack barrier was added.',
     'manual_driver':'Same original corrected next_response_pair scheduling plus recv(MSG_DONTWAIT)/send(MSG_DONTWAIT|MSG_NOSIGNAL). Persistent rawworker and caller CV handoff; original directnghttp2 state/body storage and teardown.',
     'shared_outside_timing':'Body-string generation and both persistent harnesses/workercreation/destruction outside callbacks, one route active at a time.',
     'not_equal_strategy':'The two-fiber public driver and one manual dual-endpoint loop are deliberately different execution strategies. No attribution to pure scheduler, kernel time, a removed copy or the recent correctness fixes is made.',
     'hardware_counters':'Both formal stdout preserve perf_event_open unavailable notice. Zero/missing cycle/instruction/contextswitch fields are not interpreted as measured absence of work.',
 },
 'closure':{
     'fresh_TUs':['Current src/io_http2/http2.cc including headerstorage and bodyring fixes','Current src/io_core/proactor.cc includingCQE tokenindex/directslot/hint changes','Onlyholdout wrapper TU including a byte-identical canonicalbench snapshot'],
     'peer_sha256':sha(HERE/'http2_p1_bench.cc'),
     'peer_matches':'Exactly matches canonical bench and stage3 product/http2_p1_bench.cc bytes; fixture and both implementations unchanged.',
     'loader':'ldd confirms current-holdout/libhyle_io_core.so.0.1.0. Existing remaining io_core objects and shared foundation retained; not a wholeHEAD rebuild.',
     'reused_source_matches':identity['unchanged_reused_source'],
     'source_sha256':{name:sha(HERE/name) for name in ['http2.current.cc','proactor.current.cc','http2_p1_bench.cc','main.cc']},
     'no_configure_SDK_copy_download':True,
 },
 'resource_limits':{
     'affinity':'Both recorded commands tasksetCPU2; not a physicalhost Pcore claim. Source config retains1Hyle worker plus1RawHarness worker and caller. No during-formal actual perTID/count snapshot collected.',
     'backend':'Same fresh io_core library loaded in both processes. No capability query/counter instrumented in these formal runs, so prior separate io_uring evidence is not silently a current-run backend certificate.',
     'cache':'All reusable objects/libraries and freshconsumer hashes recorded in build-identity.json. Post-run host metadata separately labeled.',
 },
 'previous_data':'Old stage3 12.7/15.1% belongs to its preheader/prering source. New15.62/17.46% points establish the issue survives this source refresh, but comparing these separate rounds cannot assign causal speed change to either correctness fix.',
 'failures_preserved':'Initial corelink failed because inheritedrelativebin libraries were resolved from the new working directory. Frozen failure runner/commands/stderr retained. Onlypath resolution fixed, three already compiled TUs reused; no fixture change or formal retry.',
 'next':'Stopped after the two planned processes. Current gap remains unresolved; no extra shape, repeated AB/AA, probe, product optimization or cause claim.',
}
(HERE/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
with zipfile.ZipFile(HERE/'source-results.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for p in sorted(HERE.iterdir(),key=lambda p:p.name):
        if p.is_file() and p.suffix in {'.cc','.py','.json','.txt'} and p.name!='archive-record.json':
            z.write(p,p.name)
record={name:{'path':(HERE/name).relative_to(ROOT).as_posix(),'bytes':(HERE/name).stat().st_size,'sha256':sha(HERE/name)}
    for name in ['summary.json','source-results.zip','cleanup-candidates.json']}
(HERE/'archive-record.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record,indent=2))
print('points',[(r['order'],r['hyle_slower_percent']) for r in rows])
