// The canonical bench is unchanged; select only its original large-body trace.
#define main original_http2_bench_main
#include "http2_p1_bench.cc"
#undef main

int main() {
  std::signal(SIGPIPE, SIG_IGN);
  const bool peer_first = std::getenv("HYLE_BENCH_RIVAL_FIRST") != nullptr;
  const Workload holdout = make_workload(
      "HTTP/2 flow-control holdout 4x256KiB", 4, 256 * 1024,
      256 * 1024, NGHTTP2_INITIAL_CONNECTION_WINDOW_SIZE);
  HyleHarness hyle;
  RawHarness peer;
  if (std::getenv("HYLE_BENCH_SMOKE") != nullptr) {
    const int hyle_result = hyle.run(holdout);
    const int peer_result = peer.run(holdout);
    std::fprintf(stderr, "# holdout smoke hyle=%d peer=%d\n",
                  hyle_result, peer_result);
    return hyle_result == holdout.streams && peer_result == holdout.streams ? 0 : 2;
  }
  run_workload(holdout, hyle, peer, peer_first);
}
