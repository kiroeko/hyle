from pathlib import Path
import hashlib
import json
import zipfile
root=Path(__file__).resolve().parents[3]
out=Path(__file__).resolve().parent
dest=root/'docs/evidence/performance/library-review-2026-10-18/http2/tcp-transport'
summary=json.loads((dest/'summary.json').read_text(encoding='utf-8'))
completed=json.loads((out/'cleanup-executed.log').read_text(encoding='utf-8-sig').splitlines()[-1])
assert completed==dict(status='completed',deleted_files=17,deleted_bytes=8789568,retained_files_verified=7,directories_removed=0)
with zipfile.ZipFile(dest/'cleanup.zip','x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
    archive.write(root/'test.ps1','test.ps1')
    for name in ('cleanup-executed.log','prepare_cleanup.py','write_cleanup.py','finalize.py','artifact-plan.json'):
        archive.write(out/name,name)
summary['cleanup_execution']=completed
summary['cleanup_archive']={'bytes':(dest/'cleanup.zip').stat().st_size,'sha256':hashlib.sha256((dest/'cleanup.zip').read_bytes()).hexdigest()}
(dest/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
for path in dest.glob('*.zip'):
    with zipfile.ZipFile(path) as archive: assert archive.testzip() is None
print('Final evidence and exact cleanup archived; accepted product unchanged, permanent benchmark retained.')
