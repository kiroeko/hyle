# One-time exact cleanup after HTTP2 transport diagnosis. Already frozen sources/raw/maps remain.
$ErrorActionPreference = 'Stop'
$archive = Join-Path $PSScriptRoot 'docs/evidence/performance/library-review-2026-10-18/http2/tcp-transport/source-results.zip'
if ((Get-FileHash -LiteralPath $archive -Algorithm SHA256).Hash.ToLowerInvariant() -ne '213079ac10f026ae9fd1d92d20aa459e2e3f02a6db3615a7e3e898903993cae6') { throw 'Frozen evidence archive mismatch' }
$pythonSource = @'
import hashlib, json, os, stat
from pathlib import Path
root=Path('/root/hyle-scratch/http2-current-20261018')
targets = [
    (Path('/root/hyle-scratch/http2-current-20261018/hot-work/abi/candidate'), 898504, 'e16fef59b7dba88608e6e89e5fd3c60ae299a1e359d659e8eaface54b983aadb'),
    (Path('/root/hyle-scratch/http2-current-20261018/hot-work/abi/http2.o'), 225752, '1c98187a2bb20f4122343ad5cd647638f71232e8b2fc67a8e570499f3f8b3e12'),
    (Path('/root/hyle-scratch/http2-current-20261018/hot-work/abi/probe'), 888544, 'dc9bd8109fe3175d42fda7af9d098176de1586f8ddddb5da17a2ee3fcd4b2703'),
    (Path('/root/hyle-scratch/http2-current-20261018/hot-work/abi/probe-consumer.o'), 123304, '4ba288ac8cf086114d9eca33a4986d2bae3b110e1afd843433cb4a1cf203acbf'),
    (Path('/root/hyle-scratch/http2-current-20261018/hot-work/abi/probe-product.o'), 231656, 'bb506937bd3f72d8b8d0a83957ea7854c348c705797281ff85549d315b5155c2'),
    (Path('/root/hyle-scratch/http2-current-20261018/hot-work/abi/tests'), 1618560, 'a003bde5ef33575e4287c26f174c89fe165ee06371529d21a51fc92b114454d8'),
    (Path('/root/hyle-scratch/http2-current-20261018/hot-work/attempt-2/consumer.o'), 160560, '4471651385c9eb7a9874c2c7c9ecf0735de066b683d4881bac3ba5903d455051'),
    (Path('/root/hyle-scratch/http2-current-20261018/hot-work/attempt-2/diagnostic'), 898480, '6146ba9d4d9b41b1b626bdb3df360561bd191c7ee14cf5b4e5e0276464861c58'),
    (Path('/root/hyle-scratch/http2-current-20261018/hot-work/attempt-2/product.o'), 220320, 'a3850b6449e9ff2c7a6acab56018177fa12d73775d6da97d9f320644e5dbbf8a'),
    (Path('/root/hyle-scratch/http2-current-20261018/hot-work/consumer.o'), 160560, 'f28be1b52923642f39493648a32497c8a7801df37bcff41b9d9d3686ae71c81f'),
    (Path('/root/hyle-scratch/http2-current-20261018/hot-work/product.o'), 193824, '54ccb3feb298ed38beaa1cd4ba8c9c3683c64b2c433c3fbc3e2e4e9216e7e41f'),
    (Path('/root/hyle-scratch/http2-current-20261018/hot-work/transport/transport'), 901544, '31bc99c91a8dbea3478e447953b1b3ae3882ae7101d7421cd269649448115aa3'),
    (Path('/root/hyle-scratch/http2-current-20261018/hot-work/transport/transport-counts'), 902792, 'bebe33e46e72fe3cbdd2862ec6488d2b9aa3bdb2c04a32fa3bdbf6ff3b138ebc'),
    (Path('/root/hyle-scratch/http2-current-20261018/hot-work/transport/transport-counts.o'), 161624, '659ec65ca1ec96da55b0b7e6c746d5635c85a1ca45fcf5c9d0ddb8c400a75e10'),
    (Path('/root/hyle-scratch/http2-current-20261018/hot-work/transport/transport.o'), 153944, 'bab7355e8c535ab1651a88e4fcb7e6c64eeb060de925dc5575387a234b9d1c6a'),
    (Path('/root/hyle-scratch/http2-current-20261018/owner-loop/layout-new'), 898496, '3123e43a9c4e015241242673b9dc90d7c6d4ca26f72408ef53b5690cd29e4870'),
    (Path('/root/hyle-scratch/http2-current-20261018/root-cause-product/consumer.o'), 151104, '62a132158e443d6fae3df9c9ea8b4ccba19e71a21aeac9ffef6042d03df5b2b2'),
]
retained = [
    (Path('/root/hyle-scratch/http2-current-20261018/current-holdout/libhyle_io_core.so.0.1.0'), 387104, '9ead235b1bbd72f56d44eab9c8ac135b8c4b0ce0ec0a6fb72660aa917d3b4779'),
    (Path('/root/hyle-scratch/http2-current-20261018/owner-loop/http2.o'), 225824, '7c214427285e21da16dab647d0b5793b8b209554bf5f8d3ef20d4435653aa82e'),
    (Path('/root/hyle-scratch/http2-current-20261018/owner-loop/http2_test.o'), 739800, '7ffb3dac38465532c8980032a5f3dbee401ac7feec915f51c26eeb2ddd879f5c'),
    (Path('/root/hyle-scratch/http2-current-20261018/owner-loop/tests-candidate'), 1618552, '97a8e618a6db7c621e770e37f349313f0ffeda99b7b66334016a96c3db52991a'),
    (Path('/root/hyle-scratch/http2-current-20261018/paired-comparison-v2/nanobench.o'), 283672, '43b16d764541dc1460c6aba273360f40403bcc35ee2feb37461f7f4d29984987'),
    (Path('/root/hyle-scratch/http2-current-20261018/hot-work/final/consumer.o'), 151688, 'cadce3affee2fa801f8d42d8a6d8bf307ac69461151af36f94fd582b4f1c5f7d'),
    (Path('/root/hyle-scratch/http2-current-20261018/hot-work/final/benchmark'), 898496, '44cae8ca0209044da106c677c917ab272571d365cec4b6baffa79ea3c870ed36'),
]

assert root.resolve(strict=True)==root
assert len({item[0] for item in targets+retained})==len(targets)+len(retained)
def inspect(item):
    path,size,digest=item
    assert path.is_absolute() and path.is_relative_to(root)
    part=Path(path.anchor)
    for name in path.parts[1:]:
        part/=name
        assert not stat.S_ISLNK(part.lstat().st_mode), str(part)
    assert path.resolve(strict=True)==path
    before=path.lstat()
    assert stat.S_ISREG(before.st_mode) and before.st_size==size
    with os.fdopen(os.open(path,os.O_RDONLY|os.O_NOFOLLOW),'rb') as source:
        opened=os.fstat(source.fileno())
        assert (opened.st_dev,opened.st_ino)==(before.st_dev,before.st_ino)
        actual=hashlib.sha256(source.read()).hexdigest()
        after=os.fstat(source.fileno())
    now=path.lstat()
    assert actual==digest and after.st_size==size
    assert (now.st_dev,now.st_ino,now.st_size)==(after.st_dev,after.st_ino,after.st_size)
    return now.st_dev,now.st_ino
identities={item[0]:inspect(item) for item in targets+retained}
for proc in Path('/proc').iterdir():
    if not proc.name.isdigit(): continue
    try: executable=os.readlink(proc/'exe')
    except (OSError,PermissionError): continue
    assert executable not in {str(item[0]) for item in targets}, 'Target still running: '+proc.name
print(json.dumps({'preflight_delete_files':len(targets),'delete_bytes':sum(item[1] for item in targets),'retain_files':len(retained)}),flush=True)
for item in targets:
    assert inspect(item)==identities[item[0]]
    item[0].unlink()
    print('Deleted exact generated file: '+str(item[0]),flush=True)
for item in retained:
    assert inspect(item)==identities[item[0]]
print(json.dumps({'status':'completed','deleted_files':len(targets),'deleted_bytes':sum(item[1] for item in targets),'retained_files_verified':len(retained),'directories_removed':0}),flush=True)
'@
$payload = [Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes($pythonSource))
$code = 'import base64;exec(base64.b64decode("' + $payload + '"))'
& wsl.exe -d Ubuntu-24.04 -u root --exec python3 -c $code
if ($LASTEXITCODE -ne 0) { throw "Exact WSL cleanup failed: $LASTEXITCODE" }
