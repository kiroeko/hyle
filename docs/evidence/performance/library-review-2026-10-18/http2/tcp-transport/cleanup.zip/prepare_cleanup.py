from pathlib import Path
out=Path(__file__).resolve().parent
template=(out.parent/'http2-phase-costs/write_cleanup.py').read_text(encoding='utf-8')
template=template.replace('http2/phase-costs/source-results.zip','http2/tcp-transport/source-results.zip')
template=template.replace('HTTP2 phase-cost diagnosis','HTTP2 transport diagnosis')
(out/'write_cleanup.py').write_text(template,encoding='utf-8',newline='\n')
