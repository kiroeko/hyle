"""Untimed work accounting: exact native/transport/body counters, no latency claim."""
from pathlib import Path
import hashlib
import json
import os
import subprocess

root=Path('/mnt/c/public/project-hyle/hyle')
scratch=Path(__file__).resolve().parent.parent
out=Path(__file__).resolve().parent/'attempt-2'
out.mkdir(exist_ok=False)
remote=Path('/root/hyle-scratch/http2-current-20261018/hot-work/attempt-2')
remote.mkdir(exist_ok=False)
base=json.loads((scratch/'http2-paired-run/attempt-2/build.json').read_text())
flags=next(c['argv'] for c in base['commands'] if c['name']=='compile-consumer')
flags=flags[:flags.index('-c')]
env=dict(os.environ,**base['environment'])
labels=[]
def add(name,amount='1'):
    if name not in labels: labels.append(name)
    return f'diag::add({labels.index(name)}, {amount});'
def inject(source,needle,extra):
    assert source.count(needle)==1,needle
    return source.replace(needle,needle+'\n  '+extra)

product=(root/'src/io_http2/http2.cc').read_text()
assert hashlib.sha256((root/'src/io_http2/http2.cc').read_bytes()).hexdigest()=='30b57207730af05b29e3037d22427b67d35df6f5c4b69a1f99846c9630e6482f'
consumer=(root/'bench/io_http2/http2_p1_bench.cc').read_text()
assert hashlib.sha256((root/'bench/io_http2/http2_p1_bench.cc').read_bytes()).hexdigest()=='96c1659810ca5d9e11610f937d619d122615f17cd4e3f3519ced9c0f255f6d63'
entries=[
('  Http2StreamState *find(std::int32_t id) noexcept {','own_stream_find'),
('void Http2SessionState::collect_garbage() noexcept {','gc_calls'),
('    destroy_stream(*this, stream);','gc_destroy'),
('Status check_operation(const Http2SessionState &state,\n                       OperationOptions options) noexcept {','operation_checks'),
('ProgressResult try_read_once(Http2SessionState &state) noexcept {','try_read'),
('void complete_wire_frame(Http2SessionState &state) noexcept {','wire_completed'),
('ProgressResult flush_once(mem::AllocatorRef allocator, Http2SessionState &state,\n                          OperationOptions options) noexcept {','flush_calls'),
('ProgressResult read_once(mem::AllocatorRef allocator, Http2SessionState &state,\n                         OperationOptions options) noexcept {','async_read'),
('                   Ready ready, OperationOptions options) noexcept {','drive_calls'),
('bool Http2BodyReader::valid() const noexcept {','reader_valid'),
('Status acknowledge_body(Http2SessionState &state,\n                        Http2StreamState &stream) noexcept {','ack_helper'),
('    mem::AllocatorRef allocator, Http2BodyReader &reader, std::size_t max_bytes,\n    OperationOptions options) noexcept {','read_body_calls'),
('Status wait_for_change(Http2SessionState &state, OperationOptions options,\n                       std::uint64_t observed) noexcept {','wait_change'),
]
for needle,label in entries:
    if label=='gc_destroy':
        # One inside session destruction and one in collection: count separately.
        begin=product.index('void Http2SessionState::collect_garbage() noexcept {')
        head,tail=product[:begin],product[begin:]
        tail=inject(tail,needle,add(label))
        product=head+tail
    else: product=inject(product,needle,add(label))
product=inject(product,'    if (encoded == 0 && state.wire.size == 0) {',add('empty_flush'))
product=inject(product,'  stream->inbound.size += length;',add('incoming_callbacks')+add('incoming_bytes','length'))
product=inject(product,'    std::memcpy(stream->inbound.data + tail, data, first);',add('incoming_copy_calls')+add('incoming_copy_bytes','first'))
needle='''    if (length != first)
      std::memcpy(stream->inbound.data, data + first, length - first);'''
assert product.count(needle)==1
product=product.replace(needle,'''    if (length != first) {
      std::memcpy(stream->inbound.data, data + first, length - first);
      '''+add('incoming_copy_calls')+add('incoming_copy_bytes','length-first')+add('ring_wrap')+'\n    }')
product=inject(product,'  stream.body_borrowed = true;',add('delivered_chunks')+add('delivered_bytes','count'))
product=inject(product,'    Status accepted = sink(sink_state, *chunk);',add('verify_calls')+add('verify_bytes','chunk->bytes.size()'))
product=inject(product,'  const std::size_t consumed = stream.borrowed_bytes;',add('ack_borrowed')+add('ack_borrowed_bytes','consumed'))
begin=product.index('template <class Ready>\nStatus drive_until(')
end=product.index('bool valid_string(',begin)
part=product[begin:end]
part=inject(part,'  for (;;) {',add('drive_turns'))
product=product[:begin]+part+product[end:]

consumer=inject(consumer,'  const std::size_t buffered = stream->inbound.size() - stream->inbound_start;',add('incoming_callbacks')+add('incoming_bytes','length'))
consumer=inject(consumer,'      stream->inbound.insert(stream->inbound.end(), data, data + length);',add('incoming_copy_calls')+add('incoming_copy_bytes','length'))
consumer=inject(consumer,'    stream->inbound.resize(buffered);',add('compaction_calls')+add('compaction_bytes','buffered'))
consumer=inject(consumer,'      if (stream.received + count > expected_body.size() ||',add('verify_calls')+add('verify_bytes','count')+add('delivered_chunks')+add('delivered_bytes','count'))
# Place verification accounting before the if, not inside its condition.
bad='''      if (stream.received + count > expected_body.size() ||\n  '''+add('verify_calls')+add('verify_bytes','count')+add('delivered_chunks')+add('delivered_bytes','count')
assert consumer.count(bad)==1
consumer=consumer.replace(bad,'      '+add('verify_calls')+add('verify_bytes','count')+add('delivered_chunks')+add('delivered_bytes','count')+'\n      if (stream.received + count > expected_body.size() ||')
consumer=inject(consumer,'bool raw_fill_output(RawEndpoint &endpoint, RawWire &wire) noexcept {',add('flush_calls'))

wrapper='''
#include <dlfcn.h>
extern "C" void real_yield() asm("__real__ZN4hyle5sched5Fiber5yieldEv");
extern "C" __attribute__((visibility("default"))) void wrap_yield() asm("__wrap__ZN4hyle5sched5Fiber5yieldEv");
extern "C" __attribute__((visibility("default"))) void wrap_yield() { YIELD_COUNT real_yield(); }
'''.replace('YIELD_COUNT',add('explicit_yield'))
for fn in ('send','recv'):
    buffer='const void *buffer' if fn=='send' else 'void *buffer'
    wrapper+=f'''extern "C" __attribute__((visibility("default"))) ssize_t {fn}(int fd, {buffer}, size_t length, int flags) {{
  static const auto actual=reinterpret_cast<decltype(&::{fn})>(::dlsym(RTLD_NEXT,"{fn}"));
  if (!actual) std::abort();
  const auto result=actual(fd,buffer,length,flags);
  const int saved_errno=errno;
  {add(fn+'_calls')}
  if(result>0) {{ {add(fn+'_success')} {add(fn+'_bytes','static_cast<unsigned long long>(result)')} diag::{fn}_sizes[static_cast<std::size_t>(result)].fetch_add(1,std::memory_order_relaxed); }}
  else if(result<0 && (saved_errno==EAGAIN || saved_errno==EWOULDBLOCK)) {{ {add(fn+'_eagain')} }}
  else if(result==0) {{ {add(fn+'_zero')} }}
  else {{ {add(fn+'_other_error')} }}
  errno=saved_errno;
  return result;
}}
'''
native=[
 ('nghttp2_session_mem_recv2','nghttp2_ssize','nghttp2_session *s, const uint8_t *bytes, size_t length','s,bytes,length',add('native_recv')+add('native_recv_bytes','length')),
 ('nghttp2_session_mem_send2','nghttp2_ssize','nghttp2_session *s, const uint8_t **bytes','s,bytes',add('native_send')),
 ('nghttp2_session_consume_stream','int','nghttp2_session *s, int32_t id, size_t size','s,id,size',add('consume_stream')+add('consume_stream_bytes','size')),
 ('nghttp2_session_consume_connection','int','nghttp2_session *s, size_t size','s,size',add('consume_connection')+add('consume_connection_bytes','size')),
]
for name,ret,args,call,count in native:
    wrapper+=f'extern "C" {ret} __real_{name}({args});\nextern "C" {ret} __wrap_{name}({args}) {{ {count} const auto result=__real_{name}({call});'
    if name=='nghttp2_session_mem_send2':
        wrapper+=f'if(result>0) {{ {add("native_send_positive")} {add("native_send_bytes","static_cast<unsigned long long>(result)")} }} else if(result==0) {{ {add("native_send_zero")} }}'
    wrapper+='return result;}\n'

main=r'''
int main(int argc,char **argv) {
  if(argc!=2) return 2;
  const std::string_view arm(argv[1]);
  if(arm!="hyle" && arm!="reference") return 2;
  std::signal(SIGPIPE,SIG_IGN);
  const auto workload=make_workload("HTTP2 exact hot work",4,256*1024,256*1024,
                                  NGHTTP2_INITIAL_CONNECTION_WINDOW_SIZE);
  { HyleHarness harness;
    for(unsigned i=0;i!=20;++i)
      if((arm=="hyle"?harness.run(workload):run_task_peer(harness,workload,i==0))!=4) return 3;
  }
  std::printf("{\"arm\":\"%s\",\"episodes\":20,\"all_oracles_passed\":true,\"counters\":{",argv[1]);
  for(unsigned i=0;i!=DIAG_COUNT;++i)
    std::printf("%s\"%s\":%llu",i?",":"",diag::labels[i],diag::counts[i].load());
  std::printf("},\"recv_sizes\":{");
  bool comma=false;
  for(unsigned i=1;i!=65537;++i) if(auto count=diag::recv_sizes[i].load()) {
    std::printf("%s\"%u\":%llu",comma?",":"",i,count); comma=true;
  }
  std::printf("},\"send_sizes\":{");
  comma=false;
  for(unsigned i=1;i!=65537;++i) if(auto count=diag::send_sizes[i].load()) {
    std::printf("%s\"%u\":%llu",comma?",":"",i,count); comma=true;
  }
  std::printf("}}\n");
}
'''
main=main.replace('DIAG_COUNT',str(len(labels)))
prefix='''#include <atomic>
namespace diag {
extern std::atomic<unsigned long long> counts[128],recv_sizes[65537],send_sizes[65537];
inline void add(unsigned index,unsigned long long amount) { counts[index].fetch_add(amount,std::memory_order_relaxed); }
}
'''
definitions='namespace diag { std::atomic<unsigned long long> counts[128]{},recv_sizes[65537]{},send_sizes[65537]{}; const char *labels[] = '+json.dumps(labels).replace('[','{').replace(']','}')+'; }\n'
(out/'product.cc').write_text(prefix+product)
(out/'consumer.cc').write_text(prefix+definitions+'#define main legacy_main\n'+consumer+'\n#undef main\n'+wrapper+main)
(out/'labels.json').write_text(json.dumps(labels,indent=2)+'\n')
commands=[]
def run(name,argv):
    p=subprocess.run(list(map(str,argv)),cwd=remote,env=env,capture_output=True,timeout=60)
    (out/(name+'.stdout.txt')).write_bytes(p.stdout)
    (out/(name+'.stderr.txt')).write_bytes(p.stderr)
    commands.append({'name':name,'argv':list(map(str,argv)),'returncode':p.returncode})
    (out/'commands.json').write_text(json.dumps(commands,indent=2)+'\n')
    if p.returncode: print(p.stderr.decode(errors='replace')); raise SystemExit(name)
for name,extra in [('product',['-DHYLE_IO_HTTP2_BUILD']),('consumer',[])]:
    run('compile-'+name,flags+extra+['-c',out/(name+'.cc'),'-o',remote/(name+'.o')])
layout=json.loads((scratch/'http2-owner-loop/common-layout.json').read_text())['commands'][1]['argv']
link=[str(remote/'diagnostic') if s.endswith('/owner-loop/layout-new') else
      '-Wl,-Map,'+str(remote/'diagnostic.map') if s.startswith('-Wl,-Map,') else
      str(remote/'consumer.o') if s.endswith('/root-cause-product/consumer.o') else
      str(remote/'product.o') if s.endswith('/owner-loop/http2.o') else s for s in layout]
link+=['-ldl','-Wl,--export-dynamic-symbol=recv','-Wl,--export-dynamic-symbol=send', '-Wl,--export-dynamic-symbol=__wrap__ZN4hyle5sched5Fiber5yieldEv', '-Wl,--wrap=_ZN4hyle5sched5Fiber5yieldEv']
link+=['-Wl,--wrap='+item[0] for item in native]
run('link',link)
for arm in ('hyle','reference'):
    run(arm,['taskset','-c','2',remote/'diagnostic',arm])
    result=json.loads((out/(arm+'.stdout.txt')).read_text())
    print(json.dumps(result,indent=2),flush=True)
(out/'identity.json').write_text(json.dumps({'sources':[{ 'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in (root/'src/io_http2/http2.cc',root/'bench/io_http2/http2_p1_bench.cc',out/'product.cc',out/'consumer.cc')], 'scope':'Untimed atomic counters; direct native static wraps and process-wide libc send/recv interposition forward to original functions. Source-level incoming copy counts exclude native-internal copies; no timing claim.'},indent=2)+'\n')
