"""Build only the permanent paired consumer; reuse accepted product and dependencies."""
from pathlib import Path
import hashlib
import json
import os
import subprocess

root=Path('/mnt/c/public/project-hyle/hyle')
out=Path(__file__).resolve().parent
remote=Path('/root/hyle-scratch/http2-current-20261018/hot-work/final')
env=dict(os.environ,LD_LIBRARY_PATH='/root/hyle-scratch/http2-current-20261018/current-holdout:/root/hyle-scratch/io-watch-v2-dev/bin',LC_ALL='C')
remote.mkdir(exist_ok=False)
def identity(path):
    path=Path(path)
    return {'path':str(path),'bytes':path.stat().st_size,'sha256':hashlib.sha256(path.read_bytes()).hexdigest()}
def execute(name,argv,changes=None):
    dest=out/(name+'.command.json')
    assert not dest.exists(),name
    record={'argv':list(map(str,argv)),'cwd':str(remote),'environment':{**{k:env[k] for k in ('LD_LIBRARY_PATH','LC_ALL')},**(changes or {})}}
    dest.write_text(json.dumps(record,indent=2)+'\n')
    p=subprocess.run(record['argv'],cwd=remote,env=dict(env,**(changes or {})),capture_output=True,timeout=60)
    (out/(name+'.stdout.txt')).write_bytes(p.stdout)
    (out/(name+'.stderr.txt')).write_bytes(p.stderr)
    record['returncode']=p.returncode
    dest.write_text(json.dumps(record,indent=2)+'\n')
    if p.returncode: print(p.stderr.decode(errors='replace')); raise SystemExit(name)

assert identity(root/'src/io_http2/http2.cc')['sha256']=='30b57207730af05b29e3037d22427b67d35df6f5c4b69a1f99846c9630e6482f'
assert identity(out/'bench.before.cc')['sha256']=='96c1659810ca5d9e11610f937d619d122615f17cd4e3f3519ced9c0f255f6d63'
source=root/'bench/io_http2/http2_p1_bench.cc'
source_before=identity(source)
base=json.loads((out.parent/'http2-paired-run/attempt-2/build.json').read_text())
flags=next(c['argv'] for c in base['commands'] if c['name']=='compile-consumer')
flags=flags[:flags.index('-c')]
execute('final-compile',flags+['-c',source,'-o',remote/'consumer.o'])
old_link=json.loads((out.parent/'http2-owner-loop/common-layout.json').read_text())['commands'][1]['argv']
mapping={'/root/hyle-scratch/http2-current-20261018/owner-loop/layout-new':str(remote/'benchmark'),
         '-Wl,-Map,/root/hyle-scratch/http2-current-20261018/owner-loop/layout-new.map':'-Wl,-Map,'+str(remote/'benchmark.map'),
         '/root/hyle-scratch/http2-current-20261018/root-cause-product/consumer.o':str(remote/'consumer.o')}
execute('final-link',[mapping.get(s,s) for s in old_link])
execute('final-legacy-smoke',[remote/'benchmark'],{'HYLE_BENCH_SMOKE':'1'})
assert identity(source)==source_before
(out/'final-build.json').write_text(json.dumps({'source':source_before,'product_source':identity(root/'src/io_http2/http2.cc'),'product_object':identity('/root/hyle-scratch/http2-current-20261018/owner-loop/http2.o'),'artifacts':[identity(remote/name) for name in ('consumer.o','benchmark','benchmark.map')],'scope':'Only permanent benchmark consumer recompiled; product source/object restored byte-for-byte to accepted owner-loop version. Cached core/native/foundation reused. Legacy two-shape smoke passed; no fullHEAD or new platform claims.'},indent=2)+'\n')
execute('final-paired',['python3',root/'bench/io_http2/run_paired.py',remote/'benchmark','--output',out/'final-paired','--cpu','2'])
print((out/'final-paired.stdout.txt').read_text(),flush=True)
