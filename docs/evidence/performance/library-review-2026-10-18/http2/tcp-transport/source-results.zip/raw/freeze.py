from pathlib import Path
import hashlib
import json
import stat
import zipfile

root=Path('/mnt/c/public/project-hyle/hyle')
out=Path(__file__).resolve().parent
remote=Path('/root/hyle-scratch/http2-current-20261018/hot-work')
dest=root/'docs/evidence/performance/library-review-2026-10-18/http2/tcp-transport'
dest.mkdir(exist_ok=False)
def identity(path):
    path=Path(path)
    assert path.resolve(strict=True)==path and stat.S_ISREG(path.lstat().st_mode)
    return {'path':str(path),'bytes':path.stat().st_size,'sha256':hashlib.sha256(path.read_bytes()).hexdigest()}
assert identity(root/'src/io_http2/http2.cc')['sha256']=='30b57207730af05b29e3037d22427b67d35df6f5c4b69a1f99846c9630e6482f'
assert identity(root/'bench/io_http2/http2_p1_bench.cc')['sha256']=='f96e1379b64623bffe63d07a66bef0da66580546f1c8c4baa144ce0938212171'
# Recover the exact rejected two-signature candidate before dropping its ELF.
rejected=(out/'http2.before.cc').read_text().replace('read_body(mem::AllocatorRef,','read_body(const mem::AllocatorRef &,',1)
rejected=rejected.replace('                                             OperationOptions) noexcept;','                                             const OperationOptions &) noexcept;',1)
rejected=rejected.replace('''    mem::AllocatorRef allocator, Http2BodyReader &reader, std::size_t max_bytes,
    OperationOptions options) noexcept {''','''    const mem::AllocatorRef &allocator, Http2BodyReader &reader,
    std::size_t max_bytes, const OperationOptions &options) noexcept {''',1)
(out/'rejected-abi.cc').write_text(rejected)
assert identity(out/'rejected-abi.cc')['sha256']=='fd3cb8567fa3feae27f8193dae76fb48d3252fe9bfb56f6724abd61e693c4e2f'
abi=json.loads((out/'abi-timing.json').read_text())
transport=json.loads((out/'transport-timing.json').read_text())
final=json.loads((out/'final-paired/summary.json').read_text())
assert abi['status']==transport['status']==final['status']=='completed'
work={arm:json.loads((out/'attempt-2'/ (arm+'.stdout.txt')).read_text()) for arm in ('hyle','reference')}
metrics=('incoming_callbacks','incoming_bytes','incoming_copy_calls','incoming_copy_bytes','delivered_chunks','delivered_bytes','verify_calls','verify_bytes','explicit_yield','native_recv','native_recv_bytes','native_send','consume_stream','consume_stream_bytes','consume_connection','consume_connection_bytes','send_calls','send_success','send_bytes','send_eagain','recv_calls','recv_success','recv_bytes','recv_eagain')
assert all(work['hyle']['counters'][key]==work['reference']['counters'][key] for key in metrics)
assert work['hyle']['recv_sizes']==work['reference']['recv_sizes'] and work['hyle']['send_sizes']==work['reference']['send_sizes']
tcp_counts=json.loads((out/'transport-counts-tcp.stdout.txt').read_text())
assert tcp_counts==json.loads((out/'transport-counts-direct.stdout.txt').read_text())
def compact(run):
    result=run['result']
    keys=('median_ratio_percent','geomean_ratio_percent','range_percent','descriptive_iqr_percent')
    return {'name':run['name'],**{key:result[key] for key in keys},'positive_blocks':sum(block['ratio_percent']>0 for block in result['blocks']),'blocks':len(result['blocks'])}
retained=json.loads((out.parent/'http2-owner-loop/artifact-plan.json').read_text())['retain']
obsolete=('/root/hyle-scratch/http2-current-20261018/owner-loop/layout-new','/root/hyle-scratch/http2-current-20261018/root-cause-product/consumer.o')
keep=[entry for entry in retained if entry['path'] not in obsolete]
keep+=[identity(remote/'final'/name) for name in ('consumer.o','benchmark')]
for entry in keep: assert identity(entry['path'])==entry
keep_paths={entry['path'] for entry in keep}
generated=[]
for path in sorted(remote.rglob('*')):
    if path.is_file() and (path.suffix=='.o' or path.read_bytes()[:4]==b'\x7fELF'):
        generated.append(path)
generated += list(map(Path,obsolete))
plan={'delete':[identity(path) for path in generated if str(path) not in keep_paths],'retain':keep}
(out/'artifact-plan.json').write_text(json.dumps(plan,indent=2)+'\n')
summary={
 'conclusion':'For this fixed single-worker two-Task trace, an important source of the prior1–2% Hyle/reference gap was reference bypassing the TCP transport seam. Controlled same-ELF raw-task intervention adds about2.4% when using that real seam. After permanent alignment, all three process block medians are negative; sustained positive residual not reproduced. This is a benchmark-boundary correction, not a new product performance fix or universal win.',
 'permanent_change':'Only Task reference uses existing tcp_try_read_some/tcp_try_write_some, including validity/current-worker assertions and typed native results. RawWire borrows the coroutine-owned TcpStream, clears before close. No new owner, socket adoption, polling strategy, async fallback or protocol behavior. Default manual peer stays on libc. Product source restored byte-for-byte; no weakened checks or accepted const-reference ABI candidate.',
 'counted_work_20_episodes':{'matched_metrics':{key:work['hyle']['counters'][key] for key in metrics},'recv_success_sizes':work['hyle']['recv_sizes'],'send_success_sizes':work['hyle']['send_sizes'],'ring_wrap':0,'reference_compaction':0,'full_normal_oracles':True,'limit':'Atomic counters are untimed. Source-level incoming copy and body verification counts/bytes plus native/public and libc counts do not enumerate every branch or native-internal copy. libc wrappers omit io_uring directly completed I/O; native receive separately includes it. Native send-zero includes NO_COPY pause, not just empty encoding.'},
 'machine_code':'Reference vector::insert hot path is inline16B SIMD copying; Hyle incoming callback calls libc memcpy. Callback leaf counts therefore include different work. Success Result construction has six stores and no heap/refcount/payload copy. By-value private read_body really uses64B stack outgoing area for32B AllocatorRef+24B OperationOptions; static count does not establish latency.',
 'rejected_private_abi':{'runs':[compact(run) for run in abi['runs']],'decision':'Reject; one-ELF private ref/value path did not establish improvement. Default/forced-epoll17/17 passed for this candidate, but candidate was restored, not shipped. Bodies differ only in signature; extra cell-selected branch in both. Function addresses/branch directions still differ.'},
 'controlled_transport_intervention':{'runs':[compact(run) for run in transport['runs']],'meaning':transport['meaning'],'method':'Same ELF: raw TCP vs raw libc, Hyle vs raw libc, Hyle vs raw TCP. Both native/body/yield/libc success/EAGAIN/size-count outputs exactly equal for20 complete episodes. Different modes run in fixed separate processes; no arithmetic subtraction across process medians or A/A correction. Cell mode is snapshotted in Task-owned wire.socket before I/O.','tcp_seam_cost_scope':'Whole real TCP seam plus reference adaptation, including function ABI, socket/current-worker checks, typed success/EOF/error conversion. Not an isolated TLS-query or individual responsibility cycle measurement.'},
 'permanent_final':{'runs':[compact(run) for run in final['runs']],'full_oracle':'All240timed cells,12blocks/process,64complete episodes/cell,16warmups/arm/process; legacy64x1KiB and4x256KiB manual smoke passed.','tails':'Three paired process medians/GM are negative but14/36 paired blocks remain positive, including+8.618775%. No filtering or equivalence/stable-win claim. AA not CI or bias to subtract.'},
 'scope':'Only targeted diagnostic and benchmark TUs compiled, cached library/native/core reused. Current product unchanged; not a full currentHEAD SDK rebuild, TCP/TLS WAN test, other shape/platform survey or inference tokens/s result. Old manual8–11% gap remains a program comparison with different execution/contracts, not explained away by this fixed two-Task experiment.',
 'independent_recalculation':'Separate read-only agent recomputed all48ABI+96transport+60final=204blocks and native/body/libc counters from raw; all block/logratio/median/GM/range/inclusiveIQR/counter totals matched (floating differences <=1.78e-15).',
 'initial_failed_attempts':'First counter probe did not link (hidden wrapper; guard counter placement also corrected before successful run). ABI diagnostic consumer unused-function and renamed counter-driver missing-return errors corrected in scratch. Failed sources/commands/logs retained; no failed artifact measured.',
 'source_identity':[identity(root/p) for p in ('src/io_http2/http2.cc','bench/io_http2/http2_p1_bench.cc')],
 'final_build':json.loads((out/'final-build.json').read_text()),
 'artifacts':plan,
}
(dest/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
with zipfile.ZipFile(dest/'source-results.zip','x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
    for path in sorted(out.rglob('*')):
        if path.is_file() and '__pycache__' not in path.parts:
            archive.write(path,'raw/'+path.relative_to(out).as_posix())
    for path in sorted(remote.rglob('*.map')):
        archive.write(path,'maps/'+path.relative_to(remote).as_posix())
    for relative in ('src/io_http2/http2.cc','bench/io_http2/http2_p1_bench.cc'):
        archive.write(root/relative,'source/'+relative)
with zipfile.ZipFile(dest/'source-results.zip') as archive: assert archive.testzip() is None
print(json.dumps({'archive':identity(dest/'source-results.zip'),'delete_files':len(plan['delete']),'delete_bytes':sum(entry['bytes'] for entry in plan['delete']),'retained_files':len(keep)},indent=2))
