"""One-binary by-value vs const-reference private-call experiment, plus ordinary candidate."""
from pathlib import Path
import hashlib
import json
import os
import re
import subprocess
import sys

root=Path('/mnt/c/public/project-hyle/hyle')
out=Path(__file__).resolve().parent
remote=Path('/root/hyle-scratch/http2-current-20261018/hot-work/abi')
env=dict(os.environ,LD_LIBRARY_PATH='/root/hyle-scratch/http2-current-20261018/current-holdout:/root/hyle-scratch/io-watch-v2-dev/bin',LC_ALL='C')
def identity(path):
    path=Path(path)
    return {'path':str(path),'bytes':path.stat().st_size,'sha256':hashlib.sha256(path.read_bytes()).hexdigest()}
def execute(name,argv,changes=None):
    dest=out/(name+'.command.json')
    assert not dest.exists(),name
    record={'argv':list(map(str,argv)),'cwd':str(remote),'environment':{**{k:env[k] for k in ('LD_LIBRARY_PATH','LC_ALL')},**(changes or {})}}
    dest.write_text(json.dumps(record,indent=2)+'\n')
    p=subprocess.run(record['argv'],cwd=remote,env=dict(env,**(changes or {})),capture_output=True,timeout=60)
    (out/(name+'.stdout.txt')).write_bytes(p.stdout)
    (out/(name+'.stderr.txt')).write_bytes(p.stderr)
    record['returncode']=p.returncode
    dest.write_text(json.dumps(record,indent=2)+'\n')
    if p.returncode:
        print(p.stdout.decode(errors='replace')[-1000:],p.stderr.decode(errors='replace')[-2000:]); raise SystemExit(name)
    return p.stdout

def build():
    resuming=sys.argv[1]=='finish-build'
    remote.mkdir(exist_ok=resuming)
    old=(out/'http2.before.cc').read_text()
    source=root/'src/io_http2/http2.cc'
    current=source.read_text()
    assert identity(source)['sha256']=='fd3cb8567fa3feae27f8193dae76fb48d3252fe9bfb56f6724abd61e693c4e2f'
    base=json.loads((out.parent/'http2-owner-loop/build.json').read_text())
    flags=base['commands'][0]['argv'][:base['commands'][0]['argv'].index('-c')]
    if not resuming: execute('abi-compile-product',flags+['-c',source,'-o',remote/'http2.o'])
    # Both private implementations coexist in one diagnostic TU and one ELF.
    declaration=re.search(r'  static Result<HttpBodyChunkView> read_body\([\s\S]*?noexcept;',old)[0]
    candidate_declaration=re.search(r'  static Result<HttpBodyChunkView> read_body\([\s\S]*?noexcept;',current)[0]
    def_start=old.index('Result<HttpBodyChunkView> detail::Http2SessionAccess::read_body(')
    def_end=old.index('sched::Task<Result<HttpBodyChunkView>>\nhttp2_body_read(',def_start)
    old_body=old[def_start:def_end].replace('::read_body(', '::read_body_copy(',1)
    probe=current.replace(candidate_declaration,candidate_declaration+'\n'+declaration.replace(' read_body(', ' read_body_copy(',1))
    new_start=probe.index('Result<HttpBodyChunkView> detail::Http2SessionAccess::read_body(')
    probe=probe[:new_start]+old_body+probe[new_start:]
    needle='''    Result<HttpBodyChunkView> chunk =
        Http2SessionAccess::read_body(allocator, reader, max_bytes, options);'''
    assert probe.count(needle)==1
    probe=probe.replace(needle,'''    Result<HttpBodyChunkView> chunk = http2_read_body_use_copy
        ? Http2SessionAccess::read_body_copy(allocator, reader, max_bytes, options)
        : Http2SessionAccess::read_body(allocator, reader, max_bytes, options);''')
    probe='extern "C" { bool http2_read_body_use_copy = false; }\n'+probe
    (out/'abi-probe-product.cc').write_text(probe)
    if not resuming: execute('abi-compile-probe-product',flags+['-c',out/'abi-probe-product.cc','-o',remote/'probe-product.o'])
    driver=(root/'bench/io_http2/http2_p1_bench.cc').read_text()
    start=driver.index('int run_paired_comparison(bool self) {')
    end=driver.index('\nint ',start+5)
    part=driver[start:end]
    part=part.replace('const auto warm_hyle = [&] { return hyle.run(workload); };','const auto warm_hyle = [&] { http2_read_body_use_copy=false; return hyle.run(workload); };')
    old_warm='''      return self ? hyle.run(workload)
                  : run_task_peer(hyle, workload, round == 0);'''
    assert part.count(old_warm)==1
    part=part.replace(old_warm,'      http2_read_body_use_copy=!self;\n      return hyle.run(workload);')
    assert part.count('run_task_peer(hyle, workload)')==1
    part=part.replace('run_task_peer(hyle, workload)','hyle.run(workload)')
    needle='      struct rusage before{}, after{};'
    assert part.count(needle)==1
    part=part.replace(needle,'      http2_read_body_use_copy = !cell.hyle_arm && !self;\n'+needle)
    driver='extern "C" bool http2_read_body_use_copy;\n'+driver[:start]+part+driver[end:]
    driver=driver.replace('int run_task_peer(HyleHarness &harness,', '[[maybe_unused]] int run_task_peer(HyleHarness &harness,')
    if resuming: (out/'abi-probe-consumer.failed.cc').write_bytes((out/'abi-probe-consumer.cc').read_bytes())
    (out/'abi-probe-consumer.cc').write_text(driver)
    consumer_flags=[f for f in flags if f!='-DHYLE_IO_HTTP2_BUILD']
    execute('abi-compile-probe-consumer'+('-retry' if resuming else ''),consumer_flags+['-c',out/'abi-probe-consumer.cc','-o',remote/'probe-consumer.o'])
    old_link=json.loads((out.parent/'http2-owner-loop/common-layout.json').read_text())['commands'][1]['argv']
    for name,product,consumer in [('candidate',remote/'http2.o',Path('/root/hyle-scratch/http2-current-20261018/root-cause-product/consumer.o')),('probe',remote/'probe-product.o',remote/'probe-consumer.o')]:
        mapping={'/root/hyle-scratch/http2-current-20261018/owner-loop/layout-new':str(remote/name),
                 '-Wl,-Map,/root/hyle-scratch/http2-current-20261018/owner-loop/layout-new.map':'-Wl,-Map,'+str(remote/(name+'.map')),
                 '/root/hyle-scratch/http2-current-20261018/root-cause-product/consumer.o':str(consumer),
                 '/root/hyle-scratch/http2-current-20261018/owner-loop/http2.o':str(product)}
        execute('abi-link-'+name,[mapping.get(s,s) for s in old_link])
    for name in ('http2.o','probe-product.o'):
        disassembly=subprocess.check_output(['objdump','-drwC',str(remote/name)],text=True)
        parts=re.split(r'\n(?=[0-9a-f]{16} <)',disassembly)
        selected=[p for p in parts if 'Http2SessionAccess::read_body' in p or 'http2_body_consume' in p.splitlines()[0]]
        (out/(name+'.focused-objdump.txt')).write_text('\n'.join(selected))
    prior=json.loads((out.parent/'http2-owner-loop/test-commands.json').read_text())
    link=next(c['argv'] for c in prior if c['name']=='link-tests-candidate')
    assert identity('/root/hyle-scratch/http2-current-20261018/owner-loop/http2_test.o')['sha256']=='7ffb3dac38465532c8980032a5f3dbee401ac7feec915f51c26eeb2ddd879f5c'
    mapping={'/root/hyle-scratch/http2-current-20261018/owner-loop/http2.o':str(remote/'http2.o'),
             '/root/hyle-scratch/http2-current-20261018/owner-loop/tests-candidate':str(remote/'tests')}
    execute('abi-link-tests',[mapping.get(s,s) for s in link])
    execute('abi-tests-default',[remote/'tests'])
    execute('abi-tests-epoll',[remote/'tests'],{'HYLE_IO_FORCE_EPOLL':'1'})
    assert identity(source)['sha256']=='fd3cb8567fa3feae27f8193dae76fb48d3252fe9bfb56f6724abd61e693c4e2f'
    (out/'abi-build.json').write_text(json.dumps({'source':identity(source),'sources':[identity(out/p) for p in ('abi-probe-product.cc','abi-probe-consumer.cc')], 'artifacts':[identity(remote/p) for p in ('http2.o','probe-product.o','probe-consumer.o','probe','candidate','tests')]},indent=2)+'\n')
    print('Three small TUs built; existing17tests passed default/epoll; ordinary candidate and one-binary ABI probe ready.',flush=True)

def measure():
    sys.path.insert(0,str(root/'bench/io_http2'))
    from run_paired import summarize,machine_metadata
    binary=remote/'probe'
    schedule=[('self-before','paired-self'),('paired-1','paired'),('paired-2','paired'),('self-after','paired-self')]
    record={'meaning':'One ELF, both arms full Hyle. hyle arm=const-reference private read_body; reference arm=old by-value private read_body. Onlyconsume switches; one identical flag branch/chunk in both. Self arms both const-reference. All public checks/borrow/ACK retained. Both function bodies stay in same ELF; product-internal address/cache differences remain possible.', 'machine':machine_metadata(2,os.sched_getaffinity(0)), 'binary':identity(binary),'schedule':schedule,'runs':[]}
    assert not (out/'abi-timing-plan.json').exists()
    (out/'abi-timing-plan.json').write_text(json.dumps(record,indent=2)+'\n')
    for name,mode in schedule:
        stdout=execute('abi-'+name,['taskset','-c','2',binary,'--'+mode])
        result=summarize(stdout.decode(),mode,2)
        record['runs'].append({'name':name,'result':result})
        (out/'abi-timing.json').write_text(json.dumps(record,indent=2)+'\n')
        print(name,result['median_ratio_percent'],flush=True)
    record['status']='completed'
    (out/'abi-timing.json').write_text(json.dumps(record,indent=2)+'\n')

{'build':build,'finish-build':build,'measure':measure}[sys.argv[1]]()
