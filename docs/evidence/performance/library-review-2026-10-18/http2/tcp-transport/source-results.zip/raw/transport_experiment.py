"""Same-binary reference TCP-seam cost and matched-transport comparison."""
from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys

root=Path('/mnt/c/public/project-hyle/hyle')
out=Path(__file__).resolve().parent
remote=Path('/root/hyle-scratch/http2-current-20261018/hot-work/transport')
env=dict(os.environ,LD_LIBRARY_PATH='/root/hyle-scratch/http2-current-20261018/current-holdout:/root/hyle-scratch/io-watch-v2-dev/bin',LC_ALL='C')
def identity(path):
    path=Path(path)
    return {'path':str(path),'bytes':path.stat().st_size,'sha256':hashlib.sha256(path.read_bytes()).hexdigest()}
def execute(name,argv):
    dest=out/(name+'.command.json')
    assert not dest.exists(),name
    record={'argv':list(map(str,argv)),'cwd':str(remote),'environment':{k:env[k] for k in ('LD_LIBRARY_PATH','LC_ALL')}}
    dest.write_text(json.dumps(record,indent=2)+'\n')
    p=subprocess.run(record['argv'],cwd=remote,env=env,capture_output=True,timeout=60)
    (out/(name+'.stdout.txt')).write_bytes(p.stdout)
    (out/(name+'.stderr.txt')).write_bytes(p.stderr)
    record['returncode']=p.returncode
    dest.write_text(json.dumps(record,indent=2)+'\n')
    if p.returncode:
        print(p.stdout.decode(errors='replace')[-2000:],p.stderr.decode(errors='replace')[-2000:]); raise SystemExit(name)
    return p.stdout

def raw_seam(source):
    source='bool diagnostic_tcp_seam = false;\n'+source
    needle='  int descriptor = -1;\n  AllocatorRef allocator;'
    assert source.count(needle)==1
    source=source.replace(needle,'  TcpStream *socket = nullptr;\n'+needle)
    needle='  RawTaskCleanup cleanup{*episode, role, socket};'
    assert source.count(needle)==1
    source=source.replace(needle,needle+'\n  wire.socket = diagnostic_tcp_seam ? &socket : nullptr;')
    needle='    socket = TcpStream{};'
    assert source.count(needle)==1
    source=source.replace(needle,needle+'\n    episode.wire[role].socket = nullptr;')
    needle='''    const ssize_t written = ::send(wire.descriptor,
                                    wire.pending.data() + wire.begin,
                                    wire.end - wire.begin, flags);'''
    assert source.count(needle)==1
    source=source.replace(needle,'''    ssize_t written;
    if (wire.socket != nullptr) {
      const auto result = hyle::io::detail::tcp_try_write_some(*wire.socket,
          std::span<const std::byte>(reinterpret_cast<const std::byte *>(
              wire.pending.data() + wire.begin), wire.end - wire.begin));
      if (result.state == hyle::io::detail::ImmediateTransferState::kWouldBlock)
        return true;
      if (result.state != hyle::io::detail::ImmediateTransferState::kReady ||
          !result.transfer.ok() || result.transfer.bytes > wire.end - wire.begin)
        return false;
      written = static_cast<ssize_t>(result.transfer.bytes);
    } else {
      written = ::send(wire.descriptor, wire.pending.data() + wire.begin,
                       wire.end - wire.begin, flags);
    }''')
    needle='bool raw_read(RawEndpoint &endpoint, RawWire &wire, bool &progress) noexcept {'
    assert source.count(needle)==1
    source=source.replace(needle,needle+'''
  if (wire.socket != nullptr) {
    const auto result = hyle::io::detail::tcp_try_read_some(*wire.socket,
        std::span<std::byte>(reinterpret_cast<std::byte *>(wire.input.data()),
                             wire.input.size()));
    if (result.state == hyle::io::detail::ImmediateTransferState::kWouldBlock)
      return true;
    if (result.state != hyle::io::detail::ImmediateTransferState::kReady ||
        !result.transfer.ok() || result.transfer.eof || result.transfer.bytes == 0 ||
        result.transfer.bytes > wire.input.size()) return false;
    progress = true;
    return nghttp2_session_mem_recv2(endpoint.session, wire.input.data(),
        result.transfer.bytes) == static_cast<nghttp2_ssize>(result.transfer.bytes);
  }
''')
    return source

def build():
    resuming=sys.argv[1]=='finish-build'
    remote.mkdir(exist_ok=resuming)
    assert identity(root/'src/io_http2/http2.cc')['sha256']=='30b57207730af05b29e3037d22427b67d35df6f5c4b69a1f99846c9630e6482f'
    source=(root/'bench/io_http2/http2_p1_bench.cc').read_text()
    driver=raw_seam(source)
    start=driver.index('int run_paired_comparison(bool self) {')
    end=driver.index('\nint ',start+5)
    part=driver[start:end]
    part=part.replace('const auto warm_hyle = [&] { return hyle.run(workload); };',
        'const auto warm_hyle = [&] { diagnostic_tcp_seam=true; return diagnostic_transport_cost ? run_task_peer(hyle,workload) : hyle.run(workload); };')
    needle='''      return self ? hyle.run(workload)
                  : run_task_peer(hyle, workload, round == 0);'''
    assert part.count(needle)==1
    part=part.replace(needle,'''      diagnostic_tcp_seam=diagnostic_matched || (diagnostic_transport_cost && self);
      return self && !diagnostic_transport_cost ? hyle.run(workload)
                  : run_task_peer(hyle, workload, round == 0);''')
    needle='      cell.valid = true;'
    assert part.count(needle)==1
    part=part.replace(needle,needle+'\n      diagnostic_tcp_seam=diagnostic_transport_cost ? (cell.hyle_arm || self) : diagnostic_matched;')
    needle='if (cell.valid && hyle.run(workload) != workload.streams)'
    assert part.count(needle)==1
    part=part.replace(needle,'if (cell.valid && (diagnostic_transport_cost ? run_task_peer(hyle,workload) : hyle.run(workload)) != workload.streams)')
    driver='bool diagnostic_transport_cost=false,diagnostic_matched=false;\n#define main legacy_main\n'+driver[:start]+part+driver[end:]+'\n#undef main\n'
    driver+='''int main(int argc,char **argv) {
  if(argc!=2) return 2;
  std::signal(SIGPIPE,SIG_IGN);
  const std::string_view mode(argv[1]);
  diagnostic_transport_cost = mode == "cost" || mode == "cost-self";
  diagnostic_matched = mode == "matched";
  if(!diagnostic_transport_cost && !diagnostic_matched && mode!="legacy" && mode!="self") return 2;
  return run_paired_comparison(mode=="self" || mode=="cost-self");
}
'''
    (out/'transport-consumer.cc').write_text(driver)
    counts=raw_seam((out/'attempt-2/consumer.cc').read_text())
    start=counts.rindex('int main(int argc,char **argv) {')
    counts=counts[:start]+counts[start:].replace('int main(', 'int work_diag_main(',1)
    assert counts.endswith('}\n')
    counts=counts[:-2]+'  return 0;\n}\n'
    counts+='''
int main(int argc,char **argv) {
  if(argc!=2) return 2;
  const std::string_view mode(argv[1]);
  diagnostic_tcp_seam=mode=="tcp";
  if(mode!="tcp" && mode!="direct") return 2;
  char name[]="transport-counts",reference[]="reference";
  char *arguments[]={name,reference};
  return work_diag_main(2,arguments);
}
'''
    if resuming: (out/'transport-counts-consumer.failed.cc').write_bytes((out/'transport-counts-consumer.cc').read_bytes())
    (out/'transport-counts-consumer.cc').write_text(counts)
    base=json.loads((out.parent/'http2-paired-run/attempt-2/build.json').read_text())
    flags=next(c['argv'] for c in base['commands'] if c['name']=='compile-consumer')
    flags=flags[:flags.index('-c')]
    for name in ('transport','transport-counts'):
        if resuming and name=='transport': continue
        execute(name+'-compile'+('-retry' if resuming else ''),flags+['-c',out/(name+'-consumer.cc'),'-o',remote/(name+'.o')])
    original=json.loads((out.parent/'http2-owner-loop/common-layout.json').read_text())['commands'][1]['argv']
    for name in ('transport','transport-counts'):
        product='/root/hyle-scratch/http2-current-20261018/owner-loop/http2.o' if name=='transport' else '/root/hyle-scratch/http2-current-20261018/hot-work/attempt-2/product.o'
        mapping={'/root/hyle-scratch/http2-current-20261018/owner-loop/layout-new':str(remote/name),
                 '-Wl,-Map,/root/hyle-scratch/http2-current-20261018/owner-loop/layout-new.map':'-Wl,-Map,'+str(remote/(name+'.map')),
                 '/root/hyle-scratch/http2-current-20261018/root-cause-product/consumer.o':str(remote/(name+'.o')),
                 '/root/hyle-scratch/http2-current-20261018/owner-loop/http2.o':product}
        link=[mapping.get(s,s) for s in original]
        if name=='transport-counts':
            link+=['-ldl','-Wl,--export-dynamic-symbol=recv','-Wl,--export-dynamic-symbol=send','-Wl,--export-dynamic-symbol=__wrap__ZN4hyle5sched5Fiber5yieldEv','-Wl,--wrap=_ZN4hyle5sched5Fiber5yieldEv']
            link+=['-Wl,--wrap='+s for s in ('nghttp2_session_mem_recv2','nghttp2_session_mem_send2','nghttp2_session_consume_stream','nghttp2_session_consume_connection')]
        execute(name+'-link',link)
    for mode in ('direct','tcp'):
        execute('transport-counts-'+mode,['taskset','-c','2',remote/'transport-counts',mode])
    before=json.loads((out/'transport-counts-direct.stdout.txt').read_text())
    after=json.loads((out/'transport-counts-tcp.stdout.txt').read_text())
    assert before==after, 'A count changed: inspect before any timing.'
    (out/'transport-build.json').write_text(json.dumps({'scope':'No product edit. Reference Task borrows its live TcpStream only until its own cleanup, calls existing TCP immediate seam with all checks/errors retained. Manual driver still direct. Same-binary modes isolate seam cost, preserve both same fixed protocol trace and all normal oracle checks. Untimed source/native/libc counter outputs match exactly for20 episodes.', 'sources':[identity(out/p) for p in ('transport-consumer.cc','transport-counts-consumer.cc')], 'artifacts':[identity(remote/p) for p in ('transport.o','transport-counts.o','transport','transport-counts')]},indent=2)+'\n')
    print('Both reference modes passed full oracle; all native/body/yield/libc counts and size histograms match exactly.',flush=True)

def measure():
    sys.path.insert(0,str(root/'bench/io_http2'))
    from run_paired import summarize,machine_metadata
    schedule=[('cost-self-before','cost-self'),('cost-1','cost'),('legacy-1','legacy'),('matched-1','matched'),('matched-2','matched'),('legacy-2','legacy'),('cost-2','cost'),('cost-self-after','cost-self')]
    record={'meaning':'Same ELF all modes. cost: label hyle=rawTask viaTCP seam, reference=rawTask directlibc; positive=TCP seam costs more. matched: Hyle public vs rawTask viaTCP seam. legacy: Hyle public vs rawTask directlibc in same ELF. self controls both rawTCPseam. No A/A subtraction or exact sum across processes.', 'machine':machine_metadata(2,os.sched_getaffinity(0)), 'binary':identity(remote/'transport'),'schedule':schedule,'runs':[]}
    assert not (out/'transport-timing-plan.json').exists()
    (out/'transport-timing-plan.json').write_text(json.dumps(record,indent=2)+'\n')
    for name,mode in schedule:
        stdout=execute(name,['taskset','-c','2',remote/'transport',mode])
        result=summarize(stdout.decode(),'paired-self' if mode.endswith('self') else 'paired',2)
        record['runs'].append({'name':name,'mode':mode,'result':result})
        (out/'transport-timing.json').write_text(json.dumps(record,indent=2)+'\n')
        print(name,result['median_ratio_percent'],flush=True)
    record['status']='completed'
    (out/'transport-timing.json').write_text(json.dumps(record,indent=2)+'\n')

{'build':build,'finish-build':build,'measure':measure}[sys.argv[1]]()
