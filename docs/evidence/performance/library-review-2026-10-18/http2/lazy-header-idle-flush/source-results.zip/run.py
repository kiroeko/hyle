from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys

ROOT = Path('/mnt/c/public/project-hyle/hyle')
HERE = ROOT / '.scratch/perf-review-2026-10-18/http2/lazy-header-idle-flush'
PRIOR = HERE.parent / 'discard-frame'
PEER = HERE.parent / 'owned-wire-no-copy'
BASE = Path('/root/hyle-scratch/http2-current-20261018')
OUT = BASE / 'lazy-header-idle-flush'
BASELINE = BASE / 'discard-frame/http2.o'
ENV = {k: v for k, v in os.environ.items()
       if not k.startswith(('HYLE_BENCH_', 'HYLE_PERF_', 'HYLE_IO_FORCE_'))}
ENV['LD_LIBRARY_PATH'] = str(BASE / 'current-holdout') + ':/root/hyle-scratch/io-watch-v2-dev/bin'
LOG = HERE / 'commands.json'
records = json.loads(LOG.read_text()) if LOG.exists() else []


def rec(path):
    return dict(path=str(path), bytes=path.stat().st_size,
                sha256=hashlib.sha256(path.read_bytes()).hexdigest())


def write(name, value):
    (HERE / name).write_text(json.dumps(value, indent=2) + '\n')


def run(name, argv, env=ENV):
    assert not any(r['name'] == name for r in records), 'No repeated command: ' + name
    argv = list(map(str, argv))
    result = subprocess.run(argv, cwd=OUT, env=env, text=True,
                            capture_output=True, timeout=60)
    (HERE / (name + '.stdout.txt')).write_text(result.stdout)
    (HERE / (name + '.stderr.txt')).write_text(result.stderr)
    records.append(dict(name=name, argv=argv, cwd=str(OUT), exit=result.returncode,
                        environment={k: v for k, v in env.items()
                                     if k.startswith(('LD_LIBRARY_PATH', 'HYLE_'))}))
    write('commands.json', records)
    print(name, result.returncode, result.stdout[-1700:], result.stderr[-1000:], flush=True)
    if result.returncode:
        raise RuntimeError('Stopped on failed command: ' + name)
    return result.stdout


def functional():
    assert not records, 'Do not repeat functional validation'
    assert (HERE / 'http2.before.cc').read_bytes() == (PRIOR / 'http2.candidate.cc').read_bytes()
    candidate = HERE / 'http2.candidate.cc'
    candidate.write_bytes((ROOT / 'src/io_http2/http2.cc').read_bytes())
    prior = json.loads((PRIOR / 'preflight-identities.json').read_text())
    expected_baseline = next(x for x in json.loads((PRIOR / 'functional-results.json').read_text())['artifacts']
                             if x['path'] == str(BASELINE))
    assert rec(BASELINE) == expected_baseline
    for expected in prior['retained_inputs']:
        assert rec(Path(expected['path'])) == expected, expected['path']
    for key in ('current_core_source', 'coro_header', 'test_source'):
        expected = prior[key]
        assert rec(Path(expected['path'])) == expected, expected['path']
    OUT.mkdir(exist_ok=False)
    write('preflight-identities.json', dict(baseline_object=expected_baseline,
        before=rec(HERE / 'http2.before.cc'), candidate=rec(candidate),
        retained_inputs=prior['retained_inputs'],
        current_core_source=prior['current_core_source'], test_source=prior['test_source']))
    run('compiler', ['g++-14', '--version'])
    run('machine', ['python3', '-c',
        'import json,os,platform,time;print(json.dumps(dict(uname=list(platform.uname()),affinity=sorted(os.sched_getaffinity(0)),nice=os.getpriority(os.PRIO_PROCESS,0),clock=time.get_clock_info("perf_counter").__dict__,cpu_model=next(x.strip() for x in open("/proc/cpuinfo") if x.startswith("model name"))),indent=2))'])
    commands = json.loads((PRIOR / 'commands.json').read_text())
    compile_cmd = next(x['argv'] for x in commands if x['name'] == 'compile-http2')
    run('compile-http2', compile_cmd[:-4] + ['-c', candidate, '-o', OUT / 'http2.o'])
    original = next(x['argv'] for x in commands if x['name'] == 'link-tests')
    link = [str(OUT / 'tests') if x == str(BASE / 'discard-frame/tests') else
            str(OUT / 'http2.o') if x == str(BASELINE) else x for x in original]
    run('link-tests', link)
    loader = run('loader-tests', ['ldd', OUT / 'tests'])
    assert str(BASE / 'current-holdout/libhyle_io_core.so.0.1.0') in loader
    results = []
    for label in ('default', 'epoll'):
        env = ENV.copy()
        if label == 'epoll':
            env['HYLE_IO_FORCE_EPOLL'] = '1'
        run(label + '-tests', ['timeout', '--kill-after=2s', '20s', OUT / 'tests',
            '--gtest_output=json:' + str(HERE / (label + '-tests.json'))], env)
        result = json.loads((HERE / (label + '-tests.json')).read_text())
        assert result['tests'] == 15 and result['failures'] == result['errors'] == 0
        results.append(dict(backend=label, tests=result['tests'], failures=result['failures'],
                            errors=result['errors'], time=result['time']))
    write('functional-results.json', dict(results=results,
        artifacts=[rec(OUT / name) for name in ('http2.o', 'tests')],
        fresh_product_TUs=1, test_TUs_or_sdk_rebuilt=0,
        lazy_slot_malloc_oom_specifically_injected=False))


def prepare_holdout():
    assert (HERE / 'functional-results.json').exists()
    assert (HERE / 'http2.candidate.cc').read_bytes() == (ROOT / 'src/io_http2/http2.cc').read_bytes()
    peer = ROOT / 'bench/io_http2/http2_p1_bench.cc'
    assert peer.read_bytes() == (PEER / 'http2_p1_bench.cc').read_bytes()
    (HERE / 'holdout.cc').write_bytes((PEER / 'holdout.cc').read_bytes())
    (HERE / 'http2_p1_bench.cc').write_bytes(peer.read_bytes())
    previous = json.loads((PEER / 'holdout-identity.json').read_text())
    expected_nano = next(x for x in previous['linked_inputs'] if x['path'].endswith('/bench_nanobench_impl.cc.o'))
    assert rec(Path(expected_nano['path'])) == expected_nano
    commands = json.loads((PEER / 'holdout-commands.json').read_text())
    compile_cmd = next(x['argv'] for x in commands if x['name'] == 'compile-holdout')
    run('compile-holdout', compile_cmd[:-4] + ['-c', HERE / 'holdout.cc', '-o', OUT / 'holdout.o'])
    original = next(x['argv'] for x in commands if x['name'] == 'link-holdout-new')
    inputs = []
    for variant, obj in (('old', BASELINE), ('new', OUT / 'http2.o')):
        command = [str(OUT / ('holdout-' + variant)) if x == str(BASE / 'owned-wire-no-copy/holdout-new') else
                   str(obj) if x == str(BASE / 'owned-wire-no-copy/http2.o') else
                   str(OUT / 'holdout.o') if x == str(BASE / 'owned-wire-no-copy/holdout.o') else x
                   for x in original]
        run('link-holdout-' + variant, command)
        loader = run('loader-holdout-' + variant, ['ldd', OUT / ('holdout-' + variant)])
        assert str(BASE / 'current-holdout/libhyle_io_core.so.0.1.0') in loader
        smoke = ENV.copy()
        smoke['HYLE_BENCH_SMOKE'] = '1'
        run('smoke-holdout-' + variant, ['taskset', '-c', '2', 'timeout', '--kill-after=2s',
            '20s', OUT / ('holdout-' + variant)], smoke)
        inputs.extend(Path(x) for x in command if x.endswith(('.o', '.a')))
    write('holdout-identity.json', dict(sources=[rec(HERE / name) for name in
        ('holdout.cc', 'http2_p1_bench.cc', 'http2.before.cc', 'http2.candidate.cc')],
        linked_inputs=[rec(p) for p in sorted(set(inputs))],
        executables=[rec(OUT / ('holdout-' + v)) for v in ('old', 'new')],
        core=rec(BASE / 'current-holdout/libhyle_io_core.so.0.1.0'),
        closure='Two fresh TUs total: product plus unchanged canonical holdout wrapper. Reused exact native/foundation/test objects; no whole-HEAD build.'))


def formal():
    identity = json.loads((HERE / 'holdout-identity.json').read_text())
    for expected in identity['linked_inputs'] + identity['executables'] + [identity['core']]:
        assert rec(Path(expected['path'])) == expected
    assert (HERE / 'http2.candidate.cc').read_bytes() == (ROOT / 'src/io_http2/http2.cc').read_bytes()
    for index, variant in enumerate(('old', 'new', 'new', 'old')):
        env = ENV.copy()
        env['HYLE_BENCH_JSON'] = str(HERE / ('epochs-' + str(index) + '-' + variant))
        if index >= 2:
            env['HYLE_BENCH_RIVAL_FIRST'] = '1'
        run('formal-' + str(index) + '-' + variant,
            ['taskset', '-c', '2', 'timeout', '--kill-after=2s', '30s', OUT / ('holdout-' + variant)], env)
    print('Fixed four formal processes complete; stop execution.', flush=True)


{'functional': functional, 'prepare': prepare_holdout, 'formal': formal}[sys.argv[1]]()
