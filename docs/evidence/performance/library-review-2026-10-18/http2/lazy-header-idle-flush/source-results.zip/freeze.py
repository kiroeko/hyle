from pathlib import Path
import hashlib
import json
import statistics
import subprocess
import zipfile

HERE = Path(__file__).resolve().parent
REPO = HERE.parents[3]


def rec(path):
    return dict(path=str(path), bytes=path.stat().st_size,
                sha256=hashlib.sha256(path.read_bytes()).hexdigest())


def write(name, value):
    (HERE / name).write_text(json.dumps(value, indent=2) + '\n')


def main():
    assert not (HERE / 'source-results.zip').exists(), 'Do not overwrite frozen evidence'
    assert (HERE / 'http2.candidate.cc').read_bytes() == (REPO / 'src/io_http2/http2.cc').read_bytes()
    assert (HERE / 'http2_p1_bench.cc').read_bytes() == (REPO / 'bench/io_http2/http2_p1_bench.cc').read_bytes()
    commands = json.loads((HERE / 'commands.json').read_text())
    assert len([x for x in commands if x['name'].startswith('formal-')]) == 4
    assert all(x['exit'] == 0 for x in commands)
    diff = subprocess.run(['git', 'diff', '--', 'src/io_http2/http2.cc'], cwd=REPO,
                          capture_output=True, check=True)
    (HERE / 'product.diff').write_bytes(diff.stdout)
    for source, target in [('include/hyle/io/http2.h', 'http2.h'),
                           ('include/hyle/io/http.h', 'http.h'),
                           ('tests/io_http2/http2_test.cc', 'http2_test.cc')]:
        (HERE / target).write_bytes((REPO / source).read_bytes())
    processes = []
    count = 0
    for i, variant in enumerate(('old', 'new', 'new', 'old')):
        raw = json.loads((HERE / f'epochs-{i}-{variant}-4.json').read_text())
        process = dict(index=i, variant=variant,
                       inner_order='Hyle then peer' if i < 2 else 'peer then Hyle', arms=[])
        for arm in raw['results']:
            samples = arm['measurements']
            assert arm['batch'] == 4 and arm['epochs'] == len(samples) == 9
            assert all(s['iterations'] >= 5 for s in samples)
            ns = [s['elapsed'] * 1e9 / arm['batch'] for s in samples]
            median_ns = statistics.median(ns)
            assert abs(median_ns - arm['median(elapsed)'] * 1e9 / 4) < 1e-7
            process['arms'].append(dict(name=arm['name'], median_ns_per_stream=median_ns,
                min_ns_per_stream=min(ns), max_ns_per_stream=max(ns),
                mean_ns_per_stream=statistics.mean(ns), clock_resolution_ns=arm['clockResolution'] * 1e9,
                median_absolute_percent_error=arm['medianAbsolutePercentError(elapsed)'],
                samples=[dict(**s, ns_per_stream=n,
                              epoch_total_ns=s['elapsed'] * s['iterations'] * 1e9)
                         for s, n in zip(samples, ns)]))
            count += len(samples)
        hyle = next(a for a in process['arms'] if a['name'].startswith('HYLE'))
        peer = next(a for a in process['arms'] if a['name'].startswith('nghttp2'))
        process['hyle_over_peer_ratio'] = hyle['median_ns_per_stream'] / peer['median_ns_per_stream']
        processes.append(process)
    assert count == 72
    pairs = []
    for old_i, new_i in ((0, 1), (3, 2)):
        old, new = processes[old_i], processes[new_i]
        old_hyle = next(a for a in old['arms'] if a['name'].startswith('HYLE'))
        new_hyle = next(a for a in new['arms'] if a['name'].startswith('HYLE'))
        pairs.append(dict(old_process=old_i, new_process=new_i,
            hyle_median_change_percent=(new_hyle['median_ns_per_stream'] / old_hyle['median_ns_per_stream'] - 1) * 100,
            normalized_ratio_change_percent=(new['hyle_over_peer_ratio'] / old['hyle_over_peer_ratio'] - 1) * 100))
    functional = json.loads((HERE / 'functional-results.json').read_text())
    identity = json.loads((HERE / 'holdout-identity.json').read_text())
    preflight = json.loads((HERE / 'preflight-identities.json').read_text())
    artifacts = functional['artifacts'] + [x for x in identity['linked_inputs']
        if x['path'].endswith('/lazy-header-idle-flush/holdout.o')] + identity['executables']
    delete = [x for x in artifacts if not x['path'].endswith('/http2.o')]
    retain = [x for x in artifacts if x['path'].endswith('/http2.o')] + [preflight['baseline_object']]
    assert len({x['path'] for x in delete + retain}) == len(delete + retain) == 6
    cleanup = dict(host='WSL Ubuntu-24.04 root',
        roots=['/root/hyle-scratch/http2-current-20261018/lazy-header-idle-flush',
               '/root/hyle-scratch/http2-current-20261018/discard-frame'],
        files=delete, delete_count=len(delete), delete_logical_bytes=sum(x['bytes'] for x in delete),
        retain=retain, retain_count=len(retain), retain_logical_bytes=sum(x['bytes'] for x in retain),
        duplicate_or_overlap_count=0,
        disposition='Plan only. Keep current product object for next reuse and preserve immutable discard baseline. No deletion/commit. All source/log/raw/ZIP/native/foundation/test cache inputs remain.')
    write('cleanup-candidates.json', cleanup)
    source = (HERE / 'http2.candidate.cc').read_text()
    def line(text):
        offset = source.index(text)
        return source[:offset].count('\n') + 1
    review = dict(source=rec(HERE / 'http2.candidate.cc'),
        locations=dict(initialize=line('bool initialize(const Http2Limits &limits)'),
            on_header_lazy_allocation=line('if (slots == nullptr)'),
            idle_flush=line('if (encoded == 0 && state.wire.size == 0)'),
            header_views_null_guard=line('if (storage == nullptr)'),
            on_stream_close=line('int on_stream_close(')),
        lazy_storage=[
            'initialize retains count0/overflow validation and records the original fixed slot byte capacity without allocation. First actual regular header selects headers/trailers by reference after count limit rejection and allocates that exact capacity with original allocator/alignment.',
            'Allocation is before field appends. Failure preserves stream-local ResourceExhausted/internal reset plus native temporal-callback-failure return. No new field, growth, capacity, moving or free-on-chunk operation.',
            'Pseudo headers bypass slots. Empty head/trailer materialization loops count0 and header_views explicitly accepts nullptr. Informational/header continuation blocks reuse already allocated arrays; destructor frees each nonnull array at original byte count/alignment.',
            'This trace sends regular content-length on requests and responses, so regular-header slots remain necessary on both endpoints. Four streams on each endpoint have no trailers: source mechanism removes eight unused trailer slot allocation/free pairs per full episode. This is source-derived, not a runtime allocator census; no claim that both arrays disappear.'
        ],
        idle_flush=[
            'Only encoded0 && empty owned wire skips release notification. Native encoding and its temporary writebusy claim cannot suspend or be observed by another same-owner fiber.',
            'on_stream_close explicitly notifies; fatal fail publishes. DATA with owned wire, positive native bytes, transport/progress/error/partial/cancel completion keep original notifications and wire epochs.',
            'The raw peer also takes one mem_send2 frame per raw_fill_output call. No peer-only native frame batching difference is present; none is claimed or changed.'
        ],
        limits='No dedicated lazy-slot malloc OOM injection, notification count probe, runtime allocation census or isolated one-change timing was run. The combined two-change holdout does not identify either change as an individual time cause.')
    write('source-review.json', review)
    summary = dict(status='Implemented two private HTTP2 changes; all targeted functional checks pass; holdout has no speedup. Not committed or cleaned.',
        head_at_packaging=subprocess.run(['git', 'rev-parse', 'HEAD'], cwd=REPO, capture_output=True, check=True, text=True).stdout.strip(),
        source_before=rec(HERE / 'http2.before.cc'), source_after=rec(HERE / 'http2.candidate.cc'),
        changes=['Lazy original fixed header/trailer slot allocation on first regular header, no capacity or field changes.',
                 'Empty native flush releases unobservable temporary writebusy without extra owner notification; all other releases/callback publications retained.'],
        source_review='source-review.json', functional=functional,
        full_smoke=dict(old='hyle=4 peer=4, exit0', new='hyle=4 peer=4, exit0'),
        method=dict(trace='Original canonical 4x256KiB request+response trace, original flow control/reverse pair/header/body/credit/borrow/complete cleanup responsibilities.',
            order=['old', 'new', 'new', 'old'], inner_order=['Hyle first', 'Hyle first', 'peer first', 'peer first'],
            epochs_per_arm=9, arms_per_process=2, all_epochs_retained=count,
            fixture='Original run_workload has one full checked episode per arm before Bench; original nanobench minEpochIterations5, epochs9, default minEpochTime1ms, warmup0, batch4 unchanged.',
            timer='Raw measurement.elapsed is already per iteration. Divide it only by batch4 for ns/stream; epoch_total_ns additionally multiplies by recorded iterations. Hardware perf counters unavailable; warning/zero fields retained and not interpreted as measured counters.',
            resources='taskset CPU2 each formal/smoke process; caller plus existing Scheduler/RawHarness lifecycle unchanged. Actual machine/affinity/nice/clock and GCC14.2 are recorded in machine/compiler stdout. No new live TID census.',
            no_AA_retry_extra_shape_or_warm_peer_change=True,
            build='Two fresh TUs total: product and unchanged holdout wrapper. Cached current core/native/foundation/GTest/test objects verified by exact SHA. No CMake/SDK/full-HEAD rebuild/copy.'),
        processes=processes, same_inner_order_pairs=pairs,
        conclusion='No speedup in this fixed trial. Candidate Hyle medians and normalized Hyle/peer ratios are higher in both same-inner-order pairs; public API remains slower than direct manual peer. Retain the negative result. Source mechanism removes unused allocations/idle notifications but does not establish a timing benefit or resolve the residual.',
        interpretation_limits='Combined changes are not a causal per-change timing experiment. Single fixed trace and finite epochs cannot prove a general regression. No followup AA, isolated variants, instruction counters, total-memory or notification runtime counters were added.',
        failures=[], baseline_object_preserved=preflight['baseline_object'], cleanup=cleanup,
        product_scope='Only src/io_http2/http2.cc edited by this task. README, test.ps1, Apple files and peer unchanged.')
    write('summary.json', summary)
    files = sorted((p for p in HERE.iterdir() if p.is_file() and p.name not in
                    {'source-results.zip', 'archive-identity.json', 'package-manifest.json'}), key=lambda p: p.name)
    write('package-manifest.json', dict(files=[dict(path=p.name, bytes=p.stat().st_size,
        sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in files],
        no_executable_object_or_SDK_payload=True))
    files.append(HERE / 'package-manifest.json')
    archive = HERE / 'source-results.zip'
    with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED) as out:
        for p in files:
            out.write(p, p.name)
    write('archive-identity.json', dict(**rec(archive), members=len(files)))
    print(json.dumps(dict(archive=rec(archive), summary=rec(HERE / 'summary.json'),
        source_after=rec(HERE / 'http2.candidate.cc'), pairs=pairs,
        cleanup=dict(delete_count=len(delete), delete_logical_bytes=cleanup['delete_logical_bytes'],
                     retain_count=len(retain), retain_logical_bytes=cleanup['retain_logical_bytes'])), indent=2))


if __name__ == '__main__':
    main()
