# One-time exact cleanup after HTTP2 owner-loop investigation; retain current useful caches.
# Preserve source, logs, raw samples, maps, archives and shared caches.
$ErrorActionPreference = 'Stop'
$archive = Join-Path $PSScriptRoot 'docs/evidence/performance/library-review-2026-10-18/http2/owner-loop/source-results.zip'
if ((Get-FileHash -LiteralPath $archive -Algorithm SHA256).Hash.ToLowerInvariant() -ne '690e4ee5e52f3d72e1c23fddfe8903c2204780b0df67583c46d23465685dd47f') { throw 'Frozen evidence archive mismatch' }
$pythonSource = @'
import hashlib, json, os, stat
from pathlib import Path

root = Path('/root/hyle-scratch/http2-current-20261018')
targets = [
    (Path('/root/hyle-scratch/http2-current-20261018/owner-loop/after-diag'), 896680, 'e15de43a2ab34b04a8da788dc0a142c2a43b7729ea78a8b1f792c33c4120192b'),
    (Path('/root/hyle-scratch/http2-current-20261018/owner-loop/after-diag.o'), 224360, '80b4344bb2e49fc3cd9fbd4f2162134db76c85e8cea360ce7499ae7a16e158ce'),
    (Path('/root/hyle-scratch/http2-current-20261018/owner-loop/before-diag'), 896680, 'e135251b5874d3b669b4798d4ae1674980e4e53efb220e50f040f48b0cd873d0'),
    (Path('/root/hyle-scratch/http2-current-20261018/owner-loop/before-diag.o'), 223544, '78a5ebb142f450bd5da4cd1c3637ce389a8de59376f3e3b181c907ccad39e1d4'),
    (Path('/root/hyle-scratch/http2-current-20261018/owner-loop/candidate'), 897640, '0dc95da28c6709642761fec762c2a8f7f1f679ac8d6d0d03dc3305117cce2424'),
    (Path('/root/hyle-scratch/http2-current-20261018/owner-loop/consumer.o'), 152888, '8b58ce4956815f345773205f29af9924477acf1d320ad4b61bc7c6e855cec8d2'),
    (Path('/root/hyle-scratch/http2-current-20261018/owner-loop/layout-old'), 898496, 'dac2e76ffe5306b89043015564bbf3994c71023af712af9ba120b4aef1277236'),
    (Path('/root/hyle-scratch/http2-current-20261018/owner-loop/mutant.o'), 225704, '89846f871cb836d89b125f08d5a68c426045d06657a691485942be509b64dd13'),
    (Path('/root/hyle-scratch/http2-current-20261018/owner-loop/tests-mutant'), 1618568, '9ee1d52d2a839a82ebb3d10c334db18e3d00b8629f72109fc4ecedcbb359b4c3'),
    (Path('/root/hyle-scratch/http2-current-20261018/root-cause-notify/http2.o'), 224576, '91086705edabe231dc952bf2c6cb40fc9d1a13e2ca5eb5128f8ffaed405b5e62'),
    (Path('/root/hyle-scratch/http2-current-20261018/root-cause-notify/candidate'), 897640, '99feb9f6429b7a5e5631091b0800ad2ccac8bdb19e8a3e6126c36e0e61c99c2b'),
    (Path('/root/hyle-scratch/http2-current-20261018/root-cause-notify/tests'), 1588880, '3f50e4b0ec733f62ef8c4b5f50b88f0b0b69180e2d4d2957a79aec5ab4e7d464'),
    (Path('/root/hyle-scratch/http2-current-20261018/root-cause-product/http2_test.o'), 697832, 'e0aac0c23d5c6666a7d23c9b57521f4844bada7b6717dec4a57d29d821badab1'),
]
retained = [
    (Path('/root/hyle-scratch/http2-current-20261018/current-holdout/libhyle_io_core.so.0.1.0'), 387104, '9ead235b1bbd72f56d44eab9c8ac135b8c4b0ce0ec0a6fb72660aa917d3b4779'),
    (Path('/root/hyle-scratch/http2-current-20261018/owner-loop/http2.o'), 225824, '7c214427285e21da16dab647d0b5793b8b209554bf5f8d3ef20d4435653aa82e'),
    (Path('/root/hyle-scratch/http2-current-20261018/owner-loop/http2_test.o'), 739800, '7ffb3dac38465532c8980032a5f3dbee401ac7feec915f51c26eeb2ddd879f5c'),
    (Path('/root/hyle-scratch/http2-current-20261018/owner-loop/layout-new'), 898496, '3123e43a9c4e015241242673b9dc90d7c6d4ca26f72408ef53b5690cd29e4870'),
    (Path('/root/hyle-scratch/http2-current-20261018/owner-loop/tests-candidate'), 1618552, '97a8e618a6db7c621e770e37f349313f0ffeda99b7b66334016a96c3db52991a'),
    (Path('/root/hyle-scratch/http2-current-20261018/paired-comparison-v2/nanobench.o'), 283672, '43b16d764541dc1460c6aba273360f40403bcc35ee2feb37461f7f4d29984987'),
    (Path('/root/hyle-scratch/http2-current-20261018/root-cause-product/consumer.o'), 151104, '62a132158e443d6fae3df9c9ea8b4ccba19e71a21aeac9ffef6042d03df5b2b2'),
]
assert root.resolve(strict=True) == root
assert len({x[0] for x in targets + retained}) == 20
assert sum(x[1] for x in targets) == 9443488

def inspect(item):
    path, size, expected_sha = item
    assert path.is_absolute() and path.is_relative_to(Path('/root/hyle-scratch/http2-current-20261018'))
    current = Path(path.anchor)
    for part in path.parts[1:]:
        current /= part
        assert not stat.S_ISLNK(current.lstat().st_mode), str(current)
    assert path.resolve(strict=True) == path
    before = path.lstat()
    assert stat.S_ISREG(before.st_mode) and before.st_size == size
    with os.fdopen(os.open(path, os.O_RDONLY | os.O_NOFOLLOW), 'rb') as stream:
        opened = os.fstat(stream.fileno())
        assert (opened.st_dev, opened.st_ino) == (before.st_dev, before.st_ino)
        digest = hashlib.sha256(stream.read()).hexdigest()
        after = os.fstat(stream.fileno())
    current = path.lstat()
    assert digest == expected_sha and after.st_size == size
    assert (current.st_dev, current.st_ino, current.st_size) == (after.st_dev, after.st_ino, after.st_size)
    return current.st_dev, current.st_ino

identities = {x[0]: inspect(x) for x in targets + retained}
for proc in Path('/proc').iterdir():
    if not proc.name.isdigit():
        continue
    try:
        executable = os.readlink(proc / 'exe')
    except (OSError, PermissionError):
        continue
    assert executable not in {str(x[0]) for x in targets}, 'Target executable still running: ' + proc.name
print(json.dumps({'preflight_files': 20, 'delete_files': 13, 'delete_bytes': 9443488, 'retain_files': 7}), flush=True)
for item in targets:
    assert item[0].is_relative_to(root)
    assert inspect(item) == identities[item[0]]
    item[0].unlink()
    print('Deleted exact generated file: ' + str(item[0]), flush=True)
for item in retained:
    assert inspect(item) == identities[item[0]]
print(json.dumps({'status': 'completed', 'deleted_files': 13, 'deleted_bytes': 9443488, 'retained_cache_files_verified': 7, 'directories_removed': 0}), flush=True)
'@
$payload = [Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes($pythonSource))
$code = 'import base64;exec(base64.b64decode("' + $payload + '"))'
& wsl.exe -d Ubuntu-24.04 -u root --exec python3 -c $code
if ($LASTEXITCODE -ne 0) { throw "Exact WSL cleanup failed: $LASTEXITCODE" }

