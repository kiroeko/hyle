import hashlib
import json
import os
from pathlib import Path
import subprocess

root = Path('/mnt/c/public/project-hyle/hyle')
out = root / '.scratch/perf-review-2026-10-18/http2-owner-loop'
build = Path('/root/hyle-scratch/http2-current-20261018/owner-loop')
assert not (out / 'test-commands.json').exists()
prior = json.loads((root / '.scratch/perf-review-2026-10-18/http2/header-lifetime/commands.json').read_text())
env = dict(os.environ, LD_LIBRARY_PATH='/root/hyle-scratch/http2-current-20261018/current-holdout:/root/hyle-scratch/io-watch-v2-dev/bin')
commands = []
source = root / 'tests/io_http2/http2_test.cc'
source_sha = hashlib.sha256(source.read_bytes()).hexdigest()
(out / 'test-source.sha256').write_text(source_sha + '\n')
def execute(name, command, expected=0, changes=None):
    print(name, flush=True)
    result = subprocess.run(command, cwd=build, env=dict(env, **(changes or {})), capture_output=True, timeout=30)
    (out / (name + '.stdout.txt')).write_bytes(result.stdout)
    (out / (name + '.stderr.txt')).write_bytes(result.stderr)
    commands.append({'name': name, 'argv': command, 'returncode': result.returncode,
                     'expected': expected, 'environment_changes': changes or {}})
    (out / 'test-commands.json').write_text(json.dumps(commands, indent=2) + '\n')
    if result.returncode != expected:
        print(result.stdout.decode(errors='replace'), result.stderr.decode(errors='replace'), flush=True)
        raise SystemExit(1)
argv = next(c['argv'] for c in prior if c['name'] == 'compile-tests')
flags = argv[:argv.index('-c')] + ['-Wall', '-Wextra', '-Wpedantic', '-Werror']
execute('compile-tests', flags + ['-c', str(source), '-o', str(build / 'http2_test.o')])
assert hashlib.sha256(source.read_bytes()).hexdigest() == source_sha
product = (out / 'after.cc').read_text()
assert product.count('--state.owner_waiters;') == 1
mutant = out / 'waiter-reset-mutant.cc'
mutant.write_text(product.replace('--state.owner_waiters;', 'state.owner_waiters = 0;'))
base = json.loads((root / '.scratch/perf-review-2026-10-18/http2-paired-run/attempt-2/build.json').read_text())
argv = next(c['argv'] for c in base['commands'] if c['name'] == 'compile-consumer')
product_flags = argv[:argv.index('-c')] + ['-DHYLE_IO_HTTP2_BUILD']
execute('compile-mutant', product_flags + ['-c', str(mutant), '-o', str(build / 'mutant.o')])
link = next(c['argv'] for c in prior if c['name'] == 'link-tests')
for label, obj in [('candidate', build / 'http2.o'), ('mutant', build / 'mutant.o')]:
    mapping = {
        '/root/hyle-scratch/http2-current-20261018/header-lifetime/http2.o': str(obj),
        '/root/hyle-scratch/http2-current-20261018/header-lifetime/http2_test.o': str(build / 'http2_test.o'),
        '/root/hyle-scratch/http2-current-20261018/header-lifetime/tests': str(build / ('tests-' + label)),
    }
    execute('link-tests-' + label, [mapping.get(x, x) for x in link])
execute('waiter-reset-negative-control', [str(build / 'tests-mutant'), '--gtest_filter=IoHttp2.TimedOutContenderDoesNotHideAnotherOwnerWaiter'], expected=1)
execute('all-default', [str(build / 'tests-candidate')])
execute('all-epoll', [str(build / 'tests-candidate')], changes={'HYLE_IO_FORCE_EPOLL': '1'})
print('Negative control failed as expected; candidate suites passed.', flush=True)
