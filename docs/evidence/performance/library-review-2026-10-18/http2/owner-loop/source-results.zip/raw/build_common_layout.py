import hashlib
import json
import os
from pathlib import Path
import subprocess

root = Path('/mnt/c/public/project-hyle/hyle')
out = root / '.scratch/perf-review-2026-10-18/http2-owner-loop'
build = Path('/root/hyle-scratch/http2-current-20261018/owner-loop')
base = json.loads((root / '.scratch/perf-review-2026-10-18/http2-paired-run/attempt-2/build.json').read_text())
env = dict(os.environ, **base['environment'])
link = next(c['argv'] for c in base['commands'] if c['name'] == 'link')
tail = link[link.index('-L/root/hyle-scratch/io-watch-v2-dev/bin'):]
common = [
    '/root/hyle-scratch/http2-current-20261018/root-cause-product/consumer.o',
    '/root/hyle-scratch/http2-current-20261018/src_io_http_http.cc.o',
    '/root/hyle-scratch/http2-current-20261018/src_io_http2_feature.cc.o',
    '/root/hyle-scratch/http2-current-20261018/picohttpparser.o',
    '/root/hyle-scratch/http2-current-20261018/paired-comparison-v2/nanobench.o',
]
nghttp2 = '/root/hyle-scratch/http2-current-20261018/nghttp2-build/lib/libnghttp2.a'
record = {'reason': 'Default input order let a product-only TU change move common consumer/native hot text by0x500. Put common inputs first and whole native archive before varying product; assert selected common symbol addresses match. No source recompilation.', 'commands': []}
symbols = {}
for label, product in [('old', '/root/hyle-scratch/http2-current-20261018/root-cause-notify/http2.o'),
                       ('new', str(build / 'http2.o'))]:
    binary = build / ('layout-' + label)
    assert not binary.exists()
    command = ['g++-14', '-pthread', '-o', str(binary), '-Wl,-Map,' + str(binary) + '.map'] + common + \
              ['-Wl,--whole-archive', nghttp2, '-Wl,--no-whole-archive', product] + tail
    result = subprocess.run(command, cwd=build, env=env, capture_output=True, timeout=30)
    (out / ('layout-' + label + '.stdout.txt')).write_bytes(result.stdout)
    (out / ('layout-' + label + '.stderr.txt')).write_bytes(result.stderr)
    record['commands'].append({'argv': command, 'returncode': result.returncode})
    if result.returncode:
        (out / 'common-layout.json').write_text(json.dumps(record, indent=2) + '\n')
        raise SystemExit(result.stderr.decode(errors='replace'))
    lines = subprocess.check_output(['nm', '-n', '-C', str(binary)], text=True).splitlines()
    keys = ('nghttp2_session_mem_recv2', 'nghttp2_session_mem_send2', 'raw_task_endpoint',
            'raw_data_chunk', 'hyle_server', 'hyle_client', 'HyleHarness::run')
    symbols[label] = {key: [line for line in lines if key in line] for key in keys}
    record[label] = {'path': str(binary), 'bytes': binary.stat().st_size,
                     'sha256': hashlib.sha256(binary.read_bytes()).hexdigest(), 'symbols': symbols[label]}
record['same_common_addresses'] = symbols['old'] == symbols['new']
(out / 'common-layout.json').write_text(json.dumps(record, indent=2) + '\n')
assert record['same_common_addresses'], 'Common addresses still differ; do not run the experiment.'
print('Common consumer/native symbol addresses match; binaries linked.', flush=True)
