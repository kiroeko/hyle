import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

root = Path('/mnt/c/public/project-hyle/hyle')
assert len(sys.argv) == 1 or sys.argv[1:] == ['common']
common_layout = len(sys.argv) == 2
out = root / ('.scratch/perf-review-2026-10-18/http2-owner-loop/' +
              ('timing-common' if common_layout else 'timing'))
out.mkdir(exist_ok=False)
sys.path.insert(0, str(root / 'bench/io_http2'))
from run_paired import machine_metadata, summarize

before = Path('/root/hyle-scratch/http2-current-20261018/' +
              ('owner-loop/layout-old' if common_layout else 'root-cause-notify/candidate'))
after = Path('/root/hyle-scratch/http2-current-20261018/owner-loop/' +
             ('layout-new' if common_layout else 'candidate'))
schedule = [('self-before', after, 'paired-self'), ('old-1', before, 'paired'),
            ('new-1', after, 'paired'), ('new-2', after, 'paired'),
            ('old-2', before, 'paired'), ('self-after', after, 'paired-self')]
env = dict(os.environ, LD_LIBRARY_PATH='/root/hyle-scratch/http2-current-20261018/current-holdout:/root/hyle-scratch/io-watch-v2-dev/bin')
assert 2 in os.sched_getaffinity(0)
summary = {'scope': 'Shared unmodified paired consumer, complete fixed4stream AF_UNIX trace, full oracle and retirement. Only owner cache, owner-waiter notification gate and empty-flush publication differ.',
           'common_layout': common_layout,
           'limit': 'Fixed six processes; no result-driven repeat/filtering. Per-process complete blocks are the descriptive unit; no CI or equivalence.',
           'machine': machine_metadata(2, os.sched_getaffinity(0)),
           'environment': {'LD_LIBRARY_PATH': env['LD_LIBRARY_PATH']}, 'runs': [],
           'identities': [{'path': str(p), 'bytes': p.stat().st_size, 'sha256': hashlib.sha256(p.read_bytes()).hexdigest()}
                          for p in [before, after, root / 'src/io_http2/http2.cc', root / 'bench/io_http2/http2_p1_bench.cc',
                                    out.parent / 'before.cc', root / 'tests/io_http2/http2_test.cc']]}
for name, binary, mode in schedule:
    command = ['taskset', '-c', '2', str(binary), '--' + mode]
    with (out / (name + '.stdout.jsonl')).open('wb') as stdout, (out / (name + '.stderr.txt')).open('wb') as stderr:
        process = subprocess.run(command, cwd=root, env=env, stdout=stdout, stderr=stderr, timeout=60)
    run = {'name': name, 'command': command, 'returncode': process.returncode}
    summary['runs'].append(run)
    (out / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
    if process.returncode:
        raise SystemExit('Failed; output retained without retry: ' + name)
    run['result'] = summarize((out / (name + '.stdout.jsonl')).read_text(), mode, 2)
    (out / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
    print(name, 'median_percent', run['result']['median_ratio_percent'], flush=True)
summary['status'] = 'completed'
(out / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
