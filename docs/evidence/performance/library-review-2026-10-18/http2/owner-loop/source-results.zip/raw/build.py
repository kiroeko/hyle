import hashlib
import json
import os
from pathlib import Path
import subprocess

root = Path('/mnt/c/public/project-hyle/hyle')
out = root / '.scratch/perf-review-2026-10-18/http2-owner-loop'
build = Path('/root/hyle-scratch/http2-current-20261018/owner-loop')
assert not (out / 'build.json').exists()
base = json.loads((root / '.scratch/perf-review-2026-10-18/http2-paired-run/attempt-2/build.json').read_text())
argv = next(c['argv'] for c in base['commands'] if c['name'] == 'compile-consumer')
flags = argv[:argv.index('-c')] + ['-DHYLE_IO_HTTP2_BUILD']
source = root / 'src/io_http2/http2.cc'
def identity(path):
    return {'path': str(path), 'bytes': path.stat().st_size, 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}
record = {'source': identity(source), 'commands': [], 'environment': base['environment']}
env = dict(os.environ, **base['environment'])
def execute(name, command):
    print(name, flush=True)
    result = subprocess.run(command, cwd=build, env=env, capture_output=True, timeout=60)
    (out / (name + '.stdout.txt')).write_bytes(result.stdout)
    (out / (name + '.stderr.txt')).write_bytes(result.stderr)
    record['commands'].append({'name': name, 'argv': command, 'returncode': result.returncode})
    (out / 'build.json').write_text(json.dumps(record, indent=2) + '\n')
    if result.returncode:
        print(result.stderr.decode(errors='replace'), flush=True)
        raise SystemExit(result.returncode)
execute('compile-final-product', flags + ['-c', str(source), '-o', str(build / 'http2.o')])
assert identity(source) == record['source']
link = next(c['argv'] for c in base['commands'] if c['name'] == 'link')
mapping = {
    '/root/hyle-scratch/http2-current-20261018/paired-comparison-v2/paired-bench': str(build / 'candidate'),
    '-Wl,-Map,/root/hyle-scratch/http2-current-20261018/paired-comparison-v2/paired-bench.map': '-Wl,-Map,' + str(build / 'candidate.map'),
    '/root/hyle-scratch/http2-current-20261018/paired-comparison-v2/consumer.o': '/root/hyle-scratch/http2-current-20261018/root-cause-product/consumer.o',
    '/root/hyle-scratch/http2-current-20261018/dead-submit-final/http2.o': str(build / 'http2.o'),
}
execute('link-final-candidate', [mapping.get(x, x) for x in link])
record['reused'] = [identity(Path(x)) for x in mapping.values() if x.endswith('.o') and not x.startswith(str(build))]
record['built'] = [identity(build / 'http2.o'), identity(build / 'candidate')]
(out / 'build.json').write_text(json.dumps(record, indent=2) + '\n')
