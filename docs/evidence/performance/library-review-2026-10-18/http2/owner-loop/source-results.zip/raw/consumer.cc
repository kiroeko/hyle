#define main legacy_main
#include "../../../bench/io_http2/http2_p1_bench.cc"
#undef main
extern "C" unsigned long long http2_diag[10];
extern "C" unsigned real_owner(const void *) asm("__real__ZNK4hyle2io13HttpTransport12owner_workerEv");
extern "C" unsigned wrap_owner(const void *) asm("__wrap__ZNK4hyle2io13HttpTransport12owner_workerEv");
extern "C" unsigned wrap_owner(const void *p) { ++http2_diag[9]; return real_owner(p); }
int main() {
  std::signal(SIGPIPE, SIG_IGN);
  const auto workload = make_workload("owner-loop diagnostic",4,256*1024,256*1024,
                                       NGHTTP2_INITIAL_CONNECTION_WINDOW_SIZE);
  { HyleHarness hyle;
    for (unsigned i = 0; i != 20; ++i) if (hyle.run(workload) != 4) return 2;
  }
  const char *names[] = {"notify_owner", "owner_notify_all", "validate_owner", "check_operation",
    "wait_for_change", "wait_locked", "empty_flush", "received_calls", "received_bytes", "transport_owner_getter"};
  std::printf("{\"episodes\":20,\"all_oracles_passed\":true");
  for (unsigned i=0; i != 10; ++i) std::printf(",\"%s\":%llu", names[i], http2_diag[i]);
  std::printf("}\n");
}
