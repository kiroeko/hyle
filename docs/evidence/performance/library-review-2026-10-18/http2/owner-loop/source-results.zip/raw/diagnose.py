import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

root = Path('/mnt/c/public/project-hyle/hyle')
out = root / '.scratch/perf-review-2026-10-18/http2-owner-loop'
build = Path('/root/hyle-scratch/http2-current-20261018/owner-loop')
build.mkdir(exist_ok=True)
phase = sys.argv[1]
assert phase in ('before', 'after')
assert not (out / (phase + '-commands.json')).exists()
base = json.loads((root / '.scratch/perf-review-2026-10-18/http2-paired-run/attempt-2/build.json').read_text())
argv = next(c['argv'] for c in base['commands'] if c['name'] == 'compile-consumer')
flags = argv[:argv.index('-c')]
old_link = next(c['argv'] for c in base['commands'] if c['name'] == 'link')
env = dict(os.environ, **base['environment'])
source = (root / 'src/io_http2/http2.cc').read_text()
(out / (phase + '.cc')).write_text(source)
patterns = [
    ('  void notify_owner() noexcept {', '++http2_diag[0];'),
    ('Status validate_owner(const Http2SessionState &state) noexcept {', '++http2_diag[2];'),
    ('Status check_operation(const Http2SessionState &state,\n                       OperationOptions options) noexcept {', '++http2_diag[3];'),
    ('Status wait_for_change(Http2SessionState &state, OperationOptions options,\n                       std::uint64_t observed) noexcept {', '++http2_diag[4];'),
    ('  auto wait_locked = [&](std::unique_lock<util::SpinLock> &lock) noexcept {', '++http2_diag[5];'),
    ('    if (encoded == 0 && state.wire.size == 0) {', '++http2_diag[6];'),
    ('                                TransferResult received) noexcept {', '++http2_diag[7]; http2_diag[8] += received.bytes;'),
    ('    OperationOptions options) noexcept {\n  if (!reader.valid())', 'unused'),
]
for needle, counter in patterns[:-1]:
    assert source.count(needle) == 1, needle
    source = source.replace(needle, needle + '\n  ' + counter)
start = source.index('  void notify_owner() noexcept {')
end = source.index('  // Cancellation may originate', start)
fragment = source[start:end].replace('changed.notify_all();', '(++http2_diag[1], changed.notify_all());')
source = source[:start] + fragment + source[end:]
instrumented = out / (phase + '-instrumented.cc')
instrumented.write_text('extern "C" { unsigned long long http2_diag[10]{}; }\n' + source)
commands = []
def execute(name, command):
    print(name, flush=True)
    result = subprocess.run(command, cwd=build, env=env, capture_output=True, timeout=60)
    (out / (phase + '-' + name + '.stdout.txt')).write_bytes(result.stdout)
    (out / (phase + '-' + name + '.stderr.txt')).write_bytes(result.stderr)
    commands.append({'name': name, 'argv': command, 'returncode': result.returncode})
    (out / (phase + '-commands.json')).write_text(json.dumps(commands, indent=2) + '\n')
    if result.returncode:
        print(result.stderr.decode(errors='replace'), flush=True)
        raise SystemExit(result.returncode)
    if name == 'diagnostic':
        print(result.stdout.decode(), flush=True)
if phase == 'before':
    consumer = out / 'consumer.cc'
    consumer.write_text('''#define main legacy_main
#include "../../../bench/io_http2/http2_p1_bench.cc"
#undef main
extern "C" unsigned long long http2_diag[10];
extern "C" unsigned real_owner(const void *) asm("__real__ZNK4hyle2io13HttpTransport12owner_workerEv");
extern "C" unsigned wrap_owner(const void *) asm("__wrap__ZNK4hyle2io13HttpTransport12owner_workerEv");
extern "C" unsigned wrap_owner(const void *p) { ++http2_diag[9]; return real_owner(p); }
int main() {
  std::signal(SIGPIPE, SIG_IGN);
  const auto workload = make_workload("owner-loop diagnostic",4,256*1024,256*1024,
                                       NGHTTP2_INITIAL_CONNECTION_WINDOW_SIZE);
  { HyleHarness hyle;
    for (unsigned i = 0; i != 20; ++i) if (hyle.run(workload) != 4) return 2;
  }
  const char *names[] = {"notify_owner", "owner_notify_all", "validate_owner", "check_operation",
    "wait_for_change", "wait_locked", "empty_flush", "received_calls", "received_bytes", "transport_owner_getter"};
  std::printf("{\\\"episodes\\\":20,\\\"all_oracles_passed\\\":true");
  for (unsigned i=0; i != 10; ++i) std::printf(",\\\"%s\\\":%llu", names[i], http2_diag[i]);
  std::printf("}\\n");
}
''')
    execute('compile-consumer', flags + ['-c', str(consumer), '-o', str(build / 'consumer.o')])
execute('compile-product', flags + ['-DHYLE_IO_HTTP2_BUILD', '-c', str(instrumented), '-o', str(build / (phase + '-diag.o'))])
mapping = {
    '/root/hyle-scratch/http2-current-20261018/paired-comparison-v2/paired-bench': str(build / (phase + '-diag')),
    '-Wl,-Map,/root/hyle-scratch/http2-current-20261018/paired-comparison-v2/paired-bench.map': '-Wl,-Map,' + str(build / (phase + '-diag.map')),
    '/root/hyle-scratch/http2-current-20261018/paired-comparison-v2/consumer.o': str(build / 'consumer.o'),
    '/root/hyle-scratch/http2-current-20261018/dead-submit-final/http2.o': str(build / (phase + '-diag.o')),
}
execute('link', [mapping.get(x, x) for x in old_link] + ['-Wl,--wrap=_ZNK4hyle2io13HttpTransport12owner_workerEv'])
execute('diagnostic', ['taskset', '-c', '2', str(build / (phase + '-diag'))])
(out / (phase + '-source.json')).write_text(json.dumps({'sha256': hashlib.sha256((out / (phase + '.cc')).read_bytes()).hexdigest()}, indent=2) + '\n')
