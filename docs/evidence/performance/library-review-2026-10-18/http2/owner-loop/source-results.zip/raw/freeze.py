import hashlib
import json
from pathlib import Path
import stat
import zipfile

root = Path('/mnt/c/public/project-hyle/hyle')
raw = root / '.scratch/perf-review-2026-10-18/http2-owner-loop'
base = Path('/root/hyle-scratch/http2-current-20261018')
build = base / 'owner-loop'
dest = root / 'docs/evidence/performance/library-review-2026-10-18/http2/owner-loop'
dest.mkdir(exist_ok=False)
def identity(path):
    assert path.resolve(strict=True) == path and stat.S_ISREG(path.lstat().st_mode)
    with path.open('rb') as stream:
        digest = hashlib.file_digest(stream, 'sha256').hexdigest()
    return {'path': str(path), 'bytes': path.stat().st_size, 'sha256': digest}
build_record = json.loads((raw / 'build.json').read_text())
assert identity(root / 'src/io_http2/http2.cc') == build_record['source']
assert identity(root / 'tests/io_http2/http2_test.cc')['sha256'] == (raw / 'test-source.sha256').read_text().strip()
for name in ('all-default', 'all-epoll'):
    assert '[  PASSED  ] 17 tests.' in (raw / (name + '.stdout.txt')).read_text()
keep = {build / p for p in ('http2.o', 'http2_test.o', 'tests-candidate', 'layout-new')}
generated = []
for path in sorted(build.iterdir()):
    if path.is_file():
        with path.open('rb') as stream:
            elf = stream.read(4) == b'\x7fELF'
        if path.suffix == '.o' or elf:
            generated.append(path)
generated += [base / p for p in ('root-cause-notify/http2.o', 'root-cause-notify/candidate',
                                 'root-cause-notify/tests', 'root-cause-product/http2_test.o')]
retained = sorted(keep | {base / p for p in ('current-holdout/libhyle_io_core.so.0.1.0',
                                           'paired-comparison-v2/nanobench.o', 'root-cause-product/consumer.o')})
plan = {'delete': [identity(p) for p in generated if p not in keep],
        'retain': [identity(p) for p in retained]}
(raw / 'artifact-plan.json').write_text(json.dumps(plan, indent=2) + '\n')
natural = json.loads((raw / 'timing/summary.json').read_text())
common = json.loads((raw / 'timing-common/summary.json').read_text())
assert natural['status'] == common['status'] == 'completed'
summary = {
    'conclusion': 'Retain three local reductions of confirmed redundant work; no stable overall speedup, equivalence, isolated layout causality or full residual root cause established. Hyle remains slower in this fixed trace.',
    'changes': [
        'Cache fixed transport owner only inside private session validation; all27400 runtime owner/lifecycle/cancellation/deadline checks retained. Public owner_worker getters unchanged, including zero after shutdown.',
        'Count whole owner-side predicate waits; notify_owner still advances change_epoch but calls CV only if owner_waiters nonzero. Foreign cancellation still locks monitor and unconditionally notifies; counter not read by foreign thread.',
        'Empty flush with no encoded or owned wire data releases unobservable temporary write claim without artificial change publication. Registered close/error callbacks publish their own changes; real frames retain normal release notifications.'
    ],
    'diagnostic_20_complete_episodes': {
        'before': json.loads((raw / 'before-diagnostic.stdout.txt').read_text()),
        'after': json.loads((raw / 'after-diagnostic.stdout.txt').read_text()),
        'limit': 'Diagnostic counters/wrapped getter are untimed. This trace has no changed-CV waiters; notification savings in it do not establish wake behavior under contention.'},
    'validation': {'default': '17/17 passed', 'forced_epoll': '17/17 passed',
                   'multi_waiter': 'A holds native read; B/C contend on changed CV. C times out, then B must complete via normal owner notification before server replies to A.',
                   'negative_control': 'Scratch mutant resets count to0 instead of decrementing: new public regression fails normally after its budgets expire, proving it detects a remaining waiter hidden by timeout.',
                   'review': 'Independent source review of owner/cache lifetime, shutdown boundary, whole-wait counter, foreign cancel publication, native callbacks and empty encode. Independent recomputation of all144 blocks across both layouts matched summary.',
                   'scope': 'Only affected product/test TUs rebuilt; existing shared pure benchmark consumer and library/dependency caches reused. Not a full currentHEAD rebuild. No Windows/macOS/TLS-specific/sanitizer or other shape measurements.'},
    'natural_layout': natural,
    'common_layout': common,
    'layout_identity': json.loads((raw / 'common-layout.json').read_text()),
    'interpretation': {
        'natural': 'Old/new block medians +1.953503/+2.471460% and +1.932609/+1.586295%: one order worse, the other better; retained in full. No stable improvement.',
        'common': 'After an actual0x500 shift of common hot symbols was found, predeclared one additional fixed six-process sequence with unchanged consumer/native symbols at matching addresses. Old/new medians +2.758976/+1.424771% and +1.946056/+1.691295%. Limited directional support, not proof that layout caused earlier behavior.',
        'tails': 'Natural AA includes-10.524785% block; common old1 includes+27.597241%. No removal or tail-based mean claim. AA/IQR/ranges are descriptive, not CIs or corrections to subtract.',
        'remaining': 'Common new has18/24 slower blocks, medians+1.424771/+1.691295%; natural new medians+2.471460/+1.586295%. Residual remains unresolved across both layouts.'},
    'sources': [identity(root / p) for p in ('src/io_http2/http2.cc', 'tests/io_http2/http2_test.cc', 'bench/io_http2/http2_p1_bench.cc')],
    'artifacts': plan,
}
(dest / 'summary.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2) + '\n')
with zipfile.ZipFile(dest / 'source-results.zip', 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for path in sorted(raw.rglob('*')):
        if path.is_file() and '__pycache__' not in path.parts:
            archive.write(path, 'raw/' + path.relative_to(raw).as_posix())
    for p in ('src/io_http2/http2.cc', 'tests/io_http2/http2_test.cc', 'bench/io_http2/http2_p1_bench.cc'):
        archive.write(root / p, 'source/' + p)
    for name in ('layout-old.map', 'layout-new.map'):
        archive.write(build / name, 'maps/' + name)
with zipfile.ZipFile(dest / 'source-results.zip') as archive:
    assert archive.testzip() is None
print(json.dumps({'archive': identity(dest / 'source-results.zip'), 'delete_files': len(plan['delete']),
                  'delete_bytes': sum(x['bytes'] for x in plan['delete']), 'retain_files': len(plan['retain'])}, indent=2))
