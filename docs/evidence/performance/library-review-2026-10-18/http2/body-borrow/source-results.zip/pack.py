from pathlib import Path
import hashlib, json, re, subprocess, zipfile

ROOT = Path(__file__).resolve().parents[4]
HERE = Path(__file__).resolve().parent
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
sources = {'src/io_http2/http2.cc': 'http2.candidate.cc',
           'tests/io_http2/http2_test.cc': 'http2_test.cc'}
for product, snapshot in sources.items():
    assert sha(ROOT / product) == sha(HERE / snapshot)
before = (HERE / 'before-borrow-regression.stdout.txt').read_text()
assert 'Actual: false' in before and 'borrow_preserved.load()' in before
assert 'server_ok.load()' not in before and 'client_ok.load()' not in before
for name in ['candidate-http2-tests', 'candidate-epoll-tests']:
    assert '[  PASSED  ] 15 tests.' in (HERE / (name + '.stdout.txt')).read_text()
applied = 'b8cfc70b6'
(HERE / 'product.diff').write_bytes(subprocess.check_output(
    ['git', 'show', '--format=', applied, '--', *sources], cwd=ROOT))
identity = json.loads((HERE / 'identity-candidate.json').read_text())
summary = {
    'task': 'Fix HTTP2 body view invalidation by receive compaction during another stream operation',
    'applied_commit': applied,
    'scope': 'Independent borrowed-view correctness fix; not a diagnosis or resolution of the large-body manual-loop throughput residual.',
    'contract': 'HttpBodyChunkView bytes remain valid until the next operation on that reader or connection destruction (include/hyle/io/http.h). HTTP2 handles are owner-worker affine; another stream may drive the same session while the reader retains a view.',
    'before': {
        'defect': 'on_data_chunk memmoved unread bytes over an acknowledged prefix when more DATA arrived. The current borrow remained in those unread bytes, but its span still pointed at the old physical offset.',
        'no_realloc': 'inbound reserve occurs only when capacity is0; later appends use fixed capacity. This observed invalidation comes from memmove, not buffer reallocation.',
        'window_trace': 'Server consumes/ACKs32KiB then borrows another chunk. WINDOW_UPDATE permits the remainder of a96KiB request. accept() on the next stream drives those bytes before delivering that later stream head, so the old buffer needs compaction while the earlier reader has no new operation.',
        'actual_regression': 'Old product plus the new public lifecycle test exits1 solely on borrow_preserved=false. Both endpoints complete and full96KiB body plus both responses validate; no timeout/crash.',
    },
    'fix': {
        'representation': 'Only the per-stream inbound ByteBuffer uses ring semantics: size is the unacknowledged byte count, inbound_start the physical head. ByteBuffer/header/trailer/wire implementations remain unchanged.',
        'borrow': 'Borrowed bytes remain in used size until ACK; callback appends only into free ring space in at most2memcpy calls, so it cannot overwrite the current borrow.',
        'bounds': 'Tail uses subtraction to avoid head+size overflow. read limits the returned span to the contiguous ring suffix. Thus ACK head+consumed<=capacity, with wrap at capacity. Empty DATA avoids tail/copy arithmetic.',
        'lifecycle': 'done/final trailer exposure, abandon/reset credit and readiness use the same unread count. Both flow-control consume calls and release/error responsibilities remain.',
        'space': 'No fields, extra allocation or capacity added. Original one receive-window allocation and limits preserved.',
        'complexity': 'Appends copy only new payload bytes, eliminating compaction of older unread bytes. No per-reader-operation full-buffer memmove was introduced.',
    },
    'validation': {
        'build': 'Fresh GCC14 O3/NDEBUG old+candidate HTTP2 TU and one current test TU, direct link with existing nghttp2/static HTTP objects and cached foundation shared libraries. No configure/download/SDK copy/foundation rebuild.',
        'before_single': '1 new test, expected FAIL, only borrowed-view comparison failed;45ms test-run output is functional logging, not a benchmark.',
        'candidate_single': 'New regression PASS with same test TU and fixture.',
        'candidate_suite': '15/15 PASS:14protocol tests plus compiled feature test.',
        'forced_epoll_suite': 'Same15/15 PASS with HYLE_IO_FORCE_EPOLL=1.',
        'cases': re.findall(r'^\[ RUN      \] (.+)$', (HERE / 'candidate-http2-tests.stdout.txt').read_text(), re.M),
        'not_run': 'Windows/macOS, sanitizer, forced allocator-failure matrix, or throughput/ranking. No further probe or repeated timing.',
    },
    'measured_and_applied_sources_identical': {
        product: {'snapshot': snapshot, 'sha256': sha(HERE / snapshot)}
        for product, snapshot in sources.items()},
    'baseline_source': {'snapshot': 'http2.before.cc', 'sha256': sha(HERE / 'http2.before.cc')},
    'residual_boundary': 'Prior full matched manual-loop results remain unresolved. Existing stage8 aligned2fiber control did not reproduce Hyle slower in its2processes but does not establish equivalence or attribute pure scheduler cost. The old performance consumer uses consume() and does not retain the affected view across other stream operations.',
    'failures_preserved': 'Expected original borrowed-view regression failure is retained verbatim. No unexpected compile/link or candidate test failures occurred.',
}
(HERE / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
artifacts = identity['artifacts']
(HERE / 'cleanup-candidates.json').write_text(json.dumps({
    'host': 'WSL', 'directory': '/root/hyle-scratch/http2-current-20261018/body-borrow',
    'files': artifacts, 'total_bytes': sum(r['bytes'] for r in artifacts),
    'action': 'Candidates only. Root test.ps1 exact path/size/SHA cleanup; no deletion performed. Shared nghttp2/foundation/native caches untouched.'}, indent=2) + '\n')
allowed = {'.json', '.cc', '.py', '.txt', '.diff'}
with zipfile.ZipFile(HERE / 'source-results.zip', 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for p in sorted(HERE.iterdir(), key=lambda x: x.name):
        if p.is_file() and p.suffix in allowed and p.name != 'archive-record.json':
            archive.write(p, p.name)
    for name in ['include/hyle/io/http.h', 'include/hyle/io/http2.h']:
        archive.write(ROOT / name, name)
record = {name: {'path': (HERE / name).relative_to(ROOT).as_posix(),
    'bytes': (HERE / name).stat().st_size, 'sha256': sha(HERE / name)}
    for name in ['summary.json', 'source-results.zip', 'cleanup-candidates.json']}
(HERE / 'archive-record.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record, indent=2))
