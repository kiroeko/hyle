from pathlib import Path
import hashlib, json, os, subprocess, sys

ROOT = Path('/mnt/c/public/project-hyle/hyle')
HERE = ROOT / '.scratch/perf-review-2026-10-18/http2/body-borrow'
BUILD = Path('/root/hyle-scratch/http2-current-20261018/body-borrow')
BUILD.mkdir(exist_ok=True)
old = json.loads((HERE.parent / 'build-candidate-commands.json').read_text())
record_file = HERE / 'commands.json'
records = json.loads(record_file.read_text()) if record_file.exists() else []

def run(name, argv, expected=0, env=None):
    argv = list(map(str, argv))
    result = subprocess.run(argv, cwd=BUILD, env=env, capture_output=True,
                            text=True, timeout=60)
    (HERE / (name + '.stdout.txt')).write_text(result.stdout)
    (HERE / (name + '.stderr.txt')).write_text(result.stderr)
    records.append(dict(name=name, argv=argv, cwd=str(BUILD),
                        exit=result.returncode, expected_exit=expected,
                        environment={k:v for k,v in (env or {}).items()
                                     if k.startswith('HYLE_')}))
    record_file.write_text(json.dumps(records, indent=2) + '\n')
    print(name, result.returncode, result.stdout[-2600:], result.stderr[-1200:], flush=True)
    if result.returncode != expected:
        raise SystemExit(result.returncode or 1)

arm = sys.argv[1]
if arm == 'before':
    command = next(x['argv'] for x in old if x['name'] == 'compile-tests')
    run('compile-tests', command[:-4] + ['-c', HERE / 'http2_test.cc', '-o', BUILD / 'test.o'])
command = next(x['argv'] for x in old if x['name'] == 'compile-candidate')
run('compile-' + arm, command[:-4] + ['-c', HERE / ('http2.' + arm + '.cc'),
                                    '-o', BUILD / (arm + '.o')])
link = next(x['argv'] for x in old if x['name'] == 'link-tests')
args = []
for arg in link:
    if arg.endswith('/http2_tests'):
        arg = str(BUILD / (arm + '-tests'))
    elif arg.endswith('/http2-candidate.o'):
        arg = str(BUILD / (arm + '.o'))
    elif arg.endswith('/http2_test.o'):
        arg = str(BUILD / 'test.o')
    args.append(arg)
run('link-' + arm, args)
only = '--gtest_filter=IoHttp2.BorrowedBodySurvivesOtherStreamReceivingMoreData'
prefix = ['timeout', '--kill-after=2s', '20s', 'taskset', '-c', '2,3']
run(arm + '-borrow-regression', prefix + [BUILD / (arm + '-tests'), only],
    expected=1 if arm == 'before' else 0)
if arm == 'candidate':
    run('candidate-http2-tests', prefix + [BUILD / 'candidate-tests'])
    env = os.environ.copy()
    env['HYLE_IO_FORCE_EPOLL'] = '1'
    run('candidate-epoll-tests', prefix + [BUILD / 'candidate-tests'], env=env)

def identity(p):
    return dict(path=str(p), bytes=p.stat().st_size,
                sha256=hashlib.sha256(p.read_bytes()).hexdigest())
inputs = [Path(x) for x in args if x.endswith(('.o', '.a'))]
inputs += list(Path('/root/hyle-scratch/io-watch-v2-dev/bin').glob('libhyle_*.so'))
(HERE / ('identity-' + arm + '.json')).write_text(json.dumps(dict(
    sources=[identity(p) for p in [HERE / ('http2.'+arm+'.cc'), HERE / 'http2_test.cc']],
    reused=[identity(p) for p in inputs if p.is_file()],
    artifacts=[identity(p) for p in BUILD.iterdir() if p.is_file()],
    no_foundation_rebuild=True, no_sdk_download_or_copy=True,
    no_timing=True), indent=2) + '\n')
