from pathlib import Path
import hashlib
import json
import os
import subprocess

ROOT = Path('/mnt/c/public/project-hyle/hyle')
HERE = ROOT / '.scratch/perf-review-2026-10-18/http2/discard-frame'
PRIOR = HERE.parent / 'owned-wire-no-copy'
BASE = Path('/root/hyle-scratch/http2-current-20261018')
OUT = BASE / 'discard-frame'
ENV = {k: v for k, v in os.environ.items()
       if not k.startswith(('HYLE_BENCH_', 'HYLE_PERF_', 'HYLE_IO_FORCE_'))}
ENV['LD_LIBRARY_PATH'] = str(BASE / 'current-holdout') + ':/root/hyle-scratch/io-watch-v2-dev/bin'
records = []


def rec(path):
    return {'path': str(path), 'bytes': path.stat().st_size,
            'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}


def write(name, value):
    (HERE / name).write_text(json.dumps(value, indent=2) + '\n')


def run(name, argv, env=ENV):
    result = subprocess.run(list(map(str, argv)), cwd=OUT, env=env,
                            capture_output=True, text=True, timeout=60)
    (HERE / (name + '.stdout.txt')).write_text(result.stdout)
    (HERE / (name + '.stderr.txt')).write_text(result.stderr)
    records.append({'name': name, 'argv': list(map(str, argv)), 'cwd': str(OUT),
                    'exit': result.returncode,
                    'environment': {k: v for k, v in env.items()
                                    if k.startswith(('LD_LIBRARY_PATH', 'HYLE_'))}})
    write('commands.json', records)
    print(name, result.returncode, result.stdout[-2200:], result.stderr[-1000:], flush=True)
    if result.returncode:
        raise RuntimeError('Stopped on failed command: ' + name)
    return result.stdout


def disassembly(arm, obj):
    symbols = run(arm + '-symbols', ['nm', '-S', '-C', '--defined-only', obj])
    selected = {}
    for line in symbols.splitlines():
        fields = line.split(maxsplit=3)
        if len(fields) != 4:
            continue
        address, size, _, name = fields
        tag = None
        if name.startswith('hyle::io::http2_body_discard(') and \
                '[clone .actor]' in name and '[clone .cold]' not in name:
            tag = 'discard-actor'
        if name.startswith('hyle::io::http2_body_read(') and '[clone' not in name:
            tag = 'read-factory'
        if tag:
            begin, count = int(address, 16), int(size, 16)
            text = run(arm + '-' + tag, ['objdump', '-drC',
                '--start-address=' + hex(begin), '--stop-address=' + hex(begin + count), obj])
            selected[tag] = {'address': begin, 'machine_code_bytes': count,
                             'symbol': name,
                             'public_read_factory_relocations': [x.strip() for x in text.splitlines()
                                 if 'R_X86_64' in x and 'hyle::io::http2_body_read(' in x]}
    assert set(selected) == {'discard-actor', 'read-factory'}, selected
    return selected


def main():
    assert not (HERE / 'commands.json').exists(), 'Do not overwrite/rerun this validation'
    before = (HERE / 'http2.before.cc').read_bytes()
    current = (ROOT / 'src/io_http2/http2.cc').read_bytes()
    old = b'co_await http2_body_read(allocator, reader, 0, options);'
    new = b'detail::Http2SessionAccess::read_body(allocator, reader, 0, options);'
    assert before.count(old) == 1 and before.replace(old, new) == current
    assert before == (PRIOR / 'http2.candidate.cc').read_bytes()
    candidate = HERE / 'http2.candidate.cc'
    candidate.write_bytes(current)
    identity = json.loads((PRIOR / 'functional-identity.json').read_text())
    # The superseded header-lifetime product object was explicitly cleaned.
    # Its current NO_COPY replacement remains the immutable static baseline.
    baseline = BASE / 'owned-wire-no-copy/http2.o'
    expected_baseline = next(x for x in identity['artifacts'] if x['path'] == str(baseline))
    assert rec(baseline) == expected_baseline
    checked = []
    for entry in identity['reused_inputs']:
        if entry['path'] == str(BASE / 'header-lifetime/http2.o'):
            continue
        actual = rec(Path(entry['path']))
        assert actual == entry, actual
        checked.append(actual)
    previous_preflight = json.loads((PRIOR / 'preflight-identity.json').read_text())
    assert rec(ROOT / 'src/io_core/proactor.cc') == previous_preflight['current_proactor_source']
    assert (ROOT / 'tests/io_http2/http2_test.cc').read_bytes() == \
        (PRIOR.parent / 'header-lifetime/http2_test.cc').read_bytes()
    assert (ROOT / 'tests/io_http2/feature_test.cc').read_bytes() == \
        (PRIOR.parent / 'header-lifetime/feature_test.cc').read_bytes()
    OUT.mkdir(exist_ok=False)
    write('preflight-identities.json', {'baseline_object': expected_baseline,
        'baseline_source': rec(HERE / 'http2.before.cc'),
        'candidate_source': rec(candidate), 'retained_inputs': checked,
        'current_core_source': rec(ROOT / 'src/io_core/proactor.cc'),
        'coro_header': rec(ROOT / 'include/hyle/sched/coro.h'),
        'test_source': rec(ROOT / 'tests/io_http2/http2_test.cc')})
    run('compiler', ['g++-14', '--version'])
    before_asm = disassembly('before', baseline)
    assert before_asm['discard-actor']['public_read_factory_relocations']
    commands = json.loads((PRIOR / 'functional-commands.json').read_text())
    compile_cmd = next(x['argv'] for x in commands if x['name'] == 'compile-http2')
    run('compile-http2', compile_cmd[:-4] + ['-c', candidate, '-o', OUT / 'http2.o'])
    after_asm = disassembly('after', OUT / 'http2.o')
    assert not after_asm['discard-actor']['public_read_factory_relocations']
    write('static-frame-evidence.json', {'before': before_asm, 'after': after_asm,
        'interpretation': 'Original discard actor calls the public read factory on each loop, resumes/destroys its child handle. The standalone read factory allocates0xd0=208 bytes through the supplied AllocatorRef on this GCC14x86_64 build. Final discard actor has no relocation to that factory; public read remains for public callers. This is static code evidence, not a runtime allocation counter or throughput measurement.'})
    original = next(x['argv'] for x in commands if x['name'] == 'link-tests')
    link = [str(OUT / 'tests') if x == str(BASE / 'owned-wire-no-copy/tests') else
            str(OUT / 'http2.o') if x == str(baseline) else x for x in original]
    run('link-tests', link)
    loader = run('loader', ['ldd', OUT / 'tests'])
    assert str(BASE / 'current-holdout/libhyle_io_core.so.0.1.0') in loader
    results = []
    for label in ('default', 'epoll'):
        env = ENV.copy()
        if label == 'epoll':
            env['HYLE_IO_FORCE_EPOLL'] = '1'
        run(label + '-tests', ['timeout', '--kill-after=2s', '20s', OUT / 'tests',
            '--gtest_output=json:' + str(HERE / (label + '-tests.json'))], env)
        result = json.loads((HERE / (label + '-tests.json')).read_text())
        assert result['tests'] == 15 and result['failures'] == result['errors'] == 0
        results.append({'backend': label, 'tests': result['tests'],
                        'failures': result['failures'], 'errors': result['errors'],
                        'time': result['time']})
    artifacts = [rec(OUT / name) for name in ('http2.o', 'tests')]
    write('functional-results.json', {'results': results, 'artifacts': artifacts,
        'fresh_product_TUs': 1, 'test_TUs_or_sdk_rebuilt': 0,
        'static_before_after': 'static-frame-evidence.json',
        'timing_benchmark_or_extra_shape_run': False})
    write('cleanup-candidates.json', {'host': 'WSL Ubuntu-24.04 root',
        'root': str(OUT), 'files': artifacts,
        'logical_bytes': sum(x['bytes'] for x in artifacts),
        'disposition': 'Do not delete or overwrite current shared baseline/cache. New2files only; no cleanup executed.'})


if __name__ == '__main__':
    main()
