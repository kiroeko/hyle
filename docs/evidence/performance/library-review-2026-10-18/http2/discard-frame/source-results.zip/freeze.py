from pathlib import Path
import hashlib
import json
import subprocess
import zipfile

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[3]


def rec(path):
    return {'path': str(path), 'bytes': path.stat().st_size,
            'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}


def main():
    candidate = ROOT / 'http2.candidate.cc'
    assert candidate.read_bytes() == (REPO / 'src/io_http2/http2.cc').read_bytes()
    diff = subprocess.run(['git', 'diff', '--', 'src/io_http2/http2.cc'],
                          cwd=REPO, capture_output=True, check=True)
    (ROOT / 'product.diff').write_bytes(diff.stdout)
    result = json.loads((ROOT / 'functional-results.json').read_text())
    static = json.loads((ROOT / 'static-frame-evidence.json').read_text())
    preflight = json.loads((ROOT / 'preflight-identities.json').read_text())
    summary = {
        'status': 'Implemented one-line private-helper reuse; existing targeted functional tests pass; not committed or cleaned',
        'scope': 'Only http2_body_discard calls the same private read_body directly instead of co_await of public http2_body_read. Public outer discard Task and public read Task API/ABI remain.',
        'source_before': rec(ROOT / 'http2.before.cc'),
        'source_after': rec(candidate), 'promise_source': rec(ROOT / 'coro.h'),
        'static_evidence': static,
        'mechanism': {
            'before': 'The existing GCC14 NO_COPY object has one public-read factory relocation in the discard loop actor. That factory requests0xd0=208 bytes including allocator prefix, at alignment16, initializes a child coroutine frame, and old discard resumes/destroys its handle each iteration. This was not optimized away.',
            'after': 'Fresh object discard actor has no public-read factory relocation and calls Http2SessionAccess::read_body directly. Public http2_body_read factory remains for public callers; the reduction is private nesting, not removal of public support.',
            'native_code_note': 'Use relocation targets, not unresolved call display labels: an after-actor __stack_chk_fail relocation can be printed with the next read-destroy symbol as its temporary address label.',
            'measurement_limit': 'Static allocation-request evidence, not runtime allocation counting, total heap accounting, instructions or elapsed speedup.'},
        'contracts_retained': [
            'Outer discard coroutine remains lazily started and allocated through its first AllocatorRef. The same allocator, reader, max_bytes0 and OperationOptions reach read_body on every iteration.',
            'Private helper still performs per-chunk valid/busy checks, cancel/deadline/transport driving, acknowledgement of the previous borrow and current EOF/error selection.',
            'Final EOF acknowledge_body and returned Status/error path are unchanged. Reader/stream owner pins, borrowed-span lifetime and reset/retirement implementations are unchanged.',
            'Task awaiter only drove the child to completion on the same stackful fiber, with no required continuation or additional scheduled-owner lifetime. Synchronous private driving retains the same fiber suspension behavior.',
            'The unnecessary child frame allocation/free and its failure point disappear; remaining outer Task and helper/native allocator failure paths are retained. No Task-wide OOM handling or awaiter behavior was changed.'
        ],
        'functional': result,
        'closure': {'compiler': 'WSL Ubuntu24.04 GCC14.2.0, x86_64, O3/NDEBUG/C++23',
            'fresh_product_TUs': 1, 'fresh_test_TUs': 0, 'new_SDK_or_foundation_builds': 0,
            'cached_inputs_verified': len(preflight['retained_inputs']),
            'baseline_object': preflight['baseline_object'],
            'test_source': preflight['test_source'],
            'loader': 'Actual ldd resolves /root/hyle-scratch/http2-current-20261018/current-holdout/libhyle_io_core.so.0.1.0; other foundation/native/GTest inputs reused at recorded exact SHA.'},
        'performance_conclusion': 'None. No benchmark, new shape, timing, allocation-runtime probe or performance sample ran. Current consume-based4x256KiB holdout already uses the direct private helper; this discard mechanism cannot explain or claim to fix its8-11% residual.',
        'limitations': 'Existing15tests include multiple discard call sites, duplex, trailers, cancellation/reset/deadline, borrowed-body and allocator/limit checks. No new special per-chunk-frame-OOM fixture or standalone performance test was added.',
        'packaging_only_correction': 'The first freeze.py invocation used one too many parent directories and failed before generating the archive. Corrected only the packaging path; original error recorded in freeze-initial-failure.txt. No compilation/test repetition.',
        'product_diff': 'One replacement line only in src/io_http2/http2.cc. Apple9product/test files, README and test.ps1 untouched by this task.',
        'cleanup': 'cleanup-candidates.json lists only new discard-frame/http2.o and tests with exact SHA/size; no deletion, overwrite of shared cache or commit performed.'
    }
    (ROOT / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
    files = sorted((p for p in ROOT.iterdir() if p.is_file() and p.name not in
                    {'source-results.zip', 'archive-identity.json', 'package-manifest.json'}),
                   key=lambda p: p.name)
    manifest = {'files': [{**rec(p), 'path': p.name} for p in files],
                'no_executables_objects_or_SDK_in_archive': True}
    (ROOT / 'package-manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
    files.append(ROOT / 'package-manifest.json')
    archive = ROOT / 'source-results.zip'
    with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED) as out:
        for path in files:
            out.write(path, path.name)
    identity = rec(archive)
    identity['files'] = len(files)
    (ROOT / 'archive-identity.json').write_text(json.dumps(identity, indent=2) + '\n')
    print(json.dumps({'archive': identity, 'source_after': rec(candidate),
                      'summary': rec(ROOT / 'summary.json'),
                      'cleanup': json.loads((ROOT / 'cleanup-candidates.json').read_text())}, indent=2))


if __name__ == '__main__':
    main()
