from pathlib import Path
import hashlib, json, os, shutil, subprocess, time
ROOT = Path('/mnt/c/public/project-hyle/hyle')
HERE = ROOT / '.scratch/perf-review-2026-10-18/http2-dead-submit/final'
OLD = ROOT / '.scratch/perf-review-2026-10-18/http2'
OUT = Path('/root/hyle-scratch/http2-current-20261018/dead-submit-final')
ENV = {k:v for k,v in os.environ.items() if not k.startswith(('HYLE_BENCH_', 'HYLE_PERF_', 'HYLE_IO_FORCE_'))}
ENV['LD_LIBRARY_PATH'] = '/root/hyle-scratch/http2-current-20261018/current-holdout:/root/hyle-scratch/io-watch-v2-dev/bin'
records = []
def write(name, value):
    (HERE/name).write_text(json.dumps(value, indent=2)+'\n')
def identity(path):
    p=Path(path); return {'path':str(p),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
def run(name,argv,env=ENV):
    start=time.monotonic()
    p=subprocess.run(list(map(str,argv)),cwd=OUT,env=env,capture_output=True,timeout=60)
    (HERE/(name+'.stdout.txt')).write_bytes(p.stdout)
    (HERE/(name+'.stderr.txt')).write_bytes(p.stderr)
    records.append({'name':name,'argv':list(map(str,argv)),'exit':p.returncode,'seconds':time.monotonic()-start,'cwd':str(OUT),'environment':{k:v for k,v in env.items() if k=='LD_LIBRARY_PATH' or k.startswith('HYLE_IO_FORCE_')}})
    write('commands.json',records)
    print(name, 'exit',p.returncode,flush=True)
    if p.returncode: raise RuntimeError(p.stderr.decode(errors='replace')[-2500:])
    return p.stdout
assert not (HERE/'commands.json').exists(), 'Do not rerun existing results'
assert not OUT.exists(), 'Do not reuse a previous output directory'
old=json.loads((OLD/'owned-wire-no-copy/functional-identity.json').read_text())
inputs=[]
for item in old['reused_inputs']:
    if item['path'].endswith('/header-lifetime/http2.o'): continue
    actual=identity(item['path']); assert actual==item,actual
    inputs.append(actual)
for src,dst in [('src/io_http2/http2.cc','http2.candidate.cc'),('tests/io_http2/http2_test.cc','http2_test.cc')]:
    shutil.copyfile(ROOT/src,HERE/dst)
    inputs.append(identity(ROOT/src))
assert b'submit_epoch' not in (HERE/'http2.candidate.cc').read_bytes()
write('preflight-identities.json',{'retained_inputs':inputs,'baseline_source':identity(HERE/'http2.before.cc'),'public_header':identity(ROOT/'include/hyle/io/http2.h'),'core_scope':'Existing accepted core/foundation/nghttp2 retained; fresh product HTTP2 uses current headers. No elapsed comparison with old cached HTTP2.'})
OUT.mkdir()
commands=json.loads((OLD/'discard-frame/commands.json').read_text())
compiler=next(x['argv'] for x in commands if x['name']=='compile-http2')
compile_cmd=compiler[:compiler.index('-c')]+['-c',str(HERE/'http2.candidate.cc'),'-o',str(OUT/'http2.o')]
run('compile-http2',compile_cmd)
link=next(x['argv'] for x in commands if x['name']=='link-tests')
replacements={
 '/root/hyle-scratch/http2-current-20261018/discard-frame/tests':str(OUT/'tests'),
 '/root/hyle-scratch/http2-current-20261018/discard-frame/http2.o':str(OUT/'http2.o'),
 '/root/hyle-scratch/http2-current-20261018/header-lifetime/http2_test.o':'/root/hyle-scratch/http2-current-20261018/header-lifetime/http2_test.o'}
run('link-tests',[replacements.get(arg,arg) for arg in link])
results=[]
for name,extra in [('default-tests',{}),('epoll-tests',{'HYLE_IO_FORCE_EPOLL':'1'})]:
    env=ENV|extra
    run(name,['timeout','--kill-after=2s','20s',OUT/'tests','--gtest_output=json:'+str(HERE/(name+'.json'))],env)
    d=json.loads((HERE/(name+'.json')).read_text())
    assert d['failures']==0 and d['errors']==0
    results.append({'backend':name,'tests':d['tests'],'failures':d['failures'],'errors':d['errors'],'time':d['time']})
artifacts=[identity(OUT/n) for n in ['http2.o','tests']]
write('summary.json',{'status':'related functional regressions passed; no performance timing','fresh_translation_units':1,'results':results,'artifacts':artifacts,'retained_cache_inputs':inputs,'scope':'Only the private write-only submit counter was removed. The small-header stack-array candidate was rejected and reverted. No DATA/flush/borrow/cancel contract changes. No throughput, total allocation/RSS, Windows/macOS or sanitizer claim.'})
write('cleanup-candidates.json',{'root':str(OUT),'files':[a for a in artifacts if a['path'].endswith('/tests')],'retain':[a for a in artifacts if not a['path'].endswith('/tests')],'note':'Only the new test executable is a cleanup candidate; keep the final product object and existing shared test cache for reuse. Root writes exact test.ps1 before cleanup.'})
print(json.dumps({'results':results,'new_binary_bytes':sum(a['bytes'] for a in artifacts)}),flush=True)

