# One-time exact cleanup for the completed HTTP2 small-header regression.
# Preserve source, logs, raw samples, maps, archives and shared caches.
$ErrorActionPreference = 'Stop'
$archive = Join-Path $PSScriptRoot 'docs/evidence/performance/library-review-2026-10-18/http2/small-headers/source-results.zip'
if ((Get-FileHash -LiteralPath $archive -Algorithm SHA256).Hash.ToLowerInvariant() -ne '02fa1595f98346ad4b8f668692ea8869663826307977318051c9608c044c61a4') { throw 'Frozen evidence archive mismatch' }
$pythonSource = @'
import hashlib, json, os, stat
from pathlib import Path

root = Path('/root/hyle-scratch/http2-current-20261018/small-headers')
targets = [
    (Path('/root/hyle-scratch/http2-current-20261018/small-headers/tests'), 1588368, '930cfc4c960de4dddb0b51b0f0c9a267d1a4e1d7031bfc10e1e21bff53a5aac7'),
]
retained = [
    (Path('/root/hyle-scratch/http2-current-20261018/small-headers/http2.o'), 224840, '49ccfa8eacb0a7c81a1ab70a4ccb640b24c176820bce9bc2469ca3e5aa9dbc2a'),
    (Path('/root/hyle-scratch/http2-current-20261018/small-headers/http2_test.o'), 689960, 'd2a7f2d71cebd556ed733f1912942e3dc9c7a2fec9b25aa8aa24aec6da87783a'),
]
assert root.resolve(strict=True) == root
assert len({x[0] for x in targets + retained}) == 3
assert sum(x[1] for x in targets) == 1588368

def inspect(item):
    path, size, expected_sha = item
    assert path.is_absolute() and path.is_relative_to(Path('/root/hyle-scratch/http2-current-20261018'))
    current = Path(path.anchor)
    for part in path.parts[1:]:
        current /= part
        assert not stat.S_ISLNK(current.lstat().st_mode), str(current)
    assert path.resolve(strict=True) == path
    before = path.lstat()
    assert stat.S_ISREG(before.st_mode) and before.st_size == size
    with os.fdopen(os.open(path, os.O_RDONLY | os.O_NOFOLLOW), 'rb') as stream:
        opened = os.fstat(stream.fileno())
        assert (opened.st_dev, opened.st_ino) == (before.st_dev, before.st_ino)
        digest = hashlib.sha256(stream.read()).hexdigest()
        after = os.fstat(stream.fileno())
    current = path.lstat()
    assert digest == expected_sha and after.st_size == size
    assert (current.st_dev, current.st_ino, current.st_size) == (after.st_dev, after.st_ino, after.st_size)
    return current.st_dev, current.st_ino

identities = {x[0]: inspect(x) for x in targets + retained}
for proc in Path('/proc').iterdir():
    if not proc.name.isdigit():
        continue
    try:
        executable = os.readlink(proc / 'exe')
    except (OSError, PermissionError):
        continue
    assert executable not in {str(x[0]) for x in targets}, 'Target executable still running: ' + proc.name
print(json.dumps({'preflight_files': 3, 'delete_files': 1, 'delete_bytes': 1588368, 'retain_files': 2}), flush=True)
for item in targets:
    assert item[0].parent == root
    assert inspect(item) == identities[item[0]]
    item[0].unlink()
    print('Deleted exact generated file: ' + str(item[0]), flush=True)
for item in retained:
    assert inspect(item) == identities[item[0]]
print(json.dumps({'status': 'completed', 'deleted_files': 1, 'deleted_bytes': 1588368, 'retained_cache_files_verified': 2, 'directories_removed': 0}), flush=True)
'@
$payload = [Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes($pythonSource))
$code = 'import base64;exec(base64.b64decode("' + $payload + '"))'
& wsl.exe -d Ubuntu-24.04 -u root --exec python3 -c $code
if ($LASTEXITCODE -ne 0) { throw "Exact WSL cleanup failed: $LASTEXITCODE" }

