"""Authorized fixed Hyle-only baseline/candidate build and ABBA; no retries."""

from pathlib import Path
import datetime
import hashlib
import json
import os
import re
import subprocess
import sys
import time


LOCAL = Path(__file__).resolve().parent
ROOT = LOCAL.parents[2]
REMOTE = Path("/root/hyle-scratch/http2-current-20261018/small-headers-timing")
PLAN = json.loads((LOCAL / "plan.json").read_text())
COMMANDS = json.loads((LOCAL / "commands-plan.json").read_text())


def write(name, value):
    (LOCAL / name).write_text(json.dumps(value, indent=2) + "\n")


def identity(path):
    path = Path(path)
    stat = path.stat()
    return {"path": str(path), "resolved": str(path.resolve()),
            "bytes": stat.st_size,
            "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}


def execute(name, argv, cwd=None, extra_env=None):
    env = os.environ.copy()
    env.update(extra_env or {})
    assert not env.get("LD_PRELOAD") and not env.get("LD_AUDIT")
    start = time.monotonic()
    utc = datetime.datetime.now(datetime.timezone.utc).isoformat()
    process = subprocess.run(argv, cwd=cwd, env=env, capture_output=True)
    (LOCAL / (name + ".stdout.txt")).write_bytes(process.stdout)
    (LOCAL / (name + ".stderr.txt")).write_bytes(process.stderr)
    entry = {"name": name, "argv": argv, "cwd": str(cwd) if cwd else None,
             "environment": extra_env or {}, "started_utc": utc,
             "wall_seconds": time.monotonic() - start,
             "exit_code": process.returncode}
    log = LOCAL / "commands-actual.json"
    entries = json.loads(log.read_text()) if log.exists() else []
    entries.append(entry)
    write("commands-actual.json", entries)
    if process.returncode != 0:
        write("failure.json", entry)
        raise RuntimeError(f"{name} exited {process.returncode}; stop, no retry")
    return process.stdout.decode()


def build():
    assert 2 in os.sched_getaffinity(0)
    assert not REMOTE.exists(), "Refuse to overwrite any output/cache directory"
    observed = []
    failures = []
    expected_inputs = PLAN["expected_retained_inputs"] + [
        dict(expected, path=str(ROOT / expected["path"]))
        for expected in PLAN["source_snapshots"] + PLAN["live_source_inputs"]]
    for expected in expected_inputs:
        actual = identity(expected["path"])
        actual["matches_expected"] = all(actual[key] == expected[key]
                                          for key in ("bytes", "sha256"))
        observed.append(actual)
        if not actual["matches_expected"]:
            failures.append(expected["path"])
    metadata = {"allowed_affinity": sorted(os.sched_getaffinity(0)),
                "inherited_preload": os.environ.get("LD_PRELOAD"),
                "inherited_audit": os.environ.get("LD_AUDIT"),
                "observed_inputs": observed, "mismatches": failures}
    write("preflight-identities.json", metadata)
    assert not failures, failures
    metadata["uname"] = execute("uname", ["uname", "-a"]).strip()
    metadata["compiler"] = execute("compiler", ["g++-14", "--version"]).strip()
    metadata["lscpu"] = json.loads(execute("lscpu", ["lscpu", "--json"]))
    metadata["cpu2_affinity"] = execute(
        "cpu2-affinity", ["taskset", "-c", "2", "python3", "-c",
                          "import os;print(sorted(os.sched_getaffinity(0)))"]).strip()
    assert metadata["cpu2_affinity"] == "[2]"
    metadata["passed"] = True
    write("preflight-identities.json", metadata)
    REMOTE.mkdir(parents=True, exist_ok=False)
    print(json.dumps({"preflight": "passed", "inputs": len(observed)}), flush=True)

    for command in COMMANDS[:4]:
        execute(command["name"], command["argv"], REMOTE, command["environment"])
        print(json.dumps({"completed": command["name"]}), flush=True)
    loaders = {}
    expected_core = next(item for item in PLAN["expected_retained_inputs"]
                         if "/current-holdout/libhyle_io_core" in item["path"])
    for variant in ("old", "new"):
        ldd = execute("loader-" + variant, ["ldd", str(REMOTE / ("probe-" + variant))],
                      REMOTE, COMMANDS[0]["environment"])
        loaded = []
        for line in ldd.splitlines():
            match = re.search(r"=> (/\S+) ", line)
            if match:
                loaded.append(identity(match.group(1)))
        core = next(item for item in loaded if "/libhyle_io_core.so" in item["path"])
        assert all(core[key] == expected_core[key] for key in ("bytes", "sha256"))
        assert core["resolved"] == expected_core["path"]
        loaders[variant] = loaded
        map_file = REMOTE / ("probe-" + variant + ".map")
        (LOCAL / map_file.name).write_bytes(map_file.read_bytes())
    assert loaders["old"] == loaders["new"]
    objects = [identity(REMOTE / name) for name in
               ("http2-old.o", "consumer.o", "probe-old", "probe-new")]
    candidate_expected = next(item for item in PLAN["expected_retained_inputs"]
                              if "/small-headers/http2.o" in item["path"])
    candidate_actual = identity(candidate_expected["path"])
    assert all(candidate_actual[key] == candidate_expected[key] for key in ("bytes", "sha256"))
    write("build-identities.json", {"new_artifacts": objects,
                                   "retained_candidate": candidate_actual,
                                   "loaded_libraries": loaders,
                                   "current_tcp_header": identity(ROOT / "include/hyle/io/tcp.h"),
                                   "maps": [identity(REMOTE / ("probe-" + v + ".map"))
                                            for v in ("old", "new")],
                                   "ready": True})
    print(json.dumps({"build": "passed", "ready": True,
                      "new_artifacts": objects}), flush=True)


def formal():
    assert json.loads((LOCAL / "build-identities.json").read_text())["ready"]
    count = 0
    for command in COMMANDS[4:]:
        execute(command["name"], command["argv"], REMOTE, command["environment"])
        suffix = command["name"].removeprefix("formal-")
        raw = REMOTE / ("epochs-" + suffix + ".json")
        (LOCAL / raw.name).write_bytes(raw.read_bytes())
        data = json.loads(raw.read_text())
        assert len(data["results"]) == 1
        arm = data["results"][0]
        assert len(arm["measurements"]) == 9
        assert arm["batch"] == 4 and arm["minEpochTime"] == 0.01
        assert arm["minEpochIterations"] == 5
        count += 9
        print(json.dumps({"process": suffix, "exit": 0, "measurements": 9}), flush=True)
    write("terminal.json", {"status": "completed", "formal_processes": 4,
                             "measurements": count, "additional_runs": 0})
    print(json.dumps({"terminal": "completed", "formal_processes": 4,
                      "measurements": count}), flush=True)


if __name__ == "__main__":
    assert sys.platform.startswith("linux")
    {"build": build, "formal": formal}[sys.argv[1]]()
