#define main original_http2_bench_main
#include "http2_p1_bench.cc"
#undef main

#include <chrono>

int main(int argc, char **argv) {
  if (argc != 3 ||
      (std::string_view(argv[1]) != "old" &&
       std::string_view(argv[1]) != "new"))
    return 2;
  std::signal(SIGPIPE, SIG_IGN);
  const Workload workload = make_workload(
      "Hyle fixed HTTP2 small-header allocation control 4x256KiB", 4,
      256 * 1024, 256 * 1024, NGHTTP2_INITIAL_CONNECTION_WINDOW_SIZE);
  HyleHarness hyle;
  // No RawHarness is constructed in either executable. The public Hyle
  // episode, its two endpoint Tasks, ownership and cleanup are unchanged.
  const int warmed = hyle.run(workload);
  std::fprintf(stderr, "warmup variant=%s hyle=%d expected=4\n", argv[1],
               warmed);
  if (warmed != workload.streams)
    return 3;
  auto run = [&] {
    if (hyle.run(workload) != workload.streams)
      std::abort();
  };
  ankerl::nanobench::Bench bench;
  bench.title(workload.title)
      .batch(static_cast<std::uint64_t>(workload.streams))
      .unit("stream")
      .performanceCounters(false)
      .minEpochTime(std::chrono::milliseconds(10))
      .minEpochIterations(5)
      .epochs(9);
  bench.run(argv[1], run);
  std::ofstream output(argv[2]);
  if (!output)
    return 4;
  bench.render(ankerl::nanobench::templates::json(), output);
  return output ? 0 : 4;
}
