"""Freeze all results of the one completed Hyle-only ABBA, without more runs."""

from pathlib import Path
import hashlib
import json
import statistics
import zipfile


OUT = Path(__file__).resolve().parent


def read(name):
    return json.loads((OUT / name).read_text())


def write(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2) + "\n", encoding="utf-8")


def identity(path):
    data = path.read_bytes()
    return {"path": path.name, "bytes": len(data),
            "sha256": hashlib.sha256(data).hexdigest()}


plan = read("plan.json")
build = read("build-identities.json")
preflight = read("preflight-identities.json")
terminal = read("terminal.json")
commands = read("commands-actual.json")
assert terminal == {"status": "completed", "formal_processes": 4,
                    "measurements": 36, "additional_runs": 0}
results = []
for index, variant in enumerate(("old", "new", "new", "old")):
    name = f"epochs-{index}-{variant}.json"
    document = read(name)
    assert len(document["results"]) == 1
    arm = document["results"][0]
    assert arm["name"] == variant and len(arm["measurements"]) == 9
    assert arm["batch"] == 4 and arm["minEpochTime"] == 0.01
    assert arm["minEpochIterations"] == 5
    ns = [entry["elapsed"] * 1e9 for entry in arm["measurements"]]
    iterations = [entry["iterations"] for entry in arm["measurements"]]
    total_ms = [n * count / 1e6 for n, count in zip(ns, iterations)]
    assert min(iterations) >= 5
    results.append({
        "process_index": index, "variant": variant, "exit_code": 0,
        "raw_file": name, "epochs": 9,
        "median_ns_per_complete_episode": statistics.median(ns),
        "mean_of_epoch_ns_per_complete_episode": statistics.mean(ns),
        "range_ns_per_complete_episode": [min(ns), max(ns)],
        "median_ns_per_stream": statistics.median(ns) / 4,
        "all_ns_per_complete_episode_in_original_order": ns,
        "all_iterations_in_original_order": iterations,
        "all_epoch_elapsed_ms_from_normalized_elapsed_times_iterations": total_ms,
        "clock_resolution_ns": arm["clockResolution"] * 1e9,
        "median_absolute_percent_error": arm["medianAbsolutePercentError(elapsed)"] * 100,
    })

changes = []
for old_index, new_index in ((0, 1), (3, 2)):
    changes.append({
        "old_process": old_index, "new_process": new_index,
        "new_over_old_median_elapsed_change_percent": (
            results[new_index]["median_ns_per_complete_episode"] /
            results[old_index]["median_ns_per_complete_episode"] - 1) * 100,
        "new_over_old_mean_elapsed_change_percent": (
            results[new_index]["mean_of_epoch_ns_per_complete_episode"] /
            results[old_index]["mean_of_epoch_ns_per_complete_episode"] - 1) * 100,
    })

summary = {
    "status": "negative NVArray candidate rejected by root; fixed ABBA completed, no added runs, product edits, cleanup or commit by this agent",
    "comparison": "Hyle-only complete public HTTP2 episode, combined dead-submit-counter removal and temporary outgoing NV-array stack fast path",
    "external_peer_measured": False,
    "decision": {
        "candidate_source_sha256": "e841253878db846a668031e505d763385d6d0dc836e335f10890905d4910734b",
        "disposition": "Root rejected and restored the NVArray stack path and its new large-header test because there is no supported latency gain and both median comparisons show a regression signal. This agent does not edit product or README after this decision.",
        "dead_submit_counter": "Root keeps the separately justified write-only counter cleanup without a throughput claim. This combined-candidate timing does not establish dead-only latency behavior.",
        "accepted_dead_only_final_source_sha256_reported_by_root": "a4692c7924b2c13b6ba5f90b9f2b1d6560d64b2b75bb288c9b5de323bc9730be",
        "separate_dead_only_validation_reported_by_root": "Fresh final product TU, retained original15-test object: default15/15 and epoll15/15. Not run by this agent, and no timing of that final source is claimed.",
        "followup": "No further timing or variable isolation authorized or performed by this agent.",
    },
    "process_order": ["old", "new", "new", "old"],
    "plan": plan,
    "functional_results_from_this_timing": {
        "explicit_untimed_complete_warmups": 4,
        "warmup_success": "All four report hyle=4 expected=4.",
        "timed_success": "Every timed callback retains the original HyleHarness::run complete payload, header/status, reverse response ordering, flow-control and stream-count checks. Both endpoint joins and cleanup remain inside the episode. Any failure aborts; all four processes exited zero.",
        "extra_smoke_aa_shape_or_repeat": 0, "failures": [],
        "separate_product_tests": "Root previously ran default and epoll each16/16; referenced in functional_evidence in plan, not rerun or counted as this timing work.",
    },
    "actual_environment": {
        "uname": preflight["uname"], "compiler": preflight["compiler"].splitlines()[0],
        "cpu_model": next(item["data"] for item in preflight["lscpu"]["lscpu"]
                          if item["field"] == "Model name:"),
        "affinity": [2], "raw_harness_constructed": False,
        "tcp_overlay": False, "current_tcp_header_used_for_both_http2_tus": True,
        "preload": preflight["inherited_preload"], "audit": preflight["inherited_audit"],
        "both_executables_loaded_same_library_identities": build["loaded_libraries"]["old"] == build["loaded_libraries"]["new"],
    },
    "results": results,
    "paired_changes": changes,
    "old_first_to_last_median_drift_percent": (
        results[3]["median_ns_per_complete_episode"] /
        results[0]["median_ns_per_complete_episode"] - 1) * 100,
    "measurement_limits": [
        "Both new process medians are slower (+0.86253% and +2.41767%). Mean changes disagree in the reverse pair (+1.41490% and -0.94921%). Do not report a latency gain or proven no-regression.",
        "All ranges, including the final old process high epoch, are retained. No outlier filtering, extra A/A or repeated sampling was performed.",
        "Configured minEpochTime is10ms; actual recorded epoch elapsed products can fall below that target due to nanobench iteration selection and runtime variation. All actual durations and iterations are retained without resampling.",
        "This tests the two source simplifications together; it does not attribute a timing effect separately to allocation or dead-counter removal.",
        "The eight temporary NV allocation/free pairs removed from this fixed trace are a source-level mechanism statement, not a measured allocator/peak-memory counter or a claimed speedup.",
        "Do not combine these Hyle-only values or percentages with prior manual-loop/matched-peer rankings. No external peer runs occur here.",
        "Current baseline and candidate HTTP2 code use the same current TCP header and flags. Shared IO core/foundation and locked native library are reused unchanged; no full repository or SDK rebuild is claimed.",
    ],
    "independent_review": "A second agent independently recomputed every median/mean and paired change from all36 measurements, confirmed iterations>=5 and the Hyle-only common consumer with unchanged full run oracle. No extra execution.",
    "build_identity": build,
    "raw_identity": [identity(OUT / result["raw_file"]) for result in results],
    "source_identity": [identity(OUT / name) for name in
                        ("consumer.cc", "http2_p1_bench.cc", "http2.before.cc", "http2.candidate.cc")],
    "actual_commands": "commands-actual.json",
}
write("summary.json", summary)

files = [{key: item[key] for key in ("path", "bytes", "sha256")}
         for item in build["new_artifacts"] if not item["path"].endswith("/consumer.o")]
retains = [{key: item[key] for key in ("path", "bytes", "sha256")}
           for item in build["new_artifacts"] if item["path"].endswith("/consumer.o")]
retains.extend(item for item in plan["expected_retained_inputs"]
               if "/current-holdout/libhyle_io_core" in item["path"])
assert len({item["path"] for item in files + retains}) == len(files + retains)
write("cleanup-candidates.json", {
    "host": "WSL Ubuntu-24.04 root",
    "root": "/root/hyle-scratch/http2-current-20261018/small-headers-timing",
    "files": files, "count": len(files),
    "logical_bytes": sum(item["bytes"] for item in files),
    "retain": retains,
    "retain_count": len(retains),
    "retain_logical_bytes": sum(item["bytes"] for item in retains),
    "disposition": "No cleanup executed. Only these two executables and the obsolete fresh baseline object are delete candidates; root must write exact test.ps1 first. Keep shared consumer.o for reproduction and all source, logs, raw JSON, maps, archives and native/SDK/foundation inputs. The rejected small-headers/http2.o belongs to the separate functional batch and is outside this cleanup scope.",
})

names = ["consumer.cc", "http2_p1_bench.cc", "http2.before.cc", "http2.candidate.cc",
         "run.py", "freeze.py", "plan.json", "commands-plan.json", "commands-actual.json",
         "preflight-identities.json", "build-identities.json", "terminal.json", "summary.json",
         "cleanup-candidates.json", "probe-old.map", "probe-new.map"]
names.extend(result["raw_file"] for result in results)
for command in commands:
    names.extend(command["name"] + suffix for suffix in (".stdout.txt", ".stderr.txt"))
assert len(names) == len(set(names))
with zipfile.ZipFile(OUT / "source-results.zip", "w", zipfile.ZIP_DEFLATED) as archive:
    for name in names:
        assert (OUT / name).is_file(), name
        archive.write(OUT / name, name)
write("archive-identity.json", {
    "archive": identity(OUT / "source-results.zip"), "members": len(names),
    "summary": identity(OUT / "summary.json"),
    "cleanup": identity(OUT / "cleanup-candidates.json"),
    "contains_executable_object_library_or_sdk": False,
})
print(json.dumps({"archive": identity(OUT / "source-results.zip"),
                  "members": len(names), "paired_changes": changes,
                  "cleanup_count": len(files),
                  "cleanup_logical_bytes": sum(item["bytes"] for item in files)}))
