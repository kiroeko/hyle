# One-time exact cleanup for the completed/rejected HTTP2 small-header experiment.
# Preserve source, logs, raw samples, maps, archives and shared caches.
$ErrorActionPreference = 'Stop'
$archive = Join-Path $PSScriptRoot 'docs/evidence/performance/library-review-2026-10-18/http2/small-headers/timing/source-results.zip'
if ((Get-FileHash -LiteralPath $archive -Algorithm SHA256).Hash.ToLowerInvariant() -ne 'c4c2cfaf0858d7229dfd0ac14421c09a2d607fa27eae62b21883b19c7b749573') { throw 'Frozen evidence archive mismatch' }
$pythonSource = @'
import hashlib, json, os, stat
from pathlib import Path

root = Path('/root/hyle-scratch/http2-current-20261018')
targets = [
    (Path('/root/hyle-scratch/http2-current-20261018/small-headers-timing/http2-old.o'), 225520, 'ea6df19dd3e4c3e470d2547654c23280291dce87666e1d627f3585de8c532cb5'),
    (Path('/root/hyle-scratch/http2-current-20261018/small-headers-timing/probe-old'), 869192, '30e210ca11293901da6385275040111ece1c397c8876ca71b0c162392ebfe7e1'),
    (Path('/root/hyle-scratch/http2-current-20261018/small-headers-timing/probe-new'), 869192, 'd998d16ff5a9f93cf93d6ceec8dccf8d19bce67face6701a0b52c95aa4743ee6'),
    (Path('/root/hyle-scratch/http2-current-20261018/small-headers/http2.o'), 224840, '49ccfa8eacb0a7c81a1ab70a4ccb640b24c176820bce9bc2469ca3e5aa9dbc2a'),
    (Path('/root/hyle-scratch/http2-current-20261018/small-headers/http2_test.o'), 689960, 'd2a7f2d71cebd556ed733f1912942e3dc9c7a2fec9b25aa8aa24aec6da87783a'),
    (Path('/root/hyle-scratch/http2-current-20261018/dead-submit-final/tests'), 1559496, '80b9e558b8963e58d08da905006b0bf49041dc951c2c28d986a1613807e425e8'),
]
retained = [
    (Path('/root/hyle-scratch/http2-current-20261018/small-headers-timing/consumer.o'), 113632, '1c6dc5ff898f3f1f0ad79b124ab6e5b1700e15a006964e4d9113a8f1a373e418'),
    (Path('/root/hyle-scratch/http2-current-20261018/dead-submit-final/http2.o'), 224784, '90fb3ebf7e71a9ee74789aaec62866c08c931a0b96413994aa532a5cb9d99302'),
    (Path('/root/hyle-scratch/http2-current-20261018/current-holdout/libhyle_io_core.so.0.1.0'), 387104, '9ead235b1bbd72f56d44eab9c8ac135b8c4b0ce0ec0a6fb72660aa917d3b4779'),
    (Path('/root/hyle-scratch/http2-current-20261018/header-lifetime/http2_test.o'), 654624, 'debb22bed71cd36bbda594158905dc547ca59655ed62c81f8b4a42c0431f75d3'),
]
assert root.resolve(strict=True) == root
assert len({x[0] for x in targets + retained}) == 10
assert sum(x[1] for x in targets) == 4438200

def inspect(item):
    path, size, expected_sha = item
    assert path.is_absolute() and path.is_relative_to(Path('/root/hyle-scratch/http2-current-20261018'))
    current = Path(path.anchor)
    for part in path.parts[1:]:
        current /= part
        assert not stat.S_ISLNK(current.lstat().st_mode), str(current)
    assert path.resolve(strict=True) == path
    before = path.lstat()
    assert stat.S_ISREG(before.st_mode) and before.st_size == size
    with os.fdopen(os.open(path, os.O_RDONLY | os.O_NOFOLLOW), 'rb') as stream:
        opened = os.fstat(stream.fileno())
        assert (opened.st_dev, opened.st_ino) == (before.st_dev, before.st_ino)
        digest = hashlib.sha256(stream.read()).hexdigest()
        after = os.fstat(stream.fileno())
    current = path.lstat()
    assert digest == expected_sha and after.st_size == size
    assert (current.st_dev, current.st_ino, current.st_size) == (after.st_dev, after.st_ino, after.st_size)
    return current.st_dev, current.st_ino

identities = {x[0]: inspect(x) for x in targets + retained}
for proc in Path('/proc').iterdir():
    if not proc.name.isdigit():
        continue
    try:
        executable = os.readlink(proc / 'exe')
    except (OSError, PermissionError):
        continue
    assert executable not in {str(x[0]) for x in targets}, 'Target executable still running: ' + proc.name
print(json.dumps({'preflight_files': 10, 'delete_files': 6, 'delete_bytes': 4438200, 'retain_files': 4}), flush=True)
for item in targets:
    assert item[0].is_relative_to(root)
    assert inspect(item) == identities[item[0]]
    item[0].unlink()
    print('Deleted exact generated file: ' + str(item[0]), flush=True)
for item in retained:
    assert inspect(item) == identities[item[0]]
print(json.dumps({'status': 'completed', 'deleted_files': 6, 'deleted_bytes': 4438200, 'retained_cache_files_verified': 4, 'directories_removed': 0}), flush=True)
'@
$payload = [Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes($pythonSource))
$code = 'import base64;exec(base64.b64decode("' + $payload + '"))'
& wsl.exe -d Ubuntu-24.04 -u root --exec python3 -c $code
if ($LASTEXITCODE -ne 0) { throw "Exact WSL cleanup failed: $LASTEXITCODE" }

