from pathlib import Path
import hashlib,json,os,subprocess,time
ROOT=Path('/mnt/c/public/project-hyle/hyle')
HERE=ROOT/'.scratch/perf-review-2026-10-18/http2/profile'
BASE=Path('/root/hyle-scratch/http2-current-20261018')
BUILD=BASE/'profile';BUILD.mkdir(exist_ok=True)
old=json.loads((HERE.parent/'build-commands.json').read_text())
records=[]
def run(name,argv,env=None):
 begin=time.time()
 p=subprocess.run([str(x) for x in argv],cwd=BUILD,env=env,capture_output=True,text=True,timeout=60)
 (HERE/(name+'.stdout.txt')).write_text(p.stdout)
 (HERE/(name+'.stderr.txt')).write_text(p.stderr)
 records.append({'name':name,'argv':[str(x) for x in argv],'exit':p.returncode,'end_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'elapsed_seconds':time.time()-begin})
 (HERE/'seam-commands.json').write_text(json.dumps(records,indent=2))
 print(name,p.returncode,flush=True)
 if p.returncode:print(p.stdout[-2000:],p.stderr[-2000:]);raise SystemExit(p.returncode)
 return p.stdout
for key,src,dest in [('src_io_http2_http2.cc',ROOT/'src/io_http2/http2.cc',BUILD/'seam-http2.o'),('bench_io_http2_http2_p1_bench.cc',HERE/'bench-profiled.cc',BUILD/'readwrite.o'),('bench_io_http2_http2_p1_bench.cc',ROOT/'bench/io_http2/http2_p1_bench.cc',BUILD/'sendrecv.o')]:
 cmd=next(x['argv'] for x in old if x['name']==key)
 run('seam-compile-'+dest.stem,cmd[:-4]+['-c',src,'-o',dest])
link=next(x['argv'] for x in old if x['name']=='link')
for variant in ['readwrite','sendrecv']:
 cmd=[str(BUILD/variant) if x.endswith('/http2_current') else str(BUILD/'seam-http2.o') if x.endswith('/src_io_http2_http2.cc.o') else str(BUILD/(variant+'.o')) if x.endswith('/bench_io_http2_http2_p1_bench.cc.o') else x for x in link]
 run('seam-link-'+variant,cmd)
 env={k:v for k,v in os.environ.items() if not k.startswith('HYLE_BENCH_')}
 env['HYLE_BENCH_SMOKE']='1'
 run('seam-smoke-'+variant,['taskset','-c','2',BUILD/variant],env)
identity={'scope':'Matched libc socket seam only; product HTTP2 unchanged. Same freshly rebuilt current HTTP2 object and cached HTTP/feature/foundation for both executables. Not a full HEAD build.',
 'sources':{str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [ROOT/'src/io_http2/http2.cc',ROOT/'bench/io_http2/http2_p1_bench.cc',HERE/'bench-profiled.cc',ROOT/'include/hyle/container/detail/flat_hash_table.h']},
 'binaries':{v:hashlib.sha256((BUILD/v).read_bytes()).hexdigest() for v in ['readwrite','sendrecv']}}
(HERE/'seam-identity.json').write_text(json.dumps(identity,indent=2))
for index,(variant,peer_first) in enumerate([('readwrite',False),('sendrecv',True),('sendrecv',False),('readwrite',True)]):
 name=f'seam-formal-{index}-{variant}'
 env={k:v for k,v in os.environ.items() if not k.startswith('HYLE_BENCH_')}
 env['HYLE_BENCH_JSON']=str(HERE/name)
 if peer_first:env['HYLE_BENCH_RIVAL_FIRST']='1'
 run(name,['taskset','-c','2',BUILD/variant],env)
