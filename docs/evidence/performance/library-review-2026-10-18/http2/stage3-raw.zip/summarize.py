from pathlib import Path
import hashlib, json, statistics, subprocess, zipfile

root = Path('/mnt/c/public/project-hyle/hyle')
here = root / '.scratch/perf-review-2026-10-18/http2/profile'
build = Path('/root/hyle-scratch/http2-current-20261018/profile')
out = root / 'evidence/performance/library-review-2026-10-18/http2'
points = []
for path in sorted(here.glob('seam-formal-*.json')):
    data = json.loads(path.read_text())
    arms = {}
    for result in data['results']:
        measurements = result['measurements']
        arm = 'hyle' if result['name'].startswith('HYLE') else 'peer'
        arms[arm] = {
            'ns_per_stream': statistics.median(x['elapsed'] for x in measurements) * 1e9 / result['batch'],
            'epoch_MAPE': result['medianAbsolutePercentError(elapsed)'],
            'minimum_actual_epoch_seconds': min(x['elapsed'] * x['iterations'] for x in measurements),
            'empirical_clock_resolution_seconds': result['clockResolution'],
            'epochs': len(measurements),
        }
    points.append({'file': path.name, 'order': [r['name'] for r in data['results']],
                   'arms': arms,
                   'hyle_slower_percent': 100 * (arms['hyle']['ns_per_stream'] / arms['peer']['ns_per_stream'] - 1)})

locations = {
    '/usr/lib/x86_64-linux-gnu/libc.so.6': ['0x189087','0x1887ca','0x12beaa','0x12c18a','0x11c87d','0x11bd6a','0x986e1'],
    '/root/hyle-scratch/io-watch-v2-dev/bin/libhyle_sched.so.0.1.0': ['0x1413f'],
    str(build / 'consumer'): ['0x35640','0x492d7','0x6cb06','0x6dacd'],
}
resolved = []
for image, addresses in locations.items():
    command = ['addr2line', '-f', '-C', '-e', image] + addresses
    process = subprocess.run(command, capture_output=True, text=True)
    resolved.append({'image': image, 'sha256': hashlib.sha256(Path(image).read_bytes()).hexdigest(),
                     'argv': command, 'exit': process.returncode,
                     'stdout': process.stdout, 'stderr': process.stderr})
(here / 'leaf-symbol-resolution.json').write_text(json.dumps(resolved, indent=2) + '\n')

summary = {
    'change': 'Peer socket calls now match TcpStream immediate seam: recv(MSG_DONTWAIT), send(MSG_DONTWAIT|MSG_NOSIGNAL where defined), same EINTR retry and all protocol/cleanup work. Product HTTP2 unchanged.',
    'formal_schedule': 'Fixed four processes only: old read/write Hyle-first, matched send/recv peer-first, matched send/recv Hyle-first, old read/write peer-first. Same fresh unprofiled HTTP2 object, old cached HTTP/feature/foundation, taskset CPU2. Both persistent harness workers present, one route active. Nine epochs per arm, at least five complete episodes per epoch, no trimming or correction by A/A.',
    'points': points,
    'conclusion': 'The original 4x256KiB Hyle loss remains after matching the socket seam. Two matched points are slower by about13-15%; this is not a stable universal percentage. Peer absolute time changes along with the libc seam; unchanged Hyle also varies. Small body still faster in this narrow workload. Do not claim the seam explained or solved the product residual.',
    'clock': 'Raw min epoch windows are milliseconds and empirical resolution12-16ns. Counter fields zero mean unavailable, not no CPU work. Process and order drift are not clock quantization.',
    'sampling': {
        'work': '1000 complete holdout episodes per active route, same payload/header/flow-control/oracle/socket/session cleanup, one process per route. Instrumented profiles are separate from formal ranking.',
        'command': 'perf record -e cpu-clock:u -F997 --call-graph dwarf,4096; taskset -c2',
        'samples': {'hyle':322,'peer':273}, 'lost_samples':0,
        'limitation': 'Hardware PMU cycles/instructions unsupported. Installed minimal perf lacks libelf, libdw/libunwind and DWARF unwind; report/script provide leaf IPs only. addr2line resolves selected existing-image addresses independently but cannot recover parent stacks. No attribution of total gap to fibers, notify, memcpy or syscall percentages; no stack claim or profiler-time latency ranking.',
        'leaf_findings': 'Selected leafs resolve to libc memcpy/recv/send for Hyle and memcpy/read/write for peer, motivating syscall seam alignment. Source counters already showed equal body-copy bytes and no compaction; different memcpy sample percentages alone do not imply extra copied bytes.',
    },
    'scope': 'Linux WSL GCC14.2 and existing locked nghttp2 1.70/foundation cache; related TUs only. No full HEAD/native rebuild, SDK copy, Mac/Windows HTTP2 run or new product optimization. The two same-source binaries and profiling binary are rebuildable and not retained in the evidence ZIP.',
}
(here / 'stage3-summary.json').write_text(json.dumps(summary, indent=2) + '\n')
(out / 'stage3-summary.json').write_bytes((here / 'stage3-summary.json').read_bytes())
archive = out / 'stage3-raw.zip'
files = [p for p in here.iterdir() if p.is_file() and p.name != 'stage3-raw.zip']
with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for path in sorted(files): z.write(path, path.name)
    for route in ['hyle','peer']: z.write(build / (route+'.data'), 'perf/'+route+'.data')
    for name in ['build-commands.json','build-identity.json','resources-source-identity.json']:
        z.write(here.parent / name, 'prior-cache-identity/'+name)
    z.write(root / 'bench/io_http2/http2_p1_bench.cc', 'product/http2_p1_bench.cc')
    z.write(root / 'src/io_http2/http2.cc', 'product/http2.cc')
    z.write(root / 'src/io_core/tcp.cc', 'product/tcp.cc')
record = {'path':str(archive.relative_to(root)), 'bytes':archive.stat().st_size,
          'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),
          'members':len(zipfile.ZipFile(archive).namelist()),'binaries_included':False}
(out / 'stage3-archive-record.json').write_text(json.dumps(record,indent=2)+'\n')
cleanup = []
for name in ['http2.o','profile.o','consumer','seam-http2.o','readwrite.o','sendrecv.o','readwrite','sendrecv']:
    path = build / name
    cleanup.append({'path':str(path),'bytes':path.stat().st_size,'sha256':hashlib.sha256(path.read_bytes()).hexdigest()})
(here / 'rebuildable-files.json').write_text(json.dumps({'scope':'Only this profile/seam batch images and objects, all processes ended. Preserve original cached objects/libraries, sources/logs and perf raw data.', 'paths':cleanup},indent=2)+'\n')
print(json.dumps({'archive':record,'results':[(p['file'],p['hyle_slower_percent']) for p in points], 'cleanup_bytes':sum(p['bytes'] for p in cleanup)},indent=2))
