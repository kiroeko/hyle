from pathlib import Path
import hashlib,json,os,subprocess,sys
ROOT=Path('/mnt/c/public/project-hyle/hyle')
HERE=ROOT/'.scratch/perf-review-2026-10-18/http2/profile'
BASE=Path('/root/hyle-scratch/http2-current-20261018')
BUILD=BASE/'profile';BUILD.mkdir(exist_ok=True)
old=json.loads((HERE.parent/'build-commands.json').read_text())
records=[]
def run(name,argv):
 p=subprocess.run([str(x) for x in argv],cwd=BUILD,capture_output=True,text=True,timeout=60)
 (HERE/(name+'.stdout.txt')).write_text(p.stdout)
 (HERE/(name+'.stderr.txt')).write_text(p.stderr)
 records.append({'name':name,'argv':[str(x) for x in argv],'exit':p.returncode})
 (HERE/'commands.json').write_text(json.dumps(records,indent=2))
 print(name,p.returncode,flush=True)
 if p.returncode:print(p.stdout[-2000:],p.stderr[-2000:]);raise SystemExit(p.returncode)
 return p.stdout
for key,src,dest in [('src_io_http2_http2.cc',ROOT/'src/io_http2/http2.cc',BUILD/'http2.o'),('bench_io_http2_http2_p1_bench.cc',HERE/'profile.cc',BUILD/'profile.o')]:
 cmd=next(x['argv'] for x in old if x['name']==key)
 run('compile-'+dest.stem,cmd[:-4]+['-g1','-fno-omit-frame-pointer','-c',src,'-o',dest])
link=next(x['argv'] for x in old if x['name']=='link')
link=[str(BUILD/'consumer') if x.endswith('/http2_current') else str(BUILD/'http2.o') if x.endswith('/src_io_http2_http2.cc.o') else str(BUILD/'profile.o') if x.endswith('/bench_io_http2_http2_p1_bench.cc.o') else x for x in link]
run('link',link)
for route in ['hyle','peer']:
 run('smoke-'+route,['taskset','-c','2',BUILD/'consumer',route,'1'])
 run('profile-'+route,['perf','record','-e','cpu-clock:u','-F','997','--call-graph','dwarf,4096','-o',BUILD/(route+'.data'),'--','taskset','-c','2',BUILD/'consumer',route,'1000'])
 output=run('report-'+route,['perf','report','-i',BUILD/(route+'.data'),'--stdio','--no-children','--percent-limit','1','--sort','dso,symbol','--call-graph','none'])
 print(output[:7000])
identity={'scope':'CPU sampling diagnosis only; profiler changes execution. Not latency ranking or full HEAD rebuild. Fresh HTTP2/probe TUs use current public headers, old frozen HTTP/feature/pico/nanobench objects and original foundation cache.',
 'source_hashes':{str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [ROOT/'src/io_http2/http2.cc',ROOT/'bench/io_http2/http2_p1_bench.cc',ROOT/'include/hyle/container/detail/flat_hash_table.h',HERE/'profile.cc']},
 'binary_sha256':hashlib.sha256((BUILD/'consumer').read_bytes()).hexdigest(),'perf_version':subprocess.check_output(['perf','--version'],text=True),'records':records}
(HERE/'identity.json').write_text(json.dumps(identity,indent=2))
