#define main original_benchmark_main
#include "../../../../bench/io_http2/http2_p1_bench.cc"
#undef main

int main(int argc, char **argv) {
  std::signal(SIGPIPE, SIG_IGN);
  if (argc != 3) return 2;
  const std::string_view route(argv[1]);
  if (route != "hyle" && route != "peer") return 2;
  const int rounds = std::atoi(argv[2]);
  if (rounds <= 0 || rounds > 10000) return 2;
  const auto workload = make_workload("profile holdout", 4, 256 * 1024,
      256 * 1024, NGHTTP2_INITIAL_CONNECTION_WINDOW_SIZE);
  HyleHarness hyle;
  RawHarness peer;
  for (int round = 0; round < rounds; ++round) {
    const int completed = route == "hyle" ? hyle.run(workload) : peer.run(workload);
    if (completed != 4) return 3;
  }
  std::printf("{\"route\":\"%s\",\"episodes\":%d,\"streams_per_episode\":4,\"all_oracles_passed\":true}\n",
      argv[1], rounds);
}
