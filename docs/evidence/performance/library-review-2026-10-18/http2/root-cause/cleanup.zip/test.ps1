# One-time exact cleanup after HTTP2 root-cause diagnosis; keep current useful caches.
# Preserve source, logs, raw samples, maps, archives and shared caches.
$ErrorActionPreference = 'Stop'
$archive = Join-Path $PSScriptRoot 'docs/evidence/performance/library-review-2026-10-18/http2/root-cause/source-results.zip'
if ((Get-FileHash -LiteralPath $archive -Algorithm SHA256).Hash.ToLowerInvariant() -ne 'da8b01ae80532e0aaab173f63475e8813090a5f586d31c96f9be7d1ab0b1572f') { throw 'Frozen evidence archive mismatch' }
$pythonSource = @'
import hashlib, json, os, stat
from pathlib import Path

root = Path('/root/hyle-scratch/http2-current-20261018')
targets = [
    (Path('/root/hyle-scratch/http2-current-20261018/root-cause/consumer.o'), 153064, '79152caba6296f679434549cbf471f95ee7bc0397cfa5415059e9d09d5ac54d5'),
    (Path('/root/hyle-scratch/http2-current-20261018/root-cause/profile-consumer'), 900720, '93cae1b4f4de9e42acde791dfe6112a977e7a3325ab5743e587d5a1e0b5d008f'),
    (Path('/root/hyle-scratch/http2-current-20261018/root-cause-alloc/new'), 901152, 'e5ca6dff6d71131be63fb78a13a1b84c3c40d25f726f59fd7593963d009a423b'),
    (Path('/root/hyle-scratch/http2-current-20261018/root-cause-alloc/new.o'), 154240, '78efd0810df52cd333034ff9c90489dca1ca0291bec62cbfeb022ddb33cacb0f'),
    (Path('/root/hyle-scratch/http2-current-20261018/root-cause-alloc/old'), 902016, 'dbf63273b2272e45c848a5ad9447f0351dd56d9aca313d1608701175077e3ae4'),
    (Path('/root/hyle-scratch/http2-current-20261018/root-cause-alloc/old.o'), 157328, '23919ce270c029fc2d6ccaa50369fabd45eb4c8e9da0bb1c48bd68b52dc8e405'),
    (Path('/root/hyle-scratch/http2-current-20261018/root-cause-product/allocation-resume-new'), 901448, '6aaa604f1c011507587f73a1316b0abca360e4696e0bd1eb89e8a723cc3d61f6'),
    (Path('/root/hyle-scratch/http2-current-20261018/root-cause-product/allocation-resume-old'), 901464, 'a473ca69ecdbccb045c929cea506f44d4d7cdef77e97ecc3691a9cb61555b463'),
    (Path('/root/hyle-scratch/http2-current-20261018/root-cause-product/candidate'), 897640, '8bcd1cc8791fe17a506ea517db8619e07a4fdf506a95126a6d8fc1bd435def54'),
    (Path('/root/hyle-scratch/http2-current-20261018/root-cause-product/control'), 897656, '0cd420db0dd5870d6d7f1ed3a2cc1dddc7539e3d62b1a12644b8e7698f25a647'),
    (Path('/root/hyle-scratch/http2-current-20261018/root-cause-product/http2.o'), 224664, 'd662c9111c048c4dd37f3b3f61755bbe9f3cbedac0913b6d6e490d58b9515595'),
    (Path('/root/hyle-scratch/http2-current-20261018/root-cause-product/resume-probe.o'), 3616, 'd35f80652a86df480f640405d5eba11feae8be0d01f05aeab4373bb53e5c034c'),
    (Path('/root/hyle-scratch/http2-current-20261018/root-cause-product/tests-candidate'), 1588880, '166b5daec7eff898db29879522279556e390c6ec6fe0c997d5991e01525dcfba'),
    (Path('/root/hyle-scratch/http2-current-20261018/root-cause-product/tests-control'), 1588888, '037dce0c752a8debe5236e0da3c70a0c8b84a815875f7691b189886f6e5c1d09'),
    (Path('/root/hyle-scratch/http2-current-20261018/root-cause-notify/after.o'), 227056, '853d75adffb1e3478c616f536c1f77f92b35f9f07629acd8f016d77333558843'),
    (Path('/root/hyle-scratch/http2-current-20261018/root-cause-notify/before.o'), 227168, '79214f032c6adb9321f0eba4c962eb35ae03d4384869e9fe2a6e0ff3cc7667d3'),
    (Path('/root/hyle-scratch/http2-current-20261018/root-cause-notify/diagnostic-after'), 901400, '8ac65af9d8bfb314d55bdae48c590cc4314adf2fbb596dc24eac064e1b835037'),
    (Path('/root/hyle-scratch/http2-current-20261018/root-cause-notify/diagnostic-before'), 901400, '18ad385c24533a9a4d0232222d06e670445adf87d54601bacd45798fee531a8e'),
    (Path('/root/hyle-scratch/http2-current-20261018/root-cause-notify/report.o'), 3312, '83c4508ae14353dcd3d3e251191c5a247af11466a9163bf36b31726d1d9b9d40'),
    (Path('/root/hyle-scratch/http2-current-20261018/dead-submit-final/http2.o'), 224784, '90fb3ebf7e71a9ee74789aaec62866c08c931a0b96413994aa532a5cb9d99302'),
    (Path('/root/hyle-scratch/http2-current-20261018/header-lifetime/http2_test.o'), 654624, 'debb22bed71cd36bbda594158905dc547ca59655ed62c81f8b4a42c0431f75d3'),
    (Path('/root/hyle-scratch/http2-current-20261018/paired-comparison-v2/consumer.o'), 154208, 'bc2d83d4d00f28cfa136e7e4c466aadba5a4680ceb57f3f1ea1ab56a56388a06'),
]
retained = [
    (Path('/root/hyle-scratch/http2-current-20261018/current-holdout/libhyle_io_core.so.0.1.0'), 387104, '9ead235b1bbd72f56d44eab9c8ac135b8c4b0ce0ec0a6fb72660aa917d3b4779'),
    (Path('/root/hyle-scratch/http2-current-20261018/paired-comparison-v2/nanobench.o'), 283672, '43b16d764541dc1460c6aba273360f40403bcc35ee2feb37461f7f4d29984987'),
    (Path('/root/hyle-scratch/http2-current-20261018/root-cause-notify/candidate'), 897640, '99feb9f6429b7a5e5631091b0800ad2ccac8bdb19e8a3e6126c36e0e61c99c2b'),
    (Path('/root/hyle-scratch/http2-current-20261018/root-cause-notify/http2.o'), 224576, '91086705edabe231dc952bf2c6cb40fc9d1a13e2ca5eb5128f8ffaed405b5e62'),
    (Path('/root/hyle-scratch/http2-current-20261018/root-cause-notify/tests'), 1588880, '3f50e4b0ec733f62ef8c4b5f50b88f0b0b69180e2d4d2957a79aec5ab4e7d464'),
    (Path('/root/hyle-scratch/http2-current-20261018/root-cause-product/consumer.o'), 151104, '62a132158e443d6fae3df9c9ea8b4ccba19e71a21aeac9ffef6042d03df5b2b2'),
    (Path('/root/hyle-scratch/http2-current-20261018/root-cause-product/http2_test.o'), 697832, 'e0aac0c23d5c6666a7d23c9b57521f4844bada7b6717dec4a57d29d821badab1'),
]
assert root.resolve(strict=True) == root
assert len({x[0] for x in targets + retained}) == 29
assert sum(x[1] for x in targets) == 13466728

def inspect(item):
    path, size, expected_sha = item
    assert path.is_absolute() and path.is_relative_to(Path('/root/hyle-scratch/http2-current-20261018'))
    current = Path(path.anchor)
    for part in path.parts[1:]:
        current /= part
        assert not stat.S_ISLNK(current.lstat().st_mode), str(current)
    assert path.resolve(strict=True) == path
    before = path.lstat()
    assert stat.S_ISREG(before.st_mode) and before.st_size == size
    with os.fdopen(os.open(path, os.O_RDONLY | os.O_NOFOLLOW), 'rb') as stream:
        opened = os.fstat(stream.fileno())
        assert (opened.st_dev, opened.st_ino) == (before.st_dev, before.st_ino)
        digest = hashlib.sha256(stream.read()).hexdigest()
        after = os.fstat(stream.fileno())
    current = path.lstat()
    assert digest == expected_sha and after.st_size == size
    assert (current.st_dev, current.st_ino, current.st_size) == (after.st_dev, after.st_ino, after.st_size)
    return current.st_dev, current.st_ino

identities = {x[0]: inspect(x) for x in targets + retained}
for proc in Path('/proc').iterdir():
    if not proc.name.isdigit():
        continue
    try:
        executable = os.readlink(proc / 'exe')
    except (OSError, PermissionError):
        continue
    assert executable not in {str(x[0]) for x in targets}, 'Target executable still running: ' + proc.name
print(json.dumps({'preflight_files': 29, 'delete_files': 22, 'delete_bytes': 13466728, 'retain_files': 7}), flush=True)
for item in targets:
    assert item[0].is_relative_to(root)
    assert inspect(item) == identities[item[0]]
    item[0].unlink()
    print('Deleted exact generated file: ' + str(item[0]), flush=True)
for item in retained:
    assert inspect(item) == identities[item[0]]
print(json.dumps({'status': 'completed', 'deleted_files': 22, 'deleted_bytes': 13466728, 'retained_cache_files_verified': 7, 'directories_removed': 0}), flush=True)
'@
$payload = [Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes($pythonSource))
$code = 'import base64;exec(base64.b64decode("' + $payload + '"))'
& wsl.exe -d Ubuntu-24.04 -u root --exec python3 -c $code
if ($LASTEXITCODE -ne 0) { throw "Exact WSL cleanup failed: $LASTEXITCODE" }

