import hashlib
import json
import os
from pathlib import Path
import subprocess

root = Path('/mnt/c/public/project-hyle/hyle')
out = root / '.scratch/perf-review-2026-10-18/http2-root-cause'
build = Path('/root/hyle-scratch/http2-current-20261018/root-cause-alloc')
build.mkdir(exist_ok=False)
base = json.loads((root / '.scratch/perf-review-2026-10-18/http2-paired-run/attempt-2/build.json').read_text())
flags = next(c['argv'] for c in base['commands'] if c['name'] == 'compile-consumer')
flags = flags[:flags.index('-c')]
old_link = next(c['argv'] for c in base['commands'] if c['name'] == 'link')
env = os.environ.copy()
env['LD_LIBRARY_PATH'] = base['environment']['LD_LIBRARY_PATH']
prefix = r'''
#include <atomic>
#include "hyle/mem/allocator.h"
static std::atomic<bool> counting{false};
static std::atomic<unsigned long long> alloc_calls{0}, realloc_calls{0}, request_bytes{0};
static void *probe_alloc(void *, std::size_t size, std::size_t align) noexcept {
  if (counting) { ++alloc_calls; request_bytes += size; }
  return hyle::mem::system_allocator().allocate(size, align);
}
static void probe_free(void *, void *p, std::size_t size, std::size_t align) noexcept {
  hyle::mem::system_allocator().deallocate(p, size, align);
}
static void *probe_realloc(void *, void *p, std::size_t old_size, std::size_t size, std::size_t align) noexcept {
  if (counting) { ++realloc_calls; request_bytes += size; }
  return hyle::mem::system_allocator().reallocate(p, old_size, size, align);
}
static hyle::mem::AllocatorRef counting_allocator() noexcept {
  return {probe_alloc, probe_free, probe_realloc, nullptr};
}
'''
suffix = r'''
int main() {
  std::signal(SIGPIPE, SIG_IGN);
  HyleHarness harness;
  const auto workload = make_workload("allocation diagnostic", 4, 256*1024, 256*1024,
                                      NGHTTP2_INITIAL_CONNECTION_WINDOW_SIZE);
  for (int warm = 0; warm != 16; ++warm)
    if (harness.run(workload) != 4) return 2;
  for (int episode = 0; episode != 4; ++episode) {
    alloc_calls = 0; realloc_calls = 0; request_bytes = 0;
    counting = true;
    const int result = harness.run(workload);
    counting = false;
    std::printf("{\"episode\":%d,\"valid\":%s,\"allocate_calls\":%llu,\"reallocate_calls\":%llu,\"request_bytes\":%llu}\n",
      episode, result == 4 ? "true" : "false", alloc_calls.load(), realloc_calls.load(), request_bytes.load());
    if (result != 4) return 2;
  }
}
'''
commands = []
for label, source in [('old', out / 'bench.before.cc'), ('new', root / 'bench/io_http2/http2_p1_bench.cc')]:
    modified = prefix + source.read_text().replace('system_allocator()', 'counting_allocator()').replace('int main(', 'int legacy_main(') + suffix
    path = out / ('allocation-' + label + '.cc')
    path.write_text(modified)
    compile_cmd = flags + ['-c', str(path), '-o', str(build / (label + '.o'))]
    mapping = {
        '/root/hyle-scratch/http2-current-20261018/paired-comparison-v2/paired-bench': str(build / label),
        '-Wl,-Map,/root/hyle-scratch/http2-current-20261018/paired-comparison-v2/paired-bench.map': '-Wl,-Map,' + str(build / (label + '.map')),
        '/root/hyle-scratch/http2-current-20261018/paired-comparison-v2/consumer.o': str(build / (label + '.o')),
    }
    for name, argv in [(label + '-compile', compile_cmd), (label + '-link', [mapping.get(x, x) for x in old_link]),
                       (label + '-diagnostic', ['taskset', '-c', '2', str(build / label)])]:
        print(name, flush=True)
        result = subprocess.run(argv, cwd=build, env=env, capture_output=True, timeout=60)
        (out / (name + '.stdout.txt')).write_bytes(result.stdout)
        (out / (name + '.stderr.txt')).write_bytes(result.stderr)
        commands.append({'name': name, 'argv': argv, 'returncode': result.returncode})
        (out / 'allocation-commands.json').write_text(json.dumps(commands, indent=2) + '\n')
        if result.returncode:
            print(result.stderr.decode(errors='replace'), flush=True)
            raise SystemExit(result.returncode)
        if name.endswith('diagnostic'):
            print(result.stdout.decode(), flush=True)
