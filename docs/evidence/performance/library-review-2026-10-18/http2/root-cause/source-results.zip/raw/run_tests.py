import json
import hashlib
import os
from pathlib import Path
import subprocess

root = Path('/mnt/c/public/project-hyle/hyle')
out = root / '.scratch/perf-review-2026-10-18/http2-root-cause'
build = Path('/root/hyle-scratch/http2-current-20261018/root-cause-product')
prior = json.loads((root / '.scratch/perf-review-2026-10-18/http2/header-lifetime/commands.json').read_text())
env = dict(os.environ, LD_LIBRARY_PATH='/root/hyle-scratch/http2-current-20261018/current-holdout:/root/hyle-scratch/io-watch-v2-dev/bin')
commands = []
def execute(name, argv, expected=0, changes=None):
    print(name, flush=True)
    result = subprocess.run(argv, cwd=build, env=dict(env, **(changes or {})), capture_output=True, timeout=60)
    (out / ('guarded-' + name + '.stdout.txt')).write_bytes(result.stdout)
    (out / ('guarded-' + name + '.stderr.txt')).write_bytes(result.stderr)
    commands.append({'name': name, 'argv': argv, 'returncode': result.returncode, 'expected': expected, 'environment_changes': changes or {}})
    (out / 'guarded-test-commands.json').write_text(json.dumps(commands, indent=2) + '\n')
    print(result.stdout.decode(errors='replace'), result.stderr.decode(errors='replace'), flush=True)
    if result.returncode != expected:
        raise SystemExit(1)

(out / 'guarded-test-source.sha256').write_text(hashlib.sha256((root / 'tests/io_http2/http2_test.cc').read_bytes()).hexdigest() + '\n')
argv = next(c['argv'] for c in prior if c['name'] == 'compile-tests')
mapping = {
    '/mnt/c/public/project-hyle/hyle/.scratch/perf-review-2026-10-18/http2/header-lifetime/http2_test.cc': str(root / 'tests/io_http2/http2_test.cc'),
    '/root/hyle-scratch/http2-current-20261018/header-lifetime/http2_test.o': str(build / 'http2_test.o'),
}
execute('compile-tests', [mapping.get(x, x) for x in argv[:argv.index('-c')]] +
        ['-Wall', '-Wextra', '-Wpedantic', '-Werror'] + [mapping.get(x, x) for x in argv[argv.index('-c'):]])
old_link = next(c['argv'] for c in prior if c['name'] == 'link-tests')
for label, product in [('control', '/root/hyle-scratch/http2-current-20261018/dead-submit-final/http2.o'),
                       ('candidate', str(build / 'http2.o'))]:
    mapping.update({'/root/hyle-scratch/http2-current-20261018/header-lifetime/http2.o': product,
                    '/root/hyle-scratch/http2-current-20261018/header-lifetime/tests': str(build / ('tests-' + label))})
    execute('link-tests-' + label, [mapping.get(x, x) for x in old_link])
execute('control-new-regression', [str(build / 'tests-control'), '--gtest_filter=IoHttp2.TrailerSlotOomIsStreamLocalAndSessionRemainsUsable'], expected=1)
execute('candidate-all-default', [str(build / 'tests-candidate')])
execute('candidate-all-epoll', [str(build / 'tests-candidate')], changes={'HYLE_IO_FORCE_EPOLL': '1'})
