"""Resolve already-recorded leaf DSO offsets; never runs the consumer."""
from collections import Counter, defaultdict
import json
from pathlib import Path
import re
import subprocess

HERE = Path(__file__).resolve().parent
BASE = Path('/root/hyle-scratch/http2-current-20261018/root-cause')
images = {'profile-consumer': BASE / 'profile-consumer'}
for line in (HERE / 'ldd.stdout.txt').read_text().splitlines():
    match = re.match(r'\s*(\S+)\s+=>\s+(/\S+)', line)
    if match:
        images[match[1]] = Path(match[2])
    else:
        match = re.match(r'\s*(/\S+)', line)
        if match:
            images[Path(match[1]).name] = Path(match[1])
commands, result = [], {}
for arm in ('hyle', 'reference'):
    report = (HERE / ('leaf-report-' + arm + '.stdout.txt')).read_text()
    total = int(re.search(r'# Samples: (\d+)', report)[1])
    lost = int(re.search(r'# Total Lost Samples: (\d+)', report)[1])
    rows, by_image = [], defaultdict(set)
    for line in report.splitlines():
        match = re.match(r'\s*([\d.]+)%\s+(\d+)\s+(\S+)\s+\[\.\]\s+(0x[0-9a-f]+)', line)
        if not match:
            continue
        row = dict(samples=int(match[2]), image=match[3], elf_offset=match[4])
        rows.append(row)
        by_image[row['image']].add(row['elf_offset'])
    assert sum(row['samples'] for row in rows) == total
    symbols = {}
    for image, offsets in by_image.items():
        if image not in images:
            continue
        offsets = sorted(offsets, key=lambda value: int(value, 16))
        command = ['addr2line', '-f', '-C', '-e', str(images[image]), *offsets]
        process = subprocess.run(command, capture_output=True, text=True, timeout=15)
        commands.append(dict(argv=command, returncode=process.returncode, stderr=process.stderr))
        lines = process.stdout.splitlines()
        assert process.returncode == 0 and len(lines) == 2 * len(offsets)
        for index, offset in enumerate(offsets):
            symbols[image, offset] = (lines[index * 2], lines[index * 2 + 1])
    leaves, own, allocators, notifications = Counter(), Counter(), Counter(), Counter()
    for row in rows:
        row['function'], row['source_line'] = symbols.get(
            (row['image'], row['elf_offset']), ('??', '??:0'))
        leaves[row['function']] += row['samples']
        if row['function'].startswith('hyle::'):
            own[row['function']] += row['samples']
        if re.search(r'(^|::)(?:_?mi_\w+|__libc_(?:malloc|calloc|realloc|free)|'
                     r'h2_(?:malloc|calloc|realloc|free)|system_(?:alloc|realloc|dealloc))'
                     r'(?:\(|$|\.)|operator (?:new|delete)', row['function']):
            allocators[row['function']] += row['samples']
        if any(word in row['function'].lower() for word in ('notify', 'condition', 'check_operation')):
            notifications[row['function']] += row['samples']
    result[arm] = dict(samples=total, lost=lost, rows=rows,
                       leaf_samples=leaves.most_common(), hyle_leaf_samples=own.most_common(),
                       allocator_named_leaf_samples=allocators.most_common(),
                       notify_condition_check_named_leaf_samples=notifications.most_common())
result['limits'] = [
    'perf lacks libelf; original reports retain raw offsets. addr2line resolves matching existing ELF DSO offsets offline.',
    'Leaf samples only, no callgraph; optimized inline work is attributed to its enclosing symbol.',
    'Only649/634 samples; no comparative percentage subtraction, exact latency decomposition, or zero-cost inference from absent symbols.',
    'Name-based allocator/notification lists are incomplete classifications, not exhaustive cost totals.',
    'Current task-clock profile uses the frozen cached product executable; no new product objects or profiler rebuild.']
(HERE / 'leaf-symbols.json').write_text(json.dumps(result, indent=2) + '\n')
(HERE / 'leaf-symbolize-commands.json').write_text(json.dumps(commands, indent=2) + '\n')
for arm in ('hyle', 'reference'):
    print(json.dumps({arm: {key: result[arm][key][:18] for key in
          ('leaf_samples', 'hyle_leaf_samples', 'allocator_named_leaf_samples',
           'notify_condition_check_named_leaf_samples')}}, indent=2))
