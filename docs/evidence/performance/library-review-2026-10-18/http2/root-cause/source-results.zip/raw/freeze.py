import hashlib
import json
import os
from pathlib import Path
import stat
import zipfile

root = Path('/mnt/c/public/project-hyle/hyle')
raw = root / '.scratch/perf-review-2026-10-18/http2-root-cause'
base = Path('/root/hyle-scratch/http2-current-20261018')
dest = root / 'docs/evidence/performance/library-review-2026-10-18/http2/root-cause'
dest.mkdir(exist_ok=False)
def identity(path):
    assert path.resolve(strict=True) == path and stat.S_ISREG(path.lstat().st_mode)
    with path.open('rb') as stream:
        digest = hashlib.file_digest(stream, 'sha256').hexdigest()
    return {'path': str(path), 'bytes': path.stat().st_size, 'sha256': digest}
keep = {base / p for p in ('root-cause-notify/http2.o', 'root-cause-notify/candidate',
                           'root-cause-notify/tests', 'root-cause-product/consumer.o',
                           'root-cause-product/http2_test.o')}
generated = []
for name in ('root-cause', 'root-cause-alloc', 'root-cause-product', 'root-cause-notify'):
    for path in sorted((base / name).iterdir()):
        if path.is_file():
            with path.open('rb') as stream:
                elf = stream.read(4) == b'\x7fELF'
            if path.suffix == '.o' or elf:
                generated.append(path)
for relative in ('dead-submit-final/http2.o', 'header-lifetime/http2_test.o', 'paired-comparison-v2/consumer.o'):
    generated.append(base / relative)
retained = sorted(keep | {base / 'paired-comparison-v2/nanobench.o',
                          base / 'current-holdout/libhyle_io_core.so.0.1.0'})
plan = {'delete': [identity(p) for p in generated if p not in keep],
        'retain': [identity(p) for p in retained],
        'scope': 'Exact regular generated files only; retain current reusable caches, all source/raw/log/map/data/SDK and directories.'}
(raw / 'artifact-plan.json').write_text(json.dumps(plan, indent=2) + '\n')
comparison = json.loads((raw / 'notify-comparison/summary.json').read_text())
assert comparison['status'] == 'completed'
for path in (root / 'src/io_http2/http2.cc', root / 'bench/io_http2/http2_p1_bench.cc'):
    recorded = next(x for x in comparison['identities'] if x['path'] == str(path))
    assert identity(path)['sha256'] == recorded['sha256']
assert identity(root / 'tests/io_http2/http2_test.cc')['sha256'] == (raw / 'guarded-test-source.sha256').read_text().strip()
for name in ('notify-tests-default', 'notify-tests-epoll'):
    assert '[  PASSED  ] 16 tests.' in (raw / (name + '.stdout.txt')).read_text()
summary = {
    'conclusion': 'Three product redundancies removed and one benchmark-only wrapper removed. Remaining matched fixed-trace loss persists: final two process block medians +1.775196/+2.581064%, 21/24 blocks positive. Not declared fixed/equal. No calibrated error/CI or subtraction across historical rounds.',
    'benchmark': {'change': 'Direct owner-local sink co_await of public body.consume; no extra application wrapper Task; payload, total length, head/status/order,16KiB consume and full episode retirement preserved.',
                  'four_repeated_diagnostic_episodes_each': {'before': {'allocate': 268, 'reallocate': 20, 'requested_bytes': 1031428},
                                                            'after': {'allocate': 260, 'reallocate': 20, 'requested_bytes': 1029636}},
                  'limit': 'Injected AllocatorRef counts only its own route, not all process/mimalloc/libc activity. Diagnostic times not used.'},
    'products': [
        {'change': 'Allocate incoming trailer slots only on first actual regular trailer, after header-count limit validation. Empty/no trailer requires no slots. Initial headers and view lifetimes unchanged.',
         'per_complete_4_stream_episode': {'allocate_before': 260, 'allocate_after': 252, 'reallocate_both': 20,
                                           'requested_bytes_before': 1029636, 'requested_bytes_after': 972292,
                                           'requested_bytes_saved': 57344},
         'limit': 'Cumulative allocation requests, not RSS or peak-live memory.'},
        {'change': 'Remove first fixed-send resume_data before provider ever ran/deferred; retain streaming resume calls.',
         '20_complete_episode_diagnostic': {'old_resume_calls': 160, 'old_invalid_argument': 160, 'new_calls': 0}},
        {'change': 'Remove duplicate read release publication. Immediate temporary claim cannot be observed; async no-progress still publishes busy-direction release.',
         '20_complete_episode_diagnostic': {'notify_before': 30580, 'notify_after': 24100,
                                           'received_calls_both': 6480, 'received_bytes_both': 42003020,
                                           'try_read_calls_both': 20640, 'async_read_calls_both': 20,
                                           'allocate_per_episode_both': 252, 'reallocate_per_episode_both': 20}}],
    'syscall_diagnostic': json.loads((raw / 'summary.json').read_text()),
    'leaf_profile': json.loads((raw / 'leaf-summary.json').read_text()),
    'timing': comparison,
    'validation': {'final_default': '16/16 passed', 'final_forced_epoll': '16/16 passed',
                   'new_oom': 'Public custom allocator armed after complete body, first real trailer slots fail with ResourceExhausted; same session successfully serves subsequent stream. Earlier eager-allocation control has no failure at this injection point and its assertions fail, rather than proving an old functional bug.',
                   'fixture_failure': 'Initial control error branch used a co_await inside boolean short circuit and reached invalid Task result; explicit response guard fixed the test failure path. Logs retained; not reported as product failure.',
                   'independent': 'All72 final comparison block ratios/medians/geomeans/ranges/inclusiveIQR recomputed from six rawJSONL files and matched; no additional measurement.',
                   'scope': 'WSL Linux caches; strict GCC14 Release warnings, only affected product/test/consumer TUs. No full current HEAD rebuild, Windows/macOS/TLS/sanitizer or other shapes.'},
    'unresolved': 'Sampled user-space candidates include read_body, flush_once, owner checks and condition notifications. Low-resolution leaf sample counts do not prove the full residual cost or make unobserved work free. Fixed peer still has fewer generic API contracts.',
    'artifacts': plan,
}
(dest / 'summary.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2) + '\n')
with zipfile.ZipFile(dest / 'source-results.zip', 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for path in sorted(raw.rglob('*')):
        if path.is_file() and '__pycache__' not in path.parts:
            archive.write(path, 'raw/' + path.relative_to(raw).as_posix())
    for relative in ('src/io_http2/http2.cc', 'tests/io_http2/http2_test.cc', 'bench/io_http2/http2_p1_bench.cc'):
        archive.write(root / relative, 'source/' + relative)
    for relative in ('root-cause/profile-consumer.map', 'root-cause-product/candidate.map', 'root-cause-notify/candidate.map'):
        archive.write(base / relative, 'maps/' + relative.replace('/', '-'))
with zipfile.ZipFile(dest / 'source-results.zip') as archive:
    assert archive.testzip() is None
print(json.dumps({'archive': identity(dest / 'source-results.zip'),
                  'delete_files': len(plan['delete']), 'delete_bytes': sum(x['bytes'] for x in plan['delete']),
                  'retain_files': len(plan['retain'])}, indent=2))
