import hashlib
import json
import os
from pathlib import Path
import subprocess

root = Path('/mnt/c/public/project-hyle/hyle')
out = root / '.scratch/perf-review-2026-10-18/http2-root-cause'
build = Path('/root/hyle-scratch/http2-current-20261018/root-cause-notify')
build.mkdir(exist_ok=False)
base = json.loads((root / '.scratch/perf-review-2026-10-18/http2-paired-run/attempt-2/build.json').read_text())
argv = next(c['argv'] for c in base['commands'] if c['name'] == 'compile-consumer')
flags = argv[:argv.index('-c')] + ['-DHYLE_IO_HTTP2_BUILD']
old_link = next(c['argv'] for c in base['commands'] if c['name'] == 'link')
env = dict(os.environ, **base['environment'])
commands = []
def execute(name, argv, expected=0, changes=None):
    print(name, flush=True)
    result = subprocess.run(argv, cwd=build, env=dict(env, **(changes or {})), capture_output=True, timeout=60)
    (out / (name + '.stdout.txt')).write_bytes(result.stdout)
    (out / (name + '.stderr.txt')).write_bytes(result.stderr)
    commands.append({'name': name, 'argv': argv, 'returncode': result.returncode, 'environment_changes': changes or {}})
    (out / 'notify-commands.json').write_text(json.dumps(commands, indent=2) + '\n')
    if result.returncode != expected:
        print(result.stdout.decode(errors='replace'), result.stderr.decode(errors='replace'), flush=True)
        raise SystemExit(1)
    if 'diagnostic' in name:
        print(result.stdout.decode(), flush=True)
def link(label, product, consumer, extra=None):
    mapping = {
        '/root/hyle-scratch/http2-current-20261018/paired-comparison-v2/paired-bench': str(build / label),
        '-Wl,-Map,/root/hyle-scratch/http2-current-20261018/paired-comparison-v2/paired-bench.map': '-Wl,-Map,' + str(build / (label + '.map')),
        '/root/hyle-scratch/http2-current-20261018/paired-comparison-v2/consumer.o': str(consumer),
        '/root/hyle-scratch/http2-current-20261018/dead-submit-final/http2.o': str(product),
    }
    execute('notify-link-' + label, [mapping.get(x, x) for x in old_link] + (extra or []))

for label, source in [('before', out / 'http2.before-notify.cc'), ('after', root / 'src/io_http2/http2.cc')]:
    contents = source.read_text()
    patterns = [
        ('  void notify_owner() noexcept {', '++http2_diag_counts[0];'),
        ('                                TransferResult received) noexcept {', '++http2_diag_counts[1]; http2_diag_counts[2] += received.bytes;'),
        ('ProgressResult try_read_once(Http2SessionState &state) noexcept {', '++http2_diag_counts[3];'),
        ('ProgressResult read_once(mem::AllocatorRef allocator, Http2SessionState &state,\n                         OperationOptions options) noexcept {', '++http2_diag_counts[4];'),
    ]
    for pattern, counter in patterns:
        assert contents.count(pattern) == 1, pattern
        contents = contents.replace(pattern, pattern + '\n  ' + counter)
    instrumented = out / ('notify-' + label + '.cc')
    instrumented.write_text('extern "C" { unsigned long long http2_diag_counts[5]{}; }\n' + contents)
    execute('notify-compile-' + label, flags + ['-c', str(instrumented), '-o', str(build / (label + '.o'))])
reporter = out / 'notify-report.cc'
reporter.write_text('''#include <cstdio>
extern "C" unsigned long long http2_diag_counts[5];
struct Report { ~Report() {
  std::printf("{\\\"notify_calls\\\":%llu,\\\"received_calls\\\":%llu,\\\"received_bytes\\\":%llu,\\\"try_read_calls\\\":%llu,\\\"async_read_calls\\\":%llu}\\n", http2_diag_counts[0], http2_diag_counts[1], http2_diag_counts[2], http2_diag_counts[3], http2_diag_counts[4]);
} } report;
''')
execute('notify-compile-report', flags + ['-c', str(reporter), '-o', str(build / 'report.o')])
for label in ('before', 'after'):
    link('diagnostic-' + label, build / (label + '.o'), build.parent / 'root-cause-alloc/new.o', [str(build / 'report.o')])
    execute('notify-diagnostic-' + label, ['taskset', '-c', '2', str(build / ('diagnostic-' + label))])
execute('notify-compile-final', flags + ['-c', str(root / 'src/io_http2/http2.cc'), '-o', str(build / 'http2.o')])
link('candidate', build / 'http2.o', build.parent / 'root-cause-product/consumer.o')
prior_tests = json.loads((root / '.scratch/perf-review-2026-10-18/http2/header-lifetime/commands.json').read_text())
test_link = next(c['argv'] for c in prior_tests if c['name'] == 'link-tests')
mapping = {
    '/root/hyle-scratch/http2-current-20261018/header-lifetime/http2.o': str(build / 'http2.o'),
    '/root/hyle-scratch/http2-current-20261018/header-lifetime/http2_test.o': str(build.parent / 'root-cause-product/http2_test.o'),
    '/root/hyle-scratch/http2-current-20261018/header-lifetime/tests': str(build / 'tests'),
}
execute('notify-link-tests', [mapping.get(x, x) for x in test_link])
execute('notify-tests-default', [str(build / 'tests')])
execute('notify-tests-epoll', [str(build / 'tests')], changes={'HYLE_IO_FORCE_EPOLL': '1'})
artifacts = [{'path': str(p), 'bytes': p.stat().st_size, 'sha256': hashlib.sha256(p.read_bytes()).hexdigest()}
             for p in sorted(build.iterdir()) if p.is_file()]
(out / 'notify-artifacts.json').write_text(json.dumps(artifacts, indent=2) + '\n')
