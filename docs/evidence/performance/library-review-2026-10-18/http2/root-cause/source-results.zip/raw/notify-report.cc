#include <cstdio>
extern "C" unsigned long long http2_diag_counts[5];
struct Report { ~Report() {
  std::printf("{\"notify_calls\":%llu,\"received_calls\":%llu,\"received_bytes\":%llu,\"try_read_calls\":%llu,\"async_read_calls\":%llu}\n", http2_diag_counts[0], http2_diag_counts[1], http2_diag_counts[2], http2_diag_counts[3], http2_diag_counts[4]);
} } report;
