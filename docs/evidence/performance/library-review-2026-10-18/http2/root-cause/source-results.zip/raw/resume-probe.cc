#include <cstdio>
#include <nghttp2/nghttp2.h>
static unsigned calls, invalid;
extern "C" int __real_nghttp2_session_resume_data(nghttp2_session *, int32_t);
extern "C" int __wrap_nghttp2_session_resume_data(nghttp2_session *s, int32_t id) {
  ++calls; const int r = __real_nghttp2_session_resume_data(s, id);
  if (r == NGHTTP2_ERR_INVALID_ARGUMENT) ++invalid;
  return r;
}
struct Report { ~Report() { std::printf("{\"resume_calls\":%u,\"invalid_argument\":%u}\n", calls, invalid); } } report;
