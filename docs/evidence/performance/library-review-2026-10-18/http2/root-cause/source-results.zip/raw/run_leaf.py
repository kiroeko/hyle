"""One bounded software leaf sample per arm; no callgraph or new timing rank."""
import json
from pathlib import Path

import run_profile as base


def main():
    prior = json.loads((base.HERE / 'identity.json').read_text())
    binary = base.REMOTE / 'profile-consumer'
    expected = next(item for item in prior['artifacts'] if item['path'] == str(binary))
    assert base.identity(binary) == expected
    artifacts = []
    for arm in ('hyle', 'reference'):
        data = base.REMOTE / (arm + '.cpu-clock.data')
        assert not data.exists()
        record = base.execute('leaf-record-' + arm, [
            'perf', 'record', '-e', 'cpu-clock:u', '-F', '1999', '-o', data,
            '--', 'taskset', '-c', '2', binary, arm])
        if record['returncode'] != 0:
            raise RuntimeError('Sampling failed; preserve failure and stop without retry')
        oracle = json.loads((base.HERE / ('leaf-record-' + arm + '.stdout.txt')).read_text())
        assert oracle == dict(arm=arm, successful_warmups=16, successful_episodes=1024,
                              streams_per_episode=4, application_bytes_per_episode=2097152,
                              all_oracles_passed=True)
        report = base.execute('leaf-report-' + arm, [
            'perf', 'report', '-i', data, '--stdio', '--no-children',
            '--show-nr-samples', '--percent-limit', '0', '--sort', 'dso,symbol',
            '--call-graph', 'none'])
        if report['returncode'] != 0:
            raise RuntimeError('Report failed; preserve failure and stop')
        artifacts.append(base.identity(data))
    base.write('leaf-identity.json', dict(
        source=base.identity(Path(__file__).resolve()), binary=expected,
        data=artifacts, status='completed',
        scope='One cpu-clock:u F1999 record per arm; no callgraph; unchanged16 warmups plus1024 complete episodes. Whole process sampling, not latency ranking.'))


if __name__ == '__main__':
    main()
