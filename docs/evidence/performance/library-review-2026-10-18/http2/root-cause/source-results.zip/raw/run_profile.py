"""One fresh consumer TU; software/syscall diagnosis only, never a ranking."""
from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
import time

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
REMOTE = Path('/root/hyle-scratch/http2-current-20261018/root-cause')
PRIOR = json.loads((HERE.parent / 'http2-paired-run/attempt-2/build.json').read_text())
ENV = dict(os.environ, **PRIOR['environment'], LC_ALL='C')
EVENTS = ['task-clock', 'context-switches', 'cpu-migrations', 'page-faults',
          'syscalls:sys_enter_sendto', 'syscalls:sys_enter_recvfrom',
          'syscalls:sys_enter_io_uring_enter']


def write(name, value):
    (HERE / name).write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8')


def identity(path):
    path = Path(path)
    return dict(path=str(path), bytes=path.stat().st_size,
                sha256=hashlib.sha256(path.read_bytes()).hexdigest())


def execute(name, argv, timeout=60):
    prefix = HERE / name
    if prefix.with_suffix('.command.json').exists():
        raise RuntimeError('Refusing to overwrite attempt: ' + name)
    command = dict(argv=list(map(str, argv)), cwd=str(REMOTE),
                   environment={key: value for key, value in ENV.items()
                                if key.startswith(('HYLE_', 'LD_')) or key == 'LC_ALL'},
                   timeout_seconds=timeout)
    write(name + '.command.json', command)
    start = time.monotonic()
    try:
        with (HERE / (name + '.stdout.txt')).open('wb') as out, \
                (HERE / (name + '.stderr.txt')).open('wb') as err:
            process = subprocess.run(command['argv'], cwd=REMOTE, env=ENV,
                                     stdout=out, stderr=err, timeout=timeout)
        command['returncode'] = process.returncode
    except subprocess.TimeoutExpired:
        command['returncode'] = None
        command['error'] = 'timeout; no automatic retry'
    command['wall_seconds'] = time.monotonic() - start
    write(name + '.command.json', command)
    print(name, command['returncode'], flush=True)
    return command


def build():
    source = ROOT / 'bench/io_http2/http2_p1_bench.cc'
    assert identity(source)['sha256'] == '96c1659810ca5d9e11610f937d619d122615f17cd4e3f3519ced9c0f255f6d63'
    REMOTE.mkdir(exist_ok=False)
    expected = next(item for item in PRIOR['sources'] if item['path'].endswith('/src/io_http2/http2.cc'))
    assert identity(ROOT / 'src/io_http2/http2.cc')['sha256'] == expected['sha256']
    for expected in PRIOR['reused_inputs']:
        assert identity(expected['path']) == expected
    nanobench = Path('/root/hyle-scratch/http2-current-20261018/paired-comparison-v2/nanobench.o')
    expected = next(item for item in PRIOR['built'] if item['path'] == str(nanobench))
    assert identity(nanobench) == expected
    (HERE / 'canonical.profiled.cc').write_bytes(source.read_bytes())
    compile_args = next(item['argv'] for item in PRIOR['commands'] if item['name'] == 'compile-consumer')
    compile_args = [str(HERE / 'profile_consumer.cc') if item == str(source) else
                    str(REMOTE / 'consumer.o') if item.endswith('/paired-comparison-v2/consumer.o')
                    else item for item in compile_args]
    assert execute('compile-consumer', compile_args)['returncode'] == 0
    link = next(item['argv'] for item in PRIOR['commands'] if item['name'] == 'link')
    link = [str(REMOTE / 'profile-consumer') if item.endswith('/paired-comparison-v2/paired-bench') else
            '-Wl,-Map,' + str(REMOTE / 'profile-consumer.map') if item.startswith('-Wl,-Map,') else
            str(REMOTE / 'consumer.o') if item.endswith('/paired-comparison-v2/consumer.o')
            else item for item in link]
    assert execute('link', link)['returncode'] == 0
    assert execute('ldd', ['ldd', REMOTE / 'profile-consumer'])['returncode'] == 0
    loader = (HERE / 'ldd.stdout.txt').read_text()
    assert '/root/hyle-scratch/http2-current-20261018/current-holdout/libhyle_io_core.so.0.1.0' in loader
    write('identity.json', dict(sources=[identity(path) for path in
          (source, HERE / 'profile_consumer.cc', HERE / 'run_profile.py', ROOT / 'src/io_http2/http2.cc')],
          reused_inputs=PRIOR['reused_inputs'] + [identity(nanobench)],
          artifacts=[identity(REMOTE / name) for name in ('consumer.o', 'profile-consumer', 'profile-consumer.map')],
          scope='Only consumer TU freshly compiled; software/syscall diagnosis, not formal elapsed ranking.'))


def run():
    identity_record = json.loads((HERE / 'identity.json').read_text())
    expected = next(item for item in identity_record['artifacts'] if item['path'].endswith('/profile-consumer'))
    assert identity(expected['path']) == expected
    for arm in ('hyle', 'reference'):
        stats = HERE / ('stat-' + arm + '.csv')
        command = ['perf', 'stat', '--no-big-num', '-x', ';', '-o', stats,
                   '-e', ','.join(EVENTS), '--', 'taskset', '-c', '2',
                   REMOTE / 'profile-consumer', arm]
        result = execute('stat-' + arm, command)
        if result['returncode'] != 0:
            # A permission/event setup failure before the consumer starts may
            # fall back once to software counts; keep the original failure.
            stdout = (HERE / ('stat-' + arm + '.stdout.txt')).read_text()
            errors = (HERE / ('stat-' + arm + '.stderr.txt')).read_text() + (stats.read_text() if stats.exists() else '')
            if stdout.strip() or not any(word in errors.lower() for word in ('permission', 'access', 'not supported', 'unknown tracepoint')):
                raise RuntimeError('Stat failed after/without a classified setup failure')
            command[command.index('-e') + 1] = ','.join(EVENTS[:4])
            command[command.index('-o') + 1] = HERE / ('software-' + arm + '.csv')
            result = execute('software-' + arm, command)
            assert result['returncode'] == 0
            name = 'software-' + arm
        else:
            name = 'stat-' + arm
        oracle = json.loads((HERE / (name + '.stdout.txt')).read_text())
        assert oracle == dict(arm=arm, successful_warmups=16, successful_episodes=1024,
                              streams_per_episode=4, application_bytes_per_episode=2097152,
                              all_oracles_passed=True)
    write('execution-status.json', dict(status='completed', arms=['hyle', 'reference'],
          counter_boundary='Entire process including runtime/load/init, 16 warmups, 1024 full episodes, teardown and final report.',
          no_elapsed_ranking=True))


if __name__ == '__main__':
    assert sys.platform.startswith('linux')
    {'build': build, 'run': run}[sys.argv[1]]()
