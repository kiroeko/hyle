#define main legacy_main
#include "../../../bench/io_http2/http2_p1_bench.cc"
#undef main

int main(int argc, char **argv) {
  if (argc != 2 || (std::string_view(argv[1]) != "hyle" &&
                    std::string_view(argv[1]) != "reference"))
    return 2;
  std::signal(SIGPIPE, SIG_IGN);
  const bool hyle_arm = std::string_view(argv[1]) == "hyle";
  const auto workload = make_workload("HTTP2 root-cause complete episode", 4,
                                    256 * 1024, 256 * 1024,
                                    NGHTTP2_INITIAL_CONNECTION_WINDOW_SIZE);
  HyleHarness harness;
  auto run = [&](bool check_descriptors) {
    return hyle_arm ? harness.run(workload)
                    : run_task_peer(harness, workload, check_descriptors);
  };
  for (unsigned index = 0; index != 16; ++index) {
    if (run(index == 0) != workload.streams) {
      std::fprintf(stderr, "warmup oracle failed index=%u\n", index);
      return 3;
    }
  }
  for (unsigned index = 0; index != 1024; ++index) {
    if (run(false) != workload.streams) {
      std::fprintf(stderr, "episode oracle failed index=%u\n", index);
      return 4;
    }
  }
  std::printf("{\"arm\":\"%s\",\"successful_warmups\":16,"
              "\"successful_episodes\":1024,\"streams_per_episode\":4,"
              "\"application_bytes_per_episode\":2097152,"
              "\"all_oracles_passed\":true}\n", argv[1]);
  return 0;
}
