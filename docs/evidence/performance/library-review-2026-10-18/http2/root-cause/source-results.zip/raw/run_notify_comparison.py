import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

root = Path('/mnt/c/public/project-hyle/hyle')
out = root / '.scratch/perf-review-2026-10-18/http2-root-cause/notify-comparison'
out.mkdir(exist_ok=False)
sys.path.insert(0, str(root / 'bench/io_http2'))
from run_paired import summarize

before = Path('/root/hyle-scratch/http2-current-20261018/root-cause-product/candidate')
after = Path('/root/hyle-scratch/http2-current-20261018/root-cause-notify/candidate')
schedule = [('self-before', after, 'paired-self'), ('old-1', before, 'paired'),
            ('new-1', after, 'paired'), ('new-2', after, 'paired'),
            ('old-2', before, 'paired'), ('self-after', after, 'paired-self')]
env = dict(os.environ, LD_LIBRARY_PATH='/root/hyle-scratch/http2-current-20261018/current-holdout:/root/hyle-scratch/io-watch-v2-dev/bin')
summary = {'schedule': [(name, str(binary), mode) for name, binary, mode in schedule],
           'scope': 'Only duplicate read-notification change; both products already have lazy trailers and no first fixed-send resume. Shared consumer with no benchmark wrapper Task.',
           'limit': 'One predeclared six-process sequence, no retries/filtering. Complete blocks only, no independent-episode claim or confidence interval.',
           'environment': {'LD_LIBRARY_PATH': env['LD_LIBRARY_PATH']}, 'runs': [],
           'identities': [{'path': str(p), 'bytes': p.stat().st_size, 'sha256': hashlib.sha256(p.read_bytes()).hexdigest()}
                          for p in [before, after, root / 'src/io_http2/http2.cc', root / 'bench/io_http2/http2_p1_bench.cc',
                                    out.parent / 'http2.before-notify.cc']]}
for name, binary, mode in schedule:
    command = ['taskset', '-c', '2', str(binary), '--' + mode]
    with (out / (name + '.stdout.jsonl')).open('wb') as stdout, (out / (name + '.stderr.txt')).open('wb') as stderr:
        process = subprocess.run(command, cwd=root, env=env, stdout=stdout, stderr=stderr, timeout=60)
    run = {'name': name, 'command': command, 'returncode': process.returncode}
    summary['runs'].append(run)
    (out / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
    if process.returncode:
        raise SystemExit('Failed; all output retained, no retry: ' + name)
    run['result'] = summarize((out / (name + '.stdout.jsonl')).read_text(), mode, 2)
    (out / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
    print(name, 'median_percent', run['result']['median_ratio_percent'], flush=True)
summary['status'] = 'completed'
(out / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
