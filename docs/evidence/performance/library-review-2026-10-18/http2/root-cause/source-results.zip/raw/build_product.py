import hashlib
import json
import os
from pathlib import Path
import subprocess

root = Path('/mnt/c/public/project-hyle/hyle')
out = root / '.scratch/perf-review-2026-10-18/http2-root-cause'
build = Path('/root/hyle-scratch/http2-current-20261018/root-cause-product')
build.mkdir(exist_ok=False)
base = json.loads((root / '.scratch/perf-review-2026-10-18/http2-paired-run/attempt-2/build.json').read_text())
compile_cmd = next(c['argv'] for c in base['commands'] if c['name'] == 'compile-consumer')
flags = compile_cmd[:compile_cmd.index('-c')]
old_link = next(c['argv'] for c in base['commands'] if c['name'] == 'link')
env = dict(os.environ, **base['environment'])
commands = []
def execute(name, argv):
    print(name, flush=True)
    result = subprocess.run(argv, cwd=build, env=env, capture_output=True, timeout=60)
    (out / (name + '.stdout.txt')).write_bytes(result.stdout)
    (out / (name + '.stderr.txt')).write_bytes(result.stderr)
    commands.append({'name': name, 'argv': argv, 'returncode': result.returncode})
    (out / 'product-commands.json').write_text(json.dumps(commands, indent=2) + '\n')
    if result.returncode:
        print(result.stderr.decode(errors='replace'), flush=True)
        raise SystemExit(result.returncode)
    if name.endswith('diagnostic'):
        print(result.stdout.decode(), flush=True)
def link(label, product, consumer='consumer.o', wrapper=False):
    mapping = {
        '/root/hyle-scratch/http2-current-20261018/paired-comparison-v2/paired-bench': str(build / label),
        '-Wl,-Map,/root/hyle-scratch/http2-current-20261018/paired-comparison-v2/paired-bench.map': '-Wl,-Map,' + str(build / (label + '.map')),
        '/root/hyle-scratch/http2-current-20261018/paired-comparison-v2/consumer.o': str(build / consumer),
        '/root/hyle-scratch/http2-current-20261018/dead-submit-final/http2.o': product,
    }
    argv = [mapping.get(x, x) for x in old_link]
    if wrapper:
        argv += [str(build / 'resume-probe.o'), '-Wl,--wrap=nghttp2_session_resume_data']
    execute(label + '-link', argv)

for relative, output, extra in [('src/io_http2/http2.cc', 'http2.o', ['-DHYLE_IO_HTTP2_BUILD']),
                                ('bench/io_http2/http2_p1_bench.cc', 'consumer.o', [])]:
    execute('compile-' + output, flags + extra + ['-c', str(root / relative), '-o', str(build / output)])
product = str(build / 'http2.o')
old_product = '/root/hyle-scratch/http2-current-20261018/dead-submit-final/http2.o'
link('control', old_product)
link('candidate', product)
wrapper = out / 'resume-probe.cc'
wrapper.write_text('''#include <cstdio>
#include <nghttp2/nghttp2.h>
static unsigned calls, invalid;
extern "C" int __real_nghttp2_session_resume_data(nghttp2_session *, int32_t);
extern "C" int __wrap_nghttp2_session_resume_data(nghttp2_session *s, int32_t id) {
  ++calls; const int r = __real_nghttp2_session_resume_data(s, id);
  if (r == NGHTTP2_ERR_INVALID_ARGUMENT) ++invalid;
  return r;
}
struct Report { ~Report() { std::printf("{\\\"resume_calls\\\":%u,\\\"invalid_argument\\\":%u}\\n", calls, invalid); } } report;
''')
execute('compile-resume-probe', flags + ['-c', str(wrapper), '-o', str(build / 'resume-probe.o')])
diag_consumer = '../root-cause-alloc/new.o'
for label, chosen in [('old', old_product), ('new', product)]:
    link('allocation-resume-' + label, chosen, diag_consumer, wrapper=True)
    execute(label + '-product-diagnostic', ['taskset', '-c', '2', str(build / ('allocation-resume-' + label))])
record = []
for path in sorted(build.iterdir()):
    if path.is_file():
        record.append({'path': str(path), 'bytes': path.stat().st_size,
                       'sha256': hashlib.sha256(path.read_bytes()).hexdigest()})
(out / 'product-artifacts.json').write_text(json.dumps(record, indent=2) + '\n')
