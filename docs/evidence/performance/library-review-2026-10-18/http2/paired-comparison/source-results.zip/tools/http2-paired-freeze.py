import hashlib
import json
from pathlib import Path
import subprocess
import zipfile

root = Path(__file__).resolve().parents[2]
scratch = root / '.scratch/perf-review-2026-10-18'
raw = scratch / 'http2-paired-run'
attempt = raw / 'attempt-2'
destination = root / 'docs/evidence/performance/library-review-2026-10-18/http2/paired-comparison'
destination.mkdir(exist_ok=False)
build = json.loads((attempt / 'build.json').read_text(encoding='utf-8'))
for item in build['sources']:
    current = root / item['path'].removeprefix('/mnt/c/public/project-hyle/hyle/')
    assert hashlib.sha256(current.read_bytes()).hexdigest() == item['sha256'], str(current)
suite = json.loads((attempt / 'suite/summary.json').read_text(encoding='utf-8'))
assert suite['status'] == 'completed'
summary = {
    'scope': 'Linux WSL guest CPU2, fixed fresh-session AF_UNIX 4x256KiB request+response trace; full episode retirement.',
    'method': 'Fixed self/paired/paired/paired/self. Each process: 16 warmups per arm; 12 alternating ABBA/BAAB blocks, 64 episodes per cell. Positive percent = Hyle slower. No retries or filtering.',
    'conclusion': 'Three paired block medians +2.143514/+1.525264/+2.735291%; 33/36 blocks positive. Small directional loss in this trace remains unresolved. No isolated wrapper/scheduler cost, calibrated error, confidence interval, equivalence or cross-round subtraction claimed.',
    'self_limit': 'Self median -0.086333/+0.445428%; block ranges overlap paired observations. This is observed comparison variability, not an error bound or a value to subtract.',
    'timing': {'clock_min_delta_ns_range': [12, 13], 'actual_cell_ms_range': [46.358154, 52.743848],
               'socket_requested_bytes': 4096, 'socket_actual_send_receive_bytes': 8192,
               'rusage_limit': 'Process-wide deltas include measurement framework/bookkeeping outside the precise timed interval; not hardware counters.'},
    'validation': {'consumer_compile': 'GCC14 Release with -Wall -Wextra -Wpedantic -Werror; clean.',
                   'legacy_smoke': 'Hyle and manual peer each completed 64x1KiB and 4x256KiB traces.',
                   'formal': 'Five processes completed all warmups and 240 fixed cells; no invalid or missing records.',
                   'independent_check': 'Recomputed every block ratio, median/geomean, inclusive quartiles/ranges and counter totals from all five raw JSONL files; exact agreement.',
                   'initial_build_failure': 'Benchmark aggregate Event construction and use of private nanobench helper failed compilation. Fixed locally; first attempt logs retained. No failed executable measured.'},
    'build_limit': 'Only benchmark consumer and nanobench implementation TUs rebuilt; final accepted dead-counter HTTP2 and other library/dependency caches reused. Not a complete current HEAD rebuild. Binary/source and cache hashes, commands, compiler and ldd retained.',
    'benchmark_binary': build['built'][-1],
    'runs': [{'name': run['name'], **run['result']} for run in suite['runs']],
}
(destination / 'summary.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2) + '\n', encoding='utf-8', newline='\n')
with zipfile.ZipFile(destination / 'source-results.zip', 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for path in sorted(raw.rglob('*')):
        if path.is_file():
            archive.write(path, 'raw/' + path.relative_to(raw).as_posix())
    for relative in ('bench/io_http2/http2_p1_bench.cc', 'bench/io_http2/run_paired.py',
                     'bench/io_http2/CMakeLists.txt', 'bench/nanobench_impl.cc',
                     'third_party/nanobench/nanobench.h', 'src/io_http2/http2.cc'):
        archive.write(root / relative, 'source/' + relative)
    for name in ('http2-paired-build.py', 'http2-paired-execute.py', 'http2-paired-freeze.py'):
        archive.write(scratch / name, 'tools/' + name)
    diff = subprocess.run(['git', 'diff', '--', 'bench/io_http2'], cwd=root, capture_output=True, check=True).stdout
    archive.writestr('source/benchmark.diff', diff)
archive = destination / 'source-results.zip'
with zipfile.ZipFile(archive) as frozen:
    assert frozen.testzip() is None
print(json.dumps({'archive': str(archive), 'bytes': archive.stat().st_size,
                  'sha256': hashlib.sha256(archive.read_bytes()).hexdigest()}, ensure_ascii=False))
