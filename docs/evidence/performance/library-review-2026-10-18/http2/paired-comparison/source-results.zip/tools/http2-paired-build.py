import hashlib
import json
import os
from pathlib import Path
import subprocess

root = Path('/mnt/c/public/project-hyle/hyle')
out = root / '.scratch/perf-review-2026-10-18/http2-paired-run/attempt-2'
out.mkdir(exist_ok=False)
build = Path('/root/hyle-scratch/http2-current-20261018/paired-comparison-v2')
build.mkdir(exist_ok=False)
plan = json.loads((root / '.scratch/perf-review-2026-10-18/http2-small-headers-timing/commands-plan.json').read_text())
compile_old = next(x['argv'] for x in plan if x['name'] == 'compile-shared-consumer')
flags = compile_old[:compile_old.index('-c')]
warnings = ['-Wall', '-Wextra', '-Wpedantic', '-Werror']
link = next(x['argv'] for x in plan if x['name'] == 'link-new')
replacements = {
    '/root/hyle-scratch/http2-current-20261018/small-headers-timing/probe-new': str(build / 'paired-bench'),
    '-Wl,-Map,/root/hyle-scratch/http2-current-20261018/small-headers-timing/probe-new.map': '-Wl,-Map,' + str(build / 'paired-bench.map'),
    '/root/hyle-scratch/http2-current-20261018/small-headers/http2.o': '/root/hyle-scratch/http2-current-20261018/dead-submit-final/http2.o',
    '/root/hyle-scratch/http2-current-20261018/small-headers-timing/consumer.o': str(build / 'consumer.o'),
    '/root/hyle-scratch/http2-current-20261018/bench_nanobench_impl.cc.o': str(build / 'nanobench.o'),
}
link = [replacements.get(arg, arg) for arg in link]
env = os.environ.copy()
env['LD_LIBRARY_PATH'] = '/root/hyle-scratch/http2-current-20261018/current-holdout:/root/hyle-scratch/io-watch-v2-dev/bin'
commands = [
    ('compiler', ['g++-14', '--version']),
    ('compile-consumer', flags + warnings + ['-c', str(root / 'bench/io_http2/http2_p1_bench.cc'), '-o', str(build / 'consumer.o')]),
    ('compile-nanobench', flags + ['-c', str(root / 'bench/nanobench_impl.cc'), '-o', str(build / 'nanobench.o')]),
    ('link', link),
    ('ldd', ['ldd', str(build / 'paired-bench')]),
]
def identity(path):
    path = Path(path)
    return {'path': str(path), 'bytes': path.stat().st_size,
            'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}
sources = [root / x for x in ('bench/io_http2/http2_p1_bench.cc', 'bench/io_http2/run_paired.py',
                              'bench/nanobench_impl.cc', 'third_party/nanobench/nanobench.h',
                              'src/io_http2/http2.cc')]
inputs = [Path(arg) for arg in link if arg.endswith(('.o', '.a')) and not arg.startswith(str(build))]
inputs += [Path(env['LD_LIBRARY_PATH'].split(':')[0]) / 'libhyle_io_core.so.0.1.0']
record = {'sources': [identity(x) for x in sources], 'reused_inputs': [identity(x) for x in inputs],
          'environment': {'LD_LIBRARY_PATH': env['LD_LIBRARY_PATH']}, 'commands': []}
for name, argv in commands:
    print(name, flush=True)
    result = subprocess.run(argv, cwd=build, env=env, capture_output=True, timeout=120)
    (out / (name + '.stdout.txt')).write_bytes(result.stdout)
    (out / (name + '.stderr.txt')).write_bytes(result.stderr)
    record['commands'].append({'name': name, 'argv': argv, 'cwd': str(build), 'returncode': result.returncode})
    (out / 'build.json').write_text(json.dumps(record, indent=2) + '\n')
    if result.returncode:
        print(result.stderr.decode(errors='replace'), flush=True)
        raise SystemExit(result.returncode)
record['built'] = [identity(build / x) for x in ('consumer.o', 'nanobench.o', 'paired-bench')]
(out / 'build.json').write_text(json.dumps(record, indent=2) + '\n')
print('BUILT', record['built'][-1], flush=True)
