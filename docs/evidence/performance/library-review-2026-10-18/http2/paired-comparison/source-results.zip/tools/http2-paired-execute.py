import json
import os
from pathlib import Path
import subprocess

root = Path('/mnt/c/public/project-hyle/hyle')
out = root / '.scratch/perf-review-2026-10-18/http2-paired-run/attempt-2'
binary = '/root/hyle-scratch/http2-current-20261018/paired-comparison-v2/paired-bench'
env = os.environ.copy()
env['LD_LIBRARY_PATH'] = '/root/hyle-scratch/http2-current-20261018/current-holdout:/root/hyle-scratch/io-watch-v2-dev/bin'
env['HYLE_BENCH_SMOKE'] = '1'
command = ['taskset', '-c', '2', binary]
result = subprocess.run(command, cwd=root, env=env, capture_output=True, timeout=30)
(out / 'smoke.stdout.txt').write_bytes(result.stdout)
(out / 'smoke.stderr.txt').write_bytes(result.stderr)
(out / 'smoke.command.json').write_text(json.dumps({'argv': command, 'HYLE_BENCH_SMOKE': '1', 'returncode': result.returncode}, indent=2) + '\n')
print('SMOKE', result.returncode, result.stdout.decode(errors='replace'), result.stderr.decode(errors='replace'), flush=True)
if result.returncode:
    raise SystemExit(result.returncode)
env.pop('HYLE_BENCH_SMOKE')
command = ['python3', str(root / 'bench/io_http2/run_paired.py'), binary,
           '--output', str(out / 'suite'), '--cpu', '2']
with (out / 'runner.stdout.txt').open('wb') as stdout, (out / 'runner.stderr.txt').open('wb') as stderr:
    result = subprocess.run(command, cwd=root, env=env, stdout=stdout, stderr=stderr, timeout=310)
print((out / 'runner.stdout.txt').read_text(), (out / 'runner.stderr.txt').read_text(), flush=True)
raise SystemExit(result.returncode)
