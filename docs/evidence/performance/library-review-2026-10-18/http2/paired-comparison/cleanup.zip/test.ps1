# One-time exact cleanup after the fixed HTTP2 paired comparison.
# Preserve source, logs, raw samples, maps, archives and shared caches.
$ErrorActionPreference = 'Stop'
$archive = Join-Path $PSScriptRoot 'docs/evidence/performance/library-review-2026-10-18/http2/paired-comparison/source-results.zip'
if ((Get-FileHash -LiteralPath $archive -Algorithm SHA256).Hash.ToLowerInvariant() -ne '562bff1a1f5b54fa4b263be25557f58b8d1584a2db096c52041713f9109ab5a7') { throw 'Frozen evidence archive mismatch' }
$pythonSource = @'
import hashlib, json, os, stat
from pathlib import Path

root = Path('/root/hyle-scratch/http2-current-20261018')
targets = [
    (Path('/root/hyle-scratch/http2-current-20261018/paired-comparison-v2/paired-bench'), 898520, '9e7c16887d498c638345b16eb4654ac7ad2d28f46b99362c0b1cd80cde44c879'),
    (Path('/root/hyle-scratch/http2-current-20261018/small-headers-timing/consumer.o'), 113632, '1c6dc5ff898f3f1f0ad79b124ab6e5b1700e15a006964e4d9113a8f1a373e418'),
]
retained = [
    (Path('/root/hyle-scratch/http2-current-20261018/paired-comparison-v2/consumer.o'), 154208, 'bc2d83d4d00f28cfa136e7e4c466aadba5a4680ceb57f3f1ea1ab56a56388a06'),
    (Path('/root/hyle-scratch/http2-current-20261018/paired-comparison-v2/nanobench.o'), 283672, '43b16d764541dc1460c6aba273360f40403bcc35ee2feb37461f7f4d29984987'),
    (Path('/root/hyle-scratch/http2-current-20261018/dead-submit-final/http2.o'), 224784, '90fb3ebf7e71a9ee74789aaec62866c08c931a0b96413994aa532a5cb9d99302'),
    (Path('/root/hyle-scratch/http2-current-20261018/current-holdout/libhyle_io_core.so.0.1.0'), 387104, '9ead235b1bbd72f56d44eab9c8ac135b8c4b0ce0ec0a6fb72660aa917d3b4779'),
    (Path('/root/hyle-scratch/http2-current-20261018/header-lifetime/http2_test.o'), 654624, 'debb22bed71cd36bbda594158905dc547ca59655ed62c81f8b4a42c0431f75d3'),
]
assert root.resolve(strict=True) == root
assert len({x[0] for x in targets + retained}) == 7
assert sum(x[1] for x in targets) == 1012152

def inspect(item):
    path, size, expected_sha = item
    assert path.is_absolute() and path.is_relative_to(Path('/root/hyle-scratch/http2-current-20261018'))
    current = Path(path.anchor)
    for part in path.parts[1:]:
        current /= part
        assert not stat.S_ISLNK(current.lstat().st_mode), str(current)
    assert path.resolve(strict=True) == path
    before = path.lstat()
    assert stat.S_ISREG(before.st_mode) and before.st_size == size
    with os.fdopen(os.open(path, os.O_RDONLY | os.O_NOFOLLOW), 'rb') as stream:
        opened = os.fstat(stream.fileno())
        assert (opened.st_dev, opened.st_ino) == (before.st_dev, before.st_ino)
        digest = hashlib.sha256(stream.read()).hexdigest()
        after = os.fstat(stream.fileno())
    current = path.lstat()
    assert digest == expected_sha and after.st_size == size
    assert (current.st_dev, current.st_ino, current.st_size) == (after.st_dev, after.st_ino, after.st_size)
    return current.st_dev, current.st_ino

identities = {x[0]: inspect(x) for x in targets + retained}
for proc in Path('/proc').iterdir():
    if not proc.name.isdigit():
        continue
    try:
        executable = os.readlink(proc / 'exe')
    except (OSError, PermissionError):
        continue
    assert executable not in {str(x[0]) for x in targets}, 'Target executable still running: ' + proc.name
print(json.dumps({'preflight_files': 7, 'delete_files': 2, 'delete_bytes': 1012152, 'retain_files': 5}), flush=True)
for item in targets:
    assert item[0].is_relative_to(root)
    assert inspect(item) == identities[item[0]]
    item[0].unlink()
    print('Deleted exact generated file: ' + str(item[0]), flush=True)
for item in retained:
    assert inspect(item) == identities[item[0]]
print(json.dumps({'status': 'completed', 'deleted_files': 2, 'deleted_bytes': 1012152, 'retained_cache_files_verified': 5, 'directories_removed': 0}), flush=True)
'@
$payload = [Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes($pythonSource))
$code = 'import base64;exec(base64.b64decode("' + $payload + '"))'
& wsl.exe -d Ubuntu-24.04 -u root --exec python3 -c $code
if ($LASTEXITCODE -ne 0) { throw "Exact WSL cleanup failed: $LASTEXITCODE" }

