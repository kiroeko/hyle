#include "tests/compute_route_apple/tensor_test_support.h"
#include <mlx/memory.h>
#include <array>
#include <iomanip>
#include <iostream>
int main() {
  using namespace apple_tensor_test;
  try {
    constexpr int depth=256, queries=129, keys=32768, heads=4, kv_heads=2;
    std::vector<double> v(kv_heads*keys*depth);
    for(int h=0;h<kv_heads;++h)
      for(int k=0;k<keys;++k)
        std::fill_n(v.begin()+(h*keys+k)*depth,depth,k%2==0?1.25:-1.25);
    const std::array inputs{
      make(std::vector<double>(heads*queries*depth),{1,heads,queries,depth},mx::float32),
      make(std::vector<double>(kv_heads*keys*depth),{1,kv_heads,keys,depth},mx::float32),
      make(v,{1,kv_heads,keys,depth},mx::float32)};
    auto context=a::Context::create().value();
    auto program=context.prepare(c::Operation(c::ScaledDotProductAttention{
        .layout=c::AttentionLayout::kBatchHeadSequenceDepth,
        .scale=0.0625F,.causal=true}),inputs).value();
    auto slot=program.create_invocation().value();
    auto bound=slot.bind(inputs);if(!bound.ok()){std::cerr<<bound.message();return 2;}
    mx::clear_cache();
    const auto before=mx::get_active_memory(),cache_before=mx::get_cache_memory();
    mx::reset_peak_memory();
    auto work=slot.submit().value();auto result=work.wait().value();mx::synchronize(stream());
    const auto after=mx::get_active_memory(),peak=mx::get_peak_memory(),cache_after=mx::get_cache_memory();
    const auto observed=values(result.get()->arrays()[0]);
    bool passed=observed.size()==heads*queries*depth;double max_error=0;
    for(int h=0;h<heads;++h)
      for(int t=0;t<queries;++t){
        const int count=keys-queries+t+1;
        // FP64 prefix sum of fixed alternating +1.25/-1.25 values.
        const double expected=(count%2==0?0.0:1.25)/double(count);
        for(int d=0;d<depth;++d){
          const auto actual=observed[(h*queries+t)*depth+d];
          const double error=std::abs(actual-expected);
          passed&=std::isfinite(actual)&&error<=6e-6*std::abs(expected)+2e-6;
          max_error=std::max(max_error,error);
        }
      }
    std::cout<<std::setprecision(17)
      <<"{\"dtype\":\"F32\",\"B\":1,\"Hq\":4,\"Hkv\":2,\"D\":256,\"Q\":129,\"KV\":32768,\"mask\":\"None\",\"causal\":true,\"input\":\"QK0,V alternating +1.25/-1.25 per KV row\",\"caller_qkv_bytes\":134746112,\"caller_mask_bytes\":0,\"output_bytes\":528384,\"original_score_bytes\":67633152,\"active_before\":"<<before
      <<",\"cache_before\":"<<cache_before<<",\"active_after\":"<<after<<",\"peak\":"<<peak
      <<",\"peak_minus_active_before\":"<<(peak-before)<<",\"cache_after\":"<<cache_after
      <<",\"max_abs_error\":"<<max_error<<",\"checked_elements\":"<<observed.size()
      <<",\"oracle_passed\":"<<(passed?"true":"false")<<"}\n";
    return passed?0:3;
  }catch(const std::exception&e){std::cerr<<e.what()<<"\n";return 4;}
}
