from pathlib import Path
import subprocess, sys, tarfile

OUT=Path(__file__).resolve().parent
REMOTE='/Users/kiro/hyle-scratch/compute-unified/library-review-20261018-short-q'
phase=sys.argv[1]
code=r'''
from pathlib import Path
import hashlib,json,sys,tarfile
p=Path(REMOTE)
identity={}
for f in p.iterdir():
 if f.is_file() and (f.suffix=='.o' or f.name.endswith(('-tests','-space')) or f.name=='capability'):
  identity[str(f)]={'bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()}
native=Path('/Users/kiro/hyle-scratch/g09-air-direct-20261017/final-1dbfce9a0/apple-sdk/lib/libmlx.a')
identity[str(native)]={'bytes':native.stat().st_size,'sha256':hashlib.sha256(native.read_bytes()).hexdigest()}
(p/'runtime-identities.json').write_text(json.dumps(identity,indent=2))
with tarfile.open(fileobj=sys.stdout.buffer,mode='w|gz') as t:
 for f in sorted(p.rglob('*')):
  if f.is_file() and f.suffix in ['.cc','.h','.py','.json','.map','.txt']:
   t.add(f,arcname=str(f.relative_to(p)))
'''.replace('REMOTE',repr(REMOTE))
r=subprocess.run(['ssh','kiro@172.22.10.198','/usr/bin/python3 -'],input=code.encode(),stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=60)
(OUT/(phase+'-collect.stderr.txt')).write_bytes(r.stderr)
if r.returncode:raise SystemExit(r.returncode)
archive=OUT/(phase+'-raw.tar.gz');archive.write_bytes(r.stdout)
with tarfile.open(archive) as t:
 for member in t.getmembers():
  target=(OUT/phase/member.name).resolve()
  if not target.is_relative_to((OUT/phase).resolve()):raise RuntimeError('unexpected archive path')
 t.extractall(OUT/phase,filter='data')
print(phase,len(r.stdout))
