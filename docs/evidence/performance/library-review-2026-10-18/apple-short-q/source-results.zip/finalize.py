"""Summarize the frozen negative result; never build/run a workload."""
from pathlib import Path
import hashlib,json,zipfile

OUT=Path(__file__).resolve().parent
ROOT=OUT.parents[2]
hashof=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
write=lambda n,d:(OUT/n).write_text(json.dumps(d,indent=2)+'\n',encoding='utf-8')
baseline=json.loads((OUT/'measured/baseline-space.stdout.txt').read_text())
candidate=json.loads((OUT/'measured/candidate-space.stdout.txt').read_text())
identities=json.loads((OUT/'measured/runtime-identities.json').read_text())
remote='/Users/kiro/hyle-scratch/compute-unified/library-review-20261018-short-q/'
cleanup=[dict(path=p,**d) for p,d in identities.items() if p.startswith(remote)]
write('cleanup-candidates.json',dict(files=cleanup,count=len(cleanup),
    total_bytes=sum(x['bytes'] for x in cleanup),
    status='Candidates only; nothing deleted. Root must write exact removal in test.ps1 before cleanup.',
    keep='Original SDK/metallib/native cache, source snapshots, commands, maps, logs and result archive.'))
maps={}
for arm in ['baseline','candidate']:
 for kind in ['tests','space']:
  s=(OUT/'measured'/f'{arm}-{kind}.map').read_text()
  maps[arm+'-'+kind]=dict(fresh_object=(remote+arm+'.o') in s,
      old_apple_tensor_archive_member=any('libhyle_compute_route_apple.a' in line and
          'apple_tensor' in line for line in s.splitlines()))
summary=dict(
    status='negative_space_result; candidate_reverted; short-Q long-KV remains unresolved',
    baseline_commit=(OUT/'baseline-commit.txt').read_text().strip(),
    scope='One conservative short-Q extension of existing Apple GPU fallback Q16 blocks. No SDK/native/environment/tracing-eval change, no throughput measurement.',
    machine=dict(model='Mac16,12',chip='Apple M4',host='kiro@172.22.10.198',
        free_space_before='41GiB',compiler='Apple clang21.0.0',architecture='arm64',
        SDK='/Users/kiro/hyle-scratch/g09-air-direct-20261017/final-1dbfce9a0/apple-sdk'),
    attempted_change=dict(
        policy='Retain existing Q>=1024 policy. Short Q admitted only for original scores>=64MiB plus unchanged benefit/static-fallback/force/GPU/mask-admission rules.',
        safe_size='Compare batch*heads against divided Q*KV threshold, avoiding overflow of the four-dimension byte product.',
        native_fused='D2568<Q<1024 is a definite native fallback in the pinned selector, independently of NAX. Existing narrow force/native fused domains unchanged.',
        source_sha256=hashof(OUT/'apple_tensor.candidate.cc'),
        baseline_source_sha256=hashof(OUT/'apple_tensor.baseline.cc'),
        test_sha256=hashof(OUT/'attention_test.cc')),
    execution=dict(
        fresh_compilation='Only4 host TUs: baseline/candidate apple_tensor, targeted test TU and fixed space consumer;4 links. Original SDK/foundation/gtest/metallib reused.',
        targeted_tests='AppleAttention.ShortQueriesWithLongKvRetainFp32Reference:AppleAttention.UnsupportedFusedDomainsKeepTheirExistingFallback',
        test_result=dict(baseline_passed=2,candidate_passed=2),
        numerical_regression='Nonzero QK, F32 BSHD/GQA, Q129/KV32768/D256, full-KV bottom-right causal offset and1-row tail. Existing independent FP64 oracle and rel6e-6+abs2e-6 unchanged.',
        process_scope='One test executable invocation per arm; one independent space process per arm. No retries, AA/AB latency runs, block retuning, new shapes or follow-up workloads.',
        link_maps=maps),
    space=dict(
        shape='F32 B1/Hq4/Hkv2/D256, Q129/KV32768, causal,None mask input.',
        fixed_input='Q/K0; V+1.25 at even KV rows and-1.25 at odd rows, identical across heads/channels. Fixed before any execution.',
        oracle='FP64 alternating prefix sum / (KV-Q+t+1), every132096 output elements; abs(error)<=6e-6*abs(expected)+2e-6. Neither input nor budget changed after observing results.',
        metric='MLX allocator peak minus active-before-submit, including full output/native pending buffers. Public prepare/create_invocation/bind and caller inputs precede clear_cache/reset_peak; submit/wait/synchronize then sample. Not process RSS, whole-device VRAM or exact provider-private census.',
        baseline=baseline,candidate=candidate,
        extra_peak_delta_bytes=candidate['peak_minus_active_before']-baseline['peak_minus_active_before'],
        extra_peak_increase_fraction=candidate['peak_minus_active_before']/baseline['peak_minus_active_before']-1,
        interpretation='Unique sampled candidate point is516096B worse (about0.75%), despite both numerical oracles passing. Do not accept the threshold expansion as a memory optimization or infer universal regression from one pair.',
        theoretical_only='Full scores64.5MiB versus one16-row scores8MiB/9blocks does not predict actual peak.'),
    mechanism_limits=[
        'Pinned MLX retains primitive inputs to command-buffer completion. depends sequences evaluation; it does not force GPU retirement or a one-block peak.',
        'Native40-operation/40MiB commit thresholds and asynchronous completion are mechanism context only. Peak totals do not isolate an exact cause for the516096B difference.',
        'No further environment/SDK/block-size/synchronization tuning attempted after the negative result.',
        'Existing separate Q2048/KV2048 uniformV1.25 F32 large-space oracle failed on both variants in apple-nax-capability; unchanged and unresolved. This alternating-input success does not supersede it.',
        'No full Apple/Graph suite, other hardware, whole HEAD SDK rebuild or throughput claim.'
    ],
    product='Frozen candidate source/test/diff retained. Precisely restored only src/compute_route_apple/apple_tensor.cc and tests/compute_route_apple/attention_test.cc to907247284. git diff --exit-code for these paths returned0; unrelated CPU/time edits preserved.',
    cleanup='cleanup-candidates.json;8 new remote objects/executables only, original SDK/caches preserved; no deletion performed.')
write('summary.json',summary)
archive=OUT/'source-results.zip'
files=sorted(p for p in OUT.rglob('*') if p.is_file() and p.name not in
             ['source-results.zip','archive-record.json','measured-raw.tar.gz'])
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for p in files:z.write(p,str(p.relative_to(OUT)))
write('archive-record.json',dict(path=str(archive.relative_to(ROOT)),bytes=archive.stat().st_size,
    sha256=hashof(archive),files=len(files),scope='Small source/commands/logs/maps/summary/identities only. No objects/executables/SDK copies.'))
print((OUT/'archive-record.json').read_text())
print('cleanup',len(cleanup),sum(x['bytes'] for x in cleanup))
