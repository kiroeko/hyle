from pathlib import Path
import json,subprocess
OUT=Path(__file__).resolve().parent
ROOT=OUT.parents[2]
REMOTE='/Users/kiro/hyle-scratch/compute-unified/library-review-20261018-short-q'
HOST='kiro@172.22.10.198'
(OUT/'apple_tensor.candidate.cc').write_bytes((ROOT/'src/compute_route_apple/apple_tensor.cc').read_bytes())
(OUT/'attention_test.cc').write_bytes((ROOT/'tests/compute_route_apple/attention_test.cc').read_bytes())
runner=(OUT.parent/'apple-nax-capability/validate_remote.py').read_text(encoding='utf-8')
runner=runner.replace('AppleAttention.LongCausalD256RetainsFp32Reference:','AppleAttention.ShortQueriesWithLongKvRetainFp32Reference:')
# Preserve both independent space-process results even if one oracle fails.
runner=runner.replace('def run(tag,cmd):','def run(tag,cmd,required=True):')
runner=runner.replace(' if p.returncode:\n',' if p.returncode and required:\n')
runner=runner.replace("for arm in ['baseline','candidate']:run(arm+'-space',[OUT/(arm+'-space')])", "for arm in ['baseline','candidate']:run(arm+'-space',[OUT/(arm+'-space')],required=False)")
(OUT/'validate_remote.py').write_text(runner,encoding='utf-8')
q=subprocess.run(['ssh',HOST,'mkdir -p '+REMOTE],capture_output=True)
assert q.returncode==0,q.stderr
for name in ['apple_tensor.baseline.cc','apple_tensor.candidate.cc','attention_test.cc','space.cc','validate_remote.py']:
 subprocess.run(['scp',str(OUT/name),HOST+':'+REMOTE+'/'+name],check=True)
# One execution of each of the two targeted tests per arm, then one space
# process per arm. No native build, environment override or automatic retry.
r=subprocess.run(['ssh',HOST,'cd '+REMOTE+' && /usr/bin/python3 validate_remote.py --build --tests --space'],capture_output=True,timeout=240)
(OUT/'validation.stdout.txt').write_bytes(r.stdout)
(OUT/'validation.stderr.txt').write_bytes(r.stderr)
print(r.stdout.decode(errors='replace'));print(r.stderr.decode(errors='replace'))
raise SystemExit(r.returncode)
