#include "hyle/compute/state_versions.h"
#include <array>
#include <chrono>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <vector>
#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#include <windows.h>

namespace c = hyle::compute;
namespace m = hyle::mem;
using Clock = std::chrono::steady_clock;

void require(bool value) { if (!value) std::abort(); }
void check(const c::StateStoreStats &s, std::uint32_t n) {
  require(s.versions == 1 && s.drafts == 0 && s.retained_blocks == n && s.backing_roots == 1);
  require(s.registered_clone_slots == 0 && s.active_clones == 0 && s.backing_bytes == n * 64u);
  require(s.host_snapshot_bytes == 0 && s.clone_capacity_bytes == 0 && !s.closed);
}
void sample(std::uint32_t count, bool prefix) {
  const auto desc = c::TensorDesc::dense(c::DataType::kFloat32, std::array<std::int64_t, 1>{4}).value();
  std::vector<c::StateEntrySpec> specs(count, {.description = desc});
  auto schema = c::StateSchema::create(specs).value();
  auto store = c::StateStore::create(schema, {.max_versions = 2, .max_drafts = 1,
      .max_retained_blocks = 2 * count}).value();
  auto import = [&](c::LeasePool &pool, std::vector<c::StateMember> &members) {
    for (std::uint32_t i = 0; i < count; ++i) {
      auto writer = pool.allocate(16, 64).value();
      require(writer.view()->fill(std::byte{7}).ok());
      members.push_back({schema.entry(i).value(), writer.publish().value()});
    }
    return store.import(members).value();
  };
  auto old_pool = c::LeasePool::create(m::system_resource(), count * 64u,
      {.max_blocks = count, .backing_alignment = 64}).value();
  auto live_pool = c::LeasePool::create(m::system_resource(), count * 64u,
      {.max_blocks = count, .backing_alignment = 64}).value();
  std::vector<c::StateMember> old_members, live_members;
  c::StateVersion old;
  if (prefix) old = import(old_pool, old_members);
  auto live = import(live_pool, live_members);
  if (prefix) {
    const auto before = store.stats();
    require(before.versions == 2 && before.retained_blocks == 2 * count && before.backing_roots == 2);
    require(before.backing_bytes == count * 128u);
    old.reset(); old_members.clear(); require(store.collect().ok());
  }
  check(store.stats(), count);
  const auto rounds = prefix ? (count == 128 ? 2048u : 64u) : 8192u;
  std::uint64_t checksum = 0;
  for (unsigned i = 0; i < 8; ++i) check(store.stats(), count);
  const auto begin = Clock::now();
  for (unsigned i = 0; i < rounds; ++i) {
    const auto s = store.stats();
    checksum += s.versions + s.drafts + s.retained_blocks + s.backing_roots +
        s.registered_clone_slots + s.active_clones + s.backing_bytes +
        s.host_snapshot_bytes + s.clone_capacity_bytes + std::uint64_t(s.closed);
  }
  const auto elapsed = std::chrono::duration<double, std::nano>(Clock::now() - begin).count();
  check(store.stats(), count);
  require(checksum == std::uint64_t(rounds) * (2u + count + count * 64u));
  std::printf("{\"shape\":\"%s\",\"live_blocks\":%u,\"prefix_holes\":%u,\"ledger_capacity\":%u,"
      "\"rounds\":%u,\"total_ns\":%.0f,\"ns_per_call\":%.6f,\"checksum\":%llu,"
      "\"stats\":{\"versions\":1,\"drafts\":0,\"retained_blocks\":%u,\"backing_roots\":1,"
      "\"registered_clone_slots\":0,\"active_clones\":0,\"backing_bytes\":%u,"
      "\"host_snapshot_bytes\":0,\"clone_capacity_bytes\":0,\"closed\":false}}\n",
      prefix ? "collected-prefix" : "dense-control", count, prefix ? count : 0u, 2 * count,
      rounds, elapsed, elapsed / rounds, static_cast<unsigned long long>(checksum), count, count * 64u);
}
int main() {
  require(SetThreadAffinityMask(GetCurrentThread(), DWORD_PTR{1} << 4) != 0);
  LARGE_INTEGER frequency; require(QueryPerformanceFrequency(&frequency) != 0);
  std::printf("{\"host\":{\"logical_cpu\":4,\"qpc_frequency_hz\":%lld}}\n", frequency.QuadPart);
  sample(128, true); sample(2048, true); sample(2048, false);
}
