from pathlib import Path
import hashlib, json, os, re, shlex, subprocess, sys, time

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]
BUILD = ROOT / '.scratch/build-compute-v2-dev'
sys.path.insert(0, str(ROOT / 'scripts'))
from hyle_environment import windows_compiler_environment
from hyle_support import read_cache
cache = read_cache(BUILD)
env = windows_compiler_environment(cache)
env['VSLANG'] = '1033'
cl = cache['CMAKE_CXX_COMPILER']
link = str(Path(cl).with_name('link.exe'))
flags = ['/nologo', '/c', '/DWIN32', '/D_WINDOWS', '/EHsc', '/O2', '/Ob2', '/DNDEBUG',
         '/std:c++latest', '/MD', '/W4', '/permissive-', '/wd4324', '/WX', '/Zc:__cplusplus',
         '/utf-8', '/Zc:preprocessor', '/DHYLE_STATIC', '/I' + str(ROOT / 'include')]
ninja = (BUILD / 'build.ninja').read_text()
block = ninja.split('build bin\\hyle_compute_state_test.exe:', 1)[1].split('\n\n', 1)[0]
test_libs = shlex.split(re.search(r'^  LINK_LIBRARIES = (.*)$', block, re.M).group(1), posix=False)
test_libs = [x.strip('"') for x in test_libs if x != r'bin\hyle_compute_state.lib']
probe_libs = [str(BUILD / 'bin' / (n + '.lib')) for n in [
    'hyle_compute', 'hyle_compute_ops', 'hyle_mem', 'hyle_platform', 'hyle_error', 'mimalloc_static']]
probe_libs += ['bcrypt.lib', 'PowrProf.lib', 'advapi32.lib', 'ws2_32.lib', 'userenv.lib', 'psapi.lib']

def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def run(tag, command, timeout=120):
    (OUT / (tag + '-command.json')).write_text(json.dumps(command, indent=2))
    begin = time.time()
    p = subprocess.run(command, cwd=BUILD, env=env, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                       timeout=timeout)
    (OUT / (tag + '.stdout.txt')).write_bytes(p.stdout)
    (OUT / (tag + '.stderr.txt')).write_bytes(p.stderr)
    (OUT / (tag + '-exit.json')).write_text(json.dumps({'exit': p.returncode, 'wall_seconds': time.time()-begin}))
    print(tag, p.returncode)
    if p.returncode:
        print(p.stdout.decode('utf-8', errors='replace')); print(p.stderr.decode('utf-8', errors='replace'))
        raise SystemExit(p.returncode)
    return p.stdout.decode('utf-8', errors='replace')

if '--build' in sys.argv:
    (OUT / 'state_versions.candidate.cc').write_bytes((ROOT / 'src/compute_state/state_versions.cc').read_bytes())
    for variant in ['baseline', 'candidate']:
        run(variant + '-compile', [cl, *flags, '/DHYLE_COMPUTE_STATE_BUILD',
            '/I' + str(ROOT / 'src/compute_state'), '/Fo' + str(OUT / (variant + '.obj')),
            str(OUT / ('state_versions.' + variant + '.cc'))])
    run('probe-compile', [cl, *flags, '/Fo' + str(OUT / 'probe.obj'), str(OUT / 'state_prefix_probe.cc')])
    for variant in ['baseline', 'candidate']:
        run(variant + '-link', [link, '/nologo', '/machine:x64', '/INCREMENTAL:NO', '/subsystem:console',
            '/out:' + str(OUT / (variant + '.exe')), str(OUT / 'probe.obj'),
            str(OUT / (variant + '.obj')), *probe_libs])
    test_objs = []
    for test in ['state_versions_test.cc', 'state_clone_test.cc']:
        source_block = ninja.split('build tests\\compute_state\\CMakeFiles\\hyle_compute_state_test.dir\\' + test + '.obj:', 1)[1].split('\n\n', 1)[0]
        includes = shlex.split(re.search(r'^  INCLUDES = (.*)$', source_block, re.M).group(1), posix=False)
        obj = OUT / (test + '.obj'); test_objs.append(str(obj))
        run(test + '-compile', [cl, *flags, '/DHYLE_COMPUTE_CPU=1', *includes,
            '/Fo' + str(obj), str(ROOT / 'tests/compute_state' / test)])
    run('tests-link', [link, '/nologo', '/machine:x64', '/INCREMENTAL:NO', '/subsystem:console',
        '/out:' + str(OUT / 'state_tests.exe'), *test_objs, str(OUT / 'candidate.obj'), *test_libs])
    identity = {'baseline_source_sha256': sha(OUT/'state_versions.baseline.cc'),
        'candidate_source_sha256': sha(OUT/'state_versions.candidate.cc'), 'cl': cl,
        'cache': str(BUILD), 'cache_libraries_sha256': {str(p):sha(p) for p in
        [Path(x) for x in probe_libs if Path(x).is_absolute()]},
        'binary_sha256': {name:sha(OUT/name) for name in ['baseline.exe','candidate.exe','state_tests.exe']},
        'scope': 'Only fresh state_versions TU plus fresh public probe/test TUs; shared existing foundation static libraries. No CMake configure/build or SDK staging.'}
    (OUT/'identity.json').write_text(json.dumps(identity, indent=2))
if '--tests' in sys.argv:
    text = run('tests', [str(OUT/'state_tests.exe'), '--gtest_filter=StateVersions.*:StateClone.*'])
    print(text)
if '--perf' in sys.argv:
    results=[]
    for tag, variant in [('pair1-ab-baseline','baseline'),('pair1-ab-candidate','candidate'),
                         ('pair2-ba-candidate','candidate'),('pair2-ba-baseline','baseline')]:
        text = run(tag, [str(OUT/(variant+'.exe'))])
        rows=[json.loads(line) for line in text.splitlines() if line.startswith('{')]
        results.append({'tag':tag, 'variant':variant, 'rows':rows})
        print(text)
    (OUT/'raw.json').write_text(json.dumps(results, indent=2))
