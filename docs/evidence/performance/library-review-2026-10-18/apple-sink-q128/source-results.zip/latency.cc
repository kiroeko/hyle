#include "tests/compute_route_apple/tensor_test_support.h"
#include "hyle/compute/model_ops.h"
#include <array>
#include <chrono>
#include <cstdint>
#include <iomanip>
#include <iostream>
#include <stdexcept>

namespace {
using namespace apple_tensor_test;
constexpr int kDepth = 512, kQueries = 1025, kKeys = 2049, kHeads = 64;
std::vector<std::int64_t> samples;

[[noreturn]] void fail(const hyle::Status &status) {
  throw std::runtime_error(std::string(status.message()));
}

double check(const mx::array &output) {
  if (output.shape() != mx::Shape{1, kQueries, kHeads, kDepth})
    throw std::runtime_error("Sink output shape mismatch");
  const float *data = output.data<float>();
  const double expected = 1.25 / double(kKeys + 1);
  double maximum_error = 0;
  for (int t = 0; t < kQueries; ++t)
    for (int h = 0; h < kHeads; ++h)
      for (int d = 0; d < kDepth; ++d) {
        const auto offset = std::size_t(t) * output.strides(1) +
            std::size_t(h) * output.strides(2) + std::size_t(d) * output.strides(3);
        const double actual = data[offset];
        const double error = std::abs(actual - expected);
        if (!std::isfinite(actual) || error > 6e-6 * std::abs(expected) + 2e-6)
          throw std::runtime_error("Sink full FP64 oracle exceeds original budget");
        maximum_error = std::max(maximum_error, error);
      }
  return maximum_error;
}

double invoke(a::Invocation &slot, bool timed, bool oracle) {
  const auto begin = std::chrono::steady_clock::now();
  auto accepted = slot.submit();
  if (!accepted) fail(accepted.error());
  auto ready = accepted->wait();
  const auto end = std::chrono::steady_clock::now();
  if (!ready) fail(ready.error());
  if (timed) samples.push_back(std::chrono::duration_cast<std::chrono::nanoseconds>(end - begin).count());
  // The complete oracle is outside timing. This scope also releases the
  // ResultLease and OwnedResult before the next submission reuses this slot.
  return oracle ? check(ready->get()->arrays()[0]) : 0;
}
}

int main() {
  using namespace apple_tensor_test;
  try {
    auto zeros = [](mx::Shape shape) {
      std::size_t count = 1;
      for (int n : shape) count *= std::size_t(n);
      std::vector<float> data(count);
      return mx::array(data.data(), std::move(shape), mx::float32);
    };
    std::vector<float> v(std::size_t(kKeys) * kDepth);
    for (int s = 0; s < kKeys; ++s)
      std::fill_n(v.begin() + std::size_t(s) * kDepth, kDepth, s % 2 == 0 ? 1.25F : -1.25F);
    const std::array inputs{
        zeros({1, kQueries, kHeads, kDepth}), zeros({1, kKeys, 1, kDepth}),
        mx::array(v.data(), {1, kKeys, 1, kDepth}, mx::float32),
        zeros({kQueries, kKeys}), zeros({kHeads})};
    auto created = a::Context::create();
    if (!created) fail(created.error());
    auto context = std::move(*created);
    auto prepared = context.prepare(c::model_ops::sink_attention(0.0625F), inputs);
    if (!prepared) fail(prepared.error());
    auto program = std::move(*prepared);
    auto made = program.create_invocation();
    if (!made) fail(made.error());
    auto slot = std::move(*made);
    const auto bound = slot.bind(inputs);
    if (!bound.ok()) fail(bound);
    samples.reserve(9);
    invoke(slot, false, false);
    invoke(slot, false, false);
    const double before_error = invoke(slot, false, true);
    for (int sample = 0; sample < 9; ++sample) invoke(slot, true, false);
    const double after_error = invoke(slot, false, true);
    const auto closed = context.close();
    if (!closed.ok()) fail(closed);
    std::cout << std::setprecision(17)
        << "{\"dtype\":\"F32\",\"B\":1,\"H\":64,\"Hkv\":1,\"D\":512,\"Q\":1025,\"KV\":2049,"
           "\"warm_invocations\":2,\"oracle_elements_each\":33587200,\"oracle_before_maxabs\":"
        << before_error << ",\"oracle_after_maxabs\":" << after_error
        << ",\"oracle_passed\":true,\"timed_submit_checkedwait_ns\":[";
    for (std::size_t i = 0; i < samples.size(); ++i) {
      if (i) std::cout << ',';
      std::cout << samples[i];
    }
    std::cout << "]}\n";
    return 0;
  } catch (const std::exception &error) {
    std::cerr << error.what() << '\n';
    std::cout << "{\"failed\":true,\"completed_timed_samples_ns\":[";
    for (std::size_t i = 0; i < samples.size(); ++i) {
      if (i) std::cout << ',';
      std::cout << samples[i];
    }
    std::cout << "]}\n";
    return 4;
  }
}
