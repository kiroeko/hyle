from pathlib import Path
import difflib
import hashlib
import json

OUT=Path(__file__).resolve().parent
ROOT=OUT.parents[2]
files=['include/hyle/compute/detail/apple_plan.h','src/compute_route_apple/apple_context.cc',
       'src/compute_route_apple/apple_operations.cc','src/graph_route_apple/apple_lowering.cc']
support=['include/hyle/compute/apple.h','src/compute_route_apple/apple_checks.h',
         'src/compute_route_apple/apple_completion_internal.h','src/compute_route_apple/apple_internal.h',
         'src/compute_route_apple/apple_runtime_internal.h','src/compute_route_apple/apple_recurrent.h',
         'src/compute_route_apple/apple_tensor.h','src/compute/completion_internal.h',
         'src/compute_provider_ggml_metal/native_program.h','src/graph/native_analysis.h']
for name in files:
    for arm in ['baseline','candidate']:
        dest=OUT/arm/name;dest.parent.mkdir(parents=True,exist_ok=True)
        dest.write_bytes((ROOT/name).read_bytes())
for name in support:
    dest=OUT/'support'/name;dest.parent.mkdir(parents=True,exist_ok=True)
    dest.write_bytes((ROOT/name).read_bytes())

def edit(name,old,new):
    p=OUT/'candidate'/name;s=p.read_text(encoding='utf-8')
    assert s.count(old)==1,(name,old[:90],s.count(old))
    p.write_text(s.replace(old,new),encoding='utf-8',newline='\n')

header=files[0];context=files[1];operations=files[2];graph=files[3]
edit(header,'enum class RegionKind { kMlx, kGgml };','enum class RegionKind { kMlx, kGgml, kSinkBlocks };\n\n'
    'HYLE_COMPUTE_ROUTE_APPLE_API bool\n'
    'is_mlx_sink_blocks(const Operation &, std::span<const TensorDesc>) noexcept;')
edit(operations,'Result<Program>\nContext::prepare(const Operation &operation,\n',
'''bool detail::is_mlx_sink_blocks(const Operation &operation,
    std::span<const TensorDesc> inputs) noexcept {
  const auto sink=operation.custom_as<model_ops::SinkAttention>();
  if (!sink) return false;
  std::array<TensorDesc,1> outputs;
  if (!sink->infer_output_descriptions(inputs,outputs).ok()) return false;
  const auto rows=inputs[0].dimensions()[1],keys=inputs[1].dimensions()[1];
  return rows>=1024 && (rows-128)*keys>2*rows*512;
}

Result<Program>
Context::prepare(const Operation &operation,
''')
edit(operations,'    if (fixed_ggml_model_operation(operation) ||\n',
     '    if (operation.custom_as<model_ops::SinkAttention>() ||\n        fixed_ggml_model_operation(operation) ||\n')
edit(operations,'    if (ggml_model_operation(operation, descriptions)) {\n',
     '    const bool sink_blocks=detail::is_mlx_sink_blocks(operation,descriptions);\n'
     '    if (sink_blocks || ggml_model_operation(operation, descriptions)) {\n')
edit(operations,'      region.kind = detail::RegionKind::kGgml;\n',
     '      region.kind = sink_blocks ? detail::RegionKind::kSinkBlocks : detail::RegionKind::kGgml;\n')

edit(context,'struct PreparedPlan {\n',
'''struct SinkBlocks {
  MlxProgram full;
  std::optional<MlxProgram> tail;
  int rows=0;
};

struct PreparedPlan {
''')
edit(context,'  std::vector<std::optional<MlxProgram>> mlx;\n',
     '  std::vector<std::optional<MlxProgram>> mlx;\n  std::vector<std::optional<SinkBlocks>> sinks;\n')
edit(context,'  std::vector<mx::array> region_outputs;\n',
     '  std::vector<mx::array> region_outputs;\n  std::vector<mx::array> sink_arguments, sink_outputs, sink_blocks;\n')
edit(context,'Status execute_plan(InvocationState &state, mx::Stream stream) {\n',
'''Status evaluate_sink_blocks(const SinkBlocks &program, InvocationState &state,
                            mx::Stream stream) {
  const auto &ports=state.arguments;
  auto &args=state.sink_arguments;
  auto &outputs=state.sink_outputs;
  auto &blocks=state.sink_blocks;
  blocks.clear();
  for (int begin=0;begin<program.rows;) {
    const int end=begin+std::min(128,program.rows-begin);
    args.clear();
    auto first=mx::Shape(4,0),last=ports[0].shape();
    first[1]=begin;last[1]=end;
    args.push_back(mx::slice(ports[0],first,last,stream));
    args.push_back(ports[1]);args.push_back(ports[2]);
    args.push_back(mx::slice(ports[3],{begin,0},{end,ports[3].shape(1)},stream));
    args.push_back(ports[4]);
    const auto &part=end-begin==128 ? program.full : *program.tail;
    HYLE_RETURN_IF_ERROR(evaluate_mlx(part,args,outputs,stream));
    blocks.push_back(std::move(outputs[0]));
    outputs.clear();args.clear();
    begin=end;
  }
  state.region_outputs.clear();
  state.region_outputs.push_back(mx::concatenate(blocks,1,stream));
  mx::async_eval(state.region_outputs);
  mx::synchronize(stream);
  for(auto &output:state.region_outputs)output.wait();
  blocks.clear();
  return Status::Ok();
}

Status execute_plan(InvocationState &state, mx::Stream stream) {
''')
edit(context,'''    } else {
      HYLE_ASSIGN_OR_RETURN(state.region_outputs,
                            state.recurrent[i]->run(state.arguments, stream));''',
'''    } else if (region.kind == RegionKind::kSinkBlocks) {
      HYLE_RETURN_IF_ERROR(evaluate_sink_blocks(*prepared.sinks[i],state,stream));
    } else {
      HYLE_ASSIGN_OR_RETURN(state.region_outputs,
                            state.recurrent[i]->run(state.arguments, stream));''')
edit(context,'      } else if (region.kind == RegionKind::kGgml) {\n',
     '      } else if (region.kind == RegionKind::kGgml || region.kind == RegionKind::kSinkBlocks) {\n')
edit(context,'''        HYLE_RETURN_IF_ERROR(ggml_metal::NativeProgram::validate(
            region.operation, region.native_inputs));''',
'''        if(region.kind==RegionKind::kGgml) {
          HYLE_RETURN_IF_ERROR(ggml_metal::NativeProgram::validate(
              region.operation, region.native_inputs));
        } else if(!is_mlx_sink_blocks(region.operation,region.native_inputs)) {
          return std::unexpected(Status::InvalidArgument("invalid Apple Sink block region"));
        }''')
edit(context,'"Apple ggml region arity mismatch"','"Apple native region arity mismatch"')
edit(context,'    prepared.mlx.resize(prepared.description.regions.size());\n',
     '    prepared.mlx.resize(prepared.description.regions.size());\n'
     '    prepared.sinks.resize(prepared.description.regions.size());\n')
edit(context,'''          auto &mlx = prepared.mlx[i].emplace();
          auto outputs = prepare_mlx(mlx, std::move(region.mlx), specs, stream);''',
'''          if(region.kind==RegionKind::kSinkBlocks) {
            auto &sink=prepared.sinks[i].emplace();
            sink.rows=specs[0].shape[1];
            auto build=[operation=region.operation,workload=program->workload]
                (const auto &args,mx::Stream native_stream) {
              return lower(operation,args,native_stream,workload);
            };
            const auto prepare_part=[&](MlxProgram &part,int rows) -> Status {
              auto part_specs=specs;
              part_specs[0].shape[1]=rows;part_specs[0].logical_description={};
              part_specs[3].shape[0]=rows;part_specs[3].logical_description={};
              auto outputs=prepare_mlx(part,build,part_specs,stream);
              if(outputs.size()!=1 || outputs[0].shape()!=part_specs[0].shape ||
                 outputs[0].dtype()!=mx::float32)
                return Status::InvalidArgument("Apple Sink block schema mismatch");
              return Status::Ok();
            };
            HYLE_RETURN_IF_ERROR(prepare_part(sink.full,128));
            if(const int tail=sink.rows%128;tail!=0)
              HYLE_RETURN_IF_ERROR(prepare_part(sink.tail.emplace(),tail));
            continue;
          }
          auto &mlx = prepared.mlx[i].emplace();
          auto outputs = prepare_mlx(mlx, std::move(region.mlx), specs, stream);''')
edit(context,'      state->arguments.reserve(max_inputs);\n',
'''      state->arguments.reserve(max_inputs);
      state->sink_arguments.reserve(5);state->sink_outputs.reserve(1);
      std::size_t max_sink_blocks=0;
      for(const auto &sink:state_->native->sinks)
        if(sink)max_sink_blocks=std::max(max_sink_blocks,
            static_cast<std::size_t>((sink->rows-1)/128+1));
      state->sink_blocks.reserve(max_sink_blocks);
''')
edit(context,'  finish(state, std::move(terminal));\n',
'''  // evaluate_mlx/execute_with have drained every accepted prefix before
  // temporary block owners are released. Whole-Job ports/uses retire in finish.
  state.sink_arguments.clear();state.sink_outputs.clear();state.sink_blocks.clear();
  finish(state, std::move(terminal));
''')

edit(graph,'Status match(const compute::TensorDesc &description, const mx::array &value) {\n',
'''bool sink_blocks_operation(const Plan &plan,const Node &node) {
  if(!node.operation.custom_as<compute::model_ops::SinkAttention>() || node.inputs.size()!=5)
    return false;
  std::array<compute::TensorDesc,5> inputs;
  for(std::size_t i=0;i<inputs.size();++i)inputs[i]=plan.descriptions[node.inputs[i]];
  return ca::detail::is_mlx_sink_blocks(node.operation,inputs);
}

Status match(const compute::TensorDesc &description, const mx::array &value) {
''')
edit(graph,'    if (ggml_model_operation(*plan, first)) {\n      region.kind = ca::detail::RegionKind::kGgml;\n',
'''    const bool sink_blocks=sink_blocks_operation(*plan,first);
    if (sink_blocks || ggml_model_operation(*plan, first)) {
      region.kind = sink_blocks ? ca::detail::RegionKind::kSinkBlocks : ca::detail::RegionKind::kGgml;
''')
edit(graph,'           !ggml_model_operation(*plan, plan->nodes[end]))\n',
     '           !ggml_model_operation(*plan, plan->nodes[end]) &&\n'
     '           !sink_blocks_operation(*plan,plan->nodes[end]))\n')
edit(graph,'    if (has_native_model_region || has_control) {\n',
'''    const bool has_sink_blocks=std::ranges::any_of(plan->nodes,
        [&](const auto &node){return sink_blocks_operation(*plan,node);});
    if (has_native_model_region || has_control || has_sink_blocks) {
''')
edit(graph,'            : "Original MLX compiled regions split at explicit control endpoints; fixed cold binding";\n',
     '            : has_sink_blocks ? "Original MLX compiled regions and private checked Sink blocks; fixed cold binding"\n'
     '            : "Original MLX compiled regions split at explicit control endpoints; fixed cold binding";\n')
for name in files:
    b=(OUT/'baseline'/name).read_text(encoding='utf-8');c=(OUT/'candidate'/name).read_text(encoding='utf-8')
    p=OUT/(Path(name).name+'.diff')
    p.write_text(''.join(difflib.unified_diff(b.splitlines(True),c.splitlines(True),
        fromfile='baseline/'+name,tofile='candidate/'+name)),encoding='utf-8')
for name in ['sink_tests.cc','space.cc']:
    (OUT/name).write_bytes((OUT.parent/'apple-sink'/name).read_bytes())
(OUT/'latency.cc').write_bytes((OUT.parent/'apple-sink-compact/latency.cc').read_bytes())
(OUT/'frozen-source-sha256.json').write_text(json.dumps({str(p.relative_to(OUT)):hashlib.sha256(p.read_bytes()).hexdigest()
    for p in OUT.rglob('*') if p.is_file() and p.suffix in ['.h','.cc','.diff']},indent=2)+'\n',encoding='utf-8')
print('Scratch paired current-source baseline/candidate prepared; canonical unchanged')
