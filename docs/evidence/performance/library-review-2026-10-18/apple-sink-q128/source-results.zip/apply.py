from pathlib import Path
import difflib
import hashlib
import json

OUT=Path(__file__).resolve().parent
ROOT=OUT.parents[2]
products=['include/hyle/compute/detail/apple_plan.h','src/compute_route_apple/apple_context.cc',
          'src/compute_route_apple/apple_operations.cc','src/graph_route_apple/apple_lowering.cc']
for name in products:
    assert (ROOT/name).read_bytes()==(OUT/'baseline'/name).read_bytes(), 'Unrelated change in '+name
for name in products:
    (ROOT/name).write_bytes((OUT/'candidate'/name).read_bytes())

source=(OUT/'sink_tests.cc').read_text(encoding='utf-8')
helpers=source[source.index('constexpr int kSinkDepth'):source.index('TEST(AppleSinkAttention,')]
helpers=helpers.replace('constexpr int kSinkDepth','inline constexpr int kSinkDepth')
helpers=helpers.replace('constexpr float kSinkScale','inline constexpr float kSinkScale')
for marker in ['float sink_query','float sink_key','float sink_mask','float sink_logit',
               'std::array<mx::array, 5> sink_ports','std::vector<SinkExpectedRow> sink_reference',
               'std::uint64_t sink_output_hash','void check_sink']:
    assert helpers.count(marker)==1,marker
    helpers=helpers.replace(marker,'inline '+marker)
header='''#pragma once

#include "tensor_test_support.h"
#include "hyle/compute/model_ops.h"

#include <algorithm>
#include <bit>
#include <cstdio>
#include <limits>

namespace apple_tensor_test {
// Independent FP64 oracle for the existing five-port F32 Sink contract.
// The two nonzero Q/K channels and separable dyadic V keep full-output checks
// practical without deriving expected values from a provider result.
'''+helpers+'} // namespace apple_tensor_test\n'
header_path=ROOT/'tests/compute_route_apple/sink_attention_test_support.h'
assert not header_path.exists()
header_path.write_text(header,encoding='utf-8',newline='\n')

direct=ROOT/'tests/compute_route_apple/tensor_test.cc'
direct_before=direct.read_text(encoding='utf-8')
assert 'TEST(AppleSinkAttention,' not in direct_before
body=source[source.index('TEST(AppleSinkAttention,'):source.rindex('} // namespace')]
direct_after=direct_before+'\n#include "sink_attention_test_support.h"\n\nnamespace {\nusing namespace apple_tensor_test;\n\n'+body+'} // namespace\n'
direct.write_text(direct_after,encoding='utf-8',newline='\n')

graph=ROOT/'tests/graph_route_apple/tensor_test.cc'
graph_before=graph.read_text(encoding='utf-8')
assert 'TEST(AppleSinkGraph,' not in graph_before
graph_section=(OUT/'graph_test.cc').read_text(encoding='utf-8')
graph_section=graph_section[graph_section.index('namespace {'):]
graph_section=graph_section.replace('namespace g=hyle::graph;','using namespace apple_tensor_test;\nnamespace sink_graph=hyle::graph;')
graph_section=graph_section.replace('namespace ga=g::apple;','namespace sink_graph_apple=sink_graph::apple;')
graph_section=graph_section.replace('g::GraphBuilder','sink_graph::GraphBuilder').replace('g::ValueId','sink_graph::ValueId')
graph_section=graph_section.replace('ga::compile','sink_graph_apple::compile')
graph_after=graph_before+'\n#include "../compute_route_apple/sink_attention_test_support.h"\n\n'+graph_section
graph.write_text(graph_after,encoding='utf-8',newline='\n')

for name in products+['tests/compute_route_apple/tensor_test.cc','tests/graph_route_apple/tensor_test.cc',
                      'tests/compute_route_apple/sink_attention_test_support.h','tests/compute_route_apple/tensor_test_support.h']:
    dest=OUT/'applied'/name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes((ROOT/name).read_bytes())
identity=[]
for name in products:
    tested=(OUT/'candidate'/name).read_bytes();applied=(ROOT/name).read_bytes()
    identity.append(dict(path=name,identical=tested==applied,
                         sha256=hashlib.sha256(applied).hexdigest()))
(OUT/'tested-to-applied-products.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8')
(OUT/'tested-to-applied-products.diff').write_text(''.join(''.join(difflib.unified_diff(
    (OUT/'candidate'/name).read_text(encoding='utf-8').splitlines(True),(ROOT/name).read_text(encoding='utf-8').splitlines(True),
    fromfile='tested/'+name,tofile='applied/'+name)) for name in products),encoding='utf-8')
(OUT/'test-migration.json').write_text(json.dumps(dict(
    helpers='Original helper bodies moved unchanged, adding only inline/header namespace.',
    direct='Original two TEST bodies unchanged; helper now shared test-only header.',
    graph='Same original Graph TEST body; only private namespace aliases/include paths changed.',
    files=['tests/compute_route_apple/tensor_test.cc','tests/graph_route_apple/tensor_test.cc',
           'tests/compute_route_apple/sink_attention_test_support.h']),indent=2)+'\n',encoding='utf-8')
print('Four tested product files applied byte-for-byte; three regressions migrated to two existing test TUs')
