from pathlib import Path
import hashlib
import json
import subprocess
import sys

OUT=Path(__file__).resolve().parent
OLD=OUT.parent/'library-review-20261018-apple-sink'
COMPACT=OUT.parent/'library-review-20261018-apple-sink-compact'
SDK=Path('/Users/kiro/hyle-scratch/g09-air-direct-20261017/final-1dbfce9a0/apple-sdk')
BLOCKS=OUT.parent/'library-review-20261018-sdpa-blocks'
CORE=Path('/Users/kiro/hyle-scratch/compute-unified/a-cpu-apple/selected-graph/source-build')
GTEST=Path('/Users/kiro/Library/Caches/hyle/dependencies/v1/sources/googletest-063de7e9578f-162765170ae6/googletest/include')
base_flags=['-O3','-DNDEBUG','-std=c++23','-arch','arm64','-DHYLE_STATIC','-DMLX_STATIC','-DHYLE_COMPUTE_APPLE=1',
    '-DHYLE_COMPUTE_ROUTE_APPLE_API=','-DHYLE_GRAPH_ROUTE_APPLE_API=',
    '-Wall','-Wextra','-Wpedantic','-Werror',
    '-I'+str(OUT/'support/include'),'-I'+str(OUT/'support/src/compute_route_apple'),
    '-I'+str(OUT/'support/src/compute'),'-I'+str(OUT/'support/src/graph_route_apple'),
    '-I'+str(BLOCKS/'tests/compute_route_apple'),'-I'+str(BLOCKS),
    '-isystem',str(SDK/'include'),'-isystem',str(SDK/'include/metal_cpp'),'-isystem',str(GTEST)]
libs=[SDK/'lib'/('lib'+x+'.a') for x in ['hyle_graph','hyle_compute_route_apple','hyle_compute_stream',
    'hyle_compute_state','hyle_compute_batch','hyle_compute','hyle_compute_ops','hyle_simd','hyle_sched',
    'hyle_container','hyle_mem_vm','hyle_mem','mimalloc_static','hyle_platform_thread','hyle_time',
    'hyle_platform','hyle_error','hyle_compute_provider_ggml_metal','hyle_compute_ggml_runtime','ggml',
    'ggml-metal','ggml-base','mlx']]
frameworks=['-framework','Foundation','-framework','Metal','-framework','MetalKit','-framework','QuartzCore']
def run(tag,cmd,required=True):
    cmd=list(map(str,cmd))
    try:
        p=subprocess.run(cmd,cwd=OUT,capture_output=True,timeout=180)
        code,stdout,stderr=p.returncode,p.stdout,p.stderr
    except subprocess.TimeoutExpired as e:
        code,stdout,stderr=-999,e.stdout or b'',e.stderr or b''
    if (OUT/(tag+'-command.json')).exists():
        attempt=1
        while (OUT/(tag+'-attempt'+str(attempt)+'-command.json')).exists():attempt+=1
        for suffix in ['-command.json','.stdout.txt','.stderr.txt']:
            (OUT/(tag+'-attempt'+str(attempt)+suffix)).write_bytes((OUT/(tag+suffix)).read_bytes())
    (OUT/(tag+'-command.json')).write_text(json.dumps(dict(command=cmd,cwd=str(OUT),exit=code),indent=2)+'\n')
    (OUT/(tag+'.stdout.txt')).write_bytes(stdout);(OUT/(tag+'.stderr.txt')).write_bytes(stderr)
    print(tag,code,flush=True)
    if code and required:
        print(stdout.decode(errors='replace'));print(stderr.decode(errors='replace'));raise SystemExit(code)
    return code

(OUT/'support/src/graph_route_apple').mkdir(parents=True,exist_ok=True)
if not (OUT/'mlx.metallib').exists():(OUT/'mlx.metallib').symlink_to(SDK/'lib/mlx.metallib')
if '--build' in sys.argv:
    for arm in ['baseline','candidate']:
        for name,source in [('context','src/compute_route_apple/apple_context.cc'),
                            ('operations','src/compute_route_apple/apple_operations.cc'),
                            ('graph','src/graph_route_apple/apple_lowering.cc')]:
            run(arm+'-'+name+'-compile',['/usr/bin/clang++','-I'+str(OUT/arm/'include'),*base_flags,
                '-c',OUT/arm/source,'-o',OUT/(arm+'-'+name+'.o')])
if '--graph-link' in sys.argv:
    run('candidate-context-compile',['/usr/bin/clang++','-I'+str(OUT/'candidate/include'),*base_flags,
        '-c',OUT/'candidate/src/compute_route_apple/apple_context.cc','-o',OUT/'candidate-context.o'])
if '--candidate-fix' in sys.argv:
    for name,source in [('context','src/compute_route_apple/apple_context.cc'),
                        ('graph','src/graph_route_apple/apple_lowering.cc')]:
        run('candidate-'+name+'-compile',['/usr/bin/clang++','-I'+str(OUT/'candidate/include'),*base_flags,
            '-c',OUT/'candidate'/source,'-o',OUT/('candidate-'+name+'.o')])
if any(flag in sys.argv for flag in ['--build','--graph-link','--link','--candidate-fix']):
    if '--candidate-fix' not in sys.argv:
        run('graph-test-compile',['/usr/bin/clang++',*base_flags,'-c',OUT/'graph_test.cc','-o',OUT/'graph-test.o'])
    for arm in ['baseline','candidate']:
        for kind,consumer in [('tests',OLD/'tests.o'),('graph-tests',OUT/'graph-test.o'),
                              ('space',OLD/'space.o'),('latency',COMPACT/'latency.o')]:
            run(arm+'-'+kind+'-link',['/usr/bin/clang++','-O3','-std=c++23','-o',OUT/(arm+'-'+kind),
                consumer,OUT/(arm+'-context.o'),OUT/(arm+'-operations.o'),OUT/(arm+'-graph.o'),
                OLD/'apple-baseline.o',*libs,
                *([CORE/'lib/libgtest_main.a'] if kind in ['tests','graph-tests'] else []),CORE/'lib/libgtest.a',
                *frameworks,'-Wl,-map,'+str(OUT/(arm+'-'+kind+'.map'))])
    products=[p for p in OUT.iterdir() if p.suffix=='.o' or p.name in [a+'-'+k for a in ['baseline','candidate']
              for k in ['tests','graph-tests','space','latency']]]
    reused=[OLD/'tests.o',OLD/'space.o',OLD/'apple-baseline.o',COMPACT/'latency.o']
    (OUT/'runtime-identities.json').write_text(json.dumps({str(p):dict(bytes=p.stat().st_size,
        sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in products+reused},indent=2)+'\n')
if '--tests' in sys.argv:
    exits={}
    for arm in ['baseline','candidate']:
        for kind,filt in [('tests','AppleSinkAttention.*'),('graph-tests','AppleSinkGraph.*')]:
            exits[arm+'-'+kind]=run(arm+'-'+kind,[OUT/(arm+'-'+kind),'--gtest_filter='+filt,
                '--gtest_output=json:'+str(OUT/(arm+'-'+kind+'.json'))],required=False)
    gate=dict(exitcodes=exits,passed=all(v==0 for v in exits.values()))
    (OUT/'control-gate.json').write_text(json.dumps(gate,indent=2)+'\n')
    if not gate['passed']:raise SystemExit(3)
if '--space' in sys.argv:
    assert json.loads((OUT/'control-gate.json').read_text())['passed']
    for arm in ['baseline','candidate']:run(arm+'-space',[OUT/(arm+'-space')],required=False)
if '--latency' in sys.argv:
    baseline=json.loads((OUT/'baseline-space.stdout.txt').read_text())
    candidate=json.loads((OUT/'candidate-space.stdout.txt').read_text())
    assert baseline['oracle_passed'] and candidate['oracle_passed']
    assert candidate['peak_minus_active_before']<baseline['peak_minus_active_before']
    for key,args in [('machine',['/usr/sbin/sysctl','-n','hw.model','hw.memsize','machdep.cpu.brand_string']),
        ('power',['/usr/bin/pmset','-g','batt']),('thermal',['/usr/bin/pmset','-g','therm'])]:
        run('latency-before-'+key,args,required=False)
    exits=[]
    for i,arm in enumerate(['baseline','candidate','candidate','baseline']):
        exits.append(run('latency-'+str(i)+'-'+arm,[OUT/(arm+'-latency')],required=False))
    for key,args in [('power',['/usr/bin/pmset','-g','batt']),('thermal',['/usr/bin/pmset','-g','therm'])]:
        run('latency-after-'+key,args,required=False)
    (OUT/'latency-order.json').write_text(json.dumps(dict(order=['baseline','candidate','candidate','baseline'],exitcodes=exits),indent=2)+'\n')
    if any(exits):raise SystemExit(4)
