from pathlib import Path
import hashlib
import json
import statistics
import zipfile

OUT=Path(__file__).resolve().parent
ROOT=OUT.parents[2]
RAW=OUT/'measured'
COMPARATIVE=OUT/'comparative-measured'
def load(name):return json.loads((RAW/name).read_text(encoding='utf-8'))
space={arm:load(arm+'-space.stdout.txt') for arm in ['baseline','candidate']}
controls={}
for arm in ['baseline','candidate']:
    controls[arm]={}
    for kind in ['tests','graph-tests']:
        j=load(arm+'-'+kind+'.json')
        numeric=[json.loads(s) for s in (RAW/(arm+'-'+kind+'.stdout.txt')).read_text().splitlines()
                 if s.startswith('{"kind":"sink_numeric"')]
        controls[arm][kind]=dict(tests=j['tests'],failures=j['failures'],numeric_observations=numeric)
latency=[]
for i,arm in enumerate(['baseline','candidate','candidate','baseline']):
    result=load('latency-'+str(i)+'-'+arm+'.stdout.txt')
    result.update(process_order=i,arm=arm,median_ns=statistics.median(result['timed_submit_checkedwait_ns']))
    latency.append(result)
maps={}
for arm in ['baseline','candidate']:
    for kind in ['tests','graph-tests','space','latency']:
        source=(COMPARATIVE/(arm+'-'+kind+'.map')).read_text()
        objects=source.split('# Object files:\n',1)[1].split('# Sections:',1)[0]
        maps[arm+'-'+kind]=dict(fresh_context='/'+arm+'-context.o' in objects,
            fresh_operations='/'+arm+'-operations.o' in objects,fresh_graph_lowering='/'+arm+'-graph.o' in objects,
            same_original_tensor_lowerer='/apple-baseline.o' in objects,
            sdk_context='(apple_context.cc.o)' in objects,sdk_operations='(apple_operations.cc.o)' in objects,
            sdk_graph_lowering='(apple_lowering.cc.o)' in objects)
assert all(m['fresh_context'] and m['fresh_operations'] and m['fresh_graph_lowering'] and
           m['same_original_tensor_lowerer'] and not m['sdk_context'] and not m['sdk_operations'] and
           not m['sdk_graph_lowering'] for m in maps.values())
(OUT/'link-map-check.json').write_text(json.dumps(maps,indent=2)+'\n',encoding='utf-8')
applied={}
for kind in ['direct','graph']:
    j=load('applied-'+kind+'-tests.json')
    applied[kind]=dict(tests=j['tests'],failures=j['failures'],disabled=j.get('disabled',0))
products=['include/hyle/compute/detail/apple_plan.h','src/compute_route_apple/apple_context.cc',
          'src/compute_route_apple/apple_operations.cc','src/graph_route_apple/apple_lowering.cc']
applied_identity=[]
for name in products:
    a=(ROOT/name).read_bytes();b=(OUT/'candidate'/name).read_bytes()
    assert a==b,name
    applied_identity.append(dict(path=name,identical_to_tested=True,sha256=hashlib.sha256(a).hexdigest()))
summary=dict(status='Q128_applied_and_root_committed; final_filtered_canonical_tests_passed',
    root_commit='e94f73c29',independent_ordinary_guard_commit='2f68636d0',
    machine=dict(host='kiro@172.22.10.198',model='Mac16,12',chip='Apple M4',
                 sdk='/Users/kiro/hyle-scratch/g09-air-direct-20261017/final-1dbfce9a0/apple-sdk'),
    selection='Only existing legal all-F32 five-port Sink B1/H64or128/KVhead1/D512; Q>=1024 and int64(Q-128)*KV>2*Q*512. Short/no-benefit shapes retain original pure MLX. This Q128 change does not alter ordinary attention/native/shader/dtype/TF32/environment; the independent ordinary force-scale guard commit is recorded separately.',
    execution='One existing owner Job and whole-Job Completion; private RegionPlan kind has full128 and tail compiled original fallback. Slice BSHD Q axis1 and caller global mask axis0; share full K/V/sinks. Each block uses existing evaluate_mlx async_eval+synchronize+wait, then clears temporary arguments and retains only its output. Final concat on axis1 uses one checked drain. No per-block cache clear, asynchronous activeJob, extra thread/queue or public setting.',
    interfaces=dict(
        direct='Both array-example and InputSpec prepare enter the same selected private RegionPlan; lower remains pure and unchanged.',
        graph='Selected Sink is a private region at first-node dispatch, maximal-MLX scanning stop and overall compile_regions selection. Ordinary MLX regions before/after remain; last_use, constants and published outputs use original plan.',
        lifetime='Same Invocation worker ref/program/input owners/ResultSlot/native lease uses/execute_with/finish. Error-path three chunk temporaries clear only after existing accepted-prefix checked drain, before finish. Cancellation remains existing whole-Job before/after behavior; no block-level cancellation claim.',
        opaque_compile='Opaque Context::compile(RegionFunction) is deliberately unchanged and is not introspected/split. A caller embedding Sink there still gets original whole-graph fallback; typed prepare and graph::apple::compile are the changed routes.',
        visibility='Old installed static SDK uses historical export macro names. Both paired source compilations receive empty current route API macros, equivalent to HYLE_STATIC; no DLL/API/ABI change or SDK source replacement.'),
    source_identity=dict(product_files=applied_identity,tested_to_applied_products_diff='tested-to-applied-products.diff is empty',
        host='Baseline and candidate each fresh current canonical context/operations/graph lowering TUs with identical flags. Reused original tensor lowerer for every comparative number, original SDK MLX/native/foundation and same test/space/latency objects.',
        maps=maps, sdk_identity='prior-sdk-runtime-identities.json plus measured/graph-library-identity.json',
        comparative_identity='comparative-measured/runtime-identities.json and original maps/raw preserve the exact measured executable group; current measured/runtime-identities.json reflects later redundant relinks and is not substituted for that group.',
        new_product_scope='Four private product files; original controls moved to two existing canonical test TUs with one shared test-only Sink oracle header. No CMake/native/SDK patch.'),
    controls=dict(processes='One baseline and one candidate for each original Direct suite and Graph boundary suite; all original input/scale/F32 budgets retained.',
        paired=controls,
        graph='Same H64/Q1025/KV2049 nonzero dyadic QK/row-mask/head-sink input as original Direct reference. CopyQ->Sink->Neg publishes all3; CopyQ payload hash equals caller Q, Sink and Neg each use independent FP64 reference, not candidate-to-candidate comparison.',
        coverage='Original Direct two invocations/all5port rebind/old native output and independent result lifetime, fullmask rows15/16/last, cross-block/tail; H128/Q17 outsideguard control. All output channels checked. H128 long selected path and other shapes not separately measured.'),
    fixed_space=dict(processes='Exactly one independent baseline and one candidate after controls; original space.o unchanged.',
        input='Q1025/KV2049/H64/KVhead1/D512, Q/K/mask/sinks0, V alternating+1.25/-1.25 byKVrow; all33587200 outputs vsFP64 1.25/2050, rel6e-6+abs2e-6.',
        baseline=space['baseline'],candidate=space['candidate'],
        extra_peak_reduction_bytes=space['baseline']['peak_minus_active_before']-space['candidate']['peak_minus_active_before'],
        extra_peak_reduction_fraction=1-space['candidate']['peak_minus_active_before']/space['baseline']['peak_minus_active_before'],
        boundary='Original MLX active/peak/cache after prepare/create/bind, clear_cache/reset_peak then submit/checkedwait/default synchronize. Cold prepare/JIT excluded; includes output/frontiers/private active buffers. Active peak is not whole-device memory or RSS; cache_after is reported separately.',
        limit='Actual measured fixed-shape reduction; not a source-only one-block peak proof. Full output frontier plus final output remain; synchronization does not promise all native cache storage is released.'),
    matched_latency=dict(order=['baseline','candidate','candidate','baseline'],process_results=latency,
        median_candidate_over_baseline=[latency[1]['median_ns']/latency[0]['median_ns'],latency[2]['median_ns']/latency[3]['median_ns']],
        boundary='Original latency.o reused: fixed inputs/public prepare+bind outside,2untimed warm invocations, full FP64 oracle before/after,9timed submit-to-successful checkedwait each; lease/OwnedResult release between samples outside timing. All36 rawns and8complete oracle outcomes retained.',
        limit='Only four ordered processes on one fixed shape, noAA/confidence interval/throughput matrix. Roughly2.3-2.4% lower median observed, no general acceleration claim; primary demonstrated benefit is memory reduction without the compact candidate7x latency penalty.',
        power_before=(RAW/'latency-before-power.stdout.txt').read_text(),power_after=(RAW/'latency-after-power.stdout.txt').read_text(),
        thermal_before=(RAW/'latency-before-thermal.stdout.txt').read_text(),thermal_after=(RAW/'latency-after-thermal.stdout.txt').read_text(),
        environmental_limit='No actual GPU frequency/temperature sampled or adjusted; rawpmset showsAC77% before/after and no recorded thermal/performance warning.'),
    final_canonical=dict(results=applied,scope='Only freshly compiled two canonical test TUs, filtered2Direct+1Graph tests; candidate product objects reused because applied four source files match tested bytes. No repeated baseline/space/latency or full suite.',
        lowerer=load('applied-lowerer.json'),ordinary_change='Separate ordinary F32 force-scale guard may be linked in final closure; it did not participate in comparative Q128 data and does not alter Sink lowering.'),
    failures_retained=['Initial baseline context compile failed because oldSDK visibility header lacked new routeAPI macro names; matched static empty aliases supplied on both sides.',
        'Scratch Graph consumer first had a remote include-directory name mismatch, then incorrectly used GraphBuilder.add with array; corrected to same-directory helper and existing five-ValueId overload. Both failed compile records retained. No failed numerical run was discarded.',
        'Final applied wrapper initially passed --link through an imported driver, redundantly compiling the small scratch Graph consumer once and relinking8comparison executables. No product/native/SDK TU or comparative measurement reran. Original comparative hashes/maps/raw were already archived and remain in comparative-measured unchanged; cleanup hashes describe current relinked files. Wrapper now isolates sys.argv during import; this script-only fix was not executed for confirmation.'],
    precision='Original native F32 math fallback reused, full KV and original mask/sink normalization unchanged. Independent FP64 moderate-input controls passed original6e-6relative+2e-6absolute. This does not certify all NaN/Inf/extreme finite F32 payloads, allshapes or every SDK/environment.',
    prior_results='Q16 single lazy graph negative peak and compact float tile positive space/negative7x latency remain unchanged in separate evidence; neither is recast as a success.',
    cleanup='cleanup-candidates.json owns only this batch Air products; four prior preserved objects remain separate. Source/logs/data/SDK/cache not deleted by this agent. Root committed product/test changes after independent byte review.')
(OUT/'summary.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
prior=OUT.parent/'apple-sink/measured/runtime-identities.json'
(OUT/'prior-sdk-runtime-identities.json').write_bytes(prior.read_bytes())
(OUT/'final-source-sha256.json').write_text(json.dumps({str(p.relative_to(OUT/'applied')):hashlib.sha256(p.read_bytes()).hexdigest()
    for p in (OUT/'applied').rglob('*') if p.is_file()},indent=2)+'\n',encoding='utf-8')
archive=OUT/'source-results.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED) as z:
    for p in sorted(OUT.rglob('*')):
        if p.is_file() and p!=archive and p.name not in ['archive-record.json','measured-raw.tar.gz','comparative-measured-raw.tar.gz']:
            z.write(p,p.relative_to(OUT))
record=dict(path=str(archive),bytes=archive.stat().st_size,sha256=hashlib.sha256(archive.read_bytes()).hexdigest())
(OUT/'archive-record.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
print(json.dumps(record))
