from pathlib import Path
import hashlib
import json
import tarfile

OUT=Path(__file__).resolve().parent
products=[p for p in OUT.iterdir() if p.suffix=='.o' or p.name in
          [a+'-'+k for a in ['baseline','candidate'] for k in ['tests','graph-tests','space','latency']]+
          ['applied-direct-tests','applied-graph-tests']]
entries=[dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
         for p in sorted(products)]
(OUT/'cleanup-candidates.json').write_text(json.dumps(dict(remote_files=entries,
    total_bytes=sum(e['bytes'] for e in entries),
    reused_keep_separate=['../library-review-20261018-apple-sink/tests.o',
                         '../library-review-20261018-apple-sink/space.o',
                         '../library-review-20261018-apple-sink/apple-baseline.o',
                         '../library-review-20261018-apple-sink-compact/latency.o'],
    note='Only this batch current-source host objects/consumer and executables; SDK/cache/metallib/headers/source/logs/data excluded.'),indent=2)+'\n')
graphlib=Path('/Users/kiro/hyle-scratch/g09-air-direct-20261017/final-1dbfce9a0/apple-sdk/lib/libhyle_graph.a')
(OUT/'graph-library-identity.json').write_text(json.dumps(dict(path=str(graphlib),bytes=graphlib.stat().st_size,
    sha256=hashlib.sha256(graphlib.read_bytes()).hexdigest(),note='Existing graph core archive read-only reused; fresh paired graph Apple lowering host TU.'),indent=2)+'\n')
with tarfile.open(OUT/'measured-raw.tar.gz','w:gz') as archive:
    for p in sorted(OUT.rglob('*')):
        if p.is_file() and not p.is_symlink() and p.suffix in ['.h','.cc','.py','.json','.txt','.map']:
            archive.add(p,arcname=str(p.relative_to(OUT)))
print('small paired-source/raw archive and',len(entries),'exact product identities ready')
