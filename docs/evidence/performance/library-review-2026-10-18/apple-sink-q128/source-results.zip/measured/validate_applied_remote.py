from pathlib import Path
import hashlib
import json
import sys
applied_arguments=sys.argv
sys.argv=[sys.argv[0]]
import validate_remote as v
sys.argv=applied_arguments

OUT=Path(__file__).resolve().parent
if '--compile' in sys.argv:
    for kind,source in [('direct','tests/compute_route_apple/tensor_test.cc'),
                        ('graph','tests/graph_route_apple/tensor_test.cc')]:
        v.run('applied-'+kind+'-compile',['/usr/bin/clang++','-I'+str(OUT/'applied/include'),*v.base_flags,
              '-c',OUT/'applied'/source,'-o',OUT/('applied-'+kind+'.o')])
if '--link' in sys.argv:
    lowerer=Path(sys.argv[sys.argv.index('--lowerer')+1]) if '--lowerer' in sys.argv else v.OLD/'apple-baseline.o'
    (OUT/'applied-lowerer.json').write_text(json.dumps(dict(path=str(lowerer),bytes=lowerer.stat().st_size,
        sha256=hashlib.sha256(lowerer.read_bytes()).hexdigest(),
        note='Q128 numerical/space/latency used original baseline lowerer. A separate ordinary force-scale guard may be linked here only for final combined canonical tests; Sink lowering remains unchanged.'),indent=2)+'\n')
    for kind in ['direct','graph']:
        v.run('applied-'+kind+'-link',['/usr/bin/clang++','-O3','-std=c++23','-o',OUT/('applied-'+kind+'-tests'),
            OUT/('applied-'+kind+'.o'),OUT/'candidate-context.o',OUT/'candidate-operations.o',OUT/'candidate-graph.o',
            lowerer,*v.libs,v.CORE/'lib/libgtest_main.a',v.CORE/'lib/libgtest.a',*v.frameworks,
            '-Wl,-map,'+str(OUT/('applied-'+kind+'.map'))])
if '--run' in sys.argv:
    exits={}
    for kind,filt in [('direct','AppleSinkAttention.*'),('graph','AppleSinkGraph.*')]:
        exits[kind]=v.run('applied-'+kind+'-tests',[OUT/('applied-'+kind+'-tests'),'--gtest_filter='+filt,
            '--gtest_output=json:'+str(OUT/('applied-'+kind+'-tests.json'))],required=False)
    (OUT/'applied-test-exits.json').write_text(json.dumps(exits,indent=2)+'\n')
    if any(exits.values()):raise SystemExit(3)
