from pathlib import Path
import hashlib, json, os, subprocess, sys

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'scripts'))
from hyle_environment import windows_compiler_environment
from hyle_support import read_cache
cache = read_cache(ROOT / '.scratch/b-cuda-d5')
env = windows_compiler_environment(cache)
env['VSLANG'] = '1033'
toolkit = Path(cache['CMAKE_CUDA_COMPILER']).parent.parent
env['PATH'] = os.pathsep.join([str(toolkit / 'bin/x64'), str(toolkit / 'bin'), env['PATH']])
native = ROOT / '.scratch/legacy-root/hyle-scratch/ggml-native-static'
source = native / 'src/compute_ggml_runtime/source-4e1a7b2f39afe15d'
overlay = ROOT / '.scratch/perf-review-2026-10-18/ggml-attention-provider/ggml-cuda.strict.obj'
cl = Path(cache['CMAKE_CXX_COMPILER'])
exe = OUT / 'native_stages.exe'
obj = OUT / 'native_stages.obj'

def invoke(command, name, timeout=120):
    result = subprocess.run(command, cwd=OUT, env=env, capture_output=True, timeout=timeout)
    (OUT / (name + '-command.json')).write_text(json.dumps({
        'command': list(map(str, command)), 'cwd': str(OUT), 'exit': result.returncode,
        'path_prefix': env['PATH'].split(os.pathsep)[:2]}, indent=2) + '\n')
    (OUT / (name + '.stdout.log')).write_bytes(result.stdout)
    (OUT / (name + '.stderr.log')).write_bytes(result.stderr)
    print(result.stdout.decode(errors='replace'))
    print(result.stderr.decode(errors='replace'))
    if result.returncode:
        raise SystemExit(result.returncode)

if '--compile' in sys.argv:
    command = [str(cl), '/nologo', '/std:c++20', '/O2', '/MD', '/EHsc', '/W4', '/WX',
        '/DNDEBUG', '/utf-8', '/I' + str(source / 'include'),
        '/I' + str(toolkit / 'include'), '/c', str(OUT / 'native_stages.cc'),
        '/Fo' + str(obj)]
    invoke(command, 'compile')
    libs = [native / 'bin/ggml.lib', native / 'bin/ggml-cuda.lib', native / 'bin/ggml-base.lib']
    invoke([str(cl.with_name('link.exe')), '/nologo', '/machine:x64', '/INCREMENTAL:NO',
        '/out:' + str(exe), str(obj), str(overlay), *map(str, libs),
        '/LIBPATH:' + str(toolkit / 'lib/x64'), 'cudart.lib', 'cublas.lib',
        'cublasLt.lib', 'cuda.lib', 'bcrypt.lib'], 'link')

if '--run' in sys.argv:
    files = [OUT / 'native_stages.cc', OUT / 'run.py', exe, obj, overlay,
        source / 'src/ggml-cuda/softmax.cu',
        ROOT / '.scratch/perf-review-2026-10-18/ggml-attention-provider/ggml-cuda.strict.cu',
        *[native / ('bin/' + n) for n in ['ggml.lib', 'ggml-cuda.lib', 'ggml-base.lib']]]
    (OUT / 'run-identity.json').write_text(json.dumps({
        'files': {str(p.relative_to(ROOT)).replace('\\', '/'):
            {'sha256': hashlib.sha256(p.read_bytes()).hexdigest(), 'bytes': p.stat().st_size}
            for p in files},
        'method': 'Untimed native softmax followed by strict F32 PV. Same original zero-QK masked scores and values, all original rows/heads/depth observed in bounded tiles. No Hyle provider execution.',
        'overlay': 'Retained strict host-dispatch object from original failing controls; unchanged attention path, reused original kernel archive; no CUDA recompile.'}, indent=2) + '\n')
    invoke([str(exe)], 'run')
