// Untimed native stage diagnosis; no Hyle provider or changed precision budget.
#include <algorithm>
#include <array>
#include <bit>
#include <cmath>
#include <cstdint>
#include <iomanip>
#include <iostream>
#include <limits>
#include <stdexcept>
#include <vector>
#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#include <windows.h>
#include <bcrypt.h>
#include <cuda_runtime_api.h>
#include "ggml.h"
#include "ggml-backend.h"
#include "ggml-alloc.h"
#include "ggml-cuda.h"

void require(bool value, const char* what) {
  if (!value) throw std::runtime_error(what);
}
void execute(int length) {
  constexpr int heads = 8, kv_heads = 2, depth = 256;
  const int rows = std::min(128, (64 * 1024 * 1024) / (16 * heads * length));
  auto* backend = ggml_backend_cuda_init(0);
  require(backend, "CUDA init");
  ggml_context* context = ggml_init({4U << 20, nullptr, true});
  require(context, "ggml context");
  // Already-masked zero QK scores are exact for the original Q=K=0 input.
  // Stage isolation omits QK/scale/mask operations, never claims a full provider run.
  auto* scores = ggml_new_tensor_4d(context, GGML_TYPE_F32, length, rows, heads, 1);
  auto* values = ggml_new_tensor_4d(context, GGML_TYPE_F32, length, depth, kv_heads, 1);
  auto* probability = ggml_soft_max(context, scores);
  auto* output = ggml_mul_mat(context, values, probability);
  require(ggml_prec_set_acc(output, GGML_PREC_F32), "F32 accumulation");
  require(ggml_prec_set_src(output, GGML_PREC_F32, 1), "F32 source");
  auto* graph = ggml_new_graph_custom(context, 32, false);
  ggml_build_forward_expand(graph, output);
  auto* buffer = ggml_backend_alloc_ctx_tensors(context, backend);
  require(buffer, "graph allocation");
  std::vector<float> host_scores(ggml_nelements(scores));
  std::vector<float> host_probability(ggml_nelements(probability));
  std::vector<float> host_values(ggml_nelements(values), 1.25F);
  std::vector<float> host_output(ggml_nelements(output));
  std::vector<float> full(std::size_t(length) * heads * depth);
  std::vector<float> first_by_row(length);
  ggml_backend_tensor_set(values, host_values.data(), 0, ggml_nbytes(values));
  double maximum = 0, probability_rounding = 0, probability_mass = 0;
  std::size_t probability_bit_mismatches = 0;
  int worst_n = 0;
  bool finite = true, equal_dimensions_and_heads = true;
  for (int begin = 0; begin < length; begin += rows) {
    for (int h = 0; h < heads; ++h) for (int r = 0; r < rows; ++r) {
      auto* row = host_scores.data() + std::size_t(h * rows + r) * length;
      std::fill_n(row, begin + r + 1, 0.F);
      std::fill(row + begin + r + 1, row + length,
                -std::numeric_limits<float>::infinity());
    }
    ggml_backend_tensor_set(scores, host_scores.data(), 0, ggml_nbytes(scores));
    require(ggml_backend_graph_compute(backend, graph) == GGML_STATUS_SUCCESS,
            "native graph compute");
    ggml_backend_tensor_get(probability, host_probability.data(), 0,
                            ggml_nbytes(probability));
    ggml_backend_tensor_get(output, host_output.data(), 0, ggml_nbytes(output));
    for (int h = 0; h < heads; ++h) for (int r = 0; r < rows; ++r) {
      const int n = begin + r + 1;
      const float rounded = 1.F / float(n);
      double mass = 0;
      for (int j = 0; j < length; ++j) {
        const float p = host_probability[std::size_t(h * rows + r) * length + j];
        const float expected = j < n ? rounded : 0.F;
        probability_bit_mismatches += std::bit_cast<std::uint32_t>(p) !=
                                      std::bit_cast<std::uint32_t>(expected);
        probability_rounding = std::max(probability_rounding,
            std::abs(double(p) - (j < n ? 1. / n : 0.)));
        mass += p;
      }
      probability_mass = std::max(probability_mass, std::abs(mass - 1.));
      const auto first = host_output[std::size_t(h * rows + r) * depth];
      if (h == 0) first_by_row[begin + r] = first;
      for (int d = 0; d < depth; ++d) {
        const float x = host_output[std::size_t(h * rows + r) * depth + d];
        full[(std::size_t(begin + r) * heads + h) * depth + d] = x;
        finite &= std::isfinite(x);
        equal_dimensions_and_heads &= x == first_by_row[begin + r];
        if (std::abs(double(x) - 1.25) > maximum) {
          maximum = std::abs(double(x) - 1.25);
          worst_n = n;
        }
      }
    }
  }
  float cpu_serial_fma = 0;
  for (int j = 0; j < worst_n; ++j)
    cpu_serial_fma = std::fma(1.25F, 1.F / float(worst_n), cpu_serial_fma);
  std::array<unsigned char, 32> digest{};
  require(BCryptHash(BCRYPT_SHA256_ALG_HANDLE, nullptr, 0,
      reinterpret_cast<PUCHAR>(full.data()), static_cast<ULONG>(full.size() * sizeof(float)),
      digest.data(), static_cast<ULONG>(digest.size())) == 0, "SHA256");
  std::cout << std::setprecision(17) << "{\"length\":" << length
    << ",\"tile_q\":" << rows << ",\"batches\":1,\"hq\":8,\"hkv\":2,\"depth\":256"
    << ",\"finite\":" << (finite ? "true" : "false")
    << ",\"all_heads_depth_equal\":" << (equal_dimensions_and_heads ? "true" : "false")
    << ",\"probability_vs_rounded_uniform_mismatches\":" << probability_bit_mismatches
    << ",\"probability_max_abs_vs_fp64\":" << probability_rounding
    << ",\"probability_max_mass_error_fp64\":" << probability_mass
    << ",\"pv_max_abs_vs_1_25\":" << maximum
    << ",\"pv_worst_attended_count\":" << worst_n
    << ",\"pv_at_worst\":" << first_by_row[worst_n - 1]
    << ",\"fp64_pv_of_actual_f32_prob_at_worst\":" << 1.25 * double(1.F / float(worst_n)) * worst_n
    << ",\"cpu_serial_fma_at_worst\":" << cpu_serial_fma
    << ",\"full_output_sha256\":\"";
  for (auto byte : digest)
    std::cout << std::hex << std::setfill('0') << std::setw(2) << unsigned(byte);
  std::cout << std::dec << "\",\"timing\":false,\"provider_run\":false}\n";
  require(finite && equal_dimensions_and_heads,
          "stage diagnostic invariant");
  ggml_backend_buffer_free(buffer);
  ggml_free(context);
  ggml_backend_free(backend);
}
int main() {
  try { execute(2048); execute(8192); return 0; }
  catch (const std::exception& e) { std::cerr << e.what() << '\n'; return 1; }
}
