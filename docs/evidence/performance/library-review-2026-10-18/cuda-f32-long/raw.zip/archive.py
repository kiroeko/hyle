from pathlib import Path
import hashlib, json, subprocess, zipfile

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
PRIOR = OUT.parent / 'ggml-attention-provider'
TEST = OUT.parent / 'ggml-attention-tests'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
rows = [json.loads(line) for line in (OUT / 'run.stdout.log').read_text().splitlines()
        if line.startswith('{')]
assert len(rows) == 2
for row in rows:
    original = json.loads(next(line for line in
        (TEST / f"space-output-hash-candidate-f32-{row['length']}.log").read_text().splitlines()
        if line.startswith('{')))
    assert row['full_output_sha256'] == original['full_output_sha256']

product = ['src/compute_provider_ggml_cuda/ggml_cuda_provider.cc',
           'include/hyle/compute/operation.h', 'third_party/ggml_cuda_runtime/patches.json']
summary = {
    'task': 'Untimed native-stage diagnosis of unchanged long F32 SDPA constant-oracle failures',
    'head_at_packaging': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip(),
    'product_modified': False,
    'input': {'B': 1, 'Hq': 8, 'Hkv': 2, 'D': 256, 'Q_equals_KV': [2048, 8192],
              'qk': 'all zero', 'V': 1.25, 'causal': True, 'scale': 0.0625, 'dtype': 'F32'},
    'method': {
        'native_pin': '456172ec733a135778adcd32d00e576a58232e45',
        'device': 'NVIDIA GeForce RTX 4070, SM89, native log reports 12281 MiB',
        'toolchain': 'MSVC14.50/CUDA13.3; one C++ TU linked retained strict native host-dispatch object and original static kernel libraries',
        'runs': 'One final untimed executable process, sequential 2K then 8K; no throughput, AA, random matrix or whole-SDK build',
        'stages': 'Native ggml_soft_max then ggml_mul_mat with F32 source/accumulation flags; retained host override temporarily selects cuBLAS DEFAULT_MATH',
        'scores': 'Host directly supplies the exact 0/-inf masked scores of original zero QK. QK/scale/diag operations omitted for stage isolation, not a current Hyle provider execution.',
        'coverage': 'All original query rows, heads and depths observed. Bounded tiles 128 at2K/64 at8K match current query-block policy. Original GQA factor4 retained.',
        'probability_storage': 'Only one tile in memory, no full Q-squared probability file; summary stores aggregate error/mass/bit counts, worst row and output SHA',
        'completion': 'Each graph compute and tensor read completes before next tile; buffers/context/backend released after final checks',
    },
    'results': rows,
    'conclusion': {
        'unchanged_output': 'Both complete BSHD output SHA256 values exactly equal the original Hyle baseline and candidate records. Same native math reproduces the original two failures without provider wiring.',
        'softmax': 'Native probabilities differ from CPU round-to-nearest1/n by around one ulp for some entries. Full row mass error maximum9.383074939250946e-8; constant-V FP64 PV from those actual probabilities can differ from1.25 by at most1.1728843674063683e-7.',
        'pv': 'The dominant3.4332275390625e-5/1.4173984527587891e-4 error is native long PV reduction rounding. It is not introduced by query blocking or a changed source dtype/TF32 path.',
        'contract': 'The public accumulation_type=F32 declares arithmetic precision; it does not state a universal length-independent absolute1e-5 bound. This differs from the earlier Half PV accumulator mismatch. The original experiment explicitly remains FAIL at its selected1e-5 budget.',
        'fairness': 'The retained same-native F32 peer has exactly the same output. These data establish no relative Hyle F32 precision loss or throughput result; they also do not prove agreement for arbitrary inputs/backends.',
    },
    'raw_label_correction': {
        'fp64_pv_of_actual_f32_prob_at_worst': 'The measured field name overstates its calculation: code actually evaluates1.25*RN_F32(1/n)*n, not the captured native probability. Retained source and raw are unchanged.',
        'cpu_serial_fma_at_worst': 'Likewise consumes CPU RN_F32(1/n). It exactly matches the two worst native output values, a supporting example rather than per-native-probability replay.',
        'independent_attribution': 'The direct all-row native probability-mass bound above, plus exact full-output SHA match, localizes the dominant error without those two mislabeled/control fields.',
    },
    'bounded_kv_read_only_assessment': {
        'minimal_shape': 'Inside existing Q tiles, view a bounded KV slice of the already-F32 transposed V and normalized probabilities, execute the same strict-F32 native mul_mat for each slice, then combine F32 partial outputs. Never normalize softmax per KV slice.',
        'views': 'F32 native cuBLAS path uses existing data pointers and leading dimensions; non-dense KV views can keep original row/head strides without materializing new K/V copies. Existing broadcast factors preserve Hq/Hkv.',
        'extra_work': 'For P=ceil(KV/Kblock), P PV launches instead of1 plusP-1 additions per Q tile, and more graph metadata. Arithmetic big-O unchanged but launch/traffic behavior changes.',
        'extra_space': 'One partial output is4*B*Hq*Qblock*Dv bytes:1MiB at2K,0.5MiB at8K here. A naive tree can retain O(P) such tensors; a streaming add chain can bound liveness but has a longer merge reduction. Actual gallocr reuse would require verification.',
        'numerics': 'Shorter PV FMA chains and a balanced merge can reduce error, but reassociate native F32 arithmetic and change output bits. No universal absolute1e-5 guarantee for arbitrary magnitudes/cancellation; any benefit needs a deliberate precision/error contract and representative validation.',
        'decision': 'Feasible private lowering experiment, not automatically a product fix for a probe-selected budget. No candidate implementation, new probe, speed result or product change performed.',
    },
    'failures_and_limits': [
        'First host compile failed because Windows min/max macros were enabled; frozen first source/command/log retained. NOMINMAX fixed the scratch TU only.',
        'Final link reports LNK4098 LIBCMT/runtime-library warning, retained verbatim. Final executable exits0 and checks stage invariants; no claim of clean all-product build.',
        'A stage-isolation run, not an actual current HEAD provider build, Graph test, cross-platform test or broad numerical qualification.',
        'Retained strict host-dispatch/kernel archive is the exact old-control closure; it predates unrelated current IQ1/native-resource changes. Attention code/source identities retained.',
        'No product code, precision budget, input or TF32 setting was changed.',
    ],
    'current_source_identity_only': {name: {'sha256': sha(ROOT / name)} for name in product},
}
(OUT / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
members = [(p, p.name) for p in OUT.iterdir()
           if p.is_file() and p.suffix in {'.cc', '.py', '.log', '.json'}
           and p.name not in {'archive-record.json', 'cleanup-manifest.json'}]
members += [(PRIOR / name, 'native-reference/' + name) for name in
    ['native-source-identity.json', 'final-source-metadata.json',
     'ggml-cuda.strict.cu', 'common.cuh', 'native-overlay-compile-command.json']]
members += [(TEST / 'space.cc', 'original-hyle-control/space.cc')]
for length in [2048, 8192]:
    for arm in ['baseline', 'candidate']:
        name = f'space-output-hash-{arm}-f32-{length}.log'
        members.append((TEST / name, 'original-hyle-control/' + name))
with zipfile.ZipFile(OUT / 'raw.zip', 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for path, name in sorted(members, key=lambda x: x[1]):
        z.write(path, name)
cleanup = [{'path': p.relative_to(ROOT).as_posix(), 'sha256': sha(p), 'bytes': p.stat().st_size}
           for p in [OUT / 'native_stages.obj', OUT / 'native_stages.exe']]
(OUT / 'cleanup-manifest.json').write_text(json.dumps({
    'delete_candidates_only': cleanup, 'total_bytes': sum(r['bytes'] for r in cleanup),
    'retain': 'All source/log/command/json/raw evidence plus pre-existing native libraries/strict overlay/cache; no deletion performed.'}, indent=2) + '\n')
record = {name: {'path': (OUT / name).relative_to(ROOT).as_posix(),
    'bytes': (OUT / name).stat().st_size, 'sha256': sha(OUT / name)}
    for name in ['summary.json', 'raw.zip', 'cleanup-manifest.json']}
(OUT / 'archive-record.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record, indent=2))
