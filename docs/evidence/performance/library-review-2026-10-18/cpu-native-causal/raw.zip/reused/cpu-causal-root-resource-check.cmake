cmake_minimum_required(VERSION 3.25)
include("C:/public/project-hyle/hyle/cmake/HyleDependencyVersions.cmake")
hyle_audit_in_tree_dependencies(
  ggml_runtime_patches ggml_cpu_runtime_patches ggml_vulkan_runtime_patches)
message(STATUS "CPU causal: selected native resource hashes and licenses match")
