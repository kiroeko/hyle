from pathlib import Path
import hashlib
import json

ROOT = Path(__file__).resolve().parents[3]
HERE = Path(__file__).resolve().parent
raws = {
    'ggml_cpu_runtime': Path('C:/public/tools/hyle-dependencies/v1/sources/ggml_cpu-ffa4e8b80930-ac5706fbc134'),
    'ggml_runtime': Path('C:/public/tools/hyle-dependencies/v1/sources/ggml-456172ec733a-41b7e10fd424'),
}

prefix = '''static void ggml_compute_forward_flash_attn_ext_tiled(
        const ggml_compute_params * params,
        ggml_tensor * dst,
        int ir0, int ir1) {
    const ggml_tensor * q     = dst->src[0];
    const ggml_tensor * k     = dst->src[1];
    const ggml_tensor * v     = dst->src[2];
    const ggml_tensor * mask  = dst->src[3];
    const ggml_tensor * sinks = dst->src[4];'''
block = '''            // skip the tile entirely if all the masks are -inf
            if (mask) {
                bool can_skip = true;
                for (int tq = 0; tq < tile_rows; tq++) {
                    const ggml_fp16_t * mp_row = (const ggml_fp16_t *)((const char *) mask->data + (iq1 + tq)*mask->nb[1] + (iq2%mask->ne[2])*mask->nb[2] + (iq3%mask->ne[3])*mask->nb[3]);
                    for (int tk = 0; tk < kv_tile; tk++) {
                        mask32[tq * KV_TILE_SZ + tk] = slope * GGML_CPU_FP16_TO_FP32(mp_row[ic + tk]);
                        if (mask32[tq * KV_TILE_SZ + tk] != -INFINITY) {
                            can_skip = false;
                        }
                    }
                    // Pad remaining mask entries with -inf
                    for (int tk = kv_tile; tk < KV_TILE_SZ; tk++) {
                        mask32[tq * KV_TILE_SZ + tk] = -INFINITY;
                    }
                }

                if (can_skip) {
                    continue;
                }
            }'''
new_block = block.replace('if (mask) {', 'if (mask || implicit_causal) {', 1)
new_block = new_block.replace('const ggml_fp16_t * mp_row = (const ggml_fp16_t *)', 'const ggml_fp16_t * mp_row = mask ? (const ggml_fp16_t *)')
new_block = new_block.replace('(iq3%mask->ne[3])*mask->nb[3]);', '(iq3%mask->ne[3])*mask->nb[3]) : nullptr;\n                    const int64_t causal_last = hyle_flash_rows(dst,nek1) - neq1 + iq1 + tq + 1;')
new_block = new_block.replace('                        mask32[tq * KV_TILE_SZ + tk] = slope * GGML_CPU_FP16_TO_FP32(mp_row[ic + tk]);', '''                        float mv = mp_row ? GGML_CPU_FP16_TO_FP32(mp_row[ic + tk]) : 0.0f;
                        if (implicit_causal && ic + tk >= causal_last) mv = -INFINITY;
                        mask32[tq * KV_TILE_SZ + tk] = slope * mv;''')
add = '''            if (mask) {
                ggml_vec_add_f32(tile_rows * KV_TILE_SZ, KQ, KQ, mask32);
            }'''
new_edits = [dict(before=prefix, after=prefix + '\n    const bool implicit_causal = hyle_flash_implicit_causal(dst);'),
             dict(before=block, after=new_block),
             dict(before=add, after=add.replace('if (mask)', 'if (mask || implicit_causal)'))]
results = []
for owner, raw in raws.items():
    manifest_path = ROOT / 'third_party' / owner / 'patches.json'
    manifest = json.loads(manifest_path.read_text(encoding='utf8'))
    entry = next(f for f in manifest['files'] if f['path'] == 'src/ggml-cpu/ops.cpp')
    helper = next(e for e in entry['edits'] if e['before'].strip() == 'static void ggml_compute_forward_flash_attn_ext_f16_one_chunk(')
    assert 'hyle_flash_implicit_causal' not in helper['after']
    helper['after'] = helper['after'].replace('static inline bool hyle_flash_boxed', '''// Ordinary causal attention retains native tiled/split selection and PV math.
static inline bool hyle_flash_implicit_causal(const ggml_tensor * dst) {
    return dst->op_params[7] == 0x48594341;
}

static inline bool hyle_flash_boxed''', 1)
    helper['after'] = helper['after'].replace('    if (!hyle_flash_boxed(dst) || !dst->op_params[9]) return last;', '    if (!hyle_flash_implicit_causal(dst) &&\n        (!hyle_flash_boxed(dst) || !dst->op_params[9])) return last;', 1)
    entry['edits'].extend(new_edits)
    original = (raw / entry['path']).read_bytes().replace(b'\r\n', b'\n')
    assert hashlib.sha256(original).hexdigest() == entry['before_sha256']
    generated = original
    for edit in entry['edits']:
        before = edit['before'].encode()
        assert generated.count(before) == 1, (owner, edit['before'][:90], generated.count(before))
        generated = generated.replace(before, edit['after'].encode(), 1)
    entry['after_sha256'] = hashlib.sha256(generated).hexdigest()
    manifest_path.write_bytes((json.dumps(manifest, indent=2) + '\n').encode())
    folder = HERE / ('ffa4' if owner == 'ggml_cpu_runtime' else 'mixed-common')
    folder.mkdir(exist_ok=True)
    (folder / 'ops.cpp').write_bytes(generated)
    results.append(dict(owner=owner, pin=manifest['upstream_revision'], edits=len(entry['edits']), before=entry['before_sha256'], after=entry['after_sha256']))
(HERE / 'resource-generation.json').write_text(json.dumps(results, indent=2) + '\n')
print(json.dumps(results, indent=2))
