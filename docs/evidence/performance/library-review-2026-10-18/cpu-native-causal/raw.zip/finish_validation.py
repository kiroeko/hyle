from pathlib import Path
import argparse, importlib.util, subprocess

OUT=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('causal',OUT/'build.py')
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)

def test_refresh(pin):
    cfg=b.config(pin);f=cfg['folder']
    b.cpp(cfg,b.ROOT/'tests/compute_provider_ggml/attention_math_test.cc','tests')
    b.cpp(cfg,b.ROOT/'src/compute_ggml_runtime/cpu_program.cc','selector-baseline')
    for mode,selector in [('selected','selector'),('baseline','selector-baseline')]:
        exe=f/('tests-'+mode+'.exe')
        b.run(pin+'-tests-'+mode+'-link',[b.had.LINK,'/nologo','/MACHINE:X64','/SUBSYSTEM:CONSOLE','/INCREMENTAL:NO','/NODEFAULTLIB:LIBCMT','/OUT:'+str(exe),'/MAP:'+str(f/('tests-'+mode+'.map')),*[f/(x+'.obj') for x in ['provider','tests','test-main',selector,'allocator','faults','native-baseline']],*b.had.common_libs(cfg),b.had.BASE/'lib/gtest.lib',*b.had.SYSTEM])
        filters='GgmlCpuMathAttention.ImplicitCausal*:GgmlCpuMathAttention.DecodeOmitsZeroMaskAndRetainsNativeSplit'
        if mode=='selected':filters+=':GgmlCpuMathAttention.PublicCausalHalfAndBfloat16Rebind:GgmlCpuMathAttention.LayoutsBatchGqaAndOutputDepth'
        b.run(pin+'-final-tests-'+mode,[exe,'--gtest_filter='+filters])

def space():
    cfg=b.config('ffa4');f=cfg['folder']
    baseline=OUT/'baseline-ggml_cpu_provider.cc'
    data=subprocess.check_output(['git','show','2ad93d274:src/compute_provider_ggml/ggml_cpu_provider.cc'],cwd=b.ROOT)
    assert b'0x48594341' not in data
    baseline.write_bytes(data)
    b.cpp(cfg,baseline,'provider-baseline')
    b.cpp(cfg,OUT/'space_probe.cc','space')
    for arm,provider in [('baseline','provider-baseline'),('candidate','provider')]:
        exe=f/('space-'+arm+'.exe')
        b.run('ffa4-space-'+arm+'-link',[b.had.LINK,'/nologo','/MACHINE:X64','/SUBSYSTEM:CONSOLE','/INCREMENTAL:NO','/NODEFAULTLIB:LIBCMT','/OUT:'+str(exe),'/MAP:'+str(f/('space-'+arm+'.map')),*[f/(x+'.obj') for x in [provider,'space','selector','allocator','faults','native-baseline']],*b.had.common_libs(cfg),*b.had.SYSTEM])
        b.run('ffa4-space-'+arm,[exe])

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('action',choices=['tests','space']);p.add_argument('--pin',choices=['ffa4','mixed'],default='ffa4');a=p.parse_args()
    if a.action=='tests':test_refresh(a.pin)
    else:space()
