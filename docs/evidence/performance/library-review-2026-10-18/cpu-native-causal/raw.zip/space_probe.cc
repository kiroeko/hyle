#include "cpu_program.h"
#include "hyle/compute/backends/cpu.h"
#include "hyle/compute/prepared_operation.h"
#include "hyle/compute/providers/ggml_cpu.h"
#include <windows.h>
#include <array>
#include <atomic>
#include <cstdlib>
#include <filesystem>
#include <iostream>
#include <new>
namespace {
std::atomic<bool> enabled{false};
std::atomic<std::size_t> calls{0}, bytes{0}, maximum{0}, seed_requests{0};
constexpr std::int64_t queries=2048,keys=16384;
constexpr std::size_t seed_bytes=std::size_t(queries)*keys*2;
}
void* operator new(std::size_t size) {
  void*p=std::malloc(size?size:1);if(!p)throw std::bad_alloc();
  if(enabled.load(std::memory_order_relaxed)) {
    calls.fetch_add(1,std::memory_order_relaxed);
    bytes.fetch_add(size,std::memory_order_relaxed);
    auto old=maximum.load(std::memory_order_relaxed);
    while(old<size&&!maximum.compare_exchange_weak(old,size,std::memory_order_relaxed)){}
    if(size==seed_bytes)seed_requests.fetch_add(1,std::memory_order_relaxed);
  }
  return p;
}
void* operator new[](std::size_t size){return ::operator new(size);}
void operator delete(void*p)noexcept{std::free(p);}
void operator delete[](void*p)noexcept{std::free(p);}
void operator delete(void*p,std::size_t)noexcept{std::free(p);}
void operator delete[](void*p,std::size_t)noexcept{std::free(p);}
std::string owner(std::uintptr_t address) {
  HMODULE module=nullptr;
  if(!GetModuleHandleExA(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS|GET_MODULE_HANDLE_EX_FLAG_UNCHANGED_REFCOUNT,reinterpret_cast<LPCSTR>(address),&module))throw std::bad_alloc();
  std::array<char,4096> name{};
  if(!GetModuleFileNameA(module,name.data(),DWORD(name.size())))throw std::bad_alloc();
  return std::filesystem::path(name.data()).generic_string();
}
int main() {
  using namespace hyle::compute;
  try {
    auto native=ggml_runtime::select_cpu_program().value();native->initialize();
    auto context=Context::create(cpu::device(),ggml_cpu::provider({.native_threads=1})).value();
    auto queue=context.create_queue().value();
    const Operation op(ScaledDotProductAttention{.layout=AttentionLayout::kBatchSequenceHeadDepth,.scale=.25F,.causal=true});
    const auto inputs=[](std::int64_t q,std::int64_t k){
      auto dense=[](auto dims){return TensorDesc::dense(DataType::kFloat16,dims).value();};
      return std::array{dense(std::array<std::int64_t,4>{1,q,1,16}),dense(std::array<std::int64_t,4>{1,k,1,16}),dense(std::array<std::int64_t,4>{1,k,1,16})};
    };
    {const auto warm=inputs(2,4);auto prepared=prepare(context,op,warm,std::span(&warm[0],1),hyle::mem::system_resource()).value();}
    const auto desc=inputs(queries,keys);
    enabled.store(true,std::memory_order_relaxed);
    auto made=prepare(context,op,desc,std::span(&desc[0],1),hyle::mem::system_resource());
    enabled.store(false,std::memory_order_relaxed);
    if(!made){std::cerr<<made.error().message()<<'\n';return 2;}
    if(made->provider().id!=ggml_cpu::kProviderId)return 3;
    std::cout<<"{\"query\":"<<queries<<",\"keys\":"<<keys<<",\"dtype\":\"F16\",\"old_mask_seed_bytes\":"<<seed_bytes
      <<",\"successful_unaligned_new_calls\":"<<calls.load()<<",\"requested_bytes\":"<<bytes.load()<<",\"largest_request\":"<<maximum.load()<<",\"exact_seed_size_requests\":"<<seed_requests.load()
      <<",\"compute_owner\":\""<<owner(reinterpret_cast<std::uintptr_t>(native->compute))<<"\",\"prepared\":true,\"executed\":false}\n";
    return 0;
  }catch(const std::exception&e){enabled.store(false);std::cerr<<e.what()<<'\n';return 4;}
}
