from pathlib import Path
import json,subprocess,sys
ROOT=Path(__file__).resolve().parents[3]
OUT=Path(__file__).resolve().parent
base='/root/hyle/.scratch/perf-watch'
cmds=[['cmake','-S','/root/libuv','-B',base+'/libuv-build','-G','Ninja','-DCMAKE_BUILD_TYPE=Release','-DCMAKE_C_COMPILER=gcc-14','-DBUILD_TESTING=OFF','-DLIBUV_BUILD_SHARED=OFF','-DLIBUV_BUILD_TESTS=OFF','-DLIBUV_BUILD_BENCH=OFF'],['cmake','--build',base+'/libuv-build','--target','uv_a','-j','2']]
(OUT/'peer-build-commands.json').write_text(json.dumps(cmds,indent=2))
for i,cmd in enumerate(cmds):
 r=subprocess.run(['wsl.exe','-e',*cmd],stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
 (OUT/f'peer-build-{i}.log').write_bytes(r.stdout)
 print(r.stdout.decode('utf-8',errors='replace'))
 if r.returncode:raise SystemExit(r.returncode)
