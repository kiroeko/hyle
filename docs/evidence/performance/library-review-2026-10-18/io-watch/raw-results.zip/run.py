from pathlib import Path
import json,statistics,subprocess,sys,time
OUT=Path(__file__).resolve().parent
BASE='/root/hyle/.scratch/perf-watch'
EXE=BASE+'/watch_current'
subprocess.run(['wsl.exe','-e','mkdir','-p',BASE+'/tmp'],check=True)
mode=sys.argv[1] if len(sys.argv)>1 else 'ab'
count=int(sys.argv[2]) if len(sys.argv)>2 else 2
start=int(sys.argv[3]) if len(sys.argv)>3 else 0
routes={'ab':('hyle','libuv'),'aa-hyle':('hyle','hyle'),'aa-libuv':('libuv','libuv')}[mode]
allpairs=[]
for pair in range(start,start+count):
    order=(0,1) if pair%2==0 else (1,0)
    samples={}
    for side in order:
        route=routes[side]
        tag=f'{mode}-{pair}-{side}-{route}'
        command=['wsl.exe','-e','taskset','-c','2','env','TMPDIR='+BASE+'/tmp',EXE,route,'4096','5']
        before=time.time()
        try:
            r=subprocess.run(command,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=45)
        except subprocess.TimeoutExpired as e:
            (OUT/(tag+'.jsonl')).write_bytes(e.stdout or b'')
            (OUT/(tag+'.stderr')).write_bytes(e.stderr or b'')
            raise
        (OUT/(tag+'.jsonl')).write_bytes(r.stdout)
        (OUT/(tag+'.stderr')).write_bytes(r.stderr)
        rows=[json.loads(line) for line in r.stdout.splitlines() if line.strip()]
        record={'command':command,'exit':r.returncode,'seconds':time.time()-before,'rows':rows}
        (OUT/(tag+'.meta.json')).write_text(json.dumps(record,indent=2))
        if r.returncode or len(rows)!=5:raise RuntimeError(tag+' failed')
        if any(row['route']!=route or row['episodes']!=4096 or row['threads']!=2 for row in rows):raise RuntimeError(tag+' unexpected accounting')
        samples[side]=statistics.median(row['ns_per_change'] for row in rows)
        print(tag,round(samples[side],2),flush=True)
    result={'pair':pair,'order':order,'route0':routes[0],'route1':routes[1],'median0_ns':samples[0],'median1_ns':samples[1],'advantage_ratio':samples[1]/samples[0]}
    allpairs.append(result)
    print(json.dumps(result),flush=True)
(OUT/(f'{mode}-pairs-{start}-{count}.json')).write_text(json.dumps(allpairs,indent=2))
