from pathlib import Path
import subprocess,json
OUT=Path(__file__).resolve().parent
base='/root/hyle/.scratch/perf-watch'
perf='/usr/lib/linux-tools/6.18.54.1-microsoft-standard-WSL2/bin/perf'
events=['sched:sched_switch','sched:sched_waking','syscalls:sys_enter_write','syscalls:sys_enter_close','syscalls:sys_enter_rename','syscalls:sys_enter_io_uring_enter','syscalls:sys_exit_io_uring_enter']
commands=[]
for route in ['hyle','libuv']:
 cmd=['wsl.exe','-e',perf,'record','-q','-a','-C','2','-e',','.join(events),'-o',base+'/'+route+'-sched.data','--','taskset','-c','2','env','TMPDIR='+base+'/tmp',base+'/watch_current',route,'256','1']
 r=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=45)
 (OUT/(route+'-sched-record.stdout')).write_bytes(r.stdout)
 (OUT/(route+'-sched-record.stderr')).write_bytes(r.stderr)
 commands.append({'command':cmd,'exit':r.returncode})
 print(route,'record',r.returncode,r.stderr.decode(errors='replace'),flush=True)
 if r.returncode:continue
 cmd=['wsl.exe','-e',perf,'script','--ns','-i',base+'/'+route+'-sched.data']
 r=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=45)
 (OUT/(route+'-sched-script.txt')).write_bytes(r.stdout)
 (OUT/(route+'-sched-script.stderr')).write_bytes(r.stderr)
 commands.append({'command':cmd,'exit':r.returncode})
 print(route,'script',r.returncode,len(r.stdout),'bytes',flush=True)
(OUT/'sched-profile-commands.json').write_text(json.dumps(commands,indent=2))
