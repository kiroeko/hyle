from pathlib import Path
import subprocess,json
OUT=Path(__file__).resolve().parent
ROOT=OUT.parents[2]
source='/mnt/c/public/project-hyle/hyle'
base='/root/hyle/.scratch/perf-watch'
cache='/root/hyle-scratch/io-watch-v2-dev'
cmd=['g++-14','-std=c++23','-O3','-DNDEBUG','-I'+source+'/include','-I'+source+'/third_party/nanobench','-I/root/libuv/include',source+'/.scratch/perf-review-2026-10-18/io-watch/watch_current.cc',source+'/bench/nanobench_impl.cc','-o',base+'/watch_current','-L'+cache+'/bin','-Wl,-rpath,'+cache+'/bin','-lhyle_io_watch','-lhyle_io_core','-lhyle_sched','-lhyle_platform_fs','-lhyle_platform','-lhyle_mem','-lhyle_error',base+'/libuv-build/libuv.a','-pthread','-ldl','-lrt']
(OUT/'compile-command.json').write_text(json.dumps(cmd,indent=2))
r=subprocess.run(['wsl.exe','-e',*cmd],stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
(OUT/'compile.log').write_bytes(r.stdout)
print(r.stdout.decode('utf-8',errors='replace'))
raise SystemExit(r.returncode)
