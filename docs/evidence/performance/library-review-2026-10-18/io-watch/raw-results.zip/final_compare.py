from pathlib import Path
import subprocess,statistics,json
OUT=Path(__file__).resolve().parent
base='/root/hyle/.scratch/perf-watch'
cache='/root/hyle-scratch/io-watch-v2-dev'
locations={'baseline':base+'/baseline-lib','candidate':cache+'/bin'}
metadata=[]
for name,location in locations.items():
 cmd=['wsl.exe','-e','env','LD_LIBRARY_PATH='+location,'ldd',base+'/watch_current']
 r=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,check=True)
 (OUT/('final-loader-'+name+'.txt')).write_bytes(r.stdout)
 expected=location+'/libhyle_io_watch.so.0.1.0'
 assert expected in r.stdout.decode()
 metadata.append({'loader':name,'command':cmd,'expected_watch_library':expected})
 r=subprocess.run(['wsl.exe','-e','sha256sum',expected],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,check=True)
 (OUT/('final-sha256-'+name+'.txt')).write_bytes(r.stdout)
r=subprocess.run(['wsl.exe','-e','readelf','-d',base+'/watch_current'],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,check=True)
(OUT/'final-elf-dynamic.txt').write_bytes(r.stdout)
assert b'RUNPATH' in r.stdout
for pair,(order,versions) in enumerate([('hyle-libuv',['baseline','candidate']),('libuv-hyle',['candidate','baseline'])]):
 for version in versions:
  cmd=['wsl.exe','-e','taskset','-c','2','env','TMPDIR='+base+'/tmp','LD_LIBRARY_PATH='+locations[version],base+'/watch_current',order,'4096','5']
  r=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=45)
  tag=f'final-{pair}-{version}-{order}'
  (OUT/(tag+'.jsonl')).write_bytes(r.stdout);(OUT/(tag+'.stderr')).write_bytes(r.stderr)
  rows=[json.loads(x) for x in r.stdout.splitlines()]
  assert r.returncode==0 and len(rows)==10
  assert all(x['threads']==2 and x['episodes']==4096 for x in rows)
  med={route:statistics.median(x['ns_per_change'] for x in rows if x['route']==route) for route in ['hyle','libuv']}
  record={'command':cmd,'exit':r.returncode,'pair':pair,'version':version,'order':order,'process_medians_ns':med,'advantage_ratio':med['libuv']/med['hyle']}
  (OUT/(tag+'.meta.json')).write_text(json.dumps(record,indent=2));metadata.append(record)
  print(tag,json.dumps(med),med['libuv']/med['hyle'],flush=True)
(OUT/'final-comparison.json').write_text(json.dumps(metadata,indent=2))
