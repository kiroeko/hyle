# TEMPLATE ONLY: root reviews/copies to test.ps1; DO NOT run stale earlier templates.
# Rejected Apple fused-mask v1/v2 exact files; accepted products/current tests/probes/baseline retained.
$ErrorActionPreference = 'Stop'
$pythonSource = @'
import hashlib
import json
import os
from pathlib import Path
import stat

manifest = json.loads(r'''{"root":"/Users/kiro/hyle-scratch/compute-unified/library-review-20261018-apple-fused-mask","targets":[{"path":"/Users/kiro/hyle-scratch/compute-unified/library-review-20261018-apple-fused-mask/context.o","bytes":191760,"sha256":"5c8b319aad2835f3c5bb411232fd8e91ba526cee6a6a2532cfbd15c424b2535c"},{"path":"/Users/kiro/hyle-scratch/compute-unified/library-review-20261018-apple-fused-mask/operations.o","bytes":73832,"sha256":"4dba491e511014111249cb66bea487dab8076b2d878bda76045dd78f6a9eaf0d"},{"path":"/Users/kiro/hyle-scratch/compute-unified/library-review-20261018-apple-fused-mask/attention-tests.o","bytes":304352,"sha256":"1425c7c0ecc821a18a71a48e5e5696bda1ca10889fc0ff69524b16e6a6d7b570"},{"path":"/Users/kiro/hyle-scratch/compute-unified/library-review-20261018-apple-fused-mask/graph-tests.o","bytes":275992,"sha256":"db98a05c885361f029d378c6187c053b9a0cdf3e77eb24802b1df00af604372c"},{"path":"/Users/kiro/hyle-scratch/compute-unified/library-review-20261018-apple-fused-mask/baseline-tests","bytes":10475312,"sha256":"eb6ef905dab31b1aa89391621506124aab56f88248fe01c181d3499142e0d95a"},{"path":"/Users/kiro/hyle-scratch/compute-unified/library-review-20261018-apple-fused-mask/candidate-tests","bytes":10474112,"sha256":"20904edf6e5813574bedf726001daafed44d57ae20ea6c0edc4738ca802e0ddf"},{"path":"/Users/kiro/hyle-scratch/compute-unified/library-review-20261018-apple-fused-mask/diagnostic/baseline-diagnostic","bytes":9612288,"sha256":"1c0feadd6bfd3fe78133e8d110eadd270c41d4b19af0472b5d244ce61d84989b"},{"path":"/Users/kiro/hyle-scratch/compute-unified/library-review-20261018-apple-fused-mask/diagnostic/candidate-diagnostic","bytes":9611320,"sha256":"2ceaf1453a34d9dadfeb29a950c1730f919ceebc62d09e3226945f3865d72703"},{"path":"/Users/kiro/hyle-scratch/compute-unified/library-review-20261018-apple-fused-mask/native-equivalence-tests/baseline-tests","bytes":10475488,"sha256":"60c5f7f755f043bab83e9114a6672331f38fe511f63a08f7393bcd71bea1321e"},{"path":"/Users/kiro/hyle-scratch/compute-unified/library-review-20261018-apple-fused-mask/native-equivalence-tests/candidate-tests","bytes":10474288,"sha256":"a588b71ecbe92fb2d6c4539d9101d0e3bef2fd23e80ed9a5714d3124d7a830e7"},{"path":"/Users/kiro/hyle-scratch/compute-unified/library-review-20261018-apple-fused-mask/native-equivalence-tests/candidate-space","bytes":9574800,"sha256":"596b056e96220ce5a4e97b19fe653cb29962ebf8ba9daf044c2479b16f9c153d"},{"path":"/Users/kiro/hyle-scratch/compute-unified/library-review-20261018-apple-fused-mask/v2/context.o","bytes":192296,"sha256":"75f8ae24f9e96442afaa3a27e7d680bb1338317bb0db9c004a27e241d0451c7e"},{"path":"/Users/kiro/hyle-scratch/compute-unified/library-review-20261018-apple-fused-mask/v2/operations.o","bytes":74112,"sha256":"1a4b2563c440fffd2ad4a36bea9e7de62cd982c68bbf27ad92b76b5921c536a0"},{"path":"/Users/kiro/hyle-scratch/compute-unified/library-review-20261018-apple-fused-mask/v2/candidate-tests","bytes":10474416,"sha256":"49378210ab0ff4987305324cc7a3039fac56572b0f722bb352a035697f1da398"},{"path":"/Users/kiro/hyle-scratch/compute-unified/library-review-20261018-apple-fused-mask/v2/candidate-diagnostic","bytes":9611448,"sha256":"872fc6bb64d2d5d565b79e005844dfbdff6565b8650be40788481b70b48ad00b"},{"path":"/Users/kiro/hyle-scratch/compute-unified/library-review-20261018-apple-fused-mask/v2/candidate-space","bytes":9574928,"sha256":"3e4ed8fe67d73e514a93d262f4f2a5e41fb1a249f98a5424d53afdc73622b770"}],"retain":[{"path":"/Users/kiro/hyle-scratch/compute-unified/library-review-20261018-apple-ordinary-math/context.o","bytes":187280,"sha256":"5c0c5c2e324f6667ec3ec18598b63330784d6977361cd97b8aef990a7102e896"},{"path":"/Users/kiro/hyle-scratch/compute-unified/library-review-20261018-apple-ordinary-math/operations.o","bytes":73616,"sha256":"1f43f11529f2582ec1103576ab700710669f80221a706aa2a7e4135815fe0f8c"},{"path":"/Users/kiro/hyle-scratch/compute-unified/library-review-20261018-apple-ordinary-math/tensor.o","bytes":131640,"sha256":"25e905b914d0c28740c1e3721ba277f9b8506c1fbbc6ab5939d629c895665b40"},{"path":"/Users/kiro/hyle-scratch/compute-unified/library-review-20261018-apple-ordinary-short-q/candidate-graph.o","bytes":87824,"sha256":"13b405c34bb446496563f51db9b91439ea6004d34b00d833edcba6e25d197de6"},{"path":"/Users/kiro/hyle-scratch/compute-unified/library-review-20261018-apple-sink-short-q/sink-tests.o","bytes":258920,"sha256":"1f7f88bb886dc897082422be2585d775c58dc0ba115a82d0bd3f2eef2d62e051"},{"path":"/Users/kiro/hyle-scratch/compute-unified/library-review-20261018-apple-fused-mask/native-equivalence-tests/attention-tests.o","bytes":302800,"sha256":"a952c73389323374271c80a2f69b434ed5a8c76f4354e150e9500a36a6f03a09"},{"path":"/Users/kiro/hyle-scratch/compute-unified/library-review-20261018-apple-fused-mask/native-equivalence-tests/graph-tests.o","bytes":274408,"sha256":"ed7761898b035ff80b82a7ab3595fb3e32ccdbc968d823287f277285d8498784"},{"path":"/Users/kiro/hyle-scratch/compute-unified/library-review-20261018-apple-fused-mask/native-equivalence-tests/consumer.o","bytes":44120,"sha256":"a7e8ff3253f6ed221fa7bca37b7051620584c004bccd8ce4707f0deb35fcfc13"},{"path":"/Users/kiro/hyle-scratch/compute-unified/library-review-20261018-apple-fused-mask/native-equivalence-tests/baseline-space","bytes":9576000,"sha256":"1d9ebf92b9a790c4a6e177a7d4010a5ef6e138d323a5da45ad9ee8068fb6b79f"},{"path":"/Users/kiro/hyle-scratch/compute-unified/library-review-20261018-apple-fused-mask/diagnostic/diagnostic.o","bytes":94672,"sha256":"4416558f54c65d1333939de74d703b78c6e2b499ba154fb5a7e804a5119987b8"}]}''')
root = Path(manifest['root'])
targets = manifest['targets']
retained = manifest['retain']
expected_targets = {str(root / name) for name in ['context.o', 'operations.o', 'attention-tests.o', 'graph-tests.o', 'baseline-tests', 'candidate-tests', 'diagnostic/baseline-diagnostic', 'diagnostic/candidate-diagnostic', 'native-equivalence-tests/baseline-tests', 'native-equivalence-tests/candidate-tests', 'native-equivalence-tests/candidate-space', 'v2/context.o', 'v2/operations.o', 'v2/candidate-tests', 'v2/candidate-diagnostic', 'v2/candidate-space']}
expected_retained = set(['/Users/kiro/hyle-scratch/compute-unified/library-review-20261018-apple-ordinary-math/context.o', '/Users/kiro/hyle-scratch/compute-unified/library-review-20261018-apple-ordinary-math/operations.o', '/Users/kiro/hyle-scratch/compute-unified/library-review-20261018-apple-ordinary-math/tensor.o', '/Users/kiro/hyle-scratch/compute-unified/library-review-20261018-apple-ordinary-short-q/candidate-graph.o', '/Users/kiro/hyle-scratch/compute-unified/library-review-20261018-apple-sink-short-q/sink-tests.o', '/Users/kiro/hyle-scratch/compute-unified/library-review-20261018-apple-fused-mask/native-equivalence-tests/attention-tests.o', '/Users/kiro/hyle-scratch/compute-unified/library-review-20261018-apple-fused-mask/native-equivalence-tests/graph-tests.o', '/Users/kiro/hyle-scratch/compute-unified/library-review-20261018-apple-fused-mask/native-equivalence-tests/consumer.o', '/Users/kiro/hyle-scratch/compute-unified/library-review-20261018-apple-fused-mask/native-equivalence-tests/baseline-space', '/Users/kiro/hyle-scratch/compute-unified/library-review-20261018-apple-fused-mask/diagnostic/diagnostic.o'])
allowed_target_parents = {root, root / 'diagnostic', root / 'native-equivalence-tests', root / 'v2'}

def require(ok, message):
    if not ok:
        raise RuntimeError(message)

require(str(root) == '/Users/kiro/hyle-scratch/compute-unified/library-review-20261018-apple-fused-mask',
        'Wrong literal batch root')
require(root.resolve(strict=True) == root, 'Root resolves outside literal path')
require(len(targets) == 16 and len(retained) == 10, 'Wrong exact manifest counts')
require({item['path'] for item in targets} == expected_targets, 'Wrong target allowlist')
require({item['path'] for item in retained} == expected_retained, 'Wrong retained allowlist')
all_items = targets + retained
require(len({item['path'] for item in all_items}) == 26, 'Repeated or overlapping path')
for item in targets:
    path = Path(item['path'])
    require(path.parent in allowed_target_parents, 'Target outside exact batch directories')

def inspect(item):
    path = Path(item['path'])
    require(path.is_absolute() and str(path) == item['path'], 'Non-canonical absolute path')
    cursor = Path(path.anchor)
    for index, part in enumerate(path.parts[1:]):
        cursor = cursor / part
        status = cursor.lstat()
        require(not stat.S_ISLNK(status.st_mode), 'Symlink forbidden: ' + str(cursor))
        if index + 1 < len(path.parts) - 1:
            require(stat.S_ISDIR(status.st_mode), 'Non-directory ancestor: ' + str(cursor))
    require(path.resolve(strict=True) == path, 'Resolved path changed: ' + str(path))
    before = path.lstat()
    require(stat.S_ISREG(before.st_mode), 'Not a regular file: ' + str(path))
    require(before.st_size == item['bytes'], 'Size mismatch: ' + str(path))
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
    with os.fdopen(fd, 'rb') as stream:
        opened = os.fstat(stream.fileno())
        require((opened.st_dev, opened.st_ino) == (before.st_dev, before.st_ino),
                'File changed while opening: ' + str(path))
        hasher = hashlib.sha256()
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            hasher.update(chunk)
        after = os.fstat(stream.fileno())
    require(after.st_size == item['bytes'] and hasher.hexdigest() == item['sha256'],
            'Size/SHA mismatch: ' + str(path))
    current = path.lstat()
    require(not stat.S_ISLNK(current.st_mode) and
            (current.st_dev, current.st_ino, current.st_size) ==
            (after.st_dev, after.st_ino, after.st_size),
            'File changed while hashing: ' + str(path))
    return current.st_dev, current.st_ino

# Preflight every target and all 10 retained cache files before any deletion.
identities = {item['path']: inspect(item) for item in all_items}
print(json.dumps({'preflight_files': len(all_items), 'delete_files': len(targets),
                  'delete_bytes': sum(item['bytes'] for item in targets),
                  'retain_files': len(retained),
                  'retain_bytes': sum(item['bytes'] for item in retained)}), flush=True)
deleted = []
for item in targets:
    require(inspect(item) == identities[item['path']],
            'Identity changed after preflight: ' + item['path'])
    Path(item['path']).unlink()
    deleted.append(item['path'])
    print('Deleted exact file: ' + item['path'], flush=True)
for item in retained:
    require(inspect(item) == identities[item['path']],
            'Retained file changed: ' + item['path'])
print(json.dumps({'deleted': deleted, 'retained_files_verified': len(retained),
                  'deleted_bytes': sum(item['bytes'] for item in targets)}), flush=True)

'@
$payload = [Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes($pythonSource))
$remoteCode = 'import base64;exec(base64.b64decode("' + $payload + '"))'
$remoteCommand = "python3 -c '" + $remoteCode + "'"
& ssh 'kiro@172.22.10.198' $remoteCommand
if ($LASTEXITCODE -ne 0) { throw "Mac exact cleanup failed with SSH exit $LASTEXITCODE" }
