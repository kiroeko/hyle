from pathlib import Path
import base64
import hashlib
import json
import subprocess
import sys
import tarfile

HERE=Path(__file__).resolve().parent
BASE=HERE.parent
REPO=HERE.parents[3]
REMOTE='/Users/kiro/hyle-scratch/compute-unified/library-review-20261018-apple-fused-mask/v2'
HOST='kiro@172.22.10.198'


def record(p,name=None):
    return dict(path=name or str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())


def run(tag,argv,stream=False):
    assert not (HERE/(tag+'-command.json')).exists()
    argv=list(map(str,argv))
    if stream:
        with (HERE/(tag+'.stdout.txt')).open('wb') as out,(HERE/(tag+'.stderr.txt')).open('wb') as err:
            process=subprocess.Popen(argv,stdout=subprocess.PIPE,stderr=err)
            for line in process.stdout:
                out.write(line);out.flush();sys.stdout.buffer.write(line);sys.stdout.buffer.flush()
            code=process.wait()
        if code:print((HERE/(tag+'.stderr.txt')).read_text(errors='replace')[-7000:],flush=True)
    else:
        result=subprocess.run(argv,capture_output=True,timeout=120);code=result.returncode
        (HERE/(tag+'.stdout.txt')).write_bytes(result.stdout);(HERE/(tag+'.stderr.txt')).write_bytes(result.stderr)
        print(tag,code,result.stdout.decode(errors='replace')[-3000:],result.stderr.decode(errors='replace')[-3000:],flush=True)
    (HERE/(tag+'-command.json')).write_text(json.dumps(dict(argv=argv,exit=code),indent=2)+'\n')
    if code:raise RuntimeError('Stopped: '+tag)


def ssh_python(tag,code):
    payload=base64.b64encode(code.encode()).decode()
    run(tag,['ssh',HOST,'python3 -c \'import base64;exec(base64.b64decode("'+payload+'"))\''])


products=[('src/compute_route_apple/apple_context.cc','2d571ec72c24b54e003bfb12f1ae9e5400f07a87c806a61eea26e1b0550dd3be'),
          ('src/compute_route_apple/apple_operations.cc','199618974ed50c11674faa7eeccfa5bd10e4e718300b07a4f511cc47897d2bde'),
          ('src/compute_route_apple/apple_tensor.h','3454045dcb74d3f6d7238715f3734de1a933c0858b8796abd8abe4edb9c0367f')]
sources=[]
for name,sha in products:
    p=REPO/name;assert hashlib.sha256(p.read_bytes()).hexdigest()==sha
    out=HERE/'source'/name;out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(p.read_bytes());sources.append(record(out,name))
analysis=BASE/'diagnostic/analyze.py';sources.append(record(analysis,'diagnostic/analyze.py'))
native_runtime=json.loads((BASE/'native-equivalence-tests/runtime-identities.json').read_text())
native_built=json.loads((BASE/'native-equivalence-tests/built-identities.json').read_text())
diag_built=json.loads((BASE/'diagnostic/built-identities.json').read_text())
tensor=next(i for i in native_runtime['candidate_objects'] if i['path'].endswith('/tensor.o'))
graph=next(i for i in native_runtime['candidate_objects'] if i['path'].endswith('/candidate-graph.o'))
tests=[next(i for i in native_built if i['path'].endswith('/'+n)) for n in ['attention-tests.o','graph-tests.o']]
consumer=next(i for i in native_built if i['path'].endswith('/consumer.o'))
diagnostic=next(i for i in diag_built if i['path'].endswith('/diagnostic.o'))
sink=native_runtime['sink']
expected=dict(staged_sources=sources,retained_objects=[tensor,graph,*tests,consumer,diagnostic,sink],
    tensor_object=tensor['path'],graph_object=graph['path'],test_objects=[i['path'] for i in tests],
    consumer_object=consumer['path'],diagnostic_object=diagnostic['path'],sink_object=sink['path'],
    baseline_raw_reused_no_baseline_run=True,baseline_space_reused_from='../native-equivalence-tests/space-results.json')
(HERE/'expected-inputs.json').write_text(json.dumps(expected,indent=2)+'\n')
with tarfile.open(HERE/'sources.tar.gz','w:gz') as tar:
    for name,_ in products:tar.add(HERE/'source'/name,arcname=name)
    tar.add(analysis,arcname='diagnostic/analyze.py')
    for n in ['run_remote.py','expected-inputs.json']:tar.add(HERE/n,arcname=n)
ssh_python('create-remote','from pathlib import Path;Path('+repr(REMOTE)+').mkdir(exist_ok=False)')
run('stage-sources',['scp',HERE/'sources.tar.gz',HOST+':'+REMOTE+'/sources.tar.gz'])
ssh_python('extract-sources','''from pathlib import Path
import tarfile
root=Path('''+repr(REMOTE)+''')
with tarfile.open(root/'sources.tar.gz','r:gz') as tar:
    for m in tar.getmembers():
        assert m.isfile() and not Path(m.name).is_absolute() and '..' not in Path(m.name).parts
        p=root/m.name;assert not p.exists() and p.resolve().is_relative_to(root)
        p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(tar.extractfile(m).read())
print('Only3v2productsource+frozenanalyzer+driver staged; all tests/diag/consumer objects andbaseline data reused')
''')
run('execute-remote',['ssh',HOST,'python3 '+REMOTE+'/run_remote.py'],stream=True)
