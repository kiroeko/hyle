from pathlib import Path
import hashlib
import json
import subprocess
import sys

ROOT=Path(__file__).resolve().parent
BASE=ROOT.parent
NATIVE=BASE/'native-equivalence-tests'
sys.path.insert(0,str(BASE))
import run_remote as shared


def save(name,data):
    (ROOT/name).write_text(json.dumps(data,indent=2)+'\n')


def run(tag,argv):
    assert not (ROOT/(tag+'-command.json')).exists(),'No repeated attempt'
    argv=list(map(str,argv));r=subprocess.run(argv,cwd=ROOT,capture_output=True,timeout=400)
    save(tag+'-command.json',dict(argv=argv,cwd=str(ROOT),exit=r.returncode))
    (ROOT/(tag+'.stdout.txt')).write_bytes(r.stdout);(ROOT/(tag+'.stderr.txt')).write_bytes(r.stderr)
    print(tag,r.returncode,flush=True)
    if r.returncode:
        print(r.stdout.decode(errors='replace')[-7000:],flush=True)
        print(r.stderr.decode(errors='replace')[-7000:],flush=True)
        raise RuntimeError('Stopped: '+tag)


expected=json.loads((ROOT/'expected-inputs.json').read_text())
for item in expected['staged_sources']:
    p=ROOT/item['path'];assert p.stat().st_size==item['bytes'] and hashlib.sha256(p.read_bytes()).hexdigest()==item['sha256']
for item in expected['retained_objects']:
    assert shared.record(item['path'])==item,item
host=[ROOT/'context.o',ROOT/'operations.o',Path(expected['tensor_object']),Path(expected['graph_object'])]
tests=[Path(p) for p in expected['test_objects']]
sink=Path(expected['sink_object'])
diag_obj=Path(expected['diagnostic_object']);consumer=Path(expected['consumer_object'])
(ROOT/'mlx.metallib').symlink_to((BASE/'mlx.metallib').resolve())
flags=shared.FLAGS
includes=['-I'+str(ROOT/'src/compute_route_apple'),*shared.INCLUDES]
artifacts=[]
try:
    for tag,source,obj in [('compile-context','apple_context.cc',host[0]),('compile-operations','apple_operations.cc',host[1])]:
        run(tag,['/usr/bin/clang++',*flags,*includes,'-c',ROOT/'src/compute_route_apple'/source,'-o',obj]);artifacts.append(obj)
    exe=ROOT/'candidate-tests'
    run('link-candidate-tests',['/usr/bin/clang++','-O3','-std=c++23','-arch','arm64','-o',exe,*tests,sink,*host,*shared.LIBS,shared.CORE/'lib/libgtest_main.a',shared.CORE/'lib/libgtest.a',*shared.FRAMEWORKS,'-Wl,-map,'+str(exe)+'.map']);artifacts.append(exe)
    assert all(str(p) in Path(str(exe)+'.map').read_text() for p in host+tests+[sink])
    pattern=':'.join([
        'AppleAttention.CenteredShortQueryMathKeepsMasksTailAndReboundOwners',
        'AppleGraph.PublishedCenteredShortQueryMathAndNegativeCrossCheckedBoundary',
        'AppleSinkAttention.QBlocksKeepMasksSinksRebindingAndOwners',
        'AppleSinkAttention.ShortQueriesRetainExistingFallback',
        'AppleSinkGraph.PublishedCopySinkAndNegativeCrossPrivateBoundary',
        'AppleAttention.MathQueryBlocksRetainBroadcastMasksAndReboundOwners',
        'AppleAttention.FusedMasksRetainNativeValuesAcrossStridesAndRebinding',
        'AppleGraph.PublishedFusedMaskNativeResultsRetainOwnersAndRebinding'])
    run('run-candidate-tests',[exe,'--gtest_filter='+pattern,'--gtest_throw_on_failure','--gtest_fail_fast','--gtest_output=json:'+str(ROOT/'candidate-tests.json')])
    data=json.loads((ROOT/'candidate-tests.json').read_text());assert data['tests']==8 and data['failures']==data['errors']==0
    save('functional-gate.json',dict(tests=8,failures=0,arm='candidate-v2',baseline_rerun=False))
    diagnostic=ROOT/'diagnostic';diagnostic.mkdir(exist_ok=True)
    # Reuse original baseline data/log exactly, with no new baseline process or
    # duplicate rawdata. The unchanged analyzer reads this explicit alias.
    (diagnostic/'baseline-output').symlink_to(BASE/'diagnostic/baseline-output',target_is_directory=True)
    old_stdout=BASE/'diagnostic-run-baseline.stdout.txt'
    (ROOT/'diagnostic-run-baseline.stdout.txt').write_bytes(old_stdout.read_bytes())
    save('baseline-reuse.json',dict(stdout=shared.record(old_stdout),raw_directory=str(BASE/'diagnostic/baseline-output'),baseline_processes=0,original_comparison_record=str(BASE/'diagnostic/references-check.json')))
    diag_exe=ROOT/'candidate-diagnostic'
    run('link-candidate-diagnostic',['/usr/bin/clang++','-O3','-std=c++23','-arch','arm64','-o',diag_exe,diag_obj,*host,*shared.LIBS,shared.CORE/'lib/libgtest.a',*shared.FRAMEWORKS,'-Wl,-map,'+str(diag_exe)+'.map']);artifacts.append(diag_exe)
    run('diagnostic-run-candidate',[diag_exe,diagnostic/'candidate-output'])
    run('diagnostic-analysis',['python3',diagnostic/'analyze.py'])
    comparison=json.loads((diagnostic/'comparison.json').read_text())
    assert comparison['checked_elements_per_arm']==4198400 and comparison['references']['consistent']
    assert comparison['all_native_postprocess_reports_consistent'] and comparison['all_lifetimes_true']
    regressions=['oldpass_newfail','new_old_over','category_changes','bits_different','error_growth']
    if any(r['counts'][k] for r in comparison['outputs'] for k in regressions):
        raise RuntimeError('Full diagnostic changed; report before space, no numeric PASS claim')
    space_exe=ROOT/'candidate-space'
    run('link-candidate-space',['/usr/bin/clang++','-O3','-std=c++23','-arch','arm64','-o',space_exe,consumer,*host,*shared.LIBS,*shared.FRAMEWORKS,'-Wl,-map,'+str(space_exe)+'.map']);artifacts.append(space_exe)
    run('run-candidate-space',[space_exe,'--space'])
    rows=[json.loads(s) for s in (ROOT/'run-candidate-space.stdout.txt').read_text().splitlines() if s.startswith('{')]
    assert len(rows)==1;space=rows[0]
    save('candidate-space.json',space)
    baseline=json.loads((NATIVE/'space-results.json').read_text())['baseline']
    assert space['oracle_passed'] and space['checked_elements']==524800
    keys=['active_before','caller_port_requested_bytes','caller_backing_requested_bytes','caller_mask_backing_requested_bytes','output_requested_bytes']
    assert all(space[k]==baseline[k] for k in keys),(space,baseline)
    save('space-results.json',dict(baseline_reused=baseline,candidate_v2=space,baseline_rerun=False))
    save('built-identities.json',[shared.record(p) for p in artifacts])
finally:
    files=[shared.record(ROOT/n) for n in ['context.o','operations.o','candidate-tests','candidate-diagnostic','candidate-space'] if (ROOT/n).is_file()]
    save('cleanup-candidates.json',dict(files=files,total_bytes=sum(i['bytes'] for i in files),performed_cleanup=False,preserve='all v1 sources/raw/refs/log/maps/archives, diag.o and4280consumer.o andnativeparity2test.o, all SDK/caches'))
