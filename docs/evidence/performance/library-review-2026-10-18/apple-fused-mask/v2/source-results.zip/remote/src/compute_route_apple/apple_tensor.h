#pragma once

#include "hyle/compute/apple.h"

#include <cstdint>

namespace hyle::compute::apple::detail {
enum class AttentionPath { kNative, kForcedFused, kMath };
// Cold shape/dtype/capability selection only; never evaluates the arrays.
AttentionPath attention_path(const ScaledDotProductAttention &,
    const mlx::core::array &query, const mlx::core::array &key,
    const mlx::core::array &value, mlx::core::Stream);
// Target a 32MiB packed-mask window; prefer 64-row multiples for Steel/NAX tiles.
// The 64-row floor makes this a target, not a hard allocation limit.
int attention_mask_block_rows(std::uint64_t batch, std::uint64_t heads,
    std::uint64_t keys, std::uint64_t mask_itemsize) noexcept;
Result<std::vector<mlx::core::array>>
lower_sampling(const Operation &, std::span<const mlx::core::array>,
                 mlx::core::Stream);
Result<std::vector<mlx::core::array>>
lower_attention_math_block(const Operation &operation,
    std::span<const mlx::core::array> inputs, mlx::core::Stream stream) noexcept;
Result<std::vector<mlx::core::array>>
lower_tensor(const Operation &operation,
             std::span<const mlx::core::array> inputs,
             mlx::core::Stream stream) noexcept;
} // namespace hyle::compute::apple::detail
