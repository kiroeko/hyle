from array import array
from pathlib import Path
import json
import math
import sys

ROOT = Path(__file__).resolve().parent
BASE = ROOT.parent
assert sys.byteorder == 'little'
assert not (ROOT / 'comparison.json').exists(), 'No overwritten analysis'


def read(code, path):
    result = array(code)
    assert path.stat().st_size % result.itemsize == 0
    with path.open('rb') as stream:
        result.fromfile(stream, path.stat().st_size // result.itemsize)
    return result


def category(value):
    if math.isnan(value): return 'nan'
    if math.isinf(value): return '+inf' if value > 0 else '-inf'
    return 'finite'


def bad(value, reference):
    if math.isnan(reference): return not math.isnan(value)
    if math.isinf(reference): return value != reference
    return not math.isfinite(value) or abs(value - reference) > 2e-6 + 6e-6 * abs(reference)


def coord(index, layout):
    d = index % 64
    if layout == 'BSHD': return dict(query=index // 512, head=index // 64 % 8, channel=d)
    return dict(query=index // 64 % 1025, head=index // (1025 * 64), channel=d)


rows = {}
for arm in ['baseline', 'candidate']:
    data = [json.loads(s) for s in (BASE / ('diagnostic-run-' + arm + '.stdout.txt')).read_text().splitlines() if s.startswith('{')]
    outputs = [r for r in data if r['type'] == 'output']
    lifetime = [r for r in data if r['type'] == 'lifetime']
    assert len(outputs) == 8 and sum(r['elements'] for r in outputs) == 4198400
    assert len(lifetime) == 2 and all(r['old_output_bits_stable'] and r['dense_output_bits_stable'] and r['spec_result_bits_stable'] for r in lifetime)
    assert any(r['type'] == 'complete' and r['numeric_pass_claimed'] is False for r in data)
    rows[arm] = {r['name']:r for r in outputs}
assert rows['baseline'].keys() == rows['candidate'].keys()

# Compare references before accepting either as a shared semantic baseline.
# All finite FP64 values (including signed zero) must match bitwise; NaN
# payloads may vary but NaN/signed-Inf categories must be unchanged.
refs, reference_checks = {}, []
for name in sorted({r['reference'] for r in rows['baseline'].values()}):
    paths = [ROOT / (arm + '-output') / name for arm in ['baseline', 'candidate']]
    values = [read('d', p) for p in paths]
    bits = [read('Q', p) for p in paths]
    assert len(values[0]) == len(values[1]) == 524800
    finite_bit_changes = category_changes = nan_payload_changes = 0
    first_mismatch = None
    for i, (old, new) in enumerate(zip(*values)):
        changed_category = category(old) != category(new)
        changed_finite = math.isfinite(old) and math.isfinite(new) and bits[0][i] != bits[1][i]
        category_changes += changed_category
        finite_bit_changes += changed_finite
        nan_payload_changes += math.isnan(old) and math.isnan(new) and bits[0][i] != bits[1][i]
        if (changed_category or changed_finite) and first_mismatch is None: first_mismatch = i
    reference_checks.append(dict(name=name, elements=len(values[0]), finite_bit_changes=finite_bit_changes,
        category_changes=category_changes, nan_payload_changes=nan_payload_changes, first_mismatch=first_mismatch))
    refs[name] = [array('f', v) for v in values] # exact frozen float-rounded expect references
check = dict(references=reference_checks, consistent=all(r['finite_bit_changes'] == r['category_changes'] == 0 for r in reference_checks))
(ROOT / 'references-check.json').write_text(json.dumps(check, indent=2) + '\n')
assert check['consistent'], 'References differ: report before comparing own-oracle results'

reports = []
for name, old_metadata in rows['baseline'].items():
    new_metadata = rows['candidate'][name]
    assert old_metadata['layout'] == new_metadata['layout']
    assert old_metadata['reference'] == new_metadata['reference']
    reference, own_new_reference = refs[old_metadata['reference']]
    paths = [ROOT / (arm + '-output') / (name + '.f32bits.bin') for arm in ['baseline', 'candidate']]
    old_values, new_values = [read('f', p) for p in paths]
    old_bits, new_bits = [read('I', p) for p in paths]
    assert len(old_values) == len(new_values) == len(reference) == 524800
    counts = dict(old_over=0, new_over=0, own_new_over=0, oldpass_newfail=0,
                  new_old_over=0, category_changes=0, bits_different=0, error_growth=0,
                  normal_old_over=0, normal_new_over=0, corner_old_over=0, corner_new_over=0)
    old_max_error = new_max_error = max_growth = max_delta = 0.0
    old_max_ratio = new_max_ratio = 0.0
    max_growth_witness = max_delta_witness = first_new_failure = first_category_change = None
    per_query = {}
    flags = bytearray(len(reference))
    for i, (old, new, ref) in enumerate(zip(old_values, new_values, reference)):
        old_bad, new_bad = bad(old, ref), bad(new, ref)
        own_new_bad = bad(new, own_new_reference[i])
        new_old_bad = bad(new, old)
        changed_category = category(old) != category(new)
        changed_bits = old_bits[i] != new_bits[i]
        growth = 0.0
        if math.isfinite(ref) and math.isfinite(old):
            error = abs(old - ref)
            old_max_error = max(old_max_error, error)
            old_max_ratio = max(old_max_ratio, error / (2e-6 + 6e-6 * abs(ref)))
        if math.isfinite(ref) and math.isfinite(new):
            error = abs(new - ref)
            new_max_error = max(new_max_error, error)
            new_max_ratio = max(new_max_ratio, error / (2e-6 + 6e-6 * abs(ref)))
        if math.isfinite(ref) and math.isfinite(old) and math.isfinite(new):
            growth = abs(new - ref) - abs(old - ref)
        position = coord(i, old_metadata['layout'])
        corner = position['query'] in [0, 127, 128, 1024]
        values = [old_bad, new_bad, old_bad is False and new_bad,
                  new_old_bad, changed_category, changed_bits, growth > 0]
        for key, value in zip(['old_over', 'new_over', 'oldpass_newfail', 'new_old_over', 'category_changes', 'bits_different', 'error_growth'], values): counts[key] += value
        counts['own_new_over'] += own_new_bad
        counts['corner_old_over' if corner else 'normal_old_over'] += old_bad
        counts['corner_new_over' if corner else 'normal_new_over'] += new_bad
        flags[i] = sum(int(value) << bit for bit, value in enumerate(values))
        if any(values):
            bucket = per_query.setdefault(position['query'], [0] * 7)
            for bit, value in enumerate(values): bucket[bit] += value
        witness = dict(index=i, **position, old_bits=f'{old_bits[i]:08x}', new_bits=f'{new_bits[i]:08x}',
                       reference=ref if math.isfinite(ref) else category(ref),
                       old=old if math.isfinite(old) else category(old), new=new if math.isfinite(new) else category(new))
        if growth > max_growth: max_growth = growth; max_growth_witness = witness
        if math.isfinite(old) and math.isfinite(new) and abs(new - old) > max_delta:
            max_delta = abs(new - old); max_delta_witness = witness
        if not old_bad and new_bad and first_new_failure is None: first_new_failure = witness
        if changed_category and first_category_change is None: first_category_change = witness
    # Cross-check the independent postprocessing against each native dump's
    # own-reference report; disagreement is structural, never quietly ignored.
    assert counts['old_over'] == old_metadata['over_original_budget']
    assert counts['own_new_over'] == new_metadata['over_original_budget']
    assert counts['normal_old_over'] == old_metadata['normal_over_budget']
    assert counts['corner_old_over'] == old_metadata['native_corner_over_budget']
    assert counts['normal_new_over'] == new_metadata['normal_over_budget']
    assert counts['corner_new_over'] == new_metadata['native_corner_over_budget']
    assert math.isclose(old_max_error, old_metadata['max_abs_error'], rel_tol=1e-12, abs_tol=1e-12)
    assert math.isclose(new_max_error, new_metadata['max_abs_error'], rel_tol=1e-12, abs_tol=1e-12)
    assert math.isclose(old_max_ratio, old_metadata['max_error_over_budget'], rel_tol=1e-12, abs_tol=1e-12)
    assert math.isclose(new_max_ratio, new_metadata['max_error_over_budget'], rel_tol=1e-12, abs_tol=1e-12)
    flag_path = ROOT / (name + '.comparison-flags.u8.bin')
    assert not flag_path.exists()
    flag_path.write_bytes(flags)
    report = dict(name=name, layout=old_metadata['layout'], checked_elements=len(reference), counts=counts,
        old_max_error=old_max_error, new_max_error=new_max_error, old_max_ratio=old_max_ratio, new_max_ratio=new_max_ratio,
        max_error_growth=max_growth, max_growth_witness=max_growth_witness, max_new_old_abs=max_delta,
        max_delta_witness=max_delta_witness, first_oldpass_newfail=first_new_failure,
        first_category_change=first_category_change, per_query_counts=per_query,
        full_element_flags=flag_path.name)
    reports.append(report)
    print(json.dumps(dict(name=name, **counts, max_error_growth=max_growth, max_new_old_abs=max_delta)), flush=True)

result = dict(status='diagnostic_completed_not_golden_pass', checked_elements_per_arm=sum(r['checked_elements'] for r in reports),
    shared_reference='Always old side float-rounded FP64/native-corner reference after strict reference check; own-new stats separately cross-checked.',
    flag_bits=['old_over_original_budget', 'new_over_same_old_reference_budget', 'oldpass_newfail',
               'new_old_over_original_budget_using_old_actual', 'category_change', 'rawbits_different', 'error_growth'],
    per_query_count_fields=['old_over', 'new_over', 'oldpass_newfail', 'new_old_over', 'category_changes', 'bits_different', 'error_growth'],
    references=check, all_native_postprocess_reports_consistent=True, all_lifetimes_true=True, outputs=reports,
    numeric_pass_claimed=False, extra_runs_or_inputs=False)
(ROOT / 'comparison.json').write_text(json.dumps(result, indent=2) + '\n')
