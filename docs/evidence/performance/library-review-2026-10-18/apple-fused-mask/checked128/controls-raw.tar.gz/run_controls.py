from pathlib import Path
import hashlib
import json
from run_remote import run

ROOT = Path(__file__).resolve().parent
PATTERN = ':'.join([
    'AppleAttention.CenteredShortQueryMathKeepsMasksTailAndReboundOwners',
    'AppleGraph.PublishedCenteredShortQueryMathAndNegativeCrossCheckedBoundary',
    'AppleSinkAttention.QBlocksKeepMasksSinksRebindingAndOwners',
    'AppleSinkAttention.ShortQueriesRetainExistingFallback',
    'AppleSinkGraph.PublishedCopySinkAndNegativeCrossPrivateBoundary',
    'AppleAttention.MathQueryBlocksRetainBroadcastMasksAndReboundOwners'])
identities = json.loads((ROOT / 'built-identities.json').read_text())
results = []
for arm in ['baseline', 'candidate']:
    exe = ROOT / (arm + '-tests')
    item = next(i for i in identities if i['path'] == str(exe))
    assert exe.stat().st_size == item['bytes']
    assert hashlib.sha256(exe.read_bytes()).hexdigest() == item['sha256']
    run('controls-' + arm, [exe, '--gtest_filter=' + PATTERN,
        '--gtest_throw_on_failure', '--gtest_fail_fast',
        '--gtest_output=json:' + str(ROOT / ('controls-' + arm + '.json'))])
    data = json.loads((ROOT / ('controls-' + arm + '.json')).read_text())
    assert data['tests'] == 6 and data['failures'] == data['errors'] == 0
    results.append(dict(arm=arm, tests=6, failures=0, time=data['time'], binary=item))
    (ROOT / 'controls-results.json').write_text(json.dumps(results, indent=2) + '\n')
