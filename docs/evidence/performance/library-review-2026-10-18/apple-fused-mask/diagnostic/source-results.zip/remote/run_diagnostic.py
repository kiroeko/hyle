from pathlib import Path
import hashlib
import json
from run_remote import ROOT, CORE, FLAGS, INCLUDES, LIBS, FRAMEWORKS, record, run

DIAG = ROOT / 'diagnostic'
source = DIAG / 'diagnostic.cc'
assert hashlib.sha256(source.read_bytes()).hexdigest() == 'fd8a4a8134cf6ba0f979177b9792358af17be62a38c9742292c05fdea2346f86'
expected = json.loads((ROOT / 'expected-inputs.json').read_text())
runtime = json.loads((ROOT / 'runtime-identities.json').read_text())
built = json.loads((ROOT / 'built-identities.json').read_text())
baseline = [Path(p) for p in expected['baseline_objects']]
candidate = [ROOT / 'context.o', ROOT / 'operations.o', baseline[2], baseline[3]]
for p in set(baseline + candidate):
    old = next(i for i in expected['retained_objects'] + built if i['path'] == str(p))
    assert record(p) == old, str(p)
for item in expected['staged_sources']:
    if item['path'].endswith('tensor_test_support.h'):
        actual = record(ROOT / item['path'])
        assert actual['bytes'] == item['bytes'] and actual['sha256'] == item['sha256']
(DIAG / 'mlx.metallib').symlink_to((ROOT / 'mlx.metallib').resolve())
obj = DIAG / 'diagnostic.o'
artifacts = []
try:
    run('diagnostic-compile', ['/usr/bin/clang++', *FLAGS, *INCLUDES, '-c', source, '-o', obj])
    artifacts.append(obj)
    for arm, host in [('baseline', baseline), ('candidate', candidate)]:
        exe = DIAG / (arm + '-diagnostic')
        run('diagnostic-link-' + arm, ['/usr/bin/clang++', '-O3', '-std=c++23', '-arch', 'arm64',
            '-o', exe, obj, *host, *LIBS, CORE / 'lib/libgtest.a', *FRAMEWORKS,
            '-Wl,-map,' + str(exe) + '.map'])
        artifacts.append(exe)
    (DIAG / 'built-identities.json').write_text(json.dumps([record(p) for p in artifacts], indent=2) + '\n')
    for arm in ['baseline', 'candidate']:
        run('diagnostic-run-' + arm, [DIAG / (arm + '-diagnostic'), DIAG / (arm + '-output')])
        rows = [json.loads(line) for line in (ROOT / ('diagnostic-run-' + arm + '.stdout.txt')).read_text().splitlines() if line.startswith('{')]
        outputs = [r for r in rows if r['type'] == 'output']
        lifetime = [r for r in rows if r['type'] == 'lifetime']
        complete = [r for r in rows if r['type'] == 'complete']
        assert len(outputs) == 8 and sum(r['elements'] for r in outputs) == 4198400
        assert len(lifetime) == 2 and all(r['old_output_bits_stable'] and r['dense_output_bits_stable'] and r['spec_result_bits_stable'] for r in lifetime), lifetime
        assert len(complete) == 1 and complete[0]['numeric_pass_claimed'] is False
finally:
    present = [record(p) for p in [obj, DIAG / 'baseline-diagnostic', DIAG / 'candidate-diagnostic'] if p.is_file()]
    (DIAG / 'cleanup-candidates.json').write_text(json.dumps(dict(files=present,
        total_bytes=sum(p['bytes'] for p in present), performed_cleanup=False,
        preserve='all f32bits/f64refs, source/maps/commands/logs, original failure, original six artifacts and caches'), indent=2) + '\n')
