#include "../tests/compute_route_apple/tensor_test_support.h"

#include <bit>
#include <filesystem>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <stdexcept>
#include <string>

// This diagnostic keeps the frozen fixture/budget and dumps every logical
// element. Numeric failures are data, never a reason to stop at the first row.
// Exit zero means the replay/dump completed, not that the attention is golden.
namespace {
using namespace apple_tensor_test;
namespace fm = fused_broadcast_mask;
namespace fs = std::filesystem;

void check(const hyle::Status &status) {
  if (!status.ok()) throw std::runtime_error(std::string(status.message()));
}

template <class T>
void write_binary(const fs::path &path, const std::vector<T> &data) {
  if (fs::exists(path))
    throw std::runtime_error("Refusing to overwrite diagnostic data");
  std::ofstream output(path, std::ios::binary);
  output.write(reinterpret_cast<const char *>(data.data()),
               static_cast<std::streamsize>(data.size() * sizeof(T)));
  if (!output)
    throw std::runtime_error("Could not write diagnostic data");
}

int query_at(std::size_t index, c::AttentionLayout layout) {
  return layout == c::AttentionLayout::kBatchSequenceHeadDepth
      ? static_cast<int>(index / (fm::depth * ordinary_short_query_centered::heads))
      : static_cast<int>((index / fm::depth) % fm::queries);
}

void dump_output(const fs::path &root, const std::string &name,
                 const std::string &reference_name, const mx::array &output,
                 const std::vector<double> &expected,
                 c::AttentionLayout layout) {
  const auto shape = layout == c::AttentionLayout::kBatchSequenceHeadDepth
      ? mx::Shape{1, fm::queries, ordinary_short_query_centered::heads, fm::depth}
      : mx::Shape{1, ordinary_short_query_centered::heads, fm::queries, fm::depth};
  if (output.dtype() != mx::float32 || output.shape() != shape)
    throw std::runtime_error("Unexpected diagnostic output dtype/shape");
  const auto all_bits = bits(output);
  if (all_bits.size() != expected.size())
    throw std::runtime_error("Unexpected diagnostic reference size");
  std::vector<std::uint32_t> raw(all_bits.size());
  std::size_t finite = 0, nan = 0, positive_inf = 0, negative_inf = 0;
  std::size_t category_mismatch = 0, over_budget = 0, normal_over_budget = 0,
      corner_over_budget = 0;
  std::int64_t first_over = -1, max_error_index = -1, max_ratio_index = -1;
  double max_error = 0, max_ratio = 0;
  for (std::size_t i = 0; i < raw.size(); ++i) {
    raw[i] = static_cast<std::uint32_t>(all_bits[i]);
    const float observed = std::bit_cast<float>(raw[i]);
    const float reference = static_cast<float>(expected[i]);
    if (std::isnan(observed)) ++nan;
    else if (observed == std::numeric_limits<float>::infinity()) ++positive_inf;
    else if (observed == -std::numeric_limits<float>::infinity()) ++negative_inf;
    else ++finite;
    bool bad = false;
    if (std::isnan(reference)) {
      bad = !std::isnan(observed);
      category_mismatch += bad;
    } else if (std::isinf(reference)) {
      bad = observed != reference;
      category_mismatch += bad;
    } else if (!std::isfinite(observed)) {
      bad = true;
      ++category_mismatch;
    } else {
      // Exactly the frozen F32 expect() arithmetic: float-rounded reference,
      // original rel6e-6 + abs2e-6; no relative floor or widened tolerance.
      const double error = std::abs(double(observed) - double(reference));
      const double budget = 6e-6 * std::abs(double(reference)) + 2e-6;
      const double ratio = error / budget;
      bad = error > budget;
      if (error > max_error) { max_error = error; max_error_index = i; }
      if (ratio > max_ratio) { max_ratio = ratio; max_ratio_index = i; }
    }
    if (bad) {
      ++over_budget;
      if (first_over < 0) first_over = static_cast<std::int64_t>(i);
      if (fm::corner(query_at(i, layout))) ++corner_over_budget;
      else ++normal_over_budget;
    }
  }
  write_binary(root / (name + ".f32bits.bin"), raw);
  std::cout << "{\"type\":\"output\",\"name\":\"" << name
      << "\",\"reference\":\"" << reference_name
      << "\",\"layout\":\"" << (layout == c::AttentionLayout::kBatchSequenceHeadDepth ? "BSHD" : "BHSD")
      << "\",\"elements\":" << raw.size()
      << ",\"finite\":" << finite << ",\"nan\":" << nan
      << ",\"positive_inf\":" << positive_inf << ",\"negative_inf\":" << negative_inf
      << ",\"category_mismatch\":" << category_mismatch
      << ",\"over_original_budget\":" << over_budget
      << ",\"normal_over_budget\":" << normal_over_budget
      << ",\"native_corner_over_budget\":" << corner_over_budget
      << ",\"first_over_index\":" << first_over
      << ",\"max_abs_error\":" << max_error << ",\"max_error_index\":" << max_error_index
      << ",\"max_error_over_budget\":" << max_ratio << ",\"max_ratio_index\":" << max_ratio_index
      << "}\n";
}

void replay(const fs::path &root, c::MaskKind kind) {
  const auto layout = kind == c::MaskKind::kBoolean
      ? c::AttentionLayout::kBatchHeadSequenceDepth
      : c::AttentionLayout::kBatchSequenceHeadDepth;
  const std::string prefix = kind == c::MaskKind::kBoolean ? "bool" : "bf16-additive";
  auto view0 = fm::ports(kind, layout, 0), view1 = fm::ports(kind, layout, 1);
  auto dense0 = view0;
  dense0[3] = fm::mask_input(kind, 0, true);
  if (view0[3].strides()[3] != 0 || dense0[3].strides()[3] != 1 ||
      view1[3].strides()[3] != 0)
    throw std::runtime_error("Frozen mask strides changed");
  const auto expected0 = fm::reference(view0, layout, 0);
  const auto expected1 = fm::reference(view1, layout, 1);
  const std::string ref0 = prefix + "-phase0.f64.bin", ref1 = prefix + "-phase1.f64.bin";
  write_binary(root / ref0, expected0);
  write_binary(root / ref1, expected1);
  auto context = a::Context::create().value();
  const c::Operation operation(c::ScaledDotProductAttention{
      .layout = layout, .mask = kind, .scale = ordinary_short_query_centered::scale});
  auto program = context.prepare(operation, view0).value();
  std::array<a::InputSpec, 4> specs;
  for (std::size_t i = 0; i < specs.size(); ++i)
    specs[i] = {view0[i].shape(), view0[i].dtype()};
  auto from_specs = context.prepare(operation, specs).value();
  auto first = program.create_invocation().value();
  auto second = from_specs.create_invocation().value();
  check(first.bind(view0));
  check(second.bind(dense0));
  auto work0 = first.submit().value(), work_specs = second.submit().value();
  auto result0 = work0.wait().value(), result_specs = work_specs.wait().value();
  auto old_output = result0.get()->arrays()[0];
  dump_output(root, prefix + "-view0", ref0, old_output, expected0, layout);
  dump_output(root, prefix + "-spec-dense0", ref0, result_specs.get()->arrays()[0], expected0, layout);
  const auto old_bits = bits(old_output), specs_bits = bits(result_specs.get()->arrays()[0]);
  result0 = {};
  work0 = {};
  check(first.bind(dense0));
  auto dense_work = first.submit().value();
  auto dense_result = dense_work.wait().value();
  auto dense_output = dense_result.get()->arrays()[0];
  dump_output(root, prefix + "-dense-rebind0", ref0, dense_output, expected0, layout);
  const auto dense_bits = bits(dense_output);
  dense_result = {};
  dense_work = {};
  check(first.bind(view1));
  auto rebound = first.submit().value();
  first = {};
  second = {};
  program = {};
  from_specs = {};
  context = {};
  auto final_result = rebound.wait().value();
  dump_output(root, prefix + "-view1", ref1, final_result.get()->arrays()[0], expected1, layout);
  const bool old_stable = bits(old_output) == old_bits;
  const bool dense_stable = bits(dense_output) == dense_bits;
  const bool specs_stable = bits(result_specs.get()->arrays()[0]) == specs_bits;
  std::cout << "{\"type\":\"lifetime\",\"case\":\"" << prefix
      << "\",\"old_output_bits_stable\":" << (old_stable ? "true" : "false")
      << ",\"dense_output_bits_stable\":" << (dense_stable ? "true" : "false")
      << ",\"spec_result_bits_stable\":" << (specs_stable ? "true" : "false") << "}\n";
}
} // namespace

int main(int argc, char **argv) {
  if (argc != 2) return 2;
  try {
    const fs::path root(argv[1]);
    if (!root.is_absolute() || !fs::is_directory(root.parent_path()) ||
        !fs::create_directory(root))
      throw std::runtime_error("Require a new output directory under existing scratch");
    std::cout << std::setprecision(17) << std::unitbuf;
    replay(root, c::MaskKind::kBoolean);
    replay(root, c::MaskKind::kAdditive);
    std::cout << "{\"type\":\"complete\",\"output_count\":8,\"numeric_pass_claimed\":false}\n";
    return 0;
  } catch (const std::exception &error) {
    std::cerr << error.what() << '\n';
    return 3;
  }
}
