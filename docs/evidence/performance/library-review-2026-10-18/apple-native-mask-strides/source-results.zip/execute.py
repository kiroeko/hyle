from pathlib import Path
import base64
import hashlib
import json
import subprocess
import tarfile

HERE = Path(__file__).resolve().parent
REPO = HERE.parents[3]
SOURCE = HERE.parent
PREVIOUS = SOURCE.parent / 'apple-fused-mask'
REMOTE = '/Users/kiro/hyle-scratch/compute-unified/library-review-20261018-apple-native-mask-strides'
HOST = 'kiro@172.22.10.198'


def run(tag, argv, timeout=120):
    assert not (HERE / (tag + '-command.json')).exists()
    argv = list(map(str, argv))
    result = subprocess.run(argv, capture_output=True, timeout=timeout)
    (HERE / (tag + '-command.json')).write_text(json.dumps(dict(argv=argv, exit=result.returncode), indent=2) + '\n')
    (HERE / (tag + '.stdout.txt')).write_bytes(result.stdout)
    (HERE / (tag + '.stderr.txt')).write_bytes(result.stderr)
    print(tag, result.returncode, result.stdout.decode(errors='replace')[-7000:], result.stderr.decode(errors='replace')[-4000:], flush=True)
    if result.returncode:
        raise RuntimeError('Stopped: ' + tag)


def ssh_python(tag, code):
    payload = base64.b64encode(code.encode()).decode()
    run(tag, ['ssh', HOST, 'python3 -c \'import base64;exec(base64.b64decode("' + payload + '"))\''])


manifest = REPO / 'third_party/mlx_cast/patches.json'
assert hashlib.sha256(manifest.read_bytes()).hexdigest() == '0b53f4be48bceb046599a7ce8bf71d3d204a5692561795897a481d71be92dcd7'
replay = json.loads((SOURCE / 'full-manifest-replay.json').read_text())
sources = []
for item in replay['changed']:
    for arm, key in [('baseline', 'before_applied_sha256'), ('candidate', 'after_applied_sha256')]:
        p = SOURCE / arm / item['path']
        assert hashlib.sha256(p.read_bytes()).hexdigest() == item[key]
        sources.append((p, arm + '/' + item['path']))
sources.append((PREVIOUS / 'diagnostic/analyze.py', 'diagnostic/analyze.py'))
sources.extend([(SOURCE / 'native.diff', 'native.diff'), (SOURCE / 'full-manifest-replay.json', 'full-manifest-replay.json')])
staged = [dict(path=n, bytes=p.stat().st_size, sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p, n in sources]
old = json.loads((PREVIOUS / 'expected-inputs.json').read_text())
retained = json.loads((PREVIOUS / 'final-cleanup/plan.json').read_text())['retain']
singular = SOURCE.parent / 'apple-native-mask-stride'
new_test = json.loads((singular / 'artifacts.json').read_text())[0]
retained.append(new_test)
base = '/Users/kiro/hyle-scratch/compute-unified/library-review-20261018-apple-fused-mask'
expected = dict(staged_sources=staged,retained_objects=retained,
    hyle_objects=old['baseline_objects'],test_objects=[new_test['path'],base+'/native-equivalence-tests/graph-tests.o'],
    sink_object=old['sink_direct_object'],diagnostic_object=base+'/diagnostic/diagnostic.o',
    consumer_object=base+'/native-equivalence-tests/consumer.o',
    original_steel_include_closure=json.loads((PREVIOUS/'native-mask-inventory/inventory.json').read_text(encoding='utf-8-sig'))['generated_include_closure']['steel_attention'])
(HERE / 'expected-inputs.json').write_text(json.dumps(expected, indent=2) + '\n')
with tarfile.open(HERE / 'sources.tar.gz', 'w:gz') as tar:
    for p, name in sources:
        tar.add(p, arcname=name)
    for name in ['run_remote.py', 'expected-inputs.json']:
        tar.add(HERE / name, arcname=name)
ssh_python('create-remote', 'from pathlib import Path;Path(' + repr(REMOTE) + ').mkdir(exist_ok=False)')
run('stage-sources', ['scp', HERE / 'sources.tar.gz', HOST + ':' + REMOTE + '/sources.tar.gz'])
ssh_python('extract-sources', '''from pathlib import Path
import tarfile
root=Path(''' + repr(REMOTE) + ''')
with tarfile.open(root/'sources.tar.gz','r:gz') as tar:
 for member in tar.getmembers():
  assert member.isfile() and not Path(member.name).is_absolute() and '..' not in Path(member.name).parts
  p=root/member.name;assert not p.exists() and p.resolve().is_relative_to(root)
  p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(tar.extractfile(member).read())
''')
run('execute-remote', ['ssh', HOST, 'python3 ' + REMOTE + '/run_remote.py'], timeout=1400)
