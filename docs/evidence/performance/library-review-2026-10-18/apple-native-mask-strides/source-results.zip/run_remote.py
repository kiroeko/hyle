from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
PREVIOUS = ROOT.parent / 'library-review-20261018-apple-fused-mask'
sys.path.insert(0, str(PREVIOUS))
import run_remote as shared

MLX = shared.CORE / 'hyle/_deps/mlx-490c5876b63c15e8/source'
FMT = Path('/Users/kiro/Library/Caches/hyle/dependencies/v1/sources/fmt-407c905e45ad-cd0d9446fff4/include')


def save(name, value):
    (ROOT / name).write_text(json.dumps(value, indent=2) + '\n')


def run(tag, argv, env=None):
    assert not (ROOT / (tag + '-command.json')).exists(), 'No repeated command'
    argv = list(map(str, argv))
    result = subprocess.run(argv, cwd=ROOT, env=env, capture_output=True, timeout=500)
    save(tag + '-command.json', dict(argv=argv, cwd=str(ROOT), exit=result.returncode,
        environment_override={'PATH': env['PATH']} if env else {}))
    (ROOT / (tag + '.stdout.txt')).write_bytes(result.stdout)
    (ROOT / (tag + '.stderr.txt')).write_bytes(result.stderr)
    print(tag, result.returncode, flush=True)
    if result.returncode:
        print(result.stdout.decode(errors='replace')[-7000:], flush=True)
        print(result.stderr.decode(errors='replace')[-7000:], flush=True)
        raise RuntimeError('Stopped: ' + tag)


expected = json.loads((ROOT / 'expected-inputs.json').read_text())
for item in expected['staged_sources']:
    p = ROOT / item['path']
    assert p.stat().st_size == item['bytes'] and hashlib.sha256(p.read_bytes()).hexdigest() == item['sha256']
for item in expected['retained_objects']:
    assert shared.record(item['path']) == item
hosts = [Path(p) for p in expected['hyle_objects']]
tests = [Path(p) for p in expected['test_objects']]
sink = Path(expected['sink_object'])
diagnostic_obj = Path(expected['diagnostic_object'])
consumer_obj = Path(expected['consumer_object'])
if not (ROOT / 'mlx.metallib').is_symlink():
    (ROOT / 'mlx.metallib').symlink_to(shared.SDK / 'lib/mlx.metallib')
assert (ROOT / 'mlx.metallib').resolve() == (shared.SDK / 'lib/mlx.metallib').resolve()

for arm in ['baseline', 'candidate']:
    for item in expected['original_steel_include_closure']:
        original = Path(item['path'])
        assert shared.record(original) == {key: item[key] for key in ['path', 'bytes', 'sha256']}
        relative = original.relative_to(MLX)
        local = ROOT / arm / relative
        if not local.exists():
            local.parent.mkdir(parents=True, exist_ok=True)
            local.symlink_to(original)

save('runtime-identities.json', dict(
    hyle_objects=[shared.record(p) for p in hosts], tests=[shared.record(p) for p in tests],
    sink=shared.record(sink), diagnostic=shared.record(diagnostic_obj), consumer=shared.record(consumer_obj),
    SDK_libraries=[shared.record(p) for p in shared.LIBS],
    compiler=subprocess.check_output(['/usr/bin/clang++', '--version'], text=True),
    fresh_host_TUs=2, fresh_generated_Steel_TUs=1, fresh_Hyle_or_test_TUs=0,
    NO_NAX=True, NAX_compiled_or_executed=False, SDK_or_metallib_rebuilt=False,
    control='Current-manifest baseline native host plus old SDK Steel, NOT unmodified old SDK native host.',
    raw_diagnostic_reference='Frozen original SDK baseline; NOT fresh old-control diagnostic.'))

artifacts = []
try:
    native_flags = [*shared.FLAGS, '-Wno-unused-parameter', '-DFMT_HEADER_ONLY=1', '-DMLX_METAL_NO_NAX']
    for arm in ['baseline', 'candidate']:
        source = ROOT / arm / 'mlx/backend/metal/scaled_dot_product_attention.cpp'
        obj = ROOT / arm / 'native-host.o'
        run('compile-' + arm + '-native-host', ['/usr/bin/clang++', *native_flags,
            '-I' + str(ROOT / arm), '-isystem', MLX, '-isystem', FMT,
            '-isystem', shared.SDK / 'include', '-isystem', shared.SDK / 'include/metal_cpp',
            '-c', source, '-o', obj])
        artifacts.append(obj)
    generator = MLX / 'mlx/backend/metal/make_compiled_preamble.sh'
    generate_env = dict(os.environ)
    generate_env['PATH'] = '/Users/kiro/hyle-verify-tools/metal-17F109/shim:' + generate_env.get('PATH', '')
    run('generate-candidate-steel', ['bash', generator, ROOT / 'candidate/jit', '/usr/bin/clang',
        ROOT / 'candidate', 'steel/attn/kernels/steel_attention'], env=generate_env)
    generated = ROOT / 'candidate/jit/steel_attention.cpp'
    save('generated-steel-identity.json', shared.record(generated))
    steel_obj = ROOT / 'candidate/steel_attention.o'
    run('compile-candidate-steel', ['/usr/bin/clang++', '-O3', '-DNDEBUG', '-std=c++20',
        '-arch', 'arm64', '-DMLX_STATIC', '-DMLX_METAL_NO_NAX', '-c', generated, '-o', steel_obj])
    artifacts.append(steel_obj)

    def native(arm):
        return [ROOT / arm / 'native-host.o'] + ([steel_obj] if arm == 'candidate' else [])

    def link(tag, exe, leading, arm, gtest):
        run(tag, ['/usr/bin/clang++', '-O3', '-std=c++23', '-arch', 'arm64', '-o', exe,
            *leading, *hosts, *native(arm), *shared.LIBS, *gtest, *shared.FRAMEWORKS,
            '-Wl,-map,' + str(exe) + '.map'])
        artifacts.append(exe)
        mapping = Path(str(exe) + '.map').read_text()
        assert all(str(p) in mapping for p in hosts + native(arm))
        assert 'libmlx.a(scaled_dot_product_attention.cpp.o)' not in mapping
        assert ('libmlx.a(steel_attention.cpp.o)' not in mapping) if arm == 'candidate' else ('libmlx.a(steel_attention.cpp.o)' in mapping)

    gtest = [shared.CORE / 'lib/libgtest_main.a', shared.CORE / 'lib/libgtest.a']
    pattern = ':'.join([
        'AppleAttention.CenteredShortQueryMathKeepsMasksTailAndReboundOwners',
        'AppleGraph.PublishedCenteredShortQueryMathAndNegativeCrossCheckedBoundary',
        'AppleSinkAttention.QBlocksKeepMasksSinksRebindingAndOwners',
        'AppleSinkAttention.ShortQueriesRetainExistingFallback',
        'AppleSinkGraph.PublishedCopySinkAndNegativeCrossPrivateBoundary',
        'AppleAttention.MathQueryBlocksRetainBroadcastMasksAndReboundOwners',
        'AppleAttention.FusedMasksRetainNativeValuesAcrossStridesAndRebinding',
        'AppleGraph.PublishedFusedMaskNativeResultsRetainOwnersAndRebinding',
        'AppleAttention.FullMasksKeepIndependentReferenceAcrossKvStrides'])
    for arm in ['baseline', 'candidate']:
        exe = ROOT / (arm + '-tests')
        link('link-' + arm + '-tests', exe, tests + [sink], arm, gtest)
        selected = 'AppleAttention.FullMasksKeepIndependentReferenceAcrossKvStrides' if arm == 'baseline' else pattern
        run('run-' + arm + '-tests', [exe, '--gtest_filter=' + selected,
            '--gtest_throw_on_failure', '--gtest_fail_fast',
            '--gtest_output=json:' + str(ROOT / (arm + '-tests.json'))])
        result = json.loads((ROOT / (arm + '-tests.json')).read_text())
        assert result['tests'] == (1 if arm == 'baseline' else 9)
        assert result['failures'] == result['errors'] == 0
    save('functional-gate.json', dict(old_control_tests=1, candidate_tests=9, failures=0))

    diagnostic = ROOT / 'diagnostic'
    (diagnostic / 'baseline-output').symlink_to(PREVIOUS / 'diagnostic/baseline-output', target_is_directory=True)
    (ROOT / 'diagnostic-run-baseline.stdout.txt').write_bytes((PREVIOUS / 'diagnostic-run-baseline.stdout.txt').read_bytes())
    diagnostic_exe = ROOT / 'candidate-diagnostic'
    link('link-candidate-diagnostic', diagnostic_exe, [diagnostic_obj], 'candidate',
        [shared.CORE / 'lib/libgtest.a'])
    run('diagnostic-run-candidate', [diagnostic_exe, diagnostic / 'candidate-output'])
    run('diagnostic-analysis', ['python3', diagnostic / 'analyze.py'])
    comparison = json.loads((diagnostic / 'comparison.json').read_text())
    assert comparison['checked_elements_per_arm'] == 4198400 and comparison['references']['consistent']
    assert comparison['all_native_postprocess_reports_consistent'] and comparison['all_lifetimes_true']
    regressions = ['oldpass_newfail', 'new_old_over', 'category_changes', 'bits_different', 'error_growth']
    if any(row['counts'][key] for row in comparison['outputs'] for key in regressions):
        raise RuntimeError('Diagnostic difference: stop before space; no golden PASS claim')

    spaces = {}
    for arm in ['baseline', 'candidate']:
        exe = ROOT / (arm + '-space')
        link('link-' + arm + '-space', exe, [consumer_obj], arm, [])
        run('run-' + arm + '-space', [exe, '--space'])
        rows = [json.loads(line) for line in (ROOT / ('run-' + arm + '-space.stdout.txt')).read_text().splitlines() if line.startswith('{')]
        assert len(rows) == 1 and rows[0]['oracle_passed'] and rows[0]['checked_elements'] == 524800
        spaces[arm] = rows[0]
        save('space-results.json', spaces)
    keys = ['active_before', 'caller_port_requested_bytes', 'caller_backing_requested_bytes',
        'caller_mask_backing_requested_bytes', 'output_requested_bytes']
    assert all(spaces['baseline'][key] == spaces['candidate'][key] for key in keys)
    save('completed.json', dict(status='functional_diagnostic_space_complete_no_latency',
        old_control_is_new_current_manifest_host=True, old_SDK_raw_reused_only_for_diagnostic=True,
        native_fp64_failures_preserved=True))
finally:
    save('built-identities.json', [shared.record(p) for p in artifacts if p.exists()])
