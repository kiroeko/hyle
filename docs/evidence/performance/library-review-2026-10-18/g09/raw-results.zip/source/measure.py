"""Direct timings of the original G09 private facade; no qualification system."""
from pathlib import Path
import argparse
import ctypes as C
import hashlib
import json
import math
import os
import platform
import statistics
import subprocess
import sys
import time

SHAPES = ['independent-cpu-first', 'independent-gpu-first', 'two-microbatches', 'serial-holdout']
ERROR = C.POINTER(C.c_char)
CREATE = C.CFUNCTYPE(C.c_void_p, C.c_uint32, ERROR, C.c_size_t)
REPLAY = C.CFUNCTYPE(C.c_int, C.c_void_p, C.c_uint32, ERROR, C.c_size_t)
DESTROY = C.CFUNCTYPE(C.c_int, C.c_void_p, ERROR, C.c_size_t)

class Facts(C.Structure):
    _fields_ = [(name, C.c_uint64) for name in ['elements', 'slots', 'cold_fragments',
                'planned_copy_count', 'planned_copy_bytes', 'cpu_target', 'gpu_target']]

FACTS = C.CFUNCTYPE(C.c_int, C.c_void_p, C.POINTER(Facts), ERROR, C.c_size_t)

class Api(C.Structure):
    _fields_ = [('abi_version', C.c_uint64), ('struct_bytes', C.c_uint64),
                ('image_tag', C.c_char_p), ('create', CREATE), ('replay', REPLAY),
                ('facts', FACTS), ('destroy', DESTROY)]

def stats(values):
    ordered = sorted(values)
    return {'n': len(values), 'median_ns': statistics.median(values),
            'p90_ns': ordered[math.ceil(.90 * len(ordered)) - 1],
            'p99_ns': ordered[math.ceil(.99 * len(ordered)) - 1],
            'min_ns': ordered[0], 'max_ns': ordered[-1]}

def save(path, report):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')

def threads():
    """Mach snapshots only outside the replay loop; no observer thread added."""
    lib = C.CDLL(None)
    task = C.c_uint32.in_dll(lib, 'mach_task_self_').value
    ports = C.POINTER(C.c_uint32)()
    count = C.c_uint32()
    if lib.task_threads(task, C.byref(ports), C.byref(count)):
        raise RuntimeError('task_threads failed')
    lib.pthread_from_mach_thread_np.argtypes = [C.c_uint32]
    lib.pthread_from_mach_thread_np.restype = C.c_void_p
    lib.pthread_getname_np.argtypes = [C.c_void_p, C.c_void_p, C.c_size_t]
    lib.vm_deallocate.argtypes = [C.c_uint32, C.c_size_t, C.c_size_t]
    rows = []
    try:
        for i in range(count.value):
            port = ports[i]
            name = C.create_string_buffer(256)
            pthread = lib.pthread_from_mach_thread_np(port)
            if pthread:
                lib.pthread_getname_np(pthread, name, len(name))
            info = (C.c_int32 * 10)()
            size = C.c_uint32(10)
            result = lib.thread_info(port, 3, C.byref(info), C.byref(size))
            rows.append({'pthread': int(pthread or 0), 'name': name.value.decode(errors='replace'),
                         'user_us': info[0]*1000000+info[1] if not result else None,
                         'system_us': info[2]*1000000+info[3] if not result else None,
                         'run_state': info[6] if not result else None})
            lib.mach_port_deallocate(task, port)
    finally:
        lib.vm_deallocate(task, C.cast(ports, C.c_void_p).value, count.value * C.sizeof(C.c_uint32))
    return rows

def measure(args):
    image = args.image.resolve(strict=True)
    directories = []
    if os.name == 'nt':
        directories.append(os.add_dll_directory(str(image.parent)))
    report = {'mode': 'DIRECT_USER_JOURNEY_LATENCY', 'label': args.label,
              'image': str(image), 'image_sha256': hashlib.sha256(image.read_bytes()).hexdigest(),
              'host': platform.platform(), 'pid': os.getpid(), 'observer_resources': '2 Scheduler workers + original hyle-mlx owner; no extra wait pool or monitor thread', 'metal_environment': {k: os.environ.get(k) for k in ['MTL_DEBUG_LAYER','MTL_SHADER_VALIDATION']}, 'python': sys.version, 'shapes': [],
              'timing_boundary': 'Python ctypes call through original private C table; includes FFI overhead; native replay drains and releases every result before return',
              'warm_math': 'Original scalar check every slot; independent full 4M oracle before and after timed samples',
              'warmup_replays': args.warmup, 'iterations': args.iterations,
              'process_exit_vendor_cleanup': 'Included only in parent process_elapsed_ns, not warm samples'}
    begin = time.perf_counter_ns()
    library = C.CDLL(str(image))
    report['image_load_ns'] = time.perf_counter_ns() - begin
    getter = library.hyle_g09_facade_v1
    getter.restype = C.POINTER(Api)
    api = getter().contents
    if api.abi_version != 1 or api.struct_bytes != C.sizeof(Api):
        raise RuntimeError('Private facade ABI mismatch')
    report['image_tag'] = api.image_tag.decode()
    guard_visits = library.hyle_g09_guard_visits
    guard_visits.restype = C.c_uint64
    report['threads_initial'] = threads()
    for shape in [0, 3]:
        name = SHAPES[shape]
        error = C.create_string_buffer(2048)
        row = {'shape': shape, 'name': name, 'warm_ns': []}
        report['shapes'].append(row)
        state = None
        try:
            begin = time.perf_counter_ns()
            state = api.create(shape, error, len(error))
            row['cold_create_ns'] = time.perf_counter_ns() - begin
            if not state:
                raise RuntimeError(error.value.decode(errors='replace'))
            facts = Facts()
            if api.facts(state, C.byref(facts), error, len(error)):
                raise RuntimeError(error.value.decode(errors='replace'))
            row['facts'] = {field: getattr(facts, field) for field, _ in Facts._fields_}
            if facts.elements != 4194304 or facts.slots != (2 if shape == 2 else 1) or facts.cpu_target != 1 or facts.gpu_target != 0:
                raise RuntimeError('Original workload elements/slots/CPU+GPU targets changed')

            def replay(full=False):
                begin = time.perf_counter_ns()
                code = api.replay(state, int(full), error, len(error))
                elapsed = time.perf_counter_ns() - begin
                if code:
                    raise RuntimeError(error.value.decode(errors='replace'))
                return elapsed

            row['threads_after_create'] = threads()
            row['first_replay_ns'] = replay()
            row['full_oracle_before_ns'] = replay(True)
            for _ in range(args.warmup):
                replay()
            row['threads_before_timing'] = threads()
            row['guard_before_timing'] = guard_visits()
            for _ in range(args.iterations):
                row['warm_ns'].append(replay())
            row['guard_after_timing'] = guard_visits()
            row['threads_after_timing'] = threads()
            row['full_oracle_after_ns'] = replay(True)
            row['warm'] = stats(row['warm_ns'])
            row['oracle'] = 'PASS_ALL_ELEMENTS_ALL_SLOTS_BEFORE_AND_AFTER'
        except BaseException as failure:
            row['error'] = repr(failure)
            report['error'] = repr(failure)
            raise
        finally:
            if state:
                begin = time.perf_counter_ns()
                code = api.destroy(state, error, len(error))
                row['close_destroy_ns'] = time.perf_counter_ns() - begin
                row['threads_after_destroy'] = threads()
                if code:
                    row['destroy_error'] = error.value.decode(errors='replace')
                    report['error'] = row['destroy_error']
            save(args.output, report)
        if 'error' in report:
            raise RuntimeError(report['error'])
    report['result'] = 'COMPLETED_WITH_NUMERICAL_CHECKS'
    save(args.output, report)
    for row in report['shapes']:
        print(f"{args.label} {row['name']}: cold={row['cold_create_ns']/1e6:.3f} ms first={row['first_replay_ns']/1e6:.3f} ms warm median={row['warm']['median_ns']/1e6:.3f} p90={row['warm']['p90_ns']/1e6:.3f} p99={row['warm']['p99_ns']/1e6:.3f} ms oracle=PASS", flush=True)

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--image', type=Path, required=True)
parser.add_argument('--label', required=True)
parser.add_argument('--warmup', type=int, default=8)
parser.add_argument('--iterations', type=int, default=31)
parser.add_argument('--output', type=Path, required=True)
measure(parser.parse_args())
