"""Prepare only the two small G09 observer consumers in the existing Air cache."""
from pathlib import Path
import hashlib
import json

base = Path('/Users/kiro/hyle-scratch/g09-air-direct-20261017/final-1dbfce9a0')
root = base / 'observer-review-20261018'
source = root / 'source'
source.mkdir(parents=True, exist_ok=False)
original = Path('/Users/kiro/hyle-scratch/compute-unified/source-c8874688/src/graph_route_cpu_apple/invocation.cc')
text = original.read_text()
assert hashlib.sha256(original.read_bytes()).hexdigest() == '357274722348b979b0f8e8e675d27edeab4db2c0d56490895cf36b7323ff596b'
needle = '''    run.pipeline_ready.wait(lock, changed);
  }
}

void drive_cpu_lane'''
replacement = '''    // Diagnostic only: preserve all subscriptions and owners. Both arms count
    // the same eligible guard, outside any native producer callback.
    if (pending == 1 && !changed()) {
#if G09_COUNT_GUARDS
      g09_guard_visits.fetch_add(1, std::memory_order_relaxed);
#endif
#if G09_NATIVE_WAIT_CONTROL
      const auto &stage = run.plan->pipeline_stages[run.pending_native[0]];
      HYLE_FATAL_ASSERT(stage.kind == graph::detail::NativePipelineStage::Kind::kFragment);
      const auto &completion = run.fragments[stage.index].pending.completion();
      lock.unlock();
      const auto status = completion.wait();
      lock.lock();
      if (!status.ok()) run.pipeline_error.Update(status);
      continue; // Original poll, checked result, callback join and retirement.
#endif
    }
    run.pipeline_ready.wait(lock, changed);
  }
}

void drive_cpu_lane'''
assert text.count(needle) == 1
text = text.replace(needle, replacement)
needle = 'namespace hyle::graph::cpu_apple {'
counter = '''namespace {
#if G09_COUNT_GUARDS
std::atomic<std::uint64_t> g09_guard_visits{0};
#endif
}
extern "C" __attribute__((visibility("default"))) std::uint64_t
hyle_g09_guard_visits() noexcept {
#if G09_COUNT_GUARDS
  return g09_guard_visits.load(std::memory_order_relaxed);
#else
  return 0;
#endif
}

'''
assert text.count(needle) == 1
(source / 'invocation.cc').write_text(text.replace(needle, counter + needle))
(source / 'original_invocation.cc').write_bytes(original.read_bytes())
for name in ['facade.cc', 'facade_api.h', 'runtime_probe.cc']:
    (source / name).write_bytes((base / 'latency' / name).read_bytes())

cmake = '''cmake_minimum_required(VERSION 3.26)
project(g09_observer_diagnostic LANGUAGES CXX)
set(CMAKE_CXX_STANDARD 23)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
set(CMAKE_INTERPROCEDURAL_OPTIMIZATION OFF)
set(CMAKE_LIBRARY_OUTPUT_DIRECTORY "${CMAKE_BINARY_DIR}/bin")
set(CMAKE_RUNTIME_OUTPUT_DIRECTORY "${CMAKE_BINARY_DIR}/bin")
option(G09_COUNT_GUARDS "Smoke-only intervention reachability counter" ON)
find_package(Hyle CONFIG REQUIRED COMPONENTS compute graph)
if(NOT Hyle_STATIC)
  message(FATAL_ERROR "Reuse the existing static Air SDK")
endif()
foreach(arm current control)
  if(arm STREQUAL "control")
    set(control 1)
  else()
    set(control 0)
  endif()
  add_library(g09_${arm} SHARED facade.cc invocation.cc)
  target_compile_definitions(g09_${arm} PRIVATE G09_APPLE=1
    G09_COUNT_GUARDS=$<BOOL:${G09_COUNT_GUARDS}>
    G09_NATIVE_WAIT_CONTROL=${control} "G09_IMAGE_TAG=\\"same-sdk-${arm}-observer\\"")
  target_include_directories(g09_${arm} PRIVATE
    "/Users/kiro/hyle-scratch/compute-unified/source-c8874688/src/graph_route_cpu_apple")
  target_link_libraries(g09_${arm} PRIVATE hyle::compute hyle::graph)
  target_compile_options(g09_${arm} PRIVATE -fvisibility=hidden -fvisibility-inlines-hidden)
  target_link_options(g09_${arm} PRIVATE -Wl,-no_weak_exports
    -Wl,-exported_symbol,_hyle_g09_facade_v1
    -Wl,-exported_symbol,_hyle_g09_guard_visits
    "-Wl,-map,${CMAKE_BINARY_DIR}/g09_${arm}.map")
endforeach()
'''
(source / 'CMakeLists.txt').write_text(cmake)

driver = (base / 'latency/latency.py').read_text()
driver = driver[:driver.index('\ndef compare(args):')]
driver = driver.replace('for shape, name in enumerate(SHAPES):', 'for shape in [0, 3]:\n        name = SHAPES[shape]')
driver = driver.replace('def measure(args):', '''def threads():
    """Mach snapshots only outside the replay loop; no observer thread added."""
    lib = C.CDLL(None)
    task = C.c_uint32.in_dll(lib, 'mach_task_self_').value
    ports = C.POINTER(C.c_uint32)()
    count = C.c_uint32()
    if lib.task_threads(task, C.byref(ports), C.byref(count)):
        raise RuntimeError('task_threads failed')
    lib.pthread_from_mach_thread_np.argtypes = [C.c_uint32]
    lib.pthread_from_mach_thread_np.restype = C.c_void_p
    lib.pthread_getname_np.argtypes = [C.c_void_p, C.c_void_p, C.c_size_t]
    lib.vm_deallocate.argtypes = [C.c_uint32, C.c_size_t, C.c_size_t]
    rows = []
    try:
        for i in range(count.value):
            port = ports[i]
            name = C.create_string_buffer(256)
            pthread = lib.pthread_from_mach_thread_np(port)
            if pthread:
                lib.pthread_getname_np(pthread, name, len(name))
            info = (C.c_int32 * 10)()
            size = C.c_uint32(10)
            result = lib.thread_info(port, 3, C.byref(info), C.byref(size))
            rows.append({'pthread': int(pthread or 0), 'name': name.value.decode(errors='replace'),
                         'user_us': info[0]*1000000+info[1] if not result else None,
                         'system_us': info[2]*1000000+info[3] if not result else None,
                         'run_state': info[6] if not result else None})
            lib.mach_port_deallocate(task, port)
    finally:
        lib.vm_deallocate(task, C.cast(ports, C.c_void_p).value, count.value * C.sizeof(C.c_uint32))
    return rows

def measure(args):''')
driver = driver.replace("'host': platform.platform(),", "'host': platform.platform(), 'pid': os.getpid(), 'observer_resources': '2 Scheduler workers + original hyle-mlx owner; no extra wait pool or monitor thread', 'metal_environment': {k: os.environ.get(k) for k in ['MTL_DEBUG_LAYER','MTL_SHADER_VALIDATION']},")
driver = driver.replace("report['image_tag'] = api.image_tag.decode()", "report['image_tag'] = api.image_tag.decode()\n    guard_visits = library.hyle_g09_guard_visits\n    guard_visits.restype = C.c_uint64\n    report['threads_initial'] = threads()")
driver = driver.replace("row['first_replay_ns'] = replay()", "row['threads_after_create'] = threads()\n            row['first_replay_ns'] = replay()")
driver = driver.replace('for _ in range(args.iterations):', "row['threads_before_timing'] = threads()\n            row['guard_before_timing'] = guard_visits()\n            for _ in range(args.iterations):")
driver = driver.replace("row['full_oracle_after_ns'] = replay(True)", "row['guard_after_timing'] = guard_visits()\n            row['threads_after_timing'] = threads()\n            row['full_oracle_after_ns'] = replay(True)")
driver = driver.replace("row['close_destroy_ns'] = time.perf_counter_ns() - begin", "row['close_destroy_ns'] = time.perf_counter_ns() - begin\n                row['threads_after_destroy'] = threads()")
driver += '''
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--image', type=Path, required=True)
parser.add_argument('--label', required=True)
parser.add_argument('--warmup', type=int, default=8)
parser.add_argument('--iterations', type=int, default=31)
parser.add_argument('--output', type=Path, required=True)
measure(parser.parse_args())
'''
(source / 'measure.py').write_text(driver)
compile(driver, str(source / 'measure.py'), 'exec')
identity = {'base': str(base), 'sdk': str(base / 'apple-sdk'), 'original_source': str(original),
            'source_files': [{'path': p.name, 'bytes': p.stat().st_size,
                              'sha256': hashlib.sha256(p.read_bytes()).hexdigest()}
                             for p in sorted(source.iterdir()) if p.is_file()],
            'limit': 'Observer-source current; same cached foundation/SDK, not a whole HEAD rebuild. Guard counters smoke-only, disabled in both formal timing arms.'}
(root / 'source-identity.json').write_text(json.dumps(identity, indent=2) + '\n')
print(json.dumps({'root': str(root), 'source': str(source), 'files': len(identity['source_files'])}))
