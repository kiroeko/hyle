"""Disable smoke counters, compile the same two TUs, then four AB/BA processes."""
from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
import time

base = Path('/Users/kiro/hyle-scratch/g09-air-direct-20261017/final-1dbfce9a0')
root = base / 'observer-review-20261018'
build = root / 'build'
result = {'commands': [], 'order': ['current', 'control', 'control', 'current'],
          'smoke_binary_hashes': {}, 'formal_binary_hashes': {}}
for arm in ['current', 'control']:
    p = build / ('bin/libg09_' + arm + '.dylib')
    result['smoke_binary_hashes'][arm] = hashlib.sha256(p.read_bytes()).hexdigest()
(root / 'compile-commands-smoke.json').write_bytes((build / 'compile_commands.json').read_bytes())

def run(label, command, env=None):
    begin = time.monotonic()
    p = subprocess.run(command, env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    log = root / (label + '.log')
    log.write_bytes(p.stdout)
    result['commands'].append({'label': label, 'command': command, 'exit_code': p.returncode,
                               'seconds': time.monotonic() - begin, 'log': str(log),
                               'log_sha256': hashlib.sha256(p.stdout).hexdigest()})
    (root / 'measurement-commands.json').write_text(json.dumps(result, indent=2) + '\n')
    print(label, p.returncode, round(time.monotonic() - begin, 3), p.stdout.decode(errors='replace')[-1400:], flush=True)
    if p.returncode:
        raise RuntimeError(label + ' failed')

run('configure-formal', ['/opt/homebrew/bin/cmake', '-S', str(root / 'source'), '-B', str(build),
                         '-DG09_COUNT_GUARDS=OFF'])
run('build-formal', ['/opt/homebrew/bin/cmake', '--build', str(build), '--parallel', '2',
                     '--target', 'g09_current', 'g09_control', '--verbose'])
(root / 'compile-commands-formal.json').write_bytes((build / 'compile_commands.json').read_bytes())
for arm in ['current', 'control']:
    p = build / ('bin/libg09_' + arm + '.dylib')
    result['formal_binary_hashes'][arm] = hashlib.sha256(p.read_bytes()).hexdigest()
env = os.environ.copy()
env.update(MTL_DEBUG_LAYER='0', MTL_SHADER_VALIDATION='0')
for i, arm in enumerate(result['order']):
    label = f'paired-{i}-{arm}'
    run(label, [sys.executable, str(root / 'source/measure.py'),
                '--image', str(build / ('bin/libg09_' + arm + '.dylib')),
                '--label', label, '--warmup', '8', '--iterations', '31',
                '--output', str(root / (label + '.json'))], env)
    d = json.loads((root / (label + '.json')).read_text())
    assert d['result'] == 'COMPLETED_WITH_NUMERICAL_CHECKS'
    for row in d['shapes']:
        assert row['guard_before_timing'] == row['guard_after_timing'] == 0
        print('RESULT', label, row['name'], row['warm'], flush=True)
(root / 'measurement-commands.json').write_text(json.dumps(result, indent=2) + '\n')
