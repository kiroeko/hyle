"""Run only the small paired observer build and two full-oracle smoke processes."""
from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
import time

base = Path('/Users/kiro/hyle-scratch/g09-air-direct-20261017/final-1dbfce9a0')
root = base / 'observer-review-20261018'
build = root / 'build'
result = {'commands': [], 'machine': {}, 'sdk': str(base / 'apple-sdk')}
for key, command in [('os', ['sw_vers']), ('model', ['sysctl', '-n', 'hw.model']),
                     ('cpu', ['sysctl', '-n', 'machdep.cpu.brand_string']),
                     ('compiler', ['/usr/bin/c++', '--version'])]:
    result['machine'][key] = subprocess.check_output(command, text=True).strip()

def run(label, command, env=None):
    begin = time.monotonic()
    p = subprocess.run(command, env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    log = root / (label + '.log')
    log.write_bytes(p.stdout)
    result['commands'].append({'label': label, 'command': command, 'exit_code': p.returncode,
                               'seconds': time.monotonic() - begin, 'log': str(log),
                               'log_sha256': hashlib.sha256(p.stdout).hexdigest()})
    (root / 'build-smoke-commands.json').write_text(json.dumps(result, indent=2) + '\n')
    print(label, p.returncode, round(time.monotonic() - begin, 3), p.stdout.decode(errors='replace')[-1800:], flush=True)
    if p.returncode:
        raise RuntimeError(label + ' failed')

run('configure-smoke', ['/opt/homebrew/bin/cmake', '-S', str(root / 'source'), '-B', str(build),
                        '-G', 'Ninja', '-DCMAKE_MAKE_PROGRAM=/opt/homebrew/bin/ninja',
                        '-DCMAKE_BUILD_TYPE=Release', '-DCMAKE_EXPORT_COMPILE_COMMANDS=ON',
                        '-DCMAKE_CXX_COMPILER=/usr/bin/c++', '-DCMAKE_OSX_ARCHITECTURES=arm64',
                        '-DCMAKE_PREFIX_PATH=' + str(base / 'apple-sdk'), '-DG09_COUNT_GUARDS=ON'])
run('build-smoke', ['/opt/homebrew/bin/cmake', '--build', str(build), '--parallel', '2',
                    '--target', 'g09_current', 'g09_control', '--verbose'])
# Reuse the exact metallib by symlink; do not stage/copy an SDK or runtime set.
(build / 'bin/mlx.metallib').symlink_to(base / 'apple-sdk/lib/mlx.metallib')
env = os.environ.copy()
env.update(MTL_DEBUG_LAYER='0', MTL_SHADER_VALIDATION='0')
for arm in ['current', 'control']:
    run('smoke-' + arm, [sys.executable, str(root / 'source/measure.py'),
                         '--image', str(build / ('bin/libg09_' + arm + '.dylib')),
                         '--label', 'smoke-' + arm, '--warmup', '0', '--iterations', '1',
                         '--output', str(root / ('smoke-' + arm + '.json'))], env)
    d = json.loads((root / ('smoke-' + arm + '.json')).read_text())
    for row in d['shapes']:
        print('SMOKE', arm, row['name'], row['oracle'], 'guards', row['guard_after_timing'] - row['guard_before_timing'],
              'threads', [(x['name'], x['pthread']) for x in row['threads_after_create']], flush=True)
