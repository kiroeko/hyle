"""Summarize the finite observer experiment; keep every process and sample."""
from pathlib import Path
import hashlib
import json
import zipfile

base = Path('/Users/kiro/hyle-scratch/g09-air-direct-20261017/final-1dbfce9a0')
root = base / 'observer-review-20261018'
commands = json.loads((root / 'measurement-commands.json').read_text())
summary = {
    'experiment': 'Current Apple Graph subscription vs constrained native-wait diagnostic',
    'decision': 'NO_STABLE_CURRENT_LOSS_ESTABLISHED_IN_THESE_TWO_ORDERS',
    'source_and_cache': {
        'original_invocation_sha256': hashlib.sha256((root / 'source/original_invocation.cc').read_bytes()).hexdigest(),
        'compiled_invocation_sha256': hashlib.sha256((root / 'source/invocation.cc').read_bytes()).hexdigest(),
        'sdk': str(base / 'apple-sdk'),
        'current_windows_matching_hot_source': {
            'src/graph_route_cpu_apple/invocation.cc': '357274722348b979b0f8e8e675d27edeab4db2c0d56490895cf36b7323ff596b',
            'src/compute_route_apple/apple_context.cc': '5bb2691c198cf25ad2d113b5126c683fe81e3acc1cd09089f08f4e68daf9e040'},
        'limit': 'Only observer TU freshly compiled; both arms share existing static foundation/SDK and pinned patched MLX. Not an entire current HEAD rebuild or independent native-engine ranking.'},
    'boundary': {
        'input': '4194304 F32 values, exact same source tensors/math and CPU/GPU placements in both arms; shape 0 independent CPU Abs and resident Apple Neg joined by CPU Add; shape 3 serial CPU Abs -> Apple Neg -> CPU residual Add.',
        'timed': 'One Python ctypes replay call: bind, prepare_replay, submit, checked owning wait/output scalar check, release every view/ResultLease/OwnedResult, Scheduler.drain before return.',
        'outside_timing': 'Context/Graph compilation, slot/resource construction, first replay, full all-element oracles before/after, 8 warmups, thread snapshots, close/destroy/process exit.',
        'control': 'Only parallel native lane with one pending and no ready native work unlocks the same pipeline monitor and waits the original Completion. Subscriptions, native FIFO owner, leases, checked finish, callback join and final retirement remain.',
        'meaning': 'Control retains subscription/owner services and is not a theoretical minimal native wait. Serial holdout does not reach the modified parallel-lane branch.',
        'instrumentation': 'Guard counters enabled for two smoke processes; disabled in both formal arm macros. The diagnostic source is identical between arms except compile definitions. No per-stage clocks or monitoring thread.',
        'numeric': 'Every smoke/formal process passes the full exact all-element oracle before and after timing, plus the timed scalar check.'},
    'method': {'order': commands['order'], 'formal_processes': 4, 'samples_per_shape_per_process': 31,
               'shapes': [0, 3], 'aa': 'No additional A/A run.',
               'inference_limit': 'Four processes are not a cross-process confidence interval, equivalence proof or hardware timer-resolution diagnosis. No samples/outliers filtered.'},
    'processes': [], 'paired_ratios': [], 'smoke': [],
    'product_changes': 0,
    'old_reference': {
        'path': '.scratch/inference-gaps/g09-native-wait-29/source/invocation.cc:571-590',
        'meaning': 'Old R29 was an instrumented same-Graph causal intervention replacing its then-1ms observation with original Completion.wait on Scheduler root. It preserved math/owners; it is not the current Vulkan dedicated BlockingPool or Apple subscription path.',
        'current_vulkan': 'One embedded resident BlockingJob per active invocation/replay, explicit caller-owned pool; start/response/stop-destroy handoffs are charged. Only worker observes selected original Completion; unbridged additional prefixes retain bounded observation. No current Vulkan timing performed.'}}
for p in sorted(root.glob('paired-*.json')):
    d = json.loads(p.read_text())
    record = {'file': p.name, 'label': d['label'], 'pid': d['pid'], 'image_sha256': d['image_sha256'], 'shapes': []}
    for row in d['shapes']:
        before = {x['pthread']: x for x in row['threads_before_timing']}
        cpu = []
        for x in row['threads_after_timing']:
            y = before.get(x['pthread'])
            if y and x['user_us'] is not None:
                cpu.append({'pthread': x['pthread'], 'name': x['name'] or 'unnamed',
                            'user_us': x['user_us'] - y['user_us'], 'system_us': x['system_us'] - y['system_us']})
        record['shapes'].append({'shape': row['shape'], 'name': row['name'], 'facts': row['facts'],
                                  'warm': row['warm'], 'oracle': row['oracle'],
                                  'threads_before': len(before), 'threads_after': len(row['threads_after_timing']),
                                  'thread_cpu_deltas_us': cpu,
                                  'formal_guard_counter': [row['guard_before_timing'], row['guard_after_timing']]})
    summary['processes'].append(record)
for a, b in [(0, 1), (3, 2)]:
    current, control = summary['processes'][a], summary['processes'][b]
    for i in range(2):
        c, n = current['shapes'][i], control['shapes'][i]
        summary['paired_ratios'].append({'current': current['label'], 'control': control['label'], 'shape': c['name'],
                                         'current_median_ns': c['warm']['median_ns'], 'control_median_ns': n['warm']['median_ns'],
                                         'control_over_current': n['warm']['median_ns'] / c['warm']['median_ns']})
for p in sorted(root.glob('smoke-*.json')):
    d = json.loads(p.read_text())
    summary['smoke'].append({'file': p.name, 'shapes': [
        {'name': x['name'], 'oracle': x['oracle'], 'guard_hits_in_one_replay': x['guard_after_timing'] - x['guard_before_timing']}
        for x in d['shapes']]})
summary['threads'] = {'observed': 'All formal shape snapshots have 7 threads before and after: caller, hyle-mlx owner, hyle-wkr-0/1, three unnamed native-runtime threads. Six show positive user CPU deltas; one unnamed thread has zero measured delta.',
                      'limit': 'Snapshots outside replay blocks identify names/counts and block CPU deltas, not instantaneous simultaneous runnable threads; unnamed runtime roles were not inferred.'}
summary['interpretation'] = 'The independent-case order differences reverse sign. The unchanged serial path also varies between processes. This experiment has not established a stable current subscription loss. It does not establish equivalence, a win over MLX, or that the serial drift caused the observed difference.'
summary['binary_hashes'] = {'smoke': commands['smoke_binary_hashes'], 'formal': commands['formal_binary_hashes']}
(root / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')

# Record the exact reused archives; no SDK contents are copied into the bundle.
old_identity = json.loads((base / 'apple-performance-identity.json').read_text())
sdk_identity = []
for item in old_identity['sdk_archives_and_runtime']:
    p = Path(item['path'])
    now = hashlib.sha256(p.read_bytes()).hexdigest()
    sdk_identity.append({'path': str(p), 'bytes': p.stat().st_size, 'sha256': now,
                         'matches_existing_identity': now == item['sha256']})
(root / 'reused-sdk-identity.json').write_text(json.dumps(sdk_identity, indent=2) + '\n')
assert all(x['matches_existing_identity'] for x in sdk_identity)

files = [p for p in root.iterdir() if p.is_file() and p.suffix in ['.json', '.log']]
files += [p for p in (root / 'source').iterdir() if p.is_file()]
files += list((root / 'build').glob('*.map'))
archive = root / 'raw-results.zip'
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for p in sorted(files):
        z.write(p, str(p.relative_to(root)))
print(json.dumps({'root': str(root), 'archive_bytes': archive.stat().st_size,
                  'archive_sha256': hashlib.sha256(archive.read_bytes()).hexdigest(),
                  'paired_ratios': summary['paired_ratios']}))
