#pragma once

#if defined(__linux__)
#include "hyle/compute/providers/flashinfer.h"
#endif

#include <algorithm>
#include <array>
#include <cmath>
#include <cstddef>
#include <cstdint>
#include <span>
#include <vector>

#include <cuda_bf16.h>
#include <cuda_fp16.h>
#include <gtest/gtest.h>

#include "hyle/compute/backends/cuda.h"
#include "hyle/compute/prepared_operation.h"
#include "hyle/compute/tensor.h"
#include "hyle/mem/buffer.h"

namespace flashinfer_test {
namespace compute = hyle::compute;
namespace cuda = compute::cuda;
namespace mem = hyle::mem;

struct Tensor final {
  compute::TensorDesc description;
  mem::Buffer storage;
  compute::TensorView view;

  Tensor(compute::DataType type, std::array<std::int64_t, 4> shape,
         mem::MemoryResourceRef resource)
      : description(compute::TensorDesc::dense(type, shape).value()),
        storage(mem::Buffer::create(resource,
                                    description.required_bytes().value(), 256)
                    .value()),
        view(compute::TensorView::create(description, storage.view()).value()) {
  }
};

template <class T> T encode(float value);
template <> inline float encode<float>(float value) { return value; }
template <> inline __half encode<__half>(float value) {
  return __float2half_rn(value);
}
template <> inline __nv_bfloat16 encode<__nv_bfloat16>(float value) {
  return __float2bfloat16_rn(value);
}
inline float decode(float value) { return value; }
inline float decode(__half value) { return __half2float(value); }
inline float decode(__nv_bfloat16 value) { return __bfloat162float(value); }

template <class T> std::vector<T> payload(Tensor &tensor, int seed) {
  std::vector<T> values(tensor.storage.size() / sizeof(T));
  for (std::size_t i = 0; i < values.size(); ++i)
    values[i] =
        encode<T>(static_cast<float>(
                      static_cast<int>((i + std::size_t(seed)) % 29) - 14) *
                  0.03125F);
  EXPECT_TRUE(
      tensor.storage.view().write(std::as_bytes(std::span(values))).ok());
  return values;
}

template <class T>
void check_output(Tensor &output, const std::vector<T> &q,
                  const std::vector<T> &k, const std::vector<T> &v,
                  int query_length, int kv_length, double tolerance,
                  float scale = 0.0625F, bool causal = true) {
  std::vector<T> actual(q.size());
  ASSERT_TRUE(output.storage.view()
                  .read(std::as_writable_bytes(std::span(actual)))
                  .ok());
  const auto batches = output.description.dimensions()[0];
  const auto query_heads = output.description.dimensions()[2];
  const auto depth = static_cast<std::size_t>(output.description.dimensions()[3]);
  const auto kv_heads = static_cast<std::int64_t>(
      k.size() / (static_cast<std::size_t>(batches * kv_length) * depth));
  const auto head_group = query_heads / kv_heads;
  for (std::int64_t batch = 0; batch < batches; ++batch) {
    for (int n = 0; n < query_length; ++n) {
      for (std::int64_t head = 0; head < query_heads; ++head) {
        const int count = causal ? kv_length - query_length + n + 1 : kv_length;
        std::vector<double> weights(static_cast<std::size_t>(count));
        const auto qo_offset = static_cast<std::size_t>(
            ((batch * query_length + n) * query_heads + head) * depth);
        for (int s = 0; s < count; ++s) {
          const auto kv_offset = static_cast<std::size_t>(
              ((batch * kv_length + s) * kv_heads + head / head_group) * depth);
          double dot = 0;
          for (std::size_t d = 0; d < depth; ++d)
            dot += double(decode(q[qo_offset + d])) * decode(k[kv_offset + d]);
          weights[static_cast<std::size_t>(s)] = dot * scale;
        }
        const double maximum =
            *std::max_element(weights.begin(), weights.end());
        double total = 0;
        for (auto &weight : weights) {
          weight = std::exp(weight - maximum);
          total += weight;
        }
        for (std::size_t d = 0; d < depth; ++d) {
          double expected = 0;
          for (int s = 0; s < count; ++s) {
            const auto kv_offset = static_cast<std::size_t>(
                ((batch * kv_length + s) * kv_heads + head / head_group) * depth);
            expected +=
                weights[static_cast<std::size_t>(s)] * decode(v[kv_offset + d]);
          }
          ASSERT_NEAR(decode(actual[qo_offset + d]), expected / total,
                      tolerance)
              << "batch=" << batch << " token=" << n << " head=" << head
              << " depth=" << d;
        }
      }
    }
  }
}

} // namespace flashinfer_test
