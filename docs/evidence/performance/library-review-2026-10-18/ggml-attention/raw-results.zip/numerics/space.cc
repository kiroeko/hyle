// Actual Hyle Direct consumer. Residency snapshots are not peak VRAM counters.
#include <algorithm>
#include <array>
#include <cmath>
#include <cstdint>
#include <exception>
#include <iomanip>
#include <iostream>
#include <span>
#include <stdexcept>
#include <string>
#include <utility>
#include <vector>
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <bcrypt.h>
#include <cuda_fp16.h>
#include <cuda_runtime_api.h>
#include "hyle/compute/backends/cuda.h"
#include "hyle/compute/prepared_operation.h"
#include "hyle/compute/providers/ggml_cuda.h"
#include "hyle/mem/buffer.h"

namespace c = hyle::compute;
namespace m = hyle::mem;
template<class T> T take(hyle::Result<T> result) {
  if (!result) throw std::runtime_error(std::string(result.error().message()));
  return std::move(*result);
}
void require(hyle::Status result) {
  if (!result.ok()) throw std::runtime_error(std::string(result.message()));
}
void cuda_require(cudaError_t result) {
  if (result != cudaSuccess) throw std::runtime_error(cudaGetErrorString(result));
}
std::size_t used_memory() {
  cuda_require(cudaDeviceSynchronize());
  std::size_t free = 0, total = 0;
  cuda_require(cudaMemGetInfo(&free, &total));
  return total - free;
}
template<class T> T encode(float value);
template<> float encode<float>(float value) { return value; }
template<> __half encode<__half>(float value) { return __float2half_rn(value); }
float decode(float value) { return value; }
float decode(__half value) { return __half2float(value); }

template<class T> void exercise(c::DataType type, const char* name,
                                std::int64_t length) {
  cuda_require(cudaSetDevice(0));
  auto context = take(c::Context::create(take(c::cuda::device(0)),
                                        c::ggml_cuda::provider()));
  auto memory = take(c::cuda::MemoryResource::create(context,
                                                  c::cuda::MemoryKind::kDevice));
  auto queue = take(context.create_queue());
  const auto q = take(c::TensorDesc::dense(type,
      std::array<std::int64_t, 4>{1, length, 8, 256}));
  const auto kv = take(c::TensorDesc::dense(type,
      std::array<std::int64_t, 4>{1, length, 2, 256}));
  const std::array descriptions{q, kv, kv};
  const std::array output_descriptions{q};
  std::array<m::Buffer, 3> buffers;
  std::array<c::ConstTensorView, 3> inputs;
  std::size_t ports = 0;
  for (std::size_t i = 0; i < 3; ++i) {
    const auto bytes = take(descriptions[i].required_bytes());
    ports += bytes;
    buffers[i] = take(m::Buffer::create(memory.ref(), bytes, 256));
    inputs[i] = take(c::ConstTensorView::create(descriptions[i], buffers[i].view()));
    const std::vector<T> data(bytes / sizeof(T), encode<T>(i == 2 ? 1.25F : 0.0F));
    require(buffers[i].view().write(std::as_bytes(std::span(data))));
  }
  const auto output_bytes = take(q.required_bytes());
  ports += output_bytes;
  auto output = take(m::Buffer::create(memory.ref(), output_bytes, 256));
  require(output.view().fill(std::byte{0}));
  const std::array outputs{take(c::TensorView::create(q, output.view()))};
  const auto after_ports = used_memory();
  const c::Operation operation{c::ScaledDotProductAttention{
      .scale = 0.0625F, .causal = true}};
  auto prepared = take(c::prepare(context, operation, descriptions,
                                 output_descriptions, memory.ref()));
  if (prepared.provider().id != c::ggml_cuda::kProviderId)
    throw std::runtime_error("wrong provider");
  const auto after_prepare = used_memory();
  auto invocation = take(prepared.create_invocation());
  const auto after_invocation = used_memory();
  auto done = take(invocation.submit(queue, inputs, outputs));
  require(done.wait());
  const auto after_wait = used_memory();
  std::vector<T> actual(output_bytes / sizeof(T));
  require(output.view().read(std::as_writable_bytes(std::span(actual))));
  double maximum = 0;
  bool finite = true;
  for (T x : actual) {
    finite &= std::isfinite(decode(x));
    maximum = (std::max)(maximum, std::abs(double(decode(x)) - 1.25));
  }
  const double budget = type == c::DataType::kFloat32 ? 0.00001 : 0.002;
  const bool correct = finite && maximum <= budget;
  std::array<unsigned char, 32> digest{};
  if (BCryptHash(BCRYPT_SHA256_ALG_HANDLE, nullptr, 0,
      reinterpret_cast<PUCHAR>(actual.data()), static_cast<ULONG>(output_bytes),
      digest.data(), static_cast<ULONG>(digest.size())) != 0)
    throw std::runtime_error("output SHA256 failed");
  std::cout << "{\"q\":" << length << ",\"kv\":" << length
    << ",\"dtype\":\"" << name << "\",\"batch\":1,\"query_heads\":8"
    << ",\"kv_heads\":2,\"depth\":256,\"ports_requested_bytes\":" << ports
    << ",\"cuda_used_after_ports\":" << after_ports
    << ",\"cuda_used_after_prepare\":" << after_prepare
    << ",\"cuda_used_after_invocation\":" << after_invocation
    << ",\"cuda_used_after_wait\":" << after_wait
    << ",\"timing\":false,\"residency_is_peak\":false,\"fresh_process\":true"
    << ",\"max_error\":" << maximum << ",\"finite\":" << (finite ? "true" : "false")
    << ",\"absolute_budget\":" << budget
    << ",\"correct\":" << (correct ? "true" : "false")
    << ",\"full_output_sha256\":\"";
  for (auto byte : digest)
    std::cout << std::hex << std::setfill('0') << std::setw(2) << unsigned(byte);
  std::cout << "\"}\n";
  if (!correct) throw std::runtime_error("constant output oracle failed");
}
int main(int argc, char** argv) {
  try {
    if (argc != 3) throw std::runtime_error("usage: space.exe f32|f16 length");
    const auto length = std::stoll(argv[2]);
    if (length < 1 || length > 8193) throw std::runtime_error("invalid length");
    if (std::string(argv[1]) == "f32")
      exercise<float>(c::DataType::kFloat32, "F32", length);
    else if (std::string(argv[1]) == "f16")
      exercise<__half>(c::DataType::kFloat16, "F16", length);
    else throw std::runtime_error("invalid dtype");
    return 0;
  } catch (const std::exception& e) {
    std::cerr << e.what() << '\n';
    return 1;
  }
}
