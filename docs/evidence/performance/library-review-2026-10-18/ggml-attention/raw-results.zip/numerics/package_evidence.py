from pathlib import Path
import hashlib, json, re, shutil, zipfile

ROOT = Path(__file__).resolve().parents[3]
TEST = Path(__file__).resolve().parent
PROVIDER = TEST.parent / 'ggml-attention-provider'
F16 = TEST.parent / 'f16-sdpa'
OUT = ROOT / 'evidence/performance/library-review-2026-10-18/ggml-attention'
OUT.mkdir(parents=True, exist_ok=True)
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()

assert sha(PROVIDER / 'source-evidence.zip') == '29dbd2c7960ebbc8ec6fd4546d949f9cfc6272b780ae764eb547f52c6efcc6ca'
assert sha(F16 / 'raw-results.zip') == '425fdfef190e38822c5dbd64e0646a484a328d56116f0b7e2c97130b9b26ea76'
with zipfile.ZipFile(PROVIDER / 'source-evidence.zip') as archive:
    assert archive.testzip() is None
    for name in archive.namelist():
        assert Path(name).suffix.lower() not in {'.dll', '.lib', '.obj', '.exe', '.pdb'}

meta = json.loads((PROVIDER / 'final-source-metadata.json').read_text())
for path, record in meta['product_sources'].items():
    assert sha(ROOT / path) == record['sha256']
final_test = json.loads((TEST / 'final-all-attention-identity.json').read_text())
assert final_test['source_sha256'] == sha(ROOT / 'tests/compute_provider_ggml_cuda/attention_test.cc')
assert final_test['provider_sha256'] == sha(PROVIDER / 'hyle_compute_provider_ggml_cuda.dll')
assert '[  PASSED  ] 10 tests.' in (TEST / 'final-all-attention.log').read_text()

space = json.loads((TEST / 'space-parsed-results.json').read_text())
summary = {
    'task': 'Bound large standalone CUDA SDPA scratch without lowering intermediate precision',
    'outcome': 'Applied Q blocking/liveness reuse, strict per-operation cuBLAS math mode and F16 F32-math fallback. No throughput claim.',
    'baseline': {
        'provider': 'Fresh retained pre-change HEAD source; not the stale b-cuda-d5 provider DLL.',
        'provider_source_sha256': meta['baseline']['sha256'],
        'native_for_final_comparison': 'Both baseline and candidate prepend the same new host dispatch object with current MMF guards and scoped cuBLAS DEFAULT_MATH.',
        'f16_limit': 'Old baseline still uses Half PV flash accumulation, candidate uses F32 math. F16 is not a same-precision throughput comparison.'
    },
    'implementation': {
        'trigger': 'Single-node ScaledDotProductAttention recipe, Q>1, conservative four-score estimate above 8 MiB.',
        'block': 'At most 128 query rows, reduced using a conservative 64 MiB score budget; at least one row.',
        'semantics': 'Full KV per block; bottom-right n_past=KV-Q_total+q_begin; scale before masking; original output strides and copy terminals.',
        'lifetime': 'One native graph in existing root-stream order; ggml gallocr reuses intermediates. Cold reserve precedes real port binding; first submit initializes graph allocation only after valid addresses exist. Subsequent submits refresh views. Invocation drains before freeing scratch.',
        'precision': 'QK/probability/PV remain F32 in ggml math; only final output casts to F16/BF16. Explicit F32-source cuBLAS calls temporarily use DEFAULT_MATH and restore private handle mode, including unwind.',
        'complexity': 'Arithmetic remains O(Q*KV*D). Score scratch is O(B*H*KV*block_rows), with additional linear K/V casts/transposition and block metadata/launches.',
        'budget_limit': '64 MiB is a row-selection target, not total private/VRAM bound. A minimum one-row allocation may itself exceed it; ports, native pools, cuBLAS and driver are separate.',
        'public_options_or_dependencies_added': False
    },
    'validation': {
        'final_attention_tests_passed': 10,
        'log': 'raw-results.zip:numerics/final-all-attention.log',
        'tests_source_sha256': final_test['source_sha256'],
        'shared_reference_header_sha256': sha(ROOT / 'tests/compute_provider_flashinfer/attention_test_support.h'),
        'budgets': 'Existing F16 absolute .002 and BF16 .01 unchanged. New F32 short/prefix tests use .00001. Separate long space-probe budget failures remain failures.',
        'cases': 'Nonzero QK/FP64 oracle, GQA, decode, non-square bottom-right, zero/negative scale, noncausal Q>KV, block/tail/batch strides, two invocations/Queues, rebind, BF16 exponent range, F16 weak probability times large V, MLA cold admission.',
        'closure': 'Current provider TU and fresh dense-rank4 F32/F16/BF16 constructor helper. Other tensor lowering explicitly declines. Reused same foundation cache/native kernel archive with fresh strict host overlay.',
        'compile': 'MSVC14.50 /W4 /WX current provider and test TU; only one native dispatch TU rebuilt with NVCC, no all-kernel rebuild.',
        'not_run': 'Full current IQ1 backend, ordinary default provider roster, generic Graph GPU tests, allocation-fault matrix and Linux CUDA.',
        'dependency_integrity': 'cmake -P check-patch-lock.cmake passed for ggml_cuda_runtime_patches, including updated NOTICE/tree/version.',
        'discovery_limits': 'Early cached-provider and pre-overlay numerical failures are forensic records, not current same-precision baselines. Exact final commands/source are retained; early mutable test helper versions were not all frozen.'
    },
    'product_sources': meta['product_sources'],
    'space_method': {
        'consumer': 'Actual Hyle Direct, CUDA device resource, SharedQueue and owning Completion wait. Fresh process per shape.',
        'input': 'B1 Hq8 Hkv2 D256 Q=KV, Q/K zero, V=1.25, full output observed.',
        'explicit_counter': 'Cold sum of owned ggml scratch buffer sizes and ggml_gallocr_get_buffer_size. Separate probe-only snapshots append one stderr counter; normal test DLL unchanged.',
        'excluded': 'External ports, native allocator pools, cuBLAS workspace, runtime/driver, total device peak.',
        'cuda_mem_info': 'Synchronized per-phase used-memory snapshots, including other clients; not peak counters or same as explicit private allocation.',
        'initial_probe_source': 'numerics/space.initial.cc; original first-ten source SHA verified against run identity.',
        'hash_probe_source': 'numerics/space.cc; output SHA256 added for the four followups; same values and unchanged budget.',
        'timing_measured': False
    },
    'space_results_all_10': space['rows'],
    'f32_output_hash_followups': space['output_checks'],
    'numeric_limits': {
        'f32_large_space_probe': 'Both 2K and 8K baseline/candidate fail the self-selected absolute 1e-5 budget, max 3.43323e-5 and .00014174. Full output SHA256 matches respectively. No tolerance change and no numeric pass claimed for those points; allocation counts remain factual.',
        'f16_8k': 'Old flash constant output max error .149414; new F32 math zero. This diagnoses a precision gap and is not a fair old/new throughput ranking.',
        'torch_f16': 'Native Half efficient weak-probability case fails .002 with max .027413951. Half->Float efficient(TF32x3)->Half passes only this case but remains a different intermediate domain; neither extension/default route was enabled.',
        'torch_f16_space_limit': 'Its recorded peak starts after promotions and excludes the three Float input casts; no full Hyle-route space or speed measurement.'
    },
    'archives': {
        'provider-source.zip': 'Current/baseline/provider-helper/native-overlay/diagnostic sources, exact build commands, source hashes, F16 source-level review and pure cuBLAS causal probe. Original provider metadata reports the earlier nine-test checkpoint; final ten-test record is above.',
        'raw-results.zip': 'All local numeric/space logs and identities, both space consumers, final regression/reference snapshots, runners and rejected F16 native experiment archive.'
    }
}
(OUT / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
shutil.copyfile(PROVIDER / 'source-evidence.zip', OUT / 'provider-source.zip')
allowed = {'.json', '.jsonl', '.log', '.txt', '.py', '.cc', '.cmake'}
with zipfile.ZipFile(OUT / 'raw-results.zip', 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for path in sorted(TEST.iterdir(), key=lambda p: p.name):
        if path.is_file() and path.suffix in allowed:
            archive.write(path, 'numerics/' + path.name)
    archive.write(ROOT / 'tests/compute_provider_ggml_cuda/attention_test.cc', 'tests/attention_test.cc')
    archive.write(ROOT / 'tests/compute_provider_flashinfer/attention_test_support.h', 'tests/attention_test_support.h')
    archive.write(F16 / 'raw-results.zip', 'rejected-torch-f16/raw-results.zip')
    archive.write(F16 / 'summary.json', 'rejected-torch-f16/summary.json')
    archive.write(F16 / 'archive-record.json', 'rejected-torch-f16/archive-record.json')
record = {name: {'bytes': (OUT / name).stat().st_size, 'sha256': sha(OUT / name)}
          for name in ['summary.json', 'provider-source.zip', 'raw-results.zip']}
(OUT / 'archive-record.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record, indent=2))
