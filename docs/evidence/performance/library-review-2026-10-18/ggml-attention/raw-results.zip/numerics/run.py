from pathlib import Path
import argparse, hashlib, json, os, re, shlex, subprocess, sys

ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT / 'scripts'))
from hyle_environment import windows_compiler_environment
from hyle_support import read_cache

OUT = Path(__file__).resolve().parent
BUILD = ROOT / '.scratch/b-cuda-d5'
parser = argparse.ArgumentParser()
parser.add_argument('--compile', action='store_true')
parser.add_argument('--run', action='store_true')
parser.add_argument('--provider-bin', type=Path, default=BUILD / 'bin')
parser.add_argument('--filter', default='GgmlCudaAttention.*')
parser.add_argument('--tag', default='baseline')
parser.add_argument('--space', help='f32|f16:length; compile/run the space consumer')
args = parser.parse_args()
cache = read_cache(BUILD)
env = windows_compiler_environment(cache)
env['VSLANG'] = '1033'
toolkit = Path(cache.get('CUDAToolkit_ROOT') or
               Path(cache['CMAKE_CUDA_COMPILER']).parent.parent)
env['PATH'] = os.pathsep.join(map(str, [args.provider_bin.resolve(), BUILD / 'bin',
    toolkit / 'bin/x64', toolkit / 'bin', env['PATH']]))
target = 'tests/compute_provider_ggml_cuda/CMakeFiles/hyle_compute_provider_ggml_cuda_test.dir/attention_test.cc.obj'
obj = OUT / ('space.obj' if args.space else 'attention_test.obj')
exe = OUT / ('space.exe' if args.space else 'attention_tests.exe')
source = OUT / 'space.cc' if args.space else ROOT / 'tests/compute_provider_ggml_cuda/attention_test.cc'

def invoke(command, tag, timeout=120):
    record = {'command': command, 'cwd': str(BUILD), 'timeout_seconds': timeout}
    result = subprocess.run(command, cwd=BUILD, env=env,
        stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=timeout)
    record['exit'] = result.returncode
    (OUT / (tag + '-command.json')).write_text(json.dumps(record, indent=2))
    (OUT / (tag + '.log')).write_bytes(result.stdout)
    print('\n'.join(line for line in result.stdout.decode('utf-8', errors='replace').splitlines()
        if not line.startswith('Note: including file:')))
    if result.returncode:
        raise SystemExit(result.returncode)

if args.compile:
    commands = subprocess.check_output([cache['CMAKE_MAKE_PROGRAM'], '-t', 'commands', target],
        cwd=BUILD, env=env, text=True).splitlines()
    command = next(line for line in commands if 'attention_test.cc' in line and 'cl.exe' in line)
    if args.space:
        command = command.replace(str(ROOT / 'tests/compute_provider_ggml_cuda/attention_test.cc'), str(source))
    command = re.sub(r'/Fo(?:"[^"]+"|\S+)', '/Fo"' + str(obj).replace('\\', '/') + '"', command)
    command = re.sub(r'/Fd(?:"[^"]+"|\S+)', '/Fd"' + str(OUT / 'test.pdb').replace('\\', '/') + '"', command)
    invoke(command, 'space-compile' if args.space else 'compile')
    block = (BUILD / 'build.ninja').read_text().split(
        'build bin\\hyle_compute_provider_ggml_cuda_test.exe:', 1)[1].split('\n\n', 1)[0]
    line = re.search(r'^  LINK_LIBRARIES = (.*)$', block, re.M).group(1)
    libraries = [item.strip('"') for item in shlex.split(line, posix=False)]
    if args.space:
        libraries.append('bcrypt.lib')
    link = [str(Path(cache['CMAKE_CXX_COMPILER']).with_name('link.exe')), '/nologo',
        '/machine:x64', '/INCREMENTAL:NO', '/subsystem:console', '/out:' + str(exe),
        str(obj), *libraries]
    invoke(link, 'space-link' if args.space else 'link')

if args.run:
    dll = args.provider_bin / 'hyle_compute_provider_ggml_cuda.dll'
    identity = {'executable_sha256': hashlib.sha256(exe.read_bytes()).hexdigest(),
        'provider_path': str(dll.resolve()),
        'provider_sha256': hashlib.sha256(dll.read_bytes()).hexdigest(),
        'source_sha256': hashlib.sha256(source.read_bytes()).hexdigest(),
        'cache_reuse': 'Existing shared foundation and native ggml CUDA libraries; no configure/build or SDK staging.',
        'path_prefix': env['PATH'].split(os.pathsep)[:4]}
    (OUT / (args.tag + '-identity.json')).write_text(json.dumps(identity, indent=2))
    command = [str(exe), *args.space.split(':')] if args.space else [str(exe), '--gtest_filter=' + args.filter]
    invoke(command, args.tag)
