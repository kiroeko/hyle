#include <cuda_runtime_api.h>
#include <cuda_fp16.h>
#include <cublas_v2.h>
#include <algorithm>
#include <cmath>
#include <iomanip>
#include <iostream>
#include <stdexcept>
#include <string>
#include <vector>

void check(cudaError_t s) { if (s != cudaSuccess) throw std::runtime_error(cudaGetErrorString(s)); }
void check(cublasStatus_t s) { if (s != CUBLAS_STATUS_SUCCESS) throw std::runtime_error("cuBLAS status " + std::to_string(int(s))); }
int main() {
  try {
    constexpr int m = 256, n = 257, k = 273, batches = 16;
    constexpr float value = -.34375F;
    std::vector<float> a(k*m, value), b(k*n, 0), c(m*n*batches);
    for (int row = 0; row < n; ++row)
      for (int key = 0; key < 17+row; ++key) b[row*k+key] = 1.F / float(17+row);
    float *ad, *bd, *cd;
    check(cudaMalloc(reinterpret_cast<void**>(&ad), a.size()*sizeof(float)));
    check(cudaMalloc(reinterpret_cast<void**>(&bd), b.size()*sizeof(float)));
    check(cudaMalloc(reinterpret_cast<void**>(&cd), c.size()*sizeof(float)));
    check(cudaMemcpy(ad,a.data(),a.size()*sizeof(float),cudaMemcpyHostToDevice));
    check(cudaMemcpy(bd,b.data(),b.size()*sizeof(float),cudaMemcpyHostToDevice));
    std::vector<const float*> ap(batches,ad),bp(batches,bd);
    std::vector<float*> cp(batches);
    for(int i=0;i<batches;++i)cp[i]=cd+i*m*n;
    const float **apd,**bpd;float **cpd;
    check(cudaMalloc(reinterpret_cast<void**>(&apd),batches*sizeof(float*)));check(cudaMalloc(reinterpret_cast<void**>(&bpd),batches*sizeof(float*)));check(cudaMalloc(reinterpret_cast<void**>(&cpd),batches*sizeof(float*)));
    check(cudaMemcpy(apd,ap.data(),batches*sizeof(float*),cudaMemcpyHostToDevice));
    check(cudaMemcpy(bpd,bp.data(),batches*sizeof(float*),cudaMemcpyHostToDevice));
    check(cudaMemcpy(cpd,cp.data(),batches*sizeof(float*),cudaMemcpyHostToDevice));
    cublasHandle_t handle;check(cublasCreate(&handle));
    int version=0;check(cublasGetVersion(handle,&version));
    std::cout << std::setprecision(17) << "{\"cublas_version\":" << version << ",\"inputs\":\"F32 A/V and F32 B/probabilities; no half storage or Hyle operator\",\"m\":"<<m<<",\"n\":"<<n<<",\"k\":"<<k<<",\"batches\":"<<batches<<"}\n";
    const float alpha=1,beta=0;
    const auto run=[&](const char* name,cublasMath_t math,cublasComputeType_t compute,bool sgemm){
      check(cublasSetMathMode(handle,math));
      if(sgemm)check(cublasSgemm(handle,CUBLAS_OP_T,CUBLAS_OP_N,m,n,k,&alpha,ad,k,bd,k,&beta,cd,m));
      else check(cublasGemmBatchedEx(handle,CUBLAS_OP_T,CUBLAS_OP_N,m,n,k,&alpha,
          reinterpret_cast<const void* const*>(apd),CUDA_R_32F,k,
          reinterpret_cast<const void* const*>(bpd),CUDA_R_32F,k,&beta,
          reinterpret_cast<void* const*>(cpd),CUDA_R_32F,m,batches,compute,CUBLAS_GEMM_DEFAULT_TENSOR_OP));
      check(cudaDeviceSynchronize());
      check(cudaMemcpy(c.data(),cd,c.size()*sizeof(float),cudaMemcpyDeviceToHost));
      const int batch_count=sgemm?1:batches;double max_formula=0,max_actual_input=0;
      for(int batch=0;batch<batch_count;++batch)for(int row=0;row<n;++row)for(int d=0;d<m;++d){
        const double x=c[(batch*n+row)*m+d];
        max_formula=std::max(max_formula,std::abs(x-double(value)));
        max_actual_input=std::max(max_actual_input,std::abs(x-double(value)*double(b[row*k])*double(17+row)));
      }
      const double half_control=double(value)*__half2float(__float2half_rn(1.F/17))*17;
      std::cout << "{\"mode\":\""<<name<<"\",\"math_enum\":"<<int(math)<<",\"compute_enum\":"<<int(compute)
        <<",\"first_row_output\":"<<c[0]<<",\"uniform_formula\":"<<value<<",\"f64_from_actual_f32_probability\":"<<double(value)*double(b[0])*17
        <<",\"f64_after_explicit_half_probability_control\":"<<half_control
        <<",\"max_abs_vs_uniform_formula\":"<<max_formula<<",\"max_abs_vs_actual_f32_inputs\":"<<max_actual_input<<"}\n";
    };
    run("batched-tf32math-f32compute",CUBLAS_TF32_TENSOR_OP_MATH,CUBLAS_COMPUTE_32F,false);
    run("batched-defaultmath-f32compute",CUBLAS_DEFAULT_MATH,CUBLAS_COMPUTE_32F,false);
    run("batched-pedanticmath-f32compute",CUBLAS_PEDANTIC_MATH,CUBLAS_COMPUTE_32F,false);
    run("batched-tf32math-pedanticcompute",CUBLAS_TF32_TENSOR_OP_MATH,CUBLAS_COMPUTE_32F_PEDANTIC,false);
    run("sgemm-tf32math",CUBLAS_TF32_TENSOR_OP_MATH,CUBLAS_COMPUTE_32F,true);
    run("sgemm-defaultmath",CUBLAS_DEFAULT_MATH,CUBLAS_COMPUTE_32F,true);
    check(cublasDestroy(handle));
    for(void* ptr:{static_cast<void*>(ad),static_cast<void*>(bd),static_cast<void*>(cd),static_cast<void*>(apd),static_cast<void*>(bpd),static_cast<void*>(cpd)})check(cudaFree(ptr));
    return 0;
  } catch(const std::exception& e){std::cerr<<e.what()<<'\n';return 2;}
}
