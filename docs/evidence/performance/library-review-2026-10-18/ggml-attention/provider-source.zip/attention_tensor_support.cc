// Probe-only attention validation closure. Other tensor operations decline.
#include "tensor_program.h"
#include <array>
#include <algorithm>
namespace hyle::compute::ggml_cuda::internal {
bool tensor_operation_supports(Operation, std::span<const TensorDesc>,
                               std::span<const TensorDesc>) noexcept { return false; }
ggml_tensor *create_tensor_input(ggml_context *context, const TensorDesc &description) {
  const auto type = description.data_type() == DataType::kFloat16 ? GGML_TYPE_F16
      : description.data_type() == DataType::kBFloat16 ? GGML_TYPE_BF16 : GGML_TYPE_F32;
  std::array<std::int64_t, GGML_MAX_DIMS> shape{1, 1, 1, 1};
  std::reverse_copy(description.dimensions().begin(), description.dimensions().end(), shape.begin());
  return ggml_new_tensor(context, type, static_cast<int>(description.rank()), shape.data());
}
std::vector<ggml_tensor *> lower_tensor_operation(ggml_context *, const Recipe &,
    const Node &, std::span<ggml_tensor *const>, std::vector<ScalarConstant> &,
    std::vector<DenseConstant> &, std::span<const float>) { return {}; }
}
