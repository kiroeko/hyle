"""Freeze only source, commands and results; no build, run or deletion."""
from pathlib import Path
import hashlib
import json
import re
import subprocess
import zipfile

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
HAD = OUT.parent / "cpu-hadamard"
PRIOR = OUT.parent / "cpu-math-attention"
BASELINE = "143f2fedf89e071cc79ae98d15ba482797bf89c5"
PRODUCT = ["src/compute_provider_ggml/ggml_cpu_provider.cc",
           "tests/compute_provider_ggml/attention_math_test.cc"]


def identity(path):
    data = path.read_bytes()
    return {"bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}


def save(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2) + "\n", encoding="utf-8")


def git(*args):
    return subprocess.check_output(["git", *args], cwd=ROOT)


files = {}
source_identity = {}
for path, tested in zip(PRODUCT, ("provider-tested.cc", "tests-tested.cc")):
    current = ROOT / path
    before_format = OUT / tested
    assert re.sub(rb"\s", b"", current.read_bytes()) == re.sub(rb"\s", b"", before_format.read_bytes())
    source_identity[path] = {"applied": identity(current), "tested": identity(before_format),
                             "difference_only_whitespace": True}
    files["applied/" + path] = current
    files[tested] = before_format
baseline_provider = OUT / "baseline" / PRODUCT[0]
assert baseline_provider.read_bytes().replace(b"\r\n", b"\n") == git("show", BASELINE + ":" + PRODUCT[0]).replace(b"\r\n", b"\n")
files["baseline/" + PRODUCT[0]] = baseline_provider
files["attention_math_test-before.cc"] = OUT / "attention_math_test-before.cc"
save("source-identity.json", source_identity)
(OUT / "product.patch").write_bytes(git("diff", "--", *PRODUCT))

references = ["cmake/HyleDependencyLock.json", "src/compute_provider_ggml/CMakeLists.txt",
              "tests/compute_provider_ggml/CMakeLists.txt", "src/compute_ggml_runtime/cpu_program.cc",
              "src/compute_ggml_runtime/cpu_program_abi.h", "src/compute_ggml_runtime/cpu_execution.cc",
              "scripts/hyle_environment.py", "tests/compute_ggml_runtime/gallocr_faults.c",
              "tests/compute_ggml_runtime/gallocr_faults.h"]
for name in ("ggml_runtime", "ggml_cpu_runtime", "ggml_vulkan_runtime"):
    references += [f"third_party/{name}/patches.json", f"third_party/{name}/NOTICE.md"]
save("reference-identity.json", {path: identity(ROOT / path) for path in references})
for path in references:
    files["reference/" + path] = ROOT / path
for pin, manifest in (("ffa4", "ggml_cpu_runtime"), ("mixed", "ggml_runtime")):
    allocator = OUT / pin / "ggml-alloc.fallible.c"
    patches = json.loads((ROOT / "third_party" / manifest / "patches.json").read_text())
    allocator_patch = next(x for x in patches["files"] if x["path"] == "src/ggml-alloc.c")
    assert identity(allocator)["sha256"] == allocator_patch["after_sha256"]
    for name in ("ggml-alloc.fallible.c", "gallocr_faults.c"):
        files[f"{pin}/{name}"] = OUT / pin / name
for name in ("run.py", "commands.json", "source-identity.json", "summary.json"):
    files["borrowed-cpu-hadamard/" + name] = HAD / name
for pin in ("ffa4", "mixed"):
    files[f"borrowed-cpu-hadamard/{pin}/ops.unary.cpp"] = HAD / pin / "ops.unary.cpp"
for name in ("allocator-preparation.json", "resource-tree-identities.json"):
    files["borrowed-cpu-math-attention/" + name] = PRIOR / name

cleanup = []
for folder in (OUT, HAD / "__pycache__"):
    if not folder.exists():
        continue
    for path in sorted(folder.rglob("*"), key=lambda p: p.as_posix()):
        if path.is_file() and path.suffix.lower() in {".obj", ".exe", ".pdb", ".ilk", ".lib", ".exp", ".pyc"}:
            assert path.resolve().is_relative_to(OUT.resolve()) or path.resolve().is_relative_to((HAD / "__pycache__").resolve())
            cleanup.append({"path": str(path.resolve()), **identity(path)})
retain = []
for pin in ("ffa4", "mixed"):
    for name in ("native-baseline.obj", f"hyle_ggml_cpu_avx2_{pin}_hadamard_v2_overlay.dll"):
        path = HAD / pin / name
        retain.append({"path": str(path.resolve()), **identity(path)})
save("cleanup-and-retain.json", {
    "rule": "Exact files only; root writes test.ps1 and executes. Nothing removed by this script.",
    "delete_candidates": cleanup, "delete_total_bytes": sum(x["bytes"] for x in cleanup),
    "retain_for_future_cpu_work": retain, "retain_total_bytes": sum(x["bytes"] for x in retain),
    "exclude": "All shared SDK/native/foundation caches and the four retained CPUHad files. Only new host overlay/test images and recreated CPUHad Python bytecode are cleanup candidates."})

save("summary.json", {
    "status": "implemented_focused_validation_complete_awaiting_root_review",
    "baseline_commit": BASELINE,
    "scope": "Official existing GraphStorage for tiled || (recipe.nodes.size()>1 and noCacheEncode/PagedRead). Single nodes, private cache strategies, alias rules, selected CPU executor, precision and native kernels unchanged.",
    "implementation": "Only internal strategy and ownership comment changed; cold reserve, scalar-aligned real bindings, native input/output-root marks, first alloc_graph, view refresh and error cleanup reuse the already-shipping implementation.",
    "validation": {
        "candidate_tests": {"ffa4": "9/9 PASS", "mixed": "9/9 PASS"},
        "baseline_tests": "Both8/9; only new OrdinaryChainColdAllocationIsBounded assertion fails, raw logs retained. Same numerical/lifetime tests pass.",
        "coverage": "64step small finite chain with published step32 view/root, source immutability, two independent slots each rebound to two real4B-offset port sets with no AllocatorRef allocation/free during calls; branch+Fill constant+ReLU+BF16/F32 Cast+safeSoftmax NaN callbacks; cold quota0/1MiB failure charge rollback and successful retry; existing5 tiled-attention/native-gallocr checks retained.",
        "numerics": "Neg chain, finite branch and published ReLU values checked exactly. Dyadic inputs/Fill2 remain exactly representable after BF16 casts. FP64 softmax oracle abs2e-6 unchanged new budget; undefined rows and per-element NaNs checked explicitly.",
        "prepared_limit": "Actual invocation AllocatorRef counters monitored. No end-to-end global new/C malloc interception, no concurrent-slot stress. Retained native allocator fault fixture is separate from actual provider injection.",
        "boundary": "Fresh current Hyle provider/test/selector host objects and native allocator overlay link before pinned native archives, with retained ABI2 CPUHad selected AVX2 modules. Internal compile recipe/multi-node provider shared_submit uses real CPU Queue; no full public Graph partitioner/installed SDK build.",
        "build": "MSVC14.50.35717 Release/O2/MD; fresh Hyle C++ /W4 /WX. Direct CL/LINK only; no configure/cmake --build/SDK copy/download.",
        "initial_harness_compile_failures_retained": ["Fill TensorShape requires create() rather than aggregate braces", "Operation constructor is explicit; wrap native operation structs"],
        "post_test_edit": "Whitespace-only wrapping of new predicate and Fill initializer. Both exact tested snapshots and applied files included, with whitespace-stripped byte equality asserted. No semantic edit after tests.",
        "no_timing": True,
    },
    "cold_allocation": {
        "shape": "64Neg nodes, F32[256,1024],1MiB each, one input/one final output",
        "metric": "Actual incremental AllocatorRef live requested private bytes across create_invocation after prepare, including tracked native backing/metadata/workspace. Not RSS, peak resident, whole-process memory or complete C malloc metadata.",
        "baseline_both_pins_bytes": 67049688,
        "candidate_ffa4_bytes": 3086784,
        "candidate_mixed_bytes": 3086752,
        "caller_logical_required_bytes": 2097152,
        "caller_allocated_or_large_numerical_execution_in_this_cold_test": False,
        "legacy_owned_payload_census_from_source_bytes": 66060288,
        "native_backing_request_seen_in_candidate_quota_failure_bytes": 2097152,
    },
    "dependencies": {"pins": ["ffa4e8b80930029a35991f94e7c8a93cd67730ab", "456172ec733a mixed locked pin"],
                     "retain_cpu_hadamard_archive": {"path": str(HAD / "source-results.zip"), **identity(HAD / "source-results.zip")},
                     "prior_cpu_allocator_archive": {"path": str(PRIOR / "source-evidence.zip"), **identity(PRIOR / "source-evidence.zip")}},
})
for path in OUT.iterdir():
    if path.is_file() and path.suffix in {".json", ".log", ".py", ".patch"} and path.name != "archive-record.json":
        files[path.name] = path
archive = OUT / "source-evidence.zip"
with zipfile.ZipFile(archive, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for name, path in sorted(files.items()):
        assert path.suffix not in {".obj", ".exe", ".dll", ".lib", ".zip", ".pdb", ".pyc"}
        z.write(path, name)
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    count = len(z.infolist())
record = {"path": str(archive), **identity(archive), "members": count,
          "cleanup_files": len(cleanup), "cleanup_bytes": sum(x["bytes"] for x in cleanup)}
save("archive-record.json", record)
print(json.dumps({"archive": record, "source": source_identity}, indent=2))
