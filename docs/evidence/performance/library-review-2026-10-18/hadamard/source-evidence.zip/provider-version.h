#define HYLE_GGML_CUDA_PROVIDER_VERSION "hadamard-factor64+legacy-native+3IQ1decline-probe"
