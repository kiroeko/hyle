#include "../../../tests/compute_provider_ggml_cuda/hadamard_test.cc"
#include "hyle/graph/cuda.h"
#include "hyle/graph/providers/ggml_cuda.h"
#include <chrono>
#include <iomanip>
#include <iostream>
#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#include <windows.h>

namespace {
std::vector<double> reference(std::span<const float> input, std::int64_t width) {
  std::vector<double> result(input.size());
  for (std::size_t begin=0;begin<input.size();begin+=std::size_t(width))
    for (std::int64_t row=0;row<width;++row) {
      double sum=0;
      for (std::int64_t column=0;column<width;++column)
        sum+=(std::popcount(std::uint64_t(row&column))%2 ? -1 : 1)*double(input[begin+std::size_t(column)]);
      result[begin+std::size_t(row)]=sum/std::sqrt(double(width));
    }
  return result;
}
TEST(HadamardProbe, DirectColdSpaceAndWarmLatency) {
  ASSERT_NE(SetThreadAffinityMask(GetCurrentThread(),DWORD_PTR{1}<<4),0u);
  auto context=Context::create(cuda::device(0).value(),ggml_cuda::provider()).value();
  auto memory=cuda::MemoryResource::create(context,cuda::MemoryKind::kDevice).value();
  constexpr std::int64_t width=4096;
  const auto desc=dense(DataType::kFloat32,{2,2,width});
  std::vector<float> payload(std::size_t(4*width));
  for(std::size_t i=0;i<payload.size();++i)payload[i]=float(int((i*13+3)%29)-14)/32.0F;
  for(std::size_t i=0;i<payload.size();i+=std::size_t(width))payload[i]+=1.0F/64.0F;
  const auto expected=reference(payload,width);
  auto input=upload<float>(memory.ref(),payload),output=output_buffer(memory.ref(),desc);
  const std::array inputs{ConstTensorView::create(desc,input.view()).value()};
  const std::array outputs{TensorView::create(desc,output.view()).value()};
  auto prepared=prepare(context,Operation(Hadamard{}),inputs,outputs,memory.ref());
  ASSERT_TRUE(prepared)<<prepared.error().message();
  ASSERT_EQ(prepared->provider().id,ggml_cuda::kProviderId);
  auto invocation=prepared->create_invocation();ASSERT_TRUE(invocation)<<invocation.error().message();
  auto queue=context.create_queue().value();
  const auto execute=[&]() -> hyle::Status {
    auto done=invocation->submit(queue,inputs,outputs);
    if(!done)return done.error();
    return done->wait();
  };
  ASSERT_TRUE(execute().ok());
  const auto verify=[&]() {
    const auto actual=half_test::read<float>(output);
    double maximum=0;
    for(std::size_t i=0;i<actual.size();++i) {
      EXPECT_TRUE(std::isfinite(actual[i]));
      maximum=std::max(maximum,std::abs(double(actual[i])-expected[i]));
    }
    EXPECT_LE(maximum,2.e-6);return maximum;
  };
  const auto before=verify();ASSERT_FALSE(::testing::Test::HasFailure());
  for(int i=0;i<8;++i)ASSERT_TRUE(execute().ok());
  constexpr int rounds=128;
  const auto begin=std::chrono::steady_clock::now();
  for(int i=0;i<rounds;++i)ASSERT_TRUE(execute().ok());
  const auto ns=std::chrono::duration<double,std::nano>(std::chrono::steady_clock::now()-begin).count();
  const auto after=verify();
  LARGE_INTEGER frequency;ASSERT_NE(QueryPerformanceFrequency(&frequency),0);
  std::cout<<std::setprecision(17)<<"{\"width\":4096,\"rows\":4,\"rounds\":"<<rounds
      <<",\"ns_per_submit_wait\":"<<ns/rounds<<",\"aggregate_ns\":"<<ns
      <<",\"max_error_before\":"<<before<<",\"max_error_after\":"<<after
      <<",\"budget\":0.000002,\"qpc_frequency_hz\":"<<frequency.QuadPart
      <<",\"caller_ports_bytes\":"<<payload.size()*sizeof(float)*2<<"}\n";
}

TEST(HadamardProbe, GraphKeepsDownstreamAddAfterLargeTransform) {
  namespace graph=hyle::graph;
  constexpr std::int64_t width=4096;
  const auto desc=dense(DataType::kFloat32,{1,width});
  auto builder=graph::GraphBuilder::create().value();
  auto x=builder.input(desc).value(),bias=builder.input(desc).value();
  auto rotated=builder.add(Hadamard{},x).value();
  auto y=builder.add(Binary{.kind=BinaryKind::kAdd},rotated,bias).value();
  ASSERT_TRUE(builder.publish(y).ok());
  auto context=Context::create(cuda::device(0).value(),graph::ggml_cuda::provider()).value();
  auto memory=cuda::MemoryResource::create(context,cuda::MemoryKind::kDevice).value();
  auto logical=std::move(builder).finish().value();
  const std::array domains{graph::StorageDomain{.resource=memory.ref()}};
  const std::array targets{graph::ExecutionTarget{.context=&context,.default_storage=graph::StorageDomainId{0}}};
  const std::array lanes{graph::ExecutionLane{.target=graph::ExecutionTargetId{0}}};
  auto compiled=graph::compile(logical,{.storage_domains=domains,.targets=targets,.lanes=lanes});
  ASSERT_TRUE(compiled)<<compiled.error().message();
  ASSERT_EQ(compiled->report.step_count(),1u);
  std::vector<float> payload(std::size_t(width),0.0F),offsets(std::size_t(width),0.0F);
  for(std::size_t i=0;i<payload.size();++i) {payload[i]=float(int((i*7)%29)-14)/32.0F;offsets[i]=float(i%3)/16.0F;}
  const auto expected=reference(payload,width);
  auto input=upload<float>(memory.ref(),payload),addition=upload<float>(memory.ref(),offsets),output=output_buffer(memory.ref(),desc);
  auto invocation=compiled->executable.create_invocation().value();
  ASSERT_TRUE(invocation.bind(x,ConstTensorView::create(desc,input.view()).value()).ok());
  ASSERT_TRUE(invocation.bind(bias,ConstTensorView::create(desc,addition.view()).value()).ok());
  ASSERT_TRUE(invocation.bind(y,TensorView::create(desc,output.view()).value()).ok());
  auto queue=context.create_queue().value();
  const std::array queues{graph::QueueBinding{.lane=graph::ExecutionLaneId{0},.queue=&queue}};
  ASSERT_TRUE(invocation.prepare_replay(queues).ok());
  auto done=invocation.submit(queue);ASSERT_TRUE(done)<<done.error().message();ASSERT_TRUE(done->wait().ok());
  const auto actual=half_test::read<float>(output);
  for(std::size_t i=0;i<actual.size();++i)EXPECT_NEAR(actual[i],expected[i]+offsets[i],2.e-6);
}
}
