from pathlib import Path
import argparse,difflib,hashlib,json,os,re,subprocess,sys
OUT=Path(__file__).resolve().parent;ROOT=OUT.parents[2]
CONCAT=OUT.parent/'concat';OLD=OUT.parent/'ggml-attention-provider'
BUILD=ROOT/'.scratch/b-cuda-d5'
sys.path.insert(0,str(ROOT/'scripts'))
from hyle_environment import windows_compiler_environment
from hyle_support import read_cache
cache=read_cache(BUILD);env=windows_compiler_environment(cache);env['VSLANG']='1033'
toolkit=Path(cache.get('CUDAToolkit_ROOT') or Path(cache['CMAKE_CUDA_COMPILER']).parent.parent)
env['PATH']=os.pathsep.join([str(toolkit/'bin/x64'),str(toolkit/'bin'),env['PATH']])
parser=argparse.ArgumentParser();parser.add_argument('action',choices=['build','tests','latency']);args=parser.parse_args()
def invoke(tag,command,allow_fail=False):
 p=subprocess.run(command,cwd=BUILD,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=180)
 (OUT/(tag+'-command.json')).write_text(json.dumps({'command':command,'cwd':str(BUILD),'exit':p.returncode},indent=2))
 (OUT/(tag+'.stdout.txt')).write_bytes(p.stdout);(OUT/(tag+'.stderr.txt')).write_bytes(p.stderr)
 print(tag,p.returncode,flush=True)
 if p.returncode and not allow_fail:print(p.stdout.decode('utf-8',errors='replace')+p.stderr.decode('utf-8',errors='replace'));raise SystemExit(p.returncode)
 return p
def compile_source(source,obj,tag):
 command=json.loads((CONCAT/'static-provider-compile-command.json').read_text())['command']
 command=re.sub(r'-c \S+',lambda _:'-c '+str(source),command)
 command=re.sub(r'/Fo(?:"[^"]+"|\S+)',lambda _:'/Fo"'+str(obj)+'"',command)
 command=re.sub(r'/Fd(?:"[^"]+"|\S+)',lambda _:'/Fd"'+str(obj.with_suffix('.pdb'))+'"',command)
 command=command.replace(str(CONCAT/'provider-version.h'),str(OUT/'provider-version.h'))
 invoke(tag,command)
if args.action=='build':
 (OUT/'provider-version.h').write_text('#define HYLE_GGML_CUDA_PROVIDER_VERSION "hadamard-factor64+legacy-native+3IQ1decline-probe"\n')
 (OUT/'provider.candidate.cc').write_bytes((ROOT/'src/compute_provider_ggml_cuda/ggml_cuda_provider.cc').read_bytes())
 (OUT/'tensor.candidate.cc').write_bytes((ROOT/'src/compute_provider_ggml_cuda/tensor_program.cc').read_bytes())
 (OUT/'tensor_program.h').write_bytes((ROOT/'src/compute_provider_ggml_cuda/tensor_program.h').read_bytes())
 (OUT/'hadamard_test.measured.cc').write_bytes((ROOT/'tests/compute_provider_ggml_cuda/hadamard_test.cc').read_bytes())
 marker='    return Status::Ok();\n  }\n};\n\nStatus create_context'
 for variant in ['baseline','candidate']:
  tensor=(OUT/('tensor.'+variant+'.cc')).read_text();adapter=tensor
  for enum in ['IQ1_XS','IQ1_XXS','IQ1_XXXS']:
   assert adapter.count('return GGML_TYPE_'+enum+';')==1
   adapter=adapter.replace('return GGML_TYPE_'+enum+';','return GGML_TYPE_COUNT; // validation-only legacy SDK decline')
  adapted=OUT/('tensor.'+variant+'.probe.cc');adapted.write_text(adapter)
  (OUT/(variant+'-validation-adapter.diff')).write_text(''.join(difflib.unified_diff(tensor.splitlines(True),adapter.splitlines(True))))
  compile_source(adapted,OUT/(variant+'-tensor.obj'),variant+'-tensor-compile')
  source=(OUT/('provider.'+variant+'.cc')).read_text();assert source.count(marker)==1
  diagnostic='''    std::size_t host_size=0,host_capacity=0,constant_bytes=0,private_bytes=0;
    for (const auto &matrix : program.hadamards) { host_size+=matrix.size()*sizeof(float);host_capacity+=matrix.capacity()*sizeof(float); }
    for (const auto &constant : dense_constants) constant_bytes+=constant.bytes;
    for (auto *buffer : scratch) private_bytes+=ggml_backend_buffer_get_size(buffer);
    std::fprintf(stderr,"HYLE_HADAMARD_COLD_BYTES host_size=%zu host_capacity=%zu constants=%zu private=%zu tensors=%zu graph_nodes=%d\\n",host_size,host_capacity,constant_bytes,private_bytes,resources,nodes);
'''
  diag=source.replace('#include <cmath>','#include <cmath>\n#include <cstdio>').replace(marker,diagnostic+marker)
  snapshot=OUT/('provider.'+variant+'.probe.cc');snapshot.write_text(diag)
  (OUT/(variant+'-diagnostic.diff')).write_text(''.join(difflib.unified_diff(source.splitlines(True),diag.splitlines(True))))
  compile_source(snapshot,OUT/(variant+'-provider.obj'),variant+'-provider-compile')
 compile_source(OUT/'region.frozen.cc',OUT/'region.obj','region-compile')
 compile_source(OUT/'consumer.cc',OUT/'consumer.obj','consumer-compile')
 base=json.loads((CONCAT/'static-region-tests-link-command.json').read_text())['command']
 for variant in ['baseline','candidate']:
  cmd=[]
  for item in base:
   if item.startswith('/implib:'):continue
   if item.startswith('/out:'):item='/out:'+str(OUT/(variant+'.exe'))
   elif item==str(CONCAT/'static-provider.obj'):item=str(OUT/(variant+'-provider.obj'))
   elif item==str(CONCAT/'static-tensor.obj'):item=str(OUT/(variant+'-tensor.obj'))
   elif item==str(CONCAT/'static-region.obj'):item=str(OUT/'region.obj')
   elif item==str(CONCAT/'static-region-tests.obj'):item=str(OUT/'consumer.obj')
   cmd.append(item)
  invoke(variant+'-link',cmd)
if args.action=='tests':
 for variant in ['baseline','candidate']:
  p=invoke(variant+'-tests',[str(OUT/(variant+'.exe')),'--gtest_filter=GgmlCudaHadamard.*:HadamardProbe.Graph*'],allow_fail=variant=='baseline')
  print(p.stdout.decode('utf-8',errors='replace'))
if args.action=='latency':
 for tag,variant in [('pair1-ab-baseline','baseline'),('pair1-ab-candidate','candidate'),('pair2-ba-candidate','candidate'),('pair2-ba-baseline','baseline')]:
  p=invoke(tag,[str(OUT/(variant+'.exe')),'--gtest_filter=HadamardProbe.DirectColdSpaceAndWarmLatency'])
  print(p.stdout.decode('utf-8',errors='replace'))
