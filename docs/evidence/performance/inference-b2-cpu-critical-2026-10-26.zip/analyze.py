"""Read one completed Windows Nsight SQLite. No product/process/network changes."""
from pathlib import Path
from collections import Counter, defaultdict
import argparse
import bisect
import json
import sqlite3

W = Path(__file__).resolve().parent
F = W / 'hyle/trace1'


def save(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n', encoding='utf8')


def union(items):
    out = []
    for lo, hi in sorted(items):
        if lo >= hi:
            continue
        if out and lo <= out[-1][1]:
            out[-1] = (out[-1][0], max(hi, out[-1][1]))
        else:
            out.append((lo, hi))
    return out


def clip(items, lo, hi):
    return union((max(a, lo), min(b, hi)) for a, b in items if a < hi and lo < b)


def intersect(a, b):
    return union((max(x, lo), min(y, hi)) for x, y in a for lo, hi in b
                 if x < hi and lo < y)


def size(items):
    return sum(b - a for a, b in items)


def rows(c, query, params=()):
    return [dict(x) for x in c.execute(query, params)]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--sqlite', type=Path, default=F / 'trace.sqlite')
    parser.add_argument('--prefix', default='raw-cpu')
    args = parser.parse_args()
    c = sqlite3.connect('file:' + args.sqlite.as_posix() + '?mode=ro', uri=True)
    c.row_factory = sqlite3.Row
    tables = {x[0] for x in c.execute("SELECT name FROM sqlite_master WHERE type='table'")}
    required = {
        'SCHED_EVENTS': {'start', 'cpu', 'isSchedIn', 'globalTid', 'threadState', 'threadBlock'},
        'COMPOSITE_EVENTS': {'id', 'start', 'cpu', 'threadState', 'globalTid', 'cpuCycles'},
        'SAMPLING_CALLCHAINS': {'id', 'symbol', 'module', 'kernelMode', 'unresolved',
                               'specialEntry', 'originalIP', 'unwindMethod', 'stackDepth'}}
    for table, columns in required.items():
        assert table in tables
        assert columns <= {x['name'] for x in rows(c, 'PRAGMA table_info(' + table + ')')}
    nvtx = rows(c, '''SELECT n.*,COALESCE(n.text,s.value) label FROM NVTX_EVENTS n
        LEFT JOIN StringIds s ON s.id=n.textId WHERE COALESCE(n.text,s.value) LIKE 'hyle/%'
        ORDER BY n.start''')
    roots = [x for x in nvtx if x['label'].startswith('hyle/b2_episode ')]
    assert len(roots) == 99 and len(nvtx) == 1782
    tid = roots[0]['globalTid']
    assert {x['globalTid'] for x in roots} == {tid}
    lo, hi = roots[0]['start'], roots[-1]['end']
    native = json.loads((F / 'native-process.json').read_text())
    assert ((tid >> 24) & 0xFFFFFF) == native['native_pid']
    source_physical = json.loads((F / 'physical-roots.json').read_text())
    assert [(x['start'], x['end'], x['uint64Value']) for x in roots] == [
        (x['start_ns'], x['end_ns'], x['meta']['seq']) for x in source_physical]
    metadata = {x['meta']['seq']: x['meta'] for x in source_physical}
    phase_labels = json.loads((W / 'analyze-plan.json').read_text())['original_phase_labels']
    for root in roots:
        children = [x for x in nvtx if x['uint64Value'] == root['uint64Value']
                    and x['label'] in phase_labels]
        assert Counter(x['label'] for x in children) == Counter(phase_labels)
        assert all(x['globalTid'] == tid and root['start'] <= x['start'] <= x['end'] <= root['end']
                   for x in children)
    sched = rows(c, 'SELECT rowid,* FROM SCHED_EVENTS WHERE globalTid=? ORDER BY start,rowid', (tid,))
    # Windows export includes out->out transitions. The first out ends the real
    # scheduled slice; later out events may change an off-CPU state, never add CPU.
    running, off, unknown = [], [], []
    reasons = defaultdict(list)
    bad_pairs = []
    pairs = []
    for first, second in zip(sched, sched[1:]):
        a, b = first['start'], second['start']
        if a >= hi or b <= lo:
            continue
        if first['isSchedIn'] and not second['isSchedIn'] and first['cpu'] == second['cpu']:
            running.append((a, b)); kind = 'running'
        elif not first['isSchedIn']:
            off.append((a, b)); kind = 'off_cpu'
            reasons[(first['threadState'], first['threadBlock'])].append((a, b))
        else:
            unknown.append((a, b)); kind = 'unknown'
            bad_pairs.append({'first': first, 'second': second})
        pairs.append(dict(start_ns=a, end_ns=b, kind=kind, first=first, second=second))
    running, off, unknown = union(running), union(off), union(unknown)
    samples = rows(c, '''SELECT * FROM COMPOSITE_EVENTS WHERE globalTid=? AND start>=?
        AND start<? ORDER BY start,id''', (tid, lo, hi))
    chain_rows = rows(c, '''SELECT s.*,sy.value symbol_name,mo.value module_name
        FROM COMPOSITE_EVENTS e JOIN SAMPLING_CALLCHAINS s ON s.id=e.id
        LEFT JOIN StringIds sy ON sy.id=s.symbol LEFT JOIN StringIds mo ON mo.id=s.module
        WHERE e.globalTid=? AND e.start>=? AND e.start<? ORDER BY s.id,s.stackDepth''', (tid, lo, hi))
    chains = defaultdict(list)
    for entry in chain_rows:
        chains[entry['id']].append(entry)
    api = []
    for table in ('CUPTI_ACTIVITY_KIND_RUNTIME', 'CUPTI_ACTIVITY_KIND_DRIVER'):
        if table in tables:
            api += rows(c, 'SELECT x.*,s.value api FROM ' + table +
                        ' x LEFT JOIN StringIds s ON s.id=x.nameId WHERE x.globalTid=? ORDER BY x.start', (tid,))
    gpu = []
    gpid = tid & ~0xFFFFFF
    for table in ('CUPTI_ACTIVITY_KIND_GRAPH_TRACE', 'CUPTI_ACTIVITY_KIND_KERNEL',
                  'CUPTI_ACTIVITY_KIND_MEMCPY', 'CUPTI_ACTIVITY_KIND_MEMSET'):
        if table in tables:
            gpu += [dict(table=table, **x) for x in rows(c,
                    'SELECT * FROM ' + table + ' WHERE globalPid=? AND start<? AND end>? ORDER BY start', (gpid, hi, lo))]
    api_union = union((x['start'], x['end']) for x in api)
    gpu_union = union((x['start'], x['end']) for x in gpu)
    running_starts = [x[0] for x in running]
    def sample_on_cpu(sample):
        i = bisect.bisect_right(running_starts, sample['start']) - 1
        return i >= 0 and running[i][0] <= sample['start'] < running[i][1]
    def ranked(counter, limit=25):
        return [dict(symbol=k[0], module=k[1], unresolved=k[2], observations=n)
                for k, n in sorted(counter.items(), key=lambda item: (-item[1], repr(item[0])))[:limit]]
    def sampled(selected):
        leaf, inclusive, modules = Counter(), Counter(), Counter()
        no_chain = unresolved = special = kernel = zero = 0
        for sample in selected:
            if sample['cpuCycles'] <= 0:
                zero += 1; continue
            chain = chains.get(sample['id'], [])
            if not chain:
                no_chain += 1; continue
            first = chain[0]
            assert first['stackDepth'] == 0
            leaf[(first['symbol_name'], first['module_name'], first['unresolved'])] += 1
            modules[first['module_name']] += 1
            unresolved += bool(first['unresolved']); special += bool(first['specialEntry'])
            kernel += bool(first['kernelMode'])
            for key in {(x['symbol_name'], x['module_name'], x['unresolved']) for x in chain}:
                inclusive[key] += 1
        positive = [x for x in selected if x['cpuCycles'] > 0]
        return dict(all_composite_events=len(selected), zero_weight_events=zero,
            positive_weight_samples=len(positive), raw_cpuCycles_sum=sum(x['cpuCycles'] for x in positive),
            positive_samples_outside_reconstructed_running=sum(not sample_on_cpu(x) for x in positive),
            positive_samples_no_chain=no_chain, unresolved_leaf_samples=unresolved,
            artificial_leaf_samples=special, kernel_leaf_samples=kernel,
            leaf_top=ranked(leaf), inclusive_unique_per_sample_top=ranked(inclusive),
            leaf_modules=[dict(module=k, observations=v) for k, v in modules.most_common()])
    def metric(a, b):
        run, offs, un = clip(running, a, b), clip(off, a, b), clip(unknown, a, b)
        gu, au = clip(gpu_union, a, b), clip(api_union, a, b)
        wall = b - a; covered = size(run) + size(offs) + size(un)
        assert covered <= wall
        return dict(wall_ns=wall, running_ns=size(run), off_cpu_ns=size(offs),
            unknown_ns=size(un) + wall - covered, observed_gpu_union_ns=size(gu),
            cuda_api_union_ns=size(au), running_inside_cuda_api_ns=size(intersect(run, au)),
            running_overlapping_gpu_ns=size(intersect(run, gu)),
            running_outside_gpu_and_cuda_api_ns=size(run)-size(intersect(run, union(gu+au))),
            off_cpu_reasons=[dict(threadState=k[0], threadBlock=k[1], ns=size(clip(v,a,b)))
                             for k,v in reasons.items() if size(clip(v,a,b))])
    per_root = []
    for root in roots:
        a, b = root['start'], root['end']
        inner = [x for x in nvtx if x['uint64Value'] == root['uint64Value'] and x['label'] in phase_labels]
        ra = [x for x in api if x['start'] < b and a < x['end']]
        record = any('StreamBeginCapture' in x['api'] for x in ra)
        phase = {}
        for x in [dict(root, label='ROOT')] + inner:
            selected = [s for s in samples if x['start'] <= s['start'] < x['end']]
            phase[x['label']] = dict(metric=metric(x['start'], x['end']), samples=sampled(selected))
        per_root.append(dict(meta=metadata[root['uint64Value']], record=record, phases=phase))
    def aggregate(selected):
        out = {}
        seqs = {x['meta']['seq'] for x in selected}
        for label in ['ROOT'] + phase_labels:
            group = [x['phases'][label]['metric'] for x in selected]
            totals = {k:sum(x[k] for x in group) for k in group[0] if k.endswith('_ns')} if group else {}
            ranges = [(x['start'],x['end']) for x in nvtx
                      if x['uint64Value'] in seqs and (x['label'] == label or label == 'ROOT' and x in roots)]
            selected_samples = [s for s in samples if any(a <= s['start'] < b for a,b in ranges)]
            out[label] = dict(count=len(group), metric=totals, samples=sampled(selected_samples))
        return out
    decode = [x for x in per_root if x['meta']['kind']=='decode']
    diagnostics = rows(c, 'SELECT * FROM DIAGNOSTIC_EVENT')
    loss = [x for x in diagnostics if any(w in x['text'].lower() for w in ('lost','dropped','overflow'))]
    state_enums = rows(c, 'SELECT * FROM ENUM_SAMPLING_THREAD_STATE')
    block_enums = rows(c, 'SELECT * FROM ENUM_SCHEDULING_THREAD_BLOCK')
    capture_meta = rows(c, 'SELECT * FROM META_DATA_CAPTURE')
    c.close()
    facts = dict(status='ONE_HYLE_WINDOWS_CPU_RUNNING_AND_SAMPLED_STACK_ATTRIBUTION',
        source_sqlite=str(args.sqlite), source_bytes=args.sqlite.stat().st_size,
        native_pid=native['native_pid'], root_globalTid=tid, globalPid=gpid,
        roots=99, decode_roots=len(decode), phase_labels=phase_labels,
        schema_version='3.24.18', metadata=capture_meta,
        quality=dict(native_and_complete_work='See hyle/trace1/consumer-quality.json and trace-quality.json',
            all1782_closed_NVTX_ranges_checked=True, source_physical_roots_exact=True,
            loss_or_overflow_diagnostics=loss, all_diagnostics=diagnostics,
            validated_running_slice_pairs=sum(x['kind']=='running' for x in pairs),
            invalid_running_pairs=bad_pairs,
            out_to_out_transitions=sum(not x['first']['isSchedIn'] and not x['second']['isSchedIn'] for x in pairs),
            windows_out_to_out_policy='OffCPU state transition, never counted as running; raw reason enums retained without claiming exact readyqueue latency',
            original_threadState_enums=state_enums, original_threadBlock_enums=block_enums),
        decode=aggregate(decode), prefill=aggregate([x for x in per_root if x['meta']['kind']=='prefill']),
        recording_decode=aggregate([x for x in decode if x['record']]),
        nonrecording_decode=aggregate([x for x in decode if not x['record']]),
        per_root=per_root,
        limits=['Scheduled-onCPU is not exclusive userCPU and includes driver polling/kernel/interrupt execution while scheduled.',
                'Running time overlapping observedGPU is not independently recoverable CPUoverhead.',
                'Positive cpuCycles samples are counted as observations; do not turn count/rate into exact CPUselftime. Zero-weight transition stacks are excluded from function share.',
                'Symbol unresolved flags, sample coverage and small counts remain explicit; inclusive frame counts overlap.',
                'One graph-level diagnostic, no peer arm or new throughput comparison. Old node-level timing differences are not optimization gains.',
                'No reported loss diagnostic is not a certificate of absence of ETW loss; raw ETL/profiler warnings remain retained.'])
    save(W / (args.prefix + '-facts.json'), facts)
    summary = dict(status=facts['status'], source_sqlite=str(args.sqlite),
        quality=facts['quality'], decode={}, nonrecording_decode={}, recording_decode={}, limits=facts['limits'])
    for category in ('decode','nonrecording_decode','recording_decode'):
        for label,value in facts[category].items():
            summary[category][label]=dict(count=value['count'],
                milliseconds={k[:-3]+'_ms':v/1e6 for k,v in value['metric'].items()},
                positive_samples=value['samples']['positive_weight_samples'],
                unresolved_leaf_samples=value['samples']['unresolved_leaf_samples'],
                positive_samples_outside_running=value['samples']['positive_samples_outside_reconstructed_running'],
                leaf_top=value['samples']['leaf_top'][:8],
                leaf_modules=value['samples']['leaf_modules'])
    save(W / (args.prefix + '-summary.json'), summary)
    print(json.dumps(dict(status=facts['status'], decode_root=summary['decode']['ROOT'],
                         invalid_running_pairs=len(bad_pairs), loss_diagnostics=loss), indent=2))


if __name__ == '__main__':
    main()
