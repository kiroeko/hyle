"""Independent small phase/API wall view from the retained native-only SQLite."""
from pathlib import Path
from collections import defaultdict
import json
import sqlite3

W=Path(__file__).resolve().parent
F=W/'hyle/trace1'
db=F/'native-scope-resolved.sqlite'
c=sqlite3.connect('file:'+db.as_posix()+'?mode=ro',uri=True)
c.row_factory=sqlite3.Row
events=[dict(x) for x in c.execute('''SELECT n.*,COALESCE(n.text,s.value) label
 FROM NVTX_EVENTS n LEFT JOIN StringIds s ON s.id=n.textId
 WHERE COALESCE(n.text,s.value) LIKE 'hyle/%' ORDER BY n.start''')]
api=[dict(x) for x in c.execute('''SELECT n.*,s.value api FROM CUPTI_ACTIVITY_KIND_RUNTIME n
 LEFT JOIN StringIds s ON s.id=n.nameId ORDER BY n.start''')]
roots=[x for x in events if x['label'].startswith('hyle/b2_episode ')]
tid=roots[0]['globalTid']
plan=json.loads((W/'analyze-plan.json').read_text())
siblings={
 'hyle/prepare':plan['twelve_sibling_buckets'][:6],
 'hyle/postwait_publish':plan['twelve_sibling_buckets'][6:]}
for root in roots:
 inner=[x for x in events if x['uint64Value']==root['uint64Value']]
 for parent,children in siblings.items():
  parent_row=next(x for x in inner if x['label']==parent)
  selected=sorted([x for x in inner if x['label'] in children],key=lambda x:x['start'])
  assert len(selected)==len(children)
  assert all(parent_row['start']<=x['start']<=x['end']<=parent_row['end'] for x in selected)
  assert all(a['end']<=b['start'] for a,b in zip(selected,selected[1:]))
out={}
for group in ('all_decode','nonrecording_decode','recording_decode'):
 chosen=[]
 for root in roots:
  if 'kind=decode' not in root['label']:continue
  record=any('StreamBeginCapture' in x['api'] and x['globalTid']==tid and root['start']<=x['start']<root['end'] for x in api)
  if group=='all_decode' or group=='recording_decode' and record or group=='nonrecording_decode' and not record:
   chosen.append(root)
 out[group]={'roots':len(chosen),'phases':{}}
 for label in plan['original_phase_labels']:
  costs=defaultdict(lambda:[0,0])
  for root in chosen:
   phase=next(x for x in events if x['uint64Value']==root['uint64Value'] and x['label']==label)
   for call in api:
    if call['globalTid']!=tid:continue
    duration=max(0,min(call['end'],phase['end'])-max(call['start'],phase['start']))
    if duration:
     costs[call['api']][0]+=1;costs[call['api']][1]+=duration
  out[group]['phases'][label]=[dict(api=k,overlapping_call_count=v[0],clipped_API_wall_sum_ns=v[1])
   for k,v in sorted(costs.items(),key=lambda x:(-x[1][1],x[0]))]
c.close()
facts=dict(status='ORIGINAL_SIBLING_BUCKETS_DISJOINT_AND_CUDA_API_WALL_COUNTS',source_sqlite=str(db),
 roots_checked=99,disjoint_prepare_and_postwait_children_each_root='PASS',groups=out,
 limits=['API wall spans can include active polling, GPU wait, driver work and profiler interception; never equal exclusive CPUselftime or recoverable overhead.',
         'These are runtime API rows; sums may overlap when nested. The main analyzer uses interval unions for its CPU/GPU/API metrics.',
         'Function symbols from sparse COFF public records have independently documented ambiguous extents: see symbol-attribution-limits.json.',
         'One Hyle graph-level run, not a new reference comparison or throughput gain.'])
(W/'cpu-call-costs.json').write_text(json.dumps(facts,indent=2)+'\n',encoding='utf8')
print('PASS 99roots siblingbucket disjointness and actualAPIwall counts')
