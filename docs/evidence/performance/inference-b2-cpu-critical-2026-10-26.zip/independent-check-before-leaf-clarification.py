"""Independent bounded read-only CPU evidence reconstruction. No imported reducer."""
from pathlib import Path
import hashlib
import json
import re
import sqlite3

W = Path(__file__).resolve().parent
F = W / 'hyle/trace1'


def connect(path):
    db = sqlite3.connect('file:' + path.as_posix() + '?mode=ro', uri=True)
    db.row_factory = sqlite3.Row
    return db


def merge(ranges):
    answer = []
    for start, end in sorted(ranges):
        if start >= end:
            continue
        if answer and answer[-1][1] >= start:
            answer[-1][1] = max(answer[-1][1], end)
        else:
            answer.append([start, end])
    return answer


def intersection_size(left, right):
    # Two-pointer intersection of two independently unioned sorted sets.
    i = j = total = 0
    while i < len(left) and j < len(right):
        total += max(0, min(left[i][1], right[j][1]) - max(left[i][0], right[j][0]))
        if left[i][1] < right[j][1]:
            i += 1
        else:
            j += 1
    return total


def size(ranges):
    return sum(end - start for start, end in ranges)


def row_digest(cursor):
    h = hashlib.sha256()
    count = 0
    for row in cursor:
        h.update((json.dumps(list(row), separators=(',', ':')) + '\n').encode())
        count += 1
    return {'rows': count, 'sha256': h.hexdigest()}


def pin(path):
    raw = path.read_bytes()
    return {'path': str(path), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def main():
    raw = connect(F / 'trace.sqlite')
    db = connect(F / 'trace-local-resolved.sqlite')
    rows = [dict(x) for x in db.execute('''SELECT start,end,globalTid,uint64Value,
        COALESCE(n.text,s.value) label FROM NVTX_EVENTS n LEFT JOIN StringIds s
        ON s.id=n.textId WHERE COALESCE(n.text,s.value) LIKE 'hyle/%' ORDER BY start''')]
    roots = [x for x in rows if x['label'].startswith('hyle/b2_episode ')]
    decode = [x for x in roots if ' kind=decode ' in x['label']]
    assert len(roots) == 99 and len(decode) == 96 and len(rows) == 1782
    assert all(x['end'] is not None and x['end'] > x['start'] for x in rows)
    tid = roots[0]['globalTid']
    assert {x['globalTid'] for x in rows} == {tid}
    pid = (tid >> 24) & 0xFFFFFF
    gpid = tid & ~0xFFFFFF
    native = json.loads((F / 'native-process.json').read_text())
    assert pid == native['native_pid'] == 62400
    lo, hi = roots[0]['start'], roots[-1]['end']
    seqs = {x['uint64Value'] for x in decode}
    phase_counts = {}
    for root in roots:
        inside = [x for x in rows if x['uint64Value'] == root['uint64Value']]
        assert len(inside) == 18
        assert all(root['start'] <= x['start'] < x['end'] <= root['end'] for x in inside)
        labels = [x['label'] for x in inside if x is not root]
        assert len(labels) == len(set(labels)) == 17
        phase_counts[root['uint64Value']] = len(inside)
    # Reconstruct running from actual in/out transitions, not enum time or samples.
    sched = [dict(x) for x in db.execute('SELECT rowid,* FROM SCHED_EVENTS WHERE globalTid=? ORDER BY start,rowid', (tid,))]
    opened = None
    running = []
    invalid = []
    extra_out = 0
    for event in sched:
        if event['isSchedIn']:
            if opened and event['start'] > lo and opened['start'] < hi:
                invalid.append([opened, event])
            opened = event
        elif opened:
            if opened['cpu'] != event['cpu'] and event['start'] > lo and opened['start'] < hi:
                invalid.append([opened, event])
            running.append([opened['start'], event['start']])
            opened = None
        else:
            extra_out += 1
    assert not invalid
    running = merge(running)
    tables = {x[0] for x in db.execute("SELECT name FROM sqlite_master WHERE type='table'")}
    gpu = []
    for table in ('CUPTI_ACTIVITY_KIND_GRAPH_TRACE', 'CUPTI_ACTIVITY_KIND_KERNEL', 'CUPTI_ACTIVITY_KIND_MEMCPY', 'CUPTI_ACTIVITY_KIND_MEMSET'):
        if table in tables:
            gpu += [list(x) for x in db.execute('SELECT start,end FROM '+table+' WHERE globalPid=?', (gpid,))]
    gpu = merge(gpu)
    apis = []
    api_names = []
    for table in ('CUPTI_ACTIVITY_KIND_RUNTIME', 'CUPTI_ACTIVITY_KIND_DRIVER'):
        if table in tables:
            selected = [dict(x) for x in db.execute('SELECT a.start,a.end,s.value name FROM '+table+' a LEFT JOIN StringIds s ON s.id=a.nameId WHERE a.globalTid=?', (tid,))]
            apis += [[x['start'], x['end']] for x in selected]
            api_names += selected
    apis = merge(apis)
    nonrecord = [r for r in decode if not any('StreamBeginCapture' in x['name'] and x['start'] < r['end'] and x['end'] > r['start'] for x in api_names)]
    assert len(nonrecord) == 90
    nonrecord_seqs = {r['uint64Value'] for r in nonrecord}
    decode_ranges = merge([[r['start'], r['end']] for r in decode])
    waits = merge([[r['start'], r['end']] for r in rows if r['label'] == 'hyle/completion_wait' and r['uint64Value'] in seqs])
    replay = merge([[r['start'], r['end']] for r in rows if r['label'] == 'hyle/prepare_replay' and r['uint64Value'] in nonrecord_seqs])
    nonrecord_ranges = merge([[r['start'], r['end']] for r in nonrecord])
    measured = {'decode_roots': len(decode), 'decode_wall_ns': size(decode_ranges),
        'decode_running_ns': intersection_size(decode_ranges, running),
        'decode_off_cpu_ns': size(decode_ranges) - intersection_size(decode_ranges, running),
        'wait_wall_ns': size(waits), 'wait_gpu_union_overlap_ns': intersection_size(waits, gpu),
        'wait_cuda_api_union_overlap_ns': intersection_size(waits, apis),
        'nonrecord_roots': len(nonrecord), 'nonrecord_root_wall_ns': size(nonrecord_ranges),
        'nonrecord_replay_wall_ns': size(replay)}
    measured['decode_off_cpu_percent'] = 100 * measured['decode_off_cpu_ns'] / measured['decode_wall_ns']
    measured['nonrecord_replay_whole_root_percent'] = 100 * size(replay) / size(nonrecord_ranges)
    assert measured['decode_wall_ns'] == 1346646315
    assert measured['decode_running_ns'] == 1340863315
    assert measured['decode_off_cpu_ns'] == 5783000
    assert measured['wait_wall_ns'] == 1144969804
    assert measured['wait_gpu_union_overlap_ns'] == 1135763108
    assert measured['wait_cuda_api_union_overlap_ns'] == 1141377989
    assert measured['nonrecord_replay_wall_ns'] == 26015711
    samples = [dict(x) for x in db.execute('SELECT * FROM COMPOSITE_EVENTS WHERE globalTid=? AND start>=? AND start<? AND cpuCycles>0 ORDER BY start,id', (tid,lo,hi))]
    replay_samples = [x for x in samples if any(a <= x['start'] < b for a,b in replay)]
    assert len(replay_samples) == 29
    replay_chain_counts = {}
    sample_ids = [x['id'] for x in replay_samples]
    sql = '''SELECT c.id,c.stackDepth,s.value FROM SAMPLING_CALLCHAINS c JOIN StringIds s
        ON s.id=c.symbol WHERE c.id IN (''' + ','.join('?' for _ in sample_ids) + ')'
    position_samples = set()
    matched_symbols = set()
    for sample_id, depth, symbol in db.execute(sql, sample_ids):
        if 'SmallVector' in symbol and 'position_index' in symbol:
            position_samples.add(sample_id)
            matched_symbols.add(symbol)
    assert len(position_samples) == 9
    measured['nonrecord_replay_positive_samples'] = len(replay_samples)
    measured['nonrecord_replay_SmallVector_position_index_inclusive_samples'] = len(position_samples)
    # Verify symbol resolution did not change underlying samples/schedules/stack IPs.
    preservation = {}
    native_queries = {
        'native_composite_events': ('SELECT id,start,cpu,threadState,globalTid,cpuCycles FROM COMPOSITE_EVENTS WHERE globalTid=? ORDER BY id,start', (tid,)),
        'native_scheduler_events': ('SELECT start,cpu,isSchedIn,globalTid,threadState,threadBlock FROM SCHED_EVENTS WHERE globalTid=? ORDER BY start,rowid', (tid,)),
        'native_stack_identity': ('''SELECT c.id,c.kernelMode,c.thumbCode,c.specialEntry,c.originalIP,c.unwindMethod,c.stackDepth
            FROM SAMPLING_CALLCHAINS c JOIN COMPOSITE_EVENTS e ON e.id=c.id WHERE e.globalTid=? ORDER BY c.id,c.stackDepth''', (tid,))}
    for name, (query, params) in native_queries.items():
        before = row_digest(raw.execute(query, params))
        after = row_digest(db.execute(query, params))
        assert before == after, name
        preservation[name] = before
    global_counts = {}
    for name in ('COMPOSITE_EVENTS', 'SAMPLING_CALLCHAINS', 'SCHED_EVENTS', 'NVTX_EVENTS'):
        before = raw.execute('SELECT COUNT(*) FROM '+name).fetchone()[0]
        after = db.execute('SELECT COUNT(*) FROM '+name).fetchone()[0]
        assert before == after
        global_counts[name] = before
    diagnostics = [dict(x) for x in db.execute('SELECT * FROM DIAGNOSTIC_EVENT')]
    warnings = [x for x in diagnostics if x['severity'] >= 2]
    loss_terms = [x for x in diagnostics if re.search(r'\b(lost|dropped|overflow)\b', x['text'], re.I)]
    review = {'status': 'INDEPENDENT_KEY_CPU_CLAIMS_RECONSTRUCTED_AND_MATCHED',
        'scope': 'Own read-only SQLite queries/state-machine and interval sweeps; no import of analyze.py and no new consumer/profile/network/build.',
        'identity': {'native_pid': pid, 'native_thread_id': tid & 0xFFFFFF, 'globalTid': tid, 'globalPid': gpid},
        'range_gate': {'roots': len(roots), 'decode_roots': len(decode), 'closed_hyle_ranges': len(rows), 'ranges_per_root': 18, 'distinct_child_labels_per_root': 17},
        'measurements': measured, 'raw_resolved_global_row_counts_equal': global_counts,
        'native_raw_resolved_structure_digests_equal': preservation,
        'positive_replay_samples': {'all': len(replay_samples), 'position_index_inclusive_unique': len(position_samples), 'symbols': sorted(matched_symbols), 'meaning': 'Observations, not CPU milliseconds. Inclusive frames can overlap; 9/29 small samples do not estimate 9 ms or a stable cost fraction.'},
        'warnings': warnings, 'explicit_loss_word_diagnostics': loss_terms,
        'interpretation': ['Running is Windows scheduled-onCPU, including driver polling, kernel and interrupt time; it is not exclusive Hyle application CPU cost.',
            'Completion wait, CUDA API and GPU graph intervals overlap. Their measured times must not be added or treated as independently removable host overhead.',
            '5.783ms offCPU among96decode roots rejects scheduler descheduling as a large observed cause in this capture. It does not prove no scheduling problem in all runs.',
            'Steady replay whole bucket is26.016ms/1223.209ms=2.13%. Even deleting it cannot explain the full current gap; SmallVector observations are not evidence of a large recoverable bottleneck.',
            'The single-slot architecture limit is real for this Model consumer, but measured direct-cause attribution is unsupported because matched peer632 also explicitly synchronizes and publishes each episode before the next. See single-slot-review.json.',
            'Driver13.4/collector13.3 mismatch and legacy CUDA software instrumentation are retained limitations. Python wrapper warnings name its process, while native62400 has1782closed ranges and actual CUDA events. No explicit lost/dropped/overflow diagnostic is a limited negative observation, not proof of zero ETW loss.',
            'One Hyle-only diagnostic; no new peer arm or throughput result. Symbol resolution changes names only; native scheduler/sample structure and row counts are independently verified unchanged.'],
        'source_files': [pin(Path(__file__)), pin(W/'resolved-cpu-summary.json'), pin(W/'single-slot-review.json')],
        'unverified': ['Whole goal or all functional/platform coverage', 'Exact source-line exclusive times', 'Fresh llama.cpp performance or causal speedup', 'Absence of unreported ETW/profiler loss']}
    (W / 'independent-review.json').write_text(json.dumps(review, ensure_ascii=False, indent=2)+'\n', encoding='utf8')
    print(json.dumps({'review': pin(W/'independent-review.json'), 'measurements': measured, 'preservation': preservation, 'counts': global_counts}, indent=2))


if __name__ == '__main__':
    main()
