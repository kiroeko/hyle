"""Publish one CPU diagnostic using verified native-only raw datasets."""
from pathlib import Path
import hashlib
import json
import subprocess
import zipfile

W = Path(__file__).resolve().parent
R = W.parents[1]
F = W/'hyle/trace1'
DEST = R/'docs/evidence/performance'
NAME = 'inference-b2-cpu-critical-2026-10-26'

def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))
def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream,'sha256').hexdigest()

work, trace = read(F/'consumer-quality.json'), read(F/'trace-quality.json')
facts = read(W/'resolved-cpu-summary.json')
review = read(W/'independent-review.json')
reproduction = read(W/'native-filter-reproduction.json')
assert work['status'] == 'PASS_COMPLETE_ORIGINAL_REPORT_AND_198_IDS'
assert review['status'] == 'INDEPENDENT_KEY_CPU_CLAIMS_RECONSTRUCTED_AND_MATCHED'
assert reproduction['status'] == 'FILTERED_NATIVE_DATASETS_EXACTLY_REPRODUCE_ALL_ANALYSIS'
assert read(F/'process.json')['exit'] == read(F/'native-process.json')['exit'] == 0
assert not read(F/'process.json')['timeout'] and not read(F/'native-process.json')['timeout']
datasets = {'hyle/trace1/native-scope-raw.sqlite','hyle/trace1/native-scope-resolved.sqlite'}
assert datasets <= set(reproduction['archive_inputs'])
suffixes = {'.json','.log','.py','.cc','.h','.patch'}
files = []
for path in W.rglob('*'):
    if not path.is_file():
        continue
    name = path.relative_to(W).as_posix()
    if name.startswith('local-symbols/process-list/') or '__pycache__' in path.parts:
        continue
    if path.name in {'archive-receipt.json','archive-manifest.json'}:
        continue
    if path.suffix.lower() not in suffixes and name not in datasets:
        continue
    files.append((name,path))
assert all(not name.endswith(('.pdb','.obj','.exe','.dll','.lib','.exp','.map','.nsys-rep','.etl')) for name,_ in files)
assert {name for name,_ in files if name.endswith('.sqlite')} == datasets
archive_path, report_path = DEST/(NAME+'.zip'), DEST/(NAME+'.json')
if archive_path.exists() or report_path.exists():
    assert archive_path.exists() and report_path.exists()
    assert sha(archive_path) == '43e5c0dfb7b2afe303021c4ab12363068df6bbfc4524b26a1fb66aad2797ad2e'
    (W/'first-publication-before-final-quality.json').write_bytes(report_path.read_bytes())
manifest = [dict(member=name,bytes=path.stat().st_size,sha256=sha(path)) for name,path in sorted(files)]
with zipfile.ZipFile(archive_path,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as archive:
    for name,path in sorted(files):
        archive.write(path,name)
    archive.writestr('archive-manifest.json',json.dumps(manifest,indent=2)+'\n')
with zipfile.ZipFile(archive_path) as archive:
    assert archive.testzip() is None and len(archive.namelist()) == len(manifest)+1
    for row in manifest:
        raw = archive.read(row['member'])
        assert len(raw) == row['bytes'] and hashlib.sha256(raw).hexdigest() == row['sha256']
phase_summary = {group:{label:{key:value for key,value in phase.items()
    if key in {'count','milliseconds','positive_samples','unresolved_leaf_samples'}}
    for label,phase in facts[group].items()}
    for group in ('decode','nonrecording_decode','recording_decode')}
report = dict(schema='hyle.performance.evidence.v1',date='2026-10-26',
    status='FULL_WORK_AND_BOUNDED_SCHEDULING_CHECKS_PASS_PARTIAL_SYMBOL_ATTRIBUTION',
    source_git_before_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),
    activity=dict(profiles=1,native_model_processes=1,private_Model_TUs=1,
        Graph_or_SDK_or_device_builds=0,extra_model_runs=0,throughput_measurement=False,
        sampling='1000Hz CPU IP/backtrace + process-tree context switches; graph-level CUDA/NVTX',
        streams='Native stdout/stderr independently captured; no Nsight ProcessStreams extraction'),
    identity=read(W/'ready.json'), work=work, trace_quality=trace,
    phase_summary=phase_summary,
    findings=[
        'All96 decode roots:1346.646315ms wall,1340.863315ms reconstructed scheduled-onCPU,5.783ms offCPU(0.4294%). Six sample CPU-ID discrepancies affect observed slices overlapping2.7062ms decode; excluding those slices leaves1338.157115ms inferred running. This is finite sensitivity, not a universal ETW error bound. OS descheduling is not supported as the dominant cost.',
        'Completion wait:1144.969804ms wall,1135.763108ms overlaps observed GPU graph intervals and1141.377989ms CUDA APIs. These are overlapping intervals, not additive or recoverable CPU overhead.',
        'The90 nonrecording replay-preparation scopes total26.015711ms,2.12684% of their1223.208763ms root wall. This bounds the whole bucket, not a removable or exclusive function cost.',
        'Driver-module leaves dominate decode samples; most leaf frames remain unresolved. Public-symbol names can cover gaps outside their real PE function boundaries, so SmallVector position_index sample labels do not establish an expensive container loop.',
        'The Qwen consumer has one Invocation per shape Phase and one active Model episode, with realR2 batching. The exact peer consumer also serializes decode/synchronize/sample/publication before the next episode; a one-slot difference is not established as the cause.'
    ],
    symbol_coverage=read(W/'local-symbols/counts.json'),
    sample_schedule_quality=read(W/'sample-schedule-cpu-check.json'),
    cuda_api_costs=read(W/'cpu-call-costs.json'),
    symbol_name_limit=read(W/'symbol-attribution-limits.json'),
    single_slot_review=read(W/'single-slot-review.json'),
    independent_review=review, native_filter_reproduction=reproduction,
    quality_limits=[
        'One Hyle graph-level diagnostic only; no peer profile or new tokens/s table. Never subtract old node-level timings as an optimization gain.',
        'Scheduled-onCPU is not exclusive user CPU; it includes driver polling, kernel and interrupts while scheduled. Running overlapping GPU work is not independently recoverable.',
        'CPU sample observations are statistical locations, not exact self milliseconds. Unresolved/nearest-public/ICF and sparse-public ambiguities remain explicit.',
        'No CPU loss/overflow diagnostic was found; this is not a certificate of zero ETW loss. All reconstructed root boundaries passed the finite scheduling checks.',
        'Six positive samples disagree with the reconstructed scheduled CPU ID. The percentage is a reconstruction estimate, not certified precise CPU time; the entire affected observed slices and sensitivity are retained.',
        'Nsight warned about driver13.4 with CUPTI13.3 and used software tracing. Wrapper has no NVTX/CUDA; its corresponding warnings do not invalidate independently checked native1782ranges.',
        'Native-only filtered datasets preserve queried raw relationships and exactly reproduce analysis. Full unrelated system samples are omitted.'
    ],
    archive=dict(path=archive_path.name,bytes=archive_path.stat().st_size,sha256=sha(archive_path),
        members=len(manifest)+1,verification='ZIP CRC and every member length/SHA256 checked',
        raw_scope='Only two valid native-scope SQLite datasets; original whole-system databases/ETL/reports and superseded partial datasets are excluded'))
report_path.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
(W/'archive-receipt.json').write_text(json.dumps(report['archive'],indent=2)+'\n',encoding='utf8')
print(json.dumps(dict(report=str(report_path),archive=report['archive']),indent=2))
