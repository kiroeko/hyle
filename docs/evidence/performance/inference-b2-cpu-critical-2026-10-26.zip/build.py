"""Explicit optimized/symbolized diagnostic build; preparation does not run tools.

Only the previously reviewed 12-phase Model TU is rebuilt. Existing product,
Graph, native/device, and SDK inputs remain byte-identical to baseline f36.
"""
from pathlib import Path
import hashlib
import importlib.util
import json
import os
import re
import sys

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = W.parents[1]
OLD = R / '.scratch/inference-b2-host-phases-20261026'
BASE = R / '.scratch/inference-result-publication-screen-20261026/candidate'


def read(p):
    return json.loads(Path(p).read_text(encoding='utf-8-sig'))


def save(p, x):
    p = Path(p)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_bytes((json.dumps(x, indent=2, ensure_ascii=False) + '\n').encode('utf8'))


def pin(p):
    p = Path(p)
    data = p.read_bytes()
    return dict(path=str(p), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())


def exact(p):
    assert pin(p['path']) == p, p['path']


def key(p):
    return str(p).replace('/', '\\').casefold()


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def logical(path, pins):
    if key(path) in (key(pins['old_source']['path']), key(pins['source']['path'])):
        return 'PRIVATE_MODEL_SOURCE'
    if key(path) in (key(pins['old_helper']['path']), key(pins['helper']['path'])):
        return 'PRIVATE_NVTX_HELPER'
    return key(path)


def prepare():
    assert not (W / 'build-plan.json').exists(), 'Do not replace the frozen plan'
    oldpins = read(OLD / 'source-pins.json')
    oldready = read(OLD / 'ready.json')
    baseline = read(BASE / 'ready.json')
    source = W / 'source/engine/models/qwen35/main.cc'
    helper = W / 'logical_trace.h'
    assert not source.exists() and not helper.exists(), 'Preserve original snapshots'
    for x in (oldpins['after'], oldpins['helper'], oldpins['canonical_model'],
              oldpins['patch'], baseline['image'], baseline['link_inputs'], baseline['runtime']):
        exact(x)
    assert oldpins['after']['sha256'] == 'ebc9b9bd7bd0b315cec0c8f99c769643f1b17c1425a9b7170cd2000a6428af87'
    assert oldpins['helper']['sha256'] == '85fdaa4efa4f00e49ad193f6a713355007666c101783112a1974840ea6c8521d'
    deps = read(oldready['actual_dependencies']['path'])
    exact(oldready['actual_dependencies'])
    for row in deps:
        exact(row)
    inputs = read(baseline['link_inputs']['path'])
    for row in inputs:
        exact(row)
    source.parent.mkdir(parents=True)
    source.write_bytes(Path(oldpins['after']['path']).read_bytes())
    helper.write_bytes(Path(oldpins['helper']['path']).read_bytes())
    ownership = []
    for row in deps:
        path = Path(row['path'])
        if key(path) in (key(oldpins['after']['path']), key(oldpins['helper']['path'])):
            owner = 'private_instrumentation_snapshot'
        elif path.is_relative_to(R) and not path.is_relative_to(R / '.scratch'):
            owner = 'canonical_product_source_or_header'
        elif path.is_relative_to(R / '.scratch'):
            owner = 'retained_dependency_or_historical_build_include'
        else:
            owner = 'installed_toolchain_or_shared_dependency'
        ownership.append(dict(**row, ownership=owner))
    save(W / 'dependency-ownership.json', ownership)
    pins = dict(source=pin(source), helper=pin(helper), old_source=oldpins['after'],
        old_helper=oldpins['helper'], canonical_model=oldpins['canonical_model'],
        old_source_pins=pin(OLD / 'source-pins.json'), old_instrumentation_patch=oldpins['patch'],
        old_source_review=pin(OLD / 'independent-review-architecture.json'),
        old_actual_dependencies=oldready['actual_dependencies'],
        dependency_ownership=pin(W / 'dependency-ownership.json'),
        byte_identical_to_reviewed_12phase_source=True, model_math_or_endpoint_changes=False)
    save(W / 'source-pins.json', pins)
    oldplan = read(OLD / 'build-plan.json')
    compile_argv = []
    for arg in oldplan['compile']:
        if arg == oldpins['after']['path']:
            arg = str(source)
        elif arg == '/I' + str(OLD):
            arg = '/I' + str(W)
        elif arg == str(OLD / 'compile/dependencies.json'):
            arg = str(W / 'compile/dependencies.json')
        elif arg.startswith('/Fo'):
            arg = '/Fo' + str(W / 'compile/unit.obj')
        elif arg.startswith('/Fd'):
            # /Z7 embeds CodeView in the object; there is no shared compiler PDB.
            continue
        compile_argv.append(arg)
    assert '/O2' in compile_argv and '/Ob2' in compile_argv
    assert not any(x.lower() in ('/zi', '/z7', '/gl', '/od', '/ob0') for x in compile_argv)
    compile_argv.append('/Z7')
    replaced = oldplan['replaced']
    assert sum(key(x['path']) == key(replaced['path']) for x in inputs) == 1
    link_argv = []
    for arg in read(BASE / 'link/command.json')['command']:
        if key(arg) == key(replaced['path']):
            arg = str(W / 'compile/unit.obj')
        elif arg.upper().startswith('/OUT:'):
            arg = '/OUT:' + str(W / 'link/consumer.exe')
        elif arg.upper().startswith('/PDB:'):
            arg = '/PDB:' + str(W / 'link/consumer.pdb')
        elif arg.upper().startswith('/IMPLIB:'):
            arg = '/IMPLIB:' + str(W / 'link/consumer.lib')
        link_argv.append(arg)
    assert not any(x.upper().startswith(('/DEBUG', '/MAP:')) for x in link_argv)
    link_argv += ['/DEBUG:FULL', '/MAP:' + str(W / 'link/consumer.map')]
    for flag in ('/INCREMENTAL:NO', '/OPT:REF', '/OPT:ICF'):
        assert flag in link_argv
    assert link_argv.count(str(W / 'compile/unit.obj')) == 1
    save(W / 'build-plan.json', dict(compile=compile_argv, link=link_argv,
        source_pins=pin(W / 'source-pins.json'), baseline_ready=pin(BASE / 'ready.json'),
        baseline_link_inputs=baseline['link_inputs'], baseline_runtime=baseline['runtime'],
        replaced=replaced, retained_inputs=len(inputs) - 1,
        new_host_TUs=1, SDK_Graph_native_device_builds=0,
        debug_scope='Only Model TU /Z7. Optimized /O2 /Ob2 retained. Link /DEBUG:FULL /OPT:REF /OPT:ICF /INCREMENTAL:NO. Other objects supply existing public COFF symbols only.',
        limitations=['Not a benchmark image; instrumentation/debug-info/link layout may perturb timing.',
            'Other retained TUs may lack private symbols/source lines/inlined-frame information.',
            'ICF/inlining may merge or eliminate functions; an attributed public frame is not proof of exclusive source cost.',
            'No SDK/native/device/Graph rebuild and no promise of complete CPU or CUDA stack symbolization.']))
    print('CPU_CRITICAL_BUILD_PLAN', json.dumps(pin(W / 'build-plan.json')), flush=True)


def build():
    assert not (W / 'compile').exists() and not (W / 'link').exists(), 'Preserve every attempted build'
    plan = read(W / 'build-plan.json')
    for field in ('source_pins', 'baseline_ready', 'baseline_link_inputs', 'baseline_runtime'):
        exact(plan[field])
    pins = read(plan['source_pins']['path'])
    for field in ('source', 'helper', 'old_source', 'old_helper', 'canonical_model',
                  'old_source_pins', 'old_instrumentation_patch', 'old_source_review',
                  'old_actual_dependencies', 'dependency_ownership'):
        exact(pins[field])
    before_deps = read(pins['old_actual_dependencies']['path'])
    for row in before_deps:
        exact(row)
    inputs = read(plan['baseline_link_inputs']['path'])
    for row in inputs:
        exact(row)
    h = load('retained_execute', R / '.scratch/inference-synchronous-step-report-20261025/check_host.py')
    compiler = plan['compile'][0]
    env = h.discover_environment(compiler='msvc', cache={'CMAKE_C_COMPILER': compiler,
        'CMAKE_CXX_COMPILER': compiler, 'CMAKE_GENERATOR': 'Ninja'}, backends=()).env
    compiled = h.execute(plan['compile'], env, W / 'compile', timeout=120)
    dep = read(W / 'compile/dependencies.json')['Data']
    actual = [pin(x) for x in dict.fromkeys([dep['Source'], *dep['Includes']])]
    old = {logical(x['path'], pins): x for x in before_deps}
    new = {logical(x['path'], pins): x for x in actual}
    assert set(old) == set(new), (set(old) - set(new), set(new) - set(old))
    changed = [k for k in old if (old[k]['bytes'], old[k]['sha256']) != (new[k]['bytes'], new[k]['sha256'])]
    assert not changed, changed
    save(W / 'compile/actual-dependencies.json', actual)
    save(W / 'compile/dependency-contract.json', dict(original=len(old), actual=len(new),
        same_logical_dependency_set=True, byte_drift=changed, private_source_helper_identical=True,
        ownership= pins['dependency_ownership']))
    obj = pin(W / 'compile/unit.obj')
    new_inputs = [obj if key(x['path']) == key(plan['replaced']['path']) else x for x in inputs]
    save(W / 'link-inputs.json', new_inputs)
    linked = h.execute(plan['link'], env, W / 'link', timeout=120)
    for row in new_inputs:
        exact(row)
    runtime = read(plan['baseline_runtime']['path'])
    exact(runtime['native'])
    alias = W / 'link' / Path(runtime['native']['path']).name
    os.link(runtime['native']['path'], alias)
    runtime['native_hardlink'] = pin(alias)
    save(W / 'runtime.json', runtime)
    # Offline binary metadata inspection only: does not load/run the consumer.
    inspected = h.execute([str(Path(compiler).with_name('dumpbin.exe')), '/HEADERS',
        str(W / 'link/consumer.exe')], env, W / 'symbol-headers', timeout=30)
    headers = (W / 'symbol-headers/stdout.log').read_text(errors='replace')
    assert 'RSDS' in headers and 'consumer.pdb' in headers, 'Image must name its local matching PDB'
    pdb = W / 'link/consumer.pdb'
    assert pdb.read_bytes().startswith(b'Microsoft C/C++ MSF 7.00')
    maptext = (W / 'link/consumer.map').read_text(errors='replace')
    function_rows = [line for line in maptext.splitlines() if re.match(
        r'^\s+[0-9A-Fa-f]{4}:[0-9A-Fa-f]{8,16}\s+\S+\s+[0-9A-Fa-f]{8,16}\s+f\b', line)]
    model_rows = [x for x in function_rows if 'Model@qwen35' in x]
    assert len(function_rows) > 100 and model_rows, (len(function_rows), len(model_rows))
    selected = {name: [x for x in function_rows if name in x][:5]
        for name in ('Model@qwen35', 'PagedArena', 'ResourceEpisode', 'prepare_replay', 'ggml_cuda')}
    save(W / 'symbol-contract.json', dict(status='LOCAL_PDB_AND_MAP_PRESENT_PUBLIC_NAMES_VERIFIED',
        inspection=inspected, headers=pin(W / 'symbol-headers/stdout.log'),
        pdb=pin(pdb), map=pin(W / 'link/consumer.map'),
        function_rows=len(function_rows), model_function_rows=len(model_rows), samples=selected,
        limits=plan['limitations'], actual_runtime_stack_resolution='NOT_RUN'))
    save(W / 'ready.json', dict(status='CPU_CRITICAL_BUILT_NOT_PROFILED',
        image=pin(W / 'link/consumer.exe'), app=obj, source=pins['source'], helper=pins['helper'],
        source_pins=plan['source_pins'], actual_dependencies=pin(W / 'compile/actual-dependencies.json'),
        runtime=pin(W / 'runtime.json'), link_inputs=pin(W / 'link-inputs.json'),
        pdb=pin(pdb), map=pin(W / 'link/consumer.map'), symbol_contract=pin(W / 'symbol-contract.json'),
        compile=compiled, link=linked, baseline_ready=plan['baseline_ready'],
        replaced=plan['replaced'], unchanged_inputs=len(new_inputs)-1,
        new_host_TUs=1, SDK_Graph_native_device_builds=0, model_runs=0,
        limitations=plan['limitations']))
    print('CPU_CRITICAL_READY', json.dumps(pin(W / 'ready.json')), flush=True)


if __name__ == '__main__':
    if sys.argv[1:] == ['prepare']:
        prepare()
    elif sys.argv[1:] == ['build']:
        build()
    else:
        raise SystemExit('Usage: python -B ' + str(__file__) + ' prepare | build')
