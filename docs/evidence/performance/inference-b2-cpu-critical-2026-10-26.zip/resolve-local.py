"""Offline local PDB-only resolution/export of the one retained CPU profile."""
from pathlib import Path
import hashlib
import json
import os
import sqlite3
import subprocess
import sys
import time

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
F = W/'hyle/trace1'
D = W/'local-symbols'
TOOL = Path('C:/Program Files/NVIDIA Corporation/Nsight Systems 2026.1.3/host-windows-x64/ResolveSymbols.exe')
NSYS = Path('C:/Program Files/NVIDIA Corporation/Nsight Systems 2026.1.3/target-windows-x64/nsys.exe')


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def save(path, value):
    Path(path).write_text(json.dumps(value, indent=2, ensure_ascii=False)+'\n',encoding='utf8')


def pin(path):
    path = Path(path)
    with path.open('rb') as source:
        digest = hashlib.file_digest(source, 'sha256').hexdigest()
    return dict(path=str(path), bytes=path.stat().st_size, sha256=digest)


def execute(name, command, env, timeout=90):
    folder=D/name
    folder.mkdir(exist_ok=False)
    save(folder/'command.json',dict(command=command,cwd=str(W),timeout_seconds=timeout,
         native_runs=0,profile_runs=0,servers=[],environment=dict(_NT_SYMBOL_PATH='',_NT_ALT_SYMBOL_PATH='',DEBUGINFOD_URLS='',NSYS_CONFIG_DIRECTIVES='removed')))
    started=time.perf_counter()
    with (folder/'stdout.log').open('xb') as out,(folder/'stderr.log').open('xb') as err:
        process=subprocess.Popen(command,cwd=W,env=env,stdout=out,stderr=err,creationflags=subprocess.CREATE_NO_WINDOW)
        save(folder/'live.json',dict(pid=process.pid,started_unix_ns=time.time_ns()))
        print('OFFLINE_SYMBOL_TOOL_STARTED',name,process.pid,flush=True)
        timed_out=False
        try:
            code=process.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            timed_out=True
            process.kill()
            process.wait(timeout=10)
            code=process.returncode
    result=dict(exit=code,pid=process.pid,timeout=timed_out,seconds=time.perf_counter()-started)
    save(folder/'process.json',result)
    print('OFFLINE_SYMBOL_TOOL_ENDED',name,code,'timeout',timed_out,flush=True)
    assert code==0 and not timed_out,'Offline failure retained; no native/profile retry'
    return result


def main():
    assert sys.argv[1:]==['run']
    assert read(F/'consumer-quality.json')['status']=='PASS_COMPLETE_ORIGINAL_REPORT_AND_198_IDS'
    assert not D.exists(), 'Preserve every original offline attempt'
    D.mkdir()
    ready=read(W/'ready.json')
    for key in ('pdb','map','image'):
        assert pin(ready[key]['path'])==ready[key]
    raw_pins=[pin(F/'trace.nsys-rep'),pin(F/'trace.sqlite')]
    connection=sqlite3.connect('file:'+(F/'trace.sqlite').as_posix()+'?mode=ro',uri=True)
    root=connection.execute("SELECT n.globalTid FROM NVTX_EVENTS n LEFT JOIN StringIds s ON s.id=n.textId WHERE COALESCE(n.text,s.value) LIKE 'hyle/b2_episode %' ORDER BY n.start LIMIT 1").fetchone()
    connection.close()
    assert root is not None
    global_pid=root[0]&0xFFFFFFFFFF000000
    native=read(F/'native-process.json')
    assert ((global_pid>>24)&0xFFFFFF)==native['native_pid']
    env=os.environ.copy()
    env.update(_NT_SYMBOL_PATH='',_NT_ALT_SYMBOL_PATH='',DEBUGINFOD_URLS='')
    env.pop('NSYS_CONFIG_DIRECTIVES',None)
    output=F/'trace-local-resolved.nsys-rep'
    sqlite=F/'trace-local-resolved.sqlite'
    assert not output.exists() and not sqlite.exists()
    save(D/'binding.json',dict(script=pin(__file__),tool=pin(TOOL),export_tool=pin(NSYS),raw=raw_pins,
         pdb=ready['pdb'],map=ready['map'],native_pid=native['native_pid'],global_pid=global_pid,
         offline_only=True,servers=[],profile_runs=0,model_runs=0,
         note='Actual installed ResolveSymbols help has no ignore-nt-sym-path; env paths cleared. Only explicit local directory supplied.'))
    execute('help',[str(TOOL),'--help'],env)
    execute('process-list',[str(TOOL),'--process-list','--report',str(F/'trace.nsys-rep')],env)
    execute('resolve',[str(TOOL),'--report',str(F/'trace.nsys-rep'),'--output',str(output),
            '--directories',str(Path(ready['pdb']['path']).parent),'--global-pid',str(global_pid),'--verbose-log'],env)
    assert output.is_file()
    execute('export',[str(NSYS),'export','--type=sqlite','--output',str(sqlite),str(output)],env)
    assert sqlite.is_file()
    for original in raw_pins:
        assert pin(original['path'])==original,'Raw evidence changed by offline step'
    save(D/'ready.json',dict(status='OFFLINE_LOCAL_RESOLUTION_AND_EXPORT_COMPLETED_COUNTS_PENDING',
         output=pin(output),sqlite=pin(sqlite),raw_unchanged=True,originals=raw_pins,
         local_pdb=ready['pdb'],native_pid=native['native_pid'],global_pid=global_pid,
         model_runs=0,profile_runs=0,servers=[],resolution_success='Tool exit0 only; actual resolved/unresolved frame counts require inspection'))


if __name__=='__main__':
    main()
