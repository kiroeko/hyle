"""Correct only ResolveSymbols CLI GlobalPID syntax; no model/profile."""
from pathlib import Path
import importlib.util
import json
import os

W=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('retained_local_symbols',W/'resolve-local.py')
m=importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)
assert m.read(m.D/'resolve/process.json')['exit']==1
assert 'hw:vm:pid' in ''.join((m.D/'resolve'/name).read_text(encoding='utf8') for name in ('stdout.log','stderr.log'))
binding=m.read(m.D/'binding.json')
for record in binding['raw']:
    assert m.pin(record['path'])==record
global_pid=binding['global_pid']
cli_pid=':'.join(str(value) for value in ((global_pid>>56)&255,(global_pid>>48)&255,(global_pid>>24)&0xFFFFFF))
assert cli_pid=='0:1:62400'
env=os.environ.copy()
env.update(_NT_SYMBOL_PATH='',_NT_ALT_SYMBOL_PATH='',DEBUGINFOD_URLS='')
env.pop('NSYS_CONFIG_DIRECTIVES',None)
output=m.F/'trace-local-resolved.nsys-rep'
sqlite=m.F/'trace-local-resolved.sqlite'
assert not output.exists() and not sqlite.exists()
m.save(m.D/'format-fix.json',dict(original_logs=[m.pin(m.D/'resolve'/name) for name in ('stdout.log','stderr.log')],script=m.pin(__file__),
    raw_global_pid=global_pid,cli_global_pid=cli_pid,fix='Serialized numeric GlobalPID changed to documented actual parser hw:vm:pid syntax. No other command/input changes.',
    model_runs=0,profile_runs=0,servers=[]))
m.execute('resolve-format2',[str(m.TOOL),'--report',str(m.F/'trace.nsys-rep'),'--output',str(output),
    '--directories',str(Path(binding['pdb']['path']).parent),'--global-pid',cli_pid,'--verbose-log'],env)
assert output.is_file()
m.execute('export',[str(m.NSYS),'export','--type=sqlite','--output',str(sqlite),str(output)],env)
assert sqlite.is_file()
for record in binding['raw']:
    assert m.pin(record['path'])==record
m.save(m.D/'ready.json',dict(status='OFFLINE_LOCAL_RESOLUTION_AND_EXPORT_COMPLETED_COUNTS_PENDING',
    output=m.pin(output),sqlite=m.pin(sqlite),raw_unchanged=True,originals=binding['raw'],local_pdb=binding['pdb'],
    native_pid=binding['native_pid'],global_pid=global_pid,cli_global_pid=cli_pid,model_runs=0,profile_runs=0,servers=[],
    resolution_success='Tool exit0 only; actual resolved/unresolved frame counts require inspection'))
