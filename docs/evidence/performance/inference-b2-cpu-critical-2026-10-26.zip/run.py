"""Explicit root-only one-profile CPU/IP/backtrace/context-switch collection."""
from pathlib import Path
from collections import Counter
import hashlib
import importlib.util
import json
import os
import re
import sqlite3
import subprocess
import sys
import time
import traceback

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = W.parents[1]


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def save(path, value):
    Path(path).write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n', encoding='utf8')


def pin(path):
    path = Path(path)
    with path.open('rb') as stream:
        digest = hashlib.file_digest(stream, 'sha256').hexdigest()
    return dict(path=str(path), bytes=path.stat().st_size, sha256=digest)


def verify(record):
    assert pin(record['path']) == record, 'Frozen input changed: ' + record['path']


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


def work_gate(folder, plan, native):
    gate = load('cpu_profile_original_b2_work_gate', plan['work_gate_source']['path'])
    raw = json.loads((folder / 'native-stdout.log').read_bytes())
    expected, reference = read(plan['expected_work']['path']), read(plan['reference']['path'])
    ids = gate.check_work(raw, 'hyle', expected, reference)
    audit = []
    normalized = gate.normalize(raw, audit)
    differences = gate.differences(reference, normalized)
    save(folder / 'complete-nontime-report.json', normalized)
    save(folder / 'non-time-comparison.json', dict(differences=differences, normalization_audit=audit,
         reference=plan['reference'], source=plan['work_gate_source']))
    save(folder / 'ids.json', ids)
    id_differences = gate.differences(gate.ids_for(reference, 'hyle'), ids)
    save(folder / 'output-differences.json', id_differences)
    assert not differences and not id_differences, 'Full report/work/198 decisions changed; no replacement run'
    err = (folder / 'native-stderr.log').read_text(encoding='utf8')
    markers = re.findall(r'LOGICAL_NVTX sequence=(\d+) completed_ranges=(\d+) overlapping_episodes=(\d+)', err)
    assert markers and tuple(map(int, markers[-1])) == (99, 1782, 0), markers
    save(folder / 'consumer-quality.json', dict(status='PASS_COMPLETE_ORIGINAL_REPORT_AND_198_IDS',
         native_process=native, complete_nontime_report_equal=True, complete_ids_equal=True,
         decisions=198, physical_episodes=99, prefill=3, decode=96, rows=1728, R=2,
         complete_marker=markers[-1], reference=plan['reference'], scope='Original full B2 work gate; no added normalization exclusions'))


def trace_gate(folder, plan, native):
    connection = sqlite3.connect('file:' + (folder/'trace.sqlite').as_posix() + '?mode=ro', uri=True)
    connection.row_factory = sqlite3.Row
    schema = [dict(x) for x in connection.execute("SELECT name,sql FROM sqlite_master WHERE type='table' ORDER BY name")]
    tables = {x['name'] for x in schema}
    assert {'NVTX_EVENTS', 'StringIds', 'CUPTI_ACTIVITY_KIND_RUNTIME'} <= tables
    events = [dict(x) for x in connection.execute('SELECT n.*, COALESCE(n.text,s.value) label FROM NVTX_EVENTS n LEFT JOIN StringIds s ON s.id=n.textId ORDER BY n.start') if x['label']]
    roots = [x for x in events if x['label'].startswith('hyle/b2_episode ')]
    assert len(roots) == 99 and all(x['end'] is not None for x in roots)
    expected = read(plan['expected_work']['path'])
    expected_meta, context = [], 0
    for phase, tape in enumerate(expected['tapes']):
        for rows in ([tape['rows']] if tape['kind'] == 'prompt' else [1]*tape['rows']):
            expected_meta.append(dict(kind='prefill' if tape['kind']=='prompt' else 'decode', T=rows,
                                      p0=phase, p1=phase, c0=context, c1=context))
            context += rows
    labels = plan['root_contract']['hyle_phase_labels']
    physical = []
    for index, (root, expected_root) in enumerate(zip(roots, expected_meta)):
        meta = {key:int(value) for key,value in re.findall(r'(\w+)=(\d+)',root['label'])}
        meta['kind'] = re.search(r'kind=(\w+)',root['label'])[1]
        assert meta == dict(seq=index+1,index=index,R=2,m0=0,m1=1,**expected_root)
        assert root['uint64Value'] == index+1
        assert ((int(root['globalTid']) >> 24) & 0x00FFFFFF) == native['native_pid'], 'NVTX native PID differs from wrapper child'
        inner = [x for x in events if x['label'] in labels and x['uint64Value']==index+1]
        assert Counter(x['label'] for x in inner) == Counter(labels)
        assert all(x['end'] is not None and x['globalTid']==root['globalTid'] and root['start']<=x['start']<=x['end']<=root['end'] for x in inner)
        if index:
            assert roots[index-1]['end'] <= root['start']
        physical.append(dict(label=root['label'],meta=meta,start_ns=root['start'],end_ns=root['end'],globalTid=root['globalTid']))
    counts = {}
    for name in sorted(tables):
        if any(word in name.upper() for word in ('SAMPL', 'CALLCHAIN', 'CALL_CHAIN', 'CONTEXT', 'SCHED', 'SWITCH', 'DIAGNOSTIC', 'LOSS', 'THREAD', 'PROCESS', 'CPU', 'GRAPH_TRACE')):
            safe = '"' + name.replace('"','""') + '"'
            counts[name] = connection.execute('SELECT COUNT(*) FROM '+safe).fetchone()[0]
    activity = connection.execute('SELECT COUNT(*) FROM CUPTI_ACTIVITY_KIND_RUNTIME').fetchone()[0]
    assert activity > 0
    save(folder / 'sqlite-schema.json', schema)
    save(folder / 'trace-counts.json', counts)
    save(folder / 'physical-roots.json', physical)
    save(folder / 'trace-quality.json', dict(status='PASS_99_CLOSED_ORIGINAL_NATIVE_ROOTS_CPU_QUALITY_PENDING_ANALYSIS',
         native_pid=native['native_pid'], wrapper_pid=native['wrapper_pid'], roots=99, ranges=1782,
         runtime_activity_rows=activity, raw_relevant_table_counts=counts,
         sampling_and_loss_status='Not inferred from successful profiler exit; raw sample/backtrace/ctxsw/loss tables require independent offline analysis',
         limits='One instrumented Hyle diagnostic; not a throughput measurement, not a peer comparison. Wrapper samples must be excluded by actual native PID/TID.'))
    connection.close()


def main():
    if sys.argv[1:] != ['hyle']:
        raise SystemExit('Usage: python -B '+str(__file__)+' hyle')
    plan = read(W/'profile-plan.json')
    assert plan['status']=='FROZEN_PREPARATION_NOT_RUN' and plan['model_process_count']==1
    for record in plan['frozen_inputs']:
        verify(record)
    ready = read(W/'ready.json')
    for key in ('image','runtime','source','actual_dependencies','link_inputs','pdb','map','symbol_contract'):
        verify(ready[key])
    for record in read(ready['link_inputs']['path']):
        verify(record)
    assert ready['source']['sha256'] == plan['diagnostic_source_sha256']
    folder = W/'hyle/trace1'
    assert not folder.exists(), 'Original attempt must not be overwritten or refilled'
    folder.mkdir(parents=True)
    command = [ready['image']['path'], *plan['consumer_arguments']]
    save(folder/'wrapper-config.json', dict(status='ONE_EXPLICIT_NATIVE_CHILD_NOT_STARTED', command=command,
         cwd=str(R), timeout_seconds=plan['native_watchdog_seconds'], image=ready['image']))
    profile = [plan['tool']['path'], 'profile', *plan['nsys_options'], '--output='+str(folder/'trace'),
               plan['python']['path'], '-B', str(W/'wrapper.py'), str(folder/'wrapper-config.json')]
    runtime = read(ready['runtime']['path'])
    env = os.environ.copy()
    env['PATH'] = str(Path(ready['image']['path']).parent)+';'+runtime['PATH']
    env.update(runtime.get('configured_flags',{}))
    env.update(HF_HUB_OFFLINE='1', TRANSFORMERS_OFFLINE='1', _NT_SYMBOL_PATH='', _NT_ALT_SYMBOL_PATH='',
               DEBUGINFOD_URLS='')
    env.pop('NSYS_CONFIG_DIRECTIVES', None)
    save(folder/'command.json', dict(command=profile, native_command=command, cwd=str(R), timeout_seconds=plan['profile_watchdog_seconds'],
         profile_plan=pin(W/'profile-plan.json'), ready=pin(W/'ready.json'), profiler=True,
         throughput_evidence=False, native_processes=1, no_retry=True,
         env_overrides=dict(PATH='diagnostic executable directory + frozen baseline runtime.PATH',
              HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',_NT_SYMBOL_PATH='',_NT_ALT_SYMBOL_PATH='',DEBUGINFOD_URLS='',NSYS_CONFIG_DIRECTIVES='removed'),
         symbol_resolution='Disabled during capture; independent local-only ResolveSymbols step later'))
    started = time.perf_counter()
    with (folder/'nsys-stdout.log').open('xb') as stdout, (folder/'nsys-stderr.log').open('xb') as stderr:
        process = subprocess.Popen(profile,cwd=R,env=env,stdout=stdout,stderr=stderr,creationflags=subprocess.CREATE_NO_WINDOW)
        save(folder/'live.json',dict(nsys_pid=process.pid,launcher_pid=os.getpid(),started_unix_ns=time.time_ns()))
        print('B2_CPU_PROFILE_STARTED', 'nsys_pid='+str(process.pid), 'launcher_pid='+str(os.getpid()), flush=True)
        timed_out = False
        try:
            code = process.wait(timeout=plan['profile_watchdog_seconds'])
        except subprocess.TimeoutExpired:
            timed_out = True
            killed = subprocess.run(['C:/Windows/System32/taskkill.exe','/PID',str(process.pid),'/T','/F'],capture_output=True,timeout=20,creationflags=subprocess.CREATE_NO_WINDOW)
            (folder/'timeout-taskkill.stdout.log').write_bytes(killed.stdout)
            (folder/'timeout-taskkill.stderr.log').write_bytes(killed.stderr)
            process.wait(timeout=20)
            code = process.returncode
    save(folder/'process.json',dict(exit=code,nsys_pid=process.pid,seconds=time.perf_counter()-started,timeout=timed_out))
    print('B2_CPU_PROFILE_ENDED','nsys_pid='+str(process.pid),'exit='+str(code),'timeout='+str(timed_out),flush=True)
    assert code==0 and not timed_out,'Original profiler failure retained; no retry or replacement sample'
    native = read(folder/'native-process.json')
    assert native['exit']==0 and not native['timeout'],'Original native failure retained; no retry'
    work_gate(folder,plan,native)
    trace_gate(folder,plan,native)
    print('B2_CPU_FULL_WORK_GATE_PASS','native_pid='+str(native['native_pid']),flush=True)


if __name__=='__main__':
    try:
        main()
    except BaseException as error:
        folder=W/'hyle/trace1'
        if folder.exists():
            save(folder/'run-error.json',dict(type=type(error).__name__,message=str(error),traceback=traceback.format_exc(),
                 no_automatic_retry=True))
        raise
