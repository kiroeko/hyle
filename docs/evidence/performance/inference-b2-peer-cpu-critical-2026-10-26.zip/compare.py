"""Pair exact physical work from two completed CPU diagnostics, not TPS."""
from pathlib import Path
import argparse
import hashlib
import json

W=Path(__file__).resolve().parent


def read(path):return json.loads(path.read_text(encoding='utf8'))


def pin(path):
    b=path.read_bytes()
    return dict(path=str(path),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())


def main():
    p=argparse.ArgumentParser()
    p.add_argument('--hyle-facts',type=Path,required=True)
    p.add_argument('--peer-facts',type=Path,required=True)
    p.add_argument('--hyle-folder',type=Path,required=True)
    p.add_argument('--peer-folder',type=Path,required=True)
    args=p.parse_args()
    h,peer=read(args.hyle_facts),read(args.peer_facts)
    assert h['arm']=='hyle' and peer['arm']=='peer'
    assert [x['meta'] for x in h['per_root']]==[x['meta'] for x in peer['per_root']]
    assert len(h['per_root'])==99
    h_ids,p_ids=read(args.hyle_folder/'ids.json'),read(args.peer_folder/'ids.json')
    assert h_ids==p_ids and sum(len(x) for x in h_ids.values())==198
    for folder in (args.hyle_folder,args.peer_folder):
        quality=read(folder/'consumer-quality.json')
        assert quality['status']=='PASS_COMPLETE_ORIGINAL_REPORT_AND_198_IDS'
        assert quality['complete_nontime_report_equal'] and quality['complete_ids_equal']
        assert (quality['physical_episodes'],quality['prefill'],quality['decode'],quality['rows'],quality['R'])==(99,3,96,1728,2)
    hm={x['meta']['seq']:x for x in h['per_root']}
    pm={x['meta']['seq']:x for x in peer['per_root']}
    decode=[seq for seq,x in hm.items() if x['meta']['kind']=='decode']
    common_hot=[seq for seq in decode if not hm[seq]['record'] and not pm[seq]['record']]
    common_one_graph=[seq for seq in decode if len(hm[seq]['graph_activity_rows'])==1 and len(pm[seq]['graph_activity_rows'])==1]
    common_hot_one_graph=[seq for seq in common_hot if seq in common_one_graph]
    fields=['wall_ns','running_ns','off_cpu_ns','unknown_ns','observed_gpu_union_ns',
            'cuda_api_union_ns','running_inside_cuda_api_ns','running_overlapping_gpu_ns',
            'running_outside_gpu_and_cuda_api_ns','observed_graph_envelope_union_ns',
            'before_first_graph_envelope_ns','after_last_graph_envelope_ns']
    def aggregate(mapping,seqs):
        metrics={key:sum(mapping[seq]['phases']['ROOT']['metric'][key] for seq in seqs) for key in fields}
        calls={}
        for seq in seqs:
            for call in mapping[seq]['phases']['ROOT']['cuda_API_wall']:
                item=calls.setdefault(call['api'],dict(api=call['api'],count=0,clipped_API_wall_sum_ns=0))
                item['count']+=call['overlapping_call_count']
                item['clipped_API_wall_sum_ns']+=call['clipped_API_wall_sum_ns']
        return dict(roots=len(seqs),metric=metrics,API_wall=sorted(calls.values(),key=lambda x:(-x['clipped_API_wall_sum_ns'],x['api'])),
            graph_rows=sum(len(mapping[seq]['graph_activity_rows']) for seq in seqs),
            recording_roots=sum(mapping[seq]['record'] for seq in seqs),
            positive_samples=sum(mapping[seq]['phases']['ROOT']['samples']['positive_weight_samples'] for seq in seqs),
            samples_with_CPU_identity_discrepancy=sum(mapping[seq]['phases']['ROOT']['samples']['positive_samples_with_CPU_identity_discrepancy'] for seq in seqs))
    def affected_slices(facts,mapping,seqs):
        intervals=sorted(set((x['predecessor']['start'],x['successor']['start'])
            for x in facts['quality']['positive_sample_CPU_identity_discrepancies']
            if x['predecessor'] is not None and x['successor'] is not None))
        assert all(a[1]<=b[0] for a,b in zip(intervals,intervals[1:]))
        physical=read((args.hyle_folder if facts['arm']=='hyle' else args.peer_folder)/'physical-roots.json')
        by_seq={x['meta']['seq']:x for x in physical}
        return sum(max(0,min(b,by_seq[seq]['end_ns'])-max(a,by_seq[seq]['start_ns']))
            for a,b in intervals for seq in seqs)
    groups={}
    for name,seqs in [('all_decode',decode),('both_nonrecording_decode',common_hot),
                     ('both_one_graph_decode',common_one_graph),('both_nonrecording_one_graph_decode',common_hot_one_graph)]:
        hh,pp=aggregate(hm,seqs),aggregate(pm,seqs)
        if 'one_graph' in name:
            for row in (hh,pp):
                m=row['metric']
                assert m['before_first_graph_envelope_ns']+m['observed_graph_envelope_union_ns']+m['after_last_graph_envelope_ns']==m['wall_ns']
        h_suspect,p_suspect=affected_slices(h,hm,seqs),affected_slices(peer,pm,seqs)
        outside_delta=hh['metric']['running_outside_gpu_and_cuda_api_ns']-pp['metric']['running_outside_gpu_and_cuda_api_ns']
        groups[name]=dict(sequences=seqs,hyle=hh,peer=pp,
            conservative_CPU_ID_sensitivity=dict(hyle_whole_affected_slices_ns=h_suspect,
                peer_whole_affected_slices_ns=p_suspect,
                worst_case_absolute_sensitivity_bound_ns=h_suspect+p_suspect,
                host_outside_GPU_API_delta_minus_entire_suspect_slice_bound_ns=outside_delta-h_suspect-p_suspect),
            Hyle_minus_peer_ns={k:hh['metric'][k]-pp['metric'][k] for k in fields})
    common_phases={}
    for arm,mapping in [('hyle',hm),('peer',pm)]:
        common_phases[arm]={}
        for label in mapping[common_hot[0]]['phases']:
            common_phases[arm][label]={key:sum(mapping[seq]['phases'][label]['metric'][key] for seq in common_hot)
                for key in mapping[common_hot[0]]['phases'][label]['metric'] if key.endswith('_ns')}
    facts=dict(status='PAIRED_GRAPH_LEVEL_CPU_DIAGNOSTIC_EXACT_PHYSICAL_WORK',
        inputs=[pin(args.hyle_facts),pin(args.peer_facts),pin(args.hyle_folder/'consumer-quality.json'),
                pin(args.peer_folder/'consumer-quality.json'),pin(args.hyle_folder/'ids.json'),pin(args.peer_folder/'ids.json')],
        exact_99_physical_metadata_equal=True,all198_decisions_equal=True,groups=groups,
        both_nonrecording_90_root_phase_metrics=common_phases,
        actual_phase_metrics={
            'hyle':{k:dict(count=v['count'],metric=v['metric']) for k,v in h['decode'].items() if k!='ROOT'},
            'peer':{k:dict(count=v['count'],metric=v['metric']) for k,v in peer['decode'].items() if k!='ROOT'}},
        limits=['Two separate one-run instrumented diagnoses, not a new paired throughput window or gain certificate.',
                'Hyle has17 phase labels/12 children; peer has4 siblings. No peerphase is renamed as an equivalent Hylephase; wrapper llama_decode can include multiple host/native stages.',
                'Profiling options match but NVTX label/range counts differ (Hyle1782 vspeer495). Per-label instrumentation overhead is not independently excluded from hostpath differences.',
                'Graph envelope contains internal graph scheduling/gaps and is not pure kernel busytime. Before/graph/after partition is compared only where both roots contain exactlyone graph.',
                'CUDAAPI wall spans can nest/includeGPUwait/driver/profiler interception. Their differences are not recoverableCPUselftime.',
                'Scheduled-onCPU includes activepolling and interrupts. Read both CPU-ID discrepancy reports before interpreting small differences.',
                'Sparse public/PDB symbol labels alone are not exactfunction bounds. Refine against actual StaticMAP+PE.pdata without treating nearestpublic names as a hotspot.',
                'Same physical rows/predictions does not establish bitwise equality of all intermediate math or erase differences in APIs/state/output boundaries.'])
    (W/'paired-cpu-facts.json').write_text(json.dumps(facts,indent=2)+'\n',encoding='utf8')
    summary=dict(status=facts['status'],groups={k:dict(roots=len(v['sequences']),
        hyle_ms={key[:-3]+'_ms':value/1e6 for key,value in v['hyle']['metric'].items()},
        peer_ms={key[:-3]+'_ms':value/1e6 for key,value in v['peer']['metric'].items()},
        Hyle_minus_peer_ms={key[:-3]+'_ms':value/1e6 for key,value in v['Hyle_minus_peer_ns'].items()}) for k,v in groups.items()},limits=facts['limits'])
    summary['both_nonrecording_90_root_phase_ms']={arm:{label:{k[:-3]+'_ms':v/1e6 for k,v in metrics.items()}
        for label,metrics in labels.items()} for arm,labels in common_phases.items()}
    summary['common90_CPU_ID_sensitivity_ms']={k[:-3]+'_ms':v/1e6 for k,v in groups['both_nonrecording_decode']['conservative_CPU_ID_sensitivity'].items()}
    (W/'paired-cpu-summary.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf8')
    print(json.dumps(summary,indent=2))


if __name__=='__main__':main()
