"""Independent interval-edge reconstruction from retained native SQLite rows."""
from pathlib import Path
import json
import re
import sqlite3

W = Path(__file__).resolve().parent
H = W.parent / 'inference-b2-cpu-critical-20261026'

def read(path): return json.loads(path.read_text(encoding='utf8'))
def rows(c, q, p=()): return list(c.execute(q, p))

def check(folder, db, arm):
    c = sqlite3.connect(db)
    c.row_factory = sqlite3.Row
    roots = rows(c, '''SELECT n.*,COALESCE(n.text,s.value) label FROM NVTX_EVENTS n
        LEFT JOIN StringIds s ON s.id=n.textId WHERE COALESCE(n.text,s.value) LIKE ? ORDER BY n.start''',
        (arm+'/b2_episode %',))
    assert len(roots) == 99
    tid = roots[0]['globalTid']; pid = tid & ~0xffffff
    sched = rows(c, 'SELECT rowid,* FROM SCHED_EVENTS WHERE globalTid=? ORDER BY start,rowid', (tid,))
    run = []
    for a,b in zip(sched,sched[1:]):
        if a['isSchedIn']:
            assert not b['isSchedIn'] and a['cpu'] == b['cpu']
            run.append((a['start'],b['start']))
    apis = rows(c, '''SELECT a.*,s.value api FROM CUPTI_ACTIVITY_KIND_RUNTIME a
        JOIN StringIds s ON s.id=a.nameId WHERE a.globalTid=?''', (tid,))
    names = {x[0] for x in c.execute("SELECT name FROM sqlite_master WHERE type='table'")}
    gpu = []
    for table in ('GRAPH_TRACE','KERNEL','MEMCPY','MEMSET'):
        name = 'CUPTI_ACTIVITY_KIND_'+table
        if name in names:
            gpu += [dict(x, table=table) for x in rows(c, 'SELECT * FROM '+name+' WHERE globalPid=?',(pid,))]
    result = {}
    for root in roots:
        if 'kind=decode' not in root['label']: continue
        lo,hi=root['start'],root['end']
        current = [a for a in apis if a['start'] < hi and a['end'] > lo]
        if any('StreamBeginCapture' in a['api'] for a in current): continue
        graphs = [g for g in gpu if g['table']=='GRAPH_TRACE' and g['start']<hi and g['end']>lo]
        if len(graphs)!=1: continue
        assert lo <= graphs[0]['start'] < graphs[0]['end'] <= hi
        graph=graphs[0]
        launch=[a for a in current if a['correlationId']==graph['correlationId']]
        assert len(launch)==1 and 'GraphLaunch' in launch[0]['api']
        bands=[run, [(g['start'],g['end']) for g in gpu], [(a['start'],a['end']) for a in current]]
        bands=[[(max(lo,a),min(hi,b)) for a,b in band if a<hi and b>lo] for band in bands]
        edges=sorted({lo,hi,*[p for band in bands for pair in band for p in pair]})
        outside=0
        for a,b in zip(edges,edges[1:]):
            flags=[any(x<=a<y for x,y in band) for band in bands]
            if flags==[True,False,False]: outside += b-a
        result[root['uint64Value']]=dict(wall_ns=hi-lo,before_ns=graph['start']-lo,
            graph_ns=graph['end']-graph['start'],after_ns=hi-graph['end'],outside_ns=outside)
    assert read(folder/'ids.json') == read(H/'hyle/trace1/ids.json')
    return result

h=check(H/'hyle/trace1', H/'hyle/trace1/native-scope-raw.sqlite','hyle')
p=check(W/'peer/trace1', W/'peer/trace1/native-scope-raw.sqlite','peer')
common=sorted(set(h)&set(p)); assert len(common)==90
expected=read(W/'paired-cpu-facts.json')['groups']['both_nonrecording_one_graph_decode']
assert common==expected['sequences']
keys={'wall_ns':'wall_ns','before_ns':'before_first_graph_envelope_ns',
    'graph_ns':'observed_graph_envelope_union_ns','after_ns':'after_last_graph_envelope_ns',
    'outside_ns':'running_outside_gpu_and_cuda_api_ns'}
totals={}
for arm,values in [('hyle',h),('peer',p)]:
    total={key:sum(values[seq][key] for seq in common) for key in keys}
    assert total['wall_ns']==total['before_ns']+total['graph_ns']+total['after_ns']
    for key,source in keys.items(): assert total[key]==expected[arm]['metric'][source], (arm,key)
    totals[arm]=total
report=dict(status='ROOT_INDEPENDENT_NATIVE_INTERVAL_RECONSTRUCTION_EXACT',
    common_sequences=common,totals_ns=totals,
    method='Independent direct SQL and interval-edge classification; does not import analyzer or its interval functions.',
    checks=['99roots each; 198IDs equal','90common nonrecording roots each has one contained graph',
        'Graph correlation has one native-thread GraphLaunch','All5 interval claims exactly match paired facts'],
    limits=['Same single instrumented runs, not independent new measurements or throughput claims.',
        'Scheduling/graph-envelope/driver/instrumentation and math/state boundary limits still apply.'])
(W/'root-independent-review.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf8')
print(json.dumps(report,indent=2))
