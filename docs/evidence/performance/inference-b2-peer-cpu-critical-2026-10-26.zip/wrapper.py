"""One native child; write its original streams directly, outside Nsight streams."""
from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
import time

sys.dont_write_bytecode = True


def save(path, value):
    Path(path).write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n', encoding='utf8')


def pin(path):
    path = Path(path)
    with path.open('rb') as stream:
        digest = hashlib.file_digest(stream, 'sha256').hexdigest()
    return dict(path=str(path), bytes=path.stat().st_size, sha256=digest)


def main():
    assert len(sys.argv) == 2, 'Only a frozen wrapper-config path is accepted'
    config_path = Path(sys.argv[1]).resolve()
    config = json.loads(config_path.read_text(encoding='utf8'))
    folder = config_path.parent
    assert config['status'] == 'ONE_EXPLICIT_NATIVE_CHILD_NOT_STARTED'
    assert not (folder / 'native-live.json').exists(), 'No second native child in this folder'
    assert pin(config['image']['path']) == config['image']
    command = config['command']
    assert command[0] == config['image']['path']
    started = time.perf_counter()
    with (folder / 'native-stdout.log').open('xb') as stdout, (folder / 'native-stderr.log').open('xb') as stderr:
        child = subprocess.Popen(command, cwd=config['cwd'], stdout=stdout, stderr=stderr,
                                 creationflags=subprocess.CREATE_NO_WINDOW)
        save(folder / 'native-live.json', dict(wrapper_pid=os.getpid(), native_pid=child.pid,
             started_unix_ns=time.time_ns(), command=command, cwd=config['cwd']))
        print('B2_CPU_NATIVE_STARTED', 'wrapper_pid=' + str(os.getpid()), 'native_pid=' + str(child.pid), flush=True)
        timed_out = False
        try:
            code = child.wait(timeout=config['timeout_seconds'])
        except subprocess.TimeoutExpired:
            timed_out = True
            killed = subprocess.run(['C:/Windows/System32/taskkill.exe', '/PID', str(child.pid), '/T', '/F'],
                                    capture_output=True, timeout=20, creationflags=subprocess.CREATE_NO_WINDOW)
            (folder / 'native-timeout-taskkill.stdout.log').write_bytes(killed.stdout)
            (folder / 'native-timeout-taskkill.stderr.log').write_bytes(killed.stderr)
            child.wait(timeout=20)
            code = child.returncode
    process = dict(exit=code, native_pid=child.pid, wrapper_pid=os.getpid(), timeout=timed_out,
                   seconds=time.perf_counter()-started, config=pin(config_path),
                   stdout=pin(folder / 'native-stdout.log'), stderr=pin(folder / 'native-stderr.log'),
                   authoritative_streams='Independent binary file handles; Nsight ProcessStreams is not used')
    save(folder / 'native-process.json', process)
    print('B2_CPU_NATIVE_ENDED', 'native_pid=' + str(child.pid), 'exit=' + str(code),
          'timeout=' + str(timed_out), flush=True)
    return 124 if timed_out else code


if __name__ == '__main__':
    raise SystemExit(main())
