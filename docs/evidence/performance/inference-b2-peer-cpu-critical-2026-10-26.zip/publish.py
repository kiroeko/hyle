"""Publish bounded peer CPU evidence after root review; no model/build/profile."""
from pathlib import Path
import hashlib
import json
import subprocess
import sys
import zipfile

W=Path(__file__).resolve().parent
R=W.parents[1]
F=W/'peer/trace1'
DEST=R/'docs/evidence/performance'
NAME='inference-b2-peer-cpu-critical-2026-10-26'


def read(path):return json.loads(Path(path).read_text(encoding='utf-8-sig'))
def sha(path):
    with Path(path).open('rb') as source:return hashlib.file_digest(source,'sha256').hexdigest()
def pin(path):
    path=Path(path)
    return dict(path=str(path),bytes=path.stat().st_size,sha256=sha(path))
def verify(record):
    path=Path(record['path'])
    if not path.is_absolute():path=R/path
    assert path.stat().st_size==record['bytes'] and sha(path)==record['sha256'],record['path']


def main():
    assert sys.argv[1:]==['publish'],'Explicit root command only: publish.py publish'
    archive_path,report_path=DEST/(NAME+'.zip'),DEST/(NAME+'.json')
    assert not archive_path.exists() and not report_path.exists(),'Do not overwrite prior evidence'
    work=read(F/'consumer-quality.json')
    pair=read(W/'paired-cpu-facts.json');summary=read(W/'paired-cpu-summary.json')
    review=read(W/'root-independent-review.json');repro=read(W/'native-filter-reproduction.json')
    assert work['status']=='PASS_COMPLETE_ORIGINAL_REPORT_AND_198_IDS'
    assert pair['status']=='PAIRED_GRAPH_LEVEL_CPU_DIAGNOSTIC_EXACT_PHYSICAL_WORK'
    assert pair['exact_99_physical_metadata_equal'] and pair['all198_decisions_equal']
    assert review['status']=='ROOT_INDEPENDENT_NATIVE_INTERVAL_RECONSTRUCTION_EXACT'
    assert repro['status']=='PEER_NATIVE_FILTERS_EXACTLY_REPRODUCE_ALL_ANALYSIS'
    for row in pair['inputs']:verify(row)
    for row in repro['checks']:
        assert row['all_values_except_source_path_size']=='EXACT_EQUAL'
        verify(row['original']);verify(row['filtered'])
    verify(repro['analyzer']);verify(repro['filter_script'])
    common=pair['groups']['both_nonrecording_one_graph_decode']
    assert len(common['sequences'])==90
    fields={'wall_ns':'wall_ns','before_ns':'before_first_graph_envelope_ns',
            'graph_ns':'observed_graph_envelope_union_ns','after_ns':'after_last_graph_envelope_ns',
            'outside_ns':'running_outside_gpu_and_cuda_api_ns'}
    for arm in ('hyle','peer'):
        assert common[arm]['roots']==90
        for independent,metric in fields.items():
            assert review['totals_ns'][arm][independent]==common[arm]['metric'][metric]
    for name in ('process.json','native-process.json'):
        process=read(F/name);assert process['exit']==0 and not process['timeout']
    datasets={'peer/trace1/native-scope-raw.sqlite','peer/trace1/native-scope-resolved.sqlite'}
    for dataset in datasets:
        filter=read((W/dataset).with_suffix('.filter.json'))
        verify(filter['output'])
        assert all(x.get('exact_both_directions_EXCEPT')=='PASS' for x in filter['tables'].values())
    # Current analysis is archived once per raw/resolved compact dataset. The
    # identical full-database facts remain pinned in the reproduction receipt.
    duplicate_names={'peer-raw-cpu-facts.json','peer-raw-cpu-summary.json',
        'peer-local-resolved-cpu-facts.json','peer-local-resolved-cpu-summary.json',
        'native-filter-reproduction-before-quality-path-refresh.json'}
    allowed={'.py','.json','.log','.cc','.h','.patch'}
    files=[]
    for path in W.rglob('*'):
        if not path.is_file():continue
        name=path.relative_to(W).as_posix()
        if '__pycache__' in path.parts or path.name in duplicate_names:continue
        if path.name in {'archive-receipt.json','archive-manifest.json'}:continue
        if name.startswith('local-symbols2/process-list/'):continue
        if path.suffix.lower() not in allowed and name not in datasets:continue
        files.append((name,path))
    assert {name for name,_ in files if name.endswith('.sqlite')}==datasets
    assert all(not name.lower().endswith(('.obj','.exe','.dll','.lib','.exp','.pdb','.map','.nsys-rep','.etl')) for name,_ in files)
    # Optional map inputs are exact named files supplied by the concurrent
    # local PE/MAP analysis. Do not discover/copy any other Hyle workspace data.
    extras_path=W/'publish-map-inputs.json'
    assert extras_path.is_file(),'Wait for final map analysis input list before publishing'
    extras=read(extras_path)
    assert extras['status']=='FROZEN_MAP_ANALYSIS_INPUTS'
    for row in extras['files']:
        verify(row['file'])
        assert Path(row['file']['path']).suffix.lower() in allowed
        assert not row['member'].startswith(('/', '\\')) and '..' not in Path(row['member']).parts
        files.append((row['member'],Path(row['file']['path'])))
    names=[name for name,_ in files]
    assert len(names)==len(set(names)),'Archive member collision'
    manifest=[dict(member=name,bytes=path.stat().st_size,sha256=sha(path)) for name,path in sorted(files)]
    with zipfile.ZipFile(archive_path,'x',zipfile.ZIP_DEFLATED,compresslevel=6) as archive:
        for name,path in sorted(files):archive.write(path,name)
        archive.writestr('archive-manifest.json',json.dumps(manifest,indent=2)+'\n')
    with zipfile.ZipFile(archive_path) as archive:
        assert archive.testzip() is None and len(archive.namelist())==len(manifest)+1
        for row in manifest:
            raw=archive.read(row['member'])
            assert len(raw)==row['bytes'] and hashlib.sha256(raw).hexdigest()==row['sha256']
    prior_json=DEST/'inference-b2-cpu-critical-2026-10-26.json'
    prior_zip=DEST/'inference-b2-cpu-critical-2026-10-26.zip'
    report=dict(schema='hyle.performance.evidence.v1',date='2026-10-26',
        status='ONE_PEER_CPU_DIAGNOSTIC_FULL_WORK_AND_INDEPENDENT_COMMON90_RECONSTRUCTION_PASS',
        source_git_before_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),
        activity=dict(new_profiles=1,new_native_model_processes=1,new_peer_consumer_TUs=1,
            SDK_Graph_native_device_builds=0,extra_model_runs=0,throughput_measurement=False,
            sampling='1000Hz CPU IP/backtrace, process-tree context switches, graph:host-only CUDA/NVTX',
            output='Original native --result file plus independently redirected stdout/stderr; no ProcessStreams extraction'),
        peer_identity=read(W/'ready.json'),peer_work_quality=work,peer_trace_quality=read(F/'trace-quality.json'),
        hyle_source_evidence=dict(report=pin(prior_json),archive=pin(prior_zip),
            reuse='Original Hyle native-scope raw/resolved SQLite remain in this already-published archive and are not duplicated.'),
        exact_physical_work=dict(roots=99,prefill=3,decode=96,requests=2,input_rows=1728,decisions=198,
            complete_198_ids_equal=True,peer_phase_labels=4,hyle_phase_labels=17),
        common90=summary['groups']['both_nonrecording_one_graph_decode'],
        paired_quality_and_sensitivity=common['conservative_CPU_ID_sensitivity'],
        all_decode=summary['groups']['all_decode'],
        phase_boundaries='No peer phase is treated as identical to a Hyle phase. Common comparison uses original physical roots, native API/GPU intervals and graph envelopes.',
        findings=[
            'Common90: Hyle1223.208763ms/peer1085.084314ms root wall. Before first graph111.960770/40.203128ms, graph-envelope1068.759053/1028.635732ms, after last graph42.488940/16.245454ms. These describe separate instrumented runs, not new TPS or saved time.',
            'Common90 reconstructed running outside observedGPU and CUDA APIs99.701301/14.364502ms. This overlaps the before/after partition and must not be added to it or called wholly recoverable CPU work.',
            'Most decode positive-weight leaf samples remain in unresolved NVIDIA driver modules for both engines. Local PDB resolution is partial; symbol names and nearest-public aliases are not exact function extents.',
            'OS offCPU time is small in these finite reconstructed scopes. Scheduling discrepancies and full affected-slice sensitivity remain explicit; no zero-loss or exact exclusive-userCPU claim.',
            'Native-only compact raw/resolved peer records exactly reproduce current analysis, with original IDs/timestamps, metadata bytes, predecessor/successor scheduling and all referenced retained StringIds.'
        ],
        local_symbol_coverage=read(W/'local-symbols2/counts.json'),
        native_filter_reproduction=repro,independent_review=review,
        map_analysis_inputs=extras,
        quality_limits=summary['limits']+[
            'Hyle and peer were profiled at different times, each once, with17 versus4 phase labels. Instrumentation, debug/link layout, GPU/CPU clocks and system load can affect differences.',
            'Graph-level GPU envelope includes internal graph gaps; it is not kernel busytime or a device roofline.',
            'CUDA API spans include nested driver/profiler work and waiting. Scheduled-onCPU includes polling, kernel and interrupts; all interval categories overlap as specified.',
            'No loss/overflow diagnostic found is not proof of zero ETW loss. Raw profiler warnings and finite sampling/CPU-ID discrepancy evidence are retained.',
            'No new prefill/decode TPS, RAM/VRAM benefit, product optimization or MTP performance result is established by this diagnostic.',
            'The preparation profile-plan copied one Hyle-only wording string; actual peer command, source, output authority and complete work checks define this run.'
        ],
        archive=dict(path=archive_path.name,bytes=archive_path.stat().st_size,sha256=sha(archive_path),members=len(manifest)+1,
            verification='ZIP CRC and every member length/SHA256 checked',
            scope='Two peer native-scope SQLite only; no whole-system SQLite/ETL/nsys reports, binaries, PDB/MAP or duplicate old Hyle datasets. Includes bounded current source/commands/logs/analysis and named new Hyle map-analysis summaries.'))
    report_path.write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n',encoding='utf8')
    (W/'archive-receipt.json').write_text(json.dumps(report['archive'],indent=2)+'\n',encoding='utf8')
    print(json.dumps(dict(report=str(report_path),archive=report['archive']),indent=2))


if __name__=='__main__':main()
