"""Read-only exact MAP+PE runtime-function attribution of one retained capture.

Never assigns an IP to its nearest public symbol. The ASLR base is explicitly
inferred from several /Z7 Model symbol constraints, not module-load metadata.
"""
from pathlib import Path
from collections import Counter, defaultdict
import bisect
import hashlib
import json
import re
import sqlite3
import struct

W = Path(__file__).resolve().parent
SOURCE = W / 'hyle/trace1/native-scope-resolved.sqlite'
IMAGE = W / 'link/consumer.exe'
MAP = W / 'link/consumer.map'
ANCHORS = ('prepare_evaluations', 'submit_evaluations', 'submit_retained',
           'retain_state_storage', 'detach_episode')


def pin(path):
    with path.open('rb') as stream:
        digest = hashlib.file_digest(stream, 'sha256').hexdigest()
    return {'path': str(path), 'bytes': path.stat().st_size, 'sha256': digest}


def pe_functions():
    data = IMAGE.read_bytes()
    pe = struct.unpack_from('<I', data, 0x3c)[0]
    sections = struct.unpack_from('<H', data, pe + 6)[0]
    opt_size = struct.unpack_from('<H', data, pe + 20)[0]
    opt = pe + 24
    assert struct.unpack_from('<H', data, opt)[0] == 0x20b
    preferred = struct.unpack_from('<Q', data, opt + 24)[0]
    image_size = struct.unpack_from('<I', data, opt + 56)[0]
    rva, length = struct.unpack_from('<II', data, opt + 112 + 3 * 8)
    offset = None
    section_rows = []
    for i in range(sections):
        at = opt + opt_size + 40 * i
        vs, va, rs, rp = struct.unpack_from('<IIII', data, at + 8)
        section_rows.append((va,va + max(vs,rs),rp))
        if va <= rva < va + max(vs, rs):
            offset = rp + rva - va
    assert offset is not None
    functions = [struct.unpack_from('<III', data, at)
        for at in range(offset, offset + length, 12)]
    assert all(a < b <= image_size for a,b,u in functions)
    assert all(a[1] <= b[0] for a,b in zip(functions, functions[1:])), 'Overlapping pdata requires different attribution'
    def file_offset(rva):
        for a,b,p in section_rows:
            if a <= rva < b:
                return p+rva-a
        raise ValueError(hex(rva))
    by_begin = {a: (a,b,u) for a,b,u in functions}
    parents = {}
    for a,b,u in functions:
        at = file_offset(u)
        vf,prolog,codes,frame = struct.unpack_from('<BBBB',data,at)
        if (vf >> 3) & 4: # UNW_FLAG_CHAININFO, an explicit RUNTIME_FUNCTION triple.
            target = struct.unpack_from('<III',data,at+4+((codes+1)&~1)*2)
            assert by_begin.get(target[0]) == target
            parents[a] = target[0]
    primary = {}
    for a,b,u in functions:
        seen = set()
        current = a
        while current in parents:
            assert current not in seen
            seen.add(current)
            current = parents[current]
        primary[a] = current
    return preferred, image_size, functions, primary


def main():
    assert not (W / 'map-attribution.json').exists(), 'Preserve frozen attribution'
    preferred, image_size, functions, primary = pe_functions()
    starts = [a for a,b,u in functions]
    by_begin = {a: (a,b,u) for a,b,u in functions}
    symbols = defaultdict(list)
    section = 'public'
    map_counts = Counter()
    for number, line in enumerate(MAP.read_text(encoding='utf8').splitlines(), 1):
        if line.strip() == 'Static symbols':
            section = 'static'
        match = re.match(r'^\s+([0-9a-fA-F]{4}):([0-9a-fA-F]{8,16})\s+(\S+)\s+([0-9a-fA-F]{16})\s+f\s+(.*?)\s*$', line)
        if not match:
            continue
        rva = int(match[4], 16) - preferred
        if not 0 <= rva < image_size:
            continue
        value = {'name': match[3], 'kind': section, 'map_line': number, 'object_flags': match[5]}
        if value not in symbols[rva]:
            symbols[rva].append(value)
        map_counts[section] += 1
    db = sqlite3.connect('file:' + SOURCE.as_posix() + '?mode=ro', uri=True)
    db.row_factory = sqlite3.Row
    nvtx = [dict(x) for x in db.execute('''SELECT n.start,n.end,n.globalTid,n.uint64Value,
        COALESCE(n.text,s.value) label FROM NVTX_EVENTS n LEFT JOIN StringIds s ON s.id=n.textId
        WHERE COALESCE(n.text,s.value) LIKE 'hyle/%' ORDER BY n.start''')]
    roots = [x for x in nvtx if x['label'].startswith('hyle/b2_episode ')]
    assert len(roots) == 99 and len(nvtx) == 1782
    tid = roots[0]['globalTid']
    assert {x['globalTid'] for x in roots} == {tid}
    lo, hi = roots[0]['start'], roots[-1]['end']
    samples = [dict(x) for x in db.execute('''SELECT * FROM COMPOSITE_EVENTS
        WHERE globalTid=? AND cpuCycles>0 AND start>=? AND start<? ORDER BY start,id''', (tid,lo,hi))]
    chain_rows = [dict(x) for x in db.execute('''SELECT c.*,s.value symbol_name,m.value module_name,e.start sample_start
        FROM COMPOSITE_EVENTS e JOIN SAMPLING_CALLCHAINS c ON c.id=e.id
        LEFT JOIN StringIds s ON s.id=c.symbol LEFT JOIN StringIds m ON m.id=c.module
        WHERE e.globalTid=? AND e.cpuCycles>0 AND e.start>=? AND e.start<? ORDER BY c.id,c.stackDepth''', (tid,lo,hi))]
    image_key = str(IMAGE).replace('/', '\\').casefold()
    own = [x for x in chain_rows if str(x['module_name']).replace('/', '\\').casefold() == image_key]
    base_candidates = None
    anchors = []
    rejected_anchors = []
    for name in ANCHORS:
        expected = 'qwen35::Model::' + name
        maps = [(rva, entries) for rva,entries in symbols.items()
            if any(x['name'].startswith('?' + name + '@Model@qwen35@@') for x in entries)]
        assert len(maps) == 1 and maps[0][0] in by_begin, (name, maps)
        begin, end, unwind = by_begin[maps[0][0]]
        observations = [x for x in own if x['symbol_name'] == expected and not x['unresolved'] and not x['kernelMode']]
        assert observations, name
        candidates = None
        for x in observations:
            # begin <= IP-base < end and base is allocation-granularity aligned.
            low = x['originalIP'] - end + 1
            high = x['originalIP'] - begin
            possible = set(range(((low + 65535) // 65536) * 65536, high + 1, 65536))
            candidates = possible if candidates is None else candidates & possible
        anchor = {'Model_method': expected, 'positive_frame_observations': len(observations),
            'unique_positive_samples': len({x['id'] for x in observations}),
            'private_Model_source_debug': '/Z7 one Model TU; these resolved method names are local PDB information, not sparse Graph public names',
            'MAP_aliases_at_start': maps[0][1], 'PE_runtime_begin_end_RVA': [hex(begin),hex(end)],
            'observed_IP_min_max': [hex(min(x['originalIP'] for x in observations)), hex(max(x['originalIP'] for x in observations))],
            'candidate_64KB_aligned_bases': [hex(x) for x in sorted(candidates)]}
        if not candidates:
            anchor['rejected_reason'] = 'Resolved name cannot be proven inside its PRIMARY PE runtime extent at any64KB-aligned base; not used to infer base. Its explicit chained extents are checked afterward as a held-out validation.'
            rejected_anchors.append(anchor)
            continue
        base_candidates = candidates if base_candidates is None else base_candidates & candidates
        anchors.append(anchor)
    assert len(anchors) >= 3
    assert len(base_candidates) == 1, base_candidates
    base = next(iter(base_candidates))
    # Check every selected anchor frame lands inside the actual owning runtime entry.
    for anchor in anchors:
        name = anchor['Model_method']
        begin,end = [int(x,16) for x in anchor['PE_runtime_begin_end_RVA']]
        assert all(begin <= x['originalIP'] - base < end for x in own if x['symbol_name'] == name and not x['unresolved'] and not x['kernelMode'])
    def owner(ip):
        rva = ip - base
        if not 0 <= rva < image_size:
            return ('outside_image', rva)
        index = bisect.bisect_right(starts, rva) - 1
        if index < 0 or rva >= functions[index][1]:
            return ('no_pdata_extent', rva)
        begin,end,u = functions[index]
        owning = primary[begin]
        if not symbols.get(owning):
            return ('pdata_no_MAP_primary_start', owning)
        return ('exact_runtime_or_unwind_chain_MAP_start', owning)
    def frame_owner(frame):
        here = owner(frame['originalIP'])
        if frame['stackDepth'] > 0 and here != owner(frame['originalIP'] - 1):
            return ('nonleaf_return_boundary_ambiguous', frame['originalIP'] - base)
        return here
    held_out = []
    for anchor in rejected_anchors:
        observations = [x for x in own if x['symbol_name'] == anchor['Model_method'] and not x['unresolved'] and not x['kernelMode']]
        expected_begin = int(anchor['PE_runtime_begin_end_RVA'][0],16)
        assert all(owner(x['originalIP']) == ('exact_runtime_or_unwind_chain_MAP_start',expected_begin) for x in observations)
        held_out.append({'method':anchor['Model_method'],'positive_frame_observations':len(observations),
            'status':'ALL_EXACT_CHAINED_RUNTIME_EXTENTS_RESOLVE_TO_NAMED_MODEL_PRIMARY_AT_INFERRED_BASE'})
    chains = defaultdict(list)
    for x in chain_rows:
        chains[x['id']].append(x)
    api = [dict(x) for x in db.execute('''SELECT a.start,a.end,s.value name FROM CUPTI_ACTIVITY_KIND_RUNTIME a
        LEFT JOIN StringIds s ON s.id=a.nameId WHERE a.globalTid=?''', (tid,))]
    decode = [r for r in roots if ' kind=decode ' in r['label']]
    nonrecord = [r for r in decode if not any('StreamBeginCapture' in x['name'] and x['start'] < r['end'] and r['start'] < x['end'] for x in api)]
    assert len(decode) == 96 and len(nonrecord) == 90
    root_sets = {'all_decode': decode, 'nonrecording_decode': nonrecord}
    def describe(key, count):
        kind,rva = key
        answer = {'attribution': kind, 'RVA': hex(rva), 'positive_sample_observations': count}
        if kind == 'exact_runtime_or_unwind_chain_MAP_start':
            a,b,u = by_begin[rva]
            aliases = symbols[a]
            answer.update(runtime_begin_end_RVA=[hex(a),hex(b)], alias_count=len(aliases),
                aliases=aliases[:12], aliases_truncated=len(aliases)>12,
                alias_ambiguity=len({x['name'] for x in aliases})>1)
            owned_ranges = [[hex(x),hex(y)] for x,y,u in functions if primary[x] == rva]
            answer.update(primary_and_chained_runtime_extents=owned_ranges[:20],
                owned_runtime_extent_count=len(owned_ranges),owned_runtime_extents_truncated=len(owned_ranges)>20,
                note='Primary entry bounds alone do not enclose chained body regions; ownership follows explicit UNW_FLAG_CHAININFO triples.')
        return answer
    groups = {}
    all_labels = sorted({x['label'] for x in nvtx if not x['label'].startswith('hyle/b2_episode ')})
    for category, selected_roots in root_sets.items():
        seqs = {r['uint64Value'] for r in selected_roots}
        result = {}
        for label in ['ROOT'] + all_labels:
            ranges = [(r['start'],r['end']) for r in selected_roots] if label == 'ROOT' else [
                (r['start'],r['end']) for r in nvtx if r['uint64Value'] in seqs and r['label'] == label]
            selected_samples = [s for s in samples if any(a <= s['start'] < b for a,b in ranges)]
            leaf = Counter()
            inclusive = Counter()
            modules = Counter()
            missing_leaf = 0
            for sample in selected_samples:
                chain = chains[sample['id']]
                if not chain:
                    missing_leaf += 1
                    continue
                first = chain[0]
                assert first['stackDepth'] == 0
                modules[first['module_name']] += 1
                if str(first['module_name']).replace('/', '\\').casefold() == image_key:
                    leaf[frame_owner(first)] += 1
                inclusive.update({frame_owner(x) for x in chain if str(x['module_name']).replace('/', '\\').casefold() == image_key})
            result[label] = {'positive_samples': len(selected_samples), 'no_leaf_chain': missing_leaf,
                'leaf_modules': [{'module': k, 'positive_samples': v} for k,v in modules.most_common()],
                'own_image_leaf_rank': [describe(k,v) for k,v in leaf.most_common(15)],
                'own_image_inclusive_unique_per_sample_rank': [describe(k,v) for k,v in inclusive.most_common(15)]}
        groups[category] = result
    old_position = [x for x in own if 'SmallVector' in str(x['symbol_name']) and 'position_index' in str(x['symbol_name'])]
    old_leaf = [x for x in old_position if x['stackDepth'] == 0]
    correction = Counter(frame_owner(x) for x in old_leaf)
    target_methods = {}
    for name in ('prepare_command_bindings','prepare_invocation_bindings'):
        records = [(rva,e) for rva,e in symbols.items() if any(x['name'].startswith('?' + name + '@') for x in e)]
        target_methods[name] = [{'RVA':hex(a),'PE_runtime_end_RVA':hex(by_begin[a][1]) if a in by_begin else None,
            'MAP_entries': e} for a,e in records]
    output = {'status': 'INFERRED_BASE_AND_EXACT_MAP_RUNTIME_EXTENT_SAMPLE_ATTRIBUTION',
        'identity': {'native_pid': (tid>>24)&0xFFFFFF, 'globalTid': tid, 'image': pin(IMAGE), 'map': pin(MAP), 'source_sqlite': pin(SOURCE)},
        'base_derivation': {'status': 'INFERRED_NOT_DIRECT_MODULE_LOAD_METADATA', 'base': hex(base),
            'method': 'Intersect64KB-aligned bases satisfying each actual sampled IP inside its exact named /Z7 Model method MAP-start PE.pdata extent. No nearest-public-name assumption.',
            'anchor_methods': anchors, 'rejected_name_as_anchors': rejected_anchors,
            'held_out_chained_Model_validation':held_out,
            'distinct_method_constraints': len(anchors),
            'unique_common_candidate': True, 'alignment_assumption': '64KB Windows image allocation granularity; inference, not loaded-module metadata.'},
        'mapping_method': 'Parse public AND Static function records, subtract preferred PE ImageBase for RVA, use non-overlapping x64 PE.pdata half-open extents and explicit UNW_FLAG_CHAININFO RUNTIME_FUNCTION triples to primary entry; require exact MAP symbol at primary BEGIN. Preserve all same-address aliases. Do not fill symbol gaps with previous public name.',
        'coverage': {'MAP_function_rows': dict(map_counts), 'PE_runtime_function_entries':len(functions), 'positive_samples_in_root_window':len(samples), 'own_image_frames_in_root_window':len(own)},
        'specific_static_methods': target_methods,
        'prior_position_index_name_correction': {'old_named_leaf_frame_occurrences_whole_root_window': len(old_leaf),
            'actual_MAP_runtime_owners': [describe(k,v) for k,v in correction.most_common()],
            'scope': 'Whole99root window leaf observations. Nonrecord prepare_replay counts are in groups. This corrects symbol ownership, not CPU milliseconds.'},
        'groups': groups, 'limits': ['Sample counts are observations, never milliseconds, CPUselftime or recoverable overhead. Inclusive per-function counts overlap.',
            'Base is inference anchored by optimized Model source debug. The capture lacks direct loaded-module-base metadata, so inference assumptions remain explicit.',
            'Exact runtime extent and MAP-start identify containing compiled function/address aliases, not exclusive source-line/inlining costs. ICF aliases remain ambiguous.',
            'Nonleaf return addresses are attributed only when IP and IP-1 give the same owner; otherwise explicitly boundary-ambiguous. Leaf sampled instruction pointers are not decremented.',
            'Leaf functions without pdata and unnamed funclets are left unmapped; no nearest-symbol fallback.',
            'CPU-ID discrepancy, driver13.4/collector13.3, legacy CUDA tracing and finite ETW-loss limitations from priorreview still apply.',
            'One retained Hyle capture only; this performs no newpeer/native run and claims no throughput improvement.'],
        'script':pin(Path(__file__)), 'operations': {'builds':0,'profiles':0,'consumer_runs':0,'network':0,'product_edits':0}}
    (W/'map-attribution.json').write_text(json.dumps(output, ensure_ascii=False,indent=2)+'\n',encoding='utf8')
    print(json.dumps({'output':pin(W/'map-attribution.json'), 'base':hex(base), 'anchors':len(anchors),
        'steady_replay':groups['nonrecording_decode']['hyle/prepare_replay']}, ensure_ascii=False,indent=2))


if __name__ == '__main__':
    main()
