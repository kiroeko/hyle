"""Prepare or explicitly build exactly one optimized peer632 NVTX consumer TU."""
from pathlib import Path
import hashlib
import importlib.util
import json
import re
import sys

sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent
R=W.parents[1]
OLD=R/'.scratch/inference-b2-current-attribution-20261026'
P=OLD/'peer2'
B=R/'.scratch/inference-b2-current-window-20261026'


def read(path):return json.loads(Path(path).read_text(encoding='utf-8-sig'))
def save(path,value):Path(path).write_text(json.dumps(value,indent=2,ensure_ascii=False)+'\n',encoding='utf8')
def key(path):return str(path).replace('/','\\').casefold()
def pin(path):
    path=Path(path)
    with path.open('rb') as f:digest=hashlib.file_digest(f,'sha256').hexdigest()
    return dict(path=str(path),bytes=path.stat().st_size,sha256=digest)
def exact(record):assert pin(record['path'])==record,record['path']
def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path)
    mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod);return mod


def logical(path,pins):
    for name in ('source','helper'):
        if key(path) in (key(pins[name]['path']),key(pins['old_'+name]['path'])):return name
    return key(path)


def prepare():
    assert not (W/'build-plan.json').exists()
    old=read(P/'ready.json');recipe=read(P/'build-plan.json')
    sourcepins=read(OLD/'source-pins.json')
    helper=sourcepins['helper']
    for record in (old['source'],old['actual_dependencies'],old['source_pins'],old['runtime'],helper):exact(record)
    assert old['source']['sha256']=='3e76849d9bc4309ef4fff45d22befaac61279268742d4ff246786187816f448c'
    assert helper['sha256']=='85fdaa4efa4f00e49ad193f6a713355007666c101783112a1974840ea6c8521d'
    dependencies=read(old['actual_dependencies']['path'])
    for record in dependencies:exact(record)
    libs=recipe['retained_inputs'];assert len(libs)==8
    original=read(recipe['original_link_recipe']['path'])
    assert libs==original['inputs'][1:],'All8native/SDKlibraries must match actual peer632'
    for record in libs:exact(record)
    (W/'source').mkdir(exist_ok=False)
    (W/'source/peer-batch.cc').write_bytes(Path(old['source']['path']).read_bytes())
    (W/'logical_trace.h').write_bytes(Path(helper['path']).read_bytes())
    pins=dict(source=pin(W/'source/peer-batch.cc'),helper=pin(W/'logical_trace.h'),old_source=old['source'],old_helper=helper,
        old_ready=pin(P/'ready.json'),old_plan=pin(P/'build-plan.json'),old_deps=old['actual_dependencies'],
        old_source_pins=old['source_pins'],source_review=pin(P/'independent-contract-review-architecture.json'),
        baseline632_link_recipe=recipe['original_link_recipe'],peer632_image=read(B/'pins.json')['images']['peer'],
        original_support=sourcepins['peer_exact_support'],source_helper_byte_identical=True,no_math_endpoint_change=True)
    save(W/'source-pins.json',pins)
    compile=[]
    for arg in recipe['compile']:
        if arg==old['source']['path']:arg=str(W/'source/peer-batch.cc')
        elif arg=='/I'+str(OLD):arg='/I'+str(W)
        elif arg==str(P/'compile/dependencies.json'):arg=str(W/'compile/dependencies.json')
        elif arg.startswith('/Fo'):arg='/Fo'+str(W/'compile/unit.obj')
        elif arg.startswith('/Fd'):continue
        compile.append(arg)
    assert '/O2' in compile and '/Ob2' in compile
    assert not any(x.lower() in ('/z7','/zi','/od','/ob0','/gl') for x in compile)
    compile.append('/Z7')
    link=[]
    for arg in recipe['link']:
        if key(arg)==key(P/'compile/unit.obj'):arg=str(W/'compile/unit.obj')
        elif arg.upper().startswith('/OUT:'):arg='/OUT:'+str(W/'link/consumer.exe')
        elif arg.upper().startswith('/PDB:'):arg='/PDB:'+str(W/'link/consumer.pdb')
        elif arg.upper().startswith('/IMPLIB:'):arg='/IMPLIB:'+str(W/'link/consumer.lib')
        link.append(arg)
    assert not any(x.upper().startswith(('/DEBUG','/MAP:')) for x in link)
    link+=['/DEBUG:FULL','/MAP:'+str(W/'link/consumer.map'),'/OPT:REF','/OPT:ICF']
    assert '/INCREMENTAL:NO' in link
    save(W/'build-plan.json',dict(status='PREPARED_NOT_BUILT',compile=compile,link=link,source_pins=pin(W/'source-pins.json'),
        original_recipe=pin(P/'build-plan.json'),baseline_runtime=old['runtime'],retained_libraries=libs,original_dependency_set=old['actual_dependencies'],
        new_host_TUs=1,native_SDK_device_builds=0,model_runs=0,scope='Same reviewed peer632NVTXconsumer source/helper, original /O2 /Ob2 /MD /std:c++17. Add /Z7 and optimized fullPDB/MAP link. Actual8 libraries unchanged, no CPU/GPU placement changes.',
        limitations=['Diagnostic image is not a TPS measurement.','Only consumerTU privatePDB; retainedcore may lack private/source/inlined symbols.','ICF/inlining/publicMAP names are limited attribution evidence.']))
    print('PEER_CPU_BUILD_PREPARED',json.dumps(pin(W/'build-plan.json')),flush=True)


def build():
    assert not (W/'compile').exists() and not (W/'link').exists(),'Preserve original attempts'
    plan=read(W/'build-plan.json')
    for name in ('source_pins','original_recipe','baseline_runtime','original_dependency_set'):exact(plan[name])
    pins=read(plan['source_pins']['path'])
    for name in ('source','helper','old_source','old_helper','old_ready','old_plan','old_deps','old_source_pins','source_review','baseline632_link_recipe','peer632_image'):exact(pins[name])
    before=read(plan['original_dependency_set']['path'])
    for record in before:exact(record)
    for record in plan['retained_libraries']:exact(record)
    h=load('peer_cpu_execute',R/'.scratch/inference-synchronous-step-report-20261025/check_host.py')
    compiler=plan['compile'][0]
    env=h.discover_environment(compiler='msvc',cache={'CMAKE_C_COMPILER':compiler,'CMAKE_CXX_COMPILER':compiler,'CMAKE_GENERATOR':'Ninja'},backends=()).env
    compiled=h.execute(plan['compile'],env,W/'compile',timeout=120)
    dep=read(W/'compile/dependencies.json')['Data']
    actual=[pin(x) for x in dict.fromkeys([dep['Source'],*dep['Includes']])]
    previous={logical(x['path'],pins):x for x in before};now={logical(x['path'],pins):x for x in actual}
    assert set(previous)==set(now),(set(previous)-set(now),set(now)-set(previous))
    drift=[k for k in previous if (previous[k]['bytes'],previous[k]['sha256'])!=(now[k]['bytes'],now[k]['sha256'])]
    assert not drift,drift
    save(W/'compile/actual-dependencies.json',actual)
    save(W/'compile/dependency-contract.json',dict(logical_set_equal=True,source_helper_identical=True,byte_drift=drift,original=len(previous),actual=len(now)))
    obj=pin(W/'compile/unit.obj')
    inputs=[obj,*plan['retained_libraries']]
    save(W/'link-inputs.json',inputs)
    linked=h.execute(plan['link'],env,W/'link',timeout=120)
    for row in inputs:exact(row)
    runtime=read(plan['baseline_runtime']['path']);save(W/'runtime.json',runtime)
    inspected=h.execute([str(Path(compiler).with_name('dumpbin.exe')),'/HEADERS',str(W/'link/consumer.exe')],env,W/'symbol-headers',timeout=30)
    text=(W/'symbol-headers/stdout.log').read_text(errors='replace')
    assert 'RSDS' in text and 'consumer.pdb' in text
    assert (W/'link/consumer.pdb').read_bytes().startswith(b'Microsoft C/C++ MSF 7.00')
    maptext=(W/'link/consumer.map').read_text(errors='replace')
    functions=[line for line in maptext.splitlines() if re.match(r'^\s+[0-9A-Fa-f]{4}:[0-9A-Fa-f]{8,16}\s+\S+\s+[0-9A-Fa-f]{8,16}\s+f\b',line)]
    assert len(functions)>100
    save(W/'symbol-contract.json',dict(status='LOCAL_PDB_MAP_PRESENT_PARTIAL_RESOLUTION_NOT_ASSUMED',inspection=inspected,function_rows=len(functions),pdb=pin(W/'link/consumer.pdb'),map=pin(W/'link/consumer.map'),limits=plan['limitations']))
    save(W/'ready.json',dict(status='PEER_CPU_DIAGNOSTIC_BUILT_NOT_PROFILED',image=pin(W/'link/consumer.exe'),app=obj,source=pins['source'],helper=pins['helper'],source_pins=plan['source_pins'],actual_dependencies=pin(W/'compile/actual-dependencies.json'),runtime=pin(W/'runtime.json'),link_inputs=pin(W/'link-inputs.json'),pdb=pin(W/'link/consumer.pdb'),map=pin(W/'link/consumer.map'),symbol_contract=pin(W/'symbol-contract.json'),compile=compiled,link=linked,unchanged_native_libraries=8,new_host_TUs=1,SDK_native_builds=0,model_runs=0,limits=plan['limitations']))
    print('PEER_CPU_READY',json.dumps(pin(W/'ready.json')),flush=True)


if __name__=='__main__':
    if sys.argv[1:]==['prepare']:prepare()
    elif sys.argv[1:]==['build']:build()
    else:raise SystemExit('Usage: python -B '+str(__file__)+' prepare | build')
