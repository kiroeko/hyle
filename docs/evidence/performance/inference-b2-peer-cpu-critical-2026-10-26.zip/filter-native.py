"""Extract root-critical native records; never copy unrelated system processes."""
from pathlib import Path
import argparse
import hashlib
import json
import sqlite3

W = Path(__file__).resolve().parent
F = W / 'peer/trace1'


def pin(path):
    h=hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(4*1024*1024), b''):
            h.update(block)
    return dict(path=str(path), bytes=path.stat().st_size, sha256=h.hexdigest())


def main():
    p=argparse.ArgumentParser()
    p.add_argument('--sqlite',type=Path,required=True)
    p.add_argument('--output',type=Path,required=True)
    args=p.parse_args()
    assert not args.output.exists()
    c=sqlite3.connect('file:'+args.sqlite.as_posix()+'?mode=ro',uri=True)
    c.row_factory=sqlite3.Row
    roots=json.loads((F/'physical-roots.json').read_text())
    tid=roots[0]['globalTid']; gpid=tid & ~0xFFFFFF
    lo,hi=roots[0]['start_ns'],roots[-1]['end_ns']
    before=c.execute('SELECT MAX(start) FROM SCHED_EVENTS WHERE globalTid=? AND start<=?',(tid,lo)).fetchone()[0]
    after=c.execute('SELECT MIN(start) FROM SCHED_EVENTS WHERE globalTid=? AND start>=?',(tid,hi)).fetchone()[0]
    assert before is not None and after is not None
    schema={x['name']:x['sql'] for x in c.execute("SELECT name,sql FROM sqlite_master WHERE type='table'")}
    keep={
        'NVTX_EVENTS':('(globalTid & -16777216)=?',(gpid,)),
        'SCHED_EVENTS':('globalTid=? AND start>=? AND start<=?',(tid,before,after)),
        'COMPOSITE_EVENTS':('(globalTid & -16777216)=? AND start>=? AND start<?',(gpid,lo,hi)),
        'SAMPLING_CALLCHAINS':('id IN (SELECT id FROM COMPOSITE_EVENTS WHERE (globalTid & -16777216)=? AND start>=? AND start<?)',(gpid,lo,hi)),
        'ThreadNames':('(globalTid & -16777216)=?',(gpid,)),
        'PROCESSES':('globalPid=?',(gpid,)),
    }
    whole=['META_DATA_CAPTURE','META_DATA_EXPORT','DIAGNOSTIC_EVENT','ANALYSIS_DETAILS',
           'TARGET_INFO_SESSION_START_TIME','TARGET_INFO_GPU','TARGET_INFO_CUDA_DEVICE',
           'TARGET_INFO_CUDA_CONTEXT_INFO','TARGET_INFO_CUDA_STREAM']
    whole += [x for x in schema if x.startswith('ENUM_')]
    for table in whole:
        if table in schema:keep[table]=('1',())
    for table in ('CUPTI_ACTIVITY_KIND_RUNTIME','CUPTI_ACTIVITY_KIND_DRIVER','CUDA_GRAPH_EVENTS','PROFILER_OVERHEAD','CUPTI_ACTIVITY_KIND_OVERHEAD'):
        if table in schema:keep[table]=('(globalTid & -16777216)=? AND start<? AND end>?',(gpid,hi,lo))
    for table in ('CUPTI_ACTIVITY_KIND_GRAPH_TRACE','CUPTI_ACTIVITY_KIND_KERNEL',
                  'CUPTI_ACTIVITY_KIND_MEMCPY','CUPTI_ACTIVITY_KIND_MEMSET',
                  'CUPTI_ACTIVITY_KIND_SYNCHRONIZATION'):
        if table in schema:keep[table]=('globalPid=? AND start<? AND end>?',(gpid,hi,lo))
    out=sqlite3.connect(args.output,uri=True)
    out.execute('ATTACH DATABASE ? AS original',('file:'+args.sqlite.resolve().as_posix()+'?mode=ro',))
    manifest=dict(status='ROOT_CRITICAL_NATIVE_ONLY_FILTERED_SOURCE_RECORDS',source=pin(args.sqlite),
        root_globalTid=tid,globalPid=gpid,native_pid=(tid>>24)&0xFFFFFF,
        root_bounds_ns=[lo,hi],sched_boundary_ns=[before,after],tables={},
        excluded='Other processes, ProcessStreams, full-system module/name inventories, unrelated loading/unloading sample ranges',
        limits='Root-thread scheduling with predecessor/successor, all native-process samples/callchains and API/GPU records during the root window. This is not process-total scheduling/CPU usage. Source IDs and scheduling rowids preserved. Full raw files remain local until verified publication.')
    string_ids=set()
    # Only these known StringIds references are present in the selected schema.
    ref_columns={'nameId','textId','jsonTextId','symbol','module','demangledName','shortName','mangledName'}
    for table,(where,params) in keep.items():
        columns=[x[1] for x in c.execute('PRAGMA table_info('+table+')')]
        actual_columns=(['rowid'] if table=='SCHED_EVENTS' else [])+columns
        query='SELECT '+','.join(actual_columns)+' FROM '+table+' WHERE '+where
        out.execute(schema[table])
        selected=','.join(actual_columns)
        source_query='SELECT '+selected+' FROM original.'+table+' WHERE '+where
        out.execute('INSERT INTO '+table+'('+selected+') '+source_query,params)
        count=out.execute('SELECT COUNT(*) FROM '+table).fetchone()[0]
        for index,name in enumerate(actual_columns):
            if name in ref_columns:
                string_ids.update(x[0] for x in out.execute('SELECT DISTINCT '+name+' FROM '+table+' WHERE '+name+' IS NOT NULL'))
        # SQLite-to-SQLite copying also preserves any original malformed locale
        # text bytes. Do not decode/re-encode unrelated metadata in Python.
        assert not out.execute('SELECT '+selected+' FROM '+table+' EXCEPT '+source_query,params).fetchone()
        assert not out.execute(source_query+' EXCEPT SELECT '+selected+' FROM '+table,params).fetchone()
        manifest['tables'][table]=dict(query=query,params=params,rows=count,exact_both_directions_EXCEPT='PASS')
    out.execute(schema['StringIds'])
    for ident in sorted(string_ids):
        out.execute('INSERT INTO StringIds(id,value) SELECT id,value FROM original.StringIds WHERE id=?',(ident,))
    assert out.execute('SELECT COUNT(*) FROM StringIds').fetchone()[0]==len(string_ids)
    original_strings='SELECT id,value FROM original.StringIds WHERE id IN (SELECT id FROM main.StringIds)'
    assert not out.execute('SELECT id,value FROM main.StringIds EXCEPT '+original_strings).fetchone()
    assert not out.execute(original_strings+' EXCEPT SELECT id,value FROM main.StringIds').fetchone()
    manifest['tables']['StringIds']=dict(query='SELECT id,value FROM StringIds WHERE id IN (exact references of retained source records)',rows=len(string_ids),exact_both_directions_EXCEPT='PASS')
    out.commit()
    assert out.execute('PRAGMA integrity_check').fetchone()[0]=='ok'
    out.close();c.close()
    manifest['output']=pin(args.output)
    args.output.with_suffix('.filter.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf8')
    print(json.dumps(dict(source=manifest['source'],output=manifest['output'],table_counts={k:v['rows'] for k,v in manifest['tables'].items()}),indent=2))


if __name__=='__main__':main()
