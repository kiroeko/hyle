"""Resolution coverage counts only; no CPU-time attribution or resampling."""
from pathlib import Path
import hashlib
import json
import sqlite3

W=Path(__file__).resolve().parent
F=W/'peer/trace1'
D=W/'local-symbols2'
native=json.loads((F/'native-process.json').read_text(encoding='utf8'))
quality=json.loads((F/'physical-roots.json').read_text(encoding='utf8'))
root_tid=quality[0]['globalTid']


def counts(path):
    c=sqlite3.connect('file:'+path.as_posix()+'?mode=ro',uri=True)
    c.row_factory=sqlite3.Row
    out={}
    base='((globalTid >> 24) & 0x00FFFFFF) = ?'
    for name,condition,args in (
        ('native_all_events',base,[native['native_pid']]),
        ('native_periodic_positive_cpuCycles',base+' AND cpuCycles > 0',[native['native_pid']]),
        ('root_thread_all_events','globalTid = ?',[root_tid]),
        ('root_thread_periodic_positive_cpuCycles','globalTid = ? AND cpuCycles > 0',[root_tid])):
        events=[dict(x) for x in c.execute('SELECT COUNT(*) events,cpuCycles,threadState FROM COMPOSITE_EVENTS WHERE '+condition+' GROUP BY cpuCycles,threadState',args)]
        selected='SELECT id FROM COMPOSITE_EVENTS WHERE '+condition
        frames=dict(c.execute('SELECT COUNT(*) frames,COALESCE(SUM(unresolved != 0),0) unresolved_frames,COALESCE(SUM(unresolved = 0),0) resolved_frames,COALESCE(SUM(unresolved IS NULL),0) unknown_resolution_frames,COUNT(DISTINCT id) events_with_frames FROM SAMPLING_CALLCHAINS WHERE id IN ('+selected+')',args).fetchone())
        leaves=dict(c.execute('SELECT COUNT(*) leaf_frames,COALESCE(SUM(unresolved != 0),0) unresolved_leaf_frames,COALESCE(SUM(unresolved = 0),0) resolved_leaf_frames,COALESCE(SUM(unresolved IS NULL),0) unknown_resolution_leaf_frames FROM SAMPLING_CALLCHAINS WHERE stackDepth = 0 AND id IN ('+selected+')',args).fetchone())
        out[name]=dict(events_by_raw_state_and_weight=events,**frames,**leaves)
    out['table_counts']={name:c.execute('SELECT COUNT(*) FROM '+name).fetchone()[0] for name in ('COMPOSITE_EVENTS','SAMPLING_CALLCHAINS','SCHED_EVENTS','NVTX_EVENTS')}
    c.close()
    return out


result=dict(status='LOCAL_ONLY_RESOLUTION_COVERAGE_COUNTS',native_pid=native['native_pid'],root_global_tid=root_tid,
    raw=counts(F/'trace.sqlite'),resolved=counts(F/'trace-local-resolved.sqlite'),
    interpretation='Frame counts are coverage, not CPU time. cpuCycles=0 state samples kept separate from positive-weight periodic samples. All frames in one sample may contain multiple unresolved entries; frame and leaf fractions must not be substituted for time fractions.',
    servers=[],model_runs=0,profile_runs=0)
result['preserved_counts']={key:result['raw']['table_counts'][key]==result['resolved']['table_counts'][key] for key in result['raw']['table_counts']}
(D/'counts.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8')
print(json.dumps(result,indent=2))
