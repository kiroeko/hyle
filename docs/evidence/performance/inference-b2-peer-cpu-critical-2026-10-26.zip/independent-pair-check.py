"""Finite second implementation of common-root CPU/GPU/API interval accounting."""
from pathlib import Path
from collections import defaultdict
import json
import sqlite3

W=Path(__file__).resolve().parent
R=W.parents[1]
H=R/'.scratch/inference-b2-cpu-critical-20261026'


def read(path):return json.loads(path.read_text())


def fetch(c,query,args=()):return [dict(x) for x in c.execute(query,args)]


def intervals_metric(lo,hi,running,gpu,api):
    # Independent endpoint sweep, rather than clip/intersection/union helpers.
    changes=defaultdict(lambda:[0,0,0])
    changes[lo];changes[hi]
    for category,spans in enumerate((running,gpu,api)):
        for a,b in spans:
            a,b=max(a,lo),min(b,hi)
            if a<b:changes[a][category]+=1;changes[b][category]-=1
    active=[0,0,0];previous=lo;totals=[0,0,0,0]
    for at,delta in sorted(changes.items()):
        elapsed=at-previous
        if active[0]:totals[0]+=elapsed
        if active[1]:totals[1]+=elapsed
        if active[2]:totals[2]+=elapsed
        if active[0] and not active[1] and not active[2]:totals[3]+=elapsed
        active=[a+b for a,b in zip(active,delta)];previous=at
    assert active==[0,0,0]
    return dict(wall_ns=hi-lo,running_ns=totals[0],observed_gpu_union_ns=totals[1],
        cuda_api_union_ns=totals[2],running_outside_gpu_and_cuda_api_ns=totals[3])


data={}
for arm,folder,db in [('hyle',H/'hyle/trace1',H/'hyle/trace1/native-scope-resolved.sqlite'),
                      ('peer',W/'peer/trace1',W/'peer/trace1/native-scope-resolved.sqlite')]:
    c=sqlite3.connect('file:'+db.as_posix()+'?mode=ro',uri=True);c.row_factory=sqlite3.Row
    events=fetch(c,'''SELECT n.*,COALESCE(n.text,s.value) label FROM NVTX_EVENTS n
        LEFT JOIN StringIds s ON s.id=n.textId WHERE COALESCE(n.text,s.value) LIKE ?
        ORDER BY n.start''',(arm+'/%',))
    roots=[x for x in events if x['label'].startswith(arm+'/b2_episode ')]
    tid=roots[0]['globalTid'];gpid=tid & ~0xFFFFFF
    process=read(folder/'native-process.json')
    assert ((tid>>24)&0xFFFFFF)==process['native_pid'] and process['exit']==0
    physical=read(folder/'physical-roots.json')
    assert len(roots)==99 and [(x['uint64Value'],x['start'],x['end']) for x in roots]==[
        (x['meta']['seq'],x['start_ns'],x['end_ns']) for x in physical]
    meta={x['meta']['seq']:x['meta'] for x in physical}
    api=fetch(c,'''SELECT x.*,s.value api FROM CUPTI_ACTIVITY_KIND_RUNTIME x
        JOIN StringIds s ON s.id=x.nameId WHERE x.globalTid=? ORDER BY x.start''',(tid,))
    # Both actual exports contain runtime rows for cu* as well as cuda* calls.
    assert not c.execute("SELECT name FROM sqlite_master WHERE name='CUPTI_ACTIVITY_KIND_DRIVER'").fetchone()
    sched=fetch(c,'''WITH ordered AS (SELECT rowid,start,cpu,isSchedIn,
        LEAD(start) OVER(ORDER BY start,rowid) next_start,
        LEAD(cpu) OVER(ORDER BY start,rowid) next_cpu,
        LEAD(isSchedIn) OVER(ORDER BY start,rowid) next_in
        FROM SCHED_EVENTS WHERE globalTid=?) SELECT * FROM ordered ORDER BY start,rowid''',(tid,))
    running=[(x['start'],x['next_start']) for x in sched if x['isSchedIn'] and x['next_start'] is not None
             and not x['next_in'] and x['cpu']==x['next_cpu']]
    assert not [x for x in sched if x['isSchedIn'] and x['next_start'] is not None
                and (x['next_in'] or x['cpu']!=x['next_cpu'])]
    gpu=[];graphs=[]
    for table in ('CUPTI_ACTIVITY_KIND_GRAPH_TRACE','CUPTI_ACTIVITY_KIND_KERNEL','CUPTI_ACTIVITY_KIND_MEMCPY','CUPTI_ACTIVITY_KIND_MEMSET'):
        entries=fetch(c,'SELECT * FROM '+table+' WHERE globalPid=? ORDER BY start',(gpid,))
        gpu.extend((x['start'],x['end']) for x in entries)
        if table=='CUPTI_ACTIVITY_KIND_GRAPH_TRACE':graphs=entries
    by_seq={}
    for root in roots:
        seq=root['uint64Value'];a,b=root['start'],root['end']
        calls=[x for x in api if x['start']<b and a<x['end']]
        record=any('StreamBeginCapture' in x['api'] for x in calls)
        gg=[x for x in graphs if x['start']<b and a<x['end']]
        correlations=[]
        for graph in gg:
            launches=[x for x in calls if 'GraphLaunch' in x['api'] and x['correlationId']==graph['correlationId']]
            assert len(launches)==1
            launch=launches[0]
            assert a<=launch['start']<=graph['start']<=graph['end']<=b
            correlations.append(dict(correlationId=graph['correlationId'],graphId=graph['graphId'],
                graphExecId=graph['graphExecId'],contextId=graph['contextId'],streamId=graph['streamId'],
                launch_start=launch['start'],launch_end=launch['end'],graph_start=graph['start'],graph_end=graph['end']))
        scope=[dict(root,label='ROOT')]+[x for x in events if x['uint64Value']==seq and x['label']!=root['label']]
        metrics={x['label']:intervals_metric(x['start'],x['end'],running,gpu,[(z['start'],z['end']) for z in calls]) for x in scope}
        by_seq[seq]=dict(meta=meta[seq],record=record,metrics=metrics,graph_correlations=correlations)
    data[arm]=by_seq;c.close()
assert [x['meta'] for x in data['hyle'].values()]==[x['meta'] for x in data['peer'].values()]
common=[seq for seq,h in data['hyle'].items() if h['meta']['kind']=='decode'
        and not h['record'] and not data['peer'][seq]['record']]
pair=read(W/'paired-cpu-facts.json')
assert common==pair['groups']['both_nonrecording_decode']['sequences'] and len(common)==90
proof={}
for arm in data:
    proof[arm]={}
    for label in data[arm][common[0]]['metrics']:
        proof[arm][label]={key:sum(data[arm][seq]['metrics'][label][key] for seq in common)
                          for key in data[arm][common[0]]['metrics'][label]}
        expected=pair['both_nonrecording_90_root_phase_metrics'][arm][label]
        assert all(expected[k]==v for k,v in proof[arm][label].items()),(arm,label)
    assert all(len(data[arm][seq]['graph_correlations'])==1 for seq in common)
facts=dict(status='INDEPENDENT_ENDPOINT_SWEEP_EXACT_COMMON90_PHASE_METRICS_AND_GRAPH_CORRELATIONS_PASS',
    common90_sequences=common,common90_phase_metrics=proof,
    graph_correlations={arm:{str(seq):data[arm][seq]['graph_correlations'] for seq in common} for arm in data},
    limits=['Graphlaunch correlation and root bounds validated from actual nativeGPU/APIrows; graphenvelope isnotkernelbusytime.',
            'Original17Hyle/4peer phase labels retained; noequivalenceclaim betweenindividual wrapperphases.',
            'This independentcheck doesnotremove CPU-IDsampleuncertainty, NVTXinstrumentationdifferences, sparse-symbolbound limits or single-run noise.'])
(W/'independent-pair-check.json').write_text(json.dumps(facts,indent=2)+'\n')
print('PASS exact90commonroots, nativeIDs, phaseCPU/GPU/APIendpoint-sweep,180graphlaunchcorrelations and bounds')
