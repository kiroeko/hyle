"""Metadata/source preparation only; no compiler, model, profiler or network."""
from pathlib import Path
import difflib
import hashlib
import json
import sys

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = W.parents[1]
OLD = R / '.scratch/inference-b2-current-attribution-20261026'
B = R / '.scratch/inference-b2-current-window-20261026'
BASE = R / '.scratch/inference-result-publication-screen-20261026/candidate'


def read(p):
    return json.loads(Path(p).read_text(encoding='utf-8-sig'))


def save(p, x):
    Path(p).write_bytes((json.dumps(x, indent=2, ensure_ascii=False)+'\n').encode('utf8'))


def pin(p):
    p = Path(p)
    data = p.read_bytes()
    return dict(path=str(p), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())


def exact(p):
    assert pin(p['path']) == p, p['path']


PREP = ['hyle/prep/setup_inputs', 'hyle/prep/snapshot_layout_reframe', 'hyle/prep/state_bindings',
        'hyle/prep/batch_prepare', 'hyle/prepare_replay', 'hyle/prep/replay_report']
POST = ['hyle/post/readback_select', 'hyle/post/gdn_state_retain', 'hyle/post/page_frame_export',
        'hyle/post/ledger_tails', 'hyle/post/unbind', 'hyle/post/head_publish_detach']


def prepare():
    source = W/'source/engine/models/qwen35/main.cc'
    assert not source.exists(), 'Preserve frozen preparation'
    before = OLD/'hyle/source/engine/models/qwen35/main.cc'
    raw = before.read_bytes()
    assert hashlib.sha256(raw).hexdigest() == '9a3ef991bac33035f386d112e8854d9ac6bc0a6ac340a57b522edae24e43cac2'
    assert pin(R/'engine/models/qwen35/main.cc')['sha256'] == 'dfaa530b2148a31d3834f0b62c4f123d5fc6983be9f37652395269db2b69dfc6'
    nl = b'\r\n' if b'\r\n' in raw else b'\n'
    data = raw
    insertions = []

    def insert(anchor, lines, after=False):
        nonlocal data
        a = anchor.replace('\n', nl.decode()).encode()
        extra = (lines.replace('\n', nl.decode())+nl.decode()).encode()
        assert data.count(a) == 1, anchor
        data = data.replace(a, a+extra if after else extra+a, 1)
        insertions.append((a, extra, after))

    def switch(var, label, indent='      '):
        return indent+var+'.finish();\n'+indent+var+'.start("'+label+'", logical_trace::sequence);'

    insert('    auto candidate = std::make_unique<StepState>(); candidate->configure(draft_bank + 2);',
           '    logical_trace::Range trace_prepare_part("'+PREP[0]+'", logical_trace::sequence);')
    insert('      hyle::container::SmallVector<std::int32_t, 2> query_indptr{0}, old_indptr{0}, new_indptr{0}, old_last, new_last;',switch('trace_prepare_part',PREP[1]))
    insert('      if (has_mtp(role)) prepare_draft_append(step, role);\n',switch('trace_prepare_part',PREP[2]),after=True)
    insert('      check(g::batch::prepare(run, queues, layouts, {.host_workspace = execution.staging()}));',switch('trace_prepare_part',PREP[3]))
    insert('      {\n        logical_trace::Range trace_replay("hyle/prepare_replay", logical_trace::sequence);','      trace_prepare_part.finish();')
    insert('      const auto replay_end = Clock::now();\n','      trace_prepare_part.start("'+PREP[5]+'", logical_trace::sequence);',after=True)
    insert('    logical_trace::Range trace_postwait;\n','    logical_trace::Range trace_postwait_part;',after=True)
    insert('      trace_postwait.start("hyle/postwait_publish", logical_trace::sequence);\n','      trace_postwait_part.start("'+POST[0]+'", logical_trace::sequence);',after=True)
    insert('      // Export every participant\'s ordinary outputs before taking ANY append:',switch('trace_postwait_part',POST[1]))
    insert('      for (std::size_t layer = 0; layer < page_inventory.keys.size(); ++layer) {\n        for (const auto bank : {layer * 2, layer * 2 + 1}) {',switch('trace_postwait_part',POST[2]))
    insert('      // Caller-supplied completion is confined to this unpublished episode.',switch('trace_postwait_part',POST[3]))
    insert('      check(run.unbind(phase.state_resource_ports));',switch('trace_postwait_part',POST[4]))
    insert('      for (const auto &member : step.members)\n        if (member.session->head != member.base || member.session->pending != &step || member.session->stopping)',switch('trace_postwait_part',POST[5]))
    insert('    trace_postwait.finish(); trace_finish.finish(); logical_trace::episode.finish();','    trace_postwait_part.finish();')
    # Exact byte-level deletion of only inserted instrumentation recovers the
    # already-profiled B2 source. No original line, clock or statement changed.
    recovered = data
    for anchor, extra, after in reversed(insertions):
        combined = anchor+extra if after else extra+anchor
        assert recovered.count(combined) == 1
        recovered = recovered.replace(combined,anchor,1)
    assert recovered == raw
    source.parent.mkdir(parents=True)
    source.write_bytes(data)
    helper = W/'logical_trace.h'
    helper.write_bytes((OLD/'logical_trace.h').read_bytes())
    assert pin(helper)['sha256'] == '85fdaa4efa4f00e49ad193f6a713355007666c101783112a1974840ea6c8521d'
    patch=''.join(difflib.unified_diff(raw.decode().splitlines(keepends=True),data.decode().splitlines(keepends=True),
          fromfile='a/engine/models/qwen35/main.cc',tofile='b/engine/models/qwen35/main.cc'))
    (W/'source.patch').write_bytes(patch.encode())
    olddeps=read(OLD/'hyle/compile/actual-dependencies.json')
    for row in olddeps:
        exact(row)
    ready=read(BASE/'ready.json')
    for field in ('image','link_inputs','runtime'):
        exact(ready[field])
    save(W/'source-pins.json',dict(before=pin(before),canonical_model=pin(R/'engine/models/qwen35/main.cc'),
        after=pin(source),helper=pin(helper),patch=pin(W/'source.patch'),
        inserted_lines_only=True,original_bytes_recovered_by_removing_insertions=True,
        baseline_ready=pin(BASE/'ready.json'),baseline_image=ready['image'],
        baseline_actual_dependencies=pin(OLD/'hyle/compile/actual-dependencies.json'),baseline_dependency_drift=0))
    oldplan=read(OLD/'plan.json')
    record=next(x for x in oldplan['commands'] if x['arm']=='hyle')
    original_consumer=record['consumer'][0]
    record['consumer']=[ready['image']['path'],*record['consumer'][1:]]
    record['profile']=[ready['image']['path'] if x==original_consumer else
        '--output='+str(W/'hyle/trace1/trace') if x.startswith('--output=') else x for x in record['profile']]
    record['reference']=pin(R/'.scratch/inference-result-publication-screen-20261026/runs/timing-02-candidate/complete-nontime-report.json')
    labels=oldplan['root_contract']['hyle_phase_labels']
    contract=dict(oldplan['root_contract'],hyle_phase_labels=labels+[x for x in PREP+POST if x not in labels],
        prepare_children=PREP,postwait_children=POST,completed_ranges=1782,
        siblings_disjoint=True,partitions_cover_only_original_prepare_and_postwait=True)
    save(W/'plan.json',dict(status='FROZEN_SOURCE_NOT_BUILT_OR_RUN',tool=oldplan['tool'],
        source_pins=pin(W/'source-pins.json'),expected_work=oldplan['expected_work'],work_gate_source=oldplan['work_gate_source'],
        baseline_ready=pin(BASE/'ready.json'),commands=[record],root_contract=contract,
        build_scope='Exactly one Model host TU, baseline f36bda resources flag retained; all other link inputs identical. No SDK/Graph/provider/native/kernel rebuild.',
        bucket_scope=dict(prepare='setup_inputs starts with original StepState preparation, after original prepare parent begins. Earlier raw argument validation/exact-shape admission is outside this parent and remains root-exclusive.',
            state_retain='One interval for all GDN outputs plus existing conditional carry/hidden/probe exports; no per-layer/port tracing.',
            replay_report='Original replay report/count and prepared bookkeeping after prepare_replay.',
            endpoints='Original Clock statements, wait, exports, unbind, head swaps, detach and report order unchanged. Successful buckets are disjoint within their original parents; small instrumentation gaps remain explicit.',
            failures='RAII closes active buckets on exceptions. Original catch abort is unchanged; error-path bucket time may include abort cleanup and is not a successful-stage sample.'),
        no_extra_peer_or_behavior=True,profiler_duration_seconds=60,watchdog_seconds=120,
        interpretation='Instrumented same-run attribution only; not TPS or proof of recoverable host cost.'))
    print(json.dumps(dict(source=pin(source),helper=pin(helper),patch=pin(W/'source.patch'),plan=pin(W/'plan.json')),indent=2))


if __name__=='__main__':
    prepare()
