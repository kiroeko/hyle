"""Only retained SQLite/stdout analysis. No model/build/profiler invocation."""
from pathlib import Path
from collections import Counter, defaultdict
import importlib.util
import json
import re
import sqlite3
import sys

sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent
R=W.parents[1]


def load(name,path):
    s=importlib.util.spec_from_file_location(name,path)
    m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m


p=load('host_phase_metadata',W/'prepare.py')
a=load('frozen_interval_primitives',p.OLD/'analyze.py')
gate=load('original_B2_report_gate',p.B/'run.py')
runner=load('host_phase_scope_checks',W/'run.py')


def complete_prefix(text):
    decoder=json.JSONDecoder();pos=0;out={}
    assert text.startswith('{');pos=1
    while True:
        while pos<len(text) and text[pos].isspace():pos+=1
        if pos>=len(text):return out,dict(kind='end_of_stream',offset=pos)
        if text[pos]=='}':return out,None
        key,pos=decoder.raw_decode(text,pos)
        while text[pos].isspace():pos+=1
        assert text[pos]==':';pos+=1
        while pos<len(text) and text[pos].isspace():pos+=1
        try:value,end=decoder.raw_decode(text,pos)
        except json.JSONDecodeError as error:return out,dict(field=key,error=str(error),offset=error.pos)
        out[key]=value;pos=end
        while pos<len(text) and text[pos].isspace():pos+=1
        if pos>=len(text):return out,dict(kind='end_of_stream',offset=pos)
        if text[pos]=='}':return out,None
        assert text[pos]==',';pos+=1


def main():
    F=W/'hyle/trace1'
    plan=p.read(W/'plan.json')
    c=sqlite3.connect('file:'+(F/'trace.sqlite').as_posix()+'?mode=ro',uri=True);c.row_factory=sqlite3.Row
    tables={x[0] for x in c.execute("SELECT name FROM sqlite_master WHERE type='table'")}
    streams=[dict(x) for x in c.execute('SELECT p.rowid,p.globalPid,f.value filename,c.value content FROM ProcessStreams p JOIN StringIds f ON f.id=p.filenameId JOIN StringIds c ON c.id=p.contentId ORDER BY p.rowid')]
    native={kind:[x for x in streams if kind+'_' in x['filename']] for kind in ('stdout','stderr')}
    # This trace has one row per native stream, not multiple overwritten chunks.
    assert len(native['stdout'])==len(native['stderr'])==1
    for kind in native:
        original=F/('native-'+kind+'.log')
        backup=F/('native-'+kind+'.log.original-extraction')
        if not backup.exists():backup.write_bytes(original.read_bytes())
        assert original.read_text(encoding='utf8')==native[kind][0]['content']
    text=native['stdout'][0]['content'];prefix,truncated=complete_prefix(text)
    try:json.loads(text);parse_error=None
    except json.JSONDecodeError as error:parse_error=str(error)
    normalized=gate.normalize(prefix,[])
    reference=p.read(plan['commands'][0]['reference']['path'])
    prefix_differences=gate.differences({k:reference.get(k) for k in normalized},normalized)
    stream_review=dict(status='COLLECTED_STREAM_INCOMPLETE_NOT_MULTIROW_OVERWRITE',
        ProcessStreams_schema=[dict(x) for x in c.execute('PRAGMA table_info(ProcessStreams)')],
        rows=[dict(rowid=x['rowid'],globalPid=x['globalPid'],filename=x['filename'],characters=len(x['content'])) for x in streams],
        full_stdout_JSON_error=parse_error,last_incomplete_field=truncated,
        completed_prefix_fields=len(prefix),complete_prefix_keys=list(prefix),
        complete_prefix_non_time_differences=prefix_differences,
        recoverable_work={k:prefix.get(k) for k in ('source_id','backend','sampling','processed_tokens','generated_tokens','actual_graph_calls','actual_graph_tokens','active_sequences','session_count','max_batch_requests')},
        complete_physical_batch_records=len(prefix.get('batches',[])),
        unavailable=['Complete waves/sessions and all198 output IDs','Terminal LOGICAL_NVTX stderr marker'],
        original_extraction_preserved=True,new_model_or_build_or_profile=False,
        boundary='No row concatenation can supply absent bytes. Original temporary stream files no longer exist. Local export help had no explicit full-stdio recovery option; investigation stopped without another export/profile.')
    p.save(W/'stream-extraction-review.json',stream_review)
    nvtx=[dict(x) for x in c.execute('SELECT n.*,COALESCE(n.text,s.value) label FROM NVTX_EVENTS n LEFT JOIN StringIds s ON s.id=n.textId ORDER BY n.start')]
    nvtx=[x for x in nvtx if x['label']]
    roots=[x for x in nvtx if x['label'].startswith('hyle/b2_episode ')]
    labels=plan['root_contract']['hyle_phase_labels']
    phases=[x for x in nvtx if x['label'] in labels]
    assert len(roots)==99 and all(x['end'] is not None for x in roots+phases)
    expected=p.read(plan['expected_work']['path']);expected_meta=[];context=0
    for phase,tape in enumerate(expected['tapes']):
        for rows in ([tape['rows']] if tape['kind']=='prompt' else [1]*tape['rows']):
            expected_meta.append(dict(kind='prefill' if tape['kind']=='prompt' else 'decode',T=rows,p0=phase,p1=phase,c0=context,c1=context));context+=rows
    physical=[]
    for i,(root,e) in enumerate(zip(roots,expected_meta)):
        meta={k:int(v) for k,v in re.findall(r'(\w+)=(\d+)',root['label'])};meta['kind']=re.search(r'kind=(\w+)',root['label'])[1]
        assert meta==dict(seq=i+1,index=i,R=2,m0=0,m1=1,**e) and root['uint64Value']==i+1
        inner=[x for x in phases if x['uint64Value']==i+1]
        assert Counter(x['label'] for x in inner)==Counter(labels)
        assert all(x['globalTid']==root['globalTid'] and root['start']<=x['start']<=x['end']<=root['end'] for x in inner)
        if i:assert roots[i-1]['end']<=root['start']
        physical.append(dict(label=root['label'],meta=meta,start_ns=root['start'],end_ns=root['end'],globalTid=root['globalTid']))
    buckets=runner.verify_host_buckets(nvtx,roots,plan)
    closed_hyle=[x for x in nvtx if x['label'].startswith('hyle/') and x['end'] is not None]
    assert len(closed_hyle)==1782
    api=[]
    for table in ('CUPTI_ACTIVITY_KIND_RUNTIME','CUPTI_ACTIVITY_KIND_DRIVER'):
        if table in tables:api += [dict(x) for x in c.execute('SELECT x.*,s.value api FROM '+table+' x JOIN StringIds s ON s.id=x.nameId ORDER BY x.start')]
    gpu=[]
    for table in ('CUPTI_ACTIVITY_KIND_KERNEL','CUPTI_ACTIVITY_KIND_MEMCPY','CUPTI_ACTIVITY_KIND_MEMSET'):
        if table in tables:gpu += [dict(x) for x in c.execute('SELECT * FROM '+table+' ORDER BY start')]
    diagnostic=Counter(x[0] for x in c.execute('SELECT text FROM DIAGNOSTIC_EVENT'))
    c.close()
    rows=[]
    for physical_row,root in zip(physical,roots):
        lo,hi,tid=root['start'],root['end'],root['globalTid']
        rg=[x for x in a.overlaps(gpu,lo,hi) if x['globalPid']==(tid&~((1<<24)-1))]
        assert all(lo<=x['start'] and x['end']<=hi for x in rg)
        ra=[x for x in a.overlaps(api,lo,hi) if x['globalTid']==tid]
        library=[x for x in nvtx if x['globalTid']==tid and x['end'] is not None and x['label'].lower().startswith('cublas') and x['start']<hi and lo<x['end']]
        metrics={x['label']:a.metric([(x['start'],x['end'])],rg,ra+library) for x in phases if x['uint64Value']==physical_row['meta']['seq']}
        rows.append(dict(meta=physical_row['meta'],record=any('StreamBeginCapture' in x['api'] for x in ra),root=a.metric([(lo,hi)],rg,ra+library),phases=metrics))
    def totals(selected):
        return dict(roots=len(selected),root=a.add_metrics([x['root'] for x in selected]),
            phases={label:a.add_metrics([x['phases'][label] for x in selected]) for label in labels})
    decode=[x for x in rows if x['meta']['kind']=='decode']
    facts=dict(status='PHASE_INTERVAL_FACTS_WITH_INCOMPLETE_STDIO_WORK_GATE',units='integer nanoseconds',
        decode=totals(decode),prefill=totals([x for x in rows if x['meta']['kind']=='prefill']),
        decode_record=totals([x for x in decode if x['record']]),decode_nonrecord=totals([x for x in decode if not x['record']]),
        API_tables_present=sorted(x for x in tables if x in ('CUPTI_ACTIVITY_KIND_RUNTIME','CUPTI_ACTIVITY_KIND_DRIVER')),
        diagnostic_counts=dict(diagnostic),rows=rows)
    p.save(W/'facts.json',facts);p.save(F/'physical-roots.json',physical)
    quality=dict(status='PARTIAL_TRACE_SCOPE_VALID_FULL_REPORT_GATE_NOT_COMPLETED',
        profile_process=p.read(F/'process.json'),physical_roots=99,prefill=3,decode=96,R=2,rows=1728,
        full_non_time_report_comparison='NOT_COMPLETED_STDOUT_TRUNCATED',all198_output_ID_comparison='UNAVAILABLE',
        stdout_complete_prefix_non_time_differences=prefix_differences,
        actual_completed_Hyle_NVTX_ranges=1782,expected_ranges=1782,terminal_stderr_marker='UNAVAILABLE_STDERR_TRUNCATED',
        phase_counts=dict(Counter(x['label'] for x in phases)),host_bucket_check=buckets,
        model_failure_claim=False,new_runs_or_rebuilds=0)
    p.save(F/'quality.json',quality)
    def ms(metrics):return {k[:-3]+'_ms':v/1e6 for k,v in metrics.items()}
    summary=dict(status=facts['status'],quality='hyle/trace1/quality.json',stdio_review='stream-extraction-review.json',
        decode_roots=96,decode_root=ms(facts['decode']['root']),
        decode_twelve_disjoint_children={k:ms(facts['decode']['phases'][k]) for k in p.PREP+p.POST},
        decode_inclusive_parents_do_not_add={k:ms(facts['decode']['phases'][k]) for k in ('hyle/prepare','hyle/postwait_publish')},
        recording_decode_roots=facts['decode_record']['roots'],nonrecording_decode_roots=facts['decode_nonrecord']['roots'],
        limits=['No new profile/model/build; only the sole existing trace is read.',
            'Complete output/IDs work gate is unavailable because original captured streams are truncated; this is not a model-failure claim.',
            'GPU activity/API/library are interval unions clipped to each scope, never nested duration sums.',
            'Wall outside observed GPU/API is not proved pure CPU or recoverable cost. Profiling/NVTX overhead remains.',
            'Do not subtract previous trace phase clocks or infer speed gain; parents are inclusive of these children.'])
    p.save(W/'summary.json',summary)
    print(json.dumps(summary,indent=2))


if __name__=='__main__':main()
