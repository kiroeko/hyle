"""Independent, read-only wall totals; does not assert the truncated work gate."""
from pathlib import Path
import json
import sqlite3

W = Path(__file__).resolve().parent
db = W / 'hyle/trace1/trace.sqlite'
connection = sqlite3.connect('file:' + db.as_posix() + '?mode=ro', uri=True)
rows = connection.execute('''
WITH events AS (
  SELECT n.start, n.end, n.uint64Value,
         COALESCE(n.text, s.value) AS label
  FROM NVTX_EVENTS n LEFT JOIN StringIds s ON s.id = n.textId
  WHERE n.end IS NOT NULL
), decode AS (
  SELECT uint64Value FROM events
  WHERE label LIKE 'hyle/b2_episode %kind=decode%'
)
SELECT label, COUNT(*), SUM(end-start)
FROM events WHERE uint64Value IN (SELECT uint64Value FROM decode)
GROUP BY label ORDER BY SUM(end-start) DESC
''').fetchall()
connection.close()
facts = [dict(label=label, count=count, wall_ns=ns, wall_ms=ns/1e6)
         for label, count, ns in rows]
(W / 'independent-phase-wall.json').write_text(json.dumps(facts, indent=2) + '\n', encoding='utf8')
for row in facts:
    if not row['label'].startswith('hyle/b2_episode '):
        print(f"{row['label']}: {row['count']} calls, {row['wall_ms']:.6f} ms")
