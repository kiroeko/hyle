"""Root-only explicit build: one Model host TU and one retained f36 link."""
from pathlib import Path
import importlib.util
import os
import sys

sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent


def load(name,path):
    s=importlib.util.spec_from_file_location(name,path)
    m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m


m=load('host_phase_preparation',W/'prepare.py')
h=load('retained_execute',m.R/'.scratch/inference-synchronous-step-report-20261025/check_host.py')


def key(p):
    # Captured source/object paths are already absolute. Do not interpret link
    # options such as /OUT: as filesystem paths while matching the old object.
    return str(p).replace('/','\\').casefold()


def plan():
    assert not (W/'build-plan.json').exists(), 'Do not replace a frozen command plan'
    old=m.read(m.OLD/'hyle/build-plan.json')
    pins=m.read(W/'source-pins.json')
    ready=m.read(m.BASE/'ready.json')
    for x in (pins['before'],pins['after'],pins['helper'],pins['baseline_ready'],ready['link_inputs']):
        m.exact(x)
    command=[]
    for x in old['compile']:
        if x==pins['before']['path']:x=pins['after']['path']
        elif x=='/I'+str(m.OLD):x='/I'+str(W)
        elif x==str(m.OLD/'hyle/compile/dependencies.json'):x=str(W/'compile/dependencies.json')
        elif x.startswith('/Fo'):x='/Fo'+str(W/'compile/unit.obj')
        command.append(x)
    assert command.count(pins['after']['path'])==1 and '/I'+str(W) in command
    inputs=m.read(ready['link_inputs']['path'])
    before=old['baseline_object']
    assert sum(key(x['path'])==key(before['path']) for x in inputs)==1
    link=[]
    for x in m.read(m.BASE/'link/command.json')['command']:
        if key(x)==key(before['path']):x=str(W/'compile/unit.obj')
        elif x.upper().startswith('/OUT:'):x='/OUT:'+str(W/'link/consumer.exe')
        elif x.upper().startswith('/PDB:'):x='/PDB:'+str(W/'link/consumer.pdb')
        elif x.upper().startswith('/IMPLIB:'):x='/IMPLIB:'+str(W/'link/consumer.lib')
        link.append(x)
    assert link.count(str(W/'compile/unit.obj'))==1
    m.save(W/'build-plan.json',dict(compile=command,link=link,source_pins=m.pin(W/'source-pins.json'),
        baseline_ready=m.pin(m.BASE/'ready.json'),baseline_link_inputs=ready['link_inputs'],
        old_actual_dependencies=m.pin(m.OLD/'hyle/compile/actual-dependencies.json'),
        replaced=before,retained_inputs=len(inputs)-1,new_host_TUs=1,SDK_Graph_native_device_builds=0))
    print('HOST_PHASE_BUILD_PLAN',m.pin(W/'build-plan.json'),flush=True)


def build():
    assert not (W/'compile').exists() and not (W/'link').exists(), 'Preserve failed attempts; no automatic retry'
    p=m.read(W/'build-plan.json');m.exact(p['source_pins']);m.exact(p['baseline_ready']);m.exact(p['baseline_link_inputs']);m.exact(p['old_actual_dependencies'])
    pins=m.read(p['source_pins']['path'])
    for field in ('before','after','helper','patch','canonical_model'):m.exact(pins[field])
    before_deps=m.read(p['old_actual_dependencies']['path'])
    for x in before_deps:m.exact(x)
    inputs=m.read(p['baseline_link_inputs']['path'])
    for x in inputs:m.exact(x)
    compiler=p['compile'][0]
    env=h.discover_environment(compiler='msvc',cache={'CMAKE_C_COMPILER':compiler,'CMAKE_CXX_COMPILER':compiler,'CMAKE_GENERATOR':'Ninja'},backends=()).env
    compiled=h.execute(p['compile'],env,W/'compile',timeout=120)
    dep=m.read(W/'compile/dependencies.json')['Data']
    actual=[m.pin(x) for x in dict.fromkeys([dep['Source'],*dep['Includes']])]
    def logical(path):
        if key(path) in (key(pins['before']['path']),key(pins['after']['path'])):return 'MODEL_SOURCE'
        if key(path) in (key(m.OLD/'logical_trace.h'),key(W/'logical_trace.h')):return 'PRIVATE_NVTX_HELPER'
        return key(path)
    old={logical(x['path']):x for x in before_deps};new={logical(x['path']):x for x in actual}
    assert set(old)==set(new),(set(old)-set(new),set(new)-set(old))
    changed=[k for k in old if (old[k]['bytes'],old[k]['sha256'])!=(new[k]['bytes'],new[k]['sha256'])]
    assert changed==['MODEL_SOURCE'],changed
    m.save(W/'compile/actual-dependencies.json',actual)
    m.save(W/'compile/dependency-contract.json',dict(original=len(old),actual=len(new),same_dependency_set=True,
        changed_only=changed,private_helper_exact=True,remaining_dependencies_unchanged=True))
    obj=m.pin(W/'compile/unit.obj')
    new_inputs=[obj if key(x['path'])==key(p['replaced']['path']) else x for x in inputs]
    m.save(W/'link-inputs.json',new_inputs)
    linked=h.execute(p['link'],env,W/'link',timeout=120)
    for x in new_inputs:m.exact(x)
    runtime=m.read(m.read(p['baseline_ready']['path'])['runtime']['path']);m.exact(runtime['native'])
    alias=W/'link'/Path(runtime['native']['path']).name
    os.link(runtime['native']['path'],alias);runtime['native_hardlink']=m.pin(alias)
    m.save(W/'runtime.json',runtime)
    m.save(W/'ready.json',dict(status='HOST_PHASE_BUILT_NOT_PROFILED',image=m.pin(W/'link/consumer.exe'),app=obj,
        source=pins['after'],source_pins=p['source_pins'],actual_dependencies=m.pin(W/'compile/actual-dependencies.json'),
        runtime=m.pin(W/'runtime.json'),link_inputs=m.pin(W/'link-inputs.json'),compile=compiled,link=linked,
        baseline_ready=p['baseline_ready'],replaced=p['replaced'],unchanged_inputs=len(new_inputs)-1,
        new_host_TUs=1,SDK_Graph_native_device_builds=0,model_runs=0))
    print('HOST_PHASE_READY',m.pin(W/'ready.json'),flush=True)


if __name__=='__main__':
    if sys.argv[1:]==['plan']:plan()
    elif sys.argv[1:]==['build']:build()
    else:raise SystemExit('Usage: python -B '+str(__file__)+' plan | build')
