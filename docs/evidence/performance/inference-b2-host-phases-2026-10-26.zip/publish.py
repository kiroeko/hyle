"""Publish interval attribution with its incomplete stdout work gate explicit."""
from pathlib import Path
import hashlib
import json
import subprocess
import zipfile

W = Path(__file__).resolve().parent
R = W.parents[1]
G = R / '.scratch/inference-b2-graph-launch-review-20261026'
DEST = R / 'docs/evidence/performance'
NAME = 'inference-b2-host-phases-2026-10-26'


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


summary = read(W / 'summary.json')
quality = read(W / 'hyle/trace1/quality.json')
independent = read(W / 'independent-phase-wall.json')
assert summary['status'] == 'PHASE_INTERVAL_FACTS_WITH_INCOMPLETE_STDIO_WORK_GATE'
assert quality['profile_process']['exit'] == 0 and not quality['profile_process']['timeout']
assert quality['physical_roots'] == 99 and quality['actual_completed_Hyle_NVTX_ranges'] == 1782
for row in independent:
    if row['label'] in summary['decode_twelve_disjoint_children']:
        assert row['count'] == 96
        assert abs(row['wall_ns'] / 1e6 - summary['decode_twelve_disjoint_children'][row['label']]['wall_ms']) < 1e-9
archive_path = DEST / (NAME + '.zip')
report_path = DEST / (NAME + '.json')
assert not archive_path.exists() and not report_path.exists()
suffixes = {'.json', '.log', '.cc', '.h', '.patch', '.py', '.sqlite'}
files = [(p.relative_to(W).as_posix(), p) for p in W.rglob('*') if p.is_file()
         and (p.suffix in suffixes or p.name.endswith('.original-extraction'))
         and p.name not in {'archive-receipt.json', 'archive-manifest.json'}]
files += [('graph-launch-source-review/' + p.name, p) for p in G.iterdir()
          if p.is_file() and p.suffix == '.json']
manifest = [dict(member=name, bytes=path.stat().st_size, sha256=sha(path)) for name, path in sorted(files)]
with zipfile.ZipFile(archive_path, 'w', zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
    for name, path in sorted(files):
        archive.write(path, name)
    archive.writestr('archive-manifest.json', json.dumps(manifest, indent=2) + '\n')
with zipfile.ZipFile(archive_path) as archive:
    assert archive.testzip() is None and len(archive.namelist()) == len(manifest) + 1
    for row in manifest:
        raw = archive.read(row['member'])
        assert len(raw) == row['bytes'] and hashlib.sha256(raw).hexdigest() == row['sha256']
report = dict(
    schema='hyle.performance.evidence.v1', date='2026-10-26',
    status='INTERVAL_ATTRIBUTION_AVAILABLE_COMPLETE_STDIO_WORK_GATE_NOT_COMPLETED',
    source_git=subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=R, text=True).strip(),
    protocol=dict(new_host_Model_TUs=1, other_product_or_SDK_builds=0, actual_profiles=1,
                  profile_exit=0, timed_out=False, repeat_profiles=0,
                  workload='Ordinary CUDA B2 fixed-input three-turn P256+32/request, C1024 N2/R2, prefix off, no MTP',
                  baseline='f36bda5e: retained image41 closure plus adopted resources publication fact; only private NVTX Model changed',
                  prelaunch_error='First runner call failed to create a missing parent directory before starting any process. Fixed mkdir(parents=True); only one actual model/profile ran.'),
    quality=quality,
    interval_facts=summary,
    independent_wall_check='Independent direct SQLite grouped wall-ns totals match all twelve decode buckets exactly; no complete work/ID claim from this check.',
    source_action='Investigate PagedArena single-source, one-request reframing using immutable canonical page metadata, retaining original live identity, row authority, allocator and independently reclaimable guards. This is a candidate, not a measured saving.',
    graph_launch_review=dict(
        scope='Offline review of the preceding paired B2 trace and actual retained source; not another run.',
        matched_hot_launches=90,
        hyle_per_launch=dict(kernels=757, device_copies=132, device_memset=1),
        peer_per_launch=dict(kernels=709, device_copies=0, device_memset=0),
        finding='No observed instantiate flag, stream blocking or priority mismatch. Peer uses copy/writeback kernels; zero memcpy API activities does not mean zero state movement.',
        limits='State copies preserve independently retained session state. Private GGML workspace cannot become an owned snapshot by replacing Copy with View. Stride-aware BF16 L2 is only an unimplemented source-supported fallback candidate.'),
    limits=[
        'Nsight retained only 20480 stdout characters and 33585 stderr characters. Full report, terminal stderr marker and all198 output IDs are unavailable; their gates are NOT completed, not PASS.',
        'Complete retained prefix fields and all99 physical batch records match their own reference non-time fields. This does not replace the missing complete report/ID gate.',
        'All99 roots, seventeen child-label occurrences per root and1782 completed NVTX ranges are present. Twelve sibling buckets are disjoint inside their original parents.',
        'The page/frame-export21.130ms bucket includes take_append, ready and reframing; it is not exclusively reframe or recoverable CPU cost.',
        'Intervals include profiling/instrumentation effects; outside-GPU/API time is not pure CPU self-time. Do not subtract earlier runs or refresh throughput/memory tables.',
        'The captured process ended successfully; incomplete stream collection alone does not establish a model-computation failure.'
    ],
    archive=dict(path=archive_path.name, bytes=archive_path.stat().st_size, sha256=sha(archive_path),
                 members=len(manifest)+1, verification='ZIP CRC and every member byte length/SHA256 verified'))
report_path.write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n', encoding='utf8')
(W / 'archive-receipt.json').write_text(json.dumps(report['archive'], indent=2) + '\n', encoding='utf8')
print(json.dumps(dict(report=str(report_path), archive=report['archive']), indent=2))
