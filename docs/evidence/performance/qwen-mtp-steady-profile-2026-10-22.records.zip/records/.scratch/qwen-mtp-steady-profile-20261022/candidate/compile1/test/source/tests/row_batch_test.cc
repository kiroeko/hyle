// Keep the product test TU intact; this finite scratch candidate adds one case.
#include "../../../../tests/compute_provider_cublas/cublas_provider_test.cc"

namespace {

TEST(CublasProvider, BfloatTwoRowsShareStoredWeightsAndReplayIndependently) {
  using BFloat = hyle::simd::bfloat16_t;
  constexpr std::size_t k = 5;
  constexpr std::size_t e = 7;
  auto owner = context();
  auto resource =
      cuda::MemoryResource::create(owner, cuda::MemoryKind::kDevice).value();
  auto queue = owner.create_queue().value();
  ASSERT_TRUE(queue.reserve_completions(1).ok());
  Matrix left(matrix(compute::DataType::kBFloat16, 2,
                     static_cast<std::int64_t>(k), false), resource.ref());
  // A dense stored [E,K] allocation is a column-major [K,E] matrix view.
  Matrix right(matrix(compute::DataType::kBFloat16,
                      static_cast<std::int64_t>(k),
                      static_cast<std::int64_t>(e), true), resource.ref());
  Matrix output(matrix(compute::DataType::kBFloat16, 2,
                       static_cast<std::int64_t>(e), false),
                resource.ref());
  const std::array inputs{left.view.as_const(), right.view.as_const()};
  const std::array outputs{output.view};
  auto preparation = compute::prepare(
      owner, compute::Operation(compute::MatMul{}), inputs, outputs);
  ASSERT_TRUE(preparation.has_value()) << preparation.error().message();
  auto prepared = std::move(*preparation);
  EXPECT_EQ(prepared.provider().id, compute::cublas::kProviderId);
  EXPECT_TRUE(prepared.capture_compatible());
  const auto needed = prepared.workspace_requirement();
  auto workspace =
      mem::Buffer::create(resource.ref(), needed.size, needed.alignment).value();
  auto invocation = prepared.create_invocation(workspace.view()).value();

  std::array<BFloat, k * e> stored{};
  for (std::size_t column = 0; column < e; ++column)
    for (std::size_t inner = 0; inner < k; ++inner) {
      const auto value = static_cast<int>((column * 3 + inner * 2) % 5) - 2;
      stored[column * k + inner] = from_float<BFloat>(static_cast<float>(value));
    }
  ASSERT_TRUE(right.storage.view().write(std::as_bytes(std::span(stored))).ok());
  const std::array<float, k> first_row{1, 0, -1, 2, 1};
  const std::array<std::array<float, k>, 2> second_rows{
      std::array<float, k>{2, -1, 0, 1, -2},
      std::array<float, k>{-1, 2, 1, 0, 2}};
  std::array<BFloat, 2 * e> first_result{};
  for (std::size_t replay = 0; replay < second_rows.size(); ++replay) {
    SCOPED_TRACE(replay);
    std::array<BFloat, 2 * k> a{};
    for (std::size_t inner = 0; inner < k; ++inner) {
      a[inner] = from_float<BFloat>(first_row[inner]);
      a[k + inner] = from_float<BFloat>(second_rows[replay][inner]);
    }
    ASSERT_TRUE(left.storage.view().write(std::as_bytes(std::span(a))).ok());
    std::array<BFloat, 2 * e> actual{};
    actual.fill(from_float<BFloat>(-64));
    ASSERT_TRUE(output.storage.view().write(std::as_bytes(std::span(actual))).ok());
    auto done = invocation.submit(queue, left.view.as_const(),
                                  right.view.as_const(), output.view);
    ASSERT_TRUE(done.has_value()) << done.error().message();
    ASSERT_TRUE(done->wait().ok());
    ASSERT_TRUE(output.storage.view()
                    .read(std::as_writable_bytes(std::span(actual)))
                    .ok());
    for (std::size_t row = 0; row < 2; ++row)
      for (std::size_t column = 0; column < e; ++column) {
        // Small integer products/sums are exact in BF16 and F32 here.
        double expected = 0;
        for (std::size_t inner = 0; inner < k; ++inner)
          expected += double(to_float(a[row * k + inner])) *
                      double(to_float(stored[column * k + inner]));
        EXPECT_EQ(to_float(actual[row * e + column]), expected)
            << row << "," << column;
      }
    if (replay == 0) {
      first_result = actual;
    } else {
      bool second_row_changed = false;
      for (std::size_t column = 0; column < e; ++column) {
        EXPECT_EQ(to_float(actual[column]), to_float(first_result[column]));
        second_row_changed |= to_float(actual[e + column]) !=
                              to_float(first_result[e + column]);
      }
      EXPECT_TRUE(second_row_changed);
    }
  }
}

} // namespace
