"""Pure-host address/span algebra for the finite M2 -> 2*M1 candidate.

This does not compile C++, call cuBLAS, test heuristic availability or measure TPS.
"""
from pathlib import Path
import hashlib
import itertools
import json


def identity(path):
    data = path.read_bytes()
    return {"path": str(path), "bytes": len(data),
            "sha256": hashlib.sha256(data).hexdigest()}


def main():
    stage = Path(__file__).resolve().parent
    cases = 0
    for k, e, pad_a, pad_c, column_b in itertools.product(
            (1, 5, 128), (1, 7, 64), (0, 1, 8), (0, 1, 8), (False, True)):
        la, lc = k + pad_a, e + pad_c
        original_a_span = (la + k) * 2
        original_c_span = (lc + e) * 2
        native_a_span = k * 2 + la * 2
        native_c_span = e * 2 + lc * 2
        assert native_a_span == original_a_span
        assert native_c_span == original_c_span
        assert lc * 2 >= e * 2  # Output batches remain disjoint.
        for row in (0, 1):
            for inner in range(k):
                assert (row * la + inner) * 2 == row * (la * 2) + inner * 2
            for col in range(e):
                assert (row * lc + col) * 2 == row * (lc * 2) + col * 2
        # B is shared, including its original order and leading dimension.
        lb = (k if column_b else e) + 3
        for inner, col in ((0, 0), (k - 1, e - 1)):
            original_b = ((col * lb + inner) if column_b
                          else (inner * lb + col)) * 2
            assert original_b + 0 * 0 == original_b + 1 * 0
        cases += 1

    a0 = (1, 0, -1, 2, 1)
    a1 = ((2, -1, 0, 1, -2), (-1, 2, 1, 0, 2))
    stored = [[(col * 3 + inner * 2) % 5 - 2 for inner in range(5)]
              for col in range(7)]
    reference = [[[sum(row[i] * col[i] for i in range(5)) for col in stored]
                  for row in (a0, a1[replay])] for replay in (0, 1)]
    assert reference[0][0] == reference[1][0]
    assert reference[0][1] != reference[1][1]
    assert all(abs(value) <= 256 for replay in reference for row in replay
               for value in row)  # Integer BF16 oracle values are exact.
    result = {
        "status": "pure_host_algebra_pass",
        "finite_address_span_cases": cases,
        "row_batch_rank": 1, "row_batch_count": 2,
        "element_bytes": 2,
        "synthetic_strides_bytes": ["A.leading*2", 0, "C.leading*2"],
        "fixture_exact_outputs": reference,
        "candidate_source": identity(stage / "src/compute_provider_cublas/cublas_provider.cc"),
        "scratch_test": identity(stage / "tests/row_batch_test.cc"),
        "not_run": ["CXX", "cuBLAS heuristics", "native submission", "CUDA Graph", "model", "GPU", "performance"],
    }
    target = stage / "geometry-check.json"
    target.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"status": result["status"], "cases": cases,
                      "result": str(target)}))


if __name__ == "__main__":
    main()
