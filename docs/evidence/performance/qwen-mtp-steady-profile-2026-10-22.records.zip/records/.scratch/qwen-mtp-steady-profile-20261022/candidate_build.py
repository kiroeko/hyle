"""Explicit scratch-only 2-row cuBLAS candidate builds; imports perform no build."""
from pathlib import Path
import argparse
import importlib.util
import os
import sys

sys.dont_write_bytecode = True
AF = Path(__file__).resolve().parent
R = AF.parents[1]
S = AF / 'candidate'
AD = R / '.scratch/qwen-cublas-scores-20261022'
RECIPES = {'cublas': AD / 'compile2/cublas/identity.json',
           'test': AD / 'compile1/test/identity.json'}
SOURCES = {'cublas': S / 'src/compute_provider_cublas/cublas_provider.cc',
           'test': S / 'tests/row_batch_test.cc'}
_helpers = None


def helpers():
    global _helpers
    if _helpers is None:
        spec = importlib.util.spec_from_file_location('af_ad_build_helpers', AD / 'build.py')
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        _helpers = module.b, module.c
    return _helpers


def __getattr__(name):
    if name in ('b', 'c'):
        return helpers()[0 if name == 'b' else 1]
    raise AttributeError(name)


def same(record):
    b, _ = helpers()
    return b.identity(record['path']) == record


def verify_frozen_sources():
    b, c = helpers()
    frozen = c.read(S / 'freeze.json')
    for item in [frozen['source_basis'], *frozen['candidate_sources'], *frozen['required_source_dependencies']]:
        actual = b.identity(R / item['path'])
        assert (actual['bytes'], actual['sha256']) == (item['bytes'], item['sha256'])


def compile_command(tag, attempt):
    b, c = helpers()
    out = S / f'compile{attempt}' / tag
    command = b.host_command(c.read(RECIPES[tag])['command'], SOURCES[tag], tag, out)
    include = '/I' + str(R / 'src/compute_provider_cublas')
    if include.casefold() not in {x.casefold() for x in command}:
        command.insert(1, include)
    assert all(x in command for x in ('/W4', '/WX', '/O2', '/MD'))
    return command


def compile_owner(tag, attempt):
    b, c = helpers()
    verify_frozen_sources()
    source = SOURCES[tag]
    frozen = b.identity(source)
    command = compile_command(tag, attempt)
    out = S / f'compile{attempt}' / tag
    out.mkdir(parents=True, exist_ok=False)
    (out / 'tmp').mkdir()
    snapshot = out / 'source' / source.relative_to(S)
    snapshot.parent.mkdir(parents=True)
    snapshot.write_bytes(source.read_bytes())
    c.save(out / 'plan.json', dict(command=command, source=frozen,
        recipe=b.identity(RECIPES[tag]), scratch_candidate=True, SDK_builds=0, NVCC_builds=0))
    env, _ = b.environment(command, [], out)
    c.execute('compile', command, env, out)
    data = c.read(out / f'{tag}-deps.json')['Data']
    dependencies = list(dict.fromkeys([data['Source'], *data['Includes']]))
    assert same(frozen), 'scratch source changed during compile'
    c.save(out / 'identity.json', dict(source=frozen, object=b.identity(out / f'{tag}.obj'),
        command=command, recipe=b.identity(RECIPES[tag]),
        dependencies=[b.identity(x) for x in dependencies],
        scratch_candidate=True, SDK_builds=0, NVCC_builds=0))
    print('COMPILED', tag, flush=True)


def link(mode, attempt, link_attempt, cublas_attempt=None):
    b, c = helpers()
    verify_frozen_sources()
    base_path = AD / f'{mode}-link1/link-plan.json'
    base = c.read(base_path)
    tags = ('cublas', 'test') if mode == 'tests' else ('cublas',)
    assert len(base['inputs']) == (198 if mode == 'tests' else 195)
    records, record_ids, replacements = {}, [], {}
    for tag in tags:
        old = c.read(RECIPES[tag])
        assert same(old['object']), 'selected old object differs from the AD receipt'
        owner_attempt = cublas_attempt if tag=='cublas' and cublas_attempt is not None else attempt
        path = S / f'compile{owner_attempt}' / tag / 'identity.json'
        record = c.read(path)
        assert all(same(x) for x in (record['source'], record['object'], *record['dependencies']))
        records[tag] = record
        record_ids.append(b.identity(path))
        old_key = c.key(old['object']['path'])
        assert sum(c.key(x['path']) == old_key for x in base['inputs']) == 1
        replacements[old_key] = record['object']
    # Retained SDK/product inputs are checked for path+size. Only replaced and
    # newly compiled identities/dependencies are rehashed, not the whole SDK.
    assert all(Path(x['path']).is_file() and Path(x['path']).stat().st_size == x['bytes'] for x in base['inputs'])
    inputs = [replacements.get(c.key(x['path']), x) for x in base['inputs']]
    assert len({c.key(x['path']) for x in inputs}) == len(inputs)
    command = [replacements.get(c.key(x), {}).get('path', x) for x in base['command']
               if not x.upper().startswith(('/OUT:', '/MAP:', '/IMPLIB:', '/PDB:'))]
    out = S / f'{mode}-link{link_attempt}'
    out.mkdir(exist_ok=False)
    (out / 'tmp').mkdir()
    image = out / f'{mode}.exe'
    command += ['/OUT:' + str(image), '/MAP:' + str(image.with_suffix('.map')),
                '/IMPLIB:' + str(image.with_suffix('.lib'))]
    c.save(out / 'link-plan.json', dict(command=command, inputs=inputs, base=b.identity(base_path),
        compiled_records=record_ids, consumer_compiled_record=base['consumer_compiled_record'],
        consumer_recompiled=False, replaced_inputs=len(tags), retained_inputs=len(inputs)-len(tags),
        retained_identity_check='All existing input paths/sizes; selected replaced objects and new dependencies SHA256.',
        scratch_candidate=True, SDK_builds=0, NVCC_builds=0))
    env, _ = b.environment(command, [x['path'] for x in inputs], out)
    c.execute('link', command, env, out)
    runtime_path = AD / 'qwen-link1/runtime-environment.json'
    runtime = c.read(runtime_path)
    for item in runtime['staged_dlls']:
        assert same(item)
        source = Path(item['path'])
        os.link(source, out / source.name)
    runtime['previous_environment'] = b.identity(runtime_path)
    runtime['staged_dlls'] = [b.identity(x) for x in out.glob('*.dll')]
    if 'CPU_DLL' in runtime:
        name = Path(runtime['CPU_DLL']['source']['path']).name
        runtime['CPU_DLL']['destination'] = b.identity(out / name)
    c.save(out / 'runtime-environment.json', runtime)
    main = c.read(base['consumer_compiled_record']['path'])
    ready = dict(image=b.identity(image), source=main['source'] if mode=='qwen' else records['test']['source'],
        main=main['source'], consumer_compiled_record=base['consumer_compiled_record'],
        changed_sources=[records[tag]['source'] for tag in tags], compiled_records=record_ids,
        consumer_recompiled=False, base_link_plan=b.identity(base_path),
        link_plan=b.identity(out / 'link-plan.json'),runtime_environment=b.identity(out / 'runtime-environment.json'),
        replaced_inputs=len(tags), retained_inputs=len(inputs)-len(tags),
        scratch_candidate=True, SDK_builds=0, NVCC_builds=0)
    c.save(S / f'{mode}-ready-attempt{link_attempt}.json', ready)
    print('READY', mode, flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('tag', choices=(*SOURCES,'qwen','tests'))
    parser.add_argument('--attempt',type=int,default=1)
    parser.add_argument('--link',action='store_true')
    parser.add_argument('--link-attempt',type=int)
    parser.add_argument('--cublas-attempt',type=int)
    args = parser.parse_args()
    if args.attempt < 1 or any(x is not None and x < 1 for x in (args.link_attempt,args.cublas_attempt)):
        parser.error('attempt numbers must be positive')
    if args.link:
        if args.tag not in ('qwen','tests'):
            parser.error('--link requires qwen/tests')
        link(args.tag,args.attempt,args.link_attempt or args.attempt,args.cublas_attempt)
    elif args.tag in SOURCES:
        compile_owner(args.tag,args.attempt)
    else:
        parser.error('qwen/tests require --link')
