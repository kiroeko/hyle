from pathlib import Path
import json

S = Path(__file__).resolve().parent
R = S.parents[1]
T = json.loads((S / 'current-window/timing/summary.json').read_text())
M = json.loads((S / 'current-window/memory/summary.json').read_text())
assert T['within_arm_fixed_work_valid'] and T['processes'] == 12
assert M['within_arm_fixed_work_valid'] and M['processes'] == 4
G = T['groups']

def rate(arm, metric):
    return G[arm][metric]['median']

def pct(a, b):
    return 100 * (a / b - 1)

labels = dict(hyle_plain='Hyle普通', hyle_mtp='Hyle MTP K1',
              peer_plain='llama.cpp普通', peer_mtp='llama.cpp MTP K1')
arms = tuple(labels)
lines = ['## 最新完整性能对比', '',
    '**2026-10-22，当前产品镜像的新四臂窗口。** Qwen3.5-2B、RTX 4070、全CUDA、BF16权重；相同P154提示词，自然greedy输出64枚、C1024／N1／R1，前缀缓存关闭。每臂3个新进程交错测速，另各1个独立进程旁采内存。未将此前窗口合并。', '',
    '| 当前模式 | prefill tok/s | 完整decode tok/s | 综合输出 tok/s |',
    '| --- | ---: | ---: | ---: |']
for arm in arms:
    lines.append(f"| {labels[arm]} | {rate(arm, 'prefill_tokens_per_second'):.2f} | {rate(arm, 'full_decode_tokens_per_second'):.2f} | {rate(arm, 'session_output_tokens_per_second'):.2f} |")
lines += ['',
    f"普通版Hyle相对参考prefill＋{pct(rate('hyle_plain', 'prefill_tokens_per_second'), rate('peer_plain', 'prefill_tokens_per_second')):.2f}%，decode {pct(rate('hyle_plain', 'full_decode_tokens_per_second'), rate('peer_plain', 'full_decode_tokens_per_second')):.2f}%，综合{pct(rate('hyle_plain', 'session_output_tokens_per_second'), rate('peer_plain', 'session_output_tokens_per_second')):.2f}%；MTP分别＋{pct(rate('hyle_mtp', 'prefill_tokens_per_second'), rate('peer_mtp', 'prefill_tokens_per_second')):.2f}%／{pct(rate('hyle_mtp', 'full_decode_tokens_per_second'), rate('peer_mtp', 'full_decode_tokens_per_second')):.2f}%／{pct(rate('hyle_mtp', 'session_output_tokens_per_second'), rate('peer_mtp', 'session_output_tokens_per_second')):.2f}%。这里的综合是64输出／（完整prefill＋decode）的每进程比率再取中位，不含加载，也不是多轮或多人吞吐。", '',
    '| 当前模式 | prefill范围 tok/s | decode范围 tok/s | 加载s | 入口至ready s | 入口至末输出s |',
    '| --- | ---: | ---: | ---: | ---: | ---: |']
for arm in arms:
    p, d = (G[arm][k] for k in ('prefill_tokens_per_second', 'full_decode_tokens_per_second'))
    lines.append(f"| {labels[arm]} | {p['min']:.2f}～{p['max']:.2f} | {d['min']:.2f}～{d['max']:.2f} | {rate(arm, 'weights_load_seconds'):.3f} | {rate(arm, 'startup_to_ready_seconds'):.3f} | {rate(arm, 'startup_to_endpoint_seconds'):.3f} |")
lines += ['',
    '速度为各进程比率的中位数，仅3样本的描述统计。decode计prefill后63枚新输出的完整host端点，不删准备／重录／等待；综合包含prefill产出的首token。加载边界依消费者实现，入口计时不含OS装载DLL，入口至末输出不含之后销毁；这两个启动指标不能当相同加载算法的胜负。', '',
    '| 当前模式 | GPU dedicated峰 GiB | GPU shared峰 MiB | 同采样GPU总峰 GiB | CPU WS峰 GiB | CPU private commit峰 GiB |',
    '| --- | ---: | ---: | ---: | ---: | ---: |']
for arm in arms:
    p = M['groups'][arm]['sampled_peaks']
    lines.append(f"| {labels[arm]} | {p['sampled_peak_gpu_dedicated_bytes']/2**30:.3f} | {p['sampled_peak_gpu_shared_bytes']/2**20:.2f} | {p['sampled_peak_gpu_total_bytes']/2**30:.3f} | {p['sampled_max_working_set_bytes']/2**30:.3f} | {p['sampled_max_private_commit_bytes']/2**30:.3f} |")
lines += ['',
    '内存为Windows PSAPI／PDH的独立旁采观测峰，非精确物理分配；dedicated与shared分列峰不能相加，总峰只在同一有效采样点相加。CPU WS／private commit／GPU shared也不能当互斥资源求和。请求间隔10ms，实际间隔中位15.12～15.29ms、最大25.20ms，采样成本中位0.107～0.124ms。四臂均有prefill及decode阶段样本，但ready至首prefill均无样本，加载后基线和严格阶段边界增量仍unknown；启动或退出无GPU实例的空值未填0。', '',
    '**可比边界：** 各臂3次的64ID、实际工作字段及去计时后的轮次决策相同；跨引擎普通／MTP两对均从零基index18（第19枚）起分歧。Hyle普通与参考MTP的64ID相同，Hyle MTP与参考普通相同；不能据此改配测速臂或称数学相同。Hyle保BF16输入／权重→F32末分数，中间BF16及GDN F32；参考原生算术、状态、草拟prefill与工作量仍有差异。没有质量门限通过结论，也不把两种MTP接受／工作量视为相同。', '',
    '本窗两端绝对速度均低于前窗，未固定频率、独占GPU或清页缓存，不将跨窗变化归因代码回归；本次仍用当前默认镜像，未采用已拒绝的行批候选。单请求P154／64不能代表长上下文、多轮或四人并发。', '',
    '[本轮完整12次测速、4次旁采、命令／身份与比较限制](../evidence/performance/qwen-mtp-steady-profile-2026-10-22.json)。本次更新前的完整进度页和旧性能表保存在同一证据包的`before/current-work.md`；此前[cuBLASLt实现窗](../evidence/performance/qwen-cublas-scores-2026-10-22.json)、[自然四臂旧窗](../evidence/performance/qwen-mtp-window-2026-10-22.json)、[多会话批次窗](../evidence/performance/qwen-cli-batch-2026-10-22.json)及[三轮共享缓存窗](../evidence/performance/qwen-multiturn-current-2026-10-21.json)各自保留原工作量，不与本表混算。', '']

p = R / 'docs/developer/current-work.md'
t = p.read_text(encoding='utf-8')
head = t.split('## 最新完整性能对比', 1)[0]
head = head.replace('新完整窗口的Hyle前／后64枚', '此前cuBLASLt实现窗口的Hyle前／后64枚')
head = head.replace('页末最新完整四项仍是此前cuBLASLt窗。', '当前普通／MTP四臂完整测速与旁采已更新至页末，不将初筛候选数据混入。')
head = head.replace('执行资源复用的旧单会话／串行前缀窗口保留在页末，新双会话B2窗口接在其后，不混合工作量推算收益。', '页末只保留最新当前四臂窗口，历史单会话／多会话表在各自证据及本轮归档中保留，不混合工作量推算收益。')
head = head.replace('P154自然四臂及carrier对照已测；跨B续文差异、完整质量、额外capture失效及其它原生后端仍未完成。', 'P154自然四臂及carrier对照已测；额外capture失效已定因，跨B续文差异、完整质量及其它原生后端仍未完成。')
head = head.replace('后续功能顺序见下；剩余10次capture失效机制另查，不反复benchmark本次carrier。', '后续功能顺序见下；额外10次capture失效已由当前镜像直接定因，不沿用旧数值窗反推原因。')
p.write_text(head + '\n'.join(lines), encoding='utf-8')

p = R / 'docs/developer/performance/decode.md'
t = p.read_text(encoding='utf-8')
marker = '### 当前普通／MTP四臂完整窗口：2026-10-22'
assert marker not in t
t += '\n' + marker + '\n\n'
t += '已按用户询问，使用当前默认Hyle镜像和原native llama.cpp消费者重新跑12次交错测速、4次独立内存旁采。相同P154／64、C1024／N1／R1、prefix off，两个Hyle模式均保现行BF16输入→F32末分数政策；无新编译、无profiler。\n\n'
t += '| 模式 | Hyle prefill／decode／综合 tok/s | llama.cpp prefill／decode／综合 tok/s |\n| --- | ---: | ---: |\n'
for a, b, name in [('hyle_plain','peer_plain','普通'), ('hyle_mtp','peer_mtp','MTP K1')]:
    vals = lambda arm: '／'.join(f'{rate(arm,k):.2f}' for k in ('prefill_tokens_per_second','full_decode_tokens_per_second','session_output_tokens_per_second'))
    t += f'| {name} | {vals(a)} | {vals(b)} |\n'
t += '\n普通decode相对慢5.29%，MTP慢11.03%；prefill分别快50.30%／49.15%。同一模式的每臂输出／工作／决策可重复，但两对跨引擎续文都从第19枚分歧，不称同token严格差距或质量验收。两端绝对速度均低于前窗，不据非固定频率的跨窗值签代码回归。完整范围、加载／启动、显存／内存和采样限制见[当前工作末表](../current-work.md#最新完整性能对比)，原始命令／实际结果与独立host复核见[本轮证据](../../evidence/performance/qwen-mtp-steady-profile-2026-10-22.json)。只用本窗4臂互比，拒绝候选的单对初筛不混入。\n'
p.write_text(t, encoding='utf-8')
print(json.dumps({'current_work_lines': len((R/'docs/developer/current-work.md').read_text(encoding='utf-8').splitlines()), 'updated': [str(R/'docs/developer/current-work.md'), str(p)]}))
