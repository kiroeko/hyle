"""One retained AD CUDA timeline. Only explicit `run` starts the model."""
from pathlib import Path
import argparse
import hashlib
import json
import os
import subprocess
import time

S = Path(__file__).resolve().parent
R = S.parents[1]
AD = R / '.scratch/qwen-cublas-scores-20261022'
NSYS = Path('C:/Program Files/NVIDIA Corporation/Nsight Systems 2026.1.3/target-windows-x64/nsys.exe')
READY = AD / 'qwen-ready-attempt1.json'
COMMAND = AD / 'performance/timing/02-after_MTP/command.json'
BASELINE = AD / 'performance/timing/02-after_MTP/stdout.log'


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def save(path, value):
    Path(path).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


def identity(path):
    path = Path(path)
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(block)
    return dict(path=str(path), bytes=path.stat().st_size, sha256=digest.hexdigest())


def observation(path):
    values = []
    for line in Path(path).read_text(encoding='utf-8-sig', errors='replace').splitlines():
        try:
            value = json.loads(line)
        except (ValueError, TypeError):
            continue
        if isinstance(value, dict) and 'generated_ids' in value:
            values.append(value)
    if len(values) != 1:
        raise ValueError(f'expected one complete generated_ids observation in {path}, got {len(values)}')
    return values[0]


def make_plan(out):
    ready, retained = read(READY), read(COMMAND)
    model = retained['command'].copy()
    if model[0] != ready['image']['path'] or retained['image'] != ready['image']:
        raise ValueError('AD command/image identity mismatch')
    expected = ['--steps', '64', '--capacity', '1024', '--max-sessions', '1',
                '--active-sequences', '1', '--prefix-cache', 'off', '--progress',
                'direct', '--replay', 'auto', '--mtp', 'on']
    if model[3:] != expected or model[1] != '--inputs' or '--trace' in model:
        raise ValueError('retained original P154/64 MTP command changed')
    stem = out / 'capture'
    profile = [str(NSYS), 'profile', '--trace=cuda', '--sample=none', '--cpuctxsw=none',
               '--cuda-trace-all-apis=true', '--cuda-graph-trace=node:host-only',
               '--discard-environment=true', '--force-overwrite=false',
               '--output=' + str(stem), *model]
    export = [str(NSYS), 'export', '--type=sqlite', '--force-overwrite=false',
              '--output=' + str(stem) + '.sqlite', str(stem) + '.nsys-rep']
    return dict(scope='Exactly one unchanged AD P154/64 natural MTP workload; diagnostic, not throughput.',
                image=ready['image'], ready=identity(READY),
                runtime_environment=ready['runtime_environment'],
                source_command=identity(COMMAND), reference_observation=identity(BASELINE),
                model_command=model, profile=profile, export=export, cwd=str(R),
                output_directory=str(out), profiler=True, throughput_evidence=False,
                CPU_sampling=False, CPU_context_switch_trace=False,
                tensor_payload_trace=False, concurrent_GPU=False,
                steady_selection='Offline: use actual ordered host-ID completions and prepared logs; verify no new loss after decode index14 before labeling the remainder steady.')


def execute(out, tag, argv, env):
    receipt = dict(command=argv, cwd=str(R), started_unix_ns=time.time_ns(),
                   profiler=True, throughput_evidence=False)
    save(out / (tag + '.command.json'), receipt)
    started = time.perf_counter()
    with (out / (tag + '.stdout.log')).open('wb') as stdout, (out / (tag + '.stderr.log')).open('wb') as stderr:
        process = subprocess.run(argv, cwd=R, env=env, stdout=stdout, stderr=stderr)
    receipt.update(exit=process.returncode, finished_unix_ns=time.time_ns(),
                   diagnostic_process_wall_seconds=time.perf_counter() - started)
    save(out / (tag + '.result.json'), receipt)
    if process.returncode:
        raise RuntimeError(f'{tag} exited {process.returncode}; original logs retained in {out}')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action', choices=('plan', 'run', 'export'), nargs='?', default='plan')
    parser.add_argument('--attempt', type=int, default=1)
    args = parser.parse_args()
    if args.attempt < 1:
        parser.error('--attempt must be positive')
    out = S / 'execution' / ('attempt' + str(args.attempt))
    plan = make_plan(out)
    if args.action == 'plan':
        print(json.dumps(plan, ensure_ascii=False, indent=2))
        return
    env = os.environ.copy()
    env['PATH'] = read(plan['runtime_environment']['path'])['PATH']
    env['TEMP'] = env['TMP'] = str(out / 'tmp')
    if args.action == 'run':
        actual_image = identity(plan['image']['path'])
        if actual_image != plan['image']:
            raise ValueError('retained AD executable differs from its ready receipt')
        if identity(plan['runtime_environment']['path']) != plan['runtime_environment']:
            raise ValueError('AD runtime environment receipt changed')
        if not NSYS.is_file():
            raise FileNotFoundError(NSYS)
        out.mkdir(parents=True, exist_ok=False)
        (out / 'tmp').mkdir()
        plan['profiler_identity'] = identity(NSYS)
        save(out / 'plan.json', plan)
        execute(out, 'profile', plan['profile'], env)
        actual, original = observation(out / 'profile.stdout.log'), observation(BASELINE)
        fields = ('generated_ids', 'rounds', 'generated_tokens', 'generated_decode_tokens',
                  'actual_graph_calls', 'decode_graph_calls', 'actual_target_rows',
                  'actual_draft_rows', 'committed_target_rows', 'verified_target_rows',
                  'draft_rounds', 'agreements', 'accepted_drafts', 'score_policy')
        checks = {key: actual[key] == original[key] for key in fields}
        save(out / 'observation.json', actual)
        save(out / 'work-comparison.json', dict(reference=plan['reference_observation'],
             checks=checks, all_equal=all(checks.values()),
             scope='IDs, exact round decisions and exported work only; profile times are diagnostic.'))
        if not all(checks.values()):
            raise RuntimeError('profile workload differs from retained AD observation; raw run preserved')
    elif not (out / 'capture.nsys-rep').is_file():
        raise FileNotFoundError(out / 'capture.nsys-rep')
    execute(out, 'export', plan['export'], env)
    save(out / 'receipt.json', dict(report=identity(out / 'capture.nsys-rep'),
         sqlite=identity(out / 'capture.sqlite'), image=plan['image'],
         runtime_environment=plan['runtime_environment'], instrumented=True,
         throughput_evidence=False, tensor_payload_trace=False))
    print('TRACE_READY', out, flush=True)


if __name__ == '__main__':
    main()
