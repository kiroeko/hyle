"""Read one retained SQLite timeline; no native process, build or model launch."""
from pathlib import Path
from collections import Counter, defaultdict
import csv
import hashlib
import json
import re
import sqlite3
import statistics

S = Path(__file__).resolve().parent
P = S / 'execution/attempt1'
O = S / 'review'


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def identity(path):
    path = Path(path)
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(block)
    return dict(path=str(path), bytes=path.stat().st_size, sha256=digest.hexdigest())


def merge(intervals):
    result = []
    for begin, end in sorted(intervals):
        if end <= begin:
            continue
        if result and begin <= result[-1][1]:
            result[-1][1] = max(result[-1][1], end)
        else:
            result.append([begin, end])
    return result


def duration(intervals):
    return sum(end - begin for begin, end in intervals)


def intersection(left, right):
    i = j = 0
    value = 0
    while i < len(left) and j < len(right):
        value += max(0, min(left[i][1], right[j][1]) - max(left[i][0], right[j][0]))
        if left[i][1] <= right[j][1]:
            i += 1
        else:
            j += 1
    return value


def clipped(rows, begin, end):
    return [(r, max(begin, r['start']), min(end, r['end']))
            for r in rows if r['start'] < end and r['end'] > begin]


def stats(values):
    return dict(count=len(values), median=statistics.median(values), min=min(values), max=max(values))


def category(name):
    lower = name.lower()
    if any(x in lower for x in ('gemm', 'gemv', 'matmul', 'mul_mat')):
        return 'matrix_multiply'
    if 'gated_delta' in lower:
        return 'gated_delta_net'
    if 'flashinfer' in lower and ('attention' in lower or 'pagedkv' in lower):
        return 'paged_attention'
    if 'conv' in lower:
        return 'convolution'
    if any(x in lower for x in ('cpy_', 'copy_', 'get_rows', 'gather_', 'paged_append')):
        return 'kernel_copy_gather_append'
    return 'other_pointwise_reduction_or_kernel'


def metrics(kernels, copies, memsets, apis, begin, end):
    k = clipped(kernels, begin, end)
    c = clipped(copies, begin, end)
    m = clipped(memsets, begin, end)
    a = clipped(apis, begin, end)
    gpu = merge([(b, e) for _, b, e in k + c + m])
    api = merge([(b, e) for _, b, e in a])
    gaps, cursor = [], begin
    for b, e in gpu:
        if b > cursor:
            gaps.append([cursor, b])
        cursor = max(cursor, e)
    if cursor < end:
        gaps.append([cursor, end])
    groups = defaultdict(list)
    for r, b, e in a:
        groups[r['name']].append((b, e))
    api_groups = []
    for name, intervals in groups.items():
        own_union = merge(intervals)
        api_groups.append(dict(name=name, calls_intersecting_window=len(intervals),
            clipped_duration_sum_ms=duration(intervals) / 1e6,
            clipped_union_ms=duration(own_union) / 1e6,
            union_intersection_with_GPU_busy_ms=intersection(own_union, gpu) / 1e6))
    api_groups.sort(key=lambda x: x['clipped_union_ms'], reverse=True)
    kinds = defaultdict(lambda: dict(calls=0, bytes=0, clipped_duration_sum_ms=0.0))
    for r, b, e in c:
        group = kinds[r['kind']]
        group['clipped_duration_sum_ms'] += (e - b) / 1e6
        if begin <= r['start'] < end:
            group['calls'] += 1
            group['bytes'] += r['bytes']
    categories = defaultdict(lambda: dict(kernel_count=0, clipped_duration_sum_ms=0.0))
    for r, b, e in k:
        group = categories[r['category']]
        group['kernel_count'] += 1
        group['clipped_duration_sum_ms'] += (e - b) / 1e6
    top = Counter()
    for r, b, e in k:
        top[r['name']] += e - b
    result = dict(interval_ms=(end - begin) / 1e6, kernel_count=len(k),
        kernel_duration_sum_ms=sum(e - b for _, b, e in k) / 1e6,
        kernel_union_ms=duration(merge([(b, e) for _, b, e in k])) / 1e6,
        GPU_busy_union_ms=duration(gpu) / 1e6,
        GPU_inactive_ms=duration(gaps) / 1e6,
        GPU_inactive_interval_count=len(gaps),
        longest_inactive_intervals=[dict(start_ns=b, end_ns=e, duration_ms=(e-b)/1e6)
            for b, e in sorted(gaps, key=lambda x: x[1]-x[0], reverse=True)[:8]],
        memcpy=kinds, memset_count=len(m), memset_bytes=sum(r['bytes'] for r, _, _ in m if begin <= r['start'] < end),
        API_calls_intersecting_window=len(a), API_clipped_duration_sum_ms=sum(e-b for _, b, e in a)/1e6,
        API_clipped_union_ms=duration(api)/1e6,
        API_union_intersection_with_GPU_busy_ms=intersection(api, gpu)/1e6,
        API_union_outside_GPU_busy_ms=(duration(api)-intersection(api,gpu))/1e6,
        inactive_without_any_traced_CUDA_API_ms=(duration(gaps)-intersection(api,gaps))/1e6,
        kernel_categories=categories, top_kernel_duration_ms=[dict(name=n, duration_ms=v/1e6) for n,v in top.most_common(5)],
        API_by_name=api_groups,
        GPU_event_crossing_boundary_count=sum(r['start']<begin or r['end']>end for r,_,_ in k+c+m))
    assert abs(result['GPU_busy_union_ms'] + result['GPU_inactive_ms'] - result['interval_ms']) < 1e-8
    return result, gaps


def aggregate_kernels(rows, windows):
    groups = defaultdict(list)
    for r in rows:
        groups[r['name']].append(r)
    output = []
    for name, selected in groups.items():
        grids = Counter((r['gridX'],r['gridY'],r['gridZ'],r['blockX'],r['blockY'],r['blockZ']) for r in selected)
        per_round = [sum(max(0,min(e,r['end'])-max(b,r['start'])) for r in selected if r['start']<e and r['end']>b)/1e6 for b,e in windows]
        total = sum(r['end']-r['start'] for r in selected)/1e6
        output.append(dict(demangled_name=name, category=category(name), kernel_count=len(selected),
            duration_sum_ms=total, duration_per_call_us=stats([(r['end']-r['start'])/1e3 for r in selected]),
            duration_per_round_ms=stats(per_round),
            grid_block_profiles=[dict(grid=list(g[:3]),block=list(g[3:]),count=n,
                duration_sum_ms=sum(r['end']-r['start'] for r in selected if (r['gridX'],r['gridY'],r['gridZ'],r['blockX'],r['blockY'],r['blockZ'])==g)/1e6) for g,n in grids.most_common()],
            launch_ordinals=dict(Counter(r.get('launch_ordinal','outside_graph') for r in selected)),
            graph_ids=sorted({r['graphId'] for r in selected if r['graphId'] is not None})))
    output.sort(key=lambda x:x['duration_sum_ms'],reverse=True)
    return output


def main():
    O.mkdir(exist_ok=True)
    database = P/'capture.sqlite'
    connection = sqlite3.connect(database.resolve().as_uri()+'?mode=ro',uri=True)
    connection.row_factory=sqlite3.Row
    names=dict(connection.execute('select id,value from StringIds'))
    kinds=dict(connection.execute('select id,label from ENUM_CUDA_MEMCPY_OPER'))
    def load(table):
        return [dict(r) for r in connection.execute('select * from '+table+' order by start')]
    kernels,copies,memsets,apis=[load(x) for x in ('CUPTI_ACTIVITY_KIND_KERNEL','CUPTI_ACTIVITY_KIND_MEMCPY','CUPTI_ACTIVITY_KIND_MEMSET','CUPTI_ACTIVITY_KIND_RUNTIME')]
    for row in kernels:
        row['name']=names[row['demangledName']]
        row['category']=category(row['name'])
    for row in copies:
        row['kind']=kinds[row['copyKind']]
    for row in apis:
        row['name']=names[row['nameId']]
    diagnostics=[dict(r) for r in connection.execute('select * from DIAGNOSTIC_EVENT order by timestamp')]
    kernel_columns=[r['name'] for r in connection.execute('pragma table_info(CUPTI_ACTIVITY_KIND_KERNEL)')]
    graph_events=[dict(r) for r in connection.execute('select * from CUDA_GRAPH_NODE_EVENTS')]
    connection.close()
    observation=read(P/'recovered/observation.json')
    work=read(P/'recovered/work-comparison.json')
    lines=(P/'recovered/target.stderr.log').read_text(encoding='utf-8').splitlines()
    prep_pattern=re.compile(r'^prepared T=(\d+) visible=(\d+) replay=(\S+) cold_batch_seconds=(\S+) capture_recorded=(\d+) capture_reused=(\d+)$')
    step_pattern=re.compile(r'^(prefill|mtp(\d+)) tokens=(\d+) visible=(\d+) seconds=(\S+) submit_seconds=(\S+) step_seconds=(\S+) progress=(\S+) next=(-?\d+)$')
    prepared=[]
    steps=[]
    for line in lines:
        match=prep_pattern.match(line)
        if match:
            values=match.groups()
            prepared.append(dict(T=int(values[0]),visible=int(values[1]),replay=values[2],cold_batch_seconds=float(values[3]),recorded=int(values[4]),reused=int(values[5])))
        match=step_pattern.match(line)
        if match:
            v=match.groups()
            steps.append(dict(name=v[0],round=0 if v[1] is None else int(v[1]),tokens=int(v[2]),visible=int(v[3]),seconds=float(v[4]),submit_seconds=float(v[5]),step_seconds=float(v[6]),next=int(v[8])))
    assert len(prepared)==len(steps)==35
    assert steps[0]['name']=='prefill' and [x['round'] for x in steps[1:]]==list(range(1,35))
    assert steps[0]['next']==observation['generated_ids'][0]
    host_copies=[r for r in copies if r['copyKind']==2 and r['bytes'] in (4,8)]
    assert len(host_copies)==69 and [r['bytes'] for r in host_copies]==[4]+[4,8]*34
    assert all(host_copies[i]['end']<=host_copies[i+1]['start'] for i in range(68))
    launches=[r for r in apis if r['name'].startswith('cudaGraphLaunch')]
    assert len(launches)==68
    api_correlations=defaultdict(list)
    for row in apis:
        api_correlations[row['correlationId']].append(row)
    anchor_rows=[]
    for r in host_copies:
        matched=api_correlations[r['correlationId']]
        assert len(matched)==1 and matched[0]['name']=='cuMemcpyDtoH_v2'
        anchor_rows.append(dict(bytes=r['bytes'],GPU_start_ns=r['start'],GPU_end_ns=r['end'],
            runtime_start_ns=matched[0]['start'],runtime_end_ns=matched[0]['end'],correlationId=r['correlationId'],streamId=r['streamId']))
    per_round=[]
    gaps_all=[]
    committed=observation['prefill_target_rows']
    generated=[observation['generated_ids'][0]]
    previous=host_copies[0]['end']
    launch_ids={r['correlationId'] for r in launches}
    launch_ordinal={r['correlationId']:1+i%2 for i,r in enumerate(launches)}
    for row in kernels:
        if row['correlationId'] in launch_ordinal:
            row['launch_ordinal']=launch_ordinal[row['correlationId']]
    matched_graph_kernel_count=sum(r['correlationId'] in launch_ids for r in kernels)
    assert matched_graph_kernel_count==26462 and len(kernels)==28364
    for i, decision in enumerate(observation['rounds']):
        index=i+1
        draft_copy,target_copy=host_copies[1+2*i:3+2*i]
        end=target_copy['end']
        assert decision['pending']==generated[-1]
        accepted=decision['committed_target_rows']
        assert accepted in (1,2) and accepted==(2 if decision['accepted_draft'] else 1)
        generated.extend([decision['draft'],decision['target_second']] if accepted==2 else [decision['target_first']])
        committed+=accepted
        assert prepared[index]['visible']==steps[index]['visible']==committed
        assert steps[index]['next']==generated[-1] and prepared[index]['T']==steps[index]['tokens']==2
        group=[r for r in launches if previous<=r['start']<end]
        assert len(group)==2 and all(r['returnValue']==0 for r in group)
        group_summary=[]
        for ordinal, launch in enumerate(group):
            selected=[r for r in kernels if r['correlationId']==launch['correlationId']]
            ids={r['graphId'] for r in selected}
            assert selected and len(ids)==1 and None not in ids
            assert all(r['graphNodeId'] is not None and previous<=r['start'] and r['end']<=end for r in selected)
            group_summary.append(dict(ordinal=ordinal+1,API_start_ns=launch['start'],API_end_ns=launch['end'],
                API_duration_ms=(launch['end']-launch['start'])/1e6,correlationId=launch['correlationId'],
                graphId=next(iter(ids)),kernel_count=len(selected),
                kernel_duration_sum_ms=sum(r['end']-r['start'] for r in selected)/1e6,
                GPU_first_kernel_ns=min(r['start'] for r in selected),GPU_last_kernel_ns=max(r['end'] for r in selected),
                unique_graphNodeIds=len({r['graphNodeId'] for r in selected}),
                GDN_kernels=sum(r['category']=='gated_delta_net' for r in selected)))
        metric,gaps=metrics(kernels,copies,memsets,apis,previous,end)
        for b,e in gaps:
            gaps_all.append(dict(round=index,steady=index>=16,start_ns=b,end_ns=e,duration_ns=e-b))
        per_round.append(dict(round=index,region='steady_reuse' if index>=16 else 'initial_or_rerecord',
            begin_GPU_copy_end_ns=previous,end_GPU_copy_end_ns=end,
            draft_ID_copy=anchor_rows[1+2*i],target_rows_ID_copy=anchor_rows[2+2*i],
            decision=decision,prepared=prepared[index],consumer_log=steps[index],launches=group_summary,**metric))
        previous=end
    assert generated==observation['generated_ids'] and len(generated)==64
    assert committed==observation['visible_tokens']==217
    assert all(r['prepared']['recorded']==0 and r['prepared']['reused']==2 for r in per_round[15:])
    assert sum(x['prepared']['recorded'] for x in per_round)==18
    assert sum(x['prepared']['reused'] for x in per_round)==50
    role_slots=set()
    for row in per_round:
        # Single P154 prefill advances global execution parity once, then one episode/round.
        role=3 if row['decision']['draft_rows']==1 else 4
        slot=row['round']%2
        initial=(role,slot) not in role_slots
        role_slots.add((role,slot))
        row['source_inferred_role_slot']=dict(role=role,slot=slot,first_use=initial,
            initial_recorded_ranges=2 if initial else 0,
            lost_recorded_ranges=row['prepared']['recorded']-(2 if initial else 0))
        assert row['source_inferred_role_slot']['lost_recorded_ranges']>=0
    assert sum(r['source_inferred_role_slot']['initial_recorded_ranges'] for r in per_round)==8
    assert sum(r['source_inferred_role_slot']['lost_recorded_ranges'] for r in per_round)==10
    steady=per_round[15:]
    windows=[(r['begin_GPU_copy_end_ns'],r['end_GPU_copy_end_ns']) for r in steady]
    steady_begin,steady_end=windows[0][0],windows[-1][1]
    steady_metrics,_=metrics(kernels,copies,memsets,apis,steady_begin,steady_end)
    steady_kernels=[r for r in kernels if steady_begin<=r['start']<steady_end]
    top=aggregate_kernels(steady_kernels,windows)
    total_kernel_ms=steady_metrics['kernel_duration_sum_ms']
    for row in top:
        row['share_of_kernel_duration_sum_percent']=100*row['duration_sum_ms']/total_kernel_ms
    metric_keys=('interval_ms','kernel_count','kernel_duration_sum_ms','kernel_union_ms','GPU_busy_union_ms','GPU_inactive_ms','GPU_inactive_interval_count','API_calls_intersecting_window','API_clipped_duration_sum_ms','API_clipped_union_ms','API_union_intersection_with_GPU_busy_ms','API_union_outside_GPU_busy_ms','inactive_without_any_traced_CUDA_API_ms')
    summary={key:stats([r[key] for r in steady]) for key in metric_keys}
    for row in steady_metrics['API_by_name']:
        row['per_round_union_ms']=stats([next((x['clipped_union_ms'] for x in r['API_by_name'] if x['name']==row['name']),0) for r in steady])
    gap_path=O/'GPU-inactive-intervals.tsv'
    with gap_path.open('w',encoding='utf-8',newline='') as stream:
        writer=csv.DictWriter(stream,fieldnames=('round','steady','start_ns','end_ns','duration_ns'),delimiter='\t')
        writer.writeheader();writer.writerows(gaps_all)
    inputs=[database,P/'recovered/observation.json',P/'recovered/target.stderr.log',P/'recovered/target.stdout.log',P/'recovered/work-comparison.json',P/'profile.result.json',P/'export.result.json',S/'review/steady-source-map.json',Path(__file__)]
    receipt=read(P/'receipt.json')
    report=dict(status='FROZEN_HOST_ONLY_ACTUAL_STEADY_TIMELINE_ANALYSIS',
        sources=[identity(x) for x in inputs],retained_report_identity=receipt['report'],
        scope=dict(new_native_processes=0,GPU_runs=0,builds=0,product_edits=0,throughput_claim=False,quality_claim=False),
        verification=dict(native_profile_exit=read(P/'profile.result.json')['exit'],export_exit=read(P/'export.result.json')['exit'],
            recovered_AD_IDs_rounds_work_all_equal=work['all_equal'],kernels=len(kernels),runtime_APIs=len(apis),
            DtoH4B=35,DtoH8B=34,small_copy_order='prefill4B +34*(draft4B,target8B)',
            every_anchor_runtime_correlated=True,decode_prepared_lines=34,decode_step_lines=34,
            all_log_visible_next_and_observation_decisions_match=True,GraphLaunch=68,every_round_two_launches=True,
            graph_kernels_matched_to_launch_correlation=matched_graph_kernel_count,graph_kernel_count_without_launch_match=sum(r['graphId'] is not None and r['correlationId'] not in launch_ids for r in kernels),
            recorded_ranges=18,reused_ranges=50,steady_rounds=list(range(16,35)),all_steady_recorded0_reused2=True),
        boundaries=dict(definition='Previous final target8B DtoH GPU end (first interval: prefill4B end) through current target8B DtoH GPU end; half-open [begin,end).',
            exact_consumer_wall=False,reason='GPU copy completion precedes the host API return, publication and log/trace. Subsequent interval includes intervening coordination. This is a GPU-completion-anchored diagnostic interval, not consumer endpoint wall.',
            prefill_anchor=anchor_rows[0],decode_total_GPU_anchor_interval_ms=(host_copies[-1]['end']-host_copies[0]['end'])/1e6,
            logged_consumer_decode_seconds=observation['decode_seconds'],byte_accounting='Memcpy count/bytes assigned by activity start; duration clipped to interval. No partial-byte estimates.'),
        correlation=dict(method='Exact kernel.correlationId == cudaGraphLaunch runtime correlationId, then verify one graphId and nonnull graphNodeId per launch; no nearest-time association.',
            graph_node_event_rows=len(graph_events),whole_graph_activity_table_present=False,
            module_filename_available_in_kernel_schema=False,kernel_columns=kernel_columns,
            limitation='Node trace provides demangled/mangled kernel identities and graph IDs, not an executable/DLL module filename. Names are retained in full; opaque symbols are not a one-to-one operator proof.'),
        initial15_rounds=[dict(round=r['round'],recorded=r['prepared']['recorded'],reused=r['prepared']['reused'],source_inferred_role_slot=r['source_inferred_role_slot'],cold_batch_seconds=r['prepared']['cold_batch_seconds'],graphIds=[x['graphId'] for x in r['launches']],interval_ms=r['interval_ms']) for r in per_round[:15]],
        steady_summary=dict(rounds=19,per_round_statistics=summary,total=steady_metrics,
            categories={key:dict(**value,share_of_kernel_duration_sum_percent=100*value['clipped_duration_sum_ms']/total_kernel_ms) for key,value in steady_metrics['kernel_categories'].items()},
            demangled_kernel_totals=top),
        per_round=per_round,all_GPU_inactive_intervals=identity(gap_path),
        diagnostics=diagnostics,
        attribution_limits=[
            'Installed driver13.4 is unsupported by this Nsight build; actual DIAGNOSTIC_EVENT says CUPTI13.3 libraries were used. Hardware tracing unavailable; software-instrumented legacy trace was collected.',
            'Profile/all-API/node instrumentation can change kernel launch cost, gaps and timings. No tokens/s comparison or uninstrumented speedup is inferred.',
            'GPU inactive is the complement of the union of kernel/copy/memset activities on the traced workload. It is not CPU self-time and can include dependencies, launch availability, synchronization or profiler effects.',
            'CUDA API duration sums may include nested runtime/driver activity. The report separately uses clipped interval unions and intersections with GPU busy to avoid adding inclusive times as disjoint costs.',
            'Kernel duration sum may count concurrent kernels more than once; GPU busy is a union, not that sum. Logical copy kernels are kernels and have no memcpy-byte payload in this export.',
            'Categories use explicit kernel symbol families only. get_rows can be recurrent snapshot reordering, not necessarily token embedding. Source/operator refinement must use the separate frozen source map.',
            'This trace is one unchanged AD single-session MTP workload, not peer, concurrency, allocator-isolated, full numerical-quality or end-to-end throughput evidence.'])
    target=O/'actual-steady-analysis.json'
    target.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(dict(report=identity(target),steady_per_round=summary,top_kernels=[{k:r[k] for k in ('demangled_name','kernel_count','duration_sum_ms','share_of_kernel_duration_sum_percent')} for r in top[:5]]),ensure_ascii=False))


if __name__=='__main__':
    main()
