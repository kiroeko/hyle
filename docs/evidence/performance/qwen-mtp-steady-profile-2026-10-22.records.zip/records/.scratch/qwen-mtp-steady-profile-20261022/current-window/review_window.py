"""Offline independent scalar/work/memory review of the completed four-arm window."""
from pathlib import Path
import hashlib
import itertools
import json
import math
import re
import statistics

S=Path(__file__).resolve().parent
ROOT=S.parents[2]
ARMS=('hyle_plain','hyle_mtp','peer_plain','peer_mtp')
KEYS=('working_set_bytes','private_commit_bytes','gpu_dedicated_bytes','gpu_shared_bytes','gpu_total_bytes')


def unique(items):
    result={}
    for k,v in items:
        if k in result:raise ValueError('duplicate JSON key: '+k)
        result[k]=v
    return result


def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'),object_pairs_hook=unique)
def stat(v):return dict(count=len(v),median=statistics.median(v) if v else None,min=min(v) if v else None,max=max(v) if v else None)
def close(a,b):return math.isclose(a,b,rel_tol=1e-11,abs_tol=1e-10)
def ident(p):
    p=Path(p);b=p.read_bytes()
    return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def without_times(v):
    if isinstance(v,dict):return {k:without_times(x) for k,x in v.items() if k!='seconds' and not k.endswith('_seconds')}
    if isinstance(v,list):return [without_times(x) for x in v]
    return v


def main():
    sources=[]
    allruns={mode:read(S/mode/'runs.json') for mode in ('timing','memory')}
    summaries={mode:read(S/mode/'summary.json') for mode in allruns}
    assert len(allruns['timing'])==12 and len(allruns['memory'])==4
    readies={a:read(ROOT/('.scratch/qwen-cublas-scores-20261022/qwen-ready-attempt1.json' if a.startswith('hyle') else '.scratch/qwen-mtp-window-20261022/peer-ready-attempt1.json')) for a in ARMS}
    rawruns={a:[] for a in ARMS};metrics={a:[] for a in ARMS}
    for mode,runs in allruns.items():
        for run in runs:
            p=Path(run['folder']);arm=run['arm'];process=read(p/'result.json')
            assert process['exit']==0 and process['reader_errors']==[] and process['profiler'] is False
            assert process['image']==readies[arm]['image'] and process['command'][0]==readies[arm]['image']['path']
            assert process['memory_only']==(mode=='memory')
            rawpath=p/'consumer-result.json'
            if rawpath.exists():raw=read(rawpath)
            else:
                rawpath=p/'stdout.log'
                raw=json.loads(next(x for x in reversed(rawpath.read_text(encoding='utf-8-sig').splitlines()) if x.startswith('{')),object_pairs_hook=unique)
            assert raw==run['observation']['raw']==read(p/'observation.json')['raw']
            ids=raw['generated_ids'];assert len(ids)==raw['generated_tokens']==64 and not any(x in (248044,248046) for x in ids)
            assert raw['generated_decode_tokens']==63 and raw['requested_steps']==64
            assert raw['visible_tokens']==217 and raw['prefill_target_rows']==154
            pref,dec,session=[raw[k] for k in ('prefill_seconds','decode_seconds','session_seconds')]
            assert close(pref+dec,session)
            startup=raw['startup_to_endpoint_seconds'];ready=raw['startup_to_ready_seconds']
            if arm.startswith('hyle'):
                assert raw['score_dtype']=='F32' and raw['score_policy']=='bf16_inputs_f32_output'
                load=float(re.search(r'^weights_load_seconds=([^\s]+)',(p/'stderr.log').read_text(encoding='utf-8-sig'),re.M)[1])
                ttft=raw['first_token_elapsed_seconds']
                assert raw['diagnostic'] is False
            else:
                load=raw['weights_load_seconds'];ttft=startup-dec
            assert 0<load<=ready<=ttft<=startup+2e-6
            calculated=dict(prefill_tokens_per_second=154/pref,full_decode_tokens_per_second=63/dec,
                session_output_tokens_per_second=64/session,session_processed_tokens_per_second=217/session,
                prefill_seconds=pref,decode_seconds=dec,session_seconds=session,
                weights_load_seconds=load,startup_to_ready_seconds=ready,
                first_token_elapsed_seconds=ttft,startup_to_endpoint_seconds=startup,cold_output_tokens_per_second=64/startup)
            for k,v in calculated.items():assert close(v,run['observation']['metrics'][k]),(arm,k)
            assert close(raw['prefill_tokens_per_second'],154/pref)
            assert close(raw['decode_output_tokens_per_second'],63/dec)
            assert close(raw['output_tokens_per_second'],64/session)
            rounds=raw.get('rounds',[])
            if rounds:
                generated=[ids[0]];committed=verified=drafted=accepted=0
                for r in rounds:
                    assert r['pending']==generated[-1]
                    count=r['committed_target_rows'];assert count in (1,2)
                    emitted=r.get('emitted')
                    if emitted is None:emitted=[r['draft'],r['target_second']] if count==2 else [r['target_first']]
                    assert len(emitted)==count
                    generated+=emitted;committed+=count;drafted+=r['draft_rows']
                    verified+=r.get('verified_target_rows',2)
                    accepted+=int(r['accepted_draft'])
                    if 'target_before' in r:assert r['target_after']==r['target_before']+count
                assert generated==ids and committed==63 and verified==raw['verified_target_rows']
                assert drafted==raw.get('draft_rows',raw.get('draft_decode_rows'))
                assert accepted==raw['accepted_drafts']
                assert raw['actual_target_rows']==154+verified and raw['actual_draft_rows']==raw['prefill_draft_rows']+drafted
            if mode=='timing':metrics[arm].append(calculated)
            rawruns[arm].append(dict(mode=mode,raw=raw,work=run['observation']['work'],folder=p))
            sources.extend([ident(p/'result.json'),ident(rawpath)])
    within={}
    for arm,rows in rawruns.items():
        first=rows[0]
        stable=dict(IDs=all(r['raw']['generated_ids']==first['raw']['generated_ids'] for r in rows),
                    exported_work=all(r['work']==first['work'] for r in rows),
                    non_time_decisions=all(without_times(r['raw'].get('rounds'))==without_times(first['raw'].get('rounds')) for r in rows))
        assert len(rows)==4 and all(stable.values())
        within[arm]=dict(timing_processes=3,memory_processes=1,actual_output_lengths=[64]*4,all_stable=True,**stable)
    timing={}
    for arm,rows in metrics.items():
        timing[arm]={k:stat([r[k] for r in rows]) for k in rows[0]}
        for k,v in timing[arm].items():
            g=summaries['timing']['groups'][arm][k]
            assert g['count']==v['count'] and all(close(g[x],v[x]) for x in ('median','min','max'))
    pairs={}
    for left,right in itertools.combinations(ARMS,2):
        a,b=[rawruns[k][0]['raw']['generated_ids'] for k in (left,right)]
        index=next((i for i,(x,y) in enumerate(zip(a,b)) if x!=y),None)
        actual=summaries['timing']['between_arm_first_process_outputs'][left+'__'+right]
        assert actual['first_divergence']==index and actual['equal']==(a==b)
        pairs[left+'__'+right]=dict(same_64_IDs=a==b,first_differing_index_zero_based=index,
            left_token=a[index] if index is not None else None,right_token=b[index] if index is not None else None,
            overlapping_mismatches=sum(x!=y for x,y in zip(a,b)))
    memory={}
    peak_mapping=dict(sampled_max_working_set_bytes='working_set_bytes',observed_os_peak_working_set_bytes='os_peak_working_set_bytes',
        sampled_max_private_commit_bytes='private_commit_bytes',observed_os_peak_commit_bytes='os_peak_commit_bytes',
        sampled_peak_gpu_dedicated_bytes='gpu_dedicated_bytes',sampled_peak_gpu_shared_bytes='gpu_shared_bytes',sampled_peak_gpu_total_bytes='gpu_total_bytes')
    for run in allruns['memory']:
        arm=run['arm'];p=Path(run['folder']);sampled=read(p/'memory.json');summary=read(p/'memory-summary.json');record=read(p/'result.json')
        samples=sampled['samples'];running=[x for x in samples if x.get('process_running')]
        peaks={dest:max((x[key] for x in samples if x.get(key) is not None),default=None) for dest,key in peak_mapping.items()}
        assert peaks==summary['sampled_peaks']==sampled['peaks']
        for row in samples:
            a,b=row.get('gpu_dedicated_bytes'),row.get('gpu_shared_bytes')
            assert row.get('gpu_total_bytes')==(a+b if a is not None and b is not None else None)
        gaps=stat([(b['timestamp_ns']-a['timestamp_ns'])/1e6 for a,b in zip(running,running[1:])])
        costs=stat([x['sample_duration_ns']/1e6 for x in running if 'sample_duration_ns' in x])
        for value,key in ((gaps,'actual_sample_gaps_ms'),(costs,'sample_cost_ms')):
            assert all(close(value[k],summary[key][k]) for k in ('min','median','max')) and value['count']==summary[key]['count']
        nulls={k:sum(x.get(k) is None for x in samples) for k in KEYS};assert nulls==summary['null_sample_counts']
        phases={}
        for phase,window in summary['phase_windows'].items():
            begin,end=window['begin_ns'],window['end_ns']
            markers=record['markers']
            assert [x['timestamp_ns'] for x in markers if x['name']==phase+'_begin']==[begin]
            assert [x['timestamp_ns'] for x in markers if x['name']==phase+'_end']==[end]
            assert not any(window[k] for k in ('missing_boundary','ambiguous_boundary','invalid_boundary_order'))
            selected=[x for x in running if begin<=x['timestamp_ns']<=end]
            assert len(selected)==window['sample_count']
            values={k:stat([x[k] for x in selected if x.get(k) is not None]) for k in KEYS}
            for key,value in values.items():
                assert value['count']==window['values'][key]['count']
                for attr in ('min','median','max'):assert value[attr]==window['values'][key][attr]
            phases[phase]=dict(parent_received_begin_ns=begin,parent_received_end_ns=end,sample_count=len(selected),
                sampled_max_bytes={k:v['max'] for k,v in values.items()},null_counts=window['null_sample_counts'],
                missing_or_ambiguous=False,exact_endpoint_or_allocation_values=False)
        ready=summary['ready_baseline'];ready_rows=[x for x in running if ready['ready_marker_ns']<=x['timestamp_ns']<=ready['first_prefill_marker_ns']]
        assert ready['unknown']==(not ready_rows) and ready['sample']==(ready_rows[-1] if ready_rows else None)
        assert sampled['gpu_setup_error'] is None and sampled['thread_error'] is None
        memory[arm]=dict(sample_count=len(samples),running_sample_count=len(running),sampled_peaks_bytes=peaks,
            sampled_peaks_GiB={k:v/2**30 if v is not None else None for k,v in peaks.items()},
            phases=phases,actual_running_sample_gap_ms=gaps,sample_cost_ms=costs,
            null_counts=nulls,ready_baseline_unknown=ready['unknown'],ready_baseline_sample=ready['sample'],
            requested_interval_seconds=sampled['requested_interval_s'],throughput_evidence=False)
        sources.extend([ident(p/'memory.json'),ident(p/'memory-summary.json')])
    comparison={}
    for left,right in [('hyle_plain','hyle_mtp'),('peer_plain','peer_mtp'),('peer_plain','hyle_plain'),('peer_mtp','hyle_mtp')]:
        comparison[left+'__'+right]=dict(right_vs_left_median_percent={k:100*(timing[right][k]['median']/timing[left][k]['median']-1)
            for k in ('prefill_tokens_per_second','full_decode_tokens_per_second','session_output_tokens_per_second','startup_to_endpoint_seconds')},
            same_64_IDs=rawruns[left][0]['raw']['generated_ids']==rawruns[right][0]['raw']['generated_ids'],
            interpretation='Observed natural workload; no quality pass or same-token cross-arm guarantee.')
    work={a:dict(exported=rows[0]['work'],round_count=len(rows[0]['raw'].get('rounds',[])),
        score_policy=rows[0]['raw'].get('score_policy'),precision_note=rows[0]['raw'].get('precision_note'),
        target_sampling=rows[0]['raw'].get('target_sampling'),draft_sampling=rows[0]['raw'].get('draft_sampling')) for a,rows in rawruns.items()}
    report=dict(status='FROZEN_HOST_ONLY_ACTUAL_WINDOW_REVIEW',counts=dict(timing_processes=12,memory_processes=4,model_processes=16),
        verification=dict(all_exit_zero=True,within_arm_stable=True,actual_raw_matches_observations=True,
            timing_metrics_and_summaries_recomputed=True,memory_peaks_gaps_and_phase_coverage_recomputed=True,
            all64_outputs=True,all_timing_P_plus_D_equals_session=True,same_current_images_as_ready=True),
        timing=timing,within_arm_work=within,cross_arm_IDs=pairs,comparison=comparison,work=work,independent_memory=memory,
        scope=dict(prompt_tokens=154,requested_output_tokens=64,capacity=1024,N=1,R=1,former_windows_pooled=False,
            new_native_processes_by_reviewer=0,builds_by_reviewer=0,GPU_runs_by_reviewer=0,quality_pass=False),
        limits=['Only this current AD/V four-arm window; do not pool prior windows or the rejected scratch candidate screen.',
            'Three timing runs per arm give descriptive median/min/max, not statistical significance. Each process ratio is calculated first; no pooled token/time result.',
            'All16 processes emitted64 natural IDs, but cross-arm continuations differ. Hyle plain vs peer plain first differs at index18; work and acceptance are explicit, not presumed identical.',
            'Both Hyle modes export BF16-input/F32-output scores. Native GGUF small weights/recurrent math and reductions differ; dtype labels do not prove identical arithmetic or quality.',
            'Memory has one separate process per arm. Sampled peaks are lower bounds; dedicated/shared separate maxima cannot be added as a physical sum. Total is recomputed from simultaneous samples.',
            'Parent stderr markers only approximate memory phase bounds; exact timing uses existing consumer endpoints. Empty/null ready samples remain unknown. Actual sample cadence is reported, not assumed10ms.'],
        sources=[ident(S/'performance.py'),ident(S/'arms.json'),ident(S/'review_window.py'),*[ident(S/m/'summary.json') for m in ('timing','memory')],*sources])
    out=S/'review/actual-window-review.json';out.parent.mkdir(exist_ok=True)
    out.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(dict(report=ident(out),medians={a:{k:timing[a][k]['median'] for k in ('prefill_tokens_per_second','full_decode_tokens_per_second','session_output_tokens_per_second')} for a in ARMS},cross_arm_IDs=pairs,memory={a:dict(dedicated_GiB=v['sampled_peaks_GiB']['sampled_peak_gpu_dedicated_bytes'],total_GiB=v['sampled_peaks_GiB']['sampled_peak_gpu_total_bytes'],gap_median_ms=v['actual_running_sample_gap_ms']['median'],phase_counts={k:w['sample_count'] for k,w in v['phases'].items()},ready_unknown=v['ready_baseline_unknown']) for a,v in memory.items()}),ensure_ascii=False))


if __name__=='__main__':main()
