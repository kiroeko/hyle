"""Publish AF only after root freezes final docs and the12+4current window.

Importing this file does nothing. No model/native/build command is executed.
SQLite is the portable profile record; .nsys-rep identity/commands stay as JSON.
"""
from pathlib import Path
import argparse
import difflib
import hashlib
import json
import re
import zipfile

S = Path(__file__).resolve().parent
R = S.parents[1]
O = R / 'docs/evidence/performance'
AD = R / '.scratch/qwen-cublas-scores-20261022'
V = R / '.scratch/qwen-mtp-window-20261022'
NAME = 'qwen-mtp-steady-profile-2026-10-22'
ARMS = ('hyle_plain', 'hyle_mtp', 'peer_plain', 'peer_mtp')
EXCLUDED_SUFFIXES = {'.exe', '.dll', '.obj', '.map', '.lib', '.exp', '.pdb', '.pyc', '.tmp',
                     '.nsys-rep', '.safetensors', '.gguf', '.bf16', '.f32', '.f16', '.bin'}
EXCLUDED_NAMES = {'published.json', 'cleanup-plan.json', 'cleanup-result.json',
                  'cleanup_script.ps1', 'cleanup-script.ps1', 'postconditions.json'}


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def save(path, value):
    Path(path).write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + '\n', encoding='utf-8')


def resolved(path):
    path = Path(path)
    return path.resolve() if path.is_absolute() else (R / path).resolve()


def identity(path):
    path = resolved(path)
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(8 << 20), b''):
            digest.update(chunk)
    return dict(path=str(path), bytes=path.stat().st_size, sha256=digest.hexdigest())


def verify(record):
    current = identity(record['path'])
    assert (current['bytes'], current['sha256']) == (record['bytes'], record['sha256']), record['path']
    return current


def successful(path):
    result = read(path)
    assert result['exit'] == 0, str(path)
    if 'terminal' in result:
        assert result['terminal'], str(path)
    return identity(path)


def ready(path):
    value = read(path)
    verify(value['image'])
    verify(value['runtime_environment'])
    verify(value['link_plan'])
    return value


def validate(window_report):
    ordinary = ready(AD / 'qwen-ready-attempt1.json')
    peer = ready(V / 'peer-ready-attempt1.json')
    verify(ordinary['source'])
    verify(peer['source'])
    # Verify local current source and metadata only; never traverse SDK inputs.
    for item in ordinary['changed_sources']:
        verify(item)
    freeze = read(S / 'candidate/freeze.json')
    verify(freeze['source_basis'])
    assert freeze['public_or_product_changes'] is False
    for item in freeze['candidate_sources'] + freeze['required_source_dependencies'] + freeze['records']:
        verify(item)
    candidate = {mode: ready(S / f'candidate/{mode}-ready-attempt1.json') for mode in ('qwen', 'tests')}
    assert candidate['qwen']['main'] == ordinary['source']
    assert candidate['qwen']['replaced_inputs'] == 1 and candidate['qwen']['retained_inputs'] == 194
    assert candidate['tests']['replaced_inputs'] == 2 and candidate['tests']['retained_inputs'] == 196
    receipts = []
    for tag in ('cublas', 'test'):
        folder = S / 'candidate/compile1' / tag
        receipts.append(successful(folder / 'compile.result.json'))
        record = read(folder / 'identity.json')
        verify(record['source']); verify(record['object'])
        assert all(flag in record['command'] for flag in ('/O2', '/MD', '/W4', '/WX'))
    receipts += [successful(S / f'candidate/{mode}-link1/link.result.json') for mode in ('qwen', 'tests')]
    unit = successful(S / 'screen1/unit/run.result.json')
    stdout = (S / 'screen1/unit/run.stdout.log').read_text(encoding='utf-8-sig')
    assert re.search(r'\[\s*PASSED\s*\]\s+12 tests\.', stdout)
    assert not re.search(r'\[\s*(FAILED|SKIPPED)\s*\]', stdout)
    screens = [successful(S / 'screen1' / arm / 'run.result.json') for arm in ('before', 'after')]
    screen = read(S / 'screen1/summary.json')
    assert screen['all_selected_work_equal'] and screen['full_performance_window'] is False
    decision = read(S / 'review/candidate-decision.json')
    assert decision['decision'] == 'reject_this_candidate_keep_product_AD_unchanged'
    profile = successful(S / 'execution/attempt1/profile.result.json')
    export = successful(S / 'execution/attempt1/export.result.json')
    profile_receipt = read(S / 'execution/attempt1/receipt.json')
    verify(profile_receipt['report']); verify(profile_receipt['sqlite'])
    assert profile_receipt['image'] == ordinary['image']
    assert not profile_receipt['throughput_evidence'] and not profile_receipt['tensor_payload_trace']
    primary = read(S / 'review/actual-steady-analysis.json')
    independent = read(S / 'review/independent-steady-review.json')
    assert primary['status'] == 'FROZEN_HOST_ONLY_ACTUAL_STEADY_TIMELINE_ANALYSIS'
    assert primary['verification']['recovered_AD_IDs_rounds_work_all_equal']
    assert primary['verification']['steady_rounds'] == list(range(16, 35))
    assert primary['verification']['all_steady_recorded0_reused2']
    assert independent['status'] == 'FROZEN_FINITE_INDEPENDENT_PRIMARY_REVIEW'
    assert independent['verification']['independent19_clipped_kernel_and_busy_unions_match']
    report = read(window_report)
    # The final host analysis must be an explicit completed review, not a plan.
    assert 'status' in report and not any(x in report['status'].lower() for x in ('pending', 'awaiting', 'draft', 'plan_only'))
    windows = {}
    for mode, total, count in (('timing', 12, 3), ('memory', 4, 1)):
        folder = S / 'current-window' / mode
        summary = read(folder / 'summary.json'); runs = read(folder / 'runs.json')
        assert summary['status'] == 'complete_stable_within_arm_work'
        assert summary['within_arm_fixed_work_valid'] and summary['processes'] == total and len(runs) == total
        assert set(summary['within_arm_work']) == set(ARMS)
        for arm in ARMS:
            check = summary['within_arm_work'][arm]
            assert check['processes'] == count and check['stable']
            assert check['identical_IDs'] and check['identical_exported_work'] and check['identical_non_time_round_decisions']
            selected = [row for row in runs if row['arm'] == arm]
            assert len(selected) == count
            for row in selected:
                assert row['process']['exit'] == 0
                assert row['process']['memory_only'] == (mode == 'memory')
                assert row['process']['throughput_evidence'] == (mode == 'timing')
                expected = ordinary if arm.startswith('hyle') else peer
                assert row['process']['image'] == expected['image']
                assert resolved(row['folder']).is_relative_to(S / 'current-window')
        windows[mode] = dict(summary=identity(folder / 'summary.json'), runs=identity(folder / 'runs.json'),
                             processes=total, independent_analysis=identity(window_report))
    assert sum(x['processes'] for x in windows.values()) + 2 + 1 == 19
    return dict(ordinary=ordinary, peer=peer, candidate=candidate, freeze=freeze,
                compile_link_receipts=receipts, unit=unit, screens=screens, screen=screen,
                decision=decision, profile=profile, export=export, profile_receipt=profile_receipt,
                primary=primary, independent=independent, window_report=report, windows=windows)


def snapshot_docs():
    files = []
    for name, old in (('docs/developer/current-work.md', 'current-work.md'),
                      ('docs/developer/performance/decode.md', 'decode.md')):
        source = R / name; target = S / 'current' / name
        before = identity(source); data = source.read_bytes()
        target.parent.mkdir(parents=True, exist_ok=True)
        if target.exists():
            assert target.read_bytes() == data, 'existing final docs snapshot differs'
        else:
            target.write_bytes(data)
        verify(before)
        assert identity(target)['sha256'] == before['sha256']
        diff = S / 'current' / (old + '.diff')
        diff.write_text(''.join(difflib.unified_diff((S / 'before' / old).read_text(encoding='utf-8-sig').splitlines(True),
                                                   data.decode('utf-8-sig').splitlines(True),
                                                   fromfile='before/' + old, tofile=name)), encoding='utf-8')
        files.append(dict(source=before, snapshot=identity(target), before=identity(S / 'before' / old), diff=identity(diff)))
    save(S / 'docs-freeze.json', dict(files=files))
    return files


def included(path):
    relative = path.relative_to(S)
    return (path.is_file() and path.suffix.lower() not in EXCLUDED_SUFFIXES
            and path.name not in EXCLUDED_NAMES
            and not path.name.lower().startswith('cleanup')
            and not any(part in ('tmp', '__pycache__', 'publication-tmp') for part in relative.parts))


def publish(window_report):
    manifest = O / (NAME + '.json'); archive = O / (NAME + '.data.zip')
    assert not manifest.exists() and not archive.exists(), 'published artifacts must not be overwritten'
    data = validate(window_report)
    docs = snapshot_docs()
    profile_format = dict(canonical=verify(data['profile_receipt']['sqlite']),
        excluded_original_report=data['profile_receipt']['report'],
        profile_command=identity(S / 'execution/attempt1/profile.command.json'),
        export_command=identity(S / 'execution/attempt1/export.command.json'),
        profile_receipt=data['profile'], export_receipt=data['export'],
        reason='The exported SQLite is the portable canonical record for complete analysis and embedded ProcessStreams stdout/stderr. The original .nsys-rep is excluded from this archive as a duplicate representation; its original identity/export command/receipts remain preserved. No model rerun occurred for recovery.')
    save(S / 'profile-format.json', profile_format)
    bindings = dict(current_Hyle=data['ordinary'], native_peer=data['peer'],
                    current_main_unchanged=verify(data['ordinary']['source']),
                    current_cublas_unchanged=verify(data['freeze']['source_basis']),
                    candidate_freeze=identity(S / 'candidate/freeze.json'))
    save(S / 'artifact-bindings.json', bindings)
    reports = {name: identity(S / 'review' / name) for name in
               ('actual-steady-analysis.json', 'independent-steady-review.json', 'actual-execution-review.json',
                'candidate-decision.json', 'steady-source-map.json', 'small-m-source-review.json', 'image-next-slice.json')}
    summary = dict(status='Bounded actual profile/candidate/current-window evidence; candidate rejected and product unchanged; overall goal remains active',
        date='2026-10-22', product_code_changed=False, product_promotion=False,
        actual_model_processes=19, model_ledger=dict(profile=1, finite_candidate_screen=2, current_timing=12, independent_current_memory=4),
        unit_processes=1, unit_tests_passed=12,
        build_scope=dict(host_CXX_attempts=2, host_CXX_successes=2, link_attempts=2, link_successes=2,
                         scope='scratch candidate only; ordinary current consumer main retained', SDK_builds=0, NVCC_builds=0,
                         compile_link_receipts=data['compile_link_receipts']),
        artifact_bindings=bindings, docs_freeze=identity(S / 'docs-freeze.json'), reports=reports,
        final_current_window=data['windows'], final_window_review=identity(window_report),
        profile_format=profile_format,
        profile_findings=dict(verification=data['primary']['verification'],
                              steady_per_round_statistics=data['primary']['steady_summary']['per_round_statistics'],
                              diagnostics=data['primary']['diagnostics']),
        candidate=dict(decision=data['decision']['decision'], reason=data['decision']['reason'],
                       finite_screen=identity(S / 'screen1/summary.json'), unit=data['unit'], screen_receipts=data['screens']),
        limitations=[
          'One software-instrumented profile; driver13.4 warning says CUPTI13.3 libraries were used and hardware tracing unavailable. No tokens/s claim follows from profiled durations or kernel counts.',
          'Initial wrapper assumed target JSON appeared in nsys console output. Original failure script/logs are preserved; actual profile/export exited0 and host-only ProcessStreams recovery supplied IDs/work without another model process.',
          'The one-process-per-arm candidate screen passed finite numerical/unit checks but was slower; it was rejected, not promoted to product or added to the final current window.',
          'Final current-window comparison uses ordinary AD Hyle and retained native peer off/on images, three fresh timing processes plus one independent memory observation per arm. Use only the final host review for new numerical summaries; no historical window pooling.',
          'Natural IDs, actual target/draft verification work and native arithmetic can differ across modes/engines; no cross-arm same-token speed or full quality claim is assumed.',
          'Memory is sampled PSAPI/PDH WDDM dedicated/shared/WS/commit, not exact physical allocations. Missing counters/baselines stay null; CPU/GPU overlapping counters are not added as disjoint allocations.',
          'Image metadata inventory is research only. Full image inference, other backends, wider batch/session/model/quantization tasks and the overall goal remain unfinished.'],
        previous_evidence=['docs/evidence/performance/qwen-cublas-scores-2026-10-22.json',
                           'docs/evidence/performance/qwen-capture-cause-2026-10-22.json'])
    save(S / 'actual-summary.json', summary)
    files = sorted((path for path in S.rglob('*') if included(path)), key=lambda p: p.relative_to(S).as_posix())
    assert any(path.name == 'capture.sqlite' for path in files)
    assert not any(path.name == 'capture.nsys-rep' for path in files)
    assert any(path == resolved(window_report) for path in files), 'final review must be under AF'
    assert all(path.resolve().is_relative_to(S) for path in files), 'external SDK/model symlink not allowed'
    temporary = S / 'publication-tmp'; temporary.mkdir(exist_ok=True)
    staging = temporary / (NAME + '.data.zip.tmp')
    assert not staging.exists(), 'preserve a prior incomplete publication for root inspection'
    entries, unique = [], {}
    with zipfile.ZipFile(staging, 'x', zipfile.ZIP_DEFLATED, compresslevel=6) as z:
        for path in files:
            item = identity(path); key = item['bytes'], item['sha256']
            entry = unique.get(key)
            if entry is None:
                entry = path.relative_to(R).as_posix(); unique[key] = entry; z.write(path, entry)
            else:
                item['identical_content_alias'] = True
            item['entry'] = entry; entries.append(item)
    with zipfile.ZipFile(staging) as z:
        assert z.testzip() is None
        for (size, sha), entry in unique.items():
            digest = hashlib.sha256(); length = 0
            with z.open(entry) as stream:
                for chunk in iter(lambda: stream.read(8 << 20), b''):
                    digest.update(chunk); length += len(chunk)
            assert length == size and digest.hexdigest() == sha
    for item in entries: verify(item)
    for item in docs: verify(item['source'])
    O.mkdir(parents=True, exist_ok=True)
    staging.rename(archive)
    save(manifest, dict(**summary, archives=[identity(archive)], archive_files=entries,
                        archive_verified=dict(CRC=True, all_unique_entry_SHA256=True,
                                              source_files=len(entries), unique_entries=len(unique))))
    result = dict(manifest=identity(manifest), archives=[identity(archive)])
    save(S / 'published.json', result)
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--window-review', type=Path,
                        default=S / 'current-window/review/actual-window-review.json')
    args = parser.parse_args()
    publish(args.window_review.resolve())
