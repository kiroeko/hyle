"""Finite read-only check:19copy anchors,launch correlation,unions and4tops."""
from pathlib import Path
import hashlib
import json
import sqlite3
import statistics

S = Path(__file__).resolve().parents[1]


def identity(path):
    path = Path(path).resolve(); data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))


def union_ns(intervals, begin, end):
    intervals = sorted((max(a, begin), min(b, end)) for a, b in intervals if a < end and b > begin)
    total = 0; current = None
    for a, b in intervals:
        if current is None: current = [a, b]
        elif a <= current[1]: current[1] = max(current[1], b)
        else: total += current[1] - current[0]; current = [a, b]
    return total + (current[1] - current[0] if current else 0)


def main():
    primary_path = S / 'review/actual-steady-analysis.json'; primary = read(primary_path)
    db = S / 'execution/attempt1/capture.sqlite'
    con = sqlite3.connect('file:' + str(db.resolve()) + '?mode=ro', uri=True); con.row_factory = sqlite3.Row
    copies = [dict(x) for x in con.execute('select * from CUPTI_ACTIVITY_KIND_MEMCPY order by start')]
    dtoh = [x for x in copies if x['copyKind'] == 2]
    assert [x['bytes'] for x in dtoh] == [4] + [4, 8] * 34
    kernels = [dict(x) for x in con.execute('select start,end,correlationId,graphId,demangledName from CUPTI_ACTIVITY_KIND_KERNEL')]
    memset = [dict(x) for x in con.execute('select start,end from CUPTI_ACTIVITY_KIND_MEMSET')]
    strings = dict(con.execute('select id,value from StringIds'))
    launches = [dict(x) for x in con.execute("select a.start,a.end,a.correlationId,s.value from CUPTI_ACTIVITY_KIND_RUNTIME a join StringIds s on s.id=a.nameId where s.value like 'cudaGraphLaunch%'")]
    assert len(launches) == 68
    actual = read(S / 'execution/attempt1/recovered/observation.json')
    ad = read(S.parents[1] / '.scratch/qwen-cublas-scores-20261022/performance/timing/runs.json')
    baseline = next(x['observation'] for x in ad if x['arm'] == 'after_MTP')
    assert actual['generated_ids'] == baseline['generated_ids'] and actual['rounds'] == baseline['raw']['rounds']
    assert all(actual.get(key) == value for key, value in baseline['work'].items() if value is not None)
    per_round, selected_kernels = [], []
    previous = dtoh[0]['end']
    for index in range(34):
        final_copy = dtoh[2 + 2 * index]; begin, end = previous, final_copy['end']; previous = end
        original = primary['per_round'][index]
        assert original['round'] == index + 1 and original['begin_GPU_copy_end_ns'] == begin and original['end_GPU_copy_end_ns'] == end
        calls = sorted((x for x in launches if begin <= x['start'] < end), key=lambda x: x['start'])
        assert len(calls) == 2
        assert [x['correlationId'] for x in calls] == [x['correlationId'] for x in original['launches']]
        for call, expected in zip(calls, original['launches']):
            attached = [k for k in kernels if k['graphId'] and k['correlationId'] == call['correlationId']]
            assert len(attached) == expected['kernel_count']
        if index < 15: continue
        assert original['prepared']['recorded'] == 0 and original['prepared']['reused'] == 2
        active = [k for k in kernels if k['start'] < end and k['end'] > begin]
        selected_kernels += [(k, min(k['end'], end) - max(k['start'], begin)) for k in active]
        duration = sum(min(k['end'], end) - max(k['start'], begin) for k in active) / 1e6
        union = union_ns([(k['start'], k['end']) for k in active], begin, end) / 1e6
        busy = union_ns([(k['start'], k['end']) for k in active] +
                        [(x['start'], x['end']) for x in copies + memset], begin, end) / 1e6
        values = dict(interval_ms=(end-begin)/1e6, kernel_duration_sum_ms=duration,
                      kernel_union_ms=union, GPU_busy_union_ms=busy, GPU_inactive_ms=(end-begin)/1e6-busy)
        assert all(abs(value - original[key]) < 1e-9 for key, value in values.items())
        per_round.append(dict(round=index+1, begin_ns=begin, end_ns=end,
                              launch_correlations=[x['correlationId'] for x in calls], **values))
    assert len(per_round) == 19
    medians = {key: statistics.median(x[key] for x in per_round) for key in
               ('interval_ms', 'kernel_duration_sum_ms', 'kernel_union_ms', 'GPU_busy_union_ms', 'GPU_inactive_ms')}
    assert all(abs(value - primary['steady_summary']['per_round_statistics'][key]['median']) < 1e-9 for key, value in medians.items())
    selected_top = []
    for top in primary['steady_summary']['demangled_kernel_totals'][:4]:
        rows = [(k, duration) for k, duration in selected_kernels if strings[k['demangledName']] == top['demangled_name']]
        duration = sum(duration for _, duration in rows) / 1e6
        assert len(rows) == top['kernel_count'] and abs(duration - top['duration_sum_ms']) < 1e-9
        assert top['category'] == 'matrix_multiply'
        selected_top.append(dict(name=top['demangled_name'], count=len(rows), duration_sum_ms=duration,
                                 source_class='Library GEMM/GEMV matrix multiply; exact public-provider and layer assignment needs actual launch/route association, not name alone.'))
    matrix_names = {x['demangled_name'] for x in primary['steady_summary']['demangled_kernel_totals'] if x['category'] == 'matrix_multiply'}
    assert all(any(token in name.lower() for token in ('gemm', 'gemvx', 'mul_mat')) for name in matrix_names)
    matrix = sum(duration for k, duration in selected_kernels if strings[k['demangledName']] in matrix_names) / 1e6
    total = sum(duration for _, duration in selected_kernels) / 1e6
    share = matrix / total * 100
    warnings = [x['text'] for x in primary['diagnostics'] if any(t in x['text'].lower() for t in ('not supported', 'legacy', 'driver version'))]
    assert any('13.4' in x and '13.3' in x for x in warnings) and any('software' in x for x in warnings)
    report = dict(status='FROZEN_FINITE_INDEPENDENT_PRIMARY_REVIEW',
        sources=[identity(primary_path), identity(S / 'review/steady-source-map.json'), identity(S / 'review/small-m-source-review.json'),
                 identity(S / 'execution/attempt1/recovered/work-comparison.json'), identity(Path(__file__))],
        verification=dict(AD64_IDs_rounds_work_equal=True, all34_round_anchor_pairs_match=True,
                          all34_have_two_exact_launch_correlations=True, launch_kernel_counts_match=True,
                          steady_rounds=list(range(16,35)), steady_recorded0_reused2=True,
                          independent19_clipped_kernel_and_busy_unions_match=True, selected_top4_counts_durations_match=True),
        small_copy_order='35x4B+34x8B = prefill4B +34*(draft4B,target8B); original GPU end timestamps define intervals.',
        medians_ms=medians, matrix_kernel_cumulative_ms=matrix, total_kernel_cumulative_ms=total,
        matrix_kernel_cumulative_share_percent=share, selected_top4=selected_top,
        boundaries='Previous target8B GPU completion -> current target8B GPU completion, starting with prefill4B. These are device-completion anchors, not exact host endpoint/session walls.',
        source_classification='The selected top4 are genuine matrix kernel families. Actual route uses both direct cuBLASLt and a GGML paired draft-FFN region; GGML can itself call cuBLAS. No module/file table exists in this SQLite, so do not attribute all Kernel2 kernels to one public provider. GDN/conv/FlashInfer/softplus/copy/gather naming remains bounded by frozen source-map evidence.',
        driver_diagnostics=warnings,
        limits=['One software-instrumented profile with unsupported driver13.4/CUPTI13.3 compatibility warning; no hardware tracing. It is diagnostic, not tokens/s or a new performance comparison.',
                'GPU inactive is the complement of traced GPU activity, not CPU self-time or wholly recoverable cost. API waits overlap GPU busy; no addition into disjoint cost.',
                'Matrix92.46% is a cumulative kernel-duration share, not whole session wall share and not an optimization speedup bound.',
                'No global inactive-gap lists, every-kernel tables or peer trace are regenerated; primary immutable report remains authoritative for the full collection.',
                'Small-M candidate implementation and numerical validation are outside this review; no further activation-widen design is proposed.'],
        new_native_runs=0, builds=0, GPU_runs=0)
    output = S / 'review/independent-steady-review.json'
    output.write_text(json.dumps(report, indent=2, ensure_ascii=False)+'\n', encoding='utf-8')
    print(json.dumps(dict(report=identity(output), medians_ms=medians, matrix_kernel_share_percent=share)))


if __name__ == '__main__': main()
