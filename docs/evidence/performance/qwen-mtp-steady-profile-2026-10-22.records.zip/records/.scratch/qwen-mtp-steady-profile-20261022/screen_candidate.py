"""Finite candidate screen, not a complete performance comparison."""
from pathlib import Path
import argparse
import importlib.util
import json
import os
import sys

sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
R = S.parents[1]
AD = R / '.scratch/qwen-cublas-scores-20261022'
spec = importlib.util.spec_from_file_location('af_candidate_build', S / 'candidate_build.py')
h = importlib.util.module_from_spec(spec)
spec.loader.exec_module(h)
b, c = h.b, h.c

def run(name, ready_path, args):
    ready = c.read(ready_path)
    assert b.identity(ready['image']['path']) == ready['image']
    assert b.identity(ready['runtime_environment']['path']) == ready['runtime_environment']
    out = S / 'screen1' / name
    out.mkdir(parents=True, exist_ok=False)
    command = [ready['image']['path'], *args]
    env = os.environ.copy()
    env['PATH'] = c.read(ready['runtime_environment']['path'])['PATH']
    c.save(out / 'plan.json', dict(command=command, ready_record=b.identity(ready_path),
           limited_screen=True, full_performance_window=False,
           memory_measurement=False, tensor_trace=False))
    c.execute('run', command, env, out)
    return out

def unit():
    out = run('unit', S / 'candidate/tests-ready-attempt1.json', [])
    log = (out / 'run.stdout.log').read_text(encoding='utf-8-sig')
    assert '[  PASSED  ] 12 tests.' in log
    print('UNIT_OK_12')

def pair():
    assert c.read(S / 'screen1/unit/run.result.json')['exit'] == 0
    reference = c.read(AD / 'performance/timing/02-after_MTP/result.json')['command'][1:]
    observations = {}
    for name, ready in [('before', AD / 'qwen-ready-attempt1.json'),
                        ('after', S / 'candidate/qwen-ready-attempt1.json')]:
        out = run(name, ready, reference)
        data = json.loads((out / 'run.stdout.log').read_text(encoding='utf-8-sig').splitlines()[-1])
        c.save(out / 'observation.json', data)
        observations[name] = data
    fields = ['generated_ids', 'rounds', 'score_dtype', 'score_policy', 'generated_tokens',
              'actual_graph_calls', 'actual_target_rows', 'actual_draft_rows',
              'committed_target_rows', 'verified_target_rows', 'draft_rounds', 'accepted_drafts']
    equal = {key: observations['before'][key] == observations['after'][key] for key in fields}
    keys = ['prefill_tokens_per_second', 'decode_output_tokens_per_second',
            'output_tokens_per_second', 'startup_to_endpoint_seconds']
    stats = {name: {key: row[key] for key in keys} for name, row in observations.items()}
    result = dict(status='finite_one_process_per_arm_screen_complete', work_equal=equal,
                  all_selected_work_equal=all(equal.values()), metrics=stats,
                  ratios={key: stats['after'][key] / stats['before'][key] for key in keys},
                  full_performance_window=False, memory_measured=False,
                  limits='One unprofiled process/arm only. This screens a single native-geometry candidate; no statistical, allocation or quality claim. Current product remains AD.')
    c.save(S / 'screen1/summary.json', result)
    print(json.dumps(result, indent=2))

if __name__ == '__main__':
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('mode', choices=['unit', 'pair'])
    args = p.parse_args()
    unit() if args.mode == 'unit' else pair()
