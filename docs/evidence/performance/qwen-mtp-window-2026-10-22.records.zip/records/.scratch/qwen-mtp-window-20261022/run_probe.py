from pathlib import Path
import argparse,importlib.util,os,sys
sys.dont_write_bytecode=True
U=Path(__file__).resolve().parent;R=U.parents[1]
sp=importlib.util.spec_from_file_location('build',U/'build.py');h=importlib.util.module_from_spec(sp);sp.loader.exec_module(h);b,c=h.b,h.c
p=argparse.ArgumentParser();p.add_argument('tag',choices=('qwen','retirement'));p.add_argument('--attempt',type=int,default=1);p.add_argument('--image-attempt',type=int,default=1);a=p.parse_args()
out=U/f'{a.tag}-run{a.attempt}';out.mkdir(exist_ok=False);ready=c.read(U/f'{a.tag}-ready-attempt{a.image_attempt}.json')
assert h.same(ready['image'])and h.same(ready['main'])and h.same(ready['source'])
env=os.environ.copy();env['PATH']=c.read(ready['runtime_environment']['path'])['PATH']
command=[ready['image']['path'],'--inputs',str(R/'.scratch/qwen-mtp-weights-20261022/prepared'),'--mtp','on']
if a.tag=='retirement':command+=['--verify-rows','1']
if a.tag=='qwen':command+=['--steps','16','--capacity','64','--replay','commands','--trace',str(out/'trace')]
c.save(out/'identity.json',ready);c.save(out/'plan.json',dict(command=command,throughput_measurement=False,SDK_builds=0,native_rebuilds=0));c.execute('run',command,env,out)
