"""Write one fixed-source host compile/link recipe. Never execute a compiler."""
from pathlib import Path
import argparse
import hashlib
import json

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
OLD = ROOT / ".scratch/qwen-cli-batch-20261022/peer/checks/attempt1"
CACHE = ROOT / ".scratch/architecture-refactor-2026-10-18/llama-matched-consumer"


def read(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def identity(path):
    data = path.read_bytes()
    return {"path": str(path), "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--attempt", type=int, default=1)
    args = parser.parse_args()
    if args.attempt < 1:
        parser.error("attempt must be positive")
    output = HERE / "checks" / f"attempt{args.attempt}"
    source = HERE / "peer_mtp.cc"
    compile_command = read(OLD / "compile.command.json")["command"]
    compile_command = [
        str(source) if x == str(ROOT / ".scratch/qwen-cli-batch-20261022/peer-batch.cc")
        else x.replace(str(OLD), str(output)) for x in compile_command
    ]
    compile_command.insert(1, "/I" + str(CACHE / "source/src"))
    old_link = read(OLD / "link-plan.json")
    plan = {
        "status": "Prepared only. Root owns all compilation/link/native execution.",
        "cwd": str(ROOT), "output_directory": str(output), "source": identity(source),
        "compile": compile_command,
        "link": [x.replace(str(OLD), str(output)) for x in old_link["command"]],
        "retained_native_input_records_not_rehashed": old_link["inputs"][1:],
        "retained_link_reference": str(OLD / "link-plan.json"),
        "runtime_environment_reference": str(OLD / "runtime-environment.json"),
        "header_identities": [identity(CACHE / "source" / name) for name in
                              ["include/llama.h", "src/llama-ext.h", "src/llama-memory.h"]],
        "source_API_commit": "d9e03f1074dbd2979126d91dce1b5d304ec8394e",
        "new_CXX_TUs": 1, "new_links": 1, "SDK_builds": 0, "NVCC": 0,
    }
    plan_path = HERE / ("build-plan.json" if args.attempt == 1 else f"build-plan-attempt{args.attempt}.json")
    plan_path.write_text(json.dumps(plan, indent=2) + "\n", encoding="utf-8")
    cases = []
    for prompt in [15, 23]:
        for mode in ["off", "on"]:
            name = f"p{prompt}-{mode}"
            model = CACHE / ("Qwen3.5-2B-text-MTP-BF16.gguf" if mode == "on" else "Qwen3.5-2B-text-BF16.gguf")
            cases.append({"name": name, "command": [str(output / "peer.exe"), "--model", str(model),
                "--inputs", str(ROOT / ".scratch/qwen-mtp-weights-20261022/prepared"),
                "--prompt-rows", str(prompt), "--steps", "16", "--capacity", "64",
                "--mtp", mode, "--memory-snapshots", "off", "--output", str(HERE / name / "result.json")],
                "scope": "Unrun command example; parent controls actual timing/window workload and fresh output directories."})
    runs_path = HERE / ("run-plan.json" if args.attempt == 1 else f"run-plan-attempt{args.attempt}.json")
    runs_path.write_text(json.dumps({"cases": cases,
        "memory_policy": "Timing commands keep internal snapshots off. External observer runs separately; optional internal points never substitute for phase/process peaks.",
        "endpoint_policy": "Use executable steady-clock P/D/session/startup fields; phase markers only align external observer phases. No parent process wall denominator or warmup."}, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"source": plan["source"], "build_plan": str(plan_path), "run_plan": str(runs_path)}))


if __name__ == "__main__":
    main()
