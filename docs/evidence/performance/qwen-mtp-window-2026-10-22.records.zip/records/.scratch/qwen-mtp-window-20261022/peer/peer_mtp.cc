// Bounded measurement consumer. Fixed d9e03 llama/ggml math and native archives.
// No warmup, synthetic acceptance, separate weight copy or model-specific kernel.
#include "llama.h"
#include "llama-ext.h"
#include "llama-memory.h"
#include "ggml-backend.h"
#include "nlohmann/json.hpp"

#include <algorithm>
#include <chrono>
#include <cmath>
#include <cstdint>
#include <cstring>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <limits>
#include <memory>
#include <stdexcept>
#include <string>
#include <vector>

#if defined(_WIN32)
#define NOMINMAX
#define WIN32_LEAN_AND_MEAN
#define PSAPI_VERSION 2
#include <windows.h>
#include <psapi.h>
#endif

namespace peer_mtp {
using Json = nlohmann::ordered_json;
using Clock = std::chrono::steady_clock;
using Point = Clock::time_point;
using Tokens = std::vector<llama_token>;
using Model = std::unique_ptr<llama_model, decltype(&llama_model_free)>;
using Context = std::unique_ptr<llama_context, decltype(&llama_free)>;
using Sampler = std::unique_ptr<llama_sampler, decltype(&llama_sampler_free)>;

double seconds(Point end, Point begin) { return std::chrono::duration<double>(end - begin).count(); }
void require(bool value, const char * message) { if (!value) throw std::runtime_error(message); }
bool eos(llama_token id) { return id == 248044 || id == 248046; }

struct Backend final {
    Backend() { llama_backend_init(); }
    ~Backend() { llama_backend_free(); }
};

struct Batch final {
    // Draft uses the original API's explicit token+hidden-state representation.
    // llama_batch_free owns embd; token is this vector, never freed by that API.
    llama_batch value;
    Tokens draft_tokens;
    std::size_t capacity, embedding;
    Batch(std::size_t count, std::size_t width = 0)
        : value(llama_batch_init(static_cast<int32_t>(count), static_cast<int32_t>(width), 1)),
          draft_tokens(width ? count : 0), capacity(count), embedding(width) {
        if (embedding) value.token = draft_tokens.data();
    }
    ~Batch() { if (embedding) value.token = nullptr; llama_batch_free(value); }
    Batch(const Batch &) = delete;
    Batch & operator=(const Batch &) = delete;
    void fill(const Tokens & ids, std::size_t first, const std::vector<float> * hidden,
              bool all_outputs, bool last_output) {
        require(!ids.empty() && ids.size() <= capacity, "batch capacity exceeded");
        require((embedding != 0) == (hidden != nullptr), "draft hidden carrier mismatch");
        if (hidden) require(hidden->size() == ids.size() * embedding, "draft hidden row count mismatch");
        value.n_tokens = static_cast<int32_t>(ids.size());
        for (std::size_t row = 0; row < ids.size(); ++row) {
            value.token[row] = ids[row]; value.pos[row] = static_cast<llama_pos>(first + row);
            value.n_seq_id[row] = 1; value.seq_id[row][0] = 0;
            value.logits[row] = static_cast<int8_t>(all_outputs || (last_output && row + 1 == ids.size()));
        }
        if (hidden) std::memcpy(value.embd, hidden->data(), hidden->size() * sizeof(float));
    }
};

struct Drain final {
    llama_context * target, * draft;
    ~Drain() { if (target) llama_synchronize(target); if (draft) llama_synchronize(draft); }
};

Json memory(const char * name, Point start, ggml_backend_dev_t device) {
    const auto begin = Clock::now(); Json v{{"name", name}, {"elapsed_seconds", seconds(begin, start)}};
    v["unix_ms"] = std::chrono::duration_cast<std::chrono::milliseconds>(
        std::chrono::system_clock::now().time_since_epoch()).count();
#if defined(_WIN32)
    PROCESS_MEMORY_COUNTERS_EX p{}; p.cb = sizeof(p);
    if (GetProcessMemoryInfo(GetCurrentProcess(), reinterpret_cast<PROCESS_MEMORY_COUNTERS *>(&p), sizeof(p))) {
        v["working_set"] = p.WorkingSetSize; v["peak_working_set"] = p.PeakWorkingSetSize;
        v["private_commit"] = p.PrivateUsage; v["peak_commit"] = p.PeakPagefileUsage;
    }
#endif
    if (device) {
        std::size_t free_bytes = 0, total = 0; ggml_backend_dev_memory(device, &free_bytes, &total);
        v["device_free"] = free_bytes; v["device_total"] = total;
    }
    std::cerr << "measure_memory name=" << name << " elapsed_seconds=" << v["elapsed_seconds"]
              << " unix_ms=" << v["unix_ms"] << '\n';
    v["snapshot_seconds"] = seconds(Clock::now(), begin); return v;
}

std::size_t backing(llama_context * context) {
    std::size_t bytes = 0;
    for (const auto & allocation : llama_get_memory(context)->memory_breakdown()) {
        require(allocation.second <= (std::numeric_limits<std::size_t>::max)() - bytes, "cache byte overflow");
        bytes += allocation.second;
    }
    return bytes;
}

Json decode(llama_context * context, Batch & batch) {
    const auto begin = Clock::now(); const auto code = llama_decode(context, batch.value);
    const auto returned = Clock::now();
    require(code == 0, "original llama_decode failed");
    llama_synchronize(context); const auto retired = Clock::now();
    return {{"rows", batch.value.n_tokens}, {"decode_return_seconds", seconds(returned, begin)},
            {"synchronize_seconds", seconds(retired, returned)}, {"seconds", seconds(retired, begin)}};
}

Tokens sampled(llama_context * context, llama_sampler * sampler, std::size_t first, std::size_t rows,
               int32_t vocabulary) {
    Tokens ids; ids.reserve(rows);
    for (std::size_t i = first; i < first + rows; ++i) {
        const auto native = llama_get_sampled_token_ith(context, static_cast<int32_t>(i));
        require(native >= 0 && native < vocabulary, "GPU greedy output missing; CPU fallback is prohibited");
        require(native == llama_sampler_sample(sampler, context, static_cast<int32_t>(i)),
                "public/native greedy output mismatch");
        ids.push_back(native);
    }
    return ids;
}

std::vector<float> hidden(llama_context * context, std::size_t rows, std::size_t width) {
    std::vector<float> result(rows * width);
    for (std::size_t row = 0; row < rows; ++row) {
        const auto * h = llama_get_embeddings_nextn_ith(context, static_cast<int32_t>(row));
        require(h != nullptr, "target did not export every actual normalized hidden row");
        std::copy(h, h + width, result.begin() + static_cast<std::ptrdiff_t>(row * width));
    }
    require(std::all_of(result.begin(), result.end(), [](float f) { return std::isfinite(f); }),
            "nonfinite target hidden state");
    return result;
}

void position(llama_context * context, std::size_t length) {
    require(llama_memory_seq_pos_max(llama_get_memory(context), 0) == static_cast<llama_pos>(length) - 1,
            "native committed position differs from accepted boundary");
}
void trim(llama_context * context, std::size_t length) {
    require(llama_memory_seq_rm(llama_get_memory(context), 0, static_cast<llama_pos>(length), -1),
            "original context cannot remove unaccepted state");
    position(context, length);
}

struct Options final {
    std::filesystem::path model, inputs, output;
    std::size_t prompt_rows = 0, steps = 16, capacity = 64, max_rounds = 0;
    bool mtp = false, memory_snapshots = false;
};
std::size_t integer(const char * value) {
    std::size_t consumed = 0; const std::string s(value); const auto n = std::stoull(s, &consumed);
    require(consumed == s.size(), "invalid integer option"); return static_cast<std::size_t>(n);
}
Options options(int argc, char ** argv) {
    Options o;
    for (int i = 1; i < argc; ++i) {
        const std::string k = argv[i]; require(i + 1 < argc, "option requires a value"); const auto * v = argv[++i];
        if (k == "--model") o.model = v;
        else if (k == "--inputs") o.inputs = v;
        else if (k == "--output") o.output = v;
        else if (k == "--prompt-rows") o.prompt_rows = integer(v);
        else if (k == "--steps") o.steps = integer(v);
        else if (k == "--capacity") o.capacity = integer(v);
        else if (k == "--max-rounds") o.max_rounds = integer(v);
        else if (k == "--mtp" || k == "--memory-snapshots") {
            const std::string selected(v); require(selected == "on" || selected == "off", "expected on or off");
            (k == "--mtp" ? o.mtp : o.memory_snapshots) = selected == "on";
        }
        else throw std::runtime_error("unknown option: " + k);
    }
    require(!o.model.empty() && !o.inputs.empty(), "--model GGUF and --inputs DIR are required");
    require(o.capacity && o.capacity <= 4096 && o.steps && o.steps <= 1024,
            "bounded positive context<=4096 and output budget<=1024 required");
    require(o.output.empty() || !std::filesystem::exists(o.output), "output already exists");
    return o;
}

Json run(const Options & o) {
    const auto startup = Clock::now();
    std::ifstream input(o.inputs / "prompt.ids"); require(static_cast<bool>(input), "cannot open prompt.ids");
    Tokens prompt; int64_t token = 0;
    while (input >> token) {
        require(token >= 0 && token < (std::numeric_limits<llama_token>::max)(), "invalid prompt ID");
        prompt.push_back(static_cast<llama_token>(token));
    }
    require(input.eof() && !prompt.empty(), "invalid or empty prompt.ids");
    if (o.prompt_rows) { require(o.prompt_rows <= prompt.size(), "prompt rows exceed source IDs"); prompt.resize(o.prompt_rows); }
    require(prompt.size() + o.steps - 1 <= o.capacity, "prompt plus requested output inputs exceed context");
    Backend backend;
    auto * device = ggml_backend_dev_by_name("CUDA0");
    require(device && ggml_backend_dev_type(device) == GGML_BACKEND_DEVICE_TYPE_GPU, "CUDA0 GPU required");
    Json snapshots = Json::array(), phase_points = Json::array();
    const auto marker = [&](const char * name, Point point) {
        const auto unix_ms = std::chrono::duration_cast<std::chrono::milliseconds>(
            std::chrono::system_clock::now().time_since_epoch()).count();
        phase_points.push_back({{"name", name}, {"elapsed_seconds", seconds(point, startup)}, {"unix_ms", unix_ms}});
        if (std::string(name) == "ready_before_first") std::cerr << "measure_memory name=" << name;
        else std::cerr << "memory_phase=" << name;
        std::cerr << " elapsed_seconds=" << seconds(point, startup)
                  << " unix_ms=" << unix_ms << '\n';
    };
    if (o.memory_snapshots) snapshots.push_back(memory("before_model", startup, device));
    ggml_backend_dev_t devices[]{device, nullptr};
    auto mp = llama_model_default_params(); mp.devices = devices; mp.n_gpu_layers = 999; mp.load_mtp = o.mtp;
    const llama_model_tensor_buft_override overrides[]{
        {"^token_embd\\.weight$", ggml_backend_dev_buffer_type(device)}, {nullptr, nullptr}};
    mp.tensor_buft_overrides = overrides;
    const auto model_begin = Clock::now(); Model model(llama_model_load_from_file(o.model.string().c_str(), mp), &llama_model_free);
    const auto model_end = Clock::now(); require(static_cast<bool>(model), "cannot load combined target+MTP model");
    require(llama_model_n_layer(model.get()) == 24 && llama_model_n_layer_nextn(model.get()) == (o.mtp ? 1 : 0),
            "model metadata must match target-only or complete target+MTP mode");
    const auto width = static_cast<std::size_t>(llama_model_n_embd_out(model.get()));
    const auto vocabulary = llama_vocab_n_tokens(llama_model_get_vocab(model.get()));
    require(width && vocabulary > 0 && std::all_of(prompt.begin(), prompt.end(),
            [&](llama_token id) { return id < vocabulary; }), "prompt/model shape mismatch");
    Sampler target_sampler(llama_sampler_chain_init(llama_sampler_chain_default_params()), &llama_sampler_free);
    Sampler draft_sampler(nullptr, &llama_sampler_free);
    if (o.mtp) draft_sampler.reset(llama_sampler_chain_init(llama_sampler_chain_default_params()));
    require(target_sampler && (!o.mtp || draft_sampler), "cannot create original samplers");
    llama_sampler_chain_add(target_sampler.get(), llama_sampler_init_greedy());
    if (o.mtp) llama_sampler_chain_add(draft_sampler.get(), llama_sampler_init_greedy());
    llama_sampler_seq_config target_config{0, target_sampler.get()}, draft_config{0, draft_sampler.get()};
    auto cp = llama_context_default_params(); cp.n_ctx = static_cast<uint32_t>(o.capacity); cp.n_seq_max = 1;
    cp.n_outputs_max = o.mtp ? 2u : 1u; cp.n_outputs_max_per_seq = cp.n_outputs_max;
    cp.n_rs_seq = o.mtp ? 1u : 0u;
    cp.n_batch = static_cast<uint32_t>((std::max)(prompt.size(), o.mtp ? std::size_t{2} : std::size_t{1})); cp.n_ubatch = cp.n_batch;
    cp.n_threads = 24; cp.n_threads_batch = 24; cp.kv_unified = true;
    cp.type_k = GGML_TYPE_BF16; cp.type_v = GGML_TYPE_BF16; cp.flash_attn_type = LLAMA_FLASH_ATTN_TYPE_ENABLED;
    cp.samplers = &target_config; cp.n_samplers = 1;
    const auto contexts_begin = Clock::now(); Context target(llama_init_from_model(model.get(), cp), &llama_free);
    require(static_cast<bool>(target), "cannot create target context");
    Context draft(nullptr, &llama_free);
    if (o.mtp) {
        auto dp = cp; dp.ctx_type = LLAMA_CONTEXT_TYPE_MTP; dp.ctx_other = target.get(); dp.n_rs_seq = 0;
        dp.n_outputs_max = 1; dp.n_outputs_max_per_seq = 1; dp.samplers = &draft_config;
        draft.reset(llama_init_from_model(model.get(), dp));
        require(static_cast<bool>(draft), "cannot create draft context");
    }
    Drain drain{target.get(), draft.get()};
    const auto contexts_end = Clock::now();
    require(llama_n_ctx_seq(target.get()) >= o.capacity && llama_n_rs_seq(target.get()) == (o.mtp ? 1u : 0u),
            "effective target cache/rollback contract mismatch");
    if (o.mtp) require(llama_n_ctx_seq(draft.get()) >= o.capacity && llama_n_rs_seq(draft.get()) == 0,
                       "effective draft cache contract mismatch");
    if (o.mtp) llama_set_embeddings_nextn(target.get(), true, false);
    // K1 never feeds a speculative MTP hidden to another head. Only actual
    // normalized target hidden is exported; draft greedy stays on the device.
    if (o.mtp) llama_set_embeddings_nextn(draft.get(), false, true);
    Batch target_batch(cp.n_batch); std::unique_ptr<Batch> draft_batch;
    if (o.mtp) draft_batch = std::make_unique<Batch>(cp.n_batch, width);
    const auto target_backing = backing(target.get()), draft_backing = o.mtp ? backing(draft.get()) : 0;
    const auto ready = Clock::now(); marker("ready_before_first", ready);
    if (o.memory_snapshots) snapshots.push_back(memory("ready_before_first", startup, device));

    marker("generation_prefill_begin", Clock::now());
    const auto prefill_begin = Clock::now();
    target_batch.fill(prompt, 0, nullptr, false, true);
    auto target_prefill = decode(target.get(), target_batch);
    std::vector<float> target_hidden;
    if (o.mtp) target_hidden = hidden(target.get(), prompt.size(), width);
    const auto first = sampled(target.get(), target_sampler.get(), prompt.size() - 1, 1, vocabulary).front();
    Json draft_prefill = nullptr; std::vector<float> carry, prior;
    if (o.mtp) {
        std::vector<float> shifted(prompt.size() * width, 0.0f);
        if (prompt.size() > 1) std::copy(target_hidden.begin(), target_hidden.end() - static_cast<std::ptrdiff_t>(width),
                                      shifted.begin() + static_cast<std::ptrdiff_t>(width));
        draft_batch->fill(prompt, 0, &shifted, false, false);
        draft_prefill = decode(draft.get(), *draft_batch);
        trim(draft.get(), prompt.size());
        carry.assign(target_hidden.end() - static_cast<std::ptrdiff_t>(width), target_hidden.end());
    }
    position(target.get(), prompt.size());
    std::size_t length = prompt.size(), frontier = o.mtp ? length : 0, lag = 0;
    llama_token catchup = LLAMA_TOKEN_NULL, pending = first;
    const auto prefill_end = Clock::now();
    Json rounds = Json::array(); Tokens generated{first};
    std::size_t target_rows = 0, draft_rows = 0, target_calls = 0, draft_calls = 0;
    std::size_t proposals = 0, agreements = 0, accepts = 0;
    const auto decode_begin = prefill_end;
    marker("generation_prefill_end", prefill_end); marker("generation_decode_begin", decode_begin);
    while (generated.size() < o.steps && !eos(pending) && (!o.max_rounds || rounds.size() < o.max_rounds)) {
        const auto begin = Clock::now(); const auto base = length, old_frontier = frontier, old_lag = lag;
        if (o.mtp) require(frontier + lag == length && lag <= 1 && (lag == 0 || prior.size() == width), "inconsistent MTP entry frontier");
        const auto quota = o.steps - generated.size();
        const bool single = !o.mtp || quota == 1 || o.capacity - length == 1;
        Tokens draft_ids;
        std::vector<float> draft_hidden;
        Json dft = nullptr;
        if (o.mtp) {
            if (lag) { draft_ids.push_back(catchup); draft_hidden.insert(draft_hidden.end(), prior.begin(), prior.end()); }
            draft_ids.push_back(pending); draft_hidden.insert(draft_hidden.end(), carry.begin(), carry.end());
            draft_batch->fill(draft_ids, frontier, &draft_hidden, false, !single);
            dft = decode(draft.get(), *draft_batch); ++draft_calls; draft_rows += draft_ids.size();
            frontier += draft_ids.size(); require(frontier == length + 1, "draft frontier did not reach current input");
        }
        const auto proposed = single ? LLAMA_TOKEN_NULL : sampled(draft.get(), draft_sampler.get(), draft_ids.size() - 1, 1, vocabulary).front();
        Tokens verify{pending}; if (!single) verify.push_back(proposed);
        target_batch.fill(verify, length, nullptr, true, false);
        auto tgt = decode(target.get(), target_batch); ++target_calls; target_rows += verify.size();
        const auto ids = sampled(target.get(), target_sampler.get(), 0, verify.size(), vocabulary);
        std::vector<float> actual_hidden;
        if (o.mtp) actual_hidden = hidden(target.get(), verify.size(), width);
        const bool agreed = !single && proposed == ids[0];
        const bool accepted = agreed && quota >= 2 && !eos(ids[0]);
        const auto commit = accepted ? std::size_t{2} : std::size_t{1};
        // Select effective accepted state BEFORE any output counters or bonus.
        // Original n_rs_seq=1 restores all target conv/GDN members on rejection.
        length += commit;
        if (o.mtp) trim(target.get(), length); else position(target.get(), length);
        if (o.mtp) {
            trim(draft.get(), frontier);
            carry.assign(actual_hidden.begin() + static_cast<std::ptrdiff_t>((commit - 1) * width),
                         actual_hidden.begin() + static_cast<std::ptrdiff_t>(commit * width));
            if (accepted) { prior.assign(actual_hidden.begin(), actual_hidden.begin() + static_cast<std::ptrdiff_t>(width)); catchup = proposed; }
            else { prior.clear(); catchup = LLAMA_TOKEN_NULL; }
            lag = length - frontier; require(lag == (accepted ? 1u : 0u), "published draft lag mismatch");
        }
        Tokens emitted{ids[0]}; if (accepted) emitted.push_back(ids[1]);
        pending = emitted.back(); generated.insert(generated.end(), emitted.begin(), emitted.end());
        proposals += !single; agreements += agreed; accepts += accepted;
        const auto end = Clock::now();
        rounds.push_back({{"index", rounds.size()}, {"target_before", base}, {"draft_before", o.mtp ? Json(old_frontier) : Json(nullptr)}, {"lag_before", o.mtp ? Json(old_lag) : Json(nullptr)},
            {"pending", verify[0]}, {"draft", proposed}, {"target_ids", ids}, {"agreed", agreed}, {"accepted_draft", accepted},
            {"emitted", emitted}, {"quota_before", quota}, {"single", single}, {"verified_target_rows", verify.size()},
            {"committed_target_rows", commit}, {"draft_rows", draft_ids.size()}, {"target_after", length},
            {"draft_after", o.mtp ? Json(frontier) : Json(nullptr)}, {"lag_after", o.mtp ? Json(lag) : Json(nullptr)}, {"catchup_token", catchup},
            {"native_target_pos_max", llama_memory_seq_pos_max(llama_get_memory(target.get()), 0)},
            {"native_draft_pos_max", o.mtp ? Json(llama_memory_seq_pos_max(llama_get_memory(draft.get()), 0)) : Json(nullptr)},
            {"draft_compute", dft}, {"target_compute", tgt}, {"seconds", seconds(end, begin)}});
    }
    const auto endpoint = Clock::now(); marker("generation_decode_end", endpoint);
    if (o.memory_snapshots) snapshots.push_back(memory("after_journey", startup, device));
    const auto prefill_seconds = seconds(prefill_end, prefill_begin), decode_seconds = seconds(endpoint, decode_begin);
    const auto journey_seconds = seconds(endpoint, prefill_begin);
    return {{"scope", "Fixed d9e03 ordinary/K1 greedy consumer; no warmup or synthetic acceptance; no numerical-quality acceptance"},
        {"mtp", o.mtp}, {"memory_snapshots_enabled", o.memory_snapshots},
        {"model", o.model.string()}, {"inputs", o.inputs.string()}, {"prompt_ids", prompt}, {"requested_steps", o.steps},
        {"max_rounds", o.max_rounds}, {"generated_ids", generated}, {"prefill_first_id", first}, {"rounds", rounds},
        {"visible_tokens", length}, {"draft_frontier", o.mtp ? Json(frontier) : Json(nullptr)}, {"draft_lag", o.mtp ? Json(lag) : Json(nullptr)}, {"catchup_token", catchup},
        {"stopped_on_EOS", eos(pending)}, {"requested_context", o.capacity}, {"target_effective_context", llama_n_ctx_seq(target.get())},
        {"draft_effective_context", o.mtp ? Json(llama_n_ctx_seq(draft.get())) : Json(nullptr)}, {"target_n_rs_seq", llama_n_rs_seq(target.get())},
        {"draft_n_rs_seq", o.mtp ? Json(llama_n_rs_seq(draft.get())) : Json(nullptr)},
        {"target_sampling", "original native GPU greedy"}, {"target_sampling_outputs_per_sequence", o.mtp ? 2 : 1},
        {"draft_sampling", o.mtp ? Json("original native GPU greedy; configured1 last-row output") : Json(nullptr)},
        {"target_cache_backing_bytes", target_backing},
        {"draft_cache_backing_bytes", draft_backing}, {"shared_model_objects", 1}, {"native_contexts", o.mtp ? 2 : 1},
        {"startup_to_ready_seconds", seconds(ready, startup)}, {"weights_load_seconds", seconds(model_end, model_begin)},
        {"context_prepare_seconds", seconds(contexts_end, contexts_begin)}, {"startup_to_endpoint_seconds", seconds(endpoint, startup)},
        {"prefill_seconds", prefill_seconds}, {"decode_seconds", decode_seconds}, {"session_seconds", journey_seconds},
        {"prefill_tokens_per_second", prompt.size() / prefill_seconds},
        {"decode_output_tokens_per_second", generated.size() > 1 ? (generated.size() - 1) / decode_seconds : 0.0},
        {"output_tokens_per_second", generated.size() / journey_seconds},
        {"prefill_target_compute", target_prefill}, {"prefill_draft_compute", draft_prefill},
        {"prefill_target_rows", prompt.size()}, {"prefill_draft_rows", o.mtp ? prompt.size() : 0}, {"target_decode_calls", target_calls},
        {"draft_decode_calls", draft_calls}, {"verified_target_rows", target_rows}, {"committed_target_decode_rows", length - prompt.size()},
        {"draft_decode_rows", draft_rows}, {"generated_decode_tokens", generated.size() - 1}, {"proposals", proposals},
        {"agreements", agreements}, {"accepted_drafts", accepts}, {"memory", snapshots}, {"phase_points", phase_points},
        {"generated_tokens", generated.size()}, {"processed_tokens", length},
        {"actual_target_rows", prompt.size() + target_rows}, {"actual_draft_rows", o.mtp ? prompt.size() + draft_rows : 0},
        {"target_compute_calls", target_calls + 1}, {"draft_compute_calls", o.mtp ? draft_calls + 1 : 0},
        {"precision_note", "Original mostly-BF16 GGUF with F32 vectors/conv exceptions. MTP-on exports native F32 hidden/host carry; off exports no nextn hidden. No bit-equivalence with Hyle BF16 intermediate tree."},
        {"prefill_note", o.mtp ? Json("Original native MTP full block fills draft KV with output flags zero. Hyle computes only needed draft K/V prefix; all catch-up remains charged.") : Json("Original target-only prefill; no draft context, hidden export, cache, work or output.")},
        {"measurement_note", "Internal memory snapshots default off. Optional points are not continuous GPU/CPU peaks. Marker/control costs lie within shared P/D/session endpoints; memory-on runs are separate observations."}};
}
} // namespace peer_mtp

int main(int argc, char ** argv) {
    try {
        const auto options = peer_mtp::options(argc, argv); const auto result = peer_mtp::run(options);
        const auto text = result.dump(2) + '\n';
        if (!options.output.empty()) {
            if (options.output.has_parent_path()) std::filesystem::create_directories(options.output.parent_path());
            std::ofstream out(options.output, std::ios::binary); out << text;
            if (!out) throw std::runtime_error("cannot write result JSON");
        }
        std::cout << text; return 0;
    } catch (const std::exception & error) { std::cerr << "peer MTP error: " << error.what() << '\n'; return 1; }
}
