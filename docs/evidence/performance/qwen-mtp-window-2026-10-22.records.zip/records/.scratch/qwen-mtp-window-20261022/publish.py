"""Publish the actual natural-generation four-arm window and native writer-only retirement."""
from pathlib import Path
import difflib,hashlib,json,subprocess,zipfile
V=Path(__file__).resolve().parent;R=V.parents[1];O=R/'docs/evidence/performance';NAME='qwen-mtp-window-2026-10-22'
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def save(p,d):p.write_text(json.dumps(d,indent=2,ensure_ascii=False,allow_nan=False)+'\n',encoding='utf-8')
def identity(p):
 p=Path(p);h=hashlib.sha256()
 with p.open('rb')as f:
  for data in iter(lambda:f.read(8<<20),b''):h.update(data)
 return dict(path=str(p.resolve()),bytes=p.stat().st_size,sha256=h.hexdigest())
changed=['tools/qwen35_text/main.cc','tools/qwen35_text/retirement_probe.cc','tools/qwen35_text/README.md','docs/developer/current-work.md','docs/developer/performance/decode.md']
frozen=[]
for name in changed:
 p=R/name;snap=V/'current'/name;snap.parent.mkdir(parents=True,exist_ok=True);snap.write_bytes(p.read_bytes())
 record=dict(source=identity(p),snapshot=identity(snap));before=V/'before'/name
 if before.exists():
  diff=V/'product-diffs'/(name.replace('/','--')+'.diff');diff.parent.mkdir(exist_ok=True)
  diff.write_text(''.join(difflib.unified_diff(before.read_text(encoding='utf-8-sig').splitlines(True),p.read_text(encoding='utf-8-sig').splitlines(True),fromfile='before/'+name,tofile=name)),encoding='utf-8')
  result=subprocess.run(['git','diff','--no-index','--check',str(before),str(p)],capture_output=True,text=True,encoding='utf-8',errors='replace')
  assert result.returncode in(0,1)and not result.stdout.strip()and not result.stderr.strip(),(name,result.stdout,result.stderr)
  record.update(before=identity(before),diff=identity(diff),whitespace_diagnostics=[])
 frozen.append(record)
save(V/'product-freeze.json',dict(files=frozen))
ready={}
for tag in('qwen','retirement','peer'):
 p=V/f'{tag}-ready-attempt1.json';r=read(p)
 assert identity(r['image']['path'])==r['image'] and identity(r['source']['path'])==r['source']
 ready[tag]=r
retired=read(V/'retirement-run1/run.stdout.log')
assert retired['status']=='PASS'and retired['writer_only_draft']and retired['pending_target_query_rows']==1 and retired['pending_draft_query_rows']==2
assert retired['bound_append_banks']==14 and retired['actual_graph_submissions']==6
assert retired['managed_bytes_while_native_pending']==retired['managed_backing_bytes']==80240691
assert retired['old_recurrent_resources_byte_unchanged']==36 and not retired['selector_failure_published_head']and not retired['native_error_injected']
assert read(V/'retirement-run1/run.result.json')['exit']==0
timing=read(V/'performance/timing/summary.json');memory=read(V/'performance/memory/summary.json')
assert timing['processes']==12 and memory['processes']==4
for mode,count in(('timing',12),('memory',4)):
 runs=read(V/f'performance/{mode}/runs.json');assert len(runs)==count
 assert all(x['process']['exit']==0 and x['observation']['actual_generated_tokens']==64 for x in runs)
reports={p.name:read(p)for p in sorted((V/'review').glob('*.json'))}
summary=dict(status='Actual CUDA B1 natural-generation four-arm window and writer-only native retirement completed; broader goal active',
 date='2026-10-22',product_freeze=identity(V/'product-freeze.json'),inputs=read(V/'inputs/input.json'),ready=ready,
 timing=timing,memory=memory,reports=reports,writer_only_retirement=retired,
 build_scope=dict(new_Hyle_library_TUs=0,Hyle_consumer_TUs=2,peer_TUs=1,SDK_builds=0,NVCC_builds=0,full_configures=0),
 results_scope=['Same original BF16 target checkpoint family, same tokenizer154-token coding prompt, C1024/N1/R1,prefixoff, natural greedy up to64 IDs, EOS respected; all actual processes returned64.',
 'Three fresh unmonitored timing processes per arm, rotated arm order; four separate PSAPI/PDH(WDDM) memory processes. No memory timing is pooled into TPS, no warmup or forced acceptance.',
 'Hyle plain/MTP and peer plain have identical64 IDs. Peer MTP diverges at zero-based18; different follow-up tokens and acceptance work forbid treating its rate as equal-output performance or quality acceptance.',
 'Full prepare/capture/submit/wait/ID/publication endpoints charged. Peer includes its final round metadata whereas Hyle original endpoint precedes trailing reporting; offline conservative total round-gap bound is disclosed, official wall unchanged.',
 'All14 real append permissions retained while CUDA is blocked, even after stop and abandoned public Completion. Actual native retirement precedes reclaim and same-slot retry. Host selector rejection separately tested, no native GPU error injected.'],
 prior_evidence=['docs/evidence/correctness/qwen-mtp-retirement-2026-10-22.json','docs/evidence/correctness/qwen-mtp-round-2026-10-22.json','docs/evidence/performance/qwen-topone-prepared-2026-10-22.json'],
 limitations=['One short coding prompt and one card are not a general model quality or acceptance-rate test.',
 'Not a fixed multi-round/B2 performance replacement. Math/dtype/layout/rollback/resource contracts and native full draft vs KV-only draft work differ.',
 'Memory requested10ms with actual gaps retained. Peaks are sampled lower bounds; dedicated/shared separate peaks cannot be added. Missing ready baseline stays unknown. CPU WS/commit/GPU shared overlap.',
 'No native other-OS consumer or multi-session MTP tested. Selected models/quantization, image chain and broad architecture completion remain open.'],
 next=['Narrowly locate peer MTP first divergence before claiming matched-output MTP comparison; distinguish T1/T2 arithmetic from recurrent restore/carry/selection using actual outputs, not assumptions.',
 'Inspect actual cold/first-use capture and state/resource costs under MTP; preserve no-MTP baseline and all original lifetime guarantees.',
 'Continue multi-session MTP and remaining cross-platform/model/quant/image/architecture scope.'])
save(V/'actual-summary.json',summary)
excluded={'.exe','.dll','.obj','.map','.lib','.exp','.pdb','.pyc'}
files=sorted(p for p in V.rglob('*')if p.is_file()and p.suffix.lower()not in excluded and not any(x in('tmp','__pycache__')for x in p.relative_to(V).parts)and p.name not in('published.json','cleanup-plan.json','cleanup-result.json','cleanup_script.ps1'))
archive=O/(NAME+'.data.zip');assert not archive.exists();entries=[]
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=6)as z:
 for p in files:
  e=identity(p);e['entry']=p.relative_to(R).as_posix();z.write(p,e['entry']);entries.append(e)
with zipfile.ZipFile(archive)as z:
 assert z.testzip()is None and z.namelist()==[e['entry']for e in entries]
 for e in entries:
  raw=z.read(e['entry']);assert len(raw)==e['bytes']and hashlib.sha256(raw).hexdigest()==e['sha256']
manifest=O/(NAME+'.json');assert not manifest.exists()
save(manifest,dict(**summary,archives=[identity(archive)],archive_files=entries,archive_verified=dict(CRC=True,all_entry_SHA256=True,entries=len(entries),original_bytes=sum(x['bytes']for x in entries))))
published=dict(manifest=identity(manifest),archives=[identity(archive)]);save(V/'published.json',published)
print(json.dumps(dict(**published,files=len(entries),raw_bytes=sum(x['bytes']for x in entries)),indent=2))
