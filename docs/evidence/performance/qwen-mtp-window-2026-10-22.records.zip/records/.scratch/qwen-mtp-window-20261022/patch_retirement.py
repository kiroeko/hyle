from pathlib import Path
p=Path('tools/qwen35_text/retirement_probe.cc');s=p.read_text(encoding='utf-8');a=s.index('void run_mtp(');b=s.index('\n} // namespace',a);x=s[a:b]
def replace(old,new):
 global x
 assert old in x,old
 x=x.replace(old,new)
replace('void run_mtp(const std::filesystem::path &inputs) {','void run_mtp(const std::filesystem::path &inputs, std::size_t verify_rows) {\n  require(verify_rows == 1 || verify_rows == 2, "MTP verify rows must be one or two");')
replace('q::GraphRole::kMtpCatchupRound','catchup_role')
replace('  const std::array prefill{std::size_t{15}}, pair{std::size_t{2}};',
'''  const auto catchup_role = verify_rows == 1 ? q::GraphRole::kMtpCatchupSingle : q::GraphRole::kMtpCatchupRound;
  const std::array prefill{std::size_t{15}}, pair{std::size_t{2}}, catchup_calls{verify_rows};''')
replace('''  for (const auto role : {q::GraphRole::kMtpRound, catchup_role}) {
    model.prepare_family(pair, false, 1, role);
    model.plan_replay_uses(2, 1, 8, role);
  }''','''  model.prepare_family(pair, false, 1, q::GraphRole::kMtpRound);
  model.plan_replay_uses(2, 1, 8, q::GraphRole::kMtpRound);
  model.prepare_family(catchup_calls, false, 1, catchup_role);
  model.plan_replay_uses(verify_rows, 1, 8, catchup_role);''')
replace('  const std::array catchup_calls{std::size_t{2}};\n','')
replace('next->length == 19','next->length == 17 + verify_rows')
replace('model.finish_mtp_round(*recovered, 2)','model.finish_mtp_round(*recovered, verify_rows)')
replace('model.finish_mtp_round(*policy_session, 2)','model.finish_mtp_round(*policy_session, verify_rows)')
replace('ids.size() == 2 && step.draft_token >= 0','ids.size() == verify_rows && (verify_rows == 1 ? step.draft_token == -1 : step.draft_token >= 0)')
replace('std::this_thread::yield();','std::this_thread::sleep_for(std::chrono::milliseconds(1));')
replace('''            << ",\\\"pending_target_query_rows\\\":2,\\\"pending_draft_query_rows\\\":2,\\\"bound_append_banks\\\":14"
            << ",\\\"cancelled_candidate_target_tokens\\\":19,\\\"cancelled_candidate_draft_frontier\\\":18"''','''            << ",\\\"pending_target_query_rows\\\":" << verify_rows
            << ",\\\"writer_only_draft\\\":" << (verify_rows == 1 ? "true" : "false")
            << ",\\\"pending_draft_query_rows\\\":2,\\\"bound_append_banks\\\":14"
            << ",\\\"cancelled_candidate_target_tokens\\\":" << 17 + verify_rows
            << ",\\\"cancelled_candidate_draft_frontier\\\":18"''')
s=s[:a]+x+s[b:]
s=s.replace('    bool mtp = false;','    bool mtp = false;\n    std::size_t verify_rows = 2;')
s=s.replace('      else if (option == "--mtp") {','''      else if (option == "--verify-rows") {
        const std::string_view value(argv[i + 1]);
        if (value != "1" && value != "2") throw std::runtime_error("--verify-rows requires 1 or 2");
        verify_rows = value == "1" ? 1u : 2u;
      }
      else if (option == "--mtp") {''')
s=s.replace('(mtp && !tape.empty()))','(mtp && !tape.empty()) || (!mtp && verify_rows != 2))')
s=s.replace('[--decode-ids IDSFILE | --mtp on]','[--decode-ids IDSFILE | --mtp on [--verify-rows 1|2]]')
s=s.replace('if (mtp) run_mtp(inputs);','if (mtp) run_mtp(inputs, verify_rows);')
p.write_text(s,encoding='utf-8',newline='\n')
