"""Independent offline review of the frozen four-arm natural generation window.

Only raw JSON/stderr and external memory samples are read. The optional local
tokenizer decodes observed IDs; no model, Torch, GPU, build or candidate feedback.
"""
from __future__ import annotations

import hashlib
import json
import math
import os
from pathlib import Path
import re
import statistics
import sys

sys.dont_write_bytecode = True
S = Path(__file__).resolve().parents[1]
ARMS = ("hyle_plain", "hyle_mtp", "peer_plain", "peer_mtp")
KEYS = ("working_set_bytes", "private_commit_bytes", "gpu_dedicated_bytes", "gpu_shared_bytes", "gpu_total_bytes")
EOS = {248044, 248046}


def unique(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("duplicate JSON key: " + key)
        result[key] = value
    return result


def read(path):
    return json.loads(Path(path).read_text(encoding="utf-8-sig"), object_pairs_hook=unique)


def identity(path):
    path = Path(path).resolve()
    raw = path.read_bytes()
    return dict(path=str(path), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


def stats(values):
    return dict(count=len(values), median=statistics.median(values) if values else None,
                min=min(values) if values else None, max=max(values) if values else None)


def close(a, b):
    return math.isclose(a, b, rel_tol=1e-9, abs_tol=2e-8)


def raw_result(folder):
    path = folder / "consumer-result.json"
    if path.exists():
        return read(path), identity(path)
    path = folder / "stdout.log"
    line = next(line for line in reversed(path.read_text(encoding="utf-8").splitlines()) if line.startswith("{"))
    return json.loads(line, object_pairs_hook=unique), identity(path)


def ledger(raw, prompt, arm):
    ids = raw["generated_ids"]
    assert len(ids) == 64 and not any(x in EOS for x in ids)
    assert raw["generated_tokens"] == 64 and raw["generated_decode_tokens"] == 63
    assert raw["prefill_target_rows"] == prompt
    if "prompt_ids" in raw:
        assert raw["prompt_ids"] == read(S / "inputs/input.json")["prompt_ids"]
    mtp = arm.endswith("_mtp")
    assert raw["mtp"] == mtp and raw["visible_tokens"] == prompt + 63
    rounds = raw.get("rounds", [])
    if mtp:
        length = frontier = prompt
        lag, pending, at = 0, ids[0], 1
        totals = dict(rounds=0, proposals=0, accepted=0, agreements=0, verified=0, committed=0, draft=0)
        positions = []
        rejected = []
        for index, row in enumerate(rounds):
            target_ids = row.get("target_ids", [row.get("target_first"), row.get("target_second")])
            single = bool(row.get("single", row["draft"] == -1))
            if single:
                target_ids = target_ids[:1]
            query = 1 if single else 2
            assert row["pending"] == pending and row["draft_rows"] == lag + 1
            agreed = not single and row["draft"] == target_ids[0]
            accepted = agreed and len(ids) - at >= 2 and target_ids[0] not in EOS
            commit = 2 if accepted else 1
            emitted = target_ids[:commit]
            assert row["accepted_draft"] == accepted and row["committed_target_rows"] == commit
            assert ids[at:at + commit] == emitted
            if "agreed" in row:
                assert row["agreed"] == agreed
            if "emitted" in row:
                assert row["emitted"] == emitted
            if "target_before" in row:
                assert row["target_before"] == length and row["draft_before"] == frontier and row["lag_before"] == lag
                assert row["quota_before"] == len(ids) - at and row["verified_target_rows"] == query
                assert row["draft_compute"]["rows"] == lag + 1 and row["target_compute"]["rows"] == query
            position = dict(round_index=index, output_indices_zero_based=list(range(at, at + commit)),
                            pending=pending, draft=row["draft"], target_ids=target_ids, emitted=emitted,
                            accepted=accepted, target_length_before=length, draft_frontier_before=frontier, lag_before=lag)
            positions.append(position)
            if not accepted and not single:
                rejected.append(index)
            length += commit
            frontier += lag + 1
            lag = length - frontier
            assert lag in (0, 1) and lag == int(accepted)
            if "target_after" in row:
                assert row["target_after"] == length and row["draft_after"] == frontier and row["lag_after"] == lag
                assert row["native_target_pos_max"] == length - 1 and row["native_draft_pos_max"] == frontier - 1
                assert row["catchup_token"] == (row["draft"] if lag else -1)
            at += commit
            pending = emitted[-1]
            for key, amount in (("rounds", 1), ("proposals", not single), ("accepted", accepted),
                                ("agreements", agreed), ("verified", query), ("committed", commit), ("draft", row["draft_rows"])):
                totals[key] += amount
        assert at == 64 and pending == ids[-1] and length == raw["visible_tokens"]
        assert frontier == raw["draft_frontier"] and lag == raw["draft_lag"]
        assert totals["committed"] == 63 and raw["actual_target_rows"] == prompt + totals["verified"]
        assert raw["actual_draft_rows"] == prompt + totals["draft"]
        assert raw["verified_target_rows"] == totals["verified"]
        assert raw["accepted_drafts"] == totals["accepted"] and raw["agreements"] == totals["agreements"]
        assert raw.get("draft_rows", raw.get("draft_decode_rows")) == totals["draft"]
        if "actual_graph_calls" in raw:
            assert raw["actual_graph_calls"] == 1 + totals["rounds"]
        if "target_compute_calls" in raw:
            assert raw["target_compute_calls"] == raw["draft_compute_calls"] == 1 + totals["rounds"]
        if "proposals" in raw:
            assert raw["proposals"] == totals["proposals"]
        return dict(**totals, rejected_round_indices=rejected, target_computed_rows=raw["actual_target_rows"],
                    draft_computed_rows=raw["actual_draft_rows"], target_committed_rows=length,
                    rejected_verify_rows=totals["verified"] - totals["committed"], final_draft_frontier=frontier,
                    final_lag=lag, accepted_per_actual_proposal=totals["accepted"] / totals["proposals"],
                    accepted_as_fraction_of63new_outputs=totals["accepted"] / 63,
                    original_Graph_episodes=raw.get("actual_graph_calls"),
                    peer_native_target_calls=raw.get("target_compute_calls"), peer_native_draft_calls=raw.get("draft_compute_calls"),
                    all_emitted_ID_length_frontier_and_native_position_checks=True), positions
    assert raw["actual_target_rows"] == prompt + 63 and raw["actual_draft_rows"] == 0
    assert raw["verified_target_rows"] == 63 and raw["accepted_drafts"] == 0
    assert raw.get("actual_graph_calls", raw.get("target_compute_calls")) == 64
    if "decode_input_ids" in raw:
        assert raw["decode_input_ids"] == ids[:-1]
    if rounds:
        assert len(rounds)==63
        for i,row in enumerate(rounds):
            assert row["pending"]==ids[i] and row["target_ids"]==[ids[i+1]]
            assert row["single"] and not row["accepted_draft"] and row["committed_target_rows"]==1
            assert row["draft_rows"]==0 and row["target_before"]==prompt+i and row["target_after"]==prompt+i+1
            assert row["native_target_pos_max"]==prompt+i and row["target_compute"]["rows"]==1
    return dict(target_computed_rows=prompt + 63, target_committed_rows=prompt + 63, draft_computed_rows=0,
                original_Graph_episodes=raw.get("actual_graph_calls"), peer_native_target_calls=raw.get("target_compute_calls"),
                peer_native_draft_calls=raw.get("draft_compute_calls"), accepted_per_actual_proposal=None,
                all_emitted_ID_length_frontier_and_native_position_checks=True), []


def timing_row(folder, arm, prompt):
    raw, source = raw_result(folder)
    terminal = read(folder / "result.json")
    assert terminal["exit"] == 0 and not terminal.get("timeout")
    p, d, session = (raw[k] for k in ("prefill_seconds", "decode_seconds", "session_seconds"))
    assert close(p + d, session)
    startup, ready = raw["startup_to_endpoint_seconds"], raw["startup_to_ready_seconds"]
    ttft = raw.get("first_token_elapsed_seconds", startup - d)
    assert close(ttft + d, startup)
    stderr = (folder / "stderr.log").read_text(encoding="utf-8")
    load = raw.get("weights_load_seconds")
    if load is None:
        load = float(re.search(r"^weights_load_seconds=([^\s]+)", stderr, re.MULTILINE)[1])
    assert 0 < load <= ready <= ttft <= startup
    work, positions = ledger(raw, prompt, arm)
    metrics = dict(prefill_tps=prompt / p, full_decode_tps=63 / d,
                   session_output_tps=64 / session, session_processed_target_tps=217 / session,
                   prefill_seconds=p, decode_seconds=d, session_seconds=session,
                   load_seconds=load, ready_seconds=ready, startup_TTFT_seconds=ttft,
                   startup_endpoint_seconds=startup, cold_output_tps=64 / startup)
    captures = prepare_facts(stderr, raw, positions, arm) if arm.startswith("hyle") else None
    return dict(arm=arm, folder=str(folder), raw=source, stderr=identity(folder / "stderr.log"),terminal=identity(folder / "result.json"),
                metrics=metrics, work=work, prepare_capture=captures, ids=raw["generated_ids"]), positions


def prepare_facts(stderr, raw, positions, arm):
    lines = stderr.splitlines()
    prepared = []
    for i,line in enumerate(lines):
        if not line.startswith("prepared T="):
            continue
        fields = dict(re.findall(r"(\w+)=([^\s]+)", line))
        name = lines[i+1].split()[0]
        if not (name == "prefill" or re.fullmatch(r"(?:mtp|decode)\d+", name)):
            raise ValueError("prepared record is not paired with one original evaluate endpoint")
        row = dict(name=name,T=int(fields["T"]),visible=int(fields["visible"]),replay=fields["replay"],
                   cold_batch_seconds=float(fields["cold_batch_seconds"]),
                   recorded=int(fields["capture_recorded"]),reused=int(fields["capture_reused"]))
        if name == "prefill":
            role="MtpPrefill" if arm.endswith("_mtp") else "TextPrefill"
        elif arm.endswith("_mtp"):
            round_=positions[int(name[3:])-1]
            role=("MtpCatchup" if round_["lag_before"] else "Mtp")+("Round" if row["T"]==2 else "Single")
        else: role="TextDecode"
        row["role_from_actual_round_ledger"]=role
        prepared.append(row)
    assert len(prepared)==raw["actual_graph_calls"]
    totals={key:sum(r[key] for r in prepared) for key in ("cold_batch_seconds","recorded","reused")}
    decode=[r for r in prepared if r["name"]!="prefill"]
    assert sum(r["recorded"]+r["reused"] for r in decode)==len(decode)*(2 if arm.endswith("_mtp") else 1)
    byrole={}
    for role in sorted({r["role_from_actual_round_ledger"] for r in prepared}):
        own=[r for r in prepared if r["role_from_actual_round_ledger"]==role]
        byrole[role]=dict(calls=len(own),T=sorted({r["T"]for r in own}),
                         cold_batch_seconds_sum=sum(r["cold_batch_seconds"]for r in own),
                         recorded=sum(r["recorded"]for r in own),reused=sum(r["reused"]for r in own),
                         calls_recording_any=sum(r["recorded"]>0 for r in own))
    decode_sum=sum(r["cold_batch_seconds"]for r in decode)
    return dict(calls=len(prepared),totals=totals,
                decode_cold_batch_seconds_sum=decode_sum,
                decode_cold_batch_fraction_of_full_decode=decode_sum/raw["decode_seconds"],
                by_role_and_T=byrole, actual_slots=None,
                slot_scope="Runtime lines contain T/visible/replay but no actual slot index; no slot attribution is invented.",
                recorded_episode_names=[r["name"] for r in prepared if r["recorded"]],
                limits="Host replay-report range counts, not native kernel/GraphLaunch counts. Plain has one captured subrange per decode call; MTP T2 can have two. Cold-batch is the full prepare wall bucket, not a measured function self-time or proof of redundant planning.")


def memory_row(folder):
    sampled = read(folder / "memory.json")
    receipt = read(folder / "result.json")
    assert receipt["exit"] == 0 and receipt["memory_only"] and not receipt["throughput_evidence"]
    rows = sampled["samples"]
    live = [r for r in rows if r.get("process_running")]
    assert all(b["timestamp_ns"] >= a["timestamp_ns"] for a, b in zip(rows, rows[1:]))
    peaks = {key:max((r[key] for r in rows if r.get(key) is not None), default=None) for key in KEYS}
    for row in rows:
        if row.get("gpu_dedicated_bytes") is not None and row.get("gpu_shared_bytes") is not None:
            assert row["gpu_total_bytes"] == row["gpu_dedicated_bytes"] + row["gpu_shared_bytes"]
        else:
            assert row.get("gpu_total_bytes") is None
    original = read(folder / "memory-summary.json")
    map_peaks = dict(working_set_bytes="sampled_max_working_set_bytes", private_commit_bytes="sampled_max_private_commit_bytes",
                     gpu_dedicated_bytes="sampled_peak_gpu_dedicated_bytes", gpu_shared_bytes="sampled_peak_gpu_shared_bytes",
                     gpu_total_bytes="sampled_peak_gpu_total_bytes")
    assert all(peaks[key] == original["sampled_peaks"][dst] for key, dst in map_peaks.items())
    markers = receipt["markers"]
    first = next(x["timestamp_ns"] for x in markers if x["name"] == "generation_prefill_begin")
    ready = next(x["timestamp_ns"] for x in markers if x["name"] == "ready_before_first")
    ready_rows = [r for r in live if ready <= r["timestamp_ns"] <= first]
    phases = {}
    for name in ("generation_prefill", "generation_decode"):
        begins = [r["timestamp_ns"] for r in markers if r["name"] == name + "_begin"]
        ends = [r["timestamp_ns"] for r in markers if r["name"] == name + "_end"]
        assert len(begins) == len(ends) == 1 and begins[0] <= ends[0]
        begin, end = begins[0], ends[0]
        inside = [r for r in live if begin <= r["timestamp_ns"] <= end]
        before = max((r for r in live if r["timestamp_ns"] <= begin), key=lambda r:r["timestamp_ns"], default=None)
        after = min((r for r in live if r["timestamp_ns"] >= end), key=lambda r:r["timestamp_ns"], default=None)
        change = {k:after[k] - before[k] if before and after and before.get(k) is not None and after.get(k) is not None else None for k in KEYS}
        phase = dict(sample_count=len(inside), sampled_peak_bytes={k:max((r[k] for r in inside if r.get(k) is not None), default=None) for k in KEYS},
                     null_samples={k:sum(r.get(k) is None for r in inside) for k in KEYS},
                     bracket_delta_bytes=change, before_age_ns=begin - before["timestamp_ns"] if before else None,
                     after_age_ns=after["timestamp_ns"] - end if after else None)
        assert phase["sample_count"] == original["phase_windows"][name]["sample_count"]
        assert change == original["phase_windows"][name]["bracket_delta_bytes"]
        phases[name] = phase
    gaps = [(b["timestamp_ns"] - a["timestamp_ns"]) / 1e6 for a, b in zip(live, live[1:])]
    costs = [r["sample_duration_ns"] / 1e6 for r in live]
    assert stats(gaps)["median"] == original["actual_sample_gaps_ms"]["median"]
    assert (not ready_rows) == original["ready_baseline"]["unknown"]
    return dict(raw=identity(folder / "memory.json"), terminal=identity(folder / "result.json"),
                requested_interval_seconds=sampled["requested_interval_s"], all_samples=len(rows), running_samples=len(live),
                sampled_peak_bytes=peaks,
                observed_OS_lifetime_peak_bytes={k:max((r[k] for r in rows if r.get(k) is not None),default=None)
                                                for k in ("os_peak_working_set_bytes", "os_peak_commit_bytes")},
                actual_sample_gaps_ms=stats(gaps), sample_cost_ms=stats(costs),
                null_samples={k:sum(r.get(k) is None for r in rows) for k in KEYS},
                ready_baseline=None if not ready_rows else {k:ready_rows[-1].get(k) for k in KEYS},
                ready_baseline_unknown=not ready_rows, phases=phases,
                GPU_setup_error=sampled["gpu_setup_error"], sampler_thread_error=sampled["thread_error"])


def main():
    inputs = read(S / "inputs/input.json")
    p = inputs["prompt_tokens"]
    assert p == 154 and inputs["capacity"] == 1024 and inputs["requested_output_tokens"] == 64
    records, round_positions = [], {}
    plan = read(S / "performance/timing/inputs.json")
    for command in plan["commands"]:
        assert command["command"][command["command"].index("--capacity") + 1] == "1024"
        terminal=read(Path(command["folder"])/"result.json")
        assert terminal["command"]==command["command"] and terminal["image"]==command["image"]
        row, positions = timing_row(Path(command["folder"]), command["arm"], p)
        records.append(row)
        round_positions.setdefault(command["arm"], positions)
    assert len(records) == 12
    groups = {}
    first = {}
    for arm in ARMS:
        own = [r for r in records if r["arm"] == arm]
        assert len(own) == 3 and all(r["ids"] == own[0]["ids"] for r in own)
        assert all(r["work"] == own[0]["work"] for r in own)
        first[arm] = own[0]["ids"]
        groups[arm] = dict(metrics={k:stats([r["metrics"][k] for r in own]) for k in own[0]["metrics"]},
                           work=own[0]["work"], actual_tokens_per_process=64, within_arm_IDs_equal=True)
    assert first["hyle_plain"] == first["hyle_mtp"] == first["peer_plain"]
    divergent = next(i for i,(a,b) in enumerate(zip(first["hyle_plain"],first["peer_mtp"])) if a != b)
    assert divergent == 18
    peer_round = next(r for r in round_positions["peer_mtp"] if divergent in r["output_indices_zero_based"])
    hyle_round = next(r for r in round_positions["hyle_mtp"] if divergent in r["output_indices_zero_based"])
    assert peer_round["pending"] == hyle_round["pending"] == 11906
    memory_plan = read(S / "performance/memory/inputs.json")
    memories = {}
    for command in memory_plan["commands"]:
        folder, arm = Path(command["folder"]), command["arm"]
        terminal=read(folder/"result.json")
        assert terminal["command"]==command["command"] and terminal["image"]==command["image"]
        raw, _ = raw_result(folder)
        ledger(raw, p, arm)
        assert raw["generated_ids"] == first[arm]
        memories[arm] = memory_row(folder)
    assert set(memories) == set(ARMS)
    # Tokenizer only, local fixed metadata; no Torch/model import or execution.
    os.environ.update(USE_TORCH="0",USE_TF="0",USE_FLAX="0",HF_HUB_OFFLINE="1",
                      TRANSFORMERS_OFFLINE="1",HF_HUB_DISABLE_TELEMETRY="1",TOKENIZERS_PARALLELISM="false")
    from tokenizers import Tokenizer
    tokenizer = Tokenizer.from_file(str(Path(inputs["original_model"])/"tokenizer.json"))
    text = {name:tokenizer.decode(first[name],skip_special_tokens=False)
            for name in ("hyle_plain","peer_mtp")}
    changes = {}
    for base,current in (("hyle_plain","hyle_mtp"),("peer_plain","peer_mtp"),("peer_plain","hyle_plain")):
        keys = ("prefill_tps","full_decode_tps","session_output_tps","startup_endpoint_seconds")
        changes[base+"_to_"+current] = {k:100*(groups[current]["metrics"][k]["median"]/groups[base]["metrics"][k]["median"]-1) for k in keys}
        changes[base+"_to_"+current]["same_actual_generated_IDs"] = first[base] == first[current]
    memory_changes = {base+"_to_"+current:{k:memories[current]["sampled_peak_bytes"][k]-memories[base]["sampled_peak_bytes"][k]
                                                   if memories[current]["sampled_peak_bytes"][k] is not None and memories[base]["sampled_peak_bytes"][k] is not None else None
                                                   for k in KEYS}
                      for base,current in (("hyle_plain","hyle_mtp"),("peer_plain","peer_mtp"))}
    capture_groups={arm:{key:stats([r["prepare_capture"]["totals"][key]for r in records if r["arm"]==arm])
                         for key in ("recorded","reused","cold_batch_seconds")}
                    for arm in ("hyle_plain","hyle_mtp")}
    original_summary=read(S/"performance/timing/summary.json")
    metric_map=dict(prefill_tps="prefill_tokens_per_second",full_decode_tps="full_decode_tokens_per_second",
                    session_output_tps="session_output_tokens_per_second",session_processed_target_tps="session_processed_tokens_per_second",
                    load_seconds="weights_load_seconds",ready_seconds="startup_to_ready_seconds",startup_TTFT_seconds="first_token_elapsed_seconds",
                    startup_endpoint_seconds="startup_to_endpoint_seconds",cold_output_tps="cold_output_tokens_per_second")
    for arm in ARMS:
        for our_key,distribution in groups[arm]["metrics"].items():
            other=original_summary["groups"][arm][metric_map.get(our_key,our_key)]
            assert distribution["count"]==other["count"]
            assert all(close(distribution[key],other[key])for key in ("median","min","max"))
    environment={mode:{edge:dict(
                    GPU_CSV=(S/f"performance/{mode}/window-{edge}-gpu.stdout.log").read_text(encoding="utf-8").strip(),
                    GPU_record=identity(S/f"performance/{mode}/window-{edge}.json"),
                    process_list=identity(S/f"performance/{mode}/window-{edge}-compute_apps.stdout.log"))
                    for edge in ("before","after")}for mode in ("timing","memory")}
    report = dict(status="independent raw four-arm window arithmetic/ledger/sample review; descriptive finite run, no quality threshold",
                  checker=identity(Path(__file__)), inputs=identity(S / "inputs/input.json"),
                  timing_plan=identity(S / "performance/timing/inputs.json"),memory_plan=identity(S / "performance/memory/inputs.json"),
                  environment_outside_critical_window=environment,
                  workload=dict(prompt_tokens=p,requested_outputs=64,actual_outputs_all_processes=64,committed_input_tokens=217,
                                context=1024,N=1,R=1,natural=True,EOS_honored=True,prefix=False,trace=False),
                  per_process=records, groups=groups, median_change_percent=changes,
                  prepare_capture_across_three_processes=capture_groups,
                  independent_memory=memories,memory_MTP_minus_plain_peak_delta_bytes=memory_changes,
                  decoded_outputs=dict(common_Hyle_plain_Hyle_MTP_peer_plain=text["hyle_plain"],peer_MTP=text["peer_mtp"],
                                       decoder="standalone tokenizers.Tokenizer original local tokenizer.json; cleanup=false in fixed tokenizer config; no Torch import",
                                       scope="64-token fragments; output quota truncates the module. No code execution or correctness assessment."),
                  divergence=dict(common_prefix_output_count=18,first_mismatch_zero_based=18,first_mismatch_one_based=19,
                                  common_ID=first["hyle_plain"][18],peer_MTP_ID=first["peer_mtp"][18],
                                  common_token=tokenizer.decode([first["hyle_plain"][18]]),peer_MTP_token=tokenizer.decode([first["peer_mtp"][18]]),
                                  Hyle_MTP_round=hyle_round,peer_MTP_round=peer_round,
                                  peer_prior_rejected_rounds=[r["round_index"] for r in round_positions["peer_mtp"] if not r["accepted"] and r["round_index"]<peer_round["round_index"]]),
                  determined_from_current_records=[
                      "All16 original processes exit0; all64 returned IDs per arm are stable across three timing processes and its separate memory process.",
                      "Round pending tokens, emitted vectors, acceptance decisions, selected counts, target lengths, draft lag/frontier and peer native positions reconstruct without an output/round off-by-one error.",
                      "At the first mismatch both MTP paths have the same logical committed prefix and pending11906. Peer targetT2 row0 returns271 and accepts its271 draft; Hyle targetT2 row0 returns11 and rejects the same271 draft. The divergent ID comes from logged target verification, not merely copying the wrong draft/bonus to the final array.",
                      "The first18 outputs coincide, including peer's earlier reject at round5; current records do not expose the actual per-layer restored state/logits and cannot prove that restore is numerically exact.",
                      "Hyle on/off and peer plain share all64 output IDs. Hyle MTP's same-output speed/extra cold cost is a valid finite consumer observation; peer MTP's different continuation is not same-token work or a quality win.",
                      "Actual10ms-requested memory cadence has approximately15ms median gaps; no arm has a valid sampled ready baseline. Null and finite sample counts are retained. Negative decode bracket deltas can include post-endpoint teardown and are not proof of within-generation freeing/eviction."
                  ],
                  unresolved_and_smallest_followup=[
                      "No logits, top1 margin or per-layer snapshot is captured at peer round9/position171. Current timing logs cannot distinguish ordinary T1/T2 arithmetic/output-mode drift from state restoration drift or another native issue. Reported seq positions prove extents, not restored recurrent values.",
                      "Smallest next diagnostic: retain original GPU greedy math and read its already available public sampled logits/count on peer rounds5/6/9, checking CPU argmax/top2 margins and IDs11/271. No new model forward, CPU execution fallback or synthetic acceptance is required just to distinguish sampler/index reporting from a real target prediction change. If logits confirm target divergence, only then compare the fixed common prefix rebuilt by T1 vs reached through T2 rejection, with limited conv/GDN/KV evidence. No such diagnostic was run here.",
                      "Hyle MTP records18 ranges vs plain2 in each observed process, but their per-call range counts differ. Role/slot first-use and actual backing/topology changes can legitimately record. Current logs expose roles via the round ledger and T, not actual slots or invalidation reason; no duplicate-planning bug or projected TPS benefit is inferred.",
                      "Decoded truncated code fragments are not unit-test/coding quality results. Broad speculative decoding exactness or model-wide acceptance is not established by this one prompt."
                  ],
                  limits=["Compute all TPS per raw process then median/min/max; no averaging phase TPS, pooled denominators or old-window pooling.",
                          "Three fresh timing processes/one independent memory process per arm, normal desktop GPU/background/clocks, no statistical significance claim.",
                          "MTP acceptance is accepted proposals / actual proposals in this one generated stream; it is not accepted outputs / all outputs or a universal rate.",
                          "PSAPI/PDH WDDM counters are sampled attributed memory. Separate dedicated/shared maxima are not added; simultaneous total comes from each actual sample. CPU WS/commit and GPU shared can overlap.",
                          "MTP backend contracts differ: Hyle single Graph plus original14-bank publication; peer native target+draft contexts and host carry. Same C/N/R does not imply equal allocations or internal work.",
                          "Peer MTP throughput numbers are descriptive for its different natural output. Do not label the faster number a same-token victory or numerical quality PASS."],
                  activity=dict(new_model_computation=0,new_GPU_runs=0,builds=0,product_edits=0,old_result_edits=0,local_tokenizer_decode_only=True))
    assert "torch" not in sys.modules
    output=S / "review/window-analysis.json"
    output.write_text(json.dumps(report,indent=2,ensure_ascii=False,allow_nan=False)+"\n",encoding="utf-8")
    print(json.dumps(dict(output=str(output),four_arm_medians={arm:{k:v["median"] for k,v in g["metrics"].items() if k in ("prefill_tps","full_decode_tps","session_output_tps")} for arm,g in groups.items()},
                          divergence=report["divergence"],report_sha256=identity(output)["sha256"],torch_imported="torch"in sys.modules),indent=2,ensure_ascii=False))


if __name__ == "__main__":
    main()
