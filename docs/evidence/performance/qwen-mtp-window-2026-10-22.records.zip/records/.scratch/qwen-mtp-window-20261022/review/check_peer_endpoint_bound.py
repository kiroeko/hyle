from pathlib import Path
import json,hashlib,statistics,math
R=Path.cwd();V=R/'.scratch/qwen-mtp-window-20261022';T=V/'performance/timing'
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def ident(p):
 b=p.read_bytes();return {'path':str(p.relative_to(R)),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
rows=[]
for folder in sorted(T.glob('*peer*')):
 receipt=read(folder/'result.json')
 if receipt.get('exit')!=0:continue
 raw=read(folder/'consumer-result.json');assert raw==read(folder/'stdout.log')
 n=raw['generated_decode_tokens'];assert n==sum(len(x['emitted']) for x in raw['rounds'])==len(raw['generated_ids'])-1
 wall=raw['decode_seconds'];inside=math.fsum(x['seconds'] for x in raw['rounds']);gap=wall-inside;assert gap>=0 and inside>0
 rows.append({'run':folder.name,'arm':receipt['arm'],'receipt':ident(folder/'result.json'),'raw':ident(folder/'consumer-result.json'),'image':receipt['image'],'decode_output_tokens':n,'decode_seconds':wall,'sum_round_seconds':inside,'all_outside_round_seconds':gap,'all_outside_round_ms':gap*1000,'fraction_of_decode_wall_percent':gap/wall*100,'formal_measured_decode_TPS_unchanged':n/wall,'hypothetical_all_gap_removed_decode_TPS_upper_bound':n/inside,'maximum_hypothetical_relative_rate_increase_percent':(wall/inside-1)*100})
summary={}
for arm in ['peer_plain','peer_mtp']:
 s=[v for v in rows if v['arm']==arm];assert len(s)==3
 summary[arm]={'processes':3,'outside_round_ms_range':[min(x['all_outside_round_ms']for x in s),max(x['all_outside_round_ms']for x in s)],'outside_decode_fraction_percent_range':[min(x['fraction_of_decode_wall_percent']for x in s),max(x['fraction_of_decode_wall_percent']for x in s)],'max_hypothetical_rate_increase_percent':max(x['maximum_hypothetical_relative_rate_increase_percent']for x in s),'formal_measured_process_median_decode_TPS':statistics.median(x['formal_measured_decode_TPS_unchanged']for x in s),'hypothetical_process_median_TPS_upper_bound':statistics.median(x['hypothetical_all_gap_removed_decode_TPS_upper_bound']for x in s)}
out={'status':'Diagnostic hypothetical upper bound only; formal full-wall TPS unchanged','formula':{'gap':'decode_seconds - sum(actual rounds[].seconds)','optimistic_rate':'actual generated_decode_tokens / sum(rounds[].seconds)','relative_rate_increase':'decode_seconds / sum(rounds[].seconds) - 1'},'samples':rows,'summary':summary,'max_hypothetical_increase_all_processes_percent':max(x['maximum_hypothetical_relative_rate_increase_percent']for x in rows),'interpretation':['The gap includes all work outside every round timer: JSON/loop/phase markers/host scheduling gaps and any other unattributed time. It is not exclusively final metadata, pure CPU overhead, or proven removable time.','Deducting the entire positive gap deliberately overstates any possible endpoint-only correction. Max hypothetical rate increase remains below0.14% in all six processes.','Peer is already faster in the present raw fullwall observation; removing its additional accounting could only slightly raise its rate. It cannot reverse that observed direction or explain the main gap.','NativeMTP output-ID divergence exists in this window and must be analyzed separately; this bound does not establish equal semantic work or numerical quality.','No formal rates were modified and no speed winner/steady-state guarantee is certified by this diagnostic.'],'activity':{'builds':0,'GPU_runs':0,'product_or_peer_source_edits':0}}
p=V/'review/peer-endpoint-upper-bound.json';p.write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8');print(json.dumps({'report':str(p.relative_to(R)),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'maximum_hypothetical_increase_percent':out['max_hypothetical_increase_all_processes_percent']}))
