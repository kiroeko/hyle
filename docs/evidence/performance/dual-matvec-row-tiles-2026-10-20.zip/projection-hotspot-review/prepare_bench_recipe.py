"""Write literal incremental command suggestions; never spawn a compiler or GPU."""
from pathlib import Path
import ast
import hashlib
import json

STAGE = Path(__file__).resolve().parent
ARCH = STAGE.parent
ROOT = ARCH.parent.parent


def identity(path):
    data = path.read_bytes()
    return dict(path=str(path.resolve()), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())


def main():
    base = ARCH / 'cast-stable-silu/native-source'
    source = STAGE / 'candidate-overlay/source'
    out = STAGE / 'checks/prepared'
    recipe_path = ARCH / 'cast-stable-silu/checks/20261019T180121/native-unary-identity.json'
    original = json.loads(recipe_path.read_text())
    native = original['command'].copy()
    assert not any('use_fast_math' in arg or 'ftz=true' in arg for arg in native)
    substitutions = {original['source']['path']: str(source / 'src/ggml-cuda/unary.cu')}
    for index, argument in enumerate(native):
        if argument in ('-o', '-MT'): native[index + 1] = str(out / 'native-unary.obj')
        elif argument == '-MF': native[index + 1] = str(out / 'native-unary.d')
    native = [substitutions.get(argument, argument) for argument in native]
    native = [argument.replace(str(Path(original['object']['path']).with_suffix('.pdb')), str(out / 'native-unary.pdb'))
              for argument in native]
    native[1:1] = ['-I' + str(source / 'src/ggml-cuda')]
    native.append('-Xptxas=-v')
    old_bench = ARCH / 'cuda-projection-fusion/bench-checks/20261019T054748-b0f8e2cb/plan.json'
    cl = json.loads(old_bench.read_text())['compile'][0]
    cuda_include = Path(r'C:/Program Files/NVIDIA GPU Computing Toolkit/CUDA/v13.3/include')
    host = [cl, '/nologo', '/c', '/std:c++20', '/EHsc', '/Zc:preprocessor', '/Zc:__cplusplus',
        '/utf-8', '/O2', '/Ob2', '/MD', '/DNDEBUG', '/DNOMINMAX', '/W4', '/WX',
        '/I' + str(STAGE), '/I' + str(ROOT / 'src/compute_provider_ggml_cuda'),
        '/external:I' + str(base / 'include'), '/external:I' + str(cuda_include), '/external:W0',
        '/sourceDependencies', str(out / 'bench-deps.json'), str(STAGE / 'dual_rows_bench.cc'),
        '/Fo' + str(out / 'bench.obj'), '/Fd' + str(out / 'bench.pdb')]
    base_link_path = ARCH / 'ga-dense-indexer/checks/20261019T184046-metadata-boundaries/qwen-link-plan.json'
    base_link = json.loads(base_link_path.read_text())
    old_unary = original['object']['path']
    old_main = next(argument for argument in base_link['command'] if argument.endswith('29-qwen35_text-main.obj'))
    assert base_link['command'].count(old_unary) == base_link['command'].count(old_main) == 1
    substitutions = {old_unary: str(out / 'native-unary.obj'), old_main: str(out / 'bench.obj')}
    link = [substitutions.get(argument, argument) for argument in base_link['command']]
    for index, argument in enumerate(link):
        for option, filename in (('/OUT:', 'dual-rows-bench.exe'), ('/MAP:', 'bench.map'), ('/IMPLIB:', 'bench.lib')):
            if argument.upper().startswith(option): link[index] = option + str(out / filename)
    cached_replaced = {row['path']: row for row in base_link['inputs'] if row['path'] in substitutions}
    assert len(cached_replaced) == 2
    plan = dict(
        status='commands_prepared_not_executed', output_directory=str(out),
        native_recipe=identity(recipe_path), base_link_plan=identity(base_link_path),
        source_freeze=identity(STAGE / 'candidate-freeze.json'),
        source=[identity(source / 'src/ggml-cuda/mmvf.cuh'), identity(source / 'src/ggml-cuda/unary.cu'),
            identity(STAGE / 'dual_rows_bench.cc'), identity(STAGE / 'dual_rows_bench_api.h')],
        compile=[dict(tag='native-unary', command=native), dict(tag='bench', command=host)],
        link=dict(command=link, inherited_inputs=len(base_link['inputs']), replaced_inputs=cached_replaced),
        cached_native_scope='Replace only strictunary object. mmvf.cuh change adds a defaulted template parameter; no kernel runtime argument, common byvalue layout, mmvf.cu publichost signature, unary.cuh or cachedSDK math object is changed. Freshstrictunary instantiates both rowtiles from one coherentheader. All other defaultvoid consumers retain their original compiled math; this is an experiment, not a productpatch.',
        coherent_header_scope='candidate-overlay/source/src/ggml-cuda first, then the existing v25 native-source/include/src header paths retained in the actual strict recipe. No copied header/SDK tree.',
        runtime=dict(executable=str(out / 'dual-rows-bench.exe'),
            commands=[[str(out / 'dual-rows-bench.exe'), str(arm), '96'] for arm in (1, 2, 2, 1, 1, 2)],
            environment='Use the frozen base qwen link inputs to derive CUDA/Torch DLL paths, plus original MSVC dev environment; do not union unrelated CPU/CUDA runtimes. Actualrunner must preserve perprocess exit/stdout/stderr/command.',
            numerical='Each process compares all BF16 bits for3 shared weightbank pairs [K2048,N6144], plus N1/N3/N33 specialvalue/tail cases. Both outputs have16BF16 trailing canaries. No timing until all comparisons pass. The native graph matcher/Graph runtime is not under this microbenchmark.',
            timing='Three distinct gate/up pairs, total151MB weightdata, actual queriedL2 must be smaller. Same executable, rows1 vs2,12warm rotations then96measured. CUDA events surround GraphLaunch, wall includes event/sync; neither is kernel-only time or modeltokens/s. No tensor dumps or model loading.',
            reject='Numerical/canary/eligibility failure or any nonzeroexit is not a valid timing sample. Do not relax comparisons. Reject optimization if completecarrier timing regresses or rowtile registers/spills erase benefit.'),
        math_proof=[
            'For eachrow, rowtile does not change lane t, pair index t+i*block_size or x-then-y dotaccumulator order. Newsecondrow independently follows that exact recurrence; weightrow address differs only by one stride_row.',
            'The first and second warpbutterflies are the original helper and sameoffsets. Secondrow partials use disjoint32float slots, with identical eightactivepartial/24zero mapping forblock256. Allthreads execute the same threeblockbarriers. No crossing betweenrows.',
            'Bothrows call exactly the unchanged hyle_bf16_dual_matvec_silu_epilogue followed by the originalBF16RNE store. No changedoperation/precision/FMAflags; compiled equivalence remains untested.',
            'Complete rowpairs only: paired_rows=N-N%2, xrow=2*blockIdx.x, xrow+1<N. Oddtail uses originalrow1 with pointers advanced by paired_rows*K and one destinationelementrow. Existing N*K<=INTMAX bounds everyoffset. N1 takes the originalwholeentry.',
            'CurrentEpilogue=void code paths are excluded fromtile2 bystaticassert/default1. No new conditionalbranch affects a currentdefault instance arithmetic; compilerbinary resource/code differences still need checking, not claimed proven from normalizeddiff.'
        ],
        no_product_edit=True, compiled=False, GPU_run=False)
    for script in ('prepare_rows2.py', 'prepare_bench_recipe.py', 'review.py'):
        ast.parse((STAGE / script).read_text())
    target = STAGE / 'bench-plan.json'
    target.write_text(json.dumps(plan, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(identity(target)))


if __name__ == '__main__':
    main()
