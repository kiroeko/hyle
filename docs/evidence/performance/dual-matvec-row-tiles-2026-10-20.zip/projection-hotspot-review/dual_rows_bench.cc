// Scratch-only complete dual+stableSiLU/Mul carrier comparison.
// Both variants use identical native-owned weights/inputs, stream and outputs.
#include "dual_rows_bench_api.h"
#include "ggml.h"
#include "ggml-alloc.h"
#include "ggml-cuda.h"
#include "numerical_contract.h"
#include <algorithm>
#include <array>
#include <chrono>
#include <cstdint>
#include <iostream>
#include <memory>
#include <stdexcept>
#include <string>
#include <vector>

static void check(cudaError_t status) {
    if (status != cudaSuccess) throw std::runtime_error(cudaGetErrorString(status));
}
static double median(std::vector<double> data) {
    std::sort(data.begin(), data.end());
    return (data[(data.size()-1)/2] + data[data.size()/2]) / 2;
}
static std::uint32_t random_word(std::uint32_t &seed) {
    seed ^= seed << 13; seed ^= seed >> 17; seed ^= seed << 5;
    return seed;
}

struct Bank {
    ggml_tensor *x = nullptr, *gate_weight = nullptr, *up_weight = nullptr;
    ggml_tensor *gate_mm = nullptr, *up_mm = nullptr, *silu = nullptr;
    std::array<ggml_tensor *, 2> roots{}, output{};
    std::array<cudaGraph_t, 2> graphs{};
    std::array<cudaGraphExec_t, 2> executable{};
    std::int64_t n = 0;
};

static Bank bank(ggml_context *ctx, std::int64_t k, std::int64_t n) {
    Bank b;
    b.n = n;
    b.x = ggml_new_tensor_2d(ctx, GGML_TYPE_BF16, k, 1);
    b.gate_weight = ggml_new_tensor_2d(ctx, GGML_TYPE_BF16, k, n);
    b.up_weight = ggml_new_tensor_2d(ctx, GGML_TYPE_BF16, k, n);
    const auto projection = [&](ggml_tensor *weight) {
        auto *mm = ggml_new_tensor_2d(ctx, GGML_TYPE_BF16, n, 1);
        mm->op = GGML_OP_MUL_MAT; mm->src[0] = weight; mm->src[1] = b.x;
        if (!ggml_prec_set_acc(mm, GGML_PREC_F32)) throw std::runtime_error("F32 precision metadata rejected");
        return mm;
    };
    b.gate_mm = projection(b.gate_weight);
    b.up_mm = projection(b.up_weight);
    b.silu = ggml_dup_tensor(ctx, b.gate_mm);
    b.silu->op = GGML_OP_UNARY; b.silu->src[0] = b.gate_mm;
    b.silu->op_params[0] = GGML_UNARY_OP_SILU;
    b.silu->op_params[hyle::compute::ggml_cuda::internal::kUnaryContractParam] =
        hyle::compute::ggml_cuda::internal::kStableSiluContract;
    for (int arm = 0; arm != 2; ++arm) {
        // Exact logical output plus a real trailing canary, including oddN.
        b.roots[arm] = ggml_new_tensor_1d(ctx, GGML_TYPE_BF16, n + 16);
        b.output[arm] = ggml_view_2d(ctx, b.roots[arm], n, 1,
            static_cast<std::size_t>(n) * 2, 0);
        b.output[arm]->op = GGML_OP_MUL;
        b.output[arm]->src[0] = b.silu; b.output[arm]->src[1] = b.up_mm;
    }
    return b;
}

static void upload(Bank &b, std::int64_t k, std::uint32_t seed, bool special) {
    std::vector<std::uint16_t> x(static_cast<std::size_t>(k));
    for (auto &value : x) value = static_cast<std::uint16_t>((random_word(seed) & 0x807fU) | 0x3d00U);
    if (special) { std::fill(x.begin(), x.end(), std::uint16_t{0}); x[0] = 0x3f80U; }
    ggml_backend_tensor_set(b.x, x.data(), 0, x.size() * 2);
    // One CPU weight staging vector; no second device copy per variant.
    std::vector<std::uint16_t> weights(static_cast<std::size_t>(k * b.n));
    for (int which = 0; which != 2; ++which) {
        for (auto &value : weights)
            value = static_cast<std::uint16_t>((random_word(seed) & 0x807fU) | 0x3b00U);
        if (special) {
            std::fill(weights.begin(), weights.end(), std::uint16_t{0});
            const std::array<std::uint16_t, 8> witness{
                0x3f80U, 0x3f81U, 0x8000U, 0x0001U, 0xc2b0U, 0x7f80U, 0xff80U, 0x7fc1U};
            for (std::int64_t row = 0; row != b.n; ++row)
                weights[static_cast<std::size_t>(row * k)] = which == 0
                    ? witness[static_cast<std::size_t>(row) % witness.size()] : std::uint16_t{0x3fc0U};
        }
        ggml_backend_tensor_set(which == 0 ? b.gate_weight : b.up_weight,
            weights.data(), 0, weights.size() * 2);
    }
    std::vector<std::uint16_t> output(static_cast<std::size_t>(b.n + 16), 0x55aaU);
    for (auto *root : b.roots) ggml_backend_tensor_set(root, output.data(), 0, output.size() * 2);
}

static void launch(ggml_backend_t backend, Bank &b, int arm) {
    if (!hyle_dual_rows_bench_launch(backend, b.gate_mm, b.up_mm, b.silu, b.output[arm], arm + 1))
        throw std::runtime_error("real native dual eligibility rejected");
    check(cudaGetLastError());
}
static void equal_outputs(Bank &b) {
    std::array<std::vector<std::uint16_t>, 2> output;
    for (int arm = 0; arm != 2; ++arm) {
        output[arm].resize(static_cast<std::size_t>(b.n + 16));
        ggml_backend_tensor_get(b.roots[arm], output[arm].data(), 0, output[arm].size() * 2);
        if (!std::all_of(output[arm].begin() + b.n, output[arm].end(),
                [](std::uint16_t value) { return value == 0x55aaU; }))
            throw std::runtime_error("tail canary changed");
    }
    if (output[0] != output[1]) throw std::runtime_error("rows1/rows2 complete BF16 outputs differ bitwise");
}

int main(int argc, char **argv) try {
    if (argc != 3) throw std::runtime_error("usage: dual-rows-bench <rows:1|2> <steps>=32");
    const int arm = std::stoi(argv[1]) - 1, steps = std::stoi(argv[2]);
    if ((arm != 0 && arm != 1) || steps < 32 || steps > 4096) throw std::runtime_error("invalid arm/steps");
    constexpr std::int64_t k = 2048, n = 6144;
    constexpr std::size_t banks = 3;
    auto backend = std::unique_ptr<ggml_backend, decltype(&ggml_backend_free)>(ggml_backend_cuda_init(0), ggml_backend_free);
    if (!backend) throw std::runtime_error("CUDA backend unavailable");
    auto ctx = std::unique_ptr<ggml_context, decltype(&ggml_free)>(
        ggml_init({ggml_tensor_overhead() * 256, nullptr, true}), ggml_free);
    if (!ctx) throw std::runtime_error("native metadata allocation failed");
    std::vector<Bank> work;
    work.reserve(6);
    for (std::size_t i = 0; i != banks; ++i) work.push_back(bank(ctx.get(), k, n));
    for (const std::int64_t odd : {1, 3, 33}) work.push_back(bank(ctx.get(), k, odd));
    auto allocation = std::unique_ptr<ggml_backend_buffer, decltype(&ggml_backend_buffer_free)>(
        ggml_backend_alloc_ctx_tensors(ctx.get(), backend.get()), ggml_backend_buffer_free);
    if (!allocation) throw std::runtime_error("native payload allocation failed");
    const auto stream = hyle_dual_rows_bench_stream(backend.get());
    if (!stream) throw std::runtime_error("native nonblocking stream unavailable");
    cudaDeviceProp device{};
    check(cudaGetDeviceProperties(&device, 0));
    const auto ring_bytes = banks * static_cast<std::size_t>(2 * k * n * 2);
    if (ring_bytes <= static_cast<std::size_t>(device.l2CacheSize)) throw std::runtime_error("3-pair ring does not exceed actual device L2");
    for (std::size_t i = 0; i != work.size(); ++i) {
        upload(work[i], k, 0x8734abc1U + static_cast<std::uint32_t>(i), i >= banks);
        launch(backend.get(), work[i], 0); launch(backend.get(), work[i], 1);
        check(cudaStreamSynchronize(stream));
        equal_outputs(work[i]);
    }
    // Each arm captures the complete same mathematical chain. No timings
    // include upload, cold plan/capture, bit oracle or weight initialization.
    for (std::size_t i = 0; i != banks; ++i) for (int a = 0; a != 2; ++a) {
        check(cudaStreamBeginCapture(stream, cudaStreamCaptureModeThreadLocal));
        launch(backend.get(), work[i], a);
        check(cudaStreamEndCapture(stream, &work[i].graphs[a]));
        check(cudaGraphInstantiateWithFlags(&work[i].executable[a], work[i].graphs[a], 0));
    }
    cudaEvent_t start{}, end{};
    check(cudaEventCreate(&start)); check(cudaEventCreate(&end));
    std::vector<double> wall, timeline;
    for (int step = 0; step != steps + 12; ++step) {
        auto &b = work[static_cast<std::size_t>(step) % banks];
        const auto before = std::chrono::steady_clock::now();
        check(cudaEventRecord(start, stream));
        check(cudaGraphLaunch(b.executable[arm], stream));
        check(cudaEventRecord(end, stream)); check(cudaEventSynchronize(end));
        const auto after = std::chrono::steady_clock::now();
        float elapsed{};
        check(cudaEventElapsedTime(&elapsed, start, end));
        if (step >= 12) {
            wall.push_back(std::chrono::duration<double, std::micro>(after - before).count());
            timeline.push_back(elapsed * 1000.0);
        }
    }
    for (std::size_t i = 0; i != banks; ++i) equal_outputs(work[i]);
    check(cudaEventDestroy(end)); check(cudaEventDestroy(start));
    for (std::size_t i = 0; i != banks; ++i) for (int a = 0; a != 2; ++a) {
        check(cudaGraphExecDestroy(work[i].executable[a])); check(cudaGraphDestroy(work[i].graphs[a]));
    }
    std::cout << "{\"rows_per_CTA\":" << arm + 1 << ",\"K\":" << k << ",\"N\":" << n
        << ",\"banks\":" << banks << ",\"ring_weight_bytes\":" << ring_bytes
        << ",\"actual_L2_bytes\":" << device.l2CacheSize
        << ",\"steps\":" << steps << ",\"bitexact_banks\":6,\"tail_canaries\":true"
        << ",\"wall_us_median\":" << median(wall) << ",\"stream_us_median\":" << median(timeline)
        << ",\"model_throughput_claim\":false}\n";
    return 0;
} catch (const std::exception &error) {
    std::cerr << error.what() << '\n'; return 1;
}
