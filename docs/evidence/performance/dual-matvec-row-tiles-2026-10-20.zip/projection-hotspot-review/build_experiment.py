"""Compile the bounded rows1/rows2 scratch carrier; no product patch or SDK rebuild."""
from pathlib import Path
import datetime as dt
import importlib.util
import sys
sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('dual_rows_current_build', S.parent / 'cccl-single-row-topk/build_host.py')
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)
b, c = m.b, m.c
ROOT = S.parent.parents[1]

def main():
    proposal = c.read(S / 'bench-plan.json')
    base_path = S.parent / 'cccl-single-row-topk/checks/20261019T185912-host/qwen-link-plan.json'
    base = c.read(base_path)
    out = S / 'checks' / dt.datetime.now(dt.timezone.utc).strftime('%Y%m%dT%H%M%S')
    out.mkdir(parents=True, exist_ok=False)
    (out / 'tmp').mkdir()
    frozen = [b.identity(p) for p in [Path(__file__), S / 'bench-plan.json',
        S / 'candidate-freeze.json', S / 'candidate-review.json', base_path]]
    for row in proposal['source']:
        assert b.same(row), row['path']
        frozen.append(row)
    original = c.read(proposal['native_recipe']['path'])
    # Retain the exact existing strict unary header closure. The overlay adds
    # just two private files; all untouched SDK/native owners remain cached.
    for row in original['dependencies']:
        assert b.same(row), row['path']
        frozen.append(row)
    commands = []
    old_out = proposal['output_directory']
    for row in proposal['compile']:
        command = [arg.replace(old_out, str(out)) for arg in row['command']]
        if row['tag'] == 'native-unary':
            command += ['-ccbin', str(Path(proposal['compile'][1]['command'][0]).parent)]
            assert '-MD' in command and not any('use_fast_math' in x for x in command)
        commands.append(dict(tag=row['tag'], command=command,
                             object=str(out / (row['tag'] + '.obj'))))
    old_main = next(r for r in base['inputs'] if Path(r['path']).name == '29-qwen35_text-main.obj')
    old_unary = next(r for r in base['inputs'] if c.key(r['path']) == c.key(original['object']['path']))
    assert old_unary == original['object']
    replacements = {c.key(old_main['path']): commands[1]['object'],
                    c.key(old_unary['path']): commands[0]['object']}
    link = [replacements.get(c.key(x), x) for x in base['command']
            if not x.upper().startswith(('/OUT:', '/MAP:', '/IMPLIB:', '/PDB:'))]
    image = out / 'dual-rows-bench.exe'
    link += ['/OUT:' + str(image), '/MAP:' + str(image.with_suffix('.map')),
             '/IMPLIB:' + str(image.with_suffix('.lib'))]
    inputs = [x for x in link if Path(x).is_absolute() and x.lower().endswith(('.obj', '.lib'))
              and not x.upper().startswith(('/OUT:', '/MAP:', '/IMPLIB:', '/PDB:'))]
    assert len(inputs) == len(set(map(c.key, inputs))) == 130
    plan = dict(compile=commands, link=link, inputs=inputs, image=str(image), frozen=frozen,
                cached_inputs=base['inputs'], SDK_rebuild=False, product_patch=False)
    c.save(out / 'plan.json', plan)
    print('PLAN', out / 'plan.json', flush=True)
    def check():
        for row in frozen:
            assert b.same(row), row['path']
    check()
    for row in base['inputs']:
        assert b.same(row), row['path']
    env, _ = b.environment(base['command'], [r['path'] for r in base['inputs']], out)
    for row in commands:
        c.execute(row['tag'] + '-compile', row['command'], env, out)
        check()
        if row['tag'] == 'bench':
            deps = c.read(out / 'bench-deps.json')['Data']
            dependencies = [b.identity(p) for p in [deps['Source'], *deps['Includes']]]
            source = b.identity(S / 'dual_rows_bench.cc')
        else:
            dependencies = frozen[5:]
            source = b.identity(S / 'candidate-overlay/source/src/ggml-cuda/unary.cu')
        c.save(out / (row['tag'] + '-identity.json'), dict(command=row['command'],
               source=source, object=b.identity(row['object']), dependencies=dependencies))
    c.execute('bench-link', link, env, out)
    check()
    c.save(out / 'bench-image.json', b.identity(image))
    c.save(out / 'summary.json', dict(passed=True, host_TUs=1, native_TUs=1,
           SDK_rebuild=False, product_patch=False, image=b.identity(image)))
    c.save(S / 'experiment-check.json', dict(plan=str(out / 'plan.json'), summary=str(out / 'summary.json')))
    print('EXPERIMENT_BUILT', out, flush=True)

if __name__ == '__main__':
    main()
