"""Read retained CUDA traces and sources only; no build, device work or product edits."""
from pathlib import Path
import collections
import csv
import hashlib
import json
import sqlite3
import statistics

STAGE = Path(__file__).resolve().parent
ARCH = STAGE.parent
ROOT = ARCH.parent.parent


def identity(path):
    payload = path.read_bytes()
    return dict(path=str(path.resolve()), bytes=len(payload), sha256=hashlib.sha256(payload).hexdigest())


def stats(values):
    values = list(values)
    return dict(min=min(values), median=statistics.median(values), max=max(values))


def main():
    trace = ARCH / 'cast-stable-silu/profile/capture.sqlite'
    csv_path = trace.with_name('capture_cuda_gpu_kern_sum.csv')
    connection = sqlite3.connect(trace.as_uri() + '?mode=ro', uri=True)
    connection.row_factory = sqlite3.Row
    strings = dict(connection.execute('SELECT id,value FROM StringIds'))
    kernels = [dict(row) for row in connection.execute('SELECT * FROM CUPTI_ACTIVITY_KIND_KERNEL ORDER BY start')]
    for row in kernels:
        row['name'] = strings[row['demangledName']]
    endpoints = [row[0] for row in connection.execute(
        'SELECT end FROM CUPTI_ACTIVITY_KIND_MEMCPY WHERE copyKind=2 AND bytes=4 ORDER BY end')]
    connection.close()
    assert len(endpoints) == len(set(endpoints)) == 32
    actual = collections.Counter(row['name'] for row in kernels)
    with csv_path.open(encoding='utf-8-sig', newline='') as stream:
        official = collections.Counter({row['Name']: int(row['Instances'].replace(',', ''))
                                        for row in csv.DictReader(stream)})
    assert official == actual
    rows = []
    geometry = collections.Counter()
    for phase in range(7, 32):
        selected = [row for row in kernels if endpoints[phase - 1] < row['start'] and row['end'] <= endpoints[phase]]
        dual = [row for row in selected if 'hyle_bf16_dual_matvec_silu_epilogue>' in row['name']]
        single = [row for row in selected if 'internal::gemvx::kernel<' in row['name']]
        assert len(selected) == 650 and len(dual) == 24 and len(single) == 139
        for row in dual:
            geometry[tuple(row[key] for key in ('gridX', 'gridY', 'gridZ', 'blockX', 'blockY', 'blockZ',
                'registersPerThread', 'staticSharedMemory', 'dynamicSharedMemory', 'localMemoryPerThread'))] += 1
        dual_us = sum(row['end'] - row['start'] for row in dual) / 1000
        single_us = sum(row['end'] - row['start'] for row in single) / 1000
        total_us = sum(row['end'] - row['start'] for row in selected) / 1000
        rows.append(dict(phase=phase, kernels=len(selected), dual_count=len(dual), ordinary_gemvx_count=len(single),
            dual_gpu_us=dual_us, ordinary_gemvx_gpu_us=single_us, all_kernel_gpu_us=total_us,
            dual_percent_own_projection_sum=100 * dual_us / (dual_us + single_us),
            dual_nominal_weight_GB_s=(24 * 2 * 6144 * 2048 * 2) / (dual_us * 1000)))
    source = ARCH / 'cast-stable-silu/native-source/src/ggml-cuda'
    recipe = ARCH / 'cast-stable-silu/checks/20261019T180121/native-unary-identity.json'
    unary_recipe = json.loads(recipe.read_text())
    command = unary_recipe['command']
    assert not any(flag in command for flag in ('-use_fast_math', '--use_fast_math', '-ftz=true', '--ftz=true'))
    assert identity(source / 'unary.cu') == unary_recipe['source']
    existing = json.loads((ARCH / 'cuda-projection-fusion/summary.json').read_text())
    native_rejection = json.loads((ARCH / 'cuda-native-matvec/summary.json').read_text())
    report = dict(
        scope='Current retained650-kernel trace and currentv25 native sources, offline only. No source mutation, build, GPU, new profiler or throughput experiment.',
        sources={name: identity(path) for name, path in {
            'orientation': ARCH / 'ga-dense-indexer/next-qwen-hotspot-orientation.json',
            'trace': trace, 'official_csv': csv_path, 'unary': source / 'unary.cu',
            'mmvf': source / 'mmvf.cuh', 'common': source / 'common.cuh',
            'main': source / 'ggml-cuda.cu', 'strict_recipe': recipe,
            'graph_adapter': ROOT / 'src/graph_provider_ggml_cuda/ggml_cuda_region.cc',
            'lowering': ROOT / 'src/compute_provider_ggml_cuda/tensor_program.cc',
            'consumer': ROOT / 'tools/qwen35_text/main.cc',
            'single_projection_benchmark': ARCH / 'cuda-projection-fusion/summary.json',
            'earlier_default_rejection': ARCH / 'cuda-native-matvec/summary.json',
            'original_dual_design': ARCH / 'cuda-ffn-projection-review/projection-fusion-review.json',
            'prior_role_mapping': ARCH / 'cuda-bf16-dual-projection/metadata-fix/projection-role-review.json',
        }.items()},
        observed=dict(
            warm_phases='decode7..31, actual32 distinct4-byte token D2H completion endpoints',
            official_CSV_SQLite_per_symbol_equal=True,
            phases=rows,
            medians={key: stats(row[key] for row in rows) for key in (
                'dual_gpu_us', 'ordinary_gemvx_gpu_us', 'all_kernel_gpu_us',
                'dual_percent_own_projection_sum', 'dual_nominal_weight_GB_s')},
            dual_geometries=[dict(zip(('gridX', 'gridY', 'gridZ', 'blockX', 'blockY', 'blockZ',
                'registers_per_thread', 'static_shared_bytes', 'dynamic_shared_bytes',
                'local_memory_per_thread'), geometry_key), events=count)
                for geometry_key, count in geometry.items()],
            symbol=next(name for name in actual if 'hyle_bf16_dual_matvec_silu_epilogue>' in name),
            role_mapping='The24 identical6144row dual kernels match source/order/weight geometry of24 FFN gate/up pairs. No logical-node NVTX was recorded.139 ordinarygemvx are not all FFN down.',
            bandwidth_limit='Nominal logical BF16 weight bytes divided by duration is not measured DRAM bandwidth. Neither cache residency nor saturation has been established by these NsightSystems records.'),
        current_implementation=[
            dict(at='mmvf.cuh:46,129-140,310-338', fact='OneCTA per outputrow. Each lane loads one contiguous BF16 pair from each weight matrix and one activation pair. Warp32 consecutive pair addresses cover128B per matrix; there is no obvious strided/gather weight-load defect. K2048 gives4 pair iterations per lane atblock256.'),
            dict(at='mmvf.cuh:346-378; common.cuh:473-481', fact='Perrow256 lanes accumulate separate up/gate floats, XOR butterfly32 sum, interwarp shared partials with zero-filled unused lanes, then a second same32lane butterfly. Three block barriers appear in source perrow, including initialization and post-reduction protection.'),
            dict(at='unary.cu:848-855,871-950; mmvf.cuh:385-429', fact='Both projection sums narrowBF16 and widen, ordinary strict stableSiLU then narrowsBF16 and widens, product finally narrowsBF16. Four public boundaries remain. Stable math is in the existing strictunary object, not the fastmathMMVF object.'),
            dict(at='mmvf.cuh:498-516', fact='Generic launcher minimizes pair-loop iteration count alone, choosing256 forK2048. It has no outputrow tiling, dual-specific latency/occupancy criterion or measured launch-shape tuning. It does not prove256 is slow.'),
            dict(at='graph_provider_ggml_cuda/ggml_cuda_region.cc:262-349; v25main:4282-4423,5169-5174', fact='Actual existing four-node closure is already sharedinput gateMatMul/upMatMul/markedSiLU/Multiply. Private native matcher enforces real topology/metadata/use closure and actual range eligibility. Down/residual are outside this region.')],
        recommended_candidate=dict(
            name='Two outputrows perCTA in the existing strict BF16 dual carrier',
            status='Best bounded implementation experiment from source evidence; no proven speedup or actual new layout/kernel.',
            why='It targets the24 actual bandwidth-heavy dual kernels without retrying the rejected139-singleprojection route switch. It exposes two independent row accumulator chains perthread and shares the common activation-pair load. CTA count halves while retaining the same256 logical lanes perrow and the same weight layout.',
            implementation='Parameterize the current shared MMVF template with a compile-time row tile default1; only the existing nonvoid strict dual instantiation selects2. row=2*blockIdx.x+r. Keep row-r accumulators up[r]/gate[r], load one activationpair at each existingcol2, then update each validrow in the original perrow x/y multiply-add order. Give eachrow its own two32float shared partial arrays, retaining the existing warp and crosswarp reduction and four RNE epilogue. No new executor or separate matmul algorithm; old instantiations remain tile1.',
            actual_geometry_change=dict(block_threads=256, grid_x_before=6144, grid_x_after=3072,
                physical_kernel_count_before=24, physical_kernel_count_after=24,
                dynamic_shared_bytes_before=256, dynamic_shared_bytes_for_two_rows=512,
                full_weight_bytes_per_FFN_unchanged=50331648,
                original_activation_pair_payload_load_bytes_per_FFN=6144 * 2048 * 2,
                tiled_activation_pair_payload_load_bytes_per_FFN=3072 * 2048 * 2),
            savings_limit='Activation loads already likely hit cache;24MiB less logical activation load traffic perFFN is not24MiB less DRAM traffic. Both25MiB weight matrices still stream, no asymptotic complexity or mandatory DRAM-byte reduction. CTA/reduction-instruction amortization and independent load/accumulator overlap are the actual hypotheses.',
            exact_math_requirements=[
                'Retain the selectedblock_size logical lane t for everyrow. ForK2048 eachlane visits pair indices t,t+256,t+512,t+768, and pair.x then pair.y for eachdot. Interleaving independentrow instructions cannot change eachrow accumulator order.',
                'Retain the original warp butterfly offsets16,8,4,2,1 and original interwarp partial positions0..7 with zeros8..31. Do not change256 to128/64 or use a different sum tree as an unacknowledged numerical optimization.',
                'Same strictunary compilerflags and exact op_hyle_stable_silu helper, fourBF16 RNE boundaries, NaN/Inf/signedzero/subnormal behavior. No half/BF16 accumulators, TF32, tensorcore math or different FMA contraction recipe.',
                'Guard the odd finalNrow loads and stores without putting a divergent earlyreturn before any blockbarrier. Preserve the inactive zero partials and all row-independent barrier participation.',
                'Do not merge writes across downMatMul, change productdtype or remove a published/extra-reader intermediate. The original fournodeclosure and read-to-terminal allocationdependencies remain the same.'
            ],
            layout_resource_domain=[
                'Reuse current admitted NVIDIAfastBF16, BF16 same-shape dense Wgate/Wup in native[K,N,1,1], common BF16x[K,1,1,1], contiguous BF16dst[N,1,1,1], evenpositiveK, F32 declared accumulations, noIDs/bias/batch.',
                'Keep K*N<=INTMAX, actual device/owner/capacity/span/alignment/alias checks and read/write disjointness. New rowbase/ceil(N/2) calculations must avoid narrowing overflow and never read secondrow on oddN tail.',
                'At most512B dynamicshared, no new workspace or allocation, no weight concatenation/copy, capture uses originalQueue/Invocation. No common byvalue struct or publicAPI change.',
                '39registers/thread and zero local-memory reported forcurrentkernel. Two rows need more accumulators/pointers; registerallocation/spills/occupancy may offset every benefit. Compile resource metadata, not source guesses, must decide whether this remains worth timing.',
                'If a rowtile template lives inmmvf.cuh, all actual consumers of thatheader must use coherent source; mandatory nativefresh object isstrictunary. Determine otherowner dependency refresh from actual header closure before executing any build. No SDK rebuild justified.'
            ],
            falsifiable_validation='Firstcompare exact two-row vscurrentdual on small odd/evenN and nonmodel evenK, keeping allspecialvalue/RNE/closure/escape/alias fixtures and retainedheldresults. Then one cache-realistic full dual+stableSiLU/Mul capturedpair benchmark using existing weight-ring methodology, same work/weightformat/output/readback. Accept only repeatable completechain latency benefit with no spill/resource regression, then one completeQwen64 numericandpaired throughput check. Do not benchmark a singleprojection or count halfCTA as a speed proof.',
            reject_if='Any changed perrow reduction or outputcontract, new duplicateweight/scratchpayload, unacceptable register/spill/occupancy cost, or completechain regression. Retain currenttile1 as ordinary implementation fallback for unsupportedresource/geometry, with no model-name whitelist.'),
        suffix_review=dict(
            at='tools/qwen35_text/main.cc:192-203,419; currentcuBLASprovider:160-174',
            current='FFNdown is a separate BF16 MatMul [1,6144]x[6144,2048]→BF16[1,2048], then independentBF16 residualAdd. CurrentCUDAtrace contains48 BF16Add total, not proof all48 belong tothissuffix. Existing dual region already absorbs allgate/up stableSiLU/Mul math.',
            potential='Down+residual fusion remains a real functional wiring opportunity but requires retaining down BF16RNE before widenedBF16 residualAdd and finalBF16RNE. Standard Lt beta=1/C residual or a generic bias epilogue adds before downRNE, so is not a valid exactreplacement. A custom outputepilogue requires a real supported carrier and larger change; do not reuse rejected singleMMVF as an assumed win.',
            why_not_first='The requestedboundedfirstexperiment should target existingdual carrier without adding Lt/publicGraph contracts or changing139 ordinaryprojection selection. The residual kernel works on2048values; its standaloneGPUtime must be isolated by source/stream/order before prioritizing beyondweightdot work.'),
        counterevidence=dict(
            isolated_single_projection=dict(decision=existing['decision'], benchmark=existing['benchmark']),
            prior_global_native_route=dict(decision=native_rejection['decision'],
                warm_before=native_rejection['performance']['before']['decode_warm_tokens_per_second']['median'],
                warm_candidate=native_rejection['performance']['candidate']['decode_warm_tokens_per_second']['median'],
                equal_vectors=native_rejection['byte_identical_vectors'], total_vectors=native_rejection['total_vectors']),
            reason='These reject a blanket singleprojectionroute change; they do not measure or disprove exactrowtiling within alreadyselecteddual. Conversely originaldual gain does not establish furtherrowtile benefit.'),
        limits=['NsightSystems has no memorycounter/stall/occupancy evidence here. Coalesced source access does not establish hardware bandwidth saturation.',
            'Perphase summed kernel durations are not walltime/intervalunion and omit host/gaps/copies. Independent oldprofiles are not subtracted.',
            'No new implementation, numerical validation, modelquality or performanceclaim; only scratch report and reproducible offline statistics were written.'],
        product_edits=False, builds=0, GPU_runs=0, throughput_claim=False)
    target = STAGE / 'readonly-report.json'
    target.write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(dict(report=identity(target), medians=report['observed']['medians'], geometry=report['observed']['dual_geometries']), indent=2))


if __name__ == '__main__':
    main()
