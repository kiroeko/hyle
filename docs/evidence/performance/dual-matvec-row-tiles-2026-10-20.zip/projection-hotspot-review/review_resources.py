"""Only parse the completed experiment's compiler/dependency/timing receipts."""
from pathlib import Path
import hashlib
import json
import re

STAGE = Path(__file__).resolve().parent
CHECK = STAGE / 'checks/20261019T190715'


def identity(path):
    data = path.read_bytes()
    return dict(path=str(path.resolve()), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())


def main():
    resources = []
    for filename in ('native-unary-compile.stdout.log', 'native-unary-compile.stderr.log'):
        path = CHECK / filename
        lines = path.read_text(encoding='utf-8', errors='replace').splitlines()
        for index, line in enumerate(lines):
            match = re.search(r"Compiling entry function '([^']+)' for '([^']+)'", line)
            if not match or 'hyle_bf16_dual_matvec_silu_epilogue' not in match[1]:
                continue
            template = re.search(r'Li1ELi(\d+)ELb1ELb0E.*epilogueLi([12])E', match[1])
            assert template
            text = '\n'.join(lines[index:index + 5])
            stack = re.search(r'(\d+) bytes stack frame, (\d+) bytes spill stores, (\d+) bytes spill loads', text)
            used = re.search(r'Used (\d+) registers, used (\d+) barriers, (.*)', text)
            assert stack and used
            static_shared = re.search(r'(\d+) bytes smem', used[3])
            resources.append(dict(rows_per_block=int(template[2]), block_threads=int(template[1]),
                architecture=match[2], mangled_symbol=match[1], registers_per_thread=int(used[1]),
                ptxas_barrier_resource_slots=int(used[2]),
                stack_frame_bytes=int(stack[1]), spill_store_bytes=int(stack[2]), spill_load_bytes=int(stack[3]),
                static_shared_bytes_reported=int(static_shared[1]) if static_shared else 0,
                static_shared_note='No smem allocation field is emitted for this kernel; extern dynamic shared is supplied by the launch, not this ptxas field.',
                log=str(path.resolve()), line_start=index + 1, raw_lines=lines[index:index + 5]))
    selected = [row for row in resources if row['block_threads'] == 256]
    assert len(selected) == 2 and {row['rows_per_block'] for row in selected} == {1, 2}
    selected.sort(key=lambda row:row['rows_per_block'])
    compiled = json.loads((CHECK / 'native-unary-identity.json').read_text())
    result = json.loads((CHECK / 'native-unary-compile.result.json').read_text())
    assert result['exit'] == 0 and result['terminal']
    assert not any('use_fast_math' in item or 'ftz=true' in item for item in compiled['command'])
    dependency_path = CHECK / 'native-unary.d'
    deps = dependency_path.read_text(encoding='utf-8').splitlines()
    resolved = {}
    for name in ('mmvf.cuh', 'unary.cu', 'unary.cuh', 'common.cuh'):
        matches = []
        for number, line in enumerate(deps, 1):
            value = line.strip().removesuffix(' \\').strip()
            # The first make target line includes both target and source;
            # capture actual dependency rows, not a substring of the target.
            if value.endswith('/' + name) and not (' : ' in value):
                matches.append((number, Path(value)))
        unique = {str(path.resolve()).lower(): path for _, path in matches}
        assert len(unique) == 1, (name, list(unique))
        path = next(iter(unique.values()))
        resolved[name] = dict(actual=identity(path), d_lines=[number for number, _ in matches])
    for name in ('mmvf.cuh', 'unary.cu'):
        expected = STAGE / 'candidate-overlay/source/src/ggml-cuda' / name
        assert resolved[name]['actual'] == identity(expected)
    source_identity = identity(STAGE / 'candidate-overlay/source/src/ggml-cuda/unary.cu')
    assert compiled['source'] == source_identity
    dependency_records = {row['path'].lower():row for row in compiled['dependencies']}
    for name in ('mmvf.cuh', 'unary.cu'):
        record = resolved[name]['actual']
        assert dependency_records[record['path'].lower()] == record
    micro = json.loads((STAGE / 'microbenchmark/summary.json').read_text())
    assert micro['passed'] and micro['terminal_zero'] == 6
    for row in micro['runs']:
        assert row['K'] == 2048 and row['N'] == 6144 and row['bitexact_banks'] == 6 and row['tail_canaries']
    for row in selected:
        tile = row['rows_per_block']
        row.update(measured_runtime_K=2048, measured_runtime_N=6144,
            logical_lanes_per_output_row=256, grid_x_from_actual_source=6144 // tile,
            dynamic_shared_launch_bytes_from_compiled_source=tile * 32 * 4 * 2,
            unrounded_registers_per_CTA=row['registers_per_thread'] * 256,
            dynamic_shared_source='candidate-overlay/source/src/ggml-cuda/mmvf.cuh:570-576; fusion.gate is nonnull; same K-dependent original launcher selects256 forK2048')
    report = dict(
        status='rejected_for_product_promotion_no_visible_microbenchmark_gain',
        scope='Offline read of completed checks/20261019T190715 and six process microbenchmark. No new build, device call, GPU, profiler or product changes.',
        sources={name:identity(path) for name, path in {
            'compile_stdout': CHECK / 'native-unary-compile.stdout.log',
            'compile_stderr': CHECK / 'native-unary-compile.stderr.log',
            'compile_receipt': CHECK / 'native-unary-compile.result.json',
            'compiled_identity': CHECK / 'native-unary-identity.json',
            'actual_dependencies': dependency_path,
            'candidate_freeze': STAGE / 'candidate-freeze.json',
            'microbenchmark': STAGE / 'microbenchmark/summary.json'}.items()},
        actual_K2048_block256_instances=selected,
        dependency_resolution=dict(verified=True, actual=resolved,
            note='The compiler make dependency file resolves the candidate mmvf.cuh and candidate unary.cu exactly once as dependency entries. unary.cuh/common.cuh resolve to the frozenv25 source paths. Compiledsource and recorded candidateheader identities equal the actual bodies. No evidence of the candidate being replaced by cached mmvf.cuh.'),
        resource_change=dict(registers_per_thread=[selected[0]['registers_per_thread'], selected[1]['registers_per_thread']],
            registers_increase_percent=100 * (selected[1]['registers_per_thread']/selected[0]['registers_per_thread'] - 1),
            dynamic_shared_launch_bytes=[256, 512], stack_and_spill_bytes=[0, 0],
            barrier_note='ptxas used1barriers is one allocated barrier resource slot. It is not one executed __syncthreads. The unchanged three sequential source barriers can reuse the same slot.',
            occupancy_limit='Register/CTA increase can reduce theoretical residency, but no actual occupancy, register-allocation granularity, stall or memorycounter measurement was collected. Do not call the register increase the proven cause of the tie.'),
        measurement=dict(processes=6, exact_per_process_banks=6, input_K=2048, input_N=6144,
            ring_weight_bytes=150994944, actual_L2_bytes=37748736,
            process_medians=micro['process_medians'], paired_relative_reductions=micro['paired_relative_reductions'],
            observations='All six runs passed every BF16bit and trailingcanary check. Both arm event medians107.52us; wall medians115.6us one-row and115.9us two-row. All three wallpairs favor one-row slightly. No visible completecarrier benefit justifies promotion.',
            limits='Event medians are quantized reported observations, not equality of all samples or statistical equivalence. Wall includes launch/event/synchronization. This bounded microbenchmark does not prove all shapes or whole-model behavior.'),
        conclusion='Keep original one-row product carrier and its v25 patch/provider identities. Reduced CTA count and shared activation loads did not produce a visible gain in the actual same-work experiment; two-row registers increased39→48 with no spills. Do not run a full-model trial or broaden tuning on this result alone.',
        promotion_notes_written=False, new_builds=0, new_GPU_runs=0, product_changed=False)
    target = STAGE / 'resource-review.json'
    target.write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(dict(report=identity(target), resources=[{key:row[key] for key in (
        'rows_per_block','registers_per_thread','stack_frame_bytes','spill_store_bytes',
        'spill_load_bytes','dynamic_shared_launch_bytes_from_compiled_source')} for row in selected]), indent=2))


if __name__ == '__main__':
    main()
