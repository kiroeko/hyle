#pragma once
#include "ggml-backend.h"
#include <cuda_runtime_api.h>

// Scratch-only symbols exported by the candidate strict unary object.
extern "C" cudaStream_t hyle_dual_rows_bench_stream(ggml_backend_t backend);
extern "C" bool hyle_dual_rows_bench_launch(ggml_backend_t backend,
    const ggml_tensor *gate_mm, const ggml_tensor *up_mm,
    const ggml_tensor *silu, ggml_tensor *dst, int rows);
