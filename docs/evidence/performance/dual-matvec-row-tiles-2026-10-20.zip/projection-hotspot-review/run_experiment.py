"""Run three alternating process pairs of the identical native dual workload."""
from pathlib import Path
import importlib.util
import json
import statistics
import sys
sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('dual_rows_experiment_helpers', S / 'build_experiment.py')
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)
b, c = m.b, m.c
path = Path(c.read(S / 'experiment-check.json')['plan'])
plan = c.read(path)
assert c.read(path.parent / 'summary.json')['passed']
for row in plan['frozen']:
    assert b.same(row), row['path']
image = c.read(path.parent / 'bench-image.json')
assert b.same(image)
out = S / 'microbenchmark'
out.mkdir(exist_ok=False)
(out / 'tmp').mkdir()
env, runtime = b.environment(plan['link'], plan['inputs'], out)
order = [1, 2, 2, 1, 1, 2]
c.save(out / 'inputs.json', dict(image=image, plan=b.identity(path), order=order,
    runtime_library_directories=runtime, profiler=False, product_patch=False,
    limit='Original row1 differential reference in same candidate TU. Native whole-carrier CUDA Graph event/wall timing, not public Graph or model speed.'))
runs = []
try:
    for index, rows in enumerate(order):
        tag = str(index + 1) + '-rows' + str(rows)
        c.execute(tag, [image['path'], str(rows), '96'], env, out)
        data = json.loads((out / (tag + '.stdout.log')).read_text().splitlines()[-1])
        assert data['rows_per_CTA'] == rows and data['bitexact_banks'] == 6 and data['tail_canaries']
        assert data['ring_weight_bytes'] > data['actual_L2_bytes']
        runs.append(dict(tag=tag, **data))
        c.save(out / 'runs.json', runs)
    medians = {str(rows): {key: statistics.median(r[key] for r in runs if r['rows_per_CTA'] == rows)
               for key in ('wall_us_median', 'stream_us_median')} for rows in (1, 2)}
    pairs = []
    for index in range(0, len(runs), 2):
        pair = {r['rows_per_CTA']: r for r in runs[index:index + 2]}
        pairs.append({key: 1 - pair[2][key] / pair[1][key] for key in ('wall_us_median', 'stream_us_median')})
    c.save(out / 'summary.json', dict(passed=True, terminal_zero=6, runs=runs, process_medians=medians,
        paired_relative_reductions=pairs, product_patch=False, model_speed_claim=False))
    print('DUAL_ROWS', medians, 'reductions', pairs, flush=True)
except Exception as error:
    c.save(out / 'summary.json', dict(passed=False, terminal_zero=len(runs), error=str(error),
                                    runs=runs, product_patch=False))
    raise
