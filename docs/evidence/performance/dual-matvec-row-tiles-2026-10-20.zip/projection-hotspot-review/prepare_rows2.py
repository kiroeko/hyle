"""Materialize an experiment-only strict dual row tile; never touch product or SDK."""
from pathlib import Path
import difflib
import hashlib
import json

STAGE = Path(__file__).resolve().parent
ARCH = STAGE.parent
BASE = ARCH / 'cast-stable-silu/native-source'
OUT = STAGE / 'candidate-overlay/source'


def identity(path):
    data = path.read_bytes()
    return dict(path=str(path.resolve()), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())


def main():
    records, differences = [], []
    header_path = 'src/ggml-cuda/mmvf.cuh'
    path = BASE / header_path
    before = path.read_text(encoding='utf-8')
    after, edits = before, []

    def replace(old, new, count=1):
        nonlocal after
        assert after.count(old) == count, (old[:100], after.count(old), count)
        after = after.replace(old, new)
        edits.append(dict(before=old, after=new, occurrences=count))

    # Every current caller retains the default1. No runtime argument or shared
    # by-value fusion-args layout changes. Tile2 is only an explicit private
    # strict dual instantiation, never an Epilogue=void behavior.
    replace('typename Dst = float, typename Epilogue = void>',
            'typename Dst = float, typename Epilogue = void, int rows_per_block = 1>', 3)
    replace('    const int row         = blockIdx.x;', '''    static_assert(rows_per_block == 1 || (rows_per_block == 2 &&
        !std::is_void_v<Epilogue> && has_fusion && ncols_dst == 1 &&
        !is_multi_token_id && std::is_same_v<T, nv_bfloat16> &&
        std::is_same_v<type_acc, float> && std::is_same_v<Y, nv_bfloat16> &&
        std::is_same_v<Dst, nv_bfloat16>));
    // Tile2 host dispatch sends complete pairs only; an odd last row uses
    // the unchanged tile1 carrier. Thus no lane can exit before a barrier.
    const int row         = blockIdx.x * rows_per_block;''')
    replace('''    if (block_size > warp_size) {
        if (tid < warp_size) {''', '''    [[maybe_unused]] float * buf_iw_row2 = nullptr;
    [[maybe_unused]] float * buf_iw_gate_row2 = nullptr;
    if constexpr (rows_per_block == 2) {
        buf_iw_row2 = buf_iw_gate + warp_size;
        buf_iw_gate_row2 = buf_iw_row2 + warp_size;
    }

    if (block_size > warp_size) {
        if (tid < warp_size) {''')
    replace('''        }
        __syncthreads();
    }

    float sumf[ncols_dst]''', '''            if constexpr (rows_per_block == 2) {
                buf_iw_row2[tid] = 0.0f;
                buf_iw_gate_row2[tid] = 0.0f;
            }
        }
        __syncthreads();
    }

    float sumf[ncols_dst]''')
    replace('''    float sumf_gate[ncols_dst];
    if constexpr (has_fusion)''', '''    float sumf_gate[ncols_dst];
    [[maybe_unused]] float sumf_row2 = 0.0f;
    [[maybe_unused]] float sumf_gate_row2 = 0.0f;
    if constexpr (has_fusion)''')
    # This anchor is specific to the NVIDIA BF16 branch, not float/half/HIP.
    replace('''        const nv_bfloat162 * x2 = (const nv_bfloat162 *) x;
        [[maybe_unused]] const nv_bfloat162 * gate_x2 = nullptr;''', '''        const nv_bfloat162 * x2 = (const nv_bfloat162 *) x;
        [[maybe_unused]] const nv_bfloat162 * x2_row2 = nullptr;
        [[maybe_unused]] const nv_bfloat162 * gate_x2_row2 = nullptr;
        [[maybe_unused]] const nv_bfloat162 * gate_x2 = nullptr;''')
    replace('''                    tmpx_gate = gate_x2[col2];
                }
            }
#pragma unroll
            for (int j = 0; j < ncols_dst; ++j) {
                const float2 tmpy = load_pair(j*stride_col_y2 + col2);
                ggml_cuda_mad(sumf[j], tmpx.x, tmpy.x);
                ggml_cuda_mad(sumf[j], tmpx.y, tmpy.y);

                if constexpr (has_fusion) {
                    if (use_gate) {
                        ggml_cuda_mad(sumf_gate[j], tmpx_gate.x, tmpy.x);
                        ggml_cuda_mad(sumf_gate[j], tmpx_gate.y, tmpy.y);
                    }
                }
            }
        }
#endif
    } else {''', '''                    tmpx_gate = gate_x2[col2];
                }
            }
            [[maybe_unused]] nv_bfloat162 tmpx_row2, tmpx_gate_row2;
            if constexpr (rows_per_block == 2) {
                // Same K-pair index and per-dot order as row0. The one shared
                // activation load below supplies both independent row chains.
                x2_row2 = x2 + stride_row/2;
                gate_x2_row2 = gate_x2 + stride_row/2;
                tmpx_row2 = x2_row2[col2];
                tmpx_gate_row2 = gate_x2_row2[col2];
            }
#pragma unroll
            for (int j = 0; j < ncols_dst; ++j) {
                const float2 tmpy = load_pair(j*stride_col_y2 + col2);
                ggml_cuda_mad(sumf[j], tmpx.x, tmpy.x);
                ggml_cuda_mad(sumf[j], tmpx.y, tmpy.y);

                if constexpr (has_fusion) {
                    if (use_gate) {
                        ggml_cuda_mad(sumf_gate[j], tmpx_gate.x, tmpy.x);
                        ggml_cuda_mad(sumf_gate[j], tmpx_gate.y, tmpy.y);
                    }
                }
                if constexpr (rows_per_block == 2) {
                    ggml_cuda_mad(sumf_row2, tmpx_row2.x, tmpy.x);
                    ggml_cuda_mad(sumf_row2, tmpx_row2.y, tmpy.y);
                    ggml_cuda_mad(sumf_gate_row2, tmpx_gate_row2.x, tmpy.x);
                    ggml_cuda_mad(sumf_gate_row2, tmpx_gate_row2.y, tmpy.y);
                }
            }
        }
#endif
    } else {''')
    replace('''        if (block_size > warp_size) {
            buf_iw[tid/warp_size]''', '''        if constexpr (rows_per_block == 2) {
            sumf_row2 = warp_reduce_sum<warp_size>(sumf_row2);
            sumf_gate_row2 = warp_reduce_sum<warp_size>(sumf_gate_row2);
        }

        if (block_size > warp_size) {
            buf_iw[tid/warp_size]''')
    replace('''            __syncthreads();
            if (tid < warp_size) {
                sumf[j] = buf_iw[tid];''', '''            if constexpr (rows_per_block == 2) {
                buf_iw_row2[tid/warp_size] = sumf_row2;
                buf_iw_gate_row2[tid/warp_size] = sumf_gate_row2;
            }
            __syncthreads();
            if (tid < warp_size) {
                sumf[j] = buf_iw[tid];''')
    replace('''            }

            if (j < ncols_dst) {
                __syncthreads();''', '''                if constexpr (rows_per_block == 2) {
                    sumf_row2 = warp_reduce_sum<warp_size>(buf_iw_row2[tid]);
                    sumf_gate_row2 = warp_reduce_sum<warp_size>(buf_iw_gate_row2[tid]);
                }
            }

            if (j < ncols_dst) {
                __syncthreads();''')
    replace('''    if constexpr (!has_fusion) {
        GGML_UNUSED_VARS(use_gate''', '''    if constexpr (rows_per_block == 2) {
        // Only tid0 reaches this point for the qualified ncols_dst==1 case.
        dst[tid*stride_col_dst + row + 1] = __float2bfloat16_rn(
            Epilogue::apply(sumf_row2, sumf_gate_row2));
    }

    if constexpr (!has_fusion) {
        GGML_UNUSED_VARS(use_gate''')
    # Carry the compile-time choice without editing any default math branch.
    replace('true, is_multi_token_id, Y, Dst, Epilogue>, launch_params,',
            'true, is_multi_token_id, Y, Dst, Epilogue, rows_per_block>, launch_params,')
    replace('''    const int nbytes_shared = warp_size*sizeof(float) + (has_fusion ? warp_size*sizeof(float) : 0);
    const dim3 block_nums(nrows, nchannels_dst, nsamples_or_ntokens);''', '''    static_assert(rows_per_block == 1 || (rows_per_block == 2 && !std::is_void_v<Epilogue>));
    GGML_ASSERT(nrows % rows_per_block == 0);
    const int nbytes_shared = rows_per_block *
        (warp_size*sizeof(float) + (has_fusion ? warp_size*sizeof(float) : 0));
    const dim3 block_nums(nrows/rows_per_block, nchannels_dst, nsamples_or_ntokens);''')
    for block in range(32, 257, 32):
        replace(f'mul_mat_vec_f_switch_fusion<T, type_acc, ncols_dst, {block}, is_multi_token_id, Y, Dst, Epilogue>',
                f'mul_mat_vec_f_switch_fusion<T, type_acc, ncols_dst, {block}, is_multi_token_id, Y, Dst, Epilogue, rows_per_block>')
    output = OUT / header_path
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(after, encoding='utf-8', newline='\n')
    records.append(dict(path=header_path, before=identity(path), after=identity(output), edits=edits))
    differences.extend(difflib.unified_diff(before.splitlines(True), after.splitlines(True),
        fromfile='v25/' + header_path, tofile='experiment/' + header_path))

    relative = 'src/ggml-cuda/unary.cu'
    path = BASE / relative
    before = path.read_text(encoding='utf-8')
    # Original public/private product entry body stays exactly as control.
    # Appended wrappers exist only in the experiment object and are not a
    # product interface. The native matcher/default still calls original1row.
    addition = (STAGE / 'dual_rows_native.inc').read_text(encoding='utf-8')
    after = before + '\n' + addition
    output = OUT / relative
    output.write_text(after, encoding='utf-8', newline='\n')
    records.append(dict(path=relative, before=identity(path), after=identity(output),
        edits=[dict(before=before[-120:], after=before[-120:] + '\n' + addition, occurrences=1)]))
    differences.extend(difflib.unified_diff(before.splitlines(True), after.splitlines(True),
        fromfile='v25/' + relative, tofile='experiment/' + relative))
    (STAGE / 'candidate.diff').write_text(''.join(differences), encoding='utf-8')
    (STAGE / 'candidate-freeze.json').write_text(json.dumps(dict(
        status='scratch_uncompiled_not_applied', source_v25='e2d446afee1c93d5', files=records,
        original_unary_entry_preserved_byte_for_byte=True,
        no_runtime_kernel_argument_or_shared_struct_change=True,
        tile2_only_nonvoid_strict_BF16_dual=True,
        product_edits=False, builds=0, GPU_runs=0), indent=2) + '\n', encoding='utf-8')
    print(json.dumps(dict(files=[dict(path=row['path'], after=row['after']) for row in records],
        freeze=identity(STAGE / 'candidate-freeze.json')), indent=2))


if __name__ == '__main__':
    main()
