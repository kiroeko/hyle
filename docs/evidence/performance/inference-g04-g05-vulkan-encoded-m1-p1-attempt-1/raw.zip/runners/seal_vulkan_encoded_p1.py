from pathlib import Path
import hashlib,json,sys,zipfile

ROOT=Path.cwd();BASE=ROOT/'.scratch/inference-gaps/g04-g05'
attempt=int(sys.argv[1]);RUN=BASE/'vulkan-encoded-p1'/str(attempt)
launch=json.loads((RUN/'launch.json').read_text(encoding='utf-8'))
assert launch['state']=='TERMINAL','inspect original actual process; never infer terminal from observation failure'
assert launch['download_exit']==0
job=json.loads((RUN/'remote/job.json').read_text(encoding='utf-8'))
assert job['state']=='TERMINAL'
assert launch['remote_state']==job
snapshot=json.loads((RUN/'snapshot.json').read_text(encoding='utf-8'))
assert job['snapshot']==snapshot
assert job['identity']['model']=='Mac16,12' and job['identity']['arch']=='arm64'
numeric=ROOT/'evidence/correctness/inference-g04-g05-vulkan-encoded-page-preflight/receipt.json'
assert hashlib.sha256(numeric.read_bytes()).hexdigest()==snapshot['numeric_receipt_sha256']
assert json.loads(numeric.read_text(encoding='utf-8'))['verdict']=='PASS_NUMERICAL_LIFECYCLE_PREFLIGHT_ONLY'
contract=ROOT/'bench/inference_resident_sdpa/vulkan_encoded_p1/contract.json'
assert hashlib.sha256(contract.read_bytes()).hexdigest()==snapshot['contract_file_sha256']
declared=json.loads(contract.read_text(encoding='utf-8'))
assert declared['experiment']['sample_schedule']==[15,31]
out=RUN/'output'
summary_path=out/'summary.json'
summary=json.loads(summary_path.read_text(encoding='utf-8')) if summary_path.is_file() else None
aa_path=out/'vulkan-encoded-aa.json'
aa=json.loads(aa_path.read_text(encoding='utf-8')) if aa_path.is_file() else None
manifest_path=out/'manifest.json'
manifest=json.loads(manifest_path.read_text(encoding='utf-8')) if manifest_path.is_file() else None
rows=[];stages=[]
products=list((out/'raw').rglob('product-*.log'))
controls=list((out/'raw').rglob('control-*.log'))
qualified=bool(summary and summary['qualification']=='QUALIFIED')
if qualified:
 assert launch['output_download_exit']==0 and job['verify_exit']==0
 assert aa and aa['gate']=='PASS' and len(aa['runs'])==16
 assert manifest
 stages=manifest['extensions']['sample_stages']
 assert stages and stages==declared['experiment']['sample_schedule'][:len(stages)]
 index=json.loads((out/'raw-log-index.json').read_text(encoding='utf-8'))
 assert index['sample_stages']==stages
 assert len(products)==len(declared['strata'])*sum(stages)
 assert len(controls)==2*sum(stages)
 assert len(products)==sum(r['kind']=='product' for r in index['entries'])
 assert len(controls)==sum(r['kind']=='control' for r in index['entries'])
 for w in summary['workloads']:
  ratios=[s['estimate']['median_advantage_ratio'] for s in w['strata']]
  cis=[s['estimate']['confidence_interval'] for s in w['strata']]
  rows.append({'id':w['id'],'ratio_range':[min(ratios),max(ratios)],
   'noninferiority':w['combined_noninferiority_gate'],'exact':w['combined_exact_verdict'],
   'direction':'WIN' if all(c[0]>1 for c in cis) else 'LOSS' if all(c[1]<1 for c in cis) else 'INCONCLUSIVE'})
 assert len(rows)==3
passed=qualified and job['exit_code']==0 and all(r['noninferiority']=='PASS' for r in rows)
dest=ROOT/f'evidence/performance/inference-g04-g05-vulkan-encoded-m1-p1-attempt-{attempt}'
dest.mkdir(exist_ok=False)
for name in ('summary.json','manifest.json','observations.jsonl','raw-log-index.json'):
 p=out/name
 if p.is_file():(dest/name).write_bytes(p.read_bytes())
with zipfile.ZipFile(dest/'raw.zip','w',zipfile.ZIP_DEFLATED) as package:
 for p in sorted(RUN.rglob('*')):
  if p.is_file() and p.name!='hyle.bundle':package.write(p,p.relative_to(RUN).as_posix())
 for name in ('launch_vulkan_encoded_p1.py','vulkan_encoded_p1_air.py','seal_vulkan_encoded_p1.py'):
  package.write(BASE/name,'runners/'+name)
 package.write(contract,'contract.json')
receipt={'kind':'G04_G05_VULKAN_Q8_ENCODED_PAGE_COMPLETE_JOURNEY_FINITE_P1',
 'attempt':attempt,'product_candidate':snapshot['product_candidate'],'performance_source':snapshot['source_commit'],
 'identity':job['identity'],'qualification':summary['qualification'] if summary else 'NO_SUMMARY',
 'performance':'PASS' if passed else ('FAIL' if qualified else 'UNPROVEN'),
 'contract_sha256':summary['contract_sha256'] if summary else None,
 'numerical_preflight_sha256':snapshot['numeric_receipt_sha256'],
 'verify_exit':job.get('verify_exit'),'qualification_exit':job['exit_code'],
 'aa_processes':len(aa['runs']) if aa else 0,'aa_verdict':aa['gate'] if aa else 'NO_RECEIPT',
 'product_processes':len(products),'control_processes':len(controls),'sample_stages':stages,
 'sampling_scope':'Original automatic n15->n31 only; preserve every raw stage; qualified final observations do not pool stages',
 'rows':rows,'job':job,'launch':launch,
 'measured_remote_seconds':job['elapsed_seconds'],
 'source_bundle_seconds_separate':snapshot['bundle_seconds'],
 'source_deploy_seconds_separate':launch['source_deploy_seconds'],
 'outer_observation_seconds_overlaps_remote':launch['elapsed_seconds'],
 'cold_cost_model':'Original immutable payload/schema/slots cold; per-operation prepare/native objects/F2/exact guards/gather/mask/normalization/copies/completion/output release all charged',
 'limits':['Finite F16 query/output and Q8_0 KV; three declared two-request shapes only',
  'Original non-MMQ general pipeline selected explicitly; no best-of original host claim',
  'No capture, incremental producer/growth, G06, whole G04/G05 or token/s verdict',
  'Native private-pool retained bytes and hard upper remain UNKNOWN',
  'SDK CPU provider predates CE12; this is actual Vulkan qualification only'],
 'raw_zip_sha256':hashlib.sha256((dest/'raw.zip').read_bytes()).hexdigest()}
(dest/'receipt.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:v for k,v in receipt.items() if k not in ('job','launch')},ensure_ascii=False))
