from pathlib import Path
import hashlib,json,subprocess,sys,time

ROOT=Path.cwd();BASE=ROOT/'.scratch/inference-gaps/g04-g05';attempt=int(sys.argv[1])
for name in ('post-ce12-validation-job-1.json','queued-vulkan-encoded-page-preflight-5.json','ce13-validation-job-3.json','ce13-air-cpu-mixed-job-3.json'):
 assert json.loads((BASE/name).read_text(encoding='utf-8'))['state']=='TERMINAL_PASS',name
for path in BASE.glob('cpu-encoded-p1-job-*.json'):
 assert json.loads(path.read_text(encoding='utf-8'))['state']=='TERMINAL',path
cpu_receipt=ROOT/'evidence/performance/inference-g04-g05-ce13-cpu-encoded-w1-p1/receipt.json'
if cpu_receipt.is_file():
 subprocess.run([sys.executable,str(BASE/'commit_sealed_receipt.py'),'evidence/performance/inference-g04-g05-ce13-cpu-encoded-w1-p1','test(compute): seal CE13 CPU qualified performance result'],check=True)
assert not subprocess.check_output(['git','status','--porcelain'],text=True).strip(),'freeze canonical evidence and source before qualification'
numeric=ROOT/'evidence/correctness/inference-g04-g05-vulkan-encoded-page-preflight/receipt.json'
assert json.loads(numeric.read_text(encoding='utf-8'))['verdict']=='PASS_NUMERICAL_LIFECYCLE_PREFLIGHT_ONLY'
assert subprocess.check_output(['git','ls-files',str(numeric.relative_to(ROOT))],text=True).strip(),'numeric receipt must be canonical and committed'
OUT=BASE/'vulkan-encoded-p1';OUT.mkdir(exist_ok=True);run=OUT/str(attempt);run.mkdir(exist_ok=False)
host='kiro@172.22.10.198';remote_base='/Users/kiro/hyle-scratch/compute-unified'
old=subprocess.check_output(['ssh','-o','BatchMode=yes',host,'git','-C',remote_base+'/g01-native-page-p1-source','rev-parse','HEAD'],text=True).strip()
subprocess.run(['git','merge-base','--is-ancestor',old,'HEAD'],check=True)
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
bundle=run/'hyle.bundle';start=time.monotonic()
subprocess.run(['git','-c','pack.threads=4','-c','pack.compression=1','bundle','create',str(bundle),'HEAD','^'+old],check=True)
snapshot={'attempt':attempt,'source_commit':head,'product_candidate':'982676cb05a6e6244e66e0a596347aa96043617b',
 'bundle_base':old,'bundle_sha256':hashlib.sha256(bundle.read_bytes()).hexdigest(),
 'bundle_seconds':time.monotonic()-start,'numeric_receipt_sha256':hashlib.sha256(numeric.read_bytes()).hexdigest(),
 'contract_file_sha256':hashlib.sha256((ROOT/'bench/inference_resident_sdpa/vulkan_encoded_p1/contract.json').read_bytes()).hexdigest()}
(run/'snapshot.json').write_text(json.dumps(snapshot,indent=2)+'\n',encoding='utf-8')
remote=remote_base+f'/g04-vulkan-encoded-p1-runs/{attempt}'
deploy_start=time.monotonic()
subprocess.run(['ssh','-o','BatchMode=yes',host,'mkdir','-p',remote],check=True)
subprocess.run(['scp',str(bundle),str(run/'snapshot.json'),str(BASE/'vulkan_encoded_p1_air.py'),host+':'+remote+'/'],check=True)
deploy_seconds=time.monotonic()-deploy_start
command=['ssh','-o','BatchMode=yes',host,'python3',remote+'/vulkan_encoded_p1_air.py',remote]
start=time.monotonic()
with (run/'launch.log').open('wb') as stream:
 child=subprocess.Popen(command,stdout=stream,stderr=subprocess.STDOUT)
 launch={'state':'OBSERVING','pid':child.pid,'command':command,'remote_run':remote,'snapshot':snapshot,'source_deploy_seconds':deploy_seconds}
 (run/'launch.json').write_text(json.dumps(launch,indent=2)+'\n',encoding='utf-8');print(json.dumps(launch),flush=True)
 code=child.wait()
download=subprocess.run(['scp','-r',host+':'+remote,str(run/'remote')]).returncode
state=None
if (run/'remote/job.json').is_file():state=json.loads((run/'remote/job.json').read_text(encoding='utf-8'))
output_download=None
if state and state['state']=='TERMINAL':
 output_download=subprocess.run(['scp','-r',host+':'+state['output'],str(run/'output')]).returncode
launch.update(state='TERMINAL' if state and state['state'].startswith('TERMINAL') else 'OBSERVATION_ENDED_UNKNOWN',
 ssh_exit=code,download_exit=download,output_download_exit=output_download,elapsed_seconds=time.monotonic()-start,remote_state=state)
(run/'launch.json').write_text(json.dumps(launch,indent=2)+'\n',encoding='utf-8');print(json.dumps(launch),flush=True)
raise SystemExit(code)
