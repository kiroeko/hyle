"""Prepare the original forty-process protocol. Never execute a model/compiler."""
from pathlib import Path
from collections import Counter
import ast
import copy
import hashlib
import json

W = Path(__file__).resolve().parent
R = W.parents[2]
OLD = R / '.scratch/inference-stable-attention-window-20261027/attempt1'
BUILD = R / '.scratch/inference-hidden-indexed-refinement-20261028'
ARMS = ('hyle_plain', 'hyle_auto', 'hyle_mtp', 'peer_plain', 'peer_mtp')
GROUPS = (('single', 'timing'), ('single', 'memory'), ('two-turn', 'timing'), ('two-turn', 'memory'))


def read(path):
    return json.loads(Path(path).read_bytes())


def pin(path):
    path = Path(path).resolve()
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        while chunk := stream.read(1 << 20):
            digest.update(chunk)
    return dict(path=str(path), bytes=path.stat().st_size, sha256=digest.hexdigest())


def exact(row):
    assert pin(row['path']) == row, row['path']


def save(path, value):
    path = Path(path)
    assert not path.exists(), ('Preserve previous preparations/attempts', str(path))
    path.write_bytes((json.dumps(value, indent=2) + '\n').encode())


def main():
    assert not (W / 'plan.json').exists()
    assert not any((W / f'{scenario}-{mode}').exists() for scenario, mode in GROUPS)
    assert (W / 'window.py').read_bytes() == (OLD / 'window.py').read_bytes()
    ast.parse((W / 'window.py').read_text(encoding='utf-8-sig'))
    ast.parse(Path(__file__).read_text(encoding='utf-8-sig'))
    current = read(BUILD / 'ready.json')
    assert current['image']['sha256'] == 'b59fe8525dcb3fee546748879ebc06690c493fdf2c73cf161c59b75a68a3b259'
    assert current['compiled']['snapshot']['sha256'] == '01c1b57631b0c51eb17deab19582c27b62e0923f0cc1fce7838e5bdeb2295ef8'
    assert current['compiled']['process']['exit'] == current['process']['exit'] == 0
    for item in (current['image'], current['runtime'], current['inputs'], current['plan'],
                 current['compiled']['source'], current['compiled']['snapshot'],
                 current['compiled']['actual_dependencies']):
        exact(item)
    frozen = read(current['plan']['path'])
    exact(frozen['base']); exact(frozen['inputs']); exact(frozen['headers'])
    backend = read(frozen['base']['path'])
    actual_inputs = read(current['inputs']['path'])
    base_inputs = read(frozen['inputs']['path'])
    assert len(actual_inputs) == len(base_inputs) == 226
    replacements = [(a, b) for a, b in zip(base_inputs, actual_inputs) if a != b]
    assert replacements == [(frozen['old_model']['object'], current['compiled']['object'])]
    assert all(unit['object'] in actual_inputs for unit in backend['compiled'].values())
    assert {'indexed-host', 'indexed-kernel'} <= set(backend['compiled'])
    assert len({item['path'] for item in actual_inputs}) == len(actual_inputs)
    peer = read(OLD / 'peer-ready.json')
    exact(peer['image']); exact(peer['runtime_environment'])
    assert peer['image']['sha256'] == '433e7051f4c36d0d9b2297dc378631546b7e3c44630cda0653cba2d1ec6bbe8e'
    prior = read(OLD / 'binding.json')
    gguf = prior['GGUF_offline_metadata']
    for kind in ('plain', 'full_mtp'):
        assert Path(gguf[kind]['path']).stat().st_size == gguf[kind]['bytes']
    assert gguf['plain']['tensors'] == 320 and gguf['full_mtp']['tensors'] == 335
    assert 'qwen35.nextn_predict_layers' not in gguf['plain']['metadata']
    assert gguf['full_mtp']['metadata']['qwen35.nextn_predict_layers'] == 1
    for key in ('prompt', 'input_manifest', 'schedule', 'protocol', 'GGUF_metadata_receipt'):
        exact(prior[key])
    fixture = Path(prior['input_manifest']['path']).parent
    prompt = Path(prior['prompt']['path']).read_text().split()
    assert len(prompt) == 154 and prompt == (fixture / 'prompt.ids').read_text().split()

    ready = dict(image=current['image'], instrumented=False,
        canonical_main=current['compiled']['snapshot'], runtime_environment=current['runtime'],
        link_inputs=current['inputs'], build=pin(BUILD / 'ready.json'),
        actual_dependencies=current['compiled']['actual_dependencies'],
        replacement_product_dependencies={key: unit['actual_dependencies'] for key, unit in backend['compiled'].items()},
        original_native_build=frozen['base'], source_headers=frozen['headers'],
        closure_inputs=226, current_Model_object=current['compiled']['object'],
        scope='Current hidden-indexed Model plus recorded indexed-Store/attention closure; not a full SDK rebuild or latest-upstream peer.')
    save(W / 'ready.json', ready); save(W / 'peer-ready.json', peer)
    arms = copy.deepcopy(read(OLD / 'arms.json'))
    for name, row in arms['arms'].items():
        row['ready'] = str(W / ('ready.json' if name.startswith('hyle') else 'peer-ready.json'))
    arms['note'] = 'Current hidden-state five-arm window; compare only these new samples. Internal ordinary off/auto arms share the current image; frozen peer433e is not latest upstream.'
    save(W / 'arms.json', arms)
    binding = dict(status='PREPARED_ONLY_ROOT_SCHEDULING_BEFORE_RUN', Hyle=current,
        current_Model=current['compiled'], current_indexed_Store_build=frozen['base'],
        inherited_native_build=backend, link_closure=current['inputs'], closure_inputs=226,
        Model_replacement=[dict(original=a, current=b) for a, b in replacements], peer=peer,
        retained_previous_protocol=pin(OLD / 'plan.json'), retained_previous_runner=pin(OLD / 'window.py'),
        current_runner=pin(W / 'window.py'), runner_bytes_identical=True,
        parser_amendment_reused=prior['parser_amendment_reused'],
        prompt=prior['prompt'], input_manifest=prior['input_manifest'], schedule=prior['schedule'],
        GGUF_offline_metadata=gguf, GGUF_metadata_receipt=prior['GGUF_metadata_receipt'], protocol=prior['protocol'],
        scopes=prior['scopes'], endpoint_and_sampler=prior['endpoint_and_sampler'],
        actual_auto_counts=prior['actual_auto_counts'], historical_samples_pooled=False,
        payload_copied=False, payload_hashed=False, model_or_compiler_processes_started=0,
        process_limits=dict(unique_model_processes=40, timing=30, independent_memory=10,
            retained_execute_timeout_seconds=900, GPU_concurrency=1, automatic_retries=0),
        source_scope='The new image uses current Model01c1 and the 226-entry recorded closure, including indexed host/kernel additions. No old Hyle binary or historical TPS is a current control arm.')
    save(W / 'binding.json', binding)
    groups = []
    ordinal = 0
    for scenario, mode in GROUPS:
        previous = read(OLD / f'{scenario}-{mode}-plan.json')
        expected = list(ARMS) if mode == 'memory' else [ARMS[(i + j) % 5] for j in range(3) for i in range(5)]
        assert previous['arm_order'] == expected
        group = copy.deepcopy(previous)
        rows = []
        for old in previous['commands']:
            row = copy.deepcopy(old)
            arm = row['arm']; folder = W / f'{scenario}-{mode}' / f"{row['ordinal']:02}-{arm}"
            row['folder'] = str(folder); command = row['command']
            if arm.startswith('hyle'):
                command[0] = current['image']['path']
                row.update(image=current['image'], environment=current['runtime'], ready=pin(W / 'ready.json'))
                assert command[command.index('--decode-overlap') + 1] == ('auto' if arm == 'hyle_auto' else 'off')
            else:
                command[0] = peer['image']['path']; command[command.index('--output') + 1] = str(folder / 'consumer-result.json')
                row.update(image=peer['image'], environment=peer['runtime_environment'], ready=pin(W / 'peer-ready.json'))
                assert command[command.index('--model') + 1] == gguf['full_mtp' if arm == 'peer_mtp' else 'plain']['path']
            assert command[command.index('--mtp') + 1] == ('on' if arm.endswith('_mtp') else 'off')
            assert command[command.index('--capacity') + 1] == '1024'
            assert not any(flag in command for flag in ('--trace', '--decode-ids', '--ignore-eos', '--layer0-probe'))
            if scenario == 'single':
                assert command[command.index('--steps') + 1] == '64'
            else:
                assert command[command.index('--schedule') + 1] == binding['schedule']['path'] and '--steps' not in command
            restore = command.copy(); restore[0] = old['command'][0]
            if arm.startswith('peer'):
                restore[restore.index('--output') + 1] = old['command'][old['command'].index('--output') + 1]
            assert restore == old['command'], 'Only image/output locations may change'
            ordinal += 1; assert row['window_ordinal'] == ordinal; rows.append(row)
        assert Counter(row['arm'] for row in rows) == {arm: 3 if mode == 'timing' else 1 for arm in ARMS}
        assert group['memory_interval_seconds'] == 0.01 and not group['profiler'] and not group['warmup']
        group.update(commands=rows, binding=pin(W / 'binding.json'), configuration=pin(W / 'arms.json'),
            canonical_main=current['compiled']['snapshot'], retained_plan=pin(OLD / f'{scenario}-{mode}-plan.json'),
            script=pin(W / 'window.py'), plan_only=True, current_window_comparison_only=True, historical_samples_pooled=False)
        save(W / f'{scenario}-{mode}-plan.json', group)
        groups.append(dict(scenario=scenario, mode=mode, processes=len(rows), order=expected,
            plan=pin(W / f'{scenario}-{mode}-plan.json')))
    assert ordinal == 40
    plan = dict(status='PREPARED_NOT_RUN_NOT_COMPILED', processes=40, timing_processes=30,
        independent_memory_processes=10, groups=groups, ready=pin(BUILD / 'ready.json'),
        binding=pin(W / 'binding.json'), adapter=pin(W / 'window.py'), prepare_script=pin(Path(__file__)),
        scope=binding['scopes'], metrics=read(OLD / 'plan.json')['metrics'],
        future_commands=[['python', str(W / 'window.py'), 'run-one', scenario, mode] for scenario, mode in GROUPS],
        summary_command=['python', str(W / 'window.py'), 'summary'],
        constraints=['Prepare only; root owns scheduling after whole-state checks.',
            'Forty unique offline model processes, sequential; 30 timing and 10 independent memory; no warmup/profiler/download/compiler.',
            'Original runner is byte-identical, including bounded 900s execute timeout, complete endpoint/partition gates, exact within-arm non-time checks and 10ms requested PSAPI/PDH/null rules.',
            'Same input IDs, BF16 roles, fixed peer433e, natural EOS, greedy, C1024/N1/R1/K1; no historical samples pooled.',
            'Stop first actual failure and retain every attempt; a parser-only error is repaired offline/resume-one, never a replacement success process.',
            'Native attention/Store additions and current Model are distinct from old stable-attention image; cross-window deltas alone are not causal attribution.'])
    save(W / 'plan.json', plan)
    save(W / 'prepare-result.json', dict(status='PREPARED_40_NOT_RUN', plan=pin(W / 'plan.json'),
        image=current['image'], runner_unchanged=True, commands=40, closure_inputs=226,
        compiler_processes=0, model_processes=0, GPU_processes=0))
    print('PREPARED_40_NOT_RUN: 30 timing + 10 independent memory; original runner unchanged; 0 model/CXX/GPU')


if __name__ == '__main__':
    main()
