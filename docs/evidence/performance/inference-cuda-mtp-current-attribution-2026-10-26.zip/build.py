"""Explicit build action: one consumer host TU and one retained link per arm."""
from pathlib import Path
import importlib.util
import json
import os
import sys

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = W.parents[1]
spec = importlib.util.spec_from_file_location('attribution_prepare', W / 'prepare.py')
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)
spec = importlib.util.spec_from_file_location('retained_host_execution', R / '.scratch/inference-synchronous-step-report-20261025/check_host.py')
h = importlib.util.module_from_spec(spec)
spec.loader.exec_module(h)

def key(p):
    return os.path.normcase(str(Path(p).resolve()))

def exact(row):
    assert m.pin(row['path']) == row, 'Input changed: ' + row['path']

def build(arm):
    assert arm in ('hyle', 'peer')
    plan = m.read(W / 'plan.json')
    exact(plan['source_pins'])
    exact(plan['baseline_dependencies'])
    exact(plan['baseline_link_inputs'])
    F = W / arm
    if (F / 'compile').exists() or (F / 'link').exists():
        raise FileExistsError('One build per arm; preserve failure, no automatic retry')
    for row in m.read(W / 'source-pins.json')['files']:
        exact(row['before']); exact(row['after']); exact(row['patch'])
    exact(m.read(W / 'source-pins.json')['helper'])
    for row in m.read(W / 'baseline-dependencies.json')[arm]:
        exact(row['compile_input'])
    for row in m.read(W / 'baseline-link-inputs.json')[arm]:
        exact(row)
    if arm == 'hyle':
        ready = m.read(m.H / 'ready.json')
        exact(ready['image']); exact(ready['app']); exact(ready['link_inputs'])
        old = m.read(m.H / 'compile/command.json')['command']
        original_link = m.H / 'link/process/command.json'
        old_obj = ready['app']['path']
        source = F / 'source/engine/models/qwen35/main.cc'
        source_path = m.H / 'source/engine/models/qwen35/main.cc'
        old_dependencies = m.read(m.H / 'compile/actual-dependencies.json')
        runtime_path = m.H / 'runtime.json'
    else:
        ready = m.read(plan['baseline_peer_ready']['path'])
        exact(ready['image']); exact(ready['compiled_identity']); exact(ready['link_plan'])
        identity = m.read(m.P / 'compile1/peer/identity.json')
        old = identity['command']
        original_link = m.P / 'peer-link1/link-plan.json'
        old_obj = identity['object']['path']
        source = F / 'source/peer_multiturn.cc'
        source_path = m.P / 'source/peer_multiturn.cc'
        old_dependencies = identity['dependencies']
        runtime_path = Path(ready['runtime_environment']['path'])
    flags = []
    skip = False
    for a in old[1:]:
        if skip:
            skip = False
            continue
        if a == '/sourceDependencies':
            skip = True
            continue
        if a.lower().startswith(('/fo', '/fd')) or key(a) == key(source_path):
            continue
        if arm == 'hyle' and a.lower().startswith('/i') and str(m.H / 'source').lower() in a.lower():
            continue
        flags.append(a)
    cmd = [old[0], '/I' + str(W), '/external:IC:\\Program Files\\NVIDIA GPU Computing Toolkit\\CUDA\\v13.3\\include',
           *flags, str(source), '/sourceDependencies', str(F / 'compile/dependencies.json'),
           '/Fo' + str(F / 'compile/unit.obj'), '/Fd' + str(F / 'compile/unit.pdb')]
    assert cmd == m.read(F / 'build-plan.json')['compile']
    assert all(x in cmd for x in ('/W4', '/WX', '/O2', '/MD', '/DGGML_USE_CUDA'))
    env = h.discover_environment(compiler='msvc', cache={'CMAKE_C_COMPILER': old[0],
        'CMAKE_CXX_COMPILER': old[0], 'CMAKE_GENERATOR': 'Ninja'}, backends=()).env
    compiled = h.execute(cmd, env, F / 'compile', timeout=120)
    dep = m.read(F / 'compile/dependencies.json')['Data']
    actual = [m.pin(p) for p in dict.fromkeys([dep['Source'], *dep['Includes']])]
    def canonical(p):
        p = Path(p)
        if arm == 'hyle' and p.is_relative_to(F / 'source'):
            return R / p.relative_to(F / 'source')
        if arm == 'hyle' and p.is_relative_to(m.H / 'source'):
            return R / p.relative_to(m.H / 'source')
        if arm == 'peer' and p.name == 'peer_multiturn.cc':
            return source_path
        if arm == 'peer' and p.is_relative_to(F / 'source'):
            return R / 'tools/qwen35_text' / p.name
        return p
    mapped = {key(canonical(x['path'])): x for x in actual}
    baseline = {key(canonical(x['path'])): x for x in old_dependencies}
    assert set(baseline) <= set(mapped), 'Original dependency missing'
    changed = [k for k in baseline if baseline[k]['sha256'] != mapped[k]['sha256']]
    expected = key(R / 'engine/models/qwen35/main.cc') if arm == 'hyle' else key(source_path)
    assert changed == [expected], changed
    assert key(W / 'logical_trace.h') in mapped
    m.save(F / 'compile/actual-dependencies.json', actual)
    m.save(F / 'compile/dependency-contract.json', dict(original=len(baseline), actual=len(actual),
        original_unchanged=len(baseline) - 1, changed_source=changed,
        added=[x for k, x in mapped.items() if k not in baseline]))
    original = m.read(original_link)['command']
    original_inputs = [m.pin(p) for p in original if Path(p).is_absolute() and Path(p).suffix.lower() in ('.obj', '.lib')]
    if arm == 'hyle':
        assert original_inputs == m.read(m.H / 'link-inputs.json')
    else:
        assert original_inputs == m.read(original_link)['inputs']
    link = []
    replacements = 0
    for a in original:
        if key(a) == key(old_obj):
            link.append(str(F / 'compile/unit.obj')); replacements += 1
        elif not a.lower().startswith(('/out:', '/pdb:', '/map:', '/implib:')):
            link.append(a)
    assert replacements == 1
    link += ['/OUT:' + str(F / 'link/consumer.exe'), '/PDB:' + str(F / 'link/consumer.pdb'),
             '/IMPLIB:' + str(F / 'link/consumer.lib')]
    assert link == m.read(F / 'build-plan.json')['link']
    retained = [x for x in original_inputs if key(x['path']) != key(old_obj)]
    for row in retained:
        exact(row)
    m.save(F / 'link-inputs.json', [m.pin(F / 'compile/unit.obj'), *retained])
    m.save(F / 'link-contract.json', dict(original_recipe=m.pin(original_link), replaced=[old_obj],
        unchanged_absolute_inputs=len(retained), no_other_TU=True, original_entry_retained=arm == 'hyle', SDK_builds=0))
    linked = h.execute(link, env, F / 'link', timeout=120)
    for row in retained:
        exact(row)
    runtime = m.read(runtime_path)
    if arm == 'hyle':
        alias = F / 'link' / Path(runtime['native_hardlink']['path']).name
        os.link(runtime['native']['path'], alias)
        runtime['native_hardlink'] = m.pin(alias)
    m.save(F / 'runtime.json', runtime)
    m.save(F / 'ready.json', dict(status='INSTRUMENTED_CONSUMER_BUILT_NOT_PROFILED', image=m.pin(F / 'link/consumer.exe'),
        app=m.pin(F / 'compile/unit.obj'), source=m.pin(source), source_pins=m.pin(W / 'source-pins.json'),
        actual_dependencies=m.pin(F / 'compile/actual-dependencies.json'), link_inputs=m.pin(F / 'link-inputs.json'),
        runtime=m.pin(F / 'runtime.json'), compile=compiled, link=linked, original_ready=plan['baseline_' + arm + '_ready'],
        new_host_TUs=1, SDK_builds=0, model_runs=0, scope='NVTX-only delta; mathematical/native/kernel/Graph/report closure retained'))
    print(arm, 'READY', m.pin(F / 'ready.json'))

if __name__ == '__main__':
    build(sys.argv[1])
