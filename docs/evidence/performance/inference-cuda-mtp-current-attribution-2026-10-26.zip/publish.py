"""Publish the completed finite diagnostic. Never launches a consumer or compiler."""
from pathlib import Path
import hashlib
import io
import json
import subprocess
import zipfile

W = Path(__file__).resolve().parent
R = W.parents[1]
DEST = R / 'docs/evidence/performance'
NAME = 'inference-cuda-mtp-current-attribution-2026-10-26'

def read(path):
    return json.loads(Path(path).read_bytes())

def pin(path):
    path = Path(path)
    raw = path.read_bytes()
    return dict(path=str(path.resolve()), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())

def encoded(value):
    return (json.dumps(value, ensure_ascii=False, indent=2) + '\n').encode('utf-8')

assert not (DEST / (NAME + '.json')).exists()
assert not (DEST / (NAME + '.zip')).exists()
memo = read(W / 'memo.json')
review = read(W / 'independent-analysis-review.json')
assert review['status'] == 'NO_BLOCKING_FINDING_WITHIN_FINITE_OFFLINE_REVIEW'
assert review['blocking_findings'] == []
supplement = read(W / 'decode-window-supplement.json')
files = {}
for p in W.glob('*'):
    if p.is_file() and p.suffix in ('.py', '.h', '.json'):
        files[p.relative_to(W).as_posix()] = p.read_bytes()
for folder in ('hyle', 'peer', 'first-preparation-gate', 'capability'):
    for p in (W / folder).rglob('*'):
        if p.is_file() and p.suffix in ('.cc', '.h', '.json', '.py', '.patch', '.log', '.sqlite'):
            assert p.resolve().is_relative_to(W.resolve())
            assert not p.is_symlink()
            files[p.relative_to(W).as_posix()] = p.read_bytes()
for name in ('gpu.json', 'gpu.stdout.log', 'gpu.stderr.log', 'resources.json'):
    p = W / 'preflight' / name
    files[p.relative_to(W).as_posix()] = p.read_bytes()

base = R / '.scratch/inference-current-closure-20261026/full-window/two-turn-timing'
for arm, folder in [('hyle', '02-hyle_mtp'), ('peer', '04-peer_mtp')]:
    for name in ('command.json', 'result.json', 'stdout.log', 'stderr.log'):
        p = base / folder / name
        files[f'references/{arm}/{name}'] = p.read_bytes()
    if arm == 'peer':
        files['references/peer/consumer-result.json'] = (base / folder / 'consumer-result.json').read_bytes()
    quality = read(W / arm / 'trace1/quality.json')
    assert quality['status'] == 'PASS' and quality['full_non_time_equal']
    assert not quality['missing_nvtx_ends']
    assert read(W / arm / 'trace1/process.json')['exit'] == 0

# The preflight process list is intentionally excluded: application inventories
# and environment details are unnecessary to reproduce the completed result.
manifest = [dict(path=name, bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())
            for name, raw in sorted(files.items())]
files['manifest.json'] = encoded(dict(files=manifest, excluded='SDKs, weights, objects, executables, DLLs, PDBs, duplicate nsys-rep and unrelated desktop process inventory'))
data = io.BytesIO()
with zipfile.ZipFile(data, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
    for name, raw in sorted(files.items()):
        archive.writestr(name, raw)
blob = data.getvalue()
with zipfile.ZipFile(io.BytesIO(blob)) as archive:
    assert archive.testzip() is None
    for row in manifest:
        raw = archive.read(row['path'])
        assert len(raw) == row['bytes'] and hashlib.sha256(raw).hexdigest() == row['sha256']

out = DEST / (NAME + '.zip')
out.write_bytes(blob)
result = dict(
    schema='hyle.performance.evidence.v1', date='2026-10-26',
    status='PASS_ONE_PAIRED_MTP_DIAGNOSTIC_NOT_A_THROUGHPUT_WINDOW',
    head_before_documentation=subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=R, text=True).strip(),
    hardware='Windows; NVIDIA GeForce RTX 4070 12GiB; driver 617.14',
    scope='Pure CUDA Qwen3.5-2B BF16 weights, original score/activation policy, C1024 N1 R1, greedy K1 MTP, two natural P154+64 turns. One profiled process per engine. No SDK/native/kernel or product source change.',
    identities={arm: read(W / arm / 'ready.json') for arm in ('hyle', 'peer')},
    findings=memo,
    decode_window_supplement=supplement,
    independent_review=review,
    references=dict(formal_performance='inference-current-window-2026-10-26.json',
                    current_source_build='../research/inference-current-source-build-2026-10-26.json'),
    limits=[
        'These Nsight/NVTX timings are diagnostic only. Formal prefill/decode/startup/RAM/VRAM/combined throughput results are unchanged.',
        'Hyle combines target and draft in one Invocation; peer native-call boundaries differ. Matching emitted tokens does not make actual accepted work, intermediates or generation identical.',
        'GPU interval unions and API intervals do not establish recoverable CPU time. Nested intervals are never added as separate costs.',
        'The CUDA consumer inherits the explicitly frozen 2a94 closure; its Model and sampling header match current sources. New CPU team/View code is outside this CUDA validation.',
        'Peer is the retained patched 433 closure with diagnostic-only consumer markers, not latest upstream. Weights and dependency binaries were reused, not downloaded or rebuilt.',
        'One pre-compiler preparation-field failure is retained. Actual compiler/link stages and the two consumers completed; no model/profile retry.',
        'Peer ProcessStreams stdout is truncated; full consumer-result.json is retained and used for full non-time equality. No report completeness claim is based on the truncated stream.'
    ],
    archive=dict(path=out.name, bytes=len(blob), sha256=hashlib.sha256(blob).hexdigest(),
                 members=len(files), verification='ZIP CRC and every manifest length/SHA256 passed'))
(DEST / (NAME + '.json')).write_bytes(encoded(result))
print(json.dumps(dict(report=NAME + '.json', archive=result['archive']), indent=2))
