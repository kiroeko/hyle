"""Last offline supplement: same-clock continuous decode envelopes and gaps."""
from pathlib import Path
import importlib.util
import sqlite3

W = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('same_pair_unions', W / 'analyze.py')
a = importlib.util.module_from_spec(spec)
spec.loader.exec_module(a)
out = {}
for arm in ('hyle', 'peer'):
    F = W / arm / 'trace1'
    rows = a.m.read(W / arm / 'episode-rows.json')
    report = a.parse_report(arm)
    source_path = W / arm / 'source' / ('engine/models/qwen35/main.cc' if arm == 'hyle' else 'peer_multiturn.cc')
    source_lines = source_path.read_text().splitlines()
    def source_line(fragment):
        found = [i + 1 for i, line in enumerate(source_lines) if fragment in line]
        assert len(found) == 1, (fragment, found)
        return found[0]
    turns = report['sessions'][0]['result']['turns'] if arm == 'hyle' else report['turns']
    c = sqlite3.connect('file:' + (F / 'trace.sqlite').as_posix() + '?mode=ro', uri=True)
    c.row_factory = sqlite3.Row
    nvtx = [dict(x) for x in c.execute(a.SQL['nvtx']) if x['end'] is not None and x['label']]
    tables = {x[0] for x in c.execute("SELECT name FROM sqlite_master WHERE type='table'")}
    gpu = []
    for kind, table in [('kernel', 'CUPTI_ACTIVITY_KIND_KERNEL'), ('copy', 'CUPTI_ACTIVITY_KIND_MEMCPY'), ('memset', 'CUPTI_ACTIVITY_KIND_MEMSET')]:
        if table in tables:
            gpu += [dict(x, kind=kind) for x in c.execute(a.SQL[kind])]
    c.close()
    result = []
    for turn in turns:
        n = turn['turn']
        rs = [r for r in rows if not r['prefill'] and (r['same_run_ledger']['turn'] if arm == 'hyle' else r['meta']['turn']) == n]
        assert rs and rs == sorted(rs, key=lambda r: r['start_ns'])
        prepare = ([p for r in rs for p in r['phases'] if p['label'] == 'hyle/prepare'] if arm == 'hyle' else
                   [p for p in nvtx if p['label'].startswith('peer/prepare_') and p['uint64Value'] in {r['meta']['seq'] for r in rs}])
        starts = [p['start_ns'] if 'start_ns' in p else p['start'] for p in prepare]
        ends = [p['end_ns'] if 'end_ns' in p else p['end'] for p in prepare]
        lo = min(rs[0]['start_ns'], min(starts))
        last = rs[-1]
        assert arm == 'hyle' or last['source_role'] == 'target'
        hi = last['end_ns']
        roots = [(r['start_ns'], r['end_ns']) for r in rs]
        root_union = a.measure(roots)
        assert root_union == sum(b - x for x, b in roots), 'Root overlap must be reported, not added'
        gaps = a.subtract([(lo, hi)], roots)
        prep_gaps = [(max(x, p), min(b, q)) for x, b in gaps for p, q in zip(starts, ends) if x < q and p < b]
        gpu_intervals = [(max(lo, x['start']), min(hi, x['end'])) for x in gpu if lo < x['end'] and x['start'] < hi]
        gpu_gap_intervals = a.subtract(gpu_intervals, roots)
        all_gpu_union = a.measure(gpu_intervals)
        gap_gpu_union = a.measure(gpu_gap_intervals)
        result.append(dict(turn=n, first_seq=rs[0]['meta']['seq'], last_seq=last['meta']['seq'],
            actual_root_count=len(rs), role_counts={role: sum(r['source_role'] == role for r in rs) for role in sorted({r['source_role'] for r in rs})},
            start_ns=lo, first_root_start_ns=rs[0]['start_ns'], end_ns=hi,
            start_definition='earliest firstdecode Batch.fill prepare / native decode root' if arm == 'peer' else 'firstdecode episode (its prepare child starts just after it)',
            end_definition='lasttarget native decode+synchronize rootend' if arm == 'peer' else 'lastcombined K1 episode rootend',
            continuous_wall_ms=(hi - lo) / 1e6, root_wall_union_ms=root_union / 1e6,
            gap_wall_ms=a.measure(gaps) / 1e6, gap_count=len(gaps), gaps_ns=gaps,
            prepare_inside_gaps_ms=a.measure(prep_gaps) / 1e6,
            gap_outside_prepare_ms=(a.measure(gaps) - a.measure(prep_gaps)) / 1e6,
            continuous_gpu_union_ms=all_gpu_union / 1e6, gpu_in_gaps_union_ms=gap_gpu_union / 1e6,
            continuous_no_observed_gpu_ms=((hi - lo) - all_gpu_union) / 1e6,
            reported_JSON_decode_ms=turn['decode_seconds'] * 1000,
            JSON_note='Shown independently. No timestamp bridge for original Clock endpoints was added; NVTX setup/end overhead and uncovered leading/trailing work prevent equating or subtracting these as exact same boundaries.'))
    out[arm] = dict(turns=result,
        sum_same_clock_windows_ms=sum(x['continuous_wall_ms'] for x in result),
        sum_disjoint_root_wall_ms=sum(x['root_wall_union_ms'] for x in result),
        sum_gap_wall_ms=sum(x['gap_wall_ms'] for x in result),
        reported_JSON_total_decode_ms=report['decode_seconds'] * 1000,
        endpoint_source=dict(path='engine/models/qwen35/main.cc' if arm == 'hyle' else 'peer_multiturn.cc',
            frozen_source=a.m.pin(W / arm / 'source' / ('engine/models/qwen35/main.cc' if arm == 'hyle' else 'peer_multiturn.cc')),
            anchors=([dict(line=source_line('const auto finished = Clock::now();'), meaning='original finished Clock endpoint before NVTX range ends and observer/report IO'),
                      dict(line=source_line('if (!record.imported) request.endpoint = record.endpoint;'), meaning='observe_generation_commits installs record.endpoint into request/turn endpoints'),
                      dict(line=source_line('const auto seconds = std::chrono::duration<double>(finished - endpoint).count();'), meaning='run_generation_sessions classifies continuous finished-minus-previousendpoint by generation/prefill bucket'),
                      dict(line=source_line('decode_seconds += std::chrono::duration<double>(turn.endpoint - turn.prefill_endpoint).count();'), meaning='per-request turn decode is lastpublished turnendpoint minus prefill endpoint')]
                     if arm == 'hyle' else [dict(line=source_line('const auto prefill_end = Clock::now(), decode_begin = prefill_end;'), meaning='decode_begin equals prefill_end before marker IO/whileloop setup'),
                      dict(line=source_line('llama_synchronize(context); const auto retired = Clock::now();'), meaning='native callroot ends immediately after synchronize retired Clock, before sampling/hidden/state selection'),
                      dict(line=source_line('const auto end = Clock::now();'), meaning='per-round end after sample/hidden/trim/carry and emitted updates, then rounds JSON construction'),
                      dict(line=source_line('endpoint = Clock::now(); marker(label("decode_end").c_str(), endpoint);'), meaning='wholeturn decodeendpoint after loop, so includes final sample/hidden/trim and rounds JSON tail')]),
            uncovered=('Leading work after prefill endpoint through caller reporting/admission/prepare preflight; gaps contain caller/observe/report/nextloop work. NVTX rootend follows original finished Clock by range-end calls, while original lastreport is outside finalendpoint.'
                       if arm == 'hyle' else 'Leading prefill-end marker and loop setup precede firstBatch.fill marker. Native-root gaps contain prepare, sampled token/hidden reads, cache trim, carry/prior construction and round JSON; final target post-synchronize sample/hidden/trim/round JSON is beyond the lastroot end but inside JSON decode.')))
a.m.save(W / 'decode-window-supplement.json', dict(arms=out,
    scope='Only same new NVTX/CUPTI clock within each trace. Different root definitions and natural workloads remain; no paired speed from bags of means.',
    stream_limit=dict(peer_stdout_bytes=10240, peer_complete_consumer_result=a.m.pin(W / 'peer/trace1/consumer-result.json'),
        fact='Nsight ProcessStreams peerstdout is truncated midJSON. Existing quality gate correctly used complete separate consumer-result.json; no rerun or rawlog alteration.'),
    next_action=dict(decision='NO_READY_NET_BENEFIT_PRODUCT_PATCH_FROM_CURRENT_TARGET_KERNEL_SIGNATURES',
        scope='Observed target signatures are BF16 cuBLAS/CUTLASS WMMA, existing hyle_bf16_l2 and native GDN/attention. Generic kernel/grid signatures alone do not uniquely identify every logical matrix K/N.',
        closed=[dict(shape='M2 K2048 N6144 paired gate/up; wideN12288', evidence='docs/evidence/performance/mtp-m2-wide-lt-screen-2026-10-26.json', decision='Closed wideLt; no reopen from this trace.'),
                dict(shape='M2 K2048 N6144 typedMMF', evidence='docs/evidence/performance/mtp-m2-typed-mmf-consumer-screen-2026-10-26.json', decision='Closed actualconsumer no stable net gain; no reopen.'),
                dict(shape='M2 K6144 N2048 down', evidence='docs/evidence/performance/qwen-m2-typed-mmvf-consumer-screen-2026-10-24.json', decision='Leaf improved but actualconsumer rejected. OlddownLt cold algorithms also closed; not an untested easy gap.'),
                dict(shape='head cast/Top1 suffix', evidence='docs/evidence/performance/qwen-top1-real-suffix-2026-10-20.json', decision='Closed directBF16 Top1; largeheadkernel time does not justify repeating it.')],
        proposed_single_next='Continue original replay internal hostpath attribution against this same71.48ms/30.85ms instrumented envelope, as Rootscheduled; preserve cold/steady and native/API nesting, then require an actual removable mechanism before another speedcandidate. This does not claim that envelope as recoverable.',
        not_proposed='No new densekernel, generic shader/provider rewrite, same-shape MMF/MMVF retry, or largearchitecture change fromN1 gap. No new run/build authorized here.')))
for arm, x in out.items():
    print(arm, [(r['turn'], r['actual_root_count'], round(r['continuous_wall_ms'], 6), round(r['root_wall_union_ms'], 6), round(r['gap_wall_ms'], 6), round(r['prepare_inside_gaps_ms'], 6), round(r['gpu_in_gaps_union_ms'], 6), r['reported_JSON_decode_ms']) for r in x['turns']])
