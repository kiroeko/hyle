"""Offline only: original NVTX/CUPTI boundaries, correlation and interval unions."""
from pathlib import Path
from collections import Counter, defaultdict
import hashlib
import importlib.util
import json
import re
import sqlite3
import statistics
import sys

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = W.parents[1]
spec = importlib.util.spec_from_file_location('frozen_pair_plan', W / 'prepare.py')
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)
SQL = dict(
    nvtx='SELECT n.*,COALESCE(n.text,s.value) label FROM NVTX_EVENTS n LEFT JOIN StringIds s ON s.id=n.textId ORDER BY n.start',
    runtime='SELECT a.*,s.value api FROM CUPTI_ACTIVITY_KIND_RUNTIME a JOIN StringIds s ON s.id=a.nameId ORDER BY a.start',
    driver='SELECT a.*,s.value api FROM CUPTI_ACTIVITY_KIND_DRIVER a JOIN StringIds s ON s.id=a.nameId ORDER BY a.start',
    kernel='SELECT a.*,s.value name FROM CUPTI_ACTIVITY_KIND_KERNEL a JOIN StringIds s ON s.id=a.demangledName ORDER BY a.start',
    copy='SELECT * FROM CUPTI_ACTIVITY_KIND_MEMCPY ORDER BY start',
    memset='SELECT * FROM CUPTI_ACTIVITY_KIND_MEMSET ORDER BY start')

def merged(xs):
    out = []
    for a, b in sorted(xs):
        if b <= a:
            continue
        if out and a <= out[-1][1]:
            out[-1][1] = max(b, out[-1][1])
        else:
            out.append([a, b])
    return out

def measure(xs):
    return sum(b - a for a, b in merged(xs))

def event_union(xs, bounds=None):
    return measure((max(x['start'], bounds[0]), min(x['end'], bounds[1])) if bounds else (x['start'], x['end']) for x in xs)

def subtract(xs, ys):
    result = []
    ys = merged(ys)
    for a, b in merged(xs):
        pieces = [(a, b)]
        for c, d in ys:
            pieces = [(u, v) for lo, hi in pieces for u, v in ((lo, min(c, hi)), (max(d, lo), hi)) if v > u]
        result.extend(pieces)
    return merged(result)

def stats(xs):
    xs = list(xs)
    return dict(count=len(xs), total_ms=sum(xs) / 1e6, mean_ms=statistics.mean(xs) / 1e6,
                median_ms=statistics.median(xs) / 1e6, min_ms=min(xs) / 1e6, max_ms=max(xs) / 1e6) if xs else dict(count=0)

def category(name):
    n = name.lower()
    if 'gated_delta' in n:
        return 'GDN'
    if 'ssm_conv' in n:
        return 'causal_conv'
    if any(x in n for x in ('flashinfer', 'fattn', 'attention', 'merge_states')):
        return 'attention_or_attention_merge'
    if any(x in n for x in ('mul_mat', 'hyle_bf16_l2', 'gemm', 'gemv', 'cutlass::kernel')):
        return 'dense_projection_kernel'
    if any(x in n for x in ('topk', 'top_k', 'argmax')):
        return 'TopK_or_argmax'
    if any(x in n for x in ('cpy', 'copy', 'convert', 'cast')):
        return 'typed_copy_or_conversion_kernel'
    if 'norm' in n:
        return 'normalization'
    if 'rope' in n:
        return 'rotary'
    if any(x in n for x in ('unary', 'bin_', 'silu', 'scale_', 'concat', 'get_rows')):
        return 'elementwise_or_indexing'
    return 'other_name_unclassified'

def api_recording(x):
    return any(k in x['api'] for k in ('StreamBeginCapture', 'StreamEndCapture', 'GraphInstantiate', 'GraphExecUpdate'))

def phase_metrics(phase, gpu, apis):
    a, b = phase['start'], phase['end']
    work = [x for x in gpu if x['start'] < b and a < x['end']]
    calls = [x for x in apis if x['globalTid'] == phase['globalTid'] and x['start'] < b and a < x['end']]
    gu = event_union(work, (a, b))
    return dict(label=phase['label'], start_ns=a, end_ns=b, wall_ns=b - a,
                gpu_overlap_union_ns=gu, wall_without_observed_gpu_ns=b - a - gu,
                api_overlap_union_ns=event_union(calls, (a, b)), api_count=len(calls))

def parse_report(arm):
    F = W / arm / 'trace1'
    if arm == 'peer':
        return m.read(F / 'consumer-result.json')
    text = (F / 'native-stdout.log').read_text(encoding='utf8')
    return json.JSONDecoder().raw_decode(text[text.index('{"source_id"'):])[0]

def analyze(arm):
    F = W / arm / 'trace1'
    assert m.read(F / 'quality.json')['status'] == 'PASS'
    c = sqlite3.connect('file:' + (F / 'trace.sqlite').as_posix() + '?mode=ro', uri=True)
    c.row_factory = sqlite3.Row
    tables = {x[0] for x in c.execute("SELECT name FROM sqlite_master WHERE type='table'")}
    nvtx = [dict(x) for x in c.execute(SQL['nvtx'])]
    closed = [x for x in nvtx if x['end'] is not None and x['label']]
    roots = [x for x in closed if x['label'].startswith('hyle/episode' if arm == 'hyle' else ('peer/target_', 'peer/draft_'))]
    runtime = [dict(x, table='runtime') for x in c.execute(SQL['runtime'])]
    driver = [dict(x, table='driver') for x in c.execute(SQL['driver'])] if 'CUPTI_ACTIVITY_KIND_DRIVER' in tables else []
    apis = sorted(runtime + driver, key=lambda x: x['start'])
    gpu = []
    for kind, table in [('kernel', 'CUPTI_ACTIVITY_KIND_KERNEL'), ('copy', 'CUPTI_ACTIVITY_KIND_MEMCPY'), ('memset', 'CUPTI_ACTIVITY_KIND_MEMSET')]:
        if table in tables:
            gpu += [dict(x, kind=kind) for x in c.execute(SQL[kind])]
    gpu.sort(key=lambda x: x['start'])
    for i, x in enumerate(gpu):
        x['activity_index'] = i
    diagnostics = [dict(x) for x in c.execute('SELECT * FROM DIAGNOSTIC_EVENT')] if 'DIAGNOSTIC_EVENT' in tables else []
    c.close()
    # globalTid is the export's encoded process/thread identity; validate this
    # bit boundary against every observed GPU globalPid rather than equating OS PID.
    process_base = lambda tid: tid & ~((1 << 24) - 1)
    root_pids = {process_base(x['globalTid']) for x in roots}
    gpu_pids = {x['globalPid'] for x in gpu}
    assert len(root_pids) == 1 and root_pids == gpu_pids, (root_pids, gpu_pids)
    native_report = parse_report(arm)
    rows = []
    shape_seen = Counter()
    attributed = set()
    signatures = {}
    for root in roots:
        a, b, tid = root['start'], root['end'], root['globalTid']
        meta = {k: int(v) for k, v in re.findall(r'(\w+)=(\d+)', root['label'])}
        role = 'combined_K1' if arm == 'hyle' else ('target' if root['label'].startswith('peer/target') else 'draft')
        is_prefill = meta['role'] in (2, 7) if arm == 'hyle' else '_prefill ' in root['label']
        T = meta['target_T'] if arm == 'hyle' else meta['T']
        shape = (meta['role'], T, meta['draft_T'], meta['R']) if arm == 'hyle' else (role, T, is_prefill)
        shape_seen[shape] += 1
        inside = [x for x in gpu if a <= x['start'] and x['end'] <= b]
        crossing = [x for x in gpu if x['start'] < b and a < x['end'] and x not in inside]
        attributed.update(x['activity_index'] for x in inside)
        calls = [x for x in apis if x['globalTid'] == tid and a <= x['start'] and x['end'] <= b]
        corrs = {x['correlationId'] for x in calls}
        linked = [x for x in inside if x['correlationId'] in corrs]
        special = [x for x in calls if api_recording(x)]
        groups = defaultdict(list)
        for x in inside:
            if x['kind'] == 'kernel' and x.get('graphId'):
                groups[x['correlationId']].append(x)
        launches = []
        for cid, kernels in sorted(groups.items(), key=lambda kv: min(x['start'] for x in kv[1])):
            graph_calls = [x for x in calls if x['correlationId'] == cid and 'GraphLaunch' in x['api']]
            complete_signature = [(x['name'], x['gridX'], x['gridY'], x['gridZ'], x['blockX'], x['blockY'], x['blockZ']) for x in kernels]
            signature_hash = hashlib.sha256(json.dumps(complete_signature).encode()).hexdigest()
            signatures.setdefault(signature_hash, dict(kernel_count=len(kernels), sequence=complete_signature))
            has_gdn = any('gated_delta' in x['name'].lower() for x in kernels)
            has_conv = any('ssm_conv' in x['name'].lower() for x in kernels)
            has_attention = any('flashinfer' in x['name'].lower() for x in kernels)
            activities = [x for x in inside if x['correlationId'] == cid]
            launches.append(dict(correlationId=cid, source_role='unknown', kernel_count=len(kernels),
                signature=signature_hash, runtime_graph_launches=len(graph_calls), start_ns=min(x['start'] for x in kernels),
                end_ns=max(x['end'] for x in kernels), kernel_union_ns=event_union(kernels),
                correlated_all_activity_union_ns=event_union(activities), has_GDN=has_gdn, has_conv=has_conv,
                has_FlashInfer=has_attention, graphIds=sorted({x['graphId'] for x in kernels})))
        if arm == 'peer':
            for launch in launches:
                launch['source_role'] = role + '_captured_subset'
        elif not is_prefill and meta['role'] in (3, 4) and len(launches) == 2:
            front, body = launches
            # Actual-source proof: classic full draft head precedes target token
            # construction; all18 GDN/conv layers belong only to target. This is
            # a subset label, not an invented separate CPU call or eager partition.
            if all(x['runtime_graph_launches'] == 1 for x in launches) and front['end_ns'] <= body['start_ns'] and not front['has_GDN'] and front['has_FlashInfer'] and body['has_GDN'] and body['has_conv']:
                front['source_role'] = 'draft_captured_subset'
                body['source_role'] = 'target_captured_subset'
        phases = []
        if arm == 'hyle':
            phases = [phase_metrics(x, gpu, apis) for x in closed if x['label'].startswith('hyle/') and not x['label'].startswith('hyle/episode') and x['uint64Value'] == root['uint64Value']]
        else:
            phases = [phase_metrics(x, gpu, apis) for x in closed if x['label'] in ('peer/llama_decode', 'peer/synchronize') and x['uint64Value'] == root['uint64Value']]
            phases += [phase_metrics(x, gpu, apis) for x in closed if x['label'].startswith('peer/prepare_') and x['uint64Value'] == root['uint64Value']]
        krows = [x for x in inside if x['kind'] == 'kernel']
        gu = event_union(inside + crossing, (a, b))
        cls = 'record' if any('BeginCapture' in x['api'] for x in special) else 'instantiate_or_update_without_begin' if special else 'no_record'
        rec = dict(label=root['label'], meta=meta, source_role=role, prefill=is_prefill, first_logical_shape=shape_seen[shape] == 1,
            start_ns=a, end_ns=b, globalTid=tid, endGlobalTid=root['endGlobalTid'], wall_ns=b - a,
            gpu_overlap_union_ns=gu, gpu_contained_union_ns=event_union(inside), wall_without_observed_gpu_ns=b - a - gu,
            kernel_count=len(krows), kernel_union_ns=event_union(krows), all_activity_count=len(inside),
            boundary_crossing_activity_indices=[x['activity_index'] for x in crossing],
            api_union_ns=event_union(calls), api_count=len(calls), runtime_correlated_activity_count=len(linked),
            graph_launch_api_count=sum('GraphLaunch' in x['api'] for x in calls),
            uncorrelated_activity_count=len(inside) - len(linked), classification=cls,
            recording_api_counts=dict(Counter(x['api'] for x in special)), recording_api_union_ns=event_union(special),
            recording_apis=special,
            phases=phases, captured_launches=launches,
            kernel_categories={cat: dict(count=len(ys), union_ns=event_union(ys)) for cat in sorted({category(x['name']) for x in krows}) for ys in [[x for x in krows if category(x['name']) == cat]]})
        if arm == 'hyle':
            ledger = native_report['sessions'][0]['ledger']
            rec['same_run_ledger'] = ledger[meta['seq'] - 1]
        rows.append(rec)
    outside = [x for x in gpu if x['activity_index'] not in attributed]
    intervals = [(x['start'], x['end']) for x in roots]
    outside_intervals = subtract([(x['start'], x['end']) for x in gpu], intervals)
    all_api = {name: dict(calls=len(xs), union_ns=event_union(xs)) for name in sorted({x['api'] for x in apis}) for xs in [[x for x in apis if x['api'] == name]]}
    stats_by = {}
    for prefill in (True, False):
        for cls in ('all', 'record', 'instantiate_or_update_without_begin', 'no_record'):
            for role in (('combined_K1',) if arm == 'hyle' else ('target', 'draft')):
                selected = [x for x in rows if x['prefill'] == prefill and x['source_role'] == role and (cls == 'all' or x['classification'] == cls)]
                if not selected:
                    continue
                key = ('prefill' if prefill else 'decode') + '/' + role + '/' + cls
                stats_by[key] = {field: stats(x[field] for x in selected) for field in ('wall_ns', 'gpu_overlap_union_ns', 'wall_without_observed_gpu_ns', 'recording_api_union_ns')}
                stats_by[key]['sequences'] = [x['meta']['seq'] for x in selected]
                labels = sorted({p['label'] for x in selected for p in x['phases']})
                stats_by[key]['phases_inclusive_do_not_add'] = {label: {field: stats(p[field] for x in selected for p in x['phases'] if p['label'] == label) for field in ('wall_ns', 'gpu_overlap_union_ns', 'wall_without_observed_gpu_ns')} for label in labels}
    kernel_ranking = []
    for name in sorted({x['name'] for x in gpu if x['kind'] == 'kernel'}):
        selected = [x for x in gpu if x['kind'] == 'kernel' and x['name'] == name and any(not r['prefill'] and r['start_ns'] <= x['start'] and x['end'] <= r['end_ns'] for r in rows)]
        kernel_ranking.append(dict(name=name, category=category(name), count=len(selected), union_ns=event_union(selected)))
    kernel_ranking.sort(key=lambda x: x['union_ns'], reverse=True)
    role_subsets = {}
    for role in ('target', 'draft'):
        if arm == 'hyle':
            selected = [(p, r) for r in rows if not r['prefill'] and r['classification'] == 'no_record' and r['graph_launch_api_count'] for p in r['captured_launches'] if p['source_role'] == role + '_captured_subset']
            role_subsets[role] = dict(scope='Only uniquely source/correlation-supported captured subset; eager/input/output/copy outside it not assigned.',
                count=len(selected), actual_T_counts=dict(Counter(str(r['meta']['target_T'] if role == 'target' else r['meta']['draft_T']) for p, r in selected)),
                all_T_gpu_union=stats(p['correlated_all_activity_union_ns'] for p, r in selected),
                T2_gpu_union=stats(p['correlated_all_activity_union_ns'] for p, r in selected if (r['meta']['target_T'] if role == 'target' else r['meta']['draft_T']) == 2),
                late_T2_gpu_union=stats(p['correlated_all_activity_union_ns'] for p, r in selected if r['meta']['context'] >= 384 and (r['meta']['target_T'] if role == 'target' else r['meta']['draft_T']) == 2))
        else:
            selected = [r for r in rows if not r['prefill'] and r['classification'] == 'no_record' and r['graph_launch_api_count'] and r['source_role'] == role]
            role_subsets[role] = dict(scope='Whole NVTX decode+synchronize GPU containment, including any traced input/native copies. sampled/hidden/trim after return excluded.',
                count=len(selected), actual_T_counts=dict(Counter(str(r['meta']['T']) for r in selected)),
                all_T_gpu_union=stats(r['gpu_overlap_union_ns'] for r in selected),
                T2_gpu_union=stats(r['gpu_overlap_union_ns'] for r in selected if r['meta']['T'] == 2),
                late_T2_gpu_union=stats(r['gpu_overlap_union_ns'] for r in selected if r['meta']['context'] >= 384 and r['meta']['T'] == 2))
    summary = dict(arm=arm, quality=m.read(F / 'quality.json'), database=m.pin(F / 'trace.sqlite'),
        process=m.read(F / 'process.json'), logical_calls=len(rows), statistics=stats_by,
        source_supported_steady_role_subsets=role_subsets,
        first_calls=[x for x in rows if x['first_logical_shape']],
        recording_calls=[x for x in rows if x['classification'] != 'no_record'],
        graph_launch_subset_roles=dict(Counter(p['source_role'] for x in rows for p in x['captured_launches'])),
        no_record_decode_launchless_sequences=[r['meta']['seq'] for r in rows if not r['prefill'] and r['classification'] == 'no_record' and not r['graph_launch_api_count']],
        process_gpu_union_ns=event_union(gpu), gpu_overlap_all_root_union_ns=event_union(gpu) - measure(outside_intervals),
        gpu_outside_root_union_ns=measure(outside_intervals), outside_root_activity_count=len(outside),
        outside_root_interval_bounds_ns=outside_intervals, outside_root_kinds=dict(Counter(x['kind'] for x in outside)),
        all_process_apis=all_api, decode_kernel_ranking=kernel_ranking, diagnostics=diagnostics,
        driver_table_present='CUPTI_ACTIVITY_KIND_DRIVER' in tables,
        globalPid=next(iter(gpu_pids)), source_report_work={k: native_report[k] for k in ('mtp', 'turn_count', 'generated_tokens', 'generated_decode_tokens', 'prefill_target_rows', 'actual_target_rows', 'actual_draft_rows', 'committed_target_rows') if k in native_report},
        report_fields_scope='Full non-time equality already gated separately; this work subset is navigation only.')
    m.save(W / arm / 'episode-rows.json', rows)
    m.save(W / arm / 'kernel-signatures.json', signatures)
    m.save(W / arm / 'gpu-outside-roots.json', outside)
    m.save(W / arm / 'analysis.json', summary)
    return summary

if __name__ == '__main__':
    result = {arm: analyze(arm) for arm in ('hyle', 'peer')}
    m.save(W / 'analysis-summary.json', dict(status='OFFLINE_SAME_PAIR_ANALYSIS', analyzer=m.pin(Path(__file__)), SQL=SQL,
        arms={arm: {k: v for k, v in a.items() if k not in ('all_process_apis', 'first_calls', 'recording_calls', 'decode_kernel_ranking', 'diagnostics', 'outside_root_interval_bounds_ns')} for arm, a in result.items()},
        limits=['NVTX/API/phase parents are inclusive and must not be added. GPU union is intervals of kernels/copies/memsets, never kernel count or summed overlapped time.',
                'wall minus observed GPU is not pure CPU, recoverable overhead, utilization, or unprofiled TPS. node-level CUDA Graph tracing can perturb both GPU and host.',
                'Hyle combined K1 CPU episode differs from each peer native decode+synchronize. Peer sampled/hidden/trim gaps and Hyle post-endpoint IO remain explicit outside roots.',
                'Hyle source/correlation supported target/draft captured subsets are not complete per-role work; target contains18 GDN+conv layers, causal preceding FlashInfer draft subset. No old738/37 count used.',
                'No cross-engine episode seq join; natural accepted work and BF16 versus F32 intermediate mathematics differ. No old trace clock subtraction.',
                'Driver/CUPTI diagnostics and all unassigned GPU activities retained. Missing driver correlation is unknown, not zero.']))
    for arm, a in result.items():
        print(arm, 'calls', a['logical_calls'], 'work', a['source_report_work'], 'roles', a['source_supported_steady_role_subsets'])
        print('decode', {k: {f: v for f, v in x.items() if f in ('wall_ns', 'gpu_overlap_union_ns', 'wall_without_observed_gpu_ns')} for k, x in a['statistics'].items() if k.startswith('decode/')})
