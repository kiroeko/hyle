"""Source/command preparation only. Never builds or launches an inference process."""
from pathlib import Path
import difflib
import hashlib
import json
import subprocess
import sys

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = W.parents[1]
OLD = R / '.scratch/mtp-logical-call-trace-20261025'
H = R / '.scratch/inference-sampling-three-arm-20261026/batch'
P = R / '.scratch/qwen-mtp-final-window-20261024'
WINDOW = R / '.scratch/inference-current-closure-20261026/full-window/two-turn-timing'
NSYS = Path('C:/Program Files/NVIDIA Corporation/Nsight Systems 2026.1.3/target-windows-x64/nsys.exe')

def read(p):
    return json.loads(Path(p).read_bytes())

def pin(p):
    p = Path(p).resolve()
    blob = p.read_bytes()
    return dict(path=str(p), bytes=len(blob), sha256=hashlib.sha256(blob).hexdigest())

def save(p, value):
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_bytes((json.dumps(value, indent=2) + '\n').encode())

def replace(text, old, new):
    assert text.count(old) == 1, (old, text.count(old))
    return text.replace(old, new)

def write_source(arm, relative, before, after):
    newline = '\r\n' if b'\r\n' in before else '\n'
    source = W / arm / 'source' / relative
    source.parent.mkdir(parents=True, exist_ok=True)
    source.write_bytes(after.replace('\n', newline).encode())
    original = W / arm / 'before' / relative
    original.parent.mkdir(parents=True, exist_ok=True)
    original.write_bytes(before)
    patch = ''.join(difflib.unified_diff(before.decode().splitlines(True), source.read_bytes().decode().splitlines(True),
                  fromfile='a/' + relative, tofile='b/' + relative))
    (W / arm / 'source.patch').write_bytes(patch.encode())
    return dict(path=relative, before=pin(original), after=pin(source), patch=pin(W / arm / 'source.patch'))

def prepare():
    if (W / 'plan.json').exists():
        raise FileExistsError('Frozen plan already exists; no implicit regeneration')
    hready = read(H / 'ready.json')
    pready = read(R / '.scratch/mtp-performance-convergence-20261025/baseline/peer-ready.json')
    assert pin(hready['image']['path']) == hready['image']
    assert hready['image']['sha256'] == '41ce916d82910a47ff01a4fa80b286d1886b52b0afc0c6e2e2ad13a0d6c8065d'
    assert pin(pready['image']['path']) == pready['image']
    assert pready['image']['sha256'] == '433e7051f4c36d0d9b2297dc378631546b7e3c44630cda0653cba2d1ec6bbe8e'
    main = H / 'source/engine/models/qwen35/main.cc'
    assert pin(main)['sha256'] == 'dfaa530b2148a31d3834f0b62c4f123d5fc6983be9f37652395269db2b69dfc6'
    assert pin(R / 'engine/models/qwen35/main.cc')['sha256'] == pin(main)['sha256']
    # Retain the successful old NVTX primitive; only add normal scope lifetime.
    helper = (OLD / 'logical_trace.h').read_text()
    helper = helper.rsplit('\n}', 1)[0] + '''
struct RunScope final {
 RunScope() noexcept { initialize(); }
 ~RunScope() { episode.finish(); dump(); }
};
}
'''
    (W / 'logical_trace.h').write_bytes(helper.encode())
    before = main.read_bytes()
    s = before.decode().replace('\r\n', '\n')
    s = replace(s, '#include <algorithm>', '#include "logical_trace.h"\n#include <algorithm>')
    s = replace(s, 'int qwen35::run(int argc, char **argv) {',
                'int qwen35::run(int argc, char **argv) {\n  [[maybe_unused]] logical_trace::RunScope trace_process;')
    s = replace(s, '    const auto step_start = Clock::now();', '''    const auto &trace_head = *requests.front().session->head;
    logical_trace::hyle_begin(static_cast<unsigned>(role), tokens,
        has_mtp(role) ? (is_mtp_prefill(role) ? tokens + draft_lag(role) : draft_lag(role) + 1) : 0,
        requests.size(), trace_head.length, trace_head.draft ? trace_head.draft->frontier : 0,
        trace_head.draft ? trace_head.draft->lag : 0);
    logical_trace::Range trace_prepare("hyle/prepare", logical_trace::sequence);
    const auto step_start = Clock::now();''')
    s = replace(s, '      check(run.prepare_replay(queues, {.mode = phase.replay_modes[slot], .host_wait = g::HostWaitPolicy::kAllow}));', '''      {
        logical_trace::Range trace_replay("hyle/prepare_replay", logical_trace::sequence);
        check(run.prepare_replay(queues, {.mode = phase.replay_modes[slot], .host_wait = g::HostWaitPolicy::kAllow}));
      }''')
    s = replace(s, '  void submit_evaluations() {', '''  void submit_evaluations() {
    logical_trace::Range trace_submit("hyle/submit", logical_trace::sequence);''')
    s = replace(s, '    const auto step_start = step.step_start, start = step.start;', '''    logical_trace::Range trace_finish("hyle/wait_publish", logical_trace::sequence);
    logical_trace::Range trace_postwait;
    const auto step_start = step.step_start, start = step.start;''')
    s = replace(s, '      check(step.completion.wait()); step.completion = {};', '''      {
        logical_trace::Range trace_wait("hyle/completion_wait", logical_trace::sequence);
        check(step.completion.wait()); step.completion = {};
      }
      trace_postwait.start("hyle/postwait_publish", logical_trace::sequence);''')
    s = replace(s, '    const auto finished = Clock::now();', '''    const auto finished = Clock::now();
    trace_postwait.finish(); trace_finish.finish(); logical_trace::episode.finish();''')
    files = [write_source('hyle', 'engine/models/qwen35/main.cc', before, s)]
    # Only these three deleted historical schedule headers need local recovery.
    identity = read(P / 'compile1/peer/identity.json')
    support = []
    for name in ('mtp_schedule.h', 'session_schedule.h', 'schedule.h'):
        expected = next(x for x in identity['dependencies'] if Path(x['path']).name == name)
        src = OLD / 'source' / name
        assert pin(src)['sha256'] == expected['sha256']
        dst = W / 'peer/source' / name
        dst.parent.mkdir(parents=True, exist_ok=True)
        dst.write_bytes(src.read_bytes())
        support.append(dict(original=expected, frozen=pin(dst)))
    peer = Path(pready['source']['path'])
    before = peer.read_bytes()
    s = before.decode().replace('\r\n', '\n')
    s = replace(s, '#include "../../../tools/qwen35_text/mtp_schedule.h"', '#include "mtp_schedule.h"\n#include "logical_trace.h"')
    s = replace(s, 'Json decode(llama_context * context, Batch & batch) {', '''Json decode(llama_context * context, Batch & batch, const char *role, std::size_t target_context, std::size_t draft_frontier, std::size_t turn) {
    const auto trace_sequence = ++logical_trace::sequence;
    char trace_text[256]{};
    std::snprintf(trace_text, sizeof(trace_text), "peer/%s seq=%llu T=%d context=%zu frontier=%zu turn=%zu", role, trace_sequence, batch.value.n_tokens, target_context, draft_frontier, turn);
    logical_trace::Range trace_call(trace_text, trace_sequence);
    logical_trace::Range trace_submit("peer/llama_decode", trace_sequence);''')
    s = replace(s, '    require(code == 0, "original llama_decode failed");', '''    trace_submit.finish();
    require(code == 0, "original llama_decode failed");
    logical_trace::Range trace_wait("peer/synchronize", trace_sequence);''')
    s = replace(s, '    llama_synchronize(context); const auto retired = Clock::now();', '''    llama_synchronize(context); const auto retired = Clock::now();
    trace_wait.finish(); trace_call.finish();''')
    replacements = [
        ('target_batch.fill(input_ids, length, nullptr, false, true);', 'target_prefill', 'target_batch.fill(input_ids, length, nullptr, false, true);'),
        ('draft_batch->fill(draft_input, frontier, &shifted, false, false);', 'draft_prefill', 'draft_batch->fill(draft_input, frontier, &shifted, false, false);'),
        ('draft_batch->fill(draft_ids, frontier, &draft_hidden, false, !single);', 'draft_decode', 'draft_batch->fill(draft_ids, frontier, &draft_hidden, false, !single);'),
        ('target_batch.fill(verify, length, nullptr, true, false);', 'target_decode', 'target_batch.fill(verify, length, nullptr, true, false);')]
    for old, role, original in replacements:
        s = replace(s, old, '{ logical_trace::Range trace_prepare("peer/prepare_' + role + '", logical_trace::sequence + 1); ' + original + ' }')
    for old, new in [
        ('decode(target.get(), target_batch);', 'decode(target.get(), target_batch, "target_prefill", length, frontier, turn_index + 1);'),
        ('decode(draft.get(), *draft_batch);', 'decode(draft.get(), *draft_batch, "draft_prefill", length, frontier, turn_index + 1);')]:
        # Each expression has prefill and decode uses: replace the exact enclosing statement.
        prefix = 'auto turn_target_prefill = ' if 'target.get' in old else 'turn_draft_prefill = '
        s = replace(s, prefix + old, prefix + new)
    s = replace(s, 'dft = decode(draft.get(), *draft_batch);', 'dft = decode(draft.get(), *draft_batch, "draft_decode", length, frontier, turn_index + 1);')
    s = replace(s, 'auto tgt = decode(target.get(), target_batch);', 'auto tgt = decode(target.get(), target_batch, "target_decode", length, frontier, turn_index + 1);')
    s = replace(s, 'int main(int argc, char ** argv) {', 'int main(int argc, char ** argv) {\n    [[maybe_unused]] logical_trace::RunScope trace_process;')
    files.append(write_source('peer', 'peer_multiturn.cc', before, s))
    save(W / 'source-pins.json', dict(files=files, helper=pin(W / 'logical_trace.h'), peer_support=support,
          original_helper=pin(OLD / 'logical_trace.h'), product_changes=0, new_TUs=2))
    # All original dependency contents must remain frozen; recover only original schedule headers.
    dep_maps = {}
    for arm, items in [('hyle', read(H / 'compile/actual-dependencies.json')), ('peer', identity['dependencies'])]:
        mapped = []
        for item in items:
            original = Path(item['path'])
            if arm == 'hyle' and original.is_relative_to(H / 'source'):
                actual = R / original.relative_to(H / 'source')
            elif arm == 'peer' and original.name in ('mtp_schedule.h', 'session_schedule.h', 'schedule.h'):
                actual = W / 'peer/source' / original.name
            else:
                actual = original
            assert pin(actual)['sha256'] == item['sha256'], str(actual)
            mapped.append(dict(original=item, compile_input=pin(actual)))
        dep_maps[arm] = mapped
    save(W / 'baseline-dependencies.json', dep_maps)
    save(W / 'baseline-link-inputs.json', dict(hyle=read(H / 'link-inputs.json'),
                                             peer=read(P / 'peer-link1/link-plan.json')['inputs']))
    for arm in ('hyle', 'peer'):
        F = W / arm
        compile_recipe = H / 'compile/command.json' if arm == 'hyle' else P / 'compile1/peer/identity.json'
        link_recipe = H / 'link/process/command.json' if arm == 'hyle' else P / 'peer-link1/link-plan.json'
        old = read(compile_recipe)['command']
        old_source = main if arm == 'hyle' else peer
        old_obj = hready['app']['path'] if arm == 'hyle' else identity['object']['path']
        source = F / 'source' / ('engine/models/qwen35/main.cc' if arm == 'hyle' else 'peer_multiturn.cc')
        flags = []
        skip = False
        for a in old[1:]:
            if skip:
                skip = False
                continue
            if a == '/sourceDependencies':
                skip = True
                continue
            if a.lower().startswith(('/fo', '/fd')) or a.lower() == str(old_source).lower():
                continue
            if arm == 'hyle' and a.lower().startswith('/i') and str(H / 'source').lower() in a.lower():
                continue
            flags.append(a)
        compile_cmd = [old[0], '/I' + str(W), '/external:IC:\\Program Files\\NVIDIA GPU Computing Toolkit\\CUDA\\v13.3\\include',
                       *flags, str(source), '/sourceDependencies', str(F / 'compile/dependencies.json'),
                       '/Fo' + str(F / 'compile/unit.obj'), '/Fd' + str(F / 'compile/unit.pdb')]
        original_link = read(link_recipe)['command']
        assert sum(a.lower() == str(old_obj).lower() for a in original_link) == 1
        link_cmd = [str(F / 'compile/unit.obj') if a.lower() == str(old_obj).lower() else a for a in original_link
                    if not a.lower().startswith(('/out:', '/pdb:', '/map:', '/implib:'))]
        link_cmd += ['/OUT:' + str(F / 'link/consumer.exe'), '/PDB:' + str(F / 'link/consumer.pdb'),
                     '/IMPLIB:' + str(F / 'link/consumer.lib')]
        save(F / 'build-plan.json', dict(status='NOT_EXECUTED', compile=compile_cmd, link=link_cmd,
             original_compile=pin(compile_recipe), original_link=pin(link_recipe), replacement_only=old_obj,
             source=pin(source), cwd=str(R), timeout_seconds=120, new_host_TUs=1, SDK_builds=0))
    cap = W / 'capability'
    cap.mkdir(exist_ok=False)
    for label, cmd in [('version', [str(NSYS), '--version']), ('profile-help', [str(NSYS), 'profile', '--help'])]:
        p = subprocess.run(cmd, capture_output=True, timeout=30)
        (cap / (label + '.stdout.log')).write_bytes(p.stdout)
        (cap / (label + '.stderr.log')).write_bytes(p.stderr)
        save(cap / (label + '.json'), dict(command=cmd, exit=p.returncode, model_started=False))
        assert p.returncode == 0
    commands = []
    for arm, ref in [('hyle', '02-hyle_mtp'), ('peer', '04-peer_mtp')]:
        native = read(WINDOW / ref / 'command.json')['command'][:]
        native[0] = str(W / arm / 'link/consumer.exe')
        out = W / arm / 'trace1'
        if '--output' in native:
            native[native.index('--output') + 1] = str(out / 'consumer-result.json')
        cmd = [str(NSYS), 'profile', '--trace=cuda,cublas,nvtx', '--cuda-graph-trace=node',
               '--sample=none', '--cpuctxsw=none', '--discard-environment=true',
               '--nvtx-domain-include=HyleLogicalCalls', '--duration=60', '--kill=true', '--wait=all',
               '--stats=false', '--export=sqlite', '--output=' + str(out / 'trace'), *native]
        runtime = H / 'runtime.json' if arm == 'hyle' else Path(pready['runtime_environment']['path'])
        reference = WINDOW / ref / ('stdout.log' if arm == 'hyle' else 'consumer-result.json')
        commands.append(dict(arm=arm, command=cmd, run_dir=str(out), runtime=pin(runtime),
                             original_command=pin(WINDOW / ref / 'command.json'), reference=pin(reference)))
    old_sizes = {arm: {name: (OLD / arm / 'trace1' / name).stat().st_size for name in ('trace.nsys-rep', 'trace.sqlite')}
                 for arm in ('hyle', 'peer')}
    save(W / 'plan.json', dict(status='SOURCE_AND_COMMANDS_PREPARED_NOT_BUILT_NOT_PROFILED', new_host_TUs=2,
        builds_started=0, model_processes_started=0, tool=pin(NSYS), tool_version=(cap / 'version.stdout.log').read_text().strip(),
        baseline_hyle_ready=pin(H / 'ready.json'), baseline_peer_ready=pin(R / '.scratch/mtp-performance-convergence-20261025/baseline/peer-ready.json'),
        source_pins=pin(W / 'source-pins.json'), baseline_dependencies=pin(W / 'baseline-dependencies.json'),
        baseline_link_inputs=pin(W / 'baseline-link-inputs.json'),
        commands=commands, watchdog_seconds=120, trace_seconds=60, automatic_retry=False,
        expected_size=dict(previous_same_tool_bytes=old_sizes, previous_pair_total_bytes=sum(sum(x.values()) for x in old_sizes.values()),
                           estimate='Historical files total about25.1 MB; new node activities/driver warnings may differ. Reserve at least256 MiB plus transient Nsight TEMP space; no size or completeness guarantee.'),
        endpoint=dict(hyle='68 combined episode ranges: original step_start to original finished before observer/report; prepare, replay, submit, actual completion.wait, postwait publication. prepare starts after validation/exact-shape admission as in old trace.',
                      peer='134 native calls expected from reference: role/T/context/frontier/turn; cold Batch.fill prepare, llama_decode return, actual synchronize. CPU sampled/hidden/trim gaps remain outside native call.',
                      target_draft='Peer role is direct. Hyle K1 has one Invocation combining draft+target; new same-trace CUDA GraphLaunch correlation+complete mathematical kernel signatures/causal order must uniquely establish any GPU role. Never hardcode old738/37 counts, never invent separate Hyle CPU submit/wait roles. Ambiguous/eager activity remains unknown.'),
        quality=dict(report='Complete recursive non-time report equality to each reference; only original *_seconds, *tokens_per_second and unix clock fields excluded. Preserve metadata, IDs, ledger, pending, RNG, accept/work counts.',
                     trace='Normal model exit, complete report, LOGICAL_NVTX end marker/no overlaps, all68 Hyle/134 peer logical roots and original wait children, nonempty CUDA kernel/runtime tables. Missing data stops; no reprofile.',
                     association='Same process/globalTid interval plus correlationId; actual GPU interval union, never sum nested APIs/kernel durations as busy or subtract old/new clocks.'),
        differences_from_old=dict(hyle='Old instrumented95a69 Model+oldGraph closure replaced by41/dfaa Model+2a94 refreshed inherited CUDA closure. Current own Model actualdeps match canonical at preparation; CPU/team/View newer objects are not claimed.',
                                  peer='Same433 consumer/core reused with NVTX-only consumer delta. Old logicalreadyfbb is instrumented and must not be substituted for433.',
                                  no_old_seq_join=True, no_TPS=True),
        before_run=['Root serial GPU/CPU window; inspect known inference/benchmark process argv and nvidia-smi compute processes, WDDM desktop N/A is not inference.',
                    'Verify ready/image/runtime/link inputs and source/deps pins after build. Preserve original runtime PATH/native DLL and offline flags.',
                    'Ensure output directories absent, disk/TEMP free space and Nsight driver/CUPTI diagnostics retained. Driver lineage warnings may make some associations unknown.'],
        commands_for_root=['python ' + str(W / 'build.py') + ' hyle', 'python ' + str(W / 'build.py') + ' peer',
                           'python ' + str(W / 'run.py') + ' pair']))
    print('PREPARED_ONLY', pin(W / 'plan.json'))

if __name__ == '__main__':
    prepare()
