"""Root-controlled serial pair. No retry and no unprofiled inference launch."""
from pathlib import Path
import importlib.util
import json
import os
import re
import shutil
import sqlite3
import subprocess
import sys
import time

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = W.parents[1]
spec = importlib.util.spec_from_file_location('attribution_plan', W / 'prepare.py')
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)

def exact(row):
    assert m.pin(row['path']) == row, 'Input changed: ' + row['path']

def norm(v):
    if isinstance(v, list):
        return [norm(x) for x in v]
    if isinstance(v, dict):
        return {k: norm(x) for k, x in v.items() if k not in ('seconds', 'unix_ms', 'unix_ns', 'clock_unix')
                and not k.endswith('_seconds') and not k.endswith('tokens_per_second')}
    return v

def diff(a, b, path=''):
    if type(a) != type(b):
        return [dict(path=path, expected=a, actual=b)]
    if isinstance(a, dict):
        return [dict(path=path + '/' + k, expected=a.get(k), actual=b.get(k)) for k in a.keys() ^ b.keys()] + [d for k in a.keys() & b.keys() for d in diff(a[k], b[k], path + '/' + k)]
    if isinstance(a, list):
        return [dict(path=path, expected_length=len(a), actual_length=len(b))] if len(a) != len(b) else [d for i, (x, y) in enumerate(zip(a, b)) for d in diff(x, y, path + '/' + str(i))]
    return [] if a == b else [dict(path=path, expected=a, actual=b)]

def report(text):
    for needle in ('{"source_id"', '{\n  "scope"'):
        pos = text.find(needle)
        if pos >= 0:
            return json.JSONDecoder().raw_decode(text[pos:])[0]
    raise ValueError('No complete original report JSON')

def preflight():
    F = W / 'preflight'
    F.mkdir(exist_ok=False)
    commands = [
        ('gpu', ['nvidia-smi', '--query-gpu=name,driver_version,memory.total,memory.used,pstate', '--format=csv,noheader']),
        ('gpu-processes', ['nvidia-smi', '--query-compute-apps=pid,process_name,used_memory', '--format=csv,noheader']),
        ('inference-processes', ['C:/Windows/System32/WindowsPowerShell/v1.0/powershell.exe', '-NoProfile', '-Command',
          'Get-CimInstance Win32_Process | Where-Object { $_.Name -match "hyle|peer|consumer|llama|benchmark|python" } | Select-Object ProcessId,Name,ExecutablePath,CommandLine | ConvertTo-Json -Depth 3'])]
    for name, cmd in commands:
        p = subprocess.run(cmd, capture_output=True, timeout=30, creationflags=subprocess.CREATE_NO_WINDOW)
        (F / (name + '.stdout.log')).write_bytes(p.stdout)
        (F / (name + '.stderr.log')).write_bytes(p.stderr)
        m.save(F / (name + '.json'), dict(command=cmd, exit=p.returncode))
        assert p.returncode == 0
    m.save(F / 'resources.json', dict(disk_free_bytes=shutil.disk_usage(W).free,
        temp=os.environ.get('TEMP'), note='Inventory for Root-assigned exclusive window. WDDM desktop N/A and ordinary Python tooling are not inferred model activity. No automatic kill or hardware policy.'))

def run(arm):
    plan = m.read(W / 'plan.json')
    exact(plan['tool']); exact(plan['source_pins'])
    record = next(x for x in plan['commands'] if x['arm'] == arm)
    ready = m.read(W / arm / 'ready.json')
    for field in ('image', 'app', 'source', 'source_pins', 'runtime', 'actual_dependencies', 'link_inputs'):
        exact(ready[field])
    for row in m.read(ready['link_inputs']['path']):
        exact(row)
    exact(record['reference'])
    F = Path(record['run_dir'])
    F.mkdir(exist_ok=False)
    runtime = m.read(ready['runtime']['path'])
    env = os.environ.copy()
    env['PATH'] = str(Path(ready['image']['path']).parent) + ';' + runtime['PATH']
    env['HF_HUB_OFFLINE'] = '1'; env['TRANSFORMERS_OFFLINE'] = '1'
    if runtime.get('configured_flags'):
        env.update(runtime['configured_flags'])
    cmd = record['command']
    assert cmd[cmd.index('--schedule') + 1] == str(m.P / 'natural-inputs/performance64.txt')
    assert cmd.count(ready['image']['path']) == 1
    m.save(F / 'command.json', dict(command=cmd, cwd=str(R), timeout_seconds=120,
        image=ready['image'], runtime=ready['runtime'], profile_only=True, no_TPS=True))
    started = time.perf_counter()
    with (F / 'stdout.log').open('wb') as out, (F / 'stderr.log').open('wb') as err:
        p = subprocess.Popen(cmd, cwd=R, env=env, stdout=out, stderr=err, creationflags=subprocess.CREATE_NO_WINDOW)
        m.save(F / 'live.json', dict(nsys_pid=p.pid, started_unix_ns=time.time_ns()))
        print('PROFILE_STARTED', arm, p.pid, flush=True)
        timeout = False
        try:
            code = p.wait(timeout=120)
        except subprocess.TimeoutExpired:
            timeout = True
            killed = subprocess.run(['C:/Windows/System32/taskkill.exe', '/PID', str(p.pid), '/T', '/F'], capture_output=True)
            (F / 'timeout-taskkill.stdout.log').write_bytes(killed.stdout)
            (F / 'timeout-taskkill.stderr.log').write_bytes(killed.stderr)
            p.wait(timeout=20)
            code = p.returncode
    m.save(F / 'process.json', dict(exit=code, nsys_pid=p.pid, seconds=time.perf_counter() - started, timeout=timeout))
    print('PROFILE_ENDED', arm, code, 'timeout', timeout, flush=True)
    assert code == 0 and not timeout, 'Original failed capture retained; no retry'
    db = F / 'trace.sqlite'
    c = sqlite3.connect('file:' + db.as_posix() + '?mode=ro', uri=True)
    tables = {x[0] for x in c.execute("SELECT name FROM sqlite_master WHERE type='table'")}
    assert {'NVTX_EVENTS', 'CUPTI_ACTIVITY_KIND_KERNEL', 'CUPTI_ACTIVITY_KIND_RUNTIME', 'ProcessStreams'} <= tables
    for name, text in c.execute('SELECT f.value,c.value FROM ProcessStreams p JOIN StringIds f ON f.id=p.filenameId JOIN StringIds c ON c.id=p.contentId'):
        if 'stdout_' in name or 'stderr_' in name:
            (F / ('native-stdout.log' if 'stdout_' in name else 'native-stderr.log')).write_bytes(text.encode())
    raw = report((F / 'native-stdout.log').read_text(encoding='utf8')) if arm == 'hyle' else m.read(F / 'consumer-result.json')
    prior = report(Path(record['reference']['path']).read_text(encoding='utf8')) if arm == 'hyle' else m.read(record['reference']['path'])
    differences = diff(norm(prior), norm(raw))
    m.save(F / 'non-time-comparison.json', dict(differences=differences, reference=record['reference'],
           exact_exclusions=['seconds', '*_seconds', '*tokens_per_second', 'unix_ms', 'unix_ns', 'clock_unix']))
    labels = [x[0] for x in c.execute('SELECT COALESCE(n.text,s.value) FROM NVTX_EVENTS n LEFT JOIN StringIds s ON s.id=n.textId WHERE n.end IS NOT NULL') if x[0]]
    roots = [x for x in labels if x.startswith('hyle/episode' if arm == 'hyle' else ('peer/target_', 'peer/draft_'))]
    expected = 68 if arm == 'hyle' else 134
    native_err = (F / 'native-stderr.log').read_text(encoding='utf8')
    markers = re.findall(r'LOGICAL_NVTX sequence=(\d+) completed_ranges=(\d+) overlapping_episodes=(\d+)', native_err)
    counts = {t: c.execute('SELECT COUNT(*) FROM ' + t).fetchone()[0] for t in ('CUPTI_ACTIVITY_KIND_KERNEL', 'CUPTI_ACTIVITY_KIND_RUNTIME')}
    missing = [x[0] for x in c.execute('SELECT COALESCE(n.text,s.value) FROM NVTX_EVENTS n LEFT JOIN StringIds s ON s.id=n.textId WHERE n.end IS NULL') if x[0] and x[0].startswith(('hyle/', 'peer/'))]
    phase_names = ('hyle/prepare', 'hyle/prepare_replay', 'hyle/submit', 'hyle/wait_publish',
                   'hyle/completion_wait', 'hyle/postwait_publish') if arm == 'hyle' else ('peer/llama_decode', 'peer/synchronize')
    phase_counts = {name: labels.count(name) for name in phase_names}
    prepare_count = sum(x.startswith('peer/prepare_') for x in labels) if arm == 'peer' else phase_counts['hyle/prepare']
    phase_complete = all(x == expected for x in phase_counts.values()) and prepare_count == expected
    c.close()
    m.save(F / 'quality.json', dict(status='PASS' if not differences and len(roots) == expected and markers and int(markers[-1][0]) == expected and int(markers[-1][2]) == 0 and not missing and all(counts.values()) and phase_complete else 'FAIL',
        full_non_time_equal=not differences, logical_roots=len(roots), expected_roots=expected, end_markers=markers,
        phase_counts=phase_counts, prepare_count=prepare_count, missing_nvtx_ends=missing, activity_rows=counts, role_assignment='Pending offline same-trace correlation/signature verification; no old-count attribution',
        artifacts=[m.pin(F / x) for x in ('trace.sqlite', 'trace.nsys-rep', 'native-stdout.log', 'native-stderr.log')]))
    assert m.read(F / 'quality.json')['status'] == 'PASS', 'Incomplete/changed data retained; do not start another arm'

if __name__ == '__main__':
    action = sys.argv[1]
    assert action in ('preflight', 'hyle', 'peer', 'pair')
    if action in ('preflight', 'pair'):
        preflight()
    if action == 'pair':
        run('hyle'); run('peer')
    elif action != 'preflight':
        run(action)
