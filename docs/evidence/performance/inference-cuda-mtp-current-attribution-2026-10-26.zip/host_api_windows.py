"""Offline inclusive ranges; runtime/driver/library intervals are unioned once."""
from pathlib import Path
import importlib.util
import sqlite3
from collections import Counter

W = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('pair_unions', W / 'analyze.py')
a = importlib.util.module_from_spec(spec)
spec.loader.exec_module(a)
out = {}
for arm in ('hyle', 'peer'):
    c = sqlite3.connect('file:' + (W / arm / 'trace1/trace.sqlite').as_posix() + '?mode=ro', uri=True)
    c.row_factory = sqlite3.Row
    tables = {x[0] for x in c.execute("SELECT name FROM sqlite_master WHERE type='table'")}
    nvtx = [dict(x) for x in c.execute(a.SQL['nvtx']) if x['end'] is not None and x['label']]
    library = [x for x in nvtx if x['label'].startswith('cublas')]
    api = [dict(x) for x in c.execute(a.SQL['runtime'])]
    if 'CUPTI_ACTIVITY_KIND_DRIVER' in tables:
        api += [dict(x) for x in c.execute(a.SQL['driver'])]
    rows = a.m.read(W / arm / 'episode-rows.json')
    windows = []
    for row in rows:
        if row['prefill']:
            continue
        phase = next((p for p in row['phases'] if p['label'] == 'hyle/prepare_replay'), None) if arm == 'hyle' else None
        lo, hi = (phase['start_ns'], phase['end_ns']) if phase else (row['start_ns'], row['end_ns'])
        tid = row['globalTid']
        apis = [x for x in api if x['globalTid'] == tid and x['start'] < hi and lo < x['end']]
        libs = [x for x in library if x['globalTid'] == tid and x['start'] < hi and lo < x['end']]
        union = a.event_union(apis + libs, (lo, hi))
        windows.append(dict(seq=row['meta']['seq'], label=row['label'], classification=row['classification'],
            scope='prepare_replay' if arm == 'hyle' else 'native_decode_and_sync', start_ns=lo, end_ns=hi,
            wall_ns=hi - lo, visible_runtime_driver_library_union_ns=union,
            uncovered_by_visible_host_calls_ns=hi - lo - union,
            library_counts=dict(Counter(x['label'] for x in libs)),
            library_union_ns=a.event_union(libs, (lo, hi)),
            APIs={name: dict(count=len(xs), union_ns=a.event_union(xs, (lo, hi))) for name in sorted({x['api'] for x in apis}) for xs in [[x for x in apis if x['api'] == name]]}))
    c.close()
    out[arm] = dict(windows=windows,
        by_class={key: {field: a.stats(x[field] for x in xs) for field in ('wall_ns', 'visible_runtime_driver_library_union_ns', 'uncovered_by_visible_host_calls_ns', 'library_union_ns')}
                  for key in ('record', 'no_record') for xs in [[x for x in windows if x['classification'] == key]]},
        library_all_process={name: dict(count=len(xs), union_ns=a.event_union(xs)) for name in sorted({x['label'] for x in library}) for xs in [[x for x in library if x['label'] == name]]},
        library_in_record_windows=dict(Counter({name: sum(x['library_counts'].get(name, 0) for x in windows if x['classification'] == 'record') for name in {k for x in windows for k in x['library_counts']}})))
a.m.save(W / 'host-api-windows.json', dict(arms=out,
    limits=['Hyle windows are prepare_replay; peer windows are whole native decode+synchronize, not directly subtractable.',
            'Library NVTX contains runtime/driver APIs; visible union is merged once. Individual API totals overlap and cannot be added.',
            'Uncovered means not covered by recorded runtime/driver/library calls. It includes graph traversal, provider work, OS/scheduler and profiler bookkeeping; it is not a proved pure Graph CPU or recoverable bucket.',
            'Both traces report unsupported driver13.4/software tracing and original-graph lineage errors. Driver table missing, so native calls may be unobserved.']))
for arm, x in out.items():
    print(arm, x['by_class'], 'record libraries', x['library_in_record_windows'])
