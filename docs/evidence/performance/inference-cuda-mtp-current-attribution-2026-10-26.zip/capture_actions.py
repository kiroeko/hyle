"""Only analyze the already-recorded pair; no native API is called."""
from pathlib import Path
import importlib.util
import json
from collections import Counter

W = Path(__file__).resolve().parent
R = W.parents[1]
spec = importlib.util.spec_from_file_location('pair_interval_analysis', W / 'analyze.py')
a = importlib.util.module_from_spec(spec)
spec.loader.exec_module(a)

def actions(arm):
    rows = a.m.read(W / arm / 'episode-rows.json')
    seen_ids = set()
    known_signatures = set()
    last_by_shape = {}
    last_by_id = {}
    result = []
    for row in rows:
        launches = row['captured_launches']
        new = [x for x in launches if not set(x['graphIds']) <= seen_ids]
        changed = [x for x in launches if any(gid in last_by_id and last_by_id[gid] != x['signature'] for gid in x['graphIds'])]
        specs = row['recording_apis']
        captures = []
        for index, api in enumerate(specs):
            if 'BeginCapture' not in api['api']:
                continue
            next_begin = next((i for i in range(index + 1, len(specs)) if 'BeginCapture' in specs[i]['api']), len(specs))
            current = specs[index:next_begin]
            ended = [x for x in current if 'EndCapture' in x['api']]
            post = [x for x in current if 'GraphInstantiate' in x['api'] or 'GraphExecUpdate' in x['api']]
            assert len(ended) == 1 and post
            captures.append(dict(seq=row['meta']['seq'], meta=row['meta'], logical_label=row['label'],
                ordinal_in_episode=len(captures), start_ns=api['start'], end_capture_ns=ended[0]['end'],
                final_api_end_ns=post[-1]['end'], capture_to_final_api_ns=post[-1]['end'] - api['start'],
                begin_to_end_capture_ns=ended[0]['end'] - api['start'],
                APIs=current, instantiate_count=sum('GraphInstantiate' in x['api'] for x in post),
                update_count=sum('GraphExecUpdate' in x['api'] for x in post),
                source_range_role='unknown', role_mapping_basis='No native artifact handle/argument table in this API export.'))
        inst = [x for x in captures if x['instantiate_count']]
        if arm == 'hyle' and len(new) == len(inst):
            # Actual fresh graphId in the subsequent launch, one per native
            # instantiation, ordered by the original plan's range traversal.
            for cap, launch in zip(inst, new):
                cap['matched_launch'] = launch
                cap['source_range_role'] = launch['source_role']
                cap['role_mapping_basis'] = 'Unique new actual launch graphId(s), equal Instantiate count and original ordered range traversal; originalGraph/originalNode lineage is unused.'
        if arm == 'hyle' and len(captures) == len(launches) == 2:
            for cap, launch in zip(captures, launches):
                cap.setdefault('matched_launch', launch)
                cap['source_range_role'] = launch['source_role']
                cap['role_mapping_basis'] = 'Both actual ranges recorded, original ordered range traversal, unique causal draft/target GPU signatures; not kernel-count inference.'
        elif arm == 'hyle' and len(captures) == 1 and captures[0]['update_count'] and len(changed) == 1:
            cap = captures[0]; launch = changed[0]
            cap['matched_launch'] = launch
            cap['source_range_role'] = launch['source_role']
            cap['role_mapping_basis'] = 'Single Update and unique changed observed kernel/launch signature on a previously observed graphId. CUDA graph edges/parameter bytes are unavailable.'
        if arm == 'peer':
            for cap in captures:
                cap['source_range_role'] = row['source_role']
                cap['role_mapping_basis'] = 'Direct role-qualified native decode NVTX parent.'
                if len(launches) == 1:
                    cap['matched_launch'] = launches[0]
        for cap in captures:
            launch = cap.get('matched_launch')
            if launch:
                shape = (row['meta'].get('role', row['source_role']), row['meta'].get('target_T', row['meta'].get('T')),
                         row['meta'].get('draft_T'), launch['source_role'])
                cap['first_observed_family_range'] = shape not in last_by_shape
                cap['signature_seen_before_for_family_range'] = (shape, launch['signature']) in known_signatures
                cap['same_signature_as_previous_for_family_range'] = last_by_shape.get(shape) == launch['signature']
            else:
                cap['first_observed_family_range'] = None
                cap['signature_seen_before_for_family_range'] = None
            result.append(cap)
        for launch in launches:
            shape = (row['meta'].get('role', row['source_role']), row['meta'].get('target_T', row['meta'].get('T')),
                     row['meta'].get('draft_T'), launch['source_role'])
            seen_ids.update(launch['graphIds'])
            known_signatures.add((shape, launch['signature']))
            last_by_shape[shape] = launch['signature']
            for gid in launch['graphIds']:
                last_by_id[gid] = launch['signature']
    api_names = sorted({x['api'] for row in rows for x in row['recording_apis']})
    summary = dict(captures=len(result), unique_instantiate_sequences=sorted({x['seq'] for x in result if x['instantiate_count']}),
        instantiate_captures=[x for x in result if x['instantiate_count']],
        updates_with_nonzero_return=[x for x in result for v in x['APIs'] if 'GraphExecUpdate' in v['api'] and v['returnValue'] != 0],
        per_API={name: dict(count=len(xs), return_values=dict(Counter(str(x['returnValue']) for x in xs)), union_ns=a.event_union(xs)) for name in api_names for xs in [[x for row in rows for x in row['recording_apis'] if x['api'] == name]]},
        all_capture_envelope=a.stats(x['capture_to_final_api_ns'] for x in result),
        native_handle_limitation='API export has no function argument/native exec handle or UpdateResultInfo detail. All observed Update runtime return values are checked, but no unseen reason/refcount/seed branch is invented.',
        graph_signature_limitation='Ordered demangled kernel names+grid/block tuples are observed. Equality is not CUDA graph edge/parameter/address equality; originalGraph/originalNode lineage warnings retained.')
    a.m.save(W / arm / 'capture-actions.json', dict(summary=summary, rows=result))
    return summary

if __name__ == '__main__':
    summaries = {arm: actions(arm) for arm in ('hyle', 'peer')}
    pins = []
    for src, identity in [
        ('src/graph/executable.cc', '.scratch/inference-current-closure-20261026/drift8/graph--executable_cc/identity-current.json'),
        ('src/compute_backend_cuda/cuda_backend.cc', '.scratch/inference-current-closure-20261026/headers79/compute_backend_cuda--cuda_backend_cc/identity-current.json')]:
        old = a.m.read(R / identity)
        assert a.m.pin(R / src) == old['source']
        pins.append(dict(source=old['source'], actual_build_identity=a.m.pin(R / identity)))
    a.m.save(W / 'capture-action-summary.json', dict(arms=summaries, source_pins=pins,
        source_anchors=[
            dict(path='src/graph/executable.cc', line=8113, fact='Native argument invalidation clears all launch authority/keys, retains at most ONE backend-authorized nonlaunchable seed before discarding variants.'),
            dict(path='src/graph/executable.cc', line=9779, fact='Private two-variant key matching; an empty alternate slot has no retired native executable to update. Only evicting a valid variant may recycle it.'),
            dict(path='src/compute_backend_cuda/cuda_backend.cc', line=1312, fact='Update requires same context, rebuild_only, unique, not status_busy and existing executable. Only structural Update failure permits instantiate fallback.'),
            dict(path='src/compute_backend_cuda/cuda_backend.cc', line=1399, fact='Retirement recycle rejects live/shared/busy/already-rebuild artifacts and permanently revokes launch authority.')],
        conclusion='13Hyle Instantiate calls are not failed-Update fallback:14 observed Update calls all return0;13 new graphIds match13 Instantiate events. First range fill and second variant/refill are distinct. Runtime trace does not expose seed admission or exact invalidation reason; source-consistent refill inference must remain labelled. No removable17ms claim.'))
    print(json.dumps({arm: dict(captures=x['captures'], sequences=x['unique_instantiate_sequences'], per_API=x['per_API']) for arm, x in summaries.items()}, indent=2))
