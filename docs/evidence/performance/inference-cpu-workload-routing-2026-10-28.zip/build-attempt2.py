"""Narrow recipe/header amendment; original failed CXX/freeze remain intact."""
from pathlib import Path
import importlib.util
import sys

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
A = W / 'attempt2'
spec = importlib.util.spec_from_file_location('cpu_leaf_first_attempt', W / 'build.py')
b = importlib.util.module_from_spec(spec); spec.loader.exec_module(b)
t = b.t
R = b.R


def prepare():
    p, _ = b.plan(); old = t.read(W / 'source-freeze.json')
    before = A / 'source-before/bench/common/perf_process.h'
    original = next(row for row in t.read(old['includes']['path']) if t.key(row['path']) == t.key(R / 'bench/common/perf_process.h'))
    assert t.pin(before)['sha256'] == original['sha256']
    after = R / 'bench/common/perf_process.h'
    assert after.read_bytes() == before.read_bytes().replace(b'#define NOMINMAX\n', b'#ifndef NOMINMAX\n#define NOMINMAX\n#endif\n', 1)
    target = A / 'source-after/bench/common/perf_process.h'; target.parent.mkdir(parents=True, exist_ok=True)
    with target.open('xb') as out: out.write(after.read_bytes())
    args = []
    for i, arg in enumerate(t.command(p['compile_recipe']['path'])):
        if i and t.command(p['compile_recipe']['path'])[i-1].lower() == '/sourcedependencies': arg = str(W / 'compile/bench-attempt2/dependencies.json')
        elif arg.lower().startswith('/fo'): arg = '/Fo' + str(W / 'compile/bench-attempt2/unit.obj')
        elif arg.lower().startswith('/fd'): arg = '/Fd' + str(W / 'compile/bench-attempt2/unit.pdb')
        args.append(arg)
    assert '/WX' in args and not any('CRT_SECURE_NO_WARNINGS' in arg for arg in args)
    args.append('/D_CRT_SECURE_NO_WARNINGS=1')
    t.save(A / 'recipe-compile.json', dict(command=args, cwd=str(R), timeout_seconds=300))
    args = [str(W / 'compile/bench-attempt2/unit.obj') if t.key(arg) == t.key(W / 'compile/bench/unit.obj') else arg
            for arg in t.command(p['link_recipe']['path'])]
    t.save(A / 'recipe-link.json', dict(command=args, cwd=str(R), timeout_seconds=240))
    includes = [t.pin(after) if row == original else row for row in t.read(old['includes']['path'])]
    t.save(A / 'frozen-includes.json', includes)
    t.save(A / 'amendment.json', dict(original_freeze=t.pin(W / 'source-freeze.json'),
        original_compile_recipe=p['compile_recipe'], original_failure=t.pin(W / 'logs/bench/process.json'),
        failure='CXX11216 exit2: /WX caught NOMINMAX C4005 and getenv C4996. No link or native run.',
        header_before=t.pin(before), header_after=t.pin(target), canonical_after=t.pin(after),
        header_change='Only conditional NOMINMAX definition, identical Windows macro value.',
        recipe_change='Add /D_CRT_SECURE_NO_WARNINGS=1, as central hyle_register_bench MSVC policy; retain /WX and all original warning flags.',
        policy_source=t.pin(R / 'cmake/HyleModule.cmake'),
        standalone_cmake=t.pin(R / 'bench/compute_provider_native/cpu_best_of_p1/CMakeLists.txt')))
    t.save(A / 'source-freeze.json', dict(helper=t.pin(__file__), original_helper=old['helper'],
        original_freeze=t.pin(W / 'source-freeze.json'), includes=t.pin(A / 'frozen-includes.json'),
        amendment=t.pin(A / 'amendment.json'), compile_recipe=t.pin(A / 'recipe-compile.json'),
        link_recipe=t.pin(A / 'recipe-link.json')))
    print('ATTEMPT2 PREPARED/FROZEN; metadata only')


def validate():
    p, rows = b.plan(); f = t.read(A / 'source-freeze.json')
    for row in f.values(): t.exact(row)
    for row in t.read(f['includes']['path']): t.exact(row)
    old = t.read(f['original_freeze']['path'])
    for field in ('plan','workloads','source','includes','retained_stats','environment','runtime'): t.exact(old[field])
    p['compile_recipe'] = f['compile_recipe']; p['link_recipe'] = f['link_recipe']
    return p, rows, old


def parse_compile():
    p, _, _ = validate(); out = W / 'compile/bench-attempt2'
    process = t.read(W / 'logs/bench-attempt2/process.json')
    assert process['exit'] == 0 and not process['timed_out'], process
    allowed = {t.key(row['path']):row for row in t.read(A / 'frozen-includes.json')}; actual = []
    for path in dict.fromkeys(t.dep_paths(out / 'dependencies.json')):
        path = path.resolve()
        if b.local_header(path) or path == Path(p['source']['path']).resolve():
            assert t.key(path) in allowed, ('Successful CXX metadata issue; parse only, never recompile', str(path))
            t.exact(allowed[t.key(path)])
        actual.append(t.pin(path))
    t.save(out / 'actual-dependencies.json', actual)
    t.save(out / 'compiled.json', dict(source=p['source'], object=t.pin(out / 'unit.obj'), process=process,
        command=t.pin(W / 'logs/bench-attempt2/command.json'), dependencies=t.pin(out / 'dependencies.json'),
        actual_dependencies=t.pin(out / 'actual-dependencies.json')))
    print('ATTEMPT2 CXX metadata PASS')


def compile_unit():
    p, _, _ = validate(); (W / 'compile/bench-attempt2').mkdir(parents=True, exist_ok=False)
    t.execute(t.command(p['compile_recipe']['path']), W / 'logs/bench-attempt2', 300)
    parse_compile()


def link():
    p, rows, old = validate(); compiled = t.read(W / 'compile/bench-attempt2/compiled.json'); t.exact(compiled['object'])
    for row in t.read(old['retained_stats']['path']):
        st = Path(row['path']).stat(); assert (st.st_size,st.st_mtime_ns) == (row['bytes'],row['mtime_ns']), row['path']
    new = [compiled['object'] if row == p['original_consumer'] else row for row in rows]
    assert len(new) == 228 and sum(a != c for a,c in zip(rows,new)) == 1
    (W / 'bin').mkdir(exist_ok=True); native = p['native_cpu_plugin']; t.exact(native)
    alias = W / 'bin' / Path(native['path']).name
    if not alias.exists(): alias.hardlink_to(native['path'])
    assert alias.samefile(native['path'])
    args = t.command(p['link_recipe']['path'])
    assert sum(t.key(arg) == t.key(compiled['object']['path']) for arg in args) == 1
    assert not any(t.key(arg) in (t.key(p['original_consumer']['path']),t.key(W/'compile/bench/unit.obj')) for arg in args)
    t.save(W / 'inputs-bench.json', new)
    process = t.execute(args, W / 'link', 240)
    t.save(W / 'ready.json', dict(status='LINKED_NOT_RUN', image=t.pin(W / 'bin/bench.exe'),
        inputs=t.pin(W / 'inputs-bench.json'), compiled=compiled, process=process,
        recipe=t.pin(W / 'link/command.json'), runtime=old['runtime'], source_freeze=t.pin(A / 'source-freeze.json')))
    print('LINK PASS; retained227+attempt2 bench1')


if __name__ == '__main__':
    action = sys.argv[1]
    if action == 'prepare': prepare()
    elif action == 'preflight': validate(); print('ATTEMPT2 PREFLIGHT PASS')
    elif action == 'compile-attempt2': compile_unit()
    elif action == 'parse-compile': parse_compile()
    elif action == 'link': link()
    else: raise ValueError(action)
