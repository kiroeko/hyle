"""Root invokes after actual validation. Pure offline packaging; no native work."""
from pathlib import Path
import argparse
import hashlib
import json
import re
import subprocess
import zipfile

R=Path('C:/public/project-hyle/hyle')
W=Path(__file__).resolve().parent
V=W/'validation'
DEST=R/'docs/evidence/performance/inference-cpu-workload-routing-2026-10-28'


def read(path):return json.loads(Path(path).read_text(encoding='utf-8-sig'))
def data(value):return (json.dumps(value,ensure_ascii=False,indent=2)+'\n').encode('utf-8')
def sha(raw):return hashlib.sha256(raw).hexdigest()
def pin(path):
    p=Path(path);raw=p.read_bytes();return dict(path=str(p.resolve()),bytes=len(raw),sha256=sha(raw))
def exact(row):
    now=pin(row['path']);assert(now['bytes'],now['sha256'])==(row['bytes'],row['sha256']),row['path']
def successful(path):
    p=read(path);assert p['state']=='TERMINAL' and p['exit']==0 and not p['timed_out'],(str(path),p)
    return p


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--patch',type=Path)
    args=parser.parse_args()
    owned=read(W/'owned-paths.json');assert isinstance(owned,list) and len(owned)==19 and len(set(owned))==19
    assert all(not Path(s).is_absolute() and '..' not in Path(s).parts for s in owned)
    product=read(W/'product-source-freeze.json')
    for row in product['sources']:exact(row)
    assert all(not(R/s).exists() for s in product['deleted_by_root'])
    measurement=read(W/'measurement-summary.json');assert measurement['status']=='COMPLETE19_SINGLE_STRATUM'
    assert(measurement['processes'],measurement['AB'],measurement['AA'])==(19,15,4)
    probe=read(W/'runs/probe/summary.json');successful(W/'runs/probe/process.json')
    assert(probe['case_count'],probe['admission_records'],probe['numeric_pairs'])==(15,60,15)
    first=read(W/'logs/bench/process.json');assert first['pid']==11216 and first['exit']==2 and not first['timed_out']
    leaf_compile=successful(W/'logs/bench-attempt2/process.json');leaf_link=successful(W/'link/process.json')
    plan=read(V/'plan-adjacent.json');assert plan['counts']['CXX']==10 and plan['counts']['links']==3
    cxx={name:successful(V/f'logs/{name}/process.json') for name in plan['units']}
    links={name:successful(V/f'links/{name}/process.json') for name in ('direct','graph','runtime')}
    ready={name:read(V/f'ready-{name}.json') for name in links}
    for name,count in (('direct',230),('graph',230),('runtime',227)):
        exact(ready[name]['inputs']);assert len(read(ready[name]['inputs']['path']))==count
    tests={name:read(V/f'runs/{name}/summary.json') for name in ('direct','graph')}
    for name,row in tests.items():
        assert row['status'] in ('PASS','PASS_WITH_SKIPS') and row['tests']>0 and row['failures']==0
        assert row['passed']+row['skipped']==row['tests']
        successful(V/f'runs/{name}/process.json')
    runtime=[]
    for p in sorted((V/'runs').glob('runtime-*/process.json')):
        process=read(p);summary=read(p.with_name('summary.json'))
        assert summary['status'] in ('PASS','NOT_APPLICABLE'),summary
        assert not process['timed_out'] and process['state']=='TERMINAL'
        assert process['exit']==(77 if summary['status']=='NOT_APPLICABLE' else 0)
        runtime.append(summary)
    expected_runtime={'startup','query-first','late-native','late-aten','race-use','race-config','metadata-oom','foreign','runtime-drift'}
    assert {row['scenario'] for row in runtime}==expected_runtime,'Wait for the9 root-planned fresh runtime processes; no incomplete completion claim'
    source=(V/'source/tests/compute_route_cpu/thread_runtime_consumer.cc').read_text(encoding='utf-8')
    modes=list(dict.fromkeys(re.findall(r'mode\s*==\s*"--([a-z-]+)"',source)))
    measured=[];aa=[];geometry={row['id']:row for row in read(W/'workloads.json')};affinities={}
    for row in measurement['results']:
        ordinal=row['item']['ordinal'];process=successful(W/f'measurements/{ordinal:03d}/process.json')
        assert row['process']==process and row['paired_rounds']==16 and row['original_numerical_gate_passed']
        telemetry=row['telemetry'];affinities[tuple(telemetry[k] for k in ('affinity_topology','caller_cpu','affinity_ok'))]={k:telemetry[k] for k in ('affinity_topology','caller_cpu','affinity_ok')}
        a,b=row['arms'];assert a['median_seconds']>0 and b['median_seconds']>0
        base=[row['item']['case'],a['median_seconds']*1e9,b['median_seconds']*1e9,
              b['median_seconds']/a['median_seconds'],a['mdape_percent'],b['mdape_percent'],b['paired_95CI_text']]
        if row['item']['kind']=='native-AA':aa.append(base)
        else:measured.append([row['item']['case'],geometry[row['item']['case']]['elements'],*base[1:]])
    assert len(measured)==15 and len(aa)==4
    archive={}
    def add(path,name=None):
        path=Path(path);assert path.is_file(),str(path)
        label=name or path.relative_to(W).as_posix();raw=path.read_bytes()
        assert label not in archive or archive[label]==raw,label
        archive[label]=raw
    def tree(directory):
        # Only these local record subtrees; binary/SDK/model payloads excluded.
        allowed={'.json','.log','.xml','.py','.cc','.h','.diff','.patch','.txt','.cmake'}
        for path in sorted(Path(directory).rglob('*')):
            if path.is_file() and path.suffix.lower() in allowed and '__pycache__' not in path.parts:add(path)
    for name in ('prepare.py','build.py','build-attempt2.py','run.py','measure.py','evidence.py',
                 'plan.json','build-plan.json','recipe-compile.json','recipe-link.json','retained-inputs.json',
                 'retained-stats.json','frozen-includes.json','source-freeze.json','runtime.json','ready.json','inputs-bench.json',
                 'workloads.json','measurement-plan.json','measurement-summary.json','product-source-freeze.json','owned-paths.json'):
        add(W/name)
    for directory in ('source','attempt2','logs','compile','link','runs','measurements'):tree(W/directory)
    for name in ('build.py','build-before-adjacent.py','run.py','plan.json','plan-adjacent.json','runtime.json',
                 'retained-stats.json','source-freeze.json','frozen-project-includes.json',
                 'run-before-fixture-skips.py','parser-fixture-skip-amendment.json'):
        add(V/name)
    for directory in ('source','recipes','link-recipes','compile','logs','links','runs'):tree(V/directory)
    for name in links:
        add(V/f'ready-{name}.json');add(V/f'inputs-{name}.json')
    # Exact original benchmark source, not the whole old SDK/source tree.
    original=read(W/'plan.json')['retained_consumer'];exact(original)
    add(original['path'],'original/cpu_best_of_bench.cc')
    snapshots=[]
    for relative in owned:
        path=R/relative
        if path.is_file():
            add(path,'product/'+relative);snapshots.append(pin(path))
    archive['owned-source-identities.json']=data(dict(present=snapshots,deleted=product['deleted_by_root']))
    patch=args.patch.read_bytes() if args.patch else subprocess.check_output(['git','diff','--',*owned],cwd=R)
    patch_paths=set(re.findall(r'^diff --git a/(\S+) b/\S+$',patch.decode('utf-8'),re.M))
    assert patch_paths and patch_paths<=set(owned),(patch_paths-set(owned))
    assert set(product['deleted_by_root'])<=patch_paths,'Product deletion proof missing from patch'
    archive['cpu-owned-only.diff']=patch
    # Reproduction records expose only the relevant build variables, no full
    # inherited environment or token/credential names/values.
    whitelist=('PATH','INCLUDE','LIB','LIBPATH','VCToolsInstallDir','WindowsSdkDir','WindowsSDKVersion')
    environments={}
    for directory in (W,V):
        path=directory/'environment.json';env=read(path)
        environments[directory.name]=dict(identity=pin(path),preserved={k:env[k] for k in whitelist if k in env})
    archive['build-environment-relevant.json']=data(environments)
    # Full member list excludes itself; its own digest is in external JSON.
    manifest=[dict(name=name,bytes=len(raw),sha256=sha(raw)) for name,raw in sorted(archive.items())]
    manifest_raw=data(dict(members=manifest,self_digest='External JSON archive.manifest_sha256'))
    archive['MANIFEST.json']=manifest_raw
    destzip=DEST.with_suffix('.zip');destjson=DEST.with_suffix('.json')
    assert not destzip.exists() and not destjson.exists(),'Do not overwrite an evidence generation'
    DEST.parent.mkdir(parents=True,exist_ok=True)
    with zipfile.ZipFile(destzip,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for name,raw in sorted(archive.items()):z.writestr(name,raw)
    with zipfile.ZipFile(destzip) as z:
        assert z.testzip() is None
        assert set(z.namelist())==set(archive)
        for name,raw in archive.items():assert sha(z.read(name))==sha(raw),name
    summary=dict(status='FINITE_LEAF_AND_ACTUAL_CPU_VALIDATION',
        images=dict(leaf=read(W/'ready.json')['image'],validation={n:row['image'] for n,row in ready.items()},
            distinction='Leaf uses original228 SDK math. New policy is checked by separate refreshed validation executables, not by a recompiled leaf or full inference image.'),
        leaf=dict(probe=dict(process=probe['process'],cases=15,admission_records=60,numeric_pairs=15,
            per_case=dict(accepted=['native','ggml'],declined=['onednn','aten'])),
            measurements=dict(processes=19,AB=15,AA=4,paired_rounds_per_process=16,
                columns=['id','elements','native_ns','ggml_ns','ggml_over_native','native_MdAPE_pct','ggml_MdAPE_pct','paired_95CI_relative_peer_text'],table=measured,
                AA_columns=['id','candidate_native_ns','peer_native_ns','peer_over_candidate','candidate_MdAPE_pct','peer_MdAPE_pct','paired_95CI_relative_peer_text'],AA_table=aa,
                AA_max_abs_median_ratio_deviation_pct=max(abs(1/v[3]-1)*100 for v in aa),
                sample_distribution=None,median_precision='Original rounded stdout ns/op converted to seconds in raw summaries.',
                affinity_observations=list(affinities.values()),
                affinity='Original child telemetry and observed process mask preserved. Helper chose no P-core; external placement or inherited CPU requests do not establish controlled topology/absence of migration.')),
        validation=dict(CXX_processes=cxx,links=links,input_counts=dict(direct=230,graph=230,runtime=227),
            original_inputs=228,retained_original=221,replaced_SDK_objects=5,removed_default_rules_object=1,
            gtests={n:dict(pid=v['process']['pid'],tests=v['tests'],passed=v['passed'],skipped=v['skipped'],
                status=v['status'],skip_details=[case for case in v['cases'] if case['status']=='SKIP']) for n,v in tests.items()},
            runtime=runtime,unrun_runtime_modes=[m for m in modes if m not in {v['scenario'] for v in runtime}],
            product_scope=product['scope'],public_ABI_changed=product['public_ABI_changed'],math_kernels_changed=product['math_kernels_changed']),
        build_counts=dict(leaf_CXX=dict(actual=2,success=1,failed=1),leaf_links=1,
            validation_CXX=dict(actual=len(cxx),success=len(cxx),failed=0),validation_links=len(links),
            full_third_party_SDK_rebuild=0,NVCC=0,downloads=0),
        retained_failure=dict(process=first,reason='Benchmark setup /WX: NOMINMAX redefinition and getenv C4996. Conditional macro guard plus original central benchmark CRT definition; no lowered warning level, math or budget change.',attempt2=leaf_compile,link=leaf_link),
        limits=['Leaf speed ratios compare two admitted CPU Exp programs only; no CPU inference overall2–4x or GPU performance claim.',
            'Single process per shape/control in one ordering stratum. Per-process paired CI is not a general shape/provider or cross-system winner proof.',
            'Raw per-epoch samples were not exported by the unchanged binary; null is intentional.',
            'Optional ATen/CUDA changes in the concurrent worktree are outside this patch, build and validation scope.',
            'Only listed actual GTests/runtime scenarios are validated; no full-model/quality or new-platform performance result.'],
        archive=dict(**pin(destzip),members=len(archive),manifest_sha256=sha(manifest_raw),CRC='PASS',all_member_SHA256='PASS'))
    with destjson.open('xb') as stream:stream.write(data(summary))
    with (W/'evidence-readback.json').open('xb') as stream:stream.write(data(dict(JSON=pin(destjson),ZIP=pin(destzip),members=len(archive),CRC='PASS',SHA256='PASS')))
    print(json.dumps(dict(JSON=pin(destjson),ZIP=pin(destzip),members=len(archive)),ensure_ascii=False))


if __name__=='__main__':main()
