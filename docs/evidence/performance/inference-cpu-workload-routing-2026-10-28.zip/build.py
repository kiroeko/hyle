"""One leaf TU/link. Root executes compile/link; freeze is metadata only."""
from pathlib import Path
import importlib.util
import re
import sys

sys.dont_write_bytecode = True
R = Path('C:/public/project-hyle/hyle')
W = Path(__file__).resolve().parent
BASE = R / '.scratch/inference-execution-preparation-20261028'
spec = importlib.util.spec_from_file_location('retained_leaf_driver', BASE / 'build.py')
prior = importlib.util.module_from_spec(spec); spec.loader.exec_module(prior)
t = prior.t; t.W = W


def plan():
    p = t.read(W / 'build-plan.json')
    for field in ('baseline', 'original_input_manifest', 'source', 'compile_recipe',
                  'link_recipe', 'environment', 'runtime'):
        t.exact(p[field])
    rows = t.read(p['original_input_manifest']['path'])
    assert len(rows) == 228 and rows.count(p['original_consumer']) == 1
    assert t.read(W / 'retained-inputs.json') == rows
    return p, rows


def local_header(path):
    p = Path(path).resolve()
    if not p.is_relative_to(R): return False
    return p.relative_to(R).parts[0] in ('include', 'src', 'engine', 'tests', 'bench', 'third_party')


def freeze():
    p, rows = plan()
    args = t.command(p['compile_recipe']['path'])
    roots = [Path(a[2:]) for a in args if a.lower().startswith('/i')]
    roots += [Path(a[len('/external:I'):]) for a in args if a.lower().startswith('/external:i')]
    pending = [Path(p['source']['path'])]; seen = {}
    while pending:
        path = pending.pop().resolve(); k = t.key(path)
        if k in seen: continue
        seen[k] = path
        text = path.read_text(encoding='utf-8-sig')
        for kind, name in re.findall(r'^\s*#\s*include\s*([<"])([^>"\r\n]+)[>"]', text, re.M):
            candidates = ([path.parent] if kind == '"' else []) + roots
            found = next((v.resolve() for root in candidates if (v := root / name).is_file()), None)
            if found is not None and local_header(found): pending.append(found)
    t.save(W / 'frozen-includes.json', [t.pin(path) for path in sorted(seen.values())])
    retained = []
    for row in rows:
        if row == p['original_consumer']: continue
        st = Path(row['path']).stat(); assert st.st_size == row['bytes'], row['path']
        retained.append(dict(path=row['path'], bytes=st.st_size, mtime_ns=st.st_mtime_ns,
                             retained_sha256=row['sha256']))
    assert len(retained) == 227
    t.save(W / 'retained-stats.json', retained)
    env = t.read(p['environment']['path']); env['PATH'] = str(W / 'bin') + ';' + env['PATH']
    t.save(W / 'environment.json', env)
    runtime = t.read(p['runtime']['path'])
    t.save(W / 'runtime.json', dict(PATH=str(W / 'bin') + ';' + runtime['PATH'], native=runtime['native']))
    t.save(W / 'source-freeze.json', dict(helper=t.pin(__file__), plan=t.pin(W / 'build-plan.json'),
        workloads=t.pin(W / 'workloads.json'), source=p['source'], includes=t.pin(W / 'frozen-includes.json'),
        retained_stats=t.pin(W / 'retained-stats.json'), environment=t.pin(W / 'environment.json'),
        runtime=t.pin(W / 'runtime.json'),
        scope='Literal reachable project/benchmark/nanobench includes; actual MSVC includes recorded after CXX. Retained227 use original hashes plus unchanged stat; no SDK rehash/copy/build.'))
    print('FROZEN metadata only:', len(seen), 'reachable files; retain227, one new TU/link')


def validate():
    p, rows = plan(); f = t.read(W / 'source-freeze.json')
    for field in ('helper', 'plan', 'workloads', 'source', 'includes', 'retained_stats', 'environment', 'runtime'):
        t.exact(f[field])
    for row in t.read(f['includes']['path']): t.exact(row)
    return p, rows, f


def parse_compile():
    p, _, f = validate(); out = W / 'compile/bench'
    process = t.read(W / 'logs/bench/process.json')
    assert process['exit'] == 0 and not process['timed_out'], process
    allowed = {t.key(row['path']): row for row in t.read(f['includes']['path'])}
    actual = []
    for path in dict.fromkeys(t.dep_paths(out / 'dependencies.json')):
        path = path.resolve()
        if local_header(path) or path == Path(p['source']['path']).resolve():
            assert t.key(path) in allowed, ('Successful CXX metadata issue; parse only, do not recompile', str(path))
            t.exact(allowed[t.key(path)])
        actual.append(t.pin(path))
    t.save(out / 'actual-dependencies.json', actual)
    t.save(out / 'compiled.json', dict(source=p['source'], object=t.pin(out / 'unit.obj'), process=process,
        command=t.pin(W / 'logs/bench/command.json'), dependencies=t.pin(out / 'dependencies.json'),
        actual_dependencies=t.pin(out / 'actual-dependencies.json')))
    print('CXX metadata PASS; actual dependencies', len(actual))


def compile_unit():
    p, _, _ = validate(); (W / 'compile/bench').mkdir(parents=True, exist_ok=False)
    t.execute(t.command(p['compile_recipe']['path']), W / 'logs/bench', 300)
    parse_compile()


def link():
    p, rows, f = validate(); compiled = t.read(W / 'compile/bench/compiled.json')
    t.exact(compiled['object'])
    for row in t.read(f['retained_stats']['path']):
        st = Path(row['path']).stat()
        assert (st.st_size, st.st_mtime_ns) == (row['bytes'], row['mtime_ns']), row['path']
    newrows = [compiled['object'] if row == p['original_consumer'] else row for row in rows]
    assert len(newrows) == 228 and sum(a != b for a, b in zip(rows, newrows)) == 1
    args = t.command(p['link_recipe']['path'])
    assert sum(t.key(a) == t.key(compiled['object']['path']) for a in args) == 1
    assert not any(t.key(a) == t.key(p['original_consumer']['path']) for a in args)
    (W / 'bin').mkdir(exist_ok=True)
    native = p['native_cpu_plugin']; t.exact(native); alias = W / 'bin' / Path(native['path']).name
    if not alias.exists(): alias.hardlink_to(native['path'])
    assert alias.samefile(native['path'])
    t.save(W / 'inputs-bench.json', newrows)
    process = t.execute(args, W / 'link', 240)
    t.save(W / 'ready.json', dict(status='LINKED_NOT_RUN', image=t.pin(W / 'bin/bench.exe'),
        inputs=t.pin(W / 'inputs-bench.json'), compiled=compiled, process=process,
        recipe=t.pin(W / 'link/command.json'), runtime=f['runtime'], source_freeze=t.pin(W / 'source-freeze.json')))
    print('LINK PASS; inputs228 = retained227 + bench1')


if __name__ == '__main__':
    action = sys.argv[1]
    if action == 'freeze': freeze()
    elif action == 'preflight': validate(); print('PREFLIGHT PASS')
    elif action == 'compile': compile_unit()
    elif action == 'parse-compile': parse_compile()
    elif action == 'link': link()
    else: raise ValueError(action)
