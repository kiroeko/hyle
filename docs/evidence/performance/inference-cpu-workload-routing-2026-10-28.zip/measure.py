"""Finite19-process leaf plan. Every run is explicit, single-use and fail-fast."""
from pathlib import Path
import ctypes
import importlib.util
import math
import os
import re
import subprocess
import sys
import time

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('cpu_route_leaf_runtime', W / 'run.py')
r = importlib.util.module_from_spec(spec); spec.loader.exec_module(r)
t = r.t


def prepare():
    r.b.validate(); ready = t.read(W / 'ready.json'); probe = t.read(W / 'runs/probe/summary.json')
    assert probe['status'] == 'PROBE_ADMISSIONS_AND_NUMERICS_CHECKED'
    assert probe['case_count'] == 15 and probe['admission_records'] == 60 and probe['numeric_pairs'] == 15
    for case in probe['cases']:
        assert [case['providers'][f]['result'] for f in ('native','onednn','ggml','aten')] == ['ACCEPTED','DECLINED','ACCEPTED','DECLINED']
    items = []
    for case in t.read(W / 'workloads.json'):
        items.append(dict(ordinal=len(items)+1, case=case['id'], kind='native-vs-ggml',
                          actual_providers=['native','ggml'], aa=None))
        if case['id'] in ('exp-f32-1x256','exp-f32-1x4097','exp-f32-1x65536','exp-f32-1x262144'):
            items.append(dict(ordinal=len(items)+1, case=case['id'], kind='native-AA',
                              actual_providers=['native','native'], aa='candidate'))
    assert len(items) == 19
    st = Path(ready['image']['path']).stat(); assert st.st_size == ready['image']['bytes']
    t.save(W / 'measurement-plan.json', dict(status='PREPARED_NOT_RUN', executor=t.pin(__file__),
        ready=t.pin(W / 'ready.json'), probe=t.pin(W / 'runs/probe/summary.json'),
        image=ready['image'], image_stat=dict(bytes=st.st_size,mtime_ns=st.st_mtime_ns), runtime=ready['runtime'],
        processes=19, AB=15, AA=4, items=items,
        original_budget=dict(epochs=16,min_epoch_time_seconds=.002,warmup_calls_per_arm=8),
        allocation_order='Candidate allocated first; original warmup alternates; compare internally interleaves paired rounds.',
        measurement_order='Original default Candidate baseline first; no reverse-order strata in this batch.',
        affinity='No core selected by helper. Inherit explicit HYLE_PERF_CALLER_CPU only; otherwise original external telemetry and possible thread migration. No precise winner claim from uncontrolled placement.',
        sample_distribution=None, sample_distribution_reason='Existing binary does not export individual epochs. Preserve original rounded medians, MdAPE and paired95%CI/raw stdout; no binary/graph/budget change.'))
    print('PREPARED19: 15 Native/ggml + 4 interspersed Native AA; no process started')


def plan():
    p = t.read(W / 'measurement-plan.json'); t.exact(p['ready']); t.exact(p['probe']); t.exact(p['runtime'])
    return p


def number(value):
    result = float(value.strip().replace(',','').removesuffix('%'))
    assert math.isfinite(result), value
    return result


def parse_one(ordinal):
    p = plan(); item = p['items'][ordinal-1]; assert item['ordinal'] == ordinal
    out = W / f'measurements/{ordinal:03d}'; process = t.read(out / 'process.json')
    assert process['exit'] == 0 and not process['timed_out'], process
    stdout = (out / 'stdout.log').read_text(encoding='utf-8',errors='replace')
    stderr = (out / 'stderr.log').read_text(encoding='utf-8',errors='replace')
    assert 'NUMERIC_DIFFERENCE' not in stderr and 'NUMERIC_MISMATCH' not in stderr
    admissions = re.findall(r'^# ADMISSION id=(\S+) provider=(\S+) .*?result=(\S+) .*$',stderr,re.M)
    assert admissions == [(item['case'],f,'ACCEPTED') for f in item['actual_providers']], admissions
    telemetry = re.findall(r'^# CPU_BEST_OF affinity_topology=(\S+) caller_cpu=(\S+) affinity_ok=(\S+) run_nonce=(\S+)$',stderr,re.M)
    assert len(telemetry) == 1
    headers, arms = None, []
    title = item['case'] + '-native-vs-ggml'
    for line in stdout.splitlines():
        if not line.startswith('|'): continue
        cells = [v.strip() for v in line.split('|')[1:]]
        if 'ns/op' in cells:
            assert headers is None and cells[-1] == title, line
            headers = cells; continue
        if cells[-1].strip('`') not in ('Candidate '+title,'Peer '+title): continue
        assert headers and len(cells) == len(headers), line
        row = dict(zip(headers,cells)); seconds = number(row['ns/op']) * 1e-9
        assert seconds > 0
        arms.append(dict(label=cells[-1].strip('`'), actual_provider=item['actual_providers'][len(arms)],
            median_seconds=seconds, median_source='Rounded ns/op printed by unchanged nanobench',
            mdape_percent=number(row['err%']), relative_percent=number(row['relative']),
            paired_95CI_text=row['95% CI'] or None, total_measurement_seconds=number(row['total']),
            sample_distribution=None, original_table=row))
    assert len(arms) == 2 and [a['label'] for a in arms] == ['Candidate '+title,'Peer '+title]
    rounds = re.findall(r'(\d+) paired rounds, interleaved',stdout)
    assert rounds == ['16'], rounds
    t.save(out / 'summary.json', dict(status='MEASURED_ORIGINAL_PAIR', item=item, process=process,
        arms=arms, candidate_median_over_peer=arms[0]['median_seconds']/arms[1]['median_seconds'],
        paired_rounds=16, original_numerical_gate_passed=True,
        telemetry=dict(zip(('affinity_topology','caller_cpu','affinity_ok','run_nonce'),telemetry[0])),
        sample_distribution=None, sample_distribution_reason=p['sample_distribution_reason'],
        summary_text=stdout[stdout.index('  Summary'):].strip(), automatic_winner_claim=False))
    print('PARSED',ordinal,item['kind'],item['case'],[a['median_seconds'] for a in arms])


def run_one(ordinal):
    p = plan(); t.exact(p['executor']); item = p['items'][ordinal-1]; assert item['ordinal'] == ordinal
    image = Path(p['image']['path']); st = image.stat()
    assert (st.st_size,st.st_mtime_ns) == (p['image_stat']['bytes'],p['image_stat']['mtime_ns'])
    runtime = t.read(p['runtime']['path']); native = runtime['native']
    assert (W / 'bin' / Path(native['path']).name).samefile(native['path'])
    env = os.environ.copy(); env.update(PATH=runtime['PATH'],OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',
        HF_HUB_OFFLINE='1',HF_DATASETS_OFFLINE='1',TRANSFORMERS_OFFLINE='1')
    for key in ('HYLE_BENCH_RIVAL_FIRST','HYLE_BENCH_PEER_ALLOCATION_FIRST','HYLE_CPU_BESTOF_AA'):
        env.pop(key,None)
    if item['aa']: env['HYLE_CPU_BESTOF_AA'] = item['aa']
    env['HYLE_PERF_RUN_NONCE'] = f'cpu-routing-measure-{ordinal:03d}'
    mask = None
    if os.name == 'nt':
        kernel = ctypes.WinDLL('kernel32',use_last_error=True)
        kernel.GetCurrentProcess.restype = ctypes.c_void_p
        kernel.GetProcessAffinityMask.argtypes = [ctypes.c_void_p,ctypes.POINTER(ctypes.c_size_t),ctypes.POINTER(ctypes.c_size_t)]
        current, system = ctypes.c_size_t(), ctypes.c_size_t()
        if kernel.GetProcessAffinityMask(kernel.GetCurrentProcess(),ctypes.byref(current),ctypes.byref(system)):
            mask = dict(process=hex(current.value),system=hex(system.value))
    out = W / f'measurements/{ordinal:03d}'; out.mkdir(parents=True,exist_ok=False)
    args = [str(image),'--pair',item['case'],'native','ggml']; timeout = 180
    whitelist = ('HYLE_PERF_CALLER_CPU','HYLE_PERF_SAMPLING_TOPOLOGY','HYLE_PERF_RUN_NONCE',
                 'OMP_NUM_THREADS','MKL_NUM_THREADS','HYLE_CPU_BESTOF_AA')
    t.save(out / 'command.json', dict(command=args,cwd=str(r.b.R),timeout_seconds=timeout,item=item,
        ready=p['ready'],executor=t.pin(__file__),image=p['image'],image_stat=p['image_stat'],
        environment_relevant={k:env[k] for k in whitelist if k in env},
        unset_environment=['HYLE_BENCH_RIVAL_FIRST','HYLE_BENCH_PEER_ALLOCATION_FIRST'] + ([] if item['aa'] else ['HYLE_CPU_BESTOF_AA']),
        inherited_process_affinity=mask,affinity_policy=p['affinity']))
    start = time.time(); timed_out = False
    with (out / 'stdout.log').open('xb') as stdout,(out / 'stderr.log').open('xb') as stderr:
        child = subprocess.Popen(args,cwd=r.b.R,env=env,stdout=stdout,stderr=stderr,creationflags=subprocess.CREATE_NO_WINDOW)
        t.save(out / 'running.json',dict(pid=child.pid,started=start))
        try: code = child.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            timed_out=True; child.terminate()
            try: code=child.wait(timeout=10)
            except subprocess.TimeoutExpired: child.kill();code=child.wait(timeout=10)
    process=dict(pid=child.pid,exit=code,started=start,seconds=time.time()-start,state='TERMINAL',timed_out=timed_out)
    t.save(out / 'process.json',process); assert code == 0 and not timed_out,process
    parse_one(ordinal)


def summarize():
    p = plan(); rows = [t.read(W / f"measurements/{v['ordinal']:03d}/summary.json") for v in p['items']]
    t.save(W / 'measurement-summary.json',dict(status='COMPLETE19_SINGLE_STRATUM',processes=19,AB=15,AA=4,
        plan=t.pin(W / 'measurement-plan.json'),results=rows,sample_distribution=None,
        limits=[p['affinity'],p['sample_distribution_reason'],'Single process per shape/control; no automatic global routing or winner conclusion.']))
    print('SUMMARY19 written; no automatic winner claim')


if __name__ == '__main__':
    action = sys.argv[1]
    if action == 'prepare': prepare()
    elif action == 'run-one': run_one(int(sys.argv[2]))
    elif action == 'run-all':
        for item in plan()['items']: run_one(item['ordinal'])
        summarize()
    elif action == 'parse-only': parse_one(int(sys.argv[2]))
    elif action == 'summary': summarize()
    else: raise ValueError(action)
