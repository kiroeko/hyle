"""Bounded CPU route refresh: prepare only until root authorizes final freeze."""
from pathlib import Path
import importlib.util
import re
import sys

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = Path('C:/public/project-hyle/hyle')
BASE = R / '.scratch/inference-store-cohort-20261028'
spec = importlib.util.spec_from_file_location('retained_cpu_sdk_driver', R / '.scratch/inference-indexed-store-20261028/build.py')
t = importlib.util.module_from_spec(spec); spec.loader.exec_module(t); t.W = W
H79 = R / '.scratch/inference-current-closure-20261026/headers79'
OLD = R / '.scratch/glm-quark-selected-20261024/Q30/graph-integration-preparation/host1'
SOURCES = {'native':'src/compute_provider_native/native_provider.cc',
    'aten':'src/compute_provider_native/aten_cpu_provider.cc',
    'compute-context':'src/compute_route_cpu/cpu_context.cc',
    'policy':'src/compute_route_cpu/default_policy.cc',
    'graph-context':'src/graph_route_cpu/cpu_context.cc',
    'direct':'tests/compute_route_cpu/current_rules_test.cc',
    'graph':'tests/compute_route_cpu/current_rules_test.cc',
    'runtime':'tests/compute_route_cpu/thread_runtime_consumer.cc'}
SDK = ('native','aten','compute-context','policy','graph-context')
CONSUMERS = ('direct','graph','runtime')


def prepare():
    ready = t.read(BASE/'ready-tiny.json'); t.exact(ready['inputs']); rows = t.read(ready['inputs']['path'])
    assert len(rows) == 228
    templates = {
      'native':(R/'.scratch/inference-packed-sequence-20261028/logs/native-provider/command.json',R/'.scratch/inference-packed-sequence-20261028/compile/native-provider/dependencies.json',R/'.scratch/inference-packed-sequence-20261028/compile/native-provider/unit.obj'),
      'aten':(H79/'compute_provider_native--aten_cpu_provider_cc/command.json',H79/'compute_provider_native--aten_cpu_provider_cc/dependencies.json',H79/'compute_provider_native--aten_cpu_provider_cc/unit.obj'),
      'graph-context':(H79/'graph_route_cpu--cpu_context_cc/command.json',H79/'graph_route_cpu--cpu_context_cc/dependencies.json',H79/'graph_route_cpu--cpu_context_cc/unit.obj')}
    for name,stem in (('compute-context','cpu_context'),('policy','default_policy')):
        templates[name]=(OLD/f'records/compute_route_cpu--{stem}/run/command.json',OLD/f'compute_route_cpu--{stem}-deps.json',OLD/f'compute_route_cpu--{stem}.obj')
    tiny = ready['compiled']['tiny']; oldobjects = {}; units = {}
    for name in SDK:
        command,deps,obj = templates[name]; matches=[row for row in rows if t.key(row['path']) == t.key(obj)]
        assert len(matches) == 1,(name,matches); oldobjects[name]=matches[0]
        assert t.key(t.canonical(t.read(deps)['Data']['Source'])) == t.key(R/SOURCES[name]),name
    oldobjects['consumer'] = tiny['object']; assert oldobjects['consumer'] in rows
    matches = [row for row in rows if 'inference-cpu-storage-gather-20261027' in row['path'] and 'default_rules' in row['path']]
    assert len(matches)==1; oldobjects['rules']=matches[0]
    host = t.read(R/'.scratch/inference-mtp-e4-20261028/validation/host-refinement/ready-host.json')
    # Two original GTest framework libraries, not the old product closure.
    gtest = [t.pin(Path(arg)) for arg in t.command(host['recipe']['path']) if Path(arg).name.lower() in ('gtest.lib','gtest_main.lib')]
    assert len(gtest)==2
    torch_includes = [arg for arg in t.command(templates['aten'][0]) if arg.lower().startswith('/external:i') and 'libtorch' in arg.lower()]
    assert len(torch_includes)==2
    for name,source in SOURCES.items():
        if name in SDK:
            command,deps,_=templates[name]
        elif name=='runtime': command,deps=templates['aten'][:2]
        else: command=Path(tiny['command']['path']);deps=Path(tiny['dependencies']['path'])
        before=t.command(command); oldsource=t.read(deps)['Data']['Source'];args=[]
        for i,arg in enumerate(before):
            if t.key(arg)==t.key(oldsource):arg=str(R/source)
            elif i and before[i-1].lower()=='/sourcedependencies':arg=str(W/f'compile/{name}/dependencies.json')
            elif arg.lower().startswith('/fo'):arg='/Fo'+str(W/f'compile/{name}/unit.obj')
            elif arg.lower().startswith('/fd'):arg='/Fd'+str(W/f'compile/{name}/unit.pdb')
            args.append(arg)
        if name in CONSUMERS:
            for arg in ('/DHYLE_COMPUTE_CPU=1','/DHYLE_COMPUTE_GGML_CPU=1','/DHYLE_COMPUTE_ONEDNN=1','/DHYLE_TEST_GGML_CPU=1','/DHYLE_TEST_TORCH_CPU=1'):
                if arg not in args:args.append(arg)
            if name=='graph':args.append('/DHYLE_TEST_GRAPH_ROUTE_CPU=1')
            if name=='runtime':args.append('/DHYLE_G10_TEST_VENDOR=1')
            for arg in torch_includes:
                if arg not in args:args.append(arg)
        assert '/WX' in args and '/MD' in args and '/O2' in args,name
        t.save(W/f'recipes/{name}.json',dict(command=args,timeout_seconds=300))
        units[name]=dict(source=source,original_command=t.pin(command),original_dependencies=t.pin(deps),recipe=t.pin(W/f'recipes/{name}.json'))
    for name in CONSUMERS:
        replace={t.key(oldobjects[n]['path']):str(W/f'compile/{n}/unit.obj') for n in SDK}
        replace[t.key(oldobjects['consumer']['path'])]=str(W/f'compile/{name}/unit.obj');args=[]
        for arg in t.command(ready['recipe']['path']):
            if t.key(arg)==t.key(oldobjects['rules']['path']):continue
            arg=replace.get(t.key(arg),arg)
            for prefix,suffix in (('/OUT:','.exe'),('/PDB:','.pdb'),('/IMPLIB:','.lib'),('/MAP:','.map')):
                if arg.upper().startswith(prefix):arg=prefix+str((W/'bin'/name).with_suffix(suffix));break
            args.append(arg)
        if name!='runtime':args.extend(row['path'] for row in gtest)
        assert all(sum(t.key(a)==t.key(v) for a in args)==1 for v in replace.values())
        assert not any(t.key(a)==t.key(oldobjects['rules']['path']) for a in args)
        t.save(W/f'link-recipes/{name}.json',dict(command=args,timeout_seconds=240))
    excluded={t.key(row['path']) for row in oldobjects.values()};retained=[]
    for row in [row for row in rows if t.key(row['path']) not in excluded]+gtest:
        st=Path(row['path']).stat();assert st.st_size==row['bytes']
        retained.append(dict(path=row['path'],bytes=st.st_size,mtime_ns=st.st_mtime_ns,retained_sha256=row['sha256']))
    assert len(retained)==223
    t.save(W/'retained-stats.json',retained)
    env=t.read(BASE/'environment.json');env['PATH']=str(W/'bin')+';'+env['PATH'];t.save(W/'environment.json',env)
    t.save(W/'runtime.json',dict(PATH=env['PATH'],native=t.read(BASE/'runtime.json')['native']))
    t.save(W/'plan.json',dict(status='PREPARED_NOT_FROZEN',baseline=t.pin(BASE/'ready-tiny.json'),inputs=ready['inputs'],
        units=units,old_objects=oldobjects,gtest=gtest,environment=t.pin(W/'environment.json'),runtime=t.pin(W/'runtime.json'),
        retained_stats=t.pin(W/'retained-stats.json'),links={n:t.pin(W/f'link-recipes/{n}.json') for n in CONSUMERS},
        counts=dict(CXX=8,SDK_CXX=5,consumer_CXX=3,links=3,NVCC=0,downloads=0,retained_original=221,
                    direct_inputs=229,graph_inputs=229,runtime_inputs=227),
        scope='Current228 minus default_rules OBJ, replace5 SDK and consumer; add only original2 GTest libs to direct/graph. No final source hashes captured until root freeze.'))
    print('PREPARED8CXX/3links; NOT frozen; no compiler/test process')


def plan():
    p=t.read(W/'plan.json')
    for key in ('baseline','inputs','environment','runtime','retained_stats'):t.exact(p[key])
    for unit in p['units'].values():
        for key in ('original_command','original_dependencies','recipe'):t.exact(unit[key])
    for row in p['links'].values():t.exact(row)
    return p


def freeze():
    p=plan();paths={};snapshots=[]
    for unit in p['units'].values():
        args=t.command(unit['recipe']['path'])
        roots=[Path(a[2:]) for a in args if a.lower().startswith('/i')]
        roots += [Path(a[len('/external:I'):]) for a in args if a.lower().startswith('/external:i')]
        pending=[R/unit['source']];seen=set()
        while pending:
            path=pending.pop().resolve();key=t.key(path)
            if key in seen:continue
            seen.add(key);paths[key]=path
            for kind,name in re.findall(r'^\s*#\s*include\s*([<"])([^>"\r\n]+)[>"]',path.read_text(encoding='utf-8-sig'),re.M):
                found=next((v.resolve() for root in ([path.parent] if kind=='"' else [])+roots if (v:=root/name).is_file()),None)
                if found is not None and t.project(found):pending.append(found)
    t.save(W/'frozen-project-includes.json',[t.pin(path) for path in sorted(paths.values())])
    for relative in dict.fromkeys([*SOURCES.values(),'include/hyle/compute/providers/native.h','src/compute_route_cpu/default_policy.h']):
        if not (R/relative).is_file():continue
        target=W/'source'/relative;target.parent.mkdir(parents=True,exist_ok=True)
        with target.open('xb') as out:out.write((R/relative).read_bytes())
        snapshots.append(dict(original=t.pin(R/relative),snapshot=t.pin(target)))
    t.save(W/'source-freeze.json',dict(helper=t.pin(__file__),plan=t.pin(W/'plan.json'),
        includes=t.pin(W/'frozen-project-includes.json'),snapshots=snapshots,
        deleted_rule_sources={s:not(R/s).exists() for s in ('src/compute_provider_native/default_rules.h','src/compute_provider_native/default_rules.cc')},
        scope='Literal current project include closure; external SDK headers recorded by actual CXX deps. No SDK headers copied or rehashed in prepare.'))
    print('FROZEN',len(paths),'project dependencies; metadata only')


def validate():
    p=plan();f=t.read(W/'source-freeze.json')
    for key in ('helper','plan','includes'):t.exact(f[key])
    for row in t.read(f['includes']['path']):t.exact(row)
    for row in f['snapshots']:t.exact(row['original']);t.exact(row['snapshot'])
    return p,f


def parse_compile(name):
    p,f=validate();out=W/f'compile/{name}';process=t.read(W/f'logs/{name}/process.json')
    assert process['exit']==0 and not process['timed_out'],process
    allowed={t.key(row['path']):row for row in t.read(f['includes']['path'])};actual=[]
    for path in dict.fromkeys(t.dep_paths(out/'dependencies.json')):
        path=path.resolve()
        if t.project(path):
            assert t.key(path) in allowed,('Successful CXX metadata issue; parse only',str(path));t.exact(allowed[t.key(path)])
        actual.append(t.pin(path))
    t.save(out/'actual-dependencies.json',actual)
    t.save(out/'compiled.json',dict(source=t.pin(R/SOURCES[name]),object=t.pin(out/'unit.obj'),process=process,
        command=t.pin(W/f'logs/{name}/command.json'),dependencies=t.pin(out/'dependencies.json'),actual_dependencies=t.pin(out/'actual-dependencies.json')))
    print('CXX metadata PASS',name)


def compile_unit(name):
    p,_=validate();assert name in SOURCES;(W/f'compile/{name}').mkdir(parents=True,exist_ok=False)
    t.execute(t.command(p['units'][name]['recipe']['path']),W/f'logs/{name}',300);parse_compile(name)


def link(name):
    p,_=validate();assert name in CONSUMERS
    compiled={n:t.read(W/f'compile/{n}/compiled.json') for n in (*SDK,name)}
    for row in compiled.values():t.exact(row['object'])
    for row in t.read(p['retained_stats']['path']):
        st=Path(row['path']).stat();assert(st.st_size,st.st_mtime_ns)==(row['bytes'],row['mtime_ns']),row['path']
    replace={t.key(p['old_objects'][n]['path']):compiled[n]['object'] for n in SDK}
    replace[t.key(p['old_objects']['consumer']['path'])]=compiled[name]['object']
    rows=[replace.get(t.key(row['path']),row) for row in t.read(p['inputs']['path']) if t.key(row['path'])!=t.key(p['old_objects']['rules']['path'])]
    if name!='runtime':rows += p['gtest']
    assert len(rows)==(227 if name=='runtime' else 229)
    assert sum(t.key(row['path']) in {t.key(v['path']) for v in replace.values()} for row in rows)==6
    (W/'bin').mkdir(exist_ok=True);native=t.read(p['runtime']['path'])['native'];alias=W/'bin'/Path(native['path']).name
    if not alias.exists():alias.hardlink_to(native['path'])
    assert alias.samefile(native['path']);t.save(W/f'inputs-{name}.json',rows)
    process=t.execute(t.command(p['links'][name]['path']),W/f'links/{name}',240)
    t.save(W/f'ready-{name}.json',dict(image=t.pin(W/f'bin/{name}.exe'),inputs=t.pin(W/f'inputs-{name}.json'),compiled=compiled,
        process=process,recipe=t.pin(W/f'links/{name}/command.json'),runtime=p['runtime'],source_freeze=t.pin(W/'source-freeze.json')))
    print('LINK PASS',name,len(rows),'inputs')


if __name__=='__main__':
    action=sys.argv[1]
    if action=='prepare':prepare()
    elif action=='freeze':freeze()
    elif action=='preflight':validate();print('PREFLIGHT PASS')
    elif action=='compile':compile_unit(sys.argv[2])
    elif action=='parse-compile':parse_compile(sys.argv[2])
    elif action=='link':link(sys.argv[2])
    else:raise ValueError(action)
