"""Explicit finite consumers; each runtime scenario gets its original fresh process."""
from pathlib import Path
import importlib.util
import os
import re
import subprocess
import sys
import time
import xml.etree.ElementTree as ET

sys.dont_write_bytecode = True
W=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('current_cpu_route_validation',W/'build.py')
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b);t=b.t


def runtime_flags():
    frozen=t.read(W/'source-freeze.json')
    source=next(v['snapshot']['path'] for v in frozen['snapshots'] if t.key(v['original']['path'])==t.key(b.R/b.SOURCES['runtime']))
    return list(dict.fromkeys(re.findall(r'mode\s*==\s*"--([a-z-]+)"',Path(source).read_text(encoding='utf-8'))))


def parse(name,scenario=None):
    label=name if scenario is None else 'runtime-'+scenario
    out=W/'runs'/label;process=t.read(out/'process.json')
    stdout=(out/'stdout.log').read_text(encoding='utf-8',errors='replace')
    stderr=(out/'stderr.log').read_text(encoding='utf-8',errors='replace')
    assert not process['timed_out'],process
    if name=='runtime':
        if process['exit']==77:
            assert 'NOT_APPLICABLE:' in stdout,stdout
            summary=dict(status='NOT_APPLICABLE',process=process,scenario=scenario,reason=stdout.strip())
        else:
            assert process['exit']==0,process
            expected='PASS CPU runtime --'+scenario+' '
            assert sum(line.startswith(expected) for line in stdout.splitlines())==1,stdout
            assert 'FAIL CPU runtime:' not in stderr,stderr
            summary=dict(status='PASS',process=process,scenario=scenario,telemetry=next(line for line in stdout.splitlines() if line.startswith(expected)))
    else:
        assert process['exit']==0,process
        root=ET.parse(out/'results.xml').getroot();tests=int(root.attrib['tests']);failures=int(root.attrib['failures']);errors=int(root.attrib['errors'])
        skipped=len(root.findall('.//testcase/skipped'));cases=[]
        assert tests>0 and failures==0 and errors==0,(tests,failures,errors,skipped)
        for v in root.findall('.//testcase'):
            skip=v.find('skipped');reason=None
            if skip is not None:
                reason=skip.attrib.get('message','') or (skip.text or '')
                assert(v.attrib['classname'],v.attrib['name'])==('CpuDefaultContext','D5RealQwenProjectionUsesExactProfileAndReplays'),v.attrib
                assert 'set HYLE_D5_QWEN35_FIXTURE to the prepared local fixture' in reason,reason
            cases.append(dict(suite=v.attrib['classname'],name=v.attrib['name'],status='SKIP' if skip is not None else 'PASS',skip_reason=reason))
        assert len(cases)==tests
        summary=dict(status='PASS_WITH_SKIPS' if skipped else 'PASS',process=process,consumer=name,
            tests=tests,passed=tests-skipped,failures=failures,errors=errors,skipped=skipped,cases=cases)
    t.save(out/'summary.json',summary);print(label,summary['status'])


def run(name,scenario=None):
    p,_=b.validate();assert name in b.CONSUMERS
    if name=='runtime':assert scenario in runtime_flags(),(scenario,runtime_flags())
    else:assert scenario is None
    ready=t.read(W/f'ready-{name}.json');t.exact(ready['image']);t.exact(ready['inputs'])
    runtime=t.read(ready['runtime']['path']);native=runtime['native']
    assert(W/'bin'/Path(native['path']).name).samefile(native['path'])
    env=os.environ.copy();env.update(PATH=runtime['PATH'],HF_HUB_OFFLINE='1',HF_DATASETS_OFFLINE='1',TRANSFORMERS_OFFLINE='1')
    # Runtime tests deliberately exercise startup/configuration. Do not inject
    # OMP/MKL limits or affinity inherited from the separate performance leaf.
    label=name if scenario is None else 'runtime-'+scenario;out=W/'runs'/label;out.mkdir(parents=True,exist_ok=False)
    args=[ready['image']['path']]
    if name=='runtime':args.append('--'+scenario)
    else:args += ['--gtest_filter=CpuCurrentRules.*:CpuDefaultContext.*','--gtest_output=xml:'+str(out/'results.xml')]
    whitelist=('OMP_NUM_THREADS','MKL_NUM_THREADS','OMP_DYNAMIC','OMP_PROC_BIND','KMP_AFFINITY','HYLE_PERF_CALLER_CPU')
    t.save(out/'command.json',dict(command=args,cwd=str(b.R),timeout_seconds=180,ready=t.pin(W/f'ready-{name}.json'),
        environment_relevant={key:env[key] for key in whitelist if key in env},runtime=ready['runtime']))
    start=time.time();timed_out=False
    with(out/'stdout.log').open('xb') as stdout,(out/'stderr.log').open('xb') as stderr:
        child=subprocess.Popen(args,cwd=b.R,env=env,stdout=stdout,stderr=stderr,creationflags=subprocess.CREATE_NO_WINDOW)
        t.save(out/'running.json',dict(pid=child.pid,started=start))
        try:code=child.wait(timeout=180)
        except subprocess.TimeoutExpired:
            timed_out=True;child.terminate()
            try:code=child.wait(timeout=10)
            except subprocess.TimeoutExpired:child.kill();code=child.wait(timeout=10)
    process=dict(pid=child.pid,exit=code,started=start,seconds=time.time()-start,state='TERMINAL',timed_out=timed_out)
    t.save(out/'process.json',process)
    assert not timed_out and(code==0 or(name=='runtime' and code==77)),process
    parse(name,scenario)


if __name__=='__main__':
    action=sys.argv[1]
    if action=='list-runtime':print('\n'.join(runtime_flags()))
    elif action=='run':run(sys.argv[2],sys.argv[3] if len(sys.argv)>3 else None)
    elif action=='parse-only':parse(sys.argv[2],sys.argv[3] if len(sys.argv)>3 else None)
    else:raise ValueError(action)
