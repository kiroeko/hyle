"""One admission/numeric probe. Measurements are explicitly deferred to root."""
from pathlib import Path
import importlib.util
import itertools
import os
import re
import subprocess
import sys
import time

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('cpu_leaf_build', W / ('build-attempt2.py' if (W / 'attempt2/source-freeze.json').exists() else 'build.py'))
b = importlib.util.module_from_spec(spec); spec.loader.exec_module(b)
t = b.t
FAMILIES = ('native', 'onednn', 'ggml', 'aten')


def parse_probe(directory):
    out = Path(directory); process = t.read(out / 'process.json')
    assert process['exit'] == 0 and not process['timed_out'], process
    text = (out / 'stderr.log').read_text(encoding='utf-8', errors='replace')
    telemetry = re.findall(r'^# CPU_BEST_OF affinity_topology=(\S+) caller_cpu=(\S+) affinity_ok=(\S+) run_nonce=(\S+)$', text, re.M)
    assert len(telemetry) == 1, 'Missing or repeated original affinity telemetry'
    admissions, pairs, counts = {}, {}, {}
    for line in text.splitlines():
        if line.startswith('# ADMISSION '):
            m = re.match(r'^# ADMISSION id=(\S+) provider=(\S+) .*?result=(ACCEPTED|DECLINED|FEATURE_ABSENT)(?:\s|$)', line)
            assert m, line
            case, family, result = m.groups(); key = (case, family)
            assert key not in admissions, key
            admissions[key] = dict(result=result, raw=line)
        elif line.startswith('PAIR\t'):
            _, case, a, c, result = line.split('\t'); key = (case, a, c)
            assert key not in pairs and result == 'NUMERIC_MATCH', line
            pairs[key] = result
        elif line.startswith('CARRIER_COUNT\t'):
            _, case, count = line.split('\t'); assert case not in counts, case
            counts[case] = int(count)
    ids = [v['id'] for v in t.read(W / 'workloads.json')]
    assert len(ids) == 15 and set(admissions) == set(itertools.product(ids, FAMILIES))
    assert set(counts) == set(ids)
    expected_pairs = set(); cases = []
    for case in ids:
        admitted = [f for f in FAMILIES if admissions[(case, f)]['result'] == 'ACCEPTED']
        assert counts[case] == len(admitted), case
        expected_pairs.update((case, a, c) for a, c in itertools.combinations(admitted, 2))
        cases.append(dict(id=case, providers={f:admissions[(case, f)] for f in FAMILIES},
                          admitted=len(admitted), numeric_pairs=len(admitted)*(len(admitted)-1)//2))
    assert set(pairs) == expected_pairs, ('Missing/extra actual numeric comparison', set(pairs)^expected_pairs)
    assert 'NUMERIC_MISMATCH' not in text and 'NUMERIC_DIFFERENCE' not in text
    summary = dict(status='PROBE_ADMISSIONS_AND_NUMERICS_CHECKED', process=process,
        case_count=15, requested_providers=list(FAMILIES), admission_records=len(admissions),
        admitted=sum(c['admitted'] for c in cases), numeric_pairs=len(pairs), cases=cases,
        telemetry=dict(zip(('affinity_topology','caller_cpu','affinity_ok','run_nonce'),telemetry[0])),
        performance_claim=False, measurements_run=0)
    t.save(out / 'summary.json', summary)
    print('PROBE PARSED:', len(admissions), 'admission records,', len(pairs), 'numeric matches; no timing claim')


def probe():
    b.validate(); ready = t.read(W / 'ready.json'); t.exact(ready['image']); t.exact(ready['runtime'])
    runtime = t.read(ready['runtime']['path']); native = runtime['native']
    assert (W / 'bin' / Path(native['path']).name).samefile(native['path'])
    env = os.environ.copy(); env.update(PATH=runtime['PATH'], OMP_NUM_THREADS='1', MKL_NUM_THREADS='1',
        HF_HUB_OFFLINE='1', HF_DATASETS_OFFLINE='1', TRANSFORMERS_OFFLINE='1')
    # Affinity is inherited only when the launcher explicitly set it. No CPU2,
    # process affinity, priority, administrator or machine setting is imposed.
    env.setdefault('HYLE_PERF_RUN_NONCE', 'cpu-routing-admission-probe')
    allowed = ('HYLE_PERF_CALLER_CPU','HYLE_PERF_SAMPLING_TOPOLOGY','HYLE_PERF_RUN_NONCE',
               'OMP_NUM_THREADS','MKL_NUM_THREADS','HYLE_BENCH_RIVAL_FIRST',
               'HYLE_BENCH_PEER_ALLOCATION_FIRST','HYLE_CPU_BESTOF_AA')
    out = W / 'runs/probe'; out.mkdir(parents=True, exist_ok=False)
    args = [ready['image']['path'], '--probe']; timeout = 300
    t.save(out / 'command.json', dict(command=args, cwd=str(b.R), timeout_seconds=timeout,
        ready=t.pin(W / 'ready.json'), runtime=ready['runtime'],
        environment_relevant={k:env[k] for k in allowed if k in env}))
    start = time.time(); timed_out = False
    with (out / 'stdout.log').open('xb') as stdout, (out / 'stderr.log').open('xb') as stderr:
        child = subprocess.Popen(args, cwd=b.R, env=env, stdout=stdout, stderr=stderr,
                                 creationflags=subprocess.CREATE_NO_WINDOW)
        t.save(out / 'running.json', dict(pid=child.pid, started=start))
        try: code = child.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            timed_out = True; child.terminate()
            try: code = child.wait(timeout=10)
            except subprocess.TimeoutExpired: child.kill(); code = child.wait(timeout=10)
    process = dict(pid=child.pid, exit=code, started=start, seconds=time.time()-start,
                   state='TERMINAL', timed_out=timed_out)
    t.save(out / 'process.json', process)
    assert code == 0 and not timed_out, process
    parse_probe(out)


if __name__ == '__main__':
    if sys.argv[1] == 'probe': probe()
    elif sys.argv[1] == 'parse-probe': parse_probe(W / 'runs/probe')
    else: raise ValueError(sys.argv[1])
