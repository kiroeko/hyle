"""Prepare a finite leaf catalog only. Does not compile, link or run anything."""
from pathlib import Path
import hashlib
import json

R = Path('C:/public/project-hyle/hyle')
W = Path(__file__).resolve().parent
BASE = R / 'bench/compute_provider_native/cpu_best_of_p1/cpu_best_of_bench.cc'


def pin(p):
    raw = p.read_bytes()
    return dict(path=str(p), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


def save_new(p, data):
    raw = (json.dumps(data, indent=2) + '\n').encode() if not isinstance(data, bytes) else data
    p.parent.mkdir(parents=True, exist_ok=True)
    if p.exists():
        assert p.read_bytes() == raw, ('preserve previous preparation', str(p))
    else:
        p.write_bytes(raw)


shapes = [(1, 256), (1, 1024), (1, 2047), (1, 2048), (1, 3072),
          (1, 4096), (1, 4097), (1, 16384), (1, 65536), (1, 262144),
          (3072,), (3, 1024), (2, 3, 512), (32, 2048), (8, 8192)]
cases = []
for shape in shapes:
    count = 1
    for extent in shape:
        count *= extent
    cases.append(dict(id='exp-f32-' + 'x'.join(map(str, shape)),
                      operation='Unary::kExp', dtype='Float32', dimensions=shape,
                      elements=count, input_bytes=4 * count, output_bytes=4 * count,
                      layout='plain dense, same input/output dimensions',
                      legacy_anchor=shape in [(1, 2048), (1, 4096), (32, 2048)]))

source = BASE.read_text(encoding='utf-8')
source = source.replace('#include <nanobench.h>', '#define ANKERL_NANOBENCH_IMPLEMENT\n#include <nanobench.h>', 1)
old_include = '#include "../../common/perf_process.h"'
assert source.count(old_include) == 1
source = source.replace(old_include, '#include "' + (R / 'bench/common/perf_process.h').as_posix() + '"')
old_field = '  int columns = 24;\n};'
assert source.count(old_field) == 1
source = source.replace(old_field, '  int columns = 24;\n  std::vector<std::int64_t> dimensions{};\n};')
start = source.index('std::vector<Case> catalog() {')
end = source.index('template <class T> void store', start)
catalog = ['std::vector<Case> catalog() {', '  std::vector<Case> result;']
for row in cases:
    dims = row['dimensions']
    rows = dims[0] if len(dims) == 2 else 1
    width = dims[-1] if len(dims) == 2 else row['elements']
    catalog.append('  result.push_back({"' + row['id'] + '", Kind::Unary, c::DataType::kFloat32, '
                   'int(c::UnaryKind::kExp), ' + str(rows) + ', c::DataType::kFloat32, '
                   + str(width) + ', 24, {' + ', '.join(map(str, dims)) + '}});')
catalog.extend(['  return result;', '}', '', ''])
source = source[:start] + '\n'.join(catalog) + source[end:]
old_desc = '    auto d = dense(t, {r, h});'
assert source.count(old_desc) == 1
source = source.replace(old_desc, '    auto d = spec.dimensions.empty() ? dense(t, {r, h})\n'
                       '        : take(c::TensorDesc::dense(t, spec.dimensions));')
save_new(W / 'source/cpu_route_flat_exp_bench.cc', source.encode())
save_new(W / 'workloads.json', cases)

CURRENT = R / '.scratch/inference-execution-preparation-20261028'
ready = json.loads((CURRENT / 'ready-tiny.json').read_text())
inputs = json.loads(Path(ready['inputs']['path']).read_text())
assert len(inputs) == 228 and ready['compiled']['object'] in inputs
assert not any('nanobench' in row['path'].lower() for row in inputs)
old_source = json.loads(Path(ready['compiled']['dependencies']['path']).read_text())['Data']['Source']
before = json.loads(Path(ready['compiled']['command']['path']).read_text())['command']
commands = []
for i, arg in enumerate(before):
    if arg.casefold() == old_source.casefold():
        arg = str(W / 'source/cpu_route_flat_exp_bench.cc')
    elif i and before[i - 1].lower() == '/sourcedependencies':
        arg = str(W / 'compile/bench/dependencies.json')
    elif arg.lower().startswith('/fo'):
        arg = '/Fo' + str(W / 'compile/bench/unit.obj')
    elif arg.lower().startswith('/fd'):
        arg = '/Fd' + str(W / 'compile/bench/unit.pdb')
    commands.append(arg)
commands.append('/I' + str(R / 'third_party/nanobench'))
save_new(W / 'recipe-compile.json', dict(command=commands, cwd=str(R), timeout_seconds=300))
link = []
for arg in json.loads(Path(ready['recipe']['path']).read_text())['command']:
    if arg.casefold() == ready['compiled']['object']['path'].casefold():
        arg = str(W / 'compile/bench/unit.obj')
    for prefix, suffix in [('/OUT:', '.exe'), ('/PDB:', '.pdb'), ('/IMPLIB:', '.lib'), ('/MAP:', '.map')]:
        if arg.upper().startswith(prefix):
            arg = prefix + str((W / 'bin/bench').with_suffix(suffix))
            break
    link.append(arg)
save_new(W / 'recipe-link.json', dict(command=link, cwd=str(R), timeout_seconds=240))
save_new(W / 'retained-inputs.json', inputs)
runtime = json.loads((CURRENT / 'runtime.json').read_text())
save_new(W / 'build-plan.json', dict(status='METADATA_ONLY_NO_BUILD', baseline=pin(CURRENT / 'ready-tiny.json'),
    original_input_manifest=ready['inputs'], original_consumer=ready['compiled']['object'],
    source=pin(W / 'source/cpu_route_flat_exp_bench.cc'),
    compile_recipe=pin(W / 'recipe-compile.json'), link_recipe=pin(W / 'recipe-link.json'),
    environment=pin(CURRENT / 'environment.json'), runtime=pin(CURRENT / 'runtime.json'),
    native_cpu_plugin=runtime['native'],
    runtime_action='Before root runs, hardlink the exact native_cpu_plugin beside bin/bench.exe and verify samefile; no DLL copy.',
    inputs=228, replaced_consumer_objects=1, new_CXX=1, new_links=1, SDK_CXX=0, NVCC=0,
    nanobench='Original third_party implementation compiled once inside the one scratch bench TU; no retained nanobench object.'))

plan = dict(
    status='PREPARED_ONLY_NO_BUILD_OR_NATIVE_RUN',
    first_slice='Replace only dense F32 Exp shape-point routing with a measured flat-work domain.',
    source=pin(W / 'source/cpu_route_flat_exp_bench.cc'), retained_consumer=pin(BASE),
    changes=['finite catalog, independent total-element geometry and equal-count rank cases',
             'exact same Session, named provider factory, numeric comparison, submit/wait and nanobench logic'],
    unchanged_providers=['native', 'onednn', 'ggml', 'aten'],
    cases=len(cases), current_admission_probe_command=['<new-current-image>', '--probe'],
    pair_command=['<new-current-image>', '--pair', '<case-id>', 'native', '<actually-admitted-rival>'],
    order_strata=[dict(HYLE_BENCH_RIVAL_FIRST=False, HYLE_BENCH_PEER_ALLOCATION_FIRST=False),
                  dict(HYLE_BENCH_RIVAL_FIRST=True, HYLE_BENCH_PEER_ALLOCATION_FIRST=False),
                  dict(HYLE_BENCH_RIVAL_FIRST=False, HYLE_BENCH_PEER_ALLOCATION_FIRST=True),
                  dict(HYLE_BENCH_RIVAL_FIRST=True, HYLE_BENCH_PEER_ALLOCATION_FIRST=True)],
    thread_policy=dict(native_threads=1, OMP_NUM_THREADS=1, MKL_NUM_THREADS=1,
                       caller_cpu='Root selects and records an actual process-available homogeneous CPU; no fixed CPU2 assumption.'),
    build=dict(status='current_228_recipes_prepared', new_consumer_TUs=1,
               SDK_or_NVCC_builds=0, old_560_SDK_or_EXE_reused=False,
               note='Current execution-preparation ready228, consumer OBJ replacement only. Original C:/hv SDK and benchmark EXEs no longer exist.',
               manifest=pin(W / 'build-plan.json')),
    acceptance=['record every current provider admission, reject NUMERIC_MISMATCH',
                'measure only pairs whose two original programs were really admitted',
                'preserve all three old F32 Exp route points as explicit regression anchors',
                'separate rank/shape holdouts from model fitting; no extrapolated WIN label',
                'uncertain or out-of-support work keeps a visible engineering-default route_policy'],
    limits=['No product change, no benchmark result or provider winner is asserted.',
            'Old F4 observations are historical anchors, not current measurements.',
            'No online tuning, new executor, model data, download or full SDK copy.'])
save_new(W / 'plan.json', plan)
print(json.dumps(dict(status=plan['status'], cases=len(cases), source=plan['source'], plan=pin(W / 'plan.json'))))
