from pathlib import Path
import importlib.util,sys,concurrent.futures,difflib
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent;A=S.parent;R=A.parents[1];O=S/'diagnostic-build';O.mkdir(exist_ok=True);(O/'tmp').mkdir(exist_ok=True)
sp=importlib.util.spec_from_file_location('retirement_diagnostic_build',A/'grouped-shared-activation/build_host.py');h=importlib.util.module_from_spec(sp);sp.loader.exec_module(h);b,c=h.b,h.c
recipe=c.read(A/'gdn-direct-state-output/checks/native1/provider-identity.json');basepath=A/'decode-first-prepare/checks/link-plan.json';base=c.read(basepath)
for row in base['inputs']:assert h.same_identity(row)
env,runtime=b.environment(base['command'],[x['path']for x in base['inputs']],O);c.save(O/'environment.json',dict(PATH=env['PATH'],LIB=env.get('LIB'),INCLUDE=env.get('INCLUDE'),runtime=runtime))
rows=[]
for arm,original in [('before',S/'before/src/compute_provider_ggml_cuda/ggml_cuda_provider.cc'),('current',R/'src/compute_provider_ggml_cuda/ggml_cuda_provider.cc')]:
 text=original.read_bytes().decode();start=text.index('Status observe_native_retirement(void *opaque, bool wait,');end=text.index('\nStatus prepare_bindings(',start);part=text[start:end]
 part=part.replace('  Status first;\n','  Status first;\n  std::size_t diagnostic_nodes = 0, diagnostic_queries = 0, diagnostic_guards = 0;\n',1)
 part=part.replace('    auto &invocation = *static_cast<Invocation *>(current.state);','    ++diagnostic_nodes;\n    auto &invocation = *static_cast<Invocation *>(current.state);',1)
 assert part.count('const auto result = cudaStreamIsCapturing(')==1
 part=part.replace('const auto result = cudaStreamIsCapturing(','++diagnostic_queries;\n        const auto result = cudaStreamIsCapturing(',1)
 part=part.replace('          bridge::release_recording_guard();','          ++diagnostic_guards;\n          bridge::release_recording_guard();',1)
 part=part.replace('  return first;','  if (diagnostic_nodes > 1)\n    std::fprintf(stderr, "retirement-observer nodes=%zu queries=%zu guards=%zu retired=%d wait=%d\\n", diagnostic_nodes, diagnostic_queries, diagnostic_guards, *retired, wait);\n  return first;',1)
 changed='#include <cstdio>\n'+text[:start]+part+text[end:];source=S/'diagnostic-source'/arm/'ggml_cuda_provider.cc';source.parent.mkdir(parents=True,exist_ok=True);source.write_bytes(changed.encode());(source.parent/'instrumentation.diff').write_bytes(''.join(difflib.unified_diff(text.splitlines(True),changed.splitlines(True),fromfile=str(original),tofile=str(source))).encode())
 out=O/arm;out.mkdir(exist_ok=True);(out/'tmp').mkdir(exist_ok=True);rows.append(dict(tag='provider',arm=arm,source=b.identity(source),uninstrumented_source=b.identity(original),command=b.host_command(recipe['command'],source,'provider',out),out=str(out)))
testrecipe=c.read(S/'checks/provider-test-identity.json');tout=O/'tests';tout.mkdir(exist_ok=True);(tout/'tmp').mkdir(exist_ok=True);rows.append(dict(tag='provider-test',arm='tests',source=b.identity(R/'tests/compute_provider_ggml_cuda/provider_test.cc'),command=b.host_command(testrecipe['command'],R/'tests/compute_provider_ggml_cuda/provider_test.cc','provider-test',tout),out=str(tout)))
c.save(O/'plan.json',dict(compile=rows,diagnostic_main=base.get('main_object'),base=b.identity(basepath),CXX=3,links=3,NVCC=0,GPU=0))
def compile(row):
 out=Path(row['out']);c.execute(row['tag']+'-compile',row['command'],env,out);dep=out/(row['tag']+'-deps.json');d=c.read(dep)['Data'];record=dict(row,object=b.identity(out/(row['tag']+'.obj')),source_dependencies=b.identity(dep),dependencies=[b.identity(p)for p in dict.fromkeys([d['Source'],*d['Includes']])]);c.save(out/(row['tag']+'-identity.json'),record);return record
with concurrent.futures.ThreadPoolExecutor(max_workers=3)as pool:built=list(pool.map(compile,rows))
def link(arm,base,basepath,old,new,output):
 command=[new['path']if c.key(x)==c.key(old['path'])else x for x in base['command']if not x.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:'))];command+=['/OUT:'+str(output),'/MAP:'+str(output.with_suffix('.map')),'/IMPLIB:'+str(output.with_suffix('.lib'))];inputs=[new if c.key(x['path'])==c.key(old['path'])else x for x in base['inputs']]
 for row in inputs:assert h.same_identity(row)
 c.save(output.parent/'link-plan.json',dict(command=command,inputs=inputs,base=b.identity(basepath),replacements=[dict(before=old,after=new)],diagnostic=arm!='tests'));c.execute('link',command,env,output.parent);c.save(output.parent/'image.json',b.identity(output))
for row in built[:2]:link(row['arm'],base,basepath,recipe['object'],row['object'],Path(row['out'])/'qwen-retirement.exe')
tbasepath=S/'checks/refreshed-retirement/link-plan.json';tbase=c.read(tbasepath);link('tests',tbase,tbasepath,testrecipe['object'],built[2]['object'],tout/'retirement-tests.exe')
print('RETIREMENT_DIAGNOSTIC_AND_CORRECTED_TEST_LINKS_GREEN')
