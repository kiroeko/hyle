from pathlib import Path
import hashlib,json,difflib
R=Path.cwd();S=R/'.scratch/architecture-refactor-2026-10-18/decode-retirement-query-reuse';p=R/'src/compute_provider_ggml_cuda/ggml_cuda_provider.cc';b=p.read_bytes();before=S/'before/src/compute_provider_ggml_cuda/ggml_cuda_provider.cc';assert b==before.read_bytes();s=b.decode();start=s.index('Status observe_native_retirement(void *opaque, bool wait,');end=s.index('\nStatus prepare_bindings(',start);old=s[start:end]
new=old.replace('  Status first;\n','  Status first;\n  CUcontext ended_primary = nullptr;\n  cudaStream_t ended_stream = nullptr;\n',1)
a='    current = invocation.previous_retirement;\n';assert new.count(a)==1;new=new.replace(a,a+'''    // This proves the old Completion's recording ended, not that this stream
    // remains idle. A later capture belongs to another retained owner.
    const bool ended = invocation.recording_guard &&
        invocation.failed_recording_stream != nullptr &&
        invocation.primary == ended_primary &&
        invocation.failed_recording_stream == ended_stream;
    if (!ended) { ended_primary = nullptr; ended_stream = nullptr; }
''')
a='''      cudaStreamCaptureStatus capture = cudaStreamCaptureStatusNone;
      const auto result = cudaStreamIsCapturing(
          invocation.failed_recording_stream, &capture);
      observed = cuda::status(result);
      complete = result == cudaSuccess && capture == cudaStreamCaptureStatusNone;
''';assert new.count(a)==1;new=new.replace(a,'''      const auto stream = invocation.failed_recording_stream;
      if (!ended) {
        cudaStreamCaptureStatus capture = cudaStreamCaptureStatusNone;
        const auto result = cudaStreamIsCapturing(stream, &capture);
        observed = cuda::status(result);
        complete = result == cudaSuccess && capture == cudaStreamCaptureStatusNone;
      }
''')
a='''      if (complete) {
        invocation.failed_recording_stream = nullptr;
''';assert new.count(a)==1;new=new.replace(a,'''      if (complete) {
        if (invocation.recording_guard) {
          ended_primary = invocation.primary; ended_stream = stream;
        }
        invocation.failed_recording_stream = nullptr;
''')
a='    if (complete && invocation.native_retirement_required) {\n';assert new.count(a)==1;new=new.replace(a,'''    if (!complete || invocation.native_retirement_required) {
      ended_primary = nullptr; ended_stream = nullptr;
    }
'''+a)
a='  if (current.observe != nullptr) {\n';assert new.count(a)==1;new=new.replace(a,'''  // The positive proof never leaves this original GGML retirement chain.
  ended_primary = nullptr; ended_stream = nullptr;
'''+a)
s=s[:start]+new+s[end:];p.write_bytes(s.encode());out=S/'source/src/compute_provider_ggml_cuda/ggml_cuda_provider.cc';out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(p.read_bytes());(S/'source.diff').write_bytes(''.join(difflib.unified_diff(b.decode().splitlines(True),s.splitlines(True),fromfile='before/src/compute_provider_ggml_cuda/ggml_cuda_provider.cc',tofile='src/compute_provider_ggml_cuda/ggml_cuda_provider.cc')).encode())
def I(p):
 p=Path(p);v=p.read_bytes();return dict(path=str(p),bytes=len(v),sha256=hashlib.sha256(v).hexdigest())
f=dict(status='implementation_ready_not_built',product=I(p),before=I(before),source_snapshot=I(out),diff=I(S/'source.diff'),scope='Only observe_native_retirement body changed; localpositiveproof perobserver, allpernode scopes/guards/aux/error/retiredAND preserved.',concurrency_safety=['QueueSequence::finish refuses stillrecording; destructorabortsbeforefinish. End/abort mayfail so realpositiveNONEstillrequired.','defer onlypushes/returns probes fromsameactiveReservedEventSlot; itsCompletionretainsallnodes. Eachobservercallstartswithemptyproof.','Proof is oldcaptureended, notstreamforeveridle. NewcapturebeforequeryActive/Invalidatedcreatesnoproof; newcaptureafterNONEcannotresumeoldrecording andretainsitsownowners.','KeysrequireCUcontext+actualstream+recording_guard withinthisGGMLchain; changes/scopeerrors/aux/unknownfallback invalidate.'],CXX=0,GPU=0)
(S/'source-freeze.json').write_text(json.dumps(f,indent=2)+'\n');print(json.dumps(I(p)))
