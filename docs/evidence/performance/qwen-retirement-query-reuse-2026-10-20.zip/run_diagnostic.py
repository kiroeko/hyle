from pathlib import Path
import importlib.util,sys,re
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent;A=S.parent;O=S/'diagnostic';O.mkdir(exist_ok=True)
def load(name,p):
 sp=importlib.util.spec_from_file_location(name,p);m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m);return m
h=load('retirement_run_helpers',A/'grouped-shared-activation/build_host.py');b,c=h.b,h.c;n=load('retirement_numerics',A/'cuda-bf16-dual-projection/compare_numerics.py');reference=A/'batch-graph-capture/correctness-final';template=c.read(reference/'qwen.command.json')['command'];refresult=n.final_json(reference/'qwen.stdout.log');results=[]
for arm in ['before','current']:
 P=S/'diagnostic-build'/arm;link=c.read(P/'link-plan.json');image=c.read(P/'image.json')
 for row in [image,*link['inputs']]:assert h.same_identity(row)
 out=O/arm;out.mkdir(exist_ok=True);(out/'tmp').mkdir(exist_ok=True);command=template.copy();command[0]=image['path'];command[command.index('--steps')+1]='3';command[command.index('--decode-ids')+1]=str(A/'decode-first-prepare/fixed-prefix2.ids');command[command.index('--replay')+1]='prefer-capture';command[command.index('--trace')+1]=str(out/'trace');env,runtime=b.environment(link['command'],[x['path']for x in link['inputs']],out)
 if not (out/'qwen.result.json').exists():
  c.save(out/'inputs.json',dict(command=command,image=image,link=b.identity(P/'link-plan.json'),runtime=runtime,arm=arm,profiler=False,external_memory_monitor=False,throughput_window=False,instrumentation='per-observer local node/query/guard counters; one fprintf for chains with >1 node, no CUDA behavior/status override'));c.execute('qwen',command,env,out)
 else:
  assert c.read(out/'qwen.command.json')['command']==command
  assert c.read(out/'qwen.result.json')['exit']==0
 actual=n.final_json(out/'qwen.stdout.log');assert actual['generated_ids']==refresult['generated_ids'][:3]and actual['decode_input_ids']==refresult['decode_input_ids'][:2]and actual['visible_tokens']==130
 vectors=[]
 for rel in sorted(p.relative_to(out/'trace')for p in (out/'trace').rglob('*')if p.suffix in('.bf16','.f32')):
  v=n.identity(out/'trace'/rel);r=n.identity(reference/'trace'/rel);assert v['bytes']==r['bytes']and v['sha256']==r['sha256'];m=n.metrics(out/'trace'/rel,reference/'trace'/rel);assert not any(m[k]for k in ['candidate_nan','candidate_posinf','candidate_neginf']);vectors.append(dict(path=rel.as_posix(),actual=v,reference=r,byte_equal=True,metrics=m))
 assert len(vectors)==6
 text=(out/'qwen.stderr.log').read_text();stages=[];observations=[]
 pattern=r'^prepared T=(\d+) visible=(\d+) replay=(\w+) cold_batch_seconds=([0-9.e+-]+) cold_layout_seconds=([0-9.e+-]+) cold_prepare_seconds=([0-9.e+-]+) cold_replay_seconds=([0-9.e+-]+) cold_report_seconds=([0-9.e+-]+) capture_recorded=(\d+) capture_reused=(\d+)'
 for t,v,route,total,layout,batch,replay,report,recorded,reused in re.findall(pattern,text,re.M):stages.append(dict(tokens=int(t),visible=int(v),route=route,cold_total_seconds=float(total),layout_seconds=float(layout),batch_seconds=float(batch),replay_seconds=float(replay),report_seconds=float(report),recorded=int(recorded),reused=int(reused)))
 for nodes,queries,guards,retired,wait in re.findall(r'^retirement-observer nodes=(\d+) queries=(\d+) guards=(\d+) retired=(\d+) wait=(\d+)',text,re.M):observations.append(dict(nodes=int(nodes),queries=int(queries),guards=int(guards),retired=bool(int(retired)),wait=bool(int(wait))))
 assert len(stages)==3 and len(observations)==3
 assert all(r['recorded']==1 and r['reused']==0 for r in stages)
 assert all(r['nodes']>1 and r['guards']==r['nodes'] and r['retired'] for r in observations)
 assert all(r['queries']==(r['nodes'] if arm=='before'else 1) for r in observations)
 result=dict(arm=arm,passed=True,process=c.read(out/'qwen.result.json'),generated_ids=actual['generated_ids'],exact_vectors=6,all_finite=True,vectors=vectors,stages=stages,retirement_observations=observations,full_result=actual);c.save(out/'summary.json',result);results.append(result)
assert [r['nodes']for r in results[0]['retirement_observations']]==[r['nodes']for r in results[1]['retirement_observations']]
c.save(O/'summary.json',dict(passed=True,model_processes=2,arms=results,throughput_window=False,limits=['One instrumented 128+2 process per arm, same149 common inputs except deliberately changed original observer implementation. No stable throughput or causal full-step speed claim.','All per-node context scopes, guard releases and error handling remain; local diagnostic counters/fprintf add overhead inside original boundary.','Exact6prefix vectors match retained canonical source; this is not an independent quality evaluation.','Prior route report388 is not actual callbacks. Actual chains are recorded from running observer; parser initially assumed388 and failed after first successful process, then re-read the same raw process without rerunning.']))
print('RETIREMENT_REAL_QUERY_REUSE_EXACT6_GREEN')
