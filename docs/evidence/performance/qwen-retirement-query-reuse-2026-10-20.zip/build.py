from pathlib import Path
import importlib.util,sys,json,hashlib,difflib,concurrent.futures
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent;A=S.parent;R=A.parents[1];O=S/'checks';O.mkdir(exist_ok=True);(O/'tmp').mkdir(exist_ok=True)
spec=importlib.util.spec_from_file_location('retirement_build_helpers',A/'grouped-shared-activation/build_host.py');h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h);b,c=h.b,h.c
basepath=A/'cuda-native-storage-cast/current-core/link-plan.json';base=c.read(basepath)
for row in base['inputs']:assert h.same_identity(row),row['path']
records=c.read(S/'owner-inventory.json');provider_recipe=A/'gdn-direct-state-output/checks/native1/provider-identity.json';provider=c.read(provider_recipe)
test=records[c.key(A/'cuda-admitted-ggml-stream-implementation/provider-test.obj')]
retirement=records[c.key(A/'cuda-admitted-ggml-stream-implementation/retirement-test.obj')]
env,runtime=b.environment(base['command'],[x['path']for x in base['inputs']],O);c.save(O/'environment.json',dict(PATH=env['PATH'],LIB=env.get('LIB'),INCLUDE=env.get('INCLUDE'),runtime=runtime))
rows=[]
for tag,source,recipe in [('provider',R/'src/compute_provider_ggml_cuda/ggml_cuda_provider.cc',provider),('provider-test',R/'tests/compute_provider_ggml_cuda/provider_test.cc',test)]:
 rows.append(dict(tag=tag,source=b.identity(source),command=b.host_command(recipe['command'],source,tag,O),original_recipe=recipe.get('recipe',str(provider_recipe))))
c.save(O/'plan.json',dict(base=b.identity(basepath),compile=rows,reused_native_retirement_test=retirement['object'],CXX=2,NVCC=0,links=1,GPU=0))
def compile(row):
 c.execute(row['tag']+'-compile',row['command'],env,O)
 dep=O/(row['tag']+'-deps.json');d=c.read(dep)['Data'];record=dict(row,object=b.identity(O/(row['tag']+'.obj')),source_dependencies=b.identity(dep),dependencies=[b.identity(p)for p in dict.fromkeys([d['Source'],*d['Includes']])]);assert h.same_identity(row['source']);c.save(O/(row['tag']+'-identity.json'),record);return record
with concurrent.futures.ThreadPoolExecutor(max_workers=2)as pool:built=list(pool.map(compile,rows))
old=provider['object'];new=built[0]['object'];link=[new['path']if c.key(x)==c.key(old['path'])else x for x in base['command']if not x.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:'))]
extra=[built[1]['object'],retirement['object']]
for row in extra:
 assert h.same_identity(row)
 assert not any(c.key(x)==c.key(row['path'])for x in link);link.insert(1,row['path'])
image=O/'retirement-tests.exe';link+=['/OUT:'+str(image),'/MAP:'+str(image.with_suffix('.map')),'/IMPLIB:'+str(image.with_suffix('.lib'))];lookup={c.key(x['path']):x for x in [*base['inputs'],new,*extra]};inputs=[lookup[c.key(x)]for x in link if Path(x).is_absolute()and Path(x).suffix.lower()in('.obj','.lib')]
c.save(O/'link-plan.json',dict(command=link,inputs=inputs,base=b.identity(basepath),replacements=[dict(before=old,after=new)],extras=extra));c.execute('link',link,env,O)
for row in inputs:assert h.same_identity(row)
c.save(O/'image.json',b.identity(image));c.save(O/'summary.json',dict(passed=True,CXX=2,NVCC=0,links=1,GPU=0,image=b.identity(image),scope='one provider implementation owner, one adjacent existing test owner; reuse actual native retirement test'))
print('RETIREMENT_HOST_BUILD_LINK_GREEN')
