// Scratch-only mathematical candidate. No model/provider policy is changed.
#include "hyle/graph/cuda.h"
#include "hyle/graph/providers/ggml_cuda.h"
#include "hyle/compute/storage_owner.h"
#include "src/graph/plan_state.h"
#include "src/graph_provider_ggml_cuda/constant_expressions.h"
#include "fixture_paths.h"

#include <algorithm>
#include <array>
#include <bit>
#include <cmath>
#include <cstdint>
#include <cstring>
#include <fstream>
#include <iostream>
#include <limits>
#include <span>
#include <stdexcept>
#include <string>
#include <string_view>
#include <vector>
#include <gtest/gtest.h>

namespace {
namespace c = hyle::compute;
namespace g = hyle::graph;
namespace m = hyle::mem;
using Type = c::DataType;
constexpr std::int64_t kInner = 2048, kMember = 16;
constexpr c::RoutePolicyId kPaired{0x48594c4547474355ULL, 5, 1};
constexpr std::uint64_t kConstantExpression = 0x4747435545585052ULL;

template<class T> T take(hyle::Result<T> result, std::string_view label) {
  if (!result) throw std::runtime_error(std::string(label) + ": " + std::string(result.error().message()));
  return static_cast<T &&>(*result);
}
void check(hyle::Status status, std::string_view label) {
  if (!status.ok()) throw std::runtime_error(std::string(label) + ": " + std::string(status.message()));
}
c::TensorDesc dense(Type type, std::initializer_list<std::int64_t> shape) {
  return take(c::TensorDesc::dense(type, std::span(shape.begin(), shape.size())), "dense");
}
std::uint16_t bf16(double value) {
  auto bits = std::bit_cast<std::uint32_t>(static_cast<float>(value));
  if ((bits & 0x7f800000U) == 0x7f800000U)
    return static_cast<std::uint16_t>((bits >> 16) | ((bits & 0x7fffffU) ? 1U : 0U));
  bits += 0x7fffU + ((bits >> 16) & 1U);
  return static_cast<std::uint16_t>(bits >> 16);
}
double decoded(std::uint16_t bits) {
  const unsigned exponent = (bits >> 7) & 255U, fraction = bits & 127U;
  const double sign = bits & 0x8000U ? -1. : 1.;
  if (exponent == 255U) return fraction ? std::numeric_limits<double>::quiet_NaN()
                                      : sign * std::numeric_limits<double>::infinity();
  return sign * (exponent ? std::ldexp(double(128U + fraction), int(exponent) - 134)
                         : std::ldexp(double(fraction), -133));
}
std::vector<std::uint16_t> load_weight(const char *path) {
  std::vector<std::uint16_t> result(static_cast<std::size_t>(kMember * kInner));
  std::ifstream input(path, std::ios::binary);
  input.read(reinterpret_cast<char *>(result.data()), static_cast<std::streamsize>(result.size() * sizeof(result[0])));
  if (!input || input.peek() != std::char_traits<char>::eof())
    throw std::runtime_error("cached weight range differs from the exact 65536B fixture");
  return result;
}
template<class T> c::ReadLease upload(const c::StorageOwner &owner, std::span<const T> values) {
  auto buffer = take(m::Buffer::create(owner.ref(), values.size_bytes(), 256), "input buffer");
  check(buffer.view().write(std::as_bytes(values)), "input upload");
  return take(owner.adopt_buffer(std::move(buffer)), "input ready lease");
}
template<class T> std::vector<T> read_values(c::ConstTensorView view) {
  const auto &desc = view.description();
  const auto count = take(desc.element_count(), "output elements");
  const auto extent = take(desc.required_bytes(), "output extent");
  std::vector<std::byte> physical(extent);
  check(view.storage().read(physical), "actual output D2H");
  std::vector<T> result(count);
  for (std::size_t i = 0; i < count; ++i) {
    std::size_t remainder = i, offset = 0;
    for (std::size_t axis = desc.rank(); axis != 0; --axis) {
      const auto width = static_cast<std::size_t>(desc.dimensions()[axis - 1]);
      offset += (remainder % width) * static_cast<std::size_t>(desc.byte_strides()[axis - 1]);
      remainder /= width;
    }
    if (offset > extent || sizeof(T) > extent - offset) throw std::runtime_error("strided output extent");
    std::memcpy(&result[i], physical.data() + offset, sizeof(T));
  }
  return result;
}

struct Math final {
  g::Graph graph;
  g::ValueId activation{}, joined{}, wide{};
  std::array<g::ValueId, 2> weight{}, projection{}, suffix{};
  std::array<g::NodeId, 2> matmul{};
  bool packed = false;
};
Math build(std::int64_t rows, bool packed) {
  Math result{.packed = packed}; auto builder = take(g::GraphBuilder::create(), "builder");
  result.activation = take(builder.input(dense(Type::kBFloat16, {rows, kInner})), "activation input");
  for (auto &weight : result.weight)
    weight = take(builder.constant(dense(Type::kBFloat16, {kMember, kInner})), "original physical weight constant");
  const auto transpose = take(c::View::permute(std::array<std::int32_t, 2>{1, 0}), "weight transpose");
  if (packed) {
    result.joined = take(builder.add(c::Concat{.axis = 0}, result.weight[0], result.weight[1]), "cold mathematical weight concat");
    const auto rhs = take(builder.add(transpose, result.joined), "packed transpose");
    result.wide = take(builder.add(c::MatMul{.accumulation_type = Type::kFloat32}, result.activation, rhs), "wide BF16 MatMul");
    for (std::size_t part = 0; part < 2; ++part)
      result.projection[part] = take(builder.add(take(c::View::slice(1, static_cast<std::int64_t>(part) * kMember, kMember), "column View"), result.wide), "projection View");
    // One caller-owned dense root authorizes both readonly public aliases.
    // This auxiliary publication adds no mathematical operation or payload.
    check(builder.publish(result.wide), "publish wide owner");
  } else {
    for (std::size_t part = 0; part < 2; ++part) {
      const auto rhs = take(builder.add(transpose, result.weight[part]), "original transpose");
      result.projection[part] = take(builder.add(c::MatMul{.accumulation_type = Type::kFloat32}, result.activation, rhs), "original BF16 MatMul");
    }
  }
  // Preserve the two original BF16 MatMul storepoints. These are the real
  // first a/b consumer kinds, exposing any strided suffix materialization.
  result.suffix[0] = take(builder.add(c::Cast{Type::kFloat32}, result.projection[0]), "a F32 cast");
  const auto b_shape = take(c::TensorShape::create(std::array<std::int64_t, 4>{1, rows, kMember, 1}), "b shape");
  const auto b = take(builder.add(take(c::View::reshape(b_shape), "b metadata reshape"), result.projection[1]), "b reshape");
  result.suffix[1] = take(builder.add(c::Unary{c::UnaryKind::kSigmoid}, b), "b BF16 sigmoid");
  for (const auto value : result.projection) check(builder.publish(value), "publish raw projection");
  for (const auto value : result.suffix) check(builder.publish(value), "publish actual suffix");
  result.graph = take(std::move(builder).finish(), "finish math");
  if (packed) result.matmul[0] = take(result.graph.producer(result.wide), "wide MatMul node");
  else for (std::size_t part = 0; part < 2; ++part)
    result.matmul[part] = take(result.graph.producer(result.projection[part]), "original MatMul node");
  return result;
}

struct Observed final {
  std::array<std::vector<std::uint16_t>, 2> raw;
  std::vector<float> a;
  std::vector<std::uint16_t> beta;
};
void bound(std::span<const std::uint16_t> actual, std::span<const std::uint16_t> input,
           std::span<const std::uint16_t> weights, std::int64_t rows) {
  const double u = std::ldexp(1., -24), terms = double(2 * kInner + 32);
  const double gamma = terms * u / (1. - terms * u);
  ASSERT_EQ(actual.size(), static_cast<std::size_t>(rows * kMember));
  for (std::int64_t row = 0; row < rows; ++row)
    for (std::int64_t column = 0; column < kMember; ++column) {
      double sum = 0., magnitude = 0.;
      for (std::int64_t inner = 0; inner < kInner; ++inner) {
        const auto product = decoded(input[static_cast<std::size_t>(row * kInner + inner)]) *
                             decoded(weights[static_cast<std::size_t>(column * kInner + inner)]);
        sum += product; magnitude += std::abs(product);
      }
      const auto value = decoded(actual[static_cast<std::size_t>(row * kMember + column)]);
      ASSERT_TRUE(std::isfinite(sum)); ASSERT_TRUE(std::isfinite(value));
      const auto error = gamma * magnitude + double(kInner) * std::numeric_limits<float>::denorm_min();
      EXPECT_GE(value, decoded(bf16(sum - error))) << row << ":" << column;
      EXPECT_LE(value, decoded(bf16(sum + error))) << row << ":" << column;
    }
}

std::size_t cold_proof(const g::CompiledGraph &program, bool packed,
                      const std::array<std::vector<std::uint16_t>, 2> &weights) {
  const auto *state = g::detail::ExecutableAccess::state(program.executable);
  std::size_t matched = 0;
  for (const auto &owner : state->constant_artifacts) {
    if (owner->key.packing.format != kConstantExpression) continue;
    EXPECT_EQ(owner->key.packing.configuration, 2U);
    const auto *expression = static_cast<const g::ggml_cuda::constant_expressions::PreparedExpression *>(owner->payload.state);
    for (const auto view : expression->outputs) {
      if (view.description() != dense(Type::kBFloat16, {2 * kMember, kInner})) continue;
      const auto bytes = read_values<std::uint16_t>(view);
      std::vector<std::uint16_t> expected = weights[0];
      expected.insert(expected.end(), weights[1].begin(), weights[1].end());
      EXPECT_EQ(bytes, expected); // Actual selected cold device payload, not a host replacement.
      EXPECT_EQ(owner->packed_bytes, expected.size() * sizeof(expected[0])); ++matched;
    }
  }
  EXPECT_EQ(matched, packed ? 1U : 0U);
  return matched;
}

Observed run(Math &math, std::int64_t rows, c::Context &context, c::Queue &queue,
             const c::StorageOwner &owner, const c::ReadLease &activation,
             const std::array<c::ReadLease, 2> &weight_leases,
             const std::array<std::vector<std::uint16_t>, 2> &weight_values) {
  std::vector<g::ConstantBinding> constants;
  for (std::size_t part = 0; part < 2; ++part)
    constants.push_back({.value = math.weight[part],
      .tensor = take(weight_leases[part].tensor(dense(Type::kBFloat16, {kMember, kInner})), "original weight ready tensor"),
      .owner = owner, .lease = weight_leases[part]});
  auto program = take(g::cuda::compile(math.graph, context, owner, {.constants = constants}), "default Graph compile");
  const auto cold = cold_proof(program, math.packed, weight_values);
  std::size_t paired = 0, dispatches = 0, materializing_views = 0;
  const auto *state = g::detail::ExecutableAccess::state(program.executable);
  for (const auto &step : state->steps)
    materializing_views += step.kind == g::detail::PlanStepKind::kView && step.materializes;
  for (std::size_t i = 0; i < program.report.step_count(); ++i) {
    const auto step = take(program.report.step(i), "step report");
    paired += step.policy == kPaired; dispatches += step.dispatch_count;
    std::cout << "SMALL_PROJECTION_STEP rows=" << rows << " packed=" << math.packed
              << " step=" << i << " provider=" << step.provider.name
              << " nodes=" << step.node_count << " dispatches=" << step.dispatch_count
              << " copies=" << step.copy_bytes << " packed_bytes=" << step.packed_constant_bytes << '\n';
  }
  EXPECT_EQ(paired, !math.packed && rows == 1 ? 1U : 0U);
  std::vector<c::LeasePool> pools;
  auto invocation = take(program.executable.create_invocation(), "Invocation");
  check(invocation.bind(math.activation, dense(Type::kBFloat16, {rows, kInner}), activation), "bind activation");
  const auto output = [&](g::ValueId value) {
    const auto desc = take(math.graph.value_description(value), "output description");
    const auto bytes = take(desc.required_bytes(), "output bytes");
    pools.push_back(take(c::LeasePool::create(owner.ref(), bytes, {.max_blocks = 1, .backing_alignment = 256}), "output pool"));
    check(invocation.bind(value, desc, take(pools.back().allocate(bytes, 256), "output writer")), "bind actual output writer");
  };
  if (math.packed) output(math.wide); else for (const auto value : math.projection) output(value);
  for (const auto value : math.suffix) output(value);
  check(g::cuda::prepare_replay(invocation, queue, {.mode = g::ReplayMode::kRequireCapture}), "ready capture");
  const auto first = invocation.replay_report();
  EXPECT_EQ(invocation.replay_route(), g::ReplayRoute::kCaptured);
  EXPECT_GE(first.recorded_capture_range_count, 1U);
  auto done = take(invocation.submit(queue), "original submit"); check(done.wait(), "original completion"); done = {};
  Observed result;
  std::size_t strided = 0;
  for (std::size_t part = 0; part < 2; ++part) {
    auto graph_output = take(invocation.result(math.projection[part]), "raw original BF16 result");
    const auto tensor = take(graph_output.tensor(), "raw original BF16 tensor");
    strided += !tensor.description().is_dense();
    result.raw[part] = read_values<std::uint16_t>(tensor);
  }
  { auto graph_output = take(invocation.result(math.suffix[0]), "a cast result");
    result.a = read_values<float>(take(graph_output.tensor(), "a cast tensor")); }
  { auto graph_output = take(invocation.result(math.suffix[1]), "b sigmoid result");
    result.beta = read_values<std::uint16_t>(take(graph_output.tensor(), "b sigmoid tensor")); }
  for (std::size_t i = 0; i < result.a.size(); ++i) {
    EXPECT_EQ(double(result.a[i]), decoded(result.raw[0][i]));
    const double sigmoid = 1. / (1. + std::exp(-decoded(result.raw[1][i])));
    EXPECT_NEAR(decoded(result.beta[i]), sigmoid, 0.004);
  }
  check(g::cuda::prepare_replay(invocation, queue, {.mode = g::ReplayMode::kRequireCapture}), "same tuple capture reuse query");
  const auto second = invocation.replay_report();
  EXPECT_EQ(second.recorded_capture_range_count, 0U); EXPECT_GE(second.reused_capture_range_count, 1U);
  std::cout << "SMALL_PROJECTION {\"rows\":" << rows << ",\"packed\":" << math.packed
            << ",\"cold_concat_payloads\":" << cold << ",\"paired_steps\":" << paired
            << ",\"graph_steps\":" << program.report.step_count() << ",\"declared_dispatches\":" << dispatches
            << ",\"materializing_view_steps\":" << materializing_views << ",\"strided_raw_outputs\":" << strided
            << ",\"graph_copy_bytes\":" << program.report.copy_bytes()
            << ",\"packed_constant_bytes\":" << program.report.packed_constant_bytes()
            << ",\"workspace_bytes\":" << program.report.workspace_bytes()
            << ",\"recorded\":" << first.recorded_capture_range_count
            << ",\"reused_on_reprepare\":" << second.reused_capture_range_count << "}\n";
  return result;
}

void exercise(std::int64_t rows) {
  const std::array weights{load_weight(small_projection_fixture::kAPath), load_weight(small_projection_fixture::kBPath)};
  std::vector<std::uint16_t> input(static_cast<std::size_t>(rows * kInner));
  for (std::size_t i = 0; i < input.size(); ++i)
    input[i] = bf16(double(static_cast<int>((i * 17 + i / static_cast<std::size_t>(kInner)) % 127) - 63) / 32.);
  auto context = take(g::cuda::create_context(), "default original CUDA Context");
  auto owner = take(c::StorageOwner::adopt(context, take(c::cuda::MemoryResource::create(context, c::cuda::MemoryKind::kDevice), "device resource")), "storage owner");
  auto queue = take(context.create_queue(), "original queue");
  const auto activation = upload<std::uint16_t>(owner, input);
  const std::array weight_leases{upload<std::uint16_t>(owner, weights[0]), upload<std::uint16_t>(owner, weights[1])};
  auto original = build(rows, false), candidate = build(rows, true);
  const auto before = run(original, rows, context, queue, owner, activation, weight_leases, weights);
  ASSERT_FALSE(::testing::Test::HasFatalFailure());
  const auto after = run(candidate, rows, context, queue, owner, activation, weight_leases, weights);
  ASSERT_FALSE(::testing::Test::HasFatalFailure());
  std::size_t bit_differences = 0; double maximum_difference = 0.;
  for (std::size_t part = 0; part < 2; ++part) {
    bound(before.raw[part], input, weights[part], rows); bound(after.raw[part], input, weights[part], rows);
    ASSERT_EQ(before.raw[part].size(), after.raw[part].size());
    for (std::size_t i = 0; i < before.raw[part].size(); ++i) {
      bit_differences += before.raw[part][i] != after.raw[part][i];
      maximum_difference = std::max(maximum_difference, std::abs(decoded(before.raw[part][i]) - decoded(after.raw[part][i])));
    }
  }
  std::cout << "SMALL_PROJECTION_COMPARE {\"rows\":" << rows << ",\"raw_bf16_differences\":" << bit_differences
            << ",\"max_abs_difference\":" << maximum_difference << "}\n";
}
TEST(SmallProjectionCuda, CachedABM1ComparesDefaultPairedWithColdN32) { exercise(1); }
TEST(SmallProjectionCuda, CachedABM2ComparesDefaultMatricesWithColdN32) { exercise(2); }
TEST(SmallProjectionCuda, CachedABPrefill154ComparesDefaultMatricesWithColdN32) { exercise(154); }
} // namespace
