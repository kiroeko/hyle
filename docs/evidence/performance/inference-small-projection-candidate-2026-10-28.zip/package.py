"""Offline only. Run after the parent timing window is quiet.

Package the finite candidate, its two genuine failures, and existing receipts.
No compilation, model execution, payload inclusion, or SDK/binary hashing.
"""
from pathlib import Path
import difflib
import hashlib
import json
import sys
import zipfile
import xml.etree.ElementTree as ET

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = W.parents[1]
D = R / 'docs/evidence/performance'
NAME = 'inference-small-projection-candidate-2026-10-28'
SUMMARY = W / 'summary-1793121039771158900.json'
ALLOWED = {'.py', '.json', '.cc', '.h', '.log', '.xml', '.diff', '.tsv'}
FORBIDDEN = {'.obj', '.exe', '.pdb', '.lib', '.exp', '.dll', '.bf16', '.gguf', '.safetensors', '.bin'}


def read(p):
    return json.loads(Path(p).read_text(encoding='utf-8-sig'))


def pin(p):
    p = Path(p).resolve()
    data = p.read_bytes()
    return {'path': str(p), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}


def verify_small(expected):
    p = Path(expected['path'])
    assert p.suffix.lower() not in FORBIDDEN, p
    actual = pin(p)
    assert (actual['bytes'], actual['sha256']) == (expected['bytes'], expected['sha256']), p
    return actual


def save_new(p, value):
    p = Path(p)
    p.parent.mkdir(parents=True, exist_ok=True)
    with p.open('x', encoding='utf-8', newline='\n') as f:
        json.dump(value, f, indent=2)
        f.write('\n')


def same_pin(a, b):
    return (a['path'].replace('/', '\\').casefold(), a['bytes'], a['sha256']) == (
        b['path'].replace('/', '\\').casefold(), b['bytes'], b['sha256'])


def main():
    out_json, out_zip = D / (NAME + '.json'), D / (NAME + '.zip')
    assert not out_json.exists() and not out_zip.exists(), 'Do not overwrite an evidence attempt'
    plan = read(W / 'plan3.json')
    ready = read(W / 'ready3.json')
    summary = read(SUMMARY)
    analysis = read(W / 'offline-analysis.json')
    assert summary['status'] == 'PASS_FINITE_CANDIDATE'
    assert summary['image'] == ready['image'] and summary['process']['pid'] == 45564
    assert summary['process']['exit'] == 0
    verify_small(ready['plan'])
    verify_small(ready['compiled']['source'])
    verify_small(ready['compiled']['command'])
    verify_small(ready['compiled']['dependencies'])
    actual_deps = read(verify_small(ready['compiled']['actual_dependencies'])['path'])
    verify_small(ready['inputs'])
    verify_small(ready['command'])
    verify_small(ready['runtime'])
    verify_small(plan['snapshot'])
    verify_small(plan['headers'])
    verify_small(plan['fixture'])
    assert plan['snapshot']['sha256'] == '98548156fc371d583bc949858f08d957202e29d854f36cdd3f5b096926753147'
    # Verify frozen project source dependencies only. External SDK entries remain
    # exact recorded identities; do not rescan/hash the inherited toolchain.
    local_deps = []
    for dep in actual_deps:
        p = Path(dep['path'])
        if p.is_relative_to(W):
            verify_small(dep)
            local_deps.append(dep)
    old_inputs = read(verify_small(plan['original_inputs'])['path'])
    inputs = read(ready['inputs']['path'])
    assert len(old_inputs) == 228 and len(inputs) == 229
    assert all(same_pin(a, b) for a, b in zip(old_inputs, inputs[:228]))
    assert same_pin(inputs[-1], ready['compiled']['object'])
    processes = {
        'compile1': read(W / 'logs/candidate/process.json'),
        'compile2': read(W / 'logs/candidate2/process.json'),
        'compile3': read(W / 'logs/candidate3/process.json'),
        'link2': read(W / 'link2/process.json'),
        'link3': read(W / 'link3/process.json'),
        'run2': read(W / 'run2/process.json'),
        'run3': read(W / 'run3/process.json'),
    }
    assert processes['compile1']['pid'] == 40552 and processes['compile1']['exit'] == 2
    assert processes['run2']['pid'] == 3328 and processes['run2']['exit'] == 1
    for name in ('compile2', 'compile3', 'link2', 'link3', 'run3'):
        assert processes[name]['exit'] == 0, name
    xml = ET.parse(W / 'run3/results.xml').getroot()
    assert (int(xml.attrib['tests']), int(xml.attrib['failures']), int(xml.attrib.get('disabled', 0))) == (3, 0, 0)
    assert not xml.findall('.//skipped')
    assert all(x['raw_bf16_differences'] == 0 for x in summary['comparisons'])
    stdout = (W / 'run3/stdout.log').read_text(encoding='utf-8-sig')
    steps = []
    import re
    for m in re.finditer(r'^SMALL_PROJECTION_STEP rows=(\d+) packed=(\d+) step=(\d+) provider=(.*?) nodes=(\d+) dispatches=(\d+) copies=(\d+) packed_bytes=(\d+)$', stdout, re.M):
        rows, packed, step, provider, nodes, dispatches, copies, packed_bytes = m.groups()
        steps.append(dict(rows=int(rows), packed=int(packed), step=int(step), provider=provider,
                          nodes=int(nodes), dispatches=int(dispatches), copies=int(copies), packed_bytes=int(packed_bytes)))
    assert len(steps) == 44
    assert [s['provider'] for s in steps if s['rows'] == 2 and s['packed'] == 0 and s['step'] in (1, 3)] == ['cublasLt', 'cublasLt']
    refinements = []
    for left, right in [('source/small_projection_test.cc', 'source2/small_projection_test.cc'),
                        ('source2/small_projection_test.cc', 'source3/small_projection_test.cc')]:
        a, b = W / left, W / right
        refinements.append({'before': pin(a), 'after': pin(b), 'diff': ''.join(difflib.unified_diff(
            a.read_text().splitlines(True), b.read_text().splitlines(True), fromfile=left, tofile=right))})
    result = {
        'status': 'FINITE_COMPONENT_PASS_NO_PERFORMANCE_CLAIM',
        'date': '2026-10-28',
        'scope': 'Scratch-only generic ConstantConcat(axis0)+MatMul+two readonly Views versus original two MatMuls; default current native route, no product changes.',
        'source': plan['snapshot'], 'image': ready['image'], 'ready': pin(W / 'ready3.json'),
        'baseline': {'ready': plan['baseline_ready'], 'image': plan['image_as_reference'], 'inputs': plan['original_inputs'],
                     'inherited_objects': 228, 'candidate_objects': 229, 'delta': 'Append exactly one new candidate test OBJ; all 228 inherited input pins unchanged.'},
        'actual_counts': {'host_CXX_attempts': 3, 'host_CXX_success': 2, 'compiler_failures': 1,
                          'successful_links': 2, 'GPU_component_processes': 2, 'pre_submit_setup_failures': 1,
                          'successful_component_processes': 1, 'successful_GTests_same_image': 3,
                          'successful_Graph_submissions': 6, 'product_edits': 0, 'Model_processes': 0,
                          'SDK_builds': 0, 'NVCC': 0, 'downloads': 0},
        'failures_preserved': [
            {'attempt': 1, 'process': processes['compile1'], 'classification': 'Scratch Result<ReplayReport> direct-field API misuse; no successful compile or run.'},
            {'attempt': 2, 'process': processes['run2'], 'classification': 'Owned input bind rejected: Invocation factory lacked resources; before any Graph submission; M2/T154 skipped. Not a numerical failure.'}],
        'corrections': ['Check and unwrap both replay_report Results.', 'Prepare original owned resources through factory.resources; retain original permission checks.', 'Read all results and release GraphOutput handles before metadata-only reprepare.'],
        'fixture': read(W / 'fixture-manifest.json'),
        'observations': summary['observations'], 'numerical_comparisons': summary['comparisons'],
        'analysis': analysis,
        'processes': processes,
        'reproduction': {'helper': pin(W / 'build.py'), 'plan': pin(W / 'plan3.json'), 'runtime': ready['runtime'],
                         'compiled_actual_dependencies': ready['compiled']['actual_dependencies'],
                         'local_dependencies_verified': len(local_deps), 'external_dependency_and_binary_pins': 'Recorded receipts only; not recopied or rehashed by this package.',
                         'filter': plan['selected_filter'], 'fixture_payload_in_zip': False},
        'limits': ['No actual kernel timing/count, TPS, whole-model token/quality result or peak VRAM measurement.',
                   'The current dense-BF16 Model operation attributes agree, but this leaf does not certify whole-model routing or identify old N16 trace kernels.',
                   'Graph dispatches denote backend episodes; zero Graph copies/Views do not exclude provider-private materialization.',
                   'Finite deterministic BF16 X and cached original layer0 weights; zero observed raw differences is not a bitwise contract.',
                   'Packed weights add 128KiB per family/layer while original weights remain; 18 layers imply 2.25MiB logical payload only; cross-family sharing unverified.']
    }
    files = {}
    def add(p, name=None):
        p = Path(p)
        assert p.is_file() and p.suffix.lower() in ALLOWED and p.suffix.lower() not in FORBIDDEN, p
        name = name or str(p.relative_to(W)).replace('\\', '/')
        assert '..' not in Path(name).parts and name not in files, name
        files[name] = p
    # Bounded W-only traversal, never SDK/model/payload trees.
    for p in W.iterdir():
        if p.is_file() and p.suffix.lower() in ALLOWED and p.name not in ('package-receipt.json',):
            add(p)
    for directory in ('pre-cxx1', 'attempt1', 'attempt2', 'source', 'source2', 'source3', 'headers',
                      'logs', 'compile', 'compile2', 'compile3', 'link2', 'link3', 'run2', 'run3'):
        root = W / directory
        if root.exists():
            for p in sorted(root.rglob('*')):
                if p.is_file() and p.suffix.lower() in ALLOWED:
                    add(p)
    for name, key in [('reference/baseline-ready.json', 'baseline_ready'), ('reference/baseline-inputs.json', 'original_inputs')]:
        add(Path(plan[key]['path']), name)
    generated = {
        'package-result.json': (json.dumps(result, indent=2) + '\n').encode(),
        'source-refinements.json': (json.dumps(refinements, indent=2) + '\n').encode(),
        'actual-step-routes.json': (json.dumps(steps, indent=2) + '\n').encode(),
    }
    manifest = []
    D.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(out_zip, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as z:
        for name, p in sorted(files.items()):
            data = p.read_bytes()
            z.writestr(name, data)
            manifest.append({'member': name, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
        for name, data in generated.items():
            z.writestr(name, data)
            manifest.append({'member': name, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
        z.writestr('archive-members.json', (json.dumps(manifest, indent=2) + '\n').encode())
    with zipfile.ZipFile(out_zip) as z:
        assert len(z.namelist()) == len(manifest) + 1
        for row in manifest:
            data = z.read(row['member'])
            assert len(data) == row['bytes'] and hashlib.sha256(data).hexdigest() == row['sha256'], row['member']
        assert z.testzip() is None
    compact_rows = []
    for rows in (1, 2, 154):
        original, packed = [x for x in summary['observations'] if x['rows'] == rows]
        compact_rows.append({'rows': rows,
            'declared_dispatches_original_candidate': [original['declared_dispatches'], packed['declared_dispatches']],
            'workspace_bytes_original_candidate': [original['workspace_bytes'], packed['workspace_bytes']],
            'original_paired_steps': original['paired_steps'],
            'candidate_cold_packed_bytes': packed['packed_constant_bytes'],
            'candidate_strided_raw_outputs': packed['strided_raw_outputs'],
            'raw_BF16_bit_differences': next(x['raw_bf16_differences'] for x in summary['comparisons'] if x['rows'] == rows)})
    brief = {
        'status': result['status'], 'date': result['date'], 'scope': result['scope'],
        'source': result['source'], 'image': result['image'], 'ready': result['ready'],
        'baseline': result['baseline'], 'actual_counts': result['actual_counts'],
        'failures': [{'PID': 40552, 'exit': 2, 'kind': 'Scratch ReplayReport Result misuse at compile; preserved.'},
                     {'PID': 3328, 'exit': 1, 'kind': 'Factory owned-resource setup rejection before Graph submit; M2/T154 skipped; preserved.'}],
        'final_process': processes['run3'], 'finite_rows': compact_rows,
        'routing': ['M1 original: ggml-cuda paired; packed: cublasLt.',
                    'M2 and T154 original: two cublasLt MatMuls; packed: one cublasLt.',
                    'Cast remains ggml-cuda; Sigmoid changes ggml-cuda to hyle-cuda.'],
        'cold_proof': 'Actual retained ConstantArtifact contains exact cached a||b BF16 bits; one 131072-byte packed payload per candidate family/layer. Originals remain; 18 layers imply 2.25MiB logical extra payload, not VRAM peak.',
        'fixture_manifest': pin(W / 'fixture-manifest.json'),
        'cache_read_bytes': 131072, 'fixture_payload_included': False,
        'numerical_contract': 'Both raw arms independently meet FP64/F32-reduction-to-BF16 bound; a cast is exact; finite b sigmoid tolerance 0.004. No general bitwise or nonfinite claim.',
        'capture': 'Each arm recorded one range and same-tuple metadata-only reprepare reused one without recording; six Graph submissions total.',
        'materialization': 'All Graph copy_bytes/materializing-View counts are zero; candidate aliases are strided. Provider-private copies/kernels are not measured by these counters.',
        'model_boundary': 'Dense-BF16 Stored MatMul{} defaults to F32, matching leaf explicit F32; no explicit Model MatMulPolicy found. Whole finite Model topology/routing and old N16 kernel identity/performance are not certified.',
        'decision': result['analysis']['decision'],
        'reproduction': {'helper': pin(W / 'build.py'), 'plan': pin(W / 'plan3.json'),
                         'actual_dependencies': ready['compiled']['actual_dependencies'],
                         'local_source_dependencies_verified': len(local_deps),
                         'external_and_binary_pins': 'Recorded in original compile/link receipts; not recopied or rehashed by packaging.'},
        'limits': result['limits'],
        'archive': {**pin(out_zip), 'members': len(manifest) + 1,
                    'readback': 'Every member byte count/SHA256 and ZIP CRC verified; full routes/analysis/failures/refinements inside.'}
    }
    save_new(out_json, brief)
    receipt = {'status': 'PACKAGED_READBACK_VERIFIED', 'json': pin(out_json), 'zip': pin(out_zip),
               'member_count': len(manifest) + 1, 'new_builds_or_runs': 0}
    save_new(W / 'package-receipt.json', receipt)
    print(json.dumps(receipt, indent=2))


if __name__ == '__main__':
    main()
