"""One scratch candidate TU and one retained component link; no product edit.

Each action is explicit. prepare reads only the two cached64KiB weight ranges,
freezes the small test/header closure, and emits commands. It runs no compiler,
linker, GPU work, dependency build or download.
"""
from pathlib import Path
import ast
import hashlib
import importlib.util
import json
import os
import re
import sys
import time
import traceback
import xml.etree.ElementTree as ET

sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent; R=W.parents[1]
BASE=R/'.scratch/inference-indexed-store-20261028'
READY=BASE/'ready-component.json'
SOURCE=W/'small_projection_test.cc'
MANIFEST=R/'.scratch/qwen35-unsloth-mtp-20261024/geometry-v2-check/original/weights.tsv'
FILTER='SmallProjectionCuda.*'

def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def save(p,v):
    p=Path(p);p.parent.mkdir(parents=True,exist_ok=True)
    with p.open('x',encoding='utf-8') as f:json.dump(v,f,indent=2);f.write('\n')
def pin(p):
    p=Path(p).resolve();h=hashlib.sha256()
    with p.open('rb') as f:
        while data:=f.read(1<<20):h.update(data)
    return dict(path=str(p),bytes=p.stat().st_size,sha256=h.hexdigest())
def exact(p):
    now=pin(p['path']);assert (now['bytes'],now['sha256'])==(p['bytes'],p['sha256']),p['path']
def key(p):return str(p).replace('/','\\').casefold()
def project(p):
    p=Path(p).resolve();parts=p.relative_to(R).parts if p.is_relative_to(R) else ()
    return bool(parts) and parts[0] in ('src','include','tests','engine')
def canonical(p):
    p=Path(p).resolve()
    if p.is_relative_to(BASE/'source'):return R/p.relative_to(BASE/'source')
    return p
def tokens(text):return re.sub(r'\s+','',re.sub(r'//[^\n]*|/\*.*?\*/','',text,flags=re.S))

def prepare():
    ready=read(READY);inputs=read(ready['inputs']['path'])
    assert len(inputs)==228 and ready['image']['sha256'].startswith('1d7ece3d')
    # One new GTest TU only: current batch+slots tests and gtest_main remain.
    assert not any('small-projection' in row['path'].casefold() for row in inputs)
    roles=[]
    for part in ('a','b'):
        name='model.language_model.layers.0.linear_attn.in_proj_'+part+'.weight'
        fields=next(line.split('\t') for line in MANIFEST.read_text().splitlines() if line.startswith(name+'\t'))
        assert fields[1:5]==['BF16','2','16','2048']
        source=Path(fields[5].strip('"'));offset,size=map(int,fields[6:8]);assert size==65536
        with source.open('rb') as f:f.seek(offset);payload=f.read(size)
        assert len(payload)==size
        target=W/'payload'/(part+'.bf16');target.parent.mkdir(parents=True,exist_ok=True)
        with target.open('xb') as f:f.write(payload)
        roles.append(dict(role=name,source_file=str(source),source_file_bytes=source.stat().st_size,
                          offset=offset,bytes=size,sha256=hashlib.sha256(payload).hexdigest(),snapshot=pin(target)))
    fixture=W/'fixture_paths.h'
    fixture.write_text('#pragma once\nnamespace small_projection_fixture {\n'+''.join(
        'inline constexpr char k'+p.upper()+'Path[] = R"('+str(W/'payload'/(p+'.bf16'))+')";\n' for p in ('a','b'))+'}\n',encoding='utf-8')
    save(W/'fixture-manifest.json',dict(source_manifest=pin(MANIFEST),roles=roles,
        logical_shapes={'a':[16,2048],'b':[16,2048],'group':[32,2048]},actual_cache_bytes_read=131072,
        downloads=0,activation='Deterministic finite BF16 carrier; M154 is the actual production prefill shape, not a retained model hidden activation.'))
    # Preserve actual current recipes, not a guessed /D or link configuration.
    old=ready['compiled']['slots-test'];recipe=read(old['command']['path'])['command']
    project_files=set()
    for name in ('slots-test','ggml-region','resources'):
        dep=read(ready['compiled'][name]['dependencies']['path'])['Data']
        project_files.update(canonical(p) for p in dep['Includes'] if project(canonical(p)))
    include_roots=[R/'include',R,R/'src/compute',R/'src/graph',R/'src/compute_provider_ggml_cuda']
    todo=[SOURCE,*project_files]
    while todo:
        p=todo.pop()
        for inc in re.findall(r'^\s*#\s*include\s*"([^\"]+)"',p.read_text(encoding='utf-8-sig'),re.M):
            found=next((q.resolve() for root in (p.parent,*include_roots) if (q:=root/inc).is_file()),None)
            if found and project(found) and found not in project_files:project_files.add(found);todo.append(found)
    frozen=[]
    for p in sorted(project_files):
        target=W/'headers'/p.relative_to(R);target.parent.mkdir(parents=True,exist_ok=True)
        with target.open('xb') as f:f.write(p.read_bytes())
        frozen.append(dict(original=pin(p),snapshot=pin(target)))
    snapshot=W/'source';snapshot.mkdir()
    for p in (SOURCE,fixture):
        target=snapshot/p.name
        with target.open('xb') as f:f.write(p.read_bytes())
        frozen.append(dict(original=pin(p),snapshot=pin(target)))
    save(W/'source-freeze.json',frozen)
    out=W/'compile/candidate';new=[recipe[0]]
    new+=['/I'+str(p) for p in (snapshot,W/'headers/include',W/'headers',W/'headers/src/compute',W/'headers/src/graph')]
    for i,arg in enumerate(recipe[1:],1):
        if recipe[i-1].casefold()=='/sourcedependencies':arg=str(out/'dependencies.json')
        elif arg.casefold().startswith('/fo'):arg='/Fo'+str(out/'unit.obj')
        elif arg.casefold().startswith('/fd'):arg='/Fd'+str(out/'unit.pdb')
        elif arg.casefold().endswith(('.cc','.cpp','.cxx')):arg=str(snapshot/SOURCE.name)
        elif arg.casefold().startswith(('/i','/external:i')):
            prefix='/external:I' if arg.casefold().startswith('/external:i') else '/I'
            directory=canonical(arg[len(prefix):])
            if project(directory) or directory==R:arg=prefix+str(W/'headers'/directory.relative_to(R))
        new.append(arg)
    save(W/'compile-command.json',dict(command=new,cwd=str(R),timeout_seconds=240))
    image=W/'bin/small-projection-test.exe';link=[]
    for arg in read(ready['recipe']['path'])['command']:
        for option,suffix in (('/OUT:','.exe'),('/PDB:','.pdb'),('/IMPLIB:','.lib'),('/MAP:','.map')):
            if arg.upper().startswith(option):arg=option+str(image.with_suffix(suffix));break
        link.append(arg)
    link.append(str(out/'unit.obj'))
    for option,suffix in (('/PDB:','.pdb'),('/IMPLIB:','.lib')):
        if not any(arg.upper().startswith(option) for arg in link):link.append(option+str(image.with_suffix(suffix)))
    save(W/'link-command.json',dict(command=link,cwd=str(R),timeout_seconds=240))
    save(W/'environment.json',read(BASE/'environment.json'))
    save(W/'runtime-plan.json',dict(original=ready['runtime'],PATH=read(BASE/'environment.json')['PATH'],no_runtime_copy=True))
    save(W/'plan.json',dict(status='FROZEN_CANDIDATE_PREPARED_NOT_BUILT',baseline_ready=pin(READY),
        image_as_reference=ready['image'],original_inputs=ready['inputs'],original_link_recipe=ready['recipe'],
        original_CXX_recipe=old['command'],original_CXX_dependencies=old['dependencies'],
        source=pin(SOURCE),snapshot=pin(snapshot/SOURCE.name),headers=pin(W/'source-freeze.json'),
        fixture=pin(W/'fixture-manifest.json'),compile_recipe=pin(W/'compile-command.json'),link_recipe=pin(W/'link-command.json'),
        counts=dict(CXX=1,links=1,baseline_inputs=228,candidate_inputs=229,GTests=3,Graph_submissions=6,SDK=0,NVCC=0,downloads=0),
        selected_filter=FILTER,
        candidate='Generic original ConstantConcat(axis0)+MatMul+two readonly Views, no model/shape policy or product change.',
        original='Default original twoMatMul; M1 must actually select the existing equal-width paired path, M2 and M154 retain default matrices.',
        cold_proof='Inspect original retained ConstantArtifact format/configuration and its actual immutable packed tensor; compare every packed BF16 bit with the two cached original ranges.',
        numeric='Each raw BF16 output is independently bounded against FP64 sum/product magnitude and F32 reduction bound. Cross-N bitwise identity is reported, never required. Exact BF16->F32 a boundary and finite sigmoid tolerance remain.',
        route='Record actual provider/paired step and full raw output descriptions; Graph dispatch_count is episodes, not actual kernel count. Graph materializing View/copy facts exclude private ggml_cont.',
        limits=[
          'Deterministic X, real cached a/b weights: no whole-model acceptance, quality or hidden-activation claim.',
          'M2/prefill readonly split outputs are strided; real Cast/Sigmoid suffixes run, but private native materialization must not be inferred from Graph copy_bytes alone.',
          'One test row group/family; no proof of cross-family cache sharing. Existing artifact cache is family-local.',
          'N32 adds128KiB per layer when original weights remain; 18 layers2.25MiB logical payload, excluding transient/private storage. N2080 would146.25MiB and is not implemented.',
          'No timed loop, GPU event benchmark, TPS, VRAM-peak or expected speedup. Latest40 and old wide-Lt leaf are context only, not samples for this candidate.',
          'Candidate exposes an auxiliary dense wide result only to bind its true full writer; both public member views remain readonly aliases, never separate fabricated output writers.'
        ]))
    print('PREPARED one scratch CXX +one229inputlink +three finite Graph groups; zero compiler/link/GPU invocation')

def current_plan():
    return next(W/name for name in ('plan3.json','plan2.json','plan.json') if (W/name).exists())

def validate():
    p=read(current_plan())
    for field in ('baseline_ready','original_inputs','original_link_recipe','source','snapshot','headers','fixture','compile_recipe','link_recipe'):exact(p[field])
    for row in read(W/'source-freeze.json'):exact(row['snapshot'])
    for row in read(W/'fixture-manifest.json')['roles']:exact(row['snapshot'])
    return p

def execute(args,out,timeout):
    spec=importlib.util.spec_from_file_location('retained_indexed_execute',BASE/'build.py')
    tool=importlib.util.module_from_spec(spec);spec.loader.exec_module(tool)
    return tool.execute(args,out,timeout)

def compile_candidate():
    plan=validate();out=Path(plan.get('compile_directory',W/'compile/candidate'));out.mkdir(parents=True,exist_ok=False)
    logs=Path(plan.get('compile_logs',W/'logs/candidate'))
    cmd=read(plan['compile_recipe']['path']);proc=execute(cmd['command'],logs,cmd['timeout_seconds'])
    allowed={key(row['snapshot']['path']):row['snapshot'] for row in read(plan['headers']['path'])}
    actual=read(out/'dependencies.json')['Data'];rows=[]
    for p in dict.fromkeys([actual['Source'],*actual['Includes']]):
        if key(p) in allowed:exact(allowed[key(p)])
        elif project(canonical(p)) or Path(p).resolve().is_relative_to(W/'headers'):
            raise AssertionError(('project header escaped frozen overlay',p))
        rows.append(pin(p))
    save(out/'actual-dependencies.json',rows)
    save(out/'compiled.json',dict(source=pin(plan['snapshot']['path']),object=pin(out/'unit.obj'),
        process=proc,command=pin(logs/'command.json'),dependencies=pin(out/'dependencies.json'),
        actual_dependencies=pin(out/'actual-dependencies.json')))
    print('COMPILE_PASS candidate')

def link_candidate():
    plan=validate();out=Path(plan.get('compile_directory',W/'compile/candidate'))
    compiled=read(out/'compiled.json');exact(compiled['object'])
    rows=read(plan['original_inputs']['path'])+[compiled['object']];assert len(rows)==229
    for row in rows:exact(row)
    assert len({key(row['path']) for row in rows})==229
    image=Path(plan.get('image',W/'bin/small-projection-test.exe'));image.parent.mkdir(exist_ok=True);assert not image.exists()
    inputs=Path(plan.get('link_inputs',W/'link-inputs.json'));logs=Path(plan.get('link_directory',W/'link'))
    save(inputs,rows);cmd=read(plan['link_recipe']['path'])
    proc=execute(cmd['command'],logs,cmd['timeout_seconds'])
    save(Path(plan.get('ready',W/'ready.json')),dict(status='LINKED_NOT_RUN',image=pin(image),compiled=compiled,process=proc,
        inputs=pin(inputs),command=pin(logs/'command.json'),plan=pin(current_plan()),runtime=pin(W/'runtime-plan.json')))
    print('LINK_PASS candidate229')

def parse():
    plan=validate();ready=read(plan.get('ready',W/'ready.json'));run=Path(plan.get('run_directory',W/'run'))
    process=read(run/'process.json');assert process['exit']==0
    xml=ET.parse(run/'results.xml').getroot();assert int(xml.attrib['tests'])==3 and int(xml.attrib['failures'])==0
    assert not xml.findall('.//testcase/skipped')
    text=(run/'stdout.log').read_text(encoding='utf-8-sig')
    observations=[json.loads(s) for s in re.findall(r'^SMALL_PROJECTION (\{.*\})$',text,re.M)]
    comparisons=[json.loads(s) for s in re.findall(r'^SMALL_PROJECTION_COMPARE (\{.*\})$',text,re.M)]
    assert len(observations)==6 and len(comparisons)==3
    save(W/('summary-'+str(time.time_ns())+'.json'),dict(status='PASS_FINITE_CANDIDATE',process=process,
        image=ready['image'],observations=observations,comparisons=comparisons,xml=pin(run/'results.xml'),performance_claim=False))
    print('PASS three finite candidate groups; no speedup claim')

def run():
    plan=validate();ready=read(plan.get('ready',W/'ready.json'));exact(ready['image'])
    out=Path(plan.get('run_directory',W/'run'));assert not out.exists()
    execute([ready['image']['path'],'--gtest_filter='+FILTER,'--gtest_fail_fast','--gtest_output=xml:'+str(out/'results.xml')],out,180)
    parse()

if __name__=='__main__':
    try:
        action=sys.argv[1]
        if action=='prepare':prepare()
        elif action=='compile':compile_candidate()
        elif action=='link':link_candidate()
        elif action=='run':run()
        elif action=='parse':parse()
        else:raise ValueError(action)
    except BaseException:
        W.mkdir(parents=True,exist_ok=True)
        (W/('failure-'+sys.argv[1]+'-'+str(time.time_ns())+'.log')).write_text(traceback.format_exc(),encoding='utf-8')
        raise
