"""Current-closure adapter for the retained32-process protocol; explicit run only."""
from pathlib import Path
import argparse
import importlib.util
import os
import sys

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = W.parents[1]
PROTOCOL = R / '.scratch/mtp-performance-convergence-20261025/baseline/window.py'
PREVIOUS_ADAPTER = R / '.scratch/mtp-fixed-hidden-output-20261025/full-window.py'
READY = W / 'ready-current.json'
RUNTIME = W / 'runtime-current.json'
ENGINE = W / 'engine/summary.json'
PEER_SHA = '433e7051f4c36d0d9b2297dc378631546b7e3c44630cda0653cba2d1ec6bbe8e'
ORDER = (('single', 'timing'), ('single', 'memory'),
         ('two-turn', 'timing'), ('two-turn', 'memory'))
spec = importlib.util.spec_from_file_location('retained_current_full_window_protocol', PROTOCOL)
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)
m.D = W / 'full-window'
retained_analyze = m.analyze


def exact(row):
    actual = m.base.identity(row['path'])
    if (Path(actual['path']).resolve() != Path(row['path']).resolve() or
            actual['bytes'] != row['bytes'] or actual['sha256'] != row['sha256']):
        raise ValueError('pinned input changed: ' + str(row['path']))
    return actual


def engine_binding():
    engine = m.base.read(ENGINE)
    if engine['status'] != 'PASS' or engine['TUs'] != 4:
        raise ValueError('current formal entry/model/weights/report compilation is not complete')
    expected = {
        'entry': R / 'engine/main.cc',
        'model': R / 'engine/models/qwen35/main.cc',
        'weights': R / 'engine/models/qwen35/weights.cc',
        'report': R / 'engine/reporting/execution_report.cc'}
    result = {}
    for unit in engine['results']:
        key = unit['key']
        if key not in expected or Path(unit['source']['path']).resolve() != expected[key].resolve():
            raise ValueError('unexpected current engine source: ' + key)
        exact(unit['source'])
        exact(unit['object'])
        result[key] = {'source': unit['source'], 'object': unit['object'],
                       'command': unit['command'], 'actual_selfdeps': unit['current_project_dependency_manifest']}
    if set(result) != set(expected):
        raise ValueError('missing current formal engine translation unit')
    return {'summary': m.base.identity(ENGINE), 'translation_units': result}


def setup():
    if m.D.exists():
        raise FileExistsError(m.D)
    # Final root-produced files must exist. No provisional Ready, old image
    # fallback or sample directory is fabricated by this adapter.
    final = m.base.read(READY)
    image = final['image']
    exact(image)
    if final.get('instrumented', False):
        raise ValueError('formal window requires the uninstrumented final image')
    exact(final['link_inputs'])
    link_inputs = m.base.read(final['link_inputs']['path'])
    if not isinstance(link_inputs, list) or not link_inputs:
        raise ValueError('final link-input manifest must be a nonempty identity list')
    for row in link_inputs:
        exact(row)
    if 'link' in final and final['link'].get('exit') != 0:
        raise ValueError('final link did not succeed')
    engine = engine_binding()
    current_main = engine['translation_units']['model']['source']
    if 'canonical_main' in final and final['canonical_main'] != current_main:
        raise ValueError('final ready canonical main differs from actual current engine source')
    link_paths = {Path(row['path']).resolve() for row in link_inputs}
    if not all(Path(row['object']['path']).resolve() in link_paths
               for row in engine['translation_units'].values()):
        raise ValueError('final link omits a current formal engine TU')
    runtime = m.base.read(RUNTIME)
    runtime_pin = m.base.identity(RUNTIME)
    if final.get('runtime') != runtime_pin:
        raise ValueError('final ready must pin exact runtime-current.json')
    smoke_path = R / '.scratch/inference-current-cuda-20261025/smoke-runtime.json'
    smoke = m.base.read(smoke_path)
    if not runtime['PATH'].endswith(smoke['PATH']):
        raise ValueError('current runtime changed the original complete PATH suffix')
    original_runtime_path = R / '.scratch/inference-synchronous-step-report-20261025/cuda/runtime.json'
    original_runtime = m.base.read(original_runtime_path)
    if runtime.get('configured_flags', {}) != original_runtime.get('configured_flags', {}):
        raise ValueError('current runtime changed configured backend/precision flags')
    # The native loader already discovers the original hardlink beside the
    # executable. Do not require an otherwise unnecessary new PATH prefix.
    native_hardlink = runtime.get('native_hardlink')
    if not native_hardlink or Path(native_hardlink['path']).parent.resolve() != Path(image['path']).parent.resolve():
        raise ValueError('current runtime lacks its staged native DLL beside the final executable')
    exact(native_hardlink)
    if 'native' in final:
        exact(final['native'])
        if final['native']['sha256'] != native_hardlink['sha256']:
            raise ValueError('staged native DLL differs from retained original')
    config_path = PROTOCOL.parent / 'arms.json'
    arms = m.base.read(config_path)
    peers = {}
    for arm, entry in arms['arms'].items():
        if arm.startswith('hyle'):
            entry['ready'] = str(m.D / 'ready.json')
        else:
            peer = m.base.read(entry['ready'])
            if peer['image']['sha256'] != PEER_SHA:
                raise ValueError('retained peer identity changed')
            exact(peer['image'])
            peers[arm] = {'ready': m.base.identity(entry['ready']), 'image': peer['image']}
    # All real identity checks precede creation. No model process starts here.
    m.D.mkdir()
    ready = {'image': image, 'instrumented': False, 'canonical_main': current_main,
             'runtime_environment': runtime_pin, 'link_inputs': final['link_inputs'],
             'engine_split_sources': engine}
    m.base.save(m.D / 'ready.json', ready)
    m.base.save(m.D / 'arms.json', arms)
    original_input = R / '.scratch/qwen35-unsloth-mtp-20261024/geometry-v2-check/original'
    binding = {
        'current_image': ready, 'root_final_ready': m.base.identity(READY),
        'current_runtime_source': m.base.identity(smoke_path), 'runtime_receipt': runtime_pin,
        'source_main': current_main, 'engine_split_sources': engine,
        'final_link_inputs': final['link_inputs'], 'absolute_link_input_count': len(link_inputs),
        'final_object_map': final.get('object_map'), 'root_ready_limits': final.get('limits'),
        'adapter': m.base.identity(Path(__file__)),
        'input': {'V2_manifest': m.base.identity(original_input / 'weights.tsv'),
                  'V2_prompt': m.base.identity(original_input / 'prompt.ids'),
                  'original_protocol_input': m.base.identity(m.V / 'inputs/input.json'),
                  'original_prompt': m.base.identity(m.V / 'inputs/prompt.ids'),
                  'two_turn_schedule': m.base.identity(m.F / 'natural-inputs/performance64.txt'),
                  'role_mapping_receipt': m.base.identity(PROTOCOL.parent.parent / 'current-cuda/input-adaptation.json')},
        'retained_peer': peers,
        'protocol_only': {'window_adapter': m.base.identity(PROTOCOL),
                          'previous_full_adapter': m.base.identity(PREVIOUS_ADAPTER),
                          'arms': m.base.identity(config_path),
                          'window': m.base.identity(m.V / 'window.py'),
                          'turns': m.base.identity(m.F / 'turns.py'),
                          'statistics': m.base.identity(R / '.scratch/qwen-mtp-quality-20261022/current-window/performance.py'),
                          'runner': m.base.identity(m.base.RUNNER), 'observer': m.base.identity(m.base.OBSERVER)},
        'scope': 'Fresh dependency-refreshed current image with formal entry/model/weights/report split. '
                 'Retained vendor/native boundaries remain named by root Ready; no all-SDK/format certification. '
                 'Original plan/parse/normalize/analyze, arm order, flags, clocks, endpoints and independent '
                 'memory observer unchanged. No old samples pooled, extra warmup or profiler. '
                 'This new baseline follows real dependency refreshes, not additional samples for the prior report screen.',
        'process_order': [{'workload': workload, 'mode': mode,
                           'processes': 12 if mode == 'timing' else 4}
                          for workload, mode in ORDER]}
    m.base.save(m.D / 'binding.json', binding)
    print('SETUP_ONLY final current image/runtime/link-inputs + retained peer/protocol; no GPU execution', flush=True)


def select(workload, mode):
    m.WORKLOAD = workload
    return m.D / (workload + '-' + mode)


def plan(workload, mode):
    output = select(workload, mode)
    destination = m.D / (workload + '-' + mode + '-plan.json')
    if destination.exists() or output.exists():
        raise FileExistsError(destination if destination.exists() else output)
    value = m.plan(m.D / 'arms.json', mode, output)
    value.update(window_date='2026-10-26', current_closure_ready=m.base.identity(READY),
                 current_engine_split=m.base.identity(ENGINE))
    m.base.save(destination, value)
    print('PLAN_ONLY', workload, mode, len(value['commands']), flush=True)


def analyze(output):
    value = retained_analyze(output)
    value.update(baseline_date='2026-10-26', current_closure_ready=m.base.identity(READY),
                 current_engine_split=m.base.identity(ENGINE),
                 previous_samples_pooled=False)
    value['limits'] += [
        'Current107-dependency-change baseline is separate from the older frozen-be3/report-only screens; no historical samples pooled.',
        'Actual current formal entry/model/weights/report TUs and root-pinned selected project closure; retained native/vendor boundaries remain explicit.',
        'No causal speed claim for a particular small source change or blanket current codec/platform certification.']
    m.base.save(output / 'summary.json', value)
    return value


m.analyze = analyze
m.base.analyze = analyze


def run(workload, mode):
    output = select(workload, mode)
    if output.exists():
        raise FileExistsError(output)
    os.environ.update(HF_HUB_OFFLINE='1', TRANSFORMERS_OFFLINE='1')
    result = m.base.run(m.D / 'arms.json', mode, output)
    print('COMPLETE', workload, mode, result['processes'],
          result['within_arm_fixed_work_valid'], flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action', choices=('setup', 'plan', 'plan-all', 'run', 'run-all'))
    parser.add_argument('workload', nargs='?', choices=('single', 'two-turn'))
    parser.add_argument('mode', nargs='?', choices=('timing', 'memory'))
    args = parser.parse_args()
    if args.action == 'setup':
        if args.workload or args.mode:
            parser.error('setup takes no workload/mode')
        setup()
    elif args.action.endswith('-all'):
        if args.workload or args.mode:
            parser.error('all actions take no workload/mode')
        for workload, mode in ORDER:
            output = select(workload, mode)
            pending = output if args.action == 'run-all' else m.D / (workload + '-' + mode + '-plan.json')
            if pending.exists():
                raise FileExistsError(pending)
        for workload, mode in ORDER:
            (run if args.action == 'run-all' else plan)(workload, mode)
    else:
        if not args.workload or not args.mode:
            parser.error('plan/run require workload and mode')
        (plan if args.action == 'plan' else run)(args.workload, args.mode)
