"""Thin current-image adapter; only explicit run/run-all actions start GPUs."""
from pathlib import Path
import argparse
import importlib.util
import os
import sys

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = W.parents[1]
PROTOCOL = R / '.scratch/mtp-performance-convergence-20261025/baseline/window.py'
spec = importlib.util.spec_from_file_location('unchanged_full_window_protocol', PROTOCOL)
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)
# Redirect only after import: the retained module installs its original plan,
# parser, normalize, analysis and observer adapters on its own base module.
m.D = W / 'full-window'
ORDER = (('single', 'timing'), ('single', 'memory'), ('two-turn', 'timing'), ('two-turn', 'memory'))
PEER_SHA = '433e7051f4c36d0d9b2297dc378631546b7e3c44630cda0653cba2d1ec6bbe8e'

def setup():
    if m.D.exists():
        raise FileExistsError(m.D)
    original_ready = W / 'integrated/ready.json'
    # No placeholder receipt or Ready is generated before the real integrated
    # final canonical executable exists and matches its author's ready pin.
    integrated = m.base.read(original_ready)
    image = integrated['image']
    if m.base.identity(image['path']) != image or integrated.get('instrumented', False):
        raise ValueError('integrated ready must name the exact uninstrumented final executable')
    current_main = m.base.identity(R / 'engine/models/qwen35/main.cc')
    if 'canonical_main' in integrated and integrated['canonical_main'] != current_main:
        raise ValueError('integrated executable source differs from current canonical main')
    pinned_main = next((p for p in integrated.get('source_pins', []) if Path(p['path']) == Path(current_main['path'])), None)
    if pinned_main is not None and pinned_main != current_main:
        raise ValueError('integrated source pin differs from current canonical main')
    smoke_path = R / '.scratch/inference-current-cuda-20261025/smoke-runtime.json'
    runtime_path = W / 'integrated/runtime.json'
    runtime = m.base.read(runtime_path)
    smoke = m.base.read(smoke_path)
    # Reuse the final author's exact receipt; no duplicate copy or PATH rewrite.
    if not runtime['PATH'].startswith(str(Path(image['path']).parent) + ';') or not runtime['PATH'].endswith(smoke['PATH']):
        raise ValueError('integrated runtime must preserve the complete original PATH suffix')
    if 'runtime' in integrated and integrated['runtime'] != m.base.identity(runtime_path):
        raise ValueError('integrated runtime receipt changed')
    config_path = PROTOCOL.parent / 'arms.json'
    arms = m.base.read(config_path)
    peers = {}
    for arm, entry in arms['arms'].items():
        if arm.startswith('hyle'):
            entry['ready'] = str(m.D / 'ready.json')
        else:
            peer = m.base.read(entry['ready'])
            if peer['image']['sha256'] != PEER_SHA or m.base.identity(peer['image']['path']) != peer['image']:
                raise ValueError('retained peer executable changed')
            peers[arm] = {'ready': m.base.identity(entry['ready']), 'image': peer['image']}
    # All input checks precede creation; failed setup never fabricates Ready.
    m.D.mkdir()
    ready = {'image': image, 'instrumented': False, 'canonical_main': current_main,
             'runtime_environment': m.base.identity(runtime_path)}
    m.base.save(m.D / 'ready.json', ready)
    m.base.save(m.D / 'arms.json', arms)
    original_input = R / '.scratch/qwen35-unsloth-mtp-20261024/geometry-v2-check/original'
    binding = {
        'current_image': ready, 'integrated_ready': m.base.identity(original_ready),
        'current_runtime_source': m.base.identity(smoke_path), 'runtime_receipt': ready['runtime_environment'],
        'source_main': current_main, 'adapter': m.base.identity(Path(__file__)),
        'input': {'V2_manifest': m.base.identity(original_input / 'weights.tsv'),
                  'V2_prompt': m.base.identity(original_input / 'prompt.ids'),
                  'original_protocol_input': m.base.identity(m.V / 'inputs/input.json'),
                  'original_prompt': m.base.identity(m.V / 'inputs/prompt.ids'),
                  'two_turn_schedule': m.base.identity(m.F / 'natural-inputs/performance64.txt'),
                  'role_mapping_receipt': m.base.identity(PROTOCOL.parent.parent / 'current-cuda/input-adaptation.json')},
        'retained_peer': peers,
        'protocol_only': {'window_adapter': m.base.identity(PROTOCOL), 'arms': m.base.identity(config_path),
                          'window': m.base.identity(m.V / 'window.py'), 'turns': m.base.identity(m.F / 'turns.py'),
                          'statistics': m.base.identity(R / '.scratch/qwen-mtp-quality-20261022/current-window/performance.py'),
                          'runner': m.base.identity(m.base.RUNNER), 'observer': m.base.identity(m.base.OBSERVER)},
        'scope': 'Fresh current-image/runtime/input binding only. Old baseline is protocol, not current performance identity. '
                 'Original plan/parse/normalize/analyze, arm order, flags, clocks, endpoints and independent memory observer remain unchanged. '
                 'No old samples pooled, warmup, profiler or architecture causal-speed claim.',
        'process_order': [{'workload': w, 'mode': mode, 'processes': 12 if mode == 'timing' else 4} for w, mode in ORDER]}
    m.base.save(m.D / 'binding.json', binding)
    print('SETUP_ONLY current canonical image/runtime + retained peer/protocol; no GPU execution', flush=True)

def select(workload, mode):
    m.WORKLOAD = workload
    return m.D / (workload + '-' + mode)

def plan(workload, mode):
    output = select(workload, mode)
    destination = m.D / (workload + '-' + mode + '-plan.json')
    if destination.exists() or output.exists():
        raise FileExistsError(destination if destination.exists() else output)
    value = m.plan(m.D / 'arms.json', mode, output)
    m.base.save(destination, value)
    print('PLAN_ONLY', workload, mode, len(value['commands']), flush=True)

def run(workload, mode):
    output = select(workload, mode)
    if output.exists():
        raise FileExistsError(output)
    os.environ.update(HF_HUB_OFFLINE='1', TRANSFORMERS_OFFLINE='1')
    result = m.base.run(m.D / 'arms.json', mode, output)
    print('COMPLETE', workload, mode, result['processes'], result['within_arm_fixed_work_valid'], flush=True)

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action', choices=('setup', 'plan', 'plan-all', 'run', 'run-all'))
    parser.add_argument('workload', nargs='?', choices=('single', 'two-turn'))
    parser.add_argument('mode', nargs='?', choices=('timing', 'memory'))
    args = parser.parse_args()
    if args.action == 'setup':
        if args.workload or args.mode:
            parser.error('setup takes no workload/mode')
        setup()
    elif args.action.endswith('-all'):
        if args.workload or args.mode:
            parser.error('all actions take no workload/mode')
        # Refuse preexisting outputs before beginning any part of a 32-process window.
        for workload, mode in ORDER:
            output = select(workload, mode)
            pending = output if args.action == 'run-all' else m.D / (workload + '-' + mode + '-plan.json')
            if pending.exists():
                raise FileExistsError(pending)
        for workload, mode in ORDER:
            (run if args.action == 'run-all' else plan)(workload, mode)
    else:
        if not args.workload or not args.mode:
            parser.error('plan/run require workload and mode')
        (plan if args.action == 'plan' else run)(args.workload, args.mode)
