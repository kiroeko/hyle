"""One ordinary and one MTP journey after the required source/dependency refresh."""
from pathlib import Path
import hashlib
import importlib.util
import json
import os
import sys

sys.dont_write_bytecode = True
ROOT = Path.cwd()
WORK = Path(__file__).resolve().parent
BASE = ROOT / '.scratch/inference-synchronous-step-report-20261025'
spec = importlib.util.spec_from_file_location('original_journey_runner',
    ROOT / '.scratch/mtp-performance-convergence-20261025/baseline/window.py')
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)
m.WORKLOAD = 'two-turn'
helpers = m.helpers()


def read(path):
    return json.loads(path.read_bytes())


def save(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2)+'\n',encoding='utf-8')


def report(path):
    return json.loads(next(line for line in reversed(path.read_text(encoding='utf-8-sig').splitlines())
                           if line.strip().startswith('{')))


def normalize(value):
    if isinstance(value, list):
        return [normalize(item) for item in value]
    if isinstance(value, dict):
        return {key: normalize(item) for key, item in value.items()
                if not any(token in key for token in ['seconds','tokens_per_second',
                       'clock_unix','unix_ns','unix_ms'])}
    return value


def differences(left, right, path='$'):
    if type(left) is not type(right):
        return [{'path': path, 'control': left, 'candidate': right}]
    if isinstance(left, dict):
        result = []
        for key in sorted(set(left) | set(right)):
            if key not in left or key not in right:
                result.append({'path':path+'.'+key,'control':left.get(key),'candidate':right.get(key)})
            else:
                result.extend(differences(left[key], right[key], path+'.'+key))
        return result
    if isinstance(left, list):
        if len(left) != len(right):
            return [{'path':path,'control_length':len(left),'candidate_length':len(right)}]
        return [row for i,(a,b) in enumerate(zip(left,right)) for row in differences(a,b,f'{path}[{i}]')]
    return [] if left == right else [{'path':path,'control':left,'candidate':right}]


ready = read(WORK / 'ready.json')
image = ready['image']
assert hashlib.sha256(Path(image['path']).read_bytes()).hexdigest() == image['sha256']
runtime = read(WORK / 'runtime.json')
output = WORK / 'behavior'
assert not output.exists(), 'Retain previous behavior attempts'
output.mkdir()
results = []
for kind, subdir in [('ordinary','ordinary-screen'),('mtp','screen')]:
    baseline = BASE / subdir / 'timing-02-candidate'
    command = list(read(baseline / 'result.json')['command'])
    command[0] = image['path']
    env = os.environ.copy()
    env.update(HF_HUB_OFFLINE='1', TRANSFORMERS_OFFLINE='1')
    env['PATH'] = str(Path(image['path']).parent)+';'+runtime['PATH']
    folder = output / kind
    print('BEGIN',kind,flush=True)
    done = helpers.execute(folder, 'current-'+kind, command, env, False)
    assert done['exit'] == 0, (kind,done)
    actual, previous = report(folder/'stdout.log'), report(baseline/'stdout.log')
    delta = differences(normalize(previous), normalize(actual))
    save(folder/'non-time-differences.json', delta)
    assert actual['generated_tokens'] == 128 and actual['prefill_target_rows'] == 309
    results.append({'kind':kind,'process':done,'non_time_differences':len(delta),
        'generated_tokens':actual['generated_tokens'],'actual_graph_calls':actual['actual_graph_calls'],
        'prefill_target_rows':actual['prefill_target_rows'],
        'verified_target_rows':actual['verified_target_rows'],
        'reference':str(baseline.relative_to(ROOT)),
        'scope':'One behavior check, not a comparative speed/memory window'})
    save(output/'runs.json',results)
    print('END',kind,'non-time differences',len(delta),flush=True)
ok = all(row['non_time_differences']==0 for row in results)
save(output/'summary.json',{'status':'PASS_TWO_ORIGINAL_JOURNEYS' if ok else 'NON_TIME_DIFFERENCES_RECORDED',
    'image':image,'results':results,'limits':'Only this two-turn N1 ordinary/MTP consumer. '
    'No task-quality, all-model, other-platform or TPS/space claim. Retained native/vendor boundaries remain explicit.'})
raise SystemExit(0 if ok else 1)
