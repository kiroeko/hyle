"""Extract completed window summaries; never imports/runs inference or analysis."""
from pathlib import Path
import argparse
import hashlib
import json
import re
import zipfile

R = Path(__file__).resolve().parents[2]
W = Path(__file__).resolve().parent
D = W / 'full-window'
STEM = 'inference-current-window-2026-10-26'
ARMS = ('hyle_plain', 'hyle_mtp', 'peer_plain', 'peer_mtp')
ORDER = (('single', 'timing'), ('single', 'memory'), ('two-turn', 'timing'), ('two-turn', 'memory'))

def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))

def digest(raw):
    return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}

def pin(path):
    return {'path': str(path.resolve()), **digest(path.read_bytes())}

def short_stats(value):
    return {key: val for key, val in value.items() if key != 'samples'}

def sample_stamp(row):
    if row is None:
        return None
    return {key: row.get(key) for key in ('timestamp_ns', 'unix_time_ns',
            'elapsed_ns', 'process_running', 'sample_duration_ns')}

def extract():
    ready, binding = read(D / 'ready.json'), read(D / 'binding.json')
    assert not ready['instrumented']
    assert ready['image']['sha256'] == '2a94f0b297d00825c6470138c6daf472868161ff76a0dea15477f0c57b58b7a6'
    assert pin(Path(ready['image']['path'])) == ready['image']
    assert pin(Path(ready['runtime_environment']['path'])) == ready['runtime_environment']
    final = read(W / 'ready-current.json')
    assert final['image'] == ready['image']
    engine = read(W / 'engine/summary.json')
    source_pins = [row['source'] for row in engine['results']]
    for source in source_pins:
        assert pin(Path(source['path'])) == source
    comparison = read(W / 'full-window-nontime-comparison.json')
    assert comparison['status'] == 'PASS' and comparison['exact_differences_total'] == 0
    summaries, runs, processes = {}, {}, []
    for workload, mode in ORDER:
        label = workload + '-' + mode
        summaries[label] = summary = read(D / label / 'summary.json')
        runs[label] = current = read(D / label / 'runs.json')
        assert summary['within_arm_fixed_work_valid'] and summary['status'] == 'complete_stable_within_arm_work'
        assert summary['processes'] == len(current) == (12 if mode == 'timing' else 4)
        assert not summary['historical_samples_pooled'] and not summary['image_instrumented']
        for row in current:
            process = row['process']
            assert process['exit'] == 0 and not process['reader_errors'] and not process['profiler']
            assert process['memory_only'] == (mode == 'memory')
            expected_sha = ready['image']['sha256'] if row['arm'].startswith('hyle') else '433e7051f4c36d0d9b2297dc378631546b7e3c44630cda0653cba2d1ec6bbe8e'
            assert process['image']['sha256'] == expected_sha
            folder = Path(row['folder'])
            assert folder.parent == D / label
            assert read(folder / 'observation.json') == row['observation']
            processes.append({'window': label, 'arm': row['arm'], 'pid': process['pid'], 'exit': process['exit'],
                              'started_unix_ns': process['started_unix_ns'], 'finished_unix_ns': process['finished_unix_ns'],
                              'memory_only': process['memory_only'], 'throughput_evidence': process['throughput_evidence'],
                              'command': pin(folder / 'command.json'),
                              'result': pin(folder / 'result.json'), 'observation': pin(folder / 'observation.json')})
    assert len(processes) == 32
    rows, fairness = [], {}
    metrics = ('prefill_tokens_per_second', 'full_decode_tokens_per_second', 'session_output_tokens_per_second',
               'weights_load_seconds', 'startup_to_ready_seconds', 'first_token_elapsed_seconds', 'startup_to_endpoint_seconds')
    for workload in ('single', 'two-turn'):
        timing, memory = summaries[workload + '-timing'], summaries[workload + '-memory']
        fairness[workload] = {'within_arm_timing': timing['within_arm_work'],
            'within_arm_memory': memory['within_arm_work'],
            'between_arm_outputs': {pair: {key: value[key] for key in ('left_tokens', 'right_tokens', 'equal', 'first_divergence')}
                                    for pair, value in timing['between_arm_first_process_outputs'].items()},
            'actual_first_process_work': {arm: next(row['observation']['work'] for row in runs[workload + '-timing'] if row['arm'] == arm) for arm in ARMS},
            'memory_matches_timing_first': {}}
        for arm in ARMS:
            first = next(row['observation'] for row in runs[workload + '-timing'] if row['arm'] == arm)
            independent = next(row['observation'] for row in runs[workload + '-memory'] if row['arm'] == arm)
            fairness[workload]['memory_matches_timing_first'][arm] = {
                'IDs': first['generated_ids'] == independent['generated_ids'], 'work': first['work'] == independent['work']}
        for policy in ('plain', 'mtp'):
            row = {'workload': workload, 'policy': policy}
            for side, arm in [('hyle', 'hyle_' + policy), ('llama_cpp', 'peer_' + policy)]:
                group, mem = timing['groups'][arm], memory['groups'][arm]
                memory_folder = Path(next(run['folder'] for run in runs[workload + '-memory'] if run['arm'] == arm))
                memory_raw = read(memory_folder / 'memory.json')
                samples = memory_raw['samples']
                running_samples = [sample for sample in samples if sample['process_running']]
                for metric in metrics:
                    assert group[metric]['count'] == 3
                row[side] = {'timing_median': {metric: group[metric]['median'] for metric in metrics},
                    'timing_ranges': {metric: short_stats(group[metric]) for metric in metrics},
                    'independent_memory_bytes': mem['sampled_peaks'],
                    'memory_measurement': {'sample_count': mem['sample_count'], 'running_sample_count': mem['running_sample_count'],
                        'requested_interval_seconds': mem['requested_interval_seconds'], 'actual_sample_gaps_ms': short_stats(mem['actual_sample_gaps_ms']),
                        'null_sample_counts': mem['null_sample_counts'], 'unavailable_reasons': mem['unavailable_reasons'],
                        'setup_error': mem['setup_error'], 'thread_error': mem['thread_error'], 'counter_source': mem['counter_source'],
                        'first_sample': sample_stamp(samples[0] if samples else None),
                        'last_sample': sample_stamp(samples[-1] if samples else None),
                        'first_running_sample': sample_stamp(running_samples[0] if running_samples else None),
                        'last_running_sample': sample_stamp(running_samples[-1] if running_samples else None),
                        'ready_baseline': mem['ready_baseline'], 'sample_cost_ms': short_stats(mem['sample_cost_ms']),
                        'phase_markers': {name: {key: value.get(key) for key in ('begin_ns','end_ns','received_boundary_counts','missing_boundary','ambiguous_boundary','invalid_boundary_order','sample_count','exact_phase_boundary_values')}
                                          for name, value in mem['phase_windows'].items()}}}
            rows.append(row)
    return {'status': 'CURRENT_CANONICAL_FULL32_WINDOW_COMPLETE_STABLE_WITHIN_ARM', 'date': '2026-10-26',
        'current_image': ready, 'source_pins': source_pins, 'binding': binding,
        'current_closure': final,
        'build_proof_scope': '107 old objects replaced by108 current project objects, with explicit retained vendor/native boundaries. Detailed build evidence is published separately by root/architecture; no SDK rebuild or all-format certification.',
        'build_evidence': {'report': pin(R / 'docs/evidence/research/inference-current-source-build-2026-10-26.json'),
                           'archive': pin(R / 'docs/evidence/research/inference-current-source-build-2026-10-26.zip')},
        'two_turn_full_nontime_comparison': comparison,
        'old_comparison_only_archive': pin(R / 'docs/evidence/performance/inference-synchronous-step-report-2026-10-26.zip'),
        'protocol': 'Unchanged retained plan/parse/normalize/analyze; 12 unmonitored timing +4 independent memory processes per workload. No old performance samples included.',
        'table': rows, 'processes': processes, 'process_count': 32, 'fairness_and_work': fairness,
        'summary_pins': {label: pin(D / label / 'summary.json') for label in summaries},
        'original_timing_and_memory_limits': {label: value['limits'] for label, value in summaries.items()},
        'timer': summaries['single-timing']['timer'],
        'limits': ['Timing values are original per-arm medians, not ratios of pooled samples. Memory has one separate process per arm/workload and never enters timing denominators.',
            'Same source family/prompt/context/output quota does not mean equal generated IDs, accepted-draft work or subsequent attention history. Natural per-arm differences and actual work are preserved; no task-quality conclusion.',
            'Dedicated GPU/WS/private sampled peaks are lower-bound observations. PDH/PSAPI and actual gaps/nulls are retained; this is not exact physical allocation accounting or allocator peak attribution.',
            'Loading/ready and complete-session endpoints retain their original producer scopes; OS file caches are not purged. Default reporting/IO remains in its original natural boundaries.',
            'This is a new dependency-refreshed2a94/peer433e full window, not an isolated before/after candidate experiment. No cross-day absolute TPS attribution, old-sample pooling, causal optimization benefit, multi-user throughput, other model/codec/backend or quality claim.']}

def archive(report, destination):
    members, origins = {}, {}
    def add(name, path):
        assert name not in members and path.is_file()
        assert path.suffix.lower() not in {'.obj', '.lib', '.exe', '.dll', '.pdb', '.bin', '.safetensors', '.gguf', '.tar', '.gz'}
        raw = path.read_bytes()
        assert not re.search(rb'(?i)(authorization\s*[:=]\s*bearer|x-amz-(?:signature|credential)=|[?&](?:signature|access_token)=|hf_[A-Za-z0-9]{24,})', raw), name
        members[name] = raw
        origins[name] = str(path.resolve())
    for name in ('ready.json', 'arms.json', 'binding.json'):
        add('binding/' + name, D / name)
    for number, path in enumerate(dict.fromkeys(Path(value['path']) for value in report['binding']['input'].values())):
        add('input/' + str(number) + '-' + path.name, path)
    peer_paths = {Path(entry['ready']) for arm, entry in read(D / 'arms.json')['arms'].items() if arm.startswith('peer')}
    for number, path in enumerate(sorted(peer_paths)):
        add('peer/' + str(number) + '-ready.json', path)
        value = read(path)
        for key in ('runtime_environment', 'compiled_identity'):
            add('peer/' + str(number) + '-' + key + '.json', Path(value[key]['path']))
    for name in ('ready-current.json', 'runtime-current.json', 'link-inputs-current.json', 'object-map-current.json',
                 'full-window-adapter-plan.json', 'full-window-nontime-comparison.json', 'compare_window_nontime.py'):
        add('current-closure/' + name, W / name)
    # Full build commands/actual dependencies/source are in the separate build proof.
    # This window carries only identities needed to bind its actual image/runtime.
    protocol_paths = [Path(__file__), W / 'full-window.py', W / 'behavior.py']
    protocol_paths += [Path(value['path']) for value in report['binding']['protocol_only'].values()]
    for number, path in enumerate(dict.fromkeys(protocol_paths)):
        add('protocol/' + str(number) + '-' + path.name, path)
    for workload, mode in ORDER:
        label = workload + '-' + mode
        for path in sorted((D / label).rglob('*')):
            if not path.is_file() or path.suffix.lower() not in ('.json', '.log'):
                continue
            # runs.json embeds each exact observation; do not store both copies.
            if path.name == 'observation.json':
                continue
            add('actual/' + label + '/' + path.relative_to(D / label).as_posix(), path)
    index = (json.dumps({'members': [{'member': name, 'original_path': origins[name], **digest(raw)} for name, raw in sorted(members.items())],
                          'observations': 'Exact original observations are embedded in each runs.json. Their original file pins are in the public process list.',
                          'exclusions': 'No executable/object/library, SDK, source tree or model payload.'}, indent=2) + '\n').encode()
    assert not destination.exists(), destination
    destination.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(destination, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as output:
        for name, raw in sorted({**members, 'member-sha256.json': index}.items()):
            info = zipfile.ZipInfo(name); info.compress_type = zipfile.ZIP_DEFLATED; info.external_attr = 0o644 << 16
            output.writestr(info, raw, compresslevel=9)
    with zipfile.ZipFile(destination) as output:
        assert output.testzip() is None and len(output.namelist()) == len(members) + 1
        assert output.read('member-sha256.json') == index
        for name, raw in members.items():
            assert digest(output.read(name)) == digest(raw)
    return {**pin(destination), 'members': len(members) + 1, 'CRC_and_member_SHA256_verified': True,
            'index': 'member-sha256.json', 'no_binaries_SDK_source_tree_or_model_payload': True}

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--publish', action='store_true', help='Only after root confirms all32 processes have finished')
    args = parser.parse_args()
    report = extract()
    destination = R / 'docs/evidence/performance' if args.publish else W / 'report-private'
    out = destination / (STEM + '.json')
    assert not out.exists(), out
    if args.publish:
        report['archive'] = archive(report, destination / (STEM + '.zip'))
    destination.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(report, indent=2, ensure_ascii=False, allow_nan=False) + '\n', encoding='utf-8', newline='\n')
    print(json.dumps({'report': pin(out), 'archive': report.get('archive'), 'processes': report['process_count']}, indent=2))
