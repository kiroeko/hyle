"""Compare full two-turn Hyle reports only; never imports an inference runner."""
from pathlib import Path
import ast
import hashlib
import json

ROOT = Path.cwd()
WORK = Path(__file__).resolve().parent
D = WORK / 'full-window'


def read(path):
    return json.loads(path.read_bytes())


def pin(path):
    raw = path.read_bytes()
    return {'path': str(path.resolve()), 'bytes': len(raw),
            'sha256': hashlib.sha256(raw).hexdigest()}


def report(path):
    return json.loads(next(line for line in reversed(path.read_text().splitlines()) if line.startswith('{')))


source = WORK / 'behavior.py'
tree = ast.parse(source.read_text())
namespace = {}
exec(compile(ast.Module(body=[node for node in tree.body if isinstance(node, ast.FunctionDef)
    and node.name in ['normalize', 'differences']], type_ignores=[]), str(source), 'exec'), namespace)
normalize, differences = namespace['normalize'], namespace['differences']
comparisons = []
base = ROOT / '.scratch/inference-synchronous-step-report-20261025'
for label, kind in [('hyle_plain', 'ordinary'), ('hyle_mtp', 'mtp')]:
    older = base / ('ordinary-screen' if kind == 'ordinary' else 'screen') / 'timing-02-candidate/stdout.log'
    intermediate = WORK / 'behavior' / kind / 'stdout.log'
    baseline_reports = {'703_report_screen': (older, normalize(report(older))),
                        'fa32_two_journey_behavior': (intermediate, normalize(report(intermediate)))}
    for mode in ['timing', 'memory']:
        runs = read(D / ('two-turn-' + mode) / 'runs.json')
        for run in runs:
            if run['arm'] != label:
                continue
            actual_path = Path(run['folder']) / 'stdout.log'
            actual = normalize(report(actual_path))
            for baseline_name, (baseline_path, before) in baseline_reports.items():
                delta = differences(before, actual)
                comparisons.append({'mode': mode, 'arm': label, 'baseline': baseline_name,
                    'baseline_stdout': pin(baseline_path), 'current_stdout': pin(actual_path),
                    'differences': delta, 'difference_count': len(delta)})
assert len(comparisons) == 16
result = {'status': 'PASS' if not any(row['differences'] for row in comparisons) else 'EXACT_DIFFERENCES_RETAINED',
    'scope': 'All8 new two-turn Hyle reports (3timing+1independent memory per ordinary/MTP) versus both original703 report-screen candidate and fa32 intermediate behavior. Only original clock field exclusions; every other key/value/type/list is compared recursively.',
    'comparison_code': pin(source), 'script': pin(Path(__file__).resolve()),
    'current_image': read(WORK / 'ready-current.json')['image'],
    'reference_images': {'703': read(base / 'cuda/ready.json')['image'], 'fa32': read(WORK / 'ready.json')['image']},
    'comparisons': comparisons,
    'exact_differences_total': sum(row['difference_count'] for row in comparisons),
    'limits': 'Behavior/work/metadata comparison only. No timings from older screens or behavior runs enter this window. This does not causally attribute any absolute TPS change across processes/dates.'}
out = WORK / 'full-window-nontime-comparison.json'
out.write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'status': result['status'], 'comparisons': 16,
                  'exact_differences_total': result['exact_differences_total'], 'result': pin(out)}, indent=2))
