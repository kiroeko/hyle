"""Publish the completed finite AU experiment; never starts a native process."""
from pathlib import Path
import collections, difflib, hashlib, json, re, zipfile

S = Path(__file__).resolve().parent
R = S.parents[1]
OUT = R / 'docs/evidence/performance/qwen-capture-variants-2026-10-22.json'
ZIP = OUT.with_suffix('.logs.zip')

def read(p):
    return json.loads(Path(p).read_text(encoding='utf-8-sig'))

def save(p, value):
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')

def ident(p):
    p = Path(p).resolve()
    raw = p.read_bytes()
    return dict(path=str(p.relative_to(R)), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())

assert not OUT.exists() and not ZIP.exists(), 'Do not overwrite a published experiment.'

# Preserve the two common changes as a reviewable before/after delta.
common = ['src/graph/plan_state.h', 'src/graph/executable.cc']
for rel in common:
    before = S / 'common/before' / rel
    after = S / 'common/after' / rel
    after.parent.mkdir(parents=True, exist_ok=True)
    after.write_bytes((R / rel).read_bytes())
    delta = ''.join(difflib.unified_diff(before.read_text(encoding='utf-8').splitlines(True),
        after.read_text(encoding='utf-8').splitlines(True), fromfile='before/' + rel, tofile='after/' + rel))
    (S / ('common/' + Path(rel).name + '.diff')).write_text(delta, encoding='utf-8')
save(S / 'common/source-freeze.json', dict(files=[ident(R / p) for p in common],
    after=[ident(S / 'common/after' / p) for p in common]))

product_files = common + [
    'include/hyle/compute/detail/capture_bindings.h',
    'src/compute/provider_internal.h', 'src/compute/operation.cc',
    'src/compute_provider_ggml_cuda/ggml_cuda_provider.cc',
    'src/compute_provider_cublas/cublas_provider.cc',
    'src/compute_provider_cuda/collectives_provider.cc',
    'src/compute_provider_torch_cuda/artifact_provider.cc',
    'include/hyle/graph/detail/region_access.h', 'src/graph/region_access.cc',
    'src/graph_provider_ggml_cuda/ggml_cuda_region.cc',
    'src/graph_batch/batch.cc', 'src/graph_batch/paged_append.cc',
    'tests/graph/region_provider_test.cc']
for rel in product_files:
    target = S / 'source-current' / rel
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes((R / rel).read_bytes())
product = [ident(R / p) for p in product_files]
save(S / 'source-current/identities.json', product)

checks = read(S / 'checks2/summary.json')
assert checks['tests'] == 24 and not any(checks[k] for k in ['failures', 'disabled', 'errors', 'skipped'])
prefix = read(S / 'prefix-run1/vectors/observation.json')
assert prefix['status'] == 'PASS_BYTE_EXACT' and prefix['actual_graph_calls'] == 15
assert len(prefix['vectors']) == 534 and prefix['all_vectors_byte_equal'] and prefix['all_finite']

# Compare complete payloads, not just the producer's summaries. Retain the old
# payloads and record the mapping, so the new identical 128 MB can be deduplicated.
old_path = R / '.scratch/qwen-native-protocol-20261022/cuda-prefix-run1/vectors/observation.json'
old = read(old_path)
assert len(old['vectors']) == len(prefix['vectors'])
pairs = {}
for new_row, old_row in zip(prefix['vectors'], old['vectors']):
    assert {k:v for k,v in new_row.items() if k not in ['baseline', 'actual']} == {
        k:v for k,v in old_row.items() if k not in ['baseline', 'actual']}
    for key in ['baseline', 'actual']:
        new_file, old_file = Path(new_row[key]), Path(old_row[key])
        new_file.resolve().relative_to((S / 'prefix-run1/vectors').resolve())
        if str(new_file) in pairs:
            assert pairs[str(new_file)]['retained_reference']['path'] == str(old_file.relative_to(R))
            continue
        new_bytes, old_bytes = new_file.read_bytes(), old_file.read_bytes()
        assert new_bytes == old_bytes, new_row['name']
        pairs[str(new_file)] = dict(current=ident(new_file), retained_reference=ident(old_file),
            comparison='full read_bytes equality', byte_equal=True)
raw_files = {p.resolve() for p in (S / 'prefix-run1/vectors').rglob('*')
    if p.is_file() and p.suffix in ['.bf16', '.f32', '.i32', '.f16']}
assert raw_files == {Path(p).resolve() for p in pairs}, 'Do not remove an unexamined payload.'
cross = dict(status='PASS_COMPLETE_BYTES_IDENTICAL', logical_vectors=534,
    complete_payload_pairs=len(pairs), bytes_compared=sum(x['current']['bytes'] for x in pairs.values()),
    previous_observation=ident(old_path), current_observation=ident(S / 'prefix-run1/vectors/observation.json'),
    all_non_path_vector_fields_equal=True, mismatches=0, payloads=list(pairs.values()),
    retention='Keep the previous AQ payloads; new AU byte-identical duplicates may be removed after this mapping is published.')
assert cross['complete_payload_pairs'] == 324 and cross['bytes_compared'] == 127836160
save(S / 'prefix-run1/previous-image-comparison.json', cross)

timing = read(S / 'current-window/timing/summary.json')
memory = read(S / 'current-window/memory/summary.json')
assert timing['processes'] == 12 and memory['processes'] == 4
assert timing['within_arm_fixed_work_valid'] and memory['within_arm_fixed_work_valid']
runs = read(S / 'current-window/timing/runs.json')
assert all(x['process']['exit'] == 0 for x in runs)
capture = collections.defaultdict(list)
for run in runs:
    if not run['arm'].startswith('hyle_'):
        continue
    lines = (Path(run['folder']) / 'stderr.log').read_text().splitlines()
    # Exclude prefill; T1/T2 prepared lines are the decode phases here.
    rows = [tuple(map(int, m)) for line in lines if line.startswith('prepared T=') and not line.startswith('prepared T=154 ')
        for m in re.findall(r'capture_recorded=(\d+) capture_reused=(\d+)', line)]
    capture[run['arm']].append(dict(folder=run['folder'], recorded=sum(x[0] for x in rows),
        reused=sum(x[1] for x in rows), prepared_calls=len(rows)))
for row in capture['hyle_plain']:
    assert (row['recorded'], row['reused']) == (2, 61)
for row in capture['hyle_mtp']:
    assert (row['recorded'], row['reused']) == (19, 49)

old_timing = read(R / '.scratch/qwen-capture-reuse-20261022/current-window/timing/summary.json')
comparisons = {}
for mode in ['plain', 'mtp']:
    ours = timing['groups']['hyle_' + mode]
    peer = timing['groups']['peer_' + mode]
    previous = old_timing['groups']['hyle_' + mode]
    comparisons[mode] = dict(
        decode_change_vs_AS_percent=100*(ours['full_decode_tokens_per_second']['median']/previous['full_decode_tokens_per_second']['median']-1),
        decode_difference_vs_peer_percent=100*(ours['full_decode_tokens_per_second']['median']/peer['full_decode_tokens_per_second']['median']-1),
        prefill_difference_vs_peer_percent=100*(ours['prefill_tokens_per_second']['median']/peer['prefill_tokens_per_second']['median']-1),
        combined_difference_vs_peer_percent=100*(ours['session_output_tokens_per_second']['median']/peer['session_output_tokens_per_second']['median']-1))

image = read(S / 'hyle-link2/ready.json')['image']
assert ident(image['path'])['sha256'] == image['sha256']
record = dict(status='REGRESSION_RESTORED_WITH_BOUNDED_CAPTURE_VARIANTS', date='2026-10-22', goal_complete=False,
    conclusion='Ordinary decode recovered from the single-carrier regression: current median 91.44 tokens/s versus peer 95.08. MTP recovered to 112.29 versus 125.65. Remaining cross-engine gaps and other applicable MTP artifacts are not closed.',
    implementation=dict(product_changes=product, model_math_changed=False, public_engine_API_changed=False,
        steady_state_capture_variants_per_range=2, variants_include_active=True,
        native_structural_fallback_transient_exec_upper_count=3, native_private_bytes_unknown=True,
        capability='Query the actual prepared OperationInvocation/RegionInvocation. Absence or unsupported inspection keeps the existing conservative record/update path; no model/provider-name whitelist.',
        key='Every emitting step input/output description, dtype, dimensions, strides, resource, native handle, offset and span; full equality, not a hash-only test.',
        preparation='Normal binding, input source, permission, alias, seal and actual retirement remain required. A dormant graph is published only after full current preparation succeeds.',
        invalidation='Actual Queue owner, configuration, native/private argument changes, Commands mode or failed preparation clear affected variants before mutation. Identity-preserving logical reset retains its existing contract.',
        resource='One Invocation and existing state banks/workspace. No restored dual model carrier, shadow buffer or global implicit cache.'),
    provenance=dict(image=image, ggml_native_pool=read(S / 'compute/ggml-pool-evidence.json'),
        compute_freeze=ident(S / 'compute/source-freeze.json'), region_freeze=ident(S / 'regions/source-freeze.json'),
        common_freeze=ident(S / 'common/source-freeze.json'), review=read(S / 'review/common-variants-review.json')),
    checks=dict(final=checks, initial_fixture_failure=ident(S / 'checks1/results.xml'),
        fixture_correction='End failure correctly clears dormant variants; the fixture now re-primes B before testing a matching-B seal rejection. No threshold or product failure gate was weakened.',
        CUDA_prefix_observation=ident(S / 'prefix-run1/vectors/observation.json'),
        actual_graph_calls=15, vector_comparisons=534, old_prefix_full_byte_checks=7,
        cross_image_complete_bytes={k:v for k,v in cross.items() if k != 'payloads'},
        complete_payload_mapping=ident(S / 'prefix-run1/previous-image-comparison.json')),
    full_performance=dict(timing=timing, independent_memory=memory, comparisons=comparisons,
        decode_capture_counts=dict(capture),
        prior_single_carrier_update=ident(R / 'docs/evidence/performance/qwen-capture-rebuild-2026-10-22.json'),
        prior_recording_cost=ident(R / 'docs/evidence/performance/qwen-capture-recording-cost-2026-10-22.json'),
        comparison_reference_note='The inherited previous_AR_work_preserved_by_arm label in the AU driver compares the immediately preceding AS window; the actual source paths are preserved in the archived driver.'),
    limits=[
        'Three new timing processes per arm, interleaved, and four separate memory processes. All samples and ranges retained; medians are descriptive, not universal statistical speed guarantees.',
        'Same original BF16 weights and P154 input, C1024, 64 visible outputs, greedy K1, N1/R1, prefix off, replay auto. Complete decode counts all 63 outputs after prefill through host-visible completion.',
        'Cross-engine natural continuations diverge at output 19. Intermediate arithmetic and MTP acceptance/work differ. This is not a same-token or per-operator same-math claim.',
        'The combined figure is 64/(prefill+decode), excluding loading. It is not multi-round, concurrent-serving or cold-start throughput.',
        'Independent PSAPI/PDH peaks are sampled per-process counters, not exact physical GPU allocations. Dedicated/shared peaks cannot be added; total is sampled at the same instant. CPU working set/commit and shared GPU memory are not disjoint.',
        'Against AS, dedicated GPU sampled peaks rose by 6 MiB ordinary and 16 MiB MTP. Driver-private graph bytes are unknown. Stable capture count is bounded at two, with a possible third executable transiently during structural fallback.',
        'The 534 vector checks and 324 previous-image full payload matches are finite CUDA state regressions, not all-platform/all-artifact numerical quality coverage.',
        'No new SDK/NVCC/shader builds and no further favorable-sample reruns. Other applicable MTP artifacts, remaining performance gaps and the broad architecture/capability goal remain incomplete.'])

# Compact evidence contains frozen sources, commands and actual logs, not large
# reconstructible images/maps/objects or duplicate raw tensor payloads.
selected = [p for p in S.rglob('*') if p.is_file() and p.suffix.lower() in
    ['.json', '.py', '.cc', '.h', '.diff', '.log', '.xml', '.tsv', '.txt']
    and '__pycache__' not in p.parts and 'tmp' not in p.parts]
with zipfile.ZipFile(ZIP, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for p in sorted(selected):
        z.write(p, p.relative_to(S).as_posix())
with zipfile.ZipFile(ZIP) as z:
    assert z.testzip() is None
record['archived_logs'] = ident(ZIP)
save(OUT, record)
save(S / 'publication-receipt.json', dict(evidence=ident(OUT), logs=ident(ZIP), goal_complete=False))
print(json.dumps(dict(evidence=ident(OUT), logs=ident(ZIP), comparisons=comparisons, capture=dict(capture)), indent=2))
