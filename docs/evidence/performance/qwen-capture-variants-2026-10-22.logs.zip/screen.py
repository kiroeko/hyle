"""Root-only two-process current-image screen, not final throughput evidence."""
from pathlib import Path
import importlib.util,json,os,re,sys
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent;R=S.parents[1];AR=R/'.scratch/qwen-mtp-quality-20261022'
sp=importlib.util.spec_from_file_location('as_screen_helpers',AR/'run_quality.py')
h=importlib.util.module_from_spec(sp);sp.loader.exec_module(h)
image=h.read(S/'hyle-link2/ready.json')['image'];assert h.ident(image['path'])==image
env=os.environ.copy();env['PATH']=h.read(S/'hyle-link2/runtime-environment.json')['PATH']
reference=h.read(AR/'current-window/timing/runs.json');records=[]
for mtp in [False,True]:
    arm='hyle_mtp'if mtp else'hyle_plain';folder=S/'screen2'/arm
    command=[image['path'],'--inputs',str(h.V/'inputs'/('mtp'if mtp else'text')),
        '--steps','64','--capacity','1024','--max-sessions','1','--active-sequences','1',
        '--prefix-cache','off','--progress','direct','--replay','auto','--mtp','on'if mtp else'off']
    process=h.execute(command,env,folder,timeout=120)
    assert process['exit']==0 and not process['timed_out'],process
    raw=json.loads((folder/'stdout.log').read_text().strip().splitlines()[-1]);h.save(folder/'parsed.json',raw)
    old=next(x for x in reference if x['arm']==arm)['observation']['raw']
    assert raw['generated_ids']==old['generated_ids']
    log=(folder/'stderr.log').read_text()
    row=dict(arm=arm,image=image,process=process,IDs_equal_AR=True,
        full_decode_tokens_per_second=63/raw['decode_seconds'],
        capture_recorded=sum(map(int,re.findall(r'capture_recorded=(\d+)',log))),
        capture_reused=sum(map(int,re.findall(r'capture_reused=(\d+)',log))))
    records.append(row);print('SCREEN',row,flush=True)
h.save(S/'screen2/summary.json',dict(records=records,scope='Two processes, mechanism screen only; not a final timing/memory comparison.'))
