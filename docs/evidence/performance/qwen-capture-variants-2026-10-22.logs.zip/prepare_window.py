"""Reuse the fixed four-arm timing/memory protocol for current AU image."""
from pathlib import Path
S=Path(__file__).resolve().parent;R=S.parents[1]
source=R/'.scratch/qwen-capture-reuse-20261022/performance.py'
text=source.read_text(encoding='utf-8')
text=text.replace('AS current product capture-rebuild image','AU bounded capture variants image')
text=text.replace('AS Hyle rebuild','AU Hyle bounded variants').replace('AS Hyle plain/MTP','AU Hyle plain/MTP')
text=text.replace("reference=base.read(AR/'current-window/timing/runs.json')", "reference=base.read(R/'.scratch/qwen-capture-reuse-20261022/current-window/timing/runs.json')")
(S/'performance.py').write_text(text,encoding='utf-8')
print('PREPARED fixed window script')
