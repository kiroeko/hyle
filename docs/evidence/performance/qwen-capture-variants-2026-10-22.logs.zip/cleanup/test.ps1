$ErrorActionPreference = 'Stop'
$taskRoot = 'C:\public\project-hyle\hyle\.scratch\qwen-capture-variants-20261022'
$taskPrefix = $taskRoot + '\'
$taskPlan = Get-Content -LiteralPath ($taskRoot + '\cleanup-plan.json') -Raw | ConvertFrom-Json
$taskFiles = @($taskPlan.files)
foreach ($taskFile in $taskFiles) {
  $taskResolved = (Resolve-Path -LiteralPath $taskFile.path).Path
  if (-not $taskResolved.StartsWith($taskPrefix, [StringComparison]::OrdinalIgnoreCase)) { throw 'Cleanup outside exact AU workspace' }
  if ($taskResolved -in @($taskPlan.keep_current_image, $taskPlan.keep_current_map)) { throw 'Current image must be retained' }
  $taskInfo = Get-Item -LiteralPath $taskResolved
  if ($taskInfo.PSIsContainer -or $taskInfo.Length -ne $taskFile.bytes) { throw 'Cleanup target changed' }
  if ((Get-FileHash -LiteralPath $taskResolved -Algorithm SHA256).Hash -ne $taskFile.sha256) { throw 'Cleanup hash changed' }
  if ($taskFile.retained_reference) {
    $taskReference = Get-Item -LiteralPath $taskFile.retained_reference.path
    if ($taskReference.Length -ne $taskFile.bytes -or (Get-FileHash -LiteralPath $taskReference.FullName -Algorithm SHA256).Hash -ne $taskFile.sha256) { throw 'Retained identical reference changed' }
  }
}
Get-Process -Name qwen,capture-tests,probe -ErrorAction SilentlyContinue | ForEach-Object {
  if ($_.Path -in $taskFiles.path) { throw 'Cleanup image is still running' }
}
$taskRemoved = @()
foreach ($taskFile in $taskFiles) {
  Remove-Item -LiteralPath $taskFile.path -Force
  $taskRemoved += $taskFile
}
[PSCustomObject]@{ Removed = $taskRemoved; Bytes = ($taskRemoved | Measure-Object -Property bytes -Sum).Sum; CurrentImageRetained = (Test-Path -LiteralPath $taskPlan.keep_current_image) } | ConvertTo-Json -Depth 7 | Set-Content -LiteralPath ($taskRoot + '\cleanup-result.json') -Encoding utf8
