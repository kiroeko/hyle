"""Write exact cleanup operations to root test.ps1; do not delete anything here."""
from pathlib import Path
import hashlib, json
S=Path(__file__).resolve().parent; R=S.parents[1]
def read(p): return json.loads(p.read_text(encoding='utf-8-sig'))
def ident(p):
    raw=p.read_bytes()
    return dict(path=str(p.resolve()),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
assert (R/'docs/evidence/performance/qwen-capture-variants-2026-10-22.logs.zip').is_file()
files=[]
for folder in ['hyle-link1','tests-link1','tests-link2','prefix-link2']:
    files += [ident(p) for p in sorted((S/folder).iterdir()) if p.suffix in ['.exe','.map']]
mapping=read(S/'prefix-run1/previous-image-comparison.json')
for row in mapping['payloads']:
    current, old=row['current'],row['retained_reference']
    p=R/current['path']; reference=R/old['path']
    assert ident(p)['sha256']==ident(reference)['sha256']==current['sha256']==old['sha256']
    item=ident(p);item['retained_reference']=ident(reference);files.append(item)
assert len(files)==332
plan=dict(scope=str(S),files=files,bytes=sum(x['bytes'] for x in files),
    keep_current_image=str(S/'hyle-link2/qwen.exe'),keep_current_map=str(S/'hyle-link2/qwen.map'),
    keep_previous_prefix_payloads=True)
(S/'cleanup-plan.json').write_text(json.dumps(plan,indent=2)+'\n',encoding='utf-8')
script=r'''$ErrorActionPreference = 'Stop'
$taskRoot = 'C:\public\project-hyle\hyle\.scratch\qwen-capture-variants-20261022'
$taskPrefix = $taskRoot + '\'
$taskPlan = Get-Content -LiteralPath ($taskRoot + '\cleanup-plan.json') -Raw | ConvertFrom-Json
$taskFiles = @($taskPlan.files)
foreach ($taskFile in $taskFiles) {
  $taskResolved = (Resolve-Path -LiteralPath $taskFile.path).Path
  if (-not $taskResolved.StartsWith($taskPrefix, [StringComparison]::OrdinalIgnoreCase)) { throw 'Cleanup outside exact AU workspace' }
  if ($taskResolved -in @($taskPlan.keep_current_image, $taskPlan.keep_current_map)) { throw 'Current image must be retained' }
  $taskInfo = Get-Item -LiteralPath $taskResolved
  if ($taskInfo.PSIsContainer -or $taskInfo.Length -ne $taskFile.bytes) { throw 'Cleanup target changed' }
  if ((Get-FileHash -LiteralPath $taskResolved -Algorithm SHA256).Hash -ne $taskFile.sha256) { throw 'Cleanup hash changed' }
  if ($taskFile.retained_reference) {
    $taskReference = Get-Item -LiteralPath $taskFile.retained_reference.path
    if ($taskReference.Length -ne $taskFile.bytes -or (Get-FileHash -LiteralPath $taskReference.FullName -Algorithm SHA256).Hash -ne $taskFile.sha256) { throw 'Retained identical reference changed' }
  }
}
Get-Process -Name qwen,capture-tests,probe -ErrorAction SilentlyContinue | ForEach-Object {
  if ($_.Path -in $taskFiles.path) { throw 'Cleanup image is still running' }
}
$taskRemoved = @()
foreach ($taskFile in $taskFiles) {
  Remove-Item -LiteralPath $taskFile.path -Force
  $taskRemoved += $taskFile
}
[PSCustomObject]@{ Removed = $taskRemoved; Bytes = ($taskRemoved | Measure-Object -Property bytes -Sum).Sum; CurrentImageRetained = (Test-Path -LiteralPath $taskPlan.keep_current_image) } | ConvertTo-Json -Depth 7 | Set-Content -LiteralPath ($taskRoot + '\cleanup-result.json') -Encoding utf8
'''
(R/'test.ps1').write_text(script,encoding='utf-8')
print(json.dumps(dict(files=len(files),bytes=plan['bytes'],script=str(R/'test.ps1'))))
