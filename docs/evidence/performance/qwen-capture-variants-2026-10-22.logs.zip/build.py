"""Root-only bounded capture host overlay, reusing AS image closure/caches."""
from pathlib import Path
import argparse,importlib.util,os,sys
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent;R=S.parents[1];AS=R/'.scratch/qwen-capture-reuse-20261022'
sp=importlib.util.spec_from_file_location('au_cached',AS/'build.py')
m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m);b,c,h=m.b,m.c,m.h;h.S=S
BASE=AS/'hyle-link2';BASE_PLAN=c.read(BASE/'link-plan.json')
SOURCES={tag:m.SOURCES[tag]for tag in [*m.GRAPH,'progress']}
SOURCES.update({'operation':R/'src/compute/operation.cc',
 'ggml-provider':R/'src/compute_provider_ggml_cuda/ggml_cuda_provider.cc',
 'cublas':R/'src/compute_provider_cublas/cublas_provider.cc',
 'cccl':R/'src/compute_provider_cuda/collectives_provider.cc',
 'artifact':R/'src/compute_provider_torch_cuda/artifact_provider.cc',
 'ggml-region':R/'src/graph_provider_ggml_cuda/ggml_cuda_region.cc',
 'graph-batch':R/'src/graph_batch/batch.cc',
 'append':R/'src/graph_batch/paged_append.cc',
 'prefix':R/'tools/qwen35_text/mtp_session_probe.cc',
 'graph-test':R/'tests/graph/region_provider_test.cc'})
INDEX={tag:m.INDEX[tag]for tag in [*m.GRAPH,'progress']}
INDEX.update({'operation':79,'ggml-provider':143,'cublas':126,'cccl':127,
              'artifact':144,'ggml-region':145,'graph-batch':77,'append':190})
def recipe(tag):
    out=S/'recipes'/f'{tag}.json'
    if out.exists():return out
    if tag in ['ggml-provider','cublas','cccl','artifact','ggml-region']:
        obj=Path(BASE_PLAN['inputs'][INDEX[tag]]['path'])
        candidates=[obj.parent/'identity.json',*obj.parent.glob('*identity.json')]
        matching=[]
        for path in dict.fromkeys(candidates):
            if not path.exists():continue
            rec=c.read(path)
            if c.key(rec.get('object',{}).get('path',''))==c.key(obj):matching.append((path,rec))
        assert matching,(tag,obj)
        original=matching[0][1]
    else:
        original=c.read(R/'.scratch/qwen-mtp-quality-20261022/compile1/hyle/identity.json')if tag=='prefix'else c.read(m.recipe('graph-test'if tag=='graph-test'else 'executable'))
    original['command']=[{'-MD':'/MD','-O2':'/O2'}.get(x,x)for x in original['command']]
    original['command']+=['/I'+str(R/'src/graph'),'/I'+str(R/'src/compute'),'/I'+str(R/'src/compute_backend_cuda')]
    c.save(out,original);return out
def compile_one(tag,attempt):
    h.RECIPES[tag]=recipe(tag);h.SOURCES[tag]=SOURCES[tag];h.compile_one(tag,attempt)
def current(tag):
    paths=sorted(S.glob(f'compile*/{tag}/identity.json'),key=lambda x:int(x.parents[1].name[7:]))
    assert paths,tag
    return paths[-1],c.read(paths[-1])
def link(link_attempt,tests=False):
    records=[];replacement={}
    for tag in INDEX:
        path,rec=current(tag)
        assert all(b.identity(x['path'])==x for x in [rec['source'],rec['object'],*rec['dependencies']]),tag
        replacement[c.key(BASE_PLAN['inputs'][INDEX[tag]]['path'])]=rec['object'];records.append(b.identity(path))
    inputs=[replacement.get(c.key(x['path']),x)for x in BASE_PLAN['inputs']]
    command=[replacement.get(c.key(x),{}).get('path',x)for x in BASE_PLAN['command']if not x.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:'))]
    if tests:
        path,rec=current('graph-test');assert all(b.identity(x['path'])==x for x in [rec['source'],rec['object'],*rec['dependencies']])
        main=c.key(c.read(R/'.scratch/qwen-mtp-quality-20261022/compile1/hyle/identity.json')['object']['path'])
        inputs=[x for x in inputs if c.key(x['path'])!=main]
        command=[x for x in command if c.key(x)!=main]
        extra=[rec['object'],c.read(AS/'compile1/cuda-test/identity.json')['object']]
        kernel=R/'.scratch/architecture-refactor-2026-10-18/d4-windows-preparation-2026-10-21/first-decode-startup-2026-10-21/native-fix/tests/attempt1/kernel/cuda-test-kernel.obj'
        extra += [b.identity(kernel),b.identity(R/'.scratch/build-compute-v2-dev/lib/gtest_main.lib'),b.identity(R/'.scratch/build-compute-v2-dev/lib/gtest.lib')]
        inputs=extra+inputs;command[1:1]=[x['path']for x in extra];records.append(b.identity(path))
    assert all(b.identity(x['path'])==x for x in inputs)
    out=S/f'{"tests"if tests else"hyle"}-link{link_attempt}';out.mkdir();(out/'tmp').mkdir()
    image=out/('capture-tests.exe'if tests else'qwen.exe')
    command+=['/OUT:'+str(image),'/MAP:'+str(image.with_suffix('.map')),'/IMPLIB:'+str(image.with_suffix('.lib'))]
    c.save(out/'link-plan.json',dict(command=command,inputs=inputs,compiled_records=records,base=b.identity(BASE/'link-plan.json'),SDK_builds=0,NVCC=0,shaders=0))
    env,_=b.environment(command,[x['path']for x in inputs],out);c.execute('link',command,env,out)
    runtime=c.read(BASE/'runtime-environment.json')
    for x in runtime['staged_dlls']:os.link(x['path'],out/Path(x['path']).name)
    runtime['staged_dlls']=[b.identity(x)for x in out.glob('*.dll')]
    c.save(out/'runtime-environment.json',runtime);c.save(out/'ready.json',dict(image=b.identity(image)))
    print('LINKED',image,flush=True)
def link_prefix(link_attempt):
    root=S/f'hyle-link{link_attempt}';base=c.read(root/'link-plan.json');path,rec=current('prefix')
    assert all(b.identity(x['path'])==x for x in [rec['source'],rec['object'],*rec['dependencies']])
    old=c.key(c.read(R/'.scratch/qwen-mtp-quality-20261022/compile1/hyle/identity.json')['object']['path'])
    inputs=[rec['object']if c.key(x['path'])==old else x for x in base['inputs']]
    command=[rec['object']['path']if c.key(x)==old else x for x in base['command']if not x.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:'))]
    assert all(b.identity(x['path'])==x for x in inputs)
    out=S/f'prefix-link{link_attempt}';out.mkdir();(out/'tmp').mkdir();image=out/'probe.exe'
    command+=['/OUT:'+str(image),'/MAP:'+str(image.with_suffix('.map')),'/IMPLIB:'+str(image.with_suffix('.lib'))]
    c.save(out/'link-plan.json',dict(command=command,inputs=inputs,compiled_record=b.identity(path),SDK_builds=0,NVCC=0,shaders=0))
    env,_=b.environment(command,[x['path']for x in inputs],out);c.execute('link',command,env,out)
    runtime=c.read(root/'runtime-environment.json')
    for x in runtime['staged_dlls']:os.link(x['path'],out/Path(x['path']).name)
    c.save(out/'runtime-environment.json',runtime);c.save(out/'ready.json',dict(image=b.identity(image)))
    print('LINKED prefix',flush=True)
if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('actions',nargs='+',choices=[*SOURCES,'core','link','link-tests','link-prefix']);p.add_argument('--attempt',type=int,default=1);p.add_argument('--link-attempt',type=int,default=1);a=p.parse_args();(S/'recipes').mkdir(exist_ok=True)
    for tag in a.actions:
        if tag=='core':
            for item in INDEX:compile_one(item,a.attempt)
        elif tag=='link':link(a.link_attempt)
        elif tag=='link-tests':link(a.link_attempt,True)
        elif tag=='link-prefix':link_prefix(a.link_attempt)
        else:compile_one(tag,a.attempt)
