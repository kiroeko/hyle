"""One current CUDA complete-prefix/state regression; no throughput claim."""
from pathlib import Path
import argparse,importlib.util,os,sys
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent;R=S.parents[1]
sp=importlib.util.spec_from_file_location('au_prefix_helpers',R/'.scratch/qwen-mtp-quality-20261022/run_quality.py')
h=importlib.util.module_from_spec(sp);sp.loader.exec_module(h)
image=h.read(S/'prefix-link2/ready.json')['image'];assert h.ident(image['path'])==image
env=os.environ.copy();env['PATH']=h.read(S/'prefix-link2/runtime-environment.json')['PATH']
out=S/'prefix-run1';command=[image['path'],'--inputs',str(R/'.scratch/qwen-mtp-weights-20261022/prepared'),
    '--scenario','prefix','--output',str(out/'vectors')]
p=argparse.ArgumentParser();p.add_argument('--analyze',action='store_true');args=p.parse_args()
process=h.read(out/'process.json')if args.analyze else h.execute(command,env,out,timeout=120)
assert process['exit']==0 and not process['timed_out'],process
result=h.read(out/'vectors/observation.json')
assert result['status']=='PASS_BYTE_EXACT',result.get('error')
assert result['actual_graph_calls']==15 and len(result['vectors'])==534
assert result['all_vectors_byte_equal']and result['old_prefix_full_byte_checks']==7 and result['final_live_snapshot_versions']==0
h.save(out/'summary.json',dict(process=process,image=image,observation=result,
    scope='Current CUDA actual prefix/branch/negative retry, complete byte payloads against same actual partition references; not all models or model quality.'))
print('PREFIX',result['status'],result['actual_graph_calls'],len(result['vectors']),flush=True)
