"""Archive the completed exact cleanup and audit publication without native runs."""
from pathlib import Path
import hashlib,json,zipfile
S=Path(__file__).resolve().parent;R=S.parents[1]
OUT=R/'docs/evidence/performance/qwen-capture-variants-2026-10-22.json'
ZIP=OUT.with_suffix('.logs.zip')
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def ident(p):
    raw=p.read_bytes()
    return dict(path=str(p.relative_to(R)),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
record=read(OUT)
for source in record['implementation']['product_changes']:
    assert ident(R/source['path'])==source
cleanup=read(S/'cleanup-result.json')
assert cleanup['CurrentImageRetained'] and cleanup['Bytes']==936161854
assert len(cleanup['Removed'])==332
for row in cleanup['Removed']:
    assert not Path(row['path']).exists()
    if row.get('retained_reference'):
        p=Path(row['retained_reference']['path'])
        assert ident(p)['sha256']==row['sha256']
assert ident(Path(record['provenance']['image']['path']))['sha256']==record['provenance']['image']['sha256']
with zipfile.ZipFile(ZIP,'a',compression=zipfile.ZIP_DEFLATED,compresslevel=9)as z:
    for p in [S/'prepare_cleanup.py',S/'cleanup-plan.json',S/'cleanup-result.json',Path(__file__).resolve()]:
        name=p.relative_to(S).as_posix()
        assert name not in z.namelist()
        z.write(p,name)
    z.write(R/'test.ps1','cleanup/test.ps1')
with zipfile.ZipFile(ZIP)as z:
    assert z.testzip() is None
    assert len(z.namelist())==len(set(z.namelist()))
record['cleanup']=dict(deleted_files=332,deleted_bytes=cleanup['Bytes'],
    current_uninstrumented_image_and_map_retained=True,
    previous_complete_prefix_payloads_retained=True,
    receipt=ident(S/'cleanup-result.json'),script=ident(R/'test.ps1'))
record['archived_logs']=ident(ZIP)
OUT.write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
(S/'publication-receipt.json').write_text(json.dumps(dict(evidence=ident(OUT),logs=ident(ZIP),
    cleanup=record['cleanup'],goal_complete=False),indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(evidence=ident(OUT),logs=ident(ZIP),removed_bytes=cleanup['Bytes'],goal_complete=False),indent=2))
