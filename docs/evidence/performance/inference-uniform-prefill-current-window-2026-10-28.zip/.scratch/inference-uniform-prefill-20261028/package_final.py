"""One offline final archive. Root executes only after reviewing the receipt scope.

No compiler, native process, SSH, network, cleanup, or earlier packager is called.
"""
from pathlib import Path
import datetime
import difflib
import hashlib
import importlib.util
import json
import math
import re
import statistics
import zipfile

W = Path(__file__).resolve().parent
R = Path(r'C:\public\project-hyle\hyle')
OUT = R / 'docs/evidence/performance/inference-uniform-prefill-current-window-2026-10-28'
BASE = R / '.scratch/inference-program-io-window-20261028'
STAGES = (('single', 'ordinary'), ('single', 'mtp'), ('two-turn', 'ordinary'), ('two-turn', 'mtp'))
spec = importlib.util.spec_from_file_location('prior_offline_receipt_helpers', BASE / 'package.py')
t = importlib.util.module_from_spec(spec); spec.loader.exec_module(t)
read, pin, exact, triple, mib = t.read, t.pin, t.exact, t.triple, t.mib
ALLOWED = {'.json', '.py', '.log', '.txt', '.csv', '.cc', '.h', '.tsv', '.diff'}
RAW = ('command.json', 'result.json', 'stdout.log', 'stderr.log', 'consumer-result.json',
       'memory.json', 'relay-evidence.json', 'timing-partition-gate.json', 'result-schema-adapter.json')


def save(path, value):
    path = Path(path); assert not path.exists(), 'Never overwrite released evidence or the first receipt'
    path.write_bytes((json.dumps(value, indent=2, ensure_ascii=False, allow_nan=False) + '\n').encode('utf-8'))


def group(scenario, role, mode):
    return W / (scenario + '-' + role + '-' + mode)


def collect():
    summary = read(W / 'summary-continuations.json')
    assert summary['status'] == 'COMPLETE_DISTINCT_CONTINUATIONS'
    assert (summary['processes'], summary['timing_processes'], summary['independent_memory_processes']) == (32, 24, 8)
    ready, binding = read(W / 'ready-model.json'), read(W / 'binding.json')
    control = read(binding['control']['ready']['path'])
    assert ready['compiled']['source']['sha256'] == 'ad461d9776f15dedd3acf952d138774b788d6f735f444a2cea02309e11a71a43'
    assert control['compiled']['snapshot']['sha256'] == '9b6be9e7e6158eeb0a09bc4187ec0380eb63c4cdea3e2e7d06af1655c6f104e0'
    for item in (ready, control):
        assert item['compiled']['process']['exit'] == item['process']['exit'] == 0
        for key in ('image', 'inputs', 'recipe', 'runtime', 'source_freeze'): exact(item[key])
        for key in ('snapshot', 'command', 'dependencies', 'actual_dependencies'): exact(item['compiled'][key])
    a, b = read(control['inputs']['path']), read(ready['inputs']['path'])
    assert len(a) == len(b) == 229
    assert [(x, y) for x, y in zip(a, b) if x != y] == [(control['compiled']['object'], ready['compiled']['object'])]
    records, processes, omitted = {}, [], []
    for scenario, role in STAGES:
        for mode in ('timing', 'memory'):
            directory = group(scenario, role, mode)
            result = read(directory / 'analysis-continuations.json')
            rows = read(directory / 'runs-continuations.json')
            plan = read(W / (directory.name + '-plan.json'))
            assert result['status'] == 'COMPLETE_DISTINCT_CONTINUATIONS'
            assert len(rows) == len(plan['commands']) == (6 if mode == 'timing' else 2)
            assert all(v['stable'] for v in result['within_variant_complete_non_time'].values())
            for row, expected in zip(rows, plan['commands']):
                folder = Path(row['folder']); process = read(folder / 'result.json'); raw = read(folder / 'consumer-result.json')
                assert process == row['process'] and process['exit'] == 0
                assert not any(process.get(k) for k in ('timeout', 'timed_out', 'reader_errors'))
                assert process['command'] == expected['command'] and process['image'] == expected['image']
                assert process['memory_only'] == (mode == 'memory')
                assert row['observation']['raw'] == raw
                assert read(folder / 'timing-partition-gate.json')['status'] == 'PASS'
                assert math.isclose(raw['prefill_seconds'] + raw['decode_seconds'], raw['session_seconds'], rel_tol=1e-5, abs_tol=2e-6)
                processes.append(dict(scenario=scenario, role=role, mode=mode, variant=row['variant'],
                    ordinal=row['window_ordinal'], pid=process['pid'], exit=process['exit'],
                    started_unix_ns=process['started_unix_ns'], finished_unix_ns=process['finished_unix_ns'],
                    actual={key: raw[key] for key in ('generated_tokens', 'generated_decode_tokens', 'actual_target_rows',
                        'actual_draft_rows', 'verified_target_rows', 'committed_target_rows', 'prefill_target_rows',
                        'accepted_drafts', 'consumed_drafts', 'pending_flushed_tokens', 'packed_prefill_calls') if key in raw},
                    complete_report=pin(folder / 'consumer-result.json')))
                for name in ('observation.json', 'memory-summary.json'):
                    if (folder / name).exists(): omitted.append(pin(folder / name))
            for variant in ('control', 'candidate'):
                selected = [row for row in rows if row['variant'] == variant]
                facts = [t.non_time(row['observation']['raw']) for row in selected]
                assert all(f == facts[0] for f in facts)
                if mode == 'timing':
                    for key, stats in result['groups'][variant].items():
                        values = [row['observation']['metrics'][key] for row in selected if row['observation']['metrics'][key] is not None]
                        if stats is None: assert not values; continue
                        assert stats['count'] == len(values)
                        for value, label in ((statistics.median(values), 'median'), (min(values), 'min'), (max(values), 'max')):
                            assert math.isclose(value, stats[label], rel_tol=1e-12)
            records[(scenario, role, mode)] = result
            for name in ('analysis-continuations.json', 'runs-continuations.json', 'inputs.json', 'runs.json'):
                if (directory / name).exists(): omitted.append(pin(directory / name))
    assert len(processes) == len({row['ordinal'] for row in processes}) == len({row['pid'] for row in processes}) == 32
    actual = sorted(processes, key=lambda row: row['started_unix_ns'])
    assert all(a['finished_unix_ns'] <= b['started_unix_ns'] for a, b in zip(actual, actual[1:]))
    first = read(W / 'single-ordinary-timing/summary.json')
    assert first['status'] == 'PRESERVED_FACT_DIFFERENCES'
    assert len(first['unexpected_differences']) == 569 and len(first['expected_route_fact_differences']) == 6
    return summary, ready, control, binding, records, processes, omitted


def supplemental():
    numeric = read(W / 'numeric/analysis.json'); assert numeric['status'] == 'RECORDED_COMMON_PREFIX_NUMERICAL_DIFFERENCE'
    assert numeric['first18_outputs_equal'] and not numeric['output19_equal']
    numerical_processes = []
    selected = []
    for variant in ('control', 'candidate'):
        process = read(W / 'numeric' / variant / 'process.json')
        assert process['exit_code'] == 0 and process['termination_reason'] is None
        numerical_processes.append(dict(variant=variant, **process))
        for row in numeric['trace_files'][variant]:
            p = Path(row['path'])
            if p.parent.name in ('prefill', 'decode18'):
                exact(row); selected.append(row)
    assert len(selected) == 8 and sum(row['bytes'] for row in selected) == 3_989_504
    raw = read(W / 'raw-math/checked.json'); case = raw['case']
    assert raw['process']['exit'] == 0 and case['status'] == 'PASS' and len(case['steps']) == 8
    assert case['numerically_equivalent'] and case['old_checkpoints_byte_unchanged'] and case['rng_and_epochs_equal']
    assert case['numerical_budget']['absolute'] == 3e-6 and case['numerical_budget']['other_payloads'] == 'byte_exact'
    assert all(row['numerically_equivalent'] and row['boundary_equal'] and row['exact_next'] == row['bucket_next'] for row in case['steps'])
    maximum = max((diff['maximum_absolute'] for row in case['steps'] for diff in row['differences']), default=0)
    functional = read(W / 'functional/analysis.json')
    assert functional['schema'] == 'hyle.uniform-prefill.finite-packed-policies.v1'
    assert functional['status'] == 'PASS_FINITE_PACKED_POLICIES_OFFLINE_POSTCHECK'
    assert functional['native_processes'] == 3 and functional['native_reruns'] == 0 and len(functional['cases']) == 3
    for row in functional['cases']:
        assert row['process']['exit'] == 0
        assert row['report']['packed_prefill_calls'] == row['expected']['packed_calls']
        assert row['report']['prefill_target_rows'] == row['expected']['rows']
    prefix = next(row for row in functional['cases'] if row['name'] == 'prefix-scheduler')['report']
    assert prefix['live_committed_versions'] == prefix['prefix_entries'] == 1 and prefix['retired_requests'] == 1
    assert prefix['prefix_hits'] == prefix['reused_tokens'] == 0
    return dict(numerical_model_processes=numerical_processes, decision0=numeric['decisions'][0], decision18=numeric['decisions'][18],
        complete_statistics=pin(W / 'numeric/analysis.json'), all_trace_vector_pins=numeric['trace_files'], selected_vectors=selected,
        trace_bytes_retained=sum(row['bytes'] for row in selected), omitted_trace_payload_bytes=sum(row['bytes'] for values in numeric['trace_files'].values() for row in values) - sum(row['bytes'] for row in selected),
        raw_math=dict(process=raw['process'], cached_image=raw['image'], scope=raw['scope'], checks=8,
            GDN_F32_absolute_tolerance=3e-6, maximum_observed=maximum, other_payloads='byte_exact', old_checkpoints_unchanged=True, RNG_epochs_equal=True,
            same_as_new_natural_policy_claim=False, complete_model_FP64_oracle=False),
        functional=functional, trained_quality_equivalence_proven=False,
        limits=['Raw math is the existing cached synthetic consumer, not the new natural policy or a complete-model FP64 oracle.',
            'The real-model trace measures hidden/logit differences under the common prefix and an index18 near-tie decision flip; it is not quality equivalence.',
            'The prefix/scheduler native process succeeded; original observer incorrectly expected live0 while its real prefix payload owns1. No cache hit/reuse was observed.'])


def main():
    assert not OUT.with_suffix('.json').exists() and not OUT.with_suffix('.zip').exists(), 'One final package only'
    summary, ready, control, binding, records, processes, omitted = collect()
    supplements = supplemental()
    numerical_pids = [row['pid'] for row in supplements['numerical_model_processes']]
    supplemental_pids = numerical_pids + [supplements['raw_math']['process']['pid']] + [row['process']['pid'] for row in supplements['functional']['cases']]
    assert len(set(supplemental_pids + [row['pid'] for row in processes])) == 38
    timing = []; memory = []; consistency = []
    for scenario, role in STAGES:
        timed, monitored = records[(scenario, role, 'timing')], records[(scenario, role, 'memory')]
        route_only = all(re.fullmatch(r'\$\.(?:sessions\[\d+\]\.result\.)?packed_prefill_(?:calls|active_rows|physical_rows)', row['path'])
            and row['old'] > 0 and row['new'] == 0 for row in timed['cross_variant_complete_non_time_differences'])
        consistency.append(dict(scenario=scenario, role=role, generated_IDs_equal=timed['cross_variant_generated_IDs_equal'],
            first_ID_difference=timed['first_ID_difference'], all_turn_inputs_equal=timed['common_task']['all_turn_input_IDs_equal'],
            complete_non_time_difference_count=timed['cross_variant_difference_count'],
            only_packed_route_facts_differ=route_only,
            IDs_acceptance_work_and_other_report_facts_equal=route_only and timed['cross_variant_generated_IDs_equal'],
            within_each_variant_complete_report_stable=True, all_differences_retained_in_summary=True))
        for variant in ('control', 'candidate'):
            stats = timed['groups'][variant]; mem = monitored['groups'][variant]; peaks = mem['sampled_peaks']
            timing.append(dict(scenario=scenario, role=role, variant=variant,
                prefill_tps=triple(stats.get('prefill_tokens_per_second')), decode_tps=triple(stats.get('full_decode_tokens_per_second')),
                session_output_tps=triple(stats.get('session_output_tokens_per_second')), session_processed_tps=triple(stats.get('session_processed_tokens_per_second')),
                ready_seconds=triple(stats.get('startup_to_ready_seconds')), first_token_seconds=triple(stats.get('first_token_elapsed_seconds'))))
            memory.append(dict(scenario=scenario, role=role, variant=variant, processes=1,
                GPU_dedicated_MiB=mib(peaks['sampled_peak_gpu_dedicated_bytes']), GPU_shared_MiB=mib(peaks['sampled_peak_gpu_shared_bytes']),
                GPU_same_sample_total_MiB=mib(peaks['sampled_peak_gpu_total_bytes']), RAM_working_set_MiB=mib(peaks['sampled_max_working_set_bytes']),
                RAM_private_commit_MiB=mib(peaks['sampled_max_private_commit_bytes']), ready_baseline=mem['ready_baseline'],
                actual_sample_gap_ms={key: mem['actual_sample_gaps_ms'].get(key) for key in ('median', 'min', 'max')}, null_samples=mem['null_sample_counts']))
    zone = datetime.timezone(datetime.timedelta(hours=8))
    interval = [datetime.datetime.fromtimestamp(value / 1e9, zone).isoformat() for value in
        (min(row['started_unix_ns'] for row in processes), max(row['finished_unix_ns'] for row in processes))]
    receipt = dict(schema='hyle.performance.uniform-prefill.current-window.v1', date='2026-10-28', status='COMPLETE_DISTINCT_CONTINUATIONS',
        scope='Intra-Hyle current229 control8489 vs candidatebb0c. Same task/config/precision/weights and firstP154 input. All cross-variant output/acceptance/row/ledger differences retained; no new peer/window comparison.',
        counts=dict(CXX=1, links=1, SDK_CXX=0, NVCC=0, downloads=0, window_native_processes=32, timing=24, independent_memory=8,
            numerical_traces=2, cached_raw_math=1, functional=3, total_native_processes=38, native_failures=0, native_reruns=0),
        window_Beijing_interval=interval, control_image=control['image'], candidate_image=ready['image'],
        closure=dict(inputs_each=229, replacements=binding['replacements'], candidate_ready=pin(W / 'ready-model.json'),
            control_ready=binding['control']['ready'], candidate_source=ready['compiled']['snapshot'], control_source=control['compiled']['snapshot'],
            candidate_actual_dependencies=ready['compiled']['actual_dependencies'], runtime=ready['runtime']),
        timing_arrays='[median,min,max], three unmonitored native processes per version/scenario/mode; no significance claim.',
        timing_table=timing, observed_median_comparison=summary['observed_comparisons'], memory_units='MiB (2^20 bytes)', memory_table=memory,
        consistency=consistency, actual_work_and_processes=processes,
        interpretation=['First single-turn prefill uses exactly the sameP154 input and can support a local prefill implementation observation.',
            'Ordinary continuation changes at index18; decode and two-turn/full-workflow intervals are observed outcomes, not same-work code gains. Later-turn pending IDs may differ.',
            'MTP same-ID/work observations, where present, are explicitly reported in consistency; this does not erase ordinary differences or prove trained quality.',
            'All32 processes ran once, including initial6 reused offline after the strict comparator failed. No cross-version difference whitelist was broadened.',
            'Dedicated/shared, working-set/commit are distinct sampled quantities; requested10ms is not actual interval, null readiness stays unknown, peaks are lower bounds.'],
        supplemental=supplements,
        observer_and_parser_notes=[dict(kind='strict_complete_report_observer', native_processes_succeeded=6, original_expected_route_differences=6,
            original_unexpected_differences=569, raw_and_original_analysis_unchanged=True),
            dict(kind='two_turn_parser_preparation', native_exit=0, reason='Imported WORKLOAD remained single and rejected128 real output IDs under64-output contract.',
                remedy='New wrapper selects original two-turn parser before parse/helpers; successful control1 parsed offline, only missing tail5 launched.', receipt=pin(W / 'workload-parser-amendment.json')),
            dict(kind='functional_prefix_observer', native_exit=0, expected_live=0, actual_prefix_owned_live=1,
                remedy='Offline postcheck of real prefix owner and retired Session; original helper/raw kept, no rerun.', receipt=pin(W / 'functional/analysis.json'))],
        limitations=['No latest-upstream peer, cross-engine gain, full trained-quality equivalence, full-model FP64 equivalence, or all-platform conclusion.',
            'Numerical trace instrumentation is excluded from timing samples. Eight finite raw-math comparisons use the existing GDN3e-6 contract; other payload/checkpoints/RNG/epochs remain exact.',
            'No zero substitute for unmeasured/unknown counters. No pooling of old8489/b59 windows or summation of overlapping step lifetimes.'])
    # Single source diff, never edit a product source or an old frozen snapshot.
    a = Path(control['compiled']['snapshot']['path']).read_text(encoding='utf-8-sig')
    b = Path(ready['compiled']['snapshot']['path']).read_text(encoding='utf-8-sig')
    (W / 'source-delta.diff').write_text(''.join(difflib.unified_diff(a.splitlines(True), b.splitlines(True), fromfile='control/main.cc', tofile='candidate/main.cc')), encoding='utf-8', newline='\n')
    save(W / 'archive-derived-references.json', dict(omitted_duplicate_derived_files=omitted,
        policy='Keep original full producer/stdio/command/process and memory samples plus the final all-difference summary. Repeated observation/run/analysis copies are SHA-referenced instead of duplicated4 times.'))
    paths = set()
    # Current build/source scripts and receipts; no SDK binary traversal.
    for directory in (W, W / 'source', W / 'compile', W / 'logs', W / 'link', W / 'functional', W / 'raw-math', W / 'numeric'):
        candidates = directory.iterdir() if directory == W else directory.rglob('*')
        for path in candidates:
            if path.is_file() and path.suffix.lower() in ALLOWED and path.name not in ('package_partial.py',): paths.add(path.resolve())
    for scenario, role in STAGES:
        for mode in ('timing', 'memory'):
            directory = group(scenario, role, mode)
            for p in directory.glob('window-*'):
                if p.is_file() and p.suffix.lower() in ALLOWED: paths.add(p.resolve())
            for entry in read(W / (directory.name + '-plan.json'))['commands']:
                folder = Path(entry['folder'])
                paths.update((folder / name).resolve() for name in RAW if (folder / name).is_file())
    paths.update((W / 'single-ordinary-timing' / name).resolve() for name in ('summary.json', 'complete-non-time-differences.json'))
    paths.update(Path(row['path']).resolve() for row in supplements['selected_vectors'])
    paths.add(Path(control['compiled']['snapshot']['path']).resolve())
    paths.update(Path(control[key]['path']).resolve() for key in ('inputs', 'recipe', 'source_freeze'))
    paths.update(Path(control['compiled'][key]['path']).resolve() for key in ('command', 'dependencies', 'actual_dependencies'))
    paths.add(Path(binding['control']['ready']['path']).resolve())
    assert all(path.is_file() and path.is_relative_to(R) for path in paths)
    assert all(path.suffix.lower() in ALLOWED or path in {Path(row['path']).resolve() for row in supplements['selected_vectors']} for path in paths)
    manifest = [dict(member=path.relative_to(R).as_posix(), **pin(path)) for path in sorted(paths)]
    save(W / 'final-manifest.json', dict(files=manifest, selected_trace_bytes=supplements['trace_bytes_retained'],
        excluded='EXE/OBJ/PDB/DLL/LIB/EXP/SDK/model weights; other34MB trace vectors kept by statistics/SHA only; duplicate derived producer copies.'))
    save(W / 'final-evidence-summary.json', receipt)
    OUT.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(OUT.with_suffix('.zip'), 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for row in manifest: archive.write(row['path'], row['member'])
        for path in (W / 'final-manifest.json', W / 'final-evidence-summary.json'): archive.write(path, path.relative_to(R).as_posix())
    with zipfile.ZipFile(OUT.with_suffix('.zip')) as archive:
        assert archive.testzip() is None and len(archive.namelist()) == len(manifest) + 2
        for row in manifest:
            body = archive.read(row['member']); assert len(body) == row['bytes'] and hashlib.sha256(body).hexdigest() == row['sha256']
        assert json.loads(archive.read((W / 'final-evidence-summary.json').relative_to(R).as_posix())) == receipt
    receipt['archive'] = dict(**pin(OUT.with_suffix('.zip')), members=len(manifest) + 2)
    t.compact(OUT.with_suffix('.json'), receipt)
    assert read(OUT.with_suffix('.json')) == receipt
    save(W / 'final-package-result.json', dict(status='PACKAGED_AND_READ_BACK_VERIFIED', receipt=pin(OUT.with_suffix('.json')),
        archive=receipt['archive'], new_model_or_compiler_processes=0))
    print(json.dumps(read(W / 'final-package-result.json')))


if __name__ == '__main__':
    main()
