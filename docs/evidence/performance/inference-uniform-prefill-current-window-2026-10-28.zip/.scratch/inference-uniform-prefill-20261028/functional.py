"""Three finite natural-entry cases for preserved packed policies."""
from pathlib import Path
import importlib.util
import json
import sys
sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('retained_native_runner', W.parent / 'inference-indexed-store-20261028/build.py')
t = importlib.util.module_from_spec(spec); spec.loader.exec_module(t); t.W = W
ready = t.read(W / 'ready-model.json'); t.exact(ready['image'])
fixture = W.parent / 'inference-paged-frame-20261026/tiny-recursive-input'
root = W / 'functional'; root.mkdir(exist_ok=True)
assert not any(root.iterdir()), 'Preserve every attempted native case'
prompt = fixture / 'prompt.ids'; tokens = prompt.read_text().split()
assert len(tokens) == 3
schedule = root / 'two-turn.txt'
schedule.write_text(('prompt ' + prompt.as_posix() + '\ngenerate 2\n') * 2)
common = [ready['image']['path'], '--inputs', str(fixture), '--capacity', '16',
          '--max-sessions', '1', '--active-sequences', '1', '--backend', 'cuda',
          '--sampling', 'greedy', '--decode-overlap', 'auto']
cases = [('bounded-ordinary', ['--steps', '2', '--mtp', 'off', '--prefix-cache', 'off', '--prefill-chunk-tokens', '2']),
         ('bounded-mtp', ['--steps', '2', '--mtp', 'on', '--prefix-cache', 'off', '--prefill-chunk-tokens', '2']),
         ('prefix-scheduler', ['--schedule', str(schedule), '--mtp', 'off', '--prefix-cache', 'auto', '--progress', 'scheduler'])]
t.save(root / 'plan.json', dict(image=ready['image'], fixture_manifest=t.pin(fixture / 'weights.tsv'),
    schedule=t.pin(schedule), commands=[dict(name=name, command=common + args) for name, args in cases],
    scope='Current candidate natural entry, bounded ordinary/MTP and prefix/scheduler retain real packed routes; no quality or performance conclusion.'))
results = []
for name, args in cases:
    t.execute(common + args, root / name, 120)
    values = [json.loads(line) for line in (root / name / 'stdout.log').read_text().splitlines() if line.startswith('{')]
    assert len(values) == 1
    report = values[0]
    assert report['packed_prefill_calls'] > 0 and report['live_committed_versions'] == 0
    assert report['prefill_target_rows'] == (3 if name.startswith('bounded') else 7)
    results.append(dict(name=name, process=t.read(root / name / 'process.json'), report=report))
    print(name, 'PASS', 'packed', report['packed_prefill_calls'], 'rows', report['prefill_target_rows'])
t.save(root / 'results.json', dict(status='PASS_FINITE_PACKED_POLICIES', cases=results))
