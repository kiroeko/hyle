"""One cached raw-math consumer; does not exercise the new natural policy."""
from pathlib import Path
import importlib.util
import json
import sys
sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('retained_native_runner', W.parent / 'inference-indexed-store-20261028/build.py')
t = importlib.util.module_from_spec(spec); spec.loader.exec_module(t); t.W = W
case = t.read(W / 'numeric/plan.json')['optional_raw_math_case_not_automatically_run']
for field in ('ready', 'image', 'manifest'): t.exact(case[field])
t.execute(case['command'], W / 'raw-math', 120)
rows = [json.loads(line) for line in (W / 'raw-math/stdout.log').read_text().splitlines() if line.startswith('{')]
assert rows and rows[-1]['status'] == 'PASS'
t.save(W / 'raw-math/checked.json', dict(scope=case['scope'], oracle=case['oracle'],
    case=rows[-1], process=t.read(W / 'raw-math/process.json'), image=case['image'],
    limitations='Cached raw consumer, unchanged raw math; not the new natural policy or real-model quality.'))
print(json.dumps(rows[-1]))
