"""Offline ID ancestry only. No inference, numerical tolerance, or speed qualification."""
from pathlib import Path
import hashlib
import json

W = Path(__file__).resolve().parent
R = Path(r'C:\public\project-hyle\hyle')


def read(path):
    return json.loads(Path(path).read_bytes())


def pin(path):
    path = Path(path).resolve(); body = path.read_bytes()
    return dict(path=str(path), bytes=len(body), sha256=hashlib.sha256(body).hexdigest())


def main():
    destination = W / 'numeric-qualification.json'
    assert not destination.exists(), 'Preserve the first offline qualification'
    specs = (
        ('newAB', W / 'single-ordinary-timing-plan.json', ('control', 'candidate')),
        ('current40', R / '.scratch/inference-program-io-window-20261028/single-timing-plan.json',
            ('hyle_plain', 'hyle_auto', 'hyle_mtp', 'peer_plain', 'peer_mtp')),
        ('historical40', R / '.scratch/inference-hidden-state-window-20261028/attempt1/single-timing-plan.json',
            ('hyle_plain', 'hyle_auto', 'hyle_mtp', 'peer_plain', 'peer_mtp')))
    reports = {}
    for label, plan, names in specs:
        entries = read(plan)['commands']
        for name in names:
            entry = next(row for row in entries if row.get('variant', row['arm']) == name)
            source = Path(entry['folder']) / 'consumer-result.json'
            ids = read(source)['generated_ids']
            assert len(ids) == 64
            reports[label + '/' + name] = dict(generated_ids=ids, report=pin(source), image=entry['image'])
    candidate = reports['newAB/candidate']['generated_ids']
    comparisons = []
    for label, row in reports.items():
        ids = row['generated_ids']; mismatch = next((i for i, (a, b) in enumerate(zip(candidate, ids)) if a != b), None)
        comparisons.append(dict(reference=label, candidate_tokens=len(candidate), reference_tokens=len(ids),
            all_IDs_equal=candidate == ids, first_difference_index=mismatch,
            candidate_at_first_difference=None if mismatch is None else candidate[mismatch],
            reference_at_first_difference=None if mismatch is None else ids[mismatch]))
    assert candidate == reports['historical40/hyle_plain']['generated_ids'] == reports['historical40/hyle_auto']['generated_ids']
    assert candidate == reports['current40/peer_mtp']['generated_ids'] == reports['historical40/peer_mtp']['generated_ids']
    assert comparisons[0]['first_difference_index'] == 18
    stage = read(W / 'single-ordinary-timing/summary.json')
    assert stage['status'] == 'PRESERVED_FACT_DIFFERENCES'
    assert len(stage['expected_route_fact_differences']) == 6 and len(stage['unexpected_differences']) == 569
    result = dict(status='BLOCKED_NUMERICAL_QUALIFICATION_UNRESOLVED', interpretation='ID ancestry is confirmed; current exact/packed state/logit equivalence is not established by matching any old continuation.',
        reports=reports, candidate_comparisons=comparisons,
        blocked_stage=dict(actual_successful_native_processes=6, within_each_variant_complete_non_time_stable=True,
            expected_route_differences=6, unexpected_full_fact_differences=569, first_generated_ID_difference_index=18,
            control_ID=11, candidate_ID=271, subsequent_processes_started=0, planned_remaining=26),
        limits=['Historical reports are used only for ID comparison, never timing samples or reference speed estimates.',
            'No full state tensors or pre-divergence logits were measured in these six performance processes.',
            'The same first18 output IDs and an old64-ID match do not prove hidden-state/logit tolerance, quality, or current correctness.',
            'Decode/session intervals follow different continuations and cannot establish a same-work code speedup.',
            'No oracle whitelist, native output, frozen source, command, or first failure was changed.'])
    destination.write_bytes((json.dumps(result, indent=2, ensure_ascii=False) + '\n').encode('utf-8'))
    print('OFFLINE ancestry confirmed; numerical qualification remains BLOCKED; no native process')


if __name__ == '__main__':
    main()
