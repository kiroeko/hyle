"""Thirty-two fresh intra-Hyle observations; only explicit run starts a model."""
from pathlib import Path
import copy
import importlib.util
import json
import os
import re
import sys
import time
import traceback

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = Path(r'C:\public\project-hyle\hyle')
OLD = R / '.scratch/inference-program-io-window-20261028'
spec = importlib.util.spec_from_file_location('retained_current_window', OLD / 'window.py')
f = importlib.util.module_from_spec(spec); spec.loader.exec_module(f)
b = f.base
read, pin = b.read, b.identity
STAGES = (('single', 'ordinary'), ('single', 'mtp'), ('two-turn', 'ordinary'), ('two-turn', 'mtp'))
METRICS = ('prefill_tokens_per_second', 'full_decode_tokens_per_second', 'session_output_tokens_per_second', 'session_processed_tokens_per_second')
PACKED = re.compile(r'^\$\.(?:sessions\[\d+\]\.result\.)?packed_prefill_(?:calls|active_rows|physical_rows)$')


def save(path, value):
    path = Path(path); path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('x', encoding='utf-8') as stream:
        stream.write(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + '\n')


def exact(row):
    assert pin(row['path']) == row, row['path']


def folder_name(scenario, role, mode):
    return scenario + '-' + role + '-' + mode


def prepare():
    assert not (W / 'plan.json').exists(), 'Preserve every preparation and attempt'
    control_path, candidate_path = OLD / 'ready-model.json', W / 'ready-model.json'
    control, candidate = read(control_path), read(candidate_path)
    assert control['image']['sha256'] == '8489d558eb7b6c732cd908f2764467a6446c3981301c5456191ac7a4cfc5d980'
    for ready in (control, candidate):
        assert ready['compiled']['process']['exit'] == ready['process']['exit'] == 0
        for field in ('image', 'inputs', 'recipe', 'runtime', 'source_freeze'): exact(ready[field])
        for field in ('snapshot', 'command', 'dependencies', 'actual_dependencies'): exact(ready['compiled'][field])
    control_rows, candidate_rows = read(control['inputs']['path']), read(candidate['inputs']['path'])
    assert len(control_rows) == len(candidate_rows) == 229
    changes = [dict(control=a, candidate=c) for a, c in zip(control_rows, candidate_rows) if a != c]
    assert changes == [dict(control=control['compiled']['object'], candidate=candidate['compiled']['object'])]
    runtime = candidate['runtime']
    assert read(runtime['path'])['native'] == read(control['runtime']['path'])['native']
    old_binding = read(OLD / 'binding.json')
    binding = dict(control=dict(ready=pin(control_path), image=control['image'], source=control['compiled']['snapshot'],
            inputs=control['inputs'], recipe=control['recipe'], compiled=control['compiled']),
        candidate=dict(ready=pin(candidate_path), image=candidate['image'], source=candidate['compiled']['snapshot'],
            inputs=candidate['inputs'], recipe=candidate['recipe'], compiled=candidate['compiled']),
        object_count_each=229, replacements=changes, runtime=runtime,
        protocol=pin(OLD / 'window.py'), previous_window_reference=pin(OLD / 'plan.json'),
        work={key: old_binding[key] for key in ('prompt', 'input_manifest', 'schedule', 'protocol')},
        expected_difference_contract='Only explicit root/session-result packed_prefill_{calls,active_rows,physical_rows}: positive control -> zero uniform candidate. Every difference is saved; all other non-time facts must equal.',
        scope='Fresh intra-Hyle control8489 versus candidate; same runtime/weights/all228 other objects. No peer/new reference, historical samples, warmup, profiler, download, or inference from old-window TPS.')
    save(W / 'binding.json', binding)
    ordinal = 0; plans = []
    for scenario, role in STAGES:
        mapped = 'hyle_auto' if role == 'ordinary' else 'hyle_mtp'
        for mode in ('timing', 'memory'):
            source = read(OLD / (scenario + '-' + mode + '-plan.json'))
            template = next(row for row in source['commands'] if row['arm'] == mapped)
            cfg = copy.deepcopy(source)
            for field in ('canonical_main', 'retained_plan', 'configuration'): cfg.pop(field, None)
            order = ('control', 'candidate', 'candidate', 'control', 'control', 'candidate') if mode == 'timing' else ('control', 'candidate')
            commands = []; name = folder_name(scenario, role, mode)
            for local, variant in enumerate(order, 1):
                ordinal += 1; image = binding[variant]['image']
                commands.append(dict(ordinal=local, window_ordinal=ordinal, variant=variant, scenario=scenario, role=role, arm=mapped,
                    folder=str(W / name / (f'{local:02d}-' + variant)), command=[image['path'], *template['command'][1:]],
                    image=image, environment=runtime, ready=binding[variant]['ready']))
            cfg.update(mode=mode, commands=commands, arm_order=list(order), binding=pin(W / 'binding.json'), script=pin(__file__),
                timing_processes=6 if mode == 'timing' else 0, memory_processes=2 if mode == 'memory' else 0,
                workload=scenario, processes=len(commands), retained_parser_arm=mapped,
                N=1, R=1, capacity=1024, historical_samples_pooled=False, plan_only=True)
            path = W / (name + '-plan.json'); save(path, cfg)
            plans.append(dict(scenario=scenario, role=role, mode=mode, plan=pin(path)))
    assert ordinal == 32
    save(W / 'plan.json', dict(status='PREPARED32_NOT_RUN', script=pin(__file__), binding=pin(W / 'binding.json'), groups=plans,
        stages=[dict(scenario=s, role=r, processes=8) for s, r in STAGES],
        timing_processes=24, independent_memory_processes=8, total_processes=32, automatic_retries=0,
        scope='Same P154/C1024/greedy/64 natural output quota per turn. Ordinary auto and MTP K1 overlap-off. Each version/scenario/mode3 timing+1 separate memory. First single-ordinary8 gate precedes remaining24, never repeated.'))
    print('PREPARED32: first single ordinary6 timing +2 memory; root owns all native processes')


def config(scenario, role, mode):
    assert (scenario, role) in STAGES and mode in ('timing', 'memory')
    plan = read(W / 'plan.json'); exact(plan['script']); exact(plan['binding'])
    entry = next(row for row in plan['groups'] if (row['scenario'], row['role'], row['mode']) == (scenario, role, mode))
    exact(entry['plan']); return read(entry['plan']['path'])


def parse_one(entry, cfg):
    folder = Path(entry['folder']); process = read(folder / 'result.json')
    assert process['exit'] == 0 and not process.get('reader_errors') and not process.get('timeout') and not process.get('timed_out')
    assert process['command'] == entry['command'] and process['image'] == entry['image'] and process['arm'] == entry['arm']
    observation = f.parse(folder, entry['arm'], cfg)
    b.save(folder / 'observation.json', observation)
    return dict(variant=entry['variant'], scenario=entry['scenario'], role=entry['role'], folder=str(folder),
        window_ordinal=entry['window_ordinal'], process=process, observation=observation)


def expected_difference(row):
    return bool(PACKED.fullmatch(row['path'])) and type(row['old']) is int and row['old'] > 0 and row['new'] == 0


def analyze(scenario, role, mode):
    cfg = config(scenario, role, mode); out = W / folder_name(scenario, role, mode)
    rows = [parse_one(entry, cfg) for entry in cfg['commands']]
    groups = {}; facts = {}; complete = {}
    for variant in ('control', 'candidate'):
        selected = [row for row in rows if row['variant'] == variant]; expect = 3 if mode == 'timing' else 1
        assert len(selected) == expect
        normalized = [f.facts_parser.non_time(row['observation']['raw']) for row in selected]
        changes = [dict(folder=selected[i]['folder'], differences=f.differences(normalized[0], value))
            for i, value in enumerate(normalized[1:], 1) if value != normalized[0]]
        complete[variant] = dict(processes=expect, stable=not changes, changes=changes); facts[variant] = normalized[0]
        if mode == 'timing':
            groups[variant] = {key: b.stats([row['observation']['metrics'][key] for row in selected if row['observation']['metrics'][key] is not None])
                for key in selected[0]['observation']['metrics']}
        else: groups[variant] = read(Path(selected[0]['folder']) / 'memory-summary.json')
    between = f.differences(facts['control'], facts['candidate'])
    expected = [row for row in between if expected_difference(row)]
    unexpected = [row for row in between if not expected_difference(row)]
    b.save(out / 'runs.json', rows); b.save(out / 'complete-non-time-differences.json', between)
    value = dict(status='COMPLETE_STABLE' if not unexpected and all(row['stable'] for row in complete.values()) else 'PRESERVED_FACT_DIFFERENCES',
        scenario=scenario, role=role, mode=mode, processes=len(rows), groups=groups, within_variant_complete_non_time=complete,
        expected_route_fact_differences=expected, unexpected_differences=unexpected,
        all_other_complete_non_time_equal=not unexpected, memory_unknown_values_preserved=True,
        original_endpoints_and_sampler=True, historical_samples_pooled=False)
    b.save(out / 'summary.json', value)
    assert value['status'] == 'COMPLETE_STABLE', 'Preserve actual differences; no replacement samples or broad ignore filter'
    print(value['status'], scenario, role, mode, len(rows)); return value


def stage_gate(scenario, role, mode):
    index = STAGES.index((scenario, role))
    for s, r in STAGES[:index]:
        for m in ('timing', 'memory'):
            assert read(W / folder_name(s, r, m) / 'summary.json')['status'] == 'COMPLETE_STABLE'
    if mode == 'memory':
        assert read(W / folder_name(scenario, role, 'timing') / 'summary.json')['status'] == 'COMPLETE_STABLE'


def run(scenario, role, mode):
    cfg = config(scenario, role, mode); stage_gate(scenario, role, mode)
    out = W / folder_name(scenario, role, mode); assert not out.exists(), 'Never rerun/overwrite any attempt'
    out.mkdir(); save(out / 'inputs.json', cfg)
    runner = b.load_helpers(); runner.gpu_snapshot(out, 'window-before')
    try:
        for entry in cfg['commands']:
            exact(entry['ready']); exact(entry['environment'])
            env = os.environ.copy(); env['PATH'] = read(entry['environment']['path'])['PATH']
            env.update(HF_HUB_OFFLINE='1', TRANSFORMERS_OFFLINE='1', HF_HUB_DISABLE_TELEMETRY='1')
            print('BEGIN', scenario, role, mode, entry['ordinal'], entry['variant'], flush=True)
            runner.execute(Path(entry['folder']), entry['arm'], entry['command'], env, mode == 'memory')
            parse_one(entry, cfg)
            print('END', scenario, role, mode, entry['ordinal'], entry['variant'], flush=True)
    finally: runner.gpu_snapshot(out, 'window-after')
    analyze(scenario, role, mode)


def resume(scenario, role, mode):
    # Explicit parser-only recovery: all existing native processes must already
    # have succeeded. Never overwrite/relaunch one, or retry a native failure.
    cfg = config(scenario, role, mode); stage_gate(scenario, role, mode)
    out = W / folder_name(scenario, role, mode)
    assert read(out / 'inputs.json') == cfg, 'Original command/identity plan changed'
    entries = cfg['commands']; existing = [row for row in entries if Path(row['folder']).exists()]
    assert existing == entries[:len(existing)], 'Existing attempts must be a contiguous prefix'
    assert {p.resolve() for p in out.iterdir() if p.is_dir()} == {Path(row['folder']).resolve() for row in existing}
    for entry in existing:
        process = read(Path(entry['folder']) / 'result.json')
        assert process['exit'] == 0 and not process.get('timeout') and not process.get('reader_errors')
        parse_one(entry, cfg)
    runner = b.load_helpers(); runner.gpu_snapshot(out, 'resume-before')
    try:
        for entry in entries[len(existing):]:
            exact(entry['ready']); exact(entry['environment'])
            env = os.environ.copy(); env['PATH'] = read(entry['environment']['path'])['PATH']
            env.update(HF_HUB_OFFLINE='1', TRANSFORMERS_OFFLINE='1', HF_HUB_DISABLE_TELEMETRY='1')
            print('BEGIN_REMAINING', scenario, role, mode, entry['ordinal'], entry['variant'], flush=True)
            runner.execute(Path(entry['folder']), entry['arm'], entry['command'], env, mode == 'memory')
            parse_one(entry, cfg)
    finally: runner.gpu_snapshot(out, 'resume-after')
    analyze(scenario, role, mode)


def summary():
    tables = []; comparisons = []; processes = []
    for scenario, role in STAGES:
        timing = read(W / folder_name(scenario, role, 'timing') / 'summary.json')
        memory = read(W / folder_name(scenario, role, 'memory') / 'summary.json')
        assert timing['status'] == memory['status'] == 'COMPLETE_STABLE'
        for variant in ('control', 'candidate'):
            monitored, stats = memory['groups'][variant], timing['groups'][variant]
            tables.append(dict(scenario=scenario, role=role, variant=variant, timing=stats,
                memory=dict(sampled_peaks=monitored['sampled_peaks'], ready_baseline=monitored['ready_baseline'],
                    actual_sample_gaps_ms={key: monitored['actual_sample_gaps_ms'].get(key) for key in ('min', 'median', 'max')},
                    running_sample_count=monitored['running_sample_count'], null_sample_counts=monitored['null_sample_counts'])))
        comparisons.append(dict(scenario=scenario, role=role, median_delta_percent={key:
            100 * (timing['groups']['candidate'][key]['median'] / timing['groups']['control'][key]['median'] - 1) for key in METRICS}))
        for mode in ('timing', 'memory'):
            for row in read(W / folder_name(scenario, role, mode) / 'runs.json'):
                process, raw = row['process'], row['observation']['raw']
                processes.append(dict(scenario=scenario, role=role, mode=mode, variant=row['variant'], window_ordinal=row['window_ordinal'],
                    pid=process['pid'], exit=process['exit'], started_unix_ns=process['started_unix_ns'], finished_unix_ns=process['finished_unix_ns'], image=process['image'],
                    actual_target_rows=raw['actual_target_rows'], actual_draft_rows=raw['actual_draft_rows'], generated_tokens=raw['generated_tokens'],
                    accepted_drafts=raw['accepted_drafts'], packed_prefill_calls=raw['packed_prefill_calls']))
    assert len(processes) == len({row['window_ordinal'] for row in processes}) == 32
    b.save(W / 'summary.json', dict(status='COMPLETE32_CURRENT_INTRA_HYLE_STABLE', processes=32, timing_processes=24, independent_memory_processes=8,
        binding=pin(W / 'binding.json'), plan=pin(W / 'plan.json'), table=tables, within_window_comparison=comparisons, actual_processes=processes,
        limits=['Only new control/candidate observations enter medians; prior40 and peer results remain separate.',
            'Three timing/one independent memory per version/scenario/role; descriptive medians/ranges, no significance claim.',
            'Explicit expected packed-route differences are preserved with old/new values; all other producer non-time facts must match.',
            'Original producer endpoints/10ms requested PSAPI-PDH sampler and actual null/gaps preserved; no ready sample is not zero.',
            'No sums of overlapping lifetimes, no GPU-busy interpretation of producer wall times; sampled memory peaks are lower bounds.']))
    print('COMPLETE32_CURRENT_INTRA_HYLE_STABLE')


if __name__ == '__main__':
    try:
        action = sys.argv[1]
        if action == 'prepare': prepare()
        elif action == 'run': run(*sys.argv[2:])
        elif action == 'resume': resume(*sys.argv[2:])
        elif action == 'analyze': analyze(*sys.argv[2:])
        elif action == 'summary': summary()
        else: raise ValueError(action)
    except BaseException:
        (W / ('failure-' + '-'.join(sys.argv[1:5]) + '-' + str(time.time_ns()) + '.log')).write_text(traceback.format_exc(), encoding='utf-8')
        raise
