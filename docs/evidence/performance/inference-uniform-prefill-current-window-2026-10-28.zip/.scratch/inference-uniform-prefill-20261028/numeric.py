"""Bounded common-prefix numerical diagnosis; never changes the original AB6.

Explicit actions only: prepare; run control; run candidate; analyze.
This is not a performance window, a quality verdict, or a KV-state dump.
"""
import argparse
import array
import hashlib
import heapq
import json
import math
import os
from pathlib import Path
import struct
import subprocess
import sys
import time
import traceback
from datetime import datetime, timezone

W = Path(__file__).resolve().parent
ROOT = W.parent.parent
N = W / "numeric"
STEPS, VOCAB, HIDDEN = 19, 248320, 2048
TRACE_BYTES, TRACE_FILES = 32 * 1024 * 1024, 64
PAYLOAD_BYTES = STEPS * (VOCAB * 4 + HIDDEN * 2)


def read(path):
    return json.loads(Path(path).read_text(encoding="utf-8-sig"))


def write(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, allow_nan=False) + "\n", encoding="utf-8")


def pin(path):
    path = Path(path).resolve(strict=True)
    return {"path": str(path), "bytes": path.stat().st_size,
            "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}


def verify(identity):
    actual = pin(identity["path"])
    assert actual == identity, ("identity changed", identity, actual)


def now():
    return datetime.now(timezone.utc).isoformat()


def result_view(report):
    sessions = report.get("sessions")
    if sessions:
        assert len(sessions) == 1 and sessions[0]["session_id"] == "default"
        return sessions[0]["result"]
    return report


def prepare():
    assert not N.exists(), "numeric directory already exists; do not overwrite an earlier attempt"
    original = read(W / "single-ordinary-timing-plan.json")
    binding = read(W / "binding.json")
    arms = {}
    for name in ("control", "candidate"):
        old = next(x for x in original["commands"] if x["variant"] == name)
        command = old["command"].copy()
        assert command[command.index("--steps") + 1] == "64"
        assert not any(x in command for x in ("--trace", "--trace-level", "--decode-ids",
                                             "--continuation", "--layer0-probe", "--schedule",
                                             "--session-schedules", "--prefill-rows"))
        command[command.index("--steps") + 1] = str(STEPS)
        command += ["--trace", str(N / name / "trace"), "--trace-level", "decisions"]
        assert command[command.index("--decode-overlap") + 1] == "auto"
        assert command[command.index("--mtp") + 1] == "off"
        baseline_path = Path(old["folder"]) / "consumer-result.json"
        baseline = result_view(read(baseline_path))
        assert baseline["prefill_target_rows"] == 154 and len(baseline["generated_ids"]) == 64
        manifest = Path(command[command.index("--inputs") + 1])
        arms[name] = {"command": command, "folder": str(N / name),
                      "image": old["image"], "ready": old["ready"],
                      "source": binding[name]["source"], "inputs": binding[name]["inputs"],
                      "environment": old["environment"], "baseline_report": pin(baseline_path),
                      "expected_ids": baseline["generated_ids"][:STEPS],
                      "expected_packed_calls": 1 if name == "control" else 0,
                      "manifest": pin(manifest / "weights.tsv"),
                      "prompt": pin(manifest / "prompt.ids")}
    assert arms["control"]["expected_ids"][:18] == arms["candidate"]["expected_ids"][:18]
    assert arms["control"]["expected_ids"][18] != arms["candidate"]["expected_ids"][18]
    assert arms["control"]["prompt"]["sha256"] == arms["candidate"]["prompt"]["sha256"]
    tiny_ready_path = ROOT / ".scratch/inference-native-program-io-20261028/cuda/ready-tiny.json"
    tiny = read(tiny_ready_path)
    tiny_fixture = ROOT / ".scratch/inference-paged-frame-20261026/tiny-recursive-input"
    plan = {"purpose": "same P154 and first18 outputs; compare all logits/final hidden at each of19 decisions",
            "prepared_utc": now(), "script": pin(__file__),
            "original_ab_plan": pin(W / "single-ordinary-timing-plan.json"),
            "binding": pin(W / "binding.json"), "arms": arms,
            "processes": 2, "sequential": True, "timeout_seconds_each": 120,
            "trace_limits_each": {"bytes": TRACE_BYTES, "files": TRACE_FILES,
                                  "expected_decision_payload_files": 38,
                                  "expected_decision_payload_bytes": PAYLOAD_BYTES,
                                  "other_files": "cold route/boundaries TSV only; no state or KV payload"},
            "trace_preserves": {"natural_prefill": True, "decode_overlap_auto_eligibility": True,
                                "trace_states": False, "layer0_probe": False},
            "optional_raw_math_case_not_automatically_run": {
                "command": [tiny["image"]["path"], "--cuda", str(tiny_fixture), "--packed-prefill"],
                "ready": pin(tiny_ready_path), "image": tiny["image"],
                "manifest": pin(tiny_fixture / "weights.tsv"),
                "scope": "one process/two sequential tiny Models; R8 L1/3/8, nonzero prefix, old checkpoints and T1",
                "oracle": "new GDN F32 only abs<=3e-6 and finite; other payload/boundary/IDs/RNG exact",
                "not_proven": "real P154 intermediate KV/quality, CUDA bit equality across different GDN implementations"},
            "claims": {"performance": False, "quality": False, "full_kv_state_dump": False,
                       "cross_variant_output_identity": False}}
    write(N / "plan.json", plan)
    print(json.dumps({"plan": str(N / "plan.json"), "real_process_budget": 2,
                      "trace_payload_bytes_total": PAYLOAD_BYTES * 2,
                      "raw_case_automatic": False}))


def trace_usage(folder):
    files = [p for p in folder.rglob("*") if p.is_file()] if folder.exists() else []
    return {"files": len(files), "bytes": sum(p.stat().st_size for p in files)}


def run(name):
    plan = read(N / "plan.json")
    verify(plan["script"])
    arm = plan["arms"][name]
    for key in ("image", "ready", "source", "inputs", "environment", "baseline_report", "manifest", "prompt"):
        verify(arm[key])
    if name == "candidate":
        previous = read(N / "control/process.json")
        assert previous["exit_code"] == 0 and not previous["termination_reason"]
    folder = Path(arm["folder"])
    assert not folder.exists(), "this arm already has an attempt; parse offline, never silently rerun"
    folder.mkdir(parents=True)
    runtime = read(arm["environment"]["path"])
    verify(runtime["native"])
    environment = os.environ.copy()
    environment["PATH"] = runtime["PATH"]
    write(folder / "command.json", {"command": arm["command"], "cwd": str(ROOT),
                                    "environment": arm["environment"], "plan": pin(N / "plan.json")})
    started = time.perf_counter()
    receipt = {"started_utc": now(), "exit_code": None, "pid": None, "termination_reason": None}
    process = None
    try:
        with (folder / "stdout.log").open("wb") as stdout, (folder / "stderr.log").open("wb") as stderr:
            process = subprocess.Popen(arm["command"], cwd=ROOT, env=environment, stdout=stdout, stderr=stderr)
            receipt["pid"] = process.pid
            while process.poll() is None:
                usage = trace_usage(folder / "trace")
                reason = ("trace cap exceeded" if usage["bytes"] > TRACE_BYTES or usage["files"] > TRACE_FILES
                          else "timeout" if time.perf_counter() - started > plan["timeout_seconds_each"] else None)
                if reason:
                    receipt["termination_reason"] = reason
                    process.kill()
                    break
                time.sleep(0.25)
            receipt["exit_code"] = process.wait(timeout=10)
    except BaseException:
        if process is not None and process.poll() is None:
            process.kill()
            process.wait(timeout=10)
        receipt["helper_error"] = traceback.format_exc()
        raise
    finally:
        receipt.update({"finished_utc": now(), "wall_seconds": time.perf_counter() - started,
                        "trace_usage": trace_usage(folder / "trace")})
        write(folder / "process.json", receipt)
        write(folder / "as-run.json", {"plan": pin(N / "plan.json"), "script": pin(__file__),
                                       "command": pin(folder / "command.json"), "process": pin(folder / "process.json")})
    assert receipt["exit_code"] == 0 and not receipt["termination_reason"], receipt
    assert receipt["trace_usage"]["bytes"] <= TRACE_BYTES and receipt["trace_usage"]["files"] <= TRACE_FILES
    print(json.dumps(receipt))


def producer(path):
    candidates = []
    for line in Path(path).read_text(encoding="utf-8-sig").splitlines():
        try:
            item = json.loads(line)
        except json.JSONDecodeError:
            continue
        if isinstance(item, dict) and "source_id" in item and ("sessions" in item or "generated_ids" in item):
            candidates.append(item)
    assert len(candidates) == 1, ("expected one complete producer report", len(candidates))
    return candidates[0]


def values(path, count, bf16=False):
    data = Path(path).read_bytes()
    assert len(data) == count * (2 if bf16 else 4), (str(path), len(data))
    if bf16:
        out = [struct.unpack("<f", struct.pack("<I", x[0] << 16))[0] for x in struct.iter_unpack("<H", data)]
    else:
        out = array.array("f")
        out.frombytes(data)
        if sys.byteorder != "little":
            out.byteswap()
    assert all(math.isfinite(x) for x in out), ("nonfinite trace", str(path))
    return data, out


def difference(a, b):
    errors = [abs(x - y) for x, y in zip(a, b)]
    index = max(range(len(errors)), key=errors.__getitem__)
    return {"different_values": sum(x != y for x, y in zip(a, b)), "max_abs": errors[index],
            "max_abs_index": index, "control_at_max": a[index], "candidate_at_max": b[index],
            "rms_abs": math.sqrt(math.fsum(x * x for x in errors) / len(errors))}


def analyze():
    plan = read(N / "plan.json")
    reports, views, trace_files = {}, {}, {}
    for name, arm in plan["arms"].items():
        folder = Path(arm["folder"])
        process = read(folder / "process.json")
        assert process["exit_code"] == 0 and not process["termination_reason"], process
        reports[name] = producer(folder / "stdout.log")
        write(folder / "consumer-result.json", reports[name])  # original producer schema, no field removal
        view = result_view(reports[name])
        views[name] = view
        assert view["generated_ids"] == arm["expected_ids"], (name, "trace changed19-output path; do not interpret as common-prefix AB")
        assert view["prefill_target_rows"] == 154 and view["prefill_graph_calls"] == 1
        assert view["actual_target_rows"] == 172 and view["generated_tokens"] == 19
        assert view["cold_exact_admissions"] == 0
        assert view["packed_prefill_calls"] == arm["expected_packed_calls"]
        assert view["packed_prefill_active_rows"] == 154 * arm["expected_packed_calls"]
        assert view["packed_prefill_physical_rows"] == 154 * arm["expected_packed_calls"]
        assert reports[name]["decode_overlap"] is True
        trace_files[name] = []
        expected = set()
        for i in range(STEPS):
            stem = "prefill" if i == 0 else "decode" + str(i)
            base = folder / "trace/session0_default" / stem
            for file in ("logits.f32", "hidden.bf16"):
                path = base / file
                trace_files[name].append(pin(path))
                expected.add(path.resolve())
        actual = {p.resolve() for p in (folder / "trace").rglob("*")
                  if p.is_file() and p.suffix in (".f32", ".bf16", ".f16")}
        assert actual == expected, (name, "unexpected/missing tensor files", actual ^ expected)
        assert sum(x["bytes"] for x in trace_files[name]) == PAYLOAD_BYTES
        usage = trace_usage(folder / "trace")
        assert usage["bytes"] <= TRACE_BYTES and usage["files"] <= TRACE_FILES
    assert views["control"]["generated_ids"][:18] == views["candidate"]["generated_ids"][:18]
    decisions = []
    for i in range(STEPS):
        stem = "prefill" if i == 0 else "decode" + str(i)
        arrays, bytes_, top = {}, {}, {}
        for name in ("control", "candidate"):
            base = Path(plan["arms"][name]["folder"]) / "trace/session0_default" / stem
            lb, logits = values(base / "logits.f32", VOCAB)
            hb, hidden = values(base / "hidden.bf16", HIDDEN, True)
            arrays[name] = (logits, hidden)
            bytes_[name] = (lb, hb)
            ids = heapq.nlargest(8, range(VOCAB), key=logits.__getitem__)
            assert ids[0] == views[name]["generated_ids"][i], (name, i, "reported greedy ID differs from trace argmax")
            top[name] = {"id": ids[0], "margin": logits[ids[0]] - logits[ids[1]],
                         "top8": [{"id": token, "logit": logits[token]} for token in ids]}
        winners = (top["control"]["id"], top["candidate"]["id"])
        decisions.append({"index": i, "name": stem, "common_condition_prefix": True,
                          "condition_tokens": 154 + i, "selection": top,
                          "selected_pair_logits": {name: [{"id": token, "logit": arrays[name][0][token]}
                                                           for token in dict.fromkeys(winners)]
                                                   for name in ("control", "candidate")},
                          "logits_byte_equal": bytes_["control"][0] == bytes_["candidate"][0],
                          "logits": difference(arrays["control"][0], arrays["candidate"][0]),
                          "final_hidden_byte_equal": bytes_["control"][1] == bytes_["candidate"][1],
                          "final_hidden": difference(arrays["control"][1], arrays["candidate"][1])})
    write(N / "analysis.json", {"status": "RECORDED_COMMON_PREFIX_NUMERICAL_DIFFERENCE",
          "created_utc": now(), "plan": pin(N / "plan.json"), "first18_outputs_equal": True,
          "output19_equal": winners[0] == winners[1], "decisions": decisions,
          "trace_files": trace_files, "strict_ab6_unchanged": plan["original_ab_plan"],
          "limitations": ["no KV, GDN or conv-state payload in decisions trace",
                          "final-hidden and logit differences are measured, not a proof of task quality",
                          "tracing adds reads; these runs supply no performance conclusion",
                          "no numeric tolerance is used to make the different greedy IDs pass"]})
    print(json.dumps({"analysis": str(N / "analysis.json"), "last_decision": decisions[-1]}))


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("action", choices=("prepare", "run", "analyze"))
    parser.add_argument("arm", nargs="?", choices=("control", "candidate"))
    args = parser.parse_args()
    if args.action == "run":
        assert args.arm, "run needs control or candidate"
        run(args.arm)
    else:
        assert args.arm is None
        (prepare if args.action == "prepare" else analyze)()
