"""Offline correction of one observer assumption; never starts native work."""
from pathlib import Path
import hashlib
import json

W = Path(__file__).resolve().parent
R = W / 'functional'
REPO = W.parent.parent


def read(path):
    return json.loads(path.read_text(encoding='utf-8'))


def pin(path):
    data = path.read_bytes()
    return dict(path=str(path.relative_to(REPO)), bytes=len(data),
                sha256=hashlib.sha256(data).hexdigest())


plan = read(R / 'plan.json')
for field in ['image', 'fixture_manifest', 'schedule']:
    item = plan[field]
    data = Path(item['path']).read_bytes()
    assert len(data) == item['bytes']
    assert hashlib.sha256(data).hexdigest() == item['sha256']

expected = {
    'bounded-ordinary': dict(mtp=False, prefix=False, turns=1, rows=3, packed_calls=2,
                             packed_active_rows=3, packed_physical_rows=4, live=0),
    'bounded-mtp': dict(mtp=True, prefix=False, turns=1, rows=3, packed_calls=1,
                        packed_active_rows=2, packed_physical_rows=2, live=0),
    'prefix-scheduler': dict(mtp=False, prefix=True, turns=2, rows=7, packed_calls=2,
                             packed_active_rows=7, packed_physical_rows=7, live=1),
}
cases = []
for item in plan['commands']:
    name = item['name']; e = expected[name]; directory = R / name
    command = read(directory / 'command.json')
    process = read(directory / 'process.json')
    assert command['command'] == item['command']
    assert process['exit'] == 0 and process['state'] == 'TERMINAL' and not process['timed_out']
    reports = [json.loads(line) for line in (directory / 'stdout.log').read_text().splitlines()
               if line.startswith('{')]
    assert len(reports) == 1
    report = reports[0]
    assert report['backend'] == 'cuda' and report['mtp'] == e['mtp']
    assert report['session_count'] == report['admitted_requests'] == report['retired_requests'] == 1
    assert report['active_sequences'] == report['max_sessions'] == 1
    assert report['turn_count'] == report['admitted_turns'] == e['turns']
    assert report['generated_tokens'] == report['requested_output_tokens'] == 2 * e['turns']
    assert report['prefill_target_rows'] == e['rows']
    assert report['packed_prefill_calls'] == e['packed_calls'] > 0
    assert report['packed_prefill_active_rows'] == e['packed_active_rows']
    assert report['packed_prefill_physical_rows'] == e['packed_physical_rows']
    assert report['cold_exact_admissions'] == report['cold_exact_evictions'] == 0
    assert report['cache_live_requested_bytes'] <= report['cache_peak_requested_bytes'] <= report['cache_requested_byte_limit']
    assert report['prefix_cache'] == e['prefix']
    assert report['live_committed_versions'] == report['prefix_entries'] == e['live']
    assert report['peak_committed_versions'] <= report['max_sessions']
    assert report['live_committed_versions'] <= report['max_sessions']
    assert report['restore_count'] == 0
    assert all(0 < b['active_rows'] <= b['physical_rows'] for b in report['batches'])
    assert sum(b['active_rows'] for b in report['batches'] if not b['generation']) == e['rows']
    assert len(report['sessions']) == 1
    session = report['sessions'][0]
    assert len(session['result']['generated_ids']) == 2 * e['turns']
    assert len(session['result']['turns']) == e['turns']
    if e['prefix']:
        assert report['prefix_evictions'] == 2
        assert report['prefix_hits'] == report['reused_tokens'] == 0
        assert report['prefix_misses'] == 1
        assert '--progress' in command['command'] and 'scheduler' in command['command']
    cases.append(dict(name=name, status='PASS_FINITE_PACKED_POLICY', process=process,
                      expected=e, report=report,
                      evidence=[pin(directory / n) for n in
                                ['command.json', 'process.json', 'stdout.log', 'stderr.log']]))

source_basis = [
    dict(file='engine/models/qwen35/main.cc', lines=[7661, 7304, 7316, 7470, 7481, 7483, 5771, 5782, 8112, 8159, 8161, 8163],
         fact='PrefixCache is a function-local owner sized by resident_sessions. Completed turns publish the session checkpoint; successful real retirement resets the session head and Session. The report is printed while PrefixCache is still alive.'),
    dict(file='engine/models/qwen35/prefix_cache.h', lines=[101, 102, 140, 160],
         fact='PrefixPayload owns SnapshotRef; publish copies that immutable snapshot into the shared directory payload.'),
    dict(file='engine/models/qwen35/session_state.h', lines=[272, 274, 285, 306, 422],
         fact='VersionCount counts distinct live immutable versions, including explicitly retained prefixes; SnapshotRef is shared_ptr<const State>. The version is released by its original VersionRef destructor.'),
    dict(file='engine/inference/prefix_directory.h', lines=[15, 36, 37, 168, 171],
         fact='The finite directory owns each payload; eviction resets the payload. Its ordinary destruction also destroys retained entry payloads.'),
]
for basis in source_basis:
    basis['identity'] = pin(REPO / basis['file'])

analysis = dict(
    schema='hyle.uniform-prefill.finite-packed-policies.v1',
    status='PASS_FINITE_PACKED_POLICIES_OFFLINE_POSTCHECK',
    native_processes=3, native_reruns=0,
    original_observer=dict(
        helper=pin(W / 'functional.py'),
        status='ASSERTION_FAILED_AFTER_SUCCESSFUL_PREFIX_SCHEDULER_PROCESS',
        assertion='report[packed_prefill_calls] > 0 and report[live_committed_versions] == 0',
        erroneous_assumption='A report with all requests retired must have zero immutable versions even while an enabled prefix cache still owns a checkpoint.',
        observed=dict(prefix_entries=1, live_committed_versions=1, retired_requests=1),
        correction='Require zero versions for prefix-off cases. For this N=1 prefix-on case, require the one retained version to match the one live cache entry, within the original budget; successful Session retirement remains mandatory.',
        original_files_modified=False),
    scope='Three finite current-candidate natural-entry packed-policy smoke cases. These are not a quality, performance, full matrix, or cache-hit/reuse claim; prefix-scheduler had no prefix hit.',
    source_basis=source_basis, plan=pin(R / 'plan.json'),
    postcheck=pin(Path(__file__)), cases=cases)
(R / 'analysis.json').write_text(json.dumps(analysis, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')
print(json.dumps(dict(status=analysis['status'], native_processes=3, native_reruns=0,
                      cases=[dict(name=c['name'], pid=c['process']['pid'], status=c['status'],
                                  live=c['report']['live_committed_versions'], prefix_entries=c['report']['prefix_entries'])
                             for c in cases])))
