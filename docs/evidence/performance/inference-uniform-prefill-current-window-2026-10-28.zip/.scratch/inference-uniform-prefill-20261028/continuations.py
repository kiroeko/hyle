"""Same planned32 processes, transparently retaining distinct continuations.

Original runner, first6 observations and failed strict comparison are immutable.
This sidecar changes reporting scope; it does not whitelist output differences.
"""
from pathlib import Path
import importlib.util
import json
import sys

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('uniform_original_window', W / 'window.py')
o = importlib.util.module_from_spec(spec); spec.loader.exec_module(o)
b, read, pin = o.b, o.read, o.pin
STATUS = 'COMPLETE_DISTINCT_CONTINUATIONS'
RESULT = 'analysis-continuations.json'
ROWS = 'runs-continuations.json'


def prepare():
    original = read(W / 'single-ordinary-timing/summary.json')
    assert original['status'] == 'PRESERVED_FACT_DIFFERENCES'
    assert len(original['unexpected_differences']) == 569 and original['processes'] == 6
    numeric = read(W / 'numeric/analysis.json')
    assert numeric['status'] == 'RECORDED_COMMON_PREFIX_NUMERICAL_DIFFERENCE'
    o.save(W / 'continuations-plan.json', dict(script=pin(__file__), original_script=pin(W / 'window.py'),
        original_plan=pin(W / 'plan.json'), binding=pin(W / 'binding.json'),
        original_first6_analysis=pin(W / 'single-ordinary-timing/summary.json'),
        original_first6_differences=pin(W / 'single-ordinary-timing/complete-non-time-differences.json'),
        original_first6_observations=pin(W / 'single-ordinary-timing/runs.json'),
        numerical_observation=pin(W / 'numeric/analysis.json'),
        contract='Within-version complete non-time reports stay strict. All cross-version differences remain explicit. Only common task/config/precision/weights/first-prefill154 rows and packed1->0 route are asserted; decode and second-turn conditions may differ.',
        processes=dict(existing_successes=6, not_started=26, planned_total=32, rerun_existing=0)))
    print('SIDECAR PREPARED: original6 retained; remaining26 unchanged planned commands')


def validate():
    plan = read(W / 'continuations-plan.json')
    for field in ('script', 'original_script', 'original_plan', 'binding', 'original_first6_analysis',
        'original_first6_differences', 'original_first6_observations', 'numerical_observation'):
        o.exact(plan[field])
    return plan


def turns(raw):
    if 'turns' in raw: return raw['turns']
    return raw['sessions'][0]['result']['turns']


def common_task(control, candidate, cfg):
    fields = ('source_id', 'score_dtype', 'score_policy', 'mtp', 'weight_count_scope', 'text_tensors', 'mtp_tensors',
        'session_count', 'turn_count', 'active_sequences', 'max_sessions', 'sampling', 'sampling_policy_order',
        'sampling_temperature', 'sampling_top_k', 'sampling_top_p', 'sampling_seed',
        'history_repetition', 'history_presence', 'history_frequency', 'mtp_acceptance_policy',
        'mtp_max_drafts', 'mtp_min_draft_probability', 'backend', 'cpu_ffn_layers',
        'original_host_weight_bytes', 'original_device_weight_bytes', 'prefix_cache', 'requested_output_tokens',
        'logical_user_prompt_tokens', 'prefill_target_rows')
    assert all(control[key] == candidate[key] for key in fields), [(key, control.get(key), candidate.get(key)) for key in fields if control.get(key) != candidate.get(key)]
    assert all(row['command'][1:] == cfg['commands'][0]['command'][1:] for row in cfg['commands'])
    a, c = turns(control), turns(candidate)
    assert a[0]['input_ids'] == c[0]['input_ids'] and len(a[0]['input_ids']) == 154
    for raw in (control, candidate):
        first = next(row for row in raw['batches'] if not row['generation'])
        assert first['input_rows'] == [154] and first['active_rows'] == first['physical_rows'] == 154
    route = []
    for key in ('packed_prefill_calls', 'packed_prefill_active_rows', 'packed_prefill_physical_rows'):
        assert control[key] > 0 and candidate[key] == 0
        route.append(dict(path='$.' + key, control=control[key], candidate=candidate[key]))
    return dict(equal_fields=list(fields), identical_command_arguments_except_image=True,
        same_first_prefill_input_IDs=True, first_prefill_active_physical_rows=154,
        all_turn_input_IDs_equal=[row['input_ids'] for row in a] == [row['input_ids'] for row in c],
        packed_route_facts=route)


def analyze(scenario, role, mode):
    validate(); cfg = o.config(scenario, role, mode); out = W / o.folder_name(scenario, role, mode)
    rows = []
    for entry in cfg['commands']:
        folder = Path(entry['folder']); process = read(folder / 'result.json'); observation = read(folder / 'observation.json')
        assert process['exit'] == 0 and not process.get('timeout') and not process.get('timed_out') and not process.get('reader_errors')
        assert process['command'] == entry['command'] and process['image'] == entry['image'] and process['arm'] == entry['arm']
        assert observation['raw'] == read(folder / 'consumer-result.json')
        assert read(folder / 'timing-partition-gate.json')['status'] == 'PASS'
        rows.append(dict(variant=entry['variant'], scenario=scenario, role=role, folder=str(folder),
            window_ordinal=entry['window_ordinal'], process=process, observation=observation))
    groups = {}; facts = {}; raw = {}; complete = {}; work = []
    for variant in ('control', 'candidate'):
        selected = [row for row in rows if row['variant'] == variant]; expected = 3 if mode == 'timing' else 1
        assert len(selected) == expected
        normalized = [o.f.facts_parser.non_time(row['observation']['raw']) for row in selected]
        changes = [dict(folder=selected[i]['folder'], differences=o.f.differences(normalized[0], value))
            for i, value in enumerate(normalized[1:], 1) if value != normalized[0]]
        complete[variant] = dict(processes=expected, stable=not changes, changes=changes)
        facts[variant], raw[variant] = normalized[0], selected[0]['observation']['raw']
        if mode == 'timing':
            groups[variant] = {key: b.stats([row['observation']['metrics'][key] for row in selected if row['observation']['metrics'][key] is not None])
                for key in selected[0]['observation']['metrics']}
        else: groups[variant] = read(Path(selected[0]['folder']) / 'memory-summary.json')
        for row in selected:
            report = row['observation']['raw']
            fields = ('actual_graph_calls', 'generated_tokens', 'generated_decode_tokens', 'actual_target_rows',
                'actual_draft_rows', 'verified_target_rows', 'committed_target_rows', 'prefill_target_rows',
                'prefill_draft_rows', 'consumed_drafts', 'accepted_drafts', 'draft_rounds', 'pending_flushed_tokens',
                'overlap_successor_submissions', 'overlap_successor_publications', 'overlap_successor_refusals', 'overlap_successor_discards')
            work.append(dict(variant=variant, pid=row['process']['pid'], actual={key: report[key] for key in fields if key in report},
                rounds=len(report.get('rounds', [])), batches=report['batches'], report=pin(Path(row['folder']) / 'consumer-result.json')))
    between = o.f.differences(facts['control'], facts['candidate'])
    task = common_task(raw['control'], raw['candidate'], cfg)
    ids0, ids1 = raw['control']['generated_ids'], raw['candidate']['generated_ids']
    first = next((i for i, pair in enumerate(zip(ids0, ids1)) if pair[0] != pair[1]), None)
    value = dict(status=STATUS, scenario=scenario, role=role, mode=mode, processes=len(rows), groups=groups,
        within_variant_complete_non_time=complete, common_task=task,
        cross_variant_complete_non_time_differences=between, cross_variant_difference_count=len(between),
        cross_variant_generated_IDs_equal=ids0 == ids1, first_ID_difference=first,
        same_full_workflow_or_continuation_claim=False, actual_work=work, memory_unknown_values_preserved=True,
        interpretation='All differences retained, not whitelisted. First-prefill commonP154 observations are separable; decode/full workflows and later-turn prefill conditions may differ. No same-work decode or two-turn code-gain inference.',
        numerical_observation=pin(W / 'numeric/analysis.json'), historical_samples_pooled=False)
    assert all(row['stable'] for row in complete.values()), 'Preserve within-version variability; never replace a successful process'
    o.save(out / ROWS, rows); o.save(out / RESULT, value)
    print(STATUS, scenario, role, mode, len(rows), 'all cross-version differences:', len(between), flush=True)
    return value


def stage_gate(scenario, role, mode):
    validate(); index = o.STAGES.index((scenario, role))
    for s, r in o.STAGES[:index]:
        for m in ('timing', 'memory'):
            assert read(W / o.folder_name(s, r, m) / RESULT)['status'] == STATUS
    if mode == 'memory': assert read(W / o.folder_name(scenario, role, 'timing') / RESULT)['status'] == STATUS


def summary():
    validate(); tables = []; comparisons = []; processes = []; differences = []
    for scenario, role in o.STAGES:
        timing = read(W / o.folder_name(scenario, role, 'timing') / RESULT)
        memory = read(W / o.folder_name(scenario, role, 'memory') / RESULT)
        assert timing['status'] == memory['status'] == STATUS
        for variant in ('control', 'candidate'):
            tables.append(dict(scenario=scenario, role=role, variant=variant,
                timing=timing['groups'][variant], independent_memory=memory['groups'][variant]))
        comparisons.append(dict(scenario=scenario, role=role,
            observed_median_delta_percent={key: 100 * (timing['groups']['candidate'][key]['median'] / timing['groups']['control'][key]['median'] - 1) for key in o.METRICS},
            same_work_decode_or_two_turn_gain_claim=False))
        for mode, result in (('timing', timing), ('memory', memory)):
            differences.append(dict(scenario=scenario, role=role, mode=mode, report=pin(W / o.folder_name(scenario, role, mode) / RESULT),
                all_cross_variant_differences=result['cross_variant_complete_non_time_differences']))
            for row in read(W / o.folder_name(scenario, role, mode) / ROWS):
                process = row['process']; processes.append(dict(scenario=scenario, role=role, mode=mode,
                    variant=row['variant'], ordinal=row['window_ordinal'], pid=process['pid'], exit=process['exit'],
                    started_unix_ns=process['started_unix_ns'], finished_unix_ns=process['finished_unix_ns']))
    assert len(processes) == len({row['ordinal'] for row in processes}) == len({row['pid'] for row in processes}) == 32
    o.save(W / 'summary-continuations.json', dict(status=STATUS, processes=32, timing_processes=24, independent_memory_processes=8,
        existing_first6_reused_without_rerun=True, sidecar_plan=pin(W / 'continuations-plan.json'), original_plan=pin(W / 'plan.json'),
        table=tables, observed_comparisons=comparisons, cross_variant_reports=differences, actual_processes=processes,
        scope='Same task/config/precision/weights and first-prefill154 rows, not equal continuation/full mathematical work. Full32 observed once; no old-window timing pooling.',
        numerical_observation=pin(W / 'numeric/analysis.json'), trained_quality_equivalence_proven=False,
        limitations=['Within-variant complete non-time reports remain strict; every cross-variant output/acceptance/row/ledger difference is retained.',
            'Initial same-input prefill timing is distinct from decode and second-turn/full-workflow observations after the measured near-tie flip.',
            'Three timing observations/one independent memory per variant/scenario/mode; descriptive medians/ranges, no significance claim.',
            'Original producer endpoints and10ms requested sampler; actual null/gaps and sampled-peak lower bounds retained.']))
    print(STATUS, '32 processes; original first6 retained')


# Reuse the original native process loops verbatim. Only derived analysis and
# stage status checks are selected in this imported, private Python module.
o.analyze = analyze
o.stage_gate = stage_gate

if __name__ == '__main__':
    action = sys.argv[1]
    if action == 'prepare': prepare()
    elif action == 'analyze': analyze(*sys.argv[2:])
    elif action == 'run': validate(); o.run(*sys.argv[2:])
    elif action == 'resume': validate(); o.resume(*sys.argv[2:])
    elif action == 'summary': summary()
    else: raise ValueError(action)
