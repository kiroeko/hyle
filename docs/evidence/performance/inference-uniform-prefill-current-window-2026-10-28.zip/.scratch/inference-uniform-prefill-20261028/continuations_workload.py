"""Parser-only scenario binding; all frozen source/commands/runners retained."""
from pathlib import Path
import importlib.util
import sys

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('uniform_distinct_continuations', W / 'continuations.py')
c = importlib.util.module_from_spec(spec); spec.loader.exec_module(c)
protocol = c.o.f.protocol
assert c.o.f.original_parse.__globals__ is protocol.__dict__
original_normalize, original_parse = protocol.normalize, c.o.f.parse


def normalize_once(folder, arm):
    # The failed first two-turn parser already produced this derived adapter.
    # Existing stdout/stderr/result/normalized producer files are never rewritten.
    if not (Path(folder) / 'consumer-result.json').exists():
        original_normalize(folder, arm)


def parse_with_full_producer(folder, arm, configuration):
    result = original_parse(folder, arm, configuration)
    if protocol.WORKLOAD == 'two-turn':
        # The retained turns parser returns nested MTP detail as raw and keeps
        # whole-session producer as top_level_raw. The complete-fact sidecar
        # compares the actual normalized whole producer for both roles.
        result = dict(result, raw=c.read(Path(folder) / 'consumer-result.json'))
    return result


protocol.normalize = normalize_once
c.o.f.parse = parse_with_full_producer


def prepare():
    c.validate()
    folder = W / 'two-turn-ordinary-timing/01-control'
    process = c.read(folder / 'result.json')
    assert process['exit'] == 0 and not process.get('timeout')
    c.o.save(W / 'workload-parser-amendment.json', dict(script=c.pin(__file__),
        frozen_sidecar_plan=c.pin(W / 'continuations-plan.json'), original_script=c.pin(W / 'window.py'),
        retained_parser=c.pin(Path(protocol.__file__)),
        existing_successful_native=dict(pid=process['pid'], result=c.pin(folder / 'result.json'),
            raw_files=[c.pin(folder / name) for name in ('command.json', 'stdout.log', 'stderr.log', 'consumer-result.json', 'result-schema-adapter.json')]),
        reason='Preparation bug: imported retained protocol.WORKLOAD remained single, so the successful128-output two-turn process was parsed using the64-output single-turn contract.',
        changes=['Select retained protocol.WORKLOAD from explicit scenario before parser or memory-helper creation.',
            'Reuse the retained two-turn parser and original endpoints/accounting; complete facts use whole producer rather than nested MTP detail.',
            'Do not rewrite existing normalized producer/stdout/stderr/result files; only missing offline observation is generated.'],
        native_failures=0, model_reruns=0, native_commands_changed=False,
        next_command=['python', str(W / 'continuations_workload.py'), 'resume', 'two-turn', 'ordinary', 'timing']))
    print('PARSER AMENDMENT PREPARED; original successful native process retained, tail5 only')


def validate():
    c.validate(); amendment = c.read(W / 'workload-parser-amendment.json')
    for field in ('script', 'frozen_sidecar_plan', 'original_script', 'retained_parser'):
        c.o.exact(amendment[field])
    c.o.exact(amendment['existing_successful_native']['result'])
    for item in amendment['existing_successful_native']['raw_files']: c.o.exact(item)


if __name__ == '__main__':
    action = sys.argv[1]
    if action == 'prepare': prepare()
    else:
        validate()
        if action == 'summary': c.summary()
        else:
            scenario, role, mode = sys.argv[2:]
            assert scenario in ('single', 'two-turn')
            protocol.WORKLOAD = scenario
            assert c.o.f.original_parse.__globals__['WORKLOAD'] == scenario
            if action == 'run': c.o.run(scenario, role, mode)
            elif action == 'resume': c.o.resume(scenario, role, mode)
            elif action == 'analyze': c.analyze(scenario, role, mode)
            else: raise ValueError(action)
