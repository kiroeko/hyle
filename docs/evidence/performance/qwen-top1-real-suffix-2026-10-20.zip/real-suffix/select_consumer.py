"""Explicitly select the already compiled BF16-Top1 consumer; never run it.

--plan verifies the two pinned source versions, original receipt and all150
retained link inputs, and records a no-link plan. --adopt repeats those checks,
restores the exact tested after-source and performs one link, with no CXX/GPU.
Any failed adoption restores the preceding canonical consumer source.
"""
from pathlib import Path
import argparse
import hashlib
import importlib.util
import json
import subprocess
import sys
import time

sys.dont_write_bytecode = True
R = Path(__file__).resolve().parent
B = R.parent
ROOT = B.parents[2]
OUT = R / 'selected-consumer'
BEFORE = '33a3e3de91050ad752935b81d1b5bb82fa9e09a8868ca04b0a028dd832b66a6c'
AFTER = '96dcbeca56ad9b1158ab6e99189b58f2cb08199520993f66e3c8d11424b7e798'
CANONICAL = ROOT / 'tools/qwen35_text/main.cc'
AFTER_SOURCE = B / 'consumer/after/tools/qwen35_text/main.cc'
LINK = B / 'checks/qwen-link-plan.json'
RECEIPT = B / 'checks/main-identity.json'


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))


def save(path, value):
    with Path(path).open('x', encoding='utf-8', newline='\n') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)
        stream.write('\n')


def identity(path):
    path = Path(path).resolve()
    with path.open('rb') as stream:
        digest = hashlib.file_digest(stream, 'sha256').hexdigest()
    return {'path': str(path), 'bytes': path.stat().st_size, 'sha256': digest}


def equal_identity(actual, expected):
    return (Path(actual['path']).resolve() == Path(expected['path']).resolve()
            and actual['bytes'] == expected['bytes']
            and actual['sha256'] == expected['sha256'])


def prepare():
    assert identity(CANONICAL)['sha256'] == BEFORE, 'Canonical source must still be the exact D1/before consumer'
    assert identity(AFTER_SOURCE)['sha256'] == AFTER, 'Tested candidate snapshot changed'
    before_snapshot = B / 'consumer/before/tools/qwen35_text/main.cc'
    assert identity(before_snapshot)['sha256'] == BEFORE
    freeze = read(B / 'consumer/source-freeze.json')
    assert freeze['before']['sha256'] == BEFORE and freeze['after']['sha256'] == AFTER
    receipt = read(RECEIPT)
    assert receipt['source']['sha256'] == AFTER
    assert Path(receipt['source']['path']).resolve() == CANONICAL.resolve()
    original_compile = read(B / 'checks/main-compile.result.json')
    original_link = read(B / 'checks/qwen-link.result.json')
    assert original_compile['terminal'] and original_compile['exit'] == 0
    assert original_link['terminal'] and original_link['exit'] == 0
    actual_object = identity(B / 'checks/main.obj')
    assert equal_identity(actual_object, receipt['object']), 'Cached tested main.obj changed'
    assert equal_identity(identity(receipt['source_dependencies']['path']), receipt['source_dependencies'])
    link = read(LINK)
    rows = link['inputs']
    assert len(rows) == 150 and len({str(Path(x['path']).resolve()).lower() for x in rows}) == 150
    assert sum(equal_identity(row, actual_object) for row in rows) == 1
    checked = []
    for expected in rows:
        actual = identity(expected['path'])
        assert equal_identity(actual, expected), 'Retained input changed: ' + expected['path']
        checked.append(actual)
    command = [arg for arg in link['command']
               if not arg.upper().startswith(('/OUT:', '/MAP:', '/IMPLIB:', '/PDB:'))]
    assert Path(command[0]).name.lower() == 'link.exe'
    assert sum(Path(arg).resolve() == Path(actual_object['path']).resolve()
               for arg in command if not arg.startswith('/')) == 1
    image = OUT / 'qwen.exe'
    command.extend(['/OUT:' + str(image), '/MAP:' + str(image.with_suffix('.map')),
                    '/IMPLIB:' + str(image.with_suffix('.lib'))])
    return {'source_before': identity(CANONICAL), 'source_after': identity(AFTER_SOURCE),
            'consumer_freeze': identity(B / 'consumer/source-freeze.json'),
            'original_main_receipt': identity(RECEIPT), 'main_object': actual_object,
            'original_compile_result': identity(B / 'checks/main-compile.result.json'),
            'original_link_result': identity(B / 'checks/qwen-link.result.json'),
            'original_link_plan': identity(LINK), 'inputs': checked, 'command': command,
            'input_count': 150, 'CXX': 0, 'NVCC': 0, 'SDK': 0, 'GPU': 0, 'links': 1,
            'scope': 'Same150 verified actual link inputs and exact tested main object; only output destinations change. No image run or new numerical/performance claim.'}


def environment(command, inputs):
    # Reuse the exact established local linker environment construction rather
    # than introducing another compiler/SDK selection. Do not print or persist
    # process environment values.
    source = B / 'build.py'
    spec = importlib.util.spec_from_file_location('selected_top1_retained_build_helpers', source)
    helper = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(helper)
    env, runtime = helper.b.environment(command, [row['path'] for row in inputs], OUT)
    return env, runtime, identity(source)


def adopt(plan):
    assert not OUT.exists(), 'Preserve any earlier selected-consumer attempt'
    OUT.mkdir(parents=True, exist_ok=False)
    save(OUT / 'plan.json', plan)
    before = CANONICAL.read_bytes()
    (OUT / 'canonical-before.cc').write_bytes(before)
    after = AFTER_SOURCE.read_bytes()
    source_written = False
    try:
        env, runtime, helper_source = environment(plan['command'], plan['inputs'])
        save(OUT / 'environment-origin.json', {'helper': helper_source, 'runtime_directories': runtime,
                                               'environment_values_recorded': False})
        # No canonical mutation occurs until every original source/object/input
        # identity and the usable local link environment have been checked.
        assert identity(CANONICAL)['sha256'] == BEFORE
        source_written = True
        CANONICAL.write_bytes(after)
        assert identity(CANONICAL)['sha256'] == AFTER
        command_record = {'command': plan['command'], 'cwd': str(ROOT),
                          'started': time.time(), 'terminal': False, 'exit': None}
        save(OUT / 'link.command.json', command_record)
        with (OUT / 'link.stdout.log').open('wb') as stdout, (OUT / 'link.stderr.log').open('wb') as stderr:
            process = subprocess.Popen(plan['command'], cwd=ROOT, env=env, stdout=stdout, stderr=stderr)
            command_record['pid'] = process.pid
            command_record['exit'] = process.wait()
        command_record.update(finished=time.time(), terminal=True)
        save(OUT / 'link.result.json', command_record)
        assert command_record['exit'] == 0, 'Selected consumer link failed; restoring canonical source'
        image = identity(OUT / 'qwen.exe')
        assert identity(CANONICAL)['sha256'] == AFTER
        save(OUT / 'image.json', image)
        save(OUT / 'link-plan.json', {'command': plan['command'], 'inputs': plan['inputs'],
                                      'base': plan['original_link_plan'], 'main_receipt': plan['original_main_receipt'],
                                      'source_after': identity(CANONICAL), 'CXX': 0, 'GPU': 0})
        save(OUT / 'summary.json', {'adopted': True, 'canonical_source': identity(CANONICAL),
                                    'image': image, 'retained_link_inputs_verified': 150,
                                    'CXX': 0, 'NVCC': 0, 'SDK': 0, 'links': 1, 'GPU': 0,
                                    'runtime_validation': 'Not run by selector; root owns any real consumer execution'})
        print(json.dumps({'adopted': True, 'source': identity(CANONICAL), 'image': image}))
    except BaseException as error:
        restored = False
        if source_written:
            CANONICAL.write_bytes(before)
            restored = identity(CANONICAL)['sha256'] == BEFORE
        save(OUT / 'failure.json', {'error': str(error), 'source_was_written': source_written,
                                    'canonical_restored': restored if source_written else None,
                                    'canonical_source': identity(CANONICAL),
                                    'existing_artifacts_retained': True})
        raise


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument('--plan', action='store_true')
    mode.add_argument('--adopt', action='store_true')
    args = parser.parse_args()
    plan = prepare()
    if args.plan:
        save(R / 'select-consumer-plan.json', plan)
        print(json.dumps({'plan_only': True, 'verified_inputs': 150, 'canonical_written': False,
                          'CXX': 0, 'link_run': False, 'GPU': 0}))
    else:
        adopt(plan)

if __name__ == '__main__':
    main()
