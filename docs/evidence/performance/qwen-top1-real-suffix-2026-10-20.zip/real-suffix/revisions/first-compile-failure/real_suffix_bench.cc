// Real Copy->BF16 LM head->optional F32 Cast->Top1; public Graph only.
#include "hyle/compute/backends/cuda.h"
#include "hyle/compute/providers/cublas.h"
#include "hyle/compute/providers/cuda.h"
#include "hyle/graph/cuda.h"

#include <algorithm>
#include <array>
#include <bit>
#include <chrono>
#include <cmath>
#include <cstdint>
#include <filesystem>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <span>
#include <sstream>
#include <stdexcept>
#include <string>
#include <utility>
#include <vector>

namespace c = hyle::compute;
namespace g = hyle::graph;
namespace m = hyle::mem;
using Clock = std::chrono::steady_clock;
constexpr std::int64_t vocabulary = 248320, hidden = 2048;
constexpr std::size_t weight_bytes = 1017118720;
template<class T> T take(hyle::Result<T> value) {
  if (!value) throw std::runtime_error(std::string(value.error().message()));
  return std::move(*value);
}
void check(hyle::Status status) {
  if (!status.ok()) throw std::runtime_error(std::string(status.message()));
}
void cuda_check(cudaError_t status) {
  if (status != cudaSuccess) throw std::runtime_error(cudaGetErrorString(status));
}
struct Drain final { c::Queue &queue; ~Drain() { (void)queue.drain(); } };
struct Events final {
  cudaEvent_t first = nullptr, last = nullptr;
  ~Events() {
    if (last) (void)cudaEventDestroy(last);
    if (first) (void)cudaEventDestroy(first);
  }
};
c::TensorDesc desc(c::DataType type, std::int64_t rows, std::int64_t columns) {
  return take(c::TensorDesc::dense(type, std::array<std::int64_t, 2>{rows, columns}));
}
template<class T> std::vector<T> read_file(const std::filesystem::path &path,
                                          std::size_t elements) {
  std::ifstream file(path, std::ios::binary | std::ios::ate);
  const auto bytes = elements * sizeof(T);
  if (!file || file.tellg() != static_cast<std::streamoff>(bytes))
    throw std::runtime_error("Unexpected input byte count: " + path.string());
  std::vector<T> result(elements);
  file.seekg(0);
  file.read(reinterpret_cast<char *>(result.data()), static_cast<std::streamsize>(bytes));
  if (!file) throw std::runtime_error("Input read failed: " + path.string());
  return result;
}
c::ReadLease load_head(const std::filesystem::path &manifest,
                       const c::StorageOwner &owner) {
  std::ifstream text(manifest);
  std::string signature, shard, identity, line;
  std::getline(text, signature); std::getline(text, shard); std::getline(text, identity);
  if (signature != "HYLE_QWEN35_TEXT_V1" ||
      identity != "4068044d8571635d8a86f1e96a43dad104efc7089169065f735601e350008155")
    throw std::runtime_error("Original pinned manifest required");
  std::getline(text, line);
  std::istringstream fields(line);
  std::string name, type;
  std::size_t rank = 0, offset = 0, bytes = 0;
  std::int64_t n = 0, k = 0;
  fields >> name >> type >> rank >> n >> k >> offset >> bytes;
  if (!fields || name != "model.language_model.embed_tokens.weight" ||
      type != "BF16" || rank != 2 || n != vocabulary || k != hidden ||
      offset != 87024 || bytes != weight_bytes ||
      std::filesystem::file_size(shard) != 4548221488ULL)
    throw std::runtime_error("Original LM-head range differs");
  auto buffer = take(m::Buffer::create(owner.ref(), bytes, 256));
  std::ifstream source(shard, std::ios::binary);
  source.seekg(static_cast<std::streamoff>(offset));
  std::vector<std::byte> staging(8u * 1024u * 1024u);
  for (std::size_t position = 0; position < bytes;) {
    const auto count = (std::min)(staging.size(), bytes - position);
    source.read(reinterpret_cast<char *>(staging.data()), static_cast<std::streamsize>(count));
    if (!source) throw std::runtime_error("Short original head range");
    check(take(buffer.view().subview(position, count)).write(std::span(staging).first(count)));
    position += count;
  }
  return take(owner.adopt_buffer(std::move(buffer)));
}
std::uintptr_t address(const m::Buffer &buffer) {
  return reinterpret_cast<std::uintptr_t>(take(c::cuda::pointer<std::byte>(buffer.view())));
}
struct Arm final {
  g::Graph logical;
  g::CompiledGraph compiled;
  m::Buffer final_hidden, logits, token;
  g::Invocation slot;
  g::ReplayReport cold{}, warm{};
  std::uint64_t head_implementation = 0;
  bool direct = false;
};
void print_plan(const Arm &arm, const std::filesystem::path &path) {
  std::ofstream out(path);
  out << "{\"direct_bf16\":" << (arm.direct ? "true" : "false")
      << ",\"workspace_bytes\":" << arm.compiled.executable.workspace_bytes()
      << ",\"borrowed_constants\":" << arm.compiled.report.borrowed_constant_count()
      << ",\"materialized_constants\":" << arm.compiled.report.materialized_constant_count()
      << ",\"materialized_constant_bytes\":" << arm.compiled.report.materialized_constant_bytes()
      << ",\"logits_bytes\":" << arm.logits.size()
      << ",\"caller_allocation_requested_alignment\":256"
      << ",\"hidden_address\":" << address(arm.final_hidden)
      << ",\"hidden_address_mod4096\":" << address(arm.final_hidden) % 4096
      << ",\"logits_address\":" << address(arm.logits)
      << ",\"logits_address_mod4096\":" << address(arm.logits) % 4096
      << ",\"token_address\":" << address(arm.token)
      << ",\"logits_address_mod256\":" << address(arm.logits) % 256
      << ",\"internal_BF16_head_address\":\"private workspace in Cast arm; intentionally not published\""
      << ",\"route\":" << static_cast<unsigned>(arm.slot.replay_route())
      << ",\"cold_recorded\":" << arm.cold.recorded_capture_range_count
      << ",\"cold_reused\":" << arm.cold.reused_capture_range_count
      << ",\"warm_recorded\":" << arm.warm.recorded_capture_range_count
      << ",\"warm_reused\":" << arm.warm.reused_capture_range_count << ",\"steps\":[";
  for (std::size_t i = 0; i < arm.compiled.report.step_count(); ++i) {
    if (i) out << ',';
    const auto step = take(arm.compiled.report.step(i));
    out << "{\"step\":" << i << ",\"kind\":" << static_cast<unsigned>(step.kind)
        << ",\"provider\":\"" << step.provider.name << "\",\"implementation\":"
        << step.implementation.value() << ",\"dispatches\":" << step.dispatch_count
        << ",\"workspace_bytes\":" << step.workspace.size
        << ",\"capture_compatible\":" << (step.runtime.capture_compatible ? "true" : "false")
        << ",\"nodes\":[";
    for (std::size_t j = 0; j < step.node_count; ++j) {
      if (j) out << ',';
      const auto node = take(arm.compiled.report.step_node(i, j));
      out << '"' << c::operation_name(take(arm.logical.operation_kind(node))) << '"';
    }
    out << "]}";
  }
  out << "]}\n";
  if (!out) throw std::runtime_error("Cold plan output failed");
}
Arm prepare(bool direct, const c::Context &context, const c::StorageOwner &owner,
            const c::ReadLease &weight, const m::Buffer &input, c::Queue &queue) {
  Arm arm;
  arm.direct = direct;
  const auto hd = desc(c::DataType::kBFloat16, 1, hidden);
  const auto wd = desc(c::DataType::kBFloat16, vocabulary, hidden);
  const auto ld = desc(direct ? c::DataType::kBFloat16 : c::DataType::kFloat32, 1, vocabulary);
  const auto id = desc(c::DataType::kInt32, 1, 1);
  auto builder = take(g::GraphBuilder::create());
  const auto x = take(builder.input(hd));
  const auto w = take(builder.constant(wd));
  const auto copied = take(builder.add(c::Copy{}, x));
  const std::array<std::int32_t, 2> axes{1, 0};
  const auto transposed = take(builder.add(take(c::View::permute(axes)), w));
  const auto head = take(builder.add(c::MatMul{}, copied, transposed));
  const auto logits = direct ? head : take(builder.add(c::Cast{c::DataType::kFloat32}, head));
  const auto top = take(builder.add_node(c::Operation(c::TopK{.count = 1}), std::array{logits}));
  const auto token = take(builder.result(top, 1));
  for (const auto output : {copied, logits, token}) check(builder.publish(output));
  arm.logical = take(std::move(builder).finish());
  const std::array constants{g::ConstantBinding{w, take(weight.tensor(wd)),
                                               g::ConstantPolicy::kBorrow, owner, weight}};
  arm.compiled = take(g::cuda::compile(arm.logical, context, owner,
      {.provider_replay = g::ProviderReplayPolicy::kAllowAny, .constants = constants}));
  if (arm.compiled.report.borrowed_constant_count() != 1 ||
      arm.compiled.report.materialized_constant_count() != 0 ||
      arm.compiled.report.materialized_constant_bytes() != 0)
    throw std::runtime_error("The two Graphs must borrow the same original bank");
  std::size_t heads = 0, top1 = 0;
  for (std::size_t i = 0; i < arm.compiled.report.step_count(); ++i) {
    const auto step = take(arm.compiled.report.step(i));
    if (step.provider.id == c::cublas::kProviderId) {
      ++heads; arm.head_implementation = step.implementation.value();
    }
    if (step.provider.id == c::cuda_native::kCcclProviderId) {
      ++top1;
      if (step.runtime.capture_compatible)
        throw std::runtime_error("Do not alter original managed Top1 capture admission");
    }
  }
  if (heads != 1 || top1 != 1 || arm.head_implementation != 1)
    throw std::runtime_error("Original consumer cublasLt implementation1 and CCCL Top1 required");
  arm.final_hidden = take(m::Buffer::create(owner.ref(), hidden * 2, 256));
  arm.logits = take(m::Buffer::create(owner.ref(), take(ld.required_bytes()), 256));
  arm.token = take(m::Buffer::create(owner.ref(), 4, 256));
  arm.slot = take(arm.compiled.executable.create_invocation());
  check(arm.slot.bind(x, take(c::ConstTensorView::create(hd, input.view()))));
  check(arm.slot.bind(copied, take(c::TensorView::create(hd, arm.final_hidden.view()))));
  check(arm.slot.bind(logits, take(c::TensorView::create(ld, arm.logits.view()))));
  check(arm.slot.bind(token, take(c::TensorView::create(id, arm.token.view()))));
  check(g::cuda::prepare_replay(arm.slot, queue,
      {.mode = g::ReplayMode::kPreferCapture, .host_wait = g::HostWaitPolicy::kAllow}));
  arm.cold = take(arm.slot.replay_report());
  if (arm.cold.route != g::ReplayRoute::kHybrid ||
      arm.cold.recorded_capture_range_count == 0)
    throw std::runtime_error("Real head capture plus managed Top1 tail required");
  return arm;
}
std::int32_t run(Arm &arm, c::Queue &queue) {
  { auto done = take(arm.slot.submit(queue)); check(done.wait()); }
  std::int32_t result = -1;
  check(arm.token.view().read(std::as_writable_bytes(std::span(&result, 1))));
  return result;
}
void verify(const Arm &arm, const std::vector<std::uint16_t> &hidden_bits,
            const std::vector<std::uint32_t> &reference, std::int32_t expected) {
  std::vector<std::uint16_t> actual_hidden(hidden_bits.size());
  check(arm.final_hidden.view().read(std::as_writable_bytes(std::span(actual_hidden))));
  if (actual_hidden != hidden_bits) throw std::runtime_error("Published hidden Copy differs");
  if (arm.direct) {
    std::vector<std::uint16_t> values(reference.size());
    check(arm.logits.view().read(std::as_writable_bytes(std::span(values))));
    for (std::size_t i = 0; i < values.size(); ++i)
      if (static_cast<std::uint32_t>(values[i]) << 16 != reference[i])
        throw std::runtime_error("Real BF16 head differs from original full logits");
  } else {
    std::vector<std::uint32_t> values(reference.size());
    check(arm.logits.view().read(std::as_writable_bytes(std::span(values))));
    if (values != reference) throw std::runtime_error("Real widened head differs from original full logits");
  }
  std::int32_t token = -1;
  check(arm.token.view().read(std::as_writable_bytes(std::span(&token, 1))));
  if (token != expected) throw std::runtime_error("Real suffix token differs");
}
double median(std::vector<double> x) {
  std::sort(x.begin(), x.end());
  return (x[(x.size()-1)/2] + x[x.size()/2]) / 2;
}
void print_array(std::ostream &out, const std::vector<double> &x) {
  out << '[';
  for (std::size_t i = 0; i < x.size(); ++i) { if (i) out << ','; out << x[i]; }
  out << ']';
}
struct Sample final {
  std::size_t cycle; unsigned position, arm;
  std::int64_t start_ns, end_ns; double us;
};

int main(int argc, char **argv) try {
  static_assert(std::endian::native == std::endian::little);
  if (argc != 5) throw std::runtime_error("Requires manifest hidden.bf16 logits.f32 outdir");
  const std::filesystem::path outdir(argv[4]);
  std::filesystem::create_directories(outdir);
  const auto hidden_bits = read_file<std::uint16_t>(argv[2], hidden);
  const auto reference = read_file<std::uint32_t>(argv[3], vocabulary);
  std::int32_t expected = 0;
  for (std::size_t i = 0; i < reference.size(); ++i) {
    if ((reference[i] & 65535u) || !std::isfinite(std::bit_cast<float>(reference[i])))
      throw std::runtime_error("Original reference must be finite exact BF16 widening");
    if (std::bit_cast<float>(reference[i]) > std::bit_cast<float>(reference[expected]))
      expected = static_cast<std::int32_t>(i);
  }
  auto context = take(g::cuda::create_context());
  auto owner = take(c::StorageOwner::adopt(context,
      take(c::cuda::MemoryResource::create(context, c::cuda::MemoryKind::kDevice))));
  auto queue = take(context.create_queue());
  check(queue.reserve_completions(2));
  auto weight = load_head(argv[1], owner);
  auto input = take(m::Buffer::create(owner.ref(), hidden * 2, 256));
  check(input.view().write(std::as_bytes(std::span(hidden_bits))));
  std::array arms{prepare(false, context, owner, weight, input, queue),
                  prepare(true, context, owner, weight, input, queue)};
  Drain drain{queue};
  for (auto &arm : arms) {
    if (run(arm, queue) != expected) throw std::runtime_error("Cold result differs");
    verify(arm, hidden_bits, reference, expected);
    check(g::cuda::prepare_replay(arm.slot, queue,
        {.mode = g::ReplayMode::kPreferCapture, .host_wait = g::HostWaitPolicy::kAllow}));
    arm.warm = take(arm.slot.replay_report());
    if (arm.warm.route != g::ReplayRoute::kHybrid ||
        arm.warm.recorded_capture_range_count != 0 ||
        arm.warm.reused_capture_range_count != arm.cold.recorded_capture_range_count)
      throw std::runtime_error("Unchanged actual head capture must be reused");
    print_plan(arm, outdir / (arm.direct ? "direct-cold-plan.json" : "cast-cold-plan.json"));
  }
  constexpr std::size_t warmup_per_arm = 32, cycles = 64;
  for (std::size_t i = 0; i < warmup_per_arm; ++i)
    for (unsigned j = 0; j < 2; ++j)
      if (run(arms[(i+j)%2], queue) != expected) throw std::runtime_error("Warm token differs");
  std::array<std::vector<double>, 2> wall;
  std::vector<double> paired;
  std::vector<Sample> samples;
  samples.reserve(cycles * 4); paired.reserve(cycles);
  for (auto &values : wall) values.reserve(cycles * 2);
  for (std::size_t cycle = 0; cycle < cycles; ++cycle) {
    const auto order = cycle % 2 == 0 ? std::array<unsigned,4>{0,1,1,0}
                                    : std::array<unsigned,4>{1,0,0,1};
    std::array<double,2> sums{};
    for (unsigned position = 0; position < 4; ++position) {
      const auto index = order[position];
      const auto before = Clock::now();
      const auto token = run(arms[index], queue);
      const auto after = Clock::now();
      if (token != expected) throw std::runtime_error("Measured token differs");
      const auto us = std::chrono::duration<double,std::micro>(after-before).count();
      wall[index].push_back(us); sums[index] += us;
      samples.push_back({cycle, position, index,
          std::chrono::duration_cast<std::chrono::nanoseconds>(before.time_since_epoch()).count(),
          std::chrono::duration_cast<std::chrono::nanoseconds>(after.time_since_epoch()).count(), us});
    }
    paired.push_back((sums[0]-sums[1])/2);
  }
  for (const auto &arm : arms) verify(arm, hidden_bits, reference, expected);
  std::ofstream rows(outdir / "samples.jsonl");
  rows << std::setprecision(12);
  for (const auto &s : samples)
    rows << "{\"cycle\":" << s.cycle << ",\"position\":" << s.position
         << ",\"arm\":\"" << (s.arm ? "direct" : "cast") << "\",\"start_ns\":"
         << s.start_ns << ",\"end_ns\":" << s.end_ns << ",\"wall_us\":" << s.us << "}\n";
  if (!rows) throw std::runtime_error("Sample output failed");
  std::ostringstream output;
  output << std::setprecision(12)
      << "{\"completed\":true,\"route\":\"hybrid\",\"policy\":\"PreferCapture\","
      << "\"same_original_shared_head_bytes\":" << weight_bytes
      << ",\"head_rows\":1,\"head_N\":" << vocabulary << ",\"head_K\":" << hidden
      << ",\"head_implementation\":1,\"expected_token\":" << expected
      << ",\"full_original_logits_bit_equal\":true,\"TopKvalue_published\":false"
      << ",\"warmup_per_arm\":" << warmup_per_arm << ",\"cycles\":" << cycles
      << ",\"samples_per_arm\":" << wall[0].size()
      << ",\"cast_wall_us_median\":" << median(wall[0])
      << ",\"direct_wall_us_median\":" << median(wall[1])
      << ",\"paired_cast_minus_direct_us_median\":" << median(paired)
      << ",\"cast_workspace_bytes\":" << arms[0].compiled.executable.workspace_bytes()
      << ",\"direct_workspace_bytes\":" << arms[1].compiled.executable.workspace_bytes()
      << ",\"cold_recorded\":[" << arms[0].cold.recorded_capture_range_count << ','
      << arms[1].cold.recorded_capture_range_count << "],\"warm_reused\":["
      << arms[0].warm.reused_capture_range_count << ',' << arms[1].warm.reused_capture_range_count
      << "],\"cast_wall_us\":";
  print_array(output, wall[0]); output << ",\"direct_wall_us\":"; print_array(output, wall[1]);
  output << ",\"paired_cast_minus_direct_us\":"; print_array(output, paired);
  output << ",\"wall_boundary\":\"public submit+Completion wait/destruction+actual4Bhosttoken\","
      << "\"limit\":\"Real Copy/head/Top1 suffix with original caller-logits topology and managed Top1 tail; fixed hidden replays the published norm result, not its producer. Local suffix benefit is not full-model throughput. Within-process samples correlated; no cache/shape matrix or profiler timing inference.\"}";
  std::ofstream summary(outdir / "summary.json");
  summary << output.str() << '\n';
  if (!summary) throw std::runtime_error("Summary output failed");
  std::cout << output.str() << '\n';
  return 0;
} catch (const std::exception &error) {
  std::cerr << error.what() << '\n';
  return 1;
}
