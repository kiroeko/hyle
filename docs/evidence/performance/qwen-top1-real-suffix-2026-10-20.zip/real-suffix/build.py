"""Compile/link one real suffix bench; never run GPU or rebuild products."""
from pathlib import Path
import hashlib
import importlib.util
import json
import struct
import sys
sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
A = S.parents[1]
ROOT = A.parents[1]
OUT = S / "checks/retry1"
spec = importlib.util.spec_from_file_location(
    "real_suffix_retained_helpers", A / "grouped-shared-activation/build_host.py")
h = importlib.util.module_from_spec(spec)
spec.loader.exec_module(h)
b, c = h.b, h.c
BASE = S.parent / "checks/qwen-link-plan.json"
RECIPE = S.parent / "checks/main-identity.json"
SOURCE = S / "real_suffix_bench.cc"
MANIFEST = A / "qwen-gpu-comparison/128-prefill/inputs/weights.tsv"
HIDDEN = A / "batch-graph-capture/correctness-final/trace/decode7/hidden.bf16"
LOGITS = HIDDEN.with_name("logits.f32")
PROOF = A / "decode-prepare-cost/correctness/summary.json"


def vector(value, name):
    if isinstance(value, dict):
        if value.get("path") == name:
            return value
        for child in value.values():
            if (found := vector(child, name)) is not None:
                return found
    elif isinstance(value, list):
        for child in value:
            if (found := vector(child, name)) is not None:
                return found
    return None


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    (OUT / "tmp").mkdir(exist_ok=True)
    assert not (OUT / "plan.json").exists(), "Retain the original attempt"
    base, recipe = c.read(BASE), c.read(RECIPE)
    for row in base["inputs"]:
        assert h.same_identity(row), row["path"]
    proof = c.read(PROOF)
    traces = []
    for path, name, expected in [
        (HIDDEN, "decode7/hidden.bf16", "db84650d85f3c3fea8e4c3d4bf891b1fc01a65aad3f7807e8eef53315f7723f2"),
        (LOGITS, "decode7/logits.f32", "8c90db2481c2110453c52633a8b3153fe37391085de09fb4e5a0943adfe396c1")]:
        row = vector(proof, name)
        assert row["byte_equal"] and row["actual"]["sha256"] == row["reference"]["sha256"] == expected
        assert b.identity(path)["sha256"] == expected
        traces.append(dict(retained=b.identity(path), d1_vector=row))
    manifest = MANIFEST.read_text(encoding="utf-8").splitlines()
    fields = manifest[3].split()
    assert fields == ["model.language_model.embed_tokens.weight", "BF16", "2", "248320", "2048", "87024", "1017118720"]
    shard = Path(manifest[1])
    assert shard.stat().st_size == 4548221488
    with shard.open("rb") as stream:
        header_size = struct.unpack("<Q", stream.read(8))[0]
        header = stream.read(header_size)
        entry = json.loads(header)["model.language_model.embed_tokens.weight"]
        assert header_size == 76648 and entry["dtype"] == "BF16" and entry["shape"] == [248320,2048]
        assert entry["data_offsets"] == [10368,1017129088]
        assert hashlib.sha256(header).hexdigest() == "ccba2c1f645fe59268f89ee7ea552e02ce6bf0c8a087bf332fb0e3bd99bfee9d"
        stream.seek(87024)
        remaining = 1017118720
        digest = hashlib.sha256()
        while remaining:
            chunk = stream.read(min(8 * 1024 * 1024, remaining))
            assert chunk
            digest.update(chunk)
            remaining -= len(chunk)
    weight = dict(path=str(shard), file_bytes=shard.stat().st_size,
                  file_mtime_ns=shard.stat().st_mtime_ns, offset=87024, bytes=1017118720,
                  sha256=digest.hexdigest(), safetensors_header_bytes=header_size,
                  safetensors_header_sha256=hashlib.sha256(header).hexdigest(), entry=entry)
    source = b.identity(SOURCE)
    command = b.host_command(recipe["command"], SOURCE, "bench", OUT)
    plan = dict(source=source, command=command, base=b.identity(BASE), recipe=b.identity(RECIPE),
        manifest=b.identity(MANIFEST), traces=traces, d1_proof=b.identity(PROOF), weight_range=weight,
        bench_CXX=1, product_CXX=0, SDK=0, NVCC=0, links=1, GPU=0,
        topology="Original published BF16 hidden bytes -> real Copy/published caller hidden -> MatMul{} with one shared Borrow BF16 head permute{1,0} -> optional F32 Cast/published logits -> original managed TopK1; only ID published, TopK value internal",
        route="Both PreferCapture, actual Hybrid required; cold recorded and second preparation reuses unchanged ranges. All preparation and exact full-output validation outside fixed timing.",
        run_budget=dict(independent_unprofiled_processes=3, structural_nsys_processes=1,
                        per_process_warmup_each_arm=32, per_process_cycles=64,
                        per_process_samples_each_arm=128, additional_windows=0),
        limits=["Same original hidden/weights and public MatMul numerical contract; root must verify actual kernel launch with the one structural profile.",
                "ReplayReport ranges alone do not prove that the head is captured; printed runtime facts plus root's fixed structural trace establish that scope.",
                "There is no per-token metadata/layout/reprepare in this local steady suffix. It does not measure the full model's D1 preparation.",
                "Caller F32 logits in Cast arm versus caller BF16 head output in direct arm intentionally preserves the real physical change; old internal head is not additionally published.",
                "Hidden bytes come from the original already published Copy result. Repeating the real Copy is the suffix boundary replay, not the original normalization producer.",
                "No full-model throughput claim or cache/shape matrix. No auxiliary stream events in this real suffix bench."])
    c.save(OUT / "plan.json", plan)
    c.save(S / "source-freeze.json", dict(source=source, helper=b.identity(Path(__file__)),
           manifest=plan["manifest"], traces=traces, weight_range=weight, design=plan["topology"]))
    env, runtime = b.environment(command, [], OUT)
    c.execute("compile", command, env, OUT)
    depfile = OUT / "bench-deps.json"
    dep = c.read(depfile)["Data"]
    receipt = dict(source=source, object=b.identity(OUT / "bench.obj"), command=command,
           source_dependencies=b.identity(depfile), dependencies=[b.identity(Path(p).resolve())
           for p in dict.fromkeys([dep["Source"], *dep["Includes"]])])
    c.save(OUT / "bench-identity.json", receipt)
    old_main = recipe["object"]
    assert sum(c.key(x["path"]) == c.key(old_main["path"]) for x in base["inputs"]) == 1
    link = [receipt["object"]["path"] if c.key(arg) == c.key(old_main["path"]) else arg
            for arg in base["command"]
            if not arg.upper().startswith(("/OUT:", "/MAP:", "/IMPLIB:", "/PDB:"))]
    image = OUT / "bench.exe"
    link += ["/OUT:" + str(image), "/MAP:" + str(image.with_suffix(".map")),
             "/IMPLIB:" + str(image.with_suffix(".lib"))]
    inputs = [receipt["object"] if c.key(row["path"]) == c.key(old_main["path"]) else row
              for row in base["inputs"]]
    for row in inputs:
        assert h.same_identity(row), row["path"]
    c.save(OUT / "link-plan.json", dict(command=link, inputs=inputs, base=b.identity(BASE),
           replacement=dict(before=old_main, after=receipt["object"]), product_objects_unchanged=True))
    env, runtime = b.environment(link, [x["path"] for x in inputs], OUT)
    c.save(OUT / "runtime-environment.json", dict(PATH=env["PATH"], runtime=runtime))
    c.execute("link", link, env, OUT)
    c.save(OUT / "image.json", b.identity(image))
    c.save(OUT / "run-plan.json", dict(image=b.identity(image),
           command_prefix=[str(image), str(MANIFEST), str(HIDDEN), str(LOGITS)],
           outdir_argument_required=True, suggested_outdir=str(S / "observations"),
           input_identities=[plan["manifest"], *[r["retained"] for r in traces]],
           weight_range=weight, link_plan=b.identity(OUT / "link-plan.json"),
           run_budget=plan["run_budget"], GPU_run=False))
    assert h.same_identity(source)
    c.save(OUT / "summary.json", dict(built=True, bench_CXX=1, links=1, product_CXX=0,
           SDK=0, NVCC=0, GPU=0, image=b.identity(image), correctness_not_run=True,
           performance_not_run=True, source_freeze=b.identity(S / "source-freeze.json")))
    print("REAL_SUFFIX_BUILT_1CXX_1LINK_NO_GPU", flush=True)


if __name__ == "__main__":
    main()
