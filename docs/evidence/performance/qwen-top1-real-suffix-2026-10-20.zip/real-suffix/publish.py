"""Archive the finite real-suffix decision, including failures and all samples."""
from pathlib import Path
import hashlib
import importlib.util
import json
import zipfile

S = Path(__file__).resolve().parent
B = S.parent
ROOT = B.parents[2]
spec = importlib.util.spec_from_file_location('top1_prior_publication_helpers', B / 'publish.py')
p = importlib.util.module_from_spec(spec)
spec.loader.exec_module(p)
def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))
def identity(path):
    value = Path(path).read_bytes()
    return dict(bytes=len(value), sha256=hashlib.sha256(value).hexdigest())

decision = read(S / 'decision.json')
runs = read(S / 'observations/summary.json')
assert runs['independent_processes'] == 3
assert all(r['observation']['full_original_logits_bit_equal'] for r in runs['processes'])
assert all(r['source_rows_verified'] == 256 for r in runs['processes'])
assert identity(ROOT / 'tools/qwen35_text/main.cc')['sha256'] == decision['consumer_sha256']
review = read(S / 'independent-review.json')
structure = read(S / 'structure/attribution.json')
name = 'qwen-top1-real-suffix-2026-10-20'
dest = ROOT / 'docs/evidence/performance'
target, archive = dest / (name + '.json'), dest / (name + '.zip')
assert not target.exists() and not archive.exists()
files = {'real-suffix/' + f.relative_to(S).as_posix():f for f in sorted(S.rglob('*')) if p.eligible(f)}
for folder in ('consumer', 'tests'):
    for f in sorted((B / folder).rglob('*')):
        if p.eligible(f):
            files['prior-source/' + f.relative_to(B).as_posix()] = f
for rel in ('regression/summary.json','regression/results.xml','correctness/summary.json',
            'checks/qwen-image.json','checks/qwen-link-plan.json','checks/main-identity.json'):
    files['prior-proof/' + rel] = B / rel
members = []
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for member, f in files.items():
        p.safe_member(member)
        data = f.read_bytes()
        z.writestr(member,data)
        members.append(dict(member=member,bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
    z.writestr('manifest.json',json.dumps(members,indent=2)+'\n')
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    assert len(set(z.namelist())) == len(z.namelist()) == len(members)+1
    for row in members:
        data = z.read(row['member'])
        assert len(data) == row['bytes'] and hashlib.sha256(data).hexdigest() == row['sha256']
result = dict(date='2026-10-20',scope='Actual shared-original-weight LM-head suffix on Windows RTX4070; public Graph, original Copy and caller-output topology, PreferCapture/Hybrid and eager CCCL Top1 tail.',
    decision=decision, independent_review=review, unprofiled=runs, structural_attribution=structure,
    source_freeze=read(S / 'source-freeze.json'),
    original_experiment='qwen-bf16-top1-2026-10-20.json',
    limits=[
        'Three independent unprofiled processes; within each process 64 ABBA/BAAB cycles,128 correlated observations per arm. All768 timed submissions retained.',
        'One additional independent Nsight Systems process validates structure; its timing is attribution, not an unprofiled throughput ranking.',
        'Exact original head weights and already normalized decode7 hidden; this fixed suffix does not repeat the normalization producer or per-token layout/metadata preparation.',
        'Preserve candidate full-model short/long negative medians and drift in the preceding publication. Do not replace those results with this suffix or with a more favorable summary statistic.',
        'Failed first CXX attempt is retained. Retry changes CompileOptions initialization syntax only; no product object, SDK or NVCC owner rebuilt.',
        'Source receipts and logs included; executable/object/SDK, raw profiler database and tensor/weight payloads excluded. Actual local profiler database and all object inputs retained.'
    ],archive=dict(path=archive.name,**identity(archive),members=len(members)+1),payloads=members,
    archive_verified=dict(CRC=True,all_payload_SHA256=True))
target.write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
assert read(target)['archive']['sha256'] == identity(archive)['sha256']
print(json.dumps(dict(evidence=dict(path=str(target),**identity(target)),archive=dict(path=str(archive),**identity(archive)),members=len(members)+1)))
