"""Three predetermined independent paired processes, then one structural trace."""
from pathlib import Path
from collections import Counter
import importlib.util
import json
import statistics
import sys

sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
A = S.parents[1]
def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module
h = load('real_suffix_build', S / 'build.py')
b, c = h.b, h.c
PLAN = S / 'checks/retry1/run-plan.json'
plan = c.read(PLAN)
link = c.read(plan['link_plan']['path'])

def check_inputs():
    for row in [plan['image'], plan['link_plan'], *plan['input_identities']]:
        assert h.h.same_identity(row), row['path']
    weight = plan['weight_range']
    p = Path(weight['path'])
    assert p.stat().st_size == weight['file_bytes']
    assert p.stat().st_mtime_ns == weight['file_mtime_ns']

def read_process(out):
    obs = c.read(out / 'data/summary.json')
    assert obs['completed'] and obs['full_original_logits_bit_equal']
    assert obs['route'] == 'hybrid' and obs['policy'] == 'PreferCapture'
    assert obs['samples_per_arm'] == 128 and obs['cycles'] == 64
    assert obs['expected_token'] == 10462
    assert obs['cold_recorded'] == obs['warm_reused'] == [1, 1]
    rows = [json.loads(line) for line in (out / 'data/samples.jsonl').read_text().splitlines()]
    assert len(rows) == 256
    paired = []
    for cycle in range(64):
        block = rows[cycle * 4:cycle * 4 + 4]
        expected = ['cast','direct','direct','cast'] if cycle % 2 == 0 else ['direct','cast','cast','direct']
        assert [r['arm'] for r in block] == expected
        for position, row in enumerate(block):
            assert row['position'] == position and row['cycle'] == cycle
            assert abs((row['end_ns'] - row['start_ns']) / 1000 - row['wall_us']) < 1e-5
        paired.append((sum(r['wall_us'] for r in block if r['arm'] == 'cast') -
                       sum(r['wall_us'] for r in block if r['arm'] == 'direct')) / 2)
    assert abs(statistics.median(paired) - obs['paired_cast_minus_direct_us_median']) < 1e-5
    plans = {arm:c.read(out / 'data' / (arm + '-cold-plan.json')) for arm in ('cast','direct')}
    for arm, row in plans.items():
        assert row['borrowed_constants'] == 1 and row['materialized_constants'] == 0
        assert row['cold_recorded'] == row['warm_reused'] == 1
        assert row['cold_reused'] == row['warm_recorded'] == 0
        assert row['logits_address_mod256'] == 0
        assert row['logits_bytes'] == 248320 * (4 if arm == 'cast' else 2)
    return dict(observation=obs, cold_plans=plans,
        paired_positive_cycles=sum(x > 0 for x in paired),
        paired_p25_p75_us=[statistics.quantiles(paired,n=4)[i] for i in (0,2)],
        paired_range_us=[min(paired),max(paired)],
        source_rows_verified=256, correlated_samples=True)

def timing():
    out = S / 'observations'
    out.mkdir(exist_ok=False)
    check_inputs()
    env, runtime = b.environment(link['command'], [r['path'] for r in link['inputs']], out)
    c.save(out / 'inputs.json', dict(run_plan=plan, runtime=runtime,
        independent_processes=3, extra_windows=0, profiler=False,
        external_sampler=False, full_model_throughput_claim=False))
    records = []
    for index in range(1,4):
        target = out / ('process-' + str(index).zfill(2))
        target.mkdir()
        command = [*plan['command_prefix'], str(target / 'data')]
        process = c.execute('bench', command, env, target)
        check_inputs()
        record = dict(index=index, process=process, **read_process(target))
        records.append(record)
        c.save(out / 'runs.json', records)
        print('REAL_SUFFIX_PROCESS', index, {key:record['observation'][key] for key in (
            'cast_wall_us_median','direct_wall_us_median','paired_cast_minus_direct_us_median')}, flush=True)
    medians = [r['observation']['paired_cast_minus_direct_us_median'] for r in records]
    result = dict(independent_processes=3, processes=records,
        paired_process_medians_us=medians, median_of_paired_process_medians_us=statistics.median(medians),
        all_paired_process_medians_positive=all(x>0 for x in medians),
        full_model_throughput_claim=False, independent_quality_acceptance=False,
        note='One fixed actual suffix; process-level results kept separate. No pooling correlated samples into independent process count.')
    c.save(out / 'summary.json', result)
    print('REAL_SUFFIX_THREE_PROCESSES', medians, flush=True)

def profile():
    assert c.read(S / 'observations/summary.json')['independent_processes'] == 3
    out = S / 'structure'
    out.mkdir(exist_ok=False)
    (out / 'tmp').mkdir()
    check_inputs()
    previous = c.read(S.parent / 'profile/plan.json')
    nsys = previous['commands']['profile'][0]
    stem = out / 'capture'
    target = [*plan['command_prefix'], str(out / 'data')]
    commands = dict(profile=[nsys,'profile','--trace=cuda','--sample=none','--cpuctxsw=none',
        '--cuda-trace-all-apis=true','--cuda-graph-trace=node:host-only',
        '--discard-environment=true','--output='+str(stem),*target],
        export=[nsys,'export','--type=sqlite','--output='+str(stem)+'.sqlite',str(stem)+'.nsys-rep'])
    env, runtime = b.environment(link['command'], [r['path'] for r in link['inputs']], out)
    c.save(out / 'plan.json', dict(commands=commands, image=plan['image'], runtime=runtime,
        structural_only=True, throughput_claim=False))
    for tag, command in commands.items():
        c.execute(tag, command, env, out)
    p = load('real_suffix_profile_helpers', A / 'cold-prepare-review/profile.py')
    data = p.trace(stem.with_suffix('.sqlite'))
    for kind, value in data['streams'].items():
        (out / ('target.'+kind+'.log')).write_text(value,encoding='utf-8')
    grouped = Counter()
    for row in data['kernels']:
        key = tuple((name, str(row.get(name))) for name in (
            'name','gridX','gridY','gridZ','blockX','blockY','blockZ','registersPerThread','localMemoryPerThread'))
        grouped[key] += 1
    result = dict(structural_only=True, throughput_claim=False,
        unique_kernels=[dict(metadata=dict(key),count=count) for key,count in grouped.items()],
        physical_kernels=len(data['kernels']),
        graph_kernel_nodes=sum(bool(row.get('graphNodeId')) for row in data['kernels']),
        diagnostics=data['diagnostics'], benchmark=c.read(out / 'data/summary.json'))
    c.save(out / 'summary.json', result)
    print('REAL_SUFFIX_STRUCTURE',len(data['kernels']),result['graph_kernel_nodes'],flush=True)

if __name__ == '__main__':
    {'timing':timing,'profile':profile}[sys.argv[1]]()
