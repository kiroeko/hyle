"""Offline W11 archive after the owner's8 completed model processes."""
from pathlib import Path
import datetime
import hashlib
import importlib.util
import json
import zipfile

W = Path(__file__).resolve().parent
R = W.parents[1]
V = R / '.scratch/inference-vulkan-engine-slots-20261027'
DEST = R / 'docs/evidence/performance/inference-vulkan-hybrid-baseline-2026-10-27.json'
spec = importlib.util.spec_from_file_location('vulkan_hybrid_offline_analysis', W / 'window.py')
window = importlib.util.module_from_spec(spec)
spec.loader.exec_module(window)
c = window.c


def encoded(value):
    return (json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + '\n').encode('utf-8')


def main():
    assert not DEST.exists() and not DEST.with_suffix('.zip').exists()
    plan, behavior = c.read(W / 'plan.json'), c.read(W / 'behavior-summary.json')
    formal = c.read(W / 'window-plan.json')
    timing, memory = window.analyze('timing'), window.analyze('memory')
    assert timing['processes'] == 6 and memory['processes'] == 2
    assert behavior['status'] == 'FIXED_WORK_TWO_ARM_BEHAVIOR_PASS'
    assert not list((W / 'window').glob('*/failure-*.json'))
    assert not list((W / 'behavior').glob('*/failure.json'))
    for row in (formal['original_plan'], formal['behavior_summary'], formal['check_script'], formal['script']):
        c.exact(row)
    first_prepare, second_prepare = (c.read(W / ('prepare-attempt%d.json' % i)) for i in (1, 2))
    assert all(row['status'] == 'PREPARE_FAILED_BEFORE_ANY_MODEL' and row['model_processes'] == row['GPU_processes'] == 0
               for row in (first_prepare, second_prepare))
    groups = []
    for name in ('cpu_ffn0', 'cpu_ffn1'):
        observer = memory['groups'][name]
        assert observer['setup_error'] is None and observer['thread_error'] is None
        assert observer['running_sample_count'] > 0
        assert set(observer['phase_windows']) == {'generation_prefill', 'generation_decode'}
        for phase in observer['phase_windows'].values():
            assert phase['sample_count'] > 0 and not phase['missing_boundary'] and not phase['ambiguous_boundary'] and not phase['invalid_boundary_order']
        groups.append(dict(arm=name, cpu_ffn_layers=int(name[-1]),
            original_host_weight_bytes=75501568 * int(name[-1]),
            original_device_weight_bytes=3763655360 - 75501568 * int(name[-1]),
            timing=timing['groups'][name], independent_memory_bytes=observer['sampled_peaks'],
            memory_observation=dict(sample_count=observer['sample_count'], running_sample_count=observer['running_sample_count'],
                requested_interval_seconds=0.01, actual_sample_gaps_ms=observer['actual_sample_gaps_ms'],
                sample_cost_ms=observer['sample_cost_ms'], null_sample_counts=observer['null_sample_counts'],
                unavailable_reasons=observer['unavailable_reasons'], ready_baseline=observer['ready_baseline'],
                setup_error=observer['setup_error'], thread_error=observer['thread_error'],
                phase_windows=observer['phase_windows'])))
    speed_keys = formal['output_fields']['speed']
    gain = {field: 100 * (timing['groups']['cpu_ffn1'][field]['median'] / timing['groups']['cpu_ffn0'][field]['median'] - 1)
            for field in speed_keys}
    overlap = {field: max(timing['groups']['cpu_ffn0'][field]['min'], timing['groups']['cpu_ffn1'][field]['min']) <=
                            min(timing['groups']['cpu_ffn0'][field]['max'], timing['groups']['cpu_ffn1'][field]['max'])
               for field in speed_keys}
    memory_deltas = {field: None if groups[0]['independent_memory_bytes'][field] is None or groups[1]['independent_memory_bytes'][field] is None
                    else groups[1]['independent_memory_bytes'][field] - groups[0]['independent_memory_bytes'][field]
                    for field in groups[0]['independent_memory_bytes']}
    records = timing['records'] + memory['records']
    assert len({row['process']['pid'] for row in records}) == 8
    start = min(row['process']['started_unix_ns'] for row in records)
    end = max(row['process']['finished_unix_ns'] for row in records)
    zone = datetime.timezone(datetime.timedelta(hours=8))
    clock = dict(first_parent_record_unix_ns=start, last_parent_record_unix_ns=end,
                 timezone='Asia/Shanghai',
                 first_parent_record=datetime.datetime.fromtimestamp(start / 1e9, zone).isoformat(),
                 last_parent_record=datetime.datetime.fromtimestamp(end / 1e9, zone).isoformat(),
                 scope='Retained runner parent-process bracket; original consumer endpoints alone determine speed.')
    files = {}

    def add(path, name):
        path = Path(path).resolve()
        assert path.is_file() and path.suffix.lower() in ('.py', '.json', '.cc', '.h', '.log', '.tsv', '.ids', '.txt', '.diff')
        assert path.stat().st_size < 8 << 20
        assert name not in files
        files[name] = path

    for path in sorted(W.rglob('*')):
        if not path.is_file() or '__pycache__' in path.parts:
            continue
        if path.suffix.lower() in ('.py', '.json', '.cc', '.h', '.log', '.tsv', '.ids', '.txt', '.diff'):
            add(path, 'evidence/' + path.relative_to(W).as_posix())
    for name in ('ready.json', 'plan.json', 'runtime.json', 'link-inputs.json', 'source-freeze.json', 'partial-build.json'):
        add(V / name, 'retained-build/' + name)
    for folder in ('source', 'recipes', 'compile', 'link'):
        for path in sorted((V / folder).rglob('*')):
            if path.is_file() and path.suffix.lower() in ('.py', '.json', '.cc', '.h', '.log', '.txt'):
                add(path, 'retained-build/' + path.relative_to(V).as_posix())
    for name, row in formal['observation_helpers'].items():
        c.exact(row)
        add(row['path'], 'observer/' + name + '-' + Path(row['path']).name)
    for name, row in [('weights.tsv', plan['inputs']['manifest']), ('prompt.ids', plan['inputs']['prompt'])]:
        c.exact(row); add(row['path'], 'input/' + name)
    c.exact(plan['fixed_decode']['source_report'])
    add(plan['fixed_decode']['source_report']['path'], 'input/retained-real-generation-source-report.json')
    model_identity = plan['inputs']['cached_identity_source']
    c.exact(model_identity)
    add(model_identity['path'], 'input/cached-body-identity-receipt.json')
    previous = R / 'docs/evidence/correctness/inference-vulkan-engine-slots-2026-10-27.json'
    add(previous, 'retained-build/previous-functional-evidence.json')
    manifest = [dict(archive_path=name, **c.pin(path)) for name, path in sorted(files.items())]
    receipt = dict(schema='hyle.vulkan-hybrid-fixed-window.v1', date='2026-10-27',
        status='FIRST_ATTEMPT_FORMAL8_COMPLETE_FIXED_WORK', scope=formal['scope'], measured_time=clock,
        counts=dict(formal_model_processes=8, timing_processes=6, independent_memory_processes=2,
                    prerequisite_behavior_processes=2, total_new_model_processes=10,
                    model_failed_attempts=0, model_reruns=0, prepare_only_failures=2,
                    new_CXX=0, new_links=0, new_SDK=0, new_shader_builds=0, downloads=0),
        identity=dict(image=plan['image'], ready=plan['ready'], runtime=plan['runtime'], closure=plan['closure'],
                      closure_count=145, source=plan['source'], source_scope=plan['image_scope'],
                      compiled=plan['compiled'], reference='docs/evidence/correctness/inference-vulkan-engine-slots-2026-10-27.json'),
        work=dict(**plan['expected'], fixed_decode=plan['fixed_decode'],
                  source_id=plan['inputs']['source_id'], selected_text_tensors=320, selected_MTP_tensors=0,
                  source_dtypes=plan['inputs']['dtype_counts'],
                  exact_same_image_and_original_weight_ranges=True, exact_same_prompt_and_consumed_IDs=True,
                  complete_non_time_reports_equal_to_per_arm_behavior=True, cross_placement16_prediction_IDs_equal=True,
                  fact_predicate='Whole original producer report except key seconds, *_seconds and *_per_second only.',
                  numerical_boundary='Observed16 greedy IDs agree. This is not intermediate-bit, trained-task quality, universal numerical equivalence or natural RequestLoop proof.'),
        protocol=dict(plan=c.pin(W / 'window-plan.json'), original_plan=c.pin(W / 'plan.json'),
                      **formal['protocol'], CPU_policy=plan['CPU_policy'], environment=plan['environment'],
                      endpoints=plan['endpoints'], observation_helpers=formal['observation_helpers'],
                      cache_boundary='The two explicit behavior checks preceded formal sampling. No explicit warmup, cache clearing or fixed clocks; normal file/driver/runtime caches are reused. Behavior timings are excluded.'),
        table=groups, cpu_ffn1_vs0_speed_percent=gain, observed_timing_ranges_overlap=overlap,
        independent_cpu_ffn1_minus0_peak_bytes=memory_deltas,
        observations=dict(timing_summary=c.pin(W / 'window/timing/summary.json'),
                          memory_summary=c.pin(W / 'window/memory/summary.json'), records=records,
                          behavior_summary=c.pin(W / 'behavior-summary.json'), behavior_results=behavior['results']),
        interpretation=['In this frozen default-native1 configuration CPU-FFN1 lowers original GPU weight placement by75501568B, while all measured median throughput values are lower.',
                        'Prefill median drops41.29% and combined drops15.86%; observed ranges do not overlap. Decode median drops4.98%, with overlapping ranges. Three samples do not establish statistical significance.',
                        'The two independent dedicated-memory sampled peaks differ by-70475776B; this single sample per arm is not a guaranteed physical allocation saving or exact phase-boundary delta. RAM/commit observed peaks increase.',
                        'The default switch changes actual placement, domain crossings and cold resource admission. These observations do not isolate a CPU kernel, transfer, scheduler or Vulkan root cause.',
                        'Qwen2B fits this GPU. This experiment quantifies the default placement tradeoff; it does not assert mixed inference should beat full GPU or that native1 is an optimal CPU policy.'],
        input_identity=dict(manifest=plan['inputs']['manifest'], prompt=plan['inputs']['prompt'],
                            selected_text_roles=plan['inputs']['selected_text_roles'], cpu_ffn1_roles=plan['inputs']['cpu_ffn1_roles'],
                            actual_body=plan['inputs']['actual_body'], cached_body_identity=plan['inputs']['cached_body_identity'],
                            cached_identity_source=model_identity, boundary=plan['inputs']['identity_boundary']),
        preserved_prepare_failures=dict(first=first_prepare, second=second_prepare,
            outcome='Both script assumption errors occurred before any model started: raw JSON-header length excluded8B prefix, then real BF16 checkpoint included36F32 state roles. Corrected against actual header; no product/input policy changes or model reruns.'),
        consumer_wiring_suggestion=plan['consumer_wiring_suggestion'],
        limits=formal['limits'] + ['Both ready-to-first-prefill memory baselines have no sample and remain unknown. GPU missing sample counts20/21 remain null; actual median cadence is about15.17/15.10ms rather than requested10ms.',
            'Original native execution-private storage is unknown and auto cache byte caps are unbounded here. Do not present requested-byte accounting as a physical memory cap.',
            'No CUDA/llama/MTP comparison or latest-source architecture result. All8 formal processes use the retained219a image and its own actual closed dependencies.'],
        archive=dict(path=str(DEST.with_suffix('.zip')), files=len(manifest) + 2, member_manifest='archive-manifest.json',
                     binaries_SDK_models=False, full_model_body_rehashed=False,
                     contents='Full scripts/preparation failures/commands/producer reports, retained build source and dependency/link receipts, original observer and raw memory samples. No weights, OBJ, executable, library or SDK.'))
    DEST.parent.mkdir(parents=True, exist_ok=True)
    DEST.write_bytes(encoded(receipt))
    with zipfile.ZipFile(DEST.with_suffix('.zip'), 'x', zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
        archive.writestr('receipt.json', encoded(receipt))
        archive.writestr('archive-manifest.json', encoded(manifest))
        for name, path in sorted(files.items()):
            archive.write(path, name)
    with zipfile.ZipFile(DEST.with_suffix('.zip')) as archive:
        assert archive.testzip() is None and len(archive.namelist()) == receipt['archive']['files']
        assert json.loads(archive.read('receipt.json')) == receipt
        assert json.loads(archive.read('archive-manifest.json')) == manifest
        for row in manifest:
            raw = archive.read(row['archive_path'])
            assert len(raw) == row['bytes'] and hashlib.sha256(raw).hexdigest() == row['sha256']
        assert all(Path(name).suffix.lower() not in ('.bin', '.obj', '.exe', '.dll', '.pdb', '.lib', '.gguf', '.safetensors') for name in archive.namelist())
    print(json.dumps(dict(status='ARCHIVED_AND_READ_BACK', receipt=c.pin(DEST), archive=c.pin(DEST.with_suffix('.zip')),
                          members=receipt['archive']['files'], new_model_processes=0), indent=2))


if __name__ == '__main__':
    main()
