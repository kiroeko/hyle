"""Finite retained-CLI Vulkan placement check; prepare never runs a model.

Owner explicitly invokes `behavior` after reserving the GPU. There is no
timing-window, memory-sidecar, build, download, retry or automatic follow-up.
"""
from pathlib import Path
import datetime
import hashlib
import json
import math
import os
import shlex
import struct
import subprocess
import sys
import time
import traceback

W = Path(__file__).resolve().parent
R = W.parents[1]
V = R / '.scratch/inference-vulkan-engine-slots-20261027'
INPUT = R / '.scratch/qwen35-unsloth-mtp-20261024/geometry-v2-check/original'
TAPE_SOURCE = R / '.scratch/inference-generation-batch-continuation-20261027/full-window/single-timing/01-hyle_plain/stdout.log'
MODEL_EVIDENCE = R / 'docs/evidence/correctness/mtp-qwen35-apple-k1-complete-input-2026-10-24.json'
ENV_KEYS = ('OMP_NUM_THREADS', 'OMP_THREAD_LIMIT', 'MKL_NUM_THREADS', 'OPENBLAS_NUM_THREADS',
            'VECLIB_MAXIMUM_THREADS', 'NUMEXPR_NUM_THREADS', 'GGML_CUDA_DISABLE_GRAPHS',
            'VK_ICD_FILENAMES', 'VK_DRIVER_FILES', 'VK_LAYER_PATH')
CACHE = {}


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def save(path, value):
    path = Path(path)
    assert path.resolve().is_relative_to(W)
    with path.open('x', encoding='utf-8') as stream:
        json.dump(value, stream, indent=2, ensure_ascii=False, allow_nan=False)
        stream.write('\n')


def pin(path):
    path = Path(path).resolve()
    name = str(path).casefold()
    if name not in CACHE:
        digest = hashlib.sha256()
        with path.open('rb') as stream:
            for block in iter(lambda: stream.read(4 << 20), b''):
                digest.update(block)
        CACHE[name] = dict(path=str(path), bytes=path.stat().st_size, sha256=digest.hexdigest())
    return dict(CACHE[name])


def exact(row):
    actual = pin(row['path'])
    assert (actual['bytes'], actual['sha256']) == (row['bytes'], row['sha256']), (row, actual)
    return actual


def model_ranges():
    lines = (INPUT / 'weights.tsv').read_text(encoding='utf-8-sig').splitlines()
    assert lines[0] == 'HYLE_QWEN_ROLE_FILES_V2'
    assert lines[1] == '4a76decdfa58a5fd6e15acea7ff410e84fd3e81cb6c39db8a658eeb23d869fbe'
    roles = []
    for line in lines[3:]:
        fields = shlex.split(line)
        if not fields or fields[0].startswith('mtp.'):
            continue
        rank = int(fields[2]); assert len(fields) == rank + 6
        roles.append(dict(name=fields[0], dtype=fields[1], shape=list(map(int, fields[3:3 + rank])),
            source=str(Path(fields[-3]).resolve()), offset=int(fields[-2]), bytes=int(fields[-1])))
    assert len(roles) == 320 and len({row['source'] for row in roles}) == 1
    source = Path(roles[0]['source'])
    metadata = source.stat()
    assert metadata.st_size == 4548221488
    with source.open('rb') as stream:
        raw_length = stream.read(8); length = struct.unpack('<Q', raw_length)[0]
        assert length == 76656
        raw_header = stream.read(length)
    header = json.loads(raw_header)
    payload = 8 + length
    selected = sorted(roles, key=lambda row: row['offset'])
    previous_end = payload
    for row in selected:
        entry = header[row['name']]
        assert row['dtype'] == entry['dtype'] == 'BF16' and row['shape'] == entry['shape']
        assert row['offset'] == payload + entry['data_offsets'][0]
        assert row['bytes'] == entry['data_offsets'][1] - entry['data_offsets'][0] == math.prod(row['shape']) * 2
        assert row['offset'] >= previous_end and row['offset'] + row['bytes'] <= metadata.st_size
        previous_end = row['offset'] + row['bytes']
    body = read(MODEL_EVIDENCE)['input']['original']
    assert body['bytes'] == metadata.st_size and body['sha256'] == 'aa33250c4fc64891ddfaba3a314fd9542ea371843c387178b425fbcc5ed680b1'
    assert hashlib.sha256(raw_header).hexdigest() == read(MODEL_EVIDENCE)['input']['header_sha256']
    ordinary_bytes = sum(row['bytes'] for row in roles)
    host_names = {'model.language_model.layers.0.post_attention_layernorm.weight',
                  *('model.language_model.layers.0.mlp.' + name + '.weight' for name in ('gate_proj', 'up_proj', 'down_proj'))}
    host_roles = [row for row in roles if row['name'] in host_names]
    assert len(host_roles) == 4 and sum(row['bytes'] for row in host_roles) == 75501568
    assert ordinary_bytes == 3763655360
    return dict(manifest=pin(INPUT / 'weights.tsv'), prompt=pin(INPUT / 'prompt.ids'),
        source_id=lines[1], geometry=lines[2], selected_text_roles=roles, text_tensors=len(roles),
        selected_weight_bytes=ordinary_bytes, cpu_ffn1_roles=host_roles, cpu_ffn1_weight_bytes=75501568,
        actual_body=dict(path=str(source), bytes=metadata.st_size, mtime_ns=metadata.st_mtime_ns,
                        header_bytes=length, header_sha256=hashlib.sha256(raw_header).hexdigest()),
        cached_body_identity=dict(path=str(source), bytes=body['bytes'], sha256=body['sha256']),
        cached_identity_source=pin(MODEL_EVIDENCE),
        identity_boundary='Existing complete-file SHA receipt reused; this preparation checks actual header and every selected ordinary role source/range/shape/dtype, but does not rehash the4.55GB body. MTP/image roles are not selected or read. No weight payload is copied.')


def prepare():
    assert not (W / 'plan.json').exists() and not (W / 'behavior').exists()
    ready = read(V / 'ready.json')
    assert ready['image']['sha256'] == '219a5b057d3347538e545d1c093d5fba5be9eb72aed42e0471bb0871a8ccbd8f'
    for field in ('image', 'inputs', 'runtime', 'plan'):
        exact(ready[field])
    closure = read(ready['inputs']['path'])
    assert len(closure) == len({row['path'].casefold() for row in closure}) == 145
    for row in closure:
        exact(row)
    for record in ready['compiled']:
        assert record['process']['exit'] == 0
        exact(record['object']); exact(record['dependencies']); exact(record['unit']['recipe'])
    runtime = read(ready['runtime']['path'])
    exact(runtime['native']); exact(runtime['native_hardlink'])
    source = V / 'source/engine/models/qwen35/main.cc'
    assert pin(source)['sha256'] == '3d85397362f767f7c9516faf1927086d1bf087afeb0ff856783dc8cab048a67d'
    source_text = source.read_text(encoding='utf-8')
    assert 'const auto previous = forced.empty() ? next : forced[step - 1];' in source_text
    assert 'step < steps && (!forced.empty() || !qwen35::is_end_of_generation(next))' in source_text
    data = model_ranges()
    prompt = list(map(int, (INPUT / 'prompt.ids').read_text().split()))
    assert len(prompt) == 154 and all(0 <= token < 248320 for token in prompt)
    old_report = read(TAPE_SOURCE)
    assert old_report['source_id'] == data['source_id'] and not old_report['mtp']
    assert old_report['prefill_target_rows'] == 154 and len(old_report['sessions']) == 1
    ids = old_report['sessions'][0]['result']['generated_ids'][:15]
    assert len(ids) == 15 and all(type(token) is int and 0 <= token < 248320 for token in ids)
    tape = W / 'fixed-decode.ids'
    with tape.open('x', encoding='ascii') as stream:
        stream.write(' '.join(map(str, ids)) + '\n')
    env = dict(PATH=runtime['PATH'], **{key: os.environ.get(key) for key in ENV_KEYS})
    arms = []
    for cpu_layers in (0, 1):
        command = [ready['image']['path'], '--inputs', str(INPUT), '--backend', 'vulkan',
            '--decode-ids', str(tape), '--steps', '16', '--capacity', '256',
            '--max-sessions', '1', '--active-sequences', '1', '--prefix-cache', 'off',
            '--replay', 'commands', '--progress', 'direct', '--mtp', 'off',
            '--sampling', 'greedy', '--cpu-ffn-layers', str(cpu_layers)]
        arms.append(dict(name='cpu_ffn' + str(cpu_layers), cpu_ffn_layers=cpu_layers, command=command,
                         expected_host_weight_bytes=75501568 * cpu_layers,
                         expected_device_weight_bytes=3763655360 - 75501568 * cpu_layers))
    save(W / 'plan.json', dict(status='PREPARED_NOT_RUN', scope='One frozen original CLI, two Vulkan placements, real fixed input replay.',
        ready=pin(V / 'ready.json'), image=ready['image'], closure=ready['inputs'], closure_count=145,
        compiled=ready['compiled'], runtime=ready['runtime'], source=pin(source),
        image_scope='Retained3d8539 Model/weights/Vulkan closure; not current5582 full canonical source. Both arms use exactly this same image.',
        inputs=data, fixed_decode=dict(file=pin(tape), ids=ids, source_report=pin(TAPE_SOURCE),
            selector='sessions[0].result.generated_ids[:15] from an existing actual ordinary real2B generation; this new run consumes these IDs as fixed inputs.'),
        expected=dict(prompt_rows=154, decode_rows=15, physical_calls=16, visible_tokens=169,
                      actual_target_rows=169, host_predictions=16, sampling_draw_cursor=0, capacity=256),
        environment=env, arms=arms, timeout_seconds=240,
        CPU_policy='Original CLI defaults: empty caller executor, ggml native_threads1; no configure_runtime_threads call, no ATen/processwide cap. Not the earlier CPU T4 representative configuration.',
        consumer_wiring_suggestion='Ordinary CLI does not expose the existing cold CPU thread/executor options. Preserve current policy in this comparison; a later consumer-only configuration improvement can reuse Backend/create_execution CPU options without changing this experiment or the foundation API.',
        comparison='Fixed work and independent initialized predictions; cross-placement ID differences will be reported rather than silently forcing numerical equivalence. No natural RequestLoop, cross-platform, CUDA, llama whole-layer offload, MTP, quality or general speed claim.',
        endpoints=dict(prefill='154/prefill_seconds', decode='15/decode_seconds', combined='16/session_seconds',
            boundary='Original fixed-replay consumer endpoints unchanged; reports emitted before normal Session/Model destruction. Process exit0 checks terminal cleanup; no absent final-version field is invented.'),
        workflow='Owner invokes behavior once. Execute cpu_ffn0 then cpu_ffn1, stop at first failed process/report gate, preserve raw command/log/process/error. No automatic retry or benchmark follow-up.',
        measurements=dict(behavior_only=True, planned_processes=2, formal_timing_processes=0, memory_observers=0,
                          SDK=0, CXX=0, links=0, shaders=0, downloads=0)))
    print('PREPARED_NOT_RUN: two arms, P154+15 fixed decode, no GPU process started', flush=True)


def validate(report, arm, plan):
    expected = dict(source_id=plan['inputs']['source_id'], score_dtype='F32', score_policy='bf16_inputs_f32_output',
        mtp=False, backend='vulkan', text_tensors=320, mtp_tensors=0, fixed_decode=True,
        requested_steps=16, generated_tokens=16, generated_decode_tokens=15, actual_graph_calls=16,
        prefill_graph_calls=1, decode_graph_calls=15, prefill_target_rows=154, actual_target_rows=169,
        committed_target_rows=169, committed_target_decode_rows=15, verified_target_rows=15,
        continuation_graph_calls=0, continuation_target_rows=0, actual_draft_rows=0,
        draft_rows=0, draft_rounds=0, agreements=0, consumed_drafts=0, sampling_draw_cursor=0,
        visible_tokens=169, cpu_ffn_layers=arm['cpu_ffn_layers'],
        original_host_weight_bytes=arm['expected_host_weight_bytes'],
        original_device_weight_bytes=arm['expected_device_weight_bytes'], diagnostic=False)
    for field, value in expected.items():
        assert report.get(field) == value, (field, report.get(field), value)
    assert report['decode_input_ids'] == plan['fixed_decode']['ids']
    assert len(report['generated_ids']) == 16 and all(type(token) is int and 0 <= token < 248320 for token in report['generated_ids'])
    for rate, seconds, count in [('prefill_tokens_per_second', 'prefill_seconds', 154),
                                 ('decode_output_tokens_per_second', 'decode_seconds', 15),
                                 ('output_tokens_per_second', 'session_seconds', 16)]:
        assert math.isfinite(report[seconds]) and report[seconds] > 0
        assert math.isclose(report[rate], count / report[seconds], rel_tol=1e-12)
    assert math.isclose(report['session_seconds'], report['prefill_seconds'] + report['decode_seconds'], rel_tol=1e-12)
    return expected


def behavior():
    plan = read(W / 'plan.json')
    assert plan['status'] == 'PREPARED_NOT_RUN'
    assert not (W / 'behavior').exists() and not (W / 'behavior-summary.json').exists(), 'No automatic rerun'
    for row in (plan['ready'], plan['image'], plan['closure'], plan['runtime'], plan['source'],
                plan['inputs']['manifest'], plan['inputs']['prompt'], plan['fixed_decode']['file']):
        exact(row)
    for row in read(plan['closure']['path']):
        exact(row)
    current = model_ranges()
    assert current == plan['inputs'], 'Input source/header/ranges changed since preparation'
    runtime = read(plan['runtime']['path'])
    exact(runtime['native']); exact(runtime['native_hardlink'])
    environment = dict(os.environ)
    for key, value in plan['environment'].items():
        if value is None:
            environment.pop(key, None)
        else:
            environment[key] = value
    environment.update(HF_HUB_OFFLINE='1', HF_DATASETS_OFFLINE='1', TRANSFORMERS_OFFLINE='1')
    results = []
    for arm in plan['arms']:
        folder = W / 'behavior' / arm['name']; folder.mkdir(parents=True, exist_ok=False)
        save(folder / 'command.json', dict(command=arm['command'], cwd=str(R),
             environment=plan['environment'], offline_only=True, timeout_seconds=plan['timeout_seconds']))
        started = datetime.datetime.now(datetime.timezone.utc).isoformat()
        begin = time.perf_counter(); expired = False
        with (folder / 'stdout.log').open('xb') as stdout, (folder / 'stderr.log').open('xb') as stderr:
            process = subprocess.Popen(arm['command'], cwd=R, env=environment, stdout=stdout, stderr=stderr)
            save(folder / 'running.json', dict(pid=process.pid, started_UTC=started))
            try:
                code = process.wait(timeout=plan['timeout_seconds'])
            except subprocess.TimeoutExpired:
                expired = True; process.kill(); code = process.wait(timeout=10)
        elapsed = time.perf_counter() - begin
        observed = dict(pid=process.pid, exit=code, timeout=expired, seconds=elapsed,
                        started_UTC=started, finished_UTC=datetime.datetime.now(datetime.timezone.utc).isoformat())
        save(folder / 'process.json', observed)
        try:
            assert code == 0 and not expired, observed
            report = read(folder / 'stdout.log')
            save(folder / 'report.json', report)
            work = validate(report, arm, plan)
            result = dict(name=arm['name'], status='PASS', process=observed, report=pin(folder / 'report.json'), work=work)
            save(folder / 'summary.json', result); results.append(result)
        except BaseException:
            save(folder / 'failure.json', dict(status='FAILED_FIRST_ATTEMPT_STOPPED', process=observed,
                error=traceback.format_exc(), completed_arms=results, reruns=0))
            raise
        print('BEHAVIOR_PASS ' + arm['name'] + ' PID' + str(process.pid), flush=True)
    reports = [read(row['report']['path']) for row in results]
    differences = [dict(index=i, cpu_ffn0=a, cpu_ffn1=b) for i, (a, b) in
                   enumerate(zip(reports[0]['generated_ids'], reports[1]['generated_ids'])) if a != b]
    save(W / 'behavior-summary.json', dict(status='FIXED_WORK_TWO_ARM_BEHAVIOR_PASS', results=results,
        fixed_input_ids_equal=True, cross_placement_predicted_ID_differences=differences,
        cross_placement_numerical_equivalence_claim=False, task_quality_claim=False, performance_claim=False,
        memory_observers=0, formal_timing_processes=0, reruns=0,
        next='No automatic follow-up. Owner decides whether the actual behavior permits a separate timing/memory window.'))


if __name__ == '__main__':
    action = sys.argv[1] if len(sys.argv) > 1 else 'prepare'
    if action == 'prepare':
        prepare()
    elif action == 'behavior':
        behavior()
    else:
        raise ValueError('Use prepare or behavior; no benchmark action is provided.')
