"""Six unmonitored timings plus two independent PSAPI/PDH observations.

Only `run timing` / `run memory` start models, after the owner's scheduling.
`plan` and `analyze` are offline. No build, download, warmup, retry or profiler.
"""
from pathlib import Path
import importlib.util
import json
import os
import statistics
import sys
import traceback

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = W.parents[1]
RUNNER = R / '.scratch/architecture-refactor-2026-10-18/d4-windows-preparation-2026-10-21/first-decode-startup-2026-10-21/multiturn/multiturn_run.py'
OBSERVER = R / '.scratch/shared-execution-20261021/observer.py'
PROBE = R / '.scratch/architecture-refactor-2026-10-18/qwen-gpu-comparison/memory-probe/memory_probe.py'


def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    value = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(value)
    return value


c = module('vulkan_hybrid_fixed_work_checks', W / 'check.py')


def facts(value):
    # Complete original report except clock/rate fields. No work, allocation,
    # placement, capture or generated-ID fields are silently discarded.
    if isinstance(value, dict):
        return {key: facts(item) for key, item in value.items()
                if key != 'seconds' and not key.endswith('_seconds') and not key.endswith('_per_second')}
    if isinstance(value, list):
        return [facts(item) for item in value]
    return value


def prepare():
    assert not (W / 'window-plan.json').exists() and not (W / 'window').exists()
    original = c.read(W / 'plan.json')
    behavior = c.read(W / 'behavior-summary.json')
    assert original['status'] == 'PREPARED_NOT_RUN' and behavior['status'] == 'FIXED_WORK_TWO_ARM_BEHAVIOR_PASS'
    assert len(behavior['results']) == 2 and not behavior['cross_placement_predicted_ID_differences']
    references = {}
    for row in behavior['results']:
        assert row['process']['exit'] == 0 and not row['process']['timeout']
        c.exact(row['report'])  # Small completed report only; no image/body hash here.
        references[row['name']] = row['report']
    arms = {arm['name']: arm for arm in original['arms']}
    assert set(arms) == set(references) == {'cpu_ffn0', 'cpu_ffn1'}
    orders = dict(timing=['cpu_ffn0', 'cpu_ffn1', 'cpu_ffn1', 'cpu_ffn0', 'cpu_ffn0', 'cpu_ffn1'],
                  memory=['cpu_ffn0', 'cpu_ffn1'])
    commands = {mode: [dict(ordinal=i, arm=name, folder=str(W / 'window' / mode / ('%02d-' % i + name)),
                            command=arms[name]['command'], image=original['image'], reference=references[name])
                      for i, name in enumerate(order, 1)] for mode, order in orders.items()}
    c.save(W / 'window-plan.json', dict(status='PREPARED_NOT_RUN', scope='Frozen219a Vulkan CPU-FFN0/1 fixed-work comparison only.',
        original_plan=c.pin(W / 'plan.json'), behavior_summary=c.pin(W / 'behavior-summary.json'),
        check_script=c.pin(W / 'check.py'), script=c.pin(Path(__file__)),
        image=original['image'], closure=original['closure'], closure_count=145, runtime=original['runtime'],
        environment=original['environment'], expected=original['expected'], fixed_decode=original['fixed_decode'],
        references=references, commands=commands,
        observation_helpers=dict(runner=c.pin(RUNNER), observer=c.pin(OBSERVER), memory_probe=c.pin(PROBE)),
        protocol=dict(timing_processes=6, timing_each_arm=3, memory_processes=2, memory_each_arm=1,
            timing_order=orders['timing'], memory_order=orders['memory'], warmups=0, retries=0,
            requested_sample_interval_seconds=0.01, runner_watchdog_seconds=900, old_samples_pooled=False,
            behavior_processes_enter_statistics=False,
            work_gate='Each full producer report must match its own successful behavior report after removing only clock/rate fields, and both arms retain identical16 predictions and the exact15 consumed input IDs.'),
        endpoints=original['endpoints'], CPU_policy=original['CPU_policy'],
        consumer_wiring_suggestion=original['consumer_wiring_suggestion'],
        output_fields=dict(speed=['prefill_tokens_per_second', 'decode_output_tokens_per_second', 'output_tokens_per_second'],
            durations=['prefill_seconds', 'decode_seconds', 'session_seconds', 'startup_to_ready_seconds', 'startup_to_endpoint_seconds'],
            timing_statistics=['count', 'median', 'min', 'max', 'samples'],
            memory=['sampled_max_working_set_bytes', 'observed_os_peak_working_set_bytes', 'sampled_max_private_commit_bytes',
                    'observed_os_peak_commit_bytes', 'sampled_peak_gpu_dedicated_bytes', 'sampled_peak_gpu_shared_bytes', 'sampled_peak_gpu_total_bytes'],
            observer_context=['phase_windows', 'ready_baseline', 'actual_sample_gaps_ms', 'sample_cost_ms',
                              'null_sample_counts', 'unavailable_reasons', 'setup_error', 'thread_error']),
        limits=['Unmonitored timing processes alone determine speed. Independent sampled memory processes never enter timing statistics.',
                'Descriptive3-sample ranges, not statistical significance. No fixed clocks, profiler, warmup, page-cache clearing or device exclusivity claim.',
                'WDDM PSAPI/PDH samples are lower bounds. Missing counters stay null; dedicated/shared independent maxima and CPU/RAM/GPU shared values must not be added.',
                'Original fixed-replay endpoints are retained; no natural RequestLoop, current-full-source, CUDA/llama offload, MTP, quality or broad deployment claim.',
                'Default native1/empty executor remains; ATen/processwide CPU counts are not clamped and this is separate from the older T4 CPU baseline.'],
        during_plan=dict(models=0, GPU_queries=0, builds=0, downloads=0, large_hashes=0, archives=0)))
    print('WINDOW_PREPARED_NOT_RUN:6 timing+2 independent memory; no model/GPU query', flush=True)


def preflight(plan):
    original = c.read(W / 'plan.json')
    for row in (plan['original_plan'], plan['check_script'], plan['script'], plan['behavior_summary'],
                plan['image'], plan['closure'], plan['runtime'], original['source'],
                original['inputs']['manifest'], original['inputs']['prompt'], original['fixed_decode']['file']):
        c.exact(row)
    for row in c.read(plan['closure']['path']):
        c.exact(row)
    assert c.model_ranges() == original['inputs']
    runtime = c.read(plan['runtime']['path'])
    c.exact(runtime['native']); c.exact(runtime['native_hardlink'])
    for row in plan['observation_helpers'].values():
        c.exact(row)
    environment = dict(os.environ)
    for key, value in plan['environment'].items():
        if value is None:
            environment.pop(key, None)
        else:
            environment[key] = value
    environment.update(HF_HUB_OFFLINE='1', HF_DATASETS_OFFLINE='1', TRANSFORMERS_OFFLINE='1')
    return original, environment


def observed_report(entry, original):
    folder = Path(entry['folder'])
    record = c.read(folder / 'result.json')
    assert record['exit'] == 0 and not record.get('timeout') and not record['reader_errors']
    assert record['image'] == original['image'] and record['command'] == entry['command']
    report = c.read(folder / 'stdout.log')
    arm = next(value for value in original['arms'] if value['name'] == entry['arm'])
    c.validate(report, arm, original)
    c.exact(entry['reference'])
    reference = c.read(entry['reference']['path'])
    assert facts(report) == facts(reference), 'Complete non-time report differs: ' + entry['arm']
    target = folder / 'report.json'
    if target.exists():
        assert c.read(target) == report
    else:
        c.save(target, report)
    return report, record


def stats(values):
    return dict(count=len(values), median=statistics.median(values), min=min(values), max=max(values), samples=values)


def analyze(mode):
    assert mode in ('timing', 'memory')
    plan = c.read(W / 'window-plan.json'); original = c.read(W / 'plan.json')
    reports = []
    for entry in plan['commands'][mode]:
        report, process = observed_report(entry, original)
        reports.append(dict(arm=entry['arm'], process=process, report=c.pin(Path(entry['folder']) / 'report.json')))
    groups = {}
    for arm in ('cpu_ffn0', 'cpu_ffn1'):
        selected = [entry for entry in plan['commands'][mode] if entry['arm'] == arm]
        if mode == 'timing':
            assert len(selected) == 3
            groups[arm] = {field: stats([c.read(Path(entry['folder']) / 'report.json')[field] for entry in selected])
                          for field in (*plan['output_fields']['speed'], *plan['output_fields']['durations'])}
        else:
            assert len(selected) == 1
            groups[arm] = c.read(Path(selected[0]['folder']) / 'memory-summary.json')
            assert not groups[arm]['throughput_evidence']
    result = dict(status='COMPLETE_FIXED_WORK_WITHIN_ARM', mode=mode, processes=len(reports),
        records=reports, groups=groups, complete_non_time_reports_equal_within_arm=True,
        cross_placement_prediction_IDs_equal=True, expected_work=plan['expected'],
        throughput_evidence=mode == 'timing', old_samples_pooled=False,
        behavior_processes_enter_statistics=False, limits=plan['limits'])
    path = W / 'window' / mode / 'summary.json'
    if path.exists():
        assert c.read(path) == result
    else:
        c.save(path, result)
    return result


def run(mode):
    assert mode in ('timing', 'memory')
    plan = c.read(W / 'window-plan.json')
    output = W / 'window' / mode
    assert not output.exists(), 'No automatic retry or replacement samples'
    if mode == 'memory':
        assert c.read(W / 'window/timing/summary.json')['status'] == 'COMPLETE_FIXED_WORK_WITHIN_ARM'
    original, environment = preflight(plan)
    runner = module('vulkan_retained_multiturn_observer_runner', RUNNER)
    observer = module('vulkan_retained_phase_observer', OBSERVER)
    observer.install(runner)
    assert Path(runner.SAMPLER).resolve() == PROBE.resolve()
    assert Path(runner.ROOT).resolve() == R
    output.mkdir(parents=True, exist_ok=False)
    c.save(output / 'inputs.json', dict(plan=c.pin(W / 'window-plan.json'), mode=mode, commands=plan['commands'][mode]))
    for entry in plan['commands'][mode]:
        print('WINDOW_BEGIN', mode, entry['ordinal'], entry['arm'], flush=True)
        folder = Path(entry['folder'])
        try:
            runner.execute(folder, entry['arm'], entry['command'], environment, mode == 'memory')
            observed_report(entry, original)
        except BaseException:
            c.save(output / ('failure-%02d.json' % entry['ordinal']), dict(status='STOPPED_AT_FIRST_FAILURE',
                arm=entry['arm'], folder=str(folder), original_error=traceback.format_exc(),
                model_reruns=0, next='Preserve actual process/logs. If only parser assumptions failed after exit0, repair and analyze the original outputs; never rerun them automatically.'))
            raise
        print('WINDOW_END', mode, entry['ordinal'], entry['arm'], flush=True)
    result = analyze(mode)
    print(result['status'], mode, result['processes'], flush=True)


if __name__ == '__main__':
    action = sys.argv[1] if len(sys.argv) > 1 else 'plan'
    if action == 'plan':
        prepare()
    elif action == 'run' and len(sys.argv) == 3:
        run(sys.argv[2])
    elif action == 'analyze' and len(sys.argv) == 3:
        print(analyze(sys.argv[2])['status'], flush=True)
    else:
        raise ValueError('Use plan, run timing|memory, or analyze timing|memory.')
