"""Private observer adapter for actual single/multi-session phase marker names.

No GPU calls occur on import. install() changes only the retained runner's two
observer functions; model commands, timers and the original MemoryProbe remain.
"""
import re
import statistics

KEYS=('working_set_bytes','private_commit_bytes','gpu_dedicated_bytes','gpu_shared_bytes','gpu_total_bytes')
PHASE=re.compile(r'\bmemory_phase=([A-Za-z0-9][A-Za-z0-9_-]*_(?:prefill|decode)_(?:begin|end))\b')

def marker(line):
    match=PHASE.search(line)
    if match:return match[1]
    if line.startswith('weights_load_seconds='):return 'model_loaded'
    if line.startswith('initialized '):return 'ready_before_prefill'
    if line.startswith('measure_memory '):
        match=re.search(r'\bname=(\S+)',line)
        return match[1] if match else None
    return None

def stats(values):
    return dict(count=len(values),min=min(values) if values else None,
        median=statistics.median(values) if values else None,max=max(values) if values else None,samples=values)

def memory_summary(sampled,record):
    running=[x for x in sampled['samples'] if x.get('process_running')]
    phase_records={}
    for row in record['markers']:
        match=re.fullmatch(r'(.+_(?:prefill|decode))_(begin|end)',row['name'])
        if match:phase_records.setdefault(match[1],dict(begin=[],end=[]))[match[2]].append(row['timestamp_ns'])
    first_ns=min((x for p in phase_records.values() for x in p['begin']),default=None)
    ready_candidates=[x['timestamp_ns'] for x in record['markers']
        if x['name'] in ('ready_before_prefill','ready_before_first','ready')
        and (first_ns is None or x['timestamp_ns']<=first_ns)]
    ready_ns=max(ready_candidates,default=None)
    ready_rows=[x for x in running if ready_ns is not None and first_ns is not None and ready_ns<=x['timestamp_ns']<=first_ns]
    windows={}
    for name,edges in phase_records.items():
        # Never silently collapse duplicate names or invent the missing edge.
        ambiguous=len(edges['begin'])>1 or len(edges['end'])>1
        begin=edges['begin'][0] if len(edges['begin'])==1 else None
        end=edges['end'][0] if len(edges['end'])==1 else None
        missing=not edges['begin'] or not edges['end']
        invalid_order=begin is not None and end is not None and end<begin
        valid=not (ambiguous or missing or invalid_order)
        rows=[x for x in running if begin<=x['timestamp_ns']<=end] if valid else []
        before=max((x for x in running if valid and x['timestamp_ns']<=begin),key=lambda x:x['timestamp_ns'],default=None)
        after=min((x for x in running if valid and x['timestamp_ns']>=end),key=lambda x:x['timestamp_ns'],default=None)
        windows[name]=dict(begin_ns=begin,end_ns=end,received_boundary_counts={k:len(v) for k,v in edges.items()},
            missing_boundary=missing,ambiguous_boundary=ambiguous,invalid_boundary_order=invalid_order,
            sample_count=len(rows),exact_phase_boundary_values=False,boundary_before=before,boundary_after=after,
            bracket_ages_ns=dict(before=begin-before['timestamp_ns'] if before else None,after=after['timestamp_ns']-end if after else None),
            values={key:stats([x[key] for x in rows if x.get(key) is not None]) for key in KEYS},
            null_sample_counts={key:sum(x.get(key) is None for x in rows) for key in KEYS},
            bracket_delta_bytes={key:after[key]-before[key] if before and after and before.get(key) is not None and after.get(key) is not None else None for key in KEYS})
    reasons={}
    for row in sampled['samples']:
        for kind in ('dedicated','shared'):
            reason=row.get('gpu_'+kind+'_unavailable_reason')
            if reason:reasons[kind+':'+reason]=reasons.get(kind+':'+reason,0)+1
    gaps=[(b['timestamp_ns']-a['timestamp_ns'])/1e6 for a,b in zip(running,running[1:])]
    return dict(sample_count=len(sampled['samples']),running_sample_count=len(running),sampled_peaks=sampled['peaks'],
        phase_windows=windows,phase_window_count=len(windows),actual_sample_gaps_ms=stats(gaps),
        sample_cost_ms=stats([x['sample_duration_ns']/1e6 for x in running if 'sample_duration_ns' in x]),
        null_sample_counts={k:sum(x.get(k) is None for x in sampled['samples']) for k in KEYS},
        ready_baseline=dict(ready_marker_ns=ready_ns,first_prefill_marker_ns=first_ns,
            sample=ready_rows[-1] if ready_rows else None,unknown=not ready_rows,
            definition='Last process-running sample between received ready and earliest actual prefill-begin; null when none exists.'),
        unavailable_reasons=reasons,setup_error=sampled['gpu_setup_error'],thread_error=sampled['thread_error'],
        throughput_evidence=False,limits=[
            'All boundaries are parent receipt times from live stderr, not exact device/allocator times. Phase names are discovered from actual markers, including session prefixes.',
            'Missing/duplicate/reversed boundaries have no derived phase values; short/full-hit phases may have zero samples. Null bytes remain null, never zero-filled.',
            'PSAPI/PDH sampled maxima are lower bounds, not physical allocation totals. Dedicated/shared separate maxima must not be added; total uses simultaneous available counters.',
            'Neighbor-sample phase deltas include bracket age and may include subsequent work or teardown; they do not attribute allocations or frees.',
            'Old runs whose observer dropped session-prefixed markers cannot have timestamped phase samples reconstructed from untimestamped stderr. This adapter does not rewrite them.',
            'Memory sampling is independent and never contributes to unmonitored timing denominators.'])

def install(module):
    module.marker=marker
    module.memory_summary=memory_summary
    return module
