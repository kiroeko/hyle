"""Finite shared-schedule observations. Root runs consumers; no build or profiler.

prepare-inputs and plan never start a consumer. run --mode correctness|timing|memory
is the explicit execution entry point. Results live only below this new stage.
"""
from pathlib import Path
import argparse
import hashlib
import importlib.util
import json
import os
import re
import statistics
import subprocess
import sys
import threading
import time

sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
D = S.parents[1]
A = D.parent
ROOT = A.parents[1]
ENVIRONMENT = D / 'checks/link1/runtime-environment.json'
SAMPLER = A / 'qwen-gpu-comparison/memory-probe/memory_probe.py'
KEYS = ('working_set_bytes', 'private_commit_bytes', 'gpu_dedicated_bytes',
        'gpu_shared_bytes', 'gpu_total_bytes')


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def save(path, value):
    Path(path).write_text(json.dumps(value, indent=2, allow_nan=False) + '\n', encoding='utf-8')


def identity(path):
    path = Path(path).resolve()
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(8 << 20), b''):
            h.update(chunk)
    return dict(path=str(path), bytes=path.stat().st_size, sha256=h.hexdigest())


def stats(values):
    return dict(count=len(values), min=min(values), median=statistics.median(values),
                max=max(values), samples=values) if values else dict(count=0, min=None,
                median=None, max=None, samples=[])


def write_once(path, text):
    data = text.encode('utf-8')
    if path.exists():
        if path.read_bytes() != data:
            raise RuntimeError('Refuse to overwrite different prior input: ' + str(path))
    else:
        path.write_bytes(data)


def original_commands():
    hyle = read(A / 'decode-current-rebenchmark/timing/02-current.command.json')['command']
    peer = read(A / 'decode-current-rebenchmark/timing/03-llama.command.json')['command']
    return hyle, peer


def prepare_inputs():
    hc, pc = original_commands()
    fixed_path = Path(pc[2])
    fixed = read(fixed_path)
    prompt, tape = fixed['prompt_ids'], fixed['decode_input_ids']
    prompt_path = Path(hc[hc.index('--inputs') + 1]) / 'prompt.ids'
    assert list(map(int, prompt_path.read_text().split())) == prompt
    tape_path = Path(hc[hc.index('--decode-ids') + 1])
    assert list(map(int, tape_path.read_text().split())) == tape
    assert len(prompt) == 128 and len(tape) == 31
    plans = {}
    for name, sizes, capacity in [('short', [(128, 8), (16, 15)], 256),
                                  ('long', [(256, 32)] * 3, 1024)]:
        folder = S / 'inputs' / name
        folder.mkdir(parents=True, exist_ok=True)
        phases, lines, tape_at, visible, call_at = [], [], 0, 0, 0
        for turn, (np, nd) in enumerate(sizes, 1):
            for kind, count in [('prompt', np), ('decode', nd)]:
                if turn == 1 and kind == 'prompt':
                    ids = [prompt[i % len(prompt)] for i in range(count)]
                    origin = 'Original128 prompt; repeated exactly for initial256.'
                else:
                    ids = [tape[(tape_at + i) % len(tape)] for i in range(count)]
                    origin = dict(source='Original31 decode tape repeated', begin=tape_at, end=tape_at + count)
                    tape_at += count
                filename = f'round{turn}_{kind}.ids'
                write_once(folder / filename, ' '.join(map(str, ids)) + '\n')
                lines.append(f'{kind} {filename}')
                calls = 1 if kind == 'prompt' else count
                phases.append(dict(turn=turn, kind='prefill' if kind == 'prompt' else 'decode',
                    name=f'round{turn}_' + ('prefill' if kind == 'prompt' else 'decode'),
                    input_tokens=count, calls=calls, generated_tokens=calls,
                    visible_before=visible, visible_tokens=visible + count,
                    first_call=call_at, source=origin, ids=ids, file=identity(folder / filename)))
                visible += count
                call_at += calls
        manifest = folder / 'schedule.txt'
        write_once(manifest, '\n'.join(lines) + '\n')
        assert visible <= capacity
        plans[name] = dict(manifest=identity(manifest), capacity=capacity, phases=phases,
            processed_tokens=visible, generated_tokens=call_at, phase_count=len(phases),
            turn_count=len(sizes), synthetic=True, teacher_forced=True,
            natural_conversation=False, prefix_reset=False,
            generated_token_definition='One returned last-row sampled token per prompt call and per decode call; not free-running generation.')
    result = dict(schema='hyle.finite-multiturn-input-plan.v1', plans=plans,
        original_fixed_inputs=identity(fixed_path), original_decode_tape=identity(tape_path),
        original_command_records=[identity(A / 'decode-current-rebenchmark/timing' / x)
            for x in ('02-current.command.json', '03-llama.command.json')],
        input_format='tools/qwen35_text/schedule.h: alternating prompt IDSFILE / decode IDSFILE; relative paths.',
        long_scope='Synthetic fixed-ID long-context journey, 3 rounds, capacity1024; no natural chat, quality or arbitrary-context claim.',
        builds=0, GPU_runs=0)
    path = S / 'inputs/plan.json'
    if path.exists() and read(path) != result:
        raise RuntimeError('Input provenance changed; preserve prior plan instead of overwriting it')
    save(path, result)
    return result


def marker(line):
    match = re.search(r'\bmemory_phase=(round\d+_(?:prefill|decode)_(?:begin|end))\b', line)
    if match:
        return match.group(1)
    if line.startswith('weights_load_seconds='):
        return 'model_loaded'
    if line.startswith('initialized '):
        return 'ready_before_prefill'
    if line.startswith('measure_memory '):
        match = re.search(r'\bname=(\S+)', line)
        return match.group(1) if match else None
    return None


def parse_steps(stderr):
    rows = []
    for line in stderr.splitlines():
        match = re.match(r'^(round(\d+)_(prefill|decode(\d+)))\s+tokens=', line)
        if not match:
            continue
        fields = dict(re.findall(r'(\w+)=([^\s]+)', line))
        row = dict(name=match[1], turn=int(match[2]), kind='prefill' if match[3] == 'prefill' else 'decode',
                   local_decode_index=int(match[4]) if match[4] else None)
        for key, dst in [('tokens', 'input_tokens'), ('visible', 'visible_tokens'), ('next', 'predicted_id')]:
            if key in fields:
                row[dst] = int(fields[key])
        if 'predicted' in fields:
            row['predicted_id'] = int(fields['predicted'])
        for key, dst in [('step_seconds', 'step_seconds'), ('seconds', 'submit_to_token_seconds'),
                         ('submit_seconds', 'submit_seconds'), ('cold_batch_seconds', 'cold_batch_seconds')]:
            if key in fields:
                row[dst] = float(fields[key])
        rows.append(row)
    return rows


def parse_observation(folder, arm, expected):
    stderr = (folder / 'stderr.log').read_text(encoding='utf-8', errors='replace')
    if arm == 'peer':
        raw = read(folder / 'peer-result.json')
    else:
        lines = (folder / 'stdout.log').read_text(encoding='utf-8', errors='replace').splitlines()
        raw = json.loads(next(line for line in reversed(lines) if line.startswith('{')))
    for key in ('processed_tokens', 'generated_tokens', 'phase_count', 'turn_count'):
        assert raw[key] == expected[key], (key, raw.get(key), expected[key])
    assert raw['session_seconds'] > 0 and raw['startup_total_seconds'] >= raw['session_seconds']
    phases = raw['phases']
    assert len(phases) == len(expected['phases'])
    steps = parse_steps(stderr)
    by_turn = {}
    for phase, plan in zip(phases, expected['phases']):
        for key in ('turn', 'kind', 'name', 'input_tokens'):
            assert phase[key] == plan[key], (key, phase, plan)
        assert phase['context_before'] == plan['visible_before']
        assert phase['context_after'] == plan['visible_tokens']
        assert phase['seconds'] > 0 and phase['step_sum_seconds'] > 0
        turn = by_turn.setdefault(str(phase['turn']), {})
        local = [x for x in steps if x['turn'] == phase['turn'] and x['kind'] == phase['kind']]
        if local:
            assert len(local) == plan['calls']
            assert [x['visible_tokens'] for x in local] == (
                [plan['visible_tokens']] if phase['kind'] == 'prefill' else
                list(range(plan['visible_before'] + 1, plan['visible_tokens'] + 1)))
        entry = dict(input_tokens=phase['input_tokens'], calls=plan['calls'],
            complete_segment_seconds=phase['seconds'], step_sum_seconds=phase['step_sum_seconds'],
            tokens_per_second=phase['input_tokens'] / phase['seconds'], steps=local)
        if phase['kind'] == 'decode':
            ds = [x['step_seconds'] for x in local if 'step_seconds' in x]
            entry.update(full_decode_seconds=phase['seconds'],
                full_decode_tokens_per_second=plan['calls'] / phase['seconds'],
                stable_definition='Within this round, decode7..end; excludes first6 only for this diagnostic.',
                stable_decode_seconds=sum(ds[6:]) if len(ds) == plan['calls'] and len(ds) > 6 else None,
                stable_decode_tokens_per_second=(len(ds) - 6) / sum(ds[6:]) if len(ds) == plan['calls'] and len(ds) > 6 else None,
                first_two_step_seconds=sum(ds[:2]) if len(ds) >= 2 else None)
        else:
            entry['time_to_first_returned_token_seconds'] = phase['seconds']
        turn[phase['kind']] = entry
    step_sum = sum(p['step_sum_seconds'] for p in phases)
    loading = dict(raw.get('loading', {}))
    for line in stderr.splitlines():
        if line.startswith('weights_load_seconds='):
            loading['model_load_seconds'] = float(line.split('=', 1)[1])
        elif line.startswith('initialized '):
            for key, val in re.findall(r'(\w+)=([^\s]+)', line):
                try:
                    loading[key] = float(val)
                except ValueError:
                    pass
        elif line.startswith('first_token_elapsed_seconds='):
            loading['first_token_elapsed_seconds'] = float(line.split('=', 1)[1])
    metrics = dict(session_seconds=raw['session_seconds'], startup_total_seconds=raw['startup_total_seconds'],
        processed_tokens_per_second=raw['processed_tokens'] / raw['session_seconds'],
        output_tokens_per_second=raw['generated_tokens'] / raw['session_seconds'],
        cold_processed_tokens_per_second=raw['processed_tokens'] / raw['startup_total_seconds'],
        cold_output_tokens_per_second=raw['generated_tokens'] / raw['startup_total_seconds'],
        compute_step_sum_seconds=step_sum,
        session_minus_step_sum_seconds=raw['session_seconds'] - step_sum)
    ids = raw.get('predicted_ids', raw.get('generated_ids'))
    assert ids is not None and len(ids) == expected['generated_tokens']
    if steps:
        assert len(steps) == len(ids), (len(steps), len(ids))
        assert [x['predicted_id'] for x in steps] == ids
    return dict(raw=raw, metrics=metrics, rounds=by_turn, loading=loading, steps=steps,
        native_steps=raw.get('steps'),
        predicted_ids=ids, capture_counts=[list(map(int, pair)) for pair in
        re.findall(r'capture_recorded=(\d+) capture_reused=(\d+)', stderr)])


def memory_summary(sampled, record):
    running = [x for x in sampled['samples'] if x.get('process_running')]
    boundaries = {x['name']: x['timestamp_ns'] for x in record['markers']}
    ready_ns = boundaries.get('ready_before_prefill')
    first_ns = boundaries.get('round1_prefill_begin')
    ready_rows = [x for x in running if ready_ns is not None and first_ns is not None and
                  ready_ns <= x['timestamp_ns'] <= first_ns]
    ready_sample = ready_rows[-1] if ready_rows else None
    windows = {}
    phase_names = sorted({re.sub(r'_(begin|end)$', '', k) for k in boundaries if k.startswith('round')})
    for name in phase_names:
        begin, end = boundaries.get(name + '_begin'), boundaries.get(name + '_end')
        rows = [x for x in running if begin <= x['timestamp_ns'] <= end] if begin is not None and end is not None else []
        before = max((x for x in running if begin is not None and x['timestamp_ns'] <= begin),
                     key=lambda x: x['timestamp_ns'], default=None)
        after = min((x for x in running if end is not None and x['timestamp_ns'] >= end),
                    key=lambda x: x['timestamp_ns'], default=None)
        windows[name] = dict(begin_ns=begin, end_ns=end, sample_count=len(rows),
            missing_boundary=begin is None or end is None,
            exact_phase_boundary_values=False, boundary_before=before, boundary_after=after,
            bracket_ages_ns=dict(before=begin - before['timestamp_ns'] if before is not None else None,
                                  after=after['timestamp_ns'] - end if after is not None else None),
            values={key: stats([x[key] for x in rows if x.get(key) is not None]) for key in KEYS},
            null_sample_counts={key: sum(x.get(key) is None for x in rows) for key in KEYS},
            bracket_delta_bytes={key: after[key] - before[key]
                if before is not None and after is not None and before.get(key) is not None and after.get(key) is not None else None
                for key in KEYS})
    gaps = [(b['timestamp_ns'] - a['timestamp_ns']) / 1e6 for a, b in zip(running, running[1:])]
    reasons = {}
    for row in sampled['samples']:
        for kind in ('dedicated', 'shared'):
            reason = row.get('gpu_' + kind + '_unavailable_reason')
            if reason:
                key = kind + ':' + reason
                reasons[key] = reasons.get(key, 0) + 1
    return dict(sample_count=len(sampled['samples']), running_sample_count=len(running),
        sampled_peaks=sampled['peaks'], phase_windows=windows, actual_sample_gaps_ms=stats(gaps),
        sample_cost_ms=stats([x['sample_duration_ns'] / 1e6 for x in running if 'sample_duration_ns' in x]),
        ready_baseline=dict(ready_marker_ns=ready_ns, first_prefill_marker_ns=first_ns,
            sample=ready_sample, unknown=ready_sample is None,
            definition='Last sample between received ready and first prefill-begin markers; unknown if no sample fits.'),
        unavailable_reasons=reasons,
        setup_error=sampled['gpu_setup_error'], thread_error=sampled['thread_error'],
        throughput_evidence=False, limits=[
            'PSAPI/PDH current and GPU peaks are sampled lower bounds; missing values stay null.',
            'Phase brackets are adjacent parent-time samples, not exact boundary reads or allocation attribution.',
            'Dedicated/shared are separate; total uses only simultaneous available values, never the sum of independent peaks.',
            'CPU private commit and WS/GPU shared overlap; never sum them as physical resident memory.',
            'stderr arrival times can lag consumer timestamps; short phases can have zero interior samples.'])


def load_probe():
    spec = importlib.util.spec_from_file_location('original_d4_memory_probe', SAMPLER)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod.MemoryProbe


def ready_image(path):
    ready = read(path)
    image = ready['image']
    assert identity(image['path']) == image, 'Ready image no longer matches exact receipt'
    return image


def gpu_snapshot(out, label):
    result = dict(label=label, outside_consumer_session=True, started_unix_ns=time.time_ns())
    queries = dict(gpu=['--query-gpu=name,driver_version,memory.total,memory.used,utilization.gpu,pstate,temperature.gpu,clocks.current.sm,clocks.current.memory,power.draw'],
                   compute_apps=['--query-compute-apps=pid,process_name,used_memory'])
    for name, args in queries.items():
        command = ['nvidia-smi', *args, '--format=csv,noheader,nounits']
        try:
            p = subprocess.run(command, capture_output=True, timeout=15, creationflags=subprocess.CREATE_NO_WINDOW)
            (out / f'{label}-{name}.stdout.log').write_bytes(p.stdout)
            (out / f'{label}-{name}.stderr.log').write_bytes(p.stderr)
            result[name] = dict(command=command, exit=p.returncode)
        except Exception as exc:
            result[name] = dict(command=command, unavailable=repr(exc))
    result['finished_unix_ns'] = time.time_ns()
    save(out / (label + '.json'), result)
    return result


def command_for(arm, image, plan, folder):
    hc, pc = original_commands()
    if arm == 'hyle':
        return [image['path'], '--inputs', hc[hc.index('--inputs') + 1],
            '--schedule', plan['manifest']['path'], '--capacity', str(plan['capacity']),
            '--progress', 'direct', '--replay', 'auto']
    return [image['path'], pc[1], '--schedule', plan['manifest']['path'],
            '--capacity', str(plan['capacity']), '--result', str(folder / 'peer-result.json')]


def execute(folder, arm, command, environment, memory):
    folder.mkdir(parents=True, exist_ok=False)
    record = dict(command=command, cwd=str(ROOT), image=identity(command[0]), arm=arm,
        memory_only=memory, throughput_evidence=not memory, profiler=False, markers=[],
        started_unix_ns=time.time_ns())
    save(folder / 'command.json', record)
    probe = load_probe()(interval_s=0.01) if memory else None
    errors = []
    with (folder / 'stdout.log').open('wb') as so, (folder / 'stderr.log').open('wb') as se:
        def reader(stream):
            try:
                for raw in iter(stream.readline, b''):
                    received = time.perf_counter_ns()
                    se.write(raw)
                    line = raw.decode('utf-8', errors='replace').rstrip()
                    name = marker(line)
                    if name:
                        record['markers'].append(dict(name=name, timestamp_ns=received, line=line))
            except Exception as exc:
                errors.append(repr(exc))
        record['popen_perf_ns'] = time.perf_counter_ns()
        process = subprocess.Popen(command, cwd=ROOT, env=environment, stdout=so,
            stderr=subprocess.PIPE if memory else se, creationflags=subprocess.CREATE_NO_WINDOW)
        record['pid'] = process.pid
        thread = threading.Thread(target=reader, args=(process.stderr,), daemon=True) if memory else None
        if thread:
            thread.start()
        try:
            if probe:
                probe.start(process.pid)
            try:
                record['exit'] = process.wait(timeout=900)
            except subprocess.TimeoutExpired:
                record['timeout'] = True
                process.kill()
                record['exit'] = process.wait()
        finally:
            if process.poll() is None:
                process.kill()
                process.wait()
            if thread:
                thread.join()
                process.stderr.close()
            if probe:
                probe.stop()
                sampled = probe.result()
                save(folder / 'memory.json', sampled)
                probe.close()
                save(folder / 'memory-summary.json', memory_summary(sampled, record))
            record.update(finished_perf_ns=time.perf_counter_ns(), reader_errors=errors,
                finished_unix_ns=time.time_ns())
            record['process_wall_seconds'] = (record['finished_perf_ns'] - record['popen_perf_ns']) / 1e9
            save(folder / 'result.json', record)
    if record['exit'] or record.get('timeout') or errors:
        raise RuntimeError('Consumer failed; raw logs retained: ' + str(folder))
    return record


def summarize(out, runs, mode):
    groups = {}
    rounds = {}
    loading = {}
    for arm in ('hyle', 'peer'):
        selected = [x for x in runs if x['arm'] == arm]
        if selected:
            keys = selected[0]['observation']['metrics']
            groups[arm] = {key: stats([x['observation']['metrics'][key] for x in selected]) for key in keys}
            loading_keys = sorted({key for x in selected for key in x['observation']['loading']})
            loading[arm] = {key: stats([x['observation']['loading'][key] for x in selected
                if isinstance(x['observation']['loading'].get(key), (int, float))]) for key in loading_keys}
            rounds[arm] = {}
            for turn, phases in selected[0]['observation']['rounds'].items():
                rounds[arm][turn] = {}
                for kind, phase in phases.items():
                    numeric_keys = [key for key, value in phase.items() if isinstance(value, (int, float))]
                    if phase.get('stable_decode_seconds') is None:
                        numeric_keys += ['stable_decode_seconds', 'stable_decode_tokens_per_second']
                    rounds[arm][turn][kind] = {key: stats([value for x in selected
                        if (value := x['observation']['rounds'][turn][kind].get(key)) is not None])
                        for key in numeric_keys}
    ids = {arm: [x['observation']['predicted_ids'] for x in runs if x['arm'] == arm] for arm in groups}
    within_arm = {arm: all(x == values[0] for x in values) for arm, values in ids.items()}
    result = dict(mode=mode, processes=len(runs), groups=groups, rounds=rounds, loading=loading,
        within_arm_predictions_equal=within_arm,
        between_arm_predictions_equal=ids['hyle'][0] == ids['peer'][0] if len(ids) == 2 else None,
        throughput_evidence=mode == 'timing', teacher_forced=True,
        independent_quality_acceptance=False, statistical_significance=False,
        limits=['Per-process token counts / actual source session seconds; phase TPS are never averaged.',
                'Each window is separate. Monitored memory process timings are not throughput evidence.',
                'Returned tokens are fixed-input sampled endpoints, not a natural multi-turn conversation.'])
    if mode == 'memory':
        result['groups'] = {}
        result['rounds'] = {}
        result['loading'] = {}
        result['arms'] = {x['arm']: read(Path(x['folder']) / 'memory-summary.json') for x in runs}
    save(out / 'summary.json', result)
    return result


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('action', choices=['prepare-inputs', 'plan', 'run', 'analyze'])
    ap.add_argument('--hyle-ready', type=Path)
    ap.add_argument('--peer-ready', type=Path)
    ap.add_argument('--environment', type=Path)
    ap.add_argument('--workload', choices=['short', 'long'], default='short')
    ap.add_argument('--mode', choices=['correctness', 'timing', 'memory'], default='correctness')
    ap.add_argument('--output', type=Path)
    args = ap.parse_args()
    if args.action == 'analyze':
        if args.output is None:
            ap.error('analyze needs --output of an existing window')
        config = read(args.output / 'inputs.json')
        runs = read(args.output / 'runs.json')
        for run in runs:
            run['observation'] = parse_observation(Path(run['folder']), run['arm'], config['plan'])
        save(args.output / 'runs.json', runs)
        summarize(args.output, runs, config['mode'])
        return
    inputs = prepare_inputs()
    if args.action == 'prepare-inputs':
        print(json.dumps({k: {x: v[x] for x in ('capacity', 'processed_tokens', 'generated_tokens', 'manifest')}
                          for k, v in inputs['plans'].items()}, indent=2))
        return
    if args.hyle_ready is None or args.peer_ready is None:
        ap.error('plan/run need --hyle-ready and --peer-ready exact image receipts')
    images = {arm: ready_image(path) for arm, path in [('hyle', args.hyle_ready), ('peer', args.peer_ready)]}
    environment_paths = {}
    for arm, path in [('hyle', args.hyle_ready), ('peer', args.peer_ready)]:
        runtime = read(path).get('runtime_environment', ENVIRONMENT)
        environment_paths[arm] = args.environment or Path(runtime['path'] if isinstance(runtime, dict) else runtime)
    plan = inputs['plans'][args.workload]
    out = (args.output or S / f'{args.workload}-{args.mode}' / 'attempt1').resolve()
    order = ['hyle', 'peer', 'peer', 'hyle', 'hyle', 'peer'] if args.mode == 'timing' else ['hyle', 'peer']
    config = dict(plan=plan, images=images, mode=args.mode, order=order,
        driver=identity(__file__), input_plan=identity(S / 'inputs/plan.json'),
        ready_receipts=[identity(x) for x in (args.hyle_ready, args.peer_ready)],
        environments={arm: identity(path) for arm, path in environment_paths.items()},
        requested_memory_interval_seconds=0.01 if args.mode == 'memory' else None,
        sampler=identity(SAMPLER) if args.mode == 'memory' else None,
        builds=0, profiler=False, memory_monitor=args.mode == 'memory',
        throughput_evidence=args.mode == 'timing', desktop_environment='Normal desktop, not exclusive GPU; no fixed clocks or application termination.',
        commands=[dict(arm=arm, command=command_for(arm, images[arm], plan, out / f'{i:02}-{arm}'))
                  for i, arm in enumerate(order, 1)])
    if args.action == 'plan':
        print(json.dumps(config, indent=2))
        return
    out.mkdir(parents=True, exist_ok=False)
    if os.environ.get('GGML_CUDA_DISABLE_GRAPHS'):
        raise RuntimeError('Ambient GGML_CUDA_DISABLE_GRAPHS changes comparison policy')
    save(out / 'inputs.json', config)
    runs = []
    if args.mode in ('timing', 'memory'):
        gpu_snapshot(out, 'window-before')
    try:
        for i, arm in enumerate(order, 1):
            folder = out / f'{i:02}-{arm}'
            print('MULTITURN_BEGIN', args.mode, args.workload, i, arm, flush=True)
            environment = os.environ.copy()
            environment['PATH'] = read(environment_paths[arm])['PATH']
            process = execute(folder, arm, config['commands'][i - 1]['command'], environment, args.mode == 'memory')
            observation = parse_observation(folder, arm, plan)
            runs.append(dict(arm=arm, folder=str(folder), process=process, observation=observation))
            save(out / 'runs.json', runs)
            summarize(out, runs, args.mode)
            print('MULTITURN_END', i, arm, process['exit'], flush=True)
    finally:
        if args.mode in ('timing', 'memory'):
            gpu_snapshot(out, 'window-after')


if __name__ == '__main__':
    main()
