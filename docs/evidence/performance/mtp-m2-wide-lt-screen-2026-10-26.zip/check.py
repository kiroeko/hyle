"""Execute the reviewed one-host-TU leaf recipe, with build/run separate."""
from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
import time

W = Path(__file__).resolve().parent
R = W.parents[1]
sys.path.insert(0, str(R / 'scripts'))
from hyle_environment import discover_environment

def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))

def save(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8')

def pin(path):
    value = path.read_bytes()
    return {'path': str(path), 'bytes': len(value), 'sha256': hashlib.sha256(value).hexdigest()}

def check(item):
    actual = pin(Path(item['path']))
    if any(actual[k] != item[k] for k in ('bytes', 'sha256')):
        raise RuntimeError('Reviewed input changed: ' + item['path'])
    return actual

def environment(plan):
    compiler = plan['commands_not_executed']['host'][0]
    return discover_environment(compiler='msvc', cache={
        'CMAKE_C_COMPILER': compiler, 'CMAKE_CXX_COMPILER': compiler,
        'CMAKE_GENERATOR': 'Ninja'}, backends=()).env

def execute(argv, env, directory, timeout):
    directory.mkdir(parents=True, exist_ok=False)
    save(directory / 'command.json', {'command': argv, 'cwd': str(R), 'timeout_seconds': timeout})
    start = time.perf_counter()
    with (directory / 'stdout.log').open('wb') as out, (directory / 'stderr.log').open('wb') as err:
        process = subprocess.Popen(argv, cwd=R, env=env, stdout=out, stderr=err,
                                   creationflags=subprocess.CREATE_NO_WINDOW)
        save(directory / 'running.json', {'pid': process.pid, 'state': 'LIVE'})
        print('START', directory.name, process.pid, flush=True)
        try:
            code = process.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            process.kill()
            process.wait()
            code = -999
    result = {'pid': process.pid, 'state': 'TERMINAL', 'exit': code,
              'seconds': time.perf_counter() - start}
    save(directory / 'process.json', result)
    print('TERMINAL', directory.name, json.dumps(result), flush=True)
    if code:
        print((directory / 'stdout.log').read_text(errors='replace')[-6000:], flush=True)
        print((directory / 'stderr.log').read_text(errors='replace')[-2000:], flush=True)
        raise RuntimeError('Actual stage failed; original raw preserved')
    return result

def reviewed():
    plan, pins = read(W / 'plan.json'), read(W / 'source-pins.json')
    for category in ('private_source', 'retained_harness', 'installed_import_libraries'):
        for item in pins[category]:
            check(item)
    check(plan['runtime_receipt'])
    return plan

def build():
    plan = reviewed()
    env = environment(plan)
    compiled = execute(plan['commands_not_executed']['host'], env, W / 'host', 120)
    data = read(W / 'host/dependencies.json')['Data']
    paths = [Path(p) for p in dict.fromkeys([data['Source'], *data['Includes']])]
    save(W / 'actual-dependencies.json', [pin(path) for path in paths])
    linked = execute(plan['commands_not_executed']['link'], env, W / 'link', 120)
    save(W / 'ready.json', {'status': 'BUILT_NOT_RUN', 'compile': compiled, 'link': linked,
         'source': pin(W / 'wide_leaf.cc'), 'object': pin(W / 'host/probe.obj'),
         'image': pin(W / 'link/wide-leaf.exe'), 'plan': pin(W / 'plan.json'),
         'source_pins': pin(W / 'source-pins.json'), 'actual_dependencies': pin(W / 'actual-dependencies.json'),
         'GPU_runs': 0, 'CUDA_TUs': 0, 'SDK_builds': 0})
    print('READY BUILT_NOT_RUN', json.dumps(pin(W / 'ready.json')), flush=True)

def run():
    plan = reviewed()
    ready = read(W / 'ready.json')
    for key in ('source', 'object', 'image', 'plan', 'source_pins'):
        check(ready[key])
    checks = []
    for role in plan['original_roles']:
        item = role['range']
        with Path(item['path']).open('rb') as source:
            source.seek(item['offset'])
            value = source.read(item['bytes'])
        if len(value) != item['bytes'] or hashlib.sha256(value).hexdigest() != item['sha256']:
            raise RuntimeError('Actual original weight range changed: ' + role['role'])
        checks.append({'role': role['role'], 'bytes': len(value), 'sha256': item['sha256']})
    check(plan['activation']['full_trace'])
    activation = Path(plan['activation']['full_trace']['path']).read_bytes()[:8192]
    if hashlib.sha256(activation).hexdigest() != plan['activation']['selected_sha256']:
        raise RuntimeError('Retained activation prefix changed')
    save(W / 'run-inputs.json', {'original_ranges': checks, 'activation_bytes': len(activation),
                               'selected_sha256': plan['activation']['selected_sha256']})
    env = environment(plan)
    env.update({k: v for k, v in read(Path(plan['runtime_receipt']['path'])).items() if isinstance(v, str)})
    env.update(HF_HUB_OFFLINE='1', TRANSFORMERS_OFFLINE='1')
    result = execute(plan['commands_not_executed']['run'], env, W / 'run', 120)
    actual = read(W / 'run/stdout.log')
    if not actual.get('passed'):
        raise RuntimeError('Leaf omitted successful numerical completion')
    save(W / 'summary.json', {'status': 'ACTUAL_FINITE_WIDE_LT_LEAF_PASS', 'process': result,
        'ready': ready, 'actual': actual, 'original_input_checks': pin(W / 'run-inputs.json'),
        'limits': plan['numerical_layout_boundaries'], 'Model_runs': 0, 'GPU_released': True,
        'additional_algorithm_searches': 0, 'additional_trials': 0, 'product_edits': 0})
    print('GPU RELEASED', json.dumps(pin(W / 'summary.json')), flush=True)

if __name__ == '__main__':
    {'build': build, 'run': run}[sys.argv[1]]()
