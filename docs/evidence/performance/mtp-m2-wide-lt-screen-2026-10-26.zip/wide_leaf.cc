// Private original-value two-Lt versus cold-wide-Lt leaf; no Model/provider integration.
#include <cuda.h>
#include <cublasLt.h>
#include <algorithm>
#include <array>
#include <bit>
#include <chrono>
#include <cmath>
#include <cstdint>
#include <cstring>
#include <filesystem>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <limits>
#include <memory>
#include <stdexcept>
#include <string>
#include <vector>

namespace {
constexpr std::size_t M=2,K=2048,N=6144,Workspace=32*1024*1024;
constexpr std::size_t Banks=4,WeightBytes=N*K*2;
constexpr int Trials=5,Replays=64;
void require(bool v,const char *s){if(!v)throw std::runtime_error(s);}
void cu(CUresult r,const char *s){if(r!=CUDA_SUCCESS)throw std::runtime_error(std::string(s)+": CUDA="+std::to_string(int(r)));}
void lt(cublasStatus_t r,const char *s){if(r!=CUBLAS_STATUS_SUCCESS)throw std::runtime_error(std::string(s)+": Lt="+std::to_string(int(r)));}
std::vector<std::uint16_t> read(const std::filesystem::path &p,std::uint64_t offset,std::size_t words){
  std::ifstream f(p,std::ios::binary);require(bool(f),"cannot open original source");
  f.seekg(static_cast<std::streamoff>(offset));std::vector<std::uint16_t> v(words);
  f.read(reinterpret_cast<char*>(v.data()),static_cast<std::streamsize>(words*2));
  require(f.gcount()==static_cast<std::streamsize>(words*2),"short original source range");return v;
}
float bf(std::uint16_t v){return std::bit_cast<float>(std::uint32_t(v)<<16);}
std::uint16_t rne(float v){auto u=std::bit_cast<std::uint32_t>(v);return std::uint16_t((u+0x7fffu+((u>>16)&1u))>>16);}
double gamma(std::size_t count,double u){return double(count)*u/(1-double(count)*u);}
struct Interval {float low=0,high=0;double center=0,bound=0;};
// Actual BF16 operands; independent F64 dot. Fixed gamma operation-count bound,
// not a baseline-output oracle or a tolerance fitted to observed differences.
std::vector<Interval> oracle(const std::vector<std::uint16_t>&a,const std::vector<std::uint16_t>&w){
  const auto normal=[](std::uint16_t u){const float f=bf(u);return std::isfinite(f)&&(f==0||std::abs(f)>=std::numeric_limits<float>::min());};
  require(std::all_of(a.begin(),a.end(),normal)&&std::all_of(w.begin(),w.end(),normal),"oracle domain: finite normal/zero BF16 inputs");
  std::vector<Interval> out(M*N);
  for(std::size_t m=0;m<M;++m)for(std::size_t n=0;n<N;++n){
    double sum=0,absolute=0;
    for(std::size_t k=0;k<K;++k){const double p=double(bf(a[m*K+k]))*double(bf(w[n*K+k]));sum+=p;absolute+=std::abs(p);}
    require(absolute<double(std::numeric_limits<float>::max())/16,"oracle sum overflow domain");
    const double sum_upper=std::nextafter(absolute/(1-gamma(K,std::ldexp(1.0,-53))),std::numeric_limits<double>::infinity());
    const double f64=gamma(K,std::ldexp(1.0,-53))*sum_upper;
    // <=K products + <=K additions across F32 dot/split-K; compute-type
    // reduction only. F32 FTZ loss is bounded absolutely, no scaled partials.
    const double native=gamma(2*K+4,std::ldexp(1.0,-24))*sum_upper+
      (2*double(K)*std::numeric_limits<float>::min())/(1-(2*double(K)+4)*std::ldexp(1.0,-24));
    const double bound=std::nextafter(native+f64,std::numeric_limits<double>::infinity());
    const float low=bf(rne(std::nextafter(float(sum-bound),-std::numeric_limits<float>::infinity())));
    const float high=bf(rne(std::nextafter(float(sum+bound),std::numeric_limits<float>::infinity())));
    require(std::isfinite(low)&&std::isfinite(high),"oracle BF16 store overflow");
    require((low==0||std::abs(low)>=std::numeric_limits<float>::min())&&
            (high==0||std::abs(high)>=std::numeric_limits<float>::min()),"oracle BF16 subnormal result domain");
    out[m*N+n]={low,high,sum,bound};
  }return out;
}
std::array<std::uint32_t,9> config(const cublasLtMatmulAlgo_t&a){
  std::array<std::uint32_t,9> result{};
  for(std::size_t i=0;i<result.size();++i){std::size_t written=0;
    if(i<7){lt(cublasLtMatmulAlgoConfigGetAttribute(&a,cublasLtMatmulAlgoConfigAttributes_t(i),&result[i],sizeof(result[i]),&written),"algorithm attribute");require(written==4,"unexpected algorithm attribute size");}
    else{std::uint16_t small=0;lt(cublasLtMatmulAlgoConfigGetAttribute(&a,cublasLtMatmulAlgoConfigAttributes_t(i),&small,sizeof(small),&written),"algorithm shape attribute");require(written==2,"unexpected shape attribute size");result[i]=small;}
  }return result;
}
// Fixed-shape leaf only: both arms read the same cold packed bank addresses.
struct Device {
  CUdevice device=0; CUcontext context=nullptr; CUstream stream=nullptr;
  CUdeviceptr a=0,workspace=0,wide_y=0;
  std::array<CUdeviceptr,2> y{};
  std::array<CUdeviceptr,Banks> banks{};
  ~Device(){
    if(stream)(void)cuStreamSynchronize(stream);
    for(auto p:banks)if(p)(void)cuMemFree(p);
    for(auto p:y)if(p)(void)cuMemFree(p);
    for(auto p:{wide_y,workspace,a})if(p)(void)cuMemFree(p);
    if(stream)(void)cuStreamDestroy(stream);
    if(context)(void)cuDevicePrimaryCtxRelease(device);
  }
};
struct Choice {
  bool wide=false;
  cublasLtHandle_t handle=nullptr; cublasLtMatmulDesc_t op=nullptr; cublasLtMatmulPreference_t pref=nullptr;
  std::array<cublasLtMatrixLayout_t,3> layouts{};
  cublasLtMatmulHeuristicResult_t selected{};
  std::array<std::uint32_t,9> algorithm_key{};
  CUgraph graph=nullptr; CUgraphExec executable=nullptr; CUevent begin=nullptr,end=nullptr;
  std::array<double,Trials> milliseconds{},host_milliseconds{};
  std::array<std::size_t,2> different{};
  std::size_t graph_nodes=0;
  const char *name()const{return wide?"single_wide_Lt_cold_concat_M2":"two_Lt_original_role_views_M2";}
  ~Choice(){
    if(begin)(void)cuEventDestroy(begin); if(end)(void)cuEventDestroy(end);
    if(executable)(void)cuGraphExecDestroy(executable); if(graph)(void)cuGraphDestroy(graph);
    for(auto p:layouts)if(p)(void)cublasLtMatrixLayoutDestroy(p);
    if(pref)(void)cublasLtMatmulPreferenceDestroy(pref); if(op)(void)cublasLtMatmulDescDestroy(op);
    if(handle)(void)cublasLtDestroy(handle);
  }
  void prepare(){
    const auto width=wide?2*N:N;
    lt(cublasLtCreate(&handle),"Lt handle");
    lt(cublasLtMatmulDescCreate(&op,CUBLAS_COMPUTE_32F,CUDA_R_32F),"original F32 accumulate");
    const std::array<std::uint64_t,3> rows{M,K,M},cols{K,width,width};
    const std::array<std::int64_t,3> ld{K,K,static_cast<std::int64_t>(width)};
    constexpr std::array<cublasLtOrder_t,3> order{CUBLASLT_ORDER_ROW,CUBLASLT_ORDER_COL,CUBLASLT_ORDER_ROW};
    for(std::size_t i=0;i<3;++i){
      lt(cublasLtMatrixLayoutCreate(&layouts[i],CUDA_R_16BF,rows[i],cols[i],ld[i]),"BF16 layout");
      lt(cublasLtMatrixLayoutSetAttribute(layouts[i],CUBLASLT_MATRIX_LAYOUT_ORDER,&order[i],sizeof(order[i])),"layout order");
    }
    lt(cublasLtMatmulPreferenceCreate(&pref),"preference");
    lt(cublasLtMatmulPreferenceSetAttribute(pref,CUBLASLT_MATMUL_PREF_MAX_WORKSPACE_BYTES,&Workspace,sizeof(Workspace)),"original workspace cap");
    const std::uint32_t reduction=CUBLASLT_REDUCTION_SCHEME_COMPUTE_TYPE,align=16;
    lt(cublasLtMatmulPreferenceSetAttribute(pref,CUBLASLT_MATMUL_PREF_REDUCTION_SCHEME_MASK,&reduction,sizeof(reduction)),"original reduction preference");
    for(auto attribute:{CUBLASLT_MATMUL_PREF_MIN_ALIGNMENT_A_BYTES,CUBLASLT_MATMUL_PREF_MIN_ALIGNMENT_B_BYTES,CUBLASLT_MATMUL_PREF_MIN_ALIGNMENT_C_BYTES,CUBLASLT_MATMUL_PREF_MIN_ALIGNMENT_D_BYTES})
      lt(cublasLtMatmulPreferenceSetAttribute(pref,attribute,&align,sizeof(align)),"original alignment preference");
    int count=0;
    lt(cublasLtMatmulAlgoGetHeuristic(handle,op,layouts[0],layouts[1],layouts[2],layouts[2],pref,1,&selected,&count),"one default heuristic per shape, no search");
    require(count==1&&selected.state==CUBLAS_STATUS_SUCCESS&&selected.workspaceSize<=Workspace,"default algorithm missing or workspace too large");
    algorithm_key=config(selected.algo);
    require(algorithm_key[2]<=1||algorithm_key[3]==std::uint32_t(CUBLASLT_REDUCTION_SCHEME_COMPUTE_TYPE),"default partial precision changed");
    cublasLtMatmulHeuristicResult_t checked{};
    lt(cublasLtMatmulAlgoCheck(handle,op,layouts[0],layouts[1],layouts[2],layouts[2],&selected.algo,&checked),"algorithm check");
    require(checked.state==CUBLAS_STATUS_SUCCESS&&checked.workspaceSize<=selected.workspaceSize,"algorithm workspace differs");
  }
};
std::string quote(const std::string&s){std::string o="\"";for(char c:s){if(c=='\\'||c=='\"')o+='\\';o+=c;}return o+'\"';}
std::uint64_t offset_arg(const char *text){std::size_t used=0;const auto value=std::stoull(text,&used);require(used==std::strlen(text),"invalid original-role offset");return value;}
} // namespace

int main(int argc,char**argv){try{
  require(argc==5,"usage: wide-leaf ORIGINAL_FILE GATE_OFFSET UP_OFFSET ACTUAL_BF16_ACTIVATION_TRACE");
  const std::array weights{read(argv[1],offset_arg(argv[2]),N*K),read(argv[1],offset_arg(argv[3]),N*K)};
  const auto activation=read(argv[4],0,M*K);
  const std::array expected{oracle(activation,weights[0]),oracle(activation,weights[1])};
  Device d;cu(cuInit(0),"init");cu(cuDeviceGet(&d.device,0),"device");
  cu(cuDevicePrimaryCtxRetain(&d.context,d.device),"primary");cu(cuCtxSetCurrent(d.context),"current");
  int l2_bytes=0,major=0,minor=0;
  cu(cuDeviceGetAttribute(&l2_bytes,CU_DEVICE_ATTRIBUTE_L2_CACHE_SIZE,d.device),"L2 size");
  cu(cuDeviceGetAttribute(&major,CU_DEVICE_ATTRIBUTE_COMPUTE_CAPABILITY_MAJOR,d.device),"major");
  cu(cuDeviceGetAttribute(&minor,CU_DEVICE_ATTRIBUTE_COMPUTE_CAPABILITY_MINOR,d.device),"minor");
  require(major==8&&minor==9,"this finite screen is for original Ada SM89");
  require(l2_bytes>0&&2*Banks*WeightBytes>2*std::size_t(l2_bytes),"four shared pairs must exceed twice actual L2");
  cu(cuStreamCreate(&d.stream,CU_STREAM_NON_BLOCKING),"stream");
  cu(cuMemAlloc(&d.a,M*K*2),"actual A");cu(cuMemAlloc(&d.workspace,Workspace),"shared workspace cap");
  for(auto &p:d.y)cu(cuMemAlloc(&p,M*N*2),"original independent BF16 output");
  cu(cuMemAlloc(&d.wide_y,2*M*N*2),"extra wide BF16 output, no timed unpack");
  cu(cuMemcpyHtoD(d.a,activation.data(),M*K*2),"upload actual A");
  for(auto &bank:d.banks){
    cu(cuMemAlloc(&bank,2*WeightBytes),"single cold packed pair bank");
    for(std::size_t role=0;role<2;++role){
      require((bank+role*WeightBytes)%16==0,"actual original-role alignment");
      cu(cuMemcpyHtoD(bank+role*WeightBytes,weights[role].data(),WeightBytes),"original role bits into shared parent");
    }
  }
  std::array<Choice,2> choices;choices[1].wide=true;
  for(auto &choice:choices)choice.prepare();
  const float alpha=1,beta=0;
  const auto launch=[&](Choice &choice,std::size_t bank){
    const auto width=choice.wide?1u:2u;
    for(std::size_t role=0;role<width;++role){
      const auto w=d.banks[bank]+(choice.wide?0:role*WeightBytes);
      const auto y=choice.wide?d.wide_y:d.y[role];
      lt(cublasLtMatmul(choice.handle,choice.op,&alpha,reinterpret_cast<void*>(d.a),choice.layouts[0],
        reinterpret_cast<void*>(w),choice.layouts[1],&beta,reinterpret_cast<void*>(y),choice.layouts[2],
        reinterpret_cast<void*>(y),choice.layouts[2],&choice.selected.algo,reinterpret_cast<void*>(d.workspace),
        choice.selected.workspaceSize,d.stream),"fixed original-value BF16 projection");
    }
  };
  const auto poison=[&](const Choice&choice){
    if(choice.wide)cu(cuMemsetD16(d.wide_y,0x7fc1u,2*M*N),"wide output poison");
    else for(auto y:d.y)cu(cuMemsetD16(y,0x7fc1u,M*N),"independent output poison");
  };
  std::array<std::vector<std::uint16_t>,2> baseline;
  const auto verify=[&](Choice &choice,bool compare_bits){
    std::vector<std::uint16_t> wide;
    if(choice.wide){wide.resize(2*M*N);cu(cuMemcpyDtoH(wide.data(),d.wide_y,wide.size()*2),"complete wide Y");}
    for(std::size_t role=0;role<2;++role){
      std::vector<std::uint16_t> y(M*N);
      if(choice.wide)for(std::size_t m=0;m<M;++m)for(std::size_t n=0;n<N;++n)y[m*N+n]=wide[m*(2*N)+role*N+n];
      else cu(cuMemcpyDtoH(y.data(),d.y[role],y.size()*2),"complete original Y");
      for(std::size_t i=0;i<y.size();++i){const float value=bf(y[i]);
        if(!std::isfinite(value)||value<expected[role][i].low||value>expected[role][i].high)
          throw std::runtime_error("independent F64/fixed-gamma gate failed role="+std::to_string(role)+" index="+std::to_string(i)+" choice="+choice.name());
      }
      if(!compare_bits)continue;
      if(!choice.wide)baseline[role]=y;
      else for(std::size_t i=0;i<y.size();++i)choice.different[role]+=y[i]!=baseline[role][i];
    }
  };
  for(auto &choice:choices){
    poison(choice);launch(choice,0);cu(cuStreamSynchronize(d.stream),"direct numeric retirement");verify(choice,true);
    launch(choice,0);cu(cuStreamSynchronize(d.stream),"same-shape cold warmup retirement");
    cu(cuStreamBeginCapture(d.stream,CU_STREAM_CAPTURE_MODE_GLOBAL),"capture fixed rotation");
    for(int leaf=0;leaf<Replays;++leaf)launch(choice,std::size_t(leaf)%Banks);
    cu(cuStreamEndCapture(d.stream,&choice.graph),"end capture");
    cu(cuGraphInstantiate(&choice.executable,choice.graph,0),"instantiate");
    cu(cuGraphGetNodes(choice.graph,nullptr,&choice.graph_nodes),"actual graph nodes");
    require(choice.graph_nodes>=std::size_t(Replays)*(choice.wide?1u:2u),"captured projection work omitted");
    cu(cuEventCreate(&choice.begin,CU_EVENT_DEFAULT),"begin event");cu(cuEventCreate(&choice.end,CU_EVENT_DEFAULT),"end event");
    poison(choice);cu(cuGraphLaunch(choice.executable,d.stream),"pre-timing captured numeric replay");
    cu(cuStreamSynchronize(d.stream),"captured numeric retirement");verify(choice,false);
  }
  for(int trial=0;trial<Trials;++trial)for(std::size_t step=0;step<choices.size();++step){
    auto &choice=choices[(step+std::size_t(trial))%choices.size()];
    const auto begin=std::chrono::steady_clock::now();cu(cuEventRecord(choice.begin,d.stream),"time begin");
    cu(cuGraphLaunch(choice.executable,d.stream),"one64-pair graph");cu(cuEventRecord(choice.end,d.stream),"time end");
    cu(cuEventSynchronize(choice.end),"actual event retirement");const auto end=std::chrono::steady_clock::now();
    float milliseconds=0;cu(cuEventElapsedTime(&milliseconds,choice.begin,choice.end),"event duration");
    choice.milliseconds[std::size_t(trial)]=double(milliseconds)/Replays;
    choice.host_milliseconds[std::size_t(trial)]=std::chrono::duration<double,std::milli>(end-begin).count()/Replays;
  }
  std::cout<<std::setprecision(17)<<"{\"passed\":true,\"scope\":\"fixed projection leaf only; no Silu, output unpack, Model, PMU or TPS claim\",\"m\":2,\"k\":2048,\"role_n\":6144,\"wide_n\":12288"
    <<",\"workspace_cap\":"<<Workspace<<",\"cublasLt_version\":"<<cublasLtGetVersion()
    <<",\"shared_pair_bank_count\":"<<Banks<<",\"shared_weight_working_set_bytes\":"<<2*Banks*WeightBytes
    <<",\"candidate_extra_weight_bytes\":0,\"candidate_extra_output_bytes\":"<<2*M*N*2
    <<",\"actual_L2_bytes\":"<<l2_bytes<<",\"pair_jobs_per_graph\":"<<Replays<<",\"trials\":"<<Trials<<",\"choices\":[";
  for(std::size_t i=0;i<choices.size();++i){const auto &choice=choices[i];auto times=choice.milliseconds;std::sort(times.begin(),times.end());
    std::cout<<(i?",":"")<<"{\"kind\":"<<quote(choice.name())<<",\"workspace_bytes\":"<<choice.selected.workspaceSize
      <<",\"captured_graph_nodes\":"<<choice.graph_nodes<<",\"BF16_outputs_checked_per_role_each_numeric_phase\":"<<M*N
      <<",\"BF16_direct_differences_from_control\":["<<choice.different[0]<<','<<choice.different[1]<<"],\"request1_algorithm_key\":[";
    for(std::size_t j=0;j<choice.algorithm_key.size();++j)std::cout<<(j?",":"")<<choice.algorithm_key[j];
    std::cout<<"],\"device_ms_per_pair\":[";for(int trial=0;trial<Trials;++trial)std::cout<<(trial?",":"")<<choice.milliseconds[std::size_t(trial)];
    std::cout<<"],\"host_ms_per_pair\":[";for(int trial=0;trial<Trials;++trial)std::cout<<(trial?",":"")<<choice.host_milliseconds[std::size_t(trial)];
    std::cout<<"],\"device_ms_median_per_pair\":"<<times[Trials/2]<<'}';
  }
  std::cout<<"]}\n";return 0;
}catch(const std::exception&e){std::cerr<<"M2 cold-wide Lt leaf failed: "<<e.what()<<'\n';return 1;}}
