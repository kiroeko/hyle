"""Explicit-run-only, serial eight-process adapter around the retained B2 harness."""
from pathlib import Path
import ast
import hashlib
import importlib.util
import json
import math
import os
import re
import sys
import textwrap
import traceback

sys.dont_write_bytecode = True
D = Path(__file__).resolve().parent


def read(path):
    return json.loads(Path(path).read_text(encoding="utf-8-sig"))


def identity(path):
    path = Path(path)
    with path.open("rb") as f:
        digest = hashlib.file_digest(f, "sha256").hexdigest()
    return dict(path=str(path), bytes=path.stat().st_size, sha256=digest)


def verify(pin):
    assert identity(pin["path"]) == pin, "Frozen file changed: " + pin["path"]


def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


def differences(before, after, path="$"):
    if type(before) is not type(after):
        return [dict(path=path, before=before, after=after)]
    if isinstance(before, dict):
        out = []
        for key in sorted(set(before) | set(after)):
            if key not in before or key not in after:
                out.append(dict(path=path + "." + key, before_present=key in before,
                                after_present=key in after, before=before.get(key), after=after.get(key)))
            else:
                out.extend(differences(before[key], after[key], path + "." + key))
        return out
    if isinstance(before, list):
        out = []
        if len(before) != len(after):
            out.append(dict(path=path, before_length=len(before), after_length=len(after)))
        for i in range(min(len(before), len(after))):
            out.extend(differences(before[i], after[i], f"{path}[{i}]"))
        return out
    return [] if before == after else [dict(path=path, before=before, after=after)]


def normalize(value, audit, path="$"):
    if isinstance(value, list):
        return [normalize(v, audit, f"{path}[{i}]") for i, v in enumerate(value)]
    if not isinstance(value, dict):
        return value
    out = {}
    for key, item in value.items():
        reason = None
        if key == "seconds" or key.endswith("_seconds") or "tokens_per_second" in key:
            reason = "original producer clock or derived rate"
        elif any(x in key for x in ("clock_unix", "unix_ns", "unix_ms")):
            reason = "original wall-clock timestamp"
        elif key == "device_global_free_bytes" and re.fullmatch(r"\$\.memory\[\d+\]", path):
            reason = "explicit non-work global device-free-memory telemetry; raw value retained"
        if reason:
            audit.append(dict(path=path + "." + key, reason=reason, value=item))
        else:
            out[key] = normalize(item, audit, path + "." + key)
    return out


def ids_for(raw, arm):
    key = "id" if arm == "peer" else "session_id"
    assert [s[key] for s in raw["sessions"]] == ["alice", "bob"]
    ids = {s[key]: s["generated_ids"] for s in raw["sessions"]}
    assert all(len(v) == 99 and all(type(x) is int and 0 <= x < 248320 for x in v) for v in ids.values())
    return ids


def check_work(raw, arm, expected, historical):
    for key in ("processed_tokens", "generated_tokens", "actual_graph_tokens", "actual_graph_calls",
                "prefix_hits", "prefix_full_hits", "reused_tokens"):
        assert raw[key] == expected[key], (arm, key, raw.get(key), expected[key])
    assert raw["prefix_cache"] == "off" and raw["active_sequences"] == 2
    audit = []
    assert normalize(raw["waves"], audit) == expected["waves"], "Wave work changed"
    assert len(raw["sessions"]) == 2
    ids = ids_for(raw, arm)
    if arm == "hyle":
        assert raw["session_count"] == 2 and raw["max_batch_requests"] == 2
        assert raw["source_id"] == "4a76decdfa58a5fd6e15acea7ff410e84fd3e81cb6c39db8a658eeb23d869fbe"
        assert raw["text_tensors"] == 320 and raw["mtp_tensors"] == 0 and raw["diagnostic"] is False
        assert raw["score_dtype"] == "F32" and raw["score_policy"] == "bf16_inputs_f32_output"
        assert raw["evicted_session_ids"] == []
        assert raw["max_cached_sessions"] == raw["effective_cache_sessions"] == 2
        physical = [[x["kind"], x["query_rows"], x["session_ids"]] for x in raw["batches"]]
        assert all(x["requests"] == 2 and x["restore"] is False for x in raw["batches"])
        consumed = [x for tape in expected["tapes"] if tape["kind"] == "decode" for x in tape["ids"]]
        for session in raw["sessions"]:
            assert session["decode_input_ids"] == consumed
            assert session["fixed_decode"] is True and session["diagnostic"] is False
            assert session["phase_count"] == 6 and session["turn_count"] == 3
            assert session["processed_tokens"] == 864 and session["generated_tokens"] == 99
            assert session["restored_calls"] == session["restored_tokens"] == 0
            assert session["recomputed_decision_changes"] == []
    else:
        assert raw["llama_commit"] == "d9e03f1074dbd2979126d91dce1b5d304ec8394e"
        assert raw["logical_capacity"] == 1024 and raw["committed_versions_limit"] == 2
        assert raw["native_n_ctx"] == 2048 and raw["directory_evictions"] == 0
        assert len(raw["steps"]) == 198 and sum(s["input_tokens"] for s in raw["steps"]) == 1728
        physical = [[x["kind"], x["T"], [m["session"] for m in x["members"]]] for x in raw["episodes"]]
        assert all(x["requests"] == 2 for x in raw["episodes"])
        for actual, old in zip(raw["episodes"], historical["episodes"]):
            for member, old_member in zip(actual["members"], old["members"]):
                for key in ("session", "name", "position_first", "position_end", "output_input_index"):
                    assert member[key] == old_member[key], (key, member, old_member)
    assert physical == expected["physical_episodes"], "Physical kind/T/member order changed"
    old_sessions = expected["historical_peer_session_work" if arm == "peer" else "historical_hyle_session_work"]
    for session, old in zip(raw["sessions"], old_sessions):
        assert session["visible_tokens"] == 864
        assert len(session["phases"]) == len(old["phases"]) == 6
        for phase, old_phase in zip(session["phases"], old["phases"]):
            for key in ("name", "turn", "kind", "input_tokens", "context_before", "context_after"):
                assert phase[key] == old_phase[key], (key, phase, old_phase)
    return ids


def legacy_phase_parser(path):
    # The original B2 script has executable top-level code. Importing it would
    # start the old window. Reuse only its exact, pinned phase/metric parse block.
    source = Path(path).read_text(encoding="utf-8")
    start = source.index("        phase_seconds={kind:")
    end = source.index("        m.save(folder/'observation.json'", start)
    block = textwrap.dedent(source[start:end])
    tree = ast.parse(block)
    assert not any(isinstance(n, (ast.Import, ast.ImportFrom, ast.FunctionDef, ast.ClassDef)) for n in ast.walk(tree))
    return compile(tree, str(path) + ":retained_phase_metrics_only", "exec"), dict(
        source=identity(path), extracted_code_sha256=hashlib.sha256(block.encode()).hexdigest(),
        exact_original_code=block, producer_endpoints_changed=False)


def main():
    if sys.argv[1:] != ["run"]:
        raise SystemExit("Usage: python -B .scratch/inference-b2-current-window-20261026/run.py run")
    ready = read(D / "runner-ready.json")
    for row in ready["files"]:
        verify(row)
    plan, pins, expected = (read(D / name) for name in ("plan.json", "pins.json", "expected-work.json"))
    assert plan["status"] == "FROZEN_METADATA_ONLY_NOT_RUN" and len(plan["commands"]) == 8
    assert [x["arm"] for x in plan["commands"]] == ["hyle", "peer", "peer", "hyle", "hyle", "peer", "hyle", "peer"]
    assert [x["mode"] for x in plan["commands"]] == ["timing"] * 6 + ["memory"] * 2
    assert not (D / "runs").exists() and not (D / "run-state.json").exists(), "No in-place retry or output overwrite"
    for row in pins["images"].values():
        verify(row)
    for row in pins["peer_shared_absolute_libraries"]:
        verify(row)
    for key in ("hyle_ready", "hyle_actual_dependencies", "hyle_link_inputs", "hyle_runtime", "old_peer_ready",
                "peer_link_plan_632", "peer_source_identity_632", "v2_manifest", "canonical_model_now", "canonical_sampling_now"):
        verify(pins[key])
    for row in pins["hyle_source_pins"]["files"]:
        verify(row["frozen"])
    for row in pins["harness"].values():
        verify(row)
    for row in (expected["manifest"], expected["schedule"], *[x["file"] for x in expected["tapes"]]):
        verify(row)
    for entry in plan["commands"]:
        verify(entry["runtime_environment"])
        assert entry["command"][0] == pins["images"][entry["arm"]]["path"]
        assert not Path(entry["folder"]).exists()
    for row in pins["historical_reports"].values():
        verify(row)
    historical = dict(hyle=read(pins["historical_reports"]["hyle"]["path"])["raw"],
                      peer=read(pins["historical_reports"]["peer"]["path"]))
    helper = module("b2_retained_runner", pins["harness"]["runner"]["path"])
    module("b2_retained_observer", pins["harness"]["observer"]["path"]).install(helper)
    parse_code, parse_binding = legacy_phase_parser(pins["harness"]["old_performance_parser"]["path"])
    assert parse_binding["extracted_code_sha256"] == ready["legacy_phase_code_sha256"]
    helper.save(D / "phase-parser-binding.json", parse_binding)
    helper.save(D / "execution-binding.json", dict(plan=identity(D / "plan.json"), runner=identity(__file__),
                pins=identity(D / "pins.json"), expected=identity(D / "expected-work.json"),
                process_count=8, extra_behavior_or_warmup_processes=0, existing_harness= pins["harness"]))
    (D / "runs").mkdir()
    runs, baselines, baseline_ids, memory = [], {}, {}, {}
    entry = None
    helper.save(D / "run-state.json", dict(status="RUNNING", completed=0, planned=8))
    helper.gpu_snapshot(D, "window-before")
    try:
        for entry in plan["commands"]:
            arm, folder = entry["arm"], Path(entry["folder"])
            print("B2_BEGIN", entry["mode"], entry["index"], arm, flush=True)
            env = os.environ.copy()
            env["PATH"] = read(entry["runtime_environment"]["path"])["PATH"]
            env.update(HF_HUB_OFFLINE="1", TRANSFORMERS_OFFLINE="1")
            process = helper.execute(folder, arm, entry["command"], env, entry["memory_only"])
            raw = (read(folder / "peer-result.json") if arm == "peer" else
                   json.loads((folder / "stdout.log").read_text(encoding="utf-8")))
            audit = []
            normalized = normalize(raw, audit)
            helper.save(folder / "normalization-audit.json", audit)
            helper.save(folder / "complete-nontime-report.json", normalized)
            old_audit = []
            old_normalized = normalize(historical[arm], old_audit)
            helper.save(folder / "historical-nontime-differences.json", differences(old_normalized, normalized))
            old_ids = ids_for(historical[arm], arm)
            actual_ids = ids_for(raw, arm)
            old_id_diff = differences(old_ids, actual_ids)
            helper.save(folder / "historical-output-differences.json", old_id_diff)
            current_diff = differences(baselines[arm], normalized) if arm in baselines else []
            helper.save(folder / "within-arm-nontime-differences.json", current_diff)
            assert not current_diff, "Complete within-arm non-time report changed; stop without replacement samples"
            ids = check_work(raw, arm, expected, historical[arm])
            if arm not in baselines:
                baselines[arm], baseline_ids[arm] = normalized, ids
                helper.save(D / f"{arm}-nontime-baseline.json", normalized)
            namespace = dict(folder=folder, raw=raw, waves=raw["waves"], variant=arm, ids=ids, re=re)
            exec(parse_code, namespace)
            observation = namespace["observation"]
            assert all(math.isfinite(v) and v > 0 for v in observation["metrics"].values())
            helper.save(folder / "observation.json", observation)
            if entry["memory_only"]:
                mem = read(folder / "memory-summary.json")
                assert mem["setup_error"] is None and mem["thread_error"] is None
                memory[arm] = mem
            runs.append(dict(arm=arm, mode=entry["mode"], index=entry["index"], folder=str(folder),
                             process=process, metrics=observation["metrics"], historical_output_differences=len(old_id_diff),
                             within_arm_complete_nontime_differences=0))
            helper.save(D / "runs.json", runs)
            if len(baseline_ids) == 2:
                helper.save(D / "cross-engine-output-differences.json", differences(baseline_ids["hyle"], baseline_ids["peer"]))
            helper.save(D / "run-state.json", dict(status="RUNNING", completed=len(runs), planned=8))
            print("B2_END", entry["mode"], entry["index"], arm, observation["metrics"],
                  "historical_ID_differences", len(old_id_diff), flush=True)
        assert len(runs) == 8 and set(memory) == {"hyle", "peer"}
        metrics = {arm: {key: helper.stats([r["metrics"][key] for r in runs
                   if r["arm"] == arm and r["mode"] == "timing"])
                   for key in runs[0]["metrics"]} for arm in ("hyle", "peer")}
        comparisons = {key: dict(hyle_relative_to_peer_percent=(metrics["hyle"][key]["median"] /
                       metrics["peer"][key]["median"] - 1) * 100,
                       ranges_overlap=not(metrics["hyle"][key]["min"] > metrics["peer"][key]["max"] or
                                          metrics["peer"][key]["min"] > metrics["hyle"][key]["max"]))
                       for key in metrics["hyle"]}
        summary = dict(status="COMPLETE_8_WITH_FULL_WITHIN_ARM_WORK_STABLE", runs=runs,
                       process_count=8, unmonitored_timing_processes=6, independent_memory_processes=2,
                       metrics=metrics, comparisons=comparisons, memory=memory,
                       within_arm_complete_nontime_differences=0, physical_episode_order_equal=True,
                       cross_engine_output_differences=read(D / "cross-engine-output-differences.json"),
                       historical_outputs_required_equal=False, quality_acceptance=False,
                       old_samples_pooled=False, extra_behavior_or_warmup_processes=0,
                       normalization="All original seconds/rates/clocks and only memory[].device_global_free_bytes telemetry excluded explicitly; every excluded path/value is audited, original reports retained; every remaining field compared within each arm.",
                       limits=plan["fairness_limits"])
        helper.save(D / "summary.json", summary)
        helper.save(D / "run-state.json", dict(status=summary["status"], completed=8, planned=8))
    except BaseException as error:
        helper.save(D / "run-state.json", dict(status="STOPPED_FAILED_NO_REFILL", completed=len(runs), planned=8,
                    failed_entry=entry, error=repr(error), traceback=traceback.format_exc(),
                    remaining_not_run=plan["commands"][len(runs) + 1:] if entry else plan["commands"]))
        raise
    finally:
        helper.gpu_snapshot(D, "window-after")
    print("B2_TERMINAL COMPLETE_8 GPU_RELEASED", flush=True)


if __name__ == "__main__":
    main()
