"""Freeze read-only B2 run metadata; never imports a runner or starts a consumer."""
from pathlib import Path
import hashlib
import json
import shlex

R = Path(__file__).resolve().parents[2]
D = Path(__file__).resolve().parent

def read(p):
    return json.loads(Path(p).read_text(encoding="utf-8-sig"))

def pin(p):
    p = Path(p)
    return dict(path=str(p), bytes=p.stat().st_size,
                sha256=hashlib.file_digest(p.open("rb"), "sha256").hexdigest())

def verify(p):
    actual = pin(p["path"])
    assert actual == p, (actual, p)
    return actual

def save(name, obj):
    with (D / name).open("x", encoding="utf-8", newline="\n") as f:
        json.dump(obj, f, ensure_ascii=False, indent=2)
        f.write("\n")

def slim(x):
    if isinstance(x, list):
        return [slim(v) for v in x]
    if isinstance(x, dict):
        return {k: slim(v) for k, v in x.items()
                if not any(t in k for t in
                           ("seconds", "tokens_per_second", "clock_unix", "unix_ns", "unix_ms"))}
    return x

batch_dir = R / ".scratch/inference-sampling-three-arm-20261026/batch"
batch_ready_path = batch_dir / "ready.json"
h = read(batch_ready_path)
peer_ready_path = R / ".scratch/qwen-cli-batch-20261022/peer-ready.json"
p = read(peer_ready_path)
current_peer_ready_path = R / ".scratch/qwen-mtp-final-window-20261024/peer-link1/ready.json"
p433 = read(current_peer_ready_path)
assert h["image"]["sha256"].startswith("41ce916d")
assert p["image"]["sha256"].startswith("632cc09c")
assert p433["image"]["sha256"].startswith("433e7051")
images = {"hyle": verify(h["image"]), "peer": verify(p["image"]),
          "peer_433_reference_only": verify(p433["image"])}

# Compare the actual fixed library closure, not the names of the consumers.
pl = read(p["link_plan"]["path"])
pl433 = read(p433["link_plan"]["path"])
assert len(pl["inputs"]) == len(pl433["inputs"]) == 9
libraries = [v for v in pl["inputs"] if Path(v["path"]).suffix.lower() == ".lib"]
libraries433 = [v for v in pl433["inputs"] if Path(v["path"]).suffix.lower() == ".lib"]
assert len(libraries) == len(libraries433) == 8
assert libraries == libraries433
actual_libraries = [verify(v) for v in libraries]
assert read(p["runtime_environment"]["path"]) == read(p433["runtime_environment"]["path"])
dep632 = read(p["compile_identity"]["path"])["dependencies"]
dep433 = read(p433["compiled_identity"]["path"])["dependencies"]
map632 = {v["path"].casefold(): v for v in dep632}
map433 = {v["path"].casefold(): v for v in dep433}
shared = sorted(set(map632) & set(map433))
shared_changed = [dict(old=map632[k], current_reference=map433[k])
                  for k in shared if map632[k] != map433[k]]
native_summary_path = R / ".scratch/architecture-refactor-2026-10-18/llama-matched-consumer/summary.json"
native = read(native_summary_path)
versions = read(R / "docs/evidence/research/inference-performance-review-2026-10-25.json")["reference_versions"]

# Old V1 files are not accepted by the formal image. Compare small manifests,
# and reuse the already validated V2 manifest without reading payload weights.
old_inputs = R / ".scratch/architecture-refactor-2026-10-18/qwen-gpu-comparison/128-prefill/inputs"
new_inputs = R / ".scratch/qwen35-unsloth-mtp-20261024/geometry-v2-check/original"
old_lines = (old_inputs / "weights.tsv").read_text(encoding="utf-8-sig").splitlines()
new_lines = (new_inputs / "weights.tsv").read_text(encoding="utf-8-sig").splitlines()
assert old_lines[0] == "HYLE_QWEN35_TEXT_V1"
assert new_lines[0] == "HYLE_QWEN_ROLE_FILES_V2"
def role(line, source=None):
    f = shlex.split(line)
    rank = int(f[2])
    shape = [int(x) for x in f[3:3 + rank]]
    at = 3 + rank
    src = source if source is not None else f[at]
    if source is None:
        at += 1
    return dict(name=f[0], dtype=f[1], shape=shape,
                source=src.replace("\\", "/").casefold(),
                offset=int(f[at]), bytes=int(f[at + 1]))
old_roles = {x["name"]: x for line in old_lines[3:] if line.strip()
             for x in [role(line, old_lines[1])]}
new_roles = {x["name"]: x for line in new_lines[3:] if line.startswith("model.") or line.startswith("mtp.")
             for x in [role(line)]}
assert len(old_roles) == 320 and len(new_roles) == 335
assert all(new_roles.get(k) == v for k, v in old_roles.items())
assert sum(v["bytes"] for v in old_roles.values()) == 3763655360
source_sizes = {}
for v in old_roles.values():
    src = Path(v["source"])
    assert src.exists()
    size = source_sizes.setdefault(str(src), src.stat().st_size)
    assert 0 <= v["offset"] <= size and v["offset"] + v["bytes"] <= size

manifest = R / ".scratch/qwen-cli-batch-20261022/performance-sessions.txt"
entries = [line.split() for line in manifest.read_text().splitlines() if line.strip()]
assert [x[0] for x in entries] == ["alice", "bob"] and entries[0][1] == entries[1][1]
schedule = Path(entries[0][1])
tapes = []
for line in schedule.read_text().splitlines():
    kind, filename = line.split()
    tape = schedule.parent / filename
    ids = [int(x) for x in tape.read_text().split()]
    assert all(0 <= x < 248320 for x in ids)
    tapes.append(dict(kind=kind, file=pin(tape), rows=len(ids), ids=ids))
assert [x["kind"] for x in tapes] == ["prompt", "decode"] * 3
assert sum(x["rows"] for x in tapes if x["kind"] == "prompt") == 768
assert sum(x["rows"] for x in tapes if x["kind"] == "decode") == 96

old_hpath = R / ".scratch/qwen-cli-batch-20261022/performance/timing/02-batch/observation.json"
old_ppath = R / ".scratch/qwen-cli-batch-20261022/performance/timing/03-peer/peer-result.json"
oldh = read(old_hpath)["raw"]
oldp = read(old_ppath)
expected_physical_h = [(x["kind"], x["query_rows"], x["session_ids"]) for x in oldh["batches"]]
expected_physical_p = [(x["kind"], x["T"], [m["session"] for m in x["members"]]) for x in oldp["episodes"]]
assert expected_physical_h == expected_physical_p and len(expected_physical_h) == 99
expected_work = dict(
    manifest=pin(manifest), schedule=pin(schedule), tapes=tapes,
    processed_tokens=1728, generated_tokens=198, actual_graph_tokens=1728,
    actual_graph_calls=99, prefill_rows=1536, decode_rows=192,
    prefix_hits=0, prefix_full_hits=0, reused_tokens=0,
    sessions=2, active_requests=2, logical_capacity=1024,
    waves=slim(oldh["waves"]), physical_episodes=expected_physical_h,
    historical_hyle_session_work=slim(oldh["sessions"]),
    historical_peer_session_work=slim(oldp["sessions"]),
    historical_outputs_are_reference_only=True,
    limits="Use old structural inputs/wave geometry as a gate. Historical full report identity, cache allocation fields and generated IDs are not required to equal current Hyle: source/schema have evolved. Within each new arm compare the entire new non-time report exactly; cross-engine output differences are reported, not filtered or promoted to quality acceptance.")

# Pin existing harness components; do not import their top-level runner code.
runner = R / ".scratch/architecture-refactor-2026-10-18/d4-windows-preparation-2026-10-21/first-decode-startup-2026-10-21/multiturn/multiturn_run.py"
observer = R / ".scratch/shared-execution-20261021/observer.py"
old_performance = R / ".scratch/qwen-cli-batch-20261022/performance.py"
source_pins = read(h["source_pins"]["path"])
for row in source_pins["files"]:
    verify(row["frozen"])
    assert pin(R / row["path"])["sha256"] == row["frozen"]["sha256"]
project_deps = [v for v in read(h["actual_dependencies"]["path"])
                if str(R).casefold() in v["path"].casefold()]
dependency_drift = []
for v in project_deps:
    actual = pin(v["path"]) if Path(v["path"]).exists() else None
    if actual != v:
        dependency_drift.append(dict(compiled=v, live=actual))

timing_order = ["hyle", "peer", "peer", "hyle", "hyle", "peer"]
memory_order = ["hyle", "peer"]
commands = []
for mode, order in (("timing", timing_order), ("memory", memory_order)):
    for i, arm in enumerate(order, 1):
        folder = D / "runs" / f"{mode}-{i:02}-{arm}"
        assert not folder.exists(), "Never overwrite historical or partially run output"
        if arm == "hyle":
            command = [images[arm]["path"], "--inputs", str(new_inputs),
                       "--session-schedules", str(manifest), "--capacity", "1024",
                       "--max-sessions", "2", "--active-sequences", "2",
                       "--prefix-cache", "off", "--progress", "direct", "--replay", "auto",
                       "--backend", "cuda", "--sampling", "greedy", "--mtp", "off"]
            runtime = h["runtime"]
        else:
            command = [images[arm]["path"], oldp["model"], "--session-schedules", str(manifest),
                       "--capacity", "1024", "--cache-slots", "2", "--active-sequences", "2",
                       "--pool-tokens", "2048", "--prefix-cache", "off",
                       "--result", str(folder / "peer-result.json")]
            runtime = p["runtime_environment"]
        commands.append(dict(mode=mode, index=i, arm=arm, folder=str(folder), command=command,
                             runtime_environment=runtime, inherit_environment=True,
                             environment_binding="Replace only PATH from the named runtime JSON; set HF_HUB_OFFLINE=1 and TRANSFORMERS_OFFLINE=1; no diagnostics/profiler overrides.",
                             memory_only=(mode == "memory"), expected_exit=0))

pins = dict(
    images=images, hyle_ready=pin(batch_ready_path), hyle_source_pins=source_pins,
    canonical_model_now=pin(R / "engine/models/qwen35/main.cc"),
    canonical_sampling_now=pin(R / "engine/inference/sampling_graph.h"),
    canonical_Model_and_sampling_equal_frozen=True,
    hyle_actual_dependencies=pin(h["actual_dependencies"]["path"]),
    hyle_compiled_project_dependency_count=len(project_deps), hyle_live_project_dependency_drift=dependency_drift,
    hyle_link_inputs=pin(h["link_inputs"]["path"]), hyle_link_contract=read(h["link_contract"]["path"]),
    hyle_runtime=pin(h["runtime"]["path"]),
    old_peer_ready=pin(peer_ready_path), current_433_peer_ready=pin(current_peer_ready_path),
    peer_link_plan_632=pin(p["link_plan"]["path"]), peer_link_plan_433=pin(p433["link_plan"]["path"]),
    peer_absolute_input_count_each=9, peer_shared_absolute_libraries=actual_libraries,
    peer_object_diff=dict(peer632=pl["inputs"][0], peer433=pl433["inputs"][0]),
    peer_runtime_receipts_equal=True, peer_shared_compile_dependency_count=len(shared),
    peer_changed_shared_compile_dependencies=shared_changed,
    peer_source_identity_632=verify(p["source"]), peer_source_identity_433=verify(p433["source"]),
    peer_native_source_record=pin(native_summary_path),
    native_source=dict(llama_commit=native["upstream_llama_commit"], ggml_pin=native["ggml_pin"],
                       resource_patch=native["native_reuse"]),
    nine_local_reference_engine_versions_from_prior_bounded_review=versions,
    nine_engine_version_boundary="Retained2026-10-25 source review versions only; these nine checkouts are not linked into either peer. Peer632/433 use the older d9e03/raw456 resource-patched closure, not the review's23b0202 llama checkout. No upstream update or network verification in this task.",
    old_text_manifest=pin(old_inputs / "weights.tsv"), v2_manifest=pin(new_inputs / "weights.tsv"),
    role_identity_proof=dict(old_text_roles=320, V2_total_roles=335, exact_text_role_matches=320,
                             selected_bytes=3763655360, fields=["name", "dtype", "shape", "source", "offset", "bytes"],
                             old_source_id=old_lines[2], V2_source_id=new_lines[1], payloads_read_or_hashed=False,
                             source_file_sizes=source_sizes),
    input_adaptation=pin(R / ".scratch/mtp-performance-convergence-20261025/current-cuda/input-adaptation.json"),
    harness=dict(runner=pin(runner), observer=pin(observer), old_performance_parser=pin(old_performance)),
    historical_reports=dict(hyle=pin(old_hpath), peer=pin(old_ppath)))

plan = dict(
    status="FROZEN_METADATA_ONLY_NOT_RUN", date="2026-10-26",
    directory=str(D), activity=dict(builds=0, consumer_processes=0, GPU_runs=0, services=0, downloads=0,
                                    model_payload_bytes_read=0, old_results_modified=0),
    decision="Reuse exact uninstrumented formal CUDA batch image41ce916d and retained B2 peer632cc09c without rebuilding. The current formal image supports the old teacher-forced session journey, but its weights loader rejects the old TEXT_V1 manifest: use the existing V2 original directory after the exact320-role manifest comparison. Keep the original session schedules and token tapes unchanged.",
    hyle_scope="Frozen Model dfaa530b and sampling085be10d; formal entry and other221 absolute inputs inherited from refreshed2a94 CUDA closure. The R4 screen already ran this exact image without a private profiler. This B2 plan makes no new throughput claim and does not certify later CPU native/View/backend changes, any newer live-source delta, other backends or all SDK inputs as current.",
    peer_scope="Peer632 differs from the current ordinary/MTP reference433 in consumer source/object/image and supported journey; their retained link plans have exactly the same8 absolute libraries and identical runtime environment. Thus the native core/resource patch closure matches, but the consumer/reference image is not the same and must be named632 for B2. No claim of latest upstream or whole-consumer interchangeability.",
    pins_file=str(D / "pins.json"), expected_work_file=str(D / "expected-work.json"),
    process_count=8, timing_count=6, independent_memory_count=2,
    timing_order=timing_order, memory_order=memory_order, commands=commands,
    execution_handoff=[
        "Root alone executes next round after its Graph diagnostic releases the GPU. Do not start these processes during this metadata turn.",
        "Before running, revalidate the frozen plan/image/small input/harness/runtime pins and actual hardware/toolchain; keep all output under this directory. No new source/SDK/model build, copy, service, network or warmup is needed.",
        "Implement only a thin two-arm adapter around the existing multiturn_run.py execute/identity/read/save/gpu_snapshot and observer.install. Reuse old performance.py work/metrics logic. Do not import or run old performance.py directly: its top level parses args, creates historical output and starts consumers.",
        "The adapter must read Hyle runtime through ready.runtime.path (new receipt spelling), peer through ready.runtime_environment.path; bind PATH exactly as recorded, preserve original process/phase clocks and use fresh output folders with exist_ok=False.",
        "Run six unmonitored timing processes in the frozen H,P,P,H,H,P order, then one separate memory-only H,P pair. First timing H and P are also the work preflight; no extra behavior process or arbitrary retries are authorized by this8-process plan.",
        "Stop immediately on failed exit, timeout, malformed/missing fields, work-gate failure or within-arm non-time instability. Preserve the failed run and remaining-not-run plan; do not silently filter samples, refill to8 or declare success.",
        "Memory uses the original10ms requested PSAPI/PDH probe and live stderr observer. Keep null/unavailable counters and actual sample gaps; do not use monitored process times in the six-process throughput statistics.",
        "Summarize each timing metric with all three samples, median/min/max, and separate observed memory peaks. Preserve every command/stdout/stderr/result/observation and phase marker. No historical samples are pooled."
    ],
    full_work_gate=[
        "Every process exits0 without timeout or observer reader errors. Report JSON is original stdout for Hyle and peer-result.json for peer; do not move producer timing endpoints.",
        "Processed1728, generated198, actual_graph_tokens1728, graph calls99; exactly2 sessions and active2, C1024, prefixoff, reused0 and no prefix/full-hit, no restore/recompute/eviction path. Hyle is ordinary greedy CUDA, MTP off and diagnostics false; native peer is retained d9e03.",
        "Each original phase/tape is unchanged: per session3 prompts of256 rows and3 decode tapes of32 rows; six phases, three turns,864 evaluated rows and99 returned decisions. Verify actual consumed decode IDs, context-before/after and request/session identities against expected-work.json, rather than only totals.",
        "All99 physical episodes match the frozen expected kind/T/ordered[alice,bob], requests2. Hyle batches(query_rows/session_ids) and peer episodes(T/member.session) must match exactly. All waves match frozen kind/outputs/logical_tokens/actual_tokens/graph_calls, with total1536 prefill and192 decode rows. No sum of overlapping request latencies.",
        "For each engine independently, use its first new timing report as a whole-report non-time baseline and compare all subsequent timing and memory reports after removing only original seconds/rates/clock keys. Preserve new fields and differences; do not reduce the gate to IDs, selected counters or the historical report schema.",
        "Compare and report cross-engine generated IDs but do not require them equal or filter mismatches. Teacher-forced input work stays fixed independently of output; BF16/F32 recurrent/intermediate precision and N+R/failure contracts differ. Matching output IDs is not a task-quality or bit-equivalence certificate.",
        "Confirm0<sum(prefill/decode wave seconds)<=global wall*1.001; positive denominators and complete original wave classification. Hyle whole-journey denominator is interleaved_seconds and peer is session_seconds, not step_sum_seconds or overlapping per-session sums.",
        "Hyle expected current source id is V2 4a76decdfa58a5fd6e15acea7ff410e84fd3e81cb6c39db8a658eeb23d869fbe and selected original320 text role payload3763655360B. Historical TEXT_V1 source id4068044d differs by manifest identity, not a new checkpoint;320 role fields are independently compared in pins.json."
    ],
    extraction=dict(
        raw_hyle="runs/<run>/stdout.log: original single fixed-session JSON",
        raw_peer="runs/<run>/peer-result.json",
        process="runs/<run>/result.json: exit/pid/command/image/cwd/profiler=false/throughput_evidence/memory_only; parent process_wall_seconds is separate",
        loading_hyle="stderr.log weights_load_seconds=...; initialized model_seconds=... shape_prepare_seconds=... startup_to_ready_seconds=...",
        loading_peer="peer-result.json model_load_seconds and ready_seconds; context_seconds separately",
        prefill="1536 / sum(raw.waves[kind=prefill].seconds)",
        decode="192 / sum(raw.waves[kind=decode].seconds)",
        combined="198 / raw.interleaved_seconds for Hyle;198 / raw.session_seconds for peer",
        startup="raw.startup_total_seconds: keep original startup-through-last-output endpoint; report load/ready separately",
        working_set="Independent memory-summary.json sampled_peaks.sampled_max_working_set_bytes; observed_os_peak_working_set_bytes separately",
        private_commit="Independent memory-summary.json sampled_peaks.sampled_max_private_commit_bytes; observed_os_peak_commit_bytes separately",
        dedicated_VRAM="Independent memory-summary.json sampled_peaks.sampled_peak_gpu_dedicated_bytes; gpu shared/total separately and never sum independent peaks",
        memory_limits="memory-summary.json actual_sample_gaps_ms/sample_cost_ms/null_sample_counts/unavailable_reasons/setup_error/thread_error/ready_baseline/phase_windows; raw samples remain in memory.json",
        observations="New adapter saves per-run observation.json with untouched raw report plus derived metrics/phase_seconds/IDs, runs.json incrementally, complete non-time diffs and final summary.json; these do not exist yet"),
    fairness_limits=[
        "Three new independent unmonitored timing samples per engine, one independent memory process each. Finite medians/ranges only, no significance certificate.",
        "Same cached original checkpoint and exactly matched forced input work, but legal BF16/F32 math and native retained-versus-mutable state/failure contracts differ. Same logical C/N/R is not equal physical backing bytes.",
        "Hyle current source/cache/schema may differ from its2026-10-22 historical consumer; compare current arms, not pooled historical medians. Old B2 decode153.642/186.576 and17.65% gap are motivation only.",
        "This is ordinary equal-T two-session synthetic aggregate throughput with prefixoff/no eviction, not natural output, R4 random, MTP, running admission, general serving fairness, or dynamic cancellation latency.",
        "Sampled RAM/VRAM peaks are lower bounds. Ready baseline or short phase values may be unknown, not zero; WS/commit/dedicated/shared are different metrics and cannot be added. OS page cache is not cleared and load sub-boundaries differ between engines, so do not call load cold-disk speed.",
        "No product changes or performance result are claimed by this plan. No broad platform/model matrix or revalidation of previously closed leaf candidates is implied."])

save("pins.json", pins)
save("expected-work.json", expected_work)
save("plan.json", plan)
print(json.dumps(dict(status=plan["status"], processes=8,
                      role_matches=320, identical_peer_libraries=8,
                      shared_compile_dependency_changes=len(shared_changed),
                      Hyle_live_dependency_drift=len(dependency_drift),
                      paths=[str(D / x) for x in ("plan.json", "pins.json", "expected-work.json")]), indent=2))
