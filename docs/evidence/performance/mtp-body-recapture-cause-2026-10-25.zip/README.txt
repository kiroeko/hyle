Existing-data review only: no new model/GPU/compile/profile/download.

To reproduce in a repository checkout:
1. Extract this ZIP to .scratch/mtp-body-recapture-cause-20261025/.
2. Restore the five original input members listed in public JSON input_archives
   to their exact restore_repository_path_for_analyzer. Verify SHA256 first.
   Do not restore or copy SDK/model/binary trees.
3. From the repository root run:
   python .scratch/mtp-body-recapture-cause-20261025/analyze.py
4. cause-facts.json is regenerated from those original observations. The
   source-pins.json is the frozen review record, not a request to re-pin HEAD.

The first local analysis attempt asserted every varying-position literal was
known. It failed without changing source or running a model. The final analysis
retains the unknown literals explicitly (8 queries); it never invents physical
addresses. Complete equality comparisons remain exact or stop unknown.
