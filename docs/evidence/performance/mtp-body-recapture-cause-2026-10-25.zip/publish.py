from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import zipfile

ROOT = Path.cwd()
WORK = Path(__file__).resolve().parent
PUBLIC = ROOT / 'docs/evidence/performance'
STEM = 'mtp-body-recapture-cause-2026-10-25'

def digest(raw):
    return hashlib.sha256(raw).hexdigest()

def pin(path):
    return {'path': path.relative_to(ROOT).as_posix(), 'bytes': path.stat().st_size,
            'sha256': digest(path.read_bytes())}

facts = json.loads((WORK / 'cause-facts.json').read_bytes())
input_sources = [
    ('mtp-complete-binding-diff', 'records.json', '.scratch/mtp-complete-binding-diff-20261025/records.json'),
    ('mtp-complete-binding-diff', 'root-followup/offline-join/eligible-record-api-windows.json', '.scratch/mtp-complete-binding-diff-20261025/eligible-record-api-windows.json'),
    ('mtp-body-replay-design', 'reconstruct_keys.py', '.scratch/mtp-body-variant-design-20261025/reconstruct_keys.py'),
    ('mtp-body-replay-design', 'opponent-counts.json', '.scratch/mtp-body-variant-design-20261025/opponent-counts.json'),
    ('mtp-native-plan-diagnostics', 'native-slot-sequences.json', '.scratch/mtp-native-plan-diagnostics-20261025/native-slot-sequences.json')]
references = []
for name, member, original in input_sources:
    archive = PUBLIC / (name + '-2026-10-25.zip')
    with zipfile.ZipFile(archive) as z:
        raw = z.read(member)
    assert raw == (ROOT / original).read_bytes(), original
    references.append({'archive': pin(archive), 'member': member,
                       'member_bytes': len(raw), 'member_sha256': digest(raw),
                       'restore_repository_path_for_analyzer': original})

readme = '''Existing-data review only: no new model/GPU/compile/profile/download.

To reproduce in a repository checkout:
1. Extract this ZIP to .scratch/mtp-body-recapture-cause-20261025/.
2. Restore the five original input members listed in public JSON input_archives
   to their exact restore_repository_path_for_analyzer. Verify SHA256 first.
   Do not restore or copy SDK/model/binary trees.
3. From the repository root run:
   python .scratch/mtp-body-recapture-cause-20261025/analyze.py
4. cause-facts.json is regenerated from those original observations. The
   source-pins.json is the frozen review record, not a request to re-pin HEAD.

The first local analysis attempt asserted every varying-position literal was
known. It failed without changing source or running a model. The final analysis
retains the unknown literals explicitly (8 queries); it never invents physical
addresses. Complete equality comparisons remain exact or stop unknown.
'''
(WORK / 'README.txt').write_text(readme, encoding='utf-8', newline='\n')
members = ['README.txt', 'analyze.py', 'cause-facts.json', 'findings.md', 'source-pins.json', 'publish.py']
manifest = {'members': [{'name': n, 'bytes': (WORK / n).stat().st_size,
                         'sha256': digest((WORK / n).read_bytes())} for n in members]}
(WORK / 'member-sha256.json').write_text(json.dumps(manifest, indent=2) + '\n', encoding='utf-8')
archive = PUBLIC / (STEM + '.zip')
with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for name in members + ['member-sha256.json']:
        z.write(WORK / name, name)
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for entry in manifest['members']:
        raw = z.read(entry['name'])
        assert len(raw) == entry['bytes'] and digest(raw) == entry['sha256']

rows = []
for row in facts['body_records']:
    closest = row['closest_valid_variant']
    rows.append({k: row[k] for k in ['seq', 'range_begin', 'role', 'context', 'lag', 'accepted_inputs', 'reason',
                                    'native_invalidated_steps', 'capture_span_ms', 'native_API', 'native_API_ms',
                                    'capture_through_native_API_end_ms']} |
                {'closest_variant_recorded_at_seq': closest['recorded_at_seq'] if closest else None,
                 'closest_variant_changed_port_classes': closest['port_classes'] if closest else None})
report = {
    'status': 'EXISTING_TRACE_SOURCE_CAUSE_REVIEW_NO_SPEED_RESULT',
    'generated_UTC': datetime.now(timezone.utc).isoformat(),
    'scope': 'Reanalysis of prior Oct25 frozen-source direct binding observations and aligned earlier profiler API windows. Not a current-HEAD run or throughput measurement.',
    'new_model_GPU_profile_build_HTTP_processes': 0,
    'meaning': '15 body captures, not weight reloads; existing backing offsets change while all observed dtype/shape/bytes/resource/handles agree.',
    'body_queries': 66, 'key_ports_per_body': 2031,
    'body_capture_records': 15, 'body_capture_and_following_native_API_window_ms': 78.431404,
    'reason_groups': facts['reason_groups'], 'body_records': rows,
    'allocation_cause': facts['allocation_cause'],
    'native_invalidation_cause': {k: v for k, v in facts['native_invalidation_cause'].items() if k != 'prior_same_work_slots'},
    'hidden_output_counterfactual': {
        'complete_stream_other_keys_and_actual_clears_preserved': True,
        'body_records_before_after': [15, 10], 'removed_seq': [13, 14, 15, 16, 41],
        'direct_hidden_output_only_seq': [13, 14, 15, 41],
        'replacement_cascade_seq': [16], 'observed_joined_removed_window_ms': 19.474001,
        'not_executed': True, 'speed_or_recoverable_time_claim': None,
        'candidate': 'Stable hidden OUTPUT work storage plus existing canonical selected-copy/retirement path; independent from rejected hidden INPUT ingress and reverse-allocation candidates.',
        'permission': 'Ignoring offsets, overwriting old readers, relaxing budgets, or treating a cached native seed as launchable remains forbidden.'},
    'peer': {
        'capture_by_role': facts['peer_same_scope']['actual_capture_by_role'],
        'all_decode_API': facts['peer_same_scope']['all_decode_API'],
        'boundary': '7 capture windows include2 initial Instantiate+Update windows and5 Update-only; not9 recordings. First target T2 in each turn executes eager, next stable call captures. No free warmup outside original endpoints.',
        'limits': facts['peer_same_scope']['limits']},
    'source_pins': facts['source_pins'], 'input_archives': references,
    'limits': facts['limits'] + [
        'Seq37 chunk-change query was directly recorded only in a prior same-work native diagnostic. Seq38/43 exact placement is source/layout inference, not a native reason recorded in this trace.',
        'No per-layer scattered-offset cause was observed; unknown invariant literals remain explicit.',
        'Native plan/layout invalidation is a safety contract; this review does not authorize ignoring it.',
        'No current full-window refresh, peer recapture-property proof, GPU graph-lineage certification, or performance improvement.'],
    'archive': pin(archive),
    'archive_verification': {'members': len(members) + 1, 'CRC': 'PASS', 'member_SHA256': 'PASS',
                             'SDK_models_binaries_or_original_large_archives_included': False}}
(PUBLIC / (STEM + '.json')).write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'report': pin(PUBLIC / (STEM + '.json')), 'archive': pin(archive),
                  'members': len(members) + 1}, indent=2))
