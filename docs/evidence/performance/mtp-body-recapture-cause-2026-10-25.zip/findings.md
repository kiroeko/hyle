# Fifteen body captures: existing-data cause review

No compile, model run, GPU operation, profile, HTTP, or canonical edit. `analyze.py` reads the original complete-key stream and the previously verified 32-window API join. `cause-facts.json` contains all 15 rows, all 66 offset observations, peer counts, source pins, and the exact counterfactual.

These are **body CUDA Graph captures**, not weight-file reloads. Weight preparation/import and Family compilation are cold; the measured `prepare_evaluations` binds existing weights and current state leases. All recorded key changes here are offsets: dtype/shape/required bytes/resource/handle do not change. Every body key still compares all 2,031 physical ports.

|Seq|Context / lag|Direct cause / closest existing key|Capture through native API, ms|
|---:|---:|---|---:|
|2|154 / 0|First lag0 role|10.998560|
|3|156 / 1|First lag1/catchup role|7.187722|
|4|158 / 1|Second state-address pattern, versus seq3; 72 GDN + 2 hidden-output ports|6.676489|
|8|165 / 0|Second state-address pattern, versus seq2; 72 GDN ports|6.593432|
|13|173 / 0|Versus seq2: only 2 hidden-output offsets|3.830324|
|14|174 / 0|Versus seq8: only 2 hidden-output offsets|3.961606|
|15|176 / 1|Versus seq3: only 1 hidden-output offset; replacement displaces the other state pattern|4.087818|
|16|178 / 1|73/74 differing ports versus remaining variants; indirect re-fill after seq15 replacement|4.119761|
|37|372 / 0|Six target native attention steps invalidate the entire body key set|4.121719|
|38|374 / 1|Same native invalidation in catchup role|3.800894|
|39|375 / 0|Re-fill second state pattern after seq37 clear; 108 GDN ports|5.205887|
|40|377 / 1|Re-fill second state pattern after seq38 clear; 72 GDN ports|5.196732|
|41|379 / 1|Versus seq38: only 2 hidden-output offsets|3.474492|
|43|383 / 1|Six target native attention steps invalidate the entire body key set|3.674585|
|44|385 / 1|Re-fill second state pattern after seq43 clear; 72 GDN + 2 hidden-output ports|5.501383|

The four direct hidden-only windows total **15.354240 ms**. Stable hidden **outputs**, while retaining all real native clears and the complete other key fields, change the reconstructed trajectory from 15 to 10 captures: seq13/14/15/16/41 disappear, an observed joined window subset of **19.474001 ms**. Seq16 is the replacement cascade, not a fifth direct hidden-only miss. This is a fixed-binding-stream counterfactual, not executed safety or speed evidence. It does not recover all 78.431404 ms or the 1.5423 ms/episode algebraic gap.

## Allocation/retention cause, and what was disproved

The 18 GDN layer pools have identical known offset patterns within each class at every observed query. There is no evidence for per-layer offset drift producing scattered combinations. GDN states use three slots; hidden uses four in this N1/R1/K1 plan. Each GDN row is allocated in reverse prefix order, hidden in forward row order; finish retains the actual accepted state and carry, plus prior only when two inputs were accepted. Rejections at seq7/11/12/13 and seq38 change which hidden intervals stay live. The original interval allocator then returns different legal pairs, such as `[0,2]`, `[0,1]`, `[1,2]`, `[0,3]`. This is lease retention/free-range behavior, not new weights or a new shape.

Current anchors: `main.cc:1924–1941` pools, `:3623–3641` actual allocations, `:3820–3833` accepted-prefix retention, `:3952–3974` unbind/publish/detach; frozen measured main has the same operations at `:2221–2238`, `:3838–3857`, `:4030–4044`, `:4164–4187`. `resource_leases.cc:856–875` exposes ordinary allocation only; `range_allocator.cc:576–585` returns ranges only when the allocation dies. Neither permits forcing a still-read interval. More variants is not a fix: original cap2, cap3, and no-eviction cap66 all reproduce 15 captures with actual clears intact. Previously rejected reverse allocation and fixed hidden **input** ingress are separate and remain closed.

The smallest new testable mechanism is stable caller-work hidden **output** storage followed by copying only the selected carry/prior into the existing immutable canonical lease path (at most 8 KiB/episode in this K1 case). It must retain actual native retirement, old-reader independence, expected-base publication, original budget and CopyBatch authority. It is not permissible to ignore output offsets in the capture key or alias/overwrite published hidden readers. The source review has not established a correct patch or benefit; architecture review owns the next implementation decision. Full GDN staging of ~19 MiB/boundary is unnecessary for the above five-window target.

## Three native clears

Direct same-trace evidence at seq37/38/43 is `NativeArguments` at six attention steps, zero valid keys afterward and a nonlaunchable update seed retained. These windows use ExecUpdate successfully, not failed update fallback. Native plan reuse is separately qualified: `flashinfer_provider.cc:257–282` rejects changed split chunk count; `batch_execution.cc:527–530` invalidates before replacing a plan; `graph_batch/batch.cc:526–549` routes that callback to `RegionAccess::invalidate_commands` (`region_access.cc:129–135`), then `executable.cc:8126–8155` discards all affected key authority.

The prior same-work native diagnostic directly records seq37's role3 page refs13→24, chunk rows128, chunks2→3. Role4 has exactly two chunk-count rejections and no other non-initial predicate failure; its individual late query ordinals were not logged. Mapping those two to seq38 (prior context215→374, refs14→24, chunks2→3) and seq43 (context381→383, refs24→25, chunks3→4) is a source/layout inference corroborated by this trace's two actual clears. Do not label it a newly recorded native reason. The existing fixed512 candidate remains rejected; this evidence is not a reason to reopen it.

## Opponent boundary comparison

Peer actual **7 captures = target2 + draft5**, with 2 Instantiate and 7 Update API calls (first target/draft captures each Instantiate then Update; this is not nine captures). Target windows seq6/74 total8.222699 ms; draft seq7/19/35/67/75 total0.951869 ms. Target first T2 calls seq4/72 execute eager, then seq6/74 capture after stable properties. Draft likewise executes eager on first/changed shapes. No separate consumer warmup exists; eager calls remain in the measured decode endpoints. Target has64 T2 +1 T1 tail calls; Hyle has66 T2 calls, distinct continuation/acceptance and activation stores.

Matched peer `ggml-cuda.cu:2643–2682` keys graph/node/source pointer+geometry (or unchanged UID), `:4483–4500` requires stability and falls back eager on changed properties, `:4430–4438` updates/launches. Its persistent recurrent banks (`llama-memory-recurrent.cpp:101–107`) and bounded single-use rollback (`:193–201`) are not Hyle's arbitrary immutable Snapshot/escaped-reader contract. The peer trace does not record which exact property caused each of its seven captures. Thus counts and capture windows are observable; attributing all difference to GDN address stability is not proven.
