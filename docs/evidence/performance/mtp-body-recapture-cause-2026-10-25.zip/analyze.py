"""Read existing full-key observations; do not modify original evidence."""
from pathlib import Path
from collections import Counter, defaultdict
import hashlib
import json

ROOT = Path.cwd()
WORK = Path(__file__).resolve().parent
OLD = ROOT / '.scratch/mtp-body-variant-design-20261025/reconstruct_keys.py'
text = OLD.read_text()
scope = {'__file__': str(OLD)}
exec(compile(text.split('base, candidate, no_evict =')[0], str(OLD), 'exec'), scope)
events, data, groups = scope['events'], scope['D'], scope['groups']
root, values = scope['root'], scope['values']
physical_by_id = {v: json.loads(k) for k, v in scope['physical_ids'].items()}
by_event = {e['i']: e for e in events}
flat_metadata = {}
for p in data['ports']:
    e = by_event[p['event']]
    if e['saved'] in groups:
        flat_metadata[e['saved'], p['flat']] = p

def physical(cell):
    value = values[root(cell)]
    return None if value is None else physical_by_id[value]

def category(p):
    dims = p['new']['dims']
    return ('output_' if p['output'] else 'input_') + (
        'hidden' if dims == [1, 2048] else
        'history' if dims == [1, 3, 6144] else
        'recurrent' if dims == [1, 16, 128, 128] else 'other')

def compare(a, b, saved, omitted):
    unknown = 0
    for pos, (x, y) in enumerate(zip(a, b)):
        p = flat_metadata.get((saved, pos))
        if p is not None and category(p) in omitted:
            continue
        x, y = root(x), root(y)
        if x == y:
            continue
        if values[x] is not None and values[y] is not None:
            if values[x] != values[y]:
                return False
        else:
            unknown += 1
    return None if unknown else True

def project(omitted):
    cache, clock, rows = {}, 0, []
    for kind, saved, seq, key in scope['timeline']:
        if kind == 'clear':
            cache.pop(saved, None)
            continue
        clock += 1
        entries = cache.setdefault(saved, [None, None])
        hit = None
        for slot, entry in enumerate(entries):
            if entry is None:
                continue
            equality = compare(entry[0], key, saved, omitted)
            if equality is None:
                return {'status': 'UNKNOWN', 'seq': seq}
            if equality:
                hit = slot
                break
        recorded = hit is None
        if hit is None:
            hit = next((i for i, e in enumerate(entries) if e is None), None)
        if hit is None:
            hit = min(range(2), key=lambda i: entries[i][1])
        entries[hit] = key, clock
        rows.append({'seq': seq, 'range_begin': groups[saved][1], 'record': recorded})
    return {'status': 'EXACT_EQUALITY_PROJECTED_FIXED_BINDING_STREAM_ONLY',
            'omitted_port_categories': sorted(omitted),
            'records': sum(x['record'] for x in rows),
            'record_set': [[x['seq'], x['range_begin']] for x in rows if x['record']]}

windows = json.loads((ROOT / '.scratch/mtp-complete-binding-diff-20261025/eligible-record-api-windows.json').read_bytes())
api = {(r['seq'], r['range_begin']): r for r in windows['all32'] if r['range_begin']}
records = []
variant_sources = {}
for e in events:
    if e['saved'] in groups and e['kind'] == 6:
        variant_sources.pop(e['saved'], None)
    if e['saved'] in groups and e['kind'] == 9:
        variant_sources.setdefault(e['saved'], {})[e['variant']] = e['seq']
    if e['saved'] not in groups or e['kind'] != 8:
        continue
    seq, saved = e['seq'], e['saved']
    mismatches = [x for x in events if x['saved'] == saved and x['seq'] == seq and x['kind'] == 3]
    comparisons = []
    for mismatch in mismatches:
        ps = [p for p in data['ports'] if p['event'] == mismatch['i']]
        comparisons.append({'variant': mismatch['variant'], 'changed': mismatch['changed'],
                            'recorded_at_seq': variant_sources.get(saved, {}).get(mismatch['variant']),
                            'port_classes': dict(Counter(category(p) for p in ps)),
                            'all_offset_only': all(p['flags'] == 16 for p in ps)})
    native = [x for x in events if x['saved'] == saved and x['seq'] == seq and x['kind'] == 7 and x['aux'] == 2]
    reason = 'first_role_record' if seq in (2, 3) else ('native_plan_invalidation' if native else 'valid_key_address_miss')
    closest = min(comparisons, key=lambda c: c['changed']) if comparisons else None
    w = api[seq, e['begin']]
    records.append({'seq': seq, 'range_begin': e['begin'], 'role': data['FINISH_meta'][str(seq)]['role'],
                    'context': w['context'], 'frontier': w['frontier'], 'lag': w['lag'],
                    'accepted_inputs': data['FINISH_meta'][str(seq)]['accepted_inputs'],
                    'reason': reason, 'keys_before': e['keys'], 'seed_before': e['seed'],
                    'closest_valid_variant': closest, 'all_valid_comparisons': comparisons,
                    'native_invalidated_steps': sorted(set(x['selected_step'] for x in native)),
                    'capture_span_ms': w['capture_span_ms'], 'native_API': w['following_native_API']['api'],
                    'native_API_ms': w['native_API_ms'],
                    'capture_through_native_API_end_ms': w['capture_through_native_API_end_ms']})

# All observed varying physical bindings are known after DSU reconstruction.
# Deduplicate actual resource/handle/offset/size, while keeping graph direction.
query_offsets = []
for (saved, seq), key in sorted(scope['current'].items(), key=lambda kv: kv[0][1]):
    offsets = defaultdict(set)
    per_class_pools = defaultdict(dict)
    unknown_positions = 0
    for pos, cell in enumerate(key):
        p = flat_metadata.get((saved, pos))
        if p is None:
            continue
        fact = physical(cell)
        if fact is None:
            unknown_positions += 1
            continue
        cat = category(p)
        offsets[cat].add(fact['offset'] // fact['required_bytes'])
        assert fact['offset'] % fact['required_bytes'] == 0
        per_class_pools[cat].setdefault(str(fact['handle']), set()).add(fact['offset'] // fact['required_bytes'])
    query_offsets.append({'seq': seq, 'begin': groups[saved][1],
                          'accepted': data['FINISH_meta'][str(seq)]['accepted_inputs'],
                          'literal_unknown_positions': unknown_positions,
                          'classes': {cat: sorted(v) for cat, v in sorted(offsets.items())},
                          'pool_count': {cat: len(v) for cat, v in per_class_pools.items()},
                          'per_pool_offsets_identical': {cat: len({tuple(sorted(s)) for s in v.values()}) == 1
                                                        for cat, v in per_class_pools.items()}})

reason_groups = defaultdict(lambda: {'count': 0, 'seq': [], 'window_ms': 0.0, 'native_API_ms': 0.0})
for r in records:
    key = r['reason']
    if key == 'valid_key_address_miss':
        classes = set(r['closest_valid_variant']['port_classes'])
        key += '_hidden_outputs_only' if classes == {'output_hidden'} else '_GDN_present'
    g = reason_groups[key]
    g['count'] += 1
    g['seq'].append(r['seq'])
    g['window_ms'] += r['capture_through_native_API_end_ms']
    g['native_API_ms'] += r['native_API_ms']

def pin(p):
    return {'path': p.relative_to(ROOT).as_posix(), 'bytes': p.stat().st_size,
            'sha256': hashlib.sha256(p.read_bytes()).hexdigest()}

out = {'status': 'OFFLINE_EXISTING_FULL_KEY_AND_ALIGNED_API_WINDOWS_ONLY',
       'inputs': [pin(OLD), pin(scope['P']), pin(ROOT / '.scratch/mtp-complete-binding-diff-20261025/eligible-record-api-windows.json')],
       'body_records': records, 'reason_groups': dict(reason_groups),
       'projected_key_counterfactuals': [project(set()), project({'output_hidden'}),
                                        project({'input_history', 'output_history', 'input_recurrent', 'output_recurrent'}),
                                        project({'input_hidden', 'output_hidden'})],
       'all66_query_slot_offsets': query_offsets,
       'limits': ['Offset units use each exact tensor required_bytes; this is not a lease-generation or ownership proof.',
                  'Projected categories are theoretical stable-address conditions, not permission to ignore capture keys.',
                  'Every logged explicit discard is retained; addresses are reconstructed from existing complete comparisons.',
                  'API timings are from the separate prior trace joined only after all32 record seq/order/range/signature alignment.',
                  'No GPU/model/compile/network operation was run.']}
opponent_path = ROOT / '.scratch/mtp-body-variant-design-20261025/opponent-counts.json'
opponent = json.loads(opponent_path.read_bytes())
peer = opponent['arms']['peer_earlier_logical_profile']
out['peer_same_scope'] = {
    'input': pin(opponent_path),
    'actual_capture_by_role': opponent['peer_capture_by_role'],
    'all_decode_API': peer['all_API'],
    'capture_windows': peer['capture_windows'],
    'decode_groups': [g for g in peer['groups'] if 'decode' in g['role']],
    'eager_calls': [{k: r[k] for k in ['label', 'meta', 'observed_eager_kernels', 'GPU_execution_union_ms']}
                    for r in peer['logical_rows'] if 'decode' in r['label'] and r['observed_eager_kernels']],
    'limits': ['Peer target/draft are separate native graph boundaries; Hyle body is not a certified identical graph.',
               'No separate consumer warmup exists. Initial eager decodes and stability-reset eager calls remain inside original P/D endpoints.',
               'Per-peer-capture changed property was not recorded; physical state I/O stability is a source mechanism, not a per-event causal proof.',
               'Peer 65 target calls/129 rows and Hyle66 target calls/132 rows, distinct continuations/acceptance and activation stores, remain unequal work.']}
native_path = ROOT / '.scratch/mtp-native-plan-diagnostics-20261025/native-slot-sequences.json'
native = json.loads(native_path.read_bytes())
out['native_invalidation_cause'] = {
    'same_trace_direct': 'seq37/38/43: NativeArguments invalidation at six target attention steps; both complete variant keys discarded, nonlaunchable seed retained.',
    'prior_same_work_input': pin(native_path),
    'prior_same_work_slots': [{'slot': s['slot'], 'query_reasons': s['query_reasons'],
                               'unsequenced_late_reasons': s['query_predicate_counts_beyond_detail'],
                               'recorded_nonreuse_queries': [q for q in s['detailed_queries'] if q['reason'] != 'reuse']}
                              for s in native if s['slot'] in [6, 7, 13]],
    'source_inference': [
        {'seq': 37, 'role': 3, 'kind': 'prior native detailed query directly records this same-work call',
         'page_refs': [13, 24], 'chunk_rows': 128, 'chunks': [2, 3]},
        {'seq': 38, 'role': 4, 'kind': 'source/layout inference; native predicate not individually logged in this trace',
         'context_before': [215, 374], 'target_T': 2, 'page_refs': [14, 24], 'chunks': [2, 3]},
        {'seq': 43, 'role': 4, 'kind': 'source/layout inference; native predicate not individually logged in this trace',
         'context_before': [381, 383], 'target_T': 2, 'page_refs': [24, 25], 'chunks': [3, 4]}],
    'not_caused_by': ['weight load/import', 'new source weights', 'observed tensor shape/dtype/required-byte/resource/handle mismatch'],
    'qualification': 'Old native aggregate proves exactly2 chunk_count rejections in each role4 slot and no other predicate rejection. The seq38/43 placement uses deterministic same-work layouts, not a newly observed native return reason.'}
out['allocation_cause'] = {
    'GDN_layers': 18,
    'all_logged_varying_classes_have_identical_offset_sets_across_each_layer_pool':
        all(all(q['per_pool_offsets_identical'].values()) for q in query_offsets),
    'literal_unknown_positions_by_seq': {q['seq']: q['literal_unknown_positions'] for q in query_offsets if q['literal_unknown_positions']},
    'conclusion': 'No observed per-layer allocation drift. Reversed GDN prefix allocation and selected-prefix retention yield synchronized state pool offset patterns.',
    'address_fills': {'second_initial_role_variant': [4, 8], 'after_real_native_clear': [39, 40, 44]},
    'hidden_output_pair_changes': [13, 14, 15, 41],
    'indirect_variant_displacement': [16],
    'first_turn_reject_chain': [7, 11, 12, 13],
    'mechanism': 'Hidden pool has four slots for N1/R1/K1. Accepted two retains carry+prior, accepted one retains one. Fixed original per-row allocation therefore observes changing free interval pairs; old-reader/native guards still determine when intervals are genuinely reusable.',
    'no_simple_pool_reorder_candidate': 'LeasePool.allocate does not request a selected offset. Changing allocation order was already screened negatively; no new slot manager/forced reuse is proposed.'}
# These source snapshots were read and pinned when this review was made.
# Reproduction of the numerical key analysis must not silently re-pin a later
# checkout or require copying the original SDK/source tree.
out['source_pins'] = json.loads((WORK / 'source-pins.json').read_bytes())['files']
(WORK / 'cause-facts.json').write_text(json.dumps(out, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'groups': out['reason_groups'], 'projections': out['projected_key_counterfactuals'],
                  'allocation': out['allocation_cause']}, indent=2))
