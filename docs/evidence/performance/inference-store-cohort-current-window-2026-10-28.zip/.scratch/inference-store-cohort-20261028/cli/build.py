"""One explicit Model CXX/link, reusing the two successful Graph objects."""
from pathlib import Path
import importlib.util
import sys

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
ROOT = W.parent
R = Path(r'C:\public\project-hyle\hyle')
BASE = R / '.scratch/inference-review-current-window-20261028'
SOURCE = R / 'engine/models/qwen35/main.cc'
spec = importlib.util.spec_from_file_location('cohort_cli_original_driver', R / '.scratch/inference-indexed-store-20261028/build.py')
t = importlib.util.module_from_spec(spec); spec.loader.exec_module(t); t.W = W


def prepare():
    ready = t.read(BASE / 'ready-model.json')
    assert ready['image']['sha256'] == '2c0f942325ebf2bd7c2db155d7dea03049166b6fd1f189637dccb42d18ca42f2'
    for name in ('inputs', 'recipe', 'runtime'): t.exact(ready[name])
    rows = t.read(ready['inputs']['path']); assert len(rows) == 229
    frozen = t.read(ROOT / 'final-source-freeze.json'); t.exact(frozen['dependencies'])
    root_plan = t.read(ROOT / 'final-build-plan.json')
    sources = {t.key(row['original']['path']): row for row in frozen['snapshots']}
    model = sources[t.key(SOURCE)]
    t.exact(model['original']); t.exact(model['snapshot'])
    snapshot = W / 'source/engine/models/qwen35/main.cc'
    snapshot.parent.mkdir(parents=True, exist_ok=True)
    with snapshot.open('xb') as out: out.write(Path(model['snapshot']['path']).read_bytes())
    replacements = {'model': dict(original=ready['compiled']['object'], replacement=str(W / 'compile/model/unit.obj'))}
    graph = {}
    for name in ('resources', 'slots-region'):
        compiled = t.read(ROOT / f'compile/{name}/compiled.json')
        assert compiled['process']['exit'] == 0 and not compiled['process']['timed_out']
        t.exact(compiled['object'])
        assert compiled['source'] == sources[t.key(R / root_plan['units'][name]['source'])]['original']
        replacements[name] = dict(original=root_plan['original_objects'][name], replacement=compiled['object']['path'])
        graph[name] = dict(receipt=t.pin(ROOT / f'compile/{name}/compiled.json'), compiled=compiled)
    assert all(value['original'] in rows for value in replacements.values())
    before = t.command(ready['compiled']['command']['path']); args = []
    old_source = t.read(ready['compiled']['dependencies']['path'])['Data']['Source']
    for i, arg in enumerate(before):
        if t.key(arg) == t.key(old_source): arg = str(snapshot)
        elif i and before[i-1].lower() == '/sourcedependencies': arg = str(W / 'compile/model/dependencies.json')
        elif arg.lower().startswith('/fo'): arg = '/Fo' + str(W / 'compile/model/unit.obj')
        elif arg.lower().startswith('/fd'): arg = '/Fd' + str(W / 'compile/model/unit.pdb')
        args.append(arg)
    args.insert(1, '/I' + str(SOURCE.parent))
    assert sum(t.key(arg) == t.key(snapshot) for arg in args) == 1
    t.save(W / 'recipe-model.json', dict(command=args, timeout_seconds=300))
    mapping = {t.key(v['original']['path']): v['replacement'] for v in replacements.values()}
    link = []
    for arg in t.command(ready['recipe']['path']):
        arg = mapping.get(t.key(arg), arg)
        for prefix, suffix in (('/OUT:', '.exe'), ('/PDB:', '.pdb'), ('/IMPLIB:', '.lib'), ('/MAP:', '.map')):
            if arg.upper().startswith(prefix): arg = prefix + str((W / 'bin/hyle-current').with_suffix(suffix)); break
        link.append(arg)
    assert all(sum(t.key(a) == t.key(v) for a in link) == 1 for v in mapping.values())
    t.save(W / 'link-model.json', dict(command=link, timeout_seconds=240))
    stats = []
    for row in rows:
        if t.key(row['path']) in mapping: continue
        st = Path(row['path']).stat(); assert st.st_size == row['bytes']
        stats.append(dict(path=row['path'], bytes=st.st_size, mtime_ns=st.st_mtime_ns, retained_sha256=row['sha256']))
    assert len(stats) == 226
    t.save(W / 'retained-input-stats.json', stats)
    env = t.read(BASE / 'environment.json'); env['PATH'] = str(W / 'bin') + ';' + env['PATH']
    t.save(W / 'environment.json', env)
    native = t.read(ready['runtime']['path'])['native']; t.exact(native)
    t.save(W / 'runtime.json', dict(PATH=env['PATH'], native=native, ownership='Original successful CUDA/GDN runtime in place; no SDK or payload copy.'))
    # Reuse the parent's already frozen project closure. No SDK/include walk.
    dependencies = t.read(frozen['dependencies']['path'])
    for row in dependencies: t.exact(row)
    t.save(W / 'source-freeze.json', dict(source=model['original'], snapshot=t.pin(snapshot), helper=t.pin(__file__),
        parent=t.pin(ROOT / 'final-source-freeze.json'), project_dependencies=frozen['dependencies'],
        scope='Parent frozen current canonical project headers; source-only snapshot plus original quote include directory. No copied header overlay.'))
    t.save(W / 'build-plan.json', dict(baseline=t.pin(BASE / 'ready-model.json'), inputs=ready['inputs'],
        original_dependencies=ready['compiled']['dependencies'], recipe=t.pin(W / 'recipe-model.json'), link=t.pin(W / 'link-model.json'),
        source_freeze=t.pin(W / 'source-freeze.json'), replacements=replacements, graph=graph,
        retained_stats=t.pin(W / 'retained-input-stats.json'), environment=t.pin(W / 'environment.json'), runtime=t.pin(W / 'runtime.json'),
        driver=t.pin(R / '.scratch/inference-indexed-store-20261028/build.py'),
        counts=dict(CXX=1, links=1, SDK_CXX=0, NVCC=0, downloads=0, original_inputs=229, CLI_inputs=229, replaced_objects=3, retained_inputs=226),
        scope='Control2c0f229 CLI: only Model and the two already successful parent Graph objects change. Original CLI entry, weights and226 other inputs retained. No model run.'))
    print('READY: 1Model CXX +1link, 229inputs/3replacements/226retained; root owns execution')


def validate():
    plan = t.read(W / 'build-plan.json')
    for name in ('baseline', 'inputs', 'original_dependencies', 'recipe', 'link', 'source_freeze', 'retained_stats', 'environment', 'runtime', 'driver'): t.exact(plan[name])
    frozen = t.read(plan['source_freeze']['path'])
    for name in ('source', 'snapshot', 'helper', 'parent', 'project_dependencies'): t.exact(frozen[name])
    for row in t.read(frozen['project_dependencies']['path']): t.exact(row)
    for row in plan['graph'].values(): t.exact(row['receipt']); t.exact(row['compiled']['object'])
    return plan, frozen


def parse_compile():
    plan, frozen = validate(); out = W / 'compile/model'; process = t.read(W / 'logs/model/process.json')
    assert process['exit'] == 0 and not process['timed_out']
    allowed = {t.key(row['path']): row for row in t.read(frozen['project_dependencies']['path'])}
    allowed[t.key(frozen['snapshot']['path'])] = frozen['snapshot']; actual = []
    for path in dict.fromkeys(t.dep_paths(out / 'dependencies.json')):
        if t.project(path) or t.key(path) == t.key(frozen['snapshot']['path']):
            assert t.key(path) in allowed, ('Metadata error after successful CXX: repair offline, never recompile', str(path))
            t.exact(allowed[t.key(path)])
        actual.append(t.pin(path))
    t.save(out / 'actual-dependencies.json', actual)
    t.save(out / 'compiled.json', dict(source=frozen['source'], snapshot=frozen['snapshot'], object=t.pin(out / 'unit.obj'),
        command=t.pin(W / 'logs/model/command.json'), dependencies=t.pin(out / 'dependencies.json'),
        actual_dependencies=t.pin(out / 'actual-dependencies.json'), process=process))
    print('MODEL CXX actual dependencies recorded')


def compile_model():
    plan, _ = validate(); (W / 'compile/model').mkdir(parents=True, exist_ok=False)
    t.execute(t.command(plan['recipe']['path']), W / 'logs/model', 300); parse_compile()


def link_model():
    plan, frozen = validate(); compiled = t.read(W / 'compile/model/compiled.json'); t.exact(compiled['object'])
    for row in t.read(plan['retained_stats']['path']):
        st = Path(row['path']).stat(); assert (st.st_size, st.st_mtime_ns) == (row['bytes'], row['mtime_ns']), row['path']
    mapping = {t.key(row['original']['path']): compiled['object'] if name == 'model' else plan['graph'][name]['compiled']['object']
        for name, row in plan['replacements'].items()}
    original = t.read(plan['inputs']['path']); rows = [mapping.get(t.key(row['path']), row) for row in original]
    assert len(rows) == len({t.key(row['path']) for row in rows}) == 229
    assert sum(a != b for a, b in zip(original, rows)) == 3
    t.save(W / 'inputs-model.json', rows); (W / 'bin').mkdir(exist_ok=True)
    native = t.read(plan['runtime']['path'])['native']; alias = W / 'bin' / Path(native['path']).name
    if not alias.exists(): alias.hardlink_to(native['path'])
    assert alias.samefile(native['path'])
    process = t.execute(t.command(plan['link']['path']), W / 'link/model', 240)
    t.save(W / 'ready-model.json', dict(image=t.pin(W / 'bin/hyle-current.exe'), inputs=t.pin(W / 'inputs-model.json'),
        compiled=compiled, graph=plan['graph'], runtime=plan['runtime'], recipe=t.pin(W / 'link/model/command.json'),
        process=process, plan=t.pin(W / 'build-plan.json'), source_freeze=t.pin(W / 'source-freeze.json'), closure_inputs=229))
    print('CLI LINK PASS: current Model +parent resources/slots-region,226 retained inputs')


if __name__ == '__main__':
    {'prepare': prepare, 'preflight': validate, 'compile': compile_model, 'parse-compile': parse_compile, 'link': link_model}[sys.argv[1]]()
