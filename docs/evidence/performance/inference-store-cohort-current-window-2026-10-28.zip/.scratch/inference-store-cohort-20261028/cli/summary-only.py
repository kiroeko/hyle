"""Offline-only completion of the16 successful, already parsed observations."""
from pathlib import Path
import importlib.util
import shutil
import sys

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('frozen_store_cohort_window', W / 'window.py')
w = importlib.util.module_from_spec(spec); spec.loader.exec_module(w)


def main():
    plan = w.read(W / 'window-plan.json'); w.exact(plan['script']); w.exact(plan['binding'])
    failures = list(W.glob('failure-summary-*.log')); assert len(failures) == 1
    original = failures[0]; text = original.read_text(encoding='utf-8')
    assert "KeyError: 'accepted_drafts'" in text
    preserved = W / 'summary-attempt1.log'
    if not preserved.exists(): shutil.copyfile(original, preserved)
    assert original.read_bytes() == preserved.read_bytes()
    tables = []; comparisons = []; processes = []
    for scenario, role in w.STAGES:
        timing = w.read(W / w.folder_name(scenario, role, 'timing') / 'summary.json')
        memory = w.read(W / w.folder_name(scenario, role, 'memory') / 'summary.json')
        assert timing['status'] == memory['status'] == 'COMPLETE_STABLE'
        assert timing['complete_non_time_differences'] == memory['complete_non_time_differences'] == []
        for variant in ('control', 'candidate'):
            monitored, stats = memory['groups'][variant], timing['groups'][variant]
            tables.append(dict(scenario=scenario, role=role, variant=variant, timing=stats,
                memory=dict(sampled_peaks=monitored['sampled_peaks'], ready_baseline=monitored['ready_baseline'],
                    actual_sample_gaps_ms={key: monitored['actual_sample_gaps_ms'].get(key) for key in ('min', 'median', 'max')},
                    running_sample_count=monitored['running_sample_count'], null_sample_counts=monitored['null_sample_counts'])))
        comparisons.append(dict(scenario=scenario, role=role, median_delta_percent={key:
            100 * (timing['groups']['candidate'][key]['median'] / timing['groups']['control'][key]['median'] - 1) for key in w.METRICS}))
        for mode in ('timing', 'memory'):
            cfg = w.config(scenario, role, mode)
            runs = w.read(W / w.folder_name(scenario, role, mode) / 'runs.json')
            assert len(runs) == len(cfg['commands'])
            for row, expected in zip(runs, cfg['commands']):
                process, raw = row['process'], row['observation']['raw']
                assert process == w.read(Path(row['folder']) / 'result.json')
                assert process['exit'] == 0 and not process.get('timeout') and not process.get('reader_errors')
                assert process['command'] == expected['command'] and process['image'] == expected['image']
                assert raw == w.read(Path(row['folder']) / 'consumer-result.json')
                accepted = raw['accepted_drafts'] if role == 'mtp' else None
                processes.append(dict(scenario=scenario, role=role, mode=mode, variant=row['variant'], window_ordinal=row['window_ordinal'],
                    pid=process['pid'], exit=process['exit'], started_unix_ns=process['started_unix_ns'], finished_unix_ns=process['finished_unix_ns'],
                    image=process['image'], actual_target_rows=raw['actual_target_rows'], actual_draft_rows=raw['actual_draft_rows'],
                    generated_tokens=raw['generated_tokens'], accepted_drafts=accepted, packed_prefill_calls=raw['packed_prefill_calls']))
    assert len(processes) == len({row['window_ordinal'] for row in processes}) == len({row['pid'] for row in processes}) == 16
    amendment = dict(status='OFFLINE_SUMMARY_ONLY_REPAIR', script=w.pin(__file__), frozen_script=w.pin(W / 'window.py'),
        frozen_plan=w.pin(W / 'window-plan.json'), original_failure=w.pin(original), preserved_failure=w.pin(preserved),
        reason='Ordinary reports do not declare accepted_drafts; the original final-summary metadata extractor wrongly required an MTP-only field after all16 successful native processes and strict group analyses.',
        change='Ordinary accepted_drafts is null/not applicable; MTP retains strict raw[accepted_drafts]. All other extraction, original metrics/raw/plans and complete non-time assertions remain unchanged.',
        model_reruns=0, native_failures=0, frozen_files_modified=False)
    w.save(W / 'summary-amendment.json', amendment)
    w.save(W / 'summary.json', dict(status='COMPLETE16_SINGLE_TURN_STRICT_INTRA_HYLE_STABLE', processes=16, timing_processes=12, independent_memory_processes=4,
        binding=w.pin(W / 'binding.json'), plan=w.pin(W / 'window-plan.json'), summary_amendment=w.pin(W / 'summary-amendment.json'),
        table=tables, within_window_comparison=comparisons, actual_processes=processes,
        limits=['Only these new control/candidate observations enter medians; no peer or historical samples pooled.',
            'Three timing/one independent memory per version/role; descriptive medians/ranges, no significance claim.',
            'Complete producer non-time reports equal across variants and within each original group; no additional filter.',
            'Original producer endpoints/10ms requested PSAPI-PDH sampler and actual gaps/nulls retained; unknown ready is not zero.',
            'Sampled GPU memory peaks are lower bounds; Graph backing is not a physical VRAM peak.',
            'Ordinary accepted_drafts=null means not applicable, not zero measured acceptance.']))
    print('COMPLETE16_SINGLE_TURN_STRICT_INTRA_HYLE_STABLE; offline only; zero native reruns')


if __name__ == '__main__': main()
