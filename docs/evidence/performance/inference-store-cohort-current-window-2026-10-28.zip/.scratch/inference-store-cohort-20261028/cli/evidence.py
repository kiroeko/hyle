"""Offline-only sixteen-process performance receipt and small reproducible ZIP."""
from pathlib import Path
from datetime import datetime, timezone, timedelta
import hashlib
import json
import math
import statistics
import zipfile

W = Path(__file__).resolve().parent
ROOT = W.parent
R = Path(r'C:\public\project-hyle\hyle')
BASE = R / '.scratch/inference-review-current-window-20261028'
OUT = R / 'docs/evidence/performance/inference-store-cohort-current-window-2026-10-28'
FORBIDDEN = {'.exe', '.obj', '.pdb', '.dll', '.lib', '.exp', '.bin', '.gguf', '.safetensors', '.pt', '.spv', '.db', '.sqlite', '.nsys-rep', '.pyc', '.zip'}
GROUPS = ('single-ordinary-timing', 'single-ordinary-memory', 'single-mtp-timing', 'single-mtp-memory')
METRICS = ('prefill_tokens_per_second', 'full_decode_tokens_per_second', 'session_output_tokens_per_second', 'session_processed_tokens_per_second')


def read(path): return json.loads(Path(path).read_bytes())
def pin(path):
    path = Path(path).resolve(); digest = hashlib.sha256()
    with path.open('rb') as stream:
        while body := stream.read(1 << 20): digest.update(body)
    return dict(path=str(path), bytes=path.stat().st_size, sha256=digest.hexdigest())
def exact(row): assert pin(row['path']) == row, row['path']
def key(path): return str(path).replace('/', '\\').casefold()
def save(path, value):
    with Path(path).open('x', encoding='utf-8') as out: out.write(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + '\n')
def compact(path, value):
    lines = ['{']
    for index, (name, item) in enumerate(value.items()):
        lines.append('  ' + json.dumps(name) + ': ' + json.dumps(item, ensure_ascii=False, allow_nan=False) + (',' if index + 1 < len(value) else ''))
    with Path(path).open('x', encoding='utf-8') as out: out.write('\n'.join(lines + ['}']) + '\n')
def non_time(value):
    if isinstance(value, list): return [non_time(item) for item in value]
    if isinstance(value, dict): return {name: non_time(item) for name, item in value.items() if not any(word in name for word in ('seconds', 'per_second', 'clock_unix', 'unix_ns', 'unix_ms'))}
    return value
def triple(stats): return [stats[name] for name in ('median', 'min', 'max')]
def beijing(ns): return datetime.fromtimestamp(ns / 1e9, timezone(timedelta(hours=8))).isoformat(timespec='seconds')


def main():
    assert not OUT.with_suffix('.json').exists() and not OUT.with_suffix('.zip').exists(), 'Never replace a released package'
    summary = read(W / 'summary.json'); plan = read(W / 'window-plan.json'); build = read(W / 'build-plan.json')
    ready = read(W / 'ready-model.json'); control = read(BASE / 'ready-model.json'); binding = read(W / 'binding.json')
    assert summary['status'] == 'COMPLETE16_SINGLE_TURN_STRICT_INTRA_HYLE_STABLE'
    assert (summary['processes'], summary['timing_processes'], summary['independent_memory_processes']) == (16, 12, 4)
    for row in (ready, control):
        for name in ('image', 'inputs', 'recipe', 'runtime', 'source_freeze'): exact(row[name])
        for name in ('snapshot', 'command', 'dependencies', 'actual_dependencies'): exact(row['compiled'][name])
        assert row['compiled']['process']['exit'] == row['process']['exit'] == 0
    assert control['image']['sha256'] == '2c0f942325ebf2bd7c2db155d7dea03049166b6fd1f189637dccb42d18ca42f2'
    assert ready['image']['sha256'] == 'dfa9157eecff70fefec6bf370fb189690dff4ab4d6a4f4477656cc14ca981b57'
    before, after = read(control['inputs']['path']), read(ready['inputs']['path'])
    assert len(before) == len(after) == len({key(row['path']) for row in after}) == 229
    changes = [dict(control=a, candidate=b) for a, b in zip(before, after) if a != b]
    assert changes == binding['replacements'] and len(changes) == 3 and binding['retained_objects'] == 226
    expected = {key(row['original']['path']): key(row['replacement']) for row in build['replacements'].values()}
    assert all(expected[key(row['control']['path'])] == key(row['candidate']['path']) for row in changes)
    assert read(ready['runtime']['path'])['native'] == read(control['runtime']['path'])['native']
    for name in ('resources', 'slots-region'):
        record = ready['graph'][name]; exact(record['receipt'])
        assert record['compiled']['process']['exit'] == 0
    exact(plan['script']); exact(plan['binding'])
    assert set(read(W / 'environment.json')) == {'PATH', 'INCLUDE', 'LIB', 'LIBPATH'}
    processes = []; reports = {}; work = {}; groups = {}
    for group_entry in plan['groups']:
        exact(group_entry['plan']); cfg = read(group_entry['plan']['path'])
        name = '-'.join((group_entry['scenario'], group_entry['role'], group_entry['mode']))
        assert name in GROUPS
        group = read(W / name / 'summary.json'); runs = read(W / name / 'runs.json')
        assert group['status'] == 'COMPLETE_STABLE' and group['complete_non_time_differences'] == []
        assert all(v['stable'] for v in group['within_variant_complete_non_time'].values())
        assert len(runs) == len(cfg['commands']) == (6 if group_entry['mode'] == 'timing' else 2)
        groups[name] = group
        for row, command in zip(runs, cfg['commands']):
            folder = Path(row['folder']); process = read(folder / 'result.json'); raw = read(folder / 'consumer-result.json')
            assert process == row['process'] and raw == row['observation']['raw']
            assert process['exit'] == 0 and not any(process.get(k) for k in ('timeout', 'timed_out', 'reader_errors'))
            assert process['command'] == command['command'] and process['image'] == command['image']
            assert process['memory_only'] == (group_entry['mode'] == 'memory')
            assert raw['generated_tokens'] == raw['requested_output_tokens'] == 64 and len(raw['generated_ids']) == 64
            assert raw['live_committed_versions'] == 0 and raw['cold_exact_admissions'] == 0
            assert raw['decode_overlap'] == (row['role'] == 'ordinary')
            if row['role'] == 'ordinary': assert 0 < raw['overlap_successor_publications'] <= raw['overlap_successor_submissions']
            else: assert raw['overlap_successor_submissions'] == 0 and raw['accepted_drafts'] == 29
            p, d, s = (raw[key] for key in ('prefill_seconds', 'decode_seconds', 'session_seconds'))
            assert all(math.isfinite(v) and v > 0 for v in (p, d, s)) and math.isclose(p+d, s, rel_tol=1e-5, abs_tol=2e-6)
            assert read(folder / 'timing-partition-gate.json')['status'] == 'PASS'
            reports[str(folder)] = raw
            processes.append(dict(ordinal=command['window_ordinal'], role=row['role'], variant=row['variant'], mode=group_entry['mode'],
                pid=process['pid'], exit=process['exit'], started_unix_ns=process['started_unix_ns'], finished_unix_ns=process['finished_unix_ns'],
                report=pin(folder / 'consumer-result.json'), raw_process=pin(folder / 'result.json')))
        for variant in ('control', 'candidate'):
            selected = [r for r in runs if r['variant'] == variant]
            facts = [non_time(reports[r['folder']]) for r in selected]
            assert all(value == facts[0] for value in facts)
            peer_variant = [non_time(reports[r['folder']]) for r in runs if r['variant'] != variant]
            assert all(value == facts[0] for value in peer_variant)
            if group_entry['mode'] == 'timing':
                for metric, stats in group['groups'][variant].items():
                    values = [r['observation']['metrics'][metric] for r in selected if r['observation']['metrics'][metric] is not None]
                    if stats is None: assert not values; continue
                    assert stats['count'] == len(values)
                    if values:
                        assert all(math.isclose(stats[label], value, rel_tol=1e-12) for label, value in
                            (('median', statistics.median(values)), ('min', min(values)), ('max', max(values))))
    processes.sort(key=lambda r: r['ordinal'])
    assert len(processes) == len({r['pid'] for r in processes}) == len({r['ordinal'] for r in processes}) == 16
    assert all(a['finished_unix_ns'] <= b['started_unix_ns'] for a, b in zip(processes, processes[1:])), 'Native processes overlapped'
    for role in ('ordinary', 'mtp'):
        selected = [r for r in processes if r['role'] == role]
        facts = [non_time(read(r['report']['path'])) for r in selected]
        assert all(value == facts[0] for value in facts), 'Keep timing/memory work exactly aligned'
        raw = read(selected[0]['report']['path'])
        work[role] = {key: raw[key] for key in ('generated_tokens', 'generated_decode_tokens', 'actual_graph_calls', 'prefill_graph_calls',
            'decode_graph_calls', 'actual_target_rows', 'actual_draft_rows', 'prefill_target_rows', 'packed_prefill_calls',
            'overlap_successor_submissions', 'overlap_successor_publications', 'overlap_successor_discards', 'overlap_successor_refusals')}
        work[role].update(accepted_drafts=raw['accepted_drafts'] if role == 'mtp' else None, all64_output_IDs_equal_across_variants=True)
    amendment = read(W / 'summary-amendment.json')
    for name in ('script', 'frozen_script', 'frozen_plan', 'original_failure', 'preserved_failure'): exact(amendment[name])
    assert amendment['model_reruns'] == amendment['native_failures'] == 0
    table = []
    for row in summary['table']:
        timing, memory = row['timing'], row['memory']
        table.append(dict(role=row['role'], variant=row['variant'], **{name: triple(timing[name]) for name in METRICS},
            startup_to_ready_seconds=triple(timing['startup_to_ready_seconds']) if timing.get('startup_to_ready_seconds') is not None else None,
            independent_memory=memory))
    receipt = dict(schema='hyle.performance.store-cohort-current-window.v1', status=summary['status'],
        processes=dict(native=16, first_attempt_exit0=16, native_failures=0, native_reruns=0, timing=12, independent_memory=4,
            extra_Model_CXX=1, extra_CLI_links=1, SDK_CXX_in_this_performance_build=0, NVCC=0, downloads=0),
        window=dict(started_beijing=beijing(processes[0]['started_unix_ns']), finished_beijing=beijing(processes[-1]['finished_unix_ns']),
            protocol='P154/C1024/R1, single turn, greedy,64 natural outputs; ordinary auto and MTP K1 overlap-off', timing_order=['control','candidate','candidate','control','control','candidate'],
            historical_samples_pooled=False, peer_processes=0, warmup_processes=0),
        identity=dict(control=control['image'], candidate=ready['image'], current_Model=ready['compiled']['source'],
            control_ready=pin(BASE/'ready-model.json'), candidate_ready=pin(W/'ready-model.json'), closure_inputs_each=229,
            exact_replacements=changes, unchanged_inputs=226, runtime=ready['runtime'], parent_source_freeze=pin(ROOT/'final-source-freeze.json')),
        table_array_order=['median','min','max'], table=table, current_window_median_delta_percent=summary['within_window_comparison'],
        consistency=dict(all16_complete_producer_non_time_reports_equal_within_role=True, additional_field_whitelist=[],
            full_IDs_and_actual_work_preserved=True, measured_work=work, summary=pin(W/'summary.json'), native_process_index=pin(W/'process-index.json') if (W/'process-index.json').exists() else None),
        metadata_repair=dict(first_summary_failure=pin(W/'summary-attempt1.log'), amendment=pin(W/'summary-amendment.json'),
            scope='Ordinary lacks MTP accepted_drafts; null is not applicable. MTP remains strict. All16 native and strict group analyses had already succeeded; frozen runner/plans/raw unchanged.'),
        boundaries=['Three timing plus one independent memory per role/variant; median/range descriptions only. All performance ranges overlap; no significance claim.',
            'This compares the joint current Store batch-take/ordinary ProgramIo change against fresh control2c0f in the same window; it does not isolate either change or prove a host-bucket cause.',
            'No new peer, B2, two-turn, trained quality, other-platform or unknown-native-failure claim.',
            'Original complete producer endpoints and requested10ms PSAPI/PDH sampler remain; actual gaps/null counts retained. All four ready baselines are unknown, never zero-filled.',
            'Dedicated/shared sampled VRAM and process RAM are separate; peaks are lower bounds and logical Graph backing is not physical VRAM peak.'])
    save(W / 'process-index.json', processes)
    receipt['consistency']['native_process_index'] = pin(W/'process-index.json')
    allowed = {'.json','.py','.log','.txt','.csv','.cc','.h','.patch'}
    skip = {'package-manifest.json','package-result.json','evidence-summary.json'}
    paths = {p.resolve() for p in W.rglob('*') if p.is_file() and p.suffix.lower() in allowed and p.name not in skip and '__pycache__' not in p.parts}
    # Only these two reused new Graph receipts/dependency records/source facts;
    # no whole SDK tree, binary or unrelated functional runs are copied.
    for name in ('resources','slots-region'):
        for directory in (ROOT/'compile'/name, ROOT/'logs'/name):
            paths.update(p.resolve() for p in directory.iterdir() if p.is_file() and p.suffix.lower() in allowed)
        paths.add((ROOT/'recipes'/f'{name}.json').resolve())
    paths.update((ROOT/name).resolve() for name in ('final-source-freeze.json','frozen-project-dependencies.json','final-build-plan.json','product.patch'))
    frozen = read(ROOT/'final-source-freeze.json')
    for pair in frozen['snapshots']:
        relative = Path(pair['original']['path']).relative_to(R)
        if relative.parts[0] in ('src','include','engine') and relative.as_posix() != 'engine/models/qwen35/main.cc':
            exact(pair['snapshot']); paths.add(Path(pair['snapshot']['path']))
    for value in (control['inputs'], pin(BASE/'ready-model.json'), pin(BASE/'source-freeze.json'), pin(BASE/'window.py'),
        pin(BASE/'plan.json'), pin(BASE/'binding.json'), pin(R/'docs/evidence/performance/inference-review-current-window-2026-10-28.json')):
        paths.add(Path(value['path']))
    paths.add(Path(control['compiled']['snapshot']['path']))
    paths.add(Path(control['compiled']['actual_dependencies']['path']))
    for entry in plan['groups']:
        cfg = read(entry['plan']['path'])
        paths.update(Path(row['path']) for row in cfg.get('helpers',[]))
    for key_name in ('prompt','input_manifest','schedule','protocol'):
        value = binding['work'][key_name]
        if isinstance(value,dict) and 'path' in value: paths.add(Path(value['path']))
    paths = {p.resolve() for p in paths}
    assert all(p.is_file() and p.is_relative_to(R) and p.suffix.lower() not in FORBIDDEN and p.stat().st_size < 5*1024*1024 for p in paths)
    manifest = [dict(member=p.relative_to(R).as_posix(), **pin(p)) for p in sorted(paths)]
    save(W/'package-manifest.json',dict(files=manifest, policy='Raw16 reports/commands/logs and independent sampler records; actual source/recipes/dependency/closure pins only. No SDK, weights or binary payload.'))
    compact(W/'evidence-summary.json',receipt)
    OUT.parent.mkdir(parents=True,exist_ok=True)
    archive=OUT.with_suffix('.zip')
    with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for row in manifest: z.write(row['path'],row['member'])
        for p in (W/'package-manifest.json',W/'evidence-summary.json'):z.write(p,p.relative_to(R).as_posix())
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None and len(z.namelist()) == len(manifest)+2
        assert not any(Path(name).suffix.lower() in FORBIDDEN for name in z.namelist())
        for row in manifest:
            data=z.read(row['member']);assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256']
        assert read(W/'evidence-summary.json') == json.loads(z.read((W/'evidence-summary.json').relative_to(R).as_posix()))
        uncompressed=sum(row.file_size for row in z.infolist())
    receipt['archive']=dict(**pin(archive),members=len(manifest)+2,uncompressed_bytes=uncompressed,CRC_and_every_payload_SHA256_verified=True)
    receipt['manifest']=pin(W/'package-manifest.json')
    compact(OUT.with_suffix('.json'),receipt);assert read(OUT.with_suffix('.json')) == receipt
    result=dict(status='PACKAGED_AND_READ_BACK_VERIFIED',receipt=pin(OUT.with_suffix('.json')),archive=receipt['archive'],native_processes_started=0)
    save(W/'package-result.json',result);print(json.dumps(result))


if __name__ == '__main__': main()
