// Fixed two-original-W leaf. No Lt calls, W packing, SwiGLU, or new kernel math.
#include "mmvf.cuh"
#include <cstdint>
#include <initializer_list>
#include <limits>

namespace {
constexpr int K = 2048, N = 6144, M = 2, Block = 256;
constexpr std::size_t WeightBytes = std::size_t(N) * K * sizeof(nv_bfloat16);
constexpr std::size_t InputBytes = std::size_t(M) * K * sizeof(nv_bfloat16);
constexpr std::size_t OutputBytes = std::size_t(M) * N * sizeof(nv_bfloat16);

bool span_valid(const void *pointer, std::size_t bytes) noexcept {
    const auto begin = reinterpret_cast<std::uintptr_t>(pointer);
    return pointer && (begin & 15) == 0 &&
        begin <= std::numeric_limits<std::uintptr_t>::max() - bytes;
}
bool overlaps(const void *a, std::size_t na, const void *b, std::size_t nb) noexcept {
    const auto x = reinterpret_cast<std::uintptr_t>(a);
    const auto y = reinterpret_cast<std::uintptr_t>(b);
    return x < y + nb && y < x + na;
}
}

extern "C" int hyle_m2_pair_configure() noexcept {
    // Cold materialization/capability check, never performed under capture.
    cudaFuncAttributes attributes{};
    const auto status = cudaFuncGetAttributes(&attributes,
        mul_mat_vec_f<nv_bfloat16, float, M, Block, true, false,
            nv_bfloat16, nv_bfloat16, void, false, true>);
    if (status != cudaSuccess) return int(status);
    return attributes.maxThreadsPerBlock >= Block
        ? int(cudaSuccess) : int(cudaErrorInvalidConfiguration);
}

extern "C" int hyle_m2_pair_launch(const void *w0, const void *w1,
    const void *activation, void *output0, void *output1, void *stream) noexcept {
    if (!stream || !span_valid(w0, WeightBytes) || !span_valid(w1, WeightBytes) ||
        !span_valid(activation, InputBytes) || !span_valid(output0, OutputBytes) ||
        !span_valid(output1, OutputBytes) || overlaps(output0, OutputBytes, output1, OutputBytes))
        return int(cudaErrorInvalidValue);
    for (const auto *output : {output0, output1}) {
        if (overlaps(output, OutputBytes, w0, WeightBytes) ||
            overlaps(output, OutputBytes, w1, WeightBytes) ||
            overlaps(output, OutputBytes, activation, InputBytes))
            return int(cudaErrorInvalidValue);
    }
    const auto one = init_fastdiv_values(1);
    ggml_cuda_mm_fusion_args_device fusion{};
    fusion.gate = w1;
    // One CTA per output column, four independent F32 dot sums. The unchanged
    // body loads each W0/W1 BF16 pair before its M loop, and each A pair once
    // per M iteration for BOTH projections. Neither W is concatenated/copied.
    mul_mat_vec_f<nv_bfloat16, float, M, Block, true, false,
        nv_bfloat16, nv_bfloat16, void, false, true>
        <<<dim3(N, 1, 1), dim3(Block, 1, 1), 2 * 32 * sizeof(float),
           reinterpret_cast<cudaStream_t>(stream)>>>(
            static_cast<const nv_bfloat16 *>(w0),
            static_cast<const nv_bfloat16 *>(activation), nullptr, fusion,
            static_cast<nv_bfloat16 *>(output0), K / 2, one, K, K / 2, N,
            one, N * K, M * K, M * N,
            one, N * K, M * K, M * N,
            0, static_cast<nv_bfloat16 *>(output1));
    return int(cudaGetLastError());
}
