"""Offline bounded leaf evidence; never runs native work or deletes files."""
from pathlib import Path
import hashlib
import json
import re
import statistics
import zipfile

W = Path(__file__).resolve().parent
R = W.parents[1]

def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))

def pin(path):
    return {'relative_repository_path': path.relative_to(R).as_posix(),
        'bytes': path.stat().st_size, 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}

def save(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8')

raw = read(W / 'run/stdout.log')
assert raw['passed'] and read(W / 'run/process.json')['exit'] == 0
assert raw['trials'] == 5 and raw['pair_bank_count'] == 4
plan = read(W / 'plan.json')
choices = raw['choices']
stats = []
for choice in choices:
    record = {'kind': choice['kind']}
    for field in ('device_ms_per_pair', 'host_ms_per_pair'):
        values = choice[field]
        assert len(values) == 5
        record[field] = {'all': values, 'median': statistics.median(values),
            'min': min(values), 'max': max(values)}
    stats.append(record)
control = choices[0]['device_ms_per_pair']
candidate = choices[1]['device_ms_per_pair']
median_delta = (statistics.median(candidate) / statistics.median(control) - 1) * 100
overlap = max(min(control), min(candidate)) <= min(max(control), max(candidate))
assert median_delta > 0 and overlap

dependencies = (W / 'native/dependencies.d').read_text(encoding='utf-8')
native_files = []
for line in dependencies.splitlines():
    text = line.strip().removesuffix('\\').strip().replace('\\ ', ' ')
    if text.lower().startswith('c:/public/project-hyle/hyle/'):
        path = Path(text)
        if path.is_file() and path not in native_files:
            native_files.append(path)
assert W / 'source/mmvf.cuh' in native_files
assert not any(path.name == 'mmvf.cuh' and path != W / 'source/mmvf.cuh' for path in native_files)
source_pins = [pin(path) for path in native_files]
save(W / 'actual-native-source-pins.json', source_pins)
warnings = {}
for stage in ('host', 'native', 'link'):
    merged = '\n'.join((W / stage / name).read_text(errors='replace')
        for name in ('stdout.log', 'stderr.log'))
    kinds = {}
    for code in re.findall(r'warning (C\d+)', merged):
        kinds[code] = kinds.get(code, 0) + 1
    warnings[stage] = {'msvc_warning_occurrences': kinds,
        'original_stdout': pin(W / stage / 'stdout.log'),
        'original_stderr': pin(W / stage / 'stderr.log')}

cleanup = [pin(path) for folder in ('host', 'native', 'link')
    for path in sorted((W / folder).iterdir())
    if path.is_file() and path.suffix.lower() in {'.obj', '.exe', '.pdb', '.exp', '.lib', '.map'}]
save(W / 'cleanup-candidates.json', {'state': 'PROPOSED_NOT_DELETED',
    'count': len(cleanup), 'logical_bytes': sum(item['bytes'] for item in cleanup), 'files': cleanup,
    'preserve': 'All source, original inputs/weights, retained SDK/cache, commands, results and logs.'})
summary = {
    'status': 'CLOSED_NOT_MERGED',
    'decision': 'Numeric leaf gates passed, but candidate median pair latency is higher and sample ranges overlap. Stop after this one authorized leaf process.',
    'scope': plan['scope'],
    'actual_processes': {'CUDA_compile_TUs': 1, 'host_compile_TUs': 1, 'links': 1,
        'native_leaf_processes': 1, 'trials_per_arm': 5, 'pair_banks': 4,
        'Model_processes': 0, 'profilers': 0, 'SDK_builds': 0, 'HTTP': 0},
    'source_pins': pin(W / 'source-pins.json'),
    'actual_compilation_sources': pin(W / 'actual-native-source-pins.json'),
    'plan': pin(W / 'plan.json'), 'hardware_toolchain': pin(W / 'toolchain.json'),
    'original_inputs': {'manifest': plan['manifest'], 'roles': plan['original_roles'],
        'activation': plan['activation'], 'build_verification': read(W / 'build-inputs.json')['inputs']},
    'math': {'inputs_weights_outputs': 'BF16 A/W0/W1/Y0/Y1', 'dot_accumulators': 'F32',
        'oracle': plan['oracle'], 'direct_and_captured_checks_each_before_any_timing': True,
        'distinct_values_per_role': 12288, 'roles': 2,
        'baseline_vs_candidate_BF16_different': choices[1]['BF16_values_different_from_baseline'],
        'bitwise_equal_claimed': False, 'new_tolerance_or_oracle_used': False,
        'max_absolute_error': None,
        'max_absolute_error_reason': 'Original unchanged oracle reports pass/fail intervals only, not maximum error.'},
    'numeric_sequence_correction': {
        'before': pin(W / 'before-pretime-numeric/pins.json'),
        'after': pin(W / 'source-pins.json'), 'delta': pin(W / 'pretime-numeric.patch'),
        'change': 'First captured replay plus both-role readback now occurs before every timed trial. Adds one explicit untimed 64-pair graph replay per arm; five timed replays per arm unchanged.',
        'oracle_text_normalized_equal': plan['oracle']['normalized_source_text_equal']},
    'results': {'all_trials': stats,
        'candidate_device_median_latency_change_percent': median_delta,
        'device_sample_ranges_overlap': overlap,
        'same_trial_latency_change_percent': [(a / b - 1) * 100 for a, b in zip(candidate, control)],
        'baseline_graph_nodes': choices[0]['captured_graph_nodes'],
        'candidate_graph_nodes': choices[1]['captured_graph_nodes'],
        'raw': raw, 'process': read(W / 'run/process.json')},
    'warnings': warnings,
    'preparation_failures': [{
        'stage': 'offline source preparation, before any build/run',
        'detail': 'First original/new helper text equality assertion differed at a newline slicing boundary. Slice boundary corrected; F64 oracle arithmetic/operators/constants unchanged and normalized source hash equal.',
        'native_or_compile_failure': False}],
    'native_compile_or_runtime_failures': [],
    'boundaries': [
        'A is the retained real-model layer0 post-attention normalization first two prefill rows, not a freshly captured current verifier T2.',
        'Four pair rotations are 192MiB bounded leaf copies and exceed twice actual 36MiB L2; no PMU/cache-miss/DRAM-saving claim.',
        'cuBLASLt version is observed as 130600; loaded DLL absolute path is not established.',
        'Independent original fixed F64/F32-FTZ/BF16-RNE interval oracle passes; 13 gate and 12 up outputs differ in BF16 bits from Lt.',
        'Current Graph/provider/native pair eligibility remains M1/small-N; no capability/owner/capture/public ABI admission is implemented.',
        'No Model IDs, continuation quality, end-to-end speed, or public capture/owner authority is certified.',
        'Fewer graph nodes alone are not a performance result. Negative/overlapping leaf closes without further experiments.'
    ],
    'cleanup': read(W / 'cleanup-candidates.json'),
}
save(W / 'proof-summary.json', summary)

include = [path for path in W.rglob('*') if path.is_file()
    and path.suffix.lower() not in {'.obj', '.exe', '.pdb', '.exp', '.lib', '.map', '.zip'}
    and path.name not in {'proof-archive.json'} and '__pycache__' not in path.parts]
archive = W / 'proof.zip'
with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as out:
    for path in sorted(include):
        out.write(path, path.relative_to(W).as_posix())
with zipfile.ZipFile(archive) as source:
    assert source.testzip() is None
    members = len(source.infolist())
save(W / 'proof-archive.json', {'archive': pin(archive), 'members': members,
    'CRC_check': 'PASS', 'summary': pin(W / 'proof-summary.json')})
print(json.dumps({'status': summary['status'], 'median_latency_change_percent': median_delta,
    'overlap': overlap, 'archive': pin(archive), 'members': members,
    'cleanup_count': len(cleanup), 'cleanup_logical_bytes': sum(item['bytes'] for item in cleanup)}))
