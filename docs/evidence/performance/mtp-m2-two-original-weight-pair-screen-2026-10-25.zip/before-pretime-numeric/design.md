# Fixed M2, same A, two original BF16 weights — private leaf proposal

State: source/commands only. No compilation, CUDA process, download or canonical edit. `plan.json` carries exact source/input/closure pins and future commands; none is executed automatically.

## Actual shared mechanism

The original `mmvf.cuh` kernel already accepts template `ncols_dst=2`. Its BF16 loop loads W0 and W1 before the two-A-row loop, then loads one A pair per row and applies it to both independent F32 accumulators. The four sums reuse the original warp/CTA reduction and each output has its original final BF16 RN store. This is one CTA per output column and one launch for both projections, not a wrapper around two Lt calls or two independent M1 calls.

The original paired-output branch is only asserted for `ncols_dst==1`. The sole private header change admits 1 or 2 in that assertion. The fixed leaf directly instantiates the existing body at M2/K2048/N6144/256threads and paired-output=true. It does **not** relax the generic launcher's separate row1 assertion or any native/Graph matcher. No loop math is copied or changed; no SwiGLU, product, packed W, F32 shadow or second persistent Model bank is introduced.

This is source-level reuse. W bytes are still read for both original matrices. Lt already reuses data with its own tiling, so no factor-two weight/DRAM saving is claimed. Four simultaneous partial sums may increase registers/spills; actual benefit is unknown. Previous negative single-W MMVF and Lt screens remain closed.

## Current capability and safety boundary

- `ggml_cuda_region.cc:404–454` requires dense BF16 rank2 A/Y with exactly one token row; the RHS is a metadata transpose of contiguous original [N,K]. Two outputs may both be published/externally read; existing contraction/placement proof remains authoritative.
- Native `ggml_cuda_supports_bf16_paired_matvec` also requires one row, exact same A tensor identity, equal W/output shapes and F32 precision. The existing bridge capability takes K/N, not M; it must not be advertised as proof of M2 support.
- The actual geometry helper (`ggml-cuda.cu:839–859`) additionally restricts **N ≤ device.nsm**, NVIDIA fast-BF16, warp32, grid limits, ≥256 threads and ≥256B shared memory. Thus N6144 is outside the existing **small-N two-output pair** even for M1. The complete-FFN carrier has a separate domain. A winning leaf would require an explicit M2/large-N capability, while preserving the old M1/small-N policy; it cannot silently bypass these gates.
- This private leaf uses only exact [2,2048], two separate [6144,2048] original weights and two separate [2,6144] outputs. It rejects null, misaligned, overflowing or overlapping writable/readable spans. Both original weights may share readonly storage, but outputs may not overlap each other or inputs.
- The owner is the ordinary leaf Device: original buffers, stream, graphs and events remain alive through actual stream/event retirement. This proves no Model/ReadLease/native-owner integration. A future winning product proposal would need coordinated cold capability, bound matcher/encoder and allocation-dependency terminal proof; changing only Graph's row predicate would be incorrect.
- Candidate global workspace: **0**; dynamic shared scratch: **256 bytes/CTA**. A cold `cudaFuncGetAttributes` resolves the exact kernel before capture. Submit does no allocation, algorithm selection or synchronization. Baseline keeps its original caller-owned **32MiB** cap and two serial queue-ordered Lt submissions.

## Original inputs and mathematical gate

- Exact source roles are layer0 gate/up BF16 [6144,2048], each 25,165,824 bytes, at original offsets 1084498960 and 1109664784. Range SHA256 is recorded after bounded reads from the existing source file; no weight payload is copied into this batch.
- A is the retained original layer0 post-attention-norm T23 trace's first two rows [2,2048], SHA `394e94f2aa1eddf2820e132cfb8615de3a1b54fd80f64571207446bd9811df0a`. It is **not** a newly acquired current T2 verifier activation.
- The previous independent F64 dot / fixed gamma(2K+4) F32+FTZ / outward BF16 RNE interval function is text-identical after newline normalization. Call it separately for gate and up: **12,288 outputs per role, 24,576 per choice**. No baseline-output oracle or tolerance adjustment.
- The original finite normal/zero operand and finite/non-subnormal result domain is retained. Passing this leaf would not certify every nonfinite/general provider domain or model token identity.

## Fair, bounded screen if separately authorized

Four pair slots contain the same two original roles: **192MiB total working set** shared by both choices, checked to exceed twice actual L2. These are bounded leaf cache-rotation copies, not another Model bank. No PMU cold-miss claim. Both arms use the same A, role pair, two independent outputs and source layout.

One captured graph holds **64 pair jobs**: baseline performs 128 original Lt projections; candidate performs 64 paired launches. Report time **per pair**, not per single projection. Reuse the original five-trial rotating order, exact BF16/F32 layouts, request1 Lt choice/reduction policy and workspace cap. Numeric Direct and the first captured replay check both outputs; readback is outside timing endpoints. Baseline node count is observed rather than falsely requiring one kernel per Lt call; candidate must have one fixed node per pair.

Numeric failure stops before timing. Negative/overlapping leaf intervals close this direction without a model or profiler. A positive leaf would still require separately authorized same-work consumer/state/capture validation, never an automatic performance claim.

Preparation correction: the first source-builder comparison used inconsistent trailing-newline slice boundaries for the unchanged oracle and stopped before compilation; aligning the text boundaries corrected the check. No kernel/oracle arithmetic was changed to satisfy it.
