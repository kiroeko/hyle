"""One authorized fixed-shape paired-projection leaf build/run; no SDK build."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import datetime
import difflib
import hashlib
import importlib.util
import json
import os
import subprocess
import sys

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = W.parents[1]
spec = importlib.util.spec_from_file_location('retained_build', R / '.scratch/mtp-extraction-regression-20261024/check.py')
b = importlib.util.module_from_spec(spec)
spec.loader.exec_module(b)

def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))

def checked_pin(item):
    path = Path(item['path'])
    if not path.is_absolute():
        path = R / path
    actual = b.pin(path)
    if actual['bytes'] != item['bytes'] or actual['sha256'] != item['sha256']:
        raise RuntimeError('Source/input pin mismatch: ' + str(path))
    return actual

def refresh_pins():
    pins = read(W / 'source-pins.json')
    for category in ('private_candidate', 'product_or_retained_reference_inputs'):
        for item in pins[category]:
            path = Path(item['path'])
            if not path.is_absolute():
                path = R / path
            actual = b.pin(path)
            item.update(bytes=actual['bytes'], sha256=actual['sha256'])
    pins['status'] = 'PRETIME_CAPTURE_NUMERIC_CORRECTED_BEFORE_FIRST_BUILD'
    pins['pretime_numeric_before'] = str((W / 'before-pretime-numeric/pins.json').relative_to(R))
    b.save(W / 'source-pins.json', pins)
    delta = []
    for name in ('leaf_body.inc', 'm2_pair_leaf.cc', 'design.md', 'plan.json'):
        old = (W / 'before-pretime-numeric' / name).read_text(encoding='utf-8')
        new = (W / name).read_text(encoding='utf-8')
        delta.extend(difflib.unified_diff(old.splitlines(True), new.splitlines(True),
            fromfile='before-pretime-numeric/' + name, tofile=name))
    (W / 'pretime-numeric.patch').write_text(''.join(delta), encoding='utf-8')

def input_checks(plan):
    checked_pin(plan['activation']['full_trace'])
    checked_pin(plan['manifest'])
    activation = Path(plan['activation']['full_trace']['path']).read_bytes()[:8192]
    if hashlib.sha256(activation).hexdigest() != plan['activation']['selected_sha256']:
        raise RuntimeError('Selected real activation mismatch')
    for role in plan['original_roles']:
        item = role['range']
        path = Path(item['path'])
        if path.stat().st_size != role['source_file_bytes']:
            raise RuntimeError('Original safetensors file length changed')
        with path.open('rb') as stream:
            stream.seek(item['offset'])
            value = stream.read(item['bytes'])
        if len(value) != item['bytes'] or hashlib.sha256(value).hexdigest() != item['sha256']:
            raise RuntimeError('Original role range changed: ' + role['name'])
    return {'state': 'PASS', 'bounded_original_role_bytes_hashed': 50331648,
        'selected_activation_bytes': len(activation), 'full_model_hash_claimed': False}

def build():
    refresh_pins()
    plan = read(W / 'plan.json')
    checks = input_checks(plan)
    for item in plan['sources'].values():
        checked_pin(item)
    checked_pin(plan['after_header'])
    for item in plan['retained_link_inputs']:
        checked_pin(item)
    checked_pin(plan['runtime'])
    env = b.environment(plan['commands']['host'][0])
    queries = []
    for command in ([plan['commands']['native'][0], '--version'],
        ['nvidia-smi', '--query-gpu=name,driver_version,memory.total', '--format=csv,noheader'],
        [plan['commands']['host'][0]]):
        result = subprocess.run(command, cwd=R, env=env, capture_output=True, text=True,
            creationflags=subprocess.CREATE_NO_WINDOW, timeout=20)
        queries.append({'command': command, 'exit': result.returncode,
            'stdout': result.stdout, 'stderr': result.stderr})
    b.save(W / 'toolchain.json', {'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'queries': queries})
    b.save(W / 'build-inputs.json', {'inputs': checks,
        'sources': [b.pin(Path(item['path'])) for item in plan['sources'].values()],
        'private_header': b.pin(Path(plan['after_header']['path'])),
        'compile_tus': 2, 'SDK_builds': 0, 'HTTP': 0})
    # Independent compilation only; every process retains its own command/log/result.
    with ThreadPoolExecutor(max_workers=2) as executor:
        futures = [executor.submit(b.execute, plan['commands'][name], W / name, env, 240)
            for name in ('host', 'native')]
        for future in futures:
            future.result()
    b.execute(plan['commands']['link'], W / 'link', env, 120)
    b.save(W / 'build-ready.json', {'state': 'BUILT_NOT_RUN',
        'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'image': b.pin(W / 'link/paired-leaf.exe'), 'inputs': checks,
        'host_object': b.pin(W / 'host/probe.obj'), 'native_object': b.pin(W / 'native/pair.obj'),
        'source_after': [b.pin(Path(item['path'])) for item in plan['sources'].values()],
        'no_product_mutation': True})

def run():
    plan = read(W / 'plan.json')
    ready = read(W / 'build-ready.json')
    checked_pin(ready['image'])
    for item in ready['source_after']:
        checked_pin(item)
    checked_pin(plan['after_header'])
    env = b.environment(plan['commands']['host'][0])
    runtime = read(Path(plan['runtime']['path']))
    env.update({key: value for key, value in runtime.items() if isinstance(value, str)})
    env.update(HF_HUB_OFFLINE='1', TRANSFORMERS_OFFLINE='1')
    b.execute(plan['commands']['run'], W / 'run', env, 120)

if __name__ == '__main__':
    {'build': build, 'run': run}[sys.argv[1]]()
