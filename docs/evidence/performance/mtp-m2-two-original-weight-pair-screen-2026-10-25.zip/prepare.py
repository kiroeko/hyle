"""Prepare private two-W M2 leaf and exact pins/commands; no build or CUDA call."""
from pathlib import Path
import csv
import difflib
import hashlib
import json

W = Path(__file__).resolve().parent
R = W.parents[1]
OLD = R / ".scratch/mtp-performance-convergence-20261025/m2-wide-leaf"


def read(p):
    return json.loads(p.read_text())


def sha(data):
    return hashlib.sha256(data).hexdigest()


def pin(p):
    return {"path": str(p), "bytes": p.stat().st_size, "sha256": sha(p.read_bytes())}


def range_pin(p, offset, size):
    digest = hashlib.sha256()
    left = size
    with p.open("rb") as stream:
        stream.seek(offset)
        while left:
            data = stream.read(min(left, 1024 * 1024))
            assert data, "Cached original role is truncated"
            digest.update(data)
            left -= len(data)
    return {"path": str(p), "offset": offset, "bytes": size, "sha256": digest.hexdigest()}


prior = read(OLD / "plan.json")
kernel = Path(prior["owning_kernel"]["path"])
assert pin(kernel) == prior["owning_kernel"]
original = kernel.read_bytes()
needle = b"static_assert(has_fusion && ncols_dst == 1 && !is_multi_token_id && !strict_f32_ids);"
replacement = b"static_assert(has_fusion && (ncols_dst == 1 || ncols_dst == 2) && !is_multi_token_id && !strict_f32_ids);"
assert original.count(needle) == 1
candidate = original.replace(needle, replacement)
for folder, data in (("before", original), ("source", candidate)):
    target = W / folder / "mmvf.cuh"
    target.parent.mkdir(exist_ok=True)
    target.write_bytes(data)
(W / "native-header.patch").write_bytes("".join(difflib.unified_diff(
    original.decode().splitlines(keepends=True), candidate.decode().splitlines(keepends=True),
    fromfile="original/mmvf.cuh", tofile="private/mmvf.cuh")).encode())
host_original = (OLD / "m2_wide_leaf.cc").read_text()
prefix = host_original[host_original.index("#include <cuda.h>"):host_original.index("struct Device {")]
old_entry = 'extern "C" int hyle_mmvf_m2_launch(const void *weight, const void *activation, void *output, void *stream) noexcept;'
assert prefix.count(old_entry) == 1
prefix = prefix.replace(old_entry,
    'extern "C" int hyle_m2_pair_configure() noexcept;\n'
    'extern "C" int hyle_m2_pair_launch(const void *w0, const void *w1, const void *activation, void *y0, void *y1, void *stream) noexcept;')
config = host_original[host_original.index("std::array<std::uint32_t,9> config("):host_original.index("struct Choice {")]
host = "// Private two-original-W M2 pair leaf, not a Model/provider integration.\n" + prefix + config + (W / "leaf_body.inc").read_text()
oracle_start, oracle_end = "double gamma(", "struct Device {"
old_oracle = host_original[host_original.index(oracle_start):host_original.index(oracle_end)]
new_oracle = host[host.index(oracle_start):host.index("std::array<std::uint32_t,9> config(")]
assert old_oracle == new_oracle
(W / "m2_pair_leaf.cc").write_text(host)

manifest = R / ".scratch/qwen35-unsloth-mtp-20261024/geometry-v2-check/original/weights.tsv"
names = ["model.language_model.layers.0.mlp.gate_proj.weight", "model.language_model.layers.0.mlp.up_proj.weight"]
rows = {row[0]: row for row in csv.reader(manifest.read_text().splitlines(), delimiter="\t") if row and row[0] in names}
assert set(rows) == set(names)
roles = []
for name in names:
    row = rows[name]
    assert row[1:5] == ["BF16", "2", "6144", "2048"]
    path, offset, size = Path(row[5]), int(row[6]), int(row[7])
    assert size == 25165824
    roles.append({"name": name, "dtype": "BF16", "shape": [6144, 2048],
                  "source_file_bytes": path.stat().st_size, "range": range_pin(path, offset, size)})
assert roles[0]["range"] == prior["source_weight"]["original_range"]
assert roles[0]["range"]["path"] == roles[1]["range"]["path"]
activation = Path(prior["activation"]["full_trace"]["path"])
assert pin(activation) == prior["activation"]["full_trace"]
with activation.open("rb") as stream:
    selected_activation = stream.read(8192)
assert sha(selected_activation) == prior["activation"]["selected_sha256"]

commands = {}
for tag, source in (("host", W / "m2_pair_leaf.cc"), ("native", W / "m2_pair.cu")):
    command = prior["commands"][tag].copy()
    old_source = prior["sources"][tag]["path"]
    assert command.count(old_source) == 1
    command[command.index(old_source)] = str(source)
    if tag == "host":
        command[command.index("/sourceDependencies") + 1] = str(W / "host/dependencies.json")
        command = ["/Fo" + str(W / "host/probe.obj") if x.startswith("/Fo") else
                   "/Fd" + str(W / "host/probe.pdb") if x.startswith("/Fd") else x for x in command]
    else:
        # The only overridden private header is first; all original pinned
        # native/common/CUDA headers and original arithmetic flags stay intact.
        command.insert(1, "-I" + str(W / "source"))
        for flag, value in (("-MT", W / "native/pair.obj"), ("-MF", W / "native/dependencies.d"), ("-o", W / "native/pair.obj")):
            command[command.index(flag) + 1] = str(value)
        command = ["-Xcompiler=-Fd" + str(W / "native/pair.pdb") + ",-FS" if x.startswith("-Xcompiler=-Fd") else x for x in command]
    commands[tag] = command
link = []
for word in prior["commands"]["link"]:
    if word.upper().startswith(("/OUT:", "/MAP:", "/PDB:", "/IMPLIB:")):
        continue
    if word == str(OLD / "host/probe.obj"):
        word = str(W / "host/probe.obj")
    elif word == str(OLD / "native/typed.obj"):
        word = str(W / "native/pair.obj")
    link.append(word)
assert link.count(str(W / "host/probe.obj")) == link.count(str(W / "native/pair.obj")) == 1
link += ["/OUT:" + str(W / "link/paired-leaf.exe"), "/MAP:" + str(W / "link/paired-leaf.map")]
commands["link"] = link
commands["run"] = [str(W / "link/paired-leaf.exe"), roles[0]["range"]["path"],
                   str(roles[0]["range"]["offset"]), str(roles[1]["range"]["offset"]), str(activation)]
new_objects = {str(W / "host/probe.obj"), str(W / "native/pair.obj")}
retained_inputs = [pin(Path(word)) for word in link if Path(word).is_absolute() and
                   word.lower().endswith((".obj", ".lib")) and word not in new_objects]
plan = {
    "status": "PRIVATE_SOURCE_READY_NOT_COMPILED_NOT_RUN_PENDING_ROOT_REVIEW",
    "scope": "One fixed M2/K2048/N6144 two-original-W leaf; no full FFN/SwiGLU, Model, provider admission, API/ABI or product mutation",
    "shape": {"M": 2, "N": 6144, "K": 2048, "outputs": 2},
    "dtype": "BF16 A/W0/W1/Y0/Y1; four independent F32 dot sums per output-column CTA; one BF16 RN store per result",
    "actual_shared_mechanism": {
        "launches": "one fixed paired-output kernel instead of two ordinary Lt projections",
        "weights": "unchanged original BF16 W0/W1 pointers; each source W pair is loaded before the existing two-A-row loop and reused for both rows",
        "activation": "each existing BF16 A pair is loaded once per token-row iteration and used by both independent projections; no two-Lt wrapper",
        "not_claimed": "Source-level reuse, not measured DRAM/L2 traffic or speed. Lt baseline already has its own tiled reuse, so no claimed factor2 W or DRAM saving. No extra cached/packed Model bank."},
    "workspace": {"candidate_global_bytes": 0, "candidate_dynamic_shared_bytes_per_CTA": 256,
                  "baseline_original_cap_bytes": 33554432, "candidate_threads_per_CTA": 256,
                  "candidate_CTAs": 6144, "cold_materialization": "cudaFuncGetAttributes, before any capture"},
    "owners": "The leaf Device owns both original role buffers, immutable A, separate Y0/Y1 and original stream until actual event/stream retirement. No lease or parent-model lifetime claim; no public capture authority is widened.",
    "capability_boundary": {
        "current_Graph": "bfloat_projection and two-output pair require one token row; native matcher also requires x.ne1==1, and paired_output static_assert currently requires ncols_dst1",
        "current_native_geometry": "ggml-cuda.cu:839-859 also restricts N(output rows)<=device.nsm, grid/thread/shared limits, NVIDIA fast-BF16 and warp32. Actual N6144 is outside that small-N two-output pair capability even for M1; the existing complete-FFN carrier has separate eligibility.",
        "private_delta": "Only one private kernel-body static_assert admits ncols_dst2; fixed direct leaf does not relax the generic native launcher/Graph/provider matchers",
        "future_integration_if_leaf_wins": "Need explicit M2/large-N cold/native capability + matching bound encoder and allocation-dependency/terminal-liveness proof; keep old M1/small-N policy intact. Cannot merely change host row1 predicates or rely on the existing M1 bool capability. No such integration is done here."},
    "original_roles": roles, "manifest": pin(manifest),
    "activation": prior["activation"],
    "oracle": {"source": pin(OLD / "m2_wide_leaf.cc"), "block_sha256": sha(old_oracle.encode()),
               "new_block_sha256": sha(new_oracle.encode()), "normalized_source_text_equal": True,
               "hash_normalization": "UTF8 source text with newline normalization; original math operators and interval constants unchanged",
               "per_choice_outputs": 24576, "per_original_role_outputs": 12288,
               "formula": prior["oracle"], "calls": "same independent helper separately for W0 and W1; no baseline-output oracle/tolerance adjustment",
               "domain": "Original finite normal/zero BF16 operands; bounded F32 partials and finite non-subnormal BF16 final interval, as original oracle"},
    "fair_screen_if_later_authorized": {"pair_bank_count": 4, "physical_24MiB_role_copies": 8,
        "working_set_bytes": 201326592, "exceeds_twice_actual_L2_required": True,
        "note": "These are bounded leaf rotation copies of two existing source roles, not another persistent Model bank. Both choices use the same pairs/activation/outputs; no W packing or F32 shadows.",
        "pair_jobs_per_graph": 64, "projections_per_pair": 2, "trials": 5,
        "choice_order": "Original two-choice rotation by trial", "measure_unit": "time per PAIR, never mislabeled as per single projection",
        "numeric": "Actual direct and one untimed captured graph replay each check every output against each independent oracle before any timing trial; readback/synchronization stay outside all timing endpoints. Five timed graph replays per choice remain unchanged.",
        "baseline": "two original request1 Lt BF16 M2 projections, unchanged layouts/F32 accumulation/reduction preference/32MiB cap; no search for a new Lt algorithm",
        "first_failure": "preserve and stop; numeric failure before timing; negative/overlapping leaf signal closes without Model or extra sampling"},
    "before_header": pin(W / "before/mmvf.cuh"), "after_header": pin(W / "source/mmvf.cuh"),
    "header_patch": pin(W / "native-header.patch"),
    "sources": {"host": pin(W / "m2_pair_leaf.cc"), "native": pin(W / "m2_pair.cu"), "host_body": pin(W / "leaf_body.inc")},
    "source_ancestor": pin(OLD / "plan.json"), "retained_link_inputs": retained_inputs,
    "commands": commands, "runtime": prior["runtime"],
    "compiled_tus": 0, "GPU_processes": 0, "HTTP": 0, "SDK_builds": 0,
    "limits": ["Prepared source only, no syntax compilation or runtime success claimed.",
        "Original A is retained T23 prefill first2 rows, not a newly captured verifier T2 input.",
        "The earlier single-W whole-M2 MMVF/Lt candidate remains closed; this compares two distinct original projections and does not modify that product route.",
        "A positive leaf would not prove model IDs/work/quality, resource binding/capture or end-to-end benefit; those require separately authorized consumer work."]}
(W / "plan.json").write_text(json.dumps(plan, indent=2) + "\n")
print(json.dumps({"plan": str(W / "plan.json"), "state": plan["status"], "oracle_normalized_source_equal": True,
                  "original_roles": roles, "private_header": plan["after_header"]}))
