from pathlib import Path
import difflib,hashlib,json
R=Path.cwd();W=Path(__file__).resolve().parent;P=R/'tests/graph/region_provider_test.cc'
raw=P.read_bytes();before=raw.decode('utf8');private=(W/'source/region_provider_test.cc').read_text()
old='TEST(GraphRegions, NativeInvalidationAndQueueReplacementDiscardCaptureStorage)'
new='TEST(GraphRegions, NativeCommandInvalidationKeepsOnlyRebuildSeedAndQueueStillDiscards)'
a=private.index(new);b=private.index('\nTEST(',a+5);case=private[a:b]
i=before.index(old);j=before.index('\nTEST(',i+5)
line_end='\r\n'if b'\r\n'in raw else'\n'
after=before[:i]+case.replace('\n',line_end)+before[j:]
assert after.replace('\r\n','\n')[after.replace('\r\n','\n').index(new):].split('\nTEST(',1)[0]==case
(W/'canonical-test-before.cc').write_bytes(raw)
P.write_bytes(after.encode('utf8'))
(W/'canonical-test.patch').write_text(''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='before/tests/graph/region_provider_test.cc',tofile='after/tests/graph/region_provider_test.cc')),encoding='utf8')
(W/'canonical-test-bridge.json').write_text(json.dumps(dict(path=P.relative_to(R).as_posix(),private_compiled_case_sha256=hashlib.sha256(case.encode()).hexdigest(),canonical_case_byte_equal_after_lineending_normalization=True,only_original_case_expanded=True,new_test_framework=False,GPU_rerun=False,needs_matching_Graph_candidate_before_test_will_pass=True,sha256=hashlib.sha256(P.read_bytes()).hexdigest()),indent=2)+'\n')
print('CANONICAL_CASE_PORTED_WITHOUT_BODY_CHANGE')
