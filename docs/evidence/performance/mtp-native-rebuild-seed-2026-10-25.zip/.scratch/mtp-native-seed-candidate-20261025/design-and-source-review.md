Candidate: native-argument invalidation retains one nonlaunchable update seed

The current host regression exposed and fixed a necessary detail before GPU use:
native invalidation sets prepared_revision=0; binding preparation would hard-clear
the accepted seed again. The private explicit enum now separates discard,
stable-bindings, native-arguments and keep-existing-only. The last mode is used
only for stable TensorViews with neither old nor new native inputs; it never
recycles active commands. It still clears every key/binding/qualification and
runs the original prepare_bindings and seal.

Safety sources:
- include/hyle/compute/detail/command_capture.h:29-34 explicitly permits a
  backend-authorized idle allocation to survive old binding/provider owners,
  permanently nonlaunchable and forbidden to access old arguments.
- src/graph/region_access.cc:129-136 keeps resource_control_ready before native
  invalidation; src/graph/resources.cc:124-139 rejects running/failed/preparing
  invocation, retained results and unavailable completion observation.
- src/compute_backend_cuda/cuda_backend.cc:1399-1408 permits recycling only a
  unique, nonbusy executable, then sets rebuild_only. :1422 rejects its launch.
  :1312-1354 keeps same-context/unique/nonbusy seed gating and only structural
  CUDA update rejection allows fresh instantiate. No vtable/layout is changed.
- All Queue/config/import/owner hard clears retain the old discard entry;
  repeated native invalidation may keep one previously accepted seed, never old
  launch keys. At most one existing CaptureRebuildStorage per original range.
- CUDA13.3 cuda_runtime_api.h:12826-12912 documents topologically identical
  graph update, context/memory restrictions and native success/failure results.
  Our source keeps the actual result check and structural fallback. Topology
  compatibility of the six native-change recaptures remains unproven here.

Stage/cost and falsification:
- This only targets six direct clears in the measured source-path episode;
  four first records are unavoidable. It does not clone an inactive artifact to
  seed the second variant, does not enlarge variants and cannot erase recording
  or provider planning. The nine empty-variant records are unchanged in policy.
- One host case checks actual retirement rejection, duplicate invalidation,
  zero binding authority, failed seal and hard Queue/config destruction.
- One clean c343-app K1 two-turn process checks IDs/ledger/dispatch/work and
  original capture record/reuse reports. It is not a formal TPS window.
- CUDA API counts in this unprofiled process are UNKNOWN. No seed count is
  relabeled as successful Update. If actual work/correctness changes, stop;
  if no replay-preparation signal or later six updates all structurally fail,
  close this candidate rather than increase cache size or reopen fixed512.
- Prior profiled prepare_replay=107.036554ms is nested full-phase cost, not
  candidate recoverable time. Even the 19 Instantiate API total22.150082ms is
  a separate diagnostic-window sum, not this candidate's gain.
