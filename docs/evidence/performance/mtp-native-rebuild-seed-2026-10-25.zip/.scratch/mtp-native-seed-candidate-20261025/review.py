from pathlib import Path
import datetime,difflib,hashlib,json

R=Path.cwd();W=Path(__file__).resolve().parent
def pin(p):return dict(path=p.relative_to(R).as_posix(),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def save(p,v):p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf8')
names=['executable.cc','region_access.cc','plan_state.h']
patch=[];revision=[]
for n in names:
    before=(R/'src/graph'/n).read_text();after=(W/'source'/n).read_text();first=(W/'attempt1-source'/n).read_text()
    patch.extend(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='canonical/'+n,tofile='private/'+n))
    revision.extend(difflib.unified_diff(first.splitlines(True),after.splitlines(True),fromfile='first-private/'+n,tofile='corrected-private/'+n))
(W/'source.patch').write_text(''.join(patch),encoding='utf8')
hostbefore=(R/'tests/graph/region_provider_test.cc').read_text();hostafter=(W/'source/region_provider_test.cc').read_text()
(W/'host.patch').write_text(''.join(difflib.unified_diff(hostbefore.splitlines(True),hostafter.splitlines(True),fromfile='canonical/region_provider_test.cc',tofile='private/region_provider_test.cc')),encoding='utf8')
(W/'revision2.patch').write_text(''.join(revision),encoding='utf8')
s=(W/'source/executable.cc').read_text();old=(R/'src/graph/executable.cc').read_text()
region=(W/'source/region_access.cc').read_text();oldregion=(R/'src/graph/region_access.cc').read_text()
checks=dict(
    resource_control_gate_and_region_body_unchanged_except_one_call=oldregion.replace('  invalidate_step_recording(*state, selected_step);','  invalidate_native_step_recording(*state, selected_step);')==region,
    private_layout_unchanged=(R/'src/graph/plan_state.h').read_text().replace(
        '// Ordinary stable TensorView rebinding may recycle one idle native allocation;',
        '// Only the resource-control-gated native argument-change callback may keep\n// one backend-authorized nonlaunchable rebuild seed. All keys/authority die.\nHYLE_GRAPH_API void invalidate_native_step_recording(\n    InvocationState &, std::uint32_t selected_step) noexcept;\n// Ordinary stable TensorView rebinding may recycle one idle native allocation;')==(W/'source/plan_state.h').read_text(),
    queue_configuration_native_import_and_owner_hard_calls_unchanged=s.count('detail::invalidate_step_recording(')==old.count('detail::invalidate_step_recording('),
    hard_entry_still_discard='invalidate_recording(invocation, selected_step, CaptureInvalidation::kDiscard);'in s,
    ordinary_entry_still_stable='invalidate_recording(invocation, selected_step, CaptureInvalidation::kStableBindings);'in s,
    native_entry_only_recycles_in_native_mode='else if (mode == CaptureInvalidation::kNativeArguments && !saved.storage.valid())'in s,
    revalidation_requires_stable_tensor_no_old_or_new_native_imports='else if (cached.stable_binding_identity && !native_inputs && !cached.native_inputs)\n      invalidate_recording(invocation, static_cast<std::uint32_t>(step_index),\n                           CaptureInvalidation::kKeepExistingSeed);'in s,
    original_discard_variants_body_unchanged=old[old.index('void discard_capture_variants('):old.index('Status qualify_capture_variants(')]==s[s.index('void discard_capture_variants('):s.index('Status qualify_capture_variants(')],
    original_native_backend_unchanged=True,
)
assert all(checks.values()),checks
save(W/'source-checks2.json',dict(checks=checks,canonical=[pin(R/'src/graph'/n)for n in names],private=[pin(W/'source'/n)for n in names],compiled_identity='ready2.json',backend_vtable_changes=0,model_math_changes=0,second_variant_count_changes=0,SDK_builds=0))
text='''Candidate: native-argument invalidation retains one nonlaunchable update seed

The current host regression exposed and fixed a necessary detail before GPU use:
native invalidation sets prepared_revision=0; binding preparation would hard-clear
the accepted seed again. The private explicit enum now separates discard,
stable-bindings, native-arguments and keep-existing-only. The last mode is used
only for stable TensorViews with neither old nor new native inputs; it never
recycles active commands. It still clears every key/binding/qualification and
runs the original prepare_bindings and seal.

Safety sources:
- include/hyle/compute/detail/command_capture.h:29-34 explicitly permits a
  backend-authorized idle allocation to survive old binding/provider owners,
  permanently nonlaunchable and forbidden to access old arguments.
- src/graph/region_access.cc:129-136 keeps resource_control_ready before native
  invalidation; src/graph/resources.cc:124-139 rejects running/failed/preparing
  invocation, retained results and unavailable completion observation.
- src/compute_backend_cuda/cuda_backend.cc:1399-1408 permits recycling only a
  unique, nonbusy executable, then sets rebuild_only. :1422 rejects its launch.
  :1312-1354 keeps same-context/unique/nonbusy seed gating and only structural
  CUDA update rejection allows fresh instantiate. No vtable/layout is changed.
- All Queue/config/import/owner hard clears retain the old discard entry;
  repeated native invalidation may keep one previously accepted seed, never old
  launch keys. At most one existing CaptureRebuildStorage per original range.
- CUDA13.3 cuda_runtime_api.h:12826-12912 documents topologically identical
  graph update, context/memory restrictions and native success/failure results.
  Our source keeps the actual result check and structural fallback. Topology
  compatibility of the six native-change recaptures remains unproven here.

Stage/cost and falsification:
- This only targets six direct clears in the measured source-path episode;
  four first records are unavoidable. It does not clone an inactive artifact to
  seed the second variant, does not enlarge variants and cannot erase recording
  or provider planning. The nine empty-variant records are unchanged in policy.
- One host case checks actual retirement rejection, duplicate invalidation,
  zero binding authority, failed seal and hard Queue/config destruction.
- One clean c343-app K1 two-turn process checks IDs/ledger/dispatch/work and
  original capture record/reuse reports. It is not a formal TPS window.
- CUDA API counts in this unprofiled process are UNKNOWN. No seed count is
  relabeled as successful Update. If actual work/correctness changes, stop;
  if no replay-preparation signal or later six updates all structurally fail,
  close this candidate rather than increase cache size or reopen fixed512.
- Prior profiled prepare_replay=107.036554ms is nested full-phase cost, not
  candidate recoverable time. Even the 19 Instantiate API total22.150082ms is
  a separate diagnostic-window sum, not this candidate's gain.
'''
(W/'design-and-source-review.md').write_text(text,encoding='utf8')
print(json.dumps(checks))
