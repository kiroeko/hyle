from pathlib import Path
from collections import Counter
import hashlib,json,sqlite3

R=Path.cwd();W=Path(__file__).resolve().parent;B=R/'.scratch/mtp-performance-convergence-20261025/baseline'
SQL=dict(runtime='SELECT r.*,s.value AS api FROM CUPTI_ACTIVITY_KIND_RUNTIME r JOIN StringIds s ON s.id=r.nameId ORDER BY r.start',streams='SELECT f.value,c.value FROM ProcessStreams p JOIN StringIds f ON f.id=p.filenameId JOIN StringIds c ON c.id=p.contentId')
def pin(p):return dict(path=p.relative_to(R).as_posix(),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def save(p,v):p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf8')
def report(p):
    t=p.read_text(encoding='utf8');return json.JSONDecoder().raw_decode(t[t.index('{"source_id"'):])[0]
def normalize(v):
    if isinstance(v,list):return [normalize(x)for x in v]
    if isinstance(v,dict):return {k:normalize(x)for k,x in v.items()if not any(t in k for t in ['seconds','tokens_per_second','clock_unix','unix_ns','unix_ms'])}
    return v
def diff(a,b,path=''):
    if type(a)!=type(b):return[path+':type']
    if isinstance(a,dict):return[path+'/'+k+':key'for k in a.keys()^b.keys()]+[d for k in a.keys()&b.keys()for d in diff(a[k],b[k],path+'/'+k)]
    if isinstance(a,list):return[path+':length']if len(a)!=len(b)else[d for i,(x,y)in enumerate(zip(a,b))for d in diff(x,y,path+'/'+str(i))]
    return []if a==b else[path]

baseline=normalize(report(B/'two-turn-timing/02-hyle_mtp/stdout.log'))
out=dict(status='PAIRED_API_DIAGNOSTIC_OFFLINE_COMPLETE',SQL=SQL,arms={},scope='One serial original clean c343-control and candidate process each. API counts/returns only; no TPS, GPU kernel/body timing or recoverable-time conclusion.')
for arm in ['control','candidate']:
    F=W/('api-'+arm);c=sqlite3.connect('file:'+(F/'trace.sqlite').as_posix()+'?mode=ro',uri=True);c.row_factory=sqlite3.Row
    tables={x[0]for x in c.execute("SELECT name FROM sqlite_master WHERE type='table'")}
    columns=[dict(x)for x in c.execute('PRAGMA table_info(CUPTI_ACTIVITY_KIND_RUNTIME)')]
    for name,text in c.execute(SQL['streams']):
        if'stdout_'not in name and'stderr_'not in name:continue
        (F/('native-stdout.log'if'stdout_'in name else'native-stderr.log')).write_text(text,encoding='utf8')
    raw=report(F/'native-stdout.log');delta=diff(baseline,normalize(raw));assert not delta,(arm,delta)
    rows=[dict(x)for x in c.execute(SQL['runtime'])]
    actions=[x for x in rows if any(t in x['api']for t in ['StreamBeginCapture','StreamEndCapture','GraphExecUpdate','GraphInstantiate'])]
    counts={name:dict(calls=len(group),total_ms=sum(x['end']-x['start']for x in group)/1e6,return_codes=dict(Counter(str(x['returnValue'])for x in group)))for name in sorted(set(x['api']for x in actions))for group in [[x for x in actions if x['api']==name]]}
    # Capture pairing uses actual same runtime thread and chronological End->
    # next Begin. The two-arm traces have no NVTX or cross-process graph ID join.
    captures=[]
    for index,ended in enumerate(actions):
        if'StreamEndCapture'not in ended['api']:continue
        following=[]
        for v in actions[index+1:]:
            if v['globalTid']!=ended['globalTid']:continue
            if'StreamBeginCapture'in v['api']:break
            if'GraphExecUpdate'in v['api']or'GraphInstantiate'in v['api']:following.append(v)
        captures.append(dict(end_capture=ended,actions=following,order=['update'if'Update'in v['api']else'instantiate'for v in following]))
    warnings=[dict(x)for x in c.execute('SELECT severity,text,COUNT(*) AS count FROM DIAGNOSTIC_EVENT GROUP BY severity,text ORDER BY severity DESC,text')]if'DIAGNOSTIC_EVENT'in tables else[]
    result=dict(runtime_columns=columns,driver_table_present='CUPTI_ACTIVITY_KIND_DRIVER'in tables,source_work_equal=True,non_time_differences=delta,work={k:raw[k]for k in ['generated_tokens','actual_graph_calls','actual_target_rows','actual_draft_rows','consumed_drafts']},API=counts,capture_records=len(captures),capture_action_orders=dict(Counter('->'.join(v['order'])for v in captures)),warnings=warnings,trace=pin(F/'trace.sqlite'))
    save(F/'capture-actions.json',captures);save(F/'api-records.json',dict(columns=columns,actions=actions,summary=result))
    out['arms'][arm]=result;c.close()
out['non_time_cross_arm_differences']=diff(normalize(report(W/'api-control/native-stdout.log')),normalize(report(W/'api-candidate/native-stdout.log')))
assert not out['non_time_cross_arm_differences']
out['limitations']=['CUDA API return codes are recorded, not resultInfo.errorNode/errorFromNode. Runtime cudaSuccess is documented as successful update; structural failure code is separately retained.','API durations are nested within original preparation and not added to GPU work, cold gap or process wall time.','No original driver API table means driver-only outcomes remain unknown.','No graph node lineage is used. No cross-process graph ID or variant object is equated.']
save(W/'api-summary.json',out)
print(json.dumps({arm:{'API':v['API'],'capture_action_orders':v['capture_action_orders'],'work_equal':v['source_work_equal'],'warnings':v['warnings']}for arm,v in out['arms'].items()},indent=2))
