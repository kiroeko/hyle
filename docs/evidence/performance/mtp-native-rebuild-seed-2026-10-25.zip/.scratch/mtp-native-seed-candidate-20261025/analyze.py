from pathlib import Path
from collections import Counter
import hashlib,json,re,statistics,xml.etree.ElementTree as ET

R=Path.cwd();W=Path(__file__).resolve().parent;B=R/'.scratch/mtp-performance-convergence-20261025/baseline'
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def pin(p):return dict(path=p.relative_to(R).as_posix(),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def save(p,v):p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf8')
def normalize(v):
    if isinstance(v,list):return [normalize(x)for x in v]
    if isinstance(v,dict):return {k:normalize(x)for k,x in v.items()if not any(t in k for t in ['seconds','tokens_per_second','clock_unix','unix_ns','unix_ms'])}
    return v
def diff(a,b,path=''):
    if type(a)!=type(b):return [path+':type']
    if isinstance(a,dict):return [path+'/'+k+':key'for k in a.keys()^b.keys()]+[d for k in a.keys()&b.keys()for d in diff(a[k],b[k],path+'/'+k)]
    if isinstance(a,list):return [path+':length']if len(a)!=len(b)else[d for i,(x,y)in enumerate(zip(a,b))for d in diff(x,y,path+'/'+str(i))]
    return []if a==b else[path]
def report(p):
    t=p.read_text(encoding='utf8');return json.JSONDecoder().raw_decode(t[t.index('{"source_id"'):])[0]
def preparation(p):
    rows=[]
    for line in p.read_text(encoding='utf8').splitlines():
        m=re.match(r'prepared T=(\d+) visible=(\d+) replay=(\S+) cold_batch_seconds=([\d.e+-]+) capture_recorded=(\d+) capture_reused=(\d+)',line)
        if m:rows.append(dict(T=int(m[1]),visible=int(m[2]),route=m[3],seconds=float(m[4]),recorded=int(m[5]),reused=int(m[6])))
    return rows

base=B/'two-turn-timing/02-hyle_mtp';actual=report(W/'run1/stdout.log');old=report(base/'stdout.log')
differences=diff(normalize(old),normalize(actual));assert not differences,differences
prep=preparation(W/'run1/stderr.log');prior=preparation(base/'stderr.log')
prep_diff=diff([{k:v for k,v in x.items()if k!='seconds'}for x in prior],[{k:v for k,v in x.items()if k!='seconds'}for x in prep]);assert not prep_diff,prep_diff
host=ET.parse(W/'host-run2/results.xml').getroot();assert host.attrib['tests']=='1'and host.attrib['failures']=='0'
keys=['generated_tokens','actual_graph_calls','prefill_graph_calls','decode_graph_calls','prefill_target_rows','verified_target_rows','actual_target_rows','committed_target_rows','actual_draft_rows','consumed_drafts']
save(W/'preparation-records.json',dict(candidate=prep,original_clean_baseline=prior))
summary=dict(status='PRIVATE_CANDIDATE_HOST_AND_ONE_ORIGINAL_BEHAVIOR_PASS',
    product_merged=False,SDK_builds=0,HTTP=0,GPU_runs=1,GPU_released=True,
    throughput_evidence=False,numerical_or_quality_evidence=False,
    actual_process=read(W/'run1/process.json'),actual_command=pin(W/'run1/command.json'),
    clean_app=read(W/'ready2.json')['app'],image=read(W/'ready2.json')['image'],
    source_control_flow=read(W/'source-checks2.json'),source_patch=pin(W/'source.patch'),
    host=dict(tests=1,skipped=0,failures=0,process=read(W/'host-run2/process.json'),
        xml=pin(W/'host-run2/results.xml'),scope='Existing original host mock with in-flight rejection, duplicate native invalidation, storage valid / all keys and qualification absent, failed-seal no launch, hard configuration and Queue changes.'),
    source_work_equal=True,non_time_differences=differences,
    original_capture_report_equal=True,capture_report_differences=prep_diff,
    work={k:actual[k]for k in keys},
    capture_recorded=sum(x['recorded']for x in prep),capture_reused=sum(x['reused']for x in prep),
    CUDA_Instantiate_calls='unknown: unprofiled clean process, no native API hook',
    CUDA_Update_calls='unknown: unprofiled clean process, no native API hook',
    original_field_timing_observation=dict(
        scope='One candidate process versus one earlier original clean baseline process, NOT an interleaved benchmark or causal performance result.',
        baseline=pin(base/'stderr.log'),candidate=pin(W/'run1/stderr.log'),
        preparation_cold_batch_total_ms=dict(candidate=1000*sum(x['seconds']for x in prep),baseline=1000*sum(x['seconds']for x in prior)),
        recording_preparation_cold_batch_total_ms=dict(candidate=1000*sum(x['seconds']for x in prep if x['recorded']),baseline=1000*sum(x['seconds']for x in prior if x['recorded'])),
        decode_seconds=dict(candidate=actual['decode_seconds'],baseline=old['decode_seconds']),
        notes='Original endpoints/fields only. Capture records do not distinguish Update from Instantiate. This cannot prove six successful native Updates or recoverable107ms.'),
    first_failures=[dict(path='host-compile',kind='private copied test missing original tests/graph include path'),
        dict(path='host-run',kind='candidate incompleteness: next stable binding revalidation discarded the retained seed; host expected rebuild1 observed0. Fixed keep-existing-only disposition without bypassing original binding/seal.')],
    limitations=['Only one greedy K1 two-turn real workload, not random/K2/model/shape matrix.',
        'Host mock proves generic lifecycle/permission behavior, not real CUDA topology compatibility.',
        'No memory observer was added; no physical VRAM or private graph allocation limit claim.',
        'No final throughput gain claim; native Update compatibility remains a bounded next decision.'])
save(W/'summary.json',summary)
print(json.dumps({k:summary[k]for k in ['status','work','capture_recorded','capture_reused','original_field_timing_observation']},indent=2))
