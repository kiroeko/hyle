from pathlib import Path
import datetime,difflib,hashlib,json,zipfile

R=Path.cwd();W=Path(__file__).resolve().parent
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def pin(p):return dict(path=p.relative_to(R).as_posix(),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def save(p,v):p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf8')

files=['src/graph/executable.cc','src/graph/region_access.cc','src/graph/plan_state.h']
proposed=W/'proposed';pins=[]
for name in files:
    original=R/name;raw=original.read_bytes();target=proposed/name;target.parent.mkdir(parents=True,exist_ok=True)
    body=(W/'source'/Path(name).name).read_text()
    target.write_bytes(body.replace('\n','\r\n').encode('utf8')if b'\r\n'in raw else body.encode('utf8'))
    pins.append(dict(canonical_before=pin(original),compiled_private=pin(W/'source'/Path(name).name),proposed_canonical=pin(target),source_equal_after_lineending_normalization=target.read_text()==body))

test=R/'tests/graph/region_provider_test.cc';raw=test.read_bytes();old=raw.decode('utf8').replace('\r\n','\n')
private=(W/'source/region_provider_test.cc').read_text();name='TEST(GraphRegions, NativeCommandInvalidationKeepsOnlyRebuildSeedAndQueueStillDiscards)'
a=private.index(name);b=private.index('\nTEST(',a+5);case=private[a:b]
a=old.index('TEST(GraphRegions, NativeInvalidationAndQueueReplacementDiscardCaptureStorage)');b=old.index('\nTEST(',a+5)
after=old[:a]+case+old[b:];target=proposed/'tests/graph/region_provider_test.cc';target.parent.mkdir(parents=True,exist_ok=True)
target.write_bytes(after.replace('\n','\r\n').encode('utf8')if b'\r\n'in raw else after.encode('utf8'))
(W/'canonical-test.patch').write_bytes(''.join(difflib.unified_diff(old.splitlines(True),after.splitlines(True),fromfile='a/tests/graph/region_provider_test.cc',tofile='b/tests/graph/region_provider_test.cc')).encode('utf8'))
pins.append(dict(canonical_before=pin(test),compiled_private=pin(W/'source/region_provider_test.cc'),proposed_canonical=pin(target),selected_test_body_equal=True,only_actual_test_case_changed=True))
assert test.read_bytes()==(W/'canonical-test-before.cc').read_bytes()
save(W/'integration-pins.json',dict(files=pins,canonical_changed=False,product_patch=pin(W/'source.patch'),test_patch=pin(W/'canonical-test.patch'),canonical_test_temporarily_ported_then_guarded_restored=True))

s=(W/'source/executable.cc').read_text().splitlines()
points=[]
for mode in ['kDiscard','kStableBindings','kNativeArguments','kKeepExistingSeed']:
    points.append(dict(disposition=mode,private_source='source/executable.cc',call_lines=[i+1 for i,line in enumerate(s)if 'CaptureInvalidation::'+mode in line and (line.strip().endswith(');')or mode=='kKeepExistingSeed'and line.strip().endswith(');'))]))
save(W/'disposition-calls.json',dict(modes=points,meaning=dict(kDiscard='Original hard Queue/config/native-import/owner invalidation: destroy all commands, keys and rebuild storage.',kStableBindings='Original physical stable-TensorView rebind: preserve qualified2variant policy or recycle original eligible command.',kNativeArguments='Only resource_control_ready-gated RegionAccess::invalidate_commands: recycle at most1 retired command, then discard every key/binding/qualification; existing accepted seed survives duplicate invalidation.',kKeepExistingSeed='Only stable TensorView revalidation with neither old nor new native_inputs: keep already accepted nonlaunchable storage, never opportunistic recycle; original prepare_bindings/seal still mandatory.')))

superseded=[];retained=[]
for directory,keep in [('graph',False),('region',True),('host-compile2',False),('graph2',True),('host-compile3',True),('link',False),('host-link',False),('link2',True),('host-link2',True)]:
    for p in (W/directory).iterdir():
        if p.is_file()and p.suffix.lower()in ['.obj','.exe','.exp','.lib','.dll','.pdb','.map']:
            (retained if keep else superseded).append(pin(p))
cleanup=dict(superseded_files=superseded,superseded_count=len(superseded),superseded_logical_bytes=sum(v['bytes']for v in superseded),retained_current_files=retained,retained_current_count=len(retained),retained_current_logical_bytes=sum(v['bytes']for v in retained),deleted=False,scope='Only this private batch rebuildable binaries; root decides guarded cleanup. Preserve original c343 app/image, all shared closures/SDK/models/source/logs.')
save(W/'cleanup-candidates.json',cleanup)
summary=dict(status='PRIVATE_NATIVE_SEED_CANDIDATE_REVIEW_READY',created_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),product_merged=False,canonical_changes=0,GPU_released=True,SDK_builds=0,HTTP=0,
    conclusion='Six avoidable native Instantiations became successful Updates with exactly unchanged work. Timing medians nominally improve but all ranges overlap: throughput improvement UNPROVEN; no repeated window justified.',
    behavioral=read(W/'summary.json'),API_diagnostic=read(W/'api-summary.json'),bounded_screen=read(W/'screen/summary.json'),
    source_and_test_pins=read(W/'integration-pins.json'),cold_disposition_calls=read(W/'disposition-calls.json'),source_control_checks=read(W/'source-checks2.json'),cleanup=cleanup,
    retained_first_failures=['Private copied test missing original tests/graph include path; corrected host-only include.','First actual host candidate retained a seed at native invalidation, then binding revalidation deleted it. Original host expected rebuild1 observed0; fixed explicit keep-existing-only mode. Both old failure and corrected pass retained.'],
    recommendation='May merge as bounded reuse of existing nonlaunchable-seed contract, based on proven API behavior and no observed functional regression, if root accepts the explicit4mode maintenance cost. Do not describe it as a TPS win or recovery of107ms. No new cache size, math, owner permission or retired-work proof.',
    next='No more instantiation experiments. Any next candidate must come from existing ordinary/MTP end-to-end trace cost attribution and fair-work boundaries, not this overlapping timing screen.')
save(W/'proof-summary.json',summary)
allowed={'.py','.cc','.h','.json','.patch','.md','.log','.xml','.sqlite','.nsys-rep'}
paths=[p for p in W.rglob('*')if p.is_file()and p.suffix.lower()in allowed and '__pycache__'not in p.parts and p.name!='publication.json']
references=[R/'.scratch/mtp-performance-convergence-20261025/baseline/window.py',R/'.scratch/mtp-performance-convergence-20261025/baseline/runtime.json',R/'.scratch/mtp-performance-convergence-20261025/baseline/link/command.json',R/'.scratch/mtp-performance-convergence-20261025/baseline/two-turn-timing/02-hyle_mtp/stdout.log',R/'.scratch/mtp-performance-convergence-20261025/baseline/two-turn-timing/02-hyle_mtp/stderr.log',R/'.scratch/mtp-performance-convergence-20261025/baseline/two-turn-timing/02-hyle_mtp/command.json']
archive=W/'proof.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=6)as z:
    for p in sorted(set(paths+references)):z.write(p,p.relative_to(R).as_posix())
with zipfile.ZipFile(archive)as z:
    assert z.testzip()is None;entries=z.namelist();assert all(Path(n).suffix.lower()not in['.obj','.exe','.dll','.lib','.exp','.pdb','.map']for n in entries)
publication=dict(summary=pin(W/'proof-summary.json'),archive=pin(archive),entries=len(entries),CRC_pass=True,binaries_or_weights_or_SDK=False,cleanup=dict(superseded_count=len(superseded),superseded_logical_bytes=sum(v['bytes']for v in superseded),retained_count=len(retained),retained_logical_bytes=sum(v['bytes']for v in retained)))
save(W/'publication.json',publication);print(json.dumps(publication,indent=2))
