from pathlib import Path
import datetime,importlib.util,os

R=Path.cwd();W=Path(__file__).resolve().parent;B=R/'.scratch/mtp-performance-convergence-20261025/baseline'
spec=importlib.util.spec_from_file_location('retained',R/'.scratch/mtp-extraction-regression-20261024/check.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
candidate=b.read(W/'ready2.json');control=b.read(B/'ready.json')
nsys=Path(r'C:\Program Files\NVIDIA Corporation\Nsight Systems 2026.1.3\target-windows-x64\nsys.exe')
original=b.args(B/'two-turn-timing/02-hyle_mtp/command.json')
records=[]
for arm,ready in [('control',control),('candidate',candidate)]:
    image=Path(ready['image']['path']);assert b.pin(image)==ready['image']
    native=original.copy();native[0]=str(image);out=W/('api-'+arm)
    command=[str(nsys),'profile','--trace=cuda','--cuda-graph-trace=graph','--sample=none','--cpuctxsw=none','--discard-environment=true','--duration=20','--stats=false','--export=sqlite','--output='+str(out/'trace'),*native]
    records.append(dict(arm=arm,image=b.pin(image),native_argv=native,command=command,run_directory=str(out),timeout_seconds=120))
b.save(W/'api-plan.json',dict(scope='One control and one candidate serial CUDA API diagnostic; no NVTX source, node-kernel analysis or TPS window.',records=records,app=candidate['app'],runtime=b.pin(B/'runtime.json'),SDK_builds=0))
for record in records:
    env=os.environ.copy();env['HF_HUB_OFFLINE']='1';env['TRANSFORMERS_OFFLINE']='1'
    env['PATH']=str(Path(record['image']['path']).parent)+';'+b.read(B/'runtime.json')['PATH']
    print(record['arm']+' GPU start '+datetime.datetime.now(datetime.timezone.utc).isoformat(),flush=True)
    b.execute(record['command'],Path(record['run_directory']),env,record['timeout_seconds'])
print('PAIR_TERMINAL_GPU_RELEASED',flush=True)
