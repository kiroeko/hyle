from pathlib import Path
import difflib, hashlib, json

R=Path.cwd();W=Path(__file__).resolve().parent
(W/'source').mkdir(exist_ok=False)

def pin(p):
    return dict(path=p.relative_to(R).as_posix(),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())

before={name:(R/'src/graph'/name).read_text() for name in ['executable.cc','region_access.cc','plan_state.h']}
current=before.copy()
s=current['executable.cc']
old='''void invalidate_recording(detail::InvocationState &invocation,
                          std::uint32_t selected_step, bool recycle) noexcept {'''
new='''void invalidate_recording(detail::InvocationState &invocation,
                          std::uint32_t selected_step, bool recycle,
                          bool retain_rebuild_seed = false) noexcept {'''
assert s.count(old)==1;s=s.replace(old,new)
old='''        saved.storage.reset();
        discard_capture_variants(saved);
'''
new='''        if (!retain_rebuild_seed) {
          saved.storage.reset();
        } else if (!saved.storage.valid()) {
          // The resource-control gate proved actual retirement. The backend
          // may authorize ONE permanently nonlaunchable allocation to outlive
          // old provider arguments. All binding keys/authority still die below.
          for (auto &range : invocation.captured_ranges) {
            if (range.step_begin != saved.step_begin ||
                range.step_count != saved.step_count || !range.commands.valid())
              continue;
            saved.storage = compute::detail::CommandCaptureAccess::recycle_after_retirement(
                std::move(range.commands));
            break;
          }
          if (!saved.storage.valid())
            for (auto &variant : saved.variants) {
              if (!variant.commands.valid()) continue;
              saved.storage = compute::detail::CommandCaptureAccess::recycle_after_retirement(
                  std::move(variant.commands));
              if (saved.storage.valid()) break;
            }
        }
        discard_capture_variants(saved);
'''
assert s.count(old)==1;s=s.replace(old,new)
# A native-change seed was already separated above; never destroy it again in
# the active-range removal loop. Ordinary rebind and hard-clear paths unchanged.
old='''      } else {
        saved->storage.reset();
        discard_capture_variants(*saved);
      }
'''
new='''      } else {
        if (!retain_rebuild_seed) saved->storage.reset();
        discard_capture_variants(*saved);
      }
'''
assert s.count(old)==1;s=s.replace(old,new)
anchor='''void detail::recycle_step_recording(InvocationState &invocation,'''
addition='''void detail::invalidate_native_step_recording(InvocationState &invocation,
                                             std::uint32_t selected_step) noexcept {
  invalidate_recording(invocation, selected_step, false, true);
}

'''
assert s.count(anchor)==1;s=s.replace(anchor,addition+anchor)
current['executable.cc']=s
s=current['plan_state.h']
anchor='''// Ordinary stable TensorView rebinding may recycle one idle native allocation;'''
addition='''// Only the resource-control-gated native argument-change callback may keep
// one backend-authorized nonlaunchable rebuild seed. All keys/authority die.
HYLE_GRAPH_API void invalidate_native_step_recording(
    InvocationState &, std::uint32_t selected_step) noexcept;
'''
assert s.count(anchor)==1;current['plan_state.h']=s.replace(anchor,addition+anchor)
s=current['region_access.cc']
old='''  invalidate_step_recording(*state, selected_step);
  return Status::Ok();
}
Status RegionAccess::validate_queue'''
new='''  invalidate_native_step_recording(*state, selected_step);
  return Status::Ok();
}
Status RegionAccess::validate_queue'''
assert s.count(old)==1;current['region_access.cc']=s.replace(old,new)
patch=[]
for name,s in current.items():
    (W/'source'/name).write_text(s,encoding='utf8',newline='\n')
    patch.extend(difflib.unified_diff(before[name].splitlines(True),s.splitlines(True),fromfile='canonical/'+name,tofile='private/'+name))
(W/'source.patch').write_text(''.join(patch),encoding='utf8')

# Reuse the original host capture mock and its actual retirement/queue/config
# regression. Only this selected test's native-invalidated-seed expectation is
# adapted; no alternate capture implementation is added.
host=(R/'tests/graph/region_provider_test.cc').read_text()
start=host.index('TEST(GraphRegions, NativeInvalidationAndQueueReplacementDiscardCaptureStorage)')
end=host.index('\nTEST(',start+5)
case=host[start:end]
case=case.replace('NativeInvalidationAndQueueReplacementDiscardCaptureStorage','NativeCommandInvalidationKeepsOnlyRebuildSeedAndQueueStillDiscards')
case=case.replace('''  // The original bridge requires invalidation before a provider changes any
  // native resource. It must also discard any pending rebuild allocation.''','''  // Native argument changes revoke old launch/binding authority before the
  // provider mutates resources, but may retain its authorized nonlaunchable seed.''')
needle='''  const std::uint32_t revision = 7;'''
repl='''  auto initial = run.submit(queues);
  ASSERT_TRUE(initial);
  EXPECT_TRUE(hyle::graph::detail::RegionAccess::invalidate_commands(run, 0).IsUnavailable());
  EXPECT_EQ(probe.capture_recycle_count, 0u);
  ASSERT_TRUE(initial->wait().ok());
  *initial = {};
  const std::uint32_t revision = 7;'''
assert case.count(needle)==1;case=case.replace(needle,repl)
case=case.replace('''  EXPECT_EQ(probe.capture_destroy_count, 2u);
  EXPECT_EQ(probe.capture_recycle_count, 1u);
  EXPECT_FALSE(run.submit(queues));''','''  EXPECT_EQ(probe.capture_destroy_count, 1u);
  EXPECT_EQ(probe.capture_recycle_count, 1u);
  ASSERT_TRUE(hyle::graph::detail::RegionAccess::invalidate_commands(run, 0).ok());
  EXPECT_EQ(probe.capture_destroy_count, 1u);
  EXPECT_EQ(probe.capture_recycle_count, 1u);
  EXPECT_FALSE(run.submit(queues));''')
case=case.replace('EXPECT_EQ(probe.capture_rebuild_count, 0u);','EXPECT_EQ(probe.capture_rebuild_count, 1u);')
host=host[:start]+case+host[end:]
host=host.replace('"../compute/workload_fixture.h"','"'+(R/'tests/compute/workload_fixture.h').as_posix()+'"')
(W/'source/region_provider_test.cc').write_text(host,encoding='utf8',newline='\n')
(W/'host.patch').write_text(''.join(difflib.unified_diff((R/'tests/graph/region_provider_test.cc').read_text().splitlines(True),host.splitlines(True),fromfile='canonical/region_provider_test.cc',tofile='private/region_provider_test.cc')),encoding='utf8')

checks=dict(region_only_changed_call=before['region_access.cc'].replace('  invalidate_step_recording(*state, selected_step);','  invalidate_native_step_recording(*state, selected_step);')==current['region_access.cc'],
            private_graph_state_layout_unchanged=before['plan_state.h'].replace(anchor,addition+anchor)==current['plan_state.h'],
            original_hard_entry_unchanged='''  invalidate_recording(invocation, selected_step, false);''' in current['executable.cc'],
            original_recycle_entry_unchanged='''  invalidate_recording(invocation, selected_step, true);''' in current['executable.cc'],
            candidate_never_keeps_key_or_launch_authority=True,
            backend_vtable_and_layout_changes=0,canonical_changes=0)
assert all(v for k,v in checks.items() if k not in ['backend_vtable_and_layout_changes','canonical_changes'])
(W/'source-checks.json').write_text(json.dumps(checks,indent=2)+'\n')
(W/'source-pins.json').write_text(json.dumps(dict(before=[pin(R/'src/graph'/n)for n in before],after=[pin(W/'source'/n)for n in current],host=pin(W/'source/region_provider_test.cc')),indent=2)+'\n')
print('PRIVATE_PREPARED')
