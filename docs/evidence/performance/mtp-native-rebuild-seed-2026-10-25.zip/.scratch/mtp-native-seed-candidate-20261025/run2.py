from pathlib import Path
import datetime, importlib.util, os, sys

R=Path.cwd();W=Path(__file__).resolve().parent;B=R/'.scratch/mtp-performance-convergence-20261025/baseline'
spec=importlib.util.spec_from_file_location('retained',R/'.scratch/mtp-extraction-regression-20261024/check.py')
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
ready=b.read(W/'ready2.json');env=os.environ.copy()
env['HF_HUB_OFFLINE']='1';env['TRANSFORMERS_OFFLINE']='1'
env['PATH']=str(W/('host-link2'if sys.argv[1]=='host'else'link2'))+';'+b.read(B/'runtime.json')['PATH']
for p in ready['actual_dependency_pins']:
    for v in p:assert b.pin(Path(v['path']))==v
if sys.argv[1]=='host':
    assert b.pin(Path(ready['host']['path']))==ready['host']
    cmd=[ready['host']['path'],'--gtest_filter=GraphRegions.NativeCommandInvalidationKeepsOnlyRebuildSeedAndQueueStillDiscards','--gtest_output=xml:'+str(W/'host-run2/results.xml')]
    b.execute(cmd,W/'host-run2',env,60)
else:
    assert b.read(W/'host-run2/process.json')['exit']==0
    assert b.pin(Path(ready['image']['path']))==ready['image']
    cmd=b.args(B/'two-turn-timing/02-hyle_mtp/command.json');cmd[0]=ready['image']['path']
    b.save(W/'run-start.json',dict(start_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),image=ready['image'],original_command=b.pin(B/'two-turn-timing/02-hyle_mtp/command.json'),scope='One uninstrumented clean-app K1 real-two-turn behavioral/capture-report check. No profiler or formal throughput window.'))
    b.execute(cmd,W/'run1',env,120)
