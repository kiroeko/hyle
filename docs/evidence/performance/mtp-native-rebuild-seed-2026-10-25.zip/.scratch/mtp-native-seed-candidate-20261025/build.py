from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import importlib.util, json, os, sys

R=Path.cwd();W=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('retained',R/'.scratch/mtp-extraction-regression-20261024/check.py')
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
C=R/'.scratch/mtp-performance-convergence-20261025/current-cuda'
B=R/'.scratch/mtp-performance-convergence-20261025/baseline'
old=b.args(C/'product-0/command.json');flags=[];skip=False
for a in old[1:]:
    if skip:skip=False;continue
    if a=='/sourceDependencies':skip=True;continue
    if a.lower().startswith(('/fo','/fd')) or a.lower().endswith(('.cc','.cpp')):continue
    flags.append(a)
env=b.environment(old[0])

def compile_one(name,filename):
    d=W/name
    cmd=[old[0],*flags,str(W/'source'/filename),'/sourceDependencies',str(d/'dependencies.json'),'/Fo'+str(d/'unit.obj')]
    b.execute(cmd,d,env,120)
    dep=b.read(d/'dependencies.json')['Data']
    pins=[b.pin(Path(v))for v in [dep['Source'],*dep['Includes']]if Path(v).is_relative_to(R)]
    b.save(d/'source-pins.json',pins)
    return pins

host_dir='host-compile'
graph_dir='graph';link_suffix='';ready_name='ready.json'
if 'fix' in sys.argv:
    flags.append('/I'+str(R/'tests/graph'))
    graph_dir='graph2';host_dir='host-compile3';link_suffix='2';ready_name='ready2.json'
    with ThreadPoolExecutor(max_workers=2) as pool:
        newpins=list(pool.map(lambda j:compile_one(*j),[(graph_dir,'executable.cc'),(host_dir,'region_provider_test.cc')]))
    allpins=[newpins[0],b.read(W/'region/source-pins.json'),newpins[1]]
elif 'resume' in sys.argv:
    flags.append('/I'+str(R/'tests/graph'))
    host_dir='host-compile2'
    allpins=[b.read(W/'graph/source-pins.json'),b.read(W/'region/source-pins.json'),compile_one(host_dir,'region_provider_test.cc')]
else:
    jobs=[('graph','executable.cc'),('region','region_access.cc'),('host-compile','region_provider_test.cc')]
    with ThreadPoolExecutor(max_workers=3) as pool:
        allpins=list(pool.map(lambda j:compile_one(*j),jobs))

old_region=R/'.scratch/glm-quark-selected-20261024/Q30/graph-integration-preparation/host1/graph--region_access.obj'
replacements={str(C/'product-0/unit.obj').lower():str(W/graph_dir/'unit.obj'),str(old_region).lower():str(W/'region/unit.obj')}
link=b.args(B/'link/command.json');common=[];seen={k:0 for k in replacements}
for a in link[1:]:
    if a.lower() in replacements:
        common.append(replacements[a.lower()]);seen[a.lower()]+=1
    elif not a.lower().startswith(('/out:','/pdb:','/map:','/implib:')):common.append(a)
assert all(n==1 for n in seen.values()),seen
for name,actual in [('link','hyle'),('host-link','host')]:
    d=W/(name+link_suffix);args=common.copy()
    if actual=='host':
        app=str(B/'compile/unit.obj')
        assert sum(a.lower()==app.lower()for a in args)==1
        args=[str(W/host_dir/'unit.obj')if a.lower()==app.lower()else a for a in args]
        args += [str(R/'.scratch/build-compute-v2-dev/lib/gtest_main.lib'),str(R/'.scratch/build-compute-v2-dev/lib/gtest.lib')]
    b.execute([link[0],*args,'/OUT:'+str(d/(actual+'.exe')),'/IMPLIB:'+str(d/(actual+'.lib'))],d,env,90)
    os.link(B/'link/hyle_ggml_cpu_gdn_scale_v3.dll',d/'hyle_ggml_cpu_gdn_scale_v3.dll')

for pins in allpins:
    for p in pins:assert b.pin(Path(p['path']))==p
b.save(W/ready_name,dict(image=b.pin(W/('link'+link_suffix)/'hyle.exe'),host=b.pin(W/('host-link'+link_suffix)/'host.exe'),
    app=b.pin(B/'compile/unit.obj'),report=b.pin(C/'report/unit.obj'),
    original_link=b.pin(B/'link/command.json'),actual_dependency_pins=allpins,
    new_product_TUs=2,new_host_test_TUs=1,SDK_builds=0,product_edits=0))
print('CANDIDATE_READY',flush=True)
