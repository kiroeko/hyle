"""Archive the finite current native-owner experiment, excluding rebuildable images."""
from pathlib import Path
import hashlib
import json
import statistics
import zipfile

F = Path(__file__).resolve().parent
R = next(x for x in F.parents if (x / 'AGENTS.md').is_file() and (x / 'src').is_dir())
P = F / 'native-fix'
E = R / 'docs/evidence/performance'

def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))

def ident(path):
    return dict(path=str(path.relative_to(R)).replace('\\', '/'), bytes=path.stat().st_size,
                sha256=hashlib.sha256(path.read_bytes()).hexdigest())

def api_counts(row):
    return {x['name']: x['count'] for category in row['API_categories'].values()
            for x in category['API_names']}

baseline = read(F / 'analysis.json')['arms']['auto']
candidate = read(P / 'node-analysis.json')
assert [x['predicted_id'] for x in baseline['phases']] == [x['predicted_id'] for x in candidate['phases']]
trace_summary = {}
for arm, report in [('baseline', baseline), ('candidate', candidate)]:
    trace_summary[arm] = {}
    for name in ['decode1', 'decode2']:
        row = report['selected_phases'][name]
        counts = api_counts(row)
        trace_summary[arm][name] = dict(kernels=row['native_kernel_count'],
            context_push=counts.get('cuCtxPushCurrent_v2', 0),
            context_pop=counts.get('cuCtxPopCurrent_v2', 0),
            cudaMalloc=sum(v['count'] for v in row['allocation_API_placement']['cudaMalloc'].values()),
            cudaFree=sum(v['count'] for v in row['allocation_API_placement']['cudaFree'].values()))
timing = read(P / 'validation/short-timing/summary.json')
tests = read(P / 'validation/native-tests/summary.json')
smoke = read(P / 'validation/correctness/summary.json')
linux = read(F / 'linux-native-incremental/execution.json')
assert timing['passed'] and tests['passed'] and smoke['passed'] and linux['passed']
archive = E / 'qwen-capture-resource-reuse-2026-10-21.zip'
assert not archive.exists()
selected = sorted(x for x in F.rglob('*') if x.is_file()
    and x.suffix in ['.json', '.log', '.py', '.diff', '.xml', '.sqlite', '.nsys-rep', '.txt']
    and 'research' not in x.name and '__pycache__' not in x.parts)
sources = [R / p for p in ['src/compute_backend_cuda/cuda_backend.cc',
    'src/compute_provider_ggml_cuda/ggml_cuda_provider.cc',
    'tests/compute_backend_cuda/device_status_test.cc']]
with zipfile.ZipFile(archive, 'x', zipfile.ZIP_DEFLATED, compresslevel=6) as z:
    for path in selected:
        z.write(path, 'experiment/' + path.relative_to(F).as_posix())
    for path in sources:
        z.write(path, 'current-source/' + path.relative_to(R).as_posix())
    z.writestr('manifest.json', json.dumps([ident(x) for x in selected+sources], indent=2))
summary = dict(schema='hyle.qwen.capture-resource-reuse.v1', date='2026-10-21',
    status='Correctness and structural reduction verified; no throughput gain established; D4 remains open',
    changes=[
        'Queue retains one unused capture status word; checked artifacts retain independent owned words.',
        'GGML native-retirement traversal omits CUDA context guards only after same-chain positive proof and when no native query remains.'
    ],
    public_API_or_layout_changes=False,
    baseline_image=read(F.parent/'auto-replay-policy/ready-for-root.json')['image'],
    candidate_image=read(P/'ready-for-root.json')['image'],
    source_inventory=[ident(x) for x in sources],
    correctness=dict(native_tests=tests, original_vectors=smoke,
        prediction_equality_in_timing=timing['Hyle_predictions_equal'],
        trace_17_predictions_equal=True, independent_model_quality_acceptance=False),
    build=dict(Windows='Two strict product CXX objects and one Qwen link; two test CXX and one small test CUDA TU plus one test link. No SDK rebuild.',
        Linux=read(F/'linux-native-incremental/build-install-readiness.json'),
        Linux_actual_consumers=linux,
        macOS='Not rerun: product changes are CUDA-only.'),
    no_profiler_timing=timing,
    timing_interpretation='Three fresh processes per arm, interleaved baseline/candidate/peer, original128+31 host-token steps. Candidate full92.29 versus baseline93.04 and peer95.79 tok/s. Candidate first-two median32.05 versus33.67ms, but samples vary widely; no significant speedup/regression conclusion. This window is not pooled with earlier faster windows.',
    node_trace=trace_summary,
    trace_interpretation='Same596 kernels per M1. Context push/pop pairs drop1313 to945 each first M1; second capture removes one cudaMalloc, both remove one cudaFree. Counts confirm the intended structural effect. Instrumented times are not throughput evidence or recoverable savings.',
    limits=['Single RTX4070 under normal desktop use; no exclusive GPU or fixed clocks.',
        'Hyle uses mainly BF16 intermediates; peer uses additional F32 arithmetic and naturally transfers sampled logits. Same original weights and fixed inputs are not identical per-operator arithmetic.',
        'Two fixed-binding captured artifacts remain independent; source review did not justify sharing them or moving actual first execution outside timing.',
        'No new memory peak, energy, long-decode or MTP measurement in this finite native experiment.'],
    next_action='Broader local-engine source research, then rank only concrete Hyle gaps by actual full-call speed opportunity. No repeated broad benchmark matrix.',
    archive={**ident(archive), 'members':len(selected)+len(sources)+1})
out=E/'qwen-capture-resource-reuse-2026-10-21.json'
assert not out.exists()
out.write_text(json.dumps(summary, indent=2, ensure_ascii=False, allow_nan=False)+'\n', encoding='utf-8')
print(json.dumps(dict(report=ident(out), archive=summary['archive']), indent=2))
