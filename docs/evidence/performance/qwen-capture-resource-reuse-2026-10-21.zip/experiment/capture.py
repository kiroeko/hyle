"""Current auto/peer cached16 CUDA node traces; root serial execution only."""
from pathlib import Path
import importlib.util
import subprocess
import sys

sys.dont_write_bytecode = True
P = Path(__file__).resolve().parent
D = P.parent
spec = importlib.util.spec_from_file_location('first_decode_root_runner', D / 'root_run.py')
r = importlib.util.module_from_spec(spec)
spec.loader.exec_module(r)
NSYS = Path('C:/Program Files/NVIDIA Corporation/Nsight Systems 2026.1.3/target-windows-x64/nsys.exe')


def main():
    out = P / 'traces'
    out.mkdir(exist_ok=False)
    runs_path = D / 'auto-replay-policy/cached16-timing/runs.json'
    runs = r.read(runs_path)
    models = [(arm, next(x for x in runs if x['arm'] == arm)['process']['command'].copy())
              for arm in ('auto', 'llama')]
    ready = r.read(D / 'auto-replay-policy/ready-for-root.json')
    assert r.identity(models[0][1][0]) == ready['image']
    assert r.identity(ready['source']['path']) == ready['source']
    version = subprocess.run([str(NSYS), '--version'], capture_output=True, check=True)
    (out / 'version.log').write_bytes(version.stdout + version.stderr)
    r.save(out / 'plan.json', dict(tool=r.identity(NSYS), version=r.identity(out / 'version.log'),
                                 source_runs=r.identity(runs_path), source=ready['source'],
                                 scope='Two unchanged cached16 consumers. CUDA API + node activities; no throughput claim.',
                                 graph_trace='node:host-only', CPU_sampling=False, builds=0,
                                 memory_observer=False, scripted_warmup=False))
    for arm, command in models:
        folder = out / arm
        folder.mkdir()
        if arm == 'llama':
            command[-1] = str(folder / 'peer-result.json')
        r.save(folder / 'model-command.json', dict(command=command, image=r.identity(command[0]),
                                                  instrumented=True, throughput_evidence=False))
        profile = [str(NSYS), 'profile', '--trace=cuda', '--sample=none', '--cpuctxsw=none',
                   '--cuda-trace-all-apis=true', '--cuda-graph-trace=node:host-only',
                   '--discard-environment=true', '--force-overwrite=false',
                   '--output=' + str(folder / 'capture'), *command]
        r.execute(folder, 'profile', profile)
        r.execute(folder, 'export', [str(NSYS), 'export', '--type=sqlite', '--force-overwrite=false',
                                    '--output=' + str(folder / 'capture.sqlite'), str(folder / 'capture.nsys-rep')])
        r.save(folder / 'receipt.json', dict(report=r.identity(folder / 'capture.nsys-rep'),
                                             sqlite=r.identity(folder / 'capture.sqlite'),
                                             image=r.identity(command[0]), instrumented=True,
                                             throughput_evidence=False))


if __name__ == '__main__':
    main()
