"""Read-only attribution of root's two completed CUDA node traces; no model launch."""
from pathlib import Path
import collections
import hashlib
import json
import re
import sqlite3

P = Path(__file__).resolve().parent
D = P.parent
EXPECTED = dict(auto='044288ddcfdd56421b0e174c66a96aa1e0a499973ad2c5e2559f2750e01d81b8',
                llama='ce37992ff3e2ec15979e8a0af4ab260b32fa9a92b2bd9903086a0b09e8da0eae')


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def ident(path):
    path = Path(path)
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for part in iter(lambda: stream.read(4 << 20), b''):
            digest.update(part)
    return dict(path=str(path.resolve()), bytes=path.stat().st_size, sha256=digest.hexdigest())


# Same interval union convention as cached16-trace/analyze.py. All raw durations
# remain integer ns; cumulative durations and unions are deliberately separate.
def merged(intervals):
    out = []
    for begin, end in sorted(intervals):
        if end <= begin:
            continue
        if out and begin <= out[-1][1]:
            out[-1][1] = max(out[-1][1], end)
        else:
            out.append([begin, end])
    return out


def duration(intervals):
    return sum(end-begin for begin, end in merged(intervals))


def clipped(row, begin, end):
    return max(0, min(end, row['end'])-max(begin, row['start']))


def intervals(rows, begin, end):
    return [(max(begin, r['start']), min(end, r['end'])) for r in rows]


def overlaps(row, begin, end):
    return row['start'] < end and row['end'] > begin


def grouped(rows, begin, end, name='name', limit=20):
    groups = collections.defaultdict(lambda: dict(count=0, cumulative_ns=0, intervals=[]))
    for row in rows:
        if not overlaps(row, begin, end):
            continue
        g = groups[str(row[name])]
        g['count'] += 1
        g['cumulative_ns'] += clipped(row, begin, end)
        g['intervals'].append((max(begin, row['start']), min(end, row['end'])))
    result = [dict(name=name, count=g['count'], cumulative_ns=g['cumulative_ns'],
                   union_ns=duration(g['intervals'])) for name, g in groups.items()]
    return sorted(result, key=lambda r: -r['cumulative_ns'])[:limit]


def category(name):
    if 'BeginCapture' in name or 'EndCapture' in name:
        return 'capture_begin_end'
    if 'GraphInstantiate' in name:
        return 'graph_instantiate'
    if 'GraphLaunch' in name:
        return 'graph_launch'
    if 'Graph' in name:
        return 'other_graph_setup_destroy_update'
    if any(key in name for key in ['Module', 'Library', 'FuncGet', 'KernelGet', 'FuncSet', 'KernelSet']):
        return 'module_library_function_metadata'
    if any(key in name for key in ['Malloc', 'MemAlloc', 'MemHostAlloc', 'Free', 'MemPool']):
        return 'allocation_free'
    if 'Memcpy' in name or 'Memset' in name:
        return 'copy_memset_API'
    if 'Synchronize' in name or 'Event' in name:
        return 'event_and_synchronization_API'
    if 'LaunchKernel' in name:
        return 'kernel_launch_API'
    return 'other_API'


def fields(line):
    return dict(word.split('=', 1) for word in line.split()[1:] if '=' in word)


def phases_from_logs(arm, stderr, root):
    if arm == 'auto':
        phases, prepares, plans = [], [], []
        for line in stderr.splitlines():
            if line.startswith('prepared T='):
                prepares.append(fields(line))
            elif line.startswith('planned_replay '):
                plans.append(fields(line))
            elif re.match(r'^(prefill|continuation|decode\d+) tokens=', line):
                f = fields(line)
                p = prepares[len(phases)]
                phases.append(dict(name=line.split()[0], input_tokens=int(f['tokens']),
                                   visible_tokens=int(f['visible']), predicted_id=int(f['next']),
                                   step_ns_from_printed_seconds=round(float(f['step_seconds'])*1e9),
                                   cold_batch_ns_from_printed_seconds=round(float(p['cold_batch_seconds'])*1e9),
                                   submit_to_token_ns_from_printed_seconds=round(float(f['seconds'])*1e9),
                                   submit_return_ns_from_printed_seconds=round(float(f['submit_seconds'])*1e9),
                                   replay=p['replay'], capture_recorded=int(p['capture_recorded']),
                                   capture_reused=int(p['capture_reused'])))
        assert len(prepares) == len(phases)
    else:
        assert 'measure_memory name=prefill_complete' in stderr and 'measure_memory name=inference_complete' in stderr
        peer = read(root/'peer-result.json')
        phases = [dict(p, step_ns_from_printed_seconds=round(p['step_seconds']*1e9)) for p in peer['phases']]
        assert all(p['sampled_logits_elements'] == 248320 for p in phases)
        plans = []
    assert len(phases) == 17
    assert [p['name'] for p in phases] == ['prefill', 'continuation']+[f'decode{i}' for i in range(1, 16)]
    assert [p['input_tokens'] for p in phases] == [128, 16]+[1]*15
    assert [p['visible_tokens'] for p in phases] == [128, 144]+list(range(145, 160))
    return phases, plans


def phase_report(name, first, last, phases, anchors, api, kernels, copies, sets, graphs, graph_table, node_events):
    begin = anchors[first-1]['host_completion_API']['end_ns']
    end = anchors[last]['host_completion_API']['end_ns']
    selected = lambda rows: [r for r in rows if overlaps(r, begin, end)]
    aa, kk, cc, zz, gg = map(selected, [api, kernels, copies, sets, graphs])
    main_tid = anchors[last]['host_completion_API']['globalTid']
    main_api = [r for r in aa if r.get('globalTid') == main_tid]
    direct = intervals(kk+cc+zz, begin, end)
    busy = merged(direct)
    graph_nodes = [r for r in kk if r.get('graphNodeId') is not None]
    # GRAPH_TRACE is an execution envelope, not an extra kernel; node-event rows
    # describe creation/clone metadata and are never added to GPU work records.
    extended = merged(direct+intervals(gg, begin, end))
    gaps, at = [], begin
    for left, right in busy:
        if left > at:
            gaps.append((at, left))
        at = max(at, right)
    if at < end:
        gaps.append((at, end))
    gap_details = []
    for left, right in sorted(gaps, key=lambda p: -(p[1]-p[0]))[:10]:
        api_in_gap = [r for r in aa if overlaps(r, left, right)]
        gap_details.append(dict(start_ns=left, end_ns=right, start_from_envelope_ns=left-begin,
                                duration_ns=right-left, overlapping_API_union_ns=duration(intervals(api_in_gap, left, right)),
                                overlapping_API_top=grouped(api_in_gap, left, right, limit=5),
                                not_a_CPU_cause='No recorded kernel/copy/memset in this gap. CPU sampling is disabled; absence of API records does not identify the host work or prove the gap is removable.'))
    categories = collections.defaultdict(list)
    for row in aa:
        categories[category(row['name'])].append(row)
    cat_report = {key: dict(count=len(rows), cumulative_ns=sum(clipped(r, begin, end) for r in rows),
                            union_ns=duration(intervals(rows, begin, end)), API_names=grouped(rows, begin, end, limit=None))
                  for key, rows in categories.items()}
    critical = [r for r in aa if any(key in r['name'] for key in ['BeginCapture', 'EndCapture', 'GraphInstantiate', 'GraphLaunch', 'cudaMalloc', 'cudaFree'])
                or clipped(r, begin, end) >= 200000]
    copy_groups = collections.defaultdict(list)
    for row in cc:
        copy_groups[(row['copyKind'], row['bytes'])].append(row)
    capture_begin = [r for r in aa if 'BeginCapture' in r['name']]
    capture_end = [r for r in aa if 'EndCapture' in r['name']]
    adjacent = None
    if capture_begin:
        mallocs = [r for r in aa if 'cudaMalloc' in r['name'] and r['end'] <= capture_begin[0]['start']]
        instantiates = [r for r in aa if 'GraphInstantiate' in r['name']]
        frees = [r for r in aa if 'cudaFree' in r['name'] and instantiates and r['start'] >= instantiates[-1]['end']]
        if mallocs and frees:
            last_malloc, first_free = mallocs[-1], frees[0]
            adjacent = dict(
                last_malloc_before_capture={k: last_malloc[k] for k in ['name', 'start', 'end', 'correlationId']},
                first_free_after_instantiate={k: first_free[k] for k in ['name', 'start', 'end', 'correlationId']},
                malloc_duration_ns=last_malloc['end']-last_malloc['start'],
                free_duration_ns=first_free['end']-first_free['start'],
                combined_API_duration_ns=last_malloc['end']-last_malloc['start']+first_free['end']-first_free['start'],
                allocation_bytes=None,
                limit='Temporal candidates only: the API table has no size/pointer arguments. This does not prove the same allocation or4B size; mapping requires independent source evidence. Instrumented durations are not recoverable no-profile savings.')
    placement = {}
    for prefix in ['cudaMalloc', 'cuMemAlloc', 'cuMemHostAlloc', 'cudaFree']:
        zones = collections.defaultdict(lambda: dict(count=0, cumulative_ns=0))
        for row in aa:
            if prefix not in row['name']:
                continue
            zone = ('no_capture_in_phase' if not capture_begin else
                    'before_capture' if row['end'] <= capture_begin[0]['start'] else
                    'after_capture' if capture_end and row['start'] >= capture_end[-1]['end'] else 'during_capture')
            zones[zone]['count'] += 1
            zones[zone]['cumulative_ns'] += row['end']-row['start']
        placement[prefix] = dict(zones)
    node_meta = [r for r in node_events if begin <= r['start'] < end]
    logged = sum(phases[i]['step_ns_from_printed_seconds'] for i in range(first, last+1))
    result = dict(name=name, phase_ordinals=list(range(first, last+1)), logged_phases=phases[first:last+1],
                  envelope_start_ns=begin, envelope_end_ns=end, host_token_API_envelope_ns=end-begin,
                  summed_logged_step_ns=logged, envelope_minus_logged_steps_ns=end-begin-logged,
                  boundary='Previous host-token completion API return through this phase host-token completion API return; includes intervening log/snapshot overhead and excludes final tiny CPU bookkeeping. It brackets but is not the source step timer.',
                  native_kernel_count=len(kk), graph_node_kernel_count=len(graph_nodes), direct_kernel_count=len(kk)-len(graph_nodes),
                  native_kernel_cumulative_clipped_ns=sum(clipped(r, begin, end) for r in kk),
                  native_kernel_busy_union_ns=duration(intervals(kk, begin, end)),
                  native_kernel_top=grouped(kk, begin, end, limit=18),
                  first_kernel_from_envelope_ns=min((r['start']-begin for r in kk), default=None),
                  first_to_last_kernel_span_ns=max(r['end'] for r in kk)-min(r['start'] for r in kk) if kk else None,
                  recorded_kernel_copy_memset_busy_union_ns=duration(direct),
                  recorded_busy_lower_bound_ns=duration(direct), profiled_phase_time_upper_bound_ns=end-begin,
                  time_without_recorded_kernel_copy_memset_ns=end-begin-duration(direct),
                  graph_trace_table_present=graph_table,
                  graph_execution_envelopes_count=len(gg) if graph_table else None,
                  graph_envelope_plus_node_activity_coverage_union_ns=duration(extended) if graph_table else None,
                  graph_node_metadata_events_excluded_from_GPU_work=len(node_meta),
                  GPU_coverage_scope='Union is only the profiled process/device recorded node/direct kernels, copies and memsets, not PMU utilization or global card busy. Missing graph interiors or unrecorded activities can only reduce observable coverage.',
                  API_record_count=len(aa), API_cumulative_clipped_ns=sum(clipped(r, begin, end) for r in aa),
                  API_union_ns=duration(intervals(aa, begin, end)), main_host_thread_API_union_ns=duration(intervals(main_api, begin, end)),
                  API_top=grouped(aa, begin, end), API_categories=cat_report,
                  capture_recording_envelope_ns=capture_end[-1]['end']-capture_begin[0]['start'] if capture_begin and capture_end else None,
                  capture_adjacent_malloc_free_candidates=adjacent,
                  allocation_API_placement=placement,
                  critical_API_timeline=[dict(name=r['name'], start_from_envelope_ns=r['start']-begin,
                                              end_from_envelope_ns=r['end']-begin, duration_ns=r['end']-r['start'],
                                              clipped_duration_ns=clipped(r, begin, end), correlationId=r['correlationId'], globalTid=r.get('globalTid')) for r in critical],
                  memcpy_groups=[dict(copyKind=kind, bytes_per_record=size, count=len(rows),
                                      whole_record_bytes=sum(r['bytes'] for r in rows),
                                      cumulative_clipped_ns=sum(clipped(r, begin, end) for r in rows),
                                      busy_union_ns=duration(intervals(rows, begin, end))) for (kind, size), rows in sorted(copy_groups.items())],
                  memcpy_bytes_limit='Bytes count whole overlapping records; interval durations are clipped. Copy API time, GPU transfer time and synchronization time overlap and must not be added.',
                  allocation_bytes=None, allocation_limit='API records expose call duration/count, not allocation argument sizes; no memory-capacity or peak attribution is inferred.',
                  longest_recorded_GPU_gaps=gap_details)
    return result


def arm_report(arm):
    root = P/'traces'/arm
    db = root/'capture.sqlite'
    receipt, command = read(root/'receipt.json'), read(root/'model-command.json')
    db_identity = ident(db)
    assert db_identity == receipt['sqlite']
    assert command['image']['sha256'] == receipt['image']['sha256'] == EXPECTED[arm]
    assert ident(command['image']['path']) == command['image']
    c = sqlite3.connect(db.resolve().as_uri()+'?mode=ro', uri=True)
    c.execute('PRAGMA query_only=ON')
    c.row_factory = sqlite3.Row
    tables = {r['name'] for r in c.execute("select name from sqlite_master where type='table'")}
    strings = {r['id']: r['value'] for r in c.execute('select *from StringIds')}
    files = [dict(r) for r in c.execute('select *from ANALYSIS_FILE')]
    logs = {}
    for kind in ('stdout', 'stderr'):
        candidates = [r for r in files if (kind+'_') in r['filename']]
        assert len(candidates) == 1
        logs[kind] = dict(metadata=candidates[0], content=strings[candidates[0]['contentId']])
        (P/(arm+'.model.'+kind+'.extracted.log')).write_text(logs[kind]['content'], encoding='utf-8')
    pid = logs['stderr']['metadata']['globalPid']
    assert logs['stdout']['metadata']['globalPid'] == pid
    phases, plans = phases_from_logs(arm, logs['stderr']['content'], root)
    dedup = {}

    def rows(table):
        if table not in tables:
            return []
        raw = [dict(r) for r in c.execute('select *from '+table+' order by start')]
        keep, seen = [], set()
        for row in raw:
            key = tuple(row.items())
            if key not in seen:
                seen.add(key)
                keep.append(row)
        dedup[table] = dict(raw_export_rows=len(raw), exact_duplicate_full_rows_dropped=len(raw)-len(keep), unique_rows=len(keep))
        return keep

    api = rows('CUPTI_ACTIVITY_KIND_RUNTIME')
    for row in api:
        row['name'] = strings[row['nameId']]
    kernels, copies, sets = map(rows, ['CUPTI_ACTIVITY_KIND_KERNEL', 'CUPTI_ACTIVITY_KIND_MEMCPY', 'CUPTI_ACTIVITY_KIND_MEMSET'])
    for collection in [kernels, copies, sets]:
        assert all(row.get('globalPid') == pid for row in collection)
    assert {r['deviceId'] for r in kernels} == {0}
    for row in kernels:
        row['name'] = strings[row['demangledName']]
    graph_table = 'CUPTI_ACTIVITY_KIND_GRAPH_TRACE' in tables
    graphs = rows('CUPTI_ACTIVITY_KIND_GRAPH_TRACE')
    node_events = rows('CUDA_GRAPH_NODE_EVENTS')
    for row in node_events:
        row['name'] = strings[row['nameId']]
    bycorr = collections.defaultdict(list)
    for row in api:
        bycorr[row['correlationId']].append(row)
    dtoh = [r for r in copies if r['copyKind'] == 2]
    if arm == 'auto':
        assert len(dtoh) == 17 and all(r['bytes'] == 4 for r in dtoh)
        pairs = [[r] for r in dtoh]
    else:
        assert len(dtoh) == 34
        pairs = [dtoh[i:i+2] for i in range(0, 34, 2)]
        assert all([r['bytes'] for r in pair] == [4, 993280] for pair in pairs)
    anchors = []
    for i, pair in enumerate(pairs):
        last = pair[-1]
        matching = bycorr[last['correlationId']]
        assert len(matching) == 1
        op = matching[0]
        if arm == 'auto':
            assert 'MemcpyDtoH' in op['name'] and op['end'] >= last['end']
            completion = op
        else:
            syncs = [r for r in api if 'StreamSynchronize' in r['name'] and r['globalTid'] == op['globalTid']
                     and r['start'] >= op['end'] and r['start'] <= last['end'] <= r['end']]
            assert syncs
            completion = min(syncs, key=lambda r: r['end'])
        anchors.append(dict(phase=i, name=phases[i]['name'], input_tokens=phases[i]['input_tokens'],
                            visible_tokens=phases[i]['visible_tokens'], predicted_id=phases[i]['predicted_id'],
                            copies=[{k: r[k] for k in ['start', 'end', 'bytes', 'correlationId', 'streamId', 'graphNodeId']} for r in pair],
                            host_completion_API=dict(name=completion['name'], start_ns=completion['start'], end_ns=completion['end'],
                                                     globalTid=completion['globalTid'], correlationId=completion['correlationId'])))
    reports = {name: phase_report(name, first, last, phases, anchors, api, kernels, copies, sets, graphs, graph_table, node_events)
               for name, first, last in [('T16', 1, 1), ('decode1', 2, 2), ('decode2', 3, 3), ('first_two_M1', 2, 3)]}
    result = dict(sqlite=db_identity, receipt=ident(root/'receipt.json'), command=command,
                  ANALYSIS_FILE_log_metadata={k: v['metadata'] for k, v in logs.items()},
                  extracted_logs={k: ident(P/(arm+'.model.'+k+'.extracted.log')) for k in logs},
                  model_globalPid=pid, phases=phases, planned_replay=plans, actual_token_returns=anchors,
                  schema=dict(graph_trace_table_present=graph_table, kernel_columns=[r['name'] for r in c.execute('pragma table_info(CUPTI_ACTIVITY_KIND_KERNEL)')]),
                  deduplication=dedup, selected_phases=reports)
    c.close()
    assert ident(db) == db_identity
    return result


def main():
    arms = {arm: arm_report(arm) for arm in ['auto', 'llama']}
    diffs = [dict(phase=i, auto=a['predicted_id'], llama=b['predicted_id']) for i, (a, b) in enumerate(zip(arms['auto']['phases'], arms['llama']['phases'])) if a['predicted_id'] != b['predicted_id']]
    brief = {}
    for arm, a in arms.items():
        selected = [a['selected_phases'][name] for name in ['decode1', 'decode2']]
        instantiates = [r['API_categories'].get('graph_instantiate', {}) for r in selected]
        brief[arm] = dict(capture_recording_span_ns=[r['capture_recording_envelope_ns'] for r in selected],
                          capture_recording_span_sum_ns=sum(r['capture_recording_envelope_ns'] or 0 for r in selected),
                          instantiate_count=sum(r.get('count', 0) for r in instantiates),
                          instantiate_cumulative_ns=sum(r.get('cumulative_ns', 0) for r in instantiates),
                          allocation_API_placement=[r['allocation_API_placement'] for r in selected],
                          major_recorded_GPU_gap_ns=[r['longest_recorded_GPU_gaps'][0]['duration_ns'] for r in selected],
                          native_kernel_count=a['selected_phases']['first_two_M1']['native_kernel_count'],
                          native_kernel_busy_union_ns=a['selected_phases']['first_two_M1']['native_kernel_busy_union_ns'],
                          recorded_all_GPU_activity_union_ns=a['selected_phases']['first_two_M1']['recorded_kernel_copy_memset_busy_union_ns'],
                          host_token_API_envelope_ns=a['selected_phases']['first_two_M1']['host_token_API_envelope_ns'])
    report = dict(schema='hyle.first-decode.cuda-node-attribution.v1', status='read_only_trace_attribution_not_throughput',
                  actions=dict(GPU_runs=0, model_runs=0, builds=0, SQLite='mode=ro; query_only=ON'),
                  script=ident(__file__), capture_plan=read(P/'traces/plan.json'),
                  reused_analyzer_sources=[ident(D/'cached16-trace/analyze.py'), ident(D/'auto-replay-policy/analyze_first_decode_cost.py')],
                  phase_mapping='17 ordered actual host-visible token returns are joined by runtime correlation, matched to ANALYSIS_FILE model logs and peer JSON. T16 is ordinal1/visible144, first M1 ordinal2/visible145, second M1 ordinal3/visible146.',
                  graph_deduplication='Read each native kernel/memcpy/memset table once; drop only export rows identical across every field. Do not collapse repeated executions by graphNodeId. Never add CUDA_GRAPH_NODE_EVENTS creation/clone metadata or graph envelopes to kernel cumulative durations. GPU unions merge node/direct intervals across streams.',
                  units='All detailed durations are integer ns; memcpy counters are integer bytes. Logged CPU timers were printed decimals and retain that precision limit.',
                  same_phase_prediction_differences=diffs, first_two_M1_summary=brief, arms=arms,
                  limits=['CUDA node/all-API instrumentation perturbs host scheduling, launch timing, capture, module loading and GPU execution; these times are not no-profiler TPS or predicted removable savings.',
                          'Host-token API brackets include inter-phase logging/snapshots and exclude final CPU bookkeeping; source step timers are separate. Kernel/API inclusive sums overlap and are not additive to full step time.',
                          'Only recorded activities of this process/device are measured. GPU union is not global utilization or PMU busy; unrecorded work may make it a lower bound. No CPU sampling means uninstrumented host work and gap causes remain unknown.',
                          'GraphTrace may be absent in node mode. Native graph-node kernels/copies are included directly; absence of an envelope table is not evidence of no graph execution.',
                          'First-use module/capture/instantiate differences are observations. The two traces have different internal engine boundaries and profiler overhead; do not treat their gaps or API durations as causal no-profile improvements.'])
    out = P/'analysis.json'
    out.write_text(json.dumps(report, indent=2, allow_nan=False)+'\n', encoding='utf-8')
    print(json.dumps(dict(output=ident(out), phases={arm: {name: dict(kernels=r['native_kernel_count'],
                         kernel_cumulative_ms=r['native_kernel_cumulative_clipped_ns']/1e6,
                         kernel_union_ms=r['native_kernel_busy_union_ns']/1e6,
                         all_GPU_union_ms=r['recorded_kernel_copy_memset_busy_union_ns']/1e6,
                         host_bracket_ms=r['host_token_API_envelope_ns']/1e6,
                         logged_step_ms=r['summed_logged_step_ns']/1e6)
                         for name, r in a['selected_phases'].items()} for arm, a in arms.items()}), indent=2))


if __name__ == '__main__':
    main()
