"""Focused native-owner regression and one finite short-window comparison."""
from pathlib import Path
import importlib.util
import statistics
import sys
import xml.etree.ElementTree as ET

sys.dont_write_bytecode = True
P = Path(__file__).resolve().parent
F = P.parent
D = F.parent
spec = importlib.util.spec_from_file_location('native_fix_previous_auto_validation', D / 'auto_replay_run.py')
a = importlib.util.module_from_spec(spec)
spec.loader.exec_module(a)
r = a.r
READY = r.read(P / 'ready-for-root.json')
IMAGE = READY['image']
BASELINE = r.read(D / 'auto-replay-policy/ready-for-root.json')['image']
assert r.identity(IMAGE['path']) == IMAGE
assert r.identity(BASELINE['path']) == BASELINE


def smoke():
    a.P = P / 'validation'
    a.P.mkdir(exist_ok=False)
    a.IMAGE = IMAGE
    r.save(a.P / 'inputs.json', dict(driver=r.identity(__file__), previous_driver=r.identity(D / 'auto_replay_run.py'),
                                    baseline=BASELINE, image=IMAGE,
                                    scope='Same default-auto64 original vectors; only two current native owner TUs replaced.'))
    a.smoke()


def timing():
    assert r.read(P / 'validation/correctness/summary.json')['passed']
    out = P / 'validation/short-timing'
    out.mkdir(exist_ok=False)
    previous = r.read(D / 'auto-replay-policy/short-timing/runs.json')
    hc = next(x for x in previous if x['arm'] == 'auto')['process']['command'].copy()
    pc = next(x for x in previous if x['arm'] == 'llama')['process']['command'].copy()
    images = dict(baseline=BASELINE, candidate=IMAGE, llama=r.identity(pc[0]))
    order = ['baseline', 'candidate', 'llama', 'llama', 'baseline', 'candidate', 'candidate', 'llama', 'baseline']
    r.save(out / 'inputs.json', dict(images=images, order=order, source=r.identity(__file__),
                                   profiler=False, external_memory_observer=False, builds_during_window=False,
                                   window='Same original128 prefix+31 singleton teacher-forced inputs, context256; complete host-token step',
                                   precision_limit='Same original BF16 weights; Hyle/peer intermediate arithmetic and sampled-logit transfer differ.',
                                   page_cache='Uncontrolled OS cache; not cold disk'))
    runs = []
    for i, arm in enumerate(order, 1):
        tag = f'{i:02}-{arm}'
        command = (pc if arm == 'llama' else hc).copy()
        command[0] = images[arm]['path']
        if arm == 'llama':
            command[-1] = str(out / (tag + '-peer-result.json'))
        process = r.execute(out, tag, command)
        if arm == 'llama':
            raw = r.read(command[-1])
            obs = dict(raw=raw, phases=raw['phases'], loading=raw['loading'])
        else:
            obs = r.hyle_observation(out, tag)
        rows = obs['phases']
        assert [x['visible_tokens'] for x in rows] == list(range(128, 160))
        t = [x['step_seconds'] for x in rows]
        metrics = dict(prefill_tokens_per_second=128 / t[0],
                       full_decode_tokens_per_second=31 / sum(t[1:]),
                       stable_decode_tokens_per_second=25 / sum(t[7:]),
                       first_two_decode_ms=sum(t[1:3]) * 1000)
        print('  native fix', {k: round(v, 3) for k, v in metrics.items()}, flush=True)
        runs.append(dict(tag=tag, arm=arm, process=process, observation=obs, metrics=metrics,
                         predictions=[x['predicted_id'] for x in rows]))
        r.save(out / 'runs.json', runs)
    ids = next(x['predictions'] for x in runs if x['arm'] == 'baseline')
    same = all(x['predictions'] == ids for x in runs if x['arm'] != 'llama')
    groups = {arm: {k: dict(samples=[x['metrics'][k] for x in runs if x['arm'] == arm],
                           median=statistics.median(x['metrics'][k] for x in runs if x['arm'] == arm))
                    for k in runs[0]['metrics']} for arm in images}
    r.save(out / 'summary.json', dict(passed=same, groups=groups, Hyle_predictions_equal=same,
                                     processes=9, fresh_processes_per_arm=3,
                                     statistical_significance=False, independent_model_quality_acceptance=False))
    assert same


def tests():
    out = P / 'validation/native-tests'
    out.mkdir(exist_ok=False)
    ready = r.read(P / 'tests-ready-for-root.json')
    assert r.identity(ready['image']['path']) == ready['image']
    command = ready['suggested_command'].copy()
    command[-1] = '--gtest_output=xml:' + str(out / 'results.xml')
    process = r.execute(out, 'tests', command)
    cases = ET.parse(out / 'results.xml').findall('.//testcase')
    names = [x.get('classname') + '.' + x.get('name') for x in cases]
    passed = len(cases) == ready['expected_cases'] and all(x.find('failure') is None and x.find('skipped') is None for x in cases)
    r.save(out / 'summary.json', dict(passed=passed, cases=len(cases), names=names,
                                     process=process, builds=0, skipped=sum(x.find('skipped') is not None for x in cases)))
    assert passed
    print('FIVE_NATIVE_OWNER_CASES_PASS', flush=True)


if __name__ == '__main__':
    {'smoke': smoke, 'timing': timing, 'tests': tests}[sys.argv[1]]()
