"""Only two current native capture owners + unchanged Auto consumer link; no GPU."""
from pathlib import Path
import concurrent.futures
import importlib.util
import json
import os
import sys

sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
D = S.parents[1]
A = D.parent
R = A.parents[1]
spec = importlib.util.spec_from_file_location('d4_capture_fix_helpers', D / 'build.py')
h = importlib.util.module_from_spec(spec)
spec.loader.exec_module(h)
b, c = h.b, h.c


def same(row):
    return all(b.identity(row['path'])[k] == row[k] for k in ('bytes', 'sha256'))


def compile_one(job):
    tag, source, recipe_path = job
    recipe = c.read(recipe_path)
    out = S / 'checks/attempt1' / tag
    out.mkdir(parents=True, exist_ok=True)
    (out / 'tmp').mkdir(exist_ok=True)
    assert not (out / 'compile.result.json').exists(), 'Preserve actual attempts.'
    frozen = b.identity(source)
    command = b.host_command(recipe['command'], source, tag, out)
    assert all(flag in command for flag in ('/WX', '/W4', '/MD', '/O2'))
    env, _ = b.environment(command, [], out)
    c.save(out / 'compile-plan.json', dict(command=command, source=frozen,
        original_recipe=b.identity(recipe_path), GPU_runs=0, SDK_builds=0))
    c.execute('compile', command, env, out)
    deps_path = out / (tag + '-deps.json')
    deps = c.read(deps_path)['Data']
    dependencies = [b.identity(p) for p in dict.fromkeys([deps['Source'], *deps['Includes']])]
    assert same(frozen) and all(same(x) for x in dependencies)
    row = dict(source=frozen, object=b.identity(out / (tag + '.obj')),
        original_recipe=b.identity(recipe_path), command=command,
        replaced_object=recipe['object'], source_dependencies=b.identity(deps_path),
        dependencies=dependencies, dependency_drift=0, GPU_runs=0, SDK_builds=0)
    c.save(out / 'identity.json', row)
    print('COMPILED', tag, flush=True)
    return row


def main():
    base_path = D / 'auto-replay-policy/checks/attempt1/link-plan.json'
    base = c.read(base_path)
    assert len(base['inputs']) == 190 and all(same(x) for x in base['inputs'])
    jobs = [
        ('backend', R / 'src/compute_backend_cuda/cuda_backend.cc',
         A / 'cuda-capture-reuse/validation/cuda-backend-v2-identity.json'),
        ('provider', R / 'src/compute_provider_ggml_cuda/ggml_cuda_provider.cc',
         D / 'checks/attempt1/provider/identity.json')]
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
        rows = list(pool.map(compile_one, jobs))
    replace = {c.key(row['replaced_object']['path']): row['object'] for row in rows}
    assert all(sum(c.key(x['path']) == old for x in base['inputs']) == 1 for old in replace)
    inputs = [replace.get(c.key(x['path']), x) for x in base['inputs']]
    out = S / 'checks/attempt1/link'
    out.mkdir(parents=True, exist_ok=True)
    (out / 'tmp').mkdir(exist_ok=True)
    assert not (out / 'link.result.json').exists(), 'Preserve actual attempts.'
    image = out / 'qwen.exe'
    command = [replace[c.key(x)]['path'] if c.key(x) in replace else x
        for x in base['command']
        if not x.upper().startswith(('/OUT:', '/MAP:', '/IMPLIB:', '/PDB:'))]
    command += ['/OUT:' + str(image), '/MAP:' + str(image.with_suffix('.map')),
                '/IMPLIB:' + str(image.with_suffix('.lib'))]
    actual = [x for x in command if Path(x).is_absolute() and Path(x).suffix.lower() in ('.obj', '.lib')]
    assert list(map(c.key, actual)) == [c.key(x['path']) for x in inputs]
    assert len(inputs) == 190 and all(same(x) for x in inputs)
    c.save(out / 'link-plan.json', dict(command=command, inputs=inputs,
        base=b.identity(base_path), replacements=rows,
        CXX=2, links=1, NVCC=0, SDK_builds=0, GPU_runs=0))
    env, runtime = b.environment(command, [x['path'] for x in inputs], out)
    c.execute('link', command, env, out)
    modules = []
    for row in c.read(D / 'auto-replay-policy/checks/attempt1/runtime-environment.json')['staged_CPU_modules']:
        original = Path(row['destination']['path'])
        target = out / original.name
        assert same(row['destination'])
        if not target.exists():
            os.link(original, target)
        assert os.path.samefile(original, target)
        modules.append(dict(source=b.identity(original), destination=b.identity(target), hardlink=True))
    c.save(out / 'runtime-environment.json', dict(PATH=env['PATH'], runtime=runtime,
        staged_CPU_modules=modules))
    c.save(S / 'ready-for-root.json', dict(status='native_capture_two_owner_fix_compiled_linked_not_run',
        image=b.identity(image), link_plan=b.identity(out / 'link-plan.json'),
        runtime_environment=b.identity(out / 'runtime-environment.json'),
        previous_image=b.identity(D / 'auto-replay-policy/checks/attempt1/qwen.exe'),
        source_freeze=b.identity(S / 'source-freeze.json'),
        compiles=[b.identity(S / 'checks/attempt1' / tag / 'identity.json') for tag, _, _ in jobs],
        CXX=2, links=1, NVCC=0, SDK_builds=0, GPU_runs=0,
        limits='Build-only. Original per-Invocation graphExecs/status ownership/retirement retained; no speed or runtime-correctness claim yet.'))
    print('READY', image, flush=True)


if __name__ == '__main__':
    main()
