"""Build the focused original backend status/lifetime tests; never execute GPU."""
from pathlib import Path
import concurrent.futures
import importlib.util
import os
import sys

sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('native_capture_fix_build', S / 'build.py')
h = importlib.util.module_from_spec(spec)
spec.loader.exec_module(h)
b, c, R, A, D = h.b, h.c, h.R, h.A, h.D


def compile_test(tag, source):
    recipe_path = A / 'cuda-capture-reuse/validation/cuda-backend-v2-identity.json'
    recipe = c.read(recipe_path)
    template = [x for x in recipe['command'] if x != '/DHYLE_COMPUTE_BACKEND_CUDA_BUILD']
    gtest = R / '.scratch/build-compute-v2-dev/lib/gtest.lib'
    wrapper_recipe = c.read(A / 'quark-block128-scale-2026-10-21/windows/checks/attempt1/cuda-scale-policy-test/identity.json')
    template += [x for x in wrapper_recipe['command'] if x.startswith('/external:I') and 'googletest' in x]
    out = S / 'tests/attempt1' / tag
    out.mkdir(parents=True, exist_ok=True)
    (out / 'tmp').mkdir(exist_ok=True)
    assert not (out / 'compile.result.json').exists()
    command = b.host_command(template, source, tag, out)
    env, _ = b.environment(command, [str(gtest)], out)
    frozen = b.identity(source)
    c.save(out / 'compile-plan.json', dict(command=command, source=frozen,
        recipe=b.identity(recipe_path), gtest_include_recipe=b.identity(A / 'quark-block128-scale-2026-10-21/windows/checks/attempt1/cuda-scale-policy-test/identity.json')))
    c.execute('compile', command, env, out)
    deps_path = out / (tag + '-deps.json')
    deps = c.read(deps_path)['Data']
    dependencies = [b.identity(p) for p in dict.fromkeys([deps['Source'], *deps['Includes']])]
    assert h.same(frozen) and all(h.same(x) for x in dependencies)
    row = dict(source=frozen, object=b.identity(out / (tag + '.obj')),
        command=command, dependencies=dependencies, source_dependencies=b.identity(deps_path),
        dependency_drift=0, GPU_runs=0)
    c.save(out / 'identity.json', row)
    print('COMPILED', tag, flush=True)
    return row


def compile_kernel():
    source = R / 'tests/compute_backend_cuda/cuda_test_kernel.cu'
    out = S / 'tests/attempt1/kernel'
    out.mkdir(parents=True, exist_ok=True)
    (out / 'tmp').mkdir(exist_ok=True)
    assert not (out / 'compile.result.json').exists()
    cuda = Path('C:/Program Files/NVIDIA GPU Computing Toolkit/CUDA/v13.3')
    obj = out / 'cuda-test-kernel.obj'
    depfile = out / 'cuda-test-kernel.d'
    compiler = c.read(A / 'cuda-capture-reuse/validation/cuda-backend-v2-identity.json')['command'][0]
    command = [str(cuda / 'bin/nvcc.exe'), '-forward-unknown-to-host-compiler',
        '-ccbin', str(Path(compiler).parent), '-DHYLE_COMPUTE_CUDA=1', '-DHYLE_STATIC',
        '-D_WINDOWS', '-Xcompiler=/EHsc', '-Xcompiler=-O2', '-Xcompiler=-Ob2',
        '-DNDEBUG', '-std=c++17', '--generate-code=arch=compute_89,code=[compute_89,sm_89]',
        '-Xcompiler=-MD', '-Xcompiler=/utf-8', '-Xcompiler=/wd4211',
        '-I' + str(R / 'src/compute_backend_cuda'), '-I' + str(R / 'include'),
        '-MD', '-MT', str(obj), '-MF', str(depfile), '-x', 'cu', '-c', str(source), '-o', str(obj)]
    # Environment derives from the authenticated same-toolchain CXX recipe.
    env, _ = b.environment([compiler], [], out)
    frozen = b.identity(source)
    c.save(out / 'compile-plan.json', dict(command=command, source=frozen,
        native_recipe=dict(build_ninja=b.identity(R / '.scratch/build-compute-v2-dev/build.ninja'),
            target='tests/compute_backend_cuda/CMakeFiles/hyle_compute_backend_cuda_test.dir/cuda_test_kernel.cu.obj',
            preserved_flags='Release C++17 sm89/PTX89 /MD UTF-8 /wd4211; no fast-math'),
        GPU_runs=0, SDK_builds=0))
    c.execute('compile', command, env, out)
    assert h.same(frozen)
    row = dict(source=frozen, object=b.identity(obj), command=command,
        dependency_file=b.identity(depfile), toolchain=[b.identity(cuda / 'bin/nvcc.exe')],
        GPU_runs=0, SDK_builds=0)
    c.save(out / 'identity.json', row)
    return row


def main():
    jobs = [('device-status-test', R / 'tests/compute_backend_cuda/device_status_test.cc'),
            ('native-retirement-test', R / 'tests/compute_backend_cuda/native_retirement_test.cc')]
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
        rows = list(pool.map(lambda x: compile_test(*x), jobs))
    rows.append(compile_kernel())
    base_path = S / 'checks/attempt1/link/link-plan.json'
    base = c.read(base_path)
    old_main = c.read(D / 'auto-replay-policy/checks/attempt1/identity.json')['object']
    assert all(h.same(x) for x in base['inputs'])
    gtests = [x for x in c.read(D / 'preparation-plan.json')['remove_test_inputs'] if x['path'].endswith(('gtest.lib', 'gtest_main.lib'))]
    assert len(gtests) == 2 and all(h.same(x) for x in gtests)
    fresh = [row['object'] for row in rows] + gtests
    inputs = [x for x in base['inputs'] if c.key(x['path']) != c.key(old_main['path'])] + fresh
    assert len(inputs) == 194
    out = S / 'tests/attempt1/link'
    out.mkdir(parents=True, exist_ok=True)
    (out / 'tmp').mkdir(exist_ok=True)
    assert not (out / 'link.result.json').exists()
    image = out / 'native-capture-tests.exe'
    command = [x for x in base['command'] if c.key(x) != c.key(old_main['path']) and not x.upper().startswith(('/OUT:', '/MAP:', '/IMPLIB:', '/PDB:'))]
    command += [x['path'] for x in fresh]
    command += ['/OUT:' + str(image), '/MAP:' + str(image.with_suffix('.map')), '/IMPLIB:' + str(image.with_suffix('.lib'))]
    env, runtime = b.environment(command, [x['path'] for x in inputs], out)
    c.save(out / 'link-plan.json', dict(command=command, inputs=inputs, base=b.identity(base_path),
        removed_main=old_main, fresh_test_objects=rows, gtest_libraries=gtests, GPU_runs=0, SDK_builds=0))
    c.execute('link', command, env, out)
    modules = []
    for row in c.read(S / 'checks/attempt1/link/runtime-environment.json')['staged_CPU_modules']:
        original = Path(row['destination']['path'])
        target = out / original.name
        assert h.same(row['destination'])
        if not target.exists():
            os.link(original, target)
        assert os.path.samefile(original, target)
        modules.append(dict(source=b.identity(original), destination=b.identity(target), hardlink=True))
    c.save(out / 'runtime-environment.json', dict(PATH=env['PATH'], runtime=runtime, staged_CPU_modules=modules))
    filters = ['CudaDeviceStatus.PureArtifactsSurviveCheckedStatusStorageHandoff',
        'CudaDeviceStatus.PureCaptureAndPrefixAddNoStatusCommands',
        'CudaDeviceStatus.CapturedStatusRejectsOverlappingReuseAndAbortIsClean',
        'CudaDeviceStatus.ColdMetadataOomRollsBackPoolAndNativeCapturedStorage',
        'CudaNativeRetirement.RootFenceAndObservationErrorsDoNotReleaseNativeOwner']
    c.save(S / 'tests-ready-for-root.json', dict(status='focused_tests_built_not_run',
        image=b.identity(image), link_plan=b.identity(out / 'link-plan.json'),
        runtime_environment=b.identity(out / 'runtime-environment.json'),
        suggested_command=[str(image), '--gtest_filter=' + ':'.join(filters), '--gtest_output=xml:tests.xml'],
        expected_cases=len(filters), CXX=2, small_test_NVCC=1, links=1, SDK_builds=0, GPU_runs=0,
        scope='One new pure/checked handoff and old-result error-recovery journey; original pure/abort/OOM/native-lifetime neighbors. Native GGML same-chain fast path additionally needs original Qwen execution.'))
    print('TESTS READY', image, flush=True)


if __name__ == '__main__':
    main()
