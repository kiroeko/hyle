"""One candidate node trace; no throughput inference from instrumented time."""
from pathlib import Path
import importlib.util
import sys

sys.dont_write_bytecode = True
P = Path(__file__).resolve().parent
F = P.parent
spec = importlib.util.spec_from_file_location('current_native_trace_base', F / 'capture.py')
c = importlib.util.module_from_spec(spec)
spec.loader.exec_module(c)
r = c.r
out = P / 'traces/auto'
out.mkdir(parents=True, exist_ok=False)
ready = r.read(P / 'ready-for-root.json')
image = ready['image']
assert r.identity(image['path']) == image
runs = r.read(F.parent / 'auto-replay-policy/cached16-timing/runs.json')
command = next(x for x in runs if x['arm'] == 'auto')['process']['command'].copy()
command[0] = image['path']
r.save(out / 'model-command.json', dict(command=command, image=image,
                                      instrumented=True, throughput_evidence=False))
profile = [str(c.NSYS), 'profile', '--trace=cuda', '--sample=none', '--cpuctxsw=none',
           '--cuda-trace-all-apis=true', '--cuda-graph-trace=node:host-only',
           '--discard-environment=true', '--force-overwrite=false',
           '--output=' + str(out / 'capture'), *command]
r.execute(out, 'profile', profile)
r.execute(out, 'export', [str(c.NSYS), 'export', '--type=sqlite', '--force-overwrite=false',
                          '--output=' + str(out / 'capture.sqlite'), str(out / 'capture.nsys-rep')])
r.save(out / 'receipt.json', dict(report=r.identity(out / 'capture.nsys-rep'),
                                 sqlite=r.identity(out / 'capture.sqlite'), image=image,
                                 instrumented=True, throughput_evidence=False))
spec = importlib.util.spec_from_file_location('current_native_node_analyzer', F / 'analyze.py')
a = importlib.util.module_from_spec(spec)
spec.loader.exec_module(a)
a.P = P
a.EXPECTED['auto'] = image['sha256']
report = a.arm_report('auto')
r.save(P / 'node-analysis.json', report)
print('CANDIDATE_NODE_TRACE_ANALYZED', flush=True)
