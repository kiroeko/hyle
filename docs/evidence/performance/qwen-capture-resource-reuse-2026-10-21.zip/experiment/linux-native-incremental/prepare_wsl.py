"""Selected-source audit, reversible two-CPP sync and Ninja dry-run only."""
from pathlib import Path
import hashlib
import json
import os
import re
import shutil
import subprocess
import time

R = Path('/mnt/c/public/project-hyle/hyle')
A = R/'.scratch/architecture-refactor-2026-10-18'
P = A/'d4-windows-preparation-2026-10-21/first-decode-startup-2026-10-21/linux-native-incremental'
B = A/'delivery1-linux-current-build-2026-10-21'
WORK = Path('/root/hyle-scratch/active-cpu-z')
SOURCE, BUILD = WORK/'source', WORK/'build'
REMOTE = WORK/'d4-first-decode-native-incremental-2026-10-21'
PREFIX = WORK/'delivery1-linux-current-build-2026-10-21/static-sdk-relocated'
CONSUMERS = WORK/'delivery1-linux-current-build-2026-10-21'
OWNED = {'src/compute_backend_cuda/cuda_backend.cc', 'src/compute_provider_ggml_cuda/ggml_cuda_provider.cc'}
OUT_OF_ROUTE = {'include/hyle/graph/apple.h', 'src/compute_route_apple/apple_tensor.h',
                'src/graph_route_apple/apple_lowering_internal.h'}


def save(name, value):
    (P/name).write_text(json.dumps(value, indent=2)+'\n')


def ident(path):
    path = Path(path)
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(4 << 20), b''):
            digest.update(block)
    return dict(path=str(path), bytes=path.stat().st_size, sha256=digest.hexdigest())


def execute(tag, command, cwd):
    row = dict(command=command, cwd=str(cwd), started=time.time(), builds=0, GPU_runs=0)
    save(tag+'.command.json', row)
    process = subprocess.run(command, cwd=cwd, capture_output=True, text=True)
    (P/(tag+'.stdout.log')).write_text(process.stdout)
    (P/(tag+'.stderr.log')).write_text(process.stderr)
    row.update(exit_code=process.returncode, finished=time.time())
    save(tag+'.result.json', row)
    assert process.returncode == 0, (tag, process.stderr)
    return process.stdout


def main():
    assert not (P/'plan.json').exists(), 'Preserve prior plan; use a new attempt if needed'
    assert SOURCE.is_dir() and BUILD.is_dir() and PREFIX.is_dir()
    assert not (WORK/'delivery1-linux-current-2026-10-21/static-sdk-installed').exists()
    before_audit = json.loads((B/'current-selected-source-audit.json').read_text())
    names = [r['relative'] for r in before_audit['files']]
    # The later Apple-only installation fix is outside this selected route.
    # Verify its complete byte delta before classifying, never blanket-ignore
    # arbitrary future CMake changes or overwrite the validation source.
    cmake_name = 'cmake/HyleComponents.cmake'
    old_cmake, new_cmake = (SOURCE/cmake_name).read_bytes(), (R/cmake_name).read_bytes()
    old_block = '_hyle_declare_component(graph_route_apple\n  TRACE\n  PRIVATE_DEPS graph_batch compute mem util_core\n'
    new_block = '_hyle_declare_component(graph_route_apple\n  TRACE\n  PRIVATE_DEPS graph_batch compute container mem util_core\n'
    assert old_cmake.count(old_block.encode()) == 1 and old_cmake.replace(old_block.encode(), new_block.encode()) == new_cmake
    OUT_OF_ROUTE.add(cmake_name)
    save('Apple-only-CMake-difference.json', dict(path=cmake_name, complete_delta_verified=True,
          previous=old_block, current=new_block, synced=False,
          reason='Only graph_route_apple private dependency metadata; neither configured route uses that component.'))
    rows = []
    for name in names:
        authoritative, copied = ident(R/name), ident(SOURCE/name)
        rows.append(dict(relative=name, Windows=authoritative, Linux=copied,
                         equal=authoritative['sha256'] == copied['sha256']))
    drift = [r for r in rows if not r['equal'] and r['relative'] not in OUT_OF_ROUTE]
    out = [r for r in rows if not r['equal'] and r['relative'] in OUT_OF_ROUTE]
    save('source-audit-before.json', dict(selected_files=len(rows), selected_CPU_CUDA_drift=drift,
          Apple_only_out_of_route_drift=out, files=rows, scope='Original compute;graph;graph_progress / cpu;cuda selected installation closure, not all repository files.'))
    assert {r['relative'] for r in drift} == OWNED, [r['relative'] for r in drift]
    REMOTE.mkdir(parents=True, exist_ok=False)
    backups = []
    for name in sorted(OWNED):
        target = SOURCE/name
        assert not target.is_symlink() and str(target.resolve()).startswith(str(SOURCE.resolve())+'/')
        backup = REMOTE/'before'/name
        backup.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(target, backup)
        previous = ident(target)
        assert previous['sha256'] == ident(backup)['sha256']
        shutil.copyfile(R/name, target)
        current = ident(target)
        assert current['sha256'] == ident(R/name)['sha256']
        backups.append(dict(relative=name, previous=previous, backup=ident(backup), current=current))
    save('two-source-sync.json', dict(files=backups, fixed_backup_root=str(REMOTE/'before'),
                                    reverse_sync=False, SDK_copies=0, unrelated_files_changed=0))
    after = []
    for row in rows:
        name = row['relative']
        if name in OUT_OF_ROUTE:
            continue
        assert ident(R/name)['sha256'] == ident(SOURCE/name)['sha256'], name
        after.append(name)
    save('source-audit-after.json', dict(selected_files=len(names), current_CPU_CUDA_files=len(after),
          selected_CPU_CUDA_drift=0, Apple_only_out_of_route_names=sorted(OUT_OF_ROUTE),
          exactly_synced_files=sorted(OWNED), no_all_repository_current_claim=True))
    cache = (BUILD/'CMakeCache.txt').read_text()
    wanted = ['CMAKE_CXX_COMPILER', 'CMAKE_CUDA_COMPILER', 'CMAKE_CUDA_ARCHITECTURES', 'CMAKE_BUILD_TYPE',
              'CMAKE_INSTALL_PREFIX', 'HYLE_COMPONENTS', 'HYLE_COMPUTE_ROUTES', 'HYLE_STATIC',
              'HYLE_INSTALL', 'HYLE_BUILD_TESTS', 'FETCHCONTENT_FULLY_DISCONNECTED']
    cache_values = {key: re.search(r'^'+key+r':[^=]*=(.*)$', cache, re.M).group(1) for key in wanted}
    assert cache_values['HYLE_COMPONENTS'] == 'compute;graph;graph_progress'
    assert cache_values['HYLE_COMPUTE_ROUTES'] == 'cpu;cuda'
    save('cache-facts.json', dict(source=str(SOURCE), build=str(BUILD), relocated_prefix=str(PREFIX),
          cache_values=cache_values, disk=dict(zip(['total_bytes', 'used_bytes', 'free_bytes'], shutil.disk_usage(WORK))),
          producer_cache=ident(BUILD/'CMakeCache.txt'), build_ninja=ident(BUILD/'build.ninja'),
          installed_changed_archives=[ident(PREFIX/'lib'/name) for name in
              ['libhyle_compute_backend_cuda.a', 'libhyle_compute_provider_ggml_cuda.a']]))
    commands = json.loads((BUILD/'compile_commands.json').read_text())
    selected = [r for r in commands if any(r['file'] == str(SOURCE/name) for name in OWNED)]
    assert len(selected) == 2
    save('selected-existing-recipes.json', selected)
    dry = execute('producer-dryrun', ['ninja', '-n', '-v', 'all'], BUILD)
    jobs = [m.group(1) for line in dry.splitlines() if (m := re.match(r'^\[\d+/\d+\] (.*)$', line))]
    cxx = [r for r in jobs if ' -c ' in r and any(str(SOURCE/name) in r for name in OWNED)]
    archives = [r for r in jobs if '/ar qc ' in r or '/ar q ' in r or '/ar cr ' in r]
    unexpected = [r for r in jobs if r not in cxx and r not in archives]
    save('producer-job-classification.json', dict(jobs=len(jobs), CXX=len(cxx), archive_links=len(archives),
          CUDA_NVCC_jobs=sum('nvcc' in r for r in jobs), unexpected_jobs=unexpected,
          SDK_rebuild_jobs=0 if not unexpected else None, full_commands=jobs))
    assert len(jobs) == 4 and len(cxx) == len(archives) == 2 and not unexpected, jobs
    consumers = []
    for name, directory, executable in [('cpp', 'consumer-cpp2', 'hyle_package_graph_cpp'),
                                         ('cpu_cuda', 'consumer-cpu_cuda', 'hyle_cpu_cuda_sample')]:
        folder = CONSUMERS/directory
        image = folder/executable
        assert image.is_file()
        actual = execute('consumer-'+name+'-commands', ['ninja', '-t', 'commands'], folder)
        assert str(PREFIX/'lib/libhyle_compute_backend_cuda.a') in actual
        assert str(PREFIX/'lib/libhyle_compute_provider_ggml_cuda.a') in actual
        assert str(PREFIX/'include') in actual
        dry = execute('consumer-'+name+'-dryrun-before-install', ['ninja', '-n'], folder)
        assert 'no work to do' in dry
        ldd = execute('consumer-'+name+'-ldd', ['ldd', str(image)], folder)
        assert 'not found' not in ldd
        consumers.append(dict(name=name, directory=str(folder), executable=ident(image),
                               current_dryrun_jobs=0, ldd_missing_libraries=0,
                               future='Both link commands directly depend on these two installed archives. After installation, expect one relink per consumer by mtime; confirm with a fresh dry-run, not yet executed.'))
    plan = dict(status='two_CPP_synced_four_jobs_dryrun_only_waiting_Windows_correctness',
                source=str(SOURCE), build=str(BUILD), products='compute;graph;graph_progress', routes='cpu;cuda',
                selected_source_files=len(names), selected_CPU_CUDA_drift_after_sync=0,
                out_of_route_Apple_files_not_synced=sorted(OUT_OF_ROUTE),
                reversible_source_sync=backups, actual_producer_dryrun=dict(CXX=2, archive_links=2, NVCC=0, SDK_jobs=0, total=4),
                consumers=consumers, next_commands_after_root_approval=[
                    ['cmake', '--build', str(BUILD), '--parallel', '2'],
                    ['cmake', '--install', str(BUILD), '--prefix', str(PREFIX)],
                    ['cmake', '--build', str(CONSUMERS/'consumer-cpp2'), '--parallel', '2'],
                    ['cmake', '--build', str(CONSUMERS/'consumer-cpu_cuda'), '--parallel', '2']],
                install_note='Use the existing relocated prefix explicitly. Do not recreate the old configured prefix or copy SDK directories. No reconfigure is planned.',
                actions=dict(actual_builds=0, installs=0, consumer_relinks=0, GPU_runs=0))
    save('plan.json', plan)
    print(json.dumps(dict(status=plan['status'], dryrun=plan['actual_producer_dryrun'],
                          current_source_drift=0, consumers=len(consumers), plan=str(P/'plan.json')), indent=2))


if __name__ == '__main__':
    main()
