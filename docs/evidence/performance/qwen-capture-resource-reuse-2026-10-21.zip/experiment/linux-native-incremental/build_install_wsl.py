"""Authorized two-CPP producer refresh and existing installed-consumer relinks."""
from pathlib import Path
import importlib.util
import json
import os
import re
import subprocess
import sys
import time

sys.dont_write_bytecode = True
spec = importlib.util.spec_from_file_location('local_incremental_paths', Path(__file__).with_name('prepare_wsl.py'))
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)
read = lambda p: json.loads(Path(p).read_text())
plan = read(m.P/'plan.json')
assert plan['actual_payload_dryrun'] == dict(CXX=2, archive_links=2, NVCC=0, SDK_jobs=0, total=4)


def run(tag, command, cwd):
    assert not (m.P/(tag+'.result.json')).exists(), 'Preserve actual prior result'
    row = dict(command=command, cwd=str(cwd), started=time.time(), GPU_runs=0)
    m.save(tag+'.command.json', row)
    with (m.P/(tag+'.stdout.log')).open('wb') as out, (m.P/(tag+'.stderr.log')).open('wb') as err:
        child = subprocess.Popen(command, cwd=cwd, stdin=subprocess.DEVNULL, stdout=out, stderr=err)
        row['pid'] = child.pid
        m.save(tag+'.live.json', row)
        code = child.wait()
    row.update(exit_code=code, seconds=time.time()-row['started'])
    m.save(tag+'.result.json', row)
    print(json.dumps(dict(tag=tag, exit_code=code, seconds=row['seconds'])), flush=True)
    assert code == 0, tag
    return (m.P/(tag+'.stdout.log')).read_text()


resume = '--resume-after-install' in sys.argv
prefix_inode = os.stat(m.PREFIX).st_ino
assert prefix_inode == read(m.B/'relocation.json')['directory_identity']['inode']
before = {Path(row['path']).name: row for row in read(m.P/'cache-facts.json')['installed_changed_archives']}
for row in plan['source_sync']['files']:
    assert m.ident(m.R/row['relative'])['sha256'] == m.ident(m.SOURCE/row['relative'])['sha256'] == row['current']['sha256']
if resume:
    assert read(m.P/'build.result.json')['exit_code'] == read(m.P/'install-relocated.result.json')['exit_code'] == 0
    build_log = (m.P/'build.stdout.log').read_text()
else:
    build_log = run('build', ['cmake', '--build', str(m.BUILD), '--parallel', '2'], m.WORK)
jobs = [line for line in build_log.splitlines() if re.match(r'^\[\d+/\d+\] ', line)]
cxx = [line for line in jobs if 'Building CXX object' in line]
archives = [line for line in jobs if 'Linking CXX static library' in line]
assert len(cxx) == len(archives) == 2 and not any('Building CUDA object' in line for line in jobs), jobs
m.save('actual-build-classification.json', dict(CXX=len(cxx), archive_links=len(archives), NVCC=0,
       SDK_build_jobs=0, payload_jobs=4, normal_CMake_glob_verification=[line for line in jobs if 'glob' in line.lower()],
       actual_job_lines=jobs))
if not resume:
    run('install-relocated', ['cmake', '--install', str(m.BUILD), '--prefix', str(m.PREFIX)], m.WORK)
assert os.stat(m.PREFIX).st_ino == prefix_inode
assert not (m.WORK/'delivery1-linux-current-2026-10-21/static-sdk-installed').exists()
archives_after = []
for name in before:
    built, installed = m.ident(m.BUILD/'bin'/name), m.ident(m.PREFIX/'lib'/name)
    assert built['sha256'] == installed['sha256']
    archives_after.append(dict(name=name, previous=before[name], current=installed, producer=built))
consumers = []
for row in plan['consumers']:
    name, folder = row['name'], Path(row['directory'])
    dry = m.execute('consumer-'+name+'-dryrun-after-install', ['ninja', '-n'], folder)
    pending = [line for line in dry.splitlines() if re.match(r'^\[\d+/\d+\] ', line)]
    assert len(pending) == 1 and 'Linking CXX executable' in pending[0], pending
    run('consumer-'+name+'-relink', ['cmake', '--build', str(folder), '--parallel', '2'], folder)
    after = m.ident(row['image']['path'])
    ldd = m.execute('consumer-'+name+'-ldd-after', ['ldd', after['path']], folder)
    assert 'not found' not in ldd
    clean = m.execute('consumer-'+name+'-clean-dryrun', ['ninja', '-n'], folder)
    assert 'no work to do' in clean
    consumers.append(dict(name=name, previous_image=row['image'], current_image=after, CXX=0, relinks=1,
                          missing_dynamic_dependencies=0, pending_jobs_after=0, executed=False))
snapshot = m.REMOTE/'post-build.snapshot.ninja'
assert not snapshot.exists()
snapshot.write_bytes((m.BUILD/'build.ninja').read_bytes())
post = m.execute('producer-post-build-dryrun', ['ninja', '-f', str(snapshot), '-n', 'all'], m.BUILD)
assert 'no work to do' in post
result = dict(status='current_two_CPP_built_installed_relocated_and_two_consumers_relinked_not_executed',
              source=str(m.SOURCE), build=str(m.BUILD), prefix=str(m.PREFIX), prefix_inode_unchanged=prefix_inode,
              old_prefix_exists=False, producer=dict(CXX=2, archive_links=2, NVCC=0, SDK_rebuilds=0, post_build_payload_jobs=0),
              installed_archives=archives_after, consumers=consumers, new_SDK_copies=0, GPU_runs=0,
              source_sync=plan['source_sync'], source_audit=plan['source_audit'],
              next='Root may run the two original relocated sample programs sequentially; no GPU/model/sample execution performed by this script.')
m.save('build-install-readiness.json', result)
print(json.dumps(dict(status=result['status'], producer=result['producer'], consumers=len(consumers), GPU_runs=0), indent=2))
