"""Resume the completed source sync; inspect a byte-identical Ninja snapshot."""
from pathlib import Path
import importlib.util
import json
import re

path = Path(__file__).resolve().with_name('prepare_wsl.py')
spec = importlib.util.spec_from_file_location('local_incremental_preparation', path)
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)
read = lambda p: json.loads(Path(p).read_text())

assert not (m.P/'plan.json').exists()
sync = read(m.P/'two-source-sync.json')
for row in sync['files']:
    name = row['relative']
    assert m.ident(m.SOURCE/name)['sha256'] == m.ident(m.R/name)['sha256'] == row['current']['sha256']
assert read(m.P/'source-audit-after.json')['selected_CPU_CUDA_drift'] == 0
snapshot = m.REMOTE/'producer-dryrun.snapshot.ninja'
assert not snapshot.exists()
snapshot.write_bytes((m.BUILD/'build.ninja').read_bytes())
old = read(m.B/'installed-readiness.json')['post_build_dryrun']['snapshot']
assert m.ident(snapshot)['sha256'] == old['sha256'], 'Unexpected build-graph change since the installed audit'
dry = m.execute('producer-payload-dryrun', ['ninja', '-f', str(snapshot), '-n', '-v', 'all'], m.BUILD)
jobs = [match.group(1) for line in dry.splitlines() if (match := re.match(r'^\[\d+/\d+\] (.*)$', line))]
cxx = [r for r in jobs if ' -c ' in r and any(str(m.SOURCE/name) in r for name in m.OWNED)]
archives = [r for r in jobs if '/ar qc ' in r or '/ar q ' in r or '/ar cr ' in r]
unexpected = [r for r in jobs if r not in cxx and r not in archives]
m.save('producer-payload-classification.json', dict(total=len(jobs), CXX=len(cxx), archive_links=len(archives),
       NVCC=sum('nvcc' in r for r in jobs), SDK_jobs=0 if not unexpected else None,
       unexpected=unexpected, commands=jobs, snapshot=m.ident(snapshot),
       same_graph_as_original_installed_audit=True,
       limitation='Snapshot avoids dry-run uncertainty from always-run VerifyGlobs. No build graph or rule is changed. Actual standard build still runs normal glob verification.'))
assert len(jobs) == 4 and len(cxx) == len(archives) == 2 and not unexpected, jobs
consumers = []
for name, directory, executable in [('cpp', 'consumer-cpp2', 'hyle_package_graph_cpp'),
                                     ('cpu_cuda', 'consumer-cpu_cuda', 'hyle_cpu_cuda_sample')]:
    folder = m.CONSUMERS/directory
    image = folder/executable
    assert image.is_file()
    commands = m.execute('consumer-'+name+'-commands', ['ninja', '-t', 'commands'], folder)
    assert str(m.PREFIX/'include') in commands
    assert all(str(m.PREFIX/'lib'/lib) in commands for lib in ['libhyle_compute_backend_cuda.a', 'libhyle_compute_provider_ggml_cuda.a'])
    dry = m.execute('consumer-'+name+'-dryrun-before-install', ['ninja', '-n'], folder)
    assert 'no work to do' in dry
    ldd = m.execute('consumer-'+name+'-ldd', ['ldd', str(image)], folder)
    assert 'not found' not in ldd
    consumers.append(dict(name=name, directory=str(folder), image=m.ident(image), current_pending_jobs=0,
                          directly_depends_on_both_installed_archives=True, missing_dynamic_dependencies=0))
plan = dict(status='two_current_CPP_synced_four_payload_jobs_confirmed_no_build_yet',
            products='compute;graph;graph_progress', routes='cpu;cuda', source=str(m.SOURCE), build=str(m.BUILD),
            prefix=str(m.PREFIX), source_audit=read(m.P/'source-audit-after.json'),
            actual_payload_dryrun=dict(CXX=2, archive_links=2, NVCC=0, SDK_jobs=0, total=4),
            source_sync=sync, consumers=consumers,
            existing_standard_CMake_glob_verification='Normal build may print VerifyGlobs. No CMake/source graph changes or SDK jobs were added.',
            next_commands=[['cmake', '--build', str(m.BUILD), '--parallel', '2'],
                           ['cmake', '--install', str(m.BUILD), '--prefix', str(m.PREFIX)],
                           ['cmake', '--build', str(m.CONSUMERS/'consumer-cpp2'), '--parallel', '2'],
                           ['cmake', '--build', str(m.CONSUMERS/'consumer-cpu_cuda'), '--parallel', '2']],
            actions=dict(builds=0, installs=0, consumer_relinks=0, GPU_runs=0),
            installed_consumer_execution='Root only, after this CPU build/install/relink phase; not performed here.')
m.save('plan.json', plan)
print(json.dumps(dict(status=plan['status'], payload=plan['actual_payload_dryrun'], consumers=len(consumers)), indent=2))
