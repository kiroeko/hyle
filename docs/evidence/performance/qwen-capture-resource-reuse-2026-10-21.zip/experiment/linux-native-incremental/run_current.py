"""Root serial execution; reuse the two original relocated installed consumers."""
from pathlib import Path
import hashlib
import json
import subprocess
import time

P = Path(__file__).resolve().parent
ready = json.loads((P / 'build-install-readiness.json').read_text())
assert not ready['old_prefix_exists']
assert Path(ready['prefix']).is_dir()
runs = []
for item in ready['consumers']:
    image = item['current_image']
    path = Path(image['path'])
    assert path.stat().st_size == image['bytes']
    assert hashlib.sha256(path.read_bytes()).hexdigest() == image['sha256']
    out = P / ('run-' + item['name'])
    out.mkdir(exist_ok=False)
    record = dict(image=image, command=[str(path)], cwd=str(path.parent), started=time.time(),
                  execution_owner='root', builds=0, SDK_copies=0)
    (out / 'command.json').write_text(json.dumps(record, indent=2))
    with (out / 'stdout.log').open('w') as stdout, (out / 'stderr.log').open('w') as stderr:
        result = subprocess.run(record['command'], cwd=path.parent, stdout=stdout,
                                stderr=stderr, timeout=180)
    record.update(exit_code=result.returncode, seconds=time.time()-record['started'], terminal=True)
    (out / 'result.json').write_text(json.dumps(record, indent=2))
    runs.append(record)
    print(item['name'], result.returncode, flush=True)
    assert result.returncode == 0
(P / 'execution.json').write_text(json.dumps(dict(passed=True, runs=runs), indent=2))
