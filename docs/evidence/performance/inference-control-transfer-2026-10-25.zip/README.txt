Extract these files into the repository root, then run:
python .scratch/inference-system-review-20261025/control-transfer-attribution.py
The script reads existing public trace archives only and starts no model or profiler.
Reference source reviews are local-revision observations, not peer performance results.
