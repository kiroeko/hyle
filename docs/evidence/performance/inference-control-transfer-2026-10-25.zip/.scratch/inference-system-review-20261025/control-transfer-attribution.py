"""Recompute only the existing four-arm control-transfer attribution, no trace execution."""
from collections import Counter
import hashlib
import json
from pathlib import Path
import sqlite3
import zipfile

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).with_suffix('.json')
SOURCE = ROOT / 'docs/evidence/performance/mtp-current-cost-attribution-2026-10-25.zip'
BODY = ROOT / 'docs/evidence/performance/mtp-body-route-attribution-2026-10-25.zip'
SQL_API = '''SELECT r.start,r.end,r.correlationId,s.value,r.eventClass,r.returnValue
 FROM CUPTI_ACTIVITY_KIND_RUNTIME r JOIN StringIds s ON s.id=r.nameId ORDER BY r.start'''
SQL_COPY = '''SELECT start,end,correlationId,bytes,copyKind,COALESCE(graphNodeId,0)
 FROM CUPTI_ACTIVITY_KIND_MEMCPY WHERE start>=? AND end<=? ORDER BY start'''


def pin(path):
    return dict(path=path.relative_to(ROOT).as_posix(), bytes=path.stat().st_size,
                sha256=hashlib.sha256(path.read_bytes()).hexdigest())


def union_ns(intervals):
    result = []
    for start, end in sorted(intervals):
        if result and start <= result[-1][1]:
            result[-1][1] = max(result[-1][1], end)
        else:
            result.append([start, end])
    return sum(end-start for start, end in result)


result = dict(schema='hyle.offline.control-transfer-attribution.v1',
              profiler_processes_started=0, model_processes_started=0,
              source_archive=pin(SOURCE), body_archive=pin(BODY),
              SQL=dict(apis=SQL_API, copies=SQL_COPY), arms={})
with zipfile.ZipFile(SOURCE) as archive:
    original = json.loads(archive.read(next(n for n in archive.namelist()
                                           if n.endswith('/current-structure/analysis.json'))))
    for arm in ('hyle_plain', 'hyle_mtp', 'peer_plain', 'peer_mtp'):
        source = original['arms'][arm]
        member = next(n for n in archive.namelist() if n.endswith(arm+'/trace.sqlite'))
        raw = archive.read(member)
        sha = hashlib.sha256(raw).hexdigest()
        expected = next(x for x in source['input_files'] if x['path'].endswith('/trace.sqlite'))
        assert len(raw) == expected['bytes'] and sha == expected['sha256']
        db = sqlite3.connect(':memory:')
        db.deserialize(raw)
        db.execute('PRAGMA query_only=ON')
        window = source['warm_window']
        lo, hi = window['window_start_ns'], window['window_end_ns']
        apis = db.execute(SQL_API).fetchall()
        api_by_cid = {r[2]: r for r in apis}
        current = [r for r in apis if r[0] < hi and r[1] > lo]
        copies = db.execute(SQL_COPY, (lo, hi)).fetchall()
        kinds = dict(db.execute('SELECT id,label FROM ENUM_CUDA_MEMCPY_OPER'))
        output = dict(sqlite=dict(member=member, bytes=len(raw), sha256=sha),
                      image=source['image'], actual_work=source['actual_work'],
                      logical_decode_calls=source['logical_decode_calls'],
                      window=dict(start_ns=lo, end_ns=hi, span_ns=hi-lo,
                                  captured_roles=window['captured_roles'],
                                  definition=window['label']),
                      driver_table_present=bool(db.execute("SELECT name FROM sqlite_master WHERE name='CUPTI_ACTIVITY_KIND_DRIVER'").fetchone()),
                      api_event_classes=dict(Counter(r[4] for r in current)), copies={}, apis={})
        for kind in (1, 2):
            rows = [r for r in copies if r[4] == kind]
            linked = {r[2]: api_by_cid[r[2]] for r in rows if r[2] in api_by_cid}
            output['copies'][kinds[kind]] = dict(
                count=len(rows), bytes=sum(r[3] for r in rows),
                gpu_activity_ns=sum(r[1]-r[0] for r in rows),
                gpu_union_ns=union_ns([(r[0], r[1]) for r in rows]),
                bytes_histogram=dict(Counter(r[3] for r in rows)),
                captured_count=sum(r[5] != 0 for r in rows),
                matched_api_count=len(linked), unmatched_copies=sum(r[2] not in api_by_cid for r in rows),
                matched_api_names=dict(Counter(r[3] for r in linked.values())),
                matched_full_api_activity_ns=sum(r[1]-r[0] for r in linked.values()))
        for name in sorted({r[3] for r in current}):
            if not any(x in name for x in ('Memcpy', 'Synchronize', 'GraphLaunch')):
                continue
            rows = [r for r in current if r[3] == name]
            clips = [(max(r[0], lo), min(r[1], hi)) for r in rows]
            output['apis'][name] = dict(count=len(rows),
                clipped_activity_ns=sum(b-a for a, b in clips), clipped_union_ns=union_ns(clips),
                event_classes=sorted({r[4] for r in rows}), failed=sum(r[5] != 0 for r in rows))
        for label, names in (
            ('direct_H2D_and_explicit_stream_sync', {'cuMemcpyHtoD_v2', 'cuStreamSynchronize'}),
            ('direct_H2D_sync_and_D2H', {'cuMemcpyHtoD_v2', 'cuStreamSynchronize', 'cuMemcpyDtoH_v2'})):
            clips = [(max(r[0], lo), min(r[1], hi)) for r in current if r[3] in names]
            total = union_ns(clips)
            output[label] = dict(api_names=sorted(names), union_ns=total, fraction_of_profiled_envelope=total/(hi-lo))
        output['diagnostics'] = [dict(severity=s, text=t, count=n) for s, t, n in db.execute(
            'SELECT severity,text,count(*) FROM DIAGNOSTIC_EVENT WHERE severity>=2 GROUP BY severity,text')]
        result['arms'][arm] = output
        db.close()
result['limits'] = [
    'Runtime export includes visible driver APIs in eventClass1 despite no separate DRIVER table; not proof of every CUDA API coverage.',
    'Own-process last24 captured-target envelope, not complete decode or aligned cold start; input before first target and readback after last target are excluded.',
    'GPU activities, CPU APIs, sync activity and nested intervals must not be added together or called recoverable time.',
    'Original image c343 and greedy policy; no random-identity traffic or current01e timing is measured here.',
    'MTP target/draft counts and continuations differ; retain actual work instead of equalizing by output count.',
    'Driver13.4/tool13.3 compatibility warning and MTP GraphId/GraphNodeId diagnostics retained.',
]
result['conclusion'] = 'Direct control H2D plus explicit stream sync occupies about0.53% of either Hyle warm profiled envelope; real but not an established explanation of about10% throughput gap. No new profile is needed for these counts.'
result['analysis_source'] = pin(Path(__file__))
OUT.write_text(json.dumps(result, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
print(json.dumps(dict(output=OUT.relative_to(ROOT).as_posix(), bytes=OUT.stat().st_size,
                     sha256=hashlib.sha256(OUT.read_bytes()).hexdigest())))
