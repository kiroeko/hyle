# 旧四臂 trace：控制传输同步的可观测量

2026-10-25，只读 ZIP→内存 SQLite `deserialize`，`PRAGMA query_only=ON`；没有解包持久 SQLite、构建、模型或新采样。来源：

- `docs/evidence/performance/mtp-current-cost-attribution-2026-10-25.zip`，9,692,222B，SHA256 `e076c0d141b4bd219372051b299c4c0100d0a72d3488b0da73f859ee4bc92f62`；内含原四 SQLite，逐一核对原 JSON 中的 SHA，全部一致。
- `mtp-body-route-attribution-2026-10-25.zip`，44,652B，SHA256 `16ed6ad9e9fac6a2f37489a81767ec0efa4c71b4e73e80ff63807c45f2b2a6b2`；它没有新 SQLite，body 分析复用上项，不是第二份独立测量。

**重要纠正：** 四库都没有 `CUPTI_ACTIVITY_KIND_DRIVER` 表，但 `CUPTI_ACTIVITY_KIND_RUNTIME` 已同时存 runtime（`eventClass=0`）与可见 driver（`eventClass=1`）API。Hyle 的 `cuMemcpyHtoD_v2`、`cuStreamSynchronize`、`cuMemcpyDtoH_v2` 均真实存在，并能按 correlationId 对上 GPU copy。因此 driver 表不存在不能把这些调用当未知，更不能当零；也不能反过来声称所有 driver API 都已完整采集（原命令没有 `--cuda-trace-all-apis=true`）。

## 相同原口径的 warm 窗

沿原 `current-structure/analysis.json` 的 own-process 最后 24 captured target 首活动→末活动 envelope；普通包含 24 target，MTP 包含 24 target+23 间隔 draft。窗口截去了首个 target 之前的输入及最后 target 之后的读回，因此传输通常对应 **23 个 target 间边界**，不是完整 24 logical calls。各进程没有减对方时钟；不是相同续文/接受树，更不是全 decode。

| 臂 | 本进程窗 ns | span ms | H2D活动/bytes/GPU µs | D2H活动/bytes/GPU µs |
|---|---|---:|---|---|
| Hyle ordinary | 3070026230→3332314019 | 262.287789 | 92 / 2,600 / 71.903 | 23 / 92 / 23.328 |
| Hyle MTP | 3212369152→3565285787 | 352.916635 | 184 / 6,880 / 140.925 | 46 / 276 / 50.879 |
| peer ordinary | 3145032496→3396551250 | 251.518754 | 161 / 24,564 / 197.376 | 46 / 22,845,532 / 931.640 |
| peer MTP | 2758619006→3107516193 | 348.897187 | 322 / 474,720 / 413.401 | 161 / 68,913,428 / 2,835.464 |

以上 H2D/D2H 都是非 captured GPU memcpy。Hyle ordinary 46 个 4B H2D 对应直接 `cuMemcpyHtoD_v2`；另 23 个 batch-copy、23 个 runtime async-copy，不能把全部 92 次都归为 token 写。MTP 对应 92 个直接 H2D（46×4B、46×8B）、46 batch、46 runtime async。原采样为 greedy，**没有随机 identity 热上传的成本证据**。

## Host API：按原名计数，区间仅本窗内裁切

| API | Hyle ordinary count / µs | Hyle MTP count / µs |
|---|---:|---:|
| cuMemcpyHtoD_v2 | 46 / 496.467 | 92 / 842.993 |
| cuStreamSynchronize | 46 / 888.261 | 92 / 1,032.254 |
| 上两项区间 union | 1,384.728 | 1,875.247 |
| cuMemcpyDtoH_v2 | 23 / 726.037 | 46 / 1,289.930 |
| cuMemcpyBatchAsync_v2 | 23 / 366.899 | 46 / 631.184 |
| cudaMemcpyAsync_v3020 | 23 / 208.155 | 46 / 506.237 |
| cudaEventSynchronize_v3020 | 70 / 231,770.227 | 116 / 307,535.207 |

直接 H2D+显式流等待占各自被 profile 的 span **0.528% / 0.531%**；加直接 D2H 是 **0.805% / 0.897%** 的 API 占用。这是观测量，**不是可回收收益或严格端到端提速上限**：API 包含同步等待、工具开销，改变排队方式也可能改变重叠。每项分别求 union；此窗上述类没有彼此重叠，但不能和 GPU memcpy/kernel、CUPTI synchronization 活动、GraphLaunch 或 cold 时间再相加。巨大 EventSynchronize 时间主要涵盖已在 GPU busy 里的运行，不是可以删除的 host 工作。

peer 的 H2D 均关联 `cudaMemcpyAsync`，普通/MTP 对应 API 本体合 1,503.748 / 2,783.194µs；但其 `cudaStreamSynchronize` 仍有 530 / 1,151 次，合 235,639.698 / 322,677.205µs，不能从 async 名称推出无同步。GPU copy 与 API 用完整表全局 correlationId 对接，四臂这个窗口均没有未匹配 copy；仅按 API 自身落窗连接会错误漏掉跨边界调用。

## 能下的结论与不能下的结论

- 源码的逐端口同步 H2D 在旧实际 trace 中确实发生；MTP 的阶段重复使次数翻倍，有维护/提交路径简化价值。但旧 warm 窗直接 API 占用只有约 0.5%，**没有依据把它列为当前约 10% 落后的已定主因**。
- “Hyle 传输更多所以慢”不成立：peer 同窗口 H2D 次数和字节更多，D2H 还传回 logits；这也说明必须分传输方式、真实 payload 与消费边界，不能只数 copy。
- body-route 的 Hyle MTP selected-target `copy_activity` 中位 0.136366ms 是该 graph 内的另一类工作；此处 warm H2D/读回是 graph 外活动，不将两者合成一个“同步税”，也不重开已关闭的 MMVF/hidden-order/fixed512 候选。
- 四进程同请求 128 outputs、2 turns、309 target-prefill rows；普通 126 target decode，MTP Hyle 66 target/66 draft、60 agreements，peer 65/65、61 accepted，实际 verifier/draft 工作不同。以上不是 MTP 每 token apples-to-apples 因果分解。
- 原工具对 driver13.4 使用13.3 tracing 库；MTP Hyle 有各250条 GraphId/GraphNodeId错误，peer 各692条。保留原异常边界，API/活动聚合只作诊断候选；原无插桩吞吐证据不受此分析替代。

## 下一步是否需要 profile

**目前不需要再采四臂来证明同步上传存在或其 warm API 量级。** 先据这些事实降低该候选的收益预期；真正改动应复用原队列/CopyBatch、保完整状态/RNG及退休，然后由未插桩同工作 before/after 决定是否值得。

若以后确实需要新源的全 API/随机 identity 归因，最多先 Hyle ordinary、MTP 各一个原两轮进程，无需 peer 矩阵。复用 `current-structure/{hyle_plain,hyle_mtp}/command.json` 的原 argv 与 `baseline/runtime.json`，只将 image 改为当前缓存 `.scratch/inference-system-review-20261025/text-r2-suffix/link/hyle.exe`（SHA `01e0a1b0ded07d20b7c20dfe3ba94c37ccd9af486ee75fa55a9654feedae8ab3`，main `e630c272...`），新 output 留于本任务目录。Nsight 原参数 `profile --trace=cuda,cublas --cuda-graph-trace=node --sample=none --cpuctxsw=none --discard-environment=true --duration=20 --stats=false --export=sqlite` 可复用；为补少见 driver API，当前已安装 `nsys profile --help` 确认准确开关 **`--cuda-trace-all-apis=true`**，不是另造 `--trace=driver`。该开关会增加开销，也不会自动修复 driver/tool 版本不匹配；采前仍需明确缺失问题，不把它作为本轮开发前置。此处只给方案，没有启动任何进程。

复算核心：对每 ZIP member 内存连接；`SELECT r.start,r.end,r.correlationId,s.value,r.eventClass FROM CUPTI_ACTIVITY_KIND_RUNTIME r JOIN StringIds s ON s.id=r.nameId WHERE r.start<hi AND r.end>lo`；GPU copy 按 `start>=lo AND end<=hi`，以 `ENUM_CUDA_MEMCPY_OPER` 的真实 HTOD/DTOH ID分类；sum/union 各自计算，不能按表名丢 eventClass1，也不以 graphId=0 排除 NULL eager。
