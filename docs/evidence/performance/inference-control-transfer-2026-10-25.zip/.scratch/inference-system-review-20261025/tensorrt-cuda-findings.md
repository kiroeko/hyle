# TensorRT-LLM CUDA 深审：可移植到 Hyle 的四个性能候选

2026-10-25，只读源码审查；没有构建、GPU、网络或性能重测。TRT 路径均相对 `C:/public/project-hyle/TensorRT-LLM`，Hyle 路径相对本仓库。

- TRT 实际 HEAD：`46d9966b54d9d11998b712e732fb20f64d4d35c0`，2026-10-20，`[fix] Support MegaMoE CuteDSL TEP for all models (#20055)`；`git diff --name-only` 为空。
- Hyle 审查时 HEAD：`9edfae744fb7deb7819df28537b978c9e75e97d1`；`main.cc` SHA256 `e630c27255b7dba5edff50673ba581815a4b175656781901777001bd57f06e4a`。本任务不修改这些文件。
- 用户最新范围包含普通与 MTP **性能**、多会话、多请求；MTP 功能阶段不重开。下列均为待测候选，不能据源码推算收益，也不证明已解释当前约 10% 差距。

## 1. 先合并每个执行阶段的控制输入传输，减少同步 H2D 调用

**TRT 机制。** `tensorrt_llm/_torch/pyexecutor/engine/input_buffers.py:13–50` 从容量一次分配 token/position 设备存储；`cuda_graph_runner.py:782–859` 向稳定地址填入当前值，再 replay。attention 的 pinned CPU 长度缓冲与非阻塞复制见 `attention/backends/trtllm.py:397–430,1008–1010,1061–1065`。输出 `_copy_to_host` / `_record_sampler_event` 在 `pyexecutor/sampler/sampler_features.py:694–765` 用异步复制与事件代表真实可读边界。

**Hyle 确切接缝。** `engine/models/qwen35/main.cc:106–122` 的 `Tensor::write` 走 `BufferView::write`；普通 `prepare_evaluations:3624–3638` 分别写 token、position、随机 identity。这些 Tensor 在 `3322–3329` 分配于 `execution.device()`。CUDA `src/compute_backend_cuda/cuda_memory.cc:98–140` 每次设备写执行 `cuMemcpyHtoD` 后 `cuStreamSynchronize(nullptr)`。MTP 另外在 `main.cc:2858,2999–3006` 写草拟 identity、前缀 identity/IDs，因而同类提交成本会重复。

**最小方向。** 冷准备有界 pinned staging 与原设备端口；同阶段使用已有 `compute::CopyBatchProgram/Invocation`（`include/hyle/compute/batch_transfer.h:80–133`），先把多次小 H2D 排到原队列，最保守第一步只把多个逐端口等待收为一次 transfer completion。底层已经提供同 context device/pinned/managed 的 queued copy（`src/compute_backend_cuda/cuda_backend.cc:1097–1131`）和冷建固定容量 copy slot（`cuda_batch_transfer.cc:24–100`），无需第二执行器。

**约束与测量前提。** staging 在真实 copy 退休前不可覆盖；不能把栈/vector 地址直接异步提交。Graph 输入必须在其真实依赖完成后使用，失败/未知退休仍拒绝发布。当前 `finish_selected_evaluations:3852–3878` 在成功 Completion 后才读 scalar，这是必要合同；CUDA read 是同步 `cuMemcpyDtoH`（`cuda_memory.cc:109–123`），**没有**额外 `cuStreamSynchronize`，不能双计。后续若合并 D2H，必须保 caller/generated 输出原 lease、Bool/F32 验证、完整 state/RNG 与原子提交；不能直接删 readiness wait。先分别计普通/MTP 每阶段 H2D/API/等待次数和 decode/综合时间，不能用移出计时区的预热冒充收益。

## 2. 将短命 host 准备数据与不可变版本所有权分开，复用有界容量

**TRT 机制。** `attention/backends/trtllm.py:397–487` 从 max-sequences/max-blocks 建固定设备元数据存储，普通路径按实际 `max_kv_len` 限定 block-table 上传宽度（`1084–1109`）。但它**并非所有 host 路径零分配**：`pyexecutor/resource_manager.py:2724–2747` 特意建立 private pinned snapshot，防下一轮 CPU 重填覆盖尚未执行的 H2D；`kv_cache/kv_cache_manager_v2.py:6574–6598` 则由设备复制算子按已分配页搬运。

**Hyle 确切接缝。** `main.cc:1119–1133` 已有 `InputPreparationScratch` 复用 IDs/position/identity；但 `prepare_evaluations:3640–3650,3713–3717,3744–3747` 每次仍建 query/page/last、old-query、sources、layouts 容器，`3597` 创建 StepState，`reserve_snapshot:3033–3041` 创建 Snapshot。每个 `BatchSchema::version` 在 `src/compute_batch/batch_layout.cc:265–286` 新建对象和 active-size host Buffer；可导出 metadata 另在 `324–338` 延迟新建容量布局。长上下文每步还重建完整 page-ID 列表，不能把这些所有权数据都当 scratch。

**最小方向。** 先仅将不逃逸的 query/indptr/IDs/last/sources/NodeLayout 临时数组纳入原冷容量 scratch；再单独调查确实高频的版本对象/metadata backing 是否值得用有限池回收。对象可复用现有 allocator/池设施，但 `BatchSchema::version` 的 Buffer 当前硬用 `mem::system_resource()`，仅换 `BatchSchemaOptions.allocator` 不会消除该 backing 分配。保留每个已发布版本自己的不可变字节与 generation，未退休/被 Snapshot 或 Hit 保留的版本绝不能原地复写。

**已有设施与测量前提。** `src/compute_batch/batch_execution.cc:473–505` 已对 active segments 做差分并复用镜像；同布局跨层可共享 metadata（`429–442`），`src/graph_batch/batch.cc:847–882` 也优先使用同 resource 的 native metadata。故不能再称“每层整容量全表上传”。先计这条实际路由的 host allocations/metadata bytes 与 preparation 时间，区分 engine 临时数组、不可变版本和 fallback export；只优化实际发生的一类。该项 CPU/CUDA/Apple/Vulkan 都有适用面，具体 transport 各走原后端。

## 3. 多请求引入 token 工作量预算的有限分块 prefill，避免长 prompt 独占一个波次

**TRT 机制。** `cpp/tensorrt_llm/batch_manager/microBatchScheduler.cpp:67–80` 用真实未复用工作量计价；`141–200` 在 token 预算内逐 chunk-unit 推进 context 请求；`379–480,505–508` 同时安排 generation 与 context，context 使用剩余 token 预算。缓存覆盖的首块与后续块单独计账，不能只用请求数量决定负载。

**Hyle 确切接缝。** `main.cc:5335–5390` 冷准备完整 prompt/suffix 形状；`5482–5496` 以相同 role/generation/`planned_rows()` 分组，整 bucket 执行到完成后才继续下一组。`prepare_evaluations:3581` 要求等长非空 chunk。因此 N/R 限制了请求数，却没有限制一波实际新增 token 工作量，也不会自动把长 prompt 拆成较短公平片段。

**最小方向。** 在 engine 的现有 RequestWindow/BatchIndices 之上，为已知请求计划选择有限 chunk 长度和每波 token 上限，复用原 exact family、PagedAppend 与状态提交。先保持同 role/等长 bucket，不要求第一步就造混合 prefill/decode 的新 Graph，也不复制 TRT scheduler 或添 provider registry。

**约束与测量前提。** 中间 prompt 块不应向用户多生成 token或消耗采样 RNG；GDN history/recurrent、position、pending、prefix key 只按真正消费内容推进。MTP 块边界须保持已有完整 target/draft 续算合同，不能简单沿 token 数切。先用长 prompt+短 decode 的既有多请求输入比较总吞吐、首 token/逐 token 等待及峰值显存；单用户短 decode 不一定获益。所有平台可用该 engine 策略，硬件最优块长必须实测，不能照搬 TRT 常量。

## 4. 普通层边界的 residual + RMSNorm 双输出融合，严格保持舍入与别名

**TRT 机制。** `tensorrt_llm/_torch/modules/rms_norm.py:170–190` 对 FP16/BF16 residual 分支调用 `flashinfer_fused_add_rmsnorm`，`custom_ops/flashinfer_custom_ops.py:58–67` 明确 input/residual 原地变更合同。进一步 norm+NVFP4 quant 是另一种有 scale/硬件限制的分支（`rms_norm.py:120–144`），不能和普通 BF16 等同。

**Hyle 确切接缝。** `main.cc:850–857` norm 为 Cast(F32)→RMSNorm→Cast(原类型)；`877–887,2475` 分别创建 residual Add 与后续 norm。现有 ggml CUDA graph matcher `src/graph_provider_ggml_cuda/ggml_cuda_region.cc:457–513,922–954` 已消除私有 RMS 两端 casts，但不匹配前置 Add；native normalization `src/compute_provider_cuda/norm_provider.cc:37–89` 仍是单 norm 合同。值得调查的是这条**真实 Add→norm 边界**，不是重新提出已接入的 SiLU×Mul/双投影融合。

**最小方向。** 先确认当前实际 native kernel 序列确有独立 Add；若有，在现有冷 region discovery 中识别有界 Add/Cast/RMS/Cast 子图，让原 residual 与 normalized 两个真实输出保留。Compute/Graph 保持模型无关，不能把 Qwen 层名放进路由。也不能仅因 Hyle matcher 未出现就断言 vendor 内部必未融合；选中 backend 的实际执行才是决定证据。

**约束与测量前提。** Hyle 的 BF16 Add 输出既被 norm 又被 residual 路径消费，必须保 BF16 加法舍入、F32 accumulation、epsilon/gamma 语义及两个输出；不能用 F32 未舍入的和替换，也不能照搬 TRT 原地覆盖仍被旧 Snapshot/GraphOutput 持有的输入。先用非零/相消/极值原数值 oracle 与真实前后图拓扑检查，再看 kernel/访存与端到端；该普通 BF16/FP16 思路适用于 CUDA，具体 vendor kernel 能否满足原数值合同尚未认证，MTP 复用这些层也同样受益。

## 不重复立项的机制与边界

- CUDA Graph：TRT `cuda_graph_runner.py:207–210,614–662,747–779` 先 warmup 使 workspace 达到所需容量，只允许指定阶段 capture，未见 shape 运行 eager；图 key 真含 batch/draft-length/采样分支（`:61–78,363–430`）。Hyle 已有有限 exact plan、两 capture variants（`src/graph/executable.cc:9738–9756`）及 `cudaGraphExecUpdate`（`cuda_backend.cc:1318–1345`）。不另建图缓存/IR，不增 variant 数，也不以运行期静默关闭捕获换表面成功；稳定地址应从原资源寿命解决。
- workspace：TRT `attention/backends/trtllm.py:286–288,464–470` 区分 eager/graph workspace；`pyexecutor/workspace.py:58–113` 只在 forward 边界回收纯 scratch，capture/多流/未成功 forward 不缩。Hyle 已有 workspace 预算与退休，未发现足够依据另加每 token shrink 或复活 fixed512 KV 分块候选。
- weight layout/GEMM：TRT `modules/linear.py:574–594,619–647` 的 low-M/persistent BF16 路径主要针对 Blackwell/SM107；`:2125–2154,4192–4204` 的 NVFP4 GEMM+SwiGLU 使用经冷转换的特定 interleave/scales、SM100/103、无 bias。不能宣称可直接搬到 RTX4070/SM89。其 `gated_mlp.py:299–349` 的同 activation 一次 quantize、load-time 核 scale 等价思想，在 Hyle `fp8_provider.cc:113–132` 已有同输入 block128 pair，ggml dual/SiLU matcher 也已有；先核各实际量化路由是否命中，不再凭名称缺失重复建设。
- CPU 重叠：TRT overlap loop（`pyexecutor/py_executor.py:5723–5757,5902–6010`）下一轮 forward 与上一轮 host 处理交叠，同时在 page-table 修改前等真实 input-copy。Hyle 当前单 carrier (`main.cc:3565–3566`) 是有意的状态/资源边界。四候选里先做传输与 host 准备，可在现有 submit/finish 分离上测独立请求是否还需双 carrier；本审查不建议直接复制 TRT executor/后台线程、提前发布同会话未来状态或删退休检查。

建议首轮顺序：① 每阶段控制 H2D 合并 → ② 实际热 host 临时数组复用 → ④ 满足原数值边界的 residual-norm → ③ 多请求 token 预算。每项先用同真实工作负载归因；任何收益须同时报告 prefill/decode/综合速度与内存/显存，普通/MTP 分别计真实工作，未测不报百分比。
