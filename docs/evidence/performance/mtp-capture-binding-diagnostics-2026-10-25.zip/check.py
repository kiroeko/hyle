from pathlib import Path
from datetime import datetime, timezone
import difflib, hashlib, importlib.util, json, os, re, sys
sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
R = S.parents[1]
B = R/'.scratch/mtp-performance-convergence-20261025/baseline'
C = B.parent/'current-cuda'
spec = importlib.util.spec_from_file_location('retained', R/'.scratch/mtp-extraction-regression-20261024/check.py')
b = importlib.util.module_from_spec(spec); spec.loader.exec_module(b)

def args(path):
    value = b.read(path)
    return value['command'] if isinstance(value, dict) else value

def prepare():
    canonical = R/'src/graph/executable.cc'
    original = canonical.read_text(encoding='utf-8')
    assert b.pin(canonical)['sha256'] == '8652cbd963069623860074e3bf874bb8574a31e27b1f3f6a945f7b37484b95bc'
    out = original
    def add(anchor, payload, before=False, count=1):
        nonlocal out
        assert out.count(anchor) == count, (anchor[:100], out.count(anchor), count)
        tag = f'// CAPTURE_MISS_DIAG_BEGIN\n{payload}\n// CAPTURE_MISS_DIAG_END\n'
        out = out.replace(anchor, tag+anchor if before else anchor+tag, count)
    add('namespace hyle::graph {\n', '#include <atomic>\n#include <cstdio>\n#include <cstdlib>\n#include <intrin.h>', before=True)
    add('void reset_capture_cache(detail::InvocationState &invocation) noexcept {\n',
        '#include "'+str(S/'capture_probe.h').replace('\\','/')+'"', before=True)
    add('void discard_capture_variants(detail::CaptureRebuildRange &saved) noexcept {\n', '  capture_probe::discard(saved);')
    add('  saved.preserves_private_arguments = preserves;\n',
        '  capture_probe::note(invocation, capture_probe::Qualification, saved.step_begin, saved.step_count, unsigned(preserves), unsigned(ports));')
    add('      invalidate_binding_cache(invocation);\n      return status;\n',
        '      capture_probe::note(invocation, capture_probe::SealFailure, unsigned(index), unsigned(status.code()));', before=True)
    add('  auto &cached = invocation.step_bindings[step_index];\n',
        '  // Diagnostic branch source is also recorded at the actual invalidation wrapper.\n')
    add('void detail::invalidate_step_recording(InvocationState &invocation,\n                                      std::uint32_t selected_step) noexcept {\n',
        '  const auto &diag_binding = invocation.step_bindings[selected_step];\n'
        '  capture_probe::note(invocation, capture_probe::Invalidated, selected_step, 0,\n'
        '      unsigned(diag_binding.stable_binding_identity) | (unsigned(diag_binding.native_inputs) << 1),\n'
        '      unsigned(diag_binding.prepared_revision == diag_binding.revision), reinterpret_cast<std::uintptr_t>(_ReturnAddress()));')
    add('void detail::recycle_step_recording(InvocationState &invocation,\n                                   std::uint32_t selected_step) noexcept {\n',
        '  const auto &diag_binding = invocation.step_bindings[selected_step];\n'
        '  capture_probe::note(invocation, capture_probe::Invalidated, selected_step, 1,\n'
        '      unsigned(diag_binding.stable_binding_identity) | (unsigned(diag_binding.native_inputs) << 1),\n'
        '      unsigned(diag_binding.prepared_revision == diag_binding.revision), reinterpret_cast<std::uintptr_t>(_ReturnAddress()));')
    entry = 'Status Invocation::prepare_replay(std::span<const QueueBinding> queues,\n'
    assert entry in out
    # Do not insert before the original public null/phase permission gates.
    add('  // Commands will enter ordinary provider encoders on the next submit. Old\n',
        '  capture_probe::begin(*state_, options.mode);', before=True)
    add('        state_->step_bindings[index].stable_binding_identity = false;\n',
        '        capture_probe::note(*state_, capture_probe::QueueChanged, unsigned(lane), unsigned(index));', before=True)
    add('  for (const auto &candidate : state_->plan->capture_ranges) {\n',
        '    capture_probe::range(*state_, candidate);')
    add('      ++reused_range_count;\n      captured_command_count += candidate.command_count;\n      continue;\n',
        '      capture_probe::note(*state_, capture_probe::RetainedHit, range.step_begin, range.step_count);', before=True)
    add('        selected_variant = index;\n        break;\n',
        '        capture_probe::note(*state_, capture_probe::VariantHit, range.step_begin, range.step_count, index);', before=True)
    add('      selected_variant = saved->variants[0].key_valid\n',
        '      capture_probe::note(*state_, capture_probe::Miss, range.step_begin, range.step_count, unsigned(saved->preserves_private_arguments));', before=True)
    add('    compute::Queue *queue = candidate_queue(queues, segment.lane);\n',
        '    capture_probe::note(*state_, capture_probe::RecordBegin, range.step_begin, range.step_count, selected_variant, saved && saved->storage.valid());', before=True)
    add('    Status finished = finish_preparation(*sequence);\n',
        '    capture_probe::note(*state_, capture_probe::RecordEnd, range.step_begin, range.step_count,\n'
        '        captured ? 0U : unsigned(captured.error().code()), unsigned(finished.code()));')
    add('    ++recorded_range_count;\n',
        '    capture_probe::note(*state_, capture_probe::Recorded, range.step_begin, range.step_count, selected_variant, stable_identity);')
    # Every product change is an insertion with two markers; stripping it must
    # reproduce the complete canonical translation unit, byte for byte (LF).
    restored = re.sub(r'// CAPTURE_MISS_DIAG_BEGIN\n.*?// CAPTURE_MISS_DIAG_END\n', '', out, flags=re.S)
    assert restored == original
    (S/'overlay').mkdir(exist_ok=False)
    (S/'overlay/executable.cc').write_text(out, encoding='utf-8', newline='\n')
    (S/'before-executable.cc').write_bytes(canonical.read_bytes())
    (S/'source.patch').write_text(''.join(difflib.unified_diff(original.splitlines(True), out.splitlines(True), fromfile='canonical/src/graph/executable.cc', tofile='private/overlay/executable.cc')), encoding='utf-8')
    b.save(S/'equivalence.json', dict(canonical=b.pin(canonical), overlay=b.pin(S/'overlay/executable.cc'), helper=b.pin(S/'capture_probe.h'),
        insertion_only=True, stripped_body_sha256=hashlib.sha256(restored.encode()).hexdigest(), byte_equal_to_canonical=restored.encode()==canonical.read_bytes(),
        changes_native_math=False, changes_graph_or_bindings=False, changes_cache_policy=False, detail_prepares_per_invocation=20,
        capacity=dict(slots=64, events=4096, differences=2048, saved_ranges=128), tail_aggregate=True,
        dump='atexit stderr after CLI return; no token-path print, payload/lease retention, GPU read or extra submit'))
    print('SOURCE_EQUIVALENCE_PASS', flush=True)

def build():
    old = args(C/'product-0/command.json'); flags=[]; skip=False
    for value in old[1:]:
        if skip: skip=False; continue
        if value == '/sourceDependencies': skip=True; continue
        if value.lower().startswith(('/fo','/fd')) or value.lower().endswith(('.cc','.cpp')): continue
        flags.append(value)
    source=S/'overlay/executable.cc'; folder=S/'compile1'
    cmd=[old[0],*flags,str(source),'/sourceDependencies',str(folder/'dependencies.json'),'/Fo'+str(folder/'unit.obj')]
    assert sum(word.lower().endswith(('.cc','.cpp')) for word in cmd)==1
    env=b.environment(cmd[0]); b.execute(cmd,folder,env,240)
    includes=[Path(path).resolve()for path in b.read(folder/'dependencies.json')['Data']['Includes']]
    b.save(folder/'source-pins.json',dict(source=b.pin(source),dependencies=[b.pin(path)for path in includes if path.is_relative_to(R)],equivalence=b.pin(S/'equivalence.json')))
    link=args(B/'link/command.json'); replacement=str(C/'product-0/unit.obj'); assert link.count(replacement)==1
    link=[str(folder/'unit.obj')if value==replacement else value for value in link if not value.upper().startswith(('/OUT:','/PDB:','/MAP:','/IMPLIB:'))]
    link+=['/OUT:'+str(S/'link1/hyle.exe'),'/MAP:'+str(S/'link1/hyle.map')]
    b.execute(link,S/'link1',env,120)
    native=B/'link/hyle_ggml_cpu_gdn_scale_v3.dll'; os.link(native,S/'link1'/native.name)
    b.save(S/'ready.json',dict(image=b.pin(S/'link1/hyle.exe'),canonical_image=b.read(B/'ready.json')['image'],
        replaced_object=b.pin(C/'product-0/unit.obj'),diagnostic_object=b.pin(folder/'unit.obj'),link=b.pin(S/'link1/command.json'),
        helper=b.pin(S/'capture_probe.h'),overlay=b.pin(source),map=b.pin(S/'link1/hyle.map'),SDK_builds=0,HTTP=0))

def run():
    old=b.read(B/'two-turn-timing/02-hyle_mtp/command.json'); cmd=old['command'][:]
    assert b.pin(Path(cmd[0]))['sha256']=='c343db76232c4b5bd34878820433057b8c23789cd1b170b6a3b86cd91bf82fa1'
    cmd[0]=str(S/'link1/hyle.exe')
    env=dict(os.environ,PATH=str(S/'link1')+';'+b.read(B/'runtime.json')['PATH'],HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1')
    b.execute(cmd,S/'run1',env,120)

if __name__=='__main__':
    action=sys.argv[1]
    {'prepare':prepare,'build':build,'run':run}[action]()
