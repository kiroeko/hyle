"""Final offline collection. No execution, compilation, download, or cleanup."""
from pathlib import Path
from collections import Counter
import hashlib, json, zipfile
S=Path(__file__).resolve().parent; R=S.parents[1]
B=R/'.scratch/mtp-performance-convergence-20261025/baseline'
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def pin(p):return dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def raw(p):return json.loads(next(l for l in p.read_text().splitlines()if l.startswith('{')))
def compare(a,b,path='',diff=None,excluded=None):
    if diff is None:diff=[]
    if excluded is None:excluded=[]
    if type(a)!=type(b):diff.append(dict(path=path,actual=a,expected=b))
    elif isinstance(a,dict):
        for k in sorted(a.keys()|b.keys()):
            if k=='seconds'or k.endswith('_seconds')or'tokens_per_second'in k:excluded.append(path+'/'+k);continue
            if k not in a or k not in b:diff.append(dict(path=path+'/'+k,missing=True));continue
            compare(a[k],b[k],path+'/'+k,diff,excluded)
    elif isinstance(a,list):
        if len(a)!=len(b):diff.append(dict(path=path,lengths=[len(a),len(b)]))
        else:
            for i,(x,y)in enumerate(zip(a,b)):compare(x,y,path+'/'+str(i),diff,excluded)
    elif a!=b:diff.append(dict(path=path,actual=a,expected=b))
    return diff,excluded
report=raw(S/'run2/stdout.log'); baseline=raw(B/'two-turn-timing/02-hyle_mtp/stdout.log')
diff,excluded=compare(report,baseline);assert not diff
rows=[json.loads(l[8:])for l in(S/'run2/stderr.log').read_text().splitlines()if l.startswith('CAPDIAG ')]
meta=next(r for r in rows if r['type']=='meta');slots=[r for r in rows if r['type']=='slot']
events=[r for r in rows if r['type']=='event'];differences=[r for r in rows if r['type']=='difference']
assert not any(meta[k]for k in('event_overflow','difference_overflow','slot_overflow','concurrent_skips'))
assert read(S/'run2/process.json')['exit']==0
assert all(r['flags'] == 16 for r in differences)
range_series=[]
for slot in slots:
    for begin in sorted({e['a']for e in events if e['slot']==slot['slot']and e['kind']=='range'}):
        snapshots=[]
        for e in events:
            if e['slot']!=slot['slot']or e['kind']!='range'or e['a']!=begin:continue
            decisions=[x for x in events if x['slot']==e['slot']and x['prepare']==e['prepare']and x['a']==begin and x['kind']in('miss','recorded','retained_hit','variant_hit','record_begin')]
            snapshots.append(dict(event=e['seq'],prepare=e['prepare'],current_fingerprint=e['current'],cached_fingerprints=[e['cached0'],e['cached1']],
                plan_skeleton_fingerprint=e['topology'],flags=e['d'],decisions=[dict(kind=x['kind'],selected=x['c'],seed_valid=bool(x['d'])if x['kind']=='record_begin'else None)for x in decisions],
                first_mismatches=[d for d in differences if d['event']==e['seq']]))
        range_series.append(dict(slot=slot['slot'],begin=begin,role='draft' if begin == 0 else 'target',snapshots=snapshots,
            distinct_diagnostic_fingerprints=len({x['current_fingerprint']for x in snapshots}),skeleton_fingerprints=sorted({x['plan_skeleton_fingerprint']for x in snapshots})))
assert sum(s['totals']['recorded']for s in slots)==32
assert sum(s['totals']['retained_hit']+s['totals']['variant_hit']for s in slots)==100
summary=dict(status='bounded_corrected_diagnostic_complete_with_explicit_native_unknown',
    process=read(S/'run2/process.json'),ready=read(S/'ready2.json'),equivalence=read(S/'equivalence2.json'),capacity_plan=read(S/'capacity-plan2.json'),
    comparison=dict(reference=pin(B/'two-turn-timing/02-hyle_mtp/stdout.log'),actual=pin(S/'run2/stdout.log'),raw_to_raw=True,
        non_time_all_fields_equal=True,differences=diff,excluded_timing_paths=excluded),
    work={k:report[k]for k in('generated_tokens','prefill_target_rows','prefill_draft_rows','verified_target_rows','actual_target_rows','actual_draft_rows','draft_rounds','consumed_drafts')},
    diagnostic_meta=meta,slot_aggregates=slots,range_series=range_series,
    observed_first_mismatch_flags=dict(Counter(str(x['flags'])for x in differences)),
    changed_port_examples=[dict(value=value,dtype=dtype,dimensions=list(dims),count=count)for(value,dtype,dims),count in Counter((d['value'],d['new']['dtype'],tuple(d['new']['dims']))for d in differences).items()],
    invalidation_details=[e for e in events if e['kind']=='invalidated'],
    findings=[
        'Both T2 roles are actual: original batches label GraphRole3 (draft_rows1,8calls) and4 (draft_rows2,58calls), matching diagnostic Invocation1/2 counts. Each has separate draft/target capture ranges.',
        'All58 recorded first-mismatch tuples differ only in offset. Their descriptors, resource, handle and extent match; later unequal ports in the same key were not exhaustively dumped.',
        'Hidden[1,2048] first differences include same-backing offsets8192,4096,0. In catchup-role draft range, first8 fingerprints follow A,B,C,B,C,A,B,C. A returns after eviction;2variants really reuse B/C but cannot simultaneously hold all3observed tuples.',
        'Target GDN history[1,3,6144] first differences include same-backing offsets0/36864. Per-range immutable plan-step skeleton fingerprint stays unchanged during the detailed window; this is not a serialization of native kernel topology.',
        'There is also explicit invalidation: Invocation1 prepare6 completes with retained hits, then outside prepare two recycle=false calls (steps39/255) discard keys; prepare7 requalifies and records both ranges. Draft fingerprint at7 equals1but no prior key survives.',
        'All captured qualification results are preserving=true; no seal failure is observed. Explicit invalidate_commands is not itself proof of a permission failure or redundant invalidation.',
        'Complete final counters:132range decisions,32recorded,10retained hits,90variant hits. Capture caching is genuinely used.'],
    limits=[
        'One initial process had diagnostic overflow, preserved as run1; one root-directed corrected process run2 follows. Neither is TPS or memory evidence.',
        'Only first20prepares per Invocation have detailed keys. The58-call catchup role has10later recordings outside detail; its whole-journey counters remain, not their tuple explanation.',
        'Actual GraphExecUpdate result/errorNode is not visible from this one Graph TU. A rebuild seed can be present but update attempt/success/native topology rejection remain unknown.',
        'Hash repetition is a diagnostic clue, not proof of full tuple equality; exact existing variant-hit decisions remain authoritative. First-mismatch offset equality does not prove every remaining key port is equal.',
        'Raw caller addresses lack a directly captured module base. map-extract.json uses an explicitly labelled relocation inference to locate invalidate_commands; it cannot identify the adapter caller behind that function.',
        'Native permissions/owners are never retained by diagnostic records; original validation, retirement,2variant policy and math are unchanged. No cache enlargement or prewarm timing relocation is proposed.'],
    first_attempt=dict(summary=pin(S/'summary.json'),process=read(S/'run1/process.json'),overflow=read(S/'summary.json')['diagnostic_meta'],
        correction='Run1 Discarded counts are incomplete where range registration itself was lost to event overflow. Run2 catchup-role Discarded42 versus run1zero is an observation-coverage change, not product behavior. Core Begin/Range/record/hit/miss aggregates match.'),
    next_step='Read the exact state-pool selection and original adapter invalidation branch using these ports/roles. Do not growcache, collapse leases, remove permission gates, or infer a native update cause without source/contract proof.',
    SDK_builds=0,HTTP=0,canonical_product_changes=0,model_processes=2,corrected_processes=1)
(S/'summary2.json').write_text(json.dumps(summary,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
cleanup=[]
for folder in('compile1','compile2','link1','link2'):
    for p in(S/folder).iterdir():
        if p.suffix.lower()in('.obj','.exe','.exp','.lib','.pdb','.dll','.map'):cleanup.append(dict(path=str(p.resolve()),bytes=p.stat().st_size))
(S/'cleanup-candidates.json').write_text(json.dumps(dict(scope='Only this private batch; do not delete here. Root writes test.ps1 after proof review.',files=cleanup,total_logical_bytes=sum(p['bytes']for p in cleanup),note='DLLs are hard links to unchanged cached native DLL; total is logical file lengths, not unique allocated disk bytes.'),indent=2)+'\n')
files=[p for p in S.rglob('*')if p.is_file()and p.name!='proof.zip'and p.suffix.lower()not in('.obj','.exe','.exp','.lib','.pdb','.dll','.map','.pyc')]
with zipfile.ZipFile(S/'proof.zip','w',zipfile.ZIP_DEFLATED,compresslevel=6)as z:
    for p in sorted(files):z.write(p,p.relative_to(S).as_posix())
print(json.dumps(dict(summary=pin(S/'summary2.json'),proof=pin(S/'proof.zip'),cleanup_bytes=sum(p['bytes']for p in cleanup),events=meta['events'],differences=meta['differences'])))
