# Capture miss：最小诊断方案与本次实际边界

目标是区分物理tuple变化、显式资源／配置撤销、资格变化及native更新，保留现有两variant和GraphExecUpdate。不是预热、加cache或跳过权限检查。

## 确切源码事实

- `src/graph/executable.cc:1178` 的key比较只认valid、TensorDesc、resource、native_handle、offset、size；不缓存permission或owner。`:1203`才记住同样的借用tuple。
- `:1336`每次seal仍核原slot权限；`:1352–1450`重新准备时区分stable identity、revision、native inputs和实际端口变化；只有合法的普通TensorView变化可recycle。
- `:8102–8155`将retired命令停放回variant，或转为无launch权的rebuild seed，或明确discard；不是所有rebind都应摧毁cache。
- `:9555–9572` Queue owner变化撤销旧capture；`:9717–9755`先保留range命中、再试两个variant、最后才选择淘汰／重录。
- `:9802–9850` Graph只看到capture end结果及rebuild seed；`src/compute_backend_cuda/cuda_backend.cc:1312–1350`内部才知道GraphExecUpdate结果／errorNode。单Graph TU不能认证native拓扑变化，必须保留unknown。

## 已实施的私有插点

只在overlay `executable.cc`插入观察语句，借用私有 `capture_probe.h`；无canonical修改。完整`source.patch`和`equivalence.json`保存；去掉标记插入后与原479,069B源码逐字一致。

- 每Invocation前20次prepare记录；所有后续prepare仍保有限counter。plan/Invocation/range身份不跨对象混算。
- 记录retained／variant hit、record、qualify、seal失败、显式invalidate／recycle、Queue变化。key记录含当前／旧两个指纹、完整骨架指纹、首不等端口旧／新POD tuple、step/port/ValueId/instance/storage domain。
- 指纹只是定位线索；真正命中仍由原exact比较决定，不把相同hash当权限／拓扑证明。
- 固定64slots、128range索引、4096events、2048differences；无vector、TensorView／lease持有、GPU readback或额外提交。计数溢出显式报告。
- `atexit`在CLI返回后统一stderr输出；token内无打印。callback不调用原生更新检查或更改owner／退休状态。
- 编译复用`current-cuda/product-0/command.json`，仅换1个Graph TU；链接复用clean baseline，app、report及其余3Graph OBJ未改。

## 实际唯一进程与不能隐去的仪器失败

`compile1`严格`/O2 /W4 /WX`通过6.125s；`link1`通过1.969s。`run1`原MTP两轮命令exit0、3.828s；无profile、SDK、HTTP或第二次模型运行。

原raw stdout与clean c343基线逐字段比较，仅剔除明确时间／吞吐字段：**所有非时间字段完全一致**。128输出、309 target prefill、310 draft prefill、132验证行、441／434实际target／draft行、66轮、consumed60均保留。基线`consumer-result.json`有flatten适配，比较采用双方原始stdout。

但是，首次Begin之前和首次Queue切换的大量cold失效占满4096详细event，另5690条eligible记录溢出。只留下两份尚无旧key的cold range快照，**没有有效old/new tuple对照**；0个difference不能解释为tuple没变。本次诊断对此部分不成功。

全程aggregate未丢：4个Invocation prepares为1/8/58/1；两个MTP角色各2range，共132决策=32重录+10retained命中+90variant命中。无seal failure、无诊断writer竞争。权限撤销和后续key变化的具体原因仍未知，不能由这些计数单独归因。

若未来另获一次诊断授权，最小修正是：首次Begin前只计数；每prepare限制失效／Queue细节，并为range／decision独立保留容量；Begin之间的失效标成“上次prepare之后、下次Begin之前”。本次不为修仪器再加进程、不扩大缓存。

## 冻结身份

- clean `baseline/link/hyle.exe`: `c343db76232c4b5bd34878820433057b8c23789cd1b170b6a3b86cd91bf82fa1`
- canonical `src/graph/executable.cc`: `8652cbd963069623860074e3bf874bb8574a31e27b1f3f6a945f7b37484b95bc`
- `src/graph/plan_state.h`: `1627134068f7e8c2002a1dc8d7bb722a369a67c70e94dddf3f6b0841d303b9fc`
- 原Graph OBJ: `cfbb1c5508e179fc7f629c58cf8551a88bda5d0e488953a46d62673a47668f55`
- 其余3Graph OBJ SHA依次 `5b9e3721…`／`0394104d…`／`f4bd84ea…`，保持原闭包。
- 私有image: `74f54914ced1fdc8772ad0e20c23840ab7dbdde56408a30d5bb8fceeff41eba7`

详细命令、source/实际include pins、原stderr、容量失败、对照与完整aggregate见`summary.json`；时长／cache数字不作为性能或内存证据。
