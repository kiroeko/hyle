// Private diagnostic only. Included inside executable.cc's anonymous namespace.
namespace capture_probe {
enum Kind : unsigned { Begin, Range, RetainedHit, VariantHit, Miss, RecordBegin,
  RecordEnd, Recorded, Invalidated, Discarded, Qualification, SealFailure, QueueChanged, Count };
struct Physical {
  compute::TensorDesc description;
  std::uintptr_t resource, handle;
  std::size_t offset, bytes;
  bool valid;
};
struct Slot {
  std::uintptr_t invocation, plan;
  unsigned prepares, ranges;
  unsigned long long totals[Count];
};
struct Event {
  unsigned seq, slot, prepare, kind, a, b, c, d;
  unsigned long long current, cached0, cached1, topology;
  std::uintptr_t pointer;
};
struct Difference {
  unsigned event, variant, flat, step, output, port, instance, value, domain, flags;
  Physical old_value, new_value;
};
struct Saved {
  std::uintptr_t address;
  unsigned slot, begin, count;
};
struct Store {
  Slot slots[64]; Saved saved[128]; Event events[4096]; Difference differences[2048];
  unsigned slot_count, saved_count, event_count, difference_count;
  unsigned long long event_overflow, difference_overflow, slot_overflow, contention;
};
static_assert(std::is_trivially_copyable_v<Physical> && std::is_trivially_copyable_v<Store>);
inline Store data{};
inline std::atomic_flag writing = ATOMIC_FLAG_INIT;
inline std::atomic<unsigned long long> concurrent_skips{0};
struct Guard {
  bool acquired = !writing.test_and_set(std::memory_order_acquire);
  Guard() noexcept { if (!acquired) concurrent_skips.fetch_add(1, std::memory_order_relaxed); }
  ~Guard() { if (acquired) writing.clear(std::memory_order_release); }
};
inline unsigned find(detail::InvocationState &inv) noexcept {
  const auto address = reinterpret_cast<std::uintptr_t>(&inv);
  const auto plan_address = reinterpret_cast<std::uintptr_t>(inv.plan);
  for (unsigned i = 0; i < data.slot_count; ++i)
    if (data.slots[i].invocation == address && data.slots[i].plan == plan_address) return i;
  if (data.slot_count == 64) { ++data.slot_overflow; return 64; }
  const unsigned i = data.slot_count++;
  data.slots[i].invocation = address; data.slots[i].plan = plan_address;
  return i;
}
inline Event *append(unsigned slot, Kind kind) noexcept {
  if (slot == 64) return nullptr;
  auto &entry = data.slots[slot]; ++entry.totals[kind];
  // Counts continue for the complete journey; detailed tuples are bounded.
  if (entry.prepares > 20) return nullptr;
  if (data.event_count == 4096) { ++data.event_overflow; return nullptr; }
  auto &event = data.events[data.event_count++];
  event.seq = data.event_count; event.slot = slot; event.prepare = entry.prepares; event.kind = kind;
  return &event;
}
inline Physical physical(compute::ConstTensorView view) noexcept {
  Physical out{}; out.valid = view.valid(); out.description = view.description();
  const auto storage = view.storage();
  if (storage.resource().valid()) out.resource = reinterpret_cast<std::uintptr_t>(&storage.resource().resource());
  out.handle = reinterpret_cast<std::uintptr_t>(storage.native_handle());
  out.offset = storage.offset(); out.bytes = storage.size(); return out;
}
inline std::uint64_t word(std::uint64_t state, std::uint64_t value) noexcept {
  return (state ^ value) * 1099511628211ULL;
}
inline std::uint64_t hash_view(std::uint64_t state, compute::ConstTensorView view) noexcept {
  const auto value = physical(view); const auto &desc = value.description;
  state = word(state, value.valid); state = word(state, static_cast<unsigned>(desc.data_type()));
  state = word(state, desc.rank()); state = word(state, desc.block_axis().value_or(SIZE_MAX));
  const auto &format = desc.storage_format();
  state = word(state, static_cast<unsigned>(format.kind()));
  state = word(state, format.id().namespace_id); state = word(state, format.id().format_id);
  state = word(state, format.elements_per_block()); state = word(state, format.bytes_per_block());
  state = word(state, format.required_alignment());
  for (auto dimension : desc.dimensions()) state = word(state, static_cast<std::uint64_t>(dimension));
  for (auto stride : desc.byte_strides()) state = word(state, static_cast<std::uint64_t>(stride));
  if (desc.valid() && format.kind() == compute::StorageFormatKind::kOpaque) {
    auto bytes = desc.required_bytes(); state = word(state, bytes ? *bytes : SIZE_MAX);
  }
  state = word(state, value.resource); state = word(state, value.handle);
  state = word(state, value.offset); return word(state, value.bytes);
}
inline void difference(Event &event, unsigned variant, unsigned flat, unsigned step,
                       unsigned output, unsigned port, unsigned instance,
                       const detail::PlanState &plan, compute::ConstTensorView old_view,
                       compute::ConstTensorView new_view) noexcept {
  const auto old_value = physical(old_view), new_value = physical(new_view);
  unsigned flags = (old_value.valid != new_value.valid ? 1U : 0U) |
      (old_value.description != new_value.description ? 2U : 0U) |
      (old_value.resource != new_value.resource ? 4U : 0U) |
      (old_value.handle != new_value.handle ? 8U : 0U) |
      (old_value.offset != new_value.offset ? 16U : 0U) |
      (old_value.bytes != new_value.bytes ? 32U : 0U);
  if (!flags) return;
  if (data.difference_count == 2048) { ++data.difference_overflow; return; }
  auto &out = data.differences[data.difference_count++];
  out = {event.seq, variant, flat, step, output, port, instance, plan.instance_values[instance],
         plan.instance_storage[instance], flags, old_value, new_value};
}
inline void begin(detail::InvocationState &inv, ReplayMode mode) noexcept {
  Guard guard; if (!guard.acquired) return; const unsigned slot = find(inv); if (slot == 64) return;
  ++data.slots[slot].prepares;
  if (auto *event = append(slot, Begin)) {
    event->a = static_cast<unsigned>(mode); event->b = static_cast<unsigned>(inv.plan->steps.size());
    event->c = inv.plan->command_count; event->d = static_cast<unsigned>(inv.plan->capture_ranges.size());
  }
}
inline void range(detail::InvocationState &inv, const detail::PlanCaptureRange &range_value) noexcept {
  Guard guard; if (!guard.acquired) return; const unsigned slot = find(inv);
  auto *event = append(slot, Range); if (!event) return;
  event->a = range_value.step_begin; event->b = range_value.step_count; event->c = range_value.command_count;
  detail::CaptureRebuildRange *saved = nullptr;
  for (auto &candidate : inv.capture_rebuilds)
    if (candidate.step_begin == range_value.step_begin && candidate.step_count == range_value.step_count) saved = &candidate;
  if (saved) {
    event->pointer = reinterpret_cast<std::uintptr_t>(saved);
    event->d = (saved->qualification_valid ? 1U : 0U) | (saved->preserves_private_arguments ? 2U : 0U) |
        (saved->storage.valid() ? 4U : 0U) | (unsigned(saved->active_variant) << 8) | (unsigned(saved->last_used) << 12);
    for (unsigned index = 0; index < 2; ++index)
      event->d |= (saved->variants[index].key_valid ? 1U : 0U) << (16 + index * 2) |
                  (saved->variants[index].commands.valid() ? 1U : 0U) << (17 + index * 2);
    bool known = false;
    for (unsigned index = 0; index < data.saved_count; ++index) known |= data.saved[index].address == event->pointer;
    if (!known && data.saved_count < 128) data.saved[data.saved_count++] = {event->pointer, slot, event->a, event->b};
  }
  std::uint64_t current = 1469598103934665603ULL, previous[2]{current, current}, topology = current;
  unsigned flat = 0; bool different[2]{};
  for (std::size_t index = range_value.step_begin; index < std::size_t{range_value.step_begin} + range_value.step_count; ++index) {
    const auto &step = inv.plan->steps[index]; if (!step.emits_command()) continue;
    topology = word(topology, static_cast<unsigned>(step.kind)); topology = word(topology, step.node_begin);
    topology = word(topology, step.node_count); topology = word(topology, step.input_count);
    topology = word(topology, step.output_count); topology = word(topology, step.target.ordinal());
    auto observe = [&](compute::ConstTensorView view, unsigned output, unsigned port, unsigned instance) noexcept {
      current = hash_view(current, view);
      for (unsigned variant = 0; variant < 2; ++variant) {
        if (!saved || !saved->variants[variant].key_valid || flat >= saved->variants[variant].bindings.size()) continue;
        auto old_view = saved->variants[variant].bindings[flat]; previous[variant] = hash_view(previous[variant], old_view);
        if (!different[variant]) {
          const auto before = data.difference_count;
          difference(*event, variant, flat, static_cast<unsigned>(index), output, port, instance, *inv.plan, old_view, view);
          different[variant] = before != data.difference_count;
        }
      }
      ++flat;
    };
    for (unsigned input = 0; input < step.input_count; ++input)
      observe(inv.submission_inputs[step.input_begin + input], 0, input, inv.plan->node_inputs[step.input_begin + input]);
    for (unsigned output = 0; output < step.output_count; ++output)
      observe(inv.submission_outputs[step.output_begin + output].as_const(), 1, output, inv.plan->node_outputs[step.output_begin + output]);
  }
  event->current = current; event->cached0 = previous[0]; event->cached1 = previous[1]; event->topology = topology;
}
inline void note(detail::InvocationState &inv, Kind kind, unsigned a = 0, unsigned b = 0,
                 unsigned c = 0, unsigned d = 0, std::uintptr_t pointer = 0) noexcept {
  Guard guard; if (!guard.acquired) return;
  if (auto *event = append(find(inv), kind)) { event->a = a; event->b = b; event->c = c; event->d = d; event->pointer = pointer; }
}
inline void discard(detail::CaptureRebuildRange &range_value) noexcept {
  Guard guard; if (!guard.acquired) return;
  const auto address = reinterpret_cast<std::uintptr_t>(&range_value);
  for (unsigned index = 0; index < data.saved_count; ++index) if (data.saved[index].address == address) {
    if (auto *event = append(data.saved[index].slot, Discarded)) {
      event->a = range_value.step_begin; event->b = range_value.step_count;
      event->c = unsigned(range_value.active_variant); event->d = range_value.qualification_valid;
    }
    return;
  }
}
inline void print_physical(const Physical &value) noexcept {
  const auto &desc = value.description;
  std::fprintf(stderr, "{\"valid\":%u,\"resource\":%llu,\"handle\":%llu,\"offset\":%zu,\"bytes\":%zu,\"dtype\":%u,\"dims\":[",
      unsigned(value.valid), static_cast<unsigned long long>(value.resource), static_cast<unsigned long long>(value.handle),
      value.offset, value.bytes, static_cast<unsigned>(desc.data_type()));
  for (std::size_t index = 0; index < desc.rank(); ++index) std::fprintf(stderr, "%s%lld", index ? "," : "", static_cast<long long>(desc.dimensions()[index]));
  std::fprintf(stderr, "],\"strides\":[");
  for (std::size_t index = 0; index < desc.byte_strides().size(); ++index) std::fprintf(stderr, "%s%lld", index ? "," : "", static_cast<long long>(desc.byte_strides()[index]));
  std::fprintf(stderr, "]}");
}
inline void dump() noexcept {
  static constexpr const char *labels[Count] = {"begin", "range", "retained_hit", "variant_hit", "miss", "record_begin", "record_end", "recorded", "invalidated", "discarded", "qualification", "seal_failure", "queue_changed"};
  std::fprintf(stderr, "CAPDIAG {\"type\":\"meta\",\"slots\":%u,\"events\":%u,\"differences\":%u,\"event_overflow\":%llu,\"difference_overflow\":%llu,\"slot_overflow\":%llu,\"concurrent_skips\":%llu}\n",
      data.slot_count, data.event_count, data.difference_count, data.event_overflow, data.difference_overflow, data.slot_overflow, concurrent_skips.load());
  for (unsigned i = 0; i < data.slot_count; ++i) {
    const auto &slot = data.slots[i];
    std::fprintf(stderr, "CAPDIAG {\"type\":\"slot\",\"slot\":%u,\"invocation\":%llu,\"plan\":%llu,\"prepares\":%u,\"totals\":{", i,
        static_cast<unsigned long long>(slot.invocation), static_cast<unsigned long long>(slot.plan), slot.prepares);
    for (unsigned kind = 0; kind < Count; ++kind) std::fprintf(stderr, "%s\"%s\":%llu", kind ? "," : "", labels[kind], slot.totals[kind]);
    std::fprintf(stderr, "}}\n");
  }
  for (unsigned i = 0; i < data.event_count; ++i) {
    const auto &event = data.events[i];
    std::fprintf(stderr, "CAPDIAG {\"type\":\"event\",\"seq\":%u,\"slot\":%u,\"prepare\":%u,\"kind\":\"%s\",\"a\":%u,\"b\":%u,\"c\":%u,\"d\":%u,\"current\":%llu,\"cached0\":%llu,\"cached1\":%llu,\"topology\":%llu,\"pointer\":%llu}\n",
        event.seq, event.slot, event.prepare, labels[event.kind], event.a, event.b, event.c, event.d,
        event.current, event.cached0, event.cached1, event.topology, static_cast<unsigned long long>(event.pointer));
  }
  for (unsigned i = 0; i < data.difference_count; ++i) {
    const auto &diff = data.differences[i];
    std::fprintf(stderr, "CAPDIAG {\"type\":\"difference\",\"event\":%u,\"variant\":%u,\"flat\":%u,\"step\":%u,\"output\":%u,\"port\":%u,\"instance\":%u,\"value\":%u,\"domain\":%u,\"flags\":%u,\"old\":",
        diff.event, diff.variant, diff.flat, diff.step, diff.output, diff.port, diff.instance, diff.value, diff.domain, diff.flags);
    print_physical(diff.old_value); std::fprintf(stderr, ",\"new\":"); print_physical(diff.new_value); std::fprintf(stderr, "}\n");
  }
}
[[maybe_unused]] inline const int registered = std::atexit(dump);
} // namespace capture_probe
