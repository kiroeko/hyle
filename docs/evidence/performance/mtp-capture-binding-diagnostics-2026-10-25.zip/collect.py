"""Offline collection only; never builds, runs a model, or downloads."""
from pathlib import Path
import hashlib, json
S=Path(__file__).resolve().parent; R=S.parents[1]
B=R/'.scratch/mtp-performance-convergence-20261025/baseline'
def pin(path):
    return dict(path=str(path),bytes=path.stat().st_size,sha256=hashlib.sha256(path.read_bytes()).hexdigest())
def read(path):return json.loads(path.read_text(encoding='utf-8-sig'))
def raw(path):return json.loads(next(line for line in path.read_text(encoding='utf-8').splitlines()if line.startswith('{')))
actual=raw(S/'run1/stdout.log'); baseline=raw(B/'two-turn-timing/02-hyle_mtp/stdout.log')
differences=[]; excluded=[]
def compare(left,right,path=''):
    if type(left)!=type(right):differences.append(dict(path=path,actual=left,expected=right));return
    if isinstance(left,dict):
        for key in sorted(left.keys()|right.keys()):
            if key=='seconds'or key.endswith('_seconds')or'tokens_per_second'in key:excluded.append(path+'/'+key);continue
            if key not in left or key not in right:differences.append(dict(path=path+'/'+key,missing=True));continue
            compare(left[key],right[key],path+'/'+key)
    elif isinstance(left,list):
        if len(left)!=len(right):differences.append(dict(path=path,lengths=[len(left),len(right)]));return
        for index,(a,b)in enumerate(zip(left,right)):compare(a,b,path+'/'+str(index))
    elif left!=right:differences.append(dict(path=path,actual=left,expected=right))
compare(actual,baseline)
rows=[json.loads(line[8:])for line in(S/'run1/stderr.log').read_text().splitlines()if line.startswith('CAPDIAG ')]
meta=next(row for row in rows if row['type']=='meta'); slots=[row for row in rows if row['type']=='slot']
process=read(S/'run1/process.json')
assert process['exit']==0 and not process['timeout'] and not differences
work_keys=('generated_tokens','prefill_target_rows','prefill_draft_rows','verified_target_rows','actual_target_rows','actual_draft_rows','draft_rounds','consumed_drafts')
summary=dict(status='actual_work_preserved_but_diagnostic_detail_capacity_exhausted',
    created_by=pin(Path(__file__)),source_equivalence=read(S/'equivalence.json'),ready=read(S/'ready.json'),process=process,
    comparison=dict(reference=pin(B/'two-turn-timing/02-hyle_mtp/stdout.log'),actual=pin(S/'run1/stdout.log'),
        raw_to_raw=True,non_time_all_fields_equal=True,differences=differences,excluded_timing_paths=excluded,
        note='Baseline consumer-result.json is a schema adapter with flattened session fields; compare the authoritative raw stdout reports instead.'),
    work={key:actual.get(key)for key in work_keys},diagnostic_meta=meta,slot_aggregates=slots,
    facts=['4 Invocation objects prepared1/8/58/1times; sum68 matches the unchanged actual graph call count.',
           'The two MTP shape/role invocations each have2capture ranges. Their complete counters show32recorded ranges and100reused ranges (10 retained hits+90variant hits).',
           'No seal failure or concurrent diagnostic writer skip was observed. This does not prove permission revocation never occurred.',
           'Initial cold step invalidations and queue-change records consumed4096event slots;5690further eligible events overflowed. Only2range snapshots survived, both cold with no prior valid keys.',
           'Zero stored differences is a diagnostic coverage failure, not evidence of unchanged physical tuples.'],
    conclusions=['Existing variant reuse is actually exercised, especially90variant hits in the58-call role; blanket claims of no capture cache reuse are false.',
                 'This process cannot identify whether remaining misses are address cycling, page binding, explicit authority/configuration invalidation or native structural differences. Preserve unknown.',
                 'Graph TU sees rebuild seed and capture completion only. Native GraphExecUpdate result/errorNode remains below this seam and is not inferred from unchanged logical plan topology.'],
    next_instrumentation_correction='Not run: suppress pre-first-Begin detail; retain cold counters. Cap detailed invalidation/queue events per prepare separately from reserved range/decision records. Attribute between-Begin invalidation to the interval after previous prepare, not its execution. No second process was launched.',
    limits=['One instrumented diagnostic process, no profiler. Timing/memory numbers from this image are not performance or memory evidence.',
            'POD arrays/borrowed addresses do not keep TensorView/lease/owner references; diagnostic BSS is outside the model cache budget.',
            'Full aggregate counters continue after20prepares; detailed fixed arrays exhausted before meaningful old/new key comparison.',
            'No canonical source, graph/math, cache size,2variant policy, permission/retirement gate or GraphExecUpdate behavior changed.'],
    files=[pin(S/name)for name in('check.py','capture_probe.h','source.patch','before-executable.cc','overlay/executable.cc','equivalence.json','compile1/command.json','compile1/source-pins.json','compile1/stdout.log','compile1/stderr.log','compile1/process.json','link1/command.json','link1/stdout.log','link1/stderr.log','link1/process.json','run1/command.json','run1/stdout.log','run1/stderr.log','run1/process.json')])
# Correct count: two MTP invocations have16+116=132range decisions,32records+100reuses.
assert sum(s['totals']['range']for s in slots)==132
assert sum(s['totals']['recorded']for s in slots)==32
assert sum(s['totals']['retained_hit']+s['totals']['variant_hit']for s in slots)==100
(S/'summary.json').write_text(json.dumps(summary,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
print(json.dumps(dict(status=summary['status'],non_time_all_fields_equal=True,work=summary['work'],diagnostic_meta=meta)))
