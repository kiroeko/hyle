"""Increment the GDN carrier, cold lowerer and small fixture; reuse SDK objects."""
from pathlib import Path
import argparse
import datetime as dt
import importlib.util
import sys
sys.dont_write_bytecode = True
STAGE = Path(__file__).resolve().parent
ARCH = STAGE.parent
ROOT = ARCH.parents[1]
BASE = ARCH / 'decode-next-cold/checks/20261019T155819'
HEADERS = ARCH / 'cuda-fusion-precision/native-source'

def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module

h = load('gdn_build_helpers', ARCH / 'cuda-grouped-fusion/build.py')
b, c = h.b, h.c

def check(plan):
    for row in plan['frozen']:
        if not b.same(row):
            raise ValueError('Source/recipe/header drift: ' + row['path'])

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--build', action='store_true')
    parser.add_argument('--resume', type=Path)
    args = parser.parse_args()
    if args.resume:
        path = args.resume.resolve()
        plan = c.read(path)
        out = path.parent
    else:
        out = STAGE / 'checks' / dt.datetime.now(dt.timezone.utc).strftime('%Y%m%dT%H%M%S')
        out.mkdir(parents=True, exist_ok=False)
        (out / 'tmp').mkdir()
        plan = prepare(out)
        path = out / 'plan.json'
        c.save(path, plan)
    print('PLAN', path, flush=True)
    if not args.build:
        return
    check(plan)
    for row in plan['cached_inputs']:
        if not b.same(row):
            raise ValueError('Cached object/library drift: ' + row['path'])
    env, _ = b.environment(plan['links']['qwen']['command'],
        [row['path'] for row in plan['cached_inputs']], out)
    identities = {c.key(row['path']): row for row in plan['cached_inputs']}
    for row in plan['compile']:
        receipt = out / (row['tag'] + '-identity.json')
        if receipt.exists():
            old = c.read(receipt)
            if old['command'] == row['command'] and b.same(old['object']) and all(b.same(dep) for dep in old['dependencies']):
                identities[c.key(old['object']['path'])] = old['object']
                print('REUSE', row['tag'], flush=True)
                continue
        attempt = 1 + len(list(out.glob(row['tag'] + '-compile-*.result.json')))
        c.execute(row['tag'] + '-compile-' + str(attempt), row['command'], env, out)
        check(plan)
        if row['kind'] == 'host':
            data = c.read(out / (row['tag'] + '-deps.json'))['Data']
            deps = [b.identity(p) for p in [data['Source'], *data['Includes']]]
        else:
            # The actual nvcc Make dependency file remains alongside the exact
            # command. Retained native inputs are frozen explicitly, not inferred
            # from an unrelated host sourceDependencies file.
            deps = [r for r in plan['frozen'] if r['path'].lower().endswith(('.cu', '.cuh', '.h'))]
        record = dict(command=row['command'], source=row['source'], object=b.identity(row['object']), dependencies=deps)
        c.save(receipt, record)
        identities[c.key(record['object']['path'])] = record['object']
        print('COMPILED', row['tag'], flush=True)
    for arm, link in plan['links'].items():
        receipt = out / (arm + '-image.json')
        if receipt.exists() and b.same(c.read(receipt)):
            print('REUSE_IMAGE', arm, flush=True)
            continue
        attempt = 1 + len(list(out.glob(arm + '-link-*.result.json')))
        c.execute(arm + '-link-' + str(attempt), link['command'], env, out)
        check(plan)
        c.save(out / (arm + '-link-plan.json'), dict(command=link['command'], inputs=[identities[c.key(p)] for p in link['inputs']]))
        c.save(receipt, b.identity(link['image']))
    c.save(out / 'summary.json', dict(passed=True, host_TUs=3, native_TUs=2, SDK_build=False, GPU_run=False))
    c.save(STAGE / 'latest-check.json', dict(plan=str(path)))
    print('BUILD_COMPLETE', path, flush=True)

def prepare(out):
    native_root = STAGE / 'native-source'
    native_receipt = STAGE / 'native-source-freeze.json'
    host_receipt = STAGE / 'host-source-freeze.json'
    test_source = ROOT / 'tests/graph_provider_ggml_cuda/gdn_typed_load_test.cc'
    required = [Path(__file__), native_receipt, host_receipt, STAGE / 'provider-version.h',
        ROOT / 'third_party/ggml_cuda_runtime/patches.json', ROOT / 'third_party/ggml_cuda_runtime/NOTICE.md',
        ROOT / 'cmake/HyleDependencyLock.json', ROOT / 'src/compute_provider_ggml_cuda/tensor_program.h',
        ROOT / 'tests/graph_provider_ggml_cuda/CMakeLists.txt', BASE / 'qwen-link-plan.json', BASE / 'qwen-image.json']
    frozen = [b.identity(p) for p in required]
    for seal, source_root in [(native_receipt, native_root), (host_receipt, ROOT)]:
        for row in c.read(seal)['files']:
            actual = b.identity(source_root / row['path'])
            if actual['sha256'] != row.get('after', row)['sha256']:
                raise ValueError('Reviewed source differs: ' + row['path'])
            frozen.append(actual)
    rows = []
    templates = [
        ('native-main', 'native', ARCH / 'cuda-grouped-fusion/checks/20261019T123025/ggml-cuda-identity.json', native_root / 'src/ggml-cuda/ggml-cuda.cu'),
        ('native-gdn', 'native', ARCH / 'cuda-grouped-fusion/checks/20261019T123025/ggml-cuda-identity.json', native_root / 'src/ggml-cuda/gated_delta_net.cu'),
        ('provider', 'host', BASE / '24-compute_provider_ggml_cuda-ggml_cuda_provider-identity.json', ROOT / 'src/compute_provider_ggml_cuda/ggml_cuda_provider.cc'),
        ('tensor-program', 'host', BASE / '27-compute_provider_ggml_cuda-tensor_program-identity.json', ROOT / 'src/compute_provider_ggml_cuda/tensor_program.cc'),
        ('gdn-test', 'host', BASE / '32-graph_route_cuda-sglang_primitives_test-identity.json', test_source),
    ]
    for tag, kind, recipe_path, source in templates:
        recipe = c.read(recipe_path)
        template = recipe['command']
        if kind == 'native':
            command = h.a.strip_ccbin(b.native_command(h.a.strip_ccbin(template), source, tag, out))
            command = [x for x in command if not (x.startswith('-I') and ('architecture-refactor-2026-10-18' in x or 'reference-windows' in x))]
            command[1:1] = ['-I' + str(native_root / 'src/ggml-cuda'), '-I' + str(native_root / 'src'),
                '-I' + str(HEADERS / 'include'), '-I' + str(HEADERS / 'src'), '-I' + str(HEADERS / 'src/ggml-cuda')]
            old = recipe['object'] if tag == 'native-main' else None
        else:
            template = ['/FI' + str(STAGE / 'provider-version.h') if x.lower().startswith('/fi') else x for x in template]
            command = b.host_command(template, source, tag, out)
            command[1:1] = ['/external:I' + str(native_root / 'src/ggml-cuda')]
            old = recipe['object'] if tag != 'gdn-test' else None
            frozen += [b.identity(p) for p in b.host_dependencies(template)]
        row = dict(tag=tag, kind=kind, source=b.identity(source), recipe=b.identity(recipe_path), command=command,
            object=str(out / (tag + '.obj')), old_object=old)
        rows.append(row)
        frozen += [row['source'], row['recipe']]
        relative = source.relative_to(ROOT)
        snapshot = out / 'compiled-source' / relative
        snapshot.parent.mkdir(parents=True, exist_ok=True)
        snapshot.write_bytes(source.read_bytes())
        frozen.append(b.identity(snapshot))
    for p in sorted(native_root.rglob('*')):
        if p.is_file():
            frozen.append(b.identity(p))
    header_receipt = ARCH / 'cuda-fusion-precision/header-closure.json'
    frozen.append(b.identity(header_receipt))
    for row in c.read(header_receipt)['headers']:
        actual = b.identity(HEADERS / row['path'])
        if actual['sha256'] != row['sha256']:
            raise ValueError('Coherent private native header changed')
        frozen.append(actual)
    base = c.read(BASE / 'qwen-link-plan.json')
    base_cpu = c.read(BASE / 'cpu-link-plan.json')
    cached = {c.key(row['path']): row for row in base['inputs']}
    gtests = [row for row in base_cpu['inputs'] if Path(row['path']).name.lower() in ('gtest.lib', 'gtest_main.lib')]
    assert len(gtests) == 2
    cached.update({c.key(row['path']):row for row in gtests})
    replacements = {c.key(row['old_object']['path']):row['object'] for row in rows if row['old_object']}
    assert len(replacements) == 3 and set(replacements) <= set(cached)
    for row in rows:
        if row['old_object'] and cached[c.key(row['old_object']['path'])] != row['old_object']:
            raise ValueError('Replacement identity differs: ' + row['tag'])
    main = next(row['path'] for row in base['inputs'] if Path(row['path']).name == '29-qwen35_text-main.obj')
    links = {}
    for arm in ('qwen', 'gdn'):
        command = [replacements.get(c.key(x),x) for x in base['command'] if not x.upper().startswith(('/OUT:', '/MAP:', '/IMPLIB:', '/PDB:'))]
        # Explicit object satisfies the GDN symbols before archive extraction;
        # the unchanged CUDA library therefore supplies all other cached TUs.
        command.insert(1, next(row['object'] for row in rows if row['tag']=='native-gdn'))
        if arm == 'gdn':
            command = [x for x in command if c.key(x) != c.key(main)]
            command[1:1] = [next(row['object'] for row in rows if row['tag']=='gdn-test'), *(r['path'] for r in gtests)]
        image = out / (arm + '.exe')
        command += ['/OUT:' + str(image), '/MAP:' + str(image.with_suffix('.map')), '/IMPLIB:' + str(image.with_suffix('.lib'))]
        inputs = [x for x in command if Path(x).is_absolute() and x.lower().endswith(('.obj','.lib')) and not x.upper().startswith(('/OUT:', '/MAP:', '/IMPLIB:', '/PDB:'))]
        assert len(inputs) == (128 if arm=='qwen' else 130) and len(set(map(c.key,inputs)))==len(inputs)
        links[arm] = dict(command=command, inputs=inputs, image=str(image))
    return dict(compile=rows, links=links, frozen=list({c.key(r['path']):r for r in frozen}.values()), cached_inputs=list(cached.values()),
        host_TUs=3, native_TUs=2, private_shared_ABI_changed=False, SDK_build=False, GPU_run=False,
        gdn_recipe_basis='Same actual ggml-cuda target command flags as main; upstream CMake CUDA_FLAGS apply uniformly and contain no GDN-specific source flags.',
        baseline_image=c.read(BASE / 'qwen-image.json'))

if __name__ == '__main__':
    main()
