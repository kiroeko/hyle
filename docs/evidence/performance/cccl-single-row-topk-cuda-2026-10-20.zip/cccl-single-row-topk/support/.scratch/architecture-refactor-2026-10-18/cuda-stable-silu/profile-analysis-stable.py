"""Offline stable-SiLU evidence from official Nsight SQLite/CSV exports only.

No compiler, GPU process, profiler, native library, or external module is loaded.
Kernel expectations are reported as observations, never asserted as success.
"""
from pathlib import Path
import bisect
import collections
import csv
import hashlib
import json
import re
import sqlite3
import statistics
import sys

sys.dont_write_bytecode = True
STAGE = Path(__file__).resolve().parent
PROFILE = STAGE / "profile"
BASELINE = STAGE.parent / "cuda-bf16-chain-fusion/profile"
STEM = "qwen-stable-silu-trace"
FINAL_IMAGE_SHA256 = "5d0708415f863e582bbc6ac3b48beaf346960dd86f94f396f18a26151b015ac7"


def read(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def save(path, value):
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


def identity(path):
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(4 * 1024 * 1024), b""):
            digest.update(block)
    return dict(path=str(path.resolve()), bytes=path.stat().st_size, sha256=digest.hexdigest())


def distribution(values):
    values = list(values)
    if not values:
        return dict(samples=[], min=None, median=None, max=None)
    return dict(samples=values, min=min(values), median=statistics.median(values), max=max(values))


def template_arguments(name, kernel):
    """Split the outer template list without relying on a shortened symbol."""
    start = name.find(kernel + "<")
    if start < 0:
        return []
    start += len(kernel) + 1
    depth, begin, arguments = 0, start, []
    for index in range(start, len(name)):
        char = name[index]
        if char == "<":
            depth += 1
        elif char == ">":
            if depth == 0:
                return arguments + [name[begin:index].strip()]
            depth -= 1
        elif char == "," and depth == 0:
            arguments.append(name[begin:index].strip())
            begin = index + 1
    return []


def dtype(argument):
    value = argument.strip().replace("const ", "")
    if value in ("__nv_bfloat16", "nv_bfloat16"):
        return "bf16"
    if value == "float":
        return "f32"
    if value in ("half", "__half"):
        return "f16"
    return "unknown"


def classify(name):
    args = template_arguments(name, "unary_gated_op_kernel")
    if "unary_gated_op_kernel" in name:
        kind = dtype(args[1]) if len(args) > 1 else "unknown"
        marked = bool(args and "op_hyle_stable_silu" in args[0])
        value = re.sub(r"\s+", "", args[2]) if len(args) > 2 else "unknown"
        rounded = "true" if value in ("true", "(bool)1") else (
            "false" if value in ("false", "(bool)0") else "unknown")
        family = "stable_silu_mul" if marked else "other_unary_gated"
        return dict(category=f"{family}_{kind}_{rounded}", family=family,
                    dtype=kind, round_unary=rounded, stable_helper=marked,
                    template_identity_resolved=len(args) >= 3)
    args = template_arguments(name, "unary_op_kernel")
    if args and "op_hyle_stable_silu" in args[0]:
        kind = dtype(args[1]) if len(args) > 1 else "unknown"
        return dict(category="stable_silu_standalone_" + kind,
                    family="stable_silu_standalone", dtype=kind, stable_helper=True,
                    template_identity_resolved=kind != "unknown")
    args = template_arguments(name, "act_kernel")
    if "sglang_vendor::act_kernel" in name and len(args) >= 3:
        kind = dtype(args[0])
        if re.sub(r"\s+", "", args[1]).endswith("ActivationKind)0") and \
                re.sub(r"\s+", "", args[2]) in ("false", "(bool)0"):
            return dict(category="sglang_silu_" + kind, family="sglang_silu",
                        dtype=kind, stable_helper=False, template_identity_resolved=True)
    args = template_arguments(name, "k_bin_bcast")
    if args and "op_mul" in args[0]:
        kind = dtype(args[1]) if len(args) > 1 else "unknown"
        return dict(category="standalone_multiply_" + kind,
                    family="standalone_multiply", dtype=kind, stable_helper=False,
                    template_identity_resolved=kind != "unknown")
    return dict(category="other", family="other")


def parse_target(stdout, stderr):
    output = None
    for line in reversed(stdout.splitlines()):
        if line.lstrip().startswith("{"):
            try:
                candidate = json.loads(line)
            except json.JSONDecodeError:
                continue
            if "generated_ids" in candidate:
                output = candidate
                break
    captures = [dict(recorded=int(a), reused=int(b)) for a, b in re.findall(
        r"capture_recorded=(\d+) capture_reused=(\d+)", stderr)]
    phase_labels = re.findall(r"^(prefill|decode\d+) tokens=", stderr, re.M)
    return dict(output=output, capture_counts=captures, phase_labels=phase_labels,
                capture_recorded_total=sum(row["recorded"] for row in captures),
                capture_reused_total=sum(row["reused"] for row in captures))


def load(sqlite_path, csv_path, candidate=False):
    con = sqlite3.connect(sqlite_path.resolve().as_uri() + "?mode=ro", uri=True)
    con.row_factory = sqlite3.Row
    try:
        tables = {row[0] for row in con.execute("select name from sqlite_master where type='table'")}
        diagnostics = [dict(row) for row in con.execute("select * from DIAGNOSTIC_EVENT")] \
            if "DIAGNOSTIC_EVENT" in tables else []
        streams = {}
        if "ANALYSIS_FILE" in tables:
            for filename, value, pid in con.execute(
                    "select a.filename,s.value,a.globalPid from ANALYSIS_FILE a "
                    "join StringIds s on s.id=a.contentId"):
                if "/streams/" in filename.replace("\\", "/"):
                    kind = "stderr" if "stderr_" in filename else "stdout"
                    streams.setdefault(kind, []).append(dict(filename=filename, content=value, globalPid=pid))
        strings = dict(con.execute("select id,value from StringIds"))
        kernels = []
        for original in con.execute("select * from CUPTI_ACTIVITY_KIND_KERNEL order by start"):
            row = dict(original)
            names = {key: strings.get(row.get(key), "") for key in
                     ("demangledName", "shortName", "mangledName")}
            name = names["demangledName"] or names["shortName"] or names["mangledName"]
            kernels.append(dict(start=row["start"], end=row["end"], name=name,
                names=names, classification=classify(name),
                **{key: row.get(key) for key in ("streamId", "graphId", "graphNodeId",
                    "correlationId", "globalPid", "gridX", "gridY", "gridZ", "blockX", "blockY", "blockZ")}))
        copies = [dict(row) for row in con.execute(
            "select start,end,bytes,copyKind from CUPTI_ACTIVITY_KIND_MEMCPY order by start")]
        graph_apis = {}
        for table in ("CUPTI_ACTIVITY_KIND_RUNTIME", "CUPTI_ACTIVITY_KIND_DRIVER"):
            if table in tables:
                graph_apis[table] = [dict(row) for row in con.execute(
                    "select a.start,a.end,a.correlationId,a.returnValue,s.value as name from " +
                    table + " a join StringIds s on s.id=a.nameId "
                    "where s.value like '%GraphLaunch%' order by a.start")]
    finally:
        con.close()
    with csv_path.open(encoding="utf-8-sig", newline="") as stream:
        csv_counts = collections.Counter({row["Name"]: int(row["Instances"].replace(",", ""))
                                         for row in csv.DictReader(stream)})
    physical = collections.Counter(row["name"] for row in kernels)
    selected_table = next((name for name in ("CUPTI_ACTIVITY_KIND_RUNTIME", "CUPTI_ACTIVITY_KIND_DRIVER")
                           if graph_apis.get(name)), None)
    launches = graph_apis.get(selected_table, [])
    texts = {kind: "\n".join(row["content"] for row in rows) for kind, rows in streams.items()}
    target = parse_target(texts.get("stdout", ""), texts.get("stderr", ""))
    pids = sorted({int(match.group(1)) for row in diagnostics for match in
                   re.finditer(r"Process (\d+) was launched by the profiler", row["text"])})
    receipt = dict(sqlite=identity(sqlite_path), official_csv=identity(csv_path),
        physical_kernel_count=len(kernels), official_csv_kernel_count=sum(csv_counts.values()),
        csv_sqlite_per_symbol_counts_equal=csv_counts == physical,
        csv_sqlite_differences=[dict(name=name, sqlite=physical[name], csv=csv_counts[name])
                               for name in sorted(physical.keys() | csv_counts.keys())
                               if physical[name] != csv_counts[name]],
        graph_launch_api_table=selected_table,
        graph_launch_counts_by_table={key: len(value) for key, value in graph_apis.items()},
        graph_launch_count_method="Prefer runtime rows when present, otherwise driver; never add nested table representations.",
        graph_api_failures=[dict(table=key, **row) for key, rows in graph_apis.items()
                            for row in rows if row["returnValue"] != 0],
        target_pids=pids, diagnostics_count=len(diagnostics),
        warnings=[row for row in diagnostics if row["severity"] >= 2])
    if candidate:
        diagnostic_path = PROFILE / "stable-silu-diagnostics.json"
        save(diagnostic_path, diagnostics)
        receipt["diagnostics"] = identity(diagnostic_path)
        receipt["embedded_target_logs"] = {}
        for kind, value in texts.items():
            path = PROFILE / ("stable-silu-target-" + kind + ".log")
            path.write_text(value, encoding="utf-8")
            receipt["embedded_target_logs"][kind] = identity(path)
        receipt["embedded_stream_sources"] = {
            kind: [dict(filename=row["filename"], globalPid=row["globalPid"]) for row in rows]
            for kind, rows in streams.items()}
    return dict(kernels=kernels, copies=copies, launches=launches, target=target, receipt=receipt)


CATEGORIES = tuple([f"stable_silu_mul_{kind}_{flag}" for kind in ("bf16", "f32", "f16", "unknown")
                    for flag in ("true", "false", "unknown")] +
                   [f"{family}_{kind}" for family in ("stable_silu_standalone", "sglang_silu", "standalone_multiply")
                    for kind in ("bf16", "f32", "f16", "unknown")])


def phases(data):
    endpoints = [row["end"] for row in data["copies"] if row["copyKind"] == 2 and row["bytes"] == 4]
    endpoints.sort()
    complete = len(endpoints) == 32 and len(set(endpoints)) == 32
    if not complete:
        return dict(valid=False, endpoint_count=len(endpoints), phases=[],
                    error="Expected32 distinct final4byte token D2H endpoints; no phase claims made.")
    rows = [dict(phase="prefill" if index == 0 else "decode" + str(index),
        token_D2H_end_ns=end, physical_kernel_count=0, graph_node_kernel_count=0,
        graph_launch_count=0, profiled_kernel_duration_sum_ns=0,
        categories={key: 0 for key in CATEGORIES}) for index, end in enumerate(endpoints)]
    unassigned, crossings = [], 0
    for kernel in data["kernels"]:
        index = bisect.bisect_left(endpoints, kernel["start"])
        if index >= len(rows):
            unassigned.append(kernel["name"])
            continue
        row = rows[index]
        row["physical_kernel_count"] += 1
        row["graph_node_kernel_count"] += bool(kernel["graphNodeId"])
        row["profiled_kernel_duration_sum_ns"] += kernel["end"] - kernel["start"]
        category = kernel["classification"]["category"]
        row["categories"][category] = row["categories"].get(category, 0) + 1
        crossings += kernel["end"] > endpoints[index]
    for call in data["launches"]:
        index = bisect.bisect_left(endpoints, call["start"])
        if index < len(rows):
            rows[index]["graph_launch_count"] += 1
    captures = data["target"]["capture_counts"]
    for index, row in enumerate(rows):
        row["stable_silu_mul_true_count"] = sum(row["categories"][f"stable_silu_mul_{kind}_true"]
                                               for kind in ("bf16", "f32", "f16", "unknown"))
        row["host_capture"] = captures[index] if len(captures) == len(rows) else None
    warm = rows[7:]
    keys = ("physical_kernel_count", "graph_node_kernel_count", "graph_launch_count", "stable_silu_mul_true_count")
    return dict(valid=not unassigned and not crossings, endpoint_count=32,
        method="previous token D2H end < kernel.start <= current token D2H end; warm indices7..31 inclusive",
        phases=rows, unassigned_kernel_count=len(unassigned),
        kernel_crosses_token_endpoint_count=crossings,
        warm_decode7_31={**{key: distribution(row[key] for row in warm) for key in keys},
                        "categories": {key: distribution(row["categories"].get(key, 0) for row in warm)
                                       for key in sorted(set().union(*(row["categories"] for row in warm)))}})


def template_inventory(data):
    grouped = {}
    for row in data["kernels"]:
        item = grouped.setdefault(row["name"], dict(names=row["names"],
            classification=row["classification"], invocations=0, graph_node_invocations=0,
            launch_configurations=collections.Counter()))
        item["invocations"] += 1
        item["graph_node_invocations"] += bool(row["graphNodeId"])
        item["launch_configurations"][tuple(row[key] for key in
            ("gridX", "gridY", "gridZ", "blockX", "blockY", "blockZ"))] += 1
    result = []
    for name, row in sorted(grouped.items()):
        row["name"] = name
        row["launch_configurations"] = [dict(grid=list(key[:3]), block=list(key[3:]), invocations=value)
                                           for key, value in sorted(row["launch_configurations"].items())]
        result.append(row)
    return result


def compare(candidate, baseline, cp, bp):
    rows = []
    if len(cp["phases"]) == len(bp["phases"]) == 32:
        for current, old in zip(cp["phases"], bp["phases"]):
            keys = set(current["categories"]) | set(old["categories"])
            rows.append(dict(phase=current["phase"],
                physical_kernel_delta=current["physical_kernel_count"] - old["physical_kernel_count"],
                graph_node_kernel_delta=current["graph_node_kernel_count"] - old["graph_node_kernel_count"],
                graph_launch_delta=current["graph_launch_count"] - old["graph_launch_count"],
                category_deltas={key: current["categories"].get(key, 0) - old["categories"].get(key, 0)
                                 for key in sorted(keys) if current["categories"].get(key, 0) != old["categories"].get(key, 0)}))
    def counts(data, phase_data):
        if len(phase_data["phases"]) != 32:
            return collections.Counter()
        low = phase_data["phases"][6]["token_D2H_end_ns"]
        high = phase_data["phases"][-1]["token_D2H_end_ns"]
        return collections.Counter(row["name"] for row in data["kernels"] if low < row["start"] <= high)
    cc, bc = counts(candidate, cp), counts(baseline, bp)
    deltas = [dict(name=name, classification=classify(name), baseline=bc[name], candidate=cc[name],
                   delta=cc[name] - bc[name]) for name in sorted(cc.keys() | bc.keys()) if cc[name] != bc[name]]
    return dict(phases=rows, warm_phase_delta={key: distribution(row[key] for row in rows[7:])
                for key in ("physical_kernel_delta", "graph_node_kernel_delta", "graph_launch_delta")},
                warm_kernel_symbol_deltas=deltas,
                other_kernel_changes=[row for row in deltas if row["classification"]["family"] == "other"],
                comparability="Retained baseline shares model/fixed-input recipe; it is a physical count reference, not a matched profiled timing experiment.")


def main():
    sqlite_path, csv_path = PROFILE / (STEM + ".sqlite"), PROFILE / (STEM + "_cuda_gpu_kern_sum.csv")
    for path in (sqlite_path, csv_path, BASELINE / "qwen-trace.sqlite", BASELINE / "qwen-trace_cuda_gpu_kern_sum.csv"):
        if not path.is_file():
            raise FileNotFoundError("Official export is not ready: " + str(path))
    candidate = load(sqlite_path, csv_path, candidate=True)
    baseline = load(BASELINE / "qwen-trace.sqlite", BASELINE / "qwen-trace_cuda_gpu_kern_sum.csv")
    cp, bp = phases(candidate), phases(baseline)
    result_path = STAGE / "profile-qwen-stable-silu.result.json"
    inputs_path = STAGE / "profile-qwen-stable-silu-inputs.json"
    run_result, inputs = read(result_path), read(inputs_path)
    current = candidate["target"]["output"]
    old = baseline["target"]["output"]
    metrics_path = STAGE / "correctness-candidate-preferred-metrics.json"
    metrics = read(metrics_path) if metrics_path.is_file() else {}
    checks = dict(candidate_phase_binning_valid=cp["valid"], baseline_phase_binning_valid=bp["valid"],
        candidate_csv_sqlite_equal=candidate["receipt"]["csv_sqlite_per_symbol_counts_equal"],
        baseline_csv_sqlite_equal=baseline["receipt"]["csv_sqlite_per_symbol_counts_equal"],
        profiler_terminal_zero=run_result.get("terminal") is True and run_result.get("exit") == 0,
        bound_to_final_candidate=inputs.get("image", {}).get("sha256") == FINAL_IMAGE_SHA256,
        target_pid_found=bool(candidate["receipt"]["target_pids"]),
        graph_api_returns_zero=not candidate["receipt"]["graph_api_failures"],
        target_has_32_ids=bool(current and len(current.get("generated_ids", [])) == 32),
        target_has_31_fixed_decode_inputs=bool(current and len(current.get("decode_input_ids", [])) == 31),
        generated_ids_match_retained_baseline=bool(current and old and current["generated_ids"] == old["generated_ids"]),
        fixed_decode_inputs_match_retained_baseline=bool(current and old and current["decode_input_ids"] == old["decode_input_ids"]),
        generated_ids_match_unprofiled_current=bool(current and metrics and current["generated_ids"] == metrics.get("ids")))
    perf_path = STAGE / "performance-summary.json"
    performance = dict(available=perf_path.is_file(), profiler_timings_used=False)
    if perf_path.is_file():
        performance.update(receipt=identity(perf_path), unprofiled_summary=read(perf_path))
    templates_path = PROFILE / "stable-silu-kernel-templates.json"
    save(templates_path, dict(candidate=template_inventory(candidate), baseline=template_inventory(baseline)))
    report = dict(schema="hyle.stable_silu.profile_analysis.v1",
        status="official_exports_analysed" if all(checks.values()) else "evidence_incomplete_or_structural_check_failed",
        checks=checks, failed_checks=[key for key, passed in checks.items() if not passed],
        candidate=dict(receipt=candidate["receipt"], phases=cp, target=candidate["target"],
            profiler_process=dict(pid=run_result.get("pid"), exit=run_result.get("exit"), terminal=run_result.get("terminal")),
            launch_receipt=identity(result_path), inputs_receipt=identity(inputs_path), bound_image=inputs.get("image")),
        baseline=dict(receipt=baseline["receipt"], phases=bp, target=baseline["target"]),
        comparison=compare(candidate, baseline, cp, bp), templates=identity(templates_path),
        performance=performance,
        expected_pair_shape_is_not_asserted=dict(BF16_FFN=24, F32_SSM_z_gate=18,
            remaining_BF16_conv_silu="18 may stay SGLang or become native standalone; actual counts above decide.",
            note="Neither42 fused kernels nor1752 total kernels is a pass condition; no expected count is substituted for an observation."),
        interpretation=[
            "Only physical CUPTI kernel activities establish dispatch counts. Logical region count and graph capture alone do not prove fusion.",
            "Marked fusion identity requires stable helper, dtype and round_unary=true in the full template; other/unknown gated identities remain separately reported.",
            "Graph IDs are process-local. GraphLaunch count and graph-node attribution are reported separately from physical kernel count.",
            "No numerical-equivalence conclusion is inferred from a symbol or count; independent exact-output tests supply that evidence.",
            "Profiled timestamps, summed kernel durations and old baseline timings are not used for speed claims. Only the separately retained unprofiled pair summary is quoted.",
            "Diagnostic warnings are preserved; missing data, endpoint ambiguities and unrelated kernel changes prevent a unique-cause claim."],
        additional_compilation=False, additional_GPU_execution=False, additional_profiling=False)
    output = STAGE / "profile-analysis-stable-summary.json"
    save(output, report)
    print(json.dumps(dict(summary=identity(output), status=report["status"], checks=checks,
        candidate_warm=cp.get("warm_decode7_31"), warm_delta=report["comparison"]["warm_phase_delta"]), indent=2))
    if not all(checks.values()):
        raise SystemExit(1)


if __name__ == "__main__":
    main()
