"""Build exact Cast/stable-SiLU pair with strict unary math; retain SDKs and other owners."""
from pathlib import Path
import argparse
import datetime as dt
import importlib.util
import sys
sys.dont_write_bytecode=True
STAGE=Path(__file__).resolve().parent
ARCH=STAGE.parent
ROOT=ARCH.parents[1]
BASE=ARCH/'binding-port-reuse/checks/20261019T174851'
RECIPES=ARCH/'conv-typed-load/checks/20261019T171411'
UNARY=ARCH/'cuda-fusion-precision/checks/20261019T111328/unary-identity.json'
NATIVE_BASE=RECIPES
HEADERS=ARCH/'cuda-fusion-precision/native-source'

def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path)
    module=importlib.util.module_from_spec(spec); spec.loader.exec_module(module)
    return module

old=load('conv_native_build_helpers',ARCH/'gdn-typed-load/build.py')
b,c,h=old.b,old.c,old.h

def check(plan):
    for row in plan['frozen']:
        if not b.same(row): raise ValueError('Source/recipe changed: '+row['path'])

def prepare(out):
    native=STAGE/'native-source'
    required=[Path(__file__),STAGE/'host-source-freeze.json',STAGE/'native-source-freeze.json',STAGE/'tests-source-freeze.json',
        STAGE/'native-header-closure.json',STAGE/'provider-version.h',
        ROOT/'third_party/ggml_cuda_runtime/patches.json',ROOT/'third_party/ggml_cuda_runtime/NOTICE.md',
        ROOT/'cmake/HyleDependencyLock.json',ROOT/'tests/graph_provider_ggml_cuda/CMakeLists.txt']
    frozen=[b.identity(p) for p in required]
    for seal,source in [('host-source-freeze.json',ROOT),('native-source-freeze.json',native),('tests-source-freeze.json',ROOT)]:
        for row in c.read(STAGE/seal)['files']:
            actual=b.identity(source/row.get('path',row.get('source'))); expected=row.get('after',row)
            if any(actual[k]!=expected[k] for k in ('bytes','sha256')): raise ValueError('Reviewed source changed: '+row['path'])
            frozen.append(actual)
    templates=[
        ('native-main','native',NATIVE_BASE/'native-main-identity.json',native/'src/ggml-cuda/ggml-cuda.cu',True),
        ('native-unary','native',UNARY,native/'src/ggml-cuda/unary.cu',True),
        ('provider','host',NATIVE_BASE/'provider-identity.json',ROOT/'src/compute_provider_ggml_cuda/ggml_cuda_provider.cc',True),
        ('adapter','host',RECIPES/'adapter-identity.json',ROOT/'src/graph_provider_ggml_cuda/ggml_cuda_region.cc',True),
        ('cast-test','host',RECIPES/'conv-test-identity.json',ROOT/'tests/graph_provider_ggml_cuda/cast_stable_silu_test.cc',False)]
    rows=[]
    for tag,kind,recipe_path,source,replaces in templates:
        recipe=c.read(recipe_path); template=recipe['command']
        if kind=='native':
            command=h.a.strip_ccbin(b.native_command(h.a.strip_ccbin(template),source,tag,out))
            command=[x for x in command if not (x.startswith('-I') and ('architecture-refactor-2026-10-18' in x or 'reference-windows' in x))]
            command[1:1]=['-I'+str(native/'src/ggml-cuda'),'-I'+str(native/'src'),
                '-I'+str(HEADERS/'include'),'-I'+str(HEADERS/'src'),'-I'+str(HEADERS/'src/ggml-cuda')]
            if tag=='native-unary':
                assert not any('use_fast_math' in x.lower() or x.lower() in ('-ftz=true','--ftz=true') for x in command)
        else:
            template=['/FI'+str(STAGE/'provider-version.h') if x.lower().startswith('/fi') else x for x in template]
            command=b.host_command(template,source,tag,out)
            command[1:1]=['/external:I'+str(native/'src/ggml-cuda')]
            frozen += [b.identity(p) for p in b.host_dependencies(template)]
        row=dict(tag=tag,kind=kind,source=b.identity(source),recipe=b.identity(recipe_path),command=command,
            object=str(out/(tag+'.obj')),old_object=recipe['object'] if replaces else None)
        rows.append(row); frozen += [row['source'],row['recipe']]
        snapshot=out/'compiled-source'/source.relative_to(ROOT)
        snapshot.parent.mkdir(parents=True,exist_ok=True); snapshot.write_bytes(source.read_bytes())
        frozen.append(b.identity(snapshot))
    for path in sorted(native.rglob('*')):
        if path.is_file(): frozen.append(b.identity(path))
    # The unchanged fallback roots are authenticated too; the new header closure
    # identifies which actual root supplies each changed private header.
    for row in c.read(ARCH/'cuda-fusion-precision/header-closure.json')['headers']:
        actual=b.identity(HEADERS/row['path'])
        assert actual['sha256']==row['sha256']; frozen.append(actual)
    qwen=c.read(BASE/'qwen-link-plan.json')
    old_test=c.read(RECIPES/'conv-link-plan.json')
    gtests=[r for r in old_test['inputs'] if Path(r['path']).name.lower() in ('gtest.lib','gtest_main.lib')]
    assert len(gtests)==2
    cached={c.key(r['path']):r for r in [*qwen['inputs'],*gtests]}
    replacements={c.key(r['old_object']['path']):r['object'] for r in rows if r['old_object']}
    assert len(replacements)==4 and set(replacements)<=set(cached)
    for row in rows:
        if row['old_object']: assert cached[c.key(row['old_object']['path'])]==row['old_object']
    main=next(r['path'] for r in qwen['inputs'] if Path(r['path']).name=='29-qwen35_text-main.obj')
    links={}
    for arm in ('qwen','cast'):
        command=[replacements.get(c.key(x),x) for x in qwen['command']
            if not x.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:'))]
        if arm=='cast':
            command=[x for x in command if c.key(x)!=c.key(main)]
            command[1:1]=[next(r['object'] for r in rows if r['tag']=='cast-test'),*(r['path'] for r in gtests)]
        image=out/(arm+'.exe')
        command += ['/OUT:'+str(image),'/MAP:'+str(image.with_suffix('.map')),'/IMPLIB:'+str(image.with_suffix('.lib'))]
        inputs=[x for x in command if Path(x).is_absolute() and x.lower().endswith(('.obj','.lib'))
            and not x.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:'))]
        assert len(inputs)==(129 if arm=='qwen' else 131) and len(set(map(c.key,inputs)))==len(inputs)
        links[arm]=dict(command=command,inputs=inputs,image=str(image))
    frozen += [b.identity(BASE/'qwen-link-plan.json'),b.identity(RECIPES/'conv-link-plan.json')]
    return dict(compile=rows,links=links,cached_inputs=list(cached.values()),
        frozen=list({c.key(r['path']):r for r in frozen}.values()),host_TUs=3,native_TUs=2,
        SDK_build=False,private_shared_ABI_changed=False,baseline_image=c.read(BASE/'qwen-image.json'),
        scope='Original F32->BF16 RNE then ordinary stable BF16 SiLU; strict unary TU. No tensor-program changes, SDK compilation or global math changes.')

def main():
    p=argparse.ArgumentParser(description=__doc__); p.add_argument('--build',action='store_true'); p.add_argument('--resume',type=Path)
    args=p.parse_args()
    if args.resume: path=args.resume.resolve(); out=path.parent; plan=c.read(path)
    else:
        out=STAGE/'checks'/dt.datetime.now(dt.timezone.utc).strftime('%Y%m%dT%H%M%S')
        out.mkdir(parents=True,exist_ok=False); (out/'tmp').mkdir(); plan=prepare(out); path=out/'plan.json'; c.save(path,plan)
    print('PLAN',path,flush=True)
    if not args.build: return
    check(plan)
    for row in plan['cached_inputs']:
        if not b.same(row): raise ValueError('Cached link input changed: '+row['path'])
    env,_=b.environment(plan['links']['qwen']['command'],[r['path'] for r in plan['cached_inputs']],out)
    identities={c.key(r['path']):r for r in plan['cached_inputs']}
    for row in plan['compile']:
        receipt=out/(row['tag']+'-identity.json')
        if receipt.exists():
            prior=c.read(receipt)
            if prior['command']==row['command'] and b.same(prior['object']) and all(b.same(r) for r in prior['dependencies']):
                identities[c.key(prior['object']['path'])]=prior['object']; print('REUSE',row['tag'],flush=True); continue
        attempt=1+len(list(out.glob(row['tag']+'-compile-*.result.json')))
        c.execute(row['tag']+'-compile-'+str(attempt),row['command'],env,out); check(plan)
        if row['kind']=='host':
            data=c.read(out/(row['tag']+'-deps.json'))['Data']; deps=[b.identity(p) for p in [data['Source'],*data['Includes']]]
        else: deps=[r for r in plan['frozen'] if r['path'].lower().endswith(('.cu','.cuh','.h'))]
        record=dict(command=row['command'],source=row['source'],object=b.identity(row['object']),dependencies=deps)
        c.save(receipt,record); identities[c.key(record['object']['path'])]=record['object']; print('COMPILED',row['tag'],flush=True)
    for arm,link in plan['links'].items():
        receipt=out/(arm+'-image.json')
        if receipt.exists() and b.same(c.read(receipt)): continue
        attempt=1+len(list(out.glob(arm+'-link-*.result.json')))
        c.execute(arm+'-link-'+str(attempt),link['command'],env,out); check(plan)
        c.save(out/(arm+'-link-plan.json'),dict(command=link['command'],inputs=[identities[c.key(p)] for p in link['inputs']]))
        c.save(receipt,b.identity(link['image']))
    c.save(out/'summary.json',dict(passed=True,host_TUs=3,native_TUs=2,SDK_build=False,GPU_run=False))
    c.save(STAGE/'latest-check.json',dict(plan=str(path))); print('BUILD_COMPLETE',path,flush=True)

if __name__=='__main__': main()
