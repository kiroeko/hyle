"""Increment only dense-score source owners; reuse the current CUDA/SDK closure."""
from pathlib import Path
import argparse
import datetime as dt
import importlib.util
import sys
sys.dont_write_bytecode = True
STAGE = Path(__file__).resolve().parent
ARCH = STAGE.parent
ROOT = ARCH.parents[1]
BASE = ARCH / 'cast-stable-silu/checks/20261019T180121'

spec = importlib.util.spec_from_file_location('dense_score_helpers', ARCH / 'cast-stable-silu/build.py')
h = importlib.util.module_from_spec(spec)
spec.loader.exec_module(h)
b, c = h.b, h.c

def check(plan):
    for row in plan['frozen']:
        if not b.same(row):
            raise ValueError('Source/recipe changed: ' + row['path'])

def prepare(out, region, test):
    recipes_path = STAGE / 'cached-recipes.json'
    recipes = c.read(recipes_path)
    frozen = [b.identity(Path(__file__)), b.identity(recipes_path),
              b.identity(BASE / 'qwen-link-plan.json')]
    for name in ('provider-source-freeze.json', 'graph-source-freeze.json', 'tests-source-freeze.json'):
        seal = STAGE / name
        frozen.append(b.identity(seal))
        for row in c.read(seal)['files']:
            actual = b.identity(ROOT / row.get('path', row.get('source')))
            assert all(actual[k] == row['after'][k] for k in ('bytes', 'sha256'))
            frozen.append(actual)
    sources = [
        ('native-provider', 'host', ROOT / 'src/compute_provider_cuda/cuda_provider.cc'),
        ('indexer-provider', 'host', ROOT / 'src/compute_provider_cuda/row_cache_indexer_provider.cc'),
        ('compute-context', 'host', ROOT / 'src/compute_route_cuda/cuda_context.cc'),
        ('graph-context', 'host', ROOT / 'src/graph_route_cuda/cuda_context.cc'),
        ('region', 'host', region),
        ('indexer-kernel', 'native', ROOT / 'src/compute_provider_cuda/row_cache_indexer_kernel.cu'),
        ('graph-test', 'host', test)]
    for parent in ['src/compute_provider_cuda', 'src/graph_route_cuda', 'src/compute_route_cuda']:
        frozen += [b.identity(p) for p in sorted((ROOT / parent).glob('*'))
                   if p.is_file() and p.suffix in ('.h', '.cuh')]
        frozen.append(b.identity(ROOT / parent / 'CMakeLists.txt'))
    frozen += [b.identity(ROOT / 'src/compute_backend_cuda/device_status_kernel.h'),
               b.identity(ROOT / 'cmake/HyleComponents.cmake'),
               b.identity(ROOT / 'tests/graph_route_cuda/CMakeLists.txt')]
    rows = []
    for tag, kind, source in sources:
        recipe = recipes[tag]
        command = recipe['command']
        if kind == 'host':
            frozen += [b.identity(p) for p in b.host_dependencies(command)]
            command = b.host_command(command, source, tag, out)
            command[1:1] = ['/I' + str(ROOT / 'src/compute_route_cuda'),
                            '/I' + str(ROOT / 'src/compute_provider_cuda')]
        else:
            command = h.h.a.strip_ccbin(command)
            result, skip = [], False
            for arg in command:
                if skip:
                    skip = False
                elif arg in ('-c', '-o'):
                    skip = True
                else:
                    result.append(arg)
            command = result + ['-ccbin', str(Path(recipes['native-provider']['command'][0]).parent),
                '-MT', str(out / (tag + '.obj')), '-MF', str(out / (tag + '.d')),
                '-c', str(source), '-o', str(out / (tag + '.obj'))]
            assert '--gpu-architecture=sm_89' in command and '--std=c++20' in command
            assert not any('use_fast_math' in x for x in command)
        row = dict(tag=tag, kind=kind, command=command, source=b.identity(source),
                   object=str(out / (tag + '.obj')), old_object=recipe['object'])
        rows.append(row)
        frozen += [row['source'], recipe['receipt']]
        snapshot = out / 'compiled-source' / source.relative_to(ROOT)
        snapshot.parent.mkdir(parents=True, exist_ok=True)
        snapshot.write_bytes(source.read_bytes())
        frozen.append(b.identity(snapshot))
    qwen = c.read(BASE / 'qwen-link-plan.json')
    cached = {c.key(r['path']): r for r in qwen['inputs']}
    old_tests = c.read(ARCH / 'cast-stable-silu/checks/20261019T180346-fixture-correction/cast-link-plan.json')
    gtests = [r for r in old_tests['inputs'] if Path(r['path']).name.lower() in ('gtest.lib', 'gtest_main.lib')]
    assert len(gtests) == 2
    regressions = [ROOT / '.scratch/inference-foundation-review-2026-10-18/cuda-paged-indexer/tests.obj',
                   ROOT / '.scratch/inference-foundation-review-2026-10-18/cuda-row-cache-indexer/indexer-tests.obj']
    extras = [*gtests, *map(b.identity, regressions)]
    cached.update({c.key(r['path']): r for r in extras})
    replacements = {c.key(r['old_object']['path']): r['object'] for r in rows if r['old_object']}
    assert len(replacements) == 5
    for row in rows:
        if row['old_object']:
            assert cached[c.key(row['old_object']['path'])] == row['old_object']
    main = next(r['path'] for r in qwen['inputs'] if Path(r['path']).name == '29-qwen35_text-main.obj')
    links = {}
    for arm in ('qwen', 'dense'):
        command = [replacements.get(c.key(x), x) for x in qwen['command']
                   if not x.upper().startswith(('/OUT:', '/MAP:', '/IMPLIB:', '/PDB:'))]
        command[1:1] = [next(r['object'] for r in rows if r['tag'] == 'region')]
        if arm == 'dense':
            command = [x for x in command if c.key(x) != c.key(main)]
            command[1:1] = [next(r['object'] for r in rows if r['tag'] == 'graph-test'),
                            *(r['path'] for r in extras)]
        image = out / (arm + '.exe')
        command += ['/OUT:' + str(image), '/MAP:' + str(image.with_suffix('.map')),
                    '/IMPLIB:' + str(image.with_suffix('.lib'))]
        inputs = [x for x in command if Path(x).is_absolute() and x.lower().endswith(('.obj', '.lib'))
                  and not x.upper().startswith(('/OUT:', '/MAP:', '/IMPLIB:', '/PDB:'))]
        assert len(inputs) == (130 if arm == 'qwen' else 134)
        assert len(set(map(c.key, inputs))) == len(inputs)
        links[arm] = dict(command=command, inputs=inputs, image=str(image))
    return dict(compile=rows, links=links, cached_inputs=list(cached.values()),
                frozen=list({c.key(r['path']): r for r in frozen}.values()),
                host_TUs=6, native_TUs=1, SDK_build=False,
                public_ABI_changed=False, common_executor_changed=False)

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--build', action='store_true')
    parser.add_argument('--resume', type=Path)
    parser.add_argument('--region', type=Path)
    parser.add_argument('--test', type=Path, default=ROOT / 'tests/graph_route_cuda/ga_dense_indexer_test.cc')
    args = parser.parse_args()
    if args.resume:
        path = args.resume.resolve()
        plan = c.read(path)
        out = path.parent
    else:
        if not args.region:
            parser.error('--region is required for a new source plan')
        out = STAGE / 'checks' / dt.datetime.now(dt.timezone.utc).strftime('%Y%m%dT%H%M%S')
        out.mkdir(parents=True, exist_ok=False)
        (out / 'tmp').mkdir()
        plan = prepare(out, args.region.resolve(), args.test.resolve())
        path = out / 'plan.json'
        c.save(path, plan)
    print('PLAN', path, flush=True)
    if not args.build:
        return
    check(plan)
    for row in plan['cached_inputs']:
        if not b.same(row):
            raise ValueError('Cached object/library differs: ' + row['path'])
    env, _ = b.environment(plan['links']['qwen']['command'],
                           [r['path'] for r in plan['cached_inputs']], out)
    identities = {c.key(r['path']): r for r in plan['cached_inputs']}
    for row in plan['compile']:
        receipt = out / (row['tag'] + '-identity.json')
        if receipt.exists():
            prior = c.read(receipt)
            if prior['command'] == row['command'] and b.same(prior['object']) and all(b.same(r) for r in prior['dependencies']):
                identities[c.key(prior['object']['path'])] = prior['object']
                print('REUSE', row['tag'], flush=True)
                continue
        attempt = 1 + len(list(out.glob(row['tag'] + '-compile-*.result.json')))
        c.execute(row['tag'] + '-compile-' + str(attempt), row['command'], env, out)
        check(plan)
        if row['kind'] == 'host':
            data = c.read(out / (row['tag'] + '-deps.json'))['Data']
            deps = [b.identity(p) for p in [data['Source'], *data['Includes']]]
        else:
            deps = [r for r in plan['frozen'] if r['path'].lower().endswith(('.cu', '.cuh', '.h'))]
        record = dict(command=row['command'], source=row['source'],
                      object=b.identity(row['object']), dependencies=deps)
        c.save(receipt, record)
        identities[c.key(record['object']['path'])] = record['object']
        print('COMPILED', row['tag'], flush=True)
    for arm, link in plan['links'].items():
        receipt = out / (arm + '-image.json')
        if receipt.exists() and b.same(c.read(receipt)):
            continue
        attempt = 1 + len(list(out.glob(arm + '-link-*.result.json')))
        c.execute(arm + '-link-' + str(attempt), link['command'], env, out)
        check(plan)
        c.save(out / (arm + '-link-plan.json'), dict(command=link['command'],
            inputs=[identities[c.key(p)] for p in link['inputs']]))
        c.save(receipt, b.identity(link['image']))
    c.save(out / 'summary.json', dict(passed=True, host_TUs=6, native_TUs=1,
        SDK_build=False, GPU_run=False))
    c.save(STAGE / 'latest-check.json', dict(plan=str(path)))
    print('BUILD_COMPLETE', path, flush=True)

if __name__ == '__main__':
    main()
