"""Archive completed CCCL evidence. No build, model run, cleanup or SDK copy."""
from pathlib import Path
import argparse
import hashlib
import json
import re
import xml.etree.ElementTree as ET
import zipfile
import zlib

STAGE = Path(__file__).resolve().parent
ARCH = STAGE.parent
ROOT = ARCH.parents[1]
DEST = ROOT / 'docs/evidence/performance/cccl-single-row-topk-cuda-2026-10-20.zip'
PREFIX = 'cccl-single-row-topk/'
OMIT = {'.exe', '.obj', '.lib', '.exp', '.map', '.pdb', '.dll', '.ilk', '.res',
        '.pyc', '.tmp', '.zip', '.nsys-rep', '.ptx', '.cubin', '.fatbin',
        '.bf16', '.f16', '.f32', '.raw', '.bin', '.pt', '.safetensors', '.gguf'}
SOURCE = {'.h', '.hpp', '.cuh', '.cc', '.cpp', '.c', '.cu', '.cmake'}


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def identity(path):
    path = Path(path).resolve()
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())


def same(path, row):
    actual = identity(path)
    return all(actual[k] == row[k] for k in ('bytes', 'sha256'))


def eligible(path):
    parts = {part.casefold() for part in path.relative_to(STAGE).parts}
    return (path.suffix.casefold() not in OMIT and
            not parts.intersection({'sdk', 'cache', '__pycache__', 'tmp', 'vectors', 'models'}) and
            not re.search(r'\.(?:cudafe|fatbin|module_id|cu\.cpp)', path.name, re.I) and
            path.name not in {'archive-receipt.json', 'payload-sha256.json'})


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--profile-summary', type=Path, default=STAGE/'profile/summary.json')
    parser.add_argument('--rotation-summary', type=Path, default=STAGE/'performance-rotation/summary.json')
    args = parser.parse_args()
    if DEST.exists():
        raise ValueError('Archive already exists; refusing replacement')
    plan_path = Path(read(STAGE/'host-check.json')['plan']).resolve()
    plan = read(plan_path)
    final_summary = read(STAGE/'summary.json')  # Root writes this after final results/docs.
    assert isinstance(final_summary, dict) and final_summary
    assert plan_path.is_relative_to(STAGE/'checks')
    assert read(plan_path.parent/'summary.json')['passed']
    tests = read(STAGE/'tests/summary.json')
    cases = ET.parse(STAGE/'tests/results.xml').findall('.//testcase')
    names = [c.attrib['classname']+'.'+c.attrib['name'] for c in cases]
    assert tests['passed'] and tests['cases'] == len(cases) == len(set(names)) == 6
    assert tests['skipped'] == 0 and set(names) == set(tests['names'])
    assert all(c.find(t) is None for c in cases for t in ('failure', 'error', 'skipped'))
    assert read(STAGE/'tests/topk.result.json')['exit'] == 0
    model = read(STAGE/'correctness/summary.json')
    observation = model['observation']
    assert model['passed'] and observation['equal_vectors'] == len(observation['vectors']) == 64
    assert observation['all_outputs_finite'] and observation['same_greedy_ids_as_reference']
    assert observation['same_fixed_decode_inputs'] and len(observation['generated_ids']) == 32
    assert len(observation['decode_input_ids']) == 31
    assert observation['process']['exit'] == 0 and observation['process']['terminal']
    assert all(r['byte_equal'] and all(r['actual'][k] == r['reference'][k]
               for k in ('bytes', 'sha256')) for r in observation['vectors'])
    assert read(STAGE/'correctness/inputs.json')['plan'] == identity(plan_path)
    assert tests['image'] == read(plan_path.parent/'topk-image.json')
    assert observation['image'] == read(plan_path.parent/'qwen-image.json')
    micro = read(STAGE/'microbenchmark/summary.json')
    assert micro['passed'] and len(micro['runs']) == 6
    assert sorted(r['arm'] for r in micro['runs']) == ['after-bench']*3+['before-bench']*3
    for row in micro['runs']:
        assert row['correct_bits_and_index'] and row['replay'] == 'commands' and not row['captured']
        assert len(row['host_wall_us']) == len(row['stream_event_us']) == row['measured_submissions'] == 128
        result = read(STAGE/'microbenchmark'/(row['tag']+'.result.json'))
        assert result['exit'] == 0 and result['terminal']
    profile, rotation = read(args.profile_summary), read(args.rotation_summary)
    assert args.profile_summary.resolve().is_relative_to(STAGE)
    assert args.rotation_summary.resolve().is_relative_to(STAGE)
    assert profile['passed'] and (STAGE/'profile/capture.sqlite').is_file()
    assert rotation['terminal_zero'] == len(rotation['order']) == 9
    assert sorted(rotation['order']) == ['baseline']*3+['current']*3+['llama']*3
    results = list(args.rotation_summary.parent.glob('*.result.json'))
    assert len(results) == 9
    assert all(read(p)['exit'] == 0 and read(p)['terminal'] for p in results)
    for name in ('profile', 'export'):
        result = read(STAGE/'profile'/(name+'.result.json'))
        assert result['exit'] == 0 and result['terminal']

    payloads = {}
    def add(path, name):
        path = Path(path).resolve()
        assert path.is_file() and path.is_relative_to(ROOT) and not path.is_symlink(), path
        assert name not in payloads or payloads[name] == path, name
        payloads[name] = path
    stage_files = [p for p in STAGE.rglob('*') if p.is_file() and eligible(p)]
    snapshots = {}
    for path in stage_files:
        if path.suffix.casefold() in SOURCE or path.name == 'CMakeLists.txt':
            snapshots.setdefault(path.name, []).append(path)
    def retained(row):
        path = Path(row['path']).resolve()
        if path.is_file() and same(path, row):
            return path
        for candidate in snapshots.get(path.name, []):
            if same(candidate, row):
                return candidate
        raise ValueError('Missing exact compiled source: '+str(path))
    before = read(STAGE/'before.json')
    assert same(before['snapshot'], before)
    add(before['snapshot'], PREFIX+'before-source/src/compute_provider_cuda/collectives.cu')
    owners = []
    for path in sorted(STAGE.rglob('*-identity.json')):
        record = read(path)
        if not isinstance(record, dict) or not all(k in record for k in ('source', 'object', 'command')):
            continue
        owners.append(dict(receipt=identity(path), source=record['source'], object=record['object']))
        for row in [record['source'], *record.get('dependencies', [])]:
            source = Path(row['path']).resolve()
            if not source.is_relative_to(ROOT):
                continue
            relative = source.relative_to(ROOT)
            if relative.parts[0] not in ('include', 'src', 'tests', 'third_party', 'cmake'):
                continue
            if source.suffix.casefold() not in SOURCE and source.name != 'CMakeLists.txt':
                continue
            add(retained(row), PREFIX+'compiled-source/'+row['sha256']+'/'+relative.as_posix())
    assert len(owners) == 4, 'Expected one native and three host owner receipts'
    native_plan = read(Path(read(STAGE/'native-check.json')['plan']))
    for row in [*plan['frozen'], *native_plan['frozen']]:
        assert same(row['path'], row), row['path']
        path = Path(row['path']).resolve()
        if not path.is_relative_to(STAGE) and path.suffix.casefold() not in OMIT:
            add(path, PREFIX+'support/'+path.relative_to(ROOT).as_posix())
    tests_freeze = read(STAGE/'tests-source-freeze.json')
    for row in tests_freeze['product_changes']:
        for version in ('before', 'after', 'retained_source'):
            add(retained(row[version]), PREFIX+version+'/'+row['source'])
    for path in stage_files:
        add(path, PREFIX+path.relative_to(STAGE).as_posix())
    review_stage = ARCH/'projection-hotspot-review'
    for name in ('review.json', 'readonly-report.json', 'prior-experiments.json',
                 'cublas-interface-review.json', 'analyze_existing.py'):
        add(review_stage/name, PREFIX+'projection-readonly/'+name)
    # Retain literal helper imports, without importing or running historical builders.
    pending, seen = list(STAGE.rglob('*.py'))+[review_stage/'analyze_existing.py'], set()
    while pending:
        path = pending.pop().resolve()
        if path in seen or '__pycache__' in path.parts:
            continue
        assert path.is_file() and path.is_relative_to(ROOT), path
        seen.add(path)
        text = path.read_text(encoding='utf-8-sig')
        for variable, base in (('ARCH', ARCH), ('STAGE', path.parent), ('S', path.parent), ('ROOT', ROOT)):
            pending += [base/name for name in re.findall(variable+r"\s*/\s*['\"]([^'\"]+\.py)['\"]", text)]
        if not path.is_relative_to(STAGE) and path.parent != review_stage:
            add(path, PREFIX+'support/'+path.relative_to(ROOT).as_posix())
    add(ARCH/'cuda-stable-silu/profile-analysis-stable.py', PREFIX+'support/retained-trace-analysis.py')
    for name in ('docs/developer/current-work.md',
                 'docs/evidence/performance/qwen35-full-cuda-2026-10-19/README.md',
                 'docs/implementation/tasks/compute/qwen35-2b-local-input.json'):
        add(ROOT/name, PREFIX+'support/'+name)
    inputs = read(STAGE/'correctness/inputs.json')
    for name in ('manifest', 'prompt', 'decode'):
        row = inputs[name]
        assert same(row['path'], row)
        path = Path(row['path']).resolve()
        add(path, PREFIX+'support/'+path.relative_to(ROOT).as_posix())
    for name in ('batch-graph-capture/archive-receipt.json', 'ga-dense-indexer/archive-receipt.json'):
        path = ARCH/name
        if path.is_file():
            add(path, PREFIX+'reference-provenance/'+name)
    scope = dict(build_plan=identity(plan_path), compiled_owner_receipts=owners,
        tests=names, equal_vectors=64, micro_processes=6, unprofiled_rotation_processes=9,
        profile_summary=identity(args.profile_summary), rotation_summary=identity(args.rotation_summary),
        limits='Commands hot-row microtest is not kernel-only or model throughput; profile counts/durations are observations. Independent model quality is not established.',
        raw_vectors='Repeated64equal vector bodies omitted; per-vector actual/reference SHA and paths remain in comparison JSON. Original reference files remain outside this ZIP.',
        history='Uncompiled RequireCapture/enum premise draft and its Commands correction retained as source history; no observed capture failure is invented.',
        excluded='SDK/models/objects/images/maps/debug/temp/duplicate raw tensor payloads/nsys-rep. Official SQLite, CSV, commands, logs, XML and source closures retained.',
        archive_started_build_or_GPU=False, cleanup_executed=False)
    manifest = {name:identity(path) for name,path in sorted(payloads.items())}
    generated = {name:(json.dumps(value, ensure_ascii=False, indent=2)+'\n').encode()
                 for name,value in [('archive-scope.json',scope),('payload-sha256.json',manifest)]}
    DEST.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(DEST, 'w', zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
        for name,path in sorted(payloads.items()):
            archive.write(path, name)
        for name,data in generated.items():
            archive.writestr(name, data)
    expected = {name:r['sha256'] for name,r in manifest.items()}
    expected.update({name:hashlib.sha256(data).hexdigest() for name,data in generated.items()})
    with zipfile.ZipFile(DEST) as archive:
        assert len(archive.infolist()) == len(expected)
        for item in archive.infolist():
            digest, crc, size = hashlib.sha256(), 0, 0
            with archive.open(item) as stream:
                while chunk := stream.read(1024*1024):
                    digest.update(chunk); crc=zlib.crc32(chunk,crc); size+=len(chunk)
            assert size == item.file_size and crc & 0xffffffff == item.CRC, item.filename
            assert digest.hexdigest() == expected[item.filename], item.filename
    receipt = dict(**identity(DEST), entries=len(expected), CRC_and_every_payload_SHA_verified=True,
        crc_verified=True, payload_sha256_verified=True,
        verification_passes=1, tests=6, equal_vectors=64, micro_processes=6, rotation_processes=9,
        duplicate_raw_vectors_omitted=True, SDK_rebuilt=False, cleanup_executed=False)
    for path in (STAGE/'archive-receipt.json', DEST.with_name(DEST.stem+'-archive.json')):
        path.write_text(json.dumps(receipt,indent=2)+'\n', encoding='utf-8')
    print(json.dumps(receipt,indent=2))


if __name__ == '__main__':
    main()
