"""Compile only the changed CCCL CUDA owner with its retained SDK recipe."""
from pathlib import Path
import datetime as dt
import importlib.util
import sys
sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
ARCH = S.parent
ROOT = ARCH.parents[1]
spec = importlib.util.spec_from_file_location('linear_topk_helpers', ARCH / 'ga-dense-indexer/build.py')
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)
b, c = m.b, m.c
base = ARCH / 'ga-dense-indexer/checks/20261019T184046-metadata-boundaries'
link = c.read(base / 'qwen-link-plan.json')
original = ROOT / '.scratch/inference-foundation-review-2026-10-18/cccl-device-gather'
recipe_path = original / 'commands.json'
recipe = next(r['command'] for r in reversed(c.read(recipe_path)) if r['tag'] == 'native-compile')
before = c.read(S / 'before.json')
assert before['sha256'] == next(r['sha256'] for r in c.read(original / 'identities.json')['source']
    if r['path'].endswith('collectives.cu'))
old_object = b.identity(original / 'native.obj')
assert old_object in link['inputs']
out = S / 'checks' / dt.datetime.now(dt.timezone.utc).strftime('%Y%m%dT%H%M%S')
out.mkdir(parents=True, exist_ok=False)
(out / 'tmp').mkdir()
command, skip = [], False
for arg in recipe:
    if skip:
        skip = False
    elif arg in ('-c', '-o', '--compiler-bindir'):
        skip = True
    else:
        command.append(arg)
cl = c.read(base / 'native-provider-identity.json')['command'][0]
command += ['-ccbin', str(Path(cl).parent), '-MD', '-MT', str(out / 'native.obj'),
    '-MF', str(out / 'native.d'), '-c', str(ROOT / 'src/compute_provider_cuda/collectives.cu'),
    '-o', str(out / 'native.obj')]
frozen = [b.identity(p) for p in [Path(__file__), recipe_path, S / 'before.json',
    ROOT / 'src/compute_provider_cuda/collectives.cu', ROOT / 'src/compute_provider_cuda/collectives.h',
    ROOT / 'src/compute_backend_cuda/device_status_kernel.h']]
plan = dict(command=command, frozen=frozen, old_object=old_object,
    object=str(out / 'native.obj'), CUDA_SDK_rebuild=False)
c.save(out / 'native-plan.json', plan)
env, _ = b.environment(link['command'], [r['path'] for r in link['inputs']], out)
c.execute('native-compile', command, env, out)
for row in frozen:
    assert b.same(row), row['path']
record = dict(command=command, source=b.identity(ROOT / 'src/compute_provider_cuda/collectives.cu'),
    object=b.identity(out / 'native.obj'), dependencies=frozen[3:])
c.save(out / 'native-identity.json', record)
c.save(S / 'native-check.json', dict(plan=str(out / 'native-plan.json'), identity=str(out / 'native-identity.json')))
print('NATIVE_COMPLETE', out, flush=True)
