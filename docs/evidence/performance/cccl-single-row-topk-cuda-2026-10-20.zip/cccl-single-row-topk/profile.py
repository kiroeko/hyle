"""One production full-model trace to identify the actual CCCL implementation."""
from pathlib import Path
import collections
import importlib.util
import json
import sqlite3
import statistics
import sys
sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('topk_profile_build', S / 'build_host.py')
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)
b, c = m.b, m.c
path = Path(c.read(S / 'host-check.json')['plan'])
plan = c.read(path)
assert c.read(S / 'tests/summary.json')['passed'] and c.read(S / 'correctness/summary.json')['passed']
for row in plan['frozen']:
    assert b.same(row), row['path']
out = S / 'profile'
out.mkdir(exist_ok=False)
(out / 'tmp').mkdir()
prepared = c.read(S / 'performance-prepared/plan.json')
image = c.read(path.parent / 'qwen-image.json')
assert b.same(image) and image == prepared['images']['current']
old_command = c.read(S.parent / 'cast-stable-silu/profile/profile.command.json')['command']
target = next(r['command'] for r in prepared['requests'] if r['arm'] == 'current')
assert '--trace' not in target and target[0] == image['path']
command = old_command[:9] + target
command[8] = '--output=' + str(out / 'capture')
link = c.read(path.parent / 'qwen-link-plan.json')
env, runtime = b.environment(link['command'], [r['path'] for r in link['inputs']], out)
c.save(out / 'inputs.json', dict(image=image, command=command, build_plan=b.identity(path),
       runtime_library_directories=runtime, profiler=True, throughput_claim=False))
c.execute('profile', command, env, out)
c.execute('export', [command[0], 'export', '--type=sqlite', '--output=' + str(out / 'capture.sqlite'),
                    str(out / 'capture.nsys-rep')], env, out)
db = sqlite3.connect('file:' + (out / 'capture.sqlite').as_posix() + '?mode=ro', uri=True)
db.row_factory = sqlite3.Row
strings = dict(db.execute('SELECT id,value FROM StringIds'))
kernels = [dict(r) for r in db.execute('SELECT * FROM CUPTI_ACTIVITY_KIND_KERNEL ORDER BY start')]
for r in kernels:
    r.update(name=strings[r['demangledName']], us=(r['end'] - r['start']) / 1000)
tokens = [dict(r) for r in db.execute('SELECT * FROM CUPTI_ACTIVITY_KIND_MEMCPY ORDER BY end')
          if r['copyKind'] == 2 and r['bytes'] == 4]
assert len(tokens) == 32
phases = []
for i in range(1, 32):
    lo, hi = tokens[i - 1]['end'], tokens[i]['end']
    selected = [r for r in kernels if lo < r['start'] and r['end'] <= hi]
    assert not any(r['start'] < hi and r['end'] > lo and r not in selected for r in kernels)
    fast = [r for r in selected if 'DeviceReduceKernel' in r['name'] and 'SingleRowArgInput' in r['name']]
    old = [r for r in selected if 'DeviceReduceKernel' in r['name'] and 'ArgInput<' in r['name']
           and 'SingleRowArgInput' not in r['name']]
    phases.append(dict(index=i, kernels=len(selected), fast_reduce_count=len(fast),
                       generic_reduce_count=len(old), fast_reduce_us=sum(r['us'] for r in fast)))
tables = {r[0] for r in db.execute("SELECT name FROM sqlite_master WHERE type='table'")}
streams = {}
if 'ProcessStreams' in tables:
    for r in db.execute('SELECT * FROM ProcessStreams'):
        filename = strings[r['filenameId']]
        if '/streams/' in filename.replace('\\', '/'):
            streams['stderr' if 'stderr_' in filename else 'stdout'] = strings[r['contentId']]
else:
    for r in db.execute('SELECT * FROM ANALYSIS_FILE'):
        if '/streams/' in r['filename'].replace('\\', '/'):
            streams['stderr' if 'stderr_' in r['filename'] else 'stdout'] = strings[r['contentId']]
for kind, content in streams.items():
    (out / ('target.' + kind + '.log')).write_text(content, encoding='utf-8')
observed = json.loads(streams['stdout'].splitlines()[-1])
reference = json.loads((S / 'correctness/qwen.stdout.log').read_text().splitlines()[-1])
assert observed['generated_ids'] == reference['generated_ids']
assert observed['decode_input_ids'] == reference['decode_input_ids'] == prepared['fixed']['decode_input_ids']
diagnostics = [dict(r) for r in db.execute('SELECT * FROM DIAGNOSTIC_EVENT')] if 'DIAGNOSTIC_EVENT' in tables else []
db.close()
warm = [r for r in phases if r['index'] >= 7]
passed = all(r['kernels'] == 650 and r['fast_reduce_count'] == 1 and r['generic_reduce_count'] == 0 for r in warm)
summary = dict(passed=passed, image=image, sqlite=b.identity(out / 'capture.sqlite'),
    phase_anchors='32 actual4B device-to-host token completions', phases=phases,
    warm_fast_reduce_us_median=statistics.median(r['fast_reduce_us'] for r in warm),
    per_symbol=dict(collections.Counter(r['name'] for r in kernels)), diagnostics=diagnostics,
    fixed_inputs_and_predictions_same=True, throughput_claim=False,
    limit='One instrumented production trace: implementation/count evidence; profiling durations are not stable speed evidence.')
c.save(out / 'summary.json', summary)
assert passed
print('PHYSICAL_TOPK', dict(kernels=warm[0]['kernels'], fast_reduce_count=warm[0]['fast_reduce_count'],
      warm_fast_reduce_us_median=summary['warm_fast_reduce_us_median']), flush=True)
