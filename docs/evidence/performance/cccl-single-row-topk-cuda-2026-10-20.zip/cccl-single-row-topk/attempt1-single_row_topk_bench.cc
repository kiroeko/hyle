// Fixed public-Graph workload for paired old/new provider images.
// No raw kernel launch or private Program ABI. Stream timing is not kernel-only.
#include "hyle/compute/backends/cuda.h"
#include "hyle/compute/providers/cuda.h"
#include "hyle/graph/cuda.h"

#include <algorithm>
#include <array>
#include <bit>
#include <chrono>
#include <cstdint>
#include <iomanip>
#include <iostream>
#include <span>
#include <stdexcept>
#include <string>
#include <utility>
#include <vector>

namespace c = hyle::compute;
namespace g = hyle::graph;
namespace m = hyle::mem;

template <class T> T take(hyle::Result<T> result) {
  if (!result) throw std::runtime_error(std::string(result.error().message()));
  return std::move(*result);
}
void check(hyle::Status status) {
  if (!status.ok()) throw std::runtime_error(std::string(status.message()));
}
void cuda_check(cudaError_t error) {
  if (error != cudaSuccess) throw std::runtime_error(cudaGetErrorString(error));
}
struct Events final {
  cudaEvent_t start = nullptr, end = nullptr;
  ~Events() {
    if (end) (void)cudaEventDestroy(end);
    if (start) (void)cudaEventDestroy(start);
  }
};
struct Drain final {
  c::Queue &queue;
  ~Drain() { (void)queue.drain(); }
};
double median(std::vector<double> values) {
  std::sort(values.begin(), values.end());
  return (values[(values.size() - 1) / 2] + values[values.size() / 2]) / 2.0;
}
void print_array(const std::vector<double> &values) {
  std::cout << '[';
  for (std::size_t i = 0; i < values.size(); ++i) {
    if (i) std::cout << ',';
    std::cout << values[i];
  }
  std::cout << ']';
}

int main() try {
  constexpr std::int64_t width = 248320;
  constexpr std::size_t warmup = 16, iterations = 128;
  auto context = take(g::cuda::create_context());
  auto memory = take(c::cuda::MemoryResource::create(
      context, c::cuda::MemoryKind::kDevice));
  auto queue = take(context.create_queue());
  check(queue.reserve_completions(2));
  const auto stream = take(c::cuda::stream(queue));
  const auto input_desc = take(c::TensorDesc::dense(
      c::DataType::kFloat32, std::array<std::int64_t, 2>{1, width}));
  const auto values_desc = take(c::TensorDesc::dense(
      c::DataType::kFloat32, std::array<std::int64_t, 2>{1, 1}));
  const auto indices_desc = take(c::TensorDesc::dense(
      c::DataType::kInt32, std::array<std::int64_t, 2>{1, 1}));
  auto input = take(m::Buffer::create(memory.ref(), take(input_desc.required_bytes()), 256));
  auto values = take(m::Buffer::create(memory.ref(), take(values_desc.required_bytes()), 256));
  auto indices = take(m::Buffer::create(memory.ref(), take(indices_desc.required_bytes()), 256));
  std::vector<float> host(static_cast<std::size_t>(width));
  for (std::size_t i = 0; i < host.size(); ++i)
    host[i] = static_cast<float>(static_cast<int>((i * 37) % 1021) - 510) * 0.125f;
  // A repeated exact maximum also checks the stable lower-index rule.
  constexpr std::int32_t expected_index = 12345;
  constexpr float expected_value = 1024.5f;
  host[static_cast<std::size_t>(expected_index)] = expected_value;
  host[200000] = expected_value;
  check(input.view().write(std::as_bytes(std::span(host))));

  auto builder = take(g::GraphBuilder::create());
  const auto x = take(builder.input(input_desc));
  const auto top = take(builder.add_node(c::Operation(c::TopK{.count = 1}), std::array{x}));
  const auto v = take(builder.result(top, 0)), i = take(builder.result(top, 1));
  check(builder.publish(v)); check(builder.publish(i));
  const auto logical = take(std::move(builder).finish());
  auto compiled = take(g::cuda::compile(logical, context, memory.ref(),
      {.provider_replay = g::ProviderReplayPolicy::kAllowAny}));
  bool cccl_selected = false;
  for (std::size_t step = 0; step < compiled.report.step_count(); ++step)
    cccl_selected |= take(compiled.report.step(step)).provider.id == c::cuda_native::kCcclProviderId;
  if (!cccl_selected) throw std::runtime_error("CCCL TopK must be selected");
  auto slot = take(compiled.executable.create_invocation());
  Drain drain{queue}; // Retire any accepted prefix before payload/slot teardown.
  check(slot.bind(x, take(c::ConstTensorView::create(input_desc, input.view()))));
  check(slot.bind(v, take(c::TensorView::create(values_desc, values.view()))));
  check(slot.bind(i, take(c::TensorView::create(indices_desc, indices.view()))));
  check(g::cuda::prepare_replay(slot, queue,
      {.mode = g::ReplayMode::kRequireCapture}));
  if (slot.replay_route() != g::ReplayRoute::kCaptured)
    throw std::runtime_error("RequireCapture did not select captured replay");
  const auto verify = [&] {
    float actual_value = 0.0f;
    std::int32_t actual_index = -1;
    check(values.view().read(std::as_writable_bytes(std::span(&actual_value, 1))));
    check(indices.view().read(std::as_writable_bytes(std::span(&actual_index, 1))));
    if (actual_index != expected_index ||
        std::bit_cast<std::uint32_t>(actual_value) !=
            std::bit_cast<std::uint32_t>(expected_value))
      throw std::runtime_error("TopK value bits or stable index differ");
  };
  // First-use/vendor preparation and all correctness reads are outside timing.
  for (std::size_t step = 0; step < warmup; ++step) {
    auto done = take(slot.submit(queue)); check(done.wait());
  }
  verify();
  Events events;
  cuda_check(cudaEventCreate(&events.start));
  cuda_check(cudaEventCreate(&events.end));
  std::vector<double> wall, timeline;
  wall.reserve(iterations); timeline.reserve(iterations);
  for (std::size_t step = 0; step < iterations; ++step) {
    const auto before = std::chrono::steady_clock::now();
    cuda_check(cudaEventRecord(events.start, stream));
    auto done = take(slot.submit(queue));
    cuda_check(cudaEventRecord(events.end, stream));
    check(done.wait());
    cuda_check(cudaEventSynchronize(events.end));
    const auto after = std::chrono::steady_clock::now();
    float milliseconds = 0.0f;
    cuda_check(cudaEventElapsedTime(&milliseconds, events.start, events.end));
    wall.push_back(std::chrono::duration<double, std::micro>(after - before).count());
    timeline.push_back(static_cast<double>(milliseconds) * 1000.0);
  }
  verify();
  std::cout << std::setprecision(10)
      << "{\"width\":" << width << ",\"dtype\":\"F32\",\"k\":1,\"rows\":1,"
      << "\"warmup_replays\":" << warmup << ",\"measured_replays\":" << iterations
      << ",\"captured\":true,\"correct_bits_and_index\":true,"
      << "\"host_wall_us_median\":" << median(wall)
      << ",\"stream_event_us_median\":" << median(timeline)
      << ",\"host_wall_us\":";
  print_array(wall); std::cout << ",\"stream_event_us\":"; print_array(timeline);
  std::cout << "}\n";
  // Same stable input is intentionally reused: this measures iterator/launch
  // work with a hot ~970KiB vocabulary row, not the whole model or DRAM roofline.
  // Event span includes Graph launch admission gaps and Graph completion work.
  return 0;
} catch (const std::exception &error) {
  std::cerr << error.what() << '\n';
  return 1;
}
