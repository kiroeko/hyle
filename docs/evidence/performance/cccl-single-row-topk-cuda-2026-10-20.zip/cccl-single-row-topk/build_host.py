"""Increment three host owners and link against the retained coherent CUDA closure."""
from pathlib import Path
import datetime as dt
import importlib.util
import sys
sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
ARCH = S.parent
ROOT = ARCH.parents[1]
spec = importlib.util.spec_from_file_location('linear_topk_build', ARCH / 'ga-dense-indexer/build.py')
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)
b, c = m.b, m.c
BASE = ARCH / 'ga-dense-indexer/checks/20261019T184046-metadata-boundaries'

def main():
    out = S / 'checks' / (dt.datetime.now(dt.timezone.utc).strftime('%Y%m%dT%H%M%S') + '-host')
    out.mkdir(parents=True, exist_ok=False)
    (out / 'tmp').mkdir()
    template_path = ARCH / 'ga-dense-indexer/checks/20261019T182917/graph-test-identity.json'
    template = c.read(template_path)['command']
    qwen = c.read(BASE / 'qwen-link-plan.json')
    native_path = Path(c.read(S / 'native-check.json')['identity'])
    native = c.read(native_path)
    assert b.same(native['object']) and b.same(native['source'])
    frozen = [b.identity(p) for p in [Path(__file__), template_path, native_path,
        S / 'benchmark-source-freeze.json', S / 'tests-source-freeze.json', S / 'review.json']]
    benchmark = c.read(S / 'benchmark-source-freeze.json')
    for reviewed in (benchmark['source'], benchmark['product_test_unchanged']):
        actual = b.identity(reviewed['path'])
        assert all(actual[k] == reviewed[k] for k in ('bytes', 'sha256'))
    rows = []
    for tag, source in [('direct-test', ROOT / 'tests/compute_provider_cuda/collectives_test.cc'),
                        ('graph-test', ROOT / 'tests/graph_route_cuda/topk_test.cc'),
                        ('benchmark', S / 'single_row_topk_bench.cc')]:
        command = b.host_command(template, source, tag, out)
        assert '/W4' in command and '/WX' in command
        rows.append(dict(tag=tag, command=command, source=b.identity(source),
                         object=str(out / (tag + '.obj'))))
        frozen.append(rows[-1]['source'])
        snapshot = out / 'compiled-source' / source.relative_to(ROOT)
        snapshot.parent.mkdir(parents=True, exist_ok=True)
        snapshot.write_bytes(source.read_bytes())
    old_native = c.read(Path(c.read(S / 'native-check.json')['plan']))['old_object']
    assert old_native in qwen['inputs']
    main_object = next(r['path'] for r in qwen['inputs'] if Path(r['path']).name == '29-qwen35_text-main.obj')
    dense = c.read(BASE / 'dense-link-plan.json')
    gtests = [r for r in dense['inputs'] if Path(r['path']).name.lower() in ('gtest.lib', 'gtest_main.lib')]
    assert len(gtests) == 2
    cached = {c.key(r['path']): r for r in [*qwen['inputs'], *gtests, native['object']]}
    links = {}
    for arm in ('before-bench', 'after-bench', 'qwen', 'topk'):
        command = [x for x in qwen['command'] if not x.upper().startswith(('/OUT:', '/MAP:', '/IMPLIB:', '/PDB:'))]
        if arm != 'before-bench':
            command = [native['object']['path'] if c.key(x) == c.key(old_native['path']) else x for x in command]
        if arm != 'qwen':
            command = [x for x in command if c.key(x) != c.key(main_object)]
            extras = ([rows[2]['object']] if arm.endswith('bench') else
                      [rows[0]['object'], rows[1]['object'], *(r['path'] for r in gtests)])
            command[1:1] = extras
        image = out / (arm + '.exe')
        command += ['/OUT:' + str(image), '/MAP:' + str(image.with_suffix('.map')),
                    '/IMPLIB:' + str(image.with_suffix('.lib'))]
        inputs = [x for x in command if Path(x).is_absolute() and x.lower().endswith(('.obj', '.lib'))
                  and not x.upper().startswith(('/OUT:', '/MAP:', '/IMPLIB:', '/PDB:'))]
        assert len(inputs) == (133 if arm == 'topk' else 130)
        assert len(set(map(c.key, inputs))) == len(inputs)
        links[arm] = dict(command=command, inputs=inputs, image=str(image))
    plan = dict(compile=rows, links=links, frozen=frozen, cached_inputs=list(cached.values()),
                host_TUs=3, native_identity=str(native_path), SDK_rebuild=False)
    c.save(out / 'plan.json', plan)
    print('PLAN', out / 'plan.json', flush=True)
    def check():
        for r in frozen:
            assert b.same(r), r['path']
    check()
    for r in cached.values():
        assert b.same(r), r['path']
    env, _ = b.environment(links['qwen']['command'], [r['path'] for r in cached.values()], out)
    for row in rows:
        c.execute(row['tag'] + '-compile', row['command'], env, out)
        check()
        deps = c.read(out / (row['tag'] + '-deps.json'))['Data']
        record = dict(command=row['command'], source=row['source'], object=b.identity(row['object']),
                      dependencies=[b.identity(p) for p in [deps['Source'], *deps['Includes']]])
        c.save(out / (row['tag'] + '-identity.json'), record)
        cached[c.key(row['object'])] = record['object']
    for arm, link in links.items():
        c.execute(arm + '-link', link['command'], env, out)
        check()
        c.save(out / (arm + '-link-plan.json'), dict(command=link['command'],
               inputs=[cached[c.key(p)] for p in link['inputs']]))
        c.save(out / (arm + '-image.json'), b.identity(link['image']))
    c.save(out / 'summary.json', dict(passed=True, host_TUs=3, native_TUs_reused=1,
           SDK_rebuild=False, images={arm: b.identity(link['image']) for arm, link in links.items()}))
    c.save(S / 'host-check.json', dict(plan=str(out / 'plan.json'), summary=str(out / 'summary.json')))
    print('COMPLETE', out, flush=True)

if __name__ == '__main__':
    main()
