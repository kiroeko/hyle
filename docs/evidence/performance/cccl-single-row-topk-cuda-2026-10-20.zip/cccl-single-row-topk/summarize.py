"""Record this batch's observed results, including unproven and regressed metrics."""
from pathlib import Path
import datetime as dt
import importlib.util
import subprocess
import sys
sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('topk_summary_build', S / 'build_host.py')
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)
b, c = m.b, m.c
ROOT = S.parent.parents[1]
path = Path(c.read(S / 'host-check.json')['plan'])
test = c.read(S / 'tests/summary.json')
model = c.read(S / 'correctness/summary.json')
micro = c.read(S / 'microbenchmark/summary.json')
profile = c.read(S / 'profile/summary.json')
speed = c.read(S / 'performance-rotation/summary.json')
assert test['passed'] and test['cases'] == 6 and test['skipped'] == 0
assert model['passed'] and model['observation']['equal_vectors'] == 64
assert micro['passed'] and len(micro['runs']) == 6 and profile['passed']
assert speed['terminal_zero'] == 9 and speed['same_baseline_predictions_all9']
old = c.read(S.parent / 'ga-dense-indexer/checks/20261019T184046-metadata-boundaries/qwen-link-plan.json')
new = c.read(path.parent / 'qwen-link-plan.json')
old_set = {(c.key(r['path']), r['sha256']) for r in old['inputs']}
new_set = {(c.key(r['path']), r['sha256']) for r in new['inputs']}
assert len(old_set - new_set) == len(new_set - old_set) == 1
snapshot = S / 'after/src/compute_provider_cuda/collectives.cu'
snapshot.parent.mkdir(parents=True, exist_ok=True)
snapshot.write_bytes((ROOT / 'src/compute_provider_cuda/collectives.cu').read_bytes())
diff = subprocess.run(['git', 'diff', '--no-index', '--', str(S / 'before/src/compute_provider_cuda/collectives.cu'),
                       str(snapshot)], capture_output=True, cwd=ROOT)
assert diff.returncode == 1
(S / 'native-changes.diff').write_bytes(diff.stdout)
first = c.read(S / 'performance-rotation/01-baseline.result.json')
last = c.read(S / 'performance-rotation/09-baseline.result.json')
zone = dt.timezone(dt.timedelta(hours=8))
window = [dt.datetime.fromtimestamp(r, zone).isoformat() for r in (first['started'], last['finished'])]
summary = dict(passed=True, build_plan=b.identity(path), current_image=c.read(path.parent / 'qwen-image.json'),
    product_changes=['src/compute_provider_cuda/collectives.cu', 'tests/compute_provider_cuda/collectives_test.cc'],
    linked_native_object_changes=1, tests_passed=6, tests_skipped=0, model_equal_vectors=64,
    exact_finite_model_outputs=True, microbenchmark_processes=6, microbenchmark= micro['process_medians'],
    model_profile=dict(kernels_per_warm_step=650, single_row_fast_reduce_per_step=1,
        warm_fast_reduce_us_median=profile['warm_fast_reduce_us_median'], throughput_claim=False),
    speed_window_beijing=window, rotation_processes=9,
    current_over_baseline=speed['current_over_baseline'], current_over_llama=speed['current_over_llama'],
    groups=speed['groups'],
    contract='Only actual dense one-row reduction replaces layout iterator with byte-aligned linear loads. Same CCCL ArgPair/ArgBest/initial reduction and original selected-value bits, tie/NaN/signed-zero rules. Generic/multirow and Commands replay contract unchanged.',
    limits=['One independent rotated window, not long-run statistical significance.',
        'Prefill median regressed3.15%; sample ranges overlap and cause is unassigned.',
        'Hyle BF16 activation/output versus peer F32 remains different intermediate math.',
        'No independent model quality, cross-platform or total memory-peak acceptance.',
        'Microbenchmark event interval includes submit gaps, not kernel-only.',
        'Old/new profile durations came from different windows; not throughput evidence.',
        'Two-row dual projection candidate is scratch-only and uncompiled/unrun.'],
    goal_complete=False)
c.save(S / 'summary.json', summary)
print('SUMMARY', summary['speed_window_beijing'], flush=True)
