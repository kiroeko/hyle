"""Read retained SQLite/NCU/benchmark evidence; never loads a CUDA library."""
from pathlib import Path
import bisect
import collections
import csv
import hashlib
import importlib.util
import io
import json
import math
import statistics as st
import sys

sys.dont_write_bytecode = True
STAGE = Path(__file__).resolve().parent
BASE = STAGE.parent


def read(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def identity(path):
    return dict(path=str(path.resolve()), bytes=path.stat().st_size,
                sha256=hashlib.sha256(path.read_bytes()).hexdigest())


def stats(values):
    values = list(values)
    return dict(count=len(values), min=min(values), median=st.median(values),
                mean=st.mean(values), max=max(values),
                relative_stddev=st.pstdev(values) / st.mean(values) if st.mean(values) else 0)


def projection(kernel):
    return "internal::gemvx::kernel" in kernel["name"] or "void mul_mat_vec_f<" in kernel["name"]


def head_ncu(arm):
    folder = BASE / "cuda-current-peer/ncu/with-runtime"
    path = folder / (arm + ".stdout.log")
    lines = path.read_text(encoding="utf-8-sig").splitlines()
    first = next(i for i, line in enumerate(lines) if line.startswith('"ID","Process ID"'))
    rows = list(csv.DictReader(io.StringIO("\n".join(lines[first:]))))
    row = next(row for row in rows if row["ID"] == "0")
    def number(key):
        return float(row[key].replace(",", ""))
    return dict(arm=arm, source=identity(path), kernel=row["Kernel Name"],
                grid=row["Grid Size"], block=row["Block Size"],
                duration_ns=number("gpu__time_duration.sum"),
                dram_total_bytes=number("dram__bytes.sum"),
                dram_pct_peak=number("gpu__dram_throughput.avg.pct_of_peak_sustained_elapsed"),
                replay_passes=number("profiler__replayer_passes"),
                memory_backup_max_bytes=number("profiler__replayer_bytes_mem_backed_up.max"),
                cache_control="none", clock_control="none",
                measured_total_GB_s=number("dram__bytes.sum") / number("gpu__time_duration.sum"))


def main():
    helper_path = BASE / "cuda-stable-silu/profile-analysis-stable.py"
    spec = importlib.util.spec_from_file_location("retained_trace", helper_path)
    helper = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(helper)
    inputs = {
        "hyle": ("cast-stable-silu/profile/capture.sqlite", "cast-stable-silu/profile/capture_cuda_gpu_kern_sum.csv"),
        "peer": ("cuda-current-peer/profile/peer-trace.sqlite", "cuda-current-peer/profile/peer-trace_cuda_gpu_kern_sum.csv"),
    }
    output, raw_roles = {}, {}
    for arm, (sqlite, official_csv) in inputs.items():
        mapping_path = BASE / "decode-critical-path" / arm / "analysis.json"
        mapping = read(mapping_path)["projection_mapping_decode7"]
        data = helper.load(BASE / sqlite, BASE / official_csv)
        assert data["receipt"]["csv_sqlite_per_symbol_counts_equal"]
        endpoints = sorted(row["end"] for row in data["copies"] if row["copyKind"] == 2 and row["bytes"] == 4)
        assert len(endpoints) == len(set(endpoints)) == 32
        bins = [[] for _ in endpoints]
        for kernel in data["kernels"]:
            phase = bisect.bisect_left(endpoints, kernel["start"])
            if phase < len(bins):
                bins[phase].append(kernel)
        phases, durations, role_sums = [], collections.defaultdict(list), collections.defaultdict(list)
        all_durations = []
        for phase in range(7, 32):
            kernels = bins[phase]
            selected = [kernel for kernel in kernels if projection(kernel)]
            assert len(selected) == len(mapping) == 163
            sums = collections.Counter()
            for row, kernel in zip(mapping, selected):
                assert row["symbol"] == kernel["name"], (arm, phase, row["role"], "symbol")
                assert row["expected_grid"] == [kernel["gridX"], kernel["gridY"], kernel["gridZ"]]
                assert row["block"] == [kernel["blockX"], kernel["blockY"], kernel["blockZ"]]
                us = (kernel["end"] - kernel["start"]) / 1000
                durations[row["role"]].append(us)
                sums[row["role"]] += us
                all_durations.append(kernel["end"] - kernel["start"])
            for role, us in sums.items():
                role_sums[role].append(us)
            total = sum(k["end"] - k["start"] for k in kernels) / 1000
            phases.append(dict(phase=phase, kernels=len(kernels), projections=len(selected),
                               all_kernel_sum_us=total, projection_sum_us=sum(sums.values()), by_role_us=dict(sums)))
        roles = []
        for role, values in durations.items():
            rows = [row for row in mapping if row["role"] == role]
            count = len(rows)
            payload = sum(row["logical_weight_bytes"] for row in rows)
            roles.append(dict(role=role, count_per_decode=count,
                              logical_weight_shapes=[list(shape) for shape in dict.fromkeys(
                                  tuple(weight["shape"]) for row in rows for weight in row["weights"])],
                              weight_bytes_per_decode=payload,
                              individual_kernel_us=stats(values), per_decode_sum_us=stats(role_sums[role]),
                              share_of_projection_duration_mean_pct=100 * st.mean(role_sums[role]) / st.mean(p["projection_sum_us"] for p in phases),
                              nominal_weight_GB_s_at_median=payload / (st.median(role_sums[role]) * 1000)))
        roles.sort(key=lambda row: row["per_decode_sum_us"]["median"], reverse=True)
        small = sorted(set(value for value in all_durations if value < 4000))
        output[arm] = dict(receipt=data["receipt"], mapping_source=identity(mapping_path),
                           exact_symbol_grid_block_sequence_matches_all_25=True,
                           projection_family_counts=dict(collections.Counter(row["family"] for row in mapping)),
                           all_kernel_duration_sum_us=stats(p["all_kernel_sum_us"] for p in phases),
                           projection_duration_sum_us=stats(p["projection_sum_us"] for p in phases),
                           mean_projection_duration_share_pct=100 * st.mean(p["projection_sum_us"] for p in phases) / st.mean(p["all_kernel_sum_us"] for p in phases),
                           roles=roles, phases=phases,
                           observed_timestamp_granularity=dict(duration_gcd_ns=math.gcd(*all_durations),
                               smallest_unique_sub4us_durations_ns=small[:35],
                               sub4us_fraction_on_32ns_lattice_with_1ns_tolerance=sum(min(value % 32, 32 - value % 32) <= 1 for value in all_durations if value < 4000) / sum(value < 4000 for value in all_durations),
                               note="Sub4us observations cluster at32ns or adjacent integer-ns values. Export units/sample spacing are not a calibrated error bound. Individual ~2us nodes cannot justify sub-percent changes from a few samples; independent-window variation is much larger."))
        raw_roles[arm] = role_sums
    joined = read(BASE / "cold-capture-topology/ncu-preparation/projection-counters-joined.json")
    bench = read(BASE / "cuda-projection-fusion/summary.json")
    report = dict(scope="Existing decode7..31 trace and retained NCU/microbench only", product_changed=False,
        new_GPU_runs=0, new_builds=0, arms=output,
        source_contract=dict(consumer=identity(BASE.parents[1] / "tools/qwen35_text/main.cc"),
            references=["tools/qwen35_text/main.cc:171-174 ordinary MatMul on logical weight transpose;171 helpers preserve current input/output dtype.",
                        "tools/qwen35_text/main.cc:192-203 independent gate/up, ordinary stable SiLU, multiply and down, with each selected BF16 output boundary.",
                        "tools/qwen35_text/main.cc:370-371 two independent GDN a/b projections, followed by distinct consumers;431 tied embedding head followed by exact F32 widen."],
            current_projection_epilogue_review=identity(BASE / "projection-typed-epilogue-review/review.json")),
        fairness=dict(comparable="Same BF16 weight roles/shapes, one-token workload and 163 carrier invocations:139 ordinary +24 already-dual FFN.",
                      different="Hyle BF16 operands/output with staged BF16 RNE; peer F32 operands/output. Ordinary Hyle cuBLAS GEMVX vs peer MMVF; reduction trees and launch geometry differ.",
                      role_mapping_limit="Unchanged caller+weight inventory and ordered symbol/grid/block correspondence; these traces do not record tensor argument pointers.",
                      timing_limit="Separate historical acquisition windows, all-API instrumentation, unconstrained clocks/caches. Same phase ordinal is not a paired throughput sample. Peer sampled-logits D2H after token falls in next token-endpoint bin; report kernel sums only, not cross-engine phase-wall subtraction."),
        bandwidth=dict(head=[head_ncu("hyle"), head_ncu("peer")],
                       dual_source=identity(BASE / "cold-capture-topology/ncu-preparation/projection-counters-joined.json"),
                       dual=[dict(arm=row["arm"], metrics=row["metrics"]) for row in joined["profiles"]],
                       interpretation="Head historical DRAM utilization ~97%; dual ~93%. Large streaming shapes are already close to measured device-memory throughput in those node collections. Current Nsight Systems logical-weight bytes/time is only nominal, not measured DRAM traffic. Neither single node nor replayed counters establishes a stable cross-engine speed difference. Variable DRAM writes are not evidence of redundant output stores/spills; retained local-sector probe is zero."),
        prior_typed_single_projection=dict(source=identity(BASE / "cuda-projection-fusion/summary.json"),
                                          benchmark=bench["benchmark"], decision=bench["decision"]),
        limits=["No new performance, correctness or model quality validation.",
                "No profiler-duration subtraction is used to explain the current unprofiled throughput gap.",
                "Do not infer occupancy from row-grid size, or independent bandwidth saturation from each role's nominal GB/s.",
                "All163 current projection outputs are already BF16; no missing generic post-projection F32-to-BF16 cast epilogue was found in the retained source review."],
        next_experiment=dict(priority="Only if a projection-specific experiment is desired; large head/FFN rewrites have no demonstrated large bandwidth headroom.",
            hypothesis="The remaining small-row paired GDN a/b projections are dispatch/low-row-utilization limited; shared-input evaluation could amortize launch/read overhead without a weight replica.",
            shape="Two independent BF16 W[16,2048] x BF16 x[1,2048] -> two BF16[1,16], each F32 accumulation and separate BF16 RNE output;18 pairs per decode.",
            comparison="An isolated captured chunk with18 ordinary two-call pairs versus one no-copy paired carrier per pair, same actual inputs, resource lifetime, address rings and staged RNE. Keep default route unchanged. Use device-event chunk duration plus host wall; retain output error diagnostics because a different F32 reduction tree need not match cuBLAS bits.",
            falsification="Reject if chunk improvement does not survive interleaved repeated windows, if total gain is within observed variation, or if a new carrier increases full-model preparation/workspace enough to offset it. This is not a repeat of the already-near-parity N6144/down/head standalone route switch.",
            ceiling="The whole36-call role sum is a hard measured-in-this-trace budget, below1% of current projection device-duration sum; halving calls cannot remove all of that work. It cannot explain a multi-percent overall gap alone.",
            execution="Proposal only; no new kernel or benchmark was built/run."))
    small = next(row for row in output["hyle"]["roles"] if row["role"] == "GDN_a_or_b_projection")
    report["next_experiment"]["observed_group_median_us"] = small["per_decode_sum_us"]["median"]
    report["next_experiment"]["observed_group_mean_share_of_all_kernel_duration_pct"] = 100 * small["per_decode_sum_us"]["mean"] / output["hyle"]["all_kernel_duration_sum_us"]["mean"]
    path = STAGE / "review.json"
    path.write_text(json.dumps(report, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print(json.dumps(dict(output=identity(path), summary={arm:dict(
        projections=output[arm]["projection_duration_sum_us"], share=output[arm]["mean_projection_duration_share_pct"],
        roles=[dict(role=row["role"], count=row["count_per_decode"], median_sum_us=row["per_decode_sum_us"]["median"],
                    min_sum_us=row["per_decode_sum_us"]["min"],max_sum_us=row["per_decode_sum_us"]["max"],nominalGBs=row["nominal_weight_GB_s_at_median"]) for row in output[arm]["roles"]]) for arm in output}, head=report["bandwidth"]["head"]), indent=2))


if __name__ == "__main__":
    main()
