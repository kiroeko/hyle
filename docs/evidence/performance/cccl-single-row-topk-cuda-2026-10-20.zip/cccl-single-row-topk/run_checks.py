"""Related CUDA tests or a six-process paired public Graph Commands microbenchmark."""
from pathlib import Path
import argparse
import importlib.util
import statistics
import sys
import xml.etree.ElementTree as ET
sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('topk_run_build', S / 'build_host.py')
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)
b, c = m.b, m.c

def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('mode', choices=['tests', 'bench'])
    a = p.parse_args()
    path = Path(c.read(S / 'host-check.json')['plan'])
    plan = c.read(path)
    assert c.read(path.parent / 'summary.json')['passed']
    for row in plan['frozen']:
        assert b.same(row), row['path']
    out = S / ('tests' if a.mode == 'tests' else 'microbenchmark')
    out.mkdir(exist_ok=False)
    (out / 'tmp').mkdir()
    arm = 'topk' if a.mode == 'tests' else 'after-bench'
    link = c.read(path.parent / (arm + '-link-plan.json'))
    env, runtime = b.environment(link['command'], [r['path'] for r in link['inputs']], out)
    c.save(out / 'runtime.json', dict(build_plan=b.identity(path), runtime_library_directories=runtime))
    if a.mode == 'tests':
        names = ['CudaCccl.TopKFourTypesStableTiesNaNsAndOriginalBits',
            'CudaCccl.SingleRowTopOneDenseAndGenericLayoutsKeepStableOriginalBits',
            'CudaCccl.FloatingSpecialPrefixesAndInvalidDescriptions',
            'CudaCccl.WorkspaceAliasesAndExternalCaptureRejectBeforeWriting',
            'CudaCccl.PendingCompletionRetainsPreparedOwnersWithCallerWorkspace',
            'CudaDefaultGraph.SoftmaxTopKAndRenormalizationCaptureBothOutputs']
        image = c.read(path.parent / 'topk-image.json')
        assert b.same(image)
        c.execute('topk', [image['path'], '--gtest_filter=' + ':'.join(names),
                          '--gtest_output=xml:' + str(out / 'results.xml')], env, out)
        cases = ET.parse(out / 'results.xml').findall('.//testcase')
        actual = [x.attrib['classname'] + '.' + x.attrib['name'] for x in cases]
        passed = (len(actual) == len(names) and set(actual) == set(names) and
                  all(x.find(t) is None for x in cases for t in ('failure', 'error', 'skipped')))
        c.save(out / 'summary.json', dict(passed=passed, cases=len(cases), names=actual,
               skipped=sum(x.find('skipped') is not None for x in cases), image=image))
        assert passed
        print('TOPK_TESTS', len(cases), 'passed', flush=True)
        return
    assert c.read(S / 'tests/summary.json')['passed']
    assert c.read(S / 'correctness/summary.json')['passed']
    order = ['before-bench', 'after-bench', 'after-bench', 'before-bench', 'before-bench', 'after-bench']
    images = {arm: c.read(path.parent / (arm + '-image.json')) for arm in set(order)}
    for image in images.values():
        assert b.same(image)
    c.save(out / 'inputs.json', dict(images=images, order=order,
        same_benchmark_object=True, only_native_collectives_object_differs=True,
        independent_process_pairs=3, dependent_samples_per_process=128,
        profiler=False, build_during_timing=False,
        limit='Hot fixed ~970KiB row; Commands submit-to-completion/event span; not kernel-only or model throughput.'))
    runs = []
    for index, arm in enumerate(order):
        tag = str(index + 1) + '-' + arm
        c.execute(tag, [images[arm]['path']], env, out)
        data = c.read(out / (tag + '.stdout.log'))
        assert data['correct_bits_and_index'] and data['replay'] == 'commands' and not data['captured']
        runs.append(dict(arm=arm, tag=tag, **data))
    pairs = []
    for i in range(0, len(runs), 2):
        pair = {r['arm']: r for r in runs[i:i + 2]}
        pairs.append({key: 1 - pair['after-bench'][key] / pair['before-bench'][key]
                      for key in ('host_wall_us_median', 'stream_event_us_median')})
    medians = {arm: {key: statistics.median(r[key] for r in runs if r['arm'] == arm)
                    for key in ('host_wall_us_median', 'stream_event_us_median')} for arm in set(order)}
    c.save(out / 'summary.json', dict(passed=True, runs=runs, paired_relative_reductions=pairs,
        process_medians=medians, model_speed_claim=False))
    print('MICROBENCHMARK', medians, flush=True)

if __name__ == '__main__':
    main()
