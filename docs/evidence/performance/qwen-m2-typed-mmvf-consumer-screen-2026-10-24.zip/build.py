"""Five explicit overlay compiles and one Q35 relink; no model or download action."""
from pathlib import Path
import argparse, importlib.util, json, os, sys
sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
R = S.parents[3]
spec = importlib.util.spec_from_file_location('_original_leaf_helpers', S.parent.parent / 'm2-down-leaf-proposal/build.py')
b = importlib.util.module_from_spec(spec); spec.loader.exec_module(b)
BASE = R / '.scratch/qwen-mtp-quality-20261022/current-refresh-20261024/hyle-link2'
OWNERS = R / '.scratch/architecture-refactor-2026-10-18'
TAGS = ('provider', 'tensor', 'policy', 'native-main', 'native-mmvf')


def prepare(attempt):
    facts_path = S / 'source-facts.json'; facts = b.read(facts_path)
    for row in facts['files']:
        if row['original_path'] and b.identity(row['original_path'])['sha256'] != row['before_sha256']:
            raise ValueError('Original source changed: ' + row['path'])
        if b.identity(row['after_path'])['sha256'] != row['after_sha256']:
            raise ValueError('Overlay source changed: ' + row['path'])
    base = b.read(BASE / 'link-plan.json'); hosts = b.read(base['host_records']['path'])['records']
    old_host = {}
    wanted = {'provider': 'src/compute_provider_ggml_cuda/ggml_cuda_provider.cc',
              'tensor': 'src/compute_provider_ggml_cuda/tensor_program.cc',
              'policy': 'src/compute_route_cuda/default_policy.cc'}
    for row in hosts:
        record = b.read(row['path'])
        for tag, source in wanted.items():
            if Path(record['source']['path']) == R / source:
                if tag in old_host: raise ValueError('Nonunique original host')
                old_host[tag] = (row, record)
    if len(old_host) != 3: raise ValueError('Missing exact three host recipes')
    jobs = {}
    overlay = S / 'next-source/src/compute_provider_ggml_cuda'
    for tag, source in wanted.items():
        row, record = old_host[tag]; out = S / f'compile{attempt}' / tag
        command = [record['command'][0], '/I' + str(overlay), *record['command'][1:]]
        command[command.index('/sourceDependencies') + 1] = str(out / 'dependencies.json')
        for i, arg in enumerate(command):
            if arg == record['source']['path']: command[i] = str(S / 'next-source' / source)
            elif arg.startswith('/Fo'): command[i] = '/Fo' + str(out / 'output.obj')
            elif arg.startswith('/Fd'): command[i] = '/Fd' + str(out / 'output.pdb')
        jobs[tag] = dict(command=command, source=b.identity(S / 'next-source' / source),
                         old_object=record['object'], recipe=row)
    native = {
        'native-main': ('gdn-direct-state-output', 'native-main'),
        'native-mmvf': ('paired-projection-route', 'mmvf')}
    for tag, (owner, stem) in native.items():
        recipe = OWNERS / owner / f'checks/native1/{stem}-identity.json'
        record = b.read(recipe); out = S / f'compile{attempt}' / tag
        source = S / 'next-source/native-source/src/ggml-cuda' / ('ggml-cuda.cu' if tag == 'native-main' else 'mmvf.cu')
        command = [record['command'][0], '-I' + str(overlay), *record['command'][1:]]
        for option, value in [('-MT', out / 'output.obj'), ('-MF', out / 'dependencies.d'), ('-c', source), ('-o', out / 'output.obj')]:
            if command.count(option) != 1: raise ValueError('Nonunique original native option: ' + option)
            command[command.index(option) + 1] = str(value)
        pdb = [i for i, x in enumerate(command) if x.startswith('-Xcompiler=-Fd')]
        if len(pdb) != 1: raise ValueError('Nonunique original native PDB')
        command[pdb[0]] = '-Xcompiler=-Fd' + str(out / 'output.pdb') + ',-FS'
        jobs[tag] = dict(command=command, source=b.identity(source), old_object=record['object'], recipe=b.identity(recipe))
    replacements = {Path(row['old_object']['path']): S / f'compile{attempt}' / tag / 'output.obj' for tag, row in jobs.items()}
    counts = dict.fromkeys(replacements, 0); command = []
    for arg in base['command']:
        if arg.upper().startswith(('/OUT:', '/MAP:', '/PDB:', '/IMPLIB:')): continue
        p = Path(arg)
        if p in replacements: command.append(str(replacements[p])); counts[p] += 1
        else: command.append(arg)
    if set(counts.values()) != {1}: raise ValueError('Each of five original objects must be replaced exactly once')
    out = S / f'link{attempt}'; command += ['/OUT:' + str(out / 'qwen.exe'), '/MAP:' + str(out / 'qwen.map')]
    plan = dict(tool=b.identity(__file__), source_facts=b.identity(facts_path), base_link=b.identity(BASE / 'link-plan.json'),
                base_ready=b.identity(BASE / 'ready.json'), reused_consumer=base['compiled_record'],
                runtime_environment=b.identity(BASE / 'runtime-environment.json'), jobs=jobs, link=command,
                scope='Scratch finite exact-descriptor/device-profile consumer candidate. Only3host+2native replaced; old Q35 consumer and all other original objects/libraries retained. No SDK or canonical change.')
    p = S / f'commands{attempt}.json'
    if p.exists() and b.read(p) != plan: raise ValueError('Preserve immutable attempt')
    if not p.exists(): b.save(p, plan)
    return p, plan


def execute(command, out, plan):
    h = b.load('_retained_host_environment', R / '.scratch/native-paged-effects-20261022/build_windows.py')
    env, _ = h.b.environment(plan['jobs']['provider']['command'], [], out)
    env['PATH'] = str(Path(plan['jobs']['native-main']['command'][0]).parent) + os.pathsep + env['PATH']
    q = b.load('_retained_process_runner', R / '.scratch/qwen-mtp-quality-20261022/run_quality.py')
    return q.execute(command, env, out / 'run', timeout=1200)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action', choices=('prepare', 'compile', 'link'))
    parser.add_argument('--tag', choices=TAGS); parser.add_argument('--attempt', type=int, default=1)
    args = parser.parse_args()
    if args.attempt < 1: raise ValueError('Positive unique attempt required')
    p, plan = prepare(args.attempt)
    if args.action == 'prepare': print(json.dumps(dict(commands=b.identity(p), jobs=list(plan['jobs']), actual_compiles=0, HTTP=0))); return 0
    if args.action == 'compile':
        if args.tag is None: raise ValueError('Choose exactly one compile tag')
        job = plan['jobs'][args.tag]; out = S / f'compile{args.attempt}' / args.tag
        out.mkdir(parents=True, exist_ok=False); (out / 'tmp').mkdir()
        result = execute(job['command'], out, plan)
        if result['exit'] or result['timed_out']: return result['exit'] or 1
        b.require(job['source'])
        dependency = out / ('dependencies.d' if args.tag.startswith('native-') else 'dependencies.json')
        b.save(out / 'identity.json', dict(source=job['source'], object=b.identity(out / 'output.obj'), process=result,
            command=job['command'], commands=b.identity(p), recipe=job['recipe'], dependency_file=b.identity(dependency)))
    else:
        records = []
        for tag in TAGS:
            record_path = S / f'compile{args.attempt}' / tag / 'identity.json'; record = b.read(record_path)
            for key in ('source', 'object', 'commands', 'dependency_file'): b.require(record[key])
            if record['process']['exit'] or record['process']['timed_out']: raise ValueError('Actual compile failed')
            records.append(b.identity(record_path))
        b.require(plan['reused_consumer'])
        consumer = b.read(plan['reused_consumer']['path']); b.require(consumer['source'])
        out = S / f'link{args.attempt}'; out.mkdir(exist_ok=False); (out / 'tmp').mkdir()
        result = execute(plan['link'], out, plan)
        if result['exit'] or result['timed_out']: return result['exit'] or 1
        b.save(out / 'ready.json', dict(image=b.identity(out / 'qwen.exe'), commands=b.identity(p), records=records,
            reused_consumer=plan['reused_consumer'], runtime_environment=plan['runtime_environment'], process=result,
            canonical_changes=0, SDK_builds=0, fresh_host_TUs=3, fresh_NVCC_TUs=2, native_runs=0, HTTP=0))
    return 0


if __name__ == '__main__': sys.exit(main())
