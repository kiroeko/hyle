#pragma once
#include <cstdint>

namespace hyle::compute::ggml_cuda::bridge {
// Finite consumer-screen policy, not a general BF16 small-M cost model.
// Actual native ordinal and cached device resource profile; no model identity.
bool select_bfloat_m2(int native_device, std::uint64_t inner,
                      std::uint64_t output_width, std::uint64_t tokens);
} // namespace hyle::compute::ggml_cuda::bridge
