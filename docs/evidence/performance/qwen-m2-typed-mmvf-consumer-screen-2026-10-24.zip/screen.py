"""Six fresh MTP processes, retained natural two-turn64 workload; root schedules run."""
from pathlib import Path
import argparse, importlib.util, json, os, statistics, sys
sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
W = S.parent.parent
spec = importlib.util.spec_from_file_location('_retained_natural_turns_parser', W / 'turns.py')
t = importlib.util.module_from_spec(spec); spec.loader.exec_module(t)
b, q = t.base, t.smoke.q
BASE = t.c.CURRENT / 'hyle-link2/ready.json'
CANDIDATE = S / 'link2/ready.json'
REFERENCE = W / 'current-window2/natural-timing-plan1.json'
EXPECTED = {'base': 'bdbd2c8149871e76d680b410ef77fc6f87d5524479dcae3a38b9f2d25face105',
            'candidate': 'e9487374f5edb670982e76f23fa23be603a12edc83ef9149bbe6c745be25a50e'}
ORDER = ('base', 'candidate', 'candidate', 'base', 'base', 'candidate')


def plan(attempt):
    reference = b.read(REFERENCE)
    entry = next(x for x in reference['commands'] if x['arm'] == 'hyle_mtp')
    t.c.require(reference['schedule']); t.c.require(reference['input'])
    if (reference['quota'], reference['capacity'], len(reference['user_ids'])) != (64, 1024, 154):
        raise ValueError('Retained natural two-turn workload differs')
    images = {}
    for arm, path in [('base', BASE), ('candidate', CANDIDATE)]:
        ready = b.read(path)
        if ready['image']['sha256'] != EXPECTED[arm]: raise ValueError('Unexpected image identity')
        t.c.require(ready['image']); t.c.require(ready['runtime_environment'])
        if ready['runtime_environment'] != entry['environment']: raise ValueError('Actual runtime environment differs')
        images[arm] = dict(ready=b.identity(path), image=ready['image'], environment=ready['runtime_environment'])
    out = S / f'screen{attempt}'
    commands = []
    for i, arm in enumerate(ORDER, 1):
        command = [images[arm]['image']['path'], *entry['command'][1:]]
        commands.append(dict(ordinal=i, arm=arm, folder=str(out / f'{i:02}-{arm}'), command=command))
    return dict(driver=b.identity(Path(__file__)), reference_plan=b.identity(REFERENCE),
        images=images, commands=commands, order=list(ORDER), output=str(out),
        quota=64, capacity=1024, user_ids=reference['user_ids'], schedule=reference['schedule'],
        turn_count=2, new_user_tokens=308, prefill_target_input_rows=309, maximum_decode_outputs=126,
        processes=6, processes_per_arm=3, profiler=False, memory_sampling=False, warmup=False,
        scope='Finite baseline/candidate MTP consumer screen only. Same natural two-turn64 schedule and original flags. Retain actual IDs, acceptance, rows, rounds and top-level continuous P/D/session; no forced cross-arm outputs or full quality claim.')


def analyze(out):
    p = b.read(out / 'plan.json'); runs = b.read(out / 'runs.json')
    if len(runs) != 6 or [x['arm'] for x in runs] != list(ORDER): raise ValueError('Expected exactly six actual processes')
    arms = {}
    for arm in EXPECTED:
        rows = [x['observation'] for x in runs if x['arm'] == arm]; first = rows[0]
        stable = dict(identical_IDs=all(x['generated_ids'] == first['generated_ids'] for x in rows),
            identical_exported_work=all(x['work'] == first['work'] for x in rows),
            identical_non_time_rounds=all(t.c.h.decision_work(x['raw']['rounds']) == t.c.h.decision_work(first['raw']['rounds']) for x in rows))
        metrics = {}
        for key in first['metrics']:
            values = [x['metrics'][key] for x in rows]
            metrics[key] = dict(samples=values, median=statistics.median(values), range=[min(values), max(values)]) if all(v is not None for v in values) else dict(samples=values)
        arms[arm] = dict(processes=len(rows), stable=all(stable.values()), within_arm=stable, metrics=metrics,
                         generated_ids=[x['generated_ids'] for x in rows], work=[x['work'] for x in rows])
    a, c = [next(x['observation'] for x in runs if x['arm'] == arm) for arm in ('base', 'candidate')]
    summary = dict(status='complete_stable_within_arm' if all(x['stable'] for x in arms.values()) else 'complete_with_within_arm_variability',
        processes=6, plan=b.identity(out / 'plan.json'), arms=arms,
        cross_arm=dict(identical_IDs=a['generated_ids'] == c['generated_ids'], identical_exported_work=a['work'] == c['work'],
                       identical_non_time_rounds=t.c.h.decision_work(a['raw']['rounds']) == t.c.h.decision_work(c['raw']['rounds'])),
        profiler=False, memory_sampling=False, product_adopted=False, scope=p['scope'])
    b.save(out / 'summary.json', summary)
    return summary


def run(attempt):
    out = S / f'screen{attempt}'
    if out.exists(): raise ValueError('Preserve actual output; use a fresh attempt')
    p = plan(attempt); out.mkdir(); b.save(out / 'plan.json', p); runs = []
    for entry in p['commands']:
        arm = entry['arm']; env = os.environ.copy()
        env['PATH'] = b.read(p['images'][arm]['environment']['path'])['PATH']
        folder = Path(entry['folder']); print('SCREEN_BEGIN', entry['ordinal'], arm, flush=True)
        process = q.execute(entry['command'], env, folder, timeout=600)
        row = dict(arm=arm, ordinal=entry['ordinal'], process=process)
        runs.append(row); b.save(out / 'runs.json', runs)
        if process['exit'] or process['timed_out']:
            b.save(out / 'summary.json', dict(status='incomplete_actual_process_failure', processes=len(runs), failed=row)); return process['exit'] or 1
        try:
            observation = t.parse_result(folder, 'hyle_mtp', p)
        except Exception as error:
            b.save(out / 'summary.json', dict(status='incomplete_actual_observation_failure', processes=len(runs), failed=row, error=str(error))); raise
        row['observation'] = observation
        b.save(folder / 'observation.json', observation); b.save(out / 'runs.json', runs)
        print('SCREEN_END', entry['ordinal'], arm, observation['metrics']['decode_seconds'], observation['actual_context'], flush=True)
    result = analyze(out); print('SCREEN_COMPLETE', result['status'], out / 'summary.json', flush=True); return 0


if __name__ == '__main__':
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument('action', choices=('plan', 'run', 'analyze')); cli.add_argument('--attempt', type=int, default=1)
    args = cli.parse_args()
    if args.attempt < 1: raise ValueError('Positive fresh attempt required')
    if args.action == 'plan':
        value = plan(args.attempt); b.save(S / f'screen-plan{args.attempt}.json', value)
        print('PLAN_ONLY', 6, value['output'], flush=True)
    elif args.action == 'run': sys.exit(run(args.attempt))
    else: print(json.dumps(analyze(S / f'screen{args.attempt}')))
