from pathlib import Path
import importlib.util,sys,json,collections
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent;A=S.parent;R=A.parents[1];O=S/'ab';O.mkdir(exist_ok=True)
spec=importlib.util.spec_from_file_location('stable_bind_ab_helpers',A/'grouped-shared-activation/build_host.py');h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h);b,c=h.b,h.c
paths={'base':A/'qwen-finite-family/product-checks/qwen-link-plan.json','fresh':A/'cuda-native-storage-cast/green/link-plan.json'};plans={k:c.read(p)for k,p in paths.items()};meta=h.metadata(plans)
cache={}
def same(row):
 key=(c.key(row.get('path','')),row.get('bytes'),row.get('sha256'))
 if key not in cache:
  try:cache[key]=h.same_identity(row)
  except (OSError,KeyError):cache[key]=False
 return cache[key]
fresh={};dupes={} 
for row in plans['fresh']['inputs']:
 rec=meta.get(c.key(row['path']))
 if not rec:continue
 sk=c.key(rec['source_path'])
 if sk in fresh:dupes.setdefault(sk,[fresh[sk][0]['path']]).append(row['path'])
 else:fresh[sk]=(row,rec)
rows=[]
for row in plans['base']['inputs']:
 rec=meta.get(c.key(row['path']));selected=row;why='retained qwen-only or native/SDK input';new=rec
 if rec and c.key(rec['source_path'])in fresh:
  selected,new=fresh[c.key(rec['source_path'])];why='same-source current green object'
 mismatches=[]
 if not same(selected):mismatches.append({'kind':'input','identity':selected})
 if new:
  source=new.get('source')
  if not isinstance(source,dict):source=next((d for d in new.get('dependencies',[])if c.key(d.get('path',''))==c.key(new['source_path'])),None)
  if not source:mismatches.append({'kind':'missing_source_identity','source':new['source_path']})
  elif not same(source):mismatches.append({'kind':'source','identity':source})
  for d in new.get('dependencies',[]):
   if not same(d):mismatches.append({'kind':'dependency','identity':d})
 rows.append({'old':row,'selected':selected,'reason':why,'source':None if not new else new['source_path'],'recipe':None if not new else new['recipe'],'dependency_count':0 if not new else len(new.get('dependencies',[])),'mismatches':mismatches})
result={'plans':{k:b.identity(p)for k,p in paths.items()},'rows':rows,'replacements':sum(c.key(x['old']['path'])!=c.key(x['selected']['path'])for x in rows),'fresh_source_duplicates':dupes,'bad_rows':[x for x in rows if x['mismatches']],'unmapped_objects':[x for x in rows if Path(x['selected']['path']).suffix.lower()=='.obj' and not x['source']]}
c.save(O/'closure-inventory.json',result)
print(json.dumps({k:result[k]for k in ['replacements','fresh_source_duplicates']},indent=2));print('badrows',len(result['bad_rows']),'unmapped',len(result['unmapped_objects']))
for row in result['bad_rows']:print(json.dumps({'source':row['source'],'old':row['old']['path'],'selected':row['selected']['path'],'mismatches':row['mismatches'][:5]},indent=2))
for row in result['unmapped_objects']:print('UNMAPPED',row['selected']['path'])
