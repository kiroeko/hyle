from pathlib import Path
import json,re,statistics,hashlib
S=Path('.scratch/architecture-refactor-2026-10-18/decode-stable-bind');O=S/'peer-window';runs=json.loads((O/'runs.json').read_text());result=[]
def I(p):
 b=Path(p).read_bytes();return dict(path=str(Path(p).resolve()),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
for run in runs:
 rows=[]
 if run['arm']=='current':
  text=(O/(run['tag']+'.stderr.log')).read_text()
  prepared={int(vis)-128:dict(cold_batch_seconds=float(sec),capture_recorded=int(rec),capture_reused=int(reused))for vis,sec,rec,reused in re.findall(r'^prepared T=1 visible=(\d+) replay=\w+ cold_batch_seconds=([0-9.e+-]+) capture_recorded=(\d+) capture_reused=(\d+)',text,re.M)}
  for phase,seconds,submit,step in re.findall(r'^decode(\d+) tokens=1 visible=\d+ seconds=([0-9.e+-]+) submit_seconds=([0-9.e+-]+) step_seconds=([0-9.e+-]+)',text,re.M):
   phase=int(phase);p=prepared[phase];v=dict(phase=phase,step_seconds=float(step),post_prepare_submit_wait_and_id_read_seconds=float(seconds),submit_call_seconds=float(submit),**p);v['outside_cold_and_post_prepare_seconds']=v['step_seconds']-v['cold_batch_seconds']-v['post_prepare_submit_wait_and_id_read_seconds'];v['post_submit_wait_and_id_read_seconds']=v['post_prepare_submit_wait_and_id_read_seconds']-v['submit_call_seconds'];rows.append(v)
 else:
  peer=json.loads((O/(run['tag']+'-peer-result.json')).read_text());rows=[p for p in peer['phases']if p['phase']>0]
 assert [p['phase']for p in rows]==list(range(1,32))
 groups={}
 fields=(['step_seconds','cold_batch_seconds','post_prepare_submit_wait_and_id_read_seconds','submit_call_seconds','outside_cold_and_post_prepare_seconds','post_submit_wait_and_id_read_seconds']if run['arm']=='current'else ['step_seconds','input_prepare_seconds','decode_return_seconds','synchronize_seconds','token_access_seconds','sample_fastpath_seconds'])
 for name,selected in [('first2',rows[:2]),('first6',rows[:6]),('later25',rows[6:]),('all31',rows)]:
  groups[name]={key:sum(p[key]for p in selected)for key in fields};groups[name]['tokens']=len(selected);groups[name]['tokens_per_second']=len(selected)/groups[name]['step_seconds']
 result.append(dict(arm=run['arm'],tag=run['tag'],source=I(O/(run['tag']+('.stderr.log'if run['arm']=='current'else'-peer-result.json'))),phases=rows,groups=groups))
medians={}
for arm in ['current','llama']:
 medians[arm]={}
 for group in ['first2','first6','later25','all31']:
  keys=next(x for x in result if x['arm']==arm)['groups'][group].keys();medians[arm][group]={k:dict(samples=[x['groups'][group][k]for x in result if x['arm']==arm],median=statistics.median(x['groups'][group][k]for x in result if x['arm']==arm))for k in keys}
report=dict(status='read_only_existing_phase_decomposition',raw_runs=I(O/'runs.json'),runs=result,group_medians=medians,interpretation=['First6meansdecode1..6, later25meansdecode7..31; prefill excluded from both.','Hyle first2decode phases perform the first actual recording for each parity slot. Later phases reuse one retained outer capture. cold_batch includes configuration/layout preparation,metadata readiness and capture preparation, not capture alone.','Hyle post_prepare field includes submit, completion wait and4BIDread; it is not pureGPUtime. outside residual is derived from printed timer precision and includes input preparation/uploads/hostgaps, not an independently instrumented API.','Peer exposes decode_return/synchronize/tokenaccess/sample timers, but their scopes differ from Hyle. Compare total step latencies; do not label matching component names as common CPU/GPU cost.','Medians of summed stages are independent summaries and need not sum to the median of total step time. No new GPU process, profiler or timing boundary change.'],GPU_runs=0,profiler_runs=0)
p=O/'phase-decomposition.json';p.write_text(json.dumps(report,indent=2)+'\n')
for arm in medians:
 print(arm)
 for g,v in medians[arm].items():print(g,{k:round(x['median']*1000,4)for k,x in v.items()if k not in ['tokens','tokens_per_second']},'tok/s',v['tokens_per_second']['median'])
print(I(p))
