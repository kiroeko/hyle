from pathlib import Path
import importlib.util,sys,concurrent.futures
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent;A=S.parent;O=S/'ab'
spec=importlib.util.spec_from_file_location('stable_bind_link_helpers',A/'grouped-shared-activation/build_host.py');h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h);b,c=h.b,h.c
assembly=c.read(O/'link-assembly.json');first=c.read(O/'before/link-plan.json');env,runtime=b.environment(first['command'],[x['path']for x in first['inputs']],O);c.save(O/'runtime-environment.json',dict(PATH=env['PATH'],LIB=env.get('LIB'),INCLUDE=env.get('INCLUDE'),runtime=runtime))
def link(arm):
 p=O/arm/'link-plan.json';plan=c.read(p)
 for row in plan['inputs']:assert h.same_identity(row),row['path']
 assert h.same_identity(plan['main'])
 c.execute('link',plan['command'],env,O/arm)
 for row in plan['inputs']:assert h.same_identity(row),row['path']
 image=b.identity(O/arm/'qwen.exe');c.save(O/arm/'image.json',image);return dict(arm=arm,image=image,link_plan=b.identity(p))
with concurrent.futures.ThreadPoolExecutor(max_workers=2)as pool:results=list(pool.map(link,['before','current']))
c.save(O/'link-summary.json',dict(passed=True,links=2,CXX_this_script=0,main_CXX_total_stage=2,NVCC=0,GPU_runs=0,shared_inputs_count=assembly['common_inputs_count'],arms=results))
print('SAME_CORE_TWO_LINKS_GREEN')
