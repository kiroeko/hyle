from pathlib import Path
import importlib.util,sys
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent;A=S.parent;ROOT=A.parents[1];OUT=S/'checks';OUT.mkdir(exist_ok=True);(OUT/'tmp').mkdir(exist_ok=True)
spec=importlib.util.spec_from_file_location('stable_bind_host_helpers',A/'grouped-shared-activation/build_host.py');h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h);b,c=h.b,h.c
base=c.read(A/'qwen-finite-family/product-checks/qwen-link-plan.json');recipe_path=A/'qwen-finite-family/product-checks/main-identity.json';recipe=c.read(recipe_path);freeze=c.read(S/'source-freeze.json');source=ROOT/'tools/qwen35_text/main.cc'
assert b.identity(source)['sha256']==freeze['source']['sha256']
env,runtime=b.environment(base['command'],[row['path']for row in base['inputs']],OUT);c.save(OUT/'environment.json',dict(PATH=env['PATH'],runtime=runtime))
command=b.host_command(recipe['command'],source,'main',OUT);c.save(OUT/'plan.json',dict(command=command,source=b.identity(source),original_recipe=b.identity(recipe_path),source_freeze=b.identity(S/'source-freeze.json'),links=0,GPU_runs=0))
c.execute('main-compile',command,env,OUT)
assert b.identity(source)['sha256']==freeze['source']['sha256']
dep=OUT/'main-deps.json';data=c.read(dep)['Data'];receipt=dict(command=command,source=b.identity(source),object=b.identity(OUT/'main.obj'),source_dependencies=b.identity(dep),dependencies=[b.identity(p)for p in dict.fromkeys([data['Source'],*data['Includes']])],recipe=str(recipe_path));c.save(OUT/'main-identity.json',receipt);c.save(OUT/'summary.json',dict(passed=True,CXX_processes=1,links=0,GPU_runs=0,SDK_rebuilds=0,source=receipt['source'],object=receipt['object'],source_freeze=b.identity(S/'source-freeze.json'),limits='Host compile only; root will use identical current shared-product closure for baseline/candidate links. No correctness/throughput result yet.'))
