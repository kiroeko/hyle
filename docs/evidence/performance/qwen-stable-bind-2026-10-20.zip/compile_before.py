from pathlib import Path
import importlib.util,sys
sys.dont_write_bytecode=True
S=Path('.scratch/architecture-refactor-2026-10-18/decode-stable-bind').resolve();A=S.parent;R=A.parents[1];O=S/'ab';(O/'tmp').mkdir(exist_ok=True)
spec=importlib.util.spec_from_file_location('stable_bind_baseline_helpers',A/'grouped-shared-activation/build_host.py');h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h);b,c=h.b,h.c
base=c.read(A/'qwen-finite-family/product-checks/qwen-link-plan.json');recipe_path=A/'qwen-finite-family/product-checks/main-identity.json';recipe=c.read(recipe_path);src=S/'before/tools/qwen35_text/main.cc';assert b.identity(src)['sha256']=='883dcaecb78294b14bb0502c8488c59efcb6d8661aabb9c6820e4c6c736c1579'
env,runtime=b.environment(base['command'],[x['path']for x in base['inputs']],O);c.save(O/'environment.json',dict(PATH=env['PATH'],LIB=env.get('LIB'),INCLUDE=env.get('INCLUDE'),runtime=runtime))
command=b.host_command(recipe['command'],src,'before-main',O);c.save(O/'before-main-plan.json',dict(command=command,source=b.identity(src),original_recipe=b.identity(recipe_path),scope='Same original main recipe and include paths; only source snapshot/output paths differ.'))
c.execute('before-main-compile',command,env,O);d=c.read(O/'before-main-deps.json')['Data'];c.save(O/'before-main-identity.json',dict(command=command,source=b.identity(src),object=b.identity(O/'before-main.obj'),source_dependencies=b.identity(O/'before-main-deps.json'),dependencies=[b.identity(p)for p in dict.fromkeys([d['Source'],*d['Includes']])],recipe=str(recipe_path)))
print('BASELINE_MAIN_CXX_GREEN')
