from pathlib import Path
import importlib.util,sys
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent;A=S.parent;O=S/'peer-prepared';O.mkdir(exist_ok=True);(O/'tmp').mkdir(exist_ok=True)
spec=importlib.util.spec_from_file_location('stable_bind_peer_helpers',A/'qwen-finite-family/compare.py');h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h);b,c,r=h.b,h.c,h.r
old=c.read(A/'qwen-finite-family/performance-prepared/plan.json');peer=c.read(r.PEER_PLAN);link=c.read(S/'ab/current/link-plan.json');images={'current':c.read(S/'ab/current/image.json'),'llama':old['images']['llama']}
for row in [*images.values(),*link['inputs'],*old['peer_inputs']]:r.require_same(row)
assert c.read(S/'correctness/summary.json')['passed'];assert c.read(S/'final-validation.json')['actual_process_totals']['model_exit0']==6
wanted=set()
for arm in ['current','llama']:
 cmd=next(x['command']for x in old['requests']if x['arm']==arm)
 if arm=='current':
  inp=Path(cmd[cmd.index('--inputs')+1]);wanted.update(c.key(p)for p in [inp/'weights.tsv',inp/'prompt.ids',Path(cmd[cmd.index('--decode-ids')+1]),Path((inp/'weights.tsv').read_text().splitlines()[1])])
 else:wanted.update(c.key(p)for p in [Path(cmd[1]),Path(cmd[2])])
frozen=[x for x in old['frozen']if c.key(x['path'])in wanted];assert {c.key(x['path'])for x in frozen}==wanted
for row in frozen:r.require_same(row)
order=['current','llama','llama','current','current','llama'];requests=[]
for i,arm in enumerate(order,1):
 template=next(x['command']for x in old['requests']if x['arm']==arm).copy();template[0]=images[arm]['path'];tag=f'{i:02}-{arm}'
 if arm=='llama':template[-1]='{output}/'+tag+'-peer-result.json'
 assert '--trace'not in template;requests.append(dict(arm=arm,tag=tag,command=template))
env,runtime=b.environment(link['command'],[x['path']for x in link['inputs']]+[x['path']for x in old['peer_inputs']],O)
for key in r.FORBIDDEN_ENV:assert key not in env,key
plan={key:old[key]for key in ['fixed','source_id','expected_baseline_ids','metric_contract']};plan.update(status='prepared_not_run',order=order,images=images,requests=requests,frozen=frozen,peer_inputs=old['peer_inputs'],common_plan=b.identity(S/'ab/current/link-plan.json'),peer_plan=b.identity(r.PEER_PLAN),runtime=runtime,correctness=b.identity(S/'correctness/summary.json'),bind_ab=b.identity(S/'final-validation.json'),source_freeze=b.identity(S/'source-freeze.json'),compiles=0,links=0,GPU_runs=0,profiler=False,external_memory_monitor=False,statistical_significance=False,independent_quality_acceptance=False,limits=['One new6process rotated window,3fresh processes per image; no old samples pooled or reverse window planned.','Same frozen BF16 weight artifact provenance and exact128prompt+31teacher-forced decode inputs/context256; current IDs do not drive next input.','Hyle BF16 activation/output boundaries/F32accum differ from peer F32 activation/output intermediates. Same weights and predictions do not prove equivalent math or model quality.','Peer consumer reads248320F32logits per phase; Hyle reads4BselectedID. Keep end-to-end consumer difference explicit.','Hyle prepares finiteT128/T1 before prefill; peer graph maintenance occurs in step. Model load and context prepare sub-boundaries differ; compare startup/TTFT as wider observations.','No profiler/memory/power observer; OS cache not cleared and frequency/other system drift remain possible.','Reference retained image/object/library input hashes verified; no source/SDK rebuild or new support claim.'])
c.save(O/'plan.json',plan);c.save(O/'environment.json',dict(PATH=env['PATH'],runtime=runtime));print('SIX_PROCESS_PEER_PLAN_READY_NO_GPU',O/'plan.json')
