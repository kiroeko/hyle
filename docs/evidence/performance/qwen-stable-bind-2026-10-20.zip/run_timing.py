from pathlib import Path
import importlib.util,sys,re,statistics
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent;A=S.parent;O=S/'timing';O.mkdir(exist_ok=True);(O/'tmp').mkdir(exist_ok=True)
spec=importlib.util.spec_from_file_location('stable_bind_perf_helpers',A/'qwen-finite-family/compare.py');h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h);b,c,r=h.b,h.c,h.r
plan=c.read(A/'qwen-finite-family/performance-prepared/plan.json');assert c.read(S/'correctness/summary.json')['passed'];assembly=c.read(S/'ab/link-assembly.json');images={arm:c.read(S/'ab'/arm/'image.json')for arm in ['before','current']};link=c.read(S/'ab/current/link-plan.json');env,runtime=b.environment(link['command'],[x['path']for x in link['inputs']],O)
for key in r.FORBIDDEN_ENV:assert key not in env,key
for row in [*assembly['common_inputs'],*images.values()]:r.require_same(row)
request=next(row for row in plan['requests']if row['arm']=='current');template=request['command'].copy();assert '--trace'not in template
inputs=Path(template[template.index('--inputs')+1]);wanted={c.key(inputs/'weights.tsv'),c.key(inputs/'prompt.ids'),c.key(template[template.index('--decode-ids')+1]),c.key(Path((inputs/'weights.tsv').read_text().splitlines()[1]))};frozen=[x for x in plan['frozen']if c.key(x['path'])in wanted];assert {c.key(x['path'])for x in frozen}==wanted
for row in frozen:r.require_same(row)
order=['before','current','current','before'];c.save(O/'inputs.json',dict(order=order,images=images,common_inputs=assembly['common_inputs'],frozen=frozen,runtime=runtime,source_freeze=b.identity(S/'source-freeze.json'),assembly=b.identity(S/'ab/link-assembly.json'),profiler=False,external_memory_monitor=False,compiles=0,links=0,peer_comparison=False,limits='Bounded4fresh-process same-current-core window. Two samples/arm; no statistical-significance claim. OS file cache not cleared.'))
runs=[]
for i,arm in enumerate(order,1):
 cmd=template.copy();cmd[0]=images[arm]['path'];tag=f'{i:02}-{arm}';req=dict(arm='baseline'if arm=='before'else'current',tag=tag,command=cmd);process=r.execute(tag,cmd,env,O);obs=r.hyle_result(O,req,plan);assert obs['same_baseline_predictions'];assert obs['capture_counts']==[[1,0]]*3+[[0,1]]*29
 text=(O/(tag+'.stderr.log')).read_text();cold=[float(x)for x in re.findall(r'prepared T=1 visible=\d+ replay=\w+ cold_batch_seconds=([0-9.e+-]+)',text)][6:];submit=[float(x)for x in re.findall(r'decode\d+ tokens=1 .*?submit_seconds=([0-9.e+-]+)',text)][6:];assert len(cold)==25
 obs['metrics'].update(warm_cold_batch_seconds=sum(cold),warm_cold_batch_median_seconds=statistics.median(cold),warm_submit_seconds=sum(submit),warm_submit_median_seconds=statistics.median(submit));runs.append(dict(arm=arm,tag=tag,pid=process['pid'],exit=process['exit'],**obs));c.save(O/'runs.json',runs)
keys=list(runs[0]['metrics']);groups={arm:{k:dict(samples=[x['metrics'][k]for x in runs if x['arm']==arm],median=statistics.median(x['metrics'][k]for x in runs if x['arm']==arm))for k in keys}for arm in ['before','current']}
for row in [*assembly['common_inputs'],*images.values(),*frozen]:r.require_same(row)
c.save(O/'summary.json',dict(executed=True,terminal_zero=4,groups=groups,current_over_before={k:groups['current'][k]['median']/groups['before'][k]['median']for k in keys},same_predictions=True,statistical_significance=False,peer_comparison=False,scope='Only before/current consumer on identical149common inputs;4fresh unprofiled model processes. Observed window, not stable large throughput gain proof.'))
print('STABLE_BIND_SMALL_WINDOW_COMPLETE')
