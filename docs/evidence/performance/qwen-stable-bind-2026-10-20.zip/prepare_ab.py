from pathlib import Path
import importlib.util,sys,json
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent;A=S.parent;R=A.parents[1];O=S/'ab'
spec=importlib.util.spec_from_file_location('stable_bind_prepare_helpers',A/'grouped-shared-activation/build_host.py');h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h);b,c=h.b,h.c
paths={'qwen':A/'qwen-finite-family/product-checks/qwen-link-plan.json','dense':A/'cuda-native-storage-cast/dense/link-plan.json','current_state':A/'state-clone-slot-ownership/checks/after-link-plan.json','current_custom':A/'layout-binding-lifetime/checks/link-plan.json'};plans={k:c.read(p)for k,p in paths.items()};meta=h.metadata(plans)
def actual_source(obj):
 if rec:=meta.get(c.key(obj['path'])):return rec['source_path']
 p=Path(obj['path'])
 if '.scratch\\b-cuda-d5\\src\\compute_provider_cuda\\CMakeFiles\\'in str(p) and p.name.endswith('.cu.obj'):return str(R/'src/compute_provider_cuda'/p.name[:-4])
 return None
fresh={actual_source(row):row for row in plans['dense']['inputs']if actual_source(row)}
# These existing source-identical common objects carry the complete current fixes.
for source,receipt in [('src/compute_state/state_versions.cc',A/'state-clone-slot-ownership/checks/after-state_versions-identity.json'),('src/compute/custom_kernel.cc',A/'layout-binding-lifetime/checks/compute-custom_kernel-identity.json')]:
 rec=c.read(receipt);assert h.same_identity(rec['source']);assert h.same_identity(rec['object']);fresh[str(R/source)]=rec['object']
old_main=c.read(A/'qwen-finite-family/product-checks/main-identity.json')['object'];candidate=c.read(S/'checks/main-identity.json');before=c.read(O/'before-main-identity.json')
for rec in [candidate,before]:
 assert h.same_identity(rec['source']) and h.same_identity(rec['object'])
 assert all(h.same_identity(d)for d in rec['dependencies'])
replacement={};records=[]
for old in plans['qwen']['inputs']:
 source=actual_source(old);chosen=fresh.get(source,old);assert h.same_identity(old),old;assert h.same_identity(chosen),chosen
 if c.key(old['path'])!=c.key(chosen['path']):replacement[c.key(old['path'])]=chosen;records.append(dict(source=source,old=old,selected=chosen))
lookup={c.key(row['path']):row for row in [*plans['qwen']['inputs'],*replacement.values(),candidate['object'],before['object']]}
# Ensure the private64bitTensorLayout host+native closure is taken from same final dense plan.
for ending in ['tensor-kernel.obj','tensor-provider.obj','row-cache.obj','artifact-provider.obj']:
 matching=[row for row in replacement.values()if Path(row['path']).name==ending];assert len(matching)==1,(ending,matching)
common=[];arms={}
for arm,main in [('before',before),('current',candidate)]:
 out=O/arm;out.mkdir(exist_ok=True);command=[]
 for arg in plans['qwen']['command']:
  if arg.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:')):continue
  if c.key(arg)==c.key(old_main['path']):command.append(main['object']['path'])
  elif c.key(arg)in replacement:command.append(replacement[c.key(arg)]['path'])
  else:command.append(arg)
 image=out/'qwen.exe';command+=['/OUT:'+str(image),'/MAP:'+str(image.with_suffix('.map')),'/IMPLIB:'+str(image.with_suffix('.lib'))]
 inputs=[lookup[c.key(arg)]for arg in command if Path(arg).is_absolute()and Path(arg).suffix.lower()in('.obj','.lib')]
 other=[row for row in inputs if row!=main['object']]
 if common:assert common==other
 else:common=other
 plan=dict(command=command,inputs=inputs,main=main['source'],main_object=main['object'],common_source_basis={key:b.identity(p)for key,p in paths.items()},shared_inputs_count=len(common),scope='Identical selected common/native/SDK inputs for both before/current main, no provider/mathematics change between arms.')
 c.save(out/'link-plan.json',plan);arms[arm]=dict(plan=b.identity(out/'link-plan.json'),image=str(image),main=main['source'],main_object=main['object'])
notes=['model_ops.h old8b863→current differs only sharedA explanatory comments; exact diff retained.','resource_episode.h/input_sources.h/region_access.h differences only declarations and comments; behavior owners4are fresh current. No public object or PlanState layout change.','batch_ops.h comments and batch_layout.h extra overload declaration only. compute_batch actual behavior4owners already current from family base.','ggml_cuda program.h adds supports_bfloat_paired_projection declaration only; retained tensor_program source unchanged.','constant_artifact.cc current only adds explicit .queue={} GNU aggregate initialization; exact source diff proof retained under linux-layout-current-review. No recompile for equal existing default initialization.','Older native/SDK/generated owners retained from actual green closure; no full SDK rebuild or automatic recompilation on unrelated declaration/comment/source-metadata changes. Broad dependency hashes not all current; compatibility exceptions explicitly retained with bounded execution validation.']
c.save(O/'link-assembly.json',dict(replacements=records,replacement_count=len(records),common_inputs=common,common_inputs_count=len(common),arms=arms,compatibility_notes=notes,inventory=b.identity(O/'closure-inventory.json'),declaration_diffs=b.identity(O/'declaration-diffs.json'),compile_processes_this_stage=2,links_yet=0,GPU_runs_yet=0))
print(json.dumps({'replacement_count':len(records),'shared_inputs':len(common),'arm_plans':arms},indent=2))
for row in records:print(row['source'],'=>',row['selected']['path'])
