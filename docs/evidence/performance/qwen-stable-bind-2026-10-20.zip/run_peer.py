from pathlib import Path
import importlib.util,sys,statistics,re,traceback
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent;A=S.parent;O=S/'peer-window';O.mkdir(exist_ok=False);(O/'tmp').mkdir()
spec=importlib.util.spec_from_file_location('stable_bind_peer_run_helpers',A/'qwen-finite-family/compare.py');h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h);b,c,r=h.b,h.c,h.r
p=S/'peer-prepared/plan.json';plan=c.read(p);assert plan['status']=='prepared_not_run';link=c.read(plan['common_plan']['path']);env,runtime=b.environment(link['command'],[x['path']for x in link['inputs']]+[x['path']for x in plan['peer_inputs']],O)
for key in r.FORBIDDEN_ENV:assert key not in env,key
for row in [*plan['images'].values(),*link['inputs'],*plan['peer_inputs']]:r.require_same(row)
c.save(O/'inputs.json',dict(plan=b.identity(p),images=plan['images'],order=plan['order'],fixed=plan['fixed'],runtime=runtime,source_freeze=plan['source_freeze'],common_plan=plan['common_plan'],peer_plan=plan['peer_plan'],profiler=False,external_memory_monitor=False,compiles=0,links=0))
runs=[]
try:
 for req in plan['requests']:
  for row in plan['images'].values():r.require_same(row)
  command=[arg.replace('{output}',str(O))for arg in req['command']];process=r.execute(req['tag'],command,env,O)
  obs=r.peer_result(O/(req['tag']+'-peer-result.json'),plan)if req['arm']=='llama'else r.hyle_result(O,req,plan)
  if req['arm']=='current':
   assert obs['capture_counts']==[[1,0]]*3+[[0,1]]*29
   text=(O/(req['tag']+'.stderr.log')).read_text();cold=[float(x)for x in re.findall(r'prepared T=1 visible=\d+ replay=\w+ cold_batch_seconds=([0-9.e+-]+)',text)][6:];obs['warm_cold_batch_seconds']=sum(cold);obs['warm_cold_batch_median_seconds']=statistics.median(cold)
  runs.append(dict(arm=req['arm'],tag=req['tag'],pid=process['pid'],exit=process['exit'],command=command,process_wall_seconds=process['finished']-process['started'],**obs));c.save(O/'runs.json',runs)
 groups={arm:{k:dict(samples=[x['metrics'][k]for x in runs if x['arm']==arm],median=statistics.median(x['metrics'][k]for x in runs if x['arm']==arm),min=min(x['metrics'][k]for x in runs if x['arm']==arm),max=max(x['metrics'][k]for x in runs if x['arm']==arm))for k in r.COMMON_METRICS}for arm in ['current','llama']}
 summary=dict(status='six_fresh_unprofiled_processes_terminal_zero',terminal_zero=6,order=plan['order'],images=plan['images'],groups=groups,current_over_llama={k:groups['current'][k]['median']/groups['llama'][k]['median']for k in r.COMMON_METRICS},same_baseline_predictions_all6=all(x['same_baseline_predictions']for x in runs),predictions_deterministic_within_each_arm=all(len({tuple(x['generated_ids'])for x in runs if x['arm']==arm})==1for arm in groups),capture_results={arm:[x['capture_counts']for x in runs if x['arm']==arm]for arm in groups},metric_contract=plan['metric_contract'],profiler=False,external_memory_monitor=False,statistical_significance=False,independent_quality_acceptance=False,causal_performance_attribution=False,limits=plan['limits'],bind_ab_not_pooled=plan['bind_ab'])
 c.save(O/'summary.json',summary);print('SIX_PROCESS_PEER_WINDOW_COMPLETE')
except Exception as exc:
 c.save(O/'failure.json',dict(error=repr(exc),terminal_zero=len(runs),runs=runs,traceback=traceback.format_exc()));raise
