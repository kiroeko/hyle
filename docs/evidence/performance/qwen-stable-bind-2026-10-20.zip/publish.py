from pathlib import Path
import hashlib,json,zipfile,datetime
S=Path(__file__).resolve().parent;R=S.parents[2]
def read(p):return json.loads(Path(p).read_text(encoding='utf-8'))
def save(p,x):Path(p).write_text(json.dumps(x,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
def identity(p):
 p=Path(p).resolve();h=hashlib.sha256()
 with p.open('rb') as f:
  for data in iter(lambda:f.read(8<<20),b''):h.update(data)
 return dict(path=str(p),bytes=p.stat().st_size,sha256=h.hexdigest())
def equal(row):return identity(row['path'])==row
def interval(folder,first,last):
 tz=datetime.timezone(datetime.timedelta(hours=8));return dict(start=datetime.datetime.fromtimestamp(read(folder/first)['started'],tz).isoformat(),finish=datetime.datetime.fromtimestamp(read(folder/last)['finished'],tz).isoformat(),timezone='Asia/Shanghai')
def payload(p):
 rel=p.relative_to(S)
 if set(rel.parts)&{'tmp','__pycache__'}:return False
 if p.name in {'publication.json','payload-sha256.json'}:return False
 return p.suffix.lower() in {'.cc','.h','.py','.json','.diff','.log','.xml','.tsv','.ids','.md','.txt'}
final=read(S/'final-validation.json');peer_receipt=read(S/'peer-window/receipt.json');ab=read(S/'timing/summary.json');peer=read(S/'peer-window/summary.json');phase=read(S/'peer-window/phase-decomposition.json');vectors=read(S/'correctness/vector-hash-proof.json');assembly=read(S/'ab/link-assembly.json')
assert final['actual_process_totals']['model_exit0']==6 and ab['terminal_zero']==4 and peer['terminal_zero']==6 and vectors['count']==64
assert equal(final['current_source']) and (R/'tools/qwen35_text/main.cc').read_bytes()==(S/'source/tools/qwen35_text/main.cc').read_bytes()
for arm in ['before','current']:
 for row in read(S/'ab'/arm/'link-plan.json')['inputs']:assert equal(row),row['path']
 assert equal(read(S/'ab'/arm/'image.json'))
for row in read(S/'peer-prepared/plan.json')['images'].values():assert equal(row)
for row in vectors['rows']:
 for key in ['before','current','canonical_existing_reference']:assert equal(row[key])
# All64raw before/current vectors are already represented by canonical hashes.
# Do not copy raw vectors, executables, objects, libraries, SDK or full maps.
dest=R/'docs/evidence/performance/qwen-stable-bind-2026-10-20.zip';dest.parent.mkdir(parents=True,exist_ok=True)
files=sorted([p for p in S.rglob('*') if p.is_file() and payload(p)],key=lambda p:p.relative_to(S).as_posix());members=[]
with zipfile.ZipFile(dest,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p in files:
  member=p.relative_to(S).as_posix();assert not member.startswith('/') and '..' not in Path(member).parts
  row=dict(member=member,**identity(p));members.append(row);z.writestr(member,p.read_bytes())
 z.writestr('payload-sha256.json',json.dumps(members,indent=2,ensure_ascii=False).encode('utf-8'))
with zipfile.ZipFile(dest) as z:
 assert z.testzip() is None
 for row in members:assert hashlib.sha256(z.read(row['member'])).hexdigest()==row['sha256'],row['member']
 assert len(z.namelist())==len(members)+1
 assert not any(Path(n).suffix.lower() in {'.exe','.obj','.lib','.exp','.map','.pdb','.bf16','.f32'} for n in z.namelist())
metric_keys=['full31_tokens_per_second','warm7_31_tokens_per_second','prefill_tokens_per_second','ttft_seconds','startup_to_ready_seconds','load_seconds','prepare_seconds']
phase_compact={arm:{group:values for group,values in groups.items()}for arm,groups in phase['group_medians'].items()}
report=dict(date='2026-10-20',status='consumer_binding_simplified_and_two_independent_windows_retained',change=dict(source=final['current_source'],before=final['before_source'],diff=final['source_diff'],ordinary_binds_per_slot_initialized_cold=101,ordinary_hot_binds=0,reason='Caller bindings now naturally survive batch configuration changes. Initialize fixed exact-child/parity mappings at slot creation; update contents and metadata during inference.',unchanged='Original public batch preparation, replay, submit/wait, result/lifetime guards and model arithmetic. No precision/provider policy, new executor/cache or public interface.',performance_claim='No throughput improvement established. Keep as consumer/API clarity simplification; the bind-only window measured a small negative result.'),
 same_core=dict(common_inputs=149,only_main_diff_between_bind_arms=True,old_qwen_replacements=13,assembly=identity(S/'ab/link-assembly.json'),current_link_plan=identity(S/'ab/current/link-plan.json'),before_link_plan=identity(S/'ab/before/link-plan.json'),header_compatibility=identity(S/'compatibility/headers/index.json'),notes=assembly['compatibility_notes'],limits='Actual selected objects/libraries checked; shared ABI/behavior owners refreshed. Historical declaration/comment-only source metadata differences retained explicitly, not claimed all-tree source-hash freshness.'),
 exact_checks=dict(processes=2,all_exit0=True,before_equal_to_original64=True,current_equal_to_original64=True,before_current_pairwise_equal64=True,vector_hash_proof=identity(S/'correctness/vector-hash-proof.json'),regression=identity(S/'correctness/summary.json'),raw_vectors='Duplicate canonical original64 omitted; per-vector byte/hash equality and prior qwen-finite-family evidence references are in the archive. No new independent quality oracle.',not_run='No new23/4/1scheduler continuation, failure injection, other platform/full-model run in this batch.'),
 bind_only_window=dict(interval=interval(S/'timing','01-before.result.json','04-before.result.json'),receipt=identity(S/'final-validation.json'),raw_summary=identity(S/'timing/summary.json'),order=['before','current','current','before'],fresh_processes=4,all_exit0=True,groups=ab['groups'],current_over_before=ab['current_over_before'],conclusion='No measured improvement. Warm medians106.8397→105.6560tokens/s(-1.11%); full31-0.70%; whole cold preparation also did not decrease. Two samples/arm, no significance or stable regression conclusion.'),
 latest_peer_window=dict(interval=interval(S/'peer-window','01-current.result.json','06-llama.result.json'),receipt=identity(S/'peer-window/receipt.json'),raw_summary=identity(S/'peer-window/summary.json'),order=peer['order'],fresh_processes=6,all_exit0=True,groups={k:peer['groups'][k]for k in ['current','llama']},current_over_llama=peer['current_over_llama'],same_predictions_all6=peer['same_baseline_predictions_all6'],predictions_deterministic_within_arms=peer['predictions_deterministic_within_each_arm'],observed=dict(full31_tokens_per_second='Hyle92.4443/llama96.7892',warm7_31_tokens_per_second='Hyle96.0448/llama97.7765',prefill_tokens_per_second='Hyle2030.6211/llama1261.5859',TTFT_seconds='Hyle1.34885/llama1.9417832'),causal_claim=False),
 phase_decomposition=dict(source=identity(S/'peer-window/phase-decomposition.json'),read_only_existing_data=True,new_GPU_runs=0,definition='First6=decode1..6, later25=decode7..31; prefill excluded.',medians=phase_compact,first_decode_clue='First2step sums: Hyle33.4210ms/peer24.1984ms. Hyle first2cold_batch sums per process9.4738/13.7807/10.4243ms, and those2phases first record each parity slot. Later25cold_batch median sums4.5089ms. Initial preparation/recording is a concrete cost location; this is not proof that pure CUDA capture alone causes the gap.',first6_and_later25='Step-sum medians: first6Hyle75.0417ms/peer67.2758ms; later25Hyle260.2952ms/peer255.6852ms.',boundaries=phase['interpretation']),
 actual_process_totals=dict(CXX=2,NVCC=0,links=2,model_correctness=2,bind_timing=4,peer_timing=6,all_model_exit0=12,SDK_rebuild=0,profiler=0,external_memory_monitor=0),
 limits=peer['limits']+['The bind-only and peer windows are independent and never pooled. Do not attribute cross-window absolute rates or the older12:16window differences to this change.','Model weights are the frozen BF16 provenance; Hyle BF16 boundaries/F32accum and peer F32 activation/output intermediates differ. This is a consumer comparison, not bit-identical engine math.','Fixed teacher-forced decode input sequence does not depend on reported predictions. Matching IDs is regression evidence, not independent model-quality acceptance.','Peer reads248320F32logits per phase; Hyle reads4BselectedID. Loading/preparation subtimers and graph-maintenance placement differ; broader startup/TTFT observations remain explicit.','First-decode preparation is included in full31 and TTFT where it actually occurs. Moving this interval outside a timer is not a performance optimization.','Only the requested bounded windows ran. No reversed/extra window, profiler, memory/power side sampler or causal attribution.'],
 archive=dict(**identity(dest),payloads=len(members),manifest_member='payload-sha256.json',CRC_checked=True,all_payload_SHA256_checked=True,excluded='Executables, objects, libraries, SDK, full link maps and duplicate raw vectors.'))
report_path=dest.with_suffix('.json');save(report_path,report);save(S/'publication.json',dict(report=identity(report_path),archive=identity(dest),payloads=len(members),passed=True,scope='Only new evidence JSON/ZIP; no other docs or cleanup.'))
print(json.dumps(dict(report=identity(report_path),archive=identity(dest),payloads=len(members)),indent=2))
