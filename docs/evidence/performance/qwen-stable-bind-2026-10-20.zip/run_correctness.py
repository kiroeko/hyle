from pathlib import Path
import importlib.util,sys,json
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent;A=S.parent;O=S/'correctness';O.mkdir(exist_ok=True);(O/'tmp').mkdir(exist_ok=True)
def load(name,p):
 spec=importlib.util.spec_from_file_location(name,p);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
h=load('stable_bind_correct_helpers',A/'grouped-shared-activation/build_host.py');b,c=h.b,h.c;n=load('stable_bind_correct_numerics',A/'cuda-bf16-dual-projection/compare_numerics.py')
ref=A/'batch-graph-capture/correctness-final';vectors={p.relative_to(ref/'trace'):n.identity(p)for p in sorted((ref/'trace').rglob('*'))if p.suffix in('.bf16','.f32')};assert len(vectors)==64
ref_result=n.final_json(ref/'qwen.stdout.log');command=c.read(ref/'qwen.command.json')['command'];results=[]
for arm in ['before','current']:
 out=O/arm;out.mkdir(exist_ok=True);(out/'tmp').mkdir(exist_ok=True);link=c.read(S/'ab'/arm/'link-plan.json');image=c.read(S/'ab'/arm/'image.json');assert h.same_identity(image)
 for row in link['inputs']:assert h.same_identity(row),row['path']
 cmd=command.copy();cmd[0]=image['path'];cmd[cmd.index('--trace')+1]=str(out/'trace')
 env,runtime=b.environment(link['command'],[row['path']for row in link['inputs']],out);c.save(out/'inputs.json',dict(image=image,command=cmd,link_plan=b.identity(S/'ab'/arm/'link-plan.json'),reference_vectors=list(vectors.values()),runtime=runtime,profiler=False,external_memory_monitor=False));c.execute('qwen',cmd,env,out)
 obs=n.analyze_arm(arm,image,out,vectors,ref_result);assert obs['equal_vectors']==64 and obs['all_outputs_finite'] and obs['same_greedy_ids_as_reference'] and obs['same_fixed_decode_inputs'],(arm,obs['equal_vectors'])
 assert len(obs['capture_counts'])==32 and all(row['recorded']+row['reused']==1 for row in obs['capture_counts'])
 results.append(dict(arm=arm,exit0=True,equal64=True,greedy_ids=obs['generated_ids'],capture_counts=obs['capture_counts'],analysis=b.identity(out/'analysis.json')))
comparison=[]
for rel in vectors:
 before=n.identity(O/'before/trace'/rel);after=n.identity(O/'current/trace'/rel);assert before['bytes']==after['bytes']and before['sha256']==after['sha256'];comparison.append(dict(path=str(rel),before=before,current=after,byte_equal=True))
c.save(O/'summary.json',dict(passed=True,fresh_processes=2,arms=results,pairwise_equal_vectors=64,pairwise_vectors=comparison,scope='Identical current common closure before/current main; both also match historical64hidden/logit observations. Regression only, no independent model quality/performance claim.'))
print('SAME_CORE_BOTH_EXACT64_GREEN')
