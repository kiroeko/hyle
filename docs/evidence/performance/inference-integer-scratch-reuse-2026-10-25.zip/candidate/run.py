from pathlib import Path
import importlib.util,json,os,datetime
R=Path.cwd();F=R/'.scratch/inference-prepare-scratch-20261025/candidate'
spec=importlib.util.spec_from_file_location('retained',R/'.scratch/mtp-extraction-regression-20261024/check.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
ready=b.read(F/'ready.json');assert b.pin(F/'link/hyle.exe')==ready['image']
for pin in ready['sources']:assert b.pin(Path(pin['path']))==pin
runtime=b.read(R/'.scratch/mtp-performance-convergence-20261025/baseline/runtime.json');env=os.environ.copy();env.update({k:v for k,v in runtime.items()if isinstance(v,str)});env['PATH']=str(F/'link')+';'+env['PATH']
command=b.args(R/'.scratch/mtp-performance-convergence-20261025/current-cuda/mtp-two-turn/command.json');command[0]=str(F/'link/hyle.exe')
b.save(F/'run-inputs.json',dict(manifest=b.pin(R/'.scratch/qwen35-unsloth-mtp-20261024/geometry-v2-check/original/weights.tsv'),schedule=b.pin(Path(command[-1])),runtime=b.pin(R/'.scratch/mtp-performance-convergence-20261025/baseline/runtime.json'),start_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),scope='Only one behavioral verification; no speed conclusion'))
b.execute(command,F/'run1',env,180)
