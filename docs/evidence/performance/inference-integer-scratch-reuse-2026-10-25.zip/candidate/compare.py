from pathlib import Path
import json
R=Path.cwd();W=R/'.scratch/inference-prepare-scratch-20261025';F=W/'candidate'
def report(p):return [json.loads(line)for line in p.read_text().splitlines()if line.startswith('{')][-1]
def normalize(v):
 if isinstance(v,list):return [normalize(x)for x in v]
 if isinstance(v,dict):return {k:normalize(x)for k,x in v.items()if not ('seconds'in k or 'tokens_per_second'in k)}
 return v
actual=normalize(report(F/'run1/stdout.log'))
result={}
for label,path in [('original_prior',R/'.scratch/mtp-performance-convergence-20261025/current-cuda/mtp-two-turn/stdout.log'),('same_frozen_diagnostic',W/'diagnostic/run1/stdout.log')]:
 before=normalize(report(path));removed=sorted(set(before)-set(actual));added=sorted(set(actual)-set(before));changed={k:dict(before=before[k],after=actual[k])for k in before.keys()&actual.keys()if before[k]!=actual[k]}
 result[label]=dict(equal=not removed and not added and not changed,removed=removed,added=added,changed=changed,scope='All report fields recursively excluding seconds/tokens_per_second named timing fields. Includes complete IDs/ledger/session/dispatch/work.')
out=dict(status='PASS'if all(v['equal']for v in result.values())else'FAIL',process=json.loads((F/'run1/process.json').read_text()),comparisons=result,cold_page_id_capacity_executed=True,hot_page_id_reserve_or_resize_calls=0,page_id_count_source='new_refs sum actual page counts before filling; unchanged per-member loop pushes exactly those counts; prior bound rejects capacity overflow before mutation of these ranges.',no_TPS_claim=True)
(F/'comparison.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2));assert out['status']=='PASS'
