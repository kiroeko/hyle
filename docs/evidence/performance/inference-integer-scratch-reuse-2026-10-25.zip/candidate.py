from pathlib import Path
import shutil,difflib,json,hashlib
R=Path.cwd();W=R/'.scratch/inference-prepare-scratch-20261025';F=W/'candidate'
F.mkdir(exist_ok=False);shutil.copytree(R/'.scratch/inference-dual-model-20261025/source',F/'source')
p=F/'source/engine/models/qwen35/main.cc';before=p.read_bytes();s=before.decode()
def change(a,b):
 global s
 assert s.count(a)==1,(a,s.count(a));s=s.replace(a,b)
change('  std::vector<std::uint32_t> sampling_identities;\n  void prepare(const Phase &phase) {',
'''  std::vector<std::uint32_t> sampling_identities;
  // BatchSchema::version synchronously copies this integer source range.
  // Keep page readers, immutable layout versions and NodeLayouts outside scratch.
  std::vector<std::int32_t> target_page_ids;
  void prepare(const Phase &phase) {''')
change('    if (phase.family->requests > 1) reserve(packed_ids, phase.tokens);',
'''    target_page_ids.reserve(phase.attention_schema.capacity().max_page_refs);
    if (phase.family->requests > 1) reserve(packed_ids, phase.tokens);''')
change('    std::vector<std::int32_t> query{0}, old_ptr{0}, next_ptr{0}, old_last, next_last;',
'    hyle::container::SmallVector<std::int32_t, 2> query{0}, old_ptr{0}, next_ptr{0}, old_last, next_last;')
change('    for (auto *table : {&query, &old_ptr, &next_ptr, &old_last, &next_last}) table->reserve(width + 1);',
'''    for (auto *table : {&query, &old_ptr, &next_ptr})
      if (!table->try_reserve(width + 1)) throw std::bad_alloc{};
    for (auto *table : {&old_last, &next_last})
      if (!table->try_reserve(width)) throw std::bad_alloc{};''')
change('    std::vector<std::int32_t> old_query(width + 1, 0);','    std::vector<std::int32_t> old_query(width == 1 ? 0 : width + 1, 0);')
change('      std::vector<std::int32_t> old_ids, new_ids;',
'''      std::vector<std::int32_t> old_ids;
      auto &new_ids = input_scratch.target_page_ids;
      new_ids.clear();''')
change('      new_ids.reserve(new_refs);','''      if (new_refs > new_ids.capacity())
        throw std::runtime_error("target page-index scratch exceeds prepared schema capacity");''')
p.write_bytes(s.encode());(F/'source.patch').write_text(''.join(difflib.unified_diff(before.decode().splitlines(True),s.splitlines(True),fromfile='frozen28875/main.cc',tofile='candidate/main.cc')),encoding='utf8')
(F/'consumer.cc').write_text('#include "source/engine/models/qwen35/main.cc"\nint main(int argc,char **argv){return qwen35::run(argc,argv);}\n',encoding='utf8')
(F/'source-pins.json').write_text(json.dumps([dict(path=str(x.relative_to(F)),bytes=x.stat().st_size,sha256=hashlib.sha256(x.read_bytes()).hexdigest())for x in (F/'source').rglob('*')if x.is_file()],indent=2)+'\n')
# Reuse the identical successful retained one-TU recipe, changing only output folder.
build=(W/'build.py').read_text().replace("F=W/'diagnostic'","F=W/'candidate'")
assert build!=(W/'build.py').read_text();(F/'build.py').write_text(build)
print('candidate private diff ready')
