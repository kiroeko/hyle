from pathlib import Path
import json,re,statistics,hashlib
R=Path.cwd();W=R/'.scratch/inference-prepare-scratch-20261025';F=W/'diagnostic'
records=[]
for line in (F/'run1/stderr.log').read_text().splitlines():
 if line.startswith('PREP_INTEGER_SAMPLE '):records.append({k:int(v)for k,v in re.findall(r'(\w+)=(-?\d+)',line)})
summary={}
for kind,label in [(0,'target'),(1,'draft')]:
 rows=[x for x in records if x['kind']==kind]
 summary[label]=dict(calls=len(rows),widths=sorted(set(x['width']for x in rows)),rows=sorted(set(x['rows']for x in rows)),roles={str(role):sum(x['role']==role for x in rows)for role in sorted(set(x['role']for x in rows))},totals={k:sum(x[k]for x in rows)for k in ['init_allocs','init_bytes','reserve_growths','reserve_bytes','old_query_bytes','init_ns','reserve_ns','old_query_ns']},timed_ns_median={k:statistics.median(x[k]for x in rows)for k in ['init_ns','reserve_ns','old_query_ns']},new_refs_range=[min(x['new_refs']for x in rows),max(x['new_refs']for x in rows)])
def reports(p):return [json.loads(line)for line in p.read_text().splitlines()if line.startswith('{')]
before=reports(R/'.scratch/mtp-performance-convergence-20261025/current-cuda/mtp-two-turn/stdout.log')[-1];after=reports(F/'run1/stdout.log')[-1]
keys=['source_id','text_tensors','mtp_tensors','generated_tokens','generated_decode_tokens','actual_graph_calls','prefill_graph_calls','decode_graph_calls','actual_target_rows','committed_target_rows','actual_draft_rows','draft_rounds','agreements','consumed_drafts','dispatch','batches','sessions']
def normalize(v):
 if isinstance(v,list):return [normalize(x)for x in v]
 if isinstance(v,dict):return {k:normalize(x)for k,x in v.items()if not ('seconds'in k or 'tokens_per_second'in k)}
 return v
comparison={k:dict(equal=normalize(before.get(k))==normalize(after.get(k)),before=normalize(before.get(k)),after=normalize(after.get(k)))for k in keys}
out=dict(status='DIAGNOSTIC_COMPLETED',process=json.loads((F/'run1/process.json').read_text()),scope='One instrumented MTP K1 real two-turn process, frozen28875 source and original cached BF16 inputs. Not performance benchmark. Requested capacities are not heap allocation size, peak bytes, or all metadata costs. Timings include clocks and exclude destructors; new_ids is a subset.',summary=summary,work_comparison={k:v for k,v in comparison.items()if k not in ['sessions','batches','dispatch']},structured_output_equal={k:comparison[k]['equal']for k in ['sessions','batches','dispatch']},overflow=next(line for line in (F/'run1/stderr.log').read_text().splitlines()if line.startswith('PREP_INTEGER_DIAG')),observations=records)
(W/'diagnostic-summary.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({k:v for k,v in out.items()if k not in ['observations','work_comparison']},indent=2))
print('non_time_critical_work',all(v['equal']for v in comparison.values()))
