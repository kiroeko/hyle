from pathlib import Path
import hashlib, json, shutil, difflib
R=Path.cwd(); W=R/'.scratch/inference-prepare-scratch-20261025'; F=W/'diagnostic'
F.mkdir(exist_ok=False); old=R/'.scratch/inference-dual-model-20261025/source'
shutil.copytree(old,F/'source')
p=F/'source/engine/models/qwen35/main.cc'; before=p.read_bytes(); s=before.decode('utf-8')
def change(a,b):
 global s
 assert s.count(a)==1,(a,s.count(a));s=s.replace(a,b)
change('    std::vector<std::int32_t> query{0}, old_ptr{0}, next_ptr{0}, old_last, next_last;',
'''    auto &integer_diag = prep_diag::begin(1, static_cast<unsigned>(role), width, rows);
    const auto integer_diag_begin = prep_diag::Clock::now();
    std::vector<std::int32_t> query{0}, old_ptr{0}, next_ptr{0}, old_last, next_last;
    integer_diag.init_ns = prep_diag::ns(integer_diag_begin);
    for (const auto *table : {&query, &old_ptr, &next_ptr, &old_last, &next_last})
      if (table->capacity()) { ++integer_diag.init_allocs; integer_diag.init_bytes += table->capacity()*sizeof(std::int32_t); }''')
change('    for (auto *table : {&query, &old_ptr, &next_ptr, &old_last, &next_last}) table->reserve(width + 1);',
'''    for (auto *table : {&query, &old_ptr, &next_ptr, &old_last, &next_last})
      prep_diag::reserve(integer_diag, *table, width + 1);''')
change('    old_ids.reserve(old_count); next_ids.reserve(next_count);',
'''    prep_diag::reserve(integer_diag, old_ids, old_count);
    prep_diag::reserve(integer_diag, next_ids, next_count);
    integer_diag.old_refs = old_count; integer_diag.new_refs = next_count;''')
change('    std::vector<std::int32_t> old_query(width + 1, 0);',
'''    const auto old_query_begin = prep_diag::Clock::now();
    std::vector<std::int32_t> old_query(width + 1, 0);
    integer_diag.old_query_ns = prep_diag::ns(old_query_begin);
    integer_diag.old_query_bytes = old_query.capacity()*sizeof(std::int32_t);''')
change('      if (width != 1) old_ids.reserve(old_refs);\n      new_ids.reserve(new_refs);',
'''      auto &integer_diag = prep_diag::begin(0, static_cast<unsigned>(role), width, tokens);
      integer_diag.old_refs = old_refs; integer_diag.new_refs = new_refs;
      if (width != 1) prep_diag::reserve(integer_diag, old_ids, old_refs);
      prep_diag::reserve(integer_diag, new_ids, new_refs);''')
p.write_bytes(s.encode('utf-8'))
(F/'source.patch').write_text(''.join(difflib.unified_diff(before.decode().splitlines(True),s.splitlines(True),fromfile='frozen-28875/main.cc',tofile='diagnostic/main.cc')),encoding='utf8')
(F/'diag.h').write_text(r'''#pragma once
#include <array>
#include <chrono>
#include <cstdio>
#include <cstdint>
#include <vector>
namespace prep_diag {
using Clock=std::chrono::steady_clock;
struct Sample { unsigned kind=0,role=0; std::size_t width=0,rows=0,init_allocs=0,init_bytes=0,reserve_growths=0,reserve_bytes=0,old_query_bytes=0,old_refs=0,new_refs=0; std::int64_t init_ns=0,reserve_ns=0,old_query_ns=0; };
inline std::array<Sample,2048> samples{};
inline std::size_t count=0,overflow=0;
inline Sample sink{};
inline Sample &begin(unsigned kind,unsigned role,std::size_t width,std::size_t rows) { if(count==samples.size()){++overflow;return sink;} auto &v=samples[count++];v.kind=kind;v.role=role;v.width=width;v.rows=rows;return v; }
inline std::int64_t ns(Clock::time_point start){return std::chrono::duration_cast<std::chrono::nanoseconds>(Clock::now()-start).count();}
inline void reserve(Sample &v,std::vector<std::int32_t> &a,std::size_t n){const auto capacity=a.capacity();const auto start=Clock::now();a.reserve(n);v.reserve_ns+=ns(start);if(a.capacity()!=capacity){++v.reserve_growths;v.reserve_bytes+=a.capacity()*sizeof(std::int32_t);}}
inline void dump() { std::fprintf(stderr,"PREP_INTEGER_DIAG count=%zu overflow=%zu\n",count,overflow);for(std::size_t j=0;j<count;++j){const auto &v=samples[j];std::fprintf(stderr,"PREP_INTEGER_SAMPLE index=%zu kind=%u role=%u width=%zu rows=%zu init_allocs=%zu init_bytes=%zu reserve_growths=%zu reserve_bytes=%zu old_query_bytes=%zu old_refs=%zu new_refs=%zu init_ns=%lld reserve_ns=%lld old_query_ns=%lld\n",j,v.kind,v.role,v.width,v.rows,v.init_allocs,v.init_bytes,v.reserve_growths,v.reserve_bytes,v.old_query_bytes,v.old_refs,v.new_refs,static_cast<long long>(v.init_ns),static_cast<long long>(v.reserve_ns),static_cast<long long>(v.old_query_ns));}}
}
''',encoding='utf8')
(F/'consumer.cc').write_text('#include "diag.h"\n#include "source/engine/models/qwen35/main.cc"\nint main(int argc,char **argv){const int code=qwen35::run(argc,argv);prep_diag::dump();return code;}\n',encoding='utf8')
pins=[dict(path=str(x.relative_to(F)),bytes=x.stat().st_size,sha256=hashlib.sha256(x.read_bytes()).hexdigest())for x in (F/'source').rglob('*')if x.is_file()]
(F/'source-pins.json').write_text(json.dumps(pins,indent=2)+'\n')
(W/'plan.json').write_text(json.dumps(dict(frozen_main_sha256=hashlib.sha256(before).hexdigest(),source_scope='28875 BF16 source; canonical NF4 main untouched',instrumentation='Fixed POD array2048, no hot allocation. Vector init/reserve nanoseconds include clock overhead, exclude destruction, and cannot explain total host gap. Dumps only after qwen35::run returns.',processes=1,command_source='.scratch/mtp-performance-convergence-20261025/current-cuda/mtp-two-turn/command.json',mode='MTP real2turn greedy K1, original argv except image',math_graph_IO_unchanged=True),indent=2)+'\n')
print('prepared',len(pins),'frozen files')
