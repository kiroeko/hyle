# 计时端点与 eager/capture 公平性窄审

只读现有源码、无插桩12进程两轮报告和既有四臂trace；无GPU／构建／HTTP／产品改动。复算：`python .scratch/mtp-performance-convergence-20261025/endpoint-fairness/analyze.py`。

**未发现 peer 排除了真实 warmup，不能据首24 captured 的差值解释全程剩余差距。**

- 固定 peer_multiturn.cc:114–119 的 decode 包含 llama_decode 与 llama_synchronize。:294 ready 在创建模型／上下文之后；:332 开始真实prefill，:376 进入decode，:430 才结束decode。没有额外warmup调用。llama-context.cpp:122 默认warmup=false。
- 所链接native源码 ggml-cuda.cu:4483–4501 的“warmup”是每个真实graph-key先eager，第二次属性不变才capture；这些调用都在上述真实prefill/decode里，并非被扔掉的预跑。
- Hyle冻结9b73 main:5386–5419在ready前准备Family／Phase／Invocation，:3258 initialize_slot仅创建／绑定，不submit。真实layout/replay/capture/instantiate仍由第一轮调用触发。两者初始冷准备政策不同，完整startup不能当完全同工作，但这不构成peer暗排warmup。
- Hyle:4056在真实输出读回、完整state/ledger发布、旧episode detach之后取endpoint，formatter在其后。:5419/5505聚合从前一endpoint到下一endpoint的连续不重叠区间，因而前一步后置IO计入下一步，最终tail另列post_endpoint。
- peer:332续轮prefill起点沿用前一turn endpoint，包含续轮输入／报告构造；:420逐round内部end在JSON追加前，:430整体endpoint在追加后。最终小tail口径仍非逐字相同，不能把两边逐round秒数当同一GPU指标。

| 无插桩两轮，各臂3次中位数 | Hyle ordinary | peer ordinary | Hyle MTP | peer MTP |
|---|---:|---:|---:|---:|
| 全decode ms（126个输出） |1303.347|1237.912|1014.980|899.352|
| 首decode内部episode/round ms |15.492|12.324|23.192|23.820|
| 第二turn首decode内部ms |13.374|11.791|19.936|16.625|
| decode减其自身内部区间之和ms |21.927|1.885|12.043|1.131|

最后一行逐个原进程先计算再取中位数，非相减中位数。它含已声明的IO／轮间构造／验证等外部区间，内部测量边界有差异，不是“纯CPU差距”、可回收时间或formatter成本。首decode结果也不能证明整个冷期相等：Hyle之后仍有别的role/slot首次record。详细原日志pins和最初4个record episode在JSON。

**实际工作边界：**ordinary两边均309行prefill、126次T1 decode、提交435行。MTP Hyle66次T2/132验证行、60accepted；peer65次target、64proposals、129验证行、61accepted（含1次T1单行尾部）；总draft行434/435、两边输出128/提交435。已知存在自然接受结果带来的额外target工作，不能把65／66或129／132当相同成本，也不能凭一个median给这些多出行精确扣时。BF16中间值对peer F32树的精度差异保留，不据此改数学。

**同一既有trace内的warm结构：**末24 captured envelope两边均24target+23draft，Hyle span/busy/空档352.917/322.632/30.285ms，peer348.897/316.169/32.728ms；这不是整decode，也不与上表相减。按已纠正的同末24 target分组，两个正文投影组平均6.665/6.470ms，target busy平均10.800/10.495ms；warm正文余差仍存在，不能全说成首次实例化。此处沿用body-cost-breakdown/result.json，未重用较早不同窗口的6.734/6.387数值。

**首captured边界不齐：**peer普通此前已真实做1次eager decode；peer MTP已做1次target和2次draft。总uncaptured decode target/draft是ordinary2/0、MTP3/11；其活动已计入原trace。Hyle target/draft分别全126/0和66/66有captured表示。不能从首24图推出对齐的首24请求。

既有Hyle MTP API表记录19次Instantiate/22.441ms和13次Update/1.657ms、返回码均0；输出UpdateResult和driver表缺失，仍未知。API可能与原生工作重叠，不从decode或kernel时间扣掉；也不与另一个POD进程的seed13强配对。

可分的是：源级端点范围、真实行／acceptance工作、首capture前eager事实、同窗warm结构，以及本进程内部/外部区间。**无法从现数据精确加和成“工作差异+冷instantiate+warm body+host=115.6ms”**：缺少对齐的原逻辑call到GPU/CPU事件标记，且trace不是无插桩12窗。没有新的已证实错误或实现候选；不建议为公平性修补而迁移计时／预热端点。未来若另有具体冷准备根因，需单独验证，而非从本表承诺收益。
