#include "diag.h"
#include "source/engine/models/qwen35/main.cc"
int main(int argc,char **argv){const int code=qwen35::run(argc,argv);prep_diag::dump();return code;}
