#pragma once
#include <array>
#include <chrono>
#include <cstdio>
#include <cstdint>
#include <vector>
namespace prep_diag {
using Clock=std::chrono::steady_clock;
struct Sample { unsigned kind=0,role=0; std::size_t width=0,rows=0,init_allocs=0,init_bytes=0,reserve_growths=0,reserve_bytes=0,old_query_bytes=0,old_refs=0,new_refs=0; std::int64_t init_ns=0,reserve_ns=0,old_query_ns=0; };
inline std::array<Sample,2048> samples{};
inline std::size_t count=0,overflow=0;
inline Sample sink{};
inline Sample &begin(unsigned kind,unsigned role,std::size_t width,std::size_t rows) { if(count==samples.size()){++overflow;return sink;} auto &v=samples[count++];v.kind=kind;v.role=role;v.width=width;v.rows=rows;return v; }
inline std::int64_t ns(Clock::time_point start){return std::chrono::duration_cast<std::chrono::nanoseconds>(Clock::now()-start).count();}
inline void reserve(Sample &v,std::vector<std::int32_t> &a,std::size_t n){const auto capacity=a.capacity();const auto start=Clock::now();a.reserve(n);v.reserve_ns+=ns(start);if(a.capacity()!=capacity){++v.reserve_growths;v.reserve_bytes+=a.capacity()*sizeof(std::int32_t);}}
inline void dump() { std::fprintf(stderr,"PREP_INTEGER_DIAG count=%zu overflow=%zu\n",count,overflow);for(std::size_t j=0;j<count;++j){const auto &v=samples[j];std::fprintf(stderr,"PREP_INTEGER_SAMPLE index=%zu kind=%u role=%u width=%zu rows=%zu init_allocs=%zu init_bytes=%zu reserve_growths=%zu reserve_bytes=%zu old_query_bytes=%zu old_refs=%zu new_refs=%zu init_ns=%lld reserve_ns=%lld old_query_ns=%lld\n",j,v.kind,v.role,v.width,v.rows,v.init_allocs,v.init_bytes,v.reserve_growths,v.reserve_bytes,v.old_query_bytes,v.old_refs,v.new_refs,static_cast<long long>(v.init_ns),static_cast<long long>(v.reserve_ns),static_cast<long long>(v.old_query_ns));}}
}
