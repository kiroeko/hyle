from pathlib import Path
import importlib.util,json,os,hashlib,sys
R=Path.cwd(); W=R/'.scratch/inference-prepare-scratch-20261025';F=W/'diagnostic'
spec=importlib.util.spec_from_file_location('retained',R/'.scratch/mtp-extraction-regression-20261024/check.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
old=R/'.scratch/inference-system-review-20261025/schedule-inputs';original=b.args(old/'compile/command.json')
flags=[];skip=False
for a in original[1:]:
 if skip:skip=False;continue
 if a=='/sourceDependencies':skip=True;continue
 if a.lower().startswith(('/fo','/fd'))or a.lower().endswith(('.cc','.cpp')):continue
 flags.append(a)
flags=['/I'+str(F/'source'),'/I'+str(F/'source/engine/models/qwen35'),*flags]
command=[original[0],*flags,str(F/'consumer.cc'),'/sourceDependencies',str(F/'compile/dependencies.json'),'/Fo'+str(F/'compile/unit.obj'),'/Fd'+str(F/'compile/unit.pdb')]
env=b.environment(original[0]);b.execute(command,F/'compile',env,90)
deps=b.read(F/'compile/dependencies.json')['Data'];actual=[]
for n in [deps['Source'],*deps['Includes']]:
 p=Path(n).resolve()
 if p.is_relative_to(R/'engine')or p.is_relative_to(R/'tests'):raise RuntimeError('canonical source leaked '+str(p))
 if p.is_relative_to(R):actual.append(b.pin(p))
b.save(F/'compile/actual-source-pins.json',actual)
link=b.args(old/'link/command.json');args=[];replaced=0
for a in link[1:]:
 if a.lower()==str(old/'compile/unit.obj').lower():args.append(str(F/'compile/unit.obj'));replaced+=1
 elif not a.lower().startswith(('/out:','/pdb:','/map:','/implib:')):args.append(a)
assert replaced==1
b.execute([link[0],*args,'/OUT:'+str(F/'link/hyle.exe'),'/IMPLIB:'+str(F/'link/hyle.lib')],F/'link',env,90)
os.link(old/'link/hyle_ggml_cpu_gdn_scale_v3.dll',F/'link/hyle_ggml_cpu_gdn_scale_v3.dll')
for pin in actual:assert b.pin(Path(pin['path']))==pin
b.save(F/'ready.json',dict(image=b.pin(F/'link/hyle.exe'),sources=actual,SDK_builds=0,HTTP_requests=0))
print('BUILT',flush=True)
