#include "engine/models/qwen35/driver.h"
#include "hyle/compute/cpu.h"
#include "hyle/mem/allocator.h"
#include "hyle/sched/bulk.h"
#include "hyle/sched/scheduler.h"
#include "hyle/sched/waker.h"

#include <cstdio>
#include <cstdlib>

namespace {
namespace c = hyle::compute;
namespace sched = hyle::sched;

void check(hyle::Status status) noexcept {
  if (!status.ok()) {
    const auto text = status.message();
    std::fprintf(stderr, "CPU representative: %.*s\n",
        static_cast<int>(text.size()), text.data());
    std::abort();
  }
}

// The existing package cpu_executor sample's borrowed synchronous adapter.
// The original Scheduler stays open until qwen35::run destroys its artifacts.
struct Executor final {
  sched::Scheduler &scheduler;
  c::ParallelExecutorRef ref() noexcept {
    return {this, scheduler.num_workers(), &parallel_for, &in_parallel};
  }
  static bool in_parallel(void *) noexcept {
    return sched::current_worker_index() >= 0;
  }
  static void parallel_for(void *opaque, std::size_t count,
      c::ParallelTaskFn task, void *context) noexcept {
    auto &self = *static_cast<Executor *>(opaque);
    check(sched::bulk_execute(self.scheduler, 0, count,
        [&](std::size_t begin, std::size_t end) noexcept {
          for (std::size_t index = begin; index < end; ++index)
            task(context, index, count);
        }));
  }
};
const c::cpu::DefaultContextOptions *active_options = nullptr;
} // namespace

namespace qwen35 {
const hyle::compute::cpu::DefaultContextOptions &representative_cpu_options() noexcept {
  if (!active_options) std::abort();
  return *active_options;
}
} // namespace qwen35

int main(int argc, char **argv) {
  constexpr unsigned threads = 4;
  check(c::cpu::configure_runtime_threads(threads));
  sched::SchedulerOptions settings;
  settings.idle_policy = sched::SchedulerIdlePolicy::kPowerSaving;
  hyle::Status status;
  sched::Scheduler scheduler(threads, hyle::mem::system_allocator(), 64, settings, &status);
  check(status);
  Executor executor{scheduler};
  const c::cpu::DefaultContextOptions options{
      .executor = executor.ref(), .native_threads = threads};
  active_options = &options;
  std::fprintf(stderr, "cpu_representative native_threads=4 executor_concurrency=4 aten_intra_op_requested=4\n");
  const int code = qwen35::run(argc, argv);
  active_options = nullptr;
  scheduler.shutdown();
  return code;
}
