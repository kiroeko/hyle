"""Private two-TU shared native CPU team build. No execution action."""
from pathlib import Path
import hashlib, importlib.util, json, os, sys
sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = W.parents[1]
CONTROL = R/'.scratch/inference-cpu-representative-20261026/hyle'
spec = importlib.util.spec_from_file_location('team_host_tools', R/'.scratch/inference-synchronous-step-report-20261025/check_host.py')
h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
def read(p): return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def pin(p):
 p=Path(p).resolve();b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def save(p,v):
 p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((json.dumps(v,indent=2)+'\n').encode())
def key(p): return os.path.normcase(str(Path(p).resolve()))
def env(cmd):
 return h.discover_environment(compiler='msvc',cache={'CMAKE_C_COMPILER':cmd[0],'CMAKE_CXX_COMPILER':cmd[0],'CMAKE_GENERATOR':'Ninja'},backends=()).env
def compile_one(name,recipe,source):
 old=read(recipe)['command'];cmd=[old[0],'/I'+str(W/'source/include'),'/I'+str(W/'source/src/compute_ggml_runtime')];skip=False
 for a in old[1:]:
  if skip:skip=False;continue
  if a.lower()=='/sourcedependencies':skip=True;continue
  if a.lower().startswith(('/fo','/fd')) or a.lower().endswith(('.cc','.cpp')):continue
  cmd.append(a)
 out=W/'build1'/name
 cmd += [str(source),'/sourceDependencies',str(out/'dependencies.json'),'/Fo'+str(out/'unit.obj'),'/Fd'+str(out/'unit.pdb')]
 result=h.execute(cmd,env(cmd),out,timeout=120)
 d=read(out/'dependencies.json')['Data'];deps=[pin(p) for p in dict.fromkeys([d['Source'],*d['Includes']])]
 assert any(key(p['path'])==key(W/'source/src/compute_ggml_runtime/cpu_execution.h') for p in deps)
 save(out/'actual-dependencies.json',deps)
 return dict(result=result,object=pin(out/'unit.obj'),source=pin(source),recipe=pin(recipe),command=pin(out/'command.json'),actual_dependencies=pin(out/'actual-dependencies.json'))
def main():
 for row in read(W/'source-pins.json')['files']:
  assert {k:v for k,v in pin(W/'source'/row['path']).items() if k!='path'}==row['after']
  assert {k:v for k,v in pin(R/row['path']).items() if k!='path'}==row['before']
 results={}
 for name,recipe,rel in [
  ('runtime',R/'.scratch/glm-mlx-flash-original-20261024/gdn-output-scale-validation/foundation1/records/cpu-execution/identity.json','src/compute_ggml_runtime/cpu_execution.cc'),
  ('provider',R/'.scratch/inference-current-closure-20261026/headers79/compute_provider_ggml--ggml_cpu_provider_cc/command.json','src/compute_provider_ggml/ggml_cpu_provider.cc')]:
  results[name]=compile_one(name,recipe,W/'source'/rel);save(W/'build1/compile-summary.json',results)
 old=read(CONTROL/'link/command.json')['command']
 mapping={key(R/'.scratch/glm-mlx-flash-original-20261024/gdn-output-scale-validation/foundation1/cpu-execution.obj'):results['runtime']['object'],key(R/'.scratch/inference-current-closure-20261026/headers79/compute_provider_ggml--ggml_cpu_provider_cc/unit.obj'):results['provider']['object']}
 seen=[];cmd=[];out=W/'build1/link';image=out/'hyle.exe'
 for a in old:
  if a.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:')):continue
  if key(a) in mapping:seen.append(key(a));a=mapping[key(a)]['path']
  cmd.append(a)
 assert set(seen)==set(mapping) and len(seen)==2
 inputs=[]
 for item in read(CONTROL/'link-inputs.json'):
  assert pin(item['path'])==item,item['path']
  inputs.append(mapping.get(key(item['path']),item))
 save(W/'build1/link-inputs.json',inputs)
 cmd+=['/OUT:'+str(image),'/MAP:'+str(image.with_suffix('.map')),'/IMPLIB:'+str(image.with_suffix('.lib'))]
 linked=h.execute(cmd,env(cmd),out,timeout=120)
 runtime=read(CONTROL/'runtime.json');native=Path(runtime['native']['path']);target=out/Path(runtime['native_hardlink']['path']).name
 os.link(native,target);runtime['native_hardlink']=pin(target);save(W/'build1/runtime.json',runtime)
 text=image.with_suffix('.map').read_text(errors='replace')
 assert 'CpuTeam' in text and 'CpuExecution' in text
 ready=dict(status='BUILT_NOT_RUN',image=pin(image),compile=results,link=linked,source_pins=pin(W/'source-pins.json'),patch=pin(W/'source.patch'),link_inputs=pin(W/'build1/link-inputs.json'),runtime=pin(W/'build1/runtime.json'),control=pin(CONTROL/'ready.json'),replacements=[dict(old=k,new=v) for k,v in mapping.items()],model_runs=0,unit_runs=0,GPU_runs=0,SDK_builds=0)
 save(W/'build1/ready.json',ready);print('READY',json.dumps(ready['image']),flush=True)
if __name__=='__main__':main()
