"""Offline publication of the completed entry-only configuration screen."""
from pathlib import Path
import datetime,hashlib,json,zipfile
W=Path(__file__).resolve().parent;B=W.parent;R=B.parents[1];S=W/'screen1'
PUBLIC=R/'docs/evidence/performance/inference-cpu-caller-executor-screen-2026-10-26.json';ZIP=PUBLIC.with_suffix('.zip')
def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def pin(p):
 p=Path(p).resolve();b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def save(p,v):
 p=Path(p);p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((json.dumps(v,indent=2,allow_nan=False)+'\n').encode())
def norm(x):
 if isinstance(x,dict):return {k:norm(v) for k,v in x.items() if k not in {'seconds','unix_ms','unix_ns','clock_unix'} and not k.endswith('_seconds') and not k.endswith('tokens_per_second')}
 return [norm(v) for v in x] if isinstance(x,list) else x
final=read(S/'final-summary.json');summary=read(S/'summary.json');rows=read(S/'runs.json');plan=read(S/'plan.json');ready=read(W/'ready.json');source=read(W/'source-pins.json')
assert final['status']=='FRESH_CONFIG_WINDOW_WORK_PASS_POSITIVE_DECODE_SIGNAL_STOPPED'
assert len(rows)==8 and summary['work_all_passed'] and not (S/'failure.json').exists()
assert [(x['mode'],x['arm']) for x in rows]==[('timing',a) for a in 'HCCHHC']+[('memory','H'),('memory','C')]
for a in ('H','C'):
 for name in ('ready','runtime','image'):
  p=plan['arms'][a][name];assert pin(p['path'])==p
reference=read(B/'poll-default1/behavior1/stdout.log')
for x in rows:
 f=Path(x['folder']);p=read(f/'result.json');assert p['exit']==0 and not p['reader_errors']
 assert norm(read(f/'stdout.log'))==norm(reference)
assert read(W/'behavior1/nontime-diff.json')==[]
assert pin(source['before']['path'])==source['before'] and pin(source['after']['path'])==source['after']
old_inputs=read(B/'poll-default1/link-inputs.json');new_inputs=read(W/'link-inputs.json');assert len(old_inputs)==len(new_inputs)
changes=[dict(before=a,after=b) for a,b in zip(old_inputs,new_inputs) if a!=b]
assert changes==[ready['replacement']]
memory={}
for arm,value in summary['memory'].items():
 m=value['summary'];t=value['threads'];memory[arm]=dict(pid=next(x['process']['pid'] for x in rows if x['mode']=='memory' and x['arm']==arm),sampled_peaks=m['sampled_peaks'],OS_threads=dict(peak=t['peak'],samples=t['count']),memory_samples=m['sample_count'],setup_error=m['setup_error'],thread_error=m['thread_error'],unavailable_reasons=m['unavailable_reasons'],actual_sample_gaps_ms={k:v for k,v in m['actual_sample_gaps_ms'].items() if k!='samples'})
results=dict(status='ALL8_WORK_PASS_FRESH_CONFIG_SIGNAL',timing=final['timing'],comparison=final['comparison'],interleaved_pairs=final['interleaved_pairs'],whole_process_CPU=final['whole_process_CPU'],memory=memory,work=final['work'],processes=[dict(index=x['index'],mode=x['mode'],arm=x['arm'],pid=x['process']['pid'],exit=x['process']['exit'],process_wall_seconds=x['process']['process_wall_seconds']) for x in rows])
report=dict(schema='hyle.cpu-caller-executor-screen.v1',status='USE_CALLER_CONFIGURATION_FOR_THIS_CPU_LATENCY_BASELINE_NO_LIBRARY_CHANGE',generated_UTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),
 scope='One private entry-only configuration comparison: normal poll-default8ebb borrowed executor versus217e empty/caller executor. Six fresh interleaved timing and two independent memory processes; no peer, profiler or pooled old samples.',results=results,
 configuration=dict(control='borrowed Scheduler executor concurrency4',candidate='empty ParallelExecutorRef concurrency1/caller',both=dict(native_threads=4,ATen_intraop_requested=4,Scheduler_workers=4,Scheduler_creation_and_lifetime='unchanged',ggml_pool_poll='default50',budget_and_model_work='unchanged'),
  library_default='DefaultContextOptions.executor was already empty. No library change is needed to select caller execution.',
  adapter_contract='The worker-only borrowed Scheduler adapter is a legitimate business choice. Its sample and external-caller bulk_execute contract remain unchanged.',
  qualification='Executor concurrency4to1 can change generic native/oneDNN parallel_for work partitioning. Native4 and ATen4 do not establish identical provider partitioning or identical algorithms. No pure worker-hop latency is claimed.'),
 decision=dict(status='USE_CALLER_NATIVE4_ATEN4_FOR_FUTURE_COMPARISONS_OF_THIS_LATENCY_WORKLOAD',reason='Decode median improves6.5375% and combined3.3625% with nonoverlapping three-sample ranges in this fresh window. Prefill median+2.6378% has overlapping ranges. The selected configuration uses the existing empty-executor contract; no universal policy/default/custom-executor change.',product_source_changed=False,canonical_entry_changed=False),
 protocol=dict(order='H,C,C,H,H,C timing;H,C separate memory',timing_samples_each=3,memory_processes_each=1,warmups=0,retries=0,watchdog_seconds=180,old_samples_pooled=False,requested=dict(prompt_rows=154,output_limit=16,capacity=256,N=1,R=1,sampling='greedy',MTP=False,prefix_cache='off',replay='commands'),endpoints=final['protocol']['endpoints'],timing_memory_sampling=False,full_non_time_gate='Only original time keys and *_seconds/*tokens_per_second omitted recursively; no other field omitted.'),
 build=dict(control_ready=plan['arms']['H']['ready'],candidate_ready=plan['arms']['C']['ready'],control_image=plan['arms']['H']['image'],candidate_image=plan['arms']['C']['image'],candidate_compile=ready['compile'],candidate_link=ready['link'],source=source,only_object_replacement=changes[0],link_input_count=len(new_inputs),other_link_inputs_identical=True,entry_TUs=1,other_TUs=0,SDK_builds=0,compiler='Retained MSVC14.50 /O2 /MD /W4 /WX flags and actual dependency records',freeze='Original Model/provider/runtime/native closure,normal8ebb. No Graph/native instrumentation image used. Ready statusBUILT_NOT_RUN is its historical creation checkpoint,not a claim later behavior/window was unrun.'),
 first_behavior=read(W/'summary.json'),
 failures=dict(build=0,first_behavior=0,screen_model=0,observer_setup=0,timeouts=0,retries=0,offline_summary=read(S/'offline-first-failure.json')),
 measurement_boundaries=final['limits']+[
  'All timing endpoints include their actual model work. GetProcessTimes after process exit measures whole-process user/kernel time,startup/generation/teardown;not decode-only CPUtime or energy.',
  'Memory and thread sampling occurs only in the independent memory processes. Phase markers are parent stderr receipt times. Full raw samples/phase boundaries are retained;no claimed exact allocator peaks.',
  'No per-run affinity/clock/energy/per-op route/kernel trace was collected. Existing hardware inventory identifies IntelCorei9-13900K24cores/32logical processors.',
  'Only this WindowsCPU N1/R1 greedy workload. No cross-model,multi-request,mixed/GPU/macOS/Linux performance claim. No multiplication into old throughput tables.'
 ],prior_navigation=dict(normal_polling_build_and_window=pin(R/'docs/evidence/performance/inference-cpu-polling-screen-2026-10-26.json')),publication=dict(action='Offline parsing and archive only;no new build/model/network',CPU_released=True))
files={}
def add(name,p):
 p=Path(p);assert p.is_file(),p;assert p.suffix.lower() in {'.json','.py','.patch','.cc','.h','.log','.txt'},p;assert name not in files;files[name]=p
for name in ['source.patch','source-pins.json','source/cpu_entry.cc','build.py','run.py','ready.json','runtime.json','link-inputs.json','summary.json','memo.json','screen.py','screen-plan.json','freeze_screen.py','publish.py']:
 add('candidate/'+name,W/name)
add('reference/cpu_entry.cc',source['before']['path'])
for name in ['ready.json','runtime.json','link-inputs.json']:
 add('reference/'+name,B/'poll-default1'/name)
for name in ['command.json','stdout.log','stderr.log','process.json']:
 add('reference/behavior1/'+name,B/'poll-default1/behavior1'/name)
for folder in ['compile','link','behavior1']:
 for name in ['command.json','process.json','stdout.log','stderr.log','dependencies.json','actual-dependencies.json','nontime-diff.json']:
  p=W/folder/name
  if p.is_file():add('candidate/'+folder+'/'+name,p)
for name in ['plan.json','runs.json','summary.json','final-summary.json','offline-first-failure.json']:
 add('screen/'+name,S/name)
for x in rows:
 f=Path(x['folder'])
 for p in sorted(f.iterdir()):
  if p.is_file():add('screen/'+f.name+'/'+p.name,p)
add('retained-build/check_build.py',B/'check_build.py')
add('retained-build/check_host.py',R/'.scratch/inference-synchronous-step-report-20261025/check_host.py')
for name,key in [('cpu-screen.py','adapter'),('runner.py','runner'),('observer.py','observer'),('sampler.py','sampler')]:
 p=plan[key];assert pin(p['path'])==p;add('retained-sampler/'+name,p['path'])
for name,p in {
 'baseline-window.py':'.scratch/mtp-performance-convergence-20261025/baseline/window.py',
 'window.py':'.scratch/qwen-mtp-window-20261022/window.py',
 'turns.py':'.scratch/qwen-mtp-final-window-20261024/turns.py',
 'performance.py':'.scratch/qwen-mtp-quality-20261022/current-window/performance.py'}.items():add('retained-sampler/'+name,R/p)
save(W/'public-summary.json',report);add('summary.json',W/'public-summary.json')
manifest=[dict(name=n,bytes=p.stat().st_size,sha256=pin(p)['sha256']) for n,p in sorted(files.items())]
save(W/'archive-manifest.json',manifest);add('archive-manifest.json',W/'archive-manifest.json')
ZIP.parent.mkdir(parents=True,exist_ok=True)
with zipfile.ZipFile(ZIP,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name,p in sorted(files.items()):z.writestr(name,p.read_bytes())
with zipfile.ZipFile(ZIP) as z:
 assert z.testzip() is None and len(z.namelist())==len(files)
 for r in manifest:
  data=z.read(r['name']);assert len(data)==r['bytes'] and hashlib.sha256(data).hexdigest()==r['sha256']
report['archive']=dict(**pin(ZIP),members=len(files),CRC_PASS=True,member_SHA256_PASS=True,exclusions='No binary/OBJ/EXE/DLL/LIB/map/SDK/model/full-source tree/old timing samples.')
report['archive']['path']=ZIP.relative_to(R).as_posix();save(PUBLIC,report)
print(json.dumps(dict(report=pin(PUBLIC),archive=report['archive']),indent=2))
