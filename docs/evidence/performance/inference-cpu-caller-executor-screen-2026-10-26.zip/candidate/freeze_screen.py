"""Offline selected facts from exactly the authorized fresh six-plus-two window."""
from pathlib import Path
import hashlib,json,statistics
W=Path(__file__).resolve().parent;S=W/'screen1'
def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def pin(p):
 p=Path(p).resolve();b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def stats(xs):return dict(count=len(xs),min=min(xs) if xs else None,median=statistics.median(xs) if xs else None,max=max(xs) if xs else None)
s=read(S/'summary.json');rows=read(S/'runs.json')
assert s['status']=='COMPLETE' and s['work_all_passed'] and len(rows)==8
assert [(x['mode'],x['arm']) for x in rows]==[('timing',a) for a in ['H','C','C','H','H','C']]+[('memory','H'),('memory','C')]
assert all(x['process']['exit']==0 for x in rows)
pairs=[]
for i in range(0,6,2):
 group=rows[i:i+2];a={x['arm']:x for x in group}
 pairs.append(dict(pair=i//2+1,order=[x['arm'] for x in group],C_vs_H_tps_percent={k:(a['C']['metrics'][k]/a['H']['metrics'][k]-1)*100 for k in s['timing']['H']}))
memory={}
for x in rows[6:]:
 f=Path(x['folder']);m=read(f/'memory-summary.json');t=read(f/'threads.json');assert m['setup_error'] is None and m['thread_error'] is None
 phases={}
 for name,v in m['phase_windows'].items():
  assert not v['missing_boundary'] and not v['ambiguous_boundary'] and not v['invalid_boundary_order']
  counts=[r['threads'] for r in t['samples'] if 'threads' in r and v['begin_ns']<=r['timestamp_ns']<=v['end_ns']]
  phases[name]=dict(memory_samples=v['sample_count'],OS_threads=stats(counts),sampled_phase_peaks={k:y['max'] for k,y in v['values'].items()})
 memory[x['arm']]=dict(pid=x['process']['pid'],sampled_peaks=m['sampled_peaks'],memory_samples=m['sample_count'],OS_threads=dict(peak=t['peak'],samples=t['count']),phases=phases,unavailable_reasons=m['unavailable_reasons'],ready_baseline_unknown=m['ready_baseline']['unknown'],raw=dict(memory=pin(f/'memory.json'),threads=pin(f/'threads.json')))
raw=[]
for x in rows:
 f=Path(x['folder']);err=(f/'stderr.log').read_text();expected='executor_concurrency=4' if x['arm']=='H' else 'executor_concurrency=1 executor=caller scheduler_workers=4'
 assert expected in err
 raw.append(dict(index=x['index'],mode=x['mode'],arm=x['arm'],pid=x['process']['pid'],exit=x['process']['exit'],process_wall_seconds=x['process']['process_wall_seconds'],files=[pin(f/p) for p in ['command.json','result.json','stdout.log','stderr.log','checks.json','process-cpu.json']]))
result=dict(status='FRESH_CONFIG_WINDOW_WORK_PASS_POSITIVE_DECODE_SIGNAL_STOPPED',timing=s['timing'],comparison=s['comparison'],interleaved_pairs=pairs,whole_process_CPU=s['timing_process_CPU'],memory=memory,processes=raw,
 work=dict(all8_complete_reports_equal_normal_8ebb_except_time=True,prompt_rows=154,generated_tokens=16,target_rows=169,target_calls=16,decode_calls=15,generated_ids=rows[0]['work']['generated_ids'],non_time_fields_ignored=[]),
 protocol=dict(timing_order='H,C,C,H,H,C',memory_order='H,C',timing_samples_each=3,memory_samples_each=1,warmups=0,retries=0,watchdog_seconds=180,old_samples_pooled=False,timing_processes_unmonitored=True,endpoints=dict(prefill='154/prefill_seconds',decode='15/decode_seconds',combined='16/session_seconds')),
 configuration=dict(H='8ebb; borrowed Scheduler executor concurrency4',C='217e; empty executor concurrency1/caller',both='native_threads4,ATen4,Scheduler4 creation/lifetime,pollDefault50,source weights and budgets unchanged'),
 identities=dict(plan=pin(S/'plan.json'),script=pin(W/'screen.py'),reference=pin(W.parent/'poll-default1/behavior1/stdout.log'),ready_H=pin(W.parent/'poll-default1/ready.json'),ready_C=pin(W/'ready.json'),source_pins=pin(W/'source-pins.json'),analyzer=pin(__file__)),
 limits=['Legal configuration benefit,not library implementation/algorithm speedup or an automatic default-policy recommendation.',
 'Executor concurrency changes4to1. Generic native/oneDNN parallel_for partitioning may change;native4/ATen4 stayfixed. Not a claim allprovider work partitioning or algorithms are identical.',
 'Three short timing samples perarm;decode/combined ranges do not overlap in this window,prefill ranges overlap. No broad scaling/stability certificate.',
 'Full reported non-time equality is not intermediate tensor-bit equivalence. No new route/profiler traces were collected.',
 'Memory processes do not enter TPS statistics;sampled peaks are lowerbounds. BothOSthreadpeaks17;small memory differences are not a demonstrated resource benefit. MissingGPUcounters remainnull.',
 'GetProcessTimes covers fullprocess startup/generation/teardown,not decode-only CPUtime or energy.'],CPU_released=True,live_models_or_compiles=0,canonical_changed=False,extra_builds=0,GPU_runs=0)
p=S/'final-summary.json';p.write_bytes((json.dumps(result,indent=2,allow_nan=False)+'\n').encode());print(json.dumps(pin(p)))
