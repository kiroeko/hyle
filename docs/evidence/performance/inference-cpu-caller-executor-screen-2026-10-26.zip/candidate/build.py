"""Entry-only CPU configuration counterfactual. No model execution here."""
from pathlib import Path
import difflib, importlib.util, json, os, sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent; B=W.parent; R=B.parents[1]
s=importlib.util.spec_from_file_location('inline_cpu_build',B/'check_build.py');b=importlib.util.module_from_spec(s);s.loader.exec_module(b)
read=b.read;pin=b.pin;save=b.save
control=B/'poll-default1'; original=R/'.scratch/inference-cpu-representative-20261026/cpu_entry.cc'
source=W/'source/cpu_entry.cc'; source.parent.mkdir(parents=True,exist_ok=True)
old=original.read_bytes(); text=old.decode('utf-8')
assert text.count('.executor = executor.ref()')==1
text=text.replace('  Executor executor{scheduler};','  [[maybe_unused]] Executor executor{scheduler};')
text=text.replace('.executor = executor.ref()', '.executor = {}')
text=text.replace('executor_concurrency=4 aten_intra_op_requested=4','executor_concurrency=1 executor=caller scheduler_workers=4 aten_intra_op_requested=4')
source.write_bytes(text.encode('utf-8'))
patch=''.join(difflib.unified_diff(old.decode().splitlines(True),text.splitlines(True),fromfile='before/cpu_entry.cc',tofile='source/cpu_entry.cc'))
(W/'source.patch').write_bytes(patch.encode('utf-8'))
save(W/'source-pins.json',dict(before=pin(original),after=pin(source),patch=pin(W/'source.patch'),configuration='executor empty; Scheduler4 remains open, native_threads=4, ATen=4, poll default50; only entry object changes',diagnostic_only_changes=['adapter variable marked maybe_unused','stderr identifies empty executor and retained scheduler workers']))
baseline=read(control/'ready.json');assert pin(baseline['image']['path'])==baseline['image'];assert baseline['image']['sha256']=='8ebb4d5d506ec0c468b97b175c90d8caf7990d1931959beef9bc6fb7c6d6baf3'
recipe=R/'.scratch/inference-cpu-representative-20261026/compile/entry/command.json'
command=[];skip=False
for a in read(recipe)['command']:
 if skip:skip=False;continue
 if a.lower()=='/sourcedependencies':skip=True;continue
 if a.lower().startswith(('/fo','/fd')) or a.lower().endswith(('.cc','.cpp')):continue
 command.append(a)
out=W/'compile';command += [str(source),'/sourceDependencies',str(out/'dependencies.json'),'/Fo'+str(out/'unit.obj'),'/Fd'+str(out/'unit.pdb')]
compiled=b.h.execute(command,b.env(command),out,timeout=120)
d=read(out/'dependencies.json')['Data'];save(out/'actual-dependencies.json',[pin(p) for p in dict.fromkeys([d['Source'],*d['Includes']])])
oldobject=pin(R/'.scratch/inference-cpu-representative-20261026/compile/entry/unit.obj');replacement=pin(out/'unit.obj');command=[];seen=0;out=W/'link';image=out/'hyle.exe'
for a in read(control/'link/command.json')['command']:
 if a.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:')):continue
 if b.key(a)==b.key(oldobject['path']):seen+=1;a=replacement['path']
 command.append(a)
assert seen==1
inputs=[]
for p in read(control/'link-inputs.json'):
 assert pin(p['path'])==p,p['path']
 inputs.append(replacement if b.key(p['path'])==b.key(oldobject['path']) else p)
assert sum(p==replacement for p in inputs)==1
save(W/'link-inputs.json',inputs)
command += ['/OUT:'+str(image),'/MAP:'+str(image.with_suffix('.map')),'/IMPLIB:'+str(image.with_suffix('.lib'))]
linked=b.h.execute(command,b.env(command),out,timeout=120)
rt=read(control/'runtime.json');native=Path(rt['native']['path']);target=out/Path(rt['native_hardlink']['path']).name;os.link(native,target);rt['native_hardlink']=pin(target);save(W/'runtime.json',rt)
ready=dict(status='BUILT_NOT_RUN',image=pin(image),compile=compiled,link=linked,source=pin(source),source_pins=pin(W/'source-pins.json'),patch=pin(W/'source.patch'),recipe=pin(recipe),actual_dependencies=pin(W/'compile/actual-dependencies.json'),link_inputs=pin(W/'link-inputs.json'),runtime=pin(W/'runtime.json'),original_ready=pin(control/'ready.json'),replacement=dict(before=oldobject,after=replacement),all_other_link_inputs_unchanged=True,model_runs=0,canonical_changed=False)
save(W/'ready.json',ready);print('READY',json.dumps(ready['image']),flush=True)
