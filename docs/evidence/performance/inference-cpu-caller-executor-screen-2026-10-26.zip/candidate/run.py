"""Exactly one original CPU behavior journey, not a timing screen."""
from pathlib import Path
import importlib.util,json,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;B=W.parent
s=importlib.util.spec_from_file_location('inline_cpu_tools',B/'check_build.py');b=importlib.util.module_from_spec(s);s.loader.exec_module(b)
read=b.read;pin=b.pin;save=b.save
ready=read(W/'ready.json');assert pin(ready['image']['path'])==ready['image'];assert pin(ready['source']['path'])==ready['source']
control=B/'poll-default1/behavior1';command=list(read(control/'command.json')['command']);command[0]=ready['image']['path']
rt=read(W/'runtime.json');env=b.env(read(W/'compile/command.json')['command']);env['PATH']=rt['PATH'];env.update(rt.get('configured_flags',{}));env.update(HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1')
result=b.h.execute(command,env,W/'behavior1',timeout=180)
time_keys={'seconds','unix_ms','unix_ns','clock_unix'}
def norm(v):
 if isinstance(v,dict):return {k:norm(x) for k,x in v.items() if k not in time_keys and not k.endswith('_seconds') and not k.endswith('tokens_per_second')}
 if isinstance(v,list):return [norm(x) for x in v]
 return v
def diff(a,c,path='$'):
 if type(a)!=type(c):return [dict(path=path,before=a,after=c)]
 if isinstance(a,dict):
  rows=[]
  for k in a.keys()|c.keys():
   if k not in a or k not in c:rows.append(dict(path=path+'.'+k,before=a.get(k),after=c.get(k)))
   else:rows+=diff(a[k],c[k],path+'.'+k)
  return rows
 if isinstance(a,list):
  if len(a)!=len(c):return [dict(path=path,before_length=len(a),after_length=len(c))]
  return [r for i,(x,y) in enumerate(zip(a,c)) for r in diff(x,y,path+f'[{i}]')]
 return [] if a==c else [dict(path=path,before=a,after=c)]
actual=read(W/'behavior1/stdout.log');baseline=read(control/'stdout.log');rows=diff(norm(baseline),norm(actual));save(W/'behavior1/nontime-diff.json',rows)
summary=dict(status='ONE_CONFIG_BEHAVIOR_PASS' if not rows else 'BEHAVIOR_DIFFERENCE_STOP',process=result,ready=pin(W/'ready.json'),source_pins=pin(W/'source-pins.json'),reference=pin(control/'stdout.log'),nontime_difference_count=len(rows),normalization=dict(time_keys=sorted(time_keys),suffixes=['_seconds','tokens_per_second'],other_fields_ignored=[]),observed=dict(generated_tokens=actual['generated_tokens'],actual_target_rows=actual['actual_target_rows'],actual_graph_calls=actual['actual_graph_calls']),model_runs=1,entry_TUs=1,other_TUs=0,performance_claim=False,timing_screen=False,canonical_changed=False,CPU_released=True,GPU_runs=0)
save(W/'summary.json',summary);assert not rows,rows[:10]
print('ONE_CONFIG_BEHAVIOR_PASS CPU_RELEASED',json.dumps(summary),flush=True)
