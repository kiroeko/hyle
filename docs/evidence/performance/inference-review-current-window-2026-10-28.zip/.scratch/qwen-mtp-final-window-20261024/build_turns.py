"""Two consumer-only compiles/links; no model execution or acquisition."""
import argparse
import hashlib
import importlib.util
from pathlib import Path
import sys

sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
R = S.parents[1]
Q = R / '.scratch/qwen-mtp-quality-20261022'
P = S / 'natural-turns-proposal'
FROZEN = Q / 'current-refresh-preparation/build.py'
FROZEN_SHA = 'efe4ceff46b5b58a39d87621988fc9f7c9bc16e3969186221d28c7faa51809e2'
FLAT_SHA = '3749aa7a5767faad27653b133aad83994a13126db2b4cd17ea4452780f4a973d'
PEER = S / 'source/peer_multiturn.cc'
PEER_SHA = '0a6ce1d98fb66c7e74a5f56ecb26470c83aa043c8cd7814ded0afafb532e9132'


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec); spec.loader.exec_module(module)
    return module


def cached():
    if hashlib.sha256(FROZEN.read_bytes()).hexdigest() != FROZEN_SHA:
        raise ValueError('Frozen current consumer builder changed')
    value = load('_turns_retained_product_builder', FROZEN)
    value.P = P; value.FLAT_SHA = FLAT_SHA
    return value


def hyle_compile():
    c = cached(); c.compile_one(2)
    path = c.S / 'compile2/qwen/identity.json'; record = c.read(path)
    h = load('_turns_hyle_metadata', c.HELPER)
    record.update(current_entry=h.b.identity(Path(__file__)), natural_turns_parser=h.b.identity(R / 'tools/qwen35_text/mtp_schedule.h'))
    c.save(path, record)


def peer_compile():
    if hashlib.sha256(PEER.read_bytes()).hexdigest() != PEER_SHA: raise ValueError('Frozen peer source changed')
    c = cached(); h = load('_turns_peer_cached_compiler', c.HELPER)
    h.S = S; h.RECIPES = {'peer': Q / 'compile3/peer/identity.json'}; h.SOURCES = {'peer': PEER}
    h.compile_one('peer', 1)
    path = S / 'compile1/peer/identity.json'; record = c.read(path)
    record.update(current_entry=h.b.identity(Path(__file__)), peer_math_source=h.b.identity(Q / 'source/peer_mtp.cc'),
                  SDK_builds=0, NVCC_builds=0, llama_core_builds=0)
    c.save(path, record)


def peer_link():
    c = cached(); h = load('_turns_peer_cached_linker', c.HELPER)
    old = c.read(Q / 'peer-link1/link-plan.json')
    old_record = c.read(Q / 'compile3/peer/identity.json')
    path = S / 'compile1/peer/identity.json'; fresh = c.read(path)
    for row in (fresh['source'], fresh['object'], *fresh['dependencies']):
        if h.b.identity(row['path']) != row: raise ValueError('Actual new peer input changed')
    removed = c.key(old_record['object']['path']); count = 0; command = []
    for arg in old['command']:
        if arg.upper().startswith(('/OUT:', '/MAP:', '/IMPLIB:', '/PDB:')): continue
        if arg.lower().endswith('.obj') and c.key(arg) == removed:
            arg = fresh['object']['path']; count += 1
        command.append(arg)
    if count != 1: raise ValueError('Replace exactly one old peer TU')
    inputs = [fresh['object'] if c.key(row['path']) == removed else row for row in old['inputs']]
    if len(inputs) != 9: raise ValueError('Keep the exact existing nine peer link inputs')
    for row in inputs:
        if h.b.identity(row['path']) != row: raise ValueError('Actual peer core/input changed')
    out = S / 'peer-link1'; out.mkdir(exist_ok=False); (out / 'tmp').mkdir()
    image = out / 'peer.exe'
    command += ['/OUT:' + str(image), '/MAP:' + str(image.with_suffix('.map')), '/IMPLIB:' + str(image.with_suffix('.lib'))]
    c.save(out / 'link-plan.json', dict(command=command, inputs=inputs, compiled_record=h.b.identity(path),
        original_peer_plan=h.b.identity(Q / 'peer-link1/link-plan.json'), current_entry=h.b.identity(Path(__file__)),
        fresh_consumer_TUs=1, llama_core_builds=0, SDK_builds=0, NVCC_builds=0))
    env, _ = h.b.environment(command, [row['path'] for row in inputs], out)
    h.c.execute('link', command, env, out)
    result = c.read(out / 'link.result.json')
    if result['exit'] != 0: raise ValueError('Actual peer link failed')
    runtime = c.read(Q / 'peer-link1/runtime-environment.json')
    c.save(out / 'runtime-environment.json', runtime)
    c.save(out / 'ready.json', dict(image=h.b.identity(image), source=fresh['source'], compiled_identity=h.b.identity(path),
        runtime_environment=h.b.identity(out / 'runtime-environment.json'), link_plan=h.b.identity(out / 'link-plan.json'),
        original_ready=h.b.identity(Q / 'peer-link1/ready.json'), current_entry=h.b.identity(Path(__file__)),
        note='Same fixed native llama core; one new consumer adds genuine natural turns without clearing/rebuilding contexts.'))
    print('LINKED_CURRENT_PEER', image, flush=True)


if __name__ == '__main__':
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument('action', choices=('hyle-compile', 'hyle-link', 'peer-compile', 'peer-link'))
    args = cli.parse_args()
    if args.action == 'hyle-compile': hyle_compile()
    elif args.action == 'hyle-link': cached().link(2, 2)
    elif args.action == 'peer-compile': peer_compile()
    else: peer_link()
