"""Retained complete-window endpoints/parser/PSAPI-PDH, with five fixed arms.

Only explicit run-one/resume-one start processes. analyze-one/summary do not.
"""
from pathlib import Path
import copy
import importlib.util
import json
import math
import os
import sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent
R=Path(r'C:\public\project-hyle\hyle')
ARMS=('hyle_plain','hyle_auto','hyle_mtp','peer_plain','peer_mtp')
GROUPS=(('single','timing'),('single','memory'),('two-turn','timing'),('two-turn','memory'))

def module(name,path):
    spec=importlib.util.spec_from_file_location(name,path)
    value=importlib.util.module_from_spec(spec);spec.loader.exec_module(value);return value

protocol=module('continuous_retained_complete_protocol',R/'.scratch/mtp-performance-convergence-20261025/baseline/window.py')
base=protocol.base
original_analyze=protocol.original_analyze
original_parse=protocol.parse
facts_parser=module('continuous_full_non_time_oracle',R/'.scratch/inference-current-review-profile-20261027/analyze.py')
# Both original reducers use these module globals; no endpoint or memory helper
# is replaced. Only the arm cardinality changes from four to five.
base.ARMS=ARMS;protocol.h.ARMS=ARMS;protocol.D=W

def fixed_plan(config,mode,output):
    assert Path(config).resolve()==(W/'arms.json').resolve()
    scenario=protocol.WORKLOAD
    assert (scenario,mode) in GROUPS
    assert Path(output).resolve()==(W/(scenario+'-'+mode)).resolve()
    plan=base.read(W/(scenario+'-'+mode+'-plan.json'))
    for field in ('binding','configuration'):
        assert base.identity(plan[field]['path'])==plan[field]
    checked=set()
    for row in plan['commands']:
        for field in ('ready','image','environment'):
            p=row[field]
            if p['path'] in checked:continue
            assert base.identity(p['path'])==p,p['path'];checked.add(p['path'])
    return dict(plan,plan_only=False)

def parse(folder,arm,configuration):
    observation=original_parse(folder,arm,configuration)
    # Explicit independent partition gate: never reinterpret a zero prefill as
    # decode work. The producer's actual complete intervals remain unchanged.
    raw=base.read(Path(folder)/'consumer-result.json')
    prefill,decode,session=(raw[k] for k in ('prefill_seconds','decode_seconds','session_seconds'))
    assert all(isinstance(v,(int,float)) and math.isfinite(v) for v in (prefill,decode,session))
    assert prefill>0 and decode>0 and session>0,'Missing/nonpositive actual prefill/decode/session endpoint'
    assert math.isclose(prefill+decode,session,rel_tol=1e-5,abs_tol=2e-6),'Actual P+D must partition complete session'
    base.save(Path(folder)/'timing-partition-gate.json',dict(status='PASS',prefill_seconds=prefill,
        decode_seconds=decode,session_seconds=session,tolerance=dict(relative=1e-5,absolute_seconds=2e-6),
        producer_values_unchanged=True))
    if arm.startswith('hyle'):
        raw=base.read(Path(folder)/'consumer-result.json')
        assert raw['decode_overlap']==(arm=='hyle_auto')
        assert raw['live_committed_versions']==0
        if arm=='hyle_auto':
            assert raw['overlap_successor_publications']>0,'Auto must perform real device relay'
            assert 0<raw['overlap_successor_publications']<=raw['overlap_successor_submissions']
            base.save(Path(folder)/'relay-evidence.json',relay_evidence(raw,folder))
        else:assert raw['overlap_successor_submissions']==0
    return observation

def relay_evidence(raw,folder):
    return dict(folder=str(folder),report=base.identity(Path(folder)/'consumer-result.json'),
        decode_overlap_requested=raw['decode_overlap'],final_available=raw['decode_overlap_available'],
        submissions=raw['overlap_successor_submissions'],publications=raw['overlap_successor_publications'],
        discards=raw['overlap_successor_discards'],refusals=raw['overlap_successor_refusals'],
        actual_relay=raw['overlap_successor_publications']>0,
        scope='Actual relay occurred; final availability/refusals retain any mixed relay/synchronous fallback.')

def differences(old,new,path='$'):
    if type(old) is not type(new):return [dict(path=path,old=old,new=new)]
    if isinstance(old,dict):
        result=[]
        for key in sorted(set(old)|set(new)):
            if key not in old or key not in new:result.append(dict(path=path+'.'+key,old=old.get(key),new=new.get(key)))
            else:result+=differences(old[key],new[key],path+'.'+key)
        return result
    if isinstance(old,list):
        if len(old)!=len(new):return [dict(path=path,old=old,new=new)]
        return [d for i,(a,b) in enumerate(zip(old,new)) for d in differences(a,b,f'{path}[{i}]')]
    return [] if old==new else [dict(path=path,old=old,new=new)]

def analyze(output):
    output=Path(output)
    result=original_analyze(output);runs=base.read(output/'runs.json')
    expect=3 if result['mode']=='timing' else 1
    consistency=protocol.h.within_arm_work(runs)
    stable=len(runs)==5*expect and all(x['processes']==expect and x['stable'] for x in consistency.values())
    complete={}
    for arm in ARMS:
        selected=[r for r in runs if r['arm']==arm]
        reports=[base.read(Path(r['folder'])/'consumer-result.json') for r in selected]
        facts=[facts_parser.non_time(r) for r in reports]
        changed=[dict(folder=selected[i]['folder'],differences=differences(facts[0],f)) for i,f in enumerate(facts[1:],1) if f!=facts[0]]
        complete[arm]=dict(processes=len(selected),identical_complete_non_time_producer_report=not changed,changes=changed)
        stable=stable and not changed
    # Check ordinary execution-mode numerics, while retaining all explicit
    # mode/backing/capture differences as observed facts rather than erasing them.
    ordinary={arm:base.read(Path(next(r['folder'] for r in runs if r['arm']==arm))/'consumer-result.json') for arm in ('hyle_plain','hyle_auto')}
    off,auto=ordinary['hyle_plain'],ordinary['hyle_auto']
    assert off['generated_ids']==auto['generated_ids']
    compared=('generated_tokens','generated_decode_tokens','actual_graph_calls','actual_target_rows','committed_target_rows','verified_target_rows','committed_target_decode_rows','prefill_target_rows','pending_flushed_tokens')
    assert all(off[k]==auto[k] for k in compared)
    base.save(output/'ordinary-mode-fact-differences.json',dict(
        semantic_counts_equal=list(compared),all_generated_IDs_equal=True,
        differences=differences(facts_parser.non_time(off),facts_parser.non_time(auto))))
    result.update(status='complete_stable_within_arm_work' if stable else 'complete_with_preserved_variability',
        workload=protocol.WORKLOAD,arm_count=5,within_arm_work=consistency,within_arm_full_non_time_reports=complete,
        within_arm_fixed_work_valid=stable,image_instrumented=False,historical_samples_pooled=False,
        ordinary_auto_has_real_publications=dict(
            all_processes=all(base.read(Path(r['folder'])/'consumer-result.json')['overlap_successor_publications']>0 for r in runs if r['arm']=='hyle_auto'),
            evidence=[relay_evidence(base.read(Path(r['folder'])/'consumer-result.json'),r['folder']) for r in runs if r['arm']=='hyle_auto']),
        memory_unknown_values_preserved=True)
    result['limits']=[x.replace('four separate monitored processes','five separate monitored processes') for x in result['limits']]
    result['limits'] += ['Same retained complete producer endpoints and 10ms-requested PSAPI/PDH sampler; no ready sample remains unknown/null, never zero.',
        'Current ordinary-auto performs real relay; all other Hyle arms explicitly select overlap-off. Natural peer uses frozen433e, not latest upstream.',
        'Full within-arm non-time producer reports use the existing W13 non_time predicate without extra ignored metadata; any variation is preserved and stops completion.',
        'No cross-engine continuation/quality/significance claim; reported backing formulae are not sampled physical VRAM peaks.']
    base.save(output/'summary.json',result)
    assert stable,'Preserved within-arm producer-fact variability; do not replace samples'
    return result

base.plan=fixed_plan;base.parse_result=parse;base.analyze=analyze

def summary():
    groups={}
    for scenario,mode in GROUPS:
        groups[(scenario,mode)]=base.read(W/(scenario+'-'+mode)/'summary.json')
        assert groups[(scenario,mode)]['within_arm_fixed_work_valid']
    table=[]
    for scenario in ('single','two-turn'):
        for arm in ARMS:
            timing=groups[(scenario,'timing')]['groups'][arm]
            memory=groups[(scenario,'memory')]['groups'][arm]
            table.append(dict(scenario=scenario,arm=arm,timing=timing,independent_memory=memory))
    value=dict(status='COMPLETE40_FIVE_ARMS_STABLE',processes=40,timing_processes=30,independent_memory_processes=10,
        binding=base.identity(W/'binding.json'),plan=base.identity(W/'plan.json'),table=table,
        original_endpoints_and_memory_sampler=True,historical_samples_pooled=False,
        limits=['Three timing samples/one independent memory sample per arm/scenario; no significance claim.',
            'No ready sample or unsupported OS/GPU counter becomes zero; preserve raw null/unknown and measured sampling gaps.',
            'Memory sampler times are not TPS samples. Dedicated/shared/WS/commit are separate quantities; sampled maxima are lower bounds.',
            'Compare this current window internally; no old18:01 sample pooling or causal gain attribution across windows.'])
    base.save(W/'summary.json',value);print(value['status'],flush=True)

def resume_preflight(output,mode):
    configuration=fixed_plan(W/'arms.json',mode,output)
    assert base.read(output/'inputs.json')==configuration,'Original inputs/plan changed'
    entries=configuration['commands'];existing=[e for e in entries if Path(e['folder']).exists()]
    assert existing==entries[:len(existing)],'Existing attempts must be a contiguous prefix'
    assert {p.resolve() for p in output.iterdir() if p.is_dir()}=={Path(e['folder']).resolve() for e in existing}
    for e in existing:
        folder=Path(e['folder']);raw=[folder/n for n in ('command.json','result.json','stdout.log','stderr.log')]
        pins=[base.identity(p) for p in raw];terminal=base.read(folder/'result.json');command=base.read(folder/'command.json')
        assert terminal['exit']==0 and not terminal.get('timeout') and not terminal.get('reader_errors'),folder
        for actual in (command,terminal):
            assert actual['command']==e['command'] and actual['image']==e['image'] and actual['arm']==e['arm']
            assert actual['memory_only']==(mode=='memory') and Path(actual['cwd']).resolve()==R.resolve()
        parse(folder,e['arm'],configuration) # Offline only; never execute an existing successful process.
        assert [base.identity(p) for p in raw]==pins,'Raw successful attempt changed'
    return configuration,len(existing)

def resume_one(output,mode):
    configuration,count=resume_preflight(output,mode)
    helpers=base.load_helpers();helpers.gpu_snapshot(output,'resume-before')
    try:
        for e in configuration['commands'][count:]:
            folder=Path(e['folder']);assert not folder.exists(),'Never overwrite an attempt'
            assert base.identity(e['environment']['path'])==e['environment']
            env=os.environ.copy();env['PATH']=base.read(e['environment']['path'])['PATH']
            print('WINDOW_BEGIN',mode,e['ordinal'],e['arm'],flush=True)
            helpers.execute(folder,e['arm'],e['command'],env,mode=='memory')
            parse(folder,e['arm'],configuration)
            print('WINDOW_END',mode,e['ordinal'],e['arm'],flush=True)
    finally:helpers.gpu_snapshot(output,'resume-after')
    return analyze(output)

def main():
    action=sys.argv[1]
    if action=='summary':summary();return
    assert action in ('run-one','resume-one','analyze-one')
    scenario,mode=sys.argv[2:];assert (scenario,mode) in GROUPS
    protocol.WORKLOAD=scenario;output=W/(scenario+'-'+mode)
    if action=='run-one':
        assert base.read(W/'plan.json')['status']=='PREPARED_NOT_RUN_NOT_COMPILED','Model3 concrete binding not ready'
        assert not output.exists(),'Preserve every attempt; no automatic rerun'
        os.environ.update(HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',HF_HUB_DISABLE_TELEMETRY='1')
        value=base.run(W/'arms.json',mode,output)
    elif action=='resume-one':
        os.environ.update(HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',HF_HUB_DISABLE_TELEMETRY='1')
        value=resume_one(output,mode)
    else:value=analyze(output)
    print(value['status'],value['processes'],flush=True)

if __name__=='__main__':main()
