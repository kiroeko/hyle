"""Offline forty-process performance receipt. Run only after root ends timing.

No consumer/compiler/driver/network action is available here. Build/source identity is retained here; correctness is referenced independently.
Only the root agent executes this script after the forty-process window ends.
"""
from pathlib import Path
import hashlib
import json
import math
import statistics
import zipfile

W = Path(__file__).resolve().parent
R = Path(r'C:\public\project-hyle\hyle')
B = W
OUT = R / 'docs/evidence/performance/inference-review-current-window-2026-10-28'
CORRECTNESS = R / 'docs/evidence/correctness/inference-execution-preparation-2026-10-28'
PROTOCOL_ARCHIVE = R / 'docs/evidence/performance/inference-program-io-current-window-2026-10-28'
HISTORY = R / '.scratch/inference-uniform-prefill-20261028'
HISTORY_IMAGE = 'bb0ca99e604baff303b20f8e3f1e82bf78b93e76877eee573a3eda87251638be'
MODEL = '2434c27c9c49f34bcf73269b831b610af9c396ffc8f1c5d9951f04e010742f5b'
IMAGE = '2c0f942325ebf2bd7c2db155d7dea03049166b6fd1f189637dccb42d18ca42f2'
PEER = '433e7051f4c36d0d9b2297dc378631546b7e3c44630cda0653cba2d1ec6bbe8e'
ARMS = ('hyle_plain', 'hyle_auto', 'hyle_mtp', 'peer_plain', 'peer_mtp')
GROUPS = ('single-timing', 'single-memory', 'two-turn-timing', 'two-turn-memory')
FORBIDDEN = {'.exe', '.obj', '.pdb', '.dll', '.lib', '.exp', '.bin', '.gguf', '.safetensors',
             '.pt', '.spv', '.db', '.sqlite', '.nsys-rep', '.pyc', '.zip'}


def read(path):
    return json.loads(Path(path).read_bytes())


def pin(path):
    path = Path(path).resolve(); digest = hashlib.sha256()
    with path.open('rb') as stream:
        while body := stream.read(1 << 20):
            digest.update(body)
    return dict(path=str(path), bytes=path.stat().st_size, sha256=digest.hexdigest())


def exact(row):
    assert pin(row['path']) == row, row['path']


def save(path, value):
    Path(path).write_bytes((json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + '\n').encode())


def compact(path, value):
    lines = ['{']
    for index, (key, item) in enumerate(value.items()):
        start = '  ' + json.dumps(key) + ': '
        end = ',' if index + 1 < len(value) else ''
        if isinstance(item, list):
            lines.append(start + '[')
            for number, row in enumerate(item):
                lines.append('    ' + json.dumps(row, ensure_ascii=False, allow_nan=False) + (',' if number + 1 < len(item) else ''))
            lines.append('  ]' + end)
        else:
            lines.append(start + json.dumps(item, ensure_ascii=False, allow_nan=False) + end)
    Path(path).write_bytes(('\n'.join(lines + ['}']) + '\n').encode())


def non_time(value):
    # Exact original retained W13 predicate; no additional metadata filtering.
    if isinstance(value, list):
        return [non_time(item) for item in value]
    if isinstance(value, dict):
        return {key: non_time(item) for key, item in value.items() if not any(word in key
            for word in ('seconds', 'per_second', 'clock_unix', 'unix_ns', 'unix_ms'))}
    return value


def triple(stats):
    if stats is None:
        return None
    return [None if stats.get(key) is None else round(stats[key], 6) for key in ('median', 'min', 'max')]


def mib(value):
    return None if value is None else round(value / (1024 ** 2), 3)


def collect():
    # This assertion precedes all heavy hashing and compression.
    summary = read(W / 'summary.json')
    assert summary['status'] == 'COMPLETE40_FIVE_ARMS_STABLE'
    assert (summary['processes'], summary['timing_processes'], summary['independent_memory_processes']) == (40, 30, 10)
    assert CORRECTNESS.with_suffix('.json').is_file() and CORRECTNESS.with_suffix('.zip').is_file(), 'Archive referenced correctness evidence first'
    ready, plan, binding = read(B / 'ready-model.json'), read(W / 'plan.json'), read(W / 'binding.json')
    assert ready['image']['sha256'] == IMAGE
    exact(ready['image'])
    for name in ('runtime', 'inputs', 'recipe', 'plan'):
        exact(ready[name])
    assert len(read(ready['inputs']['path'])) == binding['closure_inputs'] == 229
    assert ready['compiled']['snapshot']['sha256'] == MODEL
    assert ready['compiled']['source']['sha256'] == MODEL
    assert ready['compiled']['process']['exit'] == ready['process']['exit'] == 0
    for name in ('snapshot', 'command', 'dependencies', 'actual_dependencies'):
        exact(ready['compiled'][name])
    assert binding['Hyle'] == ready and binding['current_Model'] == ready['compiled']
    assert read(W / 'ready.json')['build'] == pin(B / 'ready-model.json')
    baseline = read(binding['retained_CUDA_consumer_build']['path'])
    frozen_plan = read(ready['plan']['path'])
    actual_inputs, baseline_inputs = read(ready['inputs']['path']), read(baseline['inputs']['path'])
    assert len(baseline_inputs) == len(actual_inputs) == 229
    assert frozen_plan['entry']['object'] in actual_inputs
    changes = [(a, b) for a, b in zip(baseline_inputs, actual_inputs) if a != b]
    assert changes == [(frozen_plan['original_object'], ready['compiled']['object'])]
    assert len({p['path'] for p in actual_inputs}) == 229
    assert binding['link_closure'] == ready['inputs']
    exact(read(W / 'ready.json')['source_headers'])
    assert binding['runner_bytes_identical'] is True and not summary['historical_samples_pooled']
    assert (W / 'window.py').read_bytes() == Path(binding['retained_previous_runner']['path']).read_bytes()
    for group in plan['groups']:
        exact(group['plan'])
    peer = read(W / 'peer-ready.json')
    assert peer['image']['sha256'] == PEER
    exact(peer['image']); exact(peer['runtime_environment'])
    groups, rows_by_group, processes, reports = {}, {}, [], {}
    for name in GROUPS:
        directory = W / name
        group, rows = read(directory / 'summary.json'), read(directory / 'runs.json')
        planned = read(W / (name + '-plan.json'))['commands']
        assert len(rows) == len(planned) == (15 if name.endswith('timing') else 5)
        assert group['within_arm_fixed_work_valid'] and group['memory_unknown_values_preserved']
        groups[name] = group; rows_by_group[name] = rows
        for row, expected in zip(rows, planned):
            folder = Path(row['folder'])
            for field in ('ready', 'environment'):
                exact(expected[field])
            assert folder == Path(expected['folder']) and row['arm'] == expected['arm']
            process = read(folder / 'result.json')
            assert process == row['process'] and process['command'] == expected['command']
            assert process['exit'] == 0 and not process.get('reader_errors')
            assert not process.get('timed_out') and not process.get('timeout')
            assert process['memory_only'] == name.endswith('memory')
            assert process['image'] == expected['image']
            assert process['image']['sha256'] == (IMAGE if row['arm'].startswith('hyle') else PEER)
            raw = read(folder / 'consumer-result.json'); reports[str(folder)] = raw
            prefill, decode, session = [raw[key] for key in ('prefill_seconds', 'decode_seconds', 'session_seconds')]
            assert all(isinstance(x, (float, int)) and math.isfinite(x) and x > 0 for x in (prefill, decode, session))
            assert math.isclose(prefill + decode, session, rel_tol=1e-5, abs_tol=2e-6)
            assert read(folder / 'timing-partition-gate.json')['status'] == 'PASS'
            if row['arm'].startswith('hyle'):
                assert raw['live_committed_versions'] == 0
                assert raw['decode_overlap'] == (row['arm'] == 'hyle_auto')
                if row['arm'] == 'hyle_auto':
                    assert 0 < raw['overlap_successor_publications'] <= raw['overlap_successor_submissions']
                else:
                    assert raw['overlap_successor_submissions'] == 0
            processes.append(dict(group=name, arm=row['arm'], ordinal=expected['window_ordinal'],
                pid=process['pid'], exit=process['exit'], started_unix_ns=process['started_unix_ns'],
                finished_unix_ns=process['finished_unix_ns'], image=process['image'],
                raw_files=[pin(folder / item) for item in ('command.json', 'result.json', 'stdout.log', 'stderr.log', 'consumer-result.json')]))
        # Recheck complete producer facts in each original timing/memory group.
        for arm in ARMS:
            selected = [r for r in rows if r['arm'] == arm]
            assert len(selected) == (3 if name.endswith('timing') else 1)
            facts = [non_time(reports[r['folder']]) for r in selected]
            assert all(item == facts[0] for item in facts), ('Preserve actual full-fact variation', name, arm)
    assert len(processes) == len({p['ordinal'] for p in processes}) == len({p['pid'] for p in processes}) == 40
    assert all(a['finished_unix_ns'] <= b['started_unix_ns'] for a, b in zip(
        sorted(processes, key=lambda p: p['started_unix_ns']),
        sorted(processes, key=lambda p: p['started_unix_ns'])[1:])), 'Model process overlap'
    for row in summary['table']:
        selected = [item for item in rows_by_group[row['scenario'] + '-timing'] if item['arm'] == row['arm']]
        for key, stats in row['timing'].items():
            values = [item['observation']['metrics'].get(key) for item in selected]
            values = [x for x in values if isinstance(x, (float, int)) and math.isfinite(x)]
            if stats is None:
                assert not values
                continue
            assert stats['count'] == len(values)
            if values:
                for actual, label in ((statistics.median(values), 'median'), (min(values), 'min'), (max(values), 'max')):
                    assert math.isclose(actual, stats[label], rel_tol=1e-12)
    return summary, ready, binding, groups, rows_by_group, reports, processes


def differences(old, new, path='$'):
    if type(old) is not type(new): return [dict(path=path, old=old, new=new)]
    if isinstance(old, dict):
        result = []
        for key in sorted(set(old) | set(new)):
            if key not in old or key not in new: result.append(dict(path=path+'.'+key, old=old.get(key), new=new.get(key)))
            else: result += differences(old[key], new[key], path+'.'+key)
        return result
    if isinstance(old, list):
        if len(old) != len(new): return [dict(path=path, old=old, new=new)]
        return [item for i, (a, b) in enumerate(zip(old, new)) for item in differences(a, b, f'{path}[{i}]')]
    return [] if old == new else [dict(path=path, old=old, new=new)]


def history_comparison(rows_by_group, reports):
    # Called only after collect() has proven that all40 current processes ended.
    # These old raw reports establish fact differences only; no old time enters
    # a current median, percentage, work-equality or causal-speed claim.
    assert read(HISTORY / 'ready-model.json')['image']['sha256'] == HISTORY_IMAGE
    old_summary = read(HISTORY / 'summary-continuations.json')
    assert old_summary['status'] == 'COMPLETE_DISTINCT_CONTINUATIONS'
    result = []; sources = set()
    for name in GROUPS:
        scenario, mode = name.rsplit('-', 1)
        # Independently verify ordinary off/auto, beyond the retained reducer.
        ordinary = {arm: reports[next(row['folder'] for row in rows_by_group[name] if row['arm'] == arm)]
                    for arm in ('hyle_plain', 'hyle_auto')}
        assert ordinary['hyle_plain']['generated_ids'] == ordinary['hyle_auto']['generated_ids']
        saved = read(W / name / 'ordinary-mode-fact-differences.json')
        assert saved['all_generated_IDs_equal'] is True
        assert saved['differences'] == differences(non_time(ordinary['hyle_plain']), non_time(ordinary['hyle_auto']))
        for arm in ('hyle_plain', 'hyle_auto', 'hyle_mtp'):
            role = 'mtp' if arm == 'hyle_mtp' else 'ordinary'
            previous = HISTORY / (scenario+'-'+role+'-'+mode)
            checked = read(previous / 'analysis-continuations.json')
            assert checked['within_variant_complete_non_time']['candidate']['stable'] is True
            selected = [row for row in read(previous / 'runs-continuations.json') if row['variant'] == 'candidate']
            assert len(selected) == (3 if mode == 'timing' else 1)
            before = []
            for row in selected:
                folder = Path(row['folder']); process = read(folder / 'result.json')
                assert process['exit'] == 0 and process['image']['sha256'] == HISTORY_IMAGE
                raw = read(folder / 'consumer-result.json')
                assert row['observation']['raw'] == raw
                before.append(non_time(raw))
            assert all(value == before[0] for value in before)
            first = Path(selected[0]['folder'])
            current = next(row for row in rows_by_group[name] if row['arm'] == arm)
            now = reports[current['folder']]
            old = read(first / 'consumer-result.json')
            delta = differences(before[0], non_time(now))
            left, right = old['generated_ids'], now['generated_ids']
            first_id = next((i for i, (a, b) in enumerate(zip(left, right)) if a != b),
                            min(len(left), len(right)) if len(left) != len(right) else None)
            result.append(dict(group=name, current_arm=arm,
                historical_arm='hyle_mtp' if role == 'mtp' else 'hyle_auto',
                same_execution_mode=arm != 'hyle_plain', historical_image=HISTORY_IMAGE,
                historical_report=pin(first / 'consumer-result.json'), current_report=pin(Path(current['folder']) / 'consumer-result.json'),
                historical_candidate_complete_reports_stable=True, historical_processes=len(selected),
                all_generated_IDs_equal=left == right, first_ID_difference=first_id,
                complete_non_time_difference_count=len(delta), complete_non_time_differences=delta))
            sources.update([first / 'consumer-result.json', first / 'result.json'])
    save(W / 'historical-bb0c-non-time-differences.json', dict(
        scope='Complete producer facts, with the unchanged W13 non_time predicate; all changes remain explicit. Historical ordinary only measured auto, so current off is separately labeled a different execution mode.',
        historical_image=HISTORY_IMAGE, historical_summary=pin(HISTORY / 'summary-continuations.json'),
        historical_samples_pooled=False, causal_code_gain_claim=False, work_or_continuation_equality_assumed=False,
        comparisons=result))
    return result, sorted(sources)


def make_receipt(summary, ready, binding, groups, rows_by_group, reports):
    timing, cold, memory, work, relay, mtp = [], [], [], [], [], []
    for row in summary['table']:
        scenario, arm, stats, monitored = row['scenario'], row['arm'], row['timing'], row['independent_memory']
        timing.append(dict(scenario=scenario, arm=arm, prefill_tps=triple(stats.get('prefill_tokens_per_second')),
            decode_tps=triple(stats.get('full_decode_tokens_per_second')),
            session_output_tps=triple(stats.get('session_output_tokens_per_second')),
            session_processed_tps=triple(stats.get('session_processed_tokens_per_second'))))
        cold.append(dict(scenario=scenario, arm=arm, ready_seconds=triple(stats.get('startup_to_ready_seconds')),
            weights_load_seconds=triple(stats.get('weights_load_seconds')),
            first_token_seconds=triple(stats.get('first_token_elapsed_seconds')),
            startup_endpoint_seconds=triple(stats.get('startup_to_endpoint_seconds')),
            cold_output_tps=triple(stats.get('cold_output_tokens_per_second'))))
        peaks = monitored['sampled_peaks']
        memory.append(dict(scenario=scenario, arm=arm, independent_processes=1,
            GPU_dedicated_MiB=mib(peaks['sampled_peak_gpu_dedicated_bytes']),
            GPU_shared_MiB=mib(peaks['sampled_peak_gpu_shared_bytes']),
            GPU_same_sample_total_MiB=mib(peaks['sampled_peak_gpu_total_bytes']),
            RAM_working_set_MiB=mib(peaks['sampled_max_working_set_bytes']),
            RAM_private_commit_MiB=mib(peaks['sampled_max_private_commit_bytes']),
            ready_baseline=monitored['ready_baseline'], running_samples=monitored['running_sample_count'],
            actual_gap_ms={key: monitored['actual_sample_gaps_ms'].get(key) for key in ('median', 'min', 'max')},
            null_sample_counts=monitored['null_sample_counts']))
        first = next(item for item in rows_by_group[scenario + '-timing'] if item['arm'] == arm)
        raw = reports[first['folder']]
        fields = ('generated_tokens', 'generated_decode_tokens', 'actual_graph_calls', 'actual_target_rows',
            'committed_target_rows', 'verified_target_rows', 'committed_target_decode_rows', 'prefill_target_rows',
            'pending_flushed_tokens', 'accepted_drafts', 'consumed_drafts', 'draft_program_graph_calls',
            'prefix_decision_graph_calls', 'actual_draft_rows', 'draft_rounds', 'target_decode_calls',
            'draft_decode_calls', 'target_compute_calls', 'draft_compute_calls',
            'cache_shared_backing_bytes', 'cache_peak_requested_bytes')
        work.append(dict(scenario=scenario, arm=arm, actual={key: raw[key] for key in fields if key in raw},
            generated_IDs_report=pin(Path(first['folder']) / 'consumer-result.json')))
        if arm == 'hyle_auto':
            for name in (scenario + '-timing', scenario + '-memory'):
                for actual in rows_by_group[name]:
                    if actual['arm'] != arm:
                        continue
                    producer = reports[actual['folder']]
                    relay.append(dict(group=name, folder=actual['folder'],
                        submissions=producer['overlap_successor_submissions'], publications=producer['overlap_successor_publications'],
                        discards=producer['overlap_successor_discards'], refusals=producer['overlap_successor_refusals'],
                        final_available=producer['decode_overlap_available']))
    for group, rows in rows_by_group.items():
        for row in rows:
            if not row['arm'].endswith('_mtp'):
                continue
            raw = reports[row['folder']]
            rounds = raw['rounds']
            batches = raw.get('batches', [])
            counts = {}
            for batch in batches:
                key = (batch['role'], batch['generation'], batch['tokens'], batch['requests'])
                counts[key] = counts.get(key, 0) + 1
            mtp.append(dict(group=group, arm=row['arm'], pid=row['process']['pid'],
                rounds=len(rounds), accepted_rounds=sum(bool(x['accepted_draft']) for x in rounds),
                accepted_drafts=raw['accepted_drafts'], actual_target_rows=raw['actual_target_rows'],
                actual_draft_rows=raw['actual_draft_rows'], verified_target_rows=raw['verified_target_rows'],
                committed_target_rows=raw['committed_target_rows'],
                Hyle_batch_episode_count=len(batches) if 'batches' in raw else None,
                Hyle_batch_roles=[dict(role=key[0], generation=key[1], rows=key[2], R=key[3], count=count)
                    for key, count in sorted(counts.items())],
                peer_compute_calls={key: raw[key] for key in ('target_compute_calls', 'draft_compute_calls',
                    'target_decode_calls', 'draft_decode_calls') if key in raw}))
    compare = []
    for scenario in ('single', 'two-turn'):
        lookup = {row['arm']: row['timing'] for row in summary['table'] if row['scenario'] == scenario}
        for arm, peer in (('hyle_plain', 'peer_plain'), ('hyle_auto', 'peer_plain'), ('hyle_mtp', 'peer_mtp'), ('hyle_auto', 'hyle_plain')):
            deltas = {}
            for field, label in (('prefill_tokens_per_second', 'prefill'),
                    ('full_decode_tokens_per_second', 'decode'),
                    ('session_output_tokens_per_second', 'session_output'),
                    ('session_processed_tokens_per_second', 'session_processed')):
                deltas[label] = round(100 * (lookup[arm][field]['median'] / lookup[peer][field]['median'] - 1), 6)
            compare.append(dict(scenario=scenario, Hyle=arm, peer=peer, median_delta_percent=deltas))
    gpu = []
    for name in GROUPS:
        for edge in ('before', 'after'):
            path = W / name / ('window-' + edge + '-gpu.stdout.log')
            gpu.append(dict(group=name, edge=edge, observed_csv=path.read_text().strip(), receipt=pin(path)))
    id_comparisons = {scenario: {key: {field: value.get(field) for field in
        ('left_tokens', 'right_tokens', 'equal', 'first_divergence')}
        for key, value in groups[scenario + '-timing']['between_arm_first_process_outputs'].items()}
        for scenario in ('single', 'two-turn')}
    return dict(schema='hyle.performance.review-current-window.v1' , date='2026-10-28',
        status='COMPLETE40_FIVE_ARMS_STABLE',
        scope='One uninstrumented CUDA Qwen3.5-2B window: five arms, R1 single-user single-turn and R1 single-user two consecutive turns. Two-turn is not B2. Current-window comparison only; no historical pooling or causal attribution.',
        counts=dict(CXX=1, links=1, SDK_CXX=0, NVCC=0, downloads=0, window_compiler_processes=0, timing_processes=30, separate_memory_processes=10,
            actual_model_processes=40, timing_samples_per_arm_scenario=3, memory_samples_per_arm_scenario=1),
        images=[dict(role='all three Hyle arms', **ready['image']), dict(role='retained local peer, not latest upstream', **read(W / 'peer-ready.json')['image'])],
        closure=dict(inputs=229, build_ready=pin(B / 'ready-model.json'), link_inputs=ready['inputs'],
            Model_snapshot=ready['compiled']['snapshot'], Model_object=ready['compiled']['object'],
            actual_Model_dependencies=ready['compiled']['actual_dependencies'],
            exact_header_include_chain=read(W / 'ready.json')['source_headers'],
            retained_CUDA_consumer_build=binding['retained_CUDA_consumer_build'],
            CLI_entry=frozen_plan_entry(binding),
            correctness_json=pin(CORRECTNESS.with_suffix('.json')), correctness_zip=pin(CORRECTNESS.with_suffix('.zip')),
            retained_protocol_json=pin(PROTOCOL_ARCHIVE.with_suffix('.json')),
            retained_protocol_zip=pin(PROTOCOL_ARCHIVE.with_suffix('.zip')),
            identity_policy='Prior archives identify source/recipe/header ancestry only; their samples and overwritten old image paths are not current measurements.'),
        hardware=dict(observed_GPU='NVIDIA GeForce RTX 4070', observed_driver='617.14',
            GPU_snapshots=gpu, runtime=ready['runtime'], peer_runtime=read(W / 'peer-ready.json')['runtime_environment'],
            compiler_and_native_versions='Exact compiler/SDK headers/dependency identities are in recorded build commands and actual-dependencies; fixed local peer433e is not latest upstream.'),
        configuration='N1/R1/C1024, greedy, prefix-cache off; same P154 and at most64 natural outputs per turn. Ordinary off/auto; MTP K1 explicitly overlap-off. Original target-only/full-MTP GGUF mapping.',
        metric_order='Timing arrays are [median,min,max] from three unmonitored processes; unknown/null stays unknown/null. No significance claim.',
        metric_definitions=[
            'Prefill TPS uses actual target prefill rows and the complete producer prefill endpoint; two-turn pending flush work remains charged.',
            'Decode TPS includes all draft/catchup, preparation, host and synchronization work in the original decode endpoint; numerator excludes each turn prefill first token.',
            'Comprehensive session output TPS is all actual emitted IDs divided by prefill+decode; committed-context processed TPS is separately retained.',
            'Ready, load, first-token and cold endpoint values are original producer host-wall observations, not GPU busy time or CPU execution time.'],
        timing_table=timing, within_window_median_comparison=compare,
        comparison_definition='100*(named Hyle median / named reference median - 1); reference is retained peer or current Hyle ordinary-off. Descriptive, not paired-process significance or cross-window causal code gain.',
        ready_and_cold_table=cold,
        memory_units='MiB (2^20 bytes). One independent monitored process, excluded from timing medians.',
        memory_table=memory, actual_work=work, actual_auto_relay=relay, actual_MTP_acceptance_and_episodes=mtp,
        consistency=dict(within_arm_complete_non_time_reports={name: groups[name]['within_arm_full_non_time_reports'] for name in GROUPS},
            within_arm_work={name: groups[name]['within_arm_work'] for name in GROUPS},
            cross_engine_first_process_ID_comparisons=id_comparisons,
            detail_policy='Full ID differences, actual rounds/work, complete raw non-time oracle and process timing/index remain in the ZIP.'),
        limits=[
            'Three timing observations and one independent memory observation per arm/scenario; medians/ranges are descriptive, without significance or broad quality claims.',
            'No old-window samples or percentages enter this table. The current review Model/headers and retained native closure are jointly measured; this is not a causal code-gain experiment against older windows. Correctness builds are separately referenced.',
            'Original 10ms-requested PSAPI/PDH sampling; actual gaps/nulls and ready samples are retained. Unknown readiness or unsupported counters are never replaced with zero.',
            'Dedicated/shared GPU and working-set/private-commit RAM are distinct. GPU total uses same-sample sums; sampled maxima are lower bounds, not an exact CUDA allocation or physical VRAM maximum.',
            'Logical shared backing/cache requested-byte telemetry is actual report data, not sampled physical RAM/VRAM peak.',
            'Auto counts preserve each actual submission/publication/discard/refusal/final-availability result. Overlapping A/B step lifetimes cannot be summed as decode wall time.',
            'Four-metric tables share workload family, generation policy and token budget, not bit-identical computed work. Within-arm complete reports are stable; actual cross-engine ID boundaries are retained without assuming equality or any old divergence index. Accepted rows/roles are retained.',
            'No new EOS, fault, full hidden-state equality, concurrency beyond R1, other-platform, or latest-upstream claim is established by this performance window.'])


def frozen_plan_entry(binding):
    return binding['CLI_entry']


def numbers():
    summary = read(W / 'summary.json')
    assert summary['status'] == 'COMPLETE40_FIVE_ARMS_STABLE'
    table = []
    for row in summary['table']:
        timing, memory = row['timing'], row['independent_memory']
        peaks = memory['sampled_peaks']
        table.append(dict(scenario=row['scenario'], arm=row['arm'],
            prefill_tps=triple(timing.get('prefill_tokens_per_second')),
            decode_tps=triple(timing.get('full_decode_tokens_per_second')),
            session_output_tps=triple(timing.get('session_output_tokens_per_second')),
            ready_seconds=triple(timing.get('startup_to_ready_seconds')),
            VRAM_dedicated_MiB=mib(peaks['sampled_peak_gpu_dedicated_bytes']),
            VRAM_shared_MiB=mib(peaks['sampled_peak_gpu_shared_bytes']),
            RAM_working_set_MiB=mib(peaks['sampled_max_working_set_bytes']),
            RAM_commit_MiB=mib(peaks['sampled_max_private_commit_bytes']),
            ready_baseline=memory['ready_baseline']))
    save(W / 'result-table.json', dict(status=summary['status'], processes=40,
        timing_array_order=['median','min','max'], table=table,
        limitation='Current window only; retained peer433e, not latest upstream. Three timing/one memory per arm/scenario; no causal or significance claim.'))
    print(json.dumps(table, ensure_ascii=False))


def main():
    summary, ready, binding, groups, rows_by_group, reports, processes = collect()
    receipt = make_receipt(summary, ready, binding, groups, rows_by_group, reports)
    historical, historical_files = history_comparison(rows_by_group, reports)
    receipt['consistency']['current_vs_historical_bb0c_non_time'] = dict(report=pin(W / 'historical-bb0c-non-time-differences.json'),
        comparison_count=len(historical), historical_samples_pooled=False, causal_code_gain_claim=False,
        rows=[{key: row[key] for key in ('group','current_arm','historical_arm','all_generated_IDs_equal','first_ID_difference','complete_non_time_difference_count')} for row in historical])
    save(W / 'process-index.json', processes)
    allowed = {'.json', '.py', '.log', '.txt', '.csv', '.cc', '.h'}
    skip = {'package-manifest.json', 'package-result.json', 'evidence-summary.json'}
    # Only evidence types: no model, SDK tree or compiler/link payload is traversed.
    paths = {path.resolve() for path in W.rglob('*') if path.is_file() and
        path.suffix.lower() in allowed and path.name not in skip and '__pycache__' not in path.parts}
    extra = [*historical_files, CORRECTNESS.with_suffix('.json'), PROTOCOL_ARCHIVE.with_suffix('.json'),
        Path(binding['retained_CUDA_consumer_build']['path']),
        Path(binding['protocol']['path']), Path(binding['prompt']['path']), Path(binding['input_manifest']['path']),
        Path(binding['schedule']['path']), Path(binding['GGUF_metadata_receipt']['path']),
        Path(binding['parser_amendment_reused']['path']), Path(binding['retained_previous_runner']['path'])]
    peer = read(W / 'peer-ready.json')
    extra.extend(Path(peer[key]['path']) for key in ('source', 'compiled_identity', 'runtime_environment', 'link_plan', 'current_entry'))
    for name in GROUPS:
        group_plan = read(W / (name + '-plan.json'))
        extra += [Path(group_plan['script']['path']), *[Path(item['path']) for item in group_plan['helpers']]]
    paths.update(path.resolve() for path in extra)
    assert all(path.stat().st_size < 4 * 1024 * 1024 for path in paths if not path.is_relative_to(W)), 'Unexpected payload: inspect instead of copying SDK/models'
    OUT.parent.mkdir(parents=True, exist_ok=True)
    assert all(path.is_file() and path.is_relative_to(R) and path.suffix.lower() not in FORBIDDEN for path in paths)
    manifest = [dict(member=path.relative_to(R).as_posix(), **pin(path)) for path in sorted(paths)]
    save(W / 'package-manifest.json', dict(files=manifest,
        dependency_policy='No SDK/model/binary payload copied; exact 229-input closure and runtime pins retained, numerical/build sources in referenced correctness package.'))
    compact(W / 'evidence-summary.json', receipt)
    archive = OUT.with_suffix('.zip')
    assert not archive.exists() and not OUT.with_suffix('.json').exists(), 'Never replace a released performance package'
    with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for row in manifest:
            z.write(row['path'], row['member'])
        for path in (W / 'package-manifest.json', W / 'evidence-summary.json'):
            z.write(path, path.relative_to(R).as_posix())
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None and len(z.namelist()) == len(manifest) + 2
        assert not any(Path(name).suffix.lower() in FORBIDDEN for name in z.namelist())
        for row in manifest:
            body = z.read(row['member'])
            assert len(body) == row['bytes'] and hashlib.sha256(body).hexdigest() == row['sha256']
        assert json.loads(z.read((W / 'evidence-summary.json').relative_to(R).as_posix())) == receipt
        total_bytes = sum(item.file_size for item in z.infolist())
    receipt['archive'] = dict(**pin(archive), files=len(manifest) + 2, uncompressed_bytes=total_bytes)
    receipt['manifest'] = pin(W / 'package-manifest.json')
    compact(OUT.with_suffix('.json'), receipt)
    assert read(OUT.with_suffix('.json')) == receipt
    assert OUT.with_suffix('.json').stat().st_size < 100_000, 'Keep the human-facing receipt compact'
    result = dict(status='PACKAGED_AND_READ_BACK_VERIFIED', receipt=pin(OUT.with_suffix('.json')),
        archive=receipt['archive'], new_model_or_compiler_processes=0)
    save(W / 'package-result.json', result)
    print(json.dumps(result))


if __name__ == '__main__':
    import sys
    if len(sys.argv) == 2 and sys.argv[1] == 'numbers': numbers()
    else:
        assert len(sys.argv) == 1
        main()
