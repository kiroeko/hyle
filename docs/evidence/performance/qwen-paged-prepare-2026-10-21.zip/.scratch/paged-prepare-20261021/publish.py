"""Publish this executed two-algorithm batch; no builds, devices or deletion."""
from pathlib import Path
import hashlib
import json
import statistics
import zipfile

S = Path(__file__).resolve().parent
R = S.parents[1]
E = R / 'docs/evidence/performance'
STEM = 'qwen-paged-prepare-2026-10-21'

def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))

def identity(path):
    path = Path(path).resolve()
    data = path.read_bytes()
    name = path.relative_to(R).as_posix() if path.is_relative_to(R) else str(path)
    return dict(path=name, bytes=len(data), sha256=hashlib.sha256(data).hexdigest())

def verify(record):
    path = Path(record['path'])
    if not path.is_absolute():
        path = R / path
    actual = identity(path)
    assert (actual['bytes'], actual['sha256']) == (record['bytes'], record['sha256']), path

def stats(values):
    return dict(count=len(values), samples=values, median=statistics.median(values), min=min(values), max=max(values))

independent = S / 'performance/independent-review.json'
assert independent.is_file(), 'Wait for finite independent raw review'
timing = read(S / 'performance/timing/summary.json')
runs = read(S / 'performance/timing/runs.json')
memory = read(S / 'performance/memory/summary.json')
assert len(runs) == 12 and timing['same_Hyle_predictions']
assert len(read(S / 'performance/memory/runs.json')) == 4
for mode in ('timing', 'memory'):
    for row in read(S / 'performance' / mode / 'runs.json'):
        assert row['process']['exit'] == 0 and not row['process'].get('timeout')
        verify(row['process']['image'])
        raw = row['observation']['raw']
        assert raw['processed_tokens'] == 864 and raw['generated_tokens'] == 99
        assert [p['context_after'] for p in raw['phases']] == [256, 288, 544, 576, 832, 864]
        if row['arm'] == 'hyle':
            assert raw['diagnostic'] is False
groups = {}
for variant, group in timing['groups'].items():
    selected = [x for x in runs if x['variant'] == variant]
    groups[variant] = dict(metrics=group['metrics'], phases=group['phases'], loading=group['loading'],
        complete_decode_tps=stats([96 / sum(p['seconds'] for p in x['observation']['raw']['phases'] if p['kind'] == 'decode') for x in selected]),
        memory_peaks=memory['groups'][variant]['sampled_peaks'],
        memory_gap_ms={k:v for k,v in memory['groups'][variant]['actual_sample_gaps_ms'].items() if k != 'samples'},
        phase_dedicated_peak_bytes={k:v['values']['gpu_dedicated_bytes']['max'] for k,v in memory['groups'][variant]['phase_windows'].items()})
single, multi = read(S / 'single-run1/summary.json'), read(S / 'multi-run1/summary.json')
assert single['passed'] and multi['passed'] and single['vector_count'] == 18 and multi['vector_count'] == 72
pairs = [*single['pairs'], *(p for ss in multi['sessions'].values() for p in ss)]
for pair in pairs:
    verify(pair['baseline']); verify(pair['actual'])
    assert pair['byte_equal']
for mode in ('cpu', 'cuda'):
    assert read(S / (mode + '-run1/result.json'))['exit'] == 0
ready = read(S / 'qwen-ready.json')
verify(ready['image'])
link = read(ready['link_plan']['path'])
for item in link['inputs']:
    verify(item)
assert len(link['inputs']) == 192

order = ['current', 'before', 'dense', 'peer']
def median(arm, key):
    return groups[arm]['metrics'][key]['median']
def row(label, values, places=2):
    return '| ' + label + ' | ' + ' | '.join(f'{x:.{places}f}' for x in values) + ' |\n'
table = '| 指标 | 当前分页Hyle | 本批修复前paged | 原dense Hyle | llama.cpp |\n| --- | ---: | ---: | ---: | ---: |\n'
for turn in (1, 2, 3):
    table += row(f'第{turn}轮prefill tok/s', [groups[a]['phases'][f'round{turn}_prefill']['median'] for a in order])
for turn in (1, 2, 3):
    table += row(f'第{turn}轮完整decode tok/s', [groups[a]['phases'][f'round{turn}_decode']['median'] for a in order])
table += row('完整decode合计 tok/s（96／三段decode总wall）', [groups[a]['complete_decode_tps']['median'] for a in order])
table += row('综合输出 tok/s（99／会话wall）', [median(a, 'output_tokens_per_second') for a in order])
table += row('会话wall s', [median(a, 'session_seconds') for a in order], 5)
table += row('消费者入口至末输出 s（含加载／冷准备）', [median(a, 'startup_total_seconds') for a in order], 5)
table += row('启动至ready s', [groups[a]['loading']['startup_to_ready_seconds']['median'] for a in order], 5)
for label, key in [('GPU dedicated全程观测峰 GiB', 'sampled_peak_gpu_dedicated_bytes'),
                   ('GPU shared全程观测峰 GiB', 'sampled_peak_gpu_shared_bytes'),
                   ('进程working set观测峰 GiB', 'sampled_max_working_set_bytes'),
                   ('进程private commit观测峰 GiB', 'sampled_max_private_commit_bytes')]:
    table += row(label, [groups[a]['memory_peaks'][key] / 2**30 for a in order], 3)
tail = '''## 最新完整性能对比

**2026-10-21，无用lease查找与页集合算法修复后的完整四臂测试。** RTX 4070 12GB／Windows，Qwen3.5-2B BF16、F32 GDN、无MTP／图片；单会话三轮`256输入＋32 decode`，同固定ID、容量1024、最终上下文864。
当前`aa4868c5…`、本批修复前paged `ff42c532…`、原dense `ff748694…`、llama.cpp `9b259137…`／`d9e03f1074db…`；各3进程交错测速，显存另各1进程旁采，trace／准备诊断关闭。current与before仅替换Graph端口准备及append页集合两个对象，权重、main、Provider及全部其它链接输入相同。四臂都复用完整历史，只计算新增输入，没有淘汰／重建；尚未测完整模型共享前缀命中、多人吞吐或Spark。

''' + table + '''
本窗current比before完整decode约快**9.9%**、综合约快**8.9%**；比llama完整decode慢约**4.6%**、综合慢约**1.8%**，比原dense decode慢约4.1%。各3进程：current decode范围100.47–101.01、before91.58–91.74、dense104.93–105.07、参考104.83–105.50tok/s；对应综合89.67–90.51／82.83–83.00／93.47–93.97／91.05–92.24。该窗样本集中，收益只归本批两项通用修改的组合，不拆成单函数贡献，也不与此前窗口合算或签长期稳定胜出。
零重录decode的准备桶三轮中位current约**0.243／0.248／0.291ms**，before约**0.741／1.173／1.604ms**；这是现有完整准备桶，不能解释成纯函数自耗时。长旅程仍每进程90／96次decode为0录制／7复用，2次首用7／0、4次6／1；原真实边界失效保留。
current／before专用GPU峰同为4.114GiB，各阶段P1→D1→P2→D2→P3→D3同为 **3.995→4.005→4.110→4.112→4.112→4.114**；dense **3.956→3.972→4.077→4.081→4.081→4.085**，参考 **4.191→4.194→4.194→4.194→4.194→4.194**。current仍比dense高30MiB、比参考低约82MiB；不能把差值全部归因状态载荷。实际旁采间隔中位current／before／dense／参考约15.10／15.43／15.23／15.18ms，严格边界占用未知，GPU峰是采样下界；CPU与GPU不相加。
未固定时钟或独占GPU。窗口前后nvidia-smi利用率14%／99%、SM210／2820MHz是滚动快照，后者可能包含刚结束的消费者，不能据此称外部背景干扰；此前窗口53%／57%也不足以定位波动原因。12个计时与4个内存进程的99个预测ID均相同，不代表独立模型质量验收。
[全部样本、源码、原CPU／CUDA与18／72向量回归、独立复核](../evidence/performance/qwen-paged-prepare-2026-10-21.json)；[前一完整窗口](../evidence/performance/qwen-paged-recording-2026-10-21.json)。剩余COW／分散复制、元数据／发布及多capture范围成本继续核查，与精确前缀功能接入同步推进。
'''
work = R / 'docs/developer/current-work.md'
text = work.read_text(encoding='utf-8')
work.write_text(text.split('## 最新完整性能对比')[0] + tail, encoding='utf-8')

product_paths = {x['source']['path'] for name in ('compiled-core.json', 'compiled-append.json') for x in read(S / name)['records']}
for name in ('tools/qwen35_text/main.cc', 'tools/qwen35_text/session_state.h', 'src/graph/resources.cc',
             'src/graph_batch/batch.cc', 'include/hyle/graph/detail/region_access.h',
             'src/graph_provider_ggml_cuda/ggml_cuda_region.cc'):
    product_paths.add(str(R / name))
files = {}
allowed = {'.py', '.json', '.log', '.xml', '.tsv', '.diff', '.cc', '.h'}
for path in S.rglob('*'):
    if path.is_file() and path.suffix in allowed:
        files[path.relative_to(R).as_posix()] = path
for name in product_paths:
    path = Path(name)
    files['product/' + path.relative_to(R).as_posix()] = path
for name in ('docs/developer/current-work.md', 'docs/developer/performance/decode.md'):
    files['documentation/' + name] = R / name
zpath = E / (STEM + '.zip')
members = []
with zipfile.ZipFile(zpath, 'w', zipfile.ZIP_DEFLATED, compresslevel=7) as archive:
    for name, path in sorted(files.items()):
        data = path.read_bytes()
        archive.writestr(name, data)
        members.append(dict(member=name, bytes=len(data), sha256=hashlib.sha256(data).hexdigest()))
with zipfile.ZipFile(zpath) as archive:
    assert archive.testzip() is None
report = dict(schema='hyle.qwen-paged-prepare.v1', date='2026-10-21',
    status='Two generic preparation algorithm changes executed and measured; exact prefix cache, remaining performance and other goal lines are unfinished',
    implementation=dict(image=ready['image'], product=[identity(p) for p in sorted(product_paths)],
                        host_CXX=3, NVCC=0, SDK_builds=0, links=3,
                        current_before_only_changed_link_owners=['src/graph/executable.cc', 'src/graph_batch/paged_append.cc']),
    correctness=dict(CPU_original_and_permuted_shared_journey_exit=0, CUDA_original_COW_dependency_stale_submit_exit=0,
                     single_vectors=18, four_session_vectors=72, all_byte_identical=True,
                     vector_pairs=pairs, restored_calls=18, restored_tokens=185),
    workload=read(S / 'performance/timing/inputs.json'), groups=groups,
    timing_processes=12, memory_processes=4, per_arm_timing_processes=3,
    statistical_significance=False, independent_quality_acceptance=False,
    independent_review=identity(independent),
    source_reviews=[identity(S / 'lease-review.json'), identity(S / 'append-independent-review.json'), identity(S / 'tests/source-review.json')],
    algorithm=[
        'Only the exact positively proven borrowed TensorView carrier skips its unconsumed input lease lookup; every unproven native import path and actual episode ownership/admission remains.',
        'Every old frame guard validates arena/root/generation/range once. Call-local sorted dirty indices preserve caller ordinals; binary lookup and sorted final/old intersection replace quadratic searches.',
        'Old readonly guards may be retained in existing ready-list storage during create; no new page publication occurs until successful retired whole Graph. Original dirty writers are consumed only after complete fallible validation/allocation.',
        'A later rejection before publication or arena.read metadata-allocation failure retains already published guards without duplicating old guards; no new recovery promise for illegal external mutation or internal complete failure.',
    ],
    interpretation=[
        'Within this finite window combined decode median improves about9.9% over exact previous paged closure and session output about8.9%. Current decode remains about4.6% below reference; the goal is not complete.',
        'Current/before share identical dedicated GPU sampled peak. No proof of lower full-process peak or independent component attribution.',
        'Counters, native layout/token/physical identity, source close/failure and actual retirement gates remain. Fresh page permissions cannot be replaced with retained recording authority.',
        'Current/previous/dense/reference are four single-session paths; no full prefix-hit or concurrent GPU throughput result. Other seven model consumers are not qualified by Qwen.',
        'Samples are finite, not fixed-clock/exclusive. Nvidia-smi utilization may include recently completed consumers; do not equate window snapshots with independently measured external background load.',
        'The reference retains original F32 intermediates and its natural greedy/logits readback. Same BF16 checkpoint/fixed IDs/host-token boundaries do not make every intermediate operation identical.',
        'No new Linux/Apple/Vulkan native runtime execution or native append writer verification in this change. Existing cross-system ownership limits remain.',
    ],
    parent='docs/evidence/performance/qwen-paged-recording-2026-10-21.json',
    next='Bounded exact complete-state prefix lookup/fork; investigate remaining measured COW/copy/preparation/launch costs in parallel. No old dense executor compatibility fallback.',
    archive=identity(zpath), members=members, goal_complete=False)
out = E / (STEM + '.json')
out.write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps(dict(report=identity(out), archive=identity(zpath), members=len(members)), ensure_ascii=False))
