"""Only changed host owners and the existing CPU append fixture; no SDK/NVCC."""
from pathlib import Path
import argparse
import concurrent.futures
import importlib.util
import sys
sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
R = S.parents[1]
P = R / '.scratch/paged-append-20261021'
V = R / '.scratch/paged-recording-20261021'
W = R / '.scratch/architecture-refactor-2026-10-18/d4-windows-preparation-2026-10-21/first-decode-startup-2026-10-21/layout-workspace-facts-reuse-2026-10-21'
spec = importlib.util.spec_from_file_location('retained_host', W / 'build.py')
h = importlib.util.module_from_spec(spec)
spec.loader.exec_module(h)
b, c = h.b, h.c
parser = argparse.ArgumentParser()
parser.add_argument('phase', choices=('core', 'append'))
args = parser.parse_args()
jobs = [('src/graph/executable.cc', P / 'qwen-snapshot/unbind/checks/attempt2/graph--executable/identity.json')] if args.phase == 'core' else [
    ('src/graph_batch/paged_append.cc', V / 'checks/attempt1/graph_batch--paged_append/identity.json'),
    ('tests/graph_batch/paged_append_graph_test.cc', P / 'symbolic-rows/checks/attempt2/graph_batch--paged_append_graph_test/identity.json'),
]

def one(job):
    path, recipe = job
    source = R / path
    tag = source.parent.name + '--' + source.stem
    out = S / 'checks/attempt1' / tag
    out.mkdir(parents=True, exist_ok=False)
    (out / 'tmp').mkdir()
    frozen = b.identity(source)
    command = b.host_command(c.read(recipe)['command'], source, tag, out)
    c.save(out / 'compile-plan.json', dict(command=command, source=frozen,
        recipe=b.identity(recipe), CXX=1, NVCC=0, SDK_builds=0))
    env, _ = b.environment(command, [], out)
    c.execute('compile', command, env, out)
    deps = c.read(out / (tag + '-deps.json'))['Data']
    record = dict(source=frozen, object=b.identity(out / (tag + '.obj')), command=command,
        dependencies=[b.identity(p) for p in dict.fromkeys([deps['Source'], *deps['Includes']])])
    assert h.same(frozen) and all(h.same(x) for x in record['dependencies'])
    c.save(out / 'identity.json', record)
    return record

with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
    records = list(pool.map(one, jobs))
c.save(S / ('compiled-' + args.phase + '.json'), dict(records=records, CXX=len(records), NVCC=0, SDK_builds=0, GPU_runs=0))
print('Compiled related ' + args.phase + ' host owners.', flush=True)
