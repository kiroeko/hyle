"""Integrate changed owners into three retained, explicitly scoped closures."""
from pathlib import Path
import argparse
import importlib.util
import os
import re
import sys
sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
R = S.parents[1]
P = R / '.scratch/paged-append-20261021'
V = R / '.scratch/paged-recording-20261021'
W = R / '.scratch/architecture-refactor-2026-10-18/d4-windows-preparation-2026-10-21/first-decode-startup-2026-10-21/layout-workspace-facts-reuse-2026-10-21'
spec = importlib.util.spec_from_file_location('retained_host', W / 'build.py')
h = importlib.util.module_from_spec(spec)
spec.loader.exec_module(h)
b, c = h.b, h.c
parser = argparse.ArgumentParser()
parser.add_argument('mode', choices=('qwen', 'cuda', 'cpu'))
args = parser.parse_args()
mode = args.mode
base_ready = P / 'symbolic-rows/cpu-ready.json' if mode == 'cpu' else V / (mode + '-ready.json')
prior = c.read(base_ready)
base = c.read(prior['link_plan']['path'])
assert all(h.same(x) for x in base['inputs'])
records = c.read(S / 'compiled-core.json')['records'] + c.read(S / 'compiled-append.json')['records']
if mode != 'cpu':
    records = [row for row in records if Path(row['source']['path']).name != 'paged_append_graph_test.cc']
else:
    # The CPU fixture's previous image predates the common unbind/recording
    # changes. Refresh every ProjectedReader owner with already compiled host
    # objects instead of mixing different private aggregate layouts.
    records += [row for row in c.read(V / 'compiled.json')['records']
        if Path(row['source']['path']).name in ('resources.cc', 'batch.cc', 'native_batch_regions.cc', 'native_pending_regions.cc')]
for row in records:
    assert h.same(row['source']) and h.same(row['object'])
    assert all(h.same(x) for x in row['dependencies'])
replacements = {}
for row in records:
    source = Path(row['source']['path'])
    tag = source.parent.name + '--' + source.stem
    matches = [x for x in base['inputs'] if re.search(r'(^|--)' + re.escape(tag) + r'(?:-[0-9a-f]+)?$', Path(x['path']).stem)]
    assert len(matches) == 1, (tag, matches)
    replacements[c.key(matches[0]['path'])] = row['object']
extra = []
if mode == 'cpu':
    result = c.read(P / 'qwen-snapshot/result-detach/checks/attempt1/identity.json')
    assert h.same(result['source']) and h.same(result['object'])
    if not any(c.key(x['path']) == c.key(result['object']['path']) for x in base['inputs']):
        extra = [result['object']]
out = S / (mode + '-link1')
out.mkdir(parents=True, exist_ok=False)
(out / 'tmp').mkdir()
image = out / (mode + '.exe')
inputs = [replacements.get(c.key(x['path']), x) for x in base['inputs']] + extra
command = [replacements[c.key(x)]['path'] if c.key(x) in replacements else x for x in base['command']
           if not x.upper().startswith(('/OUT:', '/MAP:', '/IMPLIB:', '/PDB:'))]
command += [x['path'] for x in extra]
command += ['/OUT:' + str(image), '/MAP:' + str(image.with_suffix('.map')), '/IMPLIB:' + str(image.with_suffix('.lib'))]
c.save(out / 'link-plan.json', dict(command=command, inputs=inputs, base=b.identity(prior['link_plan']['path']),
    replaced_inputs=list(replacements.values()), added_inputs=extra, CXX=0, NVCC=0, links=1, SDK_builds=0))
env, _ = b.environment(command, [x['path'] for x in inputs], out)
c.execute('link', command, env, out)
for dll in Path(prior['image']['path']).parent.glob('*.dll'):
    os.link(dll, out / dll.name)
runtime = c.read(prior['runtime_environment']['path'])
runtime['PATH'] = env['PATH']
runtime['staged_dlls'] = [b.identity(x) for x in out.glob('*.dll')]
runtime['scope'] = 'Current generic borrowed-only lookup and validated append page-set algorithm. Native shared CPU or CUDA route only; no native Apple/Vulkan writer claim.'
if mode == 'cpu' and 'CPU_native_overlay' in runtime:
    runtime['CPU_native_overlay']['destination'] = b.identity(out / 'hyle_ggml_cpu_append_hyca.dll')
c.save(out / 'runtime-environment.json', runtime)
c.save(S / (mode + '-ready.json'), dict(image=b.identity(image), source=prior['source'] if mode != 'cpu' else next(x['source'] for x in records if Path(x['source']['path']).name == 'paged_append_graph_test.cc'),
    link_plan=b.identity(out / 'link-plan.json'), runtime_environment=b.identity(out / 'runtime-environment.json'),
    fresh_sources=[x['source'] for x in records], prior=b.identity(base_ready),
    CXX=0, links=1, NVCC=0, SDK_builds=0, GPU_runs=0))
print('LINKED', mode, image, flush=True)
