#include <hyle/compute/backends/cpu.h>
#include <hyle/compute/custom_kernel.h>
#include <hyle/compute/providers/ggml_cpu.h>
#include <hyle/graph/batch.h>
#include <hyle/simd/dtype.h>
#include <array>
#include <bit>
#include <cmath>
#include <cstdio>
#include <vector>
#if !defined(HYLE_APPEND_STANDALONE)
#include <gtest/gtest.h>
#endif
namespace {
namespace c=hyle::compute;namespace g=hyle::graph;namespace gb=g::batch;
using hyle::Status;using hyle::Result;
Status check(bool v,const char*s){return v?Status::Ok():Status::Internal(s);}
constexpr c::ProviderRuntimeProperties runtime{.mode=c::ProviderRuntimeMode::kSharedQueue,
 .workspace_owner=c::ProviderWorkspaceOwner::kCaller,.replay_class=c::ProviderReplayClass::kPrepared};
struct Reject final {
 static constexpr c::OperationId operation_id{0x48594c4554455354ULL,0x415050454e444641ULL};
 static constexpr std::string_view operation_name="test-reject-after-append";
 constexpr c::OperationTraits operation_traits()const noexcept{return {{0,0},0,c::AliasPolicy::kNone,c::EffectKind::kExternalSideEffect};}
 Status infer_output_descriptions(std::span<const c::TensorDesc>in,std::span<c::TensorDesc>out)const noexcept{
  return in.empty() && out.empty()?Status::Ok():Status::InvalidArgument("test rejection has no tensors");}
};
struct RejectKernel final {
 struct Invocation final {};
 Result<Invocation>create_invocation(hyle::mem::BufferView,hyle::mem::AllocatorRef)const noexcept{return Invocation{};}
 c::KernelCommandResult enqueue(Invocation&,c::detail::QueueSequence&,std::span<const c::ConstTensorView>,std::span<const c::TensorView>)const noexcept{
  return c::KernelCommandResult::rejected(Status::Internal("intentional error after the real append prefix"));}
};
struct RejectFactory final {
 Result<c::KernelProposal>propose(const c::KernelRequest&r,std::span<c::ResourceRequirement>,std::span<c::ResourceRequirement>)const noexcept{
  if(!r.operation.custom_as<Reject>())return std::unexpected(Status::Unimplemented("not the rejection test"));return c::KernelProposal{.runtime=runtime};}
 c::KernelPreparation prepare(const c::KernelPrepareRequest&r,hyle::mem::AllocatorRef a)const noexcept{
  if(!r.operation.custom_as<Reject>())return c::KernelPreparation::unsupported(Status::Unimplemented("not the rejection test"));
  auto kernel=c::make_custom_kernel(RejectKernel{},{.workspace={0,1},.runtime=runtime,.persistent_bytes=0,.invocation_private_bytes=0},a);
  return kernel?c::KernelPreparation::prepared(std::move(*kernel)):c::KernelPreparation::error(kernel.error());}
};
std::uint16_t word(float x,bool bf){return bf?hyle::simd::f32_to_bf16(x).bits:hyle::simd::f32_to_f16(x).bits;}
float number(std::uint16_t x,bool bf){return bf?std::bit_cast<float>(std::uint32_t(x)<<16):hyle::simd::f16_to_f32({x});}
Result<c::ReadLease>load(c::LeasePool&pool,std::span<const std::uint16_t>data){
 HYLE_ASSIGN_OR_RETURN(auto writer,pool.allocate(data.size_bytes(),64));HYLE_RETURN_IF_ERROR(writer.view()->write(std::as_bytes(data)));return writer.publish();}
Status run(bool bf,bool missing_edge,bool failure){
 const auto memory=hyle::mem::system_resource();
 HYLE_ASSIGN_OR_RETURN(auto failure_provider,c::make_custom_provider({{0x48594c45,0x41505046},"append-rejection-test","1"},c::cpu::kBackendId,RejectFactory{}));
 const std::array providers{c::ProviderBinding{c::ggml_cpu::provider(),0},c::ProviderBinding{failure_provider,0}};
 HYLE_ASSIGN_OR_RETURN(auto context,c::Context::create(c::cpu::device(),{.providers=providers}));HYLE_ASSIGN_OR_RETURN(auto queue,context.create_queue());
 struct Drain{c::Context&context;~Drain(){context.drain().IgnoreError();}}drain{context};
 const auto type=bf?c::DataType::kBFloat16:c::DataType::kFloat16;
 HYLE_ASSIGN_OR_RETURN(auto plain,c::CacheStorage::plain(type));
 c::BatchCapacity cap{.query_type=type,.output_type=type,.key_storage=plain,.value_storage=plain,.max_requests=1,
  .max_query_rows=2,.max_kv_rows=8,.max_pages=6,.max_page_refs=4,.query_heads=2,.kv_heads=1,.qk_head_dim=64,.value_head_dim=64,.page_size=2};
 HYLE_ASSIGN_OR_RETURN(auto schema,c::BatchSchema::create(cap));
 const std::array<std::int32_t,2>old_q{0,1},new_q{0,2},old_ptr{0,2},new_ptr{0,3},old_ids{0,1};
 const std::array<std::int32_t,3>new_ids{0,2,3};const std::array<std::int32_t,1>tail{1};
 HYLE_ASSIGN_OR_RETURN(auto old_layout,schema.version({old_q,old_ptr,old_ids,tail}));
 HYLE_ASSIGN_OR_RETURN(auto layout,schema.version({new_q,new_ptr,new_ids,tail}));
 HYLE_ASSIGN_OR_RETURN(auto keys,c::PagedArena::create(schema,c::BatchCacheRole::kKey,memory,{.max_backing_bytes=4096}));
 HYLE_ASSIGN_OR_RETURN(auto values,c::PagedArena::create(schema,c::BatchCacheRole::kValue,memory,{.max_backing_bytes=4096}));
 std::array<c::ReadLease,2>old_k,old_v;
 for(unsigned page=0;page<2;++page){HYLE_ASSIGN_OR_RETURN(auto k,keys.acquire(page));HYLE_ASSIGN_OR_RETURN(auto v,values.acquire(page));
  std::vector<std::uint16_t>zero(128,0),data(128,word(.375f,bf));if(!page){std::fill_n(data.begin(),64,word(.125f,bf));std::fill(data.begin()+64,data.end(),word(.25f,bf));}
  HYLE_RETURN_IF_ERROR(k.lease().view()->write(std::as_bytes(std::span(zero))));HYLE_RETURN_IF_ERROR(v.lease().view()->write(std::as_bytes(std::span(data))));
  HYLE_ASSIGN_OR_RETURN(old_k[page],k.publish(page?1:2));HYLE_ASSIGN_OR_RETURN(old_v[page],v.publish(page?1:2));}
 HYLE_ASSIGN_OR_RETURN(auto previous_k,keys.read(old_layout,old_k));HYLE_ASSIGN_OR_RETURN(auto previous_v,values.read(old_layout,old_v));
 std::array<c::PagedPageWriter,2>dirty_k,dirty_v;
 for(unsigned i=0;i<2;++i){HYLE_ASSIGN_OR_RETURN(dirty_k[i],keys.acquire(i+2));HYLE_ASSIGN_OR_RETURN(dirty_v[i],values.acquire(i+2));}
 // Foreign arena generations must be rejected without consuming a reservation.
 auto foreign=gb::PagedAppendPages::create(keys,layout,previous_k,dirty_v);
 HYLE_RETURN_IF_ERROR(check(!foreign && dirty_v[0].lease().valid() && dirty_v[1].lease().valid(),"foreign append consumed a writer"));
 HYLE_ASSIGN_OR_RETURN(auto append_keys,gb::PagedAppendPages::create(keys,layout,previous_k,dirty_k));
 HYLE_ASSIGN_OR_RETURN(auto append_values,gb::PagedAppendPages::create(values,layout,previous_v,dirty_v));
 HYLE_ASSIGN_OR_RETURN(auto rows,c::TensorDesc::dense(type,std::array<std::int64_t,3>{2,1,64}));
 HYLE_ASSIGN_OR_RETURN(auto qdesc,c::batch_query_description(cap,2));HYLE_ASSIGN_OR_RETURN(auto kdesc,c::batch_cache_description(schema,c::BatchCacheRole::kKey));
 HYLE_ASSIGN_OR_RETURN(auto vdesc,c::batch_cache_description(schema,c::BatchCacheRole::kValue));
 HYLE_ASSIGN_OR_RETURN(auto builder,g::GraphBuilder::create());
 HYLE_ASSIGN_OR_RETURN(auto q,builder.input(qdesc));HYLE_ASSIGN_OR_RETURN(auto new_k,builder.input(rows));HYLE_ASSIGN_OR_RETURN(auto new_v,builder.input(rows));
 HYLE_ASSIGN_OR_RETURN(auto bank_k,builder.input(kdesc));HYLE_ASSIGN_OR_RETURN(auto bank_v,builder.input(vdesc));
 // Keep a logical view in the source DAG: batch discovery precedes its
 // specialization and must not ask it for a concrete Operation.
 HYLE_ASSIGN_OR_RETURN(auto row_view,g::ViewSpec::reshape(std::array{
   g::Dimension::fixed(2),g::Dimension::fixed(1),g::Dimension::fixed(64)}));
 HYLE_ASSIGN_OR_RETURN(auto viewed_k,builder.add(row_view,new_k));
 HYLE_ASSIGN_OR_RETURN(auto produced_k,builder.add(c::Copy{},viewed_k));HYLE_ASSIGN_OR_RETURN(auto produced_v,builder.add(c::Copy{},new_v));
 HYLE_ASSIGN_OR_RETURN(auto ka,gb::paged_append(schema,c::BatchCacheRole::kKey));HYLE_ASSIGN_OR_RETURN(auto va,gb::paged_append(schema,c::BatchCacheRole::kValue));
 HYLE_ASSIGN_OR_RETURN(auto kw,builder.add_node(c::Operation::custom(ka),std::array{produced_k}));
 HYLE_ASSIGN_OR_RETURN(auto vw,builder.add_node(c::Operation::custom(va),std::array{produced_v}));HYLE_RETURN_IF_ERROR(builder.depends_on(vw,kw));
 g::NodeId reject;if(failure){HYLE_ASSIGN_OR_RETURN(reject,builder.add_node(c::Operation::custom(Reject{}),{}));HYLE_RETURN_IF_ERROR(builder.depends_on(reject,vw));}
 HYLE_ASSIGN_OR_RETURN(auto attention,gb::paged_attention(layout,{.scale=.125f}));
 HYLE_ASSIGN_OR_RETURN(auto node,builder.add_node(c::Operation::custom(attention),std::array{q,bank_k,bank_v}));
 if(!missing_edge){HYLE_RETURN_IF_ERROR(builder.depends_on(node,kw));HYLE_RETURN_IF_ERROR(builder.depends_on(node,vw));}
 if(failure)HYLE_RETURN_IF_ERROR(builder.depends_on(node,reject));
 HYLE_ASSIGN_OR_RETURN(auto output,builder.result(node));HYLE_RETURN_IF_ERROR(builder.publish(output));HYLE_ASSIGN_OR_RETURN(auto graph,std::move(builder).finish());
 const std::array domains{g::StorageDomain{memory}};HYLE_ASSIGN_OR_RETURN(auto source,g::ExecutionSource::acquire(context));
 const std::array targets{g::ExecutionTarget{source,g::StorageDomainId{0}}};
 HYLE_ASSIGN_OR_RETURN(auto compiled,gb::compile(graph,{.storage_domains=domains,.targets=targets}));
 HYLE_ASSIGN_OR_RETURN(auto invocation,compiled.executable.create_invocation({.resources=g::ResourceOptions{}}));
 const std::array queues{g::QueueBinding{g::ExecutionLaneId{0},&queue}};
 HYLE_RETURN_IF_ERROR(gb::prepare(invocation,queues,std::array{gb::NodeLayout{node,layout}},
  {.max_float_workspace_bytes=1u<<20,.max_int_workspace_bytes=64u<<10}));
 const auto key_binding=gb::bind_append(invocation,graph,kw,bank_k,std::move(append_keys));
 if(missing_edge){HYLE_RETURN_IF_ERROR(check(!key_binding.ok() && append_keys.valid() && append_keys.page(0)->lease().valid(),"missing Graph dependency consumed/accepted append"));
  std::puts("paged append missing original control edge preserves original pages PASS");return Status::Ok();}
 HYLE_RETURN_IF_ERROR(key_binding);HYLE_RETURN_IF_ERROR(gb::bind_append(invocation,graph,vw,bank_v,std::move(append_values)));
 HYLE_RETURN_IF_ERROR(check(!append_keys.valid() && !append_values.valid(),"successful bind failed to transfer page ownership"));
 HYLE_ASSIGN_OR_RETURN(auto pool,c::LeasePool::create(memory,8192,{.max_blocks=8}));
 std::vector<std::uint16_t>zero(256,0),incoming(128);std::fill_n(incoming.begin(),64,word(.5f,bf));std::fill(incoming.begin()+64,incoming.end(),word(.75f,bf));
 HYLE_ASSIGN_OR_RETURN(auto query,load(pool,zero));HYLE_ASSIGN_OR_RETURN(auto nk,load(pool,std::span(zero).first(128)));HYLE_ASSIGN_OR_RETURN(auto nv,load(pool,incoming));
 HYLE_RETURN_IF_ERROR(invocation.bind(q,qdesc,query));HYLE_RETURN_IF_ERROR(invocation.bind(new_k,rows,nk));HYLE_RETURN_IF_ERROR(invocation.bind(new_v,rows,nv));
 HYLE_ASSIGN_OR_RETURN(auto destination,pool.allocate(512,64));HYLE_ASSIGN_OR_RETURN(auto outdesc,c::batch_output_description(cap,2));HYLE_RETURN_IF_ERROR(invocation.bind(output,outdesc,std::move(destination)));
 HYLE_RETURN_IF_ERROR(invocation.prepare_replay(queues));HYLE_ASSIGN_OR_RETURN(auto done,invocation.submit(queues));
 const auto terminal=done.wait();done={};
 HYLE_RETURN_IF_ERROR(check(failure?!terminal.ok():terminal.ok(),"append Graph terminal differs"));
 bool actual_correct=true;
 if(!failure){HYLE_ASSIGN_OR_RETURN(auto actual,invocation.result(output));HYLE_ASSIGN_OR_RETURN(auto lease,actual.storage_lease());
  std::array<std::uint16_t,256>words{};HYLE_RETURN_IF_ERROR(lease.view()->read(std::as_writable_bytes(std::span(words))));
  for(std::size_t i=0;i<words.size();++i){if(std::abs(number(words[i],bf)-(i<128?.3125f:.4f))>=.003f)
      std::fprintf(stderr,"append oracle index=%zu actual=%.8g expected=%.8g type=%s\n",i,double(number(words[i],bf)),i<128?.3125:.4,bf?"BF16":"F16");
    actual_correct=actual_correct && std::abs(number(words[i],bf)-(i<128?.3125f:.4f))<.003f;}}
 HYLE_ASSIGN_OR_RETURN(auto returned_k,gb::take_append(invocation,kw));HYLE_ASSIGN_OR_RETURN(auto returned_v,gb::take_append(invocation,vw));
 HYLE_RETURN_IF_ERROR(check(!keys.acquire(1) && !values.acquire(1),"append overwrote the retained old snapshot"));
 if(failure){HYLE_RETURN_IF_ERROR(check(!returned_k.ready() && !returned_v.ready(),"failed append published ready pages"));
  for(std::size_t i=0;i<2;++i){HYLE_ASSIGN_OR_RETURN(auto&k,returned_k.page(i));HYLE_ASSIGN_OR_RETURN(auto&v,returned_v.page(i));k.lease().reset();v.lease().reset();HYLE_RETURN_IF_ERROR(k.discard());HYLE_RETURN_IF_ERROR(v.discard());}
  std::puts("paged append accepted-prefix error retains old snapshot, rejects publication, recovers original pages PASS");return Status::Ok();}
 HYLE_ASSIGN_OR_RETURN(auto next_k,returned_k.ready());HYLE_ASSIGN_OR_RETURN(auto next_v,returned_v.ready());
 if(!actual_correct){
  // Independent ordinary-ready graph on the exact resulting page frames. It
  // distinguishes an append-order defect from stale/incorrect native causal
  // arithmetic without changing the required numerical oracle.
  HYLE_ASSIGN_OR_RETURN(auto reference_builder,g::GraphBuilder::create());
  HYLE_ASSIGN_OR_RETURN(auto rq,reference_builder.input(qdesc));HYLE_ASSIGN_OR_RETURN(auto rk,reference_builder.input(kdesc));HYLE_ASSIGN_OR_RETURN(auto rv,reference_builder.input(vdesc));
  HYLE_ASSIGN_OR_RETURN(auto rn,reference_builder.add_node(c::Operation::custom(attention),std::array{rq,rk,rv}));
  HYLE_ASSIGN_OR_RETURN(auto ro,reference_builder.result(rn));HYLE_RETURN_IF_ERROR(reference_builder.publish(ro));HYLE_ASSIGN_OR_RETURN(auto reference_graph,std::move(reference_builder).finish());
  HYLE_ASSIGN_OR_RETURN(auto reference_program,gb::compile(reference_graph,{.storage_domains=domains,.targets=targets}));
  HYLE_ASSIGN_OR_RETURN(auto reference,reference_program.executable.create_invocation({.resources=g::ResourceOptions{}}));
  HYLE_RETURN_IF_ERROR(gb::prepare(reference,queues,std::array{gb::NodeLayout{rn,layout}},{.max_float_workspace_bytes=1u<<20,.max_int_workspace_bytes=64u<<10}));
  HYLE_RETURN_IF_ERROR(reference.bind(rq,qdesc,query));HYLE_RETURN_IF_ERROR(gb::bind(reference,rk,next_k));HYLE_RETURN_IF_ERROR(gb::bind(reference,rv,next_v));
  HYLE_ASSIGN_OR_RETURN(auto rw,pool.allocate(512,64));HYLE_RETURN_IF_ERROR(reference.bind(ro,outdesc,std::move(rw)));HYLE_RETURN_IF_ERROR(reference.prepare_replay(queues));
  HYLE_ASSIGN_OR_RETURN(auto rd,reference.submit(queues));HYLE_RETURN_IF_ERROR(rd.wait());HYLE_ASSIGN_OR_RETURN(auto rr,reference.result(ro));HYLE_ASSIGN_OR_RETURN(auto rl,rr.storage_lease());
  std::array<std::uint16_t,256>reference_words{};HYLE_RETURN_IF_ERROR(rl.view()->read(std::as_writable_bytes(std::span(reference_words))));
  for(unsigned i=0;i<4;++i)std::fprintf(stderr,"ordinary ready causal reference block%u=%.8g\n",i,double(number(reference_words[i*64],bf)));
  return Status::Internal("same-Graph append attention mean oracle differs; ordinary-ready reference recorded");
 }
 HYLE_RETURN_IF_ERROR(check(next_k.layout()==layout && next_v.layout()==layout && next_k.page_count()==3,"append result is not exact whole ready page frame"));
 std::array<std::uint16_t,128>unchanged{};HYLE_RETURN_IF_ERROR(old_v[1].view()->read(std::as_writable_bytes(std::span(unchanged))));
 for(unsigned i=0;i<64;++i)HYLE_RETURN_IF_ERROR(check(unchanged[i]==word(.375f,bf),"COW append changed old partial page"));
 std::printf("paged append ordinary Graph copy-producer/COW/page-boundary/attention/exact-ready/old-snapshot %s PASS\n",bf?"BF16":"F16");return Status::Ok();
}
Status symbolic_rows(){
 const auto memory=hyle::mem::system_resource();
 const std::array providers{c::ProviderBinding{c::ggml_cpu::provider(),0}};
 HYLE_ASSIGN_OR_RETURN(auto context,c::Context::create(c::cpu::device(),{.providers=providers}));
 HYLE_ASSIGN_OR_RETURN(auto queue,context.create_queue());
 struct Drain{c::Context&context;~Drain(){context.drain().IgnoreError();}}drain{context};
 constexpr auto type=c::DataType::kFloat16;
 HYLE_ASSIGN_OR_RETURN(auto plain,c::CacheStorage::plain(type));
 const c::BatchCapacity cap{.query_type=type,.output_type=type,.key_storage=plain,.value_storage=plain,.max_requests=1,
  .max_query_rows=2,.max_kv_rows=8,.max_pages=6,.max_page_refs=4,.query_heads=2,.kv_heads=1,.qk_head_dim=64,.value_head_dim=64,.page_size=2};
 HYLE_ASSIGN_OR_RETURN(auto schema,c::BatchSchema::create(cap));
 HYLE_RETURN_IF_ERROR(check(!gb::paged_append(schema,static_cast<c::BatchCacheRole>(0xff)),"invalid append cache role accepted"));
 HYLE_ASSIGN_OR_RETURN(auto kdesc,c::batch_cache_description(schema,c::BatchCacheRole::kKey));
 HYLE_ASSIGN_OR_RETURN(auto vdesc,c::batch_cache_description(schema,c::BatchCacheRole::kValue));
 HYLE_ASSIGN_OR_RETURN(auto metadata,schema.metadata_description());
 HYLE_ASSIGN_OR_RETURN(auto builder,g::GraphBuilder::create());
 HYLE_ASSIGN_OR_RETURN(auto rows,builder.dimension({1,2,1}));
 HYLE_ASSIGN_OR_RETURN(auto qspec,g::TensorSpec::dense(type,std::array{g::Dimension(rows),g::Dimension::fixed(2),g::Dimension::fixed(64)}));
 HYLE_ASSIGN_OR_RETURN(auto rspec,g::TensorSpec::dense(type,std::array{g::Dimension(rows),g::Dimension::fixed(1),g::Dimension::fixed(64)}));
 HYLE_ASSIGN_OR_RETURN(auto q,builder.input(qspec));HYLE_ASSIGN_OR_RETURN(auto new_k,builder.input(rspec));HYLE_ASSIGN_OR_RETURN(auto new_v,builder.input(rspec));
 HYLE_ASSIGN_OR_RETURN(auto bank_k,builder.input(kdesc));HYLE_ASSIGN_OR_RETURN(auto bank_v,builder.input(vdesc));HYLE_ASSIGN_OR_RETURN(auto meta,builder.input(metadata));
 HYLE_ASSIGN_OR_RETURN(auto view,g::ViewSpec::reshape(std::array{g::Dimension(rows),g::Dimension::fixed(1),g::Dimension::fixed(64)}));
 HYLE_ASSIGN_OR_RETURN(auto viewed,builder.add(view,new_k));
 HYLE_ASSIGN_OR_RETURN(auto produced_k,builder.add(c::Copy{},rspec,viewed));HYLE_ASSIGN_OR_RETURN(auto produced_v,builder.add(c::Copy{},rspec,new_v));
 HYLE_ASSIGN_OR_RETURN(auto ka,gb::paged_append(schema,c::BatchCacheRole::kKey));HYLE_ASSIGN_OR_RETURN(auto va,gb::paged_append(schema,c::BatchCacheRole::kValue));
 // Explicit empty output specs use the existing symbolic custom-operation path.
 HYLE_ASSIGN_OR_RETURN(auto kw,builder.add_node(c::Operation::custom(ka),std::array{produced_k},{}));
 HYLE_ASSIGN_OR_RETURN(auto vw,builder.add_node(c::Operation::custom(va),std::array{produced_v},{}));HYLE_RETURN_IF_ERROR(builder.depends_on(vw,kw));
 HYLE_ASSIGN_OR_RETURN(auto node,builder.add_node(c::Operation::custom(c::PagedAttention{.capacity=cap,.scale=.125f,.causal=true}),
  std::array{q,bank_k,bank_v,meta},std::array{qspec}));
 HYLE_RETURN_IF_ERROR(builder.depends_on(node,kw));HYLE_RETURN_IF_ERROR(builder.depends_on(node,vw));
 HYLE_ASSIGN_OR_RETURN(auto output,builder.result(node));HYLE_RETURN_IF_ERROR(builder.publish(output));
 HYLE_ASSIGN_OR_RETURN(auto graph,std::move(builder).finish());
 const std::array one{g::ShapeBinding{rows,1}},two{g::ShapeBinding{rows,2}};
 const std::array shapes{one,two};const std::array variants{g::ExactShapeVariant{one},g::ExactShapeVariant{two}};
 const std::array domains{g::StorageDomain{memory}};HYLE_ASSIGN_OR_RETURN(auto source,g::ExecutionSource::acquire(context));
 const std::array targets{g::ExecutionTarget{source,g::StorageDomainId{0}}};
 // One source DAG and one finite compilation, rather than rebuilding per T.
 HYLE_ASSIGN_OR_RETURN(auto compiled,gb::compile(graph,{.storage_domains=domains,.targets=targets},
  {.shape_policy=g::CompileShapePolicy::kFiniteExact,.exact_variants=variants}));
 HYLE_RETURN_IF_ERROR(check(compiled.executable.exact_variant_count()==2,"append finite family lost an exact child"));
 const std::array queues{g::QueueBinding{g::ExecutionLaneId{0},&queue}};
 for(std::size_t branch=0;branch<shapes.size();++branch){
  const auto extent=static_cast<std::uint32_t>(branch+1);
  HYLE_ASSIGN_OR_RETURN(auto invocation,compiled.executable.create_invocation({.shape=shapes[branch],.resources=g::ResourceOptions{}}));
  HYLE_RETURN_IF_ERROR(check(invocation.exact_variant_index()==branch,"append finite family selected a wrong child"));
  const std::array<std::int32_t,2>old_q{0,1},old_ptr{0,2},old_ids{0,1};const std::array<std::int32_t,1>old_tail{1};
  const std::array<std::int32_t,2>active_q{0,static_cast<std::int32_t>(extent)},active_ptr{0,extent==1?2:3};
  const std::array<std::int32_t,3>active_ids{0,2,3};const std::array<std::int32_t,1>active_tail{extent==1?2:1};
  HYLE_ASSIGN_OR_RETURN(auto old_layout,schema.version({old_q,old_ptr,old_ids,old_tail}));
  HYLE_ASSIGN_OR_RETURN(auto layout,schema.version({active_q,active_ptr,std::span(active_ids).first(extent==1?2:3),active_tail}));
  HYLE_ASSIGN_OR_RETURN(auto keys,c::PagedArena::create(schema,c::BatchCacheRole::kKey,memory,{.max_backing_bytes=4096}));
  HYLE_ASSIGN_OR_RETURN(auto values,c::PagedArena::create(schema,c::BatchCacheRole::kValue,memory,{.max_backing_bytes=4096}));
  std::array<c::ReadLease,2>old_k,old_v;
  for(unsigned page=0;page<2;++page){HYLE_ASSIGN_OR_RETURN(auto k,keys.acquire(page));HYLE_ASSIGN_OR_RETURN(auto v,values.acquire(page));
   std::vector<std::uint16_t>zero(128,0),data(128,word(.375f,false));
   if(!page){std::fill_n(data.begin(),64,word(.125f,false));std::fill(data.begin()+64,data.end(),word(.25f,false));}
   HYLE_RETURN_IF_ERROR(k.lease().view()->write(std::as_bytes(std::span(zero))));HYLE_RETURN_IF_ERROR(v.lease().view()->write(std::as_bytes(std::span(data))));
   HYLE_ASSIGN_OR_RETURN(old_k[page],k.publish(page?1:2));HYLE_ASSIGN_OR_RETURN(old_v[page],v.publish(page?1:2));}
  HYLE_ASSIGN_OR_RETURN(auto previous_k,keys.read(old_layout,old_k));HYLE_ASSIGN_OR_RETURN(auto previous_v,values.read(old_layout,old_v));
  std::array<c::PagedPageWriter,2>dirty_k,dirty_v;
  for(std::uint32_t i=0;i<extent;++i){HYLE_ASSIGN_OR_RETURN(dirty_k[i],keys.acquire(i+2));HYLE_ASSIGN_OR_RETURN(dirty_v[i],values.acquire(i+2));}
  HYLE_ASSIGN_OR_RETURN(auto append_keys,gb::PagedAppendPages::create(keys,layout,previous_k,std::span(dirty_k).first(extent)));
  HYLE_ASSIGN_OR_RETURN(auto append_values,gb::PagedAppendPages::create(values,layout,previous_v,std::span(dirty_v).first(extent)));
  HYLE_RETURN_IF_ERROR(gb::prepare(invocation,queues,std::array{gb::NodeLayout{node,layout}},
   {.max_float_workspace_bytes=1u<<20,.max_int_workspace_bytes=64u<<10}));
  if(extent==1){
   const std::array<std::int32_t,2>wrong_q{0,2},wrong_ptr{0,3};const std::array<std::int32_t,3>wrong_ids{0,4,5};
   const std::array<std::int32_t,1>wrong_tail{1};
   HYLE_ASSIGN_OR_RETURN(auto wrong_layout,schema.version({wrong_q,wrong_ptr,wrong_ids,wrong_tail}));
   std::array<c::PagedPageWriter,2>wrong_writers;
   for(unsigned i=0;i<wrong_writers.size();++i){HYLE_ASSIGN_OR_RETURN(wrong_writers[i],keys.acquire(i+4));}
   HYLE_ASSIGN_OR_RETURN(auto wrong,gb::PagedAppendPages::create(keys,wrong_layout,previous_k,wrong_writers));
   const auto rejected=gb::bind_append(invocation,graph,kw,bank_k,std::move(wrong));
   HYLE_RETURN_IF_ERROR(check(!rejected.ok() && wrong.valid() && wrong.page(0)->lease().valid(),
    "another finite child's append layout was accepted or consumed"));
   std::puts("paged append wrong finite-child layout preserves original pages PASS");
  }
  HYLE_RETURN_IF_ERROR(gb::bind_append(invocation,graph,kw,bank_k,std::move(append_keys)));
  HYLE_RETURN_IF_ERROR(gb::bind_append(invocation,graph,vw,bank_v,std::move(append_values)));
  HYLE_ASSIGN_OR_RETURN(auto qdesc,c::batch_query_description(cap,extent));HYLE_ASSIGN_OR_RETURN(auto outdesc,c::batch_output_description(cap,extent));
  HYLE_ASSIGN_OR_RETURN(auto rdesc,c::TensorDesc::dense(type,std::array<std::int64_t,3>{extent,1,64}));
  HYLE_ASSIGN_OR_RETURN(auto pool,c::LeasePool::create(memory,8192,{.max_blocks=8}));
  std::vector<std::uint16_t>zero(std::size_t(extent)*128,0),incoming(std::size_t(extent)*64,word(.5f,false));
  if(extent==2)std::fill(incoming.begin()+64,incoming.end(),word(.75f,false));
  HYLE_ASSIGN_OR_RETURN(auto query,load(pool,zero));HYLE_ASSIGN_OR_RETURN(auto nk,load(pool,std::span(zero).first(std::size_t(extent)*64)));
  HYLE_ASSIGN_OR_RETURN(auto nv,load(pool,incoming));
  HYLE_RETURN_IF_ERROR(invocation.bind(q,qdesc,query));HYLE_RETURN_IF_ERROR(invocation.bind(new_k,rdesc,nk));HYLE_RETURN_IF_ERROR(invocation.bind(new_v,rdesc,nv));
  HYLE_ASSIGN_OR_RETURN(auto destination,pool.allocate(std::size_t(extent)*256,64));HYLE_RETURN_IF_ERROR(invocation.bind(output,outdesc,std::move(destination)));
  HYLE_RETURN_IF_ERROR(invocation.prepare_replay(queues));HYLE_ASSIGN_OR_RETURN(auto done,invocation.submit(queues));HYLE_RETURN_IF_ERROR(done.wait());done={};
  {HYLE_ASSIGN_OR_RETURN(auto actual,invocation.result(output));HYLE_ASSIGN_OR_RETURN(auto lease,actual.storage_lease());
   std::vector<std::uint16_t>words(std::size_t(extent)*128);HYLE_RETURN_IF_ERROR(lease.view()->read(std::as_writable_bytes(std::span(words))));
   for(std::size_t i=0;i<words.size();++i)HYLE_RETURN_IF_ERROR(check(std::abs(number(words[i],false)-(i<128?.3125f:.4f))<.003f,"finite append causal mean differs"));}
  HYLE_ASSIGN_OR_RETURN(auto returned_k,gb::take_append(invocation,kw));HYLE_ASSIGN_OR_RETURN(auto returned_v,gb::take_append(invocation,vw));
  HYLE_ASSIGN_OR_RETURN(auto next_k,returned_k.ready());HYLE_ASSIGN_OR_RETURN(auto next_v,returned_v.ready());
  HYLE_RETURN_IF_ERROR(check(next_k.layout()==layout && next_v.layout()==layout,"finite append published another child's layout"));
  std::printf("paged append one symbolic Graph finite child T%u causal attention/exact-ready PASS\n",extent);
 }
 return Status::Ok();
}
Status all(){HYLE_RETURN_IF_ERROR(run(false,false,false));HYLE_RETURN_IF_ERROR(run(true,false,false));HYLE_RETURN_IF_ERROR(run(true,true,false));HYLE_RETURN_IF_ERROR(run(true,false,true));return symbolic_rows();}
}
#if defined(HYLE_APPEND_STANDALONE)
int main(){std::setvbuf(stdout,nullptr,_IONBF,0);const auto result=all();if(result.ok())return 0;char text[1024]{};result.ToString(text,sizeof(text));std::fprintf(stderr,"%s\n",text);return 1;}
#else
TEST(GraphPagedAppend,OriginalPagesAndSameGraphProof){const auto result=all();EXPECT_TRUE(result.ok())<<result.message();}
#endif
