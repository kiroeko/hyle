"""Root-owned, sequential GPU process; the plan supplies its actual image path."""
from pathlib import Path
import importlib.util,os,re,sys,xml.etree.ElementTree as ET
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent;P=S.parent;A=P.parent
spec=importlib.util.spec_from_file_location('ct_grouped_gpu_helpers',A/'grouped-shared-activation/build_host.py')
h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h);b,c=h.b,h.c
arm=sys.argv[1];assert arm in ['cpu','cuda','vulkan']
plan_path=Path(sys.argv[2]).resolve();plan=c.read(plan_path)
image=next(x[5:] for x in plan['command'] if x.upper().startswith('/OUT:'))
filter=sys.argv[3]
out=P/arm/'validation'/(sys.argv[4] if len(sys.argv)>4 else 'attempt1')
out.mkdir(parents=True,exist_ok=True);(out/'tmp').mkdir(exist_ok=True)
assert not (out/'tests.result.json').exists(),'Preserve an actual attempt'
assert all(b.same(row) for row in plan['inputs'])
env,runtime=b.environment(plan['command'],[r['path'] for r in plan['inputs']],out)
# The selected cached CPU adapter loads its private AVX2 module with
# LOAD_LIBRARY_SEARCH_DEFAULT_DIRS. PATH alone does not supply that module;
# stage only the exact image-embedded filename beside this test executable.
raw=Path(image).read_bytes()
module_names=sorted({x.decode('ascii') for x in re.findall(
    rb'hyle_ggml_cpu_avx2_[A-Za-z0-9_]+\.dll(?=\x00)',raw)})
del raw
private_modules=[]
for name in module_names:
 source=next((Path(directory)/name for directory in runtime
              if (Path(directory)/name).is_file()),None)
 assert source is not None,'Missing selected cached private CPU module: '+name
 source=source.resolve();destination=Path(image).resolve().parent/name
 source_before=b.identity(source)
 preexisting=destination.exists()
 if not preexisting:os.link(source,destination)
 assert os.path.samefile(source,destination),'Expected exact cached-module hardlink'
 target=b.identity(destination)
 assert target['sha256']==source_before['sha256'] and target['bytes']==source_before['bytes']
 assert b.same(source_before),'Cached private module changed during staging'
 private_modules.append(dict(source=source_before,destination=target,hardlink=True,
     preexisting=preexisting,reason='Application-directory search for the image-selected private module'))
c.save(out/'runtime-environment.json',dict(PATH=env['PATH'],runtime=runtime,
    private_modules=private_modules,staging='Exact cached private CPU module hardlink; no SDK copy'))
c.save(out/'image-before.json',b.identity(image))
try:c.execute('tests',[image,'--gtest_filter='+filter,'--gtest_output=xml:'+str(out/'tests.xml')],env,out)
finally:
 if (out/'tests.xml').exists():
  cases=ET.parse(out/'tests.xml').findall('.//testcase')
  failed=[x.attrib for x in cases if x.find('failure') is not None];skipped=[x.attrib for x in cases if x.find('skipped') is not None]
  receipt=dict(passed=bool(cases) and not failed and not skipped,cases=len(cases),failed=failed,skipped=skipped,
    filter=filter,names=[x.get('classname')+'.'+x.get('name') for x in cases],
    properties=[dict(case=x.get('classname')+'.'+x.get('name'),properties=[p.attrib for p in x.findall('./properties/property')]) for x in cases],
    image=b.identity(image),link_plan=b.identity(plan_path),xml=b.identity(out/'tests.xml'),GPU_processes=arm!='cpu')
  c.save(out/'receipt.json',receipt);print({k:receipt[k] for k in ('passed','cases','failed','skipped','names')},flush=True)


