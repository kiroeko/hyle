"""Read an exported local nsys SQLite; no CUDA/tool/process execution."""
from pathlib import Path
import collections
import csv
import hashlib
import json
import sqlite3
import sys

def identity(path):
    data=path.read_bytes();return dict(path=str(path.resolve()),bytes=len(data),sha256=hashlib.sha256(data).hexdigest())
def union_ns(intervals):
    total=0;end=None
    for lo,hi in sorted(intervals):
        if end is None or lo>end:total+=hi-lo;end=hi
        elif hi>end:total+=hi-end;end=hi
    return total
def main():
    path=Path(sys.argv[1]).resolve();db=sqlite3.connect('file:'+path.as_posix()+'?mode=ro',uri=True);db.row_factory=sqlite3.Row
    tables={row[0] for row in db.execute("SELECT name FROM sqlite_master WHERE type='table'")}
    schema={name:[row[1] for row in db.execute('PRAGMA table_info("'+name+'")')] for name in tables}
    strings={row['id']:row['value'] for row in db.execute('SELECT id,value FROM StringIds')}
    apis=[];seen=set()
    for table in ['CUPTI_ACTIVITY_KIND_RUNTIME','CUPTI_ACTIVITY_KIND_DRIVER']:
        if table not in tables:continue
        for row in db.execute('SELECT * FROM '+table+' ORDER BY start'):
            item=dict(row);name=str(strings.get(item['nameId'],item['nameId']))
            key=(name,item['start'],item['end'],item.get('globalTid'),item.get('correlationId'))
            if key in seen:continue
            seen.add(key)
            apis.append(dict(table=table,name=name,start=item['start'],end=item['end'],
                duration_us=(item['end']-item['start'])/1000,thread=item.get('globalTid'),correlation=item.get('correlationId'),
                logical_domain='runtime' if name.startswith('cuda') else 'driver'))
    apis.sort(key=lambda x:x['start']);assert apis
    copies=[dict(x) for x in db.execute('SELECT * FROM CUPTI_ACTIVITY_KIND_MEMCPY')] if 'CUPTI_ACTIVITY_KIND_MEMCPY' in tables else []
    copy_bytes=collections.defaultdict(list)
    for item in copies:copy_bytes[item['correlationId']].append(item['bytes'])
    dtoh=[x for x in apis if x['name'].startswith('cuMemcpyDtoH') and 'Async' not in x['name']]
    sized=[x for x in dtoh if 256 in copy_bytes[x['correlation']]]
    delimiters=sized if len(sized)==34 else dtoh
    method='256byte GPU-copy correlation plus synchronous Driver DtoH API' if len(sized)==34 else 'synchronous Driver DtoH API count only'
    confidence=len(delimiters)==34 and len({x['thread'] for x in delimiters})==1
    mapping=[('default',0),('default',1),('default','old_read'),('default',2),
             ('budget3MiB',0),('budget3MiB',1),('budget3MiB','old_read'),('budget3MiB',2)]
    for rep in range(11):
        for arm in (['default','budget3MiB'] if rep%2==0 else ['budget3MiB','default']):mapping.append((arm,rep+3))
    mapping += [('default','escaped0'),('default','escaped1'),('budget3MiB','escaped0'),('budget3MiB','escaped1')]
    assert len(mapping)==34
    intervals=[]
    if confidence:
        thread=delimiters[0]['thread']
        for index,(arm,call) in enumerate(mapping):
            hi=delimiters[index]['end'];lo=delimiters[index-1]['end'] if index else delimiters[index]['start']
            events=[x for x in apis if x['thread']==thread and x['start']>=lo and x['end']<=hi]
            domains={}
            for domain in ['driver','runtime']:
                selected=[x for x in events if x['logical_domain']==domain]
                grouped=collections.defaultdict(list)
                for x in selected:grouped[x['name']].append(x['duration_us'])
                domains[domain]=dict(interval_union_us=union_ns([(x['start'],x['end']) for x in selected])/1000,
                    APIs=sorted([dict(name=k,count=len(v),sum_us=sum(v),max_us=max(v)) for k,v in grouped.items()],key=lambda x:x['sum_us'],reverse=True))
            intervals.append(dict(read_ordinal=index,arm=arm,call=call,start_ns=lo,end_ns=hi,read_to_read_us=(hi-lo)/1000,
                domains=domains,all_API_union_us=union_ns([(x['start'],x['end']) for x in events])/1000,
                longest_API_events=sorted(events,key=lambda x:x['duration_us'],reverse=True)[:18],
                allocation_or_sync_events=[x for x in events if any(word in x['name'] for word in ['Alloc','Malloc','Free','Synchronize','EventCreate','CtxGetLimit'])]))
    grouped=collections.defaultdict(list)
    for item in apis:grouped[item['name']].append(item['duration_us'])
    summary=dict(status='instrumented_API_diagnostic_not_a_throughput_window',sqlite=identity(path),
        schema={name:columns for name,columns in schema.items() if name.startswith('CUPTI') or name=='StringIds'},
        mapping=dict(expected_output_reads=34,observed_sync_DtoH=len(dtoh),matched_256byte_output_reads=len(sized),
            accepted=confidence,method=method,limitation='Without NVTX or absolute host checkpoints these are output-read-to-output-read intervals. They also include prior Completion destructor/assert/sample bookkeeping outside the timed call. Do not equate interval length to submit or total.'),
        whole_trace_API_totals=sorted([dict(name=k,count=len(v),sum_us=sum(v),max_us=max(v)) for k,v in grouped.items()],key=lambda x:x['sum_us'],reverse=True),
        warm0_1_2_intervals=[x for x in intervals if x['call'] in [3,4,5]],all_mapped_intervals=intervals,
        caution='Driver/runtime API intervals can nest; sum_us across names/domains may double-count. Use the interval unions or explicit raw events. GPU execution and OS scheduling are not inferred from API duration alone.',
        next_source_hypotheses=['Graph submit/admission: src/graph/submission.cc',
            'Queue completion event-block growth cudaMalloc/cudaHostAlloc/EventCreate: src/compute_backend_cuda/cuda_backend.cc around275-315',
            'Native static leaf pointer checks+two launches: src/compute_provider_torch_cuda/artifact_provider.cc 461-487 and mlx_packed_kernel.cu 369-399',
            'Synchronous output read: src/compute_backend_cuda/cuda_memory.cc 109-123'])
    out=path.with_name('api-analysis.json');out.write_text(json.dumps(summary,indent=2)+'\n')
    with path.with_name('all-cuda-API-events.csv').open('w',newline='',encoding='utf8') as f:
        writer=csv.DictWriter(f,fieldnames=list(apis[0]));writer.writeheader();writer.writerows(apis)
    print(str(out));print(summary['mapping'])
    for item in summary['warm0_1_2_intervals']:
        print(item['arm'],item['call'],'interval',item['read_to_read_us'],'longest',[(x['name'],x['duration_us']) for x in item['longest_API_events'][:5]])
    db.close()

if __name__=='__main__':main()
