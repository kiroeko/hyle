"""Read one completed diagnostic XML; no process launch or GPU use."""
from pathlib import Path
import json
import statistics
import sys
import xml.etree.ElementTree as ET

def main():
    path=Path(sys.argv[1]);rows=[]
    for case in ET.parse(path).iter('testcase'):
        assert case.find('failure') is None and case.find('skipped') is None
        props={x.get('name'):x.get('value') for x in case.iter('property')}
        arms={}
        for tag in ['default','budget3MiB']:
            stages=[]
            for text in props[tag+'_stage_samples_us'].split(';'):
                if not text:continue
                item=dict(pair.split('=',1) for pair in text.split(','))
                stages.append({key:int(value) if key in ['call','slot'] else float(value) for key,value in item.items()})
            raw=[float(x) for x in props[tag+'_complete_samples_us'].split(',') if x]
            assert len(stages)==14 and len(raw)==11
            for index,value in enumerate(raw):
                assert abs(value-stages[index+3]['total'])<1e-6
            for item in stages:
                assert abs(sum(item[key] for key in ['release','submit','wait','result','read'])-item['total'])<1e-6
            medians={key:statistics.median(item[key] for item in stages[3:]) for key in ['release','submit','wait','result','read','total']}
            suspect=stages[4];assert suspect['slot']==1 and suspect['call']==4
            arms[tag]=dict(all_calls=stages,warm_stage_medians_us=medians,warm1_slot1=suspect,
                warm1_minus_warm_median_us={key:suspect[key]-value for key,value in medians.items()})
        rows.append(dict(test=case.get('classname')+'.'+case.get('name'),arms=arms))
    output=path.with_name('stage-analysis.json')
    output.write_text(json.dumps(dict(source_xml=str(path.resolve()),cases=rows,
        scope='Instrumented diagnostic, original complete total unchanged in scope; no independent performance window claim.'),indent=2)+'\n')
    print(str(output))
    for row in rows:
        for arm,values in row['arms'].items():
            print(row['test'],arm,'warm1',values['warm1_slot1'],'median',values['warm_stage_medians_us'])

if __name__=='__main__':main()
