"""Archive the two completed submit diagnostics; list exact cleanup paths without deleting."""
from pathlib import Path
import hashlib
import json
import xml.etree.ElementTree as ET
import zipfile
import zlib

D=Path(__file__).resolve().parent;B=D.parent;R=B.parents[2]
T=D/'nsys-api-attempt1';U=B/'cuda/validation/tail-stage-attempt1'
OUT=R/'docs/evidence/performance';STEM='outer-fp8-submit-tail-2026-10-21'
def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def ident(p):
    p=Path(p);raw=p.read_bytes();return dict(path=str(p),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def save(p,value):Path(p).write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
def main():
    public=OUT/(STEM+'.json');archive=OUT/(STEM+'.zip')
    assert not public.exists() and not archive.exists()
    runs=[]
    for name,folder in [('stage_only',U),('nsys_CUDA_API',T)]:
        cases=ET.parse(folder/'tests.xml').findall('.//testcase')
        assert len(cases)==1 and cases[0].find('failure') is None and cases[0].find('skipped') is None
        analysis=read(folder/'stage-analysis.json');assert len(analysis['cases'])==1
        arms={}
        for arm,value in analysis['cases'][0]['arms'].items():
            assert len(value['all_calls'])==14
            arms[arm]=dict(call4=value['warm1_slot1'],warm_stage_medians_us=value['warm_stage_medians_us'],all_calls=value['all_calls'])
        runs.append(dict(name=name,xml=ident(folder/'tests.xml'),stage_analysis=ident(folder/'stage-analysis.json'),arms=arms))
    api=read(T/'api-analysis.json');assert api['mapping']['accepted']
    graph=read(T/'graph-initialization-observations.json')
    call4=[x for x in graph['intervals'] if x['call']==4]
    assert len(call4)==2 and all(not x['explicit_event_pool_growth_calls_all_threads'] for x in call4)
    cleanup=[];optional=[]
    for path in sorted((D/'checks/link1').iterdir()):
        if not path.is_file():continue
        assert path.resolve().is_relative_to(D.resolve())
        if path.suffix.lower() in ['.exe','.map','.dll']:cleanup.append(ident(path))
        elif path.suffix.lower() in ['.exp','.lib','.pdb']:optional.append(ident(path))
    assert sum(Path(x['path']).suffix=='.exe' for x in cleanup)==1
    preserved=[read(D/'checks/attempt1/identity.json')['object']]
    for arm in ['cpu','cuda']:preserved.append(read(B/arm/'checks/attempt1/identity.json')['object'])
    for row in preserved:assert ident(row['path'])==row
    cleanup_plan=dict(status='inventory_only_no_deletion_test_ps1_untouched',root=str(D.resolve()),
        rebuildable_diagnostic_image_map_staged_module=cleanup,logical_bytes=sum(x['bytes'] for x in cleanup),
        optional_import_sidecars=optional,optional_logical_bytes=sum(x['bytes'] for x in optional),
        preserve_objects=preserved,preserve_all_shared_products_and_caches=True,
        trace_cleanup=[],trace_decision='Retain original nsys-rep,SQLite,API CSV and both raw XML/log windows locally; all are also archived. This finite trace is small enough that deleting its originals is unnecessary.',
        execution='Root must first write/check exact paths in repository test.ps1. No file is deleted by this script. Original CPU DLL cache/Qwen consumer are excluded.')
    save(D/'cleanup-plan.json',cleanup_plan)
    routing=dict(status='read_only_no_route_product_change_recommended_in_this_diagnostic',
        now=['Keep CPU default: the earlier single-process M2 bounded consumer was slower.',
            'The current public 3MiB StorageDomain workspace limit already selects the bounded CUDA candidate naturally, without a forced provider or product fix. Keep it as the explicit space-constrained choice.',
            'Keep all original 11 samples including one-time initialization. This diagnostic does not replace them with a tail-deleted throughput result. Typical post-initialization calls can be described, but a global CUDA default win is not established across arbitrary shapes/domains.'],
        possible_later_minimum=dict(intent='A local CUDA bounded-space engineering default, not a global optimizer or model-name rule.',
            mechanism=['Generate an additional non-obstructing GGML region cut for an actually admitted exact closed static FP8 suffix. Respect node/target/provider/replay constraints; reuse existing closure and allowed-node proof.',
                'Keep the original broad region and all leaves as fallback. Prefer the cut ahead of the obstructing broad region only in this admitted replacement context; a rank change on the suffix alone cannot undo an earlier-starting region that already consumed its Cast.',
                'The current static candidate rank200 already precedes ordinary CUDA Graph leaf baselines>=300 at its first node. A cut must be ranked strictly ahead of the original GGML maximal region100, since otherwise same-policy tie breaking prefers its larger node count. This would be a scoped engineering space policy, not measured universal latency ranking.',
                'Reuse existing RouteSearch backtracking on resource/prepare decline. No executor, hot allocation, new public operation, model whitelist or global comparator change is required in principle.'],
            owners=['src/graph_provider_ggml_cuda/ggml_cuda_region.cc: cut variants and fallback preservation',
                'src/graph_route_cuda/ct_packed_linear_region.cc or CUDA default region composition: hand off actually admitted exact candidate boundaries',
                'src/graph/static_fp8_region.h and src/graph/closed_region.h: reuse mathematical/closed-reader proof; no math change'],
            risks=['Current per-provider discovery does not directly share the other provider\'s native admission. A clean cold handoff is needed; do not reserve nodes solely from a syntactic match while the static provider is unavailable.',
                'Never remove ordinary coverage, defeat explicit placement/provider constraints, swallow published/intermediate readers or change ordered SA/SW products.',
                'No current soft memory-cost field guarantees the earliest region preserves the later suffix. Existing budgets already express the resource contract; automatic preference would be optional policy work and requires default-route/fallback evidence.']))
    save(D/'routing-decision-review.json',routing)
    summary=dict(date='2026-10-21',status='finite_submit_tail_diagnostic_complete_no_product_change',
        scope='Same CUDA M1 N128 K7168 source-bound artificial outer-FP8 role, original Commands consumer and preflight/11 calls. Two diagnostic processes, not new model throughput runs.',
        counts=dict(independent_diagnostic_processes=2,case_executions=2,distinct_backend_geometry_cases=1,failed=0,skipped=0),
        finding=['Call4 is slot1\'s second stable execution, not its first submit. Slot0\'s corresponding second stable execution occurs at preflight call2.',
            'The locked GGML CUDA source warmup_complete rule executes directly on the first/property-changing call, captures/instantiates when the second call has stable properties, and subsequently launches the existing provider-internal graph.',
            'Actual trace has five GGML graph capture/instantiate/update/launch groups for default, two for bounded at call2 and call4. Calls3 and5 contain graph launches without new instantiate. This matches original GGML Program counts5 versus2.',
            'These are original provider-internal graphs. Hyle outer replay remains Commands; the Hyle outer backend uses cudaGraphInstantiateWithFlags, while this native path uses cudaGraphInstantiate(old5arg). The bounded GPU kernel list includes static_quantize/static_code_dot; its suffix does not call cuBLAS GEMM.',
            'Call4 explicit cudaMalloc/cuMemAlloc/cudaHostAlloc/EventCreate calls are absent across all traced threads. This rules out the proposed Queue event-block expansion mechanism for this observed spike, not all possible hidden driver/CPU allocations or every workload.',
            'Trace call4 instantiation sums are61.397us(default5) and24.144us(budget2). Do not equate these with the entire submit durations387.3/172.7us or all submit excess. Other capture/launch/context/host work and instrumentation remain.'],
        measurements=runs,trace_mapping=api['mapping'],graph_initialization=graph,
        limitations=['Four extra host-clock probes remain inside the unchanged total interval; arrays/formatting are outside. Source math, preflight, old-result gates and11samples are unchanged.',
            'CUDA all-API tracing adds overhead and the stage-only window also drifted. Neither diagnostic is directly comparable to unprofiled performance or pooled with it.',
            'Without NVTX/absolute host checkpoints, API regions are output-read-to-output-read intervals and include adjacent host bookkeeping outside total. Driver/runtime API calls can nest; sums across domains are not wall time.',
            'Budget call4 submit is elevated but is not the largest complete latency in the traced window; later wait/read tails also occur. This is a specific initialization attribution, not an explanation of every tail.',
            'No public mathematical/capture/lifetime bug or need to enlarge Queue pools is established. No extra trace, warmup, route modification or product instrumentation is requested.'],
        related_performance=dict(file='outer-fp8-route-cost-2026-10-21.json',identity=ident(OUT/'outer-fp8-route-cost-2026-10-21.json')),
        source_proof=read(D/'source-evidence/patch-replay-proof.json'),
        source_proof_scope='One upstream ggml-cuda.cu file and current153 exact manifest edits replayed offline to the declared final SHA; warmup excerpt byte-identical before/after. No SDK tree or numeric model payload copied.',
        routing_decision=routing,cleanup='cleanup/cleanup-plan.json',build=dict(diagnostic_CXX=1,links=1,SDK=0,NVCC=0,product_changes=0,additional_builds_for_trace=0))
    save(D/'independent-tail-review.json',summary)
    members={}
    def add(path,name):
        path=Path(path);assert path.is_file() and name not in members
        assert path.suffix.lower() not in ['.exe','.map','.dll','.obj','.lib','.exp','.pdb','.cubin']
        members[name]=path.read_bytes()
    for name in ['role_bench_diag.cc','consumer.diff','source-freeze.json','build.py','run_trace.py','analyze_trace.py','parse.py',
                 'trace-workflow-freeze.json','design-review.json','ready-for-root-run.json','optional-nsys-plan.json','package_tail.py']:
        add(D/name,'diagnostic/'+name)
    add(B/'role_bench.cc','original/role_bench.cc');add(B/'build_bench.py','original/build_bench.py')
    add(B/'benchmark-source-freeze.json','original/benchmark-source-freeze.json')
    add(B/'root/run_windows.py','diagnostic/root-run-stage.py')
    for folder,prefix in [(U,'stage-only'),(T,'nsys')]:
        for path in sorted(folder.iterdir()):
            if path.is_file():add(path,prefix+'/'+path.name)
    for folder in [D/'checks/attempt1',D/'checks/link1']:
        for path in sorted(folder.iterdir()):
            if path.is_file() and path.suffix.lower() in ['.json','.log']:add(path,'build/'+str(path.relative_to(D)).replace('\\','/'))
    for path in sorted((D/'source-evidence').iterdir()):add(path,'source-evidence/'+path.name)
    for name in ['src/compute_provider_ggml_cuda/ggml_cuda_provider.cc','src/compute_provider_ggml_cuda/native_bridge_impl.h',
                 'src/compute_provider_torch_cuda/artifact_provider.cc','src/compute_provider_torch_cuda/mlx_packed_kernel.cu',
                 'src/compute_backend_cuda/cuda_backend.cc','src/compute_backend_cuda/cuda_memory.cc','src/graph/submission.cc',
                 'third_party/ggml_cuda_runtime/patches.json']:
        add(R/name,'sources/'+name)
    for name in ['cleanup-plan.json','routing-decision-review.json','independent-tail-review.json']:
        add(D/name,('cleanup/' if name=='cleanup-plan.json' else 'analysis/')+name)
    inventory=[dict(name=name,bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest(),crc32=f'{zlib.crc32(raw)&0xffffffff:08x}') for name,raw in sorted(members.items())]
    members['manifest.json']=(json.dumps(dict(other_members=inventory,member_count_excluding_manifest=len(inventory)),indent=2)+'\n').encode()
    with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as output:
        for name,raw in sorted(members.items()):output.writestr(name,raw)
    with zipfile.ZipFile(archive) as check:
        assert check.testzip() is None and len(check.namelist())==len(members)
        for row in inventory:
            raw=check.read(row['name']);info=check.getinfo(row['name'])
            assert hashlib.sha256(raw).hexdigest()==row['sha256'] and len(raw)==row['bytes'] and f'{info.CRC:08x}'==row['crc32']
    summary['archive']=dict(file=archive.name,**ident(archive),members=len(members),manifest='manifest.json')
    save(public,summary)
    receipt=dict(public_json=ident(public),archive=ident(archive),members=len(members),all_SHA_CRC_verified=True,
        cleanup=ident(D/'cleanup-plan.json'),deleted=0,new_GPU_runs_by_packager=0)
    save(D/'publication.json',receipt);print(json.dumps(receipt,indent=2))

if __name__=='__main__':main()
