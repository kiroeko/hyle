"""One diagnostic host TU and current CUDA closure link; no GPU execution."""
from pathlib import Path
import importlib.util
import sys

sys.dont_write_bytecode=True
D=Path(__file__).resolve().parent;P=D.parent;A=P.parent
spec=importlib.util.spec_from_file_location('current_z_helpers',A/'quark-block128-scale-2026-10-21/windows/build.py')
h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h);b,c=h.b,h.c

def main():
    recipe=P/'cuda/checks/attempt1/identity.json';old=c.read(recipe)
    source=D/'role_bench_diag.cc';out=D/'checks/attempt1';out.mkdir(parents=True,exist_ok=True);(out/'tmp').mkdir(exist_ok=True)
    assert not (out/'compile.result.json').exists()
    command=b.host_command(old['command'],source,'cuda-role-diag',out)
    c.save(out/'compile-plan.json',dict(command=command,source=b.identity(source),recipe=b.identity(recipe),GPU_runs=0,SDK_builds=0))
    env,_=b.environment(command,[],out);c.execute('compile',command,env,out)
    deps=c.read(out/'cuda-role-diag-deps.json')['Data'];paths=list(dict.fromkeys([deps['Source'],*deps['Includes']]))
    dependencies=[b.identity(x) for x in paths];assert all(h.same(x) for x in dependencies)
    record=dict(command=command,source=b.identity(source),object=b.identity(out/'cuda-role-diag.obj'),
        old_object=old['object'],recipe=b.identity(recipe),dependencies=dependencies,
        source_dependencies=b.identity(out/'cuda-role-diag-deps.json'),GPU_runs=0,SDK_builds=0)
    c.save(out/'identity.json',record)
    base=P/'cuda/checks/link1/link-plan.json';plan=c.read(base)
    assert all(h.same(x) for x in plan['inputs'])
    assert sum(c.key(x['path'])==c.key(old['object']['path']) for x in plan['inputs'])==1
    inputs=[record['object'] if c.key(x['path'])==c.key(old['object']['path']) else x for x in plan['inputs']]
    command=[record['object']['path'] if c.key(x)==c.key(old['object']['path']) else x for x in plan['command']
        if not x.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:'))]
    link=D/'checks/link1';link.mkdir(parents=True,exist_ok=True);(link/'tmp').mkdir(exist_ok=True)
    assert not (link/'link.result.json').exists()
    image=link/'cuda-role-diag.exe';command+=['/OUT:'+str(image),'/MAP:'+str(image.with_suffix('.map')),'/IMPLIB:'+str(image.with_suffix('.lib'))]
    args=[x for x in command if Path(x).is_absolute() and Path(x).suffix.lower() in ['.obj','.lib']]
    assert list(map(c.key,args))==[c.key(x['path']) for x in inputs]
    c.save(link/'link-plan.json',dict(command=command,inputs=inputs,base=b.identity(base),
        replacements=[dict(source=record['source'],old_object=old['object'],object=record['object'])],GPU_runs=0,SDK_builds=0))
    env,runtime=b.environment(command,[x['path'] for x in inputs],link)
    c.save(link/'runtime-environment.json',dict(PATH=env['PATH'],runtime=runtime))
    c.execute('link',command,env,link);c.save(link/'image.json',b.identity(image))
    ready=dict(status='one_CXX_one_link_ready_no_execution',image=b.identity(image),link_plan=b.identity(link/'link-plan.json'),
        runtime_environment=b.identity(link/'runtime-environment.json'),filter='CudaOuterFp8RouteBench.M1',expected_tests=1,
        instructions='Root run once with same original runner/staged CPU module. Original preflight/11 samples and total bounds retained; inspect call4 slot1 stage buckets, do not overwrite public results.',
        CXX=1,links=1,NVCC=0,SDK_builds=0,GPU_runs=0)
    c.save(D/'ready-for-root-run.json',ready)
    nsys=Path('C:/Program Files/NVIDIA Corporation/Nsight Systems 2026.1.3/target-windows-x64/nsys.exe')
    assert nsys.is_file()
    stage=h.R/'.scratch/build-compute-v2-dev/bin/hyle_ggml_cpu_avx2_ffa4e8b8_e74fc9bb8964d04f.dll'
    assert stage.is_file()
    trace=D/'optional-nsys';trace.mkdir(exist_ok=True)
    c.save(D/'optional-nsys-plan.json',dict(tool=b.identity(nsys),required_module=b.identity(stage),
        stage_destination=str(image.parent/stage.name),
        command=[str(nsys),'profile','--trace=cuda','--sample=none','--cpuctxsw=none','--cuda-trace-all-apis=true',
            '--discard-environment=true','--output='+str(trace/'capture'),str(image),
            '--gtest_filter=CudaOuterFp8RouteBench.M1','--gtest_output=xml:'+str(trace/'tests.xml')],
        status='optional_plan_only_not_executed',scope='Prefer one unprofiled diagnostic first; trace durations are instrumented and not a replacement performance window.'))
    print(str(D/'ready-for-root-run.json'),flush=True)

if __name__=='__main__':main()
