#include "../../../../tests/compute_models/fp8_outer_scale_fixture.h"
#include "../../../../src/graph/static_fp8_region.h"
#include "hyle/graph/cpu.h"
#include "hyle/compute/providers/native.h"
#if defined(HYLE_OUTER_BENCH_CUDA)
#include "hyle/graph/cuda.h"
#include "hyle/compute/backends/cuda.h"
#include "hyle/compute/providers/torch_cuda.h"
#endif

#include <chrono>
#include <iomanip>
#include <memory>
#include <sstream>

namespace {
namespace f=fp8_outer_scale_test;
namespace c=f::c;namespace g=f::g;namespace m=f::m;
using Clock=std::chrono::steady_clock;
double elapsed(Clock::time_point begin){return std::chrono::duration<double,std::micro>(Clock::now()-begin).count();}
std::string number(double value){std::ostringstream out;out<<std::setprecision(12)<<value;return out.str();}
void property(const std::string &key,const std::string &value){::testing::Test::RecordProperty(key,value);}
struct Backend {
  c::Context context;
  c::StorageOwner owner;
  c::Queue queue;
  Backend(){
#if defined(HYLE_OUTER_BENCH_CUDA)
    context=f::take(g::cuda::create_context(),"CUDA context");
    owner=f::take(c::StorageOwner::adopt(context,f::take(c::cuda::MemoryResource::create(context,c::cuda::MemoryKind::kDevice),"device memory")),"original owner");
#else
    context=f::take(g::cpu::create_context(),"CPU context");
#endif
    queue=f::take(context.create_queue(),"original queue");
  }
  m::MemoryResourceRef resource()const{return owner?owner.ref():m::system_resource();}
  hyle::Result<g::CompiledGraph> compile(const g::Graph &graph,g::CompileOptions options,std::size_t budget){
    const std::array storage{g::StorageDomain{.resource=resource(),.workspace_budget_bytes=budget,.owner=owner}};
    const std::array targets{g::ExecutionTarget{f::take(g::ExecutionSource::acquire(context),"same context execution source"),g::StorageDomainId{0}}};
    const std::array lanes{g::ExecutionLane{.target=g::ExecutionTargetId{0}}};
#if defined(HYLE_OUTER_BENCH_CUDA)
    return g::cuda::compile(graph,{.storage_domains=storage,.targets=targets,.lanes=lanes},options);
#else
    return g::cpu::compile(graph,{.storage_domains=storage,.targets=targets,.lanes=lanes},options);
#endif
  }
  hyle::Status prepare(g::Invocation &inv){
    const std::array queues{g::QueueBinding{g::ExecutionLaneId{0},&queue}};
    return inv.prepare_replay(queues,{.mode=g::ReplayMode::kCommands});
  }
};
struct StageSample {
  std::size_t slot=0;
  double release=0,submit=0,wait=0,result=0,read=0,total=0;
};
struct Arm {
  std::string name;
  g::CompiledGraph compiled;
  std::array<g::Invocation,2> slots;
  std::array<std::array<m::Buffer,2>,2> inputs;
  c::LeasePool pool;
  std::array<g::GraphOutput,2> retained;
  std::array<std::vector<std::byte>,2> raw;
  std::vector<double> samples;
  std::size_t packed=0;
  std::array<StageSample,16> stages{};
  std::size_t stage_count=0;
};
void record_report(const std::string &prefix,const g::CompileReport &report){
  property(prefix+"_workspace",std::to_string(report.workspace_bytes()));
  const auto storage=report.compiled_storage();
  property(prefix+"_materialized",std::to_string(storage.materialized_constant_bytes));
  property(prefix+"_persistent_known",std::to_string(storage.provider_persistent_bytes));
  property(prefix+"_private_unknown_providers",std::to_string(storage.unknown_provider_count));
  const auto search=report.search();
  property(prefix+"_route_states",std::to_string(search.route_search_states));
  property(prefix+"_plan_rejections",std::to_string(search.route_plan_rejections));
  property(prefix+"_placement_attempts",std::to_string(search.placement_attempts));
  property(prefix+"_optimization_limited",search.optimization_limited()?"true":"false");
  std::ostringstream steps,physical;
  for(std::size_t i=0;i<report.step_count();++i){
    const auto s=f::take(report.step(i),"compile step");
    steps<<"step="<<i<<",provider="<<s.provider.name<<",policy="<<s.policy.namespace_id<<':'<<s.policy.policy_id<<':'<<s.policy.version<<",nodes=";
    for(std::size_t n=0;n<s.node_count;++n)steps<<f::take(report.step_node(i,n),"step node").ordinal()<<':';
    steps<<";";
  }
  for(std::size_t i=0;i<report.physical_value_count();++i){
    const auto v=f::take(report.physical_value(i),"physical span");
    physical<<"physical="<<i<<",value="<<v.value.ordinal()<<",bytes="<<f::take(v.description.required_bytes(),"physical bytes")<<",workspace="<<v.workspace_backed<<",alias=";
    if(v.alias_source)physical<<*v.alias_source;else physical<<"none";
    physical<<';';
  }
  property(prefix+"_steps",steps.str());property(prefix+"_physical_views",physical.str());
}
std::unique_ptr<Arm> make_arm(Backend &backend,const f::Case &test,const f::Logical &logical,
    const c::ReadLease &bank,std::string name,std::size_t budget,bool forced){
  auto arm=std::make_unique<Arm>();arm->name=std::move(name);
  const auto prefix=arm->name;
  const std::array constants{g::ConstantBinding{logical.ports[1],f::take(bank.tensor(test.descriptions[1]),"original E4 bank"),g::ConstantPolicy::kMaterialize,backend.owner,backend.owner?bank:c::ReadLease{}}};
  g::CompileOptions options{.constants=constants}; // Original search/placement limits, unchanged.
  std::vector<g::NodeProviderConstraint> constraints;
  if(forced){
    using Rule=g::detail::StaticFloat8Pattern;
    for(std::size_t i=0;i<logical.graph.node_count();++i){
      Rule::Pattern pattern;
      if(!Rule::pattern(logical.graph,f::take(logical.graph.node_id(i),"recipe terminal"),pattern))continue;
      for(const auto node:pattern.span()){
#if defined(HYLE_OUTER_BENCH_CUDA)
        constraints.push_back({node,c::torch_cuda::kProviderId,{}});
#else
        constraints.push_back({node,c::native::kProviderId,{}});
#endif
      }
    }
    EXPECT_EQ(constraints.size(),std::size_t{12});options.node_providers=constraints;
  }
  property(prefix+"_forced",forced?"true":"false");
  property(prefix+"_budget",std::to_string(budget));
  property(prefix+"_route_state_limit",std::to_string(options.max_route_search_states));
  const auto start=Clock::now();auto compiled=backend.compile(logical.graph,options,budget);
  property(prefix+"_compile_us",number(elapsed(start)));
  if(!compiled){
    property(prefix+"_compile_status",std::to_string(static_cast<int>(compiled.error().status().code())));
    property(prefix+"_compile_error",std::string(compiled.error().status().message()));
    if(prefix=="default"||forced)f::check(compiled.error().status(),"required benchmark compile");
    return {};
  }
  arm->compiled=std::move(*compiled);property(prefix+"_compile_status","0");
  record_report(prefix,arm->compiled.report);
  for(std::size_t i=0;i<arm->compiled.report.step_count();++i)
    arm->packed+=f::take(arm->compiled.report.step(i),"packed step").policy==f::kPackedPolicy;
  property(prefix+"_packed_steps",std::to_string(arm->packed));
  if(forced)EXPECT_EQ(arm->packed,std::size_t{1});
  const auto first=test.payloads(test.data(0));const auto bytes=f::take(test.output.required_bytes(),"result bytes");
  const auto bind_start=Clock::now();
  const bool caller=f::take(arm->compiled.executable.output_ownership(),"result owner")==g::OutputOwnership::kCaller;
  if(caller)arm->pool=f::take(c::LeasePool::create(backend.resource(),2*((bytes+255)/256*256),{.max_blocks=2}),"two actual output blocks");
  for(std::size_t slot=0;slot<2;++slot){
    arm->slots[slot]=f::take(arm->compiled.executable.create_invocation({.resources=g::ResourceOptions{}}),"original invocation");
    for(std::size_t i=0;i<2;++i){const auto port=i==0?0U:3U;
      arm->inputs[slot][i]=f::take(m::Buffer::create(backend.resource(),first[port].size(),256),"dynamic original bytes");
      f::check(arm->inputs[slot][i].view().write(first[port]),"initial input write");
      f::check(arm->slots[slot].bind(logical.ports[port],f::take(c::ConstTensorView::create(test.descriptions[port],arm->inputs[slot][i].view()),"typed input")),"bind original input");
    }
    if(caller)f::check(arm->slots[slot].bind(logical.output,test.output,f::take(arm->pool.allocate(bytes),"owned result writer")),"bind owned result");
    arm->raw[slot].resize(bytes);
  }
  property(prefix+"_allocate_bind_us",number(elapsed(bind_start)));
  for(std::size_t slot=0;slot<2;++slot){const auto t=Clock::now();f::check(backend.prepare(arm->slots[slot]),"same Commands prepare");property(prefix+"_prepare_slot"+std::to_string(slot)+"_us",number(elapsed(t)));}
  return arm;
}
double call(Arm &arm,Backend &backend,const f::Logical &logical,std::size_t slot){
  const auto t=Clock::now();arm.retained[slot].reset();
  const auto released=Clock::now();
  auto completion=f::take(arm.slots[slot].submit(backend.queue),"complete role submit");
  const auto submitted=Clock::now();
  f::check(completion.wait(),"complete role wait");
  const auto waited=Clock::now();
  arm.retained[slot]=f::take(arm.slots[slot].result(logical.output),"original owned result");
  const auto tensor=f::take(arm.retained[slot].tensor(),"original result tensor");
  const auto result=Clock::now();
  f::check(f::take(tensor.storage().subview(0,arm.raw[slot].size()),"exact result range").read(arm.raw[slot]),"same result read boundary");
  // This endpoint is exactly where original elapsed(t) sampled the clock.
  const auto end=Clock::now();
  const auto us=[](auto start,auto finish){return std::chrono::duration<double,std::micro>(finish-start).count();};
  const double total=us(t,end);
  if(arm.stage_count>=arm.stages.size())throw std::runtime_error("diagnostic fixed cold storage exhausted");
  arm.stages[arm.stage_count++]={slot,us(t,released),us(released,submitted),us(submitted,waited),us(waited,result),us(result,end),total};
  return total;
}
void run(std::int64_t rows){
  Backend backend;const auto test=f::Case::source_role(rows);const f::Logical logical(test);
  const auto data=test.data(0),updated=test.data(1);const auto first=test.payloads(data),next=test.payloads(updated);
  const auto expected=f::f::floating(test.output_type,test.oracle(data));
  const auto expected_next=f::f::floating(test.output_type,test.oracle(updated));
  auto buffer=f::take(m::Buffer::create(backend.resource(),first[1].size(),256),"original source bank");
  f::check(buffer.view().write(first[1]),"original code bytes");
  auto bank=backend.owner?f::take(backend.owner.adopt_buffer(std::move(buffer)),"owned code source"):f::take(c::ReadLease::adopt(std::move(buffer)),"host ready code source");
  std::vector<std::unique_ptr<Arm>> arms;
  arms.push_back(make_arm(backend,test,logical,bank,"default",SIZE_MAX,false));
  auto budget=make_arm(backend,test,logical,bank,"budget3MiB",3U*1024U*1024U,false);
  const bool natural_bounded=budget&&budget->packed==1;
  if(budget)arms.push_back(std::move(budget));
  if(!natural_bounded)arms.push_back(make_arm(backend,test,logical,bank,"forced_recipe",SIZE_MAX,true));
  bank={}; // All three compile attempts received the same original immutable source.
  for(auto &arm:arms){
    const auto first_us=call(*arm,backend,logical,0);EXPECT_EQ(arm->raw[0],expected);property(arm->name+"_first_complete_call_us",number(first_us));
    for(std::size_t i=0;i<2;++i)f::check(arm->inputs[1][i].view().write(next[i==0?0U:3U]),"other slot generation");
    (void)call(*arm,backend,logical,1);EXPECT_EQ(arm->raw[1],expected_next);
    EXPECT_FALSE(arm->slots[0].submit(backend.queue));
    const auto old=f::take(arm->retained[0].tensor(),"old slot result");std::vector<std::byte> old_bytes(expected.size());
    f::check(f::take(old.storage().subview(0,old_bytes.size()),"old exact range").read(old_bytes),"old read");EXPECT_EQ(old_bytes,expected);
    arm->retained={};
    for(std::size_t slot=0;slot<2;++slot)for(std::size_t i=0;i<2;++i)f::check(arm->inputs[slot][i].view().write(first[i==0?0U:3U]),"same benchmark input");
    (void)call(*arm,backend,logical,0);EXPECT_EQ(arm->raw[0],expected);
  }
  // Eleven interleaved, complete host calls per arm; no event-only timing.
  for(std::size_t rep=0;rep<11;++rep)for(std::size_t k=0;k<arms.size();++k){
    const auto index=rep%2==0?k:arms.size()-1-k;auto &arm=*arms[index];const auto slot=rep%2;
    arm.samples.push_back(call(arm,backend,logical,slot));EXPECT_EQ(arm.raw[slot],expected);
  }
  for(auto &arm:arms){
    auto sorted=arm->samples;std::sort(sorted.begin(),sorted.end());std::ostringstream samples;samples<<std::setprecision(12);
    for(auto value:arm->samples)samples<<value<<',';
    property(arm->name+"_complete_samples_us",samples.str());property(arm->name+"_complete_median_us",number(sorted[sorted.size()/2]));
    std::ostringstream stages;stages<<std::setprecision(12);
    EXPECT_EQ(arm->stage_count,std::size_t{14});
    for(std::size_t i=0;i<arm->stage_count;++i){const auto &v=arm->stages[i];
      stages<<"call="<<i<<",slot="<<v.slot<<",release="<<v.release<<",submit="<<v.submit<<",wait="<<v.wait<<",result="<<v.result<<",read="<<v.read<<",total="<<v.total<<';';
    }
    property(arm->name+"_stage_samples_us",stages.str());
    arm->slots={};arm->compiled={};arm->inputs={};arm->pool={};
    for(const auto &result:arm->retained){const auto tensor=f::take(result.tensor(),"escaped original result");std::vector<std::byte> raw(expected.size());f::check(f::take(tensor.storage().subview(0,raw.size()),"escaped exact range").read(raw),"escaped read");EXPECT_EQ(raw,expected);}
  }
  property("scope","finite artificial source-bound role M1/M2 N128 K7168; no checkpoint payload/model/Qwen decode/throughput extrapolation");
  property("timing_boundary","same Commands; old result release+submit+Completion.wait+GraphOutput/tensor+exact result read; assertions/input updates outside timer");
  property("budget_semantics","StorageDomain.workspace_budget_bytes=3MiB; unchanged default search limits; aliases not added twice; provider unknown-private remains unknown");
}
#if defined(HYLE_OUTER_BENCH_CUDA)
TEST(CudaOuterFp8RouteBench, M1){run(1);}
TEST(CudaOuterFp8RouteBench, M2){run(2);}
#else
TEST(CpuOuterFp8RouteBench, M1){run(1);}
TEST(CpuOuterFp8RouteBench, M2){run(2);}
#endif
} // namespace
