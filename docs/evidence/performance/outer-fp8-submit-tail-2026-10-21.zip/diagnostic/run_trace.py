"""Plan by default. Root alone uses --run for one existing CUDA M1 diagnostic process."""
from pathlib import Path
import argparse
import importlib.util
import os
import re
import subprocess
import sys
import xml.etree.ElementTree as ET

sys.dont_write_bytecode=True
D=Path(__file__).resolve().parent;P=D.parent;A=P.parent
spec=importlib.util.spec_from_file_location('z_host_tools',A/'quark-block128-scale-2026-10-21/windows/build.py')
h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h);b,c=h.b,h.c
NSYS=Path('C:/Program Files/NVIDIA Corporation/Nsight Systems 2026.1.3/target-windows-x64/nsys.exe')

def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--run',action='store_true');args=parser.parse_args()
    out=D/'nsys-api-attempt1';out.mkdir(exist_ok=True);(out/'tmp').mkdir(exist_ok=True)
    help_ids=[]
    for tag,command in [('version',[str(NSYS),'--version']),('profile-help',[str(NSYS),'profile','--help']),('trace-help',[str(NSYS),'profile','--help=trace']),
                         ('windows-help',[str(NSYS),'profile','--help=windows']),('export-help',[str(NSYS),'export','--help'])]:
        path=out/(tag+'.log')
        if not path.exists():
            result=subprocess.run(command,cwd=h.R,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,encoding='utf8',errors='replace')
            path.write_text(result.stdout,encoding='utf8');assert result.returncode==0
        help_ids.append(b.identity(path))
    trace_help=(out/'profile-help.log').read_text(encoding='utf8')
    assert '--cuda-trace-all-apis=' in trace_help and "'cuda'" in trace_help
    link_path=D/'checks/link1/link-plan.json';plan=c.read(link_path)
    assert all(h.same(row) for row in plan['inputs'])
    image=Path(next(x[5:] for x in plan['command'] if x.upper().startswith('/OUT:')))
    expected=c.read(D/'checks/link1/image.json');assert b.identity(image)==expected
    env,runtime=b.environment(plan['command'],[x['path'] for x in plan['inputs']],out)
    names=sorted({x.decode('ascii') for x in re.findall(rb'hyle_ggml_cpu_avx2_[A-Za-z0-9_]+\.dll(?=\x00)',image.read_bytes())})
    modules=[]
    for name in names:
        source=next((Path(folder)/name for folder in runtime if (Path(folder)/name).is_file()),None)
        assert source is not None,name
        destination=image.parent/name
        modules.append(dict(source=b.identity(source),destination=str(destination)))
        if args.run:
            if not destination.exists():os.link(source,destination)
            assert os.path.samefile(source,destination)
    profile=[str(NSYS),'profile','--trace=cuda','--sample=none','--cpuctxsw=none',
        '--cuda-trace-all-apis=true','--discard-environment=true','--force-overwrite=false',
        '--output='+str(out/'capture'),str(image),'--gtest_filter=CudaOuterFp8RouteBench.M1',
        '--gtest_output=xml:'+str(out/'tests.xml')]
    export=[str(NSYS),'export','--type=sqlite','--force-overwrite=false','--output='+str(out/'capture.sqlite'),str(out/'capture.nsys-rep')]
    c.save(out/'plan.json',dict(status='root_run_required_diagnostic_only',tool=b.identity(NSYS),help_queries=help_ids,
        profile_command=profile,export_command=export,image=expected,link_plan=b.identity(link_path),private_modules=modules,
        scope='One existing M1 process with unchanged preflight/11samples/Commands. CUDA all-API instrumentation perturbs latency; never pool with unprofiled throughput.',
        capabilities='Local Windows help advertises CUDA tracing/all-APIs; CPU sample/contextswitch requires admin so disabled. No WDDM/CPU sampling/metrics/capture-mode change.'))
    if not args.run:
        print(str(out/'plan.json'));return
    assert not (out/'profile.result.json').exists(),'Preserve the actual attempt; do not launch a second trace'
    c.save(out/'runtime-environment.json',dict(PATH=env['PATH'],runtime=runtime,private_modules=modules))
    c.execute('profile',profile,env,out)
    cases=ET.parse(out/'tests.xml').findall('.//testcase')
    assert len(cases)==1 and cases[0].find('failure') is None and cases[0].find('skipped') is None
    c.execute('export',export,env,out)
    for tag,command in [('stages',[sys.executable,str(D/'parse.py'),str(out/'tests.xml')]),
                        ('analyze',[sys.executable,str(D/'analyze_trace.py'),str(out/'capture.sqlite')])]:
        c.execute(tag,command,env,out)
    c.save(out/'receipt.json',dict(passed=True,cases=1,failed=0,skipped=0,
        profiler_result=b.identity(out/'profile.result.json'),xml=b.identity(out/'tests.xml'),
        report=b.identity(out/'capture.nsys-rep'),sqlite=b.identity(out/'capture.sqlite'),
        analysis=b.identity(out/'api-analysis.json'),instrumented_not_throughput=True,GPU_processes=1))
    print(str(out/'receipt.json'))

if __name__=='__main__':main()
