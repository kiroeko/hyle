"""Two focused CXX owners and links against current Z products; never execute GPU work."""
from pathlib import Path
import concurrent.futures
import importlib.util
import sys

sys.dont_write_bytecode=True
P=Path(__file__).resolve().parent
Z=P.parent/'quark-block128-scale-2026-10-21'
spec=importlib.util.spec_from_file_location('z_compile_helpers',Z/'windows/build.py')
h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
b,c,R=h.b,h.c,h.R

def compile_owner(arm):
    recipe=Z/'windows/checks/attempt1'/(arm+'-scale-policy-test')/'identity.json'
    old=c.read(recipe);source=P/'role_bench.cc';tag=arm+'-outer-route-bench'
    out=P/arm/'checks/attempt1';out.mkdir(parents=True,exist_ok=True);(out/'tmp').mkdir(exist_ok=True)
    assert not (out/'compile.result.json').exists()
    command=b.host_command(old['command'],source,tag,out)
    if arm=='cuda':command.append('-DHYLE_OUTER_BENCH_CUDA=1')
    for flag in ['/W4','/WX']:
        if flag not in command:command.append(flag)
    source_id=b.identity(source)
    c.save(out/'compile-plan.json',dict(command=command,source=source_id,recipe=b.identity(recipe),GPU_runs=0,SDK_builds=0))
    env,_=b.environment(command,[],out);c.execute('compile',command,env,out)
    deps=c.read(out/(tag+'-deps.json'))['Data'];paths=list(dict.fromkeys([deps['Source'],*deps['Includes']]))
    dependencies=[b.identity(path) for path in paths]
    assert all(h.same(row) for row in [source_id,*dependencies])
    result=dict(command=command,source=source_id,object=b.identity(out/(tag+'.obj')),old_object=old['object'],
        recipe=b.identity(recipe),dependencies=dependencies,source_dependencies=b.identity(out/(tag+'-deps.json')),GPU_runs=0,SDK_builds=0)
    c.save(out/'identity.json',result);return result

def link(arm,test):
    base=Z/arm/'checks/link1/link-plan.json';plan=c.read(base)
    assert all(h.same(row) for row in plan['inputs'])
    assert sum(c.key(row['path'])==c.key(test['old_object']['path']) for row in plan['inputs'])==1
    inputs=[test['object'] if c.key(row['path'])==c.key(test['old_object']['path']) else row for row in plan['inputs']]
    command=[test['object']['path'] if c.key(arg)==c.key(test['old_object']['path']) else arg for arg in plan['command']
        if not arg.upper().startswith(('/OUT:','/MAP:','/PDB:','/IMPLIB:'))]
    out=P/arm/'checks/link1';out.mkdir(parents=True,exist_ok=True);(out/'tmp').mkdir(exist_ok=True)
    assert not (out/'link.result.json').exists()
    image=out/(arm+'-outer-route-bench.exe');command+=['/OUT:'+str(image),'/MAP:'+str(image.with_suffix('.map')),'/IMPLIB:'+str(image.with_suffix('.lib'))]
    arguments=[arg for arg in command if Path(arg).is_absolute() and Path(arg).suffix.lower() in ['.obj','.lib']]
    assert list(map(c.key,arguments))==[c.key(row['path']) for row in inputs]
    c.save(out/'link-plan.json',dict(command=command,inputs=inputs,base=b.identity(base),
        replacements=[dict(source=test['source'],old_object=test['old_object'],object=test['object'])],GPU_runs=0,SDK_builds=0))
    env,runtime=b.environment(command,[row['path'] for row in inputs],out)
    c.save(out/'runtime-environment.json',dict(PATH=env['PATH'],runtime=runtime))
    c.execute('link',command,env,out);c.save(out/'image.json',b.identity(image))
    return dict(arm=arm,image=b.identity(image),link_plan=b.identity(out/'link-plan.json'),runtime_environment=b.identity(out/'runtime-environment.json'),
        filter=('Cuda' if arm=='cuda' else 'Cpu')+'OuterFp8RouteBench.*',expected_tests=2,
        cases='M1/M2,N128,K7168; default vs3MiB budget, forced12node fallback only when budget does not select bounded',
        timing='cold compile/allocate-bind/prepare/first complete call;11 alternating complete warm host calls per arm',agent_GPU_runs=0)

def main():
    names=[P/'role_bench.cc',R/'tests/compute_models/fp8_outer_scale_fixture.h',
        R/'tests/compute_models/static_fp8_reference_fixture.h',R/'src/graph/static_fp8_region.h',R/'include/hyle/graph/executable.h']
    rows=[]
    for source in names:
        relative=source.relative_to(R);dest=P/'source'/relative;dest.parent.mkdir(parents=True,exist_ok=True)
        if dest.exists():assert dest.read_bytes()==source.read_bytes()
        else:dest.write_bytes(source.read_bytes())
        rows.append(dict(source=b.identity(source),snapshot=b.identity(dest)))
    c.save(P/'benchmark-source-freeze.json',dict(sources=rows,product_changes=0,SDK_builds=0,GPU_runs=0))
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
        records=dict(zip(['cpu','cuda'],pool.map(compile_owner,['cpu','cuda'])))
    c.save(P/'benchmark-compiles.json',dict(records=records,CXX=2,NVCC=0,SDK_builds=0,GPU_runs=0))
    arms=[link(arm,records[arm]) for arm in ['cpu','cuda']]
    c.save(P/'benchmark-ready-for-root-run.json',dict(status='two_CXX_two_links_ready_no_execution',arms=arms,
        scope='local role only; no Qwen/model throughput inference; no priority changes',CXX=2,links=2,NVCC=0,SDK_builds=0,GPU_runs=0))
    print(str(P/'benchmark-ready-for-root-run.json'),flush=True)

if __name__=='__main__':main()
