"""Offline only. Run after root confirms all 32 current processes completed."""
from pathlib import Path
import ast
from datetime import datetime, timezone, timedelta
import hashlib
import json
import math
import zipfile

R = Path(__file__).resolve().parents[2]
W = Path(__file__).resolve().parent
D = W / 'full-window'
OLD = R / '.scratch/inference-indexed-followup-20261027/full-window'
BEHAVIOR = R / '.scratch/inference-current-closure-20261026/behavior.py'
STEM = 'inference-batch-continuation-current-window-2026-10-27'
ARMS = ('hyle_plain', 'hyle_mtp', 'peer_plain', 'peer_mtp')
LABELS = tuple(w + '-' + m for w in ('single', 'two-turn') for m in ('timing', 'memory'))
METRICS = ('prefill_tokens_per_second', 'full_decode_tokens_per_second',
           'session_output_tokens_per_second', 'weights_load_seconds',
           'startup_to_ready_seconds', 'first_token_elapsed_seconds', 'startup_to_endpoint_seconds')


def read(p):
    return json.loads(Path(p).read_text(encoding='utf-8-sig'))


def digest(raw):
    return dict(bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


def pin(p):
    p = Path(p)
    return dict(path=str(p.resolve()), **digest(p.read_bytes()))


def exact(row):
    assert pin(row['path']) == row, row['path']


def producer_report(folder, arm):
    folder = Path(folder)
    if arm.startswith('hyle'):
        path = folder / 'stdout.log'
        lines = path.read_text(encoding='utf-8-sig').splitlines()
        raw = json.loads(next(line for line in reversed(lines) if line.startswith('{')))
    else:
        path = folder / 'consumer-result.json'
        raw = read(path)
    return raw, pin(path)


def save(p, value):
    p.parent.mkdir(parents=True, exist_ok=True)
    raw = json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + '\n'
    if p.exists():
        assert p.read_text(encoding='utf-8') == raw, 'Preserve different prior extraction: ' + str(p)
    else:
        p.write_text(raw, encoding='utf-8')


def stats(s):
    return {key: s[key] for key in ('count', 'median', 'min', 'max')}


def explained_telemetry(row):
    """Classify but NEVER delete a raw difference or assert equivalence."""
    name = row['path'].rsplit('.', 1)[-1]
    if name in ('cpu_ahead_prepared', 'cpu_ahead_hits', 'cpu_ahead_discarded'):
        return 'Bounded CPU integer-preparation cache telemetry; separate from model work and numerical output.'
    if name in ('decode_overlap', 'decode_overlap_available') and row.get('control') is None and row.get('candidate') is False:
        return 'New explicit policy fact; this retained window uses default overlap off.'
    if name in ('overlap_successor_submissions', 'overlap_successor_publications', 'overlap_successor_discards', 'overlap_successor_refusals') and row.get('control') is None and row.get('candidate') == 0:
        return 'New zero successor counter; no overlap successor was executed in this window.'
    return None


def main():
    destination = R / 'docs/evidence/performance'
    out, archive = (destination / (STEM + suffix) for suffix in ('.json', '.zip'))
    assert not out.exists() and not archive.exists(), 'Preserve previous publication'
    # Read every final result before creating even a comparison artifact. This
    # is not a runner and must never synthesize a result from an incomplete run.
    summaries = {label: read(D / label / 'summary.json') for label in LABELS}
    runs = {label: read(D / label / 'runs.json') for label in LABELS}
    for label in LABELS:
        expected = 12 if label.endswith('timing') else 4
        assert summaries[label]['status'] == 'complete_stable_within_arm_work'
        assert summaries[label]['within_arm_fixed_work_valid']
        assert summaries[label]['processes'] == len(runs[label]) == expected
    ready, binding = read(D / 'ready.json'), read(D / 'binding.json')
    assert not ready['instrumented'] and binding['current_image'] == ready
    assert ready['image']['sha256'] == '15dc462b5f9f3f0c7b8bc5c65fa6605233b12a83376888f3b9b5f9cc8563cae2'
    assert binding['peer']['image']['sha256'] == '433e7051f4c36d0d9b2297dc378631546b7e3c44630cda0653cba2d1ec6bbe8e'
    for row in (ready['image'], ready['runtime_environment'], ready['link_inputs'], ready['build'], ready['actual_dependencies'], binding['peer']['image'], binding['peer']['runtime_environment']):
        exact(row)
    compiled = read(ready['build']['path'])['compiled']
    assert compiled['original_source'] == ready['canonical_main']
    exact(compiled['source'])
    # Only pure definitions are extracted. behavior.py has top-level model
    # execution, so importing it would violate this offline artifact's scope.
    source = BEHAVIOR.read_text(encoding='utf-8')
    functions = [node for node in ast.parse(source).body
                 if isinstance(node, ast.FunctionDef) and node.name in ('normalize', 'differences')]
    assert {node.name for node in functions} == {'normalize', 'differences'}
    pure_source = '\n\n'.join(ast.get_source_segment(source, node) for node in functions) + '\n'
    namespace = {}
    exec(compile(ast.Module(body=functions, type_ignores=[]), str(BEHAVIOR) + ':pure-functions-only', 'exec'), namespace)
    compare_dir = W / 'full-window-offline-comparison'
    compare_dir.mkdir(exist_ok=True)
    pure_path = compare_dir / 'pure-functions.py'
    if pure_path.exists():
        assert pure_path.read_text(encoding='utf-8') == pure_source
    else:
        pure_path.write_text(pure_source, encoding='utf-8')
    old_controls = {}
    for workload in ('single', 'two-turn'):
        old_rows = read(OLD / (workload + '-timing') / 'runs.json')
        for arm in ARMS:
            old_controls[workload, arm] = next(row for row in old_rows if row['arm'] == arm)
    processes, comparisons = [], []
    for label in LABELS:
        workload, mode = label.rsplit('-', 1)
        s, rows = summaries[label], runs[label]
        assert s['baseline_date'] == '2026-10-25' and not s['historical_samples_pooled'] and not s['image_instrumented']
        for row in rows:
            p, observation, folder = row['process'], row['observation'], Path(row['folder'])
            assert folder.parent == D / label
            assert p['exit'] == 0 and not p['reader_errors'] and not p['profiler']
            assert p['memory_only'] == (mode == 'memory') and p['throughput_evidence'] == (mode == 'timing')
            assert p['image'] == (ready['image'] if row['arm'].startswith('hyle') else binding['peer']['image'])
            assert read(folder / 'observation.json') == observation
            assert all(math.isfinite(observation['metrics'][k]) and observation['metrics'][k] > 0 for k in METRICS)
            if row['arm'].startswith('hyle'):
                raw, _ = producer_report(folder, row['arm'])
                assert raw['active_sequences'] == raw['max_sessions'] == 1
                assert raw['decode_overlap'] is False and raw['decode_overlap_available'] is False
                assert raw['overlap_successor_submissions'] == raw['overlap_successor_publications'] == 0
                assert raw['live_committed_versions'] == 0
                assert raw['mtp_max_drafts'] == (1 if row['arm'].endswith('_mtp') else 0)
            processes.append(dict(window=label, arm=row['arm'], pid=p['pid'], exit=p['exit'],
                started_unix_ns=p['started_unix_ns'], finished_unix_ns=p['finished_unix_ns'], memory_only=p['memory_only']))
            prior = old_controls[workload, row['arm']]
            previous_raw, previous_report = producer_report(prior['folder'], row['arm'])
            current_raw, current_report = producer_report(folder, row['arm'])
            delta = namespace['differences'](namespace['normalize'](previous_raw), namespace['normalize'](current_raw))
            path = compare_dir / label / (folder.name + '.json')
            save(path, delta)
            named = [dict(change, explanation=explained_telemetry(change)) for change in delta if explained_telemetry(change)]
            other = [change for change in delta if not explained_telemetry(change)]
            comparisons.append(dict(window=label, arm=row['arm'], process=folder.name,
                previous_first_timing_observation=pin(Path(prior['folder']) / 'observation.json'),
                current_observation=pin(folder / 'observation.json'), differences=pin(path),
                previous_complete_producer_report=previous_report, current_complete_producer_report=current_report,
                difference_count=len(delta), changed_paths=[x['path'] for x in delta],
                named_telemetry_changes=named, other_changes=other,
                IDs_equal=prior['observation']['generated_ids'] == observation['generated_ids'],
                work_counters_equal=prior['observation']['work'] == observation['work']))
    assert len(processes) == len(comparisons) == 32
    comparison = dict(source=pin(BEHAVIOR), extracted_pure_functions=pin(pure_path),
        method='AST loads only exact normalize/differences definitions. Complete producer reports are Hyle final stdout JSON or peer original consumer-result.json; observation.raw slicing is not used. Only original clock/rate keys are normalized; no extra field is excluded. Named telemetry changes remain in every full difference record.',
        reference='First timing observation for each same workload/arm in the 04:52-04:54 indexed window. Every new timing and independent-memory observation is compared, including retained peer.',
        results=comparisons, differences_total=sum(x['difference_count'] for x in comparisons),
        named_telemetry_differences=sum(len(x['named_telemetry_changes']) for x in comparisons),
        other_differences=sum(len(x['other_changes']) for x in comparisons),
        all_IDs_equal=all(x['IDs_equal'] for x in comparisons), all_work_counters_equal=all(x['work_counters_equal'] for x in comparisons))
    save(compare_dir / 'summary.json', comparison)
    table, fairness, memory_quality = [], {}, {}
    for workload in ('single', 'two-turn'):
        timing, memory = summaries[workload + '-timing'], summaries[workload + '-memory']
        fairness[workload] = dict(within_arm_timing=True, within_arm_memory=True,
            between_arm_first_outputs={key: {name: value[name] for name in ('left_tokens', 'right_tokens', 'equal', 'first_divergence')} | {'overlapping_mismatches': len(value['overlapping_mismatches'])}
                                      for key, value in timing['between_arm_first_process_outputs'].items()}, memory_matches_timing_first={})
        for policy in ('plain', 'mtp'):
            line = dict(workload=workload, policy=policy)
            for side, arm in [('hyle', 'hyle_' + policy), ('llama_cpp', 'peer_' + policy)]:
                group, mem = timing['groups'][arm], memory['groups'][arm]
                first = next(row['observation'] for row in runs[workload + '-timing'] if row['arm'] == arm)
                independent = next(row['observation'] for row in runs[workload + '-memory'] if row['arm'] == arm)
                assert all(group[key]['count'] == 3 for key in METRICS)
                fairness[workload]['memory_matches_timing_first'][arm] = dict(IDs=first['generated_ids'] == independent['generated_ids'], work=first['work'] == independent['work'])
                line[side] = dict(timing={key: stats(group[key]) for key in METRICS},
                    independent_memory_bytes=mem['sampled_peaks'], generated_tokens=first['actual_generated_tokens'], stopped_on_EOS=first['stopped_on_EOS'],
                    work={key: value for key, value in first['work'].items() if value is not None}, unreported_work_counters=[key for key, value in first['work'].items() if value is None])
                memory_quality[workload + '/' + arm] = dict(requested_interval_seconds=mem['requested_interval_seconds'], sample_count=mem['sample_count'],
                    running_sample_count=mem['running_sample_count'], actual_sample_gaps_ms=stats(mem['actual_sample_gaps_ms']), sample_cost_ms=stats(mem['sample_cost_ms']),
                    null_sample_counts=mem['null_sample_counts'], unavailable_reasons=mem['unavailable_reasons'], setup_error=mem['setup_error'], thread_error=mem['thread_error'], counter_source=mem['counter_source'])
            line['hyle_relative_to_llama_percent'] = {key: (line['hyle']['timing'][key]['median'] / line['llama_cpp']['timing'][key]['median'] - 1) * 100 for key in METRICS[:3]}
            table.append(line)
    low, high = min(x['started_unix_ns'] for x in processes), max(x['finished_unix_ns'] for x in processes)
    stamp = lambda n, zone: datetime.fromtimestamp(n / 1e9, zone).isoformat()
    hardware = W / 'hardware-after-window.txt'
    report = dict(status='COMPLETE32_STABLE_WITHIN_ARM', date=datetime.fromtimestamp(high / 1e9, timezone(timedelta(hours=8))).date().isoformat(),
        process_count=32, timing_processes=24, independent_memory_processes=8,
        actual_window=dict(started_unix_ns=low, finished_unix_ns=high, started_UTC=stamp(low, timezone.utc), finished_UTC=stamp(high, timezone.utc),
            started_Asia_Shanghai=stamp(low, timezone(timedelta(hours=8))), finished_Asia_Shanghai=stamp(high, timezone(timedelta(hours=8)))),
        retained_protocol_baseline_date='2026-10-25', date_note='Original baseline_date is a protocol label; the actual process timestamps above identify this new window.',
        hyle=ready, retained_peer=binding['peer'], binding=pin(D / 'binding.json'),
        execution_scope=dict(N=1, R=1, capacity=1024, decode_overlap='off', ordinary='greedy', MTP='K1', prefix_cache='off', output_limit_per_turn=64),
        protocol='Same retained four arms, single/two real turns, three unmonitored timing samples and one independent memory process per arm/workload; no old samples pooled.',
        timer=summaries['single-timing']['timer'], table=table, fairness_and_work=fairness,
        old_window_nonclock_comparison=dict(report=pin(compare_dir / 'summary.json'), comparisons=32, Hyle_comparisons=16, retained_peer_comparisons=16,
            differences_total=comparison['differences_total'], named_telemetry_differences=comparison['named_telemetry_differences'], other_differences=comparison['other_differences'],
            IDs_equal=comparison['all_IDs_equal'], work_counters_equal=comparison['all_work_counters_equal'], reference_window=str(OLD),
            normalization='Exact original normalize/differences. Complete nonclock raw reports compared; named CPU-ahead/overlap telemetry differences remain explicit, not discarded.'),
        memory_measurement_quality=memory_quality, processes=processes,
        hardware_after_window=pin(hardware) if hardware.is_file() else None,
        hardware_observation='Original per-group before/after GPU observations are archived. Optional root post-window identity is included only if present; no fixed-frequency, exclusive-GPU or thermal-control claim.',
        original_summary_pins={label: pin(D / label / 'summary.json') for label in LABELS},
        limits=['Retained peer433e and frozen native core; not latest-upstream llama.cpp.',
            'This window is ordinary/MTP R1 with default overlap off and MTP K1. It measures the current image; it is not evidence for R2 continuation performance.',
            'Natural IDs, accepted drafts and target/draft work may differ across arms; these are complete natural-consumer observations, not equal-mathematical-work or task-quality rankings.',
            'Rates are medians of3 and retain their min/max plus original samples in the archive; no statistical-significance or individual-optimization causal claim.',
            'Memory uses1 independent process per arm/workload, excluded from timing medians. PSAPI/PDH peaks are sampled lower bounds; do not sum independent dedicated/shared maxima or RAM/commit as physical totals.',
            'Loading/ready retain original producer endpoints and existing OS file caches. Default reporting/IO remains inside its natural boundaries.',
            'Full old-window differences remain explicit. Host-metadata telemetry is explained separately and is not a numerical/work-equivalence claim.',
            'No CPU/Apple/Vulkan/mixed, multi-user, other-model/quantization or full task-quality claim.'])
    members, origins = {}, {}

    def add(name, path):
        path = Path(path)
        assert name not in members and path.is_file() and path.suffix.lower() in {'.json', '.log', '.py', '.txt', '.ids', '.tsv', '.cc'}
        members[name], origins[name] = path.read_bytes(), str(path.resolve())

    for name in ('ready.json', 'peer-ready.json', 'binding.json', 'arms.json'):
        add('binding/' + name, D / name)
    add('binding/offline-export-attempt1.json', W / 'archive-attempt1.json')
    if hardware.is_file():
        add('binding/hardware-after-window.txt', hardware)
    for name in ('adapter', 'protocol', 'original_arms', 'input_manifest', 'prompt', 'two_turn_schedule'):
        add('binding/actual-' + name + Path(binding[name]['path']).suffix, binding[name]['path'])
    for name in ('build', 'runtime_environment', 'link_inputs', 'actual_dependencies'):
        add('hyle/' + name + '.json', ready[name]['path'])
    add('hyle/frozen-model-main.cc', compiled['source']['path'])
    for name in ('command', 'compiler_dependencies'):
        add('hyle/' + name + '.json', compiled[name]['path'])
    for name in ('source-freeze-model1.json', 'build.py', 'full-window-plan.json'):
        add('hyle/' + name, W / name)
    for name in ('source', 'compiled_identity', 'runtime_environment', 'link_plan'):
        add('peer/' + name + Path(binding['peer'][name]['path']).suffix, binding['peer'][name]['path'])
    protocol_files = [Path(__file__), BEHAVIOR, R / '.scratch/qwen-mtp-window-20261022/window.py',
        R / '.scratch/qwen-mtp-quality-20261022/current-window/performance.py', R / '.scratch/qwen-mtp-final-window-20261024/turns.py',
        R / '.scratch/shared-execution-20261021/observer.py',
        R / '.scratch/architecture-refactor-2026-10-18/d4-windows-preparation-2026-10-21/first-decode-startup-2026-10-21/multiturn/multiturn_run.py',
        R / '.scratch/architecture-refactor-2026-10-18/qwen-gpu-comparison/memory-probe/memory_probe.py', R / '.scratch/qwen-mtp-window-20261022/inputs/prompt.ids']
    for i, path in enumerate(protocol_files):
        add(f'protocol/{i}-{path.name}', path)
    for label in LABELS:
        for path in sorted((D / label).iterdir()):
            if path.is_file() and path.suffix in ('.json', '.log'):
                add('actual/' + label + '/' + path.name, path)
        for row in runs[label]:
            folder = Path(row['folder'])
            for path in sorted(folder.iterdir()):
                if path.is_file() and path.suffix in ('.json', '.log') and path.name != 'observation.json':
                    add('actual/' + label + '/' + folder.name + '/' + path.name, path)
        add('binding/' + label + '-plan.json', D / (label + '-plan.json'))
    add('comparison/summary.json', compare_dir / 'summary.json')
    add('comparison/pure-functions.py', pure_path)
    for row in comparisons:
        add('comparison/' + row['window'] + '/' + row['process'] + '.json', row['differences']['path'])
    for (workload, arm), row in old_controls.items():
        add('comparison/old-first-timing/' + workload + '-' + arm + '.json', Path(row['folder']) / 'observation.json')
        _, original_report = producer_report(row['folder'], arm)
        add('comparison/old-complete-producer/' + workload + '-' + arm + Path(original_report['path']).suffix, original_report['path'])
    index = dict(members=[dict(member=name, original_path=origins[name], **digest(raw)) for name, raw in sorted(members.items())],
        exclusions='No models, EXE/DLL/OBJ/LIB/PDB, SDK, full traces or dependency trees. Exact observations embedded in runs.json; old first controls and exact pure comparison retained. Only the one frozen consumer source and peer consumer source are included.')
    index_bytes = (json.dumps(index, ensure_ascii=False, indent=2) + '\n').encode('utf-8')
    destination.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for name, raw in sorted(members.items()):
            z.writestr(name, raw)
        z.writestr('member-sha256.json', index_bytes)
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None and len(z.namelist()) == len(members) + 1
        assert z.read('member-sha256.json') == index_bytes
        for name, raw in members.items():
            assert digest(z.read(name)) == digest(raw)
    report['archive'] = dict(**pin(archive), members=len(members) + 1, CRC_and_member_SHA256_verified=True)
    save(out, report)
    print(json.dumps(dict(report=pin(out), archive=report['archive'],
        nonclock_difference_count=comparison['differences_total'], other_differences=comparison['other_differences'],
        table=[dict(workload=x['workload'], policy=x['policy'], hyle=[round(x['hyle']['timing'][key]['median'], 3) for key in METRICS[:3]],
                    peer=[round(x['llama_cpp']['timing'][key]['median'], 3) for key in METRICS[:3]]) for x in table]), indent=2))


if __name__ == '__main__':
    main()
