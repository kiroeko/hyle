def normalize(value):
    if isinstance(value, list):
        return [normalize(item) for item in value]
    if isinstance(value, dict):
        return {key: normalize(item) for key, item in value.items()
                if not any(token in key for token in ['seconds','tokens_per_second',
                       'clock_unix','unix_ns','unix_ms'])}
    return value

def differences(left, right, path='$'):
    if type(left) is not type(right):
        return [{'path': path, 'control': left, 'candidate': right}]
    if isinstance(left, dict):
        result = []
        for key in sorted(set(left) | set(right)):
            if key not in left or key not in right:
                result.append({'path':path+'.'+key,'control':left.get(key),'candidate':right.get(key)})
            else:
                result.extend(differences(left[key], right[key], path+'.'+key))
        return result
    if isinstance(left, list):
        if len(left) != len(right):
            return [{'path':path,'control_length':len(left),'candidate_length':len(right)}]
        return [row for i,(a,b) in enumerate(zip(left,right)) for row in differences(a,b,f'{path}[{i}]')]
    return [] if left == right else [{'path':path,'control':left,'candidate':right}]
