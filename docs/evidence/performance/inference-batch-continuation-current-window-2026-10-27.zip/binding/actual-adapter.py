"""Reuse retained 32-process protocol; setup/plan/analyze never run a model."""
from pathlib import Path
import importlib.util
import os
import sys

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = W.parents[1]
PROTOCOL = R / '.scratch/mtp-performance-convergence-20261025/baseline/window.py'
BUILD = W / 'ready-cli1.json'
spec = importlib.util.spec_from_file_location('batch_continuation_four_arm_protocol', PROTOCOL)
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)
m.D = W / 'full-window'
ORDER = [('single', 'timing'), ('single', 'memory'), ('two-turn', 'timing'), ('two-turn', 'memory')]


def exact(row):
    assert m.base.identity(row['path']) == row, row['path']


def setup():
    assert not m.D.exists(), 'Preserve previous results; no replacement samples'
    ready = m.base.read(BUILD)
    compiled = ready['compiled']
    for row in [ready['image'], ready['runtime'], ready['inputs'], compiled['source'],
                compiled['original_source'], compiled['actual_dependencies']]:
        exact(row)
    for row in m.base.read(ready['inputs']['path']):
        exact(row)
    for row in m.base.read(compiled['actual_dependencies']['path']):
        exact(row)
    source = m.base.identity(R / 'engine/models/qwen35/main.cc')
    assert source == compiled['original_source']
    peer_path = R / '.scratch/qwen-mtp-final-window-20261024/peer-link1/ready.json'
    peer = m.base.read(peer_path)
    exact(peer['image']); exact(peer['runtime_environment'])
    assert peer['image']['sha256'] == '433e7051f4c36d0d9b2297dc378631546b7e3c44630cda0653cba2d1ec6bbe8e'
    arms_path = PROTOCOL.parent / 'arms.json'
    arms = m.base.read(arms_path)
    m.D.mkdir()
    current = dict(image=ready['image'], instrumented=False, canonical_main=source,
                   runtime_environment=ready['runtime'], link_inputs=ready['inputs'],
                   build=m.base.identity(BUILD), actual_dependencies=compiled['actual_dependencies'])
    m.base.save(m.D / 'ready.json', current)
    m.base.save(m.D / 'peer-ready.json', peer)
    for arm, row in arms['arms'].items():
        row['ready'] = str(m.D / ('ready.json' if arm.startswith('hyle') else 'peer-ready.json'))
    m.base.save(m.D / 'arms.json', arms)
    fixture = R / '.scratch/qwen35-unsloth-mtp-20261024/geometry-v2-check/original'
    m.base.save(m.D / 'binding.json', dict(current_image=current, peer=peer,
        peer_ready=m.base.identity(peer_path), adapter=m.base.identity(Path(__file__)),
        protocol=m.base.identity(PROTOCOL), original_arms=m.base.identity(arms_path),
        input_manifest=m.base.identity(fixture / 'weights.tsv'), prompt=m.base.identity(fixture / 'prompt.ids'),
        two_turn_schedule=m.base.identity(m.F / 'natural-inputs/performance64.txt'),
        scope='Current uninstrumented canonical CLI; retained peer image433e with its frozen core, not latest upstream. '
              'Original four-arm order, clocks, quotas, independent PSAPI/PDH observer and parser unchanged. '
              'No historical samples pooled, no warmup/profiler/SDK build/model download. '
              'R1 default overlap-off and MTP K1; this protocol does not measure the R2 overlap candidate. '
              'Natural IDs and accepted-draft work may differ across arms; no equal-mathematical-work or quality claim.',
        planned_processes=32, timing_processes=24, memory_processes=8))
    print('SETUP_ONLY_NO_MODELS', flush=True)


def main():
    action = sys.argv[1]
    if action == 'setup':
        setup(); return
    if action == 'plan-all':
        for workload, mode in ORDER:
            m.WORKLOAD = workload
            output = m.D / (workload + '-' + mode)
            assert not output.exists()
            m.base.save(m.D / (workload + '-' + mode + '-plan.json'), m.plan(m.D / 'arms.json', mode, output))
            print('PLAN_ONLY', workload, mode, flush=True)
        return
    assert action in ('run-one', 'analyze-one')
    workload, mode = sys.argv[2:]
    assert (workload, mode) in ORDER
    m.WORKLOAD = workload
    output = m.D / (workload + '-' + mode)
    if action == 'run-one':
        assert not output.exists(), 'No automatic retry or replacement samples'
        os.environ.update(HF_HUB_OFFLINE='1', TRANSFORMERS_OFFLINE='1')
        result = m.base.run(m.D / 'arms.json', mode, output)
    else:
        result = m.analyze(output)
    print(result['status'], result['processes'], result['within_arm_fixed_work_valid'], flush=True)


if __name__ == '__main__':
    main()
