"""Extend only the retained peer consumer's fixed loop, preserving llama math/API."""
from pathlib import Path
import importlib.util
import sys
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('long_peer_helpers',S/'measure.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
b,c=m.b,m.c

def build():
    out=S/'long-peer';out.mkdir(exist_ok=True);(out/'tmp').mkdir(exist_ok=True)
    assert not (out/'image.json').exists(), 'Do not overwrite a completed peer image'
    path=m.A/'cuda-explicit-rope/performance-prepared/peer-link-plan.json'
    base=c.read(path)
    meta=m.h.h.metadata({'peer':base})
    rows=[(r,meta[c.key(r['path'])]) for r in base['inputs'] if c.key(r['path']) in meta]
    assert len(rows)==1
    old,recipe=rows[0]
    original=Path(recipe['source_path']);text=original.read_text(encoding='utf-8')
    text=m.replace_once(text,'Teacher-forced input tokens keep all 32 observations on the same fixed prefix.',
        'Teacher-forced input tokens keep observations on the same fixed prefix; bounded extended loop.')
    text=m.replace_once(text,
        '    if (prompt.empty() || prompt.size() > 224 || decode.size() != 31 || (!targets.empty() && targets.size() != 32))\n        throw std::runtime_error("expected 1..224 prompt IDs, 31 fixed decode IDs and optional 32 target IDs");',
        '    if (prompt.empty() || prompt.size() > 224 || decode.empty() || decode.size() > 127 ||\n'
        '        prompt.size() + decode.size() > 256 || (!targets.empty() && targets.size() != decode.size() + 1))\n'
        '        throw std::runtime_error("expected bounded prompt and 1..127 fixed decode IDs within context256");')
    text=m.replace_once(text,'    std::array<Step, 32> steps{};','    std::vector<Step> steps(decode.size() + 1);')
    text=m.replace_once(text,'    for (int phase = 0; phase != 32; ++phase) {','    for (int phase = 0; phase != int(steps.size()); ++phase) {')
    source=out/'peer_benchmark.cpp';source.write_text(text,encoding='utf-8',newline='\n')
    # Preserve the retained peer flags, including its original warning policy.
    # The product helper intentionally requires a different strict /W4 /WX recipe.
    command=[];skip=False
    for x in recipe['command']:
        if skip:skip=False;continue
        if x.lower()=='/sourcedependencies':skip=True;continue
        if c.key(x)==c.key(original) or x.lower().startswith(('/fo','/fd')):continue
        command.append(x)
    command+=['/sourceDependencies',str(out/'peer-deps.json'),str(source),'/Fo'+str(out/'peer.obj'),'/Fd'+str(out/'peer.pdb')]
    env,runtime=b.environment(base['command'],[x['path'] for x in base['inputs']],out)
    c.execute('compile',command,env,out);obj=b.identity(out/'peer.obj')
    image=out/'peer.exe'
    link=[obj['path'] if c.key(x)==c.key(old['path']) else x for x in base['command']
          if not x.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:'))]
    link+=['/OUT:'+str(image),'/MAP:'+str(image.with_suffix('.map')),'/IMPLIB:'+str(image.with_suffix('.lib'))]
    reused=[x for x in base['inputs'] if c.key(x['path'])!=c.key(old['path'])]
    assert all(m.h.h.same_identity(x) for x in reused)
    c.save(out/'link-plan.json',dict(command=link,inputs=[obj,*reused],compile_command=command,source=b.identity(source),original_source=b.identity(original),base=b.identity(path),scope='Only bounded consumer phase count/storage changed; same unchanged official llama implementation and sampling endpoint',runtime=runtime))
    c.execute('link',link,env,out);c.save(out/'image.json',b.identity(image))
    fixed=c.read(m.A/'qwen-gpu-comparison/128-prefill/fixed-inputs.json')
    old_tape=fixed['decode_input_ids'];assert len(old_tape)==31
    tape=(old_tape*5)[:127]
    fixed.update(decode_input_ids=tape,target_ids=[],extension_note='Original31 forced-input tape repeated/truncated to127 for a bounded longer timing journey; not natural generation or model-quality acceptance.')
    c.save(out/'fixed-inputs.json',fixed)
    (out/'decode.ids').write_text('\n'.join(map(str,tape))+'\n')

if __name__=='__main__':build()
