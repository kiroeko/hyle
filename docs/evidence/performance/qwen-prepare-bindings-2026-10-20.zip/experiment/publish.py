"""Publish compact source/command/result evidence, excluding rebuildable binaries."""
from pathlib import Path
import hashlib
import json
import zipfile
S=Path(__file__).resolve().parent
A=S.parent
ROOT=A.parents[1]
DEST=ROOT/'docs/evidence/performance'
NAME='qwen-prepare-bindings-2026-10-20'

def read(p):return json.loads(Path(p).read_text(encoding='utf-8'))
def identity(p):
    p=Path(p);data=p.read_bytes()
    return dict(path=str(p),bytes=len(data),sha256=hashlib.sha256(data).hexdigest())

def main():
    target=DEST/(NAME+'.json');archive=DEST/(NAME+'.zip')
    assert not target.exists() and not archive.exists()
    freeze=read(A/'d1-binding-span-reuse/source-freeze.json')
    for row in freeze['files']:assert identity(ROOT/row['path'])['sha256']==row['sha256']
    cpu=read(S/'cpu-regression/summary.json');cuda=read(S/'cuda-regression/summary.json');numeric=read(S/'correctness/summary.json')
    assert cpu['passed'] and cpu['cases']==18 and cuda['passed'] and cuda['cases']==6 and numeric['passed'] and numeric['equal_vectors']==64
    review=read(S/'independent-timing-review.json')
    windows={name:read(S/name/'summary.json') for name in ['timing','long-timing']}
    assert all(x['status']=='nine_uninstrumented_processes_exit_zero' and x['current_matches_baseline_ids'] for x in windows.values())
    files={}
    suffixes={'.json','.log','.xml','.py','.cc','.cpp','.h','.csv','.diff','.ids','.tsv'}
    for base,prefix in [(S,'experiment'),(A/'d1-binding-span-reuse','implementation')]:
        for path in sorted(base.rglob('*')):
            if path.is_file() and path.suffix.lower() in suffixes:
                files[prefix+'/'+path.relative_to(base).as_posix()]=path
    files['product/tools/qwen35_text/main.cc']=ROOT/'tools/qwen35_text/main.cc'
    members=[]
    with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for name,path in files.items():
            data=path.read_bytes();z.writestr(name,data)
            members.append(dict(path=name,bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
        z.writestr('manifest.json',json.dumps(members,indent=2)+'\n')
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None
        for row in members:assert hashlib.sha256(z.read(row['path'])).hexdigest()==row['sha256']
    value=dict(date='2026-10-20',status='D1_generic_binding_span_reuse_implemented_and_bounded_windows_complete',
        scope='Windows RTX4070, retained full-CUDA Qwen3.5-2B BF16 text closure. Same retained main and providers; only two generic Graph implementation objects replaced. Subsequent format-capability source owners were not all rebuilt, so this is not an all-current-source SDK delivery.',
        change='Separate reusable physical TensorView spans from each configuration episode readiness. One opaque ResourceEpisode candidate flag; same real configuration tensors, stable binding proof and revision checks; original unstable command hook retained. Fresh input/output completeness, lease candidates, seals, source/queue/dependency/transfer preparation and original lifetime gates remain.',
        source_freeze=freeze,
        diagnosis=read(S/'attribution.json'),
        preparation_and_deltas=read(S/'window-analysis.json'),
        windows=windows,
        validation=dict(cpu=dict(cases=18,failed=0,skipped=0,names=cpu['names']),cuda=cuda,
            qwen_hidden_logits=dict(byte_equal_vectors=64,all_finite=numeric['observation']['all_outputs_finite'],independent_quality_acceptance=False),
            cold_route_tsv=read(S/'route-comparison.json'),
            source_review=read(A/'d1-binding-span-reuse/independent-review.json'),timing_review=review,
            compile=dict(product_CXX=2,test_CXX=1,diagnostic_CXX=3,peer_consumer_CXX=1,total_CXX=7,links=6,NVCC=0,SDK_rebuild=0),
            repeated_numerical_vectors='Candidate64 vectors equal retained baseline; archived hashes/analysis, no duplicate tensor payload in archive.'),
        metadata_errata=['Both original timing/inputs.json files copied an old PEER limits list under precision_limit. That stale list mentions six processes and31 decode. Raw commands/logs/results are preserved unchanged; actual EACH window has9 processes,3 per arm. Short128+31, long128+127, context256. The generator is corrected in archived experiment.py.',
            'Long consumer changes only bounded observation count/array storage and input checks; underlying llama libraries, compute math and official sampling endpoint are unchanged. Original31 tape is repeated/truncated to127, a fixed timing load rather than natural generation/quality acceptance.'],
        limits=['Three independent processes per arm per window, no statistical significance or universal stable-win claim. Windows are not pooled and differ in actual visible KV length.',
            'Uninstrumented windows mean no added D1 buckets, profiler or external sampling. Retained ordinary timers/logs and original peer coarse memory snapshots remain; not a zero-observation executable.',
            'Both endpoints include actual host token. Hyle mostly BF16 activation/output while peer many F32 intermediates; peer official greedy automatically returns additional993280B sampled logits. Not strictly identical operator mathematics.',
            'Fixed predictions and64 baseline vectors do not independently accept model quality.',
            'Short prefill current/baseline median -1.126%; long -0.0085%. Preserve both windows, no stable prefill regression or nonregression claim.',
            'No new memory peak, power/energy, physical kernel trace, Linux or Apple execution in this batch. Metadata upload wait and ready lease publication unchanged.',
            'Same-reset A-B-A and payload callback ordinary-bind cases were source-reviewed, not separately added as runtime tests.'],
        next='D2 measured projection-role differences; do not treat D1 or one Qwen result as completion of the full model/quantization/platform goal.',
        archive={**identity(archive), 'path':archive.name,'members':len(members)+1,'all_member_hashes_verified':True})
    target.write_text(json.dumps(value,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
    print(json.dumps(dict(evidence=identity(target),archive=value['archive']),ensure_ascii=False))

if __name__=='__main__':main()
