"""Attribute replay binding cost without changing the original replay journey."""
from pathlib import Path
import importlib.util
import sys
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('d1_measure',S/'measure.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
b,c,h=m.b,m.c,m.h
OUT=S/'deep'

def build():
    checks=OUT/'build';checks.mkdir(parents=True,exist_ok=False);(checks/'tmp').mkdir()
    main=(S/'main-diagnostic.cc').read_text(encoding='utf-8')
    main=m.replace_once(main,'namespace qwen35 {','extern "C" double hyle_d1_replay_bindings_seconds() noexcept;\n\nnamespace qwen35 {')
    main=m.replace_once(main,'              << " replay_seconds=" << replay_seconds',
        '              << " replay_seconds=" << replay_seconds\n              << " binding_seconds=" << hyle_d1_replay_bindings_seconds()')
    source=OUT/'main-diagnostic.cc';source.write_text(main,encoding='utf-8',newline='\n')
    product=m.ROOT/'src/graph/executable.cc'
    receipt=c.read(m.A/'layout-binding-lifetime/checks/graph-executable-identity.json')
    assert h.h.same_identity(receipt['source'])
    executable=product.read_text(encoding='utf-8')
    executable=m.replace_once(executable,'#include <algorithm>','#include <algorithm>\n#include <chrono>')
    executable=m.replace_once(executable,'namespace hyle::graph {',
        'namespace { thread_local double d1_replay_bindings = 0; }\n'
        'extern "C" double hyle_d1_replay_bindings_seconds() noexcept { return d1_replay_bindings; }\n\n'
        'namespace hyle::graph {')
    executable=m.replace_once(executable,'  Status bindings = prepare_invocation_bindings(*state_);',
        '  const auto d1_binding_start = std::chrono::steady_clock::now();\n'
        '  Status bindings = prepare_invocation_bindings(*state_);\n'
        '  d1_replay_bindings = std::chrono::duration<double>(std::chrono::steady_clock::now() - d1_binding_start).count();')
    exesource=OUT/'executable-diagnostic.cc';exesource.write_text(executable,encoding='utf-8',newline='\n')
    env,runtime=h.environment(checks,m.BASE)
    jobs=[('main',source,m.MAIN['command'],m.BASE['main']),('executable',exesource,receipt['command'],receipt['object'])]
    replacements={};new=[]
    for tag,path,recipe,old in jobs:
        command=b.host_command(recipe,path,tag,checks)
        if tag=='executable':command.insert(1,'/I'+str(product.parent))
        c.execute(tag+'-compile',command,env,checks)
        obj=b.identity(checks/(tag+'.obj'));replacements[c.key(old['path'])]=obj
        c.save(checks/(tag+'-identity.json'),dict(source=b.identity(path),original_source=b.identity(m.ROOT/'tools/qwen35_text/main.cc' if tag=='main' else product),object=obj,command=command))
        new.append(obj)
    image=checks/'qwen.exe'
    link=[replacements[c.key(arg)]['path'] if c.key(arg) in replacements else arg for arg in m.BASE['command']
          if not arg.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:'))]
    link+=['/OUT:'+str(image),'/MAP:'+str(image.with_suffix('.map')),'/IMPLIB:'+str(image.with_suffix('.lib'))]
    reused=[row for row in m.BASE['inputs'] if c.key(row['path']) not in replacements]
    assert all(h.h.same_identity(row) for row in reused)
    c.save(checks/'link-plan.json',dict(command=link,inputs=[*new,*reused],replacements=replacements,diagnostic=True,product_changes=0,scope='Same retained BF16 Qwen closure plus diagnostic main/executable only'))
    c.execute('link',link,env,checks);c.save(checks/'image.json',b.identity(image))

if __name__=='__main__':
    if sys.argv[1]=='build':build()
    else:
        assert sys.argv[1]=='run'
        m.S=OUT;m.run()
