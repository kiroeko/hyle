"""D1 attribution only: same retained product objects, instrument one consumer TU."""
from pathlib import Path
import hashlib
import importlib.util
import json
import re
import statistics
import sys
sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
A = S.parent
ROOT = A.parents[1]
spec = importlib.util.spec_from_file_location('d1_rebenchmark', A/'decode-current-rebenchmark/run.py')
h = importlib.util.module_from_spec(spec)
spec.loader.exec_module(h)
b,c = h.b,h.c
BASE_PATH = A/'decode-current-rebenchmark/build/link-plan.json'
BASE = c.read(BASE_PATH)
MAIN = c.read(A/'decode-stable-bind/checks/main-identity.json')

def replace_once(text, old, new):
    assert text.count(old) == 1, old
    return text.replace(old,new)

def build():
    out = S/'build'
    out.mkdir(exist_ok=False)
    (out/'tmp').mkdir()
    assert h.h.same_identity(MAIN['source'])
    text = (ROOT/'tools/qwen35_text/main.cc').read_text(encoding='utf-8')
    text = replace_once(text, '    double cold_batch_seconds = 0;',
        '    double cold_batch_seconds = 0;\n    double layout_seconds = 0, batch_seconds = 0, replay_seconds = 0;\n    double report_seconds = 0, wait_seconds = 0;')
    text = replace_once(text,
        '      check(g::batch::prepare(run, queues, layouts, {.host_workspace = planning_memory.ref()}));\n      check(run.prepare_replay(queues, {.mode = replay_mode, .host_wait = g::HostWaitPolicy::kAllow}));',
        '      const auto layout_end = Clock::now();\n'
        '      layout_seconds = std::chrono::duration<double>(layout_end - cold_start).count();\n'
        '      check(g::batch::prepare(run, queues, layouts, {.host_workspace = planning_memory.ref()}));\n'
        '      const auto batch_end = Clock::now();\n'
        '      batch_seconds = std::chrono::duration<double>(batch_end - layout_end).count();\n'
        '      check(run.prepare_replay(queues, {.mode = replay_mode, .host_wait = g::HostWaitPolicy::kAllow}));\n'
        '      const auto replay_end = Clock::now();\n'
        '      replay_seconds = std::chrono::duration<double>(replay_end - batch_end).count();')
    text = replace_once(text,
        '      cold_batch_seconds = std::chrono::duration<double>(Clock::now() - cold_start).count();',
        '      const auto cold_end = Clock::now();\n'
        '      cold_batch_seconds = std::chrono::duration<double>(cold_end - cold_start).count();\n'
        '      report_seconds = std::chrono::duration<double>(cold_end - replay_end).count();')
    text = replace_once(text, '      check(done.wait());',
        '      check(done.wait());\n      wait_seconds = std::chrono::duration<double>(Clock::now() - start).count() - submit_seconds;')
    text = replace_once(text, '    std::int32_t next = 0;',
        '    const auto read_start = Clock::now();\n    std::int32_t next = 0;')
    text = replace_once(text, '    const auto finished = Clock::now();',
        '    const auto finished = Clock::now();\n'
        '    std::cerr << "d1 " << name\n'
        '              << " input_seconds=" << std::chrono::duration<double>(cold_start - step_start).count()\n'
        '              << " layout_seconds=" << layout_seconds\n'
        '              << " batch_seconds=" << batch_seconds\n'
        '              << " replay_seconds=" << replay_seconds\n'
        '              << " report_seconds=" << report_seconds\n'
        '              << " wait_seconds=" << wait_seconds\n'
        '              << " read_seconds=" << std::chrono::duration<double>(finished - read_start).count() << \'\\n\';')
    source = S/'main-diagnostic.cc'
    source.write_text(text,encoding='utf-8',newline='\n')
    command = b.host_command(MAIN['command'],source,'main',out)
    env,runtime = h.environment(out,BASE)
    c.save(out/'source-freeze.json',dict(product_source=b.identity(ROOT/'tools/qwen35_text/main.cc'),diagnostic=b.identity(source),product_source_edited=False,SDK_rebuilt=False,limitation='Retained product object set; instrumentation only, not throughput evidence'))
    c.execute('main-compile',command,env,out)
    obj = b.identity(out/'main.obj')
    old_main = BASE['main']
    assert sum(c.key(arg)==c.key(old_main['path']) for arg in BASE['command'])==1
    link=[obj['path'] if c.key(arg)==c.key(old_main['path']) else arg for arg in BASE['command']
          if not arg.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:'))]
    image=out/'qwen.exe'
    link += ['/OUT:'+str(image),'/MAP:'+str(image.with_suffix('.map')),'/IMPLIB:'+str(image.with_suffix('.lib'))]
    reused=[row for row in BASE['inputs'] if c.key(row['path'])!=c.key(old_main['path'])]
    assert all(h.h.same_identity(row) for row in reused)
    c.save(out/'link-plan.json',dict(command=link,inputs=[obj,*reused],base=b.identity(BASE_PATH),replaced_main=old_main,source=b.identity(source),diagnostic=True,product_implementation_changes=0))
    c.execute('link',link,env,out)
    c.save(out/'image.json',b.identity(image))
    c.save(out/'compile.json',dict(command=command,source=b.identity(source),object=obj,runtime=runtime))

def run():
    out=S/'measurement'
    out.mkdir(exist_ok=False)
    env,runtime=h.environment(out,BASE)
    image=c.read(S/'build/image.json')
    original=c.read(A/'decode-current-rebenchmark/timing/02-current.command.json')['command']
    assert h.h.same_identity(image)
    results=[]
    for index in range(1,4):
        tag=f'{index:02}-diagnostic'
        command=[image['path'],*original[1:]]
        result=c.execute(tag,command,env,out)
        text=(out/(tag+'.stderr.log')).read_text(encoding='utf-8')
        rows=[]
        for name,payload in re.findall(r'^d1 (\w+) (.+)$',text,re.M):
            rows.append(dict(name=name,**{key:float(value) for key,value in re.findall(r'(\w+)=([0-9.e+-]+)',payload)}))
        assert len(rows)==32
        assert [x['name'] for x in rows]==['prefill',*[f'decode{i}' for i in range(1,32)]]
        capture=[[int(a),int(b)] for a,b in re.findall(r'capture_recorded=(\d+) capture_reused=(\d+)',text)]
        assert capture==[[1,0]]*3+[[0,1]]*29,capture
        old=(A/'decode-current-rebenchmark/timing/02-current.stderr.log').read_text(encoding='utf-8')
        assert re.findall(r' next=(\d+)',text)==re.findall(r' next=(\d+)',old)
        warm=rows[7:]
        medians={key:statistics.median(x[key] for x in warm) for key in warm[0] if key!='name'}
        results.append(dict(tag=tag,process=result,rows=rows,warm7_31_median_seconds=medians,capture_counts=capture,same_fixed_predictions=True))
        c.save(out/'runs.json',results)
        print('BUCKETS_US',tag,{k:round(v*1e6,3) for k,v in medians.items()},flush=True)
    c.save(out/'summary.json',dict(status='three_diagnostic_processes_exit_zero',instrumented=True,not_throughput_comparison=True,image=image,product_source=b.identity(ROOT/'tools/qwen35_text/main.cc'),runs=results,runtime=runtime))

if __name__=='__main__':
    {'build':build,'run':run}[sys.argv[1]]()
