"""D1: two shared Graph owners, one changed CPU test, retained test closure."""
from pathlib import Path
import argparse
import importlib.util
import json
import sys
import xml.etree.ElementTree as ET

sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
A = S.parents[1]
ROOT = A.parents[1]
spec = importlib.util.spec_from_file_location(
    "d1_cpu_retained_helpers", A / "grouped-shared-activation/build_host.py")
h = importlib.util.module_from_spec(spec)
spec.loader.exec_module(h)
b, c = h.b, h.c
BASE = A / "layout-binding-lifetime/checks/link-plan.json"
RECIPES = A / "layout-binding-lifetime/checks"
OWNERS = [
    ("graph-executable", ROOT / "src/graph/executable.cc"),
    ("graph-resources", ROOT / "src/graph/resources.cc"),
    ("configuration_input_test", ROOT / "tests/graph/configuration_input_test.cc"),
]
FILTER = ":".join([
    "TypedCapabilityGraph.*", "ConfigurationInput.*", "InputSourceFrontier.*",
    "GraphResources.FixedBindingIndexKeepsRebindGenerationAndResultLeaseGuards",
    "GraphRegions.OwnedNativeInputsKeepFirstCoveringPermissionAcrossRetryAndRebind",
    "GraphRegions.ExclusiveDeferredInputDoesNotCaptureItsUpgradeableReader",
    "GraphRegions.UnknownCaptureIdentityRepreparesAfterSameTupleBindingEpisode",
    "GraphRegions.FailedSelectedConfigurationInvalidatesBeforeItsCallback",
    "Invocation.DynamicAliasGroupsTrackRangeChangesFailedBindsAndReset",
])


def require_same(row):
    assert h.same_identity(row), row["path"]


def proposal():
    base = c.read(BASE)
    rows = []
    for tag, source in OWNERS:
        recipe = RECIPES / (tag + "-identity.json")
        original = c.read(recipe)
        assert any(c.key(x["path"]) == c.key(original["object"]["path"])
                   for x in base["inputs"])
        rows.append(dict(tag=tag, source_path=str(source), recipe=b.identity(recipe),
                         old_object=original["object"],
                         command=b.host_command(original["command"], source, tag, S),
                         object_path=str(S / (tag + ".obj"))))
    return dict(base=b.identity(BASE), compile=rows,
                product_CXX=2, test_CXX=1, links=1, GPU=False, SDK=False,
                new_cpu_image=str(S / "cpu.exe"), filter=FILTER,
                retained_inputs=len(base["inputs"]),
                scope="Private free-function declarations and resources.cc opaque state only; no InvocationState/PlanState/ResourceEpisodeOwner layout change")


def build(ready):
    assert ready and ready.is_file(), "Wait for the source owner's ready/freeze receipt"
    assert not (S / "link-plan.json").exists(), "Preserve this attempt; choose a revision directory before retrying"
    plan = proposal()
    frozen = [b.identity(source) for _, source in OWNERS]
    frozen.append(b.identity(ROOT / "src/graph/resource_episode.h"))
    plan.update(source_ready=b.identity(ready), frozen=frozen)
    c.save(S / "plan.json", plan)
    base = c.read(BASE)
    for row in base["inputs"]:
        require_same(row)
    c.save(S / "retained-input-recheck.json", dict(passed=True, count=len(base["inputs"]), inputs=base["inputs"]))
    env, runtime = b.environment(plan["compile"][0]["command"], [], S)
    c.save(S / "compile-environment.json", dict(runtime=runtime, PATH=env["PATH"]))
    records = []
    for row in plan["compile"]:
        for item in frozen:
            require_same(item)
        source = b.identity(row["source_path"])
        c.execute(row["tag"] + "-compile", row["command"], env, S)
        depfile = S / (row["tag"] + "-deps.json")
        data = c.read(depfile)["Data"]
        dependencies = [b.identity(Path(p).resolve())
                        for p in dict.fromkeys([data["Source"], *data["Includes"]])]
        record = dict(source=source, object=b.identity(row["object_path"]),
                      command=row["command"], source_dependencies=b.identity(depfile),
                      dependencies=dependencies, old_object=row["old_object"],
                      recipe=row["recipe"], source_ready=plan["source_ready"])
        require_same(source)
        c.save(S / (row["tag"] + "-identity.json"), record)
        records.append(record)
    c.save(S / "compile-summary.json", dict(passed=True, product_CXX=2, test_CXX=1, SDK=0, NVCC=0))
    swaps = {c.key(r["old_object"]["path"]): r["object"] for r in records}
    command = [swaps[c.key(arg)]["path"] if c.key(arg) in swaps else arg
               for arg in base["command"]
               if not arg.upper().startswith(("/OUT:", "/MAP:", "/IMPLIB:", "/PDB:"))]
    image = S / "cpu.exe"
    command += ["/OUT:" + str(image), "/MAP:" + str(image.with_suffix(".map")),
                "/IMPLIB:" + str(image.with_suffix(".lib"))]
    inputs = [swaps.get(c.key(row["path"]), row) for row in base["inputs"]]
    for row in inputs:
        require_same(row)
    link = dict(command=command, inputs=inputs, base=b.identity(BASE),
                replacements=[dict(before=r["old_object"], after=r["object"])
                              for r in records], source_ready=plan["source_ready"],
                scope=plan["scope"])
    c.save(S / "link-plan.json", link)
    env, runtime = b.environment(command, [x["path"] for x in inputs], S)
    c.save(S / "runtime-environment.json", dict(runtime=runtime, PATH=env["PATH"]))
    c.execute("link", command, env, S)
    c.save(S / "image.json", b.identity(image))
    for item in frozen:
        require_same(item)


def run():
    assert not (S / "tests.result.json").exists(), "Preserve the first run"
    link = c.read(S / "link-plan.json")
    image = c.read(S / "image.json")
    require_same(image)
    for row in link["inputs"]:
        require_same(row)
    env, _ = b.environment(link["command"], [x["path"] for x in link["inputs"]], S)
    command = [image["path"], "--gtest_filter=" + FILTER,
               "--gtest_output=xml:" + str(S / "results.xml")]
    process = c.execute("tests", command, env, S)
    tree = ET.parse(S / "results.xml")
    cases = tree.findall(".//testcase")
    failed = [x.attrib for x in cases if x.find("failure") is not None]
    skipped = [x.attrib for x in cases if x.find("skipped") is not None]
    assert len(cases) >= 18, len(cases)
    assert not failed and not skipped, (failed, skipped)
    c.save(S / "summary.json", dict(passed=True, cases=len(cases), failed=failed,
           skipped=skipped, names=[x.get("classname") + "." + x.get("name") for x in cases],
           process=process, source_ready=link["source_ready"],
           product_CXX=2, test_CXX=1, links=1, GPU=0, SDK=0, NVCC=0,
           image=image, link_plan=b.identity(S / "link-plan.json")))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mode", choices=["plan", "build", "run"])
    parser.add_argument("--ready", type=Path)
    args = parser.parse_args()
    S.mkdir(parents=True, exist_ok=True)
    (S / "tmp").mkdir(exist_ok=True)
    if args.mode == "plan":
        c.save(S / "proposed-plan.json", proposal())
        print("D1_CPU_PLAN_2_PRODUCT_1_TEST_1_LINK", flush=True)
    elif args.mode == "build":
        build(args.ready.resolve() if args.ready else None)
    else:
        run()
