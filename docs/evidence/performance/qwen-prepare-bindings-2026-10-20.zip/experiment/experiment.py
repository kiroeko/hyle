"""Uninstrumented BF16 comparisons; compile/link is completed before GPU windows."""
from pathlib import Path
import importlib.util
import json
import re
import statistics
import sys
import time
import xml.etree.ElementTree as ET
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('d1_experiment',S/'measure.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
b,c,h=m.b,m.c,m.h
BASELINE=c.read(m.A/'decode-current-rebenchmark/build/image.json')

def commands(long=False):
    hc=c.read(m.A/'decode-current-rebenchmark/timing/02-current.command.json')['command'].copy()
    pc=c.read(m.A/'decode-current-rebenchmark/timing/03-llama.command.json')['command'].copy()
    if long:
        hc[hc.index('--decode-ids')+1]=str(S/'long-peer/decode.ids')
        hc[hc.index('--steps')+1]='128'
        pc[0]=str(S/'long-peer/peer.exe')
        pc[2]=str(S/'long-peer/fixed-inputs.json')
    return hc,pc

def observation(out,tag,arm,long):
    if arm=='llama':
        result=c.read(out/(tag+'-peer-result.json'))
        phases=result['phases'];seconds=[x['step_seconds'] for x in phases]
        ids=result['predicted_ids'];tape=result['decode_input_ids'];captures=None
        cold=None
    else:
        text=(out/(tag+'.stderr.log')).read_text(encoding='utf-8')
        result=json.loads((out/(tag+'.stdout.log')).read_text().strip().splitlines()[-1])
        records=re.findall(r'^(prefill|decode\d+) tokens=(\d+) visible=(\d+).*?step_seconds=([0-9.e+-]+).*?next=(\d+)',text,re.M)
        seconds=[float(x[3]) for x in records]
        assert records[0][:3]==('prefill','128','128')
        assert [x[:3] for x in records[1:]]==[(f'decode{i}','1',str(128+i)) for i in range(1,len(records))]
        ids=result['generated_ids'];tape=result['decode_input_ids']
        assert ids==[int(x[4]) for x in records]
        captures=[[int(a),int(b)] for a,b in re.findall(r'capture_recorded=(\d+) capture_reused=(\d+)',text)]
        assert captures==[[1,0]]*3+[[0,1]]*(len(seconds)-3)
        cold=[float(x) for x in re.findall(r'cold_batch_seconds=([0-9.e+-]+)',text)]
    expected=127 if long else 31
    assert len(seconds)==len(ids)==expected+1
    fixed=c.read(S/'long-peer/fixed-inputs.json' if long else m.A/'qwen-gpu-comparison/128-prefill/fixed-inputs.json')
    assert tape==fixed['decode_input_ids']
    assert all(x>0 for x in seconds)
    metrics={'prefill_tokens_per_second':128/seconds[0],
        'full_decode_tokens_per_second':expected/sum(seconds[1:]),
        'warm7_end_tokens_per_second':(expected-6)/sum(seconds[7:])}
    return dict(metrics=metrics,phase_step_seconds=seconds,generated_ids=ids,
        decode_input_ids=tape,capture_counts=captures,cold_batch_seconds=cold)

def smoke_long():
    out=S/'long-smoke';out.mkdir(exist_ok=False)
    env,runtime=h.environment(out,m.BASE)
    hc,pc=commands(True)
    hc[0]=BASELINE['path'];pc[-1]=str(out/'llama-peer-result.json')
    results={}
    for arm,command in [('baseline',hc),('llama',pc)]:
        c.execute(arm,command,env,out)
        results[arm]=observation(out,arm,arm,True)
    ids0=results['baseline']['generated_ids'];ids1=results['llama']['generated_ids']
    c.save(out/'summary.json',dict(passed=True,processes=2,phases_each=128,visible_tokens=255,
        baseline_peer_prediction_differences=[i for i,(x,y) in enumerate(zip(ids0,ids1)) if x!=y],
        independent_quality_acceptance=False,not_throughput_comparison=True,results=results,runtime=runtime))
    print('LONG_SMOKE_COMPLETE',flush=True)

def link():
    out=S/'candidate';out.mkdir(exist_ok=False);(out/'tmp').mkdir()
    receipts=[c.read(S/'cpu-regression'/(tag+'-identity.json')) for tag in ['graph-executable','graph-resources']]
    replacement={c.key(x['old_object']['path']):x['object'] for x in receipts}
    assert all(h.h.same_identity(x['object']) and h.h.same_identity(x['source']) for x in receipts)
    image=out/'qwen.exe'
    command=[replacement[c.key(x)]['path'] if c.key(x) in replacement else x for x in m.BASE['command']
             if not x.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:'))]
    command+=['/OUT:'+str(image),'/MAP:'+str(image.with_suffix('.map')),'/IMPLIB:'+str(image.with_suffix('.lib'))]
    inputs=[replacement.get(c.key(x['path']),x) for x in m.BASE['inputs']]
    assert len(replacement)==2 and all(h.h.same_identity(x) for x in inputs)
    c.save(out/'link-plan.json',dict(command=command,inputs=inputs,replacements=receipts,base=b.identity(m.BASE_PATH),diagnostic=False,retained_main=m.BASE['main']))
    env,runtime=h.environment(out,m.BASE);c.execute('link',command,env,out)
    c.save(out/'image.json',b.identity(image))

def correctness():
    out=S/'correctness';out.mkdir(exist_ok=False)
    image=c.read(S/'candidate/image.json')
    env,runtime=h.environment(out,m.BASE)
    n=h.load('d1_vectors',m.A/'cuda-bf16-dual-projection/compare_numerics.py')
    ref=m.A/'batch-graph-capture/correctness-final'
    vectors={p.relative_to(ref/'trace'):n.identity(p) for p in sorted((ref/'trace').rglob('*')) if p.suffix in ('.bf16','.f32')}
    assert len(vectors)==64
    command=c.read(ref/'qwen.command.json')['command'].copy();command[0]=image['path']
    command[command.index('--trace')+1]=str(out/'trace')
    c.execute('qwen',command,env,out)
    obs=n.analyze_arm('current',image,out,vectors,n.final_json(ref/'qwen.stdout.log'))
    assert obs['equal_vectors']==64 and obs['all_outputs_finite'] and obs['same_greedy_ids_as_reference'] and obs['same_fixed_decode_inputs']
    assert [[x['recorded'],x['reused']] for x in obs['capture_counts']]==[[1,0]]*3+[[0,1]]*29
    c.save(out/'summary.json',dict(passed=True,equal_vectors=64,observation=obs,image=image,runtime=runtime,independent_quality_acceptance=False))
    print('SIXTY_FOUR_VECTORS_EQUAL',flush=True)

def cuda():
    out=S/'cuda-regression';out.mkdir(exist_ok=False);(out/'tmp').mkdir()
    path=m.A/'layout-binding-lifetime/cuda/link-plan.json';base=c.read(path)
    receipts=[c.read(S/'cpu-regression'/(tag+'-identity.json')) for tag in ['graph-executable','graph-resources']]
    swaps={c.key(x['old_object']['path']):x['object'] for x in receipts}
    image=out/'cuda.exe'
    command=[swaps[c.key(x)]['path'] if c.key(x) in swaps else x for x in base['command']
             if not x.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:'))]
    assert sum(c.key(x['path']) in swaps for x in base['inputs'])==2
    command+=['/OUT:'+str(image),'/MAP:'+str(image.with_suffix('.map')),'/IMPLIB:'+str(image.with_suffix('.lib'))]
    inputs=[swaps.get(c.key(x['path']),x) for x in base['inputs']]
    assert all(h.h.same_identity(x) for x in inputs)
    c.save(out/'link-plan.json',dict(command=command,inputs=inputs,replacements=receipts,base=b.identity(path),new_CXX=0))
    env,runtime=b.environment(command,[x['path'] for x in inputs],out)
    c.execute('link',command,env,out);c.save(out/'image.json',b.identity(image))
    guards=['GgmlCudaGraph.WholeOriginalRegionUsesIndependentInvocations','GgmlCudaGraph.SoftmaxRegionPublishesLogicalAxesAndRetainsOldResults']
    filters=':'.join(['GraphBatchCapture.*','BatchOutputTail.*',*guards])
    c.execute('tests',[str(image),'--gtest_filter='+filters,'--gtest_output=xml:'+str(out/'results.xml')],env,out)
    cases=ET.parse(out/'results.xml').findall('.//testcase')
    names=[x.get('classname')+'.'+x.get('name') for x in cases]
    assert len(cases)==6 and all(x in names for x in guards),names
    assert all(x.find('failure') is None and x.find('skipped') is None for x in cases)
    c.save(out/'summary.json',dict(passed=True,cases=6,skipped=0,names=names,runtime=runtime,new_CXX=0,shared_core_CXX=2))

def timing(long=False):
    out=S/('long-timing' if long else 'timing');out.mkdir(exist_ok=False)
    assert c.read(S/'correctness/summary.json')['passed']
    env,runtime=h.environment(out,m.BASE)
    hc,pc=commands(long)
    images={'baseline':BASELINE,'current':c.read(S/'candidate/image.json'),
            'llama':c.read(S/'long-peer/image.json') if long else h.PEER['images']['llama']}
    for row in images.values():assert h.h.same_identity(row)
    order=['baseline','current','llama','llama','baseline','current','current','llama','baseline']
    c.save(out/'inputs.json',dict(images=images,order=order,long=long,runtime=runtime,profiler=False,
        external_memory_monitor=False,compile_during_window=False,metric='complete host-token step',
        precision_limit='Same BF16 weights; Hyle mostly BF16 activation/output boundaries, peer many F32 intermediates; official peer returns additional sampled logits. Not identical operator mathematics or independent quality acceptance.',
        process_count=9,fresh_processes_per_arm=3,prompt_tokens=128,decode_tokens=127 if long else 31,
        context_capacity=256,repeated_original31_tape_for_long=long,
        source_scope='Retained BF16 Qwen closure, only two generic graph implementation objects replaced; not all subsequent format-capability owners rebuilt.'))
    start=time.time();runs=[]
    for i,arm in enumerate(order,1):
        tag=f'{i:02}-{arm}';command=(pc if arm=='llama' else hc).copy()
        command[0]=images[arm]['path']
        if arm=='llama':command[-1]=str(out/(tag+'-peer-result.json'))
        process=c.execute(tag,command,env,out)
        obs=observation(out,tag,arm,long)
        runs.append(dict(tag=tag,arm=arm,process=process,**obs));c.save(out/'runs.json',runs)
    groups={arm:{k:dict(samples=[x['metrics'][k] for x in runs if x['arm']==arm],median=statistics.median(x['metrics'][k] for x in runs if x['arm']==arm))
                 for k in runs[0]['metrics']} for arm in images}
    ids=next(x['generated_ids'] for x in runs if x['arm']=='baseline')
    hyle_same=all(x['generated_ids']==ids for x in runs if x['arm']!='llama')
    assert hyle_same
    c.save(out/'summary.json',dict(status='nine_uninstrumented_processes_exit_zero',started=start,finished=time.time(),
        groups=groups,current_over_baseline={k:groups['current'][k]['median']/groups['baseline'][k]['median'] for k in groups['current']},
        current_over_llama={k:groups['current'][k]['median']/groups['llama'][k]['median'] for k in groups['current']},
        current_matches_baseline_ids=hyle_same,peer_prediction_differences={x['tag']:[i for i,(a,e) in enumerate(zip(x['generated_ids'],ids)) if a!=e] for x in runs if x['arm']=='llama'},
        images=images,long=long,independent_quality_acceptance=False,statistical_significance=False))
    print('WINDOW_COMPLETE',out.name,groups,flush=True)

if __name__=='__main__':
    {'smoke-long':smoke_long,'link':link,'correctness':correctness,'cuda':cuda,'timing':timing,'long-timing':lambda:timing(True)}[sys.argv[1]]()
