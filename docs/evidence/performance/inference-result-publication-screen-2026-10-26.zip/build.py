"""Explicit root action: replace exactly one resources host TU in image41."""
from pathlib import Path
import importlib.util
import json
import os
import shutil
import sys

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = W.parents[1]
F = W / 'candidate'
B = R / '.scratch/inference-sampling-three-arm-20261026/batch'
C = R / '.scratch/inference-current-closure-20261026/unresolved-host/compile/graph--resources_cc'
spec = importlib.util.spec_from_file_location('host_build', R / '.scratch/inference-synchronous-step-report-20261025/check_host.py')
h = importlib.util.module_from_spec(spec)
spec.loader.exec_module(h)


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def pin(path):
    return h.pin(Path(path))


def exact(row):
    assert pin(row['path']) == row, row['path']


if sys.argv[1:] not in (['build'], ['link']):
    raise SystemExit('Usage: python -B .scratch/inference-result-publication-screen-20261026/build.py build|link')
resume = sys.argv[1:] == ['link']
if resume:
    assert read(F / 'compile/process.json')['exit'] == 0 and not (F / 'link').exists()
else:
    assert not F.exists(), 'Preserve prior attempts; do not overwrite a failed build'
source = R / 'src/graph/resources.cc'
original_dependencies = read(C / 'actual-project-dependencies.json')
for row in original_dependencies:
    if Path(row['path']) != source:
        exact(row)
baseline = read(B / 'ready.json')
for field in ('image', 'link_inputs', 'runtime'):
    exact(baseline[field])
inputs = read(baseline['link_inputs']['path'])
old_object = str(C / 'unit.obj')
assert sum(row['path'] == old_object for row in inputs) == 1
for row in inputs:
    exact(row)
snapshot = F / 'source/resources.cc'
if not resume:
    (F / 'source').mkdir(parents=True)
    shutil.copyfile(source, snapshot)
    h.save(F / 'source-pins.json', dict(original=original_dependencies[0], candidate=pin(snapshot),
        canonical_at_build=pin(source), policy='First successful result retains original publication point; repeated scan candidate only'))
else:
    exact(read(F / 'source-pins.json')['candidate'])
    exact(read(F / 'source-pins.json')['canonical_at_build'])
recipe = read(C / 'command.json')['command']
compile_command = []
for arg in recipe:
    if arg == str(source):
        arg = str(snapshot)
    elif arg == str(C / 'dependencies.json'):
        arg = str(F / 'compile/dependencies.json')
    elif arg.startswith('/Fo'):
        arg = '/Fo' + str(F / 'compile/unit.obj')
    compile_command.append(arg)
compiler = compile_command[0]
env = h.discover_environment(compiler='msvc', cache={
    'CMAKE_C_COMPILER': compiler, 'CMAKE_CXX_COMPILER': compiler, 'CMAKE_GENERATOR': 'Ninja'}, backends=()).env
compiled = read(F / 'compile/process.json') if resume else h.execute(compile_command, env, F / 'compile', timeout=120)
dependency = read(F / 'compile/dependencies.json')['Data']
actual = [pin(path) for path in dict.fromkeys([dependency['Source'], *dependency['Includes']])]
h.save(F / 'compile/actual-dependencies.json', actual)
old_project = {os.path.normcase(row['path']): row for row in original_dependencies[1:]}
new_files = {os.path.normcase(row['path']): row for row in actual}
assert set(old_project) <= set(new_files)
assert all((new_files[path]['bytes'], new_files[path]['sha256']) == (row['bytes'], row['sha256'])
           for path, row in old_project.items())
h.save(F / 'compile/dependency-check.json', dict(status='PASS', project_headers_unchanged=True,
    path_identity='Windows normcase; compiler returned lowercase paths',
    resumed_after='Initial script compared case-sensitive paths and stopped after successful compilation; no compile retry or model run' if resume else None))
obj = pin(F / 'compile/unit.obj')
new_inputs = [obj if row['path'] == old_object else row for row in inputs]
link = []
for arg in read(B / 'link/process/command.json')['command']:
    if arg == old_object:
        arg = obj['path']
    elif arg.upper().startswith('/OUT:'):
        arg = '/OUT:' + str(F / 'link/hyle.exe')
    elif arg.upper().startswith('/PDB:'):
        arg = '/PDB:' + str(F / 'link/hyle.pdb')
    elif arg.upper().startswith('/IMPLIB:'):
        arg = '/IMPLIB:' + str(F / 'link/hyle.lib')
    link.append(arg)
linked = h.execute(link, env, F / 'link', timeout=120)
h.save(F / 'link-inputs.json', new_inputs)
runtime = read(baseline['runtime']['path'])
exact(runtime['native'])
native = F / 'link' / Path(runtime['native']['path']).name
os.link(runtime['native']['path'], native)
runtime['native_hardlink'] = pin(native)
h.save(F / 'runtime.json', runtime)
h.save(F / 'ready.json', dict(status='CANDIDATE_BUILT_NOT_RUN', image=pin(F / 'link/hyle.exe'),
    app=obj, source=pin(snapshot), source_pins=pin(F / 'source-pins.json'),
    actual_dependencies=pin(F / 'compile/actual-dependencies.json'),
    runtime=pin(F / 'runtime.json'), link_inputs=pin(F / 'link-inputs.json'),
    compile=compiled, link=linked, baseline_ready=pin(B / 'ready.json'),
    replaced=next(row for row in inputs if row['path'] == old_object),
    unchanged_absolute_inputs=len(inputs)-1, new_host_TUs=1, SDK_or_device_builds=0, model_runs=0))
print(json.dumps(dict(ready=str(F / 'ready.json'), image=pin(F / 'link/hyle.exe')), indent=2))
