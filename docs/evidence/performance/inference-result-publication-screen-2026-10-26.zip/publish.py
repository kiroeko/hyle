"""Publish the completed eight-process screen and five contract checks."""
from pathlib import Path
import hashlib
import json
import subprocess
import zipfile

W = Path(__file__).resolve().parent
R = W.parents[1]
I = R / '.scratch/inference-b2-result-publication-20261026'
DEST = R / 'docs/evidence/performance'
NAME = 'inference-result-publication-screen-2026-10-26'


def read(p):
    return json.loads(Path(p).read_text(encoding='utf-8-sig'))


def sha(p):
    with Path(p).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


result = read(W / 'summary.json')
tests = read(W / 'cpu-contract1/summary.json')
review = read(W / 'independent-result-review.json')
assert result['status'] == 'COMPLETE_8_FULL_NON_TIME_AND_198IDS_EQUAL'
assert tests['status'] == 'PASS_5_CPU_CONTRACT_TESTS'
assert result['process_count'] == 8 and result['complete_nontime_differences'] == result['ID_differences'] == 0
assert all(x['process']['exit'] == 0 for x in result['runs'])
archive_path = DEST / (NAME + '.zip')
report_path = DEST / (NAME + '.json')
assert not archive_path.exists() and not report_path.exists()
files = [(p.relative_to(W).as_posix(), p) for p in W.rglob('*')
         if p.is_file() and p.suffix in {'.json', '.log', '.py', '.cc', '.xml'}
         and p.name not in {'archive-receipt.json', 'archive-manifest.json'}]
files += [('implementation/' + p.relative_to(I).as_posix(), p)
          for p in I.rglob('*') if p.is_file() and p.suffix in {'.json', '.cc', '.patch'}]
manifest = [dict(member=name, bytes=p.stat().st_size, sha256=sha(p)) for name, p in sorted(files)]
with zipfile.ZipFile(archive_path, 'w', zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
    for name, path in sorted(files):
        archive.write(path, name)
    archive.writestr('archive-manifest.json', json.dumps(manifest, indent=2) + '\n')
with zipfile.ZipFile(archive_path) as archive:
    assert archive.testzip() is None and len(archive.namelist()) == len(manifest) + 1
    for row in manifest:
        raw = archive.read(row['member'])
        assert len(raw) == row['bytes'] and hashlib.sha256(raw).hexdigest() == row['sha256']

memory = {}
for arm, facts in result['memory'].items():
    memory[arm] = {k: facts[k] for k in ('sample_count', 'sampled_peaks', 'null_sample_counts',
                  'ready_baseline', 'actual_sample_gaps_ms', 'setup_error', 'thread_error')}
report = dict(
    schema='hyle.performance.evidence.v1', date='2026-10-26',
    status='ADOPTED_REDUNDANT_PUBLICATION_SCAN_ELIMINATION_NO_STABLE_THROUGHPUT_GAIN',
    source_git_before_commit=subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=R, text=True).strip(),
    change='ResourceEpisode records successful lazy writer publication. First valid result still publishes the original complete caller-writer prefix; later results skip only this already completed scan. Writer bind, new submission before upgrades, reset and unbind rearm it. Failure retains the original retry behavior.',
    complexity='Only the writer-publication scan changes from O(S*B) to O(B+S) per unchanged completed resource episode. Other result/export/range lookup work is unchanged; this is not an overall inference complexity claim.',
    decision='Keep this local elimination of deterministic redundant work. Do not count it as a stable tokens/s improvement or the main B2 bottleneck; do not refill samples or expand this candidate.',
    build=dict(new_product_TUs=1, new_test_TUs=1, SDK_or_device_builds=0,
               candidate_image=read(W / 'candidate/ready.json')['image'],
               control_image=read(R / '.scratch/inference-sampling-three-arm-20261026/batch/ready.json')['image'],
               link_delta=read(W / 'plan.json')['actual_link_delta'],
               tool_failure='Product compile succeeded, then the initial dependency checker compared Windows paths case-sensitively and stopped before link. Explicit link-only resume used normcase after confirming all original header hashes; no compile retry or model run was added.'),
    validation=dict(cpu_contract_tests=tests, independent_source_review=read(I / 'independent-review-architecture.json')['status'],
                    full_non_time_differences=0, output_ID_differences=0,
                    process_count=8, unmonitored_timing=6, independent_memory=2,
                    workload='Ordinary greedy CUDA B2 teacher-forced, C1024 N2/R2 prefix off; three P256+32 turns/request; 99 physical episodes, 1728 input rows, 198 decisions; no MTP.',
                    extra_warmup_or_behavior_runs=0, old_samples_pooled=False),
    metrics=result['metrics'], comparisons=result['comparisons'], memory=memory,
    independent_result_review=review,
    limits=[
        'All new prefill/decode/combined sample ranges overlap. Decode median +0.158% and combined +0.694% are not stable gains or statistical significance.',
        'One independent memory run per arm; sampled peaks are lower bounds and tiny differences do not establish savings. Missing observations remain missing.',
        'This screen compares two Hyle images. It does not refresh the llama.cpp reference or ordinary/MTP formal table; do not pool earlier peer samples.',
        'No MTP, Apple/Vulkan, other-model or full Graph suite runtime claim. Shared lazy-publication semantics were checked by the five finite CPU cases and this ordinary CUDA consumer.',
        'No attribution of the entire 32.908ms postwait phase or B2 wall gap to the eliminated scan. No new profiler was used.'
    ],
    archive=dict(path=archive_path.name, bytes=archive_path.stat().st_size, sha256=sha(archive_path),
                 members=len(manifest)+1, verification='ZIP CRC and every member byte length/SHA256 verified'))
report_path.write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n', encoding='utf8')
(W / 'archive-receipt.json').write_text(json.dumps(report['archive'], indent=2) + '\n', encoding='utf8')
print(json.dumps(dict(report=str(report_path), archive=report['archive']), indent=2))
