from pathlib import Path
from collections import Counter
import hashlib, json
S=Path(__file__).resolve().parent; R=S.parents[1]
B=R/'.scratch/mtp-performance-convergence-20261025/baseline'
C=R/'.scratch/mtp-capture-miss-20261025'
def read(p): return json.loads(p.read_text(encoding='utf-8-sig'))
def pin(p): return dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def raw(p): return json.loads(next(l for l in p.read_text().splitlines()if l.startswith('{')))
def compare(a,b,path='',diff=None,excluded=None):
    if diff is None: diff=[]
    if excluded is None: excluded=[]
    if type(a)!=type(b): diff.append(dict(path=path,actual=a,expected=b))
    elif isinstance(a,dict):
        for k in sorted(a.keys()|b.keys()):
            if k=='seconds' or k.endswith('_seconds') or 'tokens_per_second' in k: excluded.append(path+'/'+k); continue
            if k not in a or k not in b: diff.append(dict(path=path+'/'+k,missing=True)); continue
            compare(a[k],b[k],path+'/'+k,diff,excluded)
    elif isinstance(a,list):
        if len(a)!=len(b): diff.append(dict(path=path,lengths=[len(a),len(b)]))
        else:
            for i,(x,y)in enumerate(zip(a,b)): compare(x,y,path+'/'+str(i),diff,excluded)
    elif a!=b: diff.append(dict(path=path,actual=a,expected=b))
    return diff,excluded
actual=raw(S/'run1/stdout.log'); baseline=raw(B/'two-turn-timing/02-hyle_mtp/stdout.log')
diff,excluded=compare(actual,baseline)
assert not diff
rows=[json.loads(l[8:])for l in(S/'run1/stderr.log').read_text().splitlines()if l.startswith('CAPDIAG ')]
meta=next(r for r in rows if r['type']=='meta'); slots=[r for r in rows if r['type']=='slot']
assert not any(meta[k]for k in('event_overflow','difference_overflow','slot_overflow','concurrent_skips'))
assert read(S/'run1/process.json')['exit']==0
totals=Counter()
for slot in slots: totals.update(slot['totals'])
reference=read(C/'summary2.json'); ref=Counter()
for slot in reference['slot_aggregates']: ref.update(slot['totals'])
assert totals['range']==ref['range']==132
assert totals['recorded']==39 and ref['recorded']==32
assert totals['retained_hit']+totals['variant_hit']==93
canonical=R/'engine/models/qwen35/main.cc'
assert pin(canonical)['sha256']=='9b73fe9afe325d139072a94632e26d739e2b3cb48b411320c0c5bed320e9b9e9'
(S/'before-main.cc').write_bytes(canonical.read_bytes())
result=dict(status='rejected_without_product_change',candidate=read(S/'plan.json'),build=read(S/'compile/process.json'),link=read(S/'link/process.json'),process=read(S/'run1/process.json'),
    comparison=dict(reference=pin(B/'two-turn-timing/02-hyle_mtp/stdout.log'),actual=pin(S/'run1/stdout.log'),non_time_all_fields_equal=True,differences=diff,excluded_timing_paths=excluded),
    original_diagnostic='docs/evidence/performance/mtp-capture-binding-diagnostics-2026-10-25.json',
    diagnostic=dict(meta=meta,slot_aggregates=slots,totals=dict(totals),original_totals=dict(ref)),
    work={k:actual[k]for k in('generated_tokens','actual_graph_calls','prefill_target_rows','verified_target_rows','actual_target_rows','actual_draft_rows','draft_rounds','consumed_drafts')},
    conclusion='Reverse allocation order does not solve the observed binding churn. Records increase32->39 and reuse decreases100->93 at the same132decisions. Reject this candidate without clean TPS repeats or canonical edits.',
    limits=['One instrumented process; it diagnoses actual capture decisions, not performance or memory.', 'Exact non-time report equality does not certify all hidden tensor values.', 'Does not generalize to all workloads, allocation strategies, or paired-bank designs.'],
    SDK_builds=0,HTTP=0,canonical_product_changes=0,GPU_released=True,
    files=[pin(p)for p in sorted(S.rglob('*'))if p.is_file()and p.suffix.lower()not in('.obj','.exe','.dll','.exp','.lib','.pdb')])
(S/'summary.json').write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n',encoding='utf8')
print(json.dumps(dict(non_time_equal=True,decisions=132,recorded=39,reused=93,rejected=True)))
