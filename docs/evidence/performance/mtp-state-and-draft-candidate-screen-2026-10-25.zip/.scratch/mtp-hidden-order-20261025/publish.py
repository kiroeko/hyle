from pathlib import Path
import hashlib, json, zipfile
S=Path(__file__).resolve().parent; R=S.parents[1]
K=R/'.scratch/mtp-performance-convergence-20261025/k2-exploration'
M=R/'.scratch/mtp-metadata-convergence-20261025'
A=R/'.scratch/mtp-hidden-carry-20261025'
P=R/'docs/evidence/performance/mtp-state-and-draft-candidate-screen-2026-10-25.json'
Z=P.with_suffix('.zip')
def read(p): return json.loads(p.read_text(encoding='utf-8-sig'))
def pin(p): return dict(path=p.relative_to(R).as_posix(),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
assert not P.exists() and not Z.exists()
files=[]
for folder in (S,K):
    for p in sorted(folder.rglob('*')):
        if p.is_file()and p.suffix.lower()not in('.obj','.exe','.dll','.exp','.lib','.pdb','.map','.zip'):
            files.append(p)
files += [M/'final.md',M/'final.json',A/'review.md']
assert len(set(files))==len(files)
with zipfile.ZipFile(Z,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9)as z:
    for p in files: z.write(p,p.relative_to(R).as_posix())
hidden=read(S/'summary.json'); metadata=read(M/'final.json'); k2=read(K/'exploration-summary.json')
exact=[S/'compile/unit.obj',*[S/'link'/name for name in('hyle.exe','hyle.exp','hyle.lib','hyle_ggml_cpu_gdn_scale_v3.dll')]]
cleanup=[pin(p)for p in exact]
result=dict(status='bounded_candidates_closed_without_product_change',date='2026-10-25',
    scope='Current CUDA BF16 N1/R1 real-two-turn investigation. This is not a formal performance window, global functionality audit, or proof that other optimizations are impossible.',
    baseline='docs/evidence/performance/mtp-current-single-and-multiturn-2026-10-25.json',
    capture_diagnostic='docs/evidence/performance/mtp-capture-binding-diagnostics-2026-10-25.json',
    canonical=pin(R/'engine/models/qwen35/main.cc'),
    metadata=dict(status=metadata['state'],requested_bytes=22560,reason='Target metadata source is already shared; tiny one-time follower preallocation does not justify new lazy allocation states or altered admission/failure timing.',details=pin(M/'final.json')),
    paired_hidden=dict(status='closed_this_round_by_source_and_lifecycle_review',reason='Existing aliases suffice, but independent per-request parents, single-row initialization/fragmentation, recursive draft and diagnostic lifetime require a broader layout change. Full multi-K parents violate current retained-row budget. No measured benefit justifies it.',details=pin(A/'review.md')),
    hidden_order=hidden,
    independent_hidden_order_review=dict(mode='read_only raw reparse and full source comparison',non_time_leaves_equal=4452,excluded_timing_paths=33,scope='Same input/work/report; not a hidden-tensor numerical comparison or throughput result.'),
    K2=k2,
    limits=['K2 has exactly one clean model process and keeps all original timing/reporting; peer baseline is K1, not an equivalent K2 peer.',
            'Reverse-order has exactly one instrumented model process and one app-TU compile/relink; records are not tokens/s.',
            'Same K2 output IDs do not prove general quality or cross-batch bitwise equivalence.',
            'Metadata and paired-bank closures are source/trace-derived reviews; no new memory benchmark or native topology certificate.',
            'Dependency/binary pins are identities, not bundled SDKs. Source/patch/commands/raw reports are archived; use existing public baseline and capture archives for original comparison payloads.'],
    next='Inspect at most one unscreened exact BF16 body projection route; retain K1 default and original canonical allocation order.',
    archive=pin(Z),payloads=[pin(p)for p in files],
    cleanup=dict(performed=False,files=cleanup,logical_bytes=sum(p['bytes']for p in cleanup),scope='Only rejected private app object and linked artifacts; original clean baseline, shared caches and source/commands/results are retained.',note='Logical file lengths; DLL is a hardlink, not an assertion of physical freed bytes.'),
    new_product_changes=0,new_SDK_builds=0,new_HTTP=0,model_processes_in_this_candidate_batch=2,GPU_released=True)
P.write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n',encoding='utf8')
print(json.dumps(dict(public=pin(P),archive=pin(Z),cleanup_logical_bytes=result['cleanup']['logical_bytes'])))
