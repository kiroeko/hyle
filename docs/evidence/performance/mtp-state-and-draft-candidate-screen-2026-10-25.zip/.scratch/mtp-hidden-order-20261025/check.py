from pathlib import Path
import difflib, hashlib, importlib.util, json, os, sys
sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
R = S.parents[1]
B = R/'.scratch/mtp-performance-convergence-20261025/baseline'
C = R/'.scratch/mtp-capture-miss-20261025'
spec = importlib.util.spec_from_file_location('retained', R/'.scratch/mtp-extraction-regression-20261024/check.py')
b = importlib.util.module_from_spec(spec); spec.loader.exec_module(b)

def args(path):
    value = b.read(path)
    return value['command'] if isinstance(value, dict) else value

def build():
    canonical = R/'engine/models/qwen35/main.cc'
    assert b.pin(canonical)['sha256'] == '9b73fe9afe325d139072a94632e26d739e2b3cb48b411320c0c5bed320e9b9e9'
    original = canonical.read_text(encoding='utf8')
    before = '''      if (verifies_prefix(role) || has_mtp(role) || sampler.enabled) for (const auto &ports : phase.carry_ports)
        for (std::size_t i = 0; i < phase.prefix_rows; ++i)
          if (const auto &output = phase.child->output(ports[i]); output.caller_owned())'''
    after = '''      if (verifies_prefix(role) || has_mtp(role) || sampler.enabled) for (const auto &ports : phase.carry_ports)
        for (auto row = phase.prefix_rows; row != 0; --row)
          if (const auto &output = phase.child->output(ports[row - 1]); output.caller_owned())'''
    assert original.count(before) == 1
    private = original.replace(before, after)
    (S/'overlay').mkdir(exist_ok=False)
    (S/'overlay/main.cc').write_text(private, encoding='utf8', newline='\n')
    (S/'probe.cc').write_text('#include "'+str(S/'overlay/main.cc').replace('\\','/')+'"\nint main(int argc,char**argv){return qwen35::run(argc,argv);}\n', encoding='utf8')
    (S/'source.patch').write_text(''.join(difflib.unified_diff(original.splitlines(True), private.splitlines(True), fromfile='canonical/engine/models/qwen35/main.cc', tofile='private/overlay/main.cc')), encoding='utf8')
    b.save(S/'plan.json',dict(candidate='Only allocate hidden carry output rows in descending prefix order, matching existing GDN allocation order.', changes_math=False, changes_budget=False, changes_lease_or_permission=False, changes_graph=False, changes_allocation_order=True, canonical=b.pin(canonical), overlay=b.pin(S/'overlay/main.cc'), diagnostic_graph=b.pin(C/'compile2/unit.obj'), actual_single_process=True, purpose='Observe actual tuple cycles and original record/reuse counters; no TPS or memory inference.'))
    old=args(B/'compile/command.json'); flags=[]; skip=False
    for value in old[1:]:
        if skip: skip=False; continue
        if value == '/sourceDependencies': skip=True; continue
        if value.lower().startswith(('/fo','/fd')) or value.lower().endswith(('.cc','.cpp')): continue
        flags.append(value)
    folder=S/'compile'; env=b.environment(old[0])
    b.execute([old[0],*flags,str(S/'probe.cc'),'/sourceDependencies',str(folder/'dependencies.json'),'/Fo'+str(folder/'unit.obj')],folder,env,180)
    includes=[Path(p)for p in b.read(folder/'dependencies.json')['Data']['Includes']]
    assert (S/'overlay/main.cc') in includes and canonical not in includes
    b.save(folder/'source-pins.json',[b.pin(p)for p in includes if p.is_relative_to(R)])
    link=args(B/'link/command.json'); app=str(B/'compile/unit.obj'); graph=str(B.parent/'current-cuda/product-0/unit.obj')
    assert link.count(app)==1 and link.count(graph)==1
    link=[str(folder/'unit.obj')if value==app else str(C/'compile2/unit.obj')if value==graph else value for value in link if not value.upper().startswith(('/OUT:','/PDB:','/MAP:','/IMPLIB:'))]
    link+=['/OUT:'+str(S/'link/hyle.exe')]
    b.execute(link,S/'link',env,120)
    native=B/'link/hyle_ggml_cpu_gdn_scale_v3.dll'; os.link(native,S/'link'/native.name)
    b.save(S/'ready.json',dict(image=b.pin(S/'link/hyle.exe'),canonical=b.pin(canonical),overlay=b.pin(S/'overlay/main.cc'),SDK_builds=0,HTTP=0))

def run():
    cmd=args(B/'two-turn-timing/02-hyle_mtp/command.json')[:]
    assert b.pin(Path(cmd[0]))['sha256']=='c343db76232c4b5bd34878820433057b8c23789cd1b170b6a3b86cd91bf82fa1'
    cmd[0]=str(S/'link/hyle.exe')
    env=dict(os.environ,PATH=str(S/'link')+';'+b.read(B/'runtime.json')['PATH'],HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1')
    b.execute(cmd,S/'run1',env,120)

if __name__=='__main__':
    if sys.argv[1]=='build': build()
    elif sys.argv[1]=='run': run()
    else: raise ValueError(sys.argv[1])
