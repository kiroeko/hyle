#include "C:/public/project-hyle/hyle/.scratch/mtp-hidden-order-20261025/overlay/main.cc"
int main(int argc,char**argv){return qwen35::run(argc,argv);}
