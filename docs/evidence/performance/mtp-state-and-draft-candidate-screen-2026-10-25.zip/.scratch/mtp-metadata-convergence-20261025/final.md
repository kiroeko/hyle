# Metadata 候选：确认选中，关闭热点方向

本次只读当前源码和已归档实际trace；无编译、case、GPU、HTTP或产品修改。

- 原SQLite仅在内存反序列化＋query_only读取。ordinary原FlashInfer paged kernel768次，恰为6×128；MTP474次，恰为6×68 target图＋66 draft图。不是因模型调用g::batch::prepare就猜选中。
- 端点是Backend::compile→graph::batch::compile→CUDA roster的FlashInfer BatchPlanning→shared Region→BatchGraphAccess::create→BatchInvocation::create(external_output=true)。当前kNativeBatchRegionExtensionId实现只在Apple/Vulkan，无CUDA/ggml CUDA旁路；本窗是所审shared BatchInvocation路径。
- main::prepare_cache／session_state::make_plan：C1024、N1/R1、page16、max_page_refs64。batch_layout::geometry_offsets固定header32＋两个indptr各8＋page IDs256＋tail4，mirror精确308B。
- 每phase六target节点使用同一metadata port/layout/resource；batch.cc:470–482确实选择一个source＋五个follower，:538走prepare_shared，源ReadLease已共享。K1的一个draft节点另作source，不能强迫与target共享布局。
- batch_execution.cc:400–418仍为每follower准备自己的device池(512 padding＋308＝820B)、host池308B；后续借source时这些上传载荷未使用。五follower合计5640B/phase；两个decode role共11280B（约11KiB）；含两个prefill实际child的整个MTP旅程共20follower、22560B（约22KiB）。ordinary三个phase共16920B。
- 上述是源码确定的requested backing，不冒称driver实际粒度／全部私有元数据；没有逐分配时钟证明其延迟。这个一次性体量不足以支持把它当当前窗口主因继续投入，更不能解释warm decode。
- 不新增lazy-own-metadata分支。当前独立source随时可准备，预算及失败发生在原create阶段；保留这些性质，避免为小块存储增加shared→independent fallback、部分初始化／重试和新的失败时机。原独立float/int workspace、plan、capture及退休权限均保持。

结论：选中／体量已落实，metadata热点候选关闭，无悬空优化待办。当前性能推进转向root已有的真实capture miss；本检查没有速度收益声明。精确查询、来源pin与字节公式见final.json。
