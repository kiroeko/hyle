from pathlib import Path
import datetime
import hashlib
import json
import os
import subprocess
import time

D = Path(__file__).resolve().parent
R = D.parents[2]
B = D.parent / 'baseline'

def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))

def pin(path):
    path = Path(path).resolve()
    return dict(path=str(path), bytes=path.stat().st_size,
                sha256=hashlib.sha256(path.read_bytes()).hexdigest())

def require(receipt):
    assert pin(receipt['path']) == receipt, receipt['path']

def save(path, value):
    Path(path).write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8')

plan = read(B / 'two-turn-timing-plan.json')
original = next(row for row in plan['commands'] if row['arm'] == 'hyle_mtp')
for field in ('image', 'ready', 'environment'):
    require(original[field])
assert original['image']['sha256'] == 'c343db76232c4b5bd34878820433057b8c23789cd1b170b6a3b86cd91bf82fa1'
command = list(original['command'])
at = command.index('--mtp-max-drafts') + 1
assert command[at] == '1'
command[at] = '2'
assert [(i, old, new) for i, (old, new) in enumerate(zip(original['command'], command)) if old != new] == [(at, '1', '2')]
prepared = read(R / '.scratch/qwen-mtp-final-window-20261024/natural-inputs/prepared.json')
schedule_receipt = next(p['schedule'] for p in prepared['plans'] if p['output_quotas'] == [64, 64])
require(schedule_receipt)
require(prepared['prompt'])
assert schedule_receipt['path'] == command[command.index('--schedule') + 1]
inputs = Path(command[command.index('--inputs') + 1])
manifest = pin(inputs / 'weights.tsv')
assert manifest['sha256'] == 'bf81e4e411347a5d4253a01eb13665d55b6b3052922295292dd1e020857f86e1'
prompt = pin(inputs / 'prompt.ids')
assert prompt['sha256'] == 'b6a10feefb0af4687ee536285c9666bfbdf093fc9e484ab0461834345a5993a4'
runtime = read(original['environment']['path'])
require(runtime['native'])
# Original body identity and role-range mapping were already validated by the
# clean baseline. This exploration rechecks its immutable small receipts and
# underlying source size, without scanning/copying the 4.55GB model again.
source_body = Path('C:/Users/kiro/Downloads/Qwen3.5-2B/model.safetensors-00001-of-00001.safetensors')
assert source_body.stat().st_size == 4548221488
save(D / 'inputs.json', dict(image=original['image'], ready=original['ready'], runtime=original['environment'],
     native=runtime['native'], manifest=manifest, prompt=prompt, schedule=schedule_receipt,
     original_input_mapping=pin(D.parent / 'current-cuda/input-adaptation.json'),
     underlying_source=dict(path=str(source_body), bytes=source_body.stat().st_size,
                            full_hash_repeated=False), only_argv_change=dict(index=at, before='1', after='2')))
run = D / 'run1'
run.mkdir(exist_ok=False)
env = os.environ.copy()
env.update(PATH=runtime['PATH'], HF_HUB_OFFLINE='1', TRANSFORMERS_OFFLINE='1')
record = dict(command=command, cwd=str(R), image=original['image'],
              original_command=original['command'], profiler=False, instrumentation=False,
              single_strategy_exploration=True, formal_performance_window=False,
              peer_strategy='Retained peer baseline is K1; no same-K2 comparison claimed.',
              started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
              started_unix_ns=time.time_ns())
save(run / 'command.json', record)
begin = time.perf_counter()
with (run / 'stdout.log').open('wb') as out, (run / 'stderr.log').open('wb') as err:
    process = subprocess.Popen(command, cwd=R, env=env, stdout=out, stderr=err,
                               creationflags=subprocess.CREATE_NO_WINDOW)
    record['pid'] = process.pid
    save(run / 'live.json', record)
    try:
        record['exit'] = process.wait(timeout=120)
    except subprocess.TimeoutExpired:
        record['timeout'] = True
        process.kill()
        record['exit'] = process.wait()
record.update(process_wall_seconds=time.perf_counter() - begin,
              finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
              finished_unix_ns=time.time_ns())
save(run / 'process.json', record)
assert record['exit'] == 0 and not record.get('timeout'), 'Only run failed; preserve raw logs, do not retry.'
require(original['image'])
assert pin(inputs / 'weights.tsv') == manifest and pin(inputs / 'prompt.ids') == prompt
require(schedule_receipt)
raw = json.loads(next(line for line in reversed((run / 'stdout.log').read_text().splitlines()) if line.startswith('{')))
save(run / 'producer-result.json', raw)
assert len(raw['sessions']) == 1
flat = dict(raw)
for key, value in raw['sessions'][0]['result'].items():
    flat.setdefault(key, value)
assert flat['mtp_max_drafts'] == 2 and flat['sampling'] == 'greedy'
assert flat['text_tensors'] == 320 and flat['mtp_tensors'] == 15
assert flat['source_id'] == '4a76decdfa58a5fd6e15acea7ff410e84fd3e81cb6c39db8a658eeb23d869fbe'
assert flat['original_device_weight_bytes'] == 3885311680 and flat['original_host_weight_bytes'] == 0
assert flat['live_committed_versions'] == 0
save(run / 'normalized-result.json', flat)
save(D / 'summary.json', dict(state='complete', process=record,
     scope='Exactly one unchanged clean c343 actual two-turn greedy process, K1->K2 only. No clocks/profiler/hooks/SDK/downloads. Single strategy exploration, not a formal or same-K peer performance conclusion.',
     result=flat, raw_stdout=pin(run / 'stdout.log'), raw_stderr=pin(run / 'stderr.log'),
     preserved_ids=True, baseline_plan=pin(B / 'two-turn-timing-plan.json')))
print(json.dumps(dict(state='complete', folder=str(D), exit=record['exit'], keys=list(flat)), indent=2), flush=True)
