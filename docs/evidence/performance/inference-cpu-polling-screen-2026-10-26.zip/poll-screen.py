"""Fresh poll0/default CPU6timing+2memory only; prepare never runs models."""
from pathlib import Path
import ctypes,ctypes.wintypes as wt,importlib.util,json,os,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;R=W.parents[1];OUT=W/'poll-screen'
adapter=R/'.scratch/inference-cpu-representative-20261026/peer-avx2/screen.py'
spec=importlib.util.spec_from_file_location('retained_poll_cpu',adapter)
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
reference=m.read(W/'behavior1/stdout.log');detail=reference['sessions'][0]['result']
m.references=dict(hyle=reference,peer=dict(generated_ids=detail['generated_ids'],prompt_ids=detail['turns'][0]['input_ids']))
kernel=ctypes.WinDLL('kernel32',use_last_error=True)
get_times=kernel.GetProcessTimes
get_times.argtypes=[wt.HANDLE,*([ctypes.POINTER(wt.FILETIME)]*4)];get_times.restype=wt.BOOL
OriginalProcess=m.runner.subprocess.Popen
class ExitCpuTimes(OriginalProcess):
 def wait(self,timeout=None):
  code=super().wait(timeout)
  if not getattr(self,'cpu_times_taken',False):
   self.cpu_times_taken=True;created,exited,kt,ut=(wt.FILETIME() for _ in range(4))
   try:
    ok=bool(get_times(wt.HANDLE(int(self.p._handle)),ctypes.byref(created),ctypes.byref(exited),ctypes.byref(kt),ctypes.byref(ut)))
    def ticks(x):return (int(x.dwHighDateTime)<<32)|int(x.dwLowDateTime)
    value=dict(available=ok,pid=self.p.pid,after_process_wait=True,
     user_seconds=ticks(ut)/1e7 if ok else None,kernel_seconds=ticks(kt)/1e7 if ok else None,
     total_seconds=(ticks(ut)+ticks(kt))/1e7 if ok else None,
     created_FILETIME_100ns=ticks(created) if ok else None,exited_FILETIME_100ns=ticks(exited) if ok else None,
     error=None if ok else ctypes.get_last_error(),
     scope='GetProcessTimes while original Popen handle remains alive after wait;all process threads,startup,generation,teardown. Not decode-only CPU time,busy-thread count or energy.')
   except Exception as exc:value=dict(available=False,pid=self.p.pid,error=repr(exc),after_process_wait=True)
   m.save(m.current_folder/'process-cpu.json',value)
  return code
m.runner.subprocess.Popen=ExitCpuTimes
arms={'H':('build1','56303f189ee8b9833231c1e0b3166ff9d81908516c815fa7b5eadceb914acb62'),
      'C':('poll-default1','8ebb4d5d506ec0c468b97b175c90d8caf7990d1931959beef9bc6fb7c6d6baf3')}
metrics=('prefill_tokens_per_second','decode_output_tokens_per_second','output_tokens_per_second')
def summarize(rows):
 timing={a:[x for x in rows if x['mode']=='timing' and x['arm']==a] for a in arms}
 grouped={a:{k:m.stats([x['metrics'][k] for x in xs]) for k in metrics} for a,xs in timing.items()}
 compare={k:dict(median_tps_percent=(grouped['C'][k]['median']/grouped['H'][k]['median']-1)*100,
  ranges_overlap=max(grouped['C'][k]['min'],grouped['H'][k]['min'])<=min(grouped['C'][k]['max'],grouped['H'][k]['max']))
  for k in metrics if grouped['H'][k]['count'] and grouped['C'][k]['count']}
 return dict(status='COMPLETE' if len(rows)==8 else 'PARTIAL',processes=rows,timing=grouped,comparison=compare,
  timing_process_CPU={a:{k:m.stats([x['process_cpu'][k] for x in xs if x['process_cpu']['available']]) for k in ['user_seconds','kernel_seconds','total_seconds']} for a,xs in timing.items()},
  memory={x['arm']:dict(summary=m.read(Path(x['folder'])/'memory-summary.json'),threads=m.read(Path(x['folder'])/'threads.json')) for x in rows if x['mode']=='memory'},
  work_all_passed=all(x['work']['all_within_arm_non_time_fields_equal_initial_AVX2_pair'] for x in rows),
  work_reference='Shared563 behavior1 fullnon-time report;adapter field name retains historical initial_AVX2_pair spelling only.',
  order='H,C,C,H,H,C;then H,C independentmemory',H='Sharedpool poll0=563',C='Sharedpool defaultpoll50=8ebb',
  old_samples_pooled=False,peer_processes=0,warmups=0,retries=0,timeout_seconds=180,
  limits=['3short timing samples/arm;no CPUscaling or energy claim.','Original154/prefill,15/decode,16/session endpoints. Memory processes do not enter TPS stats.',
   'GetProcessTimes is after terminal process wait,wholeprocess CPU time,not decode-only time or energy. No monitoring added to timing processes.',
   'OSthread counts are not busy threads. PSAPI/PDH/thread sampled peaks are lower bounds;absentGPUinstances staynull.',
   'Only one cold poll assignment differs;native4,originalbudget/source/math/defaults unchanged. Native default50 spins a finite number of rounds,not forever.',
   'No peer run;source parity says peer creates default50 pool perwholegraph and frees it,not a cross-step persistent spin team.'])

def main():
 assert sys.argv[1:] in ([],['run'])
 plan={}
 original=list(m.read(m.W/'commands.json')['hyle']['command'])
 for a,(sub,sha) in arms.items():
  ready=m.read(W/sub/'ready.json');assert ready['image']['sha256']==sha and m.pin(ready['image']['path'])==ready['image']
  cmd=list(original);cmd[0]=ready['image']['path']
  plan[a]=dict(ready=m.pin(W/sub/'ready.json'),runtime=m.pin(W/sub/'runtime.json'),image=ready['image'],command=cmd)
 m.save(W/'poll-screen-plan.json',dict(status='PREPARED_NOT_RUN',arms=plan,script=m.pin(__file__),adapter=m.pin(adapter),
  timing_order='H,C,C,H,H,C',memory_order='H,C',old_samples_pooled=False,CPUtime='GetProcessTimes after wait only'))
 if not sys.argv[1:]:print('POLL_SCREEN_PREPARED_NOT_RUN',flush=True);return
 assert not OUT.exists(),'Refuse overwrite/repeat'
 OUT.mkdir();m.save(OUT/'plan.json',m.read(W/'poll-screen-plan.json'));rows=[]
 try:
  for index,(mode,a) in enumerate([('timing',a) for a in ['H','C','C','H','H','C']]+[('memory','H'),('memory','C')],1):
   folder=OUT/f'{index:02d}-{mode}-{a}';rt=m.read(plan[a]['runtime']['path']);env=os.environ.copy()
   env['PATH']=rt['PATH'];env.update(rt.get('configured_flags',{}));env.update(HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1')
   m.current_folder=folder;process=m.runner.execute(folder,'hyle',plan[a]['command'],env,mode=='memory')
   j=m.raw(folder,'hyle');work=m.check(j,'hyle');cpu=m.read(folder/'process-cpu.json')
   rows.append(dict(index=index,mode=mode,arm=a,folder=str(folder),process=process,process_cpu=cpu,work=work,
    metrics={k:j[k] for k in (*metrics,'prefill_seconds','decode_seconds','session_seconds','startup_to_ready_seconds','startup_to_endpoint_seconds')}))
   m.save(folder/'checks.json',work);m.save(OUT/'runs.json',rows);m.save(OUT/'summary.json',summarize(rows))
   print('POLL_TERMINAL',process['pid'],process['exit'],mode,a,'WORK_PASS',flush=True)
 except Exception as exc:m.save(OUT/'failure.json',dict(error=repr(exc),completed=len(rows),stopped_before_next_process=True));raise
 print('POLL_CPU_WINDOW_COMPLETE_RELEASED',flush=True)

if __name__=='__main__':main()
