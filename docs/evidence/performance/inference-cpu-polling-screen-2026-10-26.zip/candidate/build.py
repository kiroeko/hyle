"""One original default-poll runtime object; same tested CPU closure, no run action."""
from pathlib import Path
import importlib.util,json,os,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;B=W.parent;R=B.parents[1]
spec=importlib.util.spec_from_file_location('cpu_team_build',B/'check_build.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
read=b.read;pin=b.pin;save=b.save
old=read(B/'build1/runtime/command.json')['command'];command=[];skip=False
for a in old:
 if skip:skip=False;continue
 if a.lower()=='/sourcedependencies':skip=True;continue
 if a.lower().startswith(('/fo','/fd')) or a.lower().endswith(('.cc','.cpp')):continue
 command.append(a)
source=W/'source/src/compute_ggml_runtime/cpu_execution.cc';assert pin(source)['sha256']==read(W/'source-pins.json')['after']['sha256']
out=W/'compile';command += [str(source),'/sourceDependencies',str(out/'dependencies.json'),'/Fo'+str(out/'unit.obj'),'/Fd'+str(out/'unit.pdb')]
compiled=b.h.execute(command,b.env(command),out,timeout=120)
d=read(out/'dependencies.json')['Data'];deps=[pin(p) for p in dict.fromkeys([d['Source'],*d['Includes']])];save(out/'actual-dependencies.json',deps)
old=read(B/'build1/link/command.json')['command'];replacement=pin(out/'unit.obj');oldobject=pin(B/'build1/runtime/unit.obj');seen=0;command=[];out=W/'link';image=out/'hyle.exe'
for a in old:
 if a.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:')):continue
 if b.key(a)==b.key(oldobject['path']):seen+=1;a=replacement['path']
 command.append(a)
assert seen==1
inputs=[]
for p in read(B/'build1/link-inputs.json'):
 assert pin(p['path'])==p,p['path']
 inputs.append(replacement if b.key(p['path'])==b.key(oldobject['path']) else p)
save(W/'link-inputs.json',inputs)
command+=['/OUT:'+str(image),'/MAP:'+str(image.with_suffix('.map')),'/IMPLIB:'+str(image.with_suffix('.lib'))]
linked=b.h.execute(command,b.env(command),out,timeout=120)
runtime=read(B/'build1/runtime.json');native=Path(runtime['native']['path']);target=out/Path(runtime['native_hardlink']['path']).name;os.link(native,target);runtime['native_hardlink']=pin(target);save(W/'runtime.json',runtime)
ready=dict(status='BUILT_NOT_RUN',image=pin(image),compile=compiled,link=linked,source=pin(source),source_pins=pin(W/'source-pins.json'),command=pin(W/'compile/command.json'),actual_dependencies=pin(W/'compile/actual-dependencies.json'),link_inputs=pin(W/'link-inputs.json'),runtime=pin(W/'runtime.json'),original_ready=pin(B/'build1/ready.json'),replacement=dict(before=oldobject,after=replacement),all_other_link_inputs_unchanged=True,model_runs=0)
save(W/'ready.json',ready);print('READY',json.dumps(ready['image']),flush=True)
