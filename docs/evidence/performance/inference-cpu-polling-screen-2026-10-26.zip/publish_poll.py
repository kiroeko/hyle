"""Offline publication of the already completed bounded polling screen."""
from pathlib import Path
import datetime, hashlib, json, statistics, zipfile

W = Path(__file__).resolve().parent
R = W.parents[1]
S = W / 'poll-screen'
C = W / 'poll-default1'
PUBLIC = R / 'docs/evidence/performance/inference-cpu-polling-screen-2026-10-26.json'
ZIP = PUBLIC.with_suffix('.zip')

def read(p):
    return json.loads(Path(p).read_text(encoding='utf-8-sig'))

def pin(p):
    p = Path(p).resolve()
    b = p.read_bytes()
    return dict(path=str(p), bytes=len(b), sha256=hashlib.sha256(b).hexdigest())

def save(p, value):
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_bytes((json.dumps(value, indent=2, ensure_ascii=False, allow_nan=False) + '\n').encode())

def normalize(x):
    if isinstance(x, dict):
        return {k: normalize(v) for k, v in x.items()
                if k not in {'seconds', 'unix_ms', 'unix_ns', 'clock_unix'}
                and not k.endswith('_seconds') and not k.endswith('tokens_per_second')}
    return [normalize(v) for v in x] if isinstance(x, list) else x

def stats(xs):
    return dict(count=len(xs), median=statistics.median(xs), min=min(xs), max=max(xs), samples=xs)

def main():
    summary = read(S / 'summary.json')
    rows = read(S / 'runs.json')
    assert summary['status'] == 'COMPLETE' and len(rows) == 8
    assert [(x['mode'], x['arm']) for x in rows] == [
        ('timing', a) for a in 'HCCHHC'] + [('memory', 'H'), ('memory', 'C')]
    assert not summary['old_samples_pooled'] and summary['work_all_passed']
    assert summary['peer_processes'] == summary['warmups'] == summary['retries'] == 0
    assert not (S / 'failure.json').exists()
    reference = read(W / 'behavior1/stdout.log')
    ids = reference['sessions'][0]['result']['generated_ids']
    for x in rows:
        folder = Path(x['folder'])
        raw = read(folder / 'stdout.log')
        result = read(folder / 'result.json')
        assert result['exit'] == 0 and not result.get('reader_errors')
        assert normalize(raw) == normalize(reference)
        assert raw['backend'] == 'cpu' and raw['mtp'] is False
        assert raw['generated_tokens'] == 16 and raw['actual_target_rows'] == 169
        assert raw['prefill_target_rows'] == 154 and raw['generated_decode_tokens'] == 15
        assert raw['actual_graph_calls'] == 16 and raw['decode_graph_calls'] == 15
        assert raw['sessions'][0]['result']['generated_ids'] == ids and len(ids) == 16
        for key, numerator, denominator in [
            ('prefill_tokens_per_second', 154, 'prefill_seconds'),
            ('decode_output_tokens_per_second', 15, 'decode_seconds'),
            ('output_tokens_per_second', 16, 'session_seconds')]:
            assert abs(raw[key] - numerator / raw[denominator]) < 1e-8
        assert read(folder / 'process-cpu.json')['available']
    ready = read(C / 'ready.json')
    source = read(C / 'source-pins.json')
    assert pin(source['before']['path']) == source['before']
    assert pin(source['after']['path']) == source['after']
    before = Path(source['before']['path']).read_bytes()
    after = Path(source['after']['path']).read_bytes()
    assert before.replace(b'    params.poll = 0;\n', b'') == after
    integration = read(C / 'root-integration.json')
    assert integration['sha256'] == source['after']['sha256'] and integration['tested_source_equal']
    old_inputs, new_inputs = read(W / 'build1/link-inputs.json'), read(C / 'link-inputs.json')
    assert len(old_inputs) == len(new_inputs)
    changed = [(a, b) for a, b in zip(old_inputs, new_inputs) if a != b]
    assert len(changed) == 1 and changed[0] == (ready['replacement']['before'], ready['replacement']['after'])
    gate = read(C / 'summary.json')
    assert gate['unit']['tests'] == 9 and gate['unit']['failures'] == gate['unit']['skipped'] == 0
    assert read(C / 'behavior1/nontime-diff.json') == []
    assert gate['behavior']['nontime_difference_count'] == 0
    cpu = summary['timing_process_CPU']
    cpu_pct = (cpu['C']['total_seconds']['median'] / cpu['H']['total_seconds']['median'] - 1) * 100
    compact_memory = {}
    for arm in ('H', 'C'):
        m = summary['memory'][arm]
        mem, threads = m['summary'], m['threads']
        assert mem['setup_error'] is None and mem['thread_error'] is None
        compact_memory[arm] = dict(sampled_peaks=mem['sampled_peaks'], sample_count=mem['sample_count'],
            running_sample_count=mem['running_sample_count'], unavailable_reasons=mem['unavailable_reasons'],
            thread_count=dict(samples=threads['count'], peak=threads['peak'], median=threads['values']['median']),
            actual_sample_gaps_ms={k: v for k, v in mem['actual_sample_gaps_ms'].items() if k != 'samples'},
            source='The independent memory process only; no memory-run throughput enters timing statistics.')
    pairs = []
    for pair_index in range(3):
        pair = {x['arm']: x for x in rows[2 * pair_index:2 * pair_index + 2]}
        pairs.append(dict(pair=pair_index + 1, order=[x['arm'] for x in rows[2 * pair_index:2 * pair_index + 2]],
            C_over_H_percent={k: (pair['C']['metrics'][k] / pair['H']['metrics'][k] - 1) * 100
                              for k in summary['comparison']}))
    final = dict(status='EIGHT_FRESH_PROCESSES_COMPLETE_ALL_WORK_PASS',
        timing=summary['timing'], comparison=summary['comparison'], paired_comparison=pairs,
        timing_process_CPU=cpu, total_process_CPU_C_over_H_percent=cpu_pct,
        memory=compact_memory,
        work=dict(full_non_time_report_differences=0, prompt_rows=154, target_rows=169,
            generated_tokens=16, decode_tokens=15, graph_calls=16, decode_graph_calls=15, generated_ids=ids,
            reference=pin(W / 'behavior1/stdout.log'),
            normalization='Only retained clock keys seconds/unix_ms/unix_ns/clock_unix and *_seconds/*tokens_per_second omitted recursively; all other fields compared.'),
        process_receipts=[dict(index=x['index'], arm=x['arm'], mode=x['mode'], pid=x['process']['pid'],
            exit=x['process']['exit'], process_CPU=x['process_cpu']) for x in rows],
        decision=dict(status='ADOPTED_FOR_NATIVE_CONTEXT_TEAM',
            rationale='The measured short CPU decode window improves by 2.21% with nonoverlapping sample ranges. The combined endpoint improves by 0.71%; whole-process CPU time increases by 4.37%. Adopt the tested native bounded default polling policy without adding a Hyle option or scanning other poll levels.',
            actual_canonical_integration=integration,
            limit='This is one Windows CPU N1/R1 greedy workload. No energy, multi-request, mixed CPU/GPU, macOS/Linux or broad CPU scaling claim. No old benchmark table or cross-window gain is rewritten.'),
        failures=dict(compile=0, link=0, runtime_unit=0, initial_behavior=0, screen_model=0,
            observer_setup=0, timeouts=0, retries=0,
            note='This polling candidate and its fresh screen succeeded on their first recorded attempts. Earlier context-team test-link and previous AVX2-window PIPE failures are separate historical tasks, not failures or samples of this window.'))
    save(S / 'final-summary.json', final)

    files = {}
    def add(name, path):
        path = Path(path)
        assert path.is_file(), path
        assert path.suffix.lower() in {'.json', '.py', '.patch', '.cc', '.h', '.xml', '.log', '.txt'}, path
        assert name not in files
        files[name] = path
    for leaf in ['source.patch', 'source-pins.json', 'build.py', 'check.py', 'ready.json', 'runtime.json',
                 'link-inputs.json', 'summary.json', 'root-integration.json']:
        add('candidate/' + leaf, C / leaf)
    for folder in ['compile', 'link', 'unit-link', 'unit-run', 'behavior1']:
        for leaf in ['command.json', 'process.json', 'stdout.log', 'stderr.log', 'actual-dependencies.json',
                     'dependencies.json', 'results.xml', 'nontime-diff.json']:
            path = C / folder / leaf
            if path.is_file():
                add('candidate/' + folder + '/' + leaf, path)
    add('candidate/reused-execution-test.cc', W / 'test-source/tests/compute_ggml_runtime/execution_test.cc')
    for leaf in ['plan.json', 'runs.json', 'summary.json', 'final-summary.json']:
        add('screen/' + leaf, S / leaf)
    for x in rows:
        folder = Path(x['folder'])
        for path in sorted(folder.iterdir()):
            if path.is_file():
                add('screen/' + folder.name + '/' + path.name, path)
    add('poll-screen.py', W / 'poll-screen.py')
    add('poll-screen-plan.json', W / 'poll-screen-plan.json')
    add('publish_poll.py', Path(__file__))
    add('publication-first-failure.json', W / 'poll-publication-first-failure.json')
    add('source-review/cpu-native-source-parity.json', W / 'cpu-native-source-parity.json')
    for name, path in {
        'reference/control-ready.json': W / 'build1/ready.json',
        'reference/control-runtime.json': W / 'build1/runtime.json',
        'reference/control-link-inputs.json': W / 'build1/link-inputs.json',
        'reference/control-source-pins.json': W / 'source-pins.json',
        'reference/behavior1-stdout.log': W / 'behavior1/stdout.log',
        'reference/behavior1-summary.json': W / 'behavior1/summary.json',
        'retained-observer/cpu-screen.py': R / '.scratch/inference-cpu-representative-20261026/peer-avx2/screen.py',
        'retained-observer/CPU-commands.json': R / '.scratch/inference-cpu-representative-20261026/peer-avx2/commands.json',
        'retained-observer/baseline-window.py': R / '.scratch/mtp-performance-convergence-20261025/baseline/window.py',
        'retained-observer/window.py': R / '.scratch/qwen-mtp-window-20261022/window.py',
        'retained-observer/turns.py': R / '.scratch/qwen-mtp-final-window-20261024/turns.py',
        'retained-observer/performance.py': R / '.scratch/qwen-mtp-quality-20261022/current-window/performance.py',
        'retained-observer/runner.py': R / '.scratch/architecture-refactor-2026-10-18/d4-windows-preparation-2026-10-21/first-decode-startup-2026-10-21/multiturn/multiturn_run.py',
        'retained-observer/observer.py': R / '.scratch/shared-execution-20261021/observer.py',
        'retained-observer/sampler.py': R / '.scratch/architecture-refactor-2026-10-18/qwen-gpu-comparison/memory-probe/memory_probe.py',
    }.items():
        add(name, path)
    report = dict(schema='hyle.cpu-polling-screen.v1', status='ADOPTED_FOR_NATIVE_CONTEXT_TEAM',
        generated_UTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        scope='One-line native threadpool polling change in an existing Context-owned team. Frozen shared563 CPU consumer versus its sole-runtime-OBJ replacement; 6 fresh timing and 2 independent memory processes, no peer, no pooling of older samples.',
        results=final,
        protocol=dict(order='H,C,C,H,H,C timing; H,C independent memory',
            repetitions_per_arm=3, independent_memory_processes_per_arm=1,
            requested=dict(prompt_rows=154, output_limit=16, capacity=256, max_sessions=1,
                active_sequences=1, sampling='greedy', MTP=False, prefix_cache='off', replay='commands'),
            endpoint_definitions=dict(prefill='154 / original prefill_seconds', decode='15 / original decode_seconds',
                combined='16 / original session_seconds; prefill_seconds + decode_seconds'),
            native_threads=4, borrowed_executor_workers=4, ATen_intraop_threads=4,
            thread_limit='These independent budgets are not a four-total-OS-thread cap.',
            timeout_seconds=180, warmups=0, profiler=False, retries=0, offline=True,
            first_gate_models_excluded=True, old_samples_pooled=False,
            work_reference_field_note=summary['work_reference']),
        cold_source=dict(source=source, patch=pin(C / 'source.patch'),
            change='Delete only params.poll=0; preserve ggml_threadpool_params_default(threads) poll50 and explicit normal priority. Existing native loop uses finite 131072*poll rounds before parking. No new option, owner, threads, math, ABI or resource lifetime change.',
            parity_review=pin(W / 'cpu-native-source-parity.json'),
            peer_limit='No peer run in this screen. The source review shows the peer creates and frees a native default50 pool per whole graph; it is not a shared cross-step persistent polling team.'),
        build=dict(ready=ready, only_runtime_object_changed=changed, link_input_count=len(new_inputs),
            all_other_link_inputs_unchanged=True, new_runtime_TUs=1, new_test_TUs=0, SDK_builds=0,
            compiler='MSVC 14.50.35717 /O2 /MD /W4 /WX; original macros and CPU native DLL unchanged.',
            note='Ready/source-pins preserve their creation-time BUILT_NOT_RUN/private-only fields. Later unit, behavior, screen and root-integration receipts establish subsequent execution and adoption; those historical files are not rewritten.'),
        runtime_unit_and_initial_behavior=gate,
        measurement_boundaries=[
            'All six timing processes have no memory/thread monitor. GetProcessTimes is read once after terminal wait while the real Popen process handle is still alive. Counters include all target threads, startup, weights, generation and teardown; not decode CPU cost, child-process time, utilization or energy.',
            'GetProcessTimes records user/kernel FILETIME counts at 100ns units. Post-exit query/file recording slightly extends parent process wall measurement, never the consumer generation endpoints. Startup and parent wall are not fair throughput endpoints.',
            'PSAPI working set/private commit and PDH GPU Process Memory are sampled only in the two separate memory processes. Requested memory interval10ms, OS thread interval100ms; actual gaps and full samples retained. Peaks are observed lower bounds, not allocator totals or busy-thread counts.',
            'Phase markers are parent stderr receipt times, not exact allocator or producer endpoint instants. Phase windows, brackets and unknown ready baselines are retained in original memory-summary.json. Missing GPU PID instances remain null, not zero.',
            'Original CPU app predates the R>1 categorical batching change. This N1 greedy workload is unchanged; this image does not certify newer unrelated Model/API changes.',
            'Existing local hardware inventory is Intel Core i9-13900K,24 cores/32 logical processors. No per-run affinity, CPUID, frequency, energy or sampled-kernel inventory was collected.',
            'BF16 stored weights and activation/store policy, F32 operation boundaries and native AVX2/FMA/F16C build remain unchanged. Identical16 output IDs are not a bitwise whole-model precision or quality proof.',
            'Only Windows CPU runtime evidence. No macOS/Linux, GPU, mixed CPU/GPU, multi-Model or multi-request performance claim. Do not multiply this short-window gain into previous CPU or CUDA reference tables.'
        ],
        prior_evidence_navigation={name: pin(R / 'docs/evidence/performance' / name) for name in [
            'inference-cpu-context-team-2026-10-26.json',
            'inference-cpu-avx2-window-2026-10-26.json',
            'inference-cpu-native-attribution-2026-10-26.json']},
        publication=dict(scope='Offline parsing and archiving only; no additional model/build/network operation.',
            first_packaging_failure=read(W / 'poll-publication-first-failure.json'),
            note='One missing retained-sampler path assertion was corrected before ZIP creation. Original model/build receipts and logs were not changed; no process was rerun.'))
    save(W / 'poll-public-summary.json', report)
    add('summary.json', W / 'poll-public-summary.json')
    manifest = [dict(name=name, bytes=p.stat().st_size, sha256=pin(p)['sha256'])
                for name, p in sorted(files.items())]
    save(W / 'poll-archive-manifest.json', manifest)
    add('archive-manifest.json', W / 'poll-archive-manifest.json')
    ZIP.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(ZIP, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for name, path in sorted(files.items()):
            archive.writestr(name, path.read_bytes())
    with zipfile.ZipFile(ZIP) as archive:
        assert archive.testzip() is None
        assert len(archive.namelist()) == len(files)
        for entry in manifest:
            data = archive.read(entry['name'])
            assert len(data) == entry['bytes'] and hashlib.sha256(data).hexdigest() == entry['sha256']
    report['archive'] = dict(**pin(ZIP), members=len(files), CRC_PASS=True, member_SHA256_PASS=True,
        exclusions='No binary/EXE/OBJ/LIB/DLL/map/SDK/model, copied vendor/full source tree, old model logs or old performance samples.')
    report['archive']['path'] = ZIP.relative_to(R).as_posix()
    save(PUBLIC, report)
    print(json.dumps(dict(report=pin(PUBLIC), archive=report['archive']), indent=2))

if __name__ == '__main__':
    main()
