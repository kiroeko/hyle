"""Refresh the private batch header's host owners and targeted fixtures only."""
from pathlib import Path
import argparse
import datetime as dt
import importlib.util
import sys

sys.dont_write_bytecode = True
STAGE = Path(__file__).resolve().parent
ARCH = STAGE.parent
ROOT = ARCH.parents[1]
spec = importlib.util.spec_from_file_location('batch_build_helpers', STAGE / 'prepare_scope.py')
scope = importlib.util.module_from_spec(spec)
spec.loader.exec_module(scope)
b, c = scope.b, scope.c


def check(plan):
    for row in plan['frozen']:
        if not b.same(row):
            raise ValueError('Source/header/recipe drift: ' + row['path'])


def check_cached(plan):
    for row in plan['cached_inputs']:
        if not b.same(row):
            raise ValueError('Cached link input drift: ' + row['path'])


def inputs(command):
    return [arg for arg in command if not arg.startswith('/') and Path(arg).is_absolute()
            and Path(arg).suffix.lower() in ('.obj', '.lib')]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--build', action='store_true')
    args = parser.parse_args()
    inventory = c.read(STAGE / 'header-owners.json')
    if inventory['unresolved']:
        raise ValueError('Unresolved private-header ownership')
    for row in c.read(STAGE / 'application.json')['files']:
        if b.identity(row['path'])['sha256'] != row['after_sha256']:
            raise ValueError('Applied source differs from reviewed overlay')
    tests = c.read(STAGE / 'test-recipes.json')
    test_freeze = c.read(STAGE / 'tests-source-freeze.json')
    for row in test_freeze['files']:
        if not b.same(row):
            raise ValueError('Final reviewed test support differs')
    out = STAGE / 'checks' / dt.datetime.now(dt.timezone.utc).strftime('%Y%m%dT%H%M%S')
    out.mkdir(parents=True, exist_ok=False)
    (out / 'tmp').mkdir()
    frozen = [b.identity(path) for path in (Path(__file__), STAGE / 'header-owners.json',
        STAGE / 'source-freeze.json', STAGE / 'workspace-tests-source-freeze.json',
        STAGE / 'application.json', STAGE / 'test-recipes.json', STAGE / 'tests-source-freeze.json', scope.HEADER)]
    rows, replacements = [], {}
    fi_row = None
    for i, owner in enumerate(inventory['owners']):
        source = Path(owner['source'])
        tag = f'{i:02d}-' + source.parent.name + '-' + source.stem
        command = b.host_command(owner['command_template'], source, tag, out)
        obj = str(out / (tag + '.obj'))
        row = {'tag': tag, 'source': b.identity(source), 'command': command, 'object': obj,
               'header_owner': True, 'closures': owner['closures']}
        rows.append(row)
        replacements[c.key(owner['object']['path'])] = obj
        frozen.extend((b.identity(owner['recipe']['path']), b.identity(source)))
        frozen.extend(b.identity(path) for path in b.host_dependencies(owner['command_template']))
        frozen.extend(b.identity(item['path']) for item in owner['local_headers'])
        if source.name == 'flashinfer_provider.cc':
            fi_row = row
    if fi_row is None:
        raise ValueError('Actual FlashInfer owner is missing')
    for entry in tests['compile']:
        source = Path(entry['source']['path'] if isinstance(entry['source'], dict) else entry['source'])
        if not source.is_absolute():
            source = ROOT / source
        tag = entry['tag']
        command = b.host_command(entry['command_template'], source, tag, out)
        command[1:1] = ['/I' + str(ROOT / 'src/compute_provider_flashinfer')]
        rows.append({'tag': tag, 'source': b.identity(source), 'command': command,
                     'object': str(out / (tag + '.obj')), 'header_owner': tag == 'workspace-test'})
        frozen.extend((b.identity(entry['recipe']['path']), b.identity(source)))
        frozen.extend(b.identity(path) for path in b.host_dependencies(entry['command_template']))
        frozen.extend(b.identity(path) for path in scope.hyle_headers(source, command))
    # Instrument only a second private provider instance for the observation
    # executable. The normal Qwen/CPU/CUDA images use the ordinary provider.
    probe = b.host_command(fi_row['command'], Path(fi_row['source']['path']), 'fi-probe', out)
    probe[1:1] = ['/Dquery_batch_workspace=observed_query_batch_workspace',
                   '/Dquery_mla_workspace=observed_query_mla_workspace']
    rows.append({'tag': 'fi-probe', 'source': fi_row['source'], 'command': probe,
                 'object': str(out / 'fi-probe.obj'), 'header_owner': True})
    by_tag = {row['tag']: row for row in rows}
    if len(by_tag) != len(rows):
        raise ValueError('Duplicate compile tags')
    links, cached, baselines = {}, {}, {}
    expected = {'cpu': 114, 'cuda': 133, 'qwen': 125}
    for arm in ('cpu', 'cuda', 'qwen'):
        path = Path(inventory['bases'][arm]['path'])
        baseline = c.read(path)
        baselines[arm] = baseline
        cached.update({c.key(row['path']): row for row in baseline['inputs']})
        frozen.append(b.identity(path))
        present = {c.key(row['path']) for row in baseline['inputs']}
        if len(present) != expected[arm]:
            raise ValueError('Base link closure count differs')
        for owner in present.intersection(replacements):
            if sum(c.key(arg) == owner for arg in baseline['command']) != 1:
                raise ValueError('Nonunique header owner in link')
        command = [replacements.get(c.key(arg), arg) for arg in baseline['command']
                   if not arg.upper().startswith(('/OUT:', '/MAP:', '/IMPLIB:', '/PDB:'))]
        if arm == 'cpu':
            command.insert(1, by_tag['workspace-test']['object'])
        image = out / (arm + '.exe')
        command += ['/OUT:' + str(image), '/MAP:' + str(image.with_suffix('.map')),
                    '/IMPLIB:' + str(image.with_suffix('.lib'))]
        owned = inputs(command)
        if len(owned) != expected[arm] + (arm == 'cpu') or len(owned) != len(set(map(c.key, owned))):
            raise ValueError('Final link closure changed unexpectedly')
        links[arm] = {'command': command, 'inputs': owned, 'image': str(image)}
    command = [by_tag['fi-probe']['object'] if c.key(arg) == c.key(fi_row['object']) else arg
               for arg in links['cuda']['command'] if not arg.upper().startswith(('/OUT:', '/MAP:', '/IMPLIB:', '/PDB:'))]
    command[1:1] = [by_tag[tag]['object'] for tag in ('native-query-wrapper', 'native-query-test')]
    image = out / 'query-probe.exe'
    command += ['/OUT:' + str(image), '/MAP:' + str(image.with_suffix('.map')),
                '/IMPLIB:' + str(image.with_suffix('.lib'))]
    links['query-probe'] = {'command': command, 'inputs': inputs(command), 'image': str(image)}
    baseline_path = ARCH / 'cuda-fusion-allocation/checks/20261019T115201/qwen-image.json'
    baseline = c.read(baseline_path)
    if not b.same(baseline):
        raise ValueError('Retained baseline model image differs')
    frozen.extend((b.identity(baseline_path), baseline))
    links['baseline'] = {'command': baselines['qwen']['command'],
                         'inputs': [row['path'] for row in baselines['qwen']['inputs']], 'image': baseline['path']}
    plan = {'compile': rows, 'links': links, 'cached_inputs': list(cached.values()),
        'frozen': list({c.key(row['path']): row for row in frozen}.values()),
        'header_owners': len(inventory['owners']), 'host_TUs': len(rows), 'native_TUs': 0,
        'SDK_build': False, 'CMake_run': False, 'GPU_run': False,
        'instrumentation_is_test_only': True, 'baseline_image_reused': True}
    path = out / 'plan.json'
    c.save(path, plan)
    check(plan)
    check_cached(plan)
    print('PLAN', path, flush=True)
    if not args.build:
        return
    # Production CUDA/FlashInfer and CPU have distinct actual link closures.
    environments = {arm: b.environment(links[arm]['command'], links[arm]['inputs'], out)[0]
                    for arm in ('cpu', 'qwen')}
    for row in rows:
        use_cpu = row['tag'] == 'workspace-test' or row.get('closures') == ['cpu']
        c.execute(row['tag'] + '-compile', row['command'], environments['cpu' if use_cpu else 'qwen'], out)
        check(plan)
        if row['header_owner']:
            included = c.read(out / (row['tag'] + '-deps.json'))['Data']['Includes']
            if c.key(scope.HEADER) not in {c.key(arg) for arg in included}:
                raise ValueError('Expected changed private header in fresh owner')
        c.save(out / (row['tag'] + '-identity.json'), {'command': row['command'],
            'source': row['source'], 'object': b.identity(row['object'])})
    check_cached(plan)
    for arm in ('cpu', 'cuda', 'qwen', 'query-probe'):
        link = links[arm]
        c.execute(arm + '-link', link['command'], environments['cpu' if arm == 'cpu' else 'qwen'], out)
        check(plan)
        c.save(out / (arm + '-link-plan.json'), {'command': link['command'],
            'inputs': [b.identity(arg) for arg in link['inputs']]})
        c.save(out / (arm + '-image.json'), b.identity(link['image']))
    c.save(out / 'baseline-image.json', baseline)
    c.save(out / 'summary.json', {'passed': True, 'host_TUs': len(rows),
        'native_TUs': 0, 'SDK_build': False, 'GPU_run': False})
    print('BUILD_COMPLETE', path, flush=True)


if __name__ == '__main__':
    main()
