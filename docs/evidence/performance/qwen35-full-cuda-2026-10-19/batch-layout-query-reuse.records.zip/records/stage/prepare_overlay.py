from pathlib import Path
import difflib
import hashlib
import inspect
import json
import re

STAGE = Path(__file__).resolve().parent
REPO = STAGE.parents[2]
PATHS = ('include/hyle/compute/detail/batch_provider.h',
         'src/compute_batch/batch_execution.cc',
         'src/compute_provider_flashinfer/flashinfer_provider.cc')


def identity(path):
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}


def replace(text, old, new):
    assert text.count(old) == 1, (old[:100], text.count(old))
    return text.replace(old, new)


before = {p: (REPO / p).read_text(encoding='utf-8') for p in PATHS}
after = dict(before)

p = PATHS[0]
text = before[p]
text = replace(text,
    'kBatchPlanningExtensionId{0x48594c4542415443ULL,0x504c414e4e494e47ULL,6}',
    'kBatchPlanningExtensionId{0x48594c4542415443ULL,0x504c414e4e494e47ULL,7}')
text = replace(text,
    'kMlaBatchPlanningExtensionId{0x48594c454d4c4142ULL,0x504c414e4e494e47ULL,4}',
    'kMlaBatchPlanningExtensionId{0x48594c454d4c4142ULL,0x504c414e4e494e47ULL,5}')
text = replace(text,
    '''  Status (*workspace)(void *,Queue &,const BatchLayoutVersion &,BatchPlanReport *) noexcept=nullptr;''',
    '''  // allow_update carries the caller's existing preparation intent. Only
  // when true may a read-only reuse proof size the retained original plan.
  // False must size a fresh native plan, even when the old plan could run.
  Status (*workspace)(void *,Queue &,const BatchLayoutVersion &,bool allow_update,BatchPlanReport *) noexcept=nullptr;''')
after[p] = text

p = PATHS[1]
text = replace(before[p],
    'Result<BatchPlanReport> query_workspace(d::BatchInvocationData&s,const BatchLayoutVersion&layout)noexcept{',
    'Result<BatchPlanReport> query_workspace(d::BatchInvocationData&s,const BatchLayoutVersion&layout,bool allow_update)noexcept{')
text = replace(text,
    'struct Call{d::BatchInvocationData*state;const BatchLayoutVersion*layout;BatchPlanReport*report;}call{&s,&layout,&report};',
    'struct Call{d::BatchInvocationData*state;const BatchLayoutVersion*layout;bool allow_update;BatchPlanReport*report;}call{&s,&layout,allow_update,&report};')
text = replace(text,
    '->workspace(call.state->native,*call.state->queue,*call.layout,call.report);',
    '->workspace(call.state->native,*call.state->queue,*call.layout,call.allow_update,call.report);')
text = replace(text,
    'auto workspace_report,query_workspace(s,layout)',
    'auto workspace_report,query_workspace(s,layout,update)')
after[p] = text

p = PATHS[2]
text = before[p]
start = text.index('Result<bool> update_batch_slot(')
commit = text.index('  slot.layout=layout;', start)
finish = text.index('\nProviderRuntimeProperties batch_runtime', commit)
old_update = text[start:finish]
predicate = text[text.index('\n', start) + 1:commit]
predicate = replace(predicate, '  auto&slot=*static_cast<BatchSlot*>(opaque);', '  ')
helper = '''// A read-only proof about this original prepared plan, not a new schedule
// cache. Sizing and update must use exactly the same topology qualification.
bool can_reuse_batch_plan(const BatchSlot&slot,const BatchLayoutVersion&layout)noexcept{
''' + predicate + '''  return true;
}
'''
update = '''Result<bool> update_batch_slot(void*opaque,const BatchLayoutVersion&layout,BatchPlanReport*report)noexcept{
  auto&slot=*static_cast<BatchSlot*>(opaque);
  if(!can_reuse_batch_plan(slot,layout))return false;
''' + text[commit:finish]
text = text[:start] + update + text[finish:]
text = replace(text, 'Status query_batch_layout(BatchSlot&slot,Queue&queue,const BatchLayoutVersion&layout,\n',
               helper + 'Status query_batch_layout(BatchSlot&slot,Queue&queue,const BatchLayoutVersion&layout,\n')
text = replace(text, '                         native::BatchFacts&facts) {',
               '                         bool allow_update,native::BatchFacts&facts) {')
query_start = text.index('Status query_batch_layout(')
query_finish = text.index('Status batch_workspace(', query_start)
query = text[query_start:query_finish]
query = replace(query,
    '  auto spec=slot.spec;spec.query_rows=layout.facts().query_rows;spec.requests=layout.facts().requests;',
    '''  // Queue and primary-context admission above still runs on a reuse hit.
  // An explicit fresh-plan request must retain the original scheduler query:
  // a different fresh chunk heuristic may require more than the old plan.
  if(allow_update && can_reuse_batch_plan(slot,layout)){
    facts={};facts.float_bytes=slot.report.float_workspace_bytes;facts.int_bytes=slot.report.int_workspace_bytes;
    return Status::Ok();
  }
  auto spec=slot.spec;spec.query_rows=layout.facts().query_rows;spec.requests=layout.facts().requests;''')
text = text[:query_start] + query + text[query_finish:]
text = replace(text,
    'Status batch_workspace(void*opaque,Queue&queue,const BatchLayoutVersion&layout,BatchPlanReport*report)noexcept {',
    'Status batch_workspace(void*opaque,Queue&queue,const BatchLayoutVersion&layout,bool allow_update,BatchPlanReport*report)noexcept {')
text = replace(text,
    'query_batch_layout(*static_cast<BatchSlot*>(opaque),queue,layout,facts)',
    'query_batch_layout(*static_cast<BatchSlot*>(opaque),queue,layout,allow_update,facts)')
after[p] = text

# A legal scheduler input disproves sizing a fresh plan from the old report.
# Formula is the retained pinned PrefillBinarySearchKVChunkSize algorithm;
# this arithmetic check does not initialize CUDA or execute a model.
def schedule(lengths, maximum=15, minimum=128):
    lo, hi = minimum, max(1, *lengths)
    while lo < hi:
        mid = (lo + hi) // 2
        tiles = sum((max(length, 1) + mid - 1) // mid for length in lengths)
        if tiles > maximum:
            lo = mid + 1
        else:
            hi = mid
    return lo, sum((max(length, 1) + lo - 1) // lo for length in lengths)

old, new = [7000, 7000], [6999, 6001]
old_chunk, old_tiles = schedule(old)
new_chunk, new_tiles = schedule(new)
assert (old_chunk, old_tiles, new_chunk, new_tiles) == (1000, 14, 875, 15)
assert [(x + old_chunk - 1) // old_chunk for x in old] == [(x + old_chunk - 1) // old_chunk for x in new]
counterexample = STAGE / 'scheduler_counterexample.py'
counterexample.write_text('''"""Pure-host port of the retained pinned scheduler's chunk search.
One Q tile per request; this neither initializes CUDA nor runs a model.
Source: .scratch/compute-execution-refactor-2026-10-18/mla-zero-workspace/
verified-headers/include/flashinfer/attention/scheduler.cuh:101-130,
then padded_batch_size=new_batch_size for enable_cuda_graph=false.
"""
import json

''' + inspect.getsource(schedule) + '''
old, new = [7000, 7000], [6999, 6001]
old_chunk, old_tiles = schedule(old)
fresh_chunk, fresh_tiles = schedule(new)
old_counts = [(x + old_chunk - 1) // old_chunk for x in old]
updated_counts = [(x + old_chunk - 1) // old_chunk for x in new]
assert old_counts == updated_counts
assert fresh_tiles > old_tiles
print(json.dumps({"old_lengths": old, "new_lengths": new,
    "old_chunk": old_chunk, "old_plan_tiles": old_tiles,
    "new_lengths_at_old_chunk": updated_counts,
    "fresh_chunk": fresh_chunk, "fresh_tiles": fresh_tiles,
    "conclusion": "Old plan remains reusable, but a forced fresh plan needs more tiles/workspace."}, indent=2))
''', encoding='utf-8', newline='\n')

diff = []
records = []
for p in PATHS:
    source = REPO / p
    old_path, new_path = STAGE / 'before' / p, STAGE / 'source' / p
    old_path.parent.mkdir(parents=True, exist_ok=True)
    new_path.parent.mkdir(parents=True, exist_ok=True)
    old_path.write_bytes(source.read_bytes())
    new_path.write_text(after[p], encoding='utf-8', newline='\n')
    records.append({'target': p, 'origin': identity(source), 'before': identity(old_path), 'after': identity(new_path)})
    diff.extend(difflib.unified_diff(before[p].splitlines(True), after[p].splitlines(True),
                                    fromfile='a/' + p, tofile='b/' + p))
(STAGE / 'changes.diff').write_text(''.join(diff), encoding='utf-8', newline='\n')
predicate_old = re.sub(r'\s+', '', predicate)
predicate_new = re.sub(r'\s+', '', helper[helper.index('{') + 1:helper.rindex('  return true;')])
assert predicate_old == predicate_new
(STAGE / 'facts.json').write_text(json.dumps({
    'state': 'Scratch only; not applied, compiled or run.',
    'change': 'Private workspace callback receives existing allow_update intent; FI shares one read-only actual-plan reuse predicate with update.',
    'extension_versions': {'BatchPlanning': '6 -> 7', 'MlaBatchPlanning': '4 -> 5'},
    'force_fresh_counterexample': {'not_a_GPU_run': True, 'max_batch_if_split': 15, 'min_chunk': 128,
        'raw_host_derivation_script': identity(counterexample),
        'old_lengths': old, 'new_lengths': new, 'old_chunk': old_chunk, 'fresh_new_chunk': new_chunk,
        'old_tiles': old_tiles, 'fresh_new_tiles': new_tiles,
        'old_chunk_counts_unchanged': True,
        'conclusion': 'can_reuse old plan does not imply a fresh plan fits its workspace; allow_update=false must execute the original query.'},
    'before_after_work': {'first_plan_or_allow_update_false_or_predicate_miss': 'Original native sizing; genuine plan path unchanged.',
        'allow_update_true_and_original_plan_reusable': 'Same Queue/context validation and O(requests) predicate; no native scheduler sizing query; report original actual float/int bytes; update alone commits layout/generation.',
        'Qwen_six_selected_slots': 'Up to six avoided host-only sizing queries per warm prepare when each original plan is reusable; no measured time or speedup claim.'},
    'preserved': ['No new plan cache, public option or resource/owner identity', 'Original reset, queue, epoch, busy/result, layout and permission gates',
                  'Read-only sizing does not mutate native plan, generation, layout or report', 'Core never inspects provider/model/op names',
                  'False intent preserves explicit fresh planning and workspace hard-cap checks', 'No native CUDA/SDK/math change'],
    'compile_scope': ['flashinfer_provider.cc and batch_execution.cc fresh',
        'All actual BatchProviderVTable/extension ID header owners must refresh; no native .cu or SDK recompile required',
        'CPU ggml native_batch.cc has uses_caller_workspace=false and no workspace callback; source unchanged but header owner fresh',
        'Test agent owns workspace_test.cc companion overlay and exact recipe review'],
    'limits': ['Static predicate relocation equality is not a compiler/runtime proof',
        'Mock test proves allow_update propagation/force-replan cap behaviour; physical native-query call elimination needs direct call observation, not only reused_native_plan report',
        'No claims about skipped general Graph rebind scans or unchanged full-model performance'],
}, indent=2) + '\n', encoding='utf-8')
(STAGE / 'source-freeze.json').write_text(json.dumps({'state': 'Frozen scratch overlay; no apply/build/GPU',
    'files': records, 'diff': identity(STAGE / 'changes.diff'), 'facts': identity(STAGE / 'facts.json'),
    'predicate_normalized_identity': hashlib.sha256(predicate_old.encode()).hexdigest()}, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'files': len(records), 'diff': identity(STAGE / 'changes.diff'),
                  'freeze': identity(STAGE / 'source-freeze.json')}, indent=2))
