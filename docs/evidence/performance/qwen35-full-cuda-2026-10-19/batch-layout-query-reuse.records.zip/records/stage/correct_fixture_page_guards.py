"""Static fixture correction: pass only the active page permission guards."""
from pathlib import Path
import difflib
import hashlib
import json

STAGE=Path(__file__).resolve().parent
source=STAGE/'test-support/workspace_query_test.cc'
before=source.read_bytes()
assert hashlib.sha256(before).hexdigest()=='e8b40ac5da63e563bd0d22834772e45734f0e0c5154ee64dddcbe8094f291395'
correction=STAGE/'fixture-correction'
(correction/'before').mkdir(parents=True,exist_ok=True)
(correction/'before/workspace_query_test.cc').write_bytes(before)
(correction/'original-tests-source-freeze.json').write_bytes((STAGE/'tests-source-freeze.json').read_bytes())
text=before.decode('utf-8')
assert text.count('#include <array>')==1
text=text.replace('#include <array>','#include <array>\n#include <algorithm>')
old='''      if(paged){key_frame=key_arena.read(layout,key_pages).value();value_frame=value_arena.read(layout,value_pages).value();}'''
new='''      if(paged){
        auto pages=ids;std::sort(pages.begin(),pages.end());pages.erase(std::unique(pages.begin(),pages.end()),pages.end());
        std::vector<c::ReadLease> selected_keys,selected_values;
        for(const auto page:pages){selected_keys.push_back(key_pages[std::size_t(page)]);selected_values.push_back(value_pages[std::size_t(page)]);}
        key_frame=key_arena.read(layout,selected_keys).value();value_frame=value_arena.read(layout,selected_values).value();
      }'''
assert text.count(old)==1
text=text.replace(old,new)
after=text.encode('utf-8')
source.write_bytes(after)
(correction/'changes.diff').write_text(''.join(difflib.unified_diff(before.decode().splitlines(True),text.splitlines(True),fromfile='a/test-support/workspace_query_test.cc',tofile='b/test-support/workspace_query_test.cc')),encoding='utf-8')
record=dict(reason='Static pre-build fixture review found PagedArena::read requires exact referenced guards; no failed execution. Select deduplicated active IDs without changing any assertions or product contract.',
            files=[dict(path=str(source),before_sha256=hashlib.sha256(before).hexdigest(),after_sha256=hashlib.sha256(after).hexdigest(),bytes=len(after))])
(correction/'source-freeze.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
print(json.dumps(record,indent=2))
