from pathlib import Path
import difflib
import hashlib
import json

ROOT = Path(__file__).resolve().parents[3]
STAGE = Path(__file__).resolve().parent
name = 'tests/compute_batch/workspace_test.cc'
old = (ROOT / name).read_bytes()
text = old.decode('utf-8').replace('\r\n', '\n')

def replace(before, after):
    global text
    assert text.count(before) == 1, before
    text = text.replace(before, after)

replace('c::BatchProgramOptions options;unsigned plans=0,runs=0,queries=0;\n  std::size_t float_bytes=1536,int_bytes=1024;',
'''c::BatchProgramOptions options;unsigned plans=0,runs=0,queries=0,updates=0;
  unsigned fresh_queries=0,update_queries=0;
  bool permit_reuse=false,last_allow_update=false;
  std::size_t float_bytes=1536,int_bytes=1024;
  std::size_t planned_float_bytes=0,planned_int_bytes=0;''')
replace('.update=[](void*,const c::BatchLayoutVersion&,c::BatchPlanReport*)noexcept->hyle::Result<bool>{return false;},',
'''.update=[](void*p,const c::BatchLayoutVersion&,c::BatchPlanReport*report)noexcept->hyle::Result<bool>{
      auto&s=*static_cast<Mock*>(p);++s.updates;if(!s.permit_reuse || !s.plans)return false;
      report->float_workspace_bytes=s.planned_float_bytes;report->int_workspace_bytes=s.planned_int_bytes;return true;},''')
replace('auto&s=*static_cast<Mock*>(p);++s.plans;return d::EnqueueResult::accepted_command(s.inspect(views,true));},',
'''auto&s=*static_cast<Mock*>(p);++s.plans;const auto status=s.inspect(views,true);
      if(status.ok()){s.planned_float_bytes=s.float_bytes;s.planned_int_bytes=s.int_bytes;}
      return d::EnqueueResult::accepted_command(status);},''')
replace('if(batch.uses_caller_workspace){\n      if(!v.float_workspace.valid() || v.float_workspace.size()<float_bytes ||\n         !v.int_workspace.valid() || v.int_workspace.size()<int_bytes ||\n         !v.host_workspace.valid() || v.host_workspace.size()<int_bytes)',
'''if(batch.uses_caller_workspace){
      const auto floating=planning?float_bytes:planned_float_bytes;
      const auto integer=planning?int_bytes:planned_int_bytes;
      if(!v.float_workspace.valid() || v.float_workspace.size()<floating ||
         !v.int_workspace.valid() || v.int_workspace.size()<integer ||
         !v.host_workspace.valid() || v.host_workspace.size()<integer)''')
replace('batch.workspace=[](void*p,c::Queue&,const c::BatchLayoutVersion&,c::BatchPlanReport*report)noexcept{\n      auto&s=*static_cast<Mock*>(p);++s.queries;report->float_workspace_bytes=s.float_bytes;report->int_workspace_bytes=s.int_bytes;return hyle::Status::Ok();};',
'''batch.workspace=[](void*p,c::Queue&,const c::BatchLayoutVersion&,bool allow_update,c::BatchPlanReport*report)noexcept{
      auto&s=*static_cast<Mock*>(p);++s.queries;s.last_allow_update=allow_update;
      if(allow_update)++s.update_queries;else ++s.fresh_queries;
      const bool reuse=allow_update && s.permit_reuse && s.plans;
      report->float_workspace_bytes=reuse?s.planned_float_bytes:s.float_bytes;
      report->int_workspace_bytes=reuse?s.planned_int_bytes:s.int_bytes;return hyle::Status::Ok();};''')
replace('EXPECT_EQ(mock.queries,native?0u:1u);',
'''EXPECT_EQ(mock.queries,native?0u:1u);
      EXPECT_EQ(mock.fresh_queries,native?0u:1u);EXPECT_EQ(mock.update_queries,0u);''')

new_test = r'''
TEST(BatchWorkspace, ForcedFreshSizingPreservesOldEpisodeWhenNewPlanExceedsCap){
  Mock mock;mock.permit_reuse=true;
  auto stats=m::StatsAllocator::create(m::system_allocator()).value();
  const auto storage=c::CacheStorage::plain(c::DataType::kFloat16).value();
  auto schema=c::BatchSchema::create({.storage=c::BatchStorage::kRagged,.query_type=c::DataType::kFloat16,.output_type=c::DataType::kFloat16,
      .key_storage=storage,.value_storage=storage,.max_requests=1,.max_query_rows=1,.max_kv_rows=1,.max_pages=0,.max_page_refs=0,
      .query_heads=1,.kv_heads=1,.qk_head_dim=64,.value_head_dim=64,.page_size=1}).value();
  auto context=c::Context::create(c::cpu::device(),mock.provider()).value();auto queue=context.create_queue().value();
  auto program=c::BatchProgram::prepare(context,schema,{.resource=m::system_resource(),.host_workspace=m::system_resource(),
      .max_float_workspace_bytes=4096,.max_int_workspace_bytes=2048,.allocator=stats.get()}).value();
  auto slot=c::BatchInvocation::create(program,queue).value();
  const std::array<std::int32_t,2> offsets{0,1};const auto layout=schema.version({offsets,offsets,{},{}}).value();
  auto pool=c::LeasePool::create(m::system_resource(),1024).value();std::array<c::ReadLease,3> inputs;
  for(auto&input:inputs){auto writer=pool.allocate(128).value();ASSERT_TRUE(writer.view()->fill(std::byte{0}).ok());input=writer.publish().value();}
  auto initial=slot.prepare_batch(layout);ASSERT_TRUE(initial)<<initial.error().message();
  EXPECT_FALSE(mock.last_allow_update);EXPECT_EQ(mock.plans,1u);EXPECT_EQ(mock.updates,0u);
  auto first=initial->run(inputs);ASSERT_TRUE(first)<<first.error().message();ASSERT_TRUE(first->wait().ok());
  *first={};*initial={};const auto previous=slot.report();
  mock.float_bytes=8192; // A fresh scheduler may need more than this retained plan.
  const auto before=stats.snapshot().total_allocs;
  auto rejected=slot.prepare_batch(layout);ASSERT_FALSE(rejected);EXPECT_TRUE(rejected.error().IsResourceExhausted());
  EXPECT_FALSE(mock.last_allow_update);EXPECT_EQ(mock.fresh_queries,2u);EXPECT_EQ(mock.update_queries,0u);
  EXPECT_EQ(mock.plans,1u);EXPECT_EQ(mock.updates,0u);EXPECT_EQ(stats.snapshot().total_allocs,before);
  const auto unchanged=slot.report();EXPECT_EQ(unchanged.layout_generation,previous.layout_generation);
  EXPECT_EQ(unchanged.float_workspace_bytes,previous.float_workspace_bytes);
  EXPECT_EQ(unchanged.int_workspace_bytes,previous.int_workspace_bytes);
  EXPECT_EQ(unchanged.reused_native_plan,previous.reused_native_plan);
  {auto old=slot.output();ASSERT_TRUE(old)<<old.error().message();std::array<std::byte,128> bytes;
    ASSERT_TRUE(old->view()->read(bytes).ok());for(auto value:bytes)EXPECT_EQ(value,std::byte{7});}
  auto reused=slot.update_batch(layout);ASSERT_TRUE(reused)<<reused.error().message();
  EXPECT_TRUE(mock.last_allow_update);EXPECT_EQ(mock.update_queries,1u);EXPECT_EQ(mock.plans,1u);EXPECT_EQ(mock.updates,1u);
  EXPECT_TRUE(slot.report().reused_native_plan);EXPECT_EQ(slot.report().float_workspace_bytes,previous.float_workspace_bytes);
  auto second=reused->run(inputs);ASSERT_TRUE(second)<<second.error().message();ASSERT_TRUE(second->wait().ok());
  *second={};*reused={};EXPECT_EQ(mock.runs,2u);ASSERT_TRUE(slot.close().ok());ASSERT_TRUE(context.drain().ok());
}
'''
text = text.rsplit('\n}', 1)[0] + '\n' + new_test + '\n}\n'
out = STAGE / 'test-overlay' / name
out.parent.mkdir(parents=True, exist_ok=True)
after = text.encode('utf-8')
out.write_bytes(after)
(STAGE/'workspace-tests.diff').write_text(''.join(difflib.unified_diff(old.decode('utf-8').splitlines(True),text.splitlines(True),fromfile='a/'+name,tofile='b/'+name)),encoding='utf-8')
(STAGE/'workspace-tests-source-freeze.json').write_text(json.dumps({'files':[{'path':name,'before_sha256':hashlib.sha256(old).hexdigest(),'after_sha256':hashlib.sha256(after).hexdigest(),'bytes':len(after)}]},indent=2)+'\n',encoding='utf-8')
print(json.dumps({'path':str(out),'sha256':hashlib.sha256(after).hexdigest(),'bytes':len(after)}))
