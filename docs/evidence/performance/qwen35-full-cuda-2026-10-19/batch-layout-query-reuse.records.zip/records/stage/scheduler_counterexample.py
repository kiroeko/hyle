"""Pure-host port of the retained pinned scheduler's chunk search.
One Q tile per request; this neither initializes CUDA nor runs a model.
Source: .scratch/compute-execution-refactor-2026-10-18/mla-zero-workspace/
verified-headers/include/flashinfer/attention/scheduler.cuh:101-130,
then padded_batch_size=new_batch_size for enable_cuda_graph=false.
"""
import json

def schedule(lengths, maximum=15, minimum=128):
    lo, hi = minimum, max(1, *lengths)
    while lo < hi:
        mid = (lo + hi) // 2
        tiles = sum((max(length, 1) + mid - 1) // mid for length in lengths)
        if tiles > maximum:
            lo = mid + 1
        else:
            hi = mid
    return lo, sum((max(length, 1) + lo - 1) // lo for length in lengths)

old, new = [7000, 7000], [6999, 6001]
old_chunk, old_tiles = schedule(old)
fresh_chunk, fresh_tiles = schedule(new)
old_counts = [(x + old_chunk - 1) // old_chunk for x in old]
updated_counts = [(x + old_chunk - 1) // old_chunk for x in new]
assert old_counts == updated_counts
assert fresh_tiles > old_tiles
print(json.dumps({"old_lengths": old, "new_lengths": new,
    "old_chunk": old_chunk, "old_plan_tiles": old_tiles,
    "new_lengths_at_old_chunk": updated_counts,
    "fresh_chunk": fresh_chunk, "fresh_tiles": fresh_tiles,
    "conclusion": "Old plan remains reusable, but a forced fresh plan needs more tiles/workspace."}, indent=2))
