"""Keep successful owner objects; repair only the test capability definition."""
from pathlib import Path
import datetime as dt
import importlib.util
import sys

sys.dont_write_bytecode = True
STAGE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('batch_resume_helpers', STAGE / 'build.py')
build = importlib.util.module_from_spec(spec)
spec.loader.exec_module(build)
b, c = build.b, build.c
old_path = Path(sys.argv[1]).resolve()
old = c.read(old_path)
for row in old['frozen']:
    if Path(row['path']) == STAGE / 'build.py':
        if b.identity(STAGE / 'build-before-fi-test-define.py')['sha256'] != row['sha256']:
            raise ValueError('Historical build script differs')
    elif not b.same(row):
        raise ValueError('Source/header/recipe drift: ' + row['path'])
build.check_cached(old)
out = STAGE / 'checks' / (dt.datetime.now(dt.timezone.utc).strftime('%Y%m%dT%H%M%S') + '-test-define')
out.mkdir(exist_ok=False)
(out / 'tmp').mkdir()
rows, replacements, reused, fresh = [], {}, [], []
for row in old['compile']:
    row = row.copy()
    tag = row['tag']
    receipt = old_path.parent / (tag + '-identity.json')
    if tag not in ('native-query-test', 'fi-probe'):
        current = c.read(receipt)
        if current['source'] != row['source'] or not b.same(current['object']):
            raise ValueError('Successful retained owner differs: ' + tag)
        reused.append({'recipe': b.identity(receipt), 'object': current['object']})
    else:
        command = b.host_command(row['command'], Path(row['source']['path']), tag, out)
        if tag == 'native-query-test':
            command.insert(1, '/DHYLE_COMPUTE_FLASHINFER=1')
        row['command'] = command
        row['object'] = str(out / (tag + '.obj'))
        replacements[c.key(old['compile'][len(rows)]['object'])] = row['object']
        fresh.append(row)
    rows.append(row)
links = {}
for arm, link in old['links'].items():
    if arm == 'baseline':
        links[arm] = link
        continue
    command = [replacements.get(c.key(arg), arg) for arg in link['command']
               if not arg.upper().startswith(('/OUT:', '/MAP:', '/IMPLIB:', '/PDB:'))]
    image = out / (arm + '.exe')
    command += ['/OUT:' + str(image), '/MAP:' + str(image.with_suffix('.map')),
                '/IMPLIB:' + str(image.with_suffix('.lib'))]
    links[arm] = {'command': command, 'inputs': build.inputs(command), 'image': str(image)}
frozen = [row for row in old['frozen'] if Path(row['path']) != STAGE / 'build.py']
frozen.extend(b.identity(path) for path in (STAGE / 'build.py', Path(__file__), old_path,
    STAGE / 'build-before-fi-test-define.py'))
for row in reused:
    frozen.extend((row['recipe'], row['object']))
plan = {**old, 'compile': rows, 'links': links, 'frozen': frozen,
    'fresh_host_TUs_this_resume': len(fresh), 'reused_successful_host_TUs': len(reused),
    'original_failed_plan': b.identity(old_path),
    'correction': 'The standalone FlashInfer test needs its actual provider capability macro. Product warnings and code remain unchanged.'}
path = out / 'plan.json'
c.save(path, plan)
build.check(plan)
print('PLAN', path, flush=True)
env, _ = b.environment(links['qwen']['command'], links['qwen']['inputs'], out)
for row in fresh:
    c.execute(row['tag'] + '-compile', row['command'], env, out)
    build.check(plan)
    c.save(out / (row['tag'] + '-identity.json'), {'command': row['command'],
        'source': row['source'], 'object': b.identity(row['object'])})
build.check_cached(plan)
for arm in ('cpu', 'cuda', 'qwen', 'query-probe'):
    link = links[arm]
    link_env = b.environment(link['command'], link['inputs'], out)[0]
    c.execute(arm + '-link', link['command'], link_env, out)
    build.check(plan)
    c.save(out / (arm + '-link-plan.json'), {'command': link['command'],
        'inputs': [b.identity(arg) for arg in link['inputs']]})
    c.save(out / (arm + '-image.json'), b.identity(link['image']))
c.save(out / 'baseline-image.json', c.read(Path(old['links']['baseline']['image']).with_name('qwen-image.json')))
c.save(out / 'summary.json', {'passed': True, 'host_TUs': len(rows),
    'fresh_host_TUs_this_resume': len(fresh), 'reused_successful_host_TUs': len(reused),
    'native_TUs': 0, 'SDK_build': False, 'GPU_run': False})
print('BUILD_COMPLETE', path, flush=True)
