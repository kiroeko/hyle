"""Run the four common sizing cases and the real private native-query probe."""
from pathlib import Path
import importlib.util
import sys
import xml.etree.ElementTree as ET

sys.dont_write_bytecode = True
STAGE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('batch_check_helpers', STAGE / 'build.py')
build = importlib.util.module_from_spec(spec)
spec.loader.exec_module(build)
b, c = build.b, build.c
plan_path = Path(sys.argv[1]).resolve()
plan = c.read(plan_path)
build.check(plan)
if not c.read(plan_path.parent / 'summary.json')['passed']:
    raise ValueError('Successful host increment required')
reports = {}
for arm, name, count in (('cpu', 'BatchWorkspace.*', 4),
    ('query-probe', 'FlashinferWorkspaceQuery.ReuseSkipsNativeSizingButForcedAndChunkChangedPlansQuery', 1)):
    link = plan['links'][arm]
    out = plan_path.parent / ('run-' + arm)
    out.mkdir(exist_ok=False)
    (out / 'tmp').mkdir()
    env, directories = b.environment(link['command'], link['inputs'], out)
    c.save(out / 'inputs.json', {'image': b.identity(link['image']), 'plan': b.identity(plan_path),
        'runner': b.identity(Path(__file__)), 'runtime_link_input_paths': link['inputs'],
        'runtime_library_directories': directories, 'CPU_CUDA_cached_input_union_used': False})
    c.execute(arm, [link['image'], '--gtest_color=no', '--gtest_filter=' + name,
        '--gtest_output=xml:' + str(out / 'result.xml')], env, out)
    xml = ET.parse(out / 'result.xml').getroot()
    counts = {key: int(xml.attrib.get(key, '0')) for key in ('tests', 'failures', 'disabled', 'errors')}
    counts['skipped'] = sum(int(row.attrib.get('skipped', '0')) for row in xml.findall('testsuite'))
    passed = counts['tests'] == count and not any(counts[key] for key in ('failures', 'disabled', 'errors', 'skipped'))
    reports[arm] = {'passed': passed, **counts}
    c.save(out / 'summary.json', reports[arm])
    if not passed:
        raise ValueError('Expected all exact related cases to execute: ' + arm)
    print('BATCH_QUERY_CHECK', arm, counts, flush=True)
c.save(plan_path.parent / 'checks-summary.json', {'passed': all(row['passed'] for row in reports.values()),
    'different_cases': 5, 'reports': reports, 'MLA_or_cross_platform_runtime_claim': False,
    'actual_native_query_observed': True, 'throughput_claim': False})
