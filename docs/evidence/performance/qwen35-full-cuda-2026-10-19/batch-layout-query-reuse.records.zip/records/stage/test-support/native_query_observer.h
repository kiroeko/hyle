#pragma once
#include <cstdint>

// Scratch-only observation across the existing private native query boundary.
// No product header, public extension, or global product counter is changed.
namespace hyle_batch_query_test {
struct Counts final { std::uint64_t batch=0,mla=0; };
Counts snapshot() noexcept;
}
