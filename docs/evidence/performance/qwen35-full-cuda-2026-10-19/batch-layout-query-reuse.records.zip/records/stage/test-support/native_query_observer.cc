#include "native_query_observer.h"
#include "native_batch.h"

namespace hyle_batch_query_test {
namespace { thread_local Counts counts; }
Counts snapshot() noexcept { return counts; }
void record_batch() noexcept { ++counts.batch; }
void record_mla() noexcept { ++counts.mla; }
}

namespace hyle::compute::flashinfer::native {
// Only the test's provider TU is compiled with the two identifier substitutions.
// This TU and all cached native CUDA objects retain their original names.
cudaError_t observed_query_batch_workspace(BatchSpec spec,const std::int32_t*query,
    const std::int32_t*kv,cudaStream_t stream,BatchFacts&facts){
  hyle_batch_query_test::record_batch();
  return query_batch_workspace(spec,query,kv,stream,facts);
}
cudaError_t observed_query_mla_workspace(BatchSpec spec,const std::int32_t*query,
    const std::int32_t*kv,const std::int32_t*lengths,cudaStream_t stream,BatchFacts&facts){
  hyle_batch_query_test::record_mla();
  return query_mla_workspace(spec,query,kv,lengths,stream,facts);
}
}
