#include <gtest/gtest.h>
#include <hyle/compute/backends/cuda.h>
#include <hyle/compute/providers/flashinfer.h>
#include <hyle/compute/batch_execution.h>
#include <hyle/compute/paged_arena.h>
#include "half_test_support.h"
#include "native_query_observer.h"
#include <array>
#include <algorithm>
#include <cmath>
#include <span>
#include <vector>

namespace {
namespace c=hyle::compute;
using F16=hyle::simd::float16_t;

TEST(FlashinferWorkspaceQuery, ReuseSkipsNativeSizingButForcedAndChunkChangedPlansQuery){
  // The pinned native scheduler's minimum KV chunk is 128 rows (eight pages).
  // The expected branch comes from this independent boundary, not the product
  // predicate or the workspace sizes, which can coincide by allocator rounding.
  struct Episode final {unsigned rows;bool update,reuse;};
  constexpr std::array episodes{
      Episode{64,false,false},Episode{96,true,true},Episode{96,false,false},
      Episode{129,true,false},Episode{130,true,true}};
  for(bool paged:{false,true}){
    SCOPED_TRACE(paged);
    constexpr unsigned physical_rows=256,heads=8,kv_heads=2,depth=64;
    const auto storage=c::CacheStorage::plain(c::DataType::kFloat16).value();
    const c::BatchCapacity capacity{.storage=paged?c::BatchStorage::kPaged:c::BatchStorage::kRagged,
        .query_type=c::DataType::kFloat16,.output_type=c::DataType::kFloat16,
        .key_storage=storage,.value_storage=storage,.max_requests=1,.max_query_rows=1,
        .max_kv_rows=physical_rows,.max_pages=paged?16u:0u,.max_page_refs=paged?16u:0u,
        .query_heads=heads,.kv_heads=kv_heads,.qk_head_dim=depth,.value_head_dim=depth,.page_size=paged?16u:1u};
    auto context=c::Context::create(c::cuda::device(0).value(),c::flashinfer::provider()).value();
    auto memory=c::cuda::MemoryResource::create(context,c::cuda::MemoryKind::kDevice).value();
    auto host=c::cuda::MemoryResource::create(context,c::cuda::MemoryKind::kPinnedHost).value();
    auto queue=context.create_queue().value();auto schema=c::BatchSchema::create(capacity).value();
    std::vector<F16> query_words(heads*depth),key_words(physical_rows*kv_heads*depth),value_words(key_words.size());
    for(unsigned row=0;row<physical_rows;++row)for(unsigned head=0;head<kv_heads;++head)for(unsigned d=0;d<depth;++d)
      value_words[(std::size_t(row)*kv_heads+head)*depth+d]=half_test::encode<F16>(double(int((row*3+head*5+d)%15)-7)*.125);
    auto pool=c::LeasePool::create(memory.ref(),(query_words.size()+key_words.size()+value_words.size())*sizeof(F16)+512).value();
    const auto load=[&](std::span<const F16> values){
      auto writer=pool.allocate(values.size_bytes(),64).value();
      EXPECT_TRUE(writer.view()->write(std::as_bytes(values)).ok());return writer.publish().value();};
    const auto query=load(query_words);c::ReadLease key,value;
    c::PagedArena key_arena,value_arena;std::vector<c::ReadLease> key_pages(16),value_pages(16);
    if(paged){
      key_arena=c::PagedArena::create(schema,c::BatchCacheRole::kKey,memory.ref(),{.max_backing_bytes=key_words.size()*sizeof(F16)+64}).value();
      value_arena=c::PagedArena::create(schema,c::BatchCacheRole::kValue,memory.ref(),{.max_backing_bytes=value_words.size()*sizeof(F16)+64}).value();
      for(unsigned page=0;page<16;++page){
        auto kw=key_arena.acquire(page).value(),vw=value_arena.acquire(page).value();
        constexpr std::size_t words_per_page=16*kv_heads*depth;
        ASSERT_TRUE(kw.lease().view()->write(std::as_bytes(std::span(key_words).subspan(page*words_per_page,words_per_page))).ok());
        ASSERT_TRUE(vw.lease().view()->write(std::as_bytes(std::span(value_words).subspan(page*words_per_page,words_per_page))).ok());
        key_pages[page]=kw.publish(16).value();value_pages[page]=vw.publish(16).value();
      }
    }else{key=load(key_words);value=load(value_words);}
    auto program=c::BatchProgram::prepare(context,schema,{.resource=memory.ref(),.host_workspace=host.ref(),
        .max_float_workspace_bytes=8u<<20,.max_int_workspace_bytes=16384,.scale=.125F}).value();
    auto slot=c::BatchInvocation::create(program,queue).value();c::BatchPlanReport previous;
    for(unsigned step=0;step<episodes.size();++step){
      SCOPED_TRACE(step);
      const auto episode=episodes[step];const std::array<std::int32_t,2> q{0,1};
      const std::array<std::int32_t,2> kv{0,static_cast<std::int32_t>(paged?(episode.rows+15)/16:episode.rows)};
      const std::array<std::int32_t,1> tail{static_cast<std::int32_t>((episode.rows-1)%16+1)};
      std::vector<std::int32_t> ids;
      if(paged)for(std::int32_t page=0;page<kv[1];++page)ids.push_back((page*5+static_cast<std::int32_t>(step)*3)%16);
      const auto layout=schema.version({q,kv,ids,paged?std::span<const std::int32_t>(tail):std::span<const std::int32_t>{}}).value();
      const auto before=hyle_batch_query_test::snapshot();
      auto prepared=episode.update?slot.update_batch(layout):slot.prepare_batch(layout);
      ASSERT_TRUE(prepared)<<prepared.error().message();const auto after=hyle_batch_query_test::snapshot();
      if(episode.reuse){EXPECT_EQ(after.batch,before.batch);}
      else{EXPECT_GT(after.batch,before.batch);}
      EXPECT_EQ(after.mla,before.mla);const auto report=slot.report();EXPECT_EQ(report.reused_native_plan,episode.reuse);
      if(episode.reuse){EXPECT_EQ(report.float_workspace_bytes,previous.float_workspace_bytes);EXPECT_EQ(report.int_workspace_bytes,previous.int_workspace_bytes);}
      const std::array inputs{query,key,value};
      c::PagedArenaRead key_frame,value_frame;
      if(paged){
        auto pages=ids;std::sort(pages.begin(),pages.end());pages.erase(std::unique(pages.begin(),pages.end()),pages.end());
        std::vector<c::ReadLease> selected_keys,selected_values;
        for(const auto page:pages){selected_keys.push_back(key_pages[std::size_t(page)]);selected_values.push_back(value_pages[std::size_t(page)]);}
        key_frame=key_arena.read(layout,selected_keys).value();value_frame=value_arena.read(layout,selected_values).value();
      }
      auto done=paged?prepared->run(query,key_frame,value_frame):prepared->run(inputs);
      ASSERT_TRUE(done)<<done.error().message();ASSERT_TRUE(done->wait().ok());
      std::vector<F16> actual(heads*depth);
      {auto output=slot.output().value();ASSERT_TRUE(output.view()->read(std::as_writable_bytes(std::span(actual))).ok());}
      for(unsigned head=0;head<heads;++head)for(unsigned d=0;d<depth;++d){
        double expected=0;
        for(unsigned row=0;row<episode.rows;++row){
          const auto physical=paged?unsigned(ids[row/16])*16+row%16:row;
          expected+=half_test::decode(value_words[(std::size_t(physical)*kv_heads+head/(heads/kv_heads))*depth+d]);
        }
        const auto observed=half_test::decode(actual[head*depth+d]);
        ASSERT_TRUE(std::isfinite(observed));ASSERT_NEAR(observed,expected/double(episode.rows),.0025);
      }
      const auto after_run=hyle_batch_query_test::snapshot();EXPECT_EQ(after_run.batch,after.batch);EXPECT_EQ(after_run.mla,after.mla);
      previous=report;*done={};*prepared={};
    }
    ASSERT_TRUE(slot.close().ok());ASSERT_TRUE(context.drain().ok());
  }
}
}
