"""One fresh fixed-input full-model regression against retained allocation vectors."""
from pathlib import Path
import importlib.util
import sys

sys.dont_write_bytecode = True
STAGE = Path(__file__).resolve().parent
ARCH = STAGE.parent
ROOT = ARCH.parents[1]


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


build = load('gdn_model_build', STAGE / 'build.py')
n = load('gdn_model_numeric', ARCH / 'cuda-bf16-dual-projection/compare_numerics.py')
b, c = build.b, build.c
plan_path = Path(sys.argv[1]).resolve()
plan = c.read(plan_path)
build.check(plan)
if not c.read(plan_path.parent / 'summary.json')['passed']:
    raise ValueError('Successful incremental build required')
reference = ARCH / 'cuda-fusion-allocation/correctness'
vectors = {x.relative_to(reference / 'trace'): n.identity(x)
    for x in sorted((reference / 'trace').rglob('*')) if x.suffix in ('.bf16', '.f32')}
expected = {Path(phase) / name for phase in n.PHASES for name in ('hidden.bf16', 'logits.f32')}
if set(vectors) != expected:
    raise ValueError('Expected64 retained model observations')
out = STAGE / 'correctness'
out.mkdir(exist_ok=False)
(out / 'tmp').mkdir()
command = c.read(reference / 'qwen.command.json')['command']
command[0] = plan['links']['qwen']['image']
command[command.index('--trace') + 1] = str(out / 'trace')
inputs = Path(command[command.index('--inputs') + 1])
manifest = inputs / 'weights.tsv'
lines = manifest.read_text(encoding='utf-8').splitlines()
inventory = c.read(ROOT / 'docs/implementation/tasks/compute/qwen35-2b-local-input.json')
model = Path(lines[1])
record = next(x for x in inventory['files'] if x['path'] == model.name)
model_expected = {'path': str(model), 'bytes': record['size_bytes'], 'sha256': record['sha256']}
if lines[0] != 'HYLE_QWEN35_TEXT_V1' or lines[2] != inventory['artifact_identity_sha256'] or len(lines[3:]) != 320:
    raise ValueError('Inventory differs')
image = b.identity(command[0])
if image != c.read(plan_path.parent / 'qwen-image.json'):
    raise ValueError('Current image differs')
receipt = {'plan': b.identity(plan_path), 'runner': b.identity(Path(__file__)), 'image': image,
    'model': model_expected, 'manifest': b.identity(manifest),
    'prompt': b.identity(inputs / 'prompt.ids'), 'decode': b.identity(command[command.index('--decode-ids') + 1]),
    'reference_vectors': list(vectors.values()), 'reference_result': b.identity(reference / 'qwen.stdout.log'),
    'quality_acceptance': False, 'throughput_claim': False, 'fresh_model_processes': 1}
c.save(out / 'inputs.json', receipt)
if b.identity(model) != model_expected:
    raise ValueError('Actual model differs')
env, directories = b.environment(plan['links']['qwen']['command'], plan['links']['qwen']['inputs'], out)
c.save(out / 'runtime-environment.json', {'runtime_link_input_paths': plan['links']['qwen']['inputs'],
    'runtime_library_directories': directories, 'CPU_CUDA_cached_input_union_used': False})
c.execute('qwen', command, env, out)
observed = n.analyze_arm('current', image, out, vectors, n.final_json(reference / 'qwen.stdout.log'))
passed = (observed['equal_vectors'] == 64 and observed['all_outputs_finite'] and
          observed['capture_32_phases_with_7_ranges'] and
          observed['same_greedy_ids_as_reference'] and observed['same_fixed_decode_inputs'])
report = {'passed': passed, 'observation': observed, 'quality_acceptance': False,
    'throughput_claim': False, 'fresh_model_processes': 1,
    'limits': 'This is fixed-input allocation numerical/route regression, not throughput or cross-model coverage.'}
c.save(out / 'summary.json', report)
if not passed:
    raise ValueError('Expected64 equal finite model observations and same capture journey')
print('MODEL_CHECK', {'equal_vectors': observed['equal_vectors'], 'passed': passed}, flush=True)
