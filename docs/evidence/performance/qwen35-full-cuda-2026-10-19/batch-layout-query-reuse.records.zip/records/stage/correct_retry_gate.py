"""Require a completed original episode before sizing/updating a retained plan."""
from pathlib import Path
import difflib
import hashlib
import json

STAGE = Path(__file__).resolve().parent
ROOT = STAGE.parents[2]


def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def save(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8')


def identity(path):
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}


relative = 'src/compute_batch/batch_execution.cc'
target, overlay = ROOT / relative, STAGE / 'source' / relative
old = target.read_text(encoding='utf-8')
if target.read_bytes() != overlay.read_bytes():
    raise ValueError('Reviewed current source differs')
before = STAGE / 'before-retry-correction'
before.mkdir(exist_ok=False)
for path in (target, STAGE / 'source-freeze.json', STAGE / 'application.json', STAGE / 'changes.diff'):
    (before / path.name).write_bytes(path.read_bytes())
first = '  HYLE_ASSIGN_OR_RETURN(auto workspace_report,query_workspace(s,layout,update));'
second = '  if(update && !workspace_changed){'
if old.count(first) != 1 or old.count(second) != 1:
    raise ValueError('Expected original sizing and update gates')
new = old.replace(first, '''  // A completed preparation or retired run retains the original plan and
  // scratch. A partial preparation cleared both flags before any resize; its
  // retry must size and create a fresh plan, even if native metadata survived.
  const bool may_update=update && (s.prepared || s.ran);
  HYLE_ASSIGN_OR_RETURN(auto workspace_report,query_workspace(s,layout,may_update));''').replace(
    second, '  if(may_update && !workspace_changed){')
target.write_text(new, encoding='utf-8', newline='\n')
overlay.write_bytes(target.read_bytes())
freeze = read(STAGE / 'source-freeze.json')
row = next(row for row in freeze['files'] if row['target'] == relative)
row['after'] = identity(overlay)
diff = []
for row in freeze['files']:
    diff.extend(difflib.unified_diff(Path(row['before']['path']).read_text().splitlines(True),
        Path(row['after']['path']).read_text().splitlines(True), fromfile='a/' + row['target'], tofile='b/' + row['target']))
(STAGE / 'changes.diff').write_text(''.join(diff), encoding='utf-8', newline='\n')
freeze['diff'] = identity(STAGE / 'changes.diff')
freeze['retry_gate'] = 'Same may_update snapshot requires the original completed prepare or retired run for both sizing and update; partial preparation retries use fresh sizing and plan.'
save(STAGE / 'source-freeze.json', freeze)
application = read(STAGE / 'application.json')
row = next(row for row in application['files'] if Path(row['path']) == target)
row['after_sha256'] = identity(target)['sha256']
application['retry_gate'] = freeze['retry_gate']
save(STAGE / 'application.json', application)
print('RETRY_GATE_CORRECTED', identity(target)['sha256'], flush=True)
