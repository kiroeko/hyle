"""Prepare a separate correction from the already applied workspace test."""
from pathlib import Path
import difflib
import hashlib
import json

STAGE=Path(__file__).resolve().parent
ROOT=STAGE.parents[2]
name='tests/compute_batch/workspace_test.cc'
before=(ROOT/name).read_bytes()
assert hashlib.sha256(before).hexdigest()=='bb66fe998daf39794ef8ecec30eb226914f0997f2d3b0091146c49edb78d25b9'
archive=STAGE/'retry-correction'
for source,relative in [(ROOT/name,'before/'+name),
                        (STAGE/'tests-source-freeze.json','original-tests-source-freeze.json'),
                        (STAGE/'workspace-tests-source-freeze.json','original-workspace-tests-source-freeze.json'),
                        (STAGE/'test-recipes.json','original-test-recipes.json')]:
    target=archive/relative
    target.parent.mkdir(parents=True,exist_ok=True)
    assert not target.exists(),str(target)
    target.write_bytes(source.read_bytes())
text=before.decode('utf-8').replace('\r\n','\n')
text=text.replace('#include <gtest/gtest.h>','#include <gtest/gtest.h>\n#include "allocation_fault_fixture.h"',1)
new_test=r'''
TEST(BatchWorkspace, ScratchGrowOomForcesFreshSizingAndPlanOnRetry){
  hyle_f5_fault_fixture::Allocator fault;
  {
    Mock mock;mock.permit_reuse=true;
    const auto storage=c::CacheStorage::plain(c::DataType::kFloat16).value();
    auto schema=c::BatchSchema::create({.storage=c::BatchStorage::kRagged,.query_type=c::DataType::kFloat16,.output_type=c::DataType::kFloat16,
        .key_storage=storage,.value_storage=storage,.max_requests=1,.max_query_rows=1,.max_kv_rows=1,.max_pages=0,.max_page_refs=0,
        .query_heads=1,.kv_heads=1,.qk_head_dim=64,.value_head_dim=64,.page_size=1}).value();
    auto context=c::Context::create(c::cpu::device(),mock.provider()).value();auto queue=context.create_queue().value();
    auto program=c::BatchProgram::prepare(context,schema,{.resource=m::system_resource(),.host_workspace=m::system_resource(),
        .max_float_workspace_bytes=4096,.max_int_workspace_bytes=2048,.allocator=fault.ref()}).value();
    auto slot=c::BatchInvocation::create(program,queue).value();
    const std::array<std::int32_t,2> offsets{0,1};const auto layout=schema.version({offsets,offsets,{},{}}).value();
    auto pool=c::LeasePool::create(m::system_resource(),1024).value();std::array<c::ReadLease,3> inputs;
    for(auto&input:inputs){auto writer=pool.allocate(128).value();ASSERT_TRUE(writer.view()->fill(std::byte{0}).ok());input=writer.publish().value();}
    auto initial=slot.prepare_batch(layout);ASSERT_TRUE(initial)<<initial.error().message();
    auto first=initial->run(inputs);ASSERT_TRUE(first)<<first.error().message();ASSERT_TRUE(first->wait().ok());
    *first={};*initial={};EXPECT_EQ(mock.plans,1u);EXPECT_EQ(mock.updates,0u);
    mock.float_bytes=3072;
    // Same metadata means the next injected metadata allocation is precisely
    // the growing scratch LeasePool, after the old floating lease was reset.
    const auto target=fault.attempts;fault.fail=target;
    auto failed=slot.prepare_batch(layout);fault.fail=SIZE_MAX;
    ASSERT_FALSE(failed);EXPECT_TRUE(failed.error().IsResourceExhausted());
    EXPECT_EQ(fault.attempts,target+1);EXPECT_FALSE(mock.last_allow_update);
    EXPECT_EQ(mock.plans,1u);EXPECT_EQ(mock.updates,0u);
    const auto fresh=mock.fresh_queries,updates=mock.update_queries;
    auto retried=slot.update_batch(layout);ASSERT_TRUE(retried)<<retried.error().message();
    EXPECT_FALSE(mock.last_allow_update);EXPECT_EQ(mock.fresh_queries,fresh+1);EXPECT_EQ(mock.update_queries,updates);
    EXPECT_EQ(mock.updates,0u);EXPECT_EQ(mock.plans,2u);EXPECT_FALSE(slot.report().reused_native_plan);
    EXPECT_EQ(slot.report().float_workspace_bytes,3072u);
    auto second=retried->run(inputs);ASSERT_TRUE(second)<<second.error().message();ASSERT_TRUE(second->wait().ok());
    {auto output=slot.output().value();std::array<std::byte,128> bytes;ASSERT_TRUE(output.view()->read(bytes).ok());
      for(auto value:bytes)EXPECT_EQ(value,std::byte{7});}
    *second={};*retried={};EXPECT_EQ(mock.runs,2u);ASSERT_TRUE(slot.close().ok());ASSERT_TRUE(context.drain().ok());
  }
  EXPECT_EQ(fault.live,0u);
}
'''
text=text.rsplit('\n}',1)[0]+'\n'+new_test+'\n}\n'
after=text.encode('utf-8')
target=STAGE/'test-overlay'/name
target.write_bytes(after)
(archive/'changes.diff').write_text(''.join(difflib.unified_diff(before.decode('utf-8').splitlines(True),text.splitlines(True),fromfile='a/'+name,tofile='b/'+name)),encoding='utf-8')
record={'state':'Scratch correction only; not applied, compiled, or run.',
        'files':[{'path':name,'before_sha256':hashlib.sha256(before).hexdigest(),
                  'after_sha256':hashlib.sha256(after).hexdigest(),'bytes':len(after),'overlay':str(target)}],
        'filter':'BatchWorkspace.ScratchGrowOomForcesFreshSizingAndPlanOnRetry',
        'scope':'One next-allocation fault after same-layout forced scratch growth; retry must query fresh and skip native update. The pre-mutation-cap test and real native query counter fixture remain unchanged.'}
(archive/'source-freeze.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
print(json.dumps(record,indent=2))
