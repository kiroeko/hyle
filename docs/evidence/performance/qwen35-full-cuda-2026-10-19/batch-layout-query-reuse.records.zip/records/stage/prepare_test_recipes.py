"""Freeze only the scratch test closure; never compile or change product files."""
from pathlib import Path
import hashlib
import json

STAGE=Path(__file__).resolve().parent
ARCH=STAGE.parent
ROOT=ARCH.parents[1]

def identity(path):
    path=Path(path)
    data=path.read_bytes()
    return dict(path=str(path),bytes=len(data),sha256=hashlib.sha256(data).hexdigest())

def load(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))

def recipe(tag,source,base,extra=(),overlay=None):
    row=load(base)
    command=[]
    old_source=Path(row['source']['path'])
    skip_next=False
    for arg in row['command']:
        if skip_next:
            skip_next=False
            continue
        if arg.lower()=='/sourcedependencies':
            skip_next=True
            continue
        if arg.lower().startswith(('/fo','/fd')):
            continue
        command.append(str(source) if arg.casefold()==str(old_source).casefold() else arg)
    command.extend(extra)
    command.extend(['/sourceDependencies',str(STAGE/'recipes'/f'{tag}-deps.json'),'/Fo'+str(STAGE/'recipes'/f'{tag}.obj')])
    actual=identity(overlay or source)
    actual['path']=str(source)
    result=dict(tag=tag,source=actual,command_template=command,recipe=identity(base))
    if overlay:result['overlay']=identity(overlay)
    return result

ops=ARCH/'recurrent-gdn-schema/checks/20261019T113131/29-ops-test-identity.json'
cuda=ARCH/'recurrent-gdn-schema/checks/20261019T113131/25-compute_provider_ggml_cuda-tensor_test-identity.json'
fi=ARCH/'recurrent-gdn-schema/checks/20261019T113131/18-compute_provider_flashinfer-flashinfer_provider-identity.json'
support=STAGE/'test-support'
rows=[
    recipe('workspace-test',ROOT/'tests/compute_batch/workspace_test.cc',ops,
           overlay=STAGE/'test-overlay/tests/compute_batch/workspace_test.cc'),
    recipe('native-query-wrapper',support/'native_query_observer.cc',fi,
           ['/I'+str(support)]),
    recipe('native-query-test',support/'workspace_query_test.cc',cuda,
           ['/I'+str(support),'/I'+str(ROOT/'tests/compute_provider_native')]),
]
record=dict(state='Scratch-only command preparation; no compile, link, GPU, or product change.',compile=rows,
    test_provider_definitions=['/Dquery_batch_workspace=observed_query_batch_workspace',
                               '/Dquery_mla_workspace=observed_query_mla_workspace'],
    provider_rule='Apply both definitions ONLY to the CUDA test provider object. Do not apply to wrapper/native CUDA objects or production Qwen.',
    filters={'cpu':'BatchWorkspace.*',
             'cuda':'FlashinferWorkspaceQuery.ReuseSkipsNativeSizingButForcedAndChunkChangedPlansQuery'},
    expected_observation='Two storage domains, five real prepare/run episodes each: cold query; reusable KV growth with zero query; forced fresh query; chunk-boundary fallback query; same-chunk growth with zero query. Each run checked against zero-Q/K uniform-attention oracle.',
    private_boundaries=[identity(ROOT/'src/compute_provider_flashinfer/native_batch.h')],
    counter_scope='Scratch wrapper has thread_local counters on the synchronous host query boundary. It always delegates to unchanged native functions; no timing inference, product globals, or test-only public API.')
(STAGE/'test-recipes.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
files=[STAGE/'test-overlay/tests/compute_batch/workspace_test.cc',
       support/'native_query_observer.h',support/'native_query_observer.cc',support/'workspace_query_test.cc']
freeze=dict(state='Frozen scratch tests; not compiled.',files=[identity(path) for path in files],
            recipes=identity(STAGE/'test-recipes.json'))
(STAGE/'tests-source-freeze.json').write_text(json.dumps(freeze,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'recipes':identity(STAGE/'test-recipes.json'),'freeze':identity(STAGE/'tests-source-freeze.json')},indent=2))
