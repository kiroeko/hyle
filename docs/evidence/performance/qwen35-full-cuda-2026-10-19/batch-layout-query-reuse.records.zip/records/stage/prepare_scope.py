"""Find actual linked owners of the private batch capability header; no build."""
from pathlib import Path
import importlib.util
import json
import re
import sys

sys.dont_write_bytecode = True
STAGE = Path(__file__).resolve().parent
ARCH = STAGE.parent
ROOT = ARCH.parents[1]
spec = importlib.util.spec_from_file_location('batch_scope_helpers', ARCH / 'cuda-fusion-allocation/build.py')
prior = importlib.util.module_from_spec(spec)
spec.loader.exec_module(prior)
b, c = prior.b, prior.c
HEADER = ROOT / 'include/hyle/compute/detail/batch_provider.h'
BASES = {'cpu': ARCH / 'recurrent-gdn-schema/checks/20261019T113131/cpu-link-plan.json',
         'cuda': ARCH / 'cuda-fusion-allocation/checks/20261019T115201/cuda-link-plan.json',
         'qwen': ARCH / 'cuda-fusion-allocation/checks/20261019T115201/qwen-link-plan.json'}


def hyle_headers(source, command):
    include_roots = [ROOT / 'include', ROOT]
    for arg in command:
        for prefix in ('/external:i', '/i'):
            if arg.lower().startswith(prefix):
                include_roots.append(Path(arg[len(prefix):]))
                break
    seen, pending = {}, [Path(source)]
    while pending:
        path = pending.pop().resolve()
        if c.key(path) in seen or not path.is_file():
            continue
        seen[c.key(path)] = path
        for name in re.findall(r'^\s*#\s*include\s*[<"]([^>"\n]+)[>"]', path.read_text(encoding='utf-8-sig'), re.M):
            target = next((p / name for p in [path.parent, *include_roots] if (p / name).is_file()), None)
            if target and any(target.resolve().is_relative_to(ROOT / prefix) for prefix in ('src', 'include', 'tests')):
                pending.append(target)
    return list(seen.values())


def main():
    inventory_path = ARCH / 'immutable-constant-alias/object-inventory.json'
    original = {c.key(row['object']): row for row in c.read(inventory_path)['objects']}
    linked, membership = {}, {}
    for name, path in BASES.items():
        linked[name] = c.read(path)
        for row in linked[name]['inputs']:
            if Path(row['path']).suffix.lower() == '.obj':
                entry = membership.setdefault(c.key(row['path']), {'object': row, 'closures': []})
                entry['closures'].append(name)
    owners, unresolved, observations = [], [], []
    for objkey, entry in membership.items():
        obj = Path(entry['object']['path'])
        receipt = obj.with_name(obj.stem + '-identity.json')
        old = original.get(objkey)
        recipe, source, command = None, None, None
        if receipt.exists():
            row = c.read(receipt)
            source = row.get('source')
            source = source.get('path') if isinstance(source, dict) else source
            command = row.get('command')
            recipe = receipt
        if old and not command:
            source, command, recipe = old.get('source'), old.get('command'), Path(old['recipe']) if old.get('recipe') else None
            source = source.get('path') if isinstance(source, dict) else source
        if command and not source:
            source = next((arg for arg in command if arg.lower().endswith(('.cc', '.cpp', '.cu', '.c'))), None)
        if not source or not command:
            unresolved.append(entry)
            continue
        deps = []
        if old:
            deps.extend(x.get('path') if isinstance(x, dict) else x for x in old.get('headers', []))
        for i, arg in enumerate(command[:-1]):
            if arg.lower() == '/sourcedependencies' and Path(command[i + 1]).is_file():
                deps.extend(c.read(command[i + 1]).get('Data', {}).get('Includes', []))
        # Even when an old MSVC dependency file was removed, traverse literal
        # local includes conservatively, without preprocessing away domains.
        current = hyle_headers(source, command) if Path(source).suffix.lower() in ('.cc', '.cpp') else []
        owns = c.key(HEADER) in {c.key(path) for path in deps if path} | {c.key(path) for path in current}
        observations.append({'object': entry['object'], 'source': source, 'owns_header': owns})
        if owns:
            if Path(source).suffix.lower() not in ('.cc', '.cpp'):
                raise ValueError('Unexpected native owner needs review: ' + source)
            owners.append({**entry, 'source': source, 'command_template': command,
                'recipe': b.identity(recipe), 'local_headers': [b.identity(path) for path in current],
                'actual_dependency_contains_header': c.key(HEADER) in {c.key(path) for path in deps if path}})
    known_path = ARCH / 'recurrent-gdn-schema/unresolved-review.json'
    known = {c.key(row['path']): row for row in c.read(known_path)['resolved_nonowners']}
    resolved, missing = [], []
    for entry in unresolved:
        row = known.get(c.key(entry['object']['path']))
        if not row or row['object'] != entry['object'] or not b.same(row['source']):
            missing.append(entry)
            continue
        if any(c.key(item['path']) == c.key(HEADER) for item in row['include_closure_files']):
            raise ValueError('Unresolved object actually includes changed header')
        resolved.append({**entry, 'source': row['source'], 'classification': row['classification'],
                         'retained_include_closure': row['include_closure_files'], 'evidence': b.identity(known_path)})
    result = {'state': 'Offline source/recipe/dependency inventory; not compiled.',
        'header': b.identity(HEADER), 'bases': {name: b.identity(path) for name, path in BASES.items()},
        'owners': owners, 'resolved_nonowners': resolved, 'unresolved': missing, 'observations': observations,
        'old_object_inventory': b.identity(inventory_path)}
    c.save(STAGE / 'header-owners.json', result)
    print('HEADER_OWNERS', len(owners), 'RESOLVED_NONOWNERS', len(resolved), 'UNRESOLVED', len(missing), flush=True)
    for row in owners:
        print(','.join(row['closures']), Path(row['source']).relative_to(ROOT), flush=True)
    for row in missing:
        print('UNRESOLVED', row['object']['path'], flush=True)


if __name__ == '__main__':
    main()
