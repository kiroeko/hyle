"""Apply only the reviewed three production files and workspace regression."""
from pathlib import Path
import hashlib
import json

STAGE = Path(__file__).resolve().parent
ROOT = STAGE.parents[2]


def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def sha(data):
    return hashlib.sha256(data).hexdigest()


rows = []
for row in read(STAGE / 'source-freeze.json')['files']:
    target, proposed = Path(row['origin']['path']), Path(row['after']['path'])
    if sha(target.read_bytes()) != row['origin']['sha256'] or sha(proposed.read_bytes()) != row['after']['sha256']:
        raise ValueError('Reviewed source differs: ' + str(target))
    rows.append((target, proposed, row['origin']['sha256'], row['after']['sha256']))
for row in read(STAGE / 'workspace-tests-source-freeze.json')['files']:
    target, proposed = ROOT / row['path'], STAGE / 'test-overlay' / row['path']
    if sha(target.read_bytes()) != row['before_sha256'] or sha(proposed.read_bytes()) != row['after_sha256']:
        raise ValueError('Reviewed regression differs')
    rows.append((target, proposed, row['before_sha256'], row['after_sha256']))
receipt = []
for target, proposed, before, after in rows:
    original = STAGE / 'before-apply' / target.relative_to(ROOT)
    original.parent.mkdir(parents=True, exist_ok=True)
    original.write_bytes(target.read_bytes())
    target.write_bytes(proposed.read_bytes())
    receipt.append({'path': str(target), 'before_sha256': before, 'after_sha256': after})
(STAGE / 'application.json').write_text(json.dumps({'files': receipt, 'built': False}, indent=2) + '\n', encoding='utf-8')
print('APPLIED', len(receipt), flush=True)
