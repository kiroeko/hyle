"""Archive the tested batch-layout sizing reuse increment, without binary caches."""
from pathlib import Path
import hashlib
import json
import xml.etree.ElementTree as ET
import zipfile

STAGE=Path(__file__).resolve().parent
ARCH=STAGE.parent
ROOT=STAGE.parents[2]
PLAN=STAGE/'checks/20261019T120828-test-define/plan.json'
DEST=ROOT/'docs/evidence/performance/qwen35-full-cuda-2026-10-19/batch-layout-query-reuse.zip'
EXCLUDED={'.exe','.obj','.pdb','.lib','.exp','.dll','.pyc','.map','.tmp','.zip'}
DOCS=('docs/architecture/compute-design.md','docs/developer/current-work.md',
      'docs/evidence/performance/qwen35-full-cuda-2026-10-19/README.md')
SUPPORT=('cuda-fusion-allocation/build.py','recurrent-gdn-schema/build.py',
         'immutable-alias-index/build.py','cuda-fusion-precision/build.py',
         'cuda-fusion-layout/build.py','cuda-gdn-l2-epilogue/build.py',
         'cuda-explicit-rope/build.py','cuda-bf16-dual-projection/build_current.py',
         'cuda-projection-fusion/build.py','cold-constant-retirement/cold_check.py',
         'cuda-bf16-dual-projection/compare_numerics.py',
         'cuda-bf16-dual-projection/compare_three_dual.py')
WRAP_DEFINES=('/Dquery_batch_workspace=observed_query_batch_workspace',
              '/Dquery_mla_workspace=observed_query_mla_workspace')


def sha(data):
    return hashlib.sha256(data).hexdigest()


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def key(path):
    return str(Path(path).resolve()).casefold()


def identity(path):
    path=Path(path).resolve()
    data=path.read_bytes()
    return dict(path=str(path),bytes=len(data),sha256=sha(data))


def verify(row):
    actual=identity(row['path'])
    if any(actual[field]!=row[field] for field in ('path','bytes','sha256')):
        raise ValueError('Frozen source/evidence drift: '+row['path'])
    return Path(row['path']).resolve()


def main():
    if DEST.exists():
        raise ValueError('Archive exists; refusing replacement')
    plan=read(PLAN)
    build=read(PLAN.parent/'summary.json')
    if not build['passed'] or (build['host_TUs'],build['fresh_host_TUs_this_resume'],
            build['reused_successful_host_TUs'],build['native_TUs'])!=(13,2,11,0):
        raise ValueError('Expected thirteen-host final closure with eleven reused successes')
    if len(plan['compile'])!=13 or not plan['instrumentation_is_test_only']:
        raise ValueError('Unexpected host or instrumentation scope')
    if plan['native_TUs'] or plan['SDK_build']:
        raise ValueError('Unexpected native/SDK build')
    original=verify(plan['original_failed_plan'])
    failed_path=original.parent/'native-query-test-compile.result.json'
    failed=read(failed_path)
    if not failed.get('terminal') or failed['exit']==0:
        raise ValueError('Original missing test capability definition failure not retained')

    application=read(STAGE/'application.json')
    if len(application['files'])!=4:
        raise ValueError('Expected three production files plus the workspace regression TU')
    for row in application['files']:
        if identity(row['path'])['sha256']!=row['after_sha256']:
            raise ValueError('Applied product/test source drift')
    freeze=read(STAGE/'source-freeze.json')
    if len(freeze['files'])!=3:
        raise ValueError('Expected the three-file provider/controller/header change')
    for row in freeze['files']:
        verify(row['before']);verify(row['after'])
        if identity(ROOT/row['target'])['sha256']!=row['after']['sha256']:
            raise ValueError('Final reviewed source differs from product')
    tests=read(STAGE/'tests-source-freeze.json')
    if len(tests['files'])!=4:
        raise ValueError('Expected workspace test plus three scratch observer files')
    for row in tests['files']:
        verify(row)
    if identity(ROOT/'tests/compute_batch/workspace_test.cc')['sha256']!=tests['files'][0]['sha256']:
        raise ValueError('Final applied workspace fixture differs')
    for correction in ('retry-correction/source-freeze.json','fixture-correction/source-freeze.json'):
        for row in read(STAGE/correction)['files']:
            target=ROOT/row['path'] if not Path(row['path']).is_absolute() else Path(row['path'])
            if identity(target)['sha256']!=row['after_sha256']:
                raise ValueError('Final fixture correction differs')

    files={}
    expected={}

    def add(name,path,row=None):
        path=Path(path).resolve()
        if path.suffix.lower() in EXCLUDED or any(part in ('tmp','__pycache__') for part in path.parts):
            return
        if not path.is_relative_to(ROOT) or not path.is_file() or path.is_symlink():
            raise ValueError('Unexpected external, missing, or symlink payload: '+str(path))
        if name in files and files[name]!=path:
            raise ValueError('Duplicate archive entry: '+name)
        files[name]=path
        if row:expected[name]=row

    for row in plan['frozen']:
        path=Path(row['path']).resolve()
        if path.suffix.lower() in EXCLUDED:
            continue
        verify(row)
        if not path.is_relative_to(STAGE):
            add('tested-inputs/'+path.relative_to(ROOT).as_posix(),path,row)
    header=ROOT/'include/hyle/compute/detail/batch_provider.h'
    compiled=[]
    for row in plan['compile']:
        source=verify(row['source'])
        obj=Path(row['object'])
        receipt_path=obj.parent/(row['tag']+'-identity.json')
        receipt=read(receipt_path)
        if receipt['source']!=row['source'] or receipt['command']!=row['command']:
            raise ValueError('Actual compile recipe/source differs: '+row['tag'])
        result_path=obj.parent/(row['tag']+'-compile.result.json')
        result=read(result_path)
        if not result.get('terminal') or result['exit']!=0:
            raise ValueError('Missing successful actual owner compile: '+row['tag'])
        deps_path=obj.parent/(row['tag']+'-deps.json')
        deps=read(deps_path)['Data']
        if key(deps['Source'])!=key(source):
            raise ValueError('Actual source dependency owner differs')
        if row.get('header_owner') and key(header) not in {key(path) for path in deps['Includes']}:
            raise ValueError('Refreshed owner missed the new private ABI header')
        instrumented=[definition in row['command'] for definition in WRAP_DEFINES]
        if instrumented!=([True,True] if row['tag']=='fi-probe' else [False,False]):
            raise ValueError('Private native-query substitution escaped the test provider')
        compiled.append(dict(tag=row['tag'],source=row['source'],recipe=identity(receipt_path),
                             dependencies=identity(deps_path),object=receipt['object']))
        if not source.is_relative_to(STAGE):
            add('tested-inputs/'+source.relative_to(ROOT).as_posix(),source,row['source'])

    checks=read(PLAN.parent/'checks-summary.json')
    if not checks['passed'] or checks['different_cases']!=5 or not checks['actual_native_query_observed']:
        raise ValueError('Missing five real related cases/native query observation')
    for arm,count in (('cpu',4),('query-probe',1)):
        report=checks['reports'][arm]
        if report!={'passed':True,'tests':count,'failures':0,'disabled':0,'errors':0,'skipped':0}:
            raise ValueError('Expected all actual cases without skips')
        xml=ET.parse(PLAN.parent/('run-'+arm)/'result.xml').getroot()
        cases=xml.findall('.//testcase')
        if len(cases)!=count or any(case.findall('skipped') or case.findall('failure') or
                case.get('status')!='run' or case.get('result')!='completed' for case in cases):
            raise ValueError('Actual XML does not prove completed non-skipped cases')
    model=read(STAGE/'correctness/summary.json')
    numeric=read(STAGE/'correctness/analysis.json')
    if not model['passed'] or numeric['equal_vectors']!=64 or not numeric['all_outputs_finite']:
        raise ValueError('Missing sixty-four exact finite model vectors')
    for row in numeric['vectors']:
        verify(row['actual'])
        if not row['byte_equal'] or (row['actual']['bytes'],row['actual']['sha256'])!=(row['reference']['bytes'],row['reference']['sha256']):
            raise ValueError('Model vector comparison record differs')

    images={}
    counts={'cpu':115,'cuda':133,'qwen':125,'query-probe':135}
    for arm,count in counts.items():
        link=read(PLAN.parent/(arm+'-link-plan.json'))
        if len(link['inputs'])!=count or len({key(row['path']) for row in link['inputs']})!=count:
            raise ValueError('Actual link closure differs: '+arm)
        images[arm]=read(PLAN.parent/(arm+'-image.json'))
        verify(images[arm])
    instrumented_obj=next(row['object'] for row in plan['compile'] if row['tag']=='fi-probe')
    production_obj=next(row['object'] for row in plan['compile'] if row['tag']=='08-compute_provider_flashinfer-flashinfer_provider')
    for arm in ('qwen','cuda'):
        inputs={key(path) for path in plan['links'][arm]['inputs']}
        if key(instrumented_obj) in inputs or key(production_obj) not in inputs:
            raise ValueError('Production link accidentally uses the test observer provider')

    perf=read(STAGE/'performance-rotation/summary.json')
    runs=read(STAGE/'performance-rotation/runs.json')
    if perf['terminal_zero']!=9 or len(runs)!=9 or any(row['exit']!=0 for row in runs):
        raise ValueError('Nine-process rotated performance observations are incomplete')
    if perf['profiler'] or perf['statistical_significance'] or perf['independent_quality_acceptance']:
        raise ValueError('Unexpected broader acceptance/performance claim')
    for row in runs:
        actual=read(STAGE/'performance-rotation'/(row['tag']+'.result.json'))
        if not actual.get('terminal') or actual['exit']!=0:
            raise ValueError('Missing actual terminal rotated process result')
    for relative in SUPPORT:
        path=ARCH/relative
        add('replay-support/'+path.relative_to(ROOT).as_posix(),path)
    for relative in DOCS:
        add('documentation/'+relative,ROOT/relative)
    if (ROOT/'test.ps1').is_file():
        add('cleanup-plan/test.ps1',ROOT/'test.ps1')

    scope=dict(final_applied_files=application['files'],host_TUs=13,fresh_after_test_define_correction=2,
        retained_successful_host_TUs=11,native_TUs=0,SDK_build=False,actual_link_inputs=counts,
        compiled_source_and_command_receipts=compiled,tested_images=images,
        tests={'cpu':4,'native_query_probe':1,'failures':0,'skips':0},
        actual_native_query_probe={'storage':['ragged','paged'],'episodes_per_storage':5,
            'rows':[64,96,96,129,130],'update_intent':[False,True,False,True,True],
            'expected_native_query':['positive','zero','positive','positive','zero'],
            'proof':'Scratch-only query-symbol wrapper delegates to original native scheduler; all ten actual runs check the independent uniform-attention oracle.'},
        force_fresh_counterexample='An unchanged old-plan chunk count does not bound freshly selected scheduler workspace; allow_update=false always queries fresh.',
        retry_boundary='A single retired prepare/run snapshot controls both sizing and update; partial scratch-growth failure clears both episode flags and retries fresh.',
        preserved_corrections=['Initial freeze and before-apply source','Same-layout scratch-growth metadata OOM regression',
            'Static pre-build exact referenced-page guard correction','First test compile missing HYLE_COMPUTE_FLASHINFER and the original terminal command/log',
            'Resume compiled only two test-related owners; eleven successful owners reused'],
        failed_test_compile={'path':str(failed_path),'exit':failed['exit']},
        model_equal_vectors=64,model_quality_acceptance=False,MLA_runtime_verified=False,
        cross_platform_runtime_verified=False,performance_processes=9,
        performance_groups=perf['groups'],performance_limits=perf['limits'],
        stable_decode_improvement_proven=False,profiler=False,external_memory_monitor=False,
        runtime_boundaries_preserved=['CPU and query probe use actual independent link-input environments',
            'Production Qwen/CUDA provider is not instrumented','All nine throughput processes unprofiled',
            'Load/context preparation differ between engines; raw metric contracts retained',
            'One fixed-input 128+31 sequence and 64 exact vectors are not general model-quality acceptance'],
        historical_not_built_states='Earlier preparation/source-freeze/application state labels are retained verbatim; the two build plans and final actual receipts establish the tested state.',
        documentation_context=list(DOCS),other_unapplied_batch_drafts_included=False,
        SDK_models_objects_executables_maps_tmp_excluded=True,cleanup_plan_not_executed_at_archive_time=True)
    (STAGE/'archive-scope.json').write_text(json.dumps(scope,indent=2)+'\n',encoding='utf-8')
    for path in sorted(STAGE.rglob('*')):
        if path.is_symlink():
            raise ValueError('Unexpected stage symlink')
        if path.name=='archive-verification.json':
            raise ValueError('Unexpected existing archive receipt')
        if path.is_file():
            add('stage/'+path.relative_to(STAGE).as_posix(),path)
    records=[]
    DEST.parent.mkdir(parents=True,exist_ok=True)
    with zipfile.ZipFile(DEST,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as archive:
        for name,path in sorted(files.items()):
            data=path.read_bytes()
            record=dict(entry=name,source=str(path),bytes=len(data),sha256=sha(data))
            frozen=expected.get(name)
            if frozen and (record['bytes'],record['sha256'])!=(frozen['bytes'],frozen['sha256']):
                raise ValueError('Frozen payload drift while archiving')
            records.append(record)
            archive.writestr(name,data)
        archive.writestr('manifest.json',json.dumps(records,indent=2)+'\n')
    with zipfile.ZipFile(DEST) as archive:
        if archive.testzip() is not None or len(archive.namelist())!=len(records)+1:
            raise ValueError('ZIP CRC or entry count differs')
        for row in records:
            data=archive.read(row['entry'])
            if len(data)!=row['bytes'] or sha(data)!=row['sha256']:
                raise ValueError('Payload SHA/length differs')
        if any(Path(name).suffix.lower() in EXCLUDED or any(part in ('tmp','__pycache__') for part in Path(name).parts)
               for name in archive.namelist()):
            raise ValueError('Excluded binary/SDK cache payload in archive')
    receipt=dict(path=str(DEST),sha256=sha(DEST.read_bytes()),bytes=DEST.stat().st_size,
        payloads=len(records),entries_including_manifest=len(records)+1,
        uncompressed_payload_bytes=sum(row['bytes'] for row in records),
        CRC_and_every_payload_SHA_verified=True,host_TUs=13,native_TUs=0,
        fresh_host_TUs_after_test_define=2,reused_successful_host_TUs=11,
        tests=5,model_equal_vectors=64,performance_terminal_zero=9,
        stable_decode_improvement_proven=False,production_provider_is_uninstrumented=True,
        source_retry_fixture_and_failed_compile_corrections_preserved=True,
        SDK_models_objects_executables_maps_tmp_excluded=True,other_unapplied_batch_drafts_excluded=True)
    text=json.dumps(receipt,indent=2)+'\n'
    (STAGE/'archive-verification.json').write_text(text,encoding='utf-8')
    DEST.with_name('batch-layout-query-reuse-archive.json').write_text(text,encoding='utf-8')
    print(text,flush=True)


if __name__=='__main__':
    main()
