"""Archive the completed caller-workspace slice without its rebuildable payloads."""
from pathlib import Path
import hashlib
import json
import re
import subprocess
import zipfile
import zlib

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]
TESTS = OUT.parent / "ggml-cuda-caller-workspace-tests"
DEST = ROOT / "docs/evidence/performance/qwen35-full-cuda-2026-10-19/ggml-cuda-caller-workspace.zip"
EXCLUDED = {".obj", ".exe", ".map", ".lib", ".exp", ".pdb", ".dll", ".so", ".a", ".o", ".zip", ".pyc"}
ALLOWED = {".py", ".json", ".log", ".cc", ".cpp", ".h", ".diff", ".xml", ".txt", ".md", ".f32", ".bf16", ".ps1", ".tsv", ".csv"}
HEADER = "include/hyle/compute/providers/ggml_cuda.h"


def read(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def digest(data):
    return {"bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}


def code_without_comment_lines(data):
    # This exact header changed only complete // comment lines. Preserve all
    # remaining C++/preprocessor bytes except whitespace for the comparison.
    lines = [line for line in data.decode("utf-8").splitlines() if not line.lstrip().startswith("//")]
    return re.sub(r"\s+", "", "\n".join(lines)).encode("utf-8")


assert not DEST.exists(), str(DEST)
summary = read(OUT / "summary.json")
assert summary["sampled_peak_gpu_saving_bytes"] == 1438658560
assert all(row["all_byte_identical"] and row["vectors"] == 64
           for row in summary["decision_vector_parity"].values())
tests = read(TESTS / "summary.json")
assert tests["test_count"] == 10 and tests["run"]["exit"] == 0
workspace_test = next(row for row in tests["run"]["results"]
                      if row["name"] == "OrderedNativeRegionsShareCallerWorkspace")
assert workspace_test["properties"] == {
    "first_native_workspace_bytes": "8388608",
    "second_native_workspace_bytes": "8388608",
    "graph_workspace_bytes": "16777216",
}

# Verify the frozen current closure without copying its SDK headers/objects.
closure = read(OUT / "closure-identities.json")
for row in closure["files"]:
    assert digest(Path(row["path"]).read_bytes()) == {key: row[key] for key in ("bytes", "sha256")}, row["path"]

dependencies = read(TESTS / "dependency-check.json")
assert dependencies["checked"] == 74 and dependencies["drift"] == []
drift = []
for row in dependencies["rows"]:
    current = digest(Path(row["path"]).read_bytes())
    expected = {key: row[key] for key in ("bytes", "sha256")}
    if current != expected:
        drift.append({"path": row["path"], "tested": expected, "current": current})
assert len(drift) == 1 and Path(drift[0]["path"]).resolve() == (ROOT / HEADER).resolve(), drift
tested_header = subprocess.run(
    ["git", "show", "HEAD:" + HEADER], cwd=ROOT,
    check=True, capture_output=True,
).stdout
assert digest(tested_header) == drift[0]["tested"]
current_header = (ROOT / HEADER).read_bytes()
assert code_without_comment_lines(tested_header) == code_without_comment_lines(current_header)
comment_note = {
    "scope": "The public header comment was updated after the 74-dependency test snapshot.",
    "tested_header": drift[0]["tested"],
    "current_header": drift[0]["current"],
    "only_changed_test_dependency": HEADER,
    "code_comparison": "All non-comment-line C++/preprocessor text is identical after whitespace normalization.",
    "code_sha256": hashlib.sha256(code_without_comment_lines(current_header)).hexdigest(),
    "test_snapshot_recompiled_after_comment": False,
    "note": "The archived original drift0 receipt describes the tested bytes, not the later comment byte identity. No code or ABI difference is inferred from this comment edit.",
}

entries = []
payloads = {}
canonical = {}


def add(name, source, data=None):
    value = Path(source).read_bytes() if data is None else data
    identity = digest(value)
    key = (identity["bytes"], identity["sha256"])
    stored = canonical.setdefault(key, name)
    if stored == name:
        payloads[name] = Path(source) if data is None else value
    entries.append({"name": name, "source": str(source), "stored_as": stored,
                    **identity, "crc32": f"{zlib.crc32(value) & 0xffffffff:08x}"})


for directory, prefix in [(OUT, "measurement"), (TESTS, "regression")]:
    for path in sorted(directory.rglob("*")):
        if not path.is_file() or "__pycache__" in path.parts or path.name == "archive-receipt.json":
            continue
        assert not path.is_symlink(), str(path)
        if path.suffix.lower() in EXCLUDED:
            continue
        assert path.suffix.lower() in ALLOWED, str(path)
        add(prefix + "/" + path.relative_to(directory).as_posix(), path)

product_sources = [
    "src/compute_provider_ggml_cuda/ggml_cuda_provider.cc",
    "src/compute_provider_ggml_cuda/program.h",
    "src/compute_provider_ggml_cuda/CMakeLists.txt",
    "src/graph_provider_ggml_cuda/ggml_cuda_region.cc",
    HEADER,
    "docs/architecture/compute-design.md",
    "docs/user/compute.md",
    "tests/graph_provider_ggml_cuda/region_test.cc",
]
direct_identities = read(OUT / "direct-tests/source-identities.json")
if isinstance(direct_identities, dict):
    direct_identities = direct_identities.get("files", direct_identities.get("sources", []))
for row in direct_identities:
    path = Path(row["path"])
    if not path.is_absolute():
        path = ROOT / path
    assert digest(path.read_bytes()) == {key: row[key] for key in ("bytes", "sha256")}, str(path)
    relative = path.relative_to(ROOT).as_posix()
    if relative not in product_sources:
        product_sources.append(relative)
for relative in product_sources:
    add("current-product/" + relative, ROOT / relative)
add("tested-snapshot/" + HEADER, "git HEAD:" + HEADER, tested_header)
add("post-test-comment-note.json", "generated from the tested dependency receipt and current header",
    (json.dumps(comment_note, indent=2) + "\n").encode("utf-8"))

references = {
    "excluded_payloads": "Images/maps/import libraries/objects/SDK/native math/weights and previous archives are referenced by the retained commands and identity receipts only.",
    "retained_current_objects": [row for row in closure["files"] if Path(row["path"]).suffix.lower() == ".obj"],
    "previous_liveness_archive": read(OUT.parent / "ggml-cuda-liveness/archive-receipt.json"),
    "prior_raw_vectors": "Before vectors remain in their original frozen stages/archives. Current parity JSON records the same logical files and their comparison; this archive does not follow external references or copy prior archives.",
    "no_cleanup": "No file was removed or moved during this archive task. Root owns subsequent exact test.ps1 reclamation.",
}
add("external-references.json", "generated external-only references",
    (json.dumps(references, indent=2) + "\n").encode("utf-8"))

raw = sum(row["bytes"] for row in entries)
unique = sum(len(value) if isinstance(value, bytes) else value.stat().st_size for value in payloads.values())
assert raw < 150 * 1024**2 and unique < 150 * 1024**2, (raw, unique)
manifest = {
    "schema": "hyle.ggml.cuda.caller-workspace.archive.v1",
    "scope": "Completed original ProviderPrepared caller-workspace integration, paired process measurements, 21/128 decision-byte parity and ten selected current CUDA regressions.",
    "entries": entries,
    "note": "Identical logical payloads are stored once. Each logical file has bytes/SHA256/CRC32 and a stored_as ZIP entry. Referenced external files and old archives are not copied.",
    "raw_logical_bytes": raw,
    "unique_payload_bytes": unique,
    "intentionally_excluded": sorted(EXCLUDED),
    "results_boundary": "Observed T128 peak saving is 1,438,658,560 B. Stable decode 77.469 -> 77.948 tokens/s is not claimed as a performance improvement. Same vectors on these two tapes do not establish general quality acceptance or full-model/platform coverage.",
    "post_test_comment": comment_note,
    "unchanged_architecture_limits": "Per-shape/per-slot backings, generated persistent inputs and native auxiliary pools/capture caches remain. No SDK or native mathematical kernel was rebuilt for this slice.",
}
manifest_bytes = (json.dumps(manifest, indent=2) + "\n").encode("utf-8")
assert unique + len(manifest_bytes) < 150 * 1024**2
with zipfile.ZipFile(DEST, "x", zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for name, source in payloads.items():
        data = source if isinstance(source, bytes) else source.read_bytes()
        archive.writestr(name, data)
    archive.writestr("manifest.json", manifest_bytes)
with zipfile.ZipFile(DEST) as archive:
    assert archive.testzip() is None
    assert len(archive.namelist()) == len(payloads) + 1
    assert len(set(archive.namelist())) == len(archive.namelist())
    for row in entries:
        data = archive.read(row["stored_as"])
        expected = {key: row[key] for key in ("bytes", "sha256")}
        assert digest(data) == expected, row["name"]
        assert f"{archive.getinfo(row['stored_as']).CRC:08x}" == row["crc32"], row["name"]
        if row["source"].startswith(str(ROOT)):
            assert digest(Path(row["source"]).read_bytes()) == expected, row["source"]
    zip_uncompressed_bytes = sum(row.file_size for row in archive.infolist())
zip_bytes = DEST.read_bytes()
receipt = {
    "destination": str(DEST), **digest(zip_bytes),
    "crc32": f"{zlib.crc32(zip_bytes) & 0xffffffff:08x}",
    "zip_entries": len(payloads) + 1,
    "logical_files": len(entries),
    "raw_logical_bytes": raw,
    "unique_payload_bytes": unique,
    "zip_uncompressed_bytes": zip_uncompressed_bytes,
    "identical_bytes_not_recopied": raw - unique,
    "manifest_sha256": hashlib.sha256(manifest_bytes).hexdigest(),
    "zip_crc_verified": True,
    "every_payload_sha256_verified": True,
    "source_drift": False,
    "tested_dependencies_checked": 74,
    "post_test_comment_only_dependency_changes": 1,
    "post_test_comment": comment_note,
    "copied_sdk_objects_images_weights_or_previous_archives": False,
    "deleted_files": 0,
}
(OUT / "archive-receipt.json").write_text(json.dumps(receipt, indent=2) + "\n", encoding="utf-8", newline="\n")
print(json.dumps(receipt, indent=2))
