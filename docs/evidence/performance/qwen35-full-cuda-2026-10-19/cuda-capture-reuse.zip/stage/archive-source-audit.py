"""Audit preserved source versions for this archive; never build, run or delete."""
from pathlib import Path
import difflib
import hashlib
import json
import zipfile

STAGE = Path(__file__).resolve().parent
ROOT = STAGE.parents[2]


def sha(data):
    return hashlib.sha256(data).hexdigest()


def read(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def record(path):
    data = path.read_bytes()
    return {"path": path.relative_to(STAGE).as_posix(),
            "bytes": len(data), "sha256": sha(data)}


def check_baselines(manifest, prefix):
    verified = []
    for row in read(manifest):
        path = STAGE / prefix / row["path"]
        actual = record(path)
        assert (actual["bytes"], actual["sha256"]) == (row["bytes"], row["sha256"]), str(path)
        verified.append(actual)
    return verified


def main():
    generic = check_baselines(STAGE / "generic/before-identities.json", "before")
    tests = check_baselines(STAGE / "before-identities.json", "before")
    root_paths = ["include/hyle/graph/cuda.h", "include/hyle/graph/detail/region_access.h",
                  "src/graph/region_access.cc", "src/graph_batch/batch.cc",
                  "tools/qwen35_text/main.cc", "src/compute_provider_ggml_cuda/ggml_cuda_provider.cc"]
    roots = [record(STAGE / "before" / name) for name in root_paths]
    # The older immutable archive additionally anchors the two root preimages
    # it actually contains. Missing entries are reported, never invented.
    old = ROOT / "docs/evidence/performance/qwen35-full-cuda-2026-10-19/cuda-coarse-capture.zip"
    anchors = []
    with zipfile.ZipFile(old) as prior:
        for name in root_paths:
            data = (STAGE / "before" / name).read_bytes()
            matches = [entry.filename for entry in prior.infolist()
                       if entry.filename.endswith("/" + name) and prior.read(entry) == data]
            anchors.append({"source": name, "matching_prior_entries": matches,
                            "prior_anchor_available": bool(matches)})
    out = STAGE / "archive-source"
    out.mkdir(exist_ok=True)
    final = []
    diff = []
    for name in root_paths:
        path = ROOT / name
        data = path.read_bytes()
        target = out / "root-current" / name
        target.parent.mkdir(parents=True, exist_ok=True)
        if target.exists():
            assert target.read_bytes() == data, "refresh explicitly after a source change: " + name
        else:
            target.write_bytes(data)
        final.append(record(target))
        diff.extend(difflib.unified_diff(
            (STAGE / "before" / name).read_text(encoding="utf-8-sig").splitlines(True),
            data.decode("utf-8-sig").splitlines(True),
            fromfile="root-before/" + name, tofile="root-current/" + name))
    (out / "root-product.diff").write_text("".join(diff), encoding="utf-8")
    logical = []
    by_repo_path = {}
    for prefix in ["before", "candidate", "test/initial", "test/candidate",
                   "generic/candidate", "generic/opaque-boundary/before",
                   "generic/opaque-boundary/candidate", "archive-source/root-current"]:
        folder = STAGE / prefix
        for path in sorted(folder.rglob("*")):
            if path.is_file() and path.suffix in {".cc", ".h"}:
                row = record(path)
                repo = path.relative_to(folder).as_posix()
                logical.append(row)
                by_repo_path.setdefault(repo, []).append(row)
    report = {
        "status": "Source-only archive preparation; validation still pending; no ZIP written.",
        "metadata_name_collision": {
            "paths": ["before-identities.json", "source.diff"],
            "fact": "Root-level names were reused by initial test preparation. They describe tests, not root product changes. All distinct source preimage files remain under before/<repo-path>; the generic preimage identity manifest and both test versions are preserved separately.",
            "reconstruction": "archive-source/root-product.diff and root-current snapshots reconstruct the six root-owned product changes from retained preimage bytes and final canonical source. The initial five-file diff/audit are preserved as root-product-initial.diff/archive-source-audit-initial.json; actual old source bytes are not overwritten.",
            "limits": "For root preimages absent from the prior ZIP, the retained preimage bytes are recorded here; this audit cannot manufacture a lost earlier standalone identity receipt."
        },
        "generic_before_manifest_verified": generic,
        "test_before_manifest_verified": tests,
        "root_preimages": roots,
        "root_final_snapshots": final,
        "prior_archive": {"path": str(old), "bytes": old.stat().st_size,
                          "sha256": sha(old.read_bytes())},
        "root_prior_anchors": anchors,
        "logical_source_versions": logical,
        "distinct_source_bytes_per_repository_path": {
            key: len({r["sha256"] for r in rows}) for key, rows in sorted(by_repo_path.items())},
        "namespace_rule": "Archive names retain original stage-relative directories. Equal bytes may share one stored payload through explicit manifest aliases; different versions never overwrite one another.",
        "deleted_files": 0,
    }
    (STAGE / "archive-source-audit.json").write_text(
        json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"generic_before_verified": len(generic), "test_before_verified": len(tests),
                      "root_preimages": len(roots), "root_prior_anchored": sum(r["prior_anchor_available"] for r in anchors),
                      "source_versions": len(logical), "zip_written": False}))


if __name__ == "__main__":
    main()
