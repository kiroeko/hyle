from pathlib import Path
import importlib.util
import json
import sys

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
PREVIOUS = HERE.parent / 'cuda-coarse-capture-tests'
# Import only the previous strict compiler/command helpers; its historical
# __main__ actions never execute. All new outputs stay in this stage.
spec = importlib.util.spec_from_file_location('previous_capture_build_helpers', PREVIOUS / 'build.py')
previous = importlib.util.module_from_spec(spec)
spec.loader.exec_module(previous)

previous.OUT = HERE
PLAN = previous.read(HERE / 'validation-plan.json')


def compile_hosts():
    for row in PLAN['product_owners'] + PLAN['test_and_consumer_owners']:
        assert previous.ident(previous.ROOT / row['source']) == row['current_source'], row['source']
        previous.compile_one(row['source'], row['name'], row['template'])


def compile_v2():
    previous.OUT = HERE / 'validation'
    for row in previous.read(previous.OUT / 'v2-plan.json')['rows']:
        assert previous.ident(previous.ROOT / row['source']) == row['current_source'], row['source']
        previous.compile_one(row['source'], row['name'], row['template'])


def link(kind, suffix=''):
    output_directory = HERE / 'validation'
    output_directory.mkdir(exist_ok=True)
    previous.OUT = output_directory
    base = (PREVIOUS / 'cpu-controls-link-plan.json' if kind == 'cpu'
            else Path(PLAN['base_link_plan']['path']))
    args = previous.read(base)['command']
    if kind == 'cpu':
        # Its current generic equivalents are selected below. The original
        # obsolete helper combined both old page metadata and pending glue.
        args = [value for value in args
                if not value.endswith('src--graph_batch--native_paged_regions.obj')]
    replacements = {}
    selected = []
    versions = {row['source']: row for row in previous.read(output_directory / 'v2-plan.json')['rows']}
    source_rows = list(PLAN['product_owners'])
    source_rows += [row for row in versions.values() if row['source'].startswith('src/')
                    and row['source'] not in {value['source'] for value in source_rows}]
    for row in source_rows:
        latest = versions.get(row['source'])
        receipt = (output_directory / (latest['name'] + '-identity.json') if latest
                   else HERE / (row['name'] + '-identity.json'))
        current = previous.read(receipt)
        assert previous.ident(current['object']['path']) == current['object']
        old_objects = list(row['old_objects'])
        if row['source'] == 'src/graph_batch/batch.cc':
            old_objects.append(str(previous.ARCH / 'retire-native-runtime/paging-risks/batch.obj'))
        used = [old for old in old_objects if old in args]
        for old in used:
            assert args.count(old) == 1, old
            replacements[old] = current['object']['path']
        if used:
            selected.append(current)
    consumer = next(row for row in PLAN['test_and_consumer_owners']
                    if row['source'] == 'tools/qwen35_text/main.cc')
    main = {'cpu': 'region-control-test', 'cuda': 'torch-reuse-test',
            'qwen': 'qwen-consumer'}[kind]
    old_main = (str(PREVIOUS / 'region-control-test.obj') if kind == 'cpu'
                else consumer['old_objects'][0])
    replacements[old_main] = str(output_directory / 'region-control-test-v2.obj'
                               if kind == 'cpu' else HERE / (main + '.obj'))
    args = [replacements.get(v, v) for v in args
            if not v.upper().startswith(('/OUT:', '/MAP:', '/IMPLIB:', '/PDB:'))]
    if kind != 'qwen':
        for name in ['gtest_main.lib', 'gtest.lib']:
            library = str(previous.ROOT / '.scratch/build-compute-v2-dev/lib' / name)
            if library not in args:
                args.append(library)
    if kind == 'cpu':
        other = previous.read(PLAN['base_link_plan']['path'])['command']
        for name in ['src--graph_batch--native_batch_regions.obj',
                     'src--graph_batch--native_pending_regions.obj']:
            helper = next(value for value in other if value.endswith(name))
            if helper not in args:
                args.insert(1, helper)
    if kind == 'cuda':
        args[1:1] = [str(HERE / 'graph-cuda-control-test.obj'),
                     str(PREVIOUS / 'sglang-checked-test.obj'),
                     str(PREVIOUS / 'ggml-mean-test.obj')]
    output = output_directory / (kind + '-reuse')
    args += ['/OUT:' + str(output.with_suffix('.exe')),
             '/MAP:' + str(output.with_suffix('.map')),
             '/IMPLIB:' + str(output.with_suffix('.lib'))]
    assert all(Path(v).is_file() for v in args
               if Path(v).is_absolute() and Path(v).suffix.lower() in ['.obj', '.lib'])
    previous.save(kind + '-link-plan.json', dict(command=args,
        selected_current_owners=selected, replacements=replacements,
        original=previous.ident(base)))
    previous.execute(kind + '-link' + suffix, args)
    previous.save(kind + '-image.json', dict(
        image=previous.ident(output.with_suffix('.exe')),
        map=previous.ident(output.with_suffix('.map'))))
    if kind != 'qwen':
        filters = PLAN['cpu_filters'] if kind == 'cpu' else PLAN['cuda_filters']
        previous.save(kind + '-run-plan.json', dict(
            command=[str(output.with_suffix('.exe')), '--gtest_color=no',
                     '--gtest_filter=' + ':'.join(filters),
                     '--gtest_output=xml:' + str(output_directory / (kind + '-tests.xml'))],
            tests=filters, not_run=True, timeout_seconds=90))


if __name__ == '__main__':
    if sys.argv[1] == 'compile':
        compile_hosts()
    elif sys.argv[1] == 'compile-v2':
        compile_v2()
    else:
        assert sys.argv[1] == 'link'
        link(sys.argv[2], sys.argv[3] if len(sys.argv) > 3 else '')
