param([switch]$ReclaimCudaCaptureReuse)
$ErrorActionPreference = 'Stop'
$workspace = [IO.Path]::GetFullPath($PSScriptRoot).TrimEnd('\')
$stage = Join-Path $workspace '.scratch/architecture-refactor-2026-10-18/cuda-capture-reuse/reclaim'
$plan = Get-Content -Raw -LiteralPath (Join-Path $stage 'cleanup-plan.json') | ConvertFrom-Json
$imageDirectory = Join-Path $workspace '.scratch/architecture-refactor-2026-10-18/cuda-capture-reuse/validation'
$archiveDirectory = Join-Path $workspace 'docs/evidence/performance/qwen35-full-cuda-2026-10-19'
$expectedArchives = @{
    (Join-Path $archiveDirectory 'cuda-capture-reuse.zip') = (Join-Path $workspace '.scratch/architecture-refactor-2026-10-18/cuda-capture-reuse/archive-receipt.json')
    (Join-Path $archiveDirectory 'ggml-cuda-caller-workspace.zip') = (Join-Path $workspace '.scratch/architecture-refactor-2026-10-18/ggml-cuda-caller-workspace/archive-receipt.json')
}
function Get-IdentitySha256([string]$path) {
    $stream = [IO.File]::OpenRead($path)
    $sha = [Security.Cryptography.SHA256]::Create()
    try { return [BitConverter]::ToString($sha.ComputeHash($stream)).Replace('-', '').ToLowerInvariant() }
    finally { $sha.Dispose(); $stream.Dispose() }
}
function Assert-Identity($entry) {
    $path = [IO.Path]::GetFullPath([string]$entry.path)
    if (-not $path.StartsWith($workspace + '\', [StringComparison]::OrdinalIgnoreCase)) { throw "Outside workspace: $path" }
    if ([string]$entry.sha256 -cnotmatch '^[0-9a-f]{64}$') { throw "Invalid SHA256 identity: $path" }
    $item = Get-Item -LiteralPath $path -Force
    if ($item.PSIsContainer) { throw "Expected exact file: $path" }
    $resolved = (Resolve-Path -LiteralPath $path).ProviderPath
    if (-not [string]::Equals($resolved, $path, [StringComparison]::OrdinalIgnoreCase)) { throw "Resolved path changed: $path" }
    $cursor = $item
    while ($null -ne $cursor) {
        if ($cursor.Attributes -band [IO.FileAttributes]::ReparsePoint) { throw "Reparse path: $path" }
        if ($cursor -is [IO.FileInfo]) { $cursor = $cursor.Directory } else { $cursor = $cursor.Parent }
    }
    if ($item.Length -ne [long]$entry.bytes -or (Get-IdentitySha256 $path) -ne $entry.sha256) { throw "Identity changed: $path" }
}
if ($plan.workspace -ne $workspace -or $plan.allowed_directory -ne $imageDirectory) { throw 'Plan root does not match this task' }
if (@($plan.targets).Count -ne 33 -or $plan.files -ne 33 -or $plan.bytes -ne 878181587 -or ($plan.targets | Measure-Object bytes -Sum).Sum -ne $plan.bytes) { throw 'Expected exactly24 images plus9 stale objects totaling878181587 bytes' }
if (@($plan.retained_objects).Count -ne 19 -or @($plan.retained_raw_vectors).Count -ne 32) { throw 'Expected18 current local objects plus1 cached Direct object and32 raw vectors retained' }
$seen = [Collections.Generic.HashSet[string]]::new([StringComparer]::OrdinalIgnoreCase)
foreach ($entry in @($plan.retained_objects) + @($plan.retained_raw_vectors)) {
    if (-not $seen.Add([string]$entry.path)) { throw "Duplicate retained path: $($entry.path)" }
    Assert-Identity $entry
}
$allowedStems = @('cpu-reuse', 'cuda-reuse', 'qwen-reuse')
$historicalDirectory = Join-Path $imageDirectory 'historical-bf16-accepted'
$finalDirectory = Join-Path $imageDirectory 'binding-reuse'
$staleDirectory = Join-Path $workspace '.scratch/architecture-refactor-2026-10-18/cuda-capture-reuse'
$allowedStaleObjects = @('graph--constant_artifact', 'graph--executable', 'graph--input_sources', 'graph--region_access', 'graph--resources', 'graph--resource_report', 'graph--submission', 'graph_progress--progress', 'region-control-test')
foreach ($entry in $plan.targets) {
    $path = [IO.Path]::GetFullPath([string]$entry.path)
    $extension = [IO.Path]::GetExtension($path).ToLowerInvariant()
    $stem = [IO.Path]::GetFileNameWithoutExtension($path)
    $directory = [IO.Path]::GetDirectoryName($path)
    $validImage = (($directory -eq $imageDirectory -and $allowedStems -contains $stem) -or ($directory -eq $historicalDirectory -and $stem -eq 'accepted') -or ($directory -eq $finalDirectory -and @('cuda-final', 'qwen-final') -contains $stem)) -and @('.exe', '.map', '.lib', '.exp') -contains $extension
    $validStale = $directory -eq $staleDirectory -and $extension -eq '.obj' -and $allowedStaleObjects -contains $stem
    if (-not ($validImage -or $validStale)) { throw "Not an exact completed image or approved stale initial object: $path" }
    if (-not $seen.Add($path)) { throw "Duplicate or retained deletion target: $path" }
    Assert-Identity $entry
}
if (@($plan.archives).Count -ne 2) { throw 'New capture-reuse archive and prior vector archive required' }
$verifiedArchives = [Collections.Generic.List[object]]::new()
$pendingArchives = [Collections.Generic.List[string]]::new()
foreach ($entry in $plan.archives) {
    if (-not $expectedArchives.ContainsKey([string]$entry.path) -or $expectedArchives[[string]$entry.path] -ne $entry.receipt) { throw "Unexpected archive or receipt: $($entry.path)" }
    if (-not (Test-Path -LiteralPath $entry.path) -or -not (Test-Path -LiteralPath $entry.receipt)) {
        $pendingArchives.Add([string]$entry.path)
        continue
    }
    $receipt = Get-Content -Raw -LiteralPath $entry.receipt | ConvertFrom-Json
    $crcVerified = $receipt.crc_verified -or $receipt.zip_crc_verified -or $receipt.zip_crc_and_all_entry_sha_verified -or $receipt.crc_and_all_payload_sha_verified
    $shaVerified = $receipt.every_payload_sha256_verified -or $receipt.zip_crc_and_all_entry_sha_verified -or $receipt.crc_and_all_payload_sha_verified
    if (-not $crcVerified -or -not $shaVerified) { throw "Archive receipt lacks verified CRC and every payload SHA: $($entry.receipt)" }
    $identity = if ($null -ne $receipt.archive) { $receipt.archive } elseif ($receipt.path) { $receipt } else { [pscustomobject]@{path=$receipt.destination; bytes=$receipt.bytes; sha256=$receipt.sha256} }
    if ($identity.path -ne $entry.path) { throw "Archive receipt path differs: $($entry.receipt)" }
    if ($entry.sha256 -and ($entry.sha256 -ne $identity.sha256 -or $entry.bytes -ne $identity.bytes)) { throw "Frozen baseline archive identity differs: $($entry.path)" }
    Assert-Identity $identity
    $verifiedArchives.Add($identity)
}
$preview = [pscustomobject]@{
    preview = $true; files = 33; bytes = $plan.bytes; archives_verified = $verifiedArchives.Count
    archives_pending = $pendingArchives.ToArray(); retained_objects = 19; retained_raw_vectors = 32
    script_sha256 = (Get-IdentitySha256 $PSCommandPath)
}
if (-not $ReclaimCudaCaptureReuse) {
    $preview | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath (Join-Path $stage 'preview.json') -Encoding utf8
    $preview
    return
}
if ($pendingArchives.Count -ne 0 -or $verifiedArchives.Count -ne 2) { throw 'Final archives are not frozen and verified; no files were deleted' }
$receiptPath = Join-Path $stage 'cleanup-receipt.json'
if (Test-Path -LiteralPath $receiptPath) { throw 'Cleanup already has a receipt; do not replay deletions' }
$deleted = [Collections.Generic.List[object]]::new()
foreach ($entry in $plan.targets) {
    Assert-Identity $entry
    Remove-Item -LiteralPath ([string]$entry.path)
    if (Test-Path -LiteralPath ([string]$entry.path)) { throw "Still exists: $($entry.path)" }
    $deleted.Add($entry)
    [pscustomobject]@{
        deleted = $deleted.ToArray(); files = $deleted.Count; bytes = ($deleted | Measure-Object bytes -Sum).Sum
        archives_verified = $verifiedArchives.ToArray(); retained_objects = $plan.retained_objects; retained_raw_vectors = $plan.retained_raw_vectors
        complete = ($deleted.Count -eq $plan.targets.Count); script_sha256 = (Get-IdentitySha256 $PSCommandPath)
    } | ConvertTo-Json -Depth 12 | Set-Content -LiteralPath $receiptPath -Encoding utf8
}
foreach ($entry in @($plan.retained_objects) + @($plan.retained_raw_vectors)) { Assert-Identity $entry }
[pscustomobject]@{deleted_files=$deleted.Count; reclaimed_bytes=$plan.bytes; archives_verified=2; retained_objects=19; retained_raw_vectors=32}
