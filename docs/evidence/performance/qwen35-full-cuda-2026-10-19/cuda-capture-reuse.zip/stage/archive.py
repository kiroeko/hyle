"""Archive this bounded capture-reuse slice only; never build, run or delete."""
from pathlib import Path
import argparse
import hashlib
import json
import math
import statistics
import xml.etree.ElementTree as ET
import zipfile

STAGE = Path(__file__).resolve().parent
ROOT = STAGE.parents[2]
VALIDATION = STAGE / "validation"
FINAL = VALIDATION / "binding-reuse"
TARGET = ROOT / "docs/evidence/performance/qwen35-full-cuda-2026-10-19/cuda-capture-reuse.zip"
TEXT = {".json", ".jsonl", ".diff", ".cc", ".h", ".py", ".log", ".xml", ".txt", ".tsv", ".csv", ".cmake", ".md", ".ids", ".ps1", ".rsp"}
GENERATED = {"archive-inventory.json", "archive-receipt.json", "archive-postcheck.json"}
PREPARATION_ONLY = {"archive-plan.json", "documentation-update-plan.json"}


def sha(data):
    return hashlib.sha256(data).hexdigest()


def read(path):
    return json.loads(Path(path).read_text(encoding="utf-8-sig"))


def encoded(value):
    return (json.dumps(value, ensure_ascii=False, indent=2) + "\n").encode("utf-8")


def identity(path):
    path = Path(path)
    data = path.read_bytes()
    return {"path": str(path.resolve()), "bytes": len(data), "sha256": sha(data)}


def check_identity(row):
    path = Path(row["path"])
    if not path.is_absolute():
        path = ROOT / path
    actual = identity(path)
    assert (actual["bytes"], actual["sha256"]) == (row["bytes"], row["sha256"]), str(path)


def verify_sources():
    manifests = [STAGE / "generic/opaque-boundary/source-freeze.json", STAGE / "test/source-freeze.json",
                 STAGE / "ggml-binding-reuse/source-freeze.json"]
    checked = []
    for manifest in manifests:
        report = read(manifest)
        rows = report.get("source_identities", report.get("sources", []))
        if "source" in report:
            rows = [report["source"]]
            check_identity(report["before"])
        for row in rows:
            check_identity(row)
            checked.append(row)
    audit = read(STAGE / "archive-source-audit.json")
    for key in ["generic_before_manifest_verified", "test_before_manifest_verified", "root_preimages", "root_final_snapshots"]:
        for row in audit[key]:
            actual = identity(STAGE / row["path"])
            assert (actual["bytes"], actual["sha256"]) == (row["bytes"], row["sha256"]), row["path"]
    for row in audit["root_final_snapshots"]:
        repo = row["path"].removeprefix("archive-source/root-current/")
        actual = identity(ROOT / repo)
        assert (actual["bytes"], actual["sha256"]) == (row["bytes"], row["sha256"]), repo
    return {"final_manifests": [identity(p) for p in manifests], "canonical_source_rows": len(checked),
            "canonical_source_drift": 0, "source_preimage_audit": identity(STAGE / "archive-source-audit.json")}


def verify_results():
    # Final summary is deliberately required, even though XML already exists.
    # Parent/configuration owns the outstanding historical-baseline audit.
    summary = read(VALIDATION / "summary.json")
    assert summary["distinct_tests_passed"] == 16 and summary["live"] is False
    assert summary["product_current_source_dependency_drift"] == 0
    read(VALIDATION / "filtered-current-dependencies.json")
    read(VALIDATION / "final-selected-owners.json")
    cleanup = read(FINAL / "cleanup-windows.json")
    top = read(VALIDATION / "final-summary.json")
    assert top["live"] is False
    cases = []
    for name, expected in [("cpu-tests.xml", 11), ("cuda-tests.xml", 5)]:
        actual = list(ET.parse(VALIDATION / name).getroot().iter("testcase"))
        assert len(actual) == expected
        assert all(not item.findall("failure") and not item.findall("error") and not item.findall("skipped") for item in actual)
        cases.extend(item.attrib["classname"] + "." + item.attrib["name"] for item in actual)
    assert len(set(cases)) == 16
    commands = read(VALIDATION / "commands.json")
    assert all(row.get("terminal") is True and row.get("exit") is not None for row in commands)
    for tag in ["cpu-focused-tests-run", "cuda-focused-tests-run", "qwen-commands-probe-run", "qwen-prefer-capture-probe-run"]:
        actual = [row for row in commands if row["tag"] == tag]
        assert len(actual) == 1 and actual[0]["exit"] == 0
    probe = read(VALIDATION / "qwen-probe-summary.json")
    assert all(arm["exit"] == 0 and len(arm["prepared"]) == 4 for arm in probe["arms"].values())
    counts = [(r["recorded"], r["reused"]) for r in probe["arms"]["prefer-capture"]["prepared"]]
    assert counts == [(7, 0), (7, 0), (7, 0), (0, 7)]
    assert len(probe["paired_vectors"]) == 8 and all(row["equal"] for row in probe["paired_vectors"])
    perf = read(VALIDATION / "performance-summary.json")
    raw = read(VALIDATION / "performance-results.json")["runs"]
    assert len(raw) == 6 and all(row["exit"] == 0 and len(row["steps"]) == 32 for row in raw)
    ids = [[step["next_token"] for step in row["steps"]] for row in raw]
    assert all(tokens == ids[0] for tokens in ids)
    for mode in ["commands", "prefer-capture"]:
        selected = [row for row in raw if row["mode"] == mode]
        assert len(selected) == 3
        formulas = {
            "prefill_tokens_per_second": lambda r: 128 / r["steps"][0]["step_seconds"],
            "full_decode_tokens_per_second": lambda r: 31 / sum(s["step_seconds"] for s in r["steps"][1:]),
            "warm_decode7_to31_tokens_per_second": lambda r: 25 / sum(s["step_seconds"] for s in r["steps"][7:]),
        }
        for key, formula in formulas.items():
            actual = statistics.median(formula(row) for row in selected)
            assert math.isclose(actual, perf["medians"][mode][key], rel_tol=1e-12), (mode, key)
    assert perf["profiler"] is False and perf["memory_monitor"] is False
    assert perf["quality_acceptance"] is False
    history = read(VALIDATION / "historical-control-summary.json")
    old_inputs = read(VALIDATION / "historical-bf16-link-audit.json")
    assert old_inputs["input_count"] == 119 and not old_inputs["missing"] and not old_inputs["identity_mismatches"]
    controls = read(VALIDATION / "historical-control-results.json")["runs"]
    assert len(controls) == 6 and all(row["exit"] == 0 and len(row["phases"]) == 32 for row in controls)
    assert all([s["next_token"] for s in row["phases"]] == ids[0] for row in controls)
    for mode in ["old", "current"]:
        selected = [row for row in controls if row["arm"] == mode]
        assert len(selected) == 3
        formulas = {
            "prefill_tokens_per_second": lambda r: 128 / r["phases"][0]["step_seconds"],
            "full_decode_tokens_per_second": lambda r: 31 / sum(s["step_seconds"] for s in r["phases"][1:]),
            "warm_decode7_to31_tokens_per_second": lambda r: 25 / sum(s["step_seconds"] for s in r["phases"][7:]),
        }
        for key, formula in formulas.items():
            actual = statistics.median(formula(row) for row in selected)
            assert math.isclose(actual, history["medians"][mode][key], rel_tol=1e-12), (mode, key)
    assert history["quality_acceptance"] is False and history["all_32_generated_ids_equal"] is True
    final_summary = read(FINAL / "summary.json")
    assert final_summary["live"] is False and final_summary["source_dependency_drift_count"] == 0
    assert final_summary["full_slice_unique_tests"]["count"] == 17
    read(FINAL / "filtered-current-dependencies.json")
    read(FINAL / "final-selected-owners.json")
    final_cases = list(ET.parse(FINAL / "cuda-tests.xml").getroot().iter("testcase"))
    assert len(final_cases) == 6
    assert all(not c.findall("failure") and not c.findall("error") and not c.findall("skipped") for c in final_cases)
    all_cases = set(cases)
    all_cases.update(c.attrib["classname"] + "." + c.attrib["name"] for c in final_cases)
    assert len(all_cases) == 17
    final_commands = read(FINAL / "commands.json")
    assert all(r.get("terminal") is True and r.get("exit") == 0 for r in final_commands)
    final_probe = read(FINAL / "qwen-probe-summary.json")
    assert len(final_probe["paired_vectors"]) == 8 and all(r["equal"] for r in final_probe["paired_vectors"])
    assert [(r["recorded"], r["reused"]) for r in final_probe["arms"]["prefer-capture"]["prepared"]] == counts
    final_perf = read(FINAL / "performance-summary.json")
    final_raw = read(FINAL / "performance-results.json")["runs"]
    assert len(final_raw) == 6 and all(r["exit"] == 0 and len(r["steps"]) == 32 for r in final_raw)
    assert all([s["next_token"] for s in r["steps"]] == ids[0] for r in final_raw)
    for mode in ["commands", "prefer-capture"]:
        selected = [r for r in final_raw if r["mode"] == mode]
        assert len(selected) == 3
        formulas = {
            "prefill_tokens_per_second": lambda r: 128 / r["steps"][0]["step_seconds"],
            "full_decode_tokens_per_second": lambda r: 31 / sum(s["step_seconds"] for s in r["steps"][1:]),
            "warm_decode7_31_tokens_per_second": lambda r: 25 / sum(s["step_seconds"] for s in r["steps"][7:]),
        }
        for key, formula in formulas.items():
            actual = statistics.median(formula(r) for r in selected)
            assert math.isclose(actual, final_perf["medians"][mode][key], rel_tol=1e-12), (mode, key)
    return {"initial_summary": identity(VALIDATION / "summary.json"), "final_summary": identity(FINAL / "summary.json"),
            "passing_case_names": sorted(all_cases), "distinct_passing_cases": 17,
            "functional_pairs": 2, "functional_pair_vectors_each": 8, "actual_capture_recorded_reused": counts,
            "initial_replay_comparison_runs": 6, "historical_commands_control_runs": 6,
            "final_binding_reuse_comparison_runs": 6,
            "timed_ids_each": 32, "timed_ids_equal": True,
            "initial_same_image_medians": perf["medians"], "final_same_image_medians": final_perf["medians"],
            "historical_control_medians": history["medians"],
            "historical_control_summary": identity(VALIDATION / "historical-control-summary.json"),
            "background_gpu_observation": identity(VALIDATION / "background-gpu-observation.json"),
            "background_observation_proves_each_run_cause": False,
            "historical_boundary_review": identity(VALIDATION / "history-boundary-review.json"),
            "historical_difference_cause_established": False,
            "performance_or_quality_scope": "Use final summary limits; no unmeasured memory, new peer comparison or broad no-regression claim.",
            "failed_commands_preserved": [{"tag": r["tag"], "exit": r["exit"]} for r in commands if r["exit"] != 0],
            "cleanup_plan": identity(FINAL / "cleanup-windows.json"),
            "cleanup_candidate_files": cleanup["count"], "cleanup_candidate_bytes": cleanup["bytes"],
            "retained_local_objects": cleanup["retained_local_objects"],
            "retained_cached_direct_objects": cleanup["retained_cached_direct_objects"],
            "cleanup_performed_by_archive": False}


def verify_vectors():
    refs = read(FINAL / "decision-vector-archive-references.json")
    check_identity(refs["archive"])
    assert len(refs["vectors"]) == 8
    omitted = set()
    with zipfile.ZipFile(refs["archive"]["path"]) as previous:
        for row in refs["vectors"]:
            data = previous.read(row["archived_entry"])
            assert (len(data), sha(data)) == (row["bytes"], row["sha256"])
            assert f"{previous.getinfo(row['archived_entry']).CRC:08x}" == row["archived_crc32"]
            for name in row["current_paths"]:
                path = Path(name)
                assert path.read_bytes() == data
                omitted.add(path.resolve())
    assert len(omitted) == 32
    return {"archive": refs["archive"], "reference_manifest": identity(FINAL / "decision-vector-archive-references.json"),
            "referenced_original_vectors": 8, "current_raw_vectors_verified": len(omitted),
            "copied_raw_vectors": 0, "scratch_raw_retained": True}, omitted


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--write", action="store_true")
    args = parser.parse_args()
    sources, results = verify_sources(), verify_results()
    vectors, omitted_raw = verify_vectors()
    payloads, logical, excluded, content = {}, [], [], {}

    def add(name, path):
        assert not any(row["path"] == name for row in logical), name
        data = path.read_bytes()
        key = (len(data), sha(data))
        stored = content.get(key)
        if stored is None:
            stored = name
            content[key] = name
            payloads[name] = (path, data)
        else:
            assert payloads[stored][1] == data
        logical.append({"path": name, "stored_as": stored, "bytes": len(data), "sha256": key[1]})

    for path in sorted(STAGE.rglob("*"), key=lambda p: p.as_posix()):
        if not path.is_file():
            continue
        name = "stage/" + path.relative_to(STAGE).as_posix()
        reason = None
        if path.resolve() in omitted_raw:
            reason = "exact prior archive vector reference, current bytes verified"
        elif path.suffix.lower() in {".bf16", ".f32"}:
            raise AssertionError("unreferenced raw vector must not be silently omitted: " + str(path))
        elif path.name in PREPARATION_ONLY:
            reason = "superseded planning draft; final archive script, source audit and actual results retained"
        elif path.name in GENERATED or path.name == "live.json" or (path.parent.name == "reclaim" and path.name == "preview.json") or "__pycache__" in path.parts:
            reason = "generated/transient state"
        elif path.name.endswith("-deps.json") or path.suffix.lower() == ".d":
            reason = "raw dependency dump replaced by filtered actual Hyle identities"
        elif path.suffix.lower() not in TEXT:
            reason = "rebuildable binary/unsupported payload; see identity and selected-owner records"
        if reason:
            excluded.append({"path": name, "bytes": path.stat().st_size, "reason": reason})
        else:
            add(name, path)
    for name in ["docs/evidence/performance/qwen35-full-cuda-2026-10-19/README.md", "docs/developer/current-work.md",
                 "docs/architecture/compute-design.md", "docs/architecture/graph-design.md", "tools/qwen35_text/README.md"]:
        add("documentation/" + name, ROOT / name)
    for name in ["qwen-commands-run-plan.json", "qwen-prefer-capture-run-plan.json", "performance-plan.json", "historical-control-plan.json"]:
        plan = read(VALIDATION / name)
        for key in ["prompt", "tape", "model_manifest"]:
            if key in plan:
                check_identity(plan[key])
                add("inputs/" + name.removesuffix(".json") + "/" + Path(plan[key]["path"]).name, Path(plan[key]["path"]))
    for name in ["qwen-commands-run-plan.json", "qwen-prefer-capture-run-plan.json", "performance-plan.json"]:
        plan = read(FINAL / name)
        for key in ["prompt", "tape", "model_manifest"]:
            if key in plan:
                check_identity(plan[key])
                add("inputs/final/" + name.removesuffix(".json") + "/" + Path(plan[key]["path"]).name, Path(plan[key]["path"]))
    inventory = {"schema": "hyle.cuda.capture.reuse.archive.v1", "output": str(TARGET),
                 "logical_files": len(logical), "stored_payload_files": len(payloads),
                 "logical_bytes": sum(r["bytes"] for r in logical),
                 "stored_payload_bytes": sum(len(data) for _, data in payloads.values()),
                 "entries": logical, "excluded": excluded, "source_checks": sources,
                 "result_checks": results, "decision_vectors": vectors,
                 "reconstruction": "Each logical path resolves to stored_as. Identical source/text payloads are stored once; distinct source versions remain distinct. Old vector archive bytes/entry CRC/SHA were independently rechecked.",
                 "exclusions": "No objects, images, maps, SDK/model payload, copied old ZIP, raw dependency dump or repeated decision vectors.",
                 "deleted_files": 0}
    manifest = encoded(inventory)
    (STAGE / "archive-inventory.json").write_bytes(manifest)
    if not args.write:
        print(json.dumps({key: inventory[key] for key in ["logical_files", "stored_payload_files", "logical_bytes", "stored_payload_bytes"]}))
        return
    with zipfile.ZipFile(TARGET, "x", zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for name, (_, data) in sorted(payloads.items()):
            archive.writestr(name, data)
        archive.writestr("archive-manifest.json", manifest)
    with zipfile.ZipFile(TARGET) as archive:
        assert archive.testzip() is None
        assert len(archive.infolist()) == len(payloads) + 1
        assert archive.read("archive-manifest.json") == manifest
        for row in logical:
            data = archive.read(row["stored_as"])
            assert (len(data), sha(data)) == (row["bytes"], row["sha256"])
    for path, data in payloads.values():
        assert path.read_bytes() == data, str(path)
    receipt = {"archive": identity(TARGET), "entries": len(payloads) + 1,
               "logical_files": len(logical), "stored_payload_files": len(payloads),
               "stored_payload_bytes": inventory["stored_payload_bytes"], "manifest_sha256": sha(manifest),
               "crc_verified": True, "every_logical_payload_sha_verified": True, "source_drift": 0,
               "distinct_tests_passed": 17, "functional_pairs": 2, "functional_pair_vectors_each": 8,
               "initial_replay_comparison_runs": 6, "historical_commands_control_runs": 6,
               "final_binding_reuse_comparison_runs": 6,
               "timed_ids_per_run": 32,
               "referenced_original_vectors": 8, "raw_vector_copies": 0,
               "retained_scratch_raw_vectors": 32, "deleted_files": 0,
               "cleanup_candidates": identity(FINAL / "cleanup-windows.json"),
               "cleanup_candidate_files": results["cleanup_candidate_files"],
               "cleanup_candidate_bytes": results["cleanup_candidate_bytes"],
               "retained_local_objects": results["retained_local_objects"],
               "retained_cached_direct_objects": results["retained_cached_direct_objects"]}
    (STAGE / "archive-receipt.json").write_bytes(encoded(receipt))
    print(json.dumps(receipt))


if __name__ == "__main__":
    main()
