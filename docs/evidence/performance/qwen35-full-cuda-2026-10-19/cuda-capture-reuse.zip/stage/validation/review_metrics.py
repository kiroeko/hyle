from pathlib import Path
import hashlib
import json
import statistics

HERE = Path(__file__).resolve().parent
ARCH = HERE.parents[1]


def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def identity(path):
    return dict(path=str(path.resolve()), bytes=path.stat().st_size,
                sha256=hashlib.sha256(path.read_bytes()).hexdigest())


current = read(HERE / 'performance-summary.json')
for run in current['runs']:
    warm = run['steps'][7:]
    assert len(warm) == 25 and warm[0]['phase'] == 'decode7' and warm[-1]['phase'] == 'decode31'
    run['warm_decode7_to31_tokens_per_second'] = 25 / sum(step['step_seconds'] for step in warm)
    run['warm_decode7_to31_seconds'] = sum(step['step_seconds'] for step in warm)
for mode in ['commands', 'prefer-capture']:
    samples = [run['warm_decode7_to31_tokens_per_second'] for run in current['runs'] if run['mode'] == mode]
    current['medians'][mode]['warm_decode7_to31_tokens_per_second'] = statistics.median(samples)
current['metric_boundaries'] = dict(full_decode='decode1..31:31/sum(step_seconds)',
    warm_decode='decode7..31:25/sum(step_seconds), same historical warm range',
    prefill='128/prefill.step_seconds',
    step_seconds='Before position generation/token+position writes, through layout/bind/prepare_replay/submit/wait and selected-token readback; shape compile separately.')
(HERE / 'performance-summary.json').write_text(json.dumps(current, indent=2) + '\n')
old = ARCH / 'cuda-bfloat-elementwise-build'
historical = read(old / 'performance-summary.json')
checked = []
for directory in sorted(old.glob('perf128-*-*')):
    metrics = read(directory / 'metrics.json')
    rows = metrics['phases']
    expected = dict(prefill_tokens_per_second=128 / rows[0]['step_seconds'],
        decode_all_tokens_per_second=31 / sum(row['step_seconds'] for row in rows[1:]),
        decode_warm_tokens_per_second=25 / sum(row['step_seconds'] for row in rows[7:]))
    assert all(abs(metrics[key] - value) < 1e-10 for key, value in expected.items())
    checked.append(dict(metrics=identity(directory / 'metrics.json'), values=expected,
        command=identity(directory / 'command.json'), stderr=identity(directory / 'stderr.log')))
assert len(checked) == 6
refs = [ARCH / 'cuda-native-matvec/run.py', old / 'validate.py', old / 'analyze.py',
        old / 'performance-summary.json', old / 'candidate-link-plan.json',
        ARCH / 'qwen-gpu-comparison/candidate/main.cc',
        ARCH / 'qwen-gpu-comparison/hyle-source-identities.json']
review = dict(status='read_only_original_formulas_and_all_six_metrics_recomputed',
    historical_prefill_medians={arm: historical['groups'][arm]['prefill_tokens_per_second']['median']
                               for arm in ['before', 'candidate']},
    historical_warm_medians={arm: historical['groups'][arm]['decode_warm_tokens_per_second']['median']
                            for arm in ['before', 'candidate']},
    historical_formula=dict(source='cuda-native-matvec/run.py:32,34 imported by cuda-bfloat-elementwise-build/validate.py',
        prefill='prompt/phases[0].step_seconds', all_decode='31/sum(phases[1:].step_seconds)',
        warm_decode='25/sum(phases[7:].step_seconds), decode7..31',
        submit_to_token_seconds='Stored separately from fields.seconds; NOT used for these rates.'),
    old_consumer=dict(source='qwen-gpu-comparison/candidate/main.cc',
        identity=identity(ARCH / 'qwen-gpu-comparison/candidate/main.cc'),
        actual_object='qwen-gpu-comparison/hyle-consumer.obj explicitly selected in old BF16 candidate link plan',
        mode='Original hardcoded Commands', begin_line=473, end_line=521,
        boundary='step_start before position generation and token/position writes; finished after next_id.read; shape prepare before timer.'),
    current_warm_samples={mode: [run['warm_decode7_to31_tokens_per_second'] for run in current['runs']
                                if run['mode'] == mode] for mode in ['commands', 'prefer-capture']},
    current_medians=current['medians'], verified_historical_runs=checked,
    sources=[identity(path) for path in refs],
    conclusion='Historical 1589->1765 prefill and 77.32->79.84 warm decode use full step_seconds, not submit-to-token seconds. Compare current warm to historical warm only. Current same-image paired Commands baseline is lower than historical BF16 candidate; timer-field mismatch does not explain it.',
    comparison_limits=['Different product closures/binaries and run dates; no controlled old-binary rerun in this slice.',
        'Old six BF16 runs included WDDM 50ms memory monitor; current six runs have no monitor/profiler.',
        'No attribution of the historical-vs-current Commands difference from offline timing alone.',
        'No additional GPU run or model-quality acceptance.'])
(HERE / 'history-boundary-review.json').write_text(json.dumps(review, indent=2) + '\n')
print(json.dumps(review['current_warm_samples'], indent=2))
