from pathlib import Path
import importlib.util
import json
import os
import re
import statistics
import sys

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('capture_reuse_driver', HERE.parent / 'build.py')
driver = importlib.util.module_from_spec(spec)
spec.loader.exec_module(driver)
b = driver.previous
b.OUT = HERE
audit = b.read(HERE / 'historical-bf16-link-audit.json')
old = HERE / 'historical-bf16-accepted/accepted.exe'
current = HERE / 'qwen-reuse.exe'
libraries = [str(Path(value).parent) for value in audit['relink_proposal']['command']
             if Path(value).is_absolute() and value.lower().endswith('.lib')]
b.ENV['PATH'] = os.pathsep.join(dict.fromkeys(libraries)) + os.pathsep + b.ENV['PATH']
fixture = b.ARCH / 'qwen-gpu-comparison/128-prefill'
inputs, tape = fixture / 'inputs', fixture / 'decode.ids'
expected_ids = b.read(HERE / 'performance-summary.json')['runs'][0]['output']['generated_ids']
order = ['old', 'current', 'current', 'old', 'old', 'current']
plan = dict(status='one_authorized_bounded_historical_control',
    old_image=b.ident(old), current_image=b.ident(current), old_ABI=16, current_ABI=17,
    old_119_inputs_audit=b.ident(HERE / 'historical-bf16-link-audit.json'),
    order=['old/current', 'current/old', 'old/current'], prompt=b.ident(inputs / 'prompt.ids'),
    tape=b.ident(tape), model_manifest=b.ident(inputs / 'weights.tsv'),
    profiler=False, memory_monitor=False, mode='Commands for both', commands=[])
for index, arm in enumerate(order):
    args = [str(old if arm == 'old' else current), '--inputs', str(inputs),
            '--decode-ids', str(tape), '--capacity', '256', '--progress', 'direct']
    if arm == 'current':
        args += ['--replay', 'commands']
    plan['commands'].append(dict(tag=f'historical128-{index+1}-{arm}', arm=arm, command=args))
b.save('historical-control-plan.json', plan)
results = []
for request in plan['commands']:
    b.execute(request['tag'], request['command'], timeout=120)
    row = next(item for item in b.read(HERE / 'commands.json') if item['tag'] == request['tag'])
    text = (HERE / row['stderr']).read_text()
    output = json.loads((HERE / row['stdout']).read_text())
    assert output['generated_ids'] == expected_ids
    phases = [dict(phase=phase, tokens=int(tokens), visible=int(visible),
        submit_to_token_seconds=float(seconds), submit_seconds=float(submit),
        step_seconds=float(step), next_token=int(next_token))
        for phase, tokens, visible, seconds, submit, step, next_token in re.findall(
            r'^(prefill|decode\d+) tokens=(\d+) visible=(\d+) seconds=(\S+) '
            r'submit_seconds=(\S+) step_seconds=(\S+) progress=direct next=(\d+)', text, re.M)]
    assert len(phases) == 32 and phases[7]['phase'] == 'decode7'
    assert all(phase['step_seconds'] >= phase['submit_to_token_seconds'] >= phase['submit_seconds']
               for phase in phases)
    result = dict(arm=request['arm'], command_index=b.read(HERE / 'commands.json').index(row)+1,
        tag=request['tag'], pid=row['pid'], exit=row['exit'], stdout=row['stdout'], stderr=row['stderr'],
        phases=phases, output=output, prefill_tokens_per_second=128/phases[0]['step_seconds'],
        full_decode_tokens_per_second=31/sum(phase['step_seconds'] for phase in phases[1:]),
        warm_decode7_to31_tokens_per_second=25/sum(phase['step_seconds'] for phase in phases[7:]))
    results.append(result)
    b.save('historical-control-results.json', dict(runs=results, pending=6-len(results)))
samples = {arm: {metric: [row[metric] for row in results if row['arm'] == arm]
                 for metric in ['prefill_tokens_per_second', 'full_decode_tokens_per_second',
                                'warm_decode7_to31_tokens_per_second']}
           for arm in ['old', 'current']}
medians = {arm: {metric: statistics.median(values) for metric, values in group.items()}
           for arm, group in samples.items()}
b.save('historical-control-summary.json', dict(status='six_processes_terminal_zero',
    plan=b.ident(HERE / 'historical-control-plan.json'), runs=results, samples=samples, medians=medians,
    all_32_generated_ids_equal=True, profiler=False, memory_monitor=False,
    external_gpu_confound='Root observed user GameViewerServer background engines after original six runs; not stopped. Does not establish activity during each timing or sole cause.',
    quality_acceptance=False, no_more_gpu_runs=True))
print(json.dumps(dict(samples=samples, medians=medians), indent=2), flush=True)
