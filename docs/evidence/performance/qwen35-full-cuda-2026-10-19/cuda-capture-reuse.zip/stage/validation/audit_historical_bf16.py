from pathlib import Path
import hashlib
import json

HERE = Path(__file__).resolve().parent
ARCH = HERE.parents[1]


def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def identity(path):
    return dict(path=str(path.resolve()), bytes=path.stat().st_size,
                sha256=hashlib.sha256(path.read_bytes()).hexdigest())


old = ARCH / 'cuda-bfloat-elementwise-build'
baseline = ARCH / 'qwen-decode-native-route/link-input-identities.json'
expected = {row['path']: (row, str(baseline)) for row in read(baseline)}
for name in ['ggml-cuda', 'binbcast', 'unary', 'tensor-current']:
    receipt = old / (name + '-identity.json')
    row = read(receipt)['object']
    expected[row['path']] = (row, str(receipt))
plan_path = old / 'candidate-link-plan.json'
original = read(plan_path)['command']
inputs = [Path(value) for value in original if Path(value).is_absolute()
          and Path(value).suffix.lower() in ['.obj', '.lib']]
checked = []
for path in inputs:
    frozen, receipt = expected[str(path)]
    actual = identity(path)
    assert actual == frozen, dict(expected=frozen, actual=actual)
    checked.append(dict(**actual, original_identity_receipt=receipt, matched=True))
provider_before = ARCH / 'cuda-coarse-capture/generic-hooks/before/src/compute/provider_internal.h'
assert 'kProviderContractVersion = 16' in provider_before.read_text()
assert all('cuda-coarse-capture-tests' not in str(path) and 'cuda-capture-reuse' not in str(path)
           for path in inputs)
out = HERE / 'historical-bf16-accepted'
command = [value for value in original
           if not value.upper().startswith(('/OUT:', '/MAP:', '/IMPLIB:', '/PDB:'))]
command += ['/OUT:' + str(out / 'accepted.exe'), '/MAP:' + str(out / 'accepted.map'),
            '/IMPLIB:' + str(out / 'accepted.lib')]
image = read(old / 'perf128-06-candidate/command.json')['binary']
summary = dict(status='complete_historical_inputs_verified_relink_proposal_not_executed',
    original_link_plan=identity(plan_path), original_image_identity=image,
    reference_performance=dict(metrics=identity(old / 'perf128-06-candidate/metrics.json'),
        warm_decode7_to31=read(old / 'perf128-06-candidate/metrics.json')['decode_warm_tokens_per_second']),
    input_count=len(inputs), objects=sum(path.suffix.lower() == '.obj' for path in inputs),
    libraries=sum(path.suffix.lower() == '.lib' for path in inputs),
    input_bytes=sum(row['bytes'] for row in checked), missing=[], identity_mismatches=[],
    provider_contract=16, provider_before_snapshot=identity(provider_before),
    expected_current_product_contract=17,
    original_consumer=identity(ARCH / 'qwen-gpu-comparison/candidate/main.cc'),
    original_native_bridge=read(old / 'input-identities.json')['headers'],
    declared_inputs=checked,
    relink_proposal=dict(command=command, output_directory=str(out), executed=False,
        allowed_changes='Only output/map/import-library paths. All original 119 input identities/order/flags retained.',
        compilation=False, sdk_rebuild=False, new_abi_object_substitution=False),
    boundary='Historical-only executable. Current canonical headers/source have changed; do not compile any old owner against current17 or insert any current17 object.',
    runtime_note='Reuse original DLL search paths/import libraries. Old monitor/profile settings are separate from link reconstruction.',
    gpu_run=False)
(HERE / 'historical-bf16-link-audit.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps({key: summary[key] for key in ['status', 'input_count', 'objects', 'libraries',
    'input_bytes', 'provider_contract', 'identity_mismatches']}, indent=2))
