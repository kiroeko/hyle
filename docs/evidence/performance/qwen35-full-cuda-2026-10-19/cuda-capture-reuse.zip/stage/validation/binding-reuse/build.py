from pathlib import Path
import importlib.util
import json
import os
import re
import sys

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
BASE = HERE.parent
spec = importlib.util.spec_from_file_location('reuse_build_helpers', BASE.parent / 'build.py')
driver = importlib.util.module_from_spec(spec)
spec.loader.exec_module(driver)
b = driver.previous
b.OUT = HERE


def compile_provider():
    frozen = b.read(BASE.parent / 'ggml-binding-reuse/source-freeze.json')
    assert b.ident(frozen['source']['path']) == frozen['source']
    rows = b.read(driver.PREVIOUS / 'current-host-owners.json')['owners']
    old = next(row for row in rows if row['source'] == 'src/compute_provider_ggml_cuda/ggml_cuda_provider.cc')
    b.compile_one(old['source'], 'ggml-provider', b.read(old['receipt'])['command'])


def link(kind):
    original = BASE / (kind + '-link-plan.json')
    plan = b.read(original)
    old = next(row for row in b.read(driver.PREVIOUS / 'current-host-owners.json')['owners']
               if row['source'] == 'src/compute_provider_ggml_cuda/ggml_cuda_provider.cc')
    current = b.read(HERE / 'ggml-provider-identity.json')
    assert b.ident(current['object']['path']) == current['object']
    args = plan['command']
    assert args.count(old['object']['path']) == 1
    args = [current['object']['path'] if value == old['object']['path'] else value
            for value in args if not value.upper().startswith(('/OUT:', '/MAP:', '/IMPLIB:', '/PDB:'))]
    if kind == 'cuda':
        direct = b.read(b.ARCH / 'cuda-bfloat-elementwise-tests/tensor-test-identity.json')
        assert b.ident(direct['object']['path']) == direct['object']
        assert b.ident(direct['source']['path']) == direct['source']
        args.insert(1, direct['object']['path'])
    output = HERE / (kind + '-final')
    args += ['/OUT:' + str(output.with_suffix('.exe')), '/MAP:' + str(output.with_suffix('.map')),
             '/IMPLIB:' + str(output.with_suffix('.lib'))]
    b.save(kind + '-link-plan.json', dict(command=args, parent=b.ident(original),
        replacement=dict(before=old, after=current), retained_direct_test=direct if kind == 'cuda' else None))
    b.execute(kind + '-link', args)
    b.save(kind + '-image.json', dict(image=b.ident(output.with_suffix('.exe')),
                                     map=b.ident(output.with_suffix('.map'))))
    if kind == 'cuda':
        tests = list(driver.PLAN['cuda_filters']) + ['GgmlCudaTensor.BfloatTypedElementwiseBroadcastsAndRebindsIndependentSlots']
        b.save('cuda-run-plan.json', dict(command=[str(output.with_suffix('.exe')), '--gtest_color=no',
            '--gtest_filter=' + ':'.join(tests), '--gtest_output=xml:' + str(HERE / 'cuda-tests.xml')],
            tests=tests, timeout_seconds=90, not_run=True))


def runtime():
    libraries = [str(Path(value).parent) for value in b.read(driver.PLAN['base_link_plan']['path'])['command']
                 if Path(value).is_absolute() and value.lower().endswith('.lib')]
    b.ENV['PATH'] = os.pathsep.join(dict.fromkeys(libraries)) + os.pathsep + b.ENV['PATH']


def run_cuda():
    runtime()
    plan = b.read(HERE / 'cuda-run-plan.json')
    plan['not_run'] = False
    b.save('cuda-run-plan.json', plan)
    b.execute('cuda-six-focused-tests-run', plan['command'], timeout=plan['timeout_seconds'])


def analyze_pair():
    arms = {}
    vectors = []
    rows = b.read(HERE / 'commands.json')
    previous = b.read(BASE / 'decision-vector-archive-references.json')
    for mode in ['commands', 'prefer-capture']:
        row = next(row for row in rows if row['tag'] == 'qwen-' + mode + '-probe-run')
        stderr = (HERE / row['stderr']).read_text()
        prepared = [dict(T=int(t), visible=int(v), route=route, cold_seconds=float(cold),
                         recorded=int(recorded), reused=int(reused))
                    for t, v, route, cold, recorded, reused in re.findall(
                        r'prepared T=(\d+) visible=(\d+) replay=(\S+) cold_batch_seconds=(\S+) capture_recorded=(\d+) capture_reused=(\d+)', stderr)]
        assert len(prepared) == 4, stderr
        arms[mode] = dict(command_index=rows.index(row)+1, pid=row['pid'], exit=row['exit'],
                          prepared=prepared, output=json.loads((HERE / row['stdout']).read_text()))
    assert arms['commands']['output']['generated_ids'] == arms['prefer-capture']['output']['generated_ids']
    assert [(r['recorded'], r['reused']) for r in arms['prefer-capture']['prepared']] == [(7, 0)] * 3 + [(0, 7)]
    for old in previous['vectors']:
        paths = [HERE / ('trace-' + mode) / old['relative'] for mode in ['commands', 'prefer-capture']]
        ids = [b.ident(path) for path in paths]
        assert all(i['sha256'] == old['sha256'] and i['bytes'] == old['bytes'] for i in ids)
        vectors.append(dict(relative=old['relative'], equal=True, commands=ids[0], prefer_capture=ids[1],
                            archived_entry=old['archived_entry'], sha256=old['sha256']))
        old['current_paths'] = [old['commands_path'], old['prefer_path']] + list(map(str, paths))
    b.save('qwen-probe-summary.json', dict(status='final_provider_same_8_payloads_and_real_reuse', arms=arms,
        paired_vectors=vectors, original_archive=previous['archive'], quality_acceptance=False))
    b.save('decision-vector-archive-references.json', previous)


if __name__ == '__main__':
    action = sys.argv[1]
    if action == 'compile': compile_provider()
    elif action == 'link': link(sys.argv[2])
    elif action == 'run-cuda': run_cuda()
    elif action == 'analyze-pair': analyze_pair()
    else: raise ValueError(action)
