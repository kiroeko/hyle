from pathlib import Path
import hashlib
import json
import statistics
import xml.etree.ElementTree as ET

HERE = Path(__file__).resolve().parent
BASE = HERE.parent
STAGE = BASE.parent
ARCH = STAGE.parent
ROOT = ARCH.parents[1]


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def ident(path):
    path = Path(path)
    return dict(path=str(path.resolve()), bytes=path.stat().st_size,
                sha256=hashlib.sha256(path.read_bytes()).hexdigest())


def save(path, value):
    Path(path).write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8')


prior = read(BASE / 'final-selected-owners.json')
owners = prior['current_local_owners'] + [dict(receipt=ident(HERE / 'ggml-provider-identity.json'),
                                               **read(HERE / 'ggml-provider-identity.json'))]
assert len(owners) == 18
dependencies = {}
for owner in owners:
    assert ident(owner['object']['path']) == owner['object']
    for expected in [owner['source']] + owner.get('current_hyle_dependency_identities', []):
        actual = dependencies.setdefault(expected['path'], ident(expected['path']))
        assert actual == expected, dict(owner=owner['source'], expected=expected, actual=actual)
save(HERE / 'filtered-current-dependencies.json', dict(files=list(dependencies.values()),
    source_drift_count=0, scope='18 actual current local host/test owners; original native/SDK receipts retained unchanged.'))
direct_path = ARCH / 'cuda-bfloat-elementwise-tests/tensor-test-identity.json'
direct = read(direct_path)
assert ident(direct['object']['path']) == direct['object']
assert ident(direct['source']['path']) == direct['source']
retained = [row for row in prior['retained_selected_provider17_host_owners']
            if not row['source']['path'].endswith('compute_provider_ggml_cuda\\ggml_cuda_provider.cc')]
save(HERE / 'final-selected-owners.json', dict(current_local_owners=owners,
    retained_selected_provider17_host_owners=retained, native_main=prior['native_main'],
    direct_test=dict(receipt=ident(direct_path), source=direct['source'], object=direct['object']),
    initial_and_v2_closure=ident(BASE / 'final-selected-owners.json'),
    fresh_product_TUs_this_final_phase=1, native_sdk_compilations=0))
maps = {}
for kind in ['cuda', 'qwen']:
    plan = read(HERE / (kind + '-link-plan.json'))
    index = {}
    with (HERE / (kind + '-final.map')).open(errors='replace') as stream:
        for line in stream:
            fields = line.split()
            if fields and fields[-1].lower().endswith('.obj'):
                record = index.setdefault(fields[-1].lower(), dict(count=0, sample=[]))
                record['count'] += 1
                if len(record['sample']) < 2: record['sample'].append(line.strip())
    provider = index['ggml-provider.obj']
    assert provider['count'] > 0
    old_name = Path(plan['replacement']['before']['object']['path']).name.lower()
    assert old_name not in index
    native_name = Path(prior['native_main']['object']['path']).name.lower()
    assert index[native_name]['count'] > 0
    maps[kind] = dict(map=ident(HERE / (kind + '-final.map')), provider=provider,
        old_provider_symbols=0, native_main=index[native_name], selected_current_owners=[
            dict(source=o['source'], object=o['object'], map_symbols=index.get(Path(o['object']['path']).name.lower()))
            for o in owners if o['object']['path'] in plan['command']])
save(HERE / 'final-map-owners.json', maps)
perf = read(HERE / 'performance-summary.json')
for row in perf['runs']:
    row['warm_decode7_31_tokens_per_second'] = 25 / sum(step['step_seconds'] for step in row['steps'][7:])
for mode in ['commands', 'prefer-capture']:
    perf['medians'][mode]['warm_decode7_31_tokens_per_second'] = statistics.median(
        r['warm_decode7_31_tokens_per_second'] for r in perf['runs'] if r['mode'] == mode)
perf['phase'] = 'final_after_ggml_bindings_ready_fastpath_d155f512'
perf['warm_range'] = 'decode7..31 inclusive;25 steps,full step_seconds'
save(HERE / 'performance-summary.json', perf)
xml = ET.parse(HERE / 'cuda-tests.xml').getroot()
assert int(xml.attrib['tests']) == 6 and int(xml.attrib['failures']) == 0
test_names = [suite.attrib['name'] + '.' + case.attrib['name']
              for suite in xml.findall('testsuite') for case in suite.findall('testcase')]
assert len(test_names) == 6
commands = read(HERE / 'commands.json')
assert len(commands) == 12 and all(row['exit'] == 0 and row['terminal'] for row in commands)
initial = read(BASE / 'summary.json')
summary = dict(status='final_one_host_fix_verified_all_terminal_gpu_released',
    final_source=owners[-1]['source'], final_object=owners[-1]['object'],
    strict_host_compilation=dict(command_index=1, exit=0, native_sdk_compilations=0),
    final_links=dict(cuda=2, qwen=3), final_cuda=dict(command_index=4, tests=test_names,
        count=6, failures=0, xml=ident(HERE / 'cuda-tests.xml')),
    full_slice_unique_tests=dict(count=17, cpu=11, cuda=6,
        explanation='Prior CPU11 plus finalCUDA6;initialCUDA5 repeated within final6 and counted once.'),
    functional_pair=dict(command_indices=[5, 6], summary=ident(HERE / 'qwen-probe-summary.json'),
        bit_identical_payloads=8, same_prior_caller_archive=True, decode3_recorded=0, decode3_reused=7),
    final_performance=dict(command_indices=list(range(7, 13)), order=['B/A', 'A/B', 'B/A'],
        A='commands', B='prefer-capture', medians=perf['medians'],
        warm_range='decode7..31', full_step_includes_cold=True, all_32_generated_ids_equal=True,
        profiler=False, memory_monitor=False),
    initial_capture_reuse_result=ident(BASE / 'summary.json'),
    initial_performance=ident(BASE / 'performance-summary.json'),
    historical_old_current_control=ident(BASE / 'historical-control-summary.json'),
    historical_control_conclusion='Old79.84wasnotreproduced in samecurrentenvironment;initial/history/final remain distinct.',
    external_gpu_observation=ident(BASE / 'background-gpu-observation.json'),
    limits=['No model-quality acceptance;Torch reference~2% question unchanged.',
        'Background GameViewerServer GPU activity is a real confound,not a proven sole cause.',
        'No new profiler,memory,peer,SDK or native math run in this finalphase.'],
    source_dependency_drift_count=0, quality_acceptance=False, live=False, gpu_released=True)
save(HERE / 'summary.json', summary)
old_cleanup = read(BASE / 'cleanup-windows.json')
images = [ident(HERE / (kind + '-final' + ext)) for kind in ['cuda', 'qwen']
          for ext in ['.exe', '.map', '.lib', '.exp']]
raw = old_cleanup['retained_raw_vectors'] + [ident(r['path']) for mode in ['commands', 'prefer-capture']
        for r in read(HERE / ('qwen-' + mode + '-decisions.json'))['files']]
cleanup = dict(workspace=str(ROOT), root=str(STAGE), files=old_cleanup['files'] + images,
    count=len(old_cleanup['files']) + len(images), bytes=sum(row['bytes'] for row in old_cleanup['files'] + images),
    images=old_cleanup['images'] + images, stale_initial_objects=old_cleanup['stale_initial_objects'],
    retained_objects=[owner['object'] for owner in owners] + [direct['object']],
    retained_local_objects=18, retained_cached_direct_objects=1, retained_raw_vectors=raw,
    delete_executed=False, note='All prior SDK/native/cache objects retained;only9 obsolete initial objects targeted.')
assert cleanup['count'] == 33 and len(raw) == 32
save(HERE / 'cleanup-windows.json', cleanup)
save(BASE / 'final-summary.json', dict(final=ident(HERE / 'summary.json'),
    initial=ident(BASE / 'summary.json'), historical=ident(BASE / 'historical-control-summary.json'),
    cleanup=ident(HERE / 'cleanup-windows.json'), live=False, quality_acceptance=False))
print(json.dumps(dict(medians=perf['medians'], cleanup_count=cleanup['count'],
    cleanup_bytes=cleanup['bytes'], retained_objects=19, retained_raw_vectors=32), indent=2))
