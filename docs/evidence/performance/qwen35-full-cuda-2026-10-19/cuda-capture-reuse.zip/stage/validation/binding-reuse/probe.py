from pathlib import Path
import importlib.util
import os
import sys

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('capture_reuse_driver', HERE.parent.parent / 'build.py')
driver = importlib.util.module_from_spec(spec)
spec.loader.exec_module(driver)
b = driver.previous
b.OUT = HERE
mode = sys.argv[1]
assert mode in ['commands', 'prefer-capture']
base = b.read(driver.PLAN['base_link_plan']['path'])['command']
libraries = [str(Path(value).parent) for value in base
             if Path(value).is_absolute() and value.lower().endswith('.lib')]
b.ENV['PATH'] = os.pathsep.join(dict.fromkeys(libraries)) + os.pathsep + b.ENV['PATH']
inputs = b.ARCH / 'qwen-fixed-decode/science-inputs'
tape = driver.PREVIOUS / 'decode-3.ids'
assert len((inputs / 'prompt.ids').read_text().split()) == 21
assert len(tape.read_text().split()) == 3
trace = HERE / ('trace-' + mode)
assert not trace.exists(), 'No implicit model rerun/trace overwrite'
args = [str(HERE / 'qwen-final.exe'), '--inputs', str(inputs),
        '--decode-ids', str(tape), '--steps', '4', '--capacity', '256',
        '--progress', 'direct', '--replay', mode,
        '--trace-level', 'decisions', '--trace', str(trace)]
b.save('qwen-' + mode + '-run-plan.json', dict(command=args,
    image=b.ident(HERE / 'qwen-final.exe'), prompt=b.ident(inputs / 'prompt.ids'),
    model_manifest=b.ident(inputs / 'weights.tsv'), tape=b.ident(tape),
    description='Same actual 21-token prompt + three fixed decode inputs, original two slots; no profiler.'))
b.execute('qwen-' + mode + '-probe-run', args, timeout=120)
files = sorted(path for path in trace.rglob('*')
               if path.is_file() and path.suffix in ['.f32', '.bf16'])
assert len(files) == 8, len(files)
b.save('qwen-' + mode + '-decisions.json', dict(files=[
    dict(relative=str(path.relative_to(trace)), **b.ident(path)) for path in files]))
