from pathlib import Path
import importlib.util
import json
import os
import re
import statistics
import sys

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('capture_reuse_driver', HERE.parent.parent / 'build.py')
driver = importlib.util.module_from_spec(spec)
spec.loader.exec_module(driver)
b = driver.previous
b.OUT = HERE
guard = b.read(HERE / 'qwen-probe-summary.json')
assert len(guard['paired_vectors']) == 8 and all(row['equal'] for row in guard['paired_vectors'])
assert [(row['recorded'], row['reused']) for row in guard['arms']['prefer-capture']['prepared']] == [(7, 0), (7, 0), (7, 0), (0, 7)]
base = b.read(driver.PLAN['base_link_plan']['path'])['command']
libraries = [str(Path(value).parent) for value in base
             if Path(value).is_absolute() and value.lower().endswith('.lib')]
b.ENV['PATH'] = os.pathsep.join(dict.fromkeys(libraries)) + os.pathsep + b.ENV['PATH']
fixture = b.ARCH / 'qwen-gpu-comparison/128-prefill'
inputs, tape = fixture / 'inputs', fixture / 'decode.ids'
assert len((inputs / 'prompt.ids').read_text().split()) == 128
assert len(tape.read_text().split()) == 31
assert (inputs / 'weights.tsv').read_bytes() == (b.ARCH / 'qwen-fixed-decode/science-inputs/weights.tsv').read_bytes()
image = b.ident(HERE / 'qwen-final.exe')
plan = dict(image=image, prompt=b.ident(inputs / 'prompt.ids'), tape=b.ident(tape),
    model_manifest=b.ident(inputs / 'weights.tsv'), A='commands', B='prefer-capture',
    pair_order=['B/A', 'A/B', 'B/A'], profiler=False, memory_monitor=False,
    metric='Full step_seconds from before token/position uploads through token readback; includes cold prepare.',
    commands=[])
for index, mode in enumerate(['prefer-capture', 'commands', 'commands',
                              'prefer-capture', 'prefer-capture', 'commands']):
    tag = 'qwen128-' + str(index + 1) + '-' + mode
    args = [str(HERE / 'qwen-final.exe'), '--inputs', str(inputs), '--decode-ids', str(tape),
            '--steps', '32', '--capacity', '256', '--progress', 'direct', '--replay', mode]
    plan['commands'].append(dict(tag=tag, mode=mode, argv=args))
b.save('performance-plan.json', plan)
results = []
for request in plan['commands']:
    b.execute(request['tag'], request['argv'], timeout=120)
    row = next(item for item in b.read(HERE / 'commands.json') if item['tag'] == request['tag'])
    stderr = (HERE / row['stderr']).read_text()
    output = json.loads((HERE / row['stdout']).read_text())
    steps = [dict(phase=phase, tokens=int(tokens), visible=int(visible),
                  submit_to_token_seconds=float(seconds), submit_seconds=float(submit),
                  step_seconds=float(step), next_token=int(next_token))
             for phase, tokens, visible, seconds, submit, step, next_token in re.findall(
                 r'^(prefill|decode\d+) tokens=(\d+) visible=(\d+) seconds=(\S+) '
                 r'submit_seconds=(\S+) step_seconds=(\S+) progress=direct next=(\d+)', stderr, re.M)]
    captures = [dict(recorded=int(recorded), reused=int(reused)) for recorded, reused in re.findall(
        r'capture_recorded=(\d+) capture_reused=(\d+)', stderr)]
    assert len(steps) == len(captures) == 32
    assert all(step['step_seconds'] >= step['submit_to_token_seconds'] >= step['submit_seconds']
               for step in steps)
    if request['mode'] == 'prefer-capture':
        assert [(item['recorded'], item['reused']) for item in captures] == [(7, 0)] * 3 + [(0, 7)] * 29
    else:
        assert all(item['recorded'] == item['reused'] == 0 for item in captures)
    if results:
        assert output['generated_ids'] == results[0]['output']['generated_ids']
        assert output['decode_input_ids'] == results[0]['output']['decode_input_ids']
    result = dict(tag=request['tag'], mode=request['mode'], command_index=b.read(HERE / 'commands.json').index(row) + 1,
        pid=row['pid'], exit=row['exit'], stdout=row['stdout'], stderr=row['stderr'],
        steps=steps, captures=captures, output=output,
        prefill_tokens_per_second=128 / steps[0]['step_seconds'],
        full_decode_tokens_per_second=31 / sum(step['step_seconds'] for step in steps[1:]))
    results.append(result)
    b.save('performance-results.json', dict(runs=results, pending=len(plan['commands'])-len(results)))
medians = {mode: {metric: statistics.median(row[metric] for row in results if row['mode'] == mode)
                  for metric in ['prefill_tokens_per_second', 'full_decode_tokens_per_second']}
           for mode in ['commands', 'prefer-capture']}
b.save('performance-summary.json', dict(status='six_processes_terminal_zero', pair_order=plan['pair_order'],
    runs=results, medians=medians, full_step_includes_cold=True, profiler=False, memory_monitor=False,
    bitwise_scope='8 decision payloads of separate 21+3 functional pair only; timed 128+31 runs compare all generated IDs.',
    quality_acceptance=False))
print(json.dumps(medians, indent=2), flush=True)
