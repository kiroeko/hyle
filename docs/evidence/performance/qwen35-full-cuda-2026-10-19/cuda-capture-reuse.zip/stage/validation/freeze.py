from pathlib import Path
import hashlib
import json
import xml.etree.ElementTree as ET

HERE = Path(__file__).resolve().parent
STAGE, ARCH, ROOT = HERE.parent, HERE.parents[1], HERE.parents[3]
OLD = ARCH / 'cuda-coarse-capture-tests'


def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def save(name, value):
    (HERE / name).write_text(json.dumps(value, indent=2) + '\n')


def identity(path):
    path = Path(path)
    return dict(path=str(path.resolve()), bytes=path.stat().st_size,
                sha256=hashlib.sha256(path.read_bytes()).hexdigest())


local = [HERE / (row['name'] + '-identity.json') for row in read(HERE / 'v2-plan.json')['rows']]
local += [STAGE / (name + '-identity.json') for name in [
    'graph_batch--batch', 'torch-reuse-test', 'graph-cuda-control-test', 'qwen-consumer']]
owners = [dict(receipt=identity(path), **read(path)) for path in local]
cached = {}
drift = []
for owner in owners:
    assert identity(owner['object']['path']) == owner['object']
    for expected in [owner['source']] + owner.get('current_hyle_dependency_identities', []):
        path = expected['path']
        actual = cached.setdefault(path, identity(path))
        if actual != expected:
            drift.append(dict(expected=expected, actual=actual, owner=owner['source']['path']))
assert not drift, drift
save('filtered-current-dependencies.json', dict(scope='Only actual dependencies of 17 current local owners; retained SDK/native base is referenced by original receipts.',
    files=list(cached.values()), source_drift=drift, source_drift_count=0))
plans = {kind: read(HERE / (kind + '-link-plan.json')) for kind in ['cpu', 'cuda', 'qwen']}
all_objects = {value for plan in plans.values() for value in plan['command']
               if value.lower().endswith('.obj')}
current_sources = {owner['source']['path'] for owner in owners}
retained = []
for row in read(OLD / 'current-host-owners.json')['owners']:
    if row['object']['path'] not in all_objects:
        continue
    receipt = Path(row['receipt'])
    data = read(receipt)
    if data['source']['path'] not in current_sources:
        assert identity(data['source']['path']) == data['source']
        retained.append(dict(source=data['source'], object=data['object'], receipt=identity(receipt)))
for name in ['sglang-checked-test', 'ggml-mean-test']:
    path = OLD / (name + '-identity.json')
    data = read(path)
    assert identity(data['source']['path']) == data['source']
    retained.append(dict(source=data['source'], object=data['object'], receipt=identity(path)))
native_path = OLD / 'ggml-cuda-record-cub-identity.json'
native = read(native_path)
assert identity(native['source']['path']) == native['source']
assert identity(native['object']['path']) == native['object']
save('final-selected-owners.json', dict(current_local_owners=owners,
    retained_selected_provider17_host_owners=retained,
    native_main=dict(source=native['source'], object=native['object'], receipt=identity(native_path)),
    original_link_plan=identity(OLD / 'qwen-capture-link-plan.json'),
    cpu_carrier=identity(OLD / 'cpu-controls-link-plan.json'),
    native_sdk_compilations_this_slice=0))
maps = {}
for kind, plan in plans.items():
    index = {}
    with (HERE / (kind + '-reuse.map')).open(errors='replace') as stream:
        for line in stream:
            fields = line.split()
            if fields and fields[-1].lower().endswith('.obj'):
                key = fields[-1].lower()
                record = index.setdefault(key, dict(count=0, sample=[]))
                record['count'] += 1
                if len(record['sample']) < 2:
                    record['sample'].append(line.strip())
    selected = []
    for owner in owners:
        obj = owner['object']['path']
        if obj in plan['command']:
            selected.append(dict(source=owner['source'], object=owner['object'],
                map_symbols=index.get(Path(obj).name.lower(), dict(count=0, sample=[]))))
    maps[kind] = dict(map=read(HERE / (kind + '-image.json'))['map'], selected_current_owners=selected,
        native_main=index.get(Path(native['object']['path']).name.lower(), dict(count=0, sample=[])))
    if kind != 'cpu':
        assert maps[kind]['native_main']['count'] > 0
save('final-map-owners.json', maps)
original = read(OLD / 'decision-vector-archive-references.json')
prior = {row['relative']: row for row in original['vectors']}
current = read(HERE / 'qwen-commands-decisions.json')['files']
capture = {row['relative']: row for row in read(HERE / 'qwen-prefer-capture-decisions.json')['files']}
refs = []
for row in current:
    previous = prior[row['relative']]
    other = capture[row['relative']]
    assert (row['bytes'], row['sha256']) == (previous['bytes'], previous['sha256']) == (other['bytes'], other['sha256'])
    refs.append(dict(relative=row['relative'], bytes=row['bytes'], sha256=row['sha256'],
        commands_path=row['path'], prefer_path=other['path'],
        archived_entry=previous['archived_entry'], archived_crc32=previous['archived_crc32']))
save('decision-vector-archive-references.json', dict(archive=original['archive'],
    original_receipt=original['original_receipt'], vectors=refs,
    verification='All 16 current raw payload SHA/bytes match the existing 8 prior archive identities. Main archiver will independently CRC/SHA-check entries; no raw copied.'))
images = [identity(path) for stem in ['cpu-reuse', 'cuda-reuse', 'qwen-reuse']
          for extension in ['.exe', '.map', '.lib', '.exp']
          if (path := HERE / (stem + extension)).is_file()]
if (HERE / 'historical-bf16-image.json').exists():
    images += [identity(HERE / 'historical-bf16-accepted' / ('accepted' + extension))
               for extension in ['.exe', '.map', '.lib', '.exp']]
assert len(images) in [12, 16]
stale = []
for name in ['graph--constant_artifact', 'graph--executable', 'graph--input_sources',
             'graph--region_access', 'graph--resources', 'graph--resource_report',
             'graph--submission', 'graph_progress--progress', 'region-control-test']:
    old = read(STAGE / (name + '-identity.json'))
    changed = [item['path'] for item in [old['source']] + old['current_hyle_dependency_identities']
               if identity(item['path']) != item]
    assert changed, name
    stale.append(dict(**identity(STAGE / (name + '.obj')), stale_because=changed))
raw = [identity(row['path']) for mode in ['commands', 'prefer-capture']
       for row in read(HERE / ('qwen-' + mode + '-decisions.json'))['files']]
save('cleanup-windows.json', dict(workspace=str(ROOT), root=str(STAGE),
    images=images, stale_initial_objects=stale, files=images + stale,
    count=len(images) + len(stale), bytes=sum(row['bytes'] for row in images + stale),
    retained_objects=[owner['object'] for owner in owners], retained_raw_vectors=raw,
    previous_cache='All prior stage objects/SDK/native/model untouched; original link and source receipts retained.',
    delete_executed=False))
commands = read(HERE / 'commands.json')
initial = read(STAGE / 'commands.json')
assert all(row.get('terminal') and row['exit'] is not None for row in commands + initial)
tests = {}
for name in ['cpu', 'cuda']:
    tree = ET.parse(HERE / (name + '-tests.xml')).getroot()
    tests[name] = dict(tests=int(tree.attrib['tests']), failures=int(tree.attrib['failures']),
        disabled=int(tree.attrib['disabled']), xml=identity(HERE / (name + '-tests.xml')))
assert tests['cpu']['tests'] == 11 and tests['cuda']['tests'] == 5
assert all(row['failures'] == row['disabled'] == 0 for row in tests.values())
perf = read(HERE / 'performance-summary.json')
save('summary.json', dict(status='current_capture_reuse_validated_frozen_no_live_process',
    tests=tests, distinct_tests_passed=16,
    strict_compilations=dict(initial_13=13, final_v2_13=13, failures=0, native_sdk=0),
    historical_link_recipe_failures=[dict(command_index=index + 1, tag=row['tag'], exit=row['exit'],
        stdout=row['stdout'], stderr=row['stderr']) for index, row in enumerate(commands) if row['exit'] != 0],
    final_links=dict(cpu=16, cuda=18, qwen=20), functional_pair=dict(commands=21, prefer_capture=22,
        bit_identical_decision_payloads=8, decode3_recorded=0, decode3_reused=7),
    timed_128_pair=dict(command_indices=list(range(23, 29)), order=['B/A', 'A/B', 'B/A'],
        A='commands', B='prefer-capture', all_generated_ids_equal=True, medians=perf['medians'],
        full_step_includes_cold=True, warm_range='decode7..31', profiler=False, memory_monitor=False),
    old_79_84_boundary='Same full step_seconds/decode7..31. Historical accepted119-input image was reconstructed and measured in current environment; old79.84 not reproduced. See both history-boundary-review.json and historical-control-summary.json.',
    historical_control=(dict(summary=identity(HERE / 'historical-control-summary.json'),
        medians=read(HERE / 'historical-control-summary.json')['medians'],
        command_indices=list(range(30, 36)), all_generated_ids_equal=True,
        reconstructed_old_input_count=119, old_ABI=16, current_ABI=17)
        if (HERE / 'historical-control-summary.json').exists() else None),
    external_gpu_observation=(identity(HERE / 'background-gpu-observation.json')
        if (HERE / 'background-gpu-observation.json').exists() else None),
    actual_gpu='Qwen raw stderr: NVIDIA GeForce RTX 4070, SM8.9, 12281MiB; no model/SDK copy.',
    product_current_source_dependency_drift=0, quality_acceptance=False,
    gpu_released=True, live=False,
    cleanup=identity(HERE / 'cleanup-windows.json'),
    limits=['No independent model-quality acceptance; previous Torch~2% issue unchanged.',
        'No Linux/Apple/shared-memory capture proof or API expansion tested here.',
        'CPU mock captures assert control/lifetime; real CUDA test and Qwen prove actual math.',
        'Only this same-image 3pair capture comparison; no new peer/memory/profiler suite.']))
print(json.dumps(dict(tests=tests, retained_local_objects=len(owners), images=len(images),
    stale_initial_objects=len(stale), cleanup_bytes=sum(row['bytes'] for row in images + stale)), indent=2))
