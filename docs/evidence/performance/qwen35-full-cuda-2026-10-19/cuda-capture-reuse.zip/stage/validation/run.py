from pathlib import Path
import importlib.util
import os
import sys

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('capture_reuse_driver', HERE.parent / 'build.py')
driver = importlib.util.module_from_spec(spec)
spec.loader.exec_module(driver)
b = driver.previous
b.OUT = HERE
libraries = []
for name in ['cpu-controls-link-plan.json', 'qwen-capture-link-plan.json']:
    for value in b.read(driver.PREVIOUS / name)['command']:
        if Path(value).is_absolute() and value.lower().endswith('.lib'):
            libraries.append(str(Path(value).parent))
b.ENV['PATH'] = os.pathsep.join(dict.fromkeys(libraries)) + os.pathsep + b.ENV['PATH']
kind = sys.argv[1]
plan = b.read(HERE / (kind + '-run-plan.json'))
plan['not_run'] = False
b.save(kind + '-run-plan.json', plan)
b.execute(kind + '-focused-tests-run', plan['command'], timeout=plan['timeout_seconds'])
