#pragma once

#include "compute_provider_native/half_test_support.h"
#include "hyle/compute/cuda.h"
#include "hyle/compute/prepared_operation.h"
#include "hyle/compute/providers/cublas.h"
#include "hyle/compute/providers/ggml_cuda.h"

#include <array>
#include <bit>
#include <cstdint>
#include <vector>

namespace cuda_vector_matmul_test {
namespace c = hyle::compute;
namespace m = hyle::mem;

template <class T> struct Fixture final {
  std::int64_t rows, k, n;
  bool column_major;
  c::TensorDesc left_desc, right_desc, output_desc;
  std::vector<T> left_values, weight_values;
  m::Buffer left, weight, output;

  Fixture(m::MemoryResourceRef resource, std::int64_t inner,
          std::int64_t count = 1, bool transposed_weight = true)
      : rows(count), k(inner), n(37), column_major(transposed_weight),
        left_desc(c::TensorDesc::dense(half_test::data_type<T>(),
                                      std::array{rows, k}).value()),
        right_desc(transposed_weight
            ? c::TensorDesc::dense(half_test::data_type<T>(),
                                  std::array{n, k}).value().transposed().value()
            : c::TensorDesc::dense(half_test::data_type<T>(),
                                  std::array{k, n}).value()),
        output_desc(c::TensorDesc::dense(half_test::data_type<T>(),
                                        std::array{rows, n}).value()),
        left_values(static_cast<std::size_t>(rows * k)),
        weight_values(static_cast<std::size_t>(k * n)),
        left(m::Buffer::create(resource, *left_desc.required_bytes(), 256).value()),
        weight(m::Buffer::create(resource, *right_desc.required_bytes(), 256).value()),
        output(m::Buffer::create(resource, *output_desc.required_bytes(), 256).value()) {}

  hyle::Status write(int seed) {
    for (std::size_t i = 0; i < left_values.size(); ++i)
      left_values[i] = half_test::encode<T>(
          (static_cast<int>((i * 7 + seed * 3) % 9) - 4) / 16.0);
    for (std::size_t i = 0; i < weight_values.size(); ++i)
      weight_values[i] = half_test::encode<T>(
          (static_cast<int>((i * 5 + seed) % 11) - 5) / 16.0);
    HYLE_RETURN_IF_ERROR(left.view().write(std::as_bytes(std::span(left_values))));
    return weight.view().write(std::as_bytes(std::span(weight_values)));
  }
  std::array<c::ConstTensorView, 2> inputs() const {
    return {c::ConstTensorView::create(left_desc, left.view()).value(),
            c::ConstTensorView::create(right_desc, weight.view()).value()};
  }
  std::array<c::TensorView, 1> outputs() {
    return {c::TensorView::create(output_desc, output.view()).value()};
  }
  double reference(std::size_t index) const {
    const auto row = index / static_cast<std::size_t>(n);
    const auto col = index % static_cast<std::size_t>(n);
    double sum = 0;
    for (std::size_t j = 0; j < static_cast<std::size_t>(k); ++j) {
      const auto offset = column_major ? col * k + j : j * n + col;
      sum += half_test::decode(left_values[row * k + j]) *
             half_test::decode(weight_values[offset]);
    }
    return sum;
  }
  void check(const m::Buffer &buffer, bool negate = false) const {
    const auto actual = half_test::read<T>(buffer);
    ASSERT_EQ(actual.size(), static_cast<std::size_t>(rows * n));
    for (std::size_t i = 0; i < actual.size(); ++i) {
      const auto expected = half_test::encode<T>(
          negate ? -reference(i) : reference(i));
      if constexpr (std::is_same_v<T, float>)
        EXPECT_EQ(std::bit_cast<std::uint32_t>(actual[i]),
                  std::bit_cast<std::uint32_t>(expected)) << i;
      else
        EXPECT_EQ(actual[i].bits, expected.bits) << i;
    }
  }
};

} // namespace cuda_vector_matmul_test
