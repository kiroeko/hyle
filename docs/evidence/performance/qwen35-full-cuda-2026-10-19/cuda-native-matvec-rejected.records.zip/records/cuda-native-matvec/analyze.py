from array import array
from pathlib import Path
import hashlib, json, math, statistics
OUT=Path(__file__).resolve().parent;ARCH=OUT.parent
def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def ident(p):
 p=Path(p);b=p.read_bytes();return dict(path=str(p.resolve()),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
groups={}
for label in ('before','candidate'):
 rows=[read(p/'metrics.json') for p in sorted(OUT.glob('perf128-*-'+label))]
 assert len(rows)==3
 groups[label]={k:{'samples':[r[k] for r in rows],'median':statistics.median(r[k] for r in rows)} for k in ('prefill_tokens_per_second','decode_all_tokens_per_second','decode_warm_tokens_per_second')}
 groups[label]['GPU_GiB']={'samples':[r['memory']['sampled_peak_gpu_dedicated_bytes']/1024**3 for r in rows]}
 groups[label]['ids']=rows[0]['ids'];assert all(r['ids']==rows[0]['ids'] for r in rows)
vectors=[]
for count in (21,128):
 before=ARCH/f'ggml-cuda-caller-workspace/candidate{count}-decisions/trace'
 candidate=OUT/f'candidate{count}-decisions/trace'
 files=sorted([*candidate.glob('*/logits.f32'),*candidate.glob('*/hidden.bf16')]);assert len(files)==64
 for p in files:
  b=before/p.relative_to(candidate);old=b.read_bytes();new=p.read_bytes();assert len(old)==len(new)
  row=dict(scene=count,relative=str(p.relative_to(candidate)),before=ident(b),candidate=ident(p),byte_identical=old==new)
  if old!=new:
   if p.suffix=='.f32':
    a=array('f');a.frombytes(old);z=array('f');z.frombytes(new)
   else:
    a=array('H');a.frombytes(old);z=array('H');z.frombytes(new)
    def bf(v):
     temp=array('I',[v<<16]);f=array('f');f.frombytes(temp.tobytes());return f[0]
    a=list(map(bf,a));z=list(map(bf,z))
   assert all(math.isfinite(v) for v in (*a,*z))
   row.update(different_values=sum(x!=y for x,y in zip(a,z)),max_abs=max(abs(x-y) for x,y in zip(a,z)),relative_l2=math.sqrt(sum((x-y)**2 for x,y in zip(a,z))/max(sum(x*x for x in a),1e-300)))
  vectors.append(row)
result=dict(schema='hyle.cuda.native-matvec.experiment.v1',decision='Rejected as default optimization; product and two test TUs restored to exact pre-experiment sources. Candidate source, numeric checks and all failed/successful build attempts retained.',performance=groups,matching_prediction_ids_between_arms=groups['before']['ids']==groups['candidate']['ids'],vectors=vectors,byte_identical_vectors=sum(r['byte_identical'] for r in vectors),total_vectors=len(vectors),test_xml=ident(OUT/'tests.xml'),scope='3 paired unprofiled fresh process B/A,A/B,B/A; same inputs/own state/BF16 boundaries, context256, singleGPU, memory probe both arms; no claim of quality acceptance or general mmvf inferiority.')
(OUT/'summary.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'before_decode':groups['before']['decode_warm_tokens_per_second']['median'],'candidate_decode':groups['candidate']['decode_warm_tokens_per_second']['median'],'predictions_equal':result['matching_prediction_ids_between_arms'],'identical_vectors':result['byte_identical_vectors'],'vectors':len(vectors)}))
