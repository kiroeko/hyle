from pathlib import Path
import json, re, subprocess, sys, threading, time
sys.dont_write_bytecode = True
from build import OUT, ROOT, ARCH, ENV, ident, save, read
sys.path.insert(0, str(ARCH/'qwen-gpu-comparison/memory-probe'))
from memory_probe import MemoryProbe

BEFORE = ARCH/'qwen-decode-native-route/hyle.exe'

def trial(tag, candidate, prompt, trace=False):
    stage=OUT/tag; stage.mkdir(exist_ok=False)
    binary=OUT/'candidate.exe' if candidate else BEFORE
    inputs=ARCH/('qwen-gpu-comparison/128-prefill/inputs' if prompt==128 else 'qwen-fixed-decode/science-inputs')
    tape=ARCH/('qwen-gpu-comparison/128-prefill/decode.ids' if prompt==128 else 'qwen-fixed-decode/science-decode.ids')
    args=[str(binary),'--inputs',str(inputs),'--decode-ids',str(tape),'--capacity','256','--progress','direct']
    if trace: args+=['--trace',str(stage/'trace'),'--trace-level','decisions']
    row=dict(argv=args,binary=ident(binary),prompt_tokens=prompt,trace=trace,started=time.time())
    save(stage/'command.json',row)
    with MemoryProbe(interval_s=.05) as memory, (stage/'stdout.log').open('wb') as so,(stage/'stderr.log').open('wb') as se:
        p=subprocess.Popen(args,cwd=ROOT,env=ENV,stdout=so,stderr=se,creationflags=subprocess.CREATE_NO_WINDOW)
        row['pid']=p.pid; save(OUT/'live.json',row);memory.start(p.pid)
        row['exit']=p.wait();memory.stop();save(stage/'memory.json',memory.result())
    row.update(terminal=True,seconds=time.time()-row['started']);save(stage/'result.json',row);save(OUT/'live.json',row)
    print(tag,row['exit'],round(row['seconds'],3),flush=True)
    if row['exit']:
        print((stage/'stderr.log').read_text(errors='replace')[-8000:]);raise SystemExit(row['exit'])
    output=json.loads((stage/'stdout.log').read_text().splitlines()[-1])
    phases=[]
    for line in (stage/'stderr.log').read_text().splitlines():
        if re.match(r'^(prefill|decode\d+)\s+tokens=',line):
            parts=line.split();fields=dict(x.split('=',1) for x in parts[1:])
            phases.append(dict(phase=parts[0],tokens=int(fields['tokens']),step_seconds=float(fields['step_seconds']),submit_seconds=float(fields['submit_seconds']),submit_to_token_seconds=float(fields['seconds']),id=int(fields['next'])))
    assert len(phases)==32 and len(output['generated_ids'])==32
    metrics=dict(candidate=candidate,trace=trace,phases=phases,ids=output['generated_ids'],prefill_tokens_per_second=prompt/phases[0]['step_seconds'],decode_all_tokens_per_second=31/sum(x['step_seconds'] for x in phases[1:]),decode_warm_tokens_per_second=25/sum(x['step_seconds'] for x in phases[7:]),memory=read(stage/'memory.json')['peaks'])
    save(stage/'metrics.json',metrics)
    print('  pp',round(metrics['prefill_tokens_per_second'],2),'decode',round(metrics['decode_warm_tokens_per_second'],2),'GPU_GiB',round(metrics['memory']['sampled_peak_gpu_dedicated_bytes']/1024**3,4),flush=True)

if __name__=='__main__':
    mode=sys.argv[1]
    if mode=='correctness':
        trial('candidate21-decisions',True,21,True)
        trial('candidate128-decisions',True,128,True)
    elif mode=='performance':
        for i,candidate in [(1,False),(2,True),(3,True),(4,False),(5,False),(6,True)]:
            trial(f'perf128-{i:02d}-'+('candidate' if candidate else 'before'),candidate,128)
    else:raise SystemExit('correctness | performance')
