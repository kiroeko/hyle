from pathlib import Path
import hashlib, json, os, subprocess, sys, time
sys.dont_write_bytecode = True
OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]
ARCH = OUT.parent
sys.path.insert(0, str(ROOT / 'scripts'))
from hyle_environment import windows_compiler_environment

def read(p): return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def save(p, v): Path(p).write_text(json.dumps(v, indent=2) + '\n', encoding='utf-8')
def ident(p):
    p = Path(p); b = p.read_bytes()
    return dict(path=str(p.resolve()), bytes=len(b), sha256=hashlib.sha256(b).hexdigest())

BASE_PATH = ARCH / 'ggml-cuda-caller-workspace/candidate-link-plan.json'
BASE = read(BASE_PATH)['command']
PRODUCT_TEMPLATE = read(ARCH / 'ggml-cuda-caller-workspace/provider-compile-2.command.json')['argv']
TEST_TEMPLATE = read(ARCH / 'cuda-admitted-ggml-stream-implementation/provider-test-identity.json')['command']
ENV = windows_compiler_environment({'CMAKE_CXX_COMPILER': PRODUCT_TEMPLATE[0]})
ENV['VSLANG'] = '1033'
ENV['PATH'] = os.pathsep.join(dict.fromkeys(str(Path(x).parent) for x in BASE if Path(x).is_absolute() and x.lower().endswith('.lib'))) + os.pathsep + ENV['PATH']

def command(tag, argv):
    rows = read(OUT / 'commands.json') if (OUT / 'commands.json').exists() else []
    assert tag not in [x['tag'] for x in rows], 'Use a distinct tag for a corrected attempt'
    stem = f'{len(rows)+1:03d}-{tag}'
    row = dict(tag=tag, argv=list(map(str, argv)), started=time.time(), cwd=str(ROOT), stdout=stem+'.stdout.log', stderr=stem+'.stderr.log')
    rows.append(row); save(OUT/'commands.json', rows)
    print('START', stem, flush=True)
    with (OUT/row['stdout']).open('wb') as so, (OUT/row['stderr']).open('wb') as se:
        p = subprocess.Popen(row['argv'], cwd=ROOT, env=ENV, stdout=so, stderr=se, creationflags=subprocess.CREATE_NO_WINDOW)
        row['pid'] = p.pid; save(OUT/'live.json', row); save(OUT/'commands.json', rows)
        row['exit'] = p.wait()
    row.update(terminal=True, seconds=time.time()-row['started']); save(OUT/'commands.json', rows); save(OUT/'live.json', row)
    print('END', stem, row['exit'], round(row['seconds'], 3), flush=True)
    if row['exit']:
        print((OUT/row['stdout']).read_text(errors='replace')[-8000:])
        print((OUT/row['stderr']).read_text(errors='replace')[-4000:])
        raise SystemExit(row['exit'])

def compile_one(src, name, template, tag=None):
    source = ROOT/src; before = ident(source)
    dest = OUT/'candidate'/src; dest.parent.mkdir(parents=True, exist_ok=True); dest.write_bytes(source.read_bytes())
    args = [v for v in template if not v.lower().startswith(('/fo', '/fd')) and not v.lower().endswith('.cc')]
    args += ['/sourceDependencies', str(OUT/(name+'-deps.json')), str(source), '/Fo'+str(OUT/(name+'.obj'))]
    command(tag or name+'-compile', args)
    assert ident(source) == before, 'Source changed during compile'
    deps = read(OUT/(name+'-deps.json'))['Data']['Includes']
    save(OUT/(name+'-identity.json'), dict(source=before, object=ident(OUT/(name+'.obj')), command=args,
        hyle_dependencies=[ident(p) for p in deps if Path(p).resolve().is_relative_to(ROOT.resolve())]))

def selected_link(name, tests=False, tag=None):
    old_policy = str(ARCH/'qwen-numerical-localization/actual-f32-probe/default_policy-current.obj')
    assert BASE.count(old_policy) == 1
    args = [x for x in BASE if not x.upper().startswith(('/OUT:', '/MAP:', '/IMPLIB:', '/PDB:'))]
    args[args.index(old_policy)] = str(OUT/'default-policy.obj')
    old_tensor = str(ARCH/'qwen-numerical-localization/actual-f32-probe/tensor-current.obj')
    assert args.count(old_tensor) == 1
    args[args.index(old_tensor)] = str(OUT/'tensor-program.obj')
    if tests:
        consumer = str(ARCH/'qwen-gpu-comparison/hyle-consumer.obj')
        assert args.count(consumer) == 1
        args.remove(consumer)
        args[6:6] = [str(OUT/(n+'.obj')) for n in ('direct-test', 'graph-test')]
        args.insert(6, str(ARCH/'weight-inputs/windows/weights.obj'))
        args += [str(ROOT/'.scratch/build-compute-v2-dev/lib'/n) for n in ('gtest_main.lib', 'gtest.lib')]
    args += ['/OUT:'+str(OUT/(name+'.exe')), '/MAP:'+str(OUT/(name+'.map')), '/IMPLIB:'+str(OUT/(name+'.lib'))]
    assert all(Path(x).is_file() for x in args if Path(x).is_absolute() and Path(x).suffix.lower() in ('.obj', '.lib'))
    tag = tag or name+'-link'
    save(OUT/(tag+'-plan.json'), dict(command=args, base=ident(BASE_PATH), changed_product_objects=[ident(OUT/(n+'.obj')) for n in ('tensor-program','default-policy')], native_sdk_rebuilt=False))
    command(tag, args)

if __name__ == '__main__':
    if sys.argv[1:] == ['product']:
        compile_one('src/compute_provider_ggml_cuda/tensor_program.cc', 'tensor-program', PRODUCT_TEMPLATE)
        compile_one('src/compute_route_cuda/default_policy.cc', 'default-policy', PRODUCT_TEMPLATE)
        selected_link('candidate')
    elif sys.argv[1:] == ['tests']:
        compile_one('tests/compute_route_cuda/context_test.cc', 'direct-test', TEST_TEMPLATE)
        compile_one('tests/graph_route_cuda/ggml_test.cc', 'graph-test', TEST_TEMPLATE)
        selected_link('matvec-tests', tests=True)
    elif sys.argv[1:] == ['relink']:
        selected_link('candidate', tag='candidate-link-2')
    elif sys.argv[1:] == ['tests-fixed']:
        compile_one('tests/compute_route_cuda/context_test.cc', 'direct-test', TEST_TEMPLATE, 'direct-test-compile-2')
        compile_one('tests/graph_route_cuda/ggml_test.cc', 'graph-test', TEST_TEMPLATE)
        selected_link('matvec-tests', tests=True)
    elif sys.argv[1:] == ['relink-tests']:
        selected_link('matvec-tests', tests=True, tag='matvec-tests-link-2')
    elif sys.argv[1:] == ['current-tests']:
        selected_link('matvec-tests', tests=True, tag='matvec-tests-link-current-weights')
    else:
        raise SystemExit('product | tests')
