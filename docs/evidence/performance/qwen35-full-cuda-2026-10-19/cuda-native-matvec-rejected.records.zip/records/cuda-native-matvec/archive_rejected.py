from pathlib import Path
import collections
import hashlib
import json
import shutil
import xml.etree.ElementTree as ET
import zipfile
import zlib

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]
ARCH = OUT.parent
REVIEW = ARCH / 'cuda-vector-matmul'
DEST = ROOT / 'docs/evidence/performance/qwen35-full-cuda-2026-10-19/cuda-native-matvec-rejected.zip'
assert not DEST.exists(), 'Frozen evidence must not be overwritten'


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def save(path, value):
    Path(path).write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8')


def digest(data):
    return hashlib.sha256(data).hexdigest()


def ident(path):
    path = Path(path)
    data = path.read_bytes()
    return dict(path=str(path.resolve()), bytes=len(data), sha256=digest(data))


summary = read(OUT / 'summary.json')
assert summary['byte_identical_vectors'] == 2 and summary['total_vectors'] == 128
assert summary['matching_prediction_ids_between_arms']
xml = ET.parse(OUT / 'tests.xml').getroot()
assert xml.attrib['tests'] == '2' and xml.attrib['failures'] == '0' and xml.attrib['errors'] == '0'

# Candidate snapshots are historical compiled inputs, never the subsequently
# restored or independently edited canonical product source.
candidate_checks = []
for name in ['tensor-program-identity.json', 'default-policy-identity.json',
             'direct-test-identity.json', 'graph-test-identity.json']:
    receipt = read(OUT / name)
    relative = Path(receipt['source']['path']).relative_to(ROOT)
    snapshot = OUT / 'candidate' / relative
    got = ident(snapshot)
    assert got['sha256'] == receipt['source']['sha256'] and got['bytes'] == receipt['source']['bytes']
    candidate_checks.append(dict(receipt=name, snapshot=str(snapshot.relative_to(OUT)).replace('\\', '/'),
                                 source=receipt['source']))
freeze = read(REVIEW / 'source-freeze.json')
frozen_header = next(row for row in freeze['source_identities']
                     if row['path'] == 'tests/cuda_vector_matmul_test.h')
header = ROOT / frozen_header['path']
header_ident = ident(header)
header_snapshot = REVIEW / 'candidate' / frozen_header['path']
assert header_ident['sha256'] == frozen_header['sha256'] == ident(header_snapshot)['sha256']
assert header_ident['bytes'] == frozen_header['bytes']
images = [ident(OUT / (stem + suffix)) for stem in ['candidate', 'matvec-tests']
          for suffix in ['.exe', '.map', '.lib', '.exp']]
assert len(images) == 8
objects = [ident(path) for path in sorted(OUT.glob('*.obj'))]
assert len(objects) == 4
cleanup = dict(schema='hyle.cuda.native-matvec.rejected.cleanup.v1', root=str(ROOT),
    archive=dict(path=str(DEST), receipt=str(OUT / 'archive-receipt.json'),
                 require_existing_verified_receipt=True),
    files=images + [dict(**header_ident, reason='Rejected experiment unused new test header; '
          'matches archived candidate snapshot and no current test source includes it.')],
    bytes=sum(row['bytes'] for row in images)+header_ident['bytes'], image_count=8,
    unused_header=dict(frozen_snapshot=str(header_snapshot), expected_sha256=frozen_header['sha256']),
    retain_objects=objects,
    retain=[str(ARCH / 'qwen-decode-native-route/hyle.exe'),
            'all objects, SDK/native caches, original single model and GGUF',
            'all source snapshots, commands, logs, raw decision vectors and trace archives'],
    delete_executed=False, default_preview=True)
save(OUT / 'cleanup-windows.json', cleanup)
save(OUT / 'archive-source-check.json', dict(compiled_candidate_snapshots=candidate_checks,
    restoration_receipt=ident(OUT / 'product-restoration.json'),
    note='Product-restoration records the exact four-source restoration at that time. '
         'Later canonical source may belong to a new experiment and is deliberately not copied here.',
    header=header_ident, header_snapshot=ident(header_snapshot),
    current_external_header_references='rg under tests/src/include found only namespace lines '
        'inside the unused header, no include or test references.',
    xml=dict(tests=2, failures=0, errors=0), no_build_or_gpu_performed=True))

refs = OUT / 'trace-references'
refs.mkdir(exist_ok=True)
for stage, label in [('qwen-decode-native-route', 'baseline'),
                     ('qwen-decode-native-route-candidate', 'candidate')]:
    for name in ['summary.json', 'archive-receipt.json']:
        shutil.copyfile(ARCH / stage / name, refs / (label + '-' + name))

payload = {}
logical = []
vector_index = []
excluded = collections.Counter()


def add(path, logical_path, raw=False):
    data = path.read_bytes()
    sha = digest(data)
    archive_path = ('raw-vectors/' + sha + path.suffix.lower()) if raw else logical_path
    if archive_path in payload:
        assert payload[archive_path] == data
    else:
        payload[archive_path] = data
    logical.append(dict(path=logical_path, origin=str(path.resolve()), bytes=len(data),
                        sha256=sha, payload=archive_path))
    return archive_path


for stage, label in [(OUT, 'cuda-native-matvec'), (REVIEW, 'cuda-vector-matmul')]:
    for path in sorted(stage.rglob('*')):
        if not path.is_file() or '__pycache__' in path.parts:
            continue
        suffix = path.suffix.lower()
        if suffix in {'.obj', '.exe', '.dll', '.map', '.lib', '.exp', '.zip', '.pyc'}:
            excluded[suffix] += 1
            continue
        if path.name in {'archive-receipt.json', 'archive-inventory.json'} and path.parent == OUT:
            continue
        assert suffix not in {'.gguf', '.safetensors', '.pt', '.bin'}, 'Unexpected model/SDK payload'
        rel = path.relative_to(stage).as_posix()
        add(path, label + '/' + rel, raw=suffix in {'.bf16', '.f32'})

# Preserve both arms of the decision comparison. Existing before payloads live
# in the previous stage; retain them here without creating another raw copy.
for row in summary['vectors']:
    item = dict(scene=row['scene'], relative=row['relative'], byte_identical=row['byte_identical'])
    for arm in ['before', 'candidate']:
        receipt = row[arm]
        path = Path(receipt['path'])
        assert ident(path) == receipt
        logical_path = ('comparative-decisions/' + str(row['scene']) + '/' + arm + '/' +
                        row['relative'].replace('\\', '/'))
        item[arm] = dict(**receipt, payload=add(path, logical_path, raw=True))
    vector_index.append(item)
index_data = json.dumps(dict(comparisons=vector_index, raw_payloads_deduplicated_by_sha256=True),
                        indent=2).encode() + b'\n'
payload['decision-vector-index.json'] = index_data
manifest = dict(schema='hyle.cuda.native-matvec.rejected.archive.v1',
    decision='Rejected default-vector experiment, not a precision acceptance or general mmvf result.',
    scope='All experiment/source-review snapshots, scripts, text logs, commands, receipts, '
          'performance samples, two passing tests and both arms of128 raw decision-vector comparisons. '
          'Raw vectors deduplicated by SHA. Existing trace archives referenced, not embedded.',
    logical_files=logical, entries=[dict(path=name, bytes=len(data), sha256=digest(data),
        crc32=f'{zlib.crc32(data)&0xffffffff:08x}') for name, data in sorted(payload.items())],
    raw_unique_payloads=sum(name.startswith('raw-vectors/') for name in payload),
    raw_logical_comparisons=128, exclusions=dict(excluded),
    no_objects_images_maps_sdk_models_or_old_zip_copies=True)
DEST.parent.mkdir(parents=True, exist_ok=True)
with zipfile.ZipFile(DEST, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
    for name, data in sorted(payload.items()):
        archive.writestr(name, data)
    archive.writestr('manifest.json', json.dumps(manifest, indent=2) + '\n')
with zipfile.ZipFile(DEST) as archive:
    assert archive.testzip() is None
    assert len(archive.infolist()) == len(payload)+1
    for row in manifest['entries']:
        data = archive.read(row['path'])
        assert len(data) == row['bytes'] and digest(data) == row['sha256']
        assert f'{zlib.crc32(data)&0xffffffff:08x}' == row['crc32']
data = DEST.read_bytes()
receipt = dict(path=str(DEST), bytes=len(data), sha256=digest(data),
    crc32=f'{zlib.crc32(data)&0xffffffff:08x}', entries=len(payload)+1,
    payload_entries=len(payload), logical_files=len(logical),
    raw_unique_payloads=manifest['raw_unique_payloads'], raw_comparisons=128,
    crc_and_all_payload_sha_verified=True, no_objects_images_maps_sdk_models_old_zips=True,
    cleanup_manifest=str(OUT / 'cleanup-windows.json'), cleanup_files=9,
    cleanup_bytes=cleanup['bytes'], deletions_executed=False)
save(OUT / 'archive-receipt.json', receipt)
save(OUT / 'archive-inventory.json', manifest)
print(json.dumps(receipt, indent=2))
