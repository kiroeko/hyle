# Qwen3.5-2B 全 CUDA 实际对照

2026-10-19，Windows / RTX 4070 12GB / driver 617.14。双方完整执行官方同源2B文本模型24层，
不执行视觉或MTP，权重在推理前全部驻留GPU；同为BF16权重、BF16 KV、单请求、context容量256、GPU greedy。
llama.cpp为本地d9e03f1074dbd2979126d91dce1b5d304ec8394e，复用与其GGML pin 456相符的原CUDA数学闭包，
不是本地较新HEAD，也不把既有Hyle资源集成补丁隐藏为纯上游未修改构建。

以下首表保留修改前基线。本日后续先统一普通ggml CUDA区域的临时寿命复用，再接入共同Graph workspace，
当前128-token场景Hyle显存降至3.972 GiB；两阶段变更与同源A/B见文末，不能把旧表6.431 GiB当作修复后的数值。

每个场景3对独立进程，按H/L、L/H、H/L顺序运行，表列中位数。输入前缀和31个decode输入逐token一致，
两边分别反馈自己的KV/conv/GDN状态；未读取对方状态、hidden或logits。所有吞吐测量未挂profiler。
21-token场景另有一次关闭内存监控的对照，两端预热后decode分别76.14和106.16 tokens/s，未作开销修正。

| 指标 | Hyle | llama.cpp |
|---|---:|---:|
| 128-token场景：权重/模型加载子段 | 3.086 s | 1.603 s |
| 有效载荷加载率 | 1.136 GiB/s | 2.188 GiB/s |
| 进程启动到可推理 | 3.892 s | 1.772 s |
| 进程启动到首token | 3.968 s | 1.877 s |
| 首次prefill，128 tokens | 1680.1 tokens/s | 1223.6 tokens/s |
| decode，全部31步，含原生预热 | 69.3 tokens/s | 104.1 tokens/s |
| decode7–31，预热后25步 | 77.4 tokens/s | 105.8 tokens/s |
| 进程Dedicated显存采样峰值 | 6.431 GiB | 3.946 GiB |
| 进程RAM Working Set峰值 | 1.501 GiB | 4.069 GiB |

短输入控制：21-token首次prefill为286.6 / 222.4 tokens/s，预热后decode为78.1 / 106.7 tokens/s，
Dedicated显存峰值为4.327 / 3.825 GiB，RAM Working Set峰值为1.501 / 4.069 GiB。
128-token场景中，Hyle预热后decode低约26.9%，进程启动到ready耗时约2.20倍，Dedicated显存多约2.484 GiB。
这是当前配置的实际输项；首次prefill更快不能抵销加载、decode和显存问题，也不能外推长prefill或质量等价。

加载子段的前端工作不同：Hyle从原safetensors按manifest读取、分配并同步上传320个张量，
llama从单份官方converter生成的text-only/no-MTP GGUF加载，含原格式的metadata和tokenizer处理。
原text payload为3,763,655,360B，GGUF的有效text payload为3,764,747,520B（187 BF16＋133 F32无损例外）。
因此同时保留从进程启动到ready和首token的完整端点，不单用加载子段宣称等工作胜负。
Hyle的ready计入prefill/T1原冷编译；双方都不额外预跑数学。首次prefill仍包含各自原生首次执行开销。

完整step从输入准备前开始，到GPU选出的token在host可读为止，包含布局、绑定、重放准备和完成等待。
仅使用旧Hyle submit→token的seconds会漏费用，本表使用step_seconds。
原生预热没有被删除：全31步与实际decode7–31窗口分别列出；后者不是长期运行或热稳定性承诺。
llama原公开tensor_buft_overrides将默认在CPU的input embedding置于CUDA0，并与tied output共享原tensor/backing；
实际25/25层、6个KV层、18个recurrent层均CUDA0，32次GPU sampler快路，没有CPU采样fallback。
其原框架仍额外回读248320个sampled logits，费用保留；未修改上游以消除该工作。

显存采用本PID的Windows GPU Process Memory Dedicated/Shared，50ms采样，峰值为采样下界；
本机WDDM的NVML进程显存为N/A，未把整卡占用当本进程VRAM。RAM为PSAPI Working Set，含映射/共享驻留页，
不能据此推导整机物理RAM节省相同数量。PrivateUsage/PeakPagefileUsage另存为提交量，不能与GPU Shared相加当物理内存。
短场景的完整独立memory-review保留阶段前后点、时间偏差和缺样；尤其不能将释放后的最近点冒充推理驻留。

提示21→128 tokens、context容量始终256时，Hyle显存峰值增加2.104 GiB，peer仅增加0.121 GiB。
128场景每组model_loaded→ready间均有9个有效样本，ready前已观察到约6.23–6.30 GiB；
这之前尚未首次提交数学。自loaded后首样本至峰值的增长中，92.8%–95.3%已在ready前存在，
该区间包含状态初始化和prefill/T1各两个执行槽，不能把全部费用归因于某一allocator。
源码确认ggml非tiled Invocation逐非view/nonexternal tensor独立分配buffer并随槽保留，没有原生liveness复用；
这是首要调查候选，尚未逐buffer定量。显式Graph workspace增长仅约33.3 MiB，
默认GDN仅保最终状态，不是误保所有token状态。逐样本与有界静态算术见128-prefill/memory-review.json。
128场景推理期间RAM Working Set中位数为1.108 / 4.069 GiB，Private Commit为8.254 / 4.882 GiB；
因此Hyle Working Set较低不能直接解释为主机内存总体代价更低。

双方中间精度仍有差异：Hyle多处保BF16边界，peer多处为F32。短场景预测top1为30/32相同（decode23、29不同），
128-token场景为32/32；这些都不是独立质量评测或整模型精度接受。
各场景源代码、命令、逐步计时、预测IDs与进程内存样本见[性能原始记录](qwen-full-cuda-comparison.zip)，
正常64-token greedy生成也在包内，达到步数上限而非EOS。模型转换/设备/ABI身份及原始peer构建见
[llama参考准备](llama-reference-preparation.zip)；
不包含SDK、object、image或额外模型副本。原生capture观测另见
[实际trace](../../correctness/inference-foundation-review-2026-10-18/qwen-native-graph-observation.zip)。

归档后通过根目录test.ps1精确删除20个已完成实验exe/map/lib/exp及1个写错checkout位置的证据zip副本，
共664,878,137B；可复用object、SDK、原模型及单份转换GGUF保留。[清理记录](qwen-benchmark-reclaim.zip)

## 原生临时缓冲寿命复用

同日沿原Invocation将普通区域与分块attention统一到原生gallocr：冷reserve临时空间，
真实绑定后仅安装已有地址；保持常量、校验输入、输出/root、各槽所有权及退休顺序。
移除了普通区域逐张量独立分配的分支，没有新增公共选项、执行器或数学实现。
只替换一个provider宿主object，未重编native/SDK。同一128-token场景重新运行3对独立进程B/A、A/B、B/A：

| 指标 | 修改前 | 修改后 |
|---|---:|---:|
| PID Dedicated显存峰值 | 6.431 GiB | 5.312 GiB |
| 首次prefill | 1647.6 tokens/s | 1653.0 tokens/s |
| decode7–31 | 77.32 tokens/s | 77.36 tokens/s |

显存三次均减少1,201,676,288B（1.119 GiB），吞吐无明显变化。21-token单对控制为4.327→4.159 GiB。
21/128-token各32阶段的logits和最后hidden共128份向量与旧实现逐字节相同；不是新的通用质量接受。
原24层Add长链只publish最终输出，实际native retained从184降到8 MiB，旧实现明确不满足128 MiB宽限，
新实现通过且精确输出25*x、原输入不变。published view/root、旧结果、checked失败不发布、双slot换地址等4项通过；
原TypedSlice负控错误地强制prepare成功，允许它在prepare按InvalidArgument提前拒绝坏对齐后，该项单独1/1通过。
原失败日志、初版fixture及更正后记录均保留，没有把006原4/5记成全过。

该阶段仍比原llama参考峰值高约1.365 GiB；每region/shape/slot的独立原生workspace当时尚未接入共同Graph liveness，
原生首次执行、融合地址条件及其他模型功能继续审查。本次不据此宣布架构goal完成。
[源码、原始A/B、决策数据与回归](ggml-cuda-liveness.zip)另含下一步沿既有caller workspace接线的只读设计，未将设计当作已实现。
本修复归档对相同决策payload去重，保存全部逻辑文件身份；经test.ps1精确清理16个已完成image/map/lib/exp，
回收599,196,703B，保留4个新增复用object及全部源码/日志/数据/SDK。[清理记录](ggml-cuda-liveness-reclaim.zip)

## 接入共同 workspace

第二阶段沿既有ProviderPrepared.workspace与create_invocation(BufferView)接线，不增加公共API或新执行器。
冷编译用空地址的真实buffer描述测量精确chunk span，不分配device payload、不上传常量、不执行数学；
普通Invocation将原gallocr chunk映射到真实caller workspace，逐项核对size/offset，禁止容量不足时另开私有池。
返回的buffer保留canonical CUDA类型；原安全ID/常量和原生BLAS/pool/cache仍独立持有。
Graph adapter转发真实需求，由现有HB/liveness规划复用有序region的空间。Direct调用按标准requirement提供并持有workspace，
Graph消费者入口不变。显式冷constant packing仍自行持有临时空间，未把它变成普通执行的隐藏fallback。

只替换provider与Graph adapter两个宿主object，native数学、共同Graph/Compute owner及SDK均复用。
同一128-token固定输入再次按B/A、A/B、B/A运行3对独立进程，性能运行均无trace/profiler：

| 指标 | 仅区域内复用 | 接入共同workspace |
|---|---:|---:|
| PID Dedicated显存峰值 | 5.312 GiB | 3.972 GiB |
| 首次prefill | 1702.0 tokens/s | 1706.4 tokens/s |
| decode7–31 | 77.47 tokens/s | 77.95 tokens/s |
| 进程启动到ready | 3.777 s | 3.772 s |

显存三次均减少1,438,658,560B（1.340 GiB）；吞吐与启动变化不足以宣称改善。21-token单对控制为4.159→3.872 GiB。
从首轮6.431 GiB累计降至3.972 GiB，仍比原llama参考的3.946 GiB高约26 MiB；peer本阶段未重跑。
21/128-token各32阶段共128份logits/hidden向量与上一阶段逐字节相同，数学与中间精度未调整。
新两region测试中，各原生需求8 MiB，加上8 MiB边界张量后Graph总空间16 MiB，证明共用而非相加。
8个相关测试TU鲜编，唯一过滤运行10/10通过，覆盖普通attention、GDN快照重绑、checked失败不发布/重建、
abandon/close、view/root、旧结果和双slot。两次首次编译配方/警告失败及修正均保留，未重编native或SDK。
多chunk与其他模型的完整旅程仍未因此实测验收，独立shape与并发slot仍各自持有backing，decode和加载输项继续处理。
[源码、精确命令、A/B原始数据与回归](ggml-cuda-caller-workspace.zip)。
本阶段归档后经根目录test.ps1精确清理12个已完成image/map/lib/exp，回收451,978,680B；
2个产品与8个测试object、全部数据/源码/日志和SDK保留。[清理记录](ggml-cuda-caller-workspace-reclaim.zip)

后续全库调用者扫描另迁移8个测试/fixture文件中的9处Direct调用：按实际prepared operation的
workspace_requirement分配并持有所选resource的缓冲，零需求仍传空view。8个CUDA测试TU增量编译成功，
8个代表用例全部通过、无跳过，83项实际依赖复核无漂移；CPU共享fixture分支未运行，未重建native或SDK。
[迁移源码、精确命令和回归记录](ggml-cuda-workspace-consumers.zip)保留扫描边界与未修改的零需求调用者。
归档核对后经根目录test.ps1精确删除4个已完成image/map/lib/exp，回收153,514,557B，保留8个新object。
[清理记录](ggml-cuda-workspace-consumers-reclaim.zip)

同包另含冷常量打包的只读审查：在已接纳原生工作后，若checked drain与析构drain均未证明退休，
当前Status工厂仍进入原生对象和失败产物清理，违反其返回前完成准备的合同。该缺口未修复，未复现UAF；
普通free可能同步、终态设备错误及实际context销毁的情况分别记录，不能把观察错误直接当作仍有活内核。

## Decode 成本复核

当前共同workspace候选的三轮128-token记录中，decode7–31每步耗时中位数为12.67–12.80ms。
上传、layout更新、绑定和重放准备合计中位数0.33–0.35ms，约2.7%；submit返回前为4.37–4.58ms，
约35%，包含驱动调用和可能的阻塞，与GPU执行重叠，不能直接当作可节省的CPU费用。
此前capacity64的软件trace中，预热后每步有401次原生Graph launch；它说明提交粒度较碎，
不能代替本阶段双方GPU关键路径对照，也未定量证明BF16、转换或路由是decode差距主因。
加载消费者则逐张量读取、分配并同步上传320份权重，尚未流水化；加载与decode问题分别调查。
[离线重算脚本、当前逐步统计及旧trace结构边界](qwen-decode-cost-review.zip)。
