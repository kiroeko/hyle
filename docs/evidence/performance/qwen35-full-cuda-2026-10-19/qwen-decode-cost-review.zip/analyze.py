"""Offline recheck of existing Qwen logs; no inference, build, or profiling."""
from pathlib import Path
import hashlib
import json
import re
import statistics

OUT = Path(__file__).resolve().parent
STAGES = OUT.parent
ROOT = STAGES.parents[1]
RUNS = ["perf128-02-candidate", "perf128-03-candidate", "perf128-06-candidate"]
PATTERN = re.compile(
    r"^(prefill|decode\d+) tokens=(\d+) visible=(\d+) "
    r"seconds=([\deE.+-]+) submit_seconds=([\deE.+-]+) "
    r"step_seconds=([\deE.+-]+)", re.M)


def identity(path):
    data = path.read_bytes()
    return {"path": str(path), "bytes": len(data),
            "sha256": hashlib.sha256(data).hexdigest()}


def read(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def summary(values):
    return {"median_ms": statistics.median(values) * 1000,
            "mean_ms": statistics.mean(values) * 1000,
            "min_ms": min(values) * 1000, "max_ms": max(values) * 1000}


records = []
for name in RUNS:
    run = STAGES / "ggml-cuda-caller-workspace" / name
    rows = []
    for phase, tokens, visible, elapsed, submit, step in PATTERN.findall(
            (run / "stderr.log").read_text(encoding="utf-8")):
        if not phase.startswith("decode") or int(phase[6:]) < 7:
            continue
        elapsed, submit, step = map(float, (elapsed, submit, step))
        assert int(tokens) == 1 and step >= elapsed and submit >= 0
        rows.append({"phase": phase, "visible_tokens": int(visible),
                     "step_seconds": step, "submit_to_token_seconds": elapsed,
                     "submit_seconds": submit, "pre_submit_seconds": step - elapsed})
    assert len(rows) == 25 and [row["phase"] for row in rows] == [f"decode{i}" for i in range(7, 32)]
    assert [row["visible_tokens"] for row in rows] == list(range(135, 160))
    result = read(run / "result.json")
    records.append({
        "run": name,
        "log": identity(run / "stderr.log"),
        "original_run_result": identity(run / "result.json"),
        "recorded_image_identity": result["binary"],
        "phases": "decode7..31", "count": len(rows),
        "visible_tokens": [135, 159],
        "step": summary([row["step_seconds"] for row in rows]),
        "submit_to_token": summary([row["submit_to_token_seconds"] for row in rows]),
        "submit_call": summary([row["submit_seconds"] for row in rows]),
        "pre_submit": summary([row["pre_submit_seconds"] for row in rows]),
        "median_submit_fraction_of_step": statistics.median(row["submit_seconds"] / row["step_seconds"] for row in rows),
        "median_pre_submit_fraction_of_step": statistics.median(row["pre_submit_seconds"] / row["step_seconds"] for row in rows),
        "parsed_rows_sha256": hashlib.sha256(json.dumps(rows, sort_keys=True).encode()).hexdigest(),
    })

compiled_source = STAGES / "qwen-gpu-comparison/candidate/main.cc"
source_receipt = STAGES / "qwen-gpu-comparison/hyle-source-identities.json"
expected_source = next(row["candidate"] for row in read(source_receipt)
                       if row["relative"] == "tools/qwen35_text/main.cc")
assert identity(compiled_source) == expected_source
source_lines = compiled_source.read_text(encoding="utf-8").splitlines()
step_line = next(i + 1 for i, line in enumerate(source_lines) if "const auto step_start = Clock::now();" in line)
submit_line = next(i + 1 for i, line in enumerate(source_lines) if "auto done = take(run.submit(queues));" in line)
finish_line = next(i + 1 for i, line in enumerate(source_lines) if "const auto finished = Clock::now();" in line)
trace_path = STAGES / "qwen-native-graph-observation/results.json"
trace = read(trace_path)
old_counts = [{"phase": row["phase"],
               "cuda_graph_launches": row["successful_api_calls"].get("cudaGraphLaunch", 0)}
              for row in trace["phase_bins"] if row["phase"] in ("decode5", "decode6", "decode7")]
assert all(row["cuda_graph_launches"] == 401 for row in old_counts)

report = {
    "schema": "hyle.qwen.decode-cost-review.v1",
    "activity": "Offline parsing of three already-completed unprofiled runs; zero new GPU runs, builds, profiling, or product changes.",
    "inputs": {"prompt_tokens": 128, "fixed_decode_inputs": 31,
               "context_capacity": 256, "progress": "direct", "tensor_trace": False,
               "stable_window": "decode7..31, no synthetic warmup"},
    "runs": records,
    "median_of_run_medians_ms": {
        field: statistics.median(row[field]["median_ms"] for row in records)
        for field in ("step", "submit_to_token", "submit_call", "pre_submit")},
    "timing_source": {
        "compiled_snapshot": identity(compiled_source),
        "compiled_source_receipt": identity(source_receipt),
        "caller_link_plan": identity(STAGES / "ggml-cuda-caller-workspace/candidate-link-plan.json"),
        "current_product_source_at_review": identity(ROOT / "tools/qwen35_text/main.cc"),
        "line_numbers_in_compiled_snapshot": {"step_start": step_line, "submit": submit_line, "finished": finish_line},
        "pre_submit": "step_seconds - seconds: positions/tokens upload, owned attention layout, batch prepare, state/input/output binds, prepare_replay and the prepared diagnostic log before submission.",
        "submit_call": "Wall time inside run.submit on the host. Includes provider/driver work and any blocking; GPU execution can overlap this interval. It is not GPU duration or exclusive CPU overhead.",
        "submit_to_token": "From immediately before run.submit through Completion.wait and final selected-token readback. Contains overlapping host/GPU execution; cannot be split into GPU time by subtraction.",
        "step": "From before input preparation to selected-token readback. Shape cache lookup/creation precedes this timer and belongs to the separately recorded startup/cold-shape boundary.",
    },
    "prior_native_trace_structure_only": {
        "source": identity(trace_path),
        "geometry": trace["geometry"],
        "recorded_stable_counts": old_counts,
        "limits": "This older capacity64, 21-token, software-instrumented trace establishes many native graph launch episodes. It is not the current capacity256 GPU critical path. API durations/counts cannot be added into an exclusive end-to-end GPU attribution.",
    },
    "conclusions_and_limits": [
        "Existing runs measure about 0.34 ms of pre-submit preparation, roughly 2.6-2.75% of the step. This does not explain the entire approximately 3.4 ms engine-level decode gap discussed with the retained peer reference.",
        "The 4.4-4.6 ms submit-call medians are host wall-clock intervals, approximately 34-36% of the step. They include overlap/possible driver waits and must not be assigned as GPU duration or entirely removable CPU cost.",
        "The old 401-launch observation is a structural lead, not a measured current latency share. Common Graph steps do not enumerate all native kernels, conversions or payload traffic.",
        "Both engines' GPU critical paths have not been attributed. No BF16, routing, conversion, kernel bandwidth or launch overhead is asserted as the sole root cause.",
        "This report changes no acceptance threshold and makes no new throughput, numerical-quality or speedup claim.",
    ],
    "copied_large_raw_or_binary_payloads": False,
}
destination = OUT / "review.json"
destination.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8", newline="\n")
print(json.dumps(identity(destination), indent=2))
