"""Package only the small offline review and scripts; external inputs stay put."""
from pathlib import Path
import hashlib
import json
import zipfile
import zlib

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]
DEST = ROOT / "docs/evidence/performance/qwen35-full-cuda-2026-10-19/qwen-decode-cost-review.zip"
NAMES = ["analyze.py", "review.json", "summarize_old_trace.py", "old-trace-structure.json", "archive.py"]


def digest(data):
    return {"bytes": len(data), "sha256": hashlib.sha256(data).hexdigest(),
            "crc32": f"{zlib.crc32(data) & 0xffffffff:08x}"}


assert not DEST.exists(), str(DEST)
payloads = {name: (OUT / name).read_bytes() for name in NAMES}
entries = [{"name": name, "source": str(OUT / name), **digest(data)} for name, data in payloads.items()]
manifest = {
    "schema": "hyle.qwen.decode-cost-review.archive.v1",
    "entries": entries,
    "scope": "Small offline re-analysis of existing three unprofiled runs and a separate older software-instrumented SQLite structure. No new experiment, profiler collection, build, or product change.",
    "inputs_reference_only": "Existing stderr/result files, original compiled consumer snapshot, link plan, old results.json and SQLite are identified by path/bytes/SHA inside the review JSONs. They are not copied into this archive.",
    "limits": "About 0.34ms pre-submit preparation does not explain the whole approximately 3.4ms engine gap. The 4.4-4.6ms host submit interval overlaps GPU work. The old 401 launches and named-kernel/graph envelopes are structural observations, not a completed current peer GPU critical-path attribution.",
    "unchanged_prior_archives": True,
}
manifest_bytes = (json.dumps(manifest, indent=2) + "\n").encode("utf-8")
with zipfile.ZipFile(DEST, "x", zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for name, data in payloads.items():
        archive.writestr(name, data)
    archive.writestr("manifest.json", manifest_bytes)
with zipfile.ZipFile(DEST) as archive:
    assert archive.testzip() is None
    assert len(archive.namelist()) == len(NAMES) + 1
    for row in entries:
        assert digest(archive.read(row["name"])) == {key: row[key] for key in ("bytes", "sha256", "crc32")}
        assert archive.getinfo(row["name"]).CRC == int(row["crc32"], 16)
        assert digest(Path(row["source"]).read_bytes()) == {key: row[key] for key in ("bytes", "sha256", "crc32")}
receipt = {
    "destination": str(DEST), **digest(DEST.read_bytes()),
    "zip_entries": len(NAMES) + 1,
    "uncompressed_payload_bytes": sum(len(value) for value in payloads.values()) + len(manifest_bytes),
    "manifest_sha256": hashlib.sha256(manifest_bytes).hexdigest(),
    "zip_crc_and_every_entry_sha_verified": True,
    "packaged_source_drift": False,
    "large_external_inputs_copied": False,
    "product_changes_or_new_builds_or_GPU_runs": False,
    "deleted_or_moved_files": 0,
}
(OUT / "archive-receipt.json").write_text(json.dumps(receipt, indent=2) + "\n", encoding="utf-8", newline="\n")
print(json.dumps(receipt, indent=2))
