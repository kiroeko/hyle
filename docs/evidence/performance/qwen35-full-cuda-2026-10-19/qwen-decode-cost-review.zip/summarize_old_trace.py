"""Read only the already-recorded SQLite; no profiler, GPU work, or rebuild."""
from pathlib import Path
import hashlib
import json
import sqlite3

OUT = Path(__file__).resolve().parent
TRACE = OUT.parent / "qwen-native-graph-observation"
DATABASE = TRACE / "native-graphs.sqlite"


def identity(path):
    data = path.read_bytes()
    return {"path": str(path), "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}


bins = json.loads((TRACE / "results.json").read_text())["phase_bins"]
connection = sqlite3.connect(DATABASE.resolve().as_uri() + "?mode=ro", uri=True)
tables = ["CUPTI_ACTIVITY_KIND_KERNEL", "CUPTI_ACTIVITY_KIND_MEMCPY", "CUPTI_ACTIVITY_KIND_GRAPH_TRACE"]
counts = {table: connection.execute("SELECT COUNT(*) FROM " + table).fetchone()[0] for table in tables}
assert counts == {"CUPTI_ACTIVITY_KIND_KERNEL": 8754,
                  "CUPTI_ACTIVITY_KIND_MEMCPY": 1235,
                  "CUPTI_ACTIVITY_KIND_GRAPH_TRACE": 2017}
phases = []
for row in bins:
    if row["phase"] not in ["decode5", "decode6", "decode7"]:
        continue
    bounds = (row["interval_start_exclusive_ns"], row["interval_end_inclusive_ns"])
    totals = {}
    for table in tables:
        values = connection.execute(
            "SELECT COUNT(*), COALESCE(SUM(end-start),0) FROM " + table + " WHERE start>? AND start<=?", bounds).fetchone()
        totals[table] = {"records": values[0], "sum_record_durations_ms": values[1] / 1e6}
    top = connection.execute(
        "SELECT s.value,COUNT(*),SUM(k.end-k.start) FROM CUPTI_ACTIVITY_KIND_KERNEL k "
        "JOIN StringIds s ON s.id=k.demangledName WHERE k.start>? AND k.start<=? "
        "GROUP BY k.demangledName ORDER BY SUM(k.end-k.start) DESC LIMIT 8", bounds).fetchall()
    phases.append({"phase": row["phase"],
                   "boundary_interval_ms": (bounds[1] - bounds[0]) / 1e6,
                   "record_totals": totals,
                   "top_named_kernel_records": [
                       {"name": name, "records": number, "sum_record_durations_ms": elapsed / 1e6}
                       for name, number, elapsed in top]})
connection.close()
report = {
    "schema": "hyle.qwen.old-native-trace-structure.v1",
    "activity": "Offline read-only SQLite aggregation; no new collection, run, or build.",
    "database": identity(DATABASE),
    "original_phase_boundaries": identity(TRACE / "results.json"),
    "whole_database_record_counts": counts,
    "phases": phases,
    "limits": [
        "Older capacity64, 21-token, eight-phase software-instrumented run; not the latest capacity256 caller-workspace benchmark.",
        "The recording contains graph-level GPU activity as well as individually named kernels. Named-kernel records alone do not enumerate kernels inside every native CUDA graph launch.",
        "Sums of record durations are not exclusive GPU critical-path time. Graph envelopes can contain internal work, and asynchronous records can overlap; no sum is added to host submit duration.",
        "Top kernel names identify only the individually recorded subset. They do not attribute all 401 native graph launches, all conversion cost, or the latency gap to another engine.",
        "Software profiling overhead and the retained driver/CUPTI compatibility warning prevent treating these times as fair unprofiled throughput.",
    ],
}
destination = OUT / "old-trace-structure.json"
destination.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8", newline="\n")
print(json.dumps(report, indent=2))
