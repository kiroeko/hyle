"""Read existing native binaries/SQLite only; no compiler or GPU execution."""
from pathlib import Path
import collections
import hashlib
import json
import re
import sqlite3
import subprocess

STAGE=Path(__file__).resolve().parent
ARCH=STAGE.parent
OUT=STAGE/'native-inspection'


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))


def save(path,value):
    Path(path).write_text(json.dumps(value,indent=2)+'\n',encoding='utf-8')


def identity(path):
    path=Path(path).resolve()
    return dict(path=str(path),bytes=path.stat().st_size,
        sha256=hashlib.sha256(path.read_bytes()).hexdigest())


def execute(tag,argv):
    completed=subprocess.run(argv,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    (OUT/(tag+'.stdout.log')).write_bytes(completed.stdout)
    (OUT/(tag+'.stderr.log')).write_bytes(completed.stderr)
    save(OUT/(tag+'.command.json'),dict(command=argv))
    save(OUT/(tag+'.result.json'),dict(exit=completed.returncode,terminal=True,
        purpose='Static cuobjdump inspection of an existing binary; no GPU workload/counter/compile'))
    assert completed.returncode==0,tag
    return completed.stdout.decode('utf-8',errors='replace')


def resources(stage):
    path=ARCH/stage/'profile/capture.sqlite'
    con=sqlite3.connect('file:'+path.resolve().as_posix()+'?mode=ro',uri=True)
    con.row_factory=sqlite3.Row
    names=dict(con.execute('SELECT id,value FROM StringIds'))
    result={}
    for row in con.execute('SELECT * FROM CUPTI_ACTIVITY_KIND_KERNEL ORDER BY start'):
        name=names[row['demangledName']]
        if 'ssm_conv_' not in name:
            continue
        props={key:row[key] for key in ('registersPerThread','gridX','gridY','gridZ',
            'blockX','blockY','blockZ','staticSharedMemory','dynamicSharedMemory','localMemoryPerThread')}
        if name not in result:
            result[name]=dict(instances=0,properties=props)
        assert result[name]['properties']==props
        result[name]['instances']+=1
    gpu_tables=[row[0] for row in con.execute("SELECT name FROM sqlite_master WHERE type='table'")
                if 'GPU' in row[0] and 'TARGET' in row[0]]
    metadata={name:[dict(row) for row in con.execute('SELECT * FROM '+name)] for name in gpu_tables}
    con.close()
    return dict(sqlite=identity(path),kernels=result,recorded_gpu_metadata=metadata)


def parse_sass(text):
    result=[]
    resource_rows=re.findall(r'Function (_Z[^\s:]+):\s*\n\s*REG:(\d+) STACK:(\d+) SHARED:(\d+) LOCAL:(\d+)',text)
    for block in re.split(r'\n\s*Function : ',text)[1:]:
        name=block.splitlines()[0].strip()
        instructions=[]
        for line in block.splitlines()[1:]:
            match=re.search(r'/\*[0-9a-fA-F]+\*/\s+(?:@!?P\d+\s+)?([A-Z][A-Z0-9_.]*)\s',line)
            if match:
                instructions.append((match.group(1),line.strip()))
        counts=collections.Counter(op for op,_ in instructions)
        resource=[row for row in resource_rows if row[0]==name]
        assert len(resource)==1,(name,resource)
        result.append(dict(symbol=name,static_instructions=len(instructions),opcodes=dict(counts),
            compiled_resource_usage={key:int(value) for key,value in zip(
                ('registers','stack_bytes','static_shared_bytes','local_bytes'),resource[0][1:])},
            local_memory_instructions=[line for op,line in instructions if op.startswith(('LDL','STL'))],
            global_loads=[line for op,line in instructions if op.startswith('LDG')],
            conversion_or_widening_instructions=[line for op,line in instructions if op.startswith(('F2F','UF2F','PRMT','SHF','BMSK'))],
            integer_address_instructions=sum(count for op,count in counts.items()
                if op.startswith(('IMAD','IADD','LEA','SHF','ULDC','UIADD','UIMAD','ULEA')))))
    return result


def main():
    OUT.mkdir(exist_ok=False)
    plan_path=Path(read(STAGE/'latest-check.json')['plan'])
    recipe=read(plan_path.parent/'native-conv-identity.json')
    obj=Path(recipe['object']['path'])
    assert identity(obj)==recipe['object']
    tool=str(Path(recipe['command'][0]).with_name('cuobjdump.exe'))
    rotation=read(STAGE/'performance-prepared/plan.json')
    baseline=Path(rotation['images']['baseline']['path'])
    assert identity(baseline)==rotation['images']['baseline']
    listings={}
    for arm,image in [('baseline',baseline),('current',obj)]:
        text=execute(arm+'-list',[tool,'--list-text',str(image)])
        symbols=re.findall(r'SASS text section \d+ : x-(.+)\.sm_89\.elf\.bin',text)
        selected=[name for name in symbols if name.startswith(('_Z12ssm_conv_f32ILb0ELy128ELy4E',
            '_Z23ssm_conv_long_token_f32ILb0ELy128ELy4ELx32E'))]
        assert len(selected)==(2 if arm=='baseline' else 4),selected
        dumped=execute(arm+'-sass',[tool,'--dump-sass','--dump-resource-usage',
            '--function',','.join(selected),str(image)])
        listings[arm]=dict(image=rotation['images']['baseline'] if arm=='baseline' else recipe['object'],
            selected_symbols=selected,SASS=parse_sass(dumped),raw=identity(OUT/(arm+'-sass.stdout.log')))
    report=dict(status='static_native_binary_and_existing_trace_resources_only',
        build_plan=identity(plan_path),native_owner=identity(plan_path.parent/'native-conv-identity.json'),
        tool=identity(tool),compiled=listings,
        actual_kernel_resources={name:resources(name) for name in ('gdn-region-suffix','conv-typed-load')},
        product_modified=False,compiles=0,GPU_runs=0,GPU_counter_collections=0,
        limits='Static SASS instruction counts are not dynamic instruction counts, cache/transaction measurements, achieved occupancy or throughput attribution. Actual event durations are compared independently from existing traces.')
    save(OUT/'analysis.json',report)
    print('NATIVE_STATIC_INSPECTION',OUT/'analysis.json')


if __name__=='__main__':
    main()
