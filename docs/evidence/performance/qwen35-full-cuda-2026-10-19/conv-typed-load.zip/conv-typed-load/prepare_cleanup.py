"""Write an exact, identity-checked cleanup plan and root test.ps1; no deletion."""
from pathlib import Path
import hashlib
import json

STAGE = Path(__file__).resolve().parent
ARCH = STAGE.parent
ROOT = ARCH.parents[1]
read = lambda p: json.loads(p.read_text(encoding='utf-8-sig'))


def identity(path):
    path = path.resolve()
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())


def check(row, path=None):
    actual = identity(path or Path(row['path']))
    assert all(actual[k] == row[k] for k in ('bytes', 'sha256')), (row, actual)
    return actual


out = STAGE / 'checks/20261019T171411'
dest = ROOT / 'docs/evidence/performance/qwen35-full-cuda-2026-10-19'
receipt = read(dest / 'conv-typed-load-archive.json')
assert receipt['crc_verified'] and receipt['payload_sha256_verified']
check(receipt)
evidence = [identity(dest / name) for name in ('conv-typed-load.zip', 'conv-typed-load-archive.json')]
retained = [check(read(out / 'qwen-image.json')),
    check(read(ARCH / 'gdn-region-suffix/checks/20261019T165656/qwen-image.json')),
    check(read(ARCH / 'cuda-explicit-rope/performance-prepared/peer-image.json')),
    check(read(ARCH / 'decode-next-cold/checks/20261019T155819/cpu-image.json'))]
correctness = read(STAGE / 'correctness/summary.json')['observation']
assert correctness['equal_vectors'] == 64 and len(correctness['vectors']) == 64
references = [check(row['reference']) for row in correctness['vectors']]
targets = {}


def target(path):
    path = path.resolve()
    assert path.is_relative_to(ROOT / '.scratch') and path.is_file()
    targets[str(path).casefold()] = identity(path)


for base in (out / 'conv', STAGE / 'host-probe/baseline', STAGE / 'host-probe/current',
             ARCH / 'gdn-typed-load/checks/20261019T163125/qwen'):
    assert base.with_suffix('.exe').is_file()
    for suffix in ('.exe', '.map', '.exp', '.lib', '.pdb'):
        path = base.with_suffix(suffix)
        if path.exists():
            target(path)
for row in correctness['vectors']:
    actual = check(row['actual'], STAGE / 'correctness/trace' / row['path'])
    assert row['byte_equal'] and actual['sha256'] == row['reference']['sha256']
    target(Path(actual['path']))
build = read(out / 'plan.json')
inputs = {str(Path(p).resolve()).casefold() for link in build['links'].values() for p in link['inputs']}
assert not set(targets).intersection(inputs)
assert not set(targets).intersection(str(Path(row['path']).resolve()).casefold()
    for row in [*retained, *references, *evidence])
plan = dict(evidence=evidence, retained_images=retained, retained_vectors=references,
    current_build_plan=identity(out / 'plan.json'), targets=list(targets.values()),
    count=len(targets), total_bytes=sum(row['bytes'] for row in targets.values()),
    scope='Three temporary test/probe images and one superseded baseline, their link side products and64 duplicate exact vectors; all objects/SDKs/sources/logs and current/baseline/peer/CPU images retained.',
    recursive=False)
path = STAGE / 'cleanup-plan.json'
assert not path.exists()
path.write_text(json.dumps(plan, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
old = (ROOT / 'test.ps1').read_bytes()
(STAGE / 'test-before-reclaim.ps1').write_bytes(old)
script = old.decode('utf-8-sig')
previous_plan = read(ARCH / 'gdn-region-suffix/cleanup-plan.json')
previous_hash = identity(ARCH / 'gdn-region-suffix/cleanup-plan.json')['sha256']
script = script.replace('gdn-region-suffix\\cleanup-plan.json', 'conv-typed-load\\cleanup-plan.json')
script = script.replace('gdn-region-suffix\\cleanup-result.json', 'conv-typed-load\\cleanup-result.json')
assert previous_hash in script
script = script.replace(previous_hash, identity(path)['sha256'])
assert 'gdn-region-suffix\\cleanup-' not in script
(ROOT / 'test.ps1').write_text(script, encoding='utf-8')
(STAGE / 'executed-reclaim.ps1').write_text(script, encoding='utf-8')
print(json.dumps(dict(plan=identity(path), count=plan['count'], bytes=plan['total_bytes'],
    MiB=plan['total_bytes']/1024**2, deletion_executed=False), indent=2))
