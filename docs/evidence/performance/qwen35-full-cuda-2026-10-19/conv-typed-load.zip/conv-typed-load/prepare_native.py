"""Prepare exact-load SSM convolution from the complete current locked replay."""
from pathlib import Path
import difflib
import hashlib
import importlib.util
import json
import sys

sys.dont_write_bytecode = True
STAGE = Path(__file__).resolve().parent
ARCH = STAGE.parent
ROOT = ARCH.parents[1]
UPSTREAM = Path('C:/public/tools/hyle-dependencies/v1/sources/ggml-456172ec733a-41b7e10fd424')


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def sha(data):
    return hashlib.sha256(data).hexdigest()


def save(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8')


def read(path):
    return json.loads(path.read_text(encoding='utf-8'))


def replace(text, old, new):
    assert text.count(old) == 1, old[:120]
    return text.replace(old, new, 1)


def replay(row):
    data = (UPSTREAM / row['path']).read_bytes().replace(b'\r\n', b'\n')
    assert sha(data) == row['before_sha256']
    for edit in row['edits']:
        before, after = edit['before'].encode(), edit['after'].encode()
        assert data.count(before) == 1, row['path']
        data = data.replace(before, after, 1)
    assert sha(data) == row['after_sha256']
    return data


SUPPORT = r'''
// Metadata-only qualification of the actual SSM carrier; sizing has no addresses.
bool ggml_cuda_supports_ssm_conv(const ggml_tensor * dst) {
    if (!dst || dst->op != GGML_OP_SSM_CONV || dst->type != GGML_TYPE_F32) return false;
    const ggml_tensor * const x = dst->src[0], * const w = dst->src[1];
    if (!x || !w || (x->type != GGML_TYPE_BF16 && x->type != GGML_TYPE_F32) || w->type != GGML_TYPE_F32) return false;
    const int64_t W = x->ne[0], C = x->ne[1], B = x->ne[2], K = w->ne[0];
    if (W <= 0 || C <= 0 || C % 128 || B <= 0 || x->ne[3] != 1 ||
        (K != 3 && K != 4 && K != 5 && K != 9 && K != 15) || W < K ||
        w->ne[1] != C || w->ne[2] != 1 || w->ne[3] != 1 ||
        dst->ne[0] != C || dst->ne[1] != W - K + 1 || dst->ne[2] != B || dst->ne[3] != 1) return false;
    // Prove the kernel's signed offsets and all span calculations first.
    const ggml_tensor * const tensors[] = {x, w, dst};
    for (const auto * tensor : tensors) {
        const size_t element = ggml_type_size(tensor->type);
        uint64_t bytes = element;
        for (int axis = 0; axis < GGML_MAX_DIMS; ++axis) {
            if (tensor->ne[axis] <= 0 || tensor->nb[axis] > uint64_t(INT64_MAX) ||
                tensor->nb[axis] % element) return false;
            const uint64_t extent = uint64_t(tensor->ne[axis] - 1);
            if (extent && tensor->nb[axis] > (uint64_t(INT64_MAX) - bytes) / extent) return false;
            bytes += extent * tensor->nb[axis];
        }
    }
    if (C > INT64_MAX / int64_t(sizeof(float)) / K ||
        C > INT64_MAX / int64_t(sizeof(float)) / dst->ne[1] / B) return false;
    if (w->nb[0] != sizeof(float) || w->nb[1] < uint64_t(K) * sizeof(float) ||
        dst->nb[0] != sizeof(float) || (dst->ne[1] > 1 && dst->nb[1] < uint64_t(C) * sizeof(float))) return false;
    const uint64_t output_batch_bytes = uint64_t(dst->ne[1] - 1) * dst->nb[1] + uint64_t(C) * sizeof(float);
    if (B > 1 && dst->nb[2] < output_batch_bytes) return false;
    if (x->type == GGML_TYPE_F32) {
        // Preserve the old F32 carrier's exact time-contiguous layout domain.
        return x->nb[0] == sizeof(float) && x->nb[1] == uint64_t(W) * sizeof(float) &&
            (B == 1 || x->nb[2] >= uint64_t(W) * uint64_t(C) * sizeof(float));
    }
    const uint64_t channel_bytes = uint64_t(C) * sizeof(nv_bfloat16);
    // Native BF16 [W,C,B] is the permutation of channel-contiguous rows.
    // Padding is legal, broadcast/overlapping time or batch rows are not.
    if (x->nb[1] != sizeof(nv_bfloat16) || x->nb[0] < channel_bytes ||
        uint64_t(W - 1) > (uint64_t(INT64_MAX) - channel_bytes) / x->nb[0]) return false;
    const uint64_t batch_bytes = uint64_t(W - 1) * x->nb[0] + channel_bytes;
    return (B == 1 || x->nb[2] >= batch_bytes) && ggml_is_contiguous(dst);
}

'''


BOUND = r'''
// Device limits are captured in the original cold device-info initialization.
// No driver query or shared device-info ABI change is needed during encoding.
static bool ggml_cuda_ssm_conv_device(const ggml_tensor * dst, int device) {
    const auto & info = ggml_cuda_info();
    if (device < 0 || device >= info.device_count ||
        !ggml_cuda_supports_ssm_conv(dst) ||
        (dst->src[0]->type == GGML_TYPE_BF16 && !GGML_CUDA_CC_IS_NVIDIA(info.devices[device].cc))) return false;
    const int64_t T = dst->ne[1];
    const int64_t tiles = T / 32 + (T % 32 != 0);
    const auto & limits = ggml_cuda_ssm_conv_limits[device];
    const size_t shared = T > 32 ? size_t(128) * (size_t(dst->src[1]->ne[0]) + 31) * sizeof(float) : 0;
    return limits[0] > 0 && limits[1] > 0 && limits[2] >= 128 &&
        dst->ne[2] <= limits[0] && dst->ne[0] / 128 <= ggml_cuda_mmvq_grid_y[device] &&
        (T <= 32 || tiles <= limits[1]) && shared <= info.devices[device].smpb;
}

static bool ggml_cuda_ssm_conv_typed_bound(const ggml_tensor * dst, int device,
        const ggml_tensor * bias_add = nullptr, const ggml_tensor * silu_dst = nullptr) {
    if (!ggml_cuda_ssm_conv_device(dst, device)) return false;
    const ggml_tensor * const out = silu_dst ? silu_dst : dst;
    if (!out || out->type != GGML_TYPE_F32 || !ggml_are_same_shape(out, dst) || !ggml_is_contiguous(out)) return false;
    const ggml_tensor * bias = nullptr;
    if (bias_add) {
        if (!silu_dst || bias_add->op != GGML_OP_ADD) return false;
        if (bias_add->src[0] == dst) bias = bias_add->src[1];
        else if (bias_add->src[1] == dst) bias = bias_add->src[0];
        else return false;
        if (!bias || bias->type != GGML_TYPE_F32 || !ggml_is_contiguous(bias) ||
            bias->ne[0] != dst->ne[0] || bias->ne[1] != 1 || bias->ne[2] != 1 || bias->ne[3] != 1) return false;
    }
    const auto bounded = [device](const ggml_tensor * tensor) {
        if (!tensor || !tensor->data || !tensor->buffer || !ggml_backend_buffer_is_cuda(tensor->buffer)) return false;
        const auto * owner = static_cast<const ggml_backend_cuda_buffer_context *>(tensor->buffer->context);
        if (owner->device != device || !owner->dev_ptr) return false;
        const uintptr_t base = reinterpret_cast<uintptr_t>(owner->dev_ptr);
        const uintptr_t begin = reinterpret_cast<uintptr_t>(tensor->data);
        const size_t capacity = ggml_backend_buffer_get_size(tensor->buffer);
        uint64_t bytes = ggml_type_size(tensor->type);
        for (int axis = 0; axis < GGML_MAX_DIMS; ++axis) {
            if (tensor->ne[axis] <= 0) return false;
            const uint64_t extent = uint64_t(tensor->ne[axis] - 1);
            if (extent && tensor->nb[axis] > (uint64_t(INT64_MAX) - bytes) / extent) return false;
            bytes += extent * tensor->nb[axis];
        }
        return begin % ggml_type_size(tensor->type) == 0 && begin >= base &&
            begin - base <= capacity && bytes <= capacity - (begin - base) && bytes <= UINTPTR_MAX - begin;
    };
    if (!bounded(out)) return false;
    const ggml_tensor * const reads[] = {dst->src[0], dst->src[1], bias};
    for (const auto * read : reads) {
        if (!read) continue;
        if (!bounded(read)) return false;
        const uintptr_t begin = reinterpret_cast<uintptr_t>(read->data);
        const uintptr_t end = begin + ggml_nbytes(read);
        const uintptr_t out_begin = reinterpret_cast<uintptr_t>(out->data);
        if (begin < out_begin + ggml_nbytes(out) && out_begin < end) return false;
    }
    return true;
}

'''


def conv_source(old):
    text = old.decode()
    text = replace(text, '#include "unary.cuh"\n', '#include "unary.cuh"\n#include "convert.cuh"\n' + SUPPORT)
    text = replace(text, 'template <bool apply_silu, size_t split_d_inner, size_t d_conv>',
        'template <bool apply_silu, size_t split_d_inner, size_t d_conv, typename TX>')
    text = replace(text, 'template <bool apply_silu, size_t split_d_inner, size_t d_conv, int64_t split_n_t>',
        'template <bool apply_silu, size_t split_d_inner, size_t d_conv, int64_t split_n_t, typename TX>')
    text = replace(text, 'template <bool apply_silu>\nstatic void ssm_conv_f32_cuda',
        'template <bool apply_silu, typename TX>\nstatic void ssm_conv_f32_cuda')
    assert text.count('const float * src0') == 3
    text = text.replace('const float * src0', 'const TX * src0')
    text = replace(text, 'const float * __restrict__ src0', 'const TX * __restrict__ src0')
    text = replace(text, '    const float * GGML_CUDA_RESTRICT src0 = src0_ptr;',
        '    const TX * GGML_CUDA_RESTRICT src0 = src0_ptr;')
    assert text.count('const float * x_block = (const float *)') == 2
    text = text.replace('const float * x_block = (const float *)', 'const TX * x_block = (const TX *)')
    text = text.replace('const int src0_nb', 'const int64_t src0_nb')
    text = text.replace('const int src1_nb', 'const int64_t src1_nb')
    text = text.replace('const int dst_nb', 'const int64_t dst_nb')
    assert text.count('    const int stride_x = src0_nb1 / sizeof(float);') == 2
    text = text.replace('    const int stride_x = src0_nb1 / sizeof(float);',
        '    const int64_t stride_x = src0_nb1 / sizeof(TX);\n    const int64_t stride_t = src0_nb0 / sizeof(TX);')
    text = text.replace('    const int stride_w =', '    const int64_t stride_w =')
    text = text.replace('    const int stride_y =', '    const int64_t stride_y =')
    text = replace(text, '    GGML_UNUSED(src0_nb0);\n', '')
    text = replace(text, 'x[j] = x_block[tid * stride_x + j];',
        'x[j] = ggml_cuda_cast<float>(x_block[tid * stride_x + j * stride_t]);')
    text = replace(text, 'x[(i - 1) % d_conv] = x_block[tid * stride_x + i + d_conv - 1];',
        'x[(i - 1) % d_conv] = ggml_cuda_cast<float>(x_block[tid * stride_x + (i + d_conv - 1) * stride_t]);')
    text = replace(text, '            smem[row * n_cols + col] = x_block[row * stride_x + col];',
        '            // The last tile only owns local_n_t + K - 1 source samples.\n'
        '            // Zero-fill unused columns; every valid MAC input is unchanged.\n'
        '            smem[row * n_cols + col] = col < local_n_t + d_conv - 1\n'
        '                ? ggml_cuda_cast<float>(x_block[row * stride_x + int64_t(col) * stride_t]) : 0.0f;')
    begin = text.index('    int row = tid / load_cols;')
    end = text.index('    __syncthreads();',begin)
    original_loader = text[begin:end]
    bf16_loader = '''    if constexpr (std::is_same_v<TX, nv_bfloat16>) {
        // BF16 samples are channel-contiguous. Adjacent lanes load adjacent
        // channels, then fill the same F32 shared cells as the legacy loader.
#pragma unroll
        for (int col = 0; col < load_cols; ++col) {
            smem[tid * n_cols + col] = col < local_n_t + d_conv - 1
                ? ggml_cuda_cast<float>(x_block[tid * stride_x + int64_t(col) * stride_t]) : 0.0f;
        }
    } else {
'''
    text = text[:begin] + bf16_loader + ''.join('    '+line if line.strip() else line
        for line in original_loader.splitlines(True)) + '    }\n' + text[end:]
    text = text.replace('ssm_conv_f32<apply_silu, threads, kNC>', 'ssm_conv_f32<apply_silu, threads, kNC, TX>')
    text = text.replace('ssm_conv_long_token_f32<apply_silu, threads, kNC, split_n_t>',
        'ssm_conv_long_token_f32<apply_silu, threads, kNC, split_n_t, TX>')
    text = replace(text, '\nvoid ggml_cuda_op_ssm_conv(', '\ntemplate <typename TX>\nstatic void ggml_cuda_op_ssm_conv_impl(')
    text = replace(text, '    GGML_ASSERT(src0->nb[0] == sizeof(float));\n    GGML_ASSERT(src1->nb[0] == sizeof(float));\n    GGML_ASSERT(src0->nb[1] == src0->ne[0] * sizeof(float));',
        '    if constexpr (std::is_same_v<TX, float>) {\n'
        '        GGML_ASSERT(src0->nb[0] == sizeof(float));\n'
        '        GGML_ASSERT(src0->nb[1] == src0->ne[0] * sizeof(float));\n'
        '    }\n    GGML_ASSERT(src1->nb[0] == sizeof(float));')
    text = replace(text, '    const TX * src0_d = (const float *) src0->data;',
        '    const TX * src0_d = (const TX *) src0->data;')
    text = replace(text, '    GGML_ASSERT(src0->type == GGML_TYPE_F32);',
        '    GGML_ASSERT(src0->type == (std::is_same_v<TX, float> ? GGML_TYPE_F32 : GGML_TYPE_BF16));')
    text += r'''

void ggml_cuda_op_ssm_conv(ggml_backend_cuda_context & ctx, ggml_tensor * dst,
        ggml_tensor * bias_add_node, ggml_tensor * silu_dst) {
    if (dst->src[0]->type == GGML_TYPE_BF16) {
        if (!ggml_cuda_supports_ssm_conv(dst)) {
            hyle::compute::ggml_cuda::bridge::fail(cudaErrorInvalidValue, "invalid typed SSM convolution metadata");
        }
        ggml_cuda_op_ssm_conv_impl<nv_bfloat16>(ctx, dst, bias_add_node, silu_dst);
    } else {
        ggml_cuda_op_ssm_conv_impl<float>(ctx, dst, bias_add_node, silu_dst);
    }
}
'''
    return text.encode()


def main_source(old):
    text = old.decode()
    text = replace(text, 'static std::array<int, GGML_CUDA_MAX_DEVICES> ggml_cuda_mmvq_grid_y{};',
        'static std::array<int, GGML_CUDA_MAX_DEVICES> ggml_cuda_mmvq_grid_y{};\n'
        '// grid.x, grid.z, and one-dimensional block capacity; private to this TU.\n'
        'static std::array<std::array<int, 3>, GGML_CUDA_MAX_DEVICES> ggml_cuda_ssm_conv_limits{};')
    text = replace(text, '        ggml_cuda_mmvq_grid_y[id] = prop.maxGridSize[1];',
        '        ggml_cuda_mmvq_grid_y[id] = prop.maxGridSize[1];\n'
        '        ggml_cuda_ssm_conv_limits[id] = {prop.maxGridSize[0], prop.maxGridSize[2],\n'
        '            std::min(prop.maxThreadsPerBlock, prop.maxThreadsDim[0])};')
    anchor = '// New typed reads retain their actual original buffers. Cold supports never\n'
    text = replace(text, anchor, BOUND + anchor)
    text = replace(text, '        case GGML_OP_SSM_CONV:\n            ggml_cuda_op_ssm_conv(ctx, dst);',
        '        case GGML_OP_SSM_CONV:\n'
        '            if ((!dst->src[0] || dst->src[0]->type != GGML_TYPE_F32) &&\n'
        '                !ggml_cuda_ssm_conv_typed_bound(dst, ctx.device)) {\n'
        '                hyle::compute::ggml_cuda::bridge::fail(cudaErrorInvalidValue, "invalid bound typed SSM convolution inputs/output");\n'
        '            }\n            ggml_cuda_op_ssm_conv(ctx, dst);')
    text = replace(text, '    if (ggml_cuda_can_fuse(cgraph, i, { GGML_OP_SSM_CONV, GGML_OP_ADD, GGML_OP_UNARY }, { GGML_UNARY_OP_SILU })) {',
        '    if (ggml_cuda_can_fuse(cgraph, i, { GGML_OP_SSM_CONV, GGML_OP_ADD, GGML_OP_UNARY }, { GGML_UNARY_OP_SILU }) &&\n'
        '        (node->src[0]->type == GGML_TYPE_F32 || ggml_cuda_ssm_conv_typed_bound(\n'
        '            node, cuda_ctx->device, cgraph->nodes[i + 1], cgraph->nodes[i + 2]))) {')
    text = replace(text, '    if (ggml_cuda_can_fuse(cgraph, i, { GGML_OP_SSM_CONV, GGML_OP_UNARY }, { GGML_UNARY_OP_SILU })) {',
        '    if (ggml_cuda_can_fuse(cgraph, i, { GGML_OP_SSM_CONV, GGML_OP_UNARY }, { GGML_UNARY_OP_SILU }) &&\n'
        '        (node->src[0]->type == GGML_TYPE_F32 || ggml_cuda_ssm_conv_typed_bound(\n'
        '            node, cuda_ctx->device, nullptr, cgraph->nodes[i + 1]))) {')
    text = replace(text, '        case GGML_OP_SSM_CONV: {\n            // assumes d_inner % threads == 0\n            return op->src[0]->ne[1] % 128 == 0;\n        }',
        '        case GGML_OP_SSM_CONV:\n            return ggml_cuda_ssm_conv_device(op, dev_ctx->device);')
    return text.encode()


def unique_edits(old, new):
    left, right = old.decode().splitlines(True), new.decode().splitlines(True)
    result, data = [], old
    for group in difflib.SequenceMatcher(None, left, right, autojunk=False).get_grouped_opcodes(4):
        first, last = group[0], group[-1]
        before = ''.join(left[first[1]:last[2]])
        after = ''.join(right[first[3]:last[4]])
        assert data.count(before.encode()) == 1
        data = data.replace(before.encode(), after.encode(), 1)
        result.append(dict(before=before, after=after))
    assert data == new
    return result


def main():
    STAGE.mkdir(exist_ok=True)
    # Prefer the immutable input snapshots on replay after the product manifest
    # has advanced. Never treat our already-applied after source as the baseline.
    inputs = [
        'third_party/ggml_runtime/patches.json', 'third_party/ggml_cpu_runtime/patches.json',
        'third_party/ggml_cuda_runtime/patches.json', 'third_party/ggml_cuda_runtime/iq1-patches.json',
        'src/compute_ggml_runtime/prepare_mixed_cpu_manifest.py',
        'src/compute_ggml_runtime/prepare_cuda_iq1_manifest.py']
    for name in inputs:
        target = STAGE / 'native-before' / name
        if not target.exists():
            target.parent.mkdir(parents=True,exist_ok=True)
            target.write_bytes((ROOT/name).read_bytes())
    original = STAGE / 'native-before'
    mixed = STAGE / 'mixed-cpu-manifest.json'
    load('conv_mixed', original / 'src/compute_ggml_runtime/prepare_mixed_cpu_manifest.py').derive(UPSTREAM,
        original / 'third_party/ggml_runtime/patches.json', original / 'third_party/ggml_cpu_runtime/patches.json', mixed)
    combined = STAGE / 'before-combined.json'
    load('conv_cuda', original / 'src/compute_ggml_runtime/prepare_cuda_iq1_manifest.py').derive(UPSTREAM,
        mixed, original / 'third_party/ggml_cuda_runtime/patches.json', original / 'third_party/ggml_cuda_runtime/iq1-patches.json', combined)
    baseline = {row['path']: replay(row) for row in read(combined)['files']}
    paths = ['src/ggml-cuda/ggml-cuda.cu', 'src/ggml-cuda/ssm-conv.cu', 'src/ggml-cuda/ssm-conv.cuh']
    replacements, frozen, diffs = [], [], []
    for name in paths:
        old = baseline.get(name, (UPSTREAM / name).read_bytes().replace(b'\r\n', b'\n'))
        if name.endswith('ggml-cuda.cu'):
            new = main_source(old)
        elif name.endswith('.cu'):
            new = conv_source(old)
        else:
            new = old + b'\n// Metadata-only qualification of original F32 and private BF16 samples.\nbool ggml_cuda_supports_ssm_conv(const ggml_tensor * dst);\n'
        for folder, data in [('native-before', old), ('native-overlay/source', new)]:
            path = STAGE / folder / name
            path.parent.mkdir(parents=True, exist_ok=True)
            if path.exists() and folder == 'native-before':
                assert path.read_bytes() == data, 'Immutable native baseline changed'
            else:
                path.write_bytes(data)
        replacements.append(dict(path=name, before_sha256=sha(old), after_sha256=sha(new), edits=unique_edits(old, new)))
        frozen.append(dict(path=name, before_sha256=sha(old), after_sha256=sha(new),
            before=str(STAGE / 'native-before' / name), after=str(STAGE / 'native-overlay/source' / name)))
        diffs.extend(difflib.unified_diff(old.decode().splitlines(True), new.decode().splitlines(True), fromfile='a/' + name, tofile='b/' + name))
    save(STAGE / 'native-overlay/replacements.json', dict(files=replacements))
    (STAGE / 'native-overlay/changes.diff').write_text(''.join(diffs), encoding='utf-8')
    save(STAGE / 'native-overlay/source-freeze.json', dict(files=frozen,
        host_ABI_changed=False, public_API_changed=False, shared_by_value_struct_changed=False,
        native_TUs_requiring_refresh=['ggml-cuda.cu', 'ssm-conv.cu'], build_or_GPU_run=False))
    print('OVERLAY_READY', STAGE / 'native-overlay/source-freeze.json')


if __name__ == '__main__':
    main()
