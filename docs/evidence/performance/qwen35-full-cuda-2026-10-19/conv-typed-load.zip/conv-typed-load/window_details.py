"""Summarize the existing window; no new model or timing sample."""
from pathlib import Path
import datetime as dt
import json
import re
import statistics as st
STAGE=Path(__file__).resolve().parent
OUT=STAGE/'performance-rotation'
read=lambda p:json.loads(p.read_text(encoding='utf-8'))
runs=read(OUT/'runs.json')
processes=[]
for row in runs:
    if row['arm']=='llama': continue
    text=(OUT/(row['tag']+'.stderr.log')).read_text(encoding='utf-8')
    cold=[float(x) for x in re.findall(r'cold_batch_seconds=([0-9.eE+\-]+)',text)]
    assert len(cold)==32,(row['tag'],len(cold))
    processes.append(dict(arm=row['arm'],tag=row['tag'],cold_seconds=cold,
        prefill_cold_seconds=cold[0],warm_cold_mean_seconds=st.mean(cold[7:32]),
        prefill_step_seconds=row['phase_step_seconds'][0],
        prefill_other_seconds=row['phase_step_seconds'][0]-cold[0]))
groups={}
for arm in ('baseline','current'):
    selected=[r for r in processes if r['arm']==arm]
    groups[arm]={k:dict(samples=[r[k] for r in selected],median=st.median(r[k] for r in selected))
        for k in ('prefill_cold_seconds','warm_cold_mean_seconds','prefill_step_seconds','prefill_other_seconds')}
records=[read(p) for p in sorted(OUT.glob('*.result.json'))]
zone=dt.timezone(dt.timedelta(hours=8))
result=dict(processes=processes,groups=groups,
    window_beijing=[dt.datetime.fromtimestamp(min(r['started'] for r in records),zone).isoformat(),
                    dt.datetime.fromtimestamp(max(r['finished'] for r in records),zone).isoformat()],
    limitations='Aggregated layout/prepare/bind/replay work; not attributed to any single CPU function. Prefill_other is per-process step minus cold. No profiler and no additional sample.')
(OUT/'window-details.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(groups=groups,window=result['window_beijing']),ensure_ascii=False,indent=2))
