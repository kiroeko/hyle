"""Apply the reviewed typed/strided SSM load extension; no compilation."""
from pathlib import Path
import difflib
import hashlib
import importlib.util
import json
import sys

sys.dont_write_bytecode = True
STAGE = Path(__file__).resolve().parent
ROOT = STAGE.parents[2]
UPSTREAM = Path('C:/public/tools/hyle-dependencies/v1/sources/ggml-456172ec733a-41b7e10fd424')
VENDOR = ROOT / 'third_party/ggml_cuda_runtime'


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def sha(data):
    return hashlib.sha256(data).hexdigest()


def identity(path):
    path = Path(path)
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=sha(data))


def read(path):
    return json.loads(path.read_text(encoding='utf-8'))


def save(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8')


def replay(row):
    data = (UPSTREAM / row['path']).read_bytes().replace(b'\r\n', b'\n')
    assert sha(data) == row['before_sha256']
    for edit in row['edits']:
        before, after = edit['before'].encode(), edit['after'].encode()
        assert data.count(before) == 1, row['path']
        data = data.replace(before, after, 1)
    return data


def tree(root):
    lines = []
    for path in sorted(root.rglob('*'), key=lambda p: p.relative_to(root).as_posix()):
        assert not path.is_symlink()
        if path.is_file():
            data = path.read_bytes().replace(b'\r\n', b'\n').replace(b'\r', b'\n')
            lines.append(path.relative_to(root).as_posix() + '|' + sha(data) + '\n')
    return sha(''.join(lines).encode())


def main():
    product_paths = [VENDOR / 'patches.json', VENDOR / 'NOTICE.md', ROOT / 'cmake/HyleDependencyLock.json']
    product_before = {}
    for path in product_paths:
        relative = path.relative_to(ROOT)
        snapshot = STAGE / 'native-before' / relative
        snapshot.parent.mkdir(parents=True, exist_ok=True)
        if snapshot.exists():
            assert snapshot.read_bytes() == path.read_bytes(), 'Do not reseal an already applied batch'
        else:
            snapshot.write_bytes(path.read_bytes())
        product_before[relative.as_posix()] = identity(snapshot)
    old_lock = read(product_paths[2])
    draft = read(product_paths[0])
    changes = read(STAGE / 'native-overlay/replacements.json')['files']
    for change in changes:
        name = change['path']
        row = next((r for r in draft['files'] if r['path'] == name), None)
        if row is None:
            row = dict(path=name, before_sha256=sha((UPSTREAM / name).read_bytes().replace(b'\r\n', b'\n')), edits=[])
            draft['files'].append(row)
        row['edits'].extend(change['edits'])
        row['after_sha256'] = sha(replay(row))
    proposed = STAGE / 'native-patches.draft.json'
    save(proposed, draft)
    mixed = STAGE / 'mixed-cpu-manifest.json'
    combined = STAGE / 'combined-manifest.json'
    composer = load('conv_seal_composer', ROOT / 'src/compute_ggml_runtime/prepare_cuda_iq1_manifest.py')
    composer.derive(UPSTREAM, mixed, proposed, VENDOR / 'iq1-patches.json', combined)
    replayed = {}
    for row in read(combined)['files']:
        data = replay(row)
        assert sha(data) == row['after_sha256'], row['path']
        replayed[row['path']] = data
    for change in changes:
        target = (STAGE / 'native-overlay/source' / change['path']).read_bytes()
        assert sha(target) == change['after_sha256'] and replayed[change['path']] == target
        before = STAGE / 'native-before' / change['path']
        target_before = STAGE / 'native-before' / change['path']
        assert sha(before.read_bytes()) == change['before_sha256']
        native = STAGE / 'native-source' / change['path']
        native.parent.mkdir(parents=True, exist_ok=True)
        native.write_bytes(target)
    # Materialize only the retained 89-header dependency closure, coherently
    # replayed from the current lock; no cached SDK/source tree is modified.
    headers = []
    for record in read(STAGE.parent / 'cuda-fusion-precision/header-closure.json')['headers']:
        name = record['path']
        data = replayed.get(name, (UPSTREAM / name).read_bytes().replace(b'\r\n', b'\n'))
        target = STAGE / 'native-source' / name
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(data)
        headers.append(dict(path=name, bytes=len(data), sha256=sha(data)))
    assert len(headers) == 89
    gdn_freeze_path = STAGE.parent / 'gdn-typed-load/native-source-freeze.json'
    retained_gdn = []
    for record in read(gdn_freeze_path)['files']:
        if record['path'].endswith(('/gated_delta_net.cu', '/gated_delta_net.cuh')):
            assert sha(replayed[record['path']]) == record['after']['sha256']
            retained_gdn.append(dict(path=record['path'],sha256=record['after']['sha256']))
    assert len(retained_gdn) == 2
    save(STAGE / 'native-header-closure.json', dict(headers=headers, header_count=len(headers),
        total_header_bytes=sum(row['bytes'] for row in headers), SDK_modified=False,
        retained_v23_GDN=retained_gdn, original_native_freeze=identity(gdn_freeze_path),
        selected_dependency_list_origin=identity(STAGE.parent / 'cuda-fusion-precision/header-closure.json')))

    notice = product_paths[1].read_text(encoding='utf-8').rstrip() + '''

The existing SSM convolution kernels accept private BF16 sample carriers with
their actual time/channel/batch strides. Sample values widen at the original
scalar loads; weights, register/shared windows, j-order MAC, bias and output
remain F32 in the original fast-math compilation domain. Private stride and
offset arithmetic uses signed64-bit values. The long-tile loader bounds both
F32 and BF16 reads to the actual final tile and zeroes only unused columns.
Shared cold metadata qualification reflects implemented K templates, shapes,
strides and cached device launch limits; actual typed encoding checks original
CUDA owners, device, capacity, alignment and RESTRICT output/read disjointness.
The stable ordinary SiLU exclusion and explicit output rounding are retained.
No public CausalConv1d descriptor, shared CUDA structure or GDN implementation
is changed. This source change alone establishes neither executed numerical
coverage nor a full-model, workspace or throughput improvement.
'''
    product_paths[0].write_bytes(proposed.read_bytes())
    product_paths[1].write_text(notice, encoding='utf-8', newline='\n')
    lock = read(product_paths[2])
    cuda = next(row for row in lock['dependencies'] if row['name'] == 'ggml_cuda_runtime_patches')
    assert cuda['version'] == 'hyle-ggml-cuda-resource-iq1-inference-v23'
    cuda['version'] = 'hyle-ggml-cuda-resource-iq1-inference-v24'
    cuda['vendored']['tree_sha256'] = tree(VENDOR)
    for record in cuda['license']['files']:
        if record['root'] == 'hyle' and record['path'] == 'third_party/ggml_cuda_runtime/NOTICE.md':
            record['sha256'] = sha(product_paths[1].read_bytes())
    assert [{k:v for k,v in row.items()} for row in lock['dependencies'] if row['name'] != cuda['name']] == [
        row for row in old_lock['dependencies'] if row['name'] != cuda['name']]
    assert {k:v for k,v in old_lock.items() if k != 'dependencies'} == {k:v for k,v in lock.items() if k != 'dependencies'}
    save(product_paths[2], lock)
    entries = {row['name']: row for row in lock['dependencies']}
    source_identity = (entries['ggml_runtime_patches']['vendored']['tree_sha256'] +
        entries['ggml_cpu_runtime_patches']['vendored']['tree_sha256'] +
        sha((ROOT / 'src/compute_ggml_runtime/prepare_mixed_cpu_manifest.py').read_bytes()) +
        sha((ROOT / 'src/compute_ggml_runtime/prepare_cuda_iq1_manifest.py').read_bytes()) +
        cuda['vendored']['tree_sha256'])
    source_id = sha(source_identity.encode())[:16]
    (STAGE / 'provider-version.h').write_text('#pragma once\n#define HYLE_GGML_CUDA_PROVIDER_VERSION "456172ec+iq1-46cbf0e9-resource-' + source_id + '"\n', encoding='utf-8')
    product_records = [dict(path=path.relative_to(ROOT).as_posix(),
        before=product_before[path.relative_to(ROOT).as_posix()], after=identity(path)) for path in product_paths]
    native_records = [dict(path=row['path'], before=identity(STAGE / 'native-before' / row['path']),
        after=identity(STAGE / 'native-source' / row['path'])) for row in changes]
    save(STAGE / 'native-source-freeze.json', dict(version=cuda['version'], source_id=source_id,
        vendor_tree_sha256=cuda['vendored']['tree_sha256'], files=native_records, product_files=product_records,
        sources={row['path']: row['after']['sha256'] for row in native_records},
        all_mixed_CPU_IQ1_CUDA_edits_replayed=True, shared_by_value_struct_changed=False,
        native_TUs_requiring_refresh=['ggml-cuda.cu', 'ssm-conv.cu'],
        private_header='src/ggml-cuda/ssm-conv.cuh; actual owners main and ssm-conv only',
        retained_v23_GDN=retained_gdn,
        SDK_modified=False, compile_run=False, GPU_run=False))
    (STAGE / 'native-changes.diff').write_bytes((STAGE / 'native-overlay/changes.diff').read_bytes())
    save(STAGE / 'native-application.json', dict(applied=product_records, source_id=source_id,
        all_other_dependency_entries_unchanged=True, sglang_untouched=True,
        native_sources=native_records, compile_run=False, GPU_run=False))
    (STAGE / 'audit-native-lock.cmake').write_text('include("' + (ROOT / 'cmake/HyleDependencyVersions.cmake').as_posix() + '")\nhyle_audit_in_tree_dependencies(ggml_cuda_runtime_patches)\n', encoding='utf-8')
    print('APPLIED_NATIVE_V24', source_id)


if __name__ == '__main__':
    main()
