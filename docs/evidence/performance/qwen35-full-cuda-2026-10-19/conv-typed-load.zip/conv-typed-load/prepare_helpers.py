"""Prepare retained-window helpers; no compilation or model execution."""
from pathlib import Path
STAGE=Path(__file__).resolve().parent
OLD=STAGE.parent/'gdn-region-suffix'
for name in ('run_model.py','compare.py','window_details.py'):
    assert not (STAGE/name).exists()
(STAGE/'run_model.py').write_bytes((OLD/'run_model.py').read_bytes())
(STAGE/'window_details.py').write_bytes((OLD/'window_details.py').read_bytes())
code=(OLD/'compare.py').read_text(encoding='utf-8')
code=code.replace("BASELINE = ARCH / 'gdn-typed-load/checks/20261019T163125/qwen.exe'",
    "BASELINE = ARCH / 'gdn-region-suffix/checks/20261019T165656/qwen.exe'")
code=code.replace('9fb98bd227f73d7c9052f737a7d72cfcd0f4b462c16798a7e4c2ee6c0c57a928',
    '82fe75c4544c004b21ed082d33e08581b2c47578e198f94cdf80df95a13e0100')
code=code.replace("ARCH / 'gdn-typed-load/native-source-freeze.json'","STAGE / 'native-source-freeze.json'")
code=code.replace('Retained unchanged9fb98b production carrier image; its trace proved both inputs still F32 because ordinary region discovery split the private Casts.',
    'Retained82fe75c production image with proven704kernels, typed GDN and retained typed RMS; no temporary probe image.')
(STAGE/'compare.py').write_text(code,encoding='utf-8')
print('Prepared model, rotation and window-analysis helpers; no model started')
