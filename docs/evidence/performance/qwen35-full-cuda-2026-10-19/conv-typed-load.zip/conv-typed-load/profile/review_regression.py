"""Read-only, same-phase observations from two retained all-API traces."""
from pathlib import Path
import collections
import hashlib
import json
import re
import sqlite3
import statistics

HERE = Path(__file__).resolve().parent
ARCH = HERE.parents[1]


def identity(path):
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())


def stats(values):
    values = list(values)
    if not values:
        return dict(n=0)
    return dict(n=len(values), min=min(values), median=statistics.median(values),
                mean=statistics.mean(values), max=max(values))


def union_ns(rows):
    total = 0
    end = None
    for row in sorted(rows, key=lambda r:r['start']):
        total += max(0, row['end'] - max(row['start'], end or row['start']))
        end = max(row['end'], end or row['end'])
    return total


def family(name):
    if 'ssm_conv_' in name: return 'Conv'
    if 'cpy_scalar_transpose<' in name: return 'transpose'
    if 'cpy_scalar_contiguous<__nv_bfloat16, float>' in name: return 'BF16_to_F32'
    if 'cpy_scalar_contiguous<float, __nv_bfloat16>' in name: return 'F32_to_BF16'
    if 'internal::gemvx::kernel' in name: return 'cuBLAS_GEMVX'
    if 'hyle_bf16_dual_matvec_silu_epilogue' in name: return 'dual_FFN'
    if 'gemm' in name.lower(): return 'other_GEMM'
    if 'gated_delta_net_cuda<' in name: return 'GDN'
    if 'rms_norm_f32<' in name: return 'RMS'
    if 'hyle_bf16_l2_core<' in name: return 'L2'
    if 'flashinfer::' in name: return 'FlashInfer'
    if 'hyle_explicit_rope<' in name: return 'RoPE'
    return 'other'


def load(stage):
    folder = ARCH / stage / 'profile'
    db = folder / 'capture.sqlite'
    con = sqlite3.connect('file:' + db.as_posix() + '?mode=ro', uri=True)
    con.row_factory = sqlite3.Row
    strings = dict(con.execute('select id,value from StringIds'))
    kernels = [dict(r, name=strings[r['demangledName']]) for r in
               con.execute('select * from CUPTI_ACTIVITY_KIND_KERNEL order by start')]
    copies = [dict(r) for r in con.execute('select * from CUPTI_ACTIVITY_KIND_MEMCPY order by end')]
    tokens = [r for r in copies if r['copyKind'] == 2 and r['bytes'] == 4]
    assert len(tokens) == 32
    tables = {r[0] for r in con.execute("select name from sqlite_master where type='table'")}
    memsets = [dict(r) for r in con.execute('select * from CUPTI_ACTIVITY_KIND_MEMSET')] if 'CUPTI_ACTIVITY_KIND_MEMSET' in tables else []
    phases = []
    families = collections.defaultdict(list)
    symbols = collections.defaultdict(list)
    for i in range(1,32):
        lo,hi = tokens[i-1]['end'],tokens[i]['end']
        rows = [r for r in kernels if lo<r['start'] and r['end']<=hi]
        assert not [r for r in kernels if r['start']<hi and r['end']>lo and r not in rows]
        fs = collections.defaultdict(lambda:dict(count=0,sum_us=0))
        for r in rows:
            key=family(r['name']); duration=(r['end']-r['start'])/1000
            fs[key]['count']+=1;fs[key]['sum_us']+=duration
            if i>=7:
                families[key].append(duration)
                symbols[r['name']].append(duration)
        device = rows + [r for r in copies+memsets if lo<r['start'] and r['end']<=hi]
        first,last=min(r['start'] for r in rows),max(r['end'] for r in rows)
        active=union_ns(device)
        kernel_active=union_ns(rows)
        gaps=[max(0,b['start']-a['end'])/1000 for a,b in zip(rows,rows[1:])]
        phases.append(dict(index=i,kernels=len(rows),interval_us=(hi-lo)/1000,
            kernel_duration_sum_us=sum(r['end']-r['start'] for r in rows)/1000,
            kernel_active_union_us=kernel_active/1000,device_active_union_us=active/1000,
            interval_without_device_activity_us=(hi-lo-active)/1000,
            before_first_kernel_us=(first-lo)/1000,after_last_kernel_us=(hi-last)/1000,
            kernel_span_us=(last-first)/1000,
            kernel_span_without_kernel_activity_us=(last-first-kernel_active)/1000,
            consecutive_kernel_positive_gap_us=stats(x for x in gaps if x>0),families=dict(fs)))
    report=json.loads((folder/'analysis.json').read_text())
    anchor=report['phase_anchor']['prefill_host_anchor_ns']
    prefill=[r for r in kernels if anchor<r['start'] and r['end']<=tokens[0]['end']]
    prefill_families=collections.defaultdict(lambda:dict(count=0,sum_us=0))
    for r in prefill:
        v=prefill_families[family(r['name'])];v['count']+=1;v['sum_us']+=(r['end']-r['start'])/1000
    warm=[p for p in phases if p['index']>=7]
    totals={k:stats(p[k] for p in warm) for k in ('kernels','interval_us','kernel_duration_sum_us',
        'kernel_active_union_us','device_active_union_us','interval_without_device_activity_us',
        'before_first_kernel_us','after_last_kernel_us','kernel_span_us','kernel_span_without_kernel_activity_us')}
    family_totals={k:dict(event_duration_us=stats(v),per_phase_count=stats(p['families'].get(k,{}).get('count',0) for p in warm),
        per_phase_sum_us=stats(p['families'].get(k,{}).get('sum_us',0) for p in warm)) for k,v in families.items()}
    # Removed Conv-input casts and transposes are identified by immediate
    # legacy sequence before Conv, not every unchanged conversion in the model.
    conv_sequences=[]
    for p in warm:
        lo,hi=tokens[p['index']-1]['end'],tokens[p['index']]['end']
        rows=[r for r in kernels if lo<r['start'] and r['end']<=hi]
        for j,r in enumerate(rows):
            if family(r['name'])=='Conv':
                prev=rows[max(0,j-2):j]
                conv_sequences.append(dict(phase=p['index'],conv_us=(r['end']-r['start'])/1000,
                    previous=[dict(family=family(t['name']),us=(t['end']-t['start'])/1000) for t in prev]))
    sequence_families=collections.defaultdict(list)
    for sequence in conv_sequences:
        for item in sequence['previous']:
            sequence_families[item['family']].append(item['us'])
    logs=(folder/'target.stderr.log').read_text()
    preparations=[]
    for line in logs.splitlines():
        match=re.search(r'prepared T=(\d+) visible=(\d+).*cold_batch_seconds=([\deE.+-]+) capture_recorded=(\d+) capture_reused=(\d+)',line)
        if match: preparations.append(dict(T=int(match[1]),visible=int(match[2]),us=float(match[3])*1e6,
            recorded=int(match[4]),reused=int(match[5])))
    rope=sorted([dict(phase=p['index'],duration_us=(r['end']-r['start'])/1000,start_ns=r['start'])
        for p in warm for r in kernels if tokens[p['index']-1]['end']<r['start'] and r['end']<=tokens[p['index']]['end']
        and family(r['name'])=='RoPE'],key=lambda r:r['duration_us'],reverse=True)[:3]
    con.close()
    return dict(sqlite=identity(db),analysis=identity(folder/'analysis.json'),warm=totals,
        families=family_totals,prefill_families=dict(prefill_families),
        warm_phase_observations=[dict(index=p['index'],kernels=p['kernels'],interval_us=p['interval_us'],
            kernel_duration_sum_us=p['kernel_duration_sum_us'],device_active_union_us=p['device_active_union_us'],
            interval_without_device_activity_us=p['interval_without_device_activity_us'],
            before_first_kernel_us=p['before_first_kernel_us'],after_last_kernel_us=p['after_last_kernel_us'],
            Conv_us=p['families']['Conv']['sum_us'],
            projection_us=sum(p['families'][k]['sum_us']for k in ('cuBLAS_GEMVX','dual_FFN')))for p in warm],
        conv_previous_two_event_families={k:dict(count=len(v),event_us=stats(v),mean_sum_us_per_step=sum(v)/25) for k,v in sequence_families.items()},
        conv_sequence_samples=conv_sequences[:2],largest_RoPE_elapsed_events=rope,
        consumer_profiled_warm_cold_batch_us=stats(r['us']for r in preparations[7:]),
        capture_records=report['capture_reports']),symbols


def main():
    old,os=load('gdn-region-suffix');new,ns=load('conv-typed-load')
    common=[]
    for name in os.keys()&ns.keys():
        ov,nv=os[name],ns[name]
        common.append(dict(family=family(name),name=name,old_count=len(ov),current_count=len(nv),
            old_event_mean_us=statistics.mean(ov),current_event_mean_us=statistics.mean(nv),
            current_minus_old_per_step_sum_us=(sum(nv)-sum(ov))/25))
    common.sort(key=lambda r:abs(r['current_minus_old_per_step_sum_us']),reverse=True)
    result=dict(scope='Offline two retained same-input all-API Nsight traces; no model/build/GPU runs',
        method='Warm decode7..31 intervals are bounded by actual consecutive four-byte token D2H completions. Duration sums and interval union gaps are instrumented observations only.',
        baseline=old,current=new,unchanged_exact_symbol_top_duration_deltas=common[:12],
        findings=[
            'Physical reduction is exact in every warm phase:704 to668 kernels;18 sample widens and18 transposes removed;18 typed Conv plus existing GDN/RMS retained.',
            'Conv alone is not a large elapsed regression in these traces:18-call per-step duration median21.440 to21.728us; individual mean1.215831 to1.239447us. The old immediate18widen+18transpose cost mean48.15292us/step. Prefill18long Conv sum163.613 to104.799us.',
            'Unchanged projection kernels drift too:139 cuBLAS GEMVX per-step duration median5856.009 to5905.732us;24dual median2692.611 to2702.469us. Combined projection mean8761.12676 to8806.63480us; these independent-window observations do not isolate causes.',
            'No overall regression appears in these two instrumented warm traces:kernel-duration median9600.637 to9548.146us;interval without traced device activity median1303.031 to1265.107us. The profiled consumer cold_batch mean252.704 to242.652us likewise does not reproduce the unprofiled preparation regression.',
            'Current decode28 has one unchanged RoPE elapsed558.523us;baseline warm maximum1.984us. Preserve this event and all statistics rather than filtering it to create a speed claim. Nsight elapsed alone cannot distinguish scheduling/preemption, other GPU work or instrumentation effects.'
        ],
        minimum_follow_up=['Use root already-running source review to locate repeat cold preparation/actual layout-reuse work; this trace has no C++ prepare spans to attribute it.',
            'Do not widen the native math contract or add speculative kernel changes from the single-window throughput regression; completed64 exact results and physical36-dispatch elimination remain separate facts.'],
        unprofiled_rotation=identity(HERE.parent/'performance-rotation/summary.json'),
        limits=['Separate profiling windows, no paired or simultaneous clocks/cache/scheduling control: duration differences cannot explain the unprofiled throughput regression or establish causality.',
            'Device-active union means only traced process kernel/memcpy/memset intervals. Gaps may contain CPU preparation, command submission, synchronization, external GPU work, scheduling or collection effects; they are not measured pure CPU time.',
            'The exported timeline has no internal C++ prepare/reset spans, occupancy or hardware counters; no host subfunction attribution or memory bandwidth claim is made.'])
    host_path=HERE/'host-api-review.json'
    if host_path.exists():
        host=json.loads(host_path.read_text())
        result['independent_host_API_review']=dict(source=identity(host_path),conclusion=host['conclusion'],
            warm_counts_identical=host['warm_counts_identical'],warm_per_phase_API_count=host['warm_per_phase_API_count'],
            warm_per_phase_counts=host['warm_per_phase_counts'],warm_zero_in_both=host['warm_zero_in_both'])
    (HERE/'regression-review.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    for key,v in (('baseline',old),('current',new)):
        print(key,'warm',json.dumps(v['warm']))
        print(key,'families',json.dumps({k:{'count':t['per_phase_count']['median'],'sum_us':t['per_phase_sum_us']['median'],'event_mean_us':t['event_duration_us']['mean']} for k,t in v['families'].items()}))
        print(key,'prefill',json.dumps(v['prefill_families']))


if __name__=='__main__':main()
