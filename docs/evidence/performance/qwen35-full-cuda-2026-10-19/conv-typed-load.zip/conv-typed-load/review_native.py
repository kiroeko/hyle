"""Static source normalization and address reasoning; no build or GPU work."""
from pathlib import Path
import hashlib
import json

STAGE = Path(__file__).resolve().parent
ARCH = STAGE.parent


def sha(value):
    return hashlib.sha256(value).hexdigest()


def replace(text, before, after):
    assert text.count(before) == 1, before[:100]
    return text.replace(before, after, 1)


def main():
    path = 'src/ggml-cuda/ssm-conv.cu'
    old = (STAGE / 'native-before' / path).read_text(encoding='utf-8')
    new = (STAGE / 'native-overlay/source' / path).read_text(encoding='utf-8')
    left = old[old.index('template <bool apply_silu, size_t'):old.index('template <bool apply_silu>')]
    right = new[new.index('template <bool apply_silu, size_t'):new.index('template <bool apply_silu, typename TX>')]
    loader_begin = right.index('    if constexpr (std::is_same_v<TX, nv_bfloat16>) {')
    loader_end = right.index('    __syncthreads();',loader_begin)
    loader = right[loader_begin:loader_end]
    f32_loader = loader.split('    } else {\n',1)[1]
    assert f32_loader.endswith('    }\n')
    f32_loader = ''.join(line[4:] if line.startswith('    ') else line
        for line in f32_loader[:-6].splitlines(True))
    right = right[:loader_begin] + f32_loader + right[loader_end:]
    normalized = right.replace(', typename TX>', '>').replace('const TX *', 'const float *')
    normalized = normalized.replace('const int64_t src', 'const int src').replace('const int64_t dst', 'const int dst')
    normalized = normalized.replace('const int64_t stride_', 'const int stride_').replace('sizeof(TX)', 'sizeof(float)')
    assert normalized.count('    const int stride_t = src0_nb0 / sizeof(float);\n') == 2
    normalized = normalized.replace('    const int stride_t = src0_nb0 / sizeof(float);\n', '')
    normalized = replace(normalized, '    float       * GGML_CUDA_RESTRICT dst  = dst_ptr;\n',
        '    float       * GGML_CUDA_RESTRICT dst  = dst_ptr;\n    GGML_UNUSED(src0_nb0);\n')
    normalized = replace(normalized,
        'x[j] = ggml_cuda_cast<float>(x_block[tid * stride_x + j * stride_t]);',
        'x[j] = x_block[tid * stride_x + j];')
    normalized = replace(normalized,
        'x[(i - 1) % d_conv] = ggml_cuda_cast<float>(x_block[tid * stride_x + (i + d_conv - 1) * stride_t]);',
        'x[(i - 1) % d_conv] = x_block[tid * stride_x + i + d_conv - 1];')
    normalized = replace(normalized,
        '            // The last tile only owns local_n_t + K - 1 source samples.\n'
        '            // Zero-fill unused columns; every valid MAC input is unchanged.\n'
        '            smem[row * n_cols + col] = col < local_n_t + d_conv - 1\n'
        '                ? ggml_cuda_cast<float>(x_block[row * stride_x + int64_t(col) * stride_t]) : 0.0f;',
        '            smem[row * n_cols + col] = x_block[row * stride_x + col];')
    assert normalized == left, 'An unreviewed kernel-body change remains'
    old_launch = old[old.index('    const int threads = 128;'):old.index('\nvoid ggml_cuda_op_ssm_conv(')]
    new_launch = new[new.index('    const int threads = 128;'):new.index('\ntemplate <typename TX>')]
    assert new_launch.replace(', TX>', '>') == old_launch
    old_main = (STAGE / 'native-before/src/ggml-cuda/ggml-cuda.cu').read_text(encoding='utf-8')
    new_main = (STAGE / 'native-overlay/source/src/ggml-cuda/ggml-cuda.cu').read_text(encoding='utf-8')
    stable_begin = 'static bool ggml_cuda_is_hyle_stable_silu('
    if stable_begin not in old_main:
        stable_begin = 'static bool ggml_cuda_can_fuse('
    # The exact stable marker checks remain literal unchanged strings, including
    # the SSM matcher's existing refusal to absorb the marked ordinary Unary.
    stable_lines = [line for line in old_main.splitlines() if 'StableSilu' in line or 'stable_silu' in line]
    assert stable_lines and all(new_main.count(line) == old_main.count(line) for line in stable_lines)
    partial_domains = 0
    loader_bijections = []
    for K in (3, 4, 5, 9, 15):
        cols = K-1+32
        original_cells=[]
        for tid in range(128):
            row,col=tid//cols,tid%cols
            for idx in range(0,128*cols,128):
                if row<128:
                    original_cells.append((row,col))
                col+=128; row+=col//cols; col%=cols
                if idx>=128*cols-tid-128:
                    break
        bf16_cells=[(tid,col) for tid in range(128) for col in range(cols)]
        assert len(original_cells)==len(set(original_cells))==len(bf16_cells)
        assert set(original_cells)==set(bf16_cells)
        loader_bijections.append(dict(K=K,channels=128,columns=cols,cells=len(bf16_cells),
            original_and_BF16_loaders_write_each_same_cell_once=True))
        for local_T in range(1, 33):
            # Original j-order requires only [0,local_T+K-2], and every such
            # column is loaded. Zeroed columns cannot participate in a MAC.
            used = {i+j for i in range(local_T) for j in range(K)}
            assert used == set(range(local_T+K-1))
            assert all(col < local_T+K-1 for col in used)
            assert all(col not in used for col in range(local_T+K-1,32+K-1))
            partial_domains += 1
    convert = ARCH / 'gdn-typed-load/native-source/src/ggml-cuda/convert.cuh'
    conversion = convert.read_text(encoding='utf-8')
    assert 'return __bfloat162float(x);' in conversion
    report = dict(
        status='static_source_and_address_review_passed_not_numeric_or_GPU_validation',
        kernel_bodies=dict(original_sha256=sha(left.encode()), normalized_sha256=sha(normalized.encode()),
            byte_equal_after_explicit_load_type_stride_width_and_tail_guard_normalization=True,
            changes_undone=[
                'Input TX template and pointer type only; weights/window/shared memory/bias/destination remain float.',
                'Private byte/element strides widen int to int64_t. No public or shared by-value structure changes.',
                'Only three original sample-load statements add exact scalar conversion and truthful time stride.',
                'BF16-only shared-fill lane mapping: each channel lane iterates columns; F32 retains the old mapping.',
                'Long-loader conditional zeroes only columns unused by every valid j-order MAC.']),
        launch_body=dict(original_sha256=sha(old_launch.encode()),
            byte_equal_after_TX_template_argument_normalization=True,
            block_threads=128, long_tile=32, original_K_templates=[3,4,5,9,15]),
        partial_tail=dict(symbolic_domains_checked=partial_domains,
            invariant='0 <= i < local_T and 0 <= j < K imply 0 <= i+j < local_T+K-1.',
            old_F32_counterexample=dict(T=33,K=4,C=128,B=1,W=36,
                tensor_bytes=36*128*4, last_channel_old_prefetch_last_time=66,
                last_legal_time=35, bytes_past_tensor=124),
            applies_to_both_F32_and_BF16=True),
        shared_fill=dict(cell_bijections=loader_bijections,
            actual_value_rule='For every (row,col), both loaders store exact widen(x[row*channel_stride+col*time_stride]) when col<local_T+K-1; otherwise0. The unchanged barrier precedes the unchanged j-order MAC.',
            lane_mapping='Only BF16: tid is the channel, adjacent lanes read contiguous BF16 values. Block size,32-token tile and shared-cell indexing are unchanged.'),
        conversion=dict(path=str(convert),sha256=sha(convert.read_bytes()),
            scalar_BF16_to_F32='Existing ggml_cuda_cast<float> calls __bfloat162float; same helper as materialized copy.',
            F32_identity='Same-type branch returns the original float unchanged.',
            no_lower_precision_product_or_accumulator=True),
        qualified_addresses=[
            'F32 samples retain the legacy time-contiguous nb0=4 and nb1=W*4 domain; BF16 samples use true nb0 time, nb1=2 channel, nb2 batch pitches.',
            'All dimensions positive, all active offsets and byte spans fit signed64; F32 weight channel pitches and F32 output row/batch pitches are retained when nonoverlapping.',
            'Source time/channel/batch bases and all element offsets are computed with64-bit strides. Native grid axes bound blockIdx int values before launch.',
            'The BF16-input carrier produces dense F32 output. Cold metadata checks K/template/shape/stride and cached actual device grid/block/shared-memory limits without any buffer requirement.',
            'Typed encode checks every actual CUDA owner/device/capacity/alignment and pointer range overflow, then disallows output overlap with sample/weight/optional-bias reads.',
            'Unmarked legacy F32 SiLU(+bias) fusion is implemented for typed input and checks its actual final output and bias. Marked ordinary stable SiLU exclusion remains unchanged.'
        ],
        cold_support_correction='Legacy C%128-only support accepted K2 but the switch aborted; shared metadata now declines unsupported K before execution. No duplicate host K table.',
        stable_SiLU_marker_checks_preserved=True,
        changed_private_header='src/ggml-cuda/ssm-conv.cuh',
        header_actual_owners=['src/ggml-cuda/ggml-cuda.cu','src/ggml-cuda/ssm-conv.cu'],
        no_shared_device_info_layout_change=True,
        actual_build=False,actual_GPU_execution=False,
        limitations=[
            'Normalization is source-level mathematical evidence, not proof of compiler code generation or exhaustive NaN payload behavior.',
            'Actual directed CUDA tests, original F32 controls, fixed full-model observations and physical typed-convolution hit remain required.',
            'No throughput or workspace reduction is claimed from these source changes.'])
    (STAGE / 'native-review.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
    print('STATIC_NATIVE_REVIEW_PASSED', STAGE/'native-review.json')


if __name__ == '__main__':
    main()
