"""Reproduce warm component aggregates from the existing nine-process window."""
from pathlib import Path
import json
import re
import statistics as st

OUT = Path(__file__).resolve().parent / 'performance-rotation'
runs = json.loads((OUT / 'runs.json').read_text(encoding='utf-8'))
selected = {'baseline': [], 'current': []}
number = r'([0-9.eE+\-]+)'
for row in runs:
    if row['arm'] not in selected:
        continue
    text = (OUT / (row['tag'] + '.stderr.log')).read_text(encoding='utf-8')
    cold = [float(x) for x in re.findall('cold_batch_seconds=' + number, text)]
    timings = re.findall(r'(?:prefill|decode\d+) tokens=\d+ visible=\d+ seconds=' + number
        + r' submit_seconds=' + number + r' step_seconds=' + number, text)
    assert len(cold) == len(timings) == 32
    values = {k: [] for k in ('cold', 'submit', 'wait_and_token_read',
                              'uploads_and_position_build', 'step')}
    for i in range(7, 32):
        wait, submit, step = map(float, timings[i])
        for key, value in zip(values, (cold[i], submit, wait - submit,
                                      step - cold[i] - wait, step)):
            values[key].append(value * 1e6)
    selected[row['arm']].append({k: st.mean(v) for k, v in values.items()})
groups = {arm: {k: dict(samples=[p[k] for p in processes],
    median=st.median(p[k] for p in processes)) for k in processes[0]}
    for arm, processes in selected.items()}
result = dict(units='microseconds',
    scope='Mean of25 warm per process, then median of3; raw log rounding applies. No new process.',
    groups=groups, limitations='Group medians are not additive. Caller boundaries include queue work; no attribution to Conv or a single CPU function.')
(OUT / 'warm-component-summary.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
print(json.dumps({arm: {k: v['median'] for k, v in rows.items()} for arm, rows in groups.items()}, indent=2))
